"""
Library Manager - High-level native library loading and management.

Provides:
- Library loading with dependency resolution
- Function calling with argument marshalling
- Hook installation by symbol name
- JNI registration helpers
"""

import logging
import struct
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .emulator import Emulator

from .linker import DynamicLinker, LoadedLibrary
from .symbols import JNIMethod, Symbol, SymbolTable

logger = logging.getLogger(__name__)


@dataclass
class FunctionCall:
    """Represents a native function call."""
    address: int
    name: str = ""
    args: tuple = ()
    return_value: Any = None

    # Call state
    success: bool = False
    error: str = ""


@dataclass
class HookedFunction:
    """A hooked native function."""
    name: str
    address: int
    original_bytes: bytes
    hook_address: int
    callback: Callable
    enabled: bool = True


class NativeFunction:
    """
    Wrapper for calling native functions.
    
    Example:
        # Get function
        native_init = lib.get_function("native_init")
        
        # Call with arguments
        result = native_init(arg1, arg2)
        
        # Or with explicit types
        result = native_init.call(
            (arg1, 'int'),
            (arg2, 'pointer'),
            return_type='int'
        )
    """

    def __init__(self, manager: 'LibraryManager', address: int, name: str = ""):
        self._manager = manager
        self._address = address
        self._name = name
        self._return_type = 'int'

    @property
    def address(self) -> int:
        return self._address

    @property
    def name(self) -> str:
        return self._name

    def __call__(self, *args) -> int:
        """Call function with automatic argument handling."""
        return self._manager.call_function(self._address, *args)

    def call(self, *typed_args, return_type: str = 'int') -> Any:
        """
        Call with explicit types.
        
        Args:
            typed_args: Tuples of (value, type)
                Types: 'int', 'long', 'pointer', 'float', 'double', 'string'
            return_type: Return type
        """
        return self._manager.call_function_typed(
            self._address,
            list(typed_args),
            return_type
        )

    def __repr__(self) -> str:
        name = self._name or f"func_0x{self._address:x}"
        return f"NativeFunction({name} @ 0x{self._address:x})"


class Library:
    """
    High-level wrapper for a loaded library.
    
    Example:
        lib = manager.load_library("libnative.so")
        
        # Get function by name
        init = lib["Java_com_example_init"]
        result = init(env, cls)
        
        # List all JNI methods
        for method in lib.jni_methods:
            print(method)
        
        # Hook a function
        lib.hook("processData", my_handler)
    """

    def __init__(self, manager: 'LibraryManager', loaded: LoadedLibrary):
        self._manager = manager
        self._loaded = loaded
        self._functions: dict[str, NativeFunction] = {}

    @property
    def name(self) -> str:
        return self._loaded.name

    @property
    def path(self) -> str:
        return self._loaded.path

    @property
    def base(self) -> int:
        return self._loaded.base_address

    @property
    def size(self) -> int:
        return self._loaded.size

    @property
    def exports(self) -> dict[str, int]:
        return self._loaded.exported_symbols.copy()

    @property
    def imports(self) -> set:
        return self._loaded.imported_symbols.copy()

    @property
    def jni_methods(self) -> list[JNIMethod]:
        """Get JNI methods in this library."""
        return [
            m for m in self._manager.symbols.get_jni_methods()
            if self._manager.symbols.find(m.symbol_name).library == self.name
        ]

    def __getitem__(self, name: str) -> NativeFunction:
        """Get function by name."""
        return self.get_function(name)

    def get_function(self, name: str) -> NativeFunction | None:
        """Get function wrapper by name."""
        if name in self._functions:
            return self._functions[name]

        addr = self._loaded.exported_symbols.get(name)
        if not addr:
            # Try symbol table
            sym = self._manager.symbols.find(name)
            if sym and sym.library == self.name:
                addr = sym.address

        if not addr:
            return None

        func = NativeFunction(self._manager, addr, name)
        self._functions[name] = func
        return func

    def get_symbol(self, name: str) -> Symbol | None:
        """Get symbol by name."""
        sym = self._manager.symbols.find(name)
        if sym and sym.library == self.name:
            return sym
        return None

    def find_symbols(self, pattern: str) -> list[Symbol]:
        """Find symbols by pattern."""
        return [
            sym for sym in self._manager.symbols.find_pattern(pattern)
            if sym.library == self.name
        ]

    def hook(self, name: str, callback: Callable) -> bool:
        """Hook function by name."""
        addr = self._loaded.exported_symbols.get(name)
        if not addr:
            return False
        return self._manager.hook_function(addr, callback)

    def unhook(self, name: str) -> bool:
        """Remove hook by name."""
        addr = self._loaded.exported_symbols.get(name)
        if not addr:
            return False
        return self._manager.unhook_function(addr)

    def call_init(self) -> None:
        """Call library initialization functions."""
        self._manager.linker.call_init(self._loaded)

    def __repr__(self) -> str:
        return f"Library({self.name} @ 0x{self.base:x}, {len(self.exports)} exports)"


class LibraryManager:
    """
    High-level library manager.
    
    Combines linker, symbol table, and provides easy-to-use API
    for loading and interacting with native libraries.
    
    Example:
        manager = LibraryManager(emulator)
        
        # Add search paths
        manager.add_library_path("/data/app/com.example/lib/arm64")
        
        # Load library
        lib = manager.load("libnative.so")
        
        # Find and call JNI method
        method = manager.find_jni_method("com.example.App", "nativeInit")
        result = manager.call(method.address, jni_env, jni_class)
        
        # Hook by name
        manager.hook("Java_com_example_App_getData", my_hook)
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.linker = DynamicLinker(emulator)
        self.symbols = SymbolTable()

        # Libraries
        self._libraries: dict[str, Library] = {}

        # Hooks
        self._hooks: dict[int, HookedFunction] = {}
        self._hook_trampolines: dict[int, int] = {}

        # Trampoline memory
        self._trampoline_base = 0xCAFE0000
        self._trampoline_offset = 0

        # Return address for calls
        self._return_address = 0xDEADBEEF

        # Is 64-bit
        self.is_64bit = emulator.arch in ('arm64', 'aarch64')

        # Setup return hook
        self._setup_return_hook()

    def _setup_return_hook(self) -> None:
        """Setup hook for function return."""

        # Map return address page
        try:
            self.emulator.uc.mem_map(0xDEAD0000, 0x1000)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        # Write invalid instruction to trigger stop
        self.emulator.uc.mem_write(self._return_address, b'\x00' * 4)

    # ==================== Library Paths ====================

    def add_library_path(self, path: str) -> None:
        """Add library search path."""
        self.linker.add_library_path(path)

    def add_android_paths(self, api_level: int = 30) -> None:
        """Add standard Android library paths."""
        arch = "arm64" if self.is_64bit else "arm"

        self.linker.add_library_path(f"/system/lib{'64' if self.is_64bit else ''}")
        self.linker.add_library_path(f"/system/vendor/lib{'64' if self.is_64bit else ''}")
        self.linker.add_library_path(f"/apex/com.android.runtime/lib{'64' if self.is_64bit else ''}")

    # ==================== Library Loading ====================

    def load(self, name: str, init: bool = True) -> Library | None:
        """
        Load a native library.
        
        Args:
            name: Library name or path
            init: Whether to call initialization functions
            
        Returns:
            Library wrapper or None
        """
        lib_name = Path(name).name

        # Already loaded?
        if lib_name in self._libraries:
            return self._libraries[lib_name]

        # Load via linker
        loaded = self.linker.load_library(name)
        if not loaded:
            return None

        # Add symbols to table
        self.symbols.add_library(loaded)

        # Create wrapper
        lib = Library(self, loaded)
        self._libraries[lib_name] = lib

        # Call init
        if init:
            lib.call_init()

        logger.info(f"Loaded library: {lib}")
        return lib

    def get(self, name: str) -> Library | None:
        """Get loaded library by name."""
        return self._libraries.get(Path(name).name)

    def list_libraries(self) -> list[Library]:
        """List all loaded libraries."""
        return list(self._libraries.values())

    # ==================== Symbol Resolution ====================

    def resolve(self, name: str) -> int:
        """Resolve symbol to address."""
        return self.linker.resolve_symbol(name)

    def find_symbol(self, name: str) -> Symbol | None:
        """Find symbol by name."""
        return self.symbols.find(name)

    def find_symbols(self, pattern: str) -> list[Symbol]:
        """Find symbols by pattern."""
        return list(self.symbols.find_pattern(pattern))

    def find_function(self, name: str) -> NativeFunction | None:
        """Find function by name across all libraries."""
        sym = self.symbols.find(name)
        if sym and sym.address:
            return NativeFunction(self, sym.address, name)
        return None

    # ==================== JNI Methods ====================

    def find_jni_method(self, class_name: str, method_name: str) -> JNIMethod | None:
        """Find JNI method by class and method name."""
        return self.symbols.find_jni_method(class_name, method_name)

    def get_jni_methods(self) -> list[JNIMethod]:
        """Get all JNI methods."""
        return self.symbols.get_jni_methods()

    def get_jni_methods_for_class(self, class_name: str) -> list[JNIMethod]:
        """Get JNI methods for a class."""
        return self.symbols.get_jni_methods_for_class(class_name)

    # ==================== Function Calling ====================

    def call(self, address: int, *args) -> int:
        """
        Call native function.
        
        Args:
            address: Function address
            *args: Arguments (integers/pointers)
            
        Returns:
            Return value (x0/r0)
        """
        return self.call_function(address, *args)

    def call_function(self, address: int, *args) -> int:
        """Call function with automatic argument handling."""
        # Set up arguments
        if self.is_64bit:
            # ARM64: x0-x7 for args
            arg_regs = ['x0', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7']
        else:
            # ARM32: r0-r3 for args, rest on stack
            arg_regs = ['r0', 'r1', 'r2', 'r3']

        # Set register args
        for i, arg in enumerate(args[:len(arg_regs)]):
            if isinstance(arg, int):
                self.emulator.set_register(arg_regs[i], arg)
            elif isinstance(arg, bytes):
                # Allocate and copy string
                ptr = self.emulator.alloc_string(arg.decode() if isinstance(arg, bytes) else arg)
                self.emulator.set_register(arg_regs[i], ptr)
            else:
                self.emulator.set_register(arg_regs[i], int(arg))

        # Push remaining args to stack
        if len(args) > len(arg_regs):
            sp = self.emulator.get_register('sp')
            ptr_size = 8 if self.is_64bit else 4

            for i, arg in enumerate(args[len(arg_regs):]):
                offset = i * ptr_size
                if self.is_64bit:
                    self.emulator.uc.mem_write(sp + offset, struct.pack('<Q', arg))
                else:
                    self.emulator.uc.mem_write(sp + offset, struct.pack('<I', arg))

        # Set return address
        self.emulator.set_register('lr', self._return_address)

        # Run
        try:
            self.emulator.uc.emu_start(address, self._return_address, timeout=0, count=0)
        except Exception as e:
            logger.error(f"Function call failed at 0x{address:x}: {e}")
            return 0

        # Get return value
        return self.emulator.get_register('x0' if self.is_64bit else 'r0')

    def call_function_typed(self, address: int, args: list[tuple],
                           return_type: str = 'int') -> Any:
        """
        Call function with typed arguments.
        
        Args:
            address: Function address
            args: List of (value, type) tuples
            return_type: Return value type
        """
        # Convert typed args to raw values
        raw_args = []

        for value, vtype in args:
            if vtype == 'string':
                ptr = self.emulator.alloc_string(value)
                raw_args.append(ptr)
            elif vtype == 'pointer':
                raw_args.append(value if isinstance(value, int) else int(value))
            elif vtype == 'float':
                # Float in integer register (need FPU handling)
                raw_args.append(struct.unpack('<I', struct.pack('<f', value))[0])
            elif vtype == 'double':
                raw_args.append(struct.unpack('<Q', struct.pack('<d', value))[0])
            else:
                raw_args.append(int(value))

        result = self.call_function(address, *raw_args)

        # Convert return value
        if return_type == 'void':
            return None
        elif return_type == 'bool':
            return bool(result)
        elif return_type == 'float':
            return struct.unpack('<f', struct.pack('<I', result & 0xffffffff))[0]
        elif return_type == 'double':
            return struct.unpack('<d', struct.pack('<Q', result))[0]
        elif return_type == 'pointer':
            return result
        else:
            return result

    # ==================== Hooking ====================

    def hook_function(self, address: int, callback: Callable,
                      name: str = "") -> bool:
        """
        Hook function at address.
        
        The callback receives (emulator, args) and can return
        a value to override the return, or None to call original.
        """
        from unicorn import UC_HOOK_CODE

        if address in self._hooks:
            return False

        # Save original bytes
        original = bytes(self.emulator.uc.mem_read(address, 16))

        # Install code hook
        def hook_handler(uc, addr, size, user_data):
            if addr == address:
                # Get arguments
                if self.is_64bit:
                    args = [self.emulator.get_register(f'x{i}') for i in range(8)]
                else:
                    args = [self.emulator.get_register(f'r{i}') for i in range(4)]

                # Call callback
                try:
                    result = callback(self.emulator, args)

                    if result is not None:
                        # Override return
                        self.emulator.set_register('x0' if self.is_64bit else 'r0', result)
                        # Skip to return
                        lr = self.emulator.get_register('lr')
                        self.emulator.set_register('pc', lr)
                except Exception as e:
                    logger.error(f"Hook callback error: {e}")

        hook_handle = self.emulator.uc.hook_add(
            UC_HOOK_CODE, hook_handler, begin=address, end=address+4
        )

        hooked = HookedFunction(
            name=name or f"hook_0x{address:x}",
            address=address,
            original_bytes=original,
            hook_address=hook_handle,
            callback=callback,
        )

        self._hooks[address] = hooked
        logger.debug(f"Hooked function at 0x{address:x}")
        return True

    def hook_by_name(self, name: str, callback: Callable) -> bool:
        """Hook function by symbol name."""
        addr = self.resolve(name)
        if not addr:
            logger.warning(f"Symbol not found: {name}")
            return False
        return self.hook_function(addr, callback, name)

    def unhook_function(self, address: int) -> bool:
        """Remove hook."""
        if address not in self._hooks:
            return False

        hooked = self._hooks[address]

        # Remove UC hook
        try:
            self.emulator.uc.hook_del(hooked.hook_address)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        del self._hooks[address]
        return True

    def unhook_by_name(self, name: str) -> bool:
        """Remove hook by name."""
        addr = self.resolve(name)
        if addr:
            return self.unhook_function(addr)
        return False

    # ==================== Utilities ====================

    def print_summary(self) -> None:
        """Print manager summary."""
        print("=== Library Manager Summary ===")
        print(f"Libraries loaded: {len(self._libraries)}")

        for lib in self._libraries.values():
            print(f"  {lib.name} @ 0x{lib.base:x} ({len(lib.exports)} exports)")

        print()
        self.symbols.print_summary()

    def print_jni_methods(self) -> None:
        """Print all JNI methods."""
        self.symbols.print_jni_methods()
