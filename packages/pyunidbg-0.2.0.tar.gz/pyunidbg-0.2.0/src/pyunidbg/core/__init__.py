"""Core components of PyUniDbg."""

from pyunidbg.core.coverage_visualization import (
    BranchInfo,
    CoverageCollector,
    CoverageDiff,
    CoverageEntry,
    CoverageExporter,
    CoverageFlags,
    CoverageManager,
    CoverageType,
    EmulatorCoverageIntegration,
    FunctionCoverage,
    HTMLCoverageExporter,
    JSONCoverageExporter,
    LCOVExporter,
    create_coverage_manager,
    merge_coverage,
)
from pyunidbg.core.cpu import CPUContext
from pyunidbg.core.dwarf_unwinder import (
    CIE,
    FDE,
    CFARule,
    CFIInterpreter,
    DwarfExpressionEvaluator,
    DwarfUnwinder,
    EHFrameParser,
    RegisterRule,
    UnwindRow,
)
from pyunidbg.core.dwarf_unwinder import RegisterState as DwarfRegisterState
from pyunidbg.core.emulator import Emulator
from pyunidbg.core.exceptions import ExceptionHandler, ExceptionType, Signal, SignalHandler
from pyunidbg.core.hardware_breakpoints import (
    DebugReg,
    HardwareBreakpoint,
    HardwareBreakpointManager,
    HWBPStatus,
    Watchpoint,
    WatchpointHit,
    WatchpointIntegration,
    WatchSize,
    WatchType,
    create_hardware_breakpoint_manager,
)
from pyunidbg.core.hooks import HookAction, HookManager
from pyunidbg.core.library import Library, LibraryManager, NativeFunction
from pyunidbg.core.library_version import (
    VER_DEF,
    VER_FLG,
    VER_NDX,
    LibraryVersion,
    LibraryVersionManager,
    VersionDef,
    VersionedSymbol,
    VersionedSymbolResolver,
    VersionMatcher,
    VersionNeed,
    VersionNeededAux,
    VersionParser,
    elf_hash,
    get_library_version,
    gnu_hash,
    parse_soname,
    soname_matches,
)
from pyunidbg.core.linker import DynamicLinker, ElfRelocation, ElfSymbol, LoadedLibrary
from pyunidbg.core.memory import MemoryManager
from pyunidbg.core.pthread import PthreadHandler
from pyunidbg.core.snapshots import (
    MemoryRegion,
    QuickSnapshot,
    RegisterState,
    Snapshot,
    SnapshotDiff,
    SnapshotFlags,
    SnapshotManager,
    create_snapshot_manager,
)
from pyunidbg.core.symbols import JNIMethod, Symbol, SymbolTable, SymbolType
from pyunidbg.core.threading import (
    Barrier,
    CondVar,
    Mutex,
    RWLock,
    Semaphore,
    Thread,
    ThreadManager,
    ThreadState,
)
from pyunidbg.core.unwinder import Backtrace, StackFrame, StackUnwinder

__all__ = [
    # Core
    "Emulator",
    "MemoryManager",
    "HookManager",
    "HookAction",
    "CPUContext",

    # Linker
    "DynamicLinker",
    "LoadedLibrary",
    "ElfSymbol",
    "ElfRelocation",

    # Symbols
    "SymbolTable",
    "Symbol",
    "SymbolType",
    "JNIMethod",

    # Library Manager
    "LibraryManager",
    "Library",
    "NativeFunction",

    # Threading
    "ThreadManager",
    "Thread",
    "ThreadState",
    "Mutex",
    "CondVar",
    "Semaphore",
    "RWLock",
    "Barrier",
    "PthreadHandler",

    # Exceptions
    "ExceptionHandler",
    "Signal",
    "ExceptionType",
    "SignalHandler",

    # Stack Unwinding
    "StackUnwinder",
    "StackFrame",
    "Backtrace",

    # DWARF Unwinding
    "DwarfUnwinder",
    "EHFrameParser",
    "CFIInterpreter",
    "DwarfExpressionEvaluator",
    "CIE",
    "FDE",
    "UnwindRow",
    "RegisterRule",
    "CFARule",
    "DwarfRegisterState",

    # Snapshots
    "SnapshotManager",
    "Snapshot",
    "SnapshotDiff",
    "SnapshotFlags",
    "MemoryRegion",
    "RegisterState",
    "QuickSnapshot",
    "create_snapshot_manager",

    # Library Versioning
    "VER_DEF",
    "VER_FLG",
    "VER_NDX",
    "VersionDef",
    "VersionNeed",
    "VersionNeededAux",
    "VersionedSymbol",
    "LibraryVersion",
    "elf_hash",
    "gnu_hash",
    "VersionParser",
    "VersionMatcher",
    "VersionedSymbolResolver",
    "LibraryVersionManager",
    "parse_soname",
    "soname_matches",
    "get_library_version",

    # Hardware Breakpoints
    "WatchType",
    "WatchSize",
    "HWBPStatus",
    "DebugReg",
    "Watchpoint",
    "WatchpointHit",
    "HardwareBreakpoint",
    "HardwareBreakpointManager",
    "WatchpointIntegration",
    "create_hardware_breakpoint_manager",

    # Coverage Visualization
    "CoverageType",
    "CoverageFlags",
    "CoverageEntry",
    "BranchInfo",
    "FunctionCoverage",
    "CoverageCollector",
    "CoverageDiff",
    "CoverageExporter",
    "JSONCoverageExporter",
    "HTMLCoverageExporter",
    "LCOVExporter",
    "CoverageManager",
    "EmulatorCoverageIntegration",
    "create_coverage_manager",
    "merge_coverage",
]
