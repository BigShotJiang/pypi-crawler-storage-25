"""
Memory Leak Detection for PyUniDbg.

This module provides heap tracking and memory leak detection for emulated code,
helping identify memory allocation issues like leaks, double frees, and use-after-free.

Features:
- Heap allocation tracking (malloc, calloc, realloc, free)
- Memory leak detection
- Double-free detection
- Use-after-free detection
- Heap statistics and reporting
- Integration with emulator hooks
"""

from __future__ import annotations

import json
import logging
import time
from abc import ABC, abstractmethod
from collections import defaultdict
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from enum import IntEnum, IntFlag
from pathlib import Path
from typing import (
    Any,
    TextIO,
)

logger = logging.getLogger(__name__)


class AllocationState(IntEnum):
    """State of a memory allocation."""
    ACTIVE = 1       # Currently allocated
    FREED = 2        # Has been freed
    REALLOCATED = 3  # Was reallocated to different address


class AllocationFlags(IntFlag):
    """Flags for allocation tracking."""
    NONE = 0
    MALLOC = 1       # Allocated via malloc
    CALLOC = 2       # Allocated via calloc (zeroed)
    REALLOC = 4      # Allocated via realloc
    MMAP = 8         # Allocated via mmap
    MEMALIGN = 16    # Allocated via memalign/aligned_alloc
    NEW = 32         # Allocated via C++ new
    NEW_ARRAY = 64   # Allocated via C++ new[]
    STACK = 128      # Stack allocation


class LeakSeverity(IntEnum):
    """Severity level of a memory leak."""
    INFO = 1         # Small allocation, might be intentional
    WARNING = 2      # Medium allocation, likely a leak
    ERROR = 3        # Large allocation, definitely a problem
    CRITICAL = 4     # Very large or frequent leaks


@dataclass
class AllocationRecord:
    """Record of a single heap allocation."""
    address: int
    size: int
    timestamp: float
    state: AllocationState = AllocationState.ACTIVE
    flags: AllocationFlags = AllocationFlags.MALLOC
    call_stack: list[int] = field(default_factory=list)
    free_timestamp: float | None = None
    free_call_stack: list[int] = field(default_factory=list)
    tag: str | None = None
    reallocated_to: int | None = None

    @property
    def is_active(self) -> bool:
        """Check if allocation is still active."""
        return self.state == AllocationState.ACTIVE

    @property
    def is_freed(self) -> bool:
        """Check if allocation has been freed."""
        return self.state == AllocationState.FREED

    @property
    def lifetime(self) -> float:
        """Get lifetime in seconds (or time since allocation if still active)."""
        if self.free_timestamp:
            return self.free_timestamp - self.timestamp
        return time.time() - self.timestamp

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = {
            "address": hex(self.address),
            "size": self.size,
            "timestamp": self.timestamp,
            "state": self.state.name,
            "flags": int(self.flags),
            "is_active": self.is_active,
        }
        if self.call_stack:
            result["call_stack"] = [hex(addr) for addr in self.call_stack]
        if self.free_timestamp:
            result["free_timestamp"] = self.free_timestamp
        if self.free_call_stack:
            result["free_call_stack"] = [hex(addr) for addr in self.free_call_stack]
        if self.tag:
            result["tag"] = self.tag
        if self.reallocated_to:
            result["reallocated_to"] = hex(self.reallocated_to)
        return result


@dataclass
class LeakReport:
    """Report of a detected memory leak."""
    allocation: AllocationRecord
    severity: LeakSeverity
    description: str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "address": hex(self.allocation.address),
            "size": self.allocation.size,
            "severity": self.severity.name,
            "description": self.description,
            "allocation_time": self.allocation.timestamp,
            "lifetime": self.allocation.lifetime,
            "call_stack": [hex(addr) for addr in self.allocation.call_stack],
        }


@dataclass
class DoubleFreeReport:
    """Report of a double-free error."""
    address: int
    first_free_time: float
    second_free_time: float
    first_call_stack: list[int]
    second_call_stack: list[int]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "address": hex(self.address),
            "first_free_time": self.first_free_time,
            "second_free_time": self.second_free_time,
            "first_call_stack": [hex(addr) for addr in self.first_call_stack],
            "second_call_stack": [hex(addr) for addr in self.second_call_stack],
        }


@dataclass
class UseAfterFreeReport:
    """Report of a use-after-free error."""
    address: int
    access_address: int
    access_size: int
    access_time: float
    free_time: float
    is_write: bool
    call_stack: list[int]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "allocation_address": hex(self.address),
            "access_address": hex(self.access_address),
            "access_size": self.access_size,
            "access_time": self.access_time,
            "free_time": self.free_time,
            "is_write": self.is_write,
            "call_stack": [hex(addr) for addr in self.call_stack],
        }


@dataclass
class HeapStatistics:
    """Statistics about heap usage."""
    total_allocations: int = 0
    total_frees: int = 0
    active_allocations: int = 0
    total_bytes_allocated: int = 0
    total_bytes_freed: int = 0
    active_bytes: int = 0
    peak_bytes: int = 0
    peak_allocations: int = 0
    double_frees: int = 0
    use_after_frees: int = 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "total_allocations": self.total_allocations,
            "total_frees": self.total_frees,
            "active_allocations": self.active_allocations,
            "total_bytes_allocated": self.total_bytes_allocated,
            "total_bytes_freed": self.total_bytes_freed,
            "active_bytes": self.active_bytes,
            "peak_bytes": self.peak_bytes,
            "peak_allocations": self.peak_allocations,
            "double_frees": self.double_frees,
            "use_after_frees": self.use_after_frees,
        }


class HeapTracker:
    """Tracks heap allocations and detects memory issues."""

    def __init__(self, track_call_stacks: bool = True,
                 track_freed: bool = True,
                 detect_use_after_free: bool = True):
        self._allocations: dict[int, AllocationRecord] = {}
        self._freed_allocations: dict[int, AllocationRecord] = {}
        self._track_call_stacks = track_call_stacks
        self._track_freed = track_freed
        self._detect_use_after_free = detect_use_after_free
        self._stats = HeapStatistics()
        self._double_frees: list[DoubleFreeReport] = []
        self._use_after_frees: list[UseAfterFreeReport] = []
        self._enabled = False
        self._get_call_stack: Callable[[], list[int]] | None = None

    @property
    def is_enabled(self) -> bool:
        """Check if tracking is enabled."""
        return self._enabled

    @property
    def statistics(self) -> HeapStatistics:
        """Get heap statistics."""
        return self._stats

    @property
    def double_frees(self) -> list[DoubleFreeReport]:
        """Get list of detected double-frees."""
        return list(self._double_frees)

    @property
    def use_after_frees(self) -> list[UseAfterFreeReport]:
        """Get list of detected use-after-free errors."""
        return list(self._use_after_frees)

    def enable(self) -> None:
        """Enable heap tracking."""
        self._enabled = True
        logger.info("Heap tracking enabled")

    def disable(self) -> None:
        """Disable heap tracking."""
        self._enabled = False
        logger.info("Heap tracking disabled")

    def reset(self) -> None:
        """Reset all tracking data."""
        self._allocations.clear()
        self._freed_allocations.clear()
        self._stats = HeapStatistics()
        self._double_frees.clear()
        self._use_after_frees.clear()
        logger.info("Heap tracking reset")

    def set_call_stack_provider(self, provider: Callable[[], list[int]]) -> None:
        """Set a callback to get the current call stack."""
        self._get_call_stack = provider

    def _get_current_call_stack(self) -> list[int]:
        """Get the current call stack."""
        if self._get_call_stack and self._track_call_stacks:
            return self._get_call_stack()
        return []

    def record_allocation(self, address: int, size: int,
                         flags: AllocationFlags = AllocationFlags.MALLOC,
                         tag: str | None = None) -> AllocationRecord | None:
        """Record a new memory allocation."""
        if not self._enabled:
            return None

        if size <= 0:
            logger.warning(f"Invalid allocation size: {size}")
            return None

        call_stack = self._get_current_call_stack()

        record = AllocationRecord(
            address=address,
            size=size,
            timestamp=time.time(),
            flags=flags,
            call_stack=call_stack,
            tag=tag,
        )

        self._allocations[address] = record

        # Update statistics
        self._stats.total_allocations += 1
        self._stats.active_allocations += 1
        self._stats.total_bytes_allocated += size
        self._stats.active_bytes += size

        if self._stats.active_bytes > self._stats.peak_bytes:
            self._stats.peak_bytes = self._stats.active_bytes
        if self._stats.active_allocations > self._stats.peak_allocations:
            self._stats.peak_allocations = self._stats.active_allocations

        logger.debug(f"Recorded allocation: {hex(address)} ({size} bytes)")
        return record

    def record_free(self, address: int) -> bool:
        """Record a memory free. Returns True if successful, False if error detected."""
        if not self._enabled:
            return True

        # Check for null free (valid, just ignore)
        if address == 0:
            return True

        # Check for double-free
        if address in self._freed_allocations:
            freed_record = self._freed_allocations[address]
            report = DoubleFreeReport(
                address=address,
                first_free_time=freed_record.free_timestamp or 0,
                second_free_time=time.time(),
                first_call_stack=freed_record.free_call_stack,
                second_call_stack=self._get_current_call_stack(),
            )
            self._double_frees.append(report)
            self._stats.double_frees += 1
            logger.error(f"Double-free detected at {hex(address)}")
            return False

        # Check if address was ever allocated
        if address not in self._allocations:
            logger.warning(f"Free of unknown address: {hex(address)}")
            return False

        record = self._allocations[address]

        # Check if already freed (should have been in freed_allocations)
        if record.state == AllocationState.FREED:
            report = DoubleFreeReport(
                address=address,
                first_free_time=record.free_timestamp or 0,
                second_free_time=time.time(),
                first_call_stack=record.free_call_stack,
                second_call_stack=self._get_current_call_stack(),
            )
            self._double_frees.append(report)
            self._stats.double_frees += 1
            logger.error(f"Double-free detected at {hex(address)}")
            return False

        # Mark as freed
        record.state = AllocationState.FREED
        record.free_timestamp = time.time()
        record.free_call_stack = self._get_current_call_stack()

        # Update statistics
        self._stats.total_frees += 1
        self._stats.active_allocations -= 1
        self._stats.active_bytes -= record.size
        self._stats.total_bytes_freed += record.size

        # Move to freed allocations for tracking
        if self._track_freed:
            del self._allocations[address]
            self._freed_allocations[address] = record

        logger.debug(f"Recorded free: {hex(address)}")
        return True

    def record_realloc(self, old_address: int, new_address: int,
                       new_size: int) -> AllocationRecord | None:
        """Record a reallocation. Returns new allocation record."""
        if not self._enabled:
            return None

        # realloc(NULL, size) is equivalent to malloc(size)
        if old_address == 0:
            return self.record_allocation(new_address, new_size, AllocationFlags.REALLOC)

        # realloc(ptr, 0) is equivalent to free(ptr) on some systems
        if new_size == 0:
            self.record_free(old_address)
            return None

        # Get old record
        old_record = self._allocations.get(old_address)
        if not old_record:
            logger.warning(f"Realloc of unknown address: {hex(old_address)}")
            # Still create new allocation
            return self.record_allocation(new_address, new_size, AllocationFlags.REALLOC)

        old_size = old_record.size

        # If same address, just update size
        if old_address == new_address:
            size_diff = new_size - old_size
            old_record.size = new_size
            self._stats.active_bytes += size_diff
            if size_diff > 0:
                self._stats.total_bytes_allocated += size_diff
            else:
                self._stats.total_bytes_freed -= size_diff

            if self._stats.active_bytes > self._stats.peak_bytes:
                self._stats.peak_bytes = self._stats.active_bytes

            return old_record

        # Different address - mark old as reallocated
        old_record.state = AllocationState.REALLOCATED
        old_record.reallocated_to = new_address
        old_record.free_timestamp = time.time()

        # Update stats for old allocation
        self._stats.active_allocations -= 1
        self._stats.active_bytes -= old_size
        self._stats.total_bytes_freed += old_size

        # Move old record
        if self._track_freed:
            del self._allocations[old_address]
            self._freed_allocations[old_address] = old_record

        # Create new allocation
        call_stack = self._get_current_call_stack()
        new_record = AllocationRecord(
            address=new_address,
            size=new_size,
            timestamp=time.time(),
            flags=AllocationFlags.REALLOC,
            call_stack=call_stack,
        )

        self._allocations[new_address] = new_record

        # Update stats
        self._stats.total_allocations += 1
        self._stats.active_allocations += 1
        self._stats.total_bytes_allocated += new_size
        self._stats.active_bytes += new_size

        if self._stats.active_bytes > self._stats.peak_bytes:
            self._stats.peak_bytes = self._stats.active_bytes
        if self._stats.active_allocations > self._stats.peak_allocations:
            self._stats.peak_allocations = self._stats.active_allocations

        logger.debug(f"Recorded realloc: {hex(old_address)} -> {hex(new_address)} ({new_size} bytes)")
        return new_record

    def check_memory_access(self, address: int, size: int,
                           is_write: bool) -> UseAfterFreeReport | None:
        """Check if a memory access is to freed memory. Returns report if error."""
        if not self._enabled or not self._detect_use_after_free:
            return None

        # Check if accessing freed memory
        for freed_addr, record in self._freed_allocations.items():
            # Check if access overlaps with freed allocation
            if (address < freed_addr + record.size and
                address + size > freed_addr):
                report = UseAfterFreeReport(
                    address=freed_addr,
                    access_address=address,
                    access_size=size,
                    access_time=time.time(),
                    free_time=record.free_timestamp or 0,
                    is_write=is_write,
                    call_stack=self._get_current_call_stack(),
                )
                self._use_after_frees.append(report)
                self._stats.use_after_frees += 1
                logger.error(f"Use-after-free detected: accessing {hex(address)} "
                           f"(freed block at {hex(freed_addr)})")
                return report

        return None

    def get_allocation(self, address: int) -> AllocationRecord | None:
        """Get allocation at exact address."""
        return self._allocations.get(address)

    def get_allocation_containing(self, address: int) -> AllocationRecord | None:
        """Get allocation containing an address."""
        for alloc_addr, record in self._allocations.items():
            if alloc_addr <= address < alloc_addr + record.size:
                return record
        return None

    def get_freed_allocation(self, address: int) -> AllocationRecord | None:
        """Get freed allocation at exact address."""
        return self._freed_allocations.get(address)

    def active_allocations(self) -> Iterator[AllocationRecord]:
        """Iterate over active allocations."""
        for record in self._allocations.values():
            if record.is_active:
                yield record

    def all_allocations(self) -> Iterator[AllocationRecord]:
        """Iterate over all allocations (active and freed)."""
        yield from self._allocations.values()
        yield from self._freed_allocations.values()


class LeakDetector:
    """Analyzes heap state to detect and report memory leaks."""

    def __init__(self, tracker: HeapTracker):
        self._tracker = tracker
        self._baseline_allocations: set[int] = set()
        self._small_threshold = 256      # Bytes for INFO severity
        self._medium_threshold = 4096    # Bytes for WARNING severity
        self._large_threshold = 65536    # Bytes for ERROR severity

    def set_severity_thresholds(self, small: int, medium: int, large: int) -> None:
        """Set the size thresholds for leak severity classification."""
        self._small_threshold = small
        self._medium_threshold = medium
        self._large_threshold = large

    def mark_baseline(self) -> int:
        """Mark current allocations as baseline (not leaks). Returns count."""
        self._baseline_allocations.clear()
        for record in self._tracker.active_allocations():
            self._baseline_allocations.add(record.address)
        return len(self._baseline_allocations)

    def clear_baseline(self) -> None:
        """Clear the baseline."""
        self._baseline_allocations.clear()

    def _get_severity(self, size: int) -> LeakSeverity:
        """Determine severity based on allocation size."""
        if size >= self._large_threshold:
            return LeakSeverity.CRITICAL
        elif size >= self._medium_threshold:
            return LeakSeverity.ERROR
        elif size >= self._small_threshold:
            return LeakSeverity.WARNING
        return LeakSeverity.INFO

    def detect_leaks(self, exclude_baseline: bool = True) -> list[LeakReport]:
        """Detect memory leaks from active allocations."""
        leaks = []

        for record in self._tracker.active_allocations():
            # Skip baseline allocations
            if exclude_baseline and record.address in self._baseline_allocations:
                continue

            severity = self._get_severity(record.size)
            description = (
                f"Memory leak: {record.size} bytes allocated at {hex(record.address)}, "
                f"never freed (lifetime: {record.lifetime:.2f}s)"
            )

            leak = LeakReport(
                allocation=record,
                severity=severity,
                description=description,
            )
            leaks.append(leak)

        # Sort by severity (highest first), then by size (largest first)
        leaks.sort(key=lambda l: (-l.severity, -l.allocation.size))

        return leaks

    def get_summary(self) -> dict[str, Any]:
        """Get a summary of leak detection results."""
        leaks = self.detect_leaks()
        stats = self._tracker.statistics

        by_severity = defaultdict(int)
        total_leaked_bytes = 0

        for leak in leaks:
            by_severity[leak.severity.name] += 1
            total_leaked_bytes += leak.allocation.size

        return {
            "total_leaks": len(leaks),
            "total_leaked_bytes": total_leaked_bytes,
            "by_severity": dict(by_severity),
            "heap_stats": stats.to_dict(),
            "double_frees": stats.double_frees,
            "use_after_frees": stats.use_after_frees,
        }


class LeakReporter(ABC):
    """Base class for leak reporters."""

    @abstractmethod
    def report(self, detector: LeakDetector, output: str | Path | TextIO) -> None:
        """Generate a leak report."""
        ...  # pragma: no cover


class JSONLeakReporter(LeakReporter):
    """Reports leaks as JSON."""

    def __init__(self, include_call_stacks: bool = True, pretty: bool = True):
        self._include_call_stacks = include_call_stacks
        self._pretty = pretty

    def report(self, detector: LeakDetector, output: str | Path | TextIO) -> None:
        """Generate JSON leak report."""
        leaks = detector.detect_leaks()
        summary = detector.get_summary()

        data = {
            "summary": summary,
            "leaks": [leak.to_dict() for leak in leaks],
            "double_frees": [df.to_dict() for df in detector._tracker.double_frees],
            "use_after_frees": [uaf.to_dict() for uaf in detector._tracker.use_after_frees],
            "timestamp": time.time(),
        }

        if not self._include_call_stacks:
            for leak in data["leaks"]:
                leak.pop("call_stack", None)
            for df in data["double_frees"]:
                df.pop("first_call_stack", None)
                df.pop("second_call_stack", None)
            for uaf in data["use_after_frees"]:
                uaf.pop("call_stack", None)

        indent = 2 if self._pretty else None

        if isinstance(output, (str, Path)):
            with open(output, "w") as f:
                json.dump(data, f, indent=indent)
        else:
            json.dump(data, output, indent=indent)


class TextLeakReporter(LeakReporter):
    """Reports leaks as human-readable text."""

    def __init__(self, include_call_stacks: bool = True, max_leaks: int = 100):
        self._include_call_stacks = include_call_stacks
        self._max_leaks = max_leaks

    def report(self, detector: LeakDetector, output: str | Path | TextIO) -> None:
        """Generate text leak report."""
        lines = []
        lines.append("=" * 60)
        lines.append("MEMORY LEAK REPORT")
        lines.append("=" * 60)
        lines.append("")

        # Summary
        summary = detector.get_summary()
        stats = summary["heap_stats"]

        lines.append("HEAP STATISTICS:")
        lines.append(f"  Total allocations: {stats['total_allocations']}")
        lines.append(f"  Total frees: {stats['total_frees']}")
        lines.append(f"  Active allocations: {stats['active_allocations']}")
        lines.append(f"  Active bytes: {stats['active_bytes']:,}")
        lines.append(f"  Peak bytes: {stats['peak_bytes']:,}")
        lines.append("")

        # Errors
        if summary["double_frees"] > 0:
            lines.append(f"⚠️  DOUBLE-FREES DETECTED: {summary['double_frees']}")
        if summary["use_after_frees"] > 0:
            lines.append(f"⚠️  USE-AFTER-FREES DETECTED: {summary['use_after_frees']}")

        lines.append("")
        lines.append("LEAK SUMMARY:")
        lines.append(f"  Total leaks: {summary['total_leaks']}")
        lines.append(f"  Total leaked bytes: {summary['total_leaked_bytes']:,}")

        for severity, count in summary["by_severity"].items():
            lines.append(f"  {severity}: {count}")

        lines.append("")
        lines.append("-" * 60)
        lines.append("LEAK DETAILS:")
        lines.append("-" * 60)

        leaks = detector.detect_leaks()
        for i, leak in enumerate(leaks[:self._max_leaks]):
            lines.append("")
            lines.append(f"Leak #{i+1} [{leak.severity.name}]")
            lines.append(f"  Address: {hex(leak.allocation.address)}")
            lines.append(f"  Size: {leak.allocation.size:,} bytes")
            lines.append(f"  Lifetime: {leak.allocation.lifetime:.2f}s")
            if leak.allocation.tag:
                lines.append(f"  Tag: {leak.allocation.tag}")
            if self._include_call_stacks and leak.allocation.call_stack:
                lines.append("  Call stack:")
                for addr in leak.allocation.call_stack[:10]:
                    lines.append(f"    {hex(addr)}")

        if len(leaks) > self._max_leaks:
            lines.append(f"... and {len(leaks) - self._max_leaks} more leaks")

        lines.append("")
        lines.append("=" * 60)

        content = "\n".join(lines)

        if isinstance(output, (str, Path)):
            with open(output, "w") as f:
                f.write(content)
        else:
            output.write(content)


class MemoryLeakManager:
    """Main manager for memory leak detection."""

    def __init__(self, track_call_stacks: bool = True,
                 detect_use_after_free: bool = True):
        self._tracker = HeapTracker(
            track_call_stacks=track_call_stacks,
            detect_use_after_free=detect_use_after_free,
        )
        self._detector = LeakDetector(self._tracker)
        self._reporters: dict[str, LeakReporter] = {
            "json": JSONLeakReporter(),
            "text": TextLeakReporter(),
        }

    @property
    def tracker(self) -> HeapTracker:
        """Get the heap tracker."""
        return self._tracker

    @property
    def detector(self) -> LeakDetector:
        """Get the leak detector."""
        return self._detector

    @property
    def is_enabled(self) -> bool:
        """Check if leak detection is enabled."""
        return self._tracker.is_enabled

    def start(self) -> None:
        """Start leak detection."""
        self._tracker.enable()

    def stop(self) -> None:
        """Stop leak detection."""
        self._tracker.disable()

    def reset(self) -> None:
        """Reset all tracking data."""
        self._tracker.reset()
        self._detector.clear_baseline()

    def mark_baseline(self) -> int:
        """Mark current allocations as baseline."""
        return self._detector.mark_baseline()

    def set_call_stack_provider(self, provider: Callable[[], list[int]]) -> None:
        """Set callback to get current call stack."""
        self._tracker.set_call_stack_provider(provider)

    # Allocation tracking shortcuts
    def malloc(self, address: int, size: int, tag: str | None = None) -> AllocationRecord | None:
        """Record a malloc allocation."""
        return self._tracker.record_allocation(address, size, AllocationFlags.MALLOC, tag)

    def calloc(self, address: int, nmemb: int, size: int,
               tag: str | None = None) -> AllocationRecord | None:
        """Record a calloc allocation."""
        return self._tracker.record_allocation(address, nmemb * size, AllocationFlags.CALLOC, tag)

    def realloc(self, old_address: int, new_address: int,
                new_size: int) -> AllocationRecord | None:
        """Record a realloc."""
        return self._tracker.record_realloc(old_address, new_address, new_size)

    def free(self, address: int) -> bool:
        """Record a free."""
        return self._tracker.record_free(address)

    def check_access(self, address: int, size: int,
                    is_write: bool) -> UseAfterFreeReport | None:
        """Check memory access for use-after-free."""
        return self._tracker.check_memory_access(address, size, is_write)

    # Detection and reporting
    def detect_leaks(self) -> list[LeakReport]:
        """Detect memory leaks."""
        return self._detector.detect_leaks()

    def get_summary(self) -> dict[str, Any]:
        """Get leak detection summary."""
        return self._detector.get_summary()

    def get_statistics(self) -> HeapStatistics:
        """Get heap statistics."""
        return self._tracker.statistics

    def register_reporter(self, name: str, reporter: LeakReporter) -> None:
        """Register a custom reporter."""
        self._reporters[name] = reporter

    def report(self, format: str, output: str | Path | TextIO) -> None:
        """Generate a leak report."""
        if format not in self._reporters:
            raise ValueError(f"Unknown format: {format}. Available: {list(self._reporters.keys())}")
        self._reporters[format].report(self._detector, output)

    def report_json(self, output: str | Path | TextIO) -> None:
        """Generate JSON report."""
        self.report("json", output)

    def report_text(self, output: str | Path | TextIO) -> None:
        """Generate text report."""
        self.report("text", output)


class EmulatorLeakIntegration:
    """Integration with emulator for automatic leak detection."""

    def __init__(self, manager: MemoryLeakManager):
        self._manager = manager
        self._malloc_hook = None
        self._free_hook = None

    def install_hooks(self, emulator: Any,
                     malloc_address: int,
                     free_address: int,
                     realloc_address: int | None = None,
                     calloc_address: int | None = None) -> None:
        """Install hooks for heap functions.
        
        Note: This is a simplified version. Real implementation would
        need to understand calling convention and extract arguments.
        """
        self._manager.start()
        logger.info(f"Installed leak detection hooks: malloc@{hex(malloc_address)}, "
                   f"free@{hex(free_address)}")

    def remove_hooks(self, emulator: Any) -> None:
        """Remove leak detection hooks."""
        self._manager.stop()


def create_memory_leak_manager(track_call_stacks: bool = True,
                               detect_use_after_free: bool = True) -> tuple[MemoryLeakManager, EmulatorLeakIntegration]:
    """Factory function to create a memory leak manager.
    
    Returns:
        Tuple of (MemoryLeakManager, EmulatorLeakIntegration)
    """
    manager = MemoryLeakManager(
        track_call_stacks=track_call_stacks,
        detect_use_after_free=detect_use_after_free,
    )
    integration = EmulatorLeakIntegration(manager)
    return manager, integration
