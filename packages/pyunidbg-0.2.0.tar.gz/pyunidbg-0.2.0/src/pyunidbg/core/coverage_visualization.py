"""
Code Coverage Visualization for PyUniDbg.

This module provides code coverage tracking and visualization for emulated code,
generating HTML and JSON reports showing which instructions/blocks were executed.

Features:
- Basic block coverage tracking
- Instruction-level coverage
- Function coverage statistics
- HTML report generation with syntax highlighting
- JSON export for integration with other tools
- Coverage diff between runs
- Branch coverage analysis
"""

from __future__ import annotations

import html
import json
import logging
import time
from abc import ABC, abstractmethod
from collections import defaultdict
from collections.abc import Iterator
from dataclasses import dataclass, field
from enum import IntEnum, IntFlag
from pathlib import Path
from typing import (
    Any,
    TextIO,
)

logger = logging.getLogger(__name__)


class CoverageType(IntEnum):
    """Type of coverage being tracked."""
    INSTRUCTION = 1
    BASIC_BLOCK = 2
    FUNCTION = 3
    BRANCH = 4


class CoverageFlags(IntFlag):
    """Flags for coverage entries."""
    NONE = 0
    EXECUTED = 1
    CONDITIONAL = 2
    INDIRECT = 4
    CALL = 8
    RETURN = 16
    LOOP_HEADER = 32
    EXCEPTION_HANDLER = 64


@dataclass
class CoverageEntry:
    """Single coverage entry for an address."""
    address: int
    size: int
    hit_count: int = 0
    flags: CoverageFlags = CoverageFlags.NONE
    first_hit_time: float = 0.0
    last_hit_time: float = 0.0
    source_file: str | None = None
    source_line: int | None = None
    function_name: str | None = None

    def record_hit(self) -> None:
        """Record a hit on this entry."""
        now = time.time()
        if self.hit_count == 0:
            self.first_hit_time = now
        self.last_hit_time = now
        self.hit_count += 1
        self.flags |= CoverageFlags.EXECUTED

    def was_executed(self) -> bool:
        """Check if this entry was executed."""
        return self.hit_count > 0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = {
            "address": hex(self.address),
            "size": self.size,
            "hit_count": self.hit_count,
            "flags": int(self.flags),
            "executed": self.was_executed(),
        }
        if self.first_hit_time > 0:
            result["first_hit_time"] = self.first_hit_time
        if self.last_hit_time > 0:
            result["last_hit_time"] = self.last_hit_time
        if self.source_file:
            result["source_file"] = self.source_file
        if self.source_line is not None:
            result["source_line"] = self.source_line
        if self.function_name:
            result["function_name"] = self.function_name
        return result

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CoverageEntry:
        """Create from dictionary."""
        address = int(data["address"], 16) if isinstance(data["address"], str) else data["address"]
        entry = cls(
            address=address,
            size=data["size"],
            hit_count=data.get("hit_count", 0),
            flags=CoverageFlags(data.get("flags", 0)),
        )
        entry.first_hit_time = data.get("first_hit_time", 0.0)
        entry.last_hit_time = data.get("last_hit_time", 0.0)
        entry.source_file = data.get("source_file")
        entry.source_line = data.get("source_line")
        entry.function_name = data.get("function_name")
        return entry


@dataclass
class BranchInfo:
    """Information about a branch and its coverage."""
    source_address: int
    target_taken: int
    target_not_taken: int
    taken_count: int = 0
    not_taken_count: int = 0

    @property
    def is_fully_covered(self) -> bool:
        """Check if both paths were taken."""
        return self.taken_count > 0 and self.not_taken_count > 0

    @property
    def coverage_ratio(self) -> float:
        """Get the coverage ratio (0.0, 0.5, or 1.0)."""
        if self.taken_count > 0 and self.not_taken_count > 0:
            return 1.0
        elif self.taken_count > 0 or self.not_taken_count > 0:
            return 0.5
        return 0.0

    def record_taken(self) -> None:
        """Record that the branch was taken."""
        self.taken_count += 1

    def record_not_taken(self) -> None:
        """Record that the branch was not taken."""
        self.not_taken_count += 1

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "source": hex(self.source_address),
            "target_taken": hex(self.target_taken),
            "target_not_taken": hex(self.target_not_taken),
            "taken_count": self.taken_count,
            "not_taken_count": self.not_taken_count,
            "fully_covered": self.is_fully_covered,
        }


@dataclass
class FunctionCoverage:
    """Coverage information for a function."""
    name: str
    start_address: int
    end_address: int
    entry_count: int = 0
    blocks: list[CoverageEntry] = field(default_factory=list)
    branches: list[BranchInfo] = field(default_factory=list)

    @property
    def total_blocks(self) -> int:
        """Get total number of blocks."""
        return len(self.blocks)

    @property
    def covered_blocks(self) -> int:
        """Get number of covered blocks."""
        return sum(1 for b in self.blocks if b.was_executed())

    @property
    def block_coverage_percent(self) -> float:
        """Get block coverage percentage."""
        if self.total_blocks == 0:
            return 0.0
        return (self.covered_blocks / self.total_blocks) * 100

    @property
    def total_branches(self) -> int:
        """Get total number of branches."""
        return len(self.branches)

    @property
    def fully_covered_branches(self) -> int:
        """Get number of fully covered branches."""
        return sum(1 for b in self.branches if b.is_fully_covered)

    @property
    def branch_coverage_percent(self) -> float:
        """Get branch coverage percentage."""
        if self.total_branches == 0:
            return 0.0
        return (self.fully_covered_branches / self.total_branches) * 100

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "start": hex(self.start_address),
            "end": hex(self.end_address),
            "entry_count": self.entry_count,
            "total_blocks": self.total_blocks,
            "covered_blocks": self.covered_blocks,
            "block_coverage_percent": round(self.block_coverage_percent, 2),
            "total_branches": self.total_branches,
            "fully_covered_branches": self.fully_covered_branches,
            "branch_coverage_percent": round(self.branch_coverage_percent, 2),
        }


class CoverageCollector:
    """Collects code coverage data during emulation."""

    def __init__(self, coverage_type: CoverageType = CoverageType.BASIC_BLOCK):
        self._type = coverage_type
        self._entries: dict[int, CoverageEntry] = {}
        self._branches: dict[int, BranchInfo] = {}
        self._functions: dict[str, FunctionCoverage] = {}
        self._module_bases: dict[str, int] = {}
        self._start_time: float = 0.0
        self._enabled = False
        self._total_instructions = 0

    @property
    def coverage_type(self) -> CoverageType:
        """Get the coverage type."""
        return self._type

    @property
    def is_enabled(self) -> bool:
        """Check if collection is enabled."""
        return self._enabled

    @property
    def total_entries(self) -> int:
        """Get total number of tracked entries."""
        return len(self._entries)

    @property
    def covered_entries(self) -> int:
        """Get number of executed entries."""
        return sum(1 for e in self._entries.values() if e.was_executed())

    @property
    def coverage_percent(self) -> float:
        """Get overall coverage percentage."""
        if self.total_entries == 0:
            return 0.0
        return (self.covered_entries / self.total_entries) * 100

    @property
    def total_instructions_executed(self) -> int:
        """Get total instructions executed."""
        return self._total_instructions

    def enable(self) -> None:
        """Enable coverage collection."""
        self._enabled = True
        if self._start_time == 0.0:
            self._start_time = time.time()

    def disable(self) -> None:
        """Disable coverage collection."""
        self._enabled = False

    def reset(self) -> None:
        """Reset all coverage data."""
        self._entries.clear()
        self._branches.clear()
        self._functions.clear()
        self._start_time = 0.0
        self._total_instructions = 0

    def add_module(self, name: str, base_address: int) -> None:
        """Register a module for coverage tracking."""
        self._module_bases[name] = base_address
        logger.debug(f"Registered module {name} at {hex(base_address)}")

    def add_entry(self, address: int, size: int, flags: CoverageFlags = CoverageFlags.NONE) -> CoverageEntry:
        """Add a coverage entry."""
        if address not in self._entries:
            self._entries[address] = CoverageEntry(address=address, size=size, flags=flags)
        return self._entries[address]

    def add_branch(self, source: int, target_taken: int, target_not_taken: int) -> BranchInfo:
        """Add a branch for tracking."""
        if source not in self._branches:
            self._branches[source] = BranchInfo(
                source_address=source,
                target_taken=target_taken,
                target_not_taken=target_not_taken,
            )
        return self._branches[source]

    def add_function(self, name: str, start: int, end: int) -> FunctionCoverage:
        """Add a function for tracking."""
        if name not in self._functions:
            self._functions[name] = FunctionCoverage(
                name=name,
                start_address=start,
                end_address=end,
            )
        return self._functions[name]

    def record_execution(self, address: int, size: int = 1) -> None:
        """Record execution at an address."""
        if not self._enabled:
            return

        self._total_instructions += 1

        if address in self._entries:
            self._entries[address].record_hit()
        else:
            # Auto-add entry on first hit
            entry = self.add_entry(address, size)
            entry.record_hit()

    def record_branch_taken(self, source: int, target: int) -> None:
        """Record a branch being taken."""
        if not self._enabled:
            return

        if source in self._branches:
            branch = self._branches[source]
            if target == branch.target_taken:
                branch.record_taken()
            elif target == branch.target_not_taken:
                branch.record_not_taken()

    def record_function_entry(self, address: int) -> None:
        """Record function entry."""
        if not self._enabled:
            return

        for func in self._functions.values():
            if func.start_address == address:
                func.entry_count += 1
                break

    def get_entry(self, address: int) -> CoverageEntry | None:
        """Get entry at address."""
        return self._entries.get(address)

    def get_branch(self, address: int) -> BranchInfo | None:
        """Get branch at address."""
        return self._branches.get(address)

    def get_function(self, name: str) -> FunctionCoverage | None:
        """Get function by name."""
        return self._functions.get(name)

    def get_function_at(self, address: int) -> FunctionCoverage | None:
        """Get function containing address."""
        for func in self._functions.values():
            if func.start_address <= address < func.end_address:
                return func
        return None

    def entries(self) -> Iterator[CoverageEntry]:
        """Iterate over all entries."""
        yield from self._entries.values()

    def branches(self) -> Iterator[BranchInfo]:
        """Iterate over all branches."""
        yield from self._branches.values()

    def functions(self) -> Iterator[FunctionCoverage]:
        """Iterate over all functions."""
        yield from self._functions.values()

    def get_coverage_summary(self) -> dict[str, Any]:
        """Get coverage summary statistics."""
        total_branch_count = len(self._branches)
        covered_branches = sum(1 for b in self._branches.values() if b.coverage_ratio > 0)
        fully_covered_branches = sum(1 for b in self._branches.values() if b.is_fully_covered)

        return {
            "coverage_type": self._type.name,
            "total_entries": self.total_entries,
            "covered_entries": self.covered_entries,
            "coverage_percent": round(self.coverage_percent, 2),
            "total_branches": total_branch_count,
            "covered_branches": covered_branches,
            "fully_covered_branches": fully_covered_branches,
            "branch_coverage_percent": round(
                (fully_covered_branches / total_branch_count * 100) if total_branch_count > 0 else 0.0, 2
            ),
            "total_functions": len(self._functions),
            "covered_functions": sum(1 for f in self._functions.values() if f.entry_count > 0),
            "total_instructions_executed": self._total_instructions,
            "modules": list(self._module_bases.keys()),
        }


@dataclass
class CoverageDiff:
    """Diff between two coverage runs."""
    baseline_summary: dict[str, Any]
    current_summary: dict[str, Any]
    new_covered: list[int]  # Addresses newly covered
    no_longer_covered: list[int]  # Addresses no longer covered

    @property
    def coverage_delta(self) -> float:
        """Get the coverage percentage change."""
        baseline = self.baseline_summary.get("coverage_percent", 0.0)
        current = self.current_summary.get("coverage_percent", 0.0)
        return current - baseline

    @property
    def entries_delta(self) -> int:
        """Get the entry count change."""
        baseline = self.baseline_summary.get("covered_entries", 0)
        current = self.current_summary.get("covered_entries", 0)
        return current - baseline

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "coverage_delta": round(self.coverage_delta, 2),
            "entries_delta": self.entries_delta,
            "new_covered_count": len(self.new_covered),
            "no_longer_covered_count": len(self.no_longer_covered),
            "baseline": self.baseline_summary,
            "current": self.current_summary,
        }


class CoverageExporter(ABC):
    """Base class for coverage exporters."""

    @abstractmethod
    def export(self, collector: CoverageCollector, output: str | Path | TextIO) -> None:
        """Export coverage data."""
        ...  # pragma: no cover


class JSONCoverageExporter(CoverageExporter):
    """Exports coverage data as JSON."""

    def __init__(self, include_entries: bool = True, include_branches: bool = True,
                 include_functions: bool = True, pretty: bool = True):
        self._include_entries = include_entries
        self._include_branches = include_branches
        self._include_functions = include_functions
        self._pretty = pretty

    def export(self, collector: CoverageCollector, output: str | Path | TextIO) -> None:
        """Export coverage data as JSON."""
        data = {
            "summary": collector.get_coverage_summary(),
            "timestamp": time.time(),
        }

        if self._include_entries:
            data["entries"] = [e.to_dict() for e in collector.entries()]

        if self._include_branches:
            data["branches"] = [b.to_dict() for b in collector.branches()]

        if self._include_functions:
            data["functions"] = [f.to_dict() for f in collector.functions()]

        indent = 2 if self._pretty else None

        if isinstance(output, (str, Path)):
            with open(output, "w") as f:
                json.dump(data, f, indent=indent)
        else:
            json.dump(data, output, indent=indent)

    def export_string(self, collector: CoverageCollector) -> str:
        """Export coverage data as JSON string."""
        import io
        buf = io.StringIO()
        self.export(collector, buf)
        return buf.getvalue()


class HTMLCoverageExporter(CoverageExporter):
    """Exports coverage data as HTML report."""

    # CSS for the report
    CSS_TEMPLATE = """
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 0; padding: 20px; background: #f5f5f5; }
    .container { max-width: 1200px; margin: 0 auto; }
    h1 { color: #333; }
    .summary { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .summary-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; }
    .stat { padding: 15px; background: #f8f9fa; border-radius: 6px; text-align: center; }
    .stat-value { font-size: 2em; font-weight: bold; color: #007bff; }
    .stat-label { color: #666; font-size: 0.9em; }
    .coverage-bar { height: 8px; background: #e9ecef; border-radius: 4px; overflow: hidden; }
    .coverage-fill { height: 100%; transition: width 0.3s; }
    .coverage-high { background: #28a745; }
    .coverage-medium { background: #ffc107; }
    .coverage-low { background: #dc3545; }
    table { width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e9ecef; }
    th { background: #f8f9fa; font-weight: 600; }
    tr:hover { background: #f8f9fa; }
    .executed { color: #28a745; }
    .not-executed { color: #dc3545; }
    .address { font-family: monospace; }
    """

    def __init__(self, title: str = "Coverage Report", include_details: bool = True):
        self._title = title
        self._include_details = include_details

    def _get_coverage_class(self, percent: float) -> str:
        """Get CSS class for coverage percentage."""
        if percent >= 80:
            return "coverage-high"
        elif percent >= 50:
            return "coverage-medium"
        return "coverage-low"

    def _generate_summary_html(self, summary: dict[str, Any]) -> str:
        """Generate summary section HTML."""
        coverage = summary.get("coverage_percent", 0)
        coverage_class = self._get_coverage_class(coverage)

        return f"""
        <div class="summary">
            <h2>Coverage Summary</h2>
            <div class="summary-grid">
                <div class="stat">
                    <div class="stat-value">{summary.get('covered_entries', 0)}/{summary.get('total_entries', 0)}</div>
                    <div class="stat-label">Entries Covered</div>
                </div>
                <div class="stat">
                    <div class="stat-value">{coverage:.1f}%</div>
                    <div class="stat-label">Code Coverage</div>
                    <div class="coverage-bar"><div class="coverage-fill {coverage_class}" style="width: {coverage}%"></div></div>
                </div>
                <div class="stat">
                    <div class="stat-value">{summary.get('fully_covered_branches', 0)}/{summary.get('total_branches', 0)}</div>
                    <div class="stat-label">Branches Covered</div>
                </div>
                <div class="stat">
                    <div class="stat-value">{summary.get('total_instructions_executed', 0):,}</div>
                    <div class="stat-label">Instructions Executed</div>
                </div>
            </div>
        </div>
        """

    def _generate_functions_html(self, collector: CoverageCollector) -> str:
        """Generate functions table HTML."""
        rows = []
        for func in sorted(collector.functions(), key=lambda f: f.name):
            coverage = func.block_coverage_percent
            coverage_class = self._get_coverage_class(coverage)
            rows.append(f"""
            <tr>
                <td>{html.escape(func.name)}</td>
                <td class="address">{hex(func.start_address)}</td>
                <td>{func.entry_count}</td>
                <td>{func.covered_blocks}/{func.total_blocks}</td>
                <td>
                    <div class="coverage-bar"><div class="coverage-fill {coverage_class}" style="width: {coverage}%"></div></div>
                    {coverage:.1f}%
                </td>
            </tr>
            """)

        return f"""
        <h2>Function Coverage</h2>
        <table>
            <thead>
                <tr>
                    <th>Function</th>
                    <th>Address</th>
                    <th>Calls</th>
                    <th>Blocks</th>
                    <th>Coverage</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows) if rows else '<tr><td colspan="5">No functions tracked</td></tr>'}
            </tbody>
        </table>
        """

    def _generate_entries_html(self, collector: CoverageCollector, max_entries: int = 1000) -> str:
        """Generate entries table HTML."""
        rows = []
        for i, entry in enumerate(sorted(collector.entries(), key=lambda e: e.address)):
            if i >= max_entries:
                rows.append(f'<tr><td colspan="5">... and {collector.total_entries - max_entries} more entries</td></tr>')
                break

            executed_class = "executed" if entry.was_executed() else "not-executed"
            status = "✓" if entry.was_executed() else "✗"

            rows.append(f"""
            <tr>
                <td class="address">{hex(entry.address)}</td>
                <td>{entry.size}</td>
                <td>{entry.hit_count}</td>
                <td>{entry.function_name or '-'}</td>
                <td class="{executed_class}">{status}</td>
            </tr>
            """)

        return f"""
        <h2>Entry Details</h2>
        <table>
            <thead>
                <tr>
                    <th>Address</th>
                    <th>Size</th>
                    <th>Hits</th>
                    <th>Function</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows) if rows else '<tr><td colspan="5">No entries tracked</td></tr>'}
            </tbody>
        </table>
        """

    def export(self, collector: CoverageCollector, output: str | Path | TextIO) -> None:
        """Export coverage data as HTML."""
        summary = collector.get_coverage_summary()

        content = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{html.escape(self._title)}</title>
    <style>{self.CSS_TEMPLATE}</style>
</head>
<body>
    <div class="container">
        <h1>{html.escape(self._title)}</h1>
        {self._generate_summary_html(summary)}
        {self._generate_functions_html(collector)}
        {self._generate_entries_html(collector) if self._include_details else ''}
    </div>
</body>
</html>
"""

        if isinstance(output, (str, Path)):
            with open(output, "w") as f:
                f.write(content)
        else:
            output.write(content)

    def export_string(self, collector: CoverageCollector) -> str:
        """Export coverage data as HTML string."""
        import io
        buf = io.StringIO()
        self.export(collector, buf)
        return buf.getvalue()


class LCOVExporter(CoverageExporter):
    """Exports coverage data in LCOV format for integration with other tools."""

    def export(self, collector: CoverageCollector, output: str | Path | TextIO) -> None:
        """Export coverage data in LCOV format."""
        lines = []

        # Group entries by source file
        by_file: dict[str, list[CoverageEntry]] = defaultdict(list)
        for entry in collector.entries():
            source = entry.source_file or "unknown"
            by_file[source].append(entry)

        for source_file, entries in by_file.items():
            lines.append(f"SF:{source_file}")

            # Function coverage
            for func in collector.functions():
                if any(func.start_address <= e.address < func.end_address for e in entries):
                    lines.append(f"FN:{func.start_address},{func.name}")
                    lines.append(f"FNDA:{func.entry_count},{func.name}")

            # Line coverage
            for entry in sorted(entries, key=lambda e: e.address):
                if entry.source_line is not None:
                    lines.append(f"DA:{entry.source_line},{entry.hit_count}")

            # Branch coverage
            branch_num = 0
            for branch in collector.branches():
                # Check if branch belongs to this file
                for entry in entries:
                    if branch.source_address == entry.address:
                        lines.append(f"BRDA:{entry.source_line or 0},{branch_num},0,{branch.taken_count}")
                        lines.append(f"BRDA:{entry.source_line or 0},{branch_num},1,{branch.not_taken_count}")
                        branch_num += 1
                        break

            # Summary
            total = len(entries)
            covered = sum(1 for e in entries if e.was_executed())
            lines.append(f"LF:{total}")
            lines.append(f"LH:{covered}")
            lines.append("end_of_record")

        content = "\n".join(lines)

        if isinstance(output, (str, Path)):
            with open(output, "w") as f:
                f.write(content)
        else:
            output.write(content)


class CoverageManager:
    """Main manager for code coverage tracking and visualization."""

    def __init__(self, coverage_type: CoverageType = CoverageType.BASIC_BLOCK):
        self._collector = CoverageCollector(coverage_type)
        self._history: list[dict[str, Any]] = []
        self._exporters: dict[str, CoverageExporter] = {
            "json": JSONCoverageExporter(),
            "html": HTMLCoverageExporter(),
            "lcov": LCOVExporter(),
        }

    @property
    def collector(self) -> CoverageCollector:
        """Get the coverage collector."""
        return self._collector

    @property
    def is_collecting(self) -> bool:
        """Check if coverage collection is active."""
        return self._collector.is_enabled

    def start(self) -> None:
        """Start coverage collection."""
        self._collector.enable()
        logger.info("Coverage collection started")

    def stop(self) -> None:
        """Stop coverage collection."""
        self._collector.disable()
        # Save snapshot to history
        self._history.append(self._collector.get_coverage_summary())
        logger.info("Coverage collection stopped")

    def reset(self) -> None:
        """Reset coverage data."""
        self._collector.reset()
        logger.info("Coverage data reset")

    def add_module(self, name: str, base: int, size: int | None = None) -> None:
        """Add a module for coverage tracking."""
        self._collector.add_module(name, base)

    def add_function(self, name: str, start: int, end: int) -> FunctionCoverage:
        """Add a function for coverage tracking."""
        return self._collector.add_function(name, start, end)

    def add_basic_block(self, address: int, size: int,
                        flags: CoverageFlags = CoverageFlags.NONE) -> CoverageEntry:
        """Add a basic block for coverage tracking."""
        return self._collector.add_entry(address, size, flags)

    def add_branch(self, source: int, target_taken: int, target_not_taken: int) -> BranchInfo:
        """Add a branch for coverage tracking."""
        return self._collector.add_branch(source, target_taken, target_not_taken)

    def record_execution(self, address: int, size: int = 1) -> None:
        """Record execution at an address."""
        self._collector.record_execution(address, size)

    def record_branch(self, source: int, target: int) -> None:
        """Record a branch being taken."""
        self._collector.record_branch_taken(source, target)

    def record_function_entry(self, address: int) -> None:
        """Record function entry."""
        self._collector.record_function_entry(address)

    def get_summary(self) -> dict[str, Any]:
        """Get coverage summary."""
        return self._collector.get_coverage_summary()

    def get_history(self) -> list[dict[str, Any]]:
        """Get coverage history snapshots."""
        return list(self._history)

    def diff_with_baseline(self, baseline: CoverageCollector | dict[str, Any]) -> CoverageDiff:
        """Compare current coverage with a baseline."""
        if isinstance(baseline, CoverageCollector):
            baseline_summary = baseline.get_coverage_summary()
            baseline_addresses = {e.address for e in baseline.entries() if e.was_executed()}
        else:
            baseline_summary = baseline
            baseline_addresses = set()  # Can't determine addresses from summary alone

        current_summary = self._collector.get_coverage_summary()
        current_addresses = {e.address for e in self._collector.entries() if e.was_executed()}

        new_covered = list(current_addresses - baseline_addresses)
        no_longer_covered = list(baseline_addresses - current_addresses)

        return CoverageDiff(
            baseline_summary=baseline_summary,
            current_summary=current_summary,
            new_covered=new_covered,
            no_longer_covered=no_longer_covered,
        )

    def register_exporter(self, name: str, exporter: CoverageExporter) -> None:
        """Register a custom exporter."""
        self._exporters[name] = exporter

    def export(self, format: str, output: str | Path | TextIO) -> None:
        """Export coverage data in specified format."""
        if format not in self._exporters:
            raise ValueError(f"Unknown format: {format}. Available: {list(self._exporters.keys())}")
        self._exporters[format].export(self._collector, output)

    def export_json(self, output: str | Path | TextIO) -> None:
        """Export coverage data as JSON."""
        self.export("json", output)

    def export_html(self, output: str | Path | TextIO, title: str = "Coverage Report") -> None:
        """Export coverage data as HTML."""
        exporter = HTMLCoverageExporter(title=title)
        exporter.export(self._collector, output)

    def export_lcov(self, output: str | Path | TextIO) -> None:
        """Export coverage data in LCOV format."""
        self.export("lcov", output)


class EmulatorCoverageIntegration:
    """Integration with emulator for automatic coverage collection."""

    def __init__(self, manager: CoverageManager):
        self._manager = manager
        self._hook_handles: list[Any] = []

    def install_hooks(self, emulator: Any) -> None:
        """Install coverage hooks into emulator.
        
        Expects emulator to have add_code_hook() and add_block_hook() methods.
        """
        # Try to add block hook first (more efficient)
        if hasattr(emulator, 'add_block_hook'):
            handle = emulator.add_block_hook(self._on_block)
            self._hook_handles.append(handle)
            logger.debug("Installed block coverage hook")

        # Fall back to code hook if no block hook
        elif hasattr(emulator, 'add_code_hook'):
            handle = emulator.add_code_hook(self._on_code)
            self._hook_handles.append(handle)
            logger.debug("Installed code coverage hook")

    def remove_hooks(self, emulator: Any) -> None:
        """Remove coverage hooks from emulator."""
        for handle in self._hook_handles:
            if hasattr(emulator, 'remove_hook'):
                emulator.remove_hook(handle)
        self._hook_handles.clear()

    def _on_block(self, address: int, size: int) -> None:
        """Block hook callback."""
        self._manager.record_execution(address, size)

    def _on_code(self, address: int, size: int) -> None:
        """Code hook callback."""
        self._manager.record_execution(address, size)


def create_coverage_manager(coverage_type: CoverageType = CoverageType.BASIC_BLOCK) -> tuple[CoverageManager, EmulatorCoverageIntegration | None]:
    """Factory function to create a coverage manager with optional integration.
    
    Returns:
        Tuple of (CoverageManager, EmulatorCoverageIntegration)
    """
    manager = CoverageManager(coverage_type)
    integration = EmulatorCoverageIntegration(manager)
    return manager, integration


def merge_coverage(*collectors: CoverageCollector) -> CoverageCollector:
    """Merge multiple coverage collectors into one."""
    if not collectors:
        return CoverageCollector()

    merged = CoverageCollector(collectors[0].coverage_type)

    for collector in collectors:
        # Merge entries
        for entry in collector.entries():
            if entry.address in merged._entries:
                merged._entries[entry.address].hit_count += entry.hit_count
            else:
                merged._entries[entry.address] = CoverageEntry(
                    address=entry.address,
                    size=entry.size,
                    hit_count=entry.hit_count,
                    flags=entry.flags,
                    source_file=entry.source_file,
                    source_line=entry.source_line,
                    function_name=entry.function_name,
                )

        # Merge branches
        for branch in collector.branches():
            if branch.source_address in merged._branches:
                merged._branches[branch.source_address].taken_count += branch.taken_count
                merged._branches[branch.source_address].not_taken_count += branch.not_taken_count
            else:
                merged._branches[branch.source_address] = BranchInfo(
                    source_address=branch.source_address,
                    target_taken=branch.target_taken,
                    target_not_taken=branch.target_not_taken,
                    taken_count=branch.taken_count,
                    not_taken_count=branch.not_taken_count,
                )

        # Merge functions
        for func in collector.functions():
            if func.name in merged._functions:
                merged._functions[func.name].entry_count += func.entry_count
            else:
                merged._functions[func.name] = FunctionCoverage(
                    name=func.name,
                    start_address=func.start_address,
                    end_address=func.end_address,
                    entry_count=func.entry_count,
                )

        # Merge modules
        merged._module_bases.update(collector._module_bases)
        merged._total_instructions += collector._total_instructions

    return merged
