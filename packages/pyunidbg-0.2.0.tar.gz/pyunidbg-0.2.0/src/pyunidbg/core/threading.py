"""
Thread Emulation - Multi-threaded execution support.

Provides:
- Thread creation and management
- pthread primitives (mutex, cond, rwlock)
- Thread-local storage (TLS)
- Cooperative scheduling
"""

import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from threading import Lock
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


class ThreadState(Enum):
    """Thread execution state."""
    CREATED = auto()      # Created but not started
    RUNNING = auto()      # Currently executing
    READY = auto()        # Ready to run
    BLOCKED = auto()      # Waiting on mutex/cond
    SLEEPING = auto()     # In sleep/nanosleep
    WAITING = auto()      # Waiting for another thread
    TERMINATED = auto()   # Finished execution
    DETACHED = auto()     # Detached, resources freed


@dataclass
class ThreadContext:
    """CPU context for a thread."""
    # General purpose registers
    regs: dict[str, int] = field(default_factory=dict)

    # Program counter and stack pointer
    pc: int = 0
    sp: int = 0

    # For ARM64
    x: list[int] = field(default_factory=lambda: [0] * 31)

    # NEON/FP registers (simplified)
    fp_regs: list[int] = field(default_factory=lambda: [0] * 32)


@dataclass
class Thread:
    """Represents an emulated thread."""
    tid: int
    name: str = ""

    # State
    state: ThreadState = ThreadState.CREATED

    # CPU context
    context: ThreadContext = field(default_factory=ThreadContext)

    # Stack
    stack_base: int = 0
    stack_size: int = 0x100000  # 1MB default

    # Entry point
    entry_func: int = 0
    entry_arg: int = 0

    # Return value
    return_value: int = 0

    # Thread-local storage
    tls_base: int = 0
    tls_data: dict[int, int] = field(default_factory=dict)

    # Scheduling
    priority: int = 0
    cpu_time: int = 0

    # Waiting info
    blocked_on: int | None = None  # Mutex/cond address
    join_target: int | None = None  # Thread waiting to join

    # Detach state
    detached: bool = False

    def __repr__(self) -> str:
        return f"Thread(tid={self.tid}, state={self.state.name}, name={self.name!r})"


@dataclass
class Mutex:
    """pthread_mutex_t emulation."""
    address: int
    owner: int | None = None  # TID of owner
    lock_count: int = 0

    # Mutex type
    recursive: bool = False

    # Waiting threads
    waiters: list[int] = field(default_factory=list)

    def is_locked(self) -> bool:
        return self.owner is not None


@dataclass
class CondVar:
    """pthread_cond_t emulation."""
    address: int

    # Waiting threads
    waiters: list[int] = field(default_factory=list)


@dataclass
class RWLock:
    """pthread_rwlock_t emulation."""
    address: int

    # State
    readers: list[int] = field(default_factory=list)  # TIDs
    writer: int | None = None

    # Waiting
    read_waiters: list[int] = field(default_factory=list)
    write_waiters: list[int] = field(default_factory=list)


@dataclass
class Barrier:
    """pthread_barrier_t emulation."""
    address: int
    count: int
    waiting: list[int] = field(default_factory=list)


@dataclass
class Semaphore:
    """POSIX sem_t emulation."""
    address: int
    value: int = 0
    max_value: int = 0x7FFFFFFF  # SEM_VALUE_MAX

    # Waiting threads
    waiters: list[int] = field(default_factory=list)

    def is_available(self) -> bool:
        """Check if semaphore can be acquired."""
        return self.value > 0


class TLSManager:
    """
    Thread-Local Storage manager.
    
    Handles pthread_key_create, pthread_setspecific, pthread_getspecific.
    """

    def __init__(self):
        self._next_key = 1
        self._keys: dict[int, Callable | None] = {}  # key -> destructor
        self._max_keys = 1024

    def create_key(self, destructor: int = 0) -> int:
        """Create new TLS key."""
        if len(self._keys) >= self._max_keys:
            return -1  # EAGAIN

        key = self._next_key
        self._next_key += 1
        self._keys[key] = destructor if destructor else None
        return key

    def delete_key(self, key: int) -> bool:
        """Delete TLS key."""
        if key in self._keys:
            del self._keys[key]
            return True
        return False

    def is_valid_key(self, key: int) -> bool:
        return key in self._keys

    def get_destructor(self, key: int) -> int | None:
        return self._keys.get(key)


class ThreadManager:
    """
    Thread emulation manager.
    
    Provides pthread-compatible threading for the emulator.
    Uses cooperative scheduling (one thread runs at a time).
    
    Example:
        threads = ThreadManager(emulator)
        
        # Create thread
        tid = threads.create_thread(entry_func, arg)
        
        # Run threads
        threads.run_all()
        
        # Join thread
        result = threads.join(tid)
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.is_64bit = emulator.arch in ('arm64', 'aarch64')

        # Thread storage
        self._threads: dict[int, Thread] = {}
        self._next_tid = 1

        # Main thread
        self._main_thread: Thread | None = None
        self._current_thread: Thread | None = None

        # Synchronization primitives
        self._mutexes: dict[int, Mutex] = {}
        self._condvars: dict[int, CondVar] = {}
        self._rwlocks: dict[int, RWLock] = {}
        self._barriers: dict[int, Barrier] = {}
        self._semaphores: dict[int, Semaphore] = {}

        # TLS
        self._tls = TLSManager()

        # Stack allocation
        self._stack_base = 0x70000000
        self._stack_offset = 0

        # Scheduling
        self._time_slice = 10000  # Instructions per slice
        self._total_switches = 0

        # Lock for thread-safe operations
        self._lock = Lock()

        # Create main thread
        self._init_main_thread()

    def _init_main_thread(self) -> None:
        """Initialize main thread."""
        main = Thread(
            tid=0,
            name="main",
            state=ThreadState.RUNNING,
        )

        # Use current SP as main thread's stack
        if self.is_64bit:
            main.context.sp = self.emulator._uc.reg_read(
                self.emulator.regs['sp']
            )

        self._threads[0] = main
        self._main_thread = main
        self._current_thread = main

    # ==================== Thread Creation ====================

    def create_thread(self, entry: int, arg: int = 0,
                      stack_size: int = 0x100000,
                      name: str = "") -> int:
        """
        Create a new thread.
        
        Args:
            entry: Entry function address
            arg: Argument to pass
            stack_size: Stack size in bytes
            name: Thread name (optional)
            
        Returns:
            Thread ID
        """
        tid = self._next_tid
        self._next_tid += 1

        # Allocate stack
        stack_base = self._allocate_stack(stack_size)
        stack_top = stack_base + stack_size - 16  # Leave some space

        # Allocate TLS
        tls_base = self._allocate_tls()

        thread = Thread(
            tid=tid,
            name=name or f"thread-{tid}",
            state=ThreadState.CREATED,
            stack_base=stack_base,
            stack_size=stack_size,
            entry_func=entry,
            entry_arg=arg,
            tls_base=tls_base,
        )

        # Initialize context
        thread.context.pc = entry
        thread.context.sp = stack_top

        if self.is_64bit:
            thread.context.x[0] = arg  # First argument
            thread.context.x[29] = stack_top  # Frame pointer
            thread.context.x[30] = 0xDEAD0000  # Return address (exit)

        self._threads[tid] = thread
        logger.debug(f"Created thread {tid}: entry=0x{entry:x}, arg=0x{arg:x}")

        return tid

    def _allocate_stack(self, size: int) -> int:
        """Allocate stack memory for thread."""
        # Align size
        size = (size + 0xfff) & ~0xfff

        addr = self._stack_base + self._stack_offset
        self._stack_offset += size + 0x1000  # Guard page

        # Map stack memory
        try:
            self.emulator._uc.mem_map(addr, size)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        return addr

    def _allocate_tls(self) -> int:
        """Allocate TLS block for thread."""
        tls_size = 0x1000
        return self.emulator.memory.alloc(tls_size, aligned=0x1000)

    # ==================== Thread Control ====================

    def start_thread(self, tid: int) -> bool:
        """Start a created thread."""
        thread = self._threads.get(tid)
        if not thread or thread.state != ThreadState.CREATED:
            return False

        thread.state = ThreadState.READY
        return True

    def get_current(self) -> Thread | None:
        """Get current running thread."""
        return self._current_thread

    def get_thread(self, tid: int) -> Thread | None:
        """Get thread by ID."""
        return self._threads.get(tid)

    def get_current_tid(self) -> int:
        """Get current thread ID."""
        return self._current_thread.tid if self._current_thread else 0

    def list_threads(self) -> list[Thread]:
        """List all threads."""
        return list(self._threads.values())

    # ==================== Context Switching ====================

    def _save_context(self, thread: Thread) -> None:
        """Save current CPU state to thread context."""
        uc = self.emulator._uc

        if self.is_64bit:
            for i in range(31):
                thread.context.x[i] = uc.reg_read(self.emulator.regs[f'x{i}'])
            thread.context.pc = uc.reg_read(self.emulator.pc_reg)
            thread.context.sp = uc.reg_read(self.emulator.regs['sp'])
        else:
            for i in range(16):
                thread.context.regs[f'r{i}'] = uc.reg_read(
                    self.emulator.regs[f'r{i}']
                )
            thread.context.pc = uc.reg_read(self.emulator.pc_reg)
            thread.context.sp = uc.reg_read(self.emulator.regs['sp'])

    def _restore_context(self, thread: Thread) -> None:
        """Restore thread context to CPU."""
        uc = self.emulator._uc

        if self.is_64bit:
            for i in range(31):
                uc.reg_write(self.emulator.regs[f'x{i}'], thread.context.x[i])
            uc.reg_write(self.emulator.pc_reg, thread.context.pc)
            uc.reg_write(self.emulator.regs['sp'], thread.context.sp)
        else:
            for i in range(16):
                uc.reg_write(self.emulator.regs[f'r{i}'],
                            thread.context.regs.get(f'r{i}', 0))
            uc.reg_write(self.emulator.pc_reg, thread.context.pc)
            uc.reg_write(self.emulator.regs['sp'], thread.context.sp)

    def switch_to(self, tid: int) -> bool:
        """Switch to a specific thread."""
        thread = self._threads.get(tid)
        if not thread or thread.state not in (ThreadState.READY, ThreadState.RUNNING):
            return False

        # Save current
        if self._current_thread and self._current_thread.state == ThreadState.RUNNING:
            self._save_context(self._current_thread)
            self._current_thread.state = ThreadState.READY

        # Restore new
        self._restore_context(thread)
        thread.state = ThreadState.RUNNING
        self._current_thread = thread
        self._total_switches += 1

        return True

    def _pick_next_thread(self) -> Thread | None:
        """Pick next thread to run (round-robin)."""
        current_tid = self._current_thread.tid if self._current_thread else -1

        # Get list of ready threads
        ready = [t for t in self._threads.values()
                if t.state == ThreadState.READY and t.tid != current_tid]

        if not ready:
            # Check if current can continue
            if self._current_thread and self._current_thread.state == ThreadState.RUNNING:
                return self._current_thread
            return None

        # Simple round-robin
        return ready[0]

    # ==================== Execution ====================

    def run_current(self, count: int = 0) -> None:
        """Run current thread for specified instructions."""
        if not self._current_thread:
            return

        thread = self._current_thread
        if thread.state != ThreadState.RUNNING:
            return

        try:
            self.emulator._uc.emu_start(
                thread.context.pc,
                0xDEAD0000,  # End address (thread exit)
                timeout=0,
                count=count or self._time_slice
            )

            # Update PC
            thread.context.pc = self.emulator._uc.reg_read(self.emulator.pc_reg)

        except Exception as e:
            logger.error(f"Thread {thread.tid} execution error: {e}")
            thread.state = ThreadState.TERMINATED

    def run_all(self, max_instructions: int = 0) -> None:
        """
        Run all threads until completion.
        
        Uses cooperative scheduling with time slices.
        """
        total = 0

        while True:
            # Get runnable threads
            runnable = [t for t in self._threads.values()
                       if t.state in (ThreadState.READY, ThreadState.RUNNING)]

            if not runnable:
                break

            # Run each thread for a time slice
            for thread in runnable:
                if thread.state == ThreadState.TERMINATED:
                    continue

                self.switch_to(thread.tid)
                self.run_current(self._time_slice)

                total += self._time_slice

                if max_instructions and total >= max_instructions:
                    return

            # Check for deadlock (all threads blocked)
            active = [t for t in self._threads.values()
                     if t.state not in (ThreadState.TERMINATED,
                                        ThreadState.BLOCKED,
                                        ThreadState.WAITING)]
            if not active:
                logger.warning("Possible deadlock: all threads blocked")
                break

    def run_thread(self, tid: int) -> int:
        """Run single thread to completion."""
        thread = self._threads.get(tid)
        if not thread:
            return -1

        self.switch_to(tid)

        while thread.state == ThreadState.RUNNING:
            self.run_current(self._time_slice)

            # Check if thread exited
            pc = self.emulator._uc.reg_read(self.emulator.pc_reg)
            if pc == 0xDEAD0000:
                thread.state = ThreadState.TERMINATED
                thread.return_value = self.emulator.get_register(
                    'x0' if self.is_64bit else 'r0'
                )
                break

        return thread.return_value

    # ==================== Thread Termination ====================

    def exit_thread(self, retval: int = 0) -> None:
        """Exit current thread."""
        if not self._current_thread:
            return

        thread = self._current_thread
        thread.return_value = retval
        thread.state = ThreadState.TERMINATED

        # Call TLS destructors
        self._call_tls_destructors(thread)

        # Wake threads waiting to join
        for t in self._threads.values():
            if t.join_target == thread.tid:
                t.state = ThreadState.READY
                t.join_target = None

        # Switch to another thread
        next_thread = self._pick_next_thread()
        if next_thread:
            self.switch_to(next_thread.tid)

    def join(self, tid: int, timeout: float = 0) -> tuple[bool, int]:
        """
        Wait for thread to terminate.
        
        Returns:
            (success, return_value)
        """
        thread = self._threads.get(tid)
        if not thread:
            return (False, 0)

        if thread.detached:
            return (False, 0)

        # Already terminated?
        if thread.state == ThreadState.TERMINATED:
            return (True, thread.return_value)

        # Mark current as waiting
        if self._current_thread:
            self._current_thread.state = ThreadState.WAITING
            self._current_thread.join_target = tid

        # Run until target terminates
        start = time.time()
        while thread.state != ThreadState.TERMINATED:
            if timeout and (time.time() - start) > timeout:
                if self._current_thread:
                    self._current_thread.state = ThreadState.READY
                return (False, 0)

            self.run_all(self._time_slice * 10)

        if self._current_thread:
            self._current_thread.state = ThreadState.READY

        return (True, thread.return_value)

    def detach(self, tid: int) -> bool:
        """Detach thread (resources freed on exit)."""
        thread = self._threads.get(tid)
        if not thread:
            return False

        thread.detached = True

        # If already terminated, free resources
        if thread.state == ThreadState.TERMINATED:
            self._free_thread(thread)

        return True

    def _free_thread(self, thread: Thread) -> None:
        """Free thread resources."""
        # Free stack
        try:
            self.emulator.memory.free(thread.stack_base)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        # Free TLS
        try:
            self.emulator.memory.free(thread.tls_base)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

    def _call_tls_destructors(self, thread: Thread) -> None:
        """Call TLS destructors for thread."""
        for key, value in thread.tls_data.items():
            if value:
                destructor = self._tls.get_destructor(key)
                if destructor:
                    # Call destructor(value)
                    self.emulator.set_register('x0' if self.is_64bit else 'r0', value)
                    try:
                        self.emulator._uc.emu_start(destructor, 0xDEAD0000, count=10000)
                    except Exception:
                        logger.debug("Exception suppressed", exc_info=True)

    # ==================== Mutex ====================

    def mutex_init(self, addr: int, recursive: bool = False) -> None:
        """Initialize mutex at address."""
        self._mutexes[addr] = Mutex(address=addr, recursive=recursive)

    def mutex_lock(self, addr: int) -> int:
        """Lock mutex. Returns 0 on success."""
        mutex = self._mutexes.get(addr)
        if not mutex:
            mutex = Mutex(address=addr)
            self._mutexes[addr] = mutex

        tid = self.get_current_tid()

        if mutex.owner is None:
            # Unowned, acquire
            mutex.owner = tid
            mutex.lock_count = 1
            return 0

        if mutex.owner == tid:
            # We own it
            if mutex.recursive:
                mutex.lock_count += 1
                return 0
            else:
                # Deadlock
                return -1  # EDEADLK

        # Block
        if self._current_thread:
            self._current_thread.state = ThreadState.BLOCKED
            self._current_thread.blocked_on = addr
            mutex.waiters.append(tid)

        return 0

    def mutex_trylock(self, addr: int) -> int:
        """Try to lock mutex. Returns 0 on success, EBUSY if locked."""
        mutex = self._mutexes.get(addr)
        if not mutex:
            mutex = Mutex(address=addr)
            self._mutexes[addr] = mutex

        tid = self.get_current_tid()

        if mutex.owner is None:
            mutex.owner = tid
            mutex.lock_count = 1
            return 0

        if mutex.owner == tid and mutex.recursive:
            mutex.lock_count += 1
            return 0

        return 16  # EBUSY

    def mutex_unlock(self, addr: int) -> int:
        """Unlock mutex."""
        mutex = self._mutexes.get(addr)
        if not mutex:
            return 22  # EINVAL

        tid = self.get_current_tid()

        if mutex.owner != tid:
            return 1  # EPERM

        mutex.lock_count -= 1

        if mutex.lock_count == 0:
            mutex.owner = None

            # Wake first waiter
            if mutex.waiters:
                waiter_tid = mutex.waiters.pop(0)
                waiter = self._threads.get(waiter_tid)
                if waiter:
                    waiter.state = ThreadState.READY
                    waiter.blocked_on = None
                    mutex.owner = waiter_tid
                    mutex.lock_count = 1

        return 0

    def mutex_destroy(self, addr: int) -> int:
        """Destroy mutex."""
        if addr in self._mutexes:
            mutex = self._mutexes[addr]
            if mutex.owner is not None:
                return 16  # EBUSY
            del self._mutexes[addr]
        return 0

    # ==================== Condition Variable ====================

    def cond_init(self, addr: int) -> None:
        """Initialize condition variable."""
        self._condvars[addr] = CondVar(address=addr)

    def cond_wait(self, cond_addr: int, mutex_addr: int) -> int:
        """Wait on condition variable."""
        cond = self._condvars.get(cond_addr)
        if not cond:
            cond = CondVar(address=cond_addr)
            self._condvars[cond_addr] = cond

        tid = self.get_current_tid()

        # Release mutex
        self.mutex_unlock(mutex_addr)

        # Block on condition
        if self._current_thread:
            self._current_thread.state = ThreadState.BLOCKED
            self._current_thread.blocked_on = cond_addr
            cond.waiters.append(tid)

        # When woken, reacquire mutex
        # (This is handled when cond_signal wakes us)

        return 0

    def cond_signal(self, addr: int) -> int:
        """Signal one waiter."""
        cond = self._condvars.get(addr)
        if not cond:
            return 0

        if cond.waiters:
            waiter_tid = cond.waiters.pop(0)
            waiter = self._threads.get(waiter_tid)
            if waiter:
                waiter.state = ThreadState.READY
                waiter.blocked_on = None

        return 0

    def cond_broadcast(self, addr: int) -> int:
        """Wake all waiters."""
        cond = self._condvars.get(addr)
        if not cond:
            return 0

        for waiter_tid in cond.waiters:
            waiter = self._threads.get(waiter_tid)
            if waiter:
                waiter.state = ThreadState.READY
                waiter.blocked_on = None

        cond.waiters.clear()
        return 0

    def cond_destroy(self, addr: int) -> int:
        """Destroy condition variable."""
        if addr in self._condvars:
            del self._condvars[addr]
        return 0

    # ==================== TLS ====================

    def tls_key_create(self, destructor: int = 0) -> int:
        """Create TLS key."""
        return self._tls.create_key(destructor)

    def tls_key_delete(self, key: int) -> int:
        """Delete TLS key."""
        return 0 if self._tls.delete_key(key) else 22  # EINVAL

    def tls_set(self, key: int, value: int) -> int:
        """Set TLS value for current thread."""
        if not self._tls.is_valid_key(key):
            return 22  # EINVAL

        if self._current_thread:
            self._current_thread.tls_data[key] = value
        return 0

    def tls_get(self, key: int) -> int:
        """Get TLS value for current thread."""
        if not self._current_thread:
            return 0
        return self._current_thread.tls_data.get(key, 0)

    # ==================== Semaphore ====================

    def sem_init(self, addr: int, value: int = 0, pshared: int = 0) -> int:
        """
        Initialize semaphore at address.
        
        Args:
            addr: Semaphore address
            value: Initial value (must be >= 0)
            pshared: Process-shared flag (ignored in emulation)
            
        Returns:
            0 on success, error code otherwise
        """
        if value < 0:
            return 22  # EINVAL

        self._semaphores[addr] = Semaphore(address=addr, value=value)
        return 0

    def sem_wait(self, addr: int) -> int:
        """
        Decrement (lock) semaphore. Blocks if value is 0.
        
        Returns:
            0 on success
        """
        sem = self._semaphores.get(addr)
        if not sem:
            return 22  # EINVAL

        tid = self.get_current_tid()

        if sem.value > 0:
            sem.value -= 1
            return 0

        # Block waiting for semaphore
        if self._current_thread:
            self._current_thread.state = ThreadState.BLOCKED
            self._current_thread.blocked_on = addr
            sem.waiters.append(tid)

        return 0

    def sem_trywait(self, addr: int) -> int:
        """
        Try to decrement semaphore without blocking.
        
        Returns:
            0 on success, EAGAIN if would block
        """
        sem = self._semaphores.get(addr)
        if not sem:
            return 22  # EINVAL

        if sem.value > 0:
            sem.value -= 1
            return 0

        return 11  # EAGAIN

    def sem_timedwait(self, addr: int, timeout_ns: int) -> int:
        """
        Wait on semaphore with timeout.
        
        Args:
            addr: Semaphore address
            timeout_ns: Timeout in nanoseconds
            
        Returns:
            0 on success, ETIMEDOUT on timeout
        """
        sem = self._semaphores.get(addr)
        if not sem:
            return 22  # EINVAL

        if sem.value > 0:
            sem.value -= 1
            return 0

        # Simplified: just return timeout for now
        # Full implementation would need scheduler integration
        return 110  # ETIMEDOUT

    def sem_post(self, addr: int) -> int:
        """
        Increment (unlock) semaphore. Wakes one waiting thread.
        
        Returns:
            0 on success
        """
        sem = self._semaphores.get(addr)
        if not sem:
            return 22  # EINVAL

        if sem.value >= sem.max_value:
            return 75  # EOVERFLOW

        sem.value += 1

        # Wake first waiter
        if sem.waiters:
            waiter_tid = sem.waiters.pop(0)
            waiter = self._threads.get(waiter_tid)
            if waiter:
                waiter.state = ThreadState.READY
                waiter.blocked_on = None
                sem.value -= 1  # They acquire it

        return 0

    def sem_getvalue(self, addr: int) -> tuple[int, int]:
        """
        Get semaphore value.
        
        Returns:
            (error_code, value)
        """
        sem = self._semaphores.get(addr)
        if not sem:
            return (22, 0)  # EINVAL
        return (0, sem.value)

    def sem_destroy(self, addr: int) -> int:
        """
        Destroy semaphore.
        
        Returns:
            0 on success, EBUSY if threads waiting
        """
        sem = self._semaphores.get(addr)
        if not sem:
            return 22  # EINVAL

        if sem.waiters:
            return 16  # EBUSY

        del self._semaphores[addr]
        return 0

    # ==================== RWLock ====================

    def rwlock_init(self, addr: int) -> int:
        """Initialize read-write lock."""
        self._rwlocks[addr] = RWLock(address=addr)
        return 0

    def rwlock_rdlock(self, addr: int) -> int:
        """
        Acquire read lock. Blocks if writer holds lock.
        
        Returns:
            0 on success
        """
        rwlock = self._rwlocks.get(addr)
        if not rwlock:
            rwlock = RWLock(address=addr)
            self._rwlocks[addr] = rwlock

        tid = self.get_current_tid()

        if rwlock.writer is None:
            # No writer, can read
            rwlock.readers.append(tid)
            return 0

        # Block waiting for writer to release
        if self._current_thread:
            self._current_thread.state = ThreadState.BLOCKED
            self._current_thread.blocked_on = addr
            rwlock.read_waiters.append(tid)

        return 0

    def rwlock_tryrdlock(self, addr: int) -> int:
        """
        Try to acquire read lock without blocking.
        
        Returns:
            0 on success, EBUSY if would block
        """
        rwlock = self._rwlocks.get(addr)
        if not rwlock:
            rwlock = RWLock(address=addr)
            self._rwlocks[addr] = rwlock

        if rwlock.writer is None:
            rwlock.readers.append(self.get_current_tid())
            return 0

        return 16  # EBUSY

    def rwlock_wrlock(self, addr: int) -> int:
        """
        Acquire write lock. Blocks if any readers or writer.
        
        Returns:
            0 on success
        """
        rwlock = self._rwlocks.get(addr)
        if not rwlock:
            rwlock = RWLock(address=addr)
            self._rwlocks[addr] = rwlock

        tid = self.get_current_tid()

        if rwlock.writer is None and not rwlock.readers:
            # No one holds lock
            rwlock.writer = tid
            return 0

        # Block waiting
        if self._current_thread:
            self._current_thread.state = ThreadState.BLOCKED
            self._current_thread.blocked_on = addr
            rwlock.write_waiters.append(tid)

        return 0

    def rwlock_trywrlock(self, addr: int) -> int:
        """
        Try to acquire write lock without blocking.
        
        Returns:
            0 on success, EBUSY if would block
        """
        rwlock = self._rwlocks.get(addr)
        if not rwlock:
            rwlock = RWLock(address=addr)
            self._rwlocks[addr] = rwlock

        if rwlock.writer is None and not rwlock.readers:
            rwlock.writer = self.get_current_tid()
            return 0

        return 16  # EBUSY

    def rwlock_unlock(self, addr: int) -> int:
        """
        Release read or write lock.
        
        Returns:
            0 on success
        """
        rwlock = self._rwlocks.get(addr)
        if not rwlock:
            return 22  # EINVAL

        tid = self.get_current_tid()

        if rwlock.writer == tid:
            # Release write lock
            rwlock.writer = None

            # Prefer writers (write-preferring lock)
            if rwlock.write_waiters:
                waiter_tid = rwlock.write_waiters.pop(0)
                waiter = self._threads.get(waiter_tid)
                if waiter:
                    waiter.state = ThreadState.READY
                    waiter.blocked_on = None
                    rwlock.writer = waiter_tid
            elif rwlock.read_waiters:
                # Wake all read waiters
                for waiter_tid in rwlock.read_waiters:
                    waiter = self._threads.get(waiter_tid)
                    if waiter:
                        waiter.state = ThreadState.READY
                        waiter.blocked_on = None
                        rwlock.readers.append(waiter_tid)
                rwlock.read_waiters.clear()
        elif tid in rwlock.readers:
            # Release read lock
            rwlock.readers.remove(tid)

            # If no more readers and writers waiting, wake writer
            if not rwlock.readers and rwlock.write_waiters:
                waiter_tid = rwlock.write_waiters.pop(0)
                waiter = self._threads.get(waiter_tid)
                if waiter:
                    waiter.state = ThreadState.READY
                    waiter.blocked_on = None
                    rwlock.writer = waiter_tid
        else:
            return 1  # EPERM - not holding lock

        return 0

    def rwlock_destroy(self, addr: int) -> int:
        """Destroy read-write lock."""
        rwlock = self._rwlocks.get(addr)
        if not rwlock:
            return 22  # EINVAL

        if rwlock.writer is not None or rwlock.readers:
            return 16  # EBUSY

        del self._rwlocks[addr]
        return 0

    # ==================== Barrier ====================

    def barrier_init(self, addr: int, count: int) -> int:
        """
        Initialize barrier for count threads.
        
        Args:
            addr: Barrier address
            count: Number of threads that must wait
            
        Returns:
            0 on success
        """
        if count <= 0:
            return 22  # EINVAL

        self._barriers[addr] = Barrier(address=addr, count=count)
        return 0

    def barrier_wait(self, addr: int) -> int:
        """
        Wait at barrier until all threads arrive.
        
        Returns:
            PTHREAD_BARRIER_SERIAL_THREAD (-1) for one thread,
            0 for others
        """
        barrier = self._barriers.get(addr)
        if not barrier:
            return 22  # EINVAL

        tid = self.get_current_tid()
        barrier.waiting.append(tid)

        if len(barrier.waiting) >= barrier.count:
            # All threads arrived - wake everyone
            for waiter_tid in barrier.waiting:
                waiter = self._threads.get(waiter_tid)
                if waiter:
                    waiter.state = ThreadState.READY
                    waiter.blocked_on = None

            # Reset barrier
            result_tid = barrier.waiting[0]  # First gets serial
            barrier.waiting.clear()

            return -1 if tid == result_tid else 0  # PTHREAD_BARRIER_SERIAL_THREAD

        # Block waiting
        if self._current_thread:
            self._current_thread.state = ThreadState.BLOCKED
            self._current_thread.blocked_on = addr

        return 0

    def barrier_destroy(self, addr: int) -> int:
        """Destroy barrier."""
        barrier = self._barriers.get(addr)
        if not barrier:
            return 22  # EINVAL

        if barrier.waiting:
            return 16  # EBUSY

        del self._barriers[addr]
        return 0

    # ==================== Statistics ====================

    def print_status(self) -> None:
        """Print thread status."""
        print("=== Thread Status ===")
        print(f"Total threads: {len(self._threads)}")
        print(f"Context switches: {self._total_switches}")
        print()

        for thread in self._threads.values():
            print(f"  TID {thread.tid}: {thread.state.name} - {thread.name}")
            if thread.state == ThreadState.BLOCKED:
                print(f"    Blocked on: 0x{thread.blocked_on:x}")
