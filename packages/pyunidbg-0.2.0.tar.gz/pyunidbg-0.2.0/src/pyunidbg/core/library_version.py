"""
Library Version Management - ELF symbol versioning support.

This module implements GNU symbol versioning for shared libraries, including:
- Symbol version definitions (.gnu.version_d)
- Symbol version requirements (.gnu.version_r)
- Version symbol table (.gnu.version)
- SONAME parsing and matching
- Version compatibility checking

ELF Symbol Versioning Overview:
- Libraries define versions with .gnu.version_d (e.g., GLIBC_2.0, GLIBC_2.17)
- Libraries require versions with .gnu.version_r (e.g., needs GLIBC_2.17)
- Each symbol has a version index in .gnu.version pointing to a version string
- Symbol resolution considers version when matching

Reference:
- https://refspecs.linuxfoundation.org/LSB_5.0.0/LSB-Core-generic/LSB-Core-generic/symversion.html
- https://www.akkadia.org/drepper/symbol-versioning
"""

import logging
import re
import struct
from dataclasses import dataclass, field
from enum import IntEnum, IntFlag
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .emulator import Emulator

logger = logging.getLogger(__name__)


# ==================== Version Section Constants ====================

class VER_DEF(IntEnum):
    """Version definition section constants."""
    NONE = 0
    CURRENT = 1


class VER_FLG(IntFlag):
    """Version definition flags."""
    BASE = 0x1      # Version definition is base version
    WEAK = 0x2      # Weak version reference


class VER_NDX(IntEnum):
    """Version index special values."""
    LOCAL = 0       # Symbol is local
    GLOBAL = 1      # Symbol is global/unversioned
    LORESERVE = 0xff00
    ELIMINATE = 0xff01


# ==================== Version Data Structures ====================

@dataclass
class VersionDef:
    """
    ELF Version Definition (from .gnu.version_d).
    
    Represents a version that this library defines/provides.
    """
    vd_version: int         # Version revision
    vd_flags: VER_FLG       # Flags
    vd_ndx: int             # Version index
    vd_cnt: int             # Number of associated verdaux entries
    vd_hash: int            # ELF hash of version name
    names: list[str] = field(default_factory=list)  # Version name and predecessors

    @property
    def name(self) -> str:
        """Primary version name."""
        return self.names[0] if self.names else ""

    @property
    def is_base(self) -> bool:
        """Is this the base version?"""
        return bool(self.vd_flags & VER_FLG.BASE)

    @property
    def predecessors(self) -> list[str]:
        """Predecessor version names."""
        return self.names[1:] if len(self.names) > 1 else []

    def __str__(self) -> str:
        flags = " (BASE)" if self.is_base else ""
        preds = f" -> {self.predecessors}" if self.predecessors else ""
        return f"VersionDef[{self.vd_ndx}]: {self.name}{flags}{preds}"


@dataclass
class VersionNeed:
    """
    ELF Version Needed (from .gnu.version_r).
    
    Represents a version that this library requires from another library.
    """
    vn_version: int         # Version of structure
    vn_cnt: int             # Number of associated vernaux entries
    vn_file: str            # Dependency file name
    entries: list['VersionNeededAux'] = field(default_factory=list)

    def __str__(self) -> str:
        versions = ", ".join(e.name for e in self.entries)
        return f"VersionNeed[{self.vn_file}]: {versions}"


@dataclass
class VersionNeededAux:
    """
    ELF Version Needed Auxiliary (from .gnu.version_r).
    
    A specific version required from a dependency.
    """
    vna_hash: int           # ELF hash of version name
    vna_flags: VER_FLG      # Flags
    vna_other: int          # Version index used in symbol table
    name: str               # Version string name

    @property
    def is_weak(self) -> bool:
        """Is this a weak version reference?"""
        return bool(self.vna_flags & VER_FLG.WEAK)

    def __str__(self) -> str:
        weak = " (weak)" if self.is_weak else ""
        return f"{self.name}[{self.vna_other}]{weak}"


@dataclass
class VersionedSymbol:
    """A symbol with version information."""
    name: str               # Symbol name
    version: str            # Version string (e.g., "GLIBC_2.17")
    version_index: int      # Index in version table
    is_hidden: bool         # Symbol hidden by versioning
    is_local: bool          # Symbol is local
    address: int = 0        # Symbol address

    @property
    def full_name(self) -> str:
        """Get symbol name with version (e.g., 'malloc@@GLIBC_2.0')."""
        if self.is_hidden:
            return f"{self.name}@{self.version}"
        elif self.version:
            return f"{self.name}@@{self.version}"
        return self.name

    def __str__(self) -> str:
        return f"{self.full_name} @ 0x{self.address:x}"


@dataclass
class LibraryVersion:
    """
    Complete version information for a library.
    
    Contains all parsed version definitions, requirements, and symbol versions.
    """
    name: str               # Library name (from SONAME or filename)
    soname: str = ""        # SONAME if present

    # Version definitions (what this library provides)
    definitions: dict[int, VersionDef] = field(default_factory=dict)

    # Version requirements (what this library needs)
    requirements: list[VersionNeed] = field(default_factory=list)

    # Symbol version table (symbol index -> version index)
    symbol_versions: dict[int, int] = field(default_factory=dict)

    # Quick lookup: version_index -> version name
    version_names: dict[int, str] = field(default_factory=dict)

    def get_version_name(self, index: int) -> str:
        """Get version name for a version index."""
        if index == VER_NDX.LOCAL:
            return "*local*"
        if index == VER_NDX.GLOBAL:
            return "*global*"

        # Check definitions first
        if index in self.definitions:
            return self.definitions[index].name

        # Check cached lookups
        if index in self.version_names:
            return self.version_names[index]

        # Check requirements
        for req in self.requirements:
            for aux in req.entries:
                if aux.vna_other == index:
                    return aux.name

        return f"*unknown[{index}]*"

    def get_symbol_version(self, symbol_index: int) -> tuple[str, bool]:
        """
        Get version info for a symbol.
        
        Returns:
            Tuple of (version_name, is_hidden)
        """
        if symbol_index not in self.symbol_versions:
            return "", False

        ver_index = self.symbol_versions[symbol_index]
        is_hidden = bool(ver_index & 0x8000)
        ver_index = ver_index & 0x7fff

        return self.get_version_name(ver_index), is_hidden

    def get_defined_versions(self) -> list[str]:
        """Get list of version strings this library defines."""
        return [d.name for d in self.definitions.values() if not d.is_base]

    def get_required_versions(self) -> dict[str, list[str]]:
        """
        Get required versions grouped by library.
        
        Returns:
            Dict mapping library name to list of required versions.
        """
        result: dict[str, list[str]] = {}
        for req in self.requirements:
            versions = [aux.name for aux in req.entries]
            result[req.vn_file] = versions
        return result

    def provides_version(self, version: str) -> bool:
        """Check if this library provides a version."""
        for defn in self.definitions.values():
            if defn.name == version:
                return True
        return False

    def requires_version(self, library: str, version: str) -> bool:
        """Check if this library requires a version from another library."""
        for req in self.requirements:
            if req.vn_file == library:
                return any(aux.name == version for aux in req.entries)
        return False

    def __str__(self) -> str:
        lines = [f"LibraryVersion: {self.name}"]
        if self.soname:
            lines.append(f"  SONAME: {self.soname}")
        if self.definitions:
            lines.append(f"  Defines: {', '.join(self.get_defined_versions())}")
        for lib, versions in self.get_required_versions().items():
            lines.append(f"  Requires [{lib}]: {', '.join(versions)}")
        return "\n".join(lines)


# ==================== ELF Hash Functions ====================

def elf_hash(name: str) -> int:
    """
    Compute ELF hash of a string.
    
    This is the standard ELF hash used in .hash sections and for
    version name hashes.
    """
    h = 0
    for char in name.encode('utf-8'):
        h = (h << 4) + char
        g = h & 0xf0000000
        if g:
            h ^= g >> 24
        h &= ~g
    return h


def gnu_hash(name: str) -> int:
    """
    Compute GNU hash of a string.
    
    Used in .gnu.hash sections for faster symbol lookup.
    """
    h = 5381
    for char in name.encode('utf-8'):
        h = ((h << 5) + h + char) & 0xffffffff
    return h


# ==================== Version Parser ====================

class VersionParser:
    """
    Parser for ELF version sections.
    
    Parses:
    - .gnu.version_d (version definitions)
    - .gnu.version_r (version requirements)  
    - .gnu.version (symbol version table)
    """

    def __init__(self, is_64bit: bool = True):
        """
        Initialize version parser.
        
        Args:
            is_64bit: True for 64-bit ELF, False for 32-bit
        """
        self.is_64bit = is_64bit
        self.ptr_size = 8 if is_64bit else 4

    def parse_verdef(self, data: bytes, strtab: bytes) -> dict[int, VersionDef]:
        """
        Parse .gnu.version_d section.
        
        Args:
            data: Raw section data
            strtab: String table data for name lookups
            
        Returns:
            Dict mapping version index to VersionDef
        """
        result: dict[int, VersionDef] = {}
        offset = 0

        while offset < len(data):
            if offset + 20 > len(data):
                break

            # Elfxx_Verdef structure (20 bytes)
            vd_version, vd_flags, vd_ndx, vd_cnt, vd_hash, vd_aux, vd_next = struct.unpack_from(
                '<HHHHIII', data, offset
            )

            if vd_version != VER_DEF.CURRENT:
                logger.warning(f"Unexpected verdef version: {vd_version}")

            # Parse verdaux entries
            names: list[str] = []
            aux_offset = offset + vd_aux

            for _ in range(vd_cnt):
                if aux_offset + 8 > len(data):
                    break

                vda_name, vda_next = struct.unpack_from('<II', data, aux_offset)

                # Get name from string table
                name = self._read_string(strtab, vda_name)
                names.append(name)

                if vda_next == 0:
                    break
                aux_offset += vda_next

            verdef = VersionDef(
                vd_version=vd_version,
                vd_flags=VER_FLG(vd_flags),
                vd_ndx=vd_ndx,
                vd_cnt=vd_cnt,
                vd_hash=vd_hash,
                names=names
            )

            result[vd_ndx] = verdef

            if vd_next == 0:
                break
            offset += vd_next

        return result

    def parse_verneed(self, data: bytes, strtab: bytes) -> list[VersionNeed]:
        """
        Parse .gnu.version_r section.
        
        Args:
            data: Raw section data
            strtab: String table data for name lookups
            
        Returns:
            List of VersionNeed entries
        """
        result: list[VersionNeed] = []
        offset = 0

        while offset < len(data):
            if offset + 16 > len(data):
                break

            # Elfxx_Verneed structure (16 bytes)
            vn_version, vn_cnt, vn_file, vn_aux, vn_next = struct.unpack_from(
                '<HHIII', data, offset
            )

            # Get file name
            file_name = self._read_string(strtab, vn_file)

            # Parse vernaux entries
            entries: list[VersionNeededAux] = []
            aux_offset = offset + vn_aux

            for _ in range(vn_cnt):
                if aux_offset + 16 > len(data):
                    break

                vna_hash, vna_flags, vna_other, vna_name, vna_next = struct.unpack_from(
                    '<IHHII', data, aux_offset
                )

                name = self._read_string(strtab, vna_name)

                aux = VersionNeededAux(
                    vna_hash=vna_hash,
                    vna_flags=VER_FLG(vna_flags),
                    vna_other=vna_other,
                    name=name
                )
                entries.append(aux)

                if vna_next == 0:
                    break
                aux_offset += vna_next

            verneed = VersionNeed(
                vn_version=vn_version,
                vn_cnt=vn_cnt,
                vn_file=file_name,
                entries=entries
            )
            result.append(verneed)

            if vn_next == 0:
                break
            offset += vn_next

        return result

    def parse_versym(self, data: bytes) -> dict[int, int]:
        """
        Parse .gnu.version section (symbol version table).
        
        Args:
            data: Raw section data
            
        Returns:
            Dict mapping symbol index to version index
        """
        result: dict[int, int] = {}
        num_entries = len(data) // 2

        for i in range(num_entries):
            ver_index = struct.unpack_from('<H', data, i * 2)[0]
            result[i] = ver_index

        return result

    def _read_string(self, strtab: bytes, offset: int) -> str:
        """Read null-terminated string from string table."""
        if offset >= len(strtab):
            return ""

        end = strtab.find(b'\x00', offset)
        if end == -1:
            end = len(strtab)

        return strtab[offset:end].decode('utf-8', errors='replace')


# ==================== Version Matcher ====================

class VersionMatcher:
    """
    Version compatibility checker.
    
    Determines if loaded libraries satisfy version requirements.
    """

    def __init__(self):
        """Initialize version matcher."""
        # Library name -> LibraryVersion
        self._libraries: dict[str, LibraryVersion] = {}

        # Cached compatibility results
        self._compat_cache: dict[tuple[str, str, str], bool] = {}

    def register_library(self, lib_version: LibraryVersion) -> None:
        """
        Register a library's version information.
        
        Args:
            lib_version: Parsed version info for the library
        """
        name = lib_version.soname or lib_version.name
        self._libraries[name] = lib_version
        self._compat_cache.clear()
        logger.debug(f"Registered version info for {name}")

    def get_library(self, name: str) -> LibraryVersion | None:
        """Get registered library version info."""
        return self._libraries.get(name)

    def check_version(self, library: str, required_version: str) -> bool:
        """
        Check if a library provides a required version.
        
        Args:
            library: Library name (SONAME or filename)
            required_version: Version string to check (e.g., "GLIBC_2.17")
            
        Returns:
            True if library provides the version
        """
        # Check cache
        cache_key = (library, required_version, "provides")
        if cache_key in self._compat_cache:
            return self._compat_cache[cache_key]

        result = False
        lib = self._libraries.get(library)
        if lib:
            result = lib.provides_version(required_version)

        self._compat_cache[cache_key] = result
        return result

    def check_compatibility(self, library: LibraryVersion) -> list[tuple[str, str, bool]]:
        """
        Check if all version requirements of a library are satisfied.
        
        Args:
            library: Library to check
            
        Returns:
            List of (required_lib, required_version, is_satisfied) tuples
        """
        results: list[tuple[str, str, bool]] = []

        for req in library.requirements:
            for aux in req.entries:
                satisfied = self.check_version(req.vn_file, aux.name)
                results.append((req.vn_file, aux.name, satisfied))

        return results

    def get_unsatisfied_versions(self, library: LibraryVersion) -> list[tuple[str, str]]:
        """
        Get list of unsatisfied version requirements.
        
        Args:
            library: Library to check
            
        Returns:
            List of (library_name, version) tuples that are not satisfied
        """
        unsatisfied = []
        for req_lib, version, satisfied in self.check_compatibility(library):
            if not satisfied:
                unsatisfied.append((req_lib, version))
        return unsatisfied

    def compare_versions(self, v1: str, v2: str) -> int:
        """
        Compare two version strings.
        
        Args:
            v1: First version string
            v2: Second version string
            
        Returns:
            -1 if v1 < v2, 0 if equal, 1 if v1 > v2
        """
        # Extract version numbers from strings like "GLIBC_2.17" or "GCC_4.0.0"
        def parse_version(v: str) -> tuple[str, list[int]]:
            match = re.match(r'^([A-Za-z_]+)_?([\d.]+)?$', v)
            if match:
                prefix = match.group(1)
                nums = match.group(2) or ""
                parts = [int(x) for x in nums.split('.') if x.isdigit()]
                return prefix, parts
            return v, []

        prefix1, nums1 = parse_version(v1)
        prefix2, nums2 = parse_version(v2)

        # Different prefixes are incomparable
        if prefix1 != prefix2:
            return 0 if v1 == v2 else (-1 if v1 < v2 else 1)

        # Compare numeric parts
        for n1, n2 in zip(nums1, nums2):
            if n1 < n2:
                return -1
            if n1 > n2:
                return 1

        # One version might have more parts - check if extra parts are all zeros
        # e.g., 2.0.0 == 2.0 when trailing parts are 0
        if len(nums1) < len(nums2):
            # nums2 has extra parts - if all zeros, they're equal
            if all(n == 0 for n in nums2[len(nums1):]):
                return 0
            return -1
        if len(nums1) > len(nums2):
            # nums1 has extra parts - if all zeros, they're equal
            if all(n == 0 for n in nums1[len(nums2):]):
                return 0
            return 1

        return 0

    def get_highest_version(self, library: str, prefix: str = "") -> str | None:
        """
        Get the highest version provided by a library.
        
        Args:
            library: Library name
            prefix: Version prefix to filter (e.g., "GLIBC_")
            
        Returns:
            Highest version string, or None if not found
        """
        lib = self._libraries.get(library)
        if not lib:
            return None

        versions = lib.get_defined_versions()
        if prefix:
            versions = [v for v in versions if v.startswith(prefix)]

        if not versions:
            return None

        return max(versions, key=lambda v: self._version_key(v, prefix))

    def _version_key(self, version: str, prefix: str = "") -> list[int]:
        """Generate sortable key for a version string."""
        # Remove prefix
        v = version
        if prefix and v.startswith(prefix):
            v = v[len(prefix):]

        # Extract numbers
        parts = re.findall(r'\d+', v)
        return [int(p) for p in parts]


# ==================== SONAME Utilities ====================

def parse_soname(name: str) -> tuple[str, str | None, str | None]:
    """
    Parse a SONAME into components.
    
    Args:
        name: SONAME or library filename (e.g., "libc.so.6", "libssl.so.1.1")
        
    Returns:
        Tuple of (base_name, major_version, full_version)
        Example: ("libc", "6", None) or ("libssl", "1", "1.1")
    """
    # Match patterns like "libfoo.so.X.Y.Z" or "libfoo.so.X"
    match = re.match(r'^(.*?)\.so(?:\.(\d+))?(?:\.(.*))?$', name)
    if match:
        base = match.group(1)
        major = match.group(2)
        minor = match.group(3)

        if major and minor:
            full = f"{major}.{minor}"
        else:
            full = major

        return base, major, full

    # No .so suffix
    return name, None, None


def soname_matches(required: str, available: str) -> bool:
    """
    Check if an available library satisfies a SONAME requirement.
    
    Args:
        required: Required SONAME (e.g., "libc.so.6")
        available: Available SONAME (e.g., "libc.so.6" or "libc.so.6.1")
        
    Returns:
        True if available satisfies required
    """
    # Exact match
    if required == available:
        return True

    # Parse both
    req_base, req_major, _ = parse_soname(required)
    avail_base, avail_major, _ = parse_soname(available)

    # Base name must match
    if req_base != avail_base:
        return False

    # If required specifies major version, available must match
    if req_major is not None and avail_major != req_major:
        return False

    return True


def get_library_version(name: str) -> str | None:
    """
    Extract version from a library name.
    
    Args:
        name: Library name (e.g., "libssl.so.1.1")
        
    Returns:
        Version string or None
    """
    _, _, version = parse_soname(name)
    return version


# ==================== Versioned Symbol Resolution ====================

class VersionedSymbolResolver:
    """
    Resolver for versioned symbol lookups.
    
    Handles symbol resolution with version constraints, implementing
    the glibc symbol versioning lookup algorithm.
    """

    def __init__(self, matcher: VersionMatcher):
        """
        Initialize resolver.
        
        Args:
            matcher: Version matcher for version checks
        """
        self._matcher = matcher

        # Cache: (symbol_name, library) -> List of (address, version) tuples
        self._symbol_cache: dict[tuple[str, str], list[tuple[int, str]]] = {}

    def resolve(
        self,
        symbol: str,
        required_version: str | None = None,
        search_libs: list[str] | None = None
    ) -> tuple[int, str, str] | None:
        """
        Resolve a versioned symbol.
        
        Args:
            symbol: Symbol name to resolve
            required_version: Specific version required, or None for default
            search_libs: Libraries to search, or None for all registered
            
        Returns:
            Tuple of (address, library_name, version) or None if not found
        """
        libs = search_libs or list(self._matcher._libraries.keys())

        for lib_name in libs:
            lib = self._matcher.get_library(lib_name)
            if not lib:
                continue

            # Get symbol matches from this library
            matches = self._find_symbol_versions(symbol, lib)

            if not matches:
                continue

            if required_version:
                # Find exact version match
                for addr, ver in matches:
                    if ver == required_version:
                        return addr, lib_name, ver
            else:
                # Return default version (highest non-hidden, or base)
                # Non-hidden versions are preferred
                default = self._get_default_version(matches)
                if default:
                    return default[0], lib_name, default[1]

        return None

    def resolve_all(
        self,
        symbol: str,
        search_libs: list[str] | None = None
    ) -> list[tuple[int, str, str]]:
        """
        Find all versions of a symbol.
        
        Args:
            symbol: Symbol name
            search_libs: Libraries to search
            
        Returns:
            List of (address, library_name, version) tuples
        """
        results = []
        libs = search_libs or list(self._matcher._libraries.keys())

        for lib_name in libs:
            lib = self._matcher.get_library(lib_name)
            if not lib:
                continue

            matches = self._find_symbol_versions(symbol, lib)
            for addr, ver in matches:
                results.append((addr, lib_name, ver))

        return results

    def _find_symbol_versions(
        self,
        symbol: str,
        lib: LibraryVersion
    ) -> list[tuple[int, str]]:
        """Find all versions of a symbol in a library."""
        # This would need to integrate with the actual symbol table
        # For now, return empty - actual implementation needs symbol table access
        return []

    def _get_default_version(
        self,
        matches: list[tuple[int, str]]
    ) -> tuple[int, str] | None:
        """Get the default version from a list of matches."""
        if not matches:
            return None

        # Prefer non-hidden (@@) over hidden (@)
        # Return highest version among non-hidden
        return matches[0]  # Simplified - real implementation would sort


# ==================== Library Version Manager ====================

class LibraryVersionManager:
    """
    High-level manager for library version tracking.
    
    Coordinates version parsing, compatibility checking, and resolution.
    """

    def __init__(self, emulator: Optional['Emulator'] = None, is_64bit: bool = True):
        """
        Initialize version manager.
        
        Args:
            emulator: Optional emulator for memory access
            is_64bit: True for 64-bit mode
        """
        self._emulator = emulator
        self._is_64bit = is_64bit
        self._parser = VersionParser(is_64bit)
        self._matcher = VersionMatcher()
        self._resolver = VersionedSymbolResolver(self._matcher)

        # Registered libraries
        self._libraries: dict[str, LibraryVersion] = {}

    @property
    def matcher(self) -> VersionMatcher:
        """Get the version matcher."""
        return self._matcher

    @property
    def resolver(self) -> VersionedSymbolResolver:
        """Get the symbol resolver."""
        return self._resolver

    def parse_library(
        self,
        name: str,
        verdef_data: bytes | None = None,
        verneed_data: bytes | None = None,
        versym_data: bytes | None = None,
        strtab_data: bytes = b'',
        soname: str = ""
    ) -> LibraryVersion:
        """
        Parse version information for a library.
        
        Args:
            name: Library name
            verdef_data: .gnu.version_d section data
            verneed_data: .gnu.version_r section data  
            versym_data: .gnu.version section data
            strtab_data: String table (.dynstr) data
            soname: SONAME if known
            
        Returns:
            Parsed LibraryVersion
        """
        lib_version = LibraryVersion(name=name, soname=soname)

        if verdef_data:
            lib_version.definitions = self._parser.parse_verdef(verdef_data, strtab_data)

            # Build version name lookup
            for vd in lib_version.definitions.values():
                lib_version.version_names[vd.vd_ndx] = vd.name

        if verneed_data:
            lib_version.requirements = self._parser.parse_verneed(verneed_data, strtab_data)

            # Add required versions to lookup
            for req in lib_version.requirements:
                for aux in req.entries:
                    lib_version.version_names[aux.vna_other] = aux.name

        if versym_data:
            lib_version.symbol_versions = self._parser.parse_versym(versym_data)

        # Register with matcher
        self._matcher.register_library(lib_version)
        self._libraries[name] = lib_version

        return lib_version

    def get_library(self, name: str) -> LibraryVersion | None:
        """Get version info for a library."""
        return self._libraries.get(name)

    def check_all_requirements(self) -> dict[str, list[tuple[str, str]]]:
        """
        Check all libraries for unsatisfied requirements.
        
        Returns:
            Dict mapping library name to list of (required_lib, version) tuples
        """
        unsatisfied: dict[str, list[tuple[str, str]]] = {}

        for name, lib in self._libraries.items():
            missing = self._matcher.get_unsatisfied_versions(lib)
            if missing:
                unsatisfied[name] = missing

        return unsatisfied

    def get_version_report(self) -> str:
        """Generate a human-readable version report."""
        lines = ["Library Version Report", "=" * 50]

        for name, lib in sorted(self._libraries.items()):
            lines.append(str(lib))
            lines.append("")

        unsatisfied = self.check_all_requirements()
        if unsatisfied:
            lines.append("Unsatisfied Requirements")
            lines.append("-" * 30)
            for lib, missing in unsatisfied.items():
                for req_lib, ver in missing:
                    lines.append(f"  {lib} requires {req_lib}:{ver}")

        return "\n".join(lines)


# ==================== Exports ====================

__all__ = [
    # Constants
    'VER_DEF',
    'VER_FLG',
    'VER_NDX',

    # Data structures
    'VersionDef',
    'VersionNeed',
    'VersionNeededAux',
    'VersionedSymbol',
    'LibraryVersion',

    # Hash functions
    'elf_hash',
    'gnu_hash',

    # Parser
    'VersionParser',

    # Matcher
    'VersionMatcher',

    # SONAME utilities
    'parse_soname',
    'soname_matches',
    'get_library_version',

    # Resolver
    'VersionedSymbolResolver',

    # Manager
    'LibraryVersionManager',
]
