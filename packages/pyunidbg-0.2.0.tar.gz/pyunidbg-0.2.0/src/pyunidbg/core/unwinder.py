"""
Stack Unwinder - Stack frame analysis and backtrace generation.

Provides:
- Frame pointer based unwinding
- DWARF unwinding (simplified)
- Symbol resolution for frames
- Crash analysis
"""

import logging
import struct
from collections.abc import Iterator
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .emulator import Emulator
    from .library import LibraryManager
    from .symbols import SymbolTable

logger = logging.getLogger(__name__)


class UnwindMethod(Enum):
    """Stack unwinding method."""
    FRAME_POINTER = auto()   # FP-based unwinding
    SCAN = auto()            # Stack scanning
    DWARF = auto()           # DWARF CFI (not fully implemented)


@dataclass
class StackFrame:
    """Represents a stack frame."""
    index: int
    pc: int                  # Program counter / return address
    sp: int                  # Stack pointer
    fp: int                  # Frame pointer

    # Symbol info (if available)
    symbol_name: str = ""
    symbol_offset: int = 0
    library_name: str = ""

    # Source info (if available)
    source_file: str = ""
    source_line: int = 0

    def __repr__(self) -> str:
        if self.symbol_name:
            return f"#{self.index} 0x{self.pc:x} {self.symbol_name}+0x{self.symbol_offset:x}"
        return f"#{self.index} 0x{self.pc:x}"

    def format(self, verbose: bool = False) -> str:
        """Format frame for display."""
        parts = [f"#{self.index:2d}"]
        parts.append(f"0x{self.pc:016x}" if self.pc > 0xffffffff else f"0x{self.pc:08x}")

        if self.symbol_name:
            parts.append(f"{self.symbol_name}+0x{self.symbol_offset:x}")

        if self.library_name:
            parts.append(f"({self.library_name})")

        if verbose and self.source_file:
            parts.append(f"at {self.source_file}:{self.source_line}")

        return " ".join(parts)


@dataclass
class Backtrace:
    """Complete backtrace with frames."""
    frames: list[StackFrame] = field(default_factory=list)
    truncated: bool = False
    error: str = ""

    def __len__(self) -> int:
        return len(self.frames)

    def __iter__(self) -> Iterator[StackFrame]:
        return iter(self.frames)

    def __getitem__(self, index: int) -> StackFrame:
        return self.frames[index]

    def print(self, verbose: bool = False) -> None:
        """Print backtrace."""
        print("Backtrace:")
        for frame in self.frames:
            print(f"  {frame.format(verbose)}")

        if self.truncated:
            print("  ... (truncated)")

        if self.error:
            print(f"  Error: {self.error}")

    def to_string(self, verbose: bool = False) -> str:
        """Convert to string."""
        lines = ["Backtrace:"]
        for frame in self.frames:
            lines.append(f"  {frame.format(verbose)}")

        if self.truncated:
            lines.append("  ... (truncated)")

        return "\n".join(lines)


class StackUnwinder:
    """
    Stack unwinder for ARM/ARM64.
    
    Generates backtraces and analyzes stack frames.
    
    Example:
        unwinder = StackUnwinder(emulator)
        
        # Get current backtrace
        bt = unwinder.backtrace()
        bt.print()
        
        # Get backtrace from specific context
        bt = unwinder.backtrace_from(pc, sp, fp)
        
        # Analyze crash
        analysis = unwinder.analyze_crash(siginfo, context)
    """

    def __init__(self, emulator: 'Emulator',
                 symbol_table: 'SymbolTable' = None,
                 library_manager: 'LibraryManager' = None):
        self.emulator = emulator
        self.symbols = symbol_table
        self.libraries = library_manager
        self.is_64bit = emulator.arch in ('arm64', 'aarch64')

        # Configuration
        self.max_frames = 100
        self.validate_addresses = True

        # Pointer size
        self.ptr_size = 8 if self.is_64bit else 4

        # Register names
        if self.is_64bit:
            self.fp_reg = 'x29'
            self.lr_reg = 'x30'
            self.sp_reg = 'sp'
        else:
            self.fp_reg = 'r11'  # Or r7 for Thumb
            self.lr_reg = 'lr'
            self.sp_reg = 'sp'

    def backtrace(self, max_frames: int = 0) -> Backtrace:
        """
        Get backtrace from current context.
        
        Args:
            max_frames: Maximum frames to unwind (0 = use default)
            
        Returns:
            Backtrace object
        """
        pc = self.emulator.get_register('pc')
        sp = self.emulator.get_register(self.sp_reg)
        fp = self.emulator.get_register(self.fp_reg)
        lr = self.emulator.get_register(self.lr_reg)

        return self.backtrace_from(pc, sp, fp, lr, max_frames)

    def backtrace_from(self, pc: int, sp: int, fp: int, lr: int = 0,
                       max_frames: int = 0) -> Backtrace:
        """
        Get backtrace from specific context.
        
        Args:
            pc: Program counter
            sp: Stack pointer
            fp: Frame pointer
            lr: Link register
            max_frames: Maximum frames
            
        Returns:
            Backtrace object
        """
        bt = Backtrace()
        max_frames = max_frames or self.max_frames

        # First frame is current PC
        frame = self._create_frame(0, pc, sp, fp)
        bt.frames.append(frame)

        # Try FP-based unwinding first
        try:
            self._unwind_fp(bt, fp, max_frames)
        except Exception as e:
            bt.error = str(e)

            # Fallback to LR if we only have one frame
            if len(bt.frames) == 1 and lr and lr != pc:
                frame = self._create_frame(1, lr, sp, fp)
                bt.frames.append(frame)

                # Try stack scanning
                try:
                    self._unwind_scan(bt, sp, max_frames)
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)

        if len(bt.frames) >= max_frames:
            bt.truncated = True

        return bt

    def _unwind_fp(self, bt: Backtrace, fp: int, max_frames: int) -> None:
        """Unwind using frame pointer chain."""
        current_fp = fp

        while len(bt.frames) < max_frames:
            if not self._is_valid_address(current_fp):
                break

            # Read saved FP and LR from stack
            try:
                if self.is_64bit:
                    # ARM64: FP points to saved FP, LR is at FP+8
                    saved_fp = self._read_ptr(current_fp)
                    saved_lr = self._read_ptr(current_fp + 8)
                else:
                    # ARM32: FP points to saved FP, LR is at FP+4
                    saved_fp = self._read_ptr(current_fp)
                    saved_lr = self._read_ptr(current_fp + 4)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                break

            # Validate
            if saved_lr == 0 or saved_fp == 0:
                break

            if saved_fp <= current_fp:
                # FP should grow toward higher addresses
                break

            # Create frame
            frame = self._create_frame(
                len(bt.frames),
                saved_lr,
                current_fp,
                saved_fp
            )
            bt.frames.append(frame)

            current_fp = saved_fp

    def _unwind_scan(self, bt: Backtrace, sp: int, max_frames: int) -> None:
        """Unwind by scanning stack for return addresses."""
        scan_size = 0x1000  # Scan 4KB

        for offset in range(0, scan_size, self.ptr_size):
            if len(bt.frames) >= max_frames:
                break

            addr = sp + offset

            try:
                value = self._read_ptr(addr)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                break

            # Check if this looks like a code address
            if self._is_code_address(value):
                # Avoid duplicates
                if any(f.pc == value for f in bt.frames):
                    continue

                frame = self._create_frame(
                    len(bt.frames),
                    value,
                    addr,
                    0
                )
                bt.frames.append(frame)

    def _create_frame(self, index: int, pc: int, sp: int, fp: int) -> StackFrame:
        """Create stack frame with symbol resolution."""
        frame = StackFrame(
            index=index,
            pc=pc,
            sp=sp,
            fp=fp,
        )

        # Resolve symbol
        if self.symbols:
            sym = self.symbols.find_containing(pc)
            if sym:
                frame.symbol_name = sym.display_name
                frame.symbol_offset = pc - sym.address
                frame.library_name = sym.library

        # Get library name if not from symbol
        if not frame.library_name and self.libraries:
            lib = self.libraries.linker.get_library_at(pc)
            if lib:
                frame.library_name = lib.name

        return frame

    def _read_ptr(self, addr: int) -> int:
        """Read pointer from memory."""
        data = self.emulator._uc.mem_read(addr, self.ptr_size)
        if self.is_64bit:
            return struct.unpack('<Q', data)[0]
        else:
            return struct.unpack('<I', data)[0]

    def _is_valid_address(self, addr: int) -> bool:
        """Check if address is valid."""
        if addr == 0:
            return False

        if self.validate_addresses:
            return self.emulator.memory.is_mapped(addr)

        return True

    def _is_code_address(self, addr: int) -> bool:
        """Check if address looks like code."""
        if addr == 0:
            return False

        # Check alignment
        if self.is_64bit:
            if addr & 0x3:  # Must be 4-byte aligned
                return False

        # Check if in code region
        if self.libraries:
            lib = self.libraries.linker.get_library_at(addr)
            if lib:
                return True

        # Check memory mapping
        if self.emulator.memory.is_mapped(addr):
            # Could check execute permission here
            return True

        return False

    # ==================== Crash Analysis ====================

    def analyze_crash(self, pc: int, fault_addr: int = 0,
                      signal: int = 0) -> dict:
        """
        Analyze a crash.
        
        Returns analysis dict with:
        - backtrace
        - crash type
        - possible causes
        - relevant memory info
        """
        analysis = {
            'pc': pc,
            'fault_address': fault_addr,
            'signal': signal,
            'crash_type': 'unknown',
            'causes': [],
            'backtrace': None,
            'registers': {},
            'memory_info': {},
        }

        # Get backtrace
        bt = self.backtrace()
        analysis['backtrace'] = bt

        # Get registers
        if self.is_64bit:
            for i in range(31):
                analysis['registers'][f'x{i}'] = self.emulator.get_register(f'x{i}')
        else:
            for i in range(16):
                analysis['registers'][f'r{i}'] = self.emulator.get_register(f'r{i}')

        analysis['registers']['pc'] = pc
        analysis['registers']['sp'] = self.emulator.get_register('sp')

        # Determine crash type
        if signal == 11:  # SIGSEGV
            analysis['crash_type'] = 'segmentation_fault'

            if fault_addr == 0:
                analysis['causes'].append('NULL pointer dereference')
            elif fault_addr < 0x1000:
                analysis['causes'].append('Low address access (likely NULL + offset)')
            elif not self.emulator.memory.is_mapped(fault_addr):
                analysis['causes'].append('Access to unmapped memory')
            else:
                analysis['causes'].append('Memory protection violation')

        elif signal == 7:  # SIGBUS
            analysis['crash_type'] = 'bus_error'
            analysis['causes'].append('Unaligned memory access or hardware error')

        elif signal == 4:  # SIGILL
            analysis['crash_type'] = 'illegal_instruction'

            if not self._is_valid_address(pc):
                analysis['causes'].append('Jump to invalid address')
            else:
                analysis['causes'].append('Invalid instruction encoding')

        elif signal == 6:  # SIGABRT
            analysis['crash_type'] = 'abort'
            analysis['causes'].append('Explicit abort() call')

        elif signal == 8:  # SIGFPE
            analysis['crash_type'] = 'floating_point_exception'
            analysis['causes'].append('Division by zero or FP error')

        # Check for common patterns
        self._check_patterns(analysis)

        return analysis

    def _check_patterns(self, analysis: dict) -> None:
        """Check for common crash patterns."""
        bt = analysis.get('backtrace')
        if not bt or not bt.frames:
            return

        # Check for stack overflow
        sp = analysis['registers'].get('sp', 0)
        if sp < 0x10000:
            analysis['causes'].append('Possible stack overflow')

        # Check for use-after-free patterns
        fault_addr = analysis.get('fault_address', 0)
        if fault_addr:
            # Common freed memory patterns
            if fault_addr == 0xDEADBEEF:
                analysis['causes'].append('Freed memory marker (0xDEADBEEF)')
            elif fault_addr == 0xFEEDFACE:
                analysis['causes'].append('Freed memory marker (0xFEEDFACE)')
            elif fault_addr & 0xFFFFFFFF == 0xABABABAB:
                analysis['causes'].append('Uninitialized memory (0xABABABAB)')

        # Check if crash is in known dangerous functions
        if bt.frames:
            top_frame = bt.frames[0]
            dangerous = {'free', 'malloc', 'realloc', 'memcpy', 'strcpy'}
            if any(d in top_frame.symbol_name.lower() for d in dangerous):
                analysis['causes'].append(f'Crash in memory function: {top_frame.symbol_name}')

    def print_crash_analysis(self, analysis: dict) -> None:
        """Print crash analysis."""
        print("=== Crash Analysis ===")
        print(f"Type: {analysis['crash_type']}")
        print(f"PC: 0x{analysis['pc']:x}")

        if analysis['fault_address']:
            print(f"Fault Address: 0x{analysis['fault_address']:x}")

        if analysis['causes']:
            print("\nPossible Causes:")
            for cause in analysis['causes']:
                print(f"  - {cause}")

        print("\nRegisters:")
        regs = analysis['registers']
        if self.is_64bit:
            for i in range(0, 32, 4):
                line = "  "
                for j in range(4):
                    reg = f'x{i+j}' if i+j < 31 else 'sp'
                    if reg in regs:
                        line += f"{reg}=0x{regs[reg]:016x}  "
                print(line)

        bt = analysis.get('backtrace')
        if bt:
            print()
            bt.print()

    # ==================== Utilities ====================

    def get_frame_locals(self, frame: StackFrame) -> dict[str, int]:
        """
        Get local variables from stack frame.
        
        This is a simplified version - real implementation would
        need DWARF debug info.
        """
        locals_dict = {}

        if frame.fp == 0:
            return locals_dict

        # Read some stack slots as potential locals
        for i in range(-8, 8):
            offset = i * self.ptr_size
            addr = frame.fp + offset

            try:
                value = self._read_ptr(addr)
                locals_dict[f'slot_{i}'] = value
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        return locals_dict

    def dump_stack(self, sp: int = 0, size: int = 0x100) -> None:
        """Dump stack contents."""
        if sp == 0:
            sp = self.emulator.get_register('sp')

        print(f"Stack dump from 0x{sp:x}:")

        for offset in range(0, size, self.ptr_size * 4):
            addr = sp + offset
            line = f"0x{addr:x}:  "

            for i in range(4):
                ptr_addr = addr + i * self.ptr_size
                try:
                    value = self._read_ptr(ptr_addr)
                    if self.is_64bit:
                        line += f"0x{value:016x}  "
                    else:
                        line += f"0x{value:08x}  "
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)
                    line += "????????  "

            print(line)
