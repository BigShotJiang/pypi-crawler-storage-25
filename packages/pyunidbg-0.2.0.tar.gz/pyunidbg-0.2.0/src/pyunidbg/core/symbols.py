"""
Symbol Table Manager - Fast symbol lookup and management.

Provides:
- Symbol table aggregation across libraries
- JNI function discovery
- Symbol pattern matching
- Demangling support
"""

import logging
import re
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from enum import Enum, auto
from fnmatch import fnmatch
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .linker import ElfSymbol, LoadedLibrary

logger = logging.getLogger(__name__)


class SymbolType(Enum):
    """Symbol types."""
    UNKNOWN = auto()
    FUNCTION = auto()
    OBJECT = auto()      # Data/variable
    SECTION = auto()
    FILE = auto()
    TLS = auto()         # Thread-local storage

    # Special types
    JNI_NATIVE = auto()  # JNI native method
    INIT = auto()        # Initialization function
    FINI = auto()        # Finalization function


class SymbolVisibility(Enum):
    """Symbol visibility."""
    DEFAULT = auto()
    HIDDEN = auto()
    PROTECTED = auto()
    INTERNAL = auto()


@dataclass
class Symbol:
    """Unified symbol representation."""
    name: str
    address: int
    size: int = 0

    # Classification
    type: SymbolType = SymbolType.UNKNOWN
    visibility: SymbolVisibility = SymbolVisibility.DEFAULT

    # Origin
    library: str = ""

    # Demangled name (for C++)
    demangled: str = ""

    # JNI info
    jni_class: str = ""      # For JNI: Java class name
    jni_method: str = ""     # For JNI: Java method name
    jni_signature: str = ""  # For JNI: Method signature

    def __repr__(self) -> str:
        return f"Symbol({self.name!r}, 0x{self.address:x}, {self.type.name})"

    @property
    def display_name(self) -> str:
        """Get best display name (demangled if available)."""
        return self.demangled or self.name

    @property
    def is_jni(self) -> bool:
        return self.type == SymbolType.JNI_NATIVE


@dataclass
class JNIMethod:
    """Parsed JNI native method information."""
    symbol_name: str
    address: int

    # Java info
    class_name: str        # e.g., "com.example.MyClass"
    method_name: str       # e.g., "nativeInit"
    signature: str = ""    # e.g., "(Ljava/lang/String;)V"

    # Overload info
    is_overloaded: bool = False
    overload_suffix: str = ""

    def __repr__(self) -> str:
        return f"JNIMethod({self.class_name}.{self.method_name} @ 0x{self.address:x})"

    @property
    def full_name(self) -> str:
        return f"{self.class_name}.{self.method_name}"

    @property
    def jni_name(self) -> str:
        """Standard JNI function name."""
        class_path = self.class_name.replace('.', '_')
        return f"Java_{class_path}_{self.method_name}"


class SymbolTable:
    """
    Unified symbol table manager.
    
    Aggregates symbols from all loaded libraries and provides
    fast lookup by name, address, or pattern.
    
    Example:
        symbols = SymbolTable()
        
        # Add symbols from linker
        for lib in linker.list_libraries():
            symbols.add_library(lib)
        
        # Find symbol
        sym = symbols.find("Java_com_example_Native_init")
        
        # Find by pattern
        for sym in symbols.find_pattern("Java_*"):
            print(sym)
        
        # Get JNI methods
        for jni in symbols.get_jni_methods():
            print(f"{jni.class_name}.{jni.method_name}")
    """

    def __init__(self):
        # Symbol storage
        self._by_name: dict[str, Symbol] = {}
        self._by_address: dict[int, Symbol] = {}

        # Address-sorted list for range queries
        self._sorted_addresses: list[tuple[int, Symbol]] = []
        self._sorted_dirty = False

        # JNI method cache
        self._jni_methods: dict[str, JNIMethod] = {}

        # Demangler
        self._demangler: Callable[[str], str] | None = None
        self._setup_demangler()

    def _setup_demangler(self) -> None:
        """Setup C++ demangler if available."""
        try:
            import cxxfilt
            self._demangler = cxxfilt.demangle
        except ImportError:
            try:
                # Try subprocess fallback
                import subprocess
                def demangle(name: str) -> str:
                    try:
                        result = subprocess.run(
                            ['c++filt', name],
                            capture_output=True,
                            text=True,
                            timeout=1
                        )
                        return result.stdout.strip() or name
                    except Exception:
                        logger.debug("Exception suppressed", exc_info=True)
                        return name
                self._demangler = demangle
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                self._demangler = None

    # ==================== Adding Symbols ====================

    def add_symbol(self, sym: Symbol) -> None:
        """Add a single symbol."""
        self._by_name[sym.name] = sym
        self._by_address[sym.address] = sym
        self._sorted_dirty = True

        # Demangle C++ names
        if self._demangler and sym.name.startswith('_Z'):
            try:
                sym.demangled = self._demangler(sym.name)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        # Detect JNI methods
        if sym.name.startswith('Java_'):
            self._parse_jni_symbol(sym)

    def add_library(self, lib: 'LoadedLibrary') -> int:
        """Add all symbols from a library. Returns count added."""
        count = 0
        for name, elf_sym in lib.symbols.items():
            sym = Symbol(
                name=name,
                address=elf_sym.address,
                size=elf_sym.size,
                type=self._classify_symbol(elf_sym),
                library=lib.name,
            )
            self.add_symbol(sym)
            count += 1

        logger.debug(f"Added {count} symbols from {lib.name}")
        return count

    def _classify_symbol(self, elf_sym: 'ElfSymbol') -> SymbolType:
        """Classify ELF symbol type."""
        st_type = elf_sym.type

        if st_type == 2:  # STT_FUNC
            if elf_sym.name.startswith('Java_'):
                return SymbolType.JNI_NATIVE
            return SymbolType.FUNCTION
        elif st_type == 1:  # STT_OBJECT
            return SymbolType.OBJECT
        elif st_type == 3:  # STT_SECTION
            return SymbolType.SECTION
        elif st_type == 4:  # STT_FILE
            return SymbolType.FILE
        elif st_type == 6:  # STT_TLS
            return SymbolType.TLS

        return SymbolType.UNKNOWN

    def _parse_jni_symbol(self, sym: Symbol) -> None:
        """Parse JNI native method symbol."""
        # Format: Java_package_Class_method or Java_package_Class_method__signature
        name = sym.name[5:]  # Remove "Java_"

        # Check for overloaded method (has signature suffix)
        is_overloaded = '__' in name
        overload_suffix = ""

        if is_overloaded:
            parts = name.rsplit('__', 1)
            name = parts[0]
            overload_suffix = parts[1] if len(parts) > 1 else ""

        # Split into class and method
        # The last part is the method name
        parts = name.split('_')

        if len(parts) < 2:
            return

        method_name = parts[-1]
        class_parts = parts[:-1]
        class_name = '.'.join(class_parts)

        # Decode escaped characters
        class_name = self._decode_jni_name(class_name)
        method_name = self._decode_jni_name(method_name)

        jni = JNIMethod(
            symbol_name=sym.name,
            address=sym.address,
            class_name=class_name,
            method_name=method_name,
            is_overloaded=is_overloaded,
            overload_suffix=overload_suffix,
        )

        self._jni_methods[sym.name] = jni

        # Update symbol with JNI info
        sym.type = SymbolType.JNI_NATIVE
        sym.jni_class = class_name
        sym.jni_method = method_name

    def _decode_jni_name(self, name: str) -> str:
        """Decode JNI escaped characters."""
        # _0xxxx = Unicode character
        # _1 = _ (underscore)
        # _2 = ; (semicolon)
        # _3 = [ (array)

        result = name
        result = re.sub(r'_0([0-9a-fA-F]{4})',
                       lambda m: chr(int(m.group(1), 16)), result)
        result = result.replace('_1', '_')
        result = result.replace('_2', ';')
        result = result.replace('_3', '[')

        return result

    # ==================== Lookup ====================

    def find(self, name: str) -> Symbol | None:
        """Find symbol by exact name."""
        return self._by_name.get(name)

    def find_at(self, address: int) -> Symbol | None:
        """Find symbol at exact address."""
        return self._by_address.get(address)

    def find_containing(self, address: int) -> Symbol | None:
        """Find symbol containing address (for function lookup)."""
        self._ensure_sorted()

        # Binary search for address
        left, right = 0, len(self._sorted_addresses)

        while left < right:
            mid = (left + right) // 2
            sym_addr, sym = self._sorted_addresses[mid]

            if sym_addr <= address < sym_addr + max(sym.size, 1):
                return sym
            elif sym_addr > address:
                right = mid
            else:
                left = mid + 1

        # Check previous symbol
        if left > 0:
            sym_addr, sym = self._sorted_addresses[left - 1]
            if sym.size > 0 and sym_addr <= address < sym_addr + sym.size:
                return sym
            # Allow some slack for symbols without size info
            if sym.size == 0 and sym_addr <= address < sym_addr + 0x1000:
                return sym

        return None

    def find_pattern(self, pattern: str) -> Iterator[Symbol]:
        """Find symbols matching glob pattern."""
        for name, sym in self._by_name.items():
            if fnmatch(name, pattern):
                yield sym

    def find_regex(self, regex: str) -> Iterator[Symbol]:
        """Find symbols matching regex."""
        compiled = re.compile(regex)
        for name, sym in self._by_name.items():
            if compiled.match(name):
                yield sym

    def find_demangled(self, pattern: str) -> Iterator[Symbol]:
        """Find symbols by demangled name pattern."""
        for sym in self._by_name.values():
            if sym.demangled and fnmatch(sym.demangled, pattern):
                yield sym

    def _ensure_sorted(self) -> None:
        """Ensure address list is sorted."""
        if self._sorted_dirty:
            self._sorted_addresses = [
                (sym.address, sym)
                for sym in self._by_name.values()
                if sym.address != 0
            ]
            self._sorted_addresses.sort(key=lambda x: x[0])
            self._sorted_dirty = False

    # ==================== JNI Methods ====================

    def get_jni_methods(self) -> list[JNIMethod]:
        """Get all JNI native methods."""
        return list(self._jni_methods.values())

    def find_jni_method(self, class_name: str, method_name: str) -> JNIMethod | None:
        """Find JNI method by class and method name."""
        for jni in self._jni_methods.values():
            if jni.class_name == class_name and jni.method_name == method_name:
                return jni
        return None

    def get_jni_methods_for_class(self, class_name: str) -> list[JNIMethod]:
        """Get all JNI methods for a class."""
        return [jni for jni in self._jni_methods.values()
                if jni.class_name == class_name]

    def find_jni_by_pattern(self, pattern: str) -> Iterator[JNIMethod]:
        """Find JNI methods by class.method pattern."""
        for jni in self._jni_methods.values():
            if fnmatch(jni.full_name, pattern):
                yield jni

    # ==================== Queries ====================

    def get_functions(self, library: str = None) -> Iterator[Symbol]:
        """Get all function symbols."""
        for sym in self._by_name.values():
            if sym.type in (SymbolType.FUNCTION, SymbolType.JNI_NATIVE):
                if library is None or sym.library == library:
                    yield sym

    def get_objects(self, library: str = None) -> Iterator[Symbol]:
        """Get all object/data symbols."""
        for sym in self._by_name.values():
            if sym.type == SymbolType.OBJECT:
                if library is None or sym.library == library:
                    yield sym

    def get_imports(self, library: str) -> set[str]:
        """Get imported symbols for a library."""
        # Note: This requires tracking undefined symbols
        imports = set()
        for sym in self._by_name.values():
            if sym.library == library and sym.address == 0:
                imports.add(sym.name)
        return imports

    def get_exports(self, library: str) -> dict[str, int]:
        """Get exported symbols for a library."""
        exports = {}
        for sym in self._by_name.values():
            if sym.library == library and sym.address != 0:
                exports[sym.name] = sym.address
        return exports

    # ==================== Statistics ====================

    @property
    def count(self) -> int:
        """Total symbol count."""
        return len(self._by_name)

    def count_by_type(self) -> dict[SymbolType, int]:
        """Count symbols by type."""
        counts: dict[SymbolType, int] = {}
        for sym in self._by_name.values():
            counts[sym.type] = counts.get(sym.type, 0) + 1
        return counts

    def count_by_library(self) -> dict[str, int]:
        """Count symbols by library."""
        counts: dict[str, int] = {}
        for sym in self._by_name.values():
            lib = sym.library or "unknown"
            counts[lib] = counts.get(lib, 0) + 1
        return counts

    # ==================== Output ====================

    def print_summary(self) -> None:
        """Print symbol table summary."""
        print("=== Symbol Table Summary ===")
        print(f"Total symbols: {self.count}")
        print()

        print("By type:")
        for stype, count in sorted(self.count_by_type().items(),
                                   key=lambda x: -x[1]):
            print(f"  {stype.name}: {count}")
        print()

        print("By library:")
        for lib, count in sorted(self.count_by_library().items(),
                                key=lambda x: -x[1]):
            print(f"  {lib}: {count}")
        print()

        jni_count = len(self._jni_methods)
        if jni_count:
            print(f"JNI methods: {jni_count}")

            # Group by class
            classes: dict[str, int] = {}
            for jni in self._jni_methods.values():
                classes[jni.class_name] = classes.get(jni.class_name, 0) + 1

            for cls, count in sorted(classes.items()):
                print(f"  {cls}: {count} methods")

    def print_jni_methods(self) -> None:
        """Print all JNI methods."""
        print("=== JNI Native Methods ===")

        # Group by class
        by_class: dict[str, list[JNIMethod]] = {}
        for jni in self._jni_methods.values():
            by_class.setdefault(jni.class_name, []).append(jni)

        for class_name in sorted(by_class.keys()):
            print(f"\n{class_name}:")
            for jni in sorted(by_class[class_name], key=lambda x: x.method_name):
                print(f"  {jni.method_name} @ 0x{jni.address:x}")

    def export_symbols(self, library: str = None) -> list[dict]:
        """Export symbols as list of dicts."""
        result = []
        for sym in self._by_name.values():
            if library and sym.library != library:
                continue

            result.append({
                'name': sym.name,
                'address': sym.address,
                'size': sym.size,
                'type': sym.type.name,
                'library': sym.library,
                'demangled': sym.demangled,
            })

        return result


# ==================== Convenience Functions ====================

def find_jni_methods(library_path: str) -> list[JNIMethod]:
    """
    Quick helper to find JNI methods in a library.
    
    Example:
        methods = find_jni_methods("libnative.so")
        for m in methods:
            print(f"{m.class_name}.{m.method_name}")
    """
    from .elf import ELFFile

    with open(library_path, 'rb') as f:
        elf = ELFFile(f.read())

    symbols = SymbolTable()

    # Parse symbols from ELF
    for shdr in elf.section_headers:
        if shdr.sh_type == 11:  # SHT_DYNSYM
            # Parse dynsym
            pass  # Would need full parsing here

    return symbols.get_jni_methods()
