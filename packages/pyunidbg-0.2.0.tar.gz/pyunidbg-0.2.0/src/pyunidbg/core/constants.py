"""Constants and enumerations for PyUniDbg."""

from enum import Enum, IntEnum, auto


class Architecture(str, Enum):
    """Supported CPU architectures."""
    ARM = "arm"
    ARM64 = "arm64"
    X86 = "x86"
    X86_64 = "x86_64"


class Endianness(str, Enum):
    """Byte order."""
    LITTLE = "little"
    BIG = "big"


class MemoryProtection(IntEnum):
    """Memory protection flags."""
    NONE = 0
    READ = 1
    WRITE = 2
    EXEC = 4
    READ_WRITE = READ | WRITE
    READ_EXEC = READ | EXEC
    READ_WRITE_EXEC = READ | WRITE | EXEC
    ALL = READ | WRITE | EXEC


class MemoryAccess(IntEnum):
    """Memory access type for hooks."""
    READ = auto()
    WRITE = auto()
    FETCH = auto()
    READ_UNMAPPED = auto()
    WRITE_UNMAPPED = auto()
    FETCH_UNMAPPED = auto()
    READ_PROT = auto()
    WRITE_PROT = auto()
    FETCH_PROT = auto()


# Memory layout constants
class MemoryLayout:
    """Default memory layout for Android emulation."""

    # Stack
    STACK_BASE = 0xC0000000
    STACK_SIZE = 0x00100000  # 1MB

    # Heap
    HEAP_BASE = 0x10000000
    HEAP_SIZE = 0x10000000  # 256MB

    # Library loading base
    LIBRARY_BASE = 0x40000000
    LIBRARY_MAX = 0x80000000

    # JNI/Java heap
    JAVA_HEAP_BASE = 0x80000000
    JAVA_HEAP_SIZE = 0x10000000  # 256MB

    # Hook trampolines
    HOOK_BASE = 0x90000000
    HOOK_SIZE = 0x00100000  # 1MB

    # Page size
    PAGE_SIZE = 0x1000  # 4KB

    @classmethod
    def align_up(cls, value: int, alignment: int = None) -> int:
        """Align value up to the given alignment."""
        if alignment is None:
            alignment = cls.PAGE_SIZE
        return (value + alignment - 1) & ~(alignment - 1)

    @classmethod
    def align_down(cls, value: int, alignment: int = None) -> int:
        """Align value down to the given alignment."""
        if alignment is None:
            alignment = cls.PAGE_SIZE
        return value & ~(alignment - 1)


# ARM registers
class ARMReg(IntEnum):
    """ARM32 register indices."""
    R0 = 0
    R1 = 1
    R2 = 2
    R3 = 3
    R4 = 4
    R5 = 5
    R6 = 6
    R7 = 7
    R8 = 8
    R9 = 9
    R10 = 10
    R11 = 11  # FP
    R12 = 12  # IP
    SP = 13
    LR = 14
    PC = 15
    CPSR = 16


class ARM64Reg(IntEnum):
    """ARM64 register indices."""
    X0 = 0
    X1 = 1
    X2 = 2
    X3 = 3
    X4 = 4
    X5 = 5
    X6 = 6
    X7 = 7
    X8 = 8
    X9 = 9
    X10 = 10
    X11 = 11
    X12 = 12
    X13 = 13
    X14 = 14
    X15 = 15
    X16 = 16
    X17 = 17
    X18 = 18
    X19 = 19
    X20 = 20
    X21 = 21
    X22 = 22
    X23 = 23
    X24 = 24
    X25 = 25
    X26 = 26
    X27 = 27
    X28 = 28
    X29 = 29  # FP
    X30 = 30  # LR
    SP = 31
    PC = 32
    NZCV = 33


class X86Reg(IntEnum):
    """x86 (32-bit) register indices."""
    EAX = 0
    ECX = 1
    EDX = 2
    EBX = 3
    ESP = 4
    EBP = 5
    ESI = 6
    EDI = 7
    EIP = 8
    EFLAGS = 9


class X86_64Reg(IntEnum):
    """x86-64 register indices."""
    RAX = 0
    RCX = 1
    RDX = 2
    RBX = 3
    RSP = 4
    RBP = 5
    RSI = 6
    RDI = 7
    R8 = 8
    R9 = 9
    R10 = 10
    R11 = 11
    R12 = 12
    R13 = 13
    R14 = 14
    R15 = 15
    RIP = 16
    RFLAGS = 17
