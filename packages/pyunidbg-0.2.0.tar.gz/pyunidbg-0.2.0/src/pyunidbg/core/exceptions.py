"""
Exception Handling - ARM exceptions and Unix signals.

Provides:
- ARM exception vector emulation
- Unix signal handling (SIGSEGV, SIGBUS, etc.)
- Custom exception handlers
- Stack unwinding support
"""

import logging
import struct
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .emulator import Emulator

from unicorn import (
    UC_HOOK_INSN_INVALID,
    UC_HOOK_INTR,
    UC_HOOK_MEM_PROT,
    UC_HOOK_MEM_UNMAPPED,
    UC_MEM_FETCH,
    UC_MEM_WRITE,
)

logger = logging.getLogger(__name__)


# ==================== Signal Numbers ====================

class Signal(IntEnum):
    """Unix signal numbers (Linux/Android)."""
    SIGHUP = 1
    SIGINT = 2
    SIGQUIT = 3
    SIGILL = 4
    SIGTRAP = 5
    SIGABRT = 6
    SIGBUS = 7
    SIGFPE = 8
    SIGKILL = 9
    SIGUSR1 = 10
    SIGSEGV = 11
    SIGUSR2 = 12
    SIGPIPE = 13
    SIGALRM = 14
    SIGTERM = 15
    SIGSTKFLT = 16
    SIGCHLD = 17
    SIGCONT = 18
    SIGSTOP = 19
    SIGTSTP = 20
    SIGTTIN = 21
    SIGTTOU = 22
    SIGURG = 23
    SIGXCPU = 24
    SIGXFSZ = 25
    SIGVTALRM = 26
    SIGPROF = 27
    SIGWINCH = 28
    SIGIO = 29
    SIGPWR = 30
    SIGSYS = 31


class ExceptionType(IntEnum):
    """ARM exception types."""
    RESET = 0
    UNDEFINED = 1
    SVC = 2           # Supervisor call (syscall)
    PREFETCH_ABORT = 3
    DATA_ABORT = 4
    IRQ = 5
    FIQ = 6

    # Custom types
    BREAKPOINT = 100
    WATCHPOINT = 101
    INVALID_INSN = 102
    MEMORY_ERROR = 103


class SignalAction(IntEnum):
    """Signal disposition."""
    DEFAULT = 0      # SIG_DFL
    IGNORE = 1       # SIG_IGN
    HANDLER = 2      # Custom handler


# ==================== Data Structures ====================

@dataclass
class ExceptionContext:
    """CPU context at exception time."""
    # General registers
    regs: dict[str, int] = field(default_factory=dict)

    # Special registers
    pc: int = 0
    sp: int = 0
    lr: int = 0
    cpsr: int = 0      # ARM32 / PSTATE for ARM64

    # Exception info
    exception_type: ExceptionType = ExceptionType.UNDEFINED
    fault_address: int = 0
    error_code: int = 0

    # For ARM64
    esr: int = 0       # Exception Syndrome Register
    far: int = 0       # Fault Address Register


@dataclass
class SignalInfo:
    """siginfo_t equivalent."""
    signo: int
    errno: int = 0
    code: int = 0

    # Signal-specific data
    pid: int = 0       # Sending process
    uid: int = 0       # Sender's UID
    addr: int = 0      # Fault address (for SIGSEGV/SIGBUS)
    status: int = 0    # Exit status (for SIGCHLD)

    def to_bytes(self, is_64bit: bool) -> bytes:
        """Serialize to siginfo_t structure."""
        if is_64bit:
            # 64-bit siginfo_t (128 bytes)
            data = struct.pack('<iiiIIQ',
                self.signo, self.errno, self.code,
                self.pid, self.uid, self.addr
            )
            return data.ljust(128, b'\x00')
        else:
            # 32-bit siginfo_t
            data = struct.pack('<iiiIII',
                self.signo, self.errno, self.code,
                self.pid, self.uid, self.addr
            )
            return data.ljust(128, b'\x00')


@dataclass
class SignalHandler:
    """Registered signal handler."""
    signum: int
    action: SignalAction
    handler: int = 0        # Handler function address

    # sigaction flags
    flags: int = 0
    mask: int = 0           # Blocked signals during handler
    restorer: int = 0       # Signal return trampoline

    # Python callback (for internal use)
    callback: Callable | None = None


@dataclass
class UContext:
    """ucontext_t for signal handling."""
    # Saved context
    context: ExceptionContext

    # Signal mask
    sigmask: int = 0

    # Stack info
    stack_sp: int = 0
    stack_size: int = 0
    stack_flags: int = 0

    def to_bytes(self, is_64bit: bool) -> bytes:
        """Serialize to ucontext_t structure."""
        # Simplified - just the key fields
        if is_64bit:
            # mcontext with registers
            regs_data = b''
            for i in range(31):
                val = self.context.regs.get(f'x{i}', 0)
                regs_data += struct.pack('<Q', val)
            regs_data += struct.pack('<QQQ',
                self.context.sp, self.context.pc, self.context.cpsr)
            return regs_data
        else:
            regs_data = b''
            for i in range(16):
                val = self.context.regs.get(f'r{i}', 0)
                regs_data += struct.pack('<I', val)
            regs_data += struct.pack('<I', self.context.cpsr)
            return regs_data


class ExceptionHandler:
    """
    ARM Exception and Signal Handler.
    
    Manages:
    - Memory access violations (SIGSEGV, SIGBUS)
    - Invalid instructions (SIGILL)
    - Breakpoints and watchpoints
    - Custom signal handlers
    
    Example:
        exceptions = ExceptionHandler(emulator)
        
        # Register signal handler
        exceptions.register_signal(Signal.SIGSEGV, handler_addr)
        
        # Or use Python callback
        def on_segv(emu, siginfo, context):
            print(f"SIGSEGV at 0x{context.pc:x}")
            return True  # Handled
        
        exceptions.on_signal(Signal.SIGSEGV, on_segv)
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.is_64bit = emulator.arch in ('arm64', 'aarch64')

        # Signal handlers
        self._handlers: dict[int, SignalHandler] = {}

        # Pending signals
        self._pending: list[tuple[int, SignalInfo]] = []

        # Signal mask (blocked signals)
        self._sigmask: int = 0

        # Python callbacks
        self._callbacks: dict[int, list[Callable]] = {}

        # Exception statistics
        self._stats = {
            'total_exceptions': 0,
            'sigsegv': 0,
            'sigbus': 0,
            'sigill': 0,
            'handled': 0,
            'unhandled': 0,
        }

        # Alternate signal stack
        self._alt_stack: tuple[int, int] | None = None  # (sp, size)

        # Signal return trampoline
        self._sigreturn_addr = 0

        # Exception hooks
        self._exception_hooks: list[Callable] = []

        # Install Unicorn hooks
        self._install_hooks()

    def _install_hooks(self) -> None:
        """Install Unicorn exception hooks."""
        uc = self.emulator._uc

        # Memory access errors
        uc.hook_add(UC_HOOK_MEM_UNMAPPED, self._on_mem_error)
        uc.hook_add(UC_HOOK_MEM_PROT, self._on_mem_error)

        # Invalid instructions
        uc.hook_add(UC_HOOK_INSN_INVALID, self._on_invalid_insn)

        # Interrupts (for software breakpoints)
        uc.hook_add(UC_HOOK_INTR, self._on_interrupt)

    # ==================== Exception Hooks ====================

    def _on_mem_error(self, uc, access, address: int, size: int,
                      value: int, user_data) -> bool:
        """Handle memory access error."""
        self._stats['total_exceptions'] += 1

        # Determine signal type
        if access == UC_MEM_FETCH:
            # Instruction fetch error
            signum = Signal.SIGSEGV
            code = 1  # SEGV_MAPERR
        elif access == UC_MEM_WRITE:
            signum = Signal.SIGSEGV
            code = 2  # SEGV_ACCERR
        else:
            signum = Signal.SIGSEGV
            code = 1

        self._stats['sigsegv'] += 1

        # Create signal info
        pc = uc.reg_read(self.emulator.pc_reg)
        siginfo = SignalInfo(
            signo=signum,
            code=code,
            addr=address,
        )

        # Create exception context
        context = self._save_context()
        context.exception_type = ExceptionType.DATA_ABORT
        context.fault_address = address

        logger.warning(f"Memory error: access=0x{address:x} pc=0x{pc:x}")

        # Try to handle
        handled = self._deliver_signal(signum, siginfo, context)

        if handled:
            self._stats['handled'] += 1
            return True

        self._stats['unhandled'] += 1
        return False  # Let Unicorn raise exception

    def _on_invalid_insn(self, uc, user_data) -> bool:
        """Handle invalid instruction."""
        self._stats['total_exceptions'] += 1
        self._stats['sigill'] += 1

        pc = uc.reg_read(self.emulator.pc_reg)

        siginfo = SignalInfo(
            signo=Signal.SIGILL,
            code=1,  # ILL_ILLOPC
            addr=pc,
        )

        context = self._save_context()
        context.exception_type = ExceptionType.UNDEFINED

        logger.warning(f"Invalid instruction at 0x{pc:x}")

        handled = self._deliver_signal(Signal.SIGILL, siginfo, context)

        if handled:
            self._stats['handled'] += 1
            return True

        self._stats['unhandled'] += 1
        return False

    def _on_interrupt(self, uc, intno: int, user_data) -> None:
        """Handle interrupt (software breakpoint)."""
        if intno == 2:  # SVC
            # Syscall - handled elsewhere
            return

        self._stats['total_exceptions'] += 1

        pc = uc.reg_read(self.emulator.pc_reg)

        siginfo = SignalInfo(
            signo=Signal.SIGTRAP,
            code=1,  # TRAP_BRKPT
            addr=pc,
        )

        context = self._save_context()
        context.exception_type = ExceptionType.BREAKPOINT

        self._deliver_signal(Signal.SIGTRAP, siginfo, context)

    # ==================== Signal Delivery ====================

    def _deliver_signal(self, signum: int, siginfo: SignalInfo,
                        context: ExceptionContext) -> bool:
        """Deliver signal to handler."""
        # Check Python callbacks first
        if signum in self._callbacks:
            for callback in self._callbacks[signum]:
                try:
                    if callback(self.emulator, siginfo, context):
                        return True
                except Exception as e:
                    logger.error(f"Signal callback error: {e}")

        # Check for exception hooks
        for hook in self._exception_hooks:
            try:
                if hook(self.emulator, signum, siginfo, context):
                    return True
            except Exception as e:
                logger.error(f"Exception hook error: {e}")

        # Check registered handler
        handler = self._handlers.get(signum)
        if not handler:
            return False

        if handler.action == SignalAction.IGNORE:
            return True

        if handler.action == SignalAction.DEFAULT:
            return self._default_action(signum)

        if handler.action == SignalAction.HANDLER and handler.handler:
            return self._call_signal_handler(handler, siginfo, context)

        return False

    def _call_signal_handler(self, handler: SignalHandler,
                             siginfo: SignalInfo,
                             context: ExceptionContext) -> bool:
        """Set up and call signal handler."""
        # Choose stack
        if self._alt_stack and (handler.flags & 0x08000000):  # SA_ONSTACK
            sp = self._alt_stack[0] + self._alt_stack[1]
        else:
            sp = context.sp

        # Align stack
        sp = (sp - 256) & ~0xf

        # Create ucontext
        ucontext = UContext(context=context, sigmask=self._sigmask)

        # Write signal frame to stack
        siginfo_addr = sp
        ucontext_addr = sp + 128

        self.emulator._uc.mem_write(siginfo_addr, siginfo.to_bytes(self.is_64bit))
        self.emulator._uc.mem_write(ucontext_addr, ucontext.to_bytes(self.is_64bit))

        # Set up registers for handler call
        if self.is_64bit:
            self.emulator._uc.reg_write(self.emulator.regs['x0'], siginfo.signo)
            self.emulator._uc.reg_write(self.emulator.regs['x1'], siginfo_addr)
            self.emulator._uc.reg_write(self.emulator.regs['x2'], ucontext_addr)
            self.emulator._uc.reg_write(self.emulator.regs['sp'], sp)

            # Set return address to sigreturn trampoline
            if self._sigreturn_addr:
                self.emulator._uc.reg_write(self.emulator.regs['x30'],
                                           self._sigreturn_addr)
        else:
            self.emulator._uc.reg_write(self.emulator.regs['r0'], siginfo.signo)
            self.emulator._uc.reg_write(self.emulator.regs['r1'], siginfo_addr)
            self.emulator._uc.reg_write(self.emulator.regs['r2'], ucontext_addr)
            self.emulator._uc.reg_write(self.emulator.regs['sp'], sp)
            self.emulator._uc.reg_write(self.emulator.regs['lr'],
                                       self._sigreturn_addr or 0xDEADBEEF)

        # Jump to handler
        self.emulator._uc.reg_write(self.emulator.pc_reg, handler.handler)

        logger.debug(f"Calling signal handler at 0x{handler.handler:x} for signal {siginfo.signo}")

        return True

    def _default_action(self, signum: int) -> bool:
        """Apply default signal action."""
        # Signals that terminate
        terminate = {
            Signal.SIGHUP, Signal.SIGINT, Signal.SIGKILL, Signal.SIGTERM,
            Signal.SIGPIPE, Signal.SIGALRM, Signal.SIGUSR1, Signal.SIGUSR2,
        }

        # Signals that core dump
        coredump = {
            Signal.SIGQUIT, Signal.SIGILL, Signal.SIGABRT, Signal.SIGFPE,
            Signal.SIGSEGV, Signal.SIGBUS, Signal.SIGSYS,
        }

        # Signals to ignore
        ignore = {
            Signal.SIGCHLD, Signal.SIGURG, Signal.SIGWINCH,
        }

        if signum in ignore:
            return True

        if signum in terminate or signum in coredump:
            logger.error(f"Process terminated by signal {signum}")
            # Stop emulation
            self.emulator._uc.emu_stop()
            return True

        return False

    # ==================== Context Management ====================

    def _save_context(self) -> ExceptionContext:
        """Save current CPU context."""
        uc = self.emulator._uc
        ctx = ExceptionContext()

        if self.is_64bit:
            for i in range(31):
                ctx.regs[f'x{i}'] = uc.reg_read(self.emulator.regs[f'x{i}'])
            ctx.pc = uc.reg_read(self.emulator.pc_reg)
            ctx.sp = uc.reg_read(self.emulator.regs['sp'])
            ctx.lr = uc.reg_read(self.emulator.regs['x30'])
        else:
            for i in range(16):
                ctx.regs[f'r{i}'] = uc.reg_read(self.emulator.regs[f'r{i}'])
            ctx.pc = uc.reg_read(self.emulator.pc_reg)
            ctx.sp = uc.reg_read(self.emulator.regs['sp'])
            ctx.lr = uc.reg_read(self.emulator.regs['lr'])

        return ctx

    def _restore_context(self, ctx: ExceptionContext) -> None:
        """Restore CPU context."""
        uc = self.emulator._uc

        if self.is_64bit:
            for i in range(31):
                if f'x{i}' in ctx.regs:
                    uc.reg_write(self.emulator.regs[f'x{i}'], ctx.regs[f'x{i}'])
            uc.reg_write(self.emulator.pc_reg, ctx.pc)
            uc.reg_write(self.emulator.regs['sp'], ctx.sp)
        else:
            for i in range(16):
                if f'r{i}' in ctx.regs:
                    uc.reg_write(self.emulator.regs[f'r{i}'], ctx.regs[f'r{i}'])
            uc.reg_write(self.emulator.pc_reg, ctx.pc)
            uc.reg_write(self.emulator.regs['sp'], ctx.sp)

    # ==================== Signal Registration ====================

    def register_signal(self, signum: int, handler_addr: int,
                        flags: int = 0, mask: int = 0) -> SignalHandler | None:
        """
        Register signal handler (sigaction equivalent).
        
        Args:
            signum: Signal number
            handler_addr: Handler function address (or SIG_DFL/SIG_IGN)
            flags: SA_* flags
            mask: Signal mask during handler
            
        Returns:
            Previous handler or None
        """
        old = self._handlers.get(signum)

        if handler_addr == 0:
            action = SignalAction.DEFAULT
        elif handler_addr == 1:
            action = SignalAction.IGNORE
        else:
            action = SignalAction.HANDLER

        self._handlers[signum] = SignalHandler(
            signum=signum,
            action=action,
            handler=handler_addr,
            flags=flags,
            mask=mask,
        )

        return old

    def on_signal(self, signum: int, callback: Callable) -> None:
        """
        Register Python callback for signal.
        
        Callback signature: callback(emulator, siginfo, context) -> bool
        Return True if handled, False to continue to next handler.
        """
        if signum not in self._callbacks:
            self._callbacks[signum] = []
        self._callbacks[signum].append(callback)

    def remove_callback(self, signum: int, callback: Callable) -> bool:
        """Remove signal callback."""
        if signum in self._callbacks:
            if callback in self._callbacks[signum]:
                self._callbacks[signum].remove(callback)
                return True
        return False

    def on_exception(self, callback: Callable) -> None:
        """
        Register global exception hook.
        
        Called for all exceptions before signal delivery.
        Callback: callback(emulator, signum, siginfo, context) -> bool
        """
        self._exception_hooks.append(callback)

    # ==================== Signal Mask ====================

    def block_signal(self, signum: int) -> None:
        """Block a signal."""
        self._sigmask |= (1 << signum)

    def unblock_signal(self, signum: int) -> None:
        """Unblock a signal."""
        self._sigmask &= ~(1 << signum)

    def is_blocked(self, signum: int) -> bool:
        """Check if signal is blocked."""
        return bool(self._sigmask & (1 << signum))

    def set_mask(self, mask: int) -> int:
        """Set signal mask, return old mask."""
        old = self._sigmask
        self._sigmask = mask
        return old

    def get_mask(self) -> int:
        """Get current signal mask."""
        return self._sigmask

    # ==================== Alternate Stack ====================

    def set_alt_stack(self, sp: int, size: int) -> None:
        """Set alternate signal stack."""
        self._alt_stack = (sp, size)

    def get_alt_stack(self) -> tuple[int, int] | None:
        """Get alternate signal stack."""
        return self._alt_stack

    # ==================== Signal Sending ====================

    def raise_signal(self, signum: int, addr: int = 0) -> bool:
        """
        Raise a signal (like kill()).
        
        Args:
            signum: Signal number
            addr: Fault address (for SIGSEGV/SIGBUS)
            
        Returns:
            True if handled
        """
        siginfo = SignalInfo(signo=signum, addr=addr)
        context = self._save_context()
        return self._deliver_signal(signum, siginfo, context)

    def queue_signal(self, signum: int, siginfo: SignalInfo) -> None:
        """Queue a signal for later delivery."""
        if not self.is_blocked(signum):
            self._pending.append((signum, siginfo))

    def deliver_pending(self) -> int:
        """Deliver all pending signals. Returns count delivered."""
        count = 0

        # Work on a copy to avoid infinite loop when all signals are blocked
        to_process = self._pending[:]
        self._pending = []

        for signum, siginfo in to_process:
            if self.is_blocked(signum):
                # Keep blocked signals pending
                self._pending.append((signum, siginfo))
                continue

            context = self._save_context()
            self._deliver_signal(signum, siginfo, context)
            count += 1

        return count

    # ==================== Utilities ====================

    def setup_sigreturn_trampoline(self) -> int:
        """
        Set up signal return trampoline.
        
        Returns the trampoline address.
        """
        # Allocate memory for trampoline
        addr = self.emulator.memory.alloc(0x100, aligned=0x1000)

        if self.is_64bit:
            # ARM64: mov x8, #139 (rt_sigreturn); svc #0
            code = bytes([
                0x68, 0x11, 0x80, 0xd2,  # mov x8, #139
                0x01, 0x00, 0x00, 0xd4,  # svc #0
            ])
        else:
            # ARM32: mov r7, #173 (rt_sigreturn); svc #0
            code = bytes([
                0xad, 0x70, 0xa0, 0xe3,  # mov r7, #173
                0x00, 0x00, 0x00, 0xef,  # svc #0
            ])

        self.emulator._uc.mem_write(addr, code)
        self._sigreturn_addr = addr

        return addr

    def print_stats(self) -> None:
        """Print exception statistics."""
        print("=== Exception Statistics ===")
        for key, value in self._stats.items():
            print(f"  {key}: {value}")

    def get_handler(self, signum: int) -> SignalHandler | None:
        """Get registered handler for signal."""
        return self._handlers.get(signum)

    def list_handlers(self) -> dict[int, SignalHandler]:
        """List all registered handlers."""
        return self._handlers.copy()
