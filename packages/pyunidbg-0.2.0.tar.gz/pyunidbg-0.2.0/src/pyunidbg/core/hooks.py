"""Hook management system for the emulator."""

from __future__ import annotations

import functools
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING, Any

from unicorn import (
    UC_HOOK_BLOCK,
    UC_HOOK_CODE,
    UC_HOOK_MEM_READ,
    UC_HOOK_MEM_WRITE,
    Uc,
)

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator


import logging

logger = logging.getLogger(__name__)


class HookAction(Enum):
    """Actions that can be returned from hook callbacks."""

    CONTINUE = auto()     # Continue normal execution
    SKIP = auto()         # Skip the hooked instruction/function
    STOP = auto()         # Stop emulation
    RETRY = auto()        # Retry the instruction (after modifying state)


class HookType(Enum):
    """Types of hooks supported."""

    CODE = auto()          # Hook on code execution
    BLOCK = auto()         # Hook on basic block entry
    FUNCTION = auto()      # Hook on function entry/exit
    ADDRESS = auto()       # Hook on specific address
    MEMORY_READ = auto()   # Hook on memory read
    MEMORY_WRITE = auto()  # Hook on memory write
    MEMORY_ACCESS = auto() # Hook on any memory access
    SYSCALL = auto()       # Hook on syscall
    INTERRUPT = auto()     # Hook on interrupt


@dataclass
class Hook:
    """Represents a registered hook."""

    hook_type: HookType
    callback: Callable
    address: int | None = None
    end_address: int | None = None
    name: str | None = None
    enabled: bool = True
    uc_handle: int | None = field(default=None, repr=False)
    priority: int = 0

    def __hash__(self):
        return id(self)


class HookManager:
    """
    Manages all hooks for the emulator.
    
    Provides decorators and methods for registering various types of hooks.
    """

    def __init__(self, emulator: Emulator):
        self._emulator = emulator
        self._uc: Uc = emulator._uc
        self._hooks: list[Hook] = []
        self._function_hooks: dict[str, list[Hook]] = {}  # name -> hooks
        self._address_hooks: dict[int, list[Hook]] = {}    # address -> hooks
        self._syscall_hooks: dict[int | str, list[Hook]] = {}  # syscall num/name -> hooks

        # Setup base hooks
        self._setup_base_hooks()

    def _setup_base_hooks(self) -> None:
        """Setup the base hooks needed for the hook system to work."""
        # We use a single code hook that dispatches to registered hooks
        self._uc.hook_add(
            UC_HOOK_CODE,
            self._code_hook_dispatcher,
            user_data=self,
        )

    def _code_hook_dispatcher(
        self,
        uc: Uc,
        address: int,
        size: int,
        user_data: Any,
    ) -> None:
        """Dispatch code hooks to registered callbacks."""
        # Check for address-specific hooks
        if address in self._address_hooks:
            for hook in self._address_hooks[address]:
                if hook.enabled:
                    try:
                        result = hook.callback(self._emulator, address, size)
                        if result == HookAction.STOP:
                            uc.emu_stop()
                            return
                        elif result == HookAction.SKIP:
                            # Skip instruction by advancing PC
                            self._emulator.cpu.pc = address + size
                            return
                    except Exception as e:
                        print(f"Hook error at {address:#x}: {e}")
                        raise

    def add_hook(self, hook: Hook) -> Hook:
        """Add a hook to the manager."""
        self._hooks.append(hook)

        if hook.address is not None:
            if hook.address not in self._address_hooks:
                self._address_hooks[hook.address] = []
            self._address_hooks[hook.address].append(hook)

        return hook

    def remove_hook(self, hook: Hook) -> None:
        """Remove a hook."""
        if hook in self._hooks:
            self._hooks.remove(hook)

        if hook.address is not None and hook.address in self._address_hooks:
            self._address_hooks[hook.address].remove(hook)
            if not self._address_hooks[hook.address]:
                del self._address_hooks[hook.address]

        if hook.uc_handle is not None:
            self._uc.hook_del(hook.uc_handle)

    # Decorator-style hook registration

    def address(self, addr: int, name: str | None = None):
        """
        Decorator to hook a specific address.
        
        Usage:
            @emu.hook.address(0x1234)
            def my_hook(emu, address, size):
                print(f"Hit {address:#x}")
        """
        def decorator(func: Callable) -> Callable:
            hook = Hook(
                hook_type=HookType.ADDRESS,
                callback=func,
                address=addr,
                name=name or func.__name__,
            )
            self.add_hook(hook)

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            wrapper._hook = hook
            return wrapper

        return decorator

    def function(self, name_or_addr: str | int):
        """
        Decorator to hook a function by name or address.
        
        Usage:
            @emu.hook.function("strlen")
            def hook_strlen(emu, address, args):
                print(f"strlen({emu.read_string(args[0])})")
                return HookAction.CONTINUE
        """
        def decorator(func: Callable) -> Callable:
            hook = Hook(
                hook_type=HookType.FUNCTION,
                callback=func,
                name=name_or_addr if isinstance(name_or_addr, str) else None,
                address=name_or_addr if isinstance(name_or_addr, int) else None,
            )

            if isinstance(name_or_addr, str):
                if name_or_addr not in self._function_hooks:
                    self._function_hooks[name_or_addr] = []
                self._function_hooks[name_or_addr].append(hook)
            else:
                self.add_hook(hook)

            self._hooks.append(hook)

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            wrapper._hook = hook
            return wrapper

        return decorator

    def syscall(self, name_or_num: str | int):
        """
        Decorator to hook a syscall.
        
        Usage:
            @emu.hook.syscall("open")
            def hook_open(emu, path, flags, mode):
                print(f"Opening: {path}")
                return HookAction.CONTINUE
        """
        def decorator(func: Callable) -> Callable:
            hook = Hook(
                hook_type=HookType.SYSCALL,
                callback=func,
                name=name_or_num if isinstance(name_or_num, str) else f"syscall_{name_or_num}",
            )

            if name_or_num not in self._syscall_hooks:
                self._syscall_hooks[name_or_num] = []
            self._syscall_hooks[name_or_num].append(hook)
            self._hooks.append(hook)

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            wrapper._hook = hook
            return wrapper

        return decorator

    def memory_read(self, start: int, end: int | None = None):
        """
        Decorator to hook memory reads in a range.
        
        Usage:
            @emu.hook.memory_read(0x1000, 0x2000)
            def on_read(emu, access, address, size, value):
                print(f"Read {size} bytes from {address:#x}")
        """
        def decorator(func: Callable) -> Callable:
            if end is None:
                size = 1
            else:
                size = end - start

            def mem_callback(uc, access, address, size, value, user_data):
                return func(self._emulator, access, address, size, value)

            handle = self._uc.hook_add(
                UC_HOOK_MEM_READ,
                mem_callback,
                begin=start,
                end=end or start + 1,
            )

            hook = Hook(
                hook_type=HookType.MEMORY_READ,
                callback=func,
                address=start,
                end_address=end,
                uc_handle=handle,
            )
            self._hooks.append(hook)

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            wrapper._hook = hook
            return wrapper

        return decorator

    def memory_write(self, start: int, end: int | None = None):
        """
        Decorator to hook memory writes in a range.
        """
        def decorator(func: Callable) -> Callable:
            def mem_callback(uc, access, address, size, value, user_data):
                return func(self._emulator, access, address, size, value)

            handle = self._uc.hook_add(
                UC_HOOK_MEM_WRITE,
                mem_callback,
                begin=start,
                end=end or start + 1,
            )

            hook = Hook(
                hook_type=HookType.MEMORY_WRITE,
                callback=func,
                address=start,
                end_address=end,
                uc_handle=handle,
            )
            self._hooks.append(hook)

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            wrapper._hook = hook
            return wrapper

        return decorator

    def block(self):
        """
        Decorator to hook basic block entry.
        """
        def decorator(func: Callable) -> Callable:
            def block_callback(uc, address, size, user_data):
                return func(self._emulator, address, size)

            handle = self._uc.hook_add(UC_HOOK_BLOCK, block_callback)

            hook = Hook(
                hook_type=HookType.BLOCK,
                callback=func,
                uc_handle=handle,
            )
            self._hooks.append(hook)

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return func(*args, **kwargs)

            wrapper._hook = hook
            return wrapper

        return decorator

    def get_function_hooks(self, name: str) -> list[Hook]:
        """Get all hooks registered for a function name."""
        return self._function_hooks.get(name, [])

    def get_syscall_hooks(self, name_or_num: str | int) -> list[Hook]:
        """Get all hooks registered for a syscall."""
        return self._syscall_hooks.get(name_or_num, [])

    def resolve_function_hook(self, address: int) -> None:
        """
        Called when a function address is resolved.
        Updates function hooks to also be address hooks.
        """
        # This would be called by the loader when it resolves symbols
        pass

    def enable_all(self) -> None:
        """Enable all hooks."""
        for hook in self._hooks:
            hook.enabled = True

    def disable_all(self) -> None:
        """Disable all hooks."""
        for hook in self._hooks:
            hook.enabled = False

    def list_hooks(self) -> list[Hook]:
        """Get all registered hooks."""
        return list(self._hooks)

    def clear(self) -> None:
        """Remove all hooks."""
        for hook in self._hooks[:]:
            self.remove_hook(hook)

        self._function_hooks.clear()
        self._address_hooks.clear()
        self._syscall_hooks.clear()

    # ==================== Convenience Methods ====================

    def add_code_hook(
        self,
        callback: Callable,
        start: int | None = None,
        end: int | None = None,
        name: str | None = None,
    ) -> Hook:
        """
        Add a code execution hook.
        
        Args:
            callback: Function to call (signature: callback(address, size))
            start: Start address (optional, for range hooks)
            end: End address (optional, for range hooks)
            name: Optional name for the hook
            
        Returns:
            The created Hook object
        """
        def code_callback(uc, address, size, user_data):
            callback(address, size)

        if start is not None and end is not None:
            handle = self._uc.hook_add(UC_HOOK_CODE, code_callback, begin=start, end=end)
        else:
            handle = self._uc.hook_add(UC_HOOK_CODE, code_callback)

        hook = Hook(
            hook_type=HookType.CODE,
            callback=callback,
            address=start,
            end_address=end,
            name=name,
            uc_handle=handle,
        )
        self._hooks.append(hook)
        return hook

    def add_breakpoint(
        self,
        address: int,
        callback: Callable[[int], bool],
        name: str | None = None,
    ) -> Hook:
        """
        Add a breakpoint at a specific address.
        
        Args:
            address: Address to break at
            callback: Function to call (signature: callback(address) -> bool)
                      Return True to continue, False to stop
            name: Optional name for the breakpoint
            
        Returns:
            The created Hook object
        """
        def bp_callback(emu, addr, size):
            if addr == address:
                result = callback(addr)
                if result is False:
                    return HookAction.STOP
            return HookAction.CONTINUE

        hook = Hook(
            hook_type=HookType.ADDRESS,
            callback=bp_callback,
            address=address,
            name=name or f"bp_{address:#x}",
        )
        return self.add_hook(hook)

    def add_trace_hook(
        self,
        start: int | None = None,
        end: int | None = None,
        callback: Callable | None = None,
    ) -> Hook:
        """
        Add a trace hook that logs all executed instructions.
        
        Args:
            start: Start address (optional)
            end: End address (optional)
            callback: Optional custom callback
            
        Returns:
            The created Hook object (call .remove() to stop tracing)
        """
        def default_trace(address, size):
            # Disassemble and print
            try:
                code = self._emulator.memory.read(address, size)
                for insn in self._emulator._cs.disasm(code, address):
                    print(f"0x{insn.address:x}: {insn.mnemonic} {insn.op_str}")
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                print(f"0x{address:x}: <unknown>")

        hook = self.add_code_hook(
            callback or default_trace,
            start=start,
            end=end,
            name="trace"
        )
        hook.remove = lambda: self.remove_hook(hook)
        return hook

