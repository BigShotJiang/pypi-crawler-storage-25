"""
Snapshot and Restore for PyUniDbg.

Save and restore complete emulator state including:
- All CPU registers
- Memory contents
- Hook configurations
- Emulator settings

Useful for:
- Debugging: Save state before risky operations
- Fuzzing: Quickly restore to known good state
- Analysis: Compare states before/after function calls

Usage:
    from pyunidbg import Emulator
    from pyunidbg.core import SnapshotManager
    
    emu = Emulator(arch='arm64')
    snapshots = SnapshotManager(emu)
    
    # Save state
    snap_id = snapshots.save("before_call")
    
    # ... do stuff ...
    
    # Restore state
    snapshots.restore(snap_id)
"""

import logging
import pickle
import struct
import time
import zlib
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING, Any, BinaryIO

if TYPE_CHECKING:
    from .emulator import Emulator

logger = logging.getLogger(__name__)


class SnapshotFlags(Enum):
    """Flags controlling what to include in snapshot."""
    REGISTERS = auto()      # CPU registers
    MEMORY = auto()         # Memory contents
    MEMORY_MAP = auto()     # Memory mapping info
    HOOKS = auto()          # Hook configurations
    SETTINGS = auto()       # Emulator settings
    ALL = auto()            # Everything


@dataclass
class MemoryRegion:
    """Snapshot of a memory region."""
    address: int
    size: int
    perms: int
    data: bytes
    compressed: bool = False

    def compress(self) -> 'MemoryRegion':
        """Return compressed version of this region."""
        if self.compressed:
            return self
        compressed_data = zlib.compress(self.data, level=6)
        # Only use compression if it actually saves space
        if len(compressed_data) < len(self.data):
            return MemoryRegion(
                address=self.address,
                size=self.size,
                perms=self.perms,
                data=compressed_data,
                compressed=True
            )
        return self

    def decompress(self) -> 'MemoryRegion':
        """Return decompressed version of this region."""
        if not self.compressed:
            return self
        return MemoryRegion(
            address=self.address,
            size=self.size,
            perms=self.perms,
            data=zlib.decompress(self.data),
            compressed=False
        )


@dataclass
class RegisterState:
    """Snapshot of CPU registers."""
    general: dict[int, int] = field(default_factory=dict)  # reg_id -> value
    pc: int = 0
    sp: int = 0
    flags: int = 0
    arch: str = "arm64"


@dataclass
class Snapshot:
    """Complete emulator state snapshot."""
    id: str
    name: str
    timestamp: float
    arch: str

    # State data
    registers: RegisterState | None = None
    memory_regions: list[MemoryRegion] = field(default_factory=list)
    memory_map: list[tuple[int, int, int]] = field(default_factory=list)  # (addr, size, perms)

    # Metadata
    description: str = ""
    tags: list[str] = field(default_factory=list)
    parent_id: str | None = None

    # Statistics
    total_memory_size: int = 0
    compressed_size: int = 0

    def get_size(self) -> int:
        """Get total snapshot size in bytes."""
        size = 0
        for region in self.memory_regions:
            size += len(region.data)
        return size


@dataclass
class SnapshotDiff:
    """Difference between two snapshots."""
    snapshot_a_id: str
    snapshot_b_id: str

    # Changed registers
    register_changes: dict[str, tuple[int, int]] = field(default_factory=dict)  # name -> (old, new)

    # Changed memory regions
    memory_changes: list[tuple[int, int, bytes, bytes]] = field(default_factory=list)  # (addr, size, old, new)

    # Added/removed memory
    added_regions: list[tuple[int, int]] = field(default_factory=list)
    removed_regions: list[tuple[int, int]] = field(default_factory=list)


class SnapshotManager:
    """
    Manages emulator state snapshots.
    
    Provides save, restore, and diff operations for complete
    emulator state preservation.
    """

    # Snapshot file magic
    MAGIC = b'PYUDBG01'
    VERSION = 1

    def __init__(
        self,
        emulator: 'Emulator',
        max_snapshots: int = 100,
        compress: bool = True
    ):
        """
        Initialize snapshot manager.
        
        Args:
            emulator: PyUniDbg emulator instance
            max_snapshots: Maximum snapshots to keep in memory
            compress: Whether to compress memory data
        """
        self.emulator = emulator
        self.max_snapshots = max_snapshots
        self.compress = compress

        # Snapshot storage
        self._snapshots: dict[str, Snapshot] = {}
        self._snapshot_order: list[str] = []  # For LRU eviction
        self._next_id = 1

        # Architecture info
        self._arch = getattr(emulator, 'arch', 'arm64')
        self._reg_ids = self._get_register_ids()

    def _get_register_ids(self) -> dict[str, int]:
        """Get register name to ID mapping for architecture."""
        try:
            if self._arch in ('arm64', 'aarch64'):
                from unicorn import arm64_const
                return {
                    'x0': arm64_const.UC_ARM64_REG_X0,
                    'x1': arm64_const.UC_ARM64_REG_X1,
                    'x2': arm64_const.UC_ARM64_REG_X2,
                    'x3': arm64_const.UC_ARM64_REG_X3,
                    'x4': arm64_const.UC_ARM64_REG_X4,
                    'x5': arm64_const.UC_ARM64_REG_X5,
                    'x6': arm64_const.UC_ARM64_REG_X6,
                    'x7': arm64_const.UC_ARM64_REG_X7,
                    'x8': arm64_const.UC_ARM64_REG_X8,
                    'x9': arm64_const.UC_ARM64_REG_X9,
                    'x10': arm64_const.UC_ARM64_REG_X10,
                    'x11': arm64_const.UC_ARM64_REG_X11,
                    'x12': arm64_const.UC_ARM64_REG_X12,
                    'x13': arm64_const.UC_ARM64_REG_X13,
                    'x14': arm64_const.UC_ARM64_REG_X14,
                    'x15': arm64_const.UC_ARM64_REG_X15,
                    'x16': arm64_const.UC_ARM64_REG_X16,
                    'x17': arm64_const.UC_ARM64_REG_X17,
                    'x18': arm64_const.UC_ARM64_REG_X18,
                    'x19': arm64_const.UC_ARM64_REG_X19,
                    'x20': arm64_const.UC_ARM64_REG_X20,
                    'x21': arm64_const.UC_ARM64_REG_X21,
                    'x22': arm64_const.UC_ARM64_REG_X22,
                    'x23': arm64_const.UC_ARM64_REG_X23,
                    'x24': arm64_const.UC_ARM64_REG_X24,
                    'x25': arm64_const.UC_ARM64_REG_X25,
                    'x26': arm64_const.UC_ARM64_REG_X26,
                    'x27': arm64_const.UC_ARM64_REG_X27,
                    'x28': arm64_const.UC_ARM64_REG_X28,
                    'x29': arm64_const.UC_ARM64_REG_X29,
                    'x30': arm64_const.UC_ARM64_REG_X30,
                    'sp': arm64_const.UC_ARM64_REG_SP,
                    'pc': arm64_const.UC_ARM64_REG_PC,
                    'nzcv': arm64_const.UC_ARM64_REG_NZCV,
                }
            elif self._arch in ('arm', 'arm32'):
                from unicorn import arm_const
                return {
                    'r0': arm_const.UC_ARM_REG_R0,
                    'r1': arm_const.UC_ARM_REG_R1,
                    'r2': arm_const.UC_ARM_REG_R2,
                    'r3': arm_const.UC_ARM_REG_R3,
                    'r4': arm_const.UC_ARM_REG_R4,
                    'r5': arm_const.UC_ARM_REG_R5,
                    'r6': arm_const.UC_ARM_REG_R6,
                    'r7': arm_const.UC_ARM_REG_R7,
                    'r8': arm_const.UC_ARM_REG_R8,
                    'r9': arm_const.UC_ARM_REG_R9,
                    'r10': arm_const.UC_ARM_REG_R10,
                    'r11': arm_const.UC_ARM_REG_R11,
                    'r12': arm_const.UC_ARM_REG_R12,
                    'sp': arm_const.UC_ARM_REG_SP,
                    'lr': arm_const.UC_ARM_REG_LR,
                    'pc': arm_const.UC_ARM_REG_PC,
                    'cpsr': arm_const.UC_ARM_REG_CPSR,
                }
        except ImportError:
            pass
        return {}

    @property
    def count(self) -> int:
        """Get number of stored snapshots."""
        return len(self._snapshots)

    @property
    def snapshots(self) -> list[Snapshot]:
        """Get list of all snapshots."""
        return list(self._snapshots.values())

    def save(
        self,
        name: str = "",
        description: str = "",
        tags: list[str] | None = None,
        include_memory: bool = True
    ) -> str:
        """
        Save current emulator state.
        
        Args:
            name: Optional snapshot name
            description: Optional description
            tags: Optional tags for categorization
            include_memory: Whether to include memory contents
            
        Returns:
            Snapshot ID
        """
        # Generate ID
        snap_id = f"snap_{self._next_id}"
        self._next_id += 1

        if not name:
            name = snap_id

        # Capture registers
        registers = self._capture_registers()

        # Capture memory
        memory_regions = []
        memory_map = []
        total_size = 0
        compressed_size = 0

        if include_memory:
            memory_regions, memory_map = self._capture_memory()
            for region in memory_regions:
                total_size += region.size
                compressed_size += len(region.data)

        # Create snapshot
        snapshot = Snapshot(
            id=snap_id,
            name=name,
            timestamp=time.time(),
            arch=self._arch,
            registers=registers,
            memory_regions=memory_regions,
            memory_map=memory_map,
            description=description,
            tags=tags or [],
            total_memory_size=total_size,
            compressed_size=compressed_size
        )

        # Store snapshot
        self._snapshots[snap_id] = snapshot
        self._snapshot_order.append(snap_id)

        # Evict old snapshots if needed
        self._evict_if_needed()

        logger.info(
            f"Saved snapshot '{name}' ({snap_id}): "
            f"{total_size} bytes memory, {len(registers.general)} registers"
        )

        return snap_id

    def restore(self, snapshot_id: str) -> bool:
        """
        Restore emulator state from snapshot.
        
        Args:
            snapshot_id: Snapshot ID to restore
            
        Returns:
            True if restored successfully
        """
        if snapshot_id not in self._snapshots:
            logger.error(f"Snapshot not found: {snapshot_id}")
            return False

        snapshot = self._snapshots[snapshot_id]

        # Restore registers
        if snapshot.registers:
            self._restore_registers(snapshot.registers)

        # Restore memory
        if snapshot.memory_regions:
            self._restore_memory(snapshot.memory_regions)

        # Update LRU order
        if snapshot_id in self._snapshot_order:
            self._snapshot_order.remove(snapshot_id)
            self._snapshot_order.append(snapshot_id)

        logger.info(f"Restored snapshot '{snapshot.name}' ({snapshot_id})")
        return True

    def delete(self, snapshot_id: str) -> bool:
        """
        Delete a snapshot.
        
        Args:
            snapshot_id: Snapshot ID to delete
            
        Returns:
            True if deleted
        """
        if snapshot_id not in self._snapshots:
            return False

        del self._snapshots[snapshot_id]
        if snapshot_id in self._snapshot_order:
            self._snapshot_order.remove(snapshot_id)

        logger.debug(f"Deleted snapshot {snapshot_id}")
        return True

    def get(self, snapshot_id: str) -> Snapshot | None:
        """Get snapshot by ID."""
        return self._snapshots.get(snapshot_id)

    def find_by_name(self, name: str) -> Snapshot | None:
        """Find snapshot by name."""
        for snapshot in self._snapshots.values():
            if snapshot.name == name:
                return snapshot
        return None

    def find_by_tag(self, tag: str) -> list[Snapshot]:
        """Find snapshots by tag."""
        return [s for s in self._snapshots.values() if tag in s.tags]

    def clear(self):
        """Clear all snapshots."""
        self._snapshots.clear()
        self._snapshot_order.clear()
        logger.debug("Cleared all snapshots")

    def diff(self, snapshot_a_id: str, snapshot_b_id: str) -> SnapshotDiff | None:
        """
        Compare two snapshots.
        
        Args:
            snapshot_a_id: First snapshot ID
            snapshot_b_id: Second snapshot ID
            
        Returns:
            SnapshotDiff or None if snapshots not found
        """
        snap_a = self._snapshots.get(snapshot_a_id)
        snap_b = self._snapshots.get(snapshot_b_id)

        if not snap_a or not snap_b:
            return None

        diff = SnapshotDiff(
            snapshot_a_id=snapshot_a_id,
            snapshot_b_id=snapshot_b_id
        )

        # Compare registers
        if snap_a.registers and snap_b.registers:
            for name, reg_id in self._reg_ids.items():
                val_a = snap_a.registers.general.get(reg_id, 0)
                val_b = snap_b.registers.general.get(reg_id, 0)
                if val_a != val_b:
                    diff.register_changes[name] = (val_a, val_b)

        # Compare memory (simplified - just compare regions at same address)
        regions_a = {r.address: r for r in snap_a.memory_regions}
        regions_b = {r.address: r for r in snap_b.memory_regions}

        all_addrs = set(regions_a.keys()) | set(regions_b.keys())

        for addr in all_addrs:
            if addr in regions_a and addr not in regions_b:
                diff.removed_regions.append((addr, regions_a[addr].size))
            elif addr not in regions_a and addr in regions_b:
                diff.added_regions.append((addr, regions_b[addr].size))
            else:
                # Both exist, compare data
                r_a = regions_a[addr].decompress()
                r_b = regions_b[addr].decompress()
                if r_a.data != r_b.data:
                    # Find actual changes
                    min_len = min(len(r_a.data), len(r_b.data))
                    for i in range(0, min_len, 4096):
                        chunk_a = r_a.data[i:i+4096]
                        chunk_b = r_b.data[i:i+4096]
                        if chunk_a != chunk_b:
                            diff.memory_changes.append((
                                addr + i,
                                min(4096, min_len - i),
                                chunk_a,
                                chunk_b
                            ))

        return diff

    def _capture_registers(self) -> RegisterState:
        """Capture current register state."""
        state = RegisterState(arch=self._arch)

        try:
            for name, reg_id in self._reg_ids.items():
                value = self.emulator.reg_read(reg_id)
                state.general[reg_id] = value

                if name == 'pc':
                    state.pc = value
                elif name == 'sp':
                    state.sp = value
                elif name in ('cpsr', 'nzcv'):
                    state.flags = value
        except Exception as e:
            logger.debug(f"Error capturing registers: {e}")

        return state

    def _restore_registers(self, state: RegisterState):
        """Restore register state."""
        try:
            for reg_id, value in state.general.items():
                self.emulator.reg_write(reg_id, value)
        except Exception as e:
            logger.error(f"Error restoring registers: {e}")

    def _capture_memory(self) -> tuple[list[MemoryRegion], list[tuple[int, int, int]]]:
        """Capture current memory state."""
        regions = []
        memory_map = []

        try:
            # Get memory regions from emulator
            uc = self.emulator._uc

            for region in uc.mem_regions():
                addr, end, perms = region
                size = end - addr + 1

                memory_map.append((addr, size, perms))

                # Read memory data
                try:
                    data = uc.mem_read(addr, size)
                    region = MemoryRegion(
                        address=addr,
                        size=size,
                        perms=perms,
                        data=bytes(data)
                    )

                    if self.compress:
                        region = region.compress()

                    regions.append(region)
                except Exception as e:
                    logger.debug(f"Could not read memory at 0x{addr:x}: {e}")

        except Exception as e:
            logger.error(f"Error capturing memory: {e}")

        return regions, memory_map

    def _restore_memory(self, regions: list[MemoryRegion]):
        """Restore memory state."""
        try:
            uc = self.emulator._uc

            for region in regions:
                decompressed = region.decompress()
                try:
                    uc.mem_write(decompressed.address, decompressed.data)
                except Exception as e:
                    logger.debug(f"Could not write memory at 0x{region.address:x}: {e}")

        except Exception as e:
            logger.error(f"Error restoring memory: {e}")

    def _evict_if_needed(self):
        """Evict oldest snapshots if over limit."""
        while len(self._snapshots) > self.max_snapshots:
            oldest_id = self._snapshot_order.pop(0)
            if oldest_id in self._snapshots:
                del self._snapshots[oldest_id]
                logger.debug(f"Evicted snapshot {oldest_id}")

    # === Serialization ===

    def save_to_file(self, snapshot_id: str, filename: str):
        """
        Save snapshot to file.
        
        Args:
            snapshot_id: Snapshot to save
            filename: Output filename
        """
        snapshot = self._snapshots.get(snapshot_id)
        if not snapshot:
            raise ValueError(f"Snapshot not found: {snapshot_id}")

        with open(filename, 'wb') as f:
            self._write_snapshot(f, snapshot)

        logger.info(f"Saved snapshot to {filename}")

    def load_from_file(self, filename: str) -> str:
        """
        Load snapshot from file.
        
        Args:
            filename: Input filename
            
        Returns:
            Loaded snapshot ID
        """
        with open(filename, 'rb') as f:
            snapshot = self._read_snapshot(f)

        # Generate new ID
        snap_id = f"snap_{self._next_id}"
        self._next_id += 1
        snapshot.id = snap_id

        self._snapshots[snap_id] = snapshot
        self._snapshot_order.append(snap_id)

        logger.info(f"Loaded snapshot from {filename} as {snap_id}")
        return snap_id

    def _write_snapshot(self, f: BinaryIO, snapshot: Snapshot):
        """Write snapshot to file."""
        # Magic and version
        f.write(self.MAGIC)
        f.write(struct.pack('<I', self.VERSION))

        # Serialize with pickle (simple but effective)
        data = pickle.dumps(snapshot)
        compressed = zlib.compress(data)

        f.write(struct.pack('<I', len(compressed)))
        f.write(compressed)

    def _read_snapshot(self, f: BinaryIO) -> Snapshot:
        """Read snapshot from file."""
        # Verify magic
        magic = f.read(8)
        if magic != self.MAGIC:
            raise ValueError("Invalid snapshot file format")

        version = struct.unpack('<I', f.read(4))[0]
        if version > self.VERSION:
            raise ValueError(f"Unsupported snapshot version: {version}")

        # Read and decompress
        size = struct.unpack('<I', f.read(4))[0]
        compressed = f.read(size)
        data = zlib.decompress(compressed)

        # SECURITY: pickle deserialization can execute arbitrary code — only use with trusted data
        logger.warning("Deserializing data via pickle — ensure source is trusted")
        return pickle.loads(data)

    def export_registers_json(self, snapshot_id: str) -> dict[str, Any]:
        """Export snapshot registers as JSON-compatible dict."""
        snapshot = self._snapshots.get(snapshot_id)
        if not snapshot or not snapshot.registers:
            return {}

        result = {
            'arch': snapshot.registers.arch,
            'pc': hex(snapshot.registers.pc),
            'sp': hex(snapshot.registers.sp),
            'flags': hex(snapshot.registers.flags),
            'registers': {}
        }

        # Reverse lookup for register names
        id_to_name = {v: k for k, v in self._reg_ids.items()}

        for reg_id, value in snapshot.registers.general.items():
            name = id_to_name.get(reg_id, f"reg_{reg_id}")
            result['registers'][name] = hex(value)

        return result


# Convenience functions
def create_snapshot_manager(emulator: 'Emulator', **kwargs) -> SnapshotManager:
    """Create a snapshot manager for the emulator."""
    return SnapshotManager(emulator, **kwargs)


class QuickSnapshot:
    """
    Context manager for quick save/restore operations.
    
    Usage:
        with QuickSnapshot(emu) as snap:
            # Do risky operations
            emu.call_function(dangerous_func)
        # State automatically restored
    """

    def __init__(self, emulator: 'Emulator', name: str = "quick"):
        self.emulator = emulator
        self.name = name
        self._manager: SnapshotManager | None = None
        self._snapshot_id: str | None = None

    def __enter__(self) -> 'QuickSnapshot':
        self._manager = SnapshotManager(self.emulator)
        self._snapshot_id = self._manager.save(self.name)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._manager and self._snapshot_id:
            self._manager.restore(self._snapshot_id)
        return False  # Don't suppress exceptions

    def commit(self):
        """Commit changes (don't restore on exit)."""
        self._snapshot_id = None
