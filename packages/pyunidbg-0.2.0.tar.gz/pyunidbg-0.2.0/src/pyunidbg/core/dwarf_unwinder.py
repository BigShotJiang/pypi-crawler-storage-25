"""
DWARF/EHFRAME Stack Unwinding - Enhanced stack unwinding with debug info.

Provides:
- DWARF CIE/FDE parsing
- EHFRAME (.eh_frame) section parsing
- CFI (Call Frame Information) interpretation
- DWARF expression evaluation
- Full exception handling frame support
"""

import logging
import struct
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, IntEnum, auto
from typing import Any

logger = logging.getLogger(__name__)


# ==================== DWARF CFI Opcodes ====================

class DwarfCFAOpcode(IntEnum):
    """DWARF Call Frame Instruction opcodes."""
    # Row creation
    DW_CFA_set_loc = 0x01
    DW_CFA_advance_loc1 = 0x02
    DW_CFA_advance_loc2 = 0x03
    DW_CFA_advance_loc4 = 0x04

    # Register rules
    DW_CFA_offset = 0x80  # High 2 bits (mask 0xC0 = 0x80)
    DW_CFA_offset_extended = 0x05
    DW_CFA_offset_extended_sf = 0x11
    DW_CFA_restore = 0xC0  # High 2 bits
    DW_CFA_restore_extended = 0x06
    DW_CFA_undefined = 0x07
    DW_CFA_same_value = 0x08
    DW_CFA_register = 0x09
    DW_CFA_val_offset = 0x14
    DW_CFA_val_offset_sf = 0x15
    DW_CFA_val_expression = 0x16
    DW_CFA_expression = 0x10

    # CFA definition
    DW_CFA_def_cfa = 0x0C
    DW_CFA_def_cfa_sf = 0x12
    DW_CFA_def_cfa_register = 0x0D
    DW_CFA_def_cfa_offset = 0x0E
    DW_CFA_def_cfa_offset_sf = 0x13
    DW_CFA_def_cfa_expression = 0x0F

    # State management
    DW_CFA_remember_state = 0x0A
    DW_CFA_restore_state = 0x0B

    # Padding
    DW_CFA_nop = 0x00

    # GNU extensions
    DW_CFA_GNU_args_size = 0x2E
    DW_CFA_GNU_negative_offset_extended = 0x2F


class RegisterRule(Enum):
    """DWARF register rule types."""
    UNDEFINED = auto()      # Register has no recoverable value
    SAME_VALUE = auto()     # Register unchanged from previous frame
    OFFSET = auto()         # Value stored at CFA + offset
    VAL_OFFSET = auto()     # Value is CFA + offset (no memory access)
    REGISTER = auto()       # Value is in another register
    EXPRESSION = auto()     # Value computed by DWARF expression
    VAL_EXPRESSION = auto() # Value is result of expression (no memory access)
    ARCHITECTURAL = auto()  # Return address column


@dataclass
class RegisterState:
    """State of a register in unwind table."""
    rule: RegisterRule = RegisterRule.UNDEFINED
    offset: int = 0
    register: int = 0
    expression: bytes = b''


@dataclass
class CFARule:
    """CFA (Canonical Frame Address) definition."""
    register: int = 0  # Base register (usually SP or FP)
    offset: int = 0    # Offset from base register
    expression: bytes = b''
    is_expression: bool = False


@dataclass
class UnwindRow:
    """A row in the unwind table."""
    location: int = 0
    cfa: CFARule = field(default_factory=CFARule)
    registers: dict[int, RegisterState] = field(default_factory=dict)

    def copy(self) -> 'UnwindRow':
        """Create a deep copy of this row."""
        new_row = UnwindRow(
            location=self.location,
            cfa=CFARule(
                register=self.cfa.register,
                offset=self.cfa.offset,
                expression=self.cfa.expression,
                is_expression=self.cfa.is_expression
            ),
            registers={k: RegisterState(
                rule=v.rule,
                offset=v.offset,
                register=v.register,
                expression=v.expression
            ) for k, v in self.registers.items()}
        )
        return new_row


# ==================== CIE/FDE Structures ====================

@dataclass
class CIE:
    """Common Information Entry."""
    length: int
    cie_id: int
    version: int
    augmentation: str
    code_alignment: int
    data_alignment: int
    return_address_column: int
    initial_instructions: bytes

    # Augmentation data
    lsda_encoding: int = 0
    fde_encoding: int = 0
    personality_routine: int = 0
    signal_frame: bool = False

    # Parsed initial state
    initial_row: UnwindRow = field(default_factory=UnwindRow)


@dataclass
class FDE:
    """Frame Description Entry."""
    length: int
    cie_pointer: int
    pc_begin: int
    pc_range: int
    instructions: bytes

    # Associated CIE
    cie: CIE | None = None

    # Augmentation data
    lsda: int = 0


# ==================== DWARF Expression Evaluator ====================

class DwarfExpressionOp(IntEnum):
    """DWARF expression opcodes (subset)."""
    DW_OP_addr = 0x03
    DW_OP_deref = 0x06
    DW_OP_const1u = 0x08
    DW_OP_const1s = 0x09
    DW_OP_const2u = 0x0A
    DW_OP_const2s = 0x0B
    DW_OP_const4u = 0x0C
    DW_OP_const4s = 0x0D
    DW_OP_const8u = 0x0E
    DW_OP_const8s = 0x0F
    DW_OP_constu = 0x10
    DW_OP_consts = 0x11
    DW_OP_dup = 0x12
    DW_OP_drop = 0x13
    DW_OP_over = 0x14
    DW_OP_pick = 0x15
    DW_OP_swap = 0x16
    DW_OP_rot = 0x17
    DW_OP_xderef = 0x18
    DW_OP_abs = 0x19
    DW_OP_and = 0x1A
    DW_OP_div = 0x1B
    DW_OP_minus = 0x1C
    DW_OP_mod = 0x1D
    DW_OP_mul = 0x1E
    DW_OP_neg = 0x1F
    DW_OP_not = 0x20
    DW_OP_or = 0x21
    DW_OP_plus = 0x22
    DW_OP_plus_uconst = 0x23
    DW_OP_shl = 0x24
    DW_OP_shr = 0x25
    DW_OP_shra = 0x26
    DW_OP_xor = 0x27
    DW_OP_bra = 0x28
    DW_OP_eq = 0x29
    DW_OP_ge = 0x2A
    DW_OP_gt = 0x2B
    DW_OP_le = 0x2C
    DW_OP_lt = 0x2D
    DW_OP_ne = 0x2E
    DW_OP_skip = 0x2F
    DW_OP_lit0 = 0x30
    # DW_OP_lit1-31 = 0x31-0x4F
    DW_OP_reg0 = 0x50
    # DW_OP_reg1-31 = 0x51-0x6F
    DW_OP_breg0 = 0x70
    # DW_OP_breg1-31 = 0x71-0x8F
    DW_OP_regx = 0x90
    DW_OP_fbreg = 0x91
    DW_OP_bregx = 0x92
    DW_OP_piece = 0x93
    DW_OP_deref_size = 0x94
    DW_OP_xderef_size = 0x95
    DW_OP_nop = 0x96
    DW_OP_call_frame_cfa = 0x9C
    DW_OP_stack_value = 0x9F


class DwarfExpressionEvaluator:
    """
    Evaluates DWARF expressions.
    
    Used for computing register values and CFA from expressions.
    """

    def __init__(self, is_64bit: bool = True,
                 memory_reader: Callable[[int, int], bytes] = None,
                 register_reader: Callable[[int], int] = None,
                 cfa: int = 0):
        self.is_64bit = is_64bit
        self.ptr_size = 8 if is_64bit else 4
        self.memory_reader = memory_reader
        self.register_reader = register_reader
        self.cfa = cfa

    def evaluate(self, expression: bytes, initial_value: int = 0) -> int:
        """
        Evaluate a DWARF expression.
        
        Args:
            expression: DWARF expression bytecode
            initial_value: Optional initial value on stack
            
        Returns:
            Result value
        """
        stack: list[int] = []
        if initial_value:
            stack.append(initial_value)

        offset = 0
        while offset < len(expression):
            opcode = expression[offset]
            offset += 1

            # DW_OP_lit0-31
            if 0x30 <= opcode <= 0x4F:
                stack.append(opcode - 0x30)
                continue

            # DW_OP_reg0-31
            if 0x50 <= opcode <= 0x6F:
                reg_num = opcode - 0x50
                if self.register_reader:
                    stack.append(self.register_reader(reg_num))
                else:
                    stack.append(0)
                continue

            # DW_OP_breg0-31
            if 0x70 <= opcode <= 0x8F:
                reg_num = opcode - 0x70
                sleb_offset, size = self._read_sleb128(expression[offset:])
                offset += size
                if self.register_reader:
                    stack.append(self.register_reader(reg_num) + sleb_offset)
                else:
                    stack.append(sleb_offset)
                continue

            # Handle opcodes
            if opcode == DwarfExpressionOp.DW_OP_addr:
                if self.is_64bit:
                    addr = struct.unpack('<Q', expression[offset:offset+8])[0]
                    offset += 8
                else:
                    addr = struct.unpack('<I', expression[offset:offset+4])[0]
                    offset += 4
                stack.append(addr)

            elif opcode == DwarfExpressionOp.DW_OP_deref:
                if stack and self.memory_reader:
                    addr = stack.pop()
                    data = self.memory_reader(addr, self.ptr_size)
                    if self.is_64bit:
                        stack.append(struct.unpack('<Q', data)[0])
                    else:
                        stack.append(struct.unpack('<I', data)[0])

            elif opcode == DwarfExpressionOp.DW_OP_deref_size:
                size = expression[offset]
                offset += 1
                if stack and self.memory_reader:
                    addr = stack.pop()
                    data = self.memory_reader(addr, size)
                    value = int.from_bytes(data, 'little')
                    stack.append(value)

            elif opcode == DwarfExpressionOp.DW_OP_const1u:
                stack.append(expression[offset])
                offset += 1

            elif opcode == DwarfExpressionOp.DW_OP_const1s:
                stack.append(struct.unpack('b', bytes([expression[offset]]))[0])
                offset += 1

            elif opcode == DwarfExpressionOp.DW_OP_const2u:
                stack.append(struct.unpack('<H', expression[offset:offset+2])[0])
                offset += 2

            elif opcode == DwarfExpressionOp.DW_OP_const2s:
                stack.append(struct.unpack('<h', expression[offset:offset+2])[0])
                offset += 2

            elif opcode == DwarfExpressionOp.DW_OP_const4u:
                stack.append(struct.unpack('<I', expression[offset:offset+4])[0])
                offset += 4

            elif opcode == DwarfExpressionOp.DW_OP_const4s:
                stack.append(struct.unpack('<i', expression[offset:offset+4])[0])
                offset += 4

            elif opcode == DwarfExpressionOp.DW_OP_const8u:
                stack.append(struct.unpack('<Q', expression[offset:offset+8])[0])
                offset += 8

            elif opcode == DwarfExpressionOp.DW_OP_const8s:
                stack.append(struct.unpack('<q', expression[offset:offset+8])[0])
                offset += 8

            elif opcode == DwarfExpressionOp.DW_OP_constu:
                value, size = self._read_uleb128(expression[offset:])
                offset += size
                stack.append(value)

            elif opcode == DwarfExpressionOp.DW_OP_consts:
                value, size = self._read_sleb128(expression[offset:])
                offset += size
                stack.append(value)

            elif opcode == DwarfExpressionOp.DW_OP_dup:
                if stack:
                    stack.append(stack[-1])

            elif opcode == DwarfExpressionOp.DW_OP_drop:
                if stack:
                    stack.pop()

            elif opcode == DwarfExpressionOp.DW_OP_over:
                if len(stack) >= 2:
                    stack.append(stack[-2])

            elif opcode == DwarfExpressionOp.DW_OP_pick:
                idx = expression[offset]
                offset += 1
                if len(stack) > idx:
                    stack.append(stack[-(idx + 1)])

            elif opcode == DwarfExpressionOp.DW_OP_swap:
                if len(stack) >= 2:
                    stack[-1], stack[-2] = stack[-2], stack[-1]

            elif opcode == DwarfExpressionOp.DW_OP_rot:
                # Rotate: first (top) -> third, second -> first (new top), third -> second
                # Stack [1, 2, 3] with 3 on top becomes [2, 3, 1] with 1 on top
                if len(stack) >= 3:
                    first = stack[-1]   # top (3)
                    second = stack[-2]  # (2)
                    third = stack[-3]   # (1)
                    stack[-3] = second  # second becomes third position
                    stack[-2] = first   # first becomes second position
                    stack[-1] = third   # third becomes first (top)

            elif opcode == DwarfExpressionOp.DW_OP_plus:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(a + b)

            elif opcode == DwarfExpressionOp.DW_OP_plus_uconst:
                value, size = self._read_uleb128(expression[offset:])
                offset += size
                if stack:
                    stack[-1] += value

            elif opcode == DwarfExpressionOp.DW_OP_minus:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(a - b)

            elif opcode == DwarfExpressionOp.DW_OP_mul:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(a * b)

            elif opcode == DwarfExpressionOp.DW_OP_div:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    if b != 0:
                        stack.append(a // b)
                    else:
                        stack.append(0)

            elif opcode == DwarfExpressionOp.DW_OP_mod:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    if b != 0:
                        stack.append(a % b)
                    else:
                        stack.append(0)

            elif opcode == DwarfExpressionOp.DW_OP_neg:
                if stack:
                    stack[-1] = -stack[-1]

            elif opcode == DwarfExpressionOp.DW_OP_abs:
                if stack:
                    stack[-1] = abs(stack[-1])

            elif opcode == DwarfExpressionOp.DW_OP_and:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(a & b)

            elif opcode == DwarfExpressionOp.DW_OP_or:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(a | b)

            elif opcode == DwarfExpressionOp.DW_OP_xor:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(a ^ b)

            elif opcode == DwarfExpressionOp.DW_OP_not:
                if stack:
                    stack[-1] = ~stack[-1]

            elif opcode == DwarfExpressionOp.DW_OP_shl:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(a << b)

            elif opcode == DwarfExpressionOp.DW_OP_shr:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(a >> b)

            elif opcode == DwarfExpressionOp.DW_OP_shra:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    # Arithmetic shift right (sign-extending)
                    if self.is_64bit:
                        if a & (1 << 63):
                            # Negative, sign extend
                            stack.append((a >> b) | (~((1 << (64 - b)) - 1)))
                        else:
                            stack.append(a >> b)
                    else:
                        if a & (1 << 31):
                            stack.append((a >> b) | (~((1 << (32 - b)) - 1)))
                        else:
                            stack.append(a >> b)

            elif opcode == DwarfExpressionOp.DW_OP_call_frame_cfa:
                stack.append(self.cfa)

            elif opcode == DwarfExpressionOp.DW_OP_fbreg:
                sleb_offset, size = self._read_sleb128(expression[offset:])
                offset += size
                stack.append(self.cfa + sleb_offset)

            elif opcode == DwarfExpressionOp.DW_OP_bregx:
                reg, size1 = self._read_uleb128(expression[offset:])
                offset += size1
                sleb_offset, size2 = self._read_sleb128(expression[offset:])
                offset += size2
                if self.register_reader:
                    stack.append(self.register_reader(reg) + sleb_offset)
                else:
                    stack.append(sleb_offset)

            elif opcode == DwarfExpressionOp.DW_OP_regx:
                reg, size = self._read_uleb128(expression[offset:])
                offset += size
                if self.register_reader:
                    stack.append(self.register_reader(reg))
                else:
                    stack.append(0)

            # Comparison ops
            elif opcode == DwarfExpressionOp.DW_OP_eq:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(1 if a == b else 0)

            elif opcode == DwarfExpressionOp.DW_OP_ne:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(1 if a != b else 0)

            elif opcode == DwarfExpressionOp.DW_OP_lt:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(1 if a < b else 0)

            elif opcode == DwarfExpressionOp.DW_OP_le:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(1 if a <= b else 0)

            elif opcode == DwarfExpressionOp.DW_OP_gt:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(1 if a > b else 0)

            elif opcode == DwarfExpressionOp.DW_OP_ge:
                if len(stack) >= 2:
                    b = stack.pop()
                    a = stack.pop()
                    stack.append(1 if a >= b else 0)

            # Branch ops
            elif opcode == DwarfExpressionOp.DW_OP_skip:
                skip = struct.unpack('<h', expression[offset:offset+2])[0]
                offset += 2 + skip

            elif opcode == DwarfExpressionOp.DW_OP_bra:
                skip = struct.unpack('<h', expression[offset:offset+2])[0]
                offset += 2
                if stack and stack.pop() != 0:
                    offset += skip

            elif opcode == DwarfExpressionOp.DW_OP_nop:
                pass

            elif opcode == DwarfExpressionOp.DW_OP_stack_value:
                # Result is the value on top of stack (no dereference)
                pass

            elif opcode == DwarfExpressionOp.DW_OP_piece:
                # Skip piece size (used for composite locations)
                _, size = self._read_uleb128(expression[offset:])
                offset += size

        return stack[-1] if stack else 0

    def _read_uleb128(self, data: bytes) -> tuple[int, int]:
        """Read unsigned LEB128."""
        result = 0
        shift = 0
        size = 0

        for byte in data:
            size += 1
            result |= (byte & 0x7F) << shift
            if (byte & 0x80) == 0:
                break
            shift += 7

        return result, size

    def _read_sleb128(self, data: bytes) -> tuple[int, int]:
        """Read signed LEB128."""
        result = 0
        shift = 0
        size = 0

        for byte in data:
            size += 1
            result |= (byte & 0x7F) << shift
            shift += 7
            if (byte & 0x80) == 0:
                if byte & 0x40:
                    result |= -(1 << shift)
                break

        return result, size


# ==================== EHFRAME Parser ====================

class EHFrameParser:
    """
    Parser for .eh_frame and .debug_frame sections.
    
    Parses DWARF Call Frame Information (CFI) entries.
    """

    def __init__(self, data: bytes, base_address: int = 0,
                 is_64bit: bool = True, is_eh_frame: bool = True):
        self.data = data
        self.base_address = base_address
        self.is_64bit = is_64bit
        self.is_eh_frame = is_eh_frame  # .eh_frame vs .debug_frame

        self.cies: dict[int, CIE] = {}
        self.fdes: list[FDE] = []

    def parse(self) -> tuple[dict[int, CIE], list[FDE]]:
        """
        Parse the frame section.
        
        Returns:
            (CIE dict, FDE list)
        """
        offset = 0

        while offset < len(self.data):
            entry_offset = offset

            # Read length
            length = struct.unpack('<I', self.data[offset:offset+4])[0]
            offset += 4

            if length == 0:
                # End of entries
                break

            if length == 0xFFFFFFFF:
                # 64-bit length
                length = struct.unpack('<Q', self.data[offset:offset+8])[0]
                offset += 8

            entry_end = offset + length

            # Read CIE ID / CIE pointer
            if length < 4:
                offset = entry_end
                continue

            cie_id = struct.unpack('<I', self.data[offset:offset+4])[0]
            offset += 4

            if self.is_eh_frame:
                is_cie = (cie_id == 0)
            else:
                is_cie = (cie_id == 0xFFFFFFFF)

            if is_cie:
                cie = self._parse_cie(offset, entry_end, entry_offset)
                if cie:
                    self.cies[entry_offset] = cie
            else:
                fde = self._parse_fde(offset, entry_end, cie_id, entry_offset)
                if fde:
                    self.fdes.append(fde)

            offset = entry_end

        return self.cies, self.fdes

    def _parse_cie(self, offset: int, end: int, cie_offset: int) -> CIE | None:
        """Parse a CIE entry."""
        try:
            version = self.data[offset]
            offset += 1

            # Read augmentation string
            aug_end = self.data.index(0, offset)
            augmentation = self.data[offset:aug_end].decode('ascii', errors='ignore')
            offset = aug_end + 1

            # Check version
            if version not in (1, 3, 4):
                logger.warning(f"Unsupported CIE version: {version}")
                return None

            # Version 4 has address_size and segment_selector_size
            if version == 4:
                offset += 2  # Skip address_size, segment_selector_size

            # Read code alignment
            code_alignment, size = self._read_uleb128(offset)
            offset += size

            # Read data alignment (signed)
            data_alignment, size = self._read_sleb128(offset)
            offset += size

            # Return address column
            if version == 1:
                return_address_column = self.data[offset]
                offset += 1
            else:
                return_address_column, size = self._read_uleb128(offset)
                offset += size

            cie = CIE(
                length=end - cie_offset - 4,
                cie_id=0,
                version=version,
                augmentation=augmentation,
                code_alignment=code_alignment,
                data_alignment=data_alignment,
                return_address_column=return_address_column,
                initial_instructions=b'',
            )

            # Parse augmentation data
            if 'z' in augmentation:
                aug_length, size = self._read_uleb128(offset)
                offset += size
                aug_end = offset + aug_length

                for char in augmentation[1:]:  # Skip 'z'
                    if char == 'L':
                        cie.lsda_encoding = self.data[offset]
                        offset += 1
                    elif char == 'P':
                        encoding = self.data[offset]
                        offset += 1
                        cie.personality_routine, size = self._read_encoded_ptr(
                            offset, encoding
                        )
                        offset += size
                    elif char == 'R':
                        cie.fde_encoding = self.data[offset]
                        offset += 1
                    elif char == 'S':
                        cie.signal_frame = True

                offset = aug_end

            # Remaining bytes are initial instructions
            cie.initial_instructions = self.data[offset:end]

            return cie

        except Exception as e:
            logger.debug(f"Failed to parse CIE: {e}")
            return None

    def _parse_fde(self, offset: int, end: int, cie_pointer: int,
                   fde_offset: int) -> FDE | None:
        """Parse an FDE entry."""
        try:
            # Find the CIE
            if self.is_eh_frame:
                cie_offset = fde_offset + 4 - cie_pointer
            else:
                cie_offset = cie_pointer

            cie = self.cies.get(cie_offset)
            if not cie:
                logger.debug(f"FDE references unknown CIE at 0x{cie_offset:x}")
                return None

            # Read PC begin and range
            encoding = cie.fde_encoding if cie.fde_encoding else 0x1B  # Default: sdata4 + pcrel

            pc_begin, size = self._read_encoded_ptr(offset, encoding, fde_offset)
            offset += size

            # PC range uses same encoding but without pcrel
            range_encoding = encoding & 0x0F
            pc_range, size = self._read_encoded_ptr(offset, range_encoding)
            offset += size

            fde = FDE(
                length=end - fde_offset - 4,
                cie_pointer=cie_pointer,
                pc_begin=pc_begin + self.base_address,
                pc_range=pc_range,
                instructions=b'',
                cie=cie,
            )

            # Augmentation data
            if 'z' in cie.augmentation:
                aug_length, size = self._read_uleb128(offset)
                offset += size
                aug_end = offset + aug_length

                if 'L' in cie.augmentation and cie.lsda_encoding:
                    fde.lsda, size = self._read_encoded_ptr(
                        offset, cie.lsda_encoding, fde_offset
                    )
                    offset += size

                offset = aug_end

            fde.instructions = self.data[offset:end]

            return fde

        except Exception as e:
            logger.debug(f"Failed to parse FDE: {e}")
            return None

    def _read_uleb128(self, offset: int) -> tuple[int, int]:
        """Read ULEB128 at offset."""
        result = 0
        shift = 0
        size = 0

        while True:
            byte = self.data[offset + size]
            size += 1
            result |= (byte & 0x7F) << shift
            if (byte & 0x80) == 0:
                break
            shift += 7

        return result, size

    def _read_sleb128(self, offset: int) -> tuple[int, int]:
        """Read SLEB128 at offset."""
        result = 0
        shift = 0
        size = 0

        while True:
            byte = self.data[offset + size]
            size += 1
            result |= (byte & 0x7F) << shift
            shift += 7
            if (byte & 0x80) == 0:
                if byte & 0x40:
                    result |= -(1 << shift)
                break

        return result, size

    def _read_encoded_ptr(self, offset: int, encoding: int,
                          pc_rel_base: int = 0) -> tuple[int, int]:
        """Read an encoded pointer value."""
        if encoding == 0xFF:  # DW_EH_PE_omit
            return 0, 0

        # Value format (low 4 bits)
        fmt = encoding & 0x0F

        if fmt == 0x00:  # DW_EH_PE_absptr
            if self.is_64bit:
                value = struct.unpack('<Q', self.data[offset:offset+8])[0]
                size = 8
            else:
                value = struct.unpack('<I', self.data[offset:offset+4])[0]
                size = 4
        elif fmt == 0x01:  # DW_EH_PE_uleb128
            value, size = self._read_uleb128(offset)
        elif fmt == 0x02:  # DW_EH_PE_udata2
            value = struct.unpack('<H', self.data[offset:offset+2])[0]
            size = 2
        elif fmt == 0x03:  # DW_EH_PE_udata4
            value = struct.unpack('<I', self.data[offset:offset+4])[0]
            size = 4
        elif fmt == 0x04:  # DW_EH_PE_udata8
            value = struct.unpack('<Q', self.data[offset:offset+8])[0]
            size = 8
        elif fmt == 0x09:  # DW_EH_PE_sleb128
            value, size = self._read_sleb128(offset)
        elif fmt == 0x0A:  # DW_EH_PE_sdata2
            value = struct.unpack('<h', self.data[offset:offset+2])[0]
            size = 2
        elif fmt == 0x0B:  # DW_EH_PE_sdata4
            value = struct.unpack('<i', self.data[offset:offset+4])[0]
            size = 4
        elif fmt == 0x0C:  # DW_EH_PE_sdata8
            value = struct.unpack('<q', self.data[offset:offset+8])[0]
            size = 8
        else:
            return 0, 0

        # Application (high 4 bits)
        app = encoding & 0x70

        if app == 0x10:  # DW_EH_PE_pcrel
            value += pc_rel_base + offset
        elif app == 0x20:  # DW_EH_PE_textrel
            pass  # Would need text section base
        elif app == 0x30:  # DW_EH_PE_datarel
            pass  # Would need data section base
        elif app == 0x40:  # DW_EH_PE_funcrel
            pass  # Would need function base
        elif app == 0x50:  # DW_EH_PE_aligned
            pass  # Would need alignment handling

        return value, size

    def find_fde(self, address: int) -> FDE | None:
        """Find FDE covering the given address."""
        for fde in self.fdes:
            if fde.pc_begin <= address < fde.pc_begin + fde.pc_range:
                return fde
        return None


# ==================== CFI Interpreter ====================

class CFIInterpreter:
    """
    Interprets DWARF CFI (Call Frame Information) instructions.
    
    Builds unwind table from CIE/FDE instructions.
    """

    def __init__(self, cie: CIE, is_64bit: bool = True):
        self.cie = cie
        self.is_64bit = is_64bit
        self.code_alignment = cie.code_alignment
        self.data_alignment = cie.data_alignment

        # Current row being built
        self.current_row = UnwindRow()

        # Stack for remember/restore
        self.state_stack: list[UnwindRow] = []

        # Rows collected
        self.rows: list[UnwindRow] = []

    def interpret_cie(self) -> UnwindRow:
        """
        Interpret CIE initial instructions.
        
        Returns:
            Initial unwind row
        """
        self.current_row = UnwindRow()
        self._interpret(self.cie.initial_instructions, 0)
        return self.current_row.copy()

    def interpret_fde(self, fde: FDE, target_pc: int) -> UnwindRow | None:
        """
        Interpret FDE instructions up to target PC.
        
        Args:
            fde: FDE to interpret
            target_pc: PC to unwind at
            
        Returns:
            Unwind row for target PC, or None if not found
        """
        # Start with CIE initial row
        self.current_row = self.interpret_cie()
        self.current_row.location = fde.pc_begin
        self.rows = [self.current_row.copy()]
        self.state_stack = []

        # Interpret FDE instructions
        self._interpret(fde.instructions, fde.pc_begin)

        # Find row for target PC
        result = None
        for row in self.rows:
            if row.location <= target_pc:
                result = row
            else:
                break

        return result

    def _interpret(self, instructions: bytes, start_location: int) -> None:
        """Interpret CFI instructions."""
        offset = 0
        location = start_location

        while offset < len(instructions):
            opcode = instructions[offset]
            offset += 1

            # High 2 bits determine instruction class
            high_bits = opcode & 0xC0

            if high_bits == 0x40:  # DW_CFA_advance_loc (inline delta)
                delta = opcode & 0x3F
                location += delta * self.code_alignment
                self.current_row.location = location
                self.rows.append(self.current_row.copy())

            elif high_bits == 0x80:  # DW_CFA_offset (inline register)
                register = opcode & 0x3F
                factored_offset, size = self._read_uleb128(instructions[offset:])
                offset += size
                self.current_row.registers[register] = RegisterState(
                    rule=RegisterRule.OFFSET,
                    offset=factored_offset * self.data_alignment
                )

            elif high_bits == 0xC0:  # DW_CFA_restore (inline register)
                register = opcode & 0x3F
                # Restore to initial rule from CIE
                initial_row = self.interpret_cie()
                if register in initial_row.registers:
                    self.current_row.registers[register] = initial_row.registers[register]
                else:
                    self.current_row.registers.pop(register, None)

            elif opcode == DwarfCFAOpcode.DW_CFA_nop:
                pass

            elif opcode == DwarfCFAOpcode.DW_CFA_set_loc:
                if self.is_64bit:
                    location = struct.unpack('<Q', instructions[offset:offset+8])[0]
                    offset += 8
                else:
                    location = struct.unpack('<I', instructions[offset:offset+4])[0]
                    offset += 4
                self.current_row.location = location
                self.rows.append(self.current_row.copy())

            elif opcode == DwarfCFAOpcode.DW_CFA_advance_loc1:
                delta = instructions[offset]
                offset += 1
                location += delta * self.code_alignment
                self.current_row.location = location
                self.rows.append(self.current_row.copy())

            elif opcode == DwarfCFAOpcode.DW_CFA_advance_loc2:
                delta = struct.unpack('<H', instructions[offset:offset+2])[0]
                offset += 2
                location += delta * self.code_alignment
                self.current_row.location = location
                self.rows.append(self.current_row.copy())

            elif opcode == DwarfCFAOpcode.DW_CFA_advance_loc4:
                delta = struct.unpack('<I', instructions[offset:offset+4])[0]
                offset += 4
                location += delta * self.code_alignment
                self.current_row.location = location
                self.rows.append(self.current_row.copy())

            elif opcode == DwarfCFAOpcode.DW_CFA_def_cfa:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                cfa_offset, size = self._read_uleb128(instructions[offset:])
                offset += size
                self.current_row.cfa = CFARule(
                    register=register,
                    offset=cfa_offset,
                    is_expression=False
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_def_cfa_sf:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                factored_offset, size = self._read_sleb128(instructions[offset:])
                offset += size
                self.current_row.cfa = CFARule(
                    register=register,
                    offset=factored_offset * self.data_alignment,
                    is_expression=False
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_def_cfa_register:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                self.current_row.cfa.register = register
                self.current_row.cfa.is_expression = False

            elif opcode == DwarfCFAOpcode.DW_CFA_def_cfa_offset:
                cfa_offset, size = self._read_uleb128(instructions[offset:])
                offset += size
                self.current_row.cfa.offset = cfa_offset
                self.current_row.cfa.is_expression = False

            elif opcode == DwarfCFAOpcode.DW_CFA_def_cfa_offset_sf:
                factored_offset, size = self._read_sleb128(instructions[offset:])
                offset += size
                self.current_row.cfa.offset = factored_offset * self.data_alignment
                self.current_row.cfa.is_expression = False

            elif opcode == DwarfCFAOpcode.DW_CFA_def_cfa_expression:
                length, size = self._read_uleb128(instructions[offset:])
                offset += size
                expression = instructions[offset:offset+length]
                offset += length
                self.current_row.cfa = CFARule(
                    expression=expression,
                    is_expression=True
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_offset_extended:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                factored_offset, size = self._read_uleb128(instructions[offset:])
                offset += size
                self.current_row.registers[register] = RegisterState(
                    rule=RegisterRule.OFFSET,
                    offset=factored_offset * self.data_alignment
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_offset_extended_sf:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                factored_offset, size = self._read_sleb128(instructions[offset:])
                offset += size
                self.current_row.registers[register] = RegisterState(
                    rule=RegisterRule.OFFSET,
                    offset=factored_offset * self.data_alignment
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_restore_extended:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                initial_row = self.interpret_cie()
                if register in initial_row.registers:
                    self.current_row.registers[register] = initial_row.registers[register]
                else:
                    self.current_row.registers.pop(register, None)

            elif opcode == DwarfCFAOpcode.DW_CFA_undefined:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                self.current_row.registers[register] = RegisterState(
                    rule=RegisterRule.UNDEFINED
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_same_value:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                self.current_row.registers[register] = RegisterState(
                    rule=RegisterRule.SAME_VALUE
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_register:
                reg1, size = self._read_uleb128(instructions[offset:])
                offset += size
                reg2, size = self._read_uleb128(instructions[offset:])
                offset += size
                self.current_row.registers[reg1] = RegisterState(
                    rule=RegisterRule.REGISTER,
                    register=reg2
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_remember_state:
                self.state_stack.append(self.current_row.copy())

            elif opcode == DwarfCFAOpcode.DW_CFA_restore_state:
                if self.state_stack:
                    self.current_row = self.state_stack.pop()

            elif opcode == DwarfCFAOpcode.DW_CFA_val_offset:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                factored_offset, size = self._read_uleb128(instructions[offset:])
                offset += size
                self.current_row.registers[register] = RegisterState(
                    rule=RegisterRule.VAL_OFFSET,
                    offset=factored_offset * self.data_alignment
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_val_offset_sf:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                factored_offset, size = self._read_sleb128(instructions[offset:])
                offset += size
                self.current_row.registers[register] = RegisterState(
                    rule=RegisterRule.VAL_OFFSET,
                    offset=factored_offset * self.data_alignment
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_expression:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                length, size = self._read_uleb128(instructions[offset:])
                offset += size
                expression = instructions[offset:offset+length]
                offset += length
                self.current_row.registers[register] = RegisterState(
                    rule=RegisterRule.EXPRESSION,
                    expression=expression
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_val_expression:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                length, size = self._read_uleb128(instructions[offset:])
                offset += size
                expression = instructions[offset:offset+length]
                offset += length
                self.current_row.registers[register] = RegisterState(
                    rule=RegisterRule.VAL_EXPRESSION,
                    expression=expression
                )

            elif opcode == DwarfCFAOpcode.DW_CFA_GNU_args_size:
                # Skip args size (not used for unwinding)
                _, size = self._read_uleb128(instructions[offset:])
                offset += size

            elif opcode == DwarfCFAOpcode.DW_CFA_GNU_negative_offset_extended:
                register, size = self._read_uleb128(instructions[offset:])
                offset += size
                factored_offset, size = self._read_uleb128(instructions[offset:])
                offset += size
                self.current_row.registers[register] = RegisterState(
                    rule=RegisterRule.OFFSET,
                    offset=-(factored_offset * self.data_alignment)
                )

            else:
                logger.debug(f"Unknown CFI opcode: 0x{opcode:02x}")

    def _read_uleb128(self, data: bytes) -> tuple[int, int]:
        """Read ULEB128."""
        result = 0
        shift = 0
        size = 0

        for byte in data:
            size += 1
            result |= (byte & 0x7F) << shift
            if (byte & 0x80) == 0:
                break
            shift += 7

        return result, size

    def _read_sleb128(self, data: bytes) -> tuple[int, int]:
        """Read SLEB128."""
        result = 0
        shift = 0
        size = 0

        for byte in data:
            size += 1
            result |= (byte & 0x7F) << shift
            shift += 7
            if (byte & 0x80) == 0:
                if byte & 0x40:
                    result |= -(1 << shift)
                break

        return result, size


# ==================== DWARF Unwinder ====================

class DwarfUnwinder:
    """
    DWARF-based stack unwinder.
    
    Uses .eh_frame or .debug_frame sections for accurate unwinding.
    
    Example:
        # Parse eh_frame data
        unwinder = DwarfUnwinder(eh_frame_data, base_address=0x400000)
        
        # Unwind at a specific PC
        result = unwinder.unwind(pc=0x401234, registers={...}, memory_reader=...)
        
        # Get next frame's registers
        if result:
            next_pc = result.get('pc')
            next_sp = result.get('sp')
    """

    def __init__(self, eh_frame_data: bytes = b'',
                 base_address: int = 0,
                 is_64bit: bool = True):
        self.is_64bit = is_64bit
        self.ptr_size = 8 if is_64bit else 4

        # Parse eh_frame
        self.parser = EHFrameParser(
            eh_frame_data, base_address, is_64bit, is_eh_frame=True
        )
        self.cies, self.fdes = self.parser.parse() if eh_frame_data else ({}, [])

        # Register mapping for ARM64
        self.reg_names = {
            0: 'x0', 1: 'x1', 2: 'x2', 3: 'x3',
            4: 'x4', 5: 'x5', 6: 'x6', 7: 'x7',
            8: 'x8', 9: 'x9', 10: 'x10', 11: 'x11',
            12: 'x12', 13: 'x13', 14: 'x14', 15: 'x15',
            16: 'x16', 17: 'x17', 18: 'x18', 19: 'x19',
            20: 'x20', 21: 'x21', 22: 'x22', 23: 'x23',
            24: 'x24', 25: 'x25', 26: 'x26', 27: 'x27',
            28: 'x28', 29: 'x29', 30: 'x30', 31: 'sp',
        }

    def add_eh_frame(self, data: bytes, base_address: int = 0) -> None:
        """Add additional eh_frame data."""
        parser = EHFrameParser(data, base_address, self.is_64bit, True)
        cies, fdes = parser.parse()
        self.cies.update(cies)
        self.fdes.extend(fdes)

    def find_fde(self, pc: int) -> FDE | None:
        """Find FDE for the given PC."""
        for fde in self.fdes:
            if fde.pc_begin <= pc < fde.pc_begin + fde.pc_range:
                return fde
        return None

    def unwind(self, pc: int, registers: dict[str, int],
               memory_reader: Callable[[int, int], bytes]) -> dict[str, int] | None:
        """
        Unwind one frame using DWARF CFI.
        
        Args:
            pc: Current program counter
            registers: Current register values (by name)
            memory_reader: Function to read memory (addr, size) -> bytes
            
        Returns:
            Dict of register values for previous frame, or None if can't unwind
        """
        fde = self.find_fde(pc)
        if not fde or not fde.cie:
            return None

        # Interpret CFI to get unwind row
        interpreter = CFIInterpreter(fde.cie, self.is_64bit)
        row = interpreter.interpret_fde(fde, pc)
        if not row:
            return None

        # Helper to read register by DWARF number
        def get_reg(num: int) -> int:
            name = self.reg_names.get(num, f'r{num}')
            return registers.get(name, 0)

        # Compute CFA
        if row.cfa.is_expression:
            evaluator = DwarfExpressionEvaluator(
                is_64bit=self.is_64bit,
                memory_reader=memory_reader,
                register_reader=get_reg,
                cfa=0
            )
            cfa = evaluator.evaluate(row.cfa.expression)
        else:
            cfa = get_reg(row.cfa.register) + row.cfa.offset

        # Recover registers
        new_registers: dict[str, int] = {}

        for dwarf_reg, state in row.registers.items():
            reg_name = self.reg_names.get(dwarf_reg, f'r{dwarf_reg}')

            if state.rule == RegisterRule.UNDEFINED:
                new_registers[reg_name] = 0

            elif state.rule == RegisterRule.SAME_VALUE:
                new_registers[reg_name] = registers.get(reg_name, 0)

            elif state.rule == RegisterRule.OFFSET:
                # Value at CFA + offset
                addr = cfa + state.offset
                try:
                    data = memory_reader(addr, self.ptr_size)
                    if self.is_64bit:
                        new_registers[reg_name] = struct.unpack('<Q', data)[0]
                    else:
                        new_registers[reg_name] = struct.unpack('<I', data)[0]
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)

            elif state.rule == RegisterRule.VAL_OFFSET:
                # Value is CFA + offset (no memory read)
                new_registers[reg_name] = cfa + state.offset

            elif state.rule == RegisterRule.REGISTER:
                # Value is in another register
                src_name = self.reg_names.get(state.register, f'r{state.register}')
                new_registers[reg_name] = registers.get(src_name, 0)

            elif state.rule == RegisterRule.EXPRESSION:
                # Evaluate expression, result is address
                evaluator = DwarfExpressionEvaluator(
                    is_64bit=self.is_64bit,
                    memory_reader=memory_reader,
                    register_reader=get_reg,
                    cfa=cfa
                )
                addr = evaluator.evaluate(state.expression)
                try:
                    data = memory_reader(addr, self.ptr_size)
                    if self.is_64bit:
                        new_registers[reg_name] = struct.unpack('<Q', data)[0]
                    else:
                        new_registers[reg_name] = struct.unpack('<I', data)[0]
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)

            elif state.rule == RegisterRule.VAL_EXPRESSION:
                # Evaluate expression, result is the value
                evaluator = DwarfExpressionEvaluator(
                    is_64bit=self.is_64bit,
                    memory_reader=memory_reader,
                    register_reader=get_reg,
                    cfa=cfa
                )
                new_registers[reg_name] = evaluator.evaluate(state.expression)

        # Set new SP to CFA
        new_registers['sp'] = cfa

        # Get return address (PC for next frame)
        ra_column = fde.cie.return_address_column
        ra_name = self.reg_names.get(ra_column, 'x30')
        if ra_name in new_registers:
            new_registers['pc'] = new_registers[ra_name]

        return new_registers

    def unwind_all(self, initial_pc: int, initial_registers: dict[str, int],
                   memory_reader: Callable[[int, int], bytes],
                   max_frames: int = 100) -> list[dict[str, int]]:
        """
        Unwind complete stack.
        
        Returns:
            List of register states for each frame
        """
        frames = [{'pc': initial_pc, **initial_registers}]

        current_pc = initial_pc
        current_regs = initial_registers.copy()

        for _ in range(max_frames):
            result = self.unwind(current_pc, current_regs, memory_reader)
            if not result:
                break

            frames.append(result)
            current_pc = result.get('pc', 0)
            current_regs = result

            if current_pc == 0:
                break

        return frames

    def get_unwind_info(self, pc: int) -> dict[str, Any] | None:
        """
        Get unwind information for a PC without actually unwinding.
        
        Returns:
            Dict with CIE, FDE, and unwind row info
        """
        fde = self.find_fde(pc)
        if not fde or not fde.cie:
            return None

        interpreter = CFIInterpreter(fde.cie, self.is_64bit)
        row = interpreter.interpret_fde(fde, pc)

        return {
            'fde': {
                'pc_begin': fde.pc_begin,
                'pc_range': fde.pc_range,
                'lsda': fde.lsda,
            },
            'cie': {
                'version': fde.cie.version,
                'augmentation': fde.cie.augmentation,
                'code_alignment': fde.cie.code_alignment,
                'data_alignment': fde.cie.data_alignment,
                'return_address_column': fde.cie.return_address_column,
                'signal_frame': fde.cie.signal_frame,
            },
            'row': {
                'location': row.location if row else 0,
                'cfa_register': row.cfa.register if row else 0,
                'cfa_offset': row.cfa.offset if row else 0,
                'registers': {
                    self.reg_names.get(k, f'r{k}'): {
                        'rule': v.rule.name,
                        'offset': v.offset,
                    }
                    for k, v in (row.registers if row else {}).items()
                }
            } if row else None
        }
