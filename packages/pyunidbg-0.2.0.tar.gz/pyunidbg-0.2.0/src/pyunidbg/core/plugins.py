"""
Plugin System for PyUniDbg.

Provides a flexible plugin architecture for extending the emulator
with custom functionality, hooks, and analysis tools.
"""

from __future__ import annotations

import importlib
import importlib.util
import inspect
import json
import logging
import sys
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
)

if TYPE_CHECKING:
    from .emulator import Emulator

logger = logging.getLogger(__name__)


class PluginType(Enum):
    """Types of plugins."""

    ANALYZER = auto()
    HOOK = auto()
    LOADER = auto()
    EXPORTER = auto()
    UI = auto()
    INTEGRATION = auto()
    UTILITY = auto()


class PluginState(Enum):
    """Plugin lifecycle states."""

    UNLOADED = auto()
    LOADED = auto()
    ENABLED = auto()
    DISABLED = auto()
    ERROR = auto()


class HookPriority(Enum):
    """Hook execution priority."""

    HIGHEST = 0
    HIGH = 25
    NORMAL = 50
    LOW = 75
    LOWEST = 100


@dataclass
class PluginInfo:
    """Plugin metadata."""

    name: str
    version: str
    author: str = ""
    description: str = ""
    plugin_type: PluginType = PluginType.UTILITY
    dependencies: list[str] = field(default_factory=list)
    website: str = ""
    license: str = ""
    min_version: str = ""
    max_version: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "version": self.version,
            "author": self.author,
            "description": self.description,
            "type": self.plugin_type.name,
            "dependencies": self.dependencies,
            "website": self.website,
            "license": self.license,
            "min_version": self.min_version,
            "max_version": self.max_version,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> PluginInfo:
        """Create from dictionary."""
        plugin_type = PluginType[data.get("type", "UTILITY")]
        return cls(
            name=data.get("name", ""),
            version=data.get("version", ""),
            author=data.get("author", ""),
            description=data.get("description", ""),
            plugin_type=plugin_type,
            dependencies=data.get("dependencies", []),
            website=data.get("website", ""),
            license=data.get("license", ""),
            min_version=data.get("min_version", ""),
            max_version=data.get("max_version", ""),
        )


class Plugin(ABC):
    """Abstract base class for plugins."""

    def __init__(self):
        self._state = PluginState.UNLOADED
        self._emulator: Emulator | None = None
        self._config: dict[str, Any] = {}

    @property
    @abstractmethod
    def info(self) -> PluginInfo:
        """Get plugin information."""
        pass

    @property
    def state(self) -> PluginState:
        """Get current plugin state."""
        return self._state

    @property
    def emulator(self) -> Emulator | None:
        """Get attached emulator."""
        return self._emulator

    @property
    def config(self) -> dict[str, Any]:
        """Get plugin configuration."""
        return self._config

    def load(self, emulator: Emulator) -> None:
        """
        Called when plugin is loaded.
        
        Override to perform initialization.
        """
        self._emulator = emulator
        self._state = PluginState.LOADED

    def unload(self) -> None:
        """
        Called when plugin is unloaded.
        
        Override to perform cleanup.
        """
        self._emulator = None
        self._state = PluginState.UNLOADED

    def enable(self) -> None:
        """
        Called when plugin is enabled.
        
        Override to activate functionality.
        """
        if self._state == PluginState.LOADED or self._state == PluginState.DISABLED:
            self._state = PluginState.ENABLED

    def disable(self) -> None:
        """
        Called when plugin is disabled.
        
        Override to deactivate functionality.
        """
        if self._state == PluginState.ENABLED:
            self._state = PluginState.DISABLED

    def configure(self, config: dict[str, Any]) -> None:
        """
        Configure the plugin.
        
        Args:
            config: Configuration dictionary.
        """
        self._config.update(config)

    def get_config_schema(self) -> dict[str, Any]:
        """
        Get configuration schema.
        
        Override to define available configuration options.
        
        Returns:
            JSON schema for configuration.
        """
        return {}

    def get_commands(self) -> dict[str, Callable]:
        """
        Get plugin commands.
        
        Override to expose commands to the CLI.
        
        Returns:
            Dictionary of command name -> handler.
        """
        return {}

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name={self.info.name!r}, state={self.state.name})"


class AnalyzerPlugin(Plugin):
    """Base class for analyzer plugins."""

    @abstractmethod
    def analyze(self, *args, **kwargs) -> Any:
        """Perform analysis."""
        pass

    def get_results(self) -> Any:
        """Get analysis results."""
        return None

    def reset(self) -> None:
        """Reset analyzer state."""
        pass


class HookPlugin(Plugin):
    """Base class for hook plugins."""

    def __init__(self, priority: HookPriority = HookPriority.NORMAL):
        super().__init__()
        self.priority = priority
        self._hooks: list[tuple[str, Callable]] = []

    def register_hook(self, event: str, callback: Callable) -> None:
        """Register a hook callback."""
        self._hooks.append((event, callback))

    def get_hooks(self) -> list[tuple[str, Callable]]:
        """Get all registered hooks."""
        return self._hooks

    def unload(self) -> None:
        """Unload and clear hooks."""
        self._hooks.clear()
        super().unload()


class LoaderPlugin(Plugin):
    """Base class for file loader plugins."""

    @abstractmethod
    def can_load(self, path: str | Path) -> bool:
        """Check if this loader can handle the file."""
        pass

    @abstractmethod
    def load_file(self, path: str | Path) -> Any:
        """Load the file."""
        pass

    def get_supported_extensions(self) -> list[str]:
        """Get list of supported file extensions."""
        return []


class ExporterPlugin(Plugin):
    """Base class for exporter plugins."""

    @abstractmethod
    def export(self, data: Any, path: str | Path) -> None:
        """Export data to file."""
        pass

    def get_supported_formats(self) -> list[str]:
        """Get list of supported export formats."""
        return []


@dataclass
class PluginEntry:
    """Entry in the plugin registry."""

    plugin: Plugin
    path: str | None = None
    load_time: float = 0.0
    error: str | None = None

    @property
    def is_enabled(self) -> bool:
        """Check if plugin is enabled."""
        return self.plugin.state == PluginState.ENABLED

    @property
    def is_loaded(self) -> bool:
        """Check if plugin is loaded."""
        return self.plugin.state in (PluginState.LOADED, PluginState.ENABLED, PluginState.DISABLED)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "info": self.plugin.info.to_dict(),
            "state": self.plugin.state.name,
            "path": self.path,
            "load_time": self.load_time,
            "error": self.error,
        }


class PluginRegistry:
    """Registry for managing plugins."""

    def __init__(self):
        self._plugins: dict[str, PluginEntry] = {}
        self._by_type: dict[PluginType, list[str]] = {t: [] for t in PluginType}

    def register(
        self,
        plugin: Plugin,
        path: str | None = None,
    ) -> bool:
        """
        Register a plugin.
        
        Args:
            plugin: Plugin instance.
            path: Path to plugin file.
        
        Returns:
            True if registered successfully.
        """
        name = plugin.info.name

        if name in self._plugins:
            logger.warning(f"Plugin '{name}' already registered")
            return False

        entry = PluginEntry(
            plugin=plugin,
            path=path,
            load_time=datetime.now().timestamp(),
        )

        self._plugins[name] = entry
        self._by_type[plugin.info.plugin_type].append(name)

        logger.info(f"Registered plugin: {name}")
        return True

    def unregister(self, name: str) -> bool:
        """
        Unregister a plugin.
        
        Args:
            name: Plugin name.
        
        Returns:
            True if unregistered successfully.
        """
        if name not in self._plugins:
            return False

        entry = self._plugins[name]
        plugin_type = entry.plugin.info.plugin_type

        # Unload if loaded
        if entry.is_loaded:
            entry.plugin.unload()

        del self._plugins[name]
        if name in self._by_type[plugin_type]:
            self._by_type[plugin_type].remove(name)

        logger.info(f"Unregistered plugin: {name}")
        return True

    def get(self, name: str) -> Plugin | None:
        """Get a plugin by name."""
        entry = self._plugins.get(name)
        return entry.plugin if entry else None

    def get_entry(self, name: str) -> PluginEntry | None:
        """Get a plugin entry by name."""
        return self._plugins.get(name)

    def get_all(self) -> list[Plugin]:
        """Get all registered plugins."""
        return [e.plugin for e in self._plugins.values()]

    def get_by_type(self, plugin_type: PluginType) -> list[Plugin]:
        """Get plugins by type."""
        names = self._by_type.get(plugin_type, [])
        return [self._plugins[n].plugin for n in names if n in self._plugins]

    def get_enabled(self) -> list[Plugin]:
        """Get all enabled plugins."""
        return [e.plugin for e in self._plugins.values() if e.is_enabled]

    def list_names(self) -> list[str]:
        """List all plugin names."""
        return list(self._plugins.keys())

    def __len__(self) -> int:
        return len(self._plugins)

    def __iter__(self) -> Iterator[Plugin]:
        return iter(self.get_all())

    def __contains__(self, name: str) -> bool:
        return name in self._plugins


class PluginLoader:
    """Loads plugins from files and directories."""

    def __init__(self, registry: PluginRegistry | None = None):
        self.registry = registry or PluginRegistry()
        self._plugin_paths: list[Path] = []

    def add_plugin_path(self, path: str | Path) -> None:
        """Add a path to search for plugins."""
        path = Path(path)
        if path.exists() and path not in self._plugin_paths:
            self._plugin_paths.append(path)

    def load_plugin_file(self, path: str | Path) -> Plugin | None:
        """
        Load a plugin from a Python file.
        
        Args:
            path: Path to plugin file.
        
        Returns:
            Loaded plugin instance or None.
        """
        path = Path(path)
        if not path.exists() or not path.suffix == '.py':
            return None

        try:
            # Load module from file
            spec = importlib.util.spec_from_file_location(
                f"pyunidbg_plugin_{path.stem}",
                path,
            )
            if spec is None or spec.loader is None:
                return None

            module = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = module
            spec.loader.exec_module(module)

            # Find plugin classes
            for name, obj in inspect.getmembers(module, inspect.isclass):
                if (issubclass(obj, Plugin) and
                    obj not in (Plugin, AnalyzerPlugin, HookPlugin, LoaderPlugin, ExporterPlugin)):
                    # Instantiate and register
                    try:
                        plugin = obj()
                        self.registry.register(plugin, str(path))
                        logger.info(f"Loaded plugin from {path}: {plugin.info.name}")
                        return plugin
                    except Exception as e:
                        logger.error(f"Failed to instantiate plugin from {path}: {e}")

            return None

        except Exception as e:
            logger.error(f"Failed to load plugin from {path}: {e}")
            return None

    def load_plugin_directory(self, path: str | Path) -> list[Plugin]:
        """
        Load all plugins from a directory.
        
        Args:
            path: Path to plugin directory.
        
        Returns:
            List of loaded plugins.
        """
        path = Path(path)
        plugins = []

        if not path.exists() or not path.is_dir():
            return plugins

        for file in path.glob("*.py"):
            if file.name.startswith("_"):
                continue
            plugin = self.load_plugin_file(file)
            if plugin:
                plugins.append(plugin)

        # Also check subdirectories for packages
        for subdir in path.iterdir():
            if subdir.is_dir() and (subdir / "__init__.py").exists():
                init_file = subdir / "__init__.py"
                plugin = self.load_plugin_file(init_file)
                if plugin:
                    plugins.append(plugin)

        return plugins

    def discover_plugins(self) -> list[Plugin]:
        """
        Discover and load plugins from all plugin paths.
        
        Returns:
            List of discovered plugins.
        """
        plugins = []
        for path in self._plugin_paths:
            plugins.extend(self.load_plugin_directory(path))
        return plugins

    def load_builtin_plugins(self) -> list[Plugin]:
        """
        Load built-in plugins.
        
        Returns:
            List of loaded built-in plugins.
        """
        # This would load plugins bundled with the application
        return []


class PluginManager:
    """Main plugin manager class."""

    def __init__(self, emulator: Emulator | None = None):
        self.emulator = emulator
        self.registry = PluginRegistry()
        self.loader = PluginLoader(self.registry)

        self._hook_handlers: dict[str, list[tuple[Plugin, Callable, HookPriority]]] = {}
        self._commands: dict[str, tuple[Plugin, Callable]] = {}

    def set_emulator(self, emulator: Emulator) -> None:
        """Set the emulator instance."""
        self.emulator = emulator

    def add_plugin_path(self, path: str | Path) -> None:
        """Add a plugin search path."""
        self.loader.add_plugin_path(path)

    def load_plugin(self, path: str | Path) -> Plugin | None:
        """
        Load a plugin from file.
        
        Args:
            path: Path to plugin file.
        
        Returns:
            Loaded plugin or None.
        """
        plugin = self.loader.load_plugin_file(path)
        if plugin:
            self._setup_plugin(plugin)
        return plugin

    def register_plugin(self, plugin: Plugin) -> bool:
        """
        Register a plugin instance.
        
        Args:
            plugin: Plugin to register.
        
        Returns:
            True if registered successfully.
        """
        if self.registry.register(plugin):
            self._setup_plugin(plugin)
            return True
        return False

    def _setup_plugin(self, plugin: Plugin) -> None:
        """Set up a newly loaded plugin."""
        # Load plugin with emulator
        if self.emulator:
            plugin.load(self.emulator)

        # Register hooks
        if isinstance(plugin, HookPlugin):
            for event, callback in plugin.get_hooks():
                self._register_hook(event, plugin, callback, plugin.priority)

        # Register commands
        for name, handler in plugin.get_commands().items():
            self._commands[name] = (plugin, handler)

    def _register_hook(
        self,
        event: str,
        plugin: Plugin,
        callback: Callable,
        priority: HookPriority,
    ) -> None:
        """Register a hook handler."""
        if event not in self._hook_handlers:
            self._hook_handlers[event] = []

        self._hook_handlers[event].append((plugin, callback, priority))

        # Sort by priority
        self._hook_handlers[event].sort(key=lambda x: x[2].value)

    def unload_plugin(self, name: str) -> bool:
        """
        Unload a plugin.
        
        Args:
            name: Plugin name.
        
        Returns:
            True if unloaded successfully.
        """
        plugin = self.registry.get(name)
        if not plugin:
            return False

        # Disable first
        self.disable_plugin(name)

        # Remove hooks
        for event in list(self._hook_handlers.keys()):
            self._hook_handlers[event] = [
                (p, c, pr) for p, c, pr in self._hook_handlers[event]
                if p is not plugin
            ]

        # Remove commands
        to_remove = [cmd for cmd, (p, _) in self._commands.items() if p is plugin]
        for cmd in to_remove:
            del self._commands[cmd]

        # Unload and unregister
        plugin.unload()
        return self.registry.unregister(name)

    def enable_plugin(self, name: str) -> bool:
        """
        Enable a plugin.
        
        Args:
            name: Plugin name.
        
        Returns:
            True if enabled successfully.
        """
        plugin = self.registry.get(name)
        if not plugin:
            return False

        # Check dependencies
        for dep in plugin.info.dependencies:
            dep_plugin = self.registry.get(dep)
            if not dep_plugin or dep_plugin.state != PluginState.ENABLED:
                logger.error(f"Cannot enable {name}: dependency {dep} not enabled")
                return False

        plugin.enable()
        return plugin.state == PluginState.ENABLED

    def disable_plugin(self, name: str) -> bool:
        """
        Disable a plugin.
        
        Args:
            name: Plugin name.
        
        Returns:
            True if disabled successfully.
        """
        plugin = self.registry.get(name)
        if not plugin:
            return False

        plugin.disable()
        return plugin.state == PluginState.DISABLED

    def get_plugin(self, name: str) -> Plugin | None:
        """Get a plugin by name."""
        return self.registry.get(name)

    def list_plugins(self) -> list[dict[str, Any]]:
        """List all plugins with their status."""
        result = []
        for name in self.registry.list_names():
            entry = self.registry.get_entry(name)
            if entry:
                result.append(entry.to_dict())
        return result

    def discover_plugins(self) -> list[Plugin]:
        """Discover and load plugins from plugin paths."""
        plugins = self.loader.discover_plugins()
        for plugin in plugins:
            self._setup_plugin(plugin)
        return plugins

    def dispatch_event(self, event: str, *args, **kwargs) -> list[Any]:
        """
        Dispatch an event to registered hooks.
        
        Args:
            event: Event name.
            *args: Event arguments.
            **kwargs: Event keyword arguments.
        
        Returns:
            List of handler results.
        """
        results = []
        handlers = self._hook_handlers.get(event, [])

        for plugin, callback, _ in handlers:
            if plugin.state != PluginState.ENABLED:
                continue

            try:
                result = callback(*args, **kwargs)
                results.append(result)
            except Exception as e:
                logger.error(f"Hook handler error in {plugin.info.name}: {e}")

        return results

    def execute_command(self, command: str, *args, **kwargs) -> Any:
        """
        Execute a plugin command.
        
        Args:
            command: Command name.
            *args: Command arguments.
            **kwargs: Command keyword arguments.
        
        Returns:
            Command result.
        """
        if command not in self._commands:
            raise ValueError(f"Unknown command: {command}")

        plugin, handler = self._commands[command]

        if plugin.state != PluginState.ENABLED:
            raise RuntimeError(f"Plugin {plugin.info.name} is not enabled")

        return handler(*args, **kwargs)

    def get_commands(self) -> dict[str, str]:
        """
        Get all available commands.
        
        Returns:
            Dictionary of command name -> plugin name.
        """
        return {cmd: plugin.info.name for cmd, (plugin, _) in self._commands.items()}

    def get_analyzers(self) -> list[AnalyzerPlugin]:
        """Get all analyzer plugins."""
        return [p for p in self.registry.get_by_type(PluginType.ANALYZER)
                if isinstance(p, AnalyzerPlugin)]

    def get_loaders(self) -> list[LoaderPlugin]:
        """Get all loader plugins."""
        return [p for p in self.registry.get_by_type(PluginType.LOADER)
                if isinstance(p, LoaderPlugin)]

    def get_exporters(self) -> list[ExporterPlugin]:
        """Get all exporter plugins."""
        return [p for p in self.registry.get_by_type(PluginType.EXPORTER)
                if isinstance(p, ExporterPlugin)]

    def find_loader(self, path: str | Path) -> LoaderPlugin | None:
        """
        Find a loader that can handle the file.
        
        Args:
            path: File path.
        
        Returns:
            Loader plugin or None.
        """
        for loader in self.get_loaders():
            if loader.state == PluginState.ENABLED and loader.can_load(path):
                return loader
        return None

    def configure_plugin(self, name: str, config: dict[str, Any]) -> bool:
        """
        Configure a plugin.
        
        Args:
            name: Plugin name.
            config: Configuration dictionary.
        
        Returns:
            True if configured successfully.
        """
        plugin = self.registry.get(name)
        if not plugin:
            return False

        plugin.configure(config)
        return True

    def save_state(self, path: str | Path) -> None:
        """Save plugin manager state to file."""
        path = Path(path)
        state = {
            "plugins": [
                {
                    "name": p.info.name,
                    "enabled": p.state == PluginState.ENABLED,
                    "config": p.config,
                }
                for p in self.registry.get_all()
            ],
        }

        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w') as f:
            json.dump(state, f, indent=2)

    def load_state(self, path: str | Path) -> None:
        """Load plugin manager state from file."""
        path = Path(path)
        if not path.exists():
            return

        with open(path) as f:
            state = json.load(f)

        for plugin_state in state.get("plugins", []):
            name = plugin_state["name"]
            plugin = self.registry.get(name)

            if plugin:
                plugin.configure(plugin_state.get("config", {}))
                if plugin_state.get("enabled"):
                    self.enable_plugin(name)
                else:
                    self.disable_plugin(name)

    def print_summary(self) -> None:
        """Print plugin manager summary."""
        print("\n" + "=" * 60)
        print("PLUGIN MANAGER SUMMARY")
        print("=" * 60)
        print(f"Total Plugins:    {len(self.registry)}")
        print(f"Enabled Plugins:  {len(self.registry.get_enabled())}")
        print(f"Commands:         {len(self._commands)}")
        print(f"Hook Events:      {len(self._hook_handlers)}")
        print("-" * 60)

        for entry in self.registry._plugins.values():
            info = entry.plugin.info
            state = entry.plugin.state.name
            print(f"  {info.name} v{info.version} [{state}] - {info.description[:40]}")

        print("=" * 60 + "\n")

    def __repr__(self) -> str:
        return (
            f"PluginManager(plugins={len(self.registry)}, "
            f"enabled={len(self.registry.get_enabled())})"
        )


def create_plugin_manager(
    emulator: Emulator | None = None,
    plugin_paths: list[str] | None = None,
    auto_discover: bool = False,
) -> PluginManager:
    """
    Create a configured plugin manager.
    
    Args:
        emulator: Emulator instance.
        plugin_paths: Paths to search for plugins.
        auto_discover: Whether to auto-discover plugins.
    
    Returns:
        Configured PluginManager instance.
    """
    manager = PluginManager(emulator)

    if plugin_paths:
        for path in plugin_paths:
            manager.add_plugin_path(path)

    if auto_discover:
        manager.discover_plugins()

    return manager
