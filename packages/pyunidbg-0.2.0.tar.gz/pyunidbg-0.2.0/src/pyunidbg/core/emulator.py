"""Core emulator implementation."""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from capstone import (
    CS_ARCH_ARM,
    CS_ARCH_ARM64,
    CS_ARCH_X86,
    CS_MODE_32,
    CS_MODE_64,
    CS_MODE_ARM,
    Cs,
)
from unicorn import (
    UC_ARCH_ARM,
    UC_ARCH_ARM64,
    UC_ARCH_X86,
    UC_MODE_32,
    UC_MODE_64,
    UC_MODE_ARM,
    Uc,
)
from unicorn.arm64_const import UC_ARM64_REG_PC
from unicorn.arm_const import UC_ARM_REG_PC

from pyunidbg.core.constants import Architecture, Endianness, MemoryLayout
from pyunidbg.core.cpu import CPUContext
from pyunidbg.core.hooks import HookManager
from pyunidbg.core.memory import MemoryManager

logger = logging.getLogger(__name__)


# Map architecture to Unicorn/Capstone constants
ARCH_MAP = {
    Architecture.ARM: {
        "uc_arch": UC_ARCH_ARM,
        "uc_mode": UC_MODE_ARM,
        "cs_arch": CS_ARCH_ARM,
        "cs_mode": CS_MODE_ARM,
    },
    Architecture.ARM64: {
        "uc_arch": UC_ARCH_ARM64,
        "uc_mode": UC_MODE_ARM,
        "cs_arch": CS_ARCH_ARM64,
        "cs_mode": CS_MODE_ARM,
    },
    Architecture.X86: {
        "uc_arch": UC_ARCH_X86,
        "uc_mode": UC_MODE_32,
        "cs_arch": CS_ARCH_X86,
        "cs_mode": CS_MODE_32,
    },
    Architecture.X86_64: {
        "uc_arch": UC_ARCH_X86,
        "uc_mode": UC_MODE_64,
        "cs_arch": CS_ARCH_X86,
        "cs_mode": CS_MODE_64,
    },
}


@dataclass
class EmulatorConfig:
    """Configuration for the emulator."""

    arch: Architecture = Architecture.ARM64
    endianness: Endianness = Endianness.LITTLE
    stack_size: int = MemoryLayout.STACK_SIZE
    heap_size: int = MemoryLayout.HEAP_SIZE
    trace_instructions: bool = False
    trace_memory: bool = False
    verbose: bool = False


class Emulator:
    """
    Core emulator class that wraps Unicorn Engine.
    
    Provides a high-level interface for:
    - Loading and executing code
    - Memory management
    - CPU state manipulation
    - Hook registration
    - Debugging
    """

    def __init__(self, config: EmulatorConfig | None = None):
        """
        Initialize the emulator.
        
        Args:
            config: Emulator configuration. Uses defaults if not provided.
        """
        self.config = config or EmulatorConfig()

        # Get architecture settings
        arch_settings = ARCH_MAP.get(self.config.arch)
        if arch_settings is None:
            raise ValueError(f"Unsupported architecture: {self.config.arch}")

        # Initialize Unicorn
        self._uc = Uc(arch_settings["uc_arch"], arch_settings["uc_mode"])

        # Initialize Capstone for disassembly
        self._cs = Cs(arch_settings["cs_arch"], arch_settings["cs_mode"])
        self._cs.detail = True

        # Initialize subsystems
        self.memory = MemoryManager(
            self._uc,
            self.config.arch,
            self.config.endianness,
        )
        self.cpu = CPUContext(self.config.arch, self._uc)
        self.hook = HookManager(self)

        # State
        self._running = False
        self._stopped = False
        self._exit_code = 0

        # Loaded modules
        self._modules: dict[str, Any] = {}  # name -> LoadedModule

        # Setup initial CPU state
        self._setup_initial_state()

    def _setup_initial_state(self) -> None:
        """Setup initial CPU state."""
        # Set stack pointer
        self.cpu.sp = self.memory.stack_top

        # Set a return address that will cause controlled exit
        self._exit_address = MemoryLayout.HOOK_BASE
        self.memory.map(
            self._exit_address,
            MemoryLayout.PAGE_SIZE,
            name="[exit_trap]",
        )

        if self.config.arch in (Architecture.X86, Architecture.X86_64):
            # x86: write HLT (0xF4) at exit trap and push return address on stack
            self.memory.write(self._exit_address, b"\xf4\xf4\xf4\xf4")
        else:
            # ARM: write invalid instruction to trap
            self.memory.write(self._exit_address, b"\x00\x00\x00\x00")

        self.cpu.lr = self._exit_address

    @property
    def arch(self) -> Architecture:
        """Get the architecture."""
        return self.config.arch

    @property
    def uc(self) -> Uc:
        """Expose the underlying Unicorn instance (used by analysis modules)."""
        return self._uc

    @property
    def pc_reg(self) -> int:
        """Unicorn register ID for the program counter (used by analysis modules)."""
        if self.config.arch == Architecture.ARM64:
            return UC_ARM64_REG_PC
        return UC_ARM_REG_PC

    @property
    def is_64bit(self) -> bool:
        """Check if running in 64-bit mode."""
        return self.config.arch in (Architecture.ARM64, Architecture.X86_64)

    @property
    def pointer_size(self) -> int:
        """Get pointer size in bytes."""
        return 8 if self.is_64bit else 4

    def read_string(self, address: int, max_length: int = 4096) -> str:
        """Read a null-terminated string from memory."""
        return self.memory.read_string(address, max_length)

    def write_string(self, address: int, string: str) -> int:
        """Write a null-terminated string to memory."""
        return self.memory.write_string(address, string)

    def alloc_string(self, string: str) -> int:
        """Allocate and write a string, returning its address."""
        return self.memory.alloc_string(string)

    def call(
        self,
        address: int,
        args: list[int] | None = None,
        return_address: int | None = None,
    ) -> int:
        """
        Call a function at the given address.
        
        Args:
            address: Function address
            args: List of integer arguments
            return_address: Where to return to (defaults to exit trap)
        
        Returns:
            Return value (from R0/X0)
        """
        args = args or []
        ret_addr = return_address or self._exit_address

        if self.config.arch == Architecture.X86:
            # cdecl: push args right-to-left, then push return address
            sp = self.cpu.sp
            # Reserve space for all args + return address
            sp -= (len(args) + 1) * 4
            sp &= ~0xF  # 16-byte align
            self.cpu.sp = sp
            # Write return address at [ESP]
            self.memory.write(sp, ret_addr.to_bytes(4, 'little'))
            # Write args at [ESP+4], [ESP+8], ...
            for i, arg in enumerate(args):
                self.memory.write(sp + (i + 1) * 4, (arg & 0xFFFFFFFF).to_bytes(4, 'little'))
        elif self.config.arch == Architecture.X86_64:
            # System V AMD64: first 6 in regs, rest on stack, then push return address
            _ARG_REGS_COUNT = 6
            # Push stack args right-to-left if any
            sp = self.cpu.sp
            stack_args = args[_ARG_REGS_COUNT:] if len(args) > _ARG_REGS_COUNT else []
            sp -= (len(stack_args) + 1) * 8  # +1 for return address
            sp &= ~0xF
            self.cpu.sp = sp
            # Write return address at [RSP]
            self.memory.write(sp, ret_addr.to_bytes(8, 'little'))
            # Write stack args
            for i, arg in enumerate(stack_args):
                self.memory.write(sp + (i + 1) * 8, (arg & 0xFFFFFFFFFFFFFFFF).to_bytes(8, 'little'))
            # Set register args
            for i, arg in enumerate(args[:_ARG_REGS_COUNT]):
                self.cpu.set_arg(i, arg)
        else:
            # ARM / ARM64: reserve stack space for overflow args
            if self.config.arch == Architecture.ARM64:
                reg_count, slot_size, align = 8, 8, 0xF
            else:
                reg_count, slot_size, align = 4, 4, 0x7

            if len(args) > reg_count:
                stack_slots = len(args) - reg_count
                sp = self.cpu.sp
                sp -= stack_slots * slot_size
                sp &= ~align
                self.cpu.sp = sp

            # Set arguments (registers first, then stack via cpu.set_arg)
            for i, arg in enumerate(args):
                self.cpu.set_arg(i, arg)

            # Set return address via link register
            self.cpu.lr = ret_addr

        # Set PC and run
        self.cpu.pc = address

        try:
            self._running = True
            self._uc.emu_start(address, self._exit_address)
        except Exception:
            self._running = False
            raise
        finally:
            self._running = False

        return self.cpu.get_return_value()

    def run(
        self,
        start: int,
        end: int = 0,
        timeout: int = 0,
        count: int = 0,
    ) -> None:
        """
        Run emulation.
        
        Args:
            start: Start address
            end: End address (0 = run until error/hook stops)
            timeout: Timeout in microseconds (0 = no timeout)
            count: Max instructions to execute (0 = unlimited)
        """
        self._running = True
        self._stopped = False

        try:
            self._uc.emu_start(start, end, timeout, count)
        finally:
            self._running = False

    def step(self, count: int = 1) -> None:
        """Execute a number of instructions."""
        pc = self.cpu.pc
        self.run(pc, count=count)

    def stop(self) -> None:
        """Stop emulation."""
        self._stopped = True
        self._uc.emu_stop()

    def disassemble(
        self,
        address: int,
        size: int = 64,
        count: int = 0,
    ) -> list[tuple[int, str, str]]:
        """
        Disassemble code at address.
        
        Args:
            address: Start address
            size: Number of bytes to disassemble
            count: Max instructions (0 = all in size)
        
        Returns:
            List of (address, mnemonic, op_str) tuples
        """
        region = self.memory.find_region(address)
        if region is None:
            return []
        available = region.end - address
        read_size = min(size, available)
        if read_size <= 0:
            return []
        try:
            code = self.memory.read(address, read_size)
        except Exception:
            return []
        result = []

        for insn in self._cs.disasm(code, address):
            result.append((insn.address, insn.mnemonic, insn.op_str))
            if count and len(result) >= count:
                break

        return result

    def disassemble_at(self, address: int, count: int = 10) -> str:
        """
        Get a formatted disassembly string.
        
        Args:
            address: Start address
            count: Number of instructions
        
        Returns:
            Formatted disassembly string
        """
        lines = []
        for addr, mnemonic, op_str in self.disassemble(address, count=count):
            marker = " => " if addr == self.cpu.pc else "    "
            lines.append(f"{marker}{addr:#010x}: {mnemonic:8} {op_str}")
        return "\n".join(lines)

    def save_state(self) -> dict:
        """
        Save complete emulator state.
        
        Returns:
            State dictionary that can be passed to restore_state()
        """
        state = {
            "cpu": self.cpu.save(),
            "memory": {},
        }

        # Save memory contents
        for region in self.memory.get_regions():
            try:
                data = self.memory.read(region.start, region.size)
                state["memory"][region.start] = {
                    "size": region.size,
                    "protection": region.protection,
                    "name": region.name,
                    "data": data,
                }
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        return state

    def restore_state(self, state: dict) -> None:
        """
        Restore emulator state from a saved state.
        
        Args:
            state: State dictionary from save_state()
        """
        # Restore CPU
        self.cpu.restore(state["cpu"])

        # Restore memory
        for addr, region_data in state["memory"].items():
            data = region_data["data"]
            # Ensure data is bytes (not bytearray)
            if isinstance(data, bytearray):
                data = bytes(data)
            self.memory.write(addr, data)

    def add_symbol(self, name: str, address: int) -> None:
        """Register a symbol (for debugging/hooks)."""
        # This would be used by the loader
        pass

    def get_symbol(self, name: str) -> int | None:
        """Get address of a symbol by name."""
        # This would be used for resolving function names
        return None

    def hook_add_code(self, address: int, callback: Callable):
        """
        Add a code hook at a specific address (convenience wrapper for session/web use).

        The callback receives (emulator, address, size).
        """
        from pyunidbg.core.hooks import Hook, HookType
        hook = Hook(
            hook_type=HookType.ADDRESS,
            callback=callback,
            address=address,
        )
        return self.hook.add_hook(hook)

    def get_cpu_context(self) -> CPUContext:
        """Return the current CPU context (used by web session and analysis)."""
        return self.cpu

    def mem_regions(self):
        """
        Iterate over mapped memory regions as (start, end, perms) tuples.

        Compatible with Unicorn's uc.mem_regions() tuple format expected by
        session.py and analysis modules.
        """
        for r in self.memory.get_regions():
            yield (r.start, r.end, int(r.protection))

    def mem_read(self, address: int, size: int) -> bytearray:
        """Read bytes from emulator memory (Unicorn-compatible proxy)."""
        return bytearray(self.memory.read(address, size))

    def mem_write(self, address: int, data: bytes) -> None:
        """Write bytes to emulator memory (Unicorn-compatible proxy)."""
        self.memory.write(address, bytes(data))

    def hexdump(self, address: int, size: int = 64) -> str:
        """Get a hex dump of memory."""
        return self.memory.hexdump(address, size)

    def __repr__(self) -> str:
        return (
            f"Emulator(arch={self.config.arch.value}, "
            f"pc={self.cpu.pc:#x}, sp={self.cpu.sp:#x})"
        )
