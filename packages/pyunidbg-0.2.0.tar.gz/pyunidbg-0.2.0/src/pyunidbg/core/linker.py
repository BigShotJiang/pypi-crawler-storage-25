"""
Dynamic Linker -- load, link, and initialise ELF shared libraries.

This module implements the core of the ELF dynamic linker (``ld.so``
equivalent) inside the emulator.  It handles every stage of bringing a
``.so`` into the emulated address space:

1. **Library discovery** -- searching configurable path lists for a
   requested library name.
2. **ELF loading** -- mapping ``PT_LOAD`` segments into Unicorn memory
   and zeroing the ``.bss`` region.
3. **Dynamic section parsing** -- reading ``DT_NEEDED``, ``DT_INIT``,
   ``DT_INIT_ARRAY``, etc. from the ``PT_DYNAMIC`` segment.
4. **Symbol parsing** -- extracting the ``.dynsym`` / ``.dynstr``
   tables and classifying each symbol as an export or import.
5. **Relocation processing** -- applying ``R_*_RELATIVE``,
   ``R_*_GLOB_DAT``, ``R_*_JUMP_SLOT``, ``R_*_ABS*`` and
   ``R_*_IRELATIVE`` relocations for both REL and RELA formats.
6. **Dependency loading** -- recursively loading ``DT_NEEDED``
   libraries before the requesting library is linked.
7. **Initialisation** -- calling ``.init`` and ``.init_array``
   constructors (in dependency order) once relocations are applied.
8. **Symbol resolution** -- a three-tier lookup (hooks → global table →
   per-library exports) with automatic stub generation for truly
   undefined symbols.

Supported architectures
~~~~~~~~~~~~~~~~~~~~~~~
* **AArch64 / ARM64** -- ``R_AARCH64_*`` relocation types, 64-bit
  pointers, ``Elf64_Sym`` / ``Elf64_Rela`` layouts.
* **ARM32** -- ``R_ARM_*`` relocation types, 32-bit pointers,
  ``Elf32_Sym`` / ``Elf32_Rel`` layouts.

Typical usage
~~~~~~~~~~~~~
::

    linker = DynamicLinker(emulator)
    linker.add_library_path("/system/lib64")
    lib = linker.load_library("libnative.so")
    linker.call_init(lib)
    addr = linker.resolve_symbol("JNI_OnLoad")
"""

import logging
import struct
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntEnum
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .elf import ELFFile
    from .emulator import Emulator

logger = logging.getLogger(__name__)


# ==================== ELF Dynamic Tags ====================

class DT(IntEnum):
    """``Elf{32,64}_Dyn.d_tag`` values used when parsing the ``PT_DYNAMIC``
    segment.  Only the tags that are actually consulted by the linker are
    listed here; the full set is defined in the ELF specification
    (``elf.h``)."""
    NULL = 0
    NEEDED = 1
    PLTRELSZ = 2
    PLTGOT = 3
    HASH = 4
    STRTAB = 5
    SYMTAB = 6
    RELA = 7
    RELASZ = 8
    RELAENT = 9
    STRSZ = 10
    SYMENT = 11
    INIT = 12
    FINI = 13
    SONAME = 14
    RPATH = 15
    SYMBOLIC = 16
    REL = 17
    RELSZ = 18
    RELENT = 19
    PLTREL = 20
    DEBUG = 21
    TEXTREL = 22
    JMPREL = 23
    BIND_NOW = 24
    INIT_ARRAY = 25
    FINI_ARRAY = 26
    INIT_ARRAYSZ = 27
    FINI_ARRAYSZ = 28
    RUNPATH = 29
    FLAGS = 30
    PREINIT_ARRAY = 32
    PREINIT_ARRAYSZ = 33
    GNU_HASH = 0x6ffffef5
    VERSYM = 0x6ffffff0
    VERNEED = 0x6ffffffe
    VERNEEDNUM = 0x6fffffff


# ==================== Relocation Types ====================

class R_AARCH64(IntEnum):
    """AArch64 ELF relocation types (``R_AARCH64_*``).

    Only the types processed by :meth:`DynamicLinker._apply_relocation`
    are included.  See *ELF for the Arm 64-bit Architecture (AArch64)*
    for the full catalogue.
    """
    NONE = 0
    ABS64 = 257
    ABS32 = 258
    ABS16 = 259
    PREL64 = 260
    PREL32 = 261
    PREL16 = 262
    MOVW_UABS_G0 = 263
    MOVW_UABS_G0_NC = 264
    MOVW_UABS_G1 = 265
    MOVW_UABS_G1_NC = 266
    MOVW_UABS_G2 = 267
    MOVW_UABS_G2_NC = 268
    MOVW_UABS_G3 = 269
    GLOB_DAT = 1025
    JUMP_SLOT = 1026
    RELATIVE = 1027
    TLS_DTPREL64 = 1028
    TLS_DTPMOD64 = 1029
    TLS_TPREL64 = 1030
    COPY = 1024
    IRELATIVE = 1032


class R_ARM(IntEnum):
    """ARM32 ELF relocation types (``R_ARM_*``).

    Only the types processed by :meth:`DynamicLinker._apply_relocation`
    are included.  See *ELF for the Arm Architecture* for the full
    catalogue.
    """
    NONE = 0
    PC24 = 1
    ABS32 = 2
    REL32 = 3
    GLOB_DAT = 21
    JUMP_SLOT = 22
    RELATIVE = 23
    COPY = 20
    TLS_DTPMOD32 = 17
    TLS_DTPOFF32 = 18
    TLS_TPOFF32 = 19
    IRELATIVE = 160


# ==================== Data Structures ====================

@dataclass
class ElfSymbol:
    """A parsed ``Elf{32,64}_Sym`` entry from the ``.dynsym`` table.

    Attributes:
        name:    Symbol name (decoded from ``.dynstr``).
        value:   ``st_value`` -- section-relative offset before relocation.
        size:    ``st_size``  -- object size in bytes (0 if unknown).
        info:    ``st_info``  -- binding (upper nibble) and type (lower
                 nibble) packed into a single byte.
        other:   ``st_other`` -- visibility (lowest 2 bits).
        shndx:   ``st_shndx`` -- section index; ``SHN_UNDEF`` (0) means
                 the symbol is an import.
        address: Resolved virtual address after base relocation.  Zero
                 for undefined (imported) symbols until resolved.
    """

    name: str
    value: int
    size: int
    info: int
    other: int
    shndx: int

    address: int = 0

    @property
    def bind(self) -> int:
        """Symbol binding: ``STB_LOCAL`` (0), ``STB_GLOBAL`` (1), ``STB_WEAK`` (2)."""
        return self.info >> 4

    @property
    def type(self) -> int:
        """Symbol type: ``STT_NOTYPE`` (0), ``STT_FUNC`` (2), ``STT_OBJECT`` (1), etc."""
        return self.info & 0xf

    @property
    def is_weak(self) -> bool:
        """``True`` if the symbol has ``STB_WEAK`` binding."""
        return self.bind == 2  # STB_WEAK

    @property
    def is_undefined(self) -> bool:
        """``True`` if ``st_shndx == SHN_UNDEF`` (the symbol is imported)."""
        return self.shndx == 0  # SHN_UNDEF

    def __repr__(self) -> str:
        return f"ElfSymbol({self.name!r}, addr=0x{self.address:x})"


@dataclass
class ElfRelocation:
    """A parsed ``Elf{32,64}_Rel`` or ``Elf{32,64}_Rela`` entry.

    Attributes:
        offset: ``r_offset`` -- location to patch, relative to the
                library base address.
        info:   ``r_info``   -- packed symbol index + relocation type.
        addend: ``r_addend`` -- explicit addend (RELA only; 0 for REL,
                where the addend is read from memory).
    """

    offset: int
    info: int
    addend: int = 0

    @property
    def sym_idx(self) -> int:
        """Symbol table index extracted from ``r_info``."""
        return self.info >> 32 if self._is_64 else self.info >> 8

    @property
    def type(self) -> int:
        """Relocation type extracted from ``r_info``."""
        return self.info & 0xffffffff if self._is_64 else self.info & 0xff

    _is_64: bool = True


@dataclass
class LoadedLibrary:
    """A shared library that has been mapped into the emulated address space.

    Created by :meth:`DynamicLinker.load_library` after all segments are
    mapped, the dynamic section is parsed, symbols are extracted, and
    relocations are applied.

    Attributes:
        name:             Base filename (e.g. ``"libnative.so"``).
        path:             Absolute filesystem path the library was loaded from.
        base_address:     Virtual address where the first ``PT_LOAD``
                          segment was mapped.
        size:             Total memory footprint (page-aligned).
        symbols:          All parsed ``.dynsym`` entries keyed by name.
        exported_symbols: Defined symbols mapped to their resolved
                          virtual addresses.
        imported_symbols: Names of undefined (imported) symbols.
        init_func:        Address of the ``.init`` function (0 if absent).
        init_array:       Addresses of ``.init_array`` constructors, in
                          order.
        fini_func:        Address of the ``.fini`` function (0 if absent).
        fini_array:       Addresses of ``.fini_array`` destructors, in
                          order.
        needed:           ``DT_NEEDED`` library names (dependencies).
        initialized:      ``True`` after :meth:`DynamicLinker.call_init`
                          has been called for this library.
    """

    name: str
    path: str
    base_address: int
    size: int

    symbols: dict[str, ElfSymbol] = field(default_factory=dict)
    exported_symbols: dict[str, int] = field(default_factory=dict)
    imported_symbols: set[str] = field(default_factory=set)

    init_func: int = 0
    init_array: list[int] = field(default_factory=list)
    fini_func: int = 0
    fini_array: list[int] = field(default_factory=list)

    needed: list[str] = field(default_factory=list)

    initialized: bool = False

    def get_symbol(self, name: str) -> ElfSymbol | None:
        """Look up a symbol by *name* (exports and imports)."""
        return self.symbols.get(name)

    def get_export(self, name: str) -> int | None:
        """Return the address of exported symbol *name*, or ``None``."""
        return self.exported_symbols.get(name)


class DynamicLinker:
    """ELF dynamic linker for the emulated environment.

    Mirrors the behaviour of Android's ``linker64`` / ``linker``:
    loads shared libraries into Unicorn memory, resolves cross-library
    symbol references, applies relocations, and calls constructors.

    The linker maintains:

    * A set of **library search paths** (analogous to ``LD_LIBRARY_PATH``).
    * A **global symbol table** aggregated from every loaded library.
    * **Symbol hooks** that let the caller intercept symbol resolution
      and redirect it to custom addresses (e.g. libc shims).
    * **Stub functions** -- small ``mov r0, #0; bx lr`` / ``ret``
      code snippets generated on the fly for symbols that remain
      unresolved.  This prevents hard crashes from missing imports.
    * **Load / resolve callbacks** for monitoring linker activity.

    Args:
        emulator: The :class:`~pyunidbg.core.emulator.Emulator` instance
            that owns memory and the Unicorn engine.

    Example::

        linker = DynamicLinker(emulator)

        linker.add_library_path("/system/lib64")
        linker.add_library_path("/vendor/lib64")

        lib = linker.load_library("libnative.so")
        linker.call_init(lib)

        addr = linker.resolve_symbol("Java_com_example_Native_init")
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.is_64bit = emulator.arch in ('arm64', 'aarch64')

        # Loaded libraries
        self._libraries: dict[str, LoadedLibrary] = {}
        self._libraries_by_base: dict[int, LoadedLibrary] = {}

        # Global symbol table (for resolution)
        self._global_symbols: dict[str, tuple[LoadedLibrary, int]] = {}

        # Library search paths
        self._library_paths: list[str] = []

        # Symbol hooks (intercept resolution)
        self._symbol_hooks: dict[str, int] = {}

        # Stub generator for undefined symbols
        self._stub_base = 0xDEAD0000
        self._stub_offset = 0
        self._stub_functions: dict[str, int] = {}

        # Callbacks
        self._on_library_load: list[Callable[[LoadedLibrary], None]] = []
        self._on_symbol_resolve: list[Callable[[str, int], None]] = []

        # Relocation types
        if self.is_64bit:
            self.R_GLOB_DAT = R_AARCH64.GLOB_DAT
            self.R_JUMP_SLOT = R_AARCH64.JUMP_SLOT
            self.R_RELATIVE = R_AARCH64.RELATIVE
            self.R_ABS = R_AARCH64.ABS64
            self.R_IRELATIVE = R_AARCH64.IRELATIVE
        else:
            self.R_GLOB_DAT = R_ARM.GLOB_DAT
            self.R_JUMP_SLOT = R_ARM.JUMP_SLOT
            self.R_RELATIVE = R_ARM.RELATIVE
            self.R_ABS = R_ARM.ABS32
            self.R_IRELATIVE = R_ARM.IRELATIVE

    # ==================== Library Paths ====================

    def add_library_path(self, path: str) -> None:
        """Append *path* to the library search list (no duplicates).

        Paths are searched in insertion order by :meth:`find_library`.
        """
        if path not in self._library_paths:
            self._library_paths.append(path)

    def find_library(self, name: str) -> str | None:
        """Locate a library on disk.

        If *name* contains a ``/`` it is treated as an explicit path and
        returned directly when the file exists.  Otherwise each
        registered search path is probed in order.

        Returns:
            Absolute path to the library, or ``None`` if not found.
        """
        # Already a path?
        if '/' in name:
            if Path(name).exists():
                return name
            return None

        # Search in paths
        for lib_path in self._library_paths:
            full_path = Path(lib_path) / name
            if full_path.exists():
                return str(full_path)

        return None

    # ==================== Library Loading ====================

    def load_library(self, name: str, base_address: int = 0) -> LoadedLibrary | None:
        """Load a shared library into the emulated address space.

        The full loading pipeline is:

        1. Return early if the library (by base filename) is already
           loaded.
        2. Resolve the on-disk path via :meth:`find_library`.
        3. Parse the ELF header and program headers.
        4. Allocate page-aligned memory and map ``PT_LOAD`` segments.
        5. Parse the ``PT_DYNAMIC`` segment for metadata.
        6. Recursively load ``DT_NEEDED`` dependencies.
        7. Parse ``.dynsym`` / ``.dynstr`` for symbols.
        8. Apply REL / RELA relocations.
        9. Register the library in internal lookup tables and fire
           load callbacks.

        Args:
            name:         Library name (e.g. ``"libc.so"``) or absolute
                          path.
            base_address: Fixed base address.  When ``0`` (default),
                          memory is allocated automatically via
                          :meth:`~pyunidbg.core.memory.MemoryManager.alloc`.

        Returns:
            The :class:`LoadedLibrary` descriptor, or ``None`` if the
            file could not be found on disk.
        """
        # Already loaded?
        lib_name = Path(name).name
        if lib_name in self._libraries:
            return self._libraries[lib_name]

        # Find library
        lib_path = self.find_library(name)
        if not lib_path:
            logger.warning(f"Library not found: {name}")
            return None

        logger.info(f"Loading library: {lib_path}")

        # Parse ELF
        from .elf import ELFFile

        with open(lib_path, 'rb') as f:
            elf_data = f.read()

        elf = ELFFile(elf_data)

        # Calculate load size
        load_size = self._calculate_load_size(elf)

        # Allocate memory
        if base_address == 0:
            base_address = self.emulator.memory.alloc(load_size, aligned=0x1000)

        # Create library entry
        lib = LoadedLibrary(
            name=lib_name,
            path=lib_path,
            base_address=base_address,
            size=load_size,
        )

        # Load segments
        self._load_segments(elf, lib)

        # Parse dynamic section
        self._parse_dynamic(elf, lib)

        # Load dependencies first
        for needed in lib.needed:
            dep = self.load_library(needed)
            if not dep:
                logger.warning(f"Missing dependency: {needed}")

        # Parse symbols
        self._parse_symbols(elf, lib)

        # Process relocations
        self._process_relocations(elf, lib)

        # Register library
        self._libraries[lib_name] = lib
        self._libraries_by_base[base_address] = lib

        # Export symbols to global table
        for name, addr in lib.exported_symbols.items():
            if name not in self._global_symbols:
                self._global_symbols[name] = (lib, addr)

        # Callbacks
        for callback in self._on_library_load:
            callback(lib)

        logger.info(f"Loaded {lib_name} at 0x{base_address:x} ({len(lib.exported_symbols)} exports)")

        return lib

    def _calculate_load_size(self, elf: 'ELFFile') -> int:
        """Return page-aligned memory span of all ``PT_LOAD`` segments."""
        min_addr = float('inf')
        max_addr = 0

        for phdr in elf.program_headers:
            if phdr.p_type == 1:  # PT_LOAD
                min_addr = min(min_addr, phdr.p_vaddr)
                max_addr = max(max_addr, phdr.p_vaddr + phdr.p_memsz)

        if min_addr == float('inf'):
            return 0

        # Align to page size
        size = max_addr - min_addr
        return (size + 0xfff) & ~0xfff

    def _load_segments(self, elf: 'ELFFile', lib: LoadedLibrary) -> None:
        """Map every ``PT_LOAD`` segment into Unicorn memory.

        For each loadable segment the method:

        1. Calculates the page-aligned virtual address range.
        2. Maps the range in Unicorn (silently ignoring *already-mapped*
           errors so overlapping segments are handled).
        3. Copies ``p_filesz`` bytes from the ELF file.
        4. Zero-fills the remainder up to ``p_memsz`` (``.bss``).
        """
        for phdr in elf.program_headers:
            if phdr.p_type != 1:  # PT_LOAD
                continue

            # Calculate addresses
            file_offset = phdr.p_offset
            file_size = phdr.p_filesz
            mem_size = phdr.p_memsz
            vaddr = lib.base_address + phdr.p_vaddr

            # Map memory if not already mapped
            page_start = vaddr & ~0xfff
            page_end = (vaddr + mem_size + 0xfff) & ~0xfff

            try:
                self.emulator.uc.mem_map(page_start, page_end - page_start)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)  # Already mapped

            # Copy data
            data = elf.data[file_offset:file_offset + file_size]
            self.emulator.uc.mem_write(vaddr, data)

            # Zero BSS
            if mem_size > file_size:
                bss_size = mem_size - file_size
                self.emulator.uc.mem_write(vaddr + file_size, b'\x00' * bss_size)

    def _parse_dynamic(self, elf: 'ELFFile', lib: LoadedLibrary) -> None:
        """Parse the ``PT_DYNAMIC`` segment into *lib* metadata.

        Performs two passes over the dynamic entry array:

        * **Pass 1** -- locate ``DT_STRTAB`` so library names can be
          read from the string table.
        * **Pass 2** -- iterate every ``Elf_Dyn`` entry and populate
          ``lib.needed``, ``lib.init_func``, ``lib.fini_func``,
          ``lib.init_array``, and ``lib.fini_array``.
        """
        # Find PT_DYNAMIC
        dynamic_phdr = None
        for phdr in elf.program_headers:
            if phdr.p_type == 2:  # PT_DYNAMIC
                dynamic_phdr = phdr
                break

        if not dynamic_phdr:
            return

        # Read dynamic entries
        offset = dynamic_phdr.p_offset
        size = dynamic_phdr.p_filesz
        entry_size = 16 if self.is_64bit else 8

        strtab_offset = 0

        # First pass: find STRTAB
        for i in range(0, size, entry_size):
            if self.is_64bit:
                tag, val = struct.unpack('<QQ', elf.data[offset+i:offset+i+16])
            else:
                tag, val = struct.unpack('<II', elf.data[offset+i:offset+i+8])

            if tag == DT.STRTAB:
                strtab_offset = val
                break

        # Second pass: parse all entries
        for i in range(0, size, entry_size):
            if self.is_64bit:
                tag, val = struct.unpack('<QQ', elf.data[offset+i:offset+i+16])
            else:
                tag, val = struct.unpack('<II', elf.data[offset+i:offset+i+8])

            if tag == DT.NULL:
                break
            elif tag == DT.NEEDED:
                # Read library name from strtab
                name = self._read_string(elf.data, strtab_offset + val)
                lib.needed.append(name)
            elif tag == DT.INIT:
                lib.init_func = lib.base_address + val
            elif tag == DT.FINI:
                lib.fini_func = lib.base_address + val
            elif tag == DT.INIT_ARRAY:
                self._dyn_init_array_addr = lib.base_address + val
            elif tag == DT.INIT_ARRAYSZ:
                self._dyn_init_array_size = val
            elif tag == DT.FINI_ARRAY:
                self._dyn_fini_array_addr = lib.base_address + val
            elif tag == DT.FINI_ARRAYSZ:
                self._dyn_fini_array_size = val

        # Parse init/fini arrays
        ptr_size = 8 if self.is_64bit else 4

        if hasattr(self, '_dyn_init_array_addr'):
            count = getattr(self, '_dyn_init_array_size', 0) // ptr_size
            for i in range(count):
                addr = self._dyn_init_array_addr + i * ptr_size
                ptr = self._read_ptr(lib, addr - lib.base_address, elf)
                if ptr:
                    lib.init_array.append(lib.base_address + ptr)

        if hasattr(self, '_dyn_fini_array_addr'):
            count = getattr(self, '_dyn_fini_array_size', 0) // ptr_size
            for i in range(count):
                addr = self._dyn_fini_array_addr + i * ptr_size
                ptr = self._read_ptr(lib, addr - lib.base_address, elf)
                if ptr:
                    lib.fini_array.append(lib.base_address + ptr)

    def _read_string(self, data: bytes, offset: int) -> str:
        """Decode a NUL-terminated UTF-8 string starting at *offset*."""
        end = data.find(b'\x00', offset)
        if end == -1:
            return ""
        return data[offset:end].decode('utf-8', errors='replace')

    def _read_ptr(self, lib: LoadedLibrary, offset: int, elf: 'ELFFile') -> int:
        """Read a pointer-sized integer from the raw ELF *data* at *offset*."""
        if self.is_64bit:
            return struct.unpack('<Q', elf.data[offset:offset+8])[0]
        else:
            return struct.unpack('<I', elf.data[offset:offset+4])[0]

    def _parse_symbols(self, elf: 'ELFFile', lib: LoadedLibrary) -> None:
        """Parse ``.dynsym`` and classify each symbol as export or import.

        Locates the ``SHT_DYNSYM`` section header and its associated
        ``SHT_STRTAB``, then iterates every ``Elf{32,64}_Sym`` entry.
        Defined symbols (``st_shndx != SHN_UNDEF``) are added to
        ``lib.exported_symbols``; undefined ones go into
        ``lib.imported_symbols``.
        """
        # Find .dynsym and .dynstr sections
        dynsym = None
        dynstr = None

        for shdr in elf.section_headers:
            name = shdr.name if hasattr(shdr, 'name') else ''
            if shdr.sh_type == 11:  # SHT_DYNSYM
                dynsym = shdr
            elif shdr.sh_type == 3 and 'str' in name.lower():  # SHT_STRTAB
                if dynstr is None:
                    dynstr = shdr

        if not dynsym:
            return

        # Parse symbols
        sym_size = 24 if self.is_64bit else 16
        sym_count = dynsym.sh_size // sym_size

        for i in range(sym_count):
            offset = dynsym.sh_offset + i * sym_size

            if self.is_64bit:
                st_name, st_info, st_other, st_shndx, st_value, st_size = struct.unpack(
                    '<IBBHQQ', elf.data[offset:offset+24]
                )
            else:
                st_name, st_value, st_size, st_info, st_other, st_shndx = struct.unpack(
                    '<IIIBBH', elf.data[offset:offset+16]
                )

            # Read symbol name
            if dynstr and st_name:
                name = self._read_string(elf.data, dynstr.sh_offset + st_name)
            else:
                name = f"sym_{i}"

            sym = ElfSymbol(
                name=name,
                value=st_value,
                size=st_size,
                info=st_info,
                other=st_other,
                shndx=st_shndx,
                address=lib.base_address + st_value if st_shndx != 0 else 0,
            )

            lib.symbols[name] = sym

            # Track exports and imports
            if st_shndx != 0 and st_value != 0:  # Defined symbol
                lib.exported_symbols[name] = sym.address
            elif st_shndx == 0:  # Undefined (import)
                lib.imported_symbols.add(name)

    def _process_relocations(self, elf: 'ELFFile', lib: LoadedLibrary) -> None:
        """Walk all ``SHT_RELA`` and ``SHT_REL`` sections and apply them."""
        # Find relocation sections
        for shdr in elf.section_headers:
            if shdr.sh_type == 4:  # SHT_RELA
                self._apply_rela(elf, lib, shdr)
            elif shdr.sh_type == 9:  # SHT_REL
                self._apply_rel(elf, lib, shdr)

    def _apply_rela(self, elf: 'ELFFile', lib: LoadedLibrary, shdr) -> None:
        """Apply ``SHT_RELA`` relocations (explicit addend in ``r_addend``)."""
        entry_size = 24 if self.is_64bit else 12
        count = shdr.sh_size // entry_size

        for i in range(count):
            offset = shdr.sh_offset + i * entry_size

            if self.is_64bit:
                r_offset, r_info, r_addend = struct.unpack(
                    '<QQq', elf.data[offset:offset+24]
                )
                r_sym = r_info >> 32
                r_type = r_info & 0xffffffff
            else:
                r_offset, r_info, r_addend = struct.unpack(
                    '<IIi', elf.data[offset:offset+12]
                )
                r_sym = r_info >> 8
                r_type = r_info & 0xff

            self._apply_relocation(lib, r_offset, r_type, r_sym, r_addend)

    def _apply_rel(self, elf: 'ELFFile', lib: LoadedLibrary, shdr) -> None:
        """Apply ``SHT_REL`` relocations (implicit addend read from memory)."""
        entry_size = 16 if self.is_64bit else 8
        count = shdr.sh_size // entry_size

        for i in range(count):
            offset = shdr.sh_offset + i * entry_size

            if self.is_64bit:
                r_offset, r_info = struct.unpack('<QQ', elf.data[offset:offset+16])
                r_sym = r_info >> 32
                r_type = r_info & 0xffffffff
            else:
                r_offset, r_info = struct.unpack('<II', elf.data[offset:offset+8])
                r_sym = r_info >> 8
                r_type = r_info & 0xff

            # Read implicit addend from memory
            addr = lib.base_address + r_offset
            if self.is_64bit:
                r_addend = struct.unpack('<q', self.emulator.uc.mem_read(addr, 8))[0]
            else:
                r_addend = struct.unpack('<i', self.emulator.uc.mem_read(addr, 4))[0]

            self._apply_relocation(lib, r_offset, r_type, r_sym, r_addend)

    def _apply_relocation(self, lib: LoadedLibrary, offset: int,
                          rtype: int, sym_idx: int, addend: int) -> None:
        """Patch a single relocation slot in Unicorn memory.

        Supported relocation semantics:

        ========================  ==========================================
        Type                      Value written
        ========================  ==========================================
        ``R_*_RELATIVE``          ``base_address + addend``
        ``R_*_GLOB_DAT``          resolved symbol address (or stub)
        ``R_*_JUMP_SLOT``         resolved symbol address (or stub)
        ``R_*_ABS{32,64}``        ``symbol + addend``
        ``R_*_IRELATIVE``         result of calling the resolver function
                                  at ``base_address + addend``
        ========================  ==========================================

        When a ``GLOB_DAT`` / ``JUMP_SLOT`` symbol cannot be resolved,
        a return-zero stub is generated via :meth:`_create_stub` so that
        emulation can continue.

        Args:
            lib:      Library being relocated.
            offset:   ``r_offset`` relative to *lib.base_address*.
            rtype:    Architecture-specific relocation type code.
            sym_idx:  Index into *lib.symbols* (0 = no symbol).
            addend:   Addend value (explicit for RELA, implicit for REL).
        """
        addr = lib.base_address + offset

        # Get symbol if needed
        sym_name = ""
        sym_addr = 0

        if sym_idx != 0:
            # Find symbol by index
            symbols = list(lib.symbols.values())
            if sym_idx < len(symbols):
                sym = symbols[sym_idx]
                sym_name = sym.name
                sym_addr = self.resolve_symbol(sym_name)

        # Apply relocation based on type
        if rtype == self.R_RELATIVE:
            # Relative: base + addend
            value = lib.base_address + addend
            self._write_ptr(addr, value)

        elif rtype == self.R_GLOB_DAT or rtype == self.R_JUMP_SLOT:
            # Symbol address
            if sym_addr:
                self._write_ptr(addr, sym_addr)
            else:
                # Create stub for undefined
                stub = self._create_stub(sym_name)
                self._write_ptr(addr, stub)

        elif rtype == self.R_ABS:
            # Absolute: symbol + addend
            value = sym_addr + addend
            self._write_ptr(addr, value)

        elif rtype == self.R_IRELATIVE:
            # Indirect: call resolver function to get actual address
            resolver = lib.base_address + addend
            try:
                # Call the resolver function - it returns the actual target address
                result = self.emulator.call(resolver, args=[])
                self._write_ptr(addr, result)
                logger.debug(f"IRELATIVE: resolver 0x{resolver:x} -> 0x{result:x}")
            except Exception as e:
                # If resolver fails, fall back to writing resolver address
                logger.warning(f"IRELATIVE resolver at 0x{resolver:x} failed: {e}")
                self._write_ptr(addr, resolver)

    def _write_ptr(self, addr: int, value: int) -> None:
        """Write a pointer-sized little-endian integer to Unicorn memory."""
        if self.is_64bit:
            self.emulator.uc.mem_write(addr, struct.pack('<Q', value))
        else:
            self.emulator.uc.mem_write(addr, struct.pack('<I', value & 0xffffffff))

    def _create_stub(self, name: str) -> int:
        """Allocate a tiny return-zero stub for unresolved symbol *name*.

        Stubs are 256-byte-aligned entries starting at ``0xDEAD0000``.
        Each stub is a minimal two-instruction sequence
        (``mov r0/x0, #0 ; bx lr / ret``) so that calls to missing
        imports return 0 without crashing.  The same address is
        returned for repeated requests with the same *name*.

        Returns:
            Address of the stub code.
        """
        if name in self._stub_functions:
            return self._stub_functions[name]

        # Allocate stub
        stub_addr = self._stub_base + self._stub_offset
        self._stub_offset += 0x100

        # Map stub memory if needed
        page = stub_addr & ~0xfff
        try:
            self.emulator.uc.mem_map(page, 0x1000)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        # Write stub code (just return 0)
        if self.is_64bit:
            # mov x0, #0; ret
            code = bytes([0x00, 0x00, 0x80, 0xd2, 0xc0, 0x03, 0x5f, 0xd6])
        else:
            # mov r0, #0; bx lr
            code = bytes([0x00, 0x00, 0xa0, 0xe3, 0x1e, 0xff, 0x2f, 0xe1])

        self.emulator.uc.mem_write(stub_addr, code)

        self._stub_functions[name] = stub_addr
        logger.debug(f"Created stub for {name} at 0x{stub_addr:x}")

        return stub_addr

    # ==================== Symbol Resolution ====================

    def resolve_symbol(self, name: str) -> int:
        """Resolve a symbol *name* to a virtual address.

        Resolution order:

        1. **Symbol hooks** -- addresses registered via
           :meth:`add_symbol_hook` take absolute priority.
        2. **Global symbol table** -- aggregated exports from every
           loaded library (first-registered wins).
        3. **Per-library scan** -- fall-back linear search of all
           loaded libraries' export tables.

        If no match is found, ``0`` is returned.  Callers in the
        relocation pipeline may then generate a stub via
        :meth:`_create_stub`.

        Args:
            name: Symbol name to resolve.

        Returns:
            Resolved virtual address, or ``0`` if unresolved.
        """
        # Check hooks first
        if name in self._symbol_hooks:
            return self._symbol_hooks[name]

        # Check global symbols
        if name in self._global_symbols:
            lib, addr = self._global_symbols[name]

            for callback in self._on_symbol_resolve:
                callback(name, addr)

            return addr

        # Check all libraries
        for lib in self._libraries.values():
            addr = lib.get_export(name)
            if addr:
                return addr

        # Not found - return 0 (caller may create stub)
        return 0

    def add_symbol_hook(self, name: str, address: int) -> None:
        """Register a hook so that *name* always resolves to *address*.

        This takes priority over any library-provided definition.
        Useful for redirecting libc functions to emulator-provided
        implementations.
        """
        self._symbol_hooks[name] = address

    def remove_symbol_hook(self, name: str) -> bool:
        """Remove a previously registered symbol hook.

        Returns:
            ``True`` if the hook existed and was removed, ``False``
            otherwise.
        """
        if name in self._symbol_hooks:
            del self._symbol_hooks[name]
            return True
        return False

    # ==================== Library Init/Fini ====================

    def call_init(self, lib: LoadedLibrary) -> None:
        """Run *lib*'s constructors (idempotent).

        Recursively initialises dependencies first, then calls the
        ``.init`` function and every ``.init_array`` entry in order.
        Sets ``lib.initialized = True`` so repeat calls are no-ops.
        """
        if lib.initialized:
            return

        # Call dependencies first
        for needed in lib.needed:
            if needed in self._libraries:
                self.call_init(self._libraries[needed])

        # Call .init
        if lib.init_func:
            logger.debug(f"Calling {lib.name} .init at 0x{lib.init_func:x}")
            self._call_function(lib.init_func)

        # Call .init_array
        for func in lib.init_array:
            logger.debug(f"Calling {lib.name} init_array func at 0x{func:x}")
            self._call_function(func)

        lib.initialized = True

    def call_fini(self, lib: LoadedLibrary) -> None:
        """Run *lib*'s destructors.

        Calls ``.fini_array`` entries in **reverse** order, then the
        ``.fini`` function -- mirroring the C runtime tear-down
        sequence.
        """
        # Call .fini_array in reverse
        for func in reversed(lib.fini_array):
            self._call_function(func)

        # Call .fini
        if lib.fini_func:
            self._call_function(lib.fini_func)

    def _call_function(self, addr: int) -> int:
        """Invoke the function at *addr* in the Unicorn engine.

        Sets ``LR`` to a sentinel (``0xDEADBEEF``) and emulates until
        ``PC == LR``.  Returns the value left in ``x0`` / ``r0``.
        """
        # Set return address to special value
        ret_addr = 0xDEADBEEF

        if self.is_64bit:
            self.emulator.uc.reg_write(self.emulator.lr_reg, ret_addr)
        else:
            self.emulator.uc.reg_write(self.emulator.lr_reg, ret_addr)

        # Run until return
        try:
            self.emulator.uc.emu_start(addr, ret_addr, timeout=0, count=0)
        except Exception as e:
            logger.error(f"Init function failed at 0x{addr:x}: {e}")

        # Return value in x0/r0
        return self.emulator.uc.reg_read(self.emulator.regs['x0' if self.is_64bit else 'r0'])

    # ==================== Queries ====================

    def get_library(self, name: str) -> LoadedLibrary | None:
        """Return the :class:`LoadedLibrary` for *name*, or ``None``."""
        return self._libraries.get(name)

    def get_library_at(self, address: int) -> LoadedLibrary | None:
        """Return the library whose address range contains *address*.

        Performs a linear scan; suitable for diagnostic lookups, not
        hot-path use.
        """
        for lib in self._libraries.values():
            if lib.base_address <= address < lib.base_address + lib.size:
                return lib
        return None

    def list_libraries(self) -> list[LoadedLibrary]:
        """Return a list of all currently loaded libraries."""
        return list(self._libraries.values())

    def list_symbols(self, library: str = None) -> dict[str, int]:
        """Return a ``{name: address}`` mapping of exported symbols.

        Args:
            library: If given, restrict to that library's exports.
                     If ``None``, return the merged global symbol table.
        """
        if library:
            lib = self._libraries.get(library)
            return lib.exported_symbols if lib else {}
        return {name: addr for name, (_, addr) in self._global_symbols.items()}

    # ==================== Callbacks ====================

    def on_library_load(self, callback: Callable[[LoadedLibrary], None]) -> None:
        """Register a callback invoked after every successful library load.

        The callback receives the newly created :class:`LoadedLibrary`.
        """
        self._on_library_load.append(callback)

    def on_symbol_resolve(self, callback: Callable[[str, int], None]) -> None:
        """Register a callback invoked when a symbol is resolved from the
        global table.

        The callback receives ``(name, address)``.
        """
        self._on_symbol_resolve.append(callback)
