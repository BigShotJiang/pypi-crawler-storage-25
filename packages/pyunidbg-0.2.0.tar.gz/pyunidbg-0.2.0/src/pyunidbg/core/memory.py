"""Memory management for the emulator."""

from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import TYPE_CHECKING

from unicorn import UC_PROT_ALL, UC_PROT_EXEC, UC_PROT_READ, UC_PROT_WRITE, Uc

from pyunidbg.core.constants import (
    Architecture,
    Endianness,
    MemoryLayout,
    MemoryProtection,
)

if TYPE_CHECKING:
    pass


# Map our protection flags to Unicorn
PROT_MAP = {
    MemoryProtection.NONE: 0,
    MemoryProtection.READ: UC_PROT_READ,
    MemoryProtection.WRITE: UC_PROT_WRITE,
    MemoryProtection.EXEC: UC_PROT_EXEC,
    MemoryProtection.READ_WRITE: UC_PROT_READ | UC_PROT_WRITE,
    MemoryProtection.READ_EXEC: UC_PROT_READ | UC_PROT_EXEC,
    MemoryProtection.READ_WRITE_EXEC: UC_PROT_ALL,
    MemoryProtection.ALL: UC_PROT_ALL,
}


@dataclass
class MemoryRegion:
    """Represents a mapped memory region."""

    start: int
    size: int
    protection: MemoryProtection
    name: str = ""
    file_path: str | None = None
    file_offset: int = 0

    @property
    def end(self) -> int:
        """End address (exclusive)."""
        return self.start + self.size

    def contains(self, address: int) -> bool:
        """Check if address is within this region."""
        return self.start <= address < self.end

    def overlaps(self, start: int, size: int) -> bool:
        """Check if given range overlaps with this region."""
        return not (start >= self.end or start + size <= self.start)

    def __repr__(self) -> str:
        prot_str = ""
        if self.protection & MemoryProtection.READ:
            prot_str += "r"
        else:
            prot_str += "-"
        if self.protection & MemoryProtection.WRITE:
            prot_str += "w"
        else:
            prot_str += "-"
        if self.protection & MemoryProtection.EXEC:
            prot_str += "x"
        else:
            prot_str += "-"

        return (
            f"MemoryRegion({self.start:#x}-{self.end:#x} "
            f"[{prot_str}] {self.name!r})"
        )


class MemoryManager:
    """
    Manages memory allocation and access for the emulator.
    
    Handles:
    - Memory mapping and unmapping
    - Read/write operations
    - Stack and heap management
    - Memory protection
    """

    def __init__(
        self,
        uc: Uc,
        arch: Architecture,
        endianness: Endianness = Endianness.LITTLE,
    ):
        self._uc = uc
        self._arch = arch
        self._endianness = endianness
        self._regions: list[MemoryRegion] = []
        self._next_alloc = MemoryLayout.HEAP_BASE
        self._next_lib_addr = MemoryLayout.LIBRARY_BASE

        # Pointer size based on architecture
        self._ptr_size = 8 if arch in (Architecture.ARM64, Architecture.X86_64) else 4

        # Setup stack
        self._setup_stack()

    def _setup_stack(self) -> None:
        """Initialize the stack region."""
        self.map(
            MemoryLayout.STACK_BASE - MemoryLayout.STACK_SIZE,
            MemoryLayout.STACK_SIZE,
            MemoryProtection.READ_WRITE,
            name="[stack]",
        )
        self._stack_top = MemoryLayout.STACK_BASE

    @property
    def stack_top(self) -> int:
        """Get the top of the stack."""
        return self._stack_top

    @property
    def pointer_size(self) -> int:
        """Get pointer size in bytes."""
        return self._ptr_size

    def map(
        self,
        address: int,
        size: int,
        protection: MemoryProtection = MemoryProtection.READ_WRITE,
        name: str = "",
    ) -> MemoryRegion:
        """
        Map a memory region.
        
        Args:
            address: Start address (will be page-aligned)
            size: Size in bytes (will be page-aligned)
            protection: Memory protection flags
            name: Optional name for the region
        
        Returns:
            The created MemoryRegion
        """
        # Page align
        aligned_addr = MemoryLayout.align_down(address)
        aligned_size = MemoryLayout.align_up(size + (address - aligned_addr))

        # Check for overlaps
        for region in self._regions:
            if region.overlaps(aligned_addr, aligned_size):
                raise ValueError(
                    f"Memory region {aligned_addr:#x}-{aligned_addr + aligned_size:#x} "
                    f"overlaps with existing region {region}"
                )

        # Map in Unicorn
        uc_prot = PROT_MAP.get(protection, UC_PROT_ALL)
        self._uc.mem_map(aligned_addr, aligned_size, uc_prot)

        # Create and track region
        region = MemoryRegion(
            start=aligned_addr,
            size=aligned_size,
            protection=protection,
            name=name,
        )
        self._regions.append(region)
        self._regions.sort(key=lambda r: r.start)

        return region

    def unmap(self, address: int, size: int) -> None:
        """Unmap a memory region."""
        aligned_addr = MemoryLayout.align_down(address)
        aligned_size = MemoryLayout.align_up(size)

        self._uc.mem_unmap(aligned_addr, aligned_size)

        # Remove from tracking
        self._regions = [
            r for r in self._regions
            if not (r.start == aligned_addr and r.size == aligned_size)
        ]

    def protect(self, address: int, size: int, protection: MemoryProtection) -> None:
        """Change memory protection for a region."""
        aligned_addr = MemoryLayout.align_down(address)
        aligned_size = MemoryLayout.align_up(size)

        uc_prot = PROT_MAP.get(protection, UC_PROT_ALL)
        self._uc.mem_protect(aligned_addr, aligned_size, uc_prot)

        # Update tracking
        for region in self._regions:
            if region.start == aligned_addr and region.size == aligned_size:
                region.protection = protection
                break

    def find_region(self, address: int) -> MemoryRegion | None:
        """Find the region containing the given address."""
        for region in self._regions:
            if region.contains(address):
                return region
        return None

    def is_mapped(self, address: int, size: int = 1) -> bool:
        """Check if the given address range is mapped."""
        end = address + size
        current = address

        while current < end:
            region = self.find_region(current)
            if region is None:
                return False
            current = region.end

        return True

    def allocate(
        self,
        size: int,
        protection: MemoryProtection = MemoryProtection.READ_WRITE,
        name: str = "[heap]",
    ) -> int:
        """
        Allocate memory from the heap.
        
        Args:
            size: Size to allocate
            protection: Memory protection
            name: Name for the region
        
        Returns:
            Address of allocated memory
        """
        aligned_size = MemoryLayout.align_up(size)
        address = self._next_alloc

        self.map(address, aligned_size, protection, name)
        self._next_alloc += aligned_size

        return address

    def allocate_lib_space(self, size: int) -> int:
        """
        Allocate space for loading a library.
        
        Returns:
            Base address for the library
        """
        aligned_size = MemoryLayout.align_up(size)
        address = self._next_lib_addr

        if address + aligned_size > MemoryLayout.LIBRARY_MAX:
            raise MemoryError("Library address space exhausted")

        self._next_lib_addr += aligned_size
        return address

    # Read operations

    def read(self, address: int, size: int) -> bytes:
        """Read bytes from memory."""
        result = self._uc.mem_read(address, size)
        # mem_read returns bytearray but mem_write expects bytes
        return bytes(result) if isinstance(result, bytearray) else result

    def read_u8(self, address: int) -> int:
        """Read unsigned 8-bit value."""
        return struct.unpack("B", self.read(address, 1))[0]

    def read_u16(self, address: int) -> int:
        """Read unsigned 16-bit value."""
        fmt = "<H" if self._endianness == Endianness.LITTLE else ">H"
        return struct.unpack(fmt, self.read(address, 2))[0]

    def read_u32(self, address: int) -> int:
        """Read unsigned 32-bit value."""
        fmt = "<I" if self._endianness == Endianness.LITTLE else ">I"
        return struct.unpack(fmt, self.read(address, 4))[0]

    def read_u64(self, address: int) -> int:
        """Read unsigned 64-bit value."""
        fmt = "<Q" if self._endianness == Endianness.LITTLE else ">Q"
        return struct.unpack(fmt, self.read(address, 8))[0]

    def read_ptr(self, address: int) -> int:
        """Read a pointer value."""
        if self._ptr_size == 8:
            return self.read_u64(address)
        return self.read_u32(address)

    def read_string(self, address: int, max_length: int = 4096) -> str:
        """Read a null-terminated string."""
        data = bytearray()
        for i in range(max_length):
            byte = self.read_u8(address + i)
            if byte == 0:
                break
            data.append(byte)
        return data.decode("utf-8", errors="replace")

    def read_wstring(self, address: int, max_length: int = 4096) -> str:
        """Read a null-terminated wide string (UTF-16)."""
        data = bytearray()
        for i in range(0, max_length * 2, 2):
            word = self.read_u16(address + i)
            if word == 0:
                break
            data.extend(struct.pack("<H", word))
        return data.decode("utf-16-le", errors="replace")

    # Write operations

    def write(self, address: int, data: bytes) -> None:
        """Write bytes to memory."""
        self._uc.mem_write(address, data)

    def write_u8(self, address: int, value: int) -> None:
        """Write unsigned 8-bit value."""
        self.write(address, struct.pack("B", value & 0xFF))

    def write_u16(self, address: int, value: int) -> None:
        """Write unsigned 16-bit value."""
        fmt = "<H" if self._endianness == Endianness.LITTLE else ">H"
        self.write(address, struct.pack(fmt, value & 0xFFFF))

    def write_u32(self, address: int, value: int) -> None:
        """Write unsigned 32-bit value."""
        fmt = "<I" if self._endianness == Endianness.LITTLE else ">I"
        self.write(address, struct.pack(fmt, value & 0xFFFFFFFF))

    def write_u64(self, address: int, value: int) -> None:
        """Write unsigned 64-bit value."""
        fmt = "<Q" if self._endianness == Endianness.LITTLE else ">Q"
        self.write(address, struct.pack(fmt, value & 0xFFFFFFFFFFFFFFFF))

    def write_ptr(self, address: int, value: int) -> None:
        """Write a pointer value."""
        if self._ptr_size == 8:
            self.write_u64(address, value)
        else:
            self.write_u32(address, value)

    def write_string(self, address: int, string: str) -> int:
        """
        Write a null-terminated string.
        
        Returns:
            Number of bytes written (including null terminator)
        """
        data = string.encode("utf-8") + b"\x00"
        self.write(address, data)
        return len(data)

    def alloc_string(self, string: str) -> int:
        """
        Allocate memory and write a string.
        
        Returns:
            Address of the string
        """
        data = string.encode("utf-8") + b"\x00"
        address = self.allocate(len(data), name=f"[string: {string[:20]}...]")
        self.write(address, data)
        return address

    # Stack operations

    def push(self, value: int) -> int:
        """Push a value onto the stack."""
        self._stack_top -= self._ptr_size
        self.write_ptr(self._stack_top, value)
        return self._stack_top

    def pop(self) -> int:
        """Pop a value from the stack."""
        value = self.read_ptr(self._stack_top)
        self._stack_top += self._ptr_size
        return value

    def get_regions(self) -> list[MemoryRegion]:
        """Get all mapped memory regions."""
        return list(self._regions)

    def dump_maps(self) -> str:
        """Get a string representation of memory maps (like /proc/pid/maps)."""
        lines = []
        for region in self._regions:
            prot = ""
            prot += "r" if region.protection & MemoryProtection.READ else "-"
            prot += "w" if region.protection & MemoryProtection.WRITE else "-"
            prot += "x" if region.protection & MemoryProtection.EXEC else "-"
            prot += "p"  # Private

            lines.append(
                f"{region.start:012x}-{region.end:012x} {prot} "
                f"{region.file_offset:08x} 00:00 0 {region.name}"
            )
        return "\n".join(lines)

    def hexdump(self, address: int, size: int, width: int = 16) -> str:
        """
        Create a hex dump of memory.
        
        Args:
            address: Start address
            size: Number of bytes
            width: Bytes per line
        
        Returns:
            Formatted hex dump string
        """
        lines = []
        data = self.read(address, size)

        for i in range(0, len(data), width):
            chunk = data[i:i + width]
            hex_part = " ".join(f"{b:02x}" for b in chunk)
            ascii_part = "".join(
                chr(b) if 32 <= b < 127 else "."
                for b in chunk
            )
            lines.append(f"{address + i:08x}  {hex_part:<{width*3}}  {ascii_part}")

        return "\n".join(lines)
