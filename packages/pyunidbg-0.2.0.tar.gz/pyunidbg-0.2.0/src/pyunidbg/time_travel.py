"""
Time-Travel Debugging module for PyUniDbg.

This module provides functionality for recording and replaying
execution, allowing users to step backwards through execution
and inspect past states:

Features:
- Execution recording with configurable granularity
- Forward and backward stepping
- State inspection at any point in time
- Memory and register history
- Breakpoint on past conditions
- Execution replay and modification
"""

import logging
import time
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntEnum, auto
from typing import Any

logger = logging.getLogger(__name__)


class RecordingState(IntEnum):
    """Recording state."""
    IDLE = auto()
    RECORDING = auto()
    PAUSED = auto()
    REPLAYING = auto()


class StepDirection(IntEnum):
    """Step direction for time travel."""
    FORWARD = auto()
    BACKWARD = auto()


class EventType(IntEnum):
    """Types of recorded events."""
    INSTRUCTION = auto()
    MEMORY_READ = auto()
    MEMORY_WRITE = auto()
    REGISTER_CHANGE = auto()
    SYSCALL = auto()
    EXCEPTION = auto()
    BREAKPOINT = auto()
    FUNCTION_CALL = auto()
    FUNCTION_RETURN = auto()


class RecordingGranularity(IntEnum):
    """Recording granularity levels."""
    MINIMAL = 1      # Only basic execution flow
    STANDARD = 2     # Instruction + registers
    DETAILED = 3     # + memory operations
    COMPREHENSIVE = 4  # Everything including syscalls


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class RegisterState:
    """Register state at a point in time."""
    values: dict[str, int] = field(default_factory=dict)

    def get(self, name: str) -> int | None:
        """Get register value."""
        return self.values.get(name.lower())

    def set(self, name: str, value: int) -> None:
        """Set register value."""
        self.values[name.lower()] = value

    def copy(self) -> 'RegisterState':
        """Create a copy."""
        return RegisterState(values=self.values.copy())

    def to_dict(self) -> dict[str, int]:
        """Convert to dictionary."""
        return self.values.copy()


@dataclass
class MemoryState:
    """Memory state at a point in time."""
    regions: dict[int, bytes] = field(default_factory=dict)

    def read(self, address: int, size: int) -> bytes | None:
        """Read memory at address."""
        # Find region containing this address
        for base, data in self.regions.items():
            if base <= address < base + len(data):
                offset = address - base
                if offset + size <= len(data):
                    return data[offset:offset + size]
        return None

    def write(self, address: int, data: bytes) -> None:
        """Write memory at address."""
        # Find or create region
        for base in list(self.regions.keys()):
            region_data = self.regions[base]
            if base <= address < base + len(region_data):
                offset = address - base
                new_data = bytearray(region_data)
                new_data[offset:offset + len(data)] = data
                self.regions[base] = bytes(new_data)
                return

        # Create new region
        self.regions[address] = data

    def copy(self) -> 'MemoryState':
        """Create a copy."""
        return MemoryState(regions={k: v for k, v in self.regions.items()})


@dataclass
class ExecutionEvent:
    """A single execution event."""
    event_id: int
    timestamp: float
    event_type: EventType
    address: int
    data: dict[str, Any] = field(default_factory=dict)
    register_changes: dict[str, tuple[int, int]] = field(default_factory=dict)  # name -> (old, new)
    memory_changes: list[tuple[int, bytes, bytes]] = field(default_factory=list)  # (addr, old, new)

    def __str__(self) -> str:
        return f"Event {self.event_id}: {self.event_type.name} @ {hex(self.address)}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'event_id': self.event_id,
            'timestamp': self.timestamp,
            'event_type': self.event_type.name,
            'address': hex(self.address),
            'data': self.data,
        }


@dataclass
class ExecutionSnapshot:
    """Complete execution state at a point in time."""
    event_id: int
    timestamp: float
    registers: RegisterState
    memory: MemoryState
    instruction: str = ""
    address: int = 0
    call_stack: list[int] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'event_id': self.event_id,
            'timestamp': self.timestamp,
            'registers': self.registers.to_dict(),
            'instruction': self.instruction,
            'address': hex(self.address),
            'call_stack_depth': len(self.call_stack),
        }


@dataclass
class RecordingSession:
    """A complete recording session."""
    session_id: str
    start_time: float
    end_time: float | None
    granularity: RecordingGranularity
    events: list[ExecutionEvent] = field(default_factory=list)
    snapshots: dict[int, ExecutionSnapshot] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def event_count(self) -> int:
        """Get number of events."""
        return len(self.events)

    @property
    def duration(self) -> float:
        """Get recording duration."""
        if self.end_time:
            return self.end_time - self.start_time
        return time.time() - self.start_time

    def __str__(self) -> str:
        return f"Session {self.session_id}: {self.event_count} events"


@dataclass
class TimelinePosition:
    """Current position in the recording timeline."""
    event_index: int
    total_events: int
    timestamp: float
    address: int

    @property
    def progress(self) -> float:
        """Get progress as percentage."""
        if self.total_events == 0:
            return 0.0
        return (self.event_index / self.total_events) * 100.0

    @property
    def is_at_start(self) -> bool:
        """Check if at start."""
        return self.event_index == 0

    @property
    def is_at_end(self) -> bool:
        """Check if at end."""
        return self.event_index >= self.total_events - 1


@dataclass
class TimeTravelBreakpoint:
    """Breakpoint for time-travel debugging."""
    breakpoint_id: int
    condition: Callable[[ExecutionEvent], bool]
    description: str = ""
    hit_count: int = 0
    enabled: bool = True

    def check(self, event: ExecutionEvent) -> bool:
        """Check if breakpoint is hit."""
        if not self.enabled:
            return False
        try:
            return self.condition(event)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return False


# =============================================================================
# Recording Engine
# =============================================================================

class RecordingEngine:
    """Engine for recording execution."""

    def __init__(self, granularity: RecordingGranularity = RecordingGranularity.STANDARD):
        self._state = RecordingState.IDLE
        self._granularity = granularity
        self._current_session: RecordingSession | None = None
        self._event_counter = 0
        self._snapshot_interval = 1000  # Snapshot every N events
        self._current_registers = RegisterState()
        self._current_memory = MemoryState()
        self._call_stack: list[int] = []

    @property
    def state(self) -> RecordingState:
        """Get current state."""
        return self._state

    @property
    def is_recording(self) -> bool:
        """Check if recording."""
        return self._state == RecordingState.RECORDING

    @property
    def current_session(self) -> RecordingSession | None:
        """Get current session."""
        return self._current_session

    @property
    def granularity(self) -> RecordingGranularity:
        """Get recording granularity."""
        return self._granularity

    def set_granularity(self, granularity: RecordingGranularity) -> None:
        """Set recording granularity."""
        self._granularity = granularity

    def set_snapshot_interval(self, interval: int) -> None:
        """Set snapshot interval."""
        self._snapshot_interval = max(1, interval)

    def start_recording(self, session_id: str | None = None) -> RecordingSession:
        """Start a new recording session."""
        if self._state == RecordingState.RECORDING:
            self.stop_recording()

        self._current_session = RecordingSession(
            session_id=session_id or f"session_{int(time.time())}",
            start_time=time.time(),
            end_time=None,
            granularity=self._granularity,
        )
        self._event_counter = 0
        self._state = RecordingState.RECORDING

        # Create initial snapshot
        self._take_snapshot()

        return self._current_session

    def stop_recording(self) -> RecordingSession | None:
        """Stop recording and return session."""
        if self._current_session:
            self._current_session.end_time = time.time()

        session = self._current_session
        self._state = RecordingState.IDLE
        return session

    def pause_recording(self) -> None:
        """Pause recording."""
        if self._state == RecordingState.RECORDING:
            self._state = RecordingState.PAUSED

    def resume_recording(self) -> None:
        """Resume recording."""
        if self._state == RecordingState.PAUSED:
            self._state = RecordingState.RECORDING

    def record_instruction(self, address: int, instruction: str,
                          registers: dict[str, int] | None = None,
                          memory_ops: list[dict] | None = None) -> ExecutionEvent | None:
        """Record an instruction execution."""
        if self._state != RecordingState.RECORDING or not self._current_session:
            return None

        # Create event
        event = ExecutionEvent(
            event_id=self._event_counter,
            timestamp=time.time(),
            event_type=EventType.INSTRUCTION,
            address=address,
            data={'instruction': instruction},
        )

        # Record register changes
        if registers and self._granularity >= RecordingGranularity.STANDARD:
            for name, value in registers.items():
                old_value = self._current_registers.get(name)
                if old_value != value:
                    event.register_changes[name] = (old_value or 0, value)
                    self._current_registers.set(name, value)

        # Record memory operations
        if memory_ops and self._granularity >= RecordingGranularity.DETAILED:
            for op in memory_ops:
                if op.get('type') == 'write':
                    addr = op.get('address', 0)
                    old_data = self._current_memory.read(addr, len(op.get('data', b''))) or b''
                    new_data = op.get('data', b'')
                    event.memory_changes.append((addr, old_data, new_data))
                    self._current_memory.write(addr, new_data)

        self._current_session.events.append(event)
        self._event_counter += 1

        # Take periodic snapshots
        if self._event_counter % self._snapshot_interval == 0:
            self._take_snapshot()

        return event

    def record_memory_access(self, address: int, data: bytes,
                            is_write: bool) -> ExecutionEvent | None:
        """Record a memory access."""
        if self._state != RecordingState.RECORDING or not self._current_session:
            return None

        if self._granularity < RecordingGranularity.DETAILED:
            return None

        event = ExecutionEvent(
            event_id=self._event_counter,
            timestamp=time.time(),
            event_type=EventType.MEMORY_WRITE if is_write else EventType.MEMORY_READ,
            address=address,
            data={
                'size': len(data),
                'is_write': is_write,
            },
        )

        if is_write:
            old_data = self._current_memory.read(address, len(data)) or b''
            event.memory_changes.append((address, old_data, data))
            self._current_memory.write(address, data)

        self._current_session.events.append(event)
        self._event_counter += 1

        return event

    def record_syscall(self, syscall_num: int, args: list[int],
                       result: int) -> ExecutionEvent | None:
        """Record a system call."""
        if self._state != RecordingState.RECORDING or not self._current_session:
            return None

        if self._granularity < RecordingGranularity.COMPREHENSIVE:
            return None

        event = ExecutionEvent(
            event_id=self._event_counter,
            timestamp=time.time(),
            event_type=EventType.SYSCALL,
            address=0,
            data={
                'syscall_num': syscall_num,
                'args': args,
                'result': result,
            },
        )

        self._current_session.events.append(event)
        self._event_counter += 1

        return event

    def record_function_call(self, address: int, return_address: int,
                            args: list[int] | None = None) -> ExecutionEvent | None:
        """Record a function call."""
        if self._state != RecordingState.RECORDING or not self._current_session:
            return None

        event = ExecutionEvent(
            event_id=self._event_counter,
            timestamp=time.time(),
            event_type=EventType.FUNCTION_CALL,
            address=address,
            data={
                'return_address': return_address,
                'args': args or [],
            },
        )

        self._call_stack.append(return_address)
        self._current_session.events.append(event)
        self._event_counter += 1

        return event

    def record_function_return(self, address: int,
                               return_value: int | None = None) -> ExecutionEvent | None:
        """Record a function return."""
        if self._state != RecordingState.RECORDING or not self._current_session:
            return None

        event = ExecutionEvent(
            event_id=self._event_counter,
            timestamp=time.time(),
            event_type=EventType.FUNCTION_RETURN,
            address=address,
            data={
                'return_value': return_value,
            },
        )

        if self._call_stack:
            self._call_stack.pop()

        self._current_session.events.append(event)
        self._event_counter += 1

        return event

    def _take_snapshot(self) -> None:
        """Take a state snapshot."""
        if not self._current_session:
            return

        snapshot = ExecutionSnapshot(
            event_id=self._event_counter,
            timestamp=time.time(),
            registers=self._current_registers.copy(),
            memory=self._current_memory.copy(),
            call_stack=self._call_stack.copy(),
        )

        self._current_session.snapshots[self._event_counter] = snapshot

    def set_initial_state(self, registers: dict[str, int],
                          memory_regions: dict[int, bytes]) -> None:
        """Set initial state for recording."""
        for name, value in registers.items():
            self._current_registers.set(name, value)

        for address, data in memory_regions.items():
            self._current_memory.write(address, data)


# =============================================================================
# Replay Engine
# =============================================================================

class ReplayEngine:
    """Engine for replaying recorded execution."""

    def __init__(self):
        self._session: RecordingSession | None = None
        self._position: int = 0
        self._state = RecordingState.IDLE
        self._current_registers = RegisterState()
        self._current_memory = MemoryState()
        self._breakpoints: dict[int, TimeTravelBreakpoint] = {}
        self._next_breakpoint_id = 1

    @property
    def state(self) -> RecordingState:
        """Get current state."""
        return self._state

    @property
    def position(self) -> TimelinePosition:
        """Get current timeline position."""
        event_count = len(self._session.events) if self._session else 0
        event = self._session.events[self._position] if self._session and event_count > 0 else None

        return TimelinePosition(
            event_index=self._position,
            total_events=event_count,
            timestamp=event.timestamp if event else 0.0,
            address=event.address if event else 0,
        )

    @property
    def current_event(self) -> ExecutionEvent | None:
        """Get current event."""
        if not self._session or self._position >= len(self._session.events):
            return None
        return self._session.events[self._position]

    @property
    def current_registers(self) -> RegisterState:
        """Get current register state."""
        return self._current_registers

    @property
    def current_memory(self) -> MemoryState:
        """Get current memory state."""
        return self._current_memory

    def load_session(self, session: RecordingSession) -> bool:
        """Load a recording session."""
        self._session = session
        self._position = 0
        self._state = RecordingState.REPLAYING
        self._restore_snapshot(0)
        return True

    def unload_session(self) -> None:
        """Unload current session."""
        self._session = None
        self._position = 0
        self._state = RecordingState.IDLE
        self._current_registers = RegisterState()
        self._current_memory = MemoryState()

    def step_forward(self, count: int = 1) -> list[ExecutionEvent]:
        """Step forward in time."""
        if not self._session:
            return []

        events = []
        for _ in range(count):
            if self._position >= len(self._session.events) - 1:
                break

            # Apply current event's changes
            event = self._session.events[self._position]
            self._apply_event_forward(event)
            self._position += 1
            events.append(event)

            # Check breakpoints
            if self._check_breakpoints(self._session.events[self._position]):
                break

        return events

    def step_backward(self, count: int = 1) -> list[ExecutionEvent]:
        """Step backward in time."""
        if not self._session:
            return []

        events = []
        for _ in range(count):
            if self._position <= 0:
                break

            # Undo current event's changes
            event = self._session.events[self._position]
            self._apply_event_backward(event)
            self._position -= 1
            events.append(event)

            # Check breakpoints
            if self._check_breakpoints(self._session.events[self._position]):
                break

        return events

    def goto_event(self, event_index: int) -> bool:
        """Go to a specific event."""
        if not self._session:
            return False

        if event_index < 0 or event_index >= len(self._session.events):
            return False

        # Find nearest snapshot
        self._restore_snapshot(event_index)

        # Step to desired position
        while self._position < event_index:
            self._apply_event_forward(self._session.events[self._position])
            self._position += 1

        return True

    def goto_start(self) -> bool:
        """Go to the start of the recording."""
        return self.goto_event(0)

    def goto_end(self) -> bool:
        """Go to the end of the recording."""
        if not self._session:
            return False
        return self.goto_event(len(self._session.events) - 1)

    def continue_forward(self) -> ExecutionEvent | None:
        """Continue forward until breakpoint."""
        if not self._session:
            return None

        while self._position < len(self._session.events) - 1:
            event = self._session.events[self._position]
            self._apply_event_forward(event)
            self._position += 1

            if self._check_breakpoints(self._session.events[self._position]):
                return self._session.events[self._position]

        return None

    def continue_backward(self) -> ExecutionEvent | None:
        """Continue backward until breakpoint."""
        if not self._session:
            return None

        while self._position > 0:
            event = self._session.events[self._position]
            self._apply_event_backward(event)
            self._position -= 1

            if self._check_breakpoints(self._session.events[self._position]):
                return self._session.events[self._position]

        return None

    def add_breakpoint(self, condition: Callable[[ExecutionEvent], bool],
                       description: str = "") -> int:
        """Add a time-travel breakpoint."""
        bp_id = self._next_breakpoint_id
        self._next_breakpoint_id += 1

        self._breakpoints[bp_id] = TimeTravelBreakpoint(
            breakpoint_id=bp_id,
            condition=condition,
            description=description,
        )

        return bp_id

    def add_address_breakpoint(self, address: int) -> int:
        """Add a breakpoint at a specific address."""
        return self.add_breakpoint(
            lambda e: e.address == address,
            f"Address breakpoint at {hex(address)}",
        )

    def add_memory_breakpoint(self, address: int, is_write: bool = True) -> int:
        """Add a memory access breakpoint."""
        def check(event: ExecutionEvent) -> bool:
            if is_write and event.event_type != EventType.MEMORY_WRITE:
                return False
            if not is_write and event.event_type != EventType.MEMORY_READ:
                return False
            return event.address == address

        return self.add_breakpoint(
            check,
            f"Memory {'write' if is_write else 'read'} at {hex(address)}",
        )

    def remove_breakpoint(self, bp_id: int) -> bool:
        """Remove a breakpoint."""
        if bp_id in self._breakpoints:
            del self._breakpoints[bp_id]
            return True
        return False

    def get_breakpoints(self) -> list[TimeTravelBreakpoint]:
        """Get all breakpoints."""
        return list(self._breakpoints.values())

    def _check_breakpoints(self, event: ExecutionEvent) -> bool:
        """Check if any breakpoint is hit."""
        for bp in self._breakpoints.values():
            if bp.check(event):
                bp.hit_count += 1
                return True
        return False

    def _apply_event_forward(self, event: ExecutionEvent) -> None:
        """Apply event changes forward."""
        # Apply register changes
        for name, (_, new_value) in event.register_changes.items():
            self._current_registers.set(name, new_value)

        # Apply memory changes
        for address, _, new_data in event.memory_changes:
            self._current_memory.write(address, new_data)

    def _apply_event_backward(self, event: ExecutionEvent) -> None:
        """Apply event changes backward (undo)."""
        # Undo register changes
        for name, (old_value, _) in event.register_changes.items():
            self._current_registers.set(name, old_value)

        # Undo memory changes
        for address, old_data, _ in event.memory_changes:
            self._current_memory.write(address, old_data)

    def _restore_snapshot(self, target_index: int) -> None:
        """Restore from nearest snapshot before target."""
        if not self._session:
            return

        # Find nearest snapshot at or before target
        best_snapshot_id = 0
        best_snapshot = None

        for snapshot_id, snapshot in self._session.snapshots.items():
            if snapshot_id <= target_index and snapshot_id >= best_snapshot_id:
                best_snapshot_id = snapshot_id
                best_snapshot = snapshot

        if best_snapshot:
            self._current_registers = best_snapshot.registers.copy()
            self._current_memory = best_snapshot.memory.copy()
            self._position = best_snapshot_id
        else:
            # No snapshot, start from beginning
            self._current_registers = RegisterState()
            self._current_memory = MemoryState()
            self._position = 0


# =============================================================================
# Timeline Analysis
# =============================================================================

class TimelineAnalyzer:
    """Analyzes recorded execution timeline."""

    def __init__(self, session: RecordingSession):
        self._session = session

    @property
    def event_count(self) -> int:
        """Get total event count."""
        return len(self._session.events)

    def get_event_distribution(self) -> dict[EventType, int]:
        """Get distribution of event types."""
        distribution: dict[EventType, int] = defaultdict(int)
        for event in self._session.events:
            distribution[event.event_type] += 1
        return dict(distribution)

    def get_hot_addresses(self, top_n: int = 10) -> list[tuple[int, int]]:
        """Get most frequently executed addresses."""
        address_counts: dict[int, int] = defaultdict(int)

        for event in self._session.events:
            if event.event_type == EventType.INSTRUCTION:
                address_counts[event.address] += 1

        sorted_addresses = sorted(
            address_counts.items(),
            key=lambda x: x[1],
            reverse=True
        )

        return sorted_addresses[:top_n]

    def get_address_timeline(self, address: int) -> list[int]:
        """Get timeline indices where address was executed."""
        indices = []
        for i, event in enumerate(self._session.events):
            if event.address == address:
                indices.append(i)
        return indices

    def find_events_by_type(self, event_type: EventType) -> list[ExecutionEvent]:
        """Find all events of a specific type."""
        return [e for e in self._session.events if e.event_type == event_type]

    def find_memory_accesses(self, address: int,
                             size: int = 1) -> list[ExecutionEvent]:
        """Find memory accesses to an address range."""
        events = []
        for event in self._session.events:
            if event.event_type in (EventType.MEMORY_READ, EventType.MEMORY_WRITE):
                event_addr = event.address
                if address <= event_addr < address + size:
                    events.append(event)
        return events

    def get_register_history(self, register_name: str) -> list[tuple[int, int]]:
        """Get history of a register's values."""
        history = []
        register_name = register_name.lower()

        for event in self._session.events:
            if register_name in event.register_changes:
                _, new_value = event.register_changes[register_name]
                history.append((event.event_id, new_value))

        return history

    def find_function_calls(self, address: int | None = None) -> list[ExecutionEvent]:
        """Find function calls, optionally to a specific address."""
        calls = self.find_events_by_type(EventType.FUNCTION_CALL)
        if address is not None:
            calls = [c for c in calls if c.address == address]
        return calls

    def get_call_graph(self) -> dict[int, list[int]]:
        """Build call graph from recording."""
        call_graph: dict[int, list[int]] = defaultdict(list)
        call_stack = [0]  # Current function address

        for event in self._session.events:
            if event.event_type == EventType.FUNCTION_CALL:
                caller = call_stack[-1] if call_stack else 0
                callee = event.address
                if callee not in call_graph[caller]:
                    call_graph[caller].append(callee)
                call_stack.append(callee)
            elif event.event_type == EventType.FUNCTION_RETURN:
                if call_stack:
                    call_stack.pop()

        return dict(call_graph)

    def find_divergence_points(self,
                               expected_addresses: list[int]) -> list[tuple[int, int, int]]:
        """Find points where execution diverged from expected path."""
        divergences = []
        expected_idx = 0

        for i, event in enumerate(self._session.events):
            if event.event_type != EventType.INSTRUCTION:
                continue

            if expected_idx < len(expected_addresses):
                if event.address != expected_addresses[expected_idx]:
                    divergences.append((i, event.address, expected_addresses[expected_idx]))
            expected_idx += 1

        return divergences


# =============================================================================
# Time Travel Debugger
# =============================================================================

class TimeTravelDebugger:
    """Main time-travel debugging interface."""

    def __init__(self):
        self._recording_engine = RecordingEngine()
        self._replay_engine = ReplayEngine()
        self._sessions: dict[str, RecordingSession] = {}
        self._analyzer: TimelineAnalyzer | None = None

    @property
    def is_recording(self) -> bool:
        """Check if recording is active."""
        return self._recording_engine.is_recording

    @property
    def is_replaying(self) -> bool:
        """Check if replay is active."""
        return self._replay_engine.state == RecordingState.REPLAYING

    @property
    def position(self) -> TimelinePosition | None:
        """Get current timeline position."""
        if self.is_replaying:
            return self._replay_engine.position
        return None

    @property
    def current_event(self) -> ExecutionEvent | None:
        """Get current event."""
        return self._replay_engine.current_event

    @property
    def registers(self) -> RegisterState:
        """Get current register state."""
        return self._replay_engine.current_registers

    @property
    def memory(self) -> MemoryState:
        """Get current memory state."""
        return self._replay_engine.current_memory

    def set_granularity(self, granularity: RecordingGranularity) -> None:
        """Set recording granularity."""
        self._recording_engine.set_granularity(granularity)

    def start_recording(self, session_id: str | None = None) -> RecordingSession:
        """Start recording."""
        session = self._recording_engine.start_recording(session_id)
        self._sessions[session.session_id] = session
        return session

    def stop_recording(self) -> RecordingSession | None:
        """Stop recording."""
        session = self._recording_engine.stop_recording()
        if session:
            self._sessions[session.session_id] = session
        return session

    def record_instruction(self, address: int, instruction: str,
                          registers: dict[str, int] | None = None,
                          memory_ops: list[dict] | None = None) -> ExecutionEvent | None:
        """Record an instruction."""
        return self._recording_engine.record_instruction(
            address, instruction, registers, memory_ops
        )

    def record_function_call(self, address: int, return_address: int,
                            args: list[int] | None = None) -> ExecutionEvent | None:
        """Record a function call."""
        return self._recording_engine.record_function_call(address, return_address, args)

    def record_function_return(self, address: int,
                               return_value: int | None = None) -> ExecutionEvent | None:
        """Record a function return."""
        return self._recording_engine.record_function_return(address, return_value)

    def load_session(self, session_id: str) -> bool:
        """Load a session for replay."""
        if session_id not in self._sessions:
            return False

        session = self._sessions[session_id]
        self._replay_engine.load_session(session)
        self._analyzer = TimelineAnalyzer(session)
        return True

    def get_session(self, session_id: str) -> RecordingSession | None:
        """Get a recorded session."""
        return self._sessions.get(session_id)

    def list_sessions(self) -> list[str]:
        """List all session IDs."""
        return list(self._sessions.keys())

    def step_forward(self, count: int = 1) -> list[ExecutionEvent]:
        """Step forward in time."""
        return self._replay_engine.step_forward(count)

    def step_backward(self, count: int = 1) -> list[ExecutionEvent]:
        """Step backward in time."""
        return self._replay_engine.step_backward(count)

    def goto_event(self, event_index: int) -> bool:
        """Go to a specific event."""
        return self._replay_engine.goto_event(event_index)

    def goto_start(self) -> bool:
        """Go to start."""
        return self._replay_engine.goto_start()

    def goto_end(self) -> bool:
        """Go to end."""
        return self._replay_engine.goto_end()

    def continue_forward(self) -> ExecutionEvent | None:
        """Continue forward until breakpoint."""
        return self._replay_engine.continue_forward()

    def continue_backward(self) -> ExecutionEvent | None:
        """Continue backward until breakpoint."""
        return self._replay_engine.continue_backward()

    def add_breakpoint(self, condition: Callable[[ExecutionEvent], bool],
                       description: str = "") -> int:
        """Add a breakpoint."""
        return self._replay_engine.add_breakpoint(condition, description)

    def add_address_breakpoint(self, address: int) -> int:
        """Add an address breakpoint."""
        return self._replay_engine.add_address_breakpoint(address)

    def remove_breakpoint(self, bp_id: int) -> bool:
        """Remove a breakpoint."""
        return self._replay_engine.remove_breakpoint(bp_id)

    def get_breakpoints(self) -> list[TimeTravelBreakpoint]:
        """Get all breakpoints."""
        return self._replay_engine.get_breakpoints()

    def get_hot_addresses(self, top_n: int = 10) -> list[tuple[int, int]]:
        """Get most frequently executed addresses."""
        if self._analyzer:
            return self._analyzer.get_hot_addresses(top_n)
        return []

    def get_register_history(self, register_name: str) -> list[tuple[int, int]]:
        """Get register history."""
        if self._analyzer:
            return self._analyzer.get_register_history(register_name)
        return []

    def find_memory_accesses(self, address: int, size: int = 1) -> list[ExecutionEvent]:
        """Find memory accesses."""
        if self._analyzer:
            return self._analyzer.find_memory_accesses(address, size)
        return []

    def get_call_graph(self) -> dict[int, list[int]]:
        """Get call graph from recording."""
        if self._analyzer:
            return self._analyzer.get_call_graph()
        return {}


# =============================================================================
# Helper Functions
# =============================================================================

def create_time_travel_debugger() -> TimeTravelDebugger:
    """Create a time-travel debugger."""
    return TimeTravelDebugger()


def create_recording_engine(granularity: RecordingGranularity = RecordingGranularity.STANDARD) -> RecordingEngine:
    """Create a recording engine."""
    return RecordingEngine(granularity)


def create_replay_engine() -> ReplayEngine:
    """Create a replay engine."""
    return ReplayEngine()


def quick_record(instructions: list[tuple[int, str]],
                 granularity: RecordingGranularity = RecordingGranularity.STANDARD) -> RecordingSession:
    """Quickly record a sequence of instructions."""
    engine = RecordingEngine(granularity)
    session = engine.start_recording()

    for address, instruction in instructions:
        engine.record_instruction(address, instruction)

    engine.stop_recording()
    return session


# Exports
__all__ = [
    # Enums
    'RecordingState',
    'StepDirection',
    'EventType',
    'RecordingGranularity',

    # Data classes
    'RegisterState',
    'MemoryState',
    'ExecutionEvent',
    'ExecutionSnapshot',
    'RecordingSession',
    'TimelinePosition',
    'TimeTravelBreakpoint',

    # Engines
    'RecordingEngine',
    'ReplayEngine',
    'TimelineAnalyzer',
    'TimeTravelDebugger',

    # Helper functions
    'create_time_travel_debugger',
    'create_recording_engine',
    'create_replay_engine',
    'quick_record',
]
