"""
Export Formats module for PyUniDbg.

This module provides export functionality for various data formats:
- JSON export
- YAML export
- Binary/raw export
- CSV export
- XML export
- Markdown reports
- IDA/Ghidra scripts

Features:
- Memory dumps
- Execution traces
- Analysis results
- Function information
- Annotations and comments
"""

import base64
import json
import struct
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import IntEnum, auto
from io import BytesIO, StringIO
from typing import Any


class ExportFormat(IntEnum):
    """Supported export formats."""
    JSON = auto()
    YAML = auto()
    BINARY = auto()
    CSV = auto()
    XML = auto()
    MARKDOWN = auto()
    IDA_SCRIPT = auto()
    GHIDRA_SCRIPT = auto()
    TEXT = auto()


class DataCategory(IntEnum):
    """Categories of data to export."""
    MEMORY = auto()
    REGISTERS = auto()
    TRACE = auto()
    FUNCTIONS = auto()
    ANNOTATIONS = auto()
    ANALYSIS = auto()
    CONFIG = auto()
    ALL = auto()


@dataclass
class ExportOptions:
    """Options for export operations."""
    format: ExportFormat = ExportFormat.JSON
    pretty: bool = True
    include_metadata: bool = True
    compress: bool = False
    encoding: str = 'utf-8'
    base64_binary: bool = True
    include_timestamp: bool = True
    categories: list[DataCategory] = field(default_factory=lambda: [DataCategory.ALL])
    custom_fields: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'format': self.format.name,
            'pretty': self.pretty,
            'include_metadata': self.include_metadata,
            'compress': self.compress,
            'encoding': self.encoding,
            'base64_binary': self.base64_binary,
            'include_timestamp': self.include_timestamp,
            'categories': [c.name for c in self.categories],
        }


@dataclass
class ExportResult:
    """Result of an export operation."""
    success: bool
    format: ExportFormat
    size: int
    path: str | None = None
    error: str | None = None
    data: bytes | None = None

    def __str__(self) -> str:
        if self.success:
            return f"Export successful ({self.format.name}, {self.size} bytes)"
        return f"Export failed: {self.error}"


@dataclass
class MemoryRegion:
    """A memory region for export."""
    start: int
    end: int
    data: bytes
    permissions: str = "rwx"
    name: str = ""

    @property
    def size(self) -> int:
        """Get region size."""
        return self.end - self.start

    def to_dict(self, base64_data: bool = True) -> dict[str, Any]:
        """Convert to dictionary."""
        result = {
            'start': self.start,
            'end': self.end,
            'size': self.size,
            'permissions': self.permissions,
            'name': self.name,
        }
        if base64_data:
            result['data'] = base64.b64encode(self.data).decode('ascii')
        else:
            result['data_hex'] = self.data.hex()
        return result


@dataclass
class RegisterState:
    """Register state for export."""
    registers: dict[str, int]
    architecture: str = "x86_64"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'architecture': self.architecture,
            'registers': self.registers,
        }


@dataclass
class TraceEntry:
    """A trace entry for export."""
    address: int
    instruction: str
    registers: dict[str, int] | None = None
    memory_accesses: list[dict[str, Any]] = field(default_factory=list)
    timestamp: float | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        result = {
            'address': self.address,
            'instruction': self.instruction,
        }
        if self.registers:
            result['registers'] = self.registers
        if self.memory_accesses:
            result['memory_accesses'] = self.memory_accesses
        if self.timestamp is not None:
            result['timestamp'] = self.timestamp
        return result


@dataclass
class FunctionInfo:
    """Function information for export."""
    address: int
    name: str
    size: int
    signature: str = ""
    xrefs_to: list[int] = field(default_factory=list)
    xrefs_from: list[int] = field(default_factory=list)
    local_vars: list[str] = field(default_factory=list)
    comments: dict[int, str] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'address': self.address,
            'name': self.name,
            'size': self.size,
            'signature': self.signature,
            'xrefs_to': self.xrefs_to,
            'xrefs_from': self.xrefs_from,
            'local_vars': self.local_vars,
            'comments': {hex(k): v for k, v in self.comments.items()},
        }


@dataclass
class AnnotationEntry:
    """An annotation for export."""
    address: int
    comment: str
    annotation_type: str = "comment"
    repeatable: bool = False

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'address': self.address,
            'comment': self.comment,
            'type': self.annotation_type,
            'repeatable': self.repeatable,
        }


# =============================================================================
# Exporter Interface
# =============================================================================

class Exporter(ABC):
    """Abstract base class for exporters."""

    @property
    @abstractmethod
    def format(self) -> ExportFormat:
        """Get export format."""
        pass

    @property
    @abstractmethod
    def extension(self) -> str:
        """Get file extension."""
        pass

    @abstractmethod
    def export(self, data: dict[str, Any],
               options: ExportOptions) -> ExportResult:
        """Export data."""
        pass

    @abstractmethod
    def export_to_file(self, data: dict[str, Any],
                      path: str, options: ExportOptions) -> ExportResult:
        """Export data to file."""
        pass


# =============================================================================
# JSON Exporter
# =============================================================================

class JSONExporter(Exporter):
    """JSON format exporter."""

    @property
    def format(self) -> ExportFormat:
        return ExportFormat.JSON

    @property
    def extension(self) -> str:
        return ".json"

    def export(self, data: dict[str, Any],
               options: ExportOptions) -> ExportResult:
        """Export to JSON."""
        try:
            indent = 2 if options.pretty else None
            json_str = json.dumps(data, indent=indent, default=self._json_default)
            json_bytes = json_str.encode(options.encoding)

            return ExportResult(
                success=True,
                format=self.format,
                size=len(json_bytes),
                data=json_bytes,
            )
        except Exception as e:
            return ExportResult(
                success=False,
                format=self.format,
                size=0,
                error=str(e),
            )

    def export_to_file(self, data: dict[str, Any],
                      path: str, options: ExportOptions) -> ExportResult:
        """Export to JSON file."""
        result = self.export(data, options)
        if result.success and result.data:
            try:
                with open(path, 'wb') as f:
                    f.write(result.data)
                return ExportResult(
                    success=True,
                    format=self.format,
                    size=result.size,
                    path=path,
                )
            except Exception as e:
                return ExportResult(
                    success=False,
                    format=self.format,
                    size=0,
                    error=str(e),
                )
        return result

    def _json_default(self, obj: Any) -> Any:
        """Default JSON encoder for custom types."""
        if isinstance(obj, bytes):
            return base64.b64encode(obj).decode('ascii')
        if hasattr(obj, 'to_dict'):
            return obj.to_dict()
        raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


# =============================================================================
# YAML Exporter
# =============================================================================

class YAMLExporter(Exporter):
    """YAML format exporter."""

    @property
    def format(self) -> ExportFormat:
        return ExportFormat.YAML

    @property
    def extension(self) -> str:
        return ".yaml"

    def export(self, data: dict[str, Any],
               options: ExportOptions) -> ExportResult:
        """Export to YAML."""
        try:
            # Simple YAML generation without external dependencies
            yaml_str = self._to_yaml(data, indent=0)
            yaml_bytes = yaml_str.encode(options.encoding)

            return ExportResult(
                success=True,
                format=self.format,
                size=len(yaml_bytes),
                data=yaml_bytes,
            )
        except Exception as e:
            return ExportResult(
                success=False,
                format=self.format,
                size=0,
                error=str(e),
            )

    def export_to_file(self, data: dict[str, Any],
                      path: str, options: ExportOptions) -> ExportResult:
        """Export to YAML file."""
        result = self.export(data, options)
        if result.success and result.data:
            try:
                with open(path, 'wb') as f:
                    f.write(result.data)
                return ExportResult(
                    success=True,
                    format=self.format,
                    size=result.size,
                    path=path,
                )
            except Exception as e:
                return ExportResult(
                    success=False,
                    format=self.format,
                    size=0,
                    error=str(e),
                )
        return result

    def _to_yaml(self, obj: Any, indent: int = 0) -> str:
        """Convert object to YAML string."""
        prefix = "  " * indent

        if obj is None:
            return "null"
        elif isinstance(obj, bool):
            return "true" if obj else "false"
        elif isinstance(obj, (int, float)):
            return str(obj)
        elif isinstance(obj, str):
            if '\n' in obj or ':' in obj or '#' in obj:
                return f'"{obj}"'
            return obj
        elif isinstance(obj, bytes):
            return f'"{base64.b64encode(obj).decode("ascii")}"'
        elif isinstance(obj, list):
            if not obj:
                return "[]"
            lines = []
            for item in obj:
                item_yaml = self._to_yaml(item, indent + 1)
                if isinstance(item, (dict, list)):
                    lines.append(f"{prefix}-\n{item_yaml}")
                else:
                    lines.append(f"{prefix}- {item_yaml}")
            return "\n".join(lines)
        elif isinstance(obj, dict):
            if not obj:
                return "{}"
            lines = []
            for key, value in obj.items():
                value_yaml = self._to_yaml(value, indent + 1)
                if isinstance(value, (dict, list)) and value:
                    lines.append(f"{prefix}{key}:\n{value_yaml}")
                else:
                    lines.append(f"{prefix}{key}: {value_yaml}")
            return "\n".join(lines)
        elif hasattr(obj, 'to_dict'):
            return self._to_yaml(obj.to_dict(), indent)
        else:
            return str(obj)


# =============================================================================
# Binary Exporter
# =============================================================================

class BinaryExporter(Exporter):
    """Binary format exporter for raw data."""

    MAGIC = b'PYUDB'
    VERSION = 1

    @property
    def format(self) -> ExportFormat:
        return ExportFormat.BINARY

    @property
    def extension(self) -> str:
        return ".bin"

    def export(self, data: dict[str, Any],
               options: ExportOptions) -> ExportResult:
        """Export to binary format."""
        try:
            buffer = BytesIO()

            # Write header
            buffer.write(self.MAGIC)
            buffer.write(struct.pack('<H', self.VERSION))

            # Serialize sections
            sections = []

            # Memory sections
            if 'memory' in data:
                for region in data['memory']:
                    section_data = self._pack_memory_region(region)
                    sections.append((1, section_data))

            # Register sections
            if 'registers' in data:
                section_data = self._pack_registers(data['registers'])
                sections.append((2, section_data))

            # Trace sections
            if 'trace' in data:
                section_data = self._pack_trace(data['trace'])
                sections.append((3, section_data))

            # Write section count
            buffer.write(struct.pack('<I', len(sections)))

            # Write sections
            for section_type, section_data in sections:
                buffer.write(struct.pack('<BII', section_type, len(section_data), 0))
                buffer.write(section_data)

            result_data = buffer.getvalue()
            return ExportResult(
                success=True,
                format=self.format,
                size=len(result_data),
                data=result_data,
            )
        except Exception as e:
            return ExportResult(
                success=False,
                format=self.format,
                size=0,
                error=str(e),
            )

    def export_to_file(self, data: dict[str, Any],
                      path: str, options: ExportOptions) -> ExportResult:
        """Export to binary file."""
        result = self.export(data, options)
        if result.success and result.data:
            try:
                with open(path, 'wb') as f:
                    f.write(result.data)
                return ExportResult(
                    success=True,
                    format=self.format,
                    size=result.size,
                    path=path,
                )
            except Exception as e:
                return ExportResult(
                    success=False,
                    format=self.format,
                    size=0,
                    error=str(e),
                )
        return result

    def _pack_memory_region(self, region: dict | MemoryRegion) -> bytes:
        """Pack a memory region to binary."""
        if isinstance(region, dict):
            start = region.get('start', 0)
            end = region.get('end', 0)
            data = region.get('data', b'')
            if isinstance(data, str):
                # Base64 encoded
                data = base64.b64decode(data)
        else:
            start = region.start
            end = region.end
            data = region.data

        buffer = BytesIO()
        buffer.write(struct.pack('<QQ', start, end))
        buffer.write(struct.pack('<I', len(data)))
        buffer.write(data)
        return buffer.getvalue()

    def _pack_registers(self, registers: dict[str, int]) -> bytes:
        """Pack registers to binary."""
        buffer = BytesIO()
        buffer.write(struct.pack('<I', len(registers)))
        for name, value in registers.items():
            name_bytes = name.encode('utf-8')
            buffer.write(struct.pack('<B', len(name_bytes)))
            buffer.write(name_bytes)
            buffer.write(struct.pack('<Q', value))
        return buffer.getvalue()

    def _pack_trace(self, trace: list[dict]) -> bytes:
        """Pack trace to binary."""
        buffer = BytesIO()
        buffer.write(struct.pack('<I', len(trace)))
        for entry in trace:
            addr = entry.get('address', 0)
            inst = entry.get('instruction', '').encode('utf-8')
            buffer.write(struct.pack('<Q', addr))
            buffer.write(struct.pack('<H', len(inst)))
            buffer.write(inst)
        return buffer.getvalue()


# =============================================================================
# CSV Exporter
# =============================================================================

class CSVExporter(Exporter):
    """CSV format exporter."""

    @property
    def format(self) -> ExportFormat:
        return ExportFormat.CSV

    @property
    def extension(self) -> str:
        return ".csv"

    def export(self, data: dict[str, Any],
               options: ExportOptions) -> ExportResult:
        """Export to CSV format."""
        try:
            output = StringIO()

            # Export trace entries
            if 'trace' in data:
                self._export_trace_csv(data['trace'], output)
            # Export functions
            elif 'functions' in data:
                self._export_functions_csv(data['functions'], output)
            # Export annotations
            elif 'annotations' in data:
                self._export_annotations_csv(data['annotations'], output)
            # Generic export
            else:
                self._export_generic_csv(data, output)

            csv_str = output.getvalue()
            csv_bytes = csv_str.encode(options.encoding)

            return ExportResult(
                success=True,
                format=self.format,
                size=len(csv_bytes),
                data=csv_bytes,
            )
        except Exception as e:
            return ExportResult(
                success=False,
                format=self.format,
                size=0,
                error=str(e),
            )

    def export_to_file(self, data: dict[str, Any],
                      path: str, options: ExportOptions) -> ExportResult:
        """Export to CSV file."""
        result = self.export(data, options)
        if result.success and result.data:
            try:
                with open(path, 'wb') as f:
                    f.write(result.data)
                return ExportResult(
                    success=True,
                    format=self.format,
                    size=result.size,
                    path=path,
                )
            except Exception as e:
                return ExportResult(
                    success=False,
                    format=self.format,
                    size=0,
                    error=str(e),
                )
        return result

    def _escape_csv(self, value: str) -> str:
        """Escape a value for CSV."""
        if ',' in value or '"' in value or '\n' in value:
            return f'"{value.replace(chr(34), chr(34)+chr(34))}"'
        return value

    def _export_trace_csv(self, trace: list[dict], output: StringIO) -> None:
        """Export trace entries to CSV."""
        output.write("address,instruction,timestamp\n")
        for entry in trace:
            addr = hex(entry.get('address', 0))
            inst = self._escape_csv(entry.get('instruction', ''))
            ts = entry.get('timestamp', '')
            output.write(f"{addr},{inst},{ts}\n")

    def _export_functions_csv(self, functions: list[dict], output: StringIO) -> None:
        """Export functions to CSV."""
        output.write("address,name,size,signature\n")
        for func in functions:
            addr = hex(func.get('address', 0))
            name = self._escape_csv(func.get('name', ''))
            size = func.get('size', 0)
            sig = self._escape_csv(func.get('signature', ''))
            output.write(f"{addr},{name},{size},{sig}\n")

    def _export_annotations_csv(self, annotations: list[dict], output: StringIO) -> None:
        """Export annotations to CSV."""
        output.write("address,type,comment\n")
        for ann in annotations:
            addr = hex(ann.get('address', 0))
            ann_type = ann.get('type', 'comment')
            comment = self._escape_csv(ann.get('comment', ''))
            output.write(f"{addr},{ann_type},{comment}\n")

    def _export_generic_csv(self, data: dict[str, Any], output: StringIO) -> None:
        """Export generic data to CSV."""
        output.write("key,value\n")
        for key, value in data.items():
            key_str = self._escape_csv(str(key))
            value_str = self._escape_csv(str(value))
            output.write(f"{key_str},{value_str}\n")


# =============================================================================
# XML Exporter
# =============================================================================

class XMLExporter(Exporter):
    """XML format exporter."""

    @property
    def format(self) -> ExportFormat:
        return ExportFormat.XML

    @property
    def extension(self) -> str:
        return ".xml"

    def export(self, data: dict[str, Any],
               options: ExportOptions) -> ExportResult:
        """Export to XML format."""
        try:
            output = StringIO()
            output.write('<?xml version="1.0" encoding="UTF-8"?>\n')
            output.write('<pyunidbg>\n')

            self._to_xml(data, output, indent=1)

            output.write('</pyunidbg>\n')

            xml_str = output.getvalue()
            xml_bytes = xml_str.encode(options.encoding)

            return ExportResult(
                success=True,
                format=self.format,
                size=len(xml_bytes),
                data=xml_bytes,
            )
        except Exception as e:
            return ExportResult(
                success=False,
                format=self.format,
                size=0,
                error=str(e),
            )

    def export_to_file(self, data: dict[str, Any],
                      path: str, options: ExportOptions) -> ExportResult:
        """Export to XML file."""
        result = self.export(data, options)
        if result.success and result.data:
            try:
                with open(path, 'wb') as f:
                    f.write(result.data)
                return ExportResult(
                    success=True,
                    format=self.format,
                    size=result.size,
                    path=path,
                )
            except Exception as e:
                return ExportResult(
                    success=False,
                    format=self.format,
                    size=0,
                    error=str(e),
                )
        return result

    def _escape_xml(self, value: str) -> str:
        """Escape XML special characters."""
        return (value
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&apos;'))

    def _to_xml(self, obj: Any, output: StringIO, indent: int = 0,
                tag: str = "item") -> None:
        """Convert object to XML."""
        prefix = "  " * indent

        if obj is None:
            output.write(f"{prefix}<{tag} />\n")
        elif isinstance(obj, bool):
            output.write(f"{prefix}<{tag}>{str(obj).lower()}</{tag}>\n")
        elif isinstance(obj, (int, float)):
            output.write(f"{prefix}<{tag}>{obj}</{tag}>\n")
        elif isinstance(obj, str):
            output.write(f"{prefix}<{tag}>{self._escape_xml(obj)}</{tag}>\n")
        elif isinstance(obj, bytes):
            b64 = base64.b64encode(obj).decode('ascii')
            output.write(f'{prefix}<{tag} encoding="base64">{b64}</{tag}>\n')
        elif isinstance(obj, list):
            output.write(f"{prefix}<{tag}>\n")
            for item in obj:
                self._to_xml(item, output, indent + 1, "item")
            output.write(f"{prefix}</{tag}>\n")
        elif isinstance(obj, dict):
            output.write(f"{prefix}<{tag}>\n")
            for key, value in obj.items():
                # Sanitize key for XML tag
                safe_key = ''.join(c if c.isalnum() or c == '_' else '_' for c in str(key))
                if safe_key[0].isdigit():
                    safe_key = '_' + safe_key
                self._to_xml(value, output, indent + 1, safe_key)
            output.write(f"{prefix}</{tag}>\n")
        elif hasattr(obj, 'to_dict'):
            self._to_xml(obj.to_dict(), output, indent, tag)
        else:
            output.write(f"{prefix}<{tag}>{self._escape_xml(str(obj))}</{tag}>\n")


# =============================================================================
# Markdown Exporter
# =============================================================================

class MarkdownExporter(Exporter):
    """Markdown format exporter for reports."""

    @property
    def format(self) -> ExportFormat:
        return ExportFormat.MARKDOWN

    @property
    def extension(self) -> str:
        return ".md"

    def export(self, data: dict[str, Any],
               options: ExportOptions) -> ExportResult:
        """Export to Markdown format."""
        try:
            output = StringIO()

            # Title
            title = data.get('title', 'PyUniDbg Report')
            output.write(f"# {title}\n\n")

            # Metadata
            if options.include_metadata and 'metadata' in data:
                output.write("## Metadata\n\n")
                for key, value in data['metadata'].items():
                    output.write(f"- **{key}**: {value}\n")
                output.write("\n")

            # Memory regions
            if 'memory' in data:
                output.write("## Memory Regions\n\n")
                output.write("| Start | End | Size | Permissions | Name |\n")
                output.write("|-------|-----|------|-------------|------|\n")
                for region in data['memory']:
                    start = hex(region.get('start', 0))
                    end = hex(region.get('end', 0))
                    size = region.get('size', 0)
                    perms = region.get('permissions', 'rwx')
                    name = region.get('name', '')
                    output.write(f"| {start} | {end} | {size} | {perms} | {name} |\n")
                output.write("\n")

            # Functions
            if 'functions' in data:
                output.write("## Functions\n\n")
                for func in data['functions']:
                    name = func.get('name', 'unknown')
                    addr = hex(func.get('address', 0))
                    sig = func.get('signature', '')
                    output.write(f"### {name} ({addr})\n\n")
                    if sig:
                        output.write(f"```c\n{sig}\n```\n\n")
                output.write("\n")

            # Trace
            if 'trace' in data:
                output.write("## Execution Trace\n\n")
                output.write("| Address | Instruction |\n")
                output.write("|---------|-------------|\n")
                for entry in data['trace'][:100]:  # Limit entries
                    addr = hex(entry.get('address', 0))
                    inst = entry.get('instruction', '')
                    output.write(f"| {addr} | `{inst}` |\n")
                if len(data['trace']) > 100:
                    output.write(f"\n*...and {len(data['trace']) - 100} more entries*\n")
                output.write("\n")

            # Annotations
            if 'annotations' in data:
                output.write("## Annotations\n\n")
                for ann in data['annotations']:
                    addr = hex(ann.get('address', 0))
                    comment = ann.get('comment', '')
                    output.write(f"- **{addr}**: {comment}\n")
                output.write("\n")

            # Analysis results
            if 'analysis' in data:
                output.write("## Analysis Results\n\n")
                for key, value in data['analysis'].items():
                    output.write(f"### {key}\n\n")
                    if isinstance(value, list):
                        for item in value:
                            output.write(f"- {item}\n")
                    else:
                        output.write(f"{value}\n")
                    output.write("\n")

            md_str = output.getvalue()
            md_bytes = md_str.encode(options.encoding)

            return ExportResult(
                success=True,
                format=self.format,
                size=len(md_bytes),
                data=md_bytes,
            )
        except Exception as e:
            return ExportResult(
                success=False,
                format=self.format,
                size=0,
                error=str(e),
            )

    def export_to_file(self, data: dict[str, Any],
                      path: str, options: ExportOptions) -> ExportResult:
        """Export to Markdown file."""
        result = self.export(data, options)
        if result.success and result.data:
            try:
                with open(path, 'wb') as f:
                    f.write(result.data)
                return ExportResult(
                    success=True,
                    format=self.format,
                    size=result.size,
                    path=path,
                )
            except Exception as e:
                return ExportResult(
                    success=False,
                    format=self.format,
                    size=0,
                    error=str(e),
                )
        return result


# =============================================================================
# IDA Script Exporter
# =============================================================================

class IDAScriptExporter(Exporter):
    """IDA Pro Python script exporter."""

    @property
    def format(self) -> ExportFormat:
        return ExportFormat.IDA_SCRIPT

    @property
    def extension(self) -> str:
        return ".py"

    def export(self, data: dict[str, Any],
               options: ExportOptions) -> ExportResult:
        """Export to IDA Python script."""
        try:
            output = StringIO()

            # Header
            output.write('"""IDA Pro script generated by PyUniDbg"""\n\n')
            output.write('import idc\n')
            output.write('import idaapi\n')
            output.write('import ida_bytes\n')
            output.write('import ida_funcs\n')
            output.write('import ida_name\n\n')

            # Function renames
            if 'functions' in data:
                output.write('# Function renames\n')
                output.write('def apply_function_names():\n')
                for func in data['functions']:
                    addr = func.get('address', 0)
                    name = func.get('name', '')
                    if name:
                        output.write(f'    ida_name.set_name({hex(addr)}, "{name}", ida_name.SN_FORCE)\n')
                output.write('\n')

            # Comments
            if 'annotations' in data:
                output.write('# Comments\n')
                output.write('def apply_comments():\n')
                for ann in data['annotations']:
                    addr = ann.get('address', 0)
                    comment = ann.get('comment', '').replace('"', '\\"')
                    repeatable = ann.get('repeatable', False)
                    if repeatable:
                        output.write(f'    idc.set_cmt({hex(addr)}, "{comment}", 1)\n')
                    else:
                        output.write(f'    idc.set_cmt({hex(addr)}, "{comment}", 0)\n')
                output.write('\n')

            # Main
            output.write('def main():\n')
            output.write('    print("Applying PyUniDbg data...")\n')
            if 'functions' in data:
                output.write('    apply_function_names()\n')
            if 'annotations' in data:
                output.write('    apply_comments()\n')
            output.write('    print("Done!")\n\n')
            output.write('if __name__ == "__main__":\n')
            output.write('    main()\n')

            script_str = output.getvalue()
            script_bytes = script_str.encode(options.encoding)

            return ExportResult(
                success=True,
                format=self.format,
                size=len(script_bytes),
                data=script_bytes,
            )
        except Exception as e:
            return ExportResult(
                success=False,
                format=self.format,
                size=0,
                error=str(e),
            )

    def export_to_file(self, data: dict[str, Any],
                      path: str, options: ExportOptions) -> ExportResult:
        """Export to IDA script file."""
        result = self.export(data, options)
        if result.success and result.data:
            try:
                with open(path, 'wb') as f:
                    f.write(result.data)
                return ExportResult(
                    success=True,
                    format=self.format,
                    size=result.size,
                    path=path,
                )
            except Exception as e:
                return ExportResult(
                    success=False,
                    format=self.format,
                    size=0,
                    error=str(e),
                )
        return result


# =============================================================================
# Ghidra Script Exporter
# =============================================================================

class GhidraScriptExporter(Exporter):
    """Ghidra Python script exporter."""

    @property
    def format(self) -> ExportFormat:
        return ExportFormat.GHIDRA_SCRIPT

    @property
    def extension(self) -> str:
        return ".py"

    def export(self, data: dict[str, Any],
               options: ExportOptions) -> ExportResult:
        """Export to Ghidra Python script."""
        try:
            output = StringIO()

            # Header
            output.write('# Ghidra script generated by PyUniDbg\n')
            output.write('# @category PyUniDbg\n\n')
            output.write('from ghidra.program.model.symbol import SourceType\n')
            output.write('from ghidra.program.model.listing import CodeUnit\n\n')

            # Function renames
            if 'functions' in data:
                output.write('def apply_function_names():\n')
                output.write('    fm = currentProgram.getFunctionManager()\n')
                for func in data['functions']:
                    addr = func.get('address', 0)
                    name = func.get('name', '')
                    if name:
                        output.write(f'    func = fm.getFunctionAt(toAddr({hex(addr)}))\n')
                        output.write('    if func:\n')
                        output.write(f'        func.setName("{name}", SourceType.USER_DEFINED)\n')
                output.write('\n')

            # Comments
            if 'annotations' in data:
                output.write('def apply_comments():\n')
                output.write('    listing = currentProgram.getListing()\n')
                for ann in data['annotations']:
                    addr = ann.get('address', 0)
                    comment = ann.get('comment', '').replace('"', '\\"')
                    output.write(f'    cu = listing.getCodeUnitAt(toAddr({hex(addr)}))\n')
                    output.write('    if cu:\n')
                    output.write(f'        cu.setComment(CodeUnit.EOL_COMMENT, "{comment}")\n')
                output.write('\n')

            # Main
            output.write('def run():\n')
            output.write('    println("Applying PyUniDbg data...")\n')
            if 'functions' in data:
                output.write('    apply_function_names()\n')
            if 'annotations' in data:
                output.write('    apply_comments()\n')
            output.write('    println("Done!")\n\n')
            output.write('run()\n')

            script_str = output.getvalue()
            script_bytes = script_str.encode(options.encoding)

            return ExportResult(
                success=True,
                format=self.format,
                size=len(script_bytes),
                data=script_bytes,
            )
        except Exception as e:
            return ExportResult(
                success=False,
                format=self.format,
                size=0,
                error=str(e),
            )

    def export_to_file(self, data: dict[str, Any],
                      path: str, options: ExportOptions) -> ExportResult:
        """Export to Ghidra script file."""
        result = self.export(data, options)
        if result.success and result.data:
            try:
                with open(path, 'wb') as f:
                    f.write(result.data)
                return ExportResult(
                    success=True,
                    format=self.format,
                    size=result.size,
                    path=path,
                )
            except Exception as e:
                return ExportResult(
                    success=False,
                    format=self.format,
                    size=0,
                    error=str(e),
                )
        return result


# =============================================================================
# Text Exporter
# =============================================================================

class TextExporter(Exporter):
    """Plain text exporter."""

    @property
    def format(self) -> ExportFormat:
        return ExportFormat.TEXT

    @property
    def extension(self) -> str:
        return ".txt"

    def export(self, data: dict[str, Any],
               options: ExportOptions) -> ExportResult:
        """Export to plain text."""
        try:
            output = StringIO()

            output.write("=" * 60 + "\n")
            output.write("PyUniDbg Export\n")
            output.write("=" * 60 + "\n\n")

            self._write_data(data, output)

            text_str = output.getvalue()
            text_bytes = text_str.encode(options.encoding)

            return ExportResult(
                success=True,
                format=self.format,
                size=len(text_bytes),
                data=text_bytes,
            )
        except Exception as e:
            return ExportResult(
                success=False,
                format=self.format,
                size=0,
                error=str(e),
            )

    def export_to_file(self, data: dict[str, Any],
                      path: str, options: ExportOptions) -> ExportResult:
        """Export to text file."""
        result = self.export(data, options)
        if result.success and result.data:
            try:
                with open(path, 'wb') as f:
                    f.write(result.data)
                return ExportResult(
                    success=True,
                    format=self.format,
                    size=result.size,
                    path=path,
                )
            except Exception as e:
                return ExportResult(
                    success=False,
                    format=self.format,
                    size=0,
                    error=str(e),
                )
        return result

    def _write_data(self, data: dict[str, Any], output: StringIO,
                    indent: int = 0) -> None:
        """Write data to output."""
        prefix = "  " * indent

        for key, value in data.items():
            if isinstance(value, dict):
                output.write(f"{prefix}{key}:\n")
                self._write_data(value, output, indent + 1)
            elif isinstance(value, list):
                output.write(f"{prefix}{key}: ({len(value)} items)\n")
                for i, item in enumerate(value[:10]):
                    if isinstance(item, dict):
                        output.write(f"{prefix}  [{i}]:\n")
                        self._write_data(item, output, indent + 2)
                    else:
                        output.write(f"{prefix}  [{i}]: {item}\n")
                if len(value) > 10:
                    output.write(f"{prefix}  ... and {len(value) - 10} more\n")
            else:
                output.write(f"{prefix}{key}: {value}\n")


# =============================================================================
# Export Manager
# =============================================================================

class ExportManager:
    """Manages export operations with multiple formats."""

    def __init__(self):
        self._exporters: dict[ExportFormat, Exporter] = {}
        self._register_default_exporters()

    def _register_default_exporters(self) -> None:
        """Register default exporters."""
        self._exporters[ExportFormat.JSON] = JSONExporter()
        self._exporters[ExportFormat.YAML] = YAMLExporter()
        self._exporters[ExportFormat.BINARY] = BinaryExporter()
        self._exporters[ExportFormat.CSV] = CSVExporter()
        self._exporters[ExportFormat.XML] = XMLExporter()
        self._exporters[ExportFormat.MARKDOWN] = MarkdownExporter()
        self._exporters[ExportFormat.IDA_SCRIPT] = IDAScriptExporter()
        self._exporters[ExportFormat.GHIDRA_SCRIPT] = GhidraScriptExporter()
        self._exporters[ExportFormat.TEXT] = TextExporter()

    def register_exporter(self, exporter: Exporter) -> None:
        """Register a custom exporter."""
        self._exporters[exporter.format] = exporter

    def get_exporter(self, export_format: ExportFormat) -> Exporter | None:
        """Get an exporter by format."""
        return self._exporters.get(export_format)

    def export(self, data: dict[str, Any],
               options: ExportOptions | None = None) -> ExportResult:
        """Export data using the specified format."""
        if options is None:
            options = ExportOptions()

        exporter = self._exporters.get(options.format)
        if not exporter:
            return ExportResult(
                success=False,
                format=options.format,
                size=0,
                error=f"No exporter for format: {options.format.name}",
            )

        return exporter.export(data, options)

    def export_to_file(self, data: dict[str, Any], path: str,
                      options: ExportOptions | None = None) -> ExportResult:
        """Export data to a file."""
        if options is None:
            options = ExportOptions()

        exporter = self._exporters.get(options.format)
        if not exporter:
            return ExportResult(
                success=False,
                format=options.format,
                size=0,
                error=f"No exporter for format: {options.format.name}",
            )

        return exporter.export_to_file(data, path, options)

    def get_supported_formats(self) -> list[ExportFormat]:
        """Get list of supported formats."""
        return list(self._exporters.keys())

    def get_extension(self, export_format: ExportFormat) -> str:
        """Get file extension for a format."""
        exporter = self._exporters.get(export_format)
        return exporter.extension if exporter else ""


# =============================================================================
# Helper Functions
# =============================================================================

def create_export_manager() -> ExportManager:
    """Create an export manager with default exporters."""
    return ExportManager()


def quick_export(data: dict[str, Any],
                 export_format: ExportFormat = ExportFormat.JSON) -> ExportResult:
    """Quick export to a format."""
    manager = ExportManager()
    options = ExportOptions(format=export_format)
    return manager.export(data, options)


def export_memory_dump(regions: list[MemoryRegion],
                       export_format: ExportFormat = ExportFormat.BINARY) -> ExportResult:
    """Export memory dump."""
    manager = ExportManager()
    data = {'memory': [r.to_dict() for r in regions]}
    options = ExportOptions(format=export_format)
    return manager.export(data, options)


def export_trace(entries: list[TraceEntry],
                 export_format: ExportFormat = ExportFormat.JSON) -> ExportResult:
    """Export execution trace."""
    manager = ExportManager()
    data = {'trace': [e.to_dict() for e in entries]}
    options = ExportOptions(format=export_format)
    return manager.export(data, options)
