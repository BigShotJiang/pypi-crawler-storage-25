"""
PyUniDbg Web Interface.

Provides a browser-based UI with real-time interaction, terminal emulation,
and access to all PyUniDbg features.

Usage:
    # Via the standalone console script (with --help, --port, --host):
    pyunidbg-web --port 8080

    # Via the main CLI:
    pyunidbg web --port 8080

    # Via Python API:
    from pyunidbg.web import run_server
    run_server(host="0.0.0.0", port=8080)

    # Programmatic with custom app:
    from pyunidbg.web import create_app
    app = create_app()
"""

from __future__ import annotations

__all__ = ["create_app", "run_server", "main"]


def create_app():
    """Create and return the FastAPI application."""
    from pyunidbg.web.server import create_app as _create
    return _create()


def run_server(host: str = "0.0.0.0", port: int = 8080,
               reload: bool = False, log_level: str = "info") -> None:
    """Start the PyUniDbg web server."""
    from pyunidbg.web.server import run_server as _run
    _run(host=host, port=port, reload=reload, log_level=log_level)


def main(argv: list[str] | None = None) -> int:
    """Console-script entry point for ``pyunidbg-web``.

    Parses ``--host``, ``--port``, ``--reload`` and ``--log-level`` from
    ``argv`` (defaults to ``sys.argv[1:]``) and starts the server.
    """
    import argparse

    parser = argparse.ArgumentParser(
        prog="pyunidbg-web",
        description="Start the PyUniDbg web UI (FastAPI + WebSocket SPA).",
    )
    parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="Interface to bind to (default: 0.0.0.0)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8080,
        help="TCP port to listen on (default: 8080)",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable uvicorn auto-reload (development only)",
    )
    parser.add_argument(
        "--log-level",
        default="info",
        choices=["critical", "error", "warning", "info", "debug", "trace"],
        help="uvicorn log level (default: info)",
    )

    args = parser.parse_args(argv)

    try:
        run_server(
            host=args.host,
            port=args.port,
            reload=args.reload,
            log_level=args.log_level,
        )
    except KeyboardInterrupt:
        return 130
    return 0
