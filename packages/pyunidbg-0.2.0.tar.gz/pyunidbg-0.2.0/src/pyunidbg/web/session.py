"""
Session management for PyUniDbg web interface.

Each browser session maps to an emulator instance and optional terminal process.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import pty
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger("pyunidbg.web.session")


class WebSocketLogHandler(logging.Handler):
    """Bridges Python logging → WebSocket broadcast for real-time UI logs."""

    def __init__(self):
        super().__init__()
        self._sessions: set = set()
        self._loop: asyncio.AbstractEventLoop | None = None
        self._emitting = False
        self.setFormatter(logging.Formatter("%(levelname)s [%(name)s] %(message)s"))

    def set_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        self._loop = loop

    def add_session(self, session: EmulatorSession) -> None:
        self._sessions.add(session)

    def remove_session(self, session: EmulatorSession) -> None:
        self._sessions.discard(session)

    def emit(self, record: logging.LogRecord) -> None:
        if self._emitting or not self._loop or not self._sessions:
            return
        self._emitting = True
        try:
            msg = {
                "type": "log_entry",
                "level": record.levelname.lower(),
                "logger": record.name,
                "message": self.format(record),
                "timestamp": record.created,
            }
            for session in list(self._sessions):
                if session.websockets:
                    asyncio.run_coroutine_threadsafe(
                        session._broadcast(msg), self._loop
                    )
        except Exception:
            pass
        finally:
            self._emitting = False


_ws_log_handler: WebSocketLogHandler | None = None


def get_ws_log_handler() -> WebSocketLogHandler:
    """Get or create the singleton WebSocket log handler."""
    global _ws_log_handler
    if _ws_log_handler is None:
        _ws_log_handler = WebSocketLogHandler()
        pyunidbg_logger = logging.getLogger("pyunidbg")
        pyunidbg_logger.addHandler(_ws_log_handler)
        pyunidbg_logger.setLevel(logging.DEBUG)
    return _ws_log_handler


class SessionStatus(str, Enum):
    IDLE = "idle"
    LOADING = "loading"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"


@dataclass
class HookInfo:
    id: str
    address: int
    name: str
    enabled: bool = True
    hit_count: int = 0
    script: str = ""


@dataclass
class BreakpointInfo:
    id: str
    address: int
    name: str
    enabled: bool = True
    hit_count: int = 0


@dataclass
class PatchInfo:
    id: str
    address: int
    original_bytes: str  # hex string
    patch_bytes: str     # hex string
    label: str = ""
    enabled: bool = True


@dataclass
class CommentInfo:
    address: int
    text: str


@dataclass
class SessionState:
    """Snapshot of emulator state for the UI."""
    status: SessionStatus = SessionStatus.IDLE
    pc: int = 0
    sp: int = 0
    arch: str = "arm64"
    registers: dict[str, int] = field(default_factory=dict)
    memory_map: list[dict[str, Any]] = field(default_factory=list)
    loaded_module: str | None = None
    module_base: int = 0
    hooks: list[dict[str, Any]] = field(default_factory=list)
    breakpoints: list[dict[str, Any]] = field(default_factory=list)
    execution_log: list[dict[str, Any]] = field(default_factory=list)
    error: str | None = None


class EmulatorSession:
    """
    Wraps a PyUniDbg emulator instance for a single browser session.

    Emulator operations are run in an executor to avoid blocking the
    asyncio event loop.
    """

    def __init__(self, session_id: str):
        self.session_id = session_id
        self.created_at = time.time()
        self.last_active = time.time()
        self.status = SessionStatus.IDLE
        self.arch = "arm64"
        self.api_level = 29

        # Emulator state
        self._emulator: Any = None
        self._module: Any = None
        self._library_path: str | None = None
        self._original_library_path: str | None = None
        self._hooks: dict[str, HookInfo] = {}
        self._breakpoints: dict[str, BreakpointInfo] = {}
        self._patches: dict[str, PatchInfo] = {}
        self._comments: dict[int, str] = {}  # address → comment text
        self._execution_log: list[dict[str, Any]] = []

        # WebSocket connections subscribed to this session
        self.websockets: set[Any] = set()

        # Terminal (PTY) state
        self._pty_master: int | None = None
        self._pty_slave: int | None = None
        self._terminal_process: asyncio.subprocess.Process | None = None
        self._terminal_task: asyncio.Task | None = None

        # Asyncio lock for emulator access
        self._lock = asyncio.Lock()
        self._loop: asyncio.AbstractEventLoop | None = None

    def touch(self) -> None:
        self.last_active = time.time()

    # ── Emulator operations ──────────────────────────────────────────────────

    async def load_library(self, library_path: str, arch: str = "arm64",
                           api_level: int = 29) -> dict[str, Any]:
        """Load a native library into the emulator."""
        self.touch()
        self.arch = arch
        self.api_level = api_level
        self.status = SessionStatus.LOADING
        await self._broadcast({"type": "status_update", "status": "loading"})

        loop = asyncio.get_event_loop()
        try:
            result = await loop.run_in_executor(None, self._do_load, library_path, arch, api_level)
            self.status = SessionStatus.IDLE
            await self._broadcast({"type": "status_update", "status": "idle",
                                   "module": result})
            return result
        except Exception as e:
            self.status = SessionStatus.ERROR
            await self._broadcast({"type": "error", "message": str(e)})
            raise

    def _do_load(self, library_path: str, arch: str, api_level: int) -> dict[str, Any]:
        """Synchronous library loading (runs in thread pool)."""
        try:
            import shutil

            from pyunidbg.android import AndroidEmulator
            # Preserve the original caller-supplied path for project save/reload
            self._original_library_path = library_path
            persist = os.path.join(
                tempfile.gettempdir(),
                f"pyunidbg_session_{self.session_id}{os.path.splitext(library_path)[1]}"
            )
            if os.path.abspath(library_path) != os.path.abspath(persist):
                shutil.copy2(library_path, persist)
            self._library_path = persist
            self._emulator = AndroidEmulator(arch=arch, api_level=api_level)
            self._module = self._emulator.load_library(library_path, call_jni_onload=True)
            # Detect whether JNI_OnLoad is present
            has_jni = (
                getattr(self._module, "jni_onload", None) is not None
                or "JNI_OnLoad" in (getattr(self._module, "exports", {}) or {})
            )
            return {
                "name": self._module.name,
                "base_address": hex(self._module.base_address),
                "size": getattr(self._module, "size", 0),
                "exports": self._get_exports(),
                "has_jni_onload": has_jni,
            }
        except Exception as e:
            logger.error("Failed to load library: %s", e)
            raise RuntimeError(f"Load failed: {e}") from e

    async def unload_library(self) -> dict[str, Any]:
        """Unload the currently loaded library and reset emulator state."""
        self.touch()
        if not self._emulator and not self._module:
            raise RuntimeError("No library is loaded")

        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._do_unload)

        self._hooks.clear()
        self._breakpoints.clear()
        self._patches.clear()
        self._comments.clear()
        self._execution_log.clear()
        self.status = SessionStatus.IDLE

        await self._broadcast({"type": "status_update", "status": "idle"})
        await self._broadcast({"type": "library_unloaded"})
        return {"unloaded": True}

    def _do_unload(self) -> None:
        """Synchronous library unload (runs in thread pool)."""
        self._emulator = None
        self._module = None
        self._original_library_path = None
        if self._library_path:
            try:
                os.unlink(self._library_path)
            except OSError:
                pass
            self._library_path = None

    def _get_exports(self) -> list[dict[str, Any]]:
        if not self._module:
            return []
        try:
            exports = []
            for name, addr in (getattr(self._module, "exports", {}) or {}).items():
                exports.append({"name": name, "address": hex(addr)})
            return exports[:200]
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return []

    async def run_function(self, function: str, args: list[Any]) -> dict[str, Any]:
        """Call a function in the loaded library."""
        self.touch()
        if not self._emulator or not self._module:
            raise RuntimeError("No library loaded")

        self.status = SessionStatus.RUNNING
        await self._broadcast({"type": "status_update", "status": "running"})

        loop = asyncio.get_event_loop()
        try:
            result = await loop.run_in_executor(None, self._do_call, function, args)
            self.status = SessionStatus.IDLE
            await self._broadcast({"type": "status_update", "status": "idle"})
            await self._broadcast({"type": "execution_complete", "result": result})
            return result
        except Exception as e:
            self.status = SessionStatus.ERROR
            await self._broadcast({"type": "error", "message": str(e)})
            raise

    def _do_call(self, function: str, args: list[Any]) -> dict[str, Any]:
        if not self._module:
            raise RuntimeError("No library loaded")
        try:
            addr = self._module.get_function_address(function)
            if addr is None:
                raise ValueError(f"Function not found: {function}")

            # Handle Thumb bit (ARM32): strip bit 0 and toggle Thumb mode
            is_thumb = False
            if self.arch == "arm" and (addr & 1):
                is_thumb = True
                addr = addr & ~1
                try:
                    self._emulator.set_thumb_mode(True)
                except Exception:
                    pass

            # Auto-prepend JNIEnv* + jobject for Java_ functions
            call_args = list(args or [])
            if function.startswith("Java_"):
                jni_env = getattr(self._emulator, "_jni_env_ptr", None) or \
                          getattr(self._emulator, "jni_env_ptr", None) or 0
                jobj = getattr(self._emulator, "_jobject_ptr", None) or \
                       getattr(self._emulator, "jobject_ptr", None) or 0
                if not call_args or call_args[0] == 0:
                    call_args = [jni_env, jobj] + [a for a in call_args if a not in (jni_env, jobj)]

            try:
                result = self._emulator.call(addr, call_args)
            finally:
                if is_thumb:
                    try:
                        self._emulator.set_thumb_mode(False)
                    except Exception:
                        pass

            return {
                "function": function,
                "result": result,
                "result_hex": hex(result) if isinstance(result, int) else str(result),
            }
        except Exception as e:
            raise RuntimeError(str(e)) from e

    async def get_registers(self) -> dict[str, Any]:
        """Read current register values."""
        self.touch()
        if not self._emulator:
            return self._mock_registers()
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._do_get_registers)

    def _do_get_registers(self) -> dict[str, Any]:
        try:
            ctx = self._emulator.get_cpu_context()
            if ctx:
                return ctx.dump()
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
        return self._mock_registers()

    def _mock_registers(self) -> dict[str, Any]:
        if self.arch == "arm64":
            return {f"x{i}": 0 for i in range(31)} | {"sp": 0, "pc": 0, "nzcv": 0}
        return {f"r{i}": 0 for i in range(16)} | {"sp": 0, "pc": 0, "cpsr": 0}

    async def read_memory(self, address: int, size: int) -> bytes:
        """Read bytes from emulator memory."""
        self.touch()
        if not self._emulator:
            return bytes(size)
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._do_read_memory, address, size)

    def _do_read_memory(self, address: int, size: int) -> bytes:
        try:
            return bytes(self._emulator.mem_read(address, size))
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return bytes(size)

    async def write_memory(self, address: int, data: bytes) -> bool:
        """Write bytes to emulator memory."""
        self.touch()
        if not self._emulator:
            return False
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._do_write_memory, address, data)

    def _do_write_memory(self, address: int, data: bytes) -> bool:
        try:
            self._emulator.mem_write(address, data)
            return True
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return False

    async def get_memory_map(self) -> list[dict[str, Any]]:
        """Get current memory map."""
        self.touch()
        if not self._emulator:
            return []
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._do_get_memory_map)

    def _do_get_memory_map(self) -> list[dict[str, Any]]:
        try:
            regions = []
            for r in self._emulator.mem_regions():
                regions.append({
                    "start": hex(r[0]),
                    "end": hex(r[1]),
                    "size": r[1] - r[0],
                    "perms": r[2],
                })
            return regions
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return []

    async def disassemble(self, address: int, count: int = 20) -> list[dict[str, Any]]:
        """Disassemble instructions at address."""
        self.touch()
        if not self._emulator:
            return []
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._do_disassemble, address, count)

    def _do_disassemble(self, address: int, count: int) -> list[dict[str, Any]]:
        try:
            insns = self._emulator.disassemble(address, count * 4, count=count)
            return [{"address": hex(addr), "mnemonic": mnemonic,
                     "op_str": op_str, "bytes": ""} for addr, mnemonic, op_str in insns]
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return []

    async def get_symbols(self) -> dict[str, Any]:
        """Get all symbols (exports, imports, sections) from the loaded binary."""
        self.touch()
        if not self._library_path:
            return {"exports": [], "imports": [], "sections": []}
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._do_get_symbols)

    def _do_get_symbols(self) -> dict[str, Any]:
        result: dict[str, Any] = {"exports": [], "imports": [], "sections": []}
        try:
            import lief
            elf = lief.parse(self._library_path)
            if elf is None:
                return result

            for sym in elf.exported_symbols:
                result["exports"].append({
                    "name": sym.name,
                    "address": hex(sym.value),
                    "address_int": sym.value,
                    "size": sym.size,
                })
            result["exports"].sort(key=lambda s: s["address_int"])

            for sym in elf.imported_symbols:
                result["imports"].append({"name": sym.name})

            for sec in elf.sections:
                result["sections"].append({
                    "name": sec.name,
                    "address": hex(sec.virtual_address),
                    "address_int": sec.virtual_address,
                    "size": sec.size,
                    "type": str(sec.type).split(".")[-1],
                })
        except ImportError:
            logger.warning("lief not available for symbol extraction")
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
        return result

    # ── Function signature scanning ──────────────────────────────────────────

    async def scan_functions(self, filter_str: str = "", jni_only: bool = False,
                             limit: int = 0) -> dict[str, Any]:
        """Scan the loaded library and infer function argument signatures."""
        self.touch()
        if not self._library_path:
            return {"functions": [], "error": "No library loaded"}
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, self._do_scan_functions, filter_str, jni_only, limit
        )

    def _do_scan_functions(self, filter_str: str, jni_only: bool,
                           limit: int) -> dict[str, Any]:
        try:
            import fnmatch

            import lief

            elf = lief.parse(self._library_path)
            if elf is None:
                return {"functions": [], "error": "Failed to parse ELF"}

            is_64bit = elf.header.machine_type in (
                lief.ELF.ARCH.AARCH64, lief.ELF.ARCH.X86_64
            )
            ptr_type = "uint64_t*" if is_64bit else "uint32_t*"

            # Load base address offset (if module is loaded)
            base = self._module.base_address if self._module else 0

            functions = []
            for sym in elf.symbols:
                if sym.type != lief.ELF.Symbol.TYPE.FUNC:
                    continue
                if sym.value == 0 or not sym.name:
                    continue
                if jni_only and not sym.name.startswith("Java_"):
                    continue
                if filter_str and not fnmatch.fnmatch(sym.name.lower(),
                                                      f"*{filter_str.lower()}*"):
                    continue

                info = self._analyze_function_sig(sym.name, sym.value + base,
                                                   sym.size, is_64bit, ptr_type)
                functions.append(info)

            functions.sort(key=lambda f: f["address"])
            if limit > 0:
                functions = functions[:limit]

            return {"functions": functions, "total": len(functions),
                    "is_64bit": is_64bit}

        except Exception as e:
            logger.debug("scan_functions error (suppressed): %s", e, exc_info=True)
            return {"functions": [], "error": str(e)}

    # JNI type descriptor → C type
    _JNI_TYPES: dict[str, tuple] = {
        "Z": ("jboolean", "bool"),
        "B": ("jbyte", "int8_t"),
        "C": ("jchar", "uint16_t"),
        "S": ("jshort", "int16_t"),
        "I": ("jint", "int32_t"),
        "J": ("jlong", "int64_t"),
        "F": ("jfloat", "float"),
        "D": ("jdouble", "double"),
        "V": ("void", "void"),
    }

    # Known libc / common function signatures
    _KNOWN_SIGS: dict[str, dict] = {
        "malloc":   {"ret": "void*",  "args": [{"name": "size",  "type": "size_t"}]},
        "free":     {"ret": "void",   "args": [{"name": "ptr",   "type": "void*"}]},
        "memcpy":   {"ret": "void*",  "args": [{"name": "dst",   "type": "void*"},
                                                {"name": "src",   "type": "const void*"},
                                                {"name": "n",     "type": "size_t"}]},
        "memset":   {"ret": "void*",  "args": [{"name": "s",     "type": "void*"},
                                                {"name": "c",     "type": "int"},
                                                {"name": "n",     "type": "size_t"}]},
        "strlen":   {"ret": "size_t", "args": [{"name": "s",     "type": "const char*"}]},
        "strcpy":   {"ret": "char*",  "args": [{"name": "dst",   "type": "char*"},
                                                {"name": "src",   "type": "const char*"}]},
        "strcmp":   {"ret": "int",    "args": [{"name": "s1",    "type": "const char*"},
                                                {"name": "s2",    "type": "const char*"}]},
        "strncmp":  {"ret": "int",    "args": [{"name": "s1",    "type": "const char*"},
                                                {"name": "s2",    "type": "const char*"},
                                                {"name": "n",     "type": "size_t"}]},
        "sprintf":  {"ret": "int",    "args": [{"name": "buf",   "type": "char*"},
                                                {"name": "fmt",   "type": "const char*"},
                                                {"name": "...",   "type": ""}]},
        "printf":   {"ret": "int",    "args": [{"name": "fmt",   "type": "const char*"},
                                                {"name": "...",   "type": ""}]},
        "open":     {"ret": "int",    "args": [{"name": "path",  "type": "const char*"},
                                                {"name": "flags", "type": "int"}]},
        "read":     {"ret": "ssize_t","args": [{"name": "fd",    "type": "int"},
                                                {"name": "buf",   "type": "void*"},
                                                {"name": "count", "type": "size_t"}]},
        "write":    {"ret": "ssize_t","args": [{"name": "fd",    "type": "int"},
                                                {"name": "buf",   "type": "const void*"},
                                                {"name": "count", "type": "size_t"}]},
        "pthread_create": {"ret": "int", "args": [
            {"name": "thread", "type": "pthread_t*"},
            {"name": "attr",   "type": "const pthread_attr_t*"},
            {"name": "fn",     "type": "void*(*)(void*)"},
            {"name": "arg",    "type": "void*"},
        ]},
    }

    def _analyze_function_sig(self, name: str, address: int, size: int,
                               is_64bit: bool, ptr_type: str) -> dict[str, Any]:
        """Infer function argument signature from name/type."""
        result: dict[str, Any] = {
            "name": name, "address": hex(address), "size": size,
            "type": "native", "return_type": "unknown",
            "arguments": [], "signature": None, "demangled": None,
        }

        # ── JNI functions ──
        if name.startswith("Java_"):
            result["type"] = "jni"
            # Always start with JNIEnv* + jobject/jclass
            args = [
                {"name": "env",  "type": "JNIEnv*"},
                {"name": "thiz", "type": "jobject"},
            ]
            # Parse descriptor embedded in name (Java_pkg_Class_method__desc)
            # e.g. Java_com_example_Foo_encrypt__Ljava_lang_String_2
            parts = name.split("__", 1)
            if len(parts) == 2:
                desc = parts[1].replace("_2", ";").replace("_3", "[")
                parsed, ret = self._parse_jni_desc(desc, is_64bit)
                args.extend(parsed)
                result["return_type"] = ret
            else:
                result["return_type"] = "jint"
            result["arguments"] = args
            cls_parts = name[len("Java_"):].split("_")
            result["class_name"] = ".".join(cls_parts[:-1]) if len(cls_parts) > 1 else ""
            result["method_name"] = cls_parts[-1] if cls_parts else name
            arg_str = ", ".join(f"{a['type']} {a['name']}" for a in args)
            result["signature"] = f"{result['return_type']} {name}({arg_str})"

        # ── C++ mangled names ──
        elif name.startswith("_Z"):
            result["type"] = "cpp"
            try:
                import subprocess
                out = subprocess.run(
                    ["c++filt", name], capture_output=True, text=True, timeout=2
                )
                if out.returncode == 0 and out.stdout.strip() != name:
                    result["demangled"] = out.stdout.strip()
                    result["signature"] = result["demangled"]
            except Exception:
                pass

        # ── Known libc / system functions ──
        else:
            known = self._KNOWN_SIGS.get(name)
            if known:
                result["type"] = "libc"
                result["return_type"] = known["ret"]
                result["arguments"] = known["args"]
                arg_str = ", ".join(f"{a['type']} {a['name']}" for a in known["args"])
                result["signature"] = f"{known['ret']} {name}({arg_str})"

        return result

    def _parse_jni_desc(self, descriptor: str, is_64bit: bool) -> tuple:
        """Parse a JNI method descriptor string, return (args_list, return_type)."""
        ptr = "jlong" if is_64bit else "jint"
        args = []
        i = 0
        ret = "jint"

        def _next_type(s: str, pos: int) -> tuple:
            """Consume one JNI type at pos; return (c_type, new_pos)."""
            if pos >= len(s):
                return "jint", pos
            ch = s[pos]
            if ch in self._JNI_TYPES:
                return self._JNI_TYPES[ch][0], pos + 1
            if ch == "L":
                end = s.find(";", pos)
                cls = s[pos + 1: end if end != -1 else len(s)].replace("/", ".")
                return f"jobject/*{cls}*/", (end + 1 if end != -1 else len(s))
            if ch == "[":
                inner, np = _next_type(s, pos + 1)
                return f"{inner}[]", np
            return "jint", pos + 1

        # Descriptor may start after '(' in a full descriptor like (ILjava/lang/String;)V
        if descriptor.startswith("("):
            close = descriptor.find(")")
            if close != -1:
                params_str = descriptor[1:close]
                ret_str = descriptor[close + 1:]
                while i < len(params_str):
                    t, i = _next_type(params_str, i)
                    args.append({"name": f"arg{len(args)}", "type": t})
                ret, _ = _next_type(ret_str, 0)
                return args, ret
        else:
            # Encoded descriptor (from name suffix after __)
            while i < len(descriptor):
                t, i = _next_type(descriptor, i)
                if t != "void":
                    args.append({"name": f"arg{len(args)}", "type": t})
            return args, "jint"

        return args, ret

    # ── Strings extraction ──────────────────────────────────────────────────

    async def get_strings(self, min_length: int = 4, encoding: str = "all") -> dict[str, Any]:
        """Extract printable strings from the static ELF binary."""
        self.touch()
        if not self._library_path:
            return {"strings": [], "error": "No library loaded"}
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._do_get_strings, min_length, encoding)

    def _do_get_strings(self, min_length: int, encoding: str) -> dict[str, Any]:
        try:
            from pyunidbg.analysis.strings_extractor import extract_strings
            result = extract_strings(self._library_path, min_length=min_length,
                                     encoding=encoding)
            return result
        except Exception as e:
            logger.debug("Strings extraction error", exc_info=True)
            return {"strings": [], "error": str(e)}

    # ── Memory search ───────────────────────────────────────────────────────

    async def search_memory(self, pattern: str, search_type: str = "hex",
                            start: int = 0, end: int = 0,
                            max_results: int = 256) -> dict[str, Any]:
        """Search live emulator memory for a pattern."""
        self.touch()
        if not self._emulator:
            return {"matches": [], "error": "No emulator loaded"}
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, self._do_memory_search, pattern, search_type, start, end, max_results
        )

    def _do_memory_search(self, pattern: str, search_type: str,
                          start: int, end: int, max_results: int) -> dict[str, Any]:
        try:
            # Build the raw byte needle
            if search_type == "hex":
                needle = bytes.fromhex(pattern.replace(" ", "").replace("0x", ""))
            elif search_type == "ascii":
                needle = pattern.encode("ascii", errors="replace")
            elif search_type == "utf16":
                needle = pattern.encode("utf-16-le")
            elif search_type == "int32":
                import struct
                needle = struct.pack("<I", int(pattern, 0))
            elif search_type == "int64":
                import struct
                needle = struct.pack("<Q", int(pattern, 0))
            else:
                needle = bytes.fromhex(pattern.replace(" ", ""))

            matches: list[dict[str, Any]] = []
            regions = list(self._emulator.mem_regions())

            for region_start, region_end, perms in regions:
                if end and region_start >= end:
                    continue
                if start and region_end <= start:
                    continue
                r_start = max(region_start, start) if start else region_start
                r_end = min(region_end, end) if end else region_end
                size = r_end - r_start
                if size <= 0 or size > 128 * 1024 * 1024:
                    continue
                try:
                    data = bytes(self._emulator.mem_read(r_start, size))
                except Exception:
                    continue
                idx = 0
                while idx < len(data):
                    pos = data.find(needle, idx)
                    if pos == -1:
                        break
                    abs_addr = r_start + pos
                    preview_start = max(0, pos - 8)
                    preview = data[preview_start: pos + len(needle) + 8]
                    matches.append({
                        "address": hex(abs_addr),
                        "hex_preview": preview.hex(),
                        "offset_in_region": hex(pos),
                    })
                    if len(matches) >= max_results:
                        return {"matches": matches, "truncated": True, "count": len(matches)}
                    idx = pos + len(needle)

            return {"matches": matches, "truncated": False, "count": len(matches)}
        except Exception as e:
            logger.debug("Memory search error", exc_info=True)
            return {"matches": [], "error": str(e)}

    async def static_disassemble(self, target: str = "", section: str = "",
                                  address: int = 0, count: int = 200) -> dict[str, Any]:
        """Disassemble directly from the ELF file using lief+capstone (no emulator needed)."""
        self.touch()
        if not self._library_path:
            return {"error": "No library loaded", "instructions": []}
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, self._do_static_disassemble, target, section, address, count
        )

    def _do_static_disassemble(self, target: str, section: str,
                                address: int, count: int) -> dict[str, Any]:
        try:
            import lief
            from capstone import CS_ARCH_ARM, CS_ARCH_ARM64, CS_MODE_ARM, CS_MODE_LITTLE_ENDIAN, Cs

            elf = lief.parse(self._library_path)
            if elf is None:
                return {"error": "Failed to parse ELF", "instructions": []}

            is_64 = self.arch in ("arm64", "x86_64")
            if is_64:
                cs = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
            else:
                cs = Cs(CS_ARCH_ARM, CS_MODE_ARM | CS_MODE_LITTLE_ENDIAN)

            # Build address → symbol name lookup
            sym_lookup: dict[int, str] = {}
            for sym in elf.exported_symbols:
                if sym.value:
                    sym_lookup[sym.value] = sym.name

            # ── Special mode: disassemble all FUNC symbols ──────────────────
            if target == "all_functions":
                all_instructions: list[dict[str, Any]] = []
                seen: set = set()
                func_symbols = sorted(
                    [s for s in elf.symbols
                     if s.type == lief.ELF.Symbol.TYPE.FUNC and s.value and s.name],
                    key=lambda s: s.value,
                )
                # Fallback: also include exported symbols that have no TYPE.FUNC
                exported_names = {s.name for s in func_symbols}
                for sym in elf.exported_symbols:
                    if sym.value and sym.name and sym.name not in exported_names:
                        func_symbols.append(sym)
                func_symbols.sort(key=lambda s: s.value)
                for sym in func_symbols:
                    if sym.value in seen:
                        continue
                    seen.add(sym.value)
                    read_size = (sym.size if sym.size > 0 else count * 4)
                    read_size = min(read_size, count * 4)
                    try:
                        raw = bytes(elf.get_content_from_virtual_address(sym.value, read_size))
                    except Exception:
                        continue
                    # Label first instruction as the function name
                    first = True
                    for insn in cs.disasm(raw, sym.value):
                        entry: dict[str, Any] = {
                            "address": hex(insn.address),
                            "bytes": insn.bytes.hex(),
                            "mnemonic": insn.mnemonic,
                            "op_str": insn.op_str,
                        }
                        if first:
                            entry["label"] = sym.name
                            first = False
                        lbl = sym_lookup.get(insn.address)
                        if lbl and not entry.get("label"):
                            entry["label"] = lbl
                        all_instructions.append(entry)
                return {
                    "target": "all_functions",
                    "base_address": hex(func_symbols[0].value) if func_symbols else "0x0",
                    "size": 0,
                    "count": len(all_instructions),
                    "functions": len(func_symbols),
                    "instructions": all_instructions,
                }

            code = b""
            base_addr = 0
            func_name = ""
            func_size = 0

            if target:
                for sym in elf.exported_symbols:
                    if sym.name == target:
                        base_addr = sym.value
                        func_name = sym.name
                        func_size = sym.size if sym.size > 0 else count * 4
                        break
                else:
                    for sym in elf.symbols:
                        if sym.name == target:
                            base_addr = sym.value
                            func_name = sym.name
                            func_size = sym.size if sym.size > 0 else count * 4
                            break
                    else:
                        return {"error": f"Symbol not found: {target}", "instructions": []}
                read_size = min(func_size, count * 4)
                code = bytes(elf.get_content_from_virtual_address(base_addr, read_size))

            elif section:
                for sec in elf.sections:
                    if sec.name == section:
                        base_addr = sec.virtual_address
                        code = bytes(sec.content)
                        func_name = section
                        break
                else:
                    return {"error": f"Section not found: {section}", "instructions": []}

            elif address:
                base_addr = address
                read_size = count * 4
                code = bytes(elf.get_content_from_virtual_address(address, read_size))
                func_name = f"0x{address:x}"

            else:
                for sec in elf.sections:
                    if sec.name == ".text":
                        base_addr = sec.virtual_address
                        code = bytes(sec.content)
                        func_name = ".text"
                        break
                else:
                    base_addr = elf.header.entrypoint
                    code = bytes(elf.get_content_from_virtual_address(base_addr, count * 4))
                    func_name = "entry"

            instructions = []
            insn_count = 0
            for insn in cs.disasm(code, base_addr):
                if insn_count >= count:
                    break
                entry: dict[str, Any] = {
                    "address": hex(insn.address),
                    "bytes": insn.bytes.hex(),
                    "mnemonic": insn.mnemonic,
                    "op_str": insn.op_str,
                }
                label = sym_lookup.get(insn.address)
                if label:
                    entry["label"] = label
                instructions.append(entry)
                insn_count += 1

            return {
                "target": func_name,
                "base_address": hex(base_addr),
                "size": len(code),
                "count": len(instructions),
                "instructions": instructions,
            }

        except ImportError as e:
            return {"error": f"Missing dependency: {e}", "instructions": []}
        except Exception as e:
            logger.debug("Static disassembly error", exc_info=True)
            return {"error": str(e), "instructions": []}

    async def add_hook(self, address: int, name: str, script: str = "") -> str:
        """Add a hook at the given address."""
        self.touch()
        hook_id = str(uuid.uuid4())[:8]
        hook = HookInfo(id=hook_id, address=address, name=name, script=script)
        self._hooks[hook_id] = hook

        if self._emulator:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, self._do_add_hook, hook)

        await self._broadcast({"type": "hook_added", "hook": self._hook_to_dict(hook)})
        return hook_id

    def _do_add_hook(self, hook: HookInfo) -> None:
        try:
            session_ref = self

            def callback(emu, address, size, user_data):
                hook.hit_count += 1
                asyncio.run_coroutine_threadsafe(
                    session_ref._broadcast({
                        "type": "hook_hit",
                        "hook_id": hook.id,
                        "address": hex(address),
                        "hit_count": hook.hit_count,
                    }),
                    asyncio.get_event_loop()
                )

            self._emulator.hook_add_code(hook.address, callback)
        except Exception as e:
            logger.warning("Hook add failed: %s", e)

    async def remove_hook(self, hook_id: str) -> bool:
        """Remove a hook by ID."""
        if hook_id not in self._hooks:
            return False
        del self._hooks[hook_id]
        await self._broadcast({"type": "hook_removed", "hook_id": hook_id})
        return True

    async def get_hooks(self) -> list[dict[str, Any]]:
        return [self._hook_to_dict(h) for h in self._hooks.values()]

    def _hook_to_dict(self, h: HookInfo) -> dict[str, Any]:
        return {"id": h.id, "address": hex(h.address), "name": h.name,
                "enabled": h.enabled, "hit_count": h.hit_count, "script": h.script}

    async def add_breakpoint(self, address: int, name: str) -> str:
        """Add a breakpoint."""
        bp_id = str(uuid.uuid4())[:8]
        bp = BreakpointInfo(id=bp_id, address=address, name=name)
        self._breakpoints[bp_id] = bp
        await self._broadcast({"type": "breakpoint_added", "breakpoint": self._bp_to_dict(bp)})
        return bp_id

    async def remove_breakpoint(self, bp_id: str) -> bool:
        if bp_id not in self._breakpoints:
            return False
        del self._breakpoints[bp_id]
        await self._broadcast({"type": "breakpoint_removed", "bp_id": bp_id})
        return True

    async def get_breakpoints(self) -> list[dict[str, Any]]:
        return [self._bp_to_dict(b) for b in self._breakpoints.values()]

    def _bp_to_dict(self, b: BreakpointInfo) -> dict[str, Any]:
        return {"id": b.id, "address": hex(b.address), "name": b.name,
                "enabled": b.enabled, "hit_count": b.hit_count}

    async def execute_script(self, code: str, script_type: str = "python") -> dict[str, Any]:
        """Execute a Python or Frida script."""
        self.touch()
        if not self._emulator:
            raise RuntimeError("No emulator running")
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._do_execute_script, code, script_type)

    def _do_execute_script(self, code: str, script_type: str) -> dict[str, Any]:
        output_lines = []
        try:
            if script_type == "python":
                globs = {
                    "emu": self._emulator,
                    "module": self._module,
                    "print": lambda *a: output_lines.append(" ".join(str(x) for x in a)),
                }
                # SECURITY: exec() executes arbitrary code — only use with trusted input
                logger.warning("Executing user-provided code via exec() — ensure input is trusted")
                exec(code, globs)
                return {"success": True, "output": "\n".join(output_lines)}
            elif script_type == "frida":
                from pyunidbg.scripting import ScriptEngine
                engine = ScriptEngine(self._emulator)
                script = engine.create_script(code)
                script.load()
                return {"success": True, "output": "Script loaded"}
            else:
                return {"success": False, "output": f"Unknown script type: {script_type}"}
        except Exception as e:
            return {"success": False, "output": str(e)}

    async def run_analysis(self, analysis_type: str, options: dict[str, Any]) -> dict[str, Any]:
        """Run analysis (coverage, trace, taint, deobfuscation, etc.)."""
        self.touch()
        if not self._emulator:
            raise RuntimeError("No emulator running")
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._do_analysis, analysis_type, options)

    def _do_anti_tampering(self) -> list:
        """
        Scan for anti-tampering patterns.

        Strategy (most-to-least reliable):
        1. Scan the raw ELF file bytes directly — works even before emulation.
        2. Fall back to scanning the emulator's executable memory regions.
        """
        import struct

        from pyunidbg.analysis.anti_tampering import (
            KNOWN_SIGNATURES,
            Severity,
            TamperFinding,
        )

        findings: list = []
        seen_addrs: set = set()

        def _scan_bytes(data: bytes, base_offset: int = 0) -> list:
            found = []
            for sig in KNOWN_SIGNATURES:
                for const in sig.constants:
                    needle = struct.pack("<I", const & 0xFFFFFFFF)
                    idx = 0
                    while idx < len(data):
                        pos = data.find(needle, idx)
                        if pos == -1:
                            break
                        addr = base_offset + pos
                        if addr not in seen_addrs:
                            seen_addrs.add(addr)
                            found.append(TamperFinding(
                                check_type=sig.check_type,
                                address=addr,
                                severity=Severity.MEDIUM,
                                description=(
                                    f"{sig.name} constant 0x{const:08x} at file offset "
                                    f"0x{pos:x} (vaddr 0x{addr:x})"
                                ),
                            ))
                        idx = pos + 4
            return found

        # ── Pass 1: scan raw ELF file bytes (most reliable) ──
        if self._library_path:
            try:
                import lief
                elf = lief.parse(self._library_path)
                if elf is not None and self._module:
                    base = self._module.base_address
                    for seg in elf.segments:
                        import lief as _lief
                        if seg.type != _lief.ELF.Segment.TYPE.LOAD:
                            continue
                        seg_data = bytes(seg.content)
                        seg_vaddr = base + seg.virtual_address
                        findings.extend(_scan_bytes(seg_data, seg_vaddr))
            except Exception as e:
                logger.debug("Anti-tampering file scan error (suppressed): %s", e)

        # ── Pass 2: scan live emulator memory (always run to catch JIT-patched code) ──
        if self._emulator:
            try:
                from pyunidbg.analysis import AntiTamperingDetector
                from pyunidbg.core.constants import MemoryProtection
                detector = AntiTamperingDetector(self._emulator)
                # Try exec regions first; fall back to all readable regions
                regions = [
                    (r.start, r.size) for r in self._emulator.memory.get_regions()
                    if r.protection & MemoryProtection.EXEC
                ]
                if not regions:
                    regions = [
                        (r.start, r.size) for r in self._emulator.memory.get_regions()
                        if r.protection & MemoryProtection.READ
                    ]
                logger.debug(
                    "Anti-tampering: scanning %d memory region(s) in emulator", len(regions)
                )
                mem_findings = detector.scan_constants(regions if regions else None)
                for f in mem_findings:
                    if f.address not in seen_addrs:
                        seen_addrs.add(f.address)
                        findings.append(f)
            except Exception as e:
                logger.warning("Anti-tampering emulator scan error: %s", e, exc_info=True)

        if not findings:
            logger.debug(
                "Anti-tampering: no known signatures found in '%s'",
                self._library_path or "<unknown>",
            )

        return findings

    def _do_analysis(self, analysis_type: str, options: dict[str, Any]) -> dict[str, Any]:
        try:
            if analysis_type == "coverage":
                from pyunidbg.analysis import CoverageTracker
                tracker = CoverageTracker(self._emulator)
                tracker.start()
                func = options.get("function")
                if func and self._module:
                    addr = self._module.get_function_address(func)
                    if addr:
                        try:
                            self._emulator.call(addr)
                        except Exception as e:
                            logger.debug("Coverage call error (suppressed): %s", e)
                tracker.stop()
                stats = tracker.stats
                return {
                    "type": "coverage",
                    "unique_blocks": stats.unique_blocks,
                    "total_blocks": stats.total_blocks,
                    "unique_instructions": stats.unique_instructions,
                }
            elif analysis_type == "trace":
                from pyunidbg.analysis import InstructionTracer
                tracer = InstructionTracer(self._emulator)
                tracer.start()
                func = options.get("function")
                if func and self._module:
                    addr = self._module.get_function_address(func)
                    if addr:
                        try:
                            self._emulator.call(addr)
                        except Exception as e:
                            logger.debug("Trace call error (suppressed): %s", e)
                tracer.stop()
                raw_entries = tracer.entries if hasattr(tracer, "entries") else []
                serialized = []
                for e in raw_entries[:500]:
                    entry = {
                        "address": hex(e.address),
                        "mnemonic": e.disasm.mnemonic if e.disasm else "",
                        "op_str": e.disasm.operands if e.disasm else "",
                        "event": e.event_type.name if hasattr(e, "event_type") else "",
                        "symbol": getattr(e, "symbol", ""),
                    }
                    serialized.append(entry)
                return {"type": "trace", "count": len(raw_entries), "entries": serialized}
            elif analysis_type == "rop":
                from pyunidbg.pwn import create_pwn_context
                ctx = create_pwn_context(self._emulator)
                result = ctx.find_gadgets(limit=options.get("max_gadgets", 200))
                gadgets = result.gadgets if hasattr(result, "gadgets") else list(result)
                return {
                    "type": "rop",
                    "count": len(gadgets),
                    "gadgets": [{"address": hex(g.address), "description": str(g)} for g in gadgets[:200]],
                }
            elif analysis_type == "rop_chain":
                from pyunidbg.pwn import create_pwn_context
                ctx = create_pwn_context(self._emulator)
                goal = options.get("goal", "").lower().strip()
                # Search for gadgets relevant to the goal
                patterns = []
                if "execve" in goal or "/bin/sh" in goal:
                    patterns = ["pop", "mov", "ret"]
                elif "mprotect" in goal:
                    patterns = ["pop", "mov", "ret"]
                elif "ret" in goal or "return" in goal:
                    patterns = ["ret"]
                else:
                    # Generic: use goal words as gadget search patterns
                    patterns = [w for w in goal.split() if len(w) >= 3][:3] or ["ret", "pop"]
                chain_gadgets = []
                seen_addrs = set()
                for pat in patterns:
                    found = ctx.find_gadgets(pattern=pat, limit=20)
                    gs = found.gadgets if hasattr(found, "gadgets") else list(found)
                    for g in gs:
                        if g.address not in seen_addrs:
                            seen_addrs.add(g.address)
                            chain_gadgets.append({
                                "address": hex(g.address),
                                "description": str(g),
                                "pattern": pat,
                            })
                return {
                    "type": "rop_chain",
                    "goal": goal,
                    "gadgets_found": len(chain_gadgets),
                    "gadgets": chain_gadgets[:50],
                    "note": "Manual chain assembly required; use gadgets above as building blocks.",
                }
            elif analysis_type == "taint":
                from pyunidbg.analysis import TaintColor, TaintEngine, TaintSource
                engine = TaintEngine(self._emulator)
                source_name = options.get("source", "").strip()
                # source_name can be a register (e.g. "x0") or a label
                color = TaintColor.INPUT
                if source_name:
                    # Heuristic: if it looks like a register, taint it; else taint by label
                    import re
                    if re.match(r'^[xwrv]\d+$|^r\d+$|^sp$|^lr$|^pc$', source_name, re.I):
                        src = TaintSource(name="web_input", color=color, register=source_name)
                    else:
                        src = TaintSource(name=source_name or "web_input", color=color)
                    engine.add_source(src)
                engine.start()
                func = options.get("function")
                if func and self._module:
                    addr = self._module.get_function_address(func)
                    if addr:
                        try:
                            self._emulator.call(addr)
                        except Exception as e:
                            logger.debug("Taint call error (suppressed): %s", e)
                engine.stop()
                alerts = engine.alerts
                return {
                    "type": "taint",
                    "alerts": len(alerts),
                    "stats": engine.stats,
                    "findings": [str(a) for a in alerts[:50]],
                }
            elif analysis_type == "deobfuscate":
                from pyunidbg.analysis import Deobfuscator
                if not self._module:
                    return {"type": "deobfuscate", "error": "No module loaded"}
                d = Deobfuscator(self._emulator)
                start_addr = self._module.base_address
                # Limit scan to first 128 KB to avoid very long runtimes
                scan_size = min(self._module.size, 0x20000)
                end_addr = start_addr + scan_size
                block = d.analyze(start_addr, end_addr)
                return {
                    "type": "deobfuscate",
                    "patterns_found": len(block.patterns_found),
                    "stats": d.stats,
                    "patterns": [str(p) for p in block.patterns_found[:50]],
                }
            elif analysis_type == "anti_tampering":
                findings = self._do_anti_tampering()
                return {
                    "type": "anti_tampering",
                    "findings_count": len(findings),
                    "findings": [str(f) for f in findings[:50]],
                }
            elif analysis_type == "concolic":
                from pyunidbg.concolic import ConcolicConfig, create_concolic_engine
                cfg = ConcolicConfig(max_paths=options.get("max_paths", 10))
                engine = create_concolic_engine(self._emulator, cfg)
                start_addr = options.get("start_address")
                if not start_addr and self._module:
                    func = options.get("function")
                    if func:
                        start_addr = self._module.get_function_address(func)
                if not start_addr:
                    return {"type": "concolic", "error": "start_address or function required"}
                results = engine.explore(start=start_addr, max_iterations=options.get("max_iterations", 50))
                paths = getattr(results, "solutions", results) if results else []
                return {"type": "concolic", "paths_found": len(paths) if paths else 0}
            elif analysis_type == "crypto":
                from pyunidbg.analysis.crypto_detection import CryptoDetector
                detector = CryptoDetector(self._library_path)
                matches = detector.scan()
                return {
                    "type": "crypto",
                    "matches_count": len(matches),
                    "matches": [m.to_dict() for m in matches[:100]],
                }
            else:
                return {"type": analysis_type, "error": "Unknown analysis type"}
        except Exception as e:
            return {"type": analysis_type, "error": str(e)}

    async def generate_report(self, fmt: str = "json") -> dict[str, Any]:
        """Generate a session report."""
        self.touch()
        if not self._emulator:
            raise RuntimeError("No emulator running")
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._do_report, fmt)

    def _do_report(self, fmt: str) -> dict[str, Any]:
        try:
            from pyunidbg.reports import ReportGenerator
            gen = ReportGenerator(self._emulator)
            report = gen.generate_report(title="Web Session Report",
                                         include_memory=True, include_registers=True)
            fmt_dispatch = {
                "json": report.to_json,
                "html": report.to_html,
                "markdown": report.to_markdown,
            }
            renderer = fmt_dispatch.get(fmt, report.to_json)
            content = renderer()
            return {"success": True, "content": content, "format": fmt}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # ── Terminal / PTY ───────────────────────────────────────────────────────

    async def start_terminal(self, ws: Any) -> None:
        """Attach a WebSocket to a PTY running pyunidbg shell."""
        master_fd, slave_fd = pty.openpty()
        self._pty_master = master_fd

        env = os.environ.copy()
        env["TERM"] = "xterm-256color"
        env["PYTHONUNBUFFERED"] = "1"

        # Spawn an interactive Python shell with pyunidbg in scope
        init_code = (
            "import code, sys\n"
            "sys.path.insert(0, 'src')\n"
            "print('PyUniDbg interactive shell. Type help() for help.')\n"
            "try:\n"
            "    import pyunidbg; print(f'PyUniDbg {pyunidbg.__version__} ready.')\n"
            "except ImportError:\n"
            "    print('pyunidbg not installed, plain Python shell.')\n"
            "code.interact(banner='', local={'__name__': '__main__'})\n"
        )
        cmd = [sys.executable, "-c", init_code]

        self._terminal_process = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=slave_fd,
            stdout=slave_fd,
            stderr=slave_fd,
            env=env,
        )
        os.close(slave_fd)

        # Read PTY output and forward to WebSocket
        self._terminal_task = asyncio.ensure_future(self._pty_reader(master_fd, ws))

    async def _pty_reader(self, master_fd: int, ws: Any) -> None:
        loop = asyncio.get_event_loop()
        while True:
            try:
                data = await loop.run_in_executor(None, os.read, master_fd, 4096)
                if not data:
                    break
                await ws.send_text(json.dumps({"type": "terminal_output", "data": data.decode("utf-8", errors="replace")}))
            except OSError:
                break
            except Exception as e:
                logger.debug("PTY reader error: %s", e)
                break

    async def write_terminal(self, data: str) -> None:
        """Write input to the PTY."""
        if self._pty_master is not None:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(None, os.write, self._pty_master, data.encode())

    async def run_cli_command(self, command: str) -> str:
        """Run a pyunidbg CLI command and return output."""
        proc = await asyncio.create_subprocess_shell(
            f"{sys.executable} -m pyunidbg {command}",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=os.getcwd(),
        )
        stdout, stderr = await proc.communicate()
        output = stdout.decode() + (("\n" + stderr.decode()) if stderr else "")
        return output

    # ── Patches ──────────────────────────────────────────────────────────────

    async def add_patch(self, address: int, patch_bytes_hex: str,
                        label: str = "") -> dict[str, Any]:
        """Apply a byte patch at address, saving the original bytes for revert."""
        self.touch()
        patch_bytes = bytes.fromhex(patch_bytes_hex)
        patch_id = str(uuid.uuid4())[:8]

        original_hex = ""
        if self._emulator:
            loop = asyncio.get_event_loop()
            try:
                orig = await loop.run_in_executor(
                    None, lambda: self._emulator.mem_read(address, len(patch_bytes))
                )
                original_hex = bytes(orig).hex()
            except Exception:
                logger.debug("Could not read original bytes for patch", exc_info=True)

        info = PatchInfo(
            id=patch_id,
            address=address,
            original_bytes=original_hex,
            patch_bytes=patch_bytes_hex,
            label=label,
            enabled=True,
        )
        self._patches[patch_id] = info

        if self._emulator and patch_bytes:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None, lambda: self._emulator.mem_write(address, patch_bytes)
            )

        await self._broadcast({"type": "patch_added", "patch": self._patch_to_dict(info)})
        return self._patch_to_dict(info)

    async def remove_patch(self, patch_id: str) -> bool:
        """Remove a patch and revert the original bytes."""
        info = self._patches.pop(patch_id, None)
        if not info:
            return False
        if info.enabled and info.original_bytes and self._emulator:
            orig = bytes.fromhex(info.original_bytes)
            loop = asyncio.get_event_loop()
            try:
                await loop.run_in_executor(
                    None, lambda: self._emulator.mem_write(info.address, orig)
                )
            except Exception:
                logger.debug("Could not revert patch bytes", exc_info=True)
        await self._broadcast({"type": "patch_removed", "patch_id": patch_id})
        return True

    async def toggle_patch(self, patch_id: str) -> dict[str, Any]:
        """Enable or disable a patch (apply / revert bytes)."""
        info = self._patches.get(patch_id)
        if not info:
            raise KeyError(patch_id)
        info.enabled = not info.enabled
        if self._emulator:
            loop = asyncio.get_event_loop()
            if info.enabled and info.patch_bytes:
                data = bytes.fromhex(info.patch_bytes)
                await loop.run_in_executor(
                    None, lambda: self._emulator.mem_write(info.address, data)
                )
            elif not info.enabled and info.original_bytes:
                data = bytes.fromhex(info.original_bytes)
                await loop.run_in_executor(
                    None, lambda: self._emulator.mem_write(info.address, data)
                )
        return self._patch_to_dict(info)

    def get_patches(self) -> list[dict[str, Any]]:
        return [self._patch_to_dict(p) for p in self._patches.values()]

    def _patch_to_dict(self, p: PatchInfo) -> dict[str, Any]:
        return {
            "id": p.id,
            "address": hex(p.address),
            "original_bytes": p.original_bytes,
            "patch_bytes": p.patch_bytes,
            "label": p.label,
            "enabled": p.enabled,
        }

    def assemble(self, code: str, address: int = 0) -> str:
        """Assemble text instructions to hex bytes using keystone-engine."""
        try:
            import keystone
            arch_map = {
                "arm64": (keystone.KS_ARCH_ARM64, keystone.KS_MODE_LITTLE_ENDIAN),
                "arm":   (keystone.KS_ARCH_ARM,   keystone.KS_MODE_ARM),
                "x86":   (keystone.KS_ARCH_X86,   keystone.KS_MODE_32),
                "x86_64":(keystone.KS_ARCH_X86,   keystone.KS_MODE_64),
            }
            ks_arch, ks_mode = arch_map.get(self.arch, arch_map["arm64"])
            ks = keystone.Ks(ks_arch, ks_mode)
            encoding, _ = ks.asm(code, address)
            return bytes(encoding).hex()
        except ImportError:
            raise RuntimeError("keystone-engine is not installed")
        except Exception as e:
            raise RuntimeError(f"Assembly failed: {e}") from e

    # ── Comments ─────────────────────────────────────────────────────────────

    def add_comment(self, address: int, text: str) -> None:
        self._comments[address] = text

    def remove_comment(self, address: int) -> bool:
        return self._comments.pop(address, None) is not None

    def get_comments(self) -> list[dict[str, Any]]:
        return [{"address": hex(a), "text": t} for a, t in self._comments.items()]

    # ── CFG & Call Graph ─────────────────────────────────────────────────────

    def get_cfg(self, address: int, max_insns: int = 500) -> dict[str, Any]:
        """Build a control-flow graph starting at `address`."""
        if not self._library_path:
            return {"error": "No library loaded", "nodes": [], "edges": []}
        try:
            import lief
            from capstone import (
                CS_ARCH_ARM,
                CS_ARCH_ARM64,
                CS_GRP_CALL,
                CS_GRP_JUMP,
                CS_GRP_RET,
                CS_MODE_ARM,
                CS_MODE_LITTLE_ENDIAN,
                Cs,
            )

            elf = lief.parse(self._library_path)
            if elf is None:
                return {"error": "Failed to parse ELF", "nodes": [], "edges": []}

            is_64 = self.arch in ("arm64", "x86_64")
            if is_64:
                cs = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
            else:
                cs = Cs(CS_ARCH_ARM, CS_MODE_ARM | CS_MODE_LITTLE_ENDIAN)
            cs.detail = True

            # Read a reasonable chunk from the address
            read_size = min(max_insns * 8, 32768)
            raw = bytes(elf.get_content_from_virtual_address(address, read_size))

            # First pass: disassemble all instructions, record jump targets
            all_insns = []
            leaders: set = {address}
            for insn in cs.disasm(raw, address):
                if len(all_insns) >= max_insns:
                    break
                grps = list(insn.groups)
                is_jump = CS_GRP_JUMP in grps
                is_ret = CS_GRP_RET in grps
                is_call = CS_GRP_CALL in grps
                target = None
                if is_jump:
                    try:
                        target = int(insn.op_str.lstrip("#"), 16)
                        leaders.add(target)
                    except (ValueError, AttributeError):
                        pass
                    leaders.add(insn.address + insn.size)
                all_insns.append({
                    "address": insn.address,
                    "size": insn.size,
                    "mnemonic": insn.mnemonic,
                    "op_str": insn.op_str,
                    "bytes": insn.bytes.hex(),
                    "is_jump": is_jump,
                    "is_ret": is_ret,
                    "is_call": is_call,
                    "target": target,
                    "groups": grps,
                })

            # Second pass: build basic blocks
            blocks: dict[int, dict[str, Any]] = {}
            cur_leader = None
            cur_instrs: list[dict[str, Any]] = []

            for i, insn in enumerate(all_insns):
                if insn["address"] in leaders:
                    if cur_leader is not None and cur_instrs:
                        blocks[cur_leader] = {
                            "id": f"bb_{hex(cur_leader)}",
                            "address": hex(cur_leader),
                            "instructions": cur_instrs,
                        }
                    cur_leader = insn["address"]
                    cur_instrs = []
                cur_instrs.append({
                    "address": hex(insn["address"]),
                    "bytes": insn["bytes"],
                    "mnemonic": insn["mnemonic"],
                    "op_str": insn["op_str"],
                })
                if insn["is_jump"] or insn["is_ret"]:
                    if cur_leader is not None and cur_instrs:
                        blocks[cur_leader] = {
                            "id": f"bb_{hex(cur_leader)}",
                            "address": hex(cur_leader),
                            "instructions": cur_instrs,
                        }
                    cur_leader = None
                    cur_instrs = []

            if cur_leader is not None and cur_instrs:
                blocks[cur_leader] = {
                    "id": f"bb_{hex(cur_leader)}",
                    "address": hex(cur_leader),
                    "instructions": cur_instrs,
                }

            # Build edges
            edges = []
            addr_to_insn = {i["address"]: i for i in all_insns}
            for i, insn in enumerate(all_insns):
                if insn["is_jump"]:
                    # Taken edge
                    if insn["target"] and insn["target"] in blocks:
                        src_id = f"bb_{hex(insn['address'] - sum(x['size'] for x in all_insns[:i] if x['address'] < insn['address'] and insn['address'] - x['address'] < 256))}"
                        # Find which block this instruction belongs to
                        src_block = None
                        for bl_addr, bl in blocks.items():
                            instrs = bl["instructions"]
                            if any(x["address"] == hex(insn["address"]) for x in instrs):
                                src_block = bl["id"]
                                break
                        tgt_block = f"bb_{hex(insn['target'])}"
                        if src_block and tgt_block in {b["id"] for b in blocks.values()}:
                            cond = insn["mnemonic"].startswith("b.") or (
                                insn["mnemonic"] in ("beq", "bne", "blt", "bgt",
                                                     "ble", "bge", "blo", "bhi",
                                                     "cbz", "cbnz", "tbz", "tbnz")
                            )
                            edges.append({
                                "from": src_block,
                                "to": tgt_block,
                                "type": "cond" if cond else "uncond",
                            })
                    # Fall-through (conditional jumps only)
                    if insn["mnemonic"] not in ("b", "br", "ret"):
                        fall_addr = insn["address"] + insn["size"]
                        src_block = None
                        for bl in blocks.values():
                            if any(x["address"] == hex(insn["address"]) for x in bl["instructions"]):
                                src_block = bl["id"]
                                break
                        tgt_block = f"bb_{hex(fall_addr)}"
                        if src_block and tgt_block in {b["id"] for b in blocks.values()}:
                            edges.append({"from": src_block, "to": tgt_block, "type": "fallthrough"})
                elif not insn["is_ret"]:
                    # Check if the next instruction starts a new block (leader)
                    next_addr = insn["address"] + insn["size"]
                    if next_addr in leaders and next_addr in blocks:
                        src_block = None
                        for bl in blocks.values():
                            if any(x["address"] == hex(insn["address"]) for x in bl["instructions"]):
                                src_block = bl["id"]
                                break
                        if src_block:
                            edges.append({
                                "from": src_block,
                                "to": f"bb_{hex(next_addr)}",
                                "type": "fallthrough",
                            })

            # Deduplicate edges
            seen_edges: set = set()
            deduped: list[dict[str, Any]] = []
            for e in edges:
                key = (e["from"], e["to"], e["type"])
                if key not in seen_edges:
                    seen_edges.add(key)
                    deduped.append(e)

            return {
                "address": hex(address),
                "nodes": list(blocks.values()),
                "edges": deduped,
            }
        except ImportError as e:
            return {"error": f"Missing dependency: {e}", "nodes": [], "edges": []}
        except Exception as e:
            logger.debug("CFG build error", exc_info=True)
            return {"error": str(e), "nodes": [], "edges": []}

    def get_callgraph(self) -> dict[str, Any]:
        """Build a call graph from exported symbols using static disassembly."""
        if not self._library_path:
            return {"error": "No library loaded", "nodes": [], "edges": []}
        try:
            import lief
            from capstone import (
                CS_ARCH_ARM,
                CS_ARCH_ARM64,
                CS_GRP_CALL,
                CS_GRP_JUMP,
                CS_MODE_ARM,
                CS_MODE_LITTLE_ENDIAN,
                Cs,
            )

            elf = lief.parse(self._library_path)
            if elf is None:
                return {"error": "Failed to parse ELF", "nodes": [], "edges": []}

            is_64 = self.arch in ("arm64", "x86_64")
            if is_64:
                cs = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
            else:
                cs = Cs(CS_ARCH_ARM, CS_MODE_ARM | CS_MODE_LITTLE_ENDIAN)
            cs.detail = True

            # Build address→name map from all symbols
            addr_to_name: dict[int, str] = {}
            for sym in list(elf.exported_symbols) + list(elf.symbols):
                if sym.value and sym.name:
                    addr_to_name[sym.value] = sym.name

            nodes: dict[str, dict[str, Any]] = {}
            edges_set: set = set()
            edges: list[dict[str, Any]] = []

            for sym in elf.exported_symbols:
                if not sym.value or not sym.name:
                    continue
                func_id = f"fn_{sym.name}"
                if func_id not in nodes:
                    nodes[func_id] = {
                        "id": func_id,
                        "name": sym.name,
                        "address": hex(sym.value),
                    }
                read_size = max(sym.size if sym.size > 0 else 256, 64)
                read_size = min(read_size, 4096)
                try:
                    raw = bytes(elf.get_content_from_virtual_address(sym.value, read_size))
                except Exception:
                    continue
                for insn in cs.disasm(raw, sym.value):
                    grps = list(insn.groups)
                    if CS_GRP_CALL in grps or (CS_GRP_JUMP in grps and insn.mnemonic == "bl"):
                        try:
                            tgt_addr = int(insn.op_str.lstrip("#"), 16)
                        except (ValueError, AttributeError):
                            continue
                        tgt_name = addr_to_name.get(tgt_addr, f"sub_{tgt_addr:x}")
                        tgt_id = f"fn_{tgt_name}"
                        if tgt_id not in nodes:
                            nodes[tgt_id] = {
                                "id": tgt_id,
                                "name": tgt_name,
                                "address": hex(tgt_addr),
                            }
                        edge_key = (func_id, tgt_id)
                        if edge_key not in edges_set:
                            edges_set.add(edge_key)
                            edges.append({"from": func_id, "to": tgt_id})

            return {
                "nodes": list(nodes.values()),
                "edges": edges,
            }
        except ImportError as e:
            return {"error": f"Missing dependency: {e}", "nodes": [], "edges": []}
        except Exception as e:
            logger.debug("Callgraph build error", exc_info=True)
            return {"error": str(e), "nodes": [], "edges": []}

    # ── Project save / load ──────────────────────────────────────────────────

    def save_project(self) -> dict[str, Any]:
        """Serialize all session annotations to a portable project dict."""
        return {
            "version": "1.0",
            "binary_path": self._library_path or "",
            "original_binary_path": self._original_library_path or "",
            "arch": self.arch,
            "api_level": self.api_level,
            "patches": [self._patch_to_dict(p) for p in self._patches.values()],
            "comments": {hex(a): t for a, t in self._comments.items()},
            "hooks": [self._hook_to_dict(h) for h in self._hooks.values()],
            "breakpoints": [self._bp_to_dict(b) for b in self._breakpoints.values()],
            "bookmarks": [],
        }

    async def load_project(self, data: dict[str, Any]) -> dict[str, Any]:
        """Restore annotations from a saved project dict.

        If the project contains an ``original_binary_path`` that still exists on
        disk and no library is currently loaded, the binary is automatically
        reloaded before applying patches/hooks/breakpoints.
        """
        restored: dict[str, int] = {
            "patches": 0, "comments": 0, "hooks": 0, "breakpoints": 0,
            "reloaded": 0,
        }

        # Auto-reload the binary if the original path is still accessible
        orig_path = data.get("original_binary_path", "")
        if orig_path and os.path.isfile(orig_path) and not self._module:
            try:
                arch = data.get("arch", self.arch)
                api_level = data.get("api_level", self.api_level)
                await self.load_library(orig_path, arch=arch, api_level=api_level)
                restored["reloaded"] = 1
                logger.info("Project: auto-reloaded binary from %s", orig_path)
            except Exception as e:
                logger.warning("Project: could not auto-reload binary: %s", e)

        for p in data.get("patches", []):
            try:
                addr = int(p["address"], 16) if isinstance(p["address"], str) else p["address"]
                patch_id = p.get("id", str(uuid.uuid4())[:8])
                info = PatchInfo(
                    id=patch_id,
                    address=addr,
                    original_bytes=p.get("original_bytes", ""),
                    patch_bytes=p.get("patch_bytes", ""),
                    label=p.get("label", ""),
                    enabled=p.get("enabled", True),
                )
                self._patches[patch_id] = info
                if info.enabled and info.patch_bytes and self._emulator:
                    raw = bytes.fromhex(info.patch_bytes)
                    loop = asyncio.get_event_loop()
                    try:
                        await loop.run_in_executor(
                            None, lambda r=raw, a=addr: self._emulator.mem_write(a, r)
                        )
                    except Exception:
                        logger.debug("Could not apply loaded patch", exc_info=True)
                restored["patches"] += 1
            except Exception:
                logger.debug("Skipping invalid patch entry", exc_info=True)

        for addr_str, text in data.get("comments", {}).items():
            try:
                addr = int(addr_str, 16) if addr_str.startswith("0x") else int(addr_str)
                self._comments[addr] = text
                restored["comments"] += 1
            except Exception:
                pass

        for h in data.get("hooks", []):
            try:
                addr = int(h["address"], 16) if isinstance(h["address"], str) else h["address"]
                hook_id = h.get("id", str(uuid.uuid4())[:8])
                hook = HookInfo(
                    id=hook_id,
                    address=addr,
                    name=h.get("name", "hook"),
                    script=h.get("script", ""),
                )
                self._hooks[hook_id] = hook
                restored["hooks"] += 1
            except Exception:
                logger.debug("Skipping invalid hook entry", exc_info=True)

        for b in data.get("breakpoints", []):
            try:
                addr = int(b["address"], 16) if isinstance(b["address"], str) else b["address"]
                bp_id = b.get("id", str(uuid.uuid4())[:8])
                bp = BreakpointInfo(
                    id=bp_id,
                    address=addr,
                    name=b.get("name", "bp"),
                )
                self._breakpoints[bp_id] = bp
                restored["breakpoints"] += 1
            except Exception:
                logger.debug("Skipping invalid breakpoint entry", exc_info=True)

        return {"restored": restored}

    # ── WebSocket broadcast ──────────────────────────────────────────────────

    def add_websocket(self, ws: Any) -> None:
        self.websockets.add(ws)

    def remove_websocket(self, ws: Any) -> None:
        self.websockets.discard(ws)

    async def _broadcast(self, message: dict[str, Any]) -> None:
        """Send a message to all connected WebSocket clients."""
        message["session_id"] = self.session_id
        text = json.dumps(message)
        dead = set()
        for ws in list(self.websockets):
            try:
                await ws.send_text(text)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                dead.add(ws)
        self.websockets -= dead

    # ── State snapshot ───────────────────────────────────────────────────────

    def get_state(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "status": self.status.value,
            "arch": self.arch,
            "api_level": self.api_level,
            "loaded_module": self._module.name if self._module else None,
            "module_base": hex(self._module.base_address) if self._module else None,
            "hooks_count": len(self._hooks),
            "breakpoints_count": len(self._breakpoints),
            "patches_count": len(self._patches),
            "comments_count": len(self._comments),
            "created_at": self.created_at,
            "last_active": self.last_active,
        }

    async def close(self) -> None:
        """Clean up session resources."""
        if self._terminal_task:
            self._terminal_task.cancel()
        if self._terminal_process:
            try:
                self._terminal_process.terminate()
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        if self._pty_master is not None:
            try:
                os.close(self._pty_master)
            except OSError:
                pass
        if self._library_path:
            try:
                os.unlink(self._library_path)
            except OSError:
                pass
        self._emulator = None
        self._module = None
        self._library_path = None
        self._original_library_path = None


class SessionManager:
    """Manages all active emulator sessions."""

    def __init__(self, max_sessions: int = 10):
        self._sessions: dict[str, EmulatorSession] = {}
        self._max_sessions = max_sessions

    def create_session(self) -> EmulatorSession:
        if len(self._sessions) >= self._max_sessions:
            self._evict_oldest()
        session_id = str(uuid.uuid4())
        session = EmulatorSession(session_id)
        self._sessions[session_id] = session
        handler = get_ws_log_handler()
        try:
            handler.set_loop(asyncio.get_event_loop())
        except RuntimeError:
            pass
        handler.add_session(session)
        logger.info("Created session %s (total: %d)", session_id, len(self._sessions))
        return session

    def get_session(self, session_id: str) -> EmulatorSession | None:
        return self._sessions.get(session_id)

    def delete_session(self, session_id: str) -> bool:
        session = self._sessions.pop(session_id, None)
        if session:
            handler = get_ws_log_handler()
            handler.remove_session(session)
            asyncio.ensure_future(session.close())
            return True
        return False

    def list_sessions(self) -> list[dict[str, Any]]:
        return [s.get_state() for s in self._sessions.values()]

    def _evict_oldest(self) -> None:
        if not self._sessions:
            return
        oldest_id = min(self._sessions, key=lambda k: self._sessions[k].last_active)
        self.delete_session(oldest_id)
        logger.info("Evicted session %s", oldest_id)
