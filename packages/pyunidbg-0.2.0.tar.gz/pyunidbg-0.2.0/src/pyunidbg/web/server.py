"""
PyUniDbg Web Server.

FastAPI application that exposes all PyUniDbg features via:
  - REST API  (/api/...)
  - WebSocket (/ws/{session_id})
  - Static SPA (/  → index.html)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import Any

logger = logging.getLogger("pyunidbg.web")

try:
    import uvicorn
    from fastapi import (
        FastAPI,
        File,
        Form,
        HTTPException,
        Request,
        UploadFile,
        WebSocket,
        WebSocketDisconnect,
    )
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import FileResponse, HTMLResponse, JSONResponse  # noqa: F401
    from fastapi.staticfiles import StaticFiles
    FASTAPI_AVAILABLE = True
except ImportError:
    FASTAPI_AVAILABLE = False

from pyunidbg.web.session import EmulatorSession, SessionManager, get_ws_log_handler

STATIC_DIR = Path(__file__).parent / "static"

_session_manager = SessionManager(max_sessions=20)

# ── Helpers ──────────────────────────────────────────────────────────────────


def _ok(data: Any = None, **kwargs) -> dict[str, Any]:
    return {"success": True, "data": data, **kwargs}


def _err(msg: str, code: int = 400) -> None:
    raise HTTPException(status_code=code, detail=msg)


def _require_session(session_id: str) -> EmulatorSession:
    s = _session_manager.get_session(session_id)
    if not s:
        _err(f"Session not found: {session_id}", 404)
    return s


# ── App factory ──────────────────────────────────────────────────────────────


def create_app() -> FastAPI:
    if not FASTAPI_AVAILABLE:
        raise ImportError(
            "Web interface requires: pip install pyunidbg[web]\n"
            "  or: pip install fastapi uvicorn[standard] python-multipart"
        )

    from pyunidbg import __version__ as _pyunidbg_version

    app = FastAPI(
        title="PyUniDbg Web Interface",
        description="Real-time Android native library emulator web UI",
        version=_pyunidbg_version,
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Sessions ─────────────────────────────────────────────────────────────

    @app.get("/api/sessions")
    async def list_sessions():
        return _ok(_session_manager.list_sessions())

    @app.post("/api/sessions")
    async def create_session():
        s = _session_manager.create_session()
        return _ok(s.get_state())

    @app.get("/api/sessions/{session_id}")
    async def get_session(session_id: str):
        s = _require_session(session_id)
        return _ok(s.get_state())

    @app.delete("/api/sessions/{session_id}")
    async def delete_session(session_id: str):
        ok = _session_manager.delete_session(session_id)
        if not ok:
            _err("Session not found", 404)
        return _ok({"deleted": session_id})

    # ── Binary upload & load ─────────────────────────────────────────────────

    @app.post("/api/sessions/{session_id}/load")
    async def load_library(
        session_id: str,
        file: UploadFile = File(...),
        arch: str = Form("arm64"),
        api_level: int = Form(29),
    ):
        s = _require_session(session_id)
        content = await file.read()
        # Preserve the original filename so the loaded module gets a meaningful
        # name (e.g. "libnative" instead of a random tempfile stem).
        original_name = os.path.basename(file.filename or "library.so")
        if not original_name or original_name in (".", ".."):
            original_name = "library.so"
        if not os.path.splitext(original_name)[1]:
            original_name += ".so"
        tmpdir = tempfile.mkdtemp(prefix="pyunidbg_upload_")
        tmp_path = os.path.join(tmpdir, original_name)
        with open(tmp_path, "wb") as f:
            f.write(content)
        try:
            result = await s.load_library(tmp_path, arch=arch, api_level=api_level)
            return _ok(result)
        finally:
            import shutil
            shutil.rmtree(tmpdir, ignore_errors=True)

    @app.post("/api/sessions/{session_id}/load-path")
    async def load_library_path(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        path = body.get("path", "")
        arch = body.get("arch", "arm64")
        api_level = body.get("api_level", 29)
        if not path:
            _err("path is required")
        result = await s.load_library(path, arch=arch, api_level=api_level)
        return _ok(result)

    @app.post("/api/sessions/{session_id}/unload")
    async def unload_library(session_id: str):
        s = _require_session(session_id)
        result = await s.unload_library()
        return _ok(result)

    # ── Execution control ────────────────────────────────────────────────────

    @app.post("/api/sessions/{session_id}/run")
    async def run_function(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        function = body.get("function", "JNI_OnLoad")
        args = body.get("args", [])
        result = await s.run_function(function, args)
        return _ok(result)

    @app.post("/api/sessions/{session_id}/stop")
    async def stop_session(session_id: str):
        s = _require_session(session_id)
        # Signal stop (best-effort for running emulator)
        if s._emulator:
            try:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, lambda: setattr(s, "status", "stopped"))
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        return _ok({"stopped": True})

    # ── Registers ────────────────────────────────────────────────────────────

    @app.get("/api/sessions/{session_id}/registers")
    async def get_registers(session_id: str):
        s = _require_session(session_id)
        regs = await s.get_registers()
        return _ok(regs)

    # ── Memory ───────────────────────────────────────────────────────────────

    @app.get("/api/sessions/{session_id}/memory")
    async def read_memory(session_id: str, address: str, size: int = 256):
        s = _require_session(session_id)
        try:
            addr = int(address, 16) if address.startswith("0x") else int(address)
        except ValueError:
            _err("Invalid address format")
        data = await s.read_memory(addr, min(size, 65536))
        return _ok({"address": hex(addr), "size": len(data), "data": data.hex()})

    @app.post("/api/sessions/{session_id}/memory")
    async def write_memory(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        addr_str = body.get("address", "0")
        hex_data = body.get("data", "")
        try:
            addr = int(addr_str, 16) if str(addr_str).startswith("0x") else int(addr_str)
            data = bytes.fromhex(hex_data)
        except ValueError as e:
            _err(f"Invalid data: {e}")
        ok = await s.write_memory(addr, data)
        return _ok({"written": ok, "bytes": len(data)})

    @app.get("/api/sessions/{session_id}/memory/map")
    async def get_memory_map(session_id: str):
        s = _require_session(session_id)
        mmap = await s.get_memory_map()
        return _ok(mmap)

    @app.post("/api/sessions/{session_id}/memory/search")
    async def search_memory(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        pattern = body.get("pattern", "")
        search_type = body.get("type", "hex")
        start_str = body.get("start", 0)
        end_str = body.get("end", 0)
        max_results = min(int(body.get("max_results", 256)), 1024)
        if not pattern:
            _err("pattern is required")
        try:
            start_addr = int(start_str, 16) if isinstance(start_str, str) and start_str.startswith("0x") else int(start_str or 0)
            end_addr = int(end_str, 16) if isinstance(end_str, str) and end_str.startswith("0x") else int(end_str or 0)
        except (ValueError, TypeError):
            start_addr, end_addr = 0, 0
        result = await s.search_memory(pattern, search_type, start_addr, end_addr, max_results)
        return _ok(result)

    @app.get("/api/sessions/{session_id}/strings")
    async def get_strings(session_id: str, min_length: int = 4, encoding: str = "all"):
        s = _require_session(session_id)
        result = await s.get_strings(min_length=min_length, encoding=encoding)
        if result.get("error"):
            _err(result["error"])
        return _ok(result)

    # ── Disassembly ──────────────────────────────────────────────────────────

    @app.get("/api/sessions/{session_id}/disasm")
    async def disassemble(session_id: str, address: str, count: int = 30):
        s = _require_session(session_id)
        try:
            addr = int(address, 16) if address.startswith("0x") else int(address)
        except ValueError:
            _err("Invalid address")
        insns = await s.disassemble(addr, min(count, 200))
        return _ok(insns)

    @app.get("/api/sessions/{session_id}/disasm-func")
    async def disassemble_function(session_id: str, name: str, count: int = 50):
        s = _require_session(session_id)
        if not s._module:
            _err("No library loaded")
        loop = asyncio.get_event_loop()

        def _get_addr():
            return s._module.get_function_address(name)

        addr = await loop.run_in_executor(None, _get_addr)
        if not addr:
            _err(f"Function not found: {name}", 404)
        insns = await s.disassemble(addr, count)
        return _ok({"function": name, "address": hex(addr), "instructions": insns})

    # ── Static disassembly (file-level, no emulator needed) ────────────

    @app.get("/api/sessions/{session_id}/symbols")
    async def get_symbols(session_id: str):
        s = _require_session(session_id)
        symbols = await s.get_symbols()
        return _ok(symbols)

    @app.get("/api/sessions/{session_id}/scan")
    async def scan_functions(session_id: str, filter: str = "",
                             jni_only: bool = False, limit: int = 0):
        """Scan library and infer function argument signatures."""
        s = _require_session(session_id)
        result = await s.scan_functions(filter_str=filter, jni_only=jni_only,
                                        limit=limit)
        return _ok(result)

    @app.get("/api/sessions/{session_id}/static-disasm")
    async def static_disassemble(session_id: str, target: str = "",
                                  section: str = "", address: str = "",
                                  count: int = 200):
        s = _require_session(session_id)
        addr = 0
        if address:
            try:
                addr = int(address, 16) if address.startswith("0x") else int(address)
            except ValueError:
                _err("Invalid address format")
        result = await s.static_disassemble(
            target=target, section=section,
            address=addr, count=min(count, 2000),
        )
        if result.get("error"):
            _err(result["error"])
        return _ok(result)

    # ── Hooks ────────────────────────────────────────────────────────────────

    @app.get("/api/sessions/{session_id}/hooks")
    async def get_hooks(session_id: str):
        s = _require_session(session_id)
        return _ok(await s.get_hooks())

    @app.post("/api/sessions/{session_id}/hooks")
    async def add_hook(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        addr_str = body.get("address", "0")
        name = body.get("name", "hook")
        script = body.get("script", "")
        try:
            addr = int(addr_str, 16) if str(addr_str).startswith("0x") else int(addr_str)
        except ValueError:
            _err("Invalid address")
        hook_id = await s.add_hook(addr, name, script)
        return _ok({"id": hook_id})

    @app.delete("/api/sessions/{session_id}/hooks/{hook_id}")
    async def remove_hook(session_id: str, hook_id: str):
        s = _require_session(session_id)
        ok = await s.remove_hook(hook_id)
        if not ok:
            _err("Hook not found", 404)
        return _ok({"removed": hook_id})

    # ── Breakpoints ──────────────────────────────────────────────────────────

    @app.get("/api/sessions/{session_id}/breakpoints")
    async def get_breakpoints(session_id: str):
        s = _require_session(session_id)
        return _ok(await s.get_breakpoints())

    @app.post("/api/sessions/{session_id}/breakpoints")
    async def add_breakpoint(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        addr_str = body.get("address", "0")
        name = body.get("name", "bp")
        try:
            addr = int(addr_str, 16) if str(addr_str).startswith("0x") else int(addr_str)
        except ValueError:
            _err("Invalid address")
        bp_id = await s.add_breakpoint(addr, name)
        return _ok({"id": bp_id})

    @app.delete("/api/sessions/{session_id}/breakpoints/{bp_id}")
    async def remove_breakpoint(session_id: str, bp_id: str):
        s = _require_session(session_id)
        ok = await s.remove_breakpoint(bp_id)
        if not ok:
            _err("Breakpoint not found", 404)
        return _ok({"removed": bp_id})

    # ── Patches ──────────────────────────────────────────────────────────────

    @app.get("/api/sessions/{session_id}/patches")
    async def get_patches(session_id: str):
        s = _require_session(session_id)
        return _ok(s.get_patches())

    @app.post("/api/sessions/{session_id}/patches")
    async def add_patch(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        addr_str = body.get("address", "0")
        bytes_hex = body.get("bytes_hex", "")
        label = body.get("label", "")
        if not bytes_hex:
            _err("bytes_hex is required")
        try:
            addr = int(addr_str, 16) if str(addr_str).startswith("0x") else int(addr_str)
        except ValueError:
            _err("Invalid address")
        patch = await s.add_patch(addr, bytes_hex, label)
        return _ok(patch)

    @app.delete("/api/sessions/{session_id}/patches/{patch_id}")
    async def remove_patch(session_id: str, patch_id: str):
        s = _require_session(session_id)
        ok = await s.remove_patch(patch_id)
        if not ok:
            _err("Patch not found", 404)
        return _ok({"removed": patch_id})

    @app.put("/api/sessions/{session_id}/patches/{patch_id}/toggle")
    async def toggle_patch(session_id: str, patch_id: str):
        s = _require_session(session_id)
        try:
            patch = await s.toggle_patch(patch_id)
        except KeyError:
            _err("Patch not found", 404)
        return _ok(patch)

    @app.post("/api/sessions/{session_id}/assemble")
    async def assemble_code(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        code = body.get("code", "")
        addr_str = body.get("address", "0")
        if not code.strip():
            _err("code is required")
        try:
            addr = int(addr_str, 16) if str(addr_str).startswith("0x") else int(addr_str)
        except ValueError:
            addr = 0
        loop = asyncio.get_event_loop()
        try:
            hex_bytes = await loop.run_in_executor(None, s.assemble, code, addr)
        except RuntimeError as e:
            _err(str(e))
        return _ok({"bytes_hex": hex_bytes, "length": len(hex_bytes) // 2})

    # ── Comments ─────────────────────────────────────────────────────────────

    @app.get("/api/sessions/{session_id}/comments")
    async def get_comments(session_id: str):
        s = _require_session(session_id)
        return _ok(s.get_comments())

    @app.post("/api/sessions/{session_id}/comments")
    async def add_comment(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        addr_str = body.get("address", "0")
        text = body.get("text", "")
        try:
            addr = int(addr_str, 16) if str(addr_str).startswith("0x") else int(addr_str)
        except ValueError:
            _err("Invalid address")
        s.add_comment(addr, text)
        return _ok({"address": hex(addr), "text": text})

    @app.delete("/api/sessions/{session_id}/comments/{address}")
    async def remove_comment(session_id: str, address: str):
        s = _require_session(session_id)
        try:
            addr = int(address, 16) if address.startswith("0x") else int(address)
        except ValueError:
            _err("Invalid address")
        ok = s.remove_comment(addr)
        if not ok:
            _err("Comment not found", 404)
        return _ok({"removed": address})

    # ── CFG & Call Graph ─────────────────────────────────────────────────────

    @app.get("/api/sessions/{session_id}/cfg")
    async def get_cfg(session_id: str, address: str, size: int = 500):
        s = _require_session(session_id)
        if not s._library_path:
            _err("No library loaded")
        try:
            addr = int(address, 16) if address.startswith("0x") else int(address)
        except ValueError:
            _err("Invalid address")
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, s.get_cfg, addr, min(size, 2000))
        if result.get("error"):
            _err(result["error"])
        return _ok(result)

    @app.get("/api/sessions/{session_id}/callgraph")
    async def get_callgraph(session_id: str):
        s = _require_session(session_id)
        if not s._library_path:
            _err("No library loaded")
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, s.get_callgraph)
        if result.get("error"):
            _err(result["error"])
        return _ok(result)

    # ── Project save / load ──────────────────────────────────────────────────

    @app.get("/api/sessions/{session_id}/project")
    async def save_project(session_id: str):
        s = _require_session(session_id)
        project_data = s.save_project()
        json_bytes = json.dumps(project_data, indent=2).encode()
        module_name = (s._module.name if s._module else "project").replace("/", "_")
        filename = f"{module_name}.pyunidbg.json"
        from fastapi.responses import Response
        return Response(
            content=json_bytes,
            media_type="application/json",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    @app.post("/api/sessions/{session_id}/project")
    async def load_project(session_id: str, file: UploadFile = File(...)):
        s = _require_session(session_id)
        content = await file.read()
        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            _err(f"Invalid JSON: {e}")
        result = await s.load_project(data)
        return _ok(result)

    # ── Scripting ────────────────────────────────────────────────────────────

    @app.post("/api/sessions/{session_id}/script")
    async def execute_script(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        code = body.get("code", "")
        script_type = body.get("type", "python")
        if not code.strip():
            _err("code is required")
        result = await s.execute_script(code, script_type)
        return _ok(result)

    # ── Analysis ─────────────────────────────────────────────────────────────

    @app.post("/api/sessions/{session_id}/analysis")
    async def run_analysis(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        analysis_type = body.get("type", "coverage")
        options = body.get("options", {})
        result = await s.run_analysis(analysis_type, options)
        return _ok(result)

    # ── Reports ──────────────────────────────────────────────────────────────

    @app.post("/api/sessions/{session_id}/report")
    async def generate_report(session_id: str, request: Request):
        s = _require_session(session_id)
        body = await request.json()
        fmt = body.get("format", "json")
        result = await s.generate_report(fmt)
        return _ok(result)

    # ── Library info (static analysis, no emulator needed) ───────────────────

    @app.post("/api/info")
    async def library_info(file: UploadFile = File(...)):
        content = await file.read()
        tmp = tempfile.NamedTemporaryFile(suffix=".so", delete=False)
        tmp.write(content)
        tmp.close()
        try:
            return _ok(_parse_library_info(tmp.name))
        finally:
            try:
                os.unlink(tmp.name)
            except OSError:
                pass

    @app.get("/api/info-path")
    async def library_info_path(path: str):
        if not os.path.exists(path):
            _err(f"File not found: {path}", 404)
        return _ok(_parse_library_info(path))

    # ── CLI execution ────────────────────────────────────────────────────────

    @app.post("/api/cli")
    async def run_cli(request: Request):
        body = await request.json()
        command = body.get("command", "")
        if not command.strip():
            _err("command is required")
        proc = await asyncio.create_subprocess_shell(
            f"{sys.executable} -m pyunidbg {command}",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)
        return _ok({
            "command": command,
            "stdout": stdout.decode(errors="replace"),
            "stderr": stderr.decode(errors="replace"),
            "exit_code": proc.returncode,
        })

    # ── Config ───────────────────────────────────────────────────────────────

    @app.get("/api/config")
    async def get_config():
        try:
            from pyunidbg.config import Config
            cfg = Config.load()
            return _ok(cfg.to_dict())
        except Exception as e:
            return _ok({}, error=str(e))

    @app.put("/api/config")
    async def update_config(request: Request):
        body = await request.json()
        try:
            from pyunidbg.config import Config
            cfg = Config.load()
            for key, value in body.items():
                cfg.set(key, value)
            cfg.save()
            return _ok(cfg.to_dict())
        except Exception as e:
            _err(str(e))

    # ── Scripting autocomplete ────────────────────────────────────────────────

    @app.get("/api/autocomplete")
    async def get_autocomplete():
        return _ok(_build_autocomplete_dict())

    # ── Version ──────────────────────────────────────────────────────────────

    @app.get("/api/version")
    async def get_version():
        info: dict[str, str] = {}
        try:
            import pyunidbg
            info["pyunidbg"] = getattr(pyunidbg, "__version__", "unknown")
        except ImportError:
            info["pyunidbg"] = "unknown"
        try:
            import unicorn
            info["unicorn"] = unicorn.__version__
        except ImportError:
            pass
        try:
            import capstone
            info["capstone"] = ".".join(map(str, capstone.cs_version()))
        except ImportError:
            pass
        try:
            import lief
            info["lief"] = lief.__version__
        except ImportError:
            pass
        info["python"] = sys.version.split()[0]
        return _ok(info)

    # ── WebSocket ────────────────────────────────────────────────────────────

    @app.websocket("/ws/{session_id}")
    async def websocket_endpoint(websocket: WebSocket, session_id: str):
        await websocket.accept()
        s = _session_manager.get_session(session_id)
        if not s:
            await websocket.send_text(json.dumps({"type": "error", "message": "Session not found"}))
            await websocket.close()
            return

        s.add_websocket(websocket)
        get_ws_log_handler().set_loop(asyncio.get_event_loop())
        await websocket.send_text(json.dumps({"type": "connected", "session_id": session_id,
                                               "state": s.get_state()}))
        logger.info("WS connected: %s", session_id)

        try:
            while True:
                raw = await websocket.receive_text()
                msg = json.loads(raw)
                await _handle_ws_message(s, websocket, msg)
        except WebSocketDisconnect:
            logger.info("WS disconnected: %s", session_id)
        except Exception as e:
            logger.warning("WS error (%s): %s", session_id, e)
        finally:
            s.remove_websocket(websocket)

    @app.websocket("/ws/terminal/{session_id}")
    async def terminal_websocket(websocket: WebSocket, session_id: str):
        """Dedicated WebSocket for the xterm.js terminal PTY."""
        await websocket.accept()
        s = _session_manager.get_session(session_id)
        if not s:
            await websocket.send_text(json.dumps({"type": "error", "message": "Session not found"}))
            await websocket.close()
            return

        await s.start_terminal(websocket)
        try:
            while True:
                raw = await websocket.receive_text()
                msg = json.loads(raw)
                if msg.get("type") == "terminal_input":
                    await s.write_terminal(msg.get("data", ""))
                elif msg.get("type") == "terminal_resize":
                    # Handle resize via ioctl if needed
                    pass
        except WebSocketDisconnect:
            pass
        except Exception as e:
            logger.debug("Terminal WS error: %s", e)

    # ── Static files ─────────────────────────────────────────────────────────

    @app.get("/", response_class=HTMLResponse)
    async def serve_spa():
        index = STATIC_DIR / "index.html"
        if index.exists():
            return HTMLResponse(index.read_text())
        return HTMLResponse("<h1>PyUniDbg Web UI</h1><p>Static files not found.</p>")

    if STATIC_DIR.exists():
        app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    return app


# ── WebSocket message handler ─────────────────────────────────────────────────

async def _handle_ws_message(session: EmulatorSession, ws: Any, msg: dict[str, Any]) -> None:
    msg_type = msg.get("type", "")

    try:
        if msg_type == "subscribe_logs":
            pass

        elif msg_type == "get_registers":
            regs = await session.get_registers()
            await ws.send_text(json.dumps({"type": "register_update", "registers": regs}))

        elif msg_type == "get_memory":
            addr = int(msg.get("address", "0"), 16)
            size = msg.get("size", 256)
            data = await session.read_memory(addr, size)
            await ws.send_text(json.dumps({
                "type": "memory_data",
                "address": hex(addr),
                "data": data.hex(),
            }))

        elif msg_type == "get_disasm":
            addr = int(msg.get("address", "0"), 16)
            count = msg.get("count", 30)
            insns = await session.disassemble(addr, count)
            await ws.send_text(json.dumps({"type": "disasm_data", "instructions": insns}))

        elif msg_type == "ping":
            await ws.send_text(json.dumps({"type": "pong"}))

        elif msg_type == "get_state":
            await ws.send_text(json.dumps({"type": "state_update", "state": session.get_state()}))

        elif msg_type == "run":
            func = msg.get("function", "JNI_OnLoad")
            args = msg.get("args", [])
            asyncio.ensure_future(session.run_function(func, args))

        elif msg_type == "execute_script":
            code = msg.get("code", "")
            stype = msg.get("script_type", "python")
            result = await session.execute_script(code, stype)
            await ws.send_text(json.dumps({"type": "script_result", "result": result}))

        elif msg_type == "run_analysis":
            atype = msg.get("analysis_type", "coverage")
            opts = msg.get("options", {})
            result = await session.run_analysis(atype, opts)
            await ws.send_text(json.dumps({"type": "analysis_result", "result": result}))

        elif msg_type == "get_hooks":
            hooks = await session.get_hooks()
            await ws.send_text(json.dumps({"type": "hooks_list", "hooks": hooks}))

        elif msg_type == "get_breakpoints":
            bps = await session.get_breakpoints()
            await ws.send_text(json.dumps({"type": "breakpoints_list", "breakpoints": bps}))

    except Exception as e:
        await ws.send_text(json.dumps({"type": "error", "message": str(e)}))


# ── Static analysis helper ────────────────────────────────────────────────────

def _parse_library_info(path: str) -> dict[str, Any]:
    info: dict[str, Any] = {"path": path, "name": os.path.basename(path)}
    try:
        import lief
        elf = lief.parse(path)
        if elf is None:
            return {**info, "error": "Failed to parse ELF"}

        info.update({
            "type": elf.header.file_type.name,
            "machine": elf.header.machine_type.name,
            "entry_point": hex(elf.header.entrypoint),
            "sections": [{"name": s.name, "size": s.size, "va": hex(s.virtual_address)}
                         for s in elf.sections],
            "exports": [{"name": sym.name, "address": hex(sym.value), "size": sym.size}
                        for sym in elf.exported_symbols],
            "imports": [{"name": sym.name} for sym in elf.imported_symbols],
            "libraries": list(elf.libraries),
        })
    except ImportError:
        info["error"] = "lief not available"
    except Exception as e:
        info["error"] = str(e)
    return info


# ── Autocomplete dictionary ────────────────────────────────────────────────────

def _build_autocomplete_dict() -> dict[str, Any]:
    return {
        "python": {
            "globals": ["emu", "module", "print"],
            "emu": [
                "call(address, args=[])", "run(start, end=0)", "step(count=1)", "stop()",
                "mem_read(address, size)", "mem_write(address, data)",
                "read_string(address)", "write_string(address, string)", "alloc_string(string)",
                "disassemble(address, size=64)", "disassemble_at(address, count=10)",
                "save_state()", "restore_state(state)", "hexdump(address, size=64)",
                "add_symbol(name, address)", "get_symbol(name)",
                "hook_add_code(address, callback)", "get_cpu_context()",
                "mem_regions()", "arch", "is_64bit", "pointer_size",
                "memory", "cpu", "hook",
            ],
            "module": [
                "name", "base_address", "size", "exports",
                "get_function_address(name)",
            ],
            "imports": {
                "pyunidbg.scripting": [
                    "ScriptEngine", "Script", "Interceptor", "Memory", "Module",
                    "Process", "NativePointer", "NativeFunction", "NativeCallback",
                    "ApiResolver", "Instruction", "Stalker", "Java",
                    "InvocationContext", "InvocationArgs", "InvocationRetval",
                ],
                "pyunidbg.android": ["AndroidEmulator"],
                "pyunidbg": ["Emulator", "AndroidEmulator"],
            },
            "classes": {
                "Interceptor": [
                    "attach(target, on_enter=None, on_leave=None)",
                    "detachAll()", "replace(target, replacement)", "revert(target)", "flush()",
                ],
                "Memory": [
                    "alloc(size)", "allocUtf8String(string)", "allocUtf16String(string)",
                    "free(address)", "copy(dst, src, n)", "protect(address, size, protection)",
                    "readPointer(address)", "readU8(address)", "readU16(address)",
                    "readU32(address)", "readU64(address)", "readS32(address)",
                    "readFloat(address)", "readDouble(address)",
                    "readByteArray(address, length)", "readUtf8String(address)",
                    "readCString(address)", "readUtf16String(address)",
                    "writePointer(address, value)", "writeU8(address, value)",
                    "writeU32(address, value)", "writeU64(address, value)",
                    "writeByteArray(address, bytes)", "writeUtf8String(address, string)",
                    "scan(address, size, pattern, callbacks)", "scanSync(address, size, pattern)",
                ],
                "NativePointer": [
                    "isNull()", "toInt32()", "toUInt32()", "toString(radix=16)",
                    "add(offset)", "sub(offset)", "and_(mask)", "or_(mask)",
                    "readPointer()", "readU8()", "readU32()", "readU64()",
                    "readUtf8String()", "readByteArray(length)",
                    "writePointer(value)", "writeU8(value)", "writeU32(value)",
                    "writeUtf8String(string)", "writeByteArray(bytes)",
                ],
                "NativeFunction": [
                    "__init__(address, return_type, arg_types, abi='default')",
                    "call(*args)", "apply(args, this=None)",
                ],
                "Module": [
                    "load(path)", "findBaseAddress(name)", "findExportByName(module, name)",
                    "enumerateModules()", "enumerateExports(name)", "enumerateImports(name)",
                    "findModuleByName(name)", "findModuleByAddress(address)",
                ],
                "Process": [
                    "get_id()", "get_arch()", "get_platform()", "get_pointerSize()",
                    "getCurrentThreadId()", "enumerateThreads()", "enumerateModules()",
                    "enumerateRanges(protection)", "findModuleByName(name)",
                ],
                "Java": [
                    "get_available", "perform(fn)", "performNow(fn)",
                    "use(class_name)", "choose(class_name)",
                    "enumerateLoadedClassesSync()", "enumerateClassLoadersSync()",
                    "registerClass(spec)", "cast(obj, klass)",
                    "scheduleOnMainThread(fn)", "isMainThread()",
                ],
                "Stalker": [
                    "follow(thread_id=None, options=None)", "unfollow(thread_id=None)",
                    "exclude(range)", "flush()", "garbageCollect()",
                    "addCallProbe(address, callback)", "removeCallProbe(probe_id)",
                ],
                "Instruction": [
                    "parse(address)", "parseN(address, count)",
                ],
                "ApiResolver": [
                    "__init__(type='module')", "enumerateMatches(query)",
                ],
            },
        },
        "frida": {
            "globals": [
                "Interceptor", "Memory", "Module", "Process", "NativePointer",
                "NativeFunction", "NativeCallback", "ptr", "NULL", "console",
                "send", "recv", "Java", "Stalker", "Instruction", "ApiResolver",
            ],
            "Interceptor": [
                "attach(target, { onEnter(args) {}, onLeave(retval) {} })",
                "detachAll()", "replace(target, replacement)", "revert(target)",
            ],
            "Memory": [
                "alloc(size)", "allocUtf8String(str)", "copy(dst, src, n)",
                "readPointer(addr)", "readU8(addr)", "readU32(addr)", "readU64(addr)",
                "readByteArray(addr, len)", "readUtf8String(addr)", "readCString(addr)",
                "writeU32(addr, val)", "writeByteArray(addr, bytes)",
                "scan(addr, size, pattern, { onMatch(addr, size) {}, onComplete() {} })",
                "scanSync(addr, size, pattern)",
            ],
            "console": ["log(...args)", "warn(...args)", "error(...args)"],
            "Java": [
                "available", "perform(fn)", "use(className)",
                "choose(className, { onMatch(instance) {}, onComplete() {} })",
                "enumerateLoadedClassesSync()",
            ],
        },
    }


# ── Runner ───────────────────────────────────────────────────────────────────

def run_server(host: str = "0.0.0.0", port: int = 8080,
               reload: bool = False, log_level: str = "info") -> None:
    """Start the PyUniDbg web server."""
    if not FASTAPI_AVAILABLE:
        print(
            "Error: Web interface dependencies not installed.\n"
            "Install with: pip install pyunidbg[web]\n"
            "  or: pip install fastapi uvicorn[standard] python-multipart",
            file=sys.stderr,
        )
        sys.exit(1)

    app = create_app()
    print("\n  PyUniDbg Web Interface")
    print("  ─────────────────────────────────────")
    print(f"  Local:   http://localhost:{port}")
    print(f"  Network: http://{host}:{port}")
    print(f"  Docs:    http://localhost:{port}/docs")
    print("  ─────────────────────────────────────\n")

    uvicorn.run(app, host=host, port=port, reload=reload, log_level=log_level)
