// ── Globals ──────────────────────────────────────────────────────────────
const API = '';  // same origin
let sessionId = null;
let ws = null;
let termWs = null;
let term = null;
let fitAddon = null;
let scriptEditor = null;
let cliHistory = [];
let cliHistIdx = -1;
let currentTab = 'terminal';
let reportData = null;
let logEntries = [];
let autocompleteData = null;
let binSymbols = null;

// ── Utilities ────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const api = async (method, path, body, isForm=false) => {
  const opts = { method, headers: {} };
  if (body) {
    if (isForm) { opts.body = body; }
    else { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
  }
  const r = await fetch(API + path, opts);
  if (!r.ok) {
    const err = await r.json().catch(() => ({detail:'Network error'}));
    throw new Error(err.detail || 'Request failed');
  }
  return r.json();
};
const get  = (p)    => api('GET', p);
const post = (p, b) => api('POST', p, b);
const put  = (p, b) => api('PUT', p, b);
const del  = (p)    => api('DELETE', p);

function toast(msg, type='info', dur=4000) {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${msg}</span>`;
  $('toast-container').appendChild(el);
  setTimeout(() => el.remove(), dur);
}

function log(msg, type='info') {
  const al = $('activity-log');
  const line = document.createElement('div');
  line.className = `log-line ${type}`;
  line.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
  al.appendChild(line);
  al.scrollTop = al.scrollHeight;
}

// ── Session management ────────────────────────────────────────────────────
async function createSession() {
  try {
    const r = await post('/api/sessions');
    sessionId = r.data.session_id;
    await refreshSessionList();
    connectWS();
    log(`Created session: ${sessionId}`, 'ok');
    toast('New session created', 'info');
  } catch(e) { toast(e.message, 'error'); }
}

async function refreshSessionList() {
  const r = await get('/api/sessions');
  const sel = $('session-selector');
  sel.innerHTML = r.data.map(s =>
    `<option value="${s.session_id}" ${s.session_id===sessionId?'selected':''}>${s.session_id.slice(0,8)} (${s.status})</option>`
  ).join('') || '<option value="">No sessions</option>';
  $('dash-sessions').textContent = r.data.length;
}

async function switchSession() {
  const newId = $('session-selector').value;
  if (newId && newId !== sessionId) {
    switchSessionGuarded(newId);
  }
}

async function doSwitchSession(newId) {
  sessionId = newId;
  markClean();
  aiMessages = [];
  if (sessionId) {
    connectWS();
    await refreshDashboard();
  }
}

$('session-selector').addEventListener('change', switchSession);

// ── WebSocket ────────────────────────────────────────────────────────────
function connectWS() {
  if (ws) { ws.close(); }
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${proto}://${location.host}/ws/${sessionId}`);

  ws.onopen = () => {
    setConnStatus(true);
    log('WebSocket connected', 'ok');
    connectTerminalWS();
  };
  ws.onclose = () => {
    setConnStatus(false);
    log('WebSocket disconnected', 'warn');
    setTimeout(() => { if (sessionId) connectWS(); }, 3000);
  };
  ws.onmessage = e => handleWS(JSON.parse(e.data));
  ws.onerror = () => setConnStatus(false);
}

function handleWS(msg) {
  switch (msg.type) {
    case 'connected':
      updateDashState(msg.state); break;
    case 'status_update':
      updateStatus(msg.status, msg.module); break;
    case 'register_update':
      renderRegisters(msg.registers); break;
    case 'hook_hit':
      onHookHit(msg); break;
    case 'breakpoint_hit':
      onBreakpointHit(msg); break;
    case 'execution_complete':
      log(`Execution complete: ${JSON.stringify(msg.result)}`, 'ok');
      toast('Execution complete', 'info'); break;
    case 'log_entry':
      addLogEntry(msg); break;
    case 'library_unloaded':
      log('Library unloaded', 'ok');
      $('binary-info').style.display = 'none';
      $('binary-info-content').innerHTML = '';
      $('btn-unload').style.display = 'none';
      break;
    case 'error':
      log(`Error: ${msg.message}`, 'error');
      toast(msg.message, 'error'); break;
    case 'hook_added': case 'hook_removed':
    case 'breakpoint_added': case 'breakpoint_removed':
      refreshHooks(); refreshBreakpoints(); break;
  }
}

function connectTerminalWS() {
  if (termWs) { termWs.close(); }
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  termWs = new WebSocket(`${proto}://${location.host}/ws/terminal/${sessionId}`);
  termWs.onmessage = e => {
    const msg = JSON.parse(e.data);
    if (msg.type === 'terminal_output' && term) {
      term.write(msg.data);
    }
  };
  termWs.onerror = () => {};
}

function setConnStatus(ok) {
  $('conn-dot').className = ok ? 'connected' : '';
  $('conn-label').textContent = ok ? 'Connected' : 'Disconnected';
}

function wsSend(msg) {
  if (ws && ws.readyState === 1) ws.send(JSON.stringify(msg));
}

// ── Terminal ──────────────────────────────────────────────────────────────
function initTerminal() {
  term = new Terminal({
    theme: {
      background: '#1e1e1e', foreground: '#d4d4d4',
      cursor: '#007acc', selectionBackground: 'rgba(0,122,204,0.3)',
      black: '#1e1e1e', red: '#f14c4c', green: '#4ec9b0',
      yellow: '#dcdcaa', blue: '#569cd6', magenta: '#c586c0',
      cyan: '#4fc1ff', white: '#d4d4d4',
    },
    fontFamily: "'Courier New', monospace",
    fontSize: 13,
    lineHeight: 1.5,
    cursorBlink: true,
    scrollback: 5000,
  });
  fitAddon = new FitAddon.FitAddon();
  term.loadAddon(fitAddon);
  term.loadAddon(new WebLinksAddon.WebLinksAddon());
  term.open($('terminal-container'));
  fitAddon.fit();

  term.onData(data => {
    if (termWs && termWs.readyState === 1) {
      termWs.send(JSON.stringify({type: 'terminal_input', data}));
    }
  });

  window.addEventListener('resize', () => fitAddon && fitAddon.fit());
  term.writeln('\x1b[36m╔═══════════════════════════════════════╗\x1b[0m');
  term.writeln('\x1b[36m║   PyUniDbg Web Terminal               ║\x1b[0m');
  term.writeln('\x1b[36m╚═══════════════════════════════════════╝\x1b[0m');
  term.writeln('\x1b[33mCreate or select a session to connect.\x1b[0m\r\n');
}

// Hide/show the bottom footer (Terminal / Logs / CLI runner). We keep the
// state in localStorage so the user's choice survives page reloads.
function toggleTerminalPanel(force) {
  const wrap = $('content-wrap');
  if (!wrap) return;
  const willCollapse = (typeof force === 'boolean')
    ? force
    : !wrap.classList.contains('terminal-collapsed');
  wrap.classList.toggle('terminal-collapsed', willCollapse);
  try { localStorage.setItem('pyunidbg_term_collapsed', willCollapse ? '1' : '0'); } catch(e) {}
  // xterm needs a size recalc when its container reappears, otherwise the
  // grid stays at the dimensions it had while hidden.
  if (!willCollapse && typeof fitAddon !== 'undefined' && fitAddon) {
    setTimeout(() => { try { fitAddon.fit(); } catch(e) {} }, 80);
  }
}

function restoreTerminalCollapsed() {
  let collapsed = false;
  try { collapsed = localStorage.getItem('pyunidbg_term_collapsed') === '1'; } catch(e) {}
  if (collapsed) toggleTerminalPanel(true);
}

function switchTermTab(tab, el) {
  currentTab = tab;
  document.querySelectorAll('.term-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  const tc = $('terminal-container');
  const cp = $('cli-panel');
  const lp = $('log-panel');
  tc.style.display = 'none'; cp.style.display = 'none';
  lp.classList.remove('active');
  if (tab === 'xterm') {
    tc.style.display = '';
    fitAddon && fitAddon.fit();
  } else if (tab === 'logs') {
    lp.classList.add('active');
  } else {
    cp.style.display = 'flex';
    $('cli-input').focus();
  }
}

// ── Resize handle ────────────────────────────────────────────────────────
(function initResize() {
  const handle = $('resize-handle');
  const panel = $('terminal-panel');
  let dragging = false, startY = 0, startH = 0;
  handle.addEventListener('mousedown', e => {
    dragging = true; startY = e.clientY;
    startH = panel.offsetHeight;
    document.body.style.userSelect = 'none';
  });
  window.addEventListener('mousemove', e => {
    if (!dragging) return;
    const dy = startY - e.clientY;
    const h = Math.max(80, Math.min(600, startH + dy));
    panel.style.height = h + 'px';
    fitAddon && fitAddon.fit();
  });
  window.addEventListener('mouseup', () => {
    dragging = false;
    document.body.style.userSelect = '';
  });
})();

// ── Panel switching ──────────────────────────────────────────────────────
let currentPanel = 'dashboard';

function switchPanel(name, el) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  const panel = $(`panel-${name}`);
  if (panel) panel.classList.add('active');
  if (el) {
    el.classList.add('active');
  } else {
    // Caller didn't pass the nav element — light up the right one ourselves
    const navEl = document.querySelector(`.nav-btn[data-panel="${name}"]`);
    if (navEl) navEl.classList.add('active');
  }
  currentPanel = name;
  // Defer to allow layout to settle before measuring (matters for CodeMirror etc.)
  try { onPanelShown(name); } catch(e) { console.error('onPanelShown', name, e); }
}

// Hook called every time a panel becomes visible so each section can
// refresh state, auto-fill helpful defaults and trigger initial loads
// (so the user lands on a usable view without an extra click).
function onPanelShown(name) {
  // Always reconcile the visible sub-tab with the sub-tab marked .active —
  // sub-contents have inline styles in this codebase and a stale
  // display value (or a previously hidden tab) could otherwise leave the
  // panel looking empty until the user clicks a tab.
  ensureDefaultSubTabVisible(`panel-${name}`);
  switch (name) {
    case 'memory':
      // Make sure the hex view has a sensible address and the quick-jump
      // dropdown is populated with module / heap / stack starts.
      ensureBinSymbols();
      populateMemoryQuickAddrs();
      autoFillMemoryAddr();
      break;
    case 'disasm':
      // Land on the Binary (static) tab — most users open this section to
      // browse the binary, not the live runtime.
      ensureBinSymbols();
      loadBinaryDisasm();
      break;
    case 'graph':
      // Pre-fill the CFG address with the first interesting export so
      // "Build" works immediately without hunting for an address.
      ensureBinSymbols();
      autoFillGraphAddr();
      break;
    case 'patches':
      refreshPatches();
      refreshComments();
      break;
    case 'hooks':
      refreshHooks();
      break;
    case 'breakpoints':
      refreshBreakpoints();
      break;
    case 'registers':
      // Auto-fetch the live CPU state — the user shouldn't have to hit
      // Refresh just to see the register grid after running JNI_OnLoad.
      fetchRegisters();
      break;
    case 'analysis':
      // Surface the list of known functions in every analysis sub-tab so the
      // user can pick from a dropdown instead of typing names blindly.
      ensureBinSymbols().then(populateAnalysisFunctionLists);
      break;
    case 'scripting':
      // CodeMirror is initialised inside a hidden panel — without a refresh
      // here line-number gutters and content can render misaligned.
      if (typeof scriptEditor !== 'undefined' && scriptEditor) {
        setTimeout(() => { try { scriptEditor.refresh(); scriptEditor.focus(); } catch(e){} }, 50);
      }
      break;
  }
}

// Walk the freshly-shown panel and make absolutely sure the active sub-tab
// has a visible sub-content. Catches the edge case where sub-content elements
// were given inline `style="display:..."` overrides or where the matching
// sub-content was somehow left with `.active` removed.
function ensureDefaultSubTabVisible(panelId) {
  const panel = $(panelId);
  if (!panel) return;
  const tabBars = panel.querySelectorAll('.sub-tabs');
  if (!tabBars.length) return;
  tabBars.forEach(bar => {
    const active = bar.querySelector('.sub-tab.active') || bar.querySelector('.sub-tab');
    if (!active) return;
    if (!active.classList.contains('active')) active.classList.add('active');
    // Pull the (prefix, key) pair out of the onclick handler so we can find
    // the corresponding content element regardless of where it lives in the
    // DOM (some panels nest the sub-content in a sibling wrapper).
    const oc = active.getAttribute('onclick') || '';
    const m = oc.match(/switchSubTab\(\s*['"]([^'"]+)['"]\s*,\s*['"]([^'"]+)['"]/);
    if (!m) return;
    const [, prefix, key] = m;
    const target = $(`${prefix}-${key}`);
    if (!target) return;
    // Reset every sibling sub-content first
    const container = target.parentElement;
    if (container) {
      container.querySelectorAll('.sub-content').forEach(c => {
        if (c !== target) {
          c.classList.remove('active');
          // Wipe any leftover inline display so the .active rule wins next time
          if (c.style && c.style.display && c.style.display !== 'none') c.style.display = '';
        }
      });
    }
    target.classList.add('active');
    // If the target sub-content uses flex layout, force flex (the .sub-content.flex-col.active
    // rule gives us this for free, but inline styles can override it — set it explicitly).
    if (target.classList.contains('flex-col')) {
      target.style.display = 'flex';
    }
  });
}

function switchSubTab(prefix, tab, el) {
  const parent = el.closest('.panel, .sub-content')?.parentElement || el.parentElement.parentElement;
  parent.querySelectorAll('.sub-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  parent.querySelectorAll('.sub-content').forEach(c => c.classList.remove('active'));
  const content = $(`${prefix}-${tab}`);
  if (content) content.classList.add('active');
  // Refresh CodeMirror when the script editor sub-tab becomes visible
  if (prefix === 'script' && tab === 'editor' && typeof scriptEditor !== 'undefined' && scriptEditor) {
    setTimeout(() => { try { scriptEditor.refresh(); } catch(e){} }, 50);
  }
}

// Programmatically activate a sub-tab inside the currently visible panel.
// Used by integration code (e.g. "open Binary disasm at this address").
function activateSubTab(prefix, tab) {
  const content = $(`${prefix}-${tab}`);
  if (!content) return;
  const tabs = content.parentElement.querySelectorAll('.sub-tab');
  // Match the sub-tab whose onclick references the same key, e.g.
  // switchSubTab('disasm','binary',...).
  tabs.forEach(t => {
    const oc = t.getAttribute('onclick') || '';
    const isMatch = oc.includes(`'${prefix}','${tab}'`) || oc.includes(`"${prefix}","${tab}"`);
    if (isMatch) {
      t.classList.add('active');
    } else {
      t.classList.remove('active');
    }
  });
  content.parentElement.querySelectorAll('.sub-content').forEach(c => c.classList.remove('active'));
  content.classList.add('active');
}

// ── Dashboard ────────────────────────────────────────────────────────────
async function refreshDashboard() {
  try {
    if (!sessionId) return;
    const r = await get(`/api/sessions/${sessionId}`);
    updateDashState(r.data);
    await refreshSessionList();
  } catch(e) { log(e.message, 'error'); }
}

function updateDashState(s) {
  if (!s) return;
  $('dash-status').textContent = (s.status||'idle').toUpperCase();
  $('dash-arch').textContent = s.arch || '—';
  $('dash-module').textContent = s.loaded_module || 'None';
  $('dash-module-base').textContent = s.module_base || '—';
  $('dash-hooks').textContent = s.hooks_count || 0;
  $('dash-bps').textContent = s.breakpoints_count || 0;
  $('emu-status').textContent = s.loaded_module
    ? `${s.loaded_module} @ ${s.module_base}`
    : 'No library loaded';
  $('right-module').textContent = s.loaded_module
    ? `${s.loaded_module}\n@ ${s.module_base}` : '—';
}

function updateStatus(status) {
  $('dash-status').textContent = (status||'idle').toUpperCase();
  $('emu-status').textContent = `Status: ${status}`;
}

async function quickRun() {
  if (!sessionId) { toast('Create a session first', 'error'); return; }
  const btn = document.querySelector('button[onclick="quickRun()"]');
  if (btn && btn.disabled) return;
  try {
    const r = await post(`/api/sessions/${sessionId}/run`, {function: 'JNI_OnLoad', args: []});
    log(`JNI_OnLoad result: ${JSON.stringify(r.data)}`, 'ok');
    toast('Execution complete', 'info');
  } catch(e) { toast(e.message, 'error'); log(e.message, 'error'); }
}

// ── Binary loading ────────────────────────────────────────────────────────
// Triggered when the user picks a file in the upload widget. We peek at
// the first 20 bytes to identify the ELF header and pre-select the right
// arch in the dropdown so the user doesn't have to know what their .so
// was compiled for. Falls back silently for non-ELF files.
async function onLibraryFileSelected(ev) {
  const f = ev.target.files && ev.target.files[0];
  const badge = $('arch-detect-badge');
  if (badge) badge.style.display = 'none';
  if (!f) return;
  try {
    const head = await f.slice(0, 20).arrayBuffer();
    const view = new Uint8Array(head);
    // ELF magic: 0x7F 'E' 'L' 'F'
    if (view[0] !== 0x7F || view[1] !== 0x45 || view[2] !== 0x4C || view[3] !== 0x46) {
      log(`File ${f.name} is not an ELF (no auto-detect).`, 'warn');
      return;
    }
    const ei_class = view[4]; // 1 = ELF32, 2 = ELF64
    const ei_data  = view[5]; // 1 = little-endian, 2 = big-endian
    // e_machine lives at offset 0x12, 2 bytes wide
    const lo = view[0x12], hi = view[0x13];
    const e_machine = (ei_data === 2) ? ((lo << 8) | hi) : ((hi << 8) | lo);
    let detected = null;
    switch (e_machine) {
      case 0x28: detected = 'arm';    break; // EM_ARM
      case 0xB7: detected = 'arm64';  break; // EM_AARCH64
      case 0x03: detected = 'x86';    break; // EM_386
      case 0x3E: detected = 'x86_64'; break; // EM_X86_64
      case 0x08: detected = ei_class === 2 ? 'mips64' : 'mips';   break; // EM_MIPS (informational)
      case 0xF3: detected = ei_class === 2 ? 'riscv64' : 'riscv'; break; // EM_RISCV (informational)
    }
    if (!detected) {
      log(`File ${f.name}: ELF detected, but unknown e_machine=0x${e_machine.toString(16)}.`, 'warn');
      return;
    }
    const sel = $('load-arch');
    if (!sel) return;
    // Only switch the selector if the detected arch is actually one of the
    // supported options — we don't silently swap to e.g. 'mips64' when the
    // backend can't run it.
    const supported = Array.from(sel.options).map(o => o.value);
    if (supported.includes(detected)) {
      sel.value = detected;
      if (badge) {
        badge.textContent = `auto: ${detected}`;
        badge.style.display = 'inline-block';
      }
      log(`Detected ${detected} from ELF header (e_machine=0x${e_machine.toString(16)}, class=ELF${ei_class === 2 ? '64' : '32'}).`, 'ok');
    } else {
      log(`Detected '${detected}' but the loader doesn't support it — leaving arch selector unchanged.`, 'warn');
    }
  } catch (e) {
    log(`Arch auto-detect failed: ${e.message}`, 'warn');
  }
}

async function loadBinary() {
  if (!sessionId) { toast('Create a session first', 'error'); return; }
  const fileInput = $('file-input');
  if (!fileInput.files.length) { toast('Select a file first', 'error'); return; }

  const form = new FormData();
  form.append('file', fileInput.files[0]);
  form.append('arch', $('load-arch').value);
  form.append('api_level', $('load-api').value);

  $('btn-load').disabled = true;
  log(`Loading ${fileInput.files[0].name}...`);
  toast('Loading library...', 'info');

  try {
    const r = await api('POST', `/api/sessions/${sessionId}/load`, form, true);
    log(`Loaded: ${r.data.name} at ${r.data.base_address}`, 'ok');
    toast(`Loaded ${r.data.name}`, 'info');
    renderBinaryInfo(r.data);
    populateRunFuncDropdown();
    await refreshDashboard();
    await postLoadRefresh();
  } catch(e) {
    log(e.message, 'error'); toast(e.message, 'error');
  } finally {
    $('btn-load').disabled = false;
  }
}

function loadByPath() { openModal('modal-load-path'); }

async function loadFromPath() {
  const path = $('load-path-input').value.trim();
  if (!path) return;
  if (!sessionId) { toast('Create a session first', 'error'); return; }
  closeModal('modal-load-path');
  try {
    const r = await post(`/api/sessions/${sessionId}/load-path`, {
      path, arch: $('load-arch').value, api_level: parseInt($('load-api').value)
    });
    log(`Loaded: ${r.data.name}`, 'ok');
    toast(`Loaded ${r.data.name}`, 'info');
    renderBinaryInfo(r.data);
    populateRunFuncDropdown();
    await refreshDashboard();
    await postLoadRefresh();
  } catch(e) { toast(e.message, 'error'); }
}

// Hook for "library just got loaded" — pre-populates every cross-section
// helper so panels are usable immediately, before the user even clicks.
async function postLoadRefresh() {
  await ensureBinSymbols();
  populateAnalysisFunctionLists();
  // If the user is currently on a panel that depends on binSymbols,
  // re-trigger its onShown so the new data is reflected right away.
  if (currentPanel) {
    try { onPanelShown(currentPanel); } catch(e) {}
  }
}

function renderBinaryInfo(data) {
  binSymbols = null;
  const info = $('binary-info');
  info.style.display = 'block';
  $('btn-unload').style.display = '';
  const hasJni = data.has_jni_onload !== false;
  // Update the Run JNI_OnLoad quick-action button state
  const qrBtn = document.querySelector('button[onclick="quickRun()"]');
  if (qrBtn) {
    qrBtn.disabled = !hasJni;
    qrBtn.title = hasJni ? 'Run JNI_OnLoad' : 'This library has no JNI_OnLoad export';
    qrBtn.style.opacity = hasJni ? '' : '0.45';
  }
  $('binary-info-content').innerHTML = `
    <div class="result-box">
      <div class="stat-row"><span class="stat-label">Name</span><span class="stat-val">${data.name||'—'}</span></div>
      <div class="stat-row"><span class="stat-label">Base</span><span class="stat-val">${data.base_address||'—'}</span></div>
      <div class="stat-row"><span class="stat-label">Size</span><span class="stat-val">${data.size||'—'}</span></div>
      <div class="stat-row"><span class="stat-label">Exports</span><span class="stat-val">${(data.exports||[]).length}</span></div>
      <div class="stat-row"><span class="stat-label">JNI_OnLoad</span><span class="stat-val" style="color:${hasJni?'var(--green)':'var(--red)'}">
        ${hasJni ? '✓ Present' : '✗ Not found'}
      </span></div>
    </div>
    ${data.exports && data.exports.length ? `
    <div class="section-label" style="margin-top:12px">Exports (${data.exports.length})</div>
    <div style="max-height:200px;overflow:auto">
    <table class="data-table">
      <thead><tr><th>Name</th><th>Address</th><th></th></tr></thead>
      <tbody>${(data.exports||[]).map(e=>`<tr>
        <td class="name">${escHtml(e.name)}</td>
        <td class="addr">${e.address}</td>
        <td><button class="btn btn-ghost" style="padding:2px 6px;font-size:10px" onclick="runExport('${escAttr(e.name)}')">Run</button></td>
      </tr>`).join('')}</tbody>
    </table></div>` : ''}
  `;
}

async function unloadBinary() {
  if (!sessionId) { toast('No active session', 'error'); return; }
  $('btn-unload').disabled = true;
  try {
    await post(`/api/sessions/${sessionId}/unload`, {});
    log('Library unloaded', 'ok');
    toast('Library unloaded', 'info');
    $('binary-info').style.display = 'none';
    $('binary-info-content').innerHTML = '';
    $('btn-unload').style.display = 'none';
    $('file-input').value = '';
    // Re-enable the JNI run button
    const qrBtn = document.querySelector('button[onclick="quickRun()"]');
    if (qrBtn) { qrBtn.disabled = false; qrBtn.style.opacity = ''; qrBtn.title = ''; }
    await refreshDashboard();
  } catch(e) {
    log(e.message, 'error'); toast(e.message, 'error');
  } finally {
    $('btn-unload').disabled = false;
  }
}

async function runExport(name) {
  if (!sessionId) { toast('No active session', 'error'); return; }
  try {
    log(`Running ${name}...`);
    const r = await post(`/api/sessions/${sessionId}/run`, {function: name, args: []});
    const d = r.data;
    log(`${name} → result=${d.result_hex||d.result}`, 'ok');
    toast(`${name}: ${d.result_hex||d.result}`, 'info');
  } catch(e) { toast(e.message, 'error'); log(e.message, 'error'); }
}

async function populateRunFuncDropdown() {
  if (!sessionId) return;
  try {
    const r = await get(`/api/sessions/${sessionId}/scan?limit=500`);
    const funcs = (r.data && r.data.functions) || [];
    const sel = $('run-func-select');
    if (!sel) return;
    if (!funcs.length) {
      sel.innerHTML = '<option value="">-- no exported functions found --</option>';
      return;
    }
    const typeLabel = {jni:'[JNI]', cpp:'[C++]', libc:'[libc]', native:''};
    sel.innerHTML = '<option value="">-- select function --</option>' +
      funcs.map(f => {
        const label = `${typeLabel[f.type]||''} ${f.name}  (${f.address})`;
        return `<option value="${escAttr(f.name)}" data-type="${f.type}">${escHtml(label)}</option>`;
      }).join('');
  } catch(e) {
    logger && logger.debug && logger.debug('populateRunFuncDropdown error: ' + e.message);
  }
}

async function runSelectedFunc() {
  if (!sessionId) { toast('No active session', 'error'); return; }
  const sel = $('run-func-select');
  const name = sel ? sel.value : '';
  if (!name) { toast('Select a function first', 'error'); return; }
  const argsRaw = ($('run-func-args') || {}).value || '[]';
  let args = [];
  try { args = JSON.parse(argsRaw); } catch(e) { toast('Invalid args JSON', 'error'); return; }
  const resBox = $('run-func-result');
  if (resBox) { resBox.style.display = 'block'; resBox.innerHTML = '<span style="color:var(--text2)">Running…</span>'; }
  try {
    log(`Running ${name}(${argsRaw})...`);
    const r = await post(`/api/sessions/${sessionId}/run`, {function: name, args});
    const d = r.data;
    const hex = d.result_hex || String(d.result);
    const intVal = typeof d.result === 'number' ? d.result : null;
    log(`${name} → ${hex}`, 'ok');
    toast(`${name}: ${hex}`, 'info');
    if (resBox) {
      resBox.innerHTML = `
        <div class="stat-row"><span class="stat-label">Function</span><span class="stat-val" style="color:var(--cyan)">${escHtml(name)}</span></div>
        <div class="stat-row"><span class="stat-label">Return (hex)</span><span class="stat-val" style="color:var(--green)">${escHtml(hex)}</span></div>
        ${intVal !== null ? `<div class="stat-row"><span class="stat-label">Return (int)</span><span class="stat-val">${intVal}</span></div>` : ''}
      `;
    }
  } catch(e) {
    if (resBox) resBox.innerHTML = `<span style="color:var(--red)">${escHtml(e.message)}</span>`;
    toast(e.message, 'error'); log(e.message, 'error');
  }
}

async function staticAnalyze() {
  const path = $('static-path').value.trim();
  if (!path) return;
  try {
    const r = await get(`/api/info-path?path=${encodeURIComponent(path)}`);
    const d = r.data;
    $('static-info').style.display = 'block';
    $('static-info').innerHTML = `
      <div class="result-box">
        <div class="stat-row"><span class="stat-label">Machine</span><span class="stat-val">${d.machine||'?'}</span></div>
        <div class="stat-row"><span class="stat-label">Type</span><span class="stat-val">${d.type||'?'}</span></div>
        <div class="stat-row"><span class="stat-label">Entry</span><span class="stat-val">${d.entry_point||'0'}</span></div>
        <div class="stat-row"><span class="stat-label">Sections</span><span class="stat-val">${(d.sections||[]).length}</span></div>
        <div class="stat-row"><span class="stat-label">Exports</span><span class="stat-val">${(d.exports||[]).length}</span></div>
        <div class="stat-row"><span class="stat-label">Imports</span><span class="stat-val">${(d.imports||[]).length}</span></div>
        <div class="stat-row"><span class="stat-label">Deps</span><span class="stat-val">${(d.libraries||[]).join(', ')||'none'}</span></div>
        ${d.error ? `<div class="stat-row"><span class="stat-label" style="color:var(--red)">Error</span><span class="stat-val" style="color:var(--red)">${d.error}</span></div>` : ''}
      </div>
    `;
  } catch(e) { toast(e.message, 'error'); }
}

async function extractStrings() {
  if (!sessionId) { toast('No active session', 'error'); return; }
  const minLen = parseInt($('strings-min-len').value) || 4;
  const enc = $('strings-encoding').value || 'all';
  const sp = $('strings-spinner');
  if (sp) sp.style.display = 'inline-block';
  try {
    const r = await get(`/api/sessions/${sessionId}/strings?min_length=${minLen}&encoding=${enc}`);
    const d = r.data;
    if (d.error) { toast(d.error, 'error'); return; }
    const strings = d.strings || [];
    $('strings-result').style.display = 'block';
    $('strings-stats').textContent = `${strings.length} strings found`;
    if (!strings.length) {
      $('strings-body').innerHTML = '<tr><td colspan="5" style="color:var(--text3);padding:12px;text-align:center">No strings found.</td></tr>';
      return;
    }
    $('strings-body').innerHTML = strings.map(s => `
      <tr>
        <td class="addr" style="cursor:pointer" onclick="jumpToAddrInDisasm('${s.address}')">${s.address}</td>
        <td><span style="font-size:10px;background:var(--bg4);border-radius:2px;padding:0 4px">${escHtml(s.encoding)}</span></td>
        <td>${s.length}</td>
        <td style="color:var(--text3);font-size:11px">${escHtml(s.section)}</td>
        <td style="font-family:monospace;max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${escHtml(s.value)}">${escHtml(s.value)}</td>
      </tr>`).join('');
    toast(`Found ${strings.length} strings`, 'info');
  } catch(e) { toast(e.message, 'error'); }
  finally { if (sp) sp.style.display = 'none'; }
}

function jumpToAddrInDisasm(addr) {
  const disasmTab = document.querySelector('[data-panel=disasm]');
  if (disasmTab) switchPanel('disasm', disasmTab);
  const inp = $('disasm-addr');
  if (inp) { inp.value = addr; fetchDisasm(); }
}

// ── Registers ────────────────────────────────────────────────────────────
async function fetchRegisters() {
  if (!sessionId) return;
  $('regs-spinner').style.display = 'inline-block';
  try {
    const r = await get(`/api/sessions/${sessionId}/registers`);
    renderRegisters(r.data);
  } catch(e) { toast(e.message, 'error'); }
  finally { $('regs-spinner').style.display = 'none'; }
}

function renderRegisters(regs) {
  if (!regs || !Object.keys(regs).length) return;
  const grid = $('reg-grid');
  grid.innerHTML = Object.entries(regs).map(([k,v]) =>
    `<div class="reg-item">
      <span class="reg-name">${k}</span>
      <span class="reg-val">0x${(typeof v === 'number' ? v : 0).toString(16).padStart(8,'0').toUpperCase()}</span>
    </div>`
  ).join('');

  // Mini register grid in right panel
  const mini = $('mini-reg-grid');
  mini.innerHTML = Object.entries(regs).slice(0, 12).map(([k,v]) =>
    `<div class="mini-reg">
      <span class="mini-reg-name">${k}</span>
      <span class="mini-reg-val">0x${(typeof v==='number'?v:0).toString(16).toUpperCase()}</span>
    </div>`
  ).join('');
}

// ── Memory ────────────────────────────────────────────────────────────────
async function fetchMemory() {
  if (!sessionId) { toast('Create a session first', 'error'); return; }
  let addr = ($('mem-addr').value || '').trim();
  if (!addr) {
    // Fall back to the dashboard's known module base before guessing 0x400000
    const dash = $('dash-module-base');
    addr = (dash && dash.textContent && dash.textContent !== '—')
      ? dash.textContent.trim()
      : '0x400000';
    $('mem-addr').value = addr;
  }
  const size = parseInt($('mem-size').value) || 256;
  try {
    const r = await get(`/api/sessions/${sessionId}/memory?address=${encodeURIComponent(addr)}&size=${size}`);
    renderHex(r.data.address, r.data.data);
  } catch(e) { toast(e.message, 'error'); }
}

function onQuickMemAddrChange(sel) {
  const v = sel.value;
  if (!v) return;
  $('mem-addr').value = v;
  fetchMemory();
}

function renderHex(address, hexStr) {
  const bytes = [];
  for (let i = 0; i < hexStr.length; i += 2) bytes.push(parseInt(hexStr.slice(i,i+2),16));
  const base = parseInt(address, 16);
  let html = '';
  for (let row = 0; row < bytes.length; row += 16) {
    const chunk = bytes.slice(row, row+16);
    const offset = `<span class="hex-offset">${(base+row).toString(16).padStart(8,'0').toUpperCase()}</span>`;
    const hexPart = chunk.map((b,i) => {
      const cls = b ? 'hex-byte nz' : 'hex-byte';
      return `<span class="${cls}">${b.toString(16).padStart(2,'0').toUpperCase()}</span>${i===7?' <span class="hex-sep">│</span> ':' '}`;
    }).join('');
    const asciiPart = chunk.map(b => {
      const c = b >= 0x20 && b < 0x7f ? String.fromCharCode(b) : '.';
      return `<span class="hex-ascii">${escHtml(c)}</span>`;
    }).join('');
    html += `${offset}  ${hexPart.padEnd(54)} │ ${asciiPart}\n`;
  }
  $('hex-view').innerHTML = html;
}

async function fetchMemoryMap() {
  if (!sessionId) return;
  try {
    const r = await get(`/api/sessions/${sessionId}/memory/map`);
    const regions = r.data || [];
    const content = $('mem-map-content');
    if (!regions.length) {
      content.innerHTML = '<div style="color:var(--text2)">No memory regions (load a library first)</div>';
      return;
    }
    content.innerHTML = `
      <table class="data-table">
        <thead><tr><th>Start</th><th>End</th><th>Size</th><th>Perms</th></tr></thead>
        <tbody>${regions.map(r=>`
          <tr>
            <td class="addr">${r.start}</td>
            <td class="addr">${r.end}</td>
            <td>${formatSize(r.size)}</td>
            <td><span class="badge badge-blue">${r.perms}</span></td>
          </tr>`).join('')}
        </tbody>
      </table>`;
  } catch(e) { toast(e.message, 'error'); }
}

function formatSize(n) {
  if (n < 1024) return n + ' B';
  if (n < 1024*1024) return (n/1024).toFixed(1) + ' KB';
  return (n/(1024*1024)).toFixed(2) + ' MB';
}

async function searchMemory() {
  if (!sessionId) { toast('No active session', 'error'); return; }
  const pattern = ($('search-pattern') || {}).value || '';
  if (!pattern.trim()) { toast('Enter a search pattern', 'error'); return; }
  const searchType = ($('search-type') || {}).value || 'hex';
  const resultBox = $('search-results');
  if (resultBox) resultBox.innerHTML = '<span style="color:var(--text2)">Searching…</span>';
  try {
    const r = await post(`/api/sessions/${sessionId}/memory/search`, {
      pattern: pattern.trim(),
      type: searchType,
      max_results: 256,
    });
    const d = r.data;
    if (d.error) {
      if (resultBox) resultBox.innerHTML = `<span style="color:var(--red)">${escHtml(d.error)}</span>`;
      toast(d.error, 'error');
      return;
    }
    const matches = d.matches || [];
    if (!matches.length) {
      if (resultBox) resultBox.innerHTML = '<span style="color:var(--text3)">No matches found.</span>';
      toast('No matches', 'info');
      return;
    }
    const truncNote = d.truncated ? ` <span style="color:var(--yellow)">(truncated to ${matches.length})</span>` : '';
    if (resultBox) {
      resultBox.innerHTML = `<div style="margin-bottom:6px;font-size:11px;color:var(--text2)">${matches.length} match(es)${truncNote}</div>
        <div style="max-height:280px;overflow:auto">
        <table class="data-table">
          <thead><tr><th>Address</th><th>Hex preview</th></tr></thead>
          <tbody>${matches.map(m => `
            <tr>
              <td class="addr" style="cursor:pointer" onclick="goToMemAddr('${m.address}')">${m.address}</td>
              <td style="font-family:monospace;font-size:11px">${formatHexPreview(m.hex_preview)}</td>
            </tr>`).join('')}
          </tbody>
        </table></div>`;
    }
    toast(`Found ${matches.length} match(es)`, 'info');
  } catch(e) {
    if (resultBox) resultBox.innerHTML = `<span style="color:var(--red)">${escHtml(e.message)}</span>`;
    toast(e.message, 'error');
  }
}

function formatHexPreview(hex) {
  if (!hex) return '';
  const bytes = hex.match(/.{1,2}/g) || [];
  return bytes.map((b,i) => `<span style="color:${i < 8 ? 'var(--text3)' : i < bytes.length - 8 ? 'var(--cyan)' : 'var(--text3)'}">${b}</span>`).join(' ');
}

function goToMemAddr(addr) {
  const memTab = document.querySelector('[data-panel=memory]');
  if (memTab) switchPanel('memory', memTab);
  const inp = $('mem-addr');
  if (inp) { inp.value = addr; fetchMemory(); }
}

// ── Disassembly ───────────────────────────────────────────────────────────
async function fetchDisasm() {
  if (!sessionId) return;
  const addrInput = $('disasm-addr').value.trim();
  const count = parseInt($('disasm-count').value) || 40;
  try {
    let url;
    if (addrInput.startsWith('0x') || /^\d+$/.test(addrInput)) {
      url = `/api/sessions/${sessionId}/disasm?address=${encodeURIComponent(addrInput)}&count=${count}`;
    } else {
      url = `/api/sessions/${sessionId}/disasm-func?name=${encodeURIComponent(addrInput)}&count=${count}`;
    }
    const r = await get(url);
    const insns = Array.isArray(r.data) ? r.data : (r.data.instructions || []);
    renderDisasm(insns);
  } catch(e) { toast(e.message, 'error'); }
}

async function disasmAtPC() {
  const r = await get(`/api/sessions/${sessionId}/registers`).catch(() => null);
  if (r) {
    const pc = r.data.pc || r.data.x15 || r.data.r15 || 0;
    $('disasm-addr').value = '0x' + pc.toString(16);
    fetchDisasm();
  }
}

function renderDisasm(insns) {
  const tbody = $('disasm-body');
  tbody.innerHTML = insns.map((i,idx) => `
    <tr>
      <td class="addr">${i.address}</td>
      <td class="bytes">${i.bytes||''}</td>
      <td class="mnem">${escHtml(i.mnemonic||'')}</td>
      <td class="ops">${escHtml(i.op_str||'')}</td>
      <td class="row-actions">${rowActionButtons(i.address)}</td>
    </tr>`).join('');
  ensureDisasmActionsHeader('disasm-table');
}

// Compact action toolbar that lives on every disasm row. Lets the user wire
// a hook, breakpoint, patch or comment to a specific instruction without
// switching panels first — the corresponding modal opens pre-filled with the
// row's address.
function rowActionButtons(addrStr) {
  const a = escAttr(addrStr || '');
  return `<div class="disasm-actions">
    <button class="ico-btn" title="Hook here"     onclick="openAddHookFor('${a}')">H</button>
    <button class="ico-btn" title="Breakpoint here" onclick="openAddBPFor('${a}')">B</button>
    <button class="ico-btn" title="Patch here"    onclick="openAddPatchFor('${a}')">P</button>
    <button class="ico-btn" title="Comment here"  onclick="openAddCommentModal('${a}')">C</button>
  </div>`;
}

// Add an "Actions" column header if the original table didn't include one
// — keeps backward compatibility with any older table markup.
function ensureDisasmActionsHeader(tableId) {
  const t = $(tableId);
  if (!t) return;
  const headRow = t.querySelector('thead tr');
  if (!headRow) return;
  if (headRow.dataset.actionsAdded) return;
  const th = document.createElement('th');
  th.style.width = '120px';
  th.textContent = 'Actions';
  headRow.appendChild(th);
  headRow.dataset.actionsAdded = '1';
}

// ── Binary Disassembly (static file-level) ────────────────────────────────

async function loadBinaryDisasm() {
  if (!sessionId) return;
  if (binSymbols) return;
  try {
    const r = await get(`/api/sessions/${sessionId}/symbols`);
    binSymbols = r.data;
    populateBinSelectors(binSymbols);
  } catch(e) {
    toast('Load a library first to use Binary disassembly', 'info');
  }
}

function populateBinSelectors(symbols) {
  const funcSel = $('bin-disasm-func');
  const secSel = $('bin-disasm-section');
  const listBody = $('bin-func-list-body');

  const exports = symbols.exports || [];
  const sections = symbols.sections || [];

  funcSel.innerHTML = '<option value="">-- select function --</option>' +
    exports.map(e => `<option value="${escHtml(e.name)}">${escHtml(e.name)}  (${e.address})</option>`).join('');

  secSel.innerHTML = '<option value="">-- select section --</option>' +
    sections.map(s => `<option value="${escHtml(s.name)}">${escHtml(s.name)}  (${s.size} bytes)</option>`).join('');

  if (!exports.length) {
    listBody.innerHTML = '<div style="padding:8px 10px;color:var(--text3)">No exported symbols found.</div>';
    return;
  }
  listBody.innerHTML = exports.map(e =>
    `<div class="bin-func-item" onclick="binFuncClick(this,'${escAttr(e.name)}')" title="${escHtml(e.name)} @ ${e.address} (${e.size} bytes)">
      <span class="fn-name">${escHtml(e.name)}</span>
      <span class="fn-addr">${e.address}</span>
    </div>`
  ).join('');
}

function escAttr(s) {
  return s.replace(/'/g, "\\'").replace(/"/g, '&quot;');
}

// ── Cross-section integration helpers ─────────────────────────────────────
// These let one panel pull data discovered in another (binary symbols, memory
// regions, exports) so the user does not have to retype information that the
// tool already knows.

// Lazily fetch the static binary symbol table once per loaded library.
// Many panels need this (binary disasm, memory quick-addrs, analysis
// dropdowns, graph default addr) so we cache it on `binSymbols`.
async function ensureBinSymbols() {
  if (!sessionId) return null;
  if (binSymbols) return binSymbols;
  try {
    const r = await get(`/api/sessions/${sessionId}/symbols`);
    binSymbols = r.data || {};
  } catch(e) {
    binSymbols = null;
  }
  return binSymbols;
}

// Pick the most "interesting" exported symbol address for default focus
// (JNI_OnLoad first, then any Java_/JNICALL export, then the first FUNC).
function pickDefaultFunctionAddr() {
  if (!binSymbols || !binSymbols.exports || !binSymbols.exports.length) return null;
  const exports = binSymbols.exports;
  const jniOnLoad = exports.find(e => e.name === 'JNI_OnLoad');
  if (jniOnLoad) return jniOnLoad;
  const jni = exports.find(e => /^Java_/.test(e.name));
  if (jni) return jni;
  return exports[0];
}

// Build the list of useful "anchor" addresses (module base, heap, stack, …)
// Returned as an array of {label, value} objects used by both the memory
// dropdown and any other "quick jump" UIs we add later.
async function buildMemoryAnchors() {
  const anchors = [];
  if (!sessionId) return anchors;
  // Module base
  try {
    const s = await get(`/api/sessions/${sessionId}`);
    if (s.data && s.data.module_base) {
      anchors.push({ label: `Module base (${s.data.loaded_module || 'binary'})`, value: s.data.module_base });
    }
  } catch(e) {}
  // Memory map regions: heuristically tag heap / stack / first executable
  try {
    const r = await get(`/api/sessions/${sessionId}/memory/map`);
    const regions = r.data || [];
    const seen = new Set();
    regions.forEach(reg => {
      const start = reg.start;
      if (seen.has(start)) return;
      seen.add(start);
      // Common synthetic regions allocated by AndroidEmulator: heap & stack
      // are usually labelled in perms or land at predictable bases.
      if (/heap/i.test(reg.name||'')) {
        anchors.push({ label: `Heap start (${reg.start})`, value: reg.start });
      } else if (/stack/i.test(reg.name||'')) {
        anchors.push({ label: `Stack start (${reg.start})`, value: reg.start });
      }
    });
    // Always offer the first region as a fallback "start of memory"
    if (regions.length) {
      anchors.push({ label: `First region (${regions[0].start} ${regions[0].perms})`, value: regions[0].start });
    }
    // Add every region as a "Region <perms>" choice so power users can jump
    // anywhere without leaving the tab.
    regions.slice(0, 16).forEach(reg => {
      anchors.push({ label: `${reg.start} – ${reg.end} (${reg.perms}, ${formatSize(reg.size)})`, value: reg.start });
    });
  } catch(e) {}
  return anchors;
}

async function populateMemoryQuickAddrs() {
  const sel = $('mem-quick-addr');
  if (!sel) return;
  sel.innerHTML = '<option value="">— quick jump —</option>';
  const anchors = await buildMemoryAnchors();
  // De-duplicate by value while preserving the first (most descriptive) label
  const seen = new Set();
  anchors.forEach(a => {
    if (seen.has(a.value)) return;
    seen.add(a.value);
    const opt = document.createElement('option');
    opt.value = a.value;
    opt.textContent = a.label;
    sel.appendChild(opt);
  });
}

function autoFillMemoryAddr() {
  const inp = $('mem-addr');
  if (!inp) return;
  // Don't clobber a value the user already entered
  const cur = (inp.value || '').trim();
  if (cur && cur !== '0x400000') return;
  const dash = $('dash-module-base');
  if (dash && dash.textContent && dash.textContent !== '—') {
    inp.value = dash.textContent.trim();
  }
}

async function autoFillGraphAddr() {
  const inp = $('graph-addr-input');
  if (!inp) return;
  // Respect any value the user typed
  const cur = (inp.value || '').trim();
  if (cur) return;
  await ensureBinSymbols();
  const f = pickDefaultFunctionAddr();
  if (f && f.address) {
    inp.value = f.address;
    inp.title = `Default: ${f.name}`;
  }
}

// Re-populate every "function name" input across the analysis panel with a
// shared <datalist> sourced from the static symbol table — gives the user
// typeahead based on what's actually in the binary. The companion <select>
// dropdowns (marked with data-pickfn) are also filled so users can pick a
// function with a single click.
async function populateAnalysisFunctionLists() {
  if (!binSymbols) return;
  const exports = binSymbols.exports || [];
  if (!exports.length) return;
  let dl = $('all-functions-datalist');
  if (!dl) {
    dl = document.createElement('datalist');
    dl.id = 'all-functions-datalist';
    document.body.appendChild(dl);
  }
  dl.innerHTML = exports.map(e =>
    `<option value="${escHtml(e.name)}">${escHtml(e.address)}</option>`
  ).join('');
  ['cov-func', 'trace-func', 'taint-source', 'disasm-addr', 'hook-addr-input', 'bp-addr-input'].forEach(id => {
    const el = $(id);
    if (el && !el.getAttribute('list')) el.setAttribute('list', 'all-functions-datalist');
  });
  // Populate the inline "pick from binary" dropdowns next to each input
  document.querySelectorAll('select[data-pickfn]').forEach(sel => {
    sel.innerHTML = '<option value="">— pick from binary —</option>' +
      exports.map(e => `<option value="${escHtml(e.name)}">${escHtml(e.name)}  (${e.address})</option>`).join('');
  });
}

function binFuncClick(el, name) {
  document.querySelectorAll('.bin-func-item').forEach(e => e.classList.remove('active'));
  el.classList.add('active');
  $('bin-disasm-func').value = name;
  $('bin-disasm-section').value = '';
  fetchStaticDisasm();
}

function onBinFuncChange() {
  if ($('bin-disasm-func').value) {
    $('bin-disasm-section').value = '';
  }
}
function onBinSectionChange() {
  if ($('bin-disasm-section').value) {
    $('bin-disasm-func').value = '';
  }
}

// ── Function signature scanner ────────────────────────────────────────────

let _scanResults = [];

async function scanFunctions() {
  if (!sessionId) { toast('No session active', 'error'); return; }
  const filter = $('scan-filter').value.trim();
  const jniOnly = $('scan-jni-only').checked;
  const sp = $('scan-spinner');
  if (sp) sp.style.display = 'inline-block';
  $('scan-func-list-body').innerHTML =
    '<div style="padding:8px 10px;color:var(--text3)">Scanning…</div>';
  $('scan-detail').innerHTML = '';
  try {
    const params = new URLSearchParams({ limit: 500 });
    if (filter) params.set('filter', filter);
    if (jniOnly) params.set('jni_only', 'true');
    const r = await get(`/api/sessions/${sessionId}/scan?${params}`);
    const d = r.data;
    if (d.error) {
      $('scan-func-list-body').innerHTML =
        `<div style="padding:8px;color:var(--red)">${escHtml(d.error)}</div>`;
      return;
    }
    _scanResults = d.functions || [];
    $('scan-count').textContent = `(${_scanResults.length})`;
    renderScanList(_scanResults);
    toast(`Scanned ${_scanResults.length} functions`, 'info');
  } catch(e) {
    toast(e.message, 'error');
  } finally {
    if (sp) sp.style.display = 'none';
  }
}

function renderScanList(funcs) {
  const body = $('scan-func-list-body');
  if (!funcs.length) {
    body.innerHTML = '<div style="padding:8px 10px;color:var(--text3)">No functions found.</div>';
    return;
  }
  const typeColor = { jni: 'var(--green)', cpp: 'var(--yellow)', libc: 'var(--cyan)', native: 'var(--text3)' };
  body.innerHTML = funcs.map((f, i) => {
    const badge = f.type !== 'native'
      ? `<span style="font-size:9px;background:${typeColor[f.type]||'var(--text3)'};color:#000;border-radius:2px;padding:0 3px;margin-right:3px">${f.type.toUpperCase()}</span>`
      : '';
    const display = f.demangled ? f.demangled.substring(0, 35) : (f.name.length > 35 ? f.name.substring(0,32)+'…' : f.name);
    return `<div class="bin-func-item" onclick="showScanDetail(${i})" title="${escHtml(f.signature||f.name)}">
      <span class="fn-name">${badge}${escHtml(display)}</span>
      <span class="fn-addr">${f.address}</span>
    </div>`;
  }).join('');
}

function showScanDetail(idx) {
  document.querySelectorAll('#scan-func-list-body .bin-func-item')
    .forEach((el, i) => el.classList.toggle('active', i === idx));
  const f = _scanResults[idx];
  if (!f) return;

  const args = f.arguments || [];
  const argRows = args.length
    ? args.map((a,i) => `<tr><td style="color:var(--cyan)">${i}</td><td style="color:var(--green)">${escHtml(a.type)}</td><td>${escHtml(a.name)}</td></tr>`).join('')
    : '<tr><td colspan="3" style="color:var(--text3)">No arguments detected</td></tr>';

  const callArgs = args.filter(a => a.type !== '').map((a,i) => {
    if (a.type.includes('char*') || a.type.includes('String')) return `"arg${i}"`;
    if (a.type.includes('*')) return '0x0';
    if (a.type.includes('JNIEnv')) return ''; // skip
    return '0';
  }).filter(Boolean).join(', ');

  $('scan-detail').innerHTML = `
    <div style="margin-bottom:12px">
      <div style="font-weight:600;font-size:13px;color:var(--fg);margin-bottom:4px">${escHtml(f.name)}</div>
      ${f.demangled ? `<div style="color:var(--text2);font-size:11px;margin-bottom:4px">${escHtml(f.demangled)}</div>` : ''}
      <div style="display:flex;gap:8px;flex-wrap:wrap;font-size:11px;color:var(--text3);margin-bottom:8px">
        <span>Type: <b style="color:var(--fg)">${f.type}</b></span>
        <span>Address: <b style="color:var(--cyan)">${f.address}</b></span>
        <span>Size: <b style="color:var(--fg)">${f.size} bytes</b></span>
        <span>Returns: <b style="color:var(--green)">${escHtml(f.return_type||'unknown')}</b></span>
      </div>
      ${f.signature ? `<div class="code-block" style="font-size:11px;padding:8px;margin-bottom:8px;word-break:break-all">${escHtml(f.signature)}</div>` : ''}
    </div>
    <div class="section-label">Arguments (${args.length})</div>
    <table class="data-table" style="margin-bottom:12px">
      <thead><tr><th>#</th><th>Type</th><th>Name</th></tr></thead>
      <tbody>${argRows}</tbody>
    </table>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn btn-primary" onclick="applyFuncToQuickRun('${escAttr(f.name)}','${escAttr(callArgs)}')" title="Fill the dashboard's quick-run form and switch to it">
        Use in Quick-Run
      </button>
      <button class="btn btn-success" onclick="applyFuncToScript('${escAttr(f.name)}','${escAttr(callArgs)}')" title="Open the Script editor with a ready-to-run emu.call snippet">
        Use in Script Editor
      </button>
      <button class="btn btn-ghost" onclick="binFuncClickByName('${escAttr(f.name)}')">
        Disassemble
      </button>
      <button class="btn btn-ghost" onclick="openAddHookFor('${escAttr(f.name)}')">+ Hook</button>
      <button class="btn btn-ghost" onclick="openAddBPFor('${escAttr(f.name)}')">+ BP</button>
    </div>`;
}

// Send the function into the dashboard's "Run Any Function" widget so the
// user can immediately hit "Run" without retyping anything.
function applyFuncToQuickRun(name, callArgs) {
  const navEl = document.querySelector('.nav-btn[data-panel="dashboard"]');
  switchPanel('dashboard', navEl);
  const sel = $('run-func-select');
  if (sel) {
    let opt = Array.from(sel.options).find(o => o.value === name);
    if (!opt) {
      opt = document.createElement('option');
      opt.value = name;
      opt.textContent = name;
      sel.appendChild(opt);
    }
    sel.value = name;
  }
  const argsInp = $('run-func-args');
  if (argsInp) {
    // Wrap the comma-separated argument expressions into a JSON array
    const parts = (callArgs || '').split(',').map(p => p.trim()).filter(Boolean);
    argsInp.value = '[' + parts.join(', ') + ']';
  }
  toast(`Quick-Run filled: ${name}`, 'info');
}

// Drop a ready-to-run Python snippet into the script editor and switch to it.
// This lets the user iterate on the call (try different args, log return
// values, hook before/after) without leaving the workflow.
function applyFuncToScript(name, callArgs) {
  const navEl = document.querySelector('.nav-btn[data-panel="scripting"]');
  switchPanel('scripting', navEl);
  activateSubTab('script', 'editor');
  if (typeof scriptEditor !== 'undefined' && scriptEditor) {
    const argsExpr = '[' + (callArgs || '').split(',').map(p => p.trim()).filter(Boolean).join(', ') + ']';
    const snippet = `# Generated by Scan / Signatures → Use in Script Editor
# Function: ${name}
result = emu.call('${name}', ${argsExpr})
print(f'${name} returned: {result!r}')
`;
    const cur = scriptEditor.getValue();
    scriptEditor.setValue(cur && cur.trim() ? cur.replace(/\n*$/, '\n\n') + snippet : snippet);
    setTimeout(() => { scriptEditor.refresh(); scriptEditor.focus(); }, 50);
  }
  toast(`Script ready: ${name}`, 'info');
}

function binFuncClickByName(name) {
  // Switch to the Binary disasm tab and select the function
  const navEl = document.querySelector('.nav-btn[data-panel="disasm"]');
  switchPanel('disasm', navEl);
  activateSubTab('disasm', 'binary');
  const sel = $('bin-disasm-func');
  if (sel) {
    sel.value = name;
    fetchStaticDisasm();
  }
}

async function fetchStaticDisasm() {
  if (!sessionId) { toast('Create a session first', 'error'); return; }

  const target = $('bin-disasm-func').value;
  const section = $('bin-disasm-section').value;
  const count = parseInt($('bin-disasm-count').value) || 200;

  if (!target && !section) {
    toast('Select a function or section', 'info');
    return;
  }

  const params = new URLSearchParams({ count: count.toString() });
  if (target) params.set('target', target);
  if (section) params.set('section', section);

  try {
    const r = await get(`/api/sessions/${sessionId}/static-disasm?${params}`);
    renderStaticDisasm(r.data);
  } catch(e) { toast(e.message, 'error'); }
}

async function disasmAllFunctions() {
  if (!sessionId) { toast('Create a session first', 'error'); return; }
  const count = parseInt($('bin-disasm-count').value) || 200;
  const params = new URLSearchParams({target: 'all_functions', count});
  const info = $('bin-disasm-info');
  const tbody = $('bin-disasm-body');
  if (tbody) tbody.innerHTML = '<tr><td colspan="6" style="color:var(--text2);padding:16px">Disassembling all functions…</td></tr>';
  if (info) info.style.display = 'none';
  try {
    const r = await get(`/api/sessions/${sessionId}/static-disasm?${params}`);
    const data = r.data;
    if (info) {
      info.style.display = '';
      $('bin-disasm-target').textContent = 'All Functions';
      $('bin-disasm-meta').textContent = `${data.count} instructions  ·  ${data.functions||'?'} functions`;
    }
    renderBinDisasm(data.instructions || []);
  } catch(e) { toast(e.message, 'error'); }
}

function renderBinDisasm(insns) {
  const tbody = $('bin-disasm-body');
  if (!insns.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="color:var(--text3);padding:20px;text-align:center">No instructions found.</td></tr>';
    return;
  }
  tbody.innerHTML = insns.map(i => {
    const labelRow = i.label
      ? `<tr><td colspan="6" class="bin-disasm-label">${escHtml(i.label)}:</td></tr>`
      : '';
    return labelRow + `<tr>
      <td style="width:30px;text-align:center;color:var(--text3);font-size:10px"></td>
      <td class="addr">${i.address}</td>
      <td class="bytes">${i.bytes || ''}</td>
      <td class="mnem">${escHtml(i.mnemonic || '')}</td>
      <td class="ops">${escHtml(i.op_str || '')}</td>
      <td class="row-actions">${rowActionButtons(i.address)}</td>
    </tr>`;
  }).join('');
  ensureDisasmActionsHeader('bin-disasm-table');
}

function renderStaticDisasm(data) {
  const insns = data.instructions || [];
  const info = $('bin-disasm-info');
  const tbody = $('bin-disasm-body');

  info.style.display = 'block';
  $('bin-disasm-target').textContent = data.target || '';
  $('bin-disasm-meta').textContent = `${data.count} instructions  ·  base ${data.base_address}  ·  ${data.size} bytes`;

  if (!insns.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="color:var(--text3);padding:20px;text-align:center">No instructions found.</td></tr>';
    return;
  }

  tbody.innerHTML = insns.map(i => {
    const labelRow = i.label
      ? `<tr><td colspan="6" class="bin-disasm-label">${escHtml(i.label)}:</td></tr>`
      : '';
    return labelRow + `<tr>
      <td style="width:30px;text-align:center;color:var(--text3);font-size:10px"></td>
      <td class="addr">${i.address}</td>
      <td class="bytes">${i.bytes || ''}</td>
      <td class="mnem">${escHtml(i.mnemonic || '')}</td>
      <td class="ops">${escHtml(i.op_str || '')}</td>
      <td class="row-actions">${rowActionButtons(i.address)}</td>
    </tr>`;
  }).join('');
  ensureDisasmActionsHeader('bin-disasm-table');
}


// ── Hooks ─────────────────────────────────────────────────────────────────
async function refreshHooks() {
  if (!sessionId) return;
  try {
    const r = await get(`/api/sessions/${sessionId}/hooks`);
    renderHooks(r.data || []);
    $('dash-hooks').textContent = (r.data||[]).length;
  } catch(e) {}
}

function renderHooks(hooks) {
  const list = $('hooks-list');
  if (!hooks.length) {
    list.innerHTML = '<div style="color:var(--text2);font-size:12px">No hooks. Click "+ Add Hook" to create one.</div>';
    return;
  }
  list.innerHTML = hooks.map(h => `
    <div class="item-card">
      <div class="item-card-info">
        <span class="item-card-name">${escHtml(h.name)}</span>
        <span class="item-card-addr">${h.address}</span>
        <span class="item-card-meta">Hits: ${h.hit_count} &nbsp; ${h.enabled ? '<span class="badge badge-green">enabled</span>' : '<span class="badge badge-red">disabled</span>'}</span>
      </div>
      <div class="item-card-actions">
        <button class="btn btn-ghost" style="padding:3px 8px;font-size:11px" onclick="removeHook('${h.id}')">Remove</button>
      </div>
    </div>`).join('');
}

function openAddHook() { openAddHookFor(''); }

// Open the hook modal pre-filled with `addr`. Used by the "+ Hook" buttons
// on every disasm row and by the scan-detail panel.
function openAddHookFor(addr) {
  $('hook-addr-input').value = addr || '';
  $('hook-name-input').value = '';
  // Sensible default script: print where we hit, plus the live PC so the
  // user has something runnable the moment the modal closes.
  $('hook-script-input').value = `print(f'[hook] hit at {address:#x}')`;
  openModal('modal-add-hook');
}

async function addHook() {
  if (!sessionId) { toast('No session', 'error'); return; }
  const addr = $('hook-addr-input').value.trim();
  const name = $('hook-name-input').value.trim() || 'hook';
  const script = $('hook-script-input').value;
  if (!addr) { toast('Address required', 'error'); return; }
  try {
    await post(`/api/sessions/${sessionId}/hooks`, {address: addr, name, script});
    closeModal('modal-add-hook');
    toast('Hook added — open Script tab to test', 'info');
    markDirty();
    refreshHooks();
    // Drop the user into the script editor with a ready-to-run snippet that
    // exercises the hook (the natural next step after creating one).
    afterHookOrBPRedirect('hook', name, addr);
  } catch(e) { toast(e.message, 'error'); }
}

// Append a "test" snippet to the script editor and switch to it, so the user
// can immediately invoke the function the hook/breakpoint is attached to.
function afterHookOrBPRedirect(kind, name, addr) {
  const navEl = document.querySelector('.nav-btn[data-panel="scripting"]');
  switchPanel('scripting', navEl);
  activateSubTab('script', 'editor');
  if (typeof scriptEditor === 'undefined' || !scriptEditor) return;
  // If `addr` looks like a function name (or matches a known export), we
  // call it directly. Otherwise we just try the default JNI_OnLoad.
  let target = "'JNI_OnLoad'";
  if (addr && !/^0x?[0-9a-fA-F]+$/.test(addr)) {
    target = `'${addr.replace(/'/g, "\\'")}'`;
  }
  const snippet = `# Generated after adding ${kind} '${name}' @ ${addr || '(unknown)'}
# Run this to trigger the ${kind} you just installed.
try:
    result = emu.call(${target})
    print(f'${kind} test → {target} returned {result!r}')
except Exception as e:
    print(f'${kind} test failed: {e}')
`;
  const cur = scriptEditor.getValue();
  scriptEditor.setValue(cur && cur.trim() ? cur.replace(/\n*$/, '\n\n') + snippet : snippet);
  setTimeout(() => { scriptEditor.refresh(); scriptEditor.focus(); }, 50);
}
async function removeHook(id) {
  await del(`/api/sessions/${sessionId}/hooks/${id}`).catch(e => toast(e.message,'error'));
  markDirty();
  refreshHooks();
}
function onHookHit(msg) {
  log(`Hook ${msg.hook_id} hit at ${msg.address} (x${msg.hit_count})`, 'warn');
  $('right-hooks').textContent = `Hit: hook ${msg.hook_id} @ ${msg.address}`;
}

// ── Breakpoints ───────────────────────────────────────────────────────────
async function refreshBreakpoints() {
  if (!sessionId) return;
  try {
    const r = await get(`/api/sessions/${sessionId}/breakpoints`);
    renderBreakpoints(r.data || []);
    $('dash-bps').textContent = (r.data||[]).length;
  } catch(e) {}
}

function renderBreakpoints(bps) {
  const list = $('bp-list');
  if (!bps.length) {
    list.innerHTML = '<div style="color:var(--text2);font-size:12px">No breakpoints. Click "+ Add Breakpoint".</div>';
    return;
  }
  list.innerHTML = bps.map(b => `
    <div class="item-card">
      <div class="item-card-info">
        <span class="item-card-name">${escHtml(b.name)}</span>
        <span class="item-card-addr">${b.address}</span>
        <span class="item-card-meta">Hits: ${b.hit_count}</span>
      </div>
      <div class="item-card-actions">
        <button class="btn btn-danger" style="padding:3px 8px;font-size:11px" onclick="removeBreakpoint('${b.id}')">Remove</button>
      </div>
    </div>`).join('');
}

function openAddBP() { openAddBPFor(''); }

function openAddBPFor(addr) {
  $('bp-addr-input').value = addr || '';
  $('bp-name-input').value = '';
  openModal('modal-add-bp');
}

async function addBreakpoint() {
  if (!sessionId) { toast('No session', 'error'); return; }
  const addr = $('bp-addr-input').value.trim();
  const name = $('bp-name-input').value.trim() || 'bp';
  if (!addr) { toast('Address required', 'error'); return; }
  try {
    await post(`/api/sessions/${sessionId}/breakpoints`, {address: addr, name});
    closeModal('modal-add-bp');
    toast('Breakpoint added — open Script tab to trigger', 'info');
    markDirty();
    refreshBreakpoints();
    afterHookOrBPRedirect('breakpoint', name, addr);
  } catch(e) { toast(e.message, 'error'); }
}
async function removeBreakpoint(id) {
  await del(`/api/sessions/${sessionId}/breakpoints/${id}`).catch(e => toast(e.message,'error'));
  markDirty();
  refreshBreakpoints();
}
function onBreakpointHit(msg) {
  log(`Breakpoint ${msg.bp_id} hit at ${msg.address}`, 'warn');
  toast(`Breakpoint hit @ ${msg.address}`, 'info');
}

// ── Analysis ──────────────────────────────────────────────────────────────
async function runAnalysis(type, options) {
  if (!sessionId) { toast('No session active', 'error'); return; }
  log(`Running ${type} analysis...`);
  toast(`Starting ${type}...`, 'info');
  try {
    const r = await post(`/api/sessions/${sessionId}/analysis`, {type, options});
    const d = r.data;
    const resultId = {
      coverage: 'cov-result',
      trace: 'trace-result',
      taint: 'taint-result',
      deobfuscate: 'deobfuscate-result',
      anti_tampering: 'antitamper-result',
      rop: 'gadget-list',
      rop_chain: 'rop-chain-result',
    }[type] || 'cov-result';

    const box = $(resultId);
    if (!box) return;
    box.style.display = 'block';

    if (d.error) {
      box.innerHTML = `<h4>${type} Error</h4><div style="color:var(--red)">${escHtml(d.error)}</div>`;
      toast(d.error, 'error');
    } else if (type === 'coverage') {
      box.innerHTML = `<h4>Coverage Results</h4>
        <div class="stat-row"><span class="stat-label">Unique Blocks</span><span class="stat-val">${d.unique_blocks||0}</span></div>
        <div class="stat-row"><span class="stat-label">Total Blocks</span><span class="stat-val">${d.total_blocks||0}</span></div>
        <div class="stat-row"><span class="stat-label">Instructions</span><span class="stat-val">${d.unique_instructions||0}</span></div>`;
      toast('Coverage done', 'info');
    } else if (type === 'trace') {
      box.innerHTML = `<h4>Trace Results</h4>
        <div class="stat-row"><span class="stat-label">Instructions traced</span><span class="stat-val">${d.count||0}</span></div>`;
      if (d.entries && d.entries.length) {
        const tw = $('trace-table-wrap');
        if (tw) {
          tw.style.display = 'block';
          $('trace-body').innerHTML = d.entries.slice(0,200).map((e,i)=>
            `<tr><td>${i+1}</td><td class="addr">${e.address||''}</td><td class="mnem">${escHtml(e.mnemonic||'')}</td><td class="ops">${escHtml(e.op_str||'')}</td></tr>`
          ).join('');
        }
      }
      toast('Trace complete', 'info');
    } else if (type === 'rop') {
      const gadgets = d.gadgets || [];
      box.innerHTML = gadgets.map(g =>
        `<div class="gadget-item"><span class="gadget-addr">${g.address}</span><span class="gadget-insns">${escHtml(g.description||'')}</span></div>`
      ).join('') || '<div style="color:var(--text2)">No gadgets found</div>';
      toast(`Found ${d.count||0} gadgets`, 'info');
    } else {
      box.innerHTML = `<h4>${type}</h4><pre style="font-size:11px;color:var(--text2)">${escHtml(JSON.stringify(d,null,2))}</pre>`;
      toast(`${type} complete`, 'info');
    }
    log(`${type} complete`, 'ok');
  } catch(e) {
    toast(e.message, 'error'); log(e.message, 'error');
  }
}

async function runCryptoDetection() {
  if (!sessionId) { toast('No session active', 'error'); return; }
  const sp = $('crypto-spinner');
  if (sp) sp.style.display = 'inline-block';
  log('Running crypto detection...');
  try {
    const r = await post(`/api/sessions/${sessionId}/analysis`, {type: 'crypto', options: {}});
    const d = r.data;
    $('crypto-result').style.display = 'block';
    if (d.error) {
      $('crypto-stats').textContent = 'Error: ' + d.error;
      $('crypto-body').innerHTML = '';
      toast(d.error, 'error');
      return;
    }
    const matches = d.matches || [];
    $('crypto-stats').textContent = `${matches.length} crypto constant${matches.length !== 1 ? 's' : ''} found`;
    if (!matches.length) {
      $('crypto-body').innerHTML = '<tr><td colspan="5" style="color:var(--text3);padding:12px;text-align:center">No known crypto constants detected.</td></tr>';
      toast('No crypto constants found', 'info');
      return;
    }
    const algColors = {
      'AES': 'var(--cyan)', 'DES': 'var(--yellow)',
      'MD5': 'var(--orange)', 'SHA-1': 'var(--blue)',
      'SHA-256': 'var(--purple)', 'RC4': 'var(--green)',
    };
    $('crypto-body').innerHTML = matches.map(m => `
      <tr>
        <td><span style="font-weight:600;color:${algColors[m.algorithm]||'var(--text)'}">${escHtml(m.algorithm)}</span></td>
        <td>${Math.round(m.confidence * 100)}%</td>
        <td class="addr" style="cursor:pointer" onclick="jumpToAddrInDisasm('${m.address}')">${m.address}</td>
        <td style="font-size:11px;color:var(--text3)">${escHtml(m.signature)}</td>
        <td style="font-size:11px;color:var(--text3)">${escHtml(m.section)}</td>
      </tr>`).join('');
    toast(`Found ${matches.length} crypto constant(s)`, 'info');
    log(`Crypto detection: ${matches.length} matches`, 'ok');
  } catch(e) {
    toast(e.message, 'error'); log(e.message, 'error');
  } finally {
    if (sp) sp.style.display = 'none';
  }
}

// ── Scripting ─────────────────────────────────────────────────────────────
function initScriptEditor() {
  const ta = $('script-cm-area');
  scriptEditor = CodeMirror.fromTextArea(ta, {
    mode: 'python',
    theme: 'one-dark',
    lineNumbers: true,
    matchBrackets: true,
    autoCloseBrackets: true,
    indentUnit: 4,
    tabSize: 4,
    indentWithTabs: false,
    extraKeys: {
      "Ctrl-Enter": runScript,
      "Ctrl-Space": cm => cm.showHint({hint: pyunidbgHint, completeSingle: false}),
    },
    hintOptions: { completeSingle: false },
  });
  scriptEditor.setValue(`# PyUniDbg Python Script
# Available: emu, module, print
# Ctrl+Space for autocomplete

print("Hello from PyUniDbg script!")
if emu:
    regs = emu.get_cpu_context()
    print(f"PC: {getattr(regs, 'pc', 0):#x}")
`);

  scriptEditor.on('inputRead', (cm, event) => {
    if (event.text[0] && /[a-zA-Z_.]/.test(event.text[0])) {
      cm.showHint({hint: pyunidbgHint, completeSingle: false});
    }
  });

  document.querySelector('#script-type').addEventListener('change', function() {
    scriptEditor.setOption('mode', this.value === 'frida' ? 'javascript' : 'python');
  });

  loadAutocompleteData();
}

async function loadAutocompleteData() {
  try {
    const r = await get('/api/autocomplete');
    autocompleteData = r.data;
  } catch(e) {
    autocompleteData = _fallbackAutocomplete();
  }
}

function _fallbackAutocomplete() {
  return {
    python: {
      globals: ['emu', 'module', 'print'],
      emu: ['call', 'run', 'step', 'stop', 'mem_read', 'mem_write', 'read_string',
            'write_string', 'alloc_string', 'disassemble', 'disassemble_at',
            'save_state', 'restore_state', 'hexdump', 'add_symbol', 'get_symbol',
            'hook_add_code', 'get_cpu_context', 'mem_regions', 'arch', 'is_64bit', 'pointer_size'],
      module: ['name', 'base_address', 'size', 'exports', 'get_function_address'],
      classes: {
        Interceptor: ['attach', 'detachAll', 'replace', 'revert', 'flush'],
        Memory: ['alloc', 'allocUtf8String', 'readU32', 'readU64', 'readUtf8String',
                 'writeU32', 'writeU64', 'writeByteArray', 'scan', 'scanSync'],
        NativePointer: ['isNull', 'add', 'sub', 'readU32', 'readUtf8String', 'writeU32'],
        NativeFunction: ['call', 'apply'],
        Module: ['load', 'findBaseAddress', 'findExportByName', 'enumerateModules'],
        Process: ['get_id', 'get_arch', 'enumerateModules', 'enumerateRanges'],
        Java: ['perform', 'use', 'choose', 'enumerateLoadedClassesSync'],
      },
    },
    frida: {
      globals: ['Interceptor', 'Memory', 'Module', 'Process', 'NativePointer',
                'NativeFunction', 'ptr', 'NULL', 'console', 'send', 'recv', 'Java', 'Stalker'],
    },
  };
}

function pyunidbgHint(cm) {
  const cur = cm.getCursor();
  const token = cm.getTokenAt(cur);
  const line = cm.getLine(cur.line);
  const end = cur.ch;
  let start = token.start;
  const word = token.string;

  const mode = $('script-type').value;
  const dict = autocompleteData ? autocompleteData[mode] || autocompleteData.python : _fallbackAutocomplete().python;
  let completions = [];

  const dotMatch = line.slice(0, end).match(/(\w+)\.\s*(\w*)$/);
  if (dotMatch) {
    const obj = dotMatch[1];
    const partial = dotMatch[2] || '';
    start = end - partial.length;
    let members = [];
    if (dict[obj]) {
      members = Array.isArray(dict[obj]) ? dict[obj] : [];
    }
    if (dict.classes && dict.classes[obj]) {
      members = members.concat(dict.classes[obj]);
    }
    completions = members
      .filter(m => {
        const name = typeof m === 'string' ? m.split('(')[0] : m;
        return name.toLowerCase().startsWith(partial.toLowerCase());
      })
      .map(m => typeof m === 'string' ? m : m);
  } else {
    if (word.length >= 1) {
      const allWords = new Set();
      (dict.globals || []).forEach(g => allWords.add(g));
      if (dict.imports) {
        Object.values(dict.imports).forEach(arr => arr.forEach(s => allWords.add(s)));
      }
      if (dict.classes) {
        Object.keys(dict.classes).forEach(c => allWords.add(c));
      }
      ['from', 'import', 'def', 'class', 'return', 'if', 'elif', 'else', 'for', 'while',
       'try', 'except', 'finally', 'with', 'as', 'lambda', 'True', 'False', 'None',
       'Interceptor', 'Memory', 'NativePointer', 'NativeFunction', 'Module', 'Process',
       'Java', 'Stalker', 'Instruction', 'ApiResolver', 'NativeCallback',
      ].forEach(k => allWords.add(k));

      completions = [...allWords].filter(w => w.toLowerCase().startsWith(word.toLowerCase()) && w !== word);
    }
  }

  if (!completions.length) return;
  return {
    list: completions.map(c => {
      const display = typeof c === 'string' ? c : String(c);
      const text = display.split('(')[0];
      return { text, displayText: display };
    }),
    from: CodeMirror.Pos(cur.line, start),
    to: CodeMirror.Pos(cur.line, end),
  };
}

async function runScript() {
  if (!sessionId) { toast('No session active', 'error'); return; }
  const code = scriptEditor ? scriptEditor.getValue() : '';
  const type = $('script-type').value;
  const out = $('script-output');
  out.textContent = 'Running...';
  out.className = 'script-output';
  try {
    const r = await post(`/api/sessions/${sessionId}/script`, {code, type});
    out.textContent = r.data.output || '(no output)';
    if (!r.data.success) out.classList.add('error');
    log('Script executed', r.data.success ? 'ok' : 'error');
  } catch(e) {
    out.textContent = e.message; out.classList.add('error');
    toast(e.message, 'error');
  }
}

const SCRIPT_TEMPLATES = [
  {name:'Hook JNI_OnLoad', code:`# Hook JNI_OnLoad
def on_jni_onload(emu, address, size, user_data):
    print(f"JNI_OnLoad called at {address:#x}")

if module:
    addr = module.get_function_address('JNI_OnLoad')
    if addr:
        emu.hook_add_code(addr, on_jni_onload)
        print(f"Hooked JNI_OnLoad at {addr:#x}")
`},
  {name:'Read String from Memory', code:`# Read null-terminated string from address
def read_str(emu, addr, max_len=256):
    data = bytes(emu.mem_read(addr, max_len))
    end = data.find(b'\\x00')
    return data[:end].decode('utf-8', errors='replace')

# Example:
# s = read_str(emu, 0x12345678)
# print(f"String: {s}")
print("Adjust address and uncomment")
`},
  {name:'Dump Exports', code:`# Dump all exports of the loaded module
if module:
    exports = getattr(module, 'exports', {}) or {}
    for name, addr in sorted(exports.items(), key=lambda x: x[1]):
        print(f"  {addr:#010x}  {name}")
else:
    print("No module loaded")
`},
  {name:'Memory Pattern Search', code:`# Search for a byte pattern in all mapped memory
PATTERN = bytes.fromhex('DE AD BE EF')  # change this

if emu:
    try:
        for start, end, perms in emu.mem_regions():
            data = bytes(emu.mem_read(start, end - start))
            pos = 0
            while True:
                idx = data.find(PATTERN, pos)
                if idx == -1: break
                print(f"Found at {start + idx:#x}")
                pos = idx + 1
    except Exception as e:
        print(f"Error: {e}")
`},
];

function loadScriptTemplate() {
  const list = $('template-list');
  list.innerHTML = SCRIPT_TEMPLATES.map((t,i)=>
    `<div class="item-card" style="cursor:pointer" onclick="applyTemplate(${i})">
      <div class="item-card-info"><span class="item-card-name">${t.name}</span></div>
      <button class="btn btn-ghost" style="font-size:11px;padding:3px 8px">Use</button>
    </div>`
  ).join('');
  openModal('modal-templates');
}

function applyTemplate(i) {
  if (scriptEditor) scriptEditor.setValue(SCRIPT_TEMPLATES[i].code);
  closeModal('modal-templates');
}

// ── ROP ───────────────────────────────────────────────────────────────────
async function findGadgets() {
  await runAnalysis('rop', {max_gadgets: parseInt($('gadget-max').value)||200});
}

async function buildROPChain() {
  if (!sessionId) { toast('No session', 'error'); return; }
  const goal = $('rop-goal').value.trim();
  if (!goal) { toast('Enter a goal first', 'error'); return; }
  const box = $('rop-chain-result');
  box.style.display = 'block';
  box.innerHTML = `<p style="color:var(--text2)">Searching gadgets for goal: "${escHtml(goal)}"...</p>`;
  try {
    const r = await post(`/api/sessions/${sessionId}/analysis`, {type: 'rop_chain', options: {goal}});
    const d = r.data;
    if (d.error) {
      box.innerHTML = `<div style="color:var(--red)">${escHtml(d.error)}</div>`;
      return;
    }
    const gadgets = d.gadgets || [];
    const note = d.note ? `<p style="color:var(--text2);font-size:11px">${escHtml(d.note)}</p>` : '';
    box.innerHTML = `<h4>ROP gadgets for: ${escHtml(d.goal||goal)}</h4>${note}` +
      (gadgets.length
        ? gadgets.map(g =>
            `<div class="gadget-item"><span class="gadget-addr">${escHtml(g.address)}</span><span class="gadget-insns">${escHtml(g.description||'')} <em style="color:var(--text2)">[${escHtml(g.pattern||'')}]</em></span></div>`
          ).join('')
        : '<div style="color:var(--text2)">No matching gadgets found. Try loading a library first.</div>');
    toast(`Found ${d.gadgets_found||0} candidate gadgets`, 'info');
  } catch(e) {
    box.innerHTML = `<div style="color:var(--red)">${escHtml(e.message)}</div>`;
    toast(e.message, 'error');
  }
}

async function genShellcode() {
  if (!sessionId) { toast('No session', 'error'); return; }
  const box = $('shellcode-result');
  box.style.display = 'block';
  const scType = $('shellcode-type') ? $('shellcode-type').value : '';
  const customAsm = $('shellcode-asm') ? $('shellcode-asm').value.trim() : '';
  // Use the script API to generate shellcode via pwntools/keystone
  const code = customAsm
    ? `# Assemble custom shellcode\ntry:\n    import keystone; ks = keystone.Ks(keystone.KS_ARCH_ARM64, keystone.KS_MODE_LITTLE_ENDIAN)\n    sc, _ = ks.asm("""${customAsm.replace(/"/g, "'").replace(/\n/g, '\\n')}""")\n    print("Shellcode (" + str(len(sc)) + " bytes):", bytes(sc).hex())\nexcept Exception as e:\n    print("Error:", e)\n    print("Tip: install keystone-engine with: pip install keystone-engine")`
    : `# Generate shellcode via pwntools\ntry:\n    import pwn; pwn.context.arch = 'aarch64'; pwn.context.os = 'linux'\n    sc = pwn.asm(pwn.shellcraft.sh())\n    print("exec /bin/sh shellcode (" + str(len(sc)) + " bytes):", sc.hex())\nexcept Exception as e:\n    print("Error:", e)\n    print("Tip: install pwntools with: pip install pwntools")`;
  box.innerHTML = `<p style="color:var(--text2)">Running in script editor...</p>`;
  if (scriptEditor) {
    scriptEditor.setValue(code);
    toast('Shellcode script loaded — press Run Script or Ctrl+Enter', 'info');
    // Switch to the script tab
    const scriptTab = document.querySelector('[data-panel="panel-script"]');
    if (scriptTab) scriptTab.click();
  } else {
    box.innerHTML = `<pre style="font-size:11px;color:var(--text2)">${escHtml(code)}</pre><p style="color:var(--text2)">Copy the above into the Script Editor and run it.</p>`;
  }
}

// ── Concolic ──────────────────────────────────────────────────────────────
async function runConcolic() {
  if (!sessionId) { toast('No session', 'error'); return; }
  const func = $('conc-func').value.trim();
  const max_paths = parseInt($('conc-paths').value);
  await runAnalysis('concolic', {function: func, max_paths});
  const box = $('conc-result');
  box.style.display = 'block';
}

// ── Reports ───────────────────────────────────────────────────────────────
async function generateReport() {
  if (!sessionId) { toast('No session', 'error'); return; }
  const fmt = $('report-fmt').value;
  toast('Generating report...', 'info');
  try {
    const r = await post(`/api/sessions/${sessionId}/report`, {format: fmt});
    reportData = r.data;
    if (r.data.success) {
      $('report-content').style.display = 'block';
      $('report-output').value = r.data.content || JSON.stringify(r.data, null, 2);
      toast('Report generated', 'info');
    } else {
      toast(r.data.error || 'Report failed', 'error');
    }
  } catch(e) { toast(e.message, 'error'); }
}

function downloadReport() {
  if (!reportData) return;
  const blob = new Blob([reportData.content || JSON.stringify(reportData)],
    {type: reportData.format === 'html' ? 'text/html' : 'text/plain'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `pyunidbg-report.${reportData.format}`;
  a.click();
}

function copyReport() {
  navigator.clipboard.writeText($('report-output').value);
  toast('Copied to clipboard', 'info');
}

// ── Config ────────────────────────────────────────────────────────────────
async function loadConfig() {
  try {
    const [vr, cr] = await Promise.all([get('/api/version'), get('/api/config')]);
    const v = vr.data;
    $('version-info').innerHTML = Object.entries(v).map(([k,val])=>
      `<div class="stat-row"><span class="stat-label">${k}</span><span class="stat-val">${escHtml(String(val))}</span></div>`
    ).join('');
    const cfg = cr.data || {};
    const form = $('config-form');
    form.innerHTML = Object.entries(cfg).map(([k,v])=>`
      <div class="field-row">
        <label>${k}</label>
        <input type="text" id="cfg-${k}" value="${escHtml(String(v))}">
      </div>`).join('') || '<div style="color:var(--text2)">No config keys.</div>';
  } catch(e) { $('version-info').innerHTML = `<span style="color:var(--red)">${e.message}</span>`; }
}

async function saveConfig() {
  const form = $('config-form');
  const inputs = form.querySelectorAll('input');
  const data = {};
  inputs.forEach(i => { data[i.id.replace('cfg-','')] = i.value; });
  try {
    await put('/api/config', data);
    toast('Config saved', 'info');
  } catch(e) { toast(e.message, 'error'); }
}

async function runCLICommand() {
  const cmd = $('cfg-cli-cmd').value.trim();
  if (!cmd) return;
  const out = $('cli-cmd-output');
  out.style.display = 'block';
  out.textContent = 'Running...';
  try {
    const r = await post('/api/cli', {command: cmd});
    out.textContent = r.data.stdout + (r.data.stderr ? '\nSTDERR:\n' + r.data.stderr : '');
  } catch(e) { out.textContent = e.message; }
}

// ── CLI panel ─────────────────────────────────────────────────────────────
async function cliKeydown(e) {
  if (e.key === 'Enter') {
    const cmd = e.target.value.trim();
    if (!cmd) return;
    cliHistory.unshift(cmd);
    cliHistIdx = -1;
    e.target.value = '';
    appendCLI(`$ pyunidbg ${cmd}`, 'var(--text2)');
    try {
      const r = await post('/api/cli', {command: cmd});
      appendCLI(r.data.stdout);
      if (r.data.stderr) appendCLI(r.data.stderr, 'var(--red)');
    } catch(err) { appendCLI(err.message, 'var(--red)'); }
  } else if (e.key === 'ArrowUp') {
    if (cliHistIdx < cliHistory.length-1) {
      cliHistIdx++;
      e.target.value = cliHistory[cliHistIdx];
    }
    e.preventDefault();
  } else if (e.key === 'ArrowDown') {
    if (cliHistIdx > 0) { cliHistIdx--; e.target.value = cliHistory[cliHistIdx]; }
    else { cliHistIdx = -1; e.target.value = ''; }
    e.preventDefault();
  }
}

function appendCLI(text, color) {
  const out = $('cli-output');
  const span = document.createElement('span');
  if (color) span.style.color = color;
  span.textContent = text;
  out.appendChild(span);
  out.appendChild(document.createElement('br'));
  out.scrollTop = out.scrollHeight;
}

// ── Modals ────────────────────────────────────────────────────────────────
function openModal(id) { $(id).classList.add('open'); }
function closeModal(id) { $(id).classList.remove('open'); }
// Close on overlay click
document.querySelectorAll('.modal-overlay').forEach(ov => {
  ov.addEventListener('click', e => { if (e.target === ov) ov.classList.remove('open'); });
});

// ── Log viewer ────────────────────────────────────────────────────────────
const LOG_LEVELS = { debug: 0, info: 1, warning: 2, error: 3, critical: 4 };
const MAX_LOG_ENTRIES = 5000;

function addLogEntry(msg) {
  const entry = {
    level: (msg.level || 'info').toLowerCase(),
    logger: msg.logger || '',
    message: msg.message || '',
    timestamp: msg.timestamp || (Date.now() / 1000),
  };
  logEntries.push(entry);
  if (logEntries.length > MAX_LOG_ENTRIES) logEntries.splice(0, logEntries.length - MAX_LOG_ENTRIES);

  log(`[${entry.level.toUpperCase()}] ${entry.message}`,
      entry.level === 'error' || entry.level === 'critical' ? 'error' :
      entry.level === 'warning' ? 'warn' : 'info');

  if (shouldShowEntry(entry)) {
    appendLogDOM(entry);
  }
  $('log-count').textContent = `${logEntries.length} entries`;
}

function shouldShowEntry(entry) {
  const minLevel = $('log-level-filter').value;
  if ((LOG_LEVELS[entry.level] || 0) < (LOG_LEVELS[minLevel] || 0)) return false;
  const textFilter = ($('log-text-filter').value || '').toLowerCase();
  if (textFilter && !entry.message.toLowerCase().includes(textFilter) &&
      !entry.logger.toLowerCase().includes(textFilter)) return false;
  return true;
}

function appendLogDOM(entry) {
  const viewer = $('log-viewer');
  const el = document.createElement('div');
  el.className = `log-entry log-${entry.level}`;
  const ts = new Date(entry.timestamp * 1000);
  const timeStr = ts.toLocaleTimeString(undefined, {hour12:false, hour:'2-digit', minute:'2-digit', second:'2-digit'})
    + '.' + String(ts.getMilliseconds()).padStart(3, '0');
  el.innerHTML = `<span class="log-ts">${timeStr}</span><span class="log-src">${escHtml(entry.logger.replace('pyunidbg.',''))}</span>${escHtml(entry.message.replace(/^(DEBUG|INFO|WARNING|ERROR|CRITICAL)\s*\[.*?\]\s*/, ''))}`;
  viewer.appendChild(el);
  if ($('log-autoscroll').checked) {
    viewer.scrollTop = viewer.scrollHeight;
  }
}

function filterLogs() {
  const viewer = $('log-viewer');
  viewer.innerHTML = '';
  logEntries.filter(shouldShowEntry).forEach(appendLogDOM);
}

function clearLogs() {
  logEntries = [];
  $('log-viewer').innerHTML = '';
  $('log-count').textContent = '0 entries';
}

// ── Export generators ─────────────────────────────────────────────────────
function exportFrida() {
  const code = scriptEditor ? scriptEditor.getValue() : '';
  const scriptType = $('script-type').value;
  let snippet = '';

  if (scriptType === 'frida') {
    snippet = `// Generated by PyUniDbg — Frida snippet
// Paste into: frida -U -f <package> -l script.js
'use strict';

${code}
`;
  } else {
    snippet = generateFridaFromPython(code);
  }

  const out = $('export-frida-output');
  out.style.display = 'block';
  out.textContent = snippet;
}

function generateFridaFromPython(pyCode) {
  const lines = pyCode.split('\n');
  const snippetParts = [];

  snippetParts.push(`// Generated by PyUniDbg — Frida snippet
// Converted from Python. Review and adjust as needed.
// Paste into: frida -U -f <package> -l script.js
'use strict';
`);

  const hookPattern = /hook_add_code\s*\(\s*(0x[0-9a-fA-F]+|[\w.]+)\s*,/;
  const funcAddrPattern = /get_function_address\s*\(\s*['"](\w+)['"]\s*\)/;
  const memReadPattern = /mem_read\s*\(\s*(0x[0-9a-fA-F]+)\s*,\s*(\d+)\s*\)/;
  const printPattern = /^\s*print\s*\(\s*(?:f?['"](.*?)['"]|(.+))\s*\)/;
  const interceptPattern = /Interceptor\.attach\s*\(/;

  let hasHooks = false;
  for (const line of lines) {
    const hookMatch = line.match(hookPattern);
    if (hookMatch) {
      hasHooks = true;
      const addr = hookMatch[1];
      const funcMatch = pyCode.match(new RegExp(`(\\w+)\\s*=\\s*module\\.get_function_address\\(['"](.+?)['"]\\)`));
      const funcName = funcMatch ? funcMatch[2] : null;

      if (funcName) {
        snippetParts.push(`// Hook: ${funcName}
const ${funcName}_addr = Module.findExportByName(null, '${funcName}');
if (${funcName}_addr) {
  Interceptor.attach(${funcName}_addr, {
    onEnter(args) {
      console.log('[*] ${funcName} called');
      console.log('    arg0:', args[0]);
      console.log('    arg1:', args[1]);
    },
    onLeave(retval) {
      console.log('[*] ${funcName} returned:', retval);
    }
  });
}
`);
      } else {
        snippetParts.push(`// Hook at address ${addr}
Interceptor.attach(ptr('${addr}'), {
  onEnter(args) {
    console.log('[*] Hit ${addr}');
    console.log('    arg0:', args[0]);
  },
  onLeave(retval) {
    console.log('[*] Return from ${addr}:', retval);
  }
});
`);
      }
    }

    if (interceptPattern.test(line)) {
      hasHooks = true;
    }
  }

  if (!hasHooks) {
    snippetParts.push(`// No hooks detected in source. Template for manual conversion:

// To hook a native function:
// const addr = Module.findExportByName('libnative.so', 'Java_com_example_func');
// Interceptor.attach(addr, {
//   onEnter(args) {
//     console.log('[*] Called with:', args[0], args[1]);
//   },
//   onLeave(retval) {
//     console.log('[*] Returned:', retval);
//   }
// });

// To hook a JNI function:
// Java.perform(function() {
//   const cls = Java.use('com.example.MyClass');
//   cls.myMethod.implementation = function(arg) {
//     console.log('[*] myMethod called with:', arg);
//     return this.myMethod(arg);
//   };
// });
`);
  }

  return snippetParts.join('\n');
}

function exportXposed() {
  const code = scriptEditor ? scriptEditor.getValue() : '';
  const pkg = $('xposed-package').value.trim() || 'com.example.target';
  const cls = $('xposed-classname').value.trim() || 'HookModule';

  const hookPattern = /hook_add_code\s*\(\s*(0x[0-9a-fA-F]+|[\w.]+)\s*,/g;
  const funcPattern = /get_function_address\s*\(\s*['"](\w+)['"]\s*\)/g;
  const javaUsePattern = /Java\.use\s*\(\s*['"]([^'"]+)['"]\s*\)/g;
  const javaMethodPattern = /\.(\w+)\.implementation\s*=/g;

  const hooks = [];
  let m;
  while ((m = funcPattern.exec(code)) !== null) hooks.push({ type: 'native', name: m[1] });
  while ((m = hookPattern.exec(code)) !== null) {
    if (!hooks.some(h => h.name === m[1])) hooks.push({ type: 'address', addr: m[1] });
  }

  const javaClasses = [];
  while ((m = javaUsePattern.exec(code)) !== null) javaClasses.push(m[1]);
  const javaMethods = [];
  while ((m = javaMethodPattern.exec(code)) !== null) javaMethods.push(m[1]);

  const hookBlocks = [];
  for (const h of hooks) {
    if (h.type === 'native') {
      hookBlocks.push(`
            // Native hook: ${h.name}
            // Use XposedBridge.hookMethod for Java methods that call this native
            // For direct native hooking, consider using native Xposed (libxposed_art)
            XposedBridge.log("${cls}: Would hook native ${h.name}");`);
    }
  }

  for (let i = 0; i < javaClasses.length; i++) {
    const jcls = javaClasses[i];
    const method = javaMethods[i] || 'targetMethod';
    hookBlocks.push(`
            // Hook ${jcls}.${method}
            final Class<?> cls${i} = XposedHelpers.findClass("${jcls}", lpparam.classLoader);
            XposedHelpers.findAndHookMethod(cls${i}, "${method}",
                /* parameter types: */ String.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        XposedBridge.log("${cls}: ${method} called, arg0=" + param.args[0]);
                    }
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        XposedBridge.log("${cls}: ${method} returned " + param.getResult());
                    }
                });`);
  }

  if (!hookBlocks.length) {
    hookBlocks.push(`
            // TODO: Add your hooks here
            // Example:
            // final Class<?> targetClass = XposedHelpers.findClass(
            //     "com.example.TargetClass", lpparam.classLoader);
            // XposedHelpers.findAndHookMethod(targetClass, "methodName",
            //     String.class, int.class,
            //     new XC_MethodHook() {
            //         @Override
            //         protected void beforeHookedMethod(MethodHookParam param) {
            //             XposedBridge.log("Method called: " + param.args[0]);
            //         }
            //     });`);
  }

  const javaCode = `// Generated by PyUniDbg — LSPosed/Xposed Module
// 1. Create an Android project with xposed-api dependency
// 2. Add this class and register it in assets/xposed_init
// 3. Build and install as an LSPosed/Xposed module

package ${pkg.split('.').slice(0, -1).join('.') || 'com.example'}.xposed;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class ${cls} implements IXposedHookLoadPackage {

    private static final String TARGET_PACKAGE = "${pkg}";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!lpparam.packageName.equals(TARGET_PACKAGE)) return;

        XposedBridge.log("${cls}: Hooking " + TARGET_PACKAGE);

        try {${hookBlocks.join('\n')}
        } catch (Throwable t) {
            XposedBridge.log("${cls}: Error setting up hooks");
            XposedBridge.log(t);
        }
    }
}

/*
 * === xposed_init ===
 * Create file: assets/xposed_init
 * Contents (single line):
 * ${pkg.split('.').slice(0, -1).join('.') || 'com.example'}.xposed.${cls}
 *
 * === build.gradle dependency ===
 * compileOnly 'de.robv.android.xposed:api:82'
 */`;

  const out = $('export-xposed-output');
  out.style.display = 'block';
  out.textContent = javaCode;
}

function copyExport(type) {
  const out = $(`export-${type === 'xposed' ? 'xposed' : 'frida'}-output`);
  if (!out || !out.textContent) { toast('Generate export first', 'error'); return; }
  navigator.clipboard.writeText(out.textContent);
  toast('Copied to clipboard', 'info');
}

// ── Helpers ───────────────────────────────────────────────────────────────
function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── Dirty state (unsaved changes) ─────────────────────────────────────────
let dirtyState = false;
let pendingSwitchSession = null;

function markDirty() {
  if (!dirtyState) {
    dirtyState = true;
    $('dirty-indicator').classList.add('visible');
    $('btn-save-project').classList.add('dirty');
  }
}

function markClean() {
  dirtyState = false;
  $('dirty-indicator').classList.remove('visible');
  $('btn-save-project').classList.remove('dirty');
}

window.addEventListener('beforeunload', e => {
  if (dirtyState) { e.preventDefault(); e.returnValue = ''; }
});

// Intercept session switches while dirty
function switchSessionGuarded(newId) {
  if (dirtyState && newId !== sessionId) {
    pendingSwitchSession = newId;
    openModal('modal-unsaved');
  } else {
    doSwitchSession(newId);
  }
}

async function discardAndSwitch() {
  markClean();
  closeModal('modal-unsaved');
  if (pendingSwitchSession) {
    doSwitchSession(pendingSwitchSession);
    pendingSwitchSession = null;
  }
}

async function saveProjectThenSwitch() {
  closeModal('modal-unsaved');
  await saveProject();
  if (pendingSwitchSession) {
    doSwitchSession(pendingSwitchSession);
    pendingSwitchSession = null;
  }
}

// ── Project save / load ──────────────────────────────────────────────────
async function saveProject() {
  if (!sessionId) { toast('No active session', 'error'); return; }
  try {
    const resp = await fetch(`/api/sessions/${sessionId}/project`);
    if (!resp.ok) { const e = await resp.json().catch(()=>({detail:'Failed'})); throw new Error(e.detail); }
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    const cd = resp.headers.get('Content-Disposition') || '';
    const name = (cd.match(/filename="(.+?)"/) || [])[1] || 'project.pyunidbg.json';
    const a = document.createElement('a');
    a.href = url; a.download = name; a.click();
    URL.revokeObjectURL(url);
    markClean();
    toast('Project saved', 'info');
    log('Project saved: ' + name, 'ok');
  } catch(e) { toast('Save failed: ' + e.message, 'error'); }
}

async function loadProject(event) {
  const file = event.target.files[0];
  if (!file || !sessionId) return;
  event.target.value = '';
  try {
    const form = new FormData();
    form.append('file', file);
    const r = await api('POST', `/api/sessions/${sessionId}/project`, form, true);
    toast(`Project loaded: patches=${r.data.restored.patches}, comments=${r.data.restored.comments}, hooks=${r.data.restored.hooks}`, 'info');
    log('Project loaded from ' + file.name, 'ok');
    markClean();
    await refreshPatches();
    await refreshComments();
    await refreshHooks();
    await refreshBreakpoints();
    await refreshDashboard();
  } catch(e) { toast('Load failed: ' + e.message, 'error'); }
}

// ── Patches ───────────────────────────────────────────────────────────────
async function refreshPatches() {
  if (!sessionId) return;
  try {
    const r = await get(`/api/sessions/${sessionId}/patches`);
    renderPatches(r.data || []);
  } catch(e) {}
}

function renderPatches(patches) {
  const el = $('patches-list');
  if (!patches.length) {
    el.innerHTML = '<div style="color:var(--text2);font-size:12px">No patches applied.</div>';
    return;
  }
  el.innerHTML = patches.map(p => `
    <div class="item-card" id="patch-card-${p.id}">
      <div class="item-card-info">
        <div class="item-card-name">${escHtml(p.label || p.id)}</div>
        <div class="item-card-addr">${p.address}</div>
        <div class="item-card-meta">
          Original: <span style="font-family:monospace;color:var(--text3)">${p.original_bytes||'?'}</span>
          &nbsp;→&nbsp;
          Patch: <span style="font-family:monospace;color:var(--yellow)">${p.patch_bytes}</span>
        </div>
      </div>
      <span class="badge ${p.enabled ? 'badge-green' : 'badge-red'}">${p.enabled ? 'Applied' : 'Reverted'}</span>
      <div class="item-card-actions">
        <button class="btn btn-ghost" style="font-size:11px;padding:3px 8px"
          onclick="togglePatch('${p.id}')">${p.enabled ? 'Revert' : 'Apply'}</button>
        <button class="btn btn-danger" style="font-size:11px;padding:3px 8px"
          onclick="removePatch('${p.id}')">Delete</button>
      </div>
    </div>`).join('');
}

async function togglePatch(patchId) {
  if (!sessionId) return;
  try {
    await put(`/api/sessions/${sessionId}/patches/${patchId}/toggle`, {});
    await refreshPatches();
    toast('Patch toggled', 'info');
  } catch(e) { toast(e.message, 'error'); }
}

async function removePatch(patchId) {
  if (!sessionId) return;
  try {
    await del(`/api/sessions/${sessionId}/patches/${patchId}`);
    await refreshPatches();
    toast('Patch removed', 'info');
    markDirty();
  } catch(e) { toast(e.message, 'error'); }
}

// Close the patch modal and jump to the Disassembly panel so the user can
// pick a row and click its "P" action — that comes back with a properly
// pre-filled address.
function jumpToDisasmFromPatch() {
  closeModal('modal-add-patch');
  const navEl = document.querySelector('.nav-btn[data-panel="disasm"]');
  switchPanel('disasm', navEl);
  activateSubTab('disasm', 'binary');
  toast('Click the "P" button next to the instruction you want to patch', 'info');
}

// Open the Add Patch modal pre-filled with a target address. If `addr` is
// empty we hint the user to pick one from the disassembly view rather than
// guessing — patching a random address is rarely what you want.
function openAddPatchFor(addr) {
  $('patch-addr-input').value = addr || '';
  $('patch-asm-input').value = '';
  $('patch-hex-input').value = '';
  $('patch-label-input').value = '';
  $('asm-preview').textContent = '';
  // If we have an address pre-fill, also disassemble around it so the
  // hex bytes from disasm are right next to the patch input.
  if (addr) {
    const inp = $('disasm-addr');
    if (inp) inp.value = addr;
    // Don't switch — the user came from disasm or scan, so the modal is
    // sufficient context. We only auto-disasm when the user opens "+ Add
    // Patch" from the patches panel without context.
  } else {
    toast('Tip: open the Disassembly tab and use the "P" button on a row to patch a precise instruction', 'info');
  }
  openModal('modal-add-patch');
}

async function previewAssembly() {
  if (!sessionId) { toast('Load a session first', 'error'); return; }
  const code = $('patch-asm-input').value.trim();
  const addrStr = $('patch-addr-input').value.trim() || '0';
  if (!code) { toast('Enter assembly code first', 'error'); return; }
  try {
    const r = await post(`/api/sessions/${sessionId}/assemble`, {code, address: addrStr});
    $('asm-preview').textContent = r.data.bytes_hex + ` (${r.data.length}B)`;
    $('patch-hex-input').value = r.data.bytes_hex;
  } catch(e) { $('asm-preview').textContent = ''; toast('Assembly error: ' + e.message, 'error'); }
}

async function submitPatch() {
  if (!sessionId) { toast('No active session', 'error'); return; }
  const addrStr = $('patch-addr-input').value.trim();
  const hexInput = $('patch-hex-input').value.trim().replace(/\s+/g, '');
  const label = $('patch-label-input').value.trim();
  if (!addrStr) { toast('Address is required', 'error'); return; }
  if (!hexInput) {
    // Try assembling first
    const asmCode = $('patch-asm-input').value.trim();
    if (!asmCode) { toast('Enter assembly code or hex bytes', 'error'); return; }
    try {
      const r = await post(`/api/sessions/${sessionId}/assemble`, {code: asmCode, address: addrStr});
      await submitPatchHex(addrStr, r.data.bytes_hex, label);
    } catch(e) { toast('Assembly failed: ' + e.message, 'error'); return; }
  } else {
    await submitPatchHex(addrStr, hexInput, label);
  }
}

async function submitPatchHex(addrStr, hex, label) {
  try {
    await post(`/api/sessions/${sessionId}/patches`, {address: addrStr, bytes_hex: hex, label});
    closeModal('modal-add-patch');
    $('patch-addr-input').value = '';
    $('patch-asm-input').value = '';
    $('patch-hex-input').value = '';
    $('patch-label-input').value = '';
    $('asm-preview').textContent = '';
    // Show the user the freshly-applied patch in the Patches list so they
    // can verify / revert / delete it without needing an extra click.
    const navEl = document.querySelector('.nav-btn[data-panel="patches"]');
    switchPanel('patches', navEl);
    activateSubTab('ptab', 'patches');
    await refreshPatches();
    toast('Patch applied', 'info');
    markDirty();
  } catch(e) { toast(e.message, 'error'); }
}

// ── Comments ─────────────────────────────────────────────────────────────
async function refreshComments() {
  if (!sessionId) return;
  try {
    const r = await get(`/api/sessions/${sessionId}/comments`);
    renderComments(r.data || []);
  } catch(e) {}
}

function renderComments(comments) {
  const el = $('comments-list');
  if (!comments.length) {
    el.innerHTML = '<div style="color:var(--text2);font-size:12px">No comments added.</div>';
    return;
  }
  el.innerHTML = comments.map(c => `
    <div class="item-card">
      <div class="item-card-info">
        <div class="item-card-addr">${c.address}</div>
        <div class="item-card-name" style="font-family:monospace;font-size:12px;white-space:pre-wrap">${escHtml(c.text)}</div>
      </div>
      <div class="item-card-actions">
        <button class="btn btn-danger" style="font-size:11px;padding:3px 8px"
          onclick="removeComment('${c.address}')">Delete</button>
      </div>
    </div>`).join('');
}

function openAddCommentModal(addr) {
  $('comment-addr-input').value = addr || '';
  $('comment-text-input').value = '';
  openModal('modal-add-comment');
}

async function submitComment() {
  if (!sessionId) return;
  const addrStr = $('comment-addr-input').value.trim();
  const text = $('comment-text-input').value.trim();
  if (!addrStr || !text) { toast('Address and text required', 'error'); return; }
  try {
    await post(`/api/sessions/${sessionId}/comments`, {address: addrStr, text});
    closeModal('modal-add-comment');
    // Land on the Patches & Comments panel so the new entry is visible
    // immediately — same flow we use for patches and hooks.
    const navEl = document.querySelector('.nav-btn[data-panel="patches"]');
    switchPanel('patches', navEl);
    activateSubTab('ptab', 'comments');
    await refreshComments();
    toast('Comment added', 'info');
    markDirty();
  } catch(e) { toast(e.message, 'error'); }
}

async function removeComment(addrStr) {
  if (!sessionId) return;
  const encAddr = encodeURIComponent(addrStr);
  try {
    await del(`/api/sessions/${sessionId}/comments/${encAddr}`);
    await refreshComments();
    toast('Comment removed', 'info');
    markDirty();
  } catch(e) { toast(e.message, 'error'); }
}

// ── Graph View ────────────────────────────────────────────────────────────
let cyInstance = null;
let currentGraphMode = 'cfg';

function setGraphMode(mode, el) {
  currentGraphMode = mode;
  document.querySelectorAll('.graph-mode-btn').forEach(b => b.classList.remove('active'));
  el.classList.add('active');
  $('graph-legend-cfg').style.display = mode === 'cfg' ? '' : 'none';
  $('graph-legend-callgraph').style.display = mode === 'callgraph' ? '' : 'none';
  $('graph-addr-input').style.display = mode === 'cfg' ? '' : 'none';
}

async function loadGraph() {
  if (!sessionId) { toast('No active session', 'error'); return; }
  $('graph-status').textContent = 'Building graph…';
  $('graph-placeholder').style.display = 'none';

  try {
    let graphData;
    if (currentGraphMode === 'cfg') {
      // If the user hasn't typed anything, fall back to the dynamically
      // computed default (first interesting export). We still respect any
      // value the user typed manually.
      let addrStr = $('graph-addr-input').value.trim();
      if (!addrStr) {
        await ensureBinSymbols();
        const fallback = pickDefaultFunctionAddr();
        if (fallback) {
          addrStr = fallback.address;
          $('graph-addr-input').value = addrStr;
          toast(`No address — defaulting to ${fallback.name}`, 'info');
        } else {
          toast('Enter a function address', 'error');
          $('graph-status').textContent = '';
          return;
        }
      }
      const r = await get(`/api/sessions/${sessionId}/cfg?address=${encodeURIComponent(addrStr)}&size=500`);
      graphData = r.data;
      $('graph-status').textContent = `CFG: ${graphData.nodes.length} blocks, ${graphData.edges.length} edges`;
      renderCFG(graphData);
    } else {
      const r = await get(`/api/sessions/${sessionId}/callgraph`);
      graphData = r.data;
      $('graph-status').textContent = `Call Graph: ${graphData.nodes.length} functions, ${graphData.edges.length} calls`;
      renderCallGraph(graphData);
    }
  } catch(e) {
    $('graph-status').textContent = 'Error: ' + e.message;
    toast(e.message, 'error');
    $('graph-placeholder').style.display = '';
  }
}

// Tag a call-graph node with a category so cytoscape can colour it
// distinctly. Without this every node is the same purple and the white
// labels overlap unreadably.
function _classifyCallgraphNode(n) {
  const name = n.name || '';
  if (n.type === 'jni' || /^Java_/.test(name) || name === 'JNI_OnLoad' || name === 'JNI_OnUnload') return 'jni';
  if (n.type === 'libc' || /^(malloc|free|memcpy|memset|strlen|strcpy|strcmp|sprintf|printf|fopen|open|read|write|close|mmap|getenv)/.test(name)) return 'libc';
  if (n.type === 'cpp' || /^_Z/.test(name)) return 'cpp';
  if (n.type === 'native' || n.type === 'export') return 'export';
  return 'internal';
}

function buildCyElements(nodes, edges, mode) {
  const cyNodes = nodes.map(n => {
    if (mode === 'cfg') {
      const label = n.instructions.map(i => `${i.address}  ${i.mnemonic} ${i.op_str}`).join('\n');
      return { data: { id: n.id, label, address: n.address, raw: n } };
    } else {
      return {
        data: {
          id: n.id,
          label: n.name,
          address: n.address,
          category: _classifyCallgraphNode(n),
        }
      };
    }
  });
  const cyEdges = edges.map((e, i) => ({
    data: {
      id: `e${i}`, source: e.from, target: e.to,
      type: e.type || 'call',
    }
  }));
  return [...cyNodes, ...cyEdges];
}

function initCytoscape(elements, mode) {
  if (cyInstance) { cyInstance.destroy(); cyInstance = null; }

  // Per-category palette for the call graph. CFG keeps its single colour
  // because every node is a basic block of the same function.
  const callgraphPalette = {
    jni:      { bg: '#c586c0', fg: '#1a0b1a' }, // purple
    libc:     { bg: '#4fc1ff', fg: '#06223a' }, // cyan
    cpp:      { bg: '#dcdcaa', fg: '#2b2b1a' }, // yellow
    export:   { bg: '#4ec9b0', fg: '#062a23' }, // green
    internal: { bg: '#9ca3af', fg: '#1a1a1a' }, // grey
  };

  const baseNodeStyle = mode === 'cfg' ? {
    'background-color': '#1e3a5f',
    'border-color': '#569cd6',
    'border-width': 1.5,
    'color': '#e6edf3',
    'shape': 'rectangle',
    'text-valign': 'center',
    'text-halign': 'center',
    'font-family': 'Courier New, monospace',
    'font-size': '10px',
    'text-wrap': 'wrap',
    'text-max-width': '320px',
    'width': 'label',
    'height': 'label',
    'padding': '10px',
    'label': 'data(label)',
  } : {
    // Call-graph: node is a small coloured pill, label sits OUTSIDE to the
    // right so descriptions never stack on top of each other.
    'background-color': callgraphPalette.internal.bg,
    'border-color': '#1e1e1e',
    'border-width': 1,
    'shape': 'round-rectangle',
    'width': '14px',
    'height': '14px',
    'label': 'data(label)',
    'color': '#d4d4d4',
    'font-size': '11px',
    'font-family': 'ui-monospace, Menlo, Consolas, monospace',
    'text-valign': 'center',
    'text-halign': 'right',
    'text-margin-x': 6,
    'text-background-color': '#1e1e1e',
    'text-background-opacity': 0.8,
    'text-background-padding': 2,
    'text-background-shape': 'roundrectangle',
  };

  const styleSheet = [
    { selector: 'node', style: baseNodeStyle },
    { selector: 'edge[type="cond"]',        style: { 'line-color': '#4ec9b0', 'target-arrow-color': '#4ec9b0', 'target-arrow-shape': 'triangle', 'curve-style': 'bezier', 'width': 1.5 } },
    { selector: 'edge[type="uncond"]',      style: { 'line-color': '#f14c4c', 'target-arrow-color': '#f14c4c', 'target-arrow-shape': 'triangle', 'curve-style': 'bezier', 'width': 1.5 } },
    { selector: 'edge[type="fallthrough"]', style: { 'line-color': '#555',    'target-arrow-color': '#555',    'target-arrow-shape': 'triangle', 'curve-style': 'bezier', 'width': 1, 'line-style': 'dashed' } },
    { selector: 'edge[type="call"]',        style: { 'line-color': '#6b7280', 'target-arrow-color': '#6b7280', 'target-arrow-shape': 'triangle', 'curve-style': 'bezier', 'width': 1 } },
    { selector: 'node:selected',            style: { 'border-color': '#007acc', 'border-width': 2 } },
  ];

  if (mode === 'callgraph') {
    Object.entries(callgraphPalette).forEach(([cat, c]) => {
      styleSheet.push({
        selector: `node[category="${cat}"]`,
        style: {
          'background-color': c.bg,
          'color': '#d4d4d4',
        },
      });
    });
  }

  cyInstance = cytoscape({
    container: $('cy'),
    elements,
    style: styleSheet,
    layout: {
      name: 'dagre',
      rankDir: mode === 'cfg' ? 'TB' : 'LR',
      nodeSep: mode === 'cfg' ? 20 : 14,
      rankSep: mode === 'cfg' ? 40 : 110,
      padding: 20,
      animate: false,
    },
    wheelSensitivity: 0.2,
  });

  cyInstance.on('tap', 'node', evt => {
    const addr = evt.target.data('address');
    if (addr) {
      const addrNum = parseInt(addr, 16);
      if (!isNaN(addrNum)) {
        $('disasm-addr').value = addr;
        switchPanel('disasm', document.querySelector('[data-panel=disasm]'));
        fetchDisasm();
      }
    }
  });
}

function renderCFG(graphData) {
  const elements = buildCyElements(graphData.nodes, graphData.edges, 'cfg');
  initCytoscape(elements, 'cfg');
}

function renderCallGraph(graphData) {
  const elements = buildCyElements(graphData.nodes, graphData.edges, 'callgraph');
  initCytoscape(elements, 'callgraph');
}

function cyFit() { if (cyInstance) cyInstance.fit(undefined, 20); }
function cyZoom(factor) { if (cyInstance) cyInstance.zoom(cyInstance.zoom() * factor); }

// ── AI Assistant ──────────────────────────────────────────────────────────
const AI_PROVIDERS = {
  openai:    { base: 'https://api.openai.com/v1', model: 'gpt-4o',          chat: '/chat/completions' },
  anthropic: { base: 'https://api.anthropic.com/v1', model: 'claude-3-5-sonnet-20241022', chat: '/messages' },
  ollama:    { base: 'http://localhost:11434/v1', model: 'llama3',           chat: '/chat/completions' },
  custom:    { base: '',                           model: '',                chat: '/chat/completions' },
};

let aiMessages = [];  // chat history

function onAIProviderChange() {
  const provider = $('ai-provider').value;
  const p = AI_PROVIDERS[provider];
  if (p) {
    $('ai-base-url').value = p.base;
    if (!$('ai-model').value || AI_PROVIDERS[Object.keys(AI_PROVIDERS).find(k => AI_PROVIDERS[k].model === $('ai-model').value)]) {
      $('ai-model').value = p.model;
    }
  }
}

function saveAIConfig() {
  localStorage.setItem('pyunidbg_ai', JSON.stringify({
    provider: $('ai-provider').value,
    model: $('ai-model').value,
    api_key: $('ai-api-key').value,
    base_url: $('ai-base-url').value,
  }));
  toast('AI config saved', 'info');
}

function loadAIConfig() {
  try {
    const saved = JSON.parse(localStorage.getItem('pyunidbg_ai') || '{}');
    if (saved.provider) $('ai-provider').value = saved.provider;
    if (saved.model) $('ai-model').value = saved.model;
    if (saved.api_key) $('ai-api-key').value = saved.api_key;
    if (saved.base_url) $('ai-base-url').value = saved.base_url;
    if (!$('ai-base-url').value) onAIProviderChange();
  } catch(e) { onAIProviderChange(); }
}

async function buildAIContext() {
  const parts = [];
  parts.push(`You are an expert reverse engineer and binary analysis assistant helping with PyUniDbg — a tool for emulating Android native libraries.`);
  if (sessionId) {
    try {
      const s = await get(`/api/sessions/${sessionId}`);
      const sd = s.data;
      parts.push(`\nSession: arch=${sd.arch}, api_level=${sd.api_level}, module=${sd.loaded_module||'none'}`);
    } catch(e) {}

    if ($('ctx-disasm').checked) {
      try {
        const disasmAddr = $('disasm-addr') && $('disasm-addr').value.trim();
        if (disasmAddr) {
          const r = await get(`/api/sessions/${sessionId}/disasm?address=${encodeURIComponent(disasmAddr)}&count=30`);
          const lines = (r.data||[]).map(i => `${i.address}  ${i.mnemonic} ${i.op_str}`).join('\n');
          parts.push(`\nCurrent disassembly:\n\`\`\`asm\n${lines}\n\`\`\``);
        }
      } catch(e) {}
    }
    if ($('ctx-regs').checked) {
      try {
        const r = await get(`/api/sessions/${sessionId}/registers`);
        const regStr = Object.entries(r.data||{}).map(([k,v])=>`${k}=${v}`).join('  ');
        parts.push(`\nRegisters: ${regStr}`);
      } catch(e) {}
    }
    if ($('ctx-memmap').checked) {
      try {
        const r = await get(`/api/sessions/${sessionId}/memory/map`);
        const mapStr = (r.data||[]).map(m=>`${m.start}-${m.end} ${m.perms}`).join('\n');
        parts.push(`\nMemory map:\n${mapStr}`);
      } catch(e) {}
    }
    if ($('ctx-patches').checked) {
      try {
        const r = await get(`/api/sessions/${sessionId}/patches`);
        if ((r.data||[]).length) {
          const pStr = r.data.map(p=>`${p.address}: ${p.patch_bytes} (${p.label||''})`).join('\n');
          parts.push(`\nActive patches:\n${pStr}`);
        }
        const rc = await get(`/api/sessions/${sessionId}/comments`);
        if ((rc.data||[]).length) {
          const cStr = rc.data.map(c=>`${c.address}: ${c.text}`).join('\n');
          parts.push(`\nAnalyst comments:\n${cStr}`);
        }
      } catch(e) {}
    }
    if ($('ctx-hooks').checked) {
      try {
        const r = await get(`/api/sessions/${sessionId}/hooks`);
        if ((r.data||[]).length) {
          const hStr = r.data.map(h=>`${h.address} (${h.name})`).join('\n');
          parts.push(`\nHooks:\n${hStr}`);
        }
      } catch(e) {}
    }
  }
  return parts.join('\n');
}

function appendAIMessage(role, text) {
  const body = $('ai-chat-body');
  const div = document.createElement('div');
  div.className = `ai-msg ${role}`;
  div.textContent = text;
  if (role === 'assistant') {
    const btn = document.createElement('button');
    btn.className = 'ai-msg-copy';
    btn.textContent = 'Copy';
    btn.onclick = () => { navigator.clipboard.writeText(text); toast('Copied', 'info'); };
    div.appendChild(btn);
  }
  body.appendChild(div);
  body.scrollTop = body.scrollHeight;
  return div;
}

async function sendAIMessage() {
  const input = $('ai-input');
  const userText = input.value.trim();
  if (!userText) return;

  const apiKey = $('ai-api-key').value.trim();
  const model = $('ai-model').value.trim();
  const baseUrl = $('ai-base-url').value.trim().replace(/\/$/, '');
  const provider = $('ai-provider').value;

  if (!apiKey && provider !== 'ollama') { toast('Enter an API key first', 'error'); return; }
  if (!model) { toast('Enter a model name', 'error'); return; }

  input.value = '';
  appendAIMessage('user', userText);

  const thinkEl = document.createElement('div');
  thinkEl.className = 'ai-thinking';
  thinkEl.textContent = 'Thinking…';
  $('ai-chat-body').appendChild(thinkEl);
  $('ai-chat-body').scrollTop = $('ai-chat-body').scrollHeight;

  // Build context on first message or on demand
  const systemPrompt = await buildAIContext();
  aiMessages.push({ role: 'user', content: userText });

  try {
    let responseText = '';

    if (provider === 'anthropic') {
      const resp = await fetch(`${baseUrl}/messages`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true',
        },
        body: JSON.stringify({
          model,
          max_tokens: 4096,
          system: systemPrompt,
          messages: aiMessages,
        }),
      });
      if (!resp.ok) { const e = await resp.json().catch(()=>({error:{message:'API error'}})); throw new Error(e.error?.message || resp.statusText); }
      const data = await resp.json();
      responseText = data.content?.[0]?.text || '';
    } else {
      // OpenAI-compatible (openai, ollama, custom)
      const messages = [{ role: 'system', content: systemPrompt }, ...aiMessages];
      const resp = await fetch(`${baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({ model, messages, max_tokens: 4096 }),
      });
      if (!resp.ok) { const e = await resp.json().catch(()=>({error:{message:'API error'}})); throw new Error(e.error?.message || resp.statusText); }
      const data = await resp.json();
      responseText = data.choices?.[0]?.message?.content || '';
    }

    thinkEl.remove();
    aiMessages.push({ role: 'assistant', content: responseText });
    appendAIMessage('assistant', responseText);

  } catch(e) {
    thinkEl.remove();
    const errDiv = document.createElement('div');
    errDiv.className = 'ai-msg error-msg';
    errDiv.textContent = 'Error: ' + e.message;
    $('ai-chat-body').appendChild(errDiv);
    $('ai-chat-body').scrollTop = $('ai-chat-body').scrollHeight;
    toast('AI error: ' + e.message, 'error');
  }
}

function clearAIChat() {
  aiMessages = [];
  const body = $('ai-chat-body');
  body.innerHTML = '<div class="ai-msg assistant">Chat cleared. Ask me anything about the binary.</div>';
}

// ── Init ──────────────────────────────────────────────────────────────────
async function init() {
  initTerminal();
  initScriptEditor();
  loadAIConfig();
  onAIProviderChange();
  restoreTerminalCollapsed();

  // Load version/config in background
  loadConfig();

  // Auto-create a session
  try {
    const r = await get('/api/sessions');
    if (r.data && r.data.length) {
      sessionId = r.data[0].session_id;
      await refreshSessionList();
      connectWS();
      log('Resumed existing session: ' + sessionId.slice(0,8), 'ok');
    } else {
      await createSession();
    }
  } catch(e) {
    log('Could not connect to server. Is it running?', 'error');
    toast('Server connection failed', 'error');
  }
}

init();
