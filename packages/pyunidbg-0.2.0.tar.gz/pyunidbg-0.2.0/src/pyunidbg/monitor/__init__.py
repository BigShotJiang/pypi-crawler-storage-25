"""
API Monitor - Log and analyze all API calls during emulation.

Provides comprehensive API call logging including:
- Function entry/exit logging
- Argument capture and formatting
- Return value tracking
- Call statistics and frequency analysis
- Export to various formats

Usage:
    from pyunidbg.monitor import APIMonitor
    
    monitor = APIMonitor(emulator)
    
    # Monitor specific functions
    monitor.add_function("open", signature="int open(const char *path, int flags)")
    monitor.add_function("read", signature="ssize_t read(int fd, void *buf, size_t count)")
    
    # Or monitor all exports from a library
    monitor.add_library("libc.so")
    
    # Start monitoring
    monitor.start()
    
    # Run emulation...
    emu.call(some_function)
    
    # Stop and get results
    monitor.stop()
    
    # Print call log
    monitor.print_log()
    
    # Export to JSON
    monitor.export_json("api_calls.json")
    
    # Get statistics
    stats = monitor.get_stats()
"""

from __future__ import annotations

import json
import logging
import time
from abc import ABC, abstractmethod
from collections import defaultdict
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from enum import Enum, auto
from functools import wraps
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    List,
    Optional,
    Set,
    Tuple,
    Union,
)

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator

__all__ = [
    "APIMonitor",
    "APICall",
    "FunctionSignature",
    "ArgumentType",
    "CallFilter",
    "CallStats",
    "create_monitor",
]

logger = logging.getLogger(__name__)


# ==================== Argument Types ====================

class ArgumentType(Enum):
    """Types of function arguments for formatting."""
    INT = "int"
    UINT = "uint"
    LONG = "long"
    ULONG = "ulong"
    SIZE_T = "size_t"
    SSIZE_T = "ssize_t"
    POINTER = "pointer"
    STRING = "string"
    WSTRING = "wstring"
    BUFFER = "buffer"
    FD = "fd"
    FLAGS = "flags"
    STRUCT = "struct"
    VOID = "void"
    BOOL = "bool"
    FLOAT = "float"
    DOUBLE = "double"


# ==================== Function Signature ====================

@dataclass
class ArgumentInfo:
    """Information about a function argument."""
    name: str
    type: ArgumentType
    size: int = 0  # For buffers
    format_func: Callable[[Any], str] | None = None

    def format_value(self, value: Any, emulator: Emulator) -> str:
        """Format argument value for display."""
        if self.format_func:
            return self.format_func(value)

        if self.type == ArgumentType.STRING:
            try:
                if value != 0:
                    return f'"{emulator.read_string(value)}"'
                return "NULL"
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                return f"<invalid string at {value:#x}>"

        elif self.type == ArgumentType.WSTRING:
            try:
                if value != 0:
                    # Read wide string
                    data = emulator.memory.read(value, 512)
                    # Decode as UTF-16LE
                    end = data.find(b'\x00\x00')
                    if end > 0:
                        data = data[:end+1]
                    return f'L"{data.decode("utf-16-le", errors="replace")}"'
                return "NULL"
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                return f"<invalid wstring at {value:#x}>"

        elif self.type == ArgumentType.POINTER:
            if value == 0:
                return "NULL"
            return f"{value:#x}"

        elif self.type == ArgumentType.BUFFER:
            if value == 0:
                return "NULL"
            size = min(self.size, 32) if self.size > 0 else 16
            try:
                data = emulator.memory.read(value, size)
                hex_str = data.hex()
                if len(hex_str) > 32:
                    hex_str = hex_str[:32] + "..."
                return f"[{hex_str}]"
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                return f"<buffer at {value:#x}>"

        elif self.type == ArgumentType.FD:
            return f"fd={value}"

        elif self.type == ArgumentType.FLAGS:
            return f"{value:#x}"

        elif self.type in (ArgumentType.INT, ArgumentType.LONG, ArgumentType.SSIZE_T):
            # Signed
            if value & (1 << 31):  # Check sign bit for 32-bit
                value = value - (1 << 32)
            return str(value)

        elif self.type == ArgumentType.BOOL:
            return "true" if value else "false"

        else:
            return f"{value}"


@dataclass
class FunctionSignature:
    """Signature of a monitored function."""
    name: str
    return_type: ArgumentType = ArgumentType.INT
    arguments: list[ArgumentInfo] = field(default_factory=list)
    library: str | None = None
    address: int | None = None
    calling_convention: str = "cdecl"

    @classmethod
    def parse(cls, signature: str, library: str | None = None) -> FunctionSignature:
        """
        Parse a C-style function signature.
        
        Examples:
            "int open(const char *path, int flags, mode_t mode)"
            "void *malloc(size_t size)"
            "ssize_t read(int fd, void *buf, size_t count)"
        """
        import re

        # Match: return_type function_name(args)
        pattern = r'^\s*(\w+(?:\s*\*)?)\s+(\w+)\s*\((.*)\)\s*$'
        match = re.match(pattern, signature.strip())

        if not match:
            # Simple case: just function name
            return cls(name=signature.strip(), library=library)

        return_type_str, name, args_str = match.groups()

        # Parse return type
        return_type = cls._parse_type(return_type_str)

        # Parse arguments
        arguments = []
        if args_str.strip() and args_str.strip() != "void":
            for arg in args_str.split(","):
                arg = arg.strip()
                if not arg:
                    continue

                # Parse "type name" or "type *name"
                parts = arg.rsplit(None, 1)
                if len(parts) == 2:
                    type_str, arg_name = parts
                    arg_name = arg_name.lstrip("*")
                else:
                    type_str = parts[0]
                    arg_name = f"arg{len(arguments)}"

                arg_type = cls._parse_type(type_str)
                arguments.append(ArgumentInfo(name=arg_name, type=arg_type))

        return cls(
            name=name,
            return_type=return_type,
            arguments=arguments,
            library=library
        )

    @staticmethod
    def _parse_type(type_str: str) -> ArgumentType:
        """Parse a type string to ArgumentType."""
        type_str = type_str.strip().lower()

        # Remove const/volatile
        type_str = type_str.replace("const", "").replace("volatile", "").strip()

        # Check for pointer
        if "*" in type_str:
            base_type = type_str.replace("*", "").strip()
            if base_type in ("char", "wchar_t"):
                return ArgumentType.WSTRING if "wchar" in base_type else ArgumentType.STRING
            return ArgumentType.POINTER

        # Map common types
        type_map = {
            "int": ArgumentType.INT,
            "unsigned int": ArgumentType.UINT,
            "uint": ArgumentType.UINT,
            "long": ArgumentType.LONG,
            "unsigned long": ArgumentType.ULONG,
            "ulong": ArgumentType.ULONG,
            "size_t": ArgumentType.SIZE_T,
            "ssize_t": ArgumentType.SSIZE_T,
            "void": ArgumentType.VOID,
            "bool": ArgumentType.BOOL,
            "_bool": ArgumentType.BOOL,
            "float": ArgumentType.FLOAT,
            "double": ArgumentType.DOUBLE,
        }

        return type_map.get(type_str, ArgumentType.INT)

    def format_call(self, args: list[int], emulator: Emulator) -> str:
        """Format a function call with arguments."""
        formatted_args = []
        for i, arg_value in enumerate(args):
            if i < len(self.arguments):
                arg_info = self.arguments[i]
                formatted = f"{arg_info.name}={arg_info.format_value(arg_value, emulator)}"
            else:
                formatted = f"arg{i}={arg_value:#x}"
            formatted_args.append(formatted)

        return f"{self.name}({', '.join(formatted_args)})"

    def format_return(self, value: int, emulator: Emulator) -> str:
        """Format a return value."""
        arg_info = ArgumentInfo(name="return", type=self.return_type)
        return arg_info.format_value(value, emulator)


# ==================== API Call Record ====================

@dataclass
class APICall:
    """Record of a single API call."""
    function: str
    address: int
    caller: int
    arguments: list[int]
    formatted_args: str
    timestamp: float
    thread_id: int = 0
    return_value: int | None = None
    formatted_return: str | None = None
    duration: float = 0.0
    call_depth: int = 0
    library: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "function": self.function,
            "address": hex(self.address),
            "caller": hex(self.caller),
            "arguments": [hex(a) for a in self.arguments],
            "formatted_args": self.formatted_args,
            "timestamp": self.timestamp,
            "thread_id": self.thread_id,
            "return_value": hex(self.return_value) if self.return_value is not None else None,
            "formatted_return": self.formatted_return,
            "duration": self.duration,
            "call_depth": self.call_depth,
            "library": self.library,
        }

    def __str__(self) -> str:
        indent = "  " * self.call_depth
        ret = f" => {self.formatted_return}" if self.formatted_return else ""
        return f"{indent}{self.formatted_args}{ret}"


# ==================== Call Statistics ====================

@dataclass
class FunctionStats:
    """Statistics for a single function."""
    name: str
    call_count: int = 0
    total_time: float = 0.0
    min_time: float = float('inf')
    max_time: float = 0.0
    unique_callers: set[int] = field(default_factory=set)
    return_values: dict[int, int] = field(default_factory=lambda: defaultdict(int))

    @property
    def avg_time(self) -> float:
        return self.total_time / self.call_count if self.call_count > 0 else 0.0


@dataclass
class CallStats:
    """Overall call statistics."""
    total_calls: int = 0
    unique_functions: int = 0
    total_time: float = 0.0
    start_time: float = 0.0
    end_time: float = 0.0
    functions: dict[str, FunctionStats] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_calls": self.total_calls,
            "unique_functions": self.unique_functions,
            "total_time": self.total_time,
            "duration": self.end_time - self.start_time,
            "functions": {
                name: {
                    "call_count": stats.call_count,
                    "avg_time": stats.avg_time,
                    "total_time": stats.total_time,
                    "unique_callers": len(stats.unique_callers),
                }
                for name, stats in self.functions.items()
            }
        }


# ==================== Call Filter ====================

@dataclass
class CallFilter:
    """Filter for API calls."""
    include_functions: set[str] | None = None
    exclude_functions: set[str] | None = None
    include_libraries: set[str] | None = None
    exclude_libraries: set[str] | None = None
    min_call_depth: int = 0
    max_call_depth: int = 100

    def matches(self, call: APICall) -> bool:
        """Check if a call matches this filter."""
        # Function filter
        if self.include_functions and call.function not in self.include_functions:
            return False
        if self.exclude_functions and call.function in self.exclude_functions:
            return False

        # Library filter
        if self.include_libraries and call.library not in self.include_libraries:
            return False
        if self.exclude_libraries and call.library in self.exclude_libraries:
            return False

        # Depth filter
        if call.call_depth < self.min_call_depth or call.call_depth > self.max_call_depth:
            return False

        return True


# ==================== Main API Monitor Class ====================

class APIMonitor:
    """
    Monitor and log API calls during emulation.
    
    Features:
    - Automatic argument formatting
    - Return value tracking
    - Call depth tracking
    - Statistics collection
    - Export to JSON/HTML/text
    """

    def __init__(self, emulator: Emulator):
        self._emulator = emulator
        self._signatures: dict[str, FunctionSignature] = {}
        self._address_to_sig: dict[int, FunctionSignature] = {}
        self._calls: list[APICall] = []
        self._call_stack: list[APICall] = []
        self._stats = CallStats()
        self._running = False
        self._filter: CallFilter | None = None
        self._hooks: list[Any] = []
        self._max_calls = 100000
        self._on_call_callback: Callable[[APICall], None] | None = None

        # Common libc signatures
        self._init_common_signatures()

    def _init_common_signatures(self) -> None:
        """Initialize common libc function signatures."""
        common_sigs = [
            # File operations
            "int open(const char *path, int flags, int mode)",
            "int close(int fd)",
            "ssize_t read(int fd, void *buf, size_t count)",
            "ssize_t write(int fd, void *buf, size_t count)",
            "off_t lseek(int fd, off_t offset, int whence)",
            "int stat(const char *path, void *buf)",
            "int fstat(int fd, void *buf)",
            "int access(const char *path, int mode)",
            "int unlink(const char *path)",
            "int rename(const char *old, const char *new)",
            "void *mmap(void *addr, size_t len, int prot, int flags, int fd, off_t offset)",
            "int munmap(void *addr, size_t len)",

            # Memory
            "void *malloc(size_t size)",
            "void *calloc(size_t nmemb, size_t size)",
            "void *realloc(void *ptr, size_t size)",
            "void free(void *ptr)",
            "void *memcpy(void *dest, void *src, size_t n)",
            "void *memmove(void *dest, void *src, size_t n)",
            "void *memset(void *s, int c, size_t n)",
            "int memcmp(void *s1, void *s2, size_t n)",

            # String
            "size_t strlen(const char *s)",
            "char *strcpy(char *dest, const char *src)",
            "char *strncpy(char *dest, const char *src, size_t n)",
            "int strcmp(const char *s1, const char *s2)",
            "int strncmp(const char *s1, const char *s2, size_t n)",
            "char *strcat(char *dest, const char *src)",
            "char *strchr(const char *s, int c)",
            "char *strstr(const char *haystack, const char *needle)",
            "char *strdup(const char *s)",

            # Process
            "int fork(void)",
            "int execve(const char *path, void *argv, void *envp)",
            "int getpid(void)",
            "int getppid(void)",
            "int getuid(void)",
            "int geteuid(void)",

            # Network
            "int socket(int domain, int type, int protocol)",
            "int connect(int sockfd, void *addr, int addrlen)",
            "int bind(int sockfd, void *addr, int addrlen)",
            "int listen(int sockfd, int backlog)",
            "int accept(int sockfd, void *addr, void *addrlen)",
            "ssize_t send(int sockfd, void *buf, size_t len, int flags)",
            "ssize_t recv(int sockfd, void *buf, size_t len, int flags)",

            # Time
            "int time(void *t)",
            "int gettimeofday(void *tv, void *tz)",
            "int clock_gettime(int clk_id, void *tp)",

            # Other
            "int printf(const char *format)",
            "int sprintf(char *str, const char *format)",
            "int snprintf(char *str, size_t size, const char *format)",
            "void exit(int status)",
            "void _exit(int status)",
            "int atexit(void *func)",
            "void *dlopen(const char *filename, int flags)",
            "void *dlsym(void *handle, const char *symbol)",
            "int dlclose(void *handle)",
            "char *dlerror(void)",
        ]

        for sig in common_sigs:
            parsed = FunctionSignature.parse(sig, library="libc.so")
            self._signatures[parsed.name] = parsed

    def add_function(
        self,
        name: str,
        signature: str | None = None,
        address: int | None = None,
        library: str | None = None,
    ) -> None:
        """
        Add a function to monitor.
        
        Args:
            name: Function name
            signature: C-style signature (e.g., "int func(int a, char *b)")
            address: Function address (if known)
            library: Library name
        """
        if signature:
            sig = FunctionSignature.parse(signature, library)
        elif name in self._signatures:
            sig = self._signatures[name]
        else:
            sig = FunctionSignature(name=name, library=library)

        if address:
            sig.address = address
            self._address_to_sig[address] = sig

        self._signatures[name] = sig
        logger.debug(f"Added function monitor: {name}")

    def add_library(self, library_name: str) -> int:
        """
        Add all exported functions from a library to monitor.
        
        Returns:
            Number of functions added
        """
        count = 0

        # Get loaded module
        for module in self._emulator._modules.values():
            if module.name == library_name or library_name in str(module.path):
                for sym in module.symbols.values():
                    if sym.is_function and sym.is_exported:
                        self.add_function(
                            name=sym.name,
                            address=sym.address,
                            library=module.name
                        )
                        count += 1
                break

        logger.info(f"Added {count} functions from {library_name}")
        return count

    def set_filter(self, filter_: CallFilter) -> None:
        """Set a filter for logged calls."""
        self._filter = filter_

    def set_callback(self, callback: Callable[[APICall], None]) -> None:
        """Set a callback for each API call."""
        self._on_call_callback = callback

    def start(self) -> None:
        """Start monitoring API calls."""
        if self._running:
            return

        self._running = True
        self._stats.start_time = time.time()

        # Setup hooks for all monitored functions
        for sig in self._signatures.values():
            if sig.address:
                self._setup_hook(sig)
            else:
                # Try to resolve address
                addr = self._resolve_function(sig.name, sig.library)
                if addr:
                    sig.address = addr
                    self._setup_hook(sig)

        logger.info("API monitoring started")

    def stop(self) -> None:
        """Stop monitoring API calls."""
        if not self._running:
            return

        self._running = False
        self._stats.end_time = time.time()

        # Remove hooks
        for hook in self._hooks:
            try:
                self._emulator.hook.remove_hook(hook)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        self._hooks.clear()

        logger.info(f"API monitoring stopped. {len(self._calls)} calls recorded.")

    def _setup_hook(self, sig: FunctionSignature) -> None:
        """Setup entry/exit hooks for a function."""
        if not sig.address:
            return

        @self._emulator.hook.address(sig.address)
        def on_entry(emu, address, size):
            self._on_function_entry(sig, address)

        self._hooks.append(on_entry)

    def _resolve_function(self, name: str, library: str | None = None) -> int | None:
        """Resolve function address by name."""
        for module in self._emulator._modules.values():
            if library and library not in module.name:
                continue

            addr = module.get_function_address(name)
            if addr:
                return addr

        return None

    def _on_function_entry(self, sig: FunctionSignature, address: int) -> None:
        """Called when entering a monitored function."""
        if not self._running:
            return

        if len(self._calls) >= self._max_calls:
            return

        # Get arguments based on calling convention
        args = self._get_arguments(len(sig.arguments))

        # Get caller address
        caller = self._emulator.cpu.lr

        # Create call record
        call = APICall(
            function=sig.name,
            address=address,
            caller=caller,
            arguments=args,
            formatted_args=sig.format_call(args, self._emulator),
            timestamp=time.time(),
            thread_id=0,  # TODO: Get thread ID if available
            call_depth=len(self._call_stack),
            library=sig.library,
        )

        # Apply filter
        if self._filter and not self._filter.matches(call):
            return

        # Push to call stack
        self._call_stack.append(call)

        # Update stats
        self._update_stats_entry(call)

    def _on_function_exit(self, sig: FunctionSignature, return_value: int) -> None:
        """Called when exiting a monitored function."""
        if not self._call_stack:
            return

        call = self._call_stack.pop()

        # Update call with return info
        call.return_value = return_value
        call.formatted_return = sig.format_return(return_value, self._emulator)
        call.duration = time.time() - call.timestamp

        # Add to recorded calls
        self._calls.append(call)

        # Update stats
        self._update_stats_exit(call)

        # Callback
        if self._on_call_callback:
            self._on_call_callback(call)

    def _get_arguments(self, count: int) -> list[int]:
        """Get function arguments from registers."""
        args = []

        if self._emulator.is_64bit:
            # ARM64: X0-X7
            regs = ["x0", "x1", "x2", "x3", "x4", "x5", "x6", "x7"]
        else:
            # ARM32: R0-R3, then stack
            regs = ["r0", "r1", "r2", "r3"]

        for i in range(min(count, len(regs))):
            args.append(self._emulator.cpu.get_reg(regs[i]))

        # Additional args from stack
        for i in range(len(regs), count):
            sp = self._emulator.cpu.sp
            offset = (i - len(regs)) * self._emulator.pointer_size
            try:
                if self._emulator.is_64bit:
                    args.append(self._emulator.memory.read_u64(sp + offset))
                else:
                    args.append(self._emulator.memory.read_u32(sp + offset))
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                args.append(0)

        return args

    def _update_stats_entry(self, call: APICall) -> None:
        """Update statistics on function entry."""
        self._stats.total_calls += 1

        if call.function not in self._stats.functions:
            self._stats.functions[call.function] = FunctionStats(name=call.function)
            self._stats.unique_functions += 1

        stats = self._stats.functions[call.function]
        stats.call_count += 1
        stats.unique_callers.add(call.caller)

    def _update_stats_exit(self, call: APICall) -> None:
        """Update statistics on function exit."""
        if call.function not in self._stats.functions:
            return

        stats = self._stats.functions[call.function]
        stats.total_time += call.duration
        stats.min_time = min(stats.min_time, call.duration)
        stats.max_time = max(stats.max_time, call.duration)

        if call.return_value is not None:
            stats.return_values[call.return_value] += 1

    # ==================== Query Methods ====================

    def get_calls(self, filter_: CallFilter | None = None) -> list[APICall]:
        """Get all recorded calls, optionally filtered."""
        if filter_:
            return [c for c in self._calls if filter_.matches(c)]
        return list(self._calls)

    def get_calls_by_function(self, function_name: str) -> list[APICall]:
        """Get all calls to a specific function."""
        return [c for c in self._calls if c.function == function_name]

    def get_calls_by_library(self, library_name: str) -> list[APICall]:
        """Get all calls to functions in a library."""
        return [c for c in self._calls if c.library == library_name]

    def get_stats(self) -> CallStats:
        """Get call statistics."""
        return self._stats

    def get_call_count(self) -> int:
        """Get total number of recorded calls."""
        return len(self._calls)

    def get_unique_functions(self) -> list[str]:
        """Get list of unique function names called."""
        return list(set(c.function for c in self._calls))

    def get_call_graph(self) -> dict[str, set[str]]:
        """Get call graph as adjacency list."""
        graph: dict[str, set[str]] = defaultdict(set)

        for call in self._calls:
            # Find caller function
            caller_func = None
            for sig in self._signatures.values():
                if sig.address and sig.address <= call.caller:
                    caller_func = sig.name

            if caller_func:
                graph[caller_func].add(call.function)

        return dict(graph)

    # ==================== Output Methods ====================

    def print_log(self, max_calls: int = 100, file=None) -> None:
        """Print call log to console or file."""
        import sys
        out = file or sys.stdout

        for call in self._calls[:max_calls]:
            print(call, file=out)

        if len(self._calls) > max_calls:
            print(f"... and {len(self._calls) - max_calls} more calls", file=out)

    def print_stats(self, file=None) -> None:
        """Print call statistics."""
        import sys
        out = file or sys.stdout

        print(f"\n{'='*60}", file=out)
        print("API Call Statistics", file=out)
        print(f"{'='*60}", file=out)
        print(f"Total calls: {self._stats.total_calls}", file=out)
        print(f"Unique functions: {self._stats.unique_functions}", file=out)
        print(f"Duration: {self._stats.end_time - self._stats.start_time:.3f}s", file=out)
        print("\nTop functions by call count:", file=out)

        sorted_funcs = sorted(
            self._stats.functions.values(),
            key=lambda f: f.call_count,
            reverse=True
        )[:10]

        for func in sorted_funcs:
            print(f"  {func.name}: {func.call_count} calls", file=out)

    def export_json(self, path: str | Path) -> None:
        """Export calls to JSON file."""
        data = {
            "calls": [c.to_dict() for c in self._calls],
            "stats": self._stats.to_dict(),
        }

        Path(path).write_text(json.dumps(data, indent=2))
        logger.info(f"Exported {len(self._calls)} calls to {path}")

    def export_html(self, path: str | Path) -> None:
        """Export calls to HTML file."""
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>PyUniDbg API Monitor Report</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; margin: 20px; }}
        h1 {{ color: #333; }}
        table {{ border-collapse: collapse; width: 100%; margin-top: 20px; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #4CAF50; color: white; }}
        tr:nth-child(even) {{ background-color: #f2f2f2; }}
        tr:hover {{ background-color: #ddd; }}
        .stats {{ background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .address {{ font-family: monospace; color: #666; }}
        .return-ok {{ color: green; }}
        .return-error {{ color: red; }}
    </style>
</head>
<body>
    <h1>🔍 API Monitor Report</h1>
    
    <div class="stats">
        <h2>Statistics</h2>
        <p>Total calls: {self._stats.total_calls}</p>
        <p>Unique functions: {self._stats.unique_functions}</p>
        <p>Duration: {self._stats.end_time - self._stats.start_time:.3f}s</p>
    </div>
    
    <h2>Call Log</h2>
    <table>
        <tr>
            <th>#</th>
            <th>Function</th>
            <th>Arguments</th>
            <th>Return</th>
            <th>Caller</th>
            <th>Duration</th>
        </tr>
"""

        for i, call in enumerate(self._calls[:1000]):  # Limit to 1000 calls
            ret_class = "return-ok" if call.return_value and call.return_value >= 0 else "return-error"
            html += f"""        <tr>
            <td>{i+1}</td>
            <td>{call.function}</td>
            <td><code>{call.formatted_args}</code></td>
            <td class="{ret_class}">{call.formatted_return or ''}</td>
            <td class="address">{call.caller:#x}</td>
            <td>{call.duration*1000:.2f}ms</td>
        </tr>
"""

        html += """    </table>
</body>
</html>"""

        Path(path).write_text(html)
        logger.info(f"Exported HTML report to {path}")

    def export_text(self, path: str | Path) -> None:
        """Export calls to plain text file."""
        with open(path, 'w') as f:
            self.print_log(max_calls=len(self._calls), file=f)
            f.write("\n")
            self.print_stats(file=f)

    def clear(self) -> None:
        """Clear all recorded calls."""
        self._calls.clear()
        self._call_stack.clear()
        self._stats = CallStats()


# ==================== Factory Function ====================

def create_monitor(emulator: Emulator, **kwargs) -> APIMonitor:
    """
    Create an API monitor for the emulator.
    
    Args:
        emulator: Emulator instance
        **kwargs: Additional configuration
    
    Returns:
        Configured APIMonitor instance
    """
    monitor = APIMonitor(emulator)

    if kwargs.get("monitor_libc", True):
        # Add common libc functions (already initialized)
        pass

    if kwargs.get("auto_start", False):
        monitor.start()

    return monitor
