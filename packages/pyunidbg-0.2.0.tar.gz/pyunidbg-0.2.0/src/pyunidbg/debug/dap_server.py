"""
Debug Adapter Protocol (DAP) Server for PyUniDbg.

Implements the Debug Adapter Protocol used by VS Code, allowing
remote debugging of emulated code from the VS Code debugger UI.

Also provides enhanced LLDB compatibility via the existing GDB RSP
server with LLDB-specific extensions (qHostInfo, jThreadsInfo, etc.).

Features:
- Full DAP lifecycle (initialize, launch/attach, threads, stackTrace, etc.)
- Breakpoints, stepping, continue, pause
- Variable inspection (registers, memory, locals)
- Disassembly view
- Evaluate expressions
- LLDB-compatible extensions for the GDB server

Usage — VS Code DAP:
    from pyunidbg.debug.dap_server import DAPServer

    dap = DAPServer(emulator, port=4711)
    dap.start()
    # Connect VS Code with a launch.json pointing at localhost:4711

Usage — LLDB extensions:
    from pyunidbg.debug.dap_server import LLDBExtensions

    ext = LLDBExtensions(gdb_server)
    ext.install()
    # Now `lldb -o "gdb-remote 1234"` will work
"""

from __future__ import annotations

import json
import logging
import socket
import threading
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..core.emulator import Emulator
    from .gdb_server import GDBServer

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DAP message types
# ---------------------------------------------------------------------------

class DAPMessageType(Enum):
    REQUEST = "request"
    RESPONSE = "response"
    EVENT = "event"


@dataclass
class DAPMessage:
    seq: int
    type: DAPMessageType
    command: str = ""
    body: dict[str, Any] = field(default_factory=dict)
    success: bool = True
    message: str = ""
    request_seq: int = 0


# ---------------------------------------------------------------------------
# DAP Server
# ---------------------------------------------------------------------------

class DAPServer:
    """
    Debug Adapter Protocol server.

    Communicates with VS Code (or any DAP client) over TCP using the
    standard DAP wire format (Content-Length header + JSON body).
    """

    def __init__(
        self,
        emulator: Emulator,
        host: str = "localhost",
        port: int = 4711,
    ):
        self.emulator = emulator
        self.host = host
        self.port = port

        self._seq = 1
        self._running = False
        self._socket: socket.socket | None = None
        self._client: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._initialized = False

        self._breakpoints: dict[int, _DAPBreakpoint] = {}
        self._stopped = True
        self._stop_reason = "entry"

        self._handlers: dict[str, Callable[[dict], dict]] = {
            "initialize": self._on_initialize,
            "launch": self._on_launch,
            "attach": self._on_attach,
            "disconnect": self._on_disconnect,
            "setBreakpoints": self._on_set_breakpoints,
            "setFunctionBreakpoints": self._on_set_function_breakpoints,
            "setExceptionBreakpoints": self._on_set_exception_breakpoints,
            "configurationDone": self._on_configuration_done,
            "threads": self._on_threads,
            "stackTrace": self._on_stack_trace,
            "scopes": self._on_scopes,
            "variables": self._on_variables,
            "continue": self._on_continue,
            "next": self._on_next,
            "stepIn": self._on_step_in,
            "stepOut": self._on_step_out,
            "pause": self._on_pause,
            "evaluate": self._on_evaluate,
            "disassemble": self._on_disassemble,
            "readMemory": self._on_read_memory,
            "source": self._on_source,
        }

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self, blocking: bool = False) -> bool:
        try:
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._socket.bind((self.host, self.port))
            self._socket.listen(1)
            self._socket.settimeout(1.0)
            self._running = True

            logger.info("DAP server listening on %s:%d", self.host, self.port)

            if blocking:
                self._server_loop()
            else:
                self._thread = threading.Thread(target=self._server_loop, daemon=True)
                self._thread.start()
            return True
        except Exception as e:
            logger.error("Failed to start DAP server: %s", e)
            return False

    def stop(self) -> None:
        self._running = False
        for s in (self._client, self._socket):
            if s:
                try:
                    s.close()
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)
        self._client = None
        self._socket = None
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

    def _server_loop(self) -> None:
        while self._running:
            if not self._client:
                try:
                    self._client, addr = self._socket.accept()
                    logger.info("DAP client connected from %s", addr)
                except TimeoutError:
                    continue
                except OSError:
                    break

            try:
                msg = self._recv_message()
                if msg is None:
                    self._client.close()
                    self._client = None
                    continue
                self._dispatch(msg)
            except Exception as e:
                logger.error("DAP loop error: %s", e)
                if self._client:
                    try:
                        self._client.close()
                    except Exception:
                        logger.debug("Exception suppressed", exc_info=True)
                    self._client = None

    # ------------------------------------------------------------------
    # Wire protocol
    # ------------------------------------------------------------------

    def _recv_message(self) -> dict | None:
        header = b""
        while b"\r\n\r\n" not in header:
            chunk = self._client.recv(1)
            if not chunk:
                return None
            header += chunk

        content_length = 0
        for line in header.decode("utf-8").split("\r\n"):
            if line.lower().startswith("content-length:"):
                content_length = int(line.split(":")[1].strip())

        body = b""
        while len(body) < content_length:
            chunk = self._client.recv(content_length - len(body))
            if not chunk:
                return None
            body += chunk

        return json.loads(body.decode("utf-8"))

    def _send_message(self, msg: dict) -> None:
        if not self._client:
            return
        msg["seq"] = self._seq
        self._seq += 1
        body = json.dumps(msg).encode("utf-8")
        header = f"Content-Length: {len(body)}\r\n\r\n".encode()
        try:
            self._client.sendall(header + body)
        except Exception as e:
            logger.error("Failed to send DAP message: %s", e)

    def _send_response(self, request: dict, body: dict | None = None,
                       success: bool = True, message: str = "") -> None:
        resp = {
            "type": "response",
            "request_seq": request.get("seq", 0),
            "success": success,
            "command": request.get("command", ""),
            "body": body or {},
        }
        if message:
            resp["message"] = message
        self._send_message(resp)

    def _send_event(self, event: str, body: dict | None = None) -> None:
        self._send_message({
            "type": "event",
            "event": event,
            "body": body or {},
        })

    def _dispatch(self, msg: dict) -> None:
        msg_type = msg.get("type")
        if msg_type == "request":
            command = msg.get("command", "")
            handler = self._handlers.get(command)
            if handler:
                try:
                    body = handler(msg.get("arguments", {}))
                    self._send_response(msg, body)
                except Exception as e:
                    logger.error("Error handling %s: %s", command, e)
                    self._send_response(msg, success=False, message=str(e))
            else:
                self._send_response(msg, success=False,
                                    message=f"Unknown command: {command}")

    # ------------------------------------------------------------------
    # DAP request handlers
    # ------------------------------------------------------------------

    def _on_initialize(self, args: dict) -> dict:
        self._initialized = True
        return {
            "supportsConfigurationDoneRequest": True,
            "supportsFunctionBreakpoints": True,
            "supportsEvaluateForHovers": True,
            "supportsStepBack": False,
            "supportsSetVariable": True,
            "supportsDisassembleRequest": True,
            "supportsReadMemoryRequest": True,
            "supportsSteppingGranularity": True,
        }

    def _on_launch(self, args: dict) -> dict:
        self._send_event("initialized")
        return {}

    def _on_attach(self, args: dict) -> dict:
        self._send_event("initialized")
        return {}

    def _on_disconnect(self, args: dict) -> dict:
        self._running = False
        return {}

    def _on_configuration_done(self, args: dict) -> dict:
        self._send_event("stopped", {
            "reason": self._stop_reason,
            "threadId": 1,
            "allThreadsStopped": True,
        })
        return {}

    def _on_set_breakpoints(self, args: dict) -> dict:
        source = args.get("source", {})
        bps_in = args.get("breakpoints", [])
        result_bps = []
        for bp in bps_in:
            addr = bp.get("line", 0)
            dbp = _DAPBreakpoint(address=addr)
            self._breakpoints[addr] = dbp
            from ..core.hooks import Hook, HookAction, HookType

            def _bp_cb(emu, address, size, _a=addr):
                self._stopped = True
                self._stop_reason = "breakpoint"
                self._send_event("stopped", {
                    "reason": "breakpoint",
                    "threadId": 1,
                    "allThreadsStopped": True,
                })
                return HookAction.STOP

            hook = Hook(hook_type=HookType.ADDRESS, callback=_bp_cb,
                        address=addr, name=f"dap_bp_{addr:#x}")
            self.emulator.hook.add_hook(hook)
            dbp.hook = hook

            result_bps.append({
                "id": addr,
                "verified": True,
                "line": addr,
            })
        return {"breakpoints": result_bps}

    def _on_set_function_breakpoints(self, args: dict) -> dict:
        return {"breakpoints": []}

    def _on_set_exception_breakpoints(self, args: dict) -> dict:
        return {}

    def _on_threads(self, args: dict) -> dict:
        return {"threads": [{"id": 1, "name": "main"}]}

    def _on_stack_trace(self, args: dict) -> dict:
        pc = self.emulator.cpu.pc
        sp = self.emulator.cpu.sp
        frames = [
            {
                "id": 0,
                "name": f"frame@{pc:#x}",
                "instructionPointerReference": f"{pc:#x}",
                "line": pc,
                "column": 0,
                "source": {"name": "emulated", "path": "emulated"},
            }
        ]

        if hasattr(self.emulator, "cpu") and hasattr(self.emulator.cpu, "lr"):
            try:
                lr = self.emulator.cpu.lr
                if lr and lr != pc:
                    frames.append({
                        "id": 1,
                        "name": f"caller@{lr:#x}",
                        "instructionPointerReference": f"{lr:#x}",
                        "line": lr,
                        "column": 0,
                        "source": {"name": "emulated", "path": "emulated"},
                    })
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        return {
            "stackFrames": frames,
            "totalFrames": len(frames),
        }

    def _on_scopes(self, args: dict) -> dict:
        frame_id = args.get("frameId", 0)
        return {
            "scopes": [
                {"name": "Registers", "variablesReference": 1000,
                 "expensive": False},
                {"name": "Memory", "variablesReference": 2000,
                 "expensive": True},
            ]
        }

    def _on_variables(self, args: dict) -> dict:
        ref = args.get("variablesReference", 0)
        variables = []

        if ref == 1000:
            regs = self.emulator.cpu.dump()
            for name, value in regs.items():
                variables.append({
                    "name": name,
                    "value": f"{value:#x}",
                    "type": "register",
                    "variablesReference": 0,
                })
        elif ref == 2000:
            sp = self.emulator.cpu.sp
            ptr_size = self.emulator.pointer_size
            for i in range(16):
                addr = sp + i * ptr_size
                try:
                    data = self.emulator.memory.read(addr, ptr_size)
                    val = int.from_bytes(data, "little")
                    variables.append({
                        "name": f"[SP+{i*ptr_size:#x}]",
                        "value": f"{val:#x}",
                        "type": "stack",
                        "variablesReference": 0,
                    })
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)
                    break

        return {"variables": variables}

    def _on_continue(self, args: dict) -> dict:
        self._stopped = False
        threading.Thread(target=self._run_until_stop, daemon=True).start()
        return {"allThreadsContinued": True}

    def _on_next(self, args: dict) -> dict:
        try:
            self.emulator.step(1)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
        self._stopped = True
        self._stop_reason = "step"
        self._send_event("stopped", {
            "reason": "step", "threadId": 1, "allThreadsStopped": True})
        return {}

    def _on_step_in(self, args: dict) -> dict:
        return self._on_next(args)

    def _on_step_out(self, args: dict) -> dict:
        return self._on_next(args)

    def _on_pause(self, args: dict) -> dict:
        self.emulator.stop()
        self._stopped = True
        self._stop_reason = "pause"
        self._send_event("stopped", {
            "reason": "pause", "threadId": 1, "allThreadsStopped": True})
        return {}

    def _on_evaluate(self, args: dict) -> dict:
        expression = args.get("expression", "")
        context = args.get("context", "hover")

        regs = self.emulator.cpu.dump()
        name = expression.upper()
        if name in regs:
            return {"result": f"{regs[name]:#x}", "variablesReference": 0}

        if expression.startswith("0x") or expression.startswith("*"):
            addr_str = expression.lstrip("*")
            try:
                addr = int(addr_str, 0)
                data = self.emulator.memory.read(addr, self.emulator.pointer_size)
                val = int.from_bytes(data, "little")
                return {"result": f"{val:#x}", "variablesReference": 0}
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        return {"result": f"<unknown: {expression}>", "variablesReference": 0}

    def _on_disassemble(self, args: dict) -> dict:
        ref = args.get("memoryReference", "0x0")
        offset = args.get("offset", 0)
        count = args.get("instructionCount", 20)
        addr = int(ref, 0) + offset

        instructions = []
        try:
            disasm = self.emulator.disassemble(addr, count=count)
            for da, mn, ops in disasm:
                instructions.append({
                    "address": f"{da:#x}",
                    "instruction": f"{mn} {ops}".strip(),
                })
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        return {"instructions": instructions}

    def _on_read_memory(self, args: dict) -> dict:
        import base64
        ref = args.get("memoryReference", "0x0")
        offset = args.get("offset", 0)
        count = args.get("count", 256)
        addr = int(ref, 0) + offset
        try:
            data = self.emulator.memory.read(addr, count)
            return {
                "address": f"{addr:#x}",
                "data": base64.b64encode(data).decode("ascii"),
                "unreadableBytes": 0,
            }
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return {
                "address": f"{addr:#x}",
                "data": "",
                "unreadableBytes": count,
            }

    def _on_source(self, args: dict) -> dict:
        return {"content": "; no source available for emulated code\n"}

    # ------------------------------------------------------------------
    # Execution helpers
    # ------------------------------------------------------------------

    def _run_until_stop(self) -> None:
        try:
            pc = self.emulator.cpu.pc
            self.emulator.run(pc)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
        if not self._stopped:
            self._stopped = True
            self._stop_reason = "breakpoint"
            self._send_event("stopped", {
                "reason": self._stop_reason,
                "threadId": 1,
                "allThreadsStopped": True,
            })


@dataclass
class _DAPBreakpoint:
    address: int = 0
    hook: Any = None


# ---------------------------------------------------------------------------
# LLDB Extensions for the GDB server
# ---------------------------------------------------------------------------

class LLDBExtensions:
    """
    Install LLDB-specific query handlers on an existing GDBServer
    so `lldb -o 'gdb-remote <port>'` works seamlessly.

    LLDB uses several non-standard qXxx queries:
    - qHostInfo: host triple, pointer size, endian
    - qProcessInfo: pid, triple, etc.
    - jThreadsInfo: JSON thread list
    - qRegisterInfo: per-register metadata
    - QListThreadsInStopReply
    """

    def __init__(self, gdb_server: GDBServer):
        self.server = gdb_server
        self._installed = False

    def install(self) -> None:
        """Patch the GDB command handler with LLDB extensions."""
        if self._installed:
            return
        self._installed = True

        handler = self.server.handler
        original_query = handler._handle_query

        extra_queries = {
            "HostInfo": self._query_host_info,
            "ProcessInfo": self._query_process_info,
            "RegisterInfo": self._query_register_info,
        }

        def _patched_query(cmd: str) -> str:
            query = cmd[1:]
            for prefix, fn in extra_queries.items():
                if query == prefix or query.startswith(prefix + ":"):
                    return fn(query)
            if query == "ListThreadsInStopReply":
                return "OK"
            if query.startswith("jThreadsInfo"):
                return self._json_threads_info()
            return original_query(cmd)

        handler._handle_query = _patched_query

        original_supported = handler._query_supported

        def _patched_supported(query: str) -> str:
            base = original_supported(query)
            extra = ";qXfer:features:read+;qHostInfo+;qProcessInfo+"
            return base + extra

        handler._query_supported = _patched_supported

        logger.info("LLDB extensions installed on GDB server")

    def _query_host_info(self, query: str) -> str:
        from ..core.constants import Architecture
        arch = self.server.emulator.config.arch

        triple_map = {
            Architecture.ARM64: "aarch64-unknown-linux",
            Architecture.ARM: "arm-unknown-linux",
            Architecture.X86_64: "x86_64-unknown-linux",
            Architecture.X86: "i386-unknown-linux",
        }
        triple = triple_map.get(arch, "unknown-unknown-linux")
        ptr_size = 8 if self.server.emulator.is_64bit else 4

        parts = [
            f"triple:{triple.encode().hex()};",
            f"ptrsize:{ptr_size};",
            "endian:little;",
            "hostname:7079756e69646267;",  # "pyunidbg" in hex
        ]
        return "".join(parts)

    def _query_process_info(self, query: str) -> str:
        from ..core.constants import Architecture
        arch = self.server.emulator.config.arch

        triple_map = {
            Architecture.ARM64: "aarch64-unknown-linux",
            Architecture.ARM: "arm-unknown-linux",
            Architecture.X86_64: "x86_64-unknown-linux",
            Architecture.X86: "i386-unknown-linux",
        }
        triple = triple_map.get(arch, "unknown-unknown-linux")
        ptr_size = 8 if self.server.emulator.is_64bit else 4

        return (
            f"pid:1;parent-pid:0;real-uid:0;real-gid:0;"
            f"effective-uid:0;effective-gid:0;"
            f"triple:{triple.encode().hex()};"
            f"ptrsize:{ptr_size};"
        )

    def _query_register_info(self, query: str) -> str:
        parts = query.split(":")
        if len(parts) < 2:
            idx = 0
        else:
            try:
                idx = int(parts[1])
            except ValueError:
                return "E45"

        regs = self.server.target.registers
        if idx >= len(regs):
            return "E45"

        reg = regs[idx]
        encoding = "uint"
        fmt = "hex"
        set_name = "General Purpose Registers"

        return (
            f"name:{reg.name};bitsize:{reg.bitsize};offset:{idx * (reg.bitsize // 8)};"
            f"encoding:{encoding};format:{fmt};set:{set_name};"
            f"gcc:{idx};dwarf:{idx};generic:;ehframe:{idx};"
        )

    def _json_threads_info(self) -> str:
        threads = [{"tid": 1, "name": "main"}]
        return json.dumps(threads)


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------

def create_dap_server(
    emulator: Emulator,
    port: int = 4711,
    **kwargs,
) -> DAPServer:
    return DAPServer(emulator, port=port, **kwargs)


def install_lldb_extensions(gdb_server: GDBServer) -> LLDBExtensions:
    ext = LLDBExtensions(gdb_server)
    ext.install()
    return ext


__all__ = [
    "DAPServer",
    "DAPMessage",
    "DAPMessageType",
    "LLDBExtensions",
    "create_dap_server",
    "install_lldb_extensions",
]
