"""
GDB command handlers.

Implements handlers for GDB Remote Serial Protocol commands.
"""

import logging
import re
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

from .gdb_protocol import GDBResponse, GDBSignal

if TYPE_CHECKING:
    from .gdb_server import GDBServer

logger = logging.getLogger(__name__)


class StopReason(Enum):
    """Reason for target stop."""
    NONE = "none"
    BREAKPOINT = "breakpoint"
    WATCHPOINT = "watchpoint"
    STEP = "step"
    SIGNAL = "signal"
    EXIT = "exit"


@dataclass
class StopEvent:
    """Information about why target stopped."""
    reason: StopReason
    signal: int = GDBSignal.SIGTRAP
    address: int = 0
    thread_id: int = 1

    def to_stop_reply(self) -> str:
        """Convert to GDB stop reply packet."""
        if self.reason == StopReason.EXIT:
            return GDBResponse.exit_reply(self.signal)
        return GDBResponse.stop_reply(self.signal, self.thread_id)


class GDBCommandHandler:
    """
    Handles GDB Remote Serial Protocol commands.
    
    This class implements all the command handlers for the GDB protocol.
    """

    def __init__(self, server: 'GDBServer'):
        """
        Initialize command handler.
        
        Args:
            server: Parent GDB server instance
        """
        self.server = server
        self.target = server.target
        self.reg_mapper = server.reg_mapper

        # Command handlers (command prefix -> handler)
        self._handlers: dict[str, Callable[[str], str]] = {
            '?': self._handle_stop_reason,
            'g': self._handle_read_registers,
            'G': self._handle_write_registers,
            'p': self._handle_read_register,
            'P': self._handle_write_register,
            'm': self._handle_read_memory,
            'M': self._handle_write_memory,
            'X': self._handle_write_memory_binary,
            'c': self._handle_continue,
            'C': self._handle_continue_signal,
            's': self._handle_step,
            'S': self._handle_step_signal,
            'z': self._handle_remove_breakpoint,
            'Z': self._handle_insert_breakpoint,
            'D': self._handle_detach,
            'k': self._handle_kill,
            'H': self._handle_set_thread,
            'T': self._handle_thread_alive,
            'q': self._handle_query,
            'Q': self._handle_set,
            'v': self._handle_v_command,
            '!': self._handle_extended_mode,
        }

        # Query handlers (qXxx)
        self._query_handlers: dict[str, Callable[[str], str]] = {
            'Supported': self._query_supported,
            'Attached': self._query_attached,
            'C': self._query_current_thread,
            'fThreadInfo': self._query_thread_info_first,
            'sThreadInfo': self._query_thread_info_subsequent,
            'Xfer': self._query_xfer,
            'Offsets': self._query_offsets,
            'Symbol': self._query_symbol,
            'TStatus': self._query_trace_status,
            'Rcmd': self._query_rcmd,
        }

        # Track current state
        self.current_thread = 1
        self.stopped = True
        self.last_stop = StopEvent(StopReason.NONE)

    def handle_command(self, cmd: str) -> str:
        """
        Handle a GDB command.
        
        Args:
            cmd: Command string (without framing)
            
        Returns:
            Response string
        """
        if not cmd:
            return GDBResponse.empty()

        # Find handler by first character or prefix
        handler = self._handlers.get(cmd[0])
        if handler:
            try:
                return handler(cmd)
            except Exception as e:
                logger.error(f"Error handling command '{cmd}': {e}")
                return GDBResponse.error(1)

        # Unknown command
        logger.debug(f"Unknown command: {cmd}")
        return GDBResponse.empty()

    # === Stop/Status Commands ===

    def _handle_stop_reason(self, cmd: str) -> str:
        """Handle '?' - Query stop reason."""
        return self.last_stop.to_stop_reply()

    # === Register Commands ===

    def _handle_read_registers(self, cmd: str) -> str:
        """Handle 'g' - Read all registers."""
        result = []

        for reg in self.target.registers:
            try:
                uc_reg = self.reg_mapper.gdb_to_unicorn(reg.regnum)
                if uc_reg is not None:
                    value = self.server.emulator.reg_read(uc_reg)
                else:
                    value = 0

                # Convert to hex (little-endian)
                size = reg.bitsize // 8
                hex_val = value.to_bytes(size, 'little').hex()
                result.append(hex_val)
            except Exception as e:
                logger.debug(f"Error reading register {reg.name}: {e}")
                size = reg.bitsize // 8
                result.append('00' * size)

        return ''.join(result)

    def _handle_write_registers(self, cmd: str) -> str:
        """Handle 'G' - Write all registers."""
        hex_data = cmd[1:]
        offset = 0

        for reg in self.target.registers:
            size = reg.bitsize // 8
            if offset + size * 2 > len(hex_data):
                break

            hex_val = hex_data[offset:offset + size * 2]
            try:
                value = int.from_bytes(bytes.fromhex(hex_val), 'little')
                uc_reg = self.reg_mapper.gdb_to_unicorn(reg.regnum)
                if uc_reg is not None:
                    self.server.emulator.reg_write(uc_reg, value)
            except Exception as e:
                logger.debug(f"Error writing register {reg.name}: {e}")

            offset += size * 2

        return GDBResponse.ok()

    def _handle_read_register(self, cmd: str) -> str:
        """Handle 'p' - Read single register."""
        try:
            regnum = int(cmd[1:], 16)
            reg = self.target.get_register_by_num(regnum)

            if reg is None:
                return GDBResponse.error(0)

            uc_reg = self.reg_mapper.gdb_to_unicorn(regnum)
            if uc_reg is None:
                return '00' * (reg.bitsize // 8)

            value = self.server.emulator.reg_read(uc_reg)
            size = reg.bitsize // 8
            return value.to_bytes(size, 'little').hex()
        except Exception as e:
            logger.error(f"Error reading register: {e}")
            return GDBResponse.error(1)

    def _handle_write_register(self, cmd: str) -> str:
        """Handle 'P' - Write single register."""
        try:
            # Format: Pn=r...
            match = re.match(r'P([0-9a-fA-F]+)=([0-9a-fA-F]+)', cmd)
            if not match:
                return GDBResponse.error(1)

            regnum = int(match.group(1), 16)
            hex_val = match.group(2)

            reg = self.target.get_register_by_num(regnum)
            if reg is None:
                return GDBResponse.error(0)

            value = int.from_bytes(bytes.fromhex(hex_val), 'little')
            uc_reg = self.reg_mapper.gdb_to_unicorn(regnum)

            if uc_reg is not None:
                self.server.emulator.reg_write(uc_reg, value)

            return GDBResponse.ok()
        except Exception as e:
            logger.error(f"Error writing register: {e}")
            return GDBResponse.error(1)

    # === Memory Commands ===

    def _handle_read_memory(self, cmd: str) -> str:
        """Handle 'm' - Read memory."""
        try:
            # Format: maddr,length
            match = re.match(r'm([0-9a-fA-F]+),([0-9a-fA-F]+)', cmd)
            if not match:
                return GDBResponse.error(1)

            addr = int(match.group(1), 16)
            length = int(match.group(2), 16)

            # Read memory
            data = self.server.emulator.mem_read(addr, length)
            return data.hex()
        except Exception as e:
            logger.debug(f"Error reading memory at 0x{addr:x}: {e}")
            return GDBResponse.error(0x0E)  # EFAULT

    def _handle_write_memory(self, cmd: str) -> str:
        """Handle 'M' - Write memory (hex)."""
        try:
            # Format: Maddr,length:XX...
            match = re.match(r'M([0-9a-fA-F]+),([0-9a-fA-F]+):([0-9a-fA-F]*)', cmd)
            if not match:
                return GDBResponse.error(1)

            addr = int(match.group(1), 16)
            length = int(match.group(2), 16)
            hex_data = match.group(3)

            data = bytes.fromhex(hex_data)
            if len(data) != length:
                return GDBResponse.error(1)

            self.server.emulator.mem_write(addr, data)
            return GDBResponse.ok()
        except Exception as e:
            logger.debug(f"Error writing memory at 0x{addr:x}: {e}")
            return GDBResponse.error(0x0E)

    def _handle_write_memory_binary(self, cmd: str) -> str:
        """Handle 'X' - Write memory (binary)."""
        try:
            # Format: Xaddr,length:binary_data
            # Find the colon
            colon_idx = cmd.find(':')
            if colon_idx == -1:
                return GDBResponse.error(1)

            header = cmd[1:colon_idx]
            match = re.match(r'([0-9a-fA-F]+),([0-9a-fA-F]+)', header)
            if not match:
                return GDBResponse.error(1)

            addr = int(match.group(1), 16)
            length = int(match.group(2), 16)

            # Binary data follows colon
            data = cmd[colon_idx + 1:].encode('latin-1')

            if length == 0:
                # Probe - just check if address is valid
                return GDBResponse.ok()

            self.server.emulator.mem_write(addr, data[:length])
            return GDBResponse.ok()
        except Exception as e:
            logger.debug(f"Error writing binary memory: {e}")
            return GDBResponse.error(0x0E)

    # === Execution Control ===

    def _handle_continue(self, cmd: str) -> str:
        """Handle 'c' - Continue execution."""
        addr = None
        if len(cmd) > 1:
            addr = int(cmd[1:], 16)

        self.stopped = False
        stop_event = self.server.continue_execution(addr)
        self.stopped = True
        self.last_stop = stop_event

        return stop_event.to_stop_reply()

    def _handle_continue_signal(self, cmd: str) -> str:
        """Handle 'C' - Continue with signal."""
        # Format: Csig;addr or Csig
        # We ignore the signal for now
        addr = None
        if ';' in cmd:
            addr = int(cmd.split(';')[1], 16)

        self.stopped = False
        stop_event = self.server.continue_execution(addr)
        self.stopped = True
        self.last_stop = stop_event

        return stop_event.to_stop_reply()

    def _handle_step(self, cmd: str) -> str:
        """Handle 's' - Single step."""
        addr = None
        if len(cmd) > 1:
            addr = int(cmd[1:], 16)

        self.stopped = False
        stop_event = self.server.single_step(addr)
        self.stopped = True
        self.last_stop = stop_event

        return stop_event.to_stop_reply()

    def _handle_step_signal(self, cmd: str) -> str:
        """Handle 'S' - Step with signal."""
        addr = None
        if ';' in cmd:
            addr = int(cmd.split(';')[1], 16)

        self.stopped = False
        stop_event = self.server.single_step(addr)
        self.stopped = True
        self.last_stop = stop_event

        return stop_event.to_stop_reply()

    # === Breakpoint Commands ===

    def _handle_insert_breakpoint(self, cmd: str) -> str:
        """Handle 'Z' - Insert breakpoint/watchpoint."""
        try:
            # Format: Ztype,addr,kind
            match = re.match(r'Z([0-4]),([0-9a-fA-F]+),([0-9a-fA-F]+)', cmd)
            if not match:
                return GDBResponse.error(1)

            bp_type = int(match.group(1))
            addr = int(match.group(2), 16)
            kind = int(match.group(3), 16)

            if bp_type == 0:
                # Software breakpoint
                self.server.add_breakpoint(addr)
                return GDBResponse.ok()
            elif bp_type == 1:
                # Hardware breakpoint
                self.server.add_breakpoint(addr, hardware=True)
                return GDBResponse.ok()
            elif bp_type == 2:
                # Write watchpoint
                self.server.add_watchpoint(addr, kind, write=True)
                return GDBResponse.ok()
            elif bp_type == 3:
                # Read watchpoint
                self.server.add_watchpoint(addr, kind, read=True)
                return GDBResponse.ok()
            elif bp_type == 4:
                # Access watchpoint
                self.server.add_watchpoint(addr, kind, read=True, write=True)
                return GDBResponse.ok()

            return GDBResponse.empty()
        except Exception as e:
            logger.error(f"Error inserting breakpoint: {e}")
            return GDBResponse.error(1)

    def _handle_remove_breakpoint(self, cmd: str) -> str:
        """Handle 'z' - Remove breakpoint/watchpoint."""
        try:
            match = re.match(r'z([0-4]),([0-9a-fA-F]+),([0-9a-fA-F]+)', cmd)
            if not match:
                return GDBResponse.error(1)

            bp_type = int(match.group(1))
            addr = int(match.group(2), 16)
            kind = int(match.group(3), 16)

            if bp_type in (0, 1):
                # Software/hardware breakpoint
                self.server.remove_breakpoint(addr)
                return GDBResponse.ok()
            elif bp_type in (2, 3, 4):
                # Watchpoint
                self.server.remove_watchpoint(addr)
                return GDBResponse.ok()

            return GDBResponse.empty()
        except Exception as e:
            logger.error(f"Error removing breakpoint: {e}")
            return GDBResponse.error(1)

    # === Thread Commands ===

    def _handle_set_thread(self, cmd: str) -> str:
        """Handle 'H' - Set thread for subsequent operations."""
        # Format: Hop,thread_id
        # op: 'c' for continue, 'g' for other operations
        if len(cmd) < 2:
            return GDBResponse.error(1)

        thread_str = cmd[2:]
        if thread_str == '-1' or thread_str == '0':
            # All threads or any thread
            self.current_thread = 1
        else:
            try:
                self.current_thread = int(thread_str, 16)
            except ValueError:
                return GDBResponse.error(1)

        return GDBResponse.ok()

    def _handle_thread_alive(self, cmd: str) -> str:
        """Handle 'T' - Check if thread is alive."""
        try:
            thread_id = int(cmd[1:], 16)
            # We only have thread 1
            if thread_id == 1 or thread_id == -1:
                return GDBResponse.ok()
            return GDBResponse.error(1)
        except ValueError:
            return GDBResponse.error(1)

    # === Session Commands ===

    def _handle_detach(self, cmd: str) -> str:
        """Handle 'D' - Detach from target."""
        self.server.detach()
        return GDBResponse.ok()

    def _handle_kill(self, cmd: str) -> str:
        """Handle 'k' - Kill target."""
        self.server.kill()
        return GDBResponse.ok()

    def _handle_extended_mode(self, cmd: str) -> str:
        """Handle '!' - Enable extended mode."""
        return GDBResponse.ok()

    # === Query Commands ===

    def _handle_query(self, cmd: str) -> str:
        """Handle 'q' - General query commands."""
        # Extract query name
        query = cmd[1:]

        # Check for exact match or prefix match
        for name, handler in self._query_handlers.items():
            if query == name or query.startswith(name + ':'):
                return handler(query)

        return GDBResponse.empty()

    def _handle_set(self, cmd: str) -> str:
        """Handle 'Q' - General set commands."""
        setting = cmd[1:]

        if setting.startswith('StartNoAckMode'):
            self.server.protocol.ack_mode = False
            return GDBResponse.ok()

        return GDBResponse.empty()

    def _query_supported(self, query: str) -> str:
        """Handle qSupported - Query supported features."""
        features = [
            'PacketSize=4000',
            'qXfer:features:read+',
            'QStartNoAckMode+',
            'swbreak+',
            'hwbreak+',
            'vContSupported+',
        ]
        return ';'.join(features)

    def _query_attached(self, query: str) -> str:
        """Handle qAttached - Query if attached to existing process."""
        return '1'  # Attached

    def _query_current_thread(self, query: str) -> str:
        """Handle qC - Query current thread ID."""
        return f"QC{self.current_thread:x}"

    def _query_thread_info_first(self, query: str) -> str:
        """Handle qfThreadInfo - First thread info."""
        return "m1"  # Thread 1

    def _query_thread_info_subsequent(self, query: str) -> str:
        """Handle qsThreadInfo - Subsequent thread info."""
        return "l"  # End of list

    def _query_xfer(self, query: str) -> str:
        """Handle qXfer - Transfer data."""
        # Format: qXfer:object:read:annex:offset,length
        parts = query.split(':')
        if len(parts) < 4:
            return GDBResponse.error(1)

        obj = parts[1]
        operation = parts[2]
        annex = parts[3]

        if obj == 'features' and operation == 'read':
            # Get target description
            offset_length = parts[4] if len(parts) > 4 else '0,1000'
            offset, length = map(lambda x: int(x, 16), offset_length.split(','))

            if annex == 'target.xml' or annex == '':
                xml = self.target.get_target_xml()
                chunk = xml[offset:offset + length]

                # 'm' = more data, 'l' = last chunk
                prefix = 'l' if offset + length >= len(xml) else 'm'
                return prefix + chunk

        return GDBResponse.empty()

    def _query_offsets(self, query: str) -> str:
        """Handle qOffsets - Query section offsets."""
        return "Text=0;Data=0;Bss=0"

    def _query_symbol(self, query: str) -> str:
        """Handle qSymbol - Symbol lookup."""
        return GDBResponse.ok()

    def _query_trace_status(self, query: str) -> str:
        """Handle qTStatus - Trace status."""
        return "T0"  # Tracing not supported

    def _query_rcmd(self, query: str) -> str:
        """Handle qRcmd - Remote command."""
        # Format: qRcmd,hex_command
        if ':' in query:
            hex_cmd = query.split(':')[1]
        elif ',' in query:
            hex_cmd = query.split(',')[1]
        else:
            return GDBResponse.ok()

        try:
            command = bytes.fromhex(hex_cmd).decode('utf-8')
            result = self.server.handle_monitor_command(command)
            return result.encode('utf-8').hex()
        except Exception as e:
            return f"Error: {e}".encode().hex()

    # === vCommand Handlers ===

    def _handle_v_command(self, cmd: str) -> str:
        """Handle 'v' - Extended commands."""
        if cmd.startswith('vCont?'):
            return "vCont;c;C;s;S"

        if cmd.startswith('vCont;'):
            # Parse vCont command
            actions = cmd[6:].split(';')
            for action in actions:
                if action.startswith('c'):
                    return self._handle_continue('c')
                elif action.startswith('s'):
                    return self._handle_step('s')
            return GDBResponse.empty()

        if cmd.startswith('vMustReplyEmpty'):
            return GDBResponse.empty()

        if cmd.startswith('vKill'):
            self.server.kill()
            return GDBResponse.ok()

        return GDBResponse.empty()
