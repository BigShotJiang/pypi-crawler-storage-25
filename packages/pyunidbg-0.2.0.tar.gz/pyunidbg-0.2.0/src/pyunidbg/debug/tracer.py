"""Execution tracer for PyUniDbg."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, TextIO

from unicorn import UC_HOOK_CODE, UC_HOOK_MEM_READ, UC_HOOK_MEM_WRITE

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator


import logging

logger = logging.getLogger(__name__)


@dataclass
class TraceEntry:
    """A single trace entry."""

    address: int
    instruction: str = ""
    registers: dict[str, int] = field(default_factory=dict)
    memory_access: tuple[str, int, int, int] | None = None  # (type, addr, size, value)


class Tracer:
    """
    Execution tracer.
    
    Records instruction execution, memory accesses, and register changes.
    """

    def __init__(
        self,
        emulator: Emulator,
        trace_instructions: bool = True,
        trace_memory: bool = False,
        trace_registers: bool = False,
        output: TextIO | str | Path | None = None,
    ):
        self._emulator = emulator
        self._trace_instructions = trace_instructions
        self._trace_memory = trace_memory
        self._trace_registers = trace_registers

        # Trace buffer
        self._entries: list[TraceEntry] = []
        self._max_entries = 100000

        # Output file
        self._output: TextIO | None = None
        if output:
            if isinstance(output, (str, Path)):
                self._output = open(output, 'w')
            else:
                self._output = output

        # Hooks
        self._hooks = []
        self._enabled = False

    def start(self) -> None:
        """Start tracing."""
        if self._enabled:
            return

        self._enabled = True
        self._entries.clear()

        if self._trace_instructions:
            handle = self._emulator._uc.hook_add(
                UC_HOOK_CODE,
                self._code_hook,
            )
            self._hooks.append(handle)

        if self._trace_memory:
            handle = self._emulator._uc.hook_add(
                UC_HOOK_MEM_READ | UC_HOOK_MEM_WRITE,
                self._memory_hook,
            )
            self._hooks.append(handle)

    def stop(self) -> None:
        """Stop tracing."""
        if not self._enabled:
            return

        self._enabled = False

        for handle in self._hooks:
            self._emulator._uc.hook_del(handle)
        self._hooks.clear()

    def clear(self) -> None:
        """Clear trace buffer."""
        self._entries.clear()

    def _code_hook(self, uc, address, size, user_data) -> None:
        """Hook for instruction tracing."""
        entry = TraceEntry(address=address)

        # Get instruction
        try:
            disasm = self._emulator.disassemble(address, size, count=1)
            if disasm:
                _, mnemonic, op_str = disasm[0]
                entry.instruction = f"{mnemonic} {op_str}".strip()
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        # Get registers if requested
        if self._trace_registers:
            entry.registers = self._emulator.cpu.dump()

        # Store entry
        if len(self._entries) < self._max_entries:
            self._entries.append(entry)

        # Output to file if configured
        if self._output:
            line = f"{address:#x}: {entry.instruction}"
            if self._trace_registers:
                line += f" | regs={entry.registers}"
            self._output.write(line + "\n")

    def _memory_hook(self, uc, access, address, size, value, user_data) -> None:
        """Hook for memory tracing."""
        access_type = "R" if access == 16 else "W"  # UC_MEM_READ = 16

        entry = TraceEntry(
            address=self._emulator.cpu.pc,
            memory_access=(access_type, address, size, value),
        )

        if len(self._entries) < self._max_entries:
            self._entries.append(entry)

        if self._output:
            self._output.write(
                f"[MEM] {access_type} {address:#x} size={size} value={value:#x}\n"
            )

    def get_trace(self) -> list[TraceEntry]:
        """Get all trace entries."""
        return list(self._entries)

    def get_instruction_trace(self) -> list[tuple[int, str]]:
        """Get instruction trace as (address, instruction) pairs."""
        return [(e.address, e.instruction) for e in self._entries if e.instruction]

    def save(self, path: str | Path) -> None:
        """Save trace to file."""
        with open(path, 'w') as f:
            for entry in self._entries:
                line = f"{entry.address:#x}"
                if entry.instruction:
                    line += f": {entry.instruction}"
                if entry.memory_access:
                    access_type, addr, size, value = entry.memory_access
                    line += f" [{access_type} {addr:#x}={value:#x}]"
                f.write(line + "\n")

    def print_trace(self, limit: int = 50, file: TextIO = sys.stdout) -> None:
        """Print trace to stdout."""
        entries = self._entries[-limit:] if limit else self._entries

        for entry in entries:
            line = f"{entry.address:#010x}: {entry.instruction:40s}"
            if entry.memory_access:
                access_type, addr, size, value = entry.memory_access
                line += f" [{access_type} {addr:#x}]"
            print(line, file=file)

    def find_addresses(self, pattern: str) -> list[TraceEntry]:
        """Find entries matching instruction pattern."""
        return [
            e for e in self._entries
            if pattern.lower() in e.instruction.lower()
        ]

    def find_memory_access(self, address: int) -> list[TraceEntry]:
        """Find entries accessing a specific memory address."""
        return [
            e for e in self._entries
            if e.memory_access and e.memory_access[1] == address
        ]

    @property
    def entry_count(self) -> int:
        """Number of trace entries."""
        return len(self._entries)

    def __enter__(self):
        """Context manager entry."""
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.stop()
        return False

    def __del__(self):
        """Cleanup."""
        self.stop()
        if self._output and self._output not in (sys.stdout, sys.stderr):
            self._output.close()
