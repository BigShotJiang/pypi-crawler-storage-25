"""
GDB target description for ARM and ARM64.

Provides XML target descriptions that tell GDB about the register layout
of the emulated target architecture.
"""

from dataclasses import dataclass
from enum import Enum


class TargetArch(Enum):
    """Supported target architectures."""
    ARM = "arm"
    ARM64 = "aarch64"
    X86 = "i386"
    X86_64 = "x86_64"


@dataclass
class RegisterDef:
    """Register definition for GDB."""
    name: str
    bitsize: int
    regnum: int
    type: str = "int"
    group: str = "general"

    def to_xml(self) -> str:
        """Convert to XML element."""
        return (
            f'<reg name="{self.name}" bitsize="{self.bitsize}" '
            f'regnum="{self.regnum}" type="{self.type}" group="{self.group}"/>'
        )


class GDBTarget:
    """
    GDB target description generator.
    
    Generates target.xml and related descriptions for GDB to understand
    the register layout of the emulated architecture.
    """

    # ARM32 general purpose registers
    ARM_REGS: list[RegisterDef] = [
        RegisterDef("r0", 32, 0),
        RegisterDef("r1", 32, 1),
        RegisterDef("r2", 32, 2),
        RegisterDef("r3", 32, 3),
        RegisterDef("r4", 32, 4),
        RegisterDef("r5", 32, 5),
        RegisterDef("r6", 32, 6),
        RegisterDef("r7", 32, 7),
        RegisterDef("r8", 32, 8),
        RegisterDef("r9", 32, 9),
        RegisterDef("r10", 32, 10),
        RegisterDef("r11", 32, 11),  # fp
        RegisterDef("r12", 32, 12),  # ip
        RegisterDef("sp", 32, 13),
        RegisterDef("lr", 32, 14),
        RegisterDef("pc", 32, 15),
        RegisterDef("cpsr", 32, 25, type="int", group="system"),
    ]

    # ARM64 general purpose registers
    ARM64_REGS: list[RegisterDef] = [
        RegisterDef("x0", 64, 0),
        RegisterDef("x1", 64, 1),
        RegisterDef("x2", 64, 2),
        RegisterDef("x3", 64, 3),
        RegisterDef("x4", 64, 4),
        RegisterDef("x5", 64, 5),
        RegisterDef("x6", 64, 6),
        RegisterDef("x7", 64, 7),
        RegisterDef("x8", 64, 8),
        RegisterDef("x9", 64, 9),
        RegisterDef("x10", 64, 10),
        RegisterDef("x11", 64, 11),
        RegisterDef("x12", 64, 12),
        RegisterDef("x13", 64, 13),
        RegisterDef("x14", 64, 14),
        RegisterDef("x15", 64, 15),
        RegisterDef("x16", 64, 16),
        RegisterDef("x17", 64, 17),
        RegisterDef("x18", 64, 18),
        RegisterDef("x19", 64, 19),
        RegisterDef("x20", 64, 20),
        RegisterDef("x21", 64, 21),
        RegisterDef("x22", 64, 22),
        RegisterDef("x23", 64, 23),
        RegisterDef("x24", 64, 24),
        RegisterDef("x25", 64, 25),
        RegisterDef("x26", 64, 26),
        RegisterDef("x27", 64, 27),
        RegisterDef("x28", 64, 28),
        RegisterDef("x29", 64, 29),  # fp
        RegisterDef("x30", 64, 30),  # lr
        RegisterDef("sp", 64, 31),
        RegisterDef("pc", 64, 32),
        RegisterDef("cpsr", 32, 33, type="int", group="system"),
    ]

    def __init__(self, arch: TargetArch):
        """
        Initialize target description.
        
        Args:
            arch: Target architecture
        """
        self.arch = arch
        self._registers = self._get_registers()
        self._reg_map = {r.name: r for r in self._registers}

    def _get_registers(self) -> list[RegisterDef]:
        """Get register definitions for architecture."""
        if self.arch == TargetArch.ARM:
            return self.ARM_REGS.copy()
        elif self.arch == TargetArch.ARM64:
            return self.ARM64_REGS.copy()
        else:
            raise ValueError(f"Unsupported architecture: {self.arch}")

    @property
    def registers(self) -> list[RegisterDef]:
        """Get all register definitions."""
        return self._registers

    @property
    def register_count(self) -> int:
        """Get number of registers."""
        return len(self._registers)

    @property
    def pointer_size(self) -> int:
        """Get pointer size in bytes."""
        if self.arch in (TargetArch.ARM, TargetArch.X86):
            return 4
        return 8

    def get_register(self, name: str) -> RegisterDef | None:
        """Get register by name."""
        return self._reg_map.get(name)

    def get_register_by_num(self, regnum: int) -> RegisterDef | None:
        """Get register by number."""
        for reg in self._registers:
            if reg.regnum == regnum:
                return reg
        return None

    def get_arch_name(self) -> str:
        """Get GDB architecture name."""
        return self.arch.value

    def get_target_xml(self) -> str:
        """
        Generate main target.xml description.
        
        Returns:
            XML string describing the target
        """
        xml_parts = [
            '<?xml version="1.0"?>',
            '<!DOCTYPE target SYSTEM "gdb-target.dtd">',
            '<target version="1.0">',
            f'  <architecture>{self.get_arch_name()}</architecture>',
            '  <feature name="org.gnu.gdb.arm.core">',
        ]

        for reg in self._registers:
            xml_parts.append(f'    {reg.to_xml()}')

        xml_parts.extend([
            '  </feature>',
            '</target>',
        ])

        return '\n'.join(xml_parts)

    def get_register_size_bytes(self, regnum: int) -> int:
        """Get register size in bytes."""
        reg = self.get_register_by_num(regnum)
        if reg:
            return reg.bitsize // 8
        return self.pointer_size

    def get_all_registers_size(self) -> int:
        """Get total size of all registers in bytes."""
        return sum(r.bitsize // 8 for r in self._registers)


class RegisterMapper:
    """
    Maps between GDB register numbers and Unicorn register constants.
    """

    def __init__(self, arch: TargetArch):
        """
        Initialize register mapper.
        
        Args:
            arch: Target architecture
        """
        self.arch = arch
        self._gdb_to_uc: dict[int, int] = {}
        self._uc_to_gdb: dict[int, int] = {}
        self._setup_mapping()

    def _setup_mapping(self):
        """Set up register mappings."""
        try:
            from unicorn import arm64_const, arm_const
        except ImportError:
            return

        if self.arch == TargetArch.ARM:
            # ARM32 mapping
            self._gdb_to_uc = {
                0: arm_const.UC_ARM_REG_R0,
                1: arm_const.UC_ARM_REG_R1,
                2: arm_const.UC_ARM_REG_R2,
                3: arm_const.UC_ARM_REG_R3,
                4: arm_const.UC_ARM_REG_R4,
                5: arm_const.UC_ARM_REG_R5,
                6: arm_const.UC_ARM_REG_R6,
                7: arm_const.UC_ARM_REG_R7,
                8: arm_const.UC_ARM_REG_R8,
                9: arm_const.UC_ARM_REG_R9,
                10: arm_const.UC_ARM_REG_R10,
                11: arm_const.UC_ARM_REG_R11,
                12: arm_const.UC_ARM_REG_R12,
                13: arm_const.UC_ARM_REG_SP,
                14: arm_const.UC_ARM_REG_LR,
                15: arm_const.UC_ARM_REG_PC,
                25: arm_const.UC_ARM_REG_CPSR,
            }
        elif self.arch == TargetArch.ARM64:
            # ARM64 mapping
            self._gdb_to_uc = {
                0: arm64_const.UC_ARM64_REG_X0,
                1: arm64_const.UC_ARM64_REG_X1,
                2: arm64_const.UC_ARM64_REG_X2,
                3: arm64_const.UC_ARM64_REG_X3,
                4: arm64_const.UC_ARM64_REG_X4,
                5: arm64_const.UC_ARM64_REG_X5,
                6: arm64_const.UC_ARM64_REG_X6,
                7: arm64_const.UC_ARM64_REG_X7,
                8: arm64_const.UC_ARM64_REG_X8,
                9: arm64_const.UC_ARM64_REG_X9,
                10: arm64_const.UC_ARM64_REG_X10,
                11: arm64_const.UC_ARM64_REG_X11,
                12: arm64_const.UC_ARM64_REG_X12,
                13: arm64_const.UC_ARM64_REG_X13,
                14: arm64_const.UC_ARM64_REG_X14,
                15: arm64_const.UC_ARM64_REG_X15,
                16: arm64_const.UC_ARM64_REG_X16,
                17: arm64_const.UC_ARM64_REG_X17,
                18: arm64_const.UC_ARM64_REG_X18,
                19: arm64_const.UC_ARM64_REG_X19,
                20: arm64_const.UC_ARM64_REG_X20,
                21: arm64_const.UC_ARM64_REG_X21,
                22: arm64_const.UC_ARM64_REG_X22,
                23: arm64_const.UC_ARM64_REG_X23,
                24: arm64_const.UC_ARM64_REG_X24,
                25: arm64_const.UC_ARM64_REG_X25,
                26: arm64_const.UC_ARM64_REG_X26,
                27: arm64_const.UC_ARM64_REG_X27,
                28: arm64_const.UC_ARM64_REG_X28,
                29: arm64_const.UC_ARM64_REG_X29,
                30: arm64_const.UC_ARM64_REG_X30,
                31: arm64_const.UC_ARM64_REG_SP,
                32: arm64_const.UC_ARM64_REG_PC,
                33: arm64_const.UC_ARM64_REG_NZCV,
            }

        # Build reverse mapping
        self._uc_to_gdb = {v: k for k, v in self._gdb_to_uc.items()}

    def gdb_to_unicorn(self, gdb_regnum: int) -> int | None:
        """Convert GDB register number to Unicorn constant."""
        return self._gdb_to_uc.get(gdb_regnum)

    def unicorn_to_gdb(self, uc_reg: int) -> int | None:
        """Convert Unicorn register constant to GDB number."""
        return self._uc_to_gdb.get(uc_reg)
