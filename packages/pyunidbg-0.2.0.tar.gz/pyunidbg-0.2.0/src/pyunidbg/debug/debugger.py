"""Interactive debugger for PyUniDbg."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING

from unicorn import UC_HOOK_CODE

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator


class BreakpointType(Enum):
    """Types of breakpoints."""
    SOFTWARE = auto()
    HARDWARE = auto()
    CONDITIONAL = auto()


@dataclass
class Breakpoint:
    """Represents a breakpoint."""

    id: int
    address: int
    enabled: bool = True
    type: BreakpointType = BreakpointType.SOFTWARE
    condition: Callable | None = None
    hit_count: int = 0
    temporary: bool = False

    def should_break(self, emu: Emulator) -> bool:
        """Check if breakpoint should trigger."""
        if not self.enabled:
            return False
        if self.condition and not self.condition(emu):
            return False
        return True


class Debugger:
    """
    Interactive debugger for the emulator.
    
    Provides:
    - Breakpoints (software, hardware, conditional)
    - Stepping (step in, step over, step out)
    - Memory inspection
    - Register viewing/modification
    - Stack traces
    """

    def __init__(self, emulator: Emulator):
        self._emulator = emulator
        self._breakpoints: dict[int, Breakpoint] = {}  # address -> breakpoint
        self._breakpoint_counter = 0
        self._paused = False
        self._step_mode = False
        self._step_over_return = None

        # Setup code hook for breakpoints
        self._emulator._uc.hook_add(
            UC_HOOK_CODE,
            self._code_hook,
            user_data=self,
        )

    def _code_hook(self, uc, address, size, user_data) -> None:
        """Code hook for breakpoint handling."""
        # Check for breakpoint
        if address in self._breakpoints:
            bp = self._breakpoints[address]
            if bp.should_break(self._emulator):
                bp.hit_count += 1
                self._on_breakpoint(bp)

                if bp.temporary:
                    self.remove_breakpoint(bp.id)

        # Handle stepping
        if self._step_mode:
            self._step_mode = False
            self._on_step(address)

    def _on_breakpoint(self, bp: Breakpoint) -> None:
        """Called when a breakpoint is hit."""
        print(f"\n[*] Breakpoint {bp.id} hit at {bp.address:#x}")
        self._show_context()
        self._paused = True
        self._emulator.stop()

    def _on_step(self, address: int) -> None:
        """Called after a step."""
        print(f"\n[*] Stepped to {address:#x}")
        self._show_context()
        self._paused = True
        self._emulator.stop()

    def _show_context(self) -> None:
        """Show current execution context."""
        emu = self._emulator

        # Disassembly
        print("\nDisassembly:")
        print(emu.disassemble_at(emu.cpu.pc, count=5))

        # Registers (abbreviated)
        print("\nRegisters:")
        print(f"  PC = {emu.cpu.pc:#x}")
        print(f"  SP = {emu.cpu.sp:#x}")
        print(f"  LR = {emu.cpu.lr:#x}")

    def add_breakpoint(
        self,
        address: int,
        condition: Callable | None = None,
        temporary: bool = False,
    ) -> Breakpoint:
        """
        Add a breakpoint.
        
        Args:
            address: Address to break at
            condition: Optional condition function (receives emulator)
            temporary: If True, breakpoint is removed after first hit
        
        Returns:
            The created Breakpoint
        """
        self._breakpoint_counter += 1
        bp = Breakpoint(
            id=self._breakpoint_counter,
            address=address,
            condition=condition,
            temporary=temporary,
        )
        self._breakpoints[address] = bp
        print(f"[+] Breakpoint {bp.id} set at {address:#x}")
        return bp

    def remove_breakpoint(self, bp_id: int) -> bool:
        """Remove a breakpoint by ID."""
        for addr, bp in list(self._breakpoints.items()):
            if bp.id == bp_id:
                del self._breakpoints[addr]
                print(f"[-] Breakpoint {bp_id} removed")
                return True
        return False

    def enable_breakpoint(self, bp_id: int) -> bool:
        """Enable a breakpoint."""
        for bp in self._breakpoints.values():
            if bp.id == bp_id:
                bp.enabled = True
                return True
        return False

    def disable_breakpoint(self, bp_id: int) -> bool:
        """Disable a breakpoint."""
        for bp in self._breakpoints.values():
            if bp.id == bp_id:
                bp.enabled = False
                return True
        return False

    def list_breakpoints(self) -> list[Breakpoint]:
        """List all breakpoints."""
        return list(self._breakpoints.values())

    def step_into(self) -> None:
        """Step to next instruction."""
        self._step_mode = True
        self._paused = False
        self._emulator.step(1)

    def step_over(self) -> None:
        """Step over function calls."""
        # Check if current instruction is a call
        pc = self._emulator.cpu.pc
        disasm = self._emulator.disassemble(pc, count=1)

        if disasm:
            _, mnemonic, _ = disasm[0]
            if mnemonic.lower() in ("bl", "blr", "blx", "call"):
                # Set temporary breakpoint at next instruction
                next_addr = pc + 4  # Assuming 4-byte instructions
                self.add_breakpoint(next_addr, temporary=True)
                self._paused = False
                self._emulator.run(pc, 0)
                return

        # Not a call, just step
        self.step_into()

    def step_out(self) -> None:
        """Step out of current function."""
        # Set breakpoint at return address
        lr = self._emulator.cpu.lr
        self.add_breakpoint(lr, temporary=True)
        self._paused = False
        self._emulator.run(self._emulator.cpu.pc, 0)

    def continue_execution(self) -> None:
        """Continue execution."""
        self._paused = False
        self._emulator.run(self._emulator.cpu.pc, 0)

    def show_registers(self) -> None:
        """Display all registers."""
        print(self._emulator.cpu)

    def show_memory(self, address: int, size: int = 64) -> None:
        """Display memory at address."""
        print(self._emulator.hexdump(address, size))

    def show_disassembly(self, address: int | None = None, count: int = 10) -> None:
        """Display disassembly."""
        if address is None:
            address = self._emulator.cpu.pc
        print(self._emulator.disassemble_at(address, count))

    def show_stack(self, count: int = 8) -> None:
        """Display stack contents."""
        sp = self._emulator.cpu.sp
        ptr_size = self._emulator.pointer_size

        print(f"Stack (SP = {sp:#x}):")
        for i in range(count):
            addr = sp + (i * ptr_size)
            value = self._emulator.memory.read_ptr(addr)
            print(f"  [{i:2d}] {addr:#x}: {value:#x}")

    def read_memory(self, address: int, size: int) -> bytes:
        """Read memory."""
        return self._emulator.memory.read(address, size)

    def write_memory(self, address: int, data: bytes) -> None:
        """Write memory."""
        self._emulator.memory.write(address, data)

    def get_register(self, name: str) -> int:
        """Get register by name."""
        return getattr(self._emulator.cpu, name.lower(), None)

    def set_register(self, name: str, value: int) -> None:
        """Set register by name."""
        setattr(self._emulator.cpu, name.lower(), value)

    @property
    def is_paused(self) -> bool:
        """Check if debugger is paused."""
        return self._paused


def debug_shell(emu: Emulator) -> None:
    """
    Start an interactive debug shell.
    
    Commands:
        b/break <addr>  - Set breakpoint
        d/delete <id>   - Delete breakpoint
        bl/breaklist    - List breakpoints
        s/step          - Step into
        n/next          - Step over
        finish          - Step out
        c/continue      - Continue
        r/regs          - Show registers
        x <addr> <len>  - Examine memory
        disas [addr]    - Disassembly
        stack           - Show stack
        q/quit          - Quit
    """
    dbg = Debugger(emu)

    print("PyUniDbg Debug Shell")
    print("Type 'help' for commands")
    print()

    while True:
        try:
            cmd = input("(pyunidbg) ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if not cmd:
            continue

        parts = cmd.split()
        command = parts[0].lower()
        args = parts[1:]

        try:
            if command in ("b", "break"):
                if args:
                    addr = int(args[0], 0)
                    dbg.add_breakpoint(addr)
                else:
                    print("Usage: break <address>")

            elif command in ("d", "delete"):
                if args:
                    bp_id = int(args[0])
                    dbg.remove_breakpoint(bp_id)
                else:
                    print("Usage: delete <breakpoint_id>")

            elif command in ("bl", "breaklist"):
                bps = dbg.list_breakpoints()
                if bps:
                    for bp in bps:
                        status = "enabled" if bp.enabled else "disabled"
                        print(f"  {bp.id}: {bp.address:#x} ({status}, hits={bp.hit_count})")
                else:
                    print("No breakpoints")

            elif command in ("s", "step", "si"):
                dbg.step_into()

            elif command in ("n", "next", "ni"):
                dbg.step_over()

            elif command == "finish":
                dbg.step_out()

            elif command in ("c", "continue"):
                dbg.continue_execution()

            elif command in ("r", "regs", "registers"):
                dbg.show_registers()

            elif command in ("x", "examine"):
                if len(args) >= 1:
                    addr = int(args[0], 0)
                    size = int(args[1], 0) if len(args) > 1 else 64
                    dbg.show_memory(addr, size)
                else:
                    print("Usage: x <address> [size]")

            elif command in ("disas", "disassemble"):
                addr = int(args[0], 0) if args else None
                dbg.show_disassembly(addr)

            elif command == "stack":
                dbg.show_stack()

            elif command == "help":
                print(debug_shell.__doc__)

            elif command in ("q", "quit", "exit"):
                break

            else:
                print(f"Unknown command: {command}")

        except Exception as e:
            print(f"Error: {e}")

    print("Bye!")
