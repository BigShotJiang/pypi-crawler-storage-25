"""Debugging utilities for PyUniDbg."""

from pyunidbg.debug.dap_server import (
    DAPMessage,
    DAPMessageType,
    DAPServer,
    LLDBExtensions,
    create_dap_server,
    install_lldb_extensions,
)
from pyunidbg.debug.debugger import Debugger
from pyunidbg.debug.gdb_commands import GDBCommandHandler, StopEvent, StopReason
from pyunidbg.debug.gdb_protocol import GDBPacket, GDBProtocol, GDBResponse, GDBSignal, PacketType
from pyunidbg.debug.gdb_server import Breakpoint, GDBServer, Watchpoint, create_gdb_server
from pyunidbg.debug.gdb_target import GDBTarget, RegisterDef, RegisterMapper, TargetArch
from pyunidbg.debug.tracer import Tracer

__all__ = [
    "Debugger",
    "Tracer",
    # GDB Remote Protocol
    "GDBServer",
    "create_gdb_server",
    "Breakpoint",
    "Watchpoint",
    "GDBProtocol",
    "GDBPacket",
    "PacketType",
    "GDBResponse",
    "GDBSignal",
    "GDBTarget",
    "RegisterMapper",
    "TargetArch",
    "RegisterDef",
    "GDBCommandHandler",
    "StopEvent",
    "StopReason",
    # Debug Adapter Protocol (VS Code)
    "DAPServer",
    "DAPMessage",
    "DAPMessageType",
    "create_dap_server",
    # LLDB Extensions
    "LLDBExtensions",
    "install_lldb_extensions",
]
