"""
GDB Remote Protocol Server.

Implements a GDB stub server that allows external debuggers to connect
and debug emulated code in PyUniDbg.

Usage:
    from pyunidbg import Emulator
    from pyunidbg.debug import GDBServer
    
    emu = Emulator(arch='arm64')
    emu.load_library("libnative.so")
    
    # Start GDB server on port 1234
    gdb = GDBServer(emu, port=1234)
    gdb.start()
    
    # Connect with: gdb -ex "target remote :1234"
"""

import logging
import select
import socket
import threading
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

from .gdb_commands import GDBCommandHandler, StopEvent, StopReason
from .gdb_protocol import GDBPacket, GDBProtocol, GDBSignal, PacketType
from .gdb_target import GDBTarget, RegisterMapper, TargetArch

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


class ServerState(Enum):
    """GDB server state."""
    STOPPED = "stopped"
    STARTING = "starting"
    RUNNING = "running"
    CONNECTED = "connected"
    DEBUGGING = "debugging"
    SHUTTING_DOWN = "shutting_down"


@dataclass
class Breakpoint:
    """Breakpoint definition."""
    address: int
    hardware: bool = False
    enabled: bool = True
    hit_count: int = 0
    original_byte: int | None = None  # For software breakpoints

    def __hash__(self):
        return hash(self.address)


@dataclass
class Watchpoint:
    """Watchpoint (data breakpoint) definition."""
    address: int
    size: int
    read: bool = False
    write: bool = False
    enabled: bool = True
    hit_count: int = 0

    def __hash__(self):
        return hash((self.address, self.size))


class GDBServer:
    """
    GDB Remote Protocol Server.
    
    Implements the GDB stub protocol allowing external debuggers
    (GDB, LLDB, IDA Pro, Ghidra, etc.) to debug emulated code.
    """

    # ARM breakpoint instructions
    ARM_BKPT = bytes([0x70, 0x00, 0x20, 0xE1])  # BKPT #0
    ARM_THUMB_BKPT = bytes([0x00, 0xBE])  # BKPT #0 (Thumb)
    ARM64_BRK = bytes([0x00, 0x00, 0x20, 0xD4])  # BRK #0

    def __init__(
        self,
        emulator: 'Emulator',
        host: str = 'localhost',
        port: int = 1234,
        arch: str | None = None
    ):
        """
        Initialize GDB server.
        
        Args:
            emulator: PyUniDbg emulator instance
            host: Host to bind to (default: localhost)
            port: Port to listen on (default: 1234)
            arch: Architecture override ('arm', 'arm64', etc.)
        """
        self.emulator = emulator
        self.host = host
        self.port = port

        # Determine architecture
        if arch:
            self._arch = TargetArch(arch)
        else:
            # Auto-detect from emulator
            self._arch = self._detect_arch()

        # Protocol and target
        self.protocol = GDBProtocol(ack_mode=True)
        self.target = GDBTarget(self._arch)
        self.reg_mapper = RegisterMapper(self._arch)

        # Command handler
        self.handler = GDBCommandHandler(self)

        # Server state
        self.state = ServerState.STOPPED
        self._socket: socket.socket | None = None
        self._client: socket.socket | None = None
        self._thread: threading.Thread | None = None
        self._running = False
        self._recv_buffer = bytearray()

        # Breakpoints and watchpoints
        self._breakpoints: dict[int, Breakpoint] = {}
        self._watchpoints: dict[int, Watchpoint] = {}

        # Execution state
        self._stop_requested = False

        # Monitor commands
        self._monitor_commands: dict[str, Callable[[str], str]] = {
            'help': self._monitor_help,
            'reset': self._monitor_reset,
            'info': self._monitor_info,
            'regs': self._monitor_regs,
        }

    def _detect_arch(self) -> TargetArch:
        """Detect architecture from emulator."""
        arch = getattr(self.emulator, 'arch', 'arm64')
        if arch in ('arm', 'arm32'):
            return TargetArch.ARM
        elif arch in ('arm64', 'aarch64'):
            return TargetArch.ARM64
        else:
            return TargetArch.ARM64  # Default

    @property
    def is_running(self) -> bool:
        """Check if server is running."""
        return self.state in (ServerState.RUNNING, ServerState.CONNECTED, ServerState.DEBUGGING)

    @property
    def is_connected(self) -> bool:
        """Check if a client is connected."""
        return self.state in (ServerState.CONNECTED, ServerState.DEBUGGING)

    def start(self, blocking: bool = False) -> bool:
        """
        Start the GDB server.
        
        Args:
            blocking: If True, block until server stops
            
        Returns:
            True if server started successfully
        """
        if self.is_running:
            logger.warning("GDB server already running")
            return False

        try:
            self.state = ServerState.STARTING

            # Create server socket
            self._socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._socket.bind((self.host, self.port))
            self._socket.listen(1)
            self._socket.settimeout(1.0)  # For clean shutdown

            self._running = True
            self.state = ServerState.RUNNING

            logger.info(f"GDB server listening on {self.host}:{self.port}")
            print(f"GDB server listening on {self.host}:{self.port}")
            print(f"Connect with: gdb -ex 'target remote {self.host}:{self.port}'")

            if blocking:
                self._server_loop()
            else:
                self._thread = threading.Thread(target=self._server_loop, daemon=True)
                self._thread.start()

            return True

        except Exception as e:
            logger.error(f"Failed to start GDB server: {e}")
            self.state = ServerState.STOPPED
            return False

    def stop(self):
        """Stop the GDB server."""
        if not self._running:
            return

        logger.info("Stopping GDB server...")
        self.state = ServerState.SHUTTING_DOWN
        self._running = False

        # Close client connection
        if self._client:
            try:
                self._client.close()
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
            self._client = None

        # Close server socket
        if self._socket:
            try:
                self._socket.close()
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
            self._socket = None

        # Wait for thread
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2.0)

        self.state = ServerState.STOPPED
        logger.info("GDB server stopped")

    def _server_loop(self):
        """Main server loop."""
        while self._running:
            try:
                # Wait for connection
                if not self._client:
                    try:
                        self._client, addr = self._socket.accept()
                        self._client.setblocking(False)
                        self.state = ServerState.CONNECTED
                        logger.info(f"Client connected from {addr}")

                        # Set initial stop event
                        self.handler.last_stop = StopEvent(
                            StopReason.SIGNAL,
                            signal=GDBSignal.SIGTRAP
                        )
                    except TimeoutError:
                        continue
                    except OSError:
                        break

                # Handle client
                self._handle_client()

            except Exception as e:
                logger.error(f"Server loop error: {e}")
                if self._client:
                    try:
                        self._client.close()
                    except Exception:
                        logger.debug("Exception suppressed", exc_info=True)
                    self._client = None
                    self.state = ServerState.RUNNING

    def _handle_client(self):
        """Handle connected client."""
        if not self._client:
            return

        try:
            # Check for incoming data
            ready, _, _ = select.select([self._client], [], [], 0.1)
            if not ready:
                return

            # Receive data
            data = self._client.recv(4096)
            if not data:
                # Client disconnected
                logger.info("Client disconnected")
                self._client.close()
                self._client = None
                self.state = ServerState.RUNNING
                return

            # Add to buffer
            self._recv_buffer.extend(data)

            # Parse packets
            packets, self._recv_buffer = self.protocol.parse_all_packets(
                bytes(self._recv_buffer)
            )
            self._recv_buffer = bytearray(self._recv_buffer)

            # Handle packets
            for packet in packets:
                self._handle_packet(packet)

        except BlockingIOError:
            pass
        except Exception as e:
            logger.error(f"Error handling client: {e}")

    def _handle_packet(self, packet: GDBPacket):
        """Handle a received packet."""
        if packet.type == PacketType.ACK:
            return

        if packet.type == PacketType.NACK:
            logger.warning("Received NACK, client wants retransmit")
            return

        if packet.type == PacketType.INTERRUPT:
            logger.debug("Received interrupt (Ctrl-C)")
            self._stop_requested = True
            return

        if packet.type == PacketType.DATA:
            if not packet.valid:
                self._send_nack()
                return

            # Send ACK if in ack mode
            if self.protocol.ack_mode:
                self._send_ack()

            # Handle command
            response = self.handler.handle_command(packet.data)
            self._send_packet(response)

    def _send_packet(self, data: str):
        """Send a packet to the client."""
        if not self._client:
            return

        packet = self.protocol.create_packet(data)
        try:
            self._client.sendall(packet)
        except Exception as e:
            logger.error(f"Error sending packet: {e}")

    def _send_ack(self):
        """Send acknowledgment."""
        if self._client:
            try:
                self._client.sendall(b'+')
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

    def _send_nack(self):
        """Send negative acknowledgment."""
        if self._client:
            try:
                self._client.sendall(b'-')
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

    # === Breakpoint Management ===

    def add_breakpoint(self, address: int, hardware: bool = False) -> bool:
        """
        Add a breakpoint.
        
        Args:
            address: Address to break at
            hardware: If True, use hardware breakpoint
            
        Returns:
            True if breakpoint was added
        """
        if address in self._breakpoints:
            return True

        bp = Breakpoint(address=address, hardware=hardware)

        if not hardware:
            # Save original instruction for software breakpoint
            try:
                bp.original_byte = self.emulator.mem_read(address, 1)[0]
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        self._breakpoints[address] = bp
        logger.debug(f"Added breakpoint at 0x{address:x}")
        return True

    def remove_breakpoint(self, address: int) -> bool:
        """
        Remove a breakpoint.
        
        Args:
            address: Address of breakpoint to remove
            
        Returns:
            True if breakpoint was removed
        """
        if address not in self._breakpoints:
            return False

        del self._breakpoints[address]
        logger.debug(f"Removed breakpoint at 0x{address:x}")
        return True

    def add_watchpoint(
        self,
        address: int,
        size: int,
        read: bool = False,
        write: bool = False
    ) -> bool:
        """
        Add a watchpoint (data breakpoint).
        
        Args:
            address: Address to watch
            size: Size of watched region
            read: Break on read
            write: Break on write
            
        Returns:
            True if watchpoint was added
        """
        wp = Watchpoint(
            address=address,
            size=size,
            read=read,
            write=write
        )
        self._watchpoints[address] = wp
        logger.debug(f"Added watchpoint at 0x{address:x}, size={size}")
        return True

    def remove_watchpoint(self, address: int) -> bool:
        """
        Remove a watchpoint.
        
        Args:
            address: Address of watchpoint to remove
            
        Returns:
            True if watchpoint was removed
        """
        if address not in self._watchpoints:
            return False

        del self._watchpoints[address]
        logger.debug(f"Removed watchpoint at 0x{address:x}")
        return True

    # === Execution Control ===

    def continue_execution(self, address: int | None = None) -> StopEvent:
        """
        Continue execution until breakpoint or interrupt.
        
        Args:
            address: Optional address to continue from
            
        Returns:
            StopEvent describing why execution stopped
        """
        self._stop_requested = False

        # Set PC if address provided
        if address is not None:
            self._set_pc(address)

        try:
            # Install breakpoint hooks
            self._install_breakpoint_hooks()

            # Run emulation
            pc = self._get_pc()

            # Simple execution - run until we hit something
            # In a real implementation, you'd hook into Unicorn's hooks
            while not self._stop_requested:
                current_pc = self._get_pc()

                # Check breakpoints
                if current_pc in self._breakpoints:
                    bp = self._breakpoints[current_pc]
                    bp.hit_count += 1
                    return StopEvent(
                        reason=StopReason.BREAKPOINT,
                        address=current_pc
                    )

                # Single step
                try:
                    self.emulator.emu_start(current_pc, current_pc + 4, count=1)
                except Exception as e:
                    logger.debug(f"Execution stopped: {e}")
                    return StopEvent(
                        reason=StopReason.SIGNAL,
                        signal=GDBSignal.SIGSEGV
                    )

                # Check for interrupt
                if self._check_interrupt():
                    break

            return StopEvent(
                reason=StopReason.SIGNAL,
                signal=GDBSignal.SIGINT
            )

        finally:
            self._remove_breakpoint_hooks()

    def single_step(self, address: int | None = None) -> StopEvent:
        """
        Execute a single instruction.
        
        Args:
            address: Optional address to step from
            
        Returns:
            StopEvent after stepping
        """
        # Set PC if address provided
        if address is not None:
            self._set_pc(address)

        pc = self._get_pc()

        try:
            # Execute single instruction
            self.emulator.emu_start(pc, pc + 4, count=1)

            return StopEvent(
                reason=StopReason.STEP,
                address=self._get_pc()
            )
        except Exception as e:
            logger.debug(f"Step failed: {e}")
            return StopEvent(
                reason=StopReason.SIGNAL,
                signal=GDBSignal.SIGSEGV
            )

    def _get_pc(self) -> int:
        """Get current program counter."""
        if self._arch == TargetArch.ARM:
            from unicorn import arm_const
            return self.emulator.reg_read(arm_const.UC_ARM_REG_PC)
        else:
            from unicorn import arm64_const
            return self.emulator.reg_read(arm64_const.UC_ARM64_REG_PC)

    def _set_pc(self, value: int):
        """Set program counter."""
        if self._arch == TargetArch.ARM:
            from unicorn import arm_const
            self.emulator.reg_write(arm_const.UC_ARM_REG_PC, value)
        else:
            from unicorn import arm64_const
            self.emulator.reg_write(arm64_const.UC_ARM64_REG_PC, value)

    def _install_breakpoint_hooks(self):
        """Install hooks for breakpoint handling."""
        from unicorn import UC_HOOK_CODE

        def breakpoint_hook(uc, address, size, user_data):
            """Check if we hit a breakpoint."""
            if address in self._breakpoints:
                bp = self._breakpoints[address]
                if bp.enabled:
                    bp.hit_count += 1
                    self._stop_requested = True
                    logger.debug(f"Breakpoint hit at 0x{address:x} (count={bp.hit_count})")
                    return False  # Stop execution
            # Check watchpoints for fetch access
            for wp in self._watchpoints.values():
                if wp.enabled and wp.address <= address < wp.address + wp.size:
                    wp.hit_count += 1
                    self._stop_requested = True
                    logger.debug(f"Watchpoint hit at 0x{address:x}")
                    return False
            return True

        self._bp_hook_handle = self.emulator._uc.hook_add(
            UC_HOOK_CODE,
            breakpoint_hook,
            user_data=self
        )

    def _remove_breakpoint_hooks(self):
        """Remove breakpoint hooks."""
        if hasattr(self, '_bp_hook_handle') and self._bp_hook_handle:
            try:
                self.emulator._uc.hook_del(self._bp_hook_handle)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
            self._bp_hook_handle = None

    def _check_interrupt(self) -> bool:
        """Check for pending interrupt from client."""
        if not self._client:
            return self._stop_requested

        try:
            ready, _, _ = select.select([self._client], [], [], 0)
            if ready:
                data = self._client.recv(1, socket.MSG_PEEK)
                if data and data[0] == 0x03:  # Ctrl-C
                    self._client.recv(1)
                    self._stop_requested = True
                    return True
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        return self._stop_requested

    # === Session Control ===

    def detach(self):
        """Detach from target."""
        logger.info("Detaching from target")
        if self._client:
            try:
                self._client.close()
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
            self._client = None
        self.state = ServerState.RUNNING

    def kill(self):
        """Kill target."""
        logger.info("Kill requested")
        self.stop()

    # === Monitor Commands ===

    def handle_monitor_command(self, command: str) -> str:
        """
        Handle a monitor command from GDB.
        
        Args:
            command: Command string
            
        Returns:
            Response string
        """
        parts = command.strip().split()
        if not parts:
            return self._monitor_help("")

        cmd = parts[0].lower()
        args = ' '.join(parts[1:])

        handler = self._monitor_commands.get(cmd)
        if handler:
            return handler(args)

        return f"Unknown monitor command: {cmd}\nType 'monitor help' for help."

    def _monitor_help(self, args: str) -> str:
        """Help command."""
        return """PyUniDbg GDB Monitor Commands:
  help   - Show this help
  reset  - Reset emulator state  
  info   - Show emulator info
  regs   - Show registers
"""

    def _monitor_reset(self, args: str) -> str:
        """Reset emulator state."""
        try:
            # Clear breakpoints and watchpoints
            self._breakpoints.clear()
            self._watchpoints.clear()

            # Reset stop state
            self._stop_requested = False

            # Reset CPU state if emulator supports it
            if hasattr(self.emulator, '_setup_initial_state'):
                self.emulator._setup_initial_state()

            # Re-install hooks
            self._remove_breakpoint_hooks()
            self._install_breakpoint_hooks()

            logger.info("Emulator state reset via GDB monitor")
            return "Emulator state reset successfully"
        except Exception as e:
            logger.error(f"Reset failed: {e}")
            return f"Reset failed: {e}"

    def _monitor_info(self, args: str) -> str:
        """Show info."""
        return f"""PyUniDbg Emulator Info:
  Architecture: {self._arch.value}
  Breakpoints: {len(self._breakpoints)}
  Watchpoints: {len(self._watchpoints)}
"""

    def _monitor_regs(self, args: str) -> str:
        """Show registers."""
        lines = ["Registers:"]
        for reg in self.target.registers[:16]:  # First 16 regs
            try:
                uc_reg = self.reg_mapper.gdb_to_unicorn(reg.regnum)
                if uc_reg:
                    value = self.emulator.reg_read(uc_reg)
                    lines.append(f"  {reg.name:4s} = 0x{value:016x}")
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        return '\n'.join(lines)

    def register_monitor_command(
        self,
        name: str,
        handler: Callable[[str], str]
    ):
        """
        Register a custom monitor command.
        
        Args:
            name: Command name
            handler: Handler function(args) -> response
        """
        self._monitor_commands[name.lower()] = handler


# Convenience function
def create_gdb_server(
    emulator: 'Emulator',
    port: int = 1234,
    **kwargs
) -> GDBServer:
    """
    Create a GDB server for the emulator.
    
    Args:
        emulator: PyUniDbg emulator instance
        port: Port to listen on
        **kwargs: Additional arguments for GDBServer
        
    Returns:
        GDBServer instance
    """
    return GDBServer(emulator, port=port, **kwargs)
