"""
GDB Remote Serial Protocol (RSP) implementation.

This module handles the low-level protocol details of GDB RSP:
- Packet framing ($packet#checksum)
- Acknowledgment handling (+/-)
- Escape sequences
- Packet encoding/decoding
"""

import logging
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class PacketType(Enum):
    """GDB packet types."""
    DATA = "data"
    ACK = "ack"
    NACK = "nack"
    INTERRUPT = "interrupt"
    NOTIFICATION = "notification"


@dataclass
class GDBPacket:
    """Represents a GDB RSP packet."""
    type: PacketType
    data: str = ""
    checksum: int = 0
    valid: bool = True

    def __repr__(self) -> str:
        if self.type == PacketType.DATA:
            return f"GDBPacket(${self.data}#{self.checksum:02x})"
        return f"GDBPacket({self.type.value})"


class GDBProtocol:
    """
    GDB Remote Serial Protocol handler.
    
    Handles packet framing, checksums, and acknowledgments.
    """

    # Special characters
    PACKET_START = ord('$')
    PACKET_END = ord('#')
    ESCAPE = ord('}')
    RUN_LENGTH_START = ord('*')
    ACK = ord('+')
    NACK = ord('-')
    INTERRUPT = 0x03  # Ctrl-C
    NOTIFICATION_START = ord('%')

    # Characters that need escaping
    ESCAPE_CHARS = {ord('$'), ord('#'), ord('}'), ord('*')}
    ESCAPE_XOR = 0x20

    def __init__(self, ack_mode: bool = True):
        """
        Initialize GDB protocol handler.
        
        Args:
            ack_mode: Whether to use acknowledgment mode (default True)
        """
        self.ack_mode = ack_mode
        self._buffer = bytearray()
        self._in_packet = False
        self._packet_data = bytearray()
        self._expecting_checksum = False
        self._checksum_chars = bytearray()

    @staticmethod
    def calculate_checksum(data: bytes) -> int:
        """Calculate GDB checksum (sum of bytes mod 256)."""
        return sum(data) & 0xFF

    @staticmethod
    def encode_hex(data: bytes) -> str:
        """Encode bytes as hex string."""
        return data.hex()

    @staticmethod
    def decode_hex(hex_str: str) -> bytes:
        """Decode hex string to bytes."""
        try:
            return bytes.fromhex(hex_str)
        except ValueError:
            return b""

    @staticmethod
    def encode_hex_byte(value: int) -> str:
        """Encode a single byte as 2-char hex."""
        return f"{value & 0xFF:02x}"

    @staticmethod
    def decode_hex_byte(hex_str: str) -> int:
        """Decode 2-char hex to int."""
        try:
            return int(hex_str, 16)
        except ValueError:
            return 0

    def escape_data(self, data: bytes) -> bytes:
        """Escape special characters in packet data."""
        result = bytearray()
        for b in data:
            if b in self.ESCAPE_CHARS:
                result.append(self.ESCAPE)
                result.append(b ^ self.ESCAPE_XOR)
            else:
                result.append(b)
        return bytes(result)

    def unescape_data(self, data: bytes) -> bytes:
        """Unescape special characters in packet data."""
        result = bytearray()
        i = 0
        while i < len(data):
            if data[i] == self.ESCAPE and i + 1 < len(data):
                result.append(data[i + 1] ^ self.ESCAPE_XOR)
                i += 2
            else:
                result.append(data[i])
                i += 1
        return bytes(result)

    def decode_run_length(self, data: bytes) -> bytes:
        """Decode run-length encoded data."""
        result = bytearray()
        i = 0
        while i < len(data):
            if i + 2 < len(data) and data[i + 1] == self.RUN_LENGTH_START:
                # Run-length encoding: char * count
                # Count is encoded as (char - 29), minimum 4 repetitions
                char = data[i]
                count = data[i + 2] - 29
                result.extend([char] * count)
                i += 3
            else:
                result.append(data[i])
                i += 1
        return bytes(result)

    def encode_run_length(self, data: bytes) -> bytes:
        """Apply run-length encoding to data (optional optimization)."""
        # For simplicity, we don't apply RLE in encoding
        # GDB clients can handle uncompressed data fine
        return data

    def create_packet(self, data: str) -> bytes:
        """
        Create a complete GDB packet with framing and checksum.
        
        Args:
            data: Packet payload (unescaped)
            
        Returns:
            Complete packet bytes: $data#xx
        """
        data_bytes = data.encode('latin-1')
        escaped = self.escape_data(data_bytes)
        checksum = self.calculate_checksum(escaped)
        return b'$' + escaped + b'#' + f"{checksum:02x}".encode('ascii')

    def create_notification(self, data: str) -> bytes:
        """
        Create a notification packet (async event).
        
        Args:
            data: Notification payload
            
        Returns:
            Complete notification bytes: %data#xx
        """
        data_bytes = data.encode('latin-1')
        escaped = self.escape_data(data_bytes)
        checksum = self.calculate_checksum(escaped)
        return b'%' + escaped + b'#' + f"{checksum:02x}".encode('ascii')

    def create_ack(self) -> bytes:
        """Create acknowledgment packet."""
        return b'+'

    def create_nack(self) -> bytes:
        """Create negative acknowledgment packet."""
        return b'-'

    def parse_packet(self, raw: bytes) -> tuple[GDBPacket | None, bytes]:
        """
        Parse a GDB packet from raw bytes.
        
        Args:
            raw: Raw bytes that may contain a packet
            
        Returns:
            Tuple of (parsed packet or None, remaining bytes)
        """
        if not raw:
            return None, raw

        # Handle single-byte packets
        if raw[0] == self.ACK:
            return GDBPacket(PacketType.ACK), raw[1:]
        if raw[0] == self.NACK:
            return GDBPacket(PacketType.NACK), raw[1:]
        if raw[0] == self.INTERRUPT:
            return GDBPacket(PacketType.INTERRUPT), raw[1:]

        # Handle data packets
        if raw[0] == self.PACKET_START or raw[0] == self.NOTIFICATION_START:
            is_notification = raw[0] == self.NOTIFICATION_START

            # Find packet end
            end_idx = -1
            for i in range(1, len(raw)):
                if raw[i] == self.PACKET_END:
                    end_idx = i
                    break

            if end_idx == -1:
                # Incomplete packet
                return None, raw

            # Need 2 more bytes for checksum
            if end_idx + 2 >= len(raw):
                return None, raw

            # Extract data and checksum
            data = raw[1:end_idx]
            checksum_str = raw[end_idx + 1:end_idx + 3]

            try:
                received_checksum = int(checksum_str, 16)
            except ValueError:
                logger.warning(f"Invalid checksum format: {checksum_str}")
                return GDBPacket(PacketType.DATA, valid=False), raw[end_idx + 3:]

            # Verify checksum
            calculated_checksum = self.calculate_checksum(data)
            valid = received_checksum == calculated_checksum

            if not valid:
                logger.warning(
                    f"Checksum mismatch: received {received_checksum:02x}, "
                    f"calculated {calculated_checksum:02x}"
                )

            # Unescape and decode
            unescaped = self.unescape_data(data)
            decoded = self.decode_run_length(unescaped)

            packet_type = PacketType.NOTIFICATION if is_notification else PacketType.DATA
            return GDBPacket(
                type=packet_type,
                data=decoded.decode('latin-1'),
                checksum=received_checksum,
                valid=valid
            ), raw[end_idx + 3:]

        # Unknown byte, skip it
        logger.warning(f"Unexpected byte in stream: 0x{raw[0]:02x}")
        return None, raw[1:]

    def parse_all_packets(self, raw: bytes) -> tuple[list[GDBPacket], bytes]:
        """
        Parse all complete packets from raw bytes.
        
        Args:
            raw: Raw bytes that may contain multiple packets
            
        Returns:
            Tuple of (list of parsed packets, remaining bytes)
        """
        packets = []
        remaining = raw

        while remaining:
            packet, remaining = self.parse_packet(remaining)
            if packet is None:
                break
            packets.append(packet)

        return packets, remaining


# Common response helpers
class GDBResponse:
    """Helper class for creating common GDB responses."""

    @staticmethod
    def ok() -> str:
        """Success response."""
        return "OK"

    @staticmethod
    def error(code: int = 1) -> str:
        """Error response with code."""
        return f"E{code:02x}"

    @staticmethod
    def empty() -> str:
        """Empty response (unsupported command)."""
        return ""

    @staticmethod
    def hex_bytes(data: bytes) -> str:
        """Bytes as hex string."""
        return data.hex()

    @staticmethod
    def hex_value(value: int, size: int = 8) -> str:
        """Integer as hex string (little-endian for memory)."""
        return value.to_bytes(size, 'little').hex()

    @staticmethod
    def stop_reply(signal: int = 5, thread: int = 1) -> str:
        """
        Stop reply packet.
        
        Args:
            signal: Signal number (5 = SIGTRAP for breakpoint)
            thread: Thread ID
        """
        return f"T{signal:02x}thread:{thread:x};"

    @staticmethod
    def exit_reply(code: int = 0) -> str:
        """Process exit reply."""
        return f"W{code:02x}"

    @staticmethod
    def signal_reply(signal: int) -> str:
        """Process terminated by signal."""
        return f"X{signal:02x}"


# Signal numbers (POSIX)
class GDBSignal:
    """Common signal numbers used in GDB protocol."""
    SIGHUP = 1
    SIGINT = 2
    SIGQUIT = 3
    SIGILL = 4
    SIGTRAP = 5  # Breakpoint/single-step
    SIGABRT = 6
    SIGBUS = 7
    SIGFPE = 8
    SIGKILL = 9
    SIGUSR1 = 10
    SIGSEGV = 11
    SIGUSR2 = 12
    SIGPIPE = 13
    SIGALRM = 14
    SIGTERM = 15
    SIGSTOP = 17
    SIGCONT = 19
