"""
Network Emulation for PyUniDbg.

Provides a virtual network stack that intercepts network syscalls
and allows controlled network simulation for testing applications.

Features:
- Virtual sockets (TCP, UDP, Unix)
- DNS resolution emulation
- HTTP/HTTPS interception
- Network condition simulation (latency, packet loss)
- Traffic recording and replay

Usage:
    from pyunidbg.net import VirtualNetwork, VirtualSocket
    
    net = VirtualNetwork()
    
    # Add DNS mappings
    net.add_dns("api.example.com", "192.168.1.100")
    
    # Add mock server responses
    net.add_response("192.168.1.100", 443, b"HTTP/1.1 200 OK\\r\\n...")
    
    # Hook to emulator
    emu.set_network(net)
"""

import logging
import socket as real_socket
import struct
import threading
import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, IntEnum, auto
from typing import Any, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)


class SocketDomain(IntEnum):
    """Socket address families."""
    AF_UNSPEC = 0
    AF_UNIX = 1
    AF_LOCAL = 1
    AF_INET = 2
    AF_INET6 = 10
    AF_NETLINK = 16
    AF_PACKET = 17


class SocketType(IntEnum):
    """Socket types."""
    SOCK_STREAM = 1     # TCP
    SOCK_DGRAM = 2      # UDP
    SOCK_RAW = 3        # Raw
    SOCK_SEQPACKET = 5  # Sequential packet


class SocketProtocol(IntEnum):
    """IP protocols."""
    IPPROTO_IP = 0
    IPPROTO_ICMP = 1
    IPPROTO_TCP = 6
    IPPROTO_UDP = 17


class SocketOption(IntEnum):
    """Socket options."""
    SO_DEBUG = 1
    SO_REUSEADDR = 2
    SO_TYPE = 3
    SO_ERROR = 4
    SO_DONTROUTE = 5
    SO_BROADCAST = 6
    SO_SNDBUF = 7
    SO_RCVBUF = 8
    SO_KEEPALIVE = 9
    SO_OOBINLINE = 10
    SO_LINGER = 13
    SO_RCVTIMEO = 20
    SO_SNDTIMEO = 21


class SocketState(Enum):
    """Socket connection states."""
    CLOSED = auto()
    CREATED = auto()
    BOUND = auto()
    LISTENING = auto()
    CONNECTING = auto()
    CONNECTED = auto()
    CLOSING = auto()


class ShutdownHow(IntEnum):
    """Shutdown modes."""
    SHUT_RD = 0
    SHUT_WR = 1
    SHUT_RDWR = 2


@dataclass
class SocketAddress:
    """Socket address representation."""
    family: SocketDomain = SocketDomain.AF_INET
    port: int = 0
    address: str = "0.0.0.0"

    # For Unix sockets
    path: str | None = None

    def to_sockaddr_in(self) -> bytes:
        """Convert to sockaddr_in structure."""
        if self.family == SocketDomain.AF_INET:
            # struct sockaddr_in
            addr_bytes = real_socket.inet_aton(self.address)
            return struct.pack(
                '!HH4s8s',
                self.family,
                self.port,
                addr_bytes,
                b'\x00' * 8
            )
        elif self.family == SocketDomain.AF_INET6:
            # struct sockaddr_in6
            addr_bytes = real_socket.inet_pton(real_socket.AF_INET6, self.address)
            return struct.pack(
                '!HHI16sI',
                self.family,
                self.port,
                0,  # flowinfo
                addr_bytes,
                0   # scope_id
            )
        elif self.family == SocketDomain.AF_UNIX:
            # struct sockaddr_un
            path_bytes = (self.path or "").encode('utf-8')[:107] + b'\x00'
            return struct.pack('!H', self.family) + path_bytes

        return b''

    @classmethod
    def from_sockaddr(cls, data: bytes) -> 'SocketAddress':
        """Parse from sockaddr structure."""
        if len(data) < 2:
            return cls()

        family = struct.unpack('!H', data[:2])[0]

        if family == SocketDomain.AF_INET:
            port, addr_bytes = struct.unpack('!H4s', data[2:8])
            address = real_socket.inet_ntoa(addr_bytes)
            return cls(SocketDomain.AF_INET, port, address)

        elif family == SocketDomain.AF_INET6:
            port, flowinfo, addr_bytes = struct.unpack('!HI16s', data[2:24])
            address = real_socket.inet_ntop(real_socket.AF_INET6, addr_bytes)
            return cls(SocketDomain.AF_INET6, port, address)

        elif family == SocketDomain.AF_UNIX:
            path = data[2:].split(b'\x00')[0].decode('utf-8', errors='replace')
            return cls(SocketDomain.AF_UNIX, path=path)

        return cls(SocketDomain(family))


@dataclass
class NetworkPacket:
    """A network packet."""
    data: bytes
    src_addr: SocketAddress | None = None
    dst_addr: SocketAddress | None = None
    timestamp: float = field(default_factory=time.time)

    def __len__(self) -> int:
        return len(self.data)


@dataclass
class NetworkStats:
    """Network statistics."""
    sockets_created: int = 0
    sockets_closed: int = 0
    bytes_sent: int = 0
    bytes_received: int = 0
    connections_attempted: int = 0
    connections_established: int = 0
    dns_queries: int = 0
    packets_sent: int = 0
    packets_received: int = 0


@dataclass
class ConnectionRule:
    """Rule for allowing/blocking connections."""
    address_pattern: str  # "*" for any, or specific IP/hostname
    port: int = 0  # 0 for any
    action: str = "allow"  # "allow", "block", "delay", "reset"
    delay_ms: int = 0


class VirtualSocket:
    """
    A virtual socket that mimics real socket behavior.
    
    Intercepts all socket operations and provides controlled
    responses for testing.
    """

    def __init__(
        self,
        fd: int,
        domain: SocketDomain,
        sock_type: SocketType,
        protocol: int,
        network: 'VirtualNetwork'
    ):
        self.fd = fd
        self.domain = domain
        self.sock_type = sock_type
        self.protocol = protocol
        self.network = network

        self.state = SocketState.CREATED
        self.local_addr: SocketAddress | None = None
        self.remote_addr: SocketAddress | None = None

        # Buffers
        self.recv_buffer: deque = deque()
        self.send_buffer: deque = deque()

        # Options
        self.options: dict[int, Any] = {
            SocketOption.SO_RCVBUF: 65536,
            SocketOption.SO_SNDBUF: 65536,
            SocketOption.SO_REUSEADDR: 0,
            SocketOption.SO_KEEPALIVE: 0,
        }

        # Non-blocking mode
        self.blocking = True
        self.timeout: float | None = None

        # For listening sockets
        self.backlog = 0
        self.pending_connections: deque = deque()

        # Statistics
        self.bytes_sent = 0
        self.bytes_received = 0

        # Callbacks
        self.on_connect: Callable | None = None
        self.on_send: Callable | None = None
        self.on_recv: Callable | None = None

    def bind(self, address: SocketAddress) -> int:
        """Bind socket to address."""
        if self.state != SocketState.CREATED:
            return -1  # EINVAL

        self.local_addr = address
        self.state = SocketState.BOUND

        logger.debug(f"Socket {self.fd} bound to {address.address}:{address.port}")
        return 0

    def listen(self, backlog: int = 5) -> int:
        """Start listening for connections."""
        if self.state not in (SocketState.CREATED, SocketState.BOUND):
            return -1

        self.backlog = backlog
        self.state = SocketState.LISTENING

        logger.debug(f"Socket {self.fd} listening with backlog {backlog}")
        return 0

    def accept(self) -> tuple[Optional['VirtualSocket'], SocketAddress | None]:
        """Accept incoming connection."""
        if self.state != SocketState.LISTENING:
            return None, None

        if not self.pending_connections:
            if self.blocking:
                # Would block
                return None, None
            return None, None

        client_addr = self.pending_connections.popleft()

        # Create new socket for connection
        client_socket = self.network.create_socket(
            self.domain, self.sock_type, self.protocol
        )
        client_socket.state = SocketState.CONNECTED
        client_socket.local_addr = self.local_addr
        client_socket.remote_addr = client_addr

        return client_socket, client_addr

    def connect(self, address: SocketAddress) -> int:
        """Connect to remote address."""
        if self.state not in (SocketState.CREATED, SocketState.BOUND):
            return -1  # Already connected or invalid state

        self.network.stats.connections_attempted += 1

        # Check connection rules
        result = self.network._check_connection_allowed(address)
        if result == "block":
            return -1  # ECONNREFUSED
        elif result == "reset":
            return -1  # ECONNRESET

        self.remote_addr = address
        self.state = SocketState.CONNECTING

        # Simulate connection
        if self.on_connect:
            self.on_connect(self, address)

        # Check for mock responses
        response_data = self.network._get_mock_response(address)
        if response_data:
            self.recv_buffer.append(NetworkPacket(response_data, address))

        self.state = SocketState.CONNECTED
        self.network.stats.connections_established += 1

        logger.debug(f"Socket {self.fd} connected to {address.address}:{address.port}")
        return 0

    def send(self, data: bytes, flags: int = 0) -> int:
        """Send data on socket."""
        if self.state != SocketState.CONNECTED:
            return -1  # ENOTCONN

        if self.on_send:
            data = self.on_send(self, data) or data

        packet = NetworkPacket(data, self.local_addr, self.remote_addr)
        self.send_buffer.append(packet)

        self.bytes_sent += len(data)
        self.network.stats.bytes_sent += len(data)
        self.network.stats.packets_sent += 1

        # Record traffic
        self.network._record_traffic(packet, "send")

        logger.debug(f"Socket {self.fd} sent {len(data)} bytes")
        return len(data)

    def sendto(self, data: bytes, address: SocketAddress, flags: int = 0) -> int:
        """Send data to specific address (UDP)."""
        packet = NetworkPacket(data, self.local_addr, address)
        self.send_buffer.append(packet)

        self.bytes_sent += len(data)
        self.network.stats.bytes_sent += len(data)
        self.network.stats.packets_sent += 1

        self.network._record_traffic(packet, "sendto")

        return len(data)

    def recv(self, bufsize: int, flags: int = 0) -> bytes:
        """Receive data from socket."""
        if self.state != SocketState.CONNECTED and self.sock_type == SocketType.SOCK_STREAM:
            return b''

        if not self.recv_buffer:
            if self.blocking:
                # Would block - in real impl would wait
                return b''
            return b''

        packet = self.recv_buffer.popleft()
        data = packet.data[:bufsize]

        # Put back remainder if not all consumed
        if len(packet.data) > bufsize:
            remainder = NetworkPacket(
                packet.data[bufsize:],
                packet.src_addr,
                packet.dst_addr
            )
            self.recv_buffer.appendleft(remainder)

        if self.on_recv:
            data = self.on_recv(self, data) or data

        self.bytes_received += len(data)
        self.network.stats.bytes_received += len(data)
        self.network.stats.packets_received += 1

        logger.debug(f"Socket {self.fd} received {len(data)} bytes")
        return data

    def recvfrom(self, bufsize: int, flags: int = 0) -> tuple[bytes, SocketAddress | None]:
        """Receive data with sender address (UDP)."""
        if not self.recv_buffer:
            return b'', None

        packet = self.recv_buffer.popleft()
        data = packet.data[:bufsize]

        self.bytes_received += len(data)
        self.network.stats.bytes_received += len(data)

        return data, packet.src_addr

    def shutdown(self, how: ShutdownHow) -> int:
        """Shutdown socket."""
        if self.state == SocketState.CLOSED:
            return -1

        self.state = SocketState.CLOSING
        return 0

    def close(self) -> int:
        """Close socket."""
        self.state = SocketState.CLOSED
        self.recv_buffer.clear()
        self.send_buffer.clear()

        self.network.stats.sockets_closed += 1
        logger.debug(f"Socket {self.fd} closed")
        return 0

    def setsockopt(self, level: int, optname: int, value: Any) -> int:
        """Set socket option."""
        self.options[optname] = value
        return 0

    def getsockopt(self, level: int, optname: int) -> Any:
        """Get socket option."""
        return self.options.get(optname, 0)

    def setblocking(self, blocking: bool):
        """Set blocking mode."""
        self.blocking = blocking

    def settimeout(self, timeout: float | None):
        """Set socket timeout."""
        self.timeout = timeout
        self.blocking = timeout is None or timeout > 0

    def getpeername(self) -> SocketAddress | None:
        """Get remote address."""
        return self.remote_addr

    def getsockname(self) -> SocketAddress | None:
        """Get local address."""
        return self.local_addr

    def fileno(self) -> int:
        """Get file descriptor."""
        return self.fd

    # === Data injection for testing ===

    def inject_data(self, data: bytes, from_addr: SocketAddress | None = None):
        """Inject data into receive buffer (for testing)."""
        packet = NetworkPacket(data, from_addr or self.remote_addr)
        self.recv_buffer.append(packet)

    def get_sent_data(self) -> list[bytes]:
        """Get all sent data (for testing)."""
        return [p.data for p in self.send_buffer]

    def clear_buffers(self):
        """Clear all buffers."""
        self.recv_buffer.clear()
        self.send_buffer.clear()


class DNSRecord:
    """A DNS record."""

    def __init__(
        self,
        name: str,
        record_type: str = "A",
        value: str = "",
        ttl: int = 300
    ):
        self.name = name
        self.record_type = record_type
        self.value = value
        self.ttl = ttl
        self.created = time.time()

    def is_expired(self) -> bool:
        """Check if record has expired."""
        return time.time() - self.created > self.ttl


class VirtualNetwork:
    """
    Virtual network stack for emulation.
    
    Provides complete network emulation including:
    - Socket creation and management
    - DNS resolution
    - Connection simulation
    - Traffic recording
    """

    def __init__(self):
        # Socket management
        self._sockets: dict[int, VirtualSocket] = {}
        self._next_fd = 100  # Start high to avoid conflicts

        # DNS cache
        self._dns_cache: dict[str, DNSRecord] = {}

        # Mock responses
        self._mock_responses: dict[tuple[str, int], bytes] = {}

        # Connection rules
        self._connection_rules: list[ConnectionRule] = []

        # Traffic recording
        self._traffic_log: list[tuple[str, NetworkPacket]] = []
        self._recording = False

        # Network conditions
        self._latency_ms = 0
        self._packet_loss_rate = 0.0
        self._bandwidth_limit = 0  # bytes/sec, 0 = unlimited

        # Statistics
        self.stats = NetworkStats()

        # Hooks
        self._on_dns_query: Callable | None = None
        self._on_connect: Callable | None = None
        self._on_data: Callable | None = None

    # === Socket Operations ===

    def create_socket(
        self,
        domain: SocketDomain,
        sock_type: SocketType,
        protocol: int = 0
    ) -> VirtualSocket:
        """Create a new virtual socket."""
        fd = self._next_fd
        self._next_fd += 1

        sock = VirtualSocket(fd, domain, sock_type, protocol, self)
        self._sockets[fd] = sock

        self.stats.sockets_created += 1
        logger.debug(f"Created socket fd={fd} domain={domain} type={sock_type}")

        return sock

    def get_socket(self, fd: int) -> VirtualSocket | None:
        """Get socket by file descriptor."""
        return self._sockets.get(fd)

    def close_socket(self, fd: int) -> bool:
        """Close a socket."""
        if fd in self._sockets:
            self._sockets[fd].close()
            del self._sockets[fd]
            return True
        return False

    # === DNS Emulation ===

    def add_dns(self, hostname: str, address: str, record_type: str = "A", ttl: int = 300):
        """
        Add a DNS record.
        
        Args:
            hostname: Hostname to resolve
            address: IP address to return
            record_type: Record type (A, AAAA, CNAME, etc.)
            ttl: Time to live in seconds
        """
        record = DNSRecord(hostname, record_type, address, ttl)
        self._dns_cache[hostname.lower()] = record
        logger.debug(f"Added DNS: {hostname} -> {address}")

    def remove_dns(self, hostname: str):
        """Remove a DNS record."""
        self._dns_cache.pop(hostname.lower(), None)

    def resolve(self, hostname: str) -> str | None:
        """
        Resolve a hostname.
        
        Args:
            hostname: Hostname to resolve
            
        Returns:
            IP address or None if not found
        """
        self.stats.dns_queries += 1

        if self._on_dns_query:
            result = self._on_dns_query(hostname)
            if result:
                return result

        record = self._dns_cache.get(hostname.lower())
        if record and not record.is_expired():
            return record.value

        # Check wildcard
        for name, record in self._dns_cache.items():
            if name.startswith('*.'):
                suffix = name[2:]
                if hostname.lower().endswith(suffix):
                    return record.value

        return None

    def clear_dns_cache(self):
        """Clear DNS cache."""
        self._dns_cache.clear()

    # === Mock Responses ===

    def add_response(self, address: str, port: int, data: bytes):
        """
        Add a mock response for a destination.
        
        Args:
            address: Destination IP address
            port: Destination port
            data: Data to return when connecting
        """
        self._mock_responses[(address, port)] = data
        logger.debug(f"Added mock response for {address}:{port}")

    def remove_response(self, address: str, port: int):
        """Remove a mock response."""
        self._mock_responses.pop((address, port), None)

    def _get_mock_response(self, addr: SocketAddress) -> bytes | None:
        """Get mock response for address."""
        key = (addr.address, addr.port)
        return self._mock_responses.get(key)

    # === Connection Rules ===

    def add_rule(self, rule: ConnectionRule):
        """Add a connection rule."""
        self._connection_rules.append(rule)

    def allow_connection(self, address: str, port: int = 0):
        """Allow connections to address."""
        self.add_rule(ConnectionRule(address, port, "allow"))

    def block_connection(self, address: str, port: int = 0):
        """Block connections to address."""
        self.add_rule(ConnectionRule(address, port, "block"))

    def clear_rules(self):
        """Clear all connection rules."""
        self._connection_rules.clear()

    def _check_connection_allowed(self, addr: SocketAddress) -> str:
        """Check if connection is allowed."""
        for rule in self._connection_rules:
            if rule.address_pattern == "*" or rule.address_pattern == addr.address:
                if rule.port == 0 or rule.port == addr.port:
                    return rule.action
        return "allow"  # Default allow

    # === Network Conditions ===

    def set_latency(self, ms: int):
        """Set network latency in milliseconds."""
        self._latency_ms = ms

    def set_packet_loss(self, rate: float):
        """Set packet loss rate (0.0 to 1.0)."""
        self._packet_loss_rate = max(0.0, min(1.0, rate))

    def set_bandwidth_limit(self, bytes_per_sec: int):
        """Set bandwidth limit in bytes per second."""
        self._bandwidth_limit = bytes_per_sec

    def simulate_disconnect(self):
        """Simulate network disconnection."""
        for sock in self._sockets.values():
            if sock.state == SocketState.CONNECTED:
                sock.state = SocketState.CLOSED

    def simulate_reconnect(self):
        """Simulate network reconnection."""
        # Sockets need to be reconnected manually
        pass

    # === Traffic Recording ===

    def start_recording(self):
        """Start recording network traffic."""
        self._recording = True
        self._traffic_log.clear()

    def stop_recording(self):
        """Stop recording network traffic."""
        self._recording = False

    def get_traffic_log(self) -> list[tuple[str, NetworkPacket]]:
        """Get recorded traffic."""
        return self._traffic_log.copy()

    def clear_traffic_log(self):
        """Clear traffic log."""
        self._traffic_log.clear()

    def _record_traffic(self, packet: NetworkPacket, operation: str):
        """Record a traffic event."""
        if self._recording:
            self._traffic_log.append((operation, packet))

    # === HTTP Helpers ===

    def add_http_response(
        self,
        host: str,
        port: int,
        status: int = 200,
        headers: dict[str, str] | None = None,
        body: bytes = b""
    ):
        """
        Add an HTTP response.
        
        Args:
            host: Hostname or IP
            port: Port number
            status: HTTP status code
            headers: Response headers
            body: Response body
        """
        headers = headers or {}
        headers.setdefault("Content-Length", str(len(body)))
        headers.setdefault("Content-Type", "text/plain")

        status_text = {
            200: "OK",
            201: "Created",
            301: "Moved Permanently",
            302: "Found",
            400: "Bad Request",
            401: "Unauthorized",
            403: "Forbidden",
            404: "Not Found",
            500: "Internal Server Error",
        }.get(status, "Unknown")

        response = f"HTTP/1.1 {status} {status_text}\r\n"
        for key, value in headers.items():
            response += f"{key}: {value}\r\n"
        response += "\r\n"

        self.add_response(host, port, response.encode() + body)

    def add_https_response(
        self,
        host: str,
        status: int = 200,
        headers: dict[str, str] | None = None,
        body: bytes = b""
    ):
        """Add HTTPS response (port 443)."""
        self.add_http_response(host, 443, status, headers, body)

    # === Hooks ===

    def on_dns_query(self, callback: Callable[[str], str | None]):
        """Set DNS query hook."""
        self._on_dns_query = callback

    def on_connect(self, callback: Callable[[VirtualSocket, SocketAddress], None]):
        """Set connection hook."""
        self._on_connect = callback

    def on_data(self, callback: Callable[[VirtualSocket, bytes, str], bytes | None]):
        """Set data hook (called on send/recv)."""
        self._on_data = callback

    # === Statistics ===

    def get_stats(self) -> NetworkStats:
        """Get network statistics."""
        return self.stats

    def reset_stats(self):
        """Reset statistics."""
        self.stats = NetworkStats()

    # === Utilities ===

    def get_all_sockets(self) -> list[VirtualSocket]:
        """Get all open sockets."""
        return list(self._sockets.values())

    def get_connected_sockets(self) -> list[VirtualSocket]:
        """Get all connected sockets."""
        return [s for s in self._sockets.values() if s.state == SocketState.CONNECTED]

    def close_all(self):
        """Close all sockets."""
        for fd in list(self._sockets.keys()):
            self.close_socket(fd)

    def reset(self):
        """Reset network state."""
        self.close_all()
        self.clear_dns_cache()
        self._mock_responses.clear()
        self._connection_rules.clear()
        self._traffic_log.clear()
        self.reset_stats()


class NetworkSyscallHandler:
    """
    Handles network-related syscalls.
    
    Intercepts socket operations and redirects them to
    the virtual network.
    """

    # ARM64 syscall numbers
    SYS_socket = 198
    SYS_socketpair = 199
    SYS_bind = 200
    SYS_listen = 201
    SYS_accept = 202
    SYS_connect = 203
    SYS_getsockname = 204
    SYS_getpeername = 205
    SYS_sendto = 206
    SYS_recvfrom = 207
    SYS_setsockopt = 208
    SYS_getsockopt = 209
    SYS_shutdown = 210
    SYS_sendmsg = 211
    SYS_recvmsg = 212
    SYS_accept4 = 242

    def __init__(self, emulator, network: VirtualNetwork):
        self.emulator = emulator
        self.network = network

        self._handlers = {
            self.SYS_socket: self._sys_socket,
            self.SYS_bind: self._sys_bind,
            self.SYS_listen: self._sys_listen,
            self.SYS_accept: self._sys_accept,
            self.SYS_accept4: self._sys_accept4,
            self.SYS_connect: self._sys_connect,
            self.SYS_sendto: self._sys_sendto,
            self.SYS_recvfrom: self._sys_recvfrom,
            self.SYS_setsockopt: self._sys_setsockopt,
            self.SYS_getsockopt: self._sys_getsockopt,
            self.SYS_shutdown: self._sys_shutdown,
            self.SYS_getsockname: self._sys_getsockname,
            self.SYS_getpeername: self._sys_getpeername,
        }

    def handle_syscall(self, syscall_num: int, args: tuple) -> int:
        """Handle a syscall."""
        handler = self._handlers.get(syscall_num)
        if handler:
            try:
                return handler(*args)
            except Exception as e:
                logger.error(f"Network syscall {syscall_num} error: {e}")
                return -1
        return -1  # ENOSYS

    def _read_sockaddr(self, addr_ptr: int, addr_len: int) -> SocketAddress:
        """Read sockaddr from memory."""
        data = self.emulator.mem_read(addr_ptr, addr_len)
        return SocketAddress.from_sockaddr(bytes(data))

    def _write_sockaddr(self, addr_ptr: int, addr: SocketAddress):
        """Write sockaddr to memory."""
        data = addr.to_sockaddr_in()
        self.emulator.mem_write(addr_ptr, data)

    def _sys_socket(self, domain: int, sock_type: int, protocol: int) -> int:
        """Create a socket."""
        sock = self.network.create_socket(
            SocketDomain(domain),
            SocketType(sock_type & 0xff),
            protocol
        )
        return sock.fd

    def _sys_bind(self, fd: int, addr_ptr: int, addr_len: int) -> int:
        """Bind socket to address."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9  # EBADF

        addr = self._read_sockaddr(addr_ptr, addr_len)
        return sock.bind(addr)

    def _sys_listen(self, fd: int, backlog: int) -> int:
        """Listen on socket."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9
        return sock.listen(backlog)

    def _sys_accept(self, fd: int, addr_ptr: int, addr_len_ptr: int) -> int:
        """Accept connection."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9

        client, addr = sock.accept()
        if client:
            if addr_ptr and addr:
                self._write_sockaddr(addr_ptr, addr)
            return client.fd
        return -11  # EAGAIN

    def _sys_accept4(self, fd: int, addr_ptr: int, addr_len_ptr: int, flags: int) -> int:
        """Accept with flags."""
        return self._sys_accept(fd, addr_ptr, addr_len_ptr)

    def _sys_connect(self, fd: int, addr_ptr: int, addr_len: int) -> int:
        """Connect to address."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9

        addr = self._read_sockaddr(addr_ptr, addr_len)
        return sock.connect(addr)

    def _sys_sendto(
        self, fd: int, buf_ptr: int, length: int,
        flags: int, dest_addr: int, addr_len: int
    ) -> int:
        """Send data."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9

        data = bytes(self.emulator.mem_read(buf_ptr, length))

        if dest_addr:
            addr = self._read_sockaddr(dest_addr, addr_len)
            return sock.sendto(data, addr, flags)
        else:
            return sock.send(data, flags)

    def _sys_recvfrom(
        self, fd: int, buf_ptr: int, length: int,
        flags: int, src_addr: int, addr_len_ptr: int
    ) -> int:
        """Receive data."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9

        if src_addr:
            data, addr = sock.recvfrom(length, flags)
            if addr:
                self._write_sockaddr(src_addr, addr)
        else:
            data = sock.recv(length, flags)

        if data:
            self.emulator.mem_write(buf_ptr, data)
            return len(data)
        return 0

    def _sys_setsockopt(
        self, fd: int, level: int, optname: int,
        optval_ptr: int, optlen: int
    ) -> int:
        """Set socket option."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9

        value = bytes(self.emulator.mem_read(optval_ptr, optlen))
        sock.setsockopt(level, optname, value)
        return 0

    def _sys_getsockopt(
        self, fd: int, level: int, optname: int,
        optval_ptr: int, optlen_ptr: int
    ) -> int:
        """Get socket option."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9

        value = sock.getsockopt(level, optname)
        if isinstance(value, int):
            self.emulator.mem_write(optval_ptr, struct.pack('<I', value))
        return 0

    def _sys_shutdown(self, fd: int, how: int) -> int:
        """Shutdown socket."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9
        return sock.shutdown(ShutdownHow(how))

    def _sys_getsockname(self, fd: int, addr_ptr: int, addr_len_ptr: int) -> int:
        """Get local socket address."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9

        addr = sock.getsockname()
        if addr:
            self._write_sockaddr(addr_ptr, addr)
            return 0
        return -1

    def _sys_getpeername(self, fd: int, addr_ptr: int, addr_len_ptr: int) -> int:
        """Get remote socket address."""
        sock = self.network.get_socket(fd)
        if not sock:
            return -9

        addr = sock.getpeername()
        if addr:
            self._write_sockaddr(addr_ptr, addr)
            return 0
        return -1


# Convenience functions
def create_network() -> VirtualNetwork:
    """Create a new virtual network."""
    return VirtualNetwork()


def create_loopback_network() -> VirtualNetwork:
    """Create a network with loopback configured."""
    net = VirtualNetwork()
    net.add_dns("localhost", "127.0.0.1")
    net.add_dns("localhost.localdomain", "127.0.0.1")
    return net
