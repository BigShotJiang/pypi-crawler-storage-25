"""
Advanced analysis module for PyUniDbg.

Provides:
- Instruction tracing and disassembly
- Deobfuscation and code translation
- Dynamic patching
- Snapshot/replay with time manipulation
- Taint analysis
- Code coverage tracking
"""

from .anti_tampering import (
    KNOWN_SIGNATURES,
    AntiTamperingDetector,
    ChecksumSignature,
    CodeReadTracker,
    Severity,
    SMCDetector,
    TamperCheckType,
    TamperFinding,
    create_anti_tampering_detector,
)
from .api_deobfuscation import (
    COMMON_API_NAMES,
    HASH_ALGORITHMS,
    APIDeobfuscator,
    APIHashEntry,
    ResolutionMethod,
    ResolvedAPI,
    StringDecryptEvent,
    build_hash_table,
    create_api_deobfuscator,
)
from .coverage import (
    BasicBlock,
    CoverageEntry,
    CoverageMode,
    CoverageStats,
    CoverageTracker,
    ModuleInfo,
    create_coverage_tracker,
)
from .deobfuscator import Deobfuscator, ObfuscationPattern
from .disasm import DisasmOutput, DisasmStyle, Disassembler
from .import_reconstruction import (
    CallMonitor,
    ImportReconstructor,
    ImportTableSnapshot,
    ImportType,
    ModuleImports,
    ReconstructedImport,
    SymbolResolver,
    TableReader,
    create_import_reconstructor,
)
from .loading_inspector import (
    DependencyNode,
    DependencyResolveEvent,
    InitFunctionEvent,
    LibraryLoadEvent,
    LoadingEvent,
    LoadingEventType,
    LoadingInspector,
    LoadingStats,
    MemoryMapEvent,
    RelocationEvent,
    SymbolResolveEvent,
    SymbolUnresolvedEvent,
    create_loading_inspector,
)
from .patcher import DynamicPatcher, Patch, PatchCondition
from .snapshot import ReplayController, Snapshot, SnapshotManager
from .taint import (
    TaintAlert,
    TaintColor,
    TaintEngine,
    TaintMap,
    TaintPolicy,
    TaintSink,
    TaintSource,
)
from .timewarp import TimeController, TimeWarp
from .tracer import InstructionTracer, TraceEntry, TraceFormat

__all__ = [
    # Time control
    'TimeWarp',
    'TimeController',

    # Tracing
    'InstructionTracer',
    'TraceEntry',
    'TraceFormat',

    # Disassembly
    'Disassembler',
    'DisasmOutput',
    'DisasmStyle',

    # Deobfuscation
    'Deobfuscator',
    'ObfuscationPattern',

    # Patching
    'DynamicPatcher',
    'Patch',
    'PatchCondition',

    # Snapshot/Replay
    'SnapshotManager',
    'Snapshot',
    'ReplayController',

    # Taint Analysis
    'TaintEngine',
    'TaintSource',
    'TaintSink',
    'TaintPolicy',
    'TaintColor',
    'TaintAlert',
    'TaintMap',

    # Coverage Tracking
    'CoverageTracker',
    'CoverageMode',
    'CoverageEntry',
    'BasicBlock',
    'ModuleInfo',
    'CoverageStats',
    'create_coverage_tracker',

    # Loading Inspector
    'LoadingInspector',
    'LoadingEvent',
    'LoadingEventType',
    'LibraryLoadEvent',
    'SymbolResolveEvent',
    'SymbolUnresolvedEvent',
    'DependencyResolveEvent',
    'MemoryMapEvent',
    'RelocationEvent',
    'InitFunctionEvent',
    'DependencyNode',
    'LoadingStats',
    'create_loading_inspector',

    # Anti-Tampering Detection
    'AntiTamperingDetector',
    'TamperCheckType',
    'TamperFinding',
    'Severity',
    'ChecksumSignature',
    'CodeReadTracker',
    'SMCDetector',
    'KNOWN_SIGNATURES',
    'create_anti_tampering_detector',

    # API Deobfuscation
    'APIDeobfuscator',
    'ResolvedAPI',
    'ResolutionMethod',
    'APIHashEntry',
    'StringDecryptEvent',
    'HASH_ALGORITHMS',
    'COMMON_API_NAMES',
    'build_hash_table',
    'create_api_deobfuscator',

    # Import Reconstruction
    'ImportReconstructor',
    'ReconstructedImport',
    'ImportType',
    'ModuleImports',
    'ImportTableSnapshot',
    'CallMonitor',
    'TableReader',
    'SymbolResolver',
    'create_import_reconstructor',
]
