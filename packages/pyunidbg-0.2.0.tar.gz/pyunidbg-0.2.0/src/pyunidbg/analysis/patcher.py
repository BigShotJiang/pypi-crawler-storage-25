"""
Dynamic Patcher - Runtime code patching.

Provides:
- Hot-patching of code during execution
- Conditional patches
- Patch templates for common bypasses
- Reversible patches
"""

import logging
import struct
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


class PatchType(Enum):
    """Types of patches."""
    BYTES = auto()          # Raw byte replacement
    NOP = auto()            # NOP out instructions
    RETURN = auto()         # Return immediately
    RETURN_VALUE = auto()   # Return specific value
    JUMP = auto()           # Jump to address
    CALL = auto()           # Call function
    HOOK = auto()           # Python hook function
    CONDITIONAL = auto()    # Conditional patch


@dataclass
class PatchCondition:
    """Condition for applying a patch."""
    # Register conditions
    register: str | None = None
    value: int | None = None
    operator: str = "=="  # ==, !=, <, >, <=, >=

    # Call count condition
    min_calls: int = 0
    max_calls: int = float('inf')

    # Custom condition function
    custom: Callable[['Emulator'], bool] | None = None

    def check(self, emulator: 'Emulator', call_count: int) -> bool:
        """Check if condition is met."""
        # Check call count
        if not (self.min_calls <= call_count <= self.max_calls):
            return False

        # Check register value
        if self.register and self.value is not None:
            reg_value = emulator.get_register(self.register)
            if self.operator == "==":
                if reg_value != self.value:
                    return False
            elif self.operator == "!=":
                if reg_value == self.value:
                    return False
            elif self.operator == "<":
                if reg_value >= self.value:
                    return False
            elif self.operator == ">":
                if reg_value <= self.value:
                    return False
            elif self.operator == "<=":
                if reg_value > self.value:
                    return False
            elif self.operator == ">=":
                if reg_value < self.value:
                    return False

        # Check custom condition
        if self.custom:
            if not self.custom(emulator):
                return False

        return True


@dataclass
class Patch:
    """Code patch definition."""
    address: int
    patch_type: PatchType
    name: str = ""
    enabled: bool = True

    # Original bytes (for reverting)
    original_bytes: bytes = b''
    size: int = 0

    # Patch data
    new_bytes: bytes = b''           # For BYTES type
    return_value: int = 0            # For RETURN_VALUE
    target_address: int = 0          # For JUMP/CALL
    hook_function: Callable | None = None  # For HOOK

    # Condition
    condition: PatchCondition | None = None

    # Statistics
    hit_count: int = 0
    applied_count: int = 0

    def __post_init__(self):
        if not self.name:
            self.name = f"patch_0x{self.address:x}"


class PatchTemplate:
    """Pre-built patch templates for common use cases."""

    @staticmethod
    def nop(address: int, size: int, is_64bit: bool = True) -> Patch:
        """Create NOP patch."""
        if is_64bit:
            # ARM64 NOP: 0xD503201F
            nop = b'\x1f\x20\x03\xd5'
        else:
            # ARM NOP: 0xE320F000
            nop = b'\x00\xf0\x20\xe3'

        nop_bytes = (nop * (size // 4 + 1))[:size]

        return Patch(
            address=address,
            patch_type=PatchType.NOP,
            name=f"nop_0x{address:x}",
            new_bytes=nop_bytes,
            size=size,
        )

    @staticmethod
    def return_zero(address: int, is_64bit: bool = True) -> Patch:
        """Patch to return 0."""
        if is_64bit:
            # mov x0, #0; ret
            code = b'\x00\x00\x80\xd2' + b'\xc0\x03\x5f\xd6'
        else:
            # mov r0, #0; bx lr
            code = b'\x00\x00\xa0\xe3' + b'\x1e\xff\x2f\xe1'

        return Patch(
            address=address,
            patch_type=PatchType.RETURN_VALUE,
            name=f"ret0_0x{address:x}",
            new_bytes=code,
            return_value=0,
            size=len(code),
        )

    @staticmethod
    def return_one(address: int, is_64bit: bool = True) -> Patch:
        """Patch to return 1."""
        if is_64bit:
            # mov x0, #1; ret
            code = b'\x20\x00\x80\xd2' + b'\xc0\x03\x5f\xd6'
        else:
            # mov r0, #1; bx lr
            code = b'\x01\x00\xa0\xe3' + b'\x1e\xff\x2f\xe1'

        return Patch(
            address=address,
            patch_type=PatchType.RETURN_VALUE,
            name=f"ret1_0x{address:x}",
            new_bytes=code,
            return_value=1,
            size=len(code),
        )

    @staticmethod
    def return_value(address: int, value: int, is_64bit: bool = True) -> Patch:
        """Patch to return specific value."""
        if is_64bit:
            # mov x0, #value; ret
            # For values <= 0xFFFF
            if value <= 0xFFFF:
                imm = value << 5
                code = struct.pack('<I', 0xD2800000 | imm) + b'\xc0\x03\x5f\xd6'
            else:
                # For larger values, use multiple instructions
                code = b'\x00\x00\x80\xd2'  # mov x0, #0
                code += b'\xc0\x03\x5f\xd6'  # ret
        else:
            code = b'\x00\x00\xa0\xe3' + b'\x1e\xff\x2f\xe1'

        return Patch(
            address=address,
            patch_type=PatchType.RETURN_VALUE,
            name=f"retval_0x{address:x}",
            new_bytes=code,
            return_value=value,
            size=len(code),
        )

    @staticmethod
    def jump_to(address: int, target: int, is_64bit: bool = True) -> Patch:
        """Patch to jump to target address."""
        # Calculate offset
        offset = target - address

        if is_64bit:
            # B instruction (26-bit offset, 4-byte aligned)
            if -0x8000000 <= offset < 0x8000000:
                imm26 = (offset >> 2) & 0x3FFFFFF
                code = struct.pack('<I', 0x14000000 | imm26)
            else:
                # Need indirect branch for far jumps
                code = b'\x00\x00\x80\xd2\x00\x00\x1f\xd6'  # placeholder
        else:
            # B instruction (24-bit offset, 4-byte aligned)
            imm24 = ((offset - 8) >> 2) & 0xFFFFFF
            code = struct.pack('<I', 0xEA000000 | imm24)

        return Patch(
            address=address,
            patch_type=PatchType.JUMP,
            name=f"jmp_0x{target:x}",
            new_bytes=code,
            target_address=target,
            size=len(code),
        )

    @staticmethod
    def force_branch(address: int, taken: bool = True, is_64bit: bool = True) -> Patch:
        """Force conditional branch to always/never be taken."""
        if is_64bit:
            if taken:
                # Replace conditional branch with unconditional B
                # We'll patch this dynamically based on the original instruction
                code = b'\x00\x00\x00\x14'  # B .+0 (placeholder)
            else:
                # NOP the branch
                code = b'\x1f\x20\x03\xd5'  # NOP
        else:
            if taken:
                code = b'\x00\x00\x00\xea'  # B (placeholder)
            else:
                code = b'\x00\xf0\x20\xe3'  # NOP

        return Patch(
            address=address,
            patch_type=PatchType.NOP if not taken else PatchType.JUMP,
            name=f"force_{'taken' if taken else 'skip'}_0x{address:x}",
            new_bytes=code,
            size=len(code),
        )


class DynamicPatcher:
    """
    Runtime code patcher.
    
    Allows patching code during emulation:
    - Apply/revert patches dynamically
    - Conditional patching
    - Hook functions
    - Patch templates for common bypasses
    
    Example:
        patcher = DynamicPatcher(emulator)
        
        # NOP out anti-debug check
        patcher.add(PatchTemplate.nop(0x1000, 8))
        
        # Make function return 0
        patcher.add(PatchTemplate.return_zero(0x2000))
        
        # Hook function with Python
        patcher.hook(0x3000, my_handler)
        
        # Apply all patches
        patcher.apply_all()
        
        # Run emulation
        emulator.run()
        
        # Revert all patches
        patcher.revert_all()
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator

        # Registered patches
        self._patches: dict[int, Patch] = {}

        # Applied patches
        self._applied: dict[int, Patch] = {}

        # Hook handlers
        self._hook_id: int | None = None
        self._hooks: dict[int, Callable] = {}

        # Statistics
        self._stats = {
            'patches_applied': 0,
            'patches_reverted': 0,
            'hooks_called': 0,
        }

    @property
    def patches(self) -> list[Patch]:
        return list(self._patches.values())

    @property
    def stats(self) -> dict:
        return self._stats.copy()

    # ==================== Patch Management ====================

    def add(self, patch: Patch) -> None:
        """Add patch (does not apply immediately)."""
        self._patches[patch.address] = patch
        logger.debug(f"Added patch: {patch.name}")

    def remove(self, address: int) -> bool:
        """Remove patch by address."""
        if address in self._patches:
            # Revert if applied
            if address in self._applied:
                self.revert(address)
            del self._patches[address]
            return True
        return False

    def get(self, address: int) -> Patch | None:
        """Get patch by address."""
        return self._patches.get(address)

    def clear(self) -> None:
        """Remove all patches."""
        self.revert_all()
        self._patches.clear()
        self._hooks.clear()

    # ==================== Apply/Revert ====================

    def apply(self, address: int) -> bool:
        """Apply single patch."""
        patch = self._patches.get(address)
        if not patch or not patch.enabled:
            return False

        if address in self._applied:
            return True  # Already applied

        # Check condition
        if patch.condition and not patch.condition.check(self.emulator, patch.hit_count):
            return False

        # Save original bytes
        if not patch.original_bytes:
            patch.original_bytes = self.emulator.memory.read(address, patch.size)

        # Apply patch
        self.emulator.memory.write(address, patch.new_bytes)

        self._applied[address] = patch
        patch.applied_count += 1
        self._stats['patches_applied'] += 1

        logger.info(f"Applied patch: {patch.name}")
        return True

    def apply_all(self) -> int:
        """Apply all enabled patches."""
        count = 0
        for address, patch in self._patches.items():
            if patch.enabled and self.apply(address):
                count += 1
        return count

    def revert(self, address: int) -> bool:
        """Revert single patch."""
        if address not in self._applied:
            return False

        patch = self._applied[address]

        # Restore original bytes
        if patch.original_bytes:
            self.emulator.memory.write(address, patch.original_bytes)

        del self._applied[address]
        self._stats['patches_reverted'] += 1

        logger.info(f"Reverted patch: {patch.name}")
        return True

    def revert_all(self) -> int:
        """Revert all applied patches."""
        count = 0
        for address in list(self._applied.keys()):
            if self.revert(address):
                count += 1
        return count

    # ==================== Hook Functions ====================

    def hook(self, address: int, handler: Callable[['Emulator'], int | None],
             name: str = "") -> None:
        """
        Hook address with Python function.
        
        Handler receives emulator and can:
        - Modify registers/memory
        - Return value to set as return value
        - Return None to continue normal execution
        
        Args:
            address: Address to hook
            handler: Python function(emulator) -> Optional[int]
            name: Optional name for the hook
        """
        self._hooks[address] = handler

        # Create hook patch
        patch = Patch(
            address=address,
            patch_type=PatchType.HOOK,
            name=name or f"hook_0x{address:x}",
            hook_function=handler,
            size=4,
        )
        self._patches[address] = patch

        # Install code hook if not already done
        if not self._hook_id:
            self._install_hook_handler()

    def unhook(self, address: int) -> bool:
        """Remove hook from address."""
        if address in self._hooks:
            del self._hooks[address]
            self.remove(address)
            return True
        return False

    def _install_hook_handler(self) -> None:
        """Install Unicorn hook for handling Python hooks."""
        from unicorn import UC_HOOK_CODE

        def hook_callback(uc, address, size, user_data):
            if address in self._hooks:
                handler = self._hooks[address]
                patch = self._patches.get(address)

                if patch:
                    patch.hit_count += 1

                    # Check condition
                    if patch.condition:
                        if not patch.condition.check(self.emulator, patch.hit_count):
                            return

                try:
                    result = handler(self.emulator)
                    self._stats['hooks_called'] += 1

                    # If handler returns a value, set it as return value and skip
                    if result is not None:
                        self.emulator.set_return_value(result)
                        # Skip to return instruction
                        # This is simplified - real impl would need to adjust PC

                except Exception as e:
                    logger.error(f"Hook error at 0x{address:x}: {e}")

        self._hook_id = self.emulator.uc.hook_add(UC_HOOK_CODE, hook_callback)

    # ==================== Convenience Methods ====================

    def nop(self, address: int, size: int = 4) -> Patch:
        """NOP out instructions at address."""
        patch = PatchTemplate.nop(address, size, self.emulator.is_64bit)
        self.add(patch)
        return patch

    def ret_zero(self, address: int) -> Patch:
        """Patch function to return 0."""
        patch = PatchTemplate.return_zero(address, self.emulator.is_64bit)
        self.add(patch)
        return patch

    def ret_one(self, address: int) -> Patch:
        """Patch function to return 1."""
        patch = PatchTemplate.return_one(address, self.emulator.is_64bit)
        self.add(patch)
        return patch

    def ret_value(self, address: int, value: int) -> Patch:
        """Patch function to return specific value."""
        patch = PatchTemplate.return_value(address, value, self.emulator.is_64bit)
        self.add(patch)
        return patch

    def force_branch(self, address: int, taken: bool = True) -> Patch:
        """Force branch to be taken or not."""
        patch = PatchTemplate.force_branch(address, taken, self.emulator.is_64bit)
        self.add(patch)
        return patch

    def write_bytes(self, address: int, data: bytes, name: str = "") -> Patch:
        """Write raw bytes at address."""
        patch = Patch(
            address=address,
            patch_type=PatchType.BYTES,
            name=name or f"bytes_0x{address:x}",
            new_bytes=data,
            size=len(data),
        )
        self.add(patch)
        return patch

    def conditional_patch(self, address: int, data: bytes,
                         condition: PatchCondition, name: str = "") -> Patch:
        """Apply patch only when condition is met."""
        patch = Patch(
            address=address,
            patch_type=PatchType.CONDITIONAL,
            name=name or f"cond_0x{address:x}",
            new_bytes=data,
            size=len(data),
            condition=condition,
        )
        self.add(patch)
        return patch

    # ==================== Batch Operations ====================

    def nop_range(self, start: int, end: int) -> list[Patch]:
        """NOP out range of addresses."""
        patches = []
        addr = start
        while addr < end:
            size = min(4, end - addr)
            patch = self.nop(addr, size)
            patches.append(patch)
            addr += size
        return patches

    def patch_string(self, address: int, new_string: str) -> Patch:
        """Patch string at address."""
        data = new_string.encode('utf-8') + b'\x00'
        return self.write_bytes(address, data, f"string_0x{address:x}")

    # ==================== Status ====================

    def print_status(self) -> None:
        """Print patcher status."""
        print("=== Dynamic Patcher Status ===")
        print(f"Registered patches: {len(self._patches)}")
        print(f"Applied patches: {len(self._applied)}")
        print(f"Active hooks: {len(self._hooks)}")
        print()

        if self._patches:
            print("Patches:")
            for patch in self._patches.values():
                status = "APPLIED" if patch.address in self._applied else "pending"
                enabled = "enabled" if patch.enabled else "disabled"
                print(f"  0x{patch.address:x}: {patch.name} [{status}] ({enabled})")
                print(f"    Hits: {patch.hit_count}, Applied: {patch.applied_count}")

    def export_patches(self) -> list[dict]:
        """Export patches as serializable format."""
        return [
            {
                'address': p.address,
                'type': p.patch_type.name,
                'name': p.name,
                'size': p.size,
                'new_bytes': p.new_bytes.hex(),
                'original_bytes': p.original_bytes.hex() if p.original_bytes else '',
                'enabled': p.enabled,
            }
            for p in self._patches.values()
        ]

    def import_patches(self, patches: list[dict]) -> int:
        """Import patches from serialized format."""
        count = 0
        for p in patches:
            patch = Patch(
                address=p['address'],
                patch_type=PatchType[p['type']],
                name=p['name'],
                size=p['size'],
                new_bytes=bytes.fromhex(p['new_bytes']),
                original_bytes=bytes.fromhex(p['original_bytes']) if p['original_bytes'] else b'',
                enabled=p['enabled'],
            )
            self.add(patch)
            count += 1
        return count
