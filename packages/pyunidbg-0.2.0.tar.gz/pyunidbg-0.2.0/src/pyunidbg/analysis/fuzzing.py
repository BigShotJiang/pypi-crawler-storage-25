"""
Fuzzing Framework for PyUniDbg.

Provides mutation-based and generation-based fuzzing capabilities
with coverage tracking, crash detection, and corpus management.
"""

from __future__ import annotations

import hashlib
import json
import logging
import random
import struct
import time
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
)

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator

logger = logging.getLogger(__name__)


class FuzzingStrategy(Enum):
    """Fuzzing strategies."""

    RANDOM = auto()
    MUTATION = auto()
    GENERATION = auto()
    COVERAGE_GUIDED = auto()
    DICTIONARY = auto()
    HYBRID = auto()


class MutationType(Enum):
    """Types of mutations."""

    BIT_FLIP = auto()
    BYTE_FLIP = auto()
    BYTE_INSERT = auto()
    BYTE_DELETE = auto()
    BYTE_SWAP = auto()
    ARITHMETIC = auto()
    INTERESTING_VALUE = auto()
    DICTIONARY = auto()
    HAVOC = auto()
    SPLICE = auto()
    TRIM = auto()
    EXTEND = auto()


class CrashType(Enum):
    """Types of crashes."""

    SEGFAULT = auto()
    NULL_DEREF = auto()
    STACK_OVERFLOW = auto()
    HEAP_OVERFLOW = auto()
    USE_AFTER_FREE = auto()
    DOUBLE_FREE = auto()
    ASSERTION = auto()
    TIMEOUT = auto()
    OOM = auto()
    UNKNOWN = auto()


class FuzzingState(Enum):
    """Fuzzing session state."""

    IDLE = auto()
    RUNNING = auto()
    PAUSED = auto()
    STOPPED = auto()
    COMPLETED = auto()


@dataclass
class CoverageInfo:
    """Coverage information."""

    edges: set[tuple[int, int]] = field(default_factory=set)
    blocks: set[int] = field(default_factory=set)
    hit_counts: dict[int, int] = field(default_factory=dict)

    def add_edge(self, src: int, dst: int) -> bool:
        """Add an edge and return True if it's new."""
        edge = (src, dst)
        is_new = edge not in self.edges
        self.edges.add(edge)
        return is_new

    def add_block(self, addr: int) -> bool:
        """Add a basic block and return True if it's new."""
        is_new = addr not in self.blocks
        self.blocks.add(addr)
        self.hit_counts[addr] = self.hit_counts.get(addr, 0) + 1
        return is_new

    def merge(self, other: CoverageInfo) -> int:
        """Merge with another coverage info, return number of new edges."""
        new_count = 0
        for edge in other.edges:
            if edge not in self.edges:
                self.edges.add(edge)
                new_count += 1
        for block in other.blocks:
            if block not in self.blocks:
                self.blocks.add(block)
        for addr, count in other.hit_counts.items():
            self.hit_counts[addr] = self.hit_counts.get(addr, 0) + count
        return new_count

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "edges": len(self.edges),
            "blocks": len(self.blocks),
            "edge_list": [list(e) for e in list(self.edges)[:100]],  # Sample
            "block_list": list(self.blocks)[:100],
        }


@dataclass
class TestCase:
    """Represents a fuzzing test case."""

    data: bytes
    hash: str = ""
    source: str = ""
    parent_hash: str | None = None
    mutation_type: MutationType | None = None
    coverage: CoverageInfo | None = None
    execution_time: float = 0.0
    found_at: float = 0.0
    generation: int = 0

    def __post_init__(self):
        if not self.hash:
            self.hash = self._compute_hash()
        if not self.found_at:
            self.found_at = time.time()

    def _compute_hash(self) -> str:
        """Compute hash of the data."""
        return hashlib.sha256(self.data).hexdigest()[:16]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "hash": self.hash,
            "size": len(self.data),
            "source": self.source,
            "parent_hash": self.parent_hash,
            "mutation_type": self.mutation_type.name if self.mutation_type else None,
            "execution_time": self.execution_time,
            "found_at": self.found_at,
            "generation": self.generation,
        }

    def save(self, path: str | Path) -> None:
        """Save test case to file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'wb') as f:
            f.write(self.data)

        # Save metadata
        meta_path = path.with_suffix('.meta.json')
        with open(meta_path, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, path: str | Path) -> TestCase:
        """Load test case from file."""
        path = Path(path)
        with open(path, 'rb') as f:
            data = f.read()

        # Try to load metadata
        meta_path = path.with_suffix('.meta.json')
        meta = {}
        if meta_path.exists():
            with open(meta_path) as f:
                meta = json.load(f)

        return cls(
            data=data,
            source=meta.get("source", str(path)),
            parent_hash=meta.get("parent_hash"),
            mutation_type=MutationType[meta["mutation_type"]] if meta.get("mutation_type") else None,
            execution_time=meta.get("execution_time", 0.0),
            found_at=meta.get("found_at", 0.0),
            generation=meta.get("generation", 0),
        )


@dataclass
class CrashInfo:
    """Information about a crash."""

    test_case: TestCase
    crash_type: CrashType
    address: int = 0
    register_state: dict[str, int] = field(default_factory=dict)
    stack_trace: list[int] = field(default_factory=list)
    error_message: str = ""
    dedupe_hash: str = ""
    timestamp: float = 0.0

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.time()
        if not self.dedupe_hash:
            self.dedupe_hash = self._compute_dedupe_hash()

    def _compute_dedupe_hash(self) -> str:
        """Compute deduplication hash based on crash characteristics."""
        components = [
            str(self.crash_type.value),
            hex(self.address),
            ":".join(hex(a) for a in self.stack_trace[:5]),
        ]
        combined = "|".join(components)
        return hashlib.sha256(combined.encode()).hexdigest()[:12]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "crash_type": self.crash_type.name,
            "address": hex(self.address),
            "register_state": {k: hex(v) for k, v in self.register_state.items()},
            "stack_trace": [hex(a) for a in self.stack_trace],
            "error_message": self.error_message,
            "dedupe_hash": self.dedupe_hash,
            "timestamp": self.timestamp,
            "test_case": self.test_case.to_dict(),
        }


@dataclass
class FuzzingStats:
    """Fuzzing session statistics."""

    total_executions: int = 0
    executions_per_second: float = 0.0
    unique_crashes: int = 0
    total_crashes: int = 0
    unique_timeouts: int = 0
    coverage_edges: int = 0
    coverage_blocks: int = 0
    corpus_size: int = 0
    last_new_path: float = 0.0
    start_time: float = 0.0
    elapsed_time: float = 0.0
    peak_execs_per_second: float = 0.0
    cycles_done: int = 0

    def update_execs_per_second(self, window_execs: int, window_time: float) -> None:
        """Update executions per second."""
        if window_time > 0:
            self.executions_per_second = window_execs / window_time
            if self.executions_per_second > self.peak_execs_per_second:
                self.peak_execs_per_second = self.executions_per_second

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "total_executions": self.total_executions,
            "executions_per_second": round(self.executions_per_second, 2),
            "unique_crashes": self.unique_crashes,
            "total_crashes": self.total_crashes,
            "unique_timeouts": self.unique_timeouts,
            "coverage_edges": self.coverage_edges,
            "coverage_blocks": self.coverage_blocks,
            "corpus_size": self.corpus_size,
            "last_new_path": self.last_new_path,
            "elapsed_time": round(self.elapsed_time, 2),
            "peak_execs_per_second": round(self.peak_execs_per_second, 2),
            "cycles_done": self.cycles_done,
        }


class Mutator(ABC):
    """Abstract base class for mutators."""

    @abstractmethod
    def mutate(self, data: bytes) -> bytes:
        """Apply mutation to data."""
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Get mutator name."""
        pass

    @property
    @abstractmethod
    def mutation_type(self) -> MutationType:
        """Get mutation type."""
        pass


class BitFlipMutator(Mutator):
    """Mutator that flips random bits."""

    def __init__(self, bits: int = 1):
        self.bits = bits

    def mutate(self, data: bytes) -> bytes:
        if not data:
            return data

        data = bytearray(data)
        for _ in range(self.bits):
            idx = random.randint(0, len(data) - 1)
            bit = 1 << random.randint(0, 7)
            data[idx] ^= bit
        return bytes(data)

    @property
    def name(self) -> str:
        return f"bit_flip_{self.bits}"

    @property
    def mutation_type(self) -> MutationType:
        return MutationType.BIT_FLIP


class ByteFlipMutator(Mutator):
    """Mutator that flips random bytes."""

    def __init__(self, count: int = 1):
        self.count = count

    def mutate(self, data: bytes) -> bytes:
        if not data:
            return data

        data = bytearray(data)
        for _ in range(self.count):
            idx = random.randint(0, len(data) - 1)
            data[idx] ^= 0xFF
        return bytes(data)

    @property
    def name(self) -> str:
        return f"byte_flip_{self.count}"

    @property
    def mutation_type(self) -> MutationType:
        return MutationType.BYTE_FLIP


class ByteInsertMutator(Mutator):
    """Mutator that inserts random bytes."""

    def __init__(self, max_insert: int = 16):
        self.max_insert = max_insert

    def mutate(self, data: bytes) -> bytes:
        data = bytearray(data)
        count = random.randint(1, self.max_insert)
        idx = random.randint(0, len(data)) if data else 0

        for _ in range(count):
            data.insert(idx, random.randint(0, 255))

        return bytes(data)

    @property
    def name(self) -> str:
        return f"byte_insert_{self.max_insert}"

    @property
    def mutation_type(self) -> MutationType:
        return MutationType.BYTE_INSERT


class ByteDeleteMutator(Mutator):
    """Mutator that deletes random bytes."""

    def __init__(self, max_delete: int = 16):
        self.max_delete = max_delete

    def mutate(self, data: bytes) -> bytes:
        if not data:
            return data

        data = bytearray(data)
        count = min(random.randint(1, self.max_delete), len(data))

        for _ in range(count):
            if data:
                idx = random.randint(0, len(data) - 1)
                del data[idx]

        return bytes(data)

    @property
    def name(self) -> str:
        return f"byte_delete_{self.max_delete}"

    @property
    def mutation_type(self) -> MutationType:
        return MutationType.BYTE_DELETE


class ArithmeticMutator(Mutator):
    """Mutator that applies arithmetic operations."""

    INTERESTING_8 = [0, 1, 0x7F, 0x80, 0xFF]
    INTERESTING_16 = [0, 1, 0x7FFF, 0x8000, 0xFFFF]
    INTERESTING_32 = [0, 1, 0x7FFFFFFF, 0x80000000, 0xFFFFFFFF]

    def __init__(self, max_delta: int = 35):
        self.max_delta = max_delta

    def mutate(self, data: bytes) -> bytes:
        if len(data) < 1:
            return data

        data = bytearray(data)
        idx = random.randint(0, len(data) - 1)

        # Choose width based on remaining bytes
        remaining = len(data) - idx
        if remaining >= 4 and random.random() < 0.3:
            width = 4
        elif remaining >= 2 and random.random() < 0.5:
            width = 2
        else:
            width = 1

        # Apply arithmetic operation
        delta = random.randint(-self.max_delta, self.max_delta)

        if width == 1:
            data[idx] = (data[idx] + delta) & 0xFF
        elif width == 2:
            val = struct.unpack('<H', data[idx:idx+2])[0]
            val = (val + delta) & 0xFFFF
            struct.pack_into('<H', data, idx, val)
        else:
            val = struct.unpack('<I', data[idx:idx+4])[0]
            val = (val + delta) & 0xFFFFFFFF
            struct.pack_into('<I', data, idx, val)

        return bytes(data)

    @property
    def name(self) -> str:
        return "arithmetic"

    @property
    def mutation_type(self) -> MutationType:
        return MutationType.ARITHMETIC


class InterestingValueMutator(Mutator):
    """Mutator that inserts interesting values."""

    INTERESTING_8 = [0, 1, 16, 32, 64, 100, 127, 128, 255]
    INTERESTING_16 = [0, 1, 256, 512, 1000, 1024, 4096, 32767, 32768, 65535]
    INTERESTING_32 = [
        0, 1, 256, 512, 1000, 1024, 4096, 32768, 65535, 65536,
        100663045, 2147483647, 2147483648, 4294967295,
    ]

    def mutate(self, data: bytes) -> bytes:
        if len(data) < 1:
            return data

        data = bytearray(data)
        idx = random.randint(0, len(data) - 1)
        remaining = len(data) - idx

        if remaining >= 4 and random.random() < 0.3:
            val = random.choice(self.INTERESTING_32)
            struct.pack_into('<I', data, idx, val & 0xFFFFFFFF)
        elif remaining >= 2 and random.random() < 0.5:
            val = random.choice(self.INTERESTING_16)
            struct.pack_into('<H', data, idx, val & 0xFFFF)
        else:
            data[idx] = random.choice(self.INTERESTING_8) & 0xFF

        return bytes(data)

    @property
    def name(self) -> str:
        return "interesting_value"

    @property
    def mutation_type(self) -> MutationType:
        return MutationType.INTERESTING_VALUE


class DictionaryMutator(Mutator):
    """Mutator that inserts dictionary tokens."""

    def __init__(self, dictionary: list[bytes] | None = None):
        self.dictionary = dictionary or []

    def add_token(self, token: bytes) -> None:
        """Add a token to the dictionary."""
        if token not in self.dictionary:
            self.dictionary.append(token)

    def add_tokens_from_file(self, path: str | Path) -> int:
        """Load tokens from file (one per line)."""
        path = Path(path)
        count = 0
        if path.exists():
            with open(path) as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        try:
                            # Handle escape sequences
                            token = line.encode().decode('unicode_escape').encode('latin-1')
                            self.add_token(token)
                            count += 1
                        except Exception:
                            logger.debug("Exception suppressed", exc_info=True)
                            self.add_token(line.encode())
                            count += 1
        return count

    def mutate(self, data: bytes) -> bytes:
        if not self.dictionary:
            return data

        data = bytearray(data)
        token = random.choice(self.dictionary)

        if random.random() < 0.5 and data:
            # Replace at random position
            idx = random.randint(0, len(data) - 1)
            end = min(idx + len(token), len(data))
            data[idx:end] = token[:end-idx]
        else:
            # Insert at random position
            idx = random.randint(0, len(data)) if data else 0
            data[idx:idx] = token

        return bytes(data)

    @property
    def name(self) -> str:
        return "dictionary"

    @property
    def mutation_type(self) -> MutationType:
        return MutationType.DICTIONARY


class HavocMutator(Mutator):
    """Mutator that applies random combinations of mutations."""

    def __init__(self, iterations: int = 4):
        self.iterations = iterations
        self._mutators = [
            BitFlipMutator(1),
            BitFlipMutator(4),
            ByteFlipMutator(1),
            ByteFlipMutator(4),
            ByteInsertMutator(8),
            ByteDeleteMutator(8),
            ArithmeticMutator(),
            InterestingValueMutator(),
        ]

    def mutate(self, data: bytes) -> bytes:
        for _ in range(random.randint(1, self.iterations)):
            mutator = random.choice(self._mutators)
            data = mutator.mutate(data)
        return data

    @property
    def name(self) -> str:
        return "havoc"

    @property
    def mutation_type(self) -> MutationType:
        return MutationType.HAVOC


class SpliceMutator(Mutator):
    """Mutator that splices two test cases together."""

    def __init__(self, corpus: list[bytes] | None = None):
        self.corpus = corpus or []

    def set_corpus(self, corpus: list[bytes]) -> None:
        """Set the corpus for splicing."""
        self.corpus = corpus

    def mutate(self, data: bytes) -> bytes:
        if not self.corpus or not data:
            return data

        other = random.choice(self.corpus)
        if not other:
            return data

        # Find splice point in first
        split1 = random.randint(0, len(data))
        # Find splice point in second
        split2 = random.randint(0, len(other))

        # Combine
        if random.random() < 0.5:
            return data[:split1] + other[split2:]
        else:
            return other[:split2] + data[split1:]

    @property
    def name(self) -> str:
        return "splice"

    @property
    def mutation_type(self) -> MutationType:
        return MutationType.SPLICE


class Corpus:
    """Manages the fuzzing corpus."""

    def __init__(self, path: str | Path | None = None):
        self.path = Path(path) if path else None
        self.test_cases: list[TestCase] = []
        self._hashes: set[str] = set()
        self._by_coverage: dict[int, list[TestCase]] = {}  # coverage -> test cases

    def add(self, test_case: TestCase, save: bool = True) -> bool:
        """Add a test case to the corpus. Returns True if it's new."""
        if test_case.hash in self._hashes:
            return False

        self.test_cases.append(test_case)
        self._hashes.add(test_case.hash)

        if save and self.path:
            test_case.save(self.path / f"{test_case.hash}.bin")

        return True

    def load(self, path: str | Path | None = None) -> int:
        """Load corpus from directory. Returns number loaded."""
        path = Path(path) if path else self.path
        if not path or not path.exists():
            return 0

        count = 0
        for file in path.glob("*.bin"):
            if file.name.endswith('.meta.bin'):
                continue
            try:
                tc = TestCase.load(file)
                if self.add(tc, save=False):
                    count += 1
            except Exception as e:
                logger.warning(f"Failed to load {file}: {e}")

        return count

    def save(self, path: str | Path | None = None) -> int:
        """Save corpus to directory. Returns number saved."""
        path = Path(path) if path else self.path
        if not path:
            return 0

        path.mkdir(parents=True, exist_ok=True)
        count = 0
        for tc in self.test_cases:
            try:
                tc.save(path / f"{tc.hash}.bin")
                count += 1
            except Exception as e:
                logger.warning(f"Failed to save {tc.hash}: {e}")

        return count

    def get_random(self) -> TestCase | None:
        """Get a random test case."""
        if not self.test_cases:
            return None
        return random.choice(self.test_cases)

    def get_by_coverage(self, min_edges: int = 0) -> list[TestCase]:
        """Get test cases with minimum coverage."""
        return [tc for tc in self.test_cases
                if tc.coverage and len(tc.coverage.edges) >= min_edges]

    def get_data_list(self) -> list[bytes]:
        """Get list of all test case data."""
        return [tc.data for tc in self.test_cases]

    def __len__(self) -> int:
        return len(self.test_cases)

    def __iter__(self) -> Iterator[TestCase]:
        return iter(self.test_cases)


class Generator(ABC):
    """Abstract base class for input generators."""

    @abstractmethod
    def generate(self) -> bytes:
        """Generate new input."""
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Get generator name."""
        pass


class RandomGenerator(Generator):
    """Generates random bytes."""

    def __init__(self, min_size: int = 1, max_size: int = 1024):
        self.min_size = min_size
        self.max_size = max_size

    def generate(self) -> bytes:
        size = random.randint(self.min_size, self.max_size)
        return bytes(random.randint(0, 255) for _ in range(size))

    @property
    def name(self) -> str:
        return "random"


class GrammarGenerator(Generator):
    """Generates inputs based on a grammar."""

    def __init__(self, grammar: dict[str, list[str]] | None = None):
        self.grammar = grammar or {}
        self.start_symbol = "start"
        self.max_depth = 10

    def add_rule(self, symbol: str, productions: list[str]) -> None:
        """Add a grammar rule."""
        self.grammar[symbol] = productions

    def _expand(self, symbol: str, depth: int = 0) -> str:
        """Expand a symbol according to the grammar."""
        if depth > self.max_depth:
            return ""

        if symbol not in self.grammar:
            return symbol

        production = random.choice(self.grammar[symbol])
        result = ""
        i = 0
        while i < len(production):
            if production[i] == '<':
                # Find closing >
                end = production.find('>', i)
                if end != -1:
                    inner = production[i+1:end]
                    result += self._expand(inner, depth + 1)
                    i = end + 1
                else:
                    result += production[i]
                    i += 1
            else:
                result += production[i]
                i += 1

        return result

    def generate(self) -> bytes:
        if not self.grammar:
            return b""

        result = self._expand(self.start_symbol)
        return result.encode('utf-8', errors='replace')

    @property
    def name(self) -> str:
        return "grammar"


class FuzzingHarness:
    """Harness for executing test cases."""

    def __init__(
        self,
        emulator: Emulator | None = None,
        target_function: int = 0,
        timeout: float = 1.0,
        memory_limit: int = 256 * 1024 * 1024,
    ):
        self.emulator = emulator
        self.target_function = target_function
        self.timeout = timeout
        self.memory_limit = memory_limit
        self._setup_callback: Callable[[bytes], None] | None = None
        self._run_callback: Callable[[bytes], tuple[bool, CrashInfo | None]] | None = None
        self._coverage_callback: Callable[[], CoverageInfo] | None = None
        self._reset_callback: Callable[[], None] | None = None

    def set_setup_callback(self, callback: Callable[[bytes], None]) -> None:
        """Set callback for setting up test case."""
        self._setup_callback = callback

    def set_run_callback(
        self,
        callback: Callable[[bytes], tuple[bool, CrashInfo | None]]
    ) -> None:
        """Set callback for running test case."""
        self._run_callback = callback

    def set_coverage_callback(self, callback: Callable[[], CoverageInfo]) -> None:
        """Set callback for getting coverage."""
        self._coverage_callback = callback

    def set_reset_callback(self, callback: Callable[[], None]) -> None:
        """Set callback for resetting state."""
        self._reset_callback = callback

    def setup(self, data: bytes) -> None:
        """Set up for running a test case."""
        if self._setup_callback:
            self._setup_callback(data)

    def run(self, data: bytes) -> tuple[bool, CrashInfo | None, CoverageInfo]:
        """
        Run a test case.
        
        Returns:
            (crashed, crash_info, coverage)
        """
        if self._run_callback:
            crashed, crash_info = self._run_callback(data)
        else:
            crashed = False
            crash_info = None

        if self._coverage_callback:
            coverage = self._coverage_callback()
        else:
            coverage = CoverageInfo()

        return crashed, crash_info, coverage

    def reset(self) -> None:
        """Reset state after test case."""
        if self._reset_callback:
            self._reset_callback()

    def get_coverage(self) -> CoverageInfo:
        """Get current coverage."""
        if self._coverage_callback:
            return self._coverage_callback()
        return CoverageInfo()


class Fuzzer:
    """Main fuzzer class."""

    def __init__(
        self,
        harness: FuzzingHarness | None = None,
        strategy: FuzzingStrategy = FuzzingStrategy.COVERAGE_GUIDED,
        corpus_path: str | Path | None = None,
        crash_path: str | Path | None = None,
    ):
        self.harness = harness or FuzzingHarness()
        self.strategy = strategy
        self.corpus = Corpus(corpus_path)
        self.crash_path = Path(crash_path) if crash_path else None

        self.state = FuzzingState.IDLE
        self.stats = FuzzingStats()
        self.coverage = CoverageInfo()

        self._crashes: dict[str, CrashInfo] = {}  # dedupe_hash -> crash
        self._timeouts: set[str] = set()

        # Mutators
        self._mutators: list[Mutator] = [
            BitFlipMutator(1),
            BitFlipMutator(2),
            ByteFlipMutator(1),
            ByteFlipMutator(2),
            ByteInsertMutator(16),
            ByteDeleteMutator(16),
            ArithmeticMutator(),
            InterestingValueMutator(),
            HavocMutator(),
        ]

        self._splice_mutator = SpliceMutator()
        self._dict_mutator = DictionaryMutator()

        # Generator
        self._generator: Generator = RandomGenerator()

        # Callbacks
        self._on_crash: list[Callable[[CrashInfo], None]] = []
        self._on_new_coverage: list[Callable[[TestCase], None]] = []
        self._on_stats_update: list[Callable[[FuzzingStats], None]] = []

    def add_mutator(self, mutator: Mutator) -> None:
        """Add a custom mutator."""
        self._mutators.append(mutator)

    def set_generator(self, generator: Generator) -> None:
        """Set the input generator."""
        self._generator = generator

    def add_dictionary(self, tokens: list[bytes]) -> None:
        """Add dictionary tokens."""
        for token in tokens:
            self._dict_mutator.add_token(token)

    def load_dictionary(self, path: str | Path) -> int:
        """Load dictionary from file."""
        return self._dict_mutator.add_tokens_from_file(path)

    def add_seed(self, data: bytes, source: str = "seed") -> bool:
        """Add a seed to the corpus."""
        tc = TestCase(data=data, source=source)
        return self.corpus.add(tc)

    def add_seeds_from_dir(self, path: str | Path) -> int:
        """Add seeds from directory."""
        path = Path(path)
        count = 0
        if path.exists() and path.is_dir():
            for file in path.iterdir():
                if file.is_file():
                    try:
                        with open(file, 'rb') as f:
                            data = f.read()
                        if self.add_seed(data, str(file)):
                            count += 1
                    except Exception as e:
                        logger.warning(f"Failed to load seed {file}: {e}")
        return count

    def on_crash(self, callback: Callable[[CrashInfo], None]) -> None:
        """Register crash callback."""
        self._on_crash.append(callback)

    def on_new_coverage(self, callback: Callable[[TestCase], None]) -> None:
        """Register new coverage callback."""
        self._on_new_coverage.append(callback)

    def on_stats_update(self, callback: Callable[[FuzzingStats], None]) -> None:
        """Register stats update callback."""
        self._on_stats_update.append(callback)

    def _get_input(self) -> bytes:
        """Get next input to fuzz."""
        if self.strategy == FuzzingStrategy.RANDOM:
            return self._generator.generate()

        elif self.strategy == FuzzingStrategy.GENERATION:
            return self._generator.generate()

        elif self.strategy in (FuzzingStrategy.MUTATION, FuzzingStrategy.COVERAGE_GUIDED):
            base = self.corpus.get_random()
            if base:
                mutator = random.choice(self._mutators)
                return mutator.mutate(base.data)
            else:
                return self._generator.generate()

        elif self.strategy == FuzzingStrategy.DICTIONARY:
            base = self.corpus.get_random()
            if base and self._dict_mutator.dictionary:
                return self._dict_mutator.mutate(base.data)
            else:
                return self._generator.generate()

        elif self.strategy == FuzzingStrategy.HYBRID:
            # Mix of mutation and generation
            if random.random() < 0.2:
                return self._generator.generate()
            else:
                base = self.corpus.get_random()
                if base:
                    mutator = random.choice(self._mutators)
                    return mutator.mutate(base.data)
                return self._generator.generate()

        return self._generator.generate()

    def _run_one(self, data: bytes) -> tuple[bool, CrashInfo | None, CoverageInfo]:
        """Run a single test case."""
        start_time = time.time()

        self.harness.setup(data)
        crashed, crash_info, coverage = self.harness.run(data)
        self.harness.reset()

        exec_time = time.time() - start_time

        return crashed, crash_info, coverage

    def _handle_crash(self, crash_info: CrashInfo) -> None:
        """Handle a crash."""
        self.stats.total_crashes += 1

        if crash_info.dedupe_hash not in self._crashes:
            self._crashes[crash_info.dedupe_hash] = crash_info
            self.stats.unique_crashes += 1

            # Save crash
            if self.crash_path:
                self.crash_path.mkdir(parents=True, exist_ok=True)
                crash_file = self.crash_path / f"crash_{crash_info.dedupe_hash}.bin"
                crash_info.test_case.save(crash_file)

                # Save crash info
                info_file = self.crash_path / f"crash_{crash_info.dedupe_hash}.json"
                with open(info_file, 'w') as f:
                    json.dump(crash_info.to_dict(), f, indent=2)

            # Call callbacks
            for callback in self._on_crash:
                try:
                    callback(crash_info)
                except Exception as e:
                    logger.error(f"Crash callback error: {e}")

    def _handle_new_coverage(self, test_case: TestCase) -> None:
        """Handle test case with new coverage."""
        self.stats.last_new_path = time.time()

        # Add to corpus
        self.corpus.add(test_case)
        self.stats.corpus_size = len(self.corpus)

        # Call callbacks
        for callback in self._on_new_coverage:
            try:
                callback(test_case)
            except Exception as e:
                logger.error(f"New coverage callback error: {e}")

    def _update_stats(self) -> None:
        """Update statistics."""
        self.stats.elapsed_time = time.time() - self.stats.start_time
        self.stats.coverage_edges = len(self.coverage.edges)
        self.stats.coverage_blocks = len(self.coverage.blocks)

        for callback in self._on_stats_update:
            try:
                callback(self.stats)
            except Exception as e:
                logger.error(f"Stats callback error: {e}")

    def fuzz_one(self) -> bool:
        """
        Run a single fuzzing iteration.
        
        Returns:
            True if new coverage was found.
        """
        data = self._get_input()
        crashed, crash_info, coverage = self._run_one(data)

        self.stats.total_executions += 1

        # Check for new coverage
        new_edges = self.coverage.merge(coverage)
        found_new = new_edges > 0

        if crashed and crash_info:
            test_case = TestCase(
                data=data,
                source="fuzz",
                coverage=coverage,
            )
            crash_info.test_case = test_case
            self._handle_crash(crash_info)

        if found_new:
            test_case = TestCase(
                data=data,
                source="fuzz",
                coverage=coverage,
            )
            self._handle_new_coverage(test_case)

        return found_new

    def fuzz(
        self,
        max_iterations: int | None = None,
        max_time: float | None = None,
        stop_on_crash: bool = False,
    ) -> FuzzingStats:
        """
        Run fuzzing loop.
        
        Args:
            max_iterations: Maximum number of iterations.
            max_time: Maximum time in seconds.
            stop_on_crash: Stop on first crash.
        
        Returns:
            Fuzzing statistics.
        """
        self.state = FuzzingState.RUNNING
        self.stats.start_time = time.time()

        # Update splice mutator corpus
        self._splice_mutator.set_corpus(self.corpus.get_data_list())

        iteration = 0
        window_start = time.time()
        window_execs = 0

        try:
            while self.state == FuzzingState.RUNNING:
                # Check limits
                if max_iterations and iteration >= max_iterations:
                    break
                if max_time and (time.time() - self.stats.start_time) >= max_time:
                    break

                # Run one iteration
                self.fuzz_one()

                iteration += 1
                window_execs += 1

                # Update exec/sec periodically
                window_time = time.time() - window_start
                if window_time >= 1.0:
                    self.stats.update_execs_per_second(window_execs, window_time)
                    window_start = time.time()
                    window_execs = 0
                    self._update_stats()

                # Check for crash stop
                if stop_on_crash and self.stats.unique_crashes > 0:
                    break

                # Update splice corpus periodically
                if iteration % 100 == 0:
                    self._splice_mutator.set_corpus(self.corpus.get_data_list())

        except KeyboardInterrupt:
            logger.info("Fuzzing interrupted by user")

        finally:
            self.state = FuzzingState.STOPPED
            self._update_stats()

        return self.stats

    def pause(self) -> None:
        """Pause fuzzing."""
        if self.state == FuzzingState.RUNNING:
            self.state = FuzzingState.PAUSED

    def resume(self) -> None:
        """Resume fuzzing."""
        if self.state == FuzzingState.PAUSED:
            self.state = FuzzingState.RUNNING

    def stop(self) -> None:
        """Stop fuzzing."""
        self.state = FuzzingState.STOPPED

    def get_crashes(self) -> list[CrashInfo]:
        """Get all unique crashes."""
        return list(self._crashes.values())

    def get_report(self) -> dict[str, Any]:
        """Get fuzzing report."""
        return {
            "stats": self.stats.to_dict(),
            "coverage": self.coverage.to_dict(),
            "crashes": [c.to_dict() for c in self._crashes.values()],
            "corpus_size": len(self.corpus),
            "strategy": self.strategy.name,
        }

    def save_report(self, path: str | Path) -> None:
        """Save fuzzing report to file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w') as f:
            json.dump(self.get_report(), f, indent=2)

    def print_summary(self) -> None:
        """Print fuzzing summary to console."""
        print("\n" + "=" * 60)
        print("FUZZING SUMMARY")
        print("=" * 60)
        print(f"State:              {self.state.name}")
        print(f"Strategy:           {self.strategy.name}")
        print(f"Total Executions:   {self.stats.total_executions:,}")
        print(f"Exec/sec:           {self.stats.executions_per_second:.1f}")
        print(f"Peak Exec/sec:      {self.stats.peak_execs_per_second:.1f}")
        print(f"Elapsed Time:       {self.stats.elapsed_time:.1f}s")
        print("-" * 60)
        print(f"Unique Crashes:     {self.stats.unique_crashes}")
        print(f"Total Crashes:      {self.stats.total_crashes}")
        print(f"Coverage (edges):   {len(self.coverage.edges):,}")
        print(f"Coverage (blocks):  {len(self.coverage.blocks):,}")
        print(f"Corpus Size:        {len(self.corpus)}")
        print("=" * 60 + "\n")

    def __repr__(self) -> str:
        return (
            f"Fuzzer(strategy={self.strategy.name}, "
            f"state={self.state.name}, "
            f"execs={self.stats.total_executions}, "
            f"crashes={self.stats.unique_crashes})"
        )


def create_fuzzer(
    harness: FuzzingHarness | None = None,
    strategy: FuzzingStrategy = FuzzingStrategy.COVERAGE_GUIDED,
    corpus_path: str | None = None,
    crash_path: str | None = None,
    dictionary_path: str | None = None,
    seed_dir: str | None = None,
) -> Fuzzer:
    """
    Create a configured fuzzer.
    
    Args:
        harness: Fuzzing harness.
        strategy: Fuzzing strategy.
        corpus_path: Path for corpus storage.
        crash_path: Path for crash storage.
        dictionary_path: Path to dictionary file.
        seed_dir: Path to seed directory.
    
    Returns:
        Configured Fuzzer instance.
    """
    fuzzer = Fuzzer(
        harness=harness,
        strategy=strategy,
        corpus_path=corpus_path,
        crash_path=crash_path,
    )

    if dictionary_path:
        fuzzer.load_dictionary(dictionary_path)

    if seed_dir:
        fuzzer.add_seeds_from_dir(seed_dir)

    return fuzzer
