"""
Binary Diffing Module for PyUniDbg.

Provides binary diffing capabilities for comparing two binaries,
detecting changes in functions, basic blocks, and instructions.
"""

from __future__ import annotations

import hashlib
import json
import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from enum import Enum, auto
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
)

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)


class MatchType(Enum):
    """Types of matches between elements."""

    IDENTICAL = auto()
    SIMILAR = auto()
    MODIFIED = auto()
    ADDED = auto()
    REMOVED = auto()
    RELOCATED = auto()


class ChangeType(Enum):
    """Types of changes."""

    NONE = auto()
    ADDED = auto()
    REMOVED = auto()
    MODIFIED = auto()
    REORDERED = auto()


class DiffLevel(Enum):
    """Level of diffing detail."""

    FUNCTION = auto()
    BASIC_BLOCK = auto()
    INSTRUCTION = auto()


@dataclass
class Instruction:
    """Represents a single instruction."""

    address: int
    size: int
    mnemonic: str
    operands: str
    bytes: bytes = b""

    @property
    def disassembly(self) -> str:
        """Get full disassembly string."""
        return f"{self.mnemonic} {self.operands}".strip()

    def normalized(self) -> str:
        """Get normalized instruction (addresses replaced)."""
        # Replace address-like operands with placeholders
        import re
        normalized = self.disassembly
        # Replace hex addresses
        normalized = re.sub(r'0x[0-9a-fA-F]+', 'ADDR', normalized)
        # Replace decimal numbers that look like addresses
        normalized = re.sub(r'\b\d{6,}\b', 'ADDR', normalized)
        return normalized

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "address": hex(self.address),
            "size": self.size,
            "mnemonic": self.mnemonic,
            "operands": self.operands,
            "bytes": self.bytes.hex() if self.bytes else "",
        }

    def __hash__(self) -> int:
        return hash((self.address, self.mnemonic, self.operands))


@dataclass
class BasicBlock:
    """Represents a basic block."""

    start_address: int
    end_address: int
    instructions: list[Instruction] = field(default_factory=list)
    successors: list[int] = field(default_factory=list)
    predecessors: list[int] = field(default_factory=list)

    @property
    def size(self) -> int:
        """Get block size in bytes."""
        return self.end_address - self.start_address

    @property
    def instruction_count(self) -> int:
        """Get number of instructions."""
        return len(self.instructions)

    def get_hash(self) -> str:
        """Get hash of the block based on normalized instructions."""
        normalized = [i.normalized() for i in self.instructions]
        content = "\n".join(normalized)
        return hashlib.md5(content.encode()).hexdigest()[:12]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "start_address": hex(self.start_address),
            "end_address": hex(self.end_address),
            "size": self.size,
            "instruction_count": self.instruction_count,
            "successors": [hex(s) for s in self.successors],
            "predecessors": [hex(p) for p in self.predecessors],
            "hash": self.get_hash(),
        }

    def __hash__(self) -> int:
        return hash(self.start_address)


@dataclass
class Function:
    """Represents a function."""

    address: int
    name: str
    size: int = 0
    basic_blocks: list[BasicBlock] = field(default_factory=list)
    calls: list[int] = field(default_factory=list)
    callers: list[int] = field(default_factory=list)

    @property
    def block_count(self) -> int:
        """Get number of basic blocks."""
        return len(self.basic_blocks)

    @property
    def instruction_count(self) -> int:
        """Get total number of instructions."""
        return sum(bb.instruction_count for bb in self.basic_blocks)

    def get_hash(self) -> str:
        """Get hash of the function based on block hashes."""
        block_hashes = [bb.get_hash() for bb in sorted(self.basic_blocks, key=lambda b: b.start_address)]
        content = ":".join(block_hashes)
        return hashlib.md5(content.encode()).hexdigest()[:16]

    def get_signature(self) -> tuple[int, int, int]:
        """Get function signature (blocks, edges, calls)."""
        edges = sum(len(bb.successors) for bb in self.basic_blocks)
        return (self.block_count, edges, len(self.calls))

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "address": hex(self.address),
            "name": self.name,
            "size": self.size,
            "block_count": self.block_count,
            "instruction_count": self.instruction_count,
            "call_count": len(self.calls),
            "caller_count": len(self.callers),
            "hash": self.get_hash(),
            "signature": self.get_signature(),
        }

    def __hash__(self) -> int:
        return hash(self.address)


@dataclass
class InstructionMatch:
    """Match between two instructions."""

    instruction1: Instruction | None
    instruction2: Instruction | None
    match_type: MatchType
    similarity: float = 1.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "instruction1": self.instruction1.to_dict() if self.instruction1 else None,
            "instruction2": self.instruction2.to_dict() if self.instruction2 else None,
            "match_type": self.match_type.name,
            "similarity": self.similarity,
        }


@dataclass
class BlockMatch:
    """Match between two basic blocks."""

    block1: BasicBlock | None
    block2: BasicBlock | None
    match_type: MatchType
    similarity: float = 1.0
    instruction_matches: list[InstructionMatch] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "block1": self.block1.to_dict() if self.block1 else None,
            "block2": self.block2.to_dict() if self.block2 else None,
            "match_type": self.match_type.name,
            "similarity": self.similarity,
            "instruction_matches_count": len(self.instruction_matches),
        }


@dataclass
class FunctionMatch:
    """Match between two functions."""

    function1: Function | None
    function2: Function | None
    match_type: MatchType
    similarity: float = 1.0
    block_matches: list[BlockMatch] = field(default_factory=list)

    @property
    def changed_blocks(self) -> int:
        """Get number of changed blocks."""
        return sum(1 for m in self.block_matches if m.match_type != MatchType.IDENTICAL)

    @property
    def added_blocks(self) -> int:
        """Get number of added blocks."""
        return sum(1 for m in self.block_matches if m.match_type == MatchType.ADDED)

    @property
    def removed_blocks(self) -> int:
        """Get number of removed blocks."""
        return sum(1 for m in self.block_matches if m.match_type == MatchType.REMOVED)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "function1": self.function1.to_dict() if self.function1 else None,
            "function2": self.function2.to_dict() if self.function2 else None,
            "match_type": self.match_type.name,
            "similarity": round(self.similarity, 4),
            "changed_blocks": self.changed_blocks,
            "added_blocks": self.added_blocks,
            "removed_blocks": self.removed_blocks,
            "block_matches_count": len(self.block_matches),
        }


@dataclass
class DiffResult:
    """Result of a binary diff operation."""

    binary1_path: str = ""
    binary2_path: str = ""
    function_matches: list[FunctionMatch] = field(default_factory=list)
    matched_count: int = 0
    identical_count: int = 0
    modified_count: int = 0
    added_count: int = 0
    removed_count: int = 0
    similarity: float = 0.0

    def get_matched_functions(self) -> list[FunctionMatch]:
        """Get all matched functions (not added/removed)."""
        return [m for m in self.function_matches
                if m.match_type not in (MatchType.ADDED, MatchType.REMOVED)]

    def get_modified_functions(self) -> list[FunctionMatch]:
        """Get only modified functions."""
        return [m for m in self.function_matches
                if m.match_type == MatchType.MODIFIED]

    def get_added_functions(self) -> list[FunctionMatch]:
        """Get only added functions."""
        return [m for m in self.function_matches
                if m.match_type == MatchType.ADDED]

    def get_removed_functions(self) -> list[FunctionMatch]:
        """Get only removed functions."""
        return [m for m in self.function_matches
                if m.match_type == MatchType.REMOVED]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "binary1": self.binary1_path,
            "binary2": self.binary2_path,
            "summary": {
                "matched": self.matched_count,
                "identical": self.identical_count,
                "modified": self.modified_count,
                "added": self.added_count,
                "removed": self.removed_count,
                "similarity": round(self.similarity, 4),
            },
            "function_matches": [m.to_dict() for m in self.function_matches],
        }

    def save(self, path: str | Path) -> None:
        """Save diff result to JSON file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, path: str | Path) -> DiffResult:
        """Load diff result from JSON file."""
        with open(path) as f:
            data = json.load(f)

        result = cls(
            binary1_path=data.get("binary1", ""),
            binary2_path=data.get("binary2", ""),
        )
        summary = data.get("summary", {})
        result.matched_count = summary.get("matched", 0)
        result.identical_count = summary.get("identical", 0)
        result.modified_count = summary.get("modified", 0)
        result.added_count = summary.get("added", 0)
        result.removed_count = summary.get("removed", 0)
        result.similarity = summary.get("similarity", 0.0)

        return result


class MatchingAlgorithm(ABC):
    """Abstract base class for matching algorithms."""

    @abstractmethod
    def match_functions(
        self,
        functions1: list[Function],
        functions2: list[Function],
    ) -> list[tuple[Function | None, Function | None, float]]:
        """
        Match functions between two sets.
        
        Returns:
            List of (func1, func2, similarity) tuples.
        """
        pass

    @abstractmethod
    def match_blocks(
        self,
        blocks1: list[BasicBlock],
        blocks2: list[BasicBlock],
    ) -> list[tuple[BasicBlock | None, BasicBlock | None, float]]:
        """
        Match basic blocks between two sets.
        
        Returns:
            List of (block1, block2, similarity) tuples.
        """
        pass


class HashMatchingAlgorithm(MatchingAlgorithm):
    """Matching algorithm based on hash comparison."""

    def match_functions(
        self,
        functions1: list[Function],
        functions2: list[Function],
    ) -> list[tuple[Function | None, Function | None, float]]:
        """Match functions by hash."""
        matches = []

        # Build hash maps
        hash_to_func1: dict[str, Function] = {f.get_hash(): f for f in functions1}
        hash_to_func2: dict[str, Function] = {f.get_hash(): f for f in functions2}

        matched1: set[int] = set()
        matched2: set[int] = set()

        # Exact hash matches
        for h, f1 in hash_to_func1.items():
            if h in hash_to_func2:
                f2 = hash_to_func2[h]
                matches.append((f1, f2, 1.0))
                matched1.add(f1.address)
                matched2.add(f2.address)

        # Unmatched from binary1
        for f1 in functions1:
            if f1.address not in matched1:
                matches.append((f1, None, 0.0))

        # Unmatched from binary2
        for f2 in functions2:
            if f2.address not in matched2:
                matches.append((None, f2, 0.0))

        return matches

    def match_blocks(
        self,
        blocks1: list[BasicBlock],
        blocks2: list[BasicBlock],
    ) -> list[tuple[BasicBlock | None, BasicBlock | None, float]]:
        """Match blocks by hash."""
        matches = []

        hash_to_block1 = {b.get_hash(): b for b in blocks1}
        hash_to_block2 = {b.get_hash(): b for b in blocks2}

        matched1: set[int] = set()
        matched2: set[int] = set()

        # Exact hash matches
        for h, b1 in hash_to_block1.items():
            if h in hash_to_block2:
                b2 = hash_to_block2[h]
                matches.append((b1, b2, 1.0))
                matched1.add(b1.start_address)
                matched2.add(b2.start_address)

        # Unmatched from binary1
        for b1 in blocks1:
            if b1.start_address not in matched1:
                matches.append((b1, None, 0.0))

        # Unmatched from binary2
        for b2 in blocks2:
            if b2.start_address not in matched2:
                matches.append((None, b2, 0.0))

        return matches


class SignatureMatchingAlgorithm(MatchingAlgorithm):
    """Matching algorithm based on function signatures."""

    def __init__(self, similarity_threshold: float = 0.7):
        self.similarity_threshold = similarity_threshold

    def _compute_function_similarity(self, f1: Function, f2: Function) -> float:
        """Compute similarity between two functions."""
        # Compare signatures
        sig1 = f1.get_signature()
        sig2 = f2.get_signature()

        if sig1 == sig2:
            return 1.0

        # Compare block count
        max_blocks = max(f1.block_count, f2.block_count, 1)
        block_sim = 1 - abs(f1.block_count - f2.block_count) / max_blocks

        # Compare instruction count
        max_instrs = max(f1.instruction_count, f2.instruction_count, 1)
        instr_sim = 1 - abs(f1.instruction_count - f2.instruction_count) / max_instrs

        # Compare call count
        max_calls = max(len(f1.calls), len(f2.calls), 1)
        call_sim = 1 - abs(len(f1.calls) - len(f2.calls)) / max_calls

        return (block_sim + instr_sim + call_sim) / 3

    def match_functions(
        self,
        functions1: list[Function],
        functions2: list[Function],
    ) -> list[tuple[Function | None, Function | None, float]]:
        """Match functions by signature similarity."""
        matches = []
        matched1: set[int] = set()
        matched2: set[int] = set()

        # First pass: name matching
        name_to_func2 = {f.name: f for f in functions2 if f.name}
        for f1 in functions1:
            if f1.name and f1.name in name_to_func2:
                f2 = name_to_func2[f1.name]
                similarity = self._compute_function_similarity(f1, f2)
                matches.append((f1, f2, similarity))
                matched1.add(f1.address)
                matched2.add(f2.address)

        # Second pass: signature matching for remaining
        remaining1 = [f for f in functions1 if f.address not in matched1]
        remaining2 = [f for f in functions2 if f.address not in matched2]

        for f1 in remaining1:
            best_match = None
            best_sim = self.similarity_threshold

            for f2 in remaining2:
                if f2.address in matched2:
                    continue
                sim = self._compute_function_similarity(f1, f2)
                if sim > best_sim:
                    best_sim = sim
                    best_match = f2

            if best_match:
                matches.append((f1, best_match, best_sim))
                matched1.add(f1.address)
                matched2.add(best_match.address)
            else:
                matches.append((f1, None, 0.0))

        # Unmatched from binary2
        for f2 in functions2:
            if f2.address not in matched2:
                matches.append((None, f2, 0.0))

        return matches

    def match_blocks(
        self,
        blocks1: list[BasicBlock],
        blocks2: list[BasicBlock],
    ) -> list[tuple[BasicBlock | None, BasicBlock | None, float]]:
        """Match blocks by similarity."""
        matches = []
        matched2: set[int] = set()

        for b1 in blocks1:
            best_match = None
            best_sim = self.similarity_threshold

            for b2 in blocks2:
                if b2.start_address in matched2:
                    continue

                # Compare normalized instructions
                instrs1 = [i.normalized() for i in b1.instructions]
                instrs2 = [i.normalized() for i in b2.instructions]

                if instrs1 == instrs2:
                    best_match = b2
                    best_sim = 1.0
                    break

                # Use sequence matcher for similarity
                matcher = SequenceMatcher(None, instrs1, instrs2)
                sim = matcher.ratio()

                if sim > best_sim:
                    best_sim = sim
                    best_match = b2

            if best_match:
                matches.append((b1, best_match, best_sim))
                matched2.add(best_match.start_address)
            else:
                matches.append((b1, None, 0.0))

        # Unmatched from binary2
        for b2 in blocks2:
            if b2.start_address not in matched2:
                matches.append((None, b2, 0.0))

        return matches


class BinaryDiffer:
    """Main binary diffing class."""

    def __init__(
        self,
        algorithm: MatchingAlgorithm | None = None,
        similarity_threshold: float = 0.7,
    ):
        self.algorithm = algorithm or SignatureMatchingAlgorithm(similarity_threshold)
        self.similarity_threshold = similarity_threshold

        self._functions1: list[Function] = []
        self._functions2: list[Function] = []

    def set_binary1_functions(self, functions: list[Function]) -> None:
        """Set functions from binary 1."""
        self._functions1 = functions

    def set_binary2_functions(self, functions: list[Function]) -> None:
        """Set functions from binary 2."""
        self._functions2 = functions

    def add_function1(self, function: Function) -> None:
        """Add a function from binary 1."""
        self._functions1.append(function)

    def add_function2(self, function: Function) -> None:
        """Add a function from binary 2."""
        self._functions2.append(function)

    def diff(
        self,
        binary1_path: str = "",
        binary2_path: str = "",
        level: DiffLevel = DiffLevel.FUNCTION,
    ) -> DiffResult:
        """
        Perform binary diff.
        
        Args:
            binary1_path: Path to first binary (for metadata).
            binary2_path: Path to second binary (for metadata).
            level: Detail level for diffing.
        
        Returns:
            DiffResult with all matches.
        """
        result = DiffResult(
            binary1_path=binary1_path,
            binary2_path=binary2_path,
        )

        # Match functions
        raw_matches = self.algorithm.match_functions(
            self._functions1,
            self._functions2,
        )

        for f1, f2, similarity in raw_matches:
            # Determine match type
            if f1 is None:
                match_type = MatchType.ADDED
                result.added_count += 1
            elif f2 is None:
                match_type = MatchType.REMOVED
                result.removed_count += 1
            elif similarity >= 0.999:
                match_type = MatchType.IDENTICAL
                result.identical_count += 1
                result.matched_count += 1
            elif similarity >= self.similarity_threshold:
                match_type = MatchType.MODIFIED
                result.modified_count += 1
                result.matched_count += 1
            else:
                match_type = MatchType.SIMILAR
                result.matched_count += 1

            func_match = FunctionMatch(
                function1=f1,
                function2=f2,
                match_type=match_type,
                similarity=similarity,
            )

            # Optionally diff blocks
            if level in (DiffLevel.BASIC_BLOCK, DiffLevel.INSTRUCTION) and f1 and f2:
                block_matches = self._diff_blocks(f1, f2, level)
                func_match.block_matches = block_matches

            result.function_matches.append(func_match)

        # Calculate overall similarity
        total_funcs = len(self._functions1) + len(self._functions2)
        if total_funcs > 0:
            matched_funcs = result.matched_count * 2
            result.similarity = matched_funcs / total_funcs

        return result

    def _diff_blocks(
        self,
        func1: Function,
        func2: Function,
        level: DiffLevel,
    ) -> list[BlockMatch]:
        """Diff basic blocks between two functions."""
        block_matches = []

        raw_matches = self.algorithm.match_blocks(
            func1.basic_blocks,
            func2.basic_blocks,
        )

        for b1, b2, similarity in raw_matches:
            if b1 is None:
                match_type = MatchType.ADDED
            elif b2 is None:
                match_type = MatchType.REMOVED
            elif similarity >= 0.999:
                match_type = MatchType.IDENTICAL
            elif similarity >= self.similarity_threshold:
                match_type = MatchType.MODIFIED
            else:
                match_type = MatchType.SIMILAR

            block_match = BlockMatch(
                block1=b1,
                block2=b2,
                match_type=match_type,
                similarity=similarity,
            )

            # Optionally diff instructions
            if level == DiffLevel.INSTRUCTION and b1 and b2:
                instr_matches = self._diff_instructions(b1, b2)
                block_match.instruction_matches = instr_matches

            block_matches.append(block_match)

        return block_matches

    def _diff_instructions(
        self,
        block1: BasicBlock,
        block2: BasicBlock,
    ) -> list[InstructionMatch]:
        """Diff instructions between two blocks."""
        instr_matches = []

        instrs1 = block1.instructions
        instrs2 = block2.instructions

        # Use sequence matcher to find matching instructions
        normalized1 = [i.normalized() for i in instrs1]
        normalized2 = [i.normalized() for i in instrs2]

        matcher = SequenceMatcher(None, normalized1, normalized2)

        matched1: set[int] = set()
        matched2: set[int] = set()

        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == 'equal':
                for idx1, idx2 in zip(range(i1, i2), range(j1, j2)):
                    instr_matches.append(InstructionMatch(
                        instruction1=instrs1[idx1],
                        instruction2=instrs2[idx2],
                        match_type=MatchType.IDENTICAL,
                        similarity=1.0,
                    ))
                    matched1.add(idx1)
                    matched2.add(idx2)
            elif tag == 'replace':
                for idx1 in range(i1, i2):
                    if idx1 - i1 + j1 < j2:
                        idx2 = idx1 - i1 + j1
                        instr_matches.append(InstructionMatch(
                            instruction1=instrs1[idx1],
                            instruction2=instrs2[idx2],
                            match_type=MatchType.MODIFIED,
                            similarity=0.5,
                        ))
                        matched1.add(idx1)
                        matched2.add(idx2)
                    else:
                        instr_matches.append(InstructionMatch(
                            instruction1=instrs1[idx1],
                            instruction2=None,
                            match_type=MatchType.REMOVED,
                            similarity=0.0,
                        ))
                        matched1.add(idx1)

                for idx2 in range(j1, j2):
                    if idx2 not in matched2:
                        instr_matches.append(InstructionMatch(
                            instruction1=None,
                            instruction2=instrs2[idx2],
                            match_type=MatchType.ADDED,
                            similarity=0.0,
                        ))
                        matched2.add(idx2)
            elif tag == 'delete':
                for idx1 in range(i1, i2):
                    instr_matches.append(InstructionMatch(
                        instruction1=instrs1[idx1],
                        instruction2=None,
                        match_type=MatchType.REMOVED,
                        similarity=0.0,
                    ))
                    matched1.add(idx1)
            elif tag == 'insert':
                for idx2 in range(j1, j2):
                    instr_matches.append(InstructionMatch(
                        instruction1=None,
                        instruction2=instrs2[idx2],
                        match_type=MatchType.ADDED,
                        similarity=0.0,
                    ))
                    matched2.add(idx2)

        return instr_matches

    def get_summary(self) -> dict[str, Any]:
        """Get summary of current state."""
        return {
            "binary1_functions": len(self._functions1),
            "binary2_functions": len(self._functions2),
            "algorithm": type(self.algorithm).__name__,
            "similarity_threshold": self.similarity_threshold,
        }

    def print_summary(self, result: DiffResult) -> None:
        """Print diff summary to console."""
        print("\n" + "=" * 60)
        print("BINARY DIFF SUMMARY")
        print("=" * 60)
        print(f"Binary 1: {result.binary1_path or 'N/A'}")
        print(f"Binary 2: {result.binary2_path or 'N/A'}")
        print("-" * 60)
        print(f"Functions in Binary 1: {len(self._functions1)}")
        print(f"Functions in Binary 2: {len(self._functions2)}")
        print("-" * 60)
        print(f"Matched Functions:   {result.matched_count}")
        print(f"  Identical:         {result.identical_count}")
        print(f"  Modified:          {result.modified_count}")
        print(f"Added Functions:     {result.added_count}")
        print(f"Removed Functions:   {result.removed_count}")
        print("-" * 60)
        print(f"Overall Similarity:  {result.similarity:.2%}")
        print("=" * 60 + "\n")

    def __repr__(self) -> str:
        return (
            f"BinaryDiffer(algorithm={type(self.algorithm).__name__}, "
            f"funcs1={len(self._functions1)}, "
            f"funcs2={len(self._functions2)})"
        )


class PatchAnalyzer:
    """Analyzes patches between two binary versions."""

    def __init__(self, differ: BinaryDiffer | None = None):
        self.differ = differ or BinaryDiffer()

    def analyze_security_patch(self, result: DiffResult) -> dict[str, Any]:
        """
        Analyze diff for potential security patches.
        
        Looks for patterns that might indicate security fixes.
        """
        findings = {
            "potentially_patched_functions": [],
            "added_checks": [],
            "removed_dangerous_patterns": [],
            "summary": {
                "high_priority": 0,
                "medium_priority": 0,
                "low_priority": 0,
            },
        }

        # Keywords that might indicate security-related changes
        security_keywords = [
            "check", "validate", "verify", "sanitize", "escape",
            "auth", "permission", "bounds", "overflow", "underflow",
            "buffer", "length", "size", "null", "safe",
        ]

        for match in result.get_modified_functions():
            if not match.function1 or not match.function2:
                continue

            name = match.function1.name.lower()

            # Check if function name contains security keywords
            for keyword in security_keywords:
                if keyword in name:
                    findings["potentially_patched_functions"].append({
                        "name": match.function1.name,
                        "address1": hex(match.function1.address),
                        "address2": hex(match.function2.address),
                        "similarity": match.similarity,
                        "keyword": keyword,
                    })
                    findings["summary"]["high_priority"] += 1
                    break
            else:
                # Check block changes
                if match.added_blocks > 0:
                    findings["added_checks"].append({
                        "function": match.function1.name,
                        "added_blocks": match.added_blocks,
                    })
                    findings["summary"]["medium_priority"] += 1

        return findings

    def get_change_statistics(self, result: DiffResult) -> dict[str, Any]:
        """Get detailed change statistics."""
        stats = {
            "total_functions_1": len(result.function_matches) - result.added_count,
            "total_functions_2": len(result.function_matches) - result.removed_count,
            "matched": result.matched_count,
            "identical": result.identical_count,
            "modified": result.modified_count,
            "added": result.added_count,
            "removed": result.removed_count,
            "match_rate": 0.0,
            "identical_rate": 0.0,
            "modification_rate": 0.0,
        }

        total_1 = stats["total_functions_1"]
        if total_1 > 0:
            stats["match_rate"] = stats["matched"] / total_1
            stats["identical_rate"] = stats["identical"] / total_1
            stats["modification_rate"] = stats["modified"] / total_1

        return stats


def create_differ(
    algorithm: str = "signature",
    similarity_threshold: float = 0.7,
) -> BinaryDiffer:
    """
    Create a binary differ with specified algorithm.
    
    Args:
        algorithm: Algorithm name ("hash" or "signature").
        similarity_threshold: Threshold for matching.
    
    Returns:
        Configured BinaryDiffer instance.
    """
    if algorithm == "hash":
        algo = HashMatchingAlgorithm()
    else:
        algo = SignatureMatchingAlgorithm(similarity_threshold)

    return BinaryDiffer(algorithm=algo, similarity_threshold=similarity_threshold)
