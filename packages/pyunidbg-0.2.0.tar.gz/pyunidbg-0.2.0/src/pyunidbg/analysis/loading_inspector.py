"""
Loading Inspector - Comprehensive library loading analysis.

Provides detailed introspection into the library loading process:
- Library load events with callbacks
- Dependency tree visualization
- Symbol resolution tracking
- Memory mapping trace
- Function call graph during loading
- Export/import analysis

Example:
    from pyunidbg.analysis import LoadingInspector
    
    inspector = LoadingInspector(emulator)
    
    # Register callbacks
    @inspector.on_library_load
    def on_load(event: LibraryLoadEvent):
        print(f"Loaded: {event.name} at {event.base_address:#x}")
        print(f"  Dependencies: {event.dependencies}")
        print(f"  Exports: {len(event.exports)}")
    
    @inspector.on_symbol_resolve
    def on_resolve(event: SymbolResolveEvent):
        print(f"Resolved: {event.symbol} -> {event.address:#x} (from {event.provider})")
    
    # Load library with inspection
    lib = emulator.load_library("libnative.so")
    
    # Get reports
    print(inspector.get_dependency_tree())
    inspector.export_report("loading_report.json")
    inspector.export_html_report("loading_report.html")
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator

logger = logging.getLogger(__name__)


# ==================== Events ====================

class LoadingEventType(Enum):
    """Types of loading events."""
    LIBRARY_LOAD_START = auto()
    LIBRARY_LOAD_COMPLETE = auto()
    DEPENDENCY_RESOLVE = auto()
    SYMBOL_RESOLVE = auto()
    SYMBOL_UNRESOLVED = auto()
    RELOCATION_APPLY = auto()
    MEMORY_MAP = auto()
    INIT_FUNCTION_CALL = auto()
    JNI_ONLOAD_CALL = auto()


@dataclass
class LoadingEvent:
    """Base class for loading events."""
    timestamp: float
    event_type: LoadingEventType

    def to_dict(self) -> dict:
        """Convert to dictionary for serialization."""
        return {
            "timestamp": self.timestamp,
            "event_type": self.event_type.name,
        }


@dataclass
class LibraryLoadEvent(LoadingEvent):
    """Event when a library is loaded."""
    name: str
    path: str
    base_address: int
    size: int
    dependencies: list[str] = field(default_factory=list)
    exports: dict[str, int] = field(default_factory=dict)
    imports: dict[str, str] = field(default_factory=dict)  # symbol -> providing library
    init_functions: list[int] = field(default_factory=list)
    jni_onload: int | None = None
    load_order: int = 0
    parent_library: str | None = None  # Which library caused this to load

    def to_dict(self) -> dict:
        return {
            **super().to_dict(),
            "name": self.name,
            "path": self.path,
            "base_address": hex(self.base_address),
            "size": self.size,
            "dependencies": self.dependencies,
            "exports_count": len(self.exports),
            "imports_count": len(self.imports),
            "init_functions": [hex(a) for a in self.init_functions],
            "jni_onload": hex(self.jni_onload) if self.jni_onload else None,
            "load_order": self.load_order,
            "parent_library": self.parent_library,
        }


@dataclass
class SymbolResolveEvent(LoadingEvent):
    """Event when a symbol is resolved."""
    symbol: str
    address: int
    provider_library: str
    consumer_library: str
    symbol_type: str = "FUNC"  # FUNC, OBJECT, etc.
    binding: str = "GLOBAL"  # GLOBAL, WEAK, LOCAL

    def to_dict(self) -> dict:
        return {
            **super().to_dict(),
            "symbol": self.symbol,
            "address": hex(self.address),
            "provider": self.provider_library,
            "consumer": self.consumer_library,
            "type": self.symbol_type,
            "binding": self.binding,
        }


@dataclass
class SymbolUnresolvedEvent(LoadingEvent):
    """Event when a symbol cannot be resolved."""
    symbol: str
    consumer_library: str
    reason: str = "not_found"

    def to_dict(self) -> dict:
        return {
            **super().to_dict(),
            "symbol": self.symbol,
            "consumer": self.consumer_library,
            "reason": self.reason,
        }


@dataclass
class DependencyResolveEvent(LoadingEvent):
    """Event when a dependency is resolved."""
    dependency_name: str
    resolved_path: str
    parent_library: str
    already_loaded: bool = False

    def to_dict(self) -> dict:
        return {
            **super().to_dict(),
            "dependency": self.dependency_name,
            "resolved_path": self.resolved_path,
            "parent": self.parent_library,
            "already_loaded": self.already_loaded,
        }


@dataclass
class MemoryMapEvent(LoadingEvent):
    """Event when memory is mapped for a library."""
    library: str
    address: int
    size: int
    protection: str  # "rwx" style
    segment_type: str = "LOAD"

    def to_dict(self) -> dict:
        return {
            **super().to_dict(),
            "library": self.library,
            "address": hex(self.address),
            "size": self.size,
            "protection": self.protection,
            "segment_type": self.segment_type,
        }


@dataclass
class RelocationEvent(LoadingEvent):
    """Event when a relocation is applied."""
    library: str
    target_address: int
    relocation_type: str
    symbol: str | None = None
    value_written: int = 0

    def to_dict(self) -> dict:
        return {
            **super().to_dict(),
            "library": self.library,
            "target": hex(self.target_address),
            "type": self.relocation_type,
            "symbol": self.symbol,
            "value": hex(self.value_written),
        }


@dataclass
class InitFunctionEvent(LoadingEvent):
    """Event when an init function is called."""
    library: str
    function_address: int
    function_index: int
    is_jni_onload: bool = False
    return_value: int | None = None
    duration_ms: float = 0.0

    def to_dict(self) -> dict:
        return {
            **super().to_dict(),
            "library": self.library,
            "address": hex(self.function_address),
            "index": self.function_index,
            "is_jni_onload": self.is_jni_onload,
            "return_value": self.return_value,
            "duration_ms": self.duration_ms,
        }


# ==================== Dependency Tree ====================

@dataclass
class DependencyNode:
    """Node in the dependency tree."""
    name: str
    path: str
    base_address: int
    children: list[DependencyNode] = field(default_factory=list)
    exports_used: list[str] = field(default_factory=list)  # Symbols provided to children

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "path": self.path,
            "base_address": hex(self.base_address),
            "children": [c.to_dict() for c in self.children],
            "exports_used": self.exports_used[:10],  # Limit for readability
            "exports_used_count": len(self.exports_used),
        }

    def to_ascii(self, prefix: str = "", is_last: bool = True) -> str:
        """Generate ASCII tree representation."""
        connector = "└── " if is_last else "├── "
        lines = [f"{prefix}{connector}{self.name} @ {self.base_address:#x}"]

        child_prefix = prefix + ("    " if is_last else "│   ")
        for i, child in enumerate(self.children):
            is_child_last = (i == len(self.children) - 1)
            lines.append(child.to_ascii(child_prefix, is_child_last))

        return "\n".join(lines)


# ==================== Loading Statistics ====================

@dataclass
class LoadingStats:
    """Statistics about the loading process."""
    total_libraries: int = 0
    total_symbols_resolved: int = 0
    total_symbols_unresolved: int = 0
    total_relocations: int = 0
    total_memory_mapped: int = 0
    total_init_functions: int = 0
    total_jni_onload: int = 0
    load_time_ms: float = 0.0

    # Per-library breakdown
    library_stats: dict[str, dict] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "total_libraries": self.total_libraries,
            "total_symbols_resolved": self.total_symbols_resolved,
            "total_symbols_unresolved": self.total_symbols_unresolved,
            "total_relocations": self.total_relocations,
            "total_memory_mapped_bytes": self.total_memory_mapped,
            "total_init_functions": self.total_init_functions,
            "total_jni_onload": self.total_jni_onload,
            "load_time_ms": self.load_time_ms,
            "per_library": self.library_stats,
        }


# ==================== Loading Inspector ====================

class LoadingInspector:
    """
    Comprehensive library loading analysis.
    
    Hooks into the library loading process to capture detailed
    information about:
    - Which libraries are loaded and when
    - Dependency resolution order
    - Symbol resolution (which library provides which symbol)
    - Memory layout
    - Init function execution
    
    Example:
        inspector = LoadingInspector(emulator)
        
        @inspector.on_library_load
        def handle_load(event):
            print(f"Loaded: {event.name}")
        
        # Load libraries
        emulator.load_library("libnative.so")
        
        # Get analysis
        tree = inspector.get_dependency_tree()
        report = inspector.export_report("json")
    """

    def __init__(self, emulator: Emulator):
        self.emulator = emulator

        # Event storage
        self._events: list[LoadingEvent] = []
        self._library_events: dict[str, LibraryLoadEvent] = {}

        # Callbacks
        self._on_library_load_callbacks: list[Callable[[LibraryLoadEvent], None]] = []
        self._on_symbol_resolve_callbacks: list[Callable[[SymbolResolveEvent], None]] = []
        self._on_symbol_unresolved_callbacks: list[Callable[[SymbolUnresolvedEvent], None]] = []
        self._on_dependency_resolve_callbacks: list[Callable[[DependencyResolveEvent], None]] = []
        self._on_memory_map_callbacks: list[Callable[[MemoryMapEvent], None]] = []
        self._on_relocation_callbacks: list[Callable[[RelocationEvent], None]] = []
        self._on_init_function_callbacks: list[Callable[[InitFunctionEvent], None]] = []

        # State
        self._load_order = 0
        self._loading_stack: list[str] = []  # Track nested loading
        self._symbol_origins: dict[str, str] = {}  # symbol -> provider library
        self._enabled = True
        self._start_time: float = 0

        # Statistics
        self._stats = LoadingStats()

        # Install hooks
        self._install_hooks()

    def _install_hooks(self) -> None:
        """Install hooks into the emulator's loading infrastructure."""
        # Hook into ELF loader if available
        if hasattr(self.emulator, 'loader'):
            loader = self.emulator.loader

            # Wrap the load method
            original_load = loader.load

            def hooked_load(path, base_address=None, auto_init=True):
                return self._on_load_library(
                    original_load, path, base_address, auto_init
                )

            loader.load = hooked_load

            # Wrap symbol resolution
            if hasattr(loader, '_resolve_symbol'):
                original_resolve = loader._resolve_symbol

                def hooked_resolve(name, current_module):
                    return self._on_resolve_symbol(
                        original_resolve, name, current_module
                    )

                loader._resolve_symbol = hooked_resolve

        # Hook into dynamic linker if available
        if hasattr(self.emulator, 'linker'):
            linker = self.emulator.linker

            # Register callbacks
            if hasattr(linker, '_on_library_load'):
                linker._on_library_load.append(self._handle_linker_library_load)

            if hasattr(linker, '_on_symbol_resolve'):
                linker._on_symbol_resolve.append(self._handle_linker_symbol_resolve)

    # ==================== Hook Handlers ====================

    def _on_load_library(
        self,
        original_load: Callable,
        path,
        base_address,
        auto_init: bool,
    ):
        """Called when a library is being loaded."""
        if not self._enabled:
            return original_load(path, base_address, auto_init)

        path = Path(path)
        lib_name = path.stem
        parent = self._loading_stack[-1] if self._loading_stack else None

        # Record start
        if not self._start_time:
            self._start_time = time.time()

        # Push to loading stack
        self._loading_stack.append(lib_name)

        try:
            # Call original load
            module = original_load(path, base_address, auto_init)

            if module:
                # Create load event
                event = LibraryLoadEvent(
                    timestamp=time.time(),
                    event_type=LoadingEventType.LIBRARY_LOAD_COMPLETE,
                    name=module.name,
                    path=str(module.path),
                    base_address=module.base_address,
                    size=module.size,
                    dependencies=self._get_dependencies(module),
                    exports=self._get_exports(module),
                    imports={},  # Filled during symbol resolution
                    init_functions=getattr(module, 'init_array', []),
                    jni_onload=getattr(module, 'jni_onload', None),
                    load_order=self._load_order,
                    parent_library=parent,
                )

                self._load_order += 1
                self._events.append(event)
                self._library_events[module.name] = event

                # Update stats
                self._stats.total_libraries += 1
                self._stats.library_stats[module.name] = {
                    "exports": len(event.exports),
                    "base_address": hex(module.base_address),
                    "size": module.size,
                }

                # Register exports
                for sym_name in event.exports:
                    self._symbol_origins[sym_name] = module.name

                # Fire callbacks
                for callback in self._on_library_load_callbacks:
                    try:
                        callback(event)
                    except Exception as e:
                        logger.warning(f"Callback error: {e}")

                logger.debug(f"Inspector: Loaded {module.name} ({len(event.exports)} exports)")

            return module

        finally:
            self._loading_stack.pop()

    def _on_resolve_symbol(
        self,
        original_resolve: Callable,
        name: str,
        current_module,
    ):
        """Called when a symbol is being resolved."""
        if not self._enabled:
            return original_resolve(name, current_module)

        result = original_resolve(name, current_module)

        consumer_name = current_module.name if current_module else "unknown"

        if result:
            # Symbol resolved
            provider_name = self._symbol_origins.get(name, "unknown")

            event = SymbolResolveEvent(
                timestamp=time.time(),
                event_type=LoadingEventType.SYMBOL_RESOLVE,
                symbol=name,
                address=result.address if hasattr(result, 'address') else result,
                provider_library=provider_name,
                consumer_library=consumer_name,
                symbol_type=getattr(result, 'type', 'FUNC'),
                binding=getattr(result, 'binding', 'GLOBAL'),
            )

            self._events.append(event)
            self._stats.total_symbols_resolved += 1

            # Update library imports
            if consumer_name in self._library_events:
                self._library_events[consumer_name].imports[name] = provider_name

            # Fire callbacks
            for callback in self._on_symbol_resolve_callbacks:
                try:
                    callback(event)
                except Exception as e:
                    logger.warning(f"Callback error: {e}")
        else:
            # Symbol unresolved
            event = SymbolUnresolvedEvent(
                timestamp=time.time(),
                event_type=LoadingEventType.SYMBOL_UNRESOLVED,
                symbol=name,
                consumer_library=consumer_name,
            )

            self._events.append(event)
            self._stats.total_symbols_unresolved += 1

            # Fire callbacks
            for callback in self._on_symbol_unresolved_callbacks:
                try:
                    callback(event)
                except Exception as e:
                    logger.warning(f"Callback error: {e}")

        return result

    def _handle_linker_library_load(self, lib) -> None:
        """Handle library load from dynamic linker."""
        # This is called by the linker's callback system
        pass

    def _handle_linker_symbol_resolve(self, name: str, address: int) -> None:
        """Handle symbol resolution from dynamic linker."""
        pass

    # ==================== Helper Methods ====================

    def _get_dependencies(self, module) -> list[str]:
        """Extract dependencies from a module."""
        deps = []
        if hasattr(module, 'needed'):
            deps = list(module.needed)
        return deps

    def _get_exports(self, module) -> dict[str, int]:
        """Extract exports from a module."""
        exports = {}
        if hasattr(module, 'symbols'):
            for name, sym in module.symbols.items():
                if hasattr(sym, 'is_exported') and sym.is_exported:
                    exports[name] = sym.address
                elif hasattr(sym, 'address') and sym.address:
                    exports[name] = sym.address
        elif hasattr(module, 'exported_symbols'):
            exports = dict(module.exported_symbols)
        return exports

    # ==================== Callback Decorators ====================

    def on_library_load(self, callback: Callable[[LibraryLoadEvent], None]):
        """Decorator to register library load callback."""
        self._on_library_load_callbacks.append(callback)
        return callback

    def on_symbol_resolve(self, callback: Callable[[SymbolResolveEvent], None]):
        """Decorator to register symbol resolve callback."""
        self._on_symbol_resolve_callbacks.append(callback)
        return callback

    def on_symbol_unresolved(self, callback: Callable[[SymbolUnresolvedEvent], None]):
        """Decorator to register unresolved symbol callback."""
        self._on_symbol_unresolved_callbacks.append(callback)
        return callback

    def on_dependency_resolve(self, callback: Callable[[DependencyResolveEvent], None]):
        """Decorator to register dependency resolve callback."""
        self._on_dependency_resolve_callbacks.append(callback)
        return callback

    def on_memory_map(self, callback: Callable[[MemoryMapEvent], None]):
        """Decorator to register memory map callback."""
        self._on_memory_map_callbacks.append(callback)
        return callback

    def on_relocation(self, callback: Callable[[RelocationEvent], None]):
        """Decorator to register relocation callback."""
        self._on_relocation_callbacks.append(callback)
        return callback

    def on_init_function(self, callback: Callable[[InitFunctionEvent], None]):
        """Decorator to register init function callback."""
        self._on_init_function_callbacks.append(callback)
        return callback

    # ==================== Manual Event Recording ====================

    def record_memory_map(
        self,
        library: str,
        address: int,
        size: int,
        protection: str,
        segment_type: str = "LOAD",
    ) -> None:
        """Manually record a memory mapping event."""
        event = MemoryMapEvent(
            timestamp=time.time(),
            event_type=LoadingEventType.MEMORY_MAP,
            library=library,
            address=address,
            size=size,
            protection=protection,
            segment_type=segment_type,
        )
        self._events.append(event)
        self._stats.total_memory_mapped += size

        for callback in self._on_memory_map_callbacks:
            callback(event)

    def record_relocation(
        self,
        library: str,
        target_address: int,
        relocation_type: str,
        symbol: str | None = None,
        value_written: int = 0,
    ) -> None:
        """Manually record a relocation event."""
        event = RelocationEvent(
            timestamp=time.time(),
            event_type=LoadingEventType.RELOCATION_APPLY,
            library=library,
            target_address=target_address,
            relocation_type=relocation_type,
            symbol=symbol,
            value_written=value_written,
        )
        self._events.append(event)
        self._stats.total_relocations += 1

        for callback in self._on_relocation_callbacks:
            callback(event)

    def record_init_function(
        self,
        library: str,
        function_address: int,
        function_index: int,
        is_jni_onload: bool = False,
        return_value: int | None = None,
        duration_ms: float = 0.0,
    ) -> None:
        """Manually record an init function call event."""
        event = InitFunctionEvent(
            timestamp=time.time(),
            event_type=LoadingEventType.INIT_FUNCTION_CALL if not is_jni_onload else LoadingEventType.JNI_ONLOAD_CALL,
            library=library,
            function_address=function_address,
            function_index=function_index,
            is_jni_onload=is_jni_onload,
            return_value=return_value,
            duration_ms=duration_ms,
        )
        self._events.append(event)
        self._stats.total_init_functions += 1
        if is_jni_onload:
            self._stats.total_jni_onload += 1

        for callback in self._on_init_function_callbacks:
            callback(event)

    # ==================== Analysis Methods ====================

    def get_dependency_tree(self, root_library: str | None = None) -> DependencyNode:
        """
        Build dependency tree starting from root library.
        
        Args:
            root_library: Starting library (or first loaded if None)
            
        Returns:
            DependencyNode tree
        """
        if not self._library_events:
            return DependencyNode(name="(empty)", path="", base_address=0)

        # Find root
        if root_library:
            root_event = self._library_events.get(root_library)
        else:
            # Use first loaded library
            root_event = min(
                self._library_events.values(),
                key=lambda e: e.load_order
            )

        if not root_event:
            return DependencyNode(name="(not found)", path="", base_address=0)

        # Build tree recursively
        visited = set()

        def build_node(lib_name: str) -> DependencyNode:
            if lib_name in visited:
                return DependencyNode(
                    name=f"{lib_name} (circular)",
                    path="",
                    base_address=0,
                )

            visited.add(lib_name)

            event = self._library_events.get(lib_name)
            if not event:
                return DependencyNode(
                    name=lib_name,
                    path="(not loaded)",
                    base_address=0,
                )

            node = DependencyNode(
                name=event.name,
                path=event.path,
                base_address=event.base_address,
            )

            # Add children (dependencies)
            for dep in event.dependencies:
                dep_stem = Path(dep).stem
                child = build_node(dep_stem)
                node.children.append(child)

            # Find which exports are used by other libraries
            for other_event in self._library_events.values():
                for sym, provider in other_event.imports.items():
                    if provider == lib_name:
                        if sym not in node.exports_used:
                            node.exports_used.append(sym)

            return node

        return build_node(root_event.name)

    def get_symbol_origins(self) -> dict[str, str]:
        """
        Get mapping of symbols to their providing libraries.
        
        Returns:
            Dict mapping symbol name to library name
        """
        return dict(self._symbol_origins)

    def get_library_exports(self, library: str) -> dict[str, int]:
        """Get all exports from a library."""
        event = self._library_events.get(library)
        if event:
            return dict(event.exports)
        return {}

    def get_library_imports(self, library: str) -> dict[str, str]:
        """Get all imports for a library (symbol -> provider)."""
        event = self._library_events.get(library)
        if event:
            return dict(event.imports)
        return {}

    def get_unresolved_symbols(self) -> list[tuple[str, str]]:
        """Get list of unresolved symbols with their consumers."""
        unresolved = []
        for event in self._events:
            if isinstance(event, SymbolUnresolvedEvent):
                unresolved.append((event.symbol, event.consumer_library))
        return unresolved

    def get_load_order(self) -> list[str]:
        """Get libraries in load order."""
        events = sorted(
            self._library_events.values(),
            key=lambda e: e.load_order
        )
        return [e.name for e in events]

    def get_memory_layout(self) -> list[dict]:
        """Get memory layout of all loaded libraries."""
        layout = []
        for event in self._library_events.values():
            layout.append({
                "name": event.name,
                "base": event.base_address,
                "end": event.base_address + event.size,
                "size": event.size,
            })

        return sorted(layout, key=lambda x: x["base"])

    def get_stats(self) -> LoadingStats:
        """Get loading statistics."""
        if self._start_time:
            self._stats.load_time_ms = (time.time() - self._start_time) * 1000
        return self._stats

    # ==================== Export Methods ====================

    def export_report(self, path: str | None = None, format: str = "json") -> str:
        """
        Export loading report.
        
        Args:
            path: Output file path (or None for string return)
            format: Output format ("json" or "text")
            
        Returns:
            Report string if path is None
        """
        if format == "json":
            report = self._generate_json_report()
        else:
            report = self._generate_text_report()

        if path:
            with open(path, 'w') as f:
                f.write(report)
            logger.info(f"Report exported to {path}")

        return report

    def export_html_report(self, path: str) -> None:
        """Export interactive HTML report."""
        html = self._generate_html_report()
        with open(path, 'w') as f:
            f.write(html)
        logger.info(f"HTML report exported to {path}")

    def _generate_json_report(self) -> str:
        """Generate JSON report."""
        report = {
            "generated_at": datetime.now().isoformat(),
            "summary": self.get_stats().to_dict(),
            "load_order": self.get_load_order(),
            "memory_layout": self.get_memory_layout(),
            "dependency_tree": self.get_dependency_tree().to_dict(),
            "unresolved_symbols": [
                {"symbol": s, "consumer": c}
                for s, c in self.get_unresolved_symbols()
            ],
            "libraries": {
                name: event.to_dict()
                for name, event in self._library_events.items()
            },
            "events": [e.to_dict() for e in self._events[-1000:]],  # Last 1000 events
        }

        return json.dumps(report, indent=2)

    def _generate_text_report(self) -> str:
        """Generate text report."""
        lines = [
            "=" * 60,
            "PyUniDbg Loading Report",
            "=" * 60,
            "",
            "## Summary",
            f"  Libraries loaded:      {self._stats.total_libraries}",
            f"  Symbols resolved:      {self._stats.total_symbols_resolved}",
            f"  Symbols unresolved:    {self._stats.total_symbols_unresolved}",
            f"  Total memory mapped:   {self._stats.total_memory_mapped:,} bytes",
            f"  Init functions called: {self._stats.total_init_functions}",
            f"  Load time:             {self._stats.load_time_ms:.2f} ms",
            "",
            "## Load Order",
        ]

        for i, name in enumerate(self.get_load_order()):
            event = self._library_events[name]
            lines.append(
                f"  {i+1}. {name} @ {event.base_address:#x} "
                f"({len(event.exports)} exports)"
            )

        lines.extend([
            "",
            "## Memory Layout",
        ])

        for entry in self.get_memory_layout():
            lines.append(
                f"  {entry['base']:#010x} - {entry['end']:#010x}  "
                f"({entry['size']:>8,} bytes)  {entry['name']}"
            )

        lines.extend([
            "",
            "## Dependency Tree",
            self.get_dependency_tree().to_ascii(),
        ])

        unresolved = self.get_unresolved_symbols()
        if unresolved:
            lines.extend([
                "",
                "## Unresolved Symbols",
            ])
            for sym, consumer in unresolved[:20]:  # Limit to 20
                lines.append(f"  {sym} (needed by {consumer})")
            if len(unresolved) > 20:
                lines.append(f"  ... and {len(unresolved) - 20} more")

        return "\n".join(lines)

    def _generate_html_report(self) -> str:
        """Generate interactive HTML report."""
        stats = self.get_stats()
        tree = self.get_dependency_tree()

        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PyUniDbg Loading Report</title>
    <style>
        :root {{
            --bg-primary: #1e1e1e;
            --bg-secondary: #252526;
            --bg-tertiary: #2d2d30;
            --text-primary: #d4d4d4;
            --text-secondary: #858585;
            --accent: #0e639c;
            --accent-hover: #1177bb;
            --success: #4ec9b0;
            --warning: #ce9178;
            --error: #f14c4c;
        }}
        
        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }}
        
        body {{
            font-family: 'Segoe UI', system-ui, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            line-height: 1.6;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
        }}
        
        h1 {{
            color: var(--success);
            margin-bottom: 0.5rem;
        }}
        
        h2 {{
            color: var(--text-primary);
            border-bottom: 1px solid var(--bg-tertiary);
            padding-bottom: 0.5rem;
            margin: 2rem 0 1rem 0;
        }}
        
        .subtitle {{
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }}
        
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }}
        
        .stat-card {{
            background: var(--bg-secondary);
            border-radius: 8px;
            padding: 1rem;
            text-align: center;
        }}
        
        .stat-value {{
            font-size: 2rem;
            font-weight: bold;
            color: var(--success);
        }}
        
        .stat-label {{
            color: var(--text-secondary);
            font-size: 0.9rem;
        }}
        
        table {{
            width: 100%;
            border-collapse: collapse;
            background: var(--bg-secondary);
            border-radius: 8px;
            overflow: hidden;
        }}
        
        th, td {{
            padding: 0.75rem 1rem;
            text-align: left;
            border-bottom: 1px solid var(--bg-tertiary);
        }}
        
        th {{
            background: var(--bg-tertiary);
            font-weight: 600;
        }}
        
        tr:hover {{
            background: var(--bg-tertiary);
        }}
        
        .address {{
            font-family: monospace;
            color: var(--warning);
        }}
        
        .tree {{
            background: var(--bg-secondary);
            padding: 1rem;
            border-radius: 8px;
            font-family: monospace;
            white-space: pre;
            overflow-x: auto;
        }}
        
        .collapsible {{
            cursor: pointer;
            padding: 1rem;
            background: var(--bg-secondary);
            border: none;
            text-align: left;
            outline: none;
            font-size: 1rem;
            color: var(--text-primary);
            border-radius: 8px;
            margin-bottom: 0.5rem;
            width: 100%;
        }}
        
        .collapsible:hover {{
            background: var(--bg-tertiary);
        }}
        
        .collapsible:after {{
            content: '\\25BC';
            float: right;
            color: var(--text-secondary);
        }}
        
        .active:after {{
            content: '\\25B2';
        }}
        
        .content {{
            display: none;
            overflow: hidden;
            background: var(--bg-secondary);
            border-radius: 8px;
            margin-bottom: 1rem;
        }}
        
        .badge {{
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.8rem;
            font-weight: 500;
        }}
        
        .badge-success {{
            background: rgba(78, 201, 176, 0.2);
            color: var(--success);
        }}
        
        .badge-warning {{
            background: rgba(206, 145, 120, 0.2);
            color: var(--warning);
        }}
        
        .badge-error {{
            background: rgba(241, 76, 76, 0.2);
            color: var(--error);
        }}
        
        .search-box {{
            padding: 0.75rem 1rem;
            background: var(--bg-secondary);
            border: 1px solid var(--bg-tertiary);
            border-radius: 8px;
            color: var(--text-primary);
            width: 100%;
            margin-bottom: 1rem;
        }}
        
        .search-box:focus {{
            outline: none;
            border-color: var(--accent);
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 PyUniDbg Loading Report</h1>
        <p class="subtitle">Generated at {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
        
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value">{stats.total_libraries}</div>
                <div class="stat-label">Libraries Loaded</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{stats.total_symbols_resolved}</div>
                <div class="stat-label">Symbols Resolved</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{stats.total_symbols_unresolved}</div>
                <div class="stat-label">Unresolved</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{stats.total_memory_mapped // 1024}KB</div>
                <div class="stat-label">Memory Mapped</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{stats.load_time_ms:.1f}ms</div>
                <div class="stat-label">Load Time</div>
            </div>
        </div>
        
        <h2>📚 Loaded Libraries</h2>
        <table id="libraryTable">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Base Address</th>
                    <th>Size</th>
                    <th>Exports</th>
                    <th>Dependencies</th>
                </tr>
            </thead>
            <tbody>
                {''.join(self._generate_library_rows())}
            </tbody>
        </table>
        
        <h2>🌳 Dependency Tree</h2>
        <div class="tree">{tree.to_ascii()}</div>
        
        <h2>🗺️ Memory Layout</h2>
        <table>
            <thead>
                <tr>
                    <th>Library</th>
                    <th>Start</th>
                    <th>End</th>
                    <th>Size</th>
                </tr>
            </thead>
            <tbody>
                {''.join(self._generate_memory_rows())}
            </tbody>
        </table>
        
        {self._generate_unresolved_section()}
        
        <h2>📋 Event Log (Last 50)</h2>
        <button class="collapsible">Show Events</button>
        <div class="content">
            <table>
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Event</th>
                        <th>Details</th>
                    </tr>
                </thead>
                <tbody>
                    {''.join(self._generate_event_rows())}
                </tbody>
            </table>
        </div>
    </div>
    
    <script>
        // Collapsible sections
        var coll = document.getElementsByClassName("collapsible");
        for (var i = 0; i < coll.length; i++) {{
            coll[i].addEventListener("click", function() {{
                this.classList.toggle("active");
                var content = this.nextElementSibling;
                if (content.style.display === "block") {{
                    content.style.display = "none";
                }} else {{
                    content.style.display = "block";
                }}
            }});
        }}
    </script>
</body>
</html>'''

        return html

    def _generate_library_rows(self) -> list[str]:
        """Generate HTML table rows for libraries."""
        rows = []
        for i, name in enumerate(self.get_load_order()):
            event = self._library_events[name]
            rows.append(f'''
                <tr>
                    <td>{i + 1}</td>
                    <td><strong>{name}</strong></td>
                    <td class="address">{event.base_address:#x}</td>
                    <td>{event.size:,} bytes</td>
                    <td><span class="badge badge-success">{len(event.exports)}</span></td>
                    <td>{len(event.dependencies)}</td>
                </tr>
            ''')
        return rows

    def _generate_memory_rows(self) -> list[str]:
        """Generate HTML table rows for memory layout."""
        rows = []
        for entry in self.get_memory_layout():
            rows.append(f'''
                <tr>
                    <td>{entry['name']}</td>
                    <td class="address">{entry['base']:#x}</td>
                    <td class="address">{entry['end']:#x}</td>
                    <td>{entry['size']:,} bytes</td>
                </tr>
            ''')
        return rows

    def _generate_unresolved_section(self) -> str:
        """Generate HTML section for unresolved symbols."""
        unresolved = self.get_unresolved_symbols()
        if not unresolved:
            return ""

        rows = []
        for sym, consumer in unresolved[:50]:
            rows.append(f'''
                <tr>
                    <td><code>{sym}</code></td>
                    <td>{consumer}</td>
                </tr>
            ''')

        return f'''
        <h2>⚠️ Unresolved Symbols ({len(unresolved)})</h2>
        <table>
            <thead>
                <tr>
                    <th>Symbol</th>
                    <th>Needed By</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>
        '''

    def _generate_event_rows(self) -> list[str]:
        """Generate HTML table rows for events."""
        rows = []
        for event in self._events[-50:]:  # Last 50
            event_dict = event.to_dict()
            details = ", ".join(
                f"{k}: {v}" for k, v in event_dict.items()
                if k not in ('timestamp', 'event_type')
            )[:100]

            rows.append(f'''
                <tr>
                    <td>{event.timestamp:.3f}</td>
                    <td>{event.event_type.name}</td>
                    <td>{details}</td>
                </tr>
            ''')
        return rows

    # ==================== Control Methods ====================

    def enable(self) -> None:
        """Enable the inspector."""
        self._enabled = True

    def disable(self) -> None:
        """Disable the inspector."""
        self._enabled = False

    def clear(self) -> None:
        """Clear all recorded events."""
        self._events.clear()
        self._library_events.clear()
        self._symbol_origins.clear()
        self._load_order = 0
        self._start_time = 0
        self._stats = LoadingStats()

    def __repr__(self) -> str:
        return (
            f"LoadingInspector("
            f"libraries={self._stats.total_libraries}, "
            f"symbols={self._stats.total_symbols_resolved}, "
            f"events={len(self._events)})"
        )


# ==================== Convenience Functions ====================

def create_loading_inspector(emulator: Emulator) -> LoadingInspector:
    """Create and attach a LoadingInspector to an emulator."""
    return LoadingInspector(emulator)
