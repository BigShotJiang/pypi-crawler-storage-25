"""
Disassembler - Multi-format instruction disassembly.

Provides disassembly using Capstone with multiple output formats:
- Assembly (AT&T/Intel syntax)
- Hex dump
- Pseudo-C translation
- JSON for tooling
"""

import logging
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)

# Try to import Capstone
try:
    from capstone import (
        CS_ARCH_ARM,
        CS_ARCH_ARM64,
        CS_MODE_ARM,
        CS_MODE_LITTLE_ENDIAN,
        CS_MODE_THUMB,
        CS_OPT_DETAIL,
        Cs,
        CsInsn,
    )
    from capstone.arm64_const import *
    from capstone.arm_const import *
    HAS_CAPSTONE = True
except ImportError:
    HAS_CAPSTONE = False
    logger.warning("Capstone not installed. Disassembly will be limited.")


class DisasmStyle(Enum):
    """Disassembly output style."""
    ASSEMBLY = auto()     # Standard assembly
    INTEL = auto()        # Intel syntax (x86-style)
    PSEUDO_C = auto()     # Pseudo-C translation
    HEX_DUMP = auto()     # Raw hex with annotations
    JSON = auto()         # Structured JSON
    COMPACT = auto()      # One-line compact format


@dataclass
class DisasmOutput:
    """Disassembled instruction output."""
    address: int
    size: int
    bytes: bytes
    mnemonic: str
    operands: str

    # Detailed info (if available)
    reads: list[str] = field(default_factory=list)     # Registers/memory read
    writes: list[str] = field(default_factory=list)    # Registers/memory written
    groups: list[str] = field(default_factory=list)    # Instruction groups

    # Translations
    pseudo_c: str = ""
    comment: str = ""

    def to_assembly(self) -> str:
        """Format as assembly."""
        return f"0x{self.address:08x}:  {self.mnemonic:8} {self.operands}"

    def to_hex_dump(self) -> str:
        """Format as hex dump."""
        hex_bytes = ' '.join(f'{b:02x}' for b in self.bytes)
        return f"0x{self.address:08x}:  {hex_bytes:24} {self.mnemonic} {self.operands}"

    def to_pseudo_c(self) -> str:
        """Format as pseudo-C."""
        if self.pseudo_c:
            return f"/* 0x{self.address:08x} */ {self.pseudo_c}"
        return f"/* 0x{self.address:08x} */ {self.mnemonic}({self.operands})"

    def to_compact(self) -> str:
        """Format as compact one-liner."""
        return f"{self.address:x}: {self.mnemonic} {self.operands}"

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            'address': self.address,
            'size': self.size,
            'bytes': self.bytes.hex(),
            'mnemonic': self.mnemonic,
            'operands': self.operands,
            'reads': self.reads,
            'writes': self.writes,
            'groups': self.groups,
            'pseudo_c': self.pseudo_c,
            'comment': self.comment,
        }


class PseudoCTranslator:
    """Translates ARM/ARM64 instructions to pseudo-C."""

    # ARM64 instruction patterns to pseudo-C
    ARM64_PATTERNS = {
        # Data movement
        'mov': lambda ops: f"{ops[0]} = {ops[1]}",
        'movz': lambda ops: f"{ops[0]} = {ops[1]}",
        'movk': lambda ops: f"{ops[0]} |= {ops[1]}",
        'movn': lambda ops: f"{ops[0]} = ~{ops[1]}",

        # Arithmetic
        'add': lambda ops: f"{ops[0]} = {ops[1]} + {ops[2]}" if len(ops) > 2 else f"{ops[0]} += {ops[1]}",
        'sub': lambda ops: f"{ops[0]} = {ops[1]} - {ops[2]}" if len(ops) > 2 else f"{ops[0]} -= {ops[1]}",
        'mul': lambda ops: f"{ops[0]} = {ops[1]} * {ops[2]}",
        'sdiv': lambda ops: f"{ops[0]} = (signed){ops[1]} / {ops[2]}",
        'udiv': lambda ops: f"{ops[0]} = {ops[1]} / {ops[2]}",
        'neg': lambda ops: f"{ops[0]} = -{ops[1]}",
        'madd': lambda ops: f"{ops[0]} = {ops[1]} * {ops[2]} + {ops[3]}",
        'msub': lambda ops: f"{ops[0]} = {ops[1]} * {ops[2]} - {ops[3]}",

        # Logical
        'and': lambda ops: f"{ops[0]} = {ops[1]} & {ops[2]}",
        'orr': lambda ops: f"{ops[0]} = {ops[1]} | {ops[2]}",
        'eor': lambda ops: f"{ops[0]} = {ops[1]} ^ {ops[2]}",
        'bic': lambda ops: f"{ops[0]} = {ops[1]} & ~{ops[2]}",
        'mvn': lambda ops: f"{ops[0]} = ~{ops[1]}",

        # Shifts
        'lsl': lambda ops: f"{ops[0]} = {ops[1]} << {ops[2]}",
        'lsr': lambda ops: f"{ops[0]} = {ops[1]} >> {ops[2]}",
        'asr': lambda ops: f"{ops[0]} = (signed){ops[1]} >> {ops[2]}",
        'ror': lambda ops: f"{ops[0]} = rotate_right({ops[1]}, {ops[2]})",

        # Memory
        'ldr': lambda ops: f"{ops[0]} = *({ops[1]})" if len(ops) == 2 else f"{ops[0]} = *(uint64_t*)({ops[1]})",
        'ldur': lambda ops: f"{ops[0]} = *({ops[1]})",
        'ldrb': lambda ops: f"{ops[0]} = *(uint8_t*)({ops[1]})",
        'ldrh': lambda ops: f"{ops[0]} = *(uint16_t*)({ops[1]})",
        'ldrsw': lambda ops: f"{ops[0]} = *(int32_t*)({ops[1]})",
        'ldrsb': lambda ops: f"{ops[0]} = *(int8_t*)({ops[1]})",
        'ldrsh': lambda ops: f"{ops[0]} = *(int16_t*)({ops[1]})",
        'ldp': lambda ops: f"{ops[0]}, {ops[1]} = *({ops[2]})",

        'str': lambda ops: f"*({ops[1]}) = {ops[0]}",
        'stur': lambda ops: f"*({ops[1]}) = {ops[0]}",
        'strb': lambda ops: f"*(uint8_t*)({ops[1]}) = {ops[0]}",
        'strh': lambda ops: f"*(uint16_t*)({ops[1]}) = {ops[0]}",
        'stp': lambda ops: f"*({ops[2]}) = {{{ops[0]}, {ops[1]}}}",

        # Compare
        'cmp': lambda ops: f"flags = compare({ops[0]}, {ops[1]})",
        'cmn': lambda ops: f"flags = compare({ops[0]}, -{ops[1]})",
        'tst': lambda ops: f"flags = test({ops[0]} & {ops[1]})",

        # Branches
        'b': lambda ops: f"goto {ops[0]}",
        'bl': lambda ops: f"call {ops[0]}",
        'blr': lambda ops: f"call *{ops[0]}",
        'br': lambda ops: f"goto *{ops[0]}",
        'ret': lambda ops: "return",
        'b.eq': lambda ops: f"if (eq) goto {ops[0]}",
        'b.ne': lambda ops: f"if (ne) goto {ops[0]}",
        'b.lt': lambda ops: f"if (lt) goto {ops[0]}",
        'b.le': lambda ops: f"if (le) goto {ops[0]}",
        'b.gt': lambda ops: f"if (gt) goto {ops[0]}",
        'b.ge': lambda ops: f"if (ge) goto {ops[0]}",
        'b.hi': lambda ops: f"if (hi) goto {ops[0]}",
        'b.lo': lambda ops: f"if (lo) goto {ops[0]}",
        'b.hs': lambda ops: f"if (hs) goto {ops[0]}",
        'b.ls': lambda ops: f"if (ls) goto {ops[0]}",
        'cbz': lambda ops: f"if ({ops[0]} == 0) goto {ops[1]}",
        'cbnz': lambda ops: f"if ({ops[0]} != 0) goto {ops[1]}",
        'tbz': lambda ops: f"if (!bit({ops[0]}, {ops[1]})) goto {ops[2]}",
        'tbnz': lambda ops: f"if (bit({ops[0]}, {ops[1]})) goto {ops[2]}",

        # Conditional select
        'csel': lambda ops: f"{ops[0]} = cond ? {ops[1]} : {ops[2]}",
        'cset': lambda ops: f"{ops[0]} = cond ? 1 : 0",
        'csinc': lambda ops: f"{ops[0]} = cond ? {ops[1]} : {ops[2]} + 1",
        'csinv': lambda ops: f"{ops[0]} = cond ? {ops[1]} : ~{ops[2]}",
        'csneg': lambda ops: f"{ops[0]} = cond ? {ops[1]} : -{ops[2]}",

        # Address
        'adr': lambda ops: f"{ops[0]} = &{ops[1]}",
        'adrp': lambda ops: f"{ops[0]} = page_of(&{ops[1]})",

        # Extensions
        'sxtw': lambda ops: f"{ops[0]} = (int64_t)(int32_t){ops[1]}",
        'sxth': lambda ops: f"{ops[0]} = (int64_t)(int16_t){ops[1]}",
        'sxtb': lambda ops: f"{ops[0]} = (int64_t)(int8_t){ops[1]}",
        'uxtw': lambda ops: f"{ops[0]} = (uint64_t)(uint32_t){ops[1]}",
        'uxth': lambda ops: f"{ops[0]} = (uint64_t)(uint16_t){ops[1]}",
        'uxtb': lambda ops: f"{ops[0]} = (uint64_t)(uint8_t){ops[1]}",

        # System
        'svc': lambda ops: f"syscall({ops[0]})",
        'brk': lambda ops: f"breakpoint({ops[0]})",
        'nop': lambda ops: "/* nop */",
        'mrs': lambda ops: f"{ops[0]} = read_system_reg({ops[1]})",
        'msr': lambda ops: f"write_system_reg({ops[0]}, {ops[1]})",
    }

    # ARM32 patterns
    ARM32_PATTERNS = {
        'mov': lambda ops: f"{ops[0]} = {ops[1]}",
        'add': lambda ops: f"{ops[0]} = {ops[1]} + {ops[2]}" if len(ops) > 2 else f"{ops[0]} += {ops[1]}",
        'sub': lambda ops: f"{ops[0]} = {ops[1]} - {ops[2]}" if len(ops) > 2 else f"{ops[0]} -= {ops[1]}",
        'mul': lambda ops: f"{ops[0]} = {ops[1]} * {ops[2]}",
        'and': lambda ops: f"{ops[0]} = {ops[1]} & {ops[2]}",
        'orr': lambda ops: f"{ops[0]} = {ops[1]} | {ops[2]}",
        'eor': lambda ops: f"{ops[0]} = {ops[1]} ^ {ops[2]}",
        'ldr': lambda ops: f"{ops[0]} = *({ops[1]})",
        'str': lambda ops: f"*({ops[1]}) = {ops[0]}",
        'ldrb': lambda ops: f"{ops[0]} = *(uint8_t*)({ops[1]})",
        'strb': lambda ops: f"*(uint8_t*)({ops[1]}) = {ops[0]}",
        'push': lambda ops: f"push({ops[0]})",
        'pop': lambda ops: f"pop({ops[0]})",
        'bl': lambda ops: f"call {ops[0]}",
        'bx': lambda ops: f"goto *{ops[0]}" if ops[0] != 'lr' else "return",
        'b': lambda ops: f"goto {ops[0]}",
        'cmp': lambda ops: f"flags = compare({ops[0]}, {ops[1]})",
        'beq': lambda ops: f"if (eq) goto {ops[0]}",
        'bne': lambda ops: f"if (ne) goto {ops[0]}",
        'blt': lambda ops: f"if (lt) goto {ops[0]}",
        'ble': lambda ops: f"if (le) goto {ops[0]}",
        'bgt': lambda ops: f"if (gt) goto {ops[0]}",
        'bge': lambda ops: f"if (ge) goto {ops[0]}",
        'svc': lambda ops: f"syscall({ops[0]})",
    }

    def __init__(self, is_arm64: bool = True):
        self.is_arm64 = is_arm64
        self.patterns = self.ARM64_PATTERNS if is_arm64 else self.ARM32_PATTERNS

    def translate(self, mnemonic: str, operands: str) -> str:
        """Translate instruction to pseudo-C."""
        # Normalize mnemonic (remove condition codes for ARM32)
        base_mnemonic = mnemonic.lower().rstrip('s')

        # Parse operands
        ops = [op.strip() for op in operands.split(',') if op.strip()]

        # Look up pattern
        if base_mnemonic in self.patterns:
            try:
                return self.patterns[base_mnemonic](ops)
            except (IndexError, KeyError):
                pass

        # Check for conditional branches
        if base_mnemonic.startswith('b.'):
            cond = base_mnemonic[2:]
            return f"if ({cond}) goto {ops[0]}" if ops else f"branch_{cond}"

        # Default fallback
        return f"{mnemonic}({operands})"


class Disassembler:
    """
    Multi-format disassembler.
    
    Provides disassembly with multiple output formats:
    - Assembly (standard disassembly)
    - Hex dump (bytes + disassembly)
    - Pseudo-C (C-like translation)
    - JSON (structured data)
    
    Example:
        disasm = Disassembler(emulator)
        
        # Disassemble single instruction
        output = disasm.disasm_at(0x1000)
        print(output.to_assembly())
        print(output.to_pseudo_c())
        
        # Disassemble range
        for insn in disasm.disasm_range(0x1000, 0x1100):
            print(insn.to_hex_dump())
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator

        # Set up Capstone
        self._cs: Cs | None = None
        self._setup_capstone()

        # Pseudo-C translator
        self._translator = PseudoCTranslator(emulator.is_64bit)

        # Symbol table for better output
        self._symbols: dict[int, str] = {}

        # Comments added by user
        self._comments: dict[int, str] = {}

    def _setup_capstone(self) -> None:
        """Initialize Capstone disassembler."""
        if not HAS_CAPSTONE:
            return

        if self.emulator.is_64bit:
            self._cs = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
        else:
            # Check for Thumb mode
            self._cs = Cs(CS_ARCH_ARM, CS_MODE_ARM | CS_MODE_LITTLE_ENDIAN)

        self._cs.detail = True

    def disasm_at(self, address: int, size: int = 4) -> DisasmOutput | None:
        """
        Disassemble instruction at address.

        Args:
            address: Instruction address
            size: Max bytes to read (default 4)

        Returns:
            DisasmOutput or None if invalid
        """
        # Always read at least 4 bytes so a full ARM/ARM64 instruction can be decoded.
        # UC_HOOK_CODE sometimes fires with size=0 on certain Unicorn builds.
        read_size = max(size, 4)

        # Cap to the available mapped region to avoid UcError at region boundaries.
        region = self.emulator.memory.find_region(address)
        if region is None:
            return None
        read_size = min(read_size, region.end - address)
        if read_size <= 0:
            return None

        try:
            code = self.emulator.memory.read(address, read_size)
        except Exception:
            return None

        return self.disasm_bytes(code, address)

    def disasm_bytes(self, code: bytes, address: int = 0) -> DisasmOutput | None:
        """
        Disassemble bytes.
        
        Args:
            code: Bytes to disassemble
            address: Base address for display
            
        Returns:
            DisasmOutput or None if invalid
        """
        if not HAS_CAPSTONE or not self._cs:
            # Fallback without Capstone
            return DisasmOutput(
                address=address,
                size=len(code),
                bytes=code,
                mnemonic="???",
                operands=code.hex(),
            )

        # Disassemble
        try:
            insns = list(self._cs.disasm(code, address, count=1))
            if not insns:
                return None

            insn = insns[0]

            # Guard mnemonic/op_str — some Capstone builds raise on edge-case instructions
            try:
                mnemonic = insn.mnemonic
                operands = insn.op_str
            except Exception:
                mnemonic = "???"
                operands = ""

            # Get detailed info — guard against Capstone detail access failures
            reads = []
            writes = []
            groups = []
            try:
                if insn.detail:
                    reads = [insn.reg_name(r) for r in insn.regs_read]
                    writes = [insn.reg_name(r) for r in insn.regs_write]
                    groups = [insn.group_name(g) for g in insn.groups]
            except Exception:
                pass  # detail metadata unavailable; mnemonic/operands are still valid

            # Generate pseudo-C
            pseudo_c = self._translator.translate(mnemonic, operands)

            # Add symbol references
            operands = self._add_symbol_refs(operands)

            # Get user comment
            comment = self._comments.get(address, "")

            return DisasmOutput(
                address=insn.address,
                size=insn.size,
                bytes=bytes(insn.bytes),
                mnemonic=mnemonic,
                operands=operands,
                reads=reads,
                writes=writes,
                groups=groups,
                pseudo_c=pseudo_c,
                comment=comment,
            )

        except Exception:
            return None

    def disasm_range(self, start: int, end: int) -> list[DisasmOutput]:
        """
        Disassemble address range.

        Reads the entire range in one memory operation then disassembles the
        buffer in a single Capstone pass — much faster than calling disasm_at()
        for every 4-byte instruction window.
        
        Args:
            start: Start address
            end: End address (exclusive)
            
        Returns:
            List of DisasmOutput
        """
        if start >= end:
            return []

        # Single bulk memory read
        size = end - start
        try:
            code = self.emulator.memory.read(start, size)
        except Exception:
            logger.debug("disasm_range: memory read failed at 0x%x+0x%x", start, size)
            return []

        if not HAS_CAPSTONE or not self._cs:
            return []

        results = []
        try:
            for insn in self._cs.disasm(code, start):
                reads: list = []
                writes: list = []
                groups: list = []
                try:
                    if insn.detail:
                        reads = [insn.reg_name(r) for r in insn.regs_read]
                        writes = [insn.reg_name(r) for r in insn.regs_write]
                        groups = [insn.group_name(g) for g in insn.groups]
                except Exception:
                    pass

                operands = self._add_symbol_refs(insn.op_str)
                pseudo_c = self._translator.translate(insn.mnemonic, insn.op_str)
                comment = self._comments.get(insn.address, "")

                results.append(DisasmOutput(
                    address=insn.address,
                    size=insn.size,
                    bytes=bytes(insn.bytes),
                    mnemonic=insn.mnemonic,
                    operands=operands,
                    reads=reads,
                    writes=writes,
                    groups=groups,
                    pseudo_c=pseudo_c,
                    comment=comment,
                ))
        except Exception as e:
            logger.debug("disasm_range error at 0x%x: %s", start, e)

        return results

    def disasm_count(self, address: int, count: int) -> list[DisasmOutput]:
        """
        Disassemble N instructions.
        
        Args:
            address: Start address
            count: Number of instructions
            
        Returns:
            List of DisasmOutput
        """
        results = []
        addr = address

        for _ in range(count):
            output = self.disasm_at(addr)
            if output:
                results.append(output)
                addr += output.size
            else:
                break

        return results

    def disasm_function(self, address: int, max_insns: int = 1000) -> list[DisasmOutput]:
        """
        Disassemble function (until RET or max instructions).
        
        Args:
            address: Function start address
            max_insns: Maximum instructions to disassemble
            
        Returns:
            List of DisasmOutput
        """
        results = []
        addr = address

        for _ in range(max_insns):
            output = self.disasm_at(addr)
            if not output:
                break

            results.append(output)
            addr += output.size

            # Check for return instruction
            if output.mnemonic in ('ret', 'bx') and 'lr' in output.operands:
                break

        return results

    # ==================== Formatting ====================

    def format(self, outputs: list[DisasmOutput], style: DisasmStyle = DisasmStyle.ASSEMBLY) -> str:
        """
        Format disassembly output.
        
        Args:
            outputs: List of DisasmOutput
            style: Output style
            
        Returns:
            Formatted string
        """
        lines = []

        for out in outputs:
            if style == DisasmStyle.ASSEMBLY:
                line = out.to_assembly()
            elif style == DisasmStyle.HEX_DUMP:
                line = out.to_hex_dump()
            elif style == DisasmStyle.PSEUDO_C:
                line = out.to_pseudo_c()
            elif style == DisasmStyle.COMPACT:
                line = out.to_compact()
            elif style == DisasmStyle.JSON:
                import json
                line = json.dumps(out.to_dict())
            else:
                line = out.to_assembly()

            # Add comment if present
            if out.comment and style != DisasmStyle.JSON:
                line += f"  ; {out.comment}"

            lines.append(line)

        return '\n'.join(lines)

    # ==================== Symbols & Comments ====================

    def add_symbol(self, address: int, name: str) -> None:
        """Add symbol for better disassembly output."""
        self._symbols[address] = name

    def add_symbols(self, symbols: dict[int, str]) -> None:
        """Add multiple symbols."""
        self._symbols.update(symbols)

    def add_comment(self, address: int, comment: str) -> None:
        """Add user comment to address."""
        self._comments[address] = comment

    def _add_symbol_refs(self, operands: str) -> str:
        """Replace addresses with symbol names in operands."""
        for addr, name in self._symbols.items():
            hex_addr = f"0x{addr:x}"
            if hex_addr in operands:
                operands = operands.replace(hex_addr, f"{name}")
        return operands

    # ==================== Thumb Mode (ARM32) ====================

    def set_thumb_mode(self, enabled: bool) -> None:
        """Switch ARM32 between ARM and Thumb mode."""
        if not HAS_CAPSTONE or self.emulator.is_64bit:
            return

        if enabled:
            self._cs = Cs(CS_ARCH_ARM, CS_MODE_THUMB | CS_MODE_LITTLE_ENDIAN)
        else:
            self._cs = Cs(CS_ARCH_ARM, CS_MODE_ARM | CS_MODE_LITTLE_ENDIAN)

        self._cs.detail = True
