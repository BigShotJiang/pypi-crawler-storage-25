"""
Call Graph Generator - Visualize execution flow and function relationships.

Provides dynamic call graph generation during emulation:
- Function call relationship mapping
- Interactive graph visualization
- Export to DOT, JSON, HTML, Mermaid
- Call frequency analysis
- Cycle detection

Usage:
    from pyunidbg.analysis import CallGraphGenerator
    
    # Create generator
    cg = CallGraphGenerator(emulator)
    
    # Start tracking
    cg.start()
    
    # Run emulation
    emu.call(entry_point)
    
    # Stop and get graph
    cg.stop()
    
    # Export
    cg.export_dot("callgraph.dot")
    cg.export_html("callgraph.html")
    cg.export_mermaid("callgraph.md")
    
    # Get statistics
    stats = cg.get_stats()
    print(f"Nodes: {stats.node_count}, Edges: {stats.edge_count}")
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
)

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator

__all__ = [
    "CallGraphGenerator",
    "CallNode",
    "CallEdge",
    "CallGraph",
    "GraphStats",
    "GraphLayout",
    "create_call_graph",
]

logger = logging.getLogger(__name__)


# ==================== Enums ====================

class GraphLayout(Enum):
    """Graph layout algorithms."""
    HIERARCHICAL = "hierarchical"
    FORCE_DIRECTED = "force"
    CIRCULAR = "circular"
    TREE = "tree"


class NodeType(Enum):
    """Types of graph nodes."""
    FUNCTION = "function"
    LIBRARY = "library"
    SYSCALL = "syscall"
    JNI = "jni"
    UNKNOWN = "unknown"


# ==================== Data Classes ====================

@dataclass
class CallNode:
    """A node in the call graph representing a function."""
    address: int
    name: str
    node_type: NodeType = NodeType.FUNCTION
    library: str | None = None
    call_count: int = 0
    total_time: float = 0.0
    size: int = 0
    is_exported: bool = False
    is_imported: bool = False

    # Metrics
    in_degree: int = 0   # Number of callers
    out_degree: int = 0  # Number of callees

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "name": self.name,
            "type": self.node_type.value,
            "library": self.library,
            "call_count": self.call_count,
            "total_time": self.total_time,
            "in_degree": self.in_degree,
            "out_degree": self.out_degree,
        }

    @property
    def id(self) -> str:
        return f"node_{self.address:x}"

    def __hash__(self):
        return hash(self.address)

    def __eq__(self, other):
        if isinstance(other, CallNode):
            return self.address == other.address
        return False


@dataclass
class CallEdge:
    """An edge in the call graph representing a call relationship."""
    caller: int
    callee: int
    count: int = 0
    total_time: float = 0.0
    call_sites: set[int] = field(default_factory=set)

    def to_dict(self) -> dict[str, Any]:
        return {
            "caller": hex(self.caller),
            "callee": hex(self.callee),
            "count": self.count,
            "total_time": self.total_time,
            "call_sites": [hex(s) for s in self.call_sites],
        }

    @property
    def id(self) -> str:
        return f"edge_{self.caller:x}_{self.callee:x}"

    def __hash__(self):
        return hash((self.caller, self.callee))

    def __eq__(self, other):
        if isinstance(other, CallEdge):
            return self.caller == other.caller and self.callee == other.callee
        return False


@dataclass
class GraphStats:
    """Statistics about the call graph."""
    node_count: int = 0
    edge_count: int = 0
    total_calls: int = 0
    max_depth: int = 0
    has_cycles: bool = False
    cycle_count: int = 0
    strongly_connected_components: int = 0
    entry_points: list[int] = field(default_factory=list)
    leaf_functions: list[int] = field(default_factory=list)
    most_called: list[tuple[str, int]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "node_count": self.node_count,
            "edge_count": self.edge_count,
            "total_calls": self.total_calls,
            "max_depth": self.max_depth,
            "has_cycles": self.has_cycles,
            "cycle_count": self.cycle_count,
            "entry_points": [hex(e) for e in self.entry_points],
            "leaf_functions": [hex(l) for l in self.leaf_functions],
            "most_called": self.most_called[:10],
        }


# ==================== Call Graph ====================

class CallGraph:
    """
    Represents a call graph with nodes and edges.
    
    Provides methods for:
    - Adding/removing nodes and edges
    - Graph traversal
    - Cycle detection
    - Path finding
    - Export to various formats
    """

    def __init__(self):
        self.nodes: dict[int, CallNode] = {}
        self.edges: dict[tuple[int, int], CallEdge] = {}
        self._adjacency: dict[int, set[int]] = defaultdict(set)  # Outgoing edges
        self._reverse_adjacency: dict[int, set[int]] = defaultdict(set)  # Incoming edges

    def add_node(
        self,
        address: int,
        name: str | None = None,
        node_type: NodeType = NodeType.FUNCTION,
        **kwargs
    ) -> CallNode:
        """Add or get a node."""
        if address in self.nodes:
            node = self.nodes[address]
            if name and node.name == f"sub_{address:x}":
                node.name = name
            return node

        node = CallNode(
            address=address,
            name=name or f"sub_{address:x}",
            node_type=node_type,
            **kwargs
        )
        self.nodes[address] = node
        return node

    def add_edge(
        self,
        caller: int,
        callee: int,
        call_site: int | None = None
    ) -> CallEdge:
        """Add or update an edge."""
        key = (caller, callee)

        if key in self.edges:
            edge = self.edges[key]
            edge.count += 1
            if call_site:
                edge.call_sites.add(call_site)
        else:
            edge = CallEdge(caller=caller, callee=callee, count=1)
            if call_site:
                edge.call_sites.add(call_site)
            self.edges[key] = edge
            self._adjacency[caller].add(callee)
            self._reverse_adjacency[callee].add(caller)

        # Update node degrees
        if caller in self.nodes:
            self.nodes[caller].out_degree = len(self._adjacency[caller])
        if callee in self.nodes:
            self.nodes[callee].in_degree = len(self._reverse_adjacency[callee])

        return edge

    def get_callers(self, address: int) -> list[int]:
        """Get all callers of a function."""
        return list(self._reverse_adjacency.get(address, set()))

    def get_callees(self, address: int) -> list[int]:
        """Get all functions called by a function."""
        return list(self._adjacency.get(address, set()))

    def get_entry_points(self) -> list[int]:
        """Get functions that are never called (entry points)."""
        return [
            addr for addr in self.nodes
            if not self._reverse_adjacency.get(addr)
        ]

    def get_leaf_functions(self) -> list[int]:
        """Get functions that don't call any other functions."""
        return [
            addr for addr in self.nodes
            if not self._adjacency.get(addr)
        ]

    def find_cycles(self) -> list[list[int]]:
        """Find all cycles in the graph using Tarjan's algorithm."""
        cycles = []
        visited = set()
        rec_stack = set()
        path = []

        def dfs(node: int):
            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            for neighbor in self._adjacency.get(node, set()):
                if neighbor not in visited:
                    dfs(neighbor)
                elif neighbor in rec_stack:
                    # Found a cycle
                    cycle_start = path.index(neighbor)
                    cycles.append(path[cycle_start:] + [neighbor])

            path.pop()
            rec_stack.remove(node)

        for node in self.nodes:
            if node not in visited:
                dfs(node)

        return cycles

    def find_path(self, start: int, end: int) -> list[int] | None:
        """Find a path between two nodes using BFS."""
        if start == end:
            return [start]

        visited = {start}
        queue = [(start, [start])]

        while queue:
            node, path = queue.pop(0)

            for neighbor in self._adjacency.get(node, set()):
                if neighbor == end:
                    return path + [end]
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append((neighbor, path + [neighbor]))

        return None

    def get_subgraph(self, root: int, max_depth: int = 5) -> CallGraph:
        """Extract a subgraph starting from a root node."""
        subgraph = CallGraph()
        visited = set()

        def dfs(node: int, depth: int):
            if depth > max_depth or node in visited:
                return
            visited.add(node)

            if node in self.nodes:
                subgraph.nodes[node] = self.nodes[node]

            for callee in self._adjacency.get(node, set()):
                key = (node, callee)
                if key in self.edges:
                    subgraph.edges[key] = self.edges[key]
                    subgraph._adjacency[node].add(callee)
                    subgraph._reverse_adjacency[callee].add(node)
                dfs(callee, depth + 1)

        dfs(root, 0)
        return subgraph

    def get_stats(self) -> GraphStats:
        """Calculate graph statistics."""
        cycles = self.find_cycles()

        # Calculate max depth
        max_depth = 0
        for entry in self.get_entry_points():
            depth = self._calculate_max_depth(entry, set())
            max_depth = max(max_depth, depth)

        # Most called functions
        most_called = sorted(
            [(self.nodes[addr].name, self.nodes[addr].call_count)
             for addr in self.nodes],
            key=lambda x: x[1],
            reverse=True
        )

        return GraphStats(
            node_count=len(self.nodes),
            edge_count=len(self.edges),
            total_calls=sum(e.count for e in self.edges.values()),
            max_depth=max_depth,
            has_cycles=len(cycles) > 0,
            cycle_count=len(cycles),
            entry_points=self.get_entry_points(),
            leaf_functions=self.get_leaf_functions(),
            most_called=most_called,
        )

    def _calculate_max_depth(self, node: int, visited: set[int]) -> int:
        """Calculate maximum depth from a node."""
        if node in visited:
            return 0
        visited.add(node)

        callees = self._adjacency.get(node, set())
        if not callees:
            return 1

        max_child_depth = 0
        for callee in callees:
            depth = self._calculate_max_depth(callee, visited)
            max_child_depth = max(max_child_depth, depth)

        return max_child_depth + 1

    def to_dict(self) -> dict[str, Any]:
        """Convert graph to dictionary."""
        return {
            "nodes": [node.to_dict() for node in self.nodes.values()],
            "edges": [edge.to_dict() for edge in self.edges.values()],
            "stats": self.get_stats().to_dict(),
        }


# ==================== Call Graph Generator ====================

class CallGraphGenerator:
    """
    Generate call graphs during emulation.
    
    Tracks function calls and builds a graph representation
    of the call relationships.
    """

    def __init__(self, emulator: Emulator):
        self._emulator = emulator
        self._graph = CallGraph()
        self._running = False
        self._call_stack: list[int] = []
        self._hooks = []

        # Options
        self._track_depth = True
        self._track_time = True
        self._include_syscalls = True
        self._include_imports = True

        # State
        self._current_function: int | None = None
        self._call_times: dict[int, float] = {}

    @property
    def graph(self) -> CallGraph:
        """Get the call graph."""
        return self._graph

    def start(self) -> None:
        """Start tracking function calls."""
        if self._running:
            return

        self._running = True
        self._setup_hooks()
        logger.info("Call graph tracking started")

    def stop(self) -> None:
        """Stop tracking function calls."""
        if not self._running:
            return

        self._running = False
        self._remove_hooks()
        logger.info(f"Call graph tracking stopped. "
                   f"Nodes: {len(self._graph.nodes)}, "
                   f"Edges: {len(self._graph.edges)}")

    def _setup_hooks(self) -> None:
        """Setup hooks for call tracking."""
        from unicorn import UC_HOOK_CODE

        # Hook all code execution to detect function entries/exits
        handle = self._emulator._uc.hook_add(
            UC_HOOK_CODE,
            self._on_code,
            user_data=self
        )
        self._hooks.append(handle)

    def _remove_hooks(self) -> None:
        """Remove tracking hooks."""
        for handle in self._hooks:
            try:
                self._emulator._uc.hook_del(handle)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        self._hooks.clear()

    def _on_code(self, uc, address: int, size: int, user_data) -> None:
        """Called on each instruction execution."""
        if not self._running:
            return

        # Detect function calls by checking for BL/BLX/BLR instructions
        # This is a simplified heuristic
        try:
            code = self._emulator.memory.read(address, size)

            if self._emulator.is_64bit:
                # ARM64: BL (0b100101) or BLR (0b1101011)
                if len(code) >= 4:
                    insn = int.from_bytes(code[:4], 'little')
                    is_call = (insn >> 26) == 0b100101  # BL
                    is_call = is_call or ((insn >> 21) & 0x7FF) == 0b11010110001  # BLR
            else:
                # ARM32: BL/BLX
                if len(code) >= 4:
                    insn = int.from_bytes(code[:4], 'little')
                    is_call = (insn >> 24) == 0xEB  # BL
                    is_call = is_call or (insn >> 24) == 0xFA  # BLX

            if is_call:
                # Get target from next PC (LR will be set)
                self._on_call(address)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

    def _on_call(self, call_site: int) -> None:
        """Called when a function call is detected."""
        import time

        caller = self._call_stack[-1] if self._call_stack else 0

        # Get target address (this is approximate)
        callee = self._emulator.cpu.pc + 4  # Next instruction after call

        # Add nodes
        if caller:
            self._graph.add_node(caller, library=self._find_library(caller))
        callee_node = self._graph.add_node(callee, library=self._find_library(callee))
        callee_node.call_count += 1

        # Add edge
        if caller:
            self._graph.add_edge(caller, callee, call_site)

        # Update call stack
        self._call_stack.append(callee)

        # Track time
        if self._track_time:
            self._call_times[callee] = time.time()

    def _on_return(self, address: int) -> None:
        """Called when a function return is detected."""
        import time

        if not self._call_stack:
            return

        func_addr = self._call_stack.pop()

        # Update time
        if self._track_time and func_addr in self._call_times:
            elapsed = time.time() - self._call_times[func_addr]
            if func_addr in self._graph.nodes:
                self._graph.nodes[func_addr].total_time += elapsed
            del self._call_times[func_addr]

    def _find_library(self, address: int) -> str | None:
        """Find which library an address belongs to."""
        for module in self._emulator._modules.values():
            if module.base_address <= address < module.base_address + module.size:
                return module.name
        return None

    def _resolve_name(self, address: int) -> str | None:
        """Resolve function name from address."""
        for module in self._emulator._modules.values():
            sym = module.get_symbol_at(address)
            if sym:
                return sym.name
        return None

    # ==================== Manual Graph Building ====================

    def add_call(
        self,
        caller: int,
        callee: int,
        caller_name: str | None = None,
        callee_name: str | None = None,
    ) -> None:
        """Manually add a call to the graph."""
        self._graph.add_node(
            caller,
            name=caller_name or self._resolve_name(caller),
            library=self._find_library(caller)
        )
        node = self._graph.add_node(
            callee,
            name=callee_name or self._resolve_name(callee),
            library=self._find_library(callee)
        )
        node.call_count += 1
        self._graph.add_edge(caller, callee)

    # ==================== Export Methods ====================

    def export_dot(self, path: str | Path) -> None:
        """Export graph in DOT (Graphviz) format."""
        lines = ["digraph CallGraph {"]
        lines.append("    rankdir=TB;")
        lines.append("    node [shape=box, style=filled, fillcolor=lightblue];")
        lines.append("")

        # Add nodes
        for node in self._graph.nodes.values():
            label = f"{node.name}\\n{node.call_count} calls"
            color = self._get_node_color(node)
            lines.append(f'    {node.id} [label="{label}", fillcolor="{color}"];')

        lines.append("")

        # Add edges
        for edge in self._graph.edges.values():
            caller_id = f"node_{edge.caller:x}"
            callee_id = f"node_{edge.callee:x}"
            label = str(edge.count) if edge.count > 1 else ""
            lines.append(f'    {caller_id} -> {callee_id} [label="{label}"];')

        lines.append("}")

        Path(path).write_text("\n".join(lines))
        logger.info(f"Exported DOT graph to {path}")

    def export_json(self, path: str | Path) -> None:
        """Export graph as JSON."""
        data = self._graph.to_dict()
        Path(path).write_text(json.dumps(data, indent=2))
        logger.info(f"Exported JSON graph to {path}")

    def export_mermaid(self, path: str | Path) -> None:
        """Export graph as Mermaid diagram."""
        lines = ["```mermaid", "flowchart TD"]

        # Add nodes
        for node in self._graph.nodes.values():
            node_id = f"N{node.address:x}"
            label = node.name.replace('"', "'")
            lines.append(f'    {node_id}["{label}"]')

        # Add edges
        for edge in self._graph.edges.values():
            caller_id = f"N{edge.caller:x}"
            callee_id = f"N{edge.callee:x}"
            if edge.count > 1:
                lines.append(f'    {caller_id} -->|{edge.count}| {callee_id}')
            else:
                lines.append(f'    {caller_id} --> {callee_id}')

        lines.append("```")

        Path(path).write_text("\n".join(lines))
        logger.info(f"Exported Mermaid diagram to {path}")

    def export_html(self, path: str | Path) -> None:
        """Export interactive HTML visualization using vis.js."""
        stats = self._graph.get_stats()

        # Prepare node data
        nodes_js = []
        for node in self._graph.nodes.values():
            nodes_js.append({
                "id": node.address,
                "label": node.name[:30],
                "title": f"{node.name}\nCalls: {node.call_count}\nAddress: {node.address:#x}",
                "color": self._get_node_color(node),
                "size": min(30, 10 + node.call_count * 2),
            })

        # Prepare edge data
        edges_js = []
        for edge in self._graph.edges.values():
            edges_js.append({
                "from": edge.caller,
                "to": edge.callee,
                "arrows": "to",
                "width": min(5, 1 + edge.count // 10),
                "title": f"Calls: {edge.count}",
            })

        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <title>PyUniDbg Call Graph</title>
    <script type="text/javascript" src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
    <style>
        body {{ 
            margin: 0; 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }}
        #header {{
            background: #333;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}
        #header h1 {{
            margin: 0;
            font-size: 1.5em;
        }}
        #stats {{
            display: flex;
            gap: 20px;
        }}
        #stats span {{
            background: #555;
            padding: 5px 15px;
            border-radius: 4px;
        }}
        #graph {{
            height: calc(100vh - 60px);
            width: 100%;
        }}
        #sidebar {{
            position: fixed;
            right: 0;
            top: 60px;
            width: 300px;
            height: calc(100vh - 60px);
            background: #f5f5f5;
            border-left: 1px solid #ddd;
            padding: 15px;
            overflow-y: auto;
            display: none;
        }}
        #sidebar.active {{
            display: block;
        }}
        #sidebar h2 {{
            margin-top: 0;
        }}
        .stat-item {{
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #ddd;
        }}
    </style>
</head>
<body>
    <div id="header">
        <h1>🔍 Call Graph Visualization</h1>
        <div id="stats">
            <span>Nodes: {stats.node_count}</span>
            <span>Edges: {stats.edge_count}</span>
            <span>Total Calls: {stats.total_calls}</span>
        </div>
    </div>
    <div id="graph"></div>
    <div id="sidebar">
        <h2>Node Details</h2>
        <div id="details"></div>
    </div>
    
    <script type="text/javascript">
        var nodes = new vis.DataSet({json.dumps(nodes_js)});
        var edges = new vis.DataSet({json.dumps(edges_js)});
        
        var container = document.getElementById('graph');
        var data = {{
            nodes: nodes,
            edges: edges
        }};
        var options = {{
            layout: {{
                hierarchical: {{
                    enabled: true,
                    direction: 'UD',
                    sortMethod: 'directed',
                    levelSeparation: 100,
                    nodeSpacing: 150
                }}
            }},
            physics: {{
                enabled: false
            }},
            interaction: {{
                hover: true,
                tooltipDelay: 100
            }},
            nodes: {{
                shape: 'box',
                font: {{ size: 12 }}
            }},
            edges: {{
                smooth: {{ type: 'cubicBezier' }}
            }}
        }};
        
        var network = new vis.Network(container, data, options);
        
        network.on("selectNode", function(params) {{
            if (params.nodes.length > 0) {{
                var nodeId = params.nodes[0];
                var node = nodes.get(nodeId);
                document.getElementById('sidebar').classList.add('active');
                document.getElementById('details').innerHTML = 
                    '<div class="stat-item"><span>Name</span><span>' + node.label + '</span></div>' +
                    '<div class="stat-item"><span>Address</span><span>0x' + nodeId.toString(16) + '</span></div>';
            }}
        }});
        
        network.on("deselectNode", function() {{
            document.getElementById('sidebar').classList.remove('active');
        }});
    </script>
</body>
</html>"""

        Path(path).write_text(html_content)
        logger.info(f"Exported HTML visualization to {path}")

    def _get_node_color(self, node: CallNode) -> str:
        """Get color for a node based on its properties."""
        if node.node_type == NodeType.SYSCALL:
            return "#ffcccc"  # Light red
        elif node.node_type == NodeType.JNI:
            return "#ccffcc"  # Light green
        elif node.is_imported:
            return "#ffffcc"  # Light yellow
        elif node.is_exported:
            return "#ccccff"  # Light blue
        else:
            return "#e6e6e6"  # Light gray

    # ==================== Query Methods ====================

    def get_stats(self) -> GraphStats:
        """Get graph statistics."""
        return self._graph.get_stats()

    def get_callers(self, address: int) -> list[CallNode]:
        """Get all callers of a function."""
        return [
            self._graph.nodes[addr]
            for addr in self._graph.get_callers(address)
            if addr in self._graph.nodes
        ]

    def get_callees(self, address: int) -> list[CallNode]:
        """Get all functions called by a function."""
        return [
            self._graph.nodes[addr]
            for addr in self._graph.get_callees(address)
            if addr in self._graph.nodes
        ]

    def find_path(
        self,
        start: int | str,
        end: int | str
    ) -> list[CallNode] | None:
        """Find a call path between two functions."""
        # Resolve names to addresses
        start_addr = self._resolve_address(start)
        end_addr = self._resolve_address(end)

        if start_addr is None or end_addr is None:
            return None

        path = self._graph.find_path(start_addr, end_addr)
        if path:
            return [self._graph.nodes[addr] for addr in path if addr in self._graph.nodes]
        return None

    def _resolve_address(self, name_or_addr: int | str) -> int | None:
        """Resolve function name to address."""
        if isinstance(name_or_addr, int):
            return name_or_addr

        for node in self._graph.nodes.values():
            if node.name == name_or_addr:
                return node.address

        return None

    def clear(self) -> None:
        """Clear the call graph."""
        self._graph = CallGraph()
        self._call_stack.clear()
        self._call_times.clear()


# ==================== Factory Function ====================

def create_call_graph(emulator: Emulator, **kwargs) -> CallGraphGenerator:
    """
    Create a call graph generator for the emulator.
    
    Args:
        emulator: Emulator instance
        **kwargs: Configuration options
    
    Returns:
        Configured CallGraphGenerator instance
    """
    generator = CallGraphGenerator(emulator)

    if kwargs.get("track_time", True):
        generator._track_time = True

    if kwargs.get("auto_start", False):
        generator.start()

    return generator
