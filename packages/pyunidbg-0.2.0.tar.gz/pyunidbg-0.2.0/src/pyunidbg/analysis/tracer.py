"""
Instruction Tracer - Trace execution with real-time disassembly.

Provides:
- Full execution trace with disassembly
- Configurable trace filters
- Multiple output formats
- Performance-optimized tracing
"""

import json
import logging
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import IO, TYPE_CHECKING

from unicorn import UC_HOOK_CODE, UC_HOOK_MEM_READ, UC_HOOK_MEM_WRITE

if TYPE_CHECKING:
    from ..core.emulator import Emulator

from .disasm import DisasmOutput, Disassembler
from .timewarp import TimeWarp

logger = logging.getLogger(__name__)


class TraceFormat(Enum):
    """Trace output format."""
    ASSEMBLY = auto()     # Standard disassembly
    PSEUDO_C = auto()     # Pseudo-C translation
    HEX_DUMP = auto()     # Hex + disassembly
    COMPACT = auto()      # Minimal format
    DETAILED = auto()     # Full details with registers
    JSON = auto()         # JSON output


class TraceEvent(Enum):
    """Types of trace events."""
    INSTRUCTION = auto()  # Instruction executed
    BLOCK = auto()        # Basic block executed
    MEM_READ = auto()     # Memory read
    MEM_WRITE = auto()    # Memory write
    CALL = auto()         # Function call
    RETURN = auto()       # Function return
    SYSCALL = auto()      # System call
    EXCEPTION = auto()    # Exception/interrupt


@dataclass
class RegisterState:
    """Captured register state."""
    values: dict[str, int] = field(default_factory=dict)

    def diff(self, other: 'RegisterState') -> dict[str, tuple[int, int]]:
        """Return registers that changed: {reg: (old, new)}"""
        changes = {}
        for reg, val in self.values.items():
            if reg in other.values and other.values[reg] != val:
                changes[reg] = (val, other.values[reg])
        return changes

    def to_dict(self) -> dict:
        return self.values.copy()


@dataclass
class TraceEntry:
    """Single trace entry."""
    index: int                          # Sequential index
    timestamp: float                    # Time of execution
    event_type: TraceEvent              # Event type
    address: int                        # Address
    size: int = 0                       # Instruction/data size

    # Instruction info
    disasm: DisasmOutput | None = None

    # Register state (optional)
    regs_before: RegisterState | None = None
    regs_after: RegisterState | None = None

    # Memory access info
    mem_address: int = 0
    mem_value: int = 0
    mem_size: int = 0

    # Call info
    target: int = 0
    return_address: int = 0

    # Additional context
    symbol: str = ""
    comment: str = ""

    def format(self, style: TraceFormat = TraceFormat.ASSEMBLY) -> str:
        """Format trace entry."""
        if style == TraceFormat.ASSEMBLY:
            return self._format_assembly()
        elif style == TraceFormat.PSEUDO_C:
            return self._format_pseudo_c()
        elif style == TraceFormat.HEX_DUMP:
            return self._format_hex_dump()
        elif style == TraceFormat.COMPACT:
            return self._format_compact()
        elif style == TraceFormat.DETAILED:
            return self._format_detailed()
        elif style == TraceFormat.JSON:
            return json.dumps(self.to_dict())
        return self._format_assembly()

    def _format_assembly(self) -> str:
        if self.event_type == TraceEvent.INSTRUCTION and self.disasm:
            return f"[{self.index:6}] {self.disasm.to_assembly()}"
        elif self.event_type == TraceEvent.MEM_READ:
            return f"[{self.index:6}] MEM_READ  0x{self.mem_address:x} = 0x{self.mem_value:x}"
        elif self.event_type == TraceEvent.MEM_WRITE:
            return f"[{self.index:6}] MEM_WRITE 0x{self.mem_address:x} <- 0x{self.mem_value:x}"
        elif self.event_type == TraceEvent.CALL:
            return f"[{self.index:6}] CALL      0x{self.target:x} ({self.symbol or 'unknown'})"
        elif self.event_type == TraceEvent.RETURN:
            return f"[{self.index:6}] RETURN    to 0x{self.return_address:x}"
        return f"[{self.index:6}] {self.event_type.name} at 0x{self.address:x}"

    def _format_pseudo_c(self) -> str:
        if self.event_type == TraceEvent.INSTRUCTION and self.disasm:
            return f"[{self.index:6}] {self.disasm.to_pseudo_c()}"
        return self._format_assembly()

    def _format_hex_dump(self) -> str:
        if self.event_type == TraceEvent.INSTRUCTION and self.disasm:
            return f"[{self.index:6}] {self.disasm.to_hex_dump()}"
        return self._format_assembly()

    def _format_compact(self) -> str:
        if self.event_type == TraceEvent.INSTRUCTION and self.disasm:
            return f"{self.index}: {self.disasm.to_compact()}"
        return f"{self.index}: {self.event_type.name}@{self.address:x}"

    def _format_detailed(self) -> str:
        lines = [self._format_assembly()]
        if self.regs_after and self.regs_before:
            changes = self.regs_before.diff(self.regs_after)
            if changes:
                change_str = ', '.join(f"{r}: 0x{old:x}->0x{new:x}"
                                       for r, (old, new) in changes.items())
                lines.append(f"         Δ {change_str}")
        return '\n'.join(lines)

    def to_dict(self) -> dict:
        return {
            'index': self.index,
            'timestamp': self.timestamp,
            'event': self.event_type.name,
            'address': self.address,
            'size': self.size,
            'disasm': self.disasm.to_dict() if self.disasm else None,
            'mem_address': self.mem_address,
            'mem_value': self.mem_value,
            'symbol': self.symbol,
            'comment': self.comment,
        }


class TraceFilter:
    """Filter for trace events."""

    def __init__(self):
        # Address ranges to trace
        self.address_ranges: list[tuple[int, int]] = []

        # Specific addresses to trace
        self.addresses: set[int] = set()

        # Event types to trace
        self.event_types: set[TraceEvent] = {TraceEvent.INSTRUCTION}

        # Skip addresses (don't trace these)
        self.skip_addresses: set[int] = set()
        self.skip_ranges: list[tuple[int, int]] = []

        # Trace only N instructions
        self.max_count: int | None = None

        # Custom filter function
        self.custom_filter: Callable[[int, bytes], bool] | None = None

    def should_trace(self, address: int, event: TraceEvent = TraceEvent.INSTRUCTION) -> bool:
        """Check if address should be traced."""
        # Check event type
        if event not in self.event_types:
            return False

        # Check skip lists
        if address in self.skip_addresses:
            return False

        for start, end in self.skip_ranges:
            if start <= address < end:
                return False

        # If no address filters, trace everything
        if not self.address_ranges and not self.addresses:
            return True

        # Check specific addresses
        if address in self.addresses:
            return True

        # Check address ranges
        for start, end in self.address_ranges:
            if start <= address < end:
                return True

        return False

    def add_range(self, start: int, end: int) -> 'TraceFilter':
        """Add address range to trace."""
        self.address_ranges.append((start, end))
        return self

    def add_address(self, address: int) -> 'TraceFilter':
        """Add specific address to trace."""
        self.addresses.add(address)
        return self

    def skip_address(self, address: int) -> 'TraceFilter':
        """Skip tracing at address."""
        self.skip_addresses.add(address)
        return self

    def skip_range(self, start: int, end: int) -> 'TraceFilter':
        """Skip tracing in range."""
        self.skip_ranges.append((start, end))
        return self

    def trace_events(self, *events: TraceEvent) -> 'TraceFilter':
        """Set events to trace."""
        self.event_types = set(events)
        return self

    def set_max_count(self, count: int) -> 'TraceFilter':
        """Limit trace to N entries."""
        self.max_count = count
        return self


class InstructionTracer:
    """
    Instruction tracer with real-time disassembly.
    
    Hooks into emulation to trace every instruction with:
    - Disassembly (multiple formats)
    - Register state tracking
    - Memory access logging
    - Call/return detection
    - Symbol resolution
    
    Example:
        tracer = InstructionTracer(emulator)
        
        # Start tracing
        tracer.start()
        
        # Run code
        emulator.run()
        
        # Stop and get trace
        tracer.stop()
        
        # Print trace
        for entry in tracer.entries:
            print(entry.format(TraceFormat.PSEUDO_C))
        
        # Save to file
        tracer.save("trace.json")
    """

    def __init__(self, emulator: 'Emulator', timewarp: TimeWarp = None):
        self.emulator = emulator
        self.timewarp = timewarp or TimeWarp(emulator)

        # Disassembler
        self.disasm = Disassembler(emulator)

        # Trace storage
        self._entries: deque = deque(maxlen=1000000)  # Max 1M entries
        self._index = 0

        # Hooks
        self._code_hook = None
        self._mem_read_hook = None
        self._mem_write_hook = None

        # State
        self._tracing = False
        self._filter = TraceFilter()
        self._format = TraceFormat.ASSEMBLY

        # Register tracking
        self._track_registers = False
        self._last_regs: RegisterState | None = None

        # Output stream
        self._output_stream: IO | None = None
        self._realtime_output = False

        # Statistics
        self._stats = {
            'instructions': 0,
            'mem_reads': 0,
            'mem_writes': 0,
            'calls': 0,
            'returns': 0,
        }

        # Call stack tracking
        self._call_stack: list[int] = []

        # Symbols for better output
        self._symbols: dict[int, str] = {}

    @property
    def entries(self) -> list[TraceEntry]:
        """Get all trace entries."""
        return list(self._entries)

    @property
    def is_tracing(self) -> bool:
        return self._tracing

    @property
    def stats(self) -> dict:
        return self._stats.copy()

    # ==================== Control ====================

    def start(self, filter: TraceFilter = None) -> None:
        """Start tracing."""
        if self._tracing:
            return

        if filter:
            self._filter = filter

        self._tracing = True

        # Install hooks
        self._code_hook = self.emulator.uc.hook_add(
            UC_HOOK_CODE, self._on_instruction
        )

        if TraceEvent.MEM_READ in self._filter.event_types:
            self._mem_read_hook = self.emulator.uc.hook_add(
                UC_HOOK_MEM_READ, self._on_mem_read
            )

        if TraceEvent.MEM_WRITE in self._filter.event_types:
            self._mem_write_hook = self.emulator.uc.hook_add(
                UC_HOOK_MEM_WRITE, self._on_mem_write
            )

        logger.info("Tracing started")

    def stop(self) -> None:
        """Stop tracing."""
        if not self._tracing:
            return

        self._tracing = False

        # Remove hooks
        if self._code_hook:
            self.emulator.uc.hook_del(self._code_hook)
            self._code_hook = None

        if self._mem_read_hook:
            self.emulator.uc.hook_del(self._mem_read_hook)
            self._mem_read_hook = None

        if self._mem_write_hook:
            self.emulator.uc.hook_del(self._mem_write_hook)
            self._mem_write_hook = None

        # Close output stream
        if self._output_stream:
            self._output_stream.close()
            self._output_stream = None

        logger.info(f"Tracing stopped. {len(self._entries)} entries collected.")

    def clear(self) -> None:
        """Clear trace entries."""
        self._entries.clear()
        self._index = 0
        self._stats = dict.fromkeys(self._stats, 0)
        self._call_stack.clear()

    def pause(self) -> None:
        """Temporarily pause tracing."""
        self._tracing = False

    def resume(self) -> None:
        """Resume tracing after pause."""
        self._tracing = True

    # ==================== Configuration ====================

    def set_format(self, format: TraceFormat) -> None:
        """Set output format."""
        self._format = format

    def set_filter(self, filter: TraceFilter) -> None:
        """Set trace filter."""
        self._filter = filter

    def enable_register_tracking(self, enabled: bool = True) -> None:
        """Enable tracking register changes."""
        self._track_registers = enabled

    def set_max_entries(self, max_entries: int) -> None:
        """Set maximum trace entries to keep."""
        self._entries = deque(list(self._entries), maxlen=max_entries)

    def enable_realtime_output(self, stream: IO = None) -> None:
        """Enable real-time output to stream."""
        import sys
        self._output_stream = stream or sys.stdout
        self._realtime_output = True

    def add_symbol(self, address: int, name: str) -> None:
        """Add symbol for better output."""
        self._symbols[address] = name
        self.disasm.add_symbol(address, name)

    def add_symbols(self, symbols: dict[int, str]) -> None:
        """Add multiple symbols."""
        self._symbols.update(symbols)
        self.disasm.add_symbols(symbols)

    # ==================== Hooks ====================

    def _on_instruction(self, uc, address: int, size: int, user_data) -> None:
        """Hook called on each instruction."""
        if not self._tracing:
            return

        if not self._filter.should_trace(address, TraceEvent.INSTRUCTION):
            return

        # Check max count
        if self._filter.max_count and self._index >= self._filter.max_count:
            self.stop()
            return

        # Update timewarp
        self.timewarp.on_instruction()

        # Capture registers before
        regs_before = None
        if self._track_registers:
            regs_before = self._capture_registers()

        # Disassemble
        disasm_out = self.disasm.disasm_at(address, size)

        # Detect calls/returns
        event_type = TraceEvent.INSTRUCTION
        target = 0
        return_addr = 0

        if disasm_out:
            mnemonic = disasm_out.mnemonic.lower()
            if mnemonic in ('bl', 'blr', 'blx'):
                event_type = TraceEvent.CALL
                self._stats['calls'] += 1
                self._call_stack.append(address + size)
            elif mnemonic == 'ret' or (mnemonic == 'bx' and 'lr' in disasm_out.operands):
                event_type = TraceEvent.RETURN
                self._stats['returns'] += 1
                if self._call_stack:
                    return_addr = self._call_stack.pop()

        # Create trace entry
        entry = TraceEntry(
            index=self._index,
            timestamp=self.timewarp.realtime.get_time(),
            event_type=event_type,
            address=address,
            size=size,
            disasm=disasm_out,
            regs_before=regs_before,
            target=target,
            return_address=return_addr,
            symbol=self._symbols.get(address, ""),
        )

        # Capture registers after (will be set by next instruction)
        if self._track_registers and self._last_regs:
            # Update previous entry with current regs
            if self._entries:
                self._entries[-1].regs_after = regs_before

        self._last_regs = regs_before

        # Store entry
        self._entries.append(entry)
        self._index += 1
        self._stats['instructions'] += 1

        # Real-time output
        if self._realtime_output and self._output_stream:
            self._output_stream.write(entry.format(self._format) + '\n')
            self._output_stream.flush()

    def _on_mem_read(self, uc, access, address: int, size: int, value: int, user_data) -> None:
        """Hook called on memory read."""
        if not self._tracing:
            return

        if not self._filter.should_trace(address, TraceEvent.MEM_READ):
            return

        entry = TraceEntry(
            index=self._index,
            timestamp=self.timewarp.realtime.get_time(),
            event_type=TraceEvent.MEM_READ,
            address=self.emulator.uc.reg_read(self.emulator.pc_reg),
            mem_address=address,
            mem_value=value,
            mem_size=size,
        )

        self._entries.append(entry)
        self._index += 1
        self._stats['mem_reads'] += 1

    def _on_mem_write(self, uc, access, address: int, size: int, value: int, user_data) -> None:
        """Hook called on memory write."""
        if not self._tracing:
            return

        if not self._filter.should_trace(address, TraceEvent.MEM_WRITE):
            return

        entry = TraceEntry(
            index=self._index,
            timestamp=self.timewarp.realtime.get_time(),
            event_type=TraceEvent.MEM_WRITE,
            address=self.emulator.uc.reg_read(self.emulator.pc_reg),
            mem_address=address,
            mem_value=value,
            mem_size=size,
        )

        self._entries.append(entry)
        self._index += 1
        self._stats['mem_writes'] += 1

    def _capture_registers(self) -> RegisterState:
        """Capture current register state."""
        values = {}

        if self.emulator.is_64bit:
            from unicorn.arm64_const import (
                UC_ARM64_REG_LR,
                UC_ARM64_REG_PC,
                UC_ARM64_REG_SP,
                UC_ARM64_REG_X0,
                UC_ARM64_REG_X1,
                UC_ARM64_REG_X2,
                UC_ARM64_REG_X3,
                UC_ARM64_REG_X4,
                UC_ARM64_REG_X5,
                UC_ARM64_REG_X6,
                UC_ARM64_REG_X7,
                UC_ARM64_REG_X8,
            )
            regs = [
                ('x0', UC_ARM64_REG_X0), ('x1', UC_ARM64_REG_X1),
                ('x2', UC_ARM64_REG_X2), ('x3', UC_ARM64_REG_X3),
                ('x4', UC_ARM64_REG_X4), ('x5', UC_ARM64_REG_X5),
                ('x6', UC_ARM64_REG_X6), ('x7', UC_ARM64_REG_X7),
                ('x8', UC_ARM64_REG_X8), ('sp', UC_ARM64_REG_SP),
                ('pc', UC_ARM64_REG_PC), ('lr', UC_ARM64_REG_LR),
            ]
        else:
            from unicorn.arm_const import (
                UC_ARM_REG_LR,
                UC_ARM_REG_PC,
                UC_ARM_REG_R0,
                UC_ARM_REG_R1,
                UC_ARM_REG_R2,
                UC_ARM_REG_R3,
                UC_ARM_REG_R4,
                UC_ARM_REG_R5,
                UC_ARM_REG_R6,
                UC_ARM_REG_R7,
                UC_ARM_REG_SP,
            )
            regs = [
                ('r0', UC_ARM_REG_R0), ('r1', UC_ARM_REG_R1),
                ('r2', UC_ARM_REG_R2), ('r3', UC_ARM_REG_R3),
                ('r4', UC_ARM_REG_R4), ('r5', UC_ARM_REG_R5),
                ('r6', UC_ARM_REG_R6), ('r7', UC_ARM_REG_R7),
                ('sp', UC_ARM_REG_SP), ('pc', UC_ARM_REG_PC),
                ('lr', UC_ARM_REG_LR),
            ]

        for name, reg_id in regs:
            values[name] = self.emulator.uc.reg_read(reg_id)

        return RegisterState(values=values)

    # ==================== Output ====================

    def format_all(self, style: TraceFormat = None) -> str:
        """Format all trace entries."""
        style = style or self._format
        return '\n'.join(entry.format(style) for entry in self._entries)

    def save(self, filename: str, format: TraceFormat = None) -> None:
        """Save trace to file."""
        format = format or self._format

        with open(filename, 'w') as f:
            if format == TraceFormat.JSON:
                json.dump([e.to_dict() for e in self._entries], f, indent=2)
            else:
                for entry in self._entries:
                    f.write(entry.format(format) + '\n')

        logger.info(f"Trace saved to {filename}")

    def print_summary(self) -> None:
        """Print trace statistics."""
        print("=== Trace Summary ===")
        print(f"Total entries:     {len(self._entries)}")
        print(f"Instructions:      {self._stats['instructions']}")
        print(f"Memory reads:      {self._stats['mem_reads']}")
        print(f"Memory writes:     {self._stats['mem_writes']}")
        print(f"Function calls:    {self._stats['calls']}")
        print(f"Function returns:  {self._stats['returns']}")
