"""
Snapshot Manager - State capture and replay with time control.

Provides:
- Full CPU + memory state snapshots
- Replay with time manipulation
- Branch exploration
- Differential snapshots for efficiency
"""

import hashlib
import json
import logging
import pickle
import struct
import time
import zlib
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.emulator import Emulator

from .timewarp import TimeState, TimeWarp

logger = logging.getLogger(__name__)


class SnapshotType(Enum):
    """Snapshot types."""
    FULL = auto()          # Complete state snapshot
    DIFFERENTIAL = auto()  # Only changed memory
    CHECKPOINT = auto()    # Lightweight checkpoint


@dataclass
class MemoryRegion:
    """Captured memory region."""
    address: int
    size: int
    data: bytes
    permissions: int = 7  # RWX by default

    def compress(self) -> bytes:
        """Compress memory data."""
        return zlib.compress(self.data)

    @classmethod
    def decompress(cls, address: int, size: int, compressed: bytes,
                   permissions: int = 7) -> 'MemoryRegion':
        """Create from compressed data."""
        data = zlib.decompress(compressed)
        return cls(address=address, size=size, data=data, permissions=permissions)

    def hash(self) -> str:
        """Get hash of memory content."""
        return hashlib.md5(self.data).hexdigest()


@dataclass
class RegisterState:
    """Captured register state."""
    # ARM64 registers
    x0: int = 0
    x1: int = 0
    x2: int = 0
    x3: int = 0
    x4: int = 0
    x5: int = 0
    x6: int = 0
    x7: int = 0
    x8: int = 0
    x9: int = 0
    x10: int = 0
    x11: int = 0
    x12: int = 0
    x13: int = 0
    x14: int = 0
    x15: int = 0
    x16: int = 0
    x17: int = 0
    x18: int = 0
    x19: int = 0
    x20: int = 0
    x21: int = 0
    x22: int = 0
    x23: int = 0
    x24: int = 0
    x25: int = 0
    x26: int = 0
    x27: int = 0
    x28: int = 0
    x29: int = 0  # FP
    x30: int = 0  # LR
    sp: int = 0
    pc: int = 0

    # ARM32 registers (alternative)
    r0: int = 0
    r1: int = 0
    r2: int = 0
    r3: int = 0
    r4: int = 0
    r5: int = 0
    r6: int = 0
    r7: int = 0
    r8: int = 0
    r9: int = 0
    r10: int = 0
    r11: int = 0  # FP
    r12: int = 0
    r13: int = 0  # SP
    r14: int = 0  # LR
    r15: int = 0  # PC
    cpsr: int = 0

    # Flags
    is_64bit: bool = True

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        if self.is_64bit:
            return {
                'x0': self.x0, 'x1': self.x1, 'x2': self.x2, 'x3': self.x3,
                'x4': self.x4, 'x5': self.x5, 'x6': self.x6, 'x7': self.x7,
                'x8': self.x8, 'x9': self.x9, 'x10': self.x10, 'x11': self.x11,
                'x12': self.x12, 'x13': self.x13, 'x14': self.x14, 'x15': self.x15,
                'x16': self.x16, 'x17': self.x17, 'x18': self.x18, 'x19': self.x19,
                'x20': self.x20, 'x21': self.x21, 'x22': self.x22, 'x23': self.x23,
                'x24': self.x24, 'x25': self.x25, 'x26': self.x26, 'x27': self.x27,
                'x28': self.x28, 'x29': self.x29, 'x30': self.x30,
                'sp': self.sp, 'pc': self.pc,
                'is_64bit': True,
            }
        else:
            return {
                'r0': self.r0, 'r1': self.r1, 'r2': self.r2, 'r3': self.r3,
                'r4': self.r4, 'r5': self.r5, 'r6': self.r6, 'r7': self.r7,
                'r8': self.r8, 'r9': self.r9, 'r10': self.r10, 'r11': self.r11,
                'r12': self.r12, 'r13': self.r13, 'r14': self.r14, 'r15': self.r15,
                'cpsr': self.cpsr,
                'is_64bit': False,
            }

    @classmethod
    def from_dict(cls, data: dict) -> 'RegisterState':
        """Create from dictionary."""
        return cls(**data)


@dataclass
class Snapshot:
    """Complete emulator state snapshot."""
    id: str                                    # Unique identifier
    name: str                                  # User-friendly name
    snapshot_type: SnapshotType
    timestamp: float                           # When snapshot was taken

    # CPU state
    registers: RegisterState = field(default_factory=RegisterState)

    # Memory state
    memory_regions: list[MemoryRegion] = field(default_factory=list)

    # Time state
    time_state: TimeState | None = None

    # Parent snapshot (for differential)
    parent_id: str | None = None

    # Metadata
    instruction_count: int = 0
    description: str = ""
    tags: list[str] = field(default_factory=list)

    # Checksums
    memory_hash: str = ""

    def size_bytes(self) -> int:
        """Calculate snapshot size in bytes."""
        return sum(len(r.data) for r in self.memory_regions)

    def to_dict(self) -> dict:
        """Convert to serializable dictionary."""
        return {
            'id': self.id,
            'name': self.name,
            'type': self.snapshot_type.name,
            'timestamp': self.timestamp,
            'registers': self.registers.to_dict(),
            'time_state': self.time_state.to_dict() if self.time_state else None,
            'parent_id': self.parent_id,
            'instruction_count': self.instruction_count,
            'description': self.description,
            'tags': self.tags,
            'memory_hash': self.memory_hash,
        }


class SnapshotManager:
    """
    Manages emulator state snapshots.
    
    Provides:
    - Full state capture (CPU + memory)
    - Efficient differential snapshots
    - Time-aware replay
    - Save/load to disk
    
    Example:
        snapmgr = SnapshotManager(emulator, timewarp)
        
        # Take snapshot
        snap_id = snapmgr.take("before_check")
        
        # Run some code...
        emulator.run()
        
        # Restore snapshot with time adjustment
        snapmgr.restore(snap_id, adjust_time=True)
        
        # Try different path...
    """

    def __init__(self, emulator: 'Emulator', timewarp: TimeWarp = None):
        self.emulator = emulator
        self.timewarp = timewarp or TimeWarp(emulator)

        # Snapshot storage
        self._snapshots: dict[str, Snapshot] = {}
        self._snapshot_order: list[str] = []  # For navigation

        # Current position
        self._current_id: str | None = None

        # Memory tracking for differential snapshots
        self._base_memory: dict[int, bytes] = {}
        self._dirty_pages: set[int] = set()

        # Settings
        self.page_size = 4096
        self.compress = True
        self.auto_checkpoint = False
        self.checkpoint_interval = 10000  # Instructions

        # Statistics
        self._stats = {
            'snapshots_taken': 0,
            'snapshots_restored': 0,
            'bytes_saved': 0,
        }

        # Checkpoint counter
        self._insn_counter = 0

    @property
    def snapshots(self) -> list[Snapshot]:
        return [self._snapshots[sid] for sid in self._snapshot_order]

    @property
    def stats(self) -> dict:
        return self._stats.copy()

    # ==================== Snapshot Operations ====================

    def take(self, name: str = "", description: str = "",
             snapshot_type: SnapshotType = SnapshotType.FULL) -> str:
        """
        Take snapshot of current state.
        
        Args:
            name: Optional name for snapshot
            description: Optional description
            snapshot_type: Full or differential
            
        Returns:
            Snapshot ID
        """
        import uuid
        snap_id = str(uuid.uuid4())[:8]

        if not name:
            name = f"snapshot_{len(self._snapshots) + 1}"

        # Capture registers
        registers = self._capture_registers()

        # Capture memory
        if snapshot_type == SnapshotType.DIFFERENTIAL and self._current_id:
            memory_regions = self._capture_differential_memory()
            parent_id = self._current_id
        else:
            memory_regions = self._capture_full_memory()
            parent_id = None

        # Capture time state
        time_state = self.timewarp.capture_state()

        # Calculate memory hash
        memory_hash = self._calculate_memory_hash(memory_regions)

        snapshot = Snapshot(
            id=snap_id,
            name=name,
            snapshot_type=snapshot_type,
            timestamp=time.time(),
            registers=registers,
            memory_regions=memory_regions,
            time_state=time_state,
            parent_id=parent_id,
            instruction_count=self.timewarp.instruction_count,
            description=description,
            memory_hash=memory_hash,
        )

        self._snapshots[snap_id] = snapshot
        self._snapshot_order.append(snap_id)
        self._current_id = snap_id

        self._stats['snapshots_taken'] += 1
        self._stats['bytes_saved'] += snapshot.size_bytes()

        logger.info(f"Snapshot taken: {name} ({snap_id})")
        return snap_id

    def restore(self, snap_id: str, adjust_time: bool = True) -> bool:
        """
        Restore emulator to snapshot state.
        
        Args:
            snap_id: Snapshot ID to restore
            adjust_time: If True, adjust time to account for elapsed real time
            
        Returns:
            True if successful
        """
        if snap_id not in self._snapshots:
            logger.error(f"Snapshot not found: {snap_id}")
            return False

        snapshot = self._snapshots[snap_id]

        # Restore registers
        self._restore_registers(snapshot.registers)

        # Restore memory
        if snapshot.snapshot_type == SnapshotType.DIFFERENTIAL:
            self._restore_differential_memory(snapshot)
        else:
            self._restore_full_memory(snapshot)

        # Restore time state
        if snapshot.time_state:
            self.timewarp.restore_state(snapshot.time_state, adjust_to_now=adjust_time)

        self._current_id = snap_id
        self._stats['snapshots_restored'] += 1

        logger.info(f"Restored snapshot: {snapshot.name} ({snap_id})")
        return True

    def delete(self, snap_id: str) -> bool:
        """Delete snapshot."""
        if snap_id not in self._snapshots:
            return False

        # Check if other snapshots depend on this one
        for other_id, other in self._snapshots.items():
            if other.parent_id == snap_id:
                logger.warning(f"Cannot delete: snapshot {other.name} depends on this")
                return False

        del self._snapshots[snap_id]
        self._snapshot_order.remove(snap_id)

        if self._current_id == snap_id:
            self._current_id = self._snapshot_order[-1] if self._snapshot_order else None

        return True

    def get(self, snap_id: str) -> Snapshot | None:
        """Get snapshot by ID."""
        return self._snapshots.get(snap_id)

    def find_by_name(self, name: str) -> Snapshot | None:
        """Find snapshot by name."""
        for snap in self._snapshots.values():
            if snap.name == name:
                return snap
        return None

    # ==================== Memory Capture ====================

    def _capture_registers(self) -> RegisterState:
        """Capture current register state."""
        regs = RegisterState(is_64bit=self.emulator.is_64bit)

        if self.emulator.is_64bit:
            from unicorn.arm64_const import (
                UC_ARM64_REG_PC,
                UC_ARM64_REG_SP,
                UC_ARM64_REG_X0,
                UC_ARM64_REG_X1,
                UC_ARM64_REG_X2,
                UC_ARM64_REG_X3,
                UC_ARM64_REG_X4,
                UC_ARM64_REG_X5,
                UC_ARM64_REG_X6,
                UC_ARM64_REG_X7,
                UC_ARM64_REG_X8,
                UC_ARM64_REG_X9,
                UC_ARM64_REG_X10,
                UC_ARM64_REG_X11,
                UC_ARM64_REG_X12,
                UC_ARM64_REG_X13,
                UC_ARM64_REG_X14,
                UC_ARM64_REG_X15,
                UC_ARM64_REG_X16,
                UC_ARM64_REG_X17,
                UC_ARM64_REG_X18,
                UC_ARM64_REG_X19,
                UC_ARM64_REG_X20,
                UC_ARM64_REG_X21,
                UC_ARM64_REG_X22,
                UC_ARM64_REG_X23,
                UC_ARM64_REG_X24,
                UC_ARM64_REG_X25,
                UC_ARM64_REG_X26,
                UC_ARM64_REG_X27,
                UC_ARM64_REG_X28,
                UC_ARM64_REG_X29,
                UC_ARM64_REG_X30,
            )

            regs.x0 = self.emulator.uc.reg_read(UC_ARM64_REG_X0)
            regs.x1 = self.emulator.uc.reg_read(UC_ARM64_REG_X1)
            regs.x2 = self.emulator.uc.reg_read(UC_ARM64_REG_X2)
            regs.x3 = self.emulator.uc.reg_read(UC_ARM64_REG_X3)
            regs.x4 = self.emulator.uc.reg_read(UC_ARM64_REG_X4)
            regs.x5 = self.emulator.uc.reg_read(UC_ARM64_REG_X5)
            regs.x6 = self.emulator.uc.reg_read(UC_ARM64_REG_X6)
            regs.x7 = self.emulator.uc.reg_read(UC_ARM64_REG_X7)
            regs.x8 = self.emulator.uc.reg_read(UC_ARM64_REG_X8)
            regs.x9 = self.emulator.uc.reg_read(UC_ARM64_REG_X9)
            regs.x10 = self.emulator.uc.reg_read(UC_ARM64_REG_X10)
            regs.x11 = self.emulator.uc.reg_read(UC_ARM64_REG_X11)
            regs.x12 = self.emulator.uc.reg_read(UC_ARM64_REG_X12)
            regs.x13 = self.emulator.uc.reg_read(UC_ARM64_REG_X13)
            regs.x14 = self.emulator.uc.reg_read(UC_ARM64_REG_X14)
            regs.x15 = self.emulator.uc.reg_read(UC_ARM64_REG_X15)
            regs.x16 = self.emulator.uc.reg_read(UC_ARM64_REG_X16)
            regs.x17 = self.emulator.uc.reg_read(UC_ARM64_REG_X17)
            regs.x18 = self.emulator.uc.reg_read(UC_ARM64_REG_X18)
            regs.x19 = self.emulator.uc.reg_read(UC_ARM64_REG_X19)
            regs.x20 = self.emulator.uc.reg_read(UC_ARM64_REG_X20)
            regs.x21 = self.emulator.uc.reg_read(UC_ARM64_REG_X21)
            regs.x22 = self.emulator.uc.reg_read(UC_ARM64_REG_X22)
            regs.x23 = self.emulator.uc.reg_read(UC_ARM64_REG_X23)
            regs.x24 = self.emulator.uc.reg_read(UC_ARM64_REG_X24)
            regs.x25 = self.emulator.uc.reg_read(UC_ARM64_REG_X25)
            regs.x26 = self.emulator.uc.reg_read(UC_ARM64_REG_X26)
            regs.x27 = self.emulator.uc.reg_read(UC_ARM64_REG_X27)
            regs.x28 = self.emulator.uc.reg_read(UC_ARM64_REG_X28)
            regs.x29 = self.emulator.uc.reg_read(UC_ARM64_REG_X29)
            regs.x30 = self.emulator.uc.reg_read(UC_ARM64_REG_X30)
            regs.sp = self.emulator.uc.reg_read(UC_ARM64_REG_SP)
            regs.pc = self.emulator.uc.reg_read(UC_ARM64_REG_PC)
        else:
            from unicorn.arm_const import (
                UC_ARM_REG_CPSR,
                UC_ARM_REG_LR,
                UC_ARM_REG_PC,
                UC_ARM_REG_R0,
                UC_ARM_REG_R1,
                UC_ARM_REG_R2,
                UC_ARM_REG_R3,
                UC_ARM_REG_R4,
                UC_ARM_REG_R5,
                UC_ARM_REG_R6,
                UC_ARM_REG_R7,
                UC_ARM_REG_R8,
                UC_ARM_REG_R9,
                UC_ARM_REG_R10,
                UC_ARM_REG_R11,
                UC_ARM_REG_R12,
                UC_ARM_REG_SP,
            )

            regs.r0 = self.emulator.uc.reg_read(UC_ARM_REG_R0)
            regs.r1 = self.emulator.uc.reg_read(UC_ARM_REG_R1)
            regs.r2 = self.emulator.uc.reg_read(UC_ARM_REG_R2)
            regs.r3 = self.emulator.uc.reg_read(UC_ARM_REG_R3)
            regs.r4 = self.emulator.uc.reg_read(UC_ARM_REG_R4)
            regs.r5 = self.emulator.uc.reg_read(UC_ARM_REG_R5)
            regs.r6 = self.emulator.uc.reg_read(UC_ARM_REG_R6)
            regs.r7 = self.emulator.uc.reg_read(UC_ARM_REG_R7)
            regs.r8 = self.emulator.uc.reg_read(UC_ARM_REG_R8)
            regs.r9 = self.emulator.uc.reg_read(UC_ARM_REG_R9)
            regs.r10 = self.emulator.uc.reg_read(UC_ARM_REG_R10)
            regs.r11 = self.emulator.uc.reg_read(UC_ARM_REG_R11)
            regs.r12 = self.emulator.uc.reg_read(UC_ARM_REG_R12)
            regs.r13 = self.emulator.uc.reg_read(UC_ARM_REG_SP)
            regs.r14 = self.emulator.uc.reg_read(UC_ARM_REG_LR)
            regs.r15 = self.emulator.uc.reg_read(UC_ARM_REG_PC)
            regs.cpsr = self.emulator.uc.reg_read(UC_ARM_REG_CPSR)

        return regs

    def _restore_registers(self, regs: RegisterState) -> None:
        """Restore register state."""
        if regs.is_64bit:
            from unicorn.arm64_const import (
                UC_ARM64_REG_PC,
                UC_ARM64_REG_SP,
                UC_ARM64_REG_X0,
                UC_ARM64_REG_X1,
                UC_ARM64_REG_X2,
                UC_ARM64_REG_X3,
                UC_ARM64_REG_X4,
                UC_ARM64_REG_X5,
                UC_ARM64_REG_X6,
                UC_ARM64_REG_X7,
                UC_ARM64_REG_X8,
                UC_ARM64_REG_X9,
                UC_ARM64_REG_X10,
                UC_ARM64_REG_X11,
                UC_ARM64_REG_X12,
                UC_ARM64_REG_X13,
                UC_ARM64_REG_X14,
                UC_ARM64_REG_X15,
                UC_ARM64_REG_X16,
                UC_ARM64_REG_X17,
                UC_ARM64_REG_X18,
                UC_ARM64_REG_X19,
                UC_ARM64_REG_X20,
                UC_ARM64_REG_X21,
                UC_ARM64_REG_X22,
                UC_ARM64_REG_X23,
                UC_ARM64_REG_X24,
                UC_ARM64_REG_X25,
                UC_ARM64_REG_X26,
                UC_ARM64_REG_X27,
                UC_ARM64_REG_X28,
                UC_ARM64_REG_X29,
                UC_ARM64_REG_X30,
            )

            self.emulator.uc.reg_write(UC_ARM64_REG_X0, regs.x0)
            self.emulator.uc.reg_write(UC_ARM64_REG_X1, regs.x1)
            self.emulator.uc.reg_write(UC_ARM64_REG_X2, regs.x2)
            self.emulator.uc.reg_write(UC_ARM64_REG_X3, regs.x3)
            self.emulator.uc.reg_write(UC_ARM64_REG_X4, regs.x4)
            self.emulator.uc.reg_write(UC_ARM64_REG_X5, regs.x5)
            self.emulator.uc.reg_write(UC_ARM64_REG_X6, regs.x6)
            self.emulator.uc.reg_write(UC_ARM64_REG_X7, regs.x7)
            self.emulator.uc.reg_write(UC_ARM64_REG_X8, regs.x8)
            self.emulator.uc.reg_write(UC_ARM64_REG_X9, regs.x9)
            self.emulator.uc.reg_write(UC_ARM64_REG_X10, regs.x10)
            self.emulator.uc.reg_write(UC_ARM64_REG_X11, regs.x11)
            self.emulator.uc.reg_write(UC_ARM64_REG_X12, regs.x12)
            self.emulator.uc.reg_write(UC_ARM64_REG_X13, regs.x13)
            self.emulator.uc.reg_write(UC_ARM64_REG_X14, regs.x14)
            self.emulator.uc.reg_write(UC_ARM64_REG_X15, regs.x15)
            self.emulator.uc.reg_write(UC_ARM64_REG_X16, regs.x16)
            self.emulator.uc.reg_write(UC_ARM64_REG_X17, regs.x17)
            self.emulator.uc.reg_write(UC_ARM64_REG_X18, regs.x18)
            self.emulator.uc.reg_write(UC_ARM64_REG_X19, regs.x19)
            self.emulator.uc.reg_write(UC_ARM64_REG_X20, regs.x20)
            self.emulator.uc.reg_write(UC_ARM64_REG_X21, regs.x21)
            self.emulator.uc.reg_write(UC_ARM64_REG_X22, regs.x22)
            self.emulator.uc.reg_write(UC_ARM64_REG_X23, regs.x23)
            self.emulator.uc.reg_write(UC_ARM64_REG_X24, regs.x24)
            self.emulator.uc.reg_write(UC_ARM64_REG_X25, regs.x25)
            self.emulator.uc.reg_write(UC_ARM64_REG_X26, regs.x26)
            self.emulator.uc.reg_write(UC_ARM64_REG_X27, regs.x27)
            self.emulator.uc.reg_write(UC_ARM64_REG_X28, regs.x28)
            self.emulator.uc.reg_write(UC_ARM64_REG_X29, regs.x29)
            self.emulator.uc.reg_write(UC_ARM64_REG_X30, regs.x30)
            self.emulator.uc.reg_write(UC_ARM64_REG_SP, regs.sp)
            self.emulator.uc.reg_write(UC_ARM64_REG_PC, regs.pc)
        else:
            from unicorn.arm_const import (
                UC_ARM_REG_CPSR,
                UC_ARM_REG_LR,
                UC_ARM_REG_PC,
                UC_ARM_REG_R0,
                UC_ARM_REG_R1,
                UC_ARM_REG_R2,
                UC_ARM_REG_R3,
                UC_ARM_REG_R4,
                UC_ARM_REG_R5,
                UC_ARM_REG_R6,
                UC_ARM_REG_R7,
                UC_ARM_REG_R8,
                UC_ARM_REG_R9,
                UC_ARM_REG_R10,
                UC_ARM_REG_R11,
                UC_ARM_REG_R12,
                UC_ARM_REG_SP,
            )

            self.emulator.uc.reg_write(UC_ARM_REG_R0, regs.r0)
            self.emulator.uc.reg_write(UC_ARM_REG_R1, regs.r1)
            self.emulator.uc.reg_write(UC_ARM_REG_R2, regs.r2)
            self.emulator.uc.reg_write(UC_ARM_REG_R3, regs.r3)
            self.emulator.uc.reg_write(UC_ARM_REG_R4, regs.r4)
            self.emulator.uc.reg_write(UC_ARM_REG_R5, regs.r5)
            self.emulator.uc.reg_write(UC_ARM_REG_R6, regs.r6)
            self.emulator.uc.reg_write(UC_ARM_REG_R7, regs.r7)
            self.emulator.uc.reg_write(UC_ARM_REG_R8, regs.r8)
            self.emulator.uc.reg_write(UC_ARM_REG_R9, regs.r9)
            self.emulator.uc.reg_write(UC_ARM_REG_R10, regs.r10)
            self.emulator.uc.reg_write(UC_ARM_REG_R11, regs.r11)
            self.emulator.uc.reg_write(UC_ARM_REG_R12, regs.r12)
            self.emulator.uc.reg_write(UC_ARM_REG_SP, regs.r13)
            self.emulator.uc.reg_write(UC_ARM_REG_LR, regs.r14)
            self.emulator.uc.reg_write(UC_ARM_REG_PC, regs.r15)
            self.emulator.uc.reg_write(UC_ARM_REG_CPSR, regs.cpsr)

    def _capture_full_memory(self) -> list[MemoryRegion]:
        """Capture all mapped memory regions."""
        regions = []

        for start, end, perm in self.emulator.uc.mem_regions():
            size = end - start + 1
            try:
                data = self.emulator.uc.mem_read(start, size)

                if self.compress:
                    region = MemoryRegion(
                        address=start,
                        size=size,
                        data=zlib.compress(bytes(data)),
                        permissions=perm,
                    )
                else:
                    region = MemoryRegion(
                        address=start,
                        size=size,
                        data=bytes(data),
                        permissions=perm,
                    )

                regions.append(region)

            except Exception as e:
                logger.warning(f"Failed to capture region 0x{start:x}: {e}")

        return regions

    def _capture_differential_memory(self) -> list[MemoryRegion]:
        """Capture only changed memory pages."""
        regions = []

        for start, end, perm in self.emulator.uc.mem_regions():
            size = end - start + 1

            # Check each page
            for page_start in range(start, start + size, self.page_size):
                page_size = min(self.page_size, start + size - page_start)

                try:
                    current_data = bytes(self.emulator.uc.mem_read(page_start, page_size))

                    # Check if changed from base
                    base_data = self._base_memory.get(page_start)
                    if base_data != current_data:
                        if self.compress:
                            data = zlib.compress(current_data)
                        else:
                            data = current_data

                        regions.append(MemoryRegion(
                            address=page_start,
                            size=page_size,
                            data=data,
                            permissions=perm,
                        ))

                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)

        return regions

    def _restore_full_memory(self, snapshot: Snapshot) -> None:
        """Restore all memory from snapshot."""
        for region in snapshot.memory_regions:
            try:
                if self.compress:
                    data = zlib.decompress(region.data)
                else:
                    data = region.data

                self.emulator.uc.mem_write(region.address, data)

            except Exception as e:
                logger.warning(f"Failed to restore region 0x{region.address:x}: {e}")

    def _restore_differential_memory(self, snapshot: Snapshot) -> None:
        """Restore differential memory, applying changes to parent state."""
        # First restore parent
        if snapshot.parent_id and snapshot.parent_id in self._snapshots:
            parent = self._snapshots[snapshot.parent_id]
            if parent.snapshot_type == SnapshotType.DIFFERENTIAL:
                self._restore_differential_memory(parent)
            else:
                self._restore_full_memory(parent)

        # Then apply this snapshot's changes
        for region in snapshot.memory_regions:
            try:
                if self.compress:
                    data = zlib.decompress(region.data)
                else:
                    data = region.data

                self.emulator.uc.mem_write(region.address, data)

            except Exception as e:
                logger.warning(f"Failed to apply diff at 0x{region.address:x}: {e}")

    def _calculate_memory_hash(self, regions: list[MemoryRegion]) -> str:
        """Calculate hash of memory content."""
        hasher = hashlib.sha256()
        for region in sorted(regions, key=lambda r: r.address):
            hasher.update(struct.pack('<Q', region.address))
            hasher.update(region.data)
        return hasher.hexdigest()[:16]

    # ==================== File Operations ====================

    def save(self, snap_id: str, filename: str) -> bool:
        """Save snapshot to file."""
        if snap_id not in self._snapshots:
            return False

        snapshot = self._snapshots[snap_id]

        with open(filename, 'wb') as f:
            pickle.dump(snapshot, f)

        logger.info(f"Saved snapshot to {filename}")
        return True

    def load(self, filename: str) -> str | None:
        """Load snapshot from file."""
        with open(filename, 'rb') as f:
            # SECURITY: pickle deserialization can execute arbitrary code — only use with trusted data
            logger.warning("Deserializing data via pickle — ensure source is trusted")
            snapshot = pickle.load(f)

        self._snapshots[snapshot.id] = snapshot
        self._snapshot_order.append(snapshot.id)

        logger.info(f"Loaded snapshot: {snapshot.name} ({snapshot.id})")
        return snapshot.id

    def export_metadata(self, filename: str) -> None:
        """Export snapshot metadata to JSON."""
        metadata = [snap.to_dict() for snap in self._snapshots.values()]
        with open(filename, 'w') as f:
            json.dump(metadata, f, indent=2)

    # ==================== Navigation ====================

    def list_snapshots(self) -> list[str]:
        """List all snapshot IDs in order."""
        return self._snapshot_order.copy()

    def previous(self) -> str | None:
        """Go to previous snapshot."""
        if not self._current_id or len(self._snapshot_order) < 2:
            return None

        idx = self._snapshot_order.index(self._current_id)
        if idx > 0:
            prev_id = self._snapshot_order[idx - 1]
            self.restore(prev_id)
            return prev_id
        return None

    def next(self) -> str | None:
        """Go to next snapshot."""
        if not self._current_id or len(self._snapshot_order) < 2:
            return None

        idx = self._snapshot_order.index(self._current_id)
        if idx < len(self._snapshot_order) - 1:
            next_id = self._snapshot_order[idx + 1]
            self.restore(next_id)
            return next_id
        return None

    def print_list(self) -> None:
        """Print list of snapshots."""
        print("=== Snapshots ===")
        for i, snap_id in enumerate(self._snapshot_order):
            snap = self._snapshots[snap_id]
            current = " *" if snap_id == self._current_id else ""
            size = snap.size_bytes()
            print(f"  [{i}] {snap.name} ({snap_id}){current}")
            print(f"      Type: {snap.snapshot_type.name}, Size: {size} bytes")
            if snap.description:
                print(f"      {snap.description}")


class ReplayController:
    """
    Controls replay execution with time manipulation.
    
    Provides:
    - Step-by-step replay
    - Branch exploration
    - Time-controlled replay
    """

    def __init__(self, emulator: 'Emulator', snapshot_mgr: SnapshotManager):
        self.emulator = emulator
        self.snapmgr = snapshot_mgr
        self.timewarp = snapshot_mgr.timewarp

        # Replay state
        self._replay_active = False
        self._current_step = 0
        self._target_step = 0

        # Branch exploration
        self._branches: list[tuple[str, int]] = []  # (snapshot_id, branch_pc)

    def start_replay(self, from_snapshot: str) -> bool:
        """Start replay from snapshot."""
        if not self.snapmgr.restore(from_snapshot, adjust_time=False):
            return False

        self._replay_active = True
        self._current_step = 0

        # Freeze time during replay
        self.timewarp.freeze_all()

        logger.info(f"Replay started from {from_snapshot}")
        return True

    def step(self, count: int = 1) -> int:
        """Execute N instructions during replay."""
        if not self._replay_active:
            return 0

        # Advance time per instruction
        for _ in range(count):
            self.timewarp.on_instruction()
            self._current_step += 1

        # Actually run the instructions
        # This would need integration with the emulator
        return count

    def stop_replay(self) -> None:
        """Stop replay."""
        self._replay_active = False
        self.timewarp.unfreeze_all()
        logger.info("Replay stopped")

    def fork_branch(self, name: str = "") -> str:
        """Create branch point for exploration."""
        snap_id = self.snapmgr.take(name or f"branch_{len(self._branches)}")
        pc = self.emulator.uc.reg_read(self.emulator.pc_reg)
        self._branches.append((snap_id, pc))
        return snap_id

    def explore_branch(self, branch_idx: int) -> bool:
        """Go to branch point."""
        if branch_idx >= len(self._branches):
            return False

        snap_id, _ = self._branches[branch_idx]
        return self.snapmgr.restore(snap_id, adjust_time=False)

    def list_branches(self) -> list[tuple[str, int]]:
        """List all branch points."""
        return self._branches.copy()
