"""
Anti-Tampering Detection Module for PyUniDbg.

Detects code integrity verification techniques used by protected
binaries, including CRC checksums, hash-based integrity checks,
self-modifying code, and code-section read patterns.

Features:
- CRC32/CRC16 computation pattern detection
- Hash-based integrity verification (MD5, SHA-1, SHA-256)
- Code section read monitoring (memory read hooks on .text)
- Self-modifying code detection via write hooks on executable regions
- Checksum loop detection (heuristic: tight loops reading code bytes)
- Configurable bypass/patch insertion for detected checks
- Integration with the existing AntiAnalysisType taxonomy

Usage:
    from pyunidbg.analysis.anti_tampering import AntiTamperingDetector

    detector = AntiTamperingDetector(emulator)
    detector.monitor()

    # ... run emulation ...

    for finding in detector.findings:
        print(finding)

    # Automatically bypass detected checks
    detector.bypass_all()
"""

from __future__ import annotations

import hashlib
import logging
import struct
import zlib
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum, IntEnum, auto
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Detection classifications
# ---------------------------------------------------------------------------

class TamperCheckType(Enum):
    """Specific integrity-check technique detected."""
    CRC32 = auto()
    CRC16 = auto()
    ADLER32 = auto()
    MD5 = auto()
    SHA1 = auto()
    SHA256 = auto()
    CUSTOM_HASH = auto()
    XOR_CHECKSUM = auto()
    SUM_CHECKSUM = auto()
    CODE_READ_LOOP = auto()
    SELF_MODIFYING_CODE = auto()
    CODE_COMPARISON = auto()
    SECTION_HASH = auto()
    PAGE_GUARD = auto()
    MEMORY_CRC = auto()


class Severity(IntEnum):
    INFO = 1
    LOW = 2
    MEDIUM = 3
    HIGH = 4
    CRITICAL = 5


@dataclass
class TamperFinding:
    """A detected anti-tampering technique."""
    check_type: TamperCheckType
    address: int
    severity: Severity
    description: str
    region_start: int = 0
    region_size: int = 0
    details: dict[str, Any] = field(default_factory=dict)
    bypassed: bool = False
    bypass_patch: bytes = b""

    def __repr__(self) -> str:
        status = " [BYPASSED]" if self.bypassed else ""
        return (
            f"TamperFinding({self.check_type.name} @ {self.address:#x}, "
            f"{self.severity.name}{status}: {self.description})"
        )


# ---------------------------------------------------------------------------
# Pattern signatures for common integrity-check routines
# ---------------------------------------------------------------------------

@dataclass
class ChecksumSignature:
    """Byte-level signature for a known checksum algorithm."""
    name: str
    check_type: TamperCheckType
    arm64_patterns: list[bytes] = field(default_factory=list)
    arm_patterns: list[bytes] = field(default_factory=list)
    x86_patterns: list[bytes] = field(default_factory=list)
    constants: list[int] = field(default_factory=list)


_CRC32_POLY = 0xEDB88320
_CRC32_POLY_BE = 0x04C11DB7

KNOWN_SIGNATURES: list[ChecksumSignature] = [
    ChecksumSignature(
        name="CRC32",
        check_type=TamperCheckType.CRC32,
        constants=[_CRC32_POLY, _CRC32_POLY_BE, 0x82F63B78],
    ),
    ChecksumSignature(
        name="CRC16-CCITT",
        check_type=TamperCheckType.CRC16,
        constants=[0x1021, 0x8408, 0xA001],
    ),
    ChecksumSignature(
        name="MD5",
        check_type=TamperCheckType.MD5,
        constants=[0xD76AA478, 0xE8C7B756, 0x242070DB, 0xC1BDCEEE],
    ),
    ChecksumSignature(
        name="SHA1",
        check_type=TamperCheckType.SHA1,
        constants=[0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0],
    ),
    ChecksumSignature(
        name="SHA256",
        check_type=TamperCheckType.SHA256,
        constants=[0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A],
    ),
]


# ---------------------------------------------------------------------------
# Code-read heuristic tracker
# ---------------------------------------------------------------------------

class CodeReadTracker:
    """
    Tracks memory reads from executable regions to detect
    code-scanning integrity checks.
    """

    def __init__(self, threshold: int = 64):
        self._reads: dict[int, list[int]] = defaultdict(list)
        self._threshold = threshold
        self._exec_ranges: list[tuple[int, int]] = []

    def set_exec_ranges(self, ranges: list[tuple[int, int]]) -> None:
        self._exec_ranges = ranges

    def record_read(self, pc: int, address: int, size: int) -> tuple[int, int, int] | None:
        """Record a memory read; returns (pc, region_start, read_count) if threshold hit."""
        for rstart, rsize in self._exec_ranges:
            if rstart <= address < rstart + rsize:
                self._reads[pc].append(address)
                count = len(self._reads[pc])
                if count == self._threshold:
                    return pc, rstart, count
                return None
        return None

    def get_hotspots(self, min_reads: int = 32) -> list[tuple[int, int]]:
        """Return (pc, count) pairs for PCs that read code memory frequently."""
        return [(pc, len(addrs)) for pc, addrs in self._reads.items()
                if len(addrs) >= min_reads]

    def clear(self) -> None:
        self._reads.clear()


# ---------------------------------------------------------------------------
# Self-modifying code detector
# ---------------------------------------------------------------------------

class SMCDetector:
    """Detect writes to executable memory regions."""

    def __init__(self):
        self._writes: list[tuple[int, int, int]] = []
        self._exec_ranges: list[tuple[int, int]] = []

    def set_exec_ranges(self, ranges: list[tuple[int, int]]) -> None:
        self._exec_ranges = ranges

    def record_write(self, pc: int, address: int, size: int) -> bool:
        """Returns True if the write targets executable memory."""
        for rstart, rsize in self._exec_ranges:
            if rstart <= address < rstart + rsize:
                self._writes.append((pc, address, size))
                return True
        return False

    @property
    def events(self) -> list[tuple[int, int, int]]:
        return list(self._writes)

    def clear(self) -> None:
        self._writes.clear()


# ---------------------------------------------------------------------------
# Main detector
# ---------------------------------------------------------------------------

class AntiTamperingDetector:
    """
    Comprehensive anti-tampering detection engine.

    Monitors emulation to detect:
    - Code integrity checksums (CRC, hash, XOR, sum)
    - Self-modifying code
    - Tight code-reading loops
    - Known crypto constant usage in integrity contexts
    """

    def __init__(self, emulator: Emulator):
        self.emulator = emulator
        self._findings: list[TamperFinding] = []
        self._code_tracker = CodeReadTracker()
        self._smc_detector = SMCDetector()
        self._hooks: list[Any] = []
        self._monitoring = False
        self._constant_hits: dict[int, list[int]] = defaultdict(list)

    @property
    def findings(self) -> list[TamperFinding]:
        return list(self._findings)

    @property
    def is_monitoring(self) -> bool:
        return self._monitoring

    # ------------------------------------------------------------------
    # Static analysis — scan loaded code for known constants
    # ------------------------------------------------------------------

    def scan_constants(
        self,
        regions: list[tuple[int, int]] | None = None,
    ) -> list[TamperFinding]:
        """
        Scan memory for constants associated with integrity-check algorithms.
        """
        if regions is None:
            regions = self._get_exec_regions()

        found: list[TamperFinding] = []
        for base, size in regions:
            try:
                data = self.emulator.memory.read(base, size)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                continue

            for sig in KNOWN_SIGNATURES:
                for const in sig.constants:
                    for width in (4,):
                        needle = struct.pack("<I", const & 0xFFFFFFFF)
                        idx = 0
                        while idx < len(data):
                            pos = data.find(needle, idx)
                            if pos == -1:
                                break
                            addr = base + pos
                            self._constant_hits[const].append(addr)
                            finding = TamperFinding(
                                check_type=sig.check_type,
                                address=addr,
                                severity=Severity.MEDIUM,
                                description=(
                                    f"{sig.name} constant {const:#010x} found at {addr:#x}"
                                ),
                                details={"constant": const, "algorithm": sig.name},
                            )
                            found.append(finding)
                            self._findings.append(finding)
                            idx = pos + width

        logger.info("Constant scan found %d potential integrity-check references", len(found))
        return found

    # ------------------------------------------------------------------
    # Dynamic monitoring
    # ------------------------------------------------------------------

    def monitor(self, code_read_threshold: int = 64) -> None:
        """
        Install hooks to monitor for integrity checks during emulation.
        """
        if self._monitoring:
            return
        self._monitoring = True

        exec_ranges = self._get_exec_regions()
        self._code_tracker.set_exec_ranges(exec_ranges)
        self._code_tracker._threshold = code_read_threshold
        self._smc_detector.set_exec_ranges(exec_ranges)

        from unicorn import UC_HOOK_MEM_READ, UC_HOOK_MEM_WRITE

        for rstart, rsize in exec_ranges:
            def _on_read(uc, access, address, size, value, user_data, _rs=rstart):
                pc = self.emulator.cpu.pc
                hit = self._code_tracker.record_read(pc, address, size)
                if hit:
                    self._report_code_read_loop(*hit)

            handle = self.emulator._uc.hook_add(
                UC_HOOK_MEM_READ, _on_read, begin=rstart, end=rstart + rsize)
            self._hooks.append(handle)

            def _on_write(uc, access, address, size, value, user_data, _rs=rstart):
                pc = self.emulator.cpu.pc
                if self._smc_detector.record_write(pc, address, size):
                    self._report_smc(pc, address, size)

            handle = self.emulator._uc.hook_add(
                UC_HOOK_MEM_WRITE, _on_write, begin=rstart, end=rstart + rsize)
            self._hooks.append(handle)

        self._install_checksum_api_hooks()
        logger.info("Anti-tampering monitoring active on %d regions", len(exec_ranges))

    def stop_monitoring(self) -> None:
        """Remove all monitoring hooks."""
        for handle in self._hooks:
            try:
                self.emulator._uc.hook_del(handle)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        self._hooks.clear()
        self._monitoring = False

    # ------------------------------------------------------------------
    # Bypass
    # ------------------------------------------------------------------

    def bypass_all(self) -> int:
        """
        Attempt to bypass all detected integrity checks by patching.

        Returns the number of checks successfully bypassed.
        """
        count = 0
        for finding in self._findings:
            if finding.bypassed:
                continue
            if self._bypass_finding(finding):
                count += 1
        logger.info("Bypassed %d / %d integrity checks", count, len(self._findings))
        return count

    def bypass_at(self, address: int) -> bool:
        """Bypass a specific finding by address."""
        for f in self._findings:
            if f.address == address:
                return self._bypass_finding(f)
        return False

    def _bypass_finding(self, finding: TamperFinding) -> bool:
        from ..core.constants import Architecture
        arch = self.emulator.config.arch

        if finding.check_type == TamperCheckType.SELF_MODIFYING_CODE:
            return False

        if finding.check_type == TamperCheckType.CODE_READ_LOOP:
            if arch == Architecture.ARM64:
                nop = b"\x1f\x20\x03\xd5"
            elif arch == Architecture.ARM:
                nop = b"\x00\xf0\x20\xe3"
            elif arch in (Architecture.X86, Architecture.X86_64):
                nop = b"\x90"
            else:
                return False
            try:
                self.emulator.memory.write(finding.address, nop)
                finding.bypassed = True
                finding.bypass_patch = nop
                return True
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                return False

        if finding.check_type in (
            TamperCheckType.CRC32, TamperCheckType.CRC16,
            TamperCheckType.MD5, TamperCheckType.SHA1,
            TamperCheckType.SHA256, TamperCheckType.CUSTOM_HASH,
            TamperCheckType.CODE_COMPARISON,
        ):
            from ..core.hooks import Hook, HookAction, HookType

            def _skip_check(emu, addr, size):
                emu.cpu.set_return_value(1)
                return HookAction.SKIP

            hook = Hook(
                hook_type=HookType.ADDRESS,
                callback=_skip_check,
                address=finding.address,
                name=f"bypass_{finding.check_type.name}_{finding.address:#x}",
            )
            self.emulator.hook.add_hook(hook)
            finding.bypassed = True
            return True

        return False

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _report_code_read_loop(self, pc: int, region_start: int, count: int) -> None:
        finding = TamperFinding(
            check_type=TamperCheckType.CODE_READ_LOOP,
            address=pc,
            severity=Severity.HIGH,
            description=(
                f"Code-reading loop at {pc:#x} — {count} reads from "
                f"executable region {region_start:#x}"
            ),
            region_start=region_start,
            details={"read_count": count},
        )
        self._findings.append(finding)
        logger.warning("Detected code-reading loop @ %#x (%d reads)", pc, count)

    def _report_smc(self, pc: int, target: int, size: int) -> None:
        finding = TamperFinding(
            check_type=TamperCheckType.SELF_MODIFYING_CODE,
            address=pc,
            severity=Severity.CRITICAL,
            description=(
                f"Self-modifying code: PC {pc:#x} writes {size} bytes "
                f"to executable address {target:#x}"
            ),
            details={"target_address": target, "write_size": size},
        )
        self._findings.append(finding)
        logger.warning("SMC detected: %#x -> %#x (%d bytes)", pc, target, size)

    def _install_checksum_api_hooks(self) -> None:
        """Hook well-known checksum/hash API functions if they exist."""
        api_map = {
            "crc32": TamperCheckType.CRC32,
            "adler32": TamperCheckType.ADLER32,
            "MD5_Init": TamperCheckType.MD5,
            "MD5_Update": TamperCheckType.MD5,
            "SHA1_Init": TamperCheckType.SHA1,
            "SHA1_Update": TamperCheckType.SHA1,
            "SHA256_Init": TamperCheckType.SHA256,
            "SHA256_Update": TamperCheckType.SHA256,
            "CC_MD5": TamperCheckType.MD5,
            "CC_SHA1": TamperCheckType.SHA1,
            "CC_SHA256": TamperCheckType.SHA256,
        }
        for func_name, check_type in api_map.items():
            addr = self.emulator.get_symbol(func_name)
            if addr is not None:
                from ..core.hooks import Hook, HookType

                def _api_hook(emu, address, size, _ct=check_type, _fn=func_name):
                    finding = TamperFinding(
                        check_type=_ct,
                        address=address,
                        severity=Severity.HIGH,
                        description=f"Hash/checksum API {_fn} called at {address:#x}",
                    )
                    self._findings.append(finding)
                    logger.info("Integrity API call: %s @ %#x", _fn, address)

                hook = Hook(
                    hook_type=HookType.ADDRESS,
                    callback=_api_hook,
                    address=addr,
                    name=f"tamper_detect_{func_name}",
                )
                self.emulator.hook.add_hook(hook)

    def _get_exec_regions(self) -> list[tuple[int, int]]:
        regions = []
        for r in self.emulator.memory.get_regions():
            if r.protection & 4:
                regions.append((r.start, r.size))
        return regions

    # ------------------------------------------------------------------
    # Utility: compute reference checksums for a code region
    # ------------------------------------------------------------------

    def compute_reference_crc32(self, address: int, size: int) -> int:
        """Compute CRC32 of a memory region (for comparison)."""
        data = self.emulator.memory.read(address, size)
        return zlib.crc32(data) & 0xFFFFFFFF

    def compute_reference_sha256(self, address: int, size: int) -> str:
        data = self.emulator.memory.read(address, size)
        return hashlib.sha256(data).hexdigest()

    def verify_region_integrity(self, address: int, size: int, expected_crc: int) -> bool:
        """Check whether a code region matches its expected CRC32."""
        actual = self.compute_reference_crc32(address, size)
        return actual == expected_crc

    def reset(self) -> None:
        self.stop_monitoring()
        self._findings.clear()
        self._code_tracker.clear()
        self._smc_detector.clear()
        self._constant_hits.clear()


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------

def create_anti_tampering_detector(emulator: Emulator) -> AntiTamperingDetector:
    return AntiTamperingDetector(emulator)


__all__ = [
    "AntiTamperingDetector",
    "TamperCheckType",
    "TamperFinding",
    "Severity",
    "ChecksumSignature",
    "CodeReadTracker",
    "SMCDetector",
    "KNOWN_SIGNATURES",
    "create_anti_tampering_detector",
]
