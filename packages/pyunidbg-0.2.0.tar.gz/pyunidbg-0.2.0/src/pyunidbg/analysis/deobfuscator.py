"""
Deobfuscator - Pattern-based code deobfuscation.

Detects and simplifies common obfuscation patterns:
- Opaque predicates
- Dead code
- Control flow flattening
- String encryption
- Constant folding
"""

import logging
import re
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.emulator import Emulator

from .disasm import DisasmOutput, Disassembler

logger = logging.getLogger(__name__)


class ObfuscationType(Enum):
    """Types of obfuscation patterns."""
    OPAQUE_PREDICATE = auto()      # Always true/false branches
    DEAD_CODE = auto()             # Unreachable code
    JUNK_CODE = auto()             # NOP-equivalent instructions
    CONSTANT_FOLDING = auto()      # Computable constants
    STRING_ENCRYPTION = auto()     # Encrypted strings
    CONTROL_FLOW_FLAT = auto()     # Flattened control flow
    INDIRECT_BRANCH = auto()       # Computed branches
    STACK_MANIPULATION = auto()    # Stack-based obfuscation
    REGISTER_REASSIGN = auto()     # Unnecessary register moves
    ARITHMETIC_ENCODING = auto()   # Encoded arithmetic (x*2 -> x+x)


@dataclass
class ObfuscationPattern:
    """Detected obfuscation pattern."""
    type: ObfuscationType
    address: int
    size: int                      # Number of bytes/instructions
    description: str
    original: list[str]            # Original instructions
    simplified: str                # Simplified representation
    confidence: float              # 0.0 to 1.0

    def __str__(self) -> str:
        return f"[{self.type.name}] 0x{self.address:x}: {self.description}"


@dataclass
class DeobfuscatedBlock:
    """Deobfuscated code block."""
    start_address: int
    end_address: int
    original_insns: list[DisasmOutput]
    simplified_insns: list[str]
    patterns_found: list[ObfuscationPattern]

    def to_pseudo_c(self) -> str:
        """Get pseudo-C representation."""
        return '\n'.join(self.simplified_insns)


class PatternMatcher:
    """Pattern matching for obfuscation detection."""

    # Junk instruction patterns (NOP-equivalent)
    JUNK_PATTERNS = [
        # mov x, x
        (r'^mov\s+(\w+),\s*\1$', "Self-move"),
        # xor x, x, x (clear register is not junk, but xor with same value is)
        # add x, x, #0
        (r'^add\s+(\w+),\s*\1,\s*#0$', "Add zero"),
        # sub x, x, #0
        (r'^sub\s+(\w+),\s*\1,\s*#0$', "Subtract zero"),
        # mul x, x, #1
        (r'^mul\s+(\w+),\s*\1,\s*#1$', "Multiply one"),
        # orr x, x, #0
        (r'^orr\s+(\w+),\s*\1,\s*#0$', "Or zero"),
        # and x, x, #-1
        (r'^and\s+(\w+),\s*\1,\s*#-1$', "And all-ones"),
        # lsl x, x, #0
        (r'^lsl\s+(\w+),\s*\1,\s*#0$', "Shift zero"),
        # nop
        (r'^nop$', "NOP"),
    ]

    # Opaque predicate patterns
    OPAQUE_PATTERNS = [
        # x*x >= 0 (always true for integers)
        (r'mul.*cmp.*b\.lt', "Square comparison"),
        # x & 1 == x & 1 (always true)
        (r'and.*cmp.*b\.eq', "Self-comparison"),
    ]

    # Dead code patterns (unreachable after unconditional branch)
    DEAD_CODE_INDICATORS = {'b', 'ret', 'br'}

    def __init__(self):
        self._compiled_junk = [(re.compile(p, re.IGNORECASE), d) for p, d in self.JUNK_PATTERNS]

    def is_junk(self, mnemonic: str, operands: str) -> tuple[bool, str]:
        """Check if instruction is junk (NOP-equivalent)."""
        full_insn = f"{mnemonic} {operands}"

        for pattern, desc in self._compiled_junk:
            if pattern.match(full_insn):
                return True, desc

        return False, ""

    def detect_constant_sequence(self, insns: list[DisasmOutput]) -> tuple[int, int, int] | None:
        """
        Detect sequences that compute a constant value.
        
        Returns:
            Tuple of (start_idx, end_idx, computed_value) or None
        """
        # Simple pattern: mov + arithmetic with constants
        if len(insns) < 2:
            return None

        # Look for mov followed by arithmetic
        for i, insn in enumerate(insns[:-1]):
            if insn.mnemonic.lower() in ('mov', 'movz'):
                # Check if followed by constant operations
                value = self._extract_immediate(insn.operands)
                if value is None:
                    continue

                # Track through subsequent operations
                reg = insn.operands.split(',')[0].strip()
                for j in range(i + 1, min(i + 5, len(insns))):
                    next_insn = insns[j]
                    if reg not in next_insn.operands:
                        break

                    imm = self._extract_immediate(next_insn.operands)
                    if imm is None:
                        break

                    mnem = next_insn.mnemonic.lower()
                    if mnem == 'add':
                        value += imm
                    elif mnem == 'sub':
                        value -= imm
                    elif mnem == 'eor':
                        value ^= imm
                    elif mnem == 'orr':
                        value |= imm
                    elif mnem == 'and':
                        value &= imm
                    else:
                        break

                    if j > i + 1:
                        return (i, j + 1, value)

        return None

    def _extract_immediate(self, operands: str) -> int | None:
        """Extract immediate value from operands."""
        match = re.search(r'#(0x[0-9a-fA-F]+|\d+)', operands)
        if match:
            val = match.group(1)
            return int(val, 16) if val.startswith('0x') else int(val)
        return None


class Deobfuscator:
    """
    Pattern-based code deobfuscator.
    
    Analyzes code to detect and simplify obfuscation:
    - Identifies obfuscation patterns
    - Removes junk/dead code
    - Simplifies constant computations
    - Reconstructs control flow
    
    Example:
        deobf = Deobfuscator(emulator)
        
        # Analyze function
        result = deobf.analyze(0x1000, 0x2000)
        
        # Get detected patterns
        for pattern in result.patterns_found:
            print(pattern)
        
        # Get simplified pseudo-C
        print(result.to_pseudo_c())
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.disasm = Disassembler(emulator)
        self.matcher = PatternMatcher()

        # Detection settings
        self.detect_junk = True
        self.detect_dead_code = True
        self.detect_constant_folding = True
        self.detect_opaque_predicates = True

        # Statistics
        self._stats = {
            'junk_removed': 0,
            'dead_code_removed': 0,
            'constants_folded': 0,
            'patterns_detected': 0,
        }

    @property
    def stats(self) -> dict:
        return self._stats.copy()

    def analyze(self, start: int, end: int) -> DeobfuscatedBlock:
        """
        Analyze code range for obfuscation.
        
        Args:
            start: Start address
            end: End address
            
        Returns:
            DeobfuscatedBlock with analysis results
        """
        # Disassemble
        insns = self.disasm.disasm_range(start, end)

        patterns: list[ObfuscationPattern] = []
        simplified: list[str] = []
        skip_indices: set[int] = set()

        i = 0
        while i < len(insns):
            if i in skip_indices:
                i += 1
                continue

            insn = insns[i]

            # Check for junk code
            if self.detect_junk:
                is_junk, junk_desc = self.matcher.is_junk(insn.mnemonic, insn.operands)
                if is_junk:
                    patterns.append(ObfuscationPattern(
                        type=ObfuscationType.JUNK_CODE,
                        address=insn.address,
                        size=insn.size,
                        description=junk_desc,
                        original=[insn.to_assembly()],
                        simplified="/* junk removed */",
                        confidence=1.0,
                    ))
                    self._stats['junk_removed'] += 1
                    i += 1
                    continue

            # Check for constant folding
            if self.detect_constant_folding:
                result = self.matcher.detect_constant_sequence(insns[i:i+6])
                if result:
                    start_idx, end_idx, value = result
                    end_idx += i

                    orig = [insns[j].to_assembly() for j in range(i, end_idx)]
                    reg = insns[i].operands.split(',')[0].strip()
                    simp = f"{reg} = 0x{value:x}"

                    patterns.append(ObfuscationPattern(
                        type=ObfuscationType.CONSTANT_FOLDING,
                        address=insn.address,
                        size=sum(insns[j].size for j in range(i, end_idx)),
                        description=f"Constant computation: {value}",
                        original=orig,
                        simplified=simp,
                        confidence=0.9,
                    ))

                    simplified.append(simp)
                    self._stats['constants_folded'] += 1

                    for j in range(i, end_idx):
                        skip_indices.add(j)
                    i = end_idx
                    continue

            # Check for dead code (after unconditional branch)
            if self.detect_dead_code and i > 0:
                prev = insns[i - 1]
                if prev.mnemonic.lower() in self.matcher.DEAD_CODE_INDICATORS:
                    # Check if this is a branch target
                    # For now, simple heuristic
                    if not self._is_branch_target(insn.address, insns):
                        patterns.append(ObfuscationPattern(
                            type=ObfuscationType.DEAD_CODE,
                            address=insn.address,
                            size=insn.size,
                            description="Unreachable after unconditional branch",
                            original=[insn.to_assembly()],
                            simplified="/* dead code */",
                            confidence=0.7,
                        ))
                        self._stats['dead_code_removed'] += 1
                        i += 1
                        continue

            # Not obfuscated, keep instruction
            simplified.append(insn.pseudo_c or insn.to_assembly())
            i += 1

        self._stats['patterns_detected'] += len(patterns)

        return DeobfuscatedBlock(
            start_address=start,
            end_address=end,
            original_insns=insns,
            simplified_insns=simplified,
            patterns_found=patterns,
        )

    def analyze_function(self, address: int, max_insns: int = 1000) -> DeobfuscatedBlock:
        """
        Analyze function for obfuscation.
        
        Args:
            address: Function start address
            max_insns: Maximum instructions to analyze
            
        Returns:
            DeobfuscatedBlock with analysis results
        """
        insns = self.disasm.disasm_function(address, max_insns)
        if not insns:
            return DeobfuscatedBlock(
                start_address=address,
                end_address=address,
                original_insns=[],
                simplified_insns=[],
                patterns_found=[],
            )

        end = insns[-1].address + insns[-1].size
        return self.analyze(address, end)

    def _is_branch_target(self, address: int, insns: list[DisasmOutput]) -> bool:
        """Check if address is a branch target."""
        addr_str = f"0x{address:x}"
        addr_str_short = f"{address:x}"

        for insn in insns:
            if insn.mnemonic.lower().startswith('b'):
                if addr_str in insn.operands or addr_str_short in insn.operands:
                    return True

        return False

    def detect_string_encryption(self, start: int, end: int) -> list[ObfuscationPattern]:
        """
        Detect encrypted string patterns.
        
        Looks for:
        - XOR decryption loops
        - Character-by-character building
        - Base64/encoding patterns
        """
        patterns = []
        insns = self.disasm.disasm_range(start, end)

        # Look for XOR loops
        for i, insn in enumerate(insns):
            if insn.mnemonic.lower() == 'eor':
                # Check if in a loop pattern
                # Look for branch back within 10 instructions
                for j in range(i + 1, min(i + 10, len(insns))):
                    if insns[j].mnemonic.lower().startswith('b'):
                        target = self._extract_branch_target(insns[j])
                        if target and target <= insn.address:
                            patterns.append(ObfuscationPattern(
                                type=ObfuscationType.STRING_ENCRYPTION,
                                address=insn.address,
                                size=insns[j].address - insn.address + insns[j].size,
                                description="XOR decryption loop",
                                original=[insns[k].to_assembly() for k in range(i, j + 1)],
                                simplified="decrypted_string = xor_decrypt(data, key)",
                                confidence=0.8,
                            ))
                            break

        return patterns

    def _extract_branch_target(self, insn: DisasmOutput) -> int | None:
        """Extract branch target address."""
        match = re.search(r'#?(0x[0-9a-fA-F]+)', insn.operands)
        if match:
            return int(match.group(1), 16)
        return None

    def simplify_arithmetic(self, insns: list[DisasmOutput]) -> list[str]:
        """
        Simplify arithmetic obfuscation.
        
        Converts patterns like:
        - x + x -> x * 2
        - x ^ x -> 0
        - x - x -> 0
        - (x + y) - y -> x
        """
        simplified = []

        for insn in insns:
            mnem = insn.mnemonic.lower()
            ops = [o.strip() for o in insn.operands.split(',')]

            if len(ops) >= 3:
                # x ^ x -> 0
                if mnem == 'eor' and ops[1] == ops[2]:
                    simplified.append(f"{ops[0]} = 0")
                    continue

                # x - x -> 0
                if mnem == 'sub' and ops[1] == ops[2]:
                    simplified.append(f"{ops[0]} = 0")
                    continue

                # x + x -> x * 2
                if mnem == 'add' and ops[1] == ops[2]:
                    simplified.append(f"{ops[0]} = {ops[1]} * 2")
                    continue

            # Default: use pseudo-C translation
            simplified.append(insn.pseudo_c or insn.to_assembly())

        return simplified

    def print_report(self, block: DeobfuscatedBlock) -> None:
        """Print analysis report."""
        print("=== Deobfuscation Report ===")
        print(f"Address range: 0x{block.start_address:x} - 0x{block.end_address:x}")
        print(f"Original instructions: {len(block.original_insns)}")
        print(f"Simplified instructions: {len(block.simplified_insns)}")
        print(f"Patterns detected: {len(block.patterns_found)}")
        print()

        if block.patterns_found:
            print("Detected Patterns:")
            for pattern in block.patterns_found:
                print(f"  {pattern}")
            print()

        print("Simplified Code:")
        for line in block.simplified_insns:
            print(f"  {line}")
