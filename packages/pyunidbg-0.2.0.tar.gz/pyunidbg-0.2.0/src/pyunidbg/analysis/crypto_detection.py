"""
Cryptographic constant detector for native ELF libraries.

Scans binary data sections for well-known cryptographic algorithm constants
(AES, DES, MD5, SHA-1, SHA-256, RC4) to identify crypto usage without
executing the binary.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import Any

# ---------------------------------------------------------------------------
# AES constants
# ---------------------------------------------------------------------------
# AES forward S-box (first 16 bytes — unique enough for detection)
_AES_SBOX_FWD = bytes([
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5,
    0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
])
# AES inverse S-box (first 16 bytes)
_AES_SBOX_INV = bytes([
    0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38,
    0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
])
# AES Rcon table (10 values)
_AES_RCON = bytes([0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36])

# ---------------------------------------------------------------------------
# DES constants — partial SP-box constants (first 8 bytes of the E-table)
# ---------------------------------------------------------------------------
_DES_SP1_PREFIX = struct.pack(">IIII", 0x01010400, 0x00000000, 0x00010000, 0x01010404)

# ---------------------------------------------------------------------------
# MD5 init constants (little-endian 32-bit)
# ---------------------------------------------------------------------------
_MD5_INIT = struct.pack("<IIII", 0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476)

# ---------------------------------------------------------------------------
# SHA-1 init constants
# ---------------------------------------------------------------------------
_SHA1_INIT = struct.pack(">IIIII",
    0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0)

# SHA-1 round constants K0-K3
_SHA1_K = struct.pack(">IIII", 0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xCA62C1D6)

# ---------------------------------------------------------------------------
# SHA-256 init constants (first 4 of 8)
# ---------------------------------------------------------------------------
_SHA256_INIT = struct.pack(">IIII",
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a)

# SHA-256 first round constant (K[0])
_SHA256_K0 = struct.pack(">I", 0x428a2f98)

# ---------------------------------------------------------------------------
# RC4 detection heuristic — PRGA initialises S[0..255] sequentially.
# We look for the byte sequence 0x00,0x01,0x02,...,0x0f as a prefix hint.
# ---------------------------------------------------------------------------
_RC4_SBOX_PREFIX = bytes(range(16))

# ---------------------------------------------------------------------------
# SIGNATURES registry
# ---------------------------------------------------------------------------
@dataclass
class _Signature:
    name: str
    algorithm: str
    needle: bytes
    confidence: float  # 0.0–1.0
    description: str


_SIGNATURES: list[_Signature] = [
    _Signature("AES_SBOX_FWD",  "AES",    _AES_SBOX_FWD,    0.95,
               "AES forward S-box prefix"),
    _Signature("AES_SBOX_INV",  "AES",    _AES_SBOX_INV,    0.95,
               "AES inverse S-box prefix"),
    _Signature("AES_RCON",      "AES",    _AES_RCON,         0.85,
               "AES Rcon table"),
    _Signature("DES_SP1",       "DES",    _DES_SP1_PREFIX,   0.80,
               "DES SP-box prefix"),
    _Signature("MD5_INIT",      "MD5",    _MD5_INIT,         0.92,
               "MD5 initial hash values"),
    _Signature("SHA1_INIT",     "SHA-1",  _SHA1_INIT,        0.92,
               "SHA-1 initial hash values"),
    _Signature("SHA1_K",        "SHA-1",  _SHA1_K,           0.88,
               "SHA-1 round constants K0-K3"),
    _Signature("SHA256_INIT",   "SHA-256", _SHA256_INIT,     0.92,
               "SHA-256 initial hash values"),
    _Signature("SHA256_K0",     "SHA-256", _SHA256_K0,       0.72,
               "SHA-256 first round constant K[0]"),
    _Signature("RC4_SBOX",      "RC4",    _RC4_SBOX_PREFIX,  0.70,
               "RC4 S-box initialization sequence prefix"),
]


@dataclass
class CryptoMatch:
    algorithm: str
    confidence: float
    address: int
    signature_name: str
    evidence: str    # hex of matched bytes
    section: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "algorithm": self.algorithm,
            "confidence": round(self.confidence, 2),
            "address": hex(self.address),
            "signature": self.signature_name,
            "evidence": self.evidence,
            "section": self.section,
        }


class CryptoDetector:
    """
    Scan a native library file for cryptographic algorithm constants.

    Parameters
    ----------
    library_path:
        Path to the ELF binary on the host filesystem.
    """

    def __init__(self, library_path: str):
        self._path = library_path

    def scan(self) -> list[CryptoMatch]:
        """Return a list of :class:`CryptoMatch` objects found in the binary."""
        try:
            import lief
        except ImportError:
            return []

        elf = lief.parse(self._path)
        if elf is None:
            return []

        matches: list[CryptoMatch] = []

        for sec in elf.sections:
            if sec.size == 0:
                continue
            try:
                raw = bytes(sec.content)
            except Exception:
                continue

            base = sec.virtual_address
            sec_name = sec.name

            for sig in _SIGNATURES:
                idx = 0
                while idx < len(raw):
                    pos = raw.find(sig.needle, idx)
                    if pos == -1:
                        break
                    abs_addr = base + pos
                    evidence = raw[pos: pos + len(sig.needle)].hex()
                    matches.append(CryptoMatch(
                        algorithm=sig.algorithm,
                        confidence=sig.confidence,
                        address=abs_addr,
                        signature_name=sig.name,
                        evidence=evidence,
                        section=sec_name,
                    ))
                    idx = pos + len(sig.needle)

        # Deduplicate: keep highest-confidence match per (algorithm, address)
        best: dict[tuple[str, int], CryptoMatch] = {}
        for m in matches:
            key = (m.algorithm, m.address)
            if key not in best or m.confidence > best[key].confidence:
                best[key] = m

        return sorted(best.values(), key=lambda x: (-x.confidence, x.address))
