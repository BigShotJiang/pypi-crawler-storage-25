"""
Code Coverage Tracking for PyUniDbg.

Tracks executed instructions, basic blocks, and functions during emulation.
Supports exporting to various formats for visualization in tools like
IDA Pro (Lighthouse), Ghidra, Binary Ninja, etc.

Usage:
    from pyunidbg import Emulator
    from pyunidbg.analysis import CoverageTracker
    
    emu = Emulator(arch='arm64')
    coverage = CoverageTracker(emu)
    coverage.start()
    
    emu.call_function(addr)
    
    coverage.stop()
    coverage.export_drcov("trace.drcov")  # For Lighthouse
    coverage.export_lcov("trace.lcov")     # For lcov/genhtml
"""

import logging
import struct
import time
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING, BinaryIO

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


class CoverageMode(Enum):
    """Coverage tracking granularity."""
    INSTRUCTION = "instruction"  # Track every instruction
    BASIC_BLOCK = "basic_block"  # Track basic blocks only
    FUNCTION = "function"        # Track function entries only
    EDGE = "edge"                # Track control flow edges


@dataclass
class CoverageEntry:
    """Single coverage entry."""
    address: int
    size: int
    hit_count: int = 1
    module_id: int = 0

    def __hash__(self):
        return hash((self.address, self.module_id))


@dataclass
class BasicBlock:
    """Basic block information."""
    start: int
    end: int
    size: int
    instruction_count: int = 0
    hit_count: int = 0
    module_id: int = 0

    def __hash__(self):
        return hash((self.start, self.module_id))


@dataclass
class ModuleInfo:
    """Module/library information for coverage."""
    id: int
    name: str
    base: int
    size: int
    path: str = ""
    checksum: int = 0
    timestamp: int = 0


@dataclass
class CoverageStats:
    """Coverage statistics."""
    total_instructions: int = 0
    unique_instructions: int = 0
    total_blocks: int = 0
    unique_blocks: int = 0
    total_functions: int = 0
    unique_functions: int = 0
    total_edges: int = 0
    unique_edges: int = 0
    start_time: float = 0.0
    end_time: float = 0.0

    @property
    def duration(self) -> float:
        """Get duration in seconds."""
        return self.end_time - self.start_time


class CoverageTracker:
    """
    Tracks code coverage during emulation.
    
    Supports multiple granularities (instruction, basic block, function)
    and export to various formats for visualization.
    """

    # DrCov file format constants
    DRCOV_VERSION = 2
    DRCOV_FLAVOR = "drcov"

    def __init__(
        self,
        emulator: 'Emulator',
        mode: CoverageMode = CoverageMode.BASIC_BLOCK
    ):
        """
        Initialize coverage tracker.
        
        Args:
            emulator: PyUniDbg emulator instance
            mode: Coverage tracking granularity
        """
        self.emulator = emulator
        self.mode = mode

        # Coverage data
        self._instructions: dict[int, CoverageEntry] = {}
        self._blocks: dict[int, BasicBlock] = {}
        self._functions: set[int] = set()
        self._edges: set[tuple[int, int]] = set()

        # Module tracking
        self._modules: dict[int, ModuleInfo] = {}
        self._next_module_id = 0

        # State
        self._active = False
        self._hook_handle = None
        self._block_hook_handle = None
        self._stats = CoverageStats()

        # Last address for edge tracking
        self._last_address: int | None = None

    @property
    def is_active(self) -> bool:
        """Check if coverage tracking is active."""
        return self._active

    @property
    def stats(self) -> CoverageStats:
        """Get coverage statistics."""
        self._update_stats()
        return self._stats

    def add_module(
        self,
        name: str,
        base: int,
        size: int,
        path: str = ""
    ) -> int:
        """
        Add a module for coverage tracking.
        
        Args:
            name: Module name
            base: Base address
            size: Module size
            path: Optional file path
            
        Returns:
            Module ID
        """
        module_id = self._next_module_id
        self._next_module_id += 1

        self._modules[module_id] = ModuleInfo(
            id=module_id,
            name=name,
            base=base,
            size=size,
            path=path or name,
            timestamp=int(time.time())
        )

        logger.debug(f"Added module {name} at 0x{base:x}, size=0x{size:x}")
        return module_id

    def start(self):
        """Start coverage tracking."""
        if self._active:
            return

        self._active = True
        self._stats.start_time = time.time()
        self._last_address = None

        # Install hooks based on mode
        if self.mode == CoverageMode.INSTRUCTION:
            self._install_instruction_hook()
        else:
            self._install_block_hook()

        logger.info(f"Coverage tracking started (mode={self.mode.value})")

    def stop(self):
        """Stop coverage tracking."""
        if not self._active:
            return

        self._active = False
        self._stats.end_time = time.time()

        # Remove hooks
        self._remove_hooks()

        self._update_stats()
        logger.info(
            f"Coverage tracking stopped: {self._stats.unique_blocks} blocks, "
            f"{self._stats.unique_instructions} instructions"
        )

    def reset(self):
        """Reset coverage data."""
        self._instructions.clear()
        self._blocks.clear()
        self._functions.clear()
        self._edges.clear()
        self._last_address = None
        self._stats = CoverageStats()
        logger.debug("Coverage data reset")

    def _install_instruction_hook(self):
        """Install instruction-level hook."""
        try:
            from unicorn import UC_HOOK_CODE

            def code_hook(uc, address, size, user_data):
                self._record_instruction(address, size)

            self._hook_handle = self.emulator._uc.hook_add(
                UC_HOOK_CODE,
                code_hook,
                None
            )
        except Exception as e:
            logger.error(f"Failed to install instruction hook: {e}")

    def _install_block_hook(self):
        """Install basic block hook."""
        try:
            from unicorn import UC_HOOK_BLOCK

            def block_hook(uc, address, size, user_data):
                self._record_block(address, size)

            self._block_hook_handle = self.emulator._uc.hook_add(
                UC_HOOK_BLOCK,
                block_hook,
                None
            )
        except Exception as e:
            logger.error(f"Failed to install block hook: {e}")

    def _remove_hooks(self):
        """Remove all hooks."""
        try:
            if self._hook_handle is not None:
                self.emulator._uc.hook_del(self._hook_handle)
                self._hook_handle = None
            if self._block_hook_handle is not None:
                self.emulator._uc.hook_del(self._block_hook_handle)
                self._block_hook_handle = None
        except Exception as e:
            logger.debug(f"Error removing hooks: {e}")

    def _record_instruction(self, address: int, size: int):
        """Record an executed instruction."""
        self._stats.total_instructions += 1

        if address in self._instructions:
            self._instructions[address].hit_count += 1
        else:
            module_id = self._find_module(address)
            self._instructions[address] = CoverageEntry(
                address=address,
                size=size,
                module_id=module_id
            )

        # Track edges
        if self.mode == CoverageMode.EDGE and self._last_address is not None:
            self._edges.add((self._last_address, address))
        self._last_address = address

    def _record_block(self, address: int, size: int):
        """Record an executed basic block."""
        self._stats.total_blocks += 1

        if address in self._blocks:
            self._blocks[address].hit_count += 1
        else:
            module_id = self._find_module(address)
            self._blocks[address] = BasicBlock(
                start=address,
                end=address + size,
                size=size,
                hit_count=1,
                module_id=module_id
            )

        # Track edges
        if self.mode == CoverageMode.EDGE and self._last_address is not None:
            self._edges.add((self._last_address, address))
        self._last_address = address

    def _find_module(self, address: int) -> int:
        """Find module ID for an address."""
        for module_id, module in self._modules.items():
            if module.base <= address < module.base + module.size:
                return module_id
        return 0

    def _update_stats(self):
        """Update coverage statistics."""
        self._stats.unique_instructions = len(self._instructions)
        self._stats.unique_blocks = len(self._blocks)
        self._stats.unique_functions = len(self._functions)
        self._stats.unique_edges = len(self._edges)

    # === Coverage Queries ===

    def get_coverage_percentage(self, module_id: int | None = None) -> float:
        """
        Get coverage percentage for a module.
        
        Args:
            module_id: Module ID (None for all modules)
            
        Returns:
            Coverage percentage (0-100)
        """
        if module_id is not None and module_id in self._modules:
            module = self._modules[module_id]
            covered = sum(
                1 for b in self._blocks.values()
                if b.module_id == module_id
            )
            # Rough estimate based on average block size
            estimated_blocks = module.size // 16
            return (covered / max(estimated_blocks, 1)) * 100

        return 0.0

    def get_uncovered_ranges(
        self,
        module_id: int,
        min_gap: int = 16
    ) -> list[tuple[int, int]]:
        """
        Get uncovered address ranges in a module.
        
        Args:
            module_id: Module ID
            min_gap: Minimum gap size to report
            
        Returns:
            List of (start, end) tuples
        """
        if module_id not in self._modules:
            return []

        module = self._modules[module_id]
        covered = sorted([
            b.start for b in self._blocks.values()
            if b.module_id == module_id
        ])

        if not covered:
            return [(module.base, module.base + module.size)]

        gaps = []

        # Gap at start
        if covered[0] > module.base + min_gap:
            gaps.append((module.base, covered[0]))

        # Gaps between blocks
        for i in range(len(covered) - 1):
            gap_start = covered[i] + self._blocks[covered[i]].size
            gap_end = covered[i + 1]
            if gap_end - gap_start >= min_gap:
                gaps.append((gap_start, gap_end))

        # Gap at end
        last = covered[-1]
        last_end = last + self._blocks[last].size
        if module.base + module.size - last_end >= min_gap:
            gaps.append((last_end, module.base + module.size))

        return gaps

    def get_hot_blocks(self, top_n: int = 10) -> list[BasicBlock]:
        """
        Get most frequently executed blocks.
        
        Args:
            top_n: Number of blocks to return
            
        Returns:
            List of BasicBlock sorted by hit count
        """
        return sorted(
            self._blocks.values(),
            key=lambda b: b.hit_count,
            reverse=True
        )[:top_n]

    # === Export Functions ===

    def export_drcov(self, filename: str):
        """
        Export coverage to DrCov format (for Lighthouse/IDA).
        
        Args:
            filename: Output filename
        """
        with open(filename, 'wb') as f:
            self._write_drcov(f)
        logger.info(f"Exported DrCov coverage to {filename}")

    def _write_drcov(self, f: BinaryIO):
        """Write DrCov format."""
        # Header
        f.write(f"DRCOV VERSION: {self.DRCOV_VERSION}\n".encode())
        f.write(f"DRCOV FLAVOR: {self.DRCOV_FLAVOR}\n".encode())

        # Module table
        modules = list(self._modules.values())
        f.write(f"Module Table: version 2, count {len(modules)}\n".encode())
        f.write(b"Columns: id, base, end, entry, checksum, timestamp, path\n")

        for module in modules:
            end = module.base + module.size
            line = (
                f"{module.id}, 0x{module.base:x}, 0x{end:x}, "
                f"0x0, 0x{module.checksum:x}, 0x{module.timestamp:x}, "
                f"{module.path}\n"
            )
            f.write(line.encode())

        # Basic block table
        blocks = list(self._blocks.values())
        f.write(f"BB Table: {len(blocks)} bbs\n".encode())

        # Write binary block data
        for block in blocks:
            # DrCov format: start (4 bytes), size (2 bytes), module_id (2 bytes)
            module = self._modules.get(block.module_id)
            if module:
                offset = block.start - module.base
            else:
                offset = block.start

            entry = struct.pack('<IHH', offset, block.size, block.module_id)
            f.write(entry)

    def export_lcov(self, filename: str):
        """
        Export coverage to LCOV format.
        
        Args:
            filename: Output filename
        """
        with open(filename, 'w') as f:
            for module in self._modules.values():
                f.write(f"SF:{module.path}\n")

                # Write covered blocks as lines
                for block in self._blocks.values():
                    if block.module_id == module.id:
                        # Use block address as "line number"
                        offset = block.start - module.base
                        f.write(f"DA:{offset},{block.hit_count}\n")

                f.write("end_of_record\n")

        logger.info(f"Exported LCOV coverage to {filename}")

    def export_json(self, filename: str):
        """
        Export coverage to JSON format.
        
        Args:
            filename: Output filename
        """
        import json

        data = {
            "version": 1,
            "stats": {
                "unique_blocks": self._stats.unique_blocks,
                "unique_instructions": self._stats.unique_instructions,
                "total_blocks": self._stats.total_blocks,
                "total_instructions": self._stats.total_instructions,
                "duration": self._stats.duration
            },
            "modules": [
                {
                    "id": m.id,
                    "name": m.name,
                    "base": hex(m.base),
                    "size": m.size,
                    "path": m.path
                }
                for m in self._modules.values()
            ],
            "blocks": [
                {
                    "start": hex(b.start),
                    "end": hex(b.end),
                    "size": b.size,
                    "hits": b.hit_count,
                    "module": b.module_id
                }
                for b in self._blocks.values()
            ]
        }

        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)

        logger.info(f"Exported JSON coverage to {filename}")

    def export_binary_ninja(self, filename: str):
        """
        Export coverage for Binary Ninja's coverage plugin.
        
        Args:
            filename: Output filename (.covdb)
        """
        import json

        data = {
            "version": 1,
            "coverage": [
                {
                    "module": self._modules[b.module_id].name if b.module_id in self._modules else "unknown",
                    "offset": b.start - self._modules[b.module_id].base if b.module_id in self._modules else b.start,
                    "size": b.size
                }
                for b in self._blocks.values()
            ]
        }

        with open(filename, 'w') as f:
            json.dump(data, f)

        logger.info(f"Exported Binary Ninja coverage to {filename}")

    def export_ida_script(self, filename: str):
        """
        Export IDA Python script to color covered blocks.
        
        Args:
            filename: Output filename (.py)
        """
        with open(filename, 'w') as f:
            f.write("# IDA Python script to highlight coverage\n")
            f.write("# Run in IDA: File -> Script file\n\n")
            f.write("import idaapi\n")
            f.write("import idc\n\n")
            f.write("# Coverage color (green)\n")
            f.write("COLOR = 0x90EE90\n\n")
            f.write("covered_blocks = [\n")

            for block in self._blocks.values():
                f.write(f"    (0x{block.start:x}, 0x{block.end:x}),\n")

            f.write("]\n\n")
            f.write("for start, end in covered_blocks:\n")
            f.write("    for addr in range(start, end):\n")
            f.write("        idc.set_color(addr, idc.CIC_ITEM, COLOR)\n")
            f.write("\n")
            f.write('print(f"Highlighted {len(covered_blocks)} blocks")\n')

        logger.info(f"Exported IDA script to {filename}")

    def get_addresses(self) -> set[int]:
        """Get all covered addresses."""
        return set(self._blocks.keys()) | set(self._instructions.keys())

    def contains(self, address: int) -> bool:
        """Check if an address was covered."""
        return address in self._blocks or address in self._instructions

    def merge(self, other: 'CoverageTracker'):
        """
        Merge coverage from another tracker.
        
        Args:
            other: Another CoverageTracker instance
        """
        # Merge blocks
        for addr, block in other._blocks.items():
            if addr in self._blocks:
                self._blocks[addr].hit_count += block.hit_count
            else:
                self._blocks[addr] = BasicBlock(
                    start=block.start,
                    end=block.end,
                    size=block.size,
                    hit_count=block.hit_count,
                    module_id=block.module_id
                )

        # Merge instructions
        for addr, entry in other._instructions.items():
            if addr in self._instructions:
                self._instructions[addr].hit_count += entry.hit_count
            else:
                self._instructions[addr] = CoverageEntry(
                    address=entry.address,
                    size=entry.size,
                    hit_count=entry.hit_count,
                    module_id=entry.module_id
                )

        # Merge edges
        self._edges.update(other._edges)

        self._update_stats()
        logger.debug(f"Merged coverage: now {len(self._blocks)} blocks")


def create_coverage_tracker(
    emulator: 'Emulator',
    mode: str = 'block'
) -> CoverageTracker:
    """
    Create a coverage tracker.
    
    Args:
        emulator: PyUniDbg emulator instance
        mode: 'instruction', 'block', 'function', or 'edge'
        
    Returns:
        CoverageTracker instance
    """
    mode_map = {
        'instruction': CoverageMode.INSTRUCTION,
        'block': CoverageMode.BASIC_BLOCK,
        'function': CoverageMode.FUNCTION,
        'edge': CoverageMode.EDGE
    }
    return CoverageTracker(emulator, mode=mode_map.get(mode, CoverageMode.BASIC_BLOCK))
