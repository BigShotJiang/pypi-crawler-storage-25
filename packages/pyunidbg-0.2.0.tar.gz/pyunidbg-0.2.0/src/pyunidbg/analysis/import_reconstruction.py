"""
Import Reconstruction Module for PyUniDbg.

Rebuilds the Import Address Table (IAT) / GOT from runtime analysis
by monitoring actual function calls and resolving thunk addresses to
their real targets.

Features:
- Runtime call monitoring via code hooks on PLT/thunk regions
- IAT/GOT entry resolution from emulated execution
- Thunk-to-function mapping across loaded modules
- Import table generation in multiple formats (dict, JSON, IDA script)
- Cross-reference tracking (which code calls which imports)
- Support for both ELF (GOT/PLT) and PE (IAT) styles

Usage:
    from pyunidbg.analysis.import_reconstruction import ImportReconstructor

    recon = ImportReconstructor(emulator)
    recon.start_monitoring()

    # ... run emulation ...

    recon.stop_monitoring()
    table = recon.get_import_table()

    for lib, imports in table.items():
        for imp in imports:
            print(f"  {imp.thunk_address:#x} -> {imp.resolved_name}")

    # Export for IDA
    recon.export_ida_script("imports.py")
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

class ImportType(Enum):
    """How the import was identified."""
    PLT_CALL = auto()
    GOT_READ = auto()
    IAT_READ = auto()
    DIRECT_CALL = auto()
    HOOK_INTERCEPT = auto()
    SYMBOL_TABLE = auto()


@dataclass
class ReconstructedImport:
    """A single reconstructed import entry."""
    thunk_address: int
    resolved_address: int
    resolved_name: str
    library: str = ""
    import_type: ImportType = ImportType.PLT_CALL
    call_count: int = 0
    callers: set[int] = field(default_factory=set)
    ordinal: int = -1

    def __repr__(self) -> str:
        lib = f"{self.library}!" if self.library else ""
        return (
            f"Import({self.thunk_address:#x} -> {lib}{self.resolved_name} "
            f"@ {self.resolved_address:#x}, calls={self.call_count})"
        )


@dataclass
class ModuleImports:
    """All imports for a single module."""
    module_name: str
    base_address: int = 0
    imports: list[ReconstructedImport] = field(default_factory=list)
    got_base: int = 0
    got_size: int = 0
    plt_base: int = 0
    plt_size: int = 0


@dataclass
class ImportTableSnapshot:
    """Complete reconstructed import state."""
    modules: dict[str, ModuleImports] = field(default_factory=dict)
    unresolved: list[ReconstructedImport] = field(default_factory=list)
    total_imports: int = 0
    total_calls_monitored: int = 0


# ---------------------------------------------------------------------------
# Call monitor
# ---------------------------------------------------------------------------

class CallMonitor:
    """
    Monitors code execution to detect calls through PLT/thunks.

    Works by hooking the PLT region and reading the GOT entry
    that each PLT stub jumps through.
    """

    def __init__(self, emulator: Emulator):
        self._emu = emulator
        self._plt_ranges: list[tuple[int, int]] = []
        self._got_ranges: list[tuple[int, int]] = []
        self._calls: dict[int, list[int]] = defaultdict(list)
        self._hooks: list[Any] = []

    def add_plt_range(self, base: int, size: int) -> None:
        self._plt_ranges.append((base, size))

    def add_got_range(self, base: int, size: int) -> None:
        self._got_ranges.append((base, size))

    def start(self) -> None:
        from unicorn import UC_HOOK_CODE

        for plt_base, plt_size in self._plt_ranges:
            def _code_hook(uc, address, size, user_data, _pb=plt_base, _ps=plt_size):
                if _pb <= address < _pb + _ps:
                    caller_pc = 0
                    try:
                        caller_pc = self._emu.cpu.lr
                    except Exception:
                        logger.debug("Exception suppressed", exc_info=True)
                    self._calls[address].append(caller_pc)

            handle = self._emu._uc.hook_add(
                UC_HOOK_CODE, _code_hook,
                begin=plt_base, end=plt_base + plt_size)
            self._hooks.append(handle)

    def stop(self) -> None:
        for h in self._hooks:
            try:
                self._emu._uc.hook_del(h)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        self._hooks.clear()

    @property
    def recorded_calls(self) -> dict[int, list[int]]:
        return dict(self._calls)

    def clear(self) -> None:
        self._calls.clear()


# ---------------------------------------------------------------------------
# GOT/IAT reader
# ---------------------------------------------------------------------------

class TableReader:
    """Reads GOT/IAT entries from emulator memory."""

    def __init__(self, emulator: Emulator):
        self._emu = emulator
        self._ptr_size = emulator.pointer_size

    def read_got(self, got_base: int, got_size: int) -> dict[int, int]:
        """Read all GOT entries, returning {got_slot_addr: target_addr}."""
        entries: dict[int, int] = {}
        for offset in range(0, got_size, self._ptr_size):
            addr = got_base + offset
            try:
                data = self._emu.memory.read(addr, self._ptr_size)
                target = int.from_bytes(data, "little")
                if target != 0:
                    entries[addr] = target
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                break
        return entries

    def read_iat(self, iat_base: int, iat_size: int) -> dict[int, int]:
        """Read IAT entries (same format as GOT for our purposes)."""
        return self.read_got(iat_base, iat_size)


# ---------------------------------------------------------------------------
# Symbol resolver
# ---------------------------------------------------------------------------

class SymbolResolver:
    """
    Resolves addresses to symbol names using loaded module information.
    """

    def __init__(self, emulator: Emulator):
        self._emu = emulator
        self._cache: dict[int, tuple[str, str]] = {}

    def resolve(self, address: int) -> tuple[str, str]:
        """Return (library_name, symbol_name) for an address."""
        if address in self._cache:
            return self._cache[address]

        if hasattr(self._emu, "_modules"):
            for mod_name, mod in self._emu._modules.items():
                if hasattr(mod, "symbols"):
                    for sym_name, sym_addr in mod.symbols.items():
                        if sym_addr == address:
                            result = (mod_name, sym_name)
                            self._cache[address] = result
                            return result

                if hasattr(mod, "base_address") and hasattr(mod, "size"):
                    if mod.base_address <= address < mod.base_address + mod.size:
                        offset = address - mod.base_address
                        result = (mod_name, f"sub_{offset:x}")
                        self._cache[address] = result
                        return result

        result = ("unknown", f"func_{address:x}")
        self._cache[address] = result
        return result

    def clear_cache(self) -> None:
        self._cache.clear()


# ---------------------------------------------------------------------------
# Main reconstructor
# ---------------------------------------------------------------------------

class ImportReconstructor:
    """
    Reconstruct import tables from runtime analysis.

    Combines PLT/GOT monitoring with symbol resolution to rebuild
    a complete import table.
    """

    def __init__(self, emulator: Emulator):
        self.emulator = emulator
        self._monitor = CallMonitor(emulator)
        self._reader = TableReader(emulator)
        self._resolver = SymbolResolver(emulator)

        self._imports: dict[int, ReconstructedImport] = {}
        self._module_imports: dict[str, ModuleImports] = {}
        self._monitoring = False

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def add_plt_region(self, base: int, size: int) -> None:
        self._monitor.add_plt_range(base, size)

    def add_got_region(self, base: int, size: int) -> None:
        self._monitor.add_got_range(base, size)

    def auto_detect_regions(self) -> int:
        """
        Auto-detect PLT/GOT regions from loaded modules.
        Returns number of regions detected.
        """
        count = 0
        if hasattr(self.emulator, "_modules"):
            for name, mod in self.emulator._modules.items():
                if hasattr(mod, "plt_address") and hasattr(mod, "plt_size"):
                    if mod.plt_address and mod.plt_size:
                        self._monitor.add_plt_range(mod.plt_address, mod.plt_size)
                        count += 1
                if hasattr(mod, "got_address") and hasattr(mod, "got_size"):
                    if mod.got_address and mod.got_size:
                        self._monitor.add_got_range(mod.got_address, mod.got_size)
                        count += 1

        for region in self.emulator.memory.get_regions():
            name = getattr(region, "name", "") or ""
            if ".plt" in name:
                self._monitor.add_plt_range(region.start, region.size)
                count += 1
            elif ".got" in name:
                self._monitor.add_got_range(region.start, region.size)
                count += 1

        logger.info("Auto-detected %d PLT/GOT regions", count)
        return count

    # ------------------------------------------------------------------
    # Monitoring
    # ------------------------------------------------------------------

    def start_monitoring(self) -> None:
        if self._monitoring:
            return
        self._monitoring = True
        self._monitor.start()
        logger.info("Import reconstruction monitoring started")

    def stop_monitoring(self) -> None:
        if not self._monitoring:
            return
        self._monitoring = False
        self._monitor.stop()
        self._process_recorded_calls()
        logger.info("Import reconstruction monitoring stopped")

    # ------------------------------------------------------------------
    # GOT/IAT snapshot
    # ------------------------------------------------------------------

    def snapshot_got(self) -> dict[int, int]:
        """Take a snapshot of all GOT entries."""
        all_entries: dict[int, int] = {}
        for got_base, got_size in self._monitor._got_ranges:
            entries = self._reader.read_got(got_base, got_size)
            all_entries.update(entries)
        return all_entries

    def resolve_got_entries(self) -> list[ReconstructedImport]:
        """Resolve all GOT entries to symbol names."""
        resolved = []
        got_snapshot = self.snapshot_got()

        for slot_addr, target_addr in got_snapshot.items():
            lib, name = self._resolver.resolve(target_addr)
            imp = ReconstructedImport(
                thunk_address=slot_addr,
                resolved_address=target_addr,
                resolved_name=name,
                library=lib,
                import_type=ImportType.GOT_READ,
            )
            self._imports[slot_addr] = imp
            resolved.append(imp)

        logger.info("Resolved %d GOT entries", len(resolved))
        return resolved

    # ------------------------------------------------------------------
    # Result access
    # ------------------------------------------------------------------

    def get_import_table(self) -> ImportTableSnapshot:
        """Get the complete reconstructed import table."""
        if not self._imports:
            self.resolve_got_entries()

        modules: dict[str, ModuleImports] = defaultdict(
            lambda: ModuleImports(module_name="unknown"))

        for imp in self._imports.values():
            lib = imp.library or "unknown"
            if lib not in modules:
                modules[lib] = ModuleImports(module_name=lib)
            modules[lib].imports.append(imp)

        unresolved = [
            imp for imp in self._imports.values()
            if imp.resolved_name.startswith("func_") or imp.resolved_name.startswith("sub_")
        ]

        return ImportTableSnapshot(
            modules=dict(modules),
            unresolved=unresolved,
            total_imports=len(self._imports),
            total_calls_monitored=sum(
                imp.call_count for imp in self._imports.values()),
        )

    def get_xrefs(self, import_name: str) -> set[int]:
        """Get all caller addresses for a given import."""
        for imp in self._imports.values():
            if imp.resolved_name == import_name:
                return imp.callers
        return set()

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def export_json(self, path: str | None = None) -> str:
        """Export reconstructed imports as JSON."""
        table = self.get_import_table()
        data = {
            "total_imports": table.total_imports,
            "total_calls": table.total_calls_monitored,
            "modules": {},
        }
        for lib, mod_imports in table.modules.items():
            data["modules"][lib] = [
                {
                    "thunk": f"{imp.thunk_address:#x}",
                    "target": f"{imp.resolved_address:#x}",
                    "name": imp.resolved_name,
                    "calls": imp.call_count,
                    "callers": [f"{c:#x}" for c in imp.callers],
                }
                for imp in mod_imports.imports
            ]

        json_str = json.dumps(data, indent=2)
        if path:
            with open(path, "w") as f:
                f.write(json_str)
        return json_str

    def export_ida_script(self, path: str) -> str:
        """Generate an IDAPython script to apply import names."""
        lines = [
            "# Auto-generated by PyUniDbg Import Reconstructor",
            "import idaapi",
            "import idc",
            "",
        ]
        for imp in self._imports.values():
            if not imp.resolved_name.startswith(("func_", "sub_")):
                lines.append(
                    f"idc.set_name({imp.thunk_address:#x}, "
                    f'"{imp.resolved_name}", idc.SN_FORCE)'
                )
                lines.append(
                    f"idc.set_cmt({imp.thunk_address:#x}, "
                    f'"{imp.library}!{imp.resolved_name}", 0)'
                )

        script = "\n".join(lines)
        with open(path, "w") as f:
            f.write(script)
        return script

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _process_recorded_calls(self) -> None:
        """Convert raw call records into ReconstructedImport entries."""
        for plt_addr, callers in self._monitor.recorded_calls.items():
            if plt_addr in self._imports:
                self._imports[plt_addr].call_count += len(callers)
                self._imports[plt_addr].callers.update(callers)
            else:
                target = self._resolve_plt_target(plt_addr)
                if target:
                    lib, name = self._resolver.resolve(target)
                    imp = ReconstructedImport(
                        thunk_address=plt_addr,
                        resolved_address=target,
                        resolved_name=name,
                        library=lib,
                        import_type=ImportType.PLT_CALL,
                        call_count=len(callers),
                        callers=set(callers),
                    )
                    self._imports[plt_addr] = imp

    def _resolve_plt_target(self, plt_addr: int) -> int | None:
        """Follow a PLT stub to find the GOT target."""
        try:
            code = self.emulator.memory.read(plt_addr, 16)
            insns = list(self.emulator._cs.disasm(code, plt_addr))
            if not insns:
                return None

            first = insns[0]
            if first.mnemonic in ("ldr", "adrp"):
                ptr_size = self.emulator.pointer_size
                for insn in insns[:3]:
                    if insn.mnemonic == "ldr" and "[" in insn.op_str:
                        try:
                            parts = insn.op_str.split("[")[1].split("]")[0]
                            tokens = [t.strip() for t in parts.split(",")]
                            regs = self.emulator.cpu.dump()
                            base = regs.get(tokens[0].upper(), 0)
                            if len(tokens) > 1:
                                offset = int(tokens[1].strip("#"), 0)
                                base += offset
                            data = self.emulator.memory.read(base, ptr_size)
                            return int.from_bytes(data, "little")
                        except Exception:
                            logger.debug("Exception suppressed", exc_info=True)

            if first.mnemonic == "jmp":
                if first.op_str.startswith("["):
                    try:
                        addr_str = first.op_str.strip("[]")
                        addr = int(addr_str, 0)
                        ptr_size = self.emulator.pointer_size
                        data = self.emulator.memory.read(addr, ptr_size)
                        return int.from_bytes(data, "little")
                    except Exception:
                        logger.debug("Exception suppressed", exc_info=True)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
        return None

    def reset(self) -> None:
        self.stop_monitoring()
        self._imports.clear()
        self._module_imports.clear()
        self._monitor.clear()
        self._resolver.clear_cache()


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------

def create_import_reconstructor(emulator: Emulator) -> ImportReconstructor:
    return ImportReconstructor(emulator)


__all__ = [
    "ImportReconstructor",
    "ReconstructedImport",
    "ImportType",
    "ModuleImports",
    "ImportTableSnapshot",
    "CallMonitor",
    "TableReader",
    "SymbolResolver",
    "create_import_reconstructor",
]
