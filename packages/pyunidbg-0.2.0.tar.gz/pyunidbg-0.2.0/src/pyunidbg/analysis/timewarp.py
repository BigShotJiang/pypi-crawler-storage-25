"""
Time Warp - Unified time control for security bypass.

Controls all time-related functions to:
- Fake timestamps during replay
- Bypass anti-debug timing checks
- Consistent time across snapshots
"""

import logging
import time
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


class TimeMode(Enum):
    """Time control modes."""
    REAL = auto()        # Use real system time
    FROZEN = auto()      # Time stands still
    CONTROLLED = auto()  # Manually controlled time
    SCALED = auto()      # Time runs faster/slower
    REPLAY = auto()      # Replaying recorded timestamps


@dataclass
class TimeState:
    """Captured time state for snapshot/replay."""
    real_time: float           # Real time when captured
    emulated_time: float       # Emulated time value
    monotonic_time: float      # Monotonic clock value
    boot_time: float           # System boot time
    thread_cpu_time: float     # Thread CPU time
    process_cpu_time: float    # Process CPU time

    def to_dict(self) -> dict:
        return {
            'real_time': self.real_time,
            'emulated_time': self.emulated_time,
            'monotonic_time': self.monotonic_time,
            'boot_time': self.boot_time,
            'thread_cpu_time': self.thread_cpu_time,
            'process_cpu_time': self.process_cpu_time,
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'TimeState':
        return cls(**data)


class TimeController:
    """
    Controls time for a single time source.
    
    Used internally by TimeWarp for each clock type.
    """

    def __init__(self, name: str, initial_value: float = None):
        self.name = name
        self._mode = TimeMode.REAL
        self._base_real_time = time.time()
        self._base_value = initial_value or time.time()
        self._frozen_value = self._base_value
        self._scale = 1.0
        self._offset = 0.0
        self._recorded_times: list[tuple[float, float]] = []  # (real_time, value)
        self._replay_index = 0

    @property
    def mode(self) -> TimeMode:
        return self._mode

    def get_time(self) -> float:
        """Get current time value based on mode."""
        if self._mode == TimeMode.REAL:
            return time.time() + self._offset

        elif self._mode == TimeMode.FROZEN:
            return self._frozen_value

        elif self._mode == TimeMode.CONTROLLED:
            return self._frozen_value

        elif self._mode == TimeMode.SCALED:
            elapsed = time.time() - self._base_real_time
            return self._base_value + (elapsed * self._scale) + self._offset

        elif self._mode == TimeMode.REPLAY:
            if self._replay_index < len(self._recorded_times):
                _, value = self._recorded_times[self._replay_index]
                return value
            return self._frozen_value

        return time.time()

    def set_real(self) -> None:
        """Switch to real time mode."""
        self._mode = TimeMode.REAL

    def freeze(self, at_value: float = None) -> None:
        """Freeze time at current or specified value."""
        self._frozen_value = at_value or self.get_time()
        self._mode = TimeMode.FROZEN

    def set_time(self, value: float) -> None:
        """Manually set time value."""
        self._frozen_value = value
        self._mode = TimeMode.CONTROLLED

    def advance(self, delta: float) -> None:
        """Advance time by delta seconds."""
        self._frozen_value += delta

    def set_scale(self, scale: float) -> None:
        """Set time scale (1.0 = normal, 2.0 = double speed)."""
        self._base_value = self.get_time()
        self._base_real_time = time.time()
        self._scale = scale
        self._mode = TimeMode.SCALED

    def set_offset(self, offset: float) -> None:
        """Add offset to time (can be negative)."""
        self._offset = offset

    def record(self) -> None:
        """Record current time for replay."""
        self._recorded_times.append((time.time(), self.get_time()))

    def start_replay(self) -> None:
        """Start replaying recorded times."""
        self._replay_index = 0
        self._mode = TimeMode.REPLAY

    def next_replay(self) -> None:
        """Move to next recorded time."""
        if self._replay_index < len(self._recorded_times):
            self._replay_index += 1

    def reset_recording(self) -> None:
        """Clear recorded times."""
        self._recorded_times.clear()
        self._replay_index = 0

    def capture_state(self) -> float:
        """Capture current time for snapshot."""
        return self.get_time()

    def restore_state(self, value: float) -> None:
        """Restore time from snapshot."""
        self._frozen_value = value
        self._mode = TimeMode.CONTROLLED


class TimeWarp:
    """
    Unified time control for emulation.
    
    Controls all time sources to ensure consistent behavior:
    - System time (gettimeofday, time())
    - Monotonic clock (clock_gettime MONOTONIC)
    - Boot time
    - CPU time
    - Performance counters
    
    Example:
        timewarp = TimeWarp(emulator)
        
        # Freeze time during analysis
        timewarp.freeze_all()
        
        # Set specific time
        timewarp.set_time(1609459200.0)  # 2021-01-01 00:00:00
        
        # Scale time (2x speed)
        timewarp.set_scale(2.0)
        
        # Replay mode - time advances with recorded values
        timewarp.start_replay()
    """

    # Clock IDs (matching Linux/Darwin)
    CLOCK_REALTIME = 0
    CLOCK_MONOTONIC = 1
    CLOCK_PROCESS_CPUTIME_ID = 2
    CLOCK_THREAD_CPUTIME_ID = 3
    CLOCK_MONOTONIC_RAW = 4
    CLOCK_REALTIME_COARSE = 5
    CLOCK_MONOTONIC_COARSE = 6
    CLOCK_BOOTTIME = 7

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator

        # Individual time controllers
        self.realtime = TimeController('realtime')
        self.monotonic = TimeController('monotonic', time.monotonic())
        self.boottime = TimeController('boottime', time.time() - 86400)  # Fake 1 day uptime
        self.process_cpu = TimeController('process_cpu', 0.0)
        self.thread_cpu = TimeController('thread_cpu', 0.0)

        # Performance counter (for RDTSC, mach_absolute_time, etc.)
        self.perf_counter = TimeController('perf_counter', 0)
        self._perf_base = time.perf_counter_ns()

        # Global settings
        self._global_mode = TimeMode.REAL
        self._instruction_count = 0
        self._time_per_instruction = 0.00001  # 10 microseconds per instruction

        # Callbacks for time updates
        self._callbacks: list[Callable[[str, float], None]] = []

        # Install hooks
        self._install_hooks()

    def _install_hooks(self) -> None:
        """Install time-related syscall hooks."""
        # This will be called by syscall handlers to get controlled time
        pass

    # ==================== Global Control ====================

    def freeze_all(self, at_time: float = None) -> None:
        """Freeze all clocks at current or specified time."""
        t = at_time or time.time()
        self._global_mode = TimeMode.FROZEN

        self.realtime.freeze(t)
        self.monotonic.freeze(time.monotonic())
        self.boottime.freeze(t - 86400)
        self.process_cpu.freeze()
        self.thread_cpu.freeze()
        self.perf_counter.freeze()

        logger.info(f"Time frozen at {t}")

    def unfreeze_all(self) -> None:
        """Resume all clocks to real time."""
        self._global_mode = TimeMode.REAL

        self.realtime.set_real()
        self.monotonic.set_real()
        self.boottime.set_real()
        self.process_cpu.set_real()
        self.thread_cpu.set_real()
        self.perf_counter.set_real()

        logger.info("Time unfrozen")

    def set_time(self, timestamp: float) -> None:
        """Set all clocks to specific timestamp."""
        self._global_mode = TimeMode.CONTROLLED

        self.realtime.set_time(timestamp)
        # Monotonic relative to realtime
        mono_offset = time.monotonic() - time.time()
        self.monotonic.set_time(timestamp + mono_offset)
        self.boottime.set_time(timestamp - 86400)

        logger.info(f"Time set to {timestamp}")

    def set_scale(self, scale: float) -> None:
        """Set time scale for all clocks."""
        self._global_mode = TimeMode.SCALED

        self.realtime.set_scale(scale)
        self.monotonic.set_scale(scale)
        self.boottime.set_scale(scale)
        self.process_cpu.set_scale(scale)
        self.thread_cpu.set_scale(scale)
        self.perf_counter.set_scale(scale)

        logger.info(f"Time scale set to {scale}x")

    def advance_all(self, delta: float) -> None:
        """Advance all clocks by delta seconds."""
        self.realtime.advance(delta)
        self.monotonic.advance(delta)
        self.boottime.advance(delta)
        self.process_cpu.advance(delta * 0.1)  # CPU time accumulates slower
        self.thread_cpu.advance(delta * 0.1)
        self.perf_counter.advance(delta * 1e9)  # Nanoseconds

    # ==================== Instruction-Based Time ====================

    def on_instruction(self) -> None:
        """Called on each instruction - advances time if in controlled mode."""
        self._instruction_count += 1

        if self._global_mode in (TimeMode.FROZEN, TimeMode.CONTROLLED):
            # Advance time based on instruction count
            delta = self._time_per_instruction
            self.advance_all(delta)

    def set_time_per_instruction(self, seconds: float) -> None:
        """Set how much time passes per instruction."""
        self._time_per_instruction = seconds

    @property
    def instruction_count(self) -> int:
        return self._instruction_count

    def reset_instruction_count(self) -> None:
        self._instruction_count = 0

    # ==================== Clock Access ====================

    def get_clock_time(self, clock_id: int) -> tuple[int, int]:
        """
        Get time for specific clock ID.
        
        Returns:
            Tuple of (seconds, nanoseconds)
        """
        if clock_id == self.CLOCK_REALTIME or clock_id == self.CLOCK_REALTIME_COARSE:
            t = self.realtime.get_time()
        elif clock_id in (self.CLOCK_MONOTONIC, self.CLOCK_MONOTONIC_RAW,
                          self.CLOCK_MONOTONIC_COARSE):
            t = self.monotonic.get_time()
        elif clock_id == self.CLOCK_BOOTTIME:
            t = self.boottime.get_time()
        elif clock_id == self.CLOCK_PROCESS_CPUTIME_ID:
            t = self.process_cpu.get_time()
        elif clock_id == self.CLOCK_THREAD_CPUTIME_ID:
            t = self.thread_cpu.get_time()
        else:
            t = self.realtime.get_time()

        sec = int(t)
        nsec = int((t - sec) * 1e9)
        return (sec, nsec)

    def get_timeval(self) -> tuple[int, int]:
        """
        Get time as timeval (for gettimeofday).
        
        Returns:
            Tuple of (seconds, microseconds)
        """
        t = self.realtime.get_time()
        sec = int(t)
        usec = int((t - sec) * 1e6)
        return (sec, usec)

    def get_perf_counter(self) -> int:
        """Get performance counter value (for RDTSC, mach_absolute_time)."""
        if self._global_mode == TimeMode.REAL:
            return time.perf_counter_ns() - self._perf_base
        return int(self.perf_counter.get_time())

    # ==================== Recording & Replay ====================

    def record_all(self) -> None:
        """Record current time on all clocks."""
        self.realtime.record()
        self.monotonic.record()
        self.boottime.record()
        self.process_cpu.record()
        self.thread_cpu.record()
        self.perf_counter.record()

    def start_replay(self) -> None:
        """Start replaying recorded times."""
        self._global_mode = TimeMode.REPLAY
        self.realtime.start_replay()
        self.monotonic.start_replay()
        self.boottime.start_replay()
        self.process_cpu.start_replay()
        self.thread_cpu.start_replay()
        self.perf_counter.start_replay()

        logger.info("Time replay started")

    def next_replay_step(self) -> None:
        """Advance to next recorded time on all clocks."""
        self.realtime.next_replay()
        self.monotonic.next_replay()
        self.boottime.next_replay()
        self.process_cpu.next_replay()
        self.thread_cpu.next_replay()
        self.perf_counter.next_replay()

    def stop_replay(self) -> None:
        """Stop replay and return to controlled mode."""
        self._global_mode = TimeMode.CONTROLLED

    def reset_recording(self) -> None:
        """Clear all recorded times."""
        self.realtime.reset_recording()
        self.monotonic.reset_recording()
        self.boottime.reset_recording()
        self.process_cpu.reset_recording()
        self.thread_cpu.reset_recording()
        self.perf_counter.reset_recording()

    # ==================== State Capture ====================

    def capture_state(self) -> TimeState:
        """Capture complete time state for snapshot."""
        return TimeState(
            real_time=time.time(),
            emulated_time=self.realtime.get_time(),
            monotonic_time=self.monotonic.get_time(),
            boot_time=self.boottime.get_time(),
            thread_cpu_time=self.thread_cpu.get_time(),
            process_cpu_time=self.process_cpu.get_time(),
        )

    def restore_state(self, state: TimeState, adjust_to_now: bool = True) -> None:
        """
        Restore time state from snapshot.
        
        Args:
            state: Captured time state
            adjust_to_now: If True, adjust times so they're relative to current time
        """
        if adjust_to_now:
            # Calculate how much real time has passed
            time_delta = time.time() - state.real_time

            self.realtime.set_time(state.emulated_time + time_delta)
            self.monotonic.set_time(state.monotonic_time + time_delta)
            self.boottime.set_time(state.boot_time + time_delta)
        else:
            self.realtime.set_time(state.emulated_time)
            self.monotonic.set_time(state.monotonic_time)
            self.boottime.set_time(state.boot_time)

        self.thread_cpu.set_time(state.thread_cpu_time)
        self.process_cpu.set_time(state.process_cpu_time)

        self._global_mode = TimeMode.CONTROLLED
        logger.info("Time state restored")

    # ==================== Callbacks ====================

    def add_callback(self, callback: Callable[[str, float], None]) -> None:
        """Add callback for time changes. Called with (clock_name, new_value)."""
        self._callbacks.append(callback)

    def remove_callback(self, callback: Callable[[str, float], None]) -> None:
        """Remove time change callback."""
        if callback in self._callbacks:
            self._callbacks.remove(callback)

    def _notify_callbacks(self, clock_name: str, value: float) -> None:
        """Notify all callbacks of time change."""
        for callback in self._callbacks:
            try:
                callback(clock_name, value)
            except Exception as e:
                logger.warning(f"Time callback error: {e}")
