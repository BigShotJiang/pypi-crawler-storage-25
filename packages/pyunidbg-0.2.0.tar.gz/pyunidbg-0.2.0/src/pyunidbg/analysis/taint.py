"""
Taint Analysis Engine - Track data flow through execution.

Provides:
- Source/sink taint tracking
- Taint propagation through registers and memory
- Policy-based alerts
- Data flow visualization
"""

import logging
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Flag, auto
from typing import TYPE_CHECKING

from unicorn import UC_HOOK_CODE, UC_HOOK_MEM_READ, UC_HOOK_MEM_WRITE

if TYPE_CHECKING:
    from ..core.emulator import Emulator

from .disasm import DisasmOutput, Disassembler

logger = logging.getLogger(__name__)


class TaintColor(Flag):
    """Taint colors for multi-source tracking."""
    NONE = 0
    INPUT = auto()      # User input
    NETWORK = auto()    # Network data
    FILE = auto()       # File data
    ENV = auto()        # Environment variables
    HEAP = auto()       # Heap allocated data
    CRYPTO = auto()     # Cryptographic keys/data
    SENSITIVE = auto()  # Generic sensitive data
    CUSTOM1 = auto()
    CUSTOM2 = auto()
    CUSTOM3 = auto()
    CUSTOM4 = auto()


@dataclass
class TaintSource:
    """Definition of a taint source."""
    name: str
    color: TaintColor

    # Source type
    address: int | None = None        # Memory address
    register: str | None = None       # Register name
    function: str | None = None       # Function that returns tainted data
    memory_range: tuple[int, int] | None = None  # (start, end)

    # Optional metadata
    description: str = ""

    def matches(self, addr: int = None, reg: str = None) -> bool:
        """Check if source matches address or register."""
        if self.address and addr == self.address:
            return True
        if self.register and reg == self.register:
            return True
        if self.memory_range and addr:
            start, end = self.memory_range
            if start <= addr < end:
                return True
        return False


@dataclass
class TaintSink:
    """Definition of a taint sink (dangerous destination)."""
    name: str

    # Sink type
    address: int | None = None        # Memory address
    register: str | None = None       # Register
    function: str | None = None       # Dangerous function
    memory_range: tuple[int, int] | None = None

    # Alert settings
    alert_colors: TaintColor = TaintColor.INPUT | TaintColor.NETWORK
    severity: str = "high"
    description: str = ""

    def matches(self, addr: int = None, reg: str = None) -> bool:
        """Check if sink matches."""
        if self.address and addr == self.address:
            return True
        if self.register and reg == self.register:
            return True
        if self.memory_range and addr:
            start, end = self.memory_range
            if start <= addr < end:
                return True
        return False


@dataclass
class TaintAlert:
    """Alert when tainted data reaches sink."""
    source: TaintSource
    sink: TaintSink
    color: TaintColor
    address: int            # PC where alert occurred
    timestamp: float

    # Flow information
    flow_path: list[int] = field(default_factory=list)

    def __str__(self) -> str:
        return f"TAINT ALERT: {self.source.name} -> {self.sink.name} at 0x{self.address:x}"


class TaintPolicy:
    """
    Policy for taint tracking behavior.
    
    Defines:
    - What data is tainted
    - What operations propagate taint
    - What triggers alerts
    """

    def __init__(self):
        # Propagation rules
        self.propagate_through_arithmetic = True
        self.propagate_through_logic = True
        self.propagate_through_memory = True
        self.propagate_through_calls = True

        # Taint combination
        self.combine_taints = True  # If A op B, result has both taints

        # Clear taint conditions
        self.clear_on_constant = True   # mov reg, #const clears taint
        self.clear_on_xor_self = True   # xor reg, reg, reg clears taint

        # Alert conditions
        self.alert_on_branch = True     # Alert when tainted data affects control flow
        self.alert_on_call = True       # Alert when tainted data is function arg
        self.alert_on_memory = True     # Alert when tainted data is memory address

        # Dangerous function patterns
        self.dangerous_functions: set[str] = {
            'system', 'exec', 'popen', 'eval',
            'strcpy', 'strcat', 'sprintf', 'gets',
            'memcpy', 'memmove',
            '__system_property_get',
        }


@dataclass
class TaintState:
    """Taint state for a single byte/register."""
    color: TaintColor = TaintColor.NONE
    sources: set[str] = field(default_factory=set)  # Source names
    first_tainted_pc: int = 0
    last_modified_pc: int = 0
    propagation_count: int = 0


class TaintMap:
    """Efficient taint map for memory."""

    def __init__(self, page_size: int = 4096):
        self.page_size = page_size
        # Page-level taint: page_addr -> {offset -> TaintState}
        self._pages: dict[int, dict[int, TaintState]] = defaultdict(dict)
        # Statistics
        self._tainted_bytes = 0

    def set_taint(self, address: int, size: int, state: TaintState) -> None:
        """Set taint for memory range."""
        for i in range(size):
            addr = address + i
            page = addr & ~(self.page_size - 1)
            offset = addr & (self.page_size - 1)

            if offset not in self._pages[page]:
                self._tainted_bytes += 1

            self._pages[page][offset] = state

    def get_taint(self, address: int) -> TaintState:
        """Get taint for single byte."""
        page = address & ~(self.page_size - 1)
        offset = address & (self.page_size - 1)

        if page in self._pages and offset in self._pages[page]:
            return self._pages[page][offset]

        return TaintState()

    def get_taint_range(self, address: int, size: int) -> TaintColor:
        """Get combined taint for memory range."""
        combined = TaintColor.NONE
        for i in range(size):
            state = self.get_taint(address + i)
            combined |= state.color
        return combined

    def clear_taint(self, address: int, size: int = 1) -> None:
        """Clear taint from memory range."""
        for i in range(size):
            addr = address + i
            page = addr & ~(self.page_size - 1)
            offset = addr & (self.page_size - 1)

            if page in self._pages and offset in self._pages[page]:
                del self._pages[page][offset]
                self._tainted_bytes -= 1

    def is_tainted(self, address: int, size: int = 1) -> bool:
        """Check if any byte in range is tainted."""
        for i in range(size):
            state = self.get_taint(address + i)
            if state.color != TaintColor.NONE:
                return True
        return False

    @property
    def tainted_count(self) -> int:
        return self._tainted_bytes

    def get_tainted_ranges(self) -> list[tuple[int, int, TaintColor]]:
        """Get list of tainted memory ranges."""
        ranges = []
        current_start = None
        current_color = TaintColor.NONE

        all_addrs = []
        for page, offsets in self._pages.items():
            for offset in offsets:
                all_addrs.append(page + offset)

        for addr in sorted(all_addrs):
            state = self.get_taint(addr)
            if current_start is None:
                current_start = addr
                current_color = state.color
            elif addr == current_start + 1 and state.color == current_color:
                pass  # Continue range
            else:
                ranges.append((current_start, addr, current_color))
                current_start = addr
                current_color = state.color

        if current_start is not None:
            ranges.append((current_start, addr + 1, current_color))

        return ranges


class TaintEngine:
    """
    Taint analysis engine.
    
    Tracks data flow from sources to sinks:
    - Input data (user input, network, files)
    - Sensitive data (keys, passwords)
    - Control flow influence
    
    Example:
        taint = TaintEngine(emulator)
        
        # Define sources
        taint.add_source(TaintSource(
            name="user_input",
            color=TaintColor.INPUT,
            memory_range=(0x1000, 0x2000)
        ))
        
        # Define sinks
        taint.add_sink(TaintSink(
            name="system_call",
            function="system",
            severity="critical"
        ))
        
        # Start tracking
        taint.start()
        
        # Run code
        emulator.run()
        
        # Check alerts
        for alert in taint.alerts:
            print(alert)
    """

    def __init__(self, emulator: 'Emulator'):
        self.emulator = emulator
        self.disasm = Disassembler(emulator)

        # Taint storage
        self._memory_taint = TaintMap()
        self._register_taint: dict[str, TaintState] = {}

        # Sources and sinks
        self._sources: list[TaintSource] = []
        self._sinks: list[TaintSink] = []

        # Policy
        self.policy = TaintPolicy()

        # Alerts
        self._alerts: list[TaintAlert] = []

        # Hooks
        self._code_hook = None
        self._mem_read_hook = None
        self._mem_write_hook = None

        # State
        self._active = False

        # Statistics
        self._stats = {
            'instructions_analyzed': 0,
            'taints_propagated': 0,
            'alerts_generated': 0,
        }

        # Flow tracking
        self._enable_flow_tracking = False
        self._flow_graph: dict[int, set[int]] = defaultdict(set)  # from -> {to}

        # Callbacks
        self._alert_callbacks: list[Callable[[TaintAlert], None]] = []

    @property
    def alerts(self) -> list[TaintAlert]:
        return self._alerts.copy()

    @property
    def stats(self) -> dict:
        return self._stats.copy()

    # ==================== Source/Sink Management ====================

    def add_source(self, source: TaintSource) -> None:
        """Add taint source."""
        self._sources.append(source)

        # Apply initial taint
        if source.address:
            self._taint_memory(source.address, 1, source.color, source.name)
        if source.register:
            self._taint_register(source.register, source.color, source.name)
        if source.memory_range:
            start, end = source.memory_range
            self._taint_memory(start, end - start, source.color, source.name)

        logger.info(f"Added taint source: {source.name}")

    def add_sink(self, sink: TaintSink) -> None:
        """Add taint sink."""
        self._sinks.append(sink)
        logger.info(f"Added taint sink: {sink.name}")

    def remove_source(self, name: str) -> bool:
        """Remove source by name."""
        for i, src in enumerate(self._sources):
            if src.name == name:
                self._sources.pop(i)
                return True
        return False

    def remove_sink(self, name: str) -> bool:
        """Remove sink by name."""
        for i, sink in enumerate(self._sinks):
            if sink.name == name:
                self._sinks.pop(i)
                return True
        return False

    # ==================== Common Sources ====================

    def taint_input(self, address: int, size: int, name: str = "input") -> None:
        """Mark memory as user input (convenience method)."""
        source = TaintSource(
            name=name,
            color=TaintColor.INPUT,
            memory_range=(address, address + size)
        )
        self.add_source(source)

    def taint_network(self, address: int, size: int, name: str = "network") -> None:
        """Mark memory as network data."""
        source = TaintSource(
            name=name,
            color=TaintColor.NETWORK,
            memory_range=(address, address + size)
        )
        self.add_source(source)

    def taint_register(self, reg: str, color: TaintColor = TaintColor.INPUT,
                       name: str = "") -> None:
        """Mark register as tainted."""
        source = TaintSource(
            name=name or f"reg_{reg}",
            color=color,
            register=reg
        )
        self.add_source(source)

    def taint_function_return(self, func_name: str, color: TaintColor = TaintColor.INPUT) -> None:
        """Mark function return value as tainted."""
        source = TaintSource(
            name=f"func_{func_name}",
            color=color,
            function=func_name
        )
        self.add_source(source)

    # ==================== Common Sinks ====================

    def add_dangerous_function(self, func_name: str, severity: str = "high") -> None:
        """Add dangerous function as sink."""
        sink = TaintSink(
            name=f"dangerous_{func_name}",
            function=func_name,
            severity=severity
        )
        self.add_sink(sink)

    def add_control_flow_sink(self, address: int, name: str = "") -> None:
        """Add control flow address as sink."""
        sink = TaintSink(
            name=name or f"control_0x{address:x}",
            address=address,
            severity="critical",
            description="Control flow influenced by tainted data"
        )
        self.add_sink(sink)

    # ==================== Engine Control ====================

    def start(self) -> None:
        """Start taint tracking."""
        if self._active:
            return

        self._active = True

        # Install hooks
        self._code_hook = self.emulator.uc.hook_add(
            UC_HOOK_CODE, self._on_instruction
        )
        self._mem_read_hook = self.emulator.uc.hook_add(
            UC_HOOK_MEM_READ, self._on_mem_read
        )
        self._mem_write_hook = self.emulator.uc.hook_add(
            UC_HOOK_MEM_WRITE, self._on_mem_write
        )

        logger.info("Taint analysis started")

    def stop(self) -> None:
        """Stop taint tracking."""
        if not self._active:
            return

        self._active = False

        # Remove hooks
        if self._code_hook:
            self.emulator.uc.hook_del(self._code_hook)
        if self._mem_read_hook:
            self.emulator.uc.hook_del(self._mem_read_hook)
        if self._mem_write_hook:
            self.emulator.uc.hook_del(self._mem_write_hook)

        logger.info(f"Taint analysis stopped. {len(self._alerts)} alerts.")

    def reset(self) -> None:
        """Reset taint state."""
        self._memory_taint = TaintMap()
        self._register_taint.clear()
        self._alerts.clear()
        self._flow_graph.clear()
        self._stats = dict.fromkeys(self._stats, 0)

    # ==================== Taint Operations ====================

    def _taint_memory(self, address: int, size: int, color: TaintColor,
                      source_name: str, pc: int = 0) -> None:
        """Apply taint to memory."""
        state = TaintState(
            color=color,
            sources={source_name},
            first_tainted_pc=pc,
            last_modified_pc=pc,
        )
        self._memory_taint.set_taint(address, size, state)

    def _taint_register(self, reg: str, color: TaintColor,
                        source_name: str, pc: int = 0) -> None:
        """Apply taint to register."""
        state = TaintState(
            color=color,
            sources={source_name},
            first_tainted_pc=pc,
            last_modified_pc=pc,
        )
        self._register_taint[reg.lower()] = state

    def _get_reg_taint(self, reg: str) -> TaintState:
        """Get taint state of register."""
        return self._register_taint.get(reg.lower(), TaintState())

    def _clear_reg_taint(self, reg: str) -> None:
        """Clear taint from register."""
        if reg.lower() in self._register_taint:
            del self._register_taint[reg.lower()]

    def _combine_taints(self, *states: TaintState) -> TaintState:
        """Combine multiple taint states."""
        combined = TaintState()
        for state in states:
            combined.color |= state.color
            combined.sources |= state.sources
            combined.propagation_count = max(combined.propagation_count,
                                             state.propagation_count) + 1
        return combined

    # ==================== Instruction Analysis ====================

    def _on_instruction(self, uc, address: int, size: int, user_data) -> None:
        """Analyze instruction for taint propagation."""
        if not self._active:
            return

        self._stats['instructions_analyzed'] += 1

        # Disassemble
        insn = self.disasm.disasm_at(address, size)
        if not insn:
            return

        # Analyze instruction
        self._analyze_instruction(insn, address)

    def _analyze_instruction(self, insn: DisasmOutput, pc: int) -> None:
        """Analyze instruction for taint propagation."""
        mnemonic = insn.mnemonic.lower()
        operands = insn.operands.lower()

        # Parse operands
        ops = [o.strip() for o in operands.split(',') if o.strip()]

        # Get destination and sources
        if not ops:
            return

        dest = ops[0]
        sources = ops[1:] if len(ops) > 1 else []

        # Check for taint clearing
        if self._should_clear_taint(mnemonic, ops):
            self._clear_reg_taint(dest)
            return

        # Calculate propagated taint
        propagated_color = TaintColor.NONE
        propagated_sources: set[str] = set()

        # Check source operands for taint
        for src in sources:
            # Check register
            if src.startswith(('x', 'w', 'r')) and src not in ('#', '['):
                reg_name = src.split('[')[0].strip()
                state = self._get_reg_taint(reg_name)
                propagated_color |= state.color
                propagated_sources |= state.sources

            # Check memory reference
            if '[' in src:
                mem_addr = self._extract_memory_address(src)
                if mem_addr:
                    mem_taint = self._memory_taint.get_taint(mem_addr)
                    propagated_color |= mem_taint.color
                    propagated_sources |= mem_taint.sources

        # Propagate taint to destination
        if propagated_color != TaintColor.NONE:
            if dest.startswith(('x', 'w', 'r')) and '[' not in dest:
                # Destination is register
                state = TaintState(
                    color=propagated_color,
                    sources=propagated_sources,
                    last_modified_pc=pc,
                )
                self._register_taint[dest] = state
                self._stats['taints_propagated'] += 1
            elif '[' in dest:
                # Destination is memory
                mem_addr = self._extract_memory_address(dest)
                if mem_addr:
                    state = TaintState(
                        color=propagated_color,
                        sources=propagated_sources,
                        last_modified_pc=pc,
                    )
                    self._memory_taint.set_taint(mem_addr, 8, state)
                    self._stats['taints_propagated'] += 1

            # Check for control flow influence
            if mnemonic.startswith('b') and self.policy.alert_on_branch:
                self._check_control_flow_taint(pc, propagated_color, propagated_sources)

            # Check for dangerous function call
            if mnemonic in ('bl', 'blr') and self.policy.alert_on_call:
                self._check_call_taint(pc, propagated_color, propagated_sources)

    def _should_clear_taint(self, mnemonic: str, ops: list[str]) -> bool:
        """Check if instruction clears taint."""
        # mov reg, #const
        if mnemonic in ('mov', 'movz', 'movn') and len(ops) >= 2:
            if ops[1].startswith('#') and self.policy.clear_on_constant:
                return True

        # xor reg, reg, reg (clear)
        if mnemonic == 'eor' and len(ops) >= 3:
            if ops[1] == ops[2] and self.policy.clear_on_xor_self:
                return True

        return False

    def _extract_memory_address(self, operand: str) -> int | None:
        """Extract memory address from operand like [x0, #0x10]."""
        import re

        # Try to find base register
        match = re.search(r'\[(\w+)', operand)
        if not match:
            return None

        base_reg = match.group(1)

        # Get base register value
        try:
            base_value = self.emulator.get_register(base_reg)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return None

        # Look for offset
        offset = 0
        offset_match = re.search(r'#(0x[0-9a-f]+|\d+)', operand)
        if offset_match:
            val = offset_match.group(1)
            offset = int(val, 16) if val.startswith('0x') else int(val)

        return base_value + offset

    def _check_control_flow_taint(self, pc: int, color: TaintColor,
                                  sources: set[str]) -> None:
        """Check if tainted data influences control flow."""
        # Find matching sink
        for sink in self._sinks:
            if sink.function or sink.address == pc:
                if color & sink.alert_colors:
                    self._generate_alert(pc, color, sources, sink)

    def _check_call_taint(self, pc: int, color: TaintColor,
                          sources: set[str]) -> None:
        """Check if tainted data is passed to dangerous function."""
        # Check if any argument register is tainted
        for reg in ['x0', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7']:
            state = self._get_reg_taint(reg)
            if state.color != TaintColor.NONE:
                # Check against dangerous functions
                for sink in self._sinks:
                    if sink.function and state.color & sink.alert_colors:
                        self._generate_alert(pc, state.color, state.sources, sink)

    def _generate_alert(self, pc: int, color: TaintColor,
                        sources: set[str], sink: TaintSink) -> None:
        """Generate taint alert."""
        import time

        # Find matching source
        source = None
        for src in self._sources:
            if src.name in sources:
                source = src
                break

        if not source:
            source = TaintSource(name=list(sources)[0] if sources else "unknown",
                                color=color)

        alert = TaintAlert(
            source=source,
            sink=sink,
            color=color,
            address=pc,
            timestamp=time.time(),
        )

        self._alerts.append(alert)
        self._stats['alerts_generated'] += 1

        logger.warning(str(alert))

        # Call callbacks
        for callback in self._alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                logger.error(f"Alert callback error: {e}")

    # ==================== Memory Hooks ====================

    def _on_mem_read(self, uc, access, address: int, size: int,
                     value: int, user_data) -> None:
        """Track memory reads."""
        if not self._active:
            return

        # Check if reading from tainted memory
        if self._memory_taint.is_tainted(address, size):
            # Taint will be propagated by instruction analysis
            pass

    def _on_mem_write(self, uc, access, address: int, size: int,
                      value: int, user_data) -> None:
        """Track memory writes."""
        if not self._active:
            return

        # Check for writing to sink
        for sink in self._sinks:
            if sink.matches(addr=address):
                mem_taint = self._memory_taint.get_taint_range(address, size)
                if mem_taint & sink.alert_colors:
                    pc = self.emulator.uc.reg_read(self.emulator.pc_reg)
                    state = self._memory_taint.get_taint(address)
                    self._generate_alert(pc, mem_taint, state.sources, sink)

    # ==================== Callbacks ====================

    def add_alert_callback(self, callback: Callable[[TaintAlert], None]) -> None:
        """Add callback for taint alerts."""
        self._alert_callbacks.append(callback)

    def remove_alert_callback(self, callback: Callable[[TaintAlert], None]) -> None:
        """Remove alert callback."""
        if callback in self._alert_callbacks:
            self._alert_callbacks.remove(callback)

    # ==================== Query Methods ====================

    def is_register_tainted(self, reg: str) -> bool:
        """Check if register is tainted."""
        state = self._get_reg_taint(reg)
        return state.color != TaintColor.NONE

    def is_memory_tainted(self, address: int, size: int = 1) -> bool:
        """Check if memory is tainted."""
        return self._memory_taint.is_tainted(address, size)

    def get_taint_color(self, address: int = None, reg: str = None) -> TaintColor:
        """Get taint color for address or register."""
        if address is not None:
            return self._memory_taint.get_taint(address).color
        if reg is not None:
            return self._get_reg_taint(reg).color
        return TaintColor.NONE

    def get_taint_sources(self, address: int = None, reg: str = None) -> set[str]:
        """Get source names for tainted data."""
        if address is not None:
            return self._memory_taint.get_taint(address).sources
        if reg is not None:
            return self._get_reg_taint(reg).sources
        return set()

    # ==================== Reporting ====================

    def print_summary(self) -> None:
        """Print taint analysis summary."""
        print("=== Taint Analysis Summary ===")
        print(f"Instructions analyzed: {self._stats['instructions_analyzed']}")
        print(f"Taints propagated: {self._stats['taints_propagated']}")
        print(f"Alerts generated: {self._stats['alerts_generated']}")
        print(f"Tainted memory bytes: {self._memory_taint.tainted_count}")
        print(f"Tainted registers: {len(self._register_taint)}")
        print()

        if self._alerts:
            print("Alerts:")
            for alert in self._alerts:
                print(f"  {alert}")

    def print_tainted_registers(self) -> None:
        """Print tainted registers."""
        print("Tainted Registers:")
        for reg, state in sorted(self._register_taint.items()):
            if state.color != TaintColor.NONE:
                sources = ', '.join(state.sources)
                print(f"  {reg}: {state.color.name} (from: {sources})")

    def print_tainted_memory(self) -> None:
        """Print tainted memory ranges."""
        print("Tainted Memory:")
        for start, end, color in self._memory_taint.get_tainted_ranges():
            print(f"  0x{start:x} - 0x{end:x}: {color.name}")

    def export_alerts(self) -> list[dict]:
        """Export alerts as serializable format."""
        return [
            {
                'source': alert.source.name,
                'sink': alert.sink.name,
                'color': alert.color.name,
                'address': alert.address,
                'timestamp': alert.timestamp,
            }
            for alert in self._alerts
        ]
