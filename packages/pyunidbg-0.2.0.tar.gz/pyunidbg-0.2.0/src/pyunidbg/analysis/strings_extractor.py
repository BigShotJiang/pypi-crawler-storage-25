"""
Native library string extractor.

Scans ELF data sections for printable ASCII and UTF-16LE strings,
similar to the ``strings`` command-line utility.
"""

from __future__ import annotations

import re
import struct
from dataclasses import dataclass
from typing import Any

# Sections that are good candidates for string content
_DATA_SECTION_NAMES = {".rodata", ".data", ".data.rel.ro", ".constdata"}


@dataclass
class StringEntry:
    address: int
    value: str
    length: int
    encoding: str
    section: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "value": self.value,
            "length": self.length,
            "encoding": self.encoding,
            "section": self.section,
        }


def _scan_ascii(data: bytes, base_addr: int, min_length: int,
                section: str) -> list[StringEntry]:
    """Yield printable ASCII string runs of at least *min_length* chars."""
    results: list[StringEntry] = []
    # Match sequences of printable ASCII (0x20–0x7e) + common whitespace
    pattern = re.compile(rb'[ -~\t\r\n]{' + str(min_length).encode() + rb',}')
    for m in pattern.finditer(data):
        s = m.group(0).decode("ascii", errors="replace").rstrip("\x00")
        if len(s) >= min_length:
            results.append(StringEntry(
                address=base_addr + m.start(),
                value=s,
                length=len(s),
                encoding="ascii",
                section=section,
            ))
    return results


def _scan_utf16(data: bytes, base_addr: int, min_length: int,
                section: str) -> list[StringEntry]:
    """Yield UTF-16LE string runs of at least *min_length* chars."""
    results: list[StringEntry] = []
    i = 0
    n = len(data)
    while i + 2 <= n:
        # Find start of a potential UTF-16LE printable sequence
        code = struct.unpack_from("<H", data, i)[0]
        if 0x20 <= code <= 0x7e or code in (0x09, 0x0a, 0x0d):
            j = i
            chars = []
            while j + 2 <= n:
                c = struct.unpack_from("<H", data, j)[0]
                if 0x20 <= c <= 0x7e or c in (0x09, 0x0a, 0x0d):
                    chars.append(chr(c))
                    j += 2
                else:
                    break
            if len(chars) >= min_length:
                s = "".join(chars)
                results.append(StringEntry(
                    address=base_addr + i,
                    value=s,
                    length=len(s),
                    encoding="utf16",
                    section=section,
                ))
            i = j if j > i else i + 2
        else:
            i += 2
    return results


def extract_strings(library_path: str, min_length: int = 4,
                    encoding: str = "all") -> dict[str, Any]:
    """
    Extract strings from *library_path*.

    Parameters
    ----------
    library_path:
        Path to an ELF shared library on the host filesystem.
    min_length:
        Minimum string length to return (default 4).
    encoding:
        ``"ascii"``, ``"utf16"``, or ``"all"`` (default).

    Returns
    -------
    dict with keys ``strings`` (list of dicts) and ``count``.
    """
    try:
        import lief
    except ImportError:
        return {"strings": [], "count": 0, "error": "lief is required for string extraction"}

    elf = lief.parse(library_path)
    if elf is None:
        return {"strings": [], "count": 0, "error": "Failed to parse ELF"}

    results: list[StringEntry] = []
    want_ascii = encoding in ("ascii", "all")
    want_utf16 = encoding in ("utf16", "all")

    for sec in elf.sections:
        # Skip executable sections and zero-size sections
        flags = int(sec.flags) if hasattr(sec.flags, "__int__") else 0
        # SHF_EXECINSTR = 0x4
        if flags & 0x4:
            continue
        if sec.size == 0:
            continue
        # Accept known data section names or sections flagged SHF_ALLOC (0x2) with content
        is_data = (
            sec.name in _DATA_SECTION_NAMES
            or sec.name.startswith(".rodata")
            or sec.name.startswith(".data")
            or (flags & 0x2 and not (flags & 0x4))
        )
        if not is_data:
            continue

        try:
            raw = bytes(sec.content)
        except Exception:
            continue

        base = sec.virtual_address
        if want_ascii:
            results.extend(_scan_ascii(raw, base, min_length, sec.name))
        if want_utf16:
            results.extend(_scan_utf16(raw, base, min_length, sec.name))

    # Deduplicate by address+encoding, sort by address
    seen: set = set()
    deduped: list[StringEntry] = []
    for s in sorted(results, key=lambda x: x.address):
        key = (s.address, s.encoding)
        if key not in seen:
            seen.add(key)
            deduped.append(s)

    return {
        "strings": [s.to_dict() for s in deduped],
        "count": len(deduped),
    }
