"""
Heap Analyzer - Analyze heap allocations during emulation.

Provides:
- Heap allocation tracking (malloc/free/realloc)
- Memory leak detection
- Use-after-free detection
- Double-free detection
- Heap overflow detection
- Heap visualization
- Memory statistics

Usage:
    from pyunidbg.analysis.heap import HeapAnalyzer
    
    # Create analyzer
    analyzer = HeapAnalyzer(emulator)
    
    # Start tracking
    analyzer.start()
    
    # Run emulation...
    
    # Get report
    report = analyzer.get_report()
    leaks = analyzer.detect_leaks()
"""

from __future__ import annotations

import json
import logging
import time
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import (
    TYPE_CHECKING,
    Any,
)

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator

__all__ = [
    "HeapAnalyzer",
    "HeapChunk",
    "HeapOperation",
    "HeapError",
    "HeapStats",
    "HeapReport",
    "AllocationState",
]

logger = logging.getLogger(__name__)


# ==================== Enums ====================

class AllocationState(Enum):
    """State of a heap allocation."""
    ALLOCATED = "allocated"
    FREED = "freed"
    REALLOCATED = "reallocated"


class HeapErrorType(Enum):
    """Types of heap errors."""
    DOUBLE_FREE = "double_free"
    USE_AFTER_FREE = "use_after_free"
    INVALID_FREE = "invalid_free"
    HEAP_OVERFLOW = "heap_overflow"
    HEAP_UNDERFLOW = "heap_underflow"
    UNINITIALIZED_READ = "uninitialized_read"
    MEMORY_LEAK = "memory_leak"
    NULL_DEREF = "null_dereference"
    MISALIGNED_ACCESS = "misaligned_access"


class OperationType(Enum):
    """Types of heap operations."""
    MALLOC = "malloc"
    FREE = "free"
    REALLOC = "realloc"
    CALLOC = "calloc"
    MEMALIGN = "memalign"
    MMAP = "mmap"
    MUNMAP = "munmap"


# ==================== Data Classes ====================

@dataclass
class HeapOperation:
    """A heap operation record."""
    operation: OperationType
    address: int
    size: int
    timestamp: float
    call_site: int = 0
    thread_id: int = 0
    old_address: int = 0  # For realloc
    old_size: int = 0     # For realloc
    result: int = 0       # Return value
    success: bool = True
    callstack: list[int] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "operation": self.operation.value,
            "address": hex(self.address),
            "size": self.size,
            "timestamp": self.timestamp,
            "call_site": hex(self.call_site),
            "thread_id": self.thread_id,
            "old_address": hex(self.old_address) if self.old_address else None,
            "old_size": self.old_size if self.old_size else None,
            "result": hex(self.result),
            "success": self.success,
            "callstack": [hex(addr) for addr in self.callstack],
        }


@dataclass
class HeapChunk:
    """A heap allocation chunk."""
    address: int
    size: int
    state: AllocationState = AllocationState.ALLOCATED
    allocated_at: float = 0.0
    freed_at: float = 0.0
    allocation_site: int = 0
    free_site: int = 0
    thread_id: int = 0

    # Tracking
    access_count: int = 0
    read_count: int = 0
    write_count: int = 0
    last_access: float = 0.0

    # Metadata
    tag: str = ""
    allocation_callstack: list[int] = field(default_factory=list)
    free_callstack: list[int] = field(default_factory=list)

    # Shadow memory for tracking
    initialized: bytearray | None = None

    @property
    def end_address(self) -> int:
        return self.address + self.size

    @property
    def is_allocated(self) -> bool:
        return self.state == AllocationState.ALLOCATED

    @property
    def is_freed(self) -> bool:
        return self.state == AllocationState.FREED

    def contains(self, address: int) -> bool:
        return self.address <= address < self.end_address

    def to_dict(self) -> dict[str, Any]:
        return {
            "address": hex(self.address),
            "size": self.size,
            "state": self.state.value,
            "allocated_at": self.allocated_at,
            "freed_at": self.freed_at,
            "allocation_site": hex(self.allocation_site),
            "free_site": hex(self.free_site) if self.free_site else None,
            "thread_id": self.thread_id,
            "access_count": self.access_count,
            "tag": self.tag,
        }


@dataclass
class HeapError:
    """A heap error detected during analysis."""
    error_type: HeapErrorType
    address: int
    chunk: HeapChunk | None
    access_site: int
    timestamp: float
    message: str = ""
    callstack: list[int] = field(default_factory=list)
    severity: str = "high"  # high, medium, low

    def to_dict(self) -> dict[str, Any]:
        return {
            "type": self.error_type.value,
            "address": hex(self.address),
            "chunk": self.chunk.to_dict() if self.chunk else None,
            "access_site": hex(self.access_site),
            "timestamp": self.timestamp,
            "message": self.message,
            "callstack": [hex(addr) for addr in self.callstack],
            "severity": self.severity,
        }


@dataclass
class HeapStats:
    """Heap usage statistics."""
    total_allocations: int = 0
    total_frees: int = 0
    total_reallocs: int = 0
    current_allocations: int = 0
    peak_allocations: int = 0
    total_bytes_allocated: int = 0
    total_bytes_freed: int = 0
    current_bytes_used: int = 0
    peak_bytes_used: int = 0

    # Size distribution
    allocations_by_size: dict[str, int] = field(default_factory=dict)

    # Errors
    double_frees: int = 0
    use_after_frees: int = 0
    invalid_frees: int = 0
    leaks_detected: int = 0
    overflows_detected: int = 0

    # Timing
    start_time: float = 0.0
    end_time: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_allocations": self.total_allocations,
            "total_frees": self.total_frees,
            "total_reallocs": self.total_reallocs,
            "current_allocations": self.current_allocations,
            "peak_allocations": self.peak_allocations,
            "total_bytes_allocated": self.total_bytes_allocated,
            "total_bytes_freed": self.total_bytes_freed,
            "current_bytes_used": self.current_bytes_used,
            "peak_bytes_used": self.peak_bytes_used,
            "allocations_by_size": self.allocations_by_size,
            "double_frees": self.double_frees,
            "use_after_frees": self.use_after_frees,
            "invalid_frees": self.invalid_frees,
            "leaks_detected": self.leaks_detected,
            "overflows_detected": self.overflows_detected,
            "duration": self.end_time - self.start_time if self.end_time else 0,
        }


@dataclass
class HeapReport:
    """Complete heap analysis report."""
    stats: HeapStats
    errors: list[HeapError]
    leaks: list[HeapChunk]
    allocations: list[HeapChunk]
    operations: list[HeapOperation]

    def to_dict(self) -> dict[str, Any]:
        return {
            "stats": self.stats.to_dict(),
            "errors": [e.to_dict() for e in self.errors],
            "leaks": [l.to_dict() for l in self.leaks],
            "allocations": [a.to_dict() for a in self.allocations],
            "operations": [o.to_dict() for o in self.operations],
        }

    def to_json(self, path: str | Path) -> None:
        """Export report to JSON file."""
        with open(path, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)


# ==================== Heap Analyzer ====================

class HeapAnalyzer:
    """
    Heap memory analyzer for detecting memory issues.
    
    Features:
    - Track malloc/free/realloc operations
    - Detect double-free, use-after-free
    - Detect heap overflow/underflow
    - Detect memory leaks
    - Track access patterns
    - Generate detailed reports
    """

    # Default allocator function names
    DEFAULT_ALLOC_FUNCS = {
        "malloc": OperationType.MALLOC,
        "free": OperationType.FREE,
        "realloc": OperationType.REALLOC,
        "calloc": OperationType.CALLOC,
        "memalign": OperationType.MEMALIGN,
        "aligned_alloc": OperationType.MEMALIGN,
        "mmap": OperationType.MMAP,
        "munmap": OperationType.MUNMAP,
    }

    # Size categories for statistics
    SIZE_CATEGORIES = [
        ("tiny", 0, 16),
        ("small", 17, 64),
        ("medium", 65, 256),
        ("large", 257, 1024),
        ("huge", 1025, 4096),
        ("giant", 4097, float('inf')),
    ]

    def __init__(
        self,
        emulator: Emulator | None = None,
        track_uninitialized: bool = False,
        redzone_size: int = 0,
        quarantine_size: int = 100,
    ):
        self._emulator = emulator
        self._track_uninitialized = track_uninitialized
        self._redzone_size = redzone_size
        self._quarantine_size = quarantine_size

        # Heap state
        self._chunks: dict[int, HeapChunk] = {}
        self._freed_chunks: dict[int, HeapChunk] = {}  # Quarantine
        self._operations: list[HeapOperation] = []
        self._errors: list[HeapError] = []

        # Statistics
        self._stats = HeapStats()

        # Hooks
        self._original_hooks: dict[int, Callable] = {}
        self._active = False

        # Callbacks
        self._on_alloc: Callable | None = None
        self._on_free: Callable | None = None
        self._on_error: Callable | None = None

        # Initialize size distribution
        for name, _, _ in self.SIZE_CATEGORIES:
            self._stats.allocations_by_size[name] = 0

    @property
    def active(self) -> bool:
        """Check if analyzer is active."""
        return self._active

    @property
    def stats(self) -> HeapStats:
        """Get current statistics."""
        return self._stats

    @property
    def chunks(self) -> dict[int, HeapChunk]:
        """Get active heap chunks."""
        return self._chunks.copy()

    @property
    def errors(self) -> list[HeapError]:
        """Get detected errors."""
        return self._errors.copy()

    def start(self) -> None:
        """Start heap analysis."""
        self._active = True
        self._stats.start_time = time.time()
        logger.info("Heap analyzer started")

    def stop(self) -> None:
        """Stop heap analysis."""
        self._active = False
        self._stats.end_time = time.time()
        logger.info("Heap analyzer stopped")

    def reset(self) -> None:
        """Reset analyzer state."""
        self._chunks.clear()
        self._freed_chunks.clear()
        self._operations.clear()
        self._errors.clear()
        self._stats = HeapStats()
        for name, _, _ in self.SIZE_CATEGORIES:
            self._stats.allocations_by_size[name] = 0

    # ==================== Allocation Tracking ====================

    def on_malloc(
        self,
        address: int,
        size: int,
        call_site: int = 0,
        callstack: list[int] = None,
    ) -> None:
        """Record a malloc operation."""
        if not self._active:
            return

        timestamp = time.time()

        # Check for overlapping allocations
        for chunk in self._chunks.values():
            if chunk.contains(address) or chunk.contains(address + size - 1):
                self._record_error(
                    HeapErrorType.HEAP_OVERFLOW,
                    address,
                    chunk,
                    call_site,
                    "Overlapping allocation detected",
                    callstack,
                )

        # Create chunk
        chunk = HeapChunk(
            address=address,
            size=size,
            state=AllocationState.ALLOCATED,
            allocated_at=timestamp,
            allocation_site=call_site,
            allocation_callstack=callstack or [],
        )

        # Track uninitialized memory
        if self._track_uninitialized:
            chunk.initialized = bytearray(size)  # All zeros = uninitialized

        self._chunks[address] = chunk

        # Record operation
        op = HeapOperation(
            operation=OperationType.MALLOC,
            address=address,
            size=size,
            timestamp=timestamp,
            call_site=call_site,
            result=address,
            callstack=callstack or [],
        )
        self._operations.append(op)

        # Update stats
        self._update_alloc_stats(size)

        # Callback
        if self._on_alloc:
            self._on_alloc(chunk)

        logger.debug(f"malloc({size}) = {hex(address)}")

    def on_free(
        self,
        address: int,
        call_site: int = 0,
        callstack: list[int] = None,
    ) -> None:
        """Record a free operation."""
        if not self._active:
            return

        timestamp = time.time()

        # Check for invalid free (NULL)
        if address == 0:
            # free(NULL) is valid
            return

        # Check for double-free
        if address in self._freed_chunks:
            old_chunk = self._freed_chunks[address]
            self._record_error(
                HeapErrorType.DOUBLE_FREE,
                address,
                old_chunk,
                call_site,
                f"Double free detected. Originally freed at {hex(old_chunk.free_site)}",
                callstack,
            )
            self._stats.double_frees += 1
            return

        # Check for invalid free (never allocated)
        if address not in self._chunks:
            self._record_error(
                HeapErrorType.INVALID_FREE,
                address,
                None,
                call_site,
                "Freeing address that was never allocated",
                callstack,
            )
            self._stats.invalid_frees += 1
            return

        chunk = self._chunks.pop(address)
        chunk.state = AllocationState.FREED
        chunk.freed_at = timestamp
        chunk.free_site = call_site
        chunk.free_callstack = callstack or []

        # Add to quarantine
        self._freed_chunks[address] = chunk
        self._trim_quarantine()

        # Record operation
        op = HeapOperation(
            operation=OperationType.FREE,
            address=address,
            size=chunk.size,
            timestamp=timestamp,
            call_site=call_site,
            callstack=callstack or [],
        )
        self._operations.append(op)

        # Update stats
        self._update_free_stats(chunk.size)

        # Callback
        if self._on_free:
            self._on_free(chunk)

        logger.debug(f"free({hex(address)})")

    def on_realloc(
        self,
        old_address: int,
        new_address: int,
        new_size: int,
        call_site: int = 0,
        callstack: list[int] = None,
    ) -> None:
        """Record a realloc operation."""
        if not self._active:
            return

        timestamp = time.time()
        old_size = 0

        # Handle realloc(NULL, size) = malloc(size)
        if old_address == 0:
            self.on_malloc(new_address, new_size, call_site, callstack)
            return

        # Handle realloc(ptr, 0) = free(ptr)
        if new_size == 0:
            self.on_free(old_address, call_site, callstack)
            return

        # Get old chunk
        if old_address in self._chunks:
            old_chunk = self._chunks.pop(old_address)
            old_size = old_chunk.size
        elif old_address in self._freed_chunks:
            # Use after free via realloc
            old_chunk = self._freed_chunks[old_address]
            self._record_error(
                HeapErrorType.USE_AFTER_FREE,
                old_address,
                old_chunk,
                call_site,
                "Realloc on freed memory",
                callstack,
            )
            self._stats.use_after_frees += 1
            return
        else:
            # Invalid realloc
            self._record_error(
                HeapErrorType.INVALID_FREE,
                old_address,
                None,
                call_site,
                "Realloc on invalid address",
                callstack,
            )
            return

        # Create new chunk
        chunk = HeapChunk(
            address=new_address,
            size=new_size,
            state=AllocationState.REALLOCATED,
            allocated_at=timestamp,
            allocation_site=call_site,
            allocation_callstack=callstack or [],
        )

        self._chunks[new_address] = chunk

        # Record operation
        op = HeapOperation(
            operation=OperationType.REALLOC,
            address=new_address,
            size=new_size,
            old_address=old_address,
            old_size=old_size,
            timestamp=timestamp,
            call_site=call_site,
            result=new_address,
            callstack=callstack or [],
        )
        self._operations.append(op)

        # Update stats
        self._stats.total_reallocs += 1
        size_diff = new_size - old_size
        if size_diff > 0:
            self._stats.total_bytes_allocated += size_diff
            self._stats.current_bytes_used += size_diff
        else:
            self._stats.total_bytes_freed += abs(size_diff)
            self._stats.current_bytes_used += size_diff

        if self._stats.current_bytes_used > self._stats.peak_bytes_used:
            self._stats.peak_bytes_used = self._stats.current_bytes_used

        logger.debug(f"realloc({hex(old_address)}, {new_size}) = {hex(new_address)}")

    def on_calloc(
        self,
        address: int,
        nmemb: int,
        size: int,
        call_site: int = 0,
        callstack: list[int] = None,
    ) -> None:
        """Record a calloc operation."""
        total_size = nmemb * size
        self.on_malloc(address, total_size, call_site, callstack)

        # Calloc zeros memory, so mark as initialized
        if self._track_uninitialized and address in self._chunks:
            chunk = self._chunks[address]
            if chunk.initialized:
                chunk.initialized = bytearray(b'\xff' * total_size)

    # ==================== Memory Access Tracking ====================

    def on_read(
        self,
        address: int,
        size: int,
        access_site: int = 0,
        callstack: list[int] = None,
    ) -> None:
        """Record a memory read access."""
        if not self._active:
            return

        chunk = self._find_chunk(address)

        if chunk:
            if chunk.is_freed:
                # Use after free
                self._record_error(
                    HeapErrorType.USE_AFTER_FREE,
                    address,
                    chunk,
                    access_site,
                    f"Reading from freed memory (freed at {hex(chunk.free_site)})",
                    callstack,
                )
                self._stats.use_after_frees += 1
            else:
                # Update access stats
                chunk.access_count += 1
                chunk.read_count += 1
                chunk.last_access = time.time()

                # Check for overflow
                if address + size > chunk.end_address:
                    self._record_error(
                        HeapErrorType.HEAP_OVERFLOW,
                        address,
                        chunk,
                        access_site,
                        f"Read overflow: {address + size - chunk.end_address} bytes past end",
                        callstack,
                    )
                    self._stats.overflows_detected += 1

                # Check for uninitialized read
                if self._track_uninitialized and chunk.initialized:
                    offset = address - chunk.address
                    for i in range(size):
                        if offset + i < len(chunk.initialized):
                            if chunk.initialized[offset + i] == 0:
                                self._record_error(
                                    HeapErrorType.UNINITIALIZED_READ,
                                    address + i,
                                    chunk,
                                    access_site,
                                    "Reading uninitialized memory",
                                    callstack,
                                    severity="medium",
                                )
                                break
        else:
            # Check freed chunks for UAF
            freed_chunk = self._find_freed_chunk(address)
            if freed_chunk:
                self._record_error(
                    HeapErrorType.USE_AFTER_FREE,
                    address,
                    freed_chunk,
                    access_site,
                    "Reading from freed memory",
                    callstack,
                )
                self._stats.use_after_frees += 1

    def on_write(
        self,
        address: int,
        size: int,
        access_site: int = 0,
        callstack: list[int] = None,
    ) -> None:
        """Record a memory write access."""
        if not self._active:
            return

        chunk = self._find_chunk(address)

        if chunk:
            if chunk.is_freed:
                self._record_error(
                    HeapErrorType.USE_AFTER_FREE,
                    address,
                    chunk,
                    access_site,
                    f"Writing to freed memory (freed at {hex(chunk.free_site)})",
                    callstack,
                )
                self._stats.use_after_frees += 1
            else:
                chunk.access_count += 1
                chunk.write_count += 1
                chunk.last_access = time.time()

                # Check for overflow
                if address + size > chunk.end_address:
                    self._record_error(
                        HeapErrorType.HEAP_OVERFLOW,
                        address,
                        chunk,
                        access_site,
                        f"Write overflow: {address + size - chunk.end_address} bytes past end",
                        callstack,
                    )
                    self._stats.overflows_detected += 1

                # Check for underflow
                if address < chunk.address:
                    self._record_error(
                        HeapErrorType.HEAP_UNDERFLOW,
                        address,
                        chunk,
                        access_site,
                        f"Write underflow: {chunk.address - address} bytes before start",
                        callstack,
                    )

                # Mark as initialized
                if self._track_uninitialized and chunk.initialized:
                    offset = address - chunk.address
                    for i in range(min(size, len(chunk.initialized) - offset)):
                        if offset + i < len(chunk.initialized):
                            chunk.initialized[offset + i] = 0xff
        else:
            freed_chunk = self._find_freed_chunk(address)
            if freed_chunk:
                self._record_error(
                    HeapErrorType.USE_AFTER_FREE,
                    address,
                    freed_chunk,
                    access_site,
                    "Writing to freed memory",
                    callstack,
                )
                self._stats.use_after_frees += 1

    # ==================== Detection ====================

    def detect_leaks(self) -> list[HeapChunk]:
        """Detect memory leaks (allocations that were never freed)."""
        leaks = []
        for chunk in self._chunks.values():
            if chunk.is_allocated:
                leaks.append(chunk)
                self._record_error(
                    HeapErrorType.MEMORY_LEAK,
                    chunk.address,
                    chunk,
                    chunk.allocation_site,
                    f"Memory leak: {chunk.size} bytes allocated but never freed",
                    chunk.allocation_callstack,
                    severity="medium",
                )

        self._stats.leaks_detected = len(leaks)
        return leaks

    def check_bounds(self, address: int, size: int) -> HeapError | None:
        """Check if memory access is within bounds."""
        chunk = self._find_chunk(address)

        if not chunk:
            return None

        if address + size > chunk.end_address:
            return HeapError(
                error_type=HeapErrorType.HEAP_OVERFLOW,
                address=address,
                chunk=chunk,
                access_site=0,
                timestamp=time.time(),
                message=f"Access would overflow by {address + size - chunk.end_address} bytes",
            )

        if address < chunk.address:
            return HeapError(
                error_type=HeapErrorType.HEAP_UNDERFLOW,
                address=address,
                chunk=chunk,
                access_site=0,
                timestamp=time.time(),
                message=f"Access would underflow by {chunk.address - address} bytes",
            )

        return None

    # ==================== Reporting ====================

    def get_report(self) -> HeapReport:
        """Generate complete heap analysis report."""
        # Detect leaks first
        leaks = self.detect_leaks()

        return HeapReport(
            stats=self._stats,
            errors=self._errors,
            leaks=leaks,
            allocations=list(self._chunks.values()),
            operations=self._operations,
        )

    def get_allocation(self, address: int) -> HeapChunk | None:
        """Get allocation at or containing address."""
        if address in self._chunks:
            return self._chunks[address]
        return self._find_chunk(address)

    def get_allocations_by_site(self, call_site: int) -> list[HeapChunk]:
        """Get all allocations from a specific call site."""
        return [c for c in self._chunks.values() if c.allocation_site == call_site]

    def get_hotspots(self, top_n: int = 10) -> list[tuple[int, int]]:
        """Get allocation hotspots (sites with most allocations)."""
        site_counts = defaultdict(int)
        for op in self._operations:
            if op.operation in (OperationType.MALLOC, OperationType.CALLOC):
                site_counts[op.call_site] += 1

        sorted_sites = sorted(site_counts.items(), key=lambda x: x[1], reverse=True)
        return sorted_sites[:top_n]

    def print_summary(self) -> str:
        """Print a summary of heap analysis."""
        lines = [
            "=" * 60,
            "Heap Analysis Summary",
            "=" * 60,
            f"Total allocations: {self._stats.total_allocations}",
            f"Total frees: {self._stats.total_frees}",
            f"Total reallocs: {self._stats.total_reallocs}",
            f"Current allocations: {self._stats.current_allocations}",
            f"Peak allocations: {self._stats.peak_allocations}",
            "",
            f"Total bytes allocated: {self._stats.total_bytes_allocated:,}",
            f"Total bytes freed: {self._stats.total_bytes_freed:,}",
            f"Current bytes used: {self._stats.current_bytes_used:,}",
            f"Peak bytes used: {self._stats.peak_bytes_used:,}",
            "",
            "Size distribution:",
        ]

        for name, count in self._stats.allocations_by_size.items():
            if count > 0:
                lines.append(f"  {name}: {count}")

        lines.extend([
            "",
            "Errors:",
            f"  Double frees: {self._stats.double_frees}",
            f"  Use after frees: {self._stats.use_after_frees}",
            f"  Invalid frees: {self._stats.invalid_frees}",
            f"  Leaks detected: {self._stats.leaks_detected}",
            f"  Overflows detected: {self._stats.overflows_detected}",
            "=" * 60,
        ])

        return "\n".join(lines)

    # ==================== Callbacks ====================

    def set_alloc_callback(self, callback: Callable[[HeapChunk], None]) -> None:
        """Set callback for allocations."""
        self._on_alloc = callback

    def set_free_callback(self, callback: Callable[[HeapChunk], None]) -> None:
        """Set callback for frees."""
        self._on_free = callback

    def set_error_callback(self, callback: Callable[[HeapError], None]) -> None:
        """Set callback for errors."""
        self._on_error = callback

    # ==================== Internal Methods ====================

    def _find_chunk(self, address: int) -> HeapChunk | None:
        """Find chunk containing address."""
        for chunk in self._chunks.values():
            if chunk.contains(address):
                return chunk
        return None

    def _find_freed_chunk(self, address: int) -> HeapChunk | None:
        """Find freed chunk containing address."""
        for chunk in self._freed_chunks.values():
            if chunk.contains(address):
                return chunk
        return None

    def _trim_quarantine(self) -> None:
        """Trim quarantine if too large."""
        while len(self._freed_chunks) > self._quarantine_size:
            oldest = min(self._freed_chunks.values(), key=lambda c: c.freed_at)
            del self._freed_chunks[oldest.address]

    def _update_alloc_stats(self, size: int) -> None:
        """Update allocation statistics."""
        self._stats.total_allocations += 1
        self._stats.current_allocations += 1
        self._stats.total_bytes_allocated += size
        self._stats.current_bytes_used += size

        if self._stats.current_allocations > self._stats.peak_allocations:
            self._stats.peak_allocations = self._stats.current_allocations

        if self._stats.current_bytes_used > self._stats.peak_bytes_used:
            self._stats.peak_bytes_used = self._stats.current_bytes_used

        # Categorize size
        for name, min_size, max_size in self.SIZE_CATEGORIES:
            if min_size <= size <= max_size:
                self._stats.allocations_by_size[name] += 1
                break

    def _update_free_stats(self, size: int) -> None:
        """Update free statistics."""
        self._stats.total_frees += 1
        self._stats.current_allocations -= 1
        self._stats.total_bytes_freed += size
        self._stats.current_bytes_used -= size

    def _record_error(
        self,
        error_type: HeapErrorType,
        address: int,
        chunk: HeapChunk | None,
        access_site: int,
        message: str,
        callstack: list[int] = None,
        severity: str = "high",
    ) -> None:
        """Record a heap error."""
        error = HeapError(
            error_type=error_type,
            address=address,
            chunk=chunk,
            access_site=access_site,
            timestamp=time.time(),
            message=message,
            callstack=callstack or [],
            severity=severity,
        )
        self._errors.append(error)

        if self._on_error:
            self._on_error(error)

        logger.warning(f"Heap error: {error_type.value} at {hex(address)}: {message}")

    def _categorize_size(self, size: int) -> str:
        """Categorize allocation size."""
        for name, min_size, max_size in self.SIZE_CATEGORIES:
            if min_size <= size <= max_size:
                return name
        return "unknown"

    def __repr__(self) -> str:
        status = "active" if self._active else "inactive"
        return f"HeapAnalyzer({status}, chunks={len(self._chunks)}, errors={len(self._errors)})"
