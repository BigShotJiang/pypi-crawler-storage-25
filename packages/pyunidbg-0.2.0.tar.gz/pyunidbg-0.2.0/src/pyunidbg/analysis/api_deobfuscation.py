"""
Automatic API Deobfuscation Module for PyUniDbg.

Monitors and resolves dynamic API imports that binaries perform at
runtime via GetProcAddress (Windows), dlsym (Linux/Android), or
custom hash-based resolution routines.

Features:
- Hook dlsym / GetProcAddress / dlopen to capture dynamic imports
- Detect API-hashing patterns (e.g. ROR13, CRC32, DJB2 based)
- Build a resolved API table mapping addresses to function names
- Detect string decryption routines that produce API names
- Reconstruct a clean import table from observed resolutions
- Pluggable hash algorithm database for known packer schemes

Usage:
    from pyunidbg.analysis.api_deobfuscation import APIDeobfuscator

    deobf = APIDeobfuscator(emulator)
    deobf.install_hooks()

    # ... run emulation ...

    for entry in deobf.resolved_apis:
        print(f"{entry.address:#x} -> {entry.name}")

    # Detect hash-based resolution
    deobf.scan_for_api_hashing()
"""

from __future__ import annotations

import logging
import struct
from collections import defaultdict
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum, auto
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..core.emulator import Emulator

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data types
# ---------------------------------------------------------------------------

class ResolutionMethod(Enum):
    """How the API was resolved."""
    DLSYM = auto()
    DLOPEN_DLSYM = auto()
    GET_PROC_ADDRESS = auto()
    HASH_LOOKUP = auto()
    STRING_DECRYPT = auto()
    MANUAL = auto()


@dataclass
class ResolvedAPI:
    """A single resolved API entry."""
    address: int
    name: str
    library: str = ""
    method: ResolutionMethod = ResolutionMethod.DLSYM
    caller_pc: int = 0
    call_count: int = 1
    hash_value: int = 0
    timestamp: int = 0

    def __repr__(self) -> str:
        lib = f"{self.library}!" if self.library else ""
        return f"ResolvedAPI({self.address:#x} -> {lib}{self.name}, via {self.method.name})"


@dataclass
class APIHashEntry:
    """Maps a known hash value to an API name."""
    hash_value: int
    api_name: str
    library: str = ""
    algorithm: str = ""


@dataclass
class StringDecryptEvent:
    """Captures a string decryption that produced an API name."""
    pc: int
    decrypted_string: str
    buffer_address: int
    encrypted_address: int = 0
    key: bytes = b""


# ---------------------------------------------------------------------------
# Known API-hashing algorithms
# ---------------------------------------------------------------------------

def _ror13_hash(name: str) -> int:
    """ROR13 hash used by many shellcode loaders."""
    h = 0
    for c in name:
        h = ((h >> 13) | (h << 19)) & 0xFFFFFFFF
        h = (h + ord(c)) & 0xFFFFFFFF
    return h


def _djb2_hash(name: str) -> int:
    """DJB2 hash."""
    h = 5381
    for c in name:
        h = ((h << 5) + h + ord(c)) & 0xFFFFFFFF
    return h


def _sdbm_hash(name: str) -> int:
    """SDBM hash."""
    h = 0
    for c in name:
        h = (ord(c) + (h << 6) + (h << 16) - h) & 0xFFFFFFFF
    return h


def _crc32_hash(name: str) -> int:
    import zlib
    return zlib.crc32(name.encode()) & 0xFFFFFFFF


HASH_ALGORITHMS: dict[str, Callable[[str], int]] = {
    "ror13": _ror13_hash,
    "djb2": _djb2_hash,
    "sdbm": _sdbm_hash,
    "crc32": _crc32_hash,
}

COMMON_API_NAMES: list[str] = [
    "dlopen", "dlsym", "dlclose", "dlerror",
    "malloc", "free", "calloc", "realloc",
    "memcpy", "memset", "memmove", "memcmp",
    "strlen", "strcpy", "strncpy", "strcmp", "strncmp", "strstr",
    "printf", "sprintf", "snprintf", "fprintf",
    "open", "close", "read", "write", "ioctl",
    "socket", "connect", "send", "recv", "bind", "listen", "accept",
    "mmap", "mprotect", "munmap",
    "fork", "execve", "exit", "getpid", "getuid",
    "pthread_create", "pthread_mutex_lock", "pthread_mutex_unlock",
    "__android_log_print", "JNI_OnLoad",
    "GetProcAddress", "LoadLibraryA", "LoadLibraryW",
    "VirtualAlloc", "VirtualProtect", "CreateThread",
    "NtAllocateVirtualMemory", "NtProtectVirtualMemory",
    "LdrLoadDll", "LdrGetProcedureAddress",
]


# ---------------------------------------------------------------------------
# Precomputed hash tables
# ---------------------------------------------------------------------------

def build_hash_table(
    algorithm: str,
    api_names: list[str] | None = None,
) -> dict[int, str]:
    """Build hash->name lookup for a given algorithm."""
    names = api_names or COMMON_API_NAMES
    fn = HASH_ALGORITHMS.get(algorithm)
    if not fn:
        return {}
    return {fn(name): name for name in names}


# ---------------------------------------------------------------------------
# Main deobfuscator
# ---------------------------------------------------------------------------

class APIDeobfuscator:
    """
    Monitors dynamic API resolution and resolves obfuscated imports.
    """

    def __init__(self, emulator: Emulator):
        self.emulator = emulator
        self._resolved: list[ResolvedAPI] = []
        self._by_address: dict[int, ResolvedAPI] = {}
        self._by_name: dict[str, list[ResolvedAPI]] = defaultdict(list)
        self._hooks: list[Any] = []
        self._hash_tables: dict[str, dict[int, str]] = {}
        self._decrypt_events: list[StringDecryptEvent] = []
        self._call_counter: int = 0

        self._build_default_hash_tables()

    @property
    def resolved_apis(self) -> list[ResolvedAPI]:
        return list(self._resolved)

    @property
    def decrypt_events(self) -> list[StringDecryptEvent]:
        return list(self._decrypt_events)

    # ------------------------------------------------------------------
    # Hook installation
    # ------------------------------------------------------------------

    def install_hooks(self) -> None:
        """Install hooks on dlsym/dlopen/GetProcAddress."""
        hook_targets = {
            "dlsym": self._on_dlsym,
            "dlopen": self._on_dlopen,
            "GetProcAddress": self._on_get_proc_address,
            "LdrGetProcedureAddress": self._on_ldr_get_proc,
        }

        from ..core.hooks import Hook, HookType

        for func_name, callback in hook_targets.items():
            addr = self.emulator.get_symbol(func_name)
            if addr is not None:
                hook = Hook(
                    hook_type=HookType.ADDRESS,
                    callback=callback,
                    address=addr,
                    name=f"api_deobf_{func_name}",
                )
                self.emulator.hook.add_hook(hook)
                self._hooks.append(hook)
                logger.debug("Hooked %s at %#x", func_name, addr)

        fn_hooks = self.emulator.hook.get_function_hooks("dlsym")
        if not fn_hooks and not any(h.name and "dlsym" in h.name for h in self._hooks):
            hook = Hook(
                hook_type=HookType.FUNCTION,
                callback=self._on_dlsym,
                name="dlsym",
            )
            if "dlsym" not in self.emulator.hook._function_hooks:
                self.emulator.hook._function_hooks["dlsym"] = []
            self.emulator.hook._function_hooks["dlsym"].append(hook)
            self.emulator.hook._hooks.append(hook)
            self._hooks.append(hook)

        logger.info("API deobfuscation hooks installed")

    def remove_hooks(self) -> None:
        for hook in self._hooks:
            try:
                self.emulator.hook.remove_hook(hook)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
        self._hooks.clear()

    # ------------------------------------------------------------------
    # Hook callbacks
    # ------------------------------------------------------------------

    def _on_dlsym(self, emu, address, size):
        self._call_counter += 1
        try:
            handle = emu.cpu.get_arg(0)
            name_ptr = emu.cpu.get_arg(1)
            name = emu.read_string(name_ptr)
            if name:
                self._record_pending_dlsym(address, name, "")
        except Exception as e:
            logger.debug("dlsym hook error: %s", e)

    def _on_dlopen(self, emu, address, size):
        try:
            path_ptr = emu.cpu.get_arg(0)
            if path_ptr:
                path = emu.read_string(path_ptr)
                logger.info("dlopen: %s", path)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

    def _on_get_proc_address(self, emu, address, size):
        self._call_counter += 1
        try:
            module_handle = emu.cpu.get_arg(0)
            name_ptr = emu.cpu.get_arg(1)
            if name_ptr > 0xFFFF:
                name = emu.read_string(name_ptr)
            else:
                name = f"ordinal_{name_ptr}"
            if name:
                self._record_pending_dlsym(address, name, "")
        except Exception as e:
            logger.debug("GetProcAddress hook error: %s", e)

    def _on_ldr_get_proc(self, emu, address, size):
        self._call_counter += 1
        try:
            name_ptr = emu.cpu.get_arg(2)
            name = emu.read_string(name_ptr)
            if name:
                self._record_pending_dlsym(address, name, "")
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

    def _record_pending_dlsym(self, caller_pc: int, name: str, library: str) -> None:
        entry = ResolvedAPI(
            address=0,
            name=name,
            library=library,
            method=ResolutionMethod.DLSYM,
            caller_pc=caller_pc,
            timestamp=self._call_counter,
        )
        self._resolved.append(entry)
        self._by_name[name].append(entry)
        logger.info("Dynamic API resolution: %s (called from %#x)", name, caller_pc)

    # ------------------------------------------------------------------
    # Hash-based API resolution detection
    # ------------------------------------------------------------------

    def scan_for_api_hashing(
        self,
        regions: list[tuple[int, int]] | None = None,
    ) -> list[ResolvedAPI]:
        """
        Scan code for constants matching known API hash values.
        """
        if regions is None:
            regions = self._get_code_regions()

        found: list[ResolvedAPI] = []
        for base, size in regions:
            try:
                data = self.emulator.memory.read(base, size)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)
                continue

            for algo_name, table in self._hash_tables.items():
                for hash_val, api_name in table.items():
                    needle = struct.pack("<I", hash_val & 0xFFFFFFFF)
                    idx = 0
                    while idx < len(data):
                        pos = data.find(needle, idx)
                        if pos == -1:
                            break
                        addr = base + pos
                        entry = ResolvedAPI(
                            address=addr,
                            name=api_name,
                            method=ResolutionMethod.HASH_LOOKUP,
                            hash_value=hash_val,
                        )
                        entry.library = algo_name
                        found.append(entry)
                        self._resolved.append(entry)
                        self._by_address[addr] = entry
                        self._by_name[api_name].append(entry)
                        idx = pos + 4

        logger.info("API hashing scan found %d potential resolutions", len(found))
        return found

    def add_hash_algorithm(
        self,
        name: str,
        hash_fn: Callable[[str], int],
        api_names: list[str] | None = None,
    ) -> None:
        """Register a custom hash algorithm for API resolution detection."""
        HASH_ALGORITHMS[name] = hash_fn
        self._hash_tables[name] = build_hash_table(name, api_names)

    # ------------------------------------------------------------------
    # String decryption monitoring
    # ------------------------------------------------------------------

    def monitor_string_decryption(
        self,
        output_buffer: int,
        buffer_size: int,
    ) -> None:
        """
        Watch a memory region for decrypted strings that match API names.
        """
        from unicorn import UC_HOOK_MEM_WRITE

        known_apis = set(COMMON_API_NAMES)

        def _on_write(uc, access, address, size, value, user_data):
            if output_buffer <= address < output_buffer + buffer_size:
                try:
                    s = self.emulator.read_string(output_buffer)
                    if s and s in known_apis:
                        pc = self.emulator.cpu.pc
                        evt = StringDecryptEvent(
                            pc=pc,
                            decrypted_string=s,
                            buffer_address=output_buffer,
                        )
                        self._decrypt_events.append(evt)

                        entry = ResolvedAPI(
                            address=output_buffer,
                            name=s,
                            method=ResolutionMethod.STRING_DECRYPT,
                            caller_pc=pc,
                        )
                        self._resolved.append(entry)
                        self._by_name[s].append(entry)
                        logger.info("String decryption produced API name: %s @ %#x", s, pc)
                except Exception:
                    logger.debug("Exception suppressed", exc_info=True)

        handle = self.emulator._uc.hook_add(
            UC_HOOK_MEM_WRITE, _on_write,
            begin=output_buffer, end=output_buffer + buffer_size)
        self._hooks.append(handle)

    # ------------------------------------------------------------------
    # Resolved table export
    # ------------------------------------------------------------------

    def get_import_table(self) -> dict[str, list[ResolvedAPI]]:
        """Group resolved APIs by library."""
        table: dict[str, list[ResolvedAPI]] = defaultdict(list)
        for entry in self._resolved:
            table[entry.library or "unknown"].append(entry)
        return dict(table)

    def lookup(self, address: int) -> ResolvedAPI | None:
        return self._by_address.get(address)

    def lookup_name(self, name: str) -> list[ResolvedAPI]:
        return self._by_name.get(name, [])

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _build_default_hash_tables(self) -> None:
        for algo in HASH_ALGORITHMS:
            self._hash_tables[algo] = build_hash_table(algo)

    def _get_code_regions(self) -> list[tuple[int, int]]:
        regions = []
        for r in self.emulator.memory.get_regions():
            if r.protection & 4:
                regions.append((r.start, r.size))
        return regions

    def reset(self) -> None:
        self.remove_hooks()
        self._resolved.clear()
        self._by_address.clear()
        self._by_name.clear()
        self._decrypt_events.clear()
        self._call_counter = 0


# ---------------------------------------------------------------------------
# Convenience
# ---------------------------------------------------------------------------

def create_api_deobfuscator(emulator: Emulator) -> APIDeobfuscator:
    return APIDeobfuscator(emulator)


__all__ = [
    "APIDeobfuscator",
    "ResolvedAPI",
    "ResolutionMethod",
    "APIHashEntry",
    "StringDecryptEvent",
    "HASH_ALGORITHMS",
    "COMMON_API_NAMES",
    "build_hash_table",
    "create_api_deobfuscator",
]
