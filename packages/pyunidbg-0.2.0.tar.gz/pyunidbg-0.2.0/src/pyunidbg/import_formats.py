"""
Import Formats module for PyUniDbg.

This module provides import functionality for various data formats:
- JSON import
- YAML import
- Binary/raw import
- CSV import
- XML import
- IDA exports
- Ghidra exports

Features:
- Memory dumps
- Execution traces
- Analysis results
- Function information
- Annotations and comments
"""

import base64
import json
import logging
import struct
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import IntEnum, auto
from io import BytesIO
from typing import Any

logger = logging.getLogger(__name__)


class ImportFormat(IntEnum):
    """Supported import formats."""
    JSON = auto()
    YAML = auto()
    BINARY = auto()
    CSV = auto()
    XML = auto()
    IDA_EXPORT = auto()
    GHIDRA_EXPORT = auto()
    AUTO_DETECT = auto()


class ImportDataType(IntEnum):
    """Types of imported data."""
    MEMORY = auto()
    REGISTERS = auto()
    TRACE = auto()
    FUNCTIONS = auto()
    ANNOTATIONS = auto()
    ANALYSIS = auto()
    CONFIG = auto()
    MIXED = auto()


@dataclass
class ImportOptions:
    """Options for import operations."""
    format: ImportFormat = ImportFormat.AUTO_DETECT
    encoding: str = 'utf-8'
    strict: bool = False
    merge_mode: bool = False
    validate: bool = True
    custom_parsers: dict[str, Callable] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            'format': self.format.name,
            'encoding': self.encoding,
            'strict': self.strict,
            'merge_mode': self.merge_mode,
            'validate': self.validate,
        }


@dataclass
class ImportResult:
    """Result of an import operation."""
    success: bool
    format: ImportFormat
    data_type: ImportDataType
    data: dict[str, Any]
    warnings: list[str] = field(default_factory=list)
    error: str | None = None
    source: str | None = None

    def __str__(self) -> str:
        if self.success:
            warning_msg = f" with {len(self.warnings)} warnings" if self.warnings else ""
            return f"Import successful ({self.format.name}, {self.data_type.name}){warning_msg}"
        return f"Import failed: {self.error}"

    @property
    def memory_regions(self) -> list[dict[str, Any]]:
        """Get imported memory regions."""
        return self.data.get('memory', [])

    @property
    def functions(self) -> list[dict[str, Any]]:
        """Get imported functions."""
        return self.data.get('functions', [])

    @property
    def annotations(self) -> list[dict[str, Any]]:
        """Get imported annotations."""
        return self.data.get('annotations', [])

    @property
    def trace(self) -> list[dict[str, Any]]:
        """Get imported trace entries."""
        return self.data.get('trace', [])


@dataclass
class ValidationError:
    """A validation error during import."""
    field: str
    message: str
    severity: str = "error"  # error, warning

    def __str__(self) -> str:
        return f"[{self.severity.upper()}] {self.field}: {self.message}"


# =============================================================================
# Importer Interface
# =============================================================================

class Importer(ABC):
    """Abstract base class for importers."""

    @property
    @abstractmethod
    def format(self) -> ImportFormat:
        """Get import format."""
        pass

    @property
    @abstractmethod
    def extensions(self) -> list[str]:
        """Get supported file extensions."""
        pass

    @abstractmethod
    def can_import(self, data: bytes) -> bool:
        """Check if data can be imported by this importer."""
        pass

    @abstractmethod
    def import_data(self, data: bytes,
                   options: ImportOptions) -> ImportResult:
        """Import data from bytes."""
        pass

    @abstractmethod
    def import_from_file(self, path: str,
                        options: ImportOptions) -> ImportResult:
        """Import data from file."""
        pass


# =============================================================================
# JSON Importer
# =============================================================================

class JSONImporter(Importer):
    """JSON format importer."""

    @property
    def format(self) -> ImportFormat:
        return ImportFormat.JSON

    @property
    def extensions(self) -> list[str]:
        return ['.json']

    def can_import(self, data: bytes) -> bool:
        """Check if data is valid JSON."""
        try:
            data_str = data.decode('utf-8').strip()
            return data_str.startswith('{') or data_str.startswith('[')
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return False

    def import_data(self, data: bytes,
                   options: ImportOptions) -> ImportResult:
        """Import from JSON bytes."""
        try:
            data_str = data.decode(options.encoding)
            parsed = json.loads(data_str)

            # Determine data type
            data_type = self._determine_data_type(parsed)

            # Validate if requested
            warnings = []
            if options.validate:
                warnings = self._validate_data(parsed)

            return ImportResult(
                success=True,
                format=self.format,
                data_type=data_type,
                data=parsed if isinstance(parsed, dict) else {'items': parsed},
                warnings=warnings,
            )
        except json.JSONDecodeError as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=f"JSON parse error: {e}",
            )
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def import_from_file(self, path: str,
                        options: ImportOptions) -> ImportResult:
        """Import from JSON file."""
        try:
            with open(path, 'rb') as f:
                data = f.read()
            result = self.import_data(data, options)
            result.source = path
            return result
        except FileNotFoundError:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=f"File not found: {path}",
            )
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def _determine_data_type(self, data: Any) -> ImportDataType:
        """Determine the type of imported data."""
        if isinstance(data, list):
            return ImportDataType.MIXED

        if isinstance(data, dict):
            keys = set(data.keys())
            if 'memory' in keys:
                return ImportDataType.MEMORY
            if 'registers' in keys:
                return ImportDataType.REGISTERS
            if 'trace' in keys:
                return ImportDataType.TRACE
            if 'functions' in keys:
                return ImportDataType.FUNCTIONS
            if 'annotations' in keys:
                return ImportDataType.ANNOTATIONS

        return ImportDataType.MIXED

    def _validate_data(self, data: Any) -> list[str]:
        """Validate imported data."""
        warnings = []

        if isinstance(data, dict):
            # Check memory regions
            for i, region in enumerate(data.get('memory', [])):
                if 'start' not in region:
                    warnings.append(f"Memory region {i}: missing 'start' field")
                if 'end' not in region and 'size' not in region:
                    warnings.append(f"Memory region {i}: missing 'end' or 'size' field")

            # Check functions
            for i, func in enumerate(data.get('functions', [])):
                if 'address' not in func:
                    warnings.append(f"Function {i}: missing 'address' field")
                if 'name' not in func:
                    warnings.append(f"Function {i}: missing 'name' field")

            # Check trace entries
            for i, entry in enumerate(data.get('trace', [])):
                if 'address' not in entry:
                    warnings.append(f"Trace entry {i}: missing 'address' field")

        return warnings


# =============================================================================
# YAML Importer
# =============================================================================

class YAMLImporter(Importer):
    """YAML format importer."""

    @property
    def format(self) -> ImportFormat:
        return ImportFormat.YAML

    @property
    def extensions(self) -> list[str]:
        return ['.yaml', '.yml']

    def can_import(self, data: bytes) -> bool:
        """Check if data looks like YAML."""
        try:
            data_str = data.decode('utf-8').strip()
            # Simple YAML detection - starts with key: or ---
            return ':' in data_str or data_str.startswith('---')
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return False

    def import_data(self, data: bytes,
                   options: ImportOptions) -> ImportResult:
        """Import from YAML bytes."""
        try:
            data_str = data.decode(options.encoding)
            parsed = self._parse_yaml(data_str)

            data_type = self._determine_data_type(parsed)

            return ImportResult(
                success=True,
                format=self.format,
                data_type=data_type,
                data=parsed if isinstance(parsed, dict) else {'items': parsed},
            )
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def import_from_file(self, path: str,
                        options: ImportOptions) -> ImportResult:
        """Import from YAML file."""
        try:
            with open(path, 'rb') as f:
                data = f.read()
            result = self.import_data(data, options)
            result.source = path
            return result
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def _parse_yaml(self, yaml_str: str) -> dict[str, Any]:
        """Simple YAML parser (limited features)."""
        result = {}
        current_key = None
        current_indent = 0
        lines = yaml_str.split('\n')

        for line in lines:
            stripped = line.lstrip()
            if not stripped or stripped.startswith('#') or stripped.startswith('---'):
                continue

            indent = len(line) - len(stripped)

            if ':' in stripped:
                parts = stripped.split(':', 1)
                key = parts[0].strip()
                value = parts[1].strip() if len(parts) > 1 else ''

                if value:
                    # Handle value types
                    if value.lower() == 'true':
                        result[key] = True
                    elif value.lower() == 'false':
                        result[key] = False
                    elif value.lower() == 'null':
                        result[key] = None
                    elif value.isdigit():
                        result[key] = int(value)
                    elif value.replace('.', '').isdigit():
                        result[key] = float(value)
                    elif value.startswith('"') and value.endswith('"'):
                        result[key] = value[1:-1]
                    elif value.startswith('[') and value.endswith(']'):
                        # Simple array
                        result[key] = [v.strip() for v in value[1:-1].split(',')]
                    else:
                        result[key] = value
                else:
                    result[key] = {}
                    current_key = key
            elif stripped.startswith('- '):
                # List item
                value = stripped[2:]
                if current_key:
                    if not isinstance(result.get(current_key), list):
                        result[current_key] = []
                    result[current_key].append(value)

        return result

    def _determine_data_type(self, data: Any) -> ImportDataType:
        """Determine the type of imported data."""
        if isinstance(data, dict):
            if 'memory' in data:
                return ImportDataType.MEMORY
            if 'trace' in data:
                return ImportDataType.TRACE
            if 'functions' in data:
                return ImportDataType.FUNCTIONS
        return ImportDataType.MIXED


# =============================================================================
# Binary Importer
# =============================================================================

class BinaryImporter(Importer):
    """Binary format importer for PyUniDbg exports."""

    MAGIC = b'PYUDB'
    VERSION = 1

    @property
    def format(self) -> ImportFormat:
        return ImportFormat.BINARY

    @property
    def extensions(self) -> list[str]:
        return ['.bin', '.pyudb']

    def can_import(self, data: bytes) -> bool:
        """Check if data is valid PyUniDbg binary format."""
        return data.startswith(self.MAGIC)

    def import_data(self, data: bytes,
                   options: ImportOptions) -> ImportResult:
        """Import from binary bytes."""
        try:
            buffer = BytesIO(data)

            # Read header
            magic = buffer.read(5)
            if magic != self.MAGIC:
                return ImportResult(
                    success=False,
                    format=self.format,
                    data_type=ImportDataType.MIXED,
                    data={},
                    error="Invalid magic number",
                )

            version = struct.unpack('<H', buffer.read(2))[0]
            if version > self.VERSION:
                return ImportResult(
                    success=False,
                    format=self.format,
                    data_type=ImportDataType.MIXED,
                    data={},
                    error=f"Unsupported version: {version}",
                )

            # Read sections
            section_count = struct.unpack('<I', buffer.read(4))[0]

            result_data = {}
            for _ in range(section_count):
                section_type = struct.unpack('<B', buffer.read(1))[0]
                section_size = struct.unpack('<I', buffer.read(4))[0]
                section_flags = struct.unpack('<I', buffer.read(4))[0]
                section_data = buffer.read(section_size)

                if section_type == 1:  # Memory
                    if 'memory' not in result_data:
                        result_data['memory'] = []
                    result_data['memory'].append(self._unpack_memory_region(section_data))
                elif section_type == 2:  # Registers
                    result_data['registers'] = self._unpack_registers(section_data)
                elif section_type == 3:  # Trace
                    result_data['trace'] = self._unpack_trace(section_data)

            return ImportResult(
                success=True,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data=result_data,
            )
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def import_from_file(self, path: str,
                        options: ImportOptions) -> ImportResult:
        """Import from binary file."""
        try:
            with open(path, 'rb') as f:
                data = f.read()
            result = self.import_data(data, options)
            result.source = path
            return result
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def _unpack_memory_region(self, data: bytes) -> dict[str, Any]:
        """Unpack a memory region from binary."""
        buffer = BytesIO(data)
        start = struct.unpack('<Q', buffer.read(8))[0]
        end = struct.unpack('<Q', buffer.read(8))[0]
        size = struct.unpack('<I', buffer.read(4))[0]
        region_data = buffer.read(size)

        return {
            'start': start,
            'end': end,
            'data': base64.b64encode(region_data).decode('ascii'),
        }

    def _unpack_registers(self, data: bytes) -> dict[str, int]:
        """Unpack registers from binary."""
        buffer = BytesIO(data)
        count = struct.unpack('<I', buffer.read(4))[0]

        registers = {}
        for _ in range(count):
            name_len = struct.unpack('<B', buffer.read(1))[0]
            name = buffer.read(name_len).decode('utf-8')
            value = struct.unpack('<Q', buffer.read(8))[0]
            registers[name] = value

        return registers

    def _unpack_trace(self, data: bytes) -> list[dict[str, Any]]:
        """Unpack trace from binary."""
        buffer = BytesIO(data)
        count = struct.unpack('<I', buffer.read(4))[0]

        trace = []
        for _ in range(count):
            addr = struct.unpack('<Q', buffer.read(8))[0]
            inst_len = struct.unpack('<H', buffer.read(2))[0]
            inst = buffer.read(inst_len).decode('utf-8')
            trace.append({'address': addr, 'instruction': inst})

        return trace


# =============================================================================
# CSV Importer
# =============================================================================

class CSVImporter(Importer):
    """CSV format importer."""

    @property
    def format(self) -> ImportFormat:
        return ImportFormat.CSV

    @property
    def extensions(self) -> list[str]:
        return ['.csv']

    def can_import(self, data: bytes) -> bool:
        """Check if data looks like CSV."""
        try:
            data_str = data.decode('utf-8')
            lines = data_str.strip().split('\n')
            if len(lines) >= 2:
                # Check if first line has commas (header)
                return ',' in lines[0]
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
        return False

    def import_data(self, data: bytes,
                   options: ImportOptions) -> ImportResult:
        """Import from CSV bytes."""
        try:
            data_str = data.decode(options.encoding)
            lines = data_str.strip().split('\n')

            if not lines:
                return ImportResult(
                    success=False,
                    format=self.format,
                    data_type=ImportDataType.MIXED,
                    data={},
                    error="Empty CSV data",
                )

            # Parse header
            header = self._parse_csv_line(lines[0])

            # Parse rows
            rows = []
            for line in lines[1:]:
                if line.strip():
                    values = self._parse_csv_line(line)
                    row = {}
                    for i, val in enumerate(values):
                        if i < len(header):
                            row[header[i]] = self._parse_value(val)
                    rows.append(row)

            # Determine data type based on headers
            data_type = self._determine_data_type_from_header(header)
            result_data = self._structure_data(header, rows)

            return ImportResult(
                success=True,
                format=self.format,
                data_type=data_type,
                data=result_data,
            )
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def import_from_file(self, path: str,
                        options: ImportOptions) -> ImportResult:
        """Import from CSV file."""
        try:
            with open(path, 'rb') as f:
                data = f.read()
            result = self.import_data(data, options)
            result.source = path
            return result
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def _parse_csv_line(self, line: str) -> list[str]:
        """Parse a CSV line handling quotes."""
        values = []
        current = ""
        in_quotes = False

        for char in line:
            if char == '"':
                in_quotes = not in_quotes
            elif char == ',' and not in_quotes:
                values.append(current.strip())
                current = ""
            else:
                current += char

        values.append(current.strip())
        return values

    def _parse_value(self, value: str) -> Any:
        """Parse a CSV value to appropriate type."""
        value = value.strip()

        # Remove surrounding quotes
        if value.startswith('"') and value.endswith('"'):
            return value[1:-1]

        # Try hex number
        if value.startswith('0x'):
            try:
                return int(value, 16)
            except Exception:
                logger.debug("Exception suppressed", exc_info=True)

        # Try integer
        try:
            return int(value)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        # Try float
        try:
            return float(value)
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        return value

    def _determine_data_type_from_header(self, header: list[str]) -> ImportDataType:
        """Determine data type from CSV header."""
        header_set = set(h.lower() for h in header)

        if 'instruction' in header_set:
            return ImportDataType.TRACE
        if 'name' in header_set and 'size' in header_set:
            return ImportDataType.FUNCTIONS
        if 'comment' in header_set:
            return ImportDataType.ANNOTATIONS

        return ImportDataType.MIXED

    def _structure_data(self, header: list[str],
                        rows: list[dict[str, Any]]) -> dict[str, Any]:
        """Structure CSV data based on detected type."""
        header_set = set(h.lower() for h in header)

        if 'instruction' in header_set:
            return {'trace': rows}
        if 'name' in header_set and 'size' in header_set:
            return {'functions': rows}
        if 'comment' in header_set:
            return {'annotations': rows}

        return {'items': rows}


# =============================================================================
# XML Importer
# =============================================================================

class XMLImporter(Importer):
    """XML format importer."""

    @property
    def format(self) -> ImportFormat:
        return ImportFormat.XML

    @property
    def extensions(self) -> list[str]:
        return ['.xml']

    def can_import(self, data: bytes) -> bool:
        """Check if data is valid XML."""
        try:
            data_str = data.decode('utf-8').strip()
            return data_str.startswith('<?xml') or data_str.startswith('<')
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return False

    def import_data(self, data: bytes,
                   options: ImportOptions) -> ImportResult:
        """Import from XML bytes."""
        try:
            data_str = data.decode(options.encoding)
            parsed = self._parse_xml(data_str)

            return ImportResult(
                success=True,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data=parsed,
            )
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def import_from_file(self, path: str,
                        options: ImportOptions) -> ImportResult:
        """Import from XML file."""
        try:
            with open(path, 'rb') as f:
                data = f.read()
            result = self.import_data(data, options)
            result.source = path
            return result
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def _parse_xml(self, xml_str: str) -> dict[str, Any]:
        """Simple XML parser (limited features)."""
        result = {}
        stack = [result]
        current_tag = None
        content = ""

        i = 0
        while i < len(xml_str):
            if xml_str[i] == '<':
                # Save any content
                if current_tag and content.strip():
                    self._set_value(stack[-1], current_tag, content.strip())
                content = ""

                # Find end of tag
                end = xml_str.find('>', i)
                if end == -1:
                    break

                tag_content = xml_str[i+1:end]

                # Skip XML declaration and comments
                if tag_content.startswith('?') or tag_content.startswith('!'):
                    i = end + 1
                    continue

                # Check for self-closing tag
                if tag_content.endswith('/'):
                    tag_name = tag_content[:-1].split()[0]
                    stack[-1][tag_name] = None
                # Check for closing tag
                elif tag_content.startswith('/'):
                    tag_name = tag_content[1:]
                    if len(stack) > 1:
                        stack.pop()
                    current_tag = None
                # Opening tag
                else:
                    tag_parts = tag_content.split()
                    tag_name = tag_parts[0]
                    current_tag = tag_name

                    new_dict = {}
                    if tag_name in stack[-1]:
                        # Convert to list
                        if not isinstance(stack[-1][tag_name], list):
                            stack[-1][tag_name] = [stack[-1][tag_name]]
                        stack[-1][tag_name].append(new_dict)
                    else:
                        stack[-1][tag_name] = new_dict
                    stack.append(new_dict)

                i = end + 1
            else:
                content += xml_str[i]
                i += 1

        # Extract from root element if present
        if 'pyunidbg' in result:
            return result['pyunidbg']
        return result

    def _set_value(self, obj: dict, key: str, value: str) -> None:
        """Set a value in the object."""
        # Try to parse as number
        try:
            if '.' in value:
                obj[key] = float(value)
            else:
                obj[key] = int(value)
            return
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)

        # Check for boolean
        if value.lower() == 'true':
            obj[key] = True
        elif value.lower() == 'false':
            obj[key] = False
        elif value.lower() == 'null':
            obj[key] = None
        else:
            obj[key] = value


# =============================================================================
# IDA Export Importer
# =============================================================================

class IDAExportImporter(Importer):
    """IDA Pro export format importer."""

    @property
    def format(self) -> ImportFormat:
        return ImportFormat.IDA_EXPORT

    @property
    def extensions(self) -> list[str]:
        return ['.idc', '.py', '.txt']

    def can_import(self, data: bytes) -> bool:
        """Check if data is IDA export format."""
        try:
            data_str = data.decode('utf-8')
            return 'MakeName' in data_str or 'set_name' in data_str or 'MakeComm' in data_str
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return False

    def import_data(self, data: bytes,
                   options: ImportOptions) -> ImportResult:
        """Import from IDA export."""
        try:
            data_str = data.decode(options.encoding)

            functions = []
            annotations = []

            for line in data_str.split('\n'):
                line = line.strip()

                # Parse function renames
                if 'MakeName' in line or 'set_name' in line:
                    result = self._parse_name_line(line)
                    if result:
                        functions.append(result)

                # Parse comments
                if 'MakeComm' in line or 'set_cmt' in line:
                    result = self._parse_comment_line(line)
                    if result:
                        annotations.append(result)

            return ImportResult(
                success=True,
                format=self.format,
                data_type=ImportDataType.FUNCTIONS if functions else ImportDataType.ANNOTATIONS,
                data={
                    'functions': functions,
                    'annotations': annotations,
                },
            )
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def import_from_file(self, path: str,
                        options: ImportOptions) -> ImportResult:
        """Import from IDA export file."""
        try:
            with open(path, 'rb') as f:
                data = f.read()
            result = self.import_data(data, options)
            result.source = path
            return result
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def _parse_name_line(self, line: str) -> dict[str, Any] | None:
        """Parse a MakeName/set_name line."""
        import re

        # Match patterns like MakeName(0x1000, "name") or set_name(0x1000, "name", ...)
        pattern = r'(?:MakeName|set_name|ida_name\.set_name)\s*\(\s*(0x[0-9a-fA-F]+)\s*,\s*["\']([^"\']+)["\']'
        match = re.search(pattern, line)

        if match:
            return {
                'address': int(match.group(1), 16),
                'name': match.group(2),
            }
        return None

    def _parse_comment_line(self, line: str) -> dict[str, Any] | None:
        """Parse a MakeComm/set_cmt line."""
        import re

        pattern = r'(?:MakeComm|set_cmt|idc\.set_cmt)\s*\(\s*(0x[0-9a-fA-F]+)\s*,\s*["\']([^"\']+)["\']'
        match = re.search(pattern, line)

        if match:
            return {
                'address': int(match.group(1), 16),
                'comment': match.group(2),
            }
        return None


# =============================================================================
# Ghidra Export Importer
# =============================================================================

class GhidraExportImporter(Importer):
    """Ghidra export format importer."""

    @property
    def format(self) -> ImportFormat:
        return ImportFormat.GHIDRA_EXPORT

    @property
    def extensions(self) -> list[str]:
        return ['.py', '.txt', '.csv']

    def can_import(self, data: bytes) -> bool:
        """Check if data is Ghidra export format."""
        try:
            data_str = data.decode('utf-8')
            return 'currentProgram' in data_str or 'ghidra' in data_str.lower()
        except Exception:
            logger.debug("Exception suppressed", exc_info=True)
            return False

    def import_data(self, data: bytes,
                   options: ImportOptions) -> ImportResult:
        """Import from Ghidra export."""
        try:
            data_str = data.decode(options.encoding)

            functions = []
            annotations = []

            for line in data_str.split('\n'):
                line = line.strip()

                # Parse function operations
                if 'setName' in line:
                    result = self._parse_name_line(line)
                    if result:
                        functions.append(result)

                # Parse comments
                if 'setComment' in line:
                    result = self._parse_comment_line(line)
                    if result:
                        annotations.append(result)

            return ImportResult(
                success=True,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={
                    'functions': functions,
                    'annotations': annotations,
                },
            )
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def import_from_file(self, path: str,
                        options: ImportOptions) -> ImportResult:
        """Import from Ghidra export file."""
        try:
            with open(path, 'rb') as f:
                data = f.read()
            result = self.import_data(data, options)
            result.source = path
            return result
        except Exception as e:
            return ImportResult(
                success=False,
                format=self.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

    def _parse_name_line(self, line: str) -> dict[str, Any] | None:
        """Parse a setName line."""
        import re

        pattern = r'setName\s*\(\s*["\']([^"\']+)["\']'
        match = re.search(pattern, line)

        if match:
            return {'name': match.group(1)}
        return None

    def _parse_comment_line(self, line: str) -> dict[str, Any] | None:
        """Parse a setComment line."""
        import re

        pattern = r'setComment\s*\([^,]+,\s*["\']([^"\']+)["\']'
        match = re.search(pattern, line)

        if match:
            return {'comment': match.group(1)}
        return None


# =============================================================================
# Import Manager
# =============================================================================

class ImportManager:
    """Manages import operations with multiple formats."""

    def __init__(self):
        self._importers: dict[ImportFormat, Importer] = {}
        self._register_default_importers()

    def _register_default_importers(self) -> None:
        """Register default importers."""
        self._importers[ImportFormat.JSON] = JSONImporter()
        self._importers[ImportFormat.YAML] = YAMLImporter()
        self._importers[ImportFormat.BINARY] = BinaryImporter()
        self._importers[ImportFormat.CSV] = CSVImporter()
        self._importers[ImportFormat.XML] = XMLImporter()
        self._importers[ImportFormat.IDA_EXPORT] = IDAExportImporter()
        self._importers[ImportFormat.GHIDRA_EXPORT] = GhidraExportImporter()

    def register_importer(self, importer: Importer) -> None:
        """Register a custom importer."""
        self._importers[importer.format] = importer

    def get_importer(self, import_format: ImportFormat) -> Importer | None:
        """Get an importer by format."""
        return self._importers.get(import_format)

    def auto_detect_format(self, data: bytes) -> ImportFormat:
        """Auto-detect format from data."""
        for format_type, importer in self._importers.items():
            if importer.can_import(data):
                return format_type
        return ImportFormat.AUTO_DETECT

    def import_data(self, data: bytes,
                   options: ImportOptions | None = None) -> ImportResult:
        """Import data using auto-detection or specified format."""
        if options is None:
            options = ImportOptions()

        # Auto-detect format if needed
        format_to_use = options.format
        if format_to_use == ImportFormat.AUTO_DETECT:
            format_to_use = self.auto_detect_format(data)
            if format_to_use == ImportFormat.AUTO_DETECT:
                return ImportResult(
                    success=False,
                    format=ImportFormat.AUTO_DETECT,
                    data_type=ImportDataType.MIXED,
                    data={},
                    error="Could not auto-detect format",
                )

        importer = self._importers.get(format_to_use)
        if not importer:
            return ImportResult(
                success=False,
                format=format_to_use,
                data_type=ImportDataType.MIXED,
                data={},
                error=f"No importer for format: {format_to_use.name}",
            )

        return importer.import_data(data, options)

    def import_from_file(self, path: str,
                        options: ImportOptions | None = None) -> ImportResult:
        """Import data from a file."""
        if options is None:
            options = ImportOptions()

        try:
            with open(path, 'rb') as f:
                data = f.read()
        except Exception as e:
            return ImportResult(
                success=False,
                format=options.format,
                data_type=ImportDataType.MIXED,
                data={},
                error=str(e),
            )

        result = self.import_data(data, options)
        result.source = path
        return result

    def get_supported_formats(self) -> list[ImportFormat]:
        """Get list of supported formats."""
        return list(self._importers.keys())

    def get_extensions(self, import_format: ImportFormat) -> list[str]:
        """Get file extensions for a format."""
        importer = self._importers.get(import_format)
        return importer.extensions if importer else []


# =============================================================================
# Helper Functions
# =============================================================================

def create_import_manager() -> ImportManager:
    """Create an import manager with default importers."""
    return ImportManager()


def quick_import(data: bytes,
                 import_format: ImportFormat = ImportFormat.AUTO_DETECT) -> ImportResult:
    """Quick import from bytes."""
    manager = ImportManager()
    options = ImportOptions(format=import_format)
    return manager.import_data(data, options)


def import_json(data: bytes) -> ImportResult:
    """Import JSON data."""
    return quick_import(data, ImportFormat.JSON)


def import_from_file(path: str,
                     import_format: ImportFormat = ImportFormat.AUTO_DETECT) -> ImportResult:
    """Import from file with optional format specification."""
    manager = ImportManager()
    options = ImportOptions(format=import_format)
    return manager.import_from_file(path, options)
