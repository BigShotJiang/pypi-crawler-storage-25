"""
ARM Crypto Extensions Emulation for PyUniDbg.

Provides software emulation of ARM cryptographic instructions
for platforms that don't have hardware crypto support.
"""

import hashlib
import struct
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Dict, List, Optional, Set, Tuple, Union


class CryptoAlgorithm(Enum):
    """Supported cryptographic algorithms."""
    AES = auto()
    SHA1 = auto()
    SHA256 = auto()
    SHA512 = auto()
    SHA3 = auto()
    CRC32 = auto()
    PMULL = auto()  # Polynomial multiply long
    SM3 = auto()    # Chinese SHA
    SM4 = auto()    # Chinese AES


class CryptoOperation(Enum):
    """Cryptographic operation types."""
    ENCRYPT = auto()
    DECRYPT = auto()
    HASH = auto()
    MAC = auto()
    MIX_COLUMNS = auto()
    SHIFT_ROWS = auto()
    SUB_BYTES = auto()


@dataclass
class CryptoContext:
    """Context for cryptographic operations."""
    algorithm: CryptoAlgorithm
    key: bytes = b''
    iv: bytes = b''
    mode: str = 'ECB'
    rounds: int = 10
    state: bytes = b''

    # For hash operations
    hash_state: list[int] = field(default_factory=list)
    message_length: int = 0

    # For CRC
    crc_polynomial: int = 0x04C11DB7
    crc_initial: int = 0xFFFFFFFF


# AES S-Box
AES_SBOX = [
    0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
    0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
    0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
    0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
    0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
    0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
    0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
    0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
    0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
    0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
    0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
    0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
    0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
    0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
    0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
    0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16,
]

# AES Inverse S-Box
AES_INV_SBOX = [
    0x52, 0x09, 0x6a, 0xd5, 0x30, 0x36, 0xa5, 0x38, 0xbf, 0x40, 0xa3, 0x9e, 0x81, 0xf3, 0xd7, 0xfb,
    0x7c, 0xe3, 0x39, 0x82, 0x9b, 0x2f, 0xff, 0x87, 0x34, 0x8e, 0x43, 0x44, 0xc4, 0xde, 0xe9, 0xcb,
    0x54, 0x7b, 0x94, 0x32, 0xa6, 0xc2, 0x23, 0x3d, 0xee, 0x4c, 0x95, 0x0b, 0x42, 0xfa, 0xc3, 0x4e,
    0x08, 0x2e, 0xa1, 0x66, 0x28, 0xd9, 0x24, 0xb2, 0x76, 0x5b, 0xa2, 0x49, 0x6d, 0x8b, 0xd1, 0x25,
    0x72, 0xf8, 0xf6, 0x64, 0x86, 0x68, 0x98, 0x16, 0xd4, 0xa4, 0x5c, 0xcc, 0x5d, 0x65, 0xb6, 0x92,
    0x6c, 0x70, 0x48, 0x50, 0xfd, 0xed, 0xb9, 0xda, 0x5e, 0x15, 0x46, 0x57, 0xa7, 0x8d, 0x9d, 0x84,
    0x90, 0xd8, 0xab, 0x00, 0x8c, 0xbc, 0xd3, 0x0a, 0xf7, 0xe4, 0x58, 0x05, 0xb8, 0xb3, 0x45, 0x06,
    0xd0, 0x2c, 0x1e, 0x8f, 0xca, 0x3f, 0x0f, 0x02, 0xc1, 0xaf, 0xbd, 0x03, 0x01, 0x13, 0x8a, 0x6b,
    0x3a, 0x91, 0x11, 0x41, 0x4f, 0x67, 0xdc, 0xea, 0x97, 0xf2, 0xcf, 0xce, 0xf0, 0xb4, 0xe6, 0x73,
    0x96, 0xac, 0x74, 0x22, 0xe7, 0xad, 0x35, 0x85, 0xe2, 0xf9, 0x37, 0xe8, 0x1c, 0x75, 0xdf, 0x6e,
    0x47, 0xf1, 0x1a, 0x71, 0x1d, 0x29, 0xc5, 0x89, 0x6f, 0xb7, 0x62, 0x0e, 0xaa, 0x18, 0xbe, 0x1b,
    0xfc, 0x56, 0x3e, 0x4b, 0xc6, 0xd2, 0x79, 0x20, 0x9a, 0xdb, 0xc0, 0xfe, 0x78, 0xcd, 0x5a, 0xf4,
    0x1f, 0xdd, 0xa8, 0x33, 0x88, 0x07, 0xc7, 0x31, 0xb1, 0x12, 0x10, 0x59, 0x27, 0x80, 0xec, 0x5f,
    0x60, 0x51, 0x7f, 0xa9, 0x19, 0xb5, 0x4a, 0x0d, 0x2d, 0xe5, 0x7a, 0x9f, 0x93, 0xc9, 0x9c, 0xef,
    0xa0, 0xe0, 0x3b, 0x4d, 0xae, 0x2a, 0xf5, 0xb0, 0xc8, 0xeb, 0xbb, 0x3c, 0x83, 0x53, 0x99, 0x61,
    0x17, 0x2b, 0x04, 0x7e, 0xba, 0x77, 0xd6, 0x26, 0xe1, 0x69, 0x14, 0x63, 0x55, 0x21, 0x0c, 0x7d,
]

# AES round constants
AES_RCON = [0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1B, 0x36]


class AESEngine:
    """AES cryptographic engine implementing ARM crypto extensions."""

    def __init__(self):
        self.key_schedule: list[bytes] = []
        self.key_size: int = 0
        self.rounds: int = 0

    def set_key(self, key: bytes) -> None:
        """Set encryption key and generate key schedule."""
        self.key_size = len(key)

        if self.key_size == 16:
            self.rounds = 10
        elif self.key_size == 24:
            self.rounds = 12
        elif self.key_size == 32:
            self.rounds = 14
        else:
            raise ValueError(f"Invalid key size: {self.key_size}")

        self.key_schedule = self._key_expansion(key)

    def _key_expansion(self, key: bytes) -> list[bytes]:
        """Expand key into round keys."""
        nk = self.key_size // 4  # Number of 32-bit words in key
        nr = self.rounds
        nb = 4  # Number of columns (always 4 for AES)

        # Initialize with original key
        w = []
        for i in range(nk):
            w.append(key[4*i:4*i+4])

        # Generate remaining round key material
        for i in range(nk, nb * (nr + 1)):
            temp = bytearray(w[i - 1])

            if i % nk == 0:
                # Rotate and substitute
                temp = bytearray([
                    AES_SBOX[temp[1]] ^ AES_RCON[(i // nk) - 1],
                    AES_SBOX[temp[2]],
                    AES_SBOX[temp[3]],
                    AES_SBOX[temp[0]]
                ])
            elif nk > 6 and i % nk == 4:
                # Extra SubBytes for 256-bit key
                temp = bytearray([AES_SBOX[b] for b in temp])

            # XOR with word nk positions earlier
            w.append(bytes([a ^ b for a, b in zip(w[i - nk], temp)]))

        # Group into round keys
        round_keys = []
        for r in range(nr + 1):
            round_key = b''.join(w[r*4:(r+1)*4])
            round_keys.append(round_key)

        return round_keys

    def sub_bytes(self, state: bytes) -> bytes:
        """Apply S-box substitution (AESE instruction component)."""
        return bytes([AES_SBOX[b] for b in state])

    def inv_sub_bytes(self, state: bytes) -> bytes:
        """Apply inverse S-box substitution (AESD instruction component)."""
        return bytes([AES_INV_SBOX[b] for b in state])

    def shift_rows(self, state: bytes) -> bytes:
        """Shift rows operation (AESE instruction component)."""
        # State is treated as 4x4 matrix in column-major order
        s = bytearray(state)

        # Row 0: no shift
        # Row 1: shift left by 1
        s[1], s[5], s[9], s[13] = s[5], s[9], s[13], s[1]
        # Row 2: shift left by 2
        s[2], s[6], s[10], s[14] = s[10], s[14], s[2], s[6]
        # Row 3: shift left by 3
        s[3], s[7], s[11], s[15] = s[15], s[3], s[7], s[11]

        return bytes(s)

    def inv_shift_rows(self, state: bytes) -> bytes:
        """Inverse shift rows operation (AESD instruction component)."""
        s = bytearray(state)

        # Row 0: no shift
        # Row 1: shift right by 1
        s[1], s[5], s[9], s[13] = s[13], s[1], s[5], s[9]
        # Row 2: shift right by 2
        s[2], s[6], s[10], s[14] = s[10], s[14], s[2], s[6]
        # Row 3: shift right by 3
        s[3], s[7], s[11], s[15] = s[7], s[11], s[15], s[3]

        return bytes(s)

    def _xtime(self, a: int) -> int:
        """Multiply by x in GF(2^8)."""
        if a & 0x80:
            return ((a << 1) ^ 0x1B) & 0xFF
        return (a << 1) & 0xFF

    def _gmul(self, a: int, b: int) -> int:
        """Multiply two numbers in GF(2^8)."""
        result = 0
        for _ in range(8):
            if b & 1:
                result ^= a
            a = self._xtime(a)
            b >>= 1
        return result

    def mix_columns(self, state: bytes) -> bytes:
        """Mix columns operation (AESMC instruction)."""
        s = bytearray(state)

        for col in range(4):
            i = col * 4
            a = [s[i], s[i+1], s[i+2], s[i+3]]

            s[i]   = self._gmul(a[0], 2) ^ self._gmul(a[1], 3) ^ a[2] ^ a[3]
            s[i+1] = a[0] ^ self._gmul(a[1], 2) ^ self._gmul(a[2], 3) ^ a[3]
            s[i+2] = a[0] ^ a[1] ^ self._gmul(a[2], 2) ^ self._gmul(a[3], 3)
            s[i+3] = self._gmul(a[0], 3) ^ a[1] ^ a[2] ^ self._gmul(a[3], 2)

        return bytes(s)

    def inv_mix_columns(self, state: bytes) -> bytes:
        """Inverse mix columns operation (AESIMC instruction)."""
        s = bytearray(state)

        for col in range(4):
            i = col * 4
            a = [s[i], s[i+1], s[i+2], s[i+3]]

            s[i]   = self._gmul(a[0], 0x0e) ^ self._gmul(a[1], 0x0b) ^ self._gmul(a[2], 0x0d) ^ self._gmul(a[3], 0x09)
            s[i+1] = self._gmul(a[0], 0x09) ^ self._gmul(a[1], 0x0e) ^ self._gmul(a[2], 0x0b) ^ self._gmul(a[3], 0x0d)
            s[i+2] = self._gmul(a[0], 0x0d) ^ self._gmul(a[1], 0x09) ^ self._gmul(a[2], 0x0e) ^ self._gmul(a[3], 0x0b)
            s[i+3] = self._gmul(a[0], 0x0b) ^ self._gmul(a[1], 0x0d) ^ self._gmul(a[2], 0x09) ^ self._gmul(a[3], 0x0e)

        return bytes(s)

    def add_round_key(self, state: bytes, round_key: bytes) -> bytes:
        """XOR state with round key."""
        return bytes([a ^ b for a, b in zip(state, round_key)])

    def aese(self, state: bytes, round_key: bytes) -> bytes:
        """
        AESE instruction: Single round of AES encryption.
        AddRoundKey -> SubBytes -> ShiftRows
        """
        state = self.add_round_key(state, round_key)
        state = self.sub_bytes(state)
        state = self.shift_rows(state)
        return state

    def aesd(self, state: bytes, round_key: bytes) -> bytes:
        """
        AESD instruction: Single round of AES decryption.
        AddRoundKey -> InvSubBytes -> InvShiftRows
        """
        state = self.add_round_key(state, round_key)
        state = self.inv_sub_bytes(state)
        state = self.inv_shift_rows(state)
        return state

    def aesmc(self, state: bytes) -> bytes:
        """AESMC instruction: MixColumns."""
        return self.mix_columns(state)

    def aesimc(self, state: bytes) -> bytes:
        """AESIMC instruction: Inverse MixColumns."""
        return self.inv_mix_columns(state)

    def encrypt_block(self, plaintext: bytes) -> bytes:
        """Encrypt a single 16-byte block."""
        if len(plaintext) != 16:
            raise ValueError("Block must be 16 bytes")

        state = plaintext

        # Initial round
        state = self.add_round_key(state, self.key_schedule[0])

        # Main rounds
        for r in range(1, self.rounds):
            state = self.sub_bytes(state)
            state = self.shift_rows(state)
            state = self.mix_columns(state)
            state = self.add_round_key(state, self.key_schedule[r])

        # Final round (no MixColumns)
        state = self.sub_bytes(state)
        state = self.shift_rows(state)
        state = self.add_round_key(state, self.key_schedule[self.rounds])

        return state

    def decrypt_block(self, ciphertext: bytes) -> bytes:
        """Decrypt a single 16-byte block."""
        if len(ciphertext) != 16:
            raise ValueError("Block must be 16 bytes")

        state = ciphertext

        # Initial round
        state = self.add_round_key(state, self.key_schedule[self.rounds])

        # Main rounds
        for r in range(self.rounds - 1, 0, -1):
            state = self.inv_shift_rows(state)
            state = self.inv_sub_bytes(state)
            state = self.add_round_key(state, self.key_schedule[r])
            state = self.inv_mix_columns(state)

        # Final round
        state = self.inv_shift_rows(state)
        state = self.inv_sub_bytes(state)
        state = self.add_round_key(state, self.key_schedule[0])

        return state


class SHA256Engine:
    """SHA-256 hash engine implementing ARM crypto extensions."""

    # Initial hash values
    H0 = [
        0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
        0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    ]

    # Round constants
    K = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ]

    def __init__(self):
        self.state = list(self.H0)
        self.buffer = b''
        self.length = 0

    def reset(self) -> None:
        """Reset hash state."""
        self.state = list(self.H0)
        self.buffer = b''
        self.length = 0

    def _rotr(self, x: int, n: int) -> int:
        """Right rotate 32-bit value."""
        return ((x >> n) | (x << (32 - n))) & 0xFFFFFFFF

    def _ch(self, x: int, y: int, z: int) -> int:
        """Choice function."""
        return (x & y) ^ (~x & z) & 0xFFFFFFFF

    def _maj(self, x: int, y: int, z: int) -> int:
        """Majority function."""
        return (x & y) ^ (x & z) ^ (y & z)

    def _sigma0(self, x: int) -> int:
        """Big sigma 0."""
        return self._rotr(x, 2) ^ self._rotr(x, 13) ^ self._rotr(x, 22)

    def _sigma1(self, x: int) -> int:
        """Big sigma 1."""
        return self._rotr(x, 6) ^ self._rotr(x, 11) ^ self._rotr(x, 25)

    def _gamma0(self, x: int) -> int:
        """Small sigma 0."""
        return self._rotr(x, 7) ^ self._rotr(x, 18) ^ (x >> 3)

    def _gamma1(self, x: int) -> int:
        """Small sigma 1."""
        return self._rotr(x, 17) ^ self._rotr(x, 19) ^ (x >> 10)

    def sha256su0(self, w0: bytes, w1: bytes) -> bytes:
        """
        SHA256SU0 instruction: Schedule update 0.
        w0[3:0] = { σ0(w0[0]) + w0[3], w0[2], w0[1], w0[0] }
        """
        # Unpack words (little endian for ARM)
        words0 = struct.unpack('<4I', w0)
        words1 = struct.unpack('<4I', w1)

        result = [
            (self._gamma0(words1[0]) + words0[0]) & 0xFFFFFFFF,
            (self._gamma0(words1[1]) + words0[1]) & 0xFFFFFFFF,
            (self._gamma0(words1[2]) + words0[2]) & 0xFFFFFFFF,
            (self._gamma0(words1[3]) + words0[3]) & 0xFFFFFFFF,
        ]

        return struct.pack('<4I', *result)

    def sha256su1(self, w0: bytes, w1: bytes, w2: bytes) -> bytes:
        """
        SHA256SU1 instruction: Schedule update 1.
        """
        words0 = struct.unpack('<4I', w0)
        words1 = struct.unpack('<4I', w1)
        words2 = struct.unpack('<4I', w2)

        result = [
            (words0[0] + self._gamma1(words2[2]) + words1[1]) & 0xFFFFFFFF,
            (words0[1] + self._gamma1(words2[3]) + words1[2]) & 0xFFFFFFFF,
            (words0[2] + self._gamma1((words0[0] + self._gamma1(words2[2]) + words1[1]) & 0xFFFFFFFF) + words1[3]) & 0xFFFFFFFF,
            (words0[3] + self._gamma1((words0[1] + self._gamma1(words2[3]) + words1[2]) & 0xFFFFFFFF) + words2[0]) & 0xFFFFFFFF,
        ]

        return struct.pack('<4I', *result)

    def sha256h(self, hash_state: bytes, w: bytes, k: bytes) -> bytes:
        """
        SHA256H instruction: Hash update (part 1).
        """
        state = struct.unpack('<4I', hash_state)
        words = struct.unpack('<4I', w)
        ks = struct.unpack('<4I', k)

        # Simplified simulation of 4 rounds
        a, b, c, d = state
        for i in range(4):
            t1 = (d + self._sigma1(c) + self._ch(c, b, a) + ks[i] + words[i]) & 0xFFFFFFFF
            t2 = (self._sigma0(a) + self._maj(a, b, c)) & 0xFFFFFFFF
            d = c
            c = b
            b = a
            a = (t1 + t2) & 0xFFFFFFFF

        return struct.pack('<4I', a, b, c, d)

    def sha256h2(self, hash_state: bytes, w: bytes, k: bytes) -> bytes:
        """
        SHA256H2 instruction: Hash update (part 2).
        """
        # Similar to sha256h but for second half of state
        state = struct.unpack('<4I', hash_state)
        words = struct.unpack('<4I', w)
        ks = struct.unpack('<4I', k)

        e, f, g, h = state
        for i in range(4):
            t1 = (h + self._sigma1(e) + self._ch(e, f, g) + ks[i] + words[i]) & 0xFFFFFFFF
            h = g
            g = f
            f = e
            e = (t1 + self._sigma0(e)) & 0xFFFFFFFF

        return struct.pack('<4I', e, f, g, h)

    def process_block(self, block: bytes) -> None:
        """Process a 64-byte block."""
        # Parse block into 16 32-bit words
        w = list(struct.unpack('>16I', block))

        # Extend to 64 words
        for i in range(16, 64):
            w.append((self._gamma1(w[i-2]) + w[i-7] + self._gamma0(w[i-15]) + w[i-16]) & 0xFFFFFFFF)

        # Initialize working variables
        a, b, c, d, e, f, g, h = self.state

        # Main loop
        for i in range(64):
            t1 = (h + self._sigma1(e) + self._ch(e, f, g) + self.K[i] + w[i]) & 0xFFFFFFFF
            t2 = (self._sigma0(a) + self._maj(a, b, c)) & 0xFFFFFFFF
            h = g
            g = f
            f = e
            e = (d + t1) & 0xFFFFFFFF
            d = c
            c = b
            b = a
            a = (t1 + t2) & 0xFFFFFFFF

        # Update state
        self.state[0] = (self.state[0] + a) & 0xFFFFFFFF
        self.state[1] = (self.state[1] + b) & 0xFFFFFFFF
        self.state[2] = (self.state[2] + c) & 0xFFFFFFFF
        self.state[3] = (self.state[3] + d) & 0xFFFFFFFF
        self.state[4] = (self.state[4] + e) & 0xFFFFFFFF
        self.state[5] = (self.state[5] + f) & 0xFFFFFFFF
        self.state[6] = (self.state[6] + g) & 0xFFFFFFFF
        self.state[7] = (self.state[7] + h) & 0xFFFFFFFF

    def update(self, data: bytes) -> None:
        """Update hash with data."""
        self.length += len(data)
        self.buffer += data

        while len(self.buffer) >= 64:
            self.process_block(self.buffer[:64])
            self.buffer = self.buffer[64:]

    def digest(self) -> bytes:
        """Finalize and return hash digest."""
        # Padding
        msg_len = self.length * 8  # Length in bits
        padded = self.buffer + b'\x80'

        # Pad to 56 bytes mod 64
        while len(padded) % 64 != 56:
            padded += b'\x00'

        # Append length
        padded += struct.pack('>Q', msg_len)

        # Process remaining blocks
        while len(padded) >= 64:
            self.process_block(padded[:64])
            padded = padded[64:]

        # Return hash
        return struct.pack('>8I', *self.state)

    def hash(self, data: bytes) -> bytes:
        """Hash data in one call."""
        self.reset()
        self.update(data)
        return self.digest()


class SHA1Engine:
    """SHA-1 hash engine implementing ARM crypto extensions."""

    H0 = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0]

    def __init__(self):
        self.state = list(self.H0)
        self.buffer = b''
        self.length = 0

    def reset(self) -> None:
        """Reset hash state."""
        self.state = list(self.H0)
        self.buffer = b''
        self.length = 0

    def _rotl(self, x: int, n: int) -> int:
        """Left rotate 32-bit value."""
        return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF

    def sha1c(self, hash_abcd: bytes, hash_e: int, w: bytes) -> bytes:
        """SHA1C instruction: Choose function rounds."""
        state = struct.unpack('<4I', hash_abcd)
        words = struct.unpack('<4I', w)

        a, b, c, d = state
        e = hash_e

        for i in range(4):
            f = (b & c) | ((~b) & d)
            k = 0x5A827999
            t = (self._rotl(a, 5) + f + e + k + words[i]) & 0xFFFFFFFF
            e = d
            d = c
            c = self._rotl(b, 30)
            b = a
            a = t

        return struct.pack('<4I', a, b, c, d)

    def sha1p(self, hash_abcd: bytes, hash_e: int, w: bytes) -> bytes:
        """SHA1P instruction: Parity function rounds."""
        state = struct.unpack('<4I', hash_abcd)
        words = struct.unpack('<4I', w)

        a, b, c, d = state
        e = hash_e

        for i in range(4):
            f = b ^ c ^ d
            k = 0x6ED9EBA1
            t = (self._rotl(a, 5) + f + e + k + words[i]) & 0xFFFFFFFF
            e = d
            d = c
            c = self._rotl(b, 30)
            b = a
            a = t

        return struct.pack('<4I', a, b, c, d)

    def sha1m(self, hash_abcd: bytes, hash_e: int, w: bytes) -> bytes:
        """SHA1M instruction: Majority function rounds."""
        state = struct.unpack('<4I', hash_abcd)
        words = struct.unpack('<4I', w)

        a, b, c, d = state
        e = hash_e

        for i in range(4):
            f = (b & c) | (b & d) | (c & d)
            k = 0x8F1BBCDC
            t = (self._rotl(a, 5) + f + e + k + words[i]) & 0xFFFFFFFF
            e = d
            d = c
            c = self._rotl(b, 30)
            b = a
            a = t

        return struct.pack('<4I', a, b, c, d)

    def sha1h(self, value: int) -> int:
        """SHA1H instruction: Rotate left by 30."""
        return self._rotl(value, 30)

    def sha1su0(self, w0: bytes, w1: bytes, w2: bytes) -> bytes:
        """SHA1SU0 instruction: Schedule update 0."""
        words0 = struct.unpack('<4I', w0)
        words1 = struct.unpack('<4I', w1)
        words2 = struct.unpack('<4I', w2)

        result = [
            words0[0] ^ words1[0] ^ words2[0],
            words0[1] ^ words1[1] ^ words2[1],
            words0[2] ^ words1[2] ^ words2[2],
            words0[3] ^ words1[3] ^ words2[3],
        ]

        return struct.pack('<4I', *result)

    def sha1su1(self, w0: bytes, w1: bytes) -> bytes:
        """SHA1SU1 instruction: Schedule update 1 (rotate)."""
        words0 = struct.unpack('<4I', w0)
        words1 = struct.unpack('<4I', w1)

        result = [
            self._rotl(words0[0] ^ words1[3], 1),
            self._rotl(words0[1], 1),
            self._rotl(words0[2], 1),
            self._rotl(words0[3] ^ (self._rotl(words0[0] ^ words1[3], 1)), 1),
        ]

        return struct.pack('<4I', *result)


class CRC32Engine:
    """CRC32 engine implementing ARM CRC32 instructions."""

    # CRC32 polynomial (IEEE 802.3)
    POLY = 0xEDB88320
    # CRC32C polynomial (Castagnoli)
    POLY_C = 0x82F63B78

    def __init__(self, polynomial: int = None, castagnoli: bool = False):
        if polynomial is None:
            polynomial = self.POLY_C if castagnoli else self.POLY

        self.polynomial = polynomial
        self.table = self._build_table(polynomial)

    def _build_table(self, polynomial: int) -> list[int]:
        """Build CRC lookup table."""
        table = []
        for i in range(256):
            crc = i
            for _ in range(8):
                if crc & 1:
                    crc = (crc >> 1) ^ polynomial
                else:
                    crc >>= 1
            table.append(crc)
        return table

    def crc32b(self, crc: int, data: int) -> int:
        """CRC32B instruction: CRC of byte."""
        crc ^= data & 0xFF
        return (crc >> 8) ^ self.table[crc & 0xFF]

    def crc32h(self, crc: int, data: int) -> int:
        """CRC32H instruction: CRC of halfword."""
        for i in range(2):
            crc = self.crc32b(crc, (data >> (i * 8)) & 0xFF)
        return crc

    def crc32w(self, crc: int, data: int) -> int:
        """CRC32W instruction: CRC of word."""
        for i in range(4):
            crc = self.crc32b(crc, (data >> (i * 8)) & 0xFF)
        return crc

    def crc32x(self, crc: int, data: int) -> int:
        """CRC32X instruction: CRC of doubleword."""
        for i in range(8):
            crc = self.crc32b(crc, (data >> (i * 8)) & 0xFF)
        return crc

    def crc32(self, data: bytes, initial: int = 0xFFFFFFFF) -> int:
        """Calculate CRC32 of data."""
        crc = initial
        for byte in data:
            crc = (crc >> 8) ^ self.table[(crc ^ byte) & 0xFF]
        return crc ^ 0xFFFFFFFF


class PMULLEngine:
    """Polynomial multiply engine implementing ARM PMULL instructions."""

    def pmull(self, a: int, b: int, size: int = 64) -> int:
        """
        PMULL instruction: Polynomial multiply.
        Performs carry-less multiplication.
        """
        result = 0
        for i in range(size):
            if b & (1 << i):
                result ^= a << i
        return result

    def pmull2(self, a: int, b: int) -> tuple[int, int]:
        """
        PMULL2 instruction: Polynomial multiply (upper elements).
        Returns 128-bit result as (high, low) tuple.
        """
        result = self.pmull(a, b, 64)
        return (result >> 64, result & ((1 << 64) - 1))


@dataclass
class CryptoStatistics:
    """Statistics for crypto operations."""
    aes_operations: int = 0
    sha_operations: int = 0
    crc_operations: int = 0
    pmull_operations: int = 0
    total_bytes_encrypted: int = 0
    total_bytes_hashed: int = 0


class CryptoEmulator:
    """
    Main crypto emulator providing ARM crypto extension support.
    """

    def __init__(self):
        self.aes = AESEngine()
        self.sha256 = SHA256Engine()
        self.sha1 = SHA1Engine()
        self.crc32 = CRC32Engine(castagnoli=False)
        self.crc32c = CRC32Engine(castagnoli=True)
        self.pmull = PMULLEngine()

        self.statistics = CryptoStatistics()
        self._enabled = True
        self._intercept_mode = False

        # Hooks for custom implementations
        self._hooks: dict[str, Callable] = {}

    @property
    def enabled(self) -> bool:
        """Check if crypto emulation is enabled."""
        return self._enabled

    def enable(self) -> None:
        """Enable crypto emulation."""
        self._enabled = True

    def disable(self) -> None:
        """Disable crypto emulation."""
        self._enabled = False

    def set_intercept_mode(self, enabled: bool) -> None:
        """Set intercept mode for crypto operations."""
        self._intercept_mode = enabled

    def register_hook(self, instruction: str, callback: Callable) -> None:
        """Register hook for crypto instruction."""
        self._hooks[instruction] = callback

    def unregister_hook(self, instruction: str) -> None:
        """Remove hook for crypto instruction."""
        self._hooks.pop(instruction, None)

    # AES instruction handlers
    def handle_aese(self, state: bytes, round_key: bytes) -> bytes:
        """Handle AESE instruction."""
        if not self._enabled:
            return state

        if 'aese' in self._hooks:
            return self._hooks['aese'](state, round_key)

        self.statistics.aes_operations += 1
        return self.aes.aese(state, round_key)

    def handle_aesd(self, state: bytes, round_key: bytes) -> bytes:
        """Handle AESD instruction."""
        if not self._enabled:
            return state

        if 'aesd' in self._hooks:
            return self._hooks['aesd'](state, round_key)

        self.statistics.aes_operations += 1
        return self.aes.aesd(state, round_key)

    def handle_aesmc(self, state: bytes) -> bytes:
        """Handle AESMC instruction."""
        if not self._enabled:
            return state

        if 'aesmc' in self._hooks:
            return self._hooks['aesmc'](state)

        self.statistics.aes_operations += 1
        return self.aes.aesmc(state)

    def handle_aesimc(self, state: bytes) -> bytes:
        """Handle AESIMC instruction."""
        if not self._enabled:
            return state

        if 'aesimc' in self._hooks:
            return self._hooks['aesimc'](state)

        self.statistics.aes_operations += 1
        return self.aes.aesimc(state)

    # SHA-256 instruction handlers
    def handle_sha256h(self, hash_state: bytes, w: bytes, k: bytes) -> bytes:
        """Handle SHA256H instruction."""
        if not self._enabled:
            return hash_state

        if 'sha256h' in self._hooks:
            return self._hooks['sha256h'](hash_state, w, k)

        self.statistics.sha_operations += 1
        return self.sha256.sha256h(hash_state, w, k)

    def handle_sha256h2(self, hash_state: bytes, w: bytes, k: bytes) -> bytes:
        """Handle SHA256H2 instruction."""
        if not self._enabled:
            return hash_state

        if 'sha256h2' in self._hooks:
            return self._hooks['sha256h2'](hash_state, w, k)

        self.statistics.sha_operations += 1
        return self.sha256.sha256h2(hash_state, w, k)

    def handle_sha256su0(self, w0: bytes, w1: bytes) -> bytes:
        """Handle SHA256SU0 instruction."""
        if not self._enabled:
            return w0

        if 'sha256su0' in self._hooks:
            return self._hooks['sha256su0'](w0, w1)

        self.statistics.sha_operations += 1
        return self.sha256.sha256su0(w0, w1)

    def handle_sha256su1(self, w0: bytes, w1: bytes, w2: bytes) -> bytes:
        """Handle SHA256SU1 instruction."""
        if not self._enabled:
            return w0

        if 'sha256su1' in self._hooks:
            return self._hooks['sha256su1'](w0, w1, w2)

        self.statistics.sha_operations += 1
        return self.sha256.sha256su1(w0, w1, w2)

    # SHA-1 instruction handlers
    def handle_sha1c(self, hash_abcd: bytes, hash_e: int, w: bytes) -> bytes:
        """Handle SHA1C instruction."""
        if not self._enabled:
            return hash_abcd

        self.statistics.sha_operations += 1
        return self.sha1.sha1c(hash_abcd, hash_e, w)

    def handle_sha1p(self, hash_abcd: bytes, hash_e: int, w: bytes) -> bytes:
        """Handle SHA1P instruction."""
        if not self._enabled:
            return hash_abcd

        self.statistics.sha_operations += 1
        return self.sha1.sha1p(hash_abcd, hash_e, w)

    def handle_sha1m(self, hash_abcd: bytes, hash_e: int, w: bytes) -> bytes:
        """Handle SHA1M instruction."""
        if not self._enabled:
            return hash_abcd

        self.statistics.sha_operations += 1
        return self.sha1.sha1m(hash_abcd, hash_e, w)

    def handle_sha1h(self, value: int) -> int:
        """Handle SHA1H instruction."""
        if not self._enabled:
            return value

        self.statistics.sha_operations += 1
        return self.sha1.sha1h(value)

    def handle_sha1su0(self, w0: bytes, w1: bytes, w2: bytes) -> bytes:
        """Handle SHA1SU0 instruction."""
        if not self._enabled:
            return w0

        self.statistics.sha_operations += 1
        return self.sha1.sha1su0(w0, w1, w2)

    def handle_sha1su1(self, w0: bytes, w1: bytes) -> bytes:
        """Handle SHA1SU1 instruction."""
        if not self._enabled:
            return w0

        self.statistics.sha_operations += 1
        return self.sha1.sha1su1(w0, w1)

    # CRC instruction handlers
    def handle_crc32b(self, crc: int, data: int, castagnoli: bool = False) -> int:
        """Handle CRC32B/CRC32CB instruction."""
        if not self._enabled:
            return crc

        self.statistics.crc_operations += 1
        engine = self.crc32c if castagnoli else self.crc32
        return engine.crc32b(crc, data)

    def handle_crc32h(self, crc: int, data: int, castagnoli: bool = False) -> int:
        """Handle CRC32H/CRC32CH instruction."""
        if not self._enabled:
            return crc

        self.statistics.crc_operations += 1
        engine = self.crc32c if castagnoli else self.crc32
        return engine.crc32h(crc, data)

    def handle_crc32w(self, crc: int, data: int, castagnoli: bool = False) -> int:
        """Handle CRC32W/CRC32CW instruction."""
        if not self._enabled:
            return crc

        self.statistics.crc_operations += 1
        engine = self.crc32c if castagnoli else self.crc32
        return engine.crc32w(crc, data)

    def handle_crc32x(self, crc: int, data: int, castagnoli: bool = False) -> int:
        """Handle CRC32X/CRC32CX instruction."""
        if not self._enabled:
            return crc

        self.statistics.crc_operations += 1
        engine = self.crc32c if castagnoli else self.crc32
        return engine.crc32x(crc, data)

    # PMULL instruction handlers
    def handle_pmull(self, a: int, b: int, size: int = 64) -> int:
        """Handle PMULL instruction."""
        if not self._enabled:
            return 0

        self.statistics.pmull_operations += 1
        return self.pmull.pmull(a, b, size)

    def handle_pmull2(self, a: int, b: int) -> tuple[int, int]:
        """Handle PMULL2 instruction."""
        if not self._enabled:
            return (0, 0)

        self.statistics.pmull_operations += 1
        return self.pmull.pmull2(a, b)

    # High-level operations
    def aes_encrypt(self, plaintext: bytes, key: bytes) -> bytes:
        """Encrypt data with AES."""
        self.aes.set_key(key)

        # Pad to block size
        padding_len = 16 - (len(plaintext) % 16)
        padded = plaintext + bytes([padding_len] * padding_len)

        result = b''
        for i in range(0, len(padded), 16):
            block = padded[i:i+16]
            encrypted = self.aes.encrypt_block(block)
            result += encrypted

        self.statistics.total_bytes_encrypted += len(plaintext)
        return result

    def aes_decrypt(self, ciphertext: bytes, key: bytes) -> bytes:
        """Decrypt data with AES."""
        self.aes.set_key(key)

        result = b''
        for i in range(0, len(ciphertext), 16):
            block = ciphertext[i:i+16]
            decrypted = self.aes.decrypt_block(block)
            result += decrypted

        # Remove padding
        if result:
            padding_len = result[-1]
            result = result[:-padding_len]

        return result

    def sha256_hash(self, data: bytes) -> bytes:
        """Calculate SHA-256 hash."""
        self.statistics.total_bytes_hashed += len(data)
        return self.sha256.hash(data)

    def crc32_checksum(self, data: bytes, castagnoli: bool = False) -> int:
        """Calculate CRC32 checksum."""
        engine = self.crc32c if castagnoli else self.crc32
        return engine.crc32(data)

    def get_statistics(self) -> dict[str, Any]:
        """Get crypto operation statistics."""
        return {
            'aes_operations': self.statistics.aes_operations,
            'sha_operations': self.statistics.sha_operations,
            'crc_operations': self.statistics.crc_operations,
            'pmull_operations': self.statistics.pmull_operations,
            'total_bytes_encrypted': self.statistics.total_bytes_encrypted,
            'total_bytes_hashed': self.statistics.total_bytes_hashed,
        }

    def reset_statistics(self) -> None:
        """Reset statistics counters."""
        self.statistics = CryptoStatistics()


def create_crypto_emulator() -> CryptoEmulator:
    """Create a new crypto emulator."""
    return CryptoEmulator()


# Convenience aliases
AES = AESEngine
SHA256 = SHA256Engine
SHA1 = SHA1Engine
CRC32 = CRC32Engine
PMULL = PMULLEngine


__all__ = [
    # Enums
    'CryptoAlgorithm',
    'CryptoOperation',

    # Engines
    'AESEngine',
    'SHA256Engine',
    'SHA1Engine',
    'CRC32Engine',
    'PMULLEngine',

    # Main emulator
    'CryptoEmulator',
    'CryptoContext',
    'CryptoStatistics',

    # Convenience
    'create_crypto_emulator',
    'AES',
    'SHA256',
    'SHA1',
    'CRC32',
    'PMULL',
]
