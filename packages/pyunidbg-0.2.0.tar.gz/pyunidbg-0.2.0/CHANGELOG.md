# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2026-05-11

### Added
- **Web interface** — FastAPI + WebSocket SPA with session management,
  uploader, terminal (xterm.js), disassembly view, hex editor, hook /
  breakpoint manager, scripting tab, live log streaming. Static assets
  are now served from `web/static/{css,js}` (split out of the previous
  monolithic `index.html`).
- **`x86` / `x86_64` emulation backend** — full Unicorn / Capstone
  integration (`X86Reg`, `X86_64Reg` enums, register maps, ARCH_MAP).
- **System V AMD64 ABI** — RDI, RSI, RDX, RCX, R8, R9 then stack;
  cdecl on x86 (all stack).
- **Stack-argument ABI everywhere** — `CPUContext.get_arg()` /
  `set_arg()` reads and writes overflow arguments from the stack on
  ARM (>= 4), ARM64 (>= 8), x86 (all), x86_64 (>= 6).
- **Full `struct stat`** — `fstat` returns every field on ARM64 (128 B)
  and ARM32 (88 B): dev, ino, mode, nlink, uid, gid, rdev, size,
  blksize, blocks, atime/mtime/ctime.
- **`strptime` / `swprintf`** — real implementations (datetime parser
  and full wide-string format engine).
- **Frida-API compatibility layer** — `Memory.protect/alloc`,
  `Module.load/enumerateImports/enumerateRanges`,
  `Process.enumerateRanges`, `_register_hook`,
  `_register_replacement`, `_call_native_function`.
- **Concolic execution engine** — instruction-level symbolic lifting,
  taint tracking, coverage-guided mutation, Z3 solver bridge.
- **ROP gadget finder** — multi-arch semantic classification, quality
  scoring, automatic mprotect/execve chain generation.
- **Anti-tampering detection** — CRC/hash constant scanning, code-read
  loop and self-modifying code detection, auto-bypass.
- **Remote debugging protocol** — VS Code DAP server and LLDB
  extensions on top of the GDB stub.
- **Automatic API deobfuscation** — `dlsym`/`GetProcAddress` hooks,
  hash-based resolution detection (ROR13/DJB2/CRC32), string-decryption
  monitoring.
- **Import reconstruction** — runtime PLT/GOT monitoring, IAT rebuild,
  thunk resolution, IDA script export.
- **Snapshot diffing**, **memory-leak detector**, **DWARF / EHFRAME
  unwinding**, **dynamic-library versioning**, **hardware breakpoints**,
  **coverage-visualization HTML/JSON/LCOV reports**, **thread sync
  primitives**.


## [0.1.0] - 2026-02-09

### Added
- ARM and ARM64 emulation powered by Unicorn Engine.
- ELF / `.so` loading with full support for Android shared libraries.
- Complete `JNIEnv` and `JavaVM` implementation.
- Linux / Android syscall emulation.
- Function-, syscall-, and memory-access hooking.
- Breakpoints, single stepping, memory inspection.
- Snapshot save / restore.
- Plugin system.
- Full CLI for working with native libraries.
- GDB debug server.
- Coverage analysis with `drcov` output.
