# PyUniDbg Roadmap

Public, high-level roadmap. For per-release detail see
[CHANGELOG.md](CHANGELOG.md). For tracked bugs and ad-hoc work see
the GitHub issue tracker.

---

## Status today

- 4 architectures: ARM, ARM64, x86, x86_64.
- Stable Android layer (JNI, syscalls, libc, anti-debug bypass).
- Beta iOS layer (Mach-O loader, basic Objective-C, syscall stubs).
- 13 000+ unit tests, ~88 % code coverage on the core.
- Web UI (FastAPI + WebSocket) and GDB / DAP debug bridges.
- Frida-compatible scripting API.

---

## Short term (next minor release)

| Area              | Item                                                      |
|-------------------|-----------------------------------------------------------|
| Web UI            | Persisted projects (`.pyudbg` bundle), import/export      |
| Web UI            | Re-attach to a running session after a page reload        |
| Integrations      | Reduce `integrations/ida.py` complexity, document API     |
| Loader            | Improve `core/linker.py` test coverage (currently 63 %)   |
| iOS               | Lift coverage of `ios/syscall.py` and `ios/emulator.py`   |
| Tooling           | Cross-platform CI (Linux + macOS + Windows runners)       |
| Docs              | Add a "writing an example" page and per-architecture guides|

## Medium term

| Area              | Item                                                      |
|-------------------|-----------------------------------------------------------|
| Analysis          | Control-flow flattening detector and CFG recovery         |
| Analysis          | String encryption analyser (auto-decrypt common schemes)  |
| Analysis          | ML-assisted function boundary detection                   |
| Performance       | Memory-hook batching for contiguous regions               |
| Performance       | Disassembly cache for repeated lifts                      |
| Performance       | Lazy symbol resolution                                    |
| Architecture      | MIPS, PowerPC, RISC-V backends as first-class targets     |
| Scripting         | Type stubs (`.pyi`) for IDE autocompletion                |
| Tooling           | Performance benchmarks tracked over time                  |

## Long term

| Area              | Item                                                      |
|-------------------|-----------------------------------------------------------|
| Architecture      | ARM64 MTE (Memory Tagging Extension) emulation            |
| Architecture      | Intel CET (Control-flow Enforcement Technology)           |
| Architecture      | Full x87 / SSE / AVX precision and SIMD acceleration      |
| Architecture      | Multi-core / true-parallel thread emulation               |
| Targets           | WebAssembly target                                        |
| Forensics         | Volatility plug-in (memory snapshot integration)          |
| Detection         | YARA-rule matching during emulation                       |
| Ecosystem         | Plug-in marketplace                                       |

---

## Already shipped

- Concolic execution engine
- ROP gadget finder
- Anti-tampering detection
- Remote debugging (DAP / LLDB)
- Automatic API deobfuscation
- Import reconstruction
- x86 / x86_64 backend with full ABI
- Frida API compatibility layer
- Hardware breakpoints, DWARF/EHFRAME unwinding
- Memory-leak detector, library versioning
- Coverage visualisation (HTML / JSON / LCOV)
- Web UI

See the [changelog](CHANGELOG.md) for the full history.

---

## Want to help?

Pick anything from this roadmap (or open an issue with a new idea),
read [CONTRIBUTING.md](CONTRIBUTING.md) and send a PR.
