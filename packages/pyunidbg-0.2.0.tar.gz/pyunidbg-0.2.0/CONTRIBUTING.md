# Contributing to PyUniDbg

Thank you for taking the time to contribute. PyUniDbg is an open project and welcomes pull requests, bug reports, documentation improvements, and new feature ideas.

By contributing, you agree that your contributions will be licensed under
the [Apache License, Version 2.0](LICENSE).

---

## Table of Contents

1. [Code of Conduct](#code-of-conduct)
2. [Getting the Source](#getting-the-source)
3. [Development Setup](#development-setup)
4. [Project Structure](#project-structure)
5. [Running Tests](#running-tests)
6. [Code Style](#code-style)
7. [Type Hints](#type-hints)
8. [Writing Tests](#writing-tests)
9. [Coverage Requirements](#coverage-requirements)
10. [Submitting a Pull Request](#submitting-a-pull-request)
11. [Commit Message Format](#commit-message-format)
12. [Reporting Bugs](#reporting-bugs)
13. [Suggesting Features](#suggesting-features)
14. [Architecture Notes for Contributors](#architecture-notes-for-contributors)

---

## Code of Conduct

Be respectful and constructive. Focus criticism on code and design, not people. Discrimination or harassment of any kind is not tolerated.

---

## Getting the Source

```bash
git clone https://github.com/elvi7major/PyUniDbg.git
cd PyUniDbg
```

---

## Development Setup

### 1. Create a virtual environment

```bash
python3.13 -m venv .venv
source .venv/bin/activate
```

### 2. Install in editable mode with dev extras

```bash
pip install -e ".[dev]"
```

This installs:
- All runtime dependencies (`unicorn`, `capstone`, `keystone-engine`, `lief`, `colorama`, `rich`)
- Dev tools: `pytest`, `pytest-cov`, `black`, `ruff`, `mypy`

### 3. Verify the install

```bash
python -c "import pyunidbg; print(pyunidbg.__version__)"
PYTHONPATH=src pytest tests/ -x -q
```

---

## Project Structure

```
PyUniDbg/
├── src/pyunidbg/       Source code (single package)
│   ├── core/           Arch-agnostic engine
│   ├── android/        Android emulation layer
│   ├── ios/            iOS emulation (beta)
│   ├── debug/          GDB server, debugger, tracer
│   ├── analysis/       Static & dynamic analysis tools
│   ├── integrations/   IDA / Ghidra / Binja / Radare2
│   ├── scripting/      Frida-compatible scripting API
│   ├── web/            FastAPI web UI (server.py + static/)
│   └── ...
├── tests/              Unit tests (one file per module where possible)
├── examples/           Runnable examples
│   └── real_world_demo/  Full end-to-end walk-through
├── plugins/            IDE-server plugins (load inside IDA / Ghidra)
├── docs/               User-facing documentation
├── scripts/            Maintenance scripts (coverage runner, ...)
├── pyproject.toml      Package metadata and tool config
├── LICENSE             Apache-2.0 license text
├── NOTICE              Third-party attributions
├── CHANGELOG.md        Per-release history
├── ROADMAP.md          Public roadmap
└── README.md           Project overview
```

All source code lives under `src/pyunidbg/`. Tests live in `tests/`. There is a one-to-one correspondence between source modules and test files where possible.

---

## Running Tests

### Without coverage (fast)

```bash
PYTHONPATH=src pytest tests/ -x -q
```

### With coverage

The `lief` C++ library can crash under `pytest-cov` instrumentation. Use the custom runner instead:

```bash
PYTHONPATH=src python scripts/run_tests_with_coverage.py tests/ \
    --cov=pyunidbg --cov-report=term
```

### Specific test file

```bash
PYTHONPATH=src pytest tests/test_core_hooks.py -v
```

### Specific test

```bash
PYTHONPATH=src pytest tests/test_core_hooks.py::test_address_hook -v
```

### Parallel tests

```bash
pip install pytest-xdist
PYTHONPATH=src pytest tests/ -n auto -q
```

---

## Code Style

PyUniDbg uses **Black** for formatting and **Ruff** for linting. Both are configured in `pyproject.toml`.

### Auto-format

```bash
black src/ tests/
```

### Lint

```bash
ruff check src/ tests/
```

### Fix lint automatically

```bash
ruff check --fix src/ tests/
```

### Configuration

| Tool | Line length | Target |
|------|-------------|--------|
| Black | 100 | py313 |
| Ruff | 100 | E, F, W, I, N, UP, B, C4 |

**Do not** submit code that fails `black --check` or `ruff check`. CI will reject it.

---

## Type Hints

All new code must include type hints. Use `from __future__ import annotations` at the top of every file so forward references work cleanly.

```python
from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pyunidbg.core.emulator import Emulator


def my_function(emu: Emulator, address: int) -> int | None:
    ...
```

### Running mypy

```bash
mypy src/pyunidbg --ignore-missing-imports
```

mypy warnings are not currently blocking (it is not run in CI), but we strive to keep the type coverage clean.

---

## Writing Tests

### Location

Each source module `src/pyunidbg/<path>.py` should have a corresponding test file `tests/test_<module_name>.py`.

### Conventions

- Use `pytest` (no `unittest.TestCase`).
- Use `conftest.py` fixtures for shared emulator instances.
- Keep each test function focused on one behaviour.
- Name tests `test_<what_it_tests>`.

### Fixtures

The shared `conftest.py` provides:

```python
@pytest.fixture
def emu():
    """A fresh AndroidEmulator for each test."""
    from pyunidbg import AndroidEmulator
    return AndroidEmulator(arch="arm64")

@pytest.fixture
def emu32():
    from pyunidbg import AndroidEmulator
    return AndroidEmulator(arch="arm")
```

### Example test

```python
# tests/test_my_feature.py

import pytest
from pyunidbg import AndroidEmulator, HookAction


@pytest.fixture
def emu():
    return AndroidEmulator(arch="arm64")


def test_address_hook_fires(emu):
    buf = emu.memory.allocate(0x10)
    emu.memory.write(buf, b"\xC0\x03\x5F\xD6")  # RET

    fired = []

    @emu.hook.address(buf)
    def on_entry(e, address, size):
        fired.append(address)
        return HookAction.STOP

    emu.call(buf)
    assert fired == [buf]


def test_memory_read(emu):
    buf = emu.memory.allocate(0x10)
    emu.memory.write_u32(buf, 0xDEADBEEF)
    assert emu.memory.read_u32(buf) == 0xDEADBEEF
```

### Mocking lief

Tests that indirectly import `lief` (via `elf_loader`) should mock it:

```python
from unittest.mock import MagicMock, patch

@patch("pyunidbg.loader.elf_loader.lief", MagicMock())
def test_loader_init():
    from pyunidbg.loader.elf_loader import ELFLoader
    # ...
```

The script `scripts/run_tests_with_coverage.py` does this globally before importing pytest.

---

## Coverage Requirements

- **New modules** should reach **90 %+ coverage** before merging.
- **Critical modules** (`core/emulator`, `core/hooks`, `core/memory`,
  `android/jni/env`) must maintain their current level or better.
- The overall project target is **≥ 90 %**.

Check coverage for your changes:

```bash
PYTHONPATH=src python scripts/run_tests_with_coverage.py tests/test_my_feature.py \
    --cov=pyunidbg.my_module --cov-report=term-missing
```

---

## Submitting a Pull Request

1. **Fork** the repository and create a branch from `main`:

   ```bash
   git checkout -b feature/my-feature
   ```

2. **Make your changes** — one logical change per PR where possible.

3. **Add tests** for any new behaviour.

4. **Run the full test suite** and ensure it passes.

5. **Format and lint**:

   ```bash
   black src/ tests/
   ruff check src/ tests/
   ```

6. **Update documentation** if you added a public API — add or update the relevant file in `docs/`.

7. **Push** your branch and open a Pull Request against `main`.

### PR checklist

- [ ] Tests pass (`PYTHONPATH=src pytest tests/ -q`)
- [ ] Code formatted (`black --check src/ tests/`)
- [ ] Linting clean (`ruff check src/ tests/`)
- [ ] New public API has type hints
- [ ] `docs/` updated if the API changed
- [ ] `CHANGELOG` entry added (see format below)

---

## Commit Message Format

Use the conventional commits format:

```
<type>(<scope>): <short description>

[optional body]

[optional footer]
```

### Types

| Type | When to use |
|------|-------------|
| `feat` | New feature |
| `fix` | Bug fix |
| `docs` | Documentation only |
| `test` | Adding or updating tests |
| `refactor` | Code restructuring without behaviour change |
| `perf` | Performance improvement |
| `chore` | Build, CI, tooling |
| `style` | Formatting only (no logic change) |

### Examples

```
feat(android): add ptrace bypass for anti-debug detection

fix(jni): handle NULL jstring in GetStringUTFChars

test(core/hooks): add coverage for RETRY action

docs(jni): document NewDirectByteBuffer API

refactor(syscalls): split file_ops into read and write modules
```

---

## Reporting Bugs

Open a GitHub Issue with:

1. **PyUniDbg version** (`python -c "import pyunidbg; print(pyunidbg.__version__)"`)
2. **Python version** (`python --version`)
3. **OS and architecture**
4. **Minimal reproducer** — the shortest script that triggers the bug
5. **Expected behaviour** vs **actual behaviour**
6. **Full traceback** (if applicable)

---

## Suggesting Features

Open a GitHub Issue labelled `enhancement` with:

1. **Use case** — what are you trying to do?
2. **Proposed API** — sketch of the Python interface
3. **Alternatives considered**
4. **Willingness to implement** — are you opening a PR?

For large features (new modules, architecture changes), open a discussion first so we can agree on the design before writing code.

---

## Architecture Notes for Contributors

### Adding a new libc function

1. Add the Python handler to the appropriate file in `src/pyunidbg/android/libc/` (e.g. `string.py`, `stdlib.py`).
2. Register it in `LibcHandler.list_functions()` / `get_function()` in `handler.py`.
3. Add a test in `tests/test_libc_<category>.py`.

### Adding a new syscall

1. Add the syscall number to `SyscallARM64` / `SyscallARM32` in `android/syscalls/defs.py`.
2. Implement the handler in the appropriate ops module (`file_ops.py`, `process_ops.py`, etc.).
3. Register it in `SyscallHandler._register_handlers()`.
4. Add tests.

### Adding a new JNI function

1. Add the function index to `JNIFunctionIndex` in `android/jni/constants.py`.
2. Implement the method on `JNIEnv` in `android/jni/env.py`.
3. Add the dispatch case in `JNIEnv._dispatch_jni_function()`.
4. Add tests.

### Adding a new architecture

1. Add the enum value to `Architecture` in `core/constants.py`.
2. Add register constants (e.g. `MIPSReg`) in `core/constants.py`.
3. Add Unicorn/Capstone constant mapping in `core/cpu.py` and `core/emulator.py`.
4. Add ABI helpers (argument registers, calling convention) in `arch/abi.py`.
5. Add architecture-specific module in `arch/<name>.py`.
6. Add tests.

### Dependency on `lief`

`lief` is used only in `loader/elf_loader.py` and `core/linker.py`. When writing tests for these modules, mock `lief` at the import level:

```python
import sys
from unittest.mock import MagicMock
sys.modules["lief"] = MagicMock()
```

Do not let `lief` leak into other modules — keep parsing isolated to the loader layer.
