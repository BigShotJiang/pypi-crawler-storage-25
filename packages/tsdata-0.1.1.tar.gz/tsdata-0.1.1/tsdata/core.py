import os
import json
from pathlib import Path
from typing import Any, Dict, Optional

import pandas as pd
import requests

DEFAULT_PROXY_URL = os.getenv("MYDATA_PROXY_URL", "http://aplucreat.xyz/api/tushare")
TOKEN_PATH = Path(os.path.expanduser('~')) / "c_t.csv"
REQUEST_TIMEOUT = int(os.getenv("MYDATA_TIMEOUT", "30"))
MYDATA_DEBUG = os.getenv("MYDATA_DEBUG", "0") in {"1", "true", "True"}

class ProxyAuthError(RuntimeError):
    pass

class MyDataClient:
    def __init__(
        self,
        proxy_url: Optional[str] = None,
        timeout: int = REQUEST_TIMEOUT,
    ) -> None:
        self.proxy_url = proxy_url or DEFAULT_PROXY_URL
        self.timeout = timeout
        self.session = requests.Session()

    def query(self, api_name: str, fields: Optional[str] = None, **params: Any) -> pd.DataFrame:
        token = _get_token()
        if not token:
            raise ProxyAuthError("请先通过 set_token(token) 设置有效的服务端 Token")

        # normalize token
        token = token.strip()

        payload: Dict[str, Any] = {
            "token": token,
            "api_name": api_name,
            "params": params or {},
        }
        if fields:
            payload["fields"] = fields

        headers = {"Authorization": f"Bearer {token}"}

        if MYDATA_DEBUG:
            print("[tsdata] POST", self.proxy_url)
            print("[tsdata] headers:", headers)
            print("[tsdata] payload:", json.dumps(payload, ensure_ascii=False))

        response = self.session.post(self.proxy_url, json=payload, headers=headers, timeout=self.timeout)

        if response.status_code >= 400:
            # try to extract server error message for better diagnostics
            err_text = response.text
            try:
                j = response.json()
                # pick common keys
                for k in ("error", "message", "msg", "detail"):
                    if k in j:
                        err_text = j[k]
                        break
            except Exception:
                pass
            if MYDATA_DEBUG:
                print(f"[tsdata] response status={response.status_code}, body={response.text}")
            raise ProxyAuthError(f"请求失败: {response.status_code} {err_text}")
        return self._to_dataframe(response.json())

    def _to_dataframe(self, data: Any) -> pd.DataFrame:
        if isinstance(data, pd.DataFrame):
            return data
        if isinstance(data, list):
            return pd.DataFrame(data)
        if isinstance(data, dict):
            return pd.DataFrame([data]) if data else pd.DataFrame()
        return pd.DataFrame({"result": [data]})

    def close(self) -> None:
        self.session.close()

def pro_api() -> MyDataClient:
    return MyDataClient()

def query(api_name: str, fields: Optional[str] = None, **params: Any) -> pd.DataFrame:
    client = pro_api()
    try:
        return client.query(api_name, fields, **params)
    finally:
        client.close()

def set_token(token: str) -> None:
    TOKEN_PATH.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_PATH.write_text(token.strip(), encoding="utf-8")

def _get_token() -> Optional[str]:
    if not TOKEN_PATH.exists():
        return None
    content = TOKEN_PATH.read_text(encoding="utf-8").strip()
    return content or None

__all__ = [
    "MyDataClient",
    "pro_api",
    "query",
    "set_token",
]


#写一个简单的测试用例
if __name__ == "__main__":
    import argparse
    import sys

    def parse_kv_pairs(pairs) -> Dict[str, str]:
        result = {}
        for pair in pairs:
            if "=" not in pair:
                raise argparse.ArgumentTypeError(f"参数必须是 key=value 形式: {pair}")
            key, value = pair.split("=", 1)
            result[key] = value
        return result


    def main() -> int:
        parser = argparse.ArgumentParser(description="tsdata 客户端手动测试")
        parser.add_argument("--token", default="你的token", help="服务端 Token")
        parser.add_argument("--api", default="daily", help="api_name")
        parser.add_argument("--fields", default=None, help="ts_code,name")
        parser.add_argument(
            "--param",
            action="append",
            default=[],
            help="附加参数，格式 key=value，可多次指定",
        )
        parser.add_argument(
            "--proxy-url",
            default=DEFAULT_PROXY_URL,
            help="服务地址，默认为环境配置",
        )
        args = parser.parse_args()

        params = parse_kv_pairs(args.param)
        set_token(args.token)

        print(f"调用 {args.api}，参数: {params}，fields={args.fields or '默认'}")
        client = MyDataClient(proxy_url=args.proxy_url)
        try:
            df = client.query(args.api, fields=args.fields, **params)
        finally:
            client.close()
        print("返回数据预览（前 5 行）：")
        print(df.head())
        return 0


    sys.exit(main())