---
name: hybris-tests-router
description: Router principal de linguagem natural para geração de testes Hybris. Ativado apenas quando o prompt NÃO começa com /junit ou /cypress.
---

# Router de testes Hybris

Este arquivo é carregado pelo aXet quando o prompt não começa com `/junit` ou `/cypress`.

## Detecção de contexto

Analise o workspace para determinar o perfil do usuário:

**Indicadores de Dev (ambiente local):**
- Workspace contém extensão Hybris com código Java (`.java` files em `src/main/java/`)
- Ausência de `cypress.config.ts` na raiz
- Branch name sem "d1", "d2", "staging", "prod"
- Pedido menciona "JUnit", "unit test", "teste unitário", classe Java

**Indicadores de Arquiteto (ambiente D1):**
- Workspace contém `cypress.config.ts` ou diretório `cypress/`
- Branch name contém "d1", "regression", "e2e"
- Pedido menciona "Cypress", "E2E", "regressivo", "checkout flow", "login flow"

## Fluxo de decisão

```
prompt recebido (sem /junit ou /cypress)
       │
       ├─ indicadores Dev claros? → carrega hybris-tests-dev.md
       │
       ├─ indicadores Arch claros? → carrega hybris-tests-arch.md
       │
       └─ ambíguo? → use ask_followup_question:
              "Você está em ambiente local (dev) ou D1 (arquiteto)?
               - Dev local: gero testes JUnit para código Java
               - D1 arquiteto: gero Cypress spec para fluxos E2E"
```

## Regra obrigatória

**Antes de qualquer geração de teste**, sempre use `ask_followup_question` para apresentar o plano (cenários, mocks, asserts planejados) e aguardar confirmação. Nunca chame `write_to_file` sem aprovação explícita do usuário.

## Scope

Este arquivo carrega o contexto correto. Toda lógica de geração está nas skills específicas (`hybris-junit`, `spartacus-cypress`, `accelerator-jsp-cypress`) e na skill base (`hybris-base`).
