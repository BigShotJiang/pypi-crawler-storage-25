---
name: hybris-tests-commands
description: Comandos diretos /junit e /cypress para geração de testes Hybris. Bypassa o router de linguagem natural.
---

# Comandos disponíveis

## /junit <ClassName>

Gera testes JUnit para a classe Hybris informada.

**Uso:**
- `/junit DefaultProductPopulator`
- `/junit AraucoDesignClubDAO`
- `/junit CustomProductInterceptor`

**Comportamento:**
1. Carrega `.axetrules/hybris-tests-dev.md` diretamente — ignora `hybris-tests.md`.
2. Executa `skills/hybris-junit/scripts/parse_java_class.py <ClassName>.java` para análise da classe.
3. Apresenta plano (cenários, mocks, asserts) via `ask_followup_question` antes de gerar.
4. Gera teste via `write_to_file` somente após confirmação.
5. Executa `skills/hybris-junit/scripts/run-junit.sh` para validar. Se falhar, invoca `skills/hybris-junit/scripts/test-healer.py`.

**Guardrail:** `/junit` é para testes de CÓDIGO (comportamento técnico). Nunca inclua regra de negócio.

---

## /cypress <fluxo> [--spartacus | --jsp]

Gera Cypress spec para o fluxo de negócio informado.

**Uso:**
- `/cypress checkout --spartacus`
- `/cypress b2b-checkout --jsp`
- `/cypress login` (detecção automática de storefront)
- `/cypress plp-search --spartacus`

**Comportamento:**
1. Carrega `.axetrules/hybris-tests-arch.md` diretamente — ignora `hybris-tests.md`.
2. Flag `--spartacus` força `skills/spartacus-cypress/`; `--jsp` força `skills/accelerator-jsp-cypress/`.
3. Sem flag: detecta automaticamente pelo workspace (presença de `cypress.config.ts`, imports Spartacus).
4. Verifica se ambiente D1 tem massa de dados antes de gerar.
5. Apresenta plano via `ask_followup_question` antes de gerar.
6. Gera spec via `write_to_file` somente após confirmação.

**Guardrail:** `/cypress` é para testes de NEGÓCIO (fluxos funcionais E2E). Nunca inclua lógica de implementação técnica.

---

## Regra de bypass

Se o prompt começa com `/junit` ou `/cypress`, o aXet ignora `hybris-tests.md` e carrega diretamente o arquivo de contexto da persona correspondente. Não há heurística de detecção — o comando é explícito.
