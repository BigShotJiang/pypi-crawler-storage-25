---
name: hybris-tests-arch
description: Contexto para Persona B (Arquiteto/Analista) — geração de testes Cypress em ambiente D1.
---

# Contexto: Arquiteto/Analista SAP Commerce (ambiente D1)

Você está auxiliando um arquiteto ou analista que trabalha em D1 (integrado) e precisa gerar Cypress specs para testes E2E de fluxos de negócio.

## Carregamento de skills

1. Carregue `skills/hybris-base/SKILL.md` para contexto Hybris geral.
2. Detecção de storefront:
   - Se `cypress/e2e/` contiver imports de `@spartacus/` ou workspace tiver `angular.json` → carregue `skills/spartacus-cypress/SKILL.md`.
   - Se workspace tiver templates `.jsp` ou flag `--jsp` foi usada → carregue `skills/accelerator-jsp-cypress/SKILL.md`.
   - Se projeto híbrido ou detecção ambígua → carregue ambas.

## Verificação de dados em D1

Antes de gerar o Cypress spec, use `ask_followup_question`:

> "O ambiente D1 tem massa de dados para o fluxo '[nome do fluxo]'? (ex: produto cadastrado, usuário B2B ativo, carrinho funcional). Se não tiver, posso incluir fixtures ImpEx no spec."

## Guardrails obrigatórios

1. **Cypress testa REGRAS DE NEGÓCIO** — fluxos funcionais ponta-a-ponta (checkout, login, carrinho, PLP, PDP). Nunca inclua validação de implementação técnica.
2. **Apresente plano antes de gerar** — use `ask_followup_question` mostrando: fluxo end-to-end mapeado, interceptações OCC planejadas (`cy.intercept`), dados necessários. Só gere após confirmação.
3. **Não gere JUnit** neste contexto. Se o usuário pedir teste unitário, redirecione para `/junit` com contexto dev.
4. **Padrão de helpers, não POM** — siga `skills/spartacus-cypress/references/helpers-not-pom.md`.

## Fluxo de geração

```
1. Identifica fluxo alvo e storefront (via prompt ou /cypress <fluxo> [--flag])
2. Verifica dados em D1 (ask_followup_question)
3. Carrega skill de Cypress correspondente
4. Apresenta plano via ask_followup_question
5. Após confirmação → write_to_file (gera spec)
6. Executa run-cypress.sh para validar
7. Se falhar → invoca test-healer.py (máx 3 iterações)
8. Reporta resultado ao arquiteto (incluindo screenshots se falhou)
```
