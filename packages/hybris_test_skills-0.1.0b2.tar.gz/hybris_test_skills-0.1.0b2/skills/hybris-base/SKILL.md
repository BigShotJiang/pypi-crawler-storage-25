---
name: hybris-base
description: Conhecimento base sobre SAP Commerce (Hybris) para auxiliar geração de testes. Não gera testes diretamente — fornece contexto para skills de geração.
---

# hybris-base — Conhecimento SAP Commerce

Adaptado de Emenowicz/sap-commerce-skill (MIT). Compatível com Hybris 2211+.

## O que esta skill fornece

Contexto Hybris geral para que skills de geração de testes (`hybris-junit`, `spartacus-cypress`, `accelerator-jsp-cypress`) funcionem corretamente sem precisar "aprender Hybris do zero" a cada prompt.

## Referências disponíveis (carregar sob demanda)

Carregue apenas as referências relevantes para a classe/fluxo sendo testado:

| Arquivo | Quando carregar |
|---------|----------------|
| `references/testing-guide.md` | Sempre — contém @UnitTest, @IntegrationTest, padrões de teste |
| `references/type-system.md` | Quando classe usa tipos Hybris (ItemModel, localized attributes) |
| `references/service-layer-architecture.md` | Quando classe é Facade, Service ou DAO |
| `references/flexiblesearch-reference.md` | Quando classe contém FlexibleSearch queries |
| `references/impex-guide.md` | Quando teste precisa de fixtures de dados (IntegrationTest) |
| `references/code-conventions.md` | Sempre — para formatação correta do código gerado |
| `references/spring-configuration.md` | Quando classe usa @Resource, @Autowired, bean aliases |

## Assets disponíveis

- `assets/service-layer/` — implementações de referência: DefaultProductService, ProductDAO, etc.

## Restrição

Esta skill **não gera testes**. Todo output de código de teste vem de `hybris-junit`, `spartacus-cypress` ou `accelerator-jsp-cypress`.
