---
name: testing-guide
description: Referência de @UnitTest e @IntegrationTest em SAP Commerce — anotações, estrutura, exemplos Given/When/Then
---

# Testing Guide — SAP Commerce (Hybris)

> Adaptado de Emenowicz/sap-commerce-skill (MIT). Foco em geração de testes JUnit para projetos NTT Data Brasil.

## Anotações de Teste

SAP Commerce usa anotações de `de.hybris.bootstrap.annotations` para classificar testes:

| Anotação | Descrição | Requer DB | Quando usar |
|----------|-----------|-----------|-------------|
| `@UnitTest` | Sem Spring context, sem DB | Não | Facade, Service, Populator, Interceptor (lógica pura) |
| `@IntegrationTest` | Spring context carregado; DB disponível | Sim | DAO, fluxos end-to-end, testes com ImpEx fixtures |
| `@PerformanceTest` | Testes de carga — excluídos do CI | Sim | Benchmarks específicos |
| `@ManualTest` | Nunca executado em CI | - | Testes exploratórios |

```java
import de.hybris.bootstrap.annotations.UnitTest;
import de.hybris.bootstrap.annotations.IntegrationTest;

@UnitTest
public class DefaultProductFacadeTest { ... }

@IntegrationTest
public class ProductDAOIntegrationTest extends ServicelayerTest { ... }
```

## @UnitTest — Sem Spring, com Mockito

Use para: Facade, Service, Populator, Interceptor (ValidateInterceptor, PrepareInterceptor).

```java
import de.hybris.bootstrap.annotations.UnitTest;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.product.ProductService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

@UnitTest
public class DefaultProductFacadeTest {

	@InjectMocks
	private DefaultProductFacade productFacade;

	@Mock
	private ProductService productService;

	@Mock
	private Converter<ProductModel, ProductData> productConverter;

	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void shouldReturnConvertedDataWhenProductExists() {
		// Given
		final String code = "TEST_PRODUCT";
		final ProductModel model = new ProductModel();
		model.setCode(code);
		final ProductData data = new ProductData();
		data.setCode(code);

		when(productService.getProductForCode(code)).thenReturn(model);
		when(productConverter.convert(model)).thenReturn(data);

		// When
		final ProductData result = productFacade.getProductForCode(code);

		// Then
		assertThat(result).isNotNull();
		assertThat(result.getCode()).isEqualTo(code);
		verify(productService).getProductForCode(code);
		verify(productConverter).convert(model);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowWhenCodeIsNull() {
		productFacade.getProductForCode(null);
	}
}
```

### Imports padrão para @UnitTest

```java
import de.hybris.bootstrap.annotations.UnitTest;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;
```

## @IntegrationTest — Com Spring Context

Use para: DAO (FlexibleSearch), fluxos que exigem ModelService real, testes com dados ImpEx.

```java
import de.hybris.bootstrap.annotations.IntegrationTest;
import de.hybris.platform.servicelayer.ServicelayerTest;
import de.hybris.platform.servicelayer.model.ModelService;
import org.junit.Before;
import org.junit.Test;

import javax.annotation.Resource;

import static org.assertj.core.api.Assertions.assertThat;

@IntegrationTest
public class ProductDAOIntegrationTest extends ServicelayerTest {

	@Resource
	private ProductDAO productDAO;

	@Resource
	private ModelService modelService;

	@Before
	public void setUp() throws Exception {
		importCsv("/myextension/test/testdata-products.impex", "utf-8");
	}

	@Test
	public void shouldReturnProductWhenCodeExists() {
		// Given
		final String code = "TEST_PROD_001";

		// When
		final ProductModel product = productDAO.findByCode(code);

		// Then
		assertThat(product).isNotNull();
		assertThat(product.getCode()).isEqualTo(code);
	}

	@Test
	public void shouldReturnNullWhenCodeDoesNotExist() {
		final ProductModel product = productDAO.findByCode("NON_EXISTENT_XYZ");
		assertThat(product).isNull();
	}
}
```

### ServicelayerTest vs ServicelayerTransactionalTest

| Classe base | Comportamento | Usar quando |
|-------------|---------------|-------------|
| `ServicelayerTest` | Dados persistem entre testes | Testes de leitura, dados compartilhados |
| `ServicelayerTransactionalTest` | Rollback automático após cada @Test | Testes que escrevem dados — evita poluição |

```java
// Prefira transacional para testes que criam/modificam dados
@IntegrationTest
public class ProductServiceIntegrationTest extends ServicelayerTransactionalTest {
    // cada @Test faz rollback automaticamente
}
```

### Imports padrão para @IntegrationTest

```java
import de.hybris.bootstrap.annotations.IntegrationTest;
import de.hybris.platform.servicelayer.ServicelayerTest;
import de.hybris.platform.servicelayer.ServicelayerTransactionalTest;
import javax.annotation.Resource;
import org.junit.Before;
import org.junit.Test;
import static org.assertj.core.api.Assertions.assertThat;
```

## Tabela: O que testar em cada camada

| Componente | Tipo de teste | Classe base | Mockear |
|------------|--------------|-------------|---------|
| Facade | @UnitTest | (nenhuma) | Service, Converter |
| Service (lógica de negócio) | @UnitTest | (nenhuma) | DAO, ModelService |
| Populator | @UnitTest | (nenhuma) | — (dados diretos) |
| ValidateInterceptor | @UnitTest | (nenhuma) | InterceptorContext |
| DAO (FlexibleSearch) | @IntegrationTest | ServicelayerTransactionalTest | — (real) |
| Service (@Transactional) | @IntegrationTest | ServicelayerTransactionalTest | — (real) |

## Estrutura Given/When/Then

Todo teste deve seguir o padrão AAA (Arrange/Act/Assert) com comentários explícitos:

```java
@Test
public void shouldCalculateDiscountWhenCustomerIsVIP() {
	// Given
	final CustomerModel customer = new CustomerModel();
	customer.setCustomerType(CustomerType.VIP);
	when(customerService.getCurrentCustomer()).thenReturn(customer);
	when(priceData.getValue()).thenReturn(BigDecimal.valueOf(100.00));

	// When
	final BigDecimal discountedPrice = pricingFacade.calculatePrice(priceData);

	// Then
	assertThat(discountedPrice).isEqualByComparingTo(BigDecimal.valueOf(90.00));
	verify(customerService).getCurrentCustomer();
}
```

## Testando Populators

Populators são ideais para @UnitTest puro — sem mocks, dados diretos:

```java
@UnitTest
public class ProductBasicPopulatorTest {

	private ProductBasicPopulator populator = new ProductBasicPopulator();

	@Test
	public void shouldPopulateCodeAndNameFromModel() {
		// Given
		final ProductModel source = new ProductModel();
		source.setCode("P001");
		source.setName("Product One");
		final ProductData target = new ProductData();

		// When
		populator.populate(source, target);

		// Then
		assertThat(target.getCode()).isEqualTo("P001");
		assertThat(target.getName()).isEqualTo("Product One");
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowWhenSourceIsNull() {
		populator.populate(null, new ProductData());
	}
}
```

## Testando Interceptors

```java
@UnitTest
public class ProductValidationInterceptorTest {

	private ProductValidationInterceptor interceptor = new ProductValidationInterceptor();

	@Test(expected = InterceptorException.class)
	public void shouldThrowWhenCodeIsNull() throws InterceptorException {
		final ProductModel product = new ProductModel();
		product.setCode(null);
		interceptor.onValidate(product, mock(InterceptorContext.class));
	}

	@Test
	public void shouldPassWhenCodeIsValid() throws InterceptorException {
		final ProductModel product = new ProductModel();
		product.setCode("VALID-CODE");
		// Não deve lançar exceção
		interceptor.onValidate(product, mock(InterceptorContext.class));
	}
}
```

## Executando Testes

```bash
# Todos os @UnitTest da extensão
ant unittests -Dtestclasses.extensions=myextension

# Todos os @IntegrationTest (requer DB)
ant integrationtests -Dtestclasses.extensions=myextension

# Classe específica
ant unittests -Dtestclasses.names=com.ntt.myext.facade.DefaultProductFacadeTest

# Todos os testes (unit + integration)
ant alltests -Dtestclasses.extensions=myextension
```

## Boas Práticas NTT

1. **Prefixo TEST_ em ImpEx** — evita colisão com dados de outros testes
2. **`@Resource` em vez de `@Autowired`** — padrão NTT e SAP Commerce (resolve por nome/alias)
3. **`ServicelayerTransactionalTest`** para testes que escrevem dados
4. **AssertJ** para assertions fluentes (`assertThat()`) em vez de JUnit básico
5. **Um comportamento por @Test** — nome do método descreve o comportamento esperado
6. **Não testar geters/setters** — apenas lógica de negócio
