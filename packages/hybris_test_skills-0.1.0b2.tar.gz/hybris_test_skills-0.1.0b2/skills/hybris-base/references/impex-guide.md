---
name: impex-guide
description: Guia ImpEx SAP Commerce — importCsv(), fixtures para @IntegrationTest, INSERT_UPDATE, macros
---

# ImpEx Guide — SAP Commerce (Hybris)

> Adaptado de Emenowicz/sap-commerce-skill (MIT). Foco em fixtures de dados para @IntegrationTest.

## Uso em @IntegrationTest com importCsv()

O método `importCsv()` está disponível em classes que estendem `ServicelayerTest` ou `ServicelayerTransactionalTest`. Ele carrega um arquivo `.impex` do classpath da extensão.

```java
@IntegrationTest
public class ProductDAOIntegrationTest extends ServicelayerTransactionalTest {

    @Before
    public void setUp() throws Exception {
        // Caminho relativo ao resources/ da extensão
        importCsv("/myextension/test/testdata-products.impex", "utf-8");
    }
}
```

## Localização do arquivo ImpEx na extensão

```
myextension/
└── resources/
    └── myextension/
        └── test/
            ├── testdata-products.impex
            ├── testdata-categories.impex
            └── testdata-users.impex
```

A convenção de caminho no `importCsv()` é:
```
"/myextension/test/<nome-do-arquivo>.impex"
```

## Formato básico

```impex
# Comentário — ignorado pelo parser
INSERT_UPDATE Product;code[unique=true];name[lang=en];catalogVersion(catalog(id),version)
;TEST_P001;Test Product One;testCatalog:Online
;TEST_P002;Test Product Two;testCatalog:Online
```

### Operações disponíveis

| Operação | Comportamento |
|----------|---------------|
| `INSERT` | Cria apenas — falha se já existe |
| `UPDATE` | Atualiza apenas — falha se não existe |
| `INSERT_UPDATE` | Cria ou atualiza (upsert) — mais seguro para fixtures |
| `REMOVE` | Remove o item |

## Macros para reduzir repetição

```impex
$catalog=testCatalog
$version=Online
$catalogVersion=catalogVersion(catalog(id),version)[unique=true,default=$catalog:$version]
$lang=en

INSERT_UPDATE Product;code[unique=true];$catalogVersion;name[lang=$lang]
;TEST_P001;;Test Product One
;TEST_P002;;Test Product Two
;TEST_P003;;Test Product Three
```

### Macros comuns para testes

```impex
# Catalog e CatalogVersion
$productCatalog=electronicsProductCatalog
$productCV=catalogVersion(catalog(id[default=$productCatalog]),version[default='Online'])

# Prefixo para dados de teste
$testPrefix=TEST_

INSERT_UPDATE Product;code[unique=true];$productCV;name[lang=en]
;${testPrefix}LAPTOP_001;;Test Laptop
;${testPrefix}PHONE_001;;Test Phone
```

## Padrão NTT — prefixo TEST_

Sempre use o prefixo `TEST_` em códigos de dados de teste para evitar colisão com dados de outros testes ou com dados de produção:

```impex
$testPrefix=TEST_

# Categorias de teste
INSERT_UPDATE Category;code[unique=true];name[lang=en];catalogVersion(catalog(id),version)
;${testPrefix}ELECTRONICS;Electronics;testCatalog:Online
;${testPrefix}LAPTOPS;Laptops;testCatalog:Online

# Produtos de teste
INSERT_UPDATE Product;code[unique=true];name[lang=en];approvalStatus(code);catalogVersion(catalog(id),version)
;${testPrefix}LAPTOP_001;Test Laptop 001;approved;testCatalog:Online
;${testPrefix}LAPTOP_002;Test Laptop 002;unapproved;testCatalog:Online

# Relação categoria-produto
INSERT_UPDATE CategoryProductRelation;source(code,catalogVersion(catalog(id),version))[unique=true];target(code,catalogVersion(catalog(id),version))[unique=true]
;${testPrefix}LAPTOPS:testCatalog:Online;${testPrefix}LAPTOP_001:testCatalog:Online
;${testPrefix}LAPTOPS:testCatalog:Online;${testPrefix}LAPTOP_002:testCatalog:Online
```

## Setup de CatalogVersion para testes

Muitos testes precisam de um CatalogVersion. Use o existente do sistema ou crie um dedicado:

```impex
# Criar catalog de teste
INSERT_UPDATE Catalog;id[unique=true];name[lang=en];defaultCatalog
;testCatalog;Test Catalog;false

# Criar CatalogVersion de teste
INSERT_UPDATE CatalogVersion;catalog(id)[unique=true];version[unique=true];active
;testCatalog;Online;true
```

## Fixtures de usuário para testes

```impex
$testPrefix=TEST_

INSERT_UPDATE Customer;uid[unique=true];name;groups(uid)
;${testPrefix}customer@ntt.com;Test Customer;customergroup

INSERT_UPDATE Address;owner(Customer.uid)[unique=true];firstname;lastname;line1;town;country(isocode);billingAddress;shippingAddress
;${testPrefix}customer@ntt.com;Test;User;Rua Teste 123;São Paulo;BR;true;true
```

## Fixtures para testes de Order

```impex
$testPrefix=TEST_
$productCatalog=electronicsProductCatalog
$catalogVersion=catalogVersion(catalog(id[default=$productCatalog]),version[default='Online'])

# Currency necessária para orders
INSERT_UPDATE Currency;isocode[unique=true];symbol;active
;BRL;R$;true

# Unit para produtos
INSERT_UPDATE Unit;unitType[unique=true];code[unique=true]
;pieces;pieces

# Produto base
INSERT_UPDATE Product;code[unique=true];unit(code);$catalogVersion;name[lang=en];approvalStatus(code)
;${testPrefix}ORDER_PROD_001;pieces;;Test Order Product;approved
```

## ImpEx com condicionais (ambiente)

```impex
# Para testes específicos de ambiente (não recomendado em fixtures de teste)
#% if: de.hybris.platform.core.Registry.getCurrentTenant().getTenantID().equals("junit");
INSERT_UPDATE Product;code[unique=true];name[lang=en]
;JUNIT_ONLY_PRODUCT;Junit Only Product
#% endif:
```

## Boas práticas NTT para fixtures de teste

1. **Prefixo `TEST_`** em todos os códigos — evita colisão com dados reais ou de outros testes
2. **Uma fixture por domínio** — `testdata-products.impex`, `testdata-categories.impex`, não misture
3. **`ServicelayerTransactionalTest`** — rollback automático após cada @Test, fixture importada no @Before
4. **Dados mínimos** — importe apenas o necessário para o teste. Não importe catálogos completos
5. **Encoding UTF-8** — sempre `importCsv("/path/file.impex", "utf-8")`
6. **Comentários no ImpEx** — documente o propósito de cada bloco de dados
