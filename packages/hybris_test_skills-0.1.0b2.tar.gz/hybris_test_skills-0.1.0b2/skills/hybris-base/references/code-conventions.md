---
name: code-conventions
description: Convenções NTT Data Brasil para SAP Commerce — indentação (tabs), nomenclatura shouldXWhenY, import order, @Resource
---

# Code Conventions — NTT Data Brasil / SAP Commerce

> Convenções de código NTT Data Brasil para projetos SAP Commerce (Hybris). Aplicar em todo código gerado.

## Indentação e formatação

- **Tabs** (não espaços), width = 4
- Chaves de abertura `{` na mesma linha da declaração
- Linha em branco entre métodos
- Uma linha em branco no final do arquivo
- Máximo 120 caracteres por linha

```java
// CORRETO
public class DefaultProductFacade implements ProductFacade {

	@Resource
	private ProductService productService;

	@Override
	public ProductData getProductForCode(final String code) {
		// ...
	}

	@Override
	public List<ProductData> getProductsForCategory(final String categoryCode) {
		// ...
	}
}
```

## Nomenclatura de classes de teste

- Padrão: `<ClasseTestada>Test`
- Exemplos:
  - `DefaultProductFacade` → `DefaultProductFacadeTest`
  - `DefaultProductService` → `DefaultProductServiceTest`
  - `DefaultProductDAO` → `DefaultProductDAOIntegrationTest` (sufixo IntegrationTest para @IntegrationTest)
  - `ProductBasicPopulator` → `ProductBasicPopulatorTest`

```java
// @UnitTest
@UnitTest
public class DefaultProductFacadeTest { ... }

// @IntegrationTest
@IntegrationTest
public class DefaultProductDAOIntegrationTest extends ServicelayerTransactionalTest { ... }
```

## Nomenclatura de métodos de teste

- Padrão: `should<Comportamento>When<Condição>`
- Alternativa aceita: `<comportamento>_<condicao>` (legado)
- Use verbos descritivos; evite `test` como prefixo

```java
// CORRETO
@Test
public void shouldReturnProductDataWhenProductExists() { ... }

@Test
public void shouldThrowIllegalArgumentExceptionWhenCodeIsNull() { ... }

@Test
public void shouldReturnEmptyListWhenCategoryHasNoProducts() { ... }

@Test
public void shouldApplyVipDiscountWhenCustomerTypeIsVip() { ... }

// EVITAR
@Test
public void testGetProduct() { ... }    // não descreve o comportamento

@Test
public void getProduct() { ... }         // sem "should"
```

## Ordem de imports

Sem wildcard imports. Ordem:
1. `java.*`
2. `javax.*`
3. `org.*`
4. `com.*` (externas: Mockito, AssertJ, etc.)
5. `de.hybris.*` (plataforma)
6. Classes internas do projeto (`com.ntt.*` ou pacote do cliente)

```java
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import de.hybris.bootstrap.annotations.UnitTest;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.product.ProductService;

import com.ntt.myextension.data.ProductData;
import com.ntt.myextension.facades.impl.DefaultProductFacade;
```

## @Resource como padrão (não @Autowired)

SAP Commerce usa alias de beans (`<alias name="default..." alias="..."/>`). `@Resource` resolve por nome (seguindo aliases corretamente). `@Autowired` resolve por tipo e pode causar ambiguidade.

```java
// CORRETO — @Resource resolve pelo alias
@Resource
private ProductService productService;

// Também aceito quando nome do campo não corresponde ao bean
@Resource(name = "productService")
private ProductService myProductService;

// EVITAR em projetos SAP Commerce
@Autowired
private ProductService productService; // pode causar ambiguidade com aliases
```

## Visibilidade de campos e métodos

```java
@UnitTest
public class DefaultProductFacadeTest {

	// Campos: sempre private
	@InjectMocks
	private DefaultProductFacade productFacade;

	@Mock
	private ProductService productService;

	// setUp(): public (padrão JUnit)
	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	// Métodos de teste: public (padrão JUnit)
	@Test
	public void shouldReturnProductWhenCodeIsValid() {
		// ...
	}
}
```

## Uso de `final`

- Parâmetros de método: sempre `final`
- Variáveis locais: sempre `final` (exceto quando reatribuída)
- Campos de classe não-`@Mock`/`@InjectMocks`: `final` quando possível

```java
@Test
public void shouldReturnProductWhenCodeIsValid() {
	// Given
	final String code = "P001";
	final ProductModel model = new ProductModel();
	model.setCode(code);

	given(productService.getProductForCode(code)).willReturn(model);

	// When
	final ProductData result = productFacade.getProductForCode(code);

	// Then
	assertThat(result).isNotNull();
}
```

## AssertJ — padrão de assertions

Use AssertJ (`assertThat`) em vez de JUnit básico (`assertEquals`, `assertTrue`):

```java
// CORRETO — AssertJ
assertThat(result).isNotNull();
assertThat(result.getCode()).isEqualTo("P001");
assertThat(products).hasSize(3);
assertThat(products).isEmpty();
assertThat(products).extracting(ProductModel::getCode)
    .containsExactlyInAnyOrder("P001", "P002", "P003");
assertThat(price).isEqualByComparingTo(BigDecimal.valueOf(90.00));

// EVITAR — JUnit básico
assertEquals("P001", result.getCode());
assertTrue(products.isEmpty());
assertNotNull(result);
```

## Mockito — BDDMockito preferred

Use BDDMockito (`given/willReturn`) para alinhamento com Given/When/Then:

```java
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

// PREFERIDO — BDD style
given(productService.getProductForCode("P001")).willReturn(model);

// ACEITO — mas menos expressivo
when(productService.getProductForCode("P001")).thenReturn(model);
```

## Estrutura de um arquivo de teste completo

```java
package com.ntt.myextension.facades.impl;

import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;

import de.hybris.bootstrap.annotations.UnitTest;
import de.hybris.platform.core.model.product.ProductModel;

import com.ntt.myextension.data.ProductData;
import com.ntt.myextension.services.ProductService;


@UnitTest
public class DefaultProductFacadeTest {

	@InjectMocks
	private DefaultProductFacade productFacade;

	@Mock
	private ProductService productService;

	@Mock
	private Converter<ProductModel, ProductData> productConverter;

	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void shouldReturnProductDataWhenCodeIsValid() {
		// Given
		final String code = "TEST_P001";
		final ProductModel model = new ProductModel();
		model.setCode(code);
		final ProductData data = new ProductData();
		data.setCode(code);

		given(productService.getProductForCode(code)).willReturn(model);
		given(productConverter.convert(model)).willReturn(data);

		// When
		final ProductData result = productFacade.getProductForCode(code);

		// Then
		assertThat(result).isNotNull();
		assertThat(result.getCode()).isEqualTo(code);
		verify(productService).getProductForCode(code);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowIllegalArgumentExceptionWhenCodeIsNull() {
		productFacade.getProductForCode(null);
	}
}
```

## Localização de arquivos de teste

```
myextension/
├── src/
│   └── com/ntt/myextension/
│       └── facades/impl/
│           └── DefaultProductFacade.java
└── testsrc/
    └── com/ntt/myextension/
        └── facades/impl/
            └── DefaultProductFacadeTest.java          (@UnitTest)
        └── daos/impl/
            └── DefaultProductDAOIntegrationTest.java   (@IntegrationTest)
```

O pacote em `testsrc/` deve espelhar o pacote da classe testada em `src/`.
