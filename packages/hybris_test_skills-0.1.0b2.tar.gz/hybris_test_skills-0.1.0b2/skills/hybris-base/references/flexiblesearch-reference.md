---
name: flexiblesearch-reference
description: Referência FlexibleSearch — sintaxe, parâmetros nomeados, JOIN, paginação, ArgumentCaptor para testes DAO
---

# FlexibleSearch Reference — SAP Commerce (Hybris)

> Adaptado de Emenowicz/sap-commerce-skill (MIT). Foco em padrões relevantes para testar DAOs.

## Sintaxe básica

```sql
-- Busca simples por PK (preferido — usa cache do platform)
SELECT {pk} FROM {Product} WHERE {code} = ?code

-- Múltiplos campos (evitar em produção — bypassa cache)
SELECT {pk}, {code}, {name} FROM {Product}

-- Subtipo com ! (exclui subtipos como VariantProduct)
SELECT {pk} FROM {Product!} WHERE {code} LIKE ?pattern
```

## Parâmetros nomeados — NUNCA concatenação de string

```java
// CORRETO — parâmetros nomeados previnem SQL injection
private static final String FIND_BY_CODE =
    "SELECT {pk} FROM {Product} WHERE {code} = ?code";

final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_BY_CODE);
query.addQueryParameter("code", productCode);

// ERRADO — concatenação é vulnerável e não usa o cache de queries
final String query = "SELECT {pk} FROM {Product} WHERE {code} = '" + code + "'";
```

## FlexibleSearchQuery — padrão completo de uso em DAO

```java
public class DefaultProductDAO implements ProductDAO {

    private static final String FIND_BY_CODE =
        "SELECT {pk} FROM {Product} WHERE {code} = ?code";

    private static final String FIND_BY_CATEGORY =
        "SELECT {p.pk} FROM {Product AS p " +
        "JOIN CategoryProductRelation AS cpr ON {p.pk} = {cpr.target} " +
        "JOIN Category AS c ON {cpr.source} = {c.pk}} " +
        "WHERE {c.code} = ?categoryCode";

    private static final String SEARCH_BY_TEXT =
        "SELECT {pk} FROM {Product} " +
        "WHERE LOWER({name}) LIKE LOWER(?searchText) " +
        "ORDER BY {name} ASC";

    @Resource
    private FlexibleSearchService flexibleSearchService;

    @Override
    public ProductModel findByCode(final String code) {
        final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_BY_CODE);
        query.addQueryParameter("code", code);
        query.setResultClassList(Collections.singletonList(ProductModel.class));

        final SearchResult<ProductModel> result = flexibleSearchService.search(query);
        return result.getResult().isEmpty() ? null : result.getResult().get(0);
    }

    @Override
    public List<ProductModel> findByCategory(final String categoryCode) {
        final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_BY_CATEGORY);
        query.addQueryParameter("categoryCode", categoryCode);

        return flexibleSearchService.search(query).getResult();
    }

    @Override
    public List<ProductModel> searchByText(final String text, final int limit, final int offset) {
        final FlexibleSearchQuery query = new FlexibleSearchQuery(SEARCH_BY_TEXT);
        query.addQueryParameter("searchText", "%" + text + "%");
        query.setCount(limit);
        query.setStart(offset);
        query.setNeedTotal(false); // evita COUNT(*) extra

        return flexibleSearchService.search(query).getResult();
    }
}
```

## Parâmetros com HashMap

```java
final Map<String, Object> params = new HashMap<>();
params.put("code", productCode);
params.put("status", ArticleApprovalStatus.APPROVED);

final FlexibleSearchQuery query = new FlexibleSearchQuery(queryString, params);
```

## Parâmetros com coleção (IN)

```java
private static final String FIND_BY_CODES =
    "SELECT {pk} FROM {Product} WHERE {code} IN (?codes)";

final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_BY_CODES);
query.addQueryParameter("codes", Arrays.asList("P001", "P002", "P003"));
```

## JOIN — padrões comuns

```sql
-- JOIN com CatalogVersion
SELECT {p.pk}
FROM {Product AS p
      JOIN CatalogVersion AS cv ON {p.catalogVersion} = {cv.pk}
      JOIN Catalog AS c ON {cv.catalog} = {c.pk}}
WHERE {c.id} = ?catalogId AND {cv.version} = ?version

-- LEFT JOIN (produtos sem StockLevel aparecem com available=null)
SELECT {p.pk}, {s.available}
FROM {Product AS p
      LEFT JOIN StockLevel AS s ON {p.pk} = {s.product}}
WHERE {p.code} = ?code

-- Subquery com IN
SELECT {pk} FROM {Product}
WHERE {pk} IN (
    SELECT {product} FROM {StockLevel} WHERE {available} > 0
)
```

## Constantes de query no DAO

Declare queries como `private static final String` no DAO — facilita testes e manutenção:

```java
public class DefaultOrderDAO implements OrderDAO {

    private static final String FIND_ORDERS_BY_USER =
        "SELECT {pk} FROM {Order} " +
        "WHERE {user} = ?user " +
        "ORDER BY {creationtime} DESC";

    private static final String FIND_RECENT_ORDERS =
        "SELECT {pk} FROM {Order} " +
        "WHERE {creationtime} >= ?startDate " +
        "ORDER BY {creationtime} DESC";

    // ...
}
```

## ArgumentCaptor para capturar queries em @IntegrationTest

Em alguns casos, você quer verificar a query exata passada ao FlexibleSearchService:

```java
@IntegrationTest
public class DefaultProductDAOIntegrationTest extends ServicelayerTransactionalTest {

    @Resource
    private FlexibleSearchService flexibleSearchService;

    @Resource
    private DefaultProductDAO productDAO;

    @Before
    public void setUp() throws Exception {
        importCsv("/myextension/test/testdata-products.impex", "utf-8");
    }

    @Test
    public void shouldPassCorrectParametersToFlexibleSearch() {
        // Usar um spy para capturar a query sem substituir a implementação real
        final FlexibleSearchService spyService = spy(flexibleSearchService);
        productDAO.setFlexibleSearchService(spyService);

        final ArgumentCaptor<FlexibleSearchQuery> captor =
            ArgumentCaptor.forClass(FlexibleSearchQuery.class);

        // When
        productDAO.findByCode("TEST_P001");

        // Then
        verify(spyService).search(captor.capture());
        final FlexibleSearchQuery capturedQuery = captor.getValue();
        assertThat(capturedQuery.getQuery()).contains("Product");
        assertThat(capturedQuery.getQueryParameters()).containsEntry("code", "TEST_P001");
    }
}
```

## Performance — boas práticas para testes

```java
// Prefira {pk} no SELECT — o platform carrega o model via cache
"SELECT {pk} FROM {Product} WHERE {code} = ?code"

// Use setNeedTotal(false) quando não precisa do total
query.setNeedTotal(false);

// Limite resultados em testes com grandes tabelas
query.setCount(100);

// Habilite cache de query em testes de performance
query.setCacheable(true);
query.setResultClassList(Collections.singletonList(ProductModel.class));
```

## COUNT query

```java
private static final String COUNT_PRODUCTS =
    "SELECT COUNT({pk}) FROM {Product} WHERE {approvalStatus} = ?status";

final FlexibleSearchQuery query = new FlexibleSearchQuery(COUNT_PRODUCTS);
query.addQueryParameter("status", ArticleApprovalStatus.APPROVED);
query.setResultClassList(Collections.singletonList(Integer.class));

final SearchResult<Integer> result = flexibleSearchService.search(query);
final int count = result.getResult().get(0);
```

## SearchResult — métodos disponíveis

```java
final SearchResult<ProductModel> result = flexibleSearchService.search(query);

final List<ProductModel> items = result.getResult();       // lista de resultados
final int returned = result.getCount();                    // qtd retornada
final int total = result.getTotalCount();                  // total (requer needTotal=true)
```
