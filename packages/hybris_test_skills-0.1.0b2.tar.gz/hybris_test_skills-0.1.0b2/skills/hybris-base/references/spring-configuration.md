---
name: spring-configuration
description: Configuração Spring em SAP Commerce — @Resource vs @Autowired, bean aliases, injeção em testes @IntegrationTest
---

# Spring Configuration — SAP Commerce (Hybris)

> Adaptado de Emenowicz/sap-commerce-skill (MIT). Foco nos aspectos que afetam a escrita de testes.

## @Resource vs @Autowired — Padrão NTT é @Resource

SAP Commerce usa extensivamente **bean aliases** para permitir override sem modificar o XML original:

```xml
<alias name="defaultProductService" alias="productService"/>
<bean id="defaultProductService" class="com.example.DefaultProductService">
    ...
</bean>
```

`@Resource` resolve **por nome** (seguindo o alias corretamente):
```java
@Resource
private ProductService productService; // resolve "productService" → "defaultProductService"
```

`@Autowired` resolve **por tipo** — pode causar `NoUniqueBeanDefinitionException` quando múltiplos beans implementam a mesma interface, ou injetar o bean errado ignorando o alias:
```java
@Autowired
private ProductService productService; // PODE causar ambiguidade com aliases
```

**Regra NTT:** sempre `@Resource` em código de produção e em @IntegrationTest.

## Como @Resource funciona em @IntegrationTest

Em @IntegrationTest, o Spring Context é carregado. `@Resource` injeta o bean real (não mock):

```java
@IntegrationTest
public class ProductDAOIntegrationTest extends ServicelayerTransactionalTest {

    @Resource
    private ProductDAO productDAO; // Spring injeta o bean "productDAO" (alias → defaultProductDAO)

    @Resource
    private ModelService modelService; // bean da plataforma

    @Resource
    private FlexibleSearchService flexibleSearchService; // bean da plataforma
}
```

## Como usar Mockito em @UnitTest (sem Spring)

Em @UnitTest, não há Spring Context. Use `@InjectMocks` e `@Mock`:

```java
@UnitTest
public class DefaultProductFacadeTest {

    @InjectMocks
    private DefaultProductFacade productFacade; // instanciado com mocks injetados

    @Mock
    private ProductService productService; // mock do Mockito, não bean Spring

    @Mock
    private Converter<ProductModel, ProductData> productConverter;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        // Não precisa de Spring — Mockito injeta os @Mock em @InjectMocks via setter/construtor/campo
    }
}
```

## Bean aliases para override sem modificar XML original

O padrão para extensão de beans sem tocar no XML do core:

```xml
<!-- XML original (não modificar) -->
<!-- Na extensão: commerceservices-spring.xml -->
<alias name="defaultProductService" alias="productService"/>
<bean id="defaultProductService" class="de.hybris.platform.commerceservices.product.impl.DefaultProductService">
    <property name="productDAO" ref="productDAO"/>
</bean>
```

```xml
<!-- XML da extensão customizada: myextension-spring.xml -->
<!-- Sobrescreve o alias — agora "productService" aponta para customProductService -->
<alias name="customProductService" alias="productService"/>
<bean id="customProductService"
      class="com.ntt.myextension.service.impl.CustomProductService"
      parent="defaultProductService"> <!-- herda properties do parent -->
    <property name="customDAO" ref="customDAO"/>
</bean>
```

Em @IntegrationTest, `@Resource private ProductService productService` injeta o `customProductService` automaticamente, pois o alias é resolvido corretamente.

## Verificando que o override funciona em @IntegrationTest

```java
@IntegrationTest
public class ProductServiceOverrideIntegrationTest extends ServicelayerTest {

    @Resource
    private ProductService productService; // deve ser CustomProductService

    @Test
    public void shouldUseCustomImplementation() {
        assertThat(productService).isInstanceOf(CustomProductService.class);
    }
}
```

## Configuração de beans de teste

Para @IntegrationTest que precisa de um bean customizado apenas para teste, crie um XML de contexto de teste:

```xml
<!-- myextension/resources/myextension/test/test-spring.xml -->
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xsi:schemaLocation="http://www.springframework.org/schema/beans
           http://www.springframework.org/schema/beans/spring-beans.xsd">

    <!-- Bean de teste que substitui o real durante testes -->
    <alias name="mockPaymentGateway" alias="paymentGateway"/>
    <bean id="mockPaymentGateway" class="com.ntt.myextension.test.MockPaymentGateway"/>

</beans>
```

```java
@IntegrationTest
@ContextConfiguration(locations = {
    "classpath:/myextension/test/test-spring.xml"
})
public class OrderFacadeIntegrationTest extends ServicelayerTest {
    // paymentGateway agora é o MockPaymentGateway
}
```

## Injeção via setter vs campo

SAP Commerce usa injeção via setter no XML (não construtor). Para consistência, os campos `@Mock` são injetados pelo Mockito via setter ou campo diretamente.

```xml
<!-- Padrão SAP Commerce — injeção via setter no XML -->
<bean id="defaultProductFacade" class="com.example.DefaultProductFacade">
    <property name="productService" ref="productService"/>     <!-- setProductService() -->
    <property name="productConverter" ref="productConverter"/> <!-- setProductConverter() -->
</bean>
```

```java
// A classe deve ter setters (ou campos com @Resource para injeção de campo)
public class DefaultProductFacade implements ProductFacade {

    private ProductService productService;
    private Converter<ProductModel, ProductData> productConverter;

    // Setter para injeção via XML
    public void setProductService(final ProductService productService) {
        this.productService = productService;
    }

    public void setProductConverter(final Converter<ProductModel, ProductData> productConverter) {
        this.productConverter = productConverter;
    }
}
```

## Boas práticas de Spring em testes

1. **`@Resource` no @IntegrationTest** — sempre, nunca `@Autowired`
2. **`@InjectMocks` + `@Mock` no @UnitTest** — substitui Spring completamente
3. **Alias pattern** — ao sobrescrever beans, sempre use `<alias>` sem modificar XML original
4. **`parent` bean** — ao estender implementação, use `parent="defaultXxx"` para herdar properties
5. **Não use `@Autowired` com `required=false`** — use `@Resource` com verificação explícita se necessário
