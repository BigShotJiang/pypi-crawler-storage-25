---
name: service-layer-architecture
description: Arquitetura de camadas SAP Commerce — DAO, Service, Facade — e padrões de mock para testes JUnit
---

# Service Layer Architecture — SAP Commerce (Hybris)

> Adaptado de Emenowicz/sap-commerce-skill (MIT). Foco em como testar cada camada corretamente.

## Visão geral das camadas

```
Controller / OCC API / JSP
        ↓
Facade (DTOs — nunca expõe Models)
        ↓
Service (lógica de negócio, @Transactional)
        ↓
DAO (FlexibleSearch, sem @Transactional)
        ↓
ModelService / FlexibleSearchService (platform)
        ↓
Database
```

**Regra de ouro:** cada camada se comunica apenas com a camada imediatamente abaixo. Facade não acessa DAO diretamente; Controller não acessa Service diretamente (usa Facade).

## Facade — Como testar

Facade transforma DTOs de entrada/saída e delega para Services. Sempre @UnitTest.

```java
@UnitTest
public class DefaultProductFacadeTest {

	@InjectMocks
	private DefaultProductFacade productFacade;

	@Mock
	private ProductService productService;

	@Mock
	private Converter<ProductModel, ProductData> productConverter;

	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void shouldReturnProductDataWhenProductExists() {
		// Given
		final ProductModel model = new ProductModel();
		model.setCode("P001");
		final ProductData expected = new ProductData();
		expected.setCode("P001");

		given(productService.getProductForCode("P001")).willReturn(model);
		given(productConverter.convert(model)).willReturn(expected);

		// When
		final ProductData result = productFacade.getProductForCode("P001");

		// Then
		assertThat(result.getCode()).isEqualTo("P001");
		verify(productService).getProductForCode("P001");
		verify(productConverter).convert(model);
	}
}
```

## Service — Como testar

Services contêm lógica de negócio. Lógica pura → @UnitTest. Integração com DB/ModelService real → @IntegrationTest.

### @UnitTest para Service (lógica pura)

```java
@UnitTest
public class DefaultPricingServiceTest {

	@InjectMocks
	private DefaultPricingService pricingService;

	@Mock
	private ProductDAO productDAO;

	@Mock
	private ModelService modelService;

	@Before
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void shouldApplyVipDiscountWhenCustomerIsVIP() {
		// Given
		final ProductModel product = new ProductModel();
		product.setCode("P001");
		given(productDAO.findByCode("P001")).willReturn(product);

		// When
		final BigDecimal price = pricingService.calculatePrice("P001", CustomerType.VIP);

		// Then
		// VIP desconto de 10%
		assertThat(price).isEqualByComparingTo(BigDecimal.valueOf(90.00));
	}

	@Test
	public void shouldVerifyProductSavedAfterUpdate() {
		// Given
		final ProductModel product = new ProductModel();
		given(productDAO.findByCode("P001")).willReturn(product);

		// When
		pricingService.updateBasePrice("P001", BigDecimal.valueOf(150.00));

		// Then — verificar que modelService.save() foi chamado
		verify(modelService).save(product);
	}
}
```

### ModelService — Padrão de mock em @UnitTest

```java
@Mock
private ModelService modelService;

// Mockar create() para retornar instância real
when(modelService.create(ProductModel.class)).thenReturn(new ProductModel());

// Verificar que save() foi chamado com o model correto
verify(modelService).save(any(ProductModel.class));

// Verificar que remove() foi chamado
verify(modelService).remove(product);

// Para testes que verificam o objeto salvo, use ArgumentCaptor
final ArgumentCaptor<ProductModel> captor = ArgumentCaptor.forClass(ProductModel.class);
verify(modelService).save(captor.capture());
assertThat(captor.getValue().getCode()).isEqualTo("P001");
```

## DAO — Como testar

DAOs usam FlexibleSearch — sempre @IntegrationTest com Spring e DB reais.

```java
@IntegrationTest
public class DefaultProductDAOIntegrationTest extends ServicelayerTransactionalTest {

	@Resource
	private DefaultProductDAO productDAO;

	@Before
	public void setUp() throws Exception {
		importCsv("/myextension/test/testdata-products.impex", "utf-8");
	}

	@Test
	public void shouldReturnProductByCode() {
		// When
		final ProductModel product = productDAO.findByCode("TEST_P001");

		// Then
		assertThat(product).isNotNull();
		assertThat(product.getCode()).isEqualTo("TEST_P001");
	}

	@Test
	public void shouldReturnNullForUnknownCode() {
		assertThat(productDAO.findByCode("INEXISTENTE_XYZ")).isNull();
	}

	@Test
	public void shouldReturnProductsInCategory() {
		// When
		final List<ProductModel> products = productDAO.findByCategory("TEST_CAT_001");

		// Then
		assertThat(products).isNotEmpty();
		assertThat(products).extracting(ProductModel::getCode)
				.containsExactlyInAnyOrder("TEST_P001", "TEST_P002");
	}
}
```

### FlexibleSearchService — Mock para @UnitTest (quando necessário)

Em alguns casos, um Service faz FlexibleSearch diretamente. Mock pattern:

```java
@Mock
private FlexibleSearchService flexibleSearchService;

@SuppressWarnings("unchecked")
@Before
public void setUp() {
	MockitoAnnotations.openMocks(this);

	// Mockar SearchResult
	final SearchResult<ProductModel> searchResult = mock(SearchResult.class);
	when(searchResult.getResult()).thenReturn(Collections.singletonList(new ProductModel()));
	when(flexibleSearchService.search(any(FlexibleSearchQuery.class))).thenReturn(searchResult);
}
```

### SearchResult mock — padrão completo

```java
// Simular lista de resultados
final ProductModel product1 = new ProductModel();
product1.setCode("P001");
final ProductModel product2 = new ProductModel();
product2.setCode("P002");

@SuppressWarnings("unchecked")
final SearchResult<ProductModel> mockResult = mock(SearchResult.class);
when(mockResult.getResult()).thenReturn(Arrays.asList(product1, product2));
when(mockResult.getTotalCount()).thenReturn(2);

when(flexibleSearchService.search(any(FlexibleSearchQuery.class))).thenReturn(mockResult);
```

## Populator/Converter — Como testar

Populators são ideais para @UnitTest puro (sem mocks necessários na maioria dos casos):

```java
@UnitTest
public class ProductBasicPopulatorTest {

	private final ProductBasicPopulator populator = new ProductBasicPopulator();

	@Test
	public void shouldPopulateAllBasicFields() {
		// Given
		final ProductModel source = new ProductModel();
		source.setCode("P001");
		source.setName("Product Name", Locale.ENGLISH);
		final ProductData target = new ProductData();

		// When
		populator.populate(source, target);

		// Then
		assertThat(target.getCode()).isEqualTo("P001");
		assertThat(target.getName()).isEqualTo("Product Name");
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowWhenSourceIsNull() {
		populator.populate(null, new ProductData());
	}
}
```

## Convenções de injeção em Spring

```xml
<!-- Padrão NTT: alias → bean default → extensão customiza apenas o alias -->
<alias name="defaultProductService" alias="productService"/>
<bean id="defaultProductService"
      class="com.ntt.myext.service.impl.DefaultProductService">
    <property name="productDAO" ref="productDAO"/>
    <property name="modelService" ref="modelService"/>
</bean>
```

Em testes @IntegrationTest, use `@Resource` com o nome do alias:

```java
@Resource
private ProductService productService; // resolve pelo alias "productService"
```

## Regra: @Transactional vai no Service, nunca no DAO

```java
// CORRETO: @Transactional no Service
public class DefaultProductService implements ProductService {

    @Override
    @Transactional
    public void updateProduct(final String code, final String name) {
        final ProductModel product = productDAO.findByCode(code);
        product.setName(name);
        modelService.save(product);
    }
}

// ERRADO: @Transactional no DAO — impede o Service de coordenar múltiplos DAOs numa transação
public class DefaultProductDAO implements ProductDAO {

    @Transactional // NÃO FAÇA ISSO
    public ProductModel findByCode(final String code) { ... }
}
```
