---
name: type-system
description: Type system SAP Commerce — ItemModel, atributos localizados (armadilha do IllegalStateException), enums, relações
---

# Type System — SAP Commerce (Hybris)

> Adaptado de Emenowicz/sap-commerce-skill (MIT). Foco nos aspectos relevantes para escrita de testes.

## ItemModel como base de todos os tipos

Todo tipo em Hybris é gerado a partir de `items.xml` e estende indiretamente `ItemModel`. Os modelos ficam em `<extension>/gensrc/` após `ant clean all`.

```java
// Hierarquia simplificada
ItemModel
  └── GenericItemModel
        └── ProductModel
        └── OrderModel
        └── CustomerModel  (estende UserModel)
        └── CategoryModel
```

Em testes, instancie modelos diretamente com `new ProductModel()` para @UnitTest, ou via `modelService.create(ProductModel.class)` em @IntegrationTest.

```java
// @UnitTest — instância direta (não persiste)
final ProductModel product = new ProductModel();
product.setCode("TEST_P001");

// @IntegrationTest — criação via ModelService (persiste no DB)
final ProductModel product = modelService.create(ProductModel.class);
product.setCode("TEST_P001");
modelService.save(product);
```

## Atributos localized — A armadilha do IllegalStateException

Atributos `localized:java.lang.String` em `items.xml` (como `name`, `description`) requerem um `LocaleProvider` ativo. Acessá-los em @UnitTest sem contexto de sessão lança:

```
java.lang.IllegalStateException: No LocaleProvider set in current session
```

### Fix 1 — Usar overload com Locale (recomendado para @UnitTest)

```java
// Em vez de:
product.getName(); // IllegalStateException em @UnitTest!

// Use o overload com Locale:
product.getName(Locale.ENGLISH); // OK em @UnitTest
product.setName("Product Name", Locale.ENGLISH);
```

### Fix 2 — Mockar i18NService em @UnitTest

```java
@Mock
private I18NService i18NService;

@Before
public void setUp() {
	MockitoAnnotations.openMocks(this);
	// Configura locale padrão para evitar IllegalStateException
	when(i18NService.getCurrentLocale()).thenReturn(Locale.ENGLISH);
}
```

### Fix 3 — Em @IntegrationTest, usar setCurrentLocale

```java
@Resource
private I18NService i18NService;

@Before
public void setUp() throws Exception {
	i18NService.setCurrentLocale(Locale.ENGLISH);
	importCsv("/myextension/test/testdata.impex", "utf-8");
}
```

## Enumerações Hybris (não Java enum nativo)

Hybris tem seu próprio sistema de enum. Enums gerados de `items.xml` são objetos de banco — não Java `enum` nativo, mas têm método `.getCode()`.

```xml
<!-- items.xml -->
<enumtype code="ArticleApprovalStatus" autocreate="true" generate="true" dynamic="false">
    <value code="approved"/>
    <value code="unapproved"/>
    <value code="check"/>
</enumtype>
```

```java
// Uso no código
product.setApprovalStatus(ArticleApprovalStatus.APPROVED);

// Em @UnitTest, mock do enum não é necessário — use diretamente
assertThat(product.getApprovalStatus()).isEqualTo(ArticleApprovalStatus.APPROVED);

// Em FlexibleSearch
"SELECT {pk} FROM {Product} WHERE {approvalStatus} = ?status"
query.addQueryParameter("status", ArticleApprovalStatus.APPROVED);
```

## Tipos primitivos e wrappers

| items.xml type | Java gerado | Observação no teste |
|----------------|-------------|---------------------|
| `java.lang.String` | `String` | null por padrão |
| `java.lang.Integer` | `Integer` | null por padrão (não 0!) |
| `java.lang.Boolean` | `Boolean` | null por padrão (não false!) |
| `java.util.Date` | `Date` | null por padrão |
| `localized:java.lang.String` | `String` (com locale) | Requer LocaleProvider — ver seção acima |

```java
// Atenção: campo Integer pode ser null, não 0!
final ProductModel product = new ProductModel();
assertThat(product.getMaxOrderQuantity()).isNull(); // correto
// assertThat(product.getMaxOrderQuantity()).isEqualTo(0); // ERRADO — NPE potencial
```

## Relações OneToMany e ManyToMany

Relações são lazy-loaded. Em @IntegrationTest com dados ImpEx, acesse normalmente. Em @UnitTest, use mocks ou listas diretas.

```java
// @UnitTest — simular relação com lista direta
final CategoryModel category = new CategoryModel();
final ProductModel product = new ProductModel();

// Relações retornam listas imutáveis quando não há contexto de persistência
// Use quando o código-alvo só lê a coleção
final List<ProductModel> products = Collections.singletonList(product);
when(categoryService.getProductsForCategory(category)).thenReturn(products);
```

```java
// @IntegrationTest — relação carregada via ImpEx + FlexibleSearch
// O ImpEx define a relação, o DAO a consulta
importCsv("/myextension/test/testdata-categories.impex", "utf-8");

final List<ProductModel> products = productDAO.findByCategory("electronics");
assertThat(products).hasSize(3);
```

## Definição de tipo — referência rápida para items.xml

```xml
<itemtype code="LoyaltyCard" extends="GenericItem"
          autocreate="true" generate="true">
    <deployment table="LoyaltyCards" typecode="10501"/>
    <attributes>
        <attribute qualifier="cardNumber" type="java.lang.String">
            <modifiers read="true" write="true" optional="false" unique="true"/>
            <persistence type="property"/>
        </attribute>
        <attribute qualifier="balance" type="java.lang.Double">
            <modifiers optional="false"/>
            <persistence type="property"/>
            <defaultvalue>Double.valueOf(0.0)</defaultvalue>
        </attribute>
        <attribute qualifier="description" type="localized:java.lang.String">
            <persistence type="property"/>
        </attribute>
    </attributes>
</itemtype>
```

Após `ant clean all`, o modelo gerado `LoyaltyCardModel` fica disponível para uso nos testes.

## Boas práticas para testes com tipos

1. **Nunca acesse atributos localized sem locale em @UnitTest** — use overload `getAttribute(Locale.ENGLISH)`
2. **Prefira `new ProductModel()` em @UnitTest** — sem `modelService.create()` (que requer Spring)
3. **Typecodes customizados devem estar em 10000–32767** — conflitos causam erros na inicialização
4. **Enum Hybris não é Java enum** — não use `.name()`, use `.getCode()`
