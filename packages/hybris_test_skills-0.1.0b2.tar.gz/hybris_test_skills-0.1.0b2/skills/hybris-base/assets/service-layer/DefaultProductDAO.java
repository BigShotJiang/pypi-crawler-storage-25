/*
 * DefaultProductDAO.java
 * Implementação de referência de ProductDAO usando FlexibleSearch.
 * Adaptado de Emenowicz/sap-commerce-skill (MIT).
 *
 * Padrões demonstrados:
 * - SELECT {pk} (preferido — usa cache da plataforma)
 * - Parâmetros nomeados (nunca concatenação de string)
 * - JOIN para entidades relacionadas
 * - Paginação com setCount/setStart
 * - Constantes de query como private static final
 */
package com.ntt.myextension.daos.impl;

import com.ntt.myextension.daos.ProductDAO;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.servicelayer.search.SearchResult;
import de.hybris.platform.servicelayer.util.ServicesUtil;

import java.util.Collections;
import java.util.List;

import javax.annotation.Resource;


/**
 * Implementação padrão de ProductDAO.
 *
 * IMPORTANTE: DAOs NÃO devem ter @Transactional. Transações são gerenciadas
 * na camada de Service para permitir coordenação de múltiplos DAOs em uma
 * única transação atômica.
 */
public class DefaultProductDAO implements ProductDAO {

	private static final String FIND_BY_CODE =
			"SELECT {pk} FROM {Product} WHERE {code} = ?code";

	private static final String FIND_BY_CODE_AND_CATALOG =
			"SELECT {p.pk} FROM {Product AS p " +
			"JOIN CatalogVersion AS cv ON {p.catalogVersion} = {cv.pk} " +
			"JOIN Catalog AS c ON {cv.catalog} = {c.pk}} " +
			"WHERE {p.code} = ?code " +
			"AND {c.id} = ?catalogId " +
			"AND {cv.version} = ?version";

	private static final String SEARCH_BY_TEXT =
			"SELECT {pk} FROM {Product} " +
			"WHERE LOWER({name}) LIKE LOWER(?searchText) " +
			"ORDER BY {name} ASC";

	private static final String FIND_BY_CATEGORY =
			"SELECT {p.pk} FROM {Product AS p " +
			"JOIN CategoryProductRelation AS cpr ON {p.pk} = {cpr.target} " +
			"JOIN Category AS c ON {cpr.source} = {c.pk}} " +
			"WHERE {c.code} = ?categoryCode";

	private static final String COUNT_ALL =
			"SELECT COUNT({pk}) FROM {Product}";

	@Resource
	private FlexibleSearchService flexibleSearchService;

	@Override
	public ProductModel findByCode(final String code) {
		ServicesUtil.validateParameterNotNull(code, "Product code must not be null");

		final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_BY_CODE);
		query.addQueryParameter("code", code);
		query.setResultClassList(Collections.singletonList(ProductModel.class));

		final SearchResult<ProductModel> result = flexibleSearchService.search(query);
		return result.getResult().isEmpty() ? null : result.getResult().get(0);
	}

	@Override
	public ProductModel findByCodeAndCatalogVersion(final String code,
			final String catalogId, final String catalogVersion) {
		ServicesUtil.validateParameterNotNull(code, "Product code must not be null");
		ServicesUtil.validateParameterNotNull(catalogId, "Catalog id must not be null");
		ServicesUtil.validateParameterNotNull(catalogVersion, "Catalog version must not be null");

		final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_BY_CODE_AND_CATALOG);
		query.addQueryParameter("code", code);
		query.addQueryParameter("catalogId", catalogId);
		query.addQueryParameter("version", catalogVersion);

		final SearchResult<ProductModel> result = flexibleSearchService.search(query);
		return result.getResult().isEmpty() ? null : result.getResult().get(0);
	}

	@Override
	public List<ProductModel> searchByText(final String searchText,
			final int limit, final int offset) {
		ServicesUtil.validateParameterNotNull(searchText, "Search text must not be null");

		final FlexibleSearchQuery query = new FlexibleSearchQuery(SEARCH_BY_TEXT);
		query.addQueryParameter("searchText", "%" + searchText + "%");
		query.setCount(limit);
		query.setStart(offset);
		query.setNeedTotal(false); // evita COUNT(*) extra para paginação simples

		return flexibleSearchService.search(query).getResult();
	}

	@Override
	public List<ProductModel> findByCategory(final String categoryCode) {
		ServicesUtil.validateParameterNotNull(categoryCode, "Category code must not be null");

		final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_BY_CATEGORY);
		query.addQueryParameter("categoryCode", categoryCode);

		return flexibleSearchService.search(query).getResult();
	}

	@Override
	public int countAll() {
		final FlexibleSearchQuery query = new FlexibleSearchQuery(COUNT_ALL);
		query.setResultClassList(Collections.singletonList(Integer.class));

		final SearchResult<Integer> result = flexibleSearchService.search(query);
		return result.getResult().isEmpty() ? 0 : result.getResult().get(0).intValue();
	}

	public void setFlexibleSearchService(final FlexibleSearchService flexibleSearchService) {
		this.flexibleSearchService = flexibleSearchService;
	}
}
