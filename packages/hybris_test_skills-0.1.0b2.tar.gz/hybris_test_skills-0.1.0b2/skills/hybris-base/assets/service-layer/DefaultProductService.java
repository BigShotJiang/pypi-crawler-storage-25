/*
 * DefaultProductService.java
 * Implementação de referência de ProductService.
 * Adaptado de Emenowicz/sap-commerce-skill (MIT).
 *
 * Padrões demonstrados:
 * - @Transactional no Service (nunca no DAO)
 * - ServicesUtil.validateParameterNotNull para validação de entrada
 * - setName(value, Locale) para atributos localizados (evita IllegalStateException)
 * - modelService para criação/persistência
 * - Delegação de consultas ao DAO
 */
package com.ntt.myextension.services.impl;

import com.ntt.myextension.daos.ProductDAO;
import com.ntt.myextension.services.ProductService;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.util.ServicesUtil;

import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Locale;


/**
 * Implementação padrão de ProductService.
 *
 * Responsabilidades:
 * 1. Lógica de negócio e regras de domínio
 * 2. Validação de entrada (ServicesUtil, verificações de negócio)
 * 3. Gerenciamento de transações (@Transactional nos métodos de escrita)
 * 4. Coordenação de DAOs
 * 5. Criação e persistência de Models via ModelService
 */
public class DefaultProductService implements ProductService {

	private ProductDAO productDAO;
	private ModelService modelService;

	@Override
	public ProductModel getProductForCode(final String code) {
		ServicesUtil.validateParameterNotNull(code, "Product code must not be null");
		return productDAO.findByCode(code);
	}

	@Override
	public List<ProductModel> searchProducts(final String searchText,
			final int pageSize, final int currentPage) {
		if (searchText == null || searchText.trim().isEmpty()) {
			return Collections.emptyList();
		}
		final int offset = currentPage * pageSize;
		return productDAO.searchByText(searchText.trim(), pageSize, offset);
	}

	@Override
	public List<ProductModel> getProductsForCategory(final String categoryCode) {
		ServicesUtil.validateParameterNotNull(categoryCode, "Category code must not be null");
		return productDAO.findByCategory(categoryCode);
	}

	@Override
	@Transactional
	public ProductModel createProduct(final String code, final String name) {
		ServicesUtil.validateParameterNotNull(code, "Product code must not be null");
		ServicesUtil.validateParameterNotNull(name, "Product name must not be null");

		// Validação de negócio — código deve ser único
		final ProductModel existing = productDAO.findByCode(code);
		if (existing != null) {
			throw new IllegalArgumentException("Product already exists with code: " + code);
		}

		final ProductModel product = modelService.create(ProductModel.class);
		product.setCode(code);
		product.setName(name, Locale.ENGLISH);
		modelService.save(product);
		return product;
	}

	@Override
	@Transactional
	public void updateProductName(final String code, final String name) {
		ServicesUtil.validateParameterNotNull(code, "Product code must not be null");
		ServicesUtil.validateParameterNotNull(name, "Product name must not be null");

		final ProductModel product = productDAO.findByCode(code);
		if (product == null) {
			throw new IllegalArgumentException("Product not found: " + code);
		}
		product.setName(name, Locale.ENGLISH);
		modelService.save(product);
	}

	@Override
	@Transactional
	public void removeProduct(final String code) {
		ServicesUtil.validateParameterNotNull(code, "Product code must not be null");

		final ProductModel product = productDAO.findByCode(code);
		if (product == null) {
			throw new IllegalArgumentException("Product not found: " + code);
		}
		modelService.remove(product);
	}

	// Setters para injeção via Spring XML
	public void setProductDAO(final ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

	public void setModelService(final ModelService modelService) {
		this.modelService = modelService;
	}
}
