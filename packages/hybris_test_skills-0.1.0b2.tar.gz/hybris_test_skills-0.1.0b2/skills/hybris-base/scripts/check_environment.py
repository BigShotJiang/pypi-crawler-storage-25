#!/usr/bin/env python3
"""
check-environment.py — Valida que todas as ferramentas necessárias estão instaladas.

Exit 0 + "OK" se tudo presente.
Exit 1 + lista do que falta + link para docs/installation.md caso contrário.
"""
import sys
import subprocess
import shutil
import os
import shlex
from pathlib import Path

INSTALLATION_DOCS = "docs/installation.md"


def check_python_version():
    v = sys.version_info
    if v >= (3, 10):
        return True, f"Python {v[0]}.{v[1]}.{v[2]}"
    return False, f"Python {v[0]}.{v[1]} encontrado, precisa de 3.10+"


def check_pip():
    if shutil.which("pip") is None and shutil.which("pip3") is None:
        return False, "pip not found — instale junto com Python 3.10+"
    try:
        result = subprocess.run(
            ["pip", "--version"], capture_output=True, text=True, timeout=10
        )
        parts = result.stdout.split()
        if len(parts) >= 2:
            ver_str = parts[1]
            major = int(ver_str.split(".")[0])
            if major >= 22:
                return True, f"pip {ver_str}"
            return False, f"pip {ver_str} encontrado, precisa de 22+"
        return False, f"pip versão não reconhecida: '{result.stdout.strip()}'"
    except subprocess.TimeoutExpired:
        return False, "pip timeout — verifique instalação"
    except ValueError:
        return False, f"pip versão não reconhecida: '{result.stdout.strip()}'"


def check_bash():
    try:
        result = subprocess.run(
            ["bash", "--version"], capture_output=True, text=True, timeout=10
        )
        line = result.stdout.split("\n")[0]
        # Suporta "version X.Y" (en) e "versão X.Y" (pt)
        for keyword in ("version ", "versão "):
            if keyword in line:
                ver_str = line.split(keyword)[1].split("(")[0].strip()
                major = int(ver_str.split(".")[0])
                if major >= 4:
                    return True, f"bash {ver_str}"
                return False, f"bash {ver_str} encontrado, precisa de 4+"
        return False, f"bash instalado mas versão não reconhecida: '{line[:60]}'"
    except FileNotFoundError:
        return False, "bash not found — Windows: instale WSL2 ou Git Bash"
    except subprocess.TimeoutExpired:
        return False, "bash timeout — verifique instalação"
    except ValueError:
        return False, "bash versão não reconhecida"


def check_node():
    if shutil.which("node") is None:
        return False, "node not found — instale em https://nodejs.org (18+)"
    try:
        result = subprocess.run(
            ["node", "--version"], capture_output=True, text=True, timeout=10
        )
        ver_str = result.stdout.strip().lstrip("v")
        major = int(ver_str.split(".")[0])
        if major >= 18:
            return True, f"node v{ver_str}"
        return False, f"node v{ver_str} encontrado, precisa de 18+"
    except subprocess.TimeoutExpired:
        return False, "node timeout — verifique instalação"
    except ValueError:
        return False, f"node versão não reconhecida: '{result.stdout.strip()}'"


def check_java():
    if shutil.which("java") is None:
        return False, "java not found — do setup SAP Commerce padrão"
    try:
        result = subprocess.run(
            ["java", "-version"], capture_output=True, text=True, timeout=10
        )
        output = result.stderr  # java -version escreve em stderr
        parts = output.split('"')
        if '"' in output and len(parts) >= 2:
            ver_str = parts[1]
            major = int(ver_str.split(".")[0])
            if major >= 17:
                return True, f"java {ver_str}"
            return False, f"java {ver_str} encontrado, precisa de 17+"
        return False, "java version parse falhou"
    except subprocess.TimeoutExpired:
        return False, "java timeout — verifique instalação"
    except ValueError:
        return False, f"java versão não reconhecida: '{output.strip()}'"
    except IndexError:
        return False, "java versão não reconhecida: formato inesperado"


def _find_setantenv() -> Path | None:
    hybris_home = os.environ.get("HYBRIS_HOME")
    if hybris_home:
        p = Path(hybris_home) / "bin" / "platform" / "setantenv.sh"
        return p if p.exists() else None
    current = Path.cwd()
    for _ in range(6):
        candidate = current / "hybris" / "bin" / "platform" / "setantenv.sh"
        if candidate.exists():
            return candidate
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def check_ant():
    if shutil.which("ant") is not None:
        return True, "ant encontrado no PATH"

    setantenv = _find_setantenv()

    if setantenv is None:
        return False, (
            "ant not found e hybris/bin/platform/setantenv.sh não encontrado — "
            "defina HYBRIS_HOME ou rode a partir da raiz do projeto"
        )

    platform_dir = setantenv.parent
    try:
        result = subprocess.run(
            ["bash", "-c",
             f"cd {shlex.quote(str(platform_dir))} && . ./setantenv.sh && ant -version"],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            version_line = result.stdout.split("\n")[0].strip()
            return True, f"ant via setantenv.sh ({version_line})"
        output = result.stdout.strip() if result.stdout.strip() else result.stderr.strip()
        first_line = output.splitlines()[0][:120] if output else ""
        return False, f"setantenv.sh encontrado mas ant falhou: {first_line}"
    except subprocess.TimeoutExpired:
        return False, "ant timeout — verifique instalação do SAP Commerce"


CHECKS = [
    ("Python 3.10+", check_python_version),
    ("pip 22+", check_pip),
    ("Bash 4+", check_bash),
    ("Node.js 18+", check_node),
    ("Java 17+", check_java),
    ("Ant", check_ant),
]


def main():
    print("hybris-test-skills — verificando ambiente...\n")
    failures = []

    for name, check_fn in CHECKS:
        ok, msg = check_fn()
        status = "[OK]     " if ok else "[MISSING]"
        print(f"  {status} {name}: {msg}")
        if not ok:
            failures.append(f"  - {name}: {msg}")

    if not failures:
        print("\nOK — ambiente pronto para hybris-test-skills.")
        sys.exit(0)
    else:
        print("\nRequisitos faltando:")
        for f in failures:
            print(f)
        print(f"\nVeja {INSTALLATION_DOCS} para instruções de instalação.")
        sys.exit(1)


if __name__ == "__main__":
    main()
