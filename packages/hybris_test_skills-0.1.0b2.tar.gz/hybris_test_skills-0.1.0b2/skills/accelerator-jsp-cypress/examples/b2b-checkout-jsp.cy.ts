// b2b-checkout-jsp.cy.ts
// Exemplo: checkout B2B Accelerator JSP com CSRF, cy.session e interceptação de AJAX de frete.

function loginAndSaveSession(username: string, password: string): void {
  cy.session(
    ['b2b-checkout', username],
    () => {
      cy.visit('/login');
      cy.get('input[name="j_username"]').type(username);
      cy.get('input[name="j_password"]').type(password);
      cy.get('[data-cy="login-submit"]').click();
      cy.url().should('not.include', '/login');
    },
    {
      validate() { cy.getCookie('JSESSIONID').should('exist'); },
      cacheAcrossSpecs: true,
    }
  );
}

function addProductToCartJSP(productCode: string): void {
  cy.intercept('POST', '/cart/add').as('addToCartJSP');
  cy.visit(`/p/${productCode}`);
  cy.get('input[name="CSRFToken"]').should('exist');
  cy.get('[data-cy="add-to-cart-btn"], button[type="submit"].addToCartButton').click();
  cy.wait('@addToCartJSP').its('response.statusCode').should('eq', 200);
}

describe('B2B Checkout — Accelerator JSP', () => {
  const USER = Cypress.env('TEST_USER') || 'cypress-test@ntt.com';
  const PASSWORD = Cypress.env('TEST_PASSWORD') || 'Cypress@123';
  const PRODUCT_CODE = Cypress.env('TEST_PRODUCT_CODE') || 'CYPRESS-PROD-001';

  beforeEach(() => {
    loginAndSaveSession(USER, PASSWORD);
  });

  it('should add product to cart with valid CSRF token', () => {
    addProductToCartJSP(PRODUCT_CODE);
    cy.get('.miniCartCount, [data-cy="mini-cart-count"]').should('contain', '1');
  });

  it('should proceed through checkout steps with CSRF on each form', () => {
    addProductToCartJSP(PRODUCT_CODE);

    cy.intercept('GET', '/checkout/multi/delivery-method/getShippingCost*').as('shippingCost');

    // Passo 1: endereço de entrega
    cy.visit('/checkout/multi/delivery-address/add');
    cy.get('input[name="CSRFToken"]').should('exist');
    cy.get('[data-cy="address-first-name"]').type('Cypress');
    cy.get('[data-cy="address-last-name"]').type('Teste');
    cy.get('[data-cy="address-line1"]').type('Rua Teste 123');
    cy.get('[data-cy="address-town"]').type('São Paulo');
    cy.get('[data-cy="address-postcode"]').type('01310-100');
    cy.get('[data-cy="address-submit"]').click();

    cy.url().should('include', '/delivery-method');

    // Passo 2: método de entrega
    cy.wait('@shippingCost');
    cy.get('input[name="deliveryMethodId"]').first().click();
    cy.get('[data-cy="delivery-method-next"]').click();

    cy.url().should('include', '/payment-type');
  });

  it('should validate required fields in shipping address form', () => {
    cy.visit('/checkout/multi/delivery-address/add');
    cy.get('[data-cy="address-submit"]').click();
    cy.get('.help-block, [data-cy="address-error"]').should('be.visible');
    cy.url().should('include', '/delivery-address');
  });

  it('should reject POST without valid CSRF token', () => {
    cy.request({
      method: 'POST',
      url: '/checkout/multi/delivery-address/add',
      form: true,
      failOnStatusCode: false,
      body: {
        CSRFToken: 'token-invalido',
        firstName: 'Teste',
      },
    }).its('status').should('eq', 403);
  });
});
