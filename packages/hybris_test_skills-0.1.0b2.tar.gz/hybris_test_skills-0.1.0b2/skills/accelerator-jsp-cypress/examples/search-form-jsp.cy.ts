// search-form-jsp.cy.ts
// Exemplo: busca via formulário JSP no Accelerator — submit, resultados, paginação.

function performSearch(query: string): void {
  cy.get('input[name="text"], [data-cy="search-input"]').clear().type(query);
  cy.get('button[type="submit"].search, [data-cy="search-submit"]').click();
}

describe('Search Form — Accelerator JSP', () => {
  beforeEach(() => {
    cy.intercept('GET', '/search*').as('searchRequest');
    cy.visit('/');
    cy.get('body').should('be.visible');
  });

  it('should return results for valid search term', () => {
    performSearch('produto');
    cy.wait('@searchRequest').then(({ request }) => {
      expect(request.url).to.include('text=produto');
    });
    cy.url().should('include', '/search');
    cy.get('[data-cy="search-result-item"], .product-listing-item').should('have.length.greaterThan', 0);
  });

  it('should show no results message for unknown term', () => {
    performSearch('xyzabcnoresult99999');
    cy.wait('@searchRequest');
    cy.get('[data-cy="no-results-message"], .noResults').should('be.visible');
  });

  it('should paginate results', () => {
    cy.intercept('GET', '/search*').as('pageRequest');
    performSearch('produto');
    cy.wait('@searchRequest');

    cy.get('[data-cy="pagination-next"], .pagination .next a').click();
    cy.wait('@pageRequest').then(({ request }) => {
      expect(request.url).to.match(/[?&]page=\d+/);
    });
    cy.url().should('match', /[?&]q=produto/);
  });

  it('should navigate to PDP from search result', () => {
    performSearch('produto');
    cy.wait('@searchRequest');
    cy.get('[data-cy="search-result-item"] a, .product-listing-item a.productListingName')
      .first().click();
    cy.url().should('match', /\/p\//);
    cy.get('[data-cy="product-name"], .productPageTitleArea').should('be.visible');
  });

  it('should encode special characters in search query', () => {
    performSearch('café especial');
    cy.wait('@searchRequest').then(({ request }) => {
      expect(decodeURIComponent(request.url)).to.include('café especial');
    });
  });
});
