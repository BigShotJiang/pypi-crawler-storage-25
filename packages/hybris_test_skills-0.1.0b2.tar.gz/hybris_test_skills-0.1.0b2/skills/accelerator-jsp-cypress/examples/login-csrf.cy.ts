// login-csrf.cy.ts
// Exemplo: login Accelerator JSP com CSRFToken e cy.session() para reutilizar JSESSIONID.

function loginAndSaveSession(username: string, password: string): void {
  cy.session(
    ['accelerator-login', username],
    () => {
      cy.visit('/login');
      cy.get('input[name="CSRFToken"]').should('exist').and('not.have.value', '');
      cy.get('input[name="j_username"]').type(username);
      cy.get('input[name="j_password"]').type(password);
      cy.get('[data-cy="login-submit"]').click();
      cy.url().should('not.include', '/login');
    },
    {
      validate() {
        cy.getCookie('JSESSIONID').should('exist');
      },
      cacheAcrossSpecs: true,
    }
  );
}

describe('Login — Accelerator JSP', () => {
  const USER = Cypress.env('TEST_USER') || 'cypress-test@ntt.com';
  const PASSWORD = Cypress.env('TEST_PASSWORD') || 'Cypress@123';

  it('should have CSRF token in login form before submit', () => {
    cy.visit('/login');
    cy.get('input[name="CSRFToken"]')
      .should('exist')
      .invoke('val')
      .should('have.length.greaterThan', 10);
  });

  it('should login successfully and redirect away from /login', () => {
    cy.intercept('POST', '/login*').as('loginPost');

    cy.visit('/login');
    cy.get('input[name="j_username"]').type(USER);
    cy.get('input[name="j_password"]').type(PASSWORD);
    cy.get('[data-cy="login-submit"]').click();

    cy.wait('@loginPost').then(({ request }) => {
      expect(request.body).to.include('CSRFToken=');
      expect(request.body).to.include(`j_username=${encodeURIComponent(USER)}`);
    });
    cy.url().should('not.include', '/login');
    cy.getCookie('JSESSIONID').should('exist');
  });

  it('should show error message for invalid credentials', () => {
    cy.visit('/login');
    cy.get('input[name="j_username"]').type('invalido@ntt.com');
    cy.get('input[name="j_password"]').type('senha-errada');
    cy.get('[data-cy="login-submit"]').click();
    cy.url().should('include', '/login');
    cy.get('.globalMessages .alert-danger, [data-cy="login-error"]')
      .should('be.visible');
  });

  it('should reuse session in subsequent tests via cy.session', () => {
    loginAndSaveSession(USER, PASSWORD);
    cy.visit('/my-account');
    cy.url().should('include', '/my-account');
    cy.get('[data-cy="account-greeting"], .accountNavItem').should('be.visible');
  });

  it('should logout and invalidate session', () => {
    loginAndSaveSession(USER, PASSWORD);
    cy.visit('/logout');
    cy.url().should('not.include', '/my-account');
    cy.getCookie('JSESSIONID').should('not.exist');
  });
});
