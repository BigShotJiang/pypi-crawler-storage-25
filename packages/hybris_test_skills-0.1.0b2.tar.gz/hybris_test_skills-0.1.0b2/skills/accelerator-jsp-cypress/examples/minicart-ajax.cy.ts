// minicart-ajax.cy.ts
// Exemplo: mini-cart AJAX no Accelerator — add, remove, update quantity via jQuery.ajax

function loginAndSaveSession(username: string, password: string): void {
  cy.session(['minicart', username], () => {
    cy.visit('/login');
    cy.get('input[name="j_username"]').type(username);
    cy.get('input[name="j_password"]').type(password);
    cy.get('[data-cy="login-submit"]').click();
    cy.url().should('not.include', '/login');
  }, {
    validate() { cy.getCookie('JSESSIONID').should('exist'); },
  });
}

describe('Mini-Cart AJAX — Accelerator JSP', () => {
  const USER = Cypress.env('TEST_USER') || 'cypress-test@ntt.com';
  const PASSWORD = Cypress.env('TEST_PASSWORD') || 'Cypress@123';
  const PRODUCT_CODE = Cypress.env('TEST_PRODUCT_CODE') || 'CYPRESS-PROD-001';

  beforeEach(() => {
    loginAndSaveSession(USER, PASSWORD);
    cy.intercept('POST', '/cart/add').as('addToCart');
    cy.intercept('GET', '/cart/miniCart').as('miniCartRefresh');
  });

  it('should add product via AJAX and update mini-cart count', () => {
    cy.visit(`/p/${PRODUCT_CODE}`);
    cy.get('[data-cy="add-to-cart-btn"]').click();

    cy.wait('@addToCart').then(({ response }) => {
      expect(response!.statusCode).to.eq(200);
    });
    cy.wait('@miniCartRefresh');
    cy.get('.miniCartCount, [data-cy="mini-cart-count"]').should('contain', '1');
  });

  it('should remove product from mini-cart', () => {
    cy.intercept('POST', '/cart/remove*').as('removeFromCart');

    cy.visit(`/p/${PRODUCT_CODE}`);
    cy.get('[data-cy="add-to-cart-btn"]').click();
    cy.wait('@addToCart');
    cy.wait('@miniCartRefresh');

    cy.get('[data-cy="mini-cart-remove"], .minicart .removeEntry').first().click();
    cy.wait('@removeFromCart').its('response.statusCode').should('eq', 200);
    cy.get('.miniCartCount, [data-cy="mini-cart-count"]').should('contain', '0');
  });

  it('should update quantity in cart via AJAX', () => {
    cy.intercept('POST', '/cart/update*').as('updateCart');

    cy.visit(`/p/${PRODUCT_CODE}`);
    cy.get('[data-cy="add-to-cart-btn"]').click();
    cy.wait('@addToCart');

    cy.visit('/cart');
    cy.get('[data-cy="cart-quantity-input"], input.qty').first().clear().type('3');
    cy.get('[data-cy="cart-quantity-update"], button.updateCartQuantity').first().click();
    cy.wait('@updateCart').its('response.statusCode').should('eq', 200);
    cy.get('[data-cy="cart-total"], .totalPrice').should('not.be.empty');
  });

  it('should show error when adding out-of-stock product', () => {
    cy.intercept('POST', '/cart/add', {
      statusCode: 200,
      body: JSON.stringify({ statusCode: 'noStock', statusMessage: 'Sem estoque disponível' }),
      headers: { 'content-type': 'application/json' },
    }).as('addNoStock');

    cy.visit(`/p/${PRODUCT_CODE}`);
    cy.get('[data-cy="add-to-cart-btn"]').click();
    cy.wait('@addNoStock');
    cy.get('.globalMessages .alert, [data-cy="cart-error"]').should('contain', 'estoque');
  });
});
