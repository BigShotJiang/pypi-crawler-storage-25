---
name: accelerator-jsp-cypress
description: Generates Cypress E2E specs for SAP Commerce Accelerator JSP/AJAX storefronts — CSRF handling, cy.session, jQuery AJAX intercepts
---

# accelerator-jsp-cypress

Gera Cypress specs para fluxos Accelerator JSP em ambiente D1. Foco em B2B checkout, CSRF, JSESSIONID e AJAX jQuery.

## Fluxo de geração (9 passos)

### 1. Verificar ambiente
Execute `scripts/check-environment.py`. Se falhar, mostre a saída e pare.

### 2. Identificar o fluxo e exemplo correspondente

| Pedido do usuário | Example a carregar |
|---|---|
| checkout B2B, endereço, entrega | `examples/b2b-checkout-jsp.cy.ts` |
| login, autenticação, sessão | `examples/login-csrf.cy.ts` |
| mini-cart, adicionar produto, AJAX | `examples/minicart-ajax.cy.ts` |
| busca, pesquisa, formulário | `examples/search-form-jsp.cy.ts` |

### 3. Carregar references sob demanda

| Situação | Carregar |
|---|---|
| Seletor de elemento JSP | `references/jsp-selectors.md` |
| Formulário POST com CSRF | `references/csrf-token-handling.md` |
| Manutenção de sessão entre testes | `references/session-management.md` |
| Chamada AJAX/fetch/jQuery | `references/ajax-intercept-patterns.md` |

### 4. Verificar pré-condições D1

Antes de gerar, pergunte:
- Qual é a URL base de D1?
- O storefront é Accelerator B2B, B2C ou customizado?
- Há `data-cy` nos templates JSP, ou usar `name="campo"` como fallback?
- O usuário de teste e produtos de teste existem no D1?

### 5. Apresentar plano (OBRIGATÓRIO — não gere sem confirmação)

Use `ask_followup_question` com:
- Fluxo a ser testado + cenários de erro
- Intercepts AJAX planejados
- Estratégia de CSRF: formulário UI (automático) ou `cy.request` (manual)
- Estratégia de sessão: `cy.session()` com `cacheAcrossSpecs` ou limpar entre testes
- Arquivo de saída: `cypress/e2e/<fluxo>.cy.ts`

### 6. Gerar spec

Após confirmação, use `write_to_file` com:
- `loginAndSaveSession()` helper no topo (se fluxo requer autenticação)
- `beforeEach` com `cy.intercept` para AJAX críticos + `loginAndSaveSession()`
- Verificação de `CSRFToken` em forms POST
- `cy.wait('@alias')` após cada ação AJAX
- Assertivas no response body ou HTML parcial retornado

### 7. Verificar configuração Cypress

Confirme existência de `cypress.config.ts`. Se não existir, gere:

```typescript
import { defineConfig } from 'cypress';

export default defineConfig({
  e2e: {
    baseUrl: process.env.CYPRESS_BASE_URL || 'https://d1.myprojeto.com',
    specPattern: 'cypress/e2e/**/*.cy.ts',
    supportFile: 'cypress/support/e2e.ts',
    video: false,
    screenshotOnRunFailure: true,
    experimentalSessionAndOrigin: true, // necessário para cy.session()
  },
});
```

### 8. Executar spec

```bash
scripts/run-cypress.sh <path/to/spec.cy.ts> <base-url-D1>
```

### 9. Analisar resultado

- `"status": "PASS"` → reporte ao arquiteto com número de cenários
- Falha por seletor: inspecione screenshot + `references/jsp-selectors.md`
- Falha por CSRF 403: verifique `references/csrf-token-handling.md`
- Falha por sessão expirada: verifique `references/session-management.md`

---

## Guardrails não-negociáveis

1. **Cypress testa fluxos funcionais e regras de negócio** — não comportamento de código Java
2. **Nunca hardcode credenciais** — use `Cypress.env()` com `cypress.env.json` (gitignored)
3. **Nunca use IDs dinâmicos `j_id_*`** — use `name=`, `data-cy=`, ou classe CSS estável
4. **Sempre `cy.session()` para autenticação** — nunca logar no `beforeEach` sem cache
5. **`cy.wait('@alias')`** após ação AJAX — nunca `cy.wait(2000)`

---

## Compatibilidade

Accelerator (B2B/B2C), SAP Commerce 2105–2211+, Cypress 12+, TypeScript 4.9+
