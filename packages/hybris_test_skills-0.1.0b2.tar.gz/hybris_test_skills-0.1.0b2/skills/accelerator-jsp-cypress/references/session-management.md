---
name: session-management
description: cy.session() patterns for JSESSIONID preservation in SAP Commerce Accelerator JSP
skill: accelerator-jsp-cypress
---

# Session Management — Accelerator JSP

## Por que cy.session() é obrigatório

Accelerator usa JSESSIONID cookie para autenticação. Sem `cy.session()`:
- Login é refeito a cada `it` block (lento, 3-5s por teste)
- Cookie expirado em meio à suíte quebra testes dependentes

## Padrão básico

```typescript
function loginAndSaveSession(username: string, password: string): void {
  cy.session(
    ['accelerator-login', username],
    () => {
      cy.visit('/login');
      cy.get('input[name="j_username"]').type(username);
      cy.get('input[name="j_password"]').type(password);
      cy.get('[data-cy="login-submit"]').click();
      cy.url().should('not.include', '/login');
    },
    {
      validate() {
        // Verifica que o cookie de sessão existe e a URL não é login
        cy.getCookie('JSESSIONID').should('exist');
        cy.visit('/my-account');
        cy.url().should('include', '/my-account');
      },
      cacheAcrossSpecs: true, // Reutiliza entre arquivos .cy.ts na mesma run
    }
  );
}
```

## Uso no spec

```typescript
describe('B2B Checkout', () => {
  beforeEach(() => {
    loginAndSaveSession(
      Cypress.env('TEST_USER'),
      Cypress.env('TEST_PASSWORD')
    );
  });

  it('should access checkout as authenticated user', () => {
    cy.visit('/checkout/multi/delivery-address/add');
    cy.url().should('include', '/delivery-address');
  });
});
```

## Limpando sessão entre testes que precisam de estado limpo

```typescript
afterEach(() => {
  cy.clearCookie('JSESSIONID');
  cy.clearLocalStorage();
});
```

## Múltiplos perfis de usuário

```typescript
// Sessão separada por perfil — Cypress gerencia caches distintos
loginAndSaveSession('admin@ntt.com', 'AdminPass@123');
loginAndSaveSession('b2b-buyer@cliente.com', 'BuyerPass@123');
```
