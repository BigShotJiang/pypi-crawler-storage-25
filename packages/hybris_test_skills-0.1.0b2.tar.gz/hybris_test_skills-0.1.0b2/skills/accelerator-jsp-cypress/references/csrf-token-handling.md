---
name: csrf-token-handling
description: Handling CSRFToken in SAP Commerce Accelerator JSP forms — extraction, assertion, and POST patterns
skill: accelerator-jsp-cypress
---

# CSRF Token Handling — Accelerator JSP

## Como o Accelerator usa CSRF

Todo formulário POST no Accelerator inclui um campo hidden `CSRFToken`:

```html
<form method="post" action="/login">
  <input type="hidden" name="CSRFToken" value="abc123xyz..." />
  <input type="text" name="j_username" />
  ...
</form>
```

Cypress respeita CSRF automaticamente quando submete formulários via `.click()` no botão
— o token já está no DOM quando o clique acontece. **Não extraia manualmente para submissões via UI.**

## Verificar que o token existe antes de submeter

```typescript
it('should have CSRF token in login form', () => {
  cy.visit('/login');
  cy.get('input[name="CSRFToken"]').should('exist').and('not.have.value', '');
});
```

## Quando usar cy.request com CSRF (teste de API direta)

Para testes via `cy.request()` que simulam POST sem UI, extraia o token da página:

```typescript
function getCSRFToken(): Cypress.Chainable<string> {
  return cy.get('input[name="CSRFToken"]').invoke('val') as Cypress.Chainable<string>;
}

it('should submit form with CSRF via cy.request', () => {
  cy.visit('/minha-pagina-com-form');
  getCSRFToken().then((token) => {
    cy.request({
      method: 'POST',
      url: '/minha-pagina/submit',
      form: true,
      body: {
        CSRFToken: token,
        campo1: 'valor',
      },
    }).its('status').should('eq', 200);
  });
});
```

## Interceptar e validar que CSRF é enviado

```typescript
cy.intercept('POST', '/login', (req) => {
  expect(req.body).to.include('CSRFToken=');
}).as('loginPost');

cy.get('input[name="j_username"]').type('usuario');
cy.get('input[name="j_password"]').type('senha');
cy.get('[data-cy="login-submit"]').click();
cy.wait('@loginPost');
```

## Token inválido — cenário de erro

```typescript
it('should reject request with invalid CSRF token', () => {
  cy.request({
    method: 'POST',
    url: '/checkout/multi/delivery-address/add',
    form: true,
    failOnStatusCode: false,
    body: { CSRFToken: 'token-invalido', addressId: '123' },
  }).its('status').should('eq', 403);
});
```
