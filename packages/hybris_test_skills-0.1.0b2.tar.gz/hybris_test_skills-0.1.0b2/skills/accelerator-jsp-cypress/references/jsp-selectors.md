---
name: jsp-selectors
description: Element selector strategy for SAP Commerce Accelerator JSP — dynamic IDs, data-cy fallback, stable patterns
skill: accelerator-jsp-cypress
---

# JSP Selectors — Accelerator

## Problema: IDs dinâmicos gerados pelo JSF/JSTL

Accelerator gera IDs dinâmicos baseados em índice de componente. Estes IDs mudam com
mudanças na página e quebram testes:

```html
<!-- Frágil — ID muda se o componente mudar de posição -->
<input id="j_id_1:j_id_3:username" name="j_username" type="text" />
```

## Hierarquia de seletores estáveis

1. `[data-cy="nome-semantico"]` — mais estável, adicionado pelo time no template JSP
2. `name="campo"` — atributos `name` são estáveis em formulários JSP
3. `input[type="text"][autocomplete="username"]` — combinar tipo + atributo semântico
4. `.classe-css-da-convencao-ntt` — classes nomeadas por convenção do projeto
5. ~~`#j_id_*`~~ — **nunca use** IDs dinâmicos JSF

## Adicionando data-cy em templates JSP

```jsp
<%-- checkout/multi/checkoutLogin.jsp --%>
<input type="text" name="j_username" data-cy="login-username" />
<input type="password" name="j_password" data-cy="login-password" />
<button type="submit" data-cy="login-submit">Entrar</button>
```

```typescript
cy.get('[data-cy="login-username"]').type('usuario@ntt.com');
cy.get('[data-cy="login-submit"]').click();
```

## Seletores por atributo `name` (fallback seguro)

```typescript
// Formulários JSP têm `name` estável mesmo sem data-cy
cy.get('input[name="j_username"]').type('usuario');
cy.get('input[name="j_password"]').type('senha');
cy.get('input[name="CSRFToken"]').should('exist');
```

## Navegação por URL (preferível a clicar em links)

```typescript
// Mais estável que clicar em elementos de menu
cy.visit('/login');
cy.visit('/checkout/multi/delivery-address/add');
cy.visit('/store-finder');
```
