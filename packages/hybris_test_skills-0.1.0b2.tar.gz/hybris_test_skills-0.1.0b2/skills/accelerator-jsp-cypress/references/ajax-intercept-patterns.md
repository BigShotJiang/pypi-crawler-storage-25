---
name: ajax-intercept-patterns
description: Cypress cy.intercept patterns for jQuery.ajax, fetch, and axios calls in SAP Commerce Accelerator JSP
skill: accelerator-jsp-cypress
---

# AJAX Intercept Patterns — Accelerator JSP

## Tipos de chamadas AJAX no Accelerator

O Accelerator usa principalmente jQuery `$.ajax()` para chamadas assíncronas:
- Mini-cart refresh
- Validação de endereço
- Cálculo de frete em tempo real
- Busca AJAX (autocomplete)

## Interceptando jQuery.ajax

`cy.intercept` intercepta **todas** as chamadas HTTP, incluindo jQuery.ajax — nenhuma config especial necessária:

```typescript
// Mini-cart update (POST para adicionar produto)
cy.intercept('POST', '/cart/add').as('addToCart');

// Mini-cart refresh (GET)
cy.intercept('GET', '/cart/miniCart').as('miniCartRefresh');

// Cálculo de frete
cy.intercept('GET', '/checkout/multi/delivery-method/getShippingCost*').as('shippingCost');

// Validação de endereço via CEP
cy.intercept('GET', '/viacep/**').as('cepLookup');
```

## Exemplo de flow: add to cart AJAX

```typescript
it('should add product via AJAX and update mini-cart', () => {
  cy.intercept('POST', '/cart/add').as('addToCart');
  cy.intercept('GET', '/cart/miniCart').as('miniCartRefresh');

  cy.visit('/p/CYPRESS-PROD-001');
  cy.get('[data-cy="add-to-cart-btn"]').click();

  cy.wait('@addToCart').then(({ response }) => {
    expect(response!.statusCode).to.eq(200);
    expect(response!.body.numberOfItems).to.be.greaterThan(0);
  });

  cy.wait('@miniCartRefresh');
  cy.get('.miniCartCount').should('contain', '1');
});
```

## Assertindo HTML parcial retornado via AJAX

O Accelerator frequentemente retorna HTML fragment em respostas AJAX:

```typescript
cy.intercept('GET', '/cart/miniCart').as('miniCart');
cy.wait('@miniCart').then(({ response }) => {
  // Response pode ser HTML, não JSON
  expect(response!.headers['content-type']).to.include('text/html');
  expect(response!.body).to.include('data-cy="mini-cart-total"');
});
```

## Interceptando fetch e axios (extensões customizadas)

```typescript
// fetch (JavaScript moderno)
cy.intercept('GET', '/api/custom/products*').as('customFetch');

// axios (libs de frontend custom)
cy.intercept('POST', '/api/v1/order-status').as('orderStatus');
```

## Stubbing de resposta AJAX para cenário de erro

```typescript
cy.intercept('POST', '/cart/add', {
  statusCode: 500,
  body: '<div class="error">Erro ao adicionar ao carrinho.</div>',
}).as('addToCartError');

cy.get('[data-cy="add-to-cart-btn"]').click();
cy.wait('@addToCartError');
cy.get('.globalMessages .alert').should('contain', 'Erro');
```
