---
name: hybris-junit
description: Gera testes JUnit (@UnitTest/@IntegrationTest) para código Java SAP Commerce. Requer hybris-base carregado.
---

# hybris-junit — Gerador de testes JUnit

> **Pré-requisito:** `skills/hybris-base/SKILL.md` deve estar carregado antes desta skill.
> **Compatibilidade:** SAP Commerce 2211+, Java 17+, JUnit 4 + Mockito 4

## O que esta skill faz

Gera testes JUnit para classes Java customizadas SAP Commerce seguindo os padrões NTT Data Brasil:
- Detecta tipo de classe automaticamente via `parse-java-class.py`
- Seleciona par de exemplos correto (few-shot)
- Detecta atributos `localized` via `parse-items-xml.py` quando necessário
- Apresenta plano antes de gerar (obrigatório)
- Valida com `run-junit.sh` após geração

## Fluxo obrigatório (nunca pular etapas)

```
1. Executar: python3 skills/hybris-junit/scripts/parse_java_class.py <ClasseAlvo.java>
2. Ler output JSON → determinar type (populator/converter/dao/facade/strategy/interceptor)
3. Se type == "dao" → @IntegrationTest, caso contrário → @UnitTest
4. Se algum public_method tem parâmetro/retorno de tipo Hybris → verificar localized:
   python3 skills/hybris-junit/scripts/parse_items_xml.py <extension>-items.xml <ItemType>
5. Carregar par de exemplos correspondente ao type (examples/<type>-source.java + examples/<type>-test.java)
6. Carregar references conforme necessidade (tabela abaixo)
7. Apresentar plano via ask_followup_question — aguardar confirmação
8. Após confirmação → write_to_file (gerar arquivo de teste)
9. Executar: bash skills/hybris-junit/scripts/run-junit.sh <fully.qualified.TestClassName>
10. Se falhar → invocar skills/hybris-junit/scripts/test-healer.py (máx 3 iterações)
```

## Tabela de referências — quando carregar

| Reference | Quando carregar |
|---|---|
| `references/scope-guardrails.md` | SEMPRE — carregar antes de gerar qualquer teste |
| `references/mock-patterns.md` | Qualquer @UnitTest com Mockito |
| `references/localized-attributes.md` | Quando parse-items-xml.py retornar `localized: true` em algum atributo |
| `references/flexsearch-captor.md` | Quando type == "dao" |
| `references/impex-fixtures.md` | Quando type == "dao" (@IntegrationTest) |

## Tabela de exemplos — par a carregar por tipo

| type (parse-java-class.py) | Source | Test | Anotação |
|---|---|---|---|
| populator | examples/populator-source.java | examples/populator-test.java | @UnitTest |
| converter | examples/converter-source.java | examples/converter-test.java | @UnitTest |
| dao | examples/dao-flexsearch-source.java | examples/dao-flexsearch-test.java | @IntegrationTest |
| facade | examples/facade-source.java | examples/facade-test.java | @UnitTest |
| strategy | examples/strategy-source.java | examples/strategy-test.java | @UnitTest |
| interceptor | examples/interceptor-source.java | examples/interceptor-test.java | @UnitTest |
| other | (nenhum par — pedir ao dev para classificar manualmente) | | |

## Plano obrigatório via ask_followup_question

Antes de gerar, apresentar ao dev:
```
Vou gerar DefaultXxxTest.java com os seguintes cenários:

**Tipo detectado:** [populator/@UnitTest ou dao/@IntegrationTest]
**Dependências mockadas:** [lista]
**Cenários:**
1. should[comportamento]When[condição] — verifica [assert]
2. shouldReturnNullWhenSourceIsNull — verifica null safety
3. [outros cenários específicos do método]

**Atributos localized detectados:** [sim/não — nome do atributo]
**Arquivo de teste:** src/test/java/[pacote]/DefaultXxxTest.java

Confirma?
```

## Guardrails não-negociáveis

1. **Não gere Cypress neste contexto.** Se o usuário pedir E2E, redirecione para `/cypress`.
2. **Não edite código de produção** — apenas gere o arquivo de teste.
3. **Não gere teste sem confirmação** do plano (ask_followup_question obrigatório).
4. **Se classe > 500 linhas** (parse-java-class.py retorna error), informe o dev e sugira refactor — não tente gerar.
5. **JUnit testa código, nunca regra de negócio** — ver scope-guardrails.md.

## Heurísticas de tipo para classes não-detectadas automaticamente

- Implements `Populator<S, T>` → populator
- Implements `Converter<S, T>` ou extends `AbstractPopulatingConverter` → converter
- Name contém "DAO" ou "Dao" ou implements `*DAO` → dao
- Name contém "Facade" ou implements `*Facade` → facade
- Implements `*Strategy` → strategy
- Implements `ValidateInterceptor`, `PrepareInterceptor`, `RemoveInterceptor` → interceptor
- Extends `AbstractJobPerformable` → jobperformable (tratar como strategy)
