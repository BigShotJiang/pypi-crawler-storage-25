---
name: scope-guardrails
description: Guardrail obrigatório — JUnit testa APENAS comportamento técnico de código Java. Nunca regra de negócio.
---

# Guardrails de escopo JUnit

## A regra fundamental

JUnit testa **comportamento técnico** de métodos Java:
- Populators: mapeamento campo-a-campo (source → target)
- Converters: conversão de tipo e delegação
- DAOs: queries FlexibleSearch corretas (parâmetros nomeados, paginação)
- Facades: delegação correta para service + converter
- Strategies: branches de algoritmo
- Interceptors: validações de campo (format, nullability)

JUnit **NÃO** testa regra de negócio. Regras de negócio são validadas pelo Arquiteto com Cypress E2E em D1.

## Exemplos: O que é e o que não é JUnit

| ✅ JUnit (código) | ❌ Não JUnit (negócio) |
|---|---|
| `setCode(source.getCode())` é chamado no populate() | Produto com código nulo não pode ser vendido |
| FlexibleSearch usa `?code` (não concatenação de string) | Busca retorna produto correto por regra de catálogo |
| `InterceptorException` lançada quando código tem espaço | Fluxo de checkout funciona após validação |
| Converter retorna `null` quando source é `null` | Desconto aplicado corretamente para usuário B2B |

## Red flags — se você ver isso, PARE

1. Teste acessa banco de dados real sem `@IntegrationTest`
2. Nome do teste descreve comportamento de usuário ("usuário consegue comprar")
3. Assert verifica valor de negócio hard-coded ("preço deve ser R$ 99,90")
4. Múltiplas classes de domínio instanciadas em conjunto sem `@IntegrationTest`
5. O healer sugeriu remover um `assertEquals` — ABORT imediatamente

## Quando usar @UnitTest vs @IntegrationTest

Use `@UnitTest` (Mockito, sem Spring):
- Populator, Converter, Strategy, Interceptor, Action, JobPerformable
- Qualquer classe sem dependência de `Registry`, `Config`, `JaloSession`

Use `@IntegrationTest` (extends ServicelayerTest, banco real):
- DAO com FlexibleSearch real
- Qualquer classe que depende de `Registry.getApplicationContext()`
- Quando precisa de dados reais carregados via ImpEx fixture
