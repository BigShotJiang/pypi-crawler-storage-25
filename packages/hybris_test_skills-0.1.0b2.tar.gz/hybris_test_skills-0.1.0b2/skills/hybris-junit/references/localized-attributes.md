---
name: localized-attributes
description: Como lidar com atributos localized em testes JUnit — evitar IllegalStateException No LocaleProvider
---

# Localized Attributes em Testes

## O problema

Atributos `localized:java.lang.String` no items.xml geram getters/setters com dois overloads:
```java
model.getName()           // lança IllegalStateException se não houver LocaleProvider na sessão
model.getName(Locale)     // seguro, sempre funciona
```

Chamar o overload sem Locale em qualquer contexto fora de uma sessão Hybris ativa (ex: @UnitTest) lança:
```
IllegalStateException: No LocaleProvider set in current session
```

## Fix 1 — Usar overload com Locale (preferido em @UnitTest)

```java
// Em produção (evitar em código novo — use fix 2)
productModel.setName("Test Product");   // ❌ lança em @UnitTest

// Correto
productModel.setName("Test Product", Locale.ENGLISH);  // ✅ sempre funciona
```

No teste, mocke o getter da mesma forma:
```java
given(source.getName(Locale.ENGLISH)).willReturn("Test Product");
verify(target).setName("Test Product");
```

## Fix 2 — Mockar CommonI18NService (quando o código de produção usa sem Locale)

Se o código de produção chama `source.getName()` e você não pode mudar o código:
```java
@Mock
private CommonI18NService commonI18NService;

@Before
public void setUp() {
    MockitoAnnotations.openMocks(this);
    given(commonI18NService.getCurrentLocale()).willReturn(Locale.ENGLISH);
    // Injete manualmente se @InjectMocks não resolve
    classUnderTest.setCommonI18NService(commonI18NService);
}
```

## Fix 3 — @IntegrationTest com sessão real

Para código que depende fortemente de sessão, use @IntegrationTest:
```java
@IntegrationTest
public class DefaultProductDAOIntegrationTest extends ServicelayerTest {
    // ServicelayerTest inicializa sessão Hybris — atributos localized funcionam normalmente
}
```

## Como detectar se um atributo é localized

Via `parse-items-xml.py`:
```bash
python3 scripts/parse-items-xml.py myextension-items.xml Product
# output: {"attributes": [{"name": "name", "localized": true, ...}]}
```

Ou na classe gerada: se o setter tem overload `setX(value, Locale)`, o atributo é localized.
