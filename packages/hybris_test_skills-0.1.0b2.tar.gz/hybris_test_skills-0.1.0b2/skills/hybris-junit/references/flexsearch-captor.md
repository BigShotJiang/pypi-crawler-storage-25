---
name: flexsearch-captor
description: Como capturar e verificar FlexibleSearchQuery em testes JUnit de DAO usando ArgumentCaptor
---

# FlexibleSearch Captor — Testando DAOs

## Por que usar ArgumentCaptor

Em @UnitTest de DAO, você quer verificar que o DAO constrói a query correta
(parâmetros nomeados corretos, string de query correta, paginação correta).
`ArgumentCaptor<FlexibleSearchQuery>` captura o objeto passado para `flexibleSearchService.search()`.

## Setup completo

```java
@UnitTest
@RunWith(MockitoJUnitRunner.class)
public class DefaultProductDAOTest {

    @InjectMocks
    private DefaultProductDAO dao;

    @Mock
    private FlexibleSearchService flexibleSearchService;

    @Captor
    private ArgumentCaptor<FlexibleSearchQuery> queryCaptor;

    @Mock
    private SearchResult<ProductModel> searchResult;

    @Before
    public void setUp() {
        given(searchResult.getResult()).willReturn(Collections.emptyList());
        given(flexibleSearchService.search(any(FlexibleSearchQuery.class))).willReturn(searchResult);
    }
}
```

## Verificar string da query e parâmetros

```java
@Test
public void shouldUseNamedParameterForCode() {
    // when
    dao.findByCode("TEST_CODE");

    // then — captura o argumento passado para .search()
    verify(flexibleSearchService).search(queryCaptor.capture());
    final FlexibleSearchQuery capturedQuery = queryCaptor.getValue();

    assertThat(capturedQuery.getQuery(), containsString("?code"));
    assertThat(capturedQuery.getQuery(), not(containsString("'TEST_CODE'")));  // sem concatenação
    assertEquals("TEST_CODE", capturedQuery.getQueryParameters().get("code"));
}
```

## Verificar paginação

```java
@Test
public void shouldApplyPaginationParameters() {
    // when
    dao.searchByText("camera", 10, 20);

    // then
    verify(flexibleSearchService).search(queryCaptor.capture());
    final FlexibleSearchQuery capturedQuery = queryCaptor.getValue();

    assertEquals(10, capturedQuery.getCount());
    assertEquals(20, capturedQuery.getStart());
}
```

## Verificar múltiplos parâmetros

```java
verify(flexibleSearchService).search(queryCaptor.capture());
final Map<String, Object> params = queryCaptor.getValue().getQueryParameters();
assertEquals("TEST_CODE", params.get("code"));
assertEquals("electronicsProductCatalog", params.get("catalogId"));
assertEquals("Online", params.get("version"));
```

## Imports necessários

```java
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;
```
