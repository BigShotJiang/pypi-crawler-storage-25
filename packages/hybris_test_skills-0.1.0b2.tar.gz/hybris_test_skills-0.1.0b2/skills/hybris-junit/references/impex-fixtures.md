---
name: impex-fixtures
description: Como usar importCsv() para carregar fixtures ImpEx em @IntegrationTest SAP Commerce
---

# ImpEx Fixtures para @IntegrationTest

## Padrão importCsv()

```java
@IntegrationTest
public class DefaultProductDAOIntegrationTest extends ServicelayerTest {

    @Before
    public void setUp() throws Exception {
        importCsv("/myextension/test/sampleProducts.impex", "utf-8");
    }
}
```

## Localização do arquivo ImpEx

O arquivo deve estar em `src/test/resources/<extensionname>/test/`:
```
myextension/
  src/
    test/
      resources/
        myextension/
          test/
            sampleProducts.impex    ← importCsv("/myextension/test/sampleProducts.impex", "utf-8")
```

## Estrutura mínima do fixture para DAO test

```impex
# Pré-requisito: CatalogVersion
INSERT_UPDATE CatalogVersion;catalog(id)[unique=true];version[unique=true];active[default=false]
;testCatalog;Online;true

# Dados de teste — sempre prefixar com TEST_ para identificar como dado de teste
INSERT_UPDATE Product;code[unique=true];catalogVersion(catalog(id),version)[unique=true];name[lang=en];approvalStatus(code)
;TEST_PRODUCT_001;testCatalog:Online;Test Product 001;approved
;TEST_PRODUCT_002;testCatalog:Online;Test Product 002;approved
;TEST_PRODUCT_UNAPPROVED;testCatalog:Online;Unapproved Product;unapproved
```

## Boas práticas

1. Prefixo `TEST_` em todos os codes de dados de teste
2. Sempre criar o CatalogVersion antes dos Products
3. Um arquivo ImpEx por suite de teste (não compartilhar entre suites diferentes)
4. Limpar dados no `@After` não é necessário — ServicelayerTest faz rollback da transação automaticamente

## Múltiplos arquivos

```java
@Before
public void setUp() throws Exception {
    importCsv("/myextension/test/testCatalog.impex", "utf-8");
    importCsv("/myextension/test/testProducts.impex", "utf-8");
    importCsv("/myextension/test/testPrices.impex", "utf-8");
}
```
