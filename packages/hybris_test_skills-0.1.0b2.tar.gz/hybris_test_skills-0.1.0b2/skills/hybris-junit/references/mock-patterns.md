---
name: mock-patterns
description: Padrões de mock Mockito para SAP Commerce — ModelService, FlexibleSearchService, SessionService, CommonI18NService
---

# Mock Patterns — SAP Commerce

## Setup padrão @UnitTest

```java
@UnitTest
@RunWith(MockitoJUnitRunner.class)
public class DefaultXxxTest {

    @InjectMocks
    private DefaultXxx classUnderTest;

    @Mock
    private ModelService modelService;

    @Mock
    private FlexibleSearchService flexibleSearchService;
}
```

## ModelService — mocks essenciais

```java
// create() — retorna instância mockada
given(modelService.create(ProductModel.class)).willReturn(productModel);

// save() — verificar que foi chamado com o model correto
verify(modelService).save(productModel);

// remove() — verificar que foi chamado
verify(modelService).remove(productModel);

// refresh() — não costuma precisar de mock, mas pode verificar
verify(modelService, never()).refresh(any());
```

## FlexibleSearchService — mock com resultado

```java
// Mock de SearchResult
final SearchResult<ProductModel> searchResult = mock(SearchResult.class);
given(searchResult.getResult()).willReturn(List.of(productModel));
given(flexibleSearchService.search(any(FlexibleSearchQuery.class))).willReturn(searchResult);

// Mock de resultado vazio
given(searchResult.getResult()).willReturn(Collections.emptyList());
```

## CommonI18NService — locale para atributos localizados

```java
@Mock
private CommonI18NService commonI18NService;

@Mock
private SessionService sessionService;

// Setup no @Before
given(commonI18NService.getCurrentLocale()).willReturn(Locale.ENGLISH);
```

## BDDMockito — imports obrigatórios

```java
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.any;
import static org.mockito.ArgumentMatchers.any;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;
```

## Padrão Given/When/Then

```java
@Test
public void shouldMapCodeWhenPopulateIsCalled() {
    // given
    given(source.getCode()).willReturn("TEST_CODE");

    // when
    classUnderTest.populate(source, target);

    // then
    verify(target).setCode("TEST_CODE");
}
```
