#!/usr/bin/env python3
"""
parse_items_xml.py — extrai definição de itemtype do items.xml do SAP Commerce.
Input:  path para *-items.xml, nome do itemtype
Output: JSON com itemtype, extends, attributes (com flag localized), relations
"""
import json
import sys
from pathlib import Path

try:
    from lxml import etree
except ImportError:
    print(json.dumps({"error": "lxml not installed. Run: pip install lxml>=5.0.0"}))
    sys.exit(1)


def parse_items_xml(xml_path: str, itemtype_name: str) -> dict:
    try:
        content = Path(xml_path).read_bytes().lstrip()
        tree = etree.fromstring(content)
    except etree.XMLSyntaxError as e:
        return {"error": f"XML syntax error: {e}", "itemtype": itemtype_name}
    root = tree
    ns = root.nsmap.get(None, "")
    ns_prefix = f"{{{ns}}}" if ns else ""

    # Find itemtype by code attribute
    itemtype_el = root.find(f".//{ns_prefix}itemtype[@code='{itemtype_name}']")
    if itemtype_el is None:
        # Try without namespace
        itemtype_el = root.find(f".//itemtype[@code='{itemtype_name}']")

    if itemtype_el is None:
        return {
            "error": f"itemtype '{itemtype_name}' not found in {xml_path}",
            "itemtype": itemtype_name,
        }

    extends = itemtype_el.get("extends")

    attributes = []
    for attr_el in itemtype_el.findall(f".//{ns_prefix}attribute") or itemtype_el.findall(".//attribute"):
        qualifier = attr_el.get("qualifier", "")
        type_el = attr_el.find(f"{ns_prefix}type") or attr_el.find("type")
        attr_type = type_el.text.strip() if type_el is not None and type_el.text else attr_el.get("type", "")

        localized = attr_type.startswith("localized:") or attr_el.get("localized", "false").lower() == "true"

        mods = attr_el.find(f"{ns_prefix}modifiers") or attr_el.find("modifiers")
        optional = mods.get("optional", "true").lower() == "true" if mods is not None else True
        unique = mods.get("unique", "false").lower() == "true" if mods is not None else False

        dv_el = attr_el.find(f"{ns_prefix}defaultvalue") or attr_el.find("defaultvalue")
        default_value = dv_el.text.strip() if dv_el is not None and dv_el.text else None

        attributes.append({
            "name": qualifier,
            "type": attr_type,
            "localized": localized,
            "optional": optional,
            "unique": unique,
            "default_value": default_value,
        })

    relations = []
    for rel_el in root.findall(f".//{ns_prefix}relation") or root.findall(".//relation"):
        src_el = rel_el.find(f"{ns_prefix}sourceElement") or rel_el.find("sourceElement")
        tgt_el = rel_el.find(f"{ns_prefix}targetElement") or rel_el.find("targetElement")
        if src_el is None or tgt_el is None:
            continue
        src_type = src_el.get("type", "")
        tgt_type = tgt_el.get("type", "")
        if src_type == itemtype_name:
            qualifier = tgt_el.get("qualifier", "")
            cardinality = "one" if tgt_el.get("cardinality", "many").lower() == "one" else "many"
            relations.append({"qualifier": qualifier, "target_type": tgt_type, "cardinality": cardinality})
        elif tgt_type == itemtype_name:
            qualifier = src_el.get("qualifier", "")
            cardinality = "one" if src_el.get("cardinality", "many").lower() == "one" else "many"
            relations.append({"qualifier": qualifier, "target_type": src_type, "cardinality": cardinality})

    return {
        "itemtype": itemtype_name,
        "extends": extends,
        "attributes": attributes,
        "relations": relations,
        "error": None,
    }


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(json.dumps({"error": "Usage: parse_items_xml.py <path-to-items.xml> <ItemTypeName>"}))
        sys.exit(1)
    result = parse_items_xml(sys.argv[1], sys.argv[2])
    print(json.dumps(result, indent=2))
    sys.exit(1 if result.get("error") else 0)
