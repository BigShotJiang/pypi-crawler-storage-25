#!/usr/bin/env python3
"""
parse_java_class.py — analisa classe Java e retorna JSON estruturado para geração de testes.
Input:  path para arquivo .java
Output: JSON com className, package, type, extends, implements, dependencies, public_methods, flexsearch_queries
"""
import json
import re
import sys
from pathlib import Path

try:
    import javalang
except ImportError:
    print(json.dumps({"error": "javalang not installed. Run: pip install javalang>=0.13.0"}))
    sys.exit(1)

MAX_LINES = 500

_TYPE_PATTERNS = [
    ("populator",     r'\bimplements\b[^{]*\bPopulator\b'),
    ("converter",     r'\bimplements\b[^{]*\bConverter\b|\bextends\b[^{]*\bConverter\b|\bextends\b[^{]*AbstractPopulatingConverter'),
    ("dao",           r'\bimplements\b[^{]*\b(DAO|Dao|Repository)\b|class\s+\w*(DAO|Dao)\b'),
    ("facade",        r'\bimplements\b[^{]*\bFacade\b|class\s+\w*Facade\b'),
    ("strategy",      r'\bimplements\b[^{]*Strategy\b'),
    ("interceptor",   r'\bimplements\b[^{]*\b(ValidateInterceptor|PrepareInterceptor|RemoveInterceptor)\b'),
    ("action",        r'\bimplements\b[^{]*\bAction\b|\bextends\b[^{]*\bAction\b'),
    ("jobperformable",r'\bextends\b[^{]*\bAbstractJobPerformable\b|\bimplements\b[^{]*\bJobPerformable\b'),
    ("service",       r'\bimplements\b[^{]*\bService\b|class\s+\w*Service\b'),
]


def detect_type(source: str) -> str:
    # Look at only the class declaration line (up to first {)
    match = re.search(r'(public\s+(?:abstract\s+)?class[^{]+)', source)
    declaration = match.group(1) if match else source[:200]
    for type_name, pattern in _TYPE_PATTERNS:
        if re.search(pattern, declaration):
            return type_name
    return "other"


def extract_flexsearch_queries(source: str) -> list:
    return re.findall(r'"(SELECT\s*\{[^"]+)"', source)


def count_branches(source: str) -> int:
    return len(re.findall(r'\bif\s*\(|\bfor\s*\(|\bwhile\s*\(', source))


def _parse_package(tree) -> str:
    return tree.package.name if tree.package else ""


def _parse_dependencies(tree) -> list:
    deps = []
    for _, field in tree.filter(javalang.tree.FieldDeclaration):
        field_type = field.type.name if hasattr(field.type, 'name') else str(field.type)
        injection = "setter"
        for ann in (field.annotations or []):
            if hasattr(ann, 'name'):
                if ann.name == "Autowired":
                    injection = "autowired"
                elif ann.name == "Resource":
                    injection = "resource"
        for decl in field.declarators:
            deps.append({"name": decl.name, "type": field_type, "injection": injection})
    return deps


def _parse_public_methods(tree, source: str) -> list:
    methods = []
    for _, method in tree.filter(javalang.tree.MethodDeclaration):
        if "public" not in (method.modifiers or set()):
            continue
        params = []
        for p in (method.parameters or []):
            params.append({
                "name": p.name,
                "type": p.type.name if hasattr(p.type, 'name') else str(p.type)
            })
        throws = [t.name if hasattr(t, 'name') else str(t) for t in (method.throws or [])]
        # Count branches in the method body via source slice heuristic
        method_source = ""
        if method.position:
            start_line = method.position.line - 1
            lines = source.splitlines()
            method_source = "\n".join(lines[start_line:start_line + 50])
        methods.append({
            "name": method.name,
            "return_type": (method.return_type.name
                            if method.return_type and hasattr(method.return_type, 'name')
                            else "void"),
            "parameters": params,
            "branches": count_branches(method_source),
            "exceptions_thrown": throws,
        })
    return methods


def parse_class(path: str) -> dict:
    source = Path(path).read_text(encoding="utf-8")
    line_count = len(source.splitlines())

    if line_count > MAX_LINES:
        # Still parse to get class name
        name_match = re.search(r'\bclass\s+(\w+)', source)
        cls_name = name_match.group(1) if name_match else Path(path).stem
        return {"error": "class too complex, consider refactoring", "className": cls_name}

    try:
        tree = javalang.parse.parse(source)
    except javalang.parser.JavaSyntaxError as e:
        return {"error": f"Java syntax error: {e}", "className": Path(path).stem}

    cls_decl = next((t for _, t in tree.filter(javalang.tree.ClassDeclaration)), None)
    if not cls_decl:
        return {"error": "No class declaration found", "className": ""}

    implements = [i.name if hasattr(i, 'name') else str(i) for i in (cls_decl.implements or [])]
    extends = cls_decl.extends.name if cls_decl.extends else None

    return {
        "className": cls_decl.name,
        "package": _parse_package(tree),
        "type": detect_type(source),
        "extends": extends,
        "implements": implements,
        "dependencies": _parse_dependencies(tree),
        "public_methods": _parse_public_methods(tree, source),
        "flexsearch_queries": extract_flexsearch_queries(source),
        "error": None,
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Usage: parse_java_class.py <path-to-java-file>"}))
        sys.exit(1)
    result = parse_class(sys.argv[1])
    print(json.dumps(result, indent=2))
    sys.exit(1 if result.get("error") else 0)
