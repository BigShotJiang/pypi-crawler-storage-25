package com.ntt.myextension.strategies.impl;

import com.ntt.myextension.strategies.DiscountCalculationStrategy;

import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.user.UserGroupModel;
import de.hybris.platform.servicelayer.util.ServicesUtil;

import java.math.BigDecimal;
import java.util.Collection;


/**
 * Calcula desconto com base no grupo do usuário e valor do carrinho.
 * Demonstra múltiplos branches para cobertura em @UnitTest.
 */
public class DefaultDiscountCalculationStrategy implements DiscountCalculationStrategy {

	private static final BigDecimal VIP_THRESHOLD = BigDecimal.valueOf(500.00);
	private static final BigDecimal VIP_DISCOUNT = BigDecimal.valueOf(0.15);
	private static final BigDecimal B2B_DISCOUNT = BigDecimal.valueOf(0.10);
	private static final BigDecimal STANDARD_DISCOUNT = BigDecimal.ZERO;

	@Override
	public BigDecimal calculateDiscount(final CartModel cart, final Collection<UserGroupModel> userGroups) {
		ServicesUtil.validateParameterNotNull(cart, "Cart must not be null");

		if (userGroups == null || userGroups.isEmpty()) {
			return STANDARD_DISCOUNT;
		}

		final boolean isVip = userGroups.stream().anyMatch(g -> "vipCustomerGroup".equals(g.getUid()));
		final boolean isB2B = userGroups.stream().anyMatch(g -> "b2bCustomerGroup".equals(g.getUid()));

		if (isVip && cart.getTotalPrice() != null
				&& BigDecimal.valueOf(cart.getTotalPrice()).compareTo(VIP_THRESHOLD) >= 0) {
			return VIP_DISCOUNT;
		}

		if (isB2B) {
			return B2B_DISCOUNT;
		}

		return STANDARD_DISCOUNT;
	}
}
