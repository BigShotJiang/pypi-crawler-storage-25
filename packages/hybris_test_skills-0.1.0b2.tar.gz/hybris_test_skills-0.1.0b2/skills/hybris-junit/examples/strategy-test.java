package com.ntt.myextension.strategies.impl;

import de.hybris.bootstrap.annotations.UnitTest;
import de.hybris.platform.core.model.order.CartModel;
import de.hybris.platform.core.model.user.UserGroupModel;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.BDDMockito.given;


@UnitTest
@RunWith(MockitoJUnitRunner.class)
public class DefaultDiscountCalculationStrategyTest {

	@InjectMocks
	private DefaultDiscountCalculationStrategy strategy;

	@Mock
	private CartModel cart;

	@Mock
	private UserGroupModel vipGroup;

	@Mock
	private UserGroupModel b2bGroup;

	@Test
	public void shouldReturnZeroDiscountWhenUserGroupsIsEmpty() {
		// when
		final BigDecimal result = strategy.calculateDiscount(cart, Collections.emptyList());

		// then
		assertEquals(BigDecimal.ZERO, result);
	}

	@Test
	public void shouldReturnZeroDiscountWhenUserGroupsIsNull() {
		// when
		final BigDecimal result = strategy.calculateDiscount(cart, null);

		// then
		assertEquals(BigDecimal.ZERO, result);
	}

	@Test
	public void shouldReturnVipDiscountWhenVipGroupAndCartAboveThreshold() {
		// given
		given(vipGroup.getUid()).willReturn("vipCustomerGroup");
		given(cart.getTotalPrice()).willReturn(Double.valueOf(600.00));

		// when
		final BigDecimal result = strategy.calculateDiscount(cart, List.of(vipGroup));

		// then
		assertEquals(0, BigDecimal.valueOf(0.15).compareTo(result));
	}

	@Test
	public void shouldReturnB2BDiscountWhenVipCartBelowThreshold() {
		// given
		given(vipGroup.getUid()).willReturn("vipCustomerGroup");
		given(b2bGroup.getUid()).willReturn("b2bCustomerGroup");
		given(cart.getTotalPrice()).willReturn(Double.valueOf(100.00));

		// when — cart below VIP_THRESHOLD, falls through to B2B check
		final BigDecimal result = strategy.calculateDiscount(cart, List.of(vipGroup, b2bGroup));

		// then
		assertEquals(0, BigDecimal.valueOf(0.10).compareTo(result));
	}

	@Test
	public void shouldReturnB2BDiscountWhenB2BGroup() {
		// given
		given(b2bGroup.getUid()).willReturn("b2bCustomerGroup");

		// when
		final BigDecimal result = strategy.calculateDiscount(cart, List.of(b2bGroup));

		// then
		assertEquals(0, BigDecimal.valueOf(0.10).compareTo(result));
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowIllegalArgumentExceptionWhenCartIsNull() {
		strategy.calculateDiscount(null, Collections.emptyList());
	}
}
