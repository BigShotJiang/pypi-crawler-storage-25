/*
 * DefaultProductPopulatorTest.java
 * Exemplo de referência: @UnitTest para Populator com atributo localized.
 * Padrões demonstrados: @Mock, @InjectMocks, BDDMockito, null safety, localized attribute.
 */
package com.ntt.myextension.populators;

import de.hybris.bootstrap.annotations.UnitTest;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import de.hybris.platform.servicelayer.media.MediaContainerService;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.Locale;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.never;
import static org.mockito.ArgumentMatchers.any;


@UnitTest
@RunWith(MockitoJUnitRunner.class)
public class DefaultProductPopulatorTest {

	@InjectMocks
	private DefaultProductPopulator populator;

	@Mock
	private CommonI18NService commonI18NService;

	@Mock
	private MediaContainerService mediaContainerService;

	@Mock
	private ProductModel source;

	private ProductData target;

	@Before
	public void setUp() {
		target = new ProductData();
		given(commonI18NService.getCurrentLocale()).willReturn(Locale.ENGLISH);
	}

	@Test
	public void shouldMapCodeWhenSourceHasCode() {
		// given
		given(source.getCode()).willReturn("TEST_PROD_001");
		given(source.getName(Locale.ENGLISH)).willReturn("Test Product");
		given(source.getThumbnails()).willReturn(Collections.emptySet());

		// when
		populator.populate(source, target);

		// then
		assertEquals("TEST_PROD_001", target.getCode());
	}

	@Test
	public void shouldMapLocalizedNameUsingCurrentLocale() {
		// given
		given(source.getCode()).willReturn("TEST_PROD_001");
		given(source.getName(Locale.ENGLISH)).willReturn("Test Product EN");
		given(source.getThumbnails()).willReturn(Collections.emptySet());

		// when
		populator.populate(source, target);

		// then
		assertEquals("Test Product EN", target.getName());
		verify(commonI18NService).getCurrentLocale();
		verify(source).getName(Locale.ENGLISH);
	}

	@Test
	public void shouldSkipImageWhenThumbnailsIsEmpty() {
		// given
		given(source.getCode()).willReturn("TEST_PROD_001");
		given(source.getName(Locale.ENGLISH)).willReturn("Test Product");
		given(source.getThumbnails()).willReturn(Collections.emptySet());

		// when
		populator.populate(source, target);

		// then
		assertNull(target.getMainImage());
		verify(mediaContainerService, never()).getMediaForFormat(any(), any());
	}

	@Test(expected = ConversionException.class)
	public void shouldThrowConversionExceptionWhenSourceIsNull() {
		// when
		populator.populate(null, target);
	}

	@Test(expected = ConversionException.class)
	public void shouldThrowConversionExceptionWhenTargetIsNull() {
		// when
		populator.populate(source, null);
	}
}
