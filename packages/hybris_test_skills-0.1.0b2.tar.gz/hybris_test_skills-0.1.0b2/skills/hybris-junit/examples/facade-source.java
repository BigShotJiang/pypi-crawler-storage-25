package com.ntt.myextension.facades.impl;

import com.ntt.myextension.facades.ProductFacade;
import com.ntt.myextension.services.ProductService;

import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.servicelayer.util.ServicesUtil;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;


public class DefaultProductFacade implements ProductFacade {

	@Resource
	private ProductService productService;

	@Resource
	private Converter<ProductModel, ProductData> productConverter;

	@Override
	public ProductData getProductForCode(final String code) {
		ServicesUtil.validateParameterNotNull(code, "Product code must not be null");
		final ProductModel model = productService.getProductForCode(code);
		if (model == null) {
			return null;
		}
		return productConverter.convert(model);
	}

	@Override
	public List<ProductData> searchProducts(final String searchText, final int pageSize, final int currentPage) {
		if (searchText == null || searchText.trim().isEmpty()) {
			return Collections.emptyList();
		}
		return productService.searchProducts(searchText.trim(), pageSize, currentPage)
				.stream()
				.map(productConverter::convert)
				.collect(Collectors.toList());
	}

	public void setProductService(final ProductService productService) {
		this.productService = productService;
	}

	public void setProductConverter(final Converter<ProductModel, ProductData> productConverter) {
		this.productConverter = productConverter;
	}
}
