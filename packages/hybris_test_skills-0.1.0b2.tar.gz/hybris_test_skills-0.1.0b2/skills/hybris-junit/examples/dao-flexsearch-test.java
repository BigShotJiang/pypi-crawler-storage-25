/*
 * DefaultOrderDAOIntegrationTest.java
 * Exemplo de referência: @IntegrationTest com ImpEx fixture e ArgumentCaptor.
 * Padrões: ServicelayerTest, importCsv(), ArgumentCaptor<FlexibleSearchQuery>.
 */
package com.ntt.myextension.daos.impl;

import de.hybris.bootstrap.annotations.IntegrationTest;
import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.servicelayer.ServicelayerTest;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.servicelayer.search.SearchResult;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;


@IntegrationTest
public class DefaultOrderDAOIntegrationTest extends ServicelayerTest {

	private DefaultOrderDAO orderDAO;

	@Mock
	private FlexibleSearchService flexibleSearchService;

	@Captor
	private ArgumentCaptor<FlexibleSearchQuery> queryCaptor;

	@Mock
	private SearchResult<OrderModel> searchResult;

	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.openMocks(this);
		orderDAO = new DefaultOrderDAO();
		orderDAO.setFlexibleSearchService(flexibleSearchService);

		given(searchResult.getResult()).willReturn(Collections.emptyList());
		given(flexibleSearchService.search(any(FlexibleSearchQuery.class))).willReturn(searchResult);

		// Carrega fixture de dados de teste
		importCsv("/myextension/test/sampleOrders.impex", "utf-8");
	}

	@Test
	public void shouldUseNamedParameterCodeInQuery() {
		// when
		orderDAO.findByCode("TEST_ORDER_001");

		// then
		verify(flexibleSearchService).search(queryCaptor.capture());
		final FlexibleSearchQuery capturedQuery = queryCaptor.getValue();

		assertThat(capturedQuery.getQuery(), containsString("?code"));
		assertEquals("TEST_ORDER_001", capturedQuery.getQueryParameters().get("code"));
	}

	@Test
	public void shouldReturnNullWhenOrderNotFound() {
		// given
		given(searchResult.getResult()).willReturn(Collections.emptyList());

		// when
		final OrderModel result = orderDAO.findByCode("NON_EXISTENT_CODE");

		// then
		assertNull(result);
	}

	@Test
	public void shouldReturnFirstResultWhenMultipleFound() {
		// given
		final OrderModel order = new OrderModel();
		given(searchResult.getResult()).willReturn(List.of(order));

		// when
		final OrderModel result = orderDAO.findByCode("TEST_ORDER_001");

		// then
		assertNotNull(result);
		assertEquals(order, result);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowIllegalArgumentExceptionWhenCodeIsNull() {
		orderDAO.findByCode(null);
	}
}
