package com.ntt.myextension.facades.impl;

import de.hybris.bootstrap.annotations.UnitTest;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;
import com.ntt.myextension.services.ProductService;
import de.hybris.platform.servicelayer.dto.converter.Converter;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.never;
import static org.mockito.ArgumentMatchers.any;


@UnitTest
@RunWith(MockitoJUnitRunner.class)
public class DefaultProductFacadeTest {

	@InjectMocks
	private DefaultProductFacade facade;

	@Mock
	private ProductService productService;

	@Mock
	private Converter<ProductModel, ProductData> productConverter;

	@Mock
	private ProductModel productModel;

	@Test
	public void shouldDelegateToServiceAndConverterWhenProductFound() {
		// given
		final ProductData expectedData = new ProductData();
		given(productService.getProductForCode("TEST_CODE")).willReturn(productModel);
		given(productConverter.convert(productModel)).willReturn(expectedData);

		// when
		final ProductData result = facade.getProductForCode("TEST_CODE");

		// then
		assertEquals(expectedData, result);
		verify(productService).getProductForCode("TEST_CODE");
		verify(productConverter).convert(productModel);
	}

	@Test
	public void shouldReturnNullWhenProductNotFoundInService() {
		// given
		given(productService.getProductForCode("MISSING")).willReturn(null);

		// when
		final ProductData result = facade.getProductForCode("MISSING");

		// then
		assertNull(result);
		verify(productConverter, never()).convert(any());
	}

	@Test
	public void shouldReturnEmptyListWhenSearchTextIsBlank() {
		// when
		final List<ProductData> result = facade.searchProducts("   ", 10, 0);

		// then
		assertTrue(result.isEmpty());
		verify(productService, never()).searchProducts(any(), any(int.class), any(int.class));
	}

	@Test
	public void shouldReturnEmptyListWhenSearchTextIsNull() {
		// when
		final List<ProductData> result = facade.searchProducts(null, 10, 0);

		// then
		assertTrue(result.isEmpty());
	}

	@Test
	public void shouldTrimSearchTextBeforeDelegating() {
		// given
		given(productService.searchProducts("camera", 10, 0)).willReturn(Collections.emptyList());

		// when
		facade.searchProducts("  camera  ", 10, 0);

		// then
		verify(productService).searchProducts("camera", 10, 0);
	}

	@Test(expected = IllegalArgumentException.class)
	public void shouldThrowIllegalArgumentExceptionWhenCodeIsNull() {
		facade.getProductForCode(null);
	}
}
