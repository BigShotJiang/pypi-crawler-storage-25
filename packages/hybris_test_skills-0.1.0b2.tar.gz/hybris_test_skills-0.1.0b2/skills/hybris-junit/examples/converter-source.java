/*
 * DefaultPriceConverter.java
 * Exemplo de referência: Converter simples sem atributo localized.
 * Padrões: null safety, delegação para serviço externo, ConversionException.
 */
package com.ntt.myextension.converters;

import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.core.model.order.price.DiscountModel;
import de.hybris.platform.europe1.model.PriceRowModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.dto.converter.Converter;
import de.hybris.platform.servicelayer.util.ServicesUtil;

import java.math.BigDecimal;

import javax.annotation.Resource;


public class DefaultPriceConverter implements Converter<PriceRowModel, PriceData> {

	@Resource
	private Converter<DiscountModel, PriceData> discountConverter;

	@Override
	public PriceData convert(final PriceRowModel source) throws ConversionException {
		ServicesUtil.validateParameterNotNull(source, "source must not be null");
		final PriceData target = new PriceData();
		populate(source, target);
		return target;
	}

	@Override
	public PriceData convert(final PriceRowModel source, final PriceData prototype) throws ConversionException {
		ServicesUtil.validateParameterNotNull(source, "source must not be null");
		ServicesUtil.validateParameterNotNull(prototype, "prototype must not be null");
		populate(source, prototype);
		return prototype;
	}

	private void populate(final PriceRowModel source, final PriceData target) {
		target.setValue(BigDecimal.valueOf(source.getPrice().doubleValue()));
		target.setCurrencyIso(source.getCurrency() != null ? source.getCurrency().getIsocode() : null);
		target.setFormattedValue(String.format("%s %.2f", target.getCurrencyIso(), source.getPrice()));
		target.setPriceType(source.getNet() != null && source.getNet() ? PriceDataType.BUY : PriceDataType.FROM);
	}

	public void setDiscountConverter(final Converter<DiscountModel, PriceData> discountConverter) {
		this.discountConverter = discountConverter;
	}
}
