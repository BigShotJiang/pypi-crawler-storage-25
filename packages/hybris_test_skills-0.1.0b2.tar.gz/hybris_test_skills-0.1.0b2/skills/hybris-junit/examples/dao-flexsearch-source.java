/*
 * DefaultOrderDAO.java
 * Exemplo de referência: DAO com FlexibleSearch.
 * Padrões: parâmetros nomeados, SELECT {pk}, JOIN, constantes de query.
 */
package com.ntt.myextension.daos.impl;

import com.ntt.myextension.daos.OrderDAO;

import de.hybris.platform.core.model.order.OrderModel;
import de.hybris.platform.core.model.user.UserModel;
import de.hybris.platform.core.enums.OrderStatus;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.servicelayer.search.SearchResult;
import de.hybris.platform.servicelayer.util.ServicesUtil;

import java.util.Collections;
import java.util.List;

import javax.annotation.Resource;


public class DefaultOrderDAO implements OrderDAO {

	private static final String FIND_BY_CODE =
			"SELECT {pk} FROM {Order} WHERE {code} = ?code";

	private static final String FIND_BY_USER =
			"SELECT {pk} FROM {Order} WHERE {user} = ?user ORDER BY {creationtime} DESC";

	private static final String FIND_BY_STATUS =
			"SELECT {o.pk} FROM {Order AS o} WHERE {o.status} = ?status";

	@Resource
	private FlexibleSearchService flexibleSearchService;

	@Override
	public OrderModel findByCode(final String code) {
		ServicesUtil.validateParameterNotNull(code, "Order code must not be null");

		final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_BY_CODE);
		query.addQueryParameter("code", code);
		query.setResultClassList(Collections.singletonList(OrderModel.class));

		final SearchResult<OrderModel> result = flexibleSearchService.search(query);
		return result.getResult().isEmpty() ? null : result.getResult().get(0);
	}

	@Override
	public List<OrderModel> findByUser(final UserModel user) {
		ServicesUtil.validateParameterNotNull(user, "User must not be null");

		final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_BY_USER);
		query.addQueryParameter("user", user);

		return flexibleSearchService.search(query).getResult();
	}

	@Override
	public List<OrderModel> findByStatus(final OrderStatus status) {
		ServicesUtil.validateParameterNotNull(status, "Status must not be null");

		final FlexibleSearchQuery query = new FlexibleSearchQuery(FIND_BY_STATUS);
		query.addQueryParameter("status", status);

		return flexibleSearchService.search(query).getResult();
	}

	public void setFlexibleSearchService(final FlexibleSearchService flexibleSearchService) {
		this.flexibleSearchService = flexibleSearchService;
	}
}
