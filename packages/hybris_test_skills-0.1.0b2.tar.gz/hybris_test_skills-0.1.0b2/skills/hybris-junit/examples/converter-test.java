package com.ntt.myextension.converters;

import de.hybris.bootstrap.annotations.UnitTest;
import de.hybris.platform.commercefacades.product.data.PriceData;
import de.hybris.platform.commercefacades.product.data.PriceDataType;
import de.hybris.platform.core.model.c2l.CurrencyModel;
import de.hybris.platform.europe1.model.PriceRowModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.BDDMockito.given;


@UnitTest
@RunWith(MockitoJUnitRunner.class)
public class DefaultPriceConverterTest {

	@InjectMocks
	private DefaultPriceConverter converter;

	@Mock
	private PriceRowModel priceRow;

	@Mock
	private CurrencyModel currency;

	@Before
	public void setUp() {
		given(currency.getIsocode()).willReturn("BRL");
		given(priceRow.getCurrency()).willReturn(currency);
		given(priceRow.getPrice()).willReturn(Double.valueOf(99.90));
		given(priceRow.getNet()).willReturn(Boolean.TRUE);
	}

	@Test
	public void shouldConvertPriceValueFromPriceRow() {
		// when
		final PriceData result = converter.convert(priceRow);

		// then
		assertNotNull(result);
		assertEquals(0, BigDecimal.valueOf(99.90).compareTo(result.getValue()));
	}

	@Test
	public void shouldMapCurrencyIsocode() {
		// when
		final PriceData result = converter.convert(priceRow);

		// then
		assertEquals("BRL", result.getCurrencyIso());
	}

	@Test
	public void shouldSetPriceTypeToBuyWhenNetIsTrue() {
		// given
		given(priceRow.getNet()).willReturn(Boolean.TRUE);

		// when
		final PriceData result = converter.convert(priceRow);

		// then
		assertEquals(PriceDataType.BUY, result.getPriceType());
	}

	@Test
	public void shouldSetPriceTypeToFromWhenNetIsFalse() {
		// given
		given(priceRow.getNet()).willReturn(Boolean.FALSE);

		// when
		final PriceData result = converter.convert(priceRow);

		// then
		assertEquals(PriceDataType.FROM, result.getPriceType());
	}

	@Test(expected = ConversionException.class)
	public void shouldThrowConversionExceptionWhenSourceIsNull() {
		converter.convert(null);
	}

	@Test
	public void shouldPopulatePrototypeWhenPrototypeOverloadIsCalled() {
		// given
		final PriceData prototype = new PriceData();

		// when
		final PriceData result = converter.convert(priceRow, prototype);

		// then
		assertNotNull(result);
		assertEquals("BRL", result.getCurrencyIso());
	}
}
