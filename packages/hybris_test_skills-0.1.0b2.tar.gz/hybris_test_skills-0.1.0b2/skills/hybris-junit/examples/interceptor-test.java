package com.ntt.myextension.interceptors;

import de.hybris.bootstrap.annotations.UnitTest;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.mockito.BDDMockito.given;


@UnitTest
@RunWith(MockitoJUnitRunner.class)
public class ProductCodeValidationInterceptorTest {

	@InjectMocks
	private ProductCodeValidationInterceptor interceptor;

	@Mock
	private ProductModel model;

	@Mock
	private InterceptorContext ctx;

	@Test
	public void shouldPassValidationWhenCodeIsValid() throws InterceptorException {
		// given
		given(model.getCode()).willReturn("VALID_CODE_001");

		// when / then — no exception expected
		interceptor.onValidate(model, ctx);
	}

	@Test(expected = InterceptorException.class)
	public void shouldThrowInterceptorExceptionWhenCodeIsNull() throws InterceptorException {
		// given
		given(model.getCode()).willReturn(null);

		// when
		interceptor.onValidate(model, ctx);
	}

	@Test(expected = InterceptorException.class)
	public void shouldThrowInterceptorExceptionWhenCodeIsBlank() throws InterceptorException {
		// given
		given(model.getCode()).willReturn("   ");

		// when
		interceptor.onValidate(model, ctx);
	}

	@Test(expected = InterceptorException.class)
	public void shouldThrowInterceptorExceptionWhenCodeContainsSpace() throws InterceptorException {
		// given
		given(model.getCode()).willReturn("INVALID CODE");

		// when
		interceptor.onValidate(model, ctx);
	}

	@Test(expected = InterceptorException.class)
	public void shouldThrowInterceptorExceptionWhenCodeExceedsMaxLength() throws InterceptorException {
		// given
		given(model.getCode()).willReturn("A".repeat(101));

		// when
		interceptor.onValidate(model, ctx);
	}

	@Test
	public void shouldPassValidationWhenCodeIsExactlyMaxLength() throws InterceptorException {
		// given
		given(model.getCode()).willReturn("A".repeat(100));

		// when / then — no exception
		interceptor.onValidate(model, ctx);
	}
}
