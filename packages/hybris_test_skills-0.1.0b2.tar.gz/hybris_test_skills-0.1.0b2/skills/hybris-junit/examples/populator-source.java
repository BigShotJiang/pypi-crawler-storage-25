/*
 * DefaultProductPopulator.java
 * Exemplo de referência: Populator com atributo localized e dependência de MediaService.
 * Padrões demonstrados: @Resource, atributo localized (name), null-safety, MediaContainerService.
 */
package com.ntt.myextension.populators;

import de.hybris.platform.commercefacades.product.data.ImageData;
import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.converters.Populator;
import de.hybris.platform.core.model.media.MediaContainerModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.dto.converter.ConversionException;
import de.hybris.platform.servicelayer.i18n.CommonI18NService;
import de.hybris.platform.servicelayer.media.MediaContainerService;
import de.hybris.platform.servicelayer.util.ServicesUtil;

import java.util.Locale;

import javax.annotation.Resource;


/**
 * Populator de referência: mapeia ProductModel → ProductData.
 * Demonstra: atributo localized, null-safety, delegação para serviço.
 */
public class DefaultProductPopulator implements Populator<ProductModel, ProductData> {

	@Resource
	private CommonI18NService commonI18NService;

	@Resource
	private MediaContainerService mediaContainerService;

	@Override
	public void populate(final ProductModel source, final ProductData target) throws ConversionException {
		ServicesUtil.validateParameterNotNull(source, "source must not be null");
		ServicesUtil.validateParameterNotNull(target, "target must not be null");

		target.setCode(source.getCode());

		// Atributo localized — usar getCurrentLocale() para obter Locale da sessão
		final Locale currentLocale = commonI18NService.getCurrentLocale();
		target.setName(source.getName(currentLocale));
		target.setDescription(source.getDescription(currentLocale));

		// Imagem principal — pode ser null
		final MediaContainerModel thumbnailContainer = source.getThumbnails() != null
				&& !source.getThumbnails().isEmpty()
				? source.getThumbnails().iterator().next()
				: null;

		if (thumbnailContainer != null) {
			final ImageData imageData = new ImageData();
			imageData.setUrl(mediaContainerService.getMediaForFormat(thumbnailContainer, "product").getURL());
			target.setMainImage(imageData);
		}
	}

	// Setters para injeção via Spring XML ou testes
	public void setCommonI18NService(final CommonI18NService commonI18NService) {
		this.commonI18NService = commonI18NService;
	}

	public void setMediaContainerService(final MediaContainerService mediaContainerService) {
		this.mediaContainerService = mediaContainerService;
	}
}
