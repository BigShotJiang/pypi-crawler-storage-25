package com.ntt.myextension.interceptors;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;
import de.hybris.platform.servicelayer.interceptor.ValidateInterceptor;


public class ProductCodeValidationInterceptor implements ValidateInterceptor<ProductModel> {

	private static final int MAX_CODE_LENGTH = 100;

	@Override
	public void onValidate(final ProductModel model, final InterceptorContext ctx) throws InterceptorException {
		final String code = model.getCode();

		if (code == null || code.trim().isEmpty()) {
			throw new InterceptorException("Product code must not be blank", this);
		}

		if (code.contains(" ")) {
			throw new InterceptorException("Product code must not contain spaces: [" + code + "]", this);
		}

		if (code.length() > MAX_CODE_LENGTH) {
			throw new InterceptorException(
					"Product code exceeds maximum length of " + MAX_CODE_LENGTH + " characters: [" + code + "]", this);
		}
	}
}
