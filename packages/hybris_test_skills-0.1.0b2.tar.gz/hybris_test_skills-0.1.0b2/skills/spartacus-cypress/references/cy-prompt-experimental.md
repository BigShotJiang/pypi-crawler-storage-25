---
name: cy-prompt-experimental
description: cy.prompt() experimental feature — uso opcional para comandos em linguagem natural no Cypress
skill: spartacus-cypress
---

# cy.prompt() — Experimental

## Status

`cy.prompt()` é uma feature experimental do Cypress que permite comandos em linguagem natural.
**Não use em CI** — requer chave de API e é instável. Use apenas para exploração local.

## Quando usar

- Exploração inicial de um fluxo desconhecido para gerar seletores
- Prototipagem rápida de um spec antes de escrever código real

## Quando NÃO usar

- CI/CD — causa falhas por rate limiting e custo imprevisível
- Testes de regressão — output não é determinístico
- Qualquer teste que precise ser auditável

## Exemplo de uso (somente local)

```typescript
// cypress.config.ts — habilitar apenas localmente
export default defineConfig({
  e2e: {
    experimentalAI: true, // requer CYPRESS_AI_KEY no ambiente
  },
});
```

```typescript
it('explores checkout with AI assistance (local only)', () => {
  cy.visit('/');
  cy.prompt('Click on the cart icon and verify it shows 0 items');
  // Gera comandos Cypress reais que você pode copiar para o spec definitivo
});
```

## Fluxo recomendado

1. Use `cy.prompt()` para explorar e capturar seletores reais do ambiente D1
2. Copie os comandos gerados para um spec `.cy.ts` real
3. Remova `cy.prompt()` antes de commitar
