---
name: test-data-impex
description: ImpEx fixtures para testes Cypress em D1 — produtos, usuários, endereços e dados B2B mínimos
skill: spartacus-cypress
---

# Test Data via ImpEx para D1

## Problema

Testes Cypress em D1 dependem de dados reais no banco. Sem fixture estável,
testes ficam frágeis (produto fora de estoque, usuário expirado, etc.).

## Verificando pré-existência dos dados no D1

```typescript
// cypress/support/commands.ts
Cypress.Commands.add('importTestData', () => {
  // Executar via cy.task se tiver plugin Node, ou assumir que dados já existem em D1
  cy.log('Test data assumed present in D1 — verify via check-environment script');
});
```

## Fixture mínima para testes de checkout (importar via hMC ou ant impex)

```impex
# Usuário de teste
INSERT_UPDATE Customer;uid[unique=true];name;password;customerID
;cypress-test@ntt.com;Cypress Test User;Cypress@123;cypress-test

# Produto simples em estoque
INSERT_UPDATE Product;code[unique=true];name[lang=pt];supercategories(code)
;CYPRESS-PROD-001;Produto Cypress Teste;testCategory

# Preço do produto
INSERT_UPDATE PriceRow;product(code)[unique=true];currency(isocode)[unique=true];price;unit(code);minqtd;net
;CYPRESS-PROD-001;BRL;49.90;pieces;1;false

INSERT_UPDATE StockLevel;productCode[unique=true];warehouse(code)[unique=true];available;inStockStatus
;CYPRESS-PROD-001;default;100;forceInStock

# Endereço default do usuário de teste
INSERT_UPDATE Address;owner(Customer.uid)[unique=true];streetname;town;postalcode;country(isocode);defaultAddress
;cypress-test@ntt.com;Rua Teste 123;São Paulo;01310-100;BR;true
```

## Verificando dados antes de rodar specs

```typescript
describe('Checkout Flow', () => {
  before(() => {
    // Confirma que produto existe e está em estoque antes de rodar a suíte
    cy.request({
      url: `${Cypress.config('baseUrl')}/occ/v2/${Cypress.env('BASE_SITE')}/products/${Cypress.env('TEST_PRODUCT_CODE') || 'CYPRESS-PROD-001'}`,
      failOnStatusCode: false,
    }).then((response) => {
      expect(response.status, 'Test product must exist in D1').to.eq(200);
    });
  });
});
```

## Credenciais via cypress.env.json (nunca committar)

```json
{
  "TEST_USER": "cypress-test@ntt.com",
  "TEST_PASSWORD": "Cypress@123",
  "BASE_SITE": "mysite"
}
```

```typescript
cy.get('[formcontrolname="userId"]').type(Cypress.env('TEST_USER'));
```
