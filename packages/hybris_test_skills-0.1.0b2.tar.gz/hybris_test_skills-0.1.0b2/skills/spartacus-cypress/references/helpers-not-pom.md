---
name: helpers-not-pom
description: Composição de helper functions para Cypress Spartacus — padrão do repositório SAP/spartacus, sem Page Object Model
skill: spartacus-cypress
---

# Helpers, Não Page Object Model

## Por que não POM no Spartacus

O time SAP/spartacus explicitamente não usa POM. POM encapsula estado em objetos que imitam páginas,
mas em Cypress: (1) estado fica nos comandos e sessões, não em objetos; (2) POM dificulta composição;
(3) helpers puros são mais fáceis de manter em monorepo Spartacus.

## Padrão: helper functions exportadas

```typescript
// Cada helper é uma função pura que opera sobre o DOM via Cypress commands.
// Sem classes. Sem `this`. Sem estado compartilhado.

export function visitHomepage(): void {
  cy.visit('/');
  cy.get('cx-storefront').should('be.visible');
}

export function addProductToCart(productCode: string, quantity = 1): void {
  cy.visit(`/product/${productCode}`);
  if (quantity > 1) {
    cy.get('cx-item-counter input').clear().type(String(quantity));
  }
  cy.get('cx-add-to-cart button[type="submit"]').click();
  cy.get('cx-added-to-cart-dialog').should('be.visible');
}

export function proceedToCheckout(): void {
  cy.get('cx-mini-cart').click();
  cy.get('[data-cy="proceed-to-checkout"]').click();
  cy.url().should('include', '/checkout');
}
```

## Composição no spec

```typescript
import { addProductToCart, proceedToCheckout } from './helpers/cart.helpers';
import { loginAsGuest } from './helpers/auth.helpers'; // ver examples/login.cy.ts para implementação

describe('Checkout Flow', () => {
  it('should complete guest checkout', () => {
    addProductToCart('300938');
    proceedToCheckout();
    loginAsGuest('guest@teste.com');
    // ... continua
  });
});
```

## Onde colocar helpers

Para testes da skill: helpers definidos no mesmo arquivo `.cy.ts` ou em `cypress/support/helpers/`.
Para extensão real do cliente: `<extensao>/cypress/support/helpers/`.

## Regra de granularidade

Um helper = uma ação do usuário (não uma página inteira). Prefira:
- `addProductToCart()` ✅
- `completeEntireCheckoutFlow()` ❌ (difícil de reusar, difícil de debugar)
