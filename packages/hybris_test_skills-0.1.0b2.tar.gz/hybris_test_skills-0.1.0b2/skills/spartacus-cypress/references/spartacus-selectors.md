---
name: spartacus-selectors
description: Element selector strategy for Spartacus — data-cy convention, cx-* components, avoiding fragile selectors
skill: spartacus-cypress
---

# Spartacus Selectors

## Hierarquia de preferência

1. `[data-cy="nome-semantico"]` — mais estável, adicionado pelo time
2. `cx-ComponentName` — componente Spartacus (estável entre versões menores)
3. `[formcontrolname="campo"]` — formulários Angular (estável)
4. `.classe-css` — usar apenas se as opções acima não existirem
5. ~~`#id-gerado`~~ — **nunca use** IDs gerados por Angular

## Exemplos por componente

```typescript
// Mini-cart
cy.get('cx-mini-cart').should('contain', '1');
cy.get('cx-mini-cart .count').should('have.text', '1');

// Add to cart button
cy.get('cx-add-to-cart button[type="submit"]').click();

// Login form
cy.get('[formcontrolname="userId"]').type('user@exemplo.com');
cy.get('[formcontrolname="password"]').type('Senha@123');

// Global messages (erros/alertas)
cy.get('cx-global-message').should('be.visible');
cy.get('cx-global-message .alert-danger').should('contain', 'Erro');

// Order confirmation
cy.get('cx-order-confirmation').should('exist');
cy.get('cx-order-confirmation [data-cy="order-number"]').should('not.be.empty');

// Product card em PLP
cy.get('cx-product-list-item').first().find('a.cx-product-name').click();

// Breadcrumb
cy.get('cx-breadcrumb').should('contain', 'Home');
```

## Adicionando data-cy no template Spartacus

Quando um seletor estável não existe, adicione `data-cy` no template customizado:

```html
<!-- myextension/cms-components/checkout/checkout-summary.component.html -->
<div class="cx-summary-total" data-cy="checkout-total">
  {{ cart.totalPrice?.formattedValue }}
</div>
```

```typescript
cy.get('[data-cy="checkout-total"]').should('contain', 'R$');
```

## Anti-patterns

```typescript
// ❌ ID Angular gerado — muda a cada build
cy.get('#mat-input-0').type('valor');

// ❌ XPath simulado via jQuery — frágil
cy.get('div > ul > li:nth-child(3) > a');

// ❌ Texto literal hardcoded — quebra com i18n
cy.contains('Adicionar ao Carrinho').click();

// ✅ prefira
cy.get('cx-add-to-cart button[type="submit"]').click();
```
