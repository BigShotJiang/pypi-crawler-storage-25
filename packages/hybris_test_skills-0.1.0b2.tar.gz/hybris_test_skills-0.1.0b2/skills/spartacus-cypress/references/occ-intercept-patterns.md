---
name: occ-intercept-patterns
description: Cypress cy.intercept patterns for SAP Commerce OCC REST API v2 — aliasing, waiting, asserting, and stubbing
skill: spartacus-cypress
---

# OCC Intercept Patterns

## Regra de ouro: nunca hardcode o baseSiteId

Use `**` wildcard — o site ID muda por ambiente:

```typescript
// ✅ correto
cy.intercept('GET', '**/occ/v2/**/products/**').as('productDetail');

// ❌ frágil
cy.intercept('GET', '/occ/v2/electronics/products/**').as('productDetail');
```

## Intercepts comuns

```typescript
// CMS page load
cy.intercept('GET', '**/occ/v2/**/cms/pages*').as('cmsPage');

// Product search (PLP)
cy.intercept('GET', '**/occ/v2/**/products/search*').as('productSearch');

// Product detail (PDP)
cy.intercept('GET', '**/occ/v2/**/products/*').as('productDetail');

// ⚠️ Registro obrigatório: productSearch ANTES de productDetail.
// products/* também corresponde a products/search — registrar o mais específico primeiro.

// Create cart (anônimo ou logado)
cy.intercept('POST', '**/occ/v2/**/users/**/carts').as('createCart');

// Add entry to cart
cy.intercept('POST', '**/occ/v2/**/users/**/carts/**/entries').as('addEntry');

// Place order
cy.intercept('POST', '**/occ/v2/**/users/**/orders').as('placeOrder');

// OAuth token
cy.intercept('POST', '**/authorizationserver/oauth/token').as('oauthToken');

// Delivery modes
cy.intercept('GET', '**/occ/v2/**/users/**/carts/**/deliverymodes').as('deliveryModes');
```

## Esperando e validando

```typescript
// Validar status code
cy.wait('@addEntry').its('response.statusCode').should('eq', 200);

// Validar campo do response body
cy.wait('@placeOrder').its('response.body.code').should('match', /^\d{8}$/);

// Inspecionar request body
cy.wait('@addEntry').then(({ request }) => {
  expect(request.body.product.code).to.eq('300938');
  expect(request.body.quantity).to.eq(1);
});
```

## Stubbing (teste isolado de UI)

Use somente quando o backend de D1 não está disponível para o fluxo específico.

```typescript
cy.intercept('GET', '**/occ/v2/**/products/300938', {
  statusCode: 200,
  body: {
    code: '300938',
    name: 'Produto Teste',
    price: { value: 99.99, currencyIso: 'BRL' },
    stock: { stockLevel: 10, stockLevelStatus: 'inStock' },
  },
}).as('productDetail');
```

## Cenário de erro

```typescript
cy.intercept('POST', '**/occ/v2/**/users/**/orders', {
  statusCode: 400,
  body: { errors: [{ type: 'InsufficientStockError', message: 'Out of stock' }] },
}).as('placeOrderFail');

cy.wait('@placeOrderFail');
cy.get('cx-global-message').should('contain', 'Out of stock');
```
