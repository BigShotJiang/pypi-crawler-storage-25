// login.cy.ts
// Exemplo: login/logout Spartacus com cy.session() para reutilizar sessão entre specs.
// Padrão: cy.session cacheando token OAuth, helper de login reutilizável.

// --- Helpers ---

function loginWithCredentials(username: string, password: string): void {
  cy.session(
    ['login', username],
    () => {
      cy.intercept('POST', '**/authorizationserver/oauth/token').as('oauthToken');

      cy.visit('/login');
      cy.get('[formcontrolname="userId"]').type(username);
      cy.get('[formcontrolname="password"]').type(password);
      cy.get('[data-cy="login-submit"]').click();

      cy.wait('@oauthToken').its('response.statusCode').should('eq', 200);
      cy.url().should('not.include', '/login');
      cy.get('cx-login').should('not.contain', 'Entrar');
    },
    {
      validate() {
        cy.getCookie('JSESSIONID').should('exist');
      },
    }
  );
}

// --- Tests ---

describe('Login Flow — Spartacus', () => {
  const USER = Cypress.env('TEST_USER') || 'cypress-test@ntt.com';
  const PASSWORD = Cypress.env('TEST_PASSWORD') || 'Cypress@123';

  it('should login with valid credentials', () => {
    cy.intercept('POST', '**/authorizationserver/oauth/token').as('oauthToken');

    cy.visit('/login');
    cy.get('[formcontrolname="userId"]').type(USER);
    cy.get('[formcontrolname="password"]').type(PASSWORD);
    cy.get('[data-cy="login-submit"]').click();

    cy.wait('@oauthToken').its('response.statusCode').should('eq', 200);
    cy.url().should('not.include', '/login');
    cy.get('cx-login .cx-login-greet').should('contain', 'Cypress');
  });

  it('should show error message with invalid credentials', () => {
    cy.visit('/login');
    cy.get('[formcontrolname="userId"]').type('invalido@ntt.com');
    cy.get('[formcontrolname="password"]').type('senha-errada');
    cy.get('[data-cy="login-submit"]').click();

    cy.get('cx-global-message .alert-danger')
      .should('be.visible')
      .and('contain', 'usuário ou senha');
  });

  it('should logout and redirect to homepage', () => {
    loginWithCredentials(USER, PASSWORD);
    cy.visit('/');
    cy.get('cx-login-register [aria-label="Meu Perfil"]').click();
    cy.get('[data-cy="logout"]').click();
    cy.url().should('eq', `${Cypress.config('baseUrl')}/`);
    cy.get('cx-login').should('contain', 'Entrar');
  });

  it('should reuse session across specs via cy.session', () => {
    loginWithCredentials(USER, PASSWORD);
    cy.visit('/my-account/orders');
    cy.url().should('include', '/my-account/orders');
    cy.get('cx-order-history').should('be.visible');
  });
});
