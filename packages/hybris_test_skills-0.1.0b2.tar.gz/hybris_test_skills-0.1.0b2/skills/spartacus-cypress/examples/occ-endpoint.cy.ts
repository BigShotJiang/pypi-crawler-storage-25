// occ-endpoint.cy.ts
// Exemplo: teste de endpoint OCC customizado — valida contrato de request/response.
// Padrão: cy.request direto para API (não via UI), validação de schema.

describe('Custom OCC Endpoint — Spartacus', () => {
  const BASE_URL = Cypress.config('baseUrl');
  const BASE_SITE = Cypress.env('BASE_SITE') || 'mysite';

  let authToken: string;

  before(() => {
    // Obter token OAuth antes da suíte
    cy.request({
      method: 'POST',
      url: `${BASE_URL}/authorizationserver/oauth/token`,
      form: true,
      body: {
        grant_type: 'password',
        client_id: 'mobile_android',
        client_secret: 'secret',
        username: Cypress.env('TEST_USER'),
        password: Cypress.env('TEST_PASSWORD'),
      },
    }).then(({ body }) => {
      authToken = body.access_token;
    });
  });

  it('should return 200 and valid schema from custom endpoint', () => {
    // Substitua pelo endpoint OCC customizado do projeto
    cy.request({
      method: 'GET',
      url: `${BASE_URL}/occ/v2/${BASE_SITE}/myextension/customdata`,
      headers: { Authorization: `Bearer ${authToken}` },
    }).then(({ status, body }) => {
      expect(status).to.eq(200);
      // Validar campos obrigatórios do contrato
      expect(body).to.have.property('items');
      expect(body.items).to.be.an('array');
      if (body.items.length > 0) {
        expect(body.items[0]).to.have.keys(['id', 'name', 'value']);
      }
    });
  });

  it('should return 401 without authorization header', () => {
    cy.request({
      method: 'GET',
      url: `${BASE_URL}/occ/v2/${BASE_SITE}/myextension/customdata`,
      failOnStatusCode: false,
    }).its('status').should('eq', 401);
  });

  it('should intercept and validate OCC call made by Spartacus component', () => {
    cy.intercept('GET', `**/occ/v2/**/${BASE_SITE}/myextension/customdata`).as('customData');
    cy.visit('/my-custom-page');
    cy.wait('@customData').then(({ response }) => {
      expect(response!.statusCode).to.eq(200);
      expect(response!.body.items).to.be.an('array');
    });
    cy.get('[data-cy="custom-component"]').should('be.visible');
  });
});
