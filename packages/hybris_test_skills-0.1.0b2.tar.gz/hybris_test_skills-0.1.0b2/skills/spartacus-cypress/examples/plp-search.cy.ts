// plp-search.cy.ts
// Exemplo: pesquisa em PLP Spartacus com intercept do endpoint de busca.

function performSearch(query: string): void {
  cy.get('cx-searchbox input[aria-label="Pesquisar"]').type(query);
  cy.get('cx-searchbox input[aria-label="Pesquisar"]').type('{enter}');
}

describe('PLP Search — Spartacus', () => {
  beforeEach(() => {
    cy.intercept('GET', '**/occ/v2/**/products/search*').as('productSearch');
    cy.visit('/');
    cy.get('cx-storefront').should('be.visible');
  });

  it('should return results for a valid search term', () => {
    performSearch('produto');
    cy.wait('@productSearch').then(({ response, request }) => {
      expect(response!.statusCode).to.eq(200);
      expect(request.url).to.include('query=produto');
      expect(response!.body.pagination.totalResults).to.be.greaterThan(0);
    });
    cy.get('cx-product-list-item').should('have.length.greaterThan', 0);
  });

  it('should show no results message for unknown term', () => {
    performSearch('xyzabcnoresult12345');
    cy.wait('@productSearch')
      .its('response.body.pagination.totalResults')
      .should('eq', 0);
    cy.get('[data-cy="no-results"]').should('be.visible');
  });

  it('should filter results by category facet', () => {
    performSearch('produto');
    cy.wait('@productSearch');

    cy.intercept('GET', '**/occ/v2/**/products/search*').as('filteredSearch');
    cy.get('cx-facet').first().find('a').first().click();
    cy.wait('@filteredSearch').then(({ request }) => {
      expect(request.url).to.include('query=produto%3A');
    });
    cy.get('cx-active-facets').should('be.visible');
  });

  it('should navigate to PDP when clicking product from PLP', () => {
    performSearch('produto');
    cy.wait('@productSearch');
    cy.intercept('GET', '**/occ/v2/**/products/*').as('productDetail');
    cy.get('cx-product-list-item').first().find('a.cx-product-name').click();
    cy.wait('@productDetail').its('response.statusCode').should('eq', 200);
    cy.url().should('include', '/product/');
  });
});
