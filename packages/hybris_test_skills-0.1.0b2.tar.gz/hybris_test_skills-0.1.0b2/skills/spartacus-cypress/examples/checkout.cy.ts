// checkout.cy.ts
// Exemplo: checkout E2E Spartacus com OCC intercepts e helper functions.
// Padrão: helpers compostos (não POM), cy.wait por alias, assertivas no response body.

// --- Helpers ---

function addProductToCart(productCode: string): void {
  cy.visit(`/product/${productCode}`);
  cy.get('cx-add-to-cart button[type="submit"]').click();
  cy.get('cx-added-to-cart-dialog').should('be.visible');
  cy.get('cx-added-to-cart-dialog [data-cy="continue-shopping"]').click();
}

function proceedToCheckout(): void {
  cy.get('cx-mini-cart').click();
  cy.get('[data-cy="proceed-to-checkout"]').click();
  cy.url().should('include', '/checkout');
}

function fillShippingAddress(address: {
  firstName: string;
  lastName: string;
  line1: string;
  town: string;
  postalCode: string;
}): void {
  cy.get('[formcontrolname="firstName"]').type(address.firstName);
  cy.get('[formcontrolname="lastName"]').type(address.lastName);
  cy.get('[formcontrolname="line1"]').type(address.line1);
  cy.get('[formcontrolname="town"]').type(address.town);
  cy.get('[formcontrolname="postalCode"]').type(address.postalCode);
  cy.get('[data-cy="address-submit"]').click();
}

// --- Tests ---

describe('Checkout Flow — Spartacus', () => {
  const PRODUCT_CODE = Cypress.env('TEST_PRODUCT_CODE') || 'CYPRESS-PROD-001';
  const BASE_URL = Cypress.config('baseUrl');

  beforeEach(() => {
    cy.intercept('GET', '**/occ/v2/**/cms/pages*').as('cmsPage');
    cy.intercept('POST', '**/occ/v2/**/users/**/carts').as('createCart');
    cy.intercept('POST', '**/occ/v2/**/users/**/carts/**/entries').as('addEntry');
    cy.intercept('GET', '**/occ/v2/**/users/**/carts/**/deliverymodes').as('deliveryModes');
    cy.intercept('POST', '**/occ/v2/**/users/**/orders').as('placeOrder');

    // Verificar que produto existe antes de cada teste
    cy.request({
      url: `${BASE_URL}/occ/v2/${Cypress.env('BASE_SITE')}/products/${PRODUCT_CODE}`,
      failOnStatusCode: false,
    }).its('status').should('eq', 200);
  });

  it('should add product to cart and verify OCC response', () => {
    addProductToCart(PRODUCT_CODE);
    cy.wait('@addEntry').then(({ response }) => {
      expect(response!.statusCode).to.eq(200);
      expect(response!.body.entry.product.code).to.eq(PRODUCT_CODE);
      expect(response!.body.entry.quantity).to.eq(1);
    });
    cy.get('cx-mini-cart .count').should('have.text', '1');
  });

  it('should navigate to checkout after adding product', () => {
    addProductToCart(PRODUCT_CODE);
    proceedToCheckout();
    cy.url().should('include', '/checkout');
    cy.get('cx-checkout-progress').should('be.visible');
  });

  it('should complete checkout and receive order confirmation', () => {
    addProductToCart(PRODUCT_CODE);
    proceedToCheckout();

    fillShippingAddress({
      firstName: 'Cypress',
      lastName: 'Teste',
      line1: 'Rua Teste 123',
      town: 'São Paulo',
      postalCode: '01310-100',
    });

    cy.wait('@deliveryModes');
    cy.get('cx-delivery-mode input[type="radio"]').first().click();
    cy.get('[data-cy="delivery-mode-next"]').click();

    // Pagamento: cartão de crédito
    cy.get('[data-cy="payment-card-number"]').type('4111111111111111');
    cy.get('[data-cy="payment-expiry"]').type('12/28');
    cy.get('[data-cy="payment-cvv"]').type('123');
    cy.get('[data-cy="payment-next"]').click();

    // Review e place order
    cy.get('cx-review-submit').should('be.visible');
    cy.get('[data-cy="place-order"]').click();
    cy.wait('@placeOrder').then(({ response }) => {
      expect(response!.statusCode).to.eq(201);
      expect(response!.body.code).to.match(/^\d{8,}$/);
    });

    cy.get('cx-order-confirmation').should('be.visible');
    cy.get('[data-cy="order-number"]').should('not.be.empty');
  });

  it('should show error when cart is empty and checkout is attempted', () => {
    cy.visit('/cart');
    cy.get('[data-cy="proceed-to-checkout"]').should('be.disabled');
    cy.get('cx-cart-details').should('contain', 'vazio');
  });
});
