// add-to-cart.cy.ts
// Exemplo: add-to-cart Spartacus com validação de mini-cart e controle de quantidade.

function visitProductPage(productCode: string): void {
  cy.intercept('GET', `**/occ/v2/**/products/${productCode}`).as('productDetail');
  cy.visit(`/product/${productCode}`);
  cy.wait('@productDetail').its('response.statusCode').should('eq', 200);
}

describe('Add to Cart — Spartacus', () => {
  const PRODUCT_CODE = Cypress.env('TEST_PRODUCT_CODE') || 'CYPRESS-PROD-001';

  beforeEach(() => {
    cy.intercept('POST', '**/occ/v2/**/users/**/carts/**/entries').as('addEntry');
    cy.intercept('GET', '**/occ/v2/**/users/**/carts/**').as('getCart');
  });

  it('should add one unit to cart and update mini-cart badge', () => {
    visitProductPage(PRODUCT_CODE);
    cy.get('cx-add-to-cart button[type="submit"]').click();

    cy.wait('@addEntry').then(({ response }) => {
      expect(response!.statusCode).to.eq(200);
      expect(response!.body.quantityAdded).to.eq(1);
    });

    cy.get('cx-added-to-cart-dialog').should('be.visible');
    cy.get('cx-mini-cart .count').should('have.text', '1');
  });

  it('should add specific quantity to cart', () => {
    visitProductPage(PRODUCT_CODE);
    cy.get('cx-item-counter input').clear().type('3');
    cy.get('cx-add-to-cart button[type="submit"]').click();

    cy.wait('@addEntry').its('response.body.quantityAdded').should('eq', 3);
    cy.get('cx-mini-cart .count').should('have.text', '3');
  });

  it('should show out-of-stock message when product unavailable', () => {
    cy.intercept('GET', `**/occ/v2/**/products/${PRODUCT_CODE}`, (req) => {
      req.reply({
        statusCode: 200,
        body: {
          code: PRODUCT_CODE,
          stock: { stockLevelStatus: 'outOfStock', stockLevel: 0 },
        },
      });
    }).as('outOfStockProduct');

    cy.visit(`/product/${PRODUCT_CODE}`);
    cy.wait('@outOfStockProduct');
    cy.get('cx-add-to-cart button[type="submit"]').should('be.disabled');
    cy.get('[data-cy="out-of-stock-notice"]').should('be.visible');
  });

  it('should update cart quantity from cart page', () => {
    visitProductPage(PRODUCT_CODE);
    cy.get('cx-add-to-cart button[type="submit"]').click();
    cy.wait('@addEntry');

    cy.visit('/cart');
    cy.intercept('PATCH', '**/occ/v2/**/users/**/carts/**/entries/**').as('updateEntry');
    cy.get('cx-item-counter input').first().clear().type('2');
    cy.wait('@updateEntry').its('response.statusCode').should('eq', 200);
    cy.get('cx-cart-item .cx-total').should('not.be.empty');
  });
});
