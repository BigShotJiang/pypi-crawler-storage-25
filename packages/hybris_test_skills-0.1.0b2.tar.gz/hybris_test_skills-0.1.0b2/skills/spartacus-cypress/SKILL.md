---
name: spartacus-cypress
description: Generates Cypress E2E specs for SAP Commerce Spartacus storefronts — OCC intercepts, helper composition, D1 fixtures
---

# spartacus-cypress

Gera Cypress specs para fluxos Spartacus em ambiente D1. Depende de `hybris-base` para contexto SAP Commerce.

## Fluxo de geração (10 passos)

### 1. Verificar ambiente
Execute `scripts/check_environment.py`. Se falhar, mostre a saída e pare.

### 2. Identificar o fluxo solicitado
Mapeie o pedido para uma das categorias:

| Pedido do usuário | Example a carregar |
|---|---|
| checkout, pagamento, pedido | `examples/checkout.cy.ts` |
| login, logout, autenticação | `examples/login.cy.ts` |
| carrinho, add to cart | `examples/add-to-cart.cy.ts` |
| busca, listagem, PLP | `examples/plp-search.cy.ts` |
| endpoint OCC, API custom | `examples/occ-endpoint.cy.ts` |

### 3. Carregar references sob demanda

| Situação | Carregar |
|---|---|
| Spec usa `cy.intercept` com OCC | `references/occ-intercept-patterns.md` |
| Seletor de elemento Spartacus | `references/spartacus-selectors.md` |
| Dúvida sobre estrutura de helpers | `references/helpers-not-pom.md` |
| Dados de teste em D1 | `references/test-data-impex.md` |
| Usuário menciona cy.prompt | `references/cy-prompt-experimental.md` |

### 4. Verificar pré-condições D1

Antes de gerar, pergunte:
- Qual é a URL base de D1? (ex: `https://d1.myprojeto.com`)
- O produto/usuário de teste já existe no ambiente? (ver `test-data-impex.md`)
- O storefront é Spartacus puro ou híbrido com JSP?

Se híbrido: carregar também `skills/accelerator-jsp-cypress/`.

### 5. Apresentar plano (OBRIGATÓRIO — não gere sem confirmação)

Use `ask_followup_question` com:
- Fluxo a ser testado (happy path + cenários de erro)
- Intercepts OCC planejados (endpoints + aliases)
- Helpers a serem criados
- Dados necessários em D1
- Arquivo de saída: `cypress/e2e/<fluxo>.cy.ts`

### 6. Gerar spec

Após confirmação, use `write_to_file` com:
- `describe` block com nome do fluxo
- `beforeEach` com todos os `cy.intercept` + `cy.session` se logado
- Helpers como funções no topo do arquivo
- `it` blocks: happy path primeiro, depois erros e edge cases
- `cy.wait('@alias')` após cada ação que dispara OCC
- Assertivas no response body além do status code

### 7. Verificar configuração Cypress

Confirme existência de `cypress.config.ts` na extensão. Se não existir, gere:

```typescript
import { defineConfig } from 'cypress';

export default defineConfig({
  e2e: {
    baseUrl: process.env.CYPRESS_BASE_URL || 'http://localhost:9001',
    specPattern: 'cypress/e2e/**/*.cy.ts',
    supportFile: 'cypress/support/e2e.ts',
    video: false,
    screenshotOnRunFailure: true,
  },
});
```

### 8. Executar spec

```bash
scripts/run-cypress.sh <path/to/spec.cy.ts> <base-url>
```

### 9. Analisar resultado

- `"status": "PASS"` → reporte ao arquiteto com número de cenários
- `"status": "FAIL"` → exiba `failures[].message` e `failures[].screenshot`
- `"status": "ERROR"` → problema de configuração; verifique `cypress.config.ts`

### 10. Iterar se necessário

Se falhar por seletor errado: inspecione screenshot, corrija seletor via `references/spartacus-selectors.md`.
Se falhar por intercept não disparado: verifique URL pattern em `references/occ-intercept-patterns.md`.
Se falhar por dados ausentes: verifique `references/test-data-impex.md`.

---

## Guardrails não-negociáveis

1. **Cypress testa fluxos funcionais e regras de negócio** — não comportamento de código Java
2. **Nunca hardcode credenciais** — use `Cypress.env()` com `cypress.env.json` (gitignored)
3. **Nunca use POM** — helpers compostos em funções puras (ver `helpers-not-pom.md`)
4. **Sempre use `cy.wait('@alias')`** após ação que dispara OCC — nunca `cy.wait(2000)`
5. **`cy.prompt()` é proibido em CI** — somente exploração local

---

## Compatibilidade

Spartacus 6.x+ (SAP Commerce 2211+), Cypress 12+, TypeScript 4.9+
