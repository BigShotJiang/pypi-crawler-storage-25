# Guia de Uso — Arquiteto/Analista (Cypress E2E)

## Pré-requisitos

Antes de usar, execute a checagem de ambiente:

```bash
python3 skills/hybris-base/scripts/check_environment.py
```

Se algum item falhar, consulte `docs/installation.md`.

## Invocação

### Opção 1: Comando direto (recomendado)

No aXet Plugin, use o comando `/cypress`:

```
/cypress checkout --spartacus
/cypress b2b-checkout --jsp
/cypress login
/cypress plp-search
/cypress occ-endpoint
```

- `--spartacus` força a skill `spartacus-cypress`
- `--jsp` força a skill `accelerator-jsp-cypress`
- Sem flag: detecção automática pelo projeto (presença de `@spartacus/`, `storefront.module.ts` vs templates JSP)

### Opção 2: Linguagem natural (fallback)

Descreva o contexto no prompt. O router `.axetrules/hybris-tests.md` detecta o storefront e carrega a skill correta.

Exemplos:
- "Gere spec Cypress para o fluxo de checkout do Spartacus em D1"
- "Preciso testar o login B2B no Accelerator, ambiente D1"
- "Crie teste E2E para a busca de produto no nosso storefront JSP"

## Fluxo de confirmação de plano

O agente sempre apresenta um plano antes de gerar. Responda à pergunta com:
- Confirmação dos cenários listados
- Ajustes necessários (ex: "adicionar cenário de usuário sem endereço cadastrado")
- Dados de D1 disponíveis (ex: produto, usuário de teste)

**Nunca pule a confirmação** — garante que os intercepts OCC corretos são mapeados.

## Configuração de ambiente (cypress.env.json)

Crie `cypress.env.json` na raiz da extensão (nunca commite):

```json
{
  "TEST_USER": "cypress-test@ntt.com",
  "TEST_PASSWORD": "Cypress@123",
  "TEST_PRODUCT_CODE": "CYPRESS-PROD-001",
  "BASE_SITE": "mysite"
}
```

Adicione ao `.gitignore`:

```
cypress.env.json
```

## Executando specs geradas

```bash
# Spec único
scripts/run-cypress.sh cypress/e2e/checkout.cy.ts https://d1.myprojeto.com

# Todas as specs
npx cypress run --config baseUrl=https://d1.myprojeto.com
```

## Tipos de fluxo por storefront

| Storefront | Skill | Exemplos incluídos |
|---|---|---|
| Spartacus (Angular) | `spartacus-cypress` | checkout, login, add-to-cart, plp-search, occ-endpoint |
| Accelerator JSP (B2C/B2B) | `accelerator-jsp-cypress` | b2b-checkout, login-csrf, minicart-ajax, search-form |
| Híbrido (ambos) | Ambas as skills | Combina padrões conforme o fluxo |

## Troubleshooting

| Sintoma | Causa provável | Solução |
|---|---|---|
| `cy.wait('@alias')` timeout | Intercept URL errado ou OCC não disparado | Verifique URL pattern em `occ-intercept-patterns.md` |
| `403 Forbidden` em POST JSP | CSRFToken ausente ou inválido | Ver `csrf-token-handling.md` |
| Sessão expirada durante spec | `cy.session()` não configurado | Ver `session-management.md` |
| Seletor não encontrado | ID dinâmico `j_id_*` ou seletor Spartacus quebrou | Ver `jsp-selectors.md` ou `spartacus-selectors.md` |
| `run-cypress.sh` retorna ERROR | Cypress não instalado ou `cypress.config.ts` ausente | `npm install cypress --save-dev` |
| `cy.prompt()` não funciona | Feature experimental, requer `CYPRESS_AI_KEY` | Ver `cy-prompt-experimental.md`; não usar em CI |
| Produto não encontrado em D1 | Dados de teste ausentes | Ver `test-data-impex.md`, importar fixture via hMC |
| Screenshot em branco | D1 não acessível ou IP bloqueado | Verificar VPN/rede para D1; testar `curl <D1_URL>` |
