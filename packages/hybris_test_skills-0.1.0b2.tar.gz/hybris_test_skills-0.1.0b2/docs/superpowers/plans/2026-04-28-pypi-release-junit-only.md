# PyPI Release JUnit-only (v0.1.0b1) — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Publicar `hybris-test-skills v0.1.0b1` no PyPI com apenas o módulo JUnit disponível, atualizando metadados do pacote, README e documentação.

**Architecture:** Mudanças de configuração e documentação — sem código novo. O workflow GitHub Actions existente (`.github/workflows/publish.yml`) dispara automaticamente ao criar a tag `v0.1.0b1`. A verificação do wheel é feita localmente com `uv build` antes do push da tag.

**Tech Stack:** Python / Hatchling (build), uv (build local), GitHub Actions + PyPA Trusted Publisher (publicação no PyPI)

---

## Mapa de arquivos

| Arquivo | Tipo | Mudança |
|---|---|---|
| `pyproject.toml` | Modify | Versão, authors, classifiers, remover Cypress de force-include |
| `README.md` | Rewrite | Fluxo PyPI (pip/uv + hybris install junit) |
| `docs/installation.md` | Modify | Remover Node.js dos pré-req; substituir seção de deps Python; corrigir refs ao Claude Code |
| `docs/usage-arch.md` | Modify | Corrigir uma referência ao "Claude Code" |

---

### Task 1: Atualizar pyproject.toml

**Files:**
- Modify: `pyproject.toml`

- [ ] **Step 1: Substituir a seção `[project]` completa**

Substituir as linhas 6-14 (de `[project]` até `dependencies = []`) por:

```toml
[project]
name = "hybris-test-skills"
version = "0.1.0b1"
description = "SAP Commerce test generation skills for aXet Plugin"
readme = "README.md"
requires-python = ">=3.10"
license = { text = "MIT" }
authors = [{ name = "Igor Chagas" }]
keywords = ["sap", "hybris", "commerce", "testing", "skills"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Programming Language :: Python :: 3",
    "Topic :: Software Development :: Testing",
]
dependencies = []
```

- [ ] **Step 2: Deletar a seção `[project.urls]`**

Remover completamente do arquivo:

```toml
[project.urls]
Repository = "https://github.com/igorchagas/hybris-test-skills"
```

- [ ] **Step 3: Substituir a seção `[tool.hatch.build.targets.wheel.force-include]`**

Substituir o bloco atual (linhas 24-29) por:

```toml
[tool.hatch.build.targets.wheel.force-include]
"skills/hybris-base"  = "hybris_test_skills/_data/base"
"skills/hybris-junit" = "hybris_test_skills/_data/junit"
".axetrules"          = "hybris_test_skills/_data/axetrules"
```

- [ ] **Step 4: Verificar o estado final do arquivo**

O `pyproject.toml` completo deve ficar assim:

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "hybris-test-skills"
version = "0.1.0b1"
description = "SAP Commerce test generation skills for aXet Plugin"
readme = "README.md"
requires-python = ">=3.10"
license = { text = "MIT" }
authors = [{ name = "Igor Chagas" }]
keywords = ["sap", "hybris", "commerce", "testing", "skills"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Programming Language :: Python :: 3",
    "Topic :: Software Development :: Testing",
]
dependencies = []

[project.scripts]
hybris = "hybris_test_skills.cli:main"

[tool.hatch.build.targets.wheel]
packages = ["src/hybris_test_skills"]

[tool.hatch.build.targets.wheel.force-include]
"skills/hybris-base"  = "hybris_test_skills/_data/base"
"skills/hybris-junit" = "hybris_test_skills/_data/junit"
".axetrules"          = "hybris_test_skills/_data/axetrules"
```

- [ ] **Step 5: Commit**

```bash
git add pyproject.toml
git commit -m "chore: versão 0.1.0b1, authors, classifiers, remover Cypress do wheel"
```

---

### Task 2: Reescrever README.md

**Files:**
- Modify: `README.md`

- [ ] **Step 1: Substituir conteúdo completo do README.md**

```markdown
# hybris-test-skills

Skills de geração de testes JUnit para projetos SAP Commerce (Hybris), consumidas pelo **aXet Plugin** no VSCode.

## Instalação

```bash
pip install hybris-test-skills
```

Ou com `uv`:

```bash
uv add hybris-test-skills
```

## Uso

```bash
hybris install junit   # copia skills e .axetrules no diretório atual
hybris list            # lista módulos disponíveis
hybris version         # exibe a versão instalada
```

Execute `hybris install junit` na raiz do projeto SAP Commerce (mesmo nível que `hybrisconfig/` ou `custom/`).

## Pré-requisitos

| Ferramenta | Versão mínima | Finalidade |
|------------|---------------|------------|
| Python     | 3.10+         | Execução dos scripts de skill |
| Java       | 17+           | Compilação e testes do SAP Commerce |
| Ant        | qualquer      | Build do SAP Commerce |
| Bash       | 4+            | Execução dos scripts shell |

> Ant e Java geralmente são providos pelo setup padrão do SAP Commerce. Veja [docs/installation.md](docs/installation.md) para instruções detalhadas por plataforma.

## Módulos disponíveis

| Módulo    | Descrição |
|-----------|-----------|
| `junit`   | Geração de testes JUnit (`@UnitTest` / `@IntegrationTest`) |
| `cypress` | Testes Cypress E2E — **em breve** |

## Integração com aXet Plugin

Após executar `hybris install junit`, abra o aXet Plugin no VSCode e use `/junit <NomeDaClasse>`.

## Licença

MIT — inclui material adaptado de [Emenowicz/sap-commerce-skill](https://github.com/Emenowicz/sap-commerce-skill) (MIT License).
```

- [ ] **Step 2: Commit**

```bash
git add README.md
git commit -m "docs: reescrever README para fluxo PyPI (pip/uv + hybris install junit)"
```

---

### Task 3: Atualizar docs/installation.md

**Files:**
- Modify: `docs/installation.md`

- [ ] **Step 1: Remover Node.js da tabela de pré-requisitos**

Localizar a seção `## Pré-requisitos` no início do arquivo. Remover a linha do Node.js:

```markdown
| Node.js    | 18+           | Runtime para utilitários JavaScript das skills |
```

A tabela final deve ficar:

```markdown
| Ferramenta | Versão mínima | Finalidade |
|------------|---------------|------------|
| Python     | 3.10+         | Execução dos scripts de skill e validação de ambiente |
| pip        | 22+           | Instalação das dependências Python |
| Bash       | 4+            | Execução dos scripts shell das skills |
| Java       | 17+           | Compilação e testes do SAP Commerce (Hybris) |
| Ant        | qualquer      | Build do SAP Commerce (instalado via setup padrão) |
```

- [ ] **Step 2: Remover seções de instalação do Node.js por plataforma**

Cada seção de plataforma (Linux, macOS) contém um bloco de instalação do Node.js via nvm. Remover esses blocos:

**Linux — remover:**
```bash
# Node.js 18+ via nvm (recomendado)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install 18
nvm use 18
node --version
```

**macOS — remover:**
```bash
# Node.js 18+ via nvm
brew install nvm
nvm install 18
nvm use 18
node --version
```

- [ ] **Step 3: Substituir seção "Dependências Python" por "Instalação do pacote"**

Localizar a seção `## Dependências Python` (linha ~95) e substituir por:

```markdown
## Instalação do pacote

```bash
pip install hybris-test-skills
```

Ou com `uv`:

```bash
uv add hybris-test-skills
```

Após instalar, execute na raiz do projeto SAP Commerce:

```bash
hybris install junit
```

Isso copia os scripts de skill e as regras `.axetrules/` no diretório atual.
```

- [ ] **Step 4: Corrigir referências ao Claude Code na seção de integração com aXet**

Localizar a linha 137 (seção `## Integração com aXet Plugin`):

**Antes:**
```
A pasta `.axetrules/` deve estar na raiz do projeto SAP Commerce (mesmo nível que `hybrisconfig/` ou `custom/`). O plugin aXet detecta e carrega as regras automaticamente ao iniciar uma sessão no Claude Code — nenhuma configuração adicional é necessária. As skills ficam disponíveis via comandos `/` no terminal do Claude Code.
```

**Depois:**
```
A pasta `.axetrules/` deve estar na raiz do projeto SAP Commerce (mesmo nível que `hybrisconfig/` ou `custom/`). O aXet Plugin detecta e carrega as regras automaticamente ao abrir o projeto no VSCode — nenhuma configuração adicional é necessária. As skills ficam disponíveis via comandos `/` no aXet Plugin.
```

- [ ] **Step 5: Remover seção de troubleshooting do Node.js**

Localizar e remover a seção:

```markdown
### Node não encontrado

```bash
# Via nvm
nvm install 18
nvm use 18
# Para tornar padrão:
nvm alias default 18
```
```

- [ ] **Step 6: Verificar seção de verificação de ambiente**

A seção `## Verificação do ambiente` mostra output do `check_environment.py`. Esse script ainda verifica Node.js (não será alterado nesta release). Adicionar nota após o bloco de output esperado:

```markdown
> **Nota:** O script ainda verifica Node.js — pode aparecer como `[WARN]` se não instalado, sem impacto no módulo JUnit.
```

- [ ] **Step 7: Commit**

```bash
git add docs/installation.md
git commit -m "docs: atualizar installation.md para fluxo PyPI, remover Node.js, corrigir refs aXet"
```

---

### Task 4: Corrigir referência ao Claude Code em docs/usage-arch.md

**Files:**
- Modify: `docs/usage-arch.md`

- [ ] **Step 1: Corrigir linha 17**

**Antes:**
```markdown
No aXet/Claude Code, use o comando `/cypress`:
```

**Depois:**
```markdown
No aXet Plugin, use o comando `/cypress`:
```

- [ ] **Step 2: Commit**

```bash
git add docs/usage-arch.md
git commit -m "docs: corrigir referência Claude Code → aXet Plugin em usage-arch.md"
```

---

### Task 5: Build local e verificação do wheel

**Files:** nenhum arquivo modificado — apenas verificação.

- [ ] **Step 1: Limpar artefatos anteriores e rebuildar**

```bash
rm -f dist/hybris_test_skills-0.1.0-py3-none-any.whl dist/hybris_test_skills-0.1.0.tar.gz
uv build
```

Esperado: criação de `dist/hybris_test_skills-0.1.0b1-py3-none-any.whl`

- [ ] **Step 2: Verificar que Cypress não está no wheel**

```bash
unzip -l dist/hybris_test_skills-0.1.0b1-py3-none-any.whl | grep -i cypress
```

Esperado: nenhuma linha de output.

- [ ] **Step 3: Verificar que JUnit e base estão no wheel**

```bash
unzip -l dist/hybris_test_skills-0.1.0b1-py3-none-any.whl | grep "_data/"
```

Esperado: linhas com `_data/base/`, `_data/junit/` e `_data/axetrules/`. Sem `_data/cypress/`.

- [ ] **Step 4: Verificar metadados do wheel**

```bash
unzip -p dist/hybris_test_skills-0.1.0b1-py3-none-any.whl "hybris_test_skills-0.1.0b1.dist-info/METADATA" | head -20
```

Esperado:
```
Metadata-Version: 2.x
Name: hybris-test-skills
Version: 0.1.0b1
Summary: SAP Commerce test generation skills for aXet Plugin
...
Author: Igor Chagas
Classifier: Development Status :: 4 - Beta
...
```

---

### Task 6: Configurar Trusted Publisher no PyPI e criar tag de release

Esta task contém passos manuais que devem ser executados pelo mantenedor.

- [ ] **Step 1: Configurar Trusted Publisher no PyPI (manual)**

1. Fazer login em [pypi.org](https://pypi.org)
2. Ir em **Account Settings → Publishing → Add a new pending publisher**
3. Preencher o formulário:
   - **PyPI project name:** `hybris-test-skills`
   - **Owner (GitHub username):** `igorchagas`
   - **Repository name:** `hybris-test-skills`
   - **Workflow filename:** `publish.yml`
   - **Environment name:** `pypi`
4. Clicar em **Add**

> O "pending publisher" permite que o primeiro push de tag crie o projeto no PyPI automaticamente via OIDC — sem token armazenado no GitHub.

- [ ] **Step 2: Verificar que o environment `pypi` existe no repositório GitHub**

No GitHub, ir em **Settings → Environments**. O environment `pypi` deve existir (foi criado junto com o workflow). Se não existir, criar manualmente sem regras de proteção adicionais.

- [ ] **Step 3: Criar e fazer push da tag de release**

```bash
git tag v0.1.0b1
git push origin v0.1.0b1
```

- [ ] **Step 4: Acompanhar o workflow no GitHub Actions**

Abrir a aba **Actions** no repositório GitHub e verificar que o job `publish` do workflow `Publish to PyPI` concluiu com sucesso.

- [ ] **Step 5: Verificar publicação no PyPI**

```bash
pip index versions hybris-test-skills
```

Esperado: `hybris-test-skills (0.1.0b1)`

Ou testar a instalação em um ambiente limpo:

```bash
pip install hybris-test-skills==0.1.0b1
hybris version
```

Esperado: `hybris-test-skills 0.1.0b1`
