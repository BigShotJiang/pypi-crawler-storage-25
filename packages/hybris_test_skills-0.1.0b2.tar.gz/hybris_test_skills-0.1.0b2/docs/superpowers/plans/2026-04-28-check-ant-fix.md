# check_ant Fix: Source from Platform Dir + Upward Search Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Corrigir `check_ant()` para sourciar `setantenv.sh` a partir do seu próprio diretório e buscar o arquivo subindo pelo CWD.

**Architecture:** Extrair `_find_setantenv()` que busca `setantenv.sh` via `HYBRIS_HOME` ou subindo pelo CWD; atualizar `check_ant()` para usar `cd platform_dir && . ./setantenv.sh` garantindo que caminhos relativos dentro do script da SAP resolvam corretamente.

**Tech Stack:** Python 3.10+, pathlib, subprocess, pytest, unittest.mock

---

### Task 1: Adicionar `_find_setantenv()` com testes (TDD)

**Files:**
- Modify: `tests/test_check_environment.py` (adicionar `TestFindSetantenv`)
- Modify: `skills/hybris-base/scripts/check_environment.py` (adicionar `_find_setantenv()`)

- [ ] **Step 1: Escrever os testes que vão falhar**

Em `tests/test_check_environment.py`, adicionar após os imports existentes `import os` (se não estiver) e adicionar a classe ao final do arquivo, antes de `TestMain`:

```python
import os  # adicionar se não existir no topo

# ---------------------------------------------------------------------------
# _find_setantenv
# ---------------------------------------------------------------------------

class TestFindSetantenv:
    def test_returns_path_when_hybris_home_set_and_setantenv_exists(self, tmp_path):
        setantenv = tmp_path / "bin" / "platform" / "setantenv.sh"
        setantenv.parent.mkdir(parents=True)
        setantenv.touch()
        with patch.dict(os.environ, {"HYBRIS_HOME": str(tmp_path)}):
            result = ce._find_setantenv()
        assert result == setantenv

    def test_returns_none_when_hybris_home_set_but_setantenv_missing(self, tmp_path):
        with patch.dict(os.environ, {"HYBRIS_HOME": str(tmp_path)}):
            result = ce._find_setantenv()
        assert result is None

    def test_finds_setantenv_at_cwd(self, tmp_path, monkeypatch):
        setantenv = tmp_path / "hybris" / "bin" / "platform" / "setantenv.sh"
        setantenv.parent.mkdir(parents=True)
        setantenv.touch()
        monkeypatch.delenv("HYBRIS_HOME", raising=False)
        with patch("pathlib.Path.cwd", return_value=tmp_path):
            result = ce._find_setantenv()
        assert result == setantenv

    def test_finds_setantenv_one_level_up_from_cwd(self, tmp_path, monkeypatch):
        setantenv = tmp_path / "hybris" / "bin" / "platform" / "setantenv.sh"
        setantenv.parent.mkdir(parents=True)
        setantenv.touch()
        subdir = tmp_path / "subproject"
        subdir.mkdir()
        monkeypatch.delenv("HYBRIS_HOME", raising=False)
        with patch("pathlib.Path.cwd", return_value=subdir):
            result = ce._find_setantenv()
        assert result == setantenv

    def test_returns_none_when_not_found_anywhere(self, tmp_path, monkeypatch):
        monkeypatch.delenv("HYBRIS_HOME", raising=False)
        with patch("pathlib.Path.cwd", return_value=tmp_path):
            result = ce._find_setantenv()
        assert result is None
```

- [ ] **Step 2: Rodar os testes e verificar que falham**

```bash
python -m pytest tests/test_check_environment.py::TestFindSetantenv -v
```

Saída esperada: `AttributeError: module 'check_environment' has no attribute '_find_setantenv'`

- [ ] **Step 3: Implementar `_find_setantenv()` em `check_environment.py`**

Adicionar logo antes de `def check_ant():` (linha ~111):

```python
def _find_setantenv() -> "Path | None":
    hybris_home = os.environ.get("HYBRIS_HOME")
    if hybris_home:
        p = Path(hybris_home) / "bin" / "platform" / "setantenv.sh"
        return p if p.exists() else None
    current = Path.cwd()
    for _ in range(6):
        candidate = current / "hybris" / "bin" / "platform" / "setantenv.sh"
        if candidate.exists():
            return candidate
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None
```

- [ ] **Step 4: Rodar os testes e verificar que passam**

```bash
python -m pytest tests/test_check_environment.py::TestFindSetantenv -v
```

Saída esperada: `5 passed`

- [ ] **Step 5: Commit**

```bash
git add skills/hybris-base/scripts/check_environment.py tests/test_check_environment.py
git commit -m "feat: adicionar _find_setantenv() com busca upward pelo CWD"
```

---

### Task 2: Atualizar `check_ant()` — cd ao platform_dir + mensagem melhorada (TDD)

**Files:**
- Modify: `tests/test_check_environment.py` (atualizar `TestCheckAnt`)
- Modify: `skills/hybris-base/scripts/check_environment.py` (reescrever `check_ant()`)

- [ ] **Step 1: Substituir `TestCheckAnt` pelos novos testes**

Substituir a classe `TestCheckAnt` inteira em `tests/test_check_environment.py`:

```python
class TestCheckAnt:
    def test_passes_when_ant_in_path(self):
        with patch("shutil.which", return_value="/usr/bin/ant"):
            ok, msg = ce.check_ant()
        assert ok is True
        assert "ant" in msg.lower()

    def test_fails_when_setantenv_not_found(self):
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=None):
                ok, msg = ce.check_ant()
        assert ok is False
        assert "not found" in msg
        assert "HYBRIS_HOME" in msg

    def test_passes_via_setantenv_when_ant_not_in_path(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Apache Ant(TM) version 1.10.15\nant home: /path\n"
        fake_setantenv = Path("/fake/hybris/bin/platform/setantenv.sh")
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
                with patch("subprocess.run", return_value=mock_result):
                    ok, msg = ce.check_ant()
        assert ok is True
        assert "setantenv.sh" in msg
        assert "Apache Ant(TM) version 1.10.15" in msg

    def test_sources_setantenv_from_its_own_directory(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Apache Ant(TM) version 1.10.15\n"
        fake_setantenv = Path("/some/path with spaces/hybris/bin/platform/setantenv.sh")
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
                with patch("subprocess.run", return_value=mock_result) as mock_run:
                    ce.check_ant()
        bash_cmd = mock_run.call_args[0][0][2]  # ["bash", "-c", "<cmd>"]
        assert ". ./setantenv.sh" in bash_cmd
        assert "cd " in bash_cmd
        assert "/some/path with spaces/hybris/bin/platform" in bash_cmd

    def test_fails_when_setantenv_found_but_ant_fails(self):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "chmod: cannot access '/path/ant': No such file\n"
        mock_result.stdout = "Comando 'ant' não encontrado\n"
        fake_setantenv = Path("/fake/hybris/bin/platform/setantenv.sh")
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
                with patch("subprocess.run", return_value=mock_result):
                    ok, msg = ce.check_ant()
        assert ok is False
        assert "falhou" in msg

    def test_error_message_prefers_stdout_over_stderr_chmod(self):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "chmod: cannot access '/path/ant': No such file\n"
        mock_result.stdout = "Comando 'ant' não encontrado\n"
        fake_setantenv = Path("/fake/hybris/bin/platform/setantenv.sh")
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
                with patch("subprocess.run", return_value=mock_result):
                    ok, msg = ce.check_ant()
        assert "chmod" not in msg
        assert "ant" in msg.lower()

    def test_fails_on_ant_timeout(self):
        fake_setantenv = Path("/fake/hybris/bin/platform/setantenv.sh")
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
                with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("bash", 30)):
                    ok, msg = ce.check_ant()
        assert ok is False
        assert "timeout" in msg
```

- [ ] **Step 2: Rodar os testes novos e verificar que falham**

```bash
python -m pytest tests/test_check_environment.py::TestCheckAnt -v
```

Saída esperada: vários `FAILED` — os testes `test_sources_setantenv_from_its_own_directory` e `test_error_message_prefers_stdout_over_stderr_chmod` devem falhar; outros podem ainda passar (comportamento existente compatível).

- [ ] **Step 3: Reescrever `check_ant()` em `check_environment.py`**

Substituir a função `check_ant()` inteira (linhas ~111–135):

```python
def check_ant():
    if shutil.which("ant") is not None:
        return True, "ant encontrado no PATH"

    setantenv = _find_setantenv()

    if setantenv is None:
        return False, (
            "ant not found e hybris/bin/platform/setantenv.sh não encontrado — "
            "defina HYBRIS_HOME ou rode a partir da raiz do projeto"
        )

    platform_dir = setantenv.parent
    try:
        result = subprocess.run(
            ["bash", "-c",
             f"cd {shlex.quote(str(platform_dir))} && . ./setantenv.sh && ant -version"],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            version_line = result.stdout.split("\n")[0].strip()
            return True, f"ant via setantenv.sh ({version_line})"
        output = result.stdout.strip() if result.stdout.strip() else result.stderr.strip()
        first_line = output.splitlines()[0][:120] if output else ""
        return False, f"setantenv.sh encontrado mas ant falhou: {first_line}"
    except subprocess.TimeoutExpired:
        return False, "ant timeout — verifique instalação do SAP Commerce"
```

- [ ] **Step 4: Rodar toda a suite e verificar que passa**

```bash
python -m pytest tests/test_check_environment.py -v
```

Saída esperada: todos os testes passando (incluindo `TestFindSetantenv` e `TestCheckAnt`).

- [ ] **Step 5: Commit**

```bash
git add skills/hybris-base/scripts/check_environment.py tests/test_check_environment.py
git commit -m "fix: sourciar setantenv.sh a partir do platform_dir e melhorar mensagem de erro do check_ant"
```
