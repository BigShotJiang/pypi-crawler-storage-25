# Ant Env Detection — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Fazer `check_environment.py` e `run-junit.sh` encontrarem e usarem o `ant` do SAP Commerce automaticamente via `setantenv.sh`, sem exigir que o dev tenha feito `source setantenv.sh` manualmente.

**Architecture:** `check_environment.py` tenta PATH primeiro; se falhar, executa `. setantenv.sh && ant -version` em subshell para validar. `run-junit.sh` sourcia `setantenv.sh` no início, antes de qualquer uso do `ant`.

**Tech Stack:** Python 3.10+ (stdlib: `os`, `pathlib`, `subprocess`, `shutil`), Bash 4+

---

## Files

- Modify: `skills/hybris-base/scripts/check_environment.py` — função `check_ant()` + imports
- Modify: `tests/test_check_environment.py` — classe `TestCheckAnt`: 1 teste atualizado + 4 novos
- Modify: `skills/hybris-junit/scripts/run-junit.sh` — sourcing de `setantenv.sh` + atualização do comentário de requisitos

---

## Task 1: TDD — nova `check_ant()` com fallback via setantenv.sh

**Files:**
- Modify: `tests/test_check_environment.py`
- Modify: `skills/hybris-base/scripts/check_environment.py`

- [ ] **Step 1: Atualizar teste existente `test_fails_when_ant_not_in_path`**

O teste atual não mocka `Path.exists`, tornando-o dependente do filesystem real. Torná-lo explícito:

Em `tests/test_check_environment.py`, dentro de `class TestCheckAnt`, substituir:

```python
def test_fails_when_ant_not_in_path(self):
    with patch("shutil.which", return_value=None):
        ok, msg = ce.check_ant()
    assert ok is False
    assert "not found" in msg
```

por:

```python
def test_fails_when_ant_not_in_path_and_no_setantenv(self):
    with patch("shutil.which", return_value=None):
        with patch("pathlib.Path.exists", return_value=False):
            ok, msg = ce.check_ant()
    assert ok is False
    assert "not found" in msg
```

- [ ] **Step 2: Adicionar 4 novos testes ao final de `class TestCheckAnt`**

Adicionar logo após `test_fails_when_ant_not_in_path_and_no_setantenv`:

```python
    def test_passes_via_setantenv_when_ant_not_in_path(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Apache Ant(TM) version 1.10.14\n"
        with patch("shutil.which", return_value=None):
            with patch("pathlib.Path.exists", return_value=True):
                with patch("subprocess.run", return_value=mock_result):
                    ok, msg = ce.check_ant()
        assert ok is True
        assert "setantenv.sh" in msg

    def test_fails_when_setantenv_found_but_ant_fails(self):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "ant: command not found"
        with patch("shutil.which", return_value=None):
            with patch("pathlib.Path.exists", return_value=True):
                with patch("subprocess.run", return_value=mock_result):
                    ok, msg = ce.check_ant()
        assert ok is False
        assert "falhou" in msg

    def test_fails_on_ant_timeout(self):
        with patch("shutil.which", return_value=None):
            with patch("pathlib.Path.exists", return_value=True):
                with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("bash", 30)):
                    ok, msg = ce.check_ant()
        assert ok is False
        assert "timeout" in msg

    def test_error_message_mentions_hybris_home_when_setantenv_missing(self):
        with patch("shutil.which", return_value=None):
            with patch("pathlib.Path.exists", return_value=False):
                ok, msg = ce.check_ant()
        assert ok is False
        assert "HYBRIS_HOME" in msg
```

- [ ] **Step 3: Rodar os testes para confirmar que falham**

```bash
cd "/home/igorchagas/Documentos/1. Projetos/Claude/hybris-test-skills"
python -m pytest tests/test_check_environment.py::TestCheckAnt -v
```

Resultado esperado: 4 testes FAIL (os novos), 1 ou 2 PASS (os já existentes que ainda funcionam). Se algum novo passar já, revise o mock — pode estar passando por acidente.

- [ ] **Step 4: Implementar nova `check_ant()` em `check_environment.py`**

Em `skills/hybris-base/scripts/check_environment.py`:

**4a.** Adicionar imports após `import shutil` (linha 10):

```python
import os
from pathlib import Path
```

**4b.** Substituir a função `check_ant()` inteira (linhas 108-111):

```python
def check_ant():
    if shutil.which("ant") is not None:
        return True, "ant encontrado no PATH"

    hybris_home = os.environ.get("HYBRIS_HOME", "hybris")
    platform_dir = Path(hybris_home) / "bin" / "platform"
    setantenv = platform_dir / "setantenv.sh"

    if not setantenv.exists():
        return False, (
            f"ant not found e {setantenv} não encontrado — "
            "defina HYBRIS_HOME ou rode a partir da raiz do projeto"
        )

    try:
        result = subprocess.run(
            ["bash", "-c", f". '{setantenv}' && ant -version"],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            version_line = result.stdout.split("\n")[0].strip()
            return True, f"ant via setantenv.sh ({version_line})"
        return False, f"setantenv.sh encontrado mas ant falhou: {result.stderr.strip()[:100]}"
    except subprocess.TimeoutExpired:
        return False, "ant timeout — verifique instalação do SAP Commerce"
```

- [ ] **Step 5: Rodar toda a suíte de testes para confirmar que passa**

```bash
python -m pytest tests/test_check_environment.py -v
```

Resultado esperado: todos os testes PASS (27 inalterados + 1 renomeado + 4 novos = 32 total). Se algum falhar, revise os mocks — provavelmente `pathlib.Path.exists` está afetando outra parte do código.

- [ ] **Step 6: Commit**

```bash
git add skills/hybris-base/scripts/check_environment.py tests/test_check_environment.py
git commit -m "feat: check_ant() com fallback automático via setantenv.sh"
```

---

## Task 2: Atualizar `run-junit.sh` — sourcing automático de setantenv.sh

**Files:**
- Modify: `skills/hybris-junit/scripts/run-junit.sh`

- [ ] **Step 1: Adicionar bloco de sourcing após a linha `PLATFORM_DIR=...`**

Em `skills/hybris-junit/scripts/run-junit.sh`, após a linha 12 (`PLATFORM_DIR="${HYBRIS_HOME}/bin/platform"`), inserir:

```bash
# Garante que ant está no PATH via setantenv.sh do hybris
SETANTENV="${PLATFORM_DIR}/setantenv.sh"
if [ -f "$SETANTENV" ]; then
    set +u  # setantenv.sh pode referenciar variáveis não definidas
    # shellcheck source=/dev/null
    . "$SETANTENV" > /dev/null 2>&1
    set -u
fi
```

O arquivo deve ficar assim nas primeiras linhas relevantes:

```bash
set -uo pipefail

HYBRIS_HOME="${HYBRIS_HOME:-hybris}"
PLATFORM_DIR="${HYBRIS_HOME}/bin/platform"

# Garante que ant está no PATH via setantenv.sh do hybris
SETANTENV="${PLATFORM_DIR}/setantenv.sh"
if [ -f "$SETANTENV" ]; then
    set +u  # setantenv.sh pode referenciar variáveis não definidas
    # shellcheck source=/dev/null
    . "$SETANTENV" > /dev/null 2>&1
    set -u
fi

if [ $# -lt 1 ]; then
```

- [ ] **Step 2: Atualizar o comentário de requisitos no cabeçalho do arquivo**

Substituir a linha:

```bash
# Requer: ant configurado no PATH, HYBRIS_HOME apontando para raiz do Hybris,
```

por:

```bash
# Requer: HYBRIS_HOME apontando para raiz do Hybris (default: ./hybris),
#         ant disponível via PATH ou via $HYBRIS_HOME/bin/platform/setantenv.sh,
```

- [ ] **Step 3: Verificar integridade do script com bash**

```bash
bash -n skills/hybris-junit/scripts/run-junit.sh
```

Resultado esperado: nenhuma saída (sem erros de sintaxe).

- [ ] **Step 4: Commit**

```bash
git add skills/hybris-junit/scripts/run-junit.sh
git commit -m "feat: run-junit.sh sourcia setantenv.sh automaticamente para resolver ant"
```

---

## Verificação manual (opcional — requer ambiente hybris real)

Para validar end-to-end em um projeto SAP Commerce real (sem `source setantenv.sh` feito):

```bash
# A partir da raiz do projeto hybris (onde existe ./hybris/bin/platform/)
python skills/hybris-base/scripts/check_environment.py
# Esperado: "[OK]     Ant: ant via setantenv.sh (Apache Ant(TM) version ...)"
```
