# hybris-test-skills PyPI Package — Fase 1 (JUnit) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Transformar o repositório em um pacote PyPI instalável via `uv tool install hybris-test-skills`, com CLI `hybris install junit` que copia as skills de JUnit para qualquer workspace.

**Architecture:** `pyproject.toml` fica na raiz do repo (não em `packages/`) para que o Hatchling consiga incluir `skills/` e `.axetrules/` via `force-include`. Os arquivos de skill continuam na raiz como fonte da verdade; o wheel os embute em `hybris_test_skills/_data/`. A CLI usa `Path(__file__).parent / "_data"` para encontrá-los após instalação. Cypress fica no bundle mas não é exposto até Fase 2.

**Tech Stack:** Python 3.10+, Hatchling (build), uv (install/build), argparse (CLI), pytest (testes)

---

## File Map

| Arquivo | Ação | Responsabilidade |
|---|---|---|
| `skills/hybris-junit/scripts/parse_java_class.py` | mover de `scripts/` | Parser Java — pertence ao módulo JUnit |
| `skills/hybris-junit/scripts/parse_items_xml.py` | mover de `scripts/` | Parser XML — pertence ao módulo JUnit |
| `skills/hybris-junit/scripts/run-junit.sh` | mover de `scripts/` | Runner JUnit — pertence ao módulo JUnit |
| `skills/hybris-base/scripts/check_environment.py` | mover de `scripts/` | Verificador de ambiente — pertence à base |
| `skills/hybris-base/scripts/requirements.txt` | mover de `scripts/` | Dependências Python — pertence à base |
| `skills/hybris-junit/SKILL.md` | modificar | Atualizar 4 referências de caminho de `scripts/` |
| `tests/test_parse_java_class.py` | modificar | Atualizar sys.path para novo caminho |
| `tests/test_parse_items_xml.py` | modificar | Atualizar sys.path para novo caminho |
| `tests/test_check_environment.py` | modificar | Atualizar sys.path para novo caminho |
| `pyproject.toml` | criar (raiz) | Build config Hatchling + CLI entry point |
| `src/hybris_test_skills/__init__.py` | criar | Pacote Python (vazio) |
| `src/hybris_test_skills/cli.py` | criar | Lógica de `hybris install/list/version` |
| `tests/test_cli.py` | criar | Testes unitários da CLI |

---

## Task 1: Mover scripts para dentro das skills

**Files:**
- Move: `scripts/parse_java_class.py` → `skills/hybris-junit/scripts/parse_java_class.py`
- Move: `scripts/parse_items_xml.py` → `skills/hybris-junit/scripts/parse_items_xml.py`
- Move: `scripts/run-junit.sh` → `skills/hybris-junit/scripts/run-junit.sh`
- Move: `scripts/check_environment.py` → `skills/hybris-base/scripts/check_environment.py`
- Move: `scripts/requirements.txt` → `skills/hybris-base/scripts/requirements.txt`

- [ ] **Step 1: Criar diretórios de destino**

```bash
mkdir -p "skills/hybris-junit/scripts"
mkdir -p "skills/hybris-base/scripts"
```

- [ ] **Step 2: Mover arquivos JUnit**

```bash
git mv scripts/parse_java_class.py skills/hybris-junit/scripts/parse_java_class.py
git mv scripts/parse_items_xml.py  skills/hybris-junit/scripts/parse_items_xml.py
git mv scripts/run-junit.sh        skills/hybris-junit/scripts/run-junit.sh
```

- [ ] **Step 3: Mover arquivos base**

```bash
git mv scripts/check_environment.py skills/hybris-base/scripts/check_environment.py
git mv scripts/requirements.txt      skills/hybris-base/scripts/requirements.txt
```

- [ ] **Step 4: Verificar que `scripts/` só tem run-cypress.sh (para Fase 2)**

```bash
ls scripts/
```

Esperado: apenas `run-cypress.sh` (Cypress fica para Fase 2, não move agora).

- [ ] **Step 5: Commitar**

```bash
git add -A
git commit -m "refactor: move scripts into skills — parse/run-junit em hybris-junit/scripts/, check-env em hybris-base/scripts/"
```

---

## Task 2: Atualizar sys.path nos arquivos de teste existentes

**Files:**
- Modify: `tests/test_parse_java_class.py:12`
- Modify: `tests/test_parse_items_xml.py`
- Modify: `tests/test_check_environment.py`

- [ ] **Step 1: Atualizar `tests/test_parse_java_class.py`**

Linha atual (12):
```python
sys.path.insert(0, str(Path(__file__).parent.parent / "scripts"))
```

Substituir por:
```python
sys.path.insert(0, str(Path(__file__).parent.parent / "skills" / "hybris-junit" / "scripts"))
```

- [ ] **Step 2: Atualizar `tests/test_parse_items_xml.py`**

Localizar a linha com `sys.path.insert` que aponta para `"scripts"` e substituir por:
```python
sys.path.insert(0, str(Path(__file__).parent.parent / "skills" / "hybris-junit" / "scripts"))
```

- [ ] **Step 3: Atualizar `tests/test_check_environment.py`**

Localizar a linha com `sys.path.insert` que aponta para `"scripts"` e substituir por:
```python
sys.path.insert(0, str(Path(__file__).parent.parent / "skills" / "hybris-base" / "scripts"))
```

- [ ] **Step 4: Rodar testes existentes para confirmar que passam**

```bash
python -m pytest tests/test_parse_java_class.py tests/test_parse_items_xml.py tests/test_check_environment.py -v
```

Esperado: todos passam.

- [ ] **Step 5: Commitar**

```bash
git add tests/
git commit -m "fix: atualiza sys.path nos testes para novos caminhos dos scripts"
```

---

## Task 3: Atualizar referências de caminho no SKILL.md do hybris-junit

**Files:**
- Modify: `skills/hybris-junit/SKILL.md`

- [ ] **Step 1: Substituir as 4 referências a `scripts/` no SKILL.md**

No arquivo `skills/hybris-junit/SKILL.md`, substituir:

```
python3 scripts/parse-java-class.py <ClasseAlvo.java>
```
por:
```
python3 skills/hybris-junit/scripts/parse_java_class.py <ClasseAlvo.java>
```

```
python3 scripts/parse-items-xml.py <extension>-items.xml <ItemType>
```
por:
```
python3 skills/hybris-junit/scripts/parse_items_xml.py <extension>-items.xml <ItemType>
```

```
bash scripts/run-junit.sh <fully.qualified.TestClassName>
```
por:
```
bash skills/hybris-junit/scripts/run-junit.sh <fully.qualified.TestClassName>
```

```
scripts/test-healer.py
```
por:
```
skills/hybris-junit/scripts/test-healer.py
```

(Nota: `test-healer.py` ainda não existe — é Sprint 4. Manter a referência atualizada para quando for criado.)

- [ ] **Step 2: Verificar que o SKILL.md não contém mais referências a `scripts/` raiz**

```bash
grep "scripts/" skills/hybris-junit/SKILL.md
```

Esperado: todas as linhas mostradas devem conter `skills/hybris-junit/scripts/`.

- [ ] **Step 3: Commitar**

```bash
git add skills/hybris-junit/SKILL.md
git commit -m "fix: atualiza caminhos de scripts no SKILL.md do hybris-junit"
```

---

## Task 4: Criar pyproject.toml e scaffold do pacote

**Files:**
- Create: `pyproject.toml` (raiz do repo)
- Create: `src/hybris_test_skills/__init__.py`

- [ ] **Step 1: Criar diretório do pacote**

```bash
mkdir -p src/hybris_test_skills
```

- [ ] **Step 2: Criar `src/hybris_test_skills/__init__.py`**

```python
"""hybris-test-skills — SAP Commerce test generation skills."""

__version__ = "0.1.0"
```

- [ ] **Step 3: Criar `pyproject.toml` na raiz**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "hybris-test-skills"
version = "0.1.0"
description = "SAP Commerce test generation skills for aXet / Claude Code"
readme = "README.md"
requires-python = ">=3.10"
license = { text = "MIT" }
keywords = ["sap", "hybris", "commerce", "testing", "skills"]
dependencies = []

[project.scripts]
hybris = "hybris_test_skills.cli:main"

[project.urls]
Repository = "https://github.com/igorchagas/hybris-test-skills"

[tool.hatch.build.targets.wheel]
packages = ["src/hybris_test_skills"]

[tool.hatch.build.targets.wheel.force-include]
"skills/hybris-base"   = "hybris_test_skills/_data/base"
"skills/hybris-junit"  = "hybris_test_skills/_data/junit"
"skills/spartacus-cypress"        = "hybris_test_skills/_data/cypress/spartacus"
"skills/accelerator-jsp-cypress"  = "hybris_test_skills/_data/cypress/accelerator"
".axetrules"           = "hybris_test_skills/_data/axetrules"
```

> **Nota:** Cypress é incluído no bundle mas não exposto pela CLI em Fase 1. O wheel contém tudo; a CLI filtra o que instala.

- [ ] **Step 4: Verificar que o uv consegue fazer build**

```bash
uv build
```

Esperado: cria `dist/hybris_test_skills-0.1.0-py3-none-any.whl` sem erros.

- [ ] **Step 5: Inspecionar conteúdo do wheel para confirmar que skills estão incluídas**

```bash
python3 -c "
import zipfile, sys
with zipfile.ZipFile('dist/hybris_test_skills-0.1.0-py3-none-any.whl') as z:
    names = z.namelist()
    print('SKILL.md files:', [n for n in names if 'SKILL.md' in n])
    print('axetrules:', [n for n in names if 'axetrules' in n])
"
```

Esperado: lista contém `hybris_test_skills/_data/base/SKILL.md`, `hybris_test_skills/_data/junit/SKILL.md`, arquivos de `.axetrules/`.

- [ ] **Step 6: Commitar**

```bash
git add pyproject.toml src/
git commit -m "feat: pyproject.toml + scaffold do pacote hybris-test-skills (Hatchling, force-include)"
```

---

## Task 5: Implementar CLI (TDD)

**Files:**
- Create: `tests/test_cli.py`
- Create: `src/hybris_test_skills/cli.py`

- [ ] **Step 1: Escrever os testes primeiro**

Criar `tests/test_cli.py`:

```python
"""Testes para a CLI hybris install/list/version."""
import sys
from pathlib import Path
import pytest

# Adiciona src/ ao path para importar o pacote sem instalar
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


class TestInstallJunit:
    def test_copia_axetrules_dev(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / ".axetrules" / "commands.md").exists()
        assert (tmp_path / ".axetrules" / "hybris-tests.md").exists()
        assert (tmp_path / ".axetrules" / "hybris-tests-dev.md").exists()

    def test_nao_copia_axetrules_arch(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert not (tmp_path / ".axetrules" / "hybris-tests-arch.md").exists()

    def test_copia_skill_base(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-base" / "SKILL.md").exists()

    def test_copia_skill_junit(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-junit" / "SKILL.md").exists()

    def test_copia_scripts_junit(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-junit" / "scripts" / "parse_java_class.py").exists()
        assert (tmp_path / "skills" / "hybris-junit" / "scripts" / "run-junit.sh").exists()

    def test_copia_scripts_base(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-base" / "scripts" / "check_environment.py").exists()

    def test_nao_copia_cypress(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert not (tmp_path / "skills" / "spartacus-cypress").exists()
        assert not (tmp_path / "skills" / "accelerator-jsp-cypress").exists()


class TestInstallCypress:
    def test_exibe_coming_soon(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_install
        cmd_install("cypress", tmp_path)

        out = capsys.readouterr().out
        assert "coming soon" in out.lower()

    def test_nao_cria_arquivos(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("cypress", tmp_path)

        assert not (tmp_path / "skills").exists()


class TestInstallAll:
    def test_all_instala_junit_na_fase1(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("all", tmp_path)

        assert (tmp_path / "skills" / "hybris-junit" / "SKILL.md").exists()


class TestVersion:
    def test_exibe_versao(self, capsys):
        from hybris_test_skills.cli import cmd_version
        cmd_version()

        out = capsys.readouterr().out
        assert "0.1.0" in out


class TestList:
    def test_exibe_modulos_disponiveis(self, capsys):
        from hybris_test_skills.cli import cmd_list
        from pathlib import Path
        cmd_list(Path("."))

        out = capsys.readouterr().out
        assert "junit" in out
        assert "cypress" in out
```

- [ ] **Step 2: Rodar testes para confirmar que falham (red)**

```bash
python -m pytest tests/test_cli.py -v
```

Esperado: `ImportError` ou `ModuleNotFoundError` — `cli.py` não existe ainda.

- [ ] **Step 3: Criar `src/hybris_test_skills/cli.py`**

```python
"""CLI hybris — instala skills de teste SAP Commerce no workspace."""
import argparse
import shutil
from pathlib import Path

VERSION = "0.1.0"

_DATA = Path(__file__).parent / "_data"

_JUNIT_CONFIG = {
    "skills": {
        "hybris-base": _DATA / "base",
        "hybris-junit": _DATA / "junit",
    },
    "axetrules": ["commands.md", "hybris-tests.md", "hybris-tests-dev.md"],
}


def cmd_install(module: str, dest: Path) -> None:
    if module == "cypress":
        print("Cypress module not available in this version. Coming soon in v1.0.0.")
        return

    config = _JUNIT_CONFIG  # Phase 1: all = junit

    _copy_skills(config["skills"], dest)
    _copy_axetrules(config["axetrules"], dest)

    print(f"hybris-test-skills[{module}] installed in {dest}")


def _copy_skills(skills: dict, dest: Path) -> None:
    skills_dest = dest / "skills"
    for dirname, src in skills.items():
        _copy_tree(src, skills_dest / dirname)


def _copy_axetrules(filenames: list, dest: Path) -> None:
    axetrules_src = _DATA / "axetrules"
    axetrules_dest = dest / ".axetrules"
    axetrules_dest.mkdir(parents=True, exist_ok=True)
    for fname in filenames:
        src = axetrules_src / fname
        if src.exists():
            shutil.copy2(src, axetrules_dest / fname)


def _copy_tree(src: Path, dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        target = dest / item.name
        if item.is_dir():
            _copy_tree(item, target)
        else:
            shutil.copy2(item, target)


def cmd_list(_dest: Path) -> None:
    print("Available modules:")
    print("  junit   — JUnit test generation skills (hybris-base + hybris-junit)")
    print("  cypress — Cypress E2E skills [coming soon in v1.0.0]")
    print("  all     — All modules [Phase 1: installs junit]")


def cmd_version() -> None:
    print(f"hybris-test-skills {VERSION}")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="hybris",
        description="SAP Commerce test skills installer",
    )
    sub = parser.add_subparsers(dest="command")

    install_p = sub.add_parser("install", help="Install skills into current workspace")
    install_p.add_argument("module", choices=["junit", "cypress", "all"])

    sub.add_parser("list", help="List available modules")
    sub.add_parser("version", help="Show installed version")

    args = parser.parse_args()

    if args.command == "install":
        cmd_install(args.module, Path.cwd())
    elif args.command == "list":
        cmd_list(Path.cwd())
    elif args.command == "version":
        cmd_version()
    else:
        parser.print_help()
```

- [ ] **Step 4: Rodar testes (green)**

```bash
python -m pytest tests/test_cli.py -v
```

Esperado: todos os testes passam.

> **Nota:** Os testes de `TestInstallJunit` que verificam cópia de arquivos reais (SKILL.md, scripts) irão passar somente após o `uv build` ter gerado o `_data/` dentro do pacote instalado. Neste step, rodamos com `sys.path` apontando para `src/`, então `_DATA` aponta para `src/hybris_test_skills/_data/` que ainda não existe. Se os testes de cópia falharem por `_data/` não existir, pule para o Step 6 e volte.

- [ ] **Step 5: Commitar**

```bash
git add src/hybris_test_skills/cli.py tests/test_cli.py
git commit -m "feat: CLI hybris install/list/version — TDD, suporte a junit (Fase 1) e cypress coming-soon"
```

---

## Task 6: Instalar localmente e validar end-to-end

**Files:** nenhum criado — validação funcional

- [ ] **Step 1: Instalar o pacote em modo editable com uv**

```bash
uv pip install -e .
```

Esperado: instala sem erros e o comando `hybris` fica disponível.

- [ ] **Step 2: Verificar que o comando existe**

```bash
hybris version
```

Esperado: `hybris-test-skills 0.1.0`

- [ ] **Step 3: Testar `hybris install junit` em diretório temporário**

```bash
mkdir /tmp/test-hybris-install
cd /tmp/test-hybris-install
hybris install junit
```

Esperado:
```
hybris-test-skills[junit] installed in /tmp/test-hybris-install
```

- [ ] **Step 4: Verificar estrutura copiada**

```bash
find /tmp/test-hybris-install -type f | sort
```

Esperado — deve conter:
```
/tmp/test-hybris-install/.axetrules/commands.md
/tmp/test-hybris-install/.axetrules/hybris-tests-dev.md
/tmp/test-hybris-install/.axetrules/hybris-tests.md
/tmp/test-hybris-install/skills/hybris-base/SKILL.md
/tmp/test-hybris-install/skills/hybris-base/scripts/check_environment.py
/tmp/test-hybris-install/skills/hybris-junit/SKILL.md
/tmp/test-hybris-install/skills/hybris-junit/scripts/parse_java_class.py
/tmp/test-hybris-install/skills/hybris-junit/scripts/run-junit.sh
... (demais arquivos de references/ e examples/)
```

NÃO deve conter: `spartacus-cypress`, `accelerator-jsp-cypress`, `hybris-tests-arch.md`

- [ ] **Step 5: Testar `hybris install cypress` (coming soon)**

```bash
hybris install cypress
```

Esperado: `Cypress module not available in this version. Coming soon in v1.0.0.`
Verificar: nenhum arquivo foi criado além dos do step 3.

- [ ] **Step 6: Rodar todos os testes com pacote instalado**

```bash
cd /home/igorchagas/Documentos/1.\ Projetos/Claude/hybris-test-skills
python -m pytest tests/ -v
```

Esperado: todos passam.

- [ ] **Step 7: Commitar (se algum ajuste foi necessário)**

```bash
git add -A
git commit -m "fix: ajustes pós smoke test local (se houver)"
```

Se não houve ajustes, pule este step.

---

## Task 7: GitHub Actions — publicação automática no PyPI

**Files:**
- Create: `.github/workflows/publish.yml`

- [ ] **Step 1: Criar diretório**

```bash
mkdir -p .github/workflows
```

- [ ] **Step 2: Criar `.github/workflows/publish.yml`**

```yaml
name: Publish to PyPI

on:
  push:
    tags:
      - "v*"

jobs:
  publish:
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write  # necessário para trusted publisher (sem token hardcoded)

    steps:
      - uses: actions/checkout@v4

      - uses: astral-sh/setup-uv@v4
        with:
          version: "latest"

      - name: Build wheel
        run: uv build

      - name: Publish to PyPI
        uses: pypa/gh-action-pypi-publish@release/v1
        with:
          packages-dir: dist/
```

> **Pré-requisito no PyPI:** configurar Trusted Publisher em pypi.org → Account Settings → Publishing → Add Publisher, informando o repo GitHub e o environment `pypi`.

- [ ] **Step 3: Commitar**

```bash
git add .github/workflows/publish.yml
git commit -m "ci: GitHub Actions — publish to PyPI on tag v*"
```

---

## Task 8: Publicar v0.1.0

**Files:** nenhum criado

- [ ] **Step 1: Validar no TestPyPI primeiro**

```bash
uv build
uv publish --index-url https://test.pypi.org/legacy/ --token $TESTPYPI_TOKEN
```

- [ ] **Step 2: Instalar do TestPyPI e verificar**

```bash
pip install --index-url https://test.pypi.org/simple/ hybris-test-skills
hybris version
hybris install junit
```

- [ ] **Step 3: Se tudo ok, criar tag e publicar no PyPI real**

```bash
git tag v0.1.0
git push origin v0.1.0
```

O GitHub Actions detecta a tag e publica automaticamente via Trusted Publisher.

- [ ] **Step 4: Verificar publicação**

```bash
pip install hybris-test-skills
hybris version
```

Esperado: `hybris-test-skills 0.1.0`

---

## Self-Review do Plano

**Cobertura do spec:**
- ✅ Seção 2 (scripts dentro de skills) — Task 1
- ✅ Seção 3 (fluxo `uv tool install` + `hybris install`) — Tasks 6-8
- ✅ Seção 4.2 (SKILL.md paths atualizados) — Task 3
- ✅ Seção 5 (o que cada install copia) — Task 5 (testes verificam)
- ✅ Seção 6 (CLI commands) — Task 5
- ✅ Seção 7 (pyproject.toml com Hatchling) — Task 4
- ✅ Seção 8 (uv build + tag + CI) — Task 7-8
- ✅ Seção 9 Fase 1 completa

**Ajuste vs spec:** `pyproject.toml` fica na raiz do repo em vez de `packages/hybris-test-skills/` — necessário para que o `force-include` do Hatchling consiga referenciar `skills/` e `.axetrules/` com caminhos relativos simples. O resultado final para o usuário é idêntico.

**Detalhe sobre os testes da Task 5:** os testes que copiam arquivos reais (`TestInstallJunit.test_copia_*`) dependem de `_data/` existir em `src/hybris_test_skills/_data/`. Isso só acontece após `uv pip install -e .`. Para rodar os testes sem instalar, esses testes serão pulados ou retornarão erro de diretório. Solução: rodar `uv pip install -e .` antes de `pytest` no CI. Adicionar ao workflow se necessário.
