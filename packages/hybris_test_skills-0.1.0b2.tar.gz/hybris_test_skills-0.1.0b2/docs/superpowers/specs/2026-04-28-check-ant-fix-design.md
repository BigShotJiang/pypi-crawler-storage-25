# Design: Correção do check_ant() no check_environment.py

**Data:** 2026-04-28
**Escopo:** `skills/hybris-base/scripts/check_environment.py` — função `check_ant()`

---

## Contexto e Bugs

Dois bugs independentes na detecção do Ant:

### Bug 1 — Source com CWD errado (aXet Plugin)

`setantenv.sh` usa caminhos **relativos ao diretório de trabalho no momento do source** (não ao diretório do próprio script). O `check_environment.py` sourcia assim:

```bash
bash -c ". /caminho/absoluto/setantenv.sh && ant -version"
```

O CWD no momento do source é o diretório do processo Python (ex: `arauco/`). Dentro de `setantenv.sh`, `ANT_HOME` é definido como `$PWD/apache-ant` — que aponta para `arauco/apache-ant`, inexistente. O `apache-ant` real está em `arauco/hybris/bin/platform/apache-ant/`.

**Comprovação:** sourcing de `arauco/` falha; sourcing de `arauco/hybris/bin/platform/` funciona.

### Bug 2 — Path relativo ao CWD (run independente)

O script procura `setantenv.sh` em `$HYBRIS_HOME/bin/platform/setantenv.sh` ou, se `HYBRIS_HOME` não estiver definida, em `hybris/bin/platform/setantenv.sh` relativo ao CWD. Rodado de fora da raiz do projeto, não encontra o arquivo.

---

## Design da Correção

Apenas `check_environment.py` é alterado. Duas mudanças cirúrgicas em `check_ant()`.

### 1. Helper `_find_setantenv()` — busca upward

```python
def _find_setantenv() -> Path | None:
    hybris_home = os.environ.get("HYBRIS_HOME")
    if hybris_home:
        p = Path(hybris_home) / "bin" / "platform" / "setantenv.sh"
        return p if p.exists() else None
    current = Path.cwd()
    for _ in range(6):
        candidate = current / "hybris" / "bin" / "platform" / "setantenv.sh"
        if candidate.exists():
            return candidate
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None
```

- Prioridade: `HYBRIS_HOME` env var → busca upward a partir do CWD (até 5 níveis)
- Resolve Bug 2: encontra `setantenv.sh` rodado de qualquer subdiretório do projeto

### 2. Source a partir do diretório correto — resolve Bug 1

```python
platform_dir = setantenv.parent
result = subprocess.run(
    ["bash", "-c",
     f"cd {shlex.quote(str(platform_dir))} && . ./setantenv.sh && ant -version"],
    capture_output=True, text=True, timeout=30
)
```

- `cd platform_dir` garante que `$PWD` seja `hybris/bin/platform/` no momento do source
- Assim `ANT_HOME = $PWD/apache-ant` resolve para `hybris/bin/platform/apache-ant`, que existe

### 3. Mensagem de erro melhorada

```python
combined = (result.stderr + result.stdout).strip()
relevant = next(
    (l for l in combined.splitlines() if "ant" in l.lower()),
    combined[:120]
)
return False, f"setantenv.sh encontrado mas ant falhou: {relevant[:120]}"
```

- Varre stdout + stderr combinados pela linha mais relevante (contém "ant")
- Evita mostrar apenas os primeiros 100 chars do stderr (que eram erros de chmod, não a causa real)

---

## Comportamento Esperado Após a Correção

| Cenário | Antes | Depois |
|---|---|---|
| aXet Plugin (CWD = arauco/) | `setantenv.sh encontrado mas ant falhou: chmod...` | `[OK] ant via setantenv.sh (Apache Ant 1.10.15)` |
| Run independente (CWD fora do projeto) | `setantenv.sh não encontrado` | `setantenv.sh não encontrado` (inalterado — correto) |
| Run de subdir do projeto | `setantenv.sh não encontrado` | `[OK] ant via setantenv.sh (...)` |

---

## Escopo

- **Arquivo alterado:** `skills/hybris-base/scripts/check_environment.py`
- **Sem alterações em:** pyproject.toml, CLI, skills de junit, axetrules
- **Testes:** atualizar suite existente para cobrir os dois cenários de bug
