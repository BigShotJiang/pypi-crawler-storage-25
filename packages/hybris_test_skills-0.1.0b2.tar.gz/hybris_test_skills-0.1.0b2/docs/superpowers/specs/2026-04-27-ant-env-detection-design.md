# Design: Detecção Automática do Ambiente Ant (setantenv.sh)

**Data:** 2026-04-27
**Escopo:** skill hybris-junit — check_environment.py e run-junit.sh

## Problema

O SAP Commerce instala o Apache Ant em `{HYBRIS_HOME}/bin/platform/apache-ant/bin/`, fora do PATH do sistema. Para usar `ant`, o desenvolvedor precisa executar `. setantenv.sh` na sessão atual do terminal. Sem isso:

- `check_environment.py` reporta `ant not found` e bloqueia o fluxo (guardrail)
- `run-junit.sh` falha com `command not found` ao invocar `ant`

## Solução

Sourcing automático de `setantenv.sh` nos dois pontos que precisam do ant, usando o mecanismo oficial do hybris. Nenhum arquivo novo é criado.

## Fluxo de resolução do ant

```
1. ant está no PATH?         → OK (dev já fez source; caminho rápido)
2. Não → localiza setantenv.sh em $HYBRIS_HOME/bin/platform/
          (HYBRIS_HOME default = "hybris" relativo ao cwd)
3. setantenv.sh existe?      → source + usa ant
4. Não existe                → erro claro pedindo HYBRIS_HOME correto
```

## Mudanças

### 1. `skills/hybris-base/scripts/check_environment.py`

`check_ant()` ganha dois estágios. Imports adicionados: `os`, `pathlib.Path`.

```python
def check_ant():
    # Caminho rápido: ant já está no PATH
    if shutil.which("ant") is not None:
        return True, "ant encontrado no PATH"

    # Caminho hybris: tenta via setantenv.sh
    hybris_home = os.environ.get("HYBRIS_HOME", "hybris")
    platform_dir = Path(hybris_home) / "bin" / "platform"
    setantenv = platform_dir / "setantenv.sh"

    if not setantenv.exists():
        return False, (
            f"ant not found e {setantenv} não encontrado — "
            "defina HYBRIS_HOME ou rode a partir da raiz do projeto"
        )

    try:
        result = subprocess.run(
            ["bash", "-c", f". '{setantenv}' && ant -version"],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            version_line = result.stdout.split("\n")[0].strip()
            return True, f"ant via setantenv.sh ({version_line})"
        return False, f"setantenv.sh encontrado mas ant falhou: {result.stderr.strip()[:100]}"
    except subprocess.TimeoutExpired:
        return False, "ant timeout — verifique instalação do SAP Commerce"
```

**Timeout:** 30s (sobe de 10s para acomodar o sourcing do setantenv.sh).

### 2. `skills/hybris-junit/scripts/run-junit.sh`

Logo após a definição de `PLATFORM_DIR`, antes de qualquer uso do `ant`:

```bash
# Garante que ant está no PATH via setantenv.sh do hybris
SETANTENV="${PLATFORM_DIR}/setantenv.sh"
if [ -f "$SETANTENV" ]; then
    set +u  # setantenv.sh pode referenciar variáveis não definidas
    # shellcheck source=/dev/null
    . "$SETANTENV" > /dev/null 2>&1
    set -u
fi
```

**`set +u` / `set -u`:** O script usa `set -uo pipefail`. O `setantenv.sh` do hybris frequentemente acessa variáveis opcionais, o que quebraria com `set -u` ativo. A proteção é desligada temporariamente apenas durante o sourcing — todas as variáveis do `run-junit.sh` já estão definidas antes desse ponto.

**`> /dev/null 2>&1`:** Suprime output do setantenv.sh para não poluir o JSON de saída.

## O que não muda

- Timeout dos demais checks em `check_environment.py` (permanecem em 10s)
- Lógica de HYBRIS_HOME em `run-junit.sh` (já usa `"${HYBRIS_HOME:-hybris}"`)
- Estrutura de diretórios, CLI, pyproject.toml

## Impactos colaterais resolvidos

| Cenário | Antes | Depois |
|---|---|---|
| Terminal sem `source setantenv.sh` | check falha, bloqueia fluxo | check passa via setantenv.sh |
| HYBRIS_HOME não definido | check falha genérico | fallback para `hybris/`, erro claro se não existir |
| ant no PATH (dev avançado) | OK | OK (caminho rápido, sem overhead) |
| run-junit.sh sem PATH do ant | falha com command not found | sourcing automático resolve antes |
