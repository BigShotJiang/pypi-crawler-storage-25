# Design: Publicação no PyPI — release JUnit-only (v0.1.0b1)

## Objetivo

Preparar e publicar o pacote `hybris-test-skills` no Python Package Index com apenas o módulo JUnit disponível. Cypress permanece bloqueado via CLI com mensagem "coming soon".

---

## Escopo de mudanças

### 1. `pyproject.toml`

- Versão: `0.1.0` → `0.1.0b1`
- Campo `description`: remover referência ao "Claude Code"; usar `"SAP Commerce test generation skills for aXet Plugin"`
- Adicionar `authors`: `[{name = "Igor Chagas"}]`
- Adicionar `classifiers`:
  - `Development Status :: 4 - Beta`
  - `Programming Language :: Python :: 3`
  - `Topic :: Software Development :: Testing`
- Remover do `[tool.hatch.build.targets.wheel.force-include]`:
  - `"skills/spartacus-cypress"`
  - `"skills/accelerator-jsp-cypress"`
- Manter: `hybris-base`, `hybris-junit`, `.axetrules`
- Sem `[project.urls]` — repositório é privado

### 2. `README.md`

Reescrita completa em português. Estrutura:

```
# hybris-test-skills
Descrição curta (skills JUnit para SAP Commerce, consumidas pelo aXet Plugin no VSCode).

## Instalação
pip install hybris-test-skills
uv add hybris-test-skills

## Uso
hybris install junit   # copia skills + .axetrules no workspace atual
hybris list            # lista módulos disponíveis
hybris version         # versão instalada

## Pré-requisitos
Tabela: Python 3.10+, Java 17+, Ant, Bash 4+
(Node.js não é requisito para JUnit)

## Módulos disponíveis
- junit  — geração de testes JUnit (@UnitTest / @IntegrationTest)
- cypress — Cypress E2E [em breve]

## Integração com aXet Plugin
Após `hybris install junit`, abra o aXet Plugin no VSCode e use `/junit <Classe>`.
Link para docs/installation.md para instruções detalhadas por plataforma.

## Licença
MIT — inclui material adaptado de Emenowicz/sap-commerce-skill (MIT License).
```

### 3. `docs/installation.md`

- Remover seção "Dependências Python" com `pip install -r requirements.txt`
- Adicionar seção "Instalação do pacote" com `pip install hybris-test-skills` e `uv add hybris-test-skills`
- Adicionar próximo passo: `hybris install junit` após instalação do pacote
- Remover Node.js da tabela de pré-requisitos
- Corrigir linha 137: `"ao iniciar uma sessão no Claude Code"` → `"ao abrir o aXet Plugin no VSCode"`
- Corrigir menção ao `terminal do Claude Code` → `aXet Plugin`

### 4. `docs/usage-arch.md`

- Linha 17: `"No aXet/Claude Code"` → `"No aXet Plugin"`
- Sem outras alterações de conteúdo (arquivo documenta Cypress, que é coming soon)

---

## Configuração do Trusted Publisher (passo manual no PyPI)

Antes do primeiro push de tag, o mantenedor deve configurar o Trusted Publisher em pypi.org:

1. Fazer login em pypi.org
2. Ir em **Account Settings → Publishing → Add a new pending publisher**
3. Preencher:
   - **PyPI project name:** `hybris-test-skills`
   - **Owner (GitHub username/org):** `igorchagas`
   - **Repository name:** `hybris-test-skills`
   - **Workflow filename:** `publish.yml`
   - **Environment name:** `pypi`
4. Salvar

O GitHub Actions já está configurado corretamente para usar Trusted Publisher (`id-token: write`, `environment: pypi`).

---

## Processo de release

Após todas as mudanças commitadas:

```bash
git tag v0.1.0b1
git push origin v0.1.0b1
```

O workflow `.github/workflows/publish.yml` dispara automaticamente e publica o wheel no PyPI.

---

## Fora do escopo

- Docs internos (`docs/PRD...`, `docs/superpowers/...`) — não alterados
- CLI (`src/hybris_test_skills/cli.py`) — sem mudanças; Cypress já bloqueado em runtime
- Testes — sem mudanças; a remoção dos Cypress do wheel não afeta os testes existentes
- `scripts/run-cypress.sh` — não está no `force-include`, já fora do wheel
