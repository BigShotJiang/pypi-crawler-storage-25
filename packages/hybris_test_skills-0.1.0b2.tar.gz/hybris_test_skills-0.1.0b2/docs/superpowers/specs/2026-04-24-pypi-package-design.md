# Design — hybris-test-skills PyPI Package

**Data:** 2026-04-24
**Autor:** Igor Chagas (Funk)
**Status:** Aprovado

---

## 1. Objetivo

Distribuir as skills do repositório `hybris-test-skills` como um pacote Python no PyPI, permitindo que times SAP Commerce instalem os skills via `pip install` e escolham quais módulos ativar no workspace via CLI.

Entrega em duas fases:
- **Fase 1 (MVP):** módulo JUnit — skills de geração de testes unitários para desenvolvedores
- **Fase 2:** módulo Cypress — skills E2E para arquitetos/analistas

---

## 2. Decisões arquiteturais

| Decisão | Escolha | Motivo |
|---|---|---|
| Número de pacotes PyPI | 1 (`hybris-test-skills`) | Dev solo, overhead mínimo, sem extras_require |
| Seleção de módulo | CLI no workspace (`hybris install junit`) | UX mais simples que extras PyPI; decisão fica no projeto, não no pip |
| Scripts | Dentro de cada skill (`skills/<nome>/scripts/`) | Coesão — cada skill é autossuficiente |
| Versionamento | Tag única (`v1.0.0`) para o pacote inteiro | Monorepo, dev solo, sem necessidade de versões independentes por módulo |
| Phased delivery | Cypress bundled mas não exposto até Fase 2 | Permite publicar JUnit agora sem bloquear Cypress futuro |

---

## 3. Fluxo de uso final

```bash
# Instalação global como ferramenta (uma vez, ambiente isolado automático)
uv tool install hybris-test-skills

# Em cada projeto, o dev escolhe o que ativar
cd meu-projeto-hybris
hybris install junit      # copia JUnit + base para o workspace
hybris install cypress    # copia Cypress para o workspace (Fase 2)
hybris install all        # copia tudo (Fase 2)
```

---

## 4. Estrutura do repositório

### 4.1 Adições (novos arquivos)

```
packages/hybris-test-skills/
├── pyproject.toml
└── src/hybris_test_skills/
    ├── __init__.py
    └── cli.py
```

Não há diretório `data/` separado. O `pyproject.toml` configura o Hatchling para incluir `skills/` e `.axetrules/` diretamente do root do repo como package data — a pasta `skills/` continua sendo a fonte da verdade, sem duplicação.

### 4.2 Mudanças nos arquivos existentes

**Scripts movidos:**

| De (atual) | Para |
|---|---|
| `scripts/parse-java-class.py` | `skills/hybris-junit/scripts/` |
| `scripts/parse-items-xml.py` | `skills/hybris-junit/scripts/` |
| `scripts/run-junit.sh` | `skills/hybris-junit/scripts/` |
| `scripts/check-environment.py` | `skills/hybris-base/scripts/` |
| `scripts/requirements.txt` | `skills/hybris-base/scripts/` |
| `scripts/run-cypress.sh` | `skills/spartacus-cypress/scripts/` e `skills/accelerator-jsp-cypress/scripts/` |

**SKILL.md com caminhos atualizados:** ~6 referências a `scripts/` precisam apontar para os novos caminhos dentro de cada skill.

### 4.3 O que não muda

- `.axetrules/` — estrutura e conteúdo intactos
- `skills/hybris-base/`, `skills/hybris-junit/`, `skills/spartacus-cypress/`, `skills/accelerator-jsp-cypress/` — estrutura de diretórios intacta, só scripts se movem
- `docs/`

---

## 5. O que cada `hybris install` copia para o workspace

### `hybris install junit`

```
.axetrules/
  commands.md
  hybris-tests.md
  hybris-tests-dev.md
skills/
  hybris-base/          (SKILL.md, references/, assets/, scripts/)
  hybris-junit/         (SKILL.md, examples/, references/, scripts/)
```

### `hybris install cypress` (Fase 2)

```
.axetrules/
  commands.md
  hybris-tests.md
  hybris-tests-arch.md
skills/
  hybris-base/
  spartacus-cypress/    (SKILL.md, examples/, references/, scripts/)
  accelerator-jsp-cypress/ (SKILL.md, examples/, references/, scripts/)
```

### `hybris install all` (Fase 2)

União dos dois acima. `.axetrules/` com os 4 arquivos.

---

## 6. CLI (`cli.py`)

**Comandos:**

```
hybris install <modulo>   — copia arquivos do módulo para o CWD
hybris list               — lista módulos disponíveis e status no CWD
hybris version            — exibe versão instalada
```

**Comportamento de `hybris install`:**

1. Funciona em qualquer diretório — não exige que seja um projeto Hybris existente
2. Se arquivos já existem no destino, pergunta antes de sobrescrever
3. Copia os arquivos preservando estrutura de pastas
4. Exibe resumo: quantos arquivos copiados, caminhos criados
5. Em Fase 1, `hybris install cypress` e `hybris install all` exibem: `"Cypress module not available in this version. Coming soon."`

---

## 7. `pyproject.toml` (estrutura essencial)

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "hybris-test-skills"
version = "0.1.0"
description = "SAP Commerce test generation skills for aXet / Claude Code"
requires-python = ">=3.10"
dependencies = []

[project.scripts]
hybris = "hybris_test_skills.cli:main"

[tool.hatch.build.targets.wheel]
packages = ["src/hybris_test_skills"]

[tool.hatch.build]
include = [
  "src/hybris_test_skills/**",
  "skills/hybris-base/**",
  "skills/hybris-junit/**",
  "skills/spartacus-cypress/**",
  "skills/accelerator-jsp-cypress/**",
  ".axetrules/**",
]
```

---

## 8. Versionamento e publicação

```bash
# Desenvolvimento normal
git commit -m "feat: ..."

# Build local para validar
uv build --directory packages/hybris-test-skills/

# Publicar nova versão
# 1. Bumpar version em pyproject.toml
# 2. Tag e push
git tag v0.1.0 && git push --tags

# GitHub Actions (a criar) detecta tag v*, roda uv build e publica no PyPI
# via trusted publisher (sem token hardcoded)
```

**Convenção de versão:**
- `0.x.y` — pré-release, Fase 1 (JUnit only)
- `1.0.0` — release completo com Fase 2 (JUnit + Cypress)

---

## 9. Plano de fases

### Fase 1 — JUnit (agora)

1. Mover scripts para dentro das skills
2. Atualizar referências de caminho nos SKILL.md
3. Criar `packages/hybris-test-skills/` com `pyproject.toml` e `cli.py`
4. Bundlar `base/` + `junit/` + `.axetrules/` dev
5. Testar localmente com `uv pip install -e packages/hybris-test-skills/`
6. Publicar `v0.1.0` no TestPyPI → validar → publicar no PyPI

### Fase 2 — Cypress (futuro)

1. Adicionar `cypress/` ao bundle em `data/`
2. Habilitar `hybris install cypress` e `hybris install all` na CLI
3. Bundlar `.axetrules/` arch
4. Publicar `v1.0.0`
