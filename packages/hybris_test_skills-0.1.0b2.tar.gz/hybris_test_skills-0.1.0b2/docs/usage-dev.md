# Guia de uso — Dev local (JUnit)

## Pré-requisito

Execute uma vez para validar o ambiente:
```bash
python3 skills/hybris-base/scripts/check_environment.py
```

Se retornar erros, siga `docs/installation.md`.

## Como gerar um teste JUnit

### Opção 1 — Comando direto (recomendado)

No aXet, digite:
```
/junit DefaultProductPopulator
```

O aXet irá:
1. Localizar `DefaultProductPopulator.java` no workspace
2. Detectar o tipo (`populator`) e carregar os exemplos corretos
3. Verificar se há atributos `localized` no itemtype correspondente
4. Apresentar um plano com cenários e mocks — **aguarde e confirme**
5. Gerar o arquivo de teste em `src/test/java/...`
6. Executar `run-junit.sh` para validar

### Opção 2 — Linguagem natural

```
Gere um teste JUnit para DefaultProductPopulator.java
```

O router de linguagem natural detecta o contexto dev automaticamente.

## Confirmação do plano (obrigatória)

O aXet sempre apresenta um plano antes de gerar. Exemplo do que você verá:

```
Vou gerar DefaultProductPopulatorTest.java com os seguintes cenários:

Tipo detectado: populator / @UnitTest
Dependências mockadas: CommonI18NService, MediaContainerService
Cenários:
1. shouldMapCodeWhenSourceHasCode — verifica setCode() chamado com código correto
2. shouldMapLocalizedNameUsingCurrentLocale — verifica getName(Locale.ENGLISH) e setName()
3. shouldSkipImageWhenThumbnailsIsEmpty — verifica mainImage null quando sem thumbnails
4. shouldThrowConversionExceptionWhenSourceIsNull — null safety
5. shouldThrowConversionExceptionWhenTargetIsNull — null safety

Atributos localized detectados: name (localized:java.lang.String)
Arquivo de teste: src/test/java/com/ntt/myextension/populators/DefaultProductPopulatorTest.java

Confirma?
```

Responda `sim` ou `confirma` para gerar. Você pode pedir ajustes antes de confirmar.

## Passando changelog (opcional)

Se você alterou a classe, informe o que mudou para estreitar o escopo:

```
/junit DefaultProductPopulator
Changelog: adicionei campo `eligible` (Boolean, optional) no itemtype Product.
O populate() agora mapeia eligible para ProductData.setEligible().
```

O aXet focará nos cenários relacionados ao campo novo e não regerará testes que não foram afetados.

## Onde o teste é gerado

O arquivo de teste é criado em:
```
<sua-extensao>/src/test/java/<mesmo-pacote-da-classe-fonte>/DefaultProductPopulatorTest.java
```

## Como executar manualmente

```bash
bash skills/hybris-junit/scripts/run-junit.sh com.ntt.myextension.populators.DefaultProductPopulatorTest
```

Output esperado (JSON):
```json
{
  "status": "PASS",
  "testClass": "com.ntt.myextension.populators.DefaultProductPopulatorTest",
  "testsRun": 5,
  "testsPassed": 5,
  "testsFailed": 0,
  "failures": [],
  "durationMs": 3421
}
```

## Tipos de classe suportados

| Tipo | Anotação | Exemplo de comando |
|---|---|---|
| Populator | @UnitTest | `/junit DefaultProductPopulator` |
| Converter | @UnitTest | `/junit DefaultPriceConverter` |
| DAO | @IntegrationTest | `/junit DefaultOrderDAO` |
| Facade | @UnitTest | `/junit DefaultProductFacade` |
| Strategy | @UnitTest | `/junit DefaultDiscountStrategy` |
| Interceptor | @UnitTest | `/junit ProductCodeValidationInterceptor` |

## Restrições

- **Não peça ao aXet para gerar testes Cypress** neste contexto — use `/cypress` para isso.
- **O aXet não edita código de produção** — apenas gera o arquivo de teste.
- **Classe com mais de 500 linhas**: o aXet pedirá que você refatore antes de gerar.
- **Atributos localized**: o aXet detecta automaticamente e usa `Locale.ENGLISH` nos mocks. Se o teste falhar com `IllegalStateException: No LocaleProvider`, veja `skills/hybris-junit/references/localized-attributes.md`.

## Solução de problemas comuns

| Erro | Causa | Fix |
|---|---|---|
| `IllegalStateException: No LocaleProvider` | Atributo localized sem mock de locale | Ver `references/localized-attributes.md` |
| `NullPointerException` no mock | `given()` não configurado para o método chamado | Adicionar `given(mock.method()).willReturn(value)` |
| `BUILD FAILED` no ant | Compilação falhou antes dos testes | Verificar imports e classpath da extensão |
| Teste gera mas não compila | Import de classe SAP Commerce errado | Verificar se dependência está em `extensioninfo.xml` |
