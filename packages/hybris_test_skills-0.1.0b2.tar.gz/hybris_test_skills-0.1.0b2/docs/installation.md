# Instalação — hybris-test-skills

## Pré-requisitos

| Ferramenta | Versão mínima | Finalidade |
|------------|---------------|------------|
| Python     | 3.10+         | Execução dos scripts de skill e validação de ambiente |
| pip        | 22+           | Instalação das dependências Python |
| Bash       | 4+            | Execução dos scripts shell das skills |
| Java       | 17+           | Compilação e testes do SAP Commerce (Hybris) |
| Ant        | qualquer      | Build do SAP Commerce (instalado via setup padrão) |

---

## Instalação por sistema operacional

### Linux (Ubuntu/Debian)

```bash
# Python 3.10+ e pip
sudo apt update
sudo apt install -y python3 python3-pip

# Confirmar versão
python3 --version
pip3 --version

# Bash 4+ (geralmente já presente)
bash --version

# Java 17
sudo apt install -y openjdk-17-jdk
java -version

# Ant
sudo apt install -y ant
ant -version
```

### macOS

```bash
# Homebrew (se não tiver)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Python 3.10+
brew install python@3.10
python3 --version
pip3 --version

# Bash 4+ (macOS vem com Bash 3.x por padrão)
brew install bash
# Adicionar ao /etc/shells e setar como shell padrão (opcional):
echo "$(brew --prefix)/bin/bash" | sudo tee -a /etc/shells
bash --version

# Java 17
brew install openjdk@17
sudo ln -sfn $(brew --prefix)/opt/openjdk@17/libexec/openjdk.jdk /Library/Java/JavaVirtualMachines/openjdk-17.jdk
java -version

# Ant
brew install ant
ant -version
```

### Windows (WSL2)

```powershell
# Instalar WSL2 (PowerShell como Administrador)
wsl --install
```

Dentro do terminal WSL2 (Ubuntu), seguir os mesmos passos da seção **Linux (Ubuntu/Debian)** acima.

> **Nota:** Ant e Java geralmente são providos pelo setup padrão do SAP Commerce na empresa.
> Verifique com o time de infraestrutura antes de instalar manualmente.

---

## Instalação do pacote

```bash
pip install hybris-test-skills
```

Ou com `uv`:

```bash
uv add hybris-test-skills
```

Após instalar, execute na raiz do projeto SAP Commerce:

```bash
hybris install junit
```

Isso copia os scripts de skill e as regras `.axetrules/` no diretório atual.

---

## Verificação do ambiente

```bash
python3 skills/hybris-base/scripts/check_environment.py
```

Saída esperada (ambiente OK):

```
hybris-test-skills — verificando ambiente...

  [OK]      Python 3.10+: Python 3.10.x
  [OK]      pip 22+: pip 22.x
  [OK]      Bash 4+: bash 5.x
  [OK]      Node.js 18+: node v18.x
  [OK]      Java 17+: java 17.x
  [OK]      Ant: ant encontrado

OK — ambiente pronto para hybris-test-skills.
```

> **Nota:** O script ainda verifica Node.js — pode aparecer como `[WARN]` se não instalado, sem impacto no módulo JUnit.

Se houver falhas, o script lista o que está faltando e aponta para este arquivo.

---

## Integração com aXet Plugin

A pasta `.axetrules/` deve estar na raiz do projeto SAP Commerce (mesmo nível que `hybrisconfig/` ou `custom/`). O aXet Plugin detecta e carrega as regras automaticamente ao abrir o projeto no VSCode — nenhuma configuração adicional é necessária. As skills ficam disponíveis via comandos `/` no aXet Plugin.

---

## Solução de problemas

### Python version too old

```bash
# Ubuntu: instalar versão específica via deadsnakes PPA
sudo add-apt-repository ppa:deadsnakes/ppa
sudo apt update
sudo apt install -y python3.10
python3.10 --version
```

### pip muito antigo

```bash
pip install --upgrade pip
pip --version  # deve ser 22+
```

### Bash 3.x no macOS

```bash
brew install bash
# Verificar versão do bash recém-instalado
$(brew --prefix)/bin/bash --version
```

### Java não encontrado / JAVA_HOME não configurado

```bash
# Localizar instalação
which java || update-alternatives --list java

# Configurar JAVA_HOME (adicionar ao ~/.bashrc ou ~/.zshrc)
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java))))
export PATH="$JAVA_HOME/bin:$PATH"
source ~/.bashrc
java -version
```

### Ant não encontrado

```bash
# Linux
sudo apt install -y ant

# macOS
brew install ant

# Verificar
ant -version
```
