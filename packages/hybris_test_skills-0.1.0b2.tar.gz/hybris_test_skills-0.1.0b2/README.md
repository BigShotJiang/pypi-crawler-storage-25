# hybris-test-skills

Skills de geração de testes JUnit para projetos SAP Commerce (Hybris), consumidas pelo **aXet Plugin** no VSCode.

## Instalação

```bash
pip install hybris-test-skills
```

Ou com `uv`:

```bash
uv add hybris-test-skills
```

## Uso

```bash
hybris install junit   # copia skills e .axetrules no diretório atual
hybris list            # lista módulos disponíveis
hybris version         # exibe a versão instalada
```

Execute `hybris install junit` na raiz do projeto SAP Commerce (mesmo nível que `hybrisconfig/` ou `custom/`).

## Pré-requisitos

| Ferramenta | Versão mínima | Finalidade |
|------------|---------------|------------|
| Python     | 3.10+         | Execução dos scripts de skill |
| Java       | 17+           | Compilação e testes do SAP Commerce |
| Ant        | qualquer      | Build do SAP Commerce |
| Bash       | 4+            | Execução dos scripts shell |

> Ant e Java geralmente são providos pelo setup padrão do SAP Commerce. Veja [docs/installation.md](docs/installation.md) para instruções detalhadas por plataforma.

## Módulos disponíveis

| Módulo    | Descrição |
|-----------|-----------|
| `junit`   | Geração de testes JUnit (`@UnitTest` / `@IntegrationTest`) |
| `cypress` | Testes Cypress E2E — **em breve** |

## Integração com aXet Plugin

Após executar `hybris install junit`, abra o aXet Plugin no VSCode e use `/junit <NomeDaClasse>`.

## Licença

MIT — inclui material adaptado de [Emenowicz/sap-commerce-skill](https://github.com/Emenowicz/sap-commerce-skill) (MIT License).
