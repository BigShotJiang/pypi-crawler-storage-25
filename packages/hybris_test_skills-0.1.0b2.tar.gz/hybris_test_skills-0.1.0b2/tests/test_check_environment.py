"""
Testes do check-environment.py.

Como o script valida o ambiente do desenvolvedor via chamadas de sistema,
os testes usam unittest.mock para isolar subprocess e shutil.which.
"""
import sys
import os
import shlex
import subprocess
from pathlib import Path
from unittest.mock import patch, MagicMock
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "skills" / "hybris-base" / "scripts"))
import check_environment as ce


# ---------------------------------------------------------------------------
# check_python_version
# ---------------------------------------------------------------------------

class TestCheckPythonVersion:
    def test_passes_with_3_10(self):
        with patch.object(sys, "version_info", (3, 10, 0, "final", 0)):
            ok, msg = ce.check_python_version()
        assert ok is True
        assert "3.10" in msg

    def test_passes_with_3_12(self):
        with patch.object(sys, "version_info", (3, 12, 1, "final", 0)):
            ok, msg = ce.check_python_version()
        assert ok is True

    def test_fails_with_3_9(self):
        with patch.object(sys, "version_info", (3, 9, 0, "final", 0)):
            ok, msg = ce.check_python_version()
        assert ok is False
        assert "3.10+" in msg

    def test_fails_with_2_7(self):
        with patch.object(sys, "version_info", (2, 7, 18, "final", 0)):
            ok, msg = ce.check_python_version()
        assert ok is False


# ---------------------------------------------------------------------------
# check_pip
# ---------------------------------------------------------------------------

class TestCheckPip:
    def test_passes_with_pip_22(self):
        mock_result = MagicMock()
        mock_result.stdout = "pip 22.3.1 from /usr/lib/python3/dist-packages/pip (python 3.10)\n"
        with patch("shutil.which", return_value="/usr/bin/pip"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_pip()
        assert ok is True
        assert "22" in msg

    def test_passes_with_pip_24(self):
        mock_result = MagicMock()
        mock_result.stdout = "pip 24.0 from /usr/local/lib/python3.12 (python 3.12)\n"
        with patch("shutil.which", return_value="/usr/local/bin/pip"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_pip()
        assert ok is True

    def test_fails_when_pip_not_in_path(self):
        with patch("shutil.which", return_value=None):
            ok, msg = ce.check_pip()
        assert ok is False
        assert "not found" in msg

    def test_fails_with_pip_21(self):
        mock_result = MagicMock()
        mock_result.stdout = "pip 21.3.1 from /usr/lib/python3/dist-packages/pip (python 3.9)\n"
        with patch("shutil.which", return_value="/usr/bin/pip"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_pip()
        assert ok is False
        assert "22+" in msg

    def test_fails_with_unexpected_pip_output(self):
        mock_result = MagicMock()
        mock_result.stdout = "unexpected\n"  # sem versão reconhecível
        with patch("shutil.which", return_value="/usr/bin/pip"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_pip()
        assert ok is False


# ---------------------------------------------------------------------------
# check_bash
# ---------------------------------------------------------------------------

class TestCheckBash:
    def test_passes_with_bash_5(self):
        mock_result = MagicMock()
        mock_result.stdout = "GNU bash, version 5.1.16(1)-release (x86_64-pc-linux-gnu)\n"
        with patch("subprocess.run", return_value=mock_result):
            ok, msg = ce.check_bash()
        assert ok is True
        assert "5" in msg

    def test_fails_with_bash_3(self):
        mock_result = MagicMock()
        mock_result.stdout = "GNU bash, version 3.2.57(1)-release (x86_64-apple-darwin20)\n"
        with patch("subprocess.run", return_value=mock_result):
            ok, msg = ce.check_bash()
        assert ok is False
        assert "4+" in msg

    def test_fails_when_bash_not_found(self):
        with patch("subprocess.run", side_effect=FileNotFoundError):
            ok, msg = ce.check_bash()
        assert ok is False
        assert "not found" in msg

    def test_fails_with_unrecognized_bash_output(self):
        mock_result = MagicMock()
        mock_result.stdout = "some unexpected bash output\n"
        with patch("subprocess.run", return_value=mock_result):
            ok, msg = ce.check_bash()
        assert ok is False


# ---------------------------------------------------------------------------
# check_node
# ---------------------------------------------------------------------------

class TestCheckNode:
    def test_passes_with_node_18(self):
        mock_result = MagicMock()
        mock_result.stdout = "v18.17.0\n"
        with patch("shutil.which", return_value="/usr/bin/node"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_node()
        assert ok is True
        assert "18" in msg

    def test_passes_with_node_20(self):
        mock_result = MagicMock()
        mock_result.stdout = "v20.11.0\n"
        with patch("shutil.which", return_value="/usr/bin/node"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_node()
        assert ok is True

    def test_fails_with_node_16(self):
        mock_result = MagicMock()
        mock_result.stdout = "v16.20.0\n"
        with patch("shutil.which", return_value="/usr/bin/node"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_node()
        assert ok is False
        assert "18+" in msg

    def test_fails_when_node_not_found(self):
        with patch("shutil.which", return_value=None):
            ok, msg = ce.check_node()
        assert ok is False
        assert "not found" in msg


# ---------------------------------------------------------------------------
# check_java
# ---------------------------------------------------------------------------

class TestCheckJava:
    def test_passes_with_java_17(self):
        mock_result = MagicMock()
        mock_result.stderr = 'openjdk version "17.0.8" 2023-07-18\n'
        with patch("shutil.which", return_value="/usr/bin/java"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_java()
        assert ok is True
        assert "17" in msg

    def test_passes_with_java_21(self):
        mock_result = MagicMock()
        mock_result.stderr = 'openjdk version "21.0.1" 2023-10-17\n'
        with patch("shutil.which", return_value="/usr/bin/java"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_java()
        assert ok is True

    def test_fails_with_java_11(self):
        mock_result = MagicMock()
        mock_result.stderr = 'openjdk version "11.0.20" 2023-07-18\n'
        with patch("shutil.which", return_value="/usr/bin/java"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_java()
        assert ok is False
        assert "17+" in msg

    def test_fails_when_java_not_found(self):
        with patch("shutil.which", return_value=None):
            ok, msg = ce.check_java()
        assert ok is False
        assert "not found" in msg

    def test_fails_with_unparseable_java_version(self):
        mock_result = MagicMock()
        mock_result.stderr = "java version without quotes\n"  # sem aspas
        with patch("shutil.which", return_value="/usr/bin/java"):
            with patch("subprocess.run", return_value=mock_result):
                ok, msg = ce.check_java()
        assert ok is False


# ---------------------------------------------------------------------------
# check_ant
# ---------------------------------------------------------------------------

class TestCheckAnt:
    def test_passes_when_ant_in_path(self):
        with patch("shutil.which", return_value="/usr/bin/ant"):
            ok, msg = ce.check_ant()
        assert ok is True
        assert "ant" in msg.lower()

    def test_fails_when_setantenv_not_found(self):
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=None):
                ok, msg = ce.check_ant()
        assert ok is False
        assert "not found" in msg
        assert "HYBRIS_HOME" in msg

    def test_passes_via_setantenv_when_ant_not_in_path(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Apache Ant(TM) version 1.10.15\nant home: /path\n"
        fake_setantenv = Path("/fake/hybris/bin/platform/setantenv.sh")
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
                with patch("subprocess.run", return_value=mock_result):
                    ok, msg = ce.check_ant()
        assert ok is True
        assert "setantenv.sh" in msg
        assert "Apache Ant(TM) version 1.10.15" in msg

    def test_sources_setantenv_from_its_own_directory(self):
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Apache Ant(TM) version 1.10.15\n"
        fake_setantenv = Path("/some/path with spaces/hybris/bin/platform/setantenv.sh")
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
                with patch("subprocess.run", return_value=mock_result) as mock_run:
                    ce.check_ant()
        bash_cmd = mock_run.call_args[0][0][2]  # ["bash", "-c", "<cmd>"]
        assert ". ./setantenv.sh" in bash_cmd
        assert "cd " in bash_cmd
        assert shlex.quote("/some/path with spaces/hybris/bin/platform") in bash_cmd

    def test_fails_when_setantenv_found_but_ant_fails(self):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "chmod: cannot access '/path/ant': No such file\n"
        mock_result.stdout = "Comando 'ant' não encontrado\n"
        fake_setantenv = Path("/fake/hybris/bin/platform/setantenv.sh")
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
                with patch("subprocess.run", return_value=mock_result):
                    ok, msg = ce.check_ant()
        assert ok is False
        assert "falhou" in msg

    def test_error_message_prefers_stdout_over_stderr_chmod(self):
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stderr = "chmod: cannot access '/path/ant': No such file\n"
        mock_result.stdout = "Comando 'ant' não encontrado\n"
        fake_setantenv = Path("/fake/hybris/bin/platform/setantenv.sh")
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
                with patch("subprocess.run", return_value=mock_result):
                    ok, msg = ce.check_ant()
        assert "chmod" not in msg
        assert "ant" in msg.lower()

    def test_fails_on_ant_timeout(self):
        fake_setantenv = Path("/fake/hybris/bin/platform/setantenv.sh")
        with patch("shutil.which", return_value=None):
            with patch.object(ce, "_find_setantenv", return_value=fake_setantenv):
                with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("bash", 30)):
                    ok, msg = ce.check_ant()
        assert ok is False
        assert "timeout" in msg


# ---------------------------------------------------------------------------
# _find_setantenv
# ---------------------------------------------------------------------------

class TestFindSetantenv:
    def test_returns_path_when_hybris_home_set_and_setantenv_exists(self, tmp_path):
        setantenv = tmp_path / "bin" / "platform" / "setantenv.sh"
        setantenv.parent.mkdir(parents=True)
        setantenv.touch()
        with patch.dict(os.environ, {"HYBRIS_HOME": str(tmp_path)}):
            result = ce._find_setantenv()
        assert result == setantenv

    def test_returns_none_when_hybris_home_set_but_setantenv_missing(self, tmp_path):
        with patch.dict(os.environ, {"HYBRIS_HOME": str(tmp_path)}):
            result = ce._find_setantenv()
        assert result is None

    def test_finds_setantenv_at_cwd(self, tmp_path, monkeypatch):
        setantenv = tmp_path / "hybris" / "bin" / "platform" / "setantenv.sh"
        setantenv.parent.mkdir(parents=True)
        setantenv.touch()
        monkeypatch.delenv("HYBRIS_HOME", raising=False)
        with patch("pathlib.Path.cwd", return_value=tmp_path):
            result = ce._find_setantenv()
        assert result == setantenv

    def test_finds_setantenv_one_level_up_from_cwd(self, tmp_path, monkeypatch):
        setantenv = tmp_path / "hybris" / "bin" / "platform" / "setantenv.sh"
        setantenv.parent.mkdir(parents=True)
        setantenv.touch()
        subdir = tmp_path / "subproject"
        subdir.mkdir()
        monkeypatch.delenv("HYBRIS_HOME", raising=False)
        with patch("pathlib.Path.cwd", return_value=subdir):
            result = ce._find_setantenv()
        assert result == setantenv

    def test_returns_none_when_not_found_anywhere(self, tmp_path, monkeypatch):
        monkeypatch.delenv("HYBRIS_HOME", raising=False)
        with patch("pathlib.Path.cwd", return_value=tmp_path):
            result = ce._find_setantenv()
        assert result is None

    def test_finds_setantenv_five_levels_up_from_cwd(self, tmp_path, monkeypatch):
        setantenv = tmp_path / "hybris" / "bin" / "platform" / "setantenv.sh"
        setantenv.parent.mkdir(parents=True)
        setantenv.touch()
        deep_dir = tmp_path / "d1" / "d2" / "d3" / "d4" / "d5"
        deep_dir.mkdir(parents=True)
        monkeypatch.delenv("HYBRIS_HOME", raising=False)
        with patch("pathlib.Path.cwd", return_value=deep_dir):
            result = ce._find_setantenv()
        assert result == setantenv

    def test_does_not_find_setantenv_six_levels_up_from_cwd(self, tmp_path, monkeypatch):
        setantenv = tmp_path / "hybris" / "bin" / "platform" / "setantenv.sh"
        setantenv.parent.mkdir(parents=True)
        setantenv.touch()
        deep_dir = tmp_path / "d1" / "d2" / "d3" / "d4" / "d5" / "d6"
        deep_dir.mkdir(parents=True)
        monkeypatch.delenv("HYBRIS_HOME", raising=False)
        with patch("pathlib.Path.cwd", return_value=deep_dir):
            result = ce._find_setantenv()
        assert result is None


# ---------------------------------------------------------------------------
# main() — exit codes e mensagens
# ---------------------------------------------------------------------------

class TestMain:
    def test_exits_0_when_all_checks_pass(self, capsys):
        with patch.object(ce, "CHECKS", [
            ("Python 3.10+", lambda: (True, "Python 3.12.0")),
            ("Node.js 18+", lambda: (True, "node v20.0.0")),
        ]):
            with pytest.raises(SystemExit) as exc:
                ce.main()
        assert exc.value.code == 0
        captured = capsys.readouterr()
        assert "OK" in captured.out

    def test_exits_1_when_any_check_fails(self, capsys):
        with patch.object(ce, "CHECKS", [
            ("Python 3.10+", lambda: (True, "Python 3.12.0")),
            ("Node.js 18+", lambda: (False, "node not found")),
        ]):
            with pytest.raises(SystemExit) as exc:
                ce.main()
        assert exc.value.code == 1

    def test_missing_items_listed_in_output(self, capsys):
        with patch.object(ce, "CHECKS", [
            ("Java 17+", lambda: (False, "java 11.0 found, need 17+")),
        ]):
            with pytest.raises(SystemExit):
                ce.main()
        captured = capsys.readouterr()
        assert "Java 17+" in captured.out

    def test_installation_link_shown_on_failure(self, capsys):
        with patch.object(ce, "CHECKS", [
            ("Ant", lambda: (False, "ant not found")),
        ]):
            with pytest.raises(SystemExit):
                ce.main()
        captured = capsys.readouterr()
        assert "installation.md" in captured.out
