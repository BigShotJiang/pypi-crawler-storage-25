"""Testes para a CLI hybris install/list/version."""
import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


class TestInstallJunit:
    def test_copia_axetrules_dev(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / ".axetrules" / "commands.md").exists()
        assert (tmp_path / ".axetrules" / "hybris-tests.md").exists()
        assert (tmp_path / ".axetrules" / "hybris-tests-dev.md").exists()

    def test_nao_copia_axetrules_arch(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert not (tmp_path / ".axetrules" / "hybris-tests-arch.md").exists()

    def test_copia_skill_base(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-base" / "SKILL.md").exists()

    def test_copia_skill_junit(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-junit" / "SKILL.md").exists()

    def test_copia_scripts_junit(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-junit" / "scripts" / "parse_java_class.py").exists()
        assert (tmp_path / "skills" / "hybris-junit" / "scripts" / "run-junit.sh").exists()

    def test_copia_scripts_base(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert (tmp_path / "skills" / "hybris-base" / "scripts" / "check_environment.py").exists()

    def test_nao_copia_cypress(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("junit", tmp_path)

        assert not (tmp_path / "skills" / "spartacus-cypress").exists()
        assert not (tmp_path / "skills" / "accelerator-jsp-cypress").exists()


class TestInstallCypress:
    def test_exibe_coming_soon(self, tmp_path, capsys):
        from hybris_test_skills.cli import cmd_install
        cmd_install("cypress", tmp_path)

        out = capsys.readouterr().out
        assert "coming soon" in out.lower()

    def test_nao_cria_arquivos(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("cypress", tmp_path)

        assert not (tmp_path / "skills").exists()


class TestInstallAll:
    def test_all_instala_junit_na_fase1(self, tmp_path):
        from hybris_test_skills.cli import cmd_install
        cmd_install("all", tmp_path)

        assert (tmp_path / "skills" / "hybris-junit" / "SKILL.md").exists()


class TestVersion:
    def test_exibe_versao(self, capsys):
        from hybris_test_skills.cli import cmd_version
        cmd_version()

        out = capsys.readouterr().out
        assert "0.1.0" in out


class TestList:
    def test_exibe_modulos_disponiveis(self, capsys):
        from hybris_test_skills.cli import cmd_list
        cmd_list(Path("."))

        out = capsys.readouterr().out
        assert "junit" in out
        assert "cypress" in out
