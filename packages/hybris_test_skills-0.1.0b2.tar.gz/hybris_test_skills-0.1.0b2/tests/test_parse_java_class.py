"""Testes para parse_java_class.py — analisa classe Java e retorna JSON."""
import json
import subprocess
import sys
import textwrap
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

# Importar funções diretamente para testes unitários
sys.path.insert(0, str(Path(__file__).parent.parent / "skills" / "hybris-junit" / "scripts"))


class TestDetectType:
    """Testa detecção de tipo de classe Java."""

    def test_detects_populator_by_implements(self):
        from parse_java_class import detect_type
        source = textwrap.dedent("""
            package com.ntt;
            public class DefaultProductPopulator implements Populator<ProductModel, ProductData> {}
        """)
        result = detect_type(source)
        assert result == "populator"

    def test_detects_converter_by_implements(self):
        from parse_java_class import detect_type
        source = textwrap.dedent("""
            package com.ntt;
            public class DefaultPriceConverter implements Converter<PriceRowModel, PriceData> {}
        """)
        result = detect_type(source)
        assert result == "converter"

    def test_detects_dao_by_class_name(self):
        from parse_java_class import detect_type
        source = textwrap.dedent("""
            package com.ntt;
            public class DefaultOrderDAO implements OrderDAO {}
        """)
        result = detect_type(source)
        assert result == "dao"

    def test_detects_facade_by_implements(self):
        from parse_java_class import detect_type
        source = textwrap.dedent("""
            package com.ntt;
            public class DefaultProductFacade implements ProductFacade {}
        """)
        result = detect_type(source)
        assert result == "facade"

    def test_detects_strategy_by_implements(self):
        from parse_java_class import detect_type
        source = textwrap.dedent("""
            package com.ntt;
            public class DefaultDiscountStrategy implements DiscountStrategy {}
        """)
        result = detect_type(source)
        assert result == "strategy"

    def test_detects_interceptor_by_implements(self):
        from parse_java_class import detect_type
        source = textwrap.dedent("""
            package com.ntt;
            public class ProductCodeValidationInterceptor implements ValidateInterceptor<ProductModel> {}
        """)
        result = detect_type(source)
        assert result == "interceptor"

    def test_returns_other_for_unknown_type(self):
        from parse_java_class import detect_type
        source = textwrap.dedent("""
            package com.ntt;
            public class SomeRandomHelper {}
        """)
        result = detect_type(source)
        assert result == "other"


class TestExtractFlexsearchQueries:
    """Testa extração de queries FlexibleSearch do código-fonte."""

    def test_extracts_single_query(self):
        from parse_java_class import extract_flexsearch_queries
        source = 'private static final String Q = "SELECT {pk} FROM {Product} WHERE {code} = ?code";'
        result = extract_flexsearch_queries(source)
        assert len(result) == 1
        assert "SELECT {pk}" in result[0]

    def test_extracts_multiple_queries(self):
        from parse_java_class import extract_flexsearch_queries
        source = '''
            String Q1 = "SELECT {pk} FROM {Product} WHERE {code} = ?code";
            String Q2 = "SELECT {pk} FROM {Order} WHERE {user} = ?user";
        '''
        result = extract_flexsearch_queries(source)
        assert len(result) == 2

    def test_returns_empty_when_no_queries(self):
        from parse_java_class import extract_flexsearch_queries
        source = "public class NoQueries { private String name; }"
        result = extract_flexsearch_queries(source)
        assert result == []


class TestCountBranches:
    """Testa contagem de branches (if, for, while)."""

    def test_counts_if_statements(self):
        from parse_java_class import count_branches
        source = "if (a) { } if (b) { } if (c) { }"
        assert count_branches(source) == 3

    def test_counts_for_loops(self):
        from parse_java_class import count_branches
        source = "for (int i=0; i<10; i++) { } for (String s : list) { }"
        assert count_branches(source) == 2

    def test_returns_zero_for_no_branches(self):
        from parse_java_class import count_branches
        source = "return result;"
        assert count_branches(source) == 0


class TestParseClass:
    """Testa parsing completo de arquivo Java."""

    def test_returns_error_for_class_over_500_lines(self, tmp_path):
        from parse_java_class import parse_class
        java_file = tmp_path / "BigClass.java"
        lines = ["public class BigClass {"] + ["    // comment"] * 510 + ["}"]
        java_file.write_text("\n".join(lines))
        result = parse_class(str(java_file))
        assert "error" in result
        assert "too complex" in result["error"]

    def test_parses_package_correctly(self, tmp_path):
        from parse_java_class import parse_class
        java_file = tmp_path / "DefaultProductPopulator.java"
        java_file.write_text(textwrap.dedent("""
            package com.ntt.myextension.populators;
            public class DefaultProductPopulator implements Populator<ProductModel, ProductData> {
                public void populate(ProductModel source, ProductData target) {}
            }
        """))
        result = parse_class(str(java_file))
        assert result["package"] == "com.ntt.myextension.populators"

    def test_parses_class_name(self, tmp_path):
        from parse_java_class import parse_class
        java_file = tmp_path / "DefaultProductPopulator.java"
        java_file.write_text(textwrap.dedent("""
            package com.ntt;
            public class DefaultProductPopulator implements Populator<ProductModel, ProductData> {
                public void populate(ProductModel source, ProductData target) {}
            }
        """))
        result = parse_class(str(java_file))
        assert result["className"] == "DefaultProductPopulator"

    def test_detects_type_as_populator(self, tmp_path):
        from parse_java_class import parse_class
        java_file = tmp_path / "DefaultProductPopulator.java"
        java_file.write_text(textwrap.dedent("""
            package com.ntt;
            public class DefaultProductPopulator implements Populator<ProductModel, ProductData> {
                public void populate(ProductModel source, ProductData target) {}
            }
        """))
        result = parse_class(str(java_file))
        assert result["type"] == "populator"

    def test_parses_public_methods(self, tmp_path):
        from parse_java_class import parse_class
        java_file = tmp_path / "DefaultProductPopulator.java"
        java_file.write_text(textwrap.dedent("""
            package com.ntt;
            public class DefaultProductPopulator implements Populator<ProductModel, ProductData> {
                public void populate(ProductModel source, ProductData target) {}
                private void helper() {}
            }
        """))
        result = parse_class(str(java_file))
        public_methods = result["public_methods"]
        assert len(public_methods) == 1
        assert public_methods[0]["name"] == "populate"

    def test_returns_error_none_for_valid_class(self, tmp_path):
        from parse_java_class import parse_class
        java_file = tmp_path / "DefaultProductPopulator.java"
        java_file.write_text(textwrap.dedent("""
            package com.ntt;
            public class DefaultProductPopulator implements Populator<ProductModel, ProductData> {
                public void populate(ProductModel source, ProductData target) {}
            }
        """))
        result = parse_class(str(java_file))
        assert result["error"] is None


class TestCLI:
    """Testa interface de linha de comando."""

    def test_exits_with_error_when_no_argument(self):
        script = Path(__file__).parent.parent / "skills" / "hybris-junit" / "scripts" / "parse_java_class.py"
        result = subprocess.run(
            [sys.executable, str(script)],
            capture_output=True, text=True
        )
        assert result.returncode == 1
        output = json.loads(result.stdout)
        assert "error" in output

    def test_exits_with_zero_for_valid_file(self, tmp_path):
        java_file = tmp_path / "DefaultProductPopulator.java"
        java_file.write_text(textwrap.dedent("""
            package com.ntt;
            public class DefaultProductPopulator implements Populator<ProductModel, ProductData> {
                public void populate(ProductModel source, ProductData target) {}
            }
        """))
        script = Path(__file__).parent.parent / "skills" / "hybris-junit" / "scripts" / "parse_java_class.py"
        result = subprocess.run(
            [sys.executable, str(script), str(java_file)],
            capture_output=True, text=True
        )
        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert output["className"] == "DefaultProductPopulator"
