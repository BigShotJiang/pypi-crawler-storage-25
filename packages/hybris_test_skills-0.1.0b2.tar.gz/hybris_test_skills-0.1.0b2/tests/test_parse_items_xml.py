"""Testes para parse_items_xml.py — extrai itemtype do SAP Commerce items.xml."""
import json
import subprocess
import sys
import textwrap
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "skills" / "hybris-junit" / "scripts"))


SAMPLE_ITEMS_XML = textwrap.dedent("""
    <?xml version="1.0" encoding="UTF-8"?>
    <items xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
        <itemtypes>
            <itemtype code="CustomProduct" extends="Product" autocreate="true" generate="true">
                <attributes>
                    <attribute qualifier="code" type="java.lang.String">
                        <modifiers unique="true" optional="false"/>
                    </attribute>
                    <attribute qualifier="name" type="localized:java.lang.String">
                        <modifiers optional="true"/>
                    </attribute>
                    <attribute qualifier="eligible" type="java.lang.Boolean">
                        <modifiers optional="true"/>
                        <defaultvalue>false</defaultvalue>
                    </attribute>
                </attributes>
            </itemtype>
            <itemtype code="OtherType" extends="GenericItem" autocreate="true" generate="true">
                <attributes>
                    <attribute qualifier="uid" type="java.lang.String">
                        <modifiers unique="true" optional="false"/>
                    </attribute>
                </attributes>
            </itemtype>
        </itemtypes>
    </items>
""")


@pytest.fixture
def items_xml_file(tmp_path):
    xml_file = tmp_path / "myextension-items.xml"
    xml_file.write_text(SAMPLE_ITEMS_XML)
    return str(xml_file)


class TestParseItemsXml:

    def test_returns_itemtype_name(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "CustomProduct")
        assert result["itemtype"] == "CustomProduct"

    def test_returns_extends(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "CustomProduct")
        assert result["extends"] == "Product"

    def test_detects_localized_attribute_by_type_prefix(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "CustomProduct")
        name_attr = next(a for a in result["attributes"] if a["name"] == "name")
        assert name_attr["localized"] is True

    def test_non_localized_attribute_has_localized_false(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "CustomProduct")
        code_attr = next(a for a in result["attributes"] if a["name"] == "code")
        assert code_attr["localized"] is False

    def test_detects_unique_modifier(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "CustomProduct")
        code_attr = next(a for a in result["attributes"] if a["name"] == "code")
        assert code_attr["unique"] is True

    def test_detects_optional_false(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "CustomProduct")
        code_attr = next(a for a in result["attributes"] if a["name"] == "code")
        assert code_attr["optional"] is False

    def test_returns_default_value(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "CustomProduct")
        eligible_attr = next(a for a in result["attributes"] if a["name"] == "eligible")
        assert eligible_attr["default_value"] == "false"

    def test_returns_none_default_value_when_absent(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "CustomProduct")
        name_attr = next(a for a in result["attributes"] if a["name"] == "name")
        assert name_attr["default_value"] is None

    def test_returns_error_when_itemtype_not_found(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "NonExistentType")
        assert "error" in result
        assert result["error"] is not None

    def test_parses_multiple_attributes(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "CustomProduct")
        assert len(result["attributes"]) == 3

    def test_error_is_none_for_valid_itemtype(self, items_xml_file):
        from parse_items_xml import parse_items_xml
        result = parse_items_xml(items_xml_file, "CustomProduct")
        assert result["error"] is None


class TestCLI:

    def test_exits_with_error_when_no_arguments(self):
        script = Path(__file__).parent.parent / "skills" / "hybris-junit" / "scripts" / "parse_items_xml.py"
        result = subprocess.run(
            [sys.executable, str(script)],
            capture_output=True, text=True
        )
        assert result.returncode == 1
        output = json.loads(result.stdout)
        assert "error" in output

    def test_exits_with_zero_for_valid_itemtype(self, tmp_path):
        xml_file = tmp_path / "test-items.xml"
        xml_file.write_text(SAMPLE_ITEMS_XML)
        script = Path(__file__).parent.parent / "skills" / "hybris-junit" / "scripts" / "parse_items_xml.py"
        result = subprocess.run(
            [sys.executable, str(script), str(xml_file), "CustomProduct"],
            capture_output=True, text=True
        )
        assert result.returncode == 0
        output = json.loads(result.stdout)
        assert output["itemtype"] == "CustomProduct"
