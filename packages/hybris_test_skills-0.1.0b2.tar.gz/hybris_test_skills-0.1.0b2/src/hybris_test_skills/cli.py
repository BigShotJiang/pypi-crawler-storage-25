"""CLI hybris — instala skills de teste SAP Commerce no workspace."""
import argparse
import shutil
from pathlib import Path

VERSION = "0.1.0b1"

_PKG_DATA = Path(__file__).parent / "_data"

# Mapping of skill name (as used in dest) to _data subdirectory (installed mode)
_SKILL_DATA_SUBDIR = {
    "hybris-base": "base",
    "hybris-junit": "junit",
}


def _is_installed_mode() -> bool:
    """Return True when the package was installed (wheel) and _data/ exists."""
    return _PKG_DATA.exists()


def _repo_root() -> Path:
    """Return the repo root (three levels up from cli.py inside src/hybris_test_skills/)."""
    return Path(__file__).parent.parent.parent


def _resolve_skill_path(key: str) -> Path:
    """Resolve the source path for a skill in both installed and dev modes."""
    if _is_installed_mode():
        subdir = _SKILL_DATA_SUBDIR.get(key, key)
        return _PKG_DATA / subdir
    # Dev mode: read directly from skills/ in the repo
    return _repo_root() / "skills" / key


def _resolve_axetrules_path() -> Path:
    """Resolve the source .axetrules directory."""
    if _is_installed_mode():
        return _PKG_DATA / "axetrules"
    return _repo_root() / ".axetrules"


_JUNIT_SKILLS = ["hybris-base", "hybris-junit"]
_JUNIT_AXETRULES = ["commands.md", "hybris-tests.md", "hybris-tests-dev.md"]


def cmd_install(module: str, dest: Path) -> None:
    if module == "cypress":
        print("Cypress module not available in this version. Coming soon in v1.0.0.")
        return

    # Phase 1: both "junit" and "all" install the junit bundle
    _copy_skills(_JUNIT_SKILLS, dest)
    _copy_axetrules(_JUNIT_AXETRULES, dest)
    print(f"hybris-test-skills[{module}] installed in {dest}")


def _copy_skills(skill_names: list, dest: Path) -> None:
    skills_dest = dest / "skills"
    for name in skill_names:
        src = _resolve_skill_path(name)
        _copy_tree(src, skills_dest / name)


def _copy_axetrules(filenames: list, dest: Path) -> None:
    src_dir = _resolve_axetrules_path()
    dst_dir = dest / ".axetrules"
    dst_dir.mkdir(parents=True, exist_ok=True)
    for fname in filenames:
        src = src_dir / fname
        if src.exists():
            shutil.copy2(src, dst_dir / fname)


def _copy_tree(src: Path, dest: Path) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    for item in src.iterdir():
        target = dest / item.name
        if item.is_dir():
            _copy_tree(item, target)
        else:
            shutil.copy2(item, target)


def cmd_list(_dest: Path) -> None:
    print("Available modules:")
    print("  junit   — JUnit test generation skills (hybris-base + hybris-junit)")
    print("  cypress — Cypress E2E skills [coming soon in v1.0.0]")
    print("  all     — All modules [Phase 1: installs junit]")


def cmd_version() -> None:
    print(f"hybris-test-skills {VERSION}")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="hybris",
        description="SAP Commerce test skills installer",
    )
    sub = parser.add_subparsers(dest="command")

    install_p = sub.add_parser("install", help="Install skills into current workspace")
    install_p.add_argument("module", choices=["junit", "cypress", "all"])

    sub.add_parser("list", help="List available modules")
    sub.add_parser("version", help="Show installed version")

    args = parser.parse_args()

    if args.command == "install":
        cmd_install(args.module, Path.cwd())
    elif args.command == "list":
        cmd_list(Path.cwd())
    elif args.command == "version":
        cmd_version()
    else:
        parser.print_help()
