"""hybris-test-skills — SAP Commerce test generation skills."""

__version__ = "0.1.0b1"
