#!/usr/bin/env bash
# run-cypress.sh — executa spec Cypress e retorna JSON estruturado.
# Uso: ./scripts/run-cypress.sh <spec-file-path> <base-url>
# Saída JSON: { status, spec, testsRun, testsPassed, testsFailed, failures, durationMs }

set -euo pipefail

SPEC="${1:-}"
BASE_URL="${2:-}"

if [[ -z "$SPEC" || -z "$BASE_URL" ]]; then
  echo '{"status":"ERROR","error":"Usage: run-cypress.sh <spec-path> <base-url>"}' >&2
  exit 1
fi

if [[ ! -f "$SPEC" ]]; then
  echo "{\"status\":\"ERROR\",\"error\":\"Spec file not found: $SPEC\"}" >&2
  exit 1
fi

command -v npx >/dev/null 2>&1 || {
  echo '{"status":"ERROR","error":"npx not found. Run: npm install -g cypress"}' >&2
  exit 1
}

RESULTS_DIR="$(mktemp -d)"
RESULTS_FILE="$RESULTS_DIR/results.json"
START_MS=$(date +%s%3N)

# Executa Cypress em modo headless com reporter JSON
set +e
npx cypress run \
  --spec "$SPEC" \
  --reporter json \
  --reporter-options "output=$RESULTS_FILE" \
  --config "baseUrl=$BASE_URL,video=false,screenshotOnRunFailure=true" \
  >/dev/null 2>&1
CYPRESS_EXIT=$?
set -e

END_MS=$(date +%s%3N)
DURATION_MS=$((END_MS - START_MS))

if [[ ! -f "$RESULTS_FILE" ]]; then
  echo "{\"status\":\"ERROR\",\"spec\":\"$SPEC\",\"error\":\"Cypress did not produce results — check cypress.config.ts\",\"durationMs\":$DURATION_MS}"
  exit 1
fi

# Parse JSON de resultados via Python (garante portabilidade)
python3 - "$RESULTS_FILE" "$SPEC" "$DURATION_MS" <<'PYEOF'
import json
import sys
from pathlib import Path

results_path, spec, duration_ms = sys.argv[1], sys.argv[2], int(sys.argv[3])

try:
    data = json.loads(Path(results_path).read_text())
except (json.JSONDecodeError, OSError) as e:
    print(json.dumps({"status": "ERROR", "spec": spec, "error": str(e), "durationMs": duration_ms}))
    sys.exit(0)

stats = data.get("stats", {})
tests_run = stats.get("tests", 0)
tests_passed = stats.get("passes", 0)
tests_failed = stats.get("failures", 0)
tests_pending = stats.get("pending", 0)
actual_duration = stats.get("duration", duration_ms)

failures = []
for suite in data.get("results", []):
    for test in suite.get("tests", []):
        if test.get("state") == "failed":
            err = test.get("err", {})
            error_msg = err.get("message", "")
            error_type = "timeout" if "timeout" in error_msg.lower() \
                else "element_not_found" if "not found" in error_msg.lower() or "does not exist" in error_msg.lower() \
                else "assertion_fail"
            failures.append({
                "testName": test.get("fullTitle", test.get("title", "")),
                "errorType": error_type,
                "message": error_msg[:500],
                "screenshot": test.get("screenshots", [{}])[0].get("path", "") if test.get("screenshots") else "",
                "videoPath": suite.get("video", ""),
            })

status = "PASS" if tests_failed == 0 and tests_run > 0 else \
         "FAIL" if tests_failed > 0 else "ERROR"

print(json.dumps({
    "status": status,
    "spec": spec,
    "testsRun": tests_run,
    "testsPassed": tests_passed,
    "testsFailed": tests_failed,
    "testsPending": tests_pending,
    "failures": failures,
    "durationMs": actual_duration,
}, indent=2))
PYEOF

rm -rf "$RESULTS_DIR"
