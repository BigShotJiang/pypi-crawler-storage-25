# src/tripwire/_verifier.py
"""StrictVerifier, SandboxContext, and InAnyOrderContext."""

import contextvars
import difflib
import itertools
import threading
import warnings
from importlib.metadata import entry_points
from types import TracebackType
from typing import TYPE_CHECKING, Any, ClassVar, Protocol

from tripwire._compat import BaseExceptionGroup
from tripwire._config import load_tripwire_config
from tripwire._context import _active_verifier, _any_order_depth
from tripwire._errors import (
    AllWildcardAssertionError,
    AssertionInsideSandboxError,
    InteractionMismatchError,
    MissingAssertionFieldsError,
    UnassertedInteractionsError,
    UnusedMocksError,
    VerificationError,
)
from tripwire._timeline import Interaction, Timeline

_MISSING = object()

if TYPE_CHECKING:
    from tripwire._base_plugin import BasePlugin
    from tripwire._mock_plugin import ImportSiteMock, MockPlugin


# Module-level sandbox_id allocator (C4). itertools.count() is thread-safe
# per CPython (single C-level increment); never reuses values.
_sandbox_id_counter: "itertools.count[int]" = itertools.count(start=1)

# Tracks the active sandbox_id for the current execution context. Tasks
# created via asyncio.create_task capture this value at creation time,
# enabling post-sandbox detection (C4).
_current_sandbox_id: contextvars.ContextVar[int | None] = contextvars.ContextVar(
    "tripwire_current_sandbox_id", default=None,
)


class _HasSourceId(Protocol):
    """Structural type for objects that can be used as interaction sources."""

    source_id: str


class StrictVerifier:
    """Manages plugin lifecycle, sandbox context, and assertion verification.

    Do NOT instantiate directly. Use tripwire's pytest integration:

        # In your test:
        tripwire.http.mock_response("GET", "/api", json={"ok": True})
        with tripwire:
            response = requests.get("/api")
        tripwire.http.assert_request("GET", "/api", status=200)

    Direct instantiation bypasses forced assertion checking and will
    silently produce tests that pass without verifying anything.

    To access the verifier in a fixture or helper:
        verifier = tripwire.current_verifier()
    """

    _suppress_direct_warning: bool = False

    def __init__(self) -> None:
        # Detect direct instantiation outside pytest
        if not StrictVerifier._suppress_direct_warning:
            from tripwire._context import _current_test_verifier  # noqa: PLC0415

            if _current_test_verifier.get(None) is None:
                warnings.warn(
                    "StrictVerifier instantiated directly. "
                    "Use `with tripwire:` for proper assertion enforcement. "
                    "Direct instantiation bypasses the pytest fixture that "
                    "enforces verify_all() at teardown.",
                    stacklevel=2,
                )
        self._plugins: list[BasePlugin] = []
        self._timeline: Timeline = Timeline()
        self._tripwire_config: dict[str, Any] = load_tripwire_config()
        self._auto_instantiate_plugins()

    def _auto_instantiate_plugins(self) -> None:
        """Create instances of all enabled plugins on this verifier.

        Checks config for enabled_plugins/disabled_plugins.
        Silently skips plugins whose optional deps are not installed.

        After built-in plugins, discovers 3rd-party plugins registered via
        the ``tripwire.plugins`` entry point group. Entry point plugins are
        instantiated unconditionally (if installed, they should work).

        Constructor bugs are intentionally NOT caught: if a plugin's __init__
        raises a non-ImportError exception, it propagates. This is correct
        because a broken plugin constructor is a bug that should be fixed, not
        silently ignored.
        """
        from tripwire._registry import get_plugin_class, resolve_enabled_plugins

        entries = resolve_enabled_plugins(self._tripwire_config)
        for entry in entries:
            try:
                plugin_cls = get_plugin_class(entry)
                plugin_cls(self)  # BasePlugin.__init__ calls _register_plugin
            except ImportError:
                explicitly_enabled = set(self._tripwire_config.get("enabled_plugins", []))
                if entry.name in explicitly_enabled:
                    from tripwire._errors import TripwireConfigError
                    raise TripwireConfigError(
                        f"Plugin '{entry.name}' is in enabled_plugins but failed "
                        f"to import. Ensure its dependencies are installed: "
                        f"pip install python-tripwire[{entry.name}]"
                    )
                # Silent skip only for default-enabled (not explicitly listed) plugins

        self._load_entrypoint_plugins()

    def _load_entrypoint_plugins(self) -> None:
        """Discover and instantiate 3rd-party plugins from entry points.

        Looks for plugins registered under the ``tripwire.plugins`` entry point
        group. Each entry point should resolve to a BasePlugin subclass.
        Duplicate types (already registered by built-in registry) are silently
        skipped by _register_plugin.
        """
        for ep in entry_points(group="tripwire.plugins"):
            try:
                plugin_cls = ep.load()
                plugin_cls(self)
            except ImportError:
                pass  # Optional dependency not installed; expected.
            except Exception as exc:
                warnings.warn(
                    f"tripwire: entry point plugin {ep.name!r} failed to load: {exc}",
                    stacklevel=1,
                )

    def _register_plugin(self, plugin: "BasePlugin") -> None:
        for existing in self._plugins:
            if type(existing) is type(plugin):
                # Silently skip: plugin of this type already registered.
                # This happens when a test author manually creates a plugin
                # that was already auto-instantiated, or vice versa.
                return
        self._plugins.append(plugin)

    def mock(self, path: str) -> "ImportSiteMock":
        """Create an import-site mock. Path format: 'module:attr'.

        Lazily creates MockPlugin if not already registered.
        """

        mock_plugin = self._get_or_create_mock_plugin()
        return mock_plugin.create_import_site_mock(path, spy=False)

    def spy(self, path: str) -> "ImportSiteMock":
        """Create an import-site spy. Path format: 'module:attr'.

        Lazily creates MockPlugin if not already registered.
        """
        mock_plugin = self._get_or_create_mock_plugin()
        return mock_plugin.create_import_site_mock(path, spy=True)

    def _get_or_create_mock_plugin(self) -> "MockPlugin":
        """Return the existing MockPlugin or create one."""
        from tripwire._mock_plugin import MockPlugin  # noqa: PLC0415

        for plugin in self._plugins:
            if isinstance(plugin, MockPlugin):
                return plugin
        return MockPlugin(self)

    def _assert_no_active_sandbox(self) -> None:
        """Raise AssertionInsideSandboxError if this verifier's sandbox is currently active."""
        if _active_verifier.get() is self:
            raise AssertionInsideSandboxError()

    def assert_interaction(
        self,
        source: _HasSourceId,
        **expected: object,
    ) -> None:
        """Assert the next interaction matches source and expected fields.

        Completeness enforcement: after matching by source_id, the interaction's
        plugin.assertable_fields() is called. Any field in the returned set that
        is absent from **expected raises MissingAssertionFieldsError immediately,
        before the field-value match check.
        """
        self._assert_no_active_sandbox()
        source_id: str = source.source_id

        if _any_order_depth.get() > 0:
            # Two-pass in_any_order: Pass 1 — find an interaction matching source_id only,
            # then enforce completeness. Pass 2 — verify full field-value match.
            candidate = self._timeline.find_any_unasserted(lambda i: i.source_id == source_id)
            if candidate is None:
                remaining = self._timeline.all_unasserted()
                hint = self._format_mismatch_error(
                    source_id, expected, actual=None, remaining=remaining
                )
                raise InteractionMismatchError(
                    expected={"source_id": source_id, **expected},
                    actual=None,
                    hint=hint,
                )
            # Completeness check against the candidate
            required_fields = candidate.plugin.assertable_fields(candidate)
            missing = required_fields - set(expected.keys())
            if missing:
                raise MissingAssertionFieldsError(
                    missing_fields=frozenset(missing),
                    provided_fields=frozenset(expected.keys()),
                )
            # Detect all-wildcard assertions
            if expected and self._all_wildcards(expected):
                hint = candidate.plugin.format_assert_hint(candidate)
                raise AllWildcardAssertionError(interaction=candidate, hint=hint)
            # Pass 2 — full field-value match (searching all unasserted, not just candidate)
            interaction = self._timeline.find_any_unasserted(
                lambda i: i.source_id == source_id and i.plugin.matches(i, expected)
            )
            if interaction is None:
                remaining = self._timeline.all_unasserted()
                hint = self._format_mismatch_error(
                    source_id, expected, actual=None, remaining=remaining
                )
                raise InteractionMismatchError(
                    expected={"source_id": source_id, **expected},
                    actual=None,
                    hint=hint,
                )
        else:
            interaction = self._timeline.peek_next_unasserted()
            if interaction is None or interaction.source_id != source_id:
                remaining = self._timeline.all_unasserted()
                hint = self._format_mismatch_error(
                    source_id, expected, actual=interaction, remaining=remaining
                )
                raise InteractionMismatchError(
                    expected={"source_id": source_id, **expected},
                    actual=interaction,
                    hint=hint,
                )
            # Completeness enforcement: check for missing required fields
            required_fields = interaction.plugin.assertable_fields(interaction)
            missing = required_fields - set(expected.keys())
            if missing:
                raise MissingAssertionFieldsError(
                    missing_fields=frozenset(missing),
                    provided_fields=frozenset(expected.keys()),
                )
            # Detect all-wildcard assertions
            if expected and self._all_wildcards(expected):
                hint = interaction.plugin.format_assert_hint(interaction)
                raise AllWildcardAssertionError(interaction=interaction, hint=hint)
            if not interaction.plugin.matches(interaction, expected):
                remaining = self._timeline.all_unasserted()
                hint = self._format_mismatch_error(
                    source_id, expected, actual=interaction, remaining=remaining
                )
                raise InteractionMismatchError(
                    expected={"source_id": source_id, **expected},
                    actual=interaction,
                    hint=hint,
                )

        self._timeline.mark_asserted(interaction)

    def in_any_order(self) -> "InAnyOrderContext":
        """Context manager: assertions within block matched in any order.

        IMPORTANT: in_any_order() relaxes ordering globally across ALL plugins.
        It is not possible to relax ordering for only one plugin type. Any
        assert_interaction() call within this block will match any unasserted
        interaction regardless of which plugin (mock or HTTP) recorded it.
        """
        self._assert_no_active_sandbox()
        return InAnyOrderContext()

    def verify_all(self) -> None:
        """Run Enforcement 2 and 3. Called at teardown.

        Only interactions with enforce=True are checked. Interactions recorded
        during individual mock activation (enforce=False) are not required to
        be asserted.
        """
        self._assert_no_active_sandbox()
        unasserted = [i for i in self._timeline.all_unasserted() if i.enforce]
        unused: list[tuple[BasePlugin, Any]] = []

        for plugin in self._plugins:
            for mock_config in plugin.get_unused_mocks():
                unused.append((plugin, mock_config))

        has_unasserted = bool(unasserted)
        has_unused = bool(unused)

        if not has_unasserted and not has_unused:
            return

        if has_unasserted and has_unused:
            raise VerificationError(
                unasserted=UnassertedInteractionsError(
                    interactions=unasserted,
                    hint=self._format_unasserted_error(unasserted),
                ),
                unused=UnusedMocksError(
                    mocks=[mc for _, mc in unused],
                    hint=self._format_unused_mocks_error(unused),
                ),
            )
        elif has_unasserted:
            raise UnassertedInteractionsError(
                interactions=unasserted,
                hint=self._format_unasserted_error(unasserted),
            )
        else:
            raise UnusedMocksError(
                mocks=[mc for _, mc in unused],
                hint=self._format_unused_mocks_error(unused),
            )

    def sandbox(self) -> "SandboxContext":
        """Return SandboxContext for this verifier (sync + async)."""
        return SandboxContext(self)

    def _format_mismatch_error(
        self,
        source_id: str,
        expected: dict[str, Any],
        actual: Interaction | None,
        remaining: list[Interaction],
    ) -> str:
        lines = [
            "Next interaction did not match assertion",
            "",
            f"  Expected source: {source_id}",
        ]

        if actual is None:
            # No interaction to compare against; fall back to flat dump
            if expected:
                fields_str = ", ".join(f"{k}={v!r}" for k, v in expected.items())
                lines.append(f"  Expected fields: {fields_str}")
            lines.append("")
            lines.append("  Actual next interaction: (none -- timeline is empty or all asserted)")
        else:
            lines.append(f"  Actual next interaction (sequence={actual.sequence}):")
            lines.append(f"    {actual.plugin.format_interaction(actual)}")
            lines.append("")

            # Field-by-field diff: only show mismatched fields
            if expected:
                matched = 0
                for key, exp_val in expected.items():
                    act_val = actual.details.get(key, _MISSING)
                    if act_val is _MISSING:
                        lines.append(f"  {key}:")
                        lines.append(f"    expected: {exp_val!r}")
                        lines.append("    actual:   (missing)")
                    elif exp_val != act_val:
                        exp_repr = repr(exp_val)
                        act_repr = repr(act_val)
                        if (
                            isinstance(exp_val, str)
                            and isinstance(act_val, str)
                            and len(exp_repr) > 60
                            and len(act_repr) > 60
                        ):
                            diff_lines = list(
                                difflib.unified_diff(
                                    exp_val.splitlines(keepends=True),
                                    act_val.splitlines(keepends=True),
                                    fromfile="expected",
                                    tofile="actual",
                                )
                            )
                            lines.append(f"  {key}:")
                            for dl in diff_lines:
                                lines.append(f"    {dl.rstrip()}")
                        else:
                            lines.append(f"  {key}:")
                            lines.append(f"    expected: {exp_repr}")
                            lines.append(f"    actual:   {act_repr}")
                    else:
                        matched += 1
                if matched:
                    lines.append(f"  ({matched} field{'s' if matched != 1 else ''} matched)")

        # Compact timeline: skip when there's exactly 1 remaining and it's the actual
        show_remaining = (
            remaining
            and not (
                len(remaining) == 1
                and actual is not None
                and remaining[0] is actual
            )
        )
        if show_remaining:
            lines.append("")
            lines.append(f"  Remaining timeline ({len(remaining)} interaction(s)):")
            for r in remaining:
                lines.append(f"    [{r.sequence}] {r.plugin.format_interaction(r)}")

        lines.append("")
        lines.append("  Hint: Did you forget an in_any_order() block?")
        return "\n".join(lines)

    @staticmethod
    def _all_wildcards(expected: dict[str, object]) -> bool:
        """Return True if ALL expected values are always-true matchers."""
        try:
            from dirty_equals import AnyThing  # noqa: PLC0415
        except ImportError:
            return False
        return all(isinstance(v, AnyThing) for v in expected.values())

    def _format_unasserted_error(self, unasserted: list[Interaction]) -> str:
        lines = [f"{len(unasserted)} interaction(s) were not asserted", ""]
        for i in unasserted:
            hint = i.plugin.format_assert_hint(i)
            # Indent each line of the hint
            indented_hint = "\n".join(f"    {ln}" for ln in hint.splitlines())
            lines.append(indented_hint)
            lines.append(f"    # ^ [sequence={i.sequence}] {i.plugin.format_interaction(i)}")
            lines.append("")
        lines.append("  Every intercepted call must be verified with an assert_* call")
        lines.append("  after the sandbox closes:")
        lines.append("")
        lines.append("    with tripwire:")
        lines.append("        result = do_something()")
        lines.append("    plugin.assert_*(...)  # <-- required for each interaction")
        return "\n".join(lines)

    def _format_unused_mocks_error(self, unused: list[tuple["BasePlugin", Any]]) -> str:
        lines = [f"{len(unused)} mock(s) were registered but never triggered", ""]
        for plugin, mock_config in unused:
            lines.append(f"  {plugin.format_unused_mock_hint(mock_config)}")
            lines.append("")
        return "\n".join(lines)


class SandboxContext:
    """Activates all plugins and mocks. Supports both sync (with) and async (async with)."""

    # Process-wide set of currently active sandbox_ids. ALL reads and
    # mutations MUST be performed while holding _active_sandbox_ids_lock.
    # Stock CPython's GIL implicitly serializes set operations, but the
    # free-threaded build (PEP 703) does not: concurrent set.add /
    # set.discard / `in` checks against a shared `set` can corrupt its
    # internal hash table and hang in `__contains__`. The lock is
    # uncontended on the GIL build, so this is effectively a no-op there.
    #
    # Process-wide set: post-sandbox detection (Branch 2 of
    # get_verifier_or_raise) must see across thread boundaries; worker
    # threads can outlive their parent sandbox. A per-thread tracker
    # would silently misclassify late interactions from those workers
    # as "no active sandbox" instead of "post-sandbox", losing the
    # diagnostic precision that PostSandboxInteractionError exists to
    # provide. Sandbox enter/exit happens at `with verifier.sandbox():`
    # boundaries (per-test, not per-call), so the lock is acquired
    # rarely on the write path; the hot-path read in Branch 2 is a
    # microsecond-scale `set.__contains__` under a brief lock.
    _active_sandbox_ids: ClassVar[set[int]] = set()
    _active_sandbox_ids_lock: ClassVar[threading.Lock] = threading.Lock()

    def __init__(self, verifier: StrictVerifier) -> None:
        self._verifier = verifier
        self._token: contextvars.Token[Any] | None = None
        self._activated_mocks: list[Any] = []  # list[_BaseMock]
        # C4: sandbox_id allocated at _enter(); ContextVar token stashed so
        # _exit() (and the _enter() error path) can reset cleanly.
        self.sandbox_id: int | None = None
        self._sandbox_id_token: contextvars.Token[int | None] | None = None

    def _enter(self) -> StrictVerifier:
        # Allocate the sandbox_id BEFORE existing activation so the stamp
        # site in BasePlugin.record() sees a consistent ContextVar value
        # for any interaction recorded during plugin/mock activation.
        self.sandbox_id = next(_sandbox_id_counter)
        with SandboxContext._active_sandbox_ids_lock:
            SandboxContext._active_sandbox_ids.add(self.sandbox_id)
        self._sandbox_id_token = _current_sandbox_id.set(self.sandbox_id)

        self._token = _active_verifier.set(self._verifier)
        activated_so_far: list[BasePlugin] = []
        errors: list[BaseException] = []

        for plugin in self._verifier._plugins:
            try:
                plugin.activate()
                activated_so_far.append(plugin)
            except Exception as e:
                errors.append(e)
                break

        # Activate all registered mocks with enforce=True
        if not errors:
            from tripwire._mock_plugin import MockPlugin as _MP  # noqa: PLC0415, N814

            mock_plugin = next(
                (p for p in self._verifier._plugins if isinstance(p, _MP)), None
            )
            if mock_plugin is not None:
                for mock_obj in mock_plugin._mocks:
                    try:
                        mock_obj._activate(enforce=True)
                        self._activated_mocks.append(mock_obj)
                    except Exception as e:
                        errors.append(e)
                        break

        if errors:
            # Deactivate mocks in reverse order first
            for mock_obj in reversed(self._activated_mocks):
                try:
                    mock_obj._deactivate()
                except Exception as cleanup_e:
                    errors.append(cleanup_e)
            self._activated_mocks.clear()
            # Then deactivate plugins
            for plugin in reversed(activated_so_far):
                try:
                    plugin.deactivate()
                except Exception as cleanup_e:
                    errors.append(cleanup_e)
            if self._token is not None:
                _active_verifier.reset(self._token)
            # C4: reset sandbox_id ContextVar and discard the id BEFORE
            # raising the error group so a failed _enter() leaves no trace
            # in `_active_sandbox_ids`.
            if self._sandbox_id_token is not None:
                _current_sandbox_id.reset(self._sandbox_id_token)
                self._sandbox_id_token = None
            if self.sandbox_id is not None:
                with SandboxContext._active_sandbox_ids_lock:
                    SandboxContext._active_sandbox_ids.discard(self.sandbox_id)
            raise BaseExceptionGroup("tripwire sandbox activation failed", errors)

        return self._verifier

    def _exit(self) -> None:
        errors: list[BaseException] = []

        try:
            # Deactivate mocks in reverse order FIRST (before plugins)
            for mock_obj in reversed(self._activated_mocks):
                try:
                    mock_obj._deactivate()
                except Exception as e:
                    errors.append(e)
            self._activated_mocks.clear()

            # Then deactivate plugins (existing behavior)
            for plugin in reversed(self._verifier._plugins):
                try:
                    plugin.deactivate()
                except Exception as e:
                    errors.append(e)
            if self._token is not None:
                _active_verifier.reset(self._token)
            if errors:
                raise BaseExceptionGroup("tripwire sandbox deactivation failed", errors)
        finally:
            # C4: ContextVar reset and id discard ALWAYS run, even if
            # deactivation raised. This guarantees the post-sandbox
            # detection works correctly: `_current_sandbox_id` returns to
            # its parent value (or None) and `_active_sandbox_ids` no
            # longer contains this sandbox.
            if self._sandbox_id_token is not None:
                _current_sandbox_id.reset(self._sandbox_id_token)
                self._sandbox_id_token = None
            if self.sandbox_id is not None:
                with SandboxContext._active_sandbox_ids_lock:
                    SandboxContext._active_sandbox_ids.discard(self.sandbox_id)

    def __enter__(self) -> StrictVerifier:
        return self._enter()

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self._exit()

    async def __aenter__(self) -> StrictVerifier:
        return self._enter()

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self._exit()


class InAnyOrderContext:
    """Context manager: assertions within block matched in any order."""

    def __init__(self) -> None:
        self._token: contextvars.Token[int] | None = None

    def __enter__(self) -> "InAnyOrderContext":
        current = _any_order_depth.get(0)
        self._token = _any_order_depth.set(current + 1)
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        if self._token is not None:
            _any_order_depth.reset(self._token)

    async def __aenter__(self) -> "InAnyOrderContext":
        return self.__enter__()

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.__exit__(exc_type, exc_val, tb)
