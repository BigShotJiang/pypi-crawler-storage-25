"""All tripwire exception classes.

This module imports NOTHING from other tripwire modules to prevent circular imports.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from tripwire._firewall_request import FirewallRequest


class TripwireError(Exception):
    """Base class for all tripwire errors."""


class UnmockedInteractionError(TripwireError):
    """Raised at call time: an interaction fired with no matching registered mock.

    Message includes: source description, args/kwargs, copy-pasteable mock hint.
    """

    def __init__(
        self,
        source_id: str,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
        hint: str,
    ) -> None:
        self.source_id = source_id
        self.args_tuple = args
        self.kwargs = kwargs
        self.hint = hint
        super().__init__(
            f"Unmocked call to {source_id!r}.\n\n"
            f"Add a mock before entering the sandbox:\n"
            f"{hint}\n\n"
            f"Then assert it after the sandbox closes:\n"
            f"    with tripwire:\n"
            f"        # ... your code that triggers the call\n"
            f"    # assert_* call here (REQUIRED)"
        )


class UnassertedInteractionsError(TripwireError):
    """Raised at teardown: timeline contains interactions not matched by assert_interaction().

    Message lists each unasserted interaction with copy-pasteable assert hint.
    """

    def __init__(self, interactions: list[Any], hint: str) -> None:
        self.interactions = interactions
        self.hint = hint
        count = len(interactions)
        header = f"{count} interaction{'s were' if count > 1 else ' was'} not asserted."
        super().__init__(f"{header}\n\n{hint}")


class UnusedMocksError(TripwireError):
    """Raised at teardown: registered mocks with required=True were never triggered.

    Message lists each unused mock with hint to either remove or set required=False.
    """

    def __init__(self, mocks: list[Any], hint: str) -> None:
        self.mocks = mocks
        self.hint = hint
        super().__init__(f"{hint}")


class VerificationError(TripwireError):
    """Raised at teardown when BOTH UnassertedInteractionsError and UnusedMocksError apply.

    Contains both reports in separate sections.
    """

    def __init__(
        self,
        unasserted: UnassertedInteractionsError | None,
        unused: UnusedMocksError | None,
    ) -> None:
        self.unasserted = unasserted
        self.unused = unused

        sections: list[str] = []
        if unasserted is not None:
            sections.append(f"--- Unasserted Interactions ---\n{unasserted}")
        if unused is not None:
            sections.append(f"--- Unused Mocks ---\n{unused}")

        if sections:
            message = "\n\n".join(sections)
        else:
            message = "VerificationError: (no details)"

        super().__init__(message)


class InteractionMismatchError(TripwireError):
    """Raised by assert_interaction() when expected source/fields don't match
    the next interaction in the timeline.

    Message includes: expected description, actual next interaction, remaining timeline.
    """

    def __init__(
        self,
        expected: object,
        actual: object,
        hint: str,
    ) -> None:
        self.expected = expected
        self.actual = actual
        self.hint = hint
        super().__init__(hint)


class SandboxNotActiveError(TripwireError):
    """Raised when an intercepted call fires but no sandbox is active.

    Attributes:
        source_id: Identifier of the interceptor that fired without a sandbox.

    Message includes hint: 'Did you forget tripwire_verifier fixture or sandbox() CM?'
    """

    def __init__(self, source_id: str) -> None:
        self.source_id = source_id
        super().__init__(
            f"SandboxNotActiveError: source_id={source_id!r}, "
            "hint='Did you forget tripwire_verifier fixture or sandbox() CM?'"
        )


class AssertionInsideSandboxError(TripwireError):
    """Raised when assert_interaction(), in_any_order(), or verify_all() is called
    while a sandbox is active on that verifier instance.

    Assertions must be made after the sandbox exits, not during it.
    """

    def __init__(self) -> None:
        super().__init__(
            "AssertionInsideSandboxError: assert_interaction(), in_any_order(), and verify_all() "
            "must be called after the sandbox has exited, not while it is active. "
            "Exit the sandbox first, then make assertions."
        )


class NoActiveVerifierError(TripwireError):
    """Raised when a module-level tripwire function is called outside a test context."""

    def __str__(self) -> str:
        return (
            "NoActiveVerifierError: no active tripwire verifier. "
            "Module-level tripwire functions (mock, sandbox, assert_interaction, etc.) "
            "require an active test context. Ensure tripwire is installed as a pytest "
            "plugin (it registers automatically) and you are running inside a pytest test."
        )


class ConflictError(TripwireError):
    """Raised at activate() time if target method is already patched by another library.

    Message names the conflicting library and the patched target.
    """

    def __init__(self, target: str, patcher: str) -> None:
        self.target = target
        self.patcher = patcher
        super().__init__(f"ConflictError: target={target!r}, patcher={patcher!r}")


class MissingAssertionFieldsError(TripwireError):
    """Raised by assert_interaction() when the caller omits one or more assertable
    fields from **expected.

    Attributes:
        missing_fields: frozenset of field names that were required but absent.
    """

    def __init__(
        self,
        missing_fields: frozenset[str],
        provided_fields: frozenset[str] | None = None,
    ) -> None:
        self.missing_fields = missing_fields
        self.provided_fields = provided_fields
        missing_str = ", ".join(sorted(missing_fields))
        lines = [
            f"Missing assertion fields: {missing_str}",
        ]
        if provided_fields is not None:
            provided_str = ", ".join(sorted(provided_fields))
            lines.append(f"  Provided: {provided_str}")
        lines.append("")
        lines.append(
            "Include them in **expected or use a dirty-equals"
            " matcher (e.g., IsAnything())"
        )
        lines.append(
            "if the value is not the focus of this assertion."
        )
        super().__init__("\n".join(lines))


class AutoAssertError(TripwireError):
    """Raised when mark_asserted() is called while record() is in progress.

    This indicates the auto-assert anti-pattern: a plugin calling
    timeline.mark_asserted() immediately after record() inside its intercept
    hook, bypassing the requirement for explicit test assertions.
    """


class AllWildcardAssertionError(TripwireError):
    """Raised when all assertion fields are wildcards (e.g., AnyThing()).

    All-wildcard assertions verify nothing. Use real expected values
    for at least some fields.
    """

    def __init__(self, interaction: object, hint: str) -> None:
        self.interaction = interaction
        self.hint = hint
        super().__init__(
            "All assertion fields are wildcards. This assertion verifies nothing.\n\n"
            "Here's what actually happened -- paste this instead:\n\n"
            f"{hint}"
        )


class TripwireConfigError(TripwireError):
    """Raised when [tool.tripwire] configuration is invalid.

    Examples: mutually exclusive keys, unknown plugin names, wrong types.
    """


class ConfigMigrationError(TripwireError):
    """Raised when a deprecated `[tool.bigfoot]` table is found in pyproject.toml.

    bigfoot was renamed to tripwire in 0.20.0. The migration check fires at
    the top of `load_tripwire_config` so the error surfaces before any other
    validation, with a clear hint to rename the table to `[tool.tripwire]`.
    """


class GuardedCallError(TripwireError):
    """Raised when a call is blocked by the tripwire firewall.

    The error message shows:
    1. Exactly what was attempted (URL, host, command, path)
    2. The most specific allow rule to fix it (not blanket allow)
    3. All three configuration syntaxes (mark, context manager, TOML)
    4. Link to docs
    """

    def __init__(
        self,
        source_id: str,
        plugin_name: str,
        firewall_request: FirewallRequest | None = None,
        user_frame: tuple[str, int, str] | None = None,
    ) -> None:
        self.source_id = source_id
        self.plugin_name = plugin_name
        self.firewall_request = firewall_request
        self.user_frame = user_frame
        super().__init__(self._build_message())

    def _build_message(self) -> str:
        req = self.firewall_request
        # Method-being-called: text after the LAST ":" in the source_id
        # (e.g., "subprocess:run" -> "run", "asyncio:subprocess:spawn" ->
        # "spawn"). Using rsplit means the trailing segment is always
        # treated as the method name regardless of how many leading
        # plugin/namespace segments precede it. Falls back to
        # "<unknown method>" if the source_id is malformed (no colon).
        #
        # Performance note: rsplit on a short source_id is one C-level
        # string scan per intercepted call, on the order of tens of
        # nanoseconds. Combined with the lock-free plugin lookup cache
        # in `_registry.py`, the per-call dispatch overhead is negligible
        # compared to the C-call interception itself.
        if ":" in self.source_id:
            method = self.source_id.rsplit(":", 1)[1]
        else:
            method = "<unknown method>"
        # User call site: rendered as "file:lineno", or "<unknown call site>"
        # when the frame walker found no user frame (e.g., spawned thread).
        if self.user_frame is None:
            site = "<unknown call site>"
        else:
            site = f"{self.user_frame[0]}:{self.user_frame[1]}"
        lines = [
            f"GuardedCallError: {self.source_id!r} blocked by tripwire firewall.",
            "",
            (
                f'  Called {self.plugin_name}.{method} at {site} '
                f'OUTSIDE any "with tripwire:" block.'
            ),
            "",
        ]

        # Section 1: What was attempted
        lines.append("  Attempted:")
        if req is not None:
            lines.append(f"    {self._describe_request(req)}")
        else:
            lines.append(f"    {self.source_id} (no request details available)")
        lines.append("")

        # Section 2: Recommended fix (most specific)
        mark_fix, cm_fix, toml_fix = self._recommend_fix(req)

        lines.append("  Fix with @pytest.mark.allow:")
        lines.append("")
        lines.append(f"    {mark_fix}")
        lines.append("    def test_something():")
        lines.append("        ...")
        lines.append("")
        lines.append("  Fix with context manager (scoped to a block):")
        lines.append("")
        lines.append(f"    {cm_fix}")
        lines.append("        ...")
        lines.append("")
        lines.append("  Fix in pyproject.toml:")
        lines.append("")
        for toml_line in toml_fix:
            lines.append(f"    {toml_line}")
        lines.append("")

        # Section 3: Or mock it
        lines.append("  Or mock the call with a sandbox:")
        lines.append("")
        lines.append("    with tripwire:")
        lines.append("        ...")
        lines.append("")
        lines.append("  Docs: https://tripwire.readthedocs.io/guides/guard-mode/")

        return "\n".join(lines)

    def _describe_request(self, req: FirewallRequest) -> str:
        """Human-readable description of what was attempted."""
        from tripwire._firewall_request import (  # noqa: PLC0415
            Boto3FirewallRequest,
            DatabaseFirewallRequest,
            FileIoFirewallRequest,
            HttpFirewallRequest,
            McpFirewallRequest,
            NetworkFirewallRequest,
            RedisFirewallRequest,
            SubprocessFirewallRequest,
        )

        if isinstance(req, HttpFirewallRequest):
            url = f"{req.scheme}://{req.host}:{req.port}{req.path}"
            return f"{req.method} {url}"
        if isinstance(req, RedisFirewallRequest):
            return f"redis://{req.host}:{req.port}/{req.db} {req.command}"
        if isinstance(req, SubprocessFirewallRequest):
            return f"subprocess: {req.command}" if req.command else f"subprocess: {req.binary}"
        if isinstance(req, FileIoFirewallRequest):
            return f"file_io: {req.operation} {req.path}"
        if isinstance(req, Boto3FirewallRequest):
            return f"boto3: {req.service}.{req.operation}"
        if isinstance(req, DatabaseFirewallRequest):
            return f"sqlite: {req.database_path}"
        if isinstance(req, McpFirewallRequest):
            return f"mcp: tool={req.tool_name} uri={req.uri}"
        if isinstance(req, NetworkFirewallRequest):
            return f"{req.protocol}://{req.host}:{req.port}"
        return f"{req.protocol}: (details unavailable)"

    def _recommend_fix(
        self, req: FirewallRequest | None,
    ) -> tuple[str, str, list[str]]:
        """Generate the most specific fix for mark, context manager, and TOML.

        Returns (mark_str, cm_str, toml_lines).
        """
        if req is None:
            # Fallback: coarse plugin-level fix
            return (
                f'@pytest.mark.allow("{self.plugin_name}")',
                f'with tripwire.allow("{self.plugin_name}"):',
                [
                    "[tool.tripwire.firewall]",
                    f'allow = ["{self.plugin_name}:*"]',
                ],
            )

        from tripwire._firewall_request import (  # noqa: PLC0415
            Boto3FirewallRequest,
            FileIoFirewallRequest,
            HttpFirewallRequest,
            RedisFirewallRequest,
            SubprocessFirewallRequest,
        )

        if isinstance(req, HttpFirewallRequest):
            m_str = f'M(protocol="http", host="{req.host}", path="{req.path}")'
            return (
                f"@pytest.mark.allow({m_str})",
                f"with tripwire.allow({m_str}):",
                [
                    "[tool.tripwire.firewall]",
                    f'allow = ["{req.scheme}://{req.host}{req.path}"]',
                ],
            )

        if isinstance(req, RedisFirewallRequest):
            m_str = f'M(protocol="redis", host="{req.host}", port={req.port})'
            return (
                f"@pytest.mark.allow({m_str})",
                f"with tripwire.allow({m_str}):",
                [
                    "[tool.tripwire.firewall]",
                    f'allow = ["redis://{req.host}:{req.port}"]',
                ],
            )

        if isinstance(req, SubprocessFirewallRequest):
            m_str = f'M(protocol="subprocess", binary="{req.binary}")'
            return (
                f"@pytest.mark.allow({m_str})",
                f"with tripwire.allow({m_str}):",
                [
                    "[tool.tripwire.firewall]",
                    f'allow = ["subprocess:{req.binary}"]',
                ],
            )

        if isinstance(req, FileIoFirewallRequest):
            m_str = f'M(protocol="file_io", path="{req.path}", operation="{req.operation}")'
            return (
                f"@pytest.mark.allow({m_str})",
                f"with tripwire.allow({m_str}):",
                [
                    "[tool.tripwire.firewall]",
                    'allow = ["file_io:*"]  # or restrict to specific paths',
                ],
            )

        if isinstance(req, Boto3FirewallRequest):
            m_str = f'M(protocol="boto3", service="{req.service}", operation="{req.operation}")'
            return (
                f"@pytest.mark.allow({m_str})",
                f"with tripwire.allow({m_str}):",
                [
                    "[tool.tripwire.firewall]",
                    'allow = ["boto3:*"]  # or restrict to specific services',
                ],
            )

        # Generic network protocol
        m_str = f'M(protocol="{req.protocol}")'
        return (
            f"@pytest.mark.allow({m_str})",
            f"with tripwire.allow({m_str}):",
            [
                "[tool.tripwire.firewall]",
                f'allow = ["{req.protocol}:*"]',
            ],
        )


class UnsafePassthroughError(TripwireError):
    """Raised when guard='warn' lets an unmocked call through to a plugin
    whose passthrough is NOT safe (i.e., would cause real I/O).

    The plugin declares this via ``passthrough_safe = False`` on its class.
    When guard='warn' would normally let an unmocked call pass through to
    the original implementation, plugins that perform real I/O on
    passthrough raise this error instead, so the test fails loud rather
    than silently performing a side effect.
    """

    def __init__(
        self,
        source_id: str,
        plugin_name: str,
        user_frame: tuple[str, int, str] | None = None,
    ) -> None:
        self.source_id = source_id
        self.plugin_name = plugin_name
        self.user_frame = user_frame
        super().__init__(self._build_message())

    def _build_message(self) -> str:
        # Method-being-called: text after the LAST ":" in the source_id.
        # Mirrors ``GuardedCallError._build_message`` so the framing prose
        # is uniform across the three pedagogical errors.
        if ":" in self.source_id:
            method = self.source_id.rsplit(":", 1)[1]
        else:
            method = "<unknown method>"
        # User call site: rendered as "file:lineno", or "<unknown call site>"
        # when the frame walker found no user frame (e.g., spawned thread).
        if self.user_frame is None:
            site = "<unknown call site>"
        else:
            site = f"{self.user_frame[0]}:{self.user_frame[1]}"
        return (
            f"UnsafePassthroughError: {self.source_id!r} would have caused "
            f"real I/O outside any 'with tripwire:' block.\n"
            f"\n"
            f"  Called {self.plugin_name}.{method} at {site} "
            f'OUTSIDE any "with tripwire:" block.\n'
            f"\n"
            f"Plugin {self.plugin_name!r} doesn't support outside-sandbox "
            f"passthrough (passthrough_safe=False), meaning its passthrough "
            f"path is NOT a no-op.\n"
            f"\n"
            f"Fix one of:\n"
            f"  - Wrap the call in 'with tripwire:' and add an allow/mock for it.\n"
            f"  - set guard='error' in [tool.tripwire] to make this fail explicitly.\n"
            f"  - If you have audited that this plugin's passthrough is safe, "
            f"set passthrough_safe=True on the plugin class.\n"
        )


class PostSandboxInteractionError(TripwireError):
    """Raised when an intercepted call fires from a thread / task / future
    that survived the `with tripwire:` exit. Distinct from the leaked-
    interaction case (call without ever having entered any sandbox)."""

    def __init__(
        self,
        source_id: str,
        plugin_name: str,
        sandbox_id: int,
        user_frame: tuple[str, int, str] | None = None,
    ) -> None:
        self.source_id = source_id
        self.plugin_name = plugin_name
        self.sandbox_id = sandbox_id
        self.user_frame = user_frame
        super().__init__(self._build_message())

    def _build_message(self) -> str:
        # Method-being-called: text after the LAST ":" in the source_id.
        # Mirrors ``GuardedCallError._build_message`` so the framing prose
        # is uniform across the three pedagogical errors.
        if ":" in self.source_id:
            method = self.source_id.rsplit(":", 1)[1]
        else:
            method = "<unknown method>"
        # User call site: rendered as "file:lineno", or "<unknown call site>"
        # when the frame walker found no user frame (e.g., spawned thread).
        if self.user_frame is None:
            site = "<unknown call site>"
        else:
            site = f"{self.user_frame[0]}:{self.user_frame[1]}"
        return (
            f"PostSandboxInteractionError: {self.source_id!r} fired from a "
            f"context that survived the exit of sandbox #{self.sandbox_id}.\n"
            f"\n"
            f"  Called {self.plugin_name}.{method} at {site} "
            f"AFTER the sandbox exited.\n"
            f"\n"
            f"This usually means an asyncio Task, thread, or future was "
            f"scheduled inside `with tripwire:` and is still running after "
            f"the block exited.\n"
            f"\n"
            f"Fix one of:\n"
            f"  - Await or cancel all pending tasks before exiting the sandbox.\n"
            f"  - Use `asyncio.gather(...)` inside the sandbox to ensure "
            f"completion.\n"
            f"  - If the late call is intentional, wrap it in its own "
            f"`with tripwire:` block.\n"
        )


class GuardedCallWarning(UserWarning):
    """Emitted when guard mode is set to 'warn' and an I/O call fires
    outside a sandbox without allow() permission.

    Filter with:
        warnings.filterwarnings("ignore", category=GuardedCallWarning)
    """


class InvalidStateError(TripwireError):
    """Raised when a state-machine method is called from an invalid state.

    Attributes:
        source_id: Identifier of the source that triggered the call.
        method: Name of the method that was called.
        current_state: The state the machine was in when the call was made.
        valid_states: The frozenset of states from which the call is permitted.
    """

    def __init__(
        self,
        source_id: str,
        method: str,
        current_state: str,
        valid_states: frozenset[str],
    ) -> None:
        self.source_id = source_id
        self.method = method
        self.current_state = current_state
        self.valid_states = valid_states
        super().__init__(
            f"'{method}' called in state '{current_state}'; valid from: {valid_states!r}"
        )
