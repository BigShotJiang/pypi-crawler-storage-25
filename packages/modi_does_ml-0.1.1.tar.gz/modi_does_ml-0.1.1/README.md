# modi_does_ml — ML Code Reference Library

Ready-to-use Machine Learning algorithm templates,  
both **with sklearn** and **from scratch (no lib)**.

---

## System Requirements (install BEFORE pip install)

These cannot be installed via pip — install them first:

**Linux:**
```bash
sudo apt install python3-tk graphviz
```

**Mac:**
```bash
brew install python-tk graphviz
```

**Windows:**
- Reinstall Python from [python.org](https://python.org) → tick **"tcl/tk"** checkbox during install
- Download and install Graphviz from [graphviz.org/download](https://graphviz.org/download/) and add to PATH during install

---

## Installation

```bash
pip install modi_does_ml
```

This will automatically install:
`pandas`, `numpy`, `matplotlib`, `scikit-learn`, `seaborn`, `xgboost`, `graphviz`, `Pillow`

---

## Quick Start

```python
from modi_does_ml import index

# Show all available modules + interactive menu
index.main()
```

---

## Generate a `.py` file

### Interactive (numbered menu):
```python
from modi_does_ml import index
index.main()
# type a number → .py file created in your current folder
```

### Direct:
```python
from modi_does_ml import index
index.generate('pca')                    # creates pca.py
index.generate('k_means_clustering')     # creates k_means_clustering.py
index.generate('lda_nolib')              # creates lda_nolib.py
```

---

## Available Modules

| Module Name                 | Description                         |
|-----------------------------|-------------------------------------|
| `linear_regression`         | Linear Regression (sklearn)         |
| `logistic_regression`       | Logistic Regression (sklearn)       |
| `decision_tree`             | Decision Tree (sklearn)             |
| `random_forest`             | Random Forest (sklearn)             |
| `svm_lineardata`            | SVM Linear Kernel (sklearn)         |
| `svm_nonlineardata`         | SVM RBF Kernel (sklearn)            |
| `k_means_clustering`        | K-Means Clustering (sklearn)        |
| `pca`                       | PCA (sklearn)                       |
| `svd`                       | SVD (sklearn)                       |
| `lda`                       | LDA (sklearn)                       |
| `xgboost`                   | XGBoost (sklearn)                   |
| `linear_regression_nolib`   | Linear Regression (from scratch)    |
| `logistic_regression_nolib` | Logistic Regression (from scratch)  |
| `decision_tree_nolib`       | Decision Tree (from scratch)        |
| `random_forest_nolib`       | Random Forest (from scratch)        |
| `svm_lineardata_nolib`      | SVM Linear (from scratch)           |
| `svm_nonlineardata_nolib`   | SVM RBF (from scratch)              |
| `k_means_clustering_nolib`  | K-Means (from scratch)              |
| `pca_nolib`                 | PCA (from scratch)                  |
| `svd_nolib`                 | SVD (from scratch)                  |
| `lda_nolib`                 | LDA (from scratch)                  |
| `xgboost_nolib`             | XGBoost / Boosting (from scratch)   |

---

## License

MIT
