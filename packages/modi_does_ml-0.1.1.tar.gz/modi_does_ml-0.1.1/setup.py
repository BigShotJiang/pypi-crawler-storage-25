from setuptools import setup, find_packages
import os

# Read long description from README if present
here = os.path.abspath(os.path.dirname(__file__))
try:
    with open(os.path.join(here, "README.md"), encoding="utf-8") as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = "ML Code Reference Library — ready-to-use ML algorithm templates."

setup(
    name="modi_does_ml",
    version="0.1.1",
    author="Your Name",
    author_email="your@email.com",
    description="ML Code Reference Library — sklearn and from-scratch templates",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/modi_does_ml",
    packages=find_packages(),
    package_data={
        "modi_does_ml": ["*.py"],
    },
    include_package_data=True,
    python_requires=">=3.7",
    install_requires=[
        "pandas",
        "numpy",
        "matplotlib",
        "scikit-learn",
        "seaborn",
        "xgboost",
        "graphviz",
        "Pillow",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Education",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    keywords="machine learning ml templates sklearn reference",
)
