# =========================================================
# PCA USING SKLEARN
# =========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler

from sklearn.decomposition import PCA

from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression

from sklearn.metrics import accuracy_score

# =========================================================
# DATASET SECTION
# Uncomment ONLY ONE SECTION
# =========================================================

# ---------------------------------------------------------
# OPTION 1 : CSV DATASET
# ---------------------------------------------------------

df = pd.read_csv("data.csv")

# ---------------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# ---------------------------------------------------------

# data = {
#     "Feature1": [2,3,4,5,6,7,8,9,10,11],
#     "Feature2": [1,2,1,3,4,5,6,7,8,9],
#     "Feature3": [5,6,7,8,9,10,11,12,13,14],
#     "Feature4": [9,8,7,6,5,4,3,2,1,0],
#     "Class":    [0,0,0,0,1,1,1,1,1,1]
# }

# df = pd.DataFrame(data)

# =========================================================
# VIEW DATA
# =========================================================

print("\nDataset:\n")

print(df.head())

# =========================================================
# FEATURES AND TARGET
# =========================================================

X = df.iloc[:, :-1]

y = df.iloc[:, -1]

# =========================================================
# STANDARDIZATION
# =========================================================

scaler = StandardScaler()

X_scaled = scaler.fit_transform(X)

# =========================================================
# PCA TRANSFORMATION
# =========================================================

pca = PCA()

X_pca = pca.fit_transform(X_scaled)

# =========================================================
# EXPLAINED VARIANCE
# =========================================================

variance_ratio = (
    pca.explained_variance_ratio_
)

print("\nExplained Variance Ratio:\n")

print(variance_ratio)

print("\nCumulative Variance:\n")

print(np.cumsum(variance_ratio))

# =========================================================
# VISUALIZATION 1
# SCREE PLOT
# =========================================================

plt.figure(figsize=(8,6))

plt.plot(
    range(1, len(variance_ratio)+1),
    variance_ratio,
    marker='o'
)

plt.xlabel("Principal Components")

plt.ylabel("Explained Variance Ratio")

plt.title("Scree Plot")

plt.grid(True)

plt.show()

# =========================================================
# VISUALIZATION 2
# VARIANCE VS COMPONENTS
# =========================================================

plt.figure(figsize=(8,6))

plt.plot(
    range(1, len(variance_ratio)+1),
    np.cumsum(variance_ratio),
    marker='o'
)

plt.xlabel("Number of Components")

plt.ylabel("Cumulative Variance")

plt.title("Variance vs Components")

plt.grid(True)

plt.show()

# =========================================================
# APPLY PCA WITH 2 COMPONENTS
# =========================================================

pca_2 = PCA(n_components=2)

X_2d = pca_2.fit_transform(X_scaled)

# =========================================================
# VISUALIZATION 3
# PCA 2D VISUALIZATION
# =========================================================

plt.figure(figsize=(8,6))

scatter = plt.scatter(
    X_2d[:,0],
    X_2d[:,1],
    c=y
)

plt.xlabel("PC1")

plt.ylabel("PC2")

plt.title("PCA 2D Visualization")

plt.legend(
    *scatter.legend_elements(),
    title="Classes"
)

plt.grid(True)

plt.show()

# =========================================================
# ACCURACY VS COMPONENTS
# =========================================================

accuracies = []

component_range = range(
    1,
    X.shape[1] + 1
)

for n in component_range:

    pca_temp = PCA(n_components=n)

    X_temp = pca_temp.fit_transform(
        X_scaled
    )

    X_train, X_test, y_train, y_test = (
        train_test_split(
            X_temp,
            y,
            test_size=0.2,
            random_state=42
        )
    )

    model = LogisticRegression()

    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    acc = accuracy_score(
        y_test,
        y_pred
    )

    accuracies.append(acc)

# =========================================================
# VISUALIZATION 4
# ACCURACY VS COMPONENTS
# =========================================================

plt.figure(figsize=(8,6))

plt.plot(
    component_range,
    accuracies,
    marker='o'
)

plt.xlabel("Number of Components")

plt.ylabel("Accuracy")

plt.title("Accuracy vs PCA Components")

plt.grid(True)

plt.show()

# =========================================================
# PRINCIPAL COMPONENTS
# =========================================================

print("\nPrincipal Components:\n")

print(pca.components_)

# =========================================================
# EIGENVALUES
# =========================================================

print("\nEigenvalues:\n")

print(pca.explained_variance_)