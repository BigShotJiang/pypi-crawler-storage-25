import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split

from sklearn.tree import (
    DecisionTreeClassifier,
    export_graphviz
)

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    auc
)

import graphviz

df = pd.read_csv("job_satisfaction_dataset.csv")

# data = {
#     "Hours": [1,2,3,4,5,6,7,8,9,10],
#     "Attendance": [50,55,60,65,70,75,80,85,90,95],
#     "Pass": [0,0,0,0,1,1,1,1,1,1]
# }

# df = pd.DataFrame(data)

print("\nDataset:\n")

print(df.head())

X = df.iloc[:, :-1]
y = df.iloc[:, -1]

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

model = DecisionTreeClassifier(
    criterion='entropy',
    max_depth=3,
    random_state=42
)

model.fit(X_train, y_train)

y_pred = model.predict(X_test)

y_prob = model.predict_proba(X_test)[:,1]

accuracy = accuracy_score(
    y_test,
    y_pred
)

print("\nAccuracy:", accuracy)


cm = confusion_matrix(
    y_test,
    y_pred
)

print("\nConfusion Matrix:\n")

print(cm)

# =========================================================
# CLASSIFICATION REPORT
# =========================================================

report = classification_report(
    y_test,
    y_pred
)

print("\nClassification Report:\n")

print(report)

# =========================================================
# FEATURE IMPORTANCE
# =========================================================

importance = pd.DataFrame({
    "Feature": X.columns,
    "Importance": model.feature_importances_
})

print("\nFeature Importance:\n")

print(importance)

# =========================================================
# ACTUAL VS PREDICTED
# =========================================================

results = pd.DataFrame({
    "Actual": y_test,
    "Predicted": y_pred
})

print("\nActual vs Predicted:\n")

print(results)

# =========================================================
# GRAPHVIZ TREE VISUALIZATION
# =========================================================

dot_data = export_graphviz(
    model,
    out_file=None,
    feature_names=X.columns,
    class_names=["0", "1"],
    filled=True,
    rounded=True,
    special_characters=True
)

graph = graphviz.Source(dot_data)

graph.render("decision_tree")

print("\nGraphviz tree saved as decision_tree.pdf")

# =========================================================
# VISUALIZATION 1
# CONFUSION MATRIX
# =========================================================

plt.figure(figsize=(6,5))

plt.imshow(cm)

plt.title("Confusion Matrix")

plt.colorbar()

plt.xlabel("Predicted")

plt.ylabel("Actual")

for i in range(len(cm)):
    for j in range(len(cm)):

        plt.text(
            j,
            i,
            cm[i][j],
            ha='center',
            va='center',
            color='red'
        )

plt.show()

# =========================================================
# VISUALIZATION 2
# ROC CURVE
# =========================================================

fpr, tpr, thresholds = roc_curve(
    y_test,
    y_prob
)

roc_auc = auc(fpr, tpr)

plt.figure(figsize=(7,6))

plt.plot(
    fpr,
    tpr,
    label=f"AUC = {roc_auc:.2f}"
)

plt.plot([0,1], [0,1], 'r--')

plt.xlabel("False Positive Rate")

plt.ylabel("True Positive Rate")

plt.title("ROC Curve")

plt.legend()

plt.grid(True)

plt.show()