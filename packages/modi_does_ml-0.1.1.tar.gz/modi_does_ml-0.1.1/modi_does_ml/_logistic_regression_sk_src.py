# =====================================================
# LOGISTIC REGRESSION (GENERALIZED TEMPLATE)
# =====================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    auc
)

# =====================================================
# DATASET SECTION
# Uncomment ONLY ONE SECTION
# =====================================================

# -----------------------------------------------------
# OPTION 1 : CSV DATASET
# -----------------------------------------------------

df = pd.read_csv("data.csv")

# -----------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# -----------------------------------------------------

# data = {

#     "Hours": [1,2,3,4,5,6,7,8,9,10],

#     "Attendance": [
#         50,55,60,65,70,
#         75,80,85,90,95
#     ],

#     "Assignments": [
#         1,1,2,2,3,
#         3,4,4,5,5
#     ],

#     "Pass": [
#         0,0,0,0,1,
#         1,1,1,1,1
#     ]
# }

# df = pd.DataFrame(data)

# =====================================================
# VIEW DATA
# =====================================================

print("\nDataset:")

print(df.head())

# =====================================================
# FEATURES AND TARGET
# =====================================================

X = df.iloc[:, :-1]

y = df.iloc[:, -1]

# =====================================================
# TRAIN TEST SPLIT
# =====================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# =====================================================
# MODEL CREATION
# =====================================================

model = LogisticRegression()

# =====================================================
# TRAIN MODEL
# =====================================================

model.fit(X_train, y_train)

# =====================================================
# PREDICTIONS
# =====================================================

y_pred = model.predict(X_test)

# Probability predictions for ROC curve

y_prob = model.predict_proba(X_test)[:, 1]

# =====================================================
# ACCURACY
# =====================================================

accuracy = accuracy_score(y_test, y_pred)

print("\nAccuracy:", accuracy)

# =====================================================
# CONFUSION MATRIX
# =====================================================

cm = confusion_matrix(y_test, y_pred)

print("\nConfusion Matrix:")

print(cm)

# =====================================================
# CLASSIFICATION REPORT
# =====================================================

report = classification_report(y_test, y_pred)

print("\nClassification Report:\n")

print(report)

# =====================================================
# ACTUAL VS PREDICTED
# =====================================================

results = pd.DataFrame({
    "Actual": y_test,
    "Predicted": y_pred
})

print("\nActual vs Predicted")

print(results)

# =====================================================
# VISUALIZATION 1
# CONFUSION MATRIX
# =====================================================

plt.figure(figsize=(6,5))

plt.imshow(cm)

plt.title("Confusion Matrix")

plt.colorbar()

plt.xlabel("Predicted")

plt.ylabel("Actual")

for i in range(len(cm)):
    for j in range(len(cm)):
        plt.text(j, i, cm[i][j],
                 ha='center',
                 va='center',
                 color='red')

plt.show()

# =====================================================
# VISUALIZATION 2
# ROC CURVE
# =====================================================

fpr, tpr, thresholds = roc_curve(y_test, y_prob)

roc_auc = auc(fpr, tpr)

plt.figure(figsize=(7,6))

plt.plot(fpr, tpr,
         label=f"AUC = {roc_auc:.2f}")

# diagonal line

plt.plot([0,1], [0,1], 'r--')

plt.xlabel("False Positive Rate")

plt.ylabel("True Positive Rate")

plt.title("ROC Curve")

plt.legend()

plt.grid(True)

plt.show()

# =====================================================
# VISUALIZATION 3
# SINGLE FEATURE DECISION BOUNDARY
# =====================================================

if X.shape[1] == 1:

    plt.figure(figsize=(8,6))

    plt.scatter(X, y)

    x_values = np.linspace(
        X.min().values[0],
        X.max().values[0],
        100
    )

    x_df = pd.DataFrame(x_values,
                        columns=[X.columns[0]])

    probs = model.predict_proba(x_df)[:,1]

    plt.plot(x_values, probs, color='red')

    plt.xlabel(X.columns[0])

    plt.ylabel("Probability")

    plt.title("Sigmoid Curve")

    plt.grid(True)

    plt.show()

# =====================================================
# CUSTOM PREDICTION
# =====================================================

# Example single feature:
# new_data = [[5]]

# Example multiple features:
# new_data = [[v1, v2, v3]]

# prediction = model.predict(new_data)

# probability = model.predict_proba(new_data)

# print("\nPrediction:", prediction)

# print("Probability:", probability)