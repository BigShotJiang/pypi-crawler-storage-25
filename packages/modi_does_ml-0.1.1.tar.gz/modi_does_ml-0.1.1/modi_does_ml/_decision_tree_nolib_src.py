# =========================================================
# MANUAL DECISION TREE WITH GRAPHVIZ VISUALIZATION
# =========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report
)

from graphviz import Digraph

from PIL import Image

# =========================================================
# DATASET SECTION
# Uncomment ONLY ONE SECTION
# =========================================================

# ---------------------------------------------------------
# OPTION 1 : CSV DATASET
# ---------------------------------------------------------

df = pd.read_csv("data.csv")

# ---------------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# ---------------------------------------------------------

# data = {
#     "Hours": [1,2,3,4,5,6,7,8,9,10],
#     "Attendance": [50,55,60,65,70,75,80,85,90,95],
#     "Pass": [0,0,0,0,1,1,1,1,1,1]
# }

# df = pd.DataFrame(data)

# =========================================================
# VIEW DATA
# =========================================================

print("\nDataset:\n")

print(df)

# =========================================================
# FEATURES AND TARGET
# =========================================================

X = df.iloc[:, :-1]

y = df.iloc[:, -1]

# =========================================================
# ENTROPY FUNCTION
# =========================================================

def entropy(column):

    values, counts = np.unique(
        column,
        return_counts=True
    )

    ent = 0

    for count in counts:

        p = count / np.sum(counts)

        ent += -p * np.log2(p)

    return ent

# =========================================================
# INFORMATION GAIN FUNCTION
# =========================================================

def information_gain(data, feature, target):

    print("\n===================================")

    print("FEATURE:", feature)

    print("===================================")

    total_entropy = entropy(
        data[target]
    )

    print("Parent Entropy:",
          total_entropy)

    values, counts = np.unique(
        data[feature],
        return_counts=True
    )

    weighted_entropy = 0

    for value, count in zip(values, counts):

        subset = data[
            data[feature] == value
        ]

        subset_entropy = entropy(
            subset[target]
        )

        weight = count / np.sum(counts)

        weighted_entropy += (
            weight * subset_entropy
        )

        print("\nValue:", value)

        print("Subset Entropy:",
              subset_entropy)

        print("Weight:",
              weight)

        print("Weighted Entropy:",
              weight * subset_entropy)

    ig = total_entropy - weighted_entropy

    print("\nFinal Weighted Entropy:",
          weighted_entropy)

    print("Information Gain:",
          ig)

    return ig

# =========================================================
# CALCULATE INFORMATION GAIN
# =========================================================

target_col = df.columns[-1]

ig_values = {}

for feature in X.columns:

    ig = information_gain(
        df,
        feature,
        target_col
    )

    ig_values[feature] = ig

# =========================================================
# BEST FEATURE
# =========================================================

best_feature = max(
    ig_values,
    key=ig_values.get
)

print("\n===================================")

print("BEST FEATURE")

print("===================================")

print(best_feature)

print("Information Gain:",
      ig_values[best_feature])

# =========================================================
# THRESHOLD
# =========================================================

threshold = df[
    best_feature
].mean()

print("\nThreshold:",
      threshold)

# =========================================================
# PREDICTIONS
# =========================================================

y_pred = []

for value in df[best_feature]:

    if value >= threshold:
        y_pred.append(1)

    else:
        y_pred.append(0)

# =========================================================
# ACCURACY
# =========================================================

accuracy = accuracy_score(
    y,
    y_pred
)

print("\nAccuracy:",
      accuracy)

# =========================================================
# CONFUSION MATRIX
# =========================================================

cm = confusion_matrix(
    y,
    y_pred
)

print("\nConfusion Matrix:\n")

print(cm)

# =========================================================
# CLASSIFICATION REPORT
# =========================================================

report = classification_report(
    y,
    y_pred
)

print("\nClassification Report:\n")

print(report)

# =========================================================
# ACTUAL VS PREDICTED
# =========================================================

results = pd.DataFrame({
    "Actual": y,
    "Predicted": y_pred
})

print("\nActual vs Predicted:\n")

print(results)

# =========================================================
# VISUALIZATION 1
# CONFUSION MATRIX
# =========================================================

plt.figure(figsize=(6,5))

plt.imshow(cm)

plt.title(
    "Confusion Matrix",
    fontsize=16
)

plt.colorbar()

plt.xlabel(
    "Predicted",
    fontsize=12
)

plt.ylabel(
    "Actual",
    fontsize=12
)

for i in range(len(cm)):
    for j in range(len(cm)):

        plt.text(
            j,
            i,
            cm[i][j],
            ha='center',
            va='center',
            color='red',
            fontsize=14
        )

plt.show()

# =========================================================
# GRAPHVIZ MANUAL TREE
# =========================================================

dot = Digraph()

# =========================================================
# ROOT NODE
# =========================================================

dot.node(
    'A',
    f'{best_feature} >= {threshold:.2f}',
    shape='ellipse',
    style='filled',
    fillcolor='lightblue',
    fontsize='18'
)

# =========================================================
# CHILD NODES
# =========================================================

dot.node(
    'B',
    'Class = 1',
    shape='box',
    style='filled',
    fillcolor='lightgreen',
    fontsize='16'
)

dot.node(
    'C',
    'Class = 0',
    shape='box',
    style='filled',
    fillcolor='lightcoral',
    fontsize='16'
)

# =========================================================
# CONNECTIONS
# =========================================================

dot.edge(
    'A',
    'B',
    label='Yes',
    fontsize='14'
)

dot.edge(
    'A',
    'C',
    label='No',
    fontsize='14'
)

# =========================================================
# SAVE TREE
# =========================================================

dot.render(
    'manual_decision_tree',
    format='png',
    cleanup=True
)

# =========================================================
# DISPLAY TREE IMAGE
# =========================================================

img = Image.open(
    'manual_decision_tree.png'
)

plt.figure(figsize=(10,7))

plt.imshow(img)

plt.axis('off')

plt.title(
    "Manual Decision Tree Visualization",
    fontsize=18
)

plt.show()
