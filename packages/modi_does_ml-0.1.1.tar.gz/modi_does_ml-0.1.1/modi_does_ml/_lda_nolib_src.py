# =========================================================
# MANUAL LDA IMPLEMENTATION
# =========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report
)

# =========================================================
# WHAT IS LDA?
# =========================================================

# LDA maximizes:
#
# Between-Class Scatter
# ---------------------
# Within-Class Scatter
#
# Goal:
# -> Best separation between classes
#
# Scatter Matrices:
#
# SW -> Within-class scatter matrix
# SB -> Between-class scatter matrix
#
# Eigenvectors of:
#
# inv(SW) * SB
#
# give discriminant directions.

# =========================================================
# DATASET
# =========================================================

# OPTION 1 : CSV
# df = pd.read_csv("data.csv")

# OPTION 2 : HARDCODED DATASET

np.random.seed(42)

rows = 200

data = {
    "Feature1": np.random.randint(1,100,rows),
    "Feature2": np.random.randint(1,100,rows),
    "Feature3": np.random.randint(1,100,rows),
    "Feature4": np.random.randint(1,100,rows),
    "Feature5": np.random.randint(1,100,rows)
}

df = pd.DataFrame(data)

df["Target"] = np.random.randint(0,2,rows)

# =========================================================
# FEATURES + TARGET
# =========================================================

X = df.iloc[:, :-1].values

y = df.iloc[:, -1].values

# =========================================================
# TARGET DISTRIBUTION
# =========================================================

plt.figure(figsize=(6,5))

sns.countplot(x=y)

plt.title("Target Distribution")

plt.grid(True)

plt.show()

# =========================================================
# HEATMAP
# =========================================================

plt.figure(figsize=(10,8))

sns.heatmap(
    df.corr(),
    annot=True,
    cmap="coolwarm"
)

plt.title("Correlation Heatmap")

plt.show()

# =========================================================
# TRAIN TEST SPLIT
# =========================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# =========================================================
# SCALING
# =========================================================

scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)

X_test = scaler.transform(X_test)

# =========================================================
# COMPUTE CLASS MEANS
# =========================================================

mean_vectors = []

for cls in np.unique(y_train):

    mean_vectors.append(
        np.mean(
            X_train[y_train == cls],
            axis=0
        )
    )

# =========================================================
# WITHIN CLASS SCATTER MATRIX
# =========================================================

# Measures spread inside each class

SW = np.zeros((X_train.shape[1], X_train.shape[1]))

for cls, mv in zip(np.unique(y_train), mean_vectors):

    class_scatter = np.zeros((X_train.shape[1], X_train.shape[1]))

    for row in X_train[y_train == cls]:

        row = row.reshape(-1,1)

        mv = mv.reshape(-1,1)

        class_scatter += (row - mv).dot((row - mv).T)

    SW += class_scatter

# =========================================================
# BETWEEN CLASS SCATTER MATRIX
# =========================================================

# Measures separation between classes

overall_mean = np.mean(X_train, axis=0)

SB = np.zeros((X_train.shape[1], X_train.shape[1]))

for i, mean_vec in enumerate(mean_vectors):

    n = X_train[y_train == i].shape[0]

    mean_vec = mean_vec.reshape(-1,1)

    overall_mean_vec = overall_mean.reshape(-1,1)

    SB += n * (
        mean_vec - overall_mean_vec
    ).dot(
        (mean_vec - overall_mean_vec).T
    )

# =========================================================
# EIGEN DECOMPOSITION
# =========================================================

# Solving:
#
# inv(SW) * SB

A = np.linalg.inv(SW).dot(SB)

eigenvalues, eigenvectors = np.linalg.eig(A)

# =========================================================
# SORT EIGENVECTORS
# =========================================================

eigen_pairs = [

    (
        np.abs(eigenvalues[i]),
        eigenvectors[:,i]
    )

    for i in range(len(eigenvalues))
]

eigen_pairs.sort(
    key=lambda x: x[0],
    reverse=True
)

# =========================================================
# SELECT TOP COMPONENT
# =========================================================

W = eigen_pairs[0][1].reshape(-1,1)

# =========================================================
# PROJECT DATA
# =========================================================

X_train_lda = X_train.dot(W)

X_test_lda = X_test.dot(W)

# =========================================================
# SIMPLE CLASSIFICATION
# =========================================================

threshold = np.mean(X_train_lda)

y_pred = []

for value in X_test_lda:

    if value >= threshold:
        y_pred.append(1)
    else:
        y_pred.append(0)

y_pred = np.array(y_pred)

# =========================================================
# ACCURACY
# =========================================================

accuracy = accuracy_score(
    y_test,
    y_pred
)

print("\nAccuracy:")
print(accuracy)

# =========================================================
# CONFUSION MATRIX
# =========================================================

cm = confusion_matrix(
    y_test,
    y_pred
)

print("\nConfusion Matrix:")
print(cm)

# =========================================================
# CLASSIFICATION REPORT
# =========================================================

print("\nClassification Report:")

print(
    classification_report(
        y_test,
        y_pred
    )
)

# =========================================================
# CONFUSION MATRIX VISUALIZATION
# =========================================================

plt.figure(figsize=(6,5))

sns.heatmap(
    cm,
    annot=True,
    fmt='d',
    cmap='Blues'
)

plt.xlabel("Predicted")
plt.ylabel("Actual")

plt.title("Confusion Matrix")

plt.show()

# =========================================================
# LDA PROJECTION
# =========================================================

plt.figure(figsize=(8,6))

for label in np.unique(y_train):

    plt.scatter(
        X_train_lda[y_train == label],
        np.zeros_like(X_train_lda[y_train == label]),
        label=f"Class {label}"
    )

plt.xlabel("Linear Discriminant")

plt.title("LDA Projection")

plt.legend()

plt.grid(True)

plt.show()

# =========================================================
# EIGENVALUES
# =========================================================

print("\nEigenvalues:")

print(eigenvalues)

# =========================================================
# FEATURE IMPORTANCE
# =========================================================

importance_df = pd.DataFrame({

    "Feature": df.columns[:-1],
    "Weight": W.flatten()

})

print("\nFeature Importance:")

print(importance_df)

# =========================================================
# FEATURE IMPORTANCE GRAPH
# =========================================================

plt.figure(figsize=(8,6))

sns.barplot(
    x="Weight",
    y="Feature",
    data=importance_df
)

plt.title("LDA Feature Importance")

plt.show()