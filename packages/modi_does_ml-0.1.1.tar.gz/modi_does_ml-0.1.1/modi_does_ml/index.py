"""
mlcode — ML Code Reference Library
====================================
Central index: lists all modules and lets you generate .py files.
"""

import os
import shutil

# ──────────────────────────────────────────────────────────────
# REGISTRY
# ──────────────────────────────────────────────────────────────

_WITH_SK = [
    "linear_regression",
    "logistic_regression",
    "decision_tree",
    "random_forest",
    "svm_lineardata",
    "svm_nonlineardata",
    "k_means_clustering",
    "pca",
    "svd",
    "lda",
    "xgboost",
]

_WITHOUT_SK = [
    "linear_regression_nolib",
    "logistic_regression_nolib",
    "decision_tree_nolib",
    "random_forest_nolib",
    "svm_lineardata_nolib",
    "svm_nonlineardata_nolib",
    "k_means_clustering_nolib",
    "pca_nolib",
    "svd_nolib",
    "lda_nolib",
    "xgboost_nolib",
]

_SRC_MAP = {
    # with sklearn
    "linear_regression":         "_linear_regression_sk_src.py",
    "logistic_regression":       "_logistic_regression_sk_src.py",
    "decision_tree":             "_decision_tree_sk_src.py",
    "random_forest":             "_random_forest_sk_src.py",
    "svm_lineardata":            "_svm_nonlinear_sk_src.py",
    "svm_nonlineardata":         "_svm_nonlinear_sk_src.py",
    "k_means_clustering":        "_k_means_sk_src.py",
    "pca":                       "_pca_sk_src.py",
    "svd":                       "_svd_sk_src.py",
    "lda":                       "_lda_sk_src.py",
    "xgboost":                   "_xgboost_sk_src.py",
    # without sklearn
    "linear_regression_nolib":   "_linear_regression_nolib_src.py",
    "logistic_regression_nolib": "_logistic_regression_nolib_src.py",
    "decision_tree_nolib":       "_decision_tree_nolib_src.py",
    "random_forest_nolib":       "_random_forest_nolib_src.py",
    "svm_lineardata_nolib":      "_svm_linear_nolib_src.py",
    "svm_nonlineardata_nolib":   "_svm_nonlinear_nolib_src.py",
    "k_means_clustering_nolib":  "_k_means_nolib_src.py",
    "pca_nolib":                 "_pca_nolib_src.py",
    "svd_nolib":                 "_svd_sk_src.py",
    "lda_nolib":                 "_lda_nolib_src.py",
    "xgboost_nolib":             "_xgboost_nolib_src.py",
}

ALL_MODULES = _WITH_SK + _WITHOUT_SK


# ──────────────────────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────────────────────

def main():
    _print_banner()
    _interactive_menu()


# ──────────────────────────────────────────────────────────────
# BANNER
# ──────────────────────────────────────────────────────────────

def _print_banner():
    w = 54
    print("\n" + "=" * w)
    print("  modi_does_ml — ML Code Reference Library")
    print("=" * w)

    print("\nwith sklearn:")
    for name in _WITH_SK:
        print(f"    {name}")

    print("\nwithout sklearn:")
    for name in _WITHOUT_SK:
        print(f"    {name}")

    print("\nUsage:")
    print("    from modi_does_ml import index")
    print("    index.main()")
    print("\n  — OR —")
    print("\n    from modi_does_ml import index")
    print("    index.generate('linear_regression')")
    print("=" * w + "\n")


# ──────────────────────────────────────────────────────────────
# GENERATE  (non-interactive, callable directly)
# ──────────────────────────────────────────────────────────────

def generate(module_name: str, output_path: str = None):
    """
    Copy the source .py for *module_name* into the current directory
    (or *output_path* if given).

    Example
    -------
    >>> from mlcode import index
    >>> index.generate('pca')
    """
    if module_name not in _SRC_MAP:
        print(f"\n❌  Unknown module: '{module_name}'")
        print(f"    Run index.main() to see available modules.\n")
        return

    src_file = _SRC_MAP[module_name]
    src_path = os.path.join(os.path.dirname(__file__), src_file)

    dest_name = f"{module_name}.py"
    dest = output_path or os.path.join(os.getcwd(), dest_name)

    shutil.copy2(src_path, dest)
    print(f"\n✅  Created: {dest}\n")


# ──────────────────────────────────────────────────────────────
# INTERACTIVE MENU
# ──────────────────────────────────────────────────────────────

def _interactive_menu():
    print("Select a module to generate as a .py file.")
    print("Enter the number or name (or 'q' to quit):\n")

    all_mods = ALL_MODULES
    for i, name in enumerate(all_mods, 1):
        tag = "(sklearn)" if not name.endswith("_nolib") else "(no lib)"
        print(f"  [{i:>2}] {name}  {tag}")

    print()
    choice = input("Your choice: ").strip()

    if choice.lower() in ("q", "quit", "exit", ""):
        print("Bye!\n")
        return

    # numeric selection
    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(all_mods):
            module_name = all_mods[idx]
        else:
            print(f"\n❌  Number out of range.\n")
            return
    else:
        module_name = choice

    generate(module_name)
