import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

# -------------------------------------------------
# OPTION 1 : CSV DATASET
# -------------------------------------------------

# df = pd.read_csv("data.csv")
# -------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# -------------------------------------------------

data = {

    "Hours": [1,2,3,4,5,6,7,8,9,10],

    "Attendance": [
        50,55,60,65,70,
        75,80,85,90,95
    ],

    "Assignments": [
        1,1,2,2,3,
        3,4,4,5,5
    ],

    "Pass": [
        0,0,0,0,1,
        1,1,1,1,1
    ]
}


df = pd.DataFrame(data)

# ==========================================
# VIEW DATA
# ==========================================

print("\nDataset:")
print(df.head())

print("\nShape:", df.shape)

# ==========================================
# FEATURES AND TARGET
# ==========================================

# Last column as target
X = df.iloc[:, :-1]

# Last column as output
y = df.iloc[:, -1]

print("\nFeatures:")
print(X.head())

print("\nTarget:")
print(y.head())

# ==========================================
# TRAIN TEST SPLIT
# ==========================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# ==========================================
# MODEL CREATION
# ==========================================

model = LinearRegression()

# ==========================================
# TRAIN MODEL
# ==========================================

model.fit(X_train, y_train)

# ==========================================
# PREDICTION
# ==========================================

y_pred = model.predict(X_test)

# ==========================================
# METRICS
# ==========================================

mae = mean_absolute_error(y_test, y_pred)

mse = mean_squared_error(y_test, y_pred)

rmse = np.sqrt(mse)

r2 = r2_score(y_test, y_pred)

print("\n========= METRICS =========")

print("MAE  :", mae)

print("MSE  :", mse)

print("RMSE :", rmse)

print("R2 Score :", r2)

# ==========================================
# MODEL PARAMETERS
# ==========================================

print("\nIntercept:")

print(model.intercept_)

print("\nCoefficients:")

print(model.coef_)

# ==========================================
# ACTUAL VS PREDICTED TABLE
# ==========================================

results = pd.DataFrame({
    "Actual": y_test,
    "Predicted": y_pred
})

print("\nActual vs Predicted")

print(results)

# ==========================================
# VISUALIZATION 1
# ACTUAL VS PREDICTED
# ==========================================

plt.figure(figsize=(8,6))

plt.scatter(y_test, y_pred)

# Ideal prediction line

plt.plot(
    [y_test.min(), y_test.max()],
    [y_test.min(), y_test.max()],
    'r--'
)

plt.xlabel("Actual Values")

plt.ylabel("Predicted Values")

plt.title("Actual vs Predicted")

plt.grid(True)

plt.show()

# ==========================================
# VISUALIZATION 2
# REGRESSION LINE
# ONLY FOR SINGLE FEATURE
# ==========================================

if X.shape[1] == 1:

    plt.figure(figsize=(8,6))

    plt.scatter(X, y, label="Actual Data")

    plt.plot(X, model.predict(X), color='red',
             label="Regression Line")

    plt.xlabel(X.columns[0])

    plt.ylabel(y.name)

    plt.title("Linear Regression Line")

    plt.legend()

    plt.grid(True)

    plt.show()

# ==========================================
# SAMPLE CUSTOM PREDICTION
# ==========================================

# Example for single feature:
# new_data = [[9]]

# Example for multiple features:
# new_data = [[val1, val2, val3]]

# prediction = model.predict(new_data)

# print("\nCustom Prediction:", prediction)