# =========================================================
# MANUAL K-MEANS CLUSTERING
# GENERALIZED TEMPLATE
# =========================================================

import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

# =========================================================
# DATASET SECTION
# =========================================================

df = pd.read_csv("data.csv")

# =========================================================
# OPTION 2 : HARDCODED DATAFRAME
# =========================================================

# np.random.seed(42)
#
# data = {
#     "Feature1": np.random.randint(10, 100, 100),
#     "Feature2": np.random.randint(20, 120, 100),
#     "Feature3": np.random.randint(5, 80, 100),
#     "Feature4": np.random.randint(50, 150, 100),
#     "Feature5": np.random.randint(1, 60, 100)
# }
#
# df = pd.DataFrame(data)

# =========================================================
# VIEW DATA
# =========================================================

print("\nDataset Head:\n")

print(df.head())

print("\nDataset Shape:")

print(df.shape)

# =========================================================
# VISUALIZATION
# =========================================================

df.hist(figsize=(15,10))

plt.show()

sns.pairplot(df)

plt.show()

plt.figure(figsize=(10,8))

sns.heatmap(
    df.corr(),
    annot=True,
    cmap="coolwarm"
)

plt.show()

# =========================================================
# FEATURE SCALING
# =========================================================

# Scaling prevents large-value features
# from dominating distance calculations.

scaler = StandardScaler()

X_scaled = scaler.fit_transform(df)

# =========================================================
# NUMBER OF CLUSTERS
# =========================================================

k = 3

# =========================================================
# RANDOM INITIAL CENTROIDS
# =========================================================

# Random points are selected as initial centroids.

np.random.seed(42)

random_indices = np.random.choice(
    len(X_scaled),
    k,
    replace=False
)

centroids = X_scaled[random_indices]

# =========================================================
# MAX ITERATIONS
# =========================================================

max_iterations = 100

# =========================================================
# TRAINING LOOP
# =========================================================

for iteration in range(max_iterations):

    # =====================================================
    # DISTANCE CALCULATION
    # =====================================================

    # Euclidean distance measures similarity
    # between points and centroids.

    distances = np.sqrt(
        ((X_scaled - centroids[:, np.newaxis])**2).sum(axis=2)
    )

    # =====================================================
    # ASSIGN CLUSTERS
    # =====================================================

    # Each point is assigned to nearest centroid.

    clusters = np.argmin(distances, axis=0)

    # =====================================================
    # STORE OLD CENTROIDS
    # =====================================================

    old_centroids = centroids.copy()

    # =====================================================
    # UPDATE CENTROIDS
    # =====================================================

    # New centroid is mean of all points
    # belonging to that cluster.

    for i in range(k):

        points = X_scaled[clusters == i]

        if len(points) > 0:

            centroids[i] = points.mean(axis=0)

    # =====================================================
    # CHECK CONVERGENCE
    # =====================================================

    # Algorithm stops when centroids stop changing.

    if np.all(old_centroids == centroids):

        print("\nConvergence Reached")

        break

# =========================================================
# ADD CLUSTER COLUMN
# =========================================================

df["Cluster"] = clusters

# =========================================================
# CLUSTER COUNTS
# =========================================================

print("\nCluster Counts:\n")

print(df["Cluster"].value_counts())

# =========================================================
# CENTROIDS
# =========================================================

print("\nCentroids:\n")

print(centroids)

# =========================================================
# SILHOUETTE SCORE
# =========================================================

# Higher silhouette score means
# better cluster separation.

score = silhouette_score(X_scaled, clusters)

print("\nSilhouette Score:")

print(score)

# =========================================================
# CLUSTER VISUALIZATION
# =========================================================

plt.figure(figsize=(8,6))

plt.scatter(
    X_scaled[:,0],
    X_scaled[:,1],
    c=clusters,
    cmap='viridis'
)

plt.scatter(
    centroids[:,0],
    centroids[:,1],
    c='red',
    s=300,
    marker='X',
    label='Centroids'
)

plt.xlabel(df.columns[0])

plt.ylabel(df.columns[1])

plt.title("Manual K-Means Clusters")

plt.legend()

plt.grid(True)

plt.show()

# =========================================================
# PCA
# =========================================================

# PCA reduces dimensions for visualization.

pca = PCA(n_components=2)

X_pca = pca.fit_transform(X_scaled)

# =========================================================
# PCA VISUALIZATION
# =========================================================

plt.figure(figsize=(8,6))

scatter = plt.scatter(
    X_pca[:,0],
    X_pca[:,1],
    c=clusters,
    cmap='rainbow'
)

plt.xlabel("PCA Component 1")

plt.ylabel("PCA Component 2")

plt.title("PCA Projection")

plt.colorbar(scatter)

plt.grid(True)

plt.show()

# =========================================================
# CLUSTER SUMMARY
# =========================================================

cluster_summary = df.groupby("Cluster").mean()

print(cluster_summary)

# =========================================================
# CLUSTER HEATMAP
# =========================================================

plt.figure(figsize=(10,6))

sns.heatmap(
    cluster_summary,
    annot=True,
    cmap="YlGnBu"
)

plt.title("Cluster-wise Feature Mean")

plt.show()

# =========================================================
# CUSTOM PREDICTION
# =========================================================

# new_data = [[50,60,30,100,25]]

# new_data_scaled = scaler.transform(new_data)

# Distance from new point to all centroids

# distances = np.sqrt(
#     ((new_data_scaled - centroids)**2).sum(axis=1)
# )

# Nearest centroid becomes predicted cluster

# prediction = np.argmin(distances)

# print("\nPredicted Cluster:", prediction)