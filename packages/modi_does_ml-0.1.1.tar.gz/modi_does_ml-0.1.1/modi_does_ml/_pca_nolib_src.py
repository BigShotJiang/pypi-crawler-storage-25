# =========================================================
# MANUAL PCA
# =========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler

# =========================================================
# DATASET SECTION
# Uncomment ONLY ONE SECTION
# =========================================================

# ---------------------------------------------------------
# OPTION 1 : CSV DATASET
# ---------------------------------------------------------

df = pd.read_csv("data.csv")

# ---------------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# ---------------------------------------------------------

# data = {
#     "Feature1": [2,3,4,5,6,7,8,9,10,11],
#     "Feature2": [1,2,1,3,4,5,6,7,8,9],
#     "Feature3": [5,6,7,8,9,10,11,12,13,14],
#     "Feature4": [9,8,7,6,5,4,3,2,1,0]
# }

# df = pd.DataFrame(data)

# =========================================================
# VIEW DATA
# =========================================================

print("\nDataset:\n")

print(df.head())

# =========================================================
# FEATURES
# =========================================================

X = df.values

# =========================================================
# STANDARDIZATION
# =========================================================

scaler = StandardScaler()

X_scaled = scaler.fit_transform(X)

# =========================================================
# COVARIANCE MATRIX
# =========================================================

cov_matrix = np.cov(
    X_scaled.T
)

print("\nCovariance Matrix:\n")

print(cov_matrix)

# =========================================================
# EIGENVALUES & EIGENVECTORS
# =========================================================

eigenvalues, eigenvectors = np.linalg.eig(
    cov_matrix
)

print("\nEigenvalues:\n")

print(eigenvalues)

print("\nEigenvectors:\n")

print(eigenvectors)

# =========================================================
# SORT EIGENVALUES
# =========================================================

sorted_index = np.argsort(
    eigenvalues
)[::-1]

sorted_eigenvalues = eigenvalues[
    sorted_index
]

sorted_eigenvectors = eigenvectors[
    :,
    sorted_index
]

print("\nSorted Eigenvalues:\n")

print(sorted_eigenvalues)

# =========================================================
# EXPLAINED VARIANCE RATIO
# =========================================================

variance_ratio = (
    sorted_eigenvalues /
    np.sum(sorted_eigenvalues)
)

print("\nExplained Variance Ratio:\n")

print(variance_ratio)

# =========================================================
# SELECT TOP 2 COMPONENTS
# =========================================================

principal_components = (
    sorted_eigenvectors[:, :2]
)

print("\nPrincipal Components:\n")

print(principal_components)

# =========================================================
# TRANSFORM DATA
# =========================================================

X_pca = np.dot(
    X_scaled,
    principal_components
)

print("\nPCA Transformed Data:\n")

print(X_pca)

# =========================================================
# VISUALIZATION 1
# SCREE PLOT
# =========================================================

plt.figure(figsize=(8,6))

plt.plot(
    range(1, len(variance_ratio)+1),
    variance_ratio,
    marker='o'
)

plt.xlabel("Principal Components")

plt.ylabel("Explained Variance Ratio")

plt.title("Scree Plot")

plt.grid(True)

plt.show()

# =========================================================
# VISUALIZATION 2
# VARIANCE VS COMPONENTS
# =========================================================

plt.figure(figsize=(8,6))

plt.plot(
    range(1, len(variance_ratio)+1),
    np.cumsum(variance_ratio),
    marker='o'
)

plt.xlabel("Number of Components")

plt.ylabel("Cumulative Variance")

plt.title("Variance vs Components")

plt.grid(True)

plt.show()

# =========================================================
# VISUALIZATION 3
# PCA 2D VISUALIZATION
# =========================================================

plt.figure(figsize=(8,6))

plt.scatter(
    X_pca[:,0],
    X_pca[:,1]
)

plt.xlabel("PC1")

plt.ylabel("PC2")

plt.title("Manual PCA Visualization")

plt.grid(True)

plt.show()