# ==========================================
# MANUAL LINEAR SVM CLASSIFICATION
# GENERALIZED TEMPLATE
# ==========================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    ConfusionMatrixDisplay
)

from sklearn.decomposition import PCA

# ==========================================
# DATASET SECTION
# ==========================================

df = pd.read_csv("data.csv")

# ==========================================
# OPTION 2 : HARDCODED DATAFRAME
# ==========================================

# np.random.seed(42)
#
# data = {
#     "Feature1": np.random.randint(1, 100, 100),
#     "Feature2": np.random.randint(1, 100, 100),
#     "Feature3": np.random.randint(1, 100, 100),
#     "Feature4": np.random.randint(1, 100, 100),
#     "Feature5": np.random.randint(1, 100, 100),
#     "Target": np.random.randint(0, 2, 100)
# }
#
# df = pd.DataFrame(data)

# ==========================================
# VIEW DATA
# ==========================================

print(df.head())

print("\nShape:", df.shape)

# ==========================================
# FEATURES AND TARGET
# ==========================================

X = df.iloc[:, :-1]

y = df.iloc[:, -1]

# ==========================================
# CONVERT TARGET TO {-1, +1}
# ==========================================

# Manual SVM math works on:
# negative class = -1
# positive class = +1

y_manual = np.where(y == 0, -1, 1)

# ==========================================
# FEATURE SCALING
# ==========================================

# Scaling helps SVM create
# balanced decision boundaries.

scaler = StandardScaler()

X_scaled = scaler.fit_transform(X)

# ==========================================
# TRAIN TEST SPLIT
# ==========================================

X_train, X_test, y_train, y_test = train_test_split(
    X_scaled,
    y,
    test_size=0.2,
    random_state=42
)

X_train_manual, X_test_manual, y_train_manual, y_test_manual = train_test_split(
    X_scaled,
    y_manual,
    test_size=0.2,
    random_state=42
)

# ==========================================
# MANUAL SVM CLASS
# ==========================================

class ManualSVM:

    def __init__(
        self,
        learning_rate=0.001,
        lambda_param=0.01,
        n_iters=1000
    ):

        # learning rate controls update step size

        self.lr = learning_rate

        # regularization reduces overfitting

        self.lambda_param = lambda_param

        self.n_iters = n_iters

        self.w = None

        self.b = None

    # ======================================
    # TRAIN MODEL
    # ======================================

    def fit(self, X, y):

        n_samples, n_features = X.shape

        self.w = np.zeros(n_features)

        self.b = 0

        # Gradient descent updates weights
        # to maximize margin.

        for _ in range(self.n_iters):

            for idx, x_i in enumerate(X):

                # SVM condition:
                # y(w.x - b) >= 1

                condition = y[idx] * (
                    np.dot(x_i, self.w) - self.b
                ) >= 1

                # correctly classified point

                if condition:

                    self.w -= self.lr * (
                        2 * self.lambda_param * self.w
                    )

                # misclassified point

                else:

                    self.w -= self.lr * (
                        2 * self.lambda_param * self.w
                        - np.dot(x_i, y[idx])
                    )

                    self.b -= self.lr * y[idx]

    # ======================================
    # PREDICT
    # ======================================

    def predict(self, X):

        # Hyperplane equation:
        # w.x - b

        linear_output = np.dot(X, self.w) - self.b

        # sign converts values into:
        # positive -> +1
        # negative -> -1

        return np.sign(linear_output)

# ==========================================
# MODEL CREATION
# ==========================================

model = ManualSVM()

# ==========================================
# TRAIN MODEL
# ==========================================

model.fit(X_train_manual, y_train_manual)

# ==========================================
# PREDICTION
# ==========================================

y_pred_manual = model.predict(X_test_manual)

# Convert predictions back:
# -1 -> 0
# +1 -> 1

y_pred = np.where(y_pred_manual == -1, 0, 1)

# ==========================================
# ACCURACY
# ==========================================

accuracy = accuracy_score(y_test, y_pred)

print("\nAccuracy:", accuracy)

# ==========================================
# CONFUSION MATRIX
# ==========================================

cm = confusion_matrix(y_test, y_pred)

print("\nConfusion Matrix:\n")

print(cm)

# ==========================================
# CLASSIFICATION REPORT
# ==========================================

print("\nClassification Report:\n")

print(classification_report(y_test, y_pred))

# ==========================================
# CONFUSION MATRIX VISUALIZATION
# ==========================================

disp = ConfusionMatrixDisplay(
    confusion_matrix=cm
)

disp.plot(cmap='Blues')

plt.title("Confusion Matrix")

plt.show()

# ==========================================
# PCA FOR VISUALIZATION
# ==========================================

pca = PCA(n_components=2)

X_pca = pca.fit_transform(X_scaled)

# ==========================================
# TRAIN MODEL ON PCA DATA
# ==========================================

model_vis = ManualSVM()

model_vis.fit(X_pca, y_manual)

# ==========================================
# HYPERPLANE VISUALIZATION
# ==========================================

def plot_hyperplane(X, y, model):

    plt.figure(figsize=(8,6))

    plt.scatter(
        X[:, 0],
        X[:, 1],
        c=y,
        cmap='bwr',
        edgecolors='k'
    )

    ax = plt.gca()

    xlim = ax.get_xlim()

    ylim = ax.get_ylim()

    xx = np.linspace(xlim[0], xlim[1], 50)

    yy = np.linspace(ylim[0], ylim[1], 50)

    YY, XX = np.meshgrid(yy, xx)

    xy = np.vstack([XX.ravel(), YY.ravel()]).T

    # Hyperplane equation:
    # w.x - b

    Z = np.dot(xy, model.w) - model.b

    Z = Z.reshape(XX.shape)

    ax.contour(
        XX,
        YY,
        Z,
        colors='black',
        levels=[-1, 0, 1],
        linestyles=['--', '-', '--']
    )

    plt.title("Manual SVM Hyperplane")

    plt.xlabel("Principal Component 1")

    plt.ylabel("Principal Component 2")

    plt.grid(True)

    plt.show()

plot_hyperplane(X_pca, y, model_vis)

# ==========================================
# MODEL PARAMETERS
# ==========================================

print("\nWeights:\n")

print(model.w)

print("\nBias:\n")

print(model.b)

# ==========================================
# CUSTOM PREDICTION
# ==========================================

# new_data = [[10,20,30,40,50]]

# new_data_scaled = scaler.transform(new_data)

# prediction = model.predict(new_data_scaled)

# prediction = np.where(prediction == -1, 0, 1)

# print("\nPrediction:", prediction)