# =========================================================
# MANUAL BOOSTING / XGBOOST CONCEPT
# WITHOUT XGBOOST LIBRARY
# =========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split

from sklearn.tree import DecisionTreeRegressor

from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

# =========================================================
# DATASET SECTION
# Uncomment ONLY ONE SECTION
# =========================================================

# ---------------------------------------------------------
# OPTION 1 : CSV DATASET
# ---------------------------------------------------------

df = pd.read_csv("data.csv")

# ---------------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# ---------------------------------------------------------

# data = {
#     "Hours": [1,2,3,4,5,6,7,8,9,10],
#     "Marks": [10,20,30,40,50,60,70,80,90,100]
# }

# df = pd.DataFrame(data)

# =========================================================
# VIEW DATA
# =========================================================

print("\nDataset:\n")

print(df.head())

# =========================================================
# FEATURES AND TARGET
# =========================================================

X = df.iloc[:, :-1]

y = df.iloc[:, -1]

# =========================================================
# TRAIN TEST SPLIT
# =========================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# =========================================================
# FIRST WEAK LEARNER
# =========================================================

model1 = DecisionTreeRegressor(
    max_depth=1
)

model1.fit(X_train, y_train)

pred1 = model1.predict(X_train)

# =========================================================
# RESIDUALS
# =========================================================

residuals = y_train - pred1

# =========================================================
# SECOND MODEL LEARNS RESIDUALS
# =========================================================

model2 = DecisionTreeRegressor(
    max_depth=1
)

model2.fit(X_train, residuals)

pred2 = model2.predict(X_test)

# =========================================================
# FINAL PREDICTION
# =========================================================

test_pred1 = model1.predict(X_test)

final_pred = test_pred1 + pred2

# =========================================================
# METRICS
# =========================================================

mae = mean_absolute_error(
    y_test,
    final_pred
)

mse = mean_squared_error(
    y_test,
    final_pred
)

rmse = np.sqrt(mse)

r2 = r2_score(
    y_test,
    final_pred
)

print("\n========= METRICS =========")

print("MAE :", mae)

print("MSE :", mse)

print("RMSE:", rmse)

print("R2 Score:", r2)

# =========================================================
# ACTUAL VS PREDICTED
# =========================================================

results = pd.DataFrame({
    "Actual": y_test,
    "Predicted": final_pred
})

print("\nActual vs Predicted:\n")

print(results)

# =========================================================
# VISUALIZATION 1
# RESIDUAL PLOT
# =========================================================

plt.figure(figsize=(8,6))

plt.scatter(
    range(len(residuals)),
    residuals
)

plt.axhline(
    y=0,
    color='red',
    linestyle='--'
)

plt.xlabel("Data Points")

plt.ylabel("Residuals")

plt.title("Residual Plot")

plt.grid(True)

plt.show()

# =========================================================
# VISUALIZATION 2
# ACTUAL VS PREDICTED
# =========================================================

plt.figure(figsize=(8,6))

plt.scatter(
    y_test,
    final_pred
)

plt.plot(
    [y_test.min(), y_test.max()],
    [y_test.min(), y_test.max()],
    'r--'
)

plt.xlabel("Actual")

plt.ylabel("Predicted")

plt.title("Actual vs Predicted")

plt.grid(True)

plt.show()

# =========================================================
# VISUALIZATION 3
# FIRST WEAK LEARNER
# =========================================================

if X.shape[1] == 1:

    plt.figure(figsize=(8,6))

    plt.scatter(
        X_train,
        y_train,
        label="Actual Data"
    )

    plt.plot(
        X_train,
        pred1,
        color='red',
        label="Weak Learner 1"
    )

    plt.xlabel(X.columns[0])

    plt.ylabel(df.columns[-1])

    plt.title("First Weak Learner")

    plt.legend()

    plt.grid(True)

    plt.show()

# =========================================================
# CUSTOM PREDICTION
# =========================================================

# Example:
# new_data = [[6]]

# pred_first = model1.predict(new_data)

# pred_second = model2.predict(new_data)

# final_prediction = pred_first + pred_second

# print("\nPrediction:", final_prediction)