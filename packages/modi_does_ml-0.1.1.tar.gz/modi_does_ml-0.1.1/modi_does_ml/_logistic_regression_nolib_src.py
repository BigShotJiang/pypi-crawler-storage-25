# =====================================================
# MANUAL LOGISTIC REGRESSION
# =====================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    auc
)

# =====================================================
# DATASET SECTION
# Uncomment ONLY ONE SECTION
# =====================================================

# -----------------------------------------------------
# OPTION 1 : CSV DATASET
# -----------------------------------------------------

df = pd.read_csv("data.csv")

# -----------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# -----------------------------------------------------

# data = {
#     "Hours": [1,2,3,4,5,6,7,8,9,10],
#     "Pass":  [0,0,0,0,1,1,1,1,1,1]
# }

# df = pd.DataFrame(data)

# =====================================================
# FEATURES AND TARGET
# =====================================================

# ONLY SINGLE FEATURE SUPPORTED

X = df.iloc[:, 0].values

y = df.iloc[:, -1].values

# =====================================================
# TRAIN TEST SPLIT
# =====================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# =====================================================
# NORMALIZATION
# =====================================================

X_train = (X_train - np.mean(X_train)) / np.std(X_train)

X_test = (X_test - np.mean(X_test)) / np.std(X_test)

# =====================================================
# INITIALIZE PARAMETERS
# =====================================================

w = 0
b = 0

learning_rate = 0.01

epochs = 1000

# =====================================================
# SIGMOID FUNCTION
# =====================================================

def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# =====================================================
# TRAINING USING GRADIENT DESCENT
# =====================================================

n = len(X_train)

for epoch in range(epochs):

    linear_model = (w * X_train) + b

    y_pred = sigmoid(linear_model)

    # gradients

    dw = (1/n) * np.sum((y_pred - y_train) * X_train)

    db = (1/n) * np.sum(y_pred - y_train)

    # update parameters

    w = w - learning_rate * dw

    b = b - learning_rate * db

print("\nWeight:", w)

print("Bias:", b)

# =====================================================
# TEST PREDICTIONS
# =====================================================

linear_test = (w * X_test) + b

probabilities = sigmoid(linear_test)

y_pred_classes = []

for p in probabilities:

    if p >= 0.5:
        y_pred_classes.append(1)
    else:
        y_pred_classes.append(0)

y_pred_classes = np.array(y_pred_classes)

# =====================================================
# ACCURACY
# =====================================================

accuracy = accuracy_score(
    y_test,
    y_pred_classes
)

print("\nAccuracy:", accuracy)

# =====================================================
# CONFUSION MATRIX
# =====================================================

cm = confusion_matrix(
    y_test,
    y_pred_classes
)

print("\nConfusion Matrix:")

print(cm)

# =====================================================
# CLASSIFICATION REPORT
# =====================================================

report = classification_report(
    y_test,
    y_pred_classes
)

print("\nClassification Report:\n")

print(report)

# =====================================================
# VISUALIZATION 1
# CONFUSION MATRIX
# =====================================================

plt.figure(figsize=(6,5))

plt.imshow(cm)

plt.title("Confusion Matrix")

plt.colorbar()

plt.xlabel("Predicted")

plt.ylabel("Actual")

for i in range(len(cm)):
    for j in range(len(cm)):
        plt.text(j, i, cm[i][j],
                 ha='center',
                 va='center',
                 color='red')

plt.show()

# =====================================================
# VISUALIZATION 2
# ROC CURVE
# =====================================================

fpr, tpr, thresholds = roc_curve(
    y_test,
    probabilities
)

roc_auc = auc(fpr, tpr)

plt.figure(figsize=(7,6))

plt.plot(fpr, tpr,
         label=f"AUC = {roc_auc:.2f}")

plt.plot([0,1], [0,1], 'r--')

plt.xlabel("False Positive Rate")

plt.ylabel("True Positive Rate")

plt.title("ROC Curve")

plt.legend()

plt.grid(True)

plt.show()

# =====================================================
# VISUALIZATION 3
# SIGMOID CURVE
# =====================================================

plt.figure(figsize=(8,6))

plt.scatter(X_train, y_train)

x_line = np.linspace(
    X_train.min(),
    X_train.max(),
    100
)

y_line = sigmoid((w * x_line) + b)

plt.plot(x_line, y_line,
         color='red')

plt.xlabel("Feature")

plt.ylabel("Probability")

plt.title("Sigmoid Curve")

plt.grid(True)

plt.show()

# =====================================================
# CUSTOM PREDICTION
# =====================================================

# Example:

# x = 2

# x = (x - np.mean(X_train)) / np.std(X_train)

# prob = sigmoid((w * x) + b)

# if prob >= 0.5:
#     pred = 1
# else:
#     pred = 0

# print("\nProbability:", prob)

# print("Prediction:", pred)