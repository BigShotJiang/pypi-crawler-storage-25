"""
modi_does_ml — ML Code Reference Library
========================================
Provides ready-to-use ML algorithm templates,
both with and without sklearn.

Quick start
-----------
>>> from modi_does_ml import index
>>> index.main()          # interactive menu + file generator

>>> index.generate('pca')              # creates pca.py in cwd
>>> index.generate('k_means_nolib')    # creates k_means_nolib.py in cwd
"""

from . import index

__version__ = "0.1.0"
__all__ = ["index"]
