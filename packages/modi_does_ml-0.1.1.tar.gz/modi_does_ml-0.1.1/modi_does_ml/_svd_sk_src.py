# =========================================================
# SVD USING SKLEARN
# =========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import TruncatedSVD
from sklearn.metrics import mean_squared_error

# =========================================================
# WHAT IS SVD?
# =========================================================

# SVD decomposes matrix A into:
#
# A = U Σ Vᵀ
#
# U  -> left singular vectors
# Σ  -> singular values
# Vᵀ -> right singular vectors
#
# Used for:
# -> Dimensionality Reduction
# -> Noise Reduction
# -> Compression
# -> Feature Extraction

# =========================================================
# DATASET
# =========================================================

# OPTION 1 : CSV
# df = pd.read_csv("data.csv")

# OPTION 2 : HARDCODED DATASET

np.random.seed(42)
rows = 120

data = {
    "Feature1": np.random.randint(1,100,rows),
    "Feature2": np.random.randint(1,100,rows),
    "Feature3": np.random.randint(1,100,rows),
    "Feature4": np.random.randint(1,100,rows),
    "Feature5": np.random.randint(1,100,rows),
    "Feature6": np.random.randint(1,100,rows)
}

df = pd.DataFrame(data)

# =========================================================
# VIEW DATASET
# =========================================================

print("\n========== DATASET ==========\n")
print(df.head())

print("\nDataset Shape:")
print(df.shape)

# =========================================================
# HEATMAP
# =========================================================

plt.figure(figsize=(10,8))

sns.heatmap(
    df.corr(),
    annot=True,
    cmap="coolwarm"
)

plt.title("Correlation Heatmap")

plt.show()

# =========================================================
# FEATURES
# =========================================================

X = df.values

# =========================================================
# STANDARDIZATION
# =========================================================

# SVD performs better on scaled data

scaler = StandardScaler()

X_scaled = scaler.fit_transform(X)

# =========================================================
# SVD MODEL
# =========================================================

# A = U Σ Vᵀ

svd = TruncatedSVD(n_components=2)

# =========================================================
# TRAIN MODEL
# =========================================================

X_svd = svd.fit_transform(X_scaled)

# =========================================================
# EXPLAINED VARIANCE
# =========================================================

variance = svd.explained_variance_ratio_

print("\n========== EXPLAINED VARIANCE ==========\n")

print("Variance Ratio:")
print(variance)

print("\nTotal Variance Retained:")
print(np.sum(variance))

# =========================================================
# SINGULAR VALUES
# =========================================================

print("\n========== SINGULAR VALUES ==========\n")

print(svd.singular_values_)

# =========================================================
# REDUCED DATASET
# =========================================================

reduced_df = pd.DataFrame(
    X_svd,
    columns=["Component1", "Component2"]
)

print("\n========== REDUCED DATA ==========\n")

print(reduced_df.head())

# =========================================================
# 2D VISUALIZATION
# =========================================================

plt.figure(figsize=(8,6))

plt.scatter(
    reduced_df["Component1"],
    reduced_df["Component2"]
)

plt.xlabel("Component 1")
plt.ylabel("Component 2")

plt.title("2D SVD Projection")

plt.grid(True)

plt.show()

# =========================================================
# SCREE PLOT
# =========================================================

plt.figure(figsize=(7,5))

plt.plot(
    range(1, len(variance)+1),
    variance,
    marker='o'
)

plt.xlabel("Components")
plt.ylabel("Explained Variance Ratio")

plt.title("Scree Plot")

plt.grid(True)

plt.show()

# =========================================================
# RECONSTRUCTION
# =========================================================

X_reconstructed = svd.inverse_transform(X_svd)

# =========================================================
# RECONSTRUCTION ERROR
# =========================================================

mse = mean_squared_error(
    X_scaled,
    X_reconstructed
)

print("\n========== RECONSTRUCTION ERROR ==========\n")

print(mse)

# =========================================================
# ORIGINAL VS RECONSTRUCTED
# =========================================================

plt.figure(figsize=(10,6))

plt.plot(
    X_scaled[0],
    label="Original"
)

plt.plot(
    X_reconstructed[0],
    label="Reconstructed"
)

plt.title("Original vs Reconstructed")

plt.legend()

plt.grid(True)

plt.show()

# =========================================================
# COMPONENT MATRIX
# =========================================================

component_df = pd.DataFrame(
    svd.components_,
    columns=df.columns
)

print("\n========== COMPONENT MATRIX ==========\n")

print(component_df)

# =========================================================
# COMPONENT HEATMAP
# =========================================================

plt.figure(figsize=(10,4))

sns.heatmap(
    component_df,
    annot=True,
    cmap="viridis"
)

plt.title("SVD Component Heatmap")

plt.show()