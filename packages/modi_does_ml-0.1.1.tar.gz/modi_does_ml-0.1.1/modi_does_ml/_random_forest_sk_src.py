# =========================================================
# RANDOM FOREST CLASSIFICATION
# USING SKLEARN TRAINING
# FULLY COMMENTED FOR ML + MATH UNDERSTANDING
# =========================================================

# =========================================================
# IMPORT LIBRARIES
# =========================================================

# Data handling
import pandas as pd
import numpy as np

# Visualization
import matplotlib.pyplot as plt
import seaborn as sns

# Train Test Split
from sklearn.model_selection import train_test_split

# Random Forest Model
from sklearn.ensemble import RandomForestClassifier

# Metrics
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    auc
)

# =========================================================
# WHAT IS RANDOM FOREST?
# =========================================================

# Random Forest is an Ensemble Learning Algorithm.
#
# Ensemble:
# -> Combining multiple models together.
#
# Random Forest uses MANY Decision Trees.
#
# Final prediction:
#
# Classification:
# -> Majority Voting
#
# Regression:
# -> Average Prediction
#
# Main idea:
# -> Multiple weak trees together create
#    a strong model.

# =========================================================
# DATASET SECTION
# Uncomment ONLY ONE SECTION
# =========================================================

# ---------------------------------------------------------
# OPTION 1 : CSV DATASET
# ---------------------------------------------------------

df = pd.read_csv("data.csv")

# ---------------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# ---------------------------------------------------------

# np.random.seed(42)
#
# rows = 120
#
# data = {
#     "Feature1": np.random.randint(1, 100, rows),
#     "Feature2": np.random.randint(1, 100, rows),
#     "Feature3": np.random.randint(1, 100, rows),
#     "Feature4": np.random.randint(1, 100, rows),
#     "Feature5": np.random.randint(1, 100, rows),
# }
#
# df = pd.DataFrame(data)
#
# df["Target"] = np.random.randint(0, 2, rows)

# =========================================================
# VIEW DATASET
# =========================================================

print("\n========== DATASET ==========\n")

print(df.head())

print("\nDataset Shape:")

print(df.shape)

# =========================================================
# FEATURES AND TARGET
# =========================================================

X = df.iloc[:, :-1]

y = df.iloc[:, -1]

# =========================================================
# TARGET DISTRIBUTION
# =========================================================

# Helps identify:
# -> balanced classes
# -> imbalanced classes

plt.figure(figsize=(6,5))

sns.countplot(x=y)

plt.title("Target Distribution")

plt.grid(True)

plt.show()

# =========================================================
# CORRELATION HEATMAP
# =========================================================

# Correlation shows relationship between features.
#
# +1 -> strong positive relation
# -1 -> strong negative relation
#  0 -> no relation

plt.figure(figsize=(10,8))

sns.heatmap(
    df.corr(),
    annot=True,
    cmap="coolwarm",
    fmt=".2f"
)

plt.title("Correlation Heatmap")

plt.show()

# =========================================================
# TRAIN TEST SPLIT
# =========================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# =========================================================
# MODEL CREATION
# =========================================================

model = RandomForestClassifier(
    n_estimators=100,
    criterion="gini",
    random_state=42
)

# n_estimators:
# -> number of trees
#
# criterion:
# -> splitting method
#
# Gini Formula:
#
# Gini = 1 - Σ(p²)

# =========================================================
# TRAIN MODEL
# =========================================================

# Each tree learns from random samples.
#
# Final prediction combines outputs
# from all trees.

model.fit(X_train, y_train)

# =========================================================
# PREDICTIONS
# =========================================================

y_pred = model.predict(X_test)

# Probability predictions
# Needed for ROC Curve

y_prob = model.predict_proba(X_test)

# =========================================================
# ACCURACY
# =========================================================

# Accuracy =
#
# Correct Predictions / Total Predictions

accuracy = accuracy_score(y_test, y_pred)

print("\n========== ACCURACY ==========\n")

print("Accuracy:", accuracy)

# =========================================================
# CONFUSION MATRIX
# =========================================================

cm = confusion_matrix(y_test, y_pred)

print("\n========== CONFUSION MATRIX ==========\n")

print(cm)

# =========================================================
# CLASSIFICATION REPORT
# =========================================================

# Precision:
# TP / (TP + FP)
#
# Recall:
# TP / (TP + FN)
#
# F1 Score:
# Harmonic mean of precision and recall

print("\n========== CLASSIFICATION REPORT ==========\n")

print(classification_report(y_test, y_pred))

# =========================================================
# CONFUSION MATRIX VISUALIZATION
# =========================================================

plt.figure(figsize=(6,5))

sns.heatmap(
    cm,
    annot=True,
    fmt="d",
    cmap="Blues"
)

plt.xlabel("Predicted")

plt.ylabel("Actual")

plt.title("Confusion Matrix")

plt.show()

# =========================================================
# ROC CURVE
# =========================================================

if len(np.unique(y)) == 2:

    y_prob_binary = y_prob[:, 1]

    fpr, tpr, thresholds = roc_curve(
        y_test,
        y_prob_binary
    )

    roc_auc = auc(fpr, tpr)

    plt.figure(figsize=(7,6))

    plt.plot(
        fpr,
        tpr,
        label=f"AUC = {roc_auc:.2f}"
    )

    plt.plot([0,1], [0,1], 'r--')

    plt.xlabel("False Positive Rate")

    plt.ylabel("True Positive Rate")

    plt.title("ROC Curve")

    plt.legend()

    plt.grid(True)

    plt.show()

# =========================================================
# FEATURE IMPORTANCE
# =========================================================

# Feature importance tells which feature
# contributes most during prediction.

importance = model.feature_importances_

importance_df = pd.DataFrame({

    "Feature": X.columns,
    "Importance": importance

})

importance_df = importance_df.sort_values(
    by="Importance",
    ascending=False
)

print("\n========== FEATURE IMPORTANCE ==========\n")

print(importance_df)

# =========================================================
# FEATURE IMPORTANCE GRAPH
# =========================================================

plt.figure(figsize=(8,6))

sns.barplot(
    x="Importance",
    y="Feature",
    data=importance_df
)

plt.title("Feature Importance")

plt.show()

# =========================================================
# CUSTOM PREDICTION
# =========================================================

# Example:
# new_data = [[10,20,30,40,50]]

# prediction = model.predict(new_data)

# print("\nPrediction:", prediction)

# =========================================================
# MODEL INFORMATION
# =========================================================

print("\n========== MODEL INFO ==========\n")

print("Number of Trees:", model.n_estimators)

print("Criterion:", model.criterion)