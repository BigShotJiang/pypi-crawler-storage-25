# =========================================================
# XGBOOST CLASSIFIER (GENERALIZED TEMPLATE)
# =========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    auc
)

from xgboost import XGBClassifier

# =========================================================
# DATASET SECTION
# Uncomment ONLY ONE SECTION
# =========================================================

# ---------------------------------------------------------
# OPTION 1 : CSV DATASET
# ---------------------------------------------------------

df = pd.read_csv("data.csv")

# ---------------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# ---------------------------------------------------------

# data = {
#     "Hours": [1,2,3,4,5,6,7,8,9,10],
#     "Attendance": [50,55,60,65,70,75,80,85,90,95],
#     "Pass": [0,0,0,0,1,1,1,1,1,1]
# }

# df = pd.DataFrame(data)

# =========================================================
# VIEW DATA
# =========================================================

print("\nDataset:")

print(df.head())

print("\nShape:", df.shape)

# =========================================================
# FEATURES AND TARGET
# =========================================================

X = df.iloc[:, :-1]

y = df.iloc[:, -1]

print("\nFeatures:\n")

print(X.head())

print("\nTarget:\n")

print(y.head())

# =========================================================
# TRAIN TEST SPLIT
# =========================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# =========================================================
# MODEL CREATION
# =========================================================

model = XGBClassifier(
    n_estimators=100,
    learning_rate=0.1,
    max_depth=3,
    random_state=42,
    eval_metric='logloss'
)

# =========================================================
# TRAIN MODEL
# =========================================================

model.fit(X_train, y_train)

# =========================================================
# PREDICTIONS
# =========================================================

y_pred = model.predict(X_test)

y_prob = model.predict_proba(X_test)[:,1]

# =========================================================
# ACCURACY
# =========================================================

accuracy = accuracy_score(
    y_test,
    y_pred
)

print("\nAccuracy:", accuracy)

# =========================================================
# CONFUSION MATRIX
# =========================================================

cm = confusion_matrix(
    y_test,
    y_pred
)

print("\nConfusion Matrix:\n")

print(cm)

# =========================================================
# CLASSIFICATION REPORT
# =========================================================

report = classification_report(
    y_test,
    y_pred
)

print("\nClassification Report:\n")

print(report)

# =========================================================
# ACTUAL VS PREDICTED
# =========================================================

results = pd.DataFrame({
    "Actual": y_test,
    "Predicted": y_pred
})

print("\nActual vs Predicted:\n")

print(results)

# =========================================================
# RESIDUALS
# =========================================================

residuals = y_test - y_pred

# =========================================================
# VISUALIZATION 1
# CONFUSION MATRIX
# =========================================================

plt.figure(figsize=(6,5))

plt.imshow(cm)

plt.title("Confusion Matrix")

plt.colorbar()

plt.xlabel("Predicted")

plt.ylabel("Actual")

for i in range(len(cm)):
    for j in range(len(cm)):

        plt.text(
            j,
            i,
            cm[i][j],
            ha='center',
            va='center',
            color='red'
        )

plt.show()

# =========================================================
# VISUALIZATION 2
# ROC CURVE
# =========================================================

fpr, tpr, thresholds = roc_curve(
    y_test,
    y_prob
)

roc_auc = auc(fpr, tpr)

plt.figure(figsize=(7,6))

plt.plot(
    fpr,
    tpr,
    label=f"AUC = {roc_auc:.2f}"
)

plt.plot([0,1], [0,1], 'r--')

plt.xlabel("False Positive Rate")

plt.ylabel("True Positive Rate")

plt.title("ROC Curve")

plt.legend()

plt.grid(True)

plt.show()

# =========================================================
# VISUALIZATION 3
# RESIDUAL PLOT
# =========================================================

plt.figure(figsize=(8,6))

plt.scatter(
    range(len(residuals)),
    residuals
)

plt.axhline(
    y=0,
    color='red',
    linestyle='--'
)

plt.xlabel("Data Points")

plt.ylabel("Residuals")

plt.title("Residual Plot")

plt.grid(True)

plt.show()

# =========================================================
# VISUALIZATION 4
# ACTUAL VS PREDICTED
# =========================================================

plt.figure(figsize=(8,6))

plt.scatter(
    y_test,
    y_pred
)

plt.plot(
    [y_test.min(), y_test.max()],
    [y_test.min(), y_test.max()],
    'r--'
)

plt.xlabel("Actual")

plt.ylabel("Predicted")

plt.title("Actual vs Predicted")

plt.grid(True)

plt.show()

# =========================================================
# CUSTOM PREDICTION
# =========================================================

# Example:
# new_data = [[6, 80]]

# prediction = model.predict(new_data)

# probability = model.predict_proba(new_data)

# print("\nPrediction:", prediction)

# print("Probability:", probability)