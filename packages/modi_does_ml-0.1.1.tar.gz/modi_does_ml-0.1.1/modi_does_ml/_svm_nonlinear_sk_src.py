# =========================================================
# NON-LINEAR SVM USING SKLEARN
# WITH CUSTOM DECISION BOUNDARY VISUALIZATION
# =========================================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split

from sklearn.preprocessing import StandardScaler

from sklearn.svm import SVC

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    auc
)

# =========================================================
# DATASET SECTION
# Uncomment ONLY ONE SECTION
# =========================================================

# ---------------------------------------------------------
# OPTION 1 : CSV DATASET
# ---------------------------------------------------------

df = pd.read_csv("data.csv")

# ---------------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# ---------------------------------------------------------

# data = {
#     "Feature1": [1,2,3,4,5,6,7,8,9,10],
#     "Feature2": [2,1,2,3,5,7,8,9,11,12],
#     "Class":    [-1,-1,-1,-1,1,1,1,1,1,1]
# }

# df = pd.DataFrame(data)

# =========================================================
# VIEW DATA
# =========================================================

print("\nDataset:\n")

print(df.head())

# =========================================================
# FEATURES AND TARGET
# =========================================================

# ONLY FIRST 2 FEATURES USED
# for visualization

X = df.iloc[:, :2].values

y = df.iloc[:, -1].values

# =========================================================
# STANDARDIZATION
# =========================================================

scaler = StandardScaler()

X = scaler.fit_transform(X)

# =========================================================
# TRAIN TEST SPLIT
# =========================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# =========================================================
# MODEL CREATION
# =========================================================

model = SVC(
    kernel='rbf',
    C=1,
    gamma='scale',
    probability=True
)

# =========================================================
# TRAIN MODEL
# =========================================================

model.fit(X_train, y_train)

# =========================================================
# PREDICTIONS
# =========================================================

y_pred = model.predict(X_test)

y_prob = model.predict_proba(X_test)[:,1]

# =========================================================
# ACCURACY
# =========================================================

accuracy = accuracy_score(
    y_test,
    y_pred
)

print("\nAccuracy:", accuracy)

# =========================================================
# CONFUSION MATRIX
# =========================================================

cm = confusion_matrix(
    y_test,
    y_pred
)

print("\nConfusion Matrix:\n")

print(cm)

# =========================================================
# CLASSIFICATION REPORT
# =========================================================

report = classification_report(
    y_test,
    y_pred
)

print("\nClassification Report:\n")

print(report)

# =========================================================
# ACTUAL VS PREDICTED
# =========================================================

results = pd.DataFrame({
    "Actual": y_test,
    "Predicted": y_pred
})

print("\nActual vs Predicted:\n")

print(results)

# =========================================================
# CUSTOM DECISION BOUNDARY FUNCTION
# =========================================================

def draw_svm_boundary(X_vis, y_vis, model):

    h = 0.05

    # =====================================================
    # MESH GRID
    # =====================================================

    x_min, x_max = (
        X_vis[:, 0].min() - 1,
        X_vis[:, 0].max() + 1
    )

    y_min, y_max = (
        X_vis[:, 1].min() - 1,
        X_vis[:, 1].max() + 1
    )

    xx, yy = np.meshgrid(
        np.arange(x_min, x_max, h),
        np.arange(y_min, y_max, h)
    )

    # =====================================================
    # GRID POINTS
    # =====================================================

    grid_points = np.c_[
        xx.ravel(),
        yy.ravel()
    ]

    # =====================================================
    # DECISION FUNCTION
    # =====================================================

    Z = model.decision_function(
        grid_points
    )

    Z = Z.reshape(xx.shape)

    # =====================================================
    # PLOT REGIONS
    # =====================================================

    plt.figure(figsize=(10,7))

    plt.contourf(
        xx,
        yy,
        Z,
        levels=[-10, 0, 10],
        alpha=0.2
    )

    # =====================================================
    # PLOT DATA
    # =====================================================

    plt.scatter(
        X_vis[y_vis == -1, 0],
        X_vis[y_vis == -1, 1],
        label='Class -1'
    )

    plt.scatter(
        X_vis[y_vis == 1, 0],
        X_vis[y_vis == 1, 1],
        label='Class 1'
    )

    # =====================================================
    # DECISION BOUNDARY
    # =====================================================

    plt.contour(
        xx,
        yy,
        Z,
        levels=[0],
        colors='black',
        linewidths=2
    )

    # =====================================================
    # SUPPORT VECTORS
    # =====================================================

    plt.scatter(
        model.support_vectors_[:,0],
        model.support_vectors_[:,1],
        s=100,
        facecolors='none',
        edgecolors='black',
        label='Support Vectors'
    )

    # =====================================================
    # LABELS
    # =====================================================

    plt.title(
        "Non-Linear SVM Decision Boundary"
    )

    plt.xlabel("Feature 1")

    plt.ylabel("Feature 2")

    plt.legend()

    plt.grid(True)

    plt.show()

# =========================================================
# DRAW BOUNDARY
# =========================================================

draw_svm_boundary(
    X,
    y,
    model
)

# =========================================================
# ROC CURVE
# =========================================================

fpr, tpr, thresholds = roc_curve(
    y_test,
    y_prob
)

roc_auc = auc(fpr, tpr)

plt.figure(figsize=(7,6))

plt.plot(
    fpr,
    tpr,
    label=f"AUC = {roc_auc:.2f}"
)

plt.plot([0,1], [0,1], 'r--')

plt.xlabel("False Positive Rate")

plt.ylabel("True Positive Rate")

plt.title("ROC Curve")

plt.legend()

plt.grid(True)

plt.show()