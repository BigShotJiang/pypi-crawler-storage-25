import os, shutil, textwrap

def _write_file(src_file, output_name):
    src_path = os.path.join(os.path.dirname(__file__), src_file)
    dest = os.path.join(os.getcwd(), output_name)
    shutil.copy2(src_path, dest)
    print(f"\n✅  Created: {output_name}  (in {os.getcwd()})")
