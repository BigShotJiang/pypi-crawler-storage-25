# =========================================================
# K-MEANS CLUSTERING USING SKLEARN
# GENERALIZED TEMPLATE
# =========================================================

import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

# =========================================================
# DATASET SECTION
# Uncomment ONLY ONE SECTION
# =========================================================

# ---------------------------------------------------------
# OPTION 1 : CSV DATASET
# ---------------------------------------------------------

df = pd.read_csv("data.csv")

# ---------------------------------------------------------
# OPTION 2 : HARDCODED DATAFRAME
# ---------------------------------------------------------

# np.random.seed(42)
#
# data = {
#     "Feature1": np.random.randint(10, 100, 100),
#     "Feature2": np.random.randint(20, 120, 100),
#     "Feature3": np.random.randint(5, 80, 100),
#     "Feature4": np.random.randint(50, 150, 100),
#     "Feature5": np.random.randint(1, 60, 100)
# }
#
# df = pd.DataFrame(data)

# =========================================================
# VIEW DATA
# =========================================================

print("\nDataset Head:\n")

print(df.head())

print("\nDataset Shape:")

print(df.shape)

print("\nMissing Values:\n")

print(df.isnull().sum())

# =========================================================
# FEATURE DISTRIBUTION
# =========================================================

df.hist(figsize=(15,10), bins=20)

plt.suptitle("Feature Distribution")

plt.tight_layout()

plt.show()

# =========================================================
# PAIRPLOT
# =========================================================

sns.pairplot(df)

plt.show()

# =========================================================
# CORRELATION HEATMAP
# =========================================================

plt.figure(figsize=(10,8))

sns.heatmap(
    df.corr(),
    annot=True,
    cmap="coolwarm",
    fmt=".2f"
)

plt.title("Correlation Heatmap")

plt.show()

# =========================================================
# FEATURE SCALING
# =========================================================

# Scaling is important because K-Means uses distance.
# Larger feature values can dominate clustering.

scaler = StandardScaler()

X_scaled = scaler.fit_transform(df)

print("\nData Scaled Successfully")

# =========================================================
# ELBOW METHOD
# =========================================================

# WCSS measures cluster compactness.
# Lower WCSS means tighter clusters.

wcss = []

K_range = range(1, 11)

for k in K_range:

    kmeans = KMeans(
        n_clusters=k,
        random_state=42,
        n_init=10
    )

    kmeans.fit(X_scaled)

    # inertia_ stores WCSS value
    wcss.append(kmeans.inertia_)

plt.figure(figsize=(8,6))

plt.plot(K_range, wcss, marker='o')

plt.xlabel("Number of Clusters")

plt.ylabel("WCSS")

plt.title("Elbow Method")

plt.grid(True)

plt.show()

# =========================================================
# CHOOSE NUMBER OF CLUSTERS
# =========================================================

k = 3

# =========================================================
# MODEL CREATION
# =========================================================

model = KMeans(
    n_clusters=k,
    random_state=42,
    n_init=10
)

# =========================================================
# TRAIN MODEL
# =========================================================

# Model tries to minimize distance
# between points and centroids.

model.fit(X_scaled)

# =========================================================
# GET CLUSTER LABELS
# =========================================================

# labels_ gives assigned cluster for each point

clusters = model.labels_

# =========================================================
# GET CENTROIDS
# =========================================================

# Cluster centers after convergence

centroids = model.cluster_centers_

# =========================================================
# ADD CLUSTER COLUMN
# =========================================================

df["Cluster"] = clusters

# =========================================================
# CLUSTER COUNTS
# =========================================================

print("\nCluster Counts:\n")

print(df["Cluster"].value_counts())

# =========================================================
# CENTROIDS
# =========================================================

print("\nCentroids:\n")

print(centroids)

# =========================================================
# SILHOUETTE SCORE
# =========================================================

# Measures cluster quality.
# Higher score means better separation.

score = silhouette_score(X_scaled, clusters)

print("\nSilhouette Score:")

print(score)

# =========================================================
# CLUSTER VISUALIZATION
# =========================================================

plt.figure(figsize=(8,6))

plt.scatter(
    X_scaled[:, 0],
    X_scaled[:, 1],
    c=clusters,
    cmap='viridis'
)

plt.scatter(
    centroids[:, 0],
    centroids[:, 1],
    s=300,
    c='red',
    marker='X',
    label='Centroids'
)

plt.xlabel(df.columns[0])

plt.ylabel(df.columns[1])

plt.title("K-Means Clusters")

plt.legend()

plt.grid(True)

plt.show()

# =========================================================
# PCA FOR DIMENSION REDUCTION
# =========================================================

# PCA converts high-dimensional data
# into 2 dimensions for visualization.

pca = PCA(n_components=2)

X_pca = pca.fit_transform(X_scaled)

# =========================================================
# PCA 2D PROJECTION
# =========================================================

plt.figure(figsize=(8,6))

scatter = plt.scatter(
    X_pca[:, 0],
    X_pca[:, 1],
    c=clusters,
    cmap='rainbow'
)

plt.xlabel("PCA Component 1")

plt.ylabel("PCA Component 2")

plt.title("PCA 2D Projection")

plt.colorbar(scatter)

plt.grid(True)

plt.show()

# =========================================================
# CLUSTER-WISE FEATURE MEAN
# =========================================================

cluster_summary = df.groupby("Cluster").mean()

print("\nCluster Wise Mean:\n")

print(cluster_summary)

# =========================================================
# HEATMAP OF CLUSTER MEANS
# =========================================================

plt.figure(figsize=(10,6))

sns.heatmap(
    cluster_summary,
    annot=True,
    cmap="YlGnBu"
)

plt.title("Cluster-wise Feature Mean Heatmap")

plt.show()

# =========================================================
# CUSTOM PREDICTION
# =========================================================

# Example:
# new_data = [[50, 60, 30, 100, 25]]

# new_data_scaled = scaler.transform(new_data)

# prediction = model.predict(new_data_scaled)

# print("\nPredicted Cluster:", prediction)