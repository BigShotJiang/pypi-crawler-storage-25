# =========================================================
# LINEAR DISCRIMINANT ANALYSIS (LDA)
# USING SKLEARN
# =========================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    auc
)

# =========================================================
# WHAT IS LDA?
# =========================================================

# LDA = Linear Discriminant Analysis
#
# LDA is both:
# -> Classification Algorithm
# -> Dimensionality Reduction Technique
#
# Main objective:
# -> Maximize separation between classes
#
# PCA:
# -> Maximizes variance
#
# LDA:
# -> Maximizes class separability
#
# LDA tries to:
#
# 1. Maximize distance between class means
# 2. Minimize spread within each class
#
# Mathematical Idea:
#
# Maximize:
#
# Between-Class Variance
# ----------------------
# Within-Class Variance
#
# LDA creates new axes called:
# -> Linear Discriminants

# =========================================================
# DATASET
# =========================================================

# OPTION 1 : CSV
# df = pd.read_csv("data.csv")

# OPTION 2 : HARDCODED DATASET

np.random.seed(42)

rows = 200

data = {
    "Feature1": np.random.randint(1,100,rows),
    "Feature2": np.random.randint(1,100,rows),
    "Feature3": np.random.randint(1,100,rows),
    "Feature4": np.random.randint(1,100,rows),
    "Feature5": np.random.randint(1,100,rows)
}

df = pd.DataFrame(data)

# Binary Target

df["Target"] = np.random.randint(0,2,rows)

# =========================================================
# VIEW DATASET
# =========================================================

print(df.head())

print(df.shape)

# =========================================================
# FEATURES + TARGET
# =========================================================

X = df.iloc[:, :-1]

y = df.iloc[:, -1]

# =========================================================
# TARGET DISTRIBUTION
# =========================================================

plt.figure(figsize=(6,5))

sns.countplot(x=y)

plt.title("Target Distribution")

plt.grid(True)

plt.show()

# =========================================================
# CORRELATION HEATMAP
# =========================================================

plt.figure(figsize=(10,8))

sns.heatmap(
    df.corr(),
    annot=True,
    cmap="coolwarm"
)

plt.title("Correlation Heatmap")

plt.show()

# =========================================================
# TRAIN TEST SPLIT
# =========================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42
)

# =========================================================
# FEATURE SCALING
# =========================================================

# Scaling helps equalize feature ranges

scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)

X_test = scaler.transform(X_test)

# =========================================================
# LDA MODEL
# =========================================================

# n_components:
# -> number of discriminant axes
#
# Maximum possible:
# -> classes - 1

lda = LinearDiscriminantAnalysis(
    n_components=1
)

# =========================================================
# TRAIN MODEL
# =========================================================

lda.fit(X_train, y_train)

# =========================================================
# TRANSFORM DATA
# =========================================================

# Projects data onto discriminant axis

X_train_lda = lda.transform(X_train)

X_test_lda = lda.transform(X_test)

# =========================================================
# PREDICTIONS
# =========================================================

y_pred = lda.predict(X_test)

# Probability predictions
# Needed for ROC curve

y_prob = lda.predict_proba(X_test)

# =========================================================
# ACCURACY
# =========================================================

accuracy = accuracy_score(
    y_test,
    y_pred
)

print("\nAccuracy:")
print(accuracy)

# =========================================================
# CONFUSION MATRIX
# =========================================================

cm = confusion_matrix(
    y_test,
    y_pred
)

print("\nConfusion Matrix:")
print(cm)

# =========================================================
# CLASSIFICATION REPORT
# =========================================================

print("\nClassification Report:")

print(
    classification_report(
        y_test,
        y_pred
    )
)

# =========================================================
# CONFUSION MATRIX VISUALIZATION
# =========================================================

plt.figure(figsize=(6,5))

sns.heatmap(
    cm,
    annot=True,
    fmt='d',
    cmap='Blues'
)

plt.xlabel("Predicted")
plt.ylabel("Actual")

plt.title("Confusion Matrix")

plt.show()

# =========================================================
# ROC CURVE
# =========================================================

y_prob_binary = y_prob[:,1]

fpr, tpr, thresholds = roc_curve(
    y_test,
    y_prob_binary
)

roc_auc = auc(fpr, tpr)

plt.figure(figsize=(7,6))

plt.plot(
    fpr,
    tpr,
    label=f"AUC = {roc_auc:.2f}"
)

plt.plot([0,1], [0,1], 'r--')

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")

plt.title("ROC Curve")

plt.legend()

plt.grid(True)

plt.show()

# =========================================================
# LDA PROJECTION VISUALIZATION
# =========================================================

plt.figure(figsize=(8,6))

for label in np.unique(y_train):

    plt.scatter(
        X_train_lda[y_train == label],
        np.zeros_like(X_train_lda[y_train == label]),
        label=f"Class {label}"
    )

plt.xlabel("Linear Discriminant 1")

plt.title("LDA Projection")

plt.legend()

plt.grid(True)

plt.show()

# =========================================================
# EXPLAINED VARIANCE RATIO
# =========================================================

# Shows discriminatory power retained

print("\nExplained Variance Ratio:")

print(lda.explained_variance_ratio_)

# =========================================================
# COEFFICIENTS
# =========================================================

# Indicates feature importance
# in discrimination

coef_df = pd.DataFrame({

    "Feature": X.columns,
    "Coefficient": lda.coef_[0]

})

print("\nFeature Coefficients:")

print(coef_df)

# =========================================================
# FEATURE IMPORTANCE GRAPH
# =========================================================

plt.figure(figsize=(8,6))

sns.barplot(
    x="Coefficient",
    y="Feature",
    data=coef_df
)

plt.title("LDA Feature Importance")

plt.show()