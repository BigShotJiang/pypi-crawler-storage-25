"""Tests for payment integrations."""
