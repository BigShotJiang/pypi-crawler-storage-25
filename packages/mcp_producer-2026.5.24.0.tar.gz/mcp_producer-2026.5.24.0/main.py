#!/usr/bin/env python3
"""
MCP Producer Server - AI Music Generation via AceDataCloud API.

A Model Context Protocol (MCP) server that provides tools for generating
AI music using Producer/Riffusion (FUZZ models) through the AceDataCloud platform.
"""

import argparse
import logging
import sys
from importlib import metadata

from dotenv import load_dotenv

# Load environment variables before importing other modules
load_dotenv()

from core.config import settings
from core.server import mcp

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def safe_print(text: str) -> None:
    """Print to stderr safely, handling encoding issues."""
    if not sys.stderr.isatty():
        logger.debug(f"[MCP Producer] {text}")
        return

    try:
        print(text, file=sys.stderr)
    except UnicodeEncodeError:
        print(text.encode("ascii", errors="replace").decode(), file=sys.stderr)


def get_version() -> str:
    """Get the package version."""
    try:
        return metadata.version("mcp-producer")
    except metadata.PackageNotFoundError:
        return "dev"


def main() -> None:
    """Run the MCP Producer server."""
    parser = argparse.ArgumentParser(
        description="MCP Producer Server - AI Music Generation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  mcp-producer                    # Run with stdio transport (default)
  mcp-producer --transport http   # Run with HTTP transport
  mcp-producer --version          # Show version

Environment Variables:
  ACEDATACLOUD_API_TOKEN          API token from AceDataCloud (required)
  PRODUCER_DEFAULT_MODEL     Default model (default: FUZZ-2.0)
  PRODUCER_REQUEST_TIMEOUT   Request timeout in seconds (default: 1800)
  LOG_LEVEL                  Logging level (default: INFO)
        """,
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"mcp-producer {get_version()}",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "http"],
        default="stdio",
        help="Transport mode (default: stdio)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port for HTTP transport (default: 8000)",
    )
    args = parser.parse_args()

    # Print startup banner
    safe_print("")
    safe_print("=" * 50)
    safe_print("  MCP Producer Server - AI Music Generation")
    safe_print("=" * 50)
    safe_print("")
    safe_print(f"  Version:   {get_version()}")
    safe_print(f"  Transport: {args.transport}")
    safe_print(f"  Model:     {settings.default_model}")
    safe_print(f"  Log Level: {settings.log_level}")
    safe_print("")

    # Validate configuration
    if not settings.is_configured and args.transport != "http":
        safe_print("  [ERROR] ACEDATACLOUD_API_TOKEN not configured!")
        safe_print("  Get your token from https://platform.acedata.cloud")
        safe_print("")
        sys.exit(1)

    if args.transport == "http":
        safe_print("  [OK] HTTP mode - tokens from request headers")
    else:
        safe_print("  [OK] API token configured")
    safe_print("")

    # Import tools and prompts to register them
    safe_print("  Loading tools and prompts...")
    import prompts  # noqa: F401, I001
    import tools  # noqa: F401

    safe_print("  [OK] Tools and prompts loaded")
    safe_print("")
    safe_print("  Available tools:")
    safe_print("    - producer_generate_music")
    safe_print("    - producer_generate_custom_music")
    safe_print("    - producer_extend_music")
    safe_print("    - producer_cover_music")
    safe_print("    - producer_variation_music")
    safe_print("    - producer_swap_vocals")
    safe_print("    - producer_swap_instrumentals")
    safe_print("    - producer_replace_section")
    safe_print("    - producer_stems_music")
    safe_print("    - producer_generate_lyrics")
    safe_print("    - producer_upload_audio")
    safe_print("    - producer_generate_video")
    safe_print("    - producer_generate_wav")
    safe_print("    - producer_get_task")
    safe_print("    - producer_get_tasks_batch")
    safe_print("    - producer_list_models")
    safe_print("    - producer_list_actions")
    safe_print("    - producer_get_lyric_format_guide")
    safe_print("")
    safe_print("  Available prompts:")
    safe_print("    - producer_music_generation_guide")
    safe_print("    - producer_workflow_examples")
    safe_print("    - producer_prompt_suggestions")
    safe_print("")
    safe_print("=" * 50)
    safe_print("  Ready for MCP connections")
    safe_print("=" * 50)
    safe_print("")

    # Run the server
    try:
        if args.transport == "http":
            import contextlib

            import uvicorn
            from starlette.applications import Starlette
            from starlette.requests import Request
            from starlette.responses import JSONResponse, RedirectResponse
            from starlette.routing import BaseRoute, Mount, Route

            from core.server import oauth_provider

            async def health(_request: Request) -> JSONResponse:
                return JSONResponse({"status": "ok"})

            async def favicon(_request: Request) -> RedirectResponse:
                return RedirectResponse(
                    "https://cdn.acedata.cloud/ahjfwi.png",
                    status_code=301,
                )

            async def server_card(_request: Request) -> JSONResponse:
                """MCP Server Card for Smithery and other registries."""
                return JSONResponse(
                    {
                        "serverInfo": {"name": "MCP Producer", "version": get_version()},
                        "authentication": {"required": True, "schemes": ["bearer"]},
                        "tools": [
                            {
                                "name": "producer_generate_music",
                                "description": "Generate AI music from a text prompt",
                            },
                            {
                                "name": "producer_generate_custom_music",
                                "description": "Generate music with custom lyrics, title, and style",
                            },
                            {
                                "name": "producer_extend_music",
                                "description": "Extend an existing song from a timestamp",
                            },
                            {
                                "name": "producer_cover_music",
                                "description": "Create a cover/remix in a different style",
                            },
                            {
                                "name": "producer_variation_music",
                                "description": "Create a variation of an existing song",
                            },
                            {
                                "name": "producer_swap_vocals",
                                "description": "Swap vocals between two songs",
                            },
                            {
                                "name": "producer_swap_instrumentals",
                                "description": "Swap instrumentals between two songs",
                            },
                            {
                                "name": "producer_replace_section",
                                "description": "Replace a time range with new content",
                            },
                            {
                                "name": "producer_stems_music",
                                "description": "Separate into vocal and instrument stems",
                            },
                            {
                                "name": "producer_generate_lyrics",
                                "description": "Generate structured lyrics from a prompt",
                            },
                            {
                                "name": "producer_upload_audio",
                                "description": "Upload external audio for processing",
                            },
                            {
                                "name": "producer_generate_video",
                                "description": "Generate a music video for a song",
                            },
                            {
                                "name": "producer_generate_wav",
                                "description": "Get lossless WAV format of a song",
                            },
                            {
                                "name": "producer_get_task",
                                "description": "Query task status and result",
                            },
                            {
                                "name": "producer_get_tasks_batch",
                                "description": "Query multiple tasks at once",
                            },
                            {
                                "name": "producer_list_models",
                                "description": "List available FUZZ models",
                            },
                            {
                                "name": "producer_list_actions",
                                "description": "List available API actions",
                            },
                            {
                                "name": "producer_get_lyric_format_guide",
                                "description": "Get lyrics formatting guide",
                            },
                        ],
                        "prompts": [
                            {
                                "name": "producer_music_generation_guide",
                                "description": "Guide for music generation",
                            },
                            {
                                "name": "producer_workflow_examples",
                                "description": "Example workflows",
                            },
                            {
                                "name": "producer_prompt_suggestions",
                                "description": "Prompt suggestions for generation",
                            },
                        ],
                        "resources": [],
                    }
                )

            @contextlib.asynccontextmanager
            async def lifespan(_app: Starlette):  # type: ignore[no-untyped-def]
                async with mcp.session_manager.run():
                    yield

            mcp.settings.stateless_http = True
            mcp.settings.json_response = True
            mcp.settings.streamable_http_path = "/mcp"

            # Build routes
            routes: list[BaseRoute] = [
                Route("/health", health),
                Route("/favicon.ico", favicon),
                Route("/.well-known/mcp/server-card.json", server_card),
            ]

            # Add OAuth callback route if OAuth is enabled
            if oauth_provider:
                routes.append(
                    Route(
                        "/oauth/callback",
                        oauth_provider.handle_callback,
                    )
                )

            # Mount legacy SSE transport (/sse + /messages) alongside Streamable HTTP (/mcp)
            # so SSE-only clients (e.g. OOBE Synapse SDK) and modern Streamable HTTP
            # clients are both supported on the same endpoint.
            for sse_route in mcp.sse_app().routes:
                routes.append(sse_route)
            routes.append(Mount("/", app=mcp.streamable_http_app()))

            app = Starlette(routes=routes, lifespan=lifespan)
            uvicorn.run(app, host="0.0.0.0", port=args.port)
        else:
            mcp.run(transport="stdio")
    except KeyboardInterrupt:
        safe_print("\nShutdown requested")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Server error: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
