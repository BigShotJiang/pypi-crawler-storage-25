# Spec: realizes graph-engine §6 (started/completed event pair model
# from proposal 0005, v0.6.0). FanOutEventConfig is the fan-out node
# event payload added by proposal 0013 (v0.10.0).

"""Node-boundary observer events.

Each node attempt produces a started/completed event PAIR. The engine
dispatches the started event before invoking the wrapped node function
and the completed event after the reducer merge succeeds (with
``post_state`` populated) or after the node, reducer, or state
validation fails (with ``error`` populated).

Frozen dataclass; observers receive a snapshot, not a live handle.
"""

from dataclasses import dataclass
from typing import Any, Literal

from .errors import RuntimeGraphError
from .state import State


# Spec: realizes observability §5.4 fan-out attributes via the
# event-payload mechanism added by proposal 0013 (v0.10.0). Backend
# observers cache ``parent_node_name`` off the fan-out node's
# started event and apply it on every per-instance span they
# synthesize (observability §5.4 mandates
# ``openarmature.fan_out.parent_node_name`` on per-instance spans).
@dataclass(frozen=True)
class FanOutEventConfig:
    """Resolved fan-out configuration carried on a fan-out node's
    own events.

    Fan-out node events carry the resolved configuration so backend
    observers can attribute the fan-out node span (``item_count`` /
    ``concurrency`` / ``error_policy``) and synthesize per-instance
    spans with the right ``parent_node_name``.

    Populated ONLY on ``started`` and ``completed`` events for a
    fan-out node itself (partition by node type, not event category;
    INCLUDES retried attempts of a fan-out node when retry middleware
    wraps it). All other events leave ``NodeEvent.fan_out_config``
    null.

    Field shapes:

    - ``item_count``: non-negative int. The resolved instance count
      (matches ``count_field`` value when configured; matches
      ``len(items_field)`` in items_field mode).
    - ``concurrency``: positive int OR ``None`` (unbounded). Zero or
      negative is rejected at config resolution time as
      ``fan_out_invalid_concurrency``. Backend mappings may translate
      ``None`` to a sentinel at the attribute layer (e.g.,
      ``openarmature.fan_out.concurrency = 0``); that translation is
      observer-internal, not engine-internal.
    - ``error_policy``: one of ``"fail_fast"`` or ``"collect"``.
    - ``parent_node_name``: the fan-out node's name in the parent
      graph. Carried here for caching by backend observers when
      attributing per-instance spans.

    All four fields MUST be present when ``fan_out_config`` is
    populated. Only ``concurrency`` is nullable.
    """

    item_count: int
    concurrency: int | None
    error_policy: str
    parent_node_name: str


# Spec: realizes graph-engine §6 NodeEvent (started/completed pair
# model from proposal 0005, v0.6.0). The ``checkpoint_saved`` phase
# is the Python shape for §10.8 save events (§10.8 SHOULDs an event
# emit but leaves the shape implementation-defined). ``fan_out_config``
# is the observability §5.4 / proposal 0013 (v0.10.0) addition.
@dataclass(frozen=True)
class NodeEvent:
    """A single node-boundary event delivered to observers.

    - ``phase`` is ``"started"`` (dispatched before the node runs) or
      ``"completed"`` (dispatched after the node returns or raises
      and the merge runs/fails). Each node attempt produces exactly
      one of each in that order. The engine ALSO dispatches a
      ``"checkpoint_saved"`` event on the same shape after a
      successful ``Checkpointer.save`` call; observers MUST opt in
      explicitly via ``phases={"checkpoint_saved"}`` to receive these
      (default subscription is ``{"started", "completed"}`` only, so
      legacy observers don't see them).
    - ``node_name`` is the name under which this node was registered
      in its immediate containing graph.
    - ``namespace`` is an ordered sequence of node names from the
      outermost graph down to this node. For a node in the outermost
      graph, ``namespace`` is ``(node_name,)``. For nested subgraphs,
      the chain extends.
    - ``step`` is a monotonically-increasing counter starting at 0,
      scoped to a single outermost invocation. Subgraph-internal nodes
      increment the same counter. The started/completed pair for one
      attempt share the same step.
    - ``pre_state`` is the state the node received, before reducer
      merge. Populated on both phases (identical across the pair).
    - ``post_state`` is the state after the node's partial update
      merged successfully. Populated only on ``completed`` events
      that succeeded.
    - ``error`` is the wrapped runtime error (``NodeException``,
      ``ReducerError``, or ``StateValidationError``) when the node
      failed. Populated only on ``completed`` events that failed.
    - ``parent_states`` carries one state snapshot per containing
      graph, outermost first; for a node in the outermost graph it's
      an empty tuple. Invariant:
      ``len(parent_states) == len(namespace) - 1``.
    - ``attempt_index`` is the 0-based index of this attempt among
      any retries. ``0`` for nodes not wrapped by retry middleware.
    - ``fan_out_index`` is the 0-based index of this fan-out instance
      among its siblings. ``None`` for nodes not inside a fan-out.
    - ``fan_out_config`` carries resolved fan-out configuration on
      events from a fan-out NODE itself. See
      :class:`FanOutEventConfig`. ``None`` on every other event.
    - ``branch_name`` is the non-empty string name of the
      parallel-branches branch this event came from. ``None`` for
      nodes outside any branch. Per graph-engine §6 / pipeline-
      utilities §11, the combination of ``namespace``,
      ``branch_name``, ``fan_out_index``, ``attempt_index``, and
      ``phase`` jointly uniquely identifies an event source.
      ``branch_name`` and ``fan_out_index`` are independent; both
      MAY be present when a branch's subgraph contains a fan-out
      (or a fan-out instance contains a parallel-branches node).

    Invariants:

    - On ``started`` events, ``post_state`` and ``error`` MUST both
      be ``None``.
    - On ``completed`` events, exactly one of ``post_state`` and
      ``error`` is populated.

    **Synthetic phases.** ``"checkpoint_saved"`` (pipeline-utilities
    §10.8) and ``"checkpoint_migrated"`` (proposal 0014 §6
    cross-ref) repurpose this dataclass for non-node events. Both
    are opt-in via ``phases={...}`` on observer registration;
    default subscriptions are ``{"started", "completed"}`` only, so
    legacy observers never see them. Conventions on synthetic
    events:

    - ``checkpoint_saved``: ``pre_state`` carries the saved
      post-merge state (still a real ``State`` instance for this
      phase), ``post_state`` is ``None``. ``step`` matches the
      saving node's step.
    - ``checkpoint_migrated``: ``step=-1`` (no graph-step
      sequencing; migrations run before any node fires).
      ``node_name="openarmature.checkpoint.migrate"`` and
      ``namespace=("openarmature.checkpoint.migrate",)`` are
      dotted-pseudo identifiers, not real node names. ``pre_state``
      carries a private ``_MigrationSummary`` dataclass with
      ``from_version`` / ``to_version`` / ``chain_length``, NOT a
      ``State`` instance. ``parent_states`` is the empty tuple.

    Because ``pre_state`` is no longer guaranteed to be a ``State``
    on the synthetic phases, its type is declared as ``Any`` and
    observer authors who subscribe to those phases MUST narrow
    per-phase before reading ``pre_state``.
    """

    node_name: str
    namespace: tuple[str, ...]
    step: int
    phase: Literal[
        "started",
        "completed",
        "checkpoint_saved",
        # Synthetic phase per spec §6 cross-ref in proposal 0014:
        # fires once at the start of a versioned resume to carry
        # the migration chain's metadata. ``pre_state`` on this
        # phase carries a ``_MigrationSummary`` (not a ``State``);
        # the field type stays permissive on this dataclass and
        # the OTel observer narrows defensively via ``isinstance``.
        "checkpoint_migrated",
    ]
    pre_state: Any
    post_state: State | None
    error: RuntimeGraphError | None
    parent_states: tuple[State, ...]
    attempt_index: int = 0
    fan_out_index: int | None = None
    fan_out_config: FanOutEventConfig | None = None
    # Per pipeline-utilities §11 / graph-engine §6 (proposal 0011):
    # optional non-empty string populated only on events from nodes
    # that execute inside a parallel-branches branch. The
    # combination of ``namespace``, ``branch_name``,
    # ``fan_out_index``, ``attempt_index``, and ``phase`` jointly
    # uniquely identifies an event source. ``branch_name`` and
    # ``fan_out_index`` are independent; both MAY be present
    # simultaneously when a branch's subgraph contains a fan-out
    # (and vice versa).
    branch_name: str | None = None


__all__ = ["FanOutEventConfig", "NodeEvent"]
