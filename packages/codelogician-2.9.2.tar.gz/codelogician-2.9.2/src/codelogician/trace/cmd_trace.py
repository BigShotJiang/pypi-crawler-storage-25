"""
CodeLogician Trace CLI — manage and check reasoning traces.

Integrated as `codelogician trace <command>`.
"""

# ruff: noqa: C901

import http.server
import json
import os
import tempfile
import threading
import uuid
import webbrowser
from datetime import UTC, datetime
from typing import Any

import typer

from .policy_compiler import (
    ACTION_TYPES,
    ARTIFACT_TYPES,
    STRUCTURAL_POLICIES,
    And,
    Atom,
    AtomWithArgs,
    EndEvent,
    FieldNeEmpty,
    Finally,
    FuncApp,
    Globally,
    Historically,
    Implies,
    Not,
    Or,
    Parser,
    PChain,
    Previously,
    PTarget,
    RawStructural,
    SinceLast,
    StartEvent,
    check_policy as syntax_check_policy,
    tokenize,
)

app = typer.Typer(help='Manage and check CodeLogician reasoning traces')


# ================================================================
# Trace I/O
# ================================================================


def load_trace(path: str) -> dict:
    if not os.path.exists(path):
        typer.echo(f'Error: trace file not found: {path}', err=True)
        raise typer.Exit(1)
    with open(path) as f:
        return json.load(f)


def save_trace(path: str, trace: dict):
    trace['timestamp'] = datetime.now(UTC).strftime('%Y-%m-%dT%H:%M:%SZ')
    dir_name = os.path.dirname(os.path.abspath(path)) or '.'
    fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix='.json')
    try:
        with os.fdopen(fd, 'w') as f:
            json.dump(trace, f, indent=2, ensure_ascii=False)
            f.write('\n')
        os.rename(tmp_path, os.path.abspath(path))
    except Exception:
        os.unlink(tmp_path)
        raise


# ================================================================
# Trace Construction
# ================================================================


def create_empty_trace(model: str, assistant: str) -> dict:
    return {
        'trace_id': f'trace-{uuid.uuid4().hex[:12]}',
        'spec_version': '1.2',
        'assistant': assistant,
        'model': model,
        'timestamp': datetime.now(UTC).strftime('%Y-%m-%dT%H:%M:%SZ'),
        'trigger': {},
        'actions': [],
        'outcome': {},
        'artifacts': [],
        'policies': [],
        'policy_evaluations': [],
        'files_modified': [],
        'metrics': {},
    }


def next_action_id(trace: dict) -> int:
    actions = trace.get('actions', [])
    return max((a['id'] for a in actions), default=0) + 1


def get_action_target(action: dict, trace: dict) -> str:
    for ev in action.get('evidence', []):
        if ev.get('type') == 'FileRef':
            return ev.get('ref', '')
    req = action.get('request', {})
    if req.get('path'):
        return req['path']
    for out_id in action.get('outputs', []):
        for art in trace.get('artifacts', []):
            if art.get('artifact_id') == out_id or art.get('name') == out_id:
                return art.get('name', '')
    return ''


def get_ancestors(artifact_id: str, trace: dict, visited: set | None = None) -> set:
    if visited is None:
        visited = set()
    if artifact_id in visited:
        return set()
    visited.add(artifact_id)
    result = set()
    for art in trace.get('artifacts', []):
        if art['artifact_id'] == artifact_id:
            for pid in art.get('derived_from', []):
                result.add(pid)
                result |= get_ancestors(pid, trace, visited)
    return result


def get_target_lineage(action: dict, trace: dict) -> set:
    targets = set()
    direct = get_action_target(action, trace)
    if direct:
        targets.add(direct)
    for out_id in action.get('outputs', []) + action.get('inputs', []):
        ancestor_ids = get_ancestors(out_id, trace)
        ancestor_ids.add(out_id)
        for art in trace.get('artifacts', []):
            if art.get('artifact_id') in ancestor_ids:
                if art.get('name'):
                    targets.add(art['name'])
                pid = art.get('producer_action_id')
                if pid is not None:
                    for a in trace.get('actions', []):
                        if a['id'] == pid:
                            t = get_action_target(a, trace)
                            if t:
                                targets.add(t)
    return targets


def in_dependency_chain(earlier: dict, current: dict, trace: dict) -> bool:
    current_refs = set(current.get('outputs', []) + current.get('inputs', []))
    all_anc = set()
    for aid in current_refs:
        all_anc.add(aid)
        all_anc |= get_ancestors(aid, trace)
    return bool(all_anc & set(earlier.get('outputs', [])))


def normalize_trace(trace: dict):
    if not trace.get('artifacts'):
        return
    art_map = {a['artifact_id']: a for a in trace['artifacts']}
    for action in trace.get('actions', []):
        for out_id in action.get('outputs', []):
            art = art_map.get(out_id)
            if not art or 'payload' not in art:
                continue
            at = art['artifact_type']
            if at == 'IMLModel' and 'iml_code' in art['payload']:
                action['formalization'] = art['payload']
            elif at == 'Formalization':
                action['formalization'] = art['payload']
            elif at == 'VerificationGoal':
                action['vg_defined'] = art['payload']
            elif at == 'VerificationResult':
                action['vg_result'] = art['payload']
            elif at == 'Decomposition':
                action['decomposition'] = art['payload']
            elif at == 'GeneratedTests':
                action['generated_tests'] = art['payload']


# ================================================================
# Runtime Policy Evaluator
# ================================================================


def evaluate_formula(node, trace, ctx=None) -> bool:
    if isinstance(node, Globally):
        return all(
            evaluate_formula(node.body, trace, {'action': a}) for a in trace['actions']
        )
    if isinstance(node, Finally):
        return any(
            evaluate_formula(node.body, trace, {'action': a}) for a in trace['actions']
        )
    if isinstance(node, Previously):
        if not ctx:
            return False
        cur = ctx['action']
        return any(
            evaluate_formula(node.body, trace, {'action': b})
            for b in trace['actions']
            if b['id'] < cur['id']
        )
    if isinstance(node, Historically):
        if not ctx:
            return True
        cur = ctx['action']
        return all(
            evaluate_formula(node.body, trace, {'action': b})
            for b in trace['actions']
            if b['id'] < cur['id']
        )
    if isinstance(node, PTarget):
        if not ctx:
            return False
        cur = ctx['action']
        cur_targets = get_target_lineage(cur, trace)
        if not cur_targets:
            return False
        return any(
            evaluate_formula(node.body, trace, {'action': b})
            for b in trace['actions']
            if b['id'] < cur['id']
            and (
                get_action_target(b, trace) in cur_targets
                or bool(get_target_lineage(b, trace) & cur_targets)
            )
        )
    if isinstance(node, PChain):
        if not ctx:
            return False
        cur = ctx['action']
        return any(
            evaluate_formula(node.body, trace, {'action': b})
            for b in trace['actions']
            if b['id'] < cur['id'] and in_dependency_chain(b, cur, trace)
        )
    if isinstance(node, SinceLast):
        if not ctx:
            return False
        cur = ctx['action']
        before = [b for b in trace['actions'] if b['id'] < cur['id']]
        boundary = 0
        for b in before:
            if evaluate_formula(node.right, trace, {'action': b}):
                boundary = max(boundary, b['id'])
        return any(
            evaluate_formula(node.left, trace, {'action': b})
            for b in before
            if b['id'] > boundary
        )
    if isinstance(node, Implies):
        return not evaluate_formula(node.left, trace, ctx) or evaluate_formula(
            node.right, trace, ctx
        )
    if isinstance(node, And):
        return evaluate_formula(node.left, trace, ctx) and evaluate_formula(
            node.right, trace, ctx
        )
    if isinstance(node, Or):
        return evaluate_formula(node.left, trace, ctx) or evaluate_formula(
            node.right, trace, ctx
        )
    if isinstance(node, Not):
        return not evaluate_formula(node.body, trace, ctx)

    if isinstance(node, Atom):
        if not ctx:
            return False
        a = ctx['action']
        name = node.name
        if name in ACTION_TYPES:
            return a.get('type') == name
        if name in ARTIFACT_TYPES:
            if a.get('type') == name:
                return True
            for oid in a.get('outputs', []):
                for art in trace.get('artifacts', []):
                    if (
                        art.get('artifact_id') == oid or art.get('name') == oid
                    ) and art.get('artifact_type') == name:
                        return True
            return False
        if name in ('gateway', 'reasoning', 'activity'):
            return a.get('category') == name
        if name == 'action':
            return True
        if name == 'completed':
            return (
                'pass' in a.get('result_summary', '').lower()
                or 'completed' in a.get('result_summary', '').lower()
            )
        if name == 'failed':
            return 'fail' in a.get('result_summary', '').lower()
        if name in ('proved', 'refuted', 'sat'):
            return a.get('vg_result', {}).get('status') == name
        if name == 'high_stakes_path':
            return any(
                p in get_action_target(a, trace)
                for p in ['payments/', 'risk/', 'stripe_payment_flow']
            )
        kw = name.replace('_', ' ').lower()
        text = f'{a.get("type", "")} {a.get("label", "")} {a.get("detail", "")} {a.get("rationale", "")} {a.get("result_summary", "")}'.lower()
        return kw in text

    if isinstance(node, AtomWithArgs):
        if not ctx:
            return False
        a = ctx['action']
        type_match = a.get('type') == node.name
        if not type_match:
            for oid in a.get('outputs', []):
                for art in trace.get('artifacts', []):
                    if (
                        art.get('artifact_id') == oid or art.get('name') == oid
                    ) and art.get('artifact_type') == node.name:
                        type_match = True
                        break
                if type_match:
                    break
        if not type_match:
            return False
        if node.args:
            vr = a.get('vg_result', {})
            for arg in node.args:
                if isinstance(arg, Atom):
                    if vr.get('status') == arg.name:
                        return True
                    for oid in a.get('outputs', []):
                        for art in trace.get('artifacts', []):
                            if art.get('artifact_id') == oid or art.get('name') == oid:
                                if art.get('payload', {}).get('status') == arg.name:
                                    return True
                elif isinstance(arg, Or):
                    if evaluate_formula(arg, trace, ctx):
                        return True
                elif evaluate_formula(arg, trace, ctx):
                    return True
            return False
        return True

    if isinstance(node, FieldNeEmpty):
        if not ctx:
            return False
        val = ctx['action'].get(node.field, '')
        return isinstance(val, str) and len(val) > 0
    if isinstance(node, StartEvent):
        return trace.get('trigger', {}).get('type') in (
            'TaskReceived',
            'TriggeredByEvent',
        )
    if isinstance(node, EndEvent):
        return trace.get('outcome', {}).get('type') in (
            'ProcessCompleted',
            'ProcessAborted',
            'ProcessInterrupted',
        )
    if isinstance(node, RawStructural):
        return evaluate_structural(node.policy_name, trace)
    if isinstance(node, FuncApp):
        if not ctx:
            return False
        a = ctx['action']
        if node.func == 'ref_model':
            req = a.get('request', {})
            if req.get('reference_model_id') == node.arg:
                return True
            return any(
                p.get('reference_model_id') == node.arg
                for p in trace.get('policies', [])
            )
        kw = node.func.replace('_', ' ').lower()
        return (
            kw
            in f'{a.get("type", "")} {a.get("label", "")} {a.get("detail", "")}'.lower()
        )
    return True


def evaluate_structural(policy_name: str, trace: dict) -> bool:
    if policy_name == 'data_flow_integrity':
        actions = sorted(trace.get('actions', []), key=lambda a: a['id'])
        output_map = {}
        for a in actions:
            for o in a.get('_original_outputs', a.get('outputs', [])):
                output_map[o] = a['id']
        for art in trace.get('artifacts', []):
            pid = art.get('producer_action_id')
            if pid is not None:
                output_map[art['artifact_id']] = pid
        for a in actions:
            for inp in a.get('_original_inputs', a.get('inputs', [])):
                if inp not in output_map or output_map[inp] >= a['id']:
                    return False
        return True
    if policy_name == 'goals_reference_valid_artifacts':
        arts = trace.get('artifacts', [])
        iml_ids = {
            a['artifact_id'] for a in arts if a.get('artifact_type') == 'IMLModel'
        }
        for art in arts:
            if art.get('artifact_type') == 'VerificationGoal':
                t = art.get('payload', {}).get('target_artifact_id')
                if t and t not in iml_ids:
                    return False
        return True
    if policy_name == 'files_modified_consistent':
        code_types = {'EditFile', 'CreateFile', 'DeleteFile'}
        actual = set()
        for a in trace.get('actions', []):
            if a.get('type') in code_types:
                for ev in a.get('evidence', []):
                    if ev.get('type') == 'FileRef':
                        actual.add(ev['ref'])
        return actual == set(trace.get('files_modified', []))
    if policy_name == 'generated_tests_require_decomposition':
        arts = trace.get('artifacts', [])
        for art in arts:
            if art.get('artifact_type') == 'GeneratedTests':
                anc = get_ancestors(art['artifact_id'], trace)
                if not any(
                    a.get('artifact_type') in ('Decomposition', 'Decomposition_Art')
                    for a in arts
                    if a['artifact_id'] in anc
                ):
                    return False
        return True
    return True


def evaluate_policy(policy: dict, trace: dict) -> tuple:
    formula_str = policy.get('formula', '')
    name = policy.get('name', '')
    if not formula_str:
        return 'unknown', 'No formula defined'
    if name in STRUCTURAL_POLICIES:
        return ('passed' if evaluate_structural(name, trace) else 'failed'), None
    try:
        tokens = tokenize(formula_str)
        ast = Parser(tokens, formula_str, name).parse()
    except Exception as e:
        return 'unknown', f'Parse error: {e}'
    if isinstance(ast, RawStructural):
        return 'unknown', 'Formula too complex for runtime evaluation'
    try:
        return ('passed' if evaluate_formula(ast, trace) else 'failed'), None
    except Exception as e:
        return 'unknown', f'Evaluation error: {e}'


# ================================================================
# Commands
# ================================================================


@app.command()
def init(
    trace_file: str,
    model: str = typer.Option('claude-opus-4-6', help='LLM model name'),
    assistant: str = typer.Option('claude-code + codelogician', help='Assistant name'),
):
    """Create a new trace file."""
    if os.path.exists(trace_file):
        typer.echo(f'Error: {trace_file} already exists.', err=True)
        raise typer.Exit(1)
    trace = create_empty_trace(model=model, assistant=assistant)
    save_trace(trace_file, trace)
    typer.echo(f'Created trace: {trace["trace_id"]}')
    typer.echo(f'  File: {trace_file}')


@app.command()
def trigger(
    trace_file: str,
    type: str = typer.Option(..., help='TaskReceived or TriggeredByEvent'),
    description: str = typer.Option(..., help='What triggered the process'),
    from_user: str | None = typer.Option(None, help='Who triggered it'),
):
    """Set the trigger event."""
    trace = load_trace(trace_file)
    trace['trigger'] = {'type': type, 'description': description}
    if from_user:
        trace['trigger']['from_user'] = from_user
    save_trace(trace_file, trace)
    typer.echo(f'Trigger set: {type} — {description}')


@app.command()
def action(
    trace_file: str,
    type: str = typer.Option(
        ..., help='Action type (ReadFile, EditFile, Formalize, etc.)'
    ),
    label: str = typer.Option(..., help='Short description'),
    rationale: str = typer.Option(..., help='Why this action was taken'),
    category: str = typer.Option('activity', help='activity, gateway, or reasoning'),
    inputs: str | None = typer.Option(None, help='Comma-separated input artifact IDs'),
    outputs: str | None = typer.Option(
        None, help='Comma-separated output artifact IDs'
    ),
    detail: str | None = typer.Option(None, help='Extended description'),
    result_summary: str | None = typer.Option(None, help='One-line result summary'),
    evidence: str | None = typer.Option(None, help='File path for evidence'),
):
    """Append an action to the trace."""
    trace = load_trace(trace_file)
    aid = next_action_id(trace)
    act = {
        'id': aid,
        'category': category,
        'type': type,
        'label': label,
        'rationale': rationale,
        'inputs': [x.strip() for x in inputs.split(',')] if inputs else [],
        'outputs': [x.strip() for x in outputs.split(',')] if outputs else [],
    }
    if detail:
        act['detail'] = detail
    if result_summary:
        act['result_summary'] = result_summary
    if evidence:
        act['evidence'] = [{'type': 'FileRef', 'ref': evidence}]
    trace['actions'].append(act)
    save_trace(trace_file, trace)
    typer.echo(f'Action #{aid}: {type} — {label}')


@app.command()
def artifact(
    trace_file: str,
    id: str | None = typer.Option(None, help='Artifact ID (auto-generated if omitted)'),
    type: str = typer.Option(..., help='Artifact type'),
    name: str = typer.Option(..., help='Human-readable name'),
    derived_from: str | None = typer.Option(
        None, help='Comma-separated parent artifact IDs'
    ),
    producer_action_id: int | None = typer.Option(
        None, help='Action that produced this'
    ),
    format: str | None = typer.Option(None, help='Format (python, iml, json, etc.)'),
    summary: str | None = typer.Option(None, help='Brief description'),
):
    """Add an artifact to the trace."""
    trace = load_trace(trace_file)
    art_id = id or f'a{len(trace.get("artifacts", [])) + 1}'
    art: dict[str, Any] = {'artifact_id': art_id, 'artifact_type': type, 'name': name}
    if derived_from:
        art['derived_from'] = [x.strip() for x in derived_from.split(',')]
    if producer_action_id is not None:
        art['producer_action_id'] = producer_action_id
    if format:
        art['format'] = format
    if summary:
        art['summary'] = summary
    trace.setdefault('artifacts', []).append(art)
    save_trace(trace_file, trace)
    typer.echo(f'Artifact: {art_id} ({type}) — {name}')


@app.command()
def complete(
    trace_file: str,
    summary: str | None = typer.Option(None, help='Outcome summary'),
):
    """Mark the trace as completed."""
    trace = load_trace(trace_file)
    trace['outcome'] = {'type': 'ProcessCompleted', 'summary': summary or ''}
    trace['metrics'] = {'total_actions': len(trace.get('actions', []))}
    save_trace(trace_file, trace)
    typer.echo(f'Trace completed: {summary or "(no summary)"}')


@app.command()
def check(
    trace_file: str,
    policy_file: str | None = typer.Option(None, help='External policy JSON file'),
    strict: bool = typer.Option(False, help='Treat warnings as errors'),
):
    """Check the trace against policies."""
    trace = load_trace(trace_file)
    normalize_trace(trace)

    if policy_file:
        with open(policy_file) as f:
            pd = json.load(f)
        policies = pd if isinstance(pd, list) else pd.get('policies', [])
    else:
        policies = trace.get('policies', [])

    if not policies:
        typer.echo('No policies to check.')
        return

    total, passed, failed, errors = len(policies), 0, 0, []
    for p in policies:
        pname = p.get('name', p.get('policy_id', '?'))
        sev = p.get('severity', 'error')
        _, syn_errors, _ = syntax_check_policy(p)
        if syn_errors:
            typer.echo(f'  SYNTAX  {pname}')
            for e in syn_errors:
                typer.echo(f'          {e.message}')
            errors.append(pname)
            continue
        status, note = evaluate_policy(p, trace)
        if status == 'passed':
            passed += 1
            typer.echo(f'  PASS    {pname}')
        elif status == 'failed':
            failed += 1
            icon = 'FAIL' if sev == 'error' else 'WARN'
            typer.echo(f'  {icon}    {pname}')
            if note:
                typer.echo(f'          {note}')
            if sev == 'error':
                errors.append(pname)
        else:
            typer.echo(f'  SKIP    {pname} — {note or "could not evaluate"}')

    typer.echo(f'\n{"=" * 50}')
    typer.echo(f'  {total} policies checked')
    typer.echo(f'  {passed} passed, {failed} failed')
    if errors:
        typer.echo(f'  {len(errors)} errors: {", ".join(errors)}')
        raise typer.Exit(1)
    if strict and failed > 0:
        raise typer.Exit(1)


@app.command()
def status(trace_file: str):
    """Show trace summary."""
    trace = load_trace(trace_file)
    typer.echo(f'Trace: {trace.get("trace_id", "N/A")}')
    typer.echo(f'  Spec:      v{trace.get("spec_version", "?")}')
    typer.echo(f'  Model:     {trace.get("model", "N/A")}')
    typer.echo(f'  Assistant: {trace.get("assistant", "N/A")}')
    typer.echo(f'  Timestamp: {trace.get("timestamp", "N/A")}')
    trig = trace.get('trigger', {})
    typer.echo(
        f'  Trigger:   {trig.get("type", "?")} — {trig.get("description", "")}'
        if trig
        else '  Trigger:   (not set)'
    )
    out = trace.get('outcome', {})
    typer.echo(
        f'  Outcome:   {out["type"]} — {out.get("summary", "")}'
        if out.get('type')
        else '  Outcome:   (incomplete)'
    )
    typer.echo(f'  Actions:   {len(trace.get("actions", []))}')
    typer.echo(f'  Artifacts: {len(trace.get("artifacts", []))}')
    typer.echo(f'  Policies:  {len(trace.get("policies", []))}')
    if trace.get('actions'):
        typer.echo('\n  Action log:')
        for a in trace['actions']:
            typer.echo(f'    #{a["id"]:3d}  {a["type"]:20s}  {a["label"][:60]}')


@app.command()
def view(trace_file: str):
    """Open trace in the browser visualizer."""
    trace = load_trace(trace_file)
    trace_json = json.dumps(trace, ensure_ascii=False)

    viz_paths = [
        os.path.join(
            os.path.dirname(__file__), 'visualizer.html'
        ),  # bundled with package
        os.path.join(
            os.path.dirname(__file__),
            '..',
            '..',
            '..',
            'vscode-codelogician-traces',
            'media',
            'visualizer.html',
        ),  # dev repo
        'visualizer.html',  # current directory
    ]
    viz_path = None
    for p in viz_paths:
        if os.path.exists(p):
            viz_path = os.path.abspath(p)
            break
    if not viz_path:
        typer.echo('Error: visualizer.html not found.', err=True)
        raise typer.Exit(1)

    with open(viz_path) as f:
        html = f.read()

    loader = f'<script>(function(){{var _t={trace_json};function _l(){{if(typeof loadTrace==="function"){{loadTrace(_t);var b=document.getElementById("demoBadge");if(b)b.style.display="none";var s=document.getElementById("demoSelect");if(s)s.value=""}}else setTimeout(_l,50)}};setTimeout(_l,200)}})();</script>'
    html = html.replace('</body>', loader + '\n</body>')

    port = 18924

    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(html.encode())

        def log_message(self, format: str, *a):
            pass

    server = http.server.HTTPServer(('127.0.0.1', port), H)
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    typer.echo(f'Visualizer at http://127.0.0.1:{port}')
    typer.echo('Press Ctrl+C to stop.')
    webbrowser.open(f'http://127.0.0.1:{port}')
    try:
        t.join()
    except KeyboardInterrupt:
        server.shutdown()
        typer.echo('\nStopped.')
