from pathlib import Path

from .md_utils import parse_frontmatter

CURR_DIR = Path(__file__).parent

skill_md = (CURR_DIR / 'skill' / 'SKILL.md').read_text()

_, skill_md_body = parse_frontmatter(skill_md)

DOC_COMMAND_HELP_HUMAN = """\
Dump and search documentation, guides and ImandraX reference.

If you are a coding agent, call `doc help` subcommand with the `--agent` flag to see
agent-specific documentation.
"""

DOC_COMMAND_HELP_AGENT = f"""\
Dump and search documentation, guides and ImandraX reference.

The following is excerpted from the SKILL.md file:
{skill_md_body}
"""
