from typing import Any

import yaml


def parse_frontmatter(md: str) -> tuple[dict[str, Any] | None, str]:
    """Parse a markdown file and return its frontmatter and content."""
    if not md.startswith('---'):
        return None, md
    end = md.find('---', 3)
    if end == -1:
        return None, md
    fm_str = md[3:end].strip()
    body = md[end + 3 :].lstrip('\n')
    try:
        fm = yaml.safe_load(fm_str)
    except yaml.YAMLError:
        return None, md
    return fm, body
