#
#   Imandra Inc.
#
#   codelogician/commands/cmd_rec.py
#

# pyright: strict
import sys
from pathlib import Path
from typing import Annotated

import typer
from imandrax_api_models import EvalRes
from imandrax_tools.iml_eval_corpus.common import BaseDiag
from imandrax_tools.iml_eval_corpus.corpus import check_all
from imandrax_tools.iml_eval_corpus.format import format_diagnostics
from pydantic import TypeAdapter

REC_COMMAND_HELP = 'Suggest next step based on IML code and eval result'

app = typer.Typer(name='Rec', help=REC_COMMAND_HELP)


@app.command(help=REC_COMMAND_HELP)
def check(
    iml: Annotated[Path, typer.Argument(help='Path of IML file')],
    eval_res: Annotated[Path, typer.Option(help='Path of eval result JSON')],
    json: Annotated[
        bool,
        typer.Option(
            help='Whether to output the results in JSON format.',
        ),
    ] = False,
    # TODO: support exclude / include rules
):
    iml_src: str
    if str(iml) == '-':
        iml_src = sys.stdin.read()
    elif not iml.exists():
        typer.secho(f'IML path {iml} does not exist.', err=True)
        return
    else:
        iml_src = iml.read_text()

    if not eval_res.exists():
        typer.secho(f'Eval result path {eval_res} does not exist.', err=True)
        return

    try:
        eval_res_v = EvalRes.model_validate_json(eval_res.read_bytes())
    except Exception as e:
        msg = ''
        msg += 'Unable to parse eval result:\n'
        msg += f'{e!s}'
        typer.secho(msg, err=True)
        return

    diags = check_all(iml_src, eval_res_v)
    if len(diags) == 0:
        typer.echo('All checks passed!')
    else:
        if json:
            out = TypeAdapter(list[BaseDiag]).dump_json(diags)
            typer.echo(out)
            return
        else:
            out = ''
            out += f'Found {len(diags)} diagnostics:\n'
            diags_str = format_diagnostics(diags, iml_src)
            out += diags_str
            typer.echo(out)
            return
