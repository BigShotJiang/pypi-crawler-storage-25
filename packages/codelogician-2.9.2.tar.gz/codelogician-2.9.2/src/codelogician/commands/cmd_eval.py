#
#   Imandra Inc.
#
#   codelogician/commands/cmd_eval.py
#

# pyright: strict
# pyright: reportMissingTypeStubs=false
import asyncio
import json as jsonlib
import os
import sys
from collections.abc import Callable
from functools import wraps
from pathlib import Path
from typing import (
    Annotated,
    Any,
    Literal,
    TypedDict,
    assert_never,
    cast,
)

import structlog
import typer
import yaml
from imandrax_api.twirp.exceptions import TwirpServerException
from imandrax_api_models import DecomposeRes, InstanceRes, Task, VerifyRes
from imandrax_api_models.client import (
    ImandraXAsyncClient,
    ImandraXClient,
    get_imandrax_async_client,
    get_imandrax_client,
)
from imandrax_api_models.context_utils import (
    format_eval_res,
    remove_art_and_task_fields,
)
from imandrax_api_models.logging_utils import configure_logging
from imandrax_api_models.region_decomp import HumDecomposeRes, mk_dumper
from imandrax_api_models.yaml_utils import ImandraXAPIModelDumper
from imandrax_tools import get_goal_state_opt
from imandrax_tools.iml_eval_corpus.common import BaseDiag
from imandrax_tools.iml_eval_corpus.corpus import check_all as check_all_diags
from imandrax_tools.iml_eval_corpus.format import format_diagnostics
from iml_query.multifile import gather_modules, parse_imports
from iml_query.processing import (
    get_decomp_reqs,
    get_instance_reqs,
    get_verify_reqs,
)
from iml_query.processing.decomp import DecompReqArgs
from pydantic import TypeAdapter

from codelogician.util import (
    ImandraAPIAccessDenied,
    ImandraAPIKeyError,
    get_imandra_uni_key_or_exit,
)

logger = structlog.getLogger(__name__)

app = typer.Typer(name='Eval')

HELP_ENV_VAR = """\
Environment variables:
    IMANDRAX_ENV: (dev, prod) environment for ImandraX
    CODELOGICIAN_DEBUG: (true, false) debug mode
"""

if os.environ.get('CODELOGICIAN_DEBUG', 'false').lower() == 'true':
    configure_logging('debug')
else:
    configure_logging('warning')


class YDumper(yaml.Dumper):
    pass


# Merge representers from RegionDecompDumper into YDumper.
# Multiple inheritance doesn't merge yaml_representers dicts, so we do it manually.
YDumper.yaml_representers = {
    **ImandraXAPIModelDumper.yaml_representers,
    **mk_dumper().yaml_representers,
}


def suppress_exceptions(func: Callable[..., Any]) -> Callable[..., Any]:
    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except Exception as e:
            logger.debug('Exception suppressed', func=func.__name__, exc_info=e)  # ty: ignore[unresolved-attribute]
            return None

    return wrapper


def _load_iml(path: str | None) -> str:
    """Read IML code from a file or stdin."""
    if (path is None) or (path == '-'):
        # Read from stdin if no path is provided
        iml = sys.stdin.read()
        if parse_imports(iml):
            msg = (
                'Error: IML content passed via stdin contains `[@@@import ...]` statements, which are ignored.'
                'Pass the IML file to properly load imported modules '
            )
            logger.error(msg)
            typer.secho(msg, err=True)
            typer.Exit(1)
    elif not Path(path).exists():
        raise typer.BadParameter(f'IML file {path} does not exist')
    else:
        iml = gather_modules(Path(path))
    logger.debug('Loaded IML', iml=iml)
    return iml


def _handle_api_errors[F: Callable[..., Any]](func: F) -> F:
    """Decorator to wrap ImandraX API errors."""

    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        try:
            return func(*args, **kwargs)
        except TwirpServerException as e:
            meta = cast(dict[str, Any], e.meta)  # pyright: ignore[reportUnknownMemberType]
            if meta.get('http_error_from_intermediary') == 'true':
                status = str(meta.get('status_code', 'unknown'))
                body = str(meta.get('body', ''))
                msg = f'Error: Imandra API returned HTTP {status}.\nDetails: {body}'
                if func.__name__ == 'check_decomp':
                    msg += (
                        '\nHint: This may happen when the decomposition is too large. '
                    )
                typer.secho(msg, err=True)
                return
            reason: str = cast(str, meta['body']['error'])
            match cast(str, e.message):
                case 'Unauthorized':
                    typer.secho(
                        f'Error: Access to Imandra API not authorized ({reason}).\n'
                        'Hint: Check you have a valid API key in your IMANDRA_UNI_KEY environment variable.',
                        err=True,
                    )
                case 'Forbidden':
                    typer.secho(
                        f'Error: Access to Imandra API forbidden ({reason}).\n'
                        f'Hint: {ImandraAPIAccessDenied("").hint}',
                        err=True,
                    )
                case _ as err_msg:
                    typer.secho(err_msg, err=True)
        except ImandraAPIKeyError as e:
            typer.secho(f'Error: {str(e)}\nHint: {e.hint}', err=True)

    return cast(F, wrapper)


# Eval
# ====================


@app.callback(invoke_without_command=True)
def _main(  # pyright: ignore[reportUnusedFunction]
    ctx: typer.Context,
):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())


@app.command(
    name='check',
    help='Evaluate an IML file (without VG and decomp by default).',
)
@_handle_api_errors
def check(
    file: Annotated[
        str | None,
        typer.Argument(
            help='Path of the IML file to evaluate. Set to "-" to read from stdin.',
        ),
    ] = None,
    with_vgs: Annotated[
        bool,
        typer.Option(
            help='Whether to strip verify and instance requests before evaluating.',
        ),
    ] = False,
    with_decomps: Annotated[
        bool,
        typer.Option(
            help='Whether to decomp requests before evaluating.',
        ),
    ] = False,
    json: Annotated[
        bool,
        typer.Option(
            help='Whether to output the results in JSON format.',
        ),
    ] = False,
):
    iml = _load_iml(file)

    c: ImandraXClient = get_imandrax_client(auth_token=get_imandra_uni_key_or_exit())
    eval_res = c.eval_model(src=iml, with_vgs=with_vgs, with_decomps=with_decomps)

    # Try to get the goal state
    goal_state_s: str | None = None
    if eval_res.success and eval_res.tasks:
        # TODO(Q): is this always the first task?
        task: Task = eval_res.tasks[0]
        goal_state_s = suppress_exceptions(get_goal_state_opt)(c, task)

    # Diags
    diags = check_all_diags(iml, eval_res)
    diags = diags[:3]  #! truncate to 3 diags

    # Return
    if not json:
        # str
        out: dict[str, str] = {}  # pyright: ignore[reportRedeclaration]
        out['eval_res'] = format_eval_res(eval_res, iml)
        if goal_state_s:
            out['goal_state'] += goal_state_s
        if len(diags) > 0:
            s = ''
            diags_str = format_diagnostics(diags, iml)
            s += f'Found {len(diags)} diagnostics:\n'
            s += diags_str
            out['diagnostics'] = s
        if len(out) == 1:
            typer.echo(out['eval_res'])
        else:
            # multiple section, use XML tags
            out_s = ''
            for k, v in out.items():
                out_s += f'<{k}>\n{v.strip()}\n</{k}>\n'
            typer.echo(out_s)
    else:
        # json str
        out: dict[str, Any] = {}
        out['eval_res'] = eval_res.model_dump(mode='json')
        out['goal_state'] = goal_state_s
        out['diagnostics'] = TypeAdapter(list[BaseDiag]).dump_python(diags, mode='json')
        typer.echo(jsonlib.dumps(out, indent=2))


# VG
# ====================


class CheckVGReq(TypedDict):
    kind: Literal['verify', 'instance']
    src: str
    hints: str | None
    start_point: tuple[int, int]
    end_point: tuple[int, int]


def _collect_vg_reqs(iml: str) -> list[CheckVGReq]:
    iml_, verify_reqs, verify_req_ranges = get_verify_reqs(iml)
    _iml, instance_reqs, instance_req_ranges = get_instance_reqs(iml_)

    # Collect
    vg_items: list[CheckVGReq] = []
    for req, req_range in zip(verify_reqs, verify_req_ranges, strict=True):
        vg_items.append(
            {
                'kind': 'verify',
                'src': req['src'],
                'hints': req['hints'],
                'start_point': (req_range.start_point[0], req_range.start_point[1]),
                'end_point': (req_range.end_point[0], req_range.end_point[1]),
            }
        )
    for req, req_range in zip(instance_reqs, instance_req_ranges, strict=False):
        vg_items.append(
            {
                'kind': 'instance',
                'src': req['src'],
                'hints': req['hints'],
                'start_point': (req_range.start_point[0], req_range.start_point[1]),
                'end_point': (req_range.end_point[0], req_range.end_point[1]),
            }
        )
    vg_items.sort(key=lambda x: x['start_point'])
    return vg_items


@app.command(
    name='list-vg',
    help='List verification goals specified by `verify` or `instance` commands in an IML file.',
)
def list_vg(
    file: Annotated[
        str | None,
        typer.Argument(
            help='Path of the IML file to check. Set to "-" to read from stdin.',
        ),
    ] = None,
    json: Annotated[
        bool,
        typer.Option(
            help='Whether to output the results in JSON format.',
        ),
    ] = False,
):
    iml = _load_iml(file)

    vg_reqs: list[CheckVGReq] = _collect_vg_reqs(iml)

    if not json:
        for i, item in enumerate(vg_reqs):
            loc_str = (
                f'{item["start_point"][0]}:{item["start_point"][1]}'
                f'-{item["end_point"][0]}:{item["end_point"][1]}'
            )
            hint_str = f' {item["hints"]}' if item['hints'] else ''
            typer.echo(f'{i}: {item["kind"]} ({loc_str}): {item["src"]}{hint_str}')
    else:
        json_s = TypeAdapter(list[CheckVGReq]).dump_json(vg_reqs, indent=2)
        typer.echo(json_s)


@app.command(
    name='check-vg',
    help='Execute verification goals specified by `verify` or `instance` commands in an IML file.',
)
@_handle_api_errors
def check_vg(
    file: Annotated[
        str | None,
        typer.Argument(
            help='Path of the IML file to check. Set to "-" to read from stdin.',
        ),
    ] = None,
    index: Annotated[
        list[int] | None,
        typer.Option(
            help='Name of the verification goal to check.',
        ),
    ] = None,
    check_all: Annotated[
        bool,
        typer.Option(
            help='Whether to check all verify requests in the IML file.',
        ),
    ] = False,
    json: Annotated[
        bool,
        typer.Option(
            help='Whether to output the results in JSON format.',
        ),
    ] = False,
):
    index = index or []

    class CheckVGRes(TypedDict):
        vg_req_index: int
        kind: Literal['verify', 'instance']
        src: str
        vg_res: dict[str, Any]

    class Res(TypedDict):
        eval_res: Literal['Success'] | tuple[Literal['Fail'], dict[str, Any]]
        diags: list[BaseDiag]
        vg_res_list: list[CheckVGRes]

    async def _async_check_vg() -> Res:
        iml = _load_iml(file)
        vg_reqs = _collect_vg_reqs(iml)

        index_: list[int] = (
            list(range(len(vg_reqs))) if check_all or (len(index) == 0) else index
        )

        vg_with_idx: list[tuple[int, CheckVGReq]] = [
            (i, vg) for (i, vg) in enumerate(vg_reqs) if i in index_
        ]

        async def _check_vg(
            vg: CheckVGReq,
            i: int,
            c: ImandraXAsyncClient,
        ) -> VerifyRes | InstanceRes:
            match vg['kind']:
                case 'verify':
                    return await c.verify_src(src=vg['src'], hints=vg['hints'])
                case 'instance':
                    return await c.instance_src(src=vg['src'], hints=vg['hints'])
                case _:
                    assert_never(vg['kind'])

        async with get_imandrax_async_client(
            auth_token=get_imandra_uni_key_or_exit()
        ) as c:
            eval_res = await c.eval_model(src=iml)
            eval_res_out: Literal['Success'] | tuple[Literal['Fail'], dict[str, Any]]
            if not eval_res.has_errors:
                eval_res_out = 'Success'
            else:
                eval_res_out = ('Fail', eval_res.model_dump(mode='json'))

            diags = check_all_diags(iml, eval_res)

            tasks = [_check_vg(vg, i, c) for (i, vg) in vg_with_idx]
            vg_res_list: list[VerifyRes | InstanceRes] = await asyncio.gather(*tasks)

            cv_res_list: list[CheckVGRes] = []
            for idx, vg_res in enumerate(vg_res_list):
                (i, vg_item) = vg_with_idx[idx]
                cv_res_list.append(
                    CheckVGRes(
                        vg_req_index=i,
                        kind=vg_item['kind'],
                        src=vg_item['src'],
                        vg_res=remove_art_and_task_fields(
                            vg_res.model_dump(mode='json')
                        ),
                    )
                )

            return Res(eval_res=eval_res_out, diags=diags, vg_res_list=cv_res_list)

    res: Res = asyncio.run(_async_check_vg())
    if json:
        s = jsonlib.dumps(res, indent=2)
    else:
        s = yaml.dump(res, Dumper=YDumper, sort_keys=False)
    echo_err: bool = res['eval_res'] != 'Success'
    typer.echo(s, err=echo_err)


# decomp
# ====================


class CheckDecompReq(TypedDict):
    req_args: DecompReqArgs
    start_point: tuple[int, int]
    end_point: tuple[int, int]


def _collect_decomp_reqs(iml: str) -> list[CheckDecompReq]:
    iml, decomp_reqs, ranges = get_decomp_reqs(iml)

    decomp_items: list[CheckDecompReq] = [
        CheckDecompReq(
            req_args=req,
            start_point=range_.start_point,
            end_point=range_.end_point,
        )
        for req, range_ in zip(decomp_reqs, ranges, strict=True)
    ]

    decomp_items.sort(key=lambda x: x['start_point'])
    return decomp_items


@app.command(
    name='list-decomp',
    help='List decomp requests in an IML file.',
)
def list_decomp(
    file: Annotated[
        str | None,
        typer.Argument(
            help='Path of the IML file to check. Set to "-" to read from stdin.',
        ),
    ] = None,
    json: Annotated[
        bool,
        typer.Option(
            help='Whether to output the results in JSON format.',
        ),
    ] = False,
):
    iml = _load_iml(file)
    decomp_reqs: list[CheckDecompReq] = _collect_decomp_reqs(iml)

    if not json:
        for i, item in enumerate(decomp_reqs):
            typer.echo(f'{i}: {item["req_args"]["name"]}')
    else:
        json_s = TypeAdapter(list[CheckDecompReq]).dump_json(decomp_reqs, indent=2)
        typer.echo(json_s)


@app.command(
    name='check-decomp',
    help='Execute decomp requests in an IML file.',
)
@_handle_api_errors
def check_decomp(
    file: Annotated[
        str | None,
        typer.Argument(
            help='Path of the IML file to check. Set to "-" to read from stdin.',
        ),
    ] = None,
    index: Annotated[
        list[int] | None,
        typer.Option(
            help='Index of the decomposition request to check.',
        ),
    ] = None,
    check_all: Annotated[
        bool,
        typer.Option(
            help='Whether to check all decomp requests in the IML file.',
        ),
    ] = False,
    json: Annotated[
        bool,
        typer.Option(
            help='Whether to output the results in JSON format.',
        ),
    ] = False,
):
    index = index or []

    class CheckDecompRes(TypedDict):
        decomp_req_index: int
        function_name: str
        decomp_res: dict[str, Any]

    class Res(TypedDict):
        eval_res: Literal['Success'] | tuple[Literal['Fail'], dict[str, Any]]
        diags: list[BaseDiag]
        decomp_res_list: list[CheckDecompRes]

    async def _async_check_decomp() -> Res:
        iml = _load_iml(file)
        decomp_reqs = _collect_decomp_reqs(iml)

        # Indexing decomp
        index_: list[int] = (
            list(range(len(decomp_reqs))) if check_all or (len(index) == 0) else index
        )
        decomp_with_idx: list[tuple[int, CheckDecompReq]] = [
            (i, decomp) for (i, decomp) in enumerate(decomp_reqs) if i in index_
        ]

        async def _check_decomp(
            decomp: CheckDecompReq, i: int, c: ImandraXAsyncClient
        ) -> HumDecomposeRes:
            decomp_res: DecomposeRes = await c.decompose(**decomp['req_args'])
            return HumDecomposeRes.from_decomp_res(decomp_res)

        async with get_imandrax_async_client(
            auth_token=get_imandra_uni_key_or_exit()
        ) as c:
            eval_res = await c.eval_model(src=iml)
            eval_res_out: Literal['Success'] | tuple[Literal['Fail'], dict[str, Any]]
            if not eval_res.has_errors:
                eval_res_out = 'Success'
            else:
                eval_res_out = ('Fail', eval_res.model_dump(mode='json'))

            diags = check_all_diags(iml, eval_res)

            tasks = [_check_decomp(decomp, i, c) for (i, decomp) in decomp_with_idx]
            hum_decomp_res_list: list[HumDecomposeRes] = await asyncio.gather(*tasks)

            cd_res_list: list[CheckDecompRes] = []
            for i, hum_decomp_res in enumerate(hum_decomp_res_list):
                (i, decomp_item) = decomp_with_idx[i]
                name = decomp_item['req_args']['name']
                cd_res_list.append(
                    CheckDecompRes(
                        decomp_req_index=i,
                        function_name=name,
                        decomp_res=hum_decomp_res.to_dict_flat(),
                    )
                )

            return Res(eval_res=eval_res_out, diags=diags, decomp_res_list=cd_res_list)

    res: Res = asyncio.run(_async_check_decomp())
    if json:
        jsonable_dict = yaml.safe_load(yaml.dump(res, Dumper=YDumper, sort_keys=False))
        s = jsonlib.dumps(jsonable_dict, indent=2)
    else:
        s = yaml.dump(res, Dumper=YDumper, sort_keys=False)
    echo_err: bool = res['eval_res'] != 'Success'
    typer.echo(s, err=echo_err)


gen_test_command_spec: dict[str, str] = {
    'name': 'gen-test',
    'help': 'Generate test cases in Python / TypeScript from region decomp in IML.',
}

# Conditionally add gen-test command
try:
    from imandrax_codegen.gen_src import Lang, gen_test_cases
    from imandrax_codegen.unparse import join_code_parts

    @app.command(
        name=gen_test_command_spec['name'],
        help=gen_test_command_spec['help'],
    )
    def gen_test_command(
        iml_path: Annotated[
            str,
            typer.Argument(
                help='Path of IML file to generate test cases (use "-" for stdin)'
            ),
        ],
        function: Annotated[
            str,
            typer.Option(
                '-f', '--function', help='Name of function to generate test cases for'
            ),
        ],
        lang: Annotated[
            str,
            typer.Option('-l', '--lang', help='Target language'),
        ],
        output: Annotated[
            str | None,
            typer.Option(
                '-o', '--output', help='Output file path (defaults to stdout)'
            ),
        ] = None,
    ) -> None:
        """Generate test cases in Python / TypeScript from region decomp in IML."""
        iml = _load_iml(iml_path)

        target_lang: Lang
        lang_lower = lang.lower()
        if lang_lower in ('typescript', 'ts'):
            target_lang = 'typescript'
        elif lang_lower in ('python', 'py'):
            target_lang = 'python'
        else:
            raise typer.BadParameter(
                f'Unsupported language: {lang}. Only TypeScript and Python are supported.'
            )

        type_def, test_def = gen_test_cases(
            iml,
            function,
            lang=target_lang,
            imandrax_api_key=get_imandra_uni_key_or_exit(),
        )
        result = join_code_parts([type_def, test_def])

        if output:
            Path(output).write_text(result)
        else:
            typer.echo(result, nl=not result.endswith('\n'))
except ModuleNotFoundError:

    @app.command(
        name=gen_test_command_spec['name'],
        help=gen_test_command_spec['help'],
    )
    def empty_gen_test_command():
        msg = (
            f'Error: {gen_test_command_spec["name"]} command requires `imandrax-codegen` optional dependency.\n'
            'Please re-install CodeLogician with optional dependency: `codelogician[codegen]`'
        )
        typer.echo(msg)
        typer.Exit(1)


if __name__ == '__main__':
    app()
