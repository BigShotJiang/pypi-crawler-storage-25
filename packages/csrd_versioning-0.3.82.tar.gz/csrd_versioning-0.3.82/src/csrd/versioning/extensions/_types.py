"""Core types for the unified plugin extension system.

This module is a dependency leaf: it imports no host-specific modules.
All host modules (`actuator`, `swagger_ui`, custom) import from here.
"""

from dataclasses import dataclass
from typing import Any, Protocol


@dataclass(frozen=True)
class ExtensionContext:
    """Read-only metadata passed to plugin contributions.

    Plugins should not assume any context fields exist beyond their host's
    documented interface.
    """

    host: str
    """Host name: 'actuator', 'swagger_ui', or custom."""

    # Additional context fields added by specific hosts at contribution time


class HostPlugin(Protocol):
    """Host-agnostic plugin protocol for all extension hosts.

    Plugins implement this to contribute to any host (actuator, swagger_ui, custom).
    The plugin registers itself and returns host-specific contributions.
    """

    name: str
    """Unique plugin identifier. User plugins with same name override defaults."""

    host: str
    """Target host: 'actuator', 'swagger_ui', or custom host name."""

    order: int
    """Registration order within host (lower = earlier). Default 100."""

    enabled_by_default: bool
    """Whether this plugin is enabled unless explicitly disabled. Default True."""

    def contribute(self, ctx: ExtensionContext) -> Any:
        """Return host-specific contribution (e.g., SwaggerPluginContribution for swagger_ui).

        Called at host initialization time. Returns should be idempotent.
        May raise exceptions; host will log warnings and skip the plugin.
        """
