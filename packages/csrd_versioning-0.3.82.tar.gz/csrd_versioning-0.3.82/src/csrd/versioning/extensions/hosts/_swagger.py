"""Swagger UI host adapter.

Manages swagger plugins using the unified extension system.
Provides backward compatibility with existing SwaggerPlugin interface.
"""

import logging
from collections.abc import Sequence

from csrd.versioning.swagger_plugins._base import SwaggerPlugin as LegacySwaggerPlugin

logger = logging.getLogger(__name__)


class SwaggerHostAdapter:
    """Manages plugin resolution and execution for the swagger_ui host."""

    @staticmethod
    def resolve_plugins(
        defaults: Sequence[LegacySwaggerPlugin],
        global_plugins: Sequence[LegacySwaggerPlugin] | None = None,
        per_version_plugins: Sequence[LegacySwaggerPlugin] | None = None,
    ) -> tuple[LegacySwaggerPlugin, ...]:
        """Resolve plugins using current by-name override semantics.

        This is the bridge function that maintains the existing
        _resolve_swagger_plugins behavior while ready for future extension system integration.
        """
        if global_plugins is not None and len(global_plugins) == 0:
            return ()

        resolved: dict[str, LegacySwaggerPlugin] = {p.name: p for p in defaults}

        if global_plugins:
            for p in global_plugins:
                resolved[p.name] = p

        if per_version_plugins is not None and len(per_version_plugins) == 0:
            return ()

        if per_version_plugins:
            for p in per_version_plugins:
                resolved[p.name] = p

        return tuple(resolved.values())
