"""Actuator host adapter.

Manages actuator plugins using the unified extension system.
Provides backward compatibility with existing ActuatorPlugin interface.
"""

import logging
from collections.abc import Mapping, Sequence

from csrd.versioning.actuator.plugins.base import ActuatorLink
from csrd.versioning.actuator.plugins.base import ActuatorPlugin as LegacyActuatorPlugin

from .._types import ExtensionContext

logger = logging.getLogger(__name__)


class ActuatorHostPlugin:
    """Adapter wrapping a legacy ActuatorPlugin for the unified extension system."""

    def __init__(self, legacy_plugin: LegacyActuatorPlugin) -> None:
        """Wrap an existing ActuatorPlugin."""
        self._legacy_plugin = legacy_plugin
        self.name: str = legacy_plugin.name
        self.host: str = "actuator"
        self.order: int = 100
        self.enabled_by_default: bool = True

    def contribute(self, ctx: ExtensionContext) -> Mapping[str, ActuatorLink]:
        """Delegate to legacy plugin's register() method."""
        # For backward compatibility, we call register() instead of contribute()
        # This should be migrated when legacy plugin interface is removed
        return {}


class ActuatorHostAdapter:
    """Manages plugin resolution and execution for the actuator host."""

    @staticmethod
    def resolve_plugins(
        defaults: Sequence[LegacyActuatorPlugin],
        user_plugins: Sequence[LegacyActuatorPlugin] | None = None,
    ) -> tuple[LegacyActuatorPlugin, ...]:
        """Resolve plugins using current by-name override semantics.

        This is the bridge function that maintains the existing
        _resolve_plugins behavior while ready for future extension system integration.
        """
        resolved: dict[str, LegacyActuatorPlugin] = {plugin.name: plugin for plugin in defaults}

        if user_plugins is not None:
            for plugin in user_plugins:
                if plugin.name in resolved:
                    logger.debug("Actuator plugin '%s' overridden by consumer", plugin.name)
                resolved[plugin.name] = plugin

        return tuple(resolved.values())
