"""Optional plugin discovery via entry points.

Supports loading plugins from installed packages without explicit registration.
Keep as opt-in to maintain control over startup behavior.
"""

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._types import HostPlugin

logger = logging.getLogger(__name__)


def discover_plugins(group: str) -> tuple["HostPlugin", ...]:
    """Load plugins from entry points in a group.

    Entry point names should be fully-qualified plugin classes or factory functions.
    Returns discovered plugins ready for registry registration.

    Args:
        group: Entry point group name, e.g., 'csrd.extensions.actuator'

    Returns:
        Tuple of discovered plugins.
    """
    try:
        import importlib.metadata as metadata
    except ImportError:
        logger.warning("importlib.metadata not available; plugin discovery disabled")
        return ()

    discovered = []

    try:
        eps = metadata.entry_points()
        # Support both dict-like (3.9) and SelectableGroups (3.10+) interfaces
        group_eps = eps.get(group) if isinstance(eps, dict) else eps.select(group=group)

        for ep in group_eps:
            try:
                plugin_class_or_factory = ep.load()
                # Try to instantiate if it looks like a class, else call as factory
                if isinstance(plugin_class_or_factory, type):
                    plugin = plugin_class_or_factory()
                else:
                    plugin = plugin_class_or_factory()

                logger.debug("Discovered plugin from entry point %s: %s", ep.name, plugin.name)
                discovered.append(plugin)
            except Exception as e:
                logger.warning("Failed to load plugin from entry point %s: %s", ep.name, e)

    except Exception as e:
        logger.warning("Failed to read entry points for group %s: %s", group, e)

    return tuple(discovered)
