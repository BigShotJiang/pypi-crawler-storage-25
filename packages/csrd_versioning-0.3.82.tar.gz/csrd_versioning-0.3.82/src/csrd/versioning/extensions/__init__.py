"""Unified extension host system for actuator, swagger, and custom hosts."""

from ._discovery import discover_plugins
from ._registry import ExtensionRegistry
from ._types import ExtensionContext, HostPlugin

__all__ = (
    "ExtensionContext",
    "ExtensionRegistry",
    "HostPlugin",
    "discover_plugins",
)
