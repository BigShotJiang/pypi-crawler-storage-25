"""Optional registry for deterministic plugin merge/order/override.

This module handles:
- merging defaults + user plugins by name
- ordering by (order, name)
- enabling/disabling
- discovery contribution

Hosts may use this or manage plugins directly.
"""

import logging
from collections.abc import Sequence
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._types import HostPlugin

logger = logging.getLogger(__name__)


class ExtensionRegistry:
    """Registry for plugins targeting one or more hosts.

    Provides by-name override semantics: defaults load first,
    user plugins override by name, discovery plugins feed in last
    and also follow override rules.
    """

    def __init__(self) -> None:
        """Initialize empty registry."""
        self._plugins: dict[tuple[str, str], HostPlugin] = {}
        """Map (host, name) -> HostPlugin for fast lookup and override."""

    def register_defaults(self, defaults: Sequence["HostPlugin"]) -> None:
        """Register default plugins.

        These load first and can be overridden by explicit or discovered plugins.
        """
        for plugin in defaults:
            key = (plugin.host, plugin.name)
            self._plugins[key] = plugin
            logger.debug("Registered default plugin %s for host %s", plugin.name, plugin.host)

    def register_user(self, plugins: Sequence["HostPlugin"]) -> None:
        """Register user-provided plugins.

        User plugins override defaults and discovered plugins with same (host, name).
        """
        for plugin in plugins:
            key = (plugin.host, plugin.name)
            if key in self._plugins:
                logger.debug(
                    "User plugin %s for host %s overrides default",
                    plugin.name,
                    plugin.host,
                )
            self._plugins[key] = plugin

    def register_discovered(self, plugins: Sequence["HostPlugin"]) -> None:
        """Register discovered plugins (e.g., from entry points).

        Discovered plugins can be overridden by user plugins.
        """
        for plugin in plugins:
            key = (plugin.host, plugin.name)
            if key in self._plugins:
                logger.debug(
                    "Discovered plugin %s for host %s already registered; skipping",
                    plugin.name,
                    plugin.host,
                )
                continue
            self._plugins[key] = plugin
            logger.debug("Registered discovered plugin %s for host %s", plugin.name, plugin.host)

    def resolve_for_host(self, host: str) -> tuple["HostPlugin", ...]:
        """Return plugins for a host, ordered and filtered by enabled status.

        Returns tuple sorted by (order, name) for deterministic behavior.
        """
        host_plugins = [
            plugin
            for (h, _), plugin in self._plugins.items()
            if h == host and plugin.enabled_by_default
        ]
        return tuple(sorted(host_plugins, key=lambda p: (p.order, p.name)))

    def resolve_all(self) -> tuple["HostPlugin", ...]:
        """Return all registered plugins, ordered by (order, name)."""
        all_plugins = [p for p in self._plugins.values() if p.enabled_by_default]
        return tuple(sorted(all_plugins, key=lambda p: (p.order, p.name)))
