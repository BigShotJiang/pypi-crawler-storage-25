"""SQLAlchemy models for the Semvec REST API.

The schema holds only application-level metadata — sessions, clusters,
cluster members, regions, and an audit log. Authentication happens via
the Ed25519 JWT license system (no password/api-key store here).

Ownership is keyed on ``license_subject`` — the ``sub`` claim of the
caller's license JWT. Requests without a subject (legacy / no-ID JWTs)
map to a single shared ``__anonymous__`` subject.
"""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import DeclarativeBase, relationship

ANONYMOUS_SUBJECT = "__anonymous__"


class Base(DeclarativeBase):
    pass


class SessionRecord(Base):
    """One row per active Semvec session.

    The hot semantic state lives in :class:`SessionManager` (in-memory);
    this row only remembers who owns the session, when it was created,
    and what the last interaction count was for audit/monitoring.
    """

    __tablename__ = "semvec_sessions"

    session_id = Column(String(64), primary_key=True)
    license_subject = Column(String(128), nullable=False, index=True)
    dimension = Column(Integer, nullable=False, default=384)
    model_name = Column(String(128), nullable=False, default="all-MiniLM-L6-v2")
    created_at = Column(DateTime, default=lambda: datetime.now(UTC), nullable=False)
    last_used_at = Column(DateTime, default=lambda: datetime.now(UTC), nullable=False)
    interaction_count = Column(Integer, nullable=False, default=0)
    is_active = Column(Boolean, nullable=False, default=True)


class ClusterRecord(Base):
    """One cluster = one shared session across member agents."""

    __tablename__ = "semvec_clusters"

    cluster_id = Column(String(64), primary_key=True)
    license_subject = Column(String(128), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    aggregation_mode = Column(String(32), nullable=False, default="weighted_average")
    coupling_factor = Column(Float, nullable=False, default=0.0)
    created_at = Column(DateTime, default=lambda: datetime.now(UTC), nullable=False)

    members = relationship("ClusterMember", back_populates="cluster", cascade="all, delete-orphan")


class ClusterMember(Base):
    """Mapping: cluster → member agent session."""

    __tablename__ = "semvec_cluster_members"

    id = Column(Integer, primary_key=True, autoincrement=True)
    cluster_id = Column(
        String(64), ForeignKey("semvec_clusters.cluster_id"), nullable=False, index=True
    )
    session_id = Column(String(64), nullable=False, index=True)
    joined_at = Column(DateTime, default=lambda: datetime.now(UTC), nullable=False)

    cluster = relationship("ClusterRecord", back_populates="members")


class RegionRecord(Base):
    """A region groups clusters and tracks consensus drift events."""

    __tablename__ = "semvec_regions"

    region_id = Column(String(64), primary_key=True)
    license_subject = Column(String(128), nullable=False, index=True)
    name = Column(String(255), nullable=False)
    meta_session_id = Column(String(64), nullable=False)
    consensus_threshold = Column(Float, nullable=False, default=0.5)
    vote_window_seconds = Column(Float, nullable=False, default=60.0)
    last_realignment_ts = Column(Float, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(UTC), nullable=False)


class RegionCluster(Base):
    """Mapping: region → cluster."""

    __tablename__ = "semvec_region_clusters"

    id = Column(Integer, primary_key=True, autoincrement=True)
    region_id = Column(
        String(64), ForeignKey("semvec_regions.region_id"), nullable=False, index=True
    )
    cluster_id = Column(String(64), nullable=False, index=True)


class AuditLog(Base):
    """Lightweight per-request audit trail.

    Intentionally minimal — path + outcome + timestamp + license subject.
    No request/response bodies are recorded; use the Prometheus middleware
    for latency + counts.
    """

    __tablename__ = "semvec_audit_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    action = Column(String(64), nullable=False, index=True)
    license_subject = Column(String(128), nullable=True, index=True)
    tier = Column(String(32), nullable=True)
    ip_address = Column(String(45), nullable=True)
    path = Column(String(255), nullable=True)
    detail = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(UTC), nullable=False)
