"""
Generic multi-track media types for the Reactor transport layer.

These types model N named tracks of any kind.  They are intentionally
**not** hard-wired to a specific number of video or audio tracks.  The
transport layer routes each track to the appropriate output based on its
:attr:`TrackInfo.kind`.

Typical usage::

    from reactor_runtime.transports.media import (
        TrackKind, TrackInfo, TrackData, MediaBundle,
    )

    bundle = MediaBundle(tracks={
        "video-0": TrackData(
            info=TrackInfo(name="video-0", kind=TrackKind.VIDEO, rate=30.0),
            data=video_frame,      # (H, W, 3) uint8 RGB
        ),
        "audio-0": TrackData(
            info=TrackInfo(name="audio-0", kind=TrackKind.AUDIO, rate=48000.0),
            data=audio_samples,    # (1, N) int16 mono
        ),
    })

Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

import numpy as np


# =============================================================================
# Inbound frame with timing metadata
# =============================================================================


# ``eq=False`` is deliberate: the auto-generated dataclass ``__eq__``
# would evaluate ``bool(arr1 == arr2)`` on the ``data`` field and raise
# ``ValueError("The truth value of an array is ambiguous")`` for every
# non-scalar ndarray; ``__hash__`` would raise ``TypeError`` because
# ``np.ndarray`` is unhashable.  Identity-based equality (inherited from
# ``object``) is also the right semantics here — two ``InputFrame``s
# wrapping byte-identical pixel data are not "the same frame".
@dataclass(frozen=True, eq=False)
class InputFrame:
    """A single inbound media frame with its presentation timestamp.

    Carries the decoded payload as a NumPy array plus a transport-agnostic
    ``pts`` so model code can align frames across tracks (or against data-
    channel events) without reinventing per-track bookkeeping.

    This is the canonical inbound type at the transport boundary:
    :mod:`reactor_runtime.transports.aiortc` and
    :mod:`reactor_runtime.transports.gstreamer` build it from their native
    frame types (``av.VideoFrame`` / ``Gst.Buffer``) and the runtime carries
    it through :class:`~reactor_runtime.transports.events.VideoFrameEvent`
    and :class:`~reactor_runtime.transports.events.AudioFrameEvent`.

    Attributes:
        data: Decoded payload.

            * **Video**: ``(H, W, 3)`` ``uint8`` RGB for a single frame.
            * **Audio**: ``(1, M)`` ``int16`` mono samples.
        pts: Presentation timestamp in seconds, or ``None`` when the
            transport could not provide one.  For video this is typically
            derived from the RTP timestamp (aiortc: ``frame.pts *
            frame.time_base``; gstreamer: ``buf.pts / Gst.SECOND``).
    """

    data: np.ndarray
    pts: Optional[float] = None


# =============================================================================
# Track Kind
# =============================================================================


class TrackKind(str, Enum):
    """Identifies the kind of media a track carries.

    Using :class:`str` as a mixin so the enum serialises cleanly to JSON
    and is easy to extend in the future.
    """

    VIDEO = "video"
    AUDIO = "audio"


# =============================================================================
# Track Direction
# =============================================================================


class TrackDirection(str, Enum):
    """Direction of data flow for a track, **from the model's perspective**.

    All directions describe which way media flows relative to the model
    process, never relative to the client or the network.

    ``IN``  -- **client → model**.  The model *receives* data from the
               client on this track (e.g. a webcam feed).  Supports
               ``latest()`` to read inbound frames.
    ``OUT`` -- **model → client**.  The model *sends* data to the
               client on this track (e.g. generated video or audio).
               Supports ``emit()`` to push outbound frames.

    Bidirectional data flow is achieved by declaring two separate
    tracks — one ``IN`` and one ``OUT`` — with distinct names.
    """

    IN = "in"
    OUT = "out"


# =============================================================================
# Track Metadata
# =============================================================================


@dataclass(frozen=True)
class TrackInfo:
    """Immutable metadata describing a single media track.

    Attributes:
        name: Unique identifier for this track within a session
            (e.g. ``"main_video"``, ``"main_audio"``).
        kind: The kind of media this track carries.
        rate: Native output rate in units per second.  For video this is
            frames/sec; for audio it is samples/sec (e.g. ``48000``).
            Set to ``0`` when the rate is unknown or not applicable.
        direction: Data-flow direction **from the model's perspective**:
            ``IN`` = client → model, ``OUT`` = model → client.
    """

    name: str
    kind: TrackKind
    rate: float = 0.0
    direction: TrackDirection = TrackDirection.OUT


_CLIENT_DIR_TO_SERVER: Dict[str, TrackDirection] = {
    "recvonly": TrackDirection.OUT,
    "sendonly": TrackDirection.IN,
}


@dataclass
class TrackMapping:
    """Mapping of MID to :class:`TrackInfo`.

    Attributes:
        tracks: Dictionary from track name (MID) to track metadata.
    """

    tracks: Dict[str, TrackInfo] = field(default_factory=dict)

    @classmethod
    def from_client_mapping(cls, entries: List[Dict[str, Any]]) -> "TrackMapping":
        """Build a :class:`TrackMapping` from a client ``track_mapping`` payload.

        The client sends an array of entries mirroring the proto ``Track``
        message, using **client-perspective** WebRTC direction terminology::

            [
                {"mid": "0", "name": "main_video", "kind": "video", "direction": "recvonly"},
                {"mid": "1", "name": "webcam",     "kind": "video", "direction": "sendonly"},
            ]

        ``mid`` is the SDP Media ID (RFC 5888).  ``direction`` is flipped
        to the **model perspective** (``recvonly`` → ``OUT``,
        ``sendonly`` → ``IN``).
        """
        mapping = cls()
        for entry in entries:
            mid = str(entry["mid"])
            kind = TrackKind(entry["kind"])
            direction = _CLIENT_DIR_TO_SERVER.get(entry["direction"])
            if direction is None:
                raise ValueError(f"Unknown track direction: {entry['direction']!r}")
            mapping.tracks[mid] = TrackInfo(
                name=entry["name"],
                kind=kind,
                direction=direction,
            )
        return mapping

    def get_track_by_mid(self, mid: str) -> Optional[TrackInfo]:
        """Return the :class:`TrackInfo` for the given MID, or ``None``."""
        return self.tracks.get(mid)

    def get_tracks_by_direction(self, direction: TrackDirection) -> List[TrackInfo]:
        """Return all :class:`TrackInfo` with the given direction."""
        return [info for info in self.tracks.values() if info.direction == direction]

    def get_mid_by_track_name(self, name: str) -> Optional[str]:
        """Return the mid (dict key) for the track with the given name, or ``None``."""
        for mid, info in self.tracks.items():
            if info.name == name:
                return mid
        return None


# =============================================================================
# Track Payload
# =============================================================================


@dataclass
class TrackData:
    """One track's payload inside a :class:`MediaBundle`.

    Attributes:
        info: Metadata for this track.
        data: NumPy array containing the track payload:

            * **Video**: ``(H, W, 3)`` ``uint8`` RGB for a single frame,
              or ``(N, H, W, 3)`` for a batch of *N* frames.
            * **Audio**: ``(1, M)`` ``int16`` mono samples.
    """

    info: TrackInfo
    data: np.ndarray


# =============================================================================
# Media Bundle
# =============================================================================


@dataclass
class MediaBundle:
    """Synchronised multi-track media unit.

    A ``MediaBundle`` groups together data from one or more named tracks
    that belong to the same logical time interval.  It flows through the
    pipeline from the model to the transport::

        Model -> BucketAccumulator -> FrameBuffer -> Runtime -> Transport

    The :attr:`tracks` dictionary is keyed by track name for O(1)
    lookup.  Helper methods provide kind-based filtering without
    hard-coding any specific track names.
    """

    tracks: Dict[str, TrackData] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Lookup helpers
    # ------------------------------------------------------------------

    def get_track(self, name: str) -> Optional[TrackData]:
        """Return the :class:`TrackData` for *name*, or ``None``."""
        return self.tracks.get(name)

    def get_tracks(self) -> List[TrackData]:
        """Return all tracks in the bundle."""
        return list(self.tracks.values())

    def get_tracks_by_kind(self, kind: TrackKind) -> List[TrackData]:
        """Return all tracks matching the given :class:`TrackKind`."""
        return [td for td in self.tracks.values() if td.info.kind == kind]

    # ------------------------------------------------------------------
    # Derived bundles
    # ------------------------------------------------------------------

    def video_only(self) -> "MediaBundle":
        """Return a copy containing only video tracks."""
        return MediaBundle(
            tracks={
                k: v for k, v in self.tracks.items() if v.info.kind == TrackKind.VIDEO
            }
        )

    # ------------------------------------------------------------------
    # Convenience factories
    # ------------------------------------------------------------------

    @staticmethod
    def from_video_frame(frame: np.ndarray, track_name: str = "video") -> "MediaBundle":
        """Wrap a bare video ``np.ndarray`` into a single-track bundle.

        Used internally to wrap inbound video frames from the transport
        into a ``MediaBundle`` before dispatching to the model.

        Args:
            frame: NumPy array with shape ``(H, W, 3)`` for a single
                frame or ``(N, H, W, 3)`` for a batch.
            track_name: The MID-derived track name (e.g. ``"webcam"``).

        Returns:
            A :class:`MediaBundle` with a single named track.
        """
        info = TrackInfo(
            name=track_name, kind=TrackKind.VIDEO, rate=0.0, direction=TrackDirection.IN
        )
        return MediaBundle(tracks={track_name: TrackData(info=info, data=frame)})
