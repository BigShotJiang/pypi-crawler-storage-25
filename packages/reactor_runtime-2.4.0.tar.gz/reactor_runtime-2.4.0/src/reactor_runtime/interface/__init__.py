# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Reactor interface — public surface.
"""

# Tracks
from reactor_runtime.interface.tracks.descriptors import Audio, Video
from reactor_runtime.interface.tracks.input import (
    INPUT_REGISTRY,
    Input,
    all_input_tracks,
)
from reactor_runtime.interface.tracks.output import (
    OUTPUT_REGISTRY,
    Output,
    all_output_tracks,
)

# Events & Messages
from reactor_runtime.interface.events.event import EVENT_REGISTRY, Event
from reactor_runtime.interface.events.connected import Connected, Disconnected
from reactor_runtime.interface.events.upload import FileUploaded
from reactor_runtime.interface.upload import UploadedFile
from reactor_runtime.interface.events.messages import (
    MESSAGE_REGISTRY,
    MessageField,
    ModelMessage,
)

# Model layer (canonical) — includes decorators and field metadata
from reactor_runtime.interface.model.reactor_model import ReactorModel
from reactor_runtime.interface.model.decorators import (
    connected,
    disconnected,
    event,
    file_uploaded,
)
from reactor_runtime.interface.defaults import FieldInfo, InputField

# Pipeline — generator + typed state layer
from reactor_runtime.interface.pipeline.reactor_pipeline import ReactorPipeline
from reactor_runtime.interface.pipeline.input_state import InputState
from reactor_runtime.interface.pipeline.idle import Idle

# Driver — programmatic step-by-step control
from reactor_runtime.interface.driver import PipelineExecutor, StepResult

# Internal (exposed for runtime integration, not stable API)
from reactor_runtime.interface.internal.reactor_core import ReactorCore
from reactor_runtime.interface.internal.output_buffer import OutputBuffer
from reactor_runtime.interface.internal.input_buffer import (
    BufferClosed,
    InputBuffer,
    ReadMode,
)

# Inbound frame with timing metadata (re-exported from transports so model
# authors can ``from reactor_runtime.interface import InputFrame``).
from reactor_runtime.transports.media import InputFrame

__all__ = [
    # Tracks
    "Output",
    "Input",
    "Video",
    "Audio",
    "OUTPUT_REGISTRY",
    "INPUT_REGISTRY",
    "all_output_tracks",
    "all_input_tracks",
    # Events & Messages
    "Event",
    "Connected",
    "Disconnected",
    "FileUploaded",
    "UploadedFile",
    "EVENT_REGISTRY",
    "MessageField",
    "ModelMessage",
    "MESSAGE_REGISTRY",
    # Model — decorators & fields
    "ReactorModel",
    "event",
    "connected",
    "disconnected",
    "file_uploaded",
    "FieldInfo",
    "InputField",
    # Pipeline
    "ReactorPipeline",
    "InputState",
    "Idle",
    # Driver
    "PipelineExecutor",
    "StepResult",
    # Internal
    "ReactorCore",
    "OutputBuffer",
    "InputBuffer",
    "BufferClosed",
    "ReadMode",
    # Inbound frame
    "InputFrame",
]
