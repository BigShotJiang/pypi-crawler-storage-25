# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
Internal base — :class:`ReactorCore`.

Provides the core primitives (:meth:`load`, :meth:`emit`,
:meth:`send`) that model classes use.  Not intended to be subclassed
directly — use :class:`ReactorModel` or :class:`ReactorPipeline`.
"""

from __future__ import annotations

import asyncio
from typing import (
    Any,
    AsyncGenerator,
    Callable,
    Dict,
    Optional,
    Tuple,
    Type,
    get_type_hints,
)

from reactor_runtime.interface.events.event import Event
from reactor_runtime.interface.events.messages import ModelMessage
from reactor_runtime.interface.internal.output_buffer import OutputBuffer
from reactor_runtime.interface.internal.input_buffer import InputBuffer
from reactor_runtime.interface.tracks.descriptors import TRACK_MARKERS
from reactor_runtime.interface.tracks.input import INPUT_REGISTRY, Input
from reactor_runtime.interface.tracks.output import Output
from reactor_runtime.transports.media import InputFrame
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class ReactorCore:
    """Internal base providing ``load()``, ``emit()``, and ``send()``.

    Not part of the public API — use :class:`ReactorModel` or
    :class:`ReactorPipeline` instead.
    """

    def __init__(self, output_queue_depth: int = 10) -> None:
        super().__init__()
        self._loop = asyncio.new_event_loop()
        self._task: Optional[asyncio.Task[None]] = None
        self._queue: Optional[asyncio.Queue[Event]] = None

        self.output_buffer = OutputBuffer(queue_depth=output_queue_depth)

        self._input_buffers: Dict[str, InputBuffer] = {}
        self._wire_input_buffers()

        self.__send_fn: Optional[Callable[[dict], None]] = None

    # ------------------------------------------------------------------
    # Input buffer wiring
    # ------------------------------------------------------------------

    @classmethod
    def _resolve_input_binding(cls) -> Optional[Tuple[str, Type[Input]]]:
        """Find a class-level annotation typed as an :class:`Input` subclass.

        Scans all annotations on the class and returns the first
        ``(attr_name, InputSubclass)`` pair found.  The attribute name
        is not prescribed — users may call it ``input``, ``media``,
        ``webcam_feed``, or anything else.
        """
        hints = get_type_hints(cls, include_extras=False)
        for attr_name, hint in hints.items():
            if isinstance(hint, type) and issubclass(hint, Input) and hint is not Input:
                return (attr_name, hint)
        return None

    def _wire_input_buffers(self) -> None:
        """Create input buffers and bind them to the annotated attribute.

        Scans for any attribute annotated with an :class:`Input`
        subclass and sets ``self.<attr>`` to an instance of that class
        with live buffers as fields.  Falls back to wiring from the
        global registry when no annotation is found (buffers are still
        accessible internally via ``_input_buffers``).
        """
        binding = self._resolve_input_binding()
        if binding is not None:
            attr_name, input_cls = binding
            sources = [input_cls]
        else:
            attr_name = None
            sources = list(INPUT_REGISTRY.values())

        for cls in sources:
            for name, marker in cls._tracks.items():
                if marker in TRACK_MARKERS:
                    if name in self._input_buffers:
                        raise ValueError(
                            f"Duplicate input track name '{name}' — "
                            f"track names must be globally unique across "
                            f"all Input subclasses"
                        )
                    buf = marker()
                    self._input_buffers[name] = buf

        if attr_name is not None and self._input_buffers:
            setattr(self, attr_name, input_cls(**self._input_buffers))

    # ------------------------------------------------------------------
    # Hooks — subclasses override these
    # ------------------------------------------------------------------

    def load(self, config: dict[str, Any]) -> None:
        """Load model weights and initialise resources.

        Called once before any client connects.  Override to load
        checkpoints, build pipelines, or allocate GPU resources.

        Args:
            config: Model configuration dictionary parsed from
                the YAML config file specified in ``reactor.yaml``.
        """

    async def run(self) -> None:
        """Main generation loop — override in :class:`ReactorModel`."""
        raise NotImplementedError(f"{type(self).__name__} must implement run()")

    # ------------------------------------------------------------------
    # Primitives — available to all layers
    # ------------------------------------------------------------------

    async def events(self) -> AsyncGenerator[Event, None]:
        """Async generator yielding events from the queue."""
        if self._queue is None:
            raise RuntimeError("events() called before the event loop started")
        while True:
            yield await self._queue.get()

    async def emit(
        self,
        output: Output,
        *,
        compute_time: Optional[float] = None,
        drop: bool = False,
    ) -> None:
        """Send an output frame (or bundle) to the client.

        Call this from your generation loop each time you have new
        media to deliver.  By default, awaits if the output queue is
        full, yielding to the event loop so handlers can still
        dispatch.

        Args:
            output: An :class:`Output` instance holding the media data
                for each declared track.
            compute_time: Optional wall-clock seconds spent producing
                this output.  When provided, the emission rate adapts
                to match the model's actual throughput.
            drop: If ``True``, silently discard the frame when the
                queue is full instead of blocking.
        """
        n_frames = await asyncio.to_thread(self.output_buffer.submit, output, drop=drop)
        if n_frames == 0:
            return
        if compute_time is not None and compute_time > 0:
            self.output_buffer.set_fps(n_frames / compute_time)
        await asyncio.sleep(0)

    async def send(self, message: ModelMessage) -> None:
        """Send a typed data message to the client.

        Use this to deliver non-media information (progress updates,
        status changes, acknowledgements, etc.) to the connected
        client.

        Args:
            message: A :class:`ModelMessage` instance to send.
        """
        fn = self.__send_fn
        if fn is not None:
            fn(message.to_wire_format())

    # ------------------------------------------------------------------
    # Runtime integration (called from the runtime / transport thread)
    # ------------------------------------------------------------------

    def _start(self) -> None:
        """Block the current thread running the model's event loop."""
        try:
            self._loop.run_until_complete(self._lifecycle())
        finally:
            self._loop.close()

    def _push_event(self, event: Event) -> None:
        """Thread-safe: enqueue an event on the model's loop."""
        if self._queue is None or self._loop.is_closed():
            return
        try:
            self._loop.call_soon_threadsafe(self._queue.put_nowait, event)
        except RuntimeError:
            pass

    def _push_media(self, track_name: str, frame: InputFrame) -> None:
        """Thread-safe: push an :class:`InputFrame` into the matching InputBuffer.

        Strict typing: callers must build an :class:`InputFrame` (transports
        do so at the ingress boundary).  Permissive auto-wrapping of a bare
        ``np.ndarray`` happens at the outer public surface
        (``PipelineExecutor.push_media``) — not here — so this stays a
        simple threadsafe dispatch.
        """
        if self._loop.is_closed():
            return
        buf = self._input_buffers.get(track_name)
        if buf is not None:
            buf._push(frame)
        else:
            logger.debug(
                "Received media for unknown input track",
                track=track_name,
                known=list(self._input_buffers.keys()),
            )

    def _stop(self) -> None:
        """Thread-safe: cancel the model task."""
        if self._task is not None and not self._loop.is_closed():
            try:
                self._loop.call_soon_threadsafe(self._task.cancel)
            except RuntimeError:
                pass

    @property
    def _send_fn(self) -> Optional[Callable[[dict], None]]:
        return self.__send_fn

    @_send_fn.setter
    def _send_fn(self, fn: Callable[[dict], None]) -> None:
        self.__send_fn = fn

    # ------------------------------------------------------------------
    # Internal lifecycle
    # ------------------------------------------------------------------

    def _init_async(self) -> None:
        """Create asyncio primitives on the running loop."""
        self._queue = asyncio.Queue()

    async def _lifecycle(self) -> None:
        self._init_async()
        self._task = asyncio.current_task()
        try:
            await self.run()
        except asyncio.CancelledError:
            logger.info("Model cancelled")
        except Exception:
            logger.exception("run() crashed")
