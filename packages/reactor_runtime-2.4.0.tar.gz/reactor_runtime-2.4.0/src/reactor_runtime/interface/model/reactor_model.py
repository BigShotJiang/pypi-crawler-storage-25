# Copyright (c) 2026 Reactor Technologies, Inc. All rights reserved.
"""
:class:`ReactorModel` — the canonical base class for Reactor models.

Provides ``@event``, ``@connected``, and ``@disconnected`` handler
dispatch, connection-lifecycle signals, and an overridable ``run()``
generation loop.  For the higher-level generator pattern, see
:class:`ReactorPipeline`.
"""

from __future__ import annotations

import asyncio
import dataclasses
import os
from typing import Any, Callable, List, Optional, Tuple, Type

from reactor_runtime.interface.events.connected import Connected, Disconnected
from reactor_runtime.interface.events.event import Event
from reactor_runtime.interface.events.upload import FileUploaded
from reactor_runtime.interface.model.handlers import (
    Handlers,
    build_dispatch_table,
    collect_handlers,
)
from reactor_runtime.interface.internal.reactor_core import ReactorCore
from reactor_runtime.utils.log import get_logger

logger = get_logger(__name__)


class ReactorModel(ReactorCore):
    """Base class for building real-time models on the Reactor runtime.

    Override :meth:`run` with an async generation loop that produces
    output and awaits connection signals.  Use ``@event``,
    ``@connected``, and ``@disconnected`` decorators on methods to
    handle client interactions.

    Class attributes:

    - ``fps`` — target output frame rate (default 30).
    - ``buffer_size`` — output queue depth (default 4).  Higher values
      smooth out jitter but add latency.

    Lifecycle signals:

    - ``self.connected`` — an ``asyncio.Event`` that is set when a
      client connects and cleared when they disconnect.

    Example::

        class MyModel(ReactorModel):
            fps = 24

            def load(self, config):
                self.pipe = load_checkpoint(config["path"])

            async def run(self):
                while True:
                    await self.connected.wait()
                    while self.connected.is_set():
                        frame = self.pipe.forward()
                        await self.emit(MyOutput(video=frame))

            @event(name="set_prompt", description="Change prompt")
            async def set_prompt(self, prompt: str = "default"):
                self.current_prompt = prompt
    """

    fps: int = 30
    buffer_size: int = 4

    connected: asyncio.Event

    def __init__(self) -> None:
        super().__init__(output_queue_depth=self.buffer_size)
        self.output_buffer.set_fps(self.fps)

    # ------------------------------------------------------------------
    # Async init (must run on the event loop thread)
    # ------------------------------------------------------------------

    def _init_async(self) -> None:
        super()._init_async()
        self.connected = asyncio.Event()

    # ------------------------------------------------------------------
    # Lifecycle — dispatcher + run() as concurrent tasks
    # ------------------------------------------------------------------

    async def _lifecycle(self) -> None:
        self._init_async()
        self._task = asyncio.current_task()

        handlers = self._get_handlers()
        dispatch_table = build_dispatch_table(handlers)

        dispatcher = asyncio.create_task(self._dispatcher(handlers, dispatch_table))
        crash: Optional[BaseException] = None
        try:
            await self.run()
        except asyncio.CancelledError:
            logger.info("Model cancelled")
        except Exception as exc:
            # Don't swallow-and-return: log, clean up via finally, then
            # fail-fast (REA-1740).  ``ReactorPipeline.run()`` contains
            # its own per-session crashes, so this only fires for custom
            # ``run()`` overrides.
            crash = exc
            logger.exception(
                "run() crashed — terminating the process",
                model=type(self).__name__,
                exc_type=type(exc).__name__,
            )
        finally:
            dispatcher.cancel()
            try:
                await dispatcher
            except asyncio.CancelledError:
                pass

        if crash is not None:
            self._fail_fast(crash)

    def _fail_fast(self, exc: BaseException) -> None:
        """Terminate the process after an unrecoverable ``run()`` error.

        Uses :func:`os._exit` (not ``sys.exit``) so the whole process
        goes away regardless of thread.  Override in subclasses or
        tests.
        """
        logger.critical(
            "Terminating process after unhandled run() exception",
            exc_type=type(exc).__name__,
        )
        os._exit(1)

    # ------------------------------------------------------------------
    # run() — override with your generation loop
    # ------------------------------------------------------------------

    async def run(self) -> None:
        """Main generation loop — override this.

        Write an async loop that awaits ``self.connected.wait()``,
        produces frames, and calls :meth:`emit`.  ``@event`` handlers
        execute concurrently while this method runs.

        The default implementation blocks forever, which is suitable
        for purely event-driven models whose logic lives entirely in
        ``@event`` handlers.
        """
        await asyncio.Future()

    # ------------------------------------------------------------------
    # Dispatcher
    # ------------------------------------------------------------------

    async def _dispatcher(
        self,
        handlers: Handlers,
        dispatch_table: List[Tuple[Type[Event], Callable, bool]],
    ) -> None:
        """Consume events and route to decorated handlers."""
        if self._queue is None:
            raise RuntimeError("Dispatcher started before the event loop")
        while True:
            event = await self._queue.get()

            if isinstance(event, Connected):
                self.connected.set()
                if handlers.connected is not None:
                    await self._invoke(
                        handlers.connected,
                        handlers.connected_is_async,
                    )

            elif isinstance(event, Disconnected):
                self.connected.clear()
                if handlers.disconnected is not None:
                    await self._invoke(
                        handlers.disconnected,
                        handlers.disconnected_is_async,
                    )

            elif isinstance(event, FileUploaded):
                if handlers.file_uploaded is not None:
                    await self._invoke(
                        handlers.file_uploaded,
                        handlers.file_uploaded_is_async,
                        uploaded_file=event.file,
                    )

            else:
                await self._dispatch_event(event, dispatch_table)

    def _dedupe(self, event: Event) -> Event:
        """Drain duplicate events from the queue for ``dedupe=True`` types.

        Returns the latest event of the same type if duplicates were
        queued, otherwise returns *event* unchanged.  Non-matching
        events pulled during the drain are re-queued in order.

        The ``_dedupe`` flag is stamped on the Event subclass by the
        ``@event(dedupe=True)`` decorator.

        This method is synchronous (no ``await``), so it runs as a
        single uninterruptible block on the event loop.  Events pushed
        via ``call_soon_threadsafe`` from the transport thread cannot
        land in the queue until this method returns.
        """
        # Check whether this event class was marked dedupe=True.
        # If not, return immediately — nothing to drain.
        if not getattr(event, "_dedupe", False):
            return event

        # Pull everything currently in the queue.  Keep the latest
        # instance of the same event type; stash everything else so
        # we can put it back in order afterwards.
        event_type = type(event)
        latest = event
        requeue: list = []
        while not self._queue.empty():
            try:
                pending = self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
            if type(pending) is event_type:
                latest = pending
            else:
                requeue.append(pending)

        for item in requeue:
            self._queue.put_nowait(item)
        return latest

    async def _dispatch_event(
        self,
        event: Event,
        dispatch_table: List[Tuple[Type[Event], Callable, bool]],
    ) -> None:
        """Match an event to an @event handler and call it."""
        for event_cls, handler, is_async in dispatch_table:
            if isinstance(event, event_cls):
                await self._invoke(handler, is_async, _event=event)
                return

    async def _invoke(
        self,
        handler: Callable,
        is_async: bool,
        *,
        _event: Event | None = None,
        **kw: Any,
    ) -> None:
        """Call a handler, logging and swallowing exceptions.

        When *_event* is provided, :meth:`_dedupe` is called first so
        that duplicate events queued while the caller was blocked (e.g.
        waiting for a lock in a subclass) are collapsed.  The handler
        kwargs are then extracted from the (possibly replaced) event.
        """
        if _event is not None:
            _event = self._dedupe(_event)
            kw = {f.name: getattr(_event, f.name) for f in dataclasses.fields(_event)}
        try:
            if is_async:
                await handler(self, **kw)
            else:
                handler(self, **kw)
        except Exception:
            logger.exception(
                "Unhandled exception in event handler",
                handler=getattr(handler, "__qualname__", repr(handler)),
            )

    # ------------------------------------------------------------------
    # Handler resolution (cached per concrete class)
    # ------------------------------------------------------------------

    @classmethod
    def _get_handlers(cls) -> Handlers:
        if "_handlers_cache" not in cls.__dict__:
            cls._handlers_cache = collect_handlers(  # type: ignore[attr-defined]
                cls, skip_classes=(ReactorCore, ReactorModel)
            )
        return cls._handlers_cache  # type: ignore[attr-defined]
