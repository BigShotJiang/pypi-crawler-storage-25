from taqwim.date import Date
from taqwim.ummalqura import UmmalQura
from taqwim.util import Util, shared as _util

__all__ = ["gregorian_to_hijri", "hijri_to_gregorian", "Date", "Util", "UmmalQura"]


def gregorian_to_hijri(date: Date) -> Date:
    jdn = _util.gregorian_to_julian(date)
    rjd = _util.jdn_to_rjd(jdn)
    index = _util.bisect(UmmalQura.MONTH_STARTS, rjd) - 1
    months = index + UmmalQura.HIJRI_OFFSET
    years = months // 12
    year = years + 1
    month = months - years * 12 + 1
    day = rjd - UmmalQura.MONTH_STARTS[index] + 1
    return Date(day=day, month=month, year=year)


def hijri_to_gregorian(date: Date) -> Date:
    jdn = _util.hijri_to_julian(date)
    don = _util.jdn_to_ordinal(jdn)
    return _util.gregorian_from_ordinal(don)
