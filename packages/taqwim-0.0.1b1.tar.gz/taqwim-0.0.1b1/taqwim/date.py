from __future__ import annotations

from datetime import datetime, timedelta, timezone


class Date:
    __slots__ = ("day", "month", "year")

    def __init__(self, *, day: int, month: int, year: int):
        self.day = day
        self.month = month
        self.year = year

    @classmethod
    def zero(cls) -> Date:
        return cls(day=0, month=0, year=0)

    @classmethod
    def now(cls) -> Date:
        return cls.from_datetime(datetime.now())

    @classmethod
    def from_datetime(cls, dt: datetime) -> Date:
        return cls(day=dt.day, month=dt.month, year=dt.year)

    @property
    def day_index(self) -> int:
        return self.day - 1

    @property
    def month_index(self) -> int:
        return self.month - 1

    def __str__(self) -> str:
        return f"{self.day}-{self.month}-{self.year}"

    def __repr__(self) -> str:
        return f"Date(day={self.day}, month={self.month}, year={self.year})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Date):
            return NotImplemented
        return self.day == other.day and self.month == other.month and self.year == other.year

    def __hash__(self) -> int:
        return hash((self.day, self.month, self.year))

    def add_to_arabic_date(self, *, days: int) -> Date:
        from taqwim import gregorian_to_hijri
        dt = self.to_english_datetime()
        dt = dt + timedelta(days=days)
        return gregorian_to_hijri(Date.from_datetime(dt))

    def subtract_from_arabic_date(self, *, days: int) -> Date:
        from taqwim import gregorian_to_hijri
        dt = self.to_english_datetime()
        dt = dt - timedelta(days=days)
        return gregorian_to_hijri(Date.from_datetime(dt))

    def any_previous_arabic_month_date(self) -> Date:
        return self.subtract_from_arabic_date(days=self.day + 2)

    def any_next_arabic_month_date(self) -> Date:
        if 1 <= self.day <= 10:
            return self.add_to_arabic_date(days=30)
        elif 11 <= self.day <= 20:
            return self.add_to_arabic_date(days=20)
        else:
            return self.add_to_arabic_date(days=10)

    def copy_with(self, *, day: int | None = None, month: int | None = None, year: int | None = None) -> Date:
        return Date(
            day=day if day is not None else self.day,
            month=month if month is not None else self.month,
            year=year if year is not None else self.year,
        )

    def to_english_datetime(self) -> datetime:
        from taqwim import hijri_to_gregorian
        date = hijri_to_gregorian(self)
        return datetime(date.year, date.month, date.day, tzinfo=timezone.utc)

    def to_datetime(self) -> datetime:
        return datetime(self.year, self.month, self.day, tzinfo=timezone.utc)
