from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from taqwim.date import Date

from taqwim.ummalqura import UmmalQura


class Util:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._init()
        return cls._instance

    def _init(self):
        self._DAYS_IN_MONTH = [-1, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        dbm = 0
        self.DAYS_BEFORE_MONTH = [-1]
        for i in range(1, len(self._DAYS_IN_MONTH)):
            self.DAYS_BEFORE_MONTH.append(dbm)
            dbm += self._DAYS_IN_MONTH[i]

    @staticmethod
    def divmod_(a: int, b: int) -> list[int]:
        return [a // b, a % b]

    @staticmethod
    def bisect(a: list[int], x: int, hi: int | None = None, lo: int = 0) -> int:
        if lo < 0:
            raise ValueError("lo must be non-negative")
        if hi is None:
            hi = len(a)
        while lo < hi:
            mid = (lo + hi) // 2
            if x < a[mid]:
                hi = mid
            else:
                lo = mid + 1
        return lo

    @staticmethod
    def jdn_to_ordinal(jdn: int) -> int:
        return jdn - 1721425

    @staticmethod
    def ordinal_to_jdn(o: int) -> int:
        return o + 1721425

    @staticmethod
    def jdn_to_rjd(jdn: int) -> int:
        return jdn - 2400000

    @staticmethod
    def rjd_to_jdn(rjd: int) -> int:
        return rjd + 2400000

    # Hijri

    @staticmethod
    def month_index(year: int, month: int) -> int:
        prior_month = (year - 1) * 12 + month - 1
        index = prior_month - UmmalQura.HIJRI_OFFSET
        return index

    def hijri_days_in_month(self, year: int, month: int) -> int:
        index = self.month_index(year, month)
        return UmmalQura.MONTH_STARTS[index + 1] - UmmalQura.MONTH_STARTS[index]

    def hijri_to_julian(self, date: Date) -> int:
        index = self.month_index(date.year, date.month)
        rjd = UmmalQura.MONTH_STARTS[index] + date.day - 1
        jdn = self.rjd_to_jdn(rjd)
        return jdn

    def gregorian_to_julian(self, date: Date) -> int:
        y = date.year - 1
        m = date.month
        days_before_year = y * 365 + y // 4 - y // 100 + y // 400
        days_before_month = self.DAYS_BEFORE_MONTH[m] + (1 if m > 2 and self.is_leap(date.year) else 0)
        don = days_before_year + days_before_month + date.day
        jdn = self.ordinal_to_jdn(don)
        return jdn

    def gregorian_from_ordinal(self, n: int) -> Date:
        from taqwim.date import Date
        year, month, day = self.ord2ymd(n)
        return Date(day=day, month=month, year=year)

    def days_before_year(self, year: int) -> int:
        y = year - 1
        return y * 365 + y // 4 - y // 100 + y // 400

    @property
    def DI400Y(self) -> int:
        return self.days_before_year(401)

    @property
    def DI100Y(self) -> int:
        return self.days_before_year(101)

    @property
    def DI4Y(self) -> int:
        return self.days_before_year(5)

    @staticmethod
    def is_leap(year: int) -> bool:
        return year % 4 == 0 and (year % 100 != 0 or year % 400 == 0)

    def days_in_month(self, year: int, month: int) -> int:
        if month == 2 and self.is_leap(year):
            return 29
        return self._DAYS_IN_MONTH[month]

    def ord2ymd(self, n: int) -> list[int]:
        n -= 1
        n400, n = self.divmod_(n, self.DI400Y)
        year = n400 * 400 + 1

        n100, n = self.divmod_(n, self.DI100Y)

        n4, n = self.divmod_(n, self.DI4Y)

        n1, n = self.divmod_(n, 365)

        year += n100 * 100 + n4 * 4 + n1
        if n1 == 4 or n100 == 4:
            return [year - 1, 12, 31]

        leap_year = n1 == 3 and (n4 != 24 or n100 == 3)
        month = (n + 50) >> 5

        preceding = self.DAYS_BEFORE_MONTH[month] + (1 if month > 2 and leap_year else 0)
        if preceding > n:
            month -= 1
            preceding -= self._DAYS_IN_MONTH[month] + (1 if month == 2 and leap_year else 0)
        n -= preceding

        return [year, month, n + 1]


shared = Util()
