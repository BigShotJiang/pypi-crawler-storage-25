# taqwim.py

Gregorian to Hijri and Hijri to Gregorian date conversion using the Umm al-Qura calendar.

Python port of [arabic_date_time](https://github.com/Greentech-Apps-Limited/arabic_date_time) Flutter package.

## Installation

```bash
pip install taqwim
```

## Usage

```python
from taqwim import Date, gregorian_to_hijri, hijri_to_gregorian

# Gregorian to Hijri
hijri = gregorian_to_hijri(Date(day=1, month=1, year=2024))
print(hijri)  # 19-6-1445

# Hijri to Gregorian
gregorian = hijri_to_gregorian(Date(day=1, month=1, year=1445))
print(gregorian)  # 19-7-2023

# Date arithmetic on Hijri dates
next_month = hijri.any_next_arabic_month_date()
prev_month = hijri.any_previous_arabic_month_date()
added = hijri.add_to_arabic_date(days=10)
subtracted = hijri.subtract_from_arabic_date(days=5)

# Convert Hijri to Python datetime
dt = hijri.to_english_datetime()

# Create Date from Python datetime
from datetime import datetime
date = Date.from_datetime(datetime.now())
```

## Valid Date Range

- **Gregorian:** August 1, 1924 to November 16, 2077
- **Hijri:** 1343/1/1 to 1500/12/30

## License

MIT
