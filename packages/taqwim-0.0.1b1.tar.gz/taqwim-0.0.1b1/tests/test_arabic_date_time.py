from taqwim import Date, gregorian_to_hijri, hijri_to_gregorian


def test_gregorian_to_hijri_known_dates():
    # 1 January 2000 -> 24 Ramadan 1420
    result = gregorian_to_hijri(Date(day=1, month=1, year=2000))
    assert result == Date(day=24, month=9, year=1420)

    # 11 September 2001 -> 23 Jumada al-Thani 1422
    result = gregorian_to_hijri(Date(day=11, month=9, year=2001))
    assert result == Date(day=23, month=6, year=1422)

    # 1 January 2024 -> 19 Jumada al-Thani 1445
    result = gregorian_to_hijri(Date(day=1, month=1, year=2024))
    assert result == Date(day=19, month=6, year=1445)


def test_hijri_to_gregorian_known_dates():
    # 1 Muharram 1445 -> 19 July 2023
    result = hijri_to_gregorian(Date(day=1, month=1, year=1445))
    assert result == Date(day=19, month=7, year=2023)

    # 1 Ramadan 1445 -> 11 March 2024
    result = hijri_to_gregorian(Date(day=1, month=9, year=1445))
    assert result == Date(day=11, month=3, year=2024)


def test_round_trip_gregorian():
    original = Date(day=15, month=6, year=2024)
    hijri = gregorian_to_hijri(original)
    back = hijri_to_gregorian(hijri)
    assert back == original


def test_round_trip_hijri():
    original = Date(day=10, month=1, year=1445)
    gregorian = hijri_to_gregorian(original)
    back = gregorian_to_hijri(gregorian)
    assert back == original


def test_date_str():
    d = Date(day=5, month=3, year=1445)
    assert str(d) == "5-3-1445"


def test_date_equality():
    a = Date(day=1, month=1, year=1445)
    b = Date(day=1, month=1, year=1445)
    c = Date(day=2, month=1, year=1445)
    assert a == b
    assert a != c


def test_date_hash():
    a = Date(day=1, month=1, year=1445)
    b = Date(day=1, month=1, year=1445)
    assert hash(a) == hash(b)
    s = {a, b}
    assert len(s) == 1


def test_date_copy_with():
    d = Date(day=5, month=3, year=1445)
    d2 = d.copy_with(day=10)
    assert d2 == Date(day=10, month=3, year=1445)
    d3 = d.copy_with(month=7, year=1446)
    assert d3 == Date(day=5, month=7, year=1446)


def test_date_indices():
    d = Date(day=5, month=3, year=1445)
    assert d.day_index == 4
    assert d.month_index == 2


def test_add_to_arabic_date():
    hijri = Date(day=1, month=1, year=1445)
    result = hijri.add_to_arabic_date(days=30)
    assert result.month == 2 or (result.month == 1 and result.day > 1)


def test_subtract_from_arabic_date():
    hijri = Date(day=15, month=2, year=1445)
    result = hijri.subtract_from_arabic_date(days=15)
    assert result.year == 1445 and result.month == 1


def test_any_previous_arabic_month_date():
    hijri = Date(day=15, month=3, year=1445)
    result = hijri.any_previous_arabic_month_date()
    assert result.month == 2


def test_any_next_arabic_month_date():
    hijri = Date(day=5, month=3, year=1445)
    result = hijri.any_next_arabic_month_date()
    assert result.month == 4


def test_to_english_datetime():
    hijri = Date(day=1, month=1, year=1445)
    dt = hijri.to_english_datetime()
    assert dt.year == 2023
    assert dt.month == 7
    assert dt.day == 19


def test_from_datetime():
    from datetime import datetime
    dt = datetime(2024, 1, 1)
    d = Date.from_datetime(dt)
    assert d == Date(day=1, month=1, year=2024)


def test_date_zero():
    z = Date.zero()
    assert z.day == 0 and z.month == 0 and z.year == 0


def test_boundary_dates():
    # Test near the start of the valid range
    result = gregorian_to_hijri(Date(day=1, month=8, year=1924))
    assert result == Date(day=1, month=1, year=1343)

    # Round trip at boundary
    back = hijri_to_gregorian(result)
    assert back == Date(day=1, month=8, year=1924)
