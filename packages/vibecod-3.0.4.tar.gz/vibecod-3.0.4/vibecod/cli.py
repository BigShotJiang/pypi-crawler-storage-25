import sys 
import os 
import subprocess 
 
CORE_EXE = os.path.join("cpp", "vibecod.exe") 
 
def new_file(name): 
    if not name.endswith(".vibe"): 
        name += ".vibe" 
    with open(name, "w") as f: 
        f.write('spit "hello vibecod"\n') 
    print(f"[vibe] created {name}") 
 
def run_file(file): 
    if not os.path.exists(file): 
        print("[vibe] file not found") 
        return 
    if os.path.exists(CORE_EXE): 
        subprocess.run([CORE_EXE, file]) 
    else: 
        print("[vibe] C++ core not found, running in python mode") 
        with open(file, "r") as f: 
            for line in f: 
                print(f"exec: {line.strip()}") 
 
def edit_file(file): 
    if not os.path.exists(file): 
        new_file(file) 
    os.system(f"notepad {file}") 
 
def main(): 
    args = sys.argv[1:] 
    if len(args) == 0 or args[0] == "--help": 
        print("vibe commands:") 
        print("  new ^<file^>") 
        print("  run ^<file^>") 
        print("  edit ^<file^>") 
        print("  --version") 
        return 
    if args[0] == "--version": 
        print("VIBEcod 3.0.0") 
        return 
    cmd = args[0] 
    if len(args) < 2: 
        print(f"missing argument for {cmd}") 
        return 
    if cmd == "new": 
        new_file(args[1]) 
    elif cmd == "run": 
        run_file(args[1]) 
    elif cmd == "edit": 
        edit_file(args[1]) 
    else: 
        print(f"unknown command: {cmd}") 
