from setuptools import setup, find_packages

setup(
    name="vibecod",
    version="3.0.4",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "vibecod": ["nano/vibecod.nanorc"],
    },
    entry_points={
        "console_scripts": [
            "vibecod = vibecod.__main__:main",
            "vibe = vibecod.__main__:main"
        ]
    },
)