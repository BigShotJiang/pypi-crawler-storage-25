#!/usr/bin/env python3
"""ATH-382 — Cython build helper.

Compiles Tier-1 SDK modules from `.pyx` source to `.so` binary.

## Why this script exists

The SDK uses `hatchling` as its build backend (pure-Python). Hatchling
doesn't natively support building C extensions. Rather than swap
backends mid-V1 or adopt an unproven third-party plugin, this script
is the simplest thing that works: invoke Cython + distutils directly,
produce `.so` files alongside the `.pyx` sources in `src/kairos/`,
and let hatchling pick them up via its include rules.

Workflow for the customer wheel build:

    python3 build_cython.py               # produces .so files
    python3 -m build                       # hatchling picks them up

Workflow for developers:

    python3 build_cython.py                # compile once; or
    # ... or skip this step; lint.py has a pyximport fallback that
    # compiles on-demand for pytest / interactive use.

## Current scope (2026-04-20)

Compiles ONE module as proof-of-concept:
  * `src/kairos/_lint_impl.pyx` → `src/kairos/_lint_impl.cpython-*.so`

Follow-ups (tracked in ATH-382 Linear):
  * Add `scoring.pyx`, `lean.pyx` once this pattern proves out
  * Integrate into hatchling via `hatch-cython` plugin or a custom
    build hook so CI doesn't need a separate script invocation
  * Cross-platform builds (macOS, Windows) if customers ever need them

## Idempotent

Re-running does not break anything — distutils rebuilds the `.so`
from the current `.pyx`. Safe to run in CI on every wheel build.
"""
from __future__ import annotations

import shutil
import sys
from pathlib import Path


# ─── Config ──────────────────────────────────────────────────────────────

REPO_ROOT = Path(__file__).resolve().parent
SRC_DIR = REPO_ROOT / "src" / "kairos"

# (module_name_without_extension, pyx_path)
PYX_MODULES: list[tuple[str, Path]] = [
    ("_lint_impl",    SRC_DIR / "_lint_impl.pyx"),
    ("_scoring_impl", SRC_DIR / "_scoring_impl.pyx"),
    # ATH-382 follow-up: add _lean_impl when it lands.
]


def main() -> int:
    try:
        from Cython.Build import cythonize
        from setuptools import Extension, setup
    except ImportError as exc:
        print(f"ERROR: Cython + setuptools required. `pip install cython setuptools`\n"
              f"Import failure: {exc}")
        return 1

    # Filter to modules whose .pyx actually exists. That way this script
    # can be committed ahead of the .pyx files landing.
    to_build = [(name, pyx) for name, pyx in PYX_MODULES if pyx.is_file()]
    if not to_build:
        print(f"No .pyx modules found to build under {SRC_DIR.relative_to(REPO_ROOT)}/.")
        return 0

    extensions = [
        Extension(
            name=f"kairos.{name}",
            sources=[str(pyx.relative_to(REPO_ROOT))],
        )
        for name, pyx in to_build
    ]

    # Run cythonize + setuptools-style build_ext inplace so the .so
    # lands next to the .pyx. `--inplace` is what makes the output
    # discoverable by Python's normal import path resolution without
    # needing to re-pack the wheel.
    saved_argv = list(sys.argv)
    sys.argv = [sys.argv[0], "build_ext", "--inplace"]
    try:
        setup(
            name="kairos-cython-build-shim",
            ext_modules=cythonize(
                extensions,
                language_level=3,
                compiler_directives={
                    "embedsignature":    True,   # keep docstrings + sigs
                    "boundscheck":       True,   # we optimize for safety not speed
                    "initializedcheck":  True,
                },
            ),
        )
    except (Exception, SystemExit) as exc:  # noqa: BLE001
        print(f"WARNING: Cython build failed ({exc}). "
              f"Python fallbacks will be used at runtime.")
        return 0
    finally:
        sys.argv = saved_argv

    # Clean up setuptools-leftover artifacts that don't belong in the
    # repo. distutils leaves `build/` + `*.c` files in place after
    # --inplace; the `.c` is an implementation detail.
    for pattern in ("build", "*.egg-info"):
        for path in REPO_ROOT.glob(pattern):
            if path.is_dir():
                shutil.rmtree(path)
    for name, pyx in to_build:
        c_file = pyx.with_suffix(".c")
        if c_file.is_file():
            c_file.unlink()

    print(f"✓ Built {len(to_build)} Cython module(s):")
    for name, pyx in to_build:
        # Find the produced .so — naming includes Python version +
        # platform tag (e.g. cpython-310-x86_64-linux-gnu).
        matches = list(SRC_DIR.glob(f"{name}.cpython-*.so"))
        for m in matches:
            print(f"    {m.relative_to(REPO_ROOT)}")
    return 0


def _write_build_meta(dev: bool) -> None:
    """Write _build_meta.py with or without a dev token."""
    import secrets
    meta_path = SRC_DIR / "_build_meta.py"
    if dev:
        token = secrets.token_hex(32)
        meta_path.write_text(
            '"""Build-time metadata — dev build with bypass token."""\n'
            f'DEV_TOKEN: str | None = "{token}"\n'
        )
        print(f"✓ Wrote dev _build_meta.py (token baked)")
    else:
        meta_path.write_text(
            '"""Build-time metadata for license bypass control.\n\n'
            'Customer wheels ship this file with DEV_TOKEN = None.\n'
            'Internal dev/CI builds overwrite DEV_TOKEN via build_cython.py --dev.\n'
            '"""\n'
            'DEV_TOKEN: str | None = None\n'
        )
        print("✓ Wrote customer _build_meta.py (no token)")


def _ip_protect() -> int:
    """ATH-995: compile high-IP .py modules to .so via Cython.

    Reads the manifest from _ip_protect.py, copies each .py to .pyx,
    compiles, then removes the .pyx copy. The .py source is excluded
    from the customer wheel by hatch exclude rules.
    """
    try:
        from kairos.sec.closed_loop._ip_protect import get_cython_targets, module_to_path
    except ImportError:
        # _ip_protect not yet on PYTHONPATH — use direct import
        import importlib.util
        spec = importlib.util.spec_from_file_location(
            "_ip_protect",
            SRC_DIR / "sec" / "closed_loop" / "_ip_protect.py",
        )
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        get_cython_targets = mod.get_cython_targets
        module_to_path = mod.module_to_path

    targets = get_cython_targets(include_medium=True)
    print(f"ATH-995: IP-protecting {len(targets)} modules via Cython...")

    created_pyx: list[Path] = []
    ip_extensions = []

    for module_dotted in targets:
        py_path = REPO_ROOT / module_to_path(module_dotted)
        if not py_path.is_file():
            print(f"  SKIP {module_dotted}: {py_path} not found")
            continue

        pyx_path = py_path.with_suffix(".pyx")
        shutil.copy2(py_path, pyx_path)
        created_pyx.append(pyx_path)

        ext_name = module_dotted
        ip_extensions.append(
            __import__("setuptools").Extension(
                name=ext_name,
                sources=[str(pyx_path.relative_to(REPO_ROOT))],
            )
        )

    if not ip_extensions:
        print("  No IP modules to compile.")
        return 0

    try:
        from Cython.Build import cythonize
        from setuptools import setup as _setup

        saved = list(sys.argv)
        sys.argv = [sys.argv[0], "build_ext", "--inplace"]
        try:
            _setup(
                name="kairos-ip-protect",
                ext_modules=cythonize(
                    ip_extensions,
                    language_level=3,
                    compiler_directives={"embedsignature": True},
                ),
            )
        finally:
            sys.argv = saved

        compiled = 0
        for module_dotted in targets:
            mod_parts = module_dotted.split(".")
            mod_name = mod_parts[-1]
            mod_dir = REPO_ROOT / "src" / "/".join(mod_parts[:-1])
            matches = list(mod_dir.glob(f"{mod_name}.cpython-*.so"))
            if matches:
                compiled += 1

        print(f"ATH-995: {compiled}/{len(targets)} IP modules compiled to .so")
    finally:
        for pyx in created_pyx:
            pyx.unlink(missing_ok=True)
            pyx.with_suffix(".c").unlink(missing_ok=True)

    return 0


if __name__ == "__main__":
    dev_flag = "--dev" in sys.argv
    if dev_flag:
        sys.argv.remove("--dev")
    ip_flag = "--ip-protect" in sys.argv
    if ip_flag:
        sys.argv.remove("--ip-protect")
    _write_build_meta(dev=dev_flag)
    rc = main()
    if rc == 0 and ip_flag:
        rc = _ip_protect()
    sys.exit(rc)
