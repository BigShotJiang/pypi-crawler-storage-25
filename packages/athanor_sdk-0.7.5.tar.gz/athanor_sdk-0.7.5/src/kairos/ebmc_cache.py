"""ATH-1470+1471: Caching layer for EBMC and yosys results.

Avoids re-running expensive subprocess calls when inputs haven't changed.

- Yosys synthesis cache: keyed by file content hash + module name
- EBMC result cache: keyed by file hashes + bound + mode + property

Thread-safe via threading.Lock.
"""
from __future__ import annotations

import hashlib
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class _CacheKey:
    content_hash: str
    module: str
    operation: str


class SynthesisCache:
    """Cache yosys synthesis cell counts by file content hash."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._cache: dict[_CacheKey, int | None] = {}
        self._hits = 0
        self._misses = 0

    def _hash_file(self, path: Path) -> str:
        return hashlib.sha256(path.read_bytes()).hexdigest()[:16]

    def get(self, design_path: Path, module_name: str) -> tuple[bool, int | None]:
        key = _CacheKey(self._hash_file(design_path), module_name, "synth")
        with self._lock:
            if key in self._cache:
                self._hits += 1
                return True, self._cache[key]
            self._misses += 1
            return False, None

    def put(self, design_path: Path, module_name: str, cell_count: int | None) -> None:
        key = _CacheKey(self._hash_file(design_path), module_name, "synth")
        with self._lock:
            self._cache[key] = cell_count

    @property
    def stats(self) -> dict[str, int]:
        with self._lock:
            return {"hits": self._hits, "misses": self._misses, "size": len(self._cache)}

    def clear(self) -> None:
        with self._lock:
            self._cache.clear()
            self._hits = 0
            self._misses = 0


_global_synth_cache = SynthesisCache()


def get_synth_cache() -> SynthesisCache:
    return _global_synth_cache


def reset_synth_cache() -> None:
    _global_synth_cache.clear()


def bisect_bound(
    sv_files: list[str],
    *,
    top_module: str,
    mode: str = "bmc",
    reset_expr: str | None = None,
    max_bound: int = 32,
    timeout_sec: int = 60,
    property_name: str | None = None,
) -> tuple[int, Any]:
    """ATH-1472: Binary search for minimum bound that proves.

    Starts at max_bound/2, narrows down. Returns (min_bound, EbmcResult).
    If the property is REFUTED at any bound, returns immediately.
    If INCONCLUSIVE at max_bound, returns (max_bound, result).
    """
    from kairos.sv.ebmc import run_ebmc

    lo, hi = 1, max_bound
    best_bound = max_bound
    best_result = None

    result = run_ebmc(
        sv_files, top_module=top_module, bound=max_bound, mode=mode,
        reset_expr=reset_expr, timeout_sec=timeout_sec,
        property_name=property_name,
    )

    if result.refuted:
        return max_bound, result
    if not result.proved:
        return max_bound, result

    best_result = result
    best_bound = max_bound

    while lo < hi:
        mid = (lo + hi) // 2
        r = run_ebmc(
            sv_files, top_module=top_module, bound=mid, mode=mode,
            reset_expr=reset_expr, timeout_sec=timeout_sec,
            property_name=property_name,
        )
        if r.proved:
            best_bound = mid
            best_result = r
            hi = mid
        else:
            lo = mid + 1

    return best_bound, best_result


__all__ = [
    "SynthesisCache",
    "get_synth_cache",
    "reset_synth_cache",
    "bisect_bound",
]
