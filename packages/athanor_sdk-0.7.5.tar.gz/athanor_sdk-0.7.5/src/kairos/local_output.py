"""kairos.local_output — per-run on-disk artifact directory.

ATH-681 (sub-ticket of ATH-675 base SDK epic). Customers
don't get our cloud dashboard, so the SDK saves every run's outputs
to a designated local directory the customer can inspect.

## Layout

Per docs/sdk-tier-model.md §4:

    ~/.athanor/runs/<run_id>/
    ├── manifest.json    {run_id, started_at, finished_at,
    │                     total_cost_usd, outcome, tier,
    │                     license_subject}
    ├── traces.jsonl     every event the SDK would have sent to
    │                    Supabase, JSON-line per event
    ├── generated/       SVAs, Lean code, refutations, splice outputs
    ├── ebmc/            raw stdout/stderr per call + extracted CEX
    ├── lake/            `lake build` output if Lean tasks ran
    └── report.html      rendered when `kairos report <run_id>`
                         invoked

The default root is ``~/.athanor/runs/``; override via
``KAIROS_LOCAL_OUTPUT_DIR`` env var. The override is convenient for
testing (point at a tmpdir) and for customers who keep run output
on a non-default volume.

## Tier classification

Per docs/sdk-tier-model.md §11: this module is **free**. Local-
output writing has no license gate; both free and paid runs use
this path. Paid runs ALSO write to SupabaseTraceSink in parallel
(local copy as backup).

## Customer entrypoint

    from kairos.local_output import LocalOutputDir, get_run_dir

    out = LocalOutputDir(run_id="abc-123")
    out.write_event({"event_type": "tier_verdict", ...})
    out.write_artifact("lean", "MyProof.lean", lean_source)
    out.finalize({"outcome": "proved", "total_cost_usd": 0.01})

The ``kairos.observe()`` + ``kairos.session()`` wrappers wire this
in as a default sink (separate PR; this module ships the primitive).
"""
from __future__ import annotations

import json
import logging
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

logger = logging.getLogger(__name__)


# Default root. Override via KAIROS_LOCAL_OUTPUT_DIR env var.
_DEFAULT_ROOT = Path.home() / ".athanor" / "runs"

# Subdirs created on demand inside each run's directory. Names match
# the §4 layout in the tier-model doc.
_TRACES_FILE = "traces.jsonl"
_MANIFEST_FILE = "manifest.json"
_GENERATED_DIR = "generated"
_EBMC_DIR = "ebmc"
_LAKE_DIR = "lake"


def get_local_output_root() -> Path:
    """Resolve the root directory for local run outputs.

    Honors the ``KAIROS_LOCAL_OUTPUT_DIR`` env var override; falls
    back to ``~/.athanor/runs/``. Does NOT create the directory; the
    caller is expected to create per-run subdirs lazily via
    :func:`get_run_dir` or :class:`LocalOutputDir`.

    Returns:
        Absolute Path to the configured root.
    """
    override = os.environ.get("KAIROS_LOCAL_OUTPUT_DIR", "").strip()
    if override:
        return Path(override).expanduser().resolve()
    return _DEFAULT_ROOT.expanduser().resolve()


def get_run_dir(run_id: str) -> Path:
    """Return the absolute Path to ``<root>/<run_id>/``.

    Idempotent + side-effect-free with respect to the filesystem;
    the directory is NOT created here. Use :class:`LocalOutputDir`
    to actually open + write into the per-run dir.
    """
    return get_local_output_root() / run_id


class LocalOutputDir:
    """Per-run on-disk artifact directory writer.

    Lazy directory creation: the root + per-run dir are created the
    first time a write method is called. Idempotent for concurrent
    writers within the same process — see :meth:`write_event`.

    Args:
        run_id: stable identifier for this run. Becomes the per-run
            directory name. Callers SHOULD use UUIDs (the SDK already
            generates run_ids as UUID4); arbitrary strings are
            tolerated as long as they're filesystem-safe.
        root: optional override for the root dir; usually leave as
            None to read from :func:`get_local_output_root`.

    Thread-safety: ``write_event`` is locked so concurrent
    appenders (multi-thread runs of the same session) don't
    interleave bytes mid-record. ``write_artifact`` locks per-path
    on a best-effort basis (overwrites are atomic via os.replace).
    ``finalize`` is single-write so concurrent finalize calls
    last-writer-wins on manifest.json.
    """

    def __init__(self, run_id: str, *, root: Path | None = None) -> None:
        self.run_id = run_id
        self._root = root if root is not None else get_local_output_root()
        self._run_dir = self._root / run_id
        # Lock guards traces.jsonl appends — mid-record interleaving
        # would corrupt the JSON-lines stream. Per-instance lock; if
        # multiple LocalOutputDir instances point at the same run_id
        # (rare), each gets its own lock and the on-disk file may
        # interleave records. Mitigation: don't construct multiple
        # writers for the same run_id within one process.
        self._traces_lock = threading.Lock()
        self._created = False

    @property
    def path(self) -> Path:
        """Absolute path to the per-run directory."""
        return self._run_dir

    @property
    def traces_path(self) -> Path:
        """Path to ``traces.jsonl``."""
        return self._run_dir / _TRACES_FILE

    @property
    def manifest_path(self) -> Path:
        """Path to ``manifest.json``."""
        return self._run_dir / _MANIFEST_FILE

    @property
    def generated_dir(self) -> Path:
        """Path to ``generated/`` (subdir for SDK-emitted artifacts)."""
        return self._run_dir / _GENERATED_DIR

    @property
    def ebmc_dir(self) -> Path:
        """Path to ``ebmc/`` (raw EBMC stdout/stderr per call)."""
        return self._run_dir / _EBMC_DIR

    @property
    def lake_dir(self) -> Path:
        """Path to ``lake/`` (raw `lake build` output for Lean tasks)."""
        return self._run_dir / _LAKE_DIR

    def _ensure_run_dir(self) -> None:
        if not self._created:
            self._run_dir.mkdir(parents=True, exist_ok=True)
            self._created = True

    def write_event(self, event: Mapping[str, Any]) -> None:
        """Append a trace event to ``traces.jsonl``.

        Each call writes one JSON line. Thread-safe within a single
        ``LocalOutputDir`` instance; concurrent appenders to the
        same instance won't interleave bytes mid-record.

        Args:
            event: any JSON-serializable mapping. The SDK passes
                :class:`kairos.trace.TraceEvent` instances dumped via
                ``dataclasses.asdict``.
        """
        self._ensure_run_dir()
        line = json.dumps(dict(event), default=str, ensure_ascii=False)
        with self._traces_lock:
            with self.traces_path.open("a", encoding="utf-8") as fh:
                fh.write(line)
                fh.write("\n")

    def write_artifact(
        self,
        category: str,
        name: str,
        content: str | bytes,
    ) -> Path:
        """Write an artifact under ``generated/<category>/<name>``.

        Categories partition by artifact kind: ``"lean"`` for Lean
        sources, ``"sva"`` for SystemVerilog Assertions, ``"refutation"``
        for Lean refutation witnesses, etc. The SDK uses these
        category names; customer-supplied categories are tolerated.

        Args:
            category: subdirectory name under ``generated/``.
            name: filename. The caller is responsible for the
                extension and uniqueness within the category.
            content: text or bytes to write. Strings are written
                with UTF-8 encoding; bytes are written raw.

        Returns:
            Absolute Path to the written file.
        """
        self._ensure_run_dir()
        cat_dir = self.generated_dir / category
        cat_dir.mkdir(parents=True, exist_ok=True)
        target = cat_dir / name
        if isinstance(content, str):
            target.write_text(content, encoding="utf-8")
        else:
            target.write_bytes(content)
        return target

    def write_subprocess_output(
        self,
        kind: str,
        name: str,
        *,
        stdout: str = "",
        stderr: str = "",
    ) -> Path:
        """Write subprocess stdout+stderr under ``ebmc/`` or ``lake/``.

        Convenience wrapper for the two subprocess-output subdirs
        from §4 of the tier-model doc. ``kind`` selects the subdir:
        ``"ebmc"`` or ``"lake"``. Other values raise ValueError —
        we don't auto-create arbitrary subdirs to avoid typo-driven
        layout drift.

        Args:
            kind: ``"ebmc"`` or ``"lake"``.
            name: filename (caller picks the convention; the SDK
                uses ``<run_id>_<call_seq>.txt``).
            stdout: subprocess stdout text.
            stderr: subprocess stderr text.

        Returns:
            Absolute Path to the written file. The on-disk format
            is a two-section text dump:

                === stdout ===
                <stdout text>
                === stderr ===
                <stderr text>
        """
        if kind == "ebmc":
            sub = self.ebmc_dir
        elif kind == "lake":
            sub = self.lake_dir
        else:
            raise ValueError(
                f"write_subprocess_output: unsupported kind={kind!r}; "
                f"expected 'ebmc' or 'lake'"
            )
        self._ensure_run_dir()
        sub.mkdir(parents=True, exist_ok=True)
        target = sub / name
        body = f"=== stdout ===\n{stdout}\n=== stderr ===\n{stderr}\n"
        target.write_text(body, encoding="utf-8")
        return target

    def finalize(self, manifest: Mapping[str, Any]) -> Path:
        """Write the run manifest.

        Manifest schema per §4 of the tier-model doc:

            {
              "run_id":          str,
              "started_at":      ISO-8601 string,
              "finished_at":     ISO-8601 string,
              "total_cost_usd":  float,
              "outcome":         str,
              "tier":            str,
              "license_subject": str | null
            }

        ``run_id`` is auto-injected from this writer's ``run_id``
        (overrides any caller-supplied value). ``finished_at`` is
        auto-injected to the current UTC instant when missing.
        Other fields are passed through unchanged.

        Args:
            manifest: customer-supplied keys to persist. The
                run_id + finished_at additions are merged in.

        Returns:
            Absolute Path to ``manifest.json``.
        """
        self._ensure_run_dir()
        body: dict[str, Any] = dict(manifest)
        body["run_id"] = self.run_id
        body.setdefault(
            "finished_at",
            datetime.now(timezone.utc).isoformat(),
        )
        # Atomic-replace write so a half-finished manifest never
        # ends up on disk. Tempfile in the same directory keeps the
        # rename within one filesystem boundary.
        target = self.manifest_path
        tmp = target.with_suffix(".json.tmp")
        tmp.write_text(
            json.dumps(body, indent=2, default=str, ensure_ascii=False),
            encoding="utf-8",
        )
        os.replace(tmp, target)
        return target


class LocalOutputTraceSink:
    """``TraceSink`` adapter that writes events into a :class:`LocalOutputDir`.

    Lets the existing trace pipeline (observe / session / SpecPipeline)
    persist its TraceEvents to ``~/.athanor/runs/<run_id>/traces.jsonl``
    + ``manifest.json`` without any other code change.

    :purity: IMPURE_SIDE_EFFECTFUL
    :idempotence: events with the same id appended twice produce two
                  jsonl lines (TraceSink Protocol calls for upsert
                  idempotence; for a local journal we leave the dedup
                  to downstream consumers — duplicate events are easy
                  to filter on read but expensive to detect on write
                  without an in-memory index).
    :side_effects: file writes under :func:`get_local_output_root`
    :swallow: per the TraceSink contract — every method catches and
              logs at ERROR; never raises.

    Tier classification: free. Local writes have no license gate.

    Construction:

        sink = LocalOutputTraceSink(run_id="abc-123")
        sink.emit(event)
        sink.close_run(run_id, status="succeeded", token_cost_usd=0.01)

    The wrapper opens the underlying ``LocalOutputDir`` lazily (the
    on-disk dir is not created until the first write).
    """

    def __init__(self, run_id: str, *, root: Path | None = None) -> None:
        self.run_id = run_id
        self._dir = LocalOutputDir(run_id, root=root)
        self._opened_at: str | None = None
        # Captured by open_run, attached to manifest at close_run.
        self._open_run_meta: dict[str, Any] = {}

    @property
    def output_dir(self) -> LocalOutputDir:
        """Underlying :class:`LocalOutputDir`. Customer code can
        ``write_artifact`` and ``write_subprocess_output`` directly
        for non-event payloads."""
        return self._dir

    # ── TraceSink Protocol ──────────────────────────────────────────────

    def emit(self, event: Any) -> None:
        """Append a ``TraceEvent`` to ``traces.jsonl`` as one JSON line."""
        try:
            payload = self._event_to_dict(event)
            self._dir.write_event(payload)
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            logger.error(
                "LocalOutputTraceSink.emit failed (run_id=%s): %s",
                self.run_id, exc,
            )

    def emit_escalation(self, event: Any) -> None:
        """Append an ``EscalationEvent`` to ``traces.jsonl`` with a
        ``__kind__`` discriminator so consumers can split escalations
        from regular events on read."""
        try:
            payload = self._event_to_dict(event)
            payload["__kind__"] = "escalation"
            self._dir.write_event(payload)
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            logger.error(
                "LocalOutputTraceSink.emit_escalation failed (run_id=%s): %s",
                self.run_id, exc,
            )

    def open_run(
        self,
        run_id: str,
        *,
        vertical: str = "other",
        builder_model: str | None = None,
        target: str | None = None,
        pipeline_version: str = "kairos-sdk",
        organization_id: str | None = None,
        engine_versions: Mapping[str, str | None] | None = None,
    ) -> None:
        """Capture the parent-run metadata so it lands in ``manifest.json``
        on :meth:`close_run`. Idempotent on duplicate calls (last-writer-wins).

        ATH-934: ``engine_versions`` is captured into the manifest dict so
        local replay tooling (kairos.trace_replay) can recover which Lean /
        EBMC / ACL2 / Pythia version produced a given run from disk alone.
        """
        try:
            self._opened_at = datetime.now(timezone.utc).isoformat()
            self._open_run_meta = {
                "run_id": run_id,
                "started_at": self._opened_at,
                "vertical": vertical,
                "builder_model": builder_model,
                "target": target if target is not None else run_id,
                "pipeline_version": pipeline_version,
                "organization_id": organization_id,
                "engine_versions": dict(engine_versions) if engine_versions else {},
            }
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            logger.error(
                "LocalOutputTraceSink.open_run failed (run_id=%s): %s",
                run_id, exc,
            )

    def close_run(
        self,
        run_id: str,
        *,
        status: str = "succeeded",
        outcome_verdict: Mapping[str, Any] | None = None,
        final_score: float | None = None,
        token_cost_usd: float | None = None,
        wall_time_seconds: float | None = None,
    ) -> None:
        """Write ``manifest.json`` with the run summary. Non-raising."""
        try:
            manifest: dict[str, Any] = dict(self._open_run_meta)
            manifest["run_id"] = run_id
            manifest["status"] = status
            if outcome_verdict is not None:
                manifest["outcome_verdict"] = dict(outcome_verdict)
            if final_score is not None:
                manifest["final_score"] = final_score
            if token_cost_usd is not None:
                manifest["total_cost_usd"] = token_cost_usd
            if wall_time_seconds is not None:
                manifest["wall_time_seconds"] = wall_time_seconds
            self._dir.finalize(manifest)
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            logger.error(
                "LocalOutputTraceSink.close_run failed (run_id=%s): %s",
                run_id, exc,
            )

    def flush(self) -> None:
        """No-op: writes are immediate (`open(..., "a")` flushes on close)."""

    # ── helpers ─────────────────────────────────────────────────────────

    @staticmethod
    def _event_to_dict(event: Any) -> dict[str, Any]:
        """Convert a TraceEvent / EscalationEvent / dict / dataclass to
        a dict suitable for JSON-line emission. ``default=str`` in
        :meth:`LocalOutputDir.write_event` handles non-native values."""
        if isinstance(event, Mapping):
            return dict(event)
        try:
            from dataclasses import asdict, is_dataclass
            if is_dataclass(event) and not isinstance(event, type):
                return asdict(event)
        except Exception:  # noqa: BLE001 — dataclass asdict serialization; fall through to __dict__
            pass
        if hasattr(event, "__dict__"):
            return dict(event.__dict__)
        return {"event": str(event)}


__all__ = [
    "LocalOutputDir",
    "LocalOutputTraceSink",
    "get_local_output_root",
    "get_run_dir",
]
