"""Gym-like environment interface for Athanor scoring containers."""

from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path

from kairos.scoring import score as _score_container, _find_docker
from kairos.security.env_allowlist import safe_env_for_cedar
from kairos.types import ScoreResult, TaskConfig


def _infer_stub_filename_from_config(config: dict, task: str) -> str:
    """Best-effort stub filename when docker extraction fails.

    Task configs across envs use different field names for the primary
    student-editable file. Check them in order of specificity and strip
    the `/workdir/data/` prefix the env container uses. Fall back to
    `{task}.py` only if nothing matches — the old behavior that led to
    bug #3 (qa dogfood 2026-04-20).

    Order matters: sv_file and lean_file are vertical-specific; they
    beat the generic solution_file if both are set.
    """
    for key in (
        "sv_file", "lean_file", "kernel_file", "dafny_file",
        "solution_file", "student_file", "source_file",
    ):
        val = config.get(key)
        if val:
            if val.startswith("/workdir/data/"):
                val = val[len("/workdir/data/"):]
            return val
    source_files = config.get("source_files") or []
    if source_files:
        return source_files[0]
    return f"{task}.py"


class Environment:
    """OpenAI Gym-compatible interface to an Athanor scoring container.

    Usage::

        env = Environment("neuron-nki-kernels", task="batched_matmul_accumulate")
        prompt = env.reset()
        result = env.score({"batched_matmul_accumulate_kernel.py": my_code})
        print(result.score)

    Tier classification: paid (requires the ``envs`` product +
    per-env access in the license's ``envs[]`` claim). ``__init__``
    calls :func:`kairos.license_scope.require_env_access` and
    raises :class:`kairos.license_scope.LicenseScopeError` when the
    loaded license doesn't grant ``env_name``. Each environment is
    licensed individually.
    """

    def __init__(
        self,
        env_name: str,
        task: str | None = None,
        *,
        image: str | None = None,
        timeout: int = 300,
    ):
        # Initialise attributes __del__ reads first, in case an early
        # exception (ATH-389 license check) leaves the object partially
        # constructed. Prevents the AttributeError traceback in __del__.
        self._workdir: Path | None = None
        self._task_configs: dict[str, dict] = {}

        # ATH-389: gate on license scope. Dev-mode (no license file)
        # is permissive; prod customers must hold the "envs" product
        # and have env_name in license.envs[].
        from kairos.license_scope import require_env_access
        require_env_access(env_name)

        self.env_name = env_name
        self.image = image or env_name
        self.task = task
        self.timeout = timeout
        self.tasks: list[str] = self._discover_tasks()

    def _discover_tasks(self) -> list[str]:
        """List available task IDs by reading config filenames from the container."""
        docker_bin = _find_docker()
        cmd = [
            docker_bin, "run", "--rm", "--user", "root",
            self.image, "bash", "-c",
            "ls /root_data/eval/configs/*.json 2>/dev/null",
        ]
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30, env=safe_env_for_cedar(),
            )
            if result.returncode != 0:
                return []
            lines = result.stdout.strip().splitlines()
            return [Path(line).stem for line in lines if line.strip()]
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return []

    def _load_task_config(self, task_id: str) -> dict:
        """Read a task's config JSON from the container."""
        if task_id in self._task_configs:
            return self._task_configs[task_id]

        docker_bin = _find_docker()
        cmd = [
            docker_bin, "run", "--rm", "--user", "root",
            self.image, "bash", "-c",
            f"cat /root_data/eval/configs/{task_id}.json",
        ]
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30, env=safe_env_for_cedar(),
            )
            if result.returncode == 0 and result.stdout.strip():
                config = json.loads(result.stdout.strip())
                self._task_configs[task_id] = config
                return config
        except (subprocess.TimeoutExpired, json.JSONDecodeError):
            pass
        return {}

    def _extract_student_stubs(self, task_id: str) -> dict[str, str]:
        """Extract student stub files from the container for a given task."""
        config = self._load_task_config(task_id)
        # Check all known solution file field names across envs
        stub_file = (
            config.get("kernel_file")
            or config.get("solution_file")
            or config.get("student_file")
            or config.get("source_file")
            or config.get("dafny_file")
            or config.get("sv_file")
            or (config.get("source_files") or [None])[0]
            or ""
        )
        # Strip /workdir/data/ prefix if present
        if stub_file and stub_file.startswith("/workdir/data/"):
            stub_file = stub_file[len("/workdir/data/"):]
        if not stub_file:
            return {}

        docker_bin = _find_docker()
        cmd = [
            docker_bin, "run", "--rm",
            self.image, "bash", "-c",
            f"cat /workdir/data/{stub_file} 2>/dev/null",
        ]
        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=30, env=safe_env_for_cedar(),
            )
            if result.returncode == 0 and result.stdout:
                return {stub_file: result.stdout}
        except subprocess.TimeoutExpired:
            pass
        return {}

    def reset(self, task: str | None = None) -> dict:
        """Set up a fresh working directory with student stubs.

        Args:
            task: Task ID to reset to. Uses self.task if not provided.

        Returns:
            Dict with keys:
                - task_id: the active task
                - description: task prompt/description
                - files: dict of filename -> stub content
                - difficulty: task difficulty level
                - lean_file: Lean proof file if applicable
        """
        if task is not None:
            self.task = task

        if self.task is None:
            if self.tasks:
                self.task = self.tasks[0]
            else:
                raise ValueError(
                    "No task specified and no tasks discovered. "
                    "Pass task= to reset() or the constructor."
                )

        # Clean up previous workdir
        if self._workdir and self._workdir.exists():
            shutil.rmtree(self._workdir, ignore_errors=True)

        # Create fresh tempdir
        self._workdir = Path(tempfile.mkdtemp(prefix=f"athanor_{self.task}_"))
        data_dir = self._workdir / "data"
        data_dir.mkdir()

        # Extract stub files
        stubs = self._extract_student_stubs(self.task)
        for filename, content in stubs.items():
            (data_dir / filename).write_text(content)

        # Load config for the prompt
        config = self._load_task_config(self.task)

        return {
            "task_id": self.task,
            "description": config.get("description", ""),
            "files": stubs,
            "difficulty": config.get("difficulty", ""),
            "lean_file": config.get("lean_file"),
        }

    def score(self, files: dict[str, str]) -> ScoreResult:
        """Write files to the working directory and run scoring.

        Args:
            files: Dict of filename -> file content to write before scoring.

        Returns:
            ScoreResult with score and metadata.
        """
        if self._workdir is None or self.task is None:
            raise RuntimeError("Call reset() before score().")

        data_dir = self._workdir / "data"
        data_dir.mkdir(exist_ok=True)

        # Write student files
        for filename, content in files.items():
            filepath = data_dir / filename
            filepath.parent.mkdir(parents=True, exist_ok=True)
            filepath.write_text(content)

        return _score_container(
            image=self.image,
            task_id=self.task,
            workdir=self._workdir,
            timeout=self.timeout,
        )

    def score_file(self, path: str) -> ScoreResult:
        """Score a single file (convenience for simple tasks).

        Reads the file at the given path and submits it under its basename.

        Args:
            path: Path to the file to score.

        Returns:
            ScoreResult with score and metadata.
        """
        p = Path(path)
        content = p.read_text()
        return self.score({p.name: content})

    @property
    def task_ids(self) -> list[str]:
        """List of available task IDs in this environment."""
        return self.tasks

    def get_task_config(self, task_id: str) -> TaskConfig:
        """Load full task configuration as a TaskConfig dataclass."""
        config = self._load_task_config(task_id)
        return TaskConfig(
            task_id=task_id,
            description=config.get("description", ""),
            difficulty=config.get("difficulty", ""),
            solution_file=config.get("kernel_file") or config.get("solution_file", ""),
            lean_file=config.get("lean_file"),
        )

    def iter_tasks(self):
        """Iterate over all tasks in this environment, yielding TaskConfig objects.

        Usage:
            env = Environment("lean-theorem-proving")
            for task in env.iter_tasks():
                print(task.task_id, task.difficulty)
        """
        for task_id in self.tasks:
            yield self.get_task_config(task_id)

    def get_task(self, task_id: str) -> TaskConfig:
        """Alias for get_task_config — fetch a single task by ID."""
        return self.get_task_config(task_id)

    def run(
        self,
        model: str,
        *,
        api_key: str | None = None,
        api_base: str | None = None,
        max_retries: int = 0,
        target_score: float = 0.95,
        platform_url: str | None = None,
        sync_token: str | None = None,
        on_score: callable | None = None,
    ) -> list[ScoreResult]:
        """Run a full evaluation loop: agent attempts the task, scores, optionally retries.

        This is the high-level "Solve" interface. The agent (specified by model)
        reads the task, writes code, and gets scored. If max_retries > 0 and
        score < target_score, the scoring feedback is fed back and the agent
        tries again.

        Args:
            model: LiteLLM model string (e.g., "anthropic/claude-sonnet-4-6")
            api_key: API key for the model provider
            api_base: Optional API base URL override
            max_retries: Number of retry-with-feedback attempts (0 = single attempt)
            target_score: Stop retrying once this score is reached
            platform_url: Athanor platform URL for trace streaming (optional)
            sync_token: Sync token for trace streaming (optional)
            on_score: Callback called with ScoreResult after each attempt

        Returns:
            List of ScoreResult for each attempt (1 + retries)
        """
        import os
        from kairos.runner import Runner

        task = self.task or (self.tasks[0] if self.tasks else None)
        if not task:
            raise ValueError("No task specified")

        # Resolve API key: prefer explicit arg, fall back to env vars
        resolved_api_key = api_key
        if not resolved_api_key:
            if "anthropic" in model or "claude" in model:
                resolved_api_key = os.environ.get("ANTHROPIC_API_KEY", "")
            elif "gemini" in model:
                # litellm uses GEMINI_API_KEY; fall back to GOOGLE_API_KEY for
                # Google client libs (ATH-196)
                resolved_api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY", "")
            else:
                resolved_api_key = os.environ.get("OPENAI_API_KEY", "")

        # Build a Runner (no network calls needed — just local Docker scoring)
        runner = Runner(token="local", platform_url=platform_url or "https://tahoe.athanor-ai.com")

        # Extract stub from container + determine filename.
        # When docker extraction succeeds, we get the real filename from
        # the container. When it fails (missing docker, wrong task slug,
        # broken image), fall back to what the task config declares — NOT
        # `{task}.py`, which is wrong for sysverilog (.sv), Lean (.lean),
        # Dafny (.dfy), etc. qa dogfood 2026-04-20 (bug #3): hw-cbmc task
        # got `telos_reno.py` instead of the `.sv` the env actually wants.
        stubs = self._extract_student_stubs(task)
        config = self._load_task_config(task)
        if stubs:
            stub_filename = next(iter(stubs))
        else:
            stub_filename = _infer_stub_filename_from_config(config, task)
        stub_code = stubs.get(stub_filename, "")
        task_config = {
            "task_slug": task,
            "task_description": config.get("description", task),
            "stub_code": stub_code,
            "stub_filename": stub_filename,
        }

        results: list[ScoreResult] = []
        for attempt in range(1 + max_retries):
            # Pass the full provider-prefixed model to runner.run_solve so
            # it can dispatch between native Anthropic and LiteLLM correctly.
            # Previously this was `model.split("/")[-1]` which stripped the
            # prefix and made all non-Anthropic calls fall through to
            # `_call_anthropic` (qa dogfood 2026-04-20: openai/kimi-k2.5
            # → 401 from Anthropic with a customer's OpenAI key).
            raw = runner.run_solve(
                self.image, task_config,
                model=model,
                api_key=resolved_api_key,
            )
            score_result = ScoreResult(
                score=raw.get("score", 0.0),
                metadata=raw.get("scoring_metadata", {}),
                student_files=raw.get("student_files", {}),
            )
            results.append(score_result)
            if on_score:
                on_score(score_result)
            if score_result.score >= target_score:
                break

        return results

    def _build_retry_context(self, prev: ScoreResult) -> str:
        """Build minimal retry context from previous attempt."""
        lines = ["PREVIOUS ATTEMPT — VERIFIER OUTPUT (deterministic):\n"]
        lines.append(f"score: {prev.score}")
        meta = prev.metadata
        if meta.get("checks_passed") is not None:
            lines.append(f"property_tests: {meta['checks_passed']}/{meta.get('checks_total', '?')}")
        if meta.get("lean_status"):
            lines.append(f"lean_status: {meta['lean_status']}")
            lines.append(f"lean_multiplier: {meta.get('lean_multiplier', 'n/a')}")
        if meta.get("lean_error"):
            lines.append(f"lean_error: {meta['lean_error']}")
        if meta.get("error"):
            lines.append(f"scoring_error: {meta['error']}")
        for name, content in (prev.student_files or {}).items():
            lines.append(f"\n--- {name} ---")
            lines.append(content[:8000])
        return "\n".join(lines)

    def reward_fn(self, completions: list[str], filename: str = "solution.py") -> list[float]:
        """TRL-compatible reward function.

        Args:
            completions: List of model completions (code strings)
            filename: Filename to submit each completion as

        Returns:
            List of float scores
        """
        scores = []
        for code in completions:
            self.reset(self.task)
            result = self.score({filename: code})
            scores.append(result.score)
        return scores

    def cleanup(self):
        """Remove the temporary working directory."""
        if self._workdir and self._workdir.exists():
            shutil.rmtree(self._workdir, ignore_errors=True)
            self._workdir = None

    def __del__(self):
        self.cleanup()

    def __repr__(self) -> str:
        return f"Environment({self.env_name!r}, task={self.task!r})"
