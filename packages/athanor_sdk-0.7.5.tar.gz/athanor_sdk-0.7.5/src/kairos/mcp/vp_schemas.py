"""VP (Verification Pipeline) kairos tool schemas for MCP exposure."""
from __future__ import annotations
from typing import Any

_GENERATE_SCHEMA: dict[str, Any] = {
    "name": "kairos_generate",
    "description": (
        "Generate RTL module proposals from a natural-language spec. "
        "Returns ranked proposals with yosys acceptance verdicts."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {
            "spec": {"type": "string", "description": "Natural-language design specification.", "minLength": 1},
            "module_name": {"type": "string", "description": "Target module name (inferred from spec if omitted)."},
            "output_dir": {"type": "string", "description": "Directory for generated RTL files."},
            "max_proposals": {"type": "integer", "description": "Maximum proposals to generate.", "default": 3, "minimum": 1},
        },
        "required": ["spec"],
        "additionalProperties": False,
    },
    "outputSchema": {
        "type": "object",
        "properties": {
            "proposals": {"type": "array", "items": {"type": "object", "properties": {"module_name": {"type": "string"}, "path": {"type": "string"}, "yosys_accepted": {"type": "boolean"}}, "required": ["module_name", "path", "yosys_accepted"]}},
            "acceptance_rate": {"type": "number"},
            "best_proposal": {"type": ["string", "null"]},
        },
        "required": ["proposals", "acceptance_rate", "best_proposal"],
    },
}

_SWEEP_SCHEMA: dict[str, Any] = {
    "name": "kairos_sweep",
    "description": (
        "Parameter-sweep an RTL design across multiple configurations. "
        "Returns Pareto-optimal variants ranked by area/timing objectives."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {
            "rtl_path": {"type": "string", "description": "Path to the RTL source file.", "minLength": 1},
            "parameters": {"type": "object", "description": "Map of parameter name to list of values to sweep.", "additionalProperties": {"type": "array"}},
            "objectives": {"type": "array", "items": {"type": "string"}, "description": "Optimization objectives.", "default": ["area"]},
            "max_variants": {"type": "integer", "description": "Maximum variants to synthesize.", "default": 10, "minimum": 1},
        },
        "required": ["rtl_path", "parameters"],
        "additionalProperties": False,
    },
    "outputSchema": {
        "type": "object",
        "properties": {
            "variants": {"type": "array", "items": {"type": "object", "properties": {"module_name": {"type": "string"}, "area": {"type": "number"}, "timing_ns": {"type": "number"}, "proved": {"type": "boolean"}}, "required": ["module_name", "area", "timing_ns", "proved"]}},
            "pareto_front": {"type": "array", "items": {"type": "integer"}},
            "recommendation": {"type": "integer"},
        },
        "required": ["variants", "pareto_front", "recommendation"],
    },
}

_COMPOSE_SCHEMA: dict[str, Any] = {
    "name": "kairos_compose",
    "description": (
        "Compose multiple RTL modules and verify interface compatibility. "
        "Checks for deadlocks and protocol violations across module boundaries."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {
            "top_module": {"type": "string", "description": "Name of the top-level module.", "minLength": 1},
            "rtl_files": {"type": "array", "items": {"type": "string"}, "description": "Paths to RTL files to compose.", "minItems": 1},
            "verify_deadlock": {"type": "boolean", "description": "Run deadlock-freedom check.", "default": True},
        },
        "required": ["top_module", "rtl_files"],
        "additionalProperties": False,
    },
    "outputSchema": {
        "type": "object",
        "properties": {
            "compatible": {"type": "boolean"},
            "violations": {"type": "array", "items": {"type": "string"}},
            "proof_certificate": {"type": ["object", "null"]},
        },
        "required": ["compatible", "violations", "proof_certificate"],
    },
}

_AUTOPILOT_SCHEMA: dict[str, Any] = {
    "name": "kairos_autopilot",
    "description": (
        "Run autonomous optimization loops over a set of RTL blocks. "
        "Iterates generate-verify-improve until timeout or convergence."
    ),
    "inputSchema": {
        "type": "object",
        "properties": {
            "tasks": {"type": "array", "items": {"type": "string"}, "description": "Task types to execute.", "default": ["optimize"]},
            "blocks_glob": {"type": "string", "description": "Glob pattern selecting RTL blocks.", "default": "*.sv"},
            "max_runtime_hours": {"type": "number", "description": "Wall-clock budget in hours.", "default": 8, "minimum": 0.1},
            "config_path": {"type": "string", "description": "Path to optional YAML/JSON config file."},
        },
        "required": [],
        "additionalProperties": False,
    },
    "outputSchema": {
        "type": "object",
        "properties": {
            "tasks_completed": {"type": "integer"},
            "improvements": {"type": "array", "items": {"type": "object", "properties": {"block": {"type": "string"}, "delta_pct": {"type": "number"}}, "required": ["block", "delta_pct"]}},
            "digest": {"type": "string"},
        },
        "required": ["tasks_completed", "improvements", "digest"],
    },
}

VP_TOOL_SCHEMAS: list[dict[str, Any]] = [_GENERATE_SCHEMA, _SWEEP_SCHEMA, _COMPOSE_SCHEMA, _AUTOPILOT_SCHEMA]
