"""kairos_advise — smart guide for fresh agents (ATH-1371 item 1).

The primary entry point for any customer agent. Accepts a natural
language description of what the agent wants to do and returns a
step-by-step plan with exact tool names and parameters.

Included — no license required.
"""
from __future__ import annotations

from typing import Any


_WORKFLOWS: dict[str, dict[str, Any]] = {
    "verify_sv": {
        "keywords": ["verify", "systemverilog", "sv", "verilog", "rtl", "prove", "check", "property", "assert"],
        "title": "Verify a SystemVerilog design",
        "steps": [
            {"tool": "kairos_smoke_validation", "params": {"spec": "<your_file.sv>"}, "description": "Quick syntax + property check"},
            {"tool": "sv_prove", "params": {"spec": "<your_file.sv>", "top": "<module_name>", "bound": 10}, "description": "Run EBMC bounded model checking"},
            {"tool": "certify", "params": {"run_id": "<from_sv_prove_result>"}, "description": "Generate proof certificate"},
        ],
    },
    "optimize_rtl": {
        "keywords": ["optimize", "area", "power", "reduce", "cells", "smaller", "rtl"],
        "title": "Optimize an RTL block",
        "steps": [
            {"tool": "kairos_optimize", "params": {"rtl_path": "<your_file.sv>"}, "description": "ABC optimization + optional LLM proposals"},
            {"tool": "kairos_verify_equivalence", "params": {"gold": "<original.sv>", "gate": "<optimized.sv>"}, "description": "Prove optimized design matches original"},
            {"tool": "certify", "params": {"run_id": "<from_optimize_result>"}, "description": "Generate optimization certificate"},
        ],
    },
    "verify_lean": {
        "keywords": ["lean", "theorem", "proof", "mathlib", "formal"],
        "title": "Verify a Lean theorem",
        "steps": [
            {"tool": "lean_verify", "params": {"file": "<your_file.lean>"}, "description": "Check a single Lean file"},
            {"tool": "verify_batch", "params": {"directory": "<project_dir>"}, "description": "Verify all .lean files in a directory"},
        ],
    },
    "verify_nki": {
        "keywords": ["nki", "kernel", "neuron", "accelerator", "trainium"],
        "title": "Verify an NKI kernel",
        "steps": [
            {"tool": "nki_verify", "params": {"kernel_path": "<kernel.py>"}, "description": "Verify NKI kernel against specification"},
        ],
    },
    "flow_verify_rtl": {
        "keywords": ["verify", "rtl", "bmc", "cegar", "escalate", "prove", "sv", "systemverilog", "bounded"],
        "title": "Verify RTL with auto BMC-to-CEGAR escalation",
        "steps": [
            {"tool": "flow_verify_rtl", "params": {"sv_file": "<your_file.sv>", "top_module": "<module_name>", "bound": 10}, "description": "Run BMC; auto-escalate to CEGAR on UNKNOWN"},
            {"tool": "certify", "params": {"run_id": "<from_verify_rtl_result>"}, "description": "Generate proof certificate"},
        ],
    },
    "diagnose": {
        "keywords": ["doctor", "debug", "diagnose", "setup", "configure", "check", "status"],
        "title": "Diagnose environment",
        "steps": [
            {"tool": "kairos_doctor", "params": {}, "description": "Check all tool dependencies and API keys"},
        ],
    },
    "verify_equivalence": {
        "keywords": ["equivalence", "sec", "sequential", "compare", "miter", "gold", "gate", "match", "same"],
        "title": "Verify two designs are equivalent (SEC)",
        "steps": [
            {"tool": "kairos_verify_equivalence", "params": {"gold": "<gold.sv>", "gate": "<gate.sv>"}, "description": "Prove gold and gate designs produce identical outputs"},
            {"tool": "certify", "params": {"run_id": "<from_equivalence_result>"}, "description": "Generate equivalence certificate"},
        ],
        "on_failure": "If REFUTED, the counterexample shows the divergent input. Use kairos_advise('explain counterexample') for next steps.",
    },
    "differential_test": {
        "keywords": ["differential", "diff", "fuzz", "random", "test", "compare", "implementations"],
        "title": "Differential testing across implementations",
        "steps": [
            {"tool": "kairos_differential", "params": {"impls": ["<impl_a>", "<impl_b>"], "n_samples": 1000}, "description": "Run N random inputs through two implementations and find disagreements"},
        ],
        "on_failure": "Disagreements indicate a real bug in one implementation. Check the disagreement list for the first divergent input.",
    },
    "cegar_verify": {
        "keywords": ["cegar", "incremental", "k-induction", "unbounded", "inductive", "invariant"],
        "title": "CEGAR incremental verification (unbounded proof)",
        "steps": [
            {"tool": "sv_prove", "params": {"spec": "<your_file.sv>", "top": "<module_name>", "bound": 10}, "description": "Try BMC first for shallow refutations"},
            {"tool": "kairos_cegar", "params": {"spec": "<your_file.sv>", "top": "<module_name>"}, "description": "Run CEGAR with lemma discovery for unbounded proof"},
        ],
        "on_failure": "If CEGAR times out, try increasing the timeout or adding manual invariants via kairos_mine_assumptions.",
    },
    "multi_abstraction": {
        "keywords": ["multi", "sandwich", "abstraction", "layers", "yaml", "multi-engine"],
        "title": "Multi-abstraction verification (sandwich rule)",
        "steps": [
            {"tool": "sv_multi", "params": {"yaml_path": "<spec.yaml>"}, "description": "Run multi-engine sandwich verification from a YAML spec"},
        ],
        "on_failure": "PARTIAL means some assertions weren't found in EBMC output. Check assertion names match the property labels in your SV file.",
    },
}


def advise(goal: str) -> dict[str, Any]:
    """Accept a natural language goal, return a step-by-step plan."""
    if goal is None:
        return {
            "status": "error",
            "message": "A goal description is required. Tell me what you want to do.",
            "available_workflows": [
                {"id": wf_id, "title": wf["title"]}
                for wf_id, wf in _WORKFLOWS.items()
            ],
        }
    goal_lower = goal.lower()

    matches = []
    for wf_id, wf in _WORKFLOWS.items():
        score = sum(1 for kw in wf["keywords"] if kw in goal_lower)
        if score > 0:
            matches.append((score, wf_id, wf))

    if not matches:
        return {
            "status": "no_match",
            "message": "I couldn't determine the right workflow from your description. Try being more specific.",
            "available_workflows": [
                {"id": wf_id, "title": wf["title"]}
                for wf_id, wf in _WORKFLOWS.items()
            ],
            "tip": "Describe what you have (e.g. 'a SystemVerilog module') and what you want (e.g. 'verify its properties').",
        }

    matches.sort(reverse=True)
    best_score, best_id, best_wf = matches[0]

    result: dict[str, Any] = {
        "status": "plan",
        "workflow": best_id,
        "title": best_wf["title"],
        "steps": best_wf["steps"],
        "tip": "Execute these steps in order. Each step's output feeds into the next.",
    }
    if "on_failure" in best_wf:
        result["on_failure"] = best_wf["on_failure"]
    if len(matches) > 1:
        result["alternatives"] = [
            {"workflow": wf_id, "title": wf["title"]}
            for _, wf_id, wf in matches[1:3]
        ]
    return result
