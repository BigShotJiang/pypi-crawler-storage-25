"""kairos.mcp.review — adversarial review via bootstrap corpus (ATH-1176).

v1 keyword matching against pattern triggers/categories. RAG is a follow-up.
"""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

_CORPUS_PATH = Path(__file__).parent / "bootstrap_corpus.json"
_CORPUS_CACHE: list[dict[str, Any]] | None = None


def load_corpus() -> list[dict[str, Any]]:
    """Load bootstrap_corpus.json. Cached after first call."""
    global _CORPUS_CACHE
    if _CORPUS_CACHE is not None:
        return _CORPUS_CACHE
    with open(_CORPUS_PATH) as f:
        _CORPUS_CACHE = json.load(f)
    return _CORPUS_CACHE


def match_patterns(claim: str, context: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Find relevant counterargument patterns by keyword match.

    Matches claim text against each pattern's trigger list and category.
    Returns patterns sorted by severity (critical > high > medium > low),
    then by number of trigger hits (descending).
    """
    corpus = load_corpus()
    claim_lower = claim.lower()
    # Extract words for matching
    claim_words = set(re.findall(r"[a-z][a-z0-9_-]+", claim_lower))

    # Context keywords (optional enrichment)
    ctx_words: set[str] = set()
    if context:
        for v in context.values():
            if isinstance(v, str):
                ctx_words.update(re.findall(r"[a-z][a-z0-9_-]+", v.lower()))

    all_words = claim_words | ctx_words
    severity_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3}

    scored: list[tuple[int, int, dict[str, Any]]] = []
    for pattern in corpus:
        triggers = pattern.get("trigger", [])
        category = pattern.get("category", "")
        hits = 0
        for t in triggers:
            # Multi-word triggers: check substring in claim
            if " " in t:
                if t in claim_lower:
                    hits += 1
            else:
                if t in all_words:
                    hits += 1
        # Category bonus
        if category in all_words:
            hits += 1
        if hits > 0:
            sev = severity_rank.get(pattern.get("severity", "medium"), 2)
            scored.append((sev, -hits, pattern))

    scored.sort(key=lambda x: (x[0], x[1]))
    return [entry[2] for entry in scored]


def format_counterarguments(patterns: list[dict[str, Any]]) -> str:
    """Format matched patterns into a structured adversarial review."""
    if not patterns:
        return (
            "No matching counterargument patterns found for this claim. "
            "Consider whether the claim is specific enough to evaluate."
        )

    lines: list[str] = []
    lines.append(f"## Adversarial Review ({len(patterns)} challenges)\n")
    for i, p in enumerate(patterns, 1):
        lines.append(f"### {i}. [{p['severity'].upper()}] {p['id']}")
        lines.append(f"**Challenge:** {p['counterargument']}")
        lines.append(f"**Evidence needed:** {p['evidence_template']}")
        lines.append(f"**Category:** {p['category']}\n")
    return "\n".join(lines)


def kairos_review(claim: str, context: dict[str, Any] | None = None) -> dict[str, Any]:
    """MCP entry point. Returns top-5 adversarial counterarguments for a claim."""
    matches = match_patterns(claim, context)
    # Cap at 5 most relevant to avoid overwhelming the caller
    top = matches[:5]
    return {
        "claim": claim,
        "n_patterns_matched": len(matches),
        "n_returned": len(top),
        "counterarguments": [
            {
                "id": p["id"],
                "severity": p["severity"],
                "category": p["category"],
                "challenge": p["counterargument"],
                "evidence_needed": p["evidence_template"],
            }
            for p in top
        ],
        "formatted_review": format_counterarguments(top),
    }
