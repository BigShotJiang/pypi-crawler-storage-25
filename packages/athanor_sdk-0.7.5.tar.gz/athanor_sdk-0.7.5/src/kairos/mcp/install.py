"""ATH-1408: kairos mcp install — auto-detect IDE, write MCP config.

One command to add kairos as an MCP server to any supported IDE:
  kairos mcp install

Auto-detection priority:
  1. Claude Code CLI (`claude` on PATH) -> claude mcp add
  2. Cursor (`.cursor/` in home) -> .cursor/mcp.json
  3. VS Code Claude extension -> .vscode/settings.json
  4. Fallback: write claude_desktop_config.json + print instructions

Every path is idempotent: re-running after install is a no-op.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path


_KAIROS_SERVER_CMD = ["kairos", "mcp", "serve"]
_KAIROS_SERVER_NAME = "kairos"


def _detect_ide() -> str:
    """Return the best IDE target: claude-code | cursor | vscode | desktop."""
    if shutil.which("claude"):
        return "claude-code"

    cursor_dir = Path.home() / ".cursor"
    if cursor_dir.is_dir():
        return "cursor"

    for vscode_dir in [
        Path.home() / ".vscode",
        Path.home() / ".vscode-server",
    ]:
        if vscode_dir.is_dir():
            return "vscode"

    return "desktop"


def _install_claude_code() -> bool:
    """Use `claude mcp add` to register kairos."""
    try:
        result = subprocess.run(
            ["claude", "mcp", "add", _KAIROS_SERVER_NAME, "--", *_KAIROS_SERVER_CMD],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            print("Installed kairos MCP server for Claude Code.", file=sys.stderr)
            print(f"  Verify: claude mcp list", file=sys.stderr)
            return True
        print(
            f"claude mcp add failed (exit {result.returncode}): {result.stderr.strip()}",
            file=sys.stderr,
        )
        return False
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        print(f"Failed to run claude CLI: {e}", file=sys.stderr)
        return False


def _install_cursor() -> bool:
    """Write to .cursor/mcp.json."""
    mcp_path = Path.home() / ".cursor" / "mcp.json"
    return _write_mcp_json(mcp_path, "Cursor")


def _install_vscode() -> bool:
    """Write to .vscode/settings.json (Claude extension reads mcpServers)."""
    settings_path = Path.home() / ".vscode" / "settings.json"
    settings_path.parent.mkdir(parents=True, exist_ok=True)

    existing = {}
    if settings_path.is_file():
        try:
            existing = json.loads(settings_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    mcp_servers = existing.get("claude.mcpServers", {})
    if _KAIROS_SERVER_NAME in mcp_servers:
        print("kairos MCP server already configured in VS Code settings.", file=sys.stderr)
        return True

    mcp_servers[_KAIROS_SERVER_NAME] = {
        "command": _KAIROS_SERVER_CMD[0],
        "args": _KAIROS_SERVER_CMD[1:],
    }
    existing["claude.mcpServers"] = mcp_servers
    settings_path.write_text(json.dumps(existing, indent=2) + "\n")
    print(f"Installed kairos MCP server in {settings_path}", file=sys.stderr)
    return True


def _install_desktop() -> bool:
    """Write claude_desktop_config.json for Claude Desktop app."""
    if sys.platform == "darwin":
        config_dir = Path.home() / "Library" / "Application Support" / "Claude"
    elif sys.platform == "win32":
        appdata = os.environ.get("APPDATA", "")
        config_dir = Path(appdata) / "Claude" if appdata else Path.home() / "AppData" / "Roaming" / "Claude"
    else:
        config_dir = Path.home() / ".config" / "claude"

    config_path = config_dir / "claude_desktop_config.json"
    return _write_mcp_json(config_path, "Claude Desktop")


def _write_mcp_json(config_path: Path, ide_name: str) -> bool:
    """Write or update an MCP config JSON file (Cursor/Desktop format)."""
    config_path.parent.mkdir(parents=True, exist_ok=True)

    existing = {}
    if config_path.is_file():
        try:
            existing = json.loads(config_path.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    mcp_servers = existing.get("mcpServers", {})
    if _KAIROS_SERVER_NAME in mcp_servers:
        print(f"kairos MCP server already configured in {ide_name}.", file=sys.stderr)
        return True

    mcp_servers[_KAIROS_SERVER_NAME] = {
        "command": _KAIROS_SERVER_CMD[0],
        "args": _KAIROS_SERVER_CMD[1:],
    }
    existing["mcpServers"] = mcp_servers
    config_path.write_text(json.dumps(existing, indent=2) + "\n")
    print(f"Installed kairos MCP server in {config_path}", file=sys.stderr)
    print(f"  Server command: {' '.join(_KAIROS_SERVER_CMD)}", file=sys.stderr)
    return True


def install(target: str | None = None) -> bool:
    """Install kairos MCP server into the detected (or specified) IDE.

    Args:
        target: Force a specific target: claude-code, cursor, vscode, desktop.
                If None, auto-detects.

    Returns:
        True if installation succeeded.
    """
    if target is None:
        target = _detect_ide()
        print(f"[kairos] Auto-detected IDE: {target}", file=sys.stderr)

    installers = {
        "claude-code": _install_claude_code,
        "cursor": _install_cursor,
        "vscode": _install_vscode,
        "desktop": _install_desktop,
    }

    installer = installers.get(target)
    if installer is None:
        print(
            f"Unknown target '{target}'. "
            f"Supported: {', '.join(installers)}",
            file=sys.stderr,
        )
        return False

    success = installer()
    if success:
        print(
            "\nkairos MCP tools are now available to your AI agent.\n"
            "  Try: 'call kairos_advise with goal=\"optimize my RTL block\"'\n"
            "  Docs: kairos helper quickstart",
            file=sys.stderr,
        )
    return success
