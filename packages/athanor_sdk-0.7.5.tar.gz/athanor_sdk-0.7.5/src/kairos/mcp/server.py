"""kairos.mcp.server — stdio MCP server (ATH-829 Phase 1.2).

The actual MCP transport that exposes kairos tools to MCP-consuming
agents (Claude Code, Cursor, Cline, Leanstral, OpenHands, etc.).
Pairs with the schemas (``kairos.mcp.schemas``), help topics
(``kairos.mcp.help_topics``), and lazy paid-tier registry
(``kairos.mcp.pro_extensions``).

## Q5 unified-server-with-lazy-imports flow

This module is the single ``kairos mcp serve`` CLI entrypoint. On
startup:

1. Probe the license via :func:`kairos.license_scope.require_product`
   (``"solve"``). Catches LicenseScopeError gracefully — no crash if
   the customer has no paid license.
2. Always register base SDK tools (``simple_prove_template``,
   ``verify_proof``, ``dispatch``, ``certify``, ``verify_batch``,
   ``list_pythia_templates``).
3. If license OK: lazy-load the paid-tier registry from
   ``kairos.mcp.pro_extensions.load_paid_extensions()`` — this is
   where the paid module imports actually happen, AFTER the license
   check passes. Preserves ATH-727's static-import-audit fence on
   the package itself.
4. Always register the agent self-onboarding affordances:

   - Resource ``capabilities://kairos`` — JSON descriptor of tier +
     verifiers + tools.
   - Resource ``decision_tree://kairos/lean`` — canonical reasoning
     path for Lean targets.
   - Tool ``kairos_help`` — `topic` argument returns prose-shaped
     guidance.

5. Run the stdio MCP server until the agent disconnects.

## Customer-Opus default flow

Customer's outer agent (their Opus 4.7) connects via Claude Code or
similar MCP-aware client. Reads ``capabilities://kairos`` to learn
its tier + tool list. For Lean targets, reads
``decision_tree://kairos/lean`` to pick the right tool. On hard
targets, calls ``lean_solve`` (paid) and either gets back a closed
proof or structured ``decompose_hints`` to drive its own next step.

## Import-fence preservation (Q5 lock)

This module DOES import paid features — but only inside the
``register_paid_tools`` function body, AFTER the license probe.
The `kairos.mcp` package's ``__init__.py`` does NOT import this
``server`` module at all (it's only invoked via the CLI subcommand,
which a customer never reaches because ``require_product``
raises). Result: ``import kairos.mcp`` stays clean of paid imports
even with this server module sitting next to it.
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

logger = logging.getLogger(__name__)

_GETTING_STARTED_GUIDE = """\
# Kairos — Getting Started for Agents

## What is kairos?
Formal verification as agentic training signal. Kairos verifies hardware (SystemVerilog, Verilog) and software (Lean, NKI) correctness, optimizes RTL designs, and generates proof certificates.

## Quick start — call `kairos_advise` first
If you're unsure which tool to use, call `kairos_advise` with a description of what you want to do. It returns a step-by-step plan with exact tool names and parameters.

## Common workflows

### Verify a SystemVerilog design
1. `kairos_smoke_validation` — quick syntax + property check
2. `kairos_verify` or `sv_prove` — run EBMC bounded model checking
3. `certify` — generate a proof certificate from the result

### Optimize an RTL block
1. `kairos_optimize` — ABC deterministic optimization + optional LLM proposals
2. `kairos_verify_equivalence` — prove the optimized design matches the original
3. `certify` — generate a certificate documenting the optimization + proof

### Verify a Lean theorem
1. `lean_verify` — check a single Lean file
2. `verify_batch` — verify all .lean files in a directory
3. `lean_race` — race multiple proof strategies for speed

### Verify NKI kernels
1. `nki_verify` — verify an NKI kernel against its specification

## Tool categories
- **Verification**: sv_prove, ebmc_verify, lean_verify, verify_batch, nki_verify, acl2_verify
- **Optimization**: kairos_optimize, kairos_propose, kairos_synth_delta
- **Certification**: certify, kairos_inspect_cert
- **Planning**: kairos_advise, kairos_plan_optimization, kairos_formal_explore
- **Diagnostics**: kairos_doctor, kairos_list_models, kairos_recall

## Tips
- Always run `kairos_doctor` first to check your environment is configured correctly
- Use `kairos_smoke_validation` before expensive verification runs
- Call `kairos_advise` when unsure — it knows the optimal tool sequence
"""


# ── Tier probe — gracefully degrade ───────────────────────────────────


def _probe_license_tier() -> tuple[str, list[str]]:
    """Return (tier_name, products_granted).

    Tier mapping:

    * ``"paid"``: license file present + ``solve`` product granted, OR
      ``KAIROS_DEV_NO_LICENSE=1`` set (internal dev bypass).
    * ``"free"``: any of: license file absent, license expired, license
      missing the ``solve`` product, license file unreadable.

    Never raises — paid tier failure cleanly degrades to free.
    """
    try:
        from kairos.license_scope import load_license

        license_ = load_license()
        if getattr(license_, "is_dev_bypass", False):
            return ("paid", ["solve", "dev_bypass"])
        products = list(getattr(license_, "products", []) or [])
        if "solve" in products:
            return ("paid", products)
        return ("free", products)
    except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
        logger.info("kairos.mcp.server: license probe failed (%s); degrading to base SDK", e)
        return ("free", [])


# ── Tool dispatch table — built at server startup ────────────────────


def _build_free_tools() -> dict[str, dict[str, Any]]:
    """Build the {tool_name: {schema, callable}} map for base SDK tools.

    Free tools live in core kairos modules — no separate package, just
    bound to public functions. The schemas live in
    :mod:`kairos.mcp.schemas`; this function pairs each schema with
    its actual Python entry point.

    Tools that haven't shipped yet (per their `_pending` marker in
    schemas) are registered with a stub that returns a structured
    ``not_yet_implemented`` response — useful for agents probing the
    surface during the SDK's incremental rollout.
    """
    from kairos.mcp.schemas import KAIROS_TOOL_SCHEMAS

    tools: dict[str, dict[str, Any]] = {}

    # kairos_advise — smart guide, first tool any agent should call
    from kairos.mcp.advisor import advise as _advise_impl
    tools["kairos_advise"] = {
        "schema": {
            "name": "kairos_advise",
            "description": (
                "Smart guide — call this FIRST. Describe what you want to do "
                "in natural language and get a step-by-step plan with exact "
                "tool names and parameters."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "goal": {
                        "type": "string",
                        "description": "What you want to accomplish (e.g. 'verify my SystemVerilog module' or 'optimize an RTL block for area')",
                    },
                },
                "required": ["goal"],
            },
        },
        "callable": lambda goal: _advise_impl(goal),
    }

    # simple_prove_template — bind to kairos.simple_prove_template
    try:
        from kairos.simple_prove_template import simple_prove_template
        tools["simple_prove_template"] = {
            "schema": KAIROS_TOOL_SCHEMAS["simple_prove_template"],
            "callable": simple_prove_template,
        }
    except ImportError as e:
        logger.warning("simple_prove_template not importable: %s", e)

    # lean_verify — atomic per-call lake compile (sibling to verify_batch).
    # Wrapped to map MCP-friendly arg names (lake_project, module_path,
    # timeout_seconds, code) onto verify_proof's kw signature, and to
    # serialise ProofResult into a JSON-safe dict.
    try:
        from kairos.lean import verify_proof as _verify_proof_impl

        def _lean_verify(
            code: str,
            lake_project: str | None = None,
            module_path: str | None = None,
            timeout_seconds: int = 600,
        ) -> dict:
            result = _verify_proof_impl(
                code=code,
                lake_project=lake_project,
                module_path=module_path,
                timeout=timeout_seconds,
            )
            return {
                "compiles": getattr(result, "compiles", False),
                "has_sorry": getattr(result, "has_sorry", False),
                "sorry_count": getattr(result, "sorry_count", 0),
                "score": getattr(result, "score", 0.0),
                "errors": [str(e) for e in (getattr(result, "errors", None) or [])],
                "banned": getattr(result, "banned", None),
            }

        tools["lean_verify"] = {
            "schema": KAIROS_TOOL_SCHEMAS["lean_verify"],
            "callable": _lean_verify,
        }
    except ImportError as e:
        logger.warning("kairos.lean.verify_proof not importable: %s", e)

    # lean_check_signature — type-check a Lean statement without proving.
    # Thin pass-through to kairos.lean.check_signature.
    try:
        from kairos.lean import check_signature as _check_signature_impl

        def _lean_check_signature(
            stmt: str,
            imports: list[str] | None = None,
            opens: list[str] | None = None,
            lake_project: str | None = None,
            timeout_seconds: int = 60,
        ) -> dict:
            return _check_signature_impl(
                stmt,
                imports=imports,
                opens=opens,
                lake_project=lake_project,
                timeout=timeout_seconds,
            )

        tools["lean_check_signature"] = {
            "schema": KAIROS_TOOL_SCHEMAS["lean_check_signature"],
            "callable": _lean_check_signature,
        }
    except ImportError as e:
        logger.warning("kairos.lean.check_signature not importable: %s", e)

    # dispatch — Pythia tactic-ladder dispatcher
    try:
        # The dispatch entry point lives in kairos.sv.dispatch (per
        # the existing base SDK surface). Import is gated to avoid
        # eager-load failures on base installs that don't have
        # the sv subpackage.
        from kairos.sv.dispatch import dispatch as _dispatch
        tools["dispatch"] = {
            "schema": KAIROS_TOOL_SCHEMAS["dispatch"],
            "callable": _dispatch,
        }
    except ImportError as e:
        logger.info("kairos.sv.dispatch not available; dispatch tool will return stub: %s", e)

    # The other free tools (verify_batch, list_pythia_templates, certify)
    # follow the same pattern. For Phase 1.2 we register the schemas;
    # the actual Python wiring is best left to QA's ATH-727 transport
    # work since they own those tool implementations. The MCP server
    # surfaces them with stub responses so agents can still discover
    # them via tools/list.
    for stub_name in ("verify_batch", "list_pythia_templates", "certify"):
        if stub_name in KAIROS_TOOL_SCHEMAS and stub_name not in tools:
            schema = KAIROS_TOOL_SCHEMAS[stub_name]
            if "_pending" in schema:
                tools[stub_name] = {
                    "schema": schema,
                    "callable": _stub_pending(stub_name, schema.get("_pending", "")),
                }

    # nki_verify — wraps NeuronNKIPlugin.verify (ATH-890). Included:
    # all the work happens in the customer-shipped bundle's verify.py;
    # this is just an MCP-callable façade.
    try:
        from kairos.verticals.neuron_nki import NeuronNKIPlugin

        def _nki_verify(
            bundle_path: str,
            timeout_sec: int = 300,
        ) -> dict:
            plugin = NeuronNKIPlugin()
            verdict = plugin.verify(
                intent={},
                witness={"bundle_path": bundle_path},
                timeout_sec=float(timeout_sec),
            )
            return {
                "outcome": verdict.outcome,
                "source": verdict.source,
                "reason": verdict.reason or "",
                "details": dict(verdict.details or {}),
            }

        tools["nki_verify"] = {
            "schema": KAIROS_TOOL_SCHEMAS["nki_verify"],
            "callable": _nki_verify,
        }
    except ImportError as e:
        logger.warning("kairos.verticals.neuron_nki not importable: %s", e)

    # ATH-1077 Phase B: kairos_smoke_validation — included mechanical
    # pre-fire gate (no LLM). Binds in the FREE fence per spec because
    # smoke is the on-ramp to the paid kairos_optimize_block — gating
    # smoke would lose more adoption than it captures.
    try:
        from kairos.sec.smoke import smoke_validate as _smoke_validate_impl

        def _kairos_smoke_validation(
            bundle_path: str,
            top_module: str | None = None,
            bound_default: int = 32,
            bound_ladder: list[int] | None = None,
            fail_fast: bool = True,
            timeout_sec_per_step: int = 60,
        ) -> dict:
            ladder = tuple(bound_ladder) if bound_ladder else (32, 64, 128)
            result = _smoke_validate_impl(
                bundle_path=bundle_path,
                top_module=top_module,
                bound_default=bound_default,
                bound_ladder=ladder,
                fail_fast=fail_fast,
                timeout_sec_per_step=timeout_sec_per_step,
            )
            return result.to_dict()

        tools["kairos_smoke_validation"] = {
            "schema": KAIROS_TOOL_SCHEMAS["kairos_smoke_validation"],
            "callable": _kairos_smoke_validation,
        }
    except ImportError as e:
        logger.warning("kairos.sec.smoke not importable: %s", e)

    # kairos_doctor — environment health check via MCP
    try:
        from kairos.doctor import run_all_checks, CheckResult

        def _kairos_doctor(live_ping: bool = False) -> dict:
            results = run_all_checks(live_ping=live_ping)
            checks = []
            for r in results:
                checks.append({
                    "name": r.name,
                    "status": str(r.status),
                    "detail": r.detail,
                    "fix_hint": r.fix_hint or None,
                })
            n_pass = sum(1 for r in results if r.is_pass())
            n_fail = sum(1 for r in results if r.is_fail())
            n_skip = len(results) - n_pass - n_fail
            return {
                "summary": f"{n_pass} passed, {n_fail} failed, {n_skip} skipped",
                "all_passed": n_fail == 0,
                "checks": checks,
            }

        tools["kairos_doctor"] = {
            "schema": KAIROS_TOOL_SCHEMAS["kairos_doctor"],
            "callable": _kairos_doctor,
        }
    except ImportError as e:
        logger.warning("kairos.doctor not importable: %s", e)

    # kairos_list_models — enumerate available models for the current env
    try:
        from kairos.doctor import list_available_models

        def _kairos_list_models() -> dict:
            # ATH-1290: AvailableModel is now a TypedDict (was @dataclass).
            # Field access via subscript; field name is `model_id`
            # (the prior `m.model` attribute access was a bug — that
            # field never existed on the dataclass and would have
            # raised AttributeError at runtime on any MCP invocation).
            models = list_available_models()
            return {
                "models": [
                    {
                        "provider": m["provider"],
                        "model": m["model_id"],
                        "backend": m["backend"],
                    }
                    for m in models
                ],
                "count": len(models),
            }

        tools["kairos_list_models"] = {
            "schema": KAIROS_TOOL_SCHEMAS["kairos_list_models"],
            "callable": _kairos_list_models,
        }
    except ImportError as e:
        logger.warning("kairos.doctor.list_available_models not importable: %s", e)

    # kairos_explain_refute — parse counterexample into structured JSON
    try:
        from kairos.sec.explain_refute import explain_refute

        def _kairos_explain_refute(
            counterexample_text: str,
            property_name: str | None = None,
            gold_module: str | None = None,
            gate_module: str | None = None,
        ) -> dict:
            result = explain_refute(
                counterexample_text,
                property_name=property_name,
                gold_module=gold_module,
                gate_module=gate_module,
            )
            return result.to_dict()

        tools["kairos_explain_refute"] = {
            "schema": KAIROS_TOOL_SCHEMAS["kairos_explain_refute"],
            "callable": _kairos_explain_refute,
        }
    except ImportError as e:
        logger.warning("kairos.sec.explain_refute not importable: %s", e)

    # kairos_plan_optimization — staged curriculum with confidence
    try:
        from kairos.sec.closed_loop.plan_optimization import plan_optimization

        def _kairos_plan_optimization(
            block_name: str = "unknown",
            block_class: str = "generic",
            is_combinational: bool = False,
            encoding: str | None = None,
            signature_path: str | None = None,
        ) -> dict:
            result = plan_optimization(
                signature_path=signature_path,
                block_name=block_name,
                block_class=block_class,
                is_combinational=is_combinational,
                encoding=encoding,
            )
            return result.to_dict()

        tools["kairos_plan_optimization"] = {
            "schema": KAIROS_TOOL_SCHEMAS["kairos_plan_optimization"],
            "callable": _kairos_plan_optimization,
        }
    except ImportError as e:
        logger.warning("kairos.sec.closed_loop.plan_optimization not importable: %s", e)

    # kairos_recall — block memory lookup (included)
    try:
        from kairos.sec.closed_loop.block_memory import load_memory

        def _kairos_recall(block_path: str) -> dict:
            mem = load_memory(block_path)
            return {
                "block_hash": mem.block_hash,
                "refutation_count": len(mem.refutations),
                "success_count": len(mem.successes),
                "synthesis_floor_confidence": mem.synthesis_floor_confidence,
                "is_at_floor": mem.is_at_floor(),
                "refutation_patterns": mem.refutation_patterns(),
                "proposer_context": mem.format_for_proposer(),
            }

        tools["kairos_recall"] = {
            "schema": KAIROS_TOOL_SCHEMAS["kairos_recall"],
            "callable": _kairos_recall,
        }
    except ImportError as e:
        logger.warning("kairos.sec.closed_loop.block_memory not importable: %s", e)

    # kairos_formal_explore — EBMC capability assessment
    try:
        from kairos.sec.formal_explore import formal_explore

        def _kairos_formal_explore(query: str) -> dict:
            return formal_explore(query).to_dict()

        tools["kairos_formal_explore"] = {
            "schema": KAIROS_TOOL_SCHEMAS["kairos_formal_explore"],
            "callable": _kairos_formal_explore,
        }
    except ImportError as e:
        logger.warning("kairos.sec.formal_explore not importable: %s", e)

    # kairos_review — adversarial counterargument review (ATH-1176)
    from kairos.mcp.review import kairos_review as _kairos_review_impl

    tools["kairos_review"] = {
        "schema": {
            "name": "kairos_review",
            "description": (
                "Adversarial review: given a verification claim, returns "
                "counterarguments from the bootstrap corpus that challenge "
                "the claim. Use after any verification pass to stress-test "
                "your confidence."
            ),
            "parameters": {
                "type": "object",
                "properties": {
                    "claim": {
                        "type": "string",
                        "description": "The verification claim to challenge (e.g. 'this RTL block is equivalent to the gold model').",
                    },
                    "context": {
                        "type": "object",
                        "description": "Optional context dict (e.g. {\"tool_used\": \"ebmc_verify\", \"bound\": \"32\"}).",
                    },
                },
                "required": ["claim"],
            },
        },
        "callable": _kairos_review_impl,
    }

    def _kairos_verify_impl(path: str, only: str | None = None, **kw: Any) -> dict:
        from kairos.verify_consolidated import verify_all
        only_layers = [s.strip() for s in only.split(",")] if only else None
        result = verify_all(path, only=only_layers)
        return {"summary": result.summary, "quality_score": result.quality_score,
                "total_findings": result.total_findings, "layers": result.layer_results}

    tools["kairos_verify"] = {
        "schema": KAIROS_TOOL_SCHEMAS.get("kairos_verify", {}),
        "callable": _kairos_verify_impl,
    }

    def _kairos_repair_impl(path: str, fix: bool = True, focus: str | None = None, **kw: Any) -> dict:
        from kairos.repair import repair, format_repair
        result = repair(path, fix=fix, focus=focus)
        return {"path": result.path, "findings": len(result.findings),
                "fixes_applied": result.fixes_applied, "error": result.error}

    tools["kairos_repair"] = {
        "schema": KAIROS_TOOL_SCHEMAS.get("kairos_repair", {}),
        "callable": _kairos_repair_impl,
    }

    def _kairos_explore_impl(path: str, **kw: Any) -> dict:
        from pathlib import Path as _EP
        p = _EP(path)
        if not p.exists():
            return {"error": f"not found: {path}"}
        if p.is_dir():
            files = sorted(str(f) for f in p.rglob("*") if f.is_file() and "__pycache__" not in str(f))[:50]
            return {"type": "directory", "path": str(p), "files": len(files), "sample": files[:10]}
        return {"type": "file", "path": str(p), "size": p.stat().st_size, "suffix": p.suffix}

    tools["kairos_explore"] = {
        "schema": KAIROS_TOOL_SCHEMAS.get("kairos_explore", {}),
        "callable": _kairos_explore_impl,
    }


    # ATH-1085: best-variant selector for compound optimization (included)
    from kairos.best_variant import select_best_variant, format_variant_report
    from kairos.best_variant import _is_proved as _bv_is_proved

    def _kairos_select_best_design(iteration_summaries: list) -> dict:
        best = select_best_variant(iteration_summaries)
        report = format_variant_report(iteration_summaries, best)
        n_proved = sum(1 for s in iteration_summaries if _bv_is_proved(s))
        return {
            "best_variant": best,
            "report": report,
            "n_proved": n_proved,
            "n_total": len(iteration_summaries),
        }

    tools["kairos_select_best_design"] = {
        "schema": KAIROS_TOOL_SCHEMAS["kairos_select_best_design"],
        "callable": _kairos_select_best_design,
    }

    return tools


def _stub_pending(tool_name: str, ticket_ref: str):
    """Build a stub callable for tools whose impl is pending another
    SDK ticket. Returns a structured "not yet implemented" response so
    agents can detect + branch."""
    def _stub(**kwargs):
        return {
            "status": "not_yet_implemented",
            "tool": tool_name,
            "tracking_ticket": ticket_ref,
            "guidance": (
                f"This tool is registered but not yet wired in the MCP server. "
                f"Track via {ticket_ref}. Base SDK alternatives: simple_prove_template, "
                f"verify_proof (when split out)."
            ),
        }
    _stub.__name__ = f"{tool_name}_stub"
    return _stub


def _build_paid_tools() -> dict[str, dict[str, Any]]:
    """Lazy-load paid-tier tools. Called only when license probe says
    ``"paid"``. Imports paid features here (NOT at module-load time)
    to preserve the static-import-audit fence on ``kairos.mcp``.

    Returns empty dict on any error — server still serves base SDK tools.
    """
    try:
        from kairos.mcp.pro_extensions import load_paid_extensions, paid_tool_schemas
        callables = load_paid_extensions()
        schemas = paid_tool_schemas()
        out: dict[str, dict[str, Any]] = {}
        for name, fn in callables.items():
            if name in schemas:
                out[name] = {"schema": schemas[name], "callable": fn}
        return out
    except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
        logger.error("kairos.mcp.server: paid-tier load failed: %s", e)
        return {}


# ── MCP Server setup ────────────────────────────────────────────────


def build_server() -> tuple[Any, dict[str, Any]]:
    """Build the MCP Server instance + the registered-tools snapshot.

    Returns (server, registered_tools) — the server is ready to run via
    stdio_server; registered_tools is the snapshot for inspection.
    """
    # mcp SDK is an OPTIONAL dependency. Import here so that
    # `from kairos.mcp.server import ...` raises a clean ImportError
    # only when the user actually tries to start the server (vs at
    # module-load time, which would break `pip install athanor-sdk`
    # without the [mcp] extra).
    from mcp.server import Server
    import mcp.types as types

    tier, products = _probe_license_tier()
    logger.info("kairos.mcp.server: license tier = %s, products = %s", tier, products)

    # Always register base SDK tools
    registered = _build_free_tools()

    # Conditionally register paid tier
    if tier == "paid":
        registered.update(_build_paid_tools())

    server = Server("kairos")

    @server.list_tools()
    async def handle_list_tools():
        # kairos.help is always available — agent self-onboarding tool
        out: list[Any] = [
            types.Tool(
                name="kairos_help",
                description=(
                    "Use this when: you're new to kairos and want guidance "
                    "on which tool to pick for your task. Returns prose-shaped "
                    "JSON for canonical topics: getting_started, lean_simple_prove, "
                    "lean_solve_decomposition, lean_solve_internal_planner, "
                    "ebmc_cegar, choosing_a_tool, list_topics."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "topic": {
                            "type": "string",
                            "description": "Help topic name. Call kairos_help with topic='list_topics' to enumerate.",
                        },
                    },
                    "required": ["topic"],
                },
            ),
        ]
        for name, info in registered.items():
            schema = info["schema"]
            out.append(types.Tool(
                name=name,
                description=schema["description"],
                inputSchema=schema["parameters"],
            ))
        return out

    @server.call_tool()
    async def handle_call_tool(name: str, arguments: dict[str, Any]):
        # Time injection: every tool response includes verified PT time
        from datetime import datetime
        import zoneinfo
        _pt = datetime.now(zoneinfo.ZoneInfo("America/Los_Angeles"))
        _time_prefix = f"[Current time: {_pt.strftime('%-I:%M %p PT, %A %B %-d %Y')}]\n\n"

        # Built-in: kairos_current_time
        if name == "kairos_current_time":
            return [types.TextContent(type="text", text=_time_prefix.strip())]

        # Built-in: kairos_help
        if name == "kairos_help":
            from kairos.mcp.help_topics import get_help_topic
            topic = arguments.get("topic", "getting_started")
            result = get_help_topic(topic)
            return [
                types.TextContent(type="text", text=_time_prefix.strip()),
                types.TextContent(type="text", text=json.dumps(result, indent=2)),
            ]

        # Routed tools
        info = registered.get(name)
        if info is None:
            return [types.TextContent(
                type="text",
                text=json.dumps({
                    "status": "tool_not_registered",
                    "tool": name,
                    "available_tools": ["kairos_help"] + list(registered.keys()),
                    "license_tier": tier,
                }, indent=2),
            )]

        try:
            result = info["callable"](**arguments)
            # Normalize result to a JSON-serializable shape.
            if hasattr(result, "__dataclass_fields__"):
                from dataclasses import asdict
                result_serialized = asdict(result)
            elif isinstance(result, dict):
                result_serialized = result
            else:
                # Fallback: stringify
                result_serialized = {"result": str(result)}
            return [
                types.TextContent(type="text", text=_time_prefix.strip()),
                types.TextContent(type="text", text=json.dumps(result_serialized, indent=2, default=str)),
            ]
        except Exception as e:
            logger.exception("Tool %s raised", name)
            return [
                types.TextContent(type="text", text=_time_prefix.strip()),
                types.TextContent(type="text", text=json.dumps({
                    "status": "error",
                    "tool": name,
                    "error_kind": type(e).__name__,
                    "error_message": str(e),
                }, indent=2)),
            ]

    @server.list_resources()
    async def handle_list_resources():
        return [
            types.Resource(
                uri="getting-started://kairos",
                name="kairos getting started guide",
                description=(
                    "READ THIS FIRST. Complete guide for new agents: "
                    "which tools to use, in what order, with examples. "
                    "Covers verification, optimization, and certification."
                ),
                mimeType="text/markdown",
            ),
            types.Resource(
                uri="capabilities://kairos",
                name="kairos capabilities descriptor",
                description=(
                    "Tier-aware capability JSON. Read this on first connect: "
                    "lists which verifiers + tools you have access to and "
                    "points at the canonical onboarding flow."
                ),
                mimeType="application/json",
            ),
            types.Resource(
                uri="decision_tree://kairos/lean",
                name="kairos Lean decision tree",
                description=(
                    "Canonical reasoning path for Lean targets: "
                    "simple_prove_template → lean_race → lean_solve → Aristotle. "
                    "Use to drive your planner's tool selection."
                ),
                mimeType="application/json",
            ),
        ]

    @server.read_resource()
    async def handle_read_resource(uri: Any):
        # uri may be an AnyUrl or string depending on mcp version
        uri_str = str(uri)
        if uri_str == "getting-started://kairos":
            return _GETTING_STARTED_GUIDE
        if uri_str == "capabilities://kairos":
            from kairos.mcp.help_topics import get_capabilities
            data = get_capabilities(license_tier=tier)
            return json.dumps(data, indent=2)
        if uri_str == "decision_tree://kairos/lean":
            from kairos.mcp.help_topics import get_decision_tree
            data = get_decision_tree("lean")
            return json.dumps(data, indent=2)
        return json.dumps({
            "status": "resource_not_found",
            "uri": uri_str,
            "available_uris": [
                "getting-started://kairos",
                "capabilities://kairos",
                "decision_tree://kairos/lean",
            ],
        }, indent=2)

    return server, registered


async def serve_stdio() -> None:
    """Run the MCP server over stdio. Called by the
    `kairos mcp serve` CLI entrypoint.
    """
    from mcp.server.stdio import stdio_server

    server, registered = build_server()
    logger.info("kairos.mcp.server: starting stdio server with %d tools", len(registered) + 1)

    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def cli_serve() -> int:
    """CLI entrypoint for `kairos mcp serve`. Returns exit code."""
    logging.basicConfig(level=logging.INFO, format="%(name)s: %(message)s")
    try:
        asyncio.run(serve_stdio())
        return 0
    except KeyboardInterrupt:
        logger.info("kairos.mcp.server: interrupted, shutting down cleanly")
        return 0
    except ImportError as e:
        # `mcp` SDK not installed — point the customer at the extras.
        logger.error(
            "MCP server requires the `mcp` package. Install via:\n"
            "  pip install athanor-sdk[mcp]\n"
            "Underlying error: %s", e
        )
        return 2


__all__ = [
    "build_server",
    "serve_stdio",
    "cli_serve",
    "_probe_license_tier",
]
