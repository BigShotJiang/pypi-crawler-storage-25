"""ATH-727 — JSON-schemas + function-calling shapes for kairos base SDK tools.

Pure Python, no external dependencies. Three output formats from the
same source-of-truth schema dict per tool:

1. `KAIROS_TOOL_SCHEMAS` — canonical Draft 2020-12 JSON Schema, suitable
   for documentation, raw HTTP consumers, and the `tools/list` MCP
   transport response (PR #2 of ATH-727).
2. `openai_tools()` — OpenAI Chat Completions function-calling shape:
   `[{type: "function", function: {name, description, parameters}}, ...]`
3. `anthropic_tools()` — Anthropic Messages tool-use shape:
   `[{name, description, input_schema}, ...]`

## BYO-LLM provider list

The `BYO_LLM_PROVIDERS` constant advertises every BYO-LLM provider the
SDK supports. Per @cto's 2026-04-27 Q4 lock, this includes Mistral
(Leanstral) alongside Anthropic / OpenAI / Gemini. Tool descriptions
reference this list so agent loops can route NL→Lean autoformalization
to a specialist model (Leanstral) and verification + certify to kairos.

## What's NOT in this module

- The MCP transport itself — see `kairos.mcp.server` (PR #2).
- The lake-build wrapper that parses `[pythia.result]` / `[pythia.failure]`
  tagged log lines — see ATH-728.
- Tool *implementations* — the schemas describe the existing entry
  points (`kairos.simple_prove_template`, `kairos.sv.dispatch`, etc.); this
  module just declares their shape.
"""
from __future__ import annotations

from typing import Any

# Per @cto 2026-04-27 (Q4 lock): advertise Leanstral / Mistral alongside
# the existing three providers. Each entry is the canonical name agents
# use when picking a provider; the SDK's BYO-LLM dispatcher reads the
# matching env var per the kairos.llm_byo registry.
BYO_LLM_PROVIDERS: tuple[dict[str, str], ...] = (
    {
        "name": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
        "default_model": "claude-haiku-4-5",
        "use_case": "general-purpose autoformalization, certify reasoning",
    },
    {
        "name": "openai",
        "env_var": "OPENAI_API_KEY",
        "default_model": "gpt-4o-mini",
        "use_case": "general-purpose autoformalization",
    },
    {
        "name": "gemini",
        "env_var": "GEMINI_API_KEY",
        "default_model": "gemini-2.5-flash",
        "use_case": "general-purpose autoformalization",
    },
    {
        "name": "mistral",
        "env_var": "MISTRAL_API_KEY",
        "default_model": "leanstral-1",
        "use_case": (
            "Lean 4 specialist (Leanstral, Mistral 2026-03). "
            "Use for high-quality NL→Lean translation when the goal "
            "involves Mathlib / Pythia symbols. kairos verifies the "
            "Lean output kernel-cleanly regardless of which provider "
            "produced it."
        ),
    },
)


# ─── Per-tool schemas (canonical) ─────────────────────────────────────


_SIMPLE_PROVE_SCHEMA: dict[str, Any] = {
    "name": "simple_prove_template",
    "description": (
        "Use this when: you have a natural-language claim (e.g. 'for all x, x+0 = x') "
        "and want a boolean proved/not-proved verdict. This is the default entry point "
        "for NL-to-proof. Matches built-in Pythia templates first (fast, no LLM cost); "
        "falls back to BYO-LLM autoformalization when no template fits. Returns an "
        "English verdict + structured detector output including vacuous-truth and "
        "axiom-audit fields. Included; no license required. Call list_pythia_templates "
        "first to check template coverage."
    ),
    "parameters": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {
            "hypothesis": {
                "type": "string",
                "description": (
                    "Free-text claim to prove. Best results when "
                    "phrased to match a Pythia template — see the "
                    "`list_pythia_templates` tool. With a BYO-LLM key "
                    "configured, free-form prose works too."
                ),
                "minLength": 1,
            },
            "show_lean": {
                "type": "boolean",
                "description": "When true, summary includes generated Lean source.",
                "default": False,
            },
            "reject_vacuous": {
                "type": "boolean",
                "description": (
                    "ATH-720 opt-in. When true, downgrade `proved=true` "
                    "to `proved=false` if the proof was vacuous "
                    "(macro-bodied sorry/admit) or smuggled a custom "
                    "axiom. Default false — kernel verdict preserved, "
                    "violations reported via `vacuous_truth_clean` and "
                    "`axiom_audit_clean` fields."
                ),
                "default": False,
            },
        },
        "required": ["hypothesis"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "summary": {"type": "string"},
            "proved": {"type": "boolean"},
            "pattern_id": {"type": ["string", "null"]},
            "used_llm": {"type": "boolean"},
            "spec_path": {"type": ["string", "null"]},
            "vacuous_truth_clean": {"type": ["boolean", "null"]},
            "axiom_audit_clean": {"type": ["boolean", "null"]},
            "detector_matches": {"type": "array"},
        },
        "required": ["summary", "proved", "used_llm"],
    },
}


_DISPATCH_SCHEMA: dict[str, Any] = {
    "name": "dispatch",
    "description": (
        "Dispatch a goal payload to the appropriate OSS Sledgehammer "
        "adapter (cvc5 / vampire / eprover / ebmc / cbmc / dafny). "
        "Use this when you have a pre-formatted SMT-LIB, TPTP, "
        "SystemVerilog, C, or Dafny file and want a raw solver verdict "
        "without Lean or LLM involvement. Pattern-matches the input shape "
        "or accepts an explicit `force_adapter`. Returns adapter_used + "
        "verdict (sat/unsat/proved/refuted/unknown) + solver transcript. "
        "Included; OSS only."
    ),
    "parameters": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {
            "goal_text": {
                "type": "string",
                "description": "Goal payload (inline content or path).",
                "minLength": 1,
            },
            "force_adapter": {
                "type": ["string", "null"],
                "enum": [None, "cvc5", "ebmc", "cbmc", "vampire", "eprover", "dafny"],
                "description": "Bypass kind detection; force a specific adapter.",
                "default": None,
            },
            "timeout_sec": {
                "type": "integer",
                "minimum": 1,
                "maximum": 3600,
                "description": "Wall-clock subprocess timeout in seconds.",
                "default": 60,
            },
        },
        "required": ["goal_text"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "adapter_used": {
                "type": "string",
                "enum": ["cvc5", "ebmc", "cbmc", "vampire", "eprover", "dafny"],
            },
            "verdict": {"type": "string"},
            "transcript": {"type": "string"},
            "error": {"type": "string"},
        },
        "required": ["adapter_used", "verdict"],
    },
}


_VERIFY_BATCH_SCHEMA: dict[str, Any] = {
    "name": "verify_batch",
    "_pending": "ATH-1315",
    "description": (
        "Run `simple_prove_template` across a JSONL batch of hypotheses "
        "in a single call. Use this when you have a regression suite or "
        "CI gate with multiple claims to verify and want per-row verdicts "
        "plus an aggregate pass/fail summary. Input: path to a JSONL file "
        "where each line is {\"hypothesis\": \"...\", \"id\": \"...\"}. "
        "Returns total/proved/failed counts plus a results array. Included."
    ),
    "parameters": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {
            "hypotheses_jsonl": {
                "type": "string",
                "description": (
                    "Path to a JSONL file. Each line: "
                    '{"hypothesis": "...", "id": "..."} (id optional).'
                ),
                "minLength": 1,
            },
        },
        "required": ["hypotheses_jsonl"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "total": {"type": "integer"},
            "proved": {"type": "integer"},
            "failed": {"type": "integer"},
            "results": {"type": "array"},
        },
    },
}


_LIST_TEMPLATES_SCHEMA: dict[str, Any] = {
    "name": "list_pythia_templates",
    "_pending": "ATH-1315",
    "description": (
        "List every shipped Pythia template the matcher recognizes. "
        "Use this when you want to know which hypothesis phrasings will "
        "hit a deterministic template (fast, no LLM cost) before calling "
        "`simple_prove_template`. Returns an array of template ID strings. "
        "Call this first to check coverage before falling back to LLM autoformalization."
    ),
    "parameters": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {},
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "array",
        "items": {"type": "string"},
    },
}


# ATH-719 (kairos certify) is not yet shipped — schema sketched here
# so PR #2 (MCP transport) can wire it the moment certify lands.
_CERTIFY_SCHEMA: dict[str, Any] = {
    "name": "certify",
    "description": (
        "Run the 8-check LLM-defensive certification audit against a "
        "Lean source file. Use this when you have a proof that lean_verify "
        "accepted but you want to catch LLM-generated unsoundness "
        "(vacuous truth, smuggled axioms, hallucinated lemmas, spec drift). "
        "Returns a structured PASS/WARN/FAIL verdict per check + an "
        "aggregate. Pending ATH-719."
    ),
    "parameters": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {
            "lean_path": {
                "type": "string",
                "description": "Path to the .lean file to certify.",
                "minLength": 1,
            },
        },
        "required": ["lean_path"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "aggregate_verdict": {
                "type": "string",
                "enum": ["PASS", "WARN", "FAIL"],
            },
            "checks": {"type": "array"},
        },
    },
    "_pending": "ATH-719",
}


_LEAN_VERIFY_SCHEMA: dict[str, Any] = {
    "name": "lean_verify",
    "description": (
        "Use this when: you have raw Lean 4 source code and want to know whether it "
        "type-checks (compiles cleanly with no sorry). This is the low-level single-file "
        "verification primitive -- use it in refinement loops where you emit Lean, check, "
        "and fix errors iteratively. Prefer simple_prove_template when starting from "
        "natural language, and lean_race/lean_solve when you want multi-drafter parallel "
        "attempts. Returns compiles (bool), has_sorry (bool), errors (string array), "
        "and score. Included; no license required."
    ),
    "parameters": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {
            "code": {
                "type": "string",
                "description": (
                    "Full Lean 4 source — typically `import …` lines "
                    "followed by a `theorem name : type := proof`."
                ),
                "minLength": 1,
            },
            "lake_project": {
                "type": ["string", "null"],
                "description": (
                    "Absolute path to the Lake project root. REQUIRED "
                    "when the proof imports Mathlib or any external "
                    "package. When null, runs in bare-file mode (only "
                    "core Lean stdlib resolves)."
                ),
                "default": None,
            },
            "module_path": {
                "type": ["string", "null"],
                "description": (
                    "Lake-mode module path (dot-separated, mapped to "
                    "the file location). Both lake_project AND "
                    "module_path must be set for lake mode."
                ),
                "default": None,
            },
            "timeout_seconds": {
                "type": "integer",
                "description": "Per-call lake timeout. Default 600.",
                "default": 600,
                "minimum": 1,
                "maximum": 7200,
            },
        },
        "required": ["code"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "compiles": {"type": "boolean"},
            "has_sorry": {"type": "boolean"},
            "sorry_count": {"type": "integer"},
            "score": {"type": "number"},
            "errors": {"type": "array", "items": {"type": "string"}},
            "banned": {"type": ["string", "null"]},
        },
        "required": ["compiles", "errors"],
    },
}


_LEAN_CHECK_SIGNATURE_SCHEMA: dict[str, Any] = {
    "name": "lean_check_signature",
    "description": (
        "Use this when: you have a Lean 4 theorem STATEMENT (type signature) and want "
        "to verify it parses and type-checks BEFORE attempting a proof. Builds a sorry-stub "
        "internally. Call this to reject malformed sub-goals cheaply before committing LLM "
        "tokens to lean_verify or lean_race. WARNING: when lake_project is null, the tool "
        "returns ok=true + skipped=true (cannot resolve imports without a project). Always "
        "check the 'skipped' field. Included."
    ),
    "parameters": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {
            "stmt": {
                "type": "string",
                "description": (
                    "The Lean type expression to check (right-hand "
                    "side of `:`). e.g. `∀ (x : ℝ), x^2 ≥ 0`."
                ),
                "minLength": 1,
            },
            "imports": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Lean imports to prepend (e.g. ['Mathlib']).",
                "default": [],
            },
            "opens": {
                "type": "array",
                "items": {"type": "string"},
                "description": "`open` namespaces to prepend.",
                "default": [],
            },
            "lake_project": {
                "type": ["string", "null"],
                "description": (
                    "Absolute path to the Lake project root. REQUIRED "
                    "for Mathlib-using statements (bare-file lean "
                    "can't resolve `import Mathlib`). When null, the "
                    "tool returns ok=true + skipped=true."
                ),
                "default": None,
            },
            "timeout_seconds": {
                "type": "integer",
                "description": "Per-check lake timeout. Default 60.",
                "default": 60,
                "minimum": 1,
                "maximum": 600,
            },
        },
        "required": ["stmt"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "ok": {"type": "boolean"},
            "errors": {"type": "array", "items": {"type": "string"}},
            "skipped": {"type": "boolean"},
        },
        "required": ["ok", "errors", "skipped"],
    },
}


_NKI_VERIFY_SCHEMA: dict[str, Any] = {
    "name": "nki_verify",
    "description": (
        "Use this when: you have an AWS Neuron NKI kernel bundle (a "
        "directory containing verify.py + kernel.py + optionally "
        "reports/*.json) and want a structured pass/fail verdict for "
        "the kernel against its property tests + fuzz + mutation "
        "harness. Wraps NeuronNKIPlugin.verify (kairos.verticals."
        "neuron_nki) — runs the bundle's verify.py, parses any report "
        "JSONs (test_report, fuzz_report, mutation_report, summary), "
        "and returns a Verdict-shaped dict. Included."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "bundle_path": {
                "type": "string",
                "description": (
                    "Absolute or cwd-relative path to a directory "
                    "containing verify.py + kernel.py. Reports are "
                    "expected under <bundle_path>/reports/ if present."
                ),
            },
            "timeout_sec": {
                "type": "integer",
                "default": 300,
                "minimum": 1,
                "maximum": 3600,
                "description": (
                    "Wall-clock timeout for verify.py invocation. On "
                    "timeout the verdict is outcome='unknown' with "
                    "details.timed_out=True."
                ),
            },
        },
        "required": ["bundle_path"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "outcome": {
                "type": "string",
                "enum": ["proved", "refuted", "unknown", "error"],
            },
            "source": {"type": "string", "const": "nki_kernel"},
            "reason": {"type": "string"},
            "details": {"type": "object"},
        },
        "required": ["outcome", "source", "reason"],
    },
}


_KAIROS_SMOKE_VALIDATION_SCHEMA: dict[str, Any] = {
    "name": "kairos_smoke_validation",
    "description": (
        "Use this when: you have an RTL bundle and want to mechanically "
        "validate it's fire-ready BEFORE spending LLM tokens on "
        "kairos_optimize_block. Runs a 3-step pipeline: "
        "yosys-elaborate (catches SV-construct blockers EBMC's parser "
        "doesn't handle) + ebmc-parse-only (catches post-elaboration "
        "parser drift) + identity-equivalence BMC at depth k (proves "
        "the gold→elaborated→parsed pipeline preserves semantics). "
        "Base SDK (no LLM, no token spend) — exactly the on-ramp to "
        "the paid kairos_optimize_block. If smoke FAILs, fix the "
        "bundle first; do NOT fire the optimizer."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "bundle_path": {
                "type": "string",
                "description": (
                    "Directory containing inputs/ (RTL files) and "
                    "optionally signature.json (port contract + "
                    "dep_files manifest per ATH-1074)."
                ),
            },
            "top_module": {
                "type": "string",
                "description": (
                    "Top-level module name. When omitted, derived "
                    "from signature.json's gold_module / target_module "
                    "field (or falls back to bundle directory basename)."
                ),
            },
            "bound_default": {
                "type": "integer",
                "default": 32,
                "minimum": 1,
                "maximum": 256,
                "description": (
                    "Starting k for identity-equiv ladder. Default 32 "
                    "per Aidan k-bound fleet directive."
                ),
            },
            "bound_ladder": {
                "type": "array",
                "items": {"type": "integer"},
                "default": [32, 64, 128],
                "description": (
                    "Retry ladder of k values. Smoke iterates until "
                    "PROVED at some rung or exhausts the ladder."
                ),
            },
            "fail_fast": {
                "type": "boolean",
                "default": True,
                "description": (
                    "Stop pipeline on first hard FAIL. When false, "
                    "continues + aggregates so engineer sees the full "
                    "failure picture in one shot."
                ),
            },
            "timeout_sec_per_step": {
                "type": "integer",
                "default": 60,
                "minimum": 10,
                "maximum": 600,
                "description": "Per-step subprocess timeout in seconds.",
            },
        },
        "required": ["bundle_path"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "smoke_version": {"type": "string"},
            "bundle_path": {"type": "string"},
            "top_module": {"type": "string"},
            "overall": {"type": "string", "enum": ["PASS", "FAIL"]},
            "elapsed_sec_total": {"type": "number"},
            "steps": {
                "type": "object",
                "properties": {
                    "yosys_elaborate": {"type": "object"},
                    "ebmc_parse_only": {"type": "object"},
                    "identity_equivalence": {"type": "object"},
                },
            },
            "remediation": {"type": ["string", "null"]},
        },
        "required": ["overall", "steps", "smoke_version"],
    },
}



# ATH-1085: best-variant selector for compound optimization
_KAIROS_SELECT_BEST_DESIGN_SCHEMA: dict[str, Any] = {
    "name": "kairos_select_best_design",
    "description": (
        "Use this when: a compound optimization has completed multiple "
        "rounds and you want to identify the BEST variant. Selects the "
        "variant with the lowest cell count among those that are PROVED "
        "EQUIVALENT (not just the last round). Returns the selected "
        "variant plus an honest report showing all variants and why the "
        "best was chosen. Use after kairos_optimize_block or kairos_optimize "
        "when running compound (multi-round) optimization. Included; "
        "no license required."
    ),
    "parameters": {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "type": "object",
        "properties": {
            "iteration_summaries": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "iteration_index": {"type": "integer"},
                        "outcome": {
                            "type": "string",
                            "enum": ["accepted", "refuted", "inconclusive", "errored"],
                        },
                        "gold_cells": {"type": ["integer", "null"]},
                        "gate_cells": {"type": ["integer", "null"]},
                        "measured_delta_pct": {"type": ["number", "null"]},
                        "claimed_area_delta_pct": {"type": ["number", "null"]},
                        "transformation_class": {"type": "string"},
                        "property_verdicts": {
                            "type": "object",
                            "additionalProperties": {"type": "string"},
                        },
                    },
                },
                "description": (
                    "Array of iteration summary dicts from compound "
                    "optimization rounds. Each dict must have at least "
                    "outcome and iteration_index fields. Pass the full "
                    "iteration_summaries from ClosedLoopResult."
                ),
            },
        },
        "required": ["iteration_summaries"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "best_variant": {
                "type": ["object", "null"],
                "description": (
                    "The selected best variant summary dict, or null "
                    "when no proved-equivalent variant exists."
                ),
            },
            "report": {
                "type": "string",
                "description": (
                    "Honest plain-text report showing all variants with "
                    "their outcomes, cell counts, and why the best was "
                    "chosen."
                ),
            },
            "n_proved": {
                "type": "integer",
                "description": "Number of proved-equivalent variants.",
            },
            "n_total": {
                "type": "integer",
                "description": "Total number of variants evaluated.",
            },
        },
        "required": ["best_variant", "report", "n_proved", "n_total"],
    },
}


KAIROS_TOOL_SCHEMAS: dict[str, dict[str, Any]] = {
    "simple_prove_template": _SIMPLE_PROVE_SCHEMA,
    "dispatch": _DISPATCH_SCHEMA,
    "verify_batch": _VERIFY_BATCH_SCHEMA,
    "list_pythia_templates": _LIST_TEMPLATES_SCHEMA,
    "certify": _CERTIFY_SCHEMA,
    "lean_verify": _LEAN_VERIFY_SCHEMA,
    "lean_check_signature": _LEAN_CHECK_SIGNATURE_SCHEMA,
    "nki_verify": _NKI_VERIFY_SCHEMA,
    # ATH-1077 Phase B: included mechanical validation (no LLM).
    "kairos_smoke_validation": _KAIROS_SMOKE_VALIDATION_SCHEMA,
    "kairos_doctor": {
        "name": "kairos_doctor",
        "description": (
            "Run the kairos environment health check. Use this when: you want "
            "to verify the customer's environment is set up correctly before "
            "running any kairos command. Checks: Python version, license, "
            "yosys/EBMC binaries, LLM provider credentials, trace sink routing. "
            "Returns per-check pass/fail/skip with actionable messages."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "live_ping": {
                    "type": "boolean",
                    "description": "If true, ping LLM providers to verify credentials (slower but more thorough)",
                    "default": False,
                },
            },
        },
        "result_schema": {
            "type": "object",
            "properties": {
                "summary": {"type": "string"},
                "all_passed": {"type": "boolean"},
                "checks": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "status": {"type": "string"},
                            "message": {"type": "string"},
                        },
                    },
                },
            },
        },
    },
    "kairos_list_models": {
        "name": "kairos_list_models",
        "description": (
            "List all LLM models available in the current environment. Use this "
            "when: you need to know which models the customer can call before "
            "selecting a model for optimize, prove, or race. Returns only models "
            "whose provider check passes (configured credentials + reachable endpoint). "
            "Fast and offline-safe (no network calls)."
        ),
        "parameters": {
            "type": "object",
            "properties": {},
        },
        "result_schema": {
            "type": "object",
            "properties": {
                "models": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "provider": {"type": "string"},
                            "model": {"type": "string"},
                            "backend": {"type": "string"},
                        },
                    },
                },
                "count": {"type": "integer"},
            },
        },
    },
    "kairos_explain_refute": {
        "name": "kairos_explain_refute",
        "description": (
            "Parse a raw EBMC counterexample trace into structured JSON. "
            "Use this when: a verification returned REFUTED and you need "
            "to understand WHY. Returns the divergence cycle, divergent "
            "signals with gold vs gate values, and suggested fixes. "
            "Included; no license required."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "counterexample_text": {
                    "type": "string",
                    "description": "Raw EBMC counterexample trace text",
                },
                "property_name": {
                    "type": ["string", "null"],
                    "description": "Name of the refuted property",
                    "default": None,
                },
                "gold_module": {
                    "type": ["string", "null"],
                    "description": "Gold-side module name (for signal matching)",
                    "default": None,
                },
                "gate_module": {
                    "type": ["string", "null"],
                    "description": "Gate-side module name (for signal matching)",
                    "default": None,
                },
            },
            "required": ["counterexample_text"],
        },
        "result_schema": {
            "type": "object",
            "properties": {
                "divergence_cycle": {"type": ["integer", "null"]},
                "divergent_signals": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "signal": {"type": "string"},
                            "cycle": {"type": "string"},
                            "gold_value": {"type": "string"},
                            "gate_value": {"type": "string"},
                        },
                    },
                },
                "property_name": {"type": ["string", "null"]},
                "total_cycles": {"type": ["integer", "null"]},
                "summary": {"type": "string"},
                "suggested_fixes": {"type": "array", "items": {"type": "string"}},
            },
        },
    },
    "kairos_plan_optimization": {
        "name": "kairos_plan_optimization",
        "description": (
            "Generate a staged optimization plan for an RTL block. "
            "Use this when: you want to know WHAT optimizations are possible "
            "and HOW LIKELY they are to succeed BEFORE running optimize. "
            "Returns stages ordered by confidence: easy transformations first "
            "(constant prop, 90%), then harder ones (datapath rewrite, 25%). "
            "Customer agent picks ambition level. Included."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "block_name": {"type": "string", "default": "unknown"},
                "block_class": {
                    "type": "string",
                    "description": "fifo, combinational_alu, combinational, generic",
                    "default": "generic",
                },
                "is_combinational": {"type": "boolean", "default": False},
                "encoding": {
                    "type": ["string", "null"],
                    "description": "Detected encoding: onehot, binary, gray, or null",
                    "default": None,
                },
                "signature_path": {
                    "type": ["string", "null"],
                    "description": "Path to signature.json (auto-reads block metadata)",
                    "default": None,
                },
            },
        },
        "result_schema": {
            "type": "object",
            "properties": {
                "block_name": {"type": "string"},
                "block_class": {"type": "string"},
                "total_stages": {"type": "integer"},
                "stages": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "stage": {"type": "integer"},
                            "name": {"type": "string"},
                            "confidence_pct": {"type": "integer"},
                            "estimated_area_delta_pct": {"type": "number"},
                            "requires_hints": {"type": "boolean"},
                            "description": {"type": "string"},
                        },
                    },
                },
            },
        },
    },
    "kairos_formal_explore": {
        "name": "kairos_formal_explore",
        "description": (
            "Assess EBMC formal verification capabilities for a given technique. "
            "Use this when: the customer asks 'can I use X for verification?' "
            "(e.g., uninterpreted functions, Burch-Dill flushing, CEGAR, "
            "k-induction, assume-guarantee). Returns per-capability supported/not "
            "with EBMC mechanisms, limitations, alternatives, and Lean theorem refs. "
            "Included."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Natural language question about formal verification capabilities",
                },
            },
            "required": ["query"],
        },
        "result_schema": {
            "type": "object",
            "properties": {
                "query": {"type": "string"},
                "summary": {"type": "string"},
                "capabilities": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "supported": {"type": "boolean"},
                            "ebmc_mechanism": {"type": ["string", "null"]},
                            "limitations": {"type": ["string", "null"]},
                            "alternative": {"type": ["string", "null"]},
                            "lean_theorem_ref": {"type": ["string", "null"]},
                        },
                    },
                },
                "references": {"type": "array", "items": {"type": "string"}},
            },
        },
    },
    "kairos_recall": {
        "name": "kairos_recall",
        "description": (
            "Recall past optimization history for a block. Returns refutation "
            "patterns, success records, and synthesis floor confidence. "
            "Use this when: your agent wants to check what kairos already "
            "tried on a block before proposing new optimizations. "
            "Included — no LLM cost."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "block_path": {
                    "type": "string",
                    "description": "Path to the gold RTL file (.v or .sv)",
                },
            },
            "required": ["block_path"],
        },
        "result_schema": {
            "type": "object",
            "properties": {
                "block_hash": {"type": "string"},
                "refutation_count": {"type": "integer"},
                "success_count": {"type": "integer"},
                "synthesis_floor_confidence": {"type": "number"},
                "is_at_floor": {"type": "boolean"},
                "refutation_patterns": {
                    "type": "array",
                    "items": {"type": "string"},
                },
                "proposer_context": {"type": "string"},
            },
        },
    },
    # ATH-1085: best-variant selector for compound optimization.
    "kairos_select_best_design": _KAIROS_SELECT_BEST_DESIGN_SCHEMA,
}


# ─── Paid-tier schemas (ATH-829 Phase 1) ──────────────────────────────
#
# These describe the paid orchestration tools. The MCP server registers
# them only after a successful license-scope check for the "solve" product
# at startup (see `kairos.mcp.pro_extensions`). Base SDK customers
# never see these in their MCP tool listing.
#
# Schemas live here (import-fence safe — pure JSON Schema, no paid
# imports) so they can be exposed via `KAIROS_PAID_TOOL_SCHEMAS` for
# documentation / discovery / function-calling clients regardless of
# whether the runtime tools are licensed.

_LEAN_RACE_SCHEMA: dict[str, Any] = {
    "name": "lean_race",
    "description": (
        "Use this when: simple_prove_template didn't close your Lean "
        "target AND you have multiple drafters available. Races N "
        "drafters in parallel; first axiom-clean closure wins. "
        "Returns RaceResult with per-drafter outcomes for introspection. "
        "Paid tier (requires `solve` product license)."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "target_id": {
                "type": "string",
                "description": "Stable identifier for the target (used in trace events).",
            },
            "imports": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Lean module imports to prepend to the candidate.",
            },
            "opens": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Lean `open` namespaces to prepend after imports.",
            },
            "header": {
                "type": "string",
                "description": "Theorem signature ending before `:= `, e.g. `theorem foo (x : Nat) : x + 0 = x`.",
            },
            "lake_project": {
                "type": "string",
                "description": "Absolute or cwd-relative path to a Lake project (must contain lakefile).",
            },
            "module_path": {
                "type": "string",
                "description": "Dotted Lean module path under the scratch namespace, e.g. `Pythia.Scratch.MyTarget`.",
            },
            "drafters": {
                "type": "array",
                "items": {
                    "type": "string",
                    "description": (
                        "Model ID string. Valid values: "
                        "\"anthropic/claude-sonnet-4-6\", "
                        "\"anthropic/claude-opus-4-6\", "
                        "\"anthropic/claude-haiku-4-5\", "
                        "\"gemini/gemini-3-flash-preview\". "
                        "Pass 1-5 drafters for parallel racing."
                    ),
                },
                "description": "List of model IDs to race in parallel.",
            },
            "max_rounds": {
                "type": "integer",
                "default": 4,
                "description": "Per-drafter max refinement rounds.",
            },
            "temperature": {
                "type": "number",
                "default": 0.0,
                "description": "Sampling temperature for the first round.",
            },
            "max_tokens": {
                "type": "integer",
                "default": 800,
                "description": "Max output tokens per drafter call.",
            },
        },
        "required": ["target_id", "imports", "opens", "header", "lake_project", "module_path", "drafters"],
    },
    "_paid": True,
    "_product": "solve",
}


_LEAN_SOLVE_SCHEMA: dict[str, Any] = {
    "name": "lean_solve",
    "description": (
        "Use this when: you want kairos to handle the cheap-first → "
        "race → decompose flow without your having to wire it. Tries "
        "simple_prove_template first, escalates to lean_race, and on "
        "race-fail returns structured `decompose_hints` so YOUR outer "
        "agent can drive the next decomposition step using its own "
        "context (file state, Mathlib hints, prior failures). Set "
        "`internal_planner_model` to opt into kairos calling a planner "
        "internally instead. Paid tier (requires `solve` product license)."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "target_id": {"type": "string"},
            "imports": {"type": "array", "items": {"type": "string"}},
            "opens": {"type": "array", "items": {"type": "string"}},
            "header": {"type": "string"},
            "lake_project": {"type": "string"},
            "module_path": {"type": "string"},
            "drafters": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Model ID strings to use as drafters. Valid: "
                    "\"anthropic/claude-sonnet-4-6\", "
                    "\"anthropic/claude-opus-4-6\", "
                    "\"anthropic/claude-haiku-4-5\", "
                    "\"gemini/gemini-3-flash-preview\"."
                ),
            },
            "internal_planner_model": {
                "type": ["string", "null"],
                "default": None,
                "description": (
                    "Set when your outer agent ISN'T Opus and you want kairos "
                    "to bring its own planner. e.g. 'anthropic/claude-opus-4-6'. "
                    "Default null — kairos hands decompose_hints back to your "
                    "outer agent (the agent-as-Opus default flow)."
                ),
            },
            "try_simple_prove_first": {
                "type": "boolean",
                "default": True,
                "description": "Try the cheap base-SDK path before racing drafters.",
            },
            "max_rounds": {"type": "integer", "default": 4},
            "n_per_drafter": {"type": "integer", "default": 10},
            "temperature": {"type": "number", "default": 0.7},
            "max_tokens": {"type": "integer", "default": 800},
        },
        "required": ["target_id", "imports", "opens", "header", "lake_project", "module_path", "drafters"],
    },
    "_paid": True,
    "_product": "solve",
}


_SV_PROVE_SCHEMA: dict[str, Any] = {
    "name": "sv_prove",
    "description": "Run EBMC bounded model checking or k-induction on SystemVerilog properties. Use this when you have an SV design with inline SVA assertions and want a formal proof or counterexample. Supports multi-file designs, struct flattening, and IC3/BDD engines. Returns per-property proved/refuted/unknown verdicts.",
    "parameters": {
        "type": "object",
        "properties": {
            "sv_file": {"type": ["string", "array"], "description": "Path(s) to SV source files."},
            "top_module": {"type": "string", "description": "Top module name for EBMC."},
            "bound": {"type": "integer", "default": 10, "description": "BMC depth / k-induction cap."},
            "mode": {"type": "string", "enum": ["bmc", "k_induction", "ic3", "bdd"], "default": "bmc"},
            "reset_expr": {"type": ["string", "null"], "default": None, "description": "Reset signal expression."},
            "timeout_sec": {"type": "integer", "default": 60},
            "extra_args": {"type": ["array", "null"], "items": {"type": "string"}, "default": None},
            "flatten": {"type": "boolean", "default": False, "description": "Preprocess through SV struct flattener."},
        },
        "required": ["sv_file", "top_module"],
    },
    "_paid": True,
    "_product": "solve",
}

_SV_CEGAR_SCHEMA: dict[str, Any] = {
    "name": "sv_cegar",
    "description": "Run the CEGAR invariant-discovery loop on a SystemVerilog design. Use this when EBMC k-induction alone cannot close a property and you need automatically discovered assume-property constraints. LLM proposes candidates, EBMC checks each, vacuity + progress gates filter trivial ones. Returns verified invariants plus per-iteration diagnostics.",
    "parameters": {
        "type": "object",
        "properties": {
            "spec": {"type": "string", "description": "Path to the SV spec file."},
            "top_module": {"type": "string"},
            "bound": {"type": "integer", "default": 10},
            "max_iter": {"type": "integer", "default": 5},
            "budget_usd": {"type": "number", "default": 5.0},
            "walltime_sec": {"type": "integer", "default": 600},
            "auto_accept_environmental": {"type": "boolean", "default": False},
            "extra_files": {"type": ["array", "null"], "items": {"type": "string"}, "default": None},
            "flatten": {"type": "boolean", "default": False},
        },
        "required": ["spec", "top_module"],
    },
    "_paid": True,
    "_product": "solve",
}

_SV_FLATTEN_SCHEMA: dict[str, Any] = {
    "name": "sv_flatten",
    "description": "Preprocess SystemVerilog files for EBMC compatibility. Use this when EBMC's parser rejects packed structs, SVA temporal operators, or generate-for blocks. Applies struct-to-bitvector flattening, SVA rewriting, loop-var dedup, procedural-var hoisting, and generate-for unrolling. Returns paths to flattened output files.",
    "parameters": {
        "type": "object",
        "properties": {
            "paths": {"type": "array", "items": {"type": "string"}, "description": "SV source file paths."},
            "output_dir": {"type": ["string", "null"], "default": None, "description": "Write flattened files here."},
        },
        "required": ["paths"],
    },
    "_paid": True,
    "_product": "solve",
}

_EBMC_VERIFY_SCHEMA: dict[str, Any] = {
    "name": "ebmc_verify",
    "description": "Run a single atomic EBMC verification subprocess and return a structured result. Use this when you need fine-grained control over one EBMC invocation (vs sv_prove which raises on refutation, or ebmc_solve which cascades strategies). Returns per-property verdicts + counterexample traces + subprocess logs.",
    "parameters": {
        "type": "object",
        "properties": {
            "rtl_file": {"type": ["string", "array"], "description": "Path(s) to SV source."},
            "top_module": {"type": "string"},
            "bound": {"type": "integer", "default": 10},
            "mode": {"type": "string", "enum": ["bmc", "k_induction", "ic3", "bdd"], "default": "bmc"},
            "reset_expr": {"type": ["string", "null"], "default": None},
            "timeout_sec": {"type": "integer", "default": 60},
            "flatten": {"type": "boolean", "default": False},
        },
        "required": ["rtl_file", "top_module"],
    },
    "_paid": True,
    "_product": "solve",
}

_EBMC_SOLVE_SCHEMA: dict[str, Any] = {
    "name": "ebmc_solve",
    "description": "Run the EBMC orchestration cascade: BMC first, escalates to k-induction if inconclusive, returns decompose hints when nothing closes. Use this when you want kairos to automatically try progressively stronger strategies without manual escalation. Returns structured result with proof path taken and decompose_hints for the next step.",
    "parameters": {
        "type": "object",
        "properties": {
            "rtl_file": {"type": ["string", "array"]},
            "top_module": {"type": "string"},
            "bound": {"type": "integer", "default": 10},
            "reset_expr": {"type": ["string", "null"], "default": None},
            "timeout_sec": {"type": "integer", "default": 300},
            "flatten": {"type": "boolean", "default": False},
        },
        "required": ["rtl_file", "top_module"],
    },
    "_paid": True,
    "_product": "solve",
}

_ACL2_VERIFY_SCHEMA: dict[str, Any] = {
    "name": "acl2_verify",
    "description": "Run an ACL2 proof script and verify theorems. Use this when the target is an unbounded refinement proof on OoO/pipelined hardware where ACL2's rewrite-based prover outperforms Lean's tactic engine. Returns Q.E.D. count, proved/failed theorem lists, and full ACL2 transcript.",
    "parameters": {
        "type": "object",
        "properties": {
            "script": {"type": "string", "description": "Path to ACL2 .lisp proof script."},
            "theorems": {"type": ["array", "null"], "items": {"type": "string"}, "description": "Expected theorem names."},
            "timeout_sec": {"type": "integer", "default": 300},
        },
        "required": ["script"],
    },
    "_paid": True,
    "_product": "solve",
}

_NKI_PORT_SCHEMA: dict[str, Any] = {
    "name": "nki_port",
    "description": (
        "Use this when: you have a CUDA / Triton / PyTorch reference "
        "kernel and want kairos to port it to AWS Neuron NKI with the "
        "verifier-loop in place (property tests + fuzz + mutation + "
        "Lean disclosure). Drives the foundry orchestrator that "
        "produces a kernel bundle compatible with nki_verify. Bundles "
        "land under solve/neuron/catalog/<date>/<kernel>/ on the "
        "athanor-builder side. Paid tier (requires `solve` product "
        "license)."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "kernel_name": {
                "type": "string",
                "description": (
                    "Stable identifier for the kernel (used as the "
                    "catalog directory name and trace target_id)."
                ),
            },
            "reference_source": {
                "type": "string",
                "description": (
                    "Source code of the reference kernel (CUDA, "
                    "Triton, or PyTorch). The orchestrator uses this "
                    "as the equivalence reference for differential "
                    "testing."
                ),
            },
            "reference_dialect": {
                "type": "string",
                "enum": ["cuda", "triton", "pytorch"],
                "description": "Dialect of the reference source.",
            },
            "intent_summary": {
                "type": "string",
                "description": (
                    "One-sentence customer intent. Routed to the LLM "
                    "porter as the goal description."
                ),
            },
            "max_rounds": {
                "type": "integer",
                "default": 4,
                "minimum": 1,
                "maximum": 16,
                "description": (
                    "Per-builder max refinement rounds inside the "
                    "foundry loop."
                ),
            },
            "timeout_sec": {
                "type": "integer",
                "default": 1800,
                "minimum": 60,
                "maximum": 7200,
                "description": "Wall-clock budget for the whole port loop.",
            },
        },
        "required": ["kernel_name", "reference_source", "reference_dialect", "intent_summary"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "bundle_path": {"type": "string"},
            "verdict": {
                "type": "object",
                "description": "Final NeuronNKIPlugin.verify Verdict on the produced bundle.",
            },
            "rounds_used": {"type": "integer"},
            "logs_path": {"type": "string"},
        },
        "required": ["bundle_path", "verdict"],
    },
    "_paid": True,
    "_product": "solve",
}


# ─── ATH-1063 closed-loop area-optimization tools ─────────────────────
#
# Five tools that wrap kairos.sec.closed_loop + kairos.cert + kairos.synth
# into MCP-callable shape for engineer-as-customer dogfood per Aidan
# 2026-05-06 two-birds directive.
#
# kairos_optimize_block is the coarse default (one call, full closed-loop
# arc, returns iteration arc + cert + dashboard URL). The four others are
# fine primitives that compose into partial workflows.
#
# Same-LLM constraint per Aidan / the customer's engineer: the model that proposes a
# transformation also writes the bridge invariants for that transformation.
# Soundness-rule (same model class + session/context end-to-end).
# kairos_propose + kairos_verify_equivalence enforce this when called
# separately by checking the model_id against the proposer's recorded model.


_KAIROS_OPTIMIZE_BLOCK_SCHEMA: dict[str, Any] = {
    "name": "kairos_optimize_block",
    "description": (
        "Use this when: you have an RTL block (a SystemVerilog or "
        "Verilog file) and want kairos to find proven power / area / "
        "timing improvements end-to-end. Drives the closed-loop "
        "iteration arc: LLM proposer suggests interface-preserving "
        "structural transformations, EBMC k-induction with bridge "
        "invariants verifies sequential equivalence on each, yosys "
        "synth pass measures verified gate-count delta, and a cert "
        "tarball mints with the full propose-verify-iterate trace. "
        "The same model that proposes each transformation also writes "
        "the bridge invariants for it (soundness rule). Returns the "
        "iteration arc + cert path + tahoe dashboard URL. Paid tier "
        "(requires `solve` product license)."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "rtl_path": {
                "type": "string",
                "description": (
                    "Path to the gold-side RTL file to optimize. "
                    "Either absolute or relative to the bundle directory."
                ),
            },
            "signature_path": {
                "type": "string",
                "description": (
                    "Path to the signature.json describing the gold "
                    "module's port list, parameters, reset semantics, "
                    "and capacity contract. Generate via "
                    "kairos.sec.signature_gen.generate_signature(rtl_path) "
                    "if you do not have one."
                ),
            },
            "vector": {
                "type": "string",
                "enum": ["gate_count", "area", "power", "timing"],
                "default": "gate_count",
                "description": (
                    "Optimization vector to drive the proposer toward. "
                    "gate_count is the default proxy for power. Power "
                    "and timing are stretch vectors not yet fully wired."
                ),
            },
            "max_iterations": {
                "type": "integer",
                "default": 3,
                "minimum": 1,
                "maximum": 16,
                "description": (
                    "Maximum number of propose-verify rounds. The loop "
                    "halts early if proved_equivalent_variant_found."
                ),
            },
            "model": {
                "type": "string",
                "default": "anthropic/claude-opus-4-6",
                "description": (
                    "Model id used end-to-end for both transformation "
                    "proposing AND bridge invariant writing (same-LLM "
                    "soundness rule). Recommended: claude-opus-4-6 for "
                    "the chief-architect-grade demo."
                ),
            },
            "k_induction_bound": {
                "type": "integer",
                "default": 32,
                "minimum": 4,
                "maximum": 256,
                "description": (
                    "k-induction depth bound. Default 32 per Aidan "
                    "fleet rule 2026-05-07 (`feedback_push_higher_k"
                    "induction_bound`). Higher k = larger reachable-"
                    "state envelope = stronger soundness when k-"
                    "induction closes. Escalation ladder when "
                    "INCONCLUSIVE: try [32, 64, 128] before falling "
                    "back to bridge-invariant generation. Override "
                    "downward only when a customer flag explicitly "
                    "trades soundness for speed."
                ),
            },
            "timeout_sec": {
                "type": "integer",
                "default": 1800,
                "minimum": 60,
                "maximum": 7200,
                "description": "Wall-clock budget for the whole arc.",
            },
        },
        "required": ["rtl_path", "signature_path"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "run_id": {
                "type": "string",
                "description": (
                    "Canonical run_id minted for this iteration arc. "
                    "Use to look up the run in tahoe at "
                    "/analytics/silicon-blocks/[run_id]."
                ),
            },
            "iteration_arc": {
                "type": "array",
                "description": (
                    "Per-iteration row: transformation_class, "
                    "claimed_area_delta_pct, bridge_label, "
                    "bridge_invariant_text, outcome (accepted / "
                    "refuted / inconclusive), verified_gate_count_delta "
                    "(when synth hook ran)."
                ),
                "items": {"type": "object"},
            },
            "halt_reason": {
                "type": "string",
                "enum": [
                    "proved_equivalent_variant_found",
                    "no_proposal_closed",
                    "max_iterations",
                    "human_review_needed",
                ],
            },
            "cert_path": {
                "type": "string",
                "description": "Path to the cert tarball (.tgz).",
            },
            "dashboard_url": {
                "type": "string",
                "description": (
                    "Tahoe URL rendering the iteration arc for "
                    "engineer review."
                ),
            },
        },
        "required": ["run_id", "iteration_arc", "halt_reason"],
    },
    "_paid": True,
    "_product": "solve",
}


_KAIROS_PROPOSE_SCHEMA: dict[str, Any] = {
    "name": "kairos_propose",
    "description": (
        "Use this when: you want the LLM to brainstorm "
        "interface-preserving area-optimization candidates on an RTL "
        "block, without running formal verification yet. Returns a "
        "ranked list of transformation proposals (most-claimed-savings "
        "first) for engineer review. To verify a candidate, call "
        "kairos_verify_equivalence with the same model_id (soundness "
        "rule on bridge invariants). Paid tier."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "rtl_path": {
                "type": "string",
                "description": "Path to the gold-side RTL file.",
            },
            "signature_path": {
                "type": "string",
                "description": "Path to the signature.json for the module.",
            },
            "vector": {
                "type": "string",
                "enum": ["gate_count", "area", "power", "timing"],
                "default": "gate_count",
            },
            "max_proposals": {
                "type": "integer",
                "default": 3,
                "minimum": 1,
                "maximum": 8,
            },
            "model": {
                "type": "string",
                "default": "anthropic/claude-opus-4-6",
                "description": (
                    "Model id. Record it; pass the same model id to "
                    "kairos_verify_equivalence so the same-LLM "
                    "soundness rule holds."
                ),
            },
            "timeout_sec": {
                "type": "integer",
                "default": 120,
                "minimum": 30,
                "maximum": 600,
            },
        },
        "required": ["rtl_path", "signature_path"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "proposals": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "transformation_class": {
                            "type": "string",
                            "enum": ["parameterization", "structural", "impl_swap"],
                        },
                        "transformation_description": {"type": "string"},
                        "proposed_gate_sv": {"type": "string"},
                        "claimed_area_delta_pct": {"type": "number"},
                        "rationale": {"type": "string"},
                    },
                    "required": [
                        "transformation_class",
                        "transformation_description",
                        "proposed_gate_sv",
                    ],
                },
            },
            "model_used": {"type": "string"},
            "session_id": {
                "type": "string",
                "description": (
                    "LLM session identifier; pass this to "
                    "kairos_verify_equivalence to maintain the "
                    "same-session soundness invariant."
                ),
            },
        },
        "required": ["proposals", "model_used"],
    },
    "_paid": True,
    "_product": "solve",
}


_KAIROS_VERIFY_EQUIVALENCE_SCHEMA: dict[str, Any] = {
    "name": "kairos_verify_equivalence",
    "description": (
        "Use this when: you have a gold-side RTL and a proposed "
        "gate-side variant and want kairos to prove sequential "
        "equivalence under bridge invariants. Runs BMC initial verdict, "
        "escalates to k-induction with assume-property bridge "
        "invariants on FAIL, returns proved / refuted / inconclusive "
        "with the EBMC subprocess output captured. The model that "
        "writes the bridge invariants must be the same that proposed "
        "the transformation (soundness rule); pass the model_id and "
        "session_id from the originating kairos_propose call. Paid tier."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "gold_path": {"type": "string"},
            "gate_path": {"type": "string"},
            "signature_path": {"type": "string"},
            "bridge_invariants": {
                "type": "array",
                "items": {"type": "string"},
                "description": (
                    "Optional pre-authored bridge invariants. If "
                    "absent, kairos drives the same-model invariant "
                    "generator (must match proposer model_id)."
                ),
            },
            "proposer_model_id": {
                "type": "string",
                "description": (
                    "Model id from the kairos_propose call that "
                    "produced this candidate. Required for soundness."
                ),
            },
            "proposer_session_id": {
                "type": "string",
                "description": (
                    "Session id from kairos_propose. Maintains the "
                    "same-context invariant for invariant generation."
                ),
            },
            "k_induction_bound": {
                "type": "integer",
                "default": 32,
                "minimum": 4,
                "maximum": 256,
                "description": (
                    "k-induction depth bound. Default 32 per Aidan "
                    "fleet rule 2026-05-07. On INCONCLUSIVE return, "
                    "the orchestrator escalates [32, 64, 128] before "
                    "falling back to bridge-invariant generation."
                ),
            },
            "timeout_sec": {
                "type": "integer",
                "default": 300,
                "minimum": 30,
                "maximum": 1800,
            },
        },
        "required": ["gold_path", "gate_path", "signature_path", "proposer_model_id"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "outcome": {
                "type": "string",
                "enum": ["accepted", "refuted", "inconclusive"],
            },
            "outcome_reason": {"type": "string"},
            "bridge_label": {"type": "string"},
            "bridge_text": {"type": "string"},
            "ebmc_bmc_log_path": {"type": "string"},
            "ebmc_kinduction_log_path": {"type": "string"},
        },
        "required": ["outcome", "outcome_reason"],
    },
    "_paid": True,
    "_product": "solve",
}


_KAIROS_SYNTH_DELTA_SCHEMA: dict[str, Any] = {
    "name": "kairos_synth_delta",
    "description": (
        "Use this when: you have a gold and gate RTL pair and want a "
        "verified gate-count delta from yosys synth + ABC technology "
        "mapping. Returns gate count for both sides plus the synth log "
        "verbatim so the customer can independently reproduce. This is "
        "what flips a cert from `claimed -X%` to `verified -N gates`. "
        "Paid tier."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "gold_path": {"type": "string"},
            "gate_path": {"type": "string"},
            "top_module": {
                "type": "string",
                "description": "Top-level module name (must match in both files).",
            },
            "abc_script": {
                "type": "string",
                "description": (
                    "Optional yosys ABC script. Default: balanced "
                    "synth + map to standard cell library equivalents."
                ),
            },
            "timeout_sec": {
                "type": "integer",
                "default": 300,
                "minimum": 30,
                "maximum": 1800,
            },
        },
        "required": ["gold_path", "gate_path", "top_module"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "gold_gate_count": {"type": "integer"},
            "gate_gate_count": {"type": "integer"},
            "delta_gates": {"type": "integer"},
            "delta_pct": {"type": "number"},
            "synth_log_path": {
                "type": "string",
                "description": (
                    "Path to verbatim yosys + ABC stdout/stderr capture. "
                    "Ships in the cert tarball for customer audit."
                ),
            },
        },
        "required": ["gold_gate_count", "gate_gate_count", "delta_gates", "delta_pct"],
    },
    "_paid": True,
    "_product": "solve",
}


_KAIROS_INSPECT_CERT_SCHEMA: dict[str, Any] = {
    "name": "kairos_inspect_cert",
    "description": (
        "Use this when: an engineer has an existing cert tarball or "
        "bundle directory and wants the structured iteration arc "
        "(transformations, verdicts, bridge invariants, gate-count "
        "deltas) for programmatic reasoning. Returns the same data the "
        "human-readable cert markdown surfaces, but as structured JSON. "
        "Useful for cross-cert comparison, drift audits across runs, "
        "or engineer-agent reasoning over prior iteration arcs. Free "
        "tier (read-only over already-minted certs)."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "cert_path": {
                "type": "string",
                "description": (
                    "Path to a cert tarball (.tgz) or extracted bundle "
                    "directory."
                ),
            },
        },
        "required": ["cert_path"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "properties": {
            "run_id": {"type": "string"},
            "halt_reason": {"type": "string"},
            "iteration_arc": {
                "type": "array",
                "items": {"type": "object"},
            },
            "verdict_mix": {
                "type": "object",
                "properties": {
                    "accepted": {"type": "integer"},
                    "refuted": {"type": "integer"},
                    "inconclusive": {"type": "integer"},
                },
            },
            "bridge_invariants": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "iteration_index": {"type": "integer"},
                        "label": {"type": "string"},
                        "text": {"type": "string"},
                    },
                },
            },
            "live_render_url": {
                "type": "string",
                "description": (
                    "Tahoe URL rendering this run's iteration arc. "
                    "Engineer's agent can hand this back to the engineer "
                    "for visual review without re-running the cert."
                ),
            },
        },
        "required": ["run_id", "iteration_arc", "verdict_mix"],
    },
    "_paid": True,
    "_product": "solve",
}


_KAIROS_MINE_ASSUMPTIONS_SCHEMA: dict[str, Any] = {
    "name": "kairos_mine_assumptions",
    "description": (
        "Use this when: you have an RTL bundle and want to mine structural "
        "SystemVerilog assertions describing operating-mode invariants BEFORE "
        "running the full closed-loop optimization arc. The LLM proposes up to "
        "max_assertions SVA candidates; EBMC Mode 1 (single design, no miter) "
        "verifies each; PROVED assertions join the downstream assumption set "
        "for kairos_optimize_block (as assume property constraints narrowing "
        "EBMC's input space). Inner-retry loop (max_inner_retries) attempts "
        "to revise INCONCLUSIVE assertions before giving up. "
        "Returns AssumptionMiningResult partitioned into proved / refuted / "
        "inconclusive / parse_errors buckets. "
        "Paid tier (LLM calls + EBMC subprocess; requires `solve` license). "
        "ATH-1087 Phase B — schemas + MCP wiring."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "bundle_path": {
                "type": "string",
                "description": (
                    "Directory containing inputs/ (RTL files) and "
                    "signature.json (port contract per ATH-1074). "
                    "signature.json must have gold_sv + clock_port + "
                    "reset_port fields."
                ),
            },
            "target_module": {
                "type": "string",
                "description": (
                    "Top-level module name to mine assertions for. "
                    "Must match the module declaration in the gold RTL."
                ),
            },
            "model": {
                "type": "string",
                "default": "anthropic/claude-opus-4-6",
                "description": (
                    "LLM model id used for assertion proposal + revision. "
                    "Default claude-opus-4-6 for highest-quality SVA proposals. "
                    "Cost scales with max_assertions × max_inner_retries."
                ),
            },
            "max_assertions": {
                "type": "integer",
                "default": 8,
                "minimum": 1,
                "maximum": 32,
                "description": (
                    "Cap on attempted assertions (LLM prompt ceiling). "
                    "Quality over quantity — 4-8 targeted assertions "
                    "outperform 20 weak ones as assume constraints."
                ),
            },
            "max_inner_retries": {
                "type": "integer",
                "default": 2,
                "minimum": 0,
                "maximum": 5,
                "description": (
                    "Cap on inner-retry-with-feedback per INCONCLUSIVE "
                    "assertion. Default 2 per CTO ATH-1089 cost-priced cap. "
                    "On REFUTED no retry (assertion is genuinely wrong)."
                ),
            },
            "k_bound": {
                "type": "integer",
                "default": 32,
                "minimum": 4,
                "maximum": 256,
                "description": (
                    "EBMC Mode 1 BMC bound. Default 32 per Aidan k-bound "
                    "fleet rule 2026-05-07. Higher k = larger reachable-state "
                    "envelope = stronger PROVED witness."
                ),
            },
            "timeout_sec": {
                "type": "integer",
                "default": 60,
                "minimum": 10,
                "maximum": 600,
                "description": "Per-assertion EBMC subprocess timeout in seconds.",
            },
        },
        "required": ["bundle_path", "target_module"],
        "additionalProperties": False,
    },
    "result_schema": {
        "type": "object",
        "description": "AssumptionMiningResult.to_dict() shape.",
        "properties": {
            "bundle_path": {"type": "string"},
            "target_module": {"type": "string"},
            "model": {"type": "string"},
            "max_assertions": {"type": "integer"},
            "max_inner_retries": {"type": "integer"},
            "k_bound": {"type": "integer"},
            "proved": {"type": "array", "items": {"type": "object"}},
            "refuted": {"type": "array", "items": {"type": "object"}},
            "inconclusive": {"type": "array", "items": {"type": "object"}},
            "parse_errors": {"type": "array", "items": {"type": "object"}},
            "elapsed_sec_total": {"type": "number"},
            "timestamp": {"type": "string"},
        },
        "required": [
            "bundle_path", "target_module", "model",
            "proved", "refuted", "inconclusive", "parse_errors",
            "elapsed_sec_total", "timestamp",
        ],
    },
    "_paid": True,
    "_product": "solve",
}


KAIROS_PAID_TOOL_SCHEMAS: dict[str, dict[str, Any]] = {
    "lean_race": _LEAN_RACE_SCHEMA,
    "lean_solve": _LEAN_SOLVE_SCHEMA,
    "sv_prove": _SV_PROVE_SCHEMA,
    "sv_cegar": _SV_CEGAR_SCHEMA,
    "sv_flatten": _SV_FLATTEN_SCHEMA,
    "ebmc_verify": _EBMC_VERIFY_SCHEMA,
    "ebmc_solve": _EBMC_SOLVE_SCHEMA,
    "acl2_verify": _ACL2_VERIFY_SCHEMA,
    "nki_port": _NKI_PORT_SCHEMA,
    "kairos_optimize_block": _KAIROS_OPTIMIZE_BLOCK_SCHEMA,
    "kairos_optimize": {
        "name": "kairos_optimize",
        "description": (
            "Use this when: you want to optimize an RTL block for area "
            "reduction with formal equivalence proof. This is the MAIN "
            "optimization tool — use it instead of kairos_optimize_block. "
            "Accepts either a raw RTL file (auto-detects clock/reset, "
            "builds bundle) or a pre-built bundle directory (with "
            "signature.json). Pass the RTL file path and optional "
            "deps/params. Returns PROVED with area reduction or explains "
            "why optimization was not possible."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "rtl_path": {
                    "type": "string",
                    "description": "Path to the gold RTL file (.v or .sv)",
                },
                "dep_paths": {
                    "type": "string",
                    "description": "Comma-separated paths to dependency RTL files",
                    "default": "",
                },
                "params": {
                    "oneOf": [
                        {"type": "string", "description": "KEY=VAL,KEY=VAL format"},
                        {"type": "object", "description": "JSON object {\"KEY\": VAL}"},
                    ],
                    "description": "Parameter overrides. Pass as JSON object {\"DATA_WIDTH\": 8, \"DEPTH\": 4} or string \"DATA_WIDTH=8,DEPTH=4\"",
                    "default": "",
                },
                "model": {
                    "type": "string",
                    "description": "LLM model for the proposer",
                    "default": "anthropic/claude-sonnet-4-6",
                },
                "max_proposals": {
                    "type": "integer",
                    "description": "Number of optimization candidates to generate",
                    "default": 3,
                },
                "timeout_sec": {
                    "type": "integer",
                    "description": "Per-engine verification timeout in seconds",
                    "default": 1800,
                },
            },
            "required": ["rtl_path"],
        },
        "_paid": True,
        "_product": "solve",
    },
    "kairos_advise_flow": {
        "name": "kairos_advise_flow",
        "description": "Validate a proposed kairos flow configuration before execution. Use this when you have assembled a JSON config dict (engine selection, model routing, bound parameters, timeout budgets) and want a pre-flight check before committing to a paid run. Returns valid/invalid with specific suggestions for misconfigured or missing fields.",
        "parameters": {
            "type": "object",
            "properties": {
                "config": {"type": "string", "description": "JSON config dict", "default": "{}"},
                "prompt": {"type": "string", "description": "Prompt text to validate", "default": ""},
            },
        },
        "_paid": True,
        "_product": "solve",
    },
    "kairos_propose": _KAIROS_PROPOSE_SCHEMA,
    "kairos_verify_equivalence": _KAIROS_VERIFY_EQUIVALENCE_SCHEMA,
    "kairos_synth_delta": _KAIROS_SYNTH_DELTA_SCHEMA,
    "kairos_inspect_cert": _KAIROS_INSPECT_CERT_SCHEMA,
    # ATH-1087 Phase B: paid-tier assumption mining (LLM + EBMC).
    "kairos_mine_assumptions": _KAIROS_MINE_ASSUMPTIONS_SCHEMA,
    "kairos_verify": {
        "name": "kairos_verify",
        "description": (
            "Verify Python code quality across all layers: types (mypy), "
            "properties (AST), symbolic exec (taint/null/div-zero), drift "
            "(security), and spec consistency. Returns quality score + "
            "actionable findings. Use --only to run a subset of layers."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["path"],
            "properties": {
                "path": {"type": "string", "description": "File or directory to verify"},
                "only": {"type": "string", "description": "Comma-separated layers: types,properties,symbolic,mutation,drift,specs"},
            },
        },
    },
    "kairos_repair": {
        "name": "kairos_repair",
        "description": (
            "Find + fix + verify. Auto-detects file type: .py → code repair, "
            ".lean → sorry closure, directory → batch parallel repair. "
            "Returns findings + fixes applied + verification status."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["path"],
            "properties": {
                "path": {"type": "string", "description": "File or directory to repair"},
                "fix": {"type": "boolean", "description": "Apply fixes (default: true)", "default": True},
                "focus": {"type": "string", "description": "Focus area: security, correctness, style"},
            },
        },
    },
    "kairos_explore": {
        "name": "kairos_explore",
        "description": (
            "Explore a codebase or RTL design. Discovers structure, "
            "dependencies, and optimization opportunities. Read-only."
        ),
        "inputSchema": {
            "type": "object",
            "required": ["path"],
            "properties": {
                "path": {"type": "string", "description": "File or directory to explore"},
            },
        },
    },
}


# ─── Format conversions ───────────────────────────────────────────────


def export_schemas() -> dict[str, dict[str, Any]]:
    """Return the canonical schema dict, unmodified.

    Suitable for serializing as the response to MCP's `tools/list` (PR #2),
    or as a documentation artifact.
    """
    return {k: dict(v) for k, v in KAIROS_TOOL_SCHEMAS.items()}


def openai_tools(*, include_pending: bool = False) -> list[dict[str, Any]]:
    """Return the OpenAI Chat Completions function-calling shape.

    Set `include_pending=True` to include tools whose backend hasn't
    shipped yet (e.g. `certify`, pending ATH-719). Default False so
    agents don't try to call non-existent tools.
    """
    out: list[dict[str, Any]] = []
    for name, schema in KAIROS_TOOL_SCHEMAS.items():
        if not include_pending and "_pending" in schema:
            continue
        out.append({
            "type": "function",
            "function": {
                "name": schema["name"],
                "description": schema["description"],
                "parameters": schema["parameters"],
            },
        })
    return out


def anthropic_tools(*, include_pending: bool = False) -> list[dict[str, Any]]:
    """Return the Anthropic Messages tool-use shape.

    Anthropic uses `input_schema` rather than `parameters`; otherwise
    the shape is identical.
    """
    out: list[dict[str, Any]] = []
    for name, schema in KAIROS_TOOL_SCHEMAS.items():
        if not include_pending and "_pending" in schema:
            continue
        out.append({
            "name": schema["name"],
            "description": schema["description"],
            "input_schema": schema["parameters"],
        })
    return out
