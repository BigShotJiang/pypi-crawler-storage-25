"""kairos.mcp — agent-tool surface for kairos base SDK (ATH-727).

Per the 2026-04-26/27 kairos-vs-pythia split with CTO:
pythia is the engine (Lean library); kairos is the dashboard (customer-
facing orchestration). This package is the agent-facing surface that
exposes kairos base SDK tools to MCP-consuming agents (Claude Code,
Cursor, Cline, OpenHands, OpenClaw, Leanstral) AND to raw OpenAI /
Anthropic / Gemini / Mistral function-calling clients that don't go
through MCP.

## Two-step ship

PR #1 (this module's first commit): the schema layer.
* `kairos.mcp.schemas` — JSON-schema + function-calling shapes for every
  base SDK tool. Pure Python, no new dependencies. Customers + agent
  loops can consume these directly via raw HTTP / SDK function-calling.

PR #2 (upcoming): the MCP transport layer.
* `kairos.mcp.server` — a Python MCP server using the `modelcontextprotocol`
  reference SDK. Optional dep installed via `pip install athanor-sdk[mcp]`.
* `athanor mcp serve` CLI entrypoint with stdio + HTTP transports.

## Base SDK coupling fence

This package MUST NOT import from `kairos.fleet` / `kairos.prove` /
`kairos.sv.cegar` / `kairos.sv.swarm` / `kairos.sv.multi` /
`kairos.sv.invariants`. Verified by static-import audit regression test.
"""
from __future__ import annotations

from kairos.mcp.schemas import (
    BYO_LLM_PROVIDERS,
    KAIROS_TOOL_SCHEMAS,
    anthropic_tools,
    export_schemas,
    openai_tools,
)

__all__ = [
    "BYO_LLM_PROVIDERS",
    "KAIROS_TOOL_SCHEMAS",
    "anthropic_tools",
    "export_schemas",
    "openai_tools",
]
