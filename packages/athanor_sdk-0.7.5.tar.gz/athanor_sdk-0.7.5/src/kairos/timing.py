"""kairos.timing -- wall-clock timing receipts for time-hallucination enforcement.

Phase 1 (Python prototype). Phase 2 adds a Rust-native implementation
with a Verus proof that receipt.duration_sec == receipt.wall_clock_end -
receipt.wall_clock_start (monotonic-clock anti-hallucination guarantee).

Design rationale: LLM-generated timing claims ("took 0.3 s") are
unverifiable unless the SDK captures monotonic wall-clock stamps at the
call boundary and returns them alongside the result. A TimingReceipt is
unforgeable evidence that the wrapped code actually ran for the claimed
duration -- the receipt exists IFF timing was measured, so
``verified=True`` is a structural invariant, not an assertion.

Public surface::

    from kairos.timing import TimingReceipt, timed, timing_context

    # Decorator form -- wraps any sync function.
    @timed
    def my_tool(x: int) -> str:
        ...
    result, receipt = my_tool(42)

    # Context-manager form -- wraps an arbitrary block.
    with timing_context("my_block") as ctx:
        do_work()
    receipt = ctx.receipt  # available after __exit__

Purity: PURE (monotonic clock reads only; no I/O).
"""

from __future__ import annotations

import functools
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Any, Callable, Generator, TypeVar

_F = TypeVar("_F", bound=Callable[..., Any])


@dataclass(frozen=True, slots=True)
class TimingReceipt:
    """Unforgeable evidence that wall-clock timing was measured.

    All timestamps come from ``time.monotonic()`` which is immune to
    NTP jumps and wall-clock resets. ``duration_sec`` is computed at
    construction time as ``wall_clock_end - wall_clock_start``; the
    frozen dataclass prevents post-hoc mutation.

    ``verified`` is always ``True`` -- the receipt's existence IS the
    proof that timing was captured. The field is present so downstream
    consumers (trace payload, cert bundles) can carry a single boolean
    without needing to reason about None-vs-present-receipt.
    """

    wall_clock_start: float
    wall_clock_end: float
    duration_sec: float
    tool_name: str
    verified: bool = field(default=True, init=False)

    def __post_init__(self) -> None:
        # Structural invariant: duration_sec MUST equal end - start.
        # Phase 2 (Verus) proves this statically; Phase 1 checks at
        # construction time so a caller who passes inconsistent values
        # gets a loud error rather than a silently wrong receipt.
        expected = round(self.wall_clock_end - self.wall_clock_start, 9)
        actual = round(self.duration_sec, 9)
        if expected != actual:
            raise ValueError(
                f"TimingReceipt invariant violated: "
                f"duration_sec={self.duration_sec} != "
                f"wall_clock_end - wall_clock_start = "
                f"{self.wall_clock_end - self.wall_clock_start}"
            )

    def to_payload(self) -> dict[str, object]:
        """Serialise to a dict suitable for TraceEvent.payload inclusion."""
        return {
            "timing_wall_clock_start": self.wall_clock_start,
            "timing_wall_clock_end": self.wall_clock_end,
            "timing_duration_sec": round(self.duration_sec, 6),
            "timing_tool_name": self.tool_name,
            "timing_verified": self.verified,
        }


def _make_receipt(start: float, end: float, tool_name: str) -> TimingReceipt:
    """Construct a TimingReceipt from raw monotonic stamps."""
    return TimingReceipt(
        wall_clock_start=start,
        wall_clock_end=end,
        duration_sec=end - start,
        tool_name=tool_name,
    )


def timed(fn: _F) -> _F:
    """Decorator that wraps ``fn`` so it returns ``(result, TimingReceipt)``.

    The receipt captures monotonic wall-clock start/end around the
    original call. ``tool_name`` defaults to ``fn.__qualname__``.

    Usage::

        @timed
        def verify(module: str) -> bool:
            ...

        ok, receipt = verify("fifo")
        assert receipt.verified
        assert receipt.duration_sec >= 0
    """

    @functools.wraps(fn)
    def wrapper(*args: Any, **kwargs: Any) -> tuple[Any, TimingReceipt]:
        tool = fn.__qualname__
        start = time.monotonic()
        result = fn(*args, **kwargs)
        end = time.monotonic()
        return result, _make_receipt(start, end, tool)

    return wrapper  # type: ignore[return-value]


@dataclass
class TimingBlock:
    """Mutable holder yielded by :func:`timing_context`.

    ``receipt`` is ``None`` inside the ``with`` block and populated on
    ``__exit__``. Callers read it after the block completes.
    """

    tool_name: str
    receipt: TimingReceipt | None = None


@contextmanager
def timing_context(tool_name: str) -> Generator[TimingBlock, None, None]:
    """Context manager that captures wall-clock timing for a code block.

    Usage::

        with timing_context("my_pipeline") as ctx:
            run_pipeline()
        print(ctx.receipt.duration_sec)

    The receipt is set on the ``TimingBlock`` when the ``with`` block
    exits (whether normally or via exception). On exception the receipt
    is still populated (the wall-clock measurement is valid regardless
    of the outcome) and the exception is re-raised.
    """
    block = TimingBlock(tool_name=tool_name)
    start = time.monotonic()
    try:
        yield block
    finally:
        end = time.monotonic()
        block.receipt = _make_receipt(start, end, tool_name)


__all__ = [
    "TimingReceipt",
    "TimingBlock",
    "timed",
    "timing_context",
]
