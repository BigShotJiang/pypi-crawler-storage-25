"""CF Access service-token helper for agent dogfood (ATH-1072).

Agents running on the fleet VM cannot curl tahoe.athanor-ai.com
because Cloudflare Access blocks non-browser requests. This module
provides a session builder that auto-injects the CF Access service
token headers from per-role env vars.

Env vars (set by Aidan/Sam after provisioning in CF dashboard):
  CF_ACCESS_CLIENT_ID     — Service token client ID
  CF_ACCESS_CLIENT_SECRET — Service token client secret

Usage:
    from kairos.dogfood.cf_access import cf_get

    data = cf_get("/api/me")
"""
from __future__ import annotations

import json
import logging
import os
from typing import Any
from urllib.request import Request, urlopen

_log = logging.getLogger(__name__)

TAHOE_BASE = "https://tahoe.athanor-ai.com"


def cf_headers() -> dict[str, str]:
    client_id = os.environ.get("CF_ACCESS_CLIENT_ID", "")
    client_secret = os.environ.get("CF_ACCESS_CLIENT_SECRET", "")
    if not client_id or not client_secret:
        _log.warning(
            "CF_ACCESS_CLIENT_ID / CF_ACCESS_CLIENT_SECRET not set. "
            "CF Access requests will be blocked. See ATH-1072."
        )
        return {}
    return {
        "CF-Access-Client-Id": client_id,
        "CF-Access-Client-Secret": client_secret,
    }


def cf_get(path: str) -> dict[str, Any]:
    if not path.startswith("/"):
        raise ValueError(
            f"cf_get accepts paths only (e.g. '/api/me'), not full URLs. "
            f"Got: {path!r}"
        )
    url = f"{TAHOE_BASE}{path}"
    headers = cf_headers()
    req = Request(url, headers=headers)
    with urlopen(req, timeout=15) as resp:  # nosemgrep: dynamic-urllib-use-detected
        result: dict[str, Any] = json.loads(resp.read())
        return result


def is_cf_configured() -> bool:
    return bool(
        os.environ.get("CF_ACCESS_CLIENT_ID")
        and os.environ.get("CF_ACCESS_CLIENT_SECRET")
    )
