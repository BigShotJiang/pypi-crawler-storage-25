"""kairos.closure_classifier — tactic-vocabulary entropy on Lean closures.

ATH-855 (L15 of the 2026-04-28 anti-cheat design review).

The 13-layer SDK anti-cheat stack already catches:

* ``axiom`` / ``unsafe`` / ``init`` declarations (banned-construct)
* ``sorry`` / ``admit`` placeholders (sorry/admit gate)
* compile failure (lake build)
* non-allowlist axioms in the dependency DAG (axiom audit)
* sorryAx-anywhere-in-the-DAG (vacuous-proof audit)
* spec mistranslation (nl-roundtrip spec-health)

The hole L15 closes is the **alpha-rename closure**: the proof
compiles, has no banned constructs, no sorry, dependency DAG is
clean — but the body is a single application of a Mathlib lemma
whose statement is alpha-equivalent to the goal. The model didn't
prove anything; it found a pre-existing equivalence and renamed it.

Two signals:

1. **Tactic-vocabulary entropy** — the Shannon entropy (in bits) of
   the tactic distribution in the proof body. A genuine proof has
   `intro`, `apply`, `simp`, `rw`, `exact`, `linarith`, etc. mixed
   together. A single-lemma rename has just `exact <lemma>` or
   `apply <lemma>` — entropy ≈ 0.
2. **Single-applied-lemma alpha-rename** — body contains exactly one
   Mathlib reference, used in `exact` / `apply` position, and the
   statement of that lemma normalised matches the theorem goal under
   alpha-equivalence (variable renaming).

The classifier is **advisory**, not a hard gate. A genuine one-line
proof (`theorem foo : True := trivial`) trips the entropy heuristic.
Customers can override with the ``allow_trivial=True`` flag, and the
trace event surfaces the verdict so platform's AntiCheatPanel can
light up the L15 row regardless of whether it gates.

## Cross-links

* ATH-845 (axiom audit) — orthogonal; that's about WHICH axioms are
  in the DAG, not how the proof body composes lemmas
* ATH-853 (Q2 ECDSA-signed verdicts) — the closure verdict goes
  into the canonicalized verdict shape that gets signed
* ATH-856 platform AntiCheatPanel — L15 row surfaces this verdict
  via the ``tactic_vocabulary_entropy`` trace event
* 2026-04-28 anti-cheat review #dev-platform ts=1777398105.887289
"""
from __future__ import annotations

import logging
import math
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Iterable

_logger = logging.getLogger(__name__)


# Default heuristic thresholds. Customer-tunable via classify_closure
# kwargs. Picked by hand against the wald_wolfowitz / alpha-rename
# corpus from the 2026-04-28 review thread; tighten if the false-
# positive rate is too high in production.
DEFAULT_MIN_ENTROPY_BITS = 1.0  # ≥1 bit ≈ 2+ distinct tactics
DEFAULT_MIN_TACTIC_TOKENS = 3   # below this, entropy is meaningless


# Lean 4 tactic vocabulary. NOT exhaustive — designed to capture the
# common tactics a non-trivial proof uses. Anything not in the list
# is treated as a "lemma reference" token (which feeds the alpha-
# rename heuristic but doesn't count toward entropy diversity).
KNOWN_TACTICS: frozenset[str] = frozenset({
    "intro", "intros", "exact", "apply", "refine", "have", "show",
    "rw", "rewrite", "simp", "simp_all", "simp_arith", "norm_num",
    "linarith", "nlinarith", "ring", "ring_nf", "field_simp",
    "constructor", "left", "right", "use", "exists", "split",
    "cases", "rcases", "obtain", "induction", "induction'",
    "decide", "rfl", "trivial", "assumption", "by_contra",
    "contradiction", "absurd", "exfalso", "push_neg", "omega",
    "calc", "trans", "ext", "funext", "congr", "subst", "set",
    "let", "match", "fun", "if", "then", "else",
    "tauto", "fin_cases", "interval_cases",
})


# Heuristic regex for "applied a lemma". Catches `exact some.lemma`,
# `apply some.lemma`, `refine some.lemma _ _`. Doesn't try to parse
# complex tactic combinators — fine, the alpha-rename heuristic only
# needs to detect the simple-shaped cheating pattern.
_LEMMA_APPLY_RE = re.compile(
    r"\b(?:exact|apply|refine)\s+(?:@)?([A-Za-z_][\w'.]*)\b",
)

# Tokenizer: pull keyword-like alphanumeric runs out of the body.
# Strips comments + string literals first so a comment containing
# `simp` doesn't inflate the tactic count.
_LINE_COMMENT_RE = re.compile(r"--[^\n]*")
_BLOCK_COMMENT_RE = re.compile(r"/-.*?-/", re.DOTALL)
_STRING_RE = re.compile(r'"(?:\\.|[^"\\])*"')
_TOKEN_RE = re.compile(r"\b[A-Za-z_][\w']*\b")


# ── Public dataclass ─────────────────────────────────────────────────


@dataclass(frozen=True)
class ClosureVerdict:
    """Outcome of running :func:`classify_closure` on a proof body.

    Attributes:
        tactic_count: Total number of tokens that matched
            ``KNOWN_TACTICS``. Below ``min_tactic_tokens`` the
            entropy field is effectively undefined; ``is_trivial``
            still reports correctly via the alpha-rename signal.
        unique_tactics: Cardinality of the distinct-tactic set.
        shannon_entropy_bits: Shannon entropy of the tactic
            distribution, base-2. ``0.0`` when only one distinct
            tactic appears or when ``tactic_count == 0``.
        applied_lemmas: Sorted list of unique lemma references
            extracted from ``exact`` / ``apply`` / ``refine`` heads.
        is_alpha_rename: ``True`` when the proof body has a single
            applied lemma and the lemma reference matches the goal's
            head symbol (a deliberately-loose heuristic — see the
            ``goal`` parameter doc on :func:`classify_closure`).
        is_trivial: ``True`` when the entropy is below the threshold
            OR ``is_alpha_rename`` fired. The advisory cheating
            signal — surfaced through the trace event.
        trivial_reason: One-line description of why ``is_trivial``
            is set (``None`` when the verdict is non-trivial).
        threshold_min_entropy_bits: The threshold actually used (so
            the trace event is self-describing).
        threshold_min_tactic_tokens: As above, for the token floor.
    """
    tactic_count: int
    unique_tactics: int
    shannon_entropy_bits: float
    applied_lemmas: list[str] = field(default_factory=list)
    is_alpha_rename: bool = False
    is_trivial: bool = False
    trivial_reason: str | None = None
    threshold_min_entropy_bits: float = DEFAULT_MIN_ENTROPY_BITS
    threshold_min_tactic_tokens: int = DEFAULT_MIN_TACTIC_TOKENS


# ── Helpers ──────────────────────────────────────────────────────────


def _strip_noise(body: str) -> str:
    """Remove block comments, line comments, and string literals.

    Order matters: strip block comments first (they contain ``--``
    sequences that the line-comment regex would otherwise misread)
    then line comments, then strings.
    """
    s = _BLOCK_COMMENT_RE.sub(" ", body)
    s = _LINE_COMMENT_RE.sub(" ", s)
    s = _STRING_RE.sub(" ", s)
    return s


def _shannon_entropy(counts: Iterable[int]) -> float:
    """Shannon entropy in bits over a count distribution.

    Returns ``0.0`` when the total is zero (no tokens to distribute
    over) — distinct from log(0) which is undefined.
    """
    counts = [c for c in counts if c > 0]
    total = sum(counts)
    if total == 0:
        return 0.0
    h = 0.0
    for c in counts:
        p = c / total
        h -= p * math.log2(p)
    return h


def _extract_tactics(clean_body: str) -> Counter[str]:
    """Pull KNOWN_TACTICS occurrences from a comment-stripped body."""
    counts: Counter[str] = Counter()
    for m in _TOKEN_RE.finditer(clean_body):
        token = m.group(0)
        if token in KNOWN_TACTICS:
            counts[token] += 1
    return counts


def _extract_applied_lemmas(clean_body: str) -> list[str]:
    """Pull unique ``exact`` / ``apply`` / ``refine`` lemma heads."""
    seen: list[str] = []
    seen_set: set[str] = set()
    for m in _LEMMA_APPLY_RE.finditer(clean_body):
        name = m.group(1)
        # Skip tokens that ARE tactics (e.g., `apply rfl` — `rfl`
        # is a tactic, not a lemma). The KNOWN_TACTICS check filters
        # that case.
        if name in KNOWN_TACTICS:
            continue
        if name not in seen_set:
            seen_set.add(name)
            seen.append(name)
    return seen


def _normalise_for_alpha(s: str) -> str:
    """Crude alpha-equivalence: lowercase + strip whitespace +
    collapse identifier-like fragments.

    NOT a real alpha-equivalence checker — we don't have a Lean
    parser at hand. Catches the trivial case where the lemma's
    name fragment (e.g. ``Nat.add_comm``) appears in the goal text
    after lowercasing. False positives possible but harmless: this
    feeds an advisory flag, not a hard gate.
    """
    return re.sub(r"\s+", "", s.lower())


# ── Public entry ─────────────────────────────────────────────────────


def classify_closure(
    *,
    proof_body: str,
    goal: str | None = None,
    min_entropy_bits: float = DEFAULT_MIN_ENTROPY_BITS,
    min_tactic_tokens: int = DEFAULT_MIN_TACTIC_TOKENS,
) -> ClosureVerdict:
    """Classify a Lean proof body for tactic-vocabulary entropy + alpha-rename.

    Args:
        proof_body: The proof source. Comments + strings are stripped
            before analysis.
        goal: Optional goal text used by the alpha-rename heuristic.
            When None, only the entropy signal fires. The heuristic
            is intentionally crude: lowercase substring match between
            the lemma reference and the goal text.
        min_entropy_bits: Threshold below which the proof is flagged
            as trivial. Default 1.0 bit (≈ 2+ distinct tactics).
        min_tactic_tokens: Tactic-count floor below which the entropy
            calculation is meaningless. Defaults to 3 — single-tactic
            closures (``:= by trivial``) ARE flagged via the
            tactic_count==1 path.

    Returns:
        :class:`ClosureVerdict` — never raises; analysis failures
        return a verdict with ``is_trivial=False`` and a logged warning.
    """
    if not proof_body:
        return ClosureVerdict(
            tactic_count=0,
            unique_tactics=0,
            shannon_entropy_bits=0.0,
            applied_lemmas=[],
            is_trivial=False,
            trivial_reason=None,
            threshold_min_entropy_bits=min_entropy_bits,
            threshold_min_tactic_tokens=min_tactic_tokens,
        )
    clean = _strip_noise(proof_body)
    counts = _extract_tactics(clean)
    total = sum(counts.values())
    unique = len(counts)
    entropy = _shannon_entropy(counts.values()) if total > 0 else 0.0
    lemmas = _extract_applied_lemmas(clean)

    # Alpha-rename heuristic. Fires when:
    #   - exactly ONE applied lemma in the body
    #   - either no goal supplied (advisory), or the lemma's
    #     bottommost identifier fragment appears in the goal
    is_alpha = False
    if len(lemmas) == 1:
        if goal is None:
            is_alpha = True
        else:
            lemma_tail = lemmas[0].split(".")[-1]
            if (
                _normalise_for_alpha(lemma_tail)
                in _normalise_for_alpha(goal)
            ):
                is_alpha = True

    # Entropy gate.
    is_low_entropy = (
        total > 0
        and total < min_tactic_tokens
        and unique <= 1
    ) or (
        total >= min_tactic_tokens
        and entropy < min_entropy_bits
    )

    is_trivial = is_alpha or is_low_entropy
    reason: str | None = None
    if is_alpha and is_low_entropy:
        reason = (
            f"single-lemma alpha-rename ({lemmas[0]!r}) AND "
            f"entropy {entropy:.2f} < {min_entropy_bits}"
        )
    elif is_alpha:
        reason = f"single-lemma alpha-rename ({lemmas[0]!r})"
    elif is_low_entropy and total > 0:
        reason = (
            f"low tactic-vocabulary entropy "
            f"({entropy:.2f} bits over {total} tokens, "
            f"{unique} distinct)"
        )
    elif is_low_entropy:
        reason = "no tactic tokens recognised in proof body"

    return ClosureVerdict(
        tactic_count=total,
        unique_tactics=unique,
        shannon_entropy_bits=round(entropy, 4),
        applied_lemmas=lemmas,
        is_alpha_rename=is_alpha,
        is_trivial=is_trivial,
        trivial_reason=reason,
        threshold_min_entropy_bits=min_entropy_bits,
        threshold_min_tactic_tokens=min_tactic_tokens,
    )


__all__ = [
    "DEFAULT_MIN_ENTROPY_BITS",
    "DEFAULT_MIN_TACTIC_TOKENS",
    "KNOWN_TACTICS",
    "ClosureVerdict",
    "classify_closure",
]
