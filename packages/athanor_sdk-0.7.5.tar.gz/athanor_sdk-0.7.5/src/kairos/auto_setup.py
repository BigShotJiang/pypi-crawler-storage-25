"""ATH-1406: zero-config auto-setup for kairos optimize.

On first run, auto-provisions what's missing so `kairos optimize block.sv`
works immediately after `pip install`. Three gates checked in order:

1. License — auto-creates 30-day eval via generate_eval_license()
2. API key — prompts once (interactive) or skips (non-interactive)
3. Working dir — warns if no .sv files present

Uses the REAL license path (~/.athanor/license.json) and the REAL
config module (kairos.config) so every gate interoperates with
license_scope, doctor, and the config CLI.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path


def _ensure_license() -> None:
    """Auto-create eval license if none exists."""
    athanor_dir = Path.home() / ".athanor"
    if athanor_dir.is_symlink():
        print("[kairos] WARNING: ~/.athanor is a symlink — refusing to write", file=sys.stderr)
        return
    athanor_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    license_path = athanor_dir / "license.json"
    if license_path.is_file():
        return
    from kairos.cmd_eval_license import generate_eval_license
    path = generate_eval_license(days=30, subject="auto-setup")
    print(f"[kairos] Auto-created 30-day eval license at {path}", file=sys.stderr)


def _ensure_proposer_backend() -> None:
    """Ensure at least one proposer backend is available.

    Checks env vars and claude CLI first. If nothing found AND stdin
    is interactive, prompts for an API key once and persists it.
    Non-interactive (CI, pipes, containers) silently skips — the real
    optimize() call will raise with clear instructions.
    """
    import shutil
    if os.environ.get("ANTHROPIC_API_KEY"):
        return
    if os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("AWS_DEFAULT_REGION"):
        return
    if shutil.which("claude"):
        return

    from kairos.config import _load_config_dict, _save_config_dict
    cfg = _load_config_dict()
    stored_key = cfg.get("anthropic_api_key")
    if stored_key and isinstance(stored_key, str):
        os.environ["ANTHROPIC_API_KEY"] = stored_key
        return

    if not sys.stdin.isatty():
        return

    print(
        "[kairos] No proposer backend detected.\n"
        "  Option 1: Enter your Anthropic API key below\n"
        "  Option 2: Press Enter to use Claude Code CLI (must be on PATH)\n",
        file=sys.stderr,
    )
    try:
        import getpass
        key = getpass.getpass("Anthropic API key (or Enter to skip): ").strip()
    except (EOFError, KeyboardInterrupt):
        return

    if key:
        cfg["anthropic_api_key"] = key
        _save_config_dict(cfg)
        config_path = Path.home() / ".athanor" / "config.json"
        if config_path.is_file():
            config_path.chmod(0o600)
        os.environ["ANTHROPIC_API_KEY"] = key
        print("[kairos] API key saved to ~/.athanor/config.json (mode 600)", file=sys.stderr)
    else:
        print("[kairos] No key entered. Install Claude Code CLI or set ANTHROPIC_API_KEY.", file=sys.stderr)


def _check_working_dir() -> None:
    """Warn if no .sv files in cwd (advisory only)."""
    cwd = Path.cwd()
    if not any(cwd.glob("*.sv")) and not any(cwd.glob("*.v")):
        print(
            "[kairos] No .sv or .v files in current directory. "
            "Pass the path explicitly: kairos optimize path/to/block.sv",
            file=sys.stderr,
        )


def ensure_ready() -> None:
    """Run all auto-setup gates. Never raises — failures degrade gracefully
    and the real command will give the proper error message."""
    try:
        _ensure_license()
    except Exception:  # noqa: BLE001
        pass
    try:
        _ensure_proposer_backend()
    except Exception:  # noqa: BLE001
        pass
    try:
        _check_working_dir()
    except Exception:  # noqa: BLE001
        pass
