"""kairos.flows.verify_rtl -- one-call BMC-to-CEGAR escalation for RTL.

Customer-facing convenience wrapper per CTO directive: the customer
calls ``verify_rtl(sv_file, top_module)`` and kairos handles the
BMC -> CEGAR escalation internally.

Strategy:
    1. Run EBMC bounded model checking (``kairos.sv.ebmc.run_ebmc``).
    2. If BMC proves all properties, return immediately.
    3. If BMC returns UNKNOWN (timeout / inconclusive at the given
       bound) **and** ``auto_cegar=True``, escalate to the incremental
       CEGAR loop (``kairos.sv.cegar_incremental.incremental_cegar``).
    4. If BMC refutes a property, return the refutation -- no point
       running CEGAR on a genuinely broken design.

The result carries which strategy produced the verdict so the caller
can attribute the proof.

Example::

    from kairos.flows.verify_rtl import verify_rtl

    result = verify_rtl("arbiter.sv", "arbiter", bound=20)
    if result.proved:
        print(f"All properties proved via {result.strategy}")
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal


@dataclass(frozen=True)
class VerifyRtlResult:
    """Outcome of :func:`verify_rtl`.

    Attributes:
        proved: True iff every property in scope was proved AND none
            were refuted.
        refuted: True iff at least one property was refuted.
        unknown: True when neither proved nor refuted (both strategies
            exhausted without closure).
        strategy: Which backend produced the terminal verdict --
            ``"bmc"``, ``"cegar"``, or ``"none"`` when nothing closed.
        property_verdicts: Per-property breakdown from the terminal
            EBMC invocation (``{name: "PROVED"|"REFUTED"|"UNKNOWN"}``).
        counterexample: Raw EBMC counterexample trace when refuted.
        bmc_elapsed_sec: Wall-clock time for the BMC leg.
        cegar_elapsed_sec: Wall-clock time for the CEGAR leg (0 if
            CEGAR was not attempted).
        total_elapsed_sec: Overall wall-clock time.
        cegar_iterations: Number of CEGAR iterations executed (0 when
            CEGAR was skipped).
        cegar_lemmas_accepted: Number of lemmas accepted during CEGAR.
        details: Free-form dict for backend-specific diagnostics.
    """

    proved: bool = False
    refuted: bool = False
    unknown: bool = False
    strategy: Literal["bmc", "cegar", "none"] = "none"
    property_verdicts: dict[str, str] = field(default_factory=dict)
    counterexample: str | None = None
    bmc_elapsed_sec: float = 0.0
    cegar_elapsed_sec: float = 0.0
    total_elapsed_sec: float = 0.0
    cegar_iterations: int = 0
    cegar_lemmas_accepted: int = 0
    details: dict[str, Any] = field(default_factory=dict)


def verify_rtl(
    sv_file: str | Path,
    top_module: str,
    *,
    bound: int = 10,
    timeout_sec: int = 120,
    auto_cegar: bool = True,
    cegar_max_iter: int = 10,
    cegar_timeout_per_step_sec: int = 300,
    reset_expr: str | None = None,
    extra_args: list[str] | None = None,
    flatten: bool = False,
) -> VerifyRtlResult:
    """Verify an RTL design, auto-escalating from BMC to CEGAR.

    Args:
        sv_file: Path to the SystemVerilog source file.
        top_module: Top-level module name to verify.
        bound: BMC depth (passed to ``run_ebmc --bound``).
        timeout_sec: Wall-clock timeout for the BMC leg.
        auto_cegar: When True and BMC returns UNKNOWN, automatically
            escalate to incremental CEGAR. When False, return the
            UNKNOWN verdict directly.
        cegar_max_iter: Maximum CEGAR iterations (only used when
            auto_cegar fires).
        cegar_timeout_per_step_sec: Per-step timeout inside the CEGAR
            loop.
        reset_expr: Reset signal expression (e.g. ``"!rst_n"``).
        extra_args: Extra CLI flags appended to every EBMC invocation.
        flatten: Pre-flatten packed structs before EBMC.

    Returns:
        :class:`VerifyRtlResult` with ``proved``, ``refuted``, or
        ``unknown`` set, and ``strategy`` indicating which backend
        produced the verdict.
    """
    from kairos.sv.ebmc import run_ebmc, EbmcResult
    from kairos.sv.cegar_incremental import (
        incremental_cegar,
        IncrementalCegarResult,
    )

    sv_path = Path(sv_file)
    t_start = time.monotonic()

    # ── Step 1: BMC ──────────────────────────────────────────────────
    bmc_t0 = time.monotonic()
    bmc_result: EbmcResult = run_ebmc(
        sv_path,
        top_module=top_module,
        bound=bound,
        mode="bmc",
        reset_expr=reset_expr,
        timeout_sec=timeout_sec,
        extra_args=extra_args,
        flatten=flatten,
    )
    bmc_elapsed = time.monotonic() - bmc_t0

    bmc_verdicts = dict(bmc_result.property_verdicts or {})

    # Refuted -- return immediately, no CEGAR needed.
    if bmc_result.refuted > 0:
        cex = None
        try:
            cex = bmc_result.counterexample
        except Exception:  # noqa: BLE001
            pass
        return VerifyRtlResult(
            refuted=True,
            strategy="bmc",
            property_verdicts=bmc_verdicts,
            counterexample=cex,
            bmc_elapsed_sec=bmc_elapsed,
            total_elapsed_sec=time.monotonic() - t_start,
            details={"exit_code": bmc_result.exit_code},
        )

    # Proved -- all declared properties verified up to bound.
    if bmc_result.proved > 0 and not bmc_result.timed_out:
        return VerifyRtlResult(
            proved=True,
            strategy="bmc",
            property_verdicts=bmc_verdicts,
            bmc_elapsed_sec=bmc_elapsed,
            total_elapsed_sec=time.monotonic() - t_start,
            details={
                "bound_k": bound,
                "exit_code": bmc_result.exit_code,
            },
        )

    # ── Step 2: UNKNOWN -- consider CEGAR escalation ─────────────────
    if not auto_cegar:
        return VerifyRtlResult(
            unknown=True,
            strategy="none",
            property_verdicts=bmc_verdicts,
            bmc_elapsed_sec=bmc_elapsed,
            total_elapsed_sec=time.monotonic() - t_start,
            details={
                "timed_out": bmc_result.timed_out,
                "exit_code": bmc_result.exit_code,
                "reason": "BMC inconclusive and auto_cegar=False",
            },
        )

    # ── Step 3: CEGAR escalation ─────────────────────────────────────
    cegar_t0 = time.monotonic()
    cegar_result: IncrementalCegarResult = incremental_cegar(
        [str(sv_path)],
        top_module=top_module,
        bound=bound,
        max_iter=cegar_max_iter,
        reset_expr=reset_expr,
        extra_args=extra_args,
        flatten=flatten,
        timeout_per_step_sec=cegar_timeout_per_step_sec,
    )
    cegar_elapsed = time.monotonic() - cegar_t0

    accepted = sum(
        1 for lem in cegar_result.lemmas if lem.classification == "accepted"
    )

    if cegar_result.proved:
        return VerifyRtlResult(
            proved=True,
            strategy="cegar",
            property_verdicts=bmc_verdicts,
            bmc_elapsed_sec=bmc_elapsed,
            cegar_elapsed_sec=cegar_elapsed,
            total_elapsed_sec=time.monotonic() - t_start,
            cegar_iterations=cegar_result.iterations,
            cegar_lemmas_accepted=accepted,
            details={
                "bound_k": bound,
                "cegar_base_elaboration_sec": cegar_result.base_elaboration_sec,
            },
        )

    # CEGAR also failed to close.
    return VerifyRtlResult(
        unknown=True,
        strategy="none",
        property_verdicts=bmc_verdicts,
        bmc_elapsed_sec=bmc_elapsed,
        cegar_elapsed_sec=cegar_elapsed,
        total_elapsed_sec=time.monotonic() - t_start,
        cegar_iterations=cegar_result.iterations,
        cegar_lemmas_accepted=accepted,
        details={
            "bmc_timed_out": bmc_result.timed_out,
            "bmc_exit_code": bmc_result.exit_code,
            "cegar_base_elaboration_sec": cegar_result.base_elaboration_sec,
            "reason": "Both BMC and CEGAR failed to close",
        },
    )
