"""kairos.flows -- convenience wrappers that compose multiple backends.

Each flow module exposes one top-level function that handles strategy
escalation internally so customers call one function instead of
manually chaining backends.

Public surface::

    from kairos.flows.verify_rtl import verify_rtl
"""
from __future__ import annotations
