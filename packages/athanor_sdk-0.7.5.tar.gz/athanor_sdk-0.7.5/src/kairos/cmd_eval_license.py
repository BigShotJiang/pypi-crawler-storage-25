"""ATH-1128: generate a lightweight eval license for customer trials.

Mints a time-limited license.json with eval-tier products. No GPG
signature (grace-period flag in _keys/ skips verification). Customer
runs `kairos eval-license` once, gets 30 days of paid features.

The eval license is NOT a security boundary — it's a UX gate so
customers don't need `KAIROS_DEV_NO_LICENSE=1` (an internal flag).
Real enforcement comes from the GPG-signed production license.
"""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


DEFAULT_EVAL_DAYS = 30
EVAL_PRODUCTS = ["solve", "envs"]
EVAL_ENVS = ["sysverilog", "neuron-nki", "cross-accel", "theorem-proving"]


def generate_eval_license(
    days: int = DEFAULT_EVAL_DAYS,
    output_path: Path | None = None,
    subject: str = "eval-trial",
) -> Path:
    """Write an eval license.json and return the path."""
    if output_path is None:
        output_path = Path.home() / ".athanor" / "license.json"

    output_path.parent.mkdir(parents=True, exist_ok=True)

    expires_at = datetime.now(timezone.utc) + timedelta(days=days)

    license_data = {
        "subject": subject,
        "products": EVAL_PRODUCTS,
        "envs": EVAL_ENVS,
        "expires_at": expires_at.isoformat(),
        "tier": "eval",
        "issued_at": datetime.now(timezone.utc).isoformat(),
    }

    output_path.write_text(json.dumps(license_data, indent=2) + "\n")
    return output_path


def add_subparser(subparsers: Any) -> None:
    p = subparsers.add_parser(
        "eval-license",
        help=argparse.SUPPRESS,
    )
    p.add_argument(
        "--days",
        type=int,
        default=DEFAULT_EVAL_DAYS,
        help=f"Number of days until the eval license expires (default: {DEFAULT_EVAL_DAYS})",
    )
    p.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output path for the license file (default: ~/.athanor/license.json)",
    )
    p.add_argument(
        "--subject",
        type=str,
        default="eval-trial",
        help="License subject identifier (default: eval-trial)",
    )


def cmd_eval_license(args: Any) -> None:
    days = args.days
    output = Path(args.output) if args.output else None
    subject = args.subject

    path = generate_eval_license(days=days, output_path=output, subject=subject)
    expires = datetime.now(timezone.utc) + timedelta(days=days)
    print(f"Eval license written to {path}")
    print(f"  Products: {', '.join(EVAL_PRODUCTS)}")
    print(f"  Expires:  {expires.strftime('%Y-%m-%d')} ({days} days)")
    print(f"  Subject:  {subject}")
    print()
    print("Run `kairos doctor` to verify the license is loaded.")
