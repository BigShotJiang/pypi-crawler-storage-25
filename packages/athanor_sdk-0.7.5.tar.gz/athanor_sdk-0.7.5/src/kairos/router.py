"""kairos.router — cross-vertical goal-shaped dispatch (ATH-894).

Six goal-shaped tools that route to the right engine automatically:
  prove, verify, diff, mutate, spec, explain.

The customer says "prove this" — the router detects the target type,
selects the engine, and runs the right pipeline. Vertical-specific
tools (sv_prove, lean_solve, acl2_verify) are internal engines; the
router is the customer-facing surface.

Engine selection:
  .sv → kairos.sv.orchestrate (flatten → BMC → k-ind → CEGAR → ACL2)
  .lean → pythia! hammer first, then Pythia.Lookup template fallback
  .dfy → kairos.dafny.verify (when available)
  .cedar → kairos.cedar (when available)
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from kairos.security.env_allowlist import safe_env_for_eval_bash_host

_logger = logging.getLogger(__name__)


@dataclass
class EngineAvailability:
    ebmc: str | None = None
    acl2: str | None = None
    lean: str | None = None
    dafny: str | None = None
    cedar: str | None = None


def detect_engines() -> EngineAvailability:
    """Probe which verification engines are installed."""
    def _find(name: str, candidates: list[str] | None = None) -> str | None:
        found = shutil.which(name)
        if found:
            return found
        for c in (candidates or []):
            if os.path.isfile(c) and os.access(c, os.X_OK):
                return c
        return None

    return EngineAvailability(
        ebmc=_find("ebmc"),
        acl2=_find("acl2", ["/tmp/acl2/saved_acl2", os.path.expanduser("~/acl2/saved_acl2")]),
        lean=_find("lean"),
        dafny=_find("dafny"),
        cedar=_find("cedar"),
    )


_ENGINES_CACHE: EngineAvailability | None = None
_PYTHIA_REGISTRY_CACHE: list[dict] | None = None


def _cached_engines() -> EngineAvailability:
    """Return cached engine availability (detected once at startup)."""
    global _ENGINES_CACHE
    if _ENGINES_CACHE is None:
        _ENGINES_CACHE = detect_engines()
    return _ENGINES_CACHE


def _load_pythia_registry(lean_bin: str | None = None) -> list[dict]:
    """Load Pythia.Lookup registry via #pythia_registry_json sidecar."""
    global _PYTHIA_REGISTRY_CACHE
    if _PYTHIA_REGISTRY_CACHE is not None:
        return _PYTHIA_REGISTRY_CACHE

    lean = lean_bin or shutil.which("lean")
    if not lean:
        _logger.warning("Lean not found — Pythia registry unavailable")
        return []

    try:
        result = subprocess.run(
            [lean, "--run", "-"],
            input='import Pythia.Lookup\n#pythia_registry_json\n',
            capture_output=True, text=True, timeout=30,
            env=safe_env_for_eval_bash_host(),
        )
        stdout = result.stdout
        begin = stdout.find("<<<PYTHIA_LOOKUP_JSON_BEGIN>>>")
        end = stdout.find("<<<PYTHIA_LOOKUP_JSON_END>>>")
        if begin >= 0 and end > begin:
            json_str = stdout[begin + len("<<<PYTHIA_LOOKUP_JSON_BEGIN>>>"):end].strip()
            _PYTHIA_REGISTRY_CACHE = json.loads(json_str)
            _logger.info("Pythia registry loaded: %d entries", len(_PYTHIA_REGISTRY_CACHE))
            return _PYTHIA_REGISTRY_CACHE
    except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
        _logger.warning("Failed to load Pythia registry: %s", e)

    return []


def _detect_target_type(target: str | Path) -> str:
    """Detect the verification domain from the target file."""
    p = Path(target)
    ext = p.suffix.lower()
    if ext in (".sv", ".v", ".svh"):
        return "systemverilog"
    if ext == ".lean":
        return "lean"
    if ext == ".dfy":
        return "dafny"
    if ext == ".cedar":
        return "cedar"
    if ext in (".lisp", ".lsp", ".acl2"):
        return "acl2"
    if ext in (".py",):
        return "python"
    return "unknown"


def _pythia_lookup(goal_class: str, registry: list[dict]) -> list[dict]:
    """Query Pythia registry by goal class prefix."""
    return [e for e in registry if e.get("goalClass", "").startswith(goal_class)]


def _pythia_lookup_module(module: str, registry: list[dict]) -> list[dict]:
    """Query Pythia registry by source module (equality match)."""
    return [e for e in registry if e.get("sourceModule", "") == module]


@dataclass
class RouterResult:
    success: bool
    target_type: str
    engine_used: str
    result: Any = None
    verification_status: str = "unverified"
    error: str | None = None
    pythia_entries: list[dict] = field(default_factory=list)
    theorem_name: str | None = None
    # ATH-912: which flow drove this run.  Set by the cascade after
    # flow_config emission; lets callers correlate a result back to
    # the YAML that produced it without scanning the trace stream.
    flow_name: str | None = None
    flow_version: str | None = None


def _finalize_with_flow(
    rr: RouterResult, flow_name: str | None, flow_version: str | None,
) -> RouterResult:
    """Stamp ``flow_name`` + ``flow_version`` onto a RouterResult and
    return it.  Use this wrapping every cascade return so callers can
    correlate a result back to the YAML that produced it (ATH-912
    Phase 1 traceability requirement)."""
    rr.flow_name = flow_name
    rr.flow_version = flow_version
    return rr


def _validate_flow_contracts_warn_only(
    flow_name: str,
    flow_version: str,
    step_kinds: list[str],
    *,
    run_subtype: str,
) -> None:
    """ATH-914 Phase 2 cascade wiring: validate the flow's step kinds
    against the typed-contract registry and emit a
    ``flow_contract_violation`` trace event on mismatch.

    Warn-only mode for the initial rollout: we don't abort the cascade
    on violation.  Once contracts are trusted in production we can
    bump to abort-mode behind a kwarg.  Today the discipline is "make
    violations visible without breaking running customers."
    """
    from kairos.flow_contracts import (
        emit_flow_contract_violation, validate_flow_contracts,
    )

    result = validate_flow_contracts(step_kinds)
    if not result.valid:
        _logger.warning(
            "flow %s@%s contract violation: %s pair_violations, %s unknown_kinds",
            flow_name, flow_version,
            len(result.pair_violations), len(result.unknown_kinds),
        )
        emit_flow_contract_violation(
            flow_name, flow_version, result, run_subtype=run_subtype,
        )


def _extract_theorem_name(source: str) -> str | None:
    """Extract the first theorem or lemma declaration name from Lean source."""
    m = re.search(r"^\s*(?:theorem|lemma)\s+(\S+)", source, re.MULTILINE)
    return m.group(1) if m else None


def _detect_lake_project(file_path: Path) -> str | None:
    """Walk up from file_path to find a lakefile.lean parent directory."""
    for parent in file_path.resolve().parents:
        if (parent / "lakefile.lean").exists():
            return str(parent)
    return None


def _file_to_module(file_path: Path, lake_project: str | None = None) -> str:
    """Convert a .lean file path to a dotted Lean module path.

    Walks up to find lakefile.lean, takes the relative path below it,
    drops .lean, dot-joins components.
    """
    fp = file_path.resolve()
    if lake_project:
        root = Path(lake_project).resolve()
        try:
            rel = fp.relative_to(root)
            return str(rel.with_suffix("")).replace(os.sep, ".")
        except ValueError:
            pass
    # Walk up looking for lakefile.lean
    for parent in fp.parents:
        if (parent / "lakefile.lean").exists():
            try:
                rel = fp.relative_to(parent)
                return str(rel.with_suffix("")).replace(os.sep, ".")
            except ValueError:
                break
    return fp.stem


def _construct_hammer_file(target_path: Path, hammer_path: Path) -> bool:
    """Rewrite target's sorries to `by pythia!`. Returns True if any sorry was replaced."""
    src = target_path.read_text()
    patterns = [
        (r":=\s*by\s+sorry\b", ":= by pythia!"),
        (r":=\s*sorry\b", ":= by pythia!"),
        (r"^(\s+)sorry\b", r"\1pythia!"),
    ]
    hammered = src
    for pat, repl in patterns:
        hammered = re.sub(pat, repl, hammered, flags=re.MULTILINE)
    if hammered == src:
        return False
    if "import Pythia.Tactic.Pythia" not in hammered:
        lines = hammered.split("\n")
        last_import = max(
            (i for i, l in enumerate(lines) if l.startswith("import ")),
            default=-1,
        )
        lines.insert(last_import + 1, "import Pythia.Tactic.Pythia")
        hammered = "\n".join(lines)
    hammer_path.write_text(hammered)
    return True


_LEAN_FLOW_NAME = "default-lean-cascade"
_LEAN_FLOW_VERSION = "1.0.0"


def _load_lean_flow():
    """Load the bundled Lean cascade flow config (lazy + cached)."""
    from kairos.flow_schema import load_flow

    bundled = (
        Path(__file__).resolve().parent / "flows"
        / f"{_LEAN_FLOW_NAME}-v{_LEAN_FLOW_VERSION}.yaml"
    )
    return load_flow(bundled)


def _lean_step_pythia_hammer(
    *, target_path: Path, source: str, lake_project: str | None,
    timeout_sec: int, **_,
) -> bool:
    """Run pythia! hammer rewrite + ``lake env lean``.  Returns True if
    the hammer closed the proof (clean elaboration, no sorry warning)."""
    if "sorry" not in source or not lake_project:
        return False
    hammer_path = target_path.with_suffix(".kairos_hammer.lean")
    try:
        had_sorries = _construct_hammer_file(target_path, hammer_path)
        if not had_sorries:
            return False
        res = subprocess.run(
            ["lake", "env", "lean", str(hammer_path)],
            cwd=lake_project,
            capture_output=True, text=True,
            timeout=timeout_sec,
            env=safe_env_for_eval_bash_host(),
        )
        return (
            res.returncode == 0
            and "declaration uses 'sorry'" not in res.stderr
        )
    except Exception:  # noqa: BLE001 — guard returns False on any error
        return False
    finally:
        hammer_path.unlink(missing_ok=True)


def _lean_step_pythia_lookup(
    *, goal_class: str, registry: list[dict], **_,
) -> list[dict]:
    """Query Pythia.Lookup for goal-class template matches."""
    return _pythia_lookup(goal_class, registry) if goal_class else []


def _lean_step_lean_audit(
    *, target_path: Path, lake_project: str | None, **_,
) -> dict[str, Any]:
    """Run ``verify_proof`` (axiom audit + sorry check)."""
    from kairos.lean import verify_proof

    return verify_proof(
        str(target_path),
        audit_axioms=True,
        lake_project=lake_project,
    )


_LEAN_STEP_HANDLERS = {
    "pythia_hammer": _lean_step_pythia_hammer,
    "pythia_lookup": _lean_step_pythia_lookup,
    "lean_audit": _lean_step_lean_audit,
}


def _lean_prove_cascade(
    target: str | Path,
    property: str | None = None,
    *,
    engines: EngineAvailability,
    registry: list[dict],
    timeout_sec: int = 300,
    lake_project: str | None = None,
) -> RouterResult:
    """Lean engine path: pythia! hammer first, then Pythia.Lookup template fallback.

    ATH-912 Phase 1: cascade ordering now read from
    ``src/kairos/flows/default-lean-cascade-v1.0.0.yaml``.  The flow
    config is emitted as a ``flow_config`` trace event at cascade
    entry so every solve_run is traceable to the exact flow version
    that produced it.  Step handlers preserve the existing data
    dependencies (audit's verdict gates which other step's outcome
    wins); fully data-driven dispatch is Phase 2 territory.
    """
    from kairos.flow_schema import emit_flow_config

    target_path = Path(target).resolve()
    goal_class = property or ""

    # Extract theorem name for explain() downstream
    try:
        source = target_path.read_text()
        thm_name = _extract_theorem_name(source)
    except OSError:
        source = ""
        thm_name = None

    # Load + emit the flow config so the run records which flow ran.
    flow_name: str | None = None
    flow_version: str | None = None
    try:
        flow = _load_lean_flow()
        emit_flow_config(flow, run_subtype="autoformalize")
        configured_kinds = [s.kind for s in flow.steps]
        flow_name = flow.name
        flow_version = flow.version
        # ATH-914: pre-flight contract validation (warn-only).
        _validate_flow_contracts_warn_only(
            flow_name, flow_version, configured_kinds,
            run_subtype="autoformalize",
        )
    except Exception as e:  # noqa: BLE001 — broad-catch fallback
        # Flow registry must always succeed; if it does not, surface
        # via verification_status='unverified' rather than crashing
        # the cascade.
        _logger.warning("flow_config load failed: %s", e)
        configured_kinds = ["pythia_hammer", "pythia_lookup", "lean_audit"]

    ctx = {
        "target_path": target_path,
        "source": source,
        "lake_project": lake_project,
        "timeout_sec": timeout_sec,
        "goal_class": goal_class,
        "registry": registry,
    }

    # Run each configured step that has a handler.  Step return values
    # populate ctx so later steps can branch on earlier outputs.
    hammer_closed = False
    entries: list[dict] = []
    audit_result: Any = None
    audit_step_ran = False

    for kind in configured_kinds:
        handler = _LEAN_STEP_HANDLERS.get(kind)
        if handler is None:
            continue  # Unknown kind — skip; future PR adds step-kind validation
        try:
            if kind == "pythia_hammer":
                hammer_closed = handler(**ctx)
            elif kind == "pythia_lookup":
                entries = handler(**ctx)
            elif kind == "lean_audit":
                audit_result = handler(**ctx)
                audit_step_ran = True
        except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
            return _finalize_with_flow(RouterResult(
                success=False,
                target_type="lean",
                engine_used=f"lean_step_{kind}",
                error=str(e),
                pythia_entries=entries,
                theorem_name=thm_name,
            ), flow_name, flow_version)

    # ATH-949 (2026-05-03 CTO): the lean_audit step is REQUIRED for
    # the cascade to mint a machine_verified verdict. Without it we
    # have no axiom-clean / banned-construct signal, so the safe
    # default is unverified — matches the "no silent success" rule.
    if not audit_step_ran:
        return _finalize_with_flow(RouterResult(
            success=False,
            target_type="lean",
            engine_used="lean_verify",
            verification_status="unverified",
            error="lean_audit step missing from cascade — no audit signal available",
            pythia_entries=entries,
            theorem_name=thm_name,
        ), flow_name, flow_version)

    # ATH-949 verdict synthesis: was {compiles + not has_sorry} → silent-
    # success when banned construct / forbidden axiom was present. Now
    # uses the same precedence as ProofResult.status (post ATH-948):
    # banned > axiom_clean=False > full_proof. ProofResult is a
    # dataclass; supports either dataclass or dict shape for forward-
    # compat with mocked test fixtures.
    def _field(obj: Any, name: str, default: Any) -> Any:
        if hasattr(obj, name):
            return getattr(obj, name)
        if hasattr(obj, "get"):
            return obj.get(name, default)
        return default

    compiles = _field(audit_result, "compiles", False)
    has_sorry = _field(audit_result, "has_sorry", True)
    banned = _field(audit_result, "banned", None)
    axiom_clean = _field(audit_result, "axiom_clean", None)

    is_machine_verified = (
        compiles
        and not has_sorry
        and not banned
        and axiom_clean is not False
    )

    if is_machine_verified:
        return _finalize_with_flow(RouterResult(
            success=True,
            target_type="lean",
            engine_used="lean_verify",
            result=audit_result,
            verification_status="machine_verified",
            pythia_entries=entries,
            theorem_name=thm_name,
        ), flow_name, flow_version)

    # ATH-949: kernel-accepted but audit caught a soundness violation
    # → unverified (NOT machine_verified). Customer-facing error text
    # tells them WHICH gate failed.
    if compiles and not has_sorry and (banned or axiom_clean is False):
        if banned:
            err_msg = f"audit refused: banned construct ({banned})"
        else:
            forbidden = _field(audit_result, "forbidden_axioms", [])
            err_msg = (
                f"audit refused: forbidden axiom(s) "
                f"{list(forbidden)[:3]} — likely sorry leak"
            )
        return _finalize_with_flow(RouterResult(
            success=False,
            target_type="lean",
            engine_used="lean_verify",
            result=audit_result,
            verification_status="unverified",
            error=err_msg,
            pythia_entries=entries,
            theorem_name=thm_name,
        ), flow_name, flow_version)
    if hammer_closed and compiles and not has_sorry and not banned and axiom_clean is not False:
        return _finalize_with_flow(RouterResult(
            success=True,
            target_type="lean",
            engine_used="pythia_hammer",
            result=audit_result,
            verification_status="machine_verified",
            pythia_entries=entries,
            theorem_name=thm_name,
        ), flow_name, flow_version)
    if entries:
        return _finalize_with_flow(RouterResult(
            success=False,
            target_type="lean",
            engine_used="pythia_template_lookup",
            result=audit_result,
            verification_status="unverified",
            error="pythia! did not close; template entries available",
            pythia_entries=entries,
            theorem_name=thm_name,
        ), flow_name, flow_version)
    return _finalize_with_flow(RouterResult(
        success=False,
        target_type="lean",
        engine_used="lean_verify",
        result=audit_result,
        verification_status="unverified",
        error=_field(audit_result, "errors_head", "proof incomplete"),
        pythia_entries=entries,
        theorem_name=thm_name,
    ), flow_name, flow_version)


_SV_FLOW_NAME = "default-sv-cascade"
_SV_FLOW_VERSION = "1.1.0"
_ACL2_FLOW_NAME = "default-acl2-cascade"
_ACL2_FLOW_VERSION = "1.1.0"


def _load_sv_flow():
    """Load the bundled SV cascade flow config."""
    from kairos.flow_schema import load_flow

    bundled = (
        Path(__file__).resolve().parent / "flows"
        / f"{_SV_FLOW_NAME}-v{_SV_FLOW_VERSION}.yaml"
    )
    return load_flow(bundled)


def _load_acl2_flow():
    """Load the bundled ACL2 cascade flow config."""
    from kairos.flow_schema import load_flow

    bundled = (
        Path(__file__).resolve().parent / "flows"
        / f"{_ACL2_FLOW_NAME}-v{_ACL2_FLOW_VERSION}.yaml"
    )
    return load_flow(bundled)


def _sv_step_orchestrate(
    *, target_path: Path, top_module: str, source_files,
    flatten: bool, reset_expr, extra_args, acl2_script,
    timeout_sec: int, **_,
):
    """Drive kairos.sv.orchestrate with the resolved arguments
    (single-step opaque mode, v1.0.0 fallback)."""
    from kairos.sv.orchestrate import orchestrate

    return orchestrate(
        str(target_path),
        top_module=top_module,
        source_files=source_files,
        flatten=flatten,
        reset_expr=reset_expr,
        extra_args=extra_args,
        timeout_per_step_sec=timeout_sec,
        acl2_script=acl2_script,
    )


# ATH-912 Phase 1.1: granular step handlers for the multi-step v1.1.0
# cascade.  Each handler does ONE thing and updates the shared ctx
# dict; downstream steps read prior results via ctx and short-circuit
# if a prior step already landed verification_status='machine_verified'.
# The granularity lets engineers compose against individual stages
# (e.g. swap sv_flatten for a custom ghost-tag preprocessor) without
# forking the whole orchestration pipeline.

def _sv_step_flatten(
    *, all_files: list[str], **_,
) -> dict:
    """Flatten SV files for EBMC compatibility."""
    import tempfile

    from kairos.sv.flatten import flatten_files

    flat_dir = Path(tempfile.mkdtemp(prefix="kairos_sv_flat_"))
    flatten_files([Path(f) for f in all_files], output_dir=flat_dir)
    return {"all_files": [str(flat_dir / Path(f).name) for f in all_files]}


def _sv_step_ebmc_bmc(
    *, all_files: list[str], top_module: str,
    bounds: list[int] | None = None,
    reset_expr, extra_args, timeout_sec: int,
    verification_status: str = "unverified",
    **_,
) -> dict:
    """Run EBMC in BMC mode across the configured bounds.  Stops at
    the first PROVED verdict."""
    if verification_status == "machine_verified":
        return {}
    from kairos.sv.ebmc import run_ebmc

    bounds = bounds or [2, 5, 10]
    last_result = None
    for bound in bounds:
        r = run_ebmc(
            all_files, top_module=top_module, bound=bound, mode="bmc",
            reset_expr=reset_expr, extra_args=extra_args,
            timeout_sec=timeout_sec,
        )
        last_result = r
        if r.proved > 0 and r.refuted == 0 and not r.timed_out:
            return {
                "bmc_result": r,
                "verification_status": "machine_verified",
                "engine_used": f"bmc_bound_{bound}",
            }
        if r.refuted > 0:
            # A real refutation is final; no point escalating.
            return {
                "bmc_result": r,
                "verification_status": "refuted",
                "engine_used": f"bmc_bound_{bound}",
            }
    return {"bmc_result": last_result}


def _sv_step_ebmc_kinduction(
    *, all_files: list[str], top_module: str,
    k_max: int = 10, reset_expr, extra_args, timeout_sec: int,
    verification_status: str = "unverified",
    **_,
) -> dict:
    """Run EBMC in k-induction mode for an unbounded proof."""
    if verification_status == "machine_verified":
        return {}
    from kairos.sv.ebmc import run_ebmc

    r = run_ebmc(
        all_files, top_module=top_module, bound=k_max, mode="k_induction",
        reset_expr=reset_expr, extra_args=extra_args,
        timeout_sec=timeout_sec,
    )
    if r.proved > 0 and r.refuted == 0 and not r.timed_out:
        return {
            "kind_result": r,
            "verification_status": "machine_verified",
            "engine_used": "k_induction",
        }
    return {"kind_result": r}


def _sv_step_cegar_loop(
    *, all_files: list[str], top_module: str,
    max_iter: int = 5, bound: int = 10,
    reset_expr, extra_args, timeout_sec: int,
    verification_status: str = "unverified",
    **_,
) -> dict:
    """Run incremental CEGAR (the BTOR2-style incremental 10-step loop)."""
    if verification_status == "machine_verified":
        return {}
    from kairos.sv.cegar_incremental import incremental_cegar

    r = incremental_cegar(
        all_files,
        top_module=top_module,
        bound=bound,
        max_iter=max_iter,
        reset_expr=reset_expr,
        extra_args=extra_args,
        timeout_per_step_sec=timeout_sec,
    )
    if r.proved:
        return {
            "cegar_result": r,
            "verification_status": "machine_verified",
            "engine_used": "cegar",
        }
    return {"cegar_result": r}


def _sv_step_acl2_fgl_refinement(
    *, all_files: list[str], top_module: str,
    timeout_sec: int = 1200,
    verification_status: str = "unverified",
    **_,
) -> dict:
    """Pivot to ACL2/FGL refinement when bounded methods cannot close.
    Single-trust-root machine-checked proof via VL+SVEX+FGL."""
    if verification_status == "machine_verified":
        return {}
    from kairos.acl2 import refinement_prove

    try:
        r = refinement_prove(
            sv_files=all_files,
            spec_module=top_module,
            impl_module=top_module,
            theorem_name="cascade-fgl-refinement",
            timeout_sec=timeout_sec,
        )
        if r.success:
            return {
                "fgl_result": r,
                "verification_status": "machine_verified",
                "engine_used": "acl2_fgl_refinement",
            }
        return {"fgl_result": r}
    except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
        _logger.warning("acl2_fgl_refinement step failed: %s", e)
        return {}


_SV_STEP_HANDLERS = {
    "sv_orchestrate": _sv_step_orchestrate,           # v1.0.0 opaque-mode fallback
    "sv_flatten": _sv_step_flatten,
    "ebmc_bmc": _sv_step_ebmc_bmc,
    "ebmc_kinduction": _sv_step_ebmc_kinduction,
    "cegar_loop": _sv_step_cegar_loop,
    "acl2_fgl_refinement": _sv_step_acl2_fgl_refinement,
}


def _sv_prove_cascade(
    target: str | Path,
    property: str | None = None,
    *,
    engines: EngineAvailability,
    timeout_sec: int = 300,
    **kwargs: Any,
) -> RouterResult:
    """SV engine path: delegate to kairos.sv.orchestrate.

    ATH-912 Phase 1: cascade ordering read from
    ``src/kairos/flows/default-sv-cascade-v1.0.0.yaml``.  flow_config
    event emitted at entry so every solve_run is traceable to the
    flow version.  Today the cascade has one step (sv_orchestrate);
    future flows can override the single-step shape with a multi-
    step cascade by committing a new YAML file.
    """
    from kairos.flow_schema import emit_flow_config

    target_path = Path(target).resolve()
    source_files = kwargs.get("source_files")
    top_module = kwargs.get("top_module", "")

    if not top_module:
        try:
            content = target_path.read_text()
            m = re.search(r"^\s*module\s+(\w+)", content, re.MULTILINE)
            if m:
                top_module = m.group(1)
        except OSError:
            pass

    flow_name: str | None = None
    flow_version: str | None = None
    configured_steps: list[tuple[str, dict]] = []
    try:
        flow = _load_sv_flow()
        emit_flow_config(flow, run_subtype="theorem_proving")
        configured_steps = [(s.kind, s.params) for s in flow.steps]
        flow_name = flow.name
        flow_version = flow.version
        # ATH-914: pre-flight contract validation (warn-only).
        _validate_flow_contracts_warn_only(
            flow_name, flow_version, [k for k, _ in configured_steps],
            run_subtype="theorem_proving",
        )
    except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
        _logger.warning("flow_config load failed for sv cascade: %s", e)
        configured_steps = [("sv_orchestrate", {})]

    # Resolve initial source files set (target + any extras).
    all_files = [str(target_path)]
    if source_files:
        all_files += [str(Path(f).resolve()) for f in source_files]

    ctx: dict[str, Any] = {
        "target_path": target_path,
        "top_module": top_module,
        "source_files": source_files,
        "all_files": all_files,
        "flatten": kwargs.get("flatten", True),
        "reset_expr": kwargs.get("reset_expr"),
        "extra_args": kwargs.get("extra_args"),
        "acl2_script": kwargs.get("acl2_script"),
        "timeout_sec": timeout_sec,
        "verification_status": "unverified",
    }

    legacy_orchestrate_result = None
    last_step_kind: str | None = None
    for kind, step_params in configured_steps:
        handler = _SV_STEP_HANDLERS.get(kind)
        if handler is None:
            continue
        last_step_kind = kind
        # Merge step params into ctx (step's params win on conflict).
        step_ctx = {**ctx, **step_params}
        try:
            if kind == "sv_orchestrate":
                legacy_orchestrate_result = handler(**step_ctx)
                if legacy_orchestrate_result.all_proved:
                    ctx["verification_status"] = "machine_verified"
                    ctx["engine_used"] = "sv_orchestrate"
                break  # opaque mode is single-step by design
            else:
                update = handler(**step_ctx) or {}
                ctx.update(update)
                if ctx.get("verification_status") == "refuted":
                    break
        except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
            return _finalize_with_flow(RouterResult(
                success=False,
                target_type="systemverilog",
                engine_used=f"sv_step_{kind}",
                error=str(e),
            ), flow_name, flow_version)

    # Verdict synthesis. Legacy v1.0.0 path: orchestrate result drives.
    # v1.1.0 path: ctx['verification_status'] tracks across granular steps.
    if legacy_orchestrate_result is not None:
        return _finalize_with_flow(RouterResult(
            success=legacy_orchestrate_result.all_proved,
            target_type="systemverilog",
            engine_used="sv_orchestrate",
            result=legacy_orchestrate_result,
            verification_status=("machine_verified" if legacy_orchestrate_result.all_proved
                                 else "unverified"),
        ), flow_name, flow_version)

    final_status = ctx.get("verification_status", "unverified")
    success = final_status == "machine_verified"
    engine_used = ctx.get("engine_used") or last_step_kind or "sv_cascade"
    final_result = (
        ctx.get("fgl_result")
        or ctx.get("cegar_result")
        or ctx.get("kind_result")
        or ctx.get("bmc_result")
    )
    return _finalize_with_flow(RouterResult(
        success=success,
        target_type="systemverilog",
        engine_used=engine_used,
        result=final_result,
        verification_status=final_status,
    ), flow_name, flow_version)


def _acl2_step_verify(*, target: str | Path, timeout_sec: int, **_):
    """Drive kairos.acl2.verify (single-step opaque mode, v1.0.0 fallback)."""
    from kairos.acl2 import verify

    return verify(script=str(target), timeout_sec=timeout_sec)


# ATH-912 Phase 1.1 granular ACL2 steps.  The two-book pattern in
# kairos.acl2.refinement_prove already runs vl_load + vl_to_svex +
# fgl_bit_blast in one pass, so today these handlers are co-resolved
# from a single refinement_prove call -- the granularity is in step
# NAMING + per-step trace events for now, with full decoupling
# planned for Phase 2 once typed I/O contracts land.

def _acl2_step_vl_load(
    *, target: str | Path, source_files: list[str] | None = None,
    top_module: str = "", timeout_sec: int = 120,
    verification_status: str = "unverified",
    **_,
) -> dict:
    """Parse SV via VL -- emits vl_load trace event so downstream
    composition can hook the parsed VL design without re-parsing."""
    if verification_status == "machine_verified":
        return {}
    # Phase 1.1: this step records its run via flow_config event
    # propagation; the actual VL parse happens inside fgl_bit_blast's
    # refinement_prove call.  Phase 2 will split this into a real
    # standalone VL load that returns a parsed *vl-design* in ctx.
    return {"vl_load_attempted": True}


def _acl2_step_vl_to_svex(
    *, verification_status: str = "unverified", **_,
) -> dict:
    """VL design to SVEX translation step.  Today co-resolved with
    fgl_bit_blast inside refinement_prove; here for traceability and
    future Phase 2 step replacement."""
    if verification_status == "machine_verified":
        return {}
    return {"vl_to_svex_attempted": True}


def _acl2_step_fgl_bit_blast(
    *, target: str | Path, source_files: list[str] | None = None,
    top_module: str = "", target_signal: str = "halted",
    timeout_sec: int = 600,
    verification_status: str = "unverified",
    **_,
) -> dict:
    """Drive the ACL2/FGL refinement proof via the two-book pattern.
    Subsumes vl_load + vl_to_svex inside refinement_prove until
    Phase 2 splits them out."""
    if verification_status == "machine_verified":
        return {}
    from kairos.acl2 import refinement_prove

    sv_files = list(source_files) if source_files else [str(target)]
    try:
        r = refinement_prove(
            sv_files=sv_files,
            spec_module=top_module or Path(target).stem,
            impl_module=top_module or Path(target).stem,
            theorem_name="cascade-fgl-refinement",
            timeout_sec=timeout_sec,
        )
        if r.success:
            return {
                "fgl_result": r,
                "verification_status": "machine_verified",
                "engine_used": "acl2_fgl",
            }
        return {"fgl_result": r}
    except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
        _logger.warning("fgl_bit_blast step failed: %s", e)
        return {}


_ACL2_STEP_HANDLERS = {
    "acl2_verify": _acl2_step_verify,                  # v1.0.0 opaque-mode fallback
    "vl_load": _acl2_step_vl_load,
    "vl_to_svex": _acl2_step_vl_to_svex,
    "fgl_bit_blast": _acl2_step_fgl_bit_blast,
}


def _acl2_prove(
    target: str | Path,
    *,
    engines: EngineAvailability,
    timeout_sec: int = 300,
    **kwargs: Any,
) -> RouterResult:
    """ACL2 engine path.

    ATH-912 Phase 1: cascade ordering read from
    ``src/kairos/flows/default-acl2-cascade-v1.0.0.yaml``.
    """
    from kairos.flow_schema import emit_flow_config

    flow_name: str | None = None
    flow_version: str | None = None
    configured_steps: list[tuple[str, dict]] = []
    try:
        flow = _load_acl2_flow()
        emit_flow_config(flow, run_subtype="theorem_proving")
        configured_steps = [(s.kind, s.params) for s in flow.steps]
        flow_name = flow.name
        flow_version = flow.version
        # ATH-914: pre-flight contract validation (warn-only).
        _validate_flow_contracts_warn_only(
            flow_name, flow_version, [k for k, _ in configured_steps],
            run_subtype="theorem_proving",
        )
    except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
        _logger.warning("flow_config load failed for acl2 cascade: %s", e)
        configured_steps = [("acl2_verify", {})]

    ctx: dict[str, Any] = {
        "target": target,
        "source_files": kwargs.get("source_files"),
        "top_module": kwargs.get("top_module", ""),
        "timeout_sec": timeout_sec,
        "verification_status": "unverified",
    }

    try:
        legacy_verify_result = None
        for kind, step_params in configured_steps:
            handler = _ACL2_STEP_HANDLERS.get(kind)
            if handler is None:
                continue
            step_ctx = {**ctx, **step_params}
            if kind == "acl2_verify":
                # v1.0.0 opaque mode — single-step, returns ACL2Result.
                legacy_verify_result = handler(**step_ctx)
                break
            update = handler(**step_ctx) or {}
            ctx.update(update)

        # v1.0.0 opaque path: ACL2Result drives the verdict.
        if legacy_verify_result is not None:
            return _finalize_with_flow(RouterResult(
                success=legacy_verify_result.all_proved,
                target_type="acl2",
                engine_used="acl2",
                result=legacy_verify_result,
                verification_status=("machine_verified"
                                     if legacy_verify_result.all_proved
                                     else "unverified"),
            ), flow_name, flow_version)

        # v1.1.0 multi-step path.
        final_status = ctx.get("verification_status", "unverified")
        return _finalize_with_flow(RouterResult(
            success=final_status == "machine_verified",
            target_type="acl2",
            engine_used=ctx.get("engine_used") or "acl2_cascade",
            result=ctx.get("fgl_result"),
            verification_status=final_status,
        ), flow_name, flow_version)
    except ImportError:
        return _finalize_with_flow(RouterResult(
            success=False, target_type="acl2", engine_used="acl2",
            error="kairos.acl2 not available",
        ), flow_name, flow_version)
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return _finalize_with_flow(RouterResult(
            success=False, target_type="acl2", engine_used="acl2",
            error=str(e),
        ), flow_name, flow_version)


def prove(
    target: str | Path,
    property: str | None = None,
    *,
    timeout_sec: int = 300,
    **kwargs: Any,
) -> RouterResult:
    """Prove a property about a target. Detects language, selects engine, runs pipeline.

    This is the top-level customer-facing tool. The customer says
    "prove this" — the router figures out the rest.
    """
    engines = _cached_engines()
    target_type = kwargs.pop("target_type", None) or _detect_target_type(target)

    if target_type == "systemverilog":
        return _sv_prove_cascade(target, property, engines=engines, timeout_sec=timeout_sec, **kwargs)
    elif target_type == "lean":
        registry = _load_pythia_registry(engines.lean)
        lake_project = kwargs.pop("lake_project", None) or _detect_lake_project(Path(target))
        return _lean_prove_cascade(
            target, property, engines=engines, registry=registry,
            timeout_sec=timeout_sec, lake_project=lake_project,
        )
    elif target_type == "acl2":
        return _acl2_prove(target, engines=engines, timeout_sec=timeout_sec, **kwargs)
    else:
        return RouterResult(
            success=False,
            target_type=target_type,
            engine_used="none",
            error=f"No engine available for target type '{target_type}'. "
                  f"Supported: .sv, .lean, .lisp/.acl2. Installed: {engines}",
        )


def verify(
    target: str | Path,
    property: str | None = None,
    *,
    timeout_sec: int = 300,
    **kwargs: Any,
) -> RouterResult:
    """Verify a target — exploratory (returns result, does not raise)."""
    return prove(target, property, timeout_sec=timeout_sec, **kwargs)


def spec(
    target: str | Path,
    **kwargs: Any,
) -> dict:
    """Extract or list specification from a target.

    For .sv: PORT reverse-engineering (state, operations, ports, conflicts).
    For .lean: list registered Pythia theorems for the module.
    """
    target_type = kwargs.pop("target_type", None) or _detect_target_type(target)

    if target_type == "lean":
        engines = _cached_engines()
        registry = _load_pythia_registry(engines.lean)
        lake_project = kwargs.get("lake_project")
        module_path = _file_to_module(Path(target), lake_project)
        entries = _pythia_lookup_module(module_path, registry)
        return {
            "target_type": "lean",
            "module": module_path,
            "registered_theorems": entries,
            "count": len(entries),
        }
    elif target_type == "systemverilog":
        try:
            from kairos.port import reverse_engineer
            return reverse_engineer(str(target), **kwargs)
        except ImportError:
            return {
                "target_type": "systemverilog",
                "error": "kairos.port not available — PORT reverse-engineering "
                         "requires the port module (not yet on main).",
            }
    else:
        return {
            "target_type": target_type,
            "error": f"kairos.spec not implemented for '{target_type}'",
        }


def explain(
    result: RouterResult | dict,
    *,
    validate: bool = True,
) -> dict:
    """Grounded explanation of a verification result.

    When validate=True, runs through Pythia.Tactic.PythiaValidate
    before returning (anti-hallucination guardrail).
    """
    if isinstance(result, RouterResult):
        summary = {
            "success": result.success,
            "target_type": result.target_type,
            "engine_used": result.engine_used,
            "verification_status": result.verification_status,
            "error": result.error,
        }
    else:
        summary = dict(result)

    explanation = {
        "summary": summary,
        "validated": False,
        "validation_skipped_reason": None,
    }

    if not validate:
        explanation["validation_skipped_reason"] = "validate=False"
    elif summary.get("target_type") == "lean":
        theorem_name = None
        if isinstance(result, RouterResult):
            theorem_name = result.theorem_name
        if not theorem_name and isinstance(result, dict):
            theorem_name = result.get("theorem_name")
        if not theorem_name:
            explanation["validation_skipped_reason"] = "no theorem_name extracted from result"
        else:
            lean = shutil.which("lean")
            if not lean:
                explanation["validation_skipped_reason"] = "lean binary not found"
            else:
                try:
                    val_result = subprocess.run(
                        [lean, "--run", "-"],
                        input=f"import Pythia.Tactic.PythiaValidate\n#pythia_validate {theorem_name}\n",
                        capture_output=True, text=True, timeout=30,
                        env=safe_env_for_eval_bash_host(),
                    )
                    output = val_result.stdout
                    end = output.find("complete for")
                    if end >= 0:
                        output = output[:end + len("complete for") + 50]
                    explanation["pythia_validation"] = output
                    explanation["validated"] = True
                    explanation["validation_skipped_reason"] = None
                except Exception as e:  # noqa: BLE001 — broad-catch fallback
                    explanation["validation_error"] = str(e)
    elif summary.get("target_type") in ("systemverilog", "acl2"):
        explanation["validation_skipped_reason"] = (
            f"Pythia validation not applicable to {summary['target_type']} targets — "
            f"verification_status from tool output is the guardrail"
        )

    return explanation


def diff(
    impl_a: str | Path,
    impl_b: str | Path,
    *,
    n_cases: int = 100,
    **kwargs: Any,
) -> dict:
    """Differential testing between two implementations."""
    try:
        from kairos.diff_test import diff_test
        return diff_test(impl_a, impl_b, n_cases=n_cases, **kwargs)
    except ImportError:
        return {"error": "kairos.diff_test not available", "n_cases": n_cases}


def mutate(
    target: str | Path,
    test_suite: str | Path | None = None,
    *,
    max_mutants: int = 50,
    **kwargs: Any,
) -> dict:
    """Mutation testing on a verified artifact."""
    try:
        from kairos.mutation_test import mutation_test
        return mutation_test(target, test_suite=test_suite, max_mutants=max_mutants, **kwargs)
    except ImportError:
        return {"error": "kairos.mutation_test not available", "max_mutants": max_mutants}


__all__ = [
    "prove",
    "verify",
    "diff",
    "mutate",
    "spec",
    "explain",
    "detect_engines",
    "list_flows",
    "RouterResult",
    "EngineAvailability",
]


def list_flows():
    """Return all bundled :class:`kairos.flow_schema.FlowConfig` flows.

    ATH-912 Phase 1 acceptance criterion: ``kairos.router.list_flows()``
    returns named flows with versions.  Walks ``src/kairos/flows/``
    via the schema module's registry helper.  Re-exported here so
    customers don't need to know the schema module path.
    """
    from kairos.flow_schema import list_flows as _list_flows

    return _list_flows()
