"""RTL comment stripping for prompt injection defense.

Strips non-formal comments from SystemVerilog/Verilog before feeding
to the LLM proposer. Preserves:
- `ifdef FORMAL / `endif blocks (contain SVA properties)
- Code structure and whitespace
- String literals

Removes:
- // single-line comments (potential injection vectors)
- /* multi-line comments */ (potential injection vectors)

This prevents customers from embedding LLM instructions in RTL
comments that could trick the proposer into generating unsafe designs.
"""
from __future__ import annotations

import re


def strip_rtl_comments(source: str, preserve_formal: bool = True) -> str:
    """Strip comments from RTL source, preserving formal blocks.

    Args:
        source: raw SystemVerilog/Verilog source text
        preserve_formal: if True, keep everything inside
            `ifdef FORMAL / `endif blocks intact

    Returns:
        source with comments removed (formal blocks preserved)
    """
    if preserve_formal:
        formal_blocks: list[tuple[int, int]] = []
        for m in re.finditer(
            r"`ifdef\s+FORMAL\b.*?`endif",
            source,
            re.DOTALL,
        ):
            formal_blocks.append((m.start(), m.end()))

    lines = source.split("\n")
    result: list[str] = []
    in_block_comment = False
    pos = 0

    for line in lines:
        line_start = pos
        line_end = pos + len(line)
        pos = line_end + 1

        if preserve_formal and _in_formal_block(line_start, line_end, formal_blocks):
            result.append(line)
            continue

        if in_block_comment:
            end_idx = line.find("*/")
            if end_idx >= 0:
                in_block_comment = False
                result.append(line[end_idx + 2:])
            else:
                result.append("")
            continue

        cleaned = _strip_line_comments(line)

        block_start = cleaned.find("/*")
        if block_start >= 0:
            block_end = cleaned.find("*/", block_start + 2)
            if block_end >= 0:
                cleaned = cleaned[:block_start] + cleaned[block_end + 2:]
            else:
                in_block_comment = True
                cleaned = cleaned[:block_start]

        result.append(cleaned)

    return "\n".join(result)


def _strip_line_comments(line: str) -> str:
    """Remove // comments, respecting string literals."""
    in_string = False
    escape = False
    for i, ch in enumerate(line):
        if escape:
            escape = False
            continue
        if ch == "\\":
            escape = True
            continue
        if ch == '"':
            in_string = not in_string
        if not in_string and i + 1 < len(line) and line[i:i+2] == "//":
            return line[:i]
    return line


def _in_formal_block(
    line_start: int,
    line_end: int,
    formal_blocks: list[tuple[int, int]],
) -> bool:
    """Check if a line falls within any `ifdef FORMAL block."""
    for start, end in formal_blocks:
        if line_start >= start and line_end <= end:
            return True
    return False


__all__ = ["strip_rtl_comments"]
