"""ATH-1200 phase 2: lazy-imported boto3 helpers for `kairos config s3`.

Customer flows:
- `kairos config s3 <bucket>` calls `verify_bucket()` which:
  1. Tries `head_bucket()` on the supplied name.
  2. 404 → bucket not found (offer auto-create in phase 2b; for now,
     emit clear error + AWS-CLI create-bucket hint).
  3. 403 → bucket exists but PutObject/HeadBucket denied. Emit the
     exact IAM policy JSON the customer needs to attach.
  4. 200 → bucket exists and accessible; run `iam_smoke_check()` to
     confirm PutObject + DeleteObject work end-to-end.

boto3 is lazy-imported (matches the litellm pattern in providers.py)
so `pip install athanor-sdk` stays light. Customers who never touch
S3 don't pay the install cost. Missing boto3 surfaces as a friendly
hint pointing at the `[s3]` install extra.

Security:
- IAM smoke uploads a 1-byte test object to `customer-traces/_athanor-smoke-<uuid>`
  then immediately deletes it. Never a real trace artifact.
- The persisted bedrock-key is NEVER read by this module; boto3 uses
  its own AWS credential chain (env / ~/.aws/credentials / IAM role).
- `generate_iam_policy_for_bucket()` returns least-privilege scope:
  PutObject + GetObject + DeleteObject on `arn:aws:s3:::<bucket>/customer-traces/*`
  and ListBucket on the bucket root (needed for the smoke check's
  HeadObject precheck). No bucket-policy admin grants.
"""
from __future__ import annotations

import json
import uuid
from typing import Any


BOTO3_MISSING_HINT = (
    "boto3 not installed. To use S3 trace bucket persistence:\n"
    "    pip install boto3\n"
    "Or install athanor-sdk with the [s3] extra (when published):\n"
    "    pip install 'athanor-sdk[s3]'\n"
    "If you intend to set the bucket name WITHOUT running the boto3\n"
    "verification (e.g., in CI before AWS keys are available), use:\n"
    "    kairos config s3 <bucket> --no-verify"
)


def _require_boto3() -> Any:
    """Lazy-import boto3; raise ImportError with friendly hint if missing."""
    try:
        import boto3  # type: ignore[import-not-found]  # noqa: F401 — presence check
        return boto3
    except ImportError as e:
        raise ImportError(BOTO3_MISSING_HINT) from e


# Result-status labels. Pinned by tests + doctor output; keep stable.
VERIFY_OK = "ok"
VERIFY_BUCKET_NOT_FOUND = "bucket_not_found"
VERIFY_FORBIDDEN = "forbidden"
VERIFY_NO_CREDENTIALS = "no_credentials"
VERIFY_OTHER_ERROR = "other_error"


def verify_bucket(bucket: str, region: str | None = None) -> dict[str, Any]:
    """Run head_bucket + iam_smoke_check against the supplied bucket.

    Returns a dict with at minimum:
    - `status`: one of VERIFY_* constants.
    - `detail`: human-readable explanation.
    - `fix_hint`: actionable next step (CLI command / IAM policy JSON).
    - `bucket`: echoed bucket name (for log context).
    - `region`: echoed region (or "default" if unset).

    Does not raise on AWS errors; converts them to status labels so
    the caller can render structured CLI output. ImportError on
    missing boto3 IS raised (different failure class).
    """
    boto3 = _require_boto3()
    from botocore.exceptions import ClientError, NoCredentialsError  # type: ignore[import-not-found]

    region_label = region or "(default — boto3 will pick from env or ~/.aws/config)"
    s3_kwargs: dict[str, Any] = {}
    if region:
        s3_kwargs["region_name"] = region
    client = boto3.client("s3", **s3_kwargs)

    # Step 1: HeadBucket — exists + accessible?
    try:
        client.head_bucket(Bucket=bucket)
    except NoCredentialsError:
        return {
            "status": VERIFY_NO_CREDENTIALS,
            "detail": "boto3 found no AWS credentials in env / ~/.aws/credentials / instance metadata",
            "fix_hint": (
                "Set AWS credentials via one of:\n"
                "  export AWS_ACCESS_KEY_ID=... AWS_SECRET_ACCESS_KEY=...\n"
                "  Or: aws configure  (writes ~/.aws/credentials)\n"
                "  Or: attach an IAM role to this EC2/Lambda instance"
            ),
            "bucket": bucket,
            "region": region_label,
        }
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "Unknown")
        if code in ("404", "NoSuchBucket"):
            return {
                "status": VERIFY_BUCKET_NOT_FOUND,
                "detail": f"bucket {bucket!r} does not exist (404)",
                "fix_hint": (
                    f"Create the bucket with:\n"
                    f"  aws s3api create-bucket --bucket {bucket}"
                    + (f" --region {region}" if region else "")
                    + (
                        f" --create-bucket-configuration LocationConstraint={region}"
                        if region and region != "us-east-1"
                        else ""
                    )
                    + "\n\nRecommended defaults (apply after create):\n"
                    f"  aws s3api put-public-access-block --bucket {bucket} "
                    "--public-access-block-configuration "
                    "BlockPublicAcls=true,IgnorePublicAcls=true,"
                    "BlockPublicPolicy=true,RestrictPublicBuckets=true\n"
                    f"  aws s3api put-bucket-versioning --bucket {bucket} "
                    "--versioning-configuration Status=Enabled\n"
                    f"  aws s3api put-bucket-encryption --bucket {bucket} "
                    '--server-side-encryption-configuration '
                    '\'{"Rules":[{"ApplyServerSideEncryptionByDefault":'
                    '{"SSEAlgorithm":"AES256"}}]}\''
                ),
                "bucket": bucket,
                "region": region_label,
            }
        if code in ("403", "Forbidden", "AccessDenied"):
            return {
                "status": VERIFY_FORBIDDEN,
                "detail": (
                    f"bucket {bucket!r} exists but the AWS credentials in "
                    "boto3's credential chain don't have HeadBucket / "
                    "PutObject access"
                ),
                "fix_hint": (
                    "Attach this IAM policy to your access key / role:\n\n"
                    + json.dumps(generate_iam_policy_for_bucket(bucket), indent=2)
                    + "\n\nVia CLI (replace <user-name>):\n"
                    + f"  aws iam put-user-policy --user-name <user-name> "
                    f"--policy-name AthanorKairosTracesAccess --policy-document "
                    f"'$(cat <<'EOJSON'\n"
                    + json.dumps(generate_iam_policy_for_bucket(bucket))
                    + "\nEOJSON\n)'"
                ),
                "bucket": bucket,
                "region": region_label,
            }
        return {
            "status": VERIFY_OTHER_ERROR,
            "detail": f"AWS ClientError {code}: {e.response.get('Error', {}).get('Message', '')}",
            "fix_hint": "Check AWS console for the bucket + IAM state; rerun with --no-verify to skip.",
            "bucket": bucket,
            "region": region_label,
        }

    # Step 2: IAM smoke — PutObject + DeleteObject on a 1-byte test key.
    smoke = iam_smoke_check(bucket, client=client)
    if smoke["status"] != VERIFY_OK:
        return smoke

    return {
        "status": VERIFY_OK,
        "detail": f"bucket {bucket!r} accessible + PutObject/DeleteObject confirmed",
        "fix_hint": "",
        "bucket": bucket,
        "region": region_label,
    }


def iam_smoke_check(bucket: str, *, client: Any = None) -> dict[str, Any]:
    """Try to PutObject + DeleteObject a 1-byte test key under the bucket.

    Test key is `customer-traces/_athanor-smoke-<uuid>` so it never collides with real
    trace artifacts; immediately deleted. Returns the same shape as
    `verify_bucket()`.

    If `client` is None, a fresh `boto3.client('s3')` is constructed
    (no region pinning — relies on env / ~/.aws/config).
    """
    if client is None:
        boto3 = _require_boto3()
        client = boto3.client("s3")
    from botocore.exceptions import ClientError

    # ATH-1200 customer-correctness fix (research catch 2026-05-14):
    # the least-privilege IAM policy scopes `customer-traces/*` but the
    # smoke key MUST also live UNDER that prefix; otherwise customer
    # attaches the correct policy + re-runs verify → smoke PutObject
    # denied → 403 right after they "fixed" their IAM. Mirror the
    # production layout exactly.
    test_key = f"customer-traces/_athanor-smoke-{uuid.uuid4().hex[:12]}"
    try:
        client.put_object(Bucket=bucket, Key=test_key, Body=b"x")
    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "Unknown")
        if code in ("403", "AccessDenied"):
            return {
                "status": VERIFY_FORBIDDEN,
                "detail": (
                    f"HeadBucket on {bucket!r} succeeded but PutObject "
                    f"denied: {code}"
                ),
                "fix_hint": (
                    "Attach this IAM policy to your access key / role:\n\n"
                    + json.dumps(generate_iam_policy_for_bucket(bucket), indent=2)
                ),
                "bucket": bucket,
                "region": "(see verify_bucket caller)",
            }
        return {
            "status": VERIFY_OTHER_ERROR,
            "detail": f"PutObject failed: {code} {e.response.get('Error', {}).get('Message', '')}",
            "fix_hint": "Check AWS console for IAM + bucket policy state.",
            "bucket": bucket,
            "region": "(see verify_bucket caller)",
        }

    # Best-effort cleanup; if DeleteObject fails the customer's bucket
    # has a stray 1-byte file but we don't fail the verify.
    try:
        client.delete_object(Bucket=bucket, Key=test_key)
    except ClientError:
        pass

    return {
        "status": VERIFY_OK,
        "detail": f"PutObject + DeleteObject confirmed on {bucket!r}",
        "fix_hint": "",
        "bucket": bucket,
        "region": "(see verify_bucket caller)",
    }


def generate_iam_policy_for_bucket(bucket: str) -> dict[str, Any]:
    """Least-privilege IAM policy granting trace-upload access to one bucket.

    Scoped to `arn:aws:s3:::<bucket>/customer-traces/*` (write/read/delete)
    plus ListBucket on the root for HeadObject preflight. No bucket-policy
    admin grants. Customer's existing IAM key gets exactly what kairos
    needs and nothing more.
    """
    return {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "AthanorKairosTracesWrite",
                "Effect": "Allow",
                "Action": [
                    "s3:PutObject",
                    "s3:GetObject",
                    "s3:DeleteObject",
                ],
                "Resource": f"arn:aws:s3:::{bucket}/customer-traces/*",
            },
            {
                "Sid": "AthanorKairosTracesList",
                "Effect": "Allow",
                "Action": [
                    "s3:ListBucket",
                ],
                "Resource": f"arn:aws:s3:::{bucket}",
                "Condition": {
                    "StringLike": {
                        "s3:prefix": "customer-traces/*",
                    }
                },
            },
        ],
    }


__all__ = [
    "BOTO3_MISSING_HINT",
    "VERIFY_OK",
    "VERIFY_BUCKET_NOT_FOUND",
    "VERIFY_FORBIDDEN",
    "VERIFY_NO_CREDENTIALS",
    "VERIFY_OTHER_ERROR",
    "verify_bucket",
    "iam_smoke_check",
    "generate_iam_policy_for_bucket",
]
