"""ATH-367 — customer-facing redaction of raw mode_fleet run.json files.

Mode_fleet writes raw `run.json` files with the full LLM conversation,
including the `role: system` message that carries our prompt templates.
Those templates are C-level IP per qa's ATH-341 audit: they encode
anti-failure-mode guidance, banned-construct regex lists, curated
lemma libraries, and per-vertical tool-use sequencing that together
make up ~60% of the company's value.

Before a bundle tarball is handed to a customer, every `run.json` must
go through this redactor. Raw traces never touch customer disk.

## Contract

    redact_for_customer(raw: dict) -> dict

- **Deterministic.** Same input produces byte-identical output on every
  call. Enables audit trails ("this redacted bundle was delivered at
  time Y, SHA-256 Z").
- **Idempotent.** Redacting an already-redacted file is a no-op.
- **Over-strip by default.** Every `role: system` message gets its
  content replaced with a fixed marker, regardless of whether we
  recognize the template. Customers rarely inject system messages
  (they provide task inputs via `role: user`), so false positives are
  rare; false negatives would leak IP.
- **Non-destructive on unknown shapes.** If `raw` doesn't match the
  expected mode_fleet structure (missing `results`, missing
  `per_phase_traces`, etc.), we leave it alone rather than mangling
  it. Redactor prefers doing less over doing harm.

## What's redacted

- `results[*].per_phase_traces[*].messages[*].content` whenever
  `role == "system"` → replaced with the REDACTED_MARKER string.

## What's preserved

- All other message roles (`user`, `assistant`, `tool`) — customer's
  task inputs, agent reasoning, tool call outputs.
- `tool_calls` arrays on assistant messages (the visible agent
  actions are customer-facing evidence, not template IP).
- Per-phase token counts, cost estimates, timings, model identifiers.
- Every non-message field in the run.json.

## Known v1 limitations

- Tool-call arguments that carry nested prompt text (when an agent
  spawns a sub-agent via a tool call passing a wrapped prompt) are
  not currently sanitized. This requires pattern-matching known
  prompt-wrapping templates. File ATH-?? (follow-up) for that work.
- Content arrays containing tool_use parts (Anthropic-style) are
  walked through structurally but their inner strings are not
  pattern-scanned. Same follow-up.

For v1 the regression guard (`tests/test_redactor.py::FORBIDDEN_MARKERS`)
is the trip-wire: if any of our known template phrases ever slips
through redaction into a customer bundle, CI fails the merge.
"""
from __future__ import annotations

from copy import deepcopy
from typing import Any


# Replacement text for redacted system-role message content.
# Versioned so that audit readers can identify which redaction policy
# produced a given bundle.
REDACTED_MARKER: str = "[redacted: athanor system prompt v1]"


def redact_for_customer(raw: Any) -> Any:
    """Return a customer-safe copy of `raw` with system-role content stripped.

    Accepts a dict (the parsed run.json) or any other value. Non-dict
    inputs pass through unchanged (defensive — we should only be called
    with a dict, but we don't want to crash on unexpected inputs and
    produce cryptic stacks at bundle time).

    The input is never mutated. Returns a fresh deepcopy with redaction
    applied.
    """
    if not isinstance(raw, dict):
        return raw

    result = deepcopy(raw)
    _redact_results_inplace(result)
    return result


def _redact_results_inplace(run: dict[str, Any]) -> None:
    """In-place walk of `run["results"][*]["per_phase_traces"][*]["messages"]`."""
    results = run.get("results")
    if not isinstance(results, list):
        return

    for per_result in results:
        if not isinstance(per_result, dict):
            continue
        traces = per_result.get("per_phase_traces")
        if not isinstance(traces, list):
            continue
        for trace in traces:
            if not isinstance(trace, dict):
                continue
            messages = trace.get("messages")
            if not isinstance(messages, list):
                continue
            for msg in messages:
                _redact_message_inplace(msg)


def _redact_message_inplace(msg: Any) -> None:
    """Redact content on a single message if role=system."""
    if not isinstance(msg, dict):
        return
    if msg.get("role") != "system":
        return
    # Over-strip: regardless of whether content is str, list-of-parts,
    # or None, replace with the marker string. Preserving the exact
    # structure of the content field for system messages would leak
    # structural information about our template shape.
    msg["content"] = REDACTED_MARKER


__all__ = ["redact_for_customer", "REDACTED_MARKER"]
