"""kairos.builder.cost_tracker — accumulating cost/token tracker.

Vendored from kairos-builder/solve/shared/cost_tracker.py as the first
slice of the SDK builder-core landing. Identical semantics; only the
model_prices import is rewired to kairos.model_prices (SDK-in-package)
instead of the builder's dynamic path-based loader.

Wraps estimate_cost_usd() from kairos.model_prices into a stateful
accumulator that accepts usage objects from multiple SDK shapes.

FORMAL INVARIANTS
=================
The following must hold at all times across all record() and merge() calls:

I1 NON-NEGATIVITY
    total_cost_usd >= 0.0 always.
    Guaranteed because estimate_cost_usd() returns >= 0 for non-negative token
    counts, and we clamp individual token fields to max(0, ...) on extraction.

I2 MONOTONICITY
    Let C_before = tracker.total_cost_usd before a record() call.
    After the call: tracker.total_cost_usd >= C_before.
    Guaranteed because delta = estimate_cost_usd(...) >= 0 for any token counts
    that survive the max(0, ...) clamp.

I3 ADDITIVITY (merge)
    Let a_before = tracker_a.total_cost_usd.
    After tracker_a.merge(tracker_b):
        tracker_a.total_cost_usd == a_before + tracker_b.total_cost_usd
    (holds within IEEE-754 rounding for large float values).

I4 IDENTITY (merge empty)
    Merging an empty CostTracker (call_count == 0, total_cost_usd == 0) is a
    no-op: all totals are unchanged.
    Follows directly from I3: adding zero cost.

I5 ZERO TOKENS => ZERO DELTA
    record(usage) where all token fields == 0 returns 0.0 and leaves
    total_cost_usd unchanged.
    Follows from estimate_cost_usd returning 0.0 for zero token counts.

Design notes
============
- Multi-model support: per_model_cost / per_model_input / per_model_output
  etc. keyed by model string. Grand total = sum of per-model totals.
- Calibration factor: multiplied into every estimate_cost_usd() call. Default 1.0.
- Thread safety: NOT thread-safe by design (single-threaded pipeline).
  Callers doing multi-threaded dispatch should maintain per-thread instances
  then merge at join points.

Usage shapes accepted by record()
==================================
1. Anthropic SDK response object:
       response.usage.input_tokens           (non-cache input)
       response.usage.output_tokens
       response.usage.cache_read_input_tokens   (may be absent/0)
       response.usage.cache_creation_input_tokens (may be absent/0)

2. litellm / OpenAI response object:
       response.usage.prompt_tokens
       response.usage.completion_tokens
       No cache fields (treated as 0)

3. Plain dict with any of the above keys (or mixed — both shapes tried).

4. An object with a .usage attribute of the above shapes.

In all cases missing fields default to 0. Negative values are clamped to 0.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from kairos.model_prices import estimate_cost_usd as _estimate_cost_usd


def _extract_tokens(usage: Any) -> dict[str, int]:
    """Extract token fields from any supported usage shape.

    Returns a dict with keys:
        input_tokens, output_tokens, cache_read_tokens, cache_create_tokens

    All values are non-negative integers.
    """
    if usage is None:
        return {"input_tokens": 0, "output_tokens": 0,
                "cache_read_tokens": 0, "cache_create_tokens": 0}

    def _get(obj: Any, *keys: str) -> int:
        """Try keys in order; return first non-None non-negative int found."""
        for k in keys:
            # dict access
            if isinstance(obj, dict):
                v = obj.get(k)
            else:
                v = getattr(obj, k, None)
            if v is not None:
                return max(0, int(v))
        return 0

    # Support both .usage wrapper and raw usage object
    raw = usage
    if hasattr(usage, "usage") and not isinstance(usage, dict):
        raw = usage.usage
    elif isinstance(usage, dict) and "usage" in usage and isinstance(usage["usage"], dict):
        raw = usage["usage"]

    input_tokens = _get(raw, "input_tokens", "prompt_tokens")
    output_tokens = _get(raw, "output_tokens", "completion_tokens")
    cache_read_tokens = _get(raw, "cache_read_input_tokens", "cache_read_tokens")
    cache_create_tokens = _get(raw, "cache_creation_input_tokens", "cache_create_tokens")

    return {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cache_read_tokens": cache_read_tokens,
        "cache_create_tokens": cache_create_tokens,
    }


class CostTracker:
    """Stateful accumulator for token counts and USD cost across LLM calls.

    See module docstring for formal invariants.

    Args:
        model: Default LiteLLM model string for all record() calls that
               don't override it (e.g. "anthropic/claude-sonnet-4-6").
        calibration_factor: Multiplied into every cost estimate. Set to
               > 1.0 to be conservative; use actual invoice data to tune.
    """

    def __init__(self, model: str, calibration_factor: float = 1.0) -> None:
        if not model:
            raise ValueError("model must be a non-empty string")
        self._default_model = model
        self._calibration_factor = calibration_factor

        # Grand totals
        self._total_cost_usd: float = 0.0
        self._total_input_tokens: int = 0
        self._total_output_tokens: int = 0
        self._total_cache_read_tokens: int = 0
        self._total_cache_create_tokens: int = 0
        self._call_count: int = 0

        # Per-model breakdown — keyed by model string
        # Values: {"cost_usd", "input_tokens", "output_tokens",
        #          "cache_read_tokens", "cache_create_tokens", "call_count"}
        self._per_model: dict[str, dict[str, Any]] = {}

    # ── Properties (I1: total_cost_usd always >= 0 because we only add non-negatives)

    @property
    def total_cost_usd(self) -> float:
        return self._total_cost_usd

    @property
    def total_input_tokens(self) -> int:
        return self._total_input_tokens

    @property
    def total_output_tokens(self) -> int:
        return self._total_output_tokens

    @property
    def total_cache_read_tokens(self) -> int:
        return self._total_cache_read_tokens

    @property
    def total_cache_create_tokens(self) -> int:
        return self._total_cache_create_tokens

    @property
    def call_count(self) -> int:
        return self._call_count

    @property
    def default_model(self) -> str:
        return self._default_model

    @property
    def calibration_factor(self) -> float:
        return self._calibration_factor

    # ── Core accumulation

    def record(self, usage: Any, model: Optional[str] = None) -> float:
        """Accumulate tokens from one LLM call and return the USD delta.

        Args:
            usage: Any of: Anthropic SDK response, litellm response, plain
                   dict with token fields, or raw usage object/dict.
            model: Model string for this specific call. Overrides the default
                   model for both cost calculation AND per-model subtotals.
                   Must be a non-empty string if supplied.

        Returns:
            The USD cost delta added by this call (>= 0.0).

        Invariant I2 (monotonicity): this value is always >= 0.
        Invariant I5 (zero tokens → zero delta): returns 0.0 if all fields 0.
        """
        effective_model = model if model else self._default_model
        tokens = _extract_tokens(usage)

        delta = _estimate_cost_usd(
            model=effective_model,
            prompt_tokens=tokens["input_tokens"],
            completion_tokens=tokens["output_tokens"],
            cache_creation_tokens=tokens["cache_create_tokens"],
            cache_read_tokens=tokens["cache_read_tokens"],
            calibration_factor=self._calibration_factor,
        )
        # delta is always >= 0.0 (model_prices returns >= 0 for >= 0 tokens)

        self._total_cost_usd += delta
        self._total_input_tokens += tokens["input_tokens"]
        self._total_output_tokens += tokens["output_tokens"]
        self._total_cache_read_tokens += tokens["cache_read_tokens"]
        self._total_cache_create_tokens += tokens["cache_create_tokens"]
        self._call_count += 1

        # Per-model sub-totals
        if effective_model not in self._per_model:
            self._per_model[effective_model] = {
                "cost_usd": 0.0,
                "input_tokens": 0,
                "output_tokens": 0,
                "cache_read_tokens": 0,
                "cache_create_tokens": 0,
                "call_count": 0,
            }
        m = self._per_model[effective_model]
        m["cost_usd"] += delta
        m["input_tokens"] += tokens["input_tokens"]
        m["output_tokens"] += tokens["output_tokens"]
        m["cache_read_tokens"] += tokens["cache_read_tokens"]
        m["cache_create_tokens"] += tokens["cache_create_tokens"]
        m["call_count"] += 1

        result: float = delta
        return result

    def merge(self, other: "CostTracker") -> None:
        """Merge another tracker's totals into this one (in-place).

        Invariant I3 (additivity): self.total_cost_usd after merge equals
        self.total_cost_usd_before + other.total_cost_usd.
        Invariant I4 (identity): merging an empty tracker is a no-op.

        Args:
            other: Another CostTracker instance. Not modified.
        """
        self._total_cost_usd += other._total_cost_usd
        self._total_input_tokens += other._total_input_tokens
        self._total_output_tokens += other._total_output_tokens
        self._total_cache_read_tokens += other._total_cache_read_tokens
        self._total_cache_create_tokens += other._total_cache_create_tokens
        self._call_count += other._call_count

        for model, sub in other._per_model.items():
            if model not in self._per_model:
                self._per_model[model] = {
                    "cost_usd": 0.0,
                    "input_tokens": 0,
                    "output_tokens": 0,
                    "cache_read_tokens": 0,
                    "cache_create_tokens": 0,
                    "call_count": 0,
                }
            m = self._per_model[model]
            m["cost_usd"] += sub["cost_usd"]
            m["input_tokens"] += sub["input_tokens"]
            m["output_tokens"] += sub["output_tokens"]
            m["cache_read_tokens"] += sub["cache_read_tokens"]
            m["cache_create_tokens"] += sub["cache_create_tokens"]
            m["call_count"] += sub["call_count"]

    def snapshot(self) -> dict[str, Any]:
        """Return a serialisable dict of the current totals.

        Keys match solve_runs table columns: token_cost_usd, plus expanded
        token counts for debugging / audit trails.

        Returns:
            {
                "token_cost_usd": float,
                "input_tokens": int,
                "output_tokens": int,
                "cache_read_tokens": int,
                "cache_create_tokens": int,
                "call_count": int,
                "model": str,          # default model for this tracker
                "per_model": dict,     # per-model subtotals
            }
        """
        return {
            "token_cost_usd": round(self._total_cost_usd, 6),
            "input_tokens": self._total_input_tokens,
            "output_tokens": self._total_output_tokens,
            "cache_read_tokens": self._total_cache_read_tokens,
            "cache_create_tokens": self._total_cache_create_tokens,
            "call_count": self._call_count,
            "model": self._default_model,
            "per_model": {
                m: {
                    "cost_usd": round(v["cost_usd"], 6),
                    "input_tokens": v["input_tokens"],
                    "output_tokens": v["output_tokens"],
                    "cache_read_tokens": v["cache_read_tokens"],
                    "cache_create_tokens": v["cache_create_tokens"],
                    "call_count": v["call_count"],
                }
                for m, v in self._per_model.items()
            },
        }

    def write_snapshot(self, path: "str | Path") -> None:
        """Write snapshot() as JSON to path. Used by research harnesses."""
        Path(path).write_text(json.dumps(self.snapshot(), indent=2))

    def __repr__(self) -> str:
        return (
            f"CostTracker(model={self._default_model!r}, "
            f"cost=${self._total_cost_usd:.4f}, "
            f"calls={self._call_count}, "
            f"in={self._total_input_tokens}, out={self._total_output_tokens})"
        )
