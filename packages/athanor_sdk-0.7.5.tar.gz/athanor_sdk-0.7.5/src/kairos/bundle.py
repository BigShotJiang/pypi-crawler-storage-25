"""V1 — customer-facing artifact bundler.

Last mile of the `athanor spec submit` flow: takes the files
`mode_fleet` wrote to `~/.athanor/runs/<run_id>/` and packs them into
a single `bundle.tar.gz` for the customer.

Design invariants (non-negotiable):

    1. Redaction gate: the bundle MUST NOT contain any IP-leak markers.
       We grep every text file we pack against the same FORBIDDEN_MARKERS
       list that `solve/shared/tests/test_redactor.py` uses as the
       regression guard. A hit is a hard fail — we do not ship the
       bundle. Builder-side redaction runs BEFORE this step; this is
       a second line of defence, not a substitute.

    2. Owner-only perms: the tarball lands at mode 0o600 via the same
       `atomic_write_secure()` pattern used elsewhere in sdk_security.

    3. Deterministic manifest: every artifact included lists its size
       + sha256 in a top-level `bundle.json`. Customers can re-verify.
       The manifest is itself included in the tarball.

    4. Path safety: we only pack files from the provided run_dir and
       its direct subdirs. Symlinks outside the dir are refused. No
       `..` components in archived paths.

    5. One run_dir → one bundle. No cross-run bundling, no partial
       bundles. If mode_fleet didn't complete, there's no bundle.

Integration:

    * `athanor spec submit`  →  after dispatch completes, optionally
      calls `create_bundle(run_dir)` to pack. Same CLI flow.
    * `athanor spec bundle <run_id>`  →  standalone post-hoc packaging
      for a completed run.

Both converge on `create_bundle(run_dir: Path) -> Path` which returns
the bundle.tar.gz path on success or raises a typed exception on any
invariant violation.
"""
from __future__ import annotations

from kairos._validate_input import _validate_input_file

import hashlib
import io
import json
import tarfile
import time
from pathlib import Path
from typing import Any, Optional

from kairos.sdk_security import atomic_write_secure


# ─── Config ──────────────────────────────────────────────────────────────

BUNDLE_FILENAME = "bundle.tar.gz"
MANIFEST_FILENAME = "bundle.json"
BUNDLE_FORMAT_VERSION = "1.0"

# Files we pack. Keys are the destination path inside the tarball;
# values are sibling-of-run_dir candidates (first match wins). The
# runner writes different verticals' output to different names.
DEFAULT_ARTIFACT_MAP: dict[str, tuple[str, ...]] = {
    "run.json":           ("run.json",),
    "proof.lean":         ("proof.lean", "proof_closed.lean", "proof_refined.lean"),
    "counterexample.txt": ("counterexample.txt", "counterexample.json"),
    "audit_report.json":  ("audit_report.json",),
    "mutation_report.json": ("mutation_report.json",),
    "property_report.json": ("property_report.json",),
}

MAX_BUNDLE_BYTES = 500 * 1024 * 1024   # 500MB hard cap — anything above
                                       # is a bug or adversarial.
MAX_FILE_BYTES = 100 * 1024 * 1024     # 100MB per file cap.

# Mirror of the FORBIDDEN_MARKERS list that
# `athanor-builder/solve/shared/tests/test_redactor.py` treats as
# regression canaries. A bundle that contains any of these is an IP
# leak and must be refused. Kept in sync manually — when the builder
# updates the list, update this too.
#
# Generic phrases like "You are an expert" were removed from the builder
# list per 2026-04-19 (too noisy). Keep only phrases that are
# vertical-unique to our prompts.
FORBIDDEN_MARKERS: list[str] = [
    # Neuron / kernel-builder
    "You are a coding agent that solves tasks",
    "You MUST use the provided tools",
    "Do NOT just describe what you would do",
    "NKI (Neuron Kernel Interface) kernel",
    "Workflow: read the task files",
    # Lean / theorem-prover
    "You are a Lean 4 theorem prover",
    "Before accepting a hypothesis",
    "unsatisfiable and closes every conclusion",
    # Sysverilog / RTL-fix
    "SystemVerilog Assertions (SVA)",
    "assert property (@(posedge clk)",
    "never `assume property`",
    # Planner / triple-voice audit
    "You are the Phase -1 planner",
    "Banned constructs:",
    "is the fifth element that binds",
]


# ─── Errors ──────────────────────────────────────────────────────────────


class BundleError(RuntimeError):
    """Base class for bundle failures. Caller prints + exits non-zero."""


class RedactionGateError(BundleError):
    """An unredacted IP marker was found in a file about to be packed.

    Raised when a file in the run_dir contains content that matches
    the FORBIDDEN_MARKERS list. Builder-side redaction should have
    removed these; a hit here means the builder's redactor regressed
    or the build was skipped. The bundle is refused so the leaked
    content doesn't ship to the customer.
    """


class BundleInvariantError(BundleError):
    """A path-safety or size-cap invariant was violated.

    Raised when the run_dir contains a symlink pointing outside, a
    file larger than MAX_FILE_BYTES, or the aggregate bundle would
    exceed MAX_BUNDLE_BYTES.
    """


# ─── Helpers ─────────────────────────────────────────────────────────────


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(8192)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _resolve_artifact(run_dir: Path, candidates: tuple[str, ...]) -> Optional[Path]:
    """First-match-wins: look for each candidate at run_dir + run_dir/artifacts/."""
    for name in candidates:
        for prefix in (run_dir, run_dir / "artifacts"):
            p = prefix / name
            if p.is_file():
                return p
    return None


def _scan_for_forbidden_markers(path: Path) -> list[str]:
    """Return a list of FORBIDDEN_MARKERS found in the file, or []."""
    # Only scan text files. Binary artifacts (if we ever add them)
    # wouldn't have legible prompt text by definition.
    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
    except (OSError, UnicodeDecodeError):
        return []  # binary or unreadable; no text leak possible
    hits = [m for m in FORBIDDEN_MARKERS if m in content]
    return hits


def _assert_path_safe(run_dir: Path, path: Path) -> None:
    """Refuse symlinks pointing outside run_dir + any .. traversal."""
    run_dir = run_dir.resolve(strict=True)
    try:
        resolved = path.resolve(strict=True)
    except FileNotFoundError:
        raise BundleInvariantError(f"missing artifact: {path}")
    try:
        resolved.relative_to(run_dir)
    except ValueError:
        raise BundleInvariantError(
            f"artifact path escapes run_dir: {path} → {resolved}"
        )


# ─── Public API ──────────────────────────────────────────────────────────


def create_bundle(
    run_dir: Path,
    artifact_map: Optional[dict[str, tuple[str, ...]]] = None,
    bundle_name: str = BUNDLE_FILENAME,
) -> Path:
    """Create a customer-facing bundle tarball from `run_dir`.

    Returns the path to `run_dir / bundle_name` on success.

    Raises:
      * `BundleInvariantError` — run_dir missing, required run.json
        absent, artifact too large, path escapes run_dir.
      * `RedactionGateError` — a FORBIDDEN_MARKER survived in any text
        artifact. Bundle not written.
      * `OSError` — underlying filesystem or tarfile failure.
    """
    run_dir = Path(run_dir)
    if not run_dir.is_dir():
        raise BundleInvariantError(f"run_dir not found: {run_dir}")
    m = artifact_map if artifact_map is not None else DEFAULT_ARTIFACT_MAP

    # Minimum: run.json must exist.
    if _resolve_artifact(run_dir, m.get("run.json", ("run.json",))) is None:
        raise BundleInvariantError(
            f"run.json not found in {run_dir} — was the run interrupted?"
        )

    manifest: dict[str, Any] = {
        "bundle_format_version": BUNDLE_FORMAT_VERSION,
        "created_at": int(time.time()),
        "source_run_dir_name": run_dir.name,
        "files": [],
    }
    packed: list[tuple[str, Path]] = []    # (archive_name, source_path)
    total_bytes = 0

    for archive_name, candidates in m.items():
        src = _resolve_artifact(run_dir, candidates)
        if src is None:
            # Optional artifact missing — skip quietly. Required-ness
            # is enforced only for run.json (above).
            continue
        _assert_path_safe(run_dir, src)

        size = src.stat().st_size
        if size > MAX_FILE_BYTES:
            raise BundleInvariantError(
                f"{src.name}: {size} bytes exceeds per-file cap "
                f"({MAX_FILE_BYTES}). Bundle would be unwieldy."
            )
        total_bytes += size
        if total_bytes > MAX_BUNDLE_BYTES:
            raise BundleInvariantError(
                f"aggregate bundle size > {MAX_BUNDLE_BYTES} bytes. "
                "Check for accidental large artifacts in run_dir."
            )

        # Redaction gate — hard fail on any FORBIDDEN_MARKER.
        hits = _scan_for_forbidden_markers(src)
        if hits:
            raise RedactionGateError(
                f"{src.name}: IP leak — forbidden marker(s) {hits!r} "
                f"survived redaction. Bundle refused. Check builder-"
                f"side redactor output in run_dir; re-run if broken."
            )

        manifest["files"].append({
            "name":   archive_name,
            "size":   size,
            "sha256": _sha256(src),
            "source": str(src.relative_to(run_dir)),
        })
        packed.append((archive_name, src))

    # Write manifest — included INSIDE the tarball so customers can
    # re-verify checksums without trusting external state.
    manifest_bytes = json.dumps(manifest, indent=2, sort_keys=True).encode("utf-8")

    # Pack into an in-memory tarball first (easier to atomic-write).
    tar_buf = io.BytesIO()
    with tarfile.open(fileobj=tar_buf, mode="w:gz") as tf:
        # Manifest at archive root.
        info = tarfile.TarInfo(name=MANIFEST_FILENAME)
        info.size = len(manifest_bytes)
        info.mtime = manifest["created_at"]
        info.mode = 0o644
        tf.addfile(info, io.BytesIO(manifest_bytes))

        for archive_name, src in packed:
            # Don't use tf.add(src) directly — it would preserve the
            # source's mode/uid/gid which could include owner=root from
            # a container write. Copy via TarInfo for a clean header.
            info = tarfile.TarInfo(name=archive_name)
            info.size = src.stat().st_size
            info.mtime = int(src.stat().st_mtime)
            info.mode = 0o644
            with open(src, "rb") as f:
                tf.addfile(info, f)

    out_path = run_dir / bundle_name
    atomic_write_secure(out_path, tar_buf.getvalue())
    return out_path


def read_manifest(bundle_path: Path) -> dict[str, Any]:
    """Read `bundle.json` from a packed tarball and return it. Useful
    for post-hoc verification + for customer-facing re-check scripts."""
    bundle_path = _validate_input_file(bundle_path, label="bundle", binary=True, exit_on_fail=False)
    with tarfile.open(bundle_path, "r:gz") as tf:
        member = tf.getmember(MANIFEST_FILENAME)
        f = tf.extractfile(member)
        if f is None:
            raise BundleError(f"cannot extract {MANIFEST_FILENAME} from {bundle_path}")
        result: dict[str, Any] = json.loads(f.read())
        return result


def verify_bundle(bundle_path: Path) -> None:
    """Verify every file in a packed bundle matches its manifest sha256.

    Raises `BundleError` on any mismatch. Useful for customer-side
    `athanor spec verify-bundle` UX + for our own regression tests.
    """
    bundle_path = _validate_input_file(bundle_path, label="bundle", binary=True, exit_on_fail=False)
    with tarfile.open(bundle_path, "r:gz") as tf:
        manifest_member = tf.getmember(MANIFEST_FILENAME)
        f = tf.extractfile(manifest_member)
        if f is None:
            raise BundleError(f"cannot extract manifest from {bundle_path}")
        manifest = json.loads(f.read())

        for entry in manifest["files"]:
            member = tf.getmember(entry["name"])
            fh = tf.extractfile(member)
            if fh is None:
                raise BundleError(f"cannot extract {entry['name']}")
            h = hashlib.sha256()
            while True:
                chunk = fh.read(8192)
                if not chunk:
                    break
                h.update(chunk)
            actual = h.hexdigest()
            if actual != entry["sha256"]:
                raise BundleError(
                    f"checksum mismatch on {entry['name']}: "
                    f"manifest {entry['sha256']} vs actual {actual}"
                )


__all__ = [
    "BUNDLE_FILENAME",
    "MANIFEST_FILENAME",
    "BUNDLE_FORMAT_VERSION",
    "DEFAULT_ARTIFACT_MAP",
    "FORBIDDEN_MARKERS",
    "BundleError",
    "BundleInvariantError",
    "RedactionGateError",
    "create_bundle",
    "read_manifest",
    "verify_bundle",
]
