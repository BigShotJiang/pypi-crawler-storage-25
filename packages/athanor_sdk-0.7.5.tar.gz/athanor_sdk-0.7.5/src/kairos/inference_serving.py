"""kairos.inference_serving — replica + batching correctness verifier (Bet G).

ATH-964. Composes on Pythia matrix-concentration primitives + the
existing :mod:`kairos.model_invariants` orchestrator to surface a
joint customer pitch claim:

    *"Your inference replica's tail latency is bounded + the served
    model is permutation-equivariant + multi-tenant batches never
    violate causality."*

per CTO 2026-05-03 next-vertical guidance:

> *Composes on `Pythia.Frontier.MatrixBernstein` (latency tail
> concentration) + your existing model_invariants for the served-
> model invariant claim.*

Architecture (now-canonical template across the vertical orchestrators)
-----------------------------------------------------------------------
* Same shape as :mod:`kairos.silicon_review` (ATH-951),
  :mod:`kairos.model_invariants` (ATH-958), :mod:`kairos.sparsity`
  (ATH-959), :mod:`kairos.security` (ATH-962). Thin compose-existing-
  primitives only.
* 4-layer vacuous-proves defense (per
  ``feedback_no_vacuous_proves_multi_layer.md``):
    1. Per-invariant verdict mapping (banned > axiom_clean=False >
       sorry > compile_error > full_proof). ATH-948 lineage.
    2. Composite precedence (error > refuted > unknown > proved;
       empty list → error not silent-proved).
    3. Theorem template references customer-spec
       ``{invariant_name}_property`` + ``{invariant_name}_proof``.
    4. Source-text + behavioral pins.
* Layer-6 (CTO 2026-05-03 ATH-962 review addendum): property-
  handle ``bool(subset) and all(...)`` guard against Python's
  ``all([]) == True`` silent-success.
* Dot-aware identifier canonicalization (ATH-961/963 pattern).

Trace event
-----------
``inference_serving_verify_complete`` registered in
:data:`kairos.trace_schema.REGISTRY` per ATH-932 emit-registry gate.
Walker-visible emit. Composes with platform's Verification Coverage
card.

Cross-ref
---------
* :mod:`kairos.model_invariants` — joint-claim composition partner.
* :func:`kairos.lean.verify_proof` — per-invariant proof checker.
* ``Pythia.MatrixBernstein`` — Tropp 2012; latency-tail concentration.
* ``Pythia.PhiTransform`` — moment-generating-function bounds.
* ``Pythia.MatchingConstants`` — sharp ε-bounds on tail probability.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

from kairos.lean_canonicalize import canonicalize_lean_identifier as _canonicalize_lean_identifier


KNOWN_SERVING_TOPOLOGIES = (
    "single_replica",          # one replica, one process
    "multi_replica",           # horizontal scale-out
    "tensor_parallel",         # weights split across devices
    "pipeline_parallel",       # layers split across stages
    "expert_parallel",         # MoE routing across experts
    "speculative_serving",     # draft+target speculative decoding
)


KNOWN_INVARIANT_KINDS = (
    "tail_latency_bounded",                 # P99 latency within ε of expected
    "kv_cache_consistency",                 # KV cache reads = writes
    "continuous_batching_causality",        # in-flight batch additions don't reorder tokens
    "speculative_decoding_equivalence",     # speculation tree's accepted path ≡ greedy
    "request_isolation",                    # cross-request memory + state isolation
    "replica_consistency",                  # multi-replica produces equivalent outputs (ε-bounded)
)


# Lean identifier canonicalization moved to :mod:`kairos.lean_canonicalize`
# in ATH-963 bulk migration. Re-imported below as the existing module
# alias to keep call-sites unchanged. The shared helper relaxes the
# regex to preserve Lean-valid Unicode (ε, λ, δ, π, σ) — strict superset
# of the prior ASCII-only behavior.


@dataclass
class InvariantOutcome:
    """Per-invariant verdict + proof artifact."""

    invariant_name: str
    verdict: str
    """One of ``"proved" / "refuted" / "unknown" / "error"``."""

    proof_artifact_path: Path | None = None
    elapsed_sec: float = 0.0
    error_message: str | None = None
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class InferenceServingResult:
    """Composite outcome from one inference-serving verification pass."""

    serving_topology: str
    composite_verdict: str
    """``"proved" / "refuted" / "unknown" / "error"``."""

    tail_latency_safe: bool
    """True iff every latency-class invariant returned ``proved``.
    Customer-facing claim handle with `bool(...)` guard against
    Python's `all([]) == True` silent-success (per ATH-962 layer-6
    addendum)."""

    causality_safe: bool
    """True iff every ordering / batching / consistency-class
    invariant returned ``proved``. Same `bool(...)` guard."""

    all_invariants_proven: bool
    """True iff every enumerated invariant returned ``proved``.
    Composite-layer silent-success defense."""

    invariant_outcomes: list[InvariantOutcome] = field(default_factory=list)
    total_elapsed_sec: float = 0.0
    error_message: str | None = None

    @property
    def proved_invariants(self) -> list[str]:
        return [o.invariant_name for o in self.invariant_outcomes if o.verdict == "proved"]

    @property
    def failed_invariants(self) -> list[str]:
        return [o.invariant_name for o in self.invariant_outcomes if o.verdict != "proved"]


# Disjoint-concerns lesson (ATH-966 / CTO 2026-05-03 ATH-964 review):
# property handles must NOT lump unrelated invariants into the same
# customer claim. `replica_consistency` is output-correctness across
# replicas, NOT a tail-latency claim. A customer who enumerates only
# `replica_consistency` and gets it proved must NOT see
# `tail_latency_safe=True` — that would over-credit the latency claim.
# Pre-fix behaviour (ATH-964 ship): `replica_consistency` was lumped
# in by analogy ("consistency drift bounded → tail-latency-relevant").
# That analogy double-credits the customer's auditable claim. Same
# disjoint-concerns pattern as ATH-962 security `timing_safe` vs
# `no_cache_leak` and ATH-965 carbon_aware excluding
# `throttle_correctness` from both handle sets.
_LATENCY_INVARIANT_NAMES = frozenset({
    "tail_latency_bounded",
})

_CAUSALITY_INVARIANT_NAMES = frozenset({
    "continuous_batching_causality",
    "kv_cache_consistency",
    "speculative_decoding_equivalence",
    "request_isolation",
})

# Invariants outside both handles (visible in invariant_outcomes but
# not collapsed into a property-handle bool):
# * replica_consistency — output correctness across replicas, separate
#   concern from tail-latency. Customer must enumerate the actual
#   tail-latency invariant (`tail_latency_bounded`) for the
#   `tail_latency_safe` handle to credit it.


def _classify_composite(
    outcomes: Sequence[InvariantOutcome],
) -> tuple[str, bool]:
    """Map per-invariant verdicts → (composite_verdict, all_proven).

    Layer-2 of the 4-layer defense: precedence error > refuted >
    unknown > proved; empty list → error not silent-proved.
    """
    if not outcomes:
        return "error", False
    verdicts = [o.verdict for o in outcomes]
    if any(v == "error" for v in verdicts):
        return "error", False
    if any(v == "refuted" for v in verdicts):
        return "refuted", False
    if any(v == "unknown" for v in verdicts):
        return "unknown", False
    if all(v == "proved" for v in verdicts):
        return "proved", True
    return "error", False


def _compute_property_handles(
    outcomes: Sequence[InvariantOutcome],
) -> tuple[bool, bool]:
    """Compute (tail_latency_safe, causality_safe) handles.

    Layer-6 property-handle silent-success defense (ATH-962 / CTO
    addendum): the `bool(subset) and all(...)` guard ensures empty
    relevant-class outcomes default to False, NOT silent-True via
    Python's `all([]) == True`.
    """
    latency_outcomes = [
        o for o in outcomes if o.invariant_name in _LATENCY_INVARIANT_NAMES
    ]
    causality_outcomes = [
        o for o in outcomes if o.invariant_name in _CAUSALITY_INVARIANT_NAMES
    ]
    tail_latency_safe = bool(latency_outcomes) and all(
        o.verdict == "proved" for o in latency_outcomes
    )
    causality_safe = bool(causality_outcomes) and all(
        o.verdict == "proved" for o in causality_outcomes
    )
    return tail_latency_safe, causality_safe


def _build_invariant_theorem(
    invariant_name: str,
    serving_topology: str,
    spec_source: str,
) -> str:
    """Construct a Lean theorem statement for the named serving invariant.

    Honest scaffold contract (layer-3 + ATH-961 dot-aware
    canonicalization): generated theorem references customer-spec
    identifiers. Empty / missing / wrong-shaped spec → compile error
    → refuted. NOT a tautology.
    """
    safe_inv = _canonicalize_lean_identifier(invariant_name)
    safe_top = _canonicalize_lean_identifier(serving_topology)
    return (
        f"{spec_source}\n\n"
        f"-- ATH-964 inference_serving invariant: {invariant_name} for "
        f"{serving_topology} topology.\n"
        f"-- Honest scaffold contract: the spec is required to define\n"
        f"--   {safe_inv}_property : Prop\n"
        f"--   {safe_inv}_proof : {safe_inv}_property\n"
        f"-- Empty / missing / wrong-shaped spec → compile error → refuted.\n"
        f"theorem {safe_inv}_verified_for_{safe_top}_serving : "
        f"{safe_inv}_property := {safe_inv}_proof\n"
    )


def verify(
    serving_topology: str,
    *,
    invariants: Sequence[str],
    served_model_lean_spec: str | Path | None = None,
    workdir: str | Path,
    lake_project: str | Path | None = None,
    timeout_sec_per_invariant: int = 300,
    emit_trace: bool = True,
) -> InferenceServingResult:
    """Verify inference-serving invariants against ``served_model_lean_spec``.

    Args:
        serving_topology: serving regime name (``"multi_replica"``,
            ``"speculative_serving"``, etc.). See
            :data:`KNOWN_SERVING_TOPOLOGIES`.
        invariants: list of invariant names to prove. See
            :data:`KNOWN_INVARIANT_KINDS`.
        served_model_lean_spec: path to Lean source describing the
            served model + customer's invariant property/proof
            definitions.
        workdir: scratch directory.
        lake_project: optional Lake project to verify against.
        timeout_sec_per_invariant: per-invariant Lean wall-clock.
        emit_trace: when True (default), emit
            ``inference_serving_verify_complete`` on completion.

    Returns:
        :class:`InferenceServingResult`. Never raises.
    """
    workdir_path = Path(workdir).resolve()
    workdir_path.mkdir(parents=True, exist_ok=True)

    if not invariants:
        result = InferenceServingResult(
            serving_topology=serving_topology,
            composite_verdict="error",
            tail_latency_safe=False,
            causality_safe=False,
            all_invariants_proven=False,
            error_message="no invariants enumerated — verify() requires ≥1",
        )
        if emit_trace:
            _emit_complete(result)
        return result

    spec_source = ""
    if served_model_lean_spec is not None:
        spec_path = Path(served_model_lean_spec).resolve()
        if not spec_path.exists():
            return InferenceServingResult(
                serving_topology=serving_topology,
                composite_verdict="error",
                tail_latency_safe=False,
                causality_safe=False,
                all_invariants_proven=False,
                error_message=f"served_model_lean_spec does not exist: {spec_path}",
            )
        spec_source = spec_path.read_text()

    t0 = time.monotonic()
    outcomes: list[InvariantOutcome] = []

    try:
        from kairos.lean import verify_proof
    except Exception as e:  # noqa: BLE001
        result = InferenceServingResult(
            serving_topology=serving_topology,
            composite_verdict="error",
            tail_latency_safe=False,
            causality_safe=False,
            all_invariants_proven=False,
            error_message=f"kairos.lean unavailable: {e}",
        )
        if emit_trace:
            _emit_complete(result)
        return result

    for inv_name in invariants:
        inv_t0 = time.monotonic()
        theorem_source = _build_invariant_theorem(
            invariant_name=inv_name,
            serving_topology=serving_topology,
            spec_source=spec_source,
        )
        try:
            proof_result = verify_proof(
                theorem_source,
                lake_project=lake_project,
                timeout=timeout_sec_per_invariant,
            )
        except Exception as e:  # noqa: BLE001
            outcomes.append(InvariantOutcome(
                invariant_name=inv_name,
                verdict="error",
                elapsed_sec=round(time.monotonic() - inv_t0, 3),
                error_message=f"verify_proof raised: {e}",
            ))
            continue

        # Layer-1 verdict mapping (ATH-948 lineage).
        if not proof_result.compiles:
            verdict = "refuted"
            err = (
                (proof_result.errors or [""])[0][:200]
                if proof_result.errors
                else "lean compile error"
            )
        elif proof_result.has_sorry:
            verdict = "refuted"
            err = "proof has sorry — incomplete"
        elif proof_result.banned:
            verdict = "refuted"
            err = f"banned construct: {proof_result.banned}"
        elif proof_result.axiom_clean is False:
            verdict = "refuted"
            err = (
                f"axiom leak: {list(proof_result.forbidden_axioms or [])[:3]}"
            )
        elif proof_result.score >= 1.0:
            verdict = "proved"
            err = None
        else:
            verdict = "error"
            err = (
                f"unexpected ProofResult shape: compiles=True, no sorry, "
                f"no banned, axiom_clean!=False, score={proof_result.score}"
            )

        outcomes.append(InvariantOutcome(
            invariant_name=inv_name,
            verdict=verdict,
            elapsed_sec=round(time.monotonic() - inv_t0, 3),
            error_message=err,
            details={
                "compiles": proof_result.compiles,
                "has_sorry": proof_result.has_sorry,
                "score": proof_result.score,
                "axiom_clean": proof_result.axiom_clean,
            },
        ))

    composite_verdict, all_proven = _classify_composite(outcomes)
    tail_latency_safe, causality_safe = _compute_property_handles(outcomes)
    total_elapsed = round(time.monotonic() - t0, 3)

    result = InferenceServingResult(
        serving_topology=serving_topology,
        composite_verdict=composite_verdict,
        tail_latency_safe=tail_latency_safe,
        causality_safe=causality_safe,
        all_invariants_proven=all_proven,
        invariant_outcomes=outcomes,
        total_elapsed_sec=total_elapsed,
    )

    if emit_trace:
        _emit_complete(result)

    return result


def _emit_complete(result: InferenceServingResult) -> None:
    """Best-effort trace emit. Never raises."""
    try:
        from kairos.observe import emit
        emit(
            "inference_serving_verify_complete",
            {
                "serving_topology": result.serving_topology,
                "composite_verdict": result.composite_verdict,
                "tail_latency_safe": result.tail_latency_safe,
                "causality_safe": result.causality_safe,
                "all_invariants_proven": result.all_invariants_proven,
                "invariants_proved": result.proved_invariants,
                "invariants_failed": result.failed_invariants,
                "total_elapsed_sec": result.total_elapsed_sec,
            },
        )
    except Exception:  # noqa: BLE001 — trace emit must never break verify()
        pass


__all__ = [
    "InvariantOutcome",
    "InferenceServingResult",
    "KNOWN_SERVING_TOPOLOGIES",
    "KNOWN_INVARIANT_KINDS",
    "verify",
]
