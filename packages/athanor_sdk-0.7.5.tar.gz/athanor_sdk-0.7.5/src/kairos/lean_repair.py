"""ATH-1448: 4-level sorry closure pipeline for Lean files.

`kairos repair file.lean` auto-detects .lean -> enters this pipeline.

Levels:
  0. Triage: parse sorry taxonomy, detect cross-sorry deps, try counterexample
  1. Simple tactics: simp, omega, decide, unfold, rfl (no LLM)
  2. LLM-assisted: decompose goal, spawn subagent per subgoal
  3. Full rewrite: different approach, memory recalls L1+L2 failures

Verification: Lean kernel checks every attempt. No false claims.
"""
from __future__ import annotations

import logging
import re
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_log = logging.getLogger("kairos.lean_repair")

_SORRY_RE = re.compile(r"^(\s*)sorry\b(.*)$")
_TAG_RE = re.compile(r"--\s*(SPEC_AXIOM|PROOF_GAP|MATHLIB_BLOCKED):\s*(.*)")

# ATH-1441: Patterns for auto-classifying untagged sorrys as SPEC_AXIOM.
# An axiom/opaque declaration, or a theorem whose name starts with spec_.
_AXIOM_DECL_RE = re.compile(r"^\s*(?:axiom|opaque)\s+(\w+)")
_SPEC_THEOREM_RE = re.compile(r"^\s*theorem\s+(spec_\w+)")
# Abstract interface markers: if the enclosing declaration references these,
# the sorry is a specification axiom, not a closable proof gap.
_ABSTRACT_IFACE_RE = re.compile(r"\b(?:Abstract|Interface|Specification|Spec)\b")


@dataclass
class SorryTarget:
    line_number: int
    tag: str
    description: str
    theorem_name: str
    indent: str
    depends_on: list[str] = field(default_factory=list)


@dataclass
class ClosureAttempt:
    target: SorryTarget
    level: int
    tactic: str
    succeeded: bool
    lean_error: str = ""
    elapsed_sec: float = 0.0


@dataclass
class LeanRepairResult:
    file_path: str
    total_sorrys: int = 0
    closed: int = 0
    unprovable: int = 0
    escalated: int = 0
    spec_axioms: int = 0
    proof_gaps: int = 0
    details: list[ClosureAttempt] = field(default_factory=list)

    @property
    def honest_report(self) -> str:
        remaining = self.total_sorrys - self.closed - self.unprovable
        lines = [
            sorry_summary(self.total_sorrys, self.spec_axioms, self.proof_gaps),
            f"Closed {self.closed}/{self.proof_gaps} proof gaps. "
            f"{self.unprovable} unprovable. "
            f"{remaining - self.spec_axioms} remaining gaps."
        ]
        for d in self.details:
            if d.succeeded:
                lines.append(f"  L{d.target.line_number}: closed at level {d.level} ({d.tactic})")
            elif d.level == 0 and "counterexample" in d.tactic:
                lines.append(f"  L{d.target.line_number}: unprovable ({d.tactic})")
        return "\n".join(lines)


def sorry_summary(total: int, spec_axioms: int, proof_gaps: int) -> str:
    """One-line sorry breakdown: spec axioms vs proof gaps.

    ATH-1441: '131 sorry' sounds like 131 gaps. But 100+ are
    specification axioms BY DESIGN. Only ~20 are closable proof gaps.
    This function produces the disambiguated summary:
      '131 sorry (112 spec axioms, 19 proof gaps)'
    """
    return f"{total} sorry ({spec_axioms} spec axioms, {proof_gaps} proof gaps)"


def _classify_untagged_sorry(
    lines: list[str],
    sorry_line_idx: int,
    current_decl: str,
    current_decl_kind: str,
) -> str:
    """Auto-classify an untagged sorry as SPEC_AXIOM or PROOF_GAP.

    ATH-1441: Classification rules:
      - SPEC_AXIOM: sorry in an `axiom` or `opaque` declaration, or in
        a theorem whose name starts with 'spec_', or in a declaration
        that references abstract interface types.
      - PROOF_GAP: sorry in a regular `theorem` or `lemma` that should
        be provable.
    """
    # Axiom / opaque declarations are specification by definition.
    if current_decl_kind in ("axiom", "opaque"):
        return "SPEC_AXIOM"

    # Theorems named spec_* are specification axioms.
    if current_decl.startswith("spec_"):
        return "SPEC_AXIOM"

    # Scan backward from the sorry to the enclosing declaration for
    # abstract interface references.
    scan_start = max(0, sorry_line_idx - 20)
    context_block = "\n".join(lines[scan_start:sorry_line_idx + 1])
    if _ABSTRACT_IFACE_RE.search(context_block):
        return "SPEC_AXIOM"

    return "PROOF_GAP"


def parse_sorrys(text: str) -> list[SorryTarget]:
    """Extract sorry targets with taxonomy tags from Lean source.

    ATH-1441: Untagged sorrys are now auto-classified as SPEC_AXIOM or
    PROOF_GAP based on the enclosing declaration context.
    """
    lines = text.splitlines()
    targets: list[SorryTarget] = []
    current_theorem = ""
    current_decl_kind = "theorem"  # default
    for i, line in enumerate(lines):
        # Track declaration kind (theorem, lemma, axiom, opaque).
        axiom_m = _AXIOM_DECL_RE.match(line)
        if axiom_m:
            current_theorem = axiom_m.group(1)
            current_decl_kind = "axiom" if line.lstrip().startswith("axiom") else "opaque"
        lemma_m = re.match(r"\s*lemma\s+(\w+)", line)
        if lemma_m:
            current_theorem = lemma_m.group(1)
            current_decl_kind = "lemma"
        theorem_m = re.match(r"\s*theorem\s+(\w+)", line)
        if theorem_m:
            current_theorem = theorem_m.group(1)
            current_decl_kind = "theorem"
        sorry_m = _SORRY_RE.match(line)
        if sorry_m:
            indent = sorry_m.group(1)
            rest = sorry_m.group(2).strip()
            tag_m = _TAG_RE.search(rest)
            if tag_m:
                tag = tag_m.group(1)
                desc = tag_m.group(2).strip()
            else:
                # ATH-1441: auto-classify untagged sorrys.
                tag = _classify_untagged_sorry(
                    lines, i, current_theorem, current_decl_kind,
                )
                desc = f"auto-classified from {current_decl_kind} {current_theorem}"
            targets.append(SorryTarget(
                line_number=i + 1,
                tag=tag,
                description=desc,
                theorem_name=current_theorem,
                indent=indent,
            ))
    return targets


def detect_dependencies(targets: list[SorryTarget], text: str) -> list[SorryTarget]:
    """Detect cross-sorry dependencies for proof ordering."""
    theorem_names = {t.theorem_name for t in targets if t.theorem_name}
    for t in targets:
        for name in theorem_names:
            if name != t.theorem_name and name in text:
                start = text.find(f"theorem {t.theorem_name}")
                if start >= 0:
                    block = text[start:text.find("\ntheorem ", start + 1) if text.find("\ntheorem ", start + 1) > 0 else len(text)]
                    if name in block and name not in (t.theorem_name,):
                        t.depends_on.append(name)
    return sorted(targets, key=lambda t: len(t.depends_on))


def _build_mathlib_lean_path() -> str:
    """Build LEAN_PATH including Mathlib oleans from the warm Pythia cache."""
    pythia_lake = Path.home() / ".athanor" / "pythia-runs" / ".lake" / "packages"
    if not pythia_lake.is_dir():
        return ""
    dirs = sorted(str(d) for d in pythia_lake.rglob("build/lib/lean") if d.is_dir())
    return ":".join(dirs)


def _lean_check(file_path: Path, timeout: int = 60) -> tuple[bool, str]:
    """Run Lean kernel on a file. Returns (success, error_output)."""
    lean_bin = shutil.which("lean")
    if not lean_bin:
        return False, "lean binary not found"
    import os
    env = os.environ.copy()
    mathlib_path = _build_mathlib_lean_path()
    if mathlib_path:
        existing = env.get("LEAN_PATH", "")
        env["LEAN_PATH"] = f"{mathlib_path}:{existing}" if existing else mathlib_path
    try:
        r = subprocess.run(
            [lean_bin, str(file_path)],
            capture_output=True, text=True, timeout=timeout,
            env=env,
        )
        return r.returncode == 0, r.stderr[:500]
    except subprocess.TimeoutExpired:
        return False, f"lean timed out after {timeout}s"


_L1_TACTICS = [
    "decide",
    "simp",
    "omega",
    "rfl",
    "simp [Nat.mod_def]",
    "simp [Nat.add_mod, Nat.mod_mod_of_dvd]",
    "simp only [Finset.countP]; omega",
    "unfold_let; simp; omega",
    "intro h; simp_all",
    "aesop",
]


def _try_tactic(
    file_path: Path,
    text: str,
    target: SorryTarget,
    tactic: str,
) -> tuple[bool, str]:
    """Replace sorry with a tactic and check if Lean accepts it."""
    _BANNED = ("#eval", "#check", "#print", "IO.", "System.", "import")
    for banned in _BANNED:
        if banned in tactic:
            return False, f"tactic contains banned keyword: {banned}"
    lines = text.splitlines()
    idx = target.line_number - 1
    lines[idx] = f"{target.indent}{tactic}"
    import tempfile
    tmp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(suffix=".lean", mode="w", delete=False) as f:
            f.write("\n".join(lines))
            f.flush()
            tmp_path = Path(f.name)
        ok, err = _lean_check(tmp_path, timeout=30)
        return ok, err
    finally:
        if tmp_path is not None:
            tmp_path.unlink(missing_ok=True)


def _extract_theorem_context(text: str, target: SorryTarget, window: int = 30) -> str:
    """Extract the theorem + surrounding context for the LLM prompt."""
    lines = text.splitlines()
    start = max(0, target.line_number - window)
    end = min(len(lines), target.line_number + 5)
    numbered = [f"{i+1:4d}| {lines[i]}" for i in range(start, end)]
    return "\n".join(numbered)


def _llm_prove(
    text: str,
    target: SorryTarget,
    l1_failures: list[str],
) -> str | None:
    """Ask Claude subagent for a proof tactic. Returns tactic string or None."""
    claude_bin = shutil.which("claude")
    if not claude_bin:
        return None

    context = _extract_theorem_context(text, target)
    failed_str = "\n".join(f"  - `{t}` failed" for t in l1_failures[:5]) if l1_failures else "  (none tried yet)"

    prompt = (
        f"Prove this Lean 4 theorem. Replace the `sorry` at line {target.line_number} "
        f"with a valid tactic proof.\n\n"
        f"Context:\n```lean\n{context}\n```\n\n"
        f"Tactics already tried and failed:\n{failed_str}\n\n"
        f"Tag: {target.tag} -- {target.description}\n\n"
        f"Return ONLY the tactic proof (the replacement for `sorry`). "
        f"No explanation. No markdown. Just the tactic expression. "
        f"Example: `simp [Nat.add_comm, Nat.add_assoc]`"
    )

    from kairos.security.env_allowlist import safe_env_for_claude_subagent
    from kairos.subagent_trace import trace_subagent_call, complete_trace
    import time as _time
    trace = trace_subagent_call("lean_prove", f"prove {target.theorem_name} L{target.line_number}", f"tag={target.tag}, {len(l1_failures)} L1 failures")
    t0 = _time.time()
    try:
        r = subprocess.run(
            [claude_bin, "--print", "-p", prompt, "--max-turns", "1"],
            capture_output=True, text=True, timeout=120,
            env=safe_env_for_claude_subagent(),
        )
        output = r.stdout.strip()
        if output.startswith("```"):
            lines = output.splitlines()
            output = "\n".join(lines[1:-1] if lines[-1].startswith("```") else lines[1:])
        output = output.strip().rstrip(";")
        if len(output) < 2 or "sorry" in output.lower():
            complete_trace(trace, output[:100], "rejected", "output empty or contains sorry", _time.time() - t0)
            return None
        complete_trace(trace, output[:100], "accepted", f"tactic: {output[:60]}", _time.time() - t0)
        return output
    except Exception:  # noqa: BLE001
        return None


def _l3_full_rewrite(
    text: str,
    target: SorryTarget,
    all_failures: list[str],
) -> str | None:
    """L3: full rewrite -- different proof approach with decomposition.

    Unlike L2 (single tactic), L3 asks the LLM to:
    1. Analyze WHY all previous attempts failed
    2. Decompose the goal into helper lemmas if needed
    3. Write a multi-line proof block
    4. Include the helper lemmas inline (have/suffices)
    """
    claude_bin = shutil.which("claude")
    if not claude_bin:
        return None

    context = _extract_theorem_context(text, target, window=50)
    failed_str = "\n".join(f"  - `{t}` -> failed" for t in all_failures[-8:])

    prompt = (
        f"This Lean 4 theorem has resisted {len(all_failures)} proof attempts. "
        f"Try a COMPLETELY DIFFERENT approach.\n\n"
        f"Theorem context:\n```lean\n{context}\n```\n\n"
        f"All failed attempts:\n{failed_str}\n\n"
        f"Instructions:\n"
        f"1. Analyze WHY the previous tactics failed\n"
        f"2. Try a different proof STRATEGY (not just different tactics)\n"
        f"3. Decompose into helper lemmas using `have` if needed\n"
        f"4. Write a multi-line proof block\n"
        f"5. The proof replaces `sorry` at line {target.line_number}\n\n"
        f"Return ONLY the tactic proof. No explanation. No markdown fences."
    )

    from kairos.security.env_allowlist import safe_env_for_claude_subagent
    from kairos.subagent_trace import trace_subagent_call, complete_trace
    import time as _time
    trace = trace_subagent_call(
        "lean_prove_l3", f"full rewrite {target.theorem_name}",
        f"{len(all_failures)} prior failures"
    )
    t0 = _time.time()
    try:
        r = subprocess.run(
            [claude_bin, "--print", "-p", prompt, "--max-turns", "1"],
            capture_output=True, text=True, timeout=180,
            env=safe_env_for_claude_subagent(),
        )
        output = r.stdout.strip()
        if output.startswith("```"):
            lines = output.splitlines()
            output = "\n".join(lines[1:-1] if lines[-1].startswith("```") else lines[1:])
        output = output.strip()
        if len(output) < 2 or "sorry" in output.lower():
            complete_trace(trace, output[:100], "rejected", "L3 output empty or sorry", _time.time() - t0)
            return None
        complete_trace(trace, output[:100], "accepted", f"L3 rewrite: {output[:60]}", _time.time() - t0)
        return output
    except Exception:  # noqa: BLE001
        complete_trace(trace, "", "error", "L3 subprocess failed", _time.time() - t0)
        return None


def repair_lean(
    path: str | Path,
    *,
    max_level: int = 3,
) -> LeanRepairResult:
    """Run the sorry closure pipeline on a Lean file.

    Level 0: triage (skip SPEC_AXIOM). No LLM.
    Level 1: simple tactics (simp, omega, decide). No LLM.
    Level 2: LLM single-tactic with failure feedback.
    Level 3: LLM full rewrite with decomposition.

    ATH-1039: Before calling LLM (L2/L3), check the proof journal for
    cached tactics from prior runs. After successful L2/L3, persist the
    tactic to the journal so rate-limited re-runs don't lose proofs.
    """
    file_path = Path(path)
    if not file_path.is_file():
        return LeanRepairResult(file_path=str(path))

    text = file_path.read_text()
    targets = parse_sorrys(text)
    targets = detect_dependencies(targets, text)

    # ATH-1441: count spec axioms vs proof gaps up front.
    n_spec = sum(1 for t in targets if t.tag == "SPEC_AXIOM")
    n_gaps = sum(1 for t in targets if t.tag != "SPEC_AXIOM")

    result = LeanRepairResult(
        file_path=str(path),
        total_sorrys=len(targets),
        spec_axioms=n_spec,
        proof_gaps=n_gaps,
    )

    if not targets:
        return result

    _log.info(sorry_summary(len(targets), n_spec, n_gaps))

    # ATH-1039: Load proof journal for cached tactics.
    from kairos.proof_journal import load_journal, lookup, persist_proof
    project_root = file_path.resolve().parent
    journal = load_journal(project_root)

    current_text = text

    proof_gaps = [t for t in targets if t.tag != "SPEC_AXIOM"]
    for target in targets:
        if target.tag == "SPEC_AXIOM":
            result.escalated += 1
            result.details.append(ClosureAttempt(
                target=target, level=0,
                tactic="skip (SPEC_AXIOM -- closes from Rust bridge)",
                succeeded=False,
            ))

    independent = [t for t in proof_gaps if not t.depends_on]
    dependent = [t for t in proof_gaps if t.depends_on]

    if len(independent) > 1:
        current_text = _batch_l1_parallel(
            file_path, current_text, independent, result, journal, project_root,
        )

        remaining = [t for t in independent if not any(
            d.target == t and d.succeeded for d in result.details
        )]
    else:
        remaining = list(independent)

    remaining.extend(dependent)

    for target in remaining:
        current_text = _repair_single_sorry(
            file_path, current_text, target, result,
            max_level, journal, project_root,
        )

    if result.closed > 0:
        file_path.write_text(current_text)
        _log.info(f"Wrote {result.closed} closures to {file_path}")

    return result


def _batch_l1_parallel(
    file_path: Path,
    text: str,
    targets: list[SorryTarget],
    result: LeanRepairResult,
    journal: Any,
    project_root: Path,
) -> str:
    """Try L1 tactics on independent sorrys in parallel.

    Each sorry gets its own copy of the text with just that sorry
    replaced. Successful closures are collected and applied in
    one batch to the original text.
    """
    from concurrent.futures import ThreadPoolExecutor, as_completed
    from kairos.proof_journal import lookup

    def _try_target(target: SorryTarget) -> tuple[SorryTarget, str | None, list[ClosureAttempt]]:
        attempts: list[ClosureAttempt] = []

        cached = lookup(journal, target.theorem_name, str(file_path), target.line_number)
        if cached is not None:
            t0 = time.time()
            ok, err = _try_tactic(file_path, text, target, cached)
            elapsed = time.time() - t0
            attempts.append(ClosureAttempt(
                target=target, level=0, tactic=f"journal:{cached}",
                succeeded=ok, lean_error=err, elapsed_sec=elapsed,
            ))
            if ok:
                return target, cached, attempts

        for tactic in _L1_TACTICS:
            t0 = time.time()
            ok, err = _try_tactic(file_path, text, target, tactic)
            elapsed = time.time() - t0
            attempts.append(ClosureAttempt(
                target=target, level=1, tactic=tactic,
                succeeded=ok, lean_error=err, elapsed_sec=elapsed,
            ))
            if ok:
                return target, tactic, attempts
        return target, None, attempts

    max_workers = min(len(targets), 4)
    closures: dict[int, str] = {}

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {pool.submit(_try_target, t): t for t in targets}
        for future in as_completed(futures):
            target, winning_tactic, attempts = future.result()
            result.details.extend(attempts)
            if winning_tactic is not None:
                closures[target.line_number] = f"{target.indent}{winning_tactic}"
                result.closed += 1
                _log.info(
                    f"L{target.line_number} ({target.theorem_name}): "
                    f"closed in parallel batch (`{winning_tactic[:40]}`)"
                )

    if closures:
        lines = text.splitlines()
        for line_num, replacement in closures.items():
            lines[line_num - 1] = replacement
        text = "\n".join(lines)

    return text


def _repair_single_sorry(
    file_path: Path,
    current_text: str,
    target: SorryTarget,
    result: LeanRepairResult,
    max_level: int,
    journal: Any,
    project_root: Path,
) -> str:
    """Run the full L0-L3 pipeline on a single sorry. Returns updated text."""
    from kairos.proof_journal import lookup, persist_proof

    already_closed = any(d.target == target and d.succeeded for d in result.details)
    if already_closed:
        return current_text

    closed = False

    cached_tactic = lookup(journal, target.theorem_name, str(file_path), target.line_number)
    if cached_tactic is not None:
        t0 = time.time()
        ok, err = _try_tactic(file_path, current_text, target, cached_tactic)
        elapsed = time.time() - t0
        attempt = ClosureAttempt(
            target=target, level=0, tactic=f"journal:{cached_tactic}",
            succeeded=ok, lean_error=err, elapsed_sec=elapsed,
        )
        result.details.append(attempt)
        if ok:
            lines = current_text.splitlines()
            lines[target.line_number - 1] = f"{target.indent}{cached_tactic}"
            current_text = "\n".join(lines)
            result.closed += 1
            closed = True
            _log.info(
                f"L{target.line_number} ({target.theorem_name}): "
                f"closed from journal cache (`{cached_tactic[:40]}`)"
            )

    if not closed:
        for tactic in _L1_TACTICS:
            t0 = time.time()
            ok, err = _try_tactic(file_path, current_text, target, tactic)
            elapsed = time.time() - t0
            attempt = ClosureAttempt(
                target=target, level=1, tactic=tactic,
                succeeded=ok, lean_error=err, elapsed_sec=elapsed,
            )
            result.details.append(attempt)
            if ok:
                lines = current_text.splitlines()
                lines[target.line_number - 1] = f"{target.indent}{tactic}"
                current_text = "\n".join(lines)
                result.closed += 1
                closed = True
                _log.info(f"L{target.line_number} ({target.theorem_name}): closed with `{tactic}`")
                break

    if not closed and max_level >= 2:
        l1_failures = [d.tactic for d in result.details if d.target == target and not d.succeeded]
        for attempt_i in range(3):
            t0 = time.time()
            tactic = _llm_prove(current_text, target, l1_failures)
            if tactic is None:
                break
            ok, err = _try_tactic(file_path, current_text, target, tactic)
            elapsed = time.time() - t0
            attempt = ClosureAttempt(
                target=target, level=2, tactic=tactic,
                succeeded=ok, lean_error=err, elapsed_sec=elapsed,
            )
            result.details.append(attempt)
            if ok:
                lines = current_text.splitlines()
                lines[target.line_number - 1] = f"{target.indent}{tactic}"
                current_text = "\n".join(lines)
                result.closed += 1
                closed = True
                _log.info(f"L{target.line_number} ({target.theorem_name}): closed at L2 attempt {attempt_i+1} ({tactic[:40]})")
                try:
                    persist_proof(
                        target.theorem_name, str(file_path),
                        target.line_number, tactic, 2,
                        project_root=project_root,
                    )
                except OSError:
                    _log.warning("Failed to persist L2 proof to journal")
                break
            l1_failures.append(tactic)

    if not closed and max_level >= 3:
        l_all_failures = [d.tactic for d in result.details if d.target == target and not d.succeeded]
        tactic = _l3_full_rewrite(current_text, target, l_all_failures)
        if tactic:
            t0 = time.time()
            ok, err = _try_tactic(file_path, current_text, target, tactic)
            elapsed = time.time() - t0
            attempt = ClosureAttempt(
                target=target, level=3, tactic=tactic,
                succeeded=ok, lean_error=err, elapsed_sec=elapsed,
            )
            result.details.append(attempt)
            if ok:
                lines = current_text.splitlines()
                lines[target.line_number - 1] = f"{target.indent}{tactic}"
                current_text = "\n".join(lines)
                result.closed += 1
                closed = True
                _log.info(f"L{target.line_number} ({target.theorem_name}): closed at L3 (full rewrite)")
                try:
                    persist_proof(
                        target.theorem_name, str(file_path),
                        target.line_number, tactic, 3,
                        project_root=project_root,
                    )
                except OSError:
                    _log.warning("Failed to persist L3 proof to journal")

    if not closed:
        _log.info(f"L{target.line_number} ({target.theorem_name}): all levels exhausted, escalating")
        result.escalated += 1

    return current_text
