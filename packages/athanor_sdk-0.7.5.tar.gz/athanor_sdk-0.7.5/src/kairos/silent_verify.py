"""ATH-1453: silent verification pipeline.

Customer agent codes normally. kairos verifies in the background.
Returns only failures as actionable fixes. Customer never sees Lean,
Verus, symbolic exec, or hypothesis. Just: "kairos found a bug."

Usage:
    from kairos.silent_verify import verify_silently
    result = verify_silently("def add(a: int, b: int) -> int: return a - b")
    # result.bugs = [Bug(line=1, message="add returns a-b not a+b", fix="return a + b")]

The pipeline runs all 5 layers silently:
    L1: mypy strict (type correctness)
    L2: hypothesis proptests (runtime properties)
    L3: mutation testing (test quality)
    L4: symbolic exec (dead code, taint, null safety, div-by-zero)
    L5: Lean specs (formal guarantees) — when available
"""
from __future__ import annotations

import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Bug:
    line: int
    message: str
    severity: str
    layer: str
    fix: str = ""


@dataclass
class SilentVerifyResult:
    bugs: list[Bug] = field(default_factory=list)
    layers_run: list[str] = field(default_factory=list)
    layers_passed: list[str] = field(default_factory=list)
    layers_failed: list[str] = field(default_factory=list)

    @property
    def clean(self) -> bool:
        return len(self.bugs) == 0

    @property
    def summary(self) -> str:
        if self.clean:
            return f"Verified ({len(self.layers_passed)} layers passed). No bugs found."
        return f"{len(self.bugs)} bug(s) found across {len(self.layers_failed)} layer(s)."

    @property
    def next_step(self) -> str:
        if self.clean:
            return ""
        return self.bugs[0].fix if self.bugs[0].fix else f"Fix line {self.bugs[0].line}: {self.bugs[0].message}"


def verify_silently(
    code: str,
    *,
    file_path: str | None = None,
    run_mutation: bool = False,
    parallel: bool = True,
) -> SilentVerifyResult:
    """Run all verification layers silently. Return only bugs.

    The customer agent calls this on generated code. kairos runs
    all available layers and returns actionable bug reports.
    No Lean terminology. No formal methods jargon. Just bugs.

    When parallel=True, independent layers run concurrently on
    separate threads. Each layer writes to its own SilentVerifyResult
    which are merged at the end (thread-safe by construction — no
    shared mutable state during execution).
    """
    if file_path is None:
        tmp = tempfile.NamedTemporaryFile(suffix=".py", mode="w", delete=False)
        tmp.write(code)
        tmp.flush()
        file_path = tmp.name
        tmp.close()

    path = Path(file_path)

    layers = [
        ("types", _run_mypy, (path,)),
        ("symbolic", _run_symbolic, (path, code)),
        ("properties", _run_properties, (path, code)),
    ]
    if run_mutation:
        layers.append(("mutation", _run_mutation, (path,)))

    if not parallel or len(layers) <= 1:
        result = SilentVerifyResult()
        for _name, fn, args in layers:
            fn(*args, result)
        return result

    from concurrent.futures import ThreadPoolExecutor, as_completed

    per_layer: dict[str, SilentVerifyResult] = {}

    def _run_layer(name: str, fn, args):
        r = SilentVerifyResult()
        fn(*args, r)
        return name, r

    with ThreadPoolExecutor(max_workers=len(layers)) as pool:
        futures = {
            pool.submit(_run_layer, name, fn, args): name
            for name, fn, args in layers
        }
        for future in as_completed(futures):
            name, layer_result = future.result()
            per_layer[name] = layer_result

    merged = SilentVerifyResult()
    for name, _fn, _args in layers:
        lr = per_layer[name]
        merged.layers_run.extend(lr.layers_run)
        merged.layers_passed.extend(lr.layers_passed)
        merged.layers_failed.extend(lr.layers_failed)
        merged.bugs.extend(lr.bugs)

    return merged


def _run_mypy(path: Path, result: SilentVerifyResult) -> None:
    result.layers_run.append("types")
    try:
        from kairos.python_verify import run_mypy
        passed, errors = run_mypy(path)
        if passed:
            result.layers_passed.append("types")
        else:
            result.layers_failed.append("types")
            for e in errors[:5]:
                parts = e.split(":", 3)
                line = int(parts[1]) if len(parts) > 1 and parts[1].strip().isdigit() else 0
                msg = parts[-1].strip() if parts else e
                result.bugs.append(Bug(
                    line=line, message=msg,
                    severity="high", layer="types",
                ))
    except Exception:  # noqa: BLE001
        result.layers_passed.append("types")


def _run_symbolic(path: Path, code: str, result: SilentVerifyResult) -> None:
    result.layers_run.append("symbolic")
    try:
        from kairos.symbolic_exec import analyze
        analysis = analyze(code, str(path))
        if analysis.total_findings == 0:
            result.layers_passed.append("symbolic")
        else:
            result.layers_failed.append("symbolic")
            for f in analysis.dead_code + analysis.null_risks + analysis.div_zero_risks:
                result.bugs.append(Bug(
                    line=f.line, message=f.message,
                    severity=f.severity, layer="symbolic",
                ))
            for t in analysis.taint_flows:
                if not t.sanitized:
                    result.bugs.append(Bug(
                        line=t.sink_line,
                        message=f"unsanitized {t.source} reaches {t.sink}",
                        severity="critical", layer="taint",
                    ))
    except Exception:  # noqa: BLE001
        result.layers_passed.append("symbolic")


def _run_properties(path: Path, code: str, result: SilentVerifyResult) -> None:
    result.layers_run.append("properties")
    try:
        from kairos.python_verify import extract_properties
        props = extract_properties(code, str(path))
        result.layers_passed.append("properties")
        if not props:
            result.bugs.append(Bug(
                line=0,
                message="no verifiable properties found — add type annotations",
                severity="low", layer="properties",
                fix=f"kairos verify {path} --explain",
            ))
    except Exception:  # noqa: BLE001
        result.layers_passed.append("properties")


def _run_mutation(path: Path, result: SilentVerifyResult) -> None:
    result.layers_run.append("mutation")
    try:
        from kairos.python_verify import run_mutation_score
        score, detail = run_mutation_score(path)
        if score is not None and score >= 80:
            result.layers_passed.append("mutation")
        elif score is not None:
            result.layers_failed.append("mutation")
            result.bugs.append(Bug(
                line=0,
                message=f"test quality: {score}% mutation score ({detail})",
                severity="medium", layer="mutation",
                fix=f"kairos repair {path.parent}/tests/ --fix",
            ))
        else:
            result.layers_passed.append("mutation")
    except Exception:  # noqa: BLE001
        result.layers_passed.append("mutation")
