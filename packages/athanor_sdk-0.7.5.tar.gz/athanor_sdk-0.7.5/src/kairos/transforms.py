"""TransformType enum for ATH-1078 Phase 1a conservative mode.

Enumerates all 14 optimization transforms across both phases:

* Phase 1a (REMOVE-only): 9 transforms that strictly reduce area/power
  without adding logic. Provable at k=1 for combo-only identity changes.
* Phase 1b (ADD-for-power): 5 transforms that add gating/isolation
  logic to reduce dynamic power at the cost of small area increase.

The enum IDs match the string IDs in
:mod:`kairos.sec.transformation_taxonomy` exactly, so they can be
cross-referenced with the taxonomy manifest.
"""
from __future__ import annotations

from enum import Enum


class TransformType(str, Enum):
    """All 14 optimization transform types across Phase 1a + 1b."""

    # --- Phase 1a: REMOVE-only (9 transforms) ---
    DEAD_LOGIC = "dead-logic-removal"
    WIDTH_REDUCTION = "width-reduction"
    REDUNDANT_GUARD = "redundant-guard-removal"
    CONSTANT_PROPAGATION = "constant-propagation"
    CSE = "common-subexpression-sharing"
    COMPARISON_NARROWING = "comparison-narrowing"
    MUTUAL_EXCLUSION_PARALLEL_OR = "mutual-exclusion-parallel-or"
    SHIFT_NOT_MULTIPLY = "shift-instead-of-multiply"
    DEAD_CONDITION = "dead-condition-elimination"

    # --- Phase 1b: ADD-for-power (5 transforms) ---
    OPERAND_ISOLATION = "operand-isolation"
    BUS_GATING = "bus-gating"
    CONDITIONAL_COMPUTATION_SKIP = "conditional-computation-skip"
    GRAY_CODE_ENCODING = "gray-code-encoding"
    LATE_SELECT = "late-select"


# Pre-built sets for mode selection.
REMOVE_ONLY: frozenset[TransformType] = frozenset(
    t for t in TransformType if t.value not in {
        "operand-isolation", "bus-gating",
        "conditional-computation-skip", "gray-code-encoding",
        "late-select",
    }
)

ADD_FOR_POWER: frozenset[TransformType] = frozenset(
    t for t in TransformType if t not in REMOVE_ONLY
)

ALL_TRANSFORMS: frozenset[TransformType] = frozenset(TransformType)


__all__ = [
    "TransformType",
    "REMOVE_ONLY",
    "ADD_FOR_POWER",
    "ALL_TRANSFORMS",
]
