"""ATH-357 stream renderer — consumes JSONL from kairos-builder, emits ANSI.

Usage (wired into cli.py as the `stream` subcommand):

    python -m solve.neuron.mode_fleet ... | athanor stream

Mode selection:

    ATHANOR_STREAM_MODE=full|terse|quiet  (default: full)
    ATHANOR_QUIET=1                       (shortcut: quiet)

Rendering:

    [phase_4   ] aristotle  : theorem starves_within REFUTED; cex params=...  CRIT  lean/aristotle_iter_2/COUNTEREXAMPLE.md
    [phase_3   ] ebmc       : p_onset_upper_bound REFUTED at k=12             CRIT  phase3/refine_iter_3/cex.txt

Columns (from left):
    stage        11 chars, bracketed, ljust
    tool         10 chars, colon-terminated, ljust
    headline     truncated to terminal width minus fixed overhead
    severity     4 chars (CRIT/WARN/INFO), right-aligned in colored box
    artifact_path  suffix, dim

TTY is detected via sys.stdout.isatty(); non-TTY (pipe, file) drops
ANSI codes entirely so the stream can be tailed through `tee`, grep,
or piped into a log cleanly.
"""
from __future__ import annotations

import json
import shutil
import sys
from typing import IO, Optional

from kairos.envvars import getenv_dual
from kairos.stream_schema import (
    QUIET_ALLOWED,
    TERSE_SUPPRESSED,
    StreamEvent,
    StreamMode,
)

# ANSI color codes. Dropped when stdout isn't a TTY.
_ANSI_RESET = "\033[0m"
_ANSI_DIM = "\033[2m"
_ANSI_BOLD = "\033[1m"
_ANSI_RED = "\033[31m"
_ANSI_YELLOW = "\033[33m"
_ANSI_CYAN = "\033[36m"
_ANSI_GREEN = "\033[32m"

_SEVERITY_COLOR = {
    "critical": _ANSI_RED,
    "warning": _ANSI_YELLOW,
    "info": _ANSI_CYAN,
}
_SEVERITY_LABEL = {
    "critical": "CRIT",
    "warning": "WARN",
    "info": "INFO",
}
# Reserved for events that don't carry a severity (phase_start etc.).
_EVENT_ACCENT = {
    "phase_start": _ANSI_BOLD,
    "phase_summary": _ANSI_BOLD,
    "verdict": _ANSI_GREEN + _ANSI_BOLD,
    "loop_tick": _ANSI_DIM,
    "cost_tick": _ANSI_DIM,
}


def resolve_mode(explicit: Optional[str] = None) -> StreamMode:
    """Resolve the active stream mode from env vars.

    Precedence:
        explicit argument  (CLI --mode flag)
        ATHANOR_QUIET=1    (shortcut to quiet)
        ATHANOR_STREAM_MODE
        default "full"
    """
    if explicit:
        return _validate_mode(explicit)
    if (getenv_dual("QUIET", "") or "").lower() in ("1", "true", "yes"):
        return "quiet"
    env = (getenv_dual("STREAM_MODE", "") or "").lower()
    if env:
        return _validate_mode(env)
    return "full"


def _validate_mode(value: str) -> StreamMode:
    if value not in ("full", "terse", "quiet"):
        raise ValueError(
            f"Invalid ATHANOR_STREAM_MODE={value!r}; expected one of full|terse|quiet"
        )
    return value  # type: ignore[return-value,unused-ignore]


def should_emit(event: StreamEvent, mode: StreamMode) -> bool:
    """Gate events against the active stream mode."""
    event_type = event.get("event", "")
    if mode == "quiet":
        return event_type in QUIET_ALLOWED
    if mode == "terse":
        return event_type not in TERSE_SUPPRESSED
    return True  # full mode: show everything


class RendererState:
    """Stateful bits the renderer tracks across events.

    ATH-396: agent-depth graph for subagent tree rendering, tool_use_id
    → agent_id map for paired tool_use/tool_result cards, running
    cost + token totals for status lines.
    """

    def __init__(self) -> None:
        # agent_id → depth (0 = root, 1 = first-level subagent, etc.).
        self.agent_depth: dict[str, int] = {}
        # tool_use_id → (agent_id, tool_name) so tool_result can
        # indent to the right depth and name.
        self.open_tool_calls: dict[str, tuple[str, str]] = {}
        # Last-seen totals; rendered on token_tick / cost_tick / verdict.
        self.total_cost_usd: float = 0.0
        self.tokens_in: int = 0
        self.tokens_out: int = 0


# ATH-396: events that use the Claude-Code-style tree-indented layout
# instead of the original bracketed-column format.
_V2_EVENT_TYPES = frozenset({
    "thinking_start",
    "thinking_end",
    "tool_use",
    "tool_result",
    "subagent_spawn",
    "subagent_join",
    "token_tick",
})


def _indent_prefix(depth: int, *, has_branch: bool = True, color: bool = True) -> str:
    """Tree-indent prefix for a given depth.

    `has_branch=True` draws a `├─` / `└─` branch char (renderer
    currently uses `├─` uniformly; last-child detection would require
    look-ahead which we don't have in a streaming context).
    Non-TTY / color=False falls back to ASCII `+--`.
    """
    if depth <= 0:
        return ""
    if color:
        # Two spaces per level, ├─ at the leaf.
        return "  " * (depth - 1) + "├─ "
    return "  " * (depth - 1) + "+- "


def _format_v2_event(
    event: StreamEvent, state: RendererState, *, color: bool = True
) -> str:
    """Render v2 events (thinking, tool_use, tool_result, subagent_*, token_tick).

    Uses the tree-indented Claude-Code-inspired layout. Maintains
    `state.agent_depth` / `state.open_tool_calls` as a side effect so
    a downstream tool_result can match back to its tool_use.
    """
    event_type = event.get("event", "")

    if event_type == "subagent_spawn":
        agent_id = event.get("agent_id", "")
        parent_id = event.get("parent_agent_id", "")
        role = event.get("tool", "") or event.get("model", "") or "agent"
        parent_depth = state.agent_depth.get(parent_id, 0) if parent_id else 0
        depth = parent_depth + 1
        if agent_id:
            state.agent_depth[agent_id] = depth
        prefix = _indent_prefix(depth, color=color)
        headline = event.get("headline", "") or f"spawn · {role}"
        if color:
            return f"{prefix}{_ANSI_CYAN}{role}{_ANSI_RESET} {_ANSI_DIM}{headline}{_ANSI_RESET}"
        return f"{prefix}{role} {headline}"

    if event_type == "subagent_join":
        agent_id = event.get("agent_id", "")
        depth = state.agent_depth.pop(agent_id, 1) if agent_id else 1
        ok = event.get("tool_result_ok", True)
        glyph = "✓" if ok else "✗"
        glyph_color = _ANSI_GREEN if ok else _ANSI_RED
        prefix = _indent_prefix(depth, color=color)
        role = event.get("tool", "") or event.get("model", "") or "agent"
        headline = event.get("headline", "") or "done"
        if color:
            return f"{prefix}{glyph_color}{glyph}{_ANSI_RESET} {_ANSI_DIM}{role} · {headline}{_ANSI_RESET}"
        return f"{prefix}{glyph} {role} · {headline}"

    if event_type == "thinking_start":
        agent_id = event.get("agent_id", "")
        depth = state.agent_depth.get(agent_id, 0) if agent_id else 0
        prefix = _indent_prefix(depth, color=color)
        model = event.get("model", "") or event.get("tool", "") or "model"
        if color:
            return f"{prefix}{_ANSI_DIM}{model} thinking…{_ANSI_RESET}"
        return f"{prefix}{model} thinking..."

    if event_type == "thinking_end":
        agent_id = event.get("agent_id", "")
        depth = state.agent_depth.get(agent_id, 0) if agent_id else 0
        prefix = _indent_prefix(depth, color=color)
        elapsed = event.get("elapsed_sec")
        model = event.get("model", "") or event.get("tool", "") or "model"
        elapsed_s = f"  ({elapsed:.0f}s)" if isinstance(elapsed, (int, float)) else ""
        if color:
            return f"{prefix}{_ANSI_DIM}{model} done{elapsed_s}{_ANSI_RESET}"
        return f"{prefix}{model} done{elapsed_s}"

    if event_type == "tool_use":
        agent_id = event.get("agent_id", "")
        depth = state.agent_depth.get(agent_id, 0) if agent_id else 0
        tool_name = event.get("tool_name", "") or event.get("tool", "") or "tool"
        tool_args = event.get("tool_args", "")
        tool_use_id = event.get("tool_use_id", "")
        if tool_use_id:
            state.open_tool_calls[tool_use_id] = (agent_id, tool_name)
        prefix = _indent_prefix(depth, color=color)
        args_s = f"({tool_args})" if tool_args else "()"
        if color:
            return f"{prefix}{_ANSI_GREEN}→{_ANSI_RESET} {_ANSI_BOLD}{tool_name}{_ANSI_RESET}{args_s}"
        return f"{prefix}-> {tool_name}{args_s}"

    if event_type == "tool_result":
        tool_use_id = event.get("tool_use_id", "")
        agent_id, tool_name = state.open_tool_calls.pop(tool_use_id, ("", ""))
        if not tool_name:
            tool_name = event.get("tool_name", "") or event.get("tool", "") or "tool"
        if not agent_id:
            agent_id = event.get("agent_id", "")
        depth = state.agent_depth.get(agent_id, 0) if agent_id else 0
        ok = event.get("tool_result_ok", True)
        preview = event.get("tool_result_preview", "") or event.get("headline", "")
        prefix = _indent_prefix(depth, color=color)
        arrow = "←" if color else "<-"
        arrow_color = _ANSI_GREEN if ok else _ANSI_RED
        ok_badge = "" if ok else (" [err]" if not color else f" {_ANSI_RED}[err]{_ANSI_RESET}")
        if color:
            return f"{prefix}{arrow_color}{arrow}{_ANSI_RESET} {_ANSI_DIM}{preview}{_ANSI_RESET}{ok_badge}"
        return f"{prefix}{arrow} {preview}{ok_badge}"

    if event_type == "token_tick":
        tokens_in = event.get("tokens_in")
        tokens_out = event.get("tokens_out")
        cost_usd = event.get("cost_usd")
        if isinstance(tokens_in, int):
            state.tokens_in = tokens_in
        if isinstance(tokens_out, int):
            state.tokens_out = tokens_out
        if isinstance(cost_usd, (int, float)):
            state.total_cost_usd = float(cost_usd)
        parts = []
        if state.total_cost_usd > 0:
            parts.append(f"${state.total_cost_usd:.2f}")
        if state.tokens_in or state.tokens_out:
            parts.append(f"{state.tokens_in:,}↑ {state.tokens_out:,}↓")
        body = "  ".join(parts) if parts else "—"
        label = "[usage]"
        if color:
            return f"{_ANSI_DIM}{label} {body}{_ANSI_RESET}"
        return f"{label} {body}"

    # Fallback — unknown v2 event; emit a dim raw line so forward-compat
    # new event types don't crash the renderer.
    return f"{_ANSI_DIM}[{event_type}] {event.get('headline', '')}{_ANSI_RESET}" if color else f"[{event_type}] {event.get('headline', '')}"


def format_event(event: StreamEvent, *, color: bool = True, state: Optional["RendererState"] = None) -> str:
    """Format a single event as a one-line rendering.

    `color=False` emits plain text (for non-TTY output).
    `state` is an optional RendererState; v2 events (tool_use, etc.)
    need it for tree depth tracking. If None, a throwaway state is
    created per-call — v1 events don't care.
    """
    event_type = event.get("event", "unknown")

    if event_type in _V2_EVENT_TYPES:
        if state is None:
            state = RendererState()
        return _format_v2_event(event, state, color=color)

    # v1 path (original format).
    stage = event.get("stage", "")
    tool = event.get("tool", "")
    severity = event.get("severity", "info")
    headline = event.get("headline", "")
    artifact = event.get("artifact_path", "")

    # Fixed column widths.
    stage_col = f"[{stage:<9}]"
    tool_col = f"{tool:<10}:"

    # Severity box.
    sev_label = _SEVERITY_LABEL.get(severity, severity.upper()[:4])

    # Assemble the middle (stage, tool, headline).
    middle = f"{stage_col} {tool_col} {headline}"

    # Right-side suffix — severity + artifact dim.
    suffix_parts = [f"  {sev_label}"]
    if artifact:
        suffix_parts.append(f"  {artifact}")
    suffix = "".join(suffix_parts)

    if not color:
        return f"{middle}{suffix}"

    # Coloring.
    sev_color = _SEVERITY_COLOR.get(severity, "")
    accent = _EVENT_ACCENT.get(event_type, "")

    # Stage accent for phase_start/phase_summary/verdict.
    stage_rendered = f"{accent}{stage_col}{_ANSI_RESET}" if accent else stage_col
    tool_rendered = f"{_ANSI_CYAN}{tool_col}{_ANSI_RESET}"

    # Headline picks up severity color when severity is critical/warning,
    # else stays default (info renders cyan on accent, default otherwise).
    if severity == "critical":
        headline_rendered = f"{_ANSI_RED}{headline}{_ANSI_RESET}"
    elif severity == "warning":
        headline_rendered = f"{_ANSI_YELLOW}{headline}{_ANSI_RESET}"
    else:
        headline_rendered = headline

    sev_rendered = f"  {sev_color}{sev_label}{_ANSI_RESET}" if sev_color else f"  {sev_label}"
    artifact_rendered = f"  {_ANSI_DIM}{artifact}{_ANSI_RESET}" if artifact else ""

    # Optional tail: cost_usd, elapsed_sec — only on phase_summary /
    # verdict / cost_tick events that carry them.
    extras = []
    if "cost_usd" in event:
        extras.append(f"${event['cost_usd']:.2f}")
    if "elapsed_sec" in event:
        extras.append(f"{event['elapsed_sec']:.0f}s")
    extras_rendered = f"  {_ANSI_DIM}{' '.join(extras)}{_ANSI_RESET}" if extras else ""

    return f"{stage_rendered} {tool_rendered} {headline_rendered}{sev_rendered}{extras_rendered}{artifact_rendered}"


def render_stream(
    source: IO[str],
    *,
    mode: StreamMode = "full",
    color: Optional[bool] = None,
    out: Optional[IO[str]] = None,
) -> int:
    """Read JSONL events from `source`, render to `out` (default stdout).

    `color=None` (default) auto-detects via out.isatty().

    Returns the count of events rendered (useful for tests).
    """
    out = out or sys.stdout
    if color is None:
        color = bool(getattr(out, "isatty", lambda: False)())

    n = 0
    state = RendererState()
    for raw in source:
        raw = raw.strip()
        if not raw:
            continue
        try:
            event: StreamEvent = json.loads(raw)
        except json.JSONDecodeError:
            # Non-JSON noise: echo dim, don't crash the renderer.
            line = f"{_ANSI_DIM}{raw}{_ANSI_RESET}" if color else raw
            print(line, file=out, flush=True)
            continue
        if not should_emit(event, mode):
            continue
        print(format_event(event, color=color, state=state), file=out, flush=True)
        n += 1
    return n


def main(argv: Optional[list[str]] = None) -> int:
    """CLI entry — invoked by `athanor stream`."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="athanor stream",
        description="Render an athanor-builder JSONL event stream as ANSI.",
    )
    parser.add_argument(
        "--mode",
        choices=("full", "terse", "quiet"),
        default=None,
        help="Explicit mode override (else reads ATHANOR_STREAM_MODE / ATHANOR_QUIET).",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable ANSI output (auto-disabled when stdout is not a TTY).",
    )
    parser.add_argument(
        "--file",
        default=None,
        help="Read events from a file instead of stdin.",
    )
    args = parser.parse_args(argv)

    mode = resolve_mode(args.mode)
    color = None if not args.no_color else False

    if args.file:
        with open(args.file) as f:
            render_stream(f, mode=mode, color=color)
    else:
        render_stream(sys.stdin, mode=mode, color=color)
    return 0


if __name__ == "__main__":
    sys.exit(main())


# Keep imports resolved even when the platform's terminal is narrow.
_ = shutil.get_terminal_size
