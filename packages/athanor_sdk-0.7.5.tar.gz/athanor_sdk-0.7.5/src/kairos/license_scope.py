"""ATH-389 + ATH-686 — runtime enforcement of license scope claims.

Two layers, both run on every paid-tier callsite:

1. **Cryptographic gate** (ATH-369 `verify_license_signature`): the
   license file at `~/.athanor/license.json` carries a detached GPG
   signature; the SDK ships the Athanor pubkey + expected fingerprint
   under `kairos/_keys/`; verification proves the license was issued
   by Athanor and not forged by a customer.

2. **Policy gate** (this module): the verified license carries
   `products` (which SKUs the customer bought), `envs` (specific
   verticals), and `expires_at`. `require_product` rejects expired
   licenses, missing claims, and dev-mode bypass attempts.

## ATH-686 fail-closed change (2026-04-26)

Pre-ATH-686 behavior: a missing `~/.athanor/license.json` returned a
permissive sentinel — anyone without a license file got paid features
free. Sam-flagged ts=1777185155 ("absolutely sure paid version cannot
be accessed by anyone who is not a customer").

Post-ATH-686 behavior:

- Missing license file → `LicenseScopeError` raised. No fall-through.
- Forged license (signature fails) → `LicenseScopeError` raised.
- Expired license → `LicenseScopeError` raised with renewal CTA.
- Wrong product → `LicenseScopeError` raised with upgrade CTA.

Internal dev/CI uses an explicit opt-in env var (`KAIROS_DEV_NO_LICENSE=1`)
that bypasses both gates for our internal CI workflows. The env var is
*not documented for customers*; it's a soft gate at v1.0 launch and
will be replaced by a build-time-baked token in v1.1.

## Two claims in license.json

- `products: ["envs", "solve"]` — SKUs the customer bought.
  `"solve"` gates the entire paid tier (`prove`, `solve`, `cegar`,
  `Orchestrator`, `kairos.sv.*`, `SupabaseTraceSink` writes to
  `*.athanor-ai.com`).
- `envs: ["neuron-nki", "sysverilog", ...]` — specific envs the
  customer is licensed for.

Plus standard claims: `subject`, `expires_at`, `signature`.
"""
from __future__ import annotations

import json
import logging
import os

from kairos.envvars import getenv_dual
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


LICENSE_JSON_PATH = ".athanor/license.json"

# ATH-997: build-time dev token bypass replaces the old env-var bypass.
# Internal dev/CI wheels bake a token via `build_cython.py --dev`.
# Customer wheels ship _build_meta.DEV_TOKEN = None. The env var
# KAIROS_DEV_NO_LICENSE only activates when the build-time token is
# present (dev wheel) — customer wheels ignore the env var entirely.
_DEV_BYPASS_ENV = "KAIROS_DEV_NO_LICENSE"

def _is_dev_build() -> bool:
    """True iff this wheel was built with --dev (has a baked token)."""
    try:
        from kairos._build_meta import DEV_TOKEN
        return DEV_TOKEN is not None
    except ImportError:
        return False


# ATH-845 — the canonical LicenseScopeError class lives in
# kairos.errors. Re-exported here so existing
# `from kairos.license_scope import LicenseScopeError` keeps working.
# Multiple inheritance in the canonical declaration also preserves
# `except RuntimeError` compatibility for any pre-ATH-845 customer
# code that was relying on the old base class.
from kairos.errors import LicenseScopeError  # noqa: F401


@dataclass(frozen=True)
class License:
    """Parsed subset of `license.json` the SDK cares about."""
    products: frozenset[str] = field(default_factory=frozenset)
    envs: frozenset[str] = field(default_factory=frozenset)
    subject: str = ""
    expires_at: datetime | None = None
    # Keep the raw dict around so downstream code can read bespoke
    # claims without re-parsing.
    raw: dict[str, Any] = field(default_factory=dict)
    # Internal dev-bypass marker. NEVER set from JSON — `_parse` always
    # constructs License instances with the default False. Forging
    # `__dev_bypass__: true` (or any other key) inside license.json
    # cannot flip this; only the in-process `_DEV_BYPASS_LICENSE`
    # singleton has it set, and that singleton is only returned when
    # KAIROS_DEV_NO_LICENSE=1 AND no license file exists.
    _internal_dev_bypass: bool = False

    @property
    def is_dev_bypass(self) -> bool:
        """True iff this is the explicit internal dev-bypass (no real license).

        Pre-ATH-686 had a `is_permissive` property for the silent
        fall-through; that is now the dev-bypass and only set when the
        `KAIROS_DEV_NO_LICENSE` env var is `1`. The flag lives on a
        constructor-only field that `_parse` never touches, so a
        customer cannot forge it through license.json content.
        """
        return self._internal_dev_bypass


# Internal dev-bypass sentinel. Only returned when the env var is set.
_DEV_BYPASS_LICENSE = License(_internal_dev_bypass=True)


# In-process cache. Reloaded when `ATHANOR_LICENSE_RELOAD=1` or the
# file mtime changes.
_cache_lock = threading.Lock()
_cached_license: License | None = None
_cached_mtime: float | None = None


def _license_path(home: Path | None = None) -> Path:
    return (home or Path.home()) / LICENSE_JSON_PATH


def _parse_expires_at(raw: dict[str, Any]) -> datetime | None:
    """Parse the `expires_at` ISO-8601 timestamp, or None when absent."""
    exp = raw.get("expires_at")
    if exp is None:
        return None
    if not isinstance(exp, str):
        raise LicenseScopeError(
            f"license.expires_at must be an ISO-8601 string; got {type(exp).__name__}"
        )
    try:
        # Accept both "Z" and "+00:00" suffixes.
        dt = datetime.fromisoformat(exp.replace("Z", "+00:00"))
    except ValueError as e:
        raise LicenseScopeError(
            f"license.expires_at is not a valid ISO-8601 timestamp: {exp!r} ({e})"
        )
    if dt.tzinfo is None:
        # ATH-686 P2: a date-only or naive timestamp would TypeError when
        # compared against `datetime.now(tz=UTC)` in load_license. Reject
        # up front with a clean LicenseScopeError instead.
        raise LicenseScopeError(
            f"license.expires_at must include a timezone offset "
            f"(e.g. 'Z' or '+00:00'); got naive timestamp {exp!r}"
        )
    return dt


def _parse(raw: dict[str, Any]) -> License:
    products = raw.get("products", [])
    envs = raw.get("envs", [])
    subject = raw.get("subject", "")
    if not isinstance(products, list) or not all(isinstance(p, str) for p in products):
        raise LicenseScopeError(
            f"license.products must be a list of strings; got {products!r}"
        )
    if not isinstance(envs, list) or not all(isinstance(e, str) for e in envs):
        raise LicenseScopeError(
            f"license.envs must be a list of strings; got {envs!r}"
        )
    if subject and not isinstance(subject, str):
        raise LicenseScopeError(
            f"license.subject must be a string; got {type(subject).__name__}"
        )
    return License(
        products=frozenset(products),
        envs=frozenset(envs),
        subject=subject,
        expires_at=_parse_expires_at(raw),
        raw=raw,
    )


def _verify_signature_if_keys_bundled(license_path: Path) -> None:
    """Run GPG signature verification when bundled keys are available.

    During the ATH-686-keys grace period (between this code-wiring PR
    and the GPG-key provisioning by Sam), the bundled pubkey may be a
    placeholder. We detect that and skip the cryptographic verification
    rather than fail-closed; instead the policy gate alone defends
    until real keys land. `kairos/_keys/__init__.py` controls the
    grace-period flag.

    On a real wheel with provisioned keys, this calls
    `kairos.sdk_security.verify_license_signature` and raises
    `LicenseScopeError` on any failure (forged signature, fingerprint
    mismatch, missing .sig file, clock skew).
    """
    try:
        from kairos._keys import (
            BUNDLED_PUBKEY_PATH,
            EXPECTED_FINGERPRINT,
            KEYS_PROVISIONED,
        )
    except ImportError:
        # No `_keys/` module shipped → grace period; policy gate only.
        logger.warning(
            "kairos._keys module missing — license signature verification "
            "skipped. This is OK during the ATH-686 grace period but "
            "MUST be resolved before v1.0 launch."
        )
        return

    if not KEYS_PROVISIONED:
        logger.debug(
            "kairos._keys reports KEYS_PROVISIONED=False — license "
            "signature verification skipped."
        )
        return

    from kairos.sdk_security import (
        LicenseVerifyError,
        verify_license_signature,
    )

    try:
        verify_license_signature(
            license_path,
            BUNDLED_PUBKEY_PATH,
            EXPECTED_FINGERPRINT,
        )
    except LicenseVerifyError as e:
        _audit(gate_name="load_license", gate_argument=str(license_path),
               decision="deny", reason="signature_verify_failed",
               extra_context={"error_class": type(e).__name__})
        raise LicenseScopeError(
            f"license signature verification failed: {e}. "
            f"Reinstall from a signed Athanor tarball or contact "
            f"Run: kairos eval-license --days 30"
        ) from e


def load_license(home: Path | None = None) -> License:
    """Return the parsed + signature-verified + non-expired license.

    Raises `LicenseScopeError` when:
    - License file is missing AND `KAIROS_DEV_NO_LICENSE` is not set.
    - License file is malformed (JSON parse error, wrong shape).
    - License signature verification fails (bundled pubkey + fingerprint).
    - License is expired (per `expires_at` claim).

    Returns the dev-bypass sentinel when `KAIROS_DEV_NO_LICENSE=1` is
    set AND no license file exists. The sentinel passes all
    `require_product` / `require_env_access` checks; it's intended for
    internal CI workflows only.

    Cached in-process; reloaded when the file mtime changes or when
    `ATHANOR_LICENSE_RELOAD=1` is set.
    """
    global _cached_license, _cached_mtime

    path = _license_path(home)

    # ATH-997: dev bypass requires BOTH build-time token AND env var.
    # Customer wheels have no token, so the env var alone does nothing.
    if not path.is_file():
        if _is_dev_build() and os.environ.get(_DEV_BYPASS_ENV) == "1":
            logger.info(
                "kairos.license_scope: dev-build token present + "
                "KAIROS_DEV_NO_LICENSE=1 set; bypassing license check."
            )
            _audit(gate_name="load_license", gate_argument=str(path),
                   decision="dev_bypass", license_=_DEV_BYPASS_LICENSE)
            return _DEV_BYPASS_LICENSE
        _audit(gate_name="load_license", gate_argument=str(path),
               decision="deny", reason="no_license_file")
        raise LicenseScopeError(
            f"no license file found at {path}. Athanor SDK paid features "
            f"require a valid license. Run: kairos eval-license --days 30 to "
            f"discuss pricing for your use case. Base SDK alternatives "
            f"that do not require a license: kairos.simple_prove() and kairos.simple_prove_template(), "
            f"kairos verify-batch (bulk Lean verification)."
        )

    with _cache_lock:
        reload_requested = getenv_dual("LICENSE_RELOAD") == "1"
        try:
            current_mtime = path.stat().st_mtime
        except OSError as e:
            raise LicenseScopeError(
                f"license file at {path} is unreadable: {e}"
            )

        if (
            _cached_license is not None
            and _cached_mtime == current_mtime
            and not reload_requested
        ):
            return _cached_license

        # Verify signature BEFORE parsing — reject forged JSON early.
        _verify_signature_if_keys_bundled(path)

        try:
            raw = json.loads(path.read_text())
        except (json.JSONDecodeError, OSError) as exc:
            raise LicenseScopeError(
                f"license.json at {path} is unreadable: {exc}. Reinstall "
                "from a signed enterprise tarball."
            )
        if not isinstance(raw, dict):
            raise LicenseScopeError(
                f"license.json at {path} must be a JSON object; "
                f"got {type(raw).__name__}."
            )

        parsed = _parse(raw)

        # Expiration check.
        if parsed.expires_at is not None:
            now_utc = datetime.now(timezone.utc)
            if parsed.expires_at < now_utc:
                _audit(gate_name="load_license",
                       gate_argument=str(path),
                       decision="deny",
                       reason="license_expired",
                       license_=parsed)
                raise LicenseScopeError(
                    f"license expired at {parsed.expires_at.isoformat()} "
                    f"(now {now_utc.isoformat()}). Contact "
                    f"Run: kairos eval-license --days 30 to renew."
                )

        _cached_license = parsed
        _cached_mtime = current_mtime
        return parsed


def _caller_callsite(skip: int = 3) -> str:
    """Best-effort: return `<module>.<function>` of the user-code frame
    `skip` levels above this helper. Default `skip=3` walks past
    `_caller_callsite` → `_audit` → the gate fn (e.g. `require_product`)
    to reach the user-code caller. Used to populate
    `AuditEvent.call_site` so the row answers "what code path tripped
    this gate?".

    Falls back to "" on any introspection failure — call_site is
    forensic enrichment, not load-bearing.

    ATH-1271 (2026-05-14): when running under mutmut, the `_audit` →
    gate-fn chain passes through a `_mutmut_trampoline` frame and one
    or more `x_<func>__mutmut_orig` wrapper frames injected by mutmut
    into mutated modules. Those frames are NOT user code; the
    `skip=3` default walks INTO them instead of past them, leaving
    `call_site` reporting "kairos.license_scope._mutmut_trampoline"
    rather than the real caller. Skip-while loop below walks past
    any frame whose `co_name` matches the mutmut convention
    (`_mutmut_trampoline` or starts with `x_` + ends with
    `__mutmut_orig` / `__mutmut_mutants`). Behavior unchanged outside
    mutmut.
    """
    try:
        import inspect

        def _is_mutmut_impl_frame(f: Any) -> bool:
            """ATH-1271: ``x_<name>__mutmut_orig`` / ``__mutmut_<n>``
            frames are mutmut implementation detail — the renamed
            original (or a mutated variant) sitting BEHIND the public
            name. They are NOT user-visible layers and walk for free.

            By contrast, ``_mutmut_trampoline`` IS user-visible: after
            mutmut rewrites the module, the public name (e.g.
            ``require_product``) is bound to ``_mutmut_trampoline``,
            so a trampoline frame represents the public-function call
            site and counts as one normal skip layer."""
            n = f.f_code.co_name
            return n.startswith("x_") and "__mutmut_" in n

        # ATH-1271: walk by USER-VISIBLE layers, not raw frame count.
        # mutmut's codegen wraps each mutated function with a pair:
        # ``x_<name>__mutmut_orig`` (the renamed original body) and
        # ``_mutmut_trampoline`` (the dispatcher bound to the public
        # name). The trampoline IS the public callsite — same
        # user-visible layer as the pre-mutation function — so it
        # counts as one skip credit. The ``x_*__mutmut_*`` frame is a
        # behind-the-scenes pass-through and walks for free.
        # Pre-mutmut equivalence: skip=3 starts at _caller_callsite
        # frame and walks 3 layers (_caller_callsite + _audit +
        # require_product), landing on the user-code frame.
        # Bounded at 64 hops to avoid pathological walking.
        frame = inspect.currentframe()
        layers_remaining = skip
        hops = 0
        while frame is not None and layers_remaining > 0 and hops < 64:
            hops += 1
            if _is_mutmut_impl_frame(frame):
                frame = frame.f_back
                continue
            # User-visible layer: consume one skip credit AND walk past.
            layers_remaining -= 1
            frame = frame.f_back
        # If we stopped on a mutmut impl frame, continue past it to
        # the next user-visible layer.
        while frame is not None and _is_mutmut_impl_frame(frame):
            frame = frame.f_back
        if frame is None:
            return ""
        module = inspect.getmodule(frame)
        mod_name = module.__name__ if module else ""
        func_name = frame.f_code.co_name
        qualname = frame.f_code.co_qualname if hasattr(
            frame.f_code, "co_qualname"
        ) else func_name
        return f"{mod_name}.{qualname}" if mod_name else qualname
    except Exception:  # noqa: BLE001
        return ""


def _audit(
    *,
    gate_name: str,
    gate_argument: str,
    decision: str,
    reason: str = "",
    license_: License | None = None,
    extra_context: dict[str, Any] | None = None,
) -> None:
    """Emit one audit-log decision via the lazy kairos.audit_log module.

    Imported lazily so a customer who explicitly opts out of audit
    logging by replacing the module (or a test that mocks it) doesn't
    pay the import cost until the first license-gate call.

    `license_` may be None for fail-closed `load_license` paths where
    no license object exists yet (no_license_file, malformed, etc).
    """
    try:
        from kairos.audit_log import emit_decision

        # Build context dict — non-sensitive enrichment per platform contract.
        ctx: dict[str, Any] = {}
        if license_ is not None:
            ctx["granted_products"] = sorted(license_.products)
            ctx["granted_envs"] = sorted(license_.envs)
            if license_.expires_at is not None:
                ctx["expires_at"] = license_.expires_at.isoformat()
        if extra_context:
            ctx.update(extra_context)

        # Best-effort call_site capture (default skip walks past
        # _caller_callsite + _audit + gate-fn to reach user code).
        call_site = _caller_callsite()

        # license_subject / organization_id pulled from the license when
        # we have one; both default to None for fail-closed paths.
        subject = license_.subject if license_ is not None else None
        org_id = (
            license_.raw.get("organization_id")
            if license_ is not None else None
        )

        emit_decision(
            gate_name=gate_name,
            gate_argument=gate_argument,
            decision=decision,
            reason=reason,
            license_subject=subject or None,  # "" → None per platform contract
            organization_id=org_id,
            call_site=call_site,
            context=ctx,
        )
    except Exception:  # noqa: BLE001 — audit must never affect gate outcome
        logger.exception("license_scope: audit emit raised, swallowing")


def require_product(product: str, home: Path | None = None) -> None:
    """Raise `LicenseScopeError` if the license does not grant `product`.

    ATH-686 fail-closed: missing license file raises (unless
    KAIROS_DEV_NO_LICENSE=1). Forged or expired license raises.

    ATH-690: emits one audit-log row per call (allow / deny / dev_bypass).
    The audit emit never affects the policy outcome.
    """
    license_ = load_license(home)
    if license_.is_dev_bypass:
        # Internal dev bypass; permitted.
        _audit(gate_name="require_product", gate_argument=product,
               decision="dev_bypass", license_=license_)
        return
    if product not in license_.products:
        granted = ", ".join(sorted(license_.products)) or "(none)"
        _audit(gate_name="require_product", gate_argument=product,
               decision="deny", reason="product_not_granted",
               license_=license_)
        raise LicenseScopeError(
            f"license does not grant access to product '{product}'. "
            f"Granted products: {granted}. "
            f"Run: kairos eval-license --days 30"
        )
    _audit(gate_name="require_product", gate_argument=product,
           decision="allow", license_=license_)


def require_env_access(env_name: str, home: Path | None = None) -> None:
    """Raise `LicenseScopeError` if the license does not grant `env_name`.

    Also requires the `"envs"` product — an envs-scoped check with no
    envs product is a license misconfiguration and we surface it.

    ATH-690: emits one audit-log row per call (allow / deny / dev_bypass).
    """
    license_ = load_license(home)
    if license_.is_dev_bypass:
        _audit(gate_name="require_env_access", gate_argument=env_name,
               decision="dev_bypass", license_=license_)
        return
    if "envs" not in license_.products:
        granted_products = ', '.join(sorted(license_.products)) or '(none)'
        _audit(gate_name="require_env_access", gate_argument=env_name,
               decision="deny", reason="envs_product_missing",
               license_=license_)
        raise LicenseScopeError(
            f"license does not grant access to the 'envs' product "
            f"(required to use Environment('{env_name}')). "
            f"Granted products: {granted_products}. "
            "Run: kairos eval-license --days 30"
        )
    if env_name not in license_.envs:
        granted = ", ".join(sorted(license_.envs)) or "(none)"
        _audit(gate_name="require_env_access", gate_argument=env_name,
               decision="deny", reason="env_not_granted",
               license_=license_)
        raise LicenseScopeError(
            f"license does not grant access to environment '{env_name}'. "
            f"Licensed environments: {granted}. "
            "Run: kairos eval-license to license this environment."
        )
    _audit(gate_name="require_env_access", gate_argument=env_name,
           decision="allow", license_=license_)


def clear_license_cache() -> None:
    """Drop the in-process license cache. Useful for tests."""
    global _cached_license, _cached_mtime
    with _cache_lock:
        _cached_license = None
        _cached_mtime = None


__all__ = [
    "License",
    "LicenseScopeError",
    "load_license",
    "require_product",
    "require_env_access",
    "clear_license_cache",
]
