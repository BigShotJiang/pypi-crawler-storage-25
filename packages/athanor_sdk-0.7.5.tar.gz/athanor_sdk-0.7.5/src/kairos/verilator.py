"""ATH-1005: Verilator wrapper + VCD toggle-activity counter.

Power proxy via switching activity: compile SV with Verilator,
run simulation dumping VCD, parse VCD for toggle counts per signal.

Honest-framing: surfaces as "switching activity (toggles/cycle)"
not "power (watts)". Verilator toggle-count is a relative proxy;
absolute power requires liberty-aware tooling.
"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# ATH-1212a: strip Athanor + customer credentials from the verilator
# pipeline subprocess env. All three sites (verilator compile / make / run
# the generated simulation binary) are part of the verilator verification
# vertical and share the factory.
from kairos.security.env_allowlist import safe_env_for_verilator


@dataclass(frozen=True)
class ToggleCount:
    signal: str
    width: int
    toggles: int
    toggles_per_cycle: float


@dataclass(frozen=True)
class VerilatorRunResult:
    cycles_run: int
    total_toggles: int
    toggles_per_cycle: float
    per_signal: list[ToggleCount] = field(default_factory=list)
    vcd_path: str | None = None
    compile_ok: bool = True
    error: str | None = None

    def delta_vs(self, other: "VerilatorRunResult") -> dict[str, Any]:
        """Compare switching activity against another result."""
        if self.toggles_per_cycle == 0 or other.toggles_per_cycle == 0:
            return {"delta_pct": None, "reason": "zero baseline"}
        delta = (
            (self.toggles_per_cycle - other.toggles_per_cycle)
            / other.toggles_per_cycle
            * 100
        )
        return {
            "gold_toggles_per_cycle": other.toggles_per_cycle,
            "gate_toggles_per_cycle": self.toggles_per_cycle,
            "delta_pct": round(delta, 2),
            "fewer_toggles": delta < 0,
        }


def _find_verilator() -> str | None:
    return shutil.which("verilator")


def _parse_vcd_toggles(vcd_path: Path, n_cycles: int) -> list[ToggleCount]:
    """Parse VCD file and count signal toggles."""
    if not vcd_path.is_file():
        return []

    signal_map: dict[str, tuple[str, int]] = {}
    toggle_counts: dict[str, int] = {}
    last_values: dict[str, str] = {}
    in_defs = False

    for line in vcd_path.read_text(errors="replace").splitlines():
        if line.startswith("$var"):
            parts = line.split()
            if len(parts) >= 5:
                width = int(parts[2]) if parts[2].isdigit() else 1
                code = parts[3]
                name = parts[4]
                signal_map[code] = (name, width)
                toggle_counts[code] = 0
                last_values[code] = ""
        elif line.startswith("#"):
            continue
        elif len(line) >= 2 and line[0] in ("0", "1", "x", "z"):
            code = line[1:]
            val = line[0]
            if code in last_values and last_values[code] and last_values[code] != val:
                toggle_counts[code] = toggle_counts.get(code, 0) + 1
            last_values[code] = val
        elif line.startswith("b"):
            parts = line.split()
            if len(parts) == 2:
                val = parts[0]
                code = parts[1]
                if code in last_values and last_values[code] and last_values[code] != val:
                    toggle_counts[code] = toggle_counts.get(code, 0) + 1
                last_values[code] = val

    results = []
    for code, (name, width) in signal_map.items():
        t = toggle_counts.get(code, 0)
        tpc = t / max(n_cycles, 1)
        results.append(ToggleCount(
            signal=name, width=width, toggles=t,
            toggles_per_cycle=round(tpc, 4),
        ))

    return sorted(results, key=lambda x: -x.toggles)


def compile_and_run(
    sv_sources: list[str | Path],
    *,
    top_module: str,
    n_cycles: int = 1000,
    timeout_sec: int = 120,
) -> VerilatorRunResult:
    """Compile SV with Verilator, run simulation, parse VCD toggles.

    Args:
        sv_sources: list of SystemVerilog source file paths
        top_module: top-level module name
        n_cycles: number of simulation cycles
        timeout_sec: compilation + simulation timeout
    """
    verilator = _find_verilator()
    if verilator is None:
        return VerilatorRunResult(
            cycles_run=0, total_toggles=0, toggles_per_cycle=0,
            compile_ok=False,
            error="verilator not found on PATH. Install: apt install verilator",
        )

    work_dir = Path(tempfile.mkdtemp(prefix="kairos_verilator_"))
    vcd_path = work_dir / "trace.vcd"

    driver_cpp = work_dir / "driver.cpp"
    driver_cpp.write_text(f"""
#include "V{top_module}.h"
#include "verilated.h"
#include "verilated_vcd_c.h"

int main(int argc, char** argv) {{
    Verilated::commandArgs(argc, argv);
    Verilated::traceEverOn(true);
    V{top_module}* top = new V{top_module};
    VerilatedVcdC* tfp = new VerilatedVcdC;
    top->trace(tfp, 99);
    tfp->open("{vcd_path}");

    for (int i = 0; i < {n_cycles}; i++) {{
        top->clk = 0;
        top->eval();
        tfp->dump(i * 2);
        top->clk = 1;
        top->eval();
        tfp->dump(i * 2 + 1);
    }}
    tfp->close();
    delete top;
    return 0;
}}
""")

    sources_str = " ".join(str(Path(s).resolve()) for s in sv_sources)
    compile_cmd = (
        f"{verilator} --cc --trace --exe "
        f"--top-module {top_module} "
        f"{sources_str} {driver_cpp}"
    )

    try:
        subprocess.run(  # nosemgrep: subprocess-shell-true
            # verilator compile-step requires shell to expand glob/$()
            # in sources_str + driver_cpp paths. env-allowlist via
            # safe_env_for_verilator (ATH-1212a site #7).
            compile_cmd, shell=True, cwd=str(work_dir),  # nosemgrep
            capture_output=True, text=True, timeout=timeout_sec,
            check=True,
            env=safe_env_for_verilator(),  # ATH-1212a
        )
    except subprocess.CalledProcessError as e:
        return VerilatorRunResult(
            cycles_run=0, total_toggles=0, toggles_per_cycle=0,
            compile_ok=False,
            error=f"verilator compile failed: {e.stderr[:500]}",
        )
    except subprocess.TimeoutExpired:
        return VerilatorRunResult(
            cycles_run=0, total_toggles=0, toggles_per_cycle=0,
            compile_ok=False,
            error=f"verilator compile timed out after {timeout_sec}s",
        )

    make_cmd = f"make -j$(nproc) -C obj_dir -f V{top_module}.mk V{top_module}"
    try:
        subprocess.run(  # nosemgrep: subprocess-shell-true
            # make $(nproc) substitution requires shell. env-allowlist
            # via safe_env_for_verilator (ATH-1212a site #7).
            make_cmd, shell=True, cwd=str(work_dir),  # nosemgrep
            capture_output=True, text=True, timeout=timeout_sec,
            check=True,
            env=safe_env_for_verilator(),  # ATH-1212a
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        return VerilatorRunResult(
            cycles_run=0, total_toggles=0, toggles_per_cycle=0,
            compile_ok=False,
            error=f"verilator make failed: {str(e)[:500]}",
        )

    sim_cmd = f"./obj_dir/V{top_module}"
    try:
        subprocess.run(  # nosemgrep: subprocess-shell-true
            # sim binary path-relative-execution requires shell.
            # env-allowlist via safe_env_for_verilator (ATH-1212a site #7).
            sim_cmd, shell=True, cwd=str(work_dir),  # nosemgrep
            capture_output=True, text=True, timeout=timeout_sec,
            check=True,
            env=safe_env_for_verilator(),  # ATH-1212a
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        return VerilatorRunResult(
            cycles_run=0, total_toggles=0, toggles_per_cycle=0,
            compile_ok=True,
            error=f"verilator simulation failed: {str(e)[:500]}",
        )

    toggles = _parse_vcd_toggles(vcd_path, n_cycles)
    total = sum(t.toggles for t in toggles)
    tpc = total / max(n_cycles, 1)

    return VerilatorRunResult(
        cycles_run=n_cycles,
        total_toggles=total,
        toggles_per_cycle=round(tpc, 4),
        per_signal=toggles,
        vcd_path=str(vcd_path),
    )
