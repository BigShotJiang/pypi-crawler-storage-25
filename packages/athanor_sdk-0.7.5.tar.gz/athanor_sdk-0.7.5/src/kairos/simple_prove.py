"""ATH-678 -- `kairos.simple_prove()`: base SDK single-LLM proof attempt.

The base SDK counterpart to the paid :func:`kairos.prove`. Single-LLM,
single-shot, no retries, no multi-prover dispatch. Closes ~50-60% of
theorems vs ~85-90% for the paid Orchestrator. Gives free customers
an end-to-end "give me a theorem, here's a closed proof" experience
without the proprietary tier-planning IP.

For the multi-LLM, retry, multi-prover dispatch path, see
:func:`kairos.prove`. For the **template-driven** base SDK flow
(Pythia-pattern matched, no target_file required), see
:func:`kairos.simple_prove_template`. The two base SDK helpers are
complementary:

* `simple_prove`: free-form. Customer brings a Lean file with a
  ``sorry`` to fill; one LLM call drafts the proof body; verify_proof
  checks it.
* `simple_prove_template`: template-driven. Customer types an
  English hypothesis; the SDK matches against a closed catalog of
  Pythia templates; one LLM call may fill template parameters; the
  resulting Lean is verified.

Use `simple_prove` for theorems with known shape but unknown proof.
Use `simple_prove_template` for theorems whose shape is itself
unknown to the customer.

## Customer entrypoint

    from kairos import simple_prove

    result = simple_prove(
        "x + 0 = x for natural numbers",
        target_file="MyProof.lean",
    )
    if result.outcome == "proved":
        print("closed")
    else:
        print(result.refined_prompt_suggestion())

## Privacy guarantees

* Zero phone-home from the SDK side. Trace events go to the local
  journal at ``~/.athanor/runs/<run_id>/`` (ATH-681); no Supabase
  writes unless the customer explicitly configures
  ``KAIROS_TRACE_SINK=supabase`` against a self-hosted instance.
* The single LLM call goes from the customer's machine directly to
  the customer's chosen provider via litellm.
* No license file required; no ``require_product("solve")`` gate.
"""
from __future__ import annotations

import logging
import re
import time
import uuid
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from kairos.prove import ProveResult

logger = logging.getLogger(__name__)


# Default model per CTO Q3 ratification (ts=1777181383). Anthropic's
# Haiku-class model is mechanical-CRUD-shape (per fleet routing rules);
# Sonnet/Opus would be overkill for the single-shot case. Customers
# without an Anthropic key fall back via
# ``kairos.config.set_simple_prove_model("gemini-flash")`` or by
# passing ``model=`` explicitly.
#
# 2026-04-28 (ATH-815): the literal lives in ``kairos.model_presets``
# so the SDK has one place to audit / swap default models. The
# constant name stays ``DEFAULT_MODEL`` for back-compat with any
# external `from kairos.simple_prove import DEFAULT_MODEL` callers.
from kairos.model_presets import DEFAULT_SIMPLE_PROVE_MODEL as DEFAULT_MODEL  # noqa: E402

# Strip a leading code fence if the model wrapped its output. Matches
# ```lean ... ``` and ``` ... ``` in either order. Same shape as the
# extractor in `kairos.lean_cycle._extract_proof_body`.
_CODE_FENCE_RE = re.compile(r"```(?:lean)?\s*\n(.*?)```", re.DOTALL)


def _extract_lean_block(text: str) -> str:
    """Strip the markdown code fence if the model included one.
    Returns the raw Lean source the model produced (the contents of
    the first fenced block, or the full text if no fence)."""
    m = _CODE_FENCE_RE.search(text)
    if m:
        return m.group(1).strip()
    return text.strip()


def simple_prove(
    hypothesis: str,
    target_file: str | Path,
    *,
    model: str | None = None,
    timeout: int = 120,
) -> ProveResult:
    """Single-LLM proof attempt against an existing Lean target file.

    Included; no license required. The customer brings a Lean source
    file containing a theorem skeleton with a ``sorry`` (or other
    placeholder) and a natural-language description of what should be
    proved. One LLM call produces a candidate completion, which is
    handed to :func:`kairos.lean.verify_proof`.

    ATH-1039: Before calling the LLM, checks the proof journal for a
    cached tactic. After a successful proof, persists the proof body
    to the journal so rate-limited re-runs don't lose proofs.

    Args:
        hypothesis: free-text description of the claim. Threaded
            into the LLM prompt so the model knows what to prove.
        target_file: path to the Lean file holding the theorem
            skeleton. The file's contents are read and shown to the
            LLM; the resulting completion is verified against the
            file's lake project (when one is detected) or as bare
            Lean source.
        model: litellm-compatible model id. Defaults to
            ``anthropic/claude-haiku-4-5``. Override per call or
            globally via :func:`kairos.config.set_simple_prove_model`.
        timeout: per-call wall-clock cap (seconds). Applied to both
            the LLM call (litellm timeout) and the lake build
            verifier (verify_proof timeout).

    Returns:
        :class:`kairos.prove.ProveResult` with ``outcome`` in the
        closed 5-value taxonomy. The same shape as the paid
        :func:`kairos.prove` so customer agent code that branches on
        ``result.outcome`` works against either path.

    Raises:
        FileNotFoundError: when ``target_file`` does not exist.

    Example:
        >>> result = simple_prove(
        ...     "addition is commutative on N",
        ...     target_file="MyProof.lean",
        ... )
        >>> print(result.outcome, result.score)
        proved 1.0
    """
    # Defer the heavy imports -- keeps the customer-import cost low for
    # callers who only touch verify_proof / lean_machines / etc.
    from kairos.lean import verify_proof
    from kairos.observe import observe
    from kairos.prove import ProveResult

    target_path = Path(target_file)
    if not target_path.exists():
        raise FileNotFoundError(
            f"simple_prove: target_file not found: {target_path}"
        )

    # Detect lake-project mode: the customer's target_file is in a
    # lake project iff the file (or any ancestor up to a few levels)
    # has a sibling lakefile.lean. Bare-file mode otherwise.
    lake_project: Path | None = None
    module_path: str | None = None
    for parent in (target_path.parent, *target_path.parents):
        if (parent / "lakefile.lean").exists():
            lake_project = parent
            # Module path: relative file path with separators -> dots,
            # minus the .lean suffix. e.g. lake_project/Pythia/Foo.lean
            # -> "Pythia.Foo".
            try:
                rel = target_path.resolve().relative_to(parent.resolve())
                module_path = str(rel.with_suffix("")).replace("/", ".")
            except ValueError:
                lake_project = None  # weird path situation; fall back
            break

    chosen_model = model or _resolve_default_model()
    target_source = target_path.read_text(encoding="utf-8")
    run_id = str(uuid.uuid4())
    t_start = time.time()

    # ATH-1039: Check proof journal for a cached proof before LLM call.
    from kairos.proof_journal import load_journal, persist_proof
    project_root = target_path.resolve().parent
    journal = load_journal(project_root)
    # Build a lookup key from the file contents -- extract theorem name
    # from the target source.
    _cached_source = _check_journal_cache(journal, target_source, str(target_path))

    # Build the prompt. The LLM sees the file's full contents + the
    # English hypothesis; it returns a complete Lean source with the
    # sorry replaced. We do not reuse `kairos.prove`'s prompt scaffolds
    # directly because those are tier/orchestrator-shaped (the paid
    # path); base SDK wants the simplest possible single-shot form.
    sys_msg = (
        "You are an expert Lean 4 theorem prover. Replace the sorry "
        "in the user's source file with a working proof. Output ONLY "
        "the complete Lean source (no markdown, no prose, no "
        "explanation). Banned tactics: sorry, admit, native_decide. "
        "Allowed axioms: propext, Classical.choice, Quot.sound."
    )
    user_msg = (
        f"Hypothesis (English): {hypothesis}\n\n"
        f"Target file ({target_path.name}):\n```lean\n{target_source}\n```\n\n"
        "Output the complete Lean source with the sorry replaced."
    )

    # ATH-678 + ATH-614 gate: wrap the LLM + verify_proof boundary in
    # `kairos.observe(...)` (the ATH-524 unified wrapper). observe is
    # the base-SDK-safe equivalent of session: captures boundary
    # events under contextvars without requiring a license. qa's
    # ATH-614 static gate (#269) accepts both observe() and session();
    # we use observe() here so simple_prove stays base SDK.
    cost_usd = 0.0
    with observe(
        run_id=run_id, run_subtype="simple_prove", spawn_reason="manual_launch"
    ):
        # ATH-1039: If we have a cached proof, use it instead of calling LLM.
        if _cached_source is not None:
            completion_text = _cached_source
            logger.info("simple_prove: using cached proof from journal")
        else:
            try:
                completion_text, completion_cost = _single_llm_call(
                    model=chosen_model,
                    system=sys_msg,
                    user=user_msg,
                    timeout=timeout,
                )
                cost_usd += completion_cost
            except Exception as exc:  # noqa: BLE001 -- logged + recovered; broad catch is intentional
                logger.warning("simple_prove: LLM call failed: %s", exc)
                return ProveResult(
                    outcome="error",
                    reason=f"LLM call failed: {type(exc).__name__}: {exc!s:.200}",
                    score=0.0,
                    cost_usd=cost_usd,
                    tier="simple_prove",
                    details={"model": chosen_model, "exception": type(exc).__name__},
                    run_id=run_id,
                )
            completion_text = completion_text  # noqa: PLW0127 -- clarity

        candidate_source = _extract_lean_block(completion_text)
        if not candidate_source:
            return ProveResult(
                outcome="error",
                reason="LLM returned an empty completion",
                score=0.0,
                cost_usd=cost_usd,
                tier="simple_prove",
                details={"model": chosen_model, "raw_completion": completion_text[:500]},
                run_id=run_id,
            )

        # Verify. Lake-project mode if we detected one; bare-file mode
        # otherwise. Both modes return the same ProofResult shape.
        proof_result = verify_proof(
            candidate_source,
            lake_project=str(lake_project) if lake_project else None,
            module_path=module_path,
            timeout=timeout,
        )

        # Map ProofResult to ProveResult outcome. The closed 5-value
        # taxonomy used by paid prove() is: proved | refuted | unknown
        # | vacuous | error. simple_prove maps:
        #   full_proof    -> proved (score 1.0)
        #   partial_proof -> unknown (compiles but has sorry; score 0.5)
        #   compile_error -> refuted (score 0.0)
        #   banned        -> refuted (banned construct found; score 0.0)
        #   axiom_leak    -> refuted (ATH-948: transitive axiom audit
        #                   found a forbidden axiom -- same soundness
        #                   class as banned; score 0.0)
        #   timeout       -> error
        score_map = {"full_proof": 1.0, "partial_proof": 0.5,
                     "compile_error": 0.0, "banned": 0.0,
                     "axiom_leak": 0.0, "timeout": 0.0}
        if proof_result.status == "full_proof":
            outcome = "proved"
            reason = f"Lean proof compiled (score={proof_result.score:.2f})."
            # ATH-1039: Persist proven tactic to journal.
            _persist_to_journal(
                target_source, str(target_path), candidate_source,
                project_root=project_root,
            )
        elif proof_result.status == "partial_proof":
            outcome = "unknown"
            reason = (
                f"Compiles but has {proof_result.sorry_count} sorry "
                f"marker(s); proof incomplete."
            )
        elif proof_result.status == "banned":
            outcome = "refuted"
            reason = (
                f"Banned construct: {proof_result.banned!r}. Remove "
                "sorry/admit/native_decide and resubmit."
            )
        elif proof_result.status == "axiom_leak":
            # ATH-948: proof compiled cleanly + no sorry + no banned
            # construct, but the transitive axiom audit found a
            # forbidden axiom (e.g. sorryAx via vacuous self-
            # reference). Treat as refuted -- the proof is unsound
            # even though it compiles.
            outcome = "refuted"
            forbidden = list(proof_result.forbidden_axioms or [])
            forbidden_preview = (
                ", ".join(forbidden[:3]) if forbidden else "(none reported)"
            )
            reason = (
                f"Proof compiles but transitive axiom audit found "
                f"forbidden axiom(s): {forbidden_preview}. "
                f"Likely a sorry-leak via vacuous self-reference. "
                f"Re-derive the proof without leaning on these axioms."
            )
        elif proof_result.status == "compile_error":
            outcome = "refuted"
            first_err = (proof_result.errors or [""])[0][:200]
            reason = f"Lean compile error: {first_err}"
        else:  # timeout / unknown status
            outcome = "error"
            reason = f"Verifier returned status={proof_result.status!r}"

        return ProveResult(
            outcome=outcome,
            reason=reason,
            score=score_map.get(proof_result.status, 0.0),
            cost_usd=cost_usd,
            tier="simple_prove",
            details={
                "model": chosen_model,
                "proof_status": proof_result.status,
                "compiles": proof_result.compiles,
                "has_sorry": proof_result.has_sorry,
                "sorry_count": proof_result.sorry_count,
                "candidate_lean": candidate_source,
                "errors": list(proof_result.errors or [])[:10],
                "wall_sec": time.time() - t_start,
            },
            run_id=run_id,
        )


def _check_journal_cache(
    journal: dict[str, str],
    target_source: str,
    file_path: str,
) -> str | None:
    """ATH-1039: Check journal for a cached proof matching the target file.

    Scans the target source for theorem names with sorry, and checks
    if any have a cached proof in the journal. Returns the full source
    with sorry replaced if found, None otherwise.
    """
    import re as _re
    if not journal:
        return None

    lines = target_source.splitlines()
    current_theorem = ""
    for i, line in enumerate(lines):
        theorem_m = _re.match(r"\s*(?:theorem|lemma)\s+(\w+)", line)
        if theorem_m:
            current_theorem = theorem_m.group(1)
        if _re.match(r"\s*sorry\b", line) and current_theorem:
            from kairos.proof_journal import lookup
            cached = lookup(journal, current_theorem, file_path, i + 1)
            if cached is not None:
                # Return the full source with the sorry replaced.
                new_lines = list(lines)
                indent_m = _re.match(r"(\s*)", line)
                indent = indent_m.group(1) if indent_m else ""
                new_lines[i] = f"{indent}{cached}"
                return "\n".join(new_lines)
    return None


def _persist_to_journal(
    original_source: str,
    file_path: str,
    candidate_source: str,
    *,
    project_root: Path | None = None,
) -> None:
    """ATH-1039: Persist the proven tactic to the proof journal.

    Diffs original vs candidate to find replaced sorry lines and
    extracts the theorem name + tactic for each.
    """
    import re as _re
    from kairos.proof_journal import persist_proof

    orig_lines = original_source.splitlines()
    current_theorem = ""
    for i, line in enumerate(orig_lines):
        theorem_m = _re.match(r"\s*(?:theorem|lemma)\s+(\w+)", line)
        if theorem_m:
            current_theorem = theorem_m.group(1)
        if _re.match(r"\s*sorry\b", line) and current_theorem:
            # Find the corresponding line in the candidate
            cand_lines = candidate_source.splitlines()
            if i < len(cand_lines):
                new_tactic = cand_lines[i].strip()
                if new_tactic and "sorry" not in new_tactic.lower():
                    try:
                        persist_proof(
                            current_theorem, file_path, i + 1,
                            new_tactic, 2,
                            project_root=project_root,
                        )
                    except OSError:
                        logger.warning("Failed to persist proof to journal")


def _resolve_default_model() -> str:
    """Resolve the simple_prove default model. Reads from
    ``kairos.config`` if a customer override is set; falls back to
    :data:`DEFAULT_MODEL` otherwise."""
    try:
        from kairos.config import get_simple_prove_model  # type: ignore[attr-defined]
        configured: str = get_simple_prove_model()
        if configured:
            return configured
    except (ImportError, AttributeError):
        # config module may not expose the helper yet; default is fine.
        pass
    default: str = DEFAULT_MODEL
    return default


def _single_llm_call(
    *, model: str, system: str, user: str, timeout: int,
) -> tuple[str, float]:
    """LLM completion call via get_client(). Returns (text, cost_usd).

    ATH-1186 / ATH-1180: migrated from direct litellm.completion() to
    get_client() which routes through ClaudeSubagentClient for internal
    fleet calls (KAIROS_AGENT_ID set) and through the standard registry
    (Bedrock/litellm) for customer calls. Zero Anthropic API key spend
    on internal fleet by structural default.

    Kept private + explicit so tests can monkeypatch this point.
    """
    from kairos.model_client.registry import get_client

    client = get_client(model)
    messages = client.format_messages(system, user)
    resp = client.call(messages, temperature=0.0, timeout=timeout)
    text = resp.assistant_turn().get("content", "")
    cost = getattr(resp, "cost_usd", 0.0) or 0.0
    return text, float(cost)


__all__ = ["simple_prove", "DEFAULT_MODEL"]
