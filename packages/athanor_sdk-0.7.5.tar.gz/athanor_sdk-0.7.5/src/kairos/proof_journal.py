"""ATH-1039: Proof-body persistence for simple_prove / lean_repair.

When an LLM-assisted proof (L2 or L3) succeeds, the tactic is persisted
to `.kairos/proof_journal.jsonl` in the project root. On re-runs, the
journal is consulted *before* calling the LLM, so a rate-limited or
flaky endpoint doesn't lose a proven tactic.

Journal format (one JSON object per line):
    {"theorem": "add_zero", "file": "MyProof.lean", "line": 7,
     "tactic": "simp [Nat.add_comm]", "level": 2,
     "timestamp": "2026-05-19T12:34:56Z"}

Thread-safety: append-only writes with a file-level lock
(``fcntl.flock`` on POSIX, best-effort on Windows).
"""
from __future__ import annotations

import datetime
import json
import logging
import os
from pathlib import Path

_log = logging.getLogger("kairos.proof_journal")

_DEFAULT_JOURNAL_NAME = os.path.join(".kairos", "proof_journal.jsonl")


def _journal_path(project_root: Path | str | None = None) -> Path:
    """Resolve the journal file path.

    If *project_root* is given, use ``<project_root>/.kairos/proof_journal.jsonl``.
    Otherwise fall back to ``~/.kairos/proof_journal.jsonl``.
    """
    if project_root is not None:
        return Path(project_root) / _DEFAULT_JOURNAL_NAME
    return Path.home() / _DEFAULT_JOURNAL_NAME


def _make_entry(
    theorem: str,
    file: str,
    line: int,
    tactic: str,
    level: int,
) -> dict:
    return {
        "theorem": theorem,
        "file": str(file),
        "line": line,
        "tactic": tactic,
        "level": level,
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }


def persist_proof(
    theorem: str,
    file: str,
    line: int,
    tactic: str,
    level: int,
    *,
    project_root: Path | str | None = None,
) -> Path:
    """Append a proven tactic to the proof journal. Returns the journal path."""
    jp = _journal_path(project_root)
    jp.parent.mkdir(parents=True, exist_ok=True)
    entry = _make_entry(theorem, file, line, tactic, level)
    line_bytes = (json.dumps(entry, separators=(",", ":")) + "\n").encode()

    # Best-effort file locking for concurrent agents.
    try:
        import fcntl

        with open(jp, "ab") as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            try:
                f.write(line_bytes)
            finally:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except (ImportError, OSError):
        # fcntl not available (Windows) or locking failed -- fall back to
        # plain append which is atomic on most POSIX FSes for small writes.
        with open(jp, "ab") as f:
            f.write(line_bytes)

    _log.debug("Persisted proof: %s -> %s (L%d) to %s", theorem, tactic[:60], level, jp)
    return jp


def load_journal(
    project_root: Path | str | None = None,
) -> dict[str, str]:
    """Load the proof journal and return a lookup: ``(theorem, file, line) -> tactic``.

    The key is ``"theorem:file:line"`` so callers can do a fast lookup.
    Later entries for the same key overwrite earlier ones (last-write-wins).

    Returns an empty dict if the journal does not exist or is corrupt.
    """
    jp = _journal_path(project_root)
    if not jp.is_file():
        return {}

    result: dict[str, str] = {}
    try:
        with open(jp, encoding="utf-8") as f:
            for lineno, raw in enumerate(f, 1):
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    entry = json.loads(raw)
                    key = f"{entry['theorem']}:{entry['file']}:{entry['line']}"
                    result[key] = entry["tactic"]
                except (json.JSONDecodeError, KeyError) as exc:
                    _log.warning(
                        "proof_journal: skipping corrupt entry at %s:%d: %s",
                        jp, lineno, exc,
                    )
    except OSError as exc:
        _log.warning("proof_journal: cannot read %s: %s", jp, exc)

    if result:
        _log.debug("Loaded %d cached proofs from %s", len(result), jp)
    return result


def lookup(
    journal: dict[str, str],
    theorem: str,
    file: str,
    line: int,
) -> str | None:
    """Look up a cached tactic for a given theorem/file/line triple."""
    key = f"{theorem}:{file}:{line}"
    return journal.get(key)


__all__ = ["persist_proof", "load_journal", "lookup"]
