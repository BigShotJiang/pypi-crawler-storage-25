"""ATH-1431: verify --spec-consistency — Lean + Verus + proptests agree.

For each crate, checks that the three verification layers cover
the same properties. Finds gaps:
- Property in Lean but not in Verus or proptests
- Property in proptests but not formalized in Lean/Verus
- Verus spec exists but no proptest exercises it

Usage:
    kairos verify --spec-consistency crates/kairos-memory/
    kairos verify --spec-consistency crates/   # all crates
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class PropertyCoverage:
    name: str
    in_lean: bool = False
    in_verus: bool = False
    in_proptests: bool = False
    lean_source: str = ""
    verus_source: str = ""
    proptest_source: str = ""

    @property
    def fully_covered(self) -> bool:
        layers = sum([self.in_lean, self.in_verus, self.in_proptests])
        return layers >= 2

    @property
    def coverage_str(self) -> str:
        parts = []
        if self.in_lean:
            parts.append("Lean")
        if self.in_verus:
            parts.append("Verus")
        if self.in_proptests:
            parts.append("proptest")
        return "+".join(parts) if parts else "NONE"


@dataclass
class ConsistencyReport:
    crate_name: str
    properties: list[PropertyCoverage] = field(default_factory=list)
    lean_only: int = 0
    verus_only: int = 0
    proptest_only: int = 0
    fully_covered: int = 0

    @property
    def honest_report(self) -> str:
        total = len(self.properties)
        if total == 0:
            return f"{self.crate_name}: no properties found"
        lines = [
            f"{self.crate_name}: {self.fully_covered}/{total} properties "
            f"covered by >=2 layers"
        ]
        for p in self.properties:
            if not p.fully_covered:
                lines.append(f"  GAP: {p.name} — only in {p.coverage_str}")
        return "\n".join(lines)


def extract_lean_properties(lean_dir: Path) -> list[str]:
    """Extract theorem names from Lean spec files."""
    props = []
    for f in sorted(lean_dir.glob("*.lean")):
        try:
            text = f.read_text(errors="replace")
        except (OSError, PermissionError):
            continue
        for line in text.splitlines():
            m = re.match(r"\s*theorem\s+(\w+)", line)
            if m:
                props.append(m.group(1))
    return props


def extract_verus_properties(verus_dir: Path) -> list[str]:
    """Extract proof/ensures names from Verus spec files."""
    props = []
    for f in sorted(verus_dir.glob("*.rs")):
        try:
            text = f.read_text(errors="replace")
        except (OSError, PermissionError):
            continue
        for m in re.finditer(r"(?:pub\s+)?(?:proof\s+)?fn\s+(\w+)", text):
            name = m.group(1)
            if name.startswith("lemma_") or name.startswith("test_") or "proof" in name.lower():
                props.append(name)
        for m in re.finditer(r"ensures\s*\n?\s*(\w+)", text):
            props.append(f"ensures_{m.group(1)}")
    return props


def extract_proptest_properties(crate_dir: Path) -> list[str]:
    """Extract proptest function names from Rust test files."""
    props = []
    lib_rs = crate_dir / "src" / "lib.rs"
    if lib_rs.is_file():
        text = lib_rs.read_text()
        for m in re.finditer(r"fn\s+(prop_\w+|proptest_\w+|test_\w+)", text):
            props.append(m.group(1))
    tests_dir = crate_dir / "tests"
    if tests_dir.is_dir():
        for f in tests_dir.glob("*.rs"):
            text = f.read_text()
            for m in re.finditer(r"fn\s+(prop_\w+|proptest_\w+|test_\w+)", text):
                props.append(m.group(1))
    return props


def _normalize_name(name: str) -> str:
    """Normalize property name for fuzzy matching."""
    name = name.lower()
    for prefix in ("theorem_", "lemma_", "prop_", "proptest_", "test_", "ensures_"):
        if name.startswith(prefix):
            name = name[len(prefix):]
    return name.replace("_", "")


def _fuzzy_match(name: str, candidates: list[str], threshold: float = 0.6) -> str | None:
    """Find the best fuzzy match using longest common subsequence ratio."""
    norm = _normalize_name(name)
    best_score = 0.0
    best_match = None
    for c in candidates:
        cn = _normalize_name(c)
        lcs = _lcs_length(norm, cn)
        total = max(len(norm), len(cn), 1)
        score = lcs / total
        if score > best_score and score >= threshold:
            best_score = score
            best_match = c
    return best_match


def _lcs_length(a: str, b: str) -> int:
    """Longest common subsequence length (not substring)."""
    if not a or not b:
        return 0
    m, n = len(a), len(b)
    prev = [0] * (n + 1)
    for i in range(1, m + 1):
        curr = [0] * (n + 1)
        for j in range(1, n + 1):
            if a[i - 1] == b[j - 1]:
                curr[j] = prev[j - 1] + 1
            else:
                curr[j] = max(prev[j], curr[j - 1])
        prev = curr
    return prev[n]


def check_crate_consistency(crate_dir: Path) -> ConsistencyReport:
    """Check spec consistency for a single crate."""
    crate_name = crate_dir.name
    report = ConsistencyReport(crate_name=crate_name)

    lean_dir = crate_dir / "lean"
    verus_dir = crate_dir / "verus"

    lean_props = extract_lean_properties(lean_dir) if lean_dir.is_dir() else []
    verus_props = extract_verus_properties(verus_dir) if verus_dir.is_dir() else []
    proptest_props = extract_proptest_properties(crate_dir)

    all_names = set()
    for p in lean_props + verus_props + proptest_props:
        all_names.add(_normalize_name(p))

    for norm_name in sorted(all_names):
        coverage = PropertyCoverage(name=norm_name)
        if any(_normalize_name(p) == norm_name for p in lean_props):
            coverage.in_lean = True
        if any(_normalize_name(p) == norm_name for p in verus_props):
            coverage.in_verus = True
        if any(_normalize_name(p) == norm_name for p in proptest_props):
            coverage.in_proptests = True
        report.properties.append(coverage)

    report.lean_only = sum(1 for p in report.properties if p.in_lean and not p.in_verus and not p.in_proptests)
    report.verus_only = sum(1 for p in report.properties if p.in_verus and not p.in_lean and not p.in_proptests)
    report.proptest_only = sum(1 for p in report.properties if p.in_proptests and not p.in_lean and not p.in_verus)
    report.fully_covered = sum(1 for p in report.properties if p.fully_covered)

    return report


def check_all_crates(crates_dir: Path) -> list[ConsistencyReport]:
    """Check spec consistency across all crates."""
    reports = []
    for crate_dir in sorted(crates_dir.iterdir()):
        if not crate_dir.is_dir() or crate_dir.name.startswith("."):
            continue
        report = check_crate_consistency(crate_dir)
        if report.properties:
            reports.append(report)
    return reports
