"""Claude subagent ModelClient — uses Claude Code subprocess instead of litellm.

ATH-1180: For internal fleet calls (KAIROS_AGENT_ID set), routes LLM
calls through a Claude Code subagent subprocess. Zero API key cost —
uses the agent's Claude session OAuth.

Falls back to litellm when claude CLI is unavailable.
"""
from __future__ import annotations

import logging
import subprocess
from typing import Any

from kairos.model_client.base import (
    BACKEND,
    ModelClient,
    ModelResponse,
    ProviderConfig,
)


class ClaudeSubagentClient(ModelClient):
    """ModelClient that routes through Claude Code subprocess.

    Same interface as AnthropicClient / GeminiClient — drop-in
    replacement in the registry. Internal fleet default.
    """

    provider = "claude-subagent"
    backend = BACKEND.DIRECT
    max_tokens_default = 16_384

    def __init__(
        self,
        model_id: str = "claude-subagent",
        config: ProviderConfig | None = None,
        timeout_sec: int = 120,
    ):
        super().__init__(model_id, config)
        self.timeout_sec = timeout_sec

    def format_messages(self, system_prompt: str, user_prompt: str) -> list[dict[str, Any]]:
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def call(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        max_tokens: int | None = None,
        timeout: int = 120,
        temperature: float | None = None,
        top_p: float | None = None,
    ) -> ModelResponse:
        if tools:
            logging.getLogger("kairos.model_client").warning(
                "ClaudeSubagentClient does not support tool-use — "
                "tools parameter silently dropped. Use litellm backend for tool-use."
            )
        system = ""
        user = ""
        for m in messages:
            if m.get("role") == "system":
                content = m.get("content", "")
                if isinstance(content, list):
                    system = " ".join(
                        b.get("text", "") for b in content
                        if isinstance(b, dict)
                    )
                else:
                    system = str(content)
            elif m.get("role") == "user":
                content = m.get("content", "")
                if isinstance(content, list):
                    user = " ".join(
                        b.get("text", "") for b in content
                        if isinstance(b, dict)
                    )
                else:
                    user = str(content)

        prompt = f"{system}\n\n{user}" if system else user

        try:
            from kairos.sec.closed_loop.claude_proposer import _safe_env  # type: ignore[attr-defined]
            result = subprocess.run(
                ["claude", "-p", prompt, "--output-format", "text", "--max-turns", "1"],
                capture_output=True,
                text=True,
                timeout=timeout or self.timeout_sec,
                env=_safe_env(),
                start_new_session=True,
            )
            content = result.stdout.strip() or ""
            return ModelResponse(
                model="claude-subagent",
                content=content,
                tool_calls=[],
                error=None if content else "empty response from claude subagent",
                prompt_tokens=len(prompt) // 4,
                completion_tokens=len(content) // 4,
            )
        except FileNotFoundError:
            return ModelResponse(
                model="claude-subagent",
                content=None,
                tool_calls=[],
                error="claude CLI not found — install Claude Code or use litellm backend",
                prompt_tokens=0,
                completion_tokens=0,
            )
        except subprocess.TimeoutExpired:
            return ModelResponse(
                model="claude-subagent",
                content=None,
                tool_calls=[],
                error=f"claude subagent timed out after {timeout or self.timeout_sec}s",
                prompt_tokens=0,
                completion_tokens=0,
            )
