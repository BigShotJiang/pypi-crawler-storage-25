"""kairos.errors — typed exception hierarchy for SDK errors (ATH-845).

Pre-fix kairos surfaced failures as un-typed `RuntimeError`,
`ValueError`, or `Exception` subclasses scattered across modules.
Customers (and research) had to grep error message strings to
distinguish failure modes:

    error="NotFoundError: GeminiException - models/gemini-3-flash is not found"

Post-fix every customer-facing failure has a typed exception with
structured fields:

    try:
        result = solve(target, drafters=[...])
    except kairos.errors.UnknownModelError as e:
        print(f"Bad model: {e.model_id} — did you mean {e.suggestion}?")
    except kairos.errors.LakeBuildTimeoutError as e:
        print(f"Lake timed out after {e.timeout_seconds}s on {e.module_path}")
    except kairos.errors.AxiomAuditFailure as e:
        print(f"Closure rejected — forbidden axioms: {e.forbidden_axioms}")
    except kairos.errors.LicenseScopeError:
        sys.exit("Need paid license for solve()")

## Hierarchy

    KairosError                            (root — catch-all)
    ├── ConfigurationError                 (env / install / license problems)
    │   ├── UnknownModelError              (model_id, suggestion?)
    │   ├── MissingEnvVarError             (env_var, provider)
    │   ├── LakeNotFoundError              (searched_paths)
    │   ├── LicenseScopeError              (re-home from kairos.license_scope)
    │   ├── InputValidationError           (field, reason)
    │   └── FileValidationError            (file_path, reason)
    ├── ProverError                        (verifier-time failures)
    │   ├── LakeBuildTimeoutError          (timeout_seconds, module_path)
    │   ├── LakeBuildFailure               (errors, exit_code, module_path)
    │   ├── BannedConstructError           (banned_pattern, candidate_head)
    │   ├── DrafterEmittedNonLean          (drafter_alias, candidate_head_60)
    │   └── SimulationError                (tool, exit_code, stderr_tail)
    ├── AuditFailure                       (axiom / sorry / vacuous gates)
    │   ├── AxiomAuditFailure              (forbidden_axioms, target_name)
    │   ├── VacuousProofError              (target_name, dependency_chain)
    │   └── HasSorryError                  (sorry_count, locations)
    └── OrchestrationError                 (planner / race / decompose failures)
        ├── DecomposerEmittedEmpty         (planner_model, target_name)
        ├── SignatureCheckFailure          (sublemma_name, lake_errors)
        ├── RaceTimeoutError               (timeout_seconds, drafter_aliases_pending)
        ├── PlatformAPIError               (url, status_code, detail)
        └── ContainerError                 (image, action, detail)

## Backwards compatibility

`kairos.license_scope.LicenseScopeError` (the only pre-existing
exception with a stable customer-facing name) is re-homed here AND
re-exported from `kairos.license_scope` so existing customer code
catching `kairos.license_scope.LicenseScopeError` keeps working.
The `KairosError` root is intentionally `Exception`-derived so a
catch-all `except KairosError` works for customers who don't want
the structured-field pattern.

## ATH-842 coupling

`kairos.errors.UnknownModelError` is the first consumer of this
module — `get_client(bad_id)` raises it instead of `ValueError`.
This module ships `UnknownModelError` ahead of ATH-842 so the PR
sequencing is independent.
"""
from __future__ import annotations

from typing import Sequence


# ─── Root ─────────────────────────────────────────────────────────────


class KairosError(Exception):
    """Root of the kairos exception hierarchy.

    Every customer-facing kairos exception inherits from this. A
    catch-all ``except KairosError`` covers every failure mode in
    the SDK without shadowing standard-library exceptions
    (``KeyboardInterrupt`` / ``SystemExit`` continue to propagate).

    All KairosError subclasses carry an ``error_code`` for agent
    integration — agents parse the code, not the human message.
    """

    error_code: str = "KAIROS_ERROR"


# ─── ConfigurationError tree ──────────────────────────────────────────


class ConfigurationError(KairosError):
    """Customer environment / install / license / config problem.

    These are typically pre-flight failures: the customer can fix
    them by editing env vars, installing a missing tool, or loading
    a different license. ``kairos doctor`` (ATH-844) reports each of
    these with a one-line remediation hint.
    """

    error_code = "CONFIGURATION_ERROR"


class UnknownModelError(ConfigurationError):
    """Model id not in the registry (or not loadable from the
    configured provider).

    Carries the bad ``model_id`` + an optional ``suggestion`` for
    the closest match. ATH-842's ``get_client(bad_id)`` raises this
    instead of ``ValueError`` so customers can catch it cleanly.
    """

    error_code = "UNKNOWN_MODEL"

    def __init__(
        self,
        model_id: str,
        *,
        suggestion: str | None = None,
        provider: str | None = None,
    ) -> None:
        self.model_id = model_id
        self.suggestion = suggestion
        self.provider = provider
        msg = f"unknown model id: {model_id!r}"
        if provider:
            msg += f" (provider={provider})"
        if suggestion:
            msg += f" — did you mean {suggestion!r}?"
        super().__init__(msg)


class MissingEnvVarError(ConfigurationError):
    """A required environment variable wasn't set.

    Carries the ``env_var`` name + an optional ``provider`` label so
    the customer knows which integration was trying to read it.
    """

    error_code = "MISSING_ENV_VAR"

    def __init__(
        self,
        env_var: str,
        *,
        provider: str | None = None,
    ) -> None:
        self.env_var = env_var
        self.provider = provider
        msg = f"missing env var: {env_var}"
        if provider:
            msg += f" (required by {provider})"
        super().__init__(msg)


class MalformedSystemVerilogSpec(ConfigurationError):
    """Customer-supplied SystemVerilog spec is malformed.

    Common causes: missing ``endmodule`` line, missing ``module``
    declaration, file isn't valid SystemVerilog. Carries
    ``spec_path`` + ``reason`` (one-line cause) so the customer
    sees what went wrong without grepping the message string.

    Used by ``kairos.sv.cegar`` / ``kairos.sv.swarm`` /
    ``kairos.sv.multi`` to wrap the pre-flight spec validation
    that previously raised bare ``ValueError``.
    """
    error_code = "MALFORMED_SYSTEMVERILOG_SPEC"

    def __init__(
        self,
        reason: str,
        *,
        spec_path: str | None = None,
    ) -> None:
        self.spec_path = spec_path
        self.reason = reason
        msg = f"malformed SystemVerilog spec: {reason}"
        if spec_path:
            msg += f" (path={spec_path!r})"
        super().__init__(msg)


class MalformedYamlSpec(ConfigurationError):
    """Customer-supplied multi-abstraction YAML spec is malformed.

    Used by ``kairos.sv.multi.run_multi`` for the multi-layer
    config validation. Carries ``yaml_path`` + ``reason``.
    """
    error_code = "MALFORMED_YAML_SPEC"

    def __init__(
        self,
        reason: str,
        *,
        yaml_path: str | None = None,
    ) -> None:
        self.yaml_path = yaml_path
        self.reason = reason
        msg = f"malformed multi-abstraction YAML spec: {reason}"
        if yaml_path:
            msg += f" (path={yaml_path!r})"
        super().__init__(msg)


class LakeNotFoundError(ConfigurationError):
    """The ``lake`` binary is missing from PATH (or the discovered
    binary is the wrong version).

    Carries the ``searched_paths`` so the customer knows where the
    SDK looked. ``kairos doctor`` reports this with the install hint
    (point to ``elan`` / ``lean-toolchain``).
    """
    error_code = "LAKE_NOT_FOUND"

    def __init__(
        self,
        searched_paths: Sequence[str] = (),
        *,
        version_required: str | None = None,
    ) -> None:
        self.searched_paths = list(searched_paths)
        self.version_required = version_required
        if version_required:
            msg = (
                f"lake binary missing or below version "
                f"{version_required}; searched: "
                f"{self.searched_paths}"
            )
        else:
            msg = (
                f"lake binary not found on PATH; searched: "
                f"{self.searched_paths}"
            )
        super().__init__(msg)


class LakeModuleNotFoundError(ConfigurationError):
    """A slate / customer driver names a Lean module that the active
    lake project does not have on its filesystem (ATH-864).

    Surfaces driver-vs-lake-project drift loudly. The two motivating
    drift bugs (research VM, 2026-04-28):

    * Stale ``MODULE_MAP = {"Quantization": "Kairos.Stats.Quantization"}``
      after the lake project renamed ``Kairos.Stats → Pythia``. Lake
      replied ``unknown target`` for every verify; every attempt
      scored ``type_fail`` and the row silently zeroed.
    * Fallback ``f"Pythia.{mod}"`` constructed ``Pythia.Mathlib`` for
      Mathlib-canon targets; the rename dropped the re-export shim.

    Customers writing their own drivers via ``kairos.lean_project``
    now get this typed exception with ``did-you-mean`` suggestions
    instead of the silent zero-row. Pair with
    :class:`~kairos.errors.LakeTargetUnknownError` (lake-side
    surface of the same class).
    """
    error_code = "LAKE_MODULE_NOT_FOUND"

    def __init__(
        self,
        short_name: str,
        *,
        package_name: str,
        suggestions: Sequence[str] = (),
        known_modules_sample: Sequence[str] = (),
    ) -> None:
        self.short_name = short_name
        self.package_name = package_name
        self.suggestions = list(suggestions)
        self.known_modules_sample = list(known_modules_sample)
        suggest_clause = (
            f" — did you mean: {self.suggestions[:3]}?"
            if self.suggestions else ""
        )
        msg = (
            f"slate module {short_name!r} has no corresponding "
            f"{package_name}.{short_name}.lean in the active lake "
            f"project{suggest_clause}"
        )
        super().__init__(msg)


class LakeTargetUnknownError(ConfigurationError):
    """``lake build <module>`` reported ``unknown target`` (ATH-864).

    The candidate was written to a scratch path that the lake
    project's namespace tree does not register. Differs from
    :class:`LakeModuleNotFoundError` (which fires before any lake
    invocation, in pure Python introspection): this fires when lake
    itself rejects the constructed target name.

    Common cause: scratch dir lives under a path the lake project's
    ``lib_root`` doesn't include (e.g. customer wrote to
    ``/tmp/scratch/foo.lean`` but the lake project only imports
    sibling files under ``<package>/``).
    """
    error_code = "LAKE_TARGET_UNKNOWN"

    def __init__(
        self,
        target: str,
        *,
        scratch_path: str | None = None,
        lake_stderr_tail: str = "",
    ) -> None:
        self.target = target
        self.scratch_path = scratch_path
        self.lake_stderr_tail = lake_stderr_tail
        path_clause = f" (scratch: {scratch_path})" if scratch_path else ""
        msg = (
            f"lake reported `unknown target` for {target!r}{path_clause}. "
            f"The scratch directory is likely outside the lake project's "
            f"namespace tree."
        )
        super().__init__(msg)


class LicenseScopeError(ConfigurationError, RuntimeError):
    """Raised when a license claim does not grant access to a codepath.

    The license-loading + scope-checking machinery lives in
    ``kairos.license_scope``; this is the canonical exception class.
    The legacy import path ``kairos.license_scope.LicenseScopeError``
    re-exports this same class so existing customer code keeps
    working.

    Multiple inheritance preserves the pre-ATH-845
    ``except RuntimeError`` back-compat: any customer code catching
    ``RuntimeError`` (the old base class) continues to catch this
    exception. The canonical catch is now
    ``except kairos.errors.LicenseScopeError`` or the broader
    ``except ConfigurationError`` / ``except KairosError``.
    """

    error_code = "LICENSE_REQUIRED"


class InputValidationError(ConfigurationError):
    """A user-supplied input value failed validation.

    Covers run_id format checks, config-field range/type validation,
    and calibrate-bounds checks. Carries ``field`` (which input) +
    ``reason`` (why it was rejected) so the customer gets a
    machine-readable handle without parsing the message string.
    """

    error_code = "INPUT_VALIDATION_ERROR"

    def __init__(
        self,
        field: str,
        *,
        reason: str = "",
        value: str | None = None,
    ) -> None:
        self.field = field
        self.reason = reason
        self.value = value
        msg = f"invalid input for {field!r}"
        if value is not None:
            msg += f" (got {value!r})"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class FileValidationError(ConfigurationError):
    """A required file is missing, binary, or unreadable.

    Raised across CLI commands when a user-supplied path doesn't
    resolve to a readable text file. Carries ``file_path`` +
    ``reason`` (e.g. "not found", "binary content detected",
    "permission denied").
    """

    error_code = "FILE_VALIDATION_ERROR"

    def __init__(
        self,
        file_path: str,
        *,
        reason: str = "",
    ) -> None:
        self.file_path = file_path
        self.reason = reason
        msg = f"file validation failed for {file_path!r}"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


# ─── ProverError tree ─────────────────────────────────────────────────


class ProverError(KairosError):
    """Verifier-time failures — lake/EBMC/Lean rejected the candidate.

    Distinguishes from ``ConfigurationError`` (customer can fix
    pre-flight) — these mean the prover ran but the proof / build
    didn't go through. Often retryable.
    """

    error_code = "PROVER_ERROR"


class LakeBuildTimeoutError(ProverError):
    """``lake build`` exceeded its timeout.

    Carries ``timeout_seconds`` + the ``module_path`` we were
    building. Common cause: cold lake cache + Mathlib pull. Customer
    sees this once on the first run, fast on subsequent runs.
    """
    error_code = "LAKE_BUILD_TIMEOUT"

    def __init__(
        self,
        timeout_seconds: float,
        *,
        module_path: str | None = None,
    ) -> None:
        self.timeout_seconds = timeout_seconds
        self.module_path = module_path
        msg = f"lake build timed out after {timeout_seconds:.0f}s"
        if module_path:
            msg += f" on module {module_path!r}"
        super().__init__(msg)


class LakeBuildFailure(ProverError):
    """``lake build`` returned a non-zero exit with structured errors.

    Carries the ``errors`` list (structured per-line lake output) +
    ``exit_code`` + ``module_path``. Distinct from
    ``LakeBuildTimeoutError`` so customers can branch on retry vs
    fix-the-source.
    """
    error_code = "LAKE_BUILD_FAILURE"

    def __init__(
        self,
        errors: Sequence[str],
        *,
        exit_code: int = 1,
        module_path: str | None = None,
    ) -> None:
        self.errors = list(errors)
        self.exit_code = exit_code
        self.module_path = module_path
        head = self.errors[0] if self.errors else "<no error message>"
        msg = (
            f"lake build failed (exit={exit_code}"
            f"{', module=' + repr(module_path) if module_path else ''}"
            f"): {head}"
        )
        super().__init__(msg)


class BannedConstructError(ProverError):
    """The candidate proof contained a banned construct.

    Examples: ``axiom``, ``unsafeIO``, ``opaque``. The audit policy
    in :func:`kairos.sorry_swarm.default_axiom_audit` rejects these.
    Carries ``banned_pattern`` (which rule fired) + ``candidate_head``
    (first ~120 chars for context).
    """

    def __init__(
        self,
        banned_pattern: str,
        *,
        candidate_head: str = "",
    ) -> None:
        self.banned_pattern = banned_pattern
        self.candidate_head = candidate_head
        msg = (
            f"candidate contains banned construct "
            f"{banned_pattern!r}"
        )
        if candidate_head:
            msg += f" — head: {candidate_head[:120]!r}"
        super().__init__(msg)


class DrafterEmittedNonLean(ProverError):
    """A drafter returned text that doesn't look like Lean source.

    Common with autocomplete models that output prose preamble or
    return empty. Carries ``drafter_alias`` + ``candidate_head_60``
    so the customer can debug which drafter is misbehaving without
    spelunking ``errors[]``.
    """

    def __init__(
        self,
        drafter_alias: str,
        *,
        candidate_head_60: str = "",
    ) -> None:
        self.drafter_alias = drafter_alias
        self.candidate_head_60 = candidate_head_60
        msg = (
            f"drafter {drafter_alias!r} emitted non-Lean output"
        )
        if candidate_head_60:
            msg += f" — head: {candidate_head_60[:60]!r}"
        super().__init__(msg)


class SimulationError(ProverError):
    """An external simulation tool (iverilog / vvp) failed.

    Raised by ``toggle_power.py`` and related RTL simulation
    wrappers when the simulator exits non-zero. Carries ``tool``
    (which binary failed), ``exit_code``, and ``stderr_tail``
    (last ~500 chars of stderr for diagnostics).
    """

    error_code = "SIMULATION_ERROR"

    def __init__(
        self,
        tool: str,
        *,
        exit_code: int = 1,
        stderr_tail: str = "",
    ) -> None:
        self.tool = tool
        self.exit_code = exit_code
        self.stderr_tail = stderr_tail[:500]
        msg = f"{tool} failed (exit={exit_code})"
        if stderr_tail:
            msg += f": {stderr_tail[:200]}"
        super().__init__(msg)


# ─── AuditFailure tree ────────────────────────────────────────────────


class AuditFailure(KairosError):
    """The proof compiled but failed the post-build audit.

    Distinct from ``ProverError`` — the lake build went green; the
    audit (axiom inspection / sorry scan / vacuous-proof detector)
    rejected it. These are the highest-trust-signal failures: a
    customer who catches one knows the model produced a syntactically
    valid but semantically broken closure.
    """

    error_code = "AUDIT_FAILURE"


class AxiomAuditFailure(AuditFailure):
    """The proof depends on a non-allowlisted axiom.

    Carries ``forbidden_axioms`` (the set of axioms not in the
    allowlist) + ``target_name`` (which theorem). The Pythia
    allowlist defaults to ``{propext, Classical.choice, Quot.sound}``
    per :data:`kairos.sorry_swarm.PYTHIA_DEFAULT_AXIOM_ALLOWLIST`;
    customer-supplied audits can extend or restrict this.
    """

    def __init__(
        self,
        forbidden_axioms: Sequence[str],
        *,
        target_name: str | None = None,
    ) -> None:
        self.forbidden_axioms = sorted(set(forbidden_axioms))
        self.target_name = target_name
        msg = (
            f"axiom audit rejected: forbidden axioms "
            f"{self.forbidden_axioms}"
        )
        if target_name:
            msg += f" (target={target_name!r})"
        super().__init__(msg)


class VacuousProofError(AuditFailure):
    """The proof is vacuous — closes via a contradiction in the
    hypotheses or via ``sorryAx`` somewhere in the dependency tree.

    Carries ``target_name`` + ``dependency_chain`` (the path through
    the proof DAG that surfaces the vacuity). Higher-trust signal
    than ``AxiomAuditFailure`` because it catches closures that look
    clean axiom-wise but don't actually load-bear the customer's
    claim.
    """

    error_code = "VACUOUS_PROOF"

    def __init__(
        self,
        target_name: str,
        *,
        dependency_chain: Sequence[str] = (),
    ) -> None:
        self.target_name = target_name
        self.dependency_chain = list(dependency_chain)
        msg = (
            f"vacuous proof for {target_name!r}: "
            f"{' → '.join(self.dependency_chain) or 'sorryAx in dep tree'}"
        )
        super().__init__(msg)


class HasSorryError(AuditFailure):
    """The candidate compiled but contains one or more ``sorry`` /
    ``admit`` placeholders.

    Carries ``sorry_count`` + ``locations`` (line offsets within the
    candidate). Distinct from ``DrafterEmittedNonLean`` — the
    candidate IS Lean and DOES compile; it just hasn't actually
    closed the proof.
    """

    def __init__(
        self,
        sorry_count: int,
        *,
        locations: Sequence[int] = (),
    ) -> None:
        self.sorry_count = sorry_count
        self.locations = list(locations)
        msg = f"candidate has {sorry_count} unresolved sorry/admit"
        if locations:
            msg += f" at lines {self.locations}"
        super().__init__(msg)


# ─── OrchestrationError tree ──────────────────────────────────────────


class OrchestrationError(KairosError):
    """Planner / race / decompose-loop failures.

    Distinct from ``ConfigurationError`` (env-level) and ``ProverError``
    (verifier-level) — these arise inside the orchestrator's flow
    when the planner LLM returns malformed output, when no drafter
    races to closure, or when sublemma signatures don't type-check.
    """

    error_code = "ORCHESTRATION_ERROR"


class DecomposerEmittedEmpty(OrchestrationError):
    """The decomposer planner returned no sublemmas.

    Carries ``planner_model`` + ``target_name``. Common when the
    planner can't break down the target (target is already atomic
    or the planner model doesn't have the right priors). Customer
    typically retries with a stronger planner model or accepts the
    bare race result.
    """

    def __init__(
        self,
        planner_model: str,
        *,
        target_name: str | None = None,
    ) -> None:
        self.planner_model = planner_model
        self.target_name = target_name
        msg = f"decomposer ({planner_model}) returned no sublemmas"
        if target_name:
            msg += f" for target {target_name!r}"
        super().__init__(msg)


class SignatureCheckFailure(OrchestrationError):
    """A decomposer-emitted sublemma's signature didn't lake-build.

    Carries ``sublemma_name`` + ``lake_errors``. Customer-Opus loops
    catch this to retry the decomposer with the failing signature
    fed back as context.
    """

    def __init__(
        self,
        sublemma_name: str,
        *,
        lake_errors: Sequence[str] = (),
    ) -> None:
        self.sublemma_name = sublemma_name
        self.lake_errors = list(lake_errors)
        head = self.lake_errors[0] if self.lake_errors else "<no error>"
        msg = (
            f"sublemma {sublemma_name!r} signature check failed: "
            f"{head}"
        )
        super().__init__(msg)


class LLMOutputParseError(OrchestrationError):
    """An LLM-driven helper (proposer / decomposer / planner) returned
    output that didn't parse to the expected structured shape.

    Carries ``model`` (which model was called), ``raw_output_head``
    (first ~300 chars of the bad response for debugging), and
    ``parse_error`` (the underlying parser exception's message).

    Distinct from :class:`OrchestrationMalformed` (in
    kairos.spec.types — orchestrator-tier-planning failures); this
    class covers any LLM that returned malformed output, not just
    the tier planner.
    """

    error_code = "LLM_PARSE_ERROR"

    def __init__(
        self,
        model: str,
        *,
        raw_output_head: str = "",
        parse_error: str = "",
    ) -> None:
        self.model = model
        self.raw_output_head = raw_output_head[:300]
        self.parse_error = parse_error
        msg = f"LLM {model!r} returned malformed output"
        if parse_error:
            msg += f" ({parse_error})"
        if raw_output_head:
            msg += f"; head: {raw_output_head[:100]!r}"
        super().__init__(msg)


class RaceTimeoutError(OrchestrationError):
    """No drafter completed within the race timeout.

    Carries ``timeout_seconds`` + ``drafter_aliases_pending`` (which
    drafters were still in flight when the race was cancelled).
    Distinct from ``LakeBuildTimeoutError`` — that fires per-build;
    this fires at the race level.
    """

    def __init__(
        self,
        timeout_seconds: float,
        *,
        drafter_aliases_pending: Sequence[str] = (),
    ) -> None:
        self.timeout_seconds = timeout_seconds
        self.drafter_aliases_pending = list(drafter_aliases_pending)
        msg = (
            f"race timed out after {timeout_seconds:.0f}s; "
            f"still pending: {self.drafter_aliases_pending}"
        )
        super().__init__(msg)


class PlatformAPIError(OrchestrationError):
    """An HTTP or auth call to the Athanor platform failed.

    Raised by ``runner.py`` on HTTP errors, bootstrap-token
    failures, and similar platform-API interactions. Carries
    ``url`` (the endpoint), ``status_code`` (HTTP status or -1
    for connection errors), and ``detail`` (server message or
    connection error description).
    """

    error_code = "PLATFORM_API_ERROR"

    def __init__(
        self,
        url: str,
        *,
        status_code: int = -1,
        detail: str = "",
    ) -> None:
        self.url = url
        self.status_code = status_code
        self.detail = detail
        msg = f"platform API call failed: {url} (status={status_code})"
        if detail:
            msg += f" — {detail}"
        super().__init__(msg)


class ContainerError(OrchestrationError):
    """A Docker container operation (pull / login / run) failed.

    Raised by ``runner.py`` and ``containerized_drafter`` when a
    container-level operation exits non-zero. Carries ``image``
    (the image ref), ``action`` (pull / login / run), and
    ``detail`` (stderr summary).
    """

    error_code = "CONTAINER_ERROR"

    def __init__(
        self,
        image: str,
        *,
        action: str = "pull",
        detail: str = "",
    ) -> None:
        self.image = image
        self.action = action
        self.detail = detail
        msg = f"docker {action} failed for {image!r}"
        if detail:
            msg += f": {detail}"
        super().__init__(msg)


__all__ = [
    "KairosError",
    # ConfigurationError tree
    "ConfigurationError",
    "UnknownModelError",
    "MissingEnvVarError",
    "MalformedSystemVerilogSpec",
    "MalformedYamlSpec",
    "LakeNotFoundError",
    "LicenseScopeError",
    "InputValidationError",
    "FileValidationError",
    # ProverError tree
    "ProverError",
    "LakeBuildTimeoutError",
    "LakeBuildFailure",
    "BannedConstructError",
    "DrafterEmittedNonLean",
    "SimulationError",
    # AuditFailure tree
    "AuditFailure",
    "AxiomAuditFailure",
    "VacuousProofError",
    "HasSorryError",
    # OrchestrationError tree
    "OrchestrationError",
    "DecomposerEmittedEmpty",
    "SignatureCheckFailure",
    "RaceTimeoutError",
    "LLMOutputParseError",
    "PlatformAPIError",
    "ContainerError",
]