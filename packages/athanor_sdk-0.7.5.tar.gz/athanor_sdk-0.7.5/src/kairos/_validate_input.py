"""Input file validation -- reusable guard for all CLI-facing file reads."""
from __future__ import annotations

import os
import sys
from pathlib import Path


def _validate_input_file(
    path: str | Path,
    *,
    label: str = "file",
    binary: bool = False,
    exit_on_fail: bool = True,
) -> Path:
    """Validate that *path* exists, is a regular file, and is readable.

    Args:
        path: User-supplied file path.
        label: Human-readable name for error messages (e.g. "run file", "spec").
        binary: If False (default), also checks the file is not binary.
        exit_on_fail: If True, prints error and calls sys.exit(1).
                      If False, raises FileNotFoundError or PermissionError.

    Returns:
        Resolved Path object on success.
    """
    p = Path(path).resolve()

    if not p.exists():
        msg = f"Error: {label} not found: {path}"
        if exit_on_fail:
            print(msg, file=sys.stderr)
            sys.exit(1)
        raise FileNotFoundError(msg)

    if not p.is_file():
        msg = f"Error: {label} is not a regular file: {path}"
        if exit_on_fail:
            print(msg, file=sys.stderr)
            sys.exit(1)
        raise FileNotFoundError(msg)

    if not os.access(p, os.R_OK):
        msg = f"Error: {label} is not readable: {path}"
        if exit_on_fail:
            print(msg, file=sys.stderr)
            sys.exit(1)
        raise PermissionError(msg)

    if not binary:
        try:
            with open(p, "rb") as f:
                chunk = f.read(8192)
            if b"\x00" in chunk:
                msg = f"Error: {label} appears to be binary: {path}"
                if exit_on_fail:
                    print(msg, file=sys.stderr)
                    sys.exit(1)
                raise ValueError(msg)
        except OSError as e:
            msg = f"Error: cannot read {label}: {path} ({e})"
            if exit_on_fail:
                print(msg, file=sys.stderr)
                sys.exit(1)
            raise

    return p
