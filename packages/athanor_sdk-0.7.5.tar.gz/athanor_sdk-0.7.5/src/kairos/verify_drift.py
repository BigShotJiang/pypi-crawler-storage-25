"""kairos verify --drift — detect when code drifts from its security/test/spec layers.

The injection class recurred 8 times because code changed without
updating the sanitization layer. Drift detection catches this:
when a file changes, check that all downstream layers still cover it.

Layers checked:
1. Security: every subprocess interpolation has sanitize_* call
2. Tests: every public function has a test
3. Specs: every Lean spec references existing code (not phantom names)
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class DriftFinding:
    file: str
    layer: str  # security | test | spec
    message: str
    severity: str = "high"


@dataclass
class DriftResult:
    files_checked: int = 0
    findings: list[DriftFinding] = field(default_factory=list)

    @property
    def drifted(self) -> bool:
        return len(self.findings) > 0

    def summary(self) -> str:
        if not self.findings:
            return f"Drift check: {self.files_checked} files, 0 drift detected"
        lines = [f"Drift check: {self.files_checked} files, {len(self.findings)} drift(s) found"]
        for f in self.findings:
            lines.append(f"  [{f.severity}] {f.layer}: {f.file} — {f.message}")
        return "\n".join(lines)


def _check_security_drift(path: Path) -> list[DriftFinding]:
    """Check that subprocess/yosys calls have sanitization."""
    findings = []
    try:
        text = path.read_text()
    except Exception:  # noqa: BLE001 — best-effort cleanup
        return findings

    has_subprocess = "subprocess.run" in text or "subprocess.Popen" in text
    has_yosys_interpolation = bool(re.search(r'f"[^"]*read_verilog[^"]*\{', text))
    has_sanitize = "sanitize_yosys_path" in text or "validate_verilog_identifier" in text

    if has_yosys_interpolation and not has_sanitize:
        findings.append(DriftFinding(
            file=str(path), layer="security",
            message="yosys script interpolation without sanitize_yosys_path",
            severity="critical",
        ))

    if has_subprocess and "module_name" in text:
        if "validate_verilog_identifier" not in text and "sanitize" not in text:
            findings.append(DriftFinding(
                file=str(path), layer="security",
                message="subprocess with module_name but no validate_verilog_identifier",
                severity="high",
            ))

    return findings


def _check_test_drift(src_path: Path, tests_dir: Path) -> list[DriftFinding]:
    """Check that public functions have corresponding tests."""
    findings = []
    try:
        tree = ast.parse(src_path.read_text())
    except Exception:  # noqa: BLE001 — best-effort cleanup
        return findings

    public_fns = []
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and not node.name.startswith("_"):
            public_fns.append(node.name)

    if not public_fns or not tests_dir.is_dir():
        return findings

    test_content = ""
    for tf in tests_dir.glob("test_*.py"):
        try:
            test_content += tf.read_text()
        except OSError:
            continue

    untested = [fn for fn in public_fns if re.search(rf'\b{re.escape(fn)}\b', test_content) is None]
    if untested and len(untested) > len(public_fns) * 0.3:
        findings.append(DriftFinding(
            file=str(src_path), layer="test",
            message=f"{len(untested)}/{len(public_fns)} public functions have no test reference",
            severity="medium",
        ))

    return findings


def verify_drift(
    src_dir: str | Path = "src/kairos",
    tests_dir: str | Path = "tests",
) -> DriftResult:
    """Check for drift between code and its security/test layers."""
    src = Path(src_dir)
    tests = Path(tests_dir)
    result = DriftResult()

    if not src.is_dir():
        return result

    for py_file in sorted(src.rglob("*.py")):
        if "__pycache__" in str(py_file):
            continue
        result.files_checked += 1
        result.findings.extend(_check_security_drift(py_file))
        result.findings.extend(_check_test_drift(py_file, tests))

    return result
