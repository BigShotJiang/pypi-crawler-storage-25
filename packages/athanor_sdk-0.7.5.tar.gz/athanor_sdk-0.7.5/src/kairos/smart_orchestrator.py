"""ATH-1443: Smart orchestrator — stream vs wait decision for subagents.

When spawning multiple subagents (proposer fleet, parallel review, batch repair),
decide intelligently:
- STREAM: show results as they arrive, cancel remaining when good enough
- WAIT: collect all results, pick the best

The decision depends on the task type, urgency, and quality bar.
"""
from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed, Future
from dataclasses import dataclass, field
from typing import Any, Callable, TypeVar

_log = logging.getLogger("kairos.orchestrator")

T = TypeVar("T")


@dataclass
class OrchestratorConfig:
    """Configuration for smart subagent orchestration."""
    max_workers: int = 3
    mode: str = "stream_first"  # stream_first | wait_all | race_best
    timeout_sec: int = 120
    good_enough: Callable[[Any], bool] | None = None


@dataclass
class SubagentResult:
    agent_id: str
    result: Any
    elapsed_sec: float
    success: bool
    error: str | None = None


@dataclass
class OrchestratorOutcome:
    results: list[SubagentResult] = field(default_factory=list)
    mode_used: str = ""
    total_elapsed_sec: float = 0.0
    early_exit: bool = False
    cancelled_count: int = 0


def run_subagents(
    tasks: list[tuple[str, Callable[[], Any]]],
    config: OrchestratorConfig | None = None,
) -> OrchestratorOutcome:
    """Run multiple subagent tasks with smart scheduling.

    Args:
        tasks: List of (agent_id, callable) pairs.
        config: Orchestration config. Defaults to stream_first with 3 workers.

    Modes:
        stream_first: Return as soon as the first good-enough result arrives.
                      Cancel remaining. Best for: optimize (first PROVED wins).
        wait_all:     Collect all results, return all. Best for: review (want
                      multiple perspectives), batch (want complete triage).
        race_best:    Collect all results within timeout, pick the best.
                      Best for: proposer fleet (want highest area reduction).
    """
    if config is None:
        config = OrchestratorConfig()

    outcome = OrchestratorOutcome(mode_used=config.mode)
    t0 = time.monotonic()

    if not tasks:
        return outcome

    if len(tasks) == 1:
        agent_id, fn = tasks[0]
        try:
            t_start = time.monotonic()
            result = fn()
            elapsed = time.monotonic() - t_start
            outcome.results.append(SubagentResult(
                agent_id=agent_id, result=result,
                elapsed_sec=elapsed, success=True,
            ))
        except Exception as e:  # noqa: BLE001
            outcome.results.append(SubagentResult(
                agent_id=agent_id, result=None,
                elapsed_sec=time.monotonic() - t_start,
                success=False, error=str(e)[:200],
            ))
        outcome.total_elapsed_sec = time.monotonic() - t0
        return outcome

    with ThreadPoolExecutor(max_workers=config.max_workers) as pool:
        future_to_id: dict[Future, str] = {}
        for agent_id, fn in tasks:
            fut = pool.submit(fn)
            future_to_id[fut] = agent_id

        try:
            _run_mode(config, future_to_id, outcome, t0)
        except TimeoutError:
            _log.warning(f"{config.mode}: global timeout — returning partial results")

    outcome.total_elapsed_sec = time.monotonic() - t0
    return outcome


def _run_mode(config, future_to_id, outcome, t0):
    if config.mode == "stream_first":
        for fut in as_completed(future_to_id, timeout=config.timeout_sec):
            agent_id = future_to_id[fut]
            try:
                result = fut.result(timeout=1)
                elapsed = time.monotonic() - t0
                sr = SubagentResult(
                    agent_id=agent_id, result=result,
                    elapsed_sec=elapsed, success=True,
                )
                outcome.results.append(sr)
                if config.good_enough and config.good_enough(result):
                    for other_fut in future_to_id:
                        if other_fut != fut and not other_fut.done():
                            other_fut.cancel()
                            outcome.cancelled_count += 1
                    outcome.early_exit = True
                    break
            except Exception as e:  # noqa: BLE001
                outcome.results.append(SubagentResult(
                    agent_id=agent_id, result=None,
                    elapsed_sec=time.monotonic() - t0,
                    success=False, error=str(e)[:200],
                ))
    elif config.mode in ("wait_all", "race_best"):
        for fut in as_completed(future_to_id, timeout=config.timeout_sec):
            agent_id = future_to_id[fut]
            try:
                result = fut.result(timeout=1)
                outcome.results.append(SubagentResult(
                    agent_id=agent_id, result=result,
                    elapsed_sec=time.monotonic() - t0, success=True,
                ))
            except Exception as e:  # noqa: BLE001
                outcome.results.append(SubagentResult(
                    agent_id=agent_id, result=None,
                    elapsed_sec=time.monotonic() - t0,
                    success=False, error=str(e)[:200],
                ))


def select_mode(task_type: str) -> str:
    """Auto-select orchestration mode based on task type.

    optimize: stream_first (first PROVED wins, cancel rest)
    review:   wait_all (want multiple perspectives)
    repair:   wait_all (want complete triage)
    explore:  race_best (want highest quality option)
    """
    return {
        "optimize": "stream_first",
        "review": "wait_all",
        "repair": "wait_all",
        "explore": "race_best",
    }.get(task_type, "wait_all")
