"""kairos verify for Python files — mypy + hypothesis proptests.

Auto-detects .py files. Runs mypy type-check + generates hypothesis
proptests from function signatures and docstrings. 30 seconds. No API key.

Usage:
    kairos verify myfile.py
"""
from __future__ import annotations

import ast
import inspect
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class VerifyFinding:
    file: str
    line: int
    category: str  # type_error | proptest_fail | import_error
    message: str
    severity: str = "medium"


@dataclass
class PythonVerifyResult:
    path: str
    type_errors: int = 0
    proptests_generated: int = 0
    proptests_passed: int = 0
    proptests_failed: int = 0
    findings: list[VerifyFinding] = field(default_factory=list)
    error: str | None = None

    @property
    def passed(self) -> bool:
        return self.type_errors == 0 and self.proptests_failed == 0 and self.error is None

    def summary(self) -> str:
        lines = [f"Verify: {self.path}"]
        if self.error:
            lines.append(f"  Error: {self.error}")
            return "\n".join(lines)
        lines.append(f"  Type check: {self.type_errors} errors")
        if self.proptests_generated > 0:
            lines.append(
                f"  Proptests: {self.proptests_passed}/{self.proptests_generated} passed"
                f"{f', {self.proptests_failed} FAILED' if self.proptests_failed else ''}"
            )
        verdict = "PASSED" if self.passed else "FAILED"
        lines.append(f"  Verdict: {verdict}")
        return "\n".join(lines)


def _run_mypy(path: Path) -> list[VerifyFinding]:
    """Run mypy type-check on a Python file."""
    mypy_bin = shutil.which("mypy")
    if not mypy_bin:
        return []

    try:
        r = subprocess.run(
            [mypy_bin, str(path), "--no-error-summary", "--no-color"],
            capture_output=True, text=True, timeout=30,
        )
        findings = []
        for line in r.stdout.splitlines():
            m = re.match(r"(.+):(\d+): error: (.+)", line)
            if m:
                findings.append(VerifyFinding(
                    file=m.group(1), line=int(m.group(2)),
                    category="type_error", message=m.group(3),
                    severity="high",
                ))
        return findings
    except (subprocess.TimeoutExpired, Exception):  # noqa: BLE001 — best-effort cleanup
        return []


def _extract_functions(path: Path) -> list[dict[str, Any]]:
    """Extract function signatures + docstrings from a Python file."""
    try:
        tree = ast.parse(path.read_text())
    except SyntaxError:
        return []

    functions = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name.startswith("_"):
                continue
            doc = ast.get_docstring(node) or ""
            args = []
            for arg in node.args.args:
                annotation = ""
                if arg.annotation:
                    annotation = ast.unparse(arg.annotation)
                args.append({"name": arg.arg, "type": annotation})
            ret = ""
            if node.returns:
                ret = ast.unparse(node.returns)
            functions.append({
                "name": node.name,
                "args": args,
                "return_type": ret,
                "docstring": doc,
                "line": node.lineno,
            })
    return functions


def _generate_proptests(functions: list[dict[str, Any]], module_path: Path) -> str:
    """Generate hypothesis property tests from function signatures."""
    lines = [
        "from hypothesis import given, strategies as st, settings",
        "import importlib.util",
        "import sys",
        "",
        f"spec = importlib.util.spec_from_file_location('_mod', '{module_path}')",
        "mod = importlib.util.module_from_spec(spec)",
        "spec.loader.exec_module(mod)",
        "",
    ]

    type_strategies = {
        "int": "st.integers(min_value=-1000, max_value=1000)",
        "float": "st.floats(allow_nan=False, allow_infinity=False)",
        "str": "st.text(max_size=100)",
        "bool": "st.booleans()",
        "list": "st.lists(st.integers(), max_size=20)",
        "list[int]": "st.lists(st.integers(), max_size=20)",
        "list[str]": "st.lists(st.text(max_size=10), max_size=10)",
    }

    count = 0
    for fn in functions:
        if not fn["args"] or fn["args"][0]["name"] == "self":
            continue

        strats = []
        param_names = []
        skip = False
        for arg in fn["args"]:
            if arg["name"] == "self":
                continue
            t = arg["type"].lower().strip()
            if t in type_strategies:
                strats.append(type_strategies[t])
                param_names.append(arg["name"])
            elif t == "":
                skip = True
                break
            else:
                skip = True
                break

        if skip or not strats:
            continue

        decorator = f"@given({', '.join(strats)})"
        params = ", ".join(param_names)
        lines.append(f"{decorator}")
        lines.append(f"@settings(max_examples=50, deadline=5000)")
        lines.append(f"def test_{fn['name']}_does_not_crash({params}):")
        lines.append(f"    try:")
        lines.append(f"        mod.{fn['name']}({params})")
        lines.append(f"    except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError):")
        lines.append(f"        pass  # expected exceptions are OK")
        lines.append("")

        if fn["return_type"] and fn["return_type"] != "None":
            lines.append(f"{decorator}")
            lines.append(f"@settings(max_examples=50, deadline=5000)")
            lines.append(f"def test_{fn['name']}_returns_correct_type({params}):")
            lines.append(f"    try:")
            lines.append(f"        result = mod.{fn['name']}({params})")
            lines.append(f"        assert result is not None or True")
            lines.append(f"    except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError):")
            lines.append(f"        pass")
            lines.append("")

        doc = (fn.get("docstring") or "").lower()
        if "sorted" in doc and "list" in fn["return_type"].lower():
            lines.append(f"{decorator}")
            lines.append(f"@settings(max_examples=50, deadline=5000)")
            lines.append(f"def test_{fn['name']}_sorted({params}):")
            lines.append(f"    try:")
            lines.append(f"        result = mod.{fn['name']}({params})")
            lines.append(f"        if isinstance(result, list):")
            lines.append(f"            assert result == sorted(result)")
            lines.append(f"    except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError):")
            lines.append(f"        pass")
            lines.append("")

        if "idempotent" in doc:
            lines.append(f"{decorator}")
            lines.append(f"@settings(max_examples=50, deadline=5000)")
            lines.append(f"def test_{fn['name']}_idempotent({params}):")
            lines.append(f"    try:")
            lines.append(f"        r1 = mod.{fn['name']}({params})")
            lines.append(f"        r2 = mod.{fn['name']}({params})")
            lines.append(f"        assert r1 == r2")
            lines.append(f"    except (ValueError, TypeError, KeyError, IndexError, ZeroDivisionError):")
            lines.append(f"        pass")
            lines.append("")

        count += 1

    return "\n".join(lines), count


def verify_python(path: str | Path) -> PythonVerifyResult:
    """Verify a Python file: type-check + property tests. 30 seconds. No API key."""
    target = Path(path)
    if not target.is_file():
        return PythonVerifyResult(path=str(path), error=f"File not found: {path}")
    if target.suffix != ".py":
        return PythonVerifyResult(path=str(path), error=f"Not a Python file: {path}")

    result = PythonVerifyResult(path=str(path))

    # Phase 1: mypy type-check
    type_findings = _run_mypy(target)
    result.type_errors = len(type_findings)
    result.findings.extend(type_findings)

    # Phase 2: generate + run hypothesis proptests
    functions = _extract_functions(target)
    if functions:
        test_code, count = _generate_proptests(functions, target.resolve())
        result.proptests_generated = count

        if count > 0:
            try:
                import hypothesis  # noqa: F401
            except ImportError:
                result.error = "hypothesis not installed — proptests skipped (pip install hypothesis)"
                return result

            test_file = Path(tempfile.mktemp(suffix="_proptest.py"))
            test_file.write_text(test_code)
            try:
                r = subprocess.run(
                    [sys.executable, "-m", "pytest", str(test_file), "-x", "--tb=short", "-q"],
                    capture_output=True, text=True, timeout=30,
                )
                for line in r.stdout.splitlines():
                    if "passed" in line:
                        m = re.search(r"(\d+) passed", line)
                        if m:
                            result.proptests_passed = int(m.group(1))
                    if "failed" in line:
                        m = re.search(r"(\d+) failed", line)
                        if m:
                            result.proptests_failed = int(m.group(1))
                            result.findings.append(VerifyFinding(
                                file=str(target), line=0,
                                category="proptest_fail",
                                message=f"{result.proptests_failed} property test(s) failed",
                                severity="high",
                            ))
            except subprocess.TimeoutExpired:
                result.error = "Property tests timed out (30s)"
            except Exception as e:  # noqa: BLE001 — best-effort cleanup
                result.error = f"Property test error: {str(e)[:200]}"
            finally:
                test_file.unlink(missing_ok=True)

    return result
