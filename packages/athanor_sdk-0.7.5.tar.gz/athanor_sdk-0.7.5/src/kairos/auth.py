"""ATH-369 — ATHANOR_TOKEN loading with file-based config.

Security background: before ATH-369, the SDK read `ATHANOR_TOKEN` only
from the environment variable. On Linux any process with read access
to `/proc/<pid>/environ` (same-user + ptrace-capable) can read all env
vars for every other process on the machine. On multi-tenant boxes
that means a malicious co-located user can harvest the token.

ATH-369 fix: prefer a config file (`~/.athanor/token`, mode 0o600 —
owner read/write only). Env var remains as a legacy fallback for
one version with a deprecation warning.

## Priority order

    1. Explicit CLI arg (`--token foo`)      — highest precedence
    2. File at `~/.athanor/token` (0o600)    — preferred
    3. Env var `ATHANOR_TOKEN` (deprecated)  — fallback, warns
    4. None                                   — caller decides what to do

## Usage

    from kairos.auth import load_token

    token = load_token(cli_arg=args.token)
    if not token:
        print("Error: no token configured. Run `athanor config --set-token`.")
        sys.exit(1)

## Writing the token

    from kairos.auth import save_token
    save_token("sk-athanor-...")

Creates `~/.athanor/` directory with mode 0o700, writes
`~/.athanor/token` with mode 0o600. Both owner-only.

## Why the deprecation window

Existing customers have bootstrap scripts that export ATHANOR_TOKEN.
Breaking those today is hostile. The fallback + warning gives them
one release to migrate; the warning includes a one-liner showing how
to move to the file-based config.
"""
from __future__ import annotations

import os

from kairos.envvars import getenv_dual
import stat
import sys
from pathlib import Path
from typing import Optional


CONFIG_DIR = Path.home() / ".athanor"
TOKEN_FILE = CONFIG_DIR / "token"

_DEPRECATION_WARNED = False


def load_token(cli_arg: Optional[str] = None) -> Optional[str]:
    """Resolve ATHANOR_TOKEN from the configured sources.

    Priority: CLI arg > config file > env var > None.

    Emits a deprecation warning (once per process) if the token comes
    from the env var — points the user at the file-based config.
    """
    if cli_arg is not None:
        if not cli_arg.strip():
            raise ValueError("--token was provided but is empty")
        return cli_arg

    token = _read_token_file()
    if token:
        return token

    env_token: str | None = getenv_dual("TOKEN")
    if env_token:
        _warn_env_deprecation_once()
        return env_token

    return None


def save_token(token: str) -> None:
    """Persist token to `~/.athanor/token` with owner-only permissions.

    Creates `~/.athanor/` (mode 0o700) if missing. Overwrites existing
    token file atomically via write-and-rename.

    Raises `OSError` on filesystem failures (permission denied, no
    space, etc.) — caller handles the error UX.
    """
    if not token or not token.strip():
        raise ValueError("token must be a non-empty string")
    if CONFIG_DIR.is_symlink():
        raise OSError(f"{CONFIG_DIR} is a symlink — refusing to write token (possible traversal)")
    CONFIG_DIR.mkdir(mode=0o700, exist_ok=True)
    os.chmod(CONFIG_DIR, 0o700)

    # Write to a temp file in the same directory, fsync, then rename —
    # atomic replace. Avoids a partial-write readable-to-other-user
    # window.
    tmp = TOKEN_FILE.with_suffix(".tmp")
    # Use low-level open so we set mode at creation time, not after.
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(str(tmp), flags, 0o600)
    try:
        os.write(fd, token.encode("utf-8"))
        os.fsync(fd)
    finally:
        os.close(fd)
    os.replace(tmp, TOKEN_FILE)
    # Defensive: re-chmod in case replace didn't preserve mode
    # (shouldn't happen on Linux, but cheap to be safe).
    os.chmod(TOKEN_FILE, 0o600)


def clear_token() -> None:
    """Remove the token file. No-op if not present."""
    try:
        TOKEN_FILE.unlink()
    except FileNotFoundError:
        pass


def _read_token_file() -> Optional[str]:
    """Return the trimmed token from the config file, or None."""
    try:
        if not TOKEN_FILE.exists():
            return None
        # Open with O_NOFOLLOW to prevent TOCTOU symlink race:
        # between an is_symlink() check and read_text(), an attacker
        # could swap the file for a symlink.
        flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
        fd = os.open(str(TOKEN_FILE), flags)
        try:
            st = os.fstat(fd)
            mode = stat.S_IMODE(st.st_mode)
            if mode & (stat.S_IRGRP | stat.S_IROTH | stat.S_IWGRP | stat.S_IWOTH):
                sys.stderr.write(
                    f"Warning: {TOKEN_FILE} has overly permissive mode "
                    f"{oct(mode)}. Ignoring. Run `chmod 0600 {TOKEN_FILE}` "
                    f"and retry, or re-save the token via "
                    f"`athanor config --set-token`.\n"
                )
                return None
            content = os.read(fd, 4096).decode("utf-8").strip()
            return content or None
        finally:
            os.close(fd)
    except OSError as e:
        if isinstance(e, PermissionError):
            sys.stderr.write(f"Warning: cannot read {TOKEN_FILE}: {e}\n")
        return None


def _warn_env_deprecation_once() -> None:
    global _DEPRECATION_WARNED
    if _DEPRECATION_WARNED:
        return
    _DEPRECATION_WARNED = True
    sys.stderr.write(
        "Warning: reading ATHANOR_TOKEN from environment variable. "
        "This is deprecated and will be removed in a future release. "
        "Migrate to the file-based config:\n"
        "  mkdir -p ~/.athanor && chmod 0700 ~/.athanor\n"
        "  printf '%s' \"$ATHANOR_TOKEN\" > ~/.athanor/token\n"
        "  chmod 0600 ~/.athanor/token\n"
        "Or: `athanor config --set-token`.\n"
    )


__all__ = [
    "CONFIG_DIR",
    "TOKEN_FILE",
    "load_token",
    "save_token",
    "clear_token",
]
