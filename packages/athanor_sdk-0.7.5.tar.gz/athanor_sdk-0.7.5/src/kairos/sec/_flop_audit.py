"""kairos.sec._flop_audit — flop-name correspondence audit (ATH-983 W3).

Per the customer's directive on the customer engagement, the SEC
gate must preserve every flop name from the original RTL.
Combinational signal names do not matter; only flops. The reason is
EBMC k-induction: the customer's engineer derives invariants from the Clash gate's
graph structure and maps those invariants back to the SV gold via
flop-name correspondence. If the Clash gate emits ``wire [2:0] hd;``
where the SV gold has ``logic [2:0] head;``, the induction step
finds an aliasing-shaped counter-example that does not exist in
the gold. Documenting this upfront saves the SEC reviewer from
hours chasing a name mismatch as if it were real semantic divergence.

Public surface
--------------

* :func:`extract_flops` — read a Verilog or SystemVerilog file and
  return the set of flop register declarations (name + width).
  Uses a deliberately simple regex-based parser; the audit is a
  cross-check, not a synthesis-quality SV parser.

* :func:`audit_flop_correspondence` — given a gold SV file and a
  gate Verilog file, return a :class:`FlopAuditResult` carrying:
    - The set of flops declared in each
    - Names present in only-gold or only-gate
    - Whether the audit passes (declared names match)

What this module does NOT do
----------------------------

* Parse Verilog at synthesis-quality. The audit runs on the source
  text using regex extraction; it correctly handles the canonical
  flop declaration shapes the Clash + SV gold patterns produce
  (``logic [W:0] name;``, ``wire [W:0] name;``,
  ``logic name;``, ``wire name;``, ``T name [DEPTH];`` for
  unpacked arrays). It does NOT handle inline preprocessor macros,
  generate blocks, or multi-line declarations spanning macro
  expansions. Those land outside the demo bundles' shape and are
  scope-out for the v0 audit.

* Distinguish flops from combinational nets. The audit reports any
  declared register or wire by name. Combinational signal-name
  divergence does not matter for SEC, so a name appearing in only
  one side that is in fact combinational is a benign false-positive.
  Callers should pass an ``ignore`` set listing combinational signal
  names they want to skip.

Cross-refs
----------

* ATH-983 (the SEC pivot ticket).
* the customer's flop-name-preservation directive (2026-05-04
  #project-customer thread, relayed via CTO to qa #dev-sdk).
* :mod:`kairos.sec._miter` (the miter that this audit's verdict
  feeds into — a failed flop-name audit means the miter would
  silently produce an aliasing counter-example).
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path


# Regex for the canonical declaration shapes. Captures the lead name
# of the decl. Comma-separated multi-name decls are handled below by
# a follow-up scan over the trailing-name run. Initialization clauses
# (``= <expr>``) are tolerated before the terminator.
_DECL_RE = re.compile(
    r"""
    \b(?:logic|wire|reg)        # storage class
    \s*
    (?:\[[^\]]*\]\s*)?            # optional packed width — any expr in []
    \s*
    (?P<name>[A-Za-z_][\w]*)    # lead identifier
    \s*
    (?:\[[^\]]*\]\s*)?            # optional unpacked dim [N]
    \s*
    (?P<rest>(?:,\s*[A-Za-z_][\w]*\s*)*)  # comma-tail
    \s*
    (?:=\s*[^;]*)?                # optional init clause = <expr>
    \s*
    ;                              # terminator
    """,
    re.VERBOSE,
)

# Regex for comma-tail names (extracted from the rest group).
_COMMA_NAME_RE = re.compile(r",\s*([A-Za-z_][\w]*)")

# Regex for ``always_ff`` blocks — declarations inside these are
# canonical flops on the SV side; we use this to filter the
# decl matches to the flop set.
#
# v0 simplification: instead of full SV parsing, we treat any logic
# declaration appearing OUTSIDE an ``always_*`` block as a flop
# candidate at the module top. SV authors typically declare flop
# storage at module-top, then drive it inside always_ff. The Clash
# emitter uses ``wire`` for everything at the top, so width-only
# audit is enough.

# Simple keywords-to-skip: SV/Verilog keywords that look like names
# in some regex hits.
_KEYWORDS = {
    "logic", "wire", "reg", "input", "output", "inout", "module",
    "endmodule", "begin", "end", "if", "else", "always",
    "always_ff", "always_comb", "assign", "posedge", "negedge",
    "clk", "rst_n", "rst",
    # Clash codegen artefacts: combinational ds wires, intermediate
    # case-alt wires. Not flops.
    "ds1", "ds2", "ds3",
}


@dataclass(frozen=True)
class FlopAuditResult:
    """Outcome of :func:`audit_flop_correspondence`.

    Attributes
    ----------
    gold_flops:
        Set of register names declared in the gold SV file.
    gate_flops:
        Set of register names declared in the gate Verilog file.
    only_in_gold:
        Names declared in gold but absent from gate. A non-empty set
        is the canonical correspondence-failure mode: the SEC engine
        may produce a counter-example where the gate's missing
        register's would-be value diverges from the gold's.
    only_in_gate:
        Names declared in gate but absent from gold. Usually
        Clash-emitted intermediate wires; benign when listed in
        ``ignore``.
    passes:
        True iff ``only_in_gold`` is empty (every gold flop has a
        same-named gate counterpart).
    """

    gold_flops: frozenset[str]
    gate_flops: frozenset[str]
    only_in_gold: frozenset[str]
    only_in_gate: frozenset[str]
    passes: bool


def extract_flops(
    sv_text: str,
    *,
    ignore: frozenset[str] = frozenset(),
) -> frozenset[str]:
    """Extract the set of declared register/wire names from SV text.

    See module docstring for the v0 simplifications. The audit is a
    cross-check, not a synthesis-quality parser.

    :param sv_text: Source text of the SV / Verilog file.
    :param ignore: Names to skip even if they appear in the source
        (combinational signals, Clash intermediate wires, etc).

    :returns: frozenset of register/wire identifiers found.
    """
    raw_names = set()
    for match in _DECL_RE.finditer(sv_text):
        name = match.group("name")
        if name not in _KEYWORDS:
            raw_names.add(name)
        # Walk the comma-tail for additional names sharing this decl.
        rest = match.group("rest") or ""
        for tail in _COMMA_NAME_RE.findall(rest):
            if tail not in _KEYWORDS:
                raw_names.add(tail)
    return frozenset(raw_names - ignore)


def audit_flop_correspondence(
    *,
    gold_sv_path: str | Path,
    gate_v_path: str | Path,
    ignore_in_gate: frozenset[str] = frozenset(),
    ignore_in_gold: frozenset[str] = frozenset(),
) -> FlopAuditResult:
    """Run the flop-name correspondence audit on a gold/gate pair.

    :param gold_sv_path: Path to the gold SystemVerilog file.
    :param gate_v_path: Path to the gate Verilog file (typically
        Clash-emitted).
    :param ignore_in_gate: Names to ignore in the gate side. Pass
        the Clash codegen's intermediate-wire prefixes here; otherwise
        every ``c$ds1_*`` and similar will appear as gate-only.
    :param ignore_in_gold: Names to ignore in the gold side. Pass
        the gold's combinational nets here so the audit only reports
        missing flop correspondence, not benign comb-net divergence.

    :returns: :class:`FlopAuditResult` carrying the per-side flop
        sets + the difference verdict.
    """
    gold_text = Path(gold_sv_path).read_text()
    gate_text = Path(gate_v_path).read_text()

    gold_flops = extract_flops(gold_text, ignore=ignore_in_gold)
    gate_flops = extract_flops(gate_text, ignore=ignore_in_gate)

    only_in_gold = gold_flops - gate_flops
    only_in_gate = gate_flops - gold_flops

    return FlopAuditResult(
        gold_flops=gold_flops,
        gate_flops=gate_flops,
        only_in_gold=frozenset(only_in_gold),
        only_in_gate=frozenset(only_in_gate),
        passes=len(only_in_gold) == 0,
    )


__all__ = [
    "FlopAuditResult",
    "audit_flop_correspondence",
    "extract_flops",
]
