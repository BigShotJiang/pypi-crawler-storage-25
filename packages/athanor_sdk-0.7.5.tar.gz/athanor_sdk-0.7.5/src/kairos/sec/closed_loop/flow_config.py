"""ATH-1118 deliverable 1: flow configuration for customer agents.

Customers configure kairos behavior via a kairos.yaml file or
keyword arguments. Every tunable parameter has a default, a type
constraint, and a validation rule. Bad values are rejected
structurally at config load time, not at runtime.

The flow config controls:
- Which verification engines to use
- Timeout thresholds (adaptive by default)
- Gate thresholds (structural + toggle power)
- Which LLM models to use
- Budget caps (cost + wall time)
- Which pipeline steps to run
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from kairos.model_presets import DEFAULT_SEC_PROPOSER_MODEL


@dataclass
class FlowConfig:
    """Customer-configurable flow parameters.

    Load from kairos.yaml or pass as kwargs to optimize().
    Every field has a safe default. Validation runs at __post_init__.
    """
    # Verification engines
    combo_engine: str = "yosys_dual_engine"
    sequential_engine: str = "ebmc_bmc_kinduction"
    confirmatory_engine: str = "ebmc_60s"
    require_multi_engine: bool = True

    # Timeouts (0 = adaptive based on design size)
    verification_timeout_sec: int = 0
    proposer_timeout_sec: int = 360
    ebmc_confirmatory_timeout_sec: int = 60

    # Gates
    structural_gate_enabled: bool = True
    toggle_power_gate_enabled: bool = True
    toggle_power_threshold_pct: float = 20.0

    # Proposer
    models: tuple[str, ...] = (
        DEFAULT_SEC_PROPOSER_MODEL,
        "azure_ai/kimi-k2.6-1",
        "azure_ai/kimi-k2.6-1",
        "azure/gpt-5.5-1",
        "gemini/gemini-2.5-flash",
    )
    max_proposals: int = 3
    max_inner_retries: int = 3
    proposer_mode: str = "full"

    # Budget
    max_cost_usd: float = 10.0
    max_wall_time_sec: int = 3600

    # Pipeline steps
    mine_before_propose: bool = False
    elaborate_gold: bool = True
    detect_patterns: bool = True
    cegar_escalation: bool = True

    # k-induction
    k_induction_bound: int = 32

    def __post_init__(self) -> None:
        errors = self.validate()
        if errors:
            raise ValueError(
                f"Invalid flow config: {'; '.join(errors)}"
            )

    def validate(self) -> list[str]:
        """Validate all config values. Returns list of errors."""
        errors = []
        if self.toggle_power_threshold_pct < 0:
            errors.append("toggle_power_threshold_pct must be >= 0")
        if self.toggle_power_threshold_pct > 100:
            errors.append("toggle_power_threshold_pct must be <= 100")
        if self.max_proposals < 1:
            errors.append("max_proposals must be >= 1")
        if self.max_proposals > 20:
            errors.append("max_proposals must be <= 20")
        if self.max_inner_retries < 0:
            errors.append("max_inner_retries must be >= 0")
        if self.max_cost_usd < 0:
            errors.append("max_cost_usd must be >= 0")
        if self.max_wall_time_sec < 60:
            errors.append("max_wall_time_sec must be >= 60")
        if self.k_induction_bound < 1:
            errors.append("k_induction_bound must be >= 1")
        valid_combo = {"yosys_dual_engine", "yosys_equiv", "yosys_sat"}
        if self.combo_engine not in valid_combo:
            from kairos.sec.closed_loop.engine_registry import get_registry
            if get_registry().get(self.combo_engine) is None:
                errors.append(f"combo_engine must be one of {valid_combo} or a registered custom engine")
        valid_seq = {"ebmc_bmc_kinduction", "ebmc_bmc_only"}
        if self.sequential_engine not in valid_seq:
            from kairos.sec.closed_loop.engine_registry import get_registry
            if get_registry().get(self.sequential_engine) is None:
                errors.append(f"sequential_engine must be one of {valid_seq} or a registered custom engine")
        valid_modes = {"full", "preserve_datapath", "diff"}
        if self.proposer_mode not in valid_modes:
            errors.append(f"proposer_mode must be one of {valid_modes}")
        return errors


def load_flow_config(
    config_path: str | Path | None = None,
    **overrides: Any,
) -> FlowConfig:
    """Load flow config from YAML file + keyword overrides.

    Priority: overrides > YAML file > defaults.
    If no YAML file, uses defaults + overrides.
    """
    config_dict: dict[str, Any] = {}

    if config_path is not None:
        path = Path(config_path)
        if path.is_file():
            try:
                import yaml  # type: ignore[import-untyped,import-not-found,unused-ignore]
                config_dict = yaml.safe_load(path.read_text()) or {}
            except ImportError:
                pass

    config_dict.update(overrides)

    if "models" in config_dict and isinstance(config_dict["models"], list):
        config_dict["models"] = tuple(config_dict["models"])

    valid_fields = {f.name for f in FlowConfig.__dataclass_fields__.values()}
    filtered = {k: v for k, v in config_dict.items() if k in valid_fields}

    return FlowConfig(**filtered)


PRESETS: dict[str, dict[str, Any]] = {
    "conservative": {
        "max_proposals": 1,
        "max_inner_retries": 1,
        "require_multi_engine": True,
        "k_induction_bound": 64,
        "max_cost_usd": 5.0,
        "cegar_escalation": False,
        "proposer_mode": "preserve_datapath",
    },
    "aggressive": {
        "max_proposals": 5,
        "max_inner_retries": 5,
        "require_multi_engine": True,
        "k_induction_bound": 32,
        "max_cost_usd": 25.0,
        "max_wall_time_sec": 7200,
        "cegar_escalation": True,
        "proposer_mode": "full",
        "mine_before_propose": True,
    },
    "ecc_specialist": {
        "max_proposals": 3,
        "max_inner_retries": 3,
        "require_multi_engine": True,
        "k_induction_bound": 32,
        "combo_engine": "yosys_dual_engine",
        "proposer_mode": "full",
        "detect_patterns": True,
    },
    "abc_only": {
        "max_proposals": 1,
        "max_inner_retries": 0,
        "require_multi_engine": True,
        "combo_engine": "yosys_dual_engine",
        "proposer_mode": "full",
        "max_cost_usd": 0.0,
    },
    "spec_rtl_refinement": {
        "max_proposals": 3,
        "max_inner_retries": 2,
        "require_multi_engine": True,
        "k_induction_bound": 64,
        "max_cost_usd": 10.0,
        "cegar_escalation": True,
        "proposer_mode": "full",
    },
}


def load_preset(name: str, **overrides: Any) -> FlowConfig:
    """Load a named preset with optional overrides.

    Available presets: conservative, aggressive, ecc_specialist, abc_only, spec_rtl_refinement.
    Overrides take precedence over preset values.
    """
    if name not in PRESETS:
        raise ValueError(
            f"Unknown preset '{name}'. Available: {', '.join(PRESETS)}"
        )
    merged = {**PRESETS[name], **overrides}
    return FlowConfig(**{
        k: v for k, v in merged.items()
        if k in {f.name for f in FlowConfig.__dataclass_fields__.values()}
    })


__all__ = ["FlowConfig", "load_flow_config", "load_preset", "PRESETS"]
