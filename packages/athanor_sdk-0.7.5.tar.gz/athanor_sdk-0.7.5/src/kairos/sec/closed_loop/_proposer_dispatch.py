"""Proposer dispatch — extracted from God Object (ATH-1415).

Routes to the correct proposer backend: zero-budget, claude-agent,
parallel, or litellm.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any


def dispatch_proposer(
    *,
    proposer_backend: str,
    max_proposals: int,
    bundle_path: Path,
    sig: dict[str, Any],
    target_module: str,
    model: str,
    proposer_timeout_sec: int,
    proposer_mode: str,
    parallel_proposer_count: int,
    parallel_proposer_models: tuple[str, ...] | None,
    toggle_activity: list[dict] | None,
    run_id: str,
    emit_fn: Any,
    log_fn: Any,
) -> Any:
    """Dispatch to the correct proposer backend. Returns ProposalRunResult."""
    from kairos.sec.closed_loop._proposer import ProposalRunResult

    if max_proposals == 0:
        log_fn("  Phase 2: SKIPPED (max_proposals=0, zero-cost mode)")
        return ProposalRunResult(
            target_module=target_module, proposals=[], halt_reason="zero_budget",
        )

    if proposer_backend == "local":
        local_model = model if model != "claude-sonnet-4-20250514" else "ollama/deepseek-coder-v2"
        log_fn(f"  Phase 2: LOCAL proposer ({local_model}, RTL stays on-machine)...")
        from kairos.sec.closed_loop._proposer import propose_transformations
        result = propose_transformations(
            bundle_path=bundle_path, target_module=target_module,
            model=local_model, max_proposals=max_proposals,
            timeout_sec=proposer_timeout_sec, proposer_mode=proposer_mode,
            toggle_activity=toggle_activity,
        )
        log_fn(f"  Local proposer: {len(result.proposals)} proposals, halt={result.halt_reason}")
        return result

    if proposer_backend == "claude-agent":
        from kairos.sec.closed_loop._proposer_fleet import spawn_claude_fleet
        gold_text = (bundle_path / sig["gold_sv"]).read_text()
        log_fn("  Phase 2: Claude subagent fleet...")
        fleet_proposals, auth_errors = spawn_claude_fleet(
            gold_text=gold_text, sig=sig,
            max_proposals=max_proposals,
            timeout_sec=proposer_timeout_sec,
            target_module=target_module,
        )
        for i, p in enumerate(fleet_proposals):
            emit_fn("transformation_proposed", run_subtype="theorem_proving", payload={
                "iteration_index": i, "parent_run_id": run_id,
                "transformation_class": p.transformation_class.value,
                "claimed_area_delta_pct": p.claimed_area_delta_pct,
            })
        halt = (f"AuthenticationError: {auth_errors[0]}" if auth_errors and not fleet_proposals
                else ("ok" if fleet_proposals else "fleet_no_proposals"))
        return ProposalRunResult(
            target_module=target_module, proposals=fleet_proposals,
            halt_reason=halt,
            halt_reason_class="auth" if auth_errors and not fleet_proposals else "",
        )

    if parallel_proposer_count > 1:
        from kairos.sec.closed_loop.parallel_proposer import propose_in_parallel
        parallel_run = propose_in_parallel(
            bundle_path=bundle_path, target_module=target_module,
            K=parallel_proposer_count, models=parallel_proposer_models,
            timeout_sec=proposer_timeout_sec,
            max_proposals_per_branch=max_proposals,
        )
        return ProposalRunResult(
            target_module=target_module,
            proposals=list(parallel_run.proposals),
            halt_reason=parallel_run.halt_reason,
        )

    from kairos.sec.closed_loop._proposer import propose_transformations
    log_fn(f"  Phase 2: LLM proposer ({model}, {max_proposals} proposals, mode={proposer_mode})...")
    result = propose_transformations(
        bundle_path=bundle_path, target_module=target_module,
        model=model, max_proposals=max_proposals,
        timeout_sec=proposer_timeout_sec, proposer_mode=proposer_mode,
        toggle_activity=toggle_activity,
    )
    log_fn(f"  Proposer: {len(result.proposals)} proposals, halt={result.halt_reason}")
    for i, p in enumerate(result.proposals):
        log_fn(f"    [{i}] {p.transformation_class.value}: {p.claimed_area_delta_pct:+.1f}% claimed")
    return result
