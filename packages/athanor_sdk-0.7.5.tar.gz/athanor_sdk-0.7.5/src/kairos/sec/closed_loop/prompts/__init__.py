from __future__ import annotations
import os
from pathlib import Path

_BUNDLED_DIR = Path(__file__).parent

def _customer_dir() -> Path | None:
    env = os.environ.get("KAIROS_PROMPTS_DIR")
    if env:
        p = Path(env)
        if p.is_dir():
            return p
    cwd_prompts = Path.cwd() / "prompts"
    if cwd_prompts.is_dir():
        return cwd_prompts
    return None

def load_prompt(name: str) -> str:
    cdir = _customer_dir()
    if cdir:
        override = cdir / f"{name}.txt"
        if override.is_file():
            return override.read_text()
    path = _BUNDLED_DIR / f"{name}.txt"
    if not path.is_file():
        raise FileNotFoundError(f"prompt template not found: {path}")
    return path.read_text()

def list_prompts() -> list[str]:
    names: set[str] = set()
    for f in _BUNDLED_DIR.glob("*.txt"):
        names.add(f.stem)
    cdir = _customer_dir()
    if cdir:
        for f in cdir.glob("*.txt"):
            names.add(f.stem)
    return sorted(names)
