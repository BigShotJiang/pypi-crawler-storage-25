"""ATH-1166 Layer 3: Agent message queue for mid-flow control.

Customer's agent queues messages into running optimizations.
Three message types:
- hint: appended to next proposer prompt
- config: overrides flow parameters (timeout, bound, model)
- control: abort/pause at next phase boundary

Messages are polled at phase boundaries in the orchestrator.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from queue import Queue, Empty
from typing import Any, Literal


MessageType = Literal["hint", "config", "control"]


@dataclass(frozen=True)
class AgentMessage:
    msg_type: MessageType
    target: str  # "proposer" | "verifier" | "orchestrator"
    content: str
    timestamp: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "msg_type": self.msg_type,
            "target": self.target,
            "content": self.content,
            "timestamp": self.timestamp,
        }


# Global registry of active session queues
_SESSION_QUEUES: dict[str, Queue[AgentMessage]] = {}


def get_queue(run_id: str) -> Queue[AgentMessage]:
    """Get or create the message queue for a run."""
    if run_id not in _SESSION_QUEUES:
        _SESSION_QUEUES[run_id] = Queue()
    return _SESSION_QUEUES[run_id]


def send_message(
    run_id: str,
    target: str,
    message: str,
    msg_type: MessageType = "hint",
) -> bool:
    """Queue a message for a running optimization.

    Returns True if the queue exists (run is active).
    """
    if run_id not in _SESSION_QUEUES:
        # Try file-based queue for cross-process messaging
        return _file_send(run_id, target, message, msg_type)

    q = _SESSION_QUEUES[run_id]
    q.put(AgentMessage(
        msg_type=msg_type,
        target=target,
        content=message,
        timestamp=time.time(),
    ))
    return True


def poll_messages(
    run_id: str,
    target: str | None = None,
) -> list[AgentMessage]:
    """Poll all pending messages for a run.

    Called by the orchestrator at phase boundaries.
    Optionally filter by target agent.
    """
    messages: list[AgentMessage] = []

    # In-process queue
    if run_id in _SESSION_QUEUES:
        q = _SESSION_QUEUES[run_id]
        while True:
            try:
                msg = q.get_nowait()
                if target is None or msg.target == target:
                    messages.append(msg)
            except Empty:
                break

    # File-based queue (cross-process)
    messages.extend(_file_poll(run_id, target))

    return messages


def close_queue(run_id: str) -> None:
    """Remove the queue for a completed run."""
    _SESSION_QUEUES.pop(run_id, None)


# File-based messaging for cross-process (CLI -> running daemon)
_INBOX_DIR = Path.home() / ".kairos" / "runs"


def _file_send(
    run_id: str, target: str, message: str, msg_type: MessageType,
) -> bool:
    inbox = _INBOX_DIR / run_id / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    msg_file = inbox / f"{time.time_ns()}.json"
    msg_file.write_text(json.dumps({
        "msg_type": msg_type,
        "target": target,
        "content": message,
        "timestamp": time.time(),
    }))
    return True


def _file_poll(run_id: str, target: str | None = None) -> list[AgentMessage]:
    inbox = _INBOX_DIR / run_id / "inbox"
    if not inbox.is_dir():
        return []
    messages = []
    for f in sorted(inbox.glob("*.json")):
        try:
            data = json.loads(f.read_text())
            msg = AgentMessage(**data)
            if target is None or msg.target == target:
                messages.append(msg)
            f.unlink()
        except Exception:  # noqa: BLE001
            f.unlink(missing_ok=True)
    return messages


__all__ = [
    "AgentMessage",
    "MessageType",
    "get_queue",
    "send_message",
    "poll_messages",
    "close_queue",
]
