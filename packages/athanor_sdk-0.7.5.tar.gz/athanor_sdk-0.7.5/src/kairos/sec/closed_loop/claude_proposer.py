"""Claude subagent proposer — uses Claude Code subagents instead of litellm API.

ATH-1172: Fleet-as-default. Instead of calling Azure Foundry / Bedrock
for LLM proposals, spawn a Claude subagent that reads the RTL, reasons
about it, and returns optimized gate Verilog.

Uses the same ProposerStrategy protocol as custom engines. The existing
litellm path stays untouched — this is an opt-in alternative activated
via --proposer-backend claude-agent.

The subagent gets the full prompt (system + block memory + cross-block
hints + port constraints) as a structured user message. Output is
parsed via the same JSON extraction fallback already in _proposer.py.
"""
from __future__ import annotations

import os

import json
import subprocess
import tempfile
from pathlib import Path
from typing import Any


# ATH-1212a: per-tool subprocess env allowlist canonical lives in
# `kairos.security.env_allowlist`. The `_safe_env` symbol below is a
# thin re-export so the 4 existing callsites
# (this file's claude_propose, sec/closed_loop/mine_assumptions.py:415,
# model_client/claude_subagent.py:89, sv/counterexample.py:132) keep
# working without textual change. New code should import the factory
# directly from kairos.security.env_allowlist.
from kairos.security.env_allowlist import safe_env_for_claude_subagent as _safe_env

import re as _re

_AUTH_ERROR_PATTERNS = _re.compile(
    r"AuthenticationError|authentication_error|invalid.api" r".key|"
    r"\b401\b.*(?:Unauthorized|invalid|denied)|"
    r"(?:api|auth).*(?:key|token).*(?:invalid|expired|missing)",
    _re.IGNORECASE,
)


class ProposerAuthenticationError(Exception):
    """Raised when a subagent subprocess fails due to API key / auth issues."""


def claude_propose(
    gold_sv: str,
    sig: dict[str, Any],
    max_proposals: int = 1,
    system_prompt: str = "",
    timeout_sec: int = 120,
    max_turns: int = 5,
    proposer_mode: str = "full",
) -> list[dict[str, Any]]:
    """Propose optimizations via Claude Code subagent.

    Writes the prompt to a temp file, invokes claude CLI as a
    subprocess, parses the JSON response.

    Returns list of proposal dicts matching ProposerStrategy protocol.
    """
    if proposer_mode == "diff":
        prompt = _build_diff_prompt(gold_sv, sig, system_prompt, max_proposals)
    else:
        prompt = _build_subagent_prompt(gold_sv, sig, system_prompt, max_proposals)

    prompt_dir = Path(tempfile.mkdtemp(prefix="kairos_proposer_"))
    prompt_file = prompt_dir / "prompt.md"
    prompt_file.write_text(prompt)

    try:
        env = _safe_env()
        # ATH-1387: ensure claude CLI finds OAuth credentials even when
        # HOME is overridden (e.g. trace sink fallback to /tmp).
        if "CLAUDE_CONFIG_DIR" not in env:
            import pathlib
            real_config = pathlib.Path.home() / ".claude"
            if not real_config.is_dir():
                real_config = pathlib.Path("/home/athanor/.claude")
            if real_config.is_dir():
                env["CLAUDE_CONFIG_DIR"] = str(real_config)
        result = subprocess.run(
            [
                "claude", "-p", prompt,
                "--output-format", "text",
                *(["--model", os.environ.get("KAIROS_PROPOSER_MODEL", "claude-opus-4-6")] if os.environ.get("KAIROS_PROPOSER_MODEL", "claude-opus-4-6") else []),
                "--max-turns", str(max_turns),
                "--tools", "",
            ],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            env=env,
        )
        response = result.stdout or ""
        if result.returncode != 0:
            stderr_msg = (result.stderr or "").strip()[:300]
            stdout_msg = (result.stdout or "").strip()[:300]
            if _AUTH_ERROR_PATTERNS.search(stderr_msg):
                raise ProposerAuthenticationError(stderr_msg)
            import sys
            print(
                f"[kairos] claude-agent proposer: exit {result.returncode}: "
                f"{stdout_msg or stderr_msg}",
                file=sys.stderr,
            )
            return []
    except subprocess.TimeoutExpired:
        import sys
        print(f"[kairos] claude-agent proposer: timeout ({timeout_sec}s)", file=sys.stderr)
        return []
    except FileNotFoundError:
        import sys
        print("[kairos] claude-agent proposer: 'claude' not found on PATH", file=sys.stderr)
        return []
    finally:
        prompt_file.unlink(missing_ok=True)
        prompt_dir.rmdir()  # clean up temp directory

    import sys as _sys
    _sys.stderr.write(f"[kairos] proposer raw response ({len(response)} chars): {response[:300]}...\n")
    return _parse_proposals(response, max_proposals, gold_sv if proposer_mode == "diff" else None)


def _build_diff_prompt(
    gold_sv: str,
    sig: dict[str, Any],
    system_prompt: str,
    max_proposals: int,
) -> str:
    """Build a DIFF-MODE prompt — proposer returns patches, not full module."""
    module = sig.get("target_module", "unknown")
    ports = sig.get("ports", [])
    output_ports = [p for p in ports if p.get("direction") == "output"]
    onames = ", ".join(p["name"] for p in output_ports) if output_ports else "all outputs"

    lines = gold_sv.splitlines()
    numbered = "\n".join(f"{i+1}: {l}" for i, l in enumerate(lines))

    return f"""You are a hardware optimization expert. Propose a TARGETED optimization
for this {len(lines)}-line Verilog module. Do NOT rewrite the entire module.
Instead, propose SPECIFIC line changes as a patch.

{system_prompt}

## Target Module: {module}
## Output signals (MUST be preserved): {onames}

## Gold RTL (with line numbers):
```
{numbered}
```

## Instructions:
Propose up to {max_proposals} targeted change(s). For each, return JSON:

```json
{{
  "patches": [
    {{"start_line": 45, "end_line": 52, "new_content": "replacement code here"}},
  ],
  "transformation_class": "<one of: parameterization, structural, impl_swap>",
  "claimed_area_delta_pct": <negative number>,
  "rationale": "<what you changed and why>"
}}
```

RULES:
- Change as FEW lines as possible. One targeted optimization.
- Preserve ALL output signals identically.
- Preserve the module name and all port declarations.
- Line numbers reference the gold RTL above.
- RETURN ONLY JSON. No explanation. No prose. The JSON must be the FIRST character of your response.
"""


def _apply_patches(gold_sv: str, patches: list[dict[str, Any]]) -> str:
    """Apply line-based patches to produce the gate module."""
    lines = gold_sv.splitlines()
    sorted_patches = sorted(patches, key=lambda p: p.get("start_line", 0), reverse=True)
    for patch in sorted_patches:
        start = patch.get("start_line", 1) - 1
        end = patch.get("end_line", start + 1)
        new_content = patch.get("new_content", "")
        lines[start:end] = new_content.splitlines()
    return "\n".join(lines)


def _build_subagent_prompt(
    gold_sv: str,
    sig: dict[str, Any],
    system_prompt: str,
    max_proposals: int,
) -> str:
    """Build the full prompt for the Claude subagent."""
    module = sig.get("target_module", "unknown")
    ports = sig.get("ports", [])
    port_list = "\n".join(
        f"  {p['name']} ({p['direction']}, width={p.get('width', 1)})"
        for p in ports
    )

    is_sequential = bool(sig.get("clock_port"))
    seq_hint = ""
    if is_sequential:
        seq_hint = (
            "\n\nThis is a SEQUENTIAL block (has clock + reset). "
            "Sequential optimization strategies: encoding swap (one-hot→binary), "
            "FSM re-encoding, pointer width narrowing, register sharing, clock gating. "
            "These changes preserve cycle-by-cycle behavior while reducing flip-flop count.\n"
        )

    output_ports = [p for p in ports if p.get("direction") == "output"]
    output_constraint = ""
    if output_ports:
        onames = ", ".join(p["name"] for p in output_ports)
        output_constraint = (
            f"\n\nCRITICAL CONSTRAINT: Every output signal ({onames}) must be "
            f"computed IDENTICALLY to the gold. Copy the output derivation "
            f"logic verbatim. Do NOT change how any output is computed. "
            f"Only optimize INTERNAL logic that does not affect outputs.\n"
        )

    return f"""You are a hardware optimization expert. Your task is to propose area-reducing
optimizations for a Verilog/SystemVerilog module. The optimization must be
FUNCTIONALLY EQUIVALENT to the original — formal verification will check this.
{seq_hint}{output_constraint}
{system_prompt}

## Target Module: {module}

## Port Interface (MUST preserve exactly):
{port_list}

## Gold RTL:
```systemverilog
{gold_sv}
```

## Instructions:
Propose up to {max_proposals} optimization(s). For each, return a JSON object:

```json
{{
  "gate_sv": "<complete optimized Verilog module>",
  "transformation_class": "<one of: parameterization, structural, impl_swap>",
  "claimed_area_delta_pct": <negative number, e.g. -15.0>,
  "rationale": "<one sentence explaining the optimization>"
}}
```

CRITICAL RULES:
- The gate module MUST have the EXACT same port names, directions, and widths as the gold.
- Rename the gate module to {module}_gate.
- Only change internal logic. Do NOT add, remove, or rename ports.
- Return ONLY the JSON. No explanation outside the JSON block.
"""


def _extract_json_objects(text: str) -> list[str]:
    """Extract top-level JSON objects handling nested braces."""
    results = []
    i = 0
    while i < len(text):
        if text[i] == '{':
            depth = 1
            start = i
            i += 1
            in_string = False
            while i < len(text) and depth > 0:
                c = text[i]
                if c == '\\' and in_string:
                    i += 2
                    continue
                if c == '"':
                    in_string = not in_string
                elif not in_string:
                    if c == '{':
                        depth += 1
                    elif c == '}':
                        depth -= 1
                i += 1
            if depth == 0:
                candidate = text[start:i]
                if '"gate_sv"' in candidate or '"patches"' in candidate:
                    results.append(candidate)
        else:
            i += 1
    return results


def _parse_proposals(response: str, max_proposals: int, gold_sv_for_diff: str | None = None) -> list[dict[str, Any]]:
    """Parse proposals from Claude subagent response."""
    proposals = []

    json_blocks = _extract_json_objects(response)

    for block in json_blocks[:max_proposals]:
        try:
            parsed = json.loads(block)
            if "gate_sv" in parsed:
                proposals.append({
                    "gate_sv": parsed["gate_sv"],
                    "transformation_class": parsed.get(
                        "transformation_class", "generic"
                    ),
                    "claimed_area_delta_pct": float(
                        parsed.get("claimed_area_delta_pct", -5.0)
                    ),
                    "rationale": parsed.get("rationale", ""),
                })
            elif "patches" in parsed and gold_sv_for_diff:
                gate_sv = _apply_patches(gold_sv_for_diff, parsed["patches"])
                module = parsed.get("_module", "")
                if module:
                    gate_sv = gate_sv.replace(f"module {module}", f"module {module}_gate", 1)
                proposals.append({
                    "gate_sv": gate_sv,
                    "transformation_class": parsed.get(
                        "transformation_class", "structural"
                    ),
                    "claimed_area_delta_pct": float(
                        parsed.get("claimed_area_delta_pct", -5.0)
                    ),
                    "rationale": parsed.get("rationale", ""),
                })
        except (json.JSONDecodeError, ValueError, KeyError):
            continue

    if not proposals and gold_sv_for_diff:
        import re
        verilog_blocks = re.findall(r'```(?:verilog|systemverilog|sv)?\s*\n(.*?)```', response, re.DOTALL)
        for vb in verilog_blocks:
            if "module " in vb and len(vb) > 50:
                proposals.append({
                    "gate_sv": vb.strip(),
                    "transformation_class": "structural",
                    "claimed_area_delta_pct": -5.0,
                    "rationale": "extracted from prose response (code fence fallback)",
                })
                break

    return proposals


__all__ = ["claude_propose"]
