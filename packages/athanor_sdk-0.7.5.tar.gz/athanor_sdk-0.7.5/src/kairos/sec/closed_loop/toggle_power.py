"""Toggle-activity power measurement via Icarus Verilog + VCD analysis.

Compiles gold and gate designs with iverilog, runs identical random
stimulus through both, captures VCD traces, counts per-signal toggle
activity, and reports the delta. Toggle reduction is a direct proxy
for dynamic power savings (P_dynamic ~ alpha * C * V^2 * f where
alpha is toggle rate).

The testbench generates deterministic pseudo-random stimulus via LFSR
so results are reproducible across runs.
"""
from __future__ import annotations

import os
import re
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from kairos.security.env_allowlist import safe_env_for_eval_bash_host
from kairos.security.path_sanitizer import validate_verilog_identifier


@dataclass(frozen=True)
class SignalToggleCount:
    name: str
    width: int
    toggles: int


@dataclass(frozen=True)
class ToggleMeasurement:
    design_label: str
    total_toggles: int
    signal_counts: tuple[SignalToggleCount, ...]
    sim_cycles: int
    vcd_path: str


@dataclass(frozen=True)
class TogglePowerResult:
    gold: ToggleMeasurement
    gate: ToggleMeasurement
    toggle_delta_pct: float
    sim_cycles: int
    gold_total: int
    gate_total: int


def _generate_testbench(
    *,
    module_name: str,
    instance_name: str,
    ports: Sequence[dict],
    clock_port: str,
    reset_port: str,
    reset_active_low: bool,
    vcd_path: str,
    sim_cycles: int = 200,
    seed: int = 42,
    param_overrides: dict[str, int | str] | None = None,
) -> str:
    """Generate a self-checking testbench that applies pseudo-random stimulus."""
    port_names = {p["name"] for p in ports}
    has_clock = clock_port in port_names
    has_reset = bool(reset_port) and reset_port in port_names

    input_ports = [p for p in ports if p["direction"] == "input"
                   and p["name"] != clock_port
                   and p["name"] != reset_port]

    lines = []
    lines.append(f"module tb_{instance_name};")
    if has_clock:
        lines.append(f"  reg {clock_port} = 0;")
    else:
        lines.append("  reg _tb_clk = 0;")
    if has_reset:
        lines.append(f"  reg {reset_port} = {1 if reset_active_low else 0};")

    for p in input_ports:
        w = p.get("width", 1)
        if w > 1:
            lines.append(f"  reg [{w-1}:0] {p['name']} = 0;")
        else:
            lines.append(f"  reg {p['name']} = 0;")

    output_ports = [p for p in ports if p["direction"] == "output"]
    for p in output_ports:
        w = p.get("width", 1)
        if w > 1:
            lines.append(f"  wire [{w-1}:0] {p['name']};")
        else:
            lines.append(f"  wire {p['name']};")

    # Instance — only bind ports that exist in the design
    lines.append(f"  {module_name} uut (")
    bindings = []
    for p in ports:
        if p["name"] == clock_port and not has_clock:
            continue
        if p["name"] == reset_port and not has_reset:
            continue
        bindings.append(f"    .{p['name']}({p['name']})")
    lines.append(",\n".join(bindings))
    lines.append("  );")

    if param_overrides:
        for k, v in param_overrides.items():
            lines.append(f"  defparam uut.{k} = {v};")

    # Clock
    clk_sig = clock_port if has_clock else "_tb_clk"
    lines.append(f"  always #5 {clk_sig} = ~{clk_sig};")

    # LFSR for pseudo-random stimulus
    lines.append("  reg [31:0] lfsr;")
    lines.append("  initial begin")
    lines.append(f'    $dumpfile("{vcd_path}");')
    lines.append(f"    $dumpvars(0, uut);")
    lines.append(f"    lfsr = 32'h{seed:08x};")

    # Reset sequence
    if has_reset:
        rst_assert = "0" if reset_active_low else "1"
        rst_deassert = "1" if reset_active_low else "0"
        lines.append(f"    {reset_port} = {rst_assert};")
        lines.append(f"    #20 {reset_port} = {rst_deassert};")

    lines.append(f"    repeat ({sim_cycles}) begin")
    lines.append(f"      @(posedge {clk_sig});")
    lines.append("      lfsr = {{lfsr[30:0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]}};")
    for i, p in enumerate(input_ports):
        w = p.get("width", 1)
        if w <= 32:
            lines.append(f"      {p['name']} = lfsr[{min(w-1, 31)}:0];")
        else:
            lines.append(f"      {p['name']} = {{{{({w}//32+1){{lfsr}}}}}};")
        # Rotate LFSR between inputs for diversity
        if i < len(input_ports) - 1:
            lines.append("      lfsr = {{lfsr[30:0], lfsr[31] ^ lfsr[21] ^ lfsr[1] ^ lfsr[0]}};")
    lines.append("    end")
    lines.append("    $finish;")
    lines.append("  end")
    lines.append("endmodule")
    return "\n".join(lines)


def _count_toggles_from_vcd(vcd_path: str) -> tuple[int, tuple[SignalToggleCount, ...]]:
    """Parse VCD and count per-signal toggles."""
    from vcdvcd import VCDVCD

    vcd = VCDVCD(vcd_path)
    counts = []
    total = 0

    for sig_name in vcd.signals:
        # Skip clock and testbench-only signals
        if "clk" in sig_name.lower() or "lfsr" in sig_name.lower():
            continue
        if not sig_name.startswith("tb_"):
            continue

        tv = vcd[sig_name].tv
        toggles = 0
        for i in range(1, len(tv)):
            if tv[i][1] != tv[i-1][1]:
                toggles += 1

        # Estimate width from signal name or value
        width = 1
        if tv:
            val = tv[0][1]
            if isinstance(val, str) and val not in ("x", "z", "0", "1"):
                width = len(val)

        counts.append(SignalToggleCount(
            name=sig_name,
            width=width,
            toggles=toggles,
        ))
        total += toggles

    return total, tuple(sorted(counts, key=lambda c: -c.toggles))


def _strip_synopsys_blocks(text: str) -> str:
    """Strip synopsys translate_off/on blocks that contain elaboration-time
    checks iverilog can't handle (e.g. module-scope if/$error)."""
    return re.sub(
        r'//\s*synopsys\s+translate_off.*?//\s*synopsys\s+translate_on',
        '', text, flags=re.DOTALL,
    )


def _preprocess_design_file(path: str | Path) -> str:
    """Preprocess a design file for iverilog compatibility.
    Strips synopsys translate_off blocks and fixes parameter
    replication expressions that iverilog can't handle.
    Returns path to the (possibly cleaned) file."""
    path = str(path)
    text = Path(path).read_text()
    modified = False
    if 'synopsys translate_off' in text:
        text = _strip_synopsys_blocks(text)
        modified = True
    if re.search(r'parameter\s+\w+\s*=\s*\{', text):
        text = re.sub(
            r'(parameter\s+INIT_VAL\s*=\s*)\{DATA_WIDTH\{1\'b0\}\}',
            r"\g<1>0",
            text,
        )
        modified = True
    if modified:
        out = tempfile.NamedTemporaryFile(
            suffix=".v", mode="w", delete=False,
            prefix=f"clean_{Path(path).stem}_",
        )
        out.write(text)
        out.close()
        return out.name
    return path


def _compile_and_simulate(
    *,
    design_files: Sequence[str | Path],
    testbench: str,
    vcd_path: str,
    label: str,
    timeout_sec: int = 60,
    iverilog_flags: Sequence[str] = (),
) -> ToggleMeasurement:
    """Compile with iverilog, simulate with vvp, parse VCD."""
    cleaned_files = []
    processed_files = []
    for f in design_files:
        pf = _preprocess_design_file(f)
        processed_files.append(pf)
        if pf != str(f):
            cleaned_files.append(pf)

    with tempfile.NamedTemporaryFile(
        suffix=".v", mode="w", delete=False, prefix=f"tb_{label}_"
    ) as f:
        f.write(testbench)
        tb_path = f.name

    sim_out = vcd_path.replace(".vcd", ".sim")

    try:
        cmd_compile = [
            "iverilog", "-g2012", "-o", sim_out,
            *iverilog_flags,
            *processed_files,
            tb_path,
        ]
        r = subprocess.run(
            cmd_compile, capture_output=True, text=True, timeout=timeout_sec,
            env=safe_env_for_eval_bash_host(),
        )
        if r.returncode != 0:
            raise RuntimeError(f"iverilog compile failed for {label}: {r.stderr}")

        r = subprocess.run(
            ["vvp", sim_out], capture_output=True, text=True, timeout=timeout_sec,
            env=safe_env_for_eval_bash_host(),
        )
        if r.returncode != 0 and "ERROR" in r.stderr:
            raise RuntimeError(f"vvp simulation failed for {label}: {r.stderr}")

        if not os.path.isfile(vcd_path):
            raise RuntimeError(f"VCD file not generated for {label}: {vcd_path}")

        total, counts = _count_toggles_from_vcd(vcd_path)

        return ToggleMeasurement(
            design_label=label,
            total_toggles=total,
            signal_counts=counts,
            sim_cycles=200,
            vcd_path=vcd_path,
        )
    finally:
        for f in [tb_path, sim_out, *cleaned_files]:
            try:
                os.unlink(f)
            except OSError:
                pass


def measure_toggle_power(
    *,
    gold_files: Sequence[str | Path],
    gate_files: Sequence[str | Path],
    gold_module: str,
    gate_module: str,
    ports: Sequence[dict],
    clock_port: str = "clk",
    reset_port: str = "rst_n",
    reset_active_low: bool = True,
    sim_cycles: int = 200,
    seed: int = 42,
    work_dir: str | Path | None = None,
    dep_files: Sequence[str | Path] | None = None,
    timeout_sec: int = 120,
    param_overrides: dict[str, int | str] | None = None,
) -> TogglePowerResult:
    """Measure toggle-activity delta between gold and gate.

    Returns a TogglePowerResult with percentage toggle reduction.
    Negative delta = fewer toggles in gate = power saved.
    """
    validate_verilog_identifier(gold_module, "gold_module")
    validate_verilog_identifier(gate_module, "gate_module")
    if work_dir is None:
        work_dir = tempfile.mkdtemp(prefix="toggle_power_")
    work_dir = Path(work_dir)
    work_dir.mkdir(parents=True, exist_ok=True)

    deps = list(dep_files or [])

    gold_vcd = str(work_dir / "gold_toggle.vcd")
    gate_vcd = str(work_dir / "gate_toggle.vcd")

    gold_tb = _generate_testbench(
        module_name=gold_module,
        instance_name="gold",
        ports=ports,
        clock_port=clock_port,
        reset_port=reset_port,
        reset_active_low=reset_active_low,
        vcd_path=gold_vcd,
        sim_cycles=sim_cycles,
        seed=seed,
        param_overrides=param_overrides,
    )

    gate_tb = _generate_testbench(
        module_name=gate_module,
        instance_name="gate",
        ports=ports,
        clock_port=clock_port,
        reset_port=reset_port,
        reset_active_low=reset_active_low,
        vcd_path=gate_vcd,
        sim_cycles=sim_cycles,
        seed=seed,
        param_overrides=param_overrides,
    )

    gold_meas = _compile_and_simulate(
        design_files=[*[str(f) for f in gold_files], *[str(d) for d in deps]],
        testbench=gold_tb,
        vcd_path=gold_vcd,
        label="gold",
        timeout_sec=timeout_sec,
    )

    gate_meas = _compile_and_simulate(
        design_files=[*[str(f) for f in gate_files], *[str(d) for d in deps]],
        testbench=gate_tb,
        vcd_path=gate_vcd,
        label="gate",
        timeout_sec=timeout_sec,
    )

    if gold_meas.total_toggles == 0:
        delta_pct = 0.0
    else:
        delta_pct = (
            (gate_meas.total_toggles - gold_meas.total_toggles)
            / gold_meas.total_toggles
            * 100.0
        )

    return TogglePowerResult(
        gold=gold_meas,
        gate=gate_meas,
        toggle_delta_pct=round(delta_pct, 2),
        sim_cycles=sim_cycles,
        gold_total=gold_meas.total_toggles,
        gate_total=gate_meas.total_toggles,
    )


__all__ = [
    "measure_toggle_power",
    "TogglePowerResult",
    "ToggleMeasurement",
    "SignalToggleCount",
]
