"""Level 2+3+4: Multi-agent orchestrator with YAML flow DSL + artifact protocol.

Customers define an agent graph in YAML. Each agent has a role, model,
tools, and budget. The orchestrator spawns agents, routes artifacts
between them via sha256-verified handoffs, and enforces safety invariants
at every transition.

Design principle: customer controls WHAT (agent roles, models, flow).
kairos enforces HOW (verify, measure, sha256 chain, multi-engine).
"""
from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from kairos.model_presets import DEFAULT_SEC_PROPOSER_MODEL


@dataclass(frozen=True)
class AgentRole:
    """One agent in the customer's optimization fleet."""
    name: str
    role: str  # miner, proposer, verifier, auditor, measurer
    model: str = DEFAULT_SEC_PROPOSER_MODEL
    tools: tuple[str, ...] = ()
    budget_usd: float = 5.0
    timeout_sec: int = 600


@dataclass
class Artifact:
    """A verified artifact passed between agents.

    Artifacts are files with sha256 provenance. No agent trusts
    another agent's CLAIMS — only ARTIFACTS with matching hashes.
    """
    path: str
    sha256: str
    producer: str
    artifact_type: str  # "gold_rtl", "gate_rtl", "miter", "verify_result", "measurement"
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_file(cls, path: Path, producer: str, artifact_type: str, **metadata: Any) -> "Artifact":
        h = hashlib.sha256(path.read_bytes()).hexdigest()
        return cls(
            path=str(path), sha256=h,
            producer=producer, artifact_type=artifact_type,
            metadata=metadata,
        )

    def verify_integrity(self) -> bool:
        """Check that the file still matches its recorded sha256."""
        actual = hashlib.sha256(Path(self.path).read_bytes()).hexdigest()
        return actual == self.sha256


@dataclass
class AgentHandoff:
    """One handoff between agents, with artifact verification."""
    from_agent: str
    to_agent: str
    artifact: Artifact
    timestamp: float = 0.0
    verified: bool = False

    def __post_init__(self) -> None:
        self.timestamp = self.timestamp or time.time()
        if Path(self.artifact.path).is_file():
            self.verified = self.artifact.verify_integrity()


@dataclass
class FlowStep:
    """One step in the customer's flow DSL."""
    agent: str
    action: str  # "mine", "propose", "verify", "audit", "measure", "cert"
    inputs: list[str] = field(default_factory=list)
    outputs: list[str] = field(default_factory=list)


@dataclass
class FlowGraph:
    """Customer-defined agent flow graph.

    Loaded from YAML. Validated against safety invariants before execution.
    """
    agents: dict[str, AgentRole]
    steps: list[FlowStep]

    def validate(self) -> list[str]:
        """Validate the flow against safety invariants."""
        errors = []

        step_actions = [s.action for s in self.steps]

        if "verify" not in step_actions:
            errors.append(
                "REJECTED: flow has no 'verify' step. Every optimization "
                "MUST be formally verified. Add a verify step."
            )

        if "measure" not in step_actions:
            errors.append(
                "REJECTED: flow has no 'measure' step. Every result MUST "
                "be measured post-synthesis. Add a measure step."
            )

        verify_idx = next((i for i, s in enumerate(self.steps) if s.action == "verify"), -1)
        measure_idx = next((i for i, s in enumerate(self.steps) if s.action == "measure"), -1)

        if verify_idx >= 0 and measure_idx >= 0 and measure_idx < verify_idx:
            errors.append(
                "REJECTED: 'measure' before 'verify'. Measurement must "
                "happen AFTER verification to ensure the measured artifact "
                "is the verified artifact."
            )

        for step in self.steps:
            if step.agent not in self.agents:
                errors.append(
                    f"REJECTED: step references agent '{step.agent}' "
                    f"which is not defined in the agents section."
                )

        return errors


def load_flow_graph(config: dict[str, Any]) -> FlowGraph:
    """Load a flow graph from a YAML-parsed dict."""
    agents = {}
    for name, agent_dict in config.get("agents", {}).items():
        tools = agent_dict.get("tools", [])
        if isinstance(tools, list):
            tools = tuple(tools)
        agents[name] = AgentRole(
            name=name,
            role=agent_dict.get("role", name),
            model=agent_dict.get("model", DEFAULT_SEC_PROPOSER_MODEL),
            tools=tools,
            budget_usd=agent_dict.get("budget_usd", 5.0),
            timeout_sec=agent_dict.get("timeout_sec", 600),
        )

    steps = []
    for step_dict in config.get("flow", []):
        steps.append(FlowStep(
            agent=step_dict.get("agent", ""),
            action=step_dict.get("action", ""),
            inputs=step_dict.get("inputs", []),
            outputs=step_dict.get("outputs", []),
        ))

    return FlowGraph(agents=agents, steps=steps)


__all__ = [
    "AgentRole",
    "Artifact",
    "AgentHandoff",
    "FlowStep",
    "FlowGraph",
    "load_flow_graph",
]
