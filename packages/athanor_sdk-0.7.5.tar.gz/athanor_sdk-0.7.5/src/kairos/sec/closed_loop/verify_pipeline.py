"""ATH-1115 sub-2c: verification pipeline utilities.

Pre-verification gates (structural + toggle), engine selection,
and EBMC outcome classification. Extracted from _orchestrator.py
to keep verification logic independently testable.

The main _emit_iteration_arc_for_proposal function remains in
_orchestrator.py but delegates to these utilities.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from kairos.security.path_sanitizer import build_yosys_inc_flags, sanitize_yosys_path
from kairos.sec.closed_loop.measurement import measure_synthesis, measure_toggle_power

# ATH-1212a: per-tool subprocess env allowlists. This module invokes both
# yosys (timing gate at check_timing_gate) and ebmc (capture_ebmc_subprocess)
# in separate subprocess sites; each gets its own factory so credentials
# stay tool-scoped.
from kairos.security.env_allowlist import safe_env_for_ebmc, safe_env_for_yosys


_gold_synth_cache: dict[tuple[str, str], int | None] = {}


def check_structural_gate(
    gold_path: Path,
    gate_path: Path,
    gold_module: str,
    gate_module: str,
) -> tuple[bool, int | None, int | None]:
    """Pre-verification gate: reject proposals that don't reduce cells.

    Returns (passes, gold_cells, gate_cells). When passes=False, the
    proposal is cosmetic and should be rejected before verification.
    Gold synthesis is cached — gold never changes between proposals.
    """
    cache_key = (str(gold_path), gold_module)
    if cache_key in _gold_synth_cache:
        gold_cells = _gold_synth_cache[cache_key]
    else:
        gold_cells = measure_synthesis(gold_path, gold_module)
        _gold_synth_cache[cache_key] = gold_cells
    gate_cells = measure_synthesis(gate_path, gate_module)
    if gold_cells and gate_cells and gate_cells >= gold_cells:
        return False, gold_cells, gate_cells
    return True, gold_cells, gate_cells


def check_toggle_power_gate(
    gold_path: Path,
    gate_path: Path,
    gold_module: str,
    gate_module: str,
    sig: dict[str, Any],
    work_dir: Path,
    threshold_pct: float = 20.0,
) -> tuple[bool, dict[str, Any] | None]:
    """Pre-verification gate: reject proposals that regress power >threshold.

    Only runs when structural gate passed (gate_cells < gold_cells).
    Returns (passes, toggle_result).
    """
    tp = measure_toggle_power(
        gold_path=gold_path,
        gate_path=gate_path,
        gold_module=gold_module,
        gate_module=gate_module,
        sig=sig,
        work_dir=work_dir,
    )
    if tp and tp.get("toggle_delta_pct", 0) > threshold_pct:
        return False, tp
    return True, tp


def check_timing_gate(
    gold_path: Path,
    gate_path: Path,
    gold_module: str,
    gate_module: str,
    timing_constraint_ns: float | None = None,
    deps: list[Path] | None = None,
) -> tuple[bool, dict[str, Any] | None]:
    """Pre-verification gate: reject proposals that violate timing.

    Uses yosys to estimate critical path delay via ABC. If the gate's
    critical path exceeds the gold's by more than 5%, reject.

    Backed by PhysicalDesign.slack_preservation: removing gates on
    non-critical paths preserves critical path slack.

    Returns (passes, timing_result).
    """
    import re
    import shutil
    import subprocess

    yosys_bin = shutil.which("yosys")
    if yosys_bin is None:
        return True, None

    inc_flags = build_yosys_inc_flags([gold_path, gate_path, *(deps or [])])
    inc_prefix = f"{inc_flags} " if inc_flags else ""

    results = {}
    for label, path, module in [
        ("gold", gold_path, gold_module),
        ("gate", gate_path, gate_module),
    ]:
        sanitize_yosys_path(path)
        script = (
            f"read_verilog -sv {inc_prefix}{path}; "
            f"proc; opt; techmap; opt; "
            f"abc -liberty /dev/null -D 1000; "
            f"tee -q /dev/stdout stat"
        )
        try:
            r = subprocess.run(
                [yosys_bin, "-p", script],
                capture_output=True, text=True, timeout=30,
                env=safe_env_for_yosys(),  # ATH-1212a
            )
            m = re.search(r"Delay\s*=\s*([0-9.]+)", r.stdout + r.stderr)
            if m:
                results[label] = float(m.group(1))
        except Exception:  # noqa: BLE001
            pass

    if "gold" not in results or "gate" not in results:
        return True, results

    gold_delay = results["gold"]
    gate_delay = results["gate"]
    timing_result: dict[str, Any] = {
        "gold_delay": gold_delay,
        "gate_delay": gate_delay,
        "delay_delta_pct": round((gate_delay - gold_delay) / gold_delay * 100, 1)
            if gold_delay > 0 else 0,
    }

    if timing_constraint_ns and gate_delay > timing_constraint_ns:
        timing_result["violation"] = f"gate delay {gate_delay}ns exceeds constraint {timing_constraint_ns}ns"
        return False, timing_result

    if gold_delay > 0 and gate_delay > gold_delay * 1.05:
        timing_result["violation"] = (
            f"gate delay {gate_delay:.1f} exceeds gold {gold_delay:.1f} by "
            f"{timing_result['delay_delta_pct']}% (>5% threshold)"
        )
        return False, timing_result

    return True, timing_result


def select_engine(sig: dict[str, Any]) -> str:
    """Select the verification engine based on design characteristics.

    Returns "combo" or "sequential". Combo blocks (no clock) route to
    yosys equiv. Sequential blocks route to EBMC BMC + k-induction.
    """
    if not sig.get("clock_port"):
        return "combo"
    return "sequential"


def classify_bmc_outcome(
    property_verdicts: dict[str, str],
) -> tuple[str, str]:
    """Classify per-property BMC verdicts into an overall outcome.

    Returns (result_str, diagnostic_class) where result_str is one of:
    PASS, FAIL, INCONCLUSIVE, SETUP_ERROR.

    FAIL (any property REFUTED) takes priority over INCONCLUSIVE.
    PASS requires ALL properties PROVED.
    """
    if not property_verdicts:
        return "INCONCLUSIVE", "empty_verdicts"

    verdicts = [v.upper() for v in property_verdicts.values()]

    if any(v == "REFUTED" for v in verdicts):
        return "FAIL", "bmc_counterexample"
    if all(v == "PROVED" for v in verdicts):
        return "PASS", "bmc_proved"
    return "INCONCLUSIVE", "bmc_inconclusive"


def diagnose_ebmc_outcome(
    proved: bool,
    refuted: bool,
    has_inconclusive_props: bool,
) -> tuple[str, str | None]:
    """Map (proved, refuted, has_inconclusive) to (result, diagnostic_class).

    EBMC per-property verdicts can mix; the iteration verdict is the
    weakest across properties (one REFUTED makes the whole iteration
    refuted; INCONCLUSIVE wins over PASS).
    """
    if refuted:
        return "FAIL", "bmc_counterexample"
    if has_inconclusive_props:
        return "INCONCLUSIVE", "missing_inductive_invariant"
    if proved:
        return "PASS", None
    return "INCONCLUSIVE", "kinduction_inconclusive"


def iteration_outcome_from_bmc_result(
    bmc_result: Any,
) -> tuple[str, str | None]:
    """Compute (result_str, diagnostic_class) from a SecVerifyResult.

    ATH-1102: per-property REFUTE escalates to FAIL even when
    bmc_result.refuted (whole-result aggregate) is False, so the
    counterexample-feedback retry loop fires on partial refutes.
    """
    verdicts = bmc_result.property_verdicts
    has_inconclusive = any(
        v.lower() == "inconclusive" for v in verdicts.values()
    )
    has_refute = any(
        v.upper() == "REFUTED" for v in verdicts.values()
    )
    return diagnose_ebmc_outcome(
        proved=bmc_result.proved,
        refuted=bmc_result.refuted or has_refute,
        has_inconclusive_props=has_inconclusive,
    )


def capture_ebmc_subprocess(
    *,
    miter_path: Path,
    gold_path: Path,
    gate_path: Path,
    work_dir: Path,
    mode: str,
    bound: int,
    top_module: str,
    reset_expr: str,
    timeout_sec: int,
    label: str,
) -> None:
    """Run ebmc as a subprocess and capture stdout/stderr/exitcode/cmdline
    to work_dir for customer-facing cert tarball audit trail."""
    import subprocess
    cmd = [
        "ebmc", str(miter_path), str(gold_path), str(gate_path),
        "--bound", str(bound), "--module", top_module,
        "--reset", reset_expr,
    ]
    if mode == "k_induction":
        cmd.append("--k-induction")
    work_dir.mkdir(parents=True, exist_ok=True)
    try:
        res = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout_sec,
            env=safe_env_for_ebmc(),  # ATH-1212a
        )
        stdout, stderr, exitcode = res.stdout, res.stderr, res.returncode
    except subprocess.TimeoutExpired as e:
        stdout = (
            e.stdout.decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        )
        stderr = (
            e.stderr.decode() if isinstance(e.stderr, bytes) else (e.stderr or "")
        )
        stderr += f"\n[capture] subprocess.TimeoutExpired after {timeout_sec}s\n"
        exitcode = -1
    except Exception as e:  # noqa: BLE001
        stdout = ""
        stderr = f"[capture] subprocess error: {type(e).__name__}: {e}\n"
        exitcode = -2
    (work_dir / f"ebmc_{label}.cmdline").write_text(" ".join(cmd) + "\n")
    (work_dir / f"ebmc_{label}.stdout").write_text(stdout)
    (work_dir / f"ebmc_{label}.stderr").write_text(stderr)
    (work_dir / f"ebmc_{label}.exitcode").write_text(str(exitcode) + "\n")


def run_yosys_equiv_verification(
    *,
    sig: dict[str, Any],
    iter_bundle: Path,
    inputs_dir: Path,
    gold_for_verify: Path,
    gate_for_verify: Path,
    gold_module: str,
    gate_module: str,
    deps_for_verify: list[Path],
    timeout_sec: int,
    bound: int,
    ports: list[dict[str, Any]],
    iteration_index: int,
    parent_run_id: str,
    proposal: Any,
    gold_cells_pre: int | None,
    gate_cells_pre: int | None,
    obs: Any,
    verify_sec_fn: Any,
    log_fn: Any = None,
) -> dict[str, Any]:
    """Run yosys equiv verification path (combo + sequential via async2sync).

    Extracted from _orchestrator._emit_iteration_arc_for_proposal lines
    791-949 to keep verification logic independently testable.

    Returns the standard iteration result dict:
    {iteration_index, outcome, outcome_reason, transformation_class,
     claimed_area_delta_pct, bridges_used, property_verdicts,
     gold_cells, gate_cells, measured_delta_pct}.
    """
    import time

    def _vlog(msg: str) -> None:
        if log_fn:
            log_fn(msg)

    from kairos.sec.closed_loop.yosys_equiv import verify_combo_equiv

    yosys_t0 = time.time()
    yeq = verify_combo_equiv(
        gold_path=iter_bundle / sig["gold_sv"],
        gate_path=iter_bundle / "gate.v",
        gold_module=gold_module,
        gate_module=gate_module,
        timeout_sec=timeout_sec,
    )
    elapsed = time.time() - yosys_t0

    bmc_result_data: dict[str, Any] = {
        "iteration_index": iteration_index,
        "parent_run_id": parent_run_id,
        "engine": yeq.method,
        "bound": 0,
        "elapsed_sec": elapsed,
    }
    property_verdicts: dict[str, str] = {
        "combo_equiv": "PROVED" if yeq.proved else ("REFUTED" if yeq.refuted else "INCONCLUSIVE"),
    }

    if yeq.proved:
        result_str = "PASS"
        diag_class = "yosys_combo_equiv"
    elif yeq.refuted:
        result_str = "FAIL"
        diag_class = "yosys_combo_refuted"
    else:
        result_str = "INCONCLUSIVE"
        diag_class = "yosys_combo_inconclusive"

    bmc_result_data["result"] = result_str
    bmc_result_data["detail"] = yeq.detail
    bmc_result_data["diagnostic_class"] = diag_class
    obs.emit("verify_attempt", run_subtype="theorem_proving", payload=bmc_result_data)

    ebmc_confirmatory = "not_run"
    if yeq.proved:
        try:
            ebmc_confirm = verify_sec_fn(
                gold_sv=gold_for_verify,
                gate_v=gate_for_verify,
                gold_module=gold_module,
                gate_module=gate_module,
                ports=ports,
                mode="bmc",
                bound=min(bound, 5),
                clock_port="",
                reset_port="",
                reset_active_low=True,
                timeout_sec=60,
                work_dir=iter_bundle / "_sec_work",
                dep_files=deps_for_verify,
            )
            if ebmc_confirm.proved:
                ebmc_confirmatory = "PROVED"
            elif ebmc_confirm.refuted:
                ebmc_confirmatory = "REFUTED"
            else:
                ebmc_confirmatory = "INCONCLUSIVE"
        except Exception:  # noqa: BLE001
            ebmc_confirmatory = "timeout_or_error"
        property_verdicts["ebmc_confirmatory"] = ebmc_confirmatory
        ebmc_result_mapped = {
            "PROVED": "PASS", "REFUTED": "FAIL",
        }.get(ebmc_confirmatory, "INCONCLUSIVE")
        obs.emit("verify_attempt", run_subtype="theorem_proving", payload={
            "iteration_index": iteration_index,
            "parent_run_id": parent_run_id,
            "engine": "ebmc_bmc_confirmatory",
            "bound": min(bound, 5),
            "result": ebmc_result_mapped,
            "elapsed_sec": round(time.time() - yosys_t0, 2),
            "diagnostic_class": "combo_ebmc_confirmatory",
            "detail": f"EBMC 60s confirmatory on combo block: {ebmc_confirmatory}",
        })

    bridges_used: list[str] = []
    if result_str == "PASS":
        if ebmc_confirmatory == "REFUTED":
            outcome = "errored"
            outcome_reason = "ENGINE DISAGREEMENT: yosys PROVED but EBMC REFUTED — investigate before shipping"
        elif ebmc_confirmatory == "PROVED":
            outcome = "accepted"
            outcome_reason = f"yosys combo equiv proved ({yeq.proven_cells} cells, {yeq.method}) + EBMC PROVED"
        elif yeq.method == "yosys_dual_engine":
            outcome = "accepted"
            ebmc_note = f" + EBMC {ebmc_confirmatory}" if ebmc_confirmatory != "not_run" else ""
            outcome_reason = f"yosys dual-engine proved (equiv + SAT miter){ebmc_note}"
        else:
            outcome = "accepted"
            outcome_reason = (
                f"yosys equiv_induct proved ({yeq.proven_cells} cells, {yeq.method}). "
                f"EBMC confirmatory: {ebmc_confirmatory}."
            )
    elif result_str == "FAIL":
        outcome = "inconclusive"
        outcome_reason = f"yosys combo equiv refuted: {yeq.detail}"
    else:
        outcome = "inconclusive"
        outcome_reason = f"yosys combo equiv inconclusive: {yeq.detail}"

    try:
        from kairos.sec.closed_loop.block_memory import (
            record_refutation as _combo_rec_ref,
            record_success as _combo_rec_succ,
        )
        _combo_gold = str(inputs_dir / sig["gold_sv"]) if sig.get("gold_sv") else ""
        if _combo_gold:
            if outcome == "accepted" and gold_cells_pre and gate_cells_pre:
                _combo_rec_succ(
                    block_path=_combo_gold,
                    transformation_class=proposal.transformation_class.value,
                    measured_delta_pct=round(
                        (gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2
                    ),
                    gold_cells=gold_cells_pre,
                    gate_cells=gate_cells_pre,
                    engine="yosys_equiv",
                    elapsed_seconds=elapsed,
                )
            elif outcome in ("inconclusive",):
                _combo_rec_ref(
                    block_path=_combo_gold,
                    transformation_class=proposal.transformation_class.value,
                    claimed_delta_pct=proposal.claimed_area_delta_pct,
                    refutation_reason=outcome_reason[:500],
                    elapsed_seconds=elapsed,
                )
    except Exception:  # noqa: BLE001
        pass

    return {
        "iteration_index": iteration_index,
        "outcome": outcome,
        "outcome_reason": outcome_reason,
        "transformation_class": proposal.transformation_class.value,
        "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
        "bridges_used": bridges_used,
        "property_verdicts": property_verdicts,
        "gold_cells": gold_cells_pre,
        "gate_cells": gate_cells_pre,
        "measured_delta_pct": (
            round((gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2)
            if gold_cells_pre and gate_cells_pre else None
        ),
    }


def analyze_bmc_failure(
    bmc_result: Any,
    bmc_result_data: dict[str, Any],
    target_module: str,
    log_fn: Any = None,
) -> None:
    """Waveform analysis + LLM explanation on BMC FAIL.

    Extracted from _orchestrator._emit_iteration_arc_for_proposal.
    Mutates bmc_result_data in place with counterexample fields.
    """
    try:
        from kairos.sv.waveform import analyze_from_ebmc_result
        wf = analyze_from_ebmc_result(bmc_result)
        if wf.violations:
            v = wf.violations[0]
            bmc_result_data["first_divergent_signal"] = v.first_divergent_signal
            bmc_result_data["first_divergent_cycle"] = v.first_divergent_cycle
            bmc_result_data["signals_observed_count"] = len(wf.signals_observed)
            bmc_result_data["counterexample_summary"] = wf.format_human_readable()
            if log_fn:
                log_fn(
                    f"  [cex] First divergence: {v.first_divergent_signal} "
                    f"at cycle {v.first_divergent_cycle}"
                )
            try:
                from kairos.sv.counterexample import explain as _explain_cex
                cex_explanation = _explain_cex(
                    ebmc_stdout=getattr(bmc_result, "stdout", "") or "",
                    ebmc_stderr=getattr(bmc_result, "stderr", "") or "",
                    counterexample=str(getattr(bmc_result, "counterexample", "") or ""),
                    spec_context=f"equivalence check: {target_module} gold vs gate",
                    timeout_sec=30,
                )
                if cex_explanation.explanation and cex_explanation.grounded:
                    bmc_result_data["counterexample_explanation"] = cex_explanation.explanation
                    if log_fn:
                        log_fn(f"  [cex] Explanation: {cex_explanation.explanation[:150]}")
            except Exception:  # noqa: BLE001
                pass
    except Exception:  # noqa: BLE001
        pass


__all__ = [
    "check_structural_gate",
    "check_toggle_power_gate",
    "select_engine",
    "classify_bmc_outcome",
    "diagnose_ebmc_outcome",
    "iteration_outcome_from_bmc_result",
    "capture_ebmc_subprocess",
    "run_yosys_equiv_verification",
    "analyze_bmc_failure",
    "prepare_iteration_bundle",
]


def prepare_iteration_bundle(
    *,
    sig: dict[str, Any],
    inputs_dir: Path,
    work_dir: Path,
    iteration_index: int,
    proposed_gate_text: str,
) -> tuple[Path, list[Path]]:
    """Set up a per-iteration bundle directory for verification.

    Creates iter_bundle with signature.json, gold copy, gate with
    deps prepended, and multi-module dep copies. Returns
    (iter_bundle_path, dep_files_for_verification).
    """
    import json as _json
    import shutil

    iter_bundle = work_dir / f"iter_{iteration_index}_bundle"
    iter_bundle.mkdir(parents=True, exist_ok=True)

    iter_sig = dict(sig)
    iter_sig["gate_v"] = "gate.v"
    (iter_bundle / "signature.json").write_text(_json.dumps(iter_sig, indent=2))

    gold_dst = iter_bundle / sig["gold_sv"]
    gold_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy(inputs_dir / sig["gold_sv"], gold_dst)

    gold_elab_key = sig.get("_gold_elab_sv")
    if gold_elab_key:
        gold_elab_dst = iter_bundle / gold_elab_key
        gold_elab_dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(inputs_dir / gold_elab_key, gold_elab_dst)

    gate_text_with_deps = proposed_gate_text
    for dep_rel in sig.get("dep_files") or []:
        dep_path = inputs_dir / dep_rel
        if dep_path.is_file() and dep_path.suffix in (".inc", ".vh", ".svh"):
            gate_text_with_deps = dep_path.read_text() + "\n" + gate_text_with_deps
    (iter_bundle / "gate.v").write_text(gate_text_with_deps)

    dep_files_iter: list[Path] = []
    for dep_rel in sig.get("dep_files") or []:
        src = inputs_dir / dep_rel
        dst = iter_bundle / dep_rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(src, dst)
        dep_files_iter.append(dst)

    if not dep_files_iter and sig.get("_gold_pre_elaborated", False):
        original_deps = sig.get("_original_dep_files") or []
        if not original_deps:
            gold_name = Path(sig["gold_sv"]).name
            inputs_subdir = inputs_dir / "inputs"
            scan_dir = inputs_subdir if inputs_subdir.is_dir() else inputs_dir
            for vf in sorted(scan_dir.glob("*.v")):
                if vf.name != gold_name:
                    original_deps.append(str(vf.relative_to(inputs_dir)))
        for dep_rel in original_deps:
            src = inputs_dir / dep_rel
            if src.is_file():
                dst = iter_bundle / dep_rel
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy(src, dst)
                dep_files_iter.append(dst)

    return iter_bundle, dep_files_iter


def elaborate_for_verification(
    *,
    sig: dict[str, Any],
    iter_bundle: Path,
    dep_files_iter: list[Path],
    gold_for_verify: Path,
    gate_for_verify: Path,
    gold_module: str,
    gate_module: str,
    timeout_sec: int,
) -> dict[str, Any]:
    """Elaborate gold + gate for verification if needed.

    Returns dict with gold_path, gate_path, deps, param_overrides.
    On gate elaboration failure: returns errored=True + error details.
    """
    param_overrides: dict[str, str | int] = {}
    for p in sig.get("parameters", []):
        name = p.get("name")
        if not name:
            continue
        v = p.get("concrete_for_sec")
        if v is None:
            continue
        param_overrides[name] = v

    gold_pre_elaborated = sig.get("_gold_pre_elaborated", False)
    result_gold = gold_for_verify
    result_gate = gate_for_verify
    result_deps: list[Path] | None = dep_files_iter or None

    if dep_files_iter or param_overrides or gold_pre_elaborated:
        from kairos.sec.preprocess import yosys_elaborate_to_verilog

        elab_dir = iter_bundle / "_elab"
        elab_dir.mkdir(parents=True, exist_ok=True)

        if not gold_pre_elaborated:
            gold_elab = yosys_elaborate_to_verilog(
                rtl_path=result_gold,
                top_module=gold_module,
                dep_files=dep_files_iter,
                output_path=elab_dir / "gold_elab.v",
                log_dir=elab_dir,
                timeout_sec=timeout_sec,
                parameter_overrides=param_overrides or None,
            )
            result_gold = Path(gold_elab.elaborated_path)

        try:
            gate_elab = yosys_elaborate_to_verilog(
                rtl_path=result_gate,
                top_module=gate_module,
                dep_files=dep_files_iter,
                output_path=elab_dir / "gate_elab.v",
                log_dir=elab_dir,
                timeout_sec=timeout_sec,
                parameter_overrides=param_overrides or None,
                flatten=False,
            )
            result_gate = Path(gate_elab.elaborated_path)
            result_deps = None
        except Exception as elab_err:  # noqa: BLE001
            from kairos.sec.closed_loop._orchestrator import _sanitize_error_for_customer
            return {
                "errored": True,
                "error_detail": f"Gate elaboration failed: {str(elab_err)[:200]}",
                "error_reason": _sanitize_error_for_customer(elab_err, "gate_elaborate_failed"),
            }

    return {
        "gold_path": result_gold,
        "gate_path": result_gate,
        "deps": result_deps,
        "param_overrides": param_overrides,
    }
