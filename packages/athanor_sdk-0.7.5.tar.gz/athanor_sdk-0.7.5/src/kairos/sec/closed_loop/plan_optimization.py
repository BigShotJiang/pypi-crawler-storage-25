"""ATH-1108: staged optimization curriculum with confidence estimates.

Given a block's signature + analysis, returns a staged plan:
easy optimizations first (high confidence), then harder ones.
Customer's agent picks ambition level, kairos executes.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class OptimizationStage:
    stage: int
    name: str
    transformation_classes: list[str]
    confidence_pct: int
    estimated_area_delta_pct: float
    requires_hints: bool = False
    hint_source: str | None = None
    description: str = ""


@dataclass(frozen=True)
class OptimizationPlan:
    block_name: str
    block_class: str
    total_stages: int
    stages: list[OptimizationStage]
    encoding_detected: str | None = None
    is_combinational: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "block_name": self.block_name,
            "block_class": self.block_class,
            "total_stages": self.total_stages,
            "encoding_detected": self.encoding_detected,
            "is_combinational": self.is_combinational,
            "stages": [
                {
                    "stage": s.stage,
                    "name": s.name,
                    "transformation_classes": s.transformation_classes,
                    "confidence_pct": s.confidence_pct,
                    "estimated_area_delta_pct": s.estimated_area_delta_pct,
                    "requires_hints": s.requires_hints,
                    "hint_source": s.hint_source,
                    "description": s.description,
                }
                for s in self.stages
            ],
        }


_COMBO_STAGES = [
    OptimizationStage(
        stage=1,
        name="constant_propagation",
        transformation_classes=["constant_prop", "dead_logic_removal"],
        confidence_pct=90,
        estimated_area_delta_pct=-5.0,
        description="Remove constant-driven logic and unreachable branches.",
    ),
    OptimizationStage(
        stage=2,
        name="logic_sharing",
        transformation_classes=["xor_sharing", "mux_tree_optimization", "common_subexpr"],
        confidence_pct=75,
        estimated_area_delta_pct=-15.0,
        description="Share common logic across parallel paths.",
    ),
    OptimizationStage(
        stage=3,
        name="arithmetic_restructuring",
        transformation_classes=["adder_tree", "carry_chain_opt", "booth_encoding"],
        confidence_pct=40,
        estimated_area_delta_pct=-25.0,
        requires_hints=True,
        hint_source="analyze_block encoding detection",
        description="Restructure arithmetic operations for area reduction.",
    ),
]

_SEQ_STAGES = [
    OptimizationStage(
        stage=1,
        name="constant_propagation",
        transformation_classes=["constant_prop", "dead_logic_removal", "dead_register_removal"],
        confidence_pct=90,
        estimated_area_delta_pct=-3.0,
        description="Remove unused registers and constant-driven logic.",
    ),
    OptimizationStage(
        stage=2,
        name="encoding_optimization",
        transformation_classes=["onehot_to_binary", "gray_to_binary", "binary_to_onehot"],
        confidence_pct=70,
        estimated_area_delta_pct=-10.0,
        requires_hints=True,
        hint_source="analyze_block encoding detection",
        description="Optimize state/pointer encoding based on detected convention.",
    ),
    OptimizationStage(
        stage=3,
        name="memory_packing",
        transformation_classes=["flop_to_sram", "register_file_merge", "fifo_depth_reduction"],
        confidence_pct=50,
        estimated_area_delta_pct=-20.0,
        requires_hints=True,
        hint_source="analyze_block + formal invariants",
        description="Pack flop-based storage into memory structures.",
    ),
    OptimizationStage(
        stage=4,
        name="datapath_rewrite",
        transformation_classes=["full_module_rewrite", "pipeline_restructuring"],
        confidence_pct=25,
        estimated_area_delta_pct=-35.0,
        requires_hints=True,
        hint_source="manual review recommended",
        description="Major structural rewrite. High reward but lower success rate.",
    ),
]


def plan_optimization(
    signature_path: str | Path | None = None,
    *,
    block_name: str | None = None,
    block_class: str | None = None,
    is_combinational: bool | None = None,
    encoding: str | None = None,
) -> OptimizationPlan:
    """Generate a staged optimization plan for a block.

    Reads signature.json if provided, or accepts explicit parameters.
    Returns stages ordered by confidence (easy first).
    """
    if signature_path is not None:
        import json
        sig = json.loads(Path(signature_path).read_text())
        block_name = block_name or sig.get("target_module", "unknown")
        block_class = block_class or sig.get("block_class", "generic")
        is_combinational = is_combinational if is_combinational is not None else sig.get("is_combinational", False)

    block_name = block_name or "unknown"
    block_class = block_class or "generic"
    is_combinational = is_combinational if is_combinational is not None else False

    if is_combinational:
        stages = list(_COMBO_STAGES)
    else:
        stages = list(_SEQ_STAGES)

    if encoding and any(s.requires_hints for s in stages):
        for i, s in enumerate(stages):
            if s.requires_hints and s.hint_source == "analyze_block encoding detection":
                stages[i] = OptimizationStage(
                    stage=s.stage,
                    name=s.name,
                    transformation_classes=s.transformation_classes,
                    confidence_pct=min(s.confidence_pct + 15, 95),
                    estimated_area_delta_pct=s.estimated_area_delta_pct,
                    requires_hints=False,
                    hint_source=f"auto-detected: {encoding}",
                    description=s.description,
                )

    return OptimizationPlan(
        block_name=block_name,
        block_class=block_class,
        total_stages=len(stages),
        stages=stages,
        encoding_detected=encoding,
        is_combinational=is_combinational,
    )
