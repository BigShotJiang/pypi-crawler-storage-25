"""ATH-1146: timing gate — reject optimizations that break timing.

Area reduction that breaks timing is worse than no optimization.
This module checks timing constraints using OpenSTA (or yosys sta)
BEFORE accepting a proved-equivalent optimization.

The gate runs AFTER equivalence is proved and area reduction is measured.
If timing degrades beyond the threshold, the optimization is rejected
even though it's equivalent and smaller.

Usage (internal — called by the orchestrator):
    from kairos.sec.closed_loop.timing_gate import check_timing
    passed, report = check_timing(gold_path, gate_path, constraints)
"""
from __future__ import annotations

import logging
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from kairos.security.env_allowlist import safe_env_for_yosys

_log = logging.getLogger("kairos.timing_gate")


@dataclass
class TimingResult:
    gold_wns: float | None = None  # worst negative slack (gold)
    gate_wns: float | None = None  # worst negative slack (gate)
    gold_tns: float | None = None  # total negative slack (gold)
    gate_tns: float | None = None  # total negative slack (gate)
    timing_met: bool = True
    degradation_pct: float = 0.0
    error: str | None = None

    @property
    def passed(self) -> bool:
        return self.timing_met and self.error is None

    @property
    def honest_report(self) -> str:
        if self.error:
            return f"Timing check failed: {self.error}"
        if self.gold_wns is None or self.gate_wns is None:
            return "Timing: no data (STA tool not available)"
        status = "MET" if self.timing_met else "VIOLATED"
        return (
            f"Timing {status}: "
            f"gold WNS={self.gold_wns:.3f}ns, gate WNS={self.gate_wns:.3f}ns "
            f"(degradation: {self.degradation_pct:+.1f}%)"
        )


def _run_sta(
    design_path: Path,
    module_name: str,
    clock_period_ns: float = 10.0,
) -> float | None:
    """Run timing analysis via yosys + STA. Returns WNS or None."""
    yosys_bin = shutil.which("yosys")
    if yosys_bin is None:
        return None

    from kairos.security.path_sanitizer import sanitize_yosys_path
    from kairos.security.env_allowlist import validate_verilog_identifier
    sanitize_yosys_path(design_path)
    validate_verilog_identifier(module_name, "module name")

    try:
        r = subprocess.run(
            [yosys_bin, "-p",
             f"read_verilog -sv {design_path}; "
             f"synth -top {module_name}; "
             f"sta"],
            capture_output=True, text=True, timeout=60,
            env=safe_env_for_yosys(),
        )
        for line in r.stdout.splitlines():
            m = re.search(r"WNS\s*[:=]\s*([-\d.]+)", line)
            if m:
                return float(m.group(1))
        return None
    except Exception:  # noqa: BLE001
        return None


def check_timing(
    gold_path: Path,
    gate_path: Path,
    module_name: str,
    *,
    clock_period_ns: float = 10.0,
    max_degradation_pct: float = 5.0,
) -> TimingResult:
    """Check timing constraints on gold vs gate.

    Returns TimingResult with pass/fail + detailed metrics.
    """
    result = TimingResult()

    gold_wns = _run_sta(gold_path, module_name, clock_period_ns)
    result.gold_wns = gold_wns

    if gold_wns is None:
        result.error = "STA tool not available or failed on gold"
        return result

    gate_module = f"{module_name}_gate"
    gate_wns = _run_sta(gate_path, gate_module, clock_period_ns)
    result.gate_wns = gate_wns

    if gate_wns is None:
        result.error = "STA failed on gate"
        return result

    if gold_wns != 0:
        result.degradation_pct = ((gate_wns - gold_wns) / abs(gold_wns)) * 100
    else:
        result.degradation_pct = 0.0

    result.timing_met = result.degradation_pct <= max_degradation_pct

    if not result.timing_met:
        _log.warning(
            "Timing gate REJECTED: %s degraded %.1f%% (threshold: %.1f%%)",
            module_name, result.degradation_pct, max_degradation_pct,
        )

    return result
