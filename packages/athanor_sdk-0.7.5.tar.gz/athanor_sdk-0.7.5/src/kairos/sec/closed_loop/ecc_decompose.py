"""ECC/Hamming XOR-tree decomposition optimizer (ATH-1131).

Deterministic optimization: extract the generator matrix from a
Hamming encoder, compute optimal XOR sub-expression sharing, and
generate the gate RTL directly. No LLM needed for the optimization
itself — the sharing is algebraic.

The LLM proposer struggles with large Hamming encoders because
rewriting the full module mangles port names. This module bypasses
the LLM entirely for ECC blocks and computes the optimal gate.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# ATH-1212a: strip Athanor + customer credentials from yosys subprocess env.
from kairos.security.env_allowlist import safe_env_for_yosys
from kairos.security.path_sanitizer import validate_verilog_identifier


@dataclass(frozen=True)
class XORShareResult:
    """Result of XOR sub-expression analysis."""
    n_original_xors: int
    n_shared_xors: int
    savings_pct: float
    shared_expressions: tuple[tuple[int, ...], ...]


def extract_generator_matrix(gold_sv: str) -> list[int] | None:
    """Extract GENERATOR_MATRIX parameter from Hamming encoder RTL."""
    m = re.search(
        r"parameter\s+GENERATOR_MATRIX\s*=\s*\{([^}]+)\}",
        gold_sv, re.DOTALL,
    )
    if not m:
        return None

    raw = m.group(1)
    rows = []
    for part in re.findall(r"\d+'b([01_]+)", raw):
        bits = part.replace("_", "")
        rows.append(int(bits, 2))
    return rows


def compute_xor_sharing(matrix: list[int], data_width: int) -> XORShareResult:
    """Compute optimal XOR sub-expression sharing across check bits.

    For each pair of check bits, find data_in positions that appear in
    both. These shared XOR results can be computed once and reused.
    """
    n_checks = len(matrix)
    bit_sets: list[set[int]] = []
    for row in matrix:
        bits = set()
        for i in range(data_width):
            if (row >> i) & 1:
                bits.add(i)
        bit_sets.append(bits)

    original_xors = sum(len(s) - 1 for s in bit_sets if len(s) > 1)

    shared: list[tuple[int, ...]] = []
    used_in_sharing: set[int] = set()

    for i in range(n_checks):
        for j in range(i + 1, n_checks):
            common = bit_sets[i] & bit_sets[j]
            if len(common) >= 3:
                key = tuple(sorted(common))
                if key not in shared:
                    shared.append(key)

    shared_xors = 0
    if shared:
        total_saved = sum(len(s) - 1 for s in shared)
        uses = sum(
            sum(1 for s in shared if s_bit.issubset(set(s)))
            for s_bit in bit_sets
        )
        shared_xors = original_xors - len(shared) * 2

    savings = (1 - shared_xors / original_xors) * 100 if original_xors > 0 else 0

    return XORShareResult(
        n_original_xors=original_xors,
        n_shared_xors=max(shared_xors, 0),
        savings_pct=round(savings, 1),
        shared_expressions=tuple(shared),
    )


def generate_optimized_gate(
    gold_sv: str,
    module_name: str,
    gate_module_name: str,
) -> str | None:
    """Generate an area-optimized gate by sharing XOR sub-expressions.

    Returns the gate RTL string, or None if the block is not a
    recognized Hamming encoder pattern.
    """
    matrix = extract_generator_matrix(gold_sv)
    if not matrix:
        return None

    data_w_match = re.search(r"parameter\s+DATA_W\s*=\s*(\d+)", gold_sv)
    chck_w_match = re.search(r"parameter\s+CHCK_W\s*=\s*(\d+)", gold_sv)
    if not data_w_match or not chck_w_match:
        return None

    data_w = int(data_w_match.group(1))
    chck_w = int(chck_w_match.group(1))

    bit_sets: list[list[int]] = []
    for row in matrix:
        bits = []
        for i in range(data_w):
            if (row >> (data_w - 1 - i)) & 1:
                bits.append(i)
        bit_sets.append(bits)

    # Find shared sub-expressions (pairs of bits that appear in 2+ check computations)
    pair_count: dict[tuple[int, int], int] = {}
    for bits in bit_sets:
        for i in range(len(bits)):
            for j in range(i + 1, len(bits)):
                pair = (bits[i], bits[j])
                pair_count[pair] = pair_count.get(pair, 0) + 1

    shared_pairs = {k: v for k, v in pair_count.items() if v >= 2}

    # Extract port declarations from gold (preserve exactly)
    port_block_match = re.search(
        r"(module\s+" + re.escape(module_name) + r".*?endmodule)",
        gold_sv, re.DOTALL,
    )
    if not port_block_match:
        return None

    full_module = port_block_match.group(1)
    # Extract just the module header up to the first line after port closing paren
    header_match = re.search(
        r"(module\s+" + re.escape(module_name) + r".*?\);)",
        full_module, re.DOTALL,
    )
    if not header_match:
        return None

    port_block = header_match.group(1)
    port_block = port_block.replace(f"module {module_name}", f"module {gate_module_name}", 1)

    # Build optimized gate
    lines = [port_block, ""]

    # Shared XOR wires
    shared_wire_idx = 0
    pair_to_wire: dict[tuple[int, int], str] = {}
    for (a, b), count in sorted(shared_pairs.items(), key=lambda x: -x[1]):
        if count >= 2:
            wire_name = f"shared_xor_{shared_wire_idx}"
            lines.append(f"  wire {wire_name} = data_in[{a}] ^ data_in[{b}];")
            pair_to_wire[(a, b)] = wire_name
            shared_wire_idx += 1

    lines.append("")
    lines.append("  assign data_out = data_in;")
    lines.append("")

    # Check bit computations using shared wires where possible
    chck_val_match = re.search(r"parameter\s+CHCK_VAL_FOR_ALL_ZEROS\s*=\s*(\d+'b[01]+)", gold_sv)
    chck_val = chck_val_match.group(1) if chck_val_match else f"{chck_w}'b0"

    lines.append(f"  wire [{chck_w-1}:0] chck_pre_invert;")
    for p in range(chck_w):
        bits = bit_sets[p]
        if not bits:
            lines.append(f"  assign chck_pre_invert[{p}] = 1'b0;")
            continue

        # Build XOR chain using shared sub-expressions where available.
        # Every bit in the original check computation must appear exactly
        # once in the output chain. Shared pairs replace two data_in[]
        # references with one shared_xor wire.
        terms: list[str] = []
        used: set[int] = set()
        for bit in bits:
            if bit in used:
                continue
            matched = False
            for other in bits:
                if other == bit or other in used:
                    continue
                pair = (min(bit, other), max(bit, other))
                if pair in pair_to_wire:
                    terms.append(pair_to_wire[pair])
                    used.add(bit)
                    used.add(other)
                    matched = True
                    break
            if not matched:
                terms.append(f"data_in[{bit}]")
                used.add(bit)
        xor_expr = " ^ ".join(terms)
        lines.append(f"  assign chck_pre_invert[{p}] = {xor_expr};")

    lines.append("")

    # Inversion + overall parity + error injection (preserve from gold)
    force_error_match = re.search(r"parameter\s+FORCE_ERROR_EN\s*=\s*(\d+)", gold_sv)
    force_en = int(force_error_match.group(1)) if force_error_match else 1

    chck_val_bits = "0" * chck_w
    cv_match = re.search(r"parameter\s+CHCK_VAL_FOR_ALL_ZEROS\s*=\s*\d+'b([01]+)", gold_sv)
    if cv_match:
        chck_val_bits = cv_match.group(1).zfill(chck_w)

    lines.append(f"  wire [{chck_w-1}:0] chck_pre_err;")
    for p in range(chck_w - 1):
        bit_val = chck_val_bits[chck_w - 1 - p]
        lines.append(f"  assign chck_pre_err[{p}] = chck_pre_invert[{p}] ^ 1'b{bit_val};")
    last_bit = chck_val_bits[0]
    lines.append(f"  assign chck_pre_err[{chck_w-1}] = chck_pre_invert[{chck_w-1}] ^ 1'b{last_bit} ^ (^chck_pre_err[{chck_w-2}:0]);")

    lines.append("")
    if force_en:
        lines.append("  assign chck_out = chck_pre_err ^ cfg_force_error_NT_;")
    else:
        lines.append("  assign chck_out = chck_pre_err;")

    lines.append("")
    lines.append("endmodule")

    return "\n".join(lines)


def _abc_optimize_block(
    *,
    gold_path: Path,
    target_module: str,
    dep_files: list[Path] | None = None,
    timeout_sec: int = 120,
) -> dict[str, Any] | None:
    """Run ABC resyn2 on a block and verify with SAT miter.

    Returns dict with proved, gold_cells, gate_cells, elapsed_sec,
    gate_path. Returns None if ABC or SAT fails.
    """
    import shutil
    import subprocess
    import tempfile
    import time

    yosys_bin = shutil.which("yosys")
    if yosys_bin is None:
        return None

    t0 = time.time()
    gold = Path(gold_path).resolve()
    inc_dirs: set[str] = set()
    source_deps: list[str] = []
    for d in (dep_files or []):
        dp = Path(d).resolve()
        if dp.suffix in (".inc", ".vh", ".svh"):
            inc_dirs.add(str(dp.parent))
        else:
            source_deps.append(str(dp))
    dep_args = " ".join(source_deps)
    inc_flags = " ".join(f"-I{d}" for d in sorted(inc_dirs))
    inc_prefix = f"{inc_flags} " if inc_flags else ""
    gate_file = Path(tempfile.mktemp(suffix=".v", prefix=f"abc_{target_module}_"))

    abc_script = (
        f"read_verilog -sv {inc_prefix}{dep_args} {gold}; "
        f"proc; opt; techmap; opt; "
        f'abc -script "+strash; ifraig; scorr; dc2; drw; drf; dc2; drw; drf"; '
        f"write_verilog -noattr {gate_file}"
    )
    try:
        r = subprocess.run(
            [yosys_bin, "-p", abc_script],
            capture_output=True, text=True, timeout=timeout_sec,
            env=safe_env_for_yosys(),  # ATH-1212a
        )
        if r.returncode != 0 or not gate_file.is_file():
            return None
    except subprocess.TimeoutExpired:
        return None

    gate_text = gate_file.read_text()
    gate_module = f"{target_module}_gate"
    gate_text = gate_text.replace(f"module {target_module}", f"module {gate_module}", 1)
    gate_file.write_text(gate_text)

    gold_cells = _count_cells(yosys_bin, gold, target_module, dep_args, timeout_sec)
    gate_cells = _count_cells(yosys_bin, gate_file, gate_module, "", timeout_sec)

    if not gold_cells or not gate_cells or gate_cells >= gold_cells:
        gate_file.unlink(missing_ok=True)
        return None

    sat_script = (
        f"read_verilog -sv {dep_args} {gold} {gate_file}; "
        f"proc; opt; techmap; opt; "
        f"miter -equiv {target_module} {gate_module} miter; "
        f"flatten miter; "
        f"sat -verify -prove trigger 0 miter"
    )
    try:
        r = subprocess.run(
            [yosys_bin, "-p", sat_script],
            capture_output=True, text=True, timeout=timeout_sec,
            env=safe_env_for_yosys(),  # ATH-1212a
        )
        proved = "SUCCESS" in (r.stdout + r.stderr)
    except subprocess.TimeoutExpired:
        proved = False

    elapsed = round(time.time() - t0, 2)

    if not proved:
        gate_file.unlink(missing_ok=True)
        return None

    return {
        "proved": True,
        "gold_cells": gold_cells,
        "gate_cells": gate_cells,
        "area_delta_pct": round((gate_cells - gold_cells) / gold_cells * 100, 1),
        "elapsed_sec": elapsed,
        "gate_path": str(gate_file),
    }


def _count_cells(
    yosys_bin: str, path: Path, module: str, dep_args: str, timeout: int,
) -> int | None:
    import subprocess
    try:
        r = subprocess.run(
            [yosys_bin, "-p",
             f"read_verilog -sv {dep_args} {path}; "
             f"proc; opt; synth -top {module}; stat"],
            capture_output=True, text=True, timeout=timeout,
            env=safe_env_for_yosys(),  # ATH-1212a
        )
        m = re.search(r"Number of cells:\s+(\d+)", r.stdout)
        return int(m.group(1)) if m else None
    except Exception:  # noqa: BLE001
        return None


def abc_optimize_any_block(
    *,
    gold_path: Path,
    target_module: str,
    dep_files: list[Path] | None = None,
    timeout_sec: int = 120,
    abc_script: str = "+strash; ifraig; scorr; dc2; drw; drf; dc2; drw; drf",
) -> dict[str, Any] | None:
    """Run ABC optimization on ANY block class, not just ECC.

    ABC's logic synthesis finds optimizations that the LLM proposer
    misses (XOR sharing, redundant logic elimination, algebraic
    rewriting). Works on any combinational or flattened sequential
    block. No LLM cost, no port mangling risk.

    Returns dict with proved, gold_cells, gate_cells, area_delta_pct,
    elapsed_sec, gate_path. None if ABC or SAT fails.
    """
    return _abc_optimize_block(
        gold_path=gold_path,
        target_module=target_module,
        dep_files=dep_files,
        timeout_sec=timeout_sec,
    )


__all__ = [
    "extract_generator_matrix",
    "compute_xor_sharing",
    "generate_optimized_gate",
    "XORShareResult",
    "_abc_optimize_block",
    "abc_optimize_any_block",
]
