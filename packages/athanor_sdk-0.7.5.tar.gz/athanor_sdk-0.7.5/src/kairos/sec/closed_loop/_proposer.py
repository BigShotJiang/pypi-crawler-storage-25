"""LLM-driven RTL area-optimization proposer (ATH-989, A v0).

Given a target RTL block (gold-side SV source) and a transformation
taxonomy, propose candidate area-reducing variants. Each proposal
ships:

* the rewritten RTL source (gate-side, ready to feed into
  :func:`kairos.sec.build_miter` against the gold-side original);
* the transformation class applied (parameterization, structural,
  impl-swap);
* a natural-language rationale tagged for the customer-facing
  certificate (per the v2 silicon-block honest-framing
  discipline);
* a *claimed* area-delta in % (LLM estimate, NOT measured) — the
  customer-facing build-tarball pre-flight gate cross-checks this
  against the post-EBMC verdict before any ship (qa-side
  pre-flight extension flagged in the ATH-988 triage thread).

Today's commit ships the dataclass + taxonomy enumeration only.
LLM call wiring lands in a follow-up commit once the
transformation-taxonomy interface is consumed by sibling modules
(the orchestrator at :mod:`._orchestrator`, ATH-991, W2 work).

Cross-refs
----------

* :issue:`ATH-988` — parent epic, the customer's chief architect ask.
* :issue:`ATH-989` — this child (proposer).
* :mod:`kairos.sec.closed_loop._invariant_gen` — sibling D-spike
  consumed by the orchestrator when proposer output produces
  k-induction INCONCLUSIVE.
"""
from __future__ import annotations

import json
import logging
import re
import time
from dataclasses import dataclass, field

_log = logging.getLogger("kairos.proposer")
from enum import Enum
from pathlib import Path
from typing import Sequence

from kairos.model_presets import DEFAULT_SEC_PROPOSER_MODEL
from kairos.security.path_sanitizer import sanitize_yosys_path, validate_verilog_identifier

_PROPOSER_TOOL: dict = {
    "type": "function",
    "function": {
        "name": "submit_proposals",
        "description": "Submit area-optimization proposals for the target RTL block.",
        "parameters": {
            "type": "object",
            "properties": {
                "proposals": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "transformation_class": {
                                "type": "string",
                                "enum": ["parameterization", "structural", "impl_swap"],
                            },
                            "gate_sv": {"type": "string"},
                            "rationale": {"type": "string"},
                            "transformation_description": {"type": "string"},
                            "claimed_area_delta_pct": {"type": "number"},
                            "target_module": {"type": "string"},
                            "proof_invariants": {
                                "type": "array",
                                "items": {"type": "string"},
                            },
                        },
                        "required": [
                            "transformation_class", "gate_sv", "rationale",
                            "transformation_description", "claimed_area_delta_pct",
                            "target_module",
                        ],
                    },
                },
            },
            "required": ["proposals"],
        },
    },
}


class TransformationClass(str, Enum):
    """Categories of area-optimization transformation the proposer emits.

    The taxonomy is deliberately small for v0; v1 expansions (CDC
    primitives, retiming pragmas, datapath restructuring, etc.) land
    once D-spike validates the LLM-invariant-gen path on the v0
    classes. This is the W1 scope per the ATH-988 triage cadence.
    """

    PARAMETERIZATION = "parameterization"
    """Width/depth parameter changes that preserve the algorithmic
    contract (e.g. trim a count register from 4 bits to 3 when the
    depth is bounded). Equivalence is straightforward to verify
    via BMC + invariant on the bound."""

    STRUCTURAL = "structural"
    """Refactor that preserves cycle-by-cycle behavior — e.g.
    rebalancing combinational logic across pipeline stages,
    de-duplicating parallel logic cones, hoisting a shared
    sub-expression. EBMC k-induction handles this class with the
    state-equality invariant from :issue:`ATH-992` D-spike."""

    IMPL_SWAP = "impl_swap"
    """Implementation swaps that change internal state encoding —
    e.g. memory vs flops for a small storage element, or one-hot
    vs binary state encoding for an FSM. This class is the hard
    case; cross-structure refinement-relation generation
    (:issue:`ATH-992` D-full) is needed when the gold-vs-gate
    state spaces don't admit a flat element-wise correspondence."""


@dataclass(frozen=True)
class TransformationProposal:
    """One LLM-proposed area-reduction transformation on a target RTL block.

    Attributes
    ----------
    transformation_class:
        Which :class:`TransformationClass` the proposal applies.
    gate_sv:
        The proposed gate-side RTL source (full module body), in
        SV or Verilog text. Fed directly to
        :func:`kairos.sec.build_miter` as the gate input against
        the gold-side original.
    rationale:
        Natural-language explanation of the optimization the
        proposer is making. Surfaced in the customer-facing
        certificate.
    claimed_area_delta_pct:
        LLM-estimated area reduction in percent (negative ==
        smaller). NOT measured. The customer-facing build-tarball
        pre-flight gate cross-checks this against post-EBMC
        verdict consistency before any ship (per the qa-side flag
        in the ATH-988 triage thread).
    target_module:
        SV module name being optimized (e.g. ``"fifo_widget"``).
        Lets the orchestrator pick the right miter shape per
        proposal in multi-module flows.
    """

    transformation_class: TransformationClass
    gate_sv: str
    rationale: str
    claimed_area_delta_pct: float
    target_module: str
    proof_invariants: tuple[str, ...] = ()


@dataclass(frozen=True)
class ProposalRunResult:
    """Result of one proposer call: ranked proposals on a target block.

    Attributes
    ----------
    target_module:
        The gold-side SV module the proposer was asked to optimize.
    proposals:
        Ordered list of :class:`TransformationProposal`, ranked
        by claimed_area_delta_pct (most-negative-first =
        biggest-claimed-savings-first). The orchestrator
        (:mod:`._orchestrator`) iterates through these in order
        and stops at the first proposal that closes formal
        equivalence verification.
    halt_reason:
        Why the proposer ended. ``"max_proposals"`` (cap reached),
        ``"no_more_ideas"`` (LLM declined to propose more),
        ``"hard_block"`` (LLM raised a structural concern, e.g.
        \"the gold-side already looks minimal\").
    raw_llm_text:
        Unparsed LLM response text. Captured for the
        sdk_agent_events trace + for post-hoc debugging when a
        parse failure happens.
    """

    target_module: str
    proposals: Sequence[TransformationProposal] = field(default_factory=list)
    halt_reason: str = ""
    halt_reason_class: str = ""
    raw_llm_text: str = ""
    stage_timings: dict[str, float] = field(default_factory=dict)

    @property
    def is_auth_error(self) -> bool:
        return self.halt_reason_class == "auth"

    def best(self) -> TransformationProposal | None:
        """Return the highest-claimed-area-savings proposal, or None if empty."""
        return self.proposals[0] if self.proposals else None


_AUTH_KEYWORDS = ("authenticationerror", "401", "403", "invalid_api_key", "invalid api key")


def _classify_halt_reason_python(error_str: str) -> str:
    """Python implementation of halt_reason classification."""
    if not error_str:
        return ""
    lower = error_str.lower()
    if any(kw in lower for kw in _AUTH_KEYWORDS):
        return "auth"
    if any(kw in lower for kw in ("timeout", "timed out")):
        return "timeout"
    if any(kw in lower for kw in ("rate_limit", "rate-limit", "429")):
        return "rate_limit"
    return ""


try:
    from kairos_halt_reason import classify_halt_reason as _classify_rust  # type: ignore[import-not-found,import-untyped]
    def _classify_halt_reason(error_str: str) -> str:
        return _classify_rust(error_str)
except ImportError:
    _classify_halt_reason = _classify_halt_reason_python


# ── LLM call wiring (ATH-1055 / v2.7 path A per CTO 2026-05-06) ───────
#
# Prompt + parser + propose_transformations() entry point. Companions
# the existing dataclass + taxonomy. Mirrors the ._invariant_gen pattern
# so the closed_loop scaffold uses one LLM client convention.

_PROPOSER_SYSTEM_PROMPT = """\
You are an expert in RTL design and area optimization. You receive a
SystemVerilog gold-reference module and propose candidate
area-optimization transformations.

CRITICAL — SYNTHESIS AWARENESS:
Your optimization must produce a DIFFERENT post-synthesis netlist,
not just different source text. The synthesis tool (yosys) already
performs: constant folding, dead-wire removal, basic CSE, register
merging. If your "optimization" is something yosys would do anyway,
the measured area delta will be 0% and the proposal is wasted.

Target optimizations that change STRUCTURAL DECISIONS the synthesis
tool cannot make on its own:
- Sharing arithmetic units across mutually-exclusive operations
  (e.g. one adder for both ADD and SUB via complement input)
- Reducing comparator/mux width when the full range is unused
- Replacing decode-tree case statements with direct computation
- Merging parallel logic cones that compute similar functions
- Eliminating provably-dead state machine branches
- Narrowing shift operands to log2(width) when only shift-amount
  bits matter

ANALYSIS STEPS (do these mentally before proposing):
1. Read the gold module. Identify the dataflow: what are the main
   computational paths from inputs to outputs?
2. Look for REDUNDANCY: are there two expressions computing similar
   results? Two muxes selecting from overlapping sets?
3. Look for OVER-PROVISIONING: comparators wider than necessary?
   Shift barrels using full-width operands when only a few bits
   matter?
4. Look for DEAD LOGIC: conditions that can never be true given
   the module's parameters? Branches that are structurally
   unreachable?
5. Propose changes that REMOVE the redundancy/over-provisioning.

Transformation classes:

* parameterization: adjust block parameters to switch between equivalent
  implementations. Lowest verification risk.
* structural: change internal structure (redundancy elimination,
  arithmetic sharing, width narrowing, fan-out balancing) without
  changing parameter shape. Medium risk.
* impl_swap: replace block implementation entirely while preserving the
  interface contract (memory vs flops; ripple-carry vs carry-lookahead;
  tree-balanced vs linear adder). Highest risk: requires inductive
  invariants on the state correspondence.

Your output MUST be a single fenced JSON block with this shape:

```json
{
  "proposals": [
    {
      "transformation_class": "parameterization" | "structural" | "impl_swap",
      "transformation_description": "<one short sentence: name the rewrite>",
      "rationale": "<one short paragraph: why this is plausibly area-saving + what risks this carries for SEC>",
      "claimed_area_delta_pct": <float; negative = area saving; e.g. -8.5>,
      "target_module": "<module name from the input>",
      "gate_sv": "<full SystemVerilog body of the optimized impl-side module; same module name + same port list as gold; internal logic is the rewrite. Triple-quoted string in JSON: use \\n line breaks>",
      "proof_invariants": [
        "<bare expression that must hold on the optimized design for your optimization to be correct. Example: 'count <= DEPTH' or 'wr_ptr != rd_ptr || empty'. These invariants will be formally verified by EBMC — if they hold, your optimization is provably correct. Write 1-4 invariants that capture WHY your transformation preserves equivalence.>"
      ]
    }
  ]
}
```

Constraints:

* Propose exactly N candidates where N is given in the user prompt.
* Each candidate must be a DIFFERENT transformation. Don't repeat the
  same transformation under different rationales.
* `claimed_area_delta_pct` is YOUR estimate before any synthesis run.
  Be honest: most area transforms save 5-15%; very few save 20%+.
* `gate_sv` is the full module body. Same `module <name>(...)` header
  + `endmodule` footer. Internal-state registers can change shape;
  the closed-loop verifier will check structural-equivalence under
  k-induction with bridge invariants.
* INTERFACE-PRESERVING (HARD CONSTRAINT, ATH-1055 Path 2 per Aidan
  2026-05-06):
  - Port list byte-identical to gold module's port list. Same names,
    same widths, same directions. Do NOT change a port's width or
    direction; do NOT add or remove ports. The proposer's job is to
    optimize the BODY, not the INTERFACE.
  - Capacity-preserving. If gold is a depth-N FIFO with N entries of
    storage, gate must also store N entries (same depth). Only the
    INTERNAL state representation may change (e.g. flop array vs
    packed memory; one-hot vs binary encoding). Do NOT halve depth
    or re-parameterize capacity.
  - Combinational-output-equivalence. Gate's outputs on every
    (clk, rst_n, push, pop, push_data) input sequence must match gold's
    bit-for-bit (modulo any X-init-aliasing already declared in the
    bundle's signature.json). Do NOT propose transformations that
    change the output behavior at the cycle level.
* CRITICAL — index-encoding consistency on data ports. If you change
  the pointer encoding (one-hot vs binary, depth-N register array vs
  packed memory), every read/write site MUST use the matching
  encoding. The data-output port (e.g. ``dout_y``, ``data_out``) is
  the most common mismatch site in FIFO transformations:

    - One-hot pointer (``4'b0001`` = position 0): output reads
      ``data[bit-set-position]``.
    - Binary pointer (``4'b0001`` = position 1): output reads
      ``data[binary-value]``.

  These differ — same bit pattern selects DIFFERENT entries.
  Failing to align reads -> output mismatch at the cycle a
  push-then-pop happens; the verifier REFUTES on this exact shape.
  Trace through one push-then-pop sequence in your head BEFORE
  emitting the gate body. Confirm the data-output port reads from
  the position the pointer encoding actually addresses. If gold
  uses one-hot and you switch to binary, every read site that
  consumed the one-hot must be re-derived; do NOT assume the
  same bit pattern means the same thing.

* Bias: prefer transformations that preserve the count register and
  externally-observable state but change internal state ENCODING
  (state-encoding swap, internal redundancy elimination, fan-out
  balancing, register-retiming). These are interface-preserving
  structural variants; the closed-loop verifier can discharge them
  under k-induction with bridge invariants on the internal state.
* `gate_sv` MUST be VERILOG-2001 SYNTAX (NOT SystemVerilog). Reason:
  EBMC parses the file as strict Verilog-2001 because the file
  extension is `.v` (not `.sv`). Use `input wire` / `output wire` /
  `output reg` (NOT `input logic` / `output logic`). Use
  `always @(posedge clk or negedge rst_n)` (NOT `always_ff`). Use
  `reg [N:0]` for storage (NOT `logic [N:0]`). Avoid SV-2017 features:
  no packed structs, no `typedef`, no `enum`, no `interface`. Add
  `` `default_nettype none `` at the top of the body if you want
  strict net declaration (matches the gold-reference sibling
  generated by Clash). Verilog-2001 reserved word list applies.
* Output ONLY the fenced JSON. No surrounding prose.
* Fail-closed on this constraint: if any proposal is missing a field,
  the parser drops the entire response and the orchestrator escalates
  to human review.
"""


_FENCED_JSON_RE = re.compile(r"```(?:json)?\s*\n(.*?)\n```", re.DOTALL)


def _extract_datapath_lines(gold_sv: str, sig: dict) -> list[str]:
    """Extract the full data-path read chain for each output port.

    Two-phase extraction:
    1. Find output-port assignment lines (``assign <port> = ...``).
    2. One-hop dependency trace: extract internal wire names from those
       assignments, then find ALL always/always_comb blocks that assign
       to those wires. Preserve the entire block (from ``always`` to
       matching ``end``).

    This ensures the one-hot mux block that computes fifo_dout from
    fifo_data[i] is preserved — not just the final assign fifo_dout_y
    line. The proposer can optimize everything else (pointer arithmetic,
    write enables, full/empty detection) but the read chain stays
    byte-identical to gold.
    """
    # Identify the HARDEST output port — the one that consistently
    # REFUTES. Focus preservation on its dependency chain only.
    # Other output ports already PROVE at baseline (4/5).
    # For FIFO blocks: fifo_dout_y is the data-path output; the
    # rest (full/empty/afull/overrun) are control-path.
    output_ports = {
        p["name"]
        for p in sig.get("ports", [])
        if p.get("direction", "").lower() == "output"
    }
    # Heuristic: data-output ports contain "dout" or "data" in name.
    # Control-output ports contain "full", "empty", "err", "overrun".
    data_ports = {
        p for p in output_ports
        if "dout" in p.lower() or "data" in p.lower()
    }
    if not data_ports:
        data_ports = output_ports  # fallback: preserve all

    lines = gold_sv.splitlines()
    preserved: list[str] = []
    internal_deps: set[str] = set()
    # Phase 1: data-port assignment lines ONLY.
    for line in lines:
        stripped = line.strip()
        for port in data_ports:
            if port in stripped and ("assign" in stripped):
                preserved.append(line.rstrip())
                rhs = stripped.split("=", 1)[-1] if "=" in stripped else ""
                for token in re.split(r"[^a-zA-Z_0-9]+", rhs):
                    if (
                        token
                        and token[0].isalpha()
                        and token not in output_ports
                        and token not in ("begin", "end", "if", "else", "for",
                                          "int", "integer", "DATA_WIDTH")
                    ):
                        internal_deps.add(token)
                break

    if not internal_deps:
        return preserved

    # Phase 2: always blocks that assign to internal deps of data ports.
    in_block = False
    block_depth = 0
    block_lines: list[str] = []
    block_touches_dep = False

    for line in lines:
        stripped = line.strip()
        if not in_block:
            if stripped.startswith(("always_comb", "always @")):
                in_block = True
                block_depth = 0
                block_lines = [line.rstrip()]
                block_touches_dep = False
                if "begin" in stripped:
                    block_depth = 1
                continue
        if in_block:
            block_lines.append(line.rstrip())
            if "begin" in stripped:
                block_depth += 1
            if stripped == "end" or stripped.startswith("end ") or stripped == "end;":
                block_depth -= 1
                if block_depth <= 0:
                    if block_touches_dep:
                        for bl in block_lines:
                            if bl.rstrip() not in preserved:
                                preserved.append(bl.rstrip())
                    in_block = False
                    block_lines = []
            for dep in internal_deps:
                if dep in stripped and ("=" in stripped):
                    block_touches_dep = True

    return preserved


def _inject_gold_datapath(
    gate_sv: str,
    gold_datapath_block: str,
    sig: dict,
) -> str:
    """Replace the gate's data-output read logic with gold's verbatim copy.

    Finds the gate's assign/always block that computes the data-output
    port (fifo_dout_y or similar) and replaces it with the gold's
    version. If the gate doesn't have a recognizable data-output
    section, appends the gold block before endmodule.

    This is the mechanical splice that sidesteps the LLM's inability
    to copy code verbatim. kairos does the injection; the LLM only
    needs to handle control-path optimization.
    """
    data_ports = {
        p["name"]
        for p in sig.get("ports", [])
        if p.get("direction", "").lower() == "output"
        and ("dout" in p["name"].lower() or "data" in p["name"].lower())
    }
    if not data_ports:
        return gate_sv

    lines = gate_sv.splitlines(keepends=True)
    # Find the gate's data-output assign line and its preceding
    # always block. Replace from the always_comb/always @(*) that
    # feeds the data output through the assign line.
    inject_start = -1
    inject_end = -1
    for idx, line in enumerate(lines):
        stripped = line.strip()
        for port in data_ports:
            if port in stripped and "assign" in stripped:
                inject_end = idx + 1
                # Walk backward to find the always block start.
                for back in range(idx - 1, -1, -1):
                    back_stripped = lines[back].strip()
                    if back_stripped.startswith(("always_comb", "always @")):
                        inject_start = back
                        break
                break
        if inject_end > 0:
            break

    if inject_start >= 0 and inject_end > inject_start:
        # Replace gate's data-path section with gold's.
        new_lines = (
            lines[:inject_start]
            + [gold_datapath_block + "\n"]
            + lines[inject_end:]
        )
        return "".join(new_lines)

    # Fallback: couldn't find the section. Insert before endmodule.
    for idx in range(len(lines) - 1, -1, -1):
        if lines[idx].strip().startswith("endmodule"):
            new_lines = (
                lines[:idx]
                + ["\n" + gold_datapath_block + "\n"]
                + lines[idx:]
            )
            return "".join(new_lines)

    return gate_sv


def _validate_datapath_preserved(
    gate_sv: str,
    preserve_lines: list[str],
) -> list[str]:
    """Check that each preserved data-path line appears in gate_sv.

    Uses whitespace-normalized comparison: both the preserved line
    and every gate line are stripped + collapsed to single spaces
    before matching. This tolerates the proposer's minor formatting
    differences (``always_comb`` vs ``always @(*)``, extra/fewer
    spaces, ``logic`` vs ``reg``) while still catching semantic
    changes (different signal names, different operators).

    Returns list of MISSING lines. Empty list = all preserved.
    """
    def _normalize(s: str) -> str:
        return re.sub(r"\s+", " ", s.strip())

    gate_normalized = {_normalize(l) for l in gate_sv.splitlines()}
    missing: list[str] = []
    for line in preserve_lines:
        norm = _normalize(line)
        if not norm:
            continue
        if norm not in gate_normalized:
            missing.append(line.rstrip())
    return missing


def _build_proposer_user_prompt(
    gold_sv: str,
    sig: dict,
    target_module: str,
    max_proposals: int,
    synth_report: str | None = None,
    prior_optimized_gate: str | None = None,
    prior_measured_delta_pct: float | None = None,
    toggle_activity: list[dict] | None = None,
) -> str:
    """Format the user message: gold body + signature + synth baseline + prior result + ask."""
    parts = [
        f"Target module: `{target_module}`\n"
        f"Number of proposals requested: {max_proposals}\n",
        f"\n## Module signature (from signature.json)\n"
        f"```json\n{json.dumps(sig, indent=2)}\n```\n",
        f"\n## Gold-reference SystemVerilog source (ORIGINAL — correctness anchor)\n"
        f"```systemverilog\n{gold_sv}\n```\n",
    ]
    if prior_optimized_gate:
        delta_str = f"{prior_measured_delta_pct:+.1f}%" if prior_measured_delta_pct is not None else "unknown"
        parts.append(
            f"\n## Prior optimization result (CONTINUE from this)\n"
            f"A previous optimization pass already achieved {delta_str} "
            f"area reduction. The optimized gate is shown below. Your job: "
            f"find ADDITIONAL savings the prior pass missed. The prior "
            f"gate may have already shared arithmetic units or narrowed "
            f"comparators — look for DIFFERENT optimization opportunities "
            f"(dead logic, redundant muxes, further sharing, width "
            f"reduction on signals the prior pass didn't touch).\n"
            f"```systemverilog\n{prior_optimized_gate}\n```\n"
        )
    if synth_report:
        parts.append(
            f"\n## Synthesis baseline (yosys synth_stat on gold)\n"
            f"```\n{synth_report}\n```\n"
            f"This is what the design looks like AFTER synthesis. Your "
            f"optimization must reduce one or more of these cell counts. "
            f"If your change only affects source-level style but produces "
            f"the same cell counts, it is wasted — target structural "
            f"changes the synthesizer cannot discover on its own.\n"
        )
    # Port-preservation hard constraint: inject the exact module header
    # so the proposer copies it verbatim instead of rewriting ports.
    header_match = re.search(
        r"(module\s+" + re.escape(target_module) + r".*?\);)",
        gold_sv, re.DOTALL,
    )
    if header_match:
        gate_module = sig.get("gate_module", f"{target_module}_gate")
        gate_header = header_match.group(1).replace(
            f"module {target_module}", f"module {gate_module}", 1,
        )
        parts.append(
            f"\n## MANDATORY: Copy this module header EXACTLY into your gate\n"
            f"```systemverilog\n{gate_header}\n```\n"
            f"Do NOT rename, remove, or reorder any port. The verification "
            f"miter binds gold and gate by port name.\n"
        )

    if toggle_activity:
        top_togglers = toggle_activity[:20]
        lines = [f"| {t['signal']} | {t['width']} | {t['toggles_per_cycle']:.2f} |"
                 for t in top_togglers]
        parts.append(
            f"\n## Switching activity (verilator, {toggle_activity[0].get('cycles', 1000)} cycles)\n"
            f"Signals ranked by toggles/cycle (highest first). Target "
            f"high-toggle signals for operand isolation, bus gating, or "
            f"conditional computation skip — reducing their switching "
            f"saves dynamic power without changing functional behavior.\n\n"
            f"| Signal | Width | Toggles/Cycle |\n"
            f"|--------|-------|---------------|\n"
            + "\n".join(lines) + "\n"
        )

    parts.append(
        f"\nNow propose {max_proposals} distinct area-optimization "
        f"transformations on this module. Output ONLY the fenced JSON "
        f"block per the system prompt's spec."
    )
    return "\n".join(parts)


def _parse_proposer_response(
    text: str,
    target_module: str,
) -> tuple[list[TransformationProposal], str]:
    """Parse LLM JSON output into list[TransformationProposal].

    Fail-closed: any malformed proposal drops the entire response and
    returns ([], halt_reason) so the orchestrator escalates to human
    review per `feedback_no_vacuous_proves_multi_layer.md`. Don't
    silently fall through to a partial list — partial = ambiguous
    failure mode the customer would mistake for success.

    Returns (proposals, halt_reason). On success, halt_reason="ok".
    """
    m = _FENCED_JSON_RE.search(text)
    json_text = m.group(1).strip() if m else None

    # Fallback: extract first { to last } if no fenced block found
    if json_text is None:
        brace_start = text.find("{")
        brace_end = text.rfind("}")
        if brace_start >= 0 and brace_end > brace_start:
            json_text = text[brace_start:brace_end + 1]

    if json_text is None:
        return [], "parse_failure: no fenced JSON block and no bare JSON object found"
    try:
        obj = json.loads(json_text)
    except json.JSONDecodeError as e:
        return [], f"parse_failure: JSON decode {e}"
    raw = obj.get("proposals")
    if not isinstance(raw, list) or not raw:
        return [], "parse_failure: no proposals list"

    parsed: list[TransformationProposal] = []
    valid_classes = {c.value for c in TransformationClass}
    for i, p in enumerate(raw):
        if not isinstance(p, dict):
            return [], f"parse_failure: proposal {i} not an object"
        tc = p.get("transformation_class", "")
        if tc not in valid_classes:
            return [], (
                f"parse_failure: proposal {i} transformation_class "
                f"{tc!r} not in {sorted(valid_classes)}"
            )
        gate_sv = p.get("gate_sv", "")
        if not isinstance(gate_sv, str) or not gate_sv.strip():
            return [], f"parse_failure: proposal {i} missing/empty gate_sv"
        rationale = p.get("rationale", "")
        if not isinstance(rationale, str) or not rationale.strip():
            return [], f"parse_failure: proposal {i} missing/empty rationale"
        try:
            claimed = float(p.get("claimed_area_delta_pct"))
        except (TypeError, ValueError):
            return [], (
                f"parse_failure: proposal {i} claimed_area_delta_pct "
                f"not a number"
            )
        # target_module from LLM should match the asked module; if
        # mismatch, flag — proposer is reasoning about a different module
        llm_target = p.get("target_module", target_module)
        valid_names = {target_module, f"{target_module}_gate"}
        if llm_target not in valid_names:
            return [], (
                f"parse_failure: proposal {i} target_module "
                f"{llm_target!r} != asked {target_module!r}"
            )
        description = p.get("transformation_description", "")
        if not isinstance(description, str) or not description.strip():
            return [], (
                f"parse_failure: proposal {i} missing/empty "
                f"transformation_description"
            )
        # Extract proof_invariants (optional — old prompts don't emit them)
        raw_invariants = p.get("proof_invariants", [])
        if isinstance(raw_invariants, list):
            proof_inv = tuple(str(inv) for inv in raw_invariants if isinstance(inv, str) and inv.strip())
        else:
            proof_inv = ()
        parsed.append(
            TransformationProposal(
                transformation_class=TransformationClass(tc),
                gate_sv=gate_sv,
                rationale=f"{description}\n\n{rationale}",
                claimed_area_delta_pct=claimed,
                target_module=target_module,
                proof_invariants=proof_inv,
            ),
        )
    parsed.sort(key=lambda p: p.claimed_area_delta_pct)
    return parsed, "ok"


def _reasoning_model_timeout(model: str, default: int) -> int:
    """Bump timeout for reasoning models that use internal chain-of-thought."""
    reasoning_prefixes = ("azure/gpt-5", "azure/o1", "azure/o3", "openai/o1", "openai/o3")
    if any(model.startswith(p) for p in reasoning_prefixes):
        return max(default, 360)
    return default


def propose_transformations(
    bundle_path: Path,
    target_module: str,
    *,
    model: str = DEFAULT_SEC_PROPOSER_MODEL,
    max_proposals: int = 3,
    timeout_sec: int = 120,
    proposer_mode: str = "full",
    toggle_activity: list[dict] | None = None,
    prior_attempts: list[dict] | None = None,
) -> ProposalRunResult:
    """Drive one LLM proposer call on a target RTL block.

    Reads the bundle's ``signature.json`` and ``<gold_sv>`` body, asks
    the LLM for ``max_proposals`` candidate area-optimization
    transformations across the :class:`TransformationClass` taxonomy,
    parses the JSON response into :class:`TransformationProposal`
    objects, and returns them ranked by ``claimed_area_delta_pct``
    (most-negative-first).

    Parameters
    ----------
    bundle_path:
        Path to the SEC bundle directory (must contain
        ``signature.json`` + the file referenced by ``signature.gold_sv``).
    target_module:
        The gold-side SV module name to optimize (e.g. ``"fifo_widget"``).
    model:
        Model id for the LLM proposer. Default ``anthropic/claude-opus-4-6``;
        v2.7 D-spike uses real LLM calls per Aidan 2026-05-06 directive.
    max_proposals:
        Number of distinct candidates to ask for. Default 3 per
        :issue:`ATH-989` deliverable 1.
    timeout_sec:
        Per-LLM-call timeout. Default 120 (proposer responses tend to be
        longer than invariant-gen because they include full SV bodies).

    Returns
    -------
    :class:`ProposalRunResult`
        ``proposals`` ordered by claimed area savings; ``halt_reason``
        ``"ok"`` on success or a parse-failure string. ``raw_llm_text``
        captures the full LLM response for sdk_agent_events trace +
        post-hoc debugging.

    Notes
    -----

    Fail-closed parser per ``feedback_no_vacuous_proves_multi_layer.md``
    discipline: any malformed proposal drops the entire response. The
    customer-block-certificate orchestrator escalates to human review on
    ``halt_reason != "ok"`` rather than silently shipping partial data.
    """
    from kairos.sec.closed_loop._session_guard import require_active_session
    require_active_session("propose_transformations")
    timeout_sec = _reasoning_model_timeout(model, timeout_sec)
    from kairos.model_client._backoff import call_with_backoff

    _t_start = time.monotonic()
    _timings: dict[str, float] = {}

    bundle = Path(bundle_path)
    sig = json.loads((bundle / "signature.json").read_text())
    from kairos.rtl_sanitize import strip_rtl_comments
    gold_sv = strip_rtl_comments((bundle / sig["gold_sv"]).read_text())

    # Generate synthesis baseline for the proposer — shows the LLM
    # exactly what cell types exist post-synthesis so it targets
    # structural changes that reduce real cell counts.
    synth_report = None
    try:
        import subprocess as _sp
        validate_verilog_identifier(target_module, "target_module")
        gold_path = bundle / sig["gold_sv"]
        real_bundle = bundle.resolve()
        if not gold_path.resolve().is_relative_to(real_bundle):
            raise ValueError(f"gold_sv escapes bundle: {sig['gold_sv']}")
        sanitize_yosys_path(gold_path)
        dep_reads = []
        inc_dirs: set[str] = set()
        for d in sig.get("dep_files") or []:
            dp = bundle / d
            if not dp.resolve().is_relative_to(real_bundle):
                _log.warning("dep_file escapes bundle, skipping: %s", d)
                continue
            sanitize_yosys_path(dp)
            if dp.suffix in (".inc", ".vh", ".svh"):
                inc_dirs.add(str(dp.parent))
            else:
                dep_reads.append(str(dp))
        script_lines = []
        for inc in sorted(inc_dirs):
            script_lines.append(f"verilog_defaults -add -I{inc}")
        for dep in dep_reads:
            script_lines.append(f"read_verilog -sv -formal {dep}")
        script_lines.append(f"read_verilog -sv -formal {gold_path}")
        script_lines.append(f"hierarchy -check -top {target_module}")
        script_lines.append(f"proc; opt; flatten; opt; synth -top {target_module}; stat")
        script_path = bundle / ".kairos_synth_baseline.ys"
        script_path.write_text("\n".join(script_lines))
        r = _sp.run(["yosys", "-s", str(script_path)], capture_output=True, text=True, timeout=30)
        script_path.unlink(missing_ok=True)
        m = re.search(r"(Number of wires:.*?)(?:\n\n|\Z)", r.stdout, re.DOTALL)
        if m:
            synth_report = m.group(1).strip()
    except Exception as _synth_err:  # noqa: BLE001
        _log.warning("synth baseline failed: %s", _synth_err)
    _timings["synth_ms"] = round((time.monotonic() - _t_start) * 1000, 1)

    _t_llm = time.monotonic()
    user_prompt = _build_proposer_user_prompt(
        gold_sv=gold_sv,
        sig=sig,
        target_module=target_module,
        max_proposals=max_proposals,
        synth_report=synth_report,
        toggle_activity=toggle_activity,
    )

    # ATH-1107 proposer mode selection.
    # Dynamic prompt composition — adapts to the block class, synthesis
    # baseline, pattern invariants, and prior attempt feedback.
    try:
        from kairos.sec.closed_loop.prompt_composer import compose_system_prompt
        system_prompt = compose_system_prompt(
            gold_sv=gold_sv,
            sig=sig,
            synth_report=synth_report,
            prior_attempts=prior_attempts,
        )
    except Exception as _prompt_err:  # noqa: BLE001
        _log.warning("compose_system_prompt failed: %s", _prompt_err)
        try:
            from kairos.sec.closed_loop.prompts import load_prompt
            system_prompt = load_prompt("proposer_system")
        except (FileNotFoundError, ImportError):
            system_prompt = _PROPOSER_SYSTEM_PROMPT
    if proposer_mode == "diff":
        from kairos.sec.closed_loop.diff_proposer import (
            DIFF_MODE_SYSTEM_ADDENDUM,
        )
        system_prompt = system_prompt + DIFF_MODE_SYSTEM_ADDENDUM
    elif proposer_mode == "preserve_datapath":
        # Extract output-port assignment lines from gold as the
        # "data-path lines to preserve verbatim." These are the
        # lines the proposer MUST NOT rewrite — they go into the
        # system prompt as a hard constraint.
        preserve_lines = _extract_datapath_lines(gold_sv, sig)
        if preserve_lines:
            block = (
                "\n\n## CRITICAL — DATA-PATH PRESERVATION + ENCODING LOCK\n\n"
                "TWO HARD CONSTRAINTS:\n\n"
                "1. PRESERVE DATA-PATH: The following lines from the gold "
                "module are DATA-PATH output logic. Copy them CHARACTER-FOR-"
                "CHARACTER into your gate_sv. Do NOT modify, rearrange, "
                "paraphrase, or rewrite these lines:\n\n"
                "```\n" + "\n".join(preserve_lines) + "\n```\n\n"
                "2. ENCODING LOCK: Do NOT change the pointer encoding. If "
                "gold uses one-hot pointers (FIFO_DEPTH-wide vectors with "
                "exactly one bit set), your gate MUST also use one-hot "
                "pointers. Do NOT replace one-hot with binary counters — "
                "that would require rewriting the data-path read mux above, "
                "violating constraint 1. Optimize WITHIN the existing "
                "encoding: dead-logic removal, constant propagation, "
                "comparison narrowing, common-subexpression sharing, "
                "redundant guard removal. These are high-value "
                "optimizations that reduce area WITHOUT changing the "
                "pointer/memory architecture.\n"
            )
            system_prompt = system_prompt + block

    # Per Aidan 2026-05-06 directive: backoff on Azure overload. Pure
    # backoff retry on the primary model by default; customers can
    # opt into multi-provider fallback via KAIROS_LLM_FALLBACK_MODELS
    # env var (comma-separated model ids). Default no-fallback shape
    # is customer-portable — single-provider customers get clean
    # backoff without the SDK assuming gemini/kimi/etc. keys exist.
    # ATH-1117: subagent-as-proposer — route through local Claude CLI
    # instead of Azure API when model starts with "subagent/"
    from kairos.model_client.subagent_proposer import is_subagent_model
    if is_subagent_model(model):
        from kairos.model_client.subagent_proposer import call_subagent_proposer
        try:
            raw_text = call_subagent_proposer(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                timeout_sec=timeout_sec,
            )
        except Exception as e:  # noqa: BLE001
            _timings["llm_call_ms"] = round((time.monotonic() - _t_llm) * 1000, 1)
            _timings["total_ms"] = round((time.monotonic() - _t_start) * 1000, 1)
            err_str = f"subagent_error: {e}"
            return ProposalRunResult(
                target_module=target_module,
                proposals=[],
                halt_reason=err_str,
                halt_reason_class=_classify_halt_reason(err_str),
                raw_llm_text="",
                stage_timings=_timings,
            )

        class _SubagentResponse:
            content = raw_text
            error = None
        response = _SubagentResponse()
    else:
        response = call_with_backoff(
            primary_model=model,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            tools=[_PROPOSER_TOOL],
            timeout_sec=timeout_sec,
        )
        try:
            from kairos.observe import _CURRENT_CONTEXT
            ctx = _CURRENT_CONTEXT.get(None)
            if ctx is not None and hasattr(response, "prompt_tokens"):
                ctx.accumulate_tokens(
                    response.prompt_tokens or 0,
                    response.completion_tokens or 0,
                )
        except Exception as _token_err:  # noqa: BLE001
            _log.warning("token accumulation failed: %s", _token_err)
    _timings["llm_call_ms"] = round((time.monotonic() - _t_llm) * 1000, 1)

    tool_calls = getattr(response, 'tool_calls', None) or []
    if response.error or (not response.content and not tool_calls):
        _timings["total_ms"] = round((time.monotonic() - _t_start) * 1000, 1)
        err_str = f"llm_error: {response.error or 'empty response'}"
        return ProposalRunResult(
            target_module=target_module,
            proposals=[],
            halt_reason=err_str,
            halt_reason_class=_classify_halt_reason(err_str),
            raw_llm_text=response.content or "",
            stage_timings=_timings,
        )

    _t_parse = time.monotonic()

    # ATH-1150: extract from tool_use response if available
    proposals = []
    halt_reason = "ok"
    if tool_calls:
        for tc in tool_calls:
            if tc.get("name") == "submit_proposals":
                args = tc.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError as e:
                        _log.warning("tool_call arguments parse failed: %s", e)
                        break
                proposals, halt_reason = _parse_proposer_response(
                    json.dumps(args), target_module,
                )
                break

    if not proposals:
        proposals, halt_reason = _parse_proposer_response(
            response.content or "", target_module,
    )

    # Retry once with format reminder on parse failure
    if not proposals and "parse_failure" in halt_reason:
        retry_prompt = (
            "Your previous response could not be parsed as JSON. "
            "Respond ONLY with a JSON object in a ```json code fence. "
            "No prose before or after. The JSON must have a "
            '"proposals" array. Example:\n'
            "```json\n"
            '{"proposals": [{"transformation_class": "structural", '
            '"gate_sv": "...", "rationale": "...", '
            '"claimed_area_delta_pct": -10.0, '
            f'"target_module": "{target_module}"}}'
            "]}\n```"
        )
        if not is_subagent_model(model):
            retry_response = call_with_backoff(
                primary_model=model,
                system_prompt=system_prompt,
                user_prompt=user_prompt + "\n\n" + retry_prompt,
                tools=[_PROPOSER_TOOL],
                timeout_sec=timeout_sec,
            )
            if retry_response.content and not retry_response.error:
                proposals, halt_reason = _parse_proposer_response(
                    retry_response.content, target_module,
                )

    # ATH-1107 diff-mode post-processing: if any proposal has
    # gate_sv == "DIFF_MODE", extract the diff from the raw LLM
    # response + apply it to gold_sv to produce the actual gate body.
    if proposer_mode == "diff" and proposals:
        from kairos.sec.closed_loop.diff_proposer import (
            apply_diff,
            extract_diff_from_response,
        )
        diff_text = extract_diff_from_response(response.content)
        if diff_text is not None:
            try:
                patched = apply_diff(gold_sv, diff_text)
                for i, p in enumerate(proposals):
                    if p.gate_sv == "DIFF_MODE" or not p.gate_sv.strip():
                        proposals[i] = TransformationProposal(
                            transformation_class=p.transformation_class,
                            gate_sv=patched,
                            rationale=p.rationale,
                            claimed_area_delta_pct=p.claimed_area_delta_pct,
                            target_module=p.target_module,
                            proof_invariants=p.proof_invariants,
                        )
            except Exception as e:  # noqa: BLE001
                # Diff parse/apply failed — fall back to whatever
                # gate_sv the proposer emitted (may be "DIFF_MODE"
                # literal, which the orchestrator will catch as an
                # elaboration failure and retry).
                halt_reason = f"diff_apply_fallback: {type(e).__name__}: {str(e)[:200]}"

    # ATH-1107 preserve_datapath: instead of REJECTING proposals that
    # don't preserve data-path lines, INJECT the gold's data-path
    # block into the proposer's gate body. The LLM can't reliably
    # copy code verbatim, but kairos can mechanically splice gold's
    # read-mux into the proposer's output. Result: proposer's
    # control-path optimizations + gold's data-path by identity.
    if proposer_mode == "preserve_datapath" and proposals:
        preserve_lines = _extract_datapath_lines(gold_sv, sig)
        if preserve_lines:
            gold_block = "\n".join(preserve_lines)
            for i, p in enumerate(proposals):
                patched = _inject_gold_datapath(p.gate_sv, gold_block, sig)
                if patched != p.gate_sv:
                    proposals[i] = TransformationProposal(
                        transformation_class=p.transformation_class,
                        gate_sv=patched,
                        rationale=p.rationale,
                        claimed_area_delta_pct=p.claimed_area_delta_pct,
                        target_module=p.target_module,
                        proof_invariants=p.proof_invariants,
                    )

    _timings["parse_ms"] = round((time.monotonic() - _t_parse) * 1000, 1)
    _timings["total_ms"] = round((time.monotonic() - _t_start) * 1000, 1)
    return ProposalRunResult(
        target_module=target_module,
        proposals=proposals,
        halt_reason=halt_reason,
        halt_reason_class=_classify_halt_reason(halt_reason),
        raw_llm_text=response.content,
        stage_timings=_timings,
    )
