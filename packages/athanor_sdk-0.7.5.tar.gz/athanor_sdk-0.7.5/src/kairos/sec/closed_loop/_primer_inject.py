r"""ATH-1087 follow-up — formal_invariants_primer injection (procedural assume).

Bypasses a yosys-EBMC SVA-clocking-syntax grammar mismatch surfaced
during a 2026-05-07 fire diagnostic. yosys 0.44 rejects the SVA
clocked-property form (concurrent-assertion clock + disable-iff
guard) during ``read_verilog -sv -formal``. The procedural form
(an always-block with an inline ``assume(...)`` call) parses cleanly
through both yosys and EBMC and is the wire path this module emits.

This module renders ``signature.formal_invariants_primer`` entries
(structured ``{name, kind, expr}`` form per Gil Stoler 2026-05-04
hand-written invariants on AP_REG_FIFO_US) into procedural
``assume(...)`` blocks, injects into a copy of the gold-side RTL, and
returns the path. Caller (orchestrator) uses the injected gold as the
gold input to verify_sec; the assumes constrain the input space EBMC
explores during the equivalence miter check.

Layer A vs Layer B (per ATH-1079 delta 2 render-contract pin):

* Layer A: ``signature.formal_invariants_primer`` — hand-written or
  signature_gen-extracted invariants. Treated as TRUE (per the customer's engineer
  2026-05-07 mining-vs-bug-finding clarification).
* Layer B: LLM-mined invariants via :mod:`mine_assumptions`. Pass
  through EBMC Mode 1 verifier before joining the assume set.

This module ships Layer A. Layer B's grammar bridge is a separate
follow-up (ATH-1094 territory).

## Public API

* :func:`render_primer_to_procedural_assume_block` — turn one primer
  entry into a procedural ``always @(*) ... assume(...)`` block.
* :func:`inject_primer_assumes_into_gold` — load primer from
  signature.json, render each entry, inject into a copy of gold,
  return path to injected gold.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any


def render_primer_to_procedural_assume_block(
    *,
    name: str,
    kind: str,
    expr: str,
    reset_port: str = "reset_n",
    reset_active_low: bool = True,
) -> str | None:
    """Render one primer entry into a procedural ``assume(...)`` block.

    Returns:
        The block as a string, or ``None`` if the kind is unsupported.

    Kinds:
        ``ASSERT_ALWAYS``: invariant always holds → ``assume(<expr>)``
        ``ASSERT_NEVER``: condition never holds → ``assume(!(<expr>))``

    The reset-guard pattern (``if (reset_n) assume(...)``) suppresses
    the assume during reset state so reset transients don't trigger
    spurious unsat constraints.
    """
    reset_guard = (
        reset_port if reset_active_low else f"!{reset_port}"
    )
    if kind == "ASSERT_ALWAYS":
        body = f"assume ({expr});"
    elif kind == "ASSERT_NEVER":
        body = f"assume (!({expr}));"
    else:
        return None
    return (
        f"\n   // [primer-inject ATH-1087 Layer A] {name}\n"
        f"   always @(*) begin\n"
        f"     if ({reset_guard}) {body}\n"
        f"   end\n"
    )


def inject_primer_assumes_into_gold(
    *,
    gold_path: Path | str,
    target_module: str,
    primer_entries: list[dict[str, Any]],
    reset_port: str = "reset_n",
    reset_active_low: bool = True,
    output_path: Path | str | None = None,
) -> Path:
    """Read ``gold_path`` text, inject each renderable primer entry as
    a procedural ``assume(...)`` block before the target module's
    ``endmodule``, write to ``output_path`` (defaults to
    ``<gold>.with_primer.v`` next to the gold), return the output path.

    Renderable entries are those with ``kind`` in ``{"ASSERT_ALWAYS",
    "ASSERT_NEVER"}``. Other kinds are silently skipped (caller can
    inspect the count via the file size delta).

    The injection point is the FIRST ``endmodule`` after the target
    module's ``module`` declaration. If no such point is found
    (target module not present in the file), the gold text is written
    unchanged — caller should treat as a no-op.

    Per the yosys-EBMC SVA grammar mismatch surfaced 2026-05-07 (Phase
    1 re-fire diagnostic), the procedural ``always @(*) ... assume()``
    form parses CLEAN through both yosys ``read_verilog -sv -formal``
    and EBMC's parser, unlike the SVA ``assert property (@(posedge
    clk) ...)`` form mining-LLM emits.
    """
    gold = Path(gold_path).resolve()
    if not gold.is_file():
        raise FileNotFoundError(f"gold_path not found: {gold}")
    if output_path is None:
        out = gold.with_name(f"{gold.stem}.with_primer.v")
    else:
        out = Path(output_path).resolve()
        out.parent.mkdir(parents=True, exist_ok=True)

    text = gold.read_text()

    blocks: list[str] = []
    for entry in primer_entries:
        block = render_primer_to_procedural_assume_block(
            name=str(entry.get("name", "anon")),
            kind=str(entry.get("kind", "")),
            expr=str(entry.get("expr", "")),
            reset_port=reset_port,
            reset_active_low=reset_active_low,
        )
        if block is not None:
            blocks.append(block)

    if not blocks:
        out.write_text(text)
        return out

    combined = (
        "\n   // [primer-inject ATH-1087 Layer A] "
        f"{len(blocks)} primer assumes from signature.formal_invariants_primer\n"
        + "".join(blocks)
    )

    mod_pat = re.compile(
        rf"(\bmodule\s+{re.escape(target_module)}\b.*?)(\bendmodule\b)",
        re.DOTALL,
    )
    m = mod_pat.search(text)
    if m is None:
        out.write_text(text)
        return out

    new_text = text.replace(
        m.group(2),
        combined + m.group(2),
        1,
    )
    out.write_text(new_text)
    return out


__all__ = [
    "render_primer_to_procedural_assume_block",
    "inject_primer_assumes_into_gold",
]
