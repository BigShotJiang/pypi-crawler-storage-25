"""ATH-1111 — multi-verifier gate before PROVED verdict.

No single-engine shortcut. The cert says PROVED only when ALL
available verification layers independently confirm equivalence.

For combo blocks: EBMC BMC + yosys equiv (2 engines minimum).
For sequential blocks: EBMC BMC + EBMC k-induction + yosys equiv (3 engines).

Each engine's verdict is captured independently. The aggregate
verdict is the WEAKEST across all engines.

ATH-1462 A1: per-property pipeline parallelism. When the miter has
multiple SVA properties, each property runs through its own
verification pipeline on a separate process. The escalation chain
(BMC -> k-induction) stays sequential within each property.

## Public API

* :func:`verify_with_all_engines` — run all applicable engines.
* :func:`verify_properties_parallel` — per-property parallelism.
* :class:`MultiVerifyResult` — per-engine verdicts + aggregate.
"""
from __future__ import annotations

import re
import subprocess
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from kairos.security.path_sanitizer import validate_verilog_identifier, build_yosys_inc_flags, sanitize_yosys_path

from kairos.security.env_allowlist import safe_env_for_yosys


@dataclass(frozen=True)
class EngineVerdict:
    """One engine's independent verdict."""
    engine: str
    verdict: str  # PROVED / REFUTED / INCONCLUSIVE / ERROR / SKIPPED
    detail: str = ""
    elapsed_sec: float = 0.0


@dataclass(frozen=True)
class MultiVerifyResult:
    """Aggregate result from all verification engines."""
    engine_verdicts: tuple[EngineVerdict, ...]
    aggregate_verdict: str  # PROVED only if ALL engines say PROVED
    is_combo: bool = False

    @property
    def all_proved(self) -> bool:
        active = [e for e in self.engine_verdicts if e.verdict != "SKIPPED"]
        return all(e.verdict == "PROVED" for e in active) and len(active) >= 2

    @property
    def summary(self) -> str:
        parts = [f"{e.engine}: {e.verdict}" for e in self.engine_verdicts]
        return f"{self.aggregate_verdict} ({', '.join(parts)})"


def _run_yosys_equiv(
    gold_path: Path,
    gate_path: Path,
    gold_module: str,
    gate_module: str,
    deps: list[Path] | None = None,
) -> EngineVerdict:
    """Run yosys equiv_make + equiv_simple + equiv_status."""
    import time
    t0 = time.time()
    sanitize_yosys_path(gold_path)
    sanitize_yosys_path(gate_path)
    inc_flags = build_yosys_inc_flags([gold_path, gate_path, *(deps or [])])
    inc_prefix = f"{inc_flags} " if inc_flags else ""
    try:
        cmd = (
            f"read_verilog -sv -formal {inc_prefix}{gold_path} {gate_path}; "
            f"equiv_make {gold_module} {gate_module} equiv_mod; "
            f"hierarchy -top equiv_mod; "
            f"equiv_simple; "
            f"equiv_status -assert"
        )
        r = subprocess.run(
            ["yosys", "-p", cmd],
            capture_output=True, text=True, timeout=120,
            env=safe_env_for_yosys(),
        )
        elapsed = time.time() - t0
        if r.returncode == 0:
            if "Verified" in r.stdout or "proven" in r.stdout.lower():
                return EngineVerdict(
                    engine="yosys_equiv",
                    verdict="PROVED",
                    detail="equiv_simple + equiv_status PASSED",
                    elapsed_sec=elapsed,
                )
            return EngineVerdict(
                engine="yosys_equiv",
                verdict="INCONCLUSIVE",
                detail=r.stdout[-200:] if r.stdout else "no output",
                elapsed_sec=elapsed,
            )
        else:
            err = r.stderr[-200:] if r.stderr else r.stdout[-200:]
            if "NOT EQUIVALENT" in (r.stdout + r.stderr).upper():
                return EngineVerdict(
                    engine="yosys_equiv", verdict="REFUTED",
                    detail=err, elapsed_sec=elapsed,
                )
            return EngineVerdict(
                engine="yosys_equiv", verdict="ERROR",
                detail=err, elapsed_sec=elapsed,
            )
    except subprocess.TimeoutExpired:
        return EngineVerdict(
            engine="yosys_equiv", verdict="INCONCLUSIVE",
            detail="timeout after 120s", elapsed_sec=time.time() - t0,
        )
    except Exception as e:  # noqa: BLE001
        return EngineVerdict(
            engine="yosys_equiv", verdict="ERROR",
            detail=str(e)[:200], elapsed_sec=time.time() - t0,
        )


_ADAPTIVE_BOUNDS = (5, 10, 32)


def verify_with_all_engines(
    *,
    gold_path: Path | str,
    gate_path: Path | str,
    gold_module: str,
    gate_module: str,
    ports: Any = None,
    clock_port: str = "clk",
    reset_port: str = "reset_n",
    reset_active_low: bool = True,
    ebmc_bound: int = 32,
    ebmc_timeout_sec: int = 900,
    is_combo: bool = False,
    deps: list[Path] | None = None,
    adaptive_bound: bool = True,
) -> MultiVerifyResult:
    """Run all applicable verification engines and return per-engine verdicts.

    Combo blocks: EBMC BMC + yosys equiv (2 engines).
    Sequential blocks: EBMC BMC + EBMC k-induction + yosys equiv (3 engines).

    ATH-1468: adaptive bound selection. Start at bound=5, escalate to
    bound=10 then bound=32 only if all properties PROVED at the lower
    bound. Saves ~4x on easy properties. Disable with adaptive_bound=False.

    ATH-1469: early termination. If BMC REFUTES any property, skip
    k-induction entirely (customer doesn't need to wait).
    """
    import os
    os.environ.setdefault("KAIROS_TEST_MODE", "1")

    gold_path = Path(gold_path)
    gate_path = Path(gate_path)
    verdicts: list[EngineVerdict] = []

    bounds = list(_ADAPTIVE_BOUNDS) if adaptive_bound else [ebmc_bound]
    if ebmc_bound not in bounds:
        bounds.append(ebmc_bound)
        bounds.sort()
    reset_expr = None if is_combo else (
        f"!{reset_port}" if reset_active_low else reset_port
    )

    # Engine 1: EBMC BMC (with adaptive bound)
    import time
    bmc_refuted = False
    try:
        from kairos.ebmc import verify as ebmc_verify
        for bound in bounds:
            t0 = time.time()
            ebmc_result = ebmc_verify(
                [str(gold_path), str(gate_path)],
                top_module="sec_miter",
                bound=bound,
                mode="bmc",
                reset_expr=reset_expr,
                timeout_sec=ebmc_timeout_sec,
            )
            elapsed = time.time() - t0
            if ebmc_result.refuted:
                verdicts.append(EngineVerdict(
                    "ebmc_bmc", "REFUTED",
                    detail=f"refuted at bound={bound}",
                    elapsed_sec=elapsed,
                ))
                bmc_refuted = True
                break
            if ebmc_result.proved:
                if bound >= ebmc_bound or not adaptive_bound:
                    verdicts.append(EngineVerdict(
                        "ebmc_bmc", "PROVED",
                        detail=f"proved at bound={bound}",
                        elapsed_sec=elapsed,
                    ))
                    break
            else:
                verdicts.append(EngineVerdict(
                    "ebmc_bmc", "INCONCLUSIVE",
                    detail=f"inconclusive at bound={bound}",
                    elapsed_sec=elapsed,
                ))
                break
        if not verdicts:
            verdicts.append(EngineVerdict("ebmc_bmc", "INCONCLUSIVE"))
    except Exception as e:  # noqa: BLE001
        verdicts.append(EngineVerdict("ebmc_bmc", "ERROR", detail=str(e)[:200]))

    # ATH-1469: early termination — skip remaining engines if REFUTED
    if bmc_refuted:
        verdicts.append(EngineVerdict(
            "yosys_equiv", "SKIPPED", detail="skipped: BMC refuted",
        ))
        verdicts.append(EngineVerdict(
            "ebmc_kinduction", "SKIPPED", detail="skipped: BMC refuted",
        ))
        return MultiVerifyResult(
            engine_verdicts=tuple(verdicts),
            aggregate_verdict="REFUTED",
            is_combo=is_combo,
        )

    # Engine 2: yosys equiv
    yosys_v = _run_yosys_equiv(gold_path, gate_path, gold_module, gate_module, deps=deps)
    verdicts.append(yosys_v)

    # Engine 3: EBMC k-induction (sequential blocks only)
    if not is_combo:
        try:
            t0 = time.time()
            kind_result = ebmc_verify(
                [str(gold_path), str(gate_path)],
                top_module="sec_miter",
                bound=ebmc_bound,
                mode="k_induction",
                reset_expr=reset_expr,
                timeout_sec=ebmc_timeout_sec,
            )
            elapsed = time.time() - t0
            if kind_result.proved:
                verdicts.append(EngineVerdict("ebmc_kinduction", "PROVED", elapsed_sec=elapsed))
            else:
                verdicts.append(EngineVerdict("ebmc_kinduction", "INCONCLUSIVE", elapsed_sec=elapsed))
        except Exception as e:  # noqa: BLE001
            verdicts.append(EngineVerdict("ebmc_kinduction", "ERROR", detail=str(e)[:200]))
    else:
        verdicts.append(EngineVerdict("ebmc_kinduction", "SKIPPED", detail="combo block"))

    # Aggregate: PROVED only if ALL active engines say PROVED
    active = [v for v in verdicts if v.verdict != "SKIPPED"]
    if all(v.verdict == "PROVED" for v in active) and len(active) >= 2:
        aggregate = "PROVED"
    elif any(v.verdict == "REFUTED" for v in active):
        aggregate = "REFUTED"
    else:
        aggregate = "INCONCLUSIVE"

    return MultiVerifyResult(
        engine_verdicts=tuple(verdicts),
        aggregate_verdict=aggregate,
        is_combo=is_combo,
    )


_SVA_PROPERTY_RE = re.compile(
    r"(?:assert|cover|assume)\s+property\s*\(\s*@\s*\(\s*(?:posedge|negedge)\s+\w+\s*\)\s*(.*?)\)",
    re.MULTILINE | re.DOTALL,
)
_PROPERTY_LABEL_RE = re.compile(r"^\s*(\w+)\s*:", re.MULTILINE)


_SVA_LABEL_LINE_RE = re.compile(
    r"^\s*(\w+)\s*:\s*(?:assert|cover|assume)\s+property\b",
    re.MULTILINE,
)


def extract_property_names(sv_path: Path | str, module_name: str = "") -> list[str]:
    """Extract SVA property label names from a SystemVerilog file.

    Returns module-qualified names (module.property) when module_name
    is provided, since EBMC --property requires the full path.
    """
    text = Path(sv_path).read_text()
    labels = [m.group(1) for m in _SVA_LABEL_LINE_RE.finditer(text)]
    if module_name:
        return [f"{module_name}.{l}" for l in labels]
    return labels


def _verify_single_property(
    gold_path_str: str,
    gate_path_str: str,
    gold_module: str,
    gate_module: str,
    property_name: str,
    ebmc_bound: int,
    ebmc_timeout_sec: int,
    reset_expr: str | None,
    is_combo: bool,
) -> tuple[str, list[EngineVerdict]]:
    """Verify a single property through BMC -> k-induction. Runs in subprocess."""
    import time
    verdicts: list[EngineVerdict] = []

    try:
        from kairos.sv.ebmc import run_ebmc
        t0 = time.time()
        bmc_result = run_ebmc(
            [gold_path_str, gate_path_str],
            top_module="sec_miter",
            bound=ebmc_bound,
            mode="bmc",
            reset_expr=reset_expr,
            timeout_sec=ebmc_timeout_sec,
            property_name=property_name,
        )
        elapsed = time.time() - t0
        if bmc_result.refuted:
            verdicts.append(EngineVerdict(
                f"ebmc_bmc[{property_name}]", "REFUTED", elapsed_sec=elapsed,
            ))
            return property_name, verdicts

        if bmc_result.proved:
            verdicts.append(EngineVerdict(
                f"ebmc_bmc[{property_name}]", "PROVED", elapsed_sec=elapsed,
            ))
        else:
            verdicts.append(EngineVerdict(
                f"ebmc_bmc[{property_name}]", "INCONCLUSIVE", elapsed_sec=elapsed,
            ))

        if not is_combo:
            t0 = time.time()
            kind_result = run_ebmc(
                [gold_path_str, gate_path_str],
                top_module="sec_miter",
                bound=ebmc_bound,
                mode="k_induction",
                reset_expr=reset_expr,
                timeout_sec=ebmc_timeout_sec,
                property_name=property_name,
            )
            elapsed = time.time() - t0
            if kind_result.proved:
                verdicts.append(EngineVerdict(
                    f"ebmc_kinduction[{property_name}]", "PROVED", elapsed_sec=elapsed,
                ))
            else:
                verdicts.append(EngineVerdict(
                    f"ebmc_kinduction[{property_name}]", "INCONCLUSIVE", elapsed_sec=elapsed,
                ))

    except Exception as e:  # noqa: BLE001
        verdicts.append(EngineVerdict(
            f"ebmc[{property_name}]", "ERROR", detail=str(e)[:200],
        ))

    return property_name, verdicts


def verify_properties_parallel(
    *,
    gold_path: Path | str,
    gate_path: Path | str,
    gold_module: str,
    gate_module: str,
    clock_port: str = "clk",
    reset_port: str = "reset_n",
    reset_active_low: bool = True,
    ebmc_bound: int = 32,
    ebmc_timeout_sec: int = 900,
    is_combo: bool = False,
    deps: list[Path] | None = None,
    max_workers: int = 4,
) -> MultiVerifyResult:
    """Per-property parallel verification.

    Extracts SVA property names from the gate file, runs each property
    through BMC -> k-induction independently on separate processes.
    Falls back to verify_with_all_engines if no properties are found
    or if there's only one property.
    """
    gold_path = Path(gold_path)
    gate_path = Path(gate_path)

    property_names = extract_property_names(gate_path, module_name=gate_module)
    if not property_names or len(property_names) <= 1:
        return verify_with_all_engines(
            gold_path=gold_path, gate_path=gate_path,
            gold_module=gold_module, gate_module=gate_module,
            clock_port=clock_port, reset_port=reset_port,
            reset_active_low=reset_active_low,
            ebmc_bound=ebmc_bound, ebmc_timeout_sec=ebmc_timeout_sec,
            is_combo=is_combo, deps=deps,
        )

    reset_expr = None if is_combo else (
        f"!{reset_port}" if reset_active_low else reset_port
    )

    all_verdicts: list[EngineVerdict] = []

    workers = min(max_workers, len(property_names))
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = {
            pool.submit(
                _verify_single_property,
                str(gold_path), str(gate_path),
                gold_module, gate_module,
                prop_name, ebmc_bound, ebmc_timeout_sec,
                reset_expr, is_combo,
            ): prop_name
            for prop_name in property_names
        }
        for future in as_completed(futures):
            _prop_name, verdicts = future.result()
            all_verdicts.extend(verdicts)

    yosys_v = _run_yosys_equiv(gold_path, gate_path, gold_module, gate_module, deps=deps)
    all_verdicts.append(yosys_v)

    active = [v for v in all_verdicts if v.verdict != "SKIPPED"]
    if all(v.verdict == "PROVED" for v in active) and len(active) >= 2:
        aggregate = "PROVED"
    elif any(v.verdict == "REFUTED" for v in active):
        aggregate = "REFUTED"
    else:
        aggregate = "INCONCLUSIVE"

    return MultiVerifyResult(
        engine_verdicts=tuple(all_verdicts),
        aggregate_verdict=aggregate,
        is_combo=is_combo,
    )


__all__ = [
    "EngineVerdict",
    "MultiVerifyResult",
    "verify_with_all_engines",
    "verify_properties_parallel",
    "extract_property_names",
]
