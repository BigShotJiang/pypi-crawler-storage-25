r"""ATH-1086 — counterexample-feedback proposer refinement.

When a transformation proposal REFUTES at the equivalence miter
(EBMC produces a counterexample showing gold and gate diverge), the
proposer gets to TRY AGAIN with the counterexample injected into its
prompt context. Per Aidan's no-wasted-effort + retry-budget directive
2026-05-07: every LLM-proposing agent has bounded retry budget;
single-shot agent that fails on a recoverable issue is wasted
tokens. The counterexample tells the proposer EXACTLY where its
prior transformation broke; refinement is the natural inner loop.

This module ships the **library function** for that refinement step.
Orchestrator wiring (call this after BMC REFUTE before declaring the
iteration refuted) is a follow-up commit so this surface lands
without entangling with the parallel cto-1087-B / platform PR #434
work on the orchestrator + render path.

Per platform-render-contract pin (V27IterationArcPanel
inner_retry_history shape, slack ts 1778159612): every refinement
attempt adds an inner_retry_history row with attempt_status
``REVISED_AFTER`` (after a REFUTE feedback) → ``PROVED`` /
``REFUTED`` / ``INCONCLUSIVE`` (next verifier verdict) so the
dashboard shows the full refinement chain to the customer.

## Public API

* :func:`refine_proposal_after_refutation` — single-call entry; returns
  a :class:`ProposalRunResult` containing the refined proposal (the
  caller verifies via the standard verify_sec path; this lib is
  proposal-only).
* :class:`CounterexampleFeedback` — frozen dataclass capturing the
  prior REFUTED proposal's verdict + EBMC counterexample summary
  for the LLM context-augmentation.

## Design discipline

Architecture-defense rule (Aidan no-LLM-hallucination): the refined
proposal still passes through EBMC's verifier before joining any
downstream state. This lib doesn't gate; it provides the LLM call
with feedback, and the caller routes the output through the same
verify_sec path. Hallucinated refinements get REFUTED again + the
caller decides whether to retry further (up to ATH-1089's
``max_inner_retries``).

## Cross-refs

* ATH-1086 (parent ticket).
* ATH-1089 (inner-retry harness; this lib produces one refinement
  attempt; harness runs the loop).
* ATH-1078 (customer strategy realignment — counterexample-feedback is the
  load-bearing addition behind the LLM proposer that closes the 0/6
  Phase 1 close-rate gap).
* ATH-1087 (mine_assumptions sibling — together they constrain the
  LLM to operate within proven assumption set + away from known
  refute-class transformations).
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from kairos.model_presets import DEFAULT_SEC_REASONING_MODEL
from kairos.sec.closed_loop._proposer import (
    ProposalRunResult,
    TransformationClass,
    propose_transformations,
)


@dataclass(frozen=True)
class CounterexampleFeedback:
    """Captures one REFUTED proposal's verdict + EBMC counterexample for LLM context.

    The LLM's refinement prompt embeds these so the proposer KNOWS
    what to avoid:

    * which transformation class produced the refute (so it can pick
      a different class);
    * the EBMC counterexample summary (so it can reason about which
      input pattern broke equivalence);
    * the prior gate_sv (so it can evolve / discard / replace it
      rather than re-propose verbatim).

    Attributes
    ----------
    refuted_class:
        The :class:`TransformationClass` of the REFUTED proposal.
    refuted_gate_sv:
        The gate_sv text the proposer emitted in the prior round.
        Truncated by the prompt builder for token budget.
    counterexample_summary:
        One-line ebmc counterexample summary (cycle / input / output
        triple). Full trace lives at ``ebmc_log_path``.
    ebmc_log_path:
        Absolute path to the ebmc subprocess capture for this prior
        attempt (cert-tarball reproducibility).
    refuted_at_property:
        The miter property label that REFUTED (e.g.
        ``sec_miter.fifo_dout_y_match``). Lets the LLM target which
        output port to focus on in its refinement.
    prior_attempt_index:
        0-based index in the proposer's outer-loop (used by retry
        harness for telemetry).
    """

    refuted_class: TransformationClass
    refuted_gate_sv: str
    counterexample_summary: str
    ebmc_log_path: str
    refuted_at_property: str
    prior_attempt_index: int = 0
    proved_properties: tuple[str, ...] = ()
    measured_delta_pct: float | None = None
    # ATH-1103 — every prior REFUTED attempt in this retry chain.
    # Empty on first retry. Each subsequent retry's feedback carries
    # the chronological list of every preceding feedback so the
    # prompt can render enumerated ANTI-PATTERNS — proposer sees the
    # full history rather than only the immediate prior attempt.
    prior_attempts: tuple["CounterexampleFeedback", ...] = ()


def refine_proposal_after_refutation(
    bundle_path: Path | str,
    target_module: str,
    *,
    feedback: CounterexampleFeedback,
    model: str = DEFAULT_SEC_REASONING_MODEL,
    max_proposals: int = 1,
    timeout_sec: int = 180,
) -> ProposalRunResult:
    """Run the proposer with a prior REFUTED proposal's counterexample
    injected into the prompt context.

    Calls :func:`propose_transformations` with an augmented user prompt
    that names the prior REFUTED transformation class + gate_sv (truncated)
    + counterexample summary, and asks the LLM to propose a refined
    alternative. Returns the standard :class:`ProposalRunResult`; caller
    routes the output through verify_sec for verdict.

    By default returns ``max_proposals=1`` (single refinement attempt
    per inner-retry call); the retry harness (ATH-1089) runs the
    multi-attempt loop. Caller may override for a wider refinement
    sweep at the cost of additional tokens per call.

    Parameters
    ----------
    bundle_path:
        SEC bundle directory.
    target_module:
        Top-level module being optimized.
    feedback:
        :class:`CounterexampleFeedback` from the prior REFUTED attempt.
    model:
        LLM model id (default: ``anthropic/claude-opus-4-6``).
    max_proposals:
        Refined-proposal cap. Default 1 per inner-retry budget.
    timeout_sec:
        LLM-call wall-clock cap.

    Returns
    -------
    :class:`ProposalRunResult` with one or more refined proposals
    (caller checks ``halt_reason == "ok"`` + ``proposals`` non-empty).

    Notes
    -----
    Phase 1 implementation: the refined-prompt augmentation lives in
    :func:`_augment_user_prompt_with_refute_feedback`, which
    prepends an ANTI-PATTERN block to the standard proposer user
    prompt. Future iterations may rewrite the prompt structure (e.g.
    chain-of-thought scaffolding) as we measure refinement close-rate
    on real customer RTL.
    """
    started = time.monotonic()
    bundle = Path(bundle_path)

    # Today's implementation: monkey-patch the user-prompt builder via
    # a context-augmentation wrapper. The propose_transformations
    # function reads its prompt from _build_proposer_user_prompt at
    # module-level; we wrap that for the duration of this call.
    from kairos.sec.closed_loop import _proposer as _prop_mod

    original_builder = _prop_mod._build_proposer_user_prompt

    def _augmented_builder(*args: Any, **kwargs: Any) -> str:
        base = original_builder(*args, **kwargs)
        return _augment_user_prompt_with_refute_feedback(base, feedback)

    _prop_mod._build_proposer_user_prompt = _augmented_builder
    try:
        result = propose_transformations(
            bundle_path=bundle,
            target_module=target_module,
            model=model,
            max_proposals=max_proposals,
            timeout_sec=timeout_sec,
        )
    finally:
        _prop_mod._build_proposer_user_prompt = original_builder

    return result


# ATH-1103 — per-attempt gate_sv truncation cap. With 5+ retries
# accumulated in prior_attempts, single-attempt budget drops from
# 1500 → 1000 chars to stay under context window. counterexample
# summaries (~200 chars each) + class names + property labels add
# negligible overhead relative to gate_sv bodies.
_PRIOR_GATE_SV_CHARCAP = 1000


def _render_one_attempt(
    feedback: CounterexampleFeedback,
    *,
    label: str,
) -> str:
    """Render one CounterexampleFeedback as an ANTI-PATTERN entry.

    ``label`` distinguishes prior attempts ("Attempt #N") from the
    current one ("Current refute") in the enumerated block.
    """
    truncated_gate = feedback.refuted_gate_sv[:_PRIOR_GATE_SV_CHARCAP]
    if len(feedback.refuted_gate_sv) > _PRIOR_GATE_SV_CHARCAP:
        truncated_gate += "\n... (truncated for token budget)"
    cls = (
        feedback.refuted_class.value
        if hasattr(feedback.refuted_class, "value")
        else feedback.refuted_class
    )
    extra = ""
    if feedback.proved_properties:
        extra += f"    Properties that PROVED (preserve these): {', '.join(feedback.proved_properties)}\n"
    if feedback.measured_delta_pct is not None:
        extra += f"    Measured synthesis delta: {feedback.measured_delta_pct:+.1f}% (your estimate was wrong if different)\n"
    return (
        f"  {label} of class {cls} REFUTED at property "
        f"{feedback.refuted_at_property}\n"
        f"    Counterexample: {feedback.counterexample_summary}\n"
        f"{extra}"
        f"    Prior gate_sv:\n"
        f"    ```\n{truncated_gate}\n    ```\n"
    )


def _augment_user_prompt_with_refute_feedback(
    base_prompt: str,
    feedback: CounterexampleFeedback,
) -> str:
    """Prepend an enumerated ANTI-PATTERNS block to the proposer prompt.

    ATH-1103 — when ``feedback.prior_attempts`` is non-empty, render
    EVERY prior attempt + the current refute as an enumerated list so
    the proposer sees the full retry history. The amnesic single-
    attempt rendering is preserved as the empty-prior_attempts case
    (backward compat).

    Block shape (cumulative, N=2 prior attempts + current):

      ANTI-PATTERNS — DO NOT REPEAT (3 prior attempts):

        Attempt #0 of class dead-logic-removal REFUTED at fifo_dout_y_match
          Counterexample: cycle 5 in=8'h7F => 8'h7F (gold) vs 8'hFF (gate)
          Prior gate_sv: <truncated>

        Attempt #1 of class dead-logic-removal REFUTED at fifo_dout_y_match
          Counterexample: cycle 7 in=8'hAA => 8'hAA (gold) vs 8'h55 (gate)
          Prior gate_sv: <truncated>

        Current refute of class dead-logic-removal REFUTED at fifo_dout_y_match
          Counterexample: cycle 3 in=8'h00 => 8'h00 (gold) vs 8'hFF (gate)
          Prior gate_sv: <truncated>

      Avoid the failure modes from EVERY attempt above. If the same
      transformation class kept refuting, pick a fundamentally
      different class OR rethink the encoding/indexing relationship
      that's causing the repeated mismatch.
    """
    parts: list[str] = []
    n_total = len(feedback.prior_attempts) + 1
    parts.append(
        f"ANTI-PATTERNS — DO NOT REPEAT ({n_total} prior attempt"
        f"{'s' if n_total != 1 else ''}):\n\n"
    )
    for prior in feedback.prior_attempts:
        parts.append(
            _render_one_attempt(
                prior, label=f"Attempt #{prior.prior_attempt_index}"
            )
        )
        parts.append("\n")
    parts.append(
        _render_one_attempt(feedback, label="Current refute")
    )
    parts.append("\n")
    if n_total == 1:
        # Single-attempt history: original guidance.
        parts.append(
            "Propose a DIFFERENT transformation that avoids this "
            "counterexample. Either pick a different transformation "
            "class OR refine the prior gate_sv to handle the "
            "counterexample case correctly.\n\n"
        )
    else:
        # Multi-attempt history: cumulative-context guidance.
        parts.append(
            "Avoid the failure modes from EVERY attempt above. If "
            "the same transformation class kept refuting, pick a "
            "fundamentally different class OR rethink the "
            "encoding/indexing relationship that's causing the "
            "repeated mismatch. Trace through one push-then-pop "
            "(or write-then-read) sequence in your head to verify "
            "the gate body's semantics match the gold body's "
            "BEFORE emitting.\n\n"
        )
    parts.append("---\n\n")
    return "".join(parts) + base_prompt


__all__ = [
    "CounterexampleFeedback",
    "refine_proposal_after_refutation",
]
