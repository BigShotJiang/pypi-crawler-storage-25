"""ATH-1114: Compositional invariant inference for SEC.

When k-induction fails on a composed module, infer bridge invariants
from sub-module properties that lift to the composition.

The key insight (proved in Lean, composition_preserves_equiv):
if each sub-module is equivalent to its optimized version,
the composed module is also equivalent. The bridge invariant
is the conjunction of sub-module equivalences.

This module:
1. Decomposes a module into sub-instances
2. Infers invariants from each sub-instance's interface
3. Lifts sub-module invariants to the composed module
4. Generates bridge invariant expressions for EBMC
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class SubInstance:
    name: str
    module_type: str
    ports: dict[str, str] = field(default_factory=dict)
    parameters: dict[str, int] = field(default_factory=dict)


@dataclass
class ComposedInvariant:
    expression: str
    source: str  # structural | inferred | user
    confidence: float = 1.0
    sub_instance: str = ""
    description: str = ""


@dataclass
class CompositionResult:
    sub_instances: list[SubInstance] = field(default_factory=list)
    invariants: list[ComposedInvariant] = field(default_factory=list)
    error: str | None = None

    @property
    def honest_report(self) -> str:
        if self.error:
            return f"Composition analysis failed: {self.error}"
        return (
            f"Composition: {len(self.sub_instances)} sub-instances, "
            f"{len(self.invariants)} invariants inferred"
        )


def extract_sub_instances(rtl_text: str) -> list[SubInstance]:
    """Extract module instantiations from RTL source."""
    instances = []
    inst_re = re.compile(
        r"(\w+)\s+(?:#\s*\([^)]*\)\s+)?(\w+)\s*\(",
        re.MULTILINE,
    )
    for m in inst_re.finditer(rtl_text):
        module_type = m.group(1)
        inst_name = m.group(2)
        if module_type in ("module", "assign", "always", "wire", "reg",
                           "input", "output", "parameter", "generate",
                           "if", "else", "for", "begin", "end"):
            continue
        instances.append(SubInstance(
            name=inst_name,
            module_type=module_type,
        ))
    return instances


def infer_structural_invariants(
    instances: list[SubInstance],
    gold_module: str,
) -> list[ComposedInvariant]:
    """Infer bridge invariants from sub-module structure.

    For each sub-instance, generate invariants that the optimized
    version must preserve:
    - Output equivalence: sub_gold.out == sub_gate.out
    - State correspondence: related state signals match
    - One-hot preservation: pointer encodings stay one-hot
    """
    invariants = []

    for inst in instances:
        invariants.append(ComposedInvariant(
            expression=f"({gold_module}.{inst.name}.* == gate.{inst.name}.*)",
            source="structural",
            confidence=0.9,
            sub_instance=inst.name,
            description=f"Output equivalence for sub-instance {inst.name} ({inst.module_type})",
        ))

        if "fifo" in inst.module_type.lower():
            invariants.append(ComposedInvariant(
                expression=f"$onehot({gold_module}.{inst.name}.push_ptr)",
                source="structural",
                confidence=1.0,
                sub_instance=inst.name,
                description=f"One-hot push pointer for {inst.name}",
            ))
            invariants.append(ComposedInvariant(
                expression=f"$onehot({gold_module}.{inst.name}.pop_ptr)",
                source="structural",
                confidence=1.0,
                sub_instance=inst.name,
                description=f"One-hot pop pointer for {inst.name}",
            ))

    return invariants


def compose_bridge_invariant(invariants: list[ComposedInvariant]) -> str:
    """Combine sub-module invariants into a single bridge expression."""
    if not invariants:
        return "1'b1"
    high_conf = [inv for inv in invariants if inv.confidence >= 0.8]
    if not high_conf:
        return "1'b1"
    return " && ".join(inv.expression for inv in high_conf)


def analyze_composition(
    rtl_path: Path,
    gold_module: str,
) -> CompositionResult:
    """Full compositional analysis: extract + infer + combine."""
    result = CompositionResult()

    if not rtl_path.is_file():
        result.error = f"File not found: {rtl_path}"
        return result

    rtl_text = rtl_path.read_text()
    result.sub_instances = extract_sub_instances(rtl_text)
    result.invariants = infer_structural_invariants(
        result.sub_instances, gold_module
    )

    return result
