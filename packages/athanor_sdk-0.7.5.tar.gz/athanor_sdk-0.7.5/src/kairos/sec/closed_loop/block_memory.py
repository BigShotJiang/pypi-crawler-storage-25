"""ATH-1167: Per-block learning store across runs.

Customer agent gets smarter every run. Memory persists at
~/.kairos/memory/<block_hash>/. The orchestrator reads memory
BEFORE proposing — past refutations become REJECTION RULES,
not suggestions.

Forcing function: proposals matching past refutation patterns
are flagged before verification, saving LLM + verifier cost.
"""
from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


MEMORY_ROOT = Path.home() / ".kairos" / "memory"


def _active_agent_id() -> str | None:
    """Return the active agent ID from env, or None for global memory."""
    return os.environ.get("KAIROS_AGENT_ID", "").strip() or None


def _sharing_mode() -> str:
    """Return sharing mode: 'org' (default) or 'private'."""
    try:
        config_path = Path.home() / ".athanor" / "config.json"
        if config_path.is_file():
            import json as _j
            config = _j.loads(config_path.read_text())
            result: str = config.get("sharing", "org")
            return result
    except Exception:  # noqa: BLE001
        pass
    return "org"


def _sanitize_agent_id(agent: str) -> str:
    """Reject agent IDs with path traversal characters."""
    import re
    if not re.match(r'^[a-zA-Z0-9_-]+$', agent):
        raise ValueError(f"Invalid agent ID (path traversal risk): {agent!r}")
    return agent


def _memory_base() -> Path:
    """Memory base dir, scoped to agent when KAIROS_AGENT_ID is set."""
    agent = _active_agent_id()
    if agent:
        return MEMORY_ROOT / f"agent-{_sanitize_agent_id(agent)}"
    return MEMORY_ROOT


# Back-compat alias
MEMORY_DIR = MEMORY_ROOT


def _block_hash(block_path: str) -> str:
    """Stable hash for a block file (content-addressed).

    In compound mode, all rounds share memory keyed by the ORIGINAL
    gold's hash (set via KAIROS_COMPOUND_ORIGIN_HASH). This ensures
    round 2 recalls round 1's successes/failures even though the
    intermediate gate has different content.
    """
    origin = os.environ.get("KAIROS_COMPOUND_ORIGIN_HASH", "").strip()
    if origin:
        return origin
    try:
        content = Path(block_path).read_bytes()
        return hashlib.sha256(content).hexdigest()[:16]
    except Exception:  # noqa: BLE001
        return hashlib.sha256(block_path.encode()).hexdigest()[:16]


def _memory_dir(block_path: str) -> Path:
    h = _block_hash(block_path)
    d = _memory_base() / h
    d.mkdir(parents=True, exist_ok=True)
    return d


@dataclass
class RefutationRecord:
    transformation_class: str
    claimed_delta_pct: float
    refutation_reason: str
    counterexample_summary: str | None = None
    timestamp: str = ""
    elapsed_seconds: float = 0.0


@dataclass
class SuccessRecord:
    transformation_class: str
    measured_delta_pct: float
    gold_cells: int
    gate_cells: int
    engine: str
    timestamp: str
    elapsed_seconds: float = 0.0


@dataclass
class BlockMemory:
    block_path: str
    block_hash: str
    refutations: list[RefutationRecord] = field(default_factory=list)
    successes: list[SuccessRecord] = field(default_factory=list)
    encoding_conventions: dict[str, str] = field(default_factory=dict)
    consecutive_refutations: int = 0
    synthesis_floor_confidence: float = 0.0

    def is_at_floor(self, threshold: float = 0.95) -> bool:
        """True if block is likely at synthesis floor."""
        return self.synthesis_floor_confidence >= threshold

    def refutation_patterns(self) -> list[str]:
        """Transformation classes that have been refuted."""
        return list(set(r.transformation_class for r in self.refutations))

    def avg_elapsed_seconds(self) -> float:
        """Average elapsed time across all recorded runs."""
        times = [s.elapsed_seconds for s in self.successes if s.elapsed_seconds > 0]
        times += [r.elapsed_seconds for r in self.refutations if r.elapsed_seconds > 0]
        return sum(times) / len(times) if times else 0.0

    def timing_estimate(self) -> str:
        """Human-readable timing estimate based on actual run history."""
        avg = self.avg_elapsed_seconds()
        if avg == 0:
            return "no timing data"
        if avg < 60:
            return f"{avg:.0f}s (based on {len(self.successes) + len(self.refutations)} prior runs)"
        return f"{avg / 60:.1f}min (based on {len(self.successes) + len(self.refutations)} prior runs)"

    def format_for_proposer(self) -> str:
        """Format memory as proposer context. This is the forcing function.

        Recent refutations (high confidence) are HARD BLOCKS.
        Old refutations (decayed confidence) are CAUTION warnings.
        """
        parts = []
        if self.refutations:
            recent = []
            faded = []
            for r in self.refutations[-8:]:
                w = _age_weight(r.timestamp)
                if w >= 0.5:
                    recent.append(r)
                else:
                    faded.append((r, w))

            if recent:
                parts.append("## PAST FAILURES ON THIS BLOCK (DO NOT REPEAT)")
                for r in recent[-5:]:
                    parts.append(
                        f"- {r.transformation_class}: REFUTED ({r.refutation_reason}). "
                        f"Counterexample: {(r.counterexample_summary or '')[:100]}"
                    )
                parts.append("")

            if faded:
                parts.append("## OLDER FAILURES (may be worth retrying with different approach)")
                for r, w in faded[-3:]:
                    parts.append(
                        f"- {r.transformation_class}: failed {r.refutation_reason} "
                        f"(confidence: {w:.0%}, may be stale)"
                    )
                parts.append("")

        if self.successes:
            parts.append("## PAST SUCCESSES ON THIS BLOCK")
            for s in self.successes[-3:]:
                parts.append(
                    f"- {s.transformation_class}: {s.measured_delta_pct:+.1f}% "
                    f"({s.gold_cells}->{s.gate_cells}) via {s.engine}"
                )
            parts.append("")

        if self.is_at_floor():
            parts.append(
                f"WARNING: This block has {self.consecutive_refutations} consecutive "
                f"refutations (confidence {self.synthesis_floor_confidence:.0%} at "
                f"synthesis floor). Consider moving to a different block."
            )

        return "\n".join(parts) if parts else ""


def load_memory_by_content(content: str) -> BlockMemory:
    """Load memory using the hash of block content directly.

    In compound mode, uses the original gold's hash so all rounds
    share the same memory store.
    """
    origin = os.environ.get("KAIROS_COMPOUND_ORIGIN_HASH", "").strip()
    h = origin if origin else hashlib.sha256(content.encode()).hexdigest()[:16]
    d = MEMORY_DIR / h
    if not d.is_dir():
        return BlockMemory(block_path="<content>", block_hash=h)
    mem = BlockMemory(block_path="<content>", block_hash=h)
    for loader, attr in [
        ("refutations.json", "refutations"),
        ("successes.json", "successes"),
        ("encoding_conventions.json", "encoding_conventions"),
    ]:
        p = d / loader
        if p.is_file():
            try:
                data = json.loads(p.read_text())
                if attr == "refutations":
                    mem.refutations = [RefutationRecord(**r) for r in data]
                elif attr == "successes":
                    mem.successes = [SuccessRecord(**s) for s in data]
                else:
                    mem.encoding_conventions = data
            except Exception:  # noqa: BLE001
                pass
    floor_path = d / "synthesis_floor.json"
    if floor_path.is_file():
        try:
            data = json.loads(floor_path.read_text())
            mem.consecutive_refutations = data.get("consecutive_refutations", 0)
            mem.synthesis_floor_confidence = data.get("confidence", 0.0)
        except Exception:  # noqa: BLE001
            pass
    return mem


def load_memory(block_path: str) -> BlockMemory:
    """Load persisted memory for a block."""
    d = _memory_dir(block_path)
    mem = BlockMemory(
        block_path=block_path,
        block_hash=_block_hash(block_path),
    )

    ref_path = d / "refutations.json"
    if ref_path.is_file():
        try:
            data = json.loads(ref_path.read_text())
            mem.refutations = [RefutationRecord(**r) for r in data]
        except Exception:  # noqa: BLE001
            pass

    succ_path = d / "successes.json"
    if succ_path.is_file():
        try:
            data = json.loads(succ_path.read_text())
            mem.successes = [SuccessRecord(**s) for s in data]
        except Exception:  # noqa: BLE001
            pass

    enc_path = d / "encoding_conventions.json"
    if enc_path.is_file():
        try:
            mem.encoding_conventions = json.loads(enc_path.read_text())
        except Exception:  # noqa: BLE001
            pass

    floor_path = d / "synthesis_floor.json"
    if floor_path.is_file():
        try:
            data = json.loads(floor_path.read_text())
            mem.consecutive_refutations = data.get("consecutive_refutations", 0)
            mem.synthesis_floor_confidence = data.get("confidence", 0.0)
        except Exception:  # noqa: BLE001
            pass

    # Merge remote entries when KAIROS_MEMORY_SYNC=1 (VM-dies recovery)
    remote = _pull_from_supabase(mem.block_hash, _active_agent_id())
    if remote:
        local_timestamps = {r.timestamp for r in mem.refutations}
        local_timestamps.update(s.timestamp for s in mem.successes)
        for entry in remote:
            prov = entry.get("provenance") or {}
            ts = entry.get("added_at", "")
            if ts in local_timestamps:
                continue
            content = prov.get("content", {})
            etype = prov.get("entry_type", "")
            if etype == "refutation" and content.get("transformation_class"):
                mem.refutations.append(RefutationRecord(
                    transformation_class=content["transformation_class"],
                    claimed_delta_pct=content.get("claimed_delta_pct", 0),
                    refutation_reason=content.get("refutation_reason", ""),
                    counterexample_summary=content.get("counterexample_summary"),
                    timestamp=ts,
                ))
            elif etype == "success" and content.get("transformation_class"):
                mem.successes.append(SuccessRecord(
                    transformation_class=content["transformation_class"],
                    measured_delta_pct=content.get("measured_delta_pct", 0),
                    gold_cells=content.get("gold_cells", 0),
                    gate_cells=content.get("gate_cells", 0),
                    engine=content.get("engine", "unknown"),
                    timestamp=ts,
                ))

    return mem


def record_refutation(
    block_path: str,
    transformation_class: str,
    claimed_delta_pct: float,
    refutation_reason: str,
    counterexample_summary: str = "",
    elapsed_seconds: float = 0.0,
) -> None:
    """Record a refuted proposal. Updates synthesis floor confidence."""
    d = _memory_dir(block_path)
    mem = load_memory(block_path)

    mem.refutations.append(RefutationRecord(
        transformation_class=transformation_class,
        claimed_delta_pct=claimed_delta_pct,
        refutation_reason=refutation_reason,
        counterexample_summary=counterexample_summary,
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        elapsed_seconds=elapsed_seconds,
    ))

    (d / "refutations.json").write_text(json.dumps(
        [{"transformation_class": r.transformation_class,
          "claimed_delta_pct": r.claimed_delta_pct,
          "refutation_reason": r.refutation_reason,
          "counterexample_summary": r.counterexample_summary,
          "timestamp": r.timestamp,
          "elapsed_seconds": r.elapsed_seconds}
         for r in mem.refutations],
        indent=2,
    ))

    # Update synthesis floor confidence: 1 - 2^(-k)
    mem.consecutive_refutations += 1
    mem.synthesis_floor_confidence = 1.0 - 2.0 ** (-mem.consecutive_refutations)

    (d / "synthesis_floor.json").write_text(json.dumps({
        "consecutive_refutations": mem.consecutive_refutations,
        "confidence": round(mem.synthesis_floor_confidence, 6),
        "last_updated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }, indent=2))

    _sync_to_supabase(
        block_hash=_block_hash(block_path),
        agent_id=_active_agent_id(),
        entry_type="refutation",
        content={
            "transformation_class": transformation_class,
            "claimed_delta_pct": claimed_delta_pct,
            "refutation_reason": refutation_reason,
            "counterexample_summary": counterexample_summary,
        },
    )


def record_success(
    block_path: str,
    transformation_class: str,
    measured_delta_pct: float,
    gold_cells: int,
    gate_cells: int,
    engine: str,
    elapsed_seconds: float = 0.0,
) -> None:
    """Record a proved optimization. Resets synthesis floor."""
    d = _memory_dir(block_path)
    mem = load_memory(block_path)

    mem.successes.append(SuccessRecord(
        transformation_class=transformation_class,
        measured_delta_pct=measured_delta_pct,
        gold_cells=gold_cells,
        gate_cells=gate_cells,
        engine=engine,
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        elapsed_seconds=elapsed_seconds,
    ))

    (d / "successes.json").write_text(json.dumps(
        [{"transformation_class": s.transformation_class,
          "measured_delta_pct": s.measured_delta_pct,
          "gold_cells": s.gold_cells,
          "gate_cells": s.gate_cells,
          "engine": s.engine,
          "timestamp": s.timestamp,
          "elapsed_seconds": s.elapsed_seconds}
         for s in mem.successes],
        indent=2,
    ))

    # Success resets the consecutive refutation counter
    (d / "synthesis_floor.json").write_text(json.dumps({
        "consecutive_refutations": 0,
        "confidence": 0.0,
        "last_updated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }, indent=2))

    _sync_to_supabase(
        block_hash=_block_hash(block_path),
        agent_id=_active_agent_id(),
        entry_type="success",
        content={
            "transformation_class": transformation_class,
            "measured_delta_pct": measured_delta_pct,
            "gold_cells": gold_cells,
            "gate_cells": gate_cells,
            "engine": engine,
        },
    )


def save_encoding_conventions(
    block_path: str,
    conventions: dict[str, str],
) -> None:
    """Persist encoding conventions from analyze_block."""
    d = _memory_dir(block_path)
    (d / "encoding_conventions.json").write_text(
        json.dumps(conventions, indent=2)
    )


def _sync_to_supabase(
    block_hash: str,
    agent_id: str | None,
    entry_type: str,
    content: dict[str, Any],
    run_id: str | None = None,
    block_class: str | None = None,
) -> None:
    """Write-through to knowledge_entries table (async, best-effort).

    Per CTO decision: kairos memory uses knowledge_entries with
    source='kairos_memory'. Leverages existing pgvector + search_knowledge
    RPC. Local JSON is source of truth when Supabase is unreachable.
    """
    supabase_url = os.environ.get("SUPABASE_URL", "")
    sync_token = os.environ.get("ATHANOR_SYNC_TOKEN", "")
    if not supabase_url or not sync_token:
        return
    try:
        import urllib.request
        agent = agent_id or "global"
        text_summary = _format_entry_text(entry_type, content)
        row = json.dumps({
            "text": text_summary,
            "source": "kairos_memory",
            "tags": [
                entry_type,
                f"block:{block_hash}",
                f"agent:{agent}",
            ] + ([f"class:{block_class}"] if block_class else []),
            "added_by": agent,
            "provenance": {
                "block_hash": block_hash,
                "agent_id": agent,
                "entry_type": entry_type,
                "run_id": run_id or "",
                "block_class": block_class or "",
                "content": content,
            },
        }).encode()
        req = urllib.request.Request(
            f"{supabase_url}/rest/v1/knowledge_entries",
            data=row,
            headers={
                "apikey": sync_token,
                "Authorization": f"Bearer {sync_token}",
                "Content-Type": "application/json",
                "Prefer": "return=minimal",
            },
            method="POST",
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:  # noqa: BLE001
        pass


def _format_entry_text(entry_type: str, content: dict[str, Any]) -> str:
    """Human-readable text for knowledge_entries.text column."""
    tc = content.get("transformation_class", "unknown")
    if entry_type == "refutation":
        reason = content.get("refutation_reason", "")
        delta = content.get("claimed_delta_pct", 0)
        return (
            f"Refutation: {tc} ({delta:+.1f}% claimed) — {reason}. "
            f"Counterexample: {(content.get('counterexample_summary') or '')[:100]}"
        )
    elif entry_type == "success":
        delta = content.get("measured_delta_pct", 0)
        gc = content.get("gold_cells", "?")
        gatec = content.get("gate_cells", "?")
        engine = content.get("engine", "unknown")
        return (
            f"Success: {tc} ({delta:+.1f}%, {gc}->{gatec} cells) "
            f"via {engine}"
        )
    return f"{entry_type}: {json.dumps(content)[:200]}"


def _pull_from_supabase(
    block_hash: str,
    agent_id: str | None,
) -> list[dict[str, Any]] | None:
    """Read-merge from knowledge_entries WHERE source=kairos_memory.

    Returns entries or None if unavailable/disabled.
    Only called when KAIROS_MEMORY_SYNC=1 is set.
    """
    if not os.environ.get("KAIROS_MEMORY_SYNC"):
        return None
    try:
        supabase_url = os.environ.get("SUPABASE_URL", "")
        sync_token = os.environ.get("ATHANOR_SYNC_TOKEN", "")
        if not supabase_url or not sync_token:
            return None
        import urllib.request
        import urllib.parse
        agent = urllib.parse.quote(agent_id or "global", safe="")
        safe_hash = urllib.parse.quote(block_hash, safe="")
        url = (
            f"{supabase_url}/rest/v1/knowledge_entries"
            f"?source=eq.kairos_memory"
            f"&tags=cs.{{block:{safe_hash},agent:{agent}}}"
            f"&select=text,provenance,added_at"
            f"&order=added_at.desc"
            f"&limit=50"
        )
        req = urllib.request.Request(url, headers={
            "apikey": sync_token,
            "Authorization": f"Bearer {sync_token}",
        })
        with urllib.request.urlopen(req, timeout=5) as resp:
            entries: list[dict[str, Any]] = json.loads(resp.read())
            return entries
    except Exception:  # noqa: BLE001
        return None


def _age_weight(timestamp_str: str, half_life_days: float = 14.0) -> float:
    """Exponential decay weight based on record age. Recent = 1.0, old = 0."""
    if not timestamp_str:
        return 0.5
    try:
        import datetime
        recorded = datetime.datetime.strptime(
            timestamp_str, "%Y-%m-%dT%H:%M:%SZ"
        ).replace(tzinfo=datetime.timezone.utc)
        now = datetime.datetime.now(datetime.timezone.utc)
        age_days = (now - recorded).total_seconds() / 86400.0
        import math
        return math.exp(-0.693 * age_days / half_life_days)
    except Exception:  # noqa: BLE001
        return 0.5


def _all_block_dirs() -> list[Path]:
    """Collect block dirs. Respects sharing mode:
    - org (default): all agent namespaces + global
    - private: only current agent's namespace
    """
    dirs: list[Path] = []
    if _sharing_mode() == "private":
        base = _memory_base()
        if base.is_dir():
            for entry in base.iterdir():
                if entry.is_dir() and len(entry.name) == 16:
                    dirs.append(entry)
        return dirs

    if not MEMORY_ROOT.is_dir():
        return dirs
    for entry in MEMORY_ROOT.iterdir():
        if not entry.is_dir():
            continue
        if entry.name.startswith("agent-"):
            for sub in entry.iterdir():
                if sub.is_dir() and not sub.name.startswith("agent-"):
                    dirs.append(sub)
        elif len(entry.name) == 16:
            dirs.append(entry)
    return dirs


def cross_block_suggestions(
    block_class: str,
    exclude_hash: str = "",
) -> list[dict[str, Any]]:
    """Find successful transformations on similar blocks.

    Searches across ALL agent namespaces so agents benefit from each
    other's successes. Returns suggestions sorted by recency-weighted delta.
    """
    suggestions: list[dict[str, Any]] = []

    for block_dir in _all_block_dirs():
        if block_dir.name == exclude_hash:
            continue

        meta_path = block_dir / "block_class.json"
        if not meta_path.is_file():
            continue
        try:
            meta = json.loads(meta_path.read_text())
            if meta.get("block_class") != block_class:
                continue
        except Exception:  # noqa: BLE001
            continue

        succ_path = block_dir / "successes.json"
        if not succ_path.is_file():
            continue
        try:
            records = json.loads(succ_path.read_text())
            for s in records:
                weight = _age_weight(s.get("timestamp", ""))
                suggestions.append({
                    "transformation_class": s["transformation_class"],
                    "measured_delta_pct": s["measured_delta_pct"],
                    "engine": s.get("engine", "unknown"),
                    "source_block_hash": block_dir.name,
                    "recency_weight": round(weight, 3),
                    "weighted_delta": round(s["measured_delta_pct"] * weight, 2),
                })
        except Exception:  # noqa: BLE001
            continue

    suggestions.sort(key=lambda x: x["weighted_delta"])
    return suggestions[:5]


def tag_block_class(inputs_dir: Path, sig: dict[str, Any]) -> str | None:
    """Detect and persist block class from gold RTL. Returns class or None."""
    from kairos.sec.closed_loop.prompt_composer import _detect_block_class
    gold_sv = sig.get("gold_sv")
    if not gold_sv:
        return None
    gold_path = inputs_dir / gold_sv
    if not gold_path.is_file():
        return None
    gold_text = gold_path.read_text()
    bc = _detect_block_class(gold_text, sig)
    if bc:
        save_block_class(str(gold_path), bc)
    return bc


def save_block_class(block_path: str, block_class: str) -> None:
    """Tag a block with its detected class for cross-block queries."""
    d = _memory_dir(block_path)
    (d / "block_class.json").write_text(json.dumps({
        "block_class": block_class,
        "tagged_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }, indent=2))


def format_cross_block_context(
    block_class: str,
    exclude_hash: str = "",
) -> str:
    """Format cross-block suggestions for the proposer prompt."""
    suggestions = cross_block_suggestions(block_class, exclude_hash)
    if not suggestions:
        return ""
    parts = ["## CROSS-BLOCK INSIGHTS (from similar blocks)"]
    for s in suggestions:
        parts.append(
            f"- {s['transformation_class']}: {s['measured_delta_pct']:+.1f}% "
            f"on similar {block_class} block (confidence: {s['recency_weight']:.0%})"
        )
    return "\n".join(parts)


def _load_global_memory() -> list[dict[str, Any]]:
    """Load global-scope memories (universal, never expire)."""
    global_dir = _memory_base() / "_global"
    if not global_dir.is_dir():
        return []
    entries: list[dict[str, Any]] = []
    for f in sorted(global_dir.glob("*.json")):
        try:
            data = json.loads(f.read_text())
            if data.get("scope") == "global":
                entries.append(data)
        except Exception:  # noqa: BLE001
            pass
    return entries


def format_for_proposer_scoped(
    block_path: str,
    block_class: str | None = None,
) -> str:
    """Scope-aware proposer context: global → class → block.

    The proposer sees cross-block patterns before block-specific history
    so it can apply general lessons before specializing.

    Forward-pin for qa's scope-tag auto-capture (ATH scope tags).
    Falls back gracefully when scope tags are absent.
    """
    sections: list[str] = []

    # 1. Global scope — universal patterns, never expire
    global_entries = _load_global_memory()
    if global_entries:
        sections.append("## GLOBAL PATTERNS (apply to all blocks)")
        for e in global_entries[-5:]:
            prov = e.get("provenance", {})
            content = prov.get("content", {})
            tc = content.get("transformation_class", "")
            reason = content.get("lesson", content.get("refutation_reason", ""))
            if tc and reason:
                sections.append(f"- {tc}: {reason}")
        sections.append("")

    # 2. Class scope — cross-block insights for this block type
    if block_class:
        mem = load_memory(block_path)
        class_ctx = format_cross_block_context(block_class, exclude_hash=mem.block_hash)
        if class_ctx:
            sections.append(class_ctx)
            sections.append("")

    # 3. Block scope — block-specific refutations + successes
    mem = load_memory(block_path)
    block_ctx = mem.format_for_proposer()
    if block_ctx:
        sections.append(block_ctx)

    return "\n".join(sections) if sections else ""


_COLD_START_SECONDS: dict[str, tuple[float, float]] = {
    "ecc": (45, 180),
    "alu": (30, 120),
    "fifo": (60, 300),
    "arbiter": (30, 150),
    "security": (60, 240),
    "compute": (60, 300),
    "flow_control": (30, 120),
    "generic": (45, 240),
}


def timing_estimate_for_block(
    block_class: str,
    cell_count: int | None = None,
) -> dict[str, Any]:
    """Pre-run timing estimate from prior run history.

    Returns dict with estimated_seconds, confidence, basis, and band.
    Cell-count matching uses ±20% band.
    Confidence: high (>=5 prior), medium (3-4), low (<3 or cold-start).
    """
    matching_times: list[float] = []
    total_scanned = 0

    for block_dir in _all_block_dirs():
        meta_path = block_dir / "block_class.json"
        if not meta_path.is_file():
            continue
        try:
            meta = json.loads(meta_path.read_text())
            if meta.get("block_class") != block_class:
                continue
        except Exception:  # noqa: BLE001
            continue

        successes_path = block_dir / "successes.json"
        refutations_path = block_dir / "refutations.json"

        for path in (successes_path, refutations_path):
            if not path.is_file():
                continue
            try:
                records = json.loads(path.read_text())
            except Exception:  # noqa: BLE001
                continue
            for rec in records:
                elapsed = rec.get("elapsed_seconds", 0)
                if elapsed <= 0:
                    continue
                total_scanned += 1
                if cell_count is not None:
                    rec_cells = rec.get("gold_cells", 0)
                    if rec_cells and abs(rec_cells - cell_count) / max(cell_count, 1) > 0.2:
                        continue
                matching_times.append(elapsed)

    if matching_times:
        n = len(matching_times)
        mean = sum(matching_times) / n
        sorted_times = sorted(matching_times)
        p90_idx = min(int(n * 0.9), n - 1)
        p90 = sorted_times[p90_idx]
        if n >= 5:
            confidence = "high"
        elif n >= 3:
            confidence = "medium"
        else:
            confidence = "low"
        band = _time_band(p90)
        return {
            "estimated_seconds": round(p90, 1),
            "confidence": confidence,
            "basis": f"{n} prior runs, mean={mean:.0f}s, p90={p90:.0f}s",
            "band": band,
        }

    lo, hi = _COLD_START_SECONDS.get(block_class, (45, 240))
    if cell_count is not None:
        scale = max(0.5, min(3.0, cell_count / 1000))
        lo = lo * scale
        hi = hi * scale
    band = _time_band(hi)
    return {
        "estimated_seconds": round(hi, 1),
        "confidence": "low",
        "basis": f"cold-start domain-typical for {block_class}"
                 + (f" ({cell_count} cells)" if cell_count else ""),
        "band": band,
    }


def _time_band(seconds: float) -> str:
    if seconds < 60:
        return "quick"
    if seconds < 300:
        return "medium"
    if seconds < 900:
        return "long"
    return "very-long"


def record_iteration_outcome(
    gold_path: str,
    outcome: str,
    outcome_reason: str,
    transformation_class: str,
    claimed_delta_pct: float,
    gold_cells: int | None,
    gate_cells: int | None,
    engine: str,
    elapsed_seconds: float = 0.0,
    counterexample_summary: str = "",
) -> None:
    """Record a proposal outcome (success or refutation) to block memory.

    Extracted from _orchestrator.py — consolidates the 2 callsites that
    route to record_success or record_refutation based on outcome.
    """
    if not gold_path:
        return
    if outcome == "accepted" and gold_cells and gate_cells:
        record_success(
            block_path=gold_path,
            transformation_class=transformation_class,
            measured_delta_pct=round(
                (gate_cells - gold_cells) / gold_cells * 100, 2
            ) if gold_cells else 0.0,
            gold_cells=gold_cells,
            gate_cells=gate_cells,
            engine=engine,
            elapsed_seconds=elapsed_seconds,
        )
    elif outcome in ("refuted", "inconclusive"):
        record_refutation(
            block_path=gold_path,
            transformation_class=transformation_class,
            claimed_delta_pct=claimed_delta_pct,
            refutation_reason=outcome_reason[:500],
            counterexample_summary=counterexample_summary[:200] if counterexample_summary else "",
            elapsed_seconds=elapsed_seconds,
        )


def load_and_validate_memory(
    bundle_path: Path,
    sig: dict[str, Any],
) -> tuple[str, int, bool]:
    """Load block memory and return (context_str, total_entries, at_floor).

    Extracted from _orchestrator.py ATH-1168 anti-forgetting gate.
    Consolidates memory loading + validation + floor detection into
    one call the orchestrator invokes before proposing.
    """
    gold_path_obj = (bundle_path / sig["gold_sv"]) if sig.get("gold_sv") else None
    if gold_path_obj is None:
        return "", 0, False
    if not gold_path_obj.resolve().is_relative_to(bundle_path.resolve()):
        return "", 0, False
    gold_path = str(gold_path_obj)
    if not gold_path:
        return "", 0, False

    mem = load_memory(gold_path)
    total = len(mem.refutations) + len(mem.successes)
    if total == 0:
        return "", 0, False

    context = mem.format_for_proposer()
    return context, total, mem.is_at_floor()


__all__ = [
    "BlockMemory",
    "cross_block_suggestions",
    "format_cross_block_context",
    "format_for_proposer_scoped",
    "load_and_validate_memory",
    "load_memory",
    "load_memory_by_content",
    "record_refutation",
    "record_success",
    "save_block_class",
    "save_encoding_conventions",
    "timing_estimate_for_block",
]
