r"""ATH-1090 Phase 2 — ACL2 discharge fallback for closed-loop SEC.

Per Aidan 2026-05-07 directive: integrate ACL2 + Lean + full-CEGAR into
the entire pipeline. This module ships the ACL2 escalation step
(integration A.1 in CTO's split): when EBMC k-induction stalls and
``invariant_gen`` CEGAR exhausts attempts, the orchestrator can escalate
to ACL2 as the deeper hammer. ACL2's industrially-pedigreed FM9801
flushing technique handles flop-state refinement EBMC can't close at
practical k-bounds.

If ACL2 closes, the customer cert's ``discharge_engine`` reads
``"ACL2 refinement"`` instead of ``"EBMC k-induction"``. Customer-trust
signal aligns with the customer's chief-architect ask — industrial provenance
on the closing engine.

## Public API

* :func:`acl2_discharge` — entry. Generates a lisp script from an
  obligation set + gold + gate, calls :func:`kairos.acl2.run_acl2`,
  returns :class:`Acl2DischargeResult`.
* :class:`Acl2DischargeResult` — frozen dataclass; per-obligation
  ACL2 verdict + lisp-script-path + run_acl2 wall-clock + Q.E.D. count.

## Phase 2 scope (this PR)

Skeleton + the ``run_acl2`` wrapper + a minimal hand-written script
fixture exercising the round-trip. Real SV-to-ACL2 translation
(generating the lisp from gold/gate + obligation literals) ships in
a follow-up commit once the kairos.acl2.parse_sv path's coverage on
customer RTL is measured. Today's commit pins the orchestrator-side
contract so the integration A.1 hookup can land symmetrically with
the Lean integration B.1.

## Cross-refs

* ATH-1090 (parent ticket; A.1=this ACL2 discharge, B.1=Lean
  formalize on PROVED witness).
* ATH-1063 closed-loop arc.
* :mod:`kairos.acl2` (engine wrapper this delegates to).
* Aidan 2026-05-07 directive (slack ts 1778160820): ACL2 + Lean +
  full-CEGAR integration.
"""
from __future__ import annotations

import shutil
import time
from dataclasses import dataclass, asdict
from pathlib import Path


@dataclass(frozen=True)
class Acl2DischargeAttempt:
    """One ACL2 thm form's outcome.

    Mirrors smoke-validation's per-attempt row pattern + the
    inner_retry_history shape so the platform render can drill down
    per-obligation for the customer's audit.
    """

    obligation_label: str
    """The EBMC property label this ACL2 thm form attempts to discharge."""

    thm_status: str
    """``"PROVED"`` (Q.E.D. seen + not in failed list), ``"REFUTED"``
    (in failed list), ``"INCONCLUSIVE"`` (timeout / no Q.E.D. and no
    failure marker), or ``"SETUP_ERROR"`` (binary missing / parse
    error / unreadable script)."""

    elapsed_sec: float
    """ACL2 subprocess wall-clock for this thm form. 0.0 on
    ``SETUP_ERROR``."""

    acl2_log_path: str | None = None
    """Path to the ``run_acl2`` stdout/stderr capture for customer-tarball
    reproduction. ``None`` on setup-class failures."""

    fail_detail: str | None = None
    """Human-readable detail on REFUTED / INCONCLUSIVE / SETUP_ERROR."""


@dataclass(frozen=True)
class Acl2DischargeResult:
    """Full ACL2 discharge outcome — what the orchestrator + cert payload consume.

    Attributes
    ----------
    bundle_path:
        Bundle directory the discharge ran against.
    target_module:
        Top-level module name.
    obligation_set:
        Tuple of EBMC property labels passed in (mirrored on the result
        for cert-tarball reproducibility).
    overall_status:
        ``"PROVED"`` when every thm form's status is PROVED;
        ``"REFUTED"`` when any thm form refuted; ``"INCONCLUSIVE"`` on
        any inconclusive without refute; ``"SETUP_ERROR"`` when the
        ACL2 binary couldn't be found or the script was unreadable.
    discharge_engine:
        Always ``"ACL2 refinement"`` on this path. Surfaced verbatim
        on the cert payload so the customer reads which engine closed
        each obligation. (Compare with ``"EBMC k-induction"`` /
        ``"EBMC BMC"`` for non-ACL2 closure paths.)
    elapsed_sec_total:
        Wall-clock sum across every thm form attempt.
    timestamp:
        UTC ISO-8601 of discharge start.
    attempts:
        Tuple of :class:`Acl2DischargeAttempt` — one per obligation.
    script_path:
        Absolute path to the generated lisp script, archived in the
        cert tarball for customer self-audit (matches the
        engine-output-verbatim discipline from Aidan 2026-05-06).
    """

    bundle_path: str
    target_module: str
    obligation_set: tuple[str, ...]
    overall_status: str
    discharge_engine: str
    elapsed_sec_total: float
    timestamp: str
    attempts: tuple[Acl2DischargeAttempt, ...]
    script_path: str | None

    def to_dict(self) -> dict[str, object]:
        """JSON-serializable dict — for emit + cert-tarball + MCP return."""
        return asdict(self)


def _acl2_present() -> bool:
    """Honest binary-presence probe so callers can skip-clean."""
    return (
        shutil.which("acl2") is not None
        or shutil.which("saved_acl2") is not None
    )


def acl2_discharge(
    *,
    bundle_path: Path | str,
    target_module: str,
    obligation_set: tuple[str, ...] | list[str],
    script_path: Path | str,
    timeout_sec: int = 600,
) -> Acl2DischargeResult:
    """Run ACL2 against a pre-generated lisp script, return per-obligation discharge.

    Phase 2 scope: caller supplies the lisp script (``script_path``).
    The script is expected to define one ``thm`` form per obligation
    label, where the thm name matches the obligation label
    (snake_cased) so :func:`_parse_acl2_outcome` can match thm name to
    obligation label. The orchestrator's lisp-from-EBMC-obligations
    generator lands in a follow-up commit; today's surface unblocks
    the integration A.1 wiring.

    Caller responsibilities (Phase 2):

    1. Build the lisp script with one ``thm`` per obligation label.
    2. Pass the script path + obligation labels here.
    3. Inspect the result; on ``overall_status="PROVED"`` the cert
       payload's ``discharge_engine`` field reads
       ``"ACL2 refinement"``.

    Parameters
    ----------
    bundle_path:
        Bundle directory the discharge ran against (recorded for
        cert-tarball reproducibility; not read in Phase 2).
    target_module:
        Top-level module name (recorded; not read in Phase 2).
    obligation_set:
        Tuple of EBMC property labels — one per ``thm`` form in the
        script. Each label must be a valid lisp-symbol-shaped name.
    script_path:
        Path to the lisp script with ``thm`` forms.
    timeout_sec:
        Wall-clock cap on the ACL2 subprocess. Default 600s
        (ACL2's industrial proofs are slow). Per Aidan
        ``give-each-agent-time`` directive; not the EBMC default
        120s.

    Returns
    -------
    :class:`Acl2DischargeResult` partitioned per-obligation.
    """
    started_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    started = time.monotonic()

    bundle = Path(bundle_path)
    script_resolved = Path(script_path).resolve()
    obligations = tuple(obligation_set)

    if not _acl2_present():
        return _setup_error_result(
            bundle=bundle,
            target_module=target_module,
            obligations=obligations,
            elapsed=time.monotonic() - started,
            started_at=started_at,
            detail="acl2 binary not found on $PATH",
            script_path=str(script_resolved) if script_resolved.exists() else None,
        )

    if not script_resolved.is_file():
        return _setup_error_result(
            bundle=bundle,
            target_module=target_module,
            obligations=obligations,
            elapsed=time.monotonic() - started,
            started_at=started_at,
            detail=f"script not found: {script_resolved}",
            script_path=None,
        )

    from kairos.acl2 import run_acl2

    raw = run_acl2(script_resolved, timeout_sec=timeout_sec)
    log_path = (
        script_resolved.with_suffix(".acl2.log")
        if not raw.timed_out
        else None
    )
    if log_path is not None:
        log_path.write_text(
            raw.stdout + "\n--- STDERR ---\n" + raw.stderr
        )

    # Per-obligation outcome: thm name in obligations is matched against
    # raw.theorems_proved + raw.theorems_failed lists.
    proved_set = {t.lower() for t in raw.theorems_proved}
    failed_set = {t.lower() for t in raw.theorems_failed}
    attempts: list[Acl2DischargeAttempt] = []
    for ob in obligations:
        ob_lower = ob.lower()
        if ob_lower in proved_set:
            status = "PROVED"
            detail = None
        elif ob_lower in failed_set:
            status = "REFUTED"
            detail = "ACL2 reported FAILED on this thm"
        elif raw.timed_out:
            status = "INCONCLUSIVE"
            detail = f"ACL2 timed out after {timeout_sec}s"
        else:
            status = "INCONCLUSIVE"
            detail = (
                f"ACL2 produced no Q.E.D. and no FAILED for {ob!r}; "
                "thm form may be missing from the script"
            )
        attempts.append(Acl2DischargeAttempt(
            obligation_label=ob,
            thm_status=status,
            elapsed_sec=raw.elapsed_sec / max(len(obligations), 1),
            acl2_log_path=str(log_path) if log_path else None,
            fail_detail=detail,
        ))

    statuses = [a.thm_status for a in attempts]
    if not statuses:
        overall = "INCONCLUSIVE"
    elif all(s == "PROVED" for s in statuses):
        overall = "PROVED"
    elif "REFUTED" in statuses:
        overall = "REFUTED"
    else:
        overall = "INCONCLUSIVE"

    return Acl2DischargeResult(
        bundle_path=str(bundle.resolve()),
        target_module=target_module,
        obligation_set=obligations,
        overall_status=overall,
        discharge_engine="ACL2 refinement",
        elapsed_sec_total=time.monotonic() - started,
        timestamp=started_at,
        attempts=tuple(attempts),
        script_path=str(script_resolved),
    )


def _setup_error_result(
    *,
    bundle: Path,
    target_module: str,
    obligations: tuple[str, ...],
    elapsed: float,
    started_at: str,
    detail: str,
    script_path: str | None,
) -> Acl2DischargeResult:
    """Build a SETUP_ERROR result — every obligation marked SETUP_ERROR + overall."""
    attempts = tuple(
        Acl2DischargeAttempt(
            obligation_label=ob,
            thm_status="SETUP_ERROR",
            elapsed_sec=0.0,
            acl2_log_path=None,
            fail_detail=detail,
        )
        for ob in obligations
    )
    return Acl2DischargeResult(
        bundle_path=str(bundle.resolve()) if bundle.exists() else str(bundle),
        target_module=target_module,
        obligation_set=obligations,
        overall_status="SETUP_ERROR",
        discharge_engine="ACL2 refinement",
        elapsed_sec_total=elapsed,
        timestamp=started_at,
        attempts=attempts,
        script_path=script_path,
    )


__all__ = [
    "Acl2DischargeAttempt",
    "Acl2DischargeResult",
    "acl2_discharge",
]
