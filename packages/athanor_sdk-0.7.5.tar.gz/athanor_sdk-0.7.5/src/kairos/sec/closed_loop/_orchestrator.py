"""Closed-loop propose-verify-adjust orchestrator (ATH-991, C v0).

.. note:: --verbose logging

   When ``logging.getLogger("kairos").level <= INFO``, the orchestrator
   prints real-time progress: phase headers, proposer model + class,
   verifier engine + verdict, per-iteration timing. Activated via
   ``kairos optimize --verbose``.

State machine that drives the autonomous iteration loop the
the customer's chief architect ask:

* takes a target RTL block + (optional) an openSTA report;
* runs the ranker (:mod:`._ranker`) to score targets;
* for each target in order, runs the proposer (:mod:`._proposer`)
  to generate candidate optimizations;
* for each proposal, runs SEC verification (:func:`kairos.sec.verify_sec`)
  in dual mode (BMC + k-induction);
* on INCONCLUSIVE under k-induction, hands off to the
  invariant-gen harness (:mod:`._invariant_gen`) for a bridge
  invariant + re-verification;
* halts when a verified-equivalent-and-area-reduced variant
  lands, OR a documented halt condition fires (max iterations,
  hard-refute, human-review-needed).

Trace event emission goes through :mod:`kairos.observe` so the
state machine produces one parent ``solve_run`` row plus per-iteration
child ``sdk_agent_events``. Platform's ATH-993 surface
(``/analytics/area-optimization``) consumes the
per-iteration emits to render the delta-cell + state-bucket dashboard
for the customer (per CTO tone-pass + ATH-987 honest-framing
discipline).
"""
from __future__ import annotations

import logging as _logging

_log = _logging.getLogger("kairos.optimize")


def _vlog(msg: str) -> None:
    """Verbose log: prints when kairos optimize --verbose is active."""
    _log.info(msg)


_dialogue = None


def _set_dialogue(d: Any) -> None:
    global _dialogue
    _dialogue = d



import json as _json
import os
import shutil
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

from kairos.model_presets import DEFAULT_SEC_PROPOSER_MODEL
from kairos.sec.closed_loop._orchestrator_types import (
    ClosedLoopResult,
    DisplayMode,
    IterationRecord,
    IterationState,
    OrchestratorHaltReason,
    OrchestratorRunResult,
    VerificationContext,
    derive_display_mode,
    _sanitize_error_for_customer,
    _poll_agent_messages,
)



# ---------------------------------------------------------------------------
# Iteration-arc helpers (moved from examples/customer/.../demo_driver.py per
# Phase 0a-wiring commit 2a). The library now owns the proposer-verifier-
# bridge-iterate emit chain so other surfaces (MCP `kairos_optimize_block`,
# in-process callers, future cert-mint scripts) reuse the same code path
# the v2.7 demo dogfooded. Path constants that used to live as module-level
# `INPUTS_DIR` / `WORK_DIR` are now explicit parameters.
# ---------------------------------------------------------------------------


from kairos.sec.closed_loop.verify_pipeline import (
    run_yosys_equiv_verification as _run_yosys_equiv_verification,
)


def _emit_iteration_arc_for_proposal(
    *,
    obs: Any,
    iteration_index: int,
    proposal: Any,  # TransformationProposal
    parent_run_id: str,
    sig: dict[str, Any],
    inputs_dir: Path,
    work_dir: Path,
    bound: int,
    timeout_sec: int,
    repo_root: Path | None = None,
    max_proposer_inner_retries: int = 5,
    proposer_model: str = DEFAULT_SEC_PROPOSER_MODEL,
    proposer_timeout_sec: int = 360,
    custom_engine: str | None = None,
) -> dict[str, Any]:
    """Run one proposal end-to-end + emit the iteration-arc event chain.

    Returns a dict summarising the outcome for cert-prose aggregation.

    Parameters
    ----------
    inputs_dir:
        Directory containing the original signature.gold_sv file. Used as
        the source for shutil.copy into the per-iteration bundle.
    work_dir:
        Directory under which per-iteration bundles
        (``iter_<n>_bundle/``) and tmp gate files are written.
    repo_root:
        Optional path used as the anchor for relative-path display in
        emitted event payloads (``gate_sv_path`` field). When ``None``,
        absolute paths are emitted.
    """
    from kairos.sec import verify_sec
    from kairos.sec.closed_loop import generate_invariant
    from kairos.sec._adapter import _ports_from_signature

    def _safe_emit(event_type: str, **kwargs: Any) -> None:
        if obs is not None:
            obs.emit(event_type, **kwargs)

    ports = _ports_from_signature(sig)
    gold_module = sig["gold_module"]
    gate_module = sig["gate_module"]

    # Write the LLM's proposed gate_sv to a tmp file inside work_dir.
    # Module-rename the proposed gate to gate_module if needed (LLM may
    # have kept the gold module name).
    proposed_gate_text = proposal.gate_sv
    if (
        f"module {gold_module}" in proposed_gate_text
        and f"module {gate_module}" not in proposed_gate_text
    ):
        proposed_gate_text = proposed_gate_text.replace(
            f"module {gold_module}",
            f"module {gate_module}",
            1,
        )
        proposed_gate_text = proposed_gate_text.replace(
            f"endmodule // {gold_module}",
            f"endmodule // {gate_module}",
        )

    from kairos.sv_validate import validate_llm_verilog, yosys_parse_check
    validation = validate_llm_verilog(proposed_gate_text, expected_module=gate_module)
    if not validation.valid:
        raise ValueError(f"LLM output rejected: {'; '.join(validation.errors)}")
    parse_check = yosys_parse_check(proposed_gate_text)
    if not parse_check.valid:
        raise ValueError(f"LLM output rejected (yosys parse): {'; '.join(parse_check.errors)}")

    work_dir.mkdir(parents=True, exist_ok=True)
    tmp_gate = work_dir / f"iter_{iteration_index}_proposed_gate.v"
    tmp_gate.write_text(proposed_gate_text)

    from kairos.sec.closed_loop.verify_pipeline import prepare_iteration_bundle
    iter_bundle, dep_files_iter = prepare_iteration_bundle(
        sig=sig, inputs_dir=inputs_dir, work_dir=work_dir,
        iteration_index=iteration_index, proposed_gate_text=proposed_gate_text,
    )

    # ATH-1076: yosys-elaborate-first preprocessing. EBMC 5.10's SV
    # parser doesn't accept several constructs yosys handles cleanly
    # (genvar `++`, `\`include` inside `\`ifdef`, `logic` keyword,
    # named generate blocks). Elaborate gold + gate via yosys to plain
    # Verilog before passing to verify_sec. Only fires when
    # signature.dep_files is non-empty (multi-module bundles); single-
    # file bundles like the v2.7 toy_fifo_chain skip elaboration to
    # preserve byte-stable cert reproduction.
    # Use pre-elaborated gold for verification when available (params
    # already baked in, clean Verilog-2001). Fall back to raw gold_sv.
    _gold_elab_sv = sig.get("_gold_elab_sv")
    gold_for_verify = (
        iter_bundle / _gold_elab_sv if _gold_elab_sv
        else iter_bundle / sig["gold_sv"]
    )
    gate_for_verify = iter_bundle / "gate.v"
    deps_for_verify: list[Path] | None = dep_files_iter or None
    from kairos.sec.closed_loop.verify_pipeline import elaborate_for_verification
    elab = elaborate_for_verification(
        sig=sig, iter_bundle=iter_bundle, dep_files_iter=dep_files_iter,
        gold_for_verify=gold_for_verify, gate_for_verify=gate_for_verify,
        gold_module=gold_module, gate_module=gate_module, timeout_sec=timeout_sec,
    )
    if elab.get("errored"):
        _safe_emit("verify_attempt", run_subtype="theorem_proving", payload={
            "iteration_index": iteration_index, "parent_run_id": parent_run_id,
            "engine": "ebmc_bmc", "bound": 0, "result": "SETUP_ERROR",
            "elapsed_sec": 0.0, "diagnostic_class": "setup_error",
            "detail": elab["error_detail"],
        })
        return {
            "iteration_index": iteration_index, "outcome": "errored",
            "outcome_reason": elab["error_reason"],
            "transformation_class": proposal.transformation_class.value,
            "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
            "bridges_used": [], "property_verdicts": {},
        }
    gold_for_verify = elab["gold_path"]
    gate_for_verify = elab["gate_path"]
    deps_for_verify = elab["deps"]
    param_overrides = elab["param_overrides"]

    if repo_root is not None:
        try:
            gate_sv_path_field = str(tmp_gate.relative_to(repo_root))
        except ValueError:
            gate_sv_path_field = str(tmp_gate)
    else:
        gate_sv_path_field = str(tmp_gate)

    _safe_emit(
        "transformation_proposed",
        run_subtype="theorem_proving",
        payload={
            "iteration_index": iteration_index,
            "parent_run_id": parent_run_id,
            "transformation_class": proposal.transformation_class.value,
            "transformation_description": (
                proposal.rationale.split("\n\n", 1)[0]
                if "\n\n" in proposal.rationale
                else proposal.rationale[:160]
            ),
            "proposer_model": proposer_model,
            "estimated_area_delta_pct": proposal.claimed_area_delta_pct,
            "gate_sv_path": gate_sv_path_field,
            # ATH-1083 Phase A: surface concrete_for_sec parameter overrides
            # so the platform-side IterationRow can render the 4-way honest-
            # framing distinction (verbatim / silent / partial WARN / full WARN).
            # None when sig.parameters carries no concrete_for_sec entries.
            "parameter_overrides": (param_overrides or None),
            # Disambiguates parameter-free RTL (b) from parameterized-RTL-
            # without-overrides (c). count = len(sig.parameters) regardless
            # of whether each entry has concrete_for_sec set. Platform reads
            # count + parameter_overrides.keys() to compute partial vs full
            # WARN. Per platform render-side flag on PR #532 scope-pass.
            "rtl_parameter_count": len(sig.get("parameters", []) or []),
        },
    )

    # Pre-verification gates (verify_pipeline.py)
    from kairos.sec.closed_loop.verify_pipeline import (
        check_structural_gate,
        check_toggle_power_gate,
        select_engine,
    )
    gate_passes, gold_cells_pre, gate_cells_pre = check_structural_gate(
        gold_for_verify, gate_for_verify, gold_module, gate_module,
    )
    if not gate_passes:
        return {
            "iteration_index": iteration_index,
            "outcome": "inconclusive",
            "outcome_reason": (
                f"structural_gate_rejected: gate ({gate_cells_pre} cells) "
                f">= gold ({gold_cells_pre} cells), delta={round((gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 1) if gold_cells_pre else '?'}%. "
                f"Yosys synthesis undid the proposed change — "
                f"the optimization is cosmetic (yosys ABC already applies it). "
                f"Try a fundamentally different strategy: encoding swap, "
                f"FSM re-encoding, register sharing, or logic restructuring "
                f"that yosys cannot discover on its own."
            ),
            "transformation_class": proposal.transformation_class.value,
            "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
            "bridges_used": [],
            "property_verdicts": {},
        }

    if gold_cells_pre and gate_cells_pre and gate_cells_pre < gold_cells_pre:
        tp_passes, tp = check_toggle_power_gate(
            gold_for_verify, gate_for_verify, gold_module, gate_module,
            sig, iter_bundle,
        )
        if not tp_passes:
            return {
                "iteration_index": iteration_index,
                "outcome": "inconclusive",
                "outcome_reason": (
                    f"toggle_power_gate_rejected: gate toggles "
                    f"{tp['toggle_delta_pct']:+.1f}% vs gold. "
                    f"Area improved but power regressed significantly."
                ),
                "transformation_class": proposal.transformation_class.value,
                "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
                "bridges_used": [],
                "property_verdicts": {},
            }

    if gold_cells_pre and gate_cells_pre and gate_cells_pre < gold_cells_pre:
        from kairos.sec.closed_loop.verify_pipeline import check_timing_gate
        timing_passes, timing_result = check_timing_gate(
            gold_for_verify, gate_for_verify, gold_module, gate_module,
            deps=deps_for_verify,
        )
        if not timing_passes:
            return {
                "iteration_index": iteration_index,
                "outcome": "inconclusive",
                "outcome_reason": (
                    f"timing_gate_rejected: gate delay exceeds gold by "
                    f"{timing_result.get('delay_delta_pct', '?')}%. "
                    f"Area improved but timing regressed."
                ),
                "transformation_class": proposal.transformation_class.value,
                "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
                "bridges_used": [],
                "property_verdicts": {},
            }

    try:
        from kairos.sec.closed_loop.block_memory import tag_block_class
        tag_block_class(inputs_dir, sig)
    except Exception:  # noqa: BLE001
        pass

    # Engine selection — custom engine overrides auto-detect
    if custom_engine:
        from kairos.sec.closed_loop.engine_registry import get_registry
        reg = get_registry()
        eng = reg.get(custom_engine)
        if eng is None:
            raise ValueError(
                f"Custom engine '{custom_engine}' not registered. "
                f"Call kairos.register_engine('{custom_engine}', your_engine) first."
            )
        _vlog(f"  Custom engine: {custom_engine}")
        t0 = time.time()
        custom_result = eng.callable(
            gold_path=gold_for_verify,
            gate_path=gate_for_verify,
            gold_module=gold_module,
            gate_module=gate_module,
            timeout_sec=timeout_sec,
        )
        elapsed = time.time() - t0
        proved = bool(custom_result.get("proved"))
        refuted = bool(custom_result.get("refuted"))
        result_str = "PASS" if proved else "FAIL" if refuted else "INCONCLUSIVE"
        property_verdicts = {custom_engine: result_str}
        bmc_result_data: dict[str, Any] = {
            "iteration_index": iteration_index,
            "parent_run_id": parent_run_id,
            "engine": custom_engine,
            "bound": 0,
            "elapsed_sec": elapsed,
            "result": result_str,
            "detail": custom_result.get("detail", ""),
            "diagnostic_class": f"custom_{custom_engine}",
        }
        _safe_emit("verify_attempt", run_subtype="theorem_proving", payload=bmc_result_data)
        if proved:
            outcome = "accepted"
            outcome_reason = f"{custom_engine} proved equivalence"
        elif refuted:
            outcome = "inconclusive"
            outcome_reason = f"{custom_engine} refuted: {custom_result.get('detail', '')}"
        else:
            outcome = "inconclusive"
            outcome_reason = f"{custom_engine} inconclusive: {custom_result.get('detail', '')}"
        return {
            "iteration_index": iteration_index,
            "outcome": outcome,
            "outcome_reason": outcome_reason,
            "transformation_class": proposal.transformation_class.value,
            "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
            "bridges_used": [],
            "property_verdicts": property_verdicts,
            "gold_cells": gold_cells_pre,
            "gate_cells": gate_cells_pre,
            "measured_delta_pct": (
                round((gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2)
                if gold_cells_pre and gate_cells_pre else None
            ),
        }

    combo_only = select_engine(sig) == "combo"
    use_yosys_equiv = True  # yosys equiv handles both combo and sequential (with async2sync)
    _vlog(f"  [engine] use_yosys_equiv={use_yosys_equiv}, gold={iter_bundle / sig['gold_sv']}, gate={iter_bundle / 'gate.v'}")
    if use_yosys_equiv:
        _iter_result = _run_yosys_equiv_verification(
            sig=sig,
            iter_bundle=iter_bundle,
            inputs_dir=inputs_dir,
            gold_for_verify=gold_for_verify,
            gate_for_verify=gate_for_verify,
            gold_module=gold_module,
            gate_module=gate_module,
            deps_for_verify=deps_for_verify,
            timeout_sec=timeout_sec,
            bound=bound,
            ports=ports,
            iteration_index=iteration_index,
            parent_run_id=parent_run_id,
            proposal=proposal,
            gold_cells_pre=gold_cells_pre,
            gate_cells_pre=gate_cells_pre,
            obs=obs,
            verify_sec_fn=verify_sec,
            log_fn=_vlog,
        )
    else:
        from kairos.sec.closed_loop._ebmc_verification import run_ebmc_verification_path
        _iter_result = run_ebmc_verification_path(
            obs=obs,
            iteration_index=iteration_index,
            proposal=proposal,
            parent_run_id=parent_run_id,
            sig=sig,
            inputs_dir=inputs_dir,
            iter_bundle=iter_bundle,
            gold_for_verify=gold_for_verify,
            gate_for_verify=gate_for_verify,
            gold_module=gold_module,
            gate_module=gate_module,
            deps_for_verify=deps_for_verify,
            ports=ports,
            bound=bound,
            timeout_sec=timeout_sec,
            gold_cells_pre=gold_cells_pre,
            gate_cells_pre=gate_cells_pre,
            max_proposer_inner_retries=max_proposer_inner_retries,
            proposer_model=proposer_model,
            proposer_timeout_sec=proposer_timeout_sec,
            verify_sec_fn=verify_sec,
            log_fn=_vlog,
        )

    # ATH-1435: attach gate_sv_text to accepted iteration summaries so the
    # compound loop can promote gate->gold only when proved=True.
    if _iter_result.get("outcome") == "accepted":
        _iter_result["gate_sv_text"] = proposed_gate_text

    return _iter_result



from kairos.sec.closed_loop.measurement import (
    build_cert_payload as _build_cert_payload,
)


# ---------------------------------------------------------------------------
# Public entry point (ATH-1063 Phase 0a-wiring commit 2b).
#
# `run_closed_loop_orchestration` is the canonical library function that
# the v2.7 demo, MCP `kairos_optimize_block`, and any future cert-mint
# script call to drive the propose-verify-bridge-iterate arc end-to-end.
# Wraps proposer + per-iteration helper + halt-reason aggregation +
# cert-payload assembly + observe-event emission, returning a structured
# :class:`ClosedLoopResult` for the caller to render / serialize / ship.
#
# The function takes a bundle dir + target module + LLM model + bound +
# timeout knobs and emits the canonical event chain:
#
#   transformation_proposed (per proposal)
#       → verify_attempt (engine=ebmc_bmc)
#       → optional bridge_invariant_proposed (per bridge attempt)
#       → optional verify_attempt (engine=ebmc_kinduction)
#       → iteration_verdict (per proposal)
#   → iteration_complete (once per run)
#   → customer_block_certificate_complete (once per run)
# ---------------------------------------------------------------------------




def run_closed_loop_orchestration(
    *,
    bundle_path: Path,
    target_module: str,
    block_name: str | None = None,
    model: str = DEFAULT_SEC_PROPOSER_MODEL,
    max_proposals: int = 3,
    k_induction_bound: int = 32,
    timeout_sec: int = 1800,
    proposer_timeout_sec: int = 360,
    max_proposer_inner_retries: int = 5,
    parallel_proposer_count: int = 1,
    parallel_proposer_models: tuple[str, ...] | None = None,
    proposer_mode: str = "preserve_datapath",
    proposer_backend: str = "litellm",
    n_enrichment_rounds: int = 1,
    mine_before_propose: bool = False,
    elaborate_gold: bool = False,
    work_dir: Path | None = None,
    repo_root: Path | None = None,
    fleet_agent_role: str = "qa",
    vertical: str = "silicon_block_sec",
    task_id: str | None = None,
    custom_engine: str | None = None,
    allowed_transforms: frozenset[str] | None = None,
) -> ClosedLoopResult:
    """Run the propose-verify-bridge-iterate arc end-to-end.

    Opens a :func:`kairos.observe.observe` context (parent ``solve_runs``
    row), calls the LLM proposer, drives the per-iteration arc via
    :func:`_emit_iteration_arc_for_proposal`, then emits
    ``iteration_complete`` + ``customer_block_certificate_complete``.

    Parameters
    ----------
    bundle_path:
        Path to the input bundle directory containing ``signature.json``,
        ``gold.sv``, and ``gate.v``. The proposer reads ``signature.json``
        for the optimization target context. Per-iteration bundles are
        written under ``work_dir`` (default: ``bundle_path / "_sec_work"``).
    target_module:
        Top-level RTL module name passed to the proposer + EBMC. Must match
        the ``gold_module`` field in ``signature.json``.
    block_name:
        Display name for the cert payload's ``block_name`` field. Defaults
        to ``target_module``.
    model:
        LLM model id for proposer + bridge-invariant generation. Default
        ``anthropic/claude-opus-4-6``.
    max_proposals:
        Number of candidate transformations to ask the proposer for.
        Default 3.
    k_induction_bound:
        EBMC BMC + k-induction bound. Default 32 per Aidan's k-bound fleet
        directive (push higher whenever possible — soundness signal scales
        with bound; cost is wrong axis).
    timeout_sec:
        Per-EBMC-mode wall-clock timeout in seconds. Default 120.
    proposer_timeout_sec:
        Wall-clock timeout for the LLM proposer call. Default 180.
    work_dir:
        Where per-iteration bundles + tmp gates land. Default
        ``bundle_path / "_sec_work"``.
    repo_root:
        Optional anchor for relative-path display in emitted event payloads.
        When ``None``, absolute paths are emitted.
    fleet_agent_role:
        ``solve_runs.fleet_agent_role`` field. Default ``"qa"``.
    vertical:
        ``solve_runs.vertical`` field. Default ``"silicon_block_sec"``.
    task_id:
        Optional ``solve_runs.task_id`` field. Defaults to
        ``f"closed_loop_{target_module}"``.

    Returns
    -------
    :class:`ClosedLoopResult` with the parent ``run_id`` + per-iteration
    summaries + cert payload.

    Raises
    ------
    FileNotFoundError:
        When ``bundle_path / "signature.json"`` is missing.
    """
    import sys

    _observe_available = False
    try:
        import kairos.observe  # noqa: F401
        _observe_available = True
    except (ImportError, OSError):
        _log.warning("kairos.observe unavailable — traces written to local JSONL only")
    from kairos.sec.closed_loop import propose_transformations
    from kairos.sec.closed_loop.bundle_loader import (
        load_signature,
        detect_and_inject_pattern_invariants,
        elaborate_gold_to_verilog,
    )

    bundle_path = Path(bundle_path)
    sig = load_signature(bundle_path)
    work_dir_resolved = (
        Path(work_dir) if work_dir is not None else bundle_path / "_sec_work"
    )
    # P0-SEC-01: never mutate the customer's signature.json in-place.
    # Copy to work_dir so all enrichments (mined_assumptions, hints) are
    # written to the working copy, not the original bundle.
    work_dir_resolved.mkdir(parents=True, exist_ok=True)
    _sig_work_path = work_dir_resolved / "signature.json"
    shutil.copy2(bundle_path / "signature.json", _sig_work_path)
    block_name_resolved = block_name if block_name is not None else target_module
    task_id_resolved = (
        task_id if task_id is not None else f"closed_loop_{target_module}"
    )

    detect_and_inject_pattern_invariants(sig, bundle_path)

    if elaborate_gold:
        elaborate_gold_to_verilog(sig, bundle_path, target_module, work_dir_resolved)

    obs_mod = sys.modules.get("kairos.observe")

    _local_trace_ref: list = []

    def _emit(event_type: str, **kwargs: Any) -> None:
        if obs_mod is not None:
            obs_mod.emit(event_type, **kwargs)
        elif _local_trace_ref:
            _local_trace_ref[0].write_event({"event_type": event_type, **kwargs})

    # Enrichment outer loop: N rounds of mine → propose → verify.
    # Each round accumulates proved assertions for the next round's
    # proposer context. Default n_enrichment_rounds=1 preserves
    # single-pass behavior.
    best_result: ClosedLoopResult | None = None
    this_result: ClosedLoopResult | None = None

    for enrichment_round in range(n_enrichment_rounds):
        # Mining pre-step (optional): mine structural assertions,
        # prove via EBMC Mode 1, enrich the proposer context.
        _mined_assumptions: list[str] = []
        if mine_before_propose:
            try:
                from kairos.sec.closed_loop.mine_assumptions import mine_assumptions
                mining = mine_assumptions(
                    bundle_path=bundle_path,
                    target_module=target_module,
                    model=model,
                    max_assertions=8,
                    k_bound=k_induction_bound,
                    timeout_sec=60,
                )
                _mined_assumptions = [a.sva_text for a in mining.proved]
                if _mined_assumptions:
                    sig["mined_assumptions"] = _mined_assumptions
                    _vlog(f"  [mining] {len(_mined_assumptions)} assumptions proved, injecting into proposer + verifier")
                    _emit("assumption_mining_complete", run_subtype="theorem_proving", payload={
                        "n_mined": len(mining.proved) + len(mining.refuted) + len(mining.inconclusive),
                        "n_proved": len(mining.proved),
                        "n_applied": len(_mined_assumptions),
                        "assumptions": [a.sva_text for a in mining.proved],
                    })
            except Exception:  # noqa: BLE001
                pass  # Mining is best-effort

        from contextlib import nullcontext
        try:
            _obs_ctx = (
                obs_mod.observe(
                    run_subtype="theorem_proving",
                    spawn_reason="closed_loop_orchestration",
                    fleet_agent_role=fleet_agent_role,
                    vertical=vertical,
                    task_id=task_id_resolved,
                ) if obs_mod is not None else nullcontext()
            )
        except Exception:  # noqa: BLE001 — best-effort cleanup
            _obs_ctx = nullcontext()
        with _obs_ctx as ctx:
            run_id = ctx.run_id if ctx is not None else "local-" + target_module
            # When observe is unavailable, write traces to local JSONL
            # so customer data is never lost.
            _local_trace = None
            if ctx is None:
                from kairos.local_output import LocalOutputDir
                _local_trace = LocalOutputDir(run_id=run_id)
                _local_trace_ref.append(_local_trace)
                _log.info(f"Tracing to local JSONL: {_local_trace.path}")

            if not os.environ.get("ATHANOR_SYNC_TOKEN"):
                _vlog(
                    "  [warn] ATHANOR_SYNC_TOKEN not set — traces are local-only. "
                    "Set it to see results on the dashboard."
                )

            _vlog(f"=== Optimizing {target_module} ===")
            if _dialogue:
                _dialogue.phase(f"Optimizing {target_module}")

            # ATH-1131: ABC deterministic optimization — try on ALL combo
            # blocks before the LLM proposer. ABC resyn2 finds algebraic
            # optimizations (XOR sharing, redundant logic, AIG rewriting)
            # with zero LLM cost and zero port mangling risk.
            from kairos.sec.closed_loop.verify_pipeline import select_engine
            engine_class = select_engine(sig)
            _vlog(f"  Engine class: {engine_class}")
            _abc_iteration = None
            if engine_class == "combo":
                _vlog("  Phase 1: ABC deterministic optimization...")
                try:
                    from kairos.sec.closed_loop.ecc_decompose import abc_optimize_any_block
                    abc_result = abc_optimize_any_block(
                        gold_path=bundle_path / sig["gold_sv"],
                        target_module=target_module,
                        dep_files=[bundle_path / d for d in sig.get("dep_files") or []],
                        timeout_sec=min(timeout_sec, 120),
                    )
                    if abc_result and abc_result.get("proved"):
                        _vlog(f"  ABC PROVED: {abc_result.get('gold_cells')} -> {abc_result.get('gate_cells')} cells ({abc_result.get('area_delta_pct')}%)")
                        if _dialogue:
                            _dialogue.verifier(f"ABC resyn2 PROVED equivalent: {abc_result.get('gold_cells')}→{abc_result.get('gate_cells')} cells ({abc_result.get('area_delta_pct')}%)")
                        _emit("verify_attempt", run_subtype="theorem_proving", payload={
                            "iteration_index": 0,
                            "parent_run_id": run_id,
                            "engine": "abc_resyn2",
                            "result": "PASS",
                            "elapsed_sec": abc_result.get("elapsed_sec", 0),
                            "detail": f"ABC deterministic: {abc_result.get('gold_cells')} -> {abc_result.get('gate_cells')} cells",
                        })
                        _abc_iteration = {
                            "iteration_index": 0,
                            "outcome": "accepted",
                            "outcome_reason": f"ABC resyn2 PROVED equivalent: {abc_result.get('gold_cells')} -> {abc_result.get('gate_cells')} cells",
                            "transformation_class": "structural",
                            "claimed_area_delta_pct": abc_result.get("area_delta_pct", 0),
                            "measured_delta_pct": abc_result.get("area_delta_pct", 0),
                            "gold_cells": abc_result.get("gold_cells"),
                            "gate_cells": abc_result.get("gate_cells"),
                            "bridges_used": [],
                            "property_verdicts": {},
                        }
                except Exception:  # noqa: BLE001
                    pass  # ABC is best-effort, fall through to LLM proposer

            # Pre-proposer phase boundary: poll for hint messages and
            # inject into sig so prompt_composer picks them up.
            pre_msgs = _poll_agent_messages(run_id)
            hint_texts = [m.content for m in pre_msgs.get("hint", [])]
            if hint_texts:
                sig["proposer_hints"] = sig.get("proposer_hints", []) + hint_texts
                _sig_work_path.write_text(
                    _json.dumps(sig, indent=2)
                )
                _vlog(f"  [hint] {len(hint_texts)} hint(s) injected into proposer context")

            _afg_total = 0
            try:
                from kairos.sec.closed_loop.block_memory import load_and_validate_memory
                _memory_context, _afg_total, _at_floor = load_and_validate_memory(bundle_path, sig)
                if _afg_total > 0:
                    _vlog(f"  [memory] {_afg_total} entries loaded.")
                    if _at_floor:
                        _vlog("  [memory] WARNING: Block at synthesis floor.")
            except Exception:  # noqa: BLE001
                pass

            # ATH-1168: Reset memory flag before proposer — structural enforcement
            try:
                from kairos.sec.closed_loop.prompt_composer import reset_memory_flag
                reset_memory_flag()
            except Exception:  # noqa: BLE001
                pass

            # ATH-1078 Phase 1b: verilator toggle pre-measurement for aggressive mode.
            # When ADD-for-power transforms are in allowed_transforms, run verilator
            # on gold to get per-signal switching activity. Proposer uses this to
            # target high-toggle nets for gating/isolation.
            _toggle_activity: list[dict] | None = None
            if allowed_transforms is not None:
                from kairos.transforms import ADD_FOR_POWER
                _add_ids = frozenset(t.value for t in ADD_FOR_POWER)
                if _add_ids & allowed_transforms:
                    try:
                        from kairos.verilator import compile_and_run as _verilator_run
                        gold_sv_for_toggle = bundle_path / sig["gold_sv"]
                        if gold_sv_for_toggle.is_file():
                            _vlog("  Phase 1.5: Verilator toggle measurement on gold...")
                            vr = _verilator_run(
                                [str(gold_sv_for_toggle)],
                                top_module=target_module,
                                n_cycles=1000,
                                timeout_sec=60,
                            )
                            if vr.compile_ok and vr.per_signal:
                                _toggle_activity = [
                                    {"signal": t.signal, "width": t.width,
                                     "toggles_per_cycle": t.toggles_per_cycle,
                                     "cycles": vr.cycles_run}
                                    for t in vr.per_signal[:30]
                                ]
                                _vlog(f"  Toggle: {vr.total_toggles} total, {len(vr.per_signal)} signals measured")
                            elif vr.error:
                                _vlog(f"  Toggle: skipped ({vr.error[:80]})")
                    except Exception as _te:  # noqa: BLE001
                        _vlog(f"  Toggle: pre-measurement failed ({_te})")

            from kairos.sec.closed_loop._proposer_dispatch import dispatch_proposer
            proposal_run = dispatch_proposer(
                proposer_backend=proposer_backend,
                max_proposals=max_proposals,
                bundle_path=bundle_path,
                sig=sig,
                target_module=target_module,
                model=model,
                proposer_timeout_sec=proposer_timeout_sec,
                proposer_mode=proposer_mode,
                parallel_proposer_count=parallel_proposer_count,
                parallel_proposer_models=parallel_proposer_models,
                toggle_activity=_toggle_activity,
                run_id=run_id,
                emit_fn=_emit,
                log_fn=_vlog,
            )

            # ATH-1168: Verify memory was loaded — structural rejection.
            # Single-proposer path: compose_system_prompt runs on main
            # thread, so was_memory_loaded() is reliable → ABORT on miss.
            # Parallel path: compose runs on worker threads, flag is
            # thread-local, main thread can't see it → EVENT only.
            try:
                from kairos.sec.closed_loop.prompt_composer import was_memory_loaded
                if _afg_total > 0 and not was_memory_loaded():
                    if parallel_proposer_count <= 1:
                        raise RuntimeError(
                            f"Memory gate rejection: block has {_afg_total} "
                            f"memory entries but prompt_composer did not load "
                            f"them. This is a code path bug — memory must be "
                            f"injected before proposer runs."
                        )
                    else:
                        _vlog(
                            f"  [memory] Parallel path — flag is thread-local, "
                            f"skipping abort (memory loaded on worker threads)"
                        )
            except RuntimeError:
                raise  # re-raise the gate rejection
            except Exception:  # noqa: BLE001
                pass

            # Phase boundary: poll agent messages before verification
            phase_msgs = _poll_agent_messages(run_id)
            if any(m.content == "abort" for m in phase_msgs.get("control", [])):
                _vlog("  [control] Abort requested by customer agent")
                return ClosedLoopResult(
                    parent_run_id=run_id,
                    halt_reason="aborted",
                    iteration_summaries=[],
                    cert_payload={},
                )
            # Apply config overrides from agent messages
            for cfg_msg in phase_msgs.get("config", []):
                try:
                    overrides = _json.loads(cfg_msg.content)
                    if "timeout_sec" in overrides:
                        timeout_sec = int(overrides["timeout_sec"])
                        _vlog(f"  [config] timeout_sec -> {timeout_sec}")
                    if "k_induction_bound" in overrides:
                        k_induction_bound = int(overrides["k_induction_bound"])
                        _vlog(f"  [config] k_induction_bound -> {k_induction_bound}")
                except Exception:  # noqa: BLE001
                    pass

            if proposal_run.halt_reason != "ok" or not proposal_run.proposals:
                abc_summaries = [_abc_iteration] if _abc_iteration is not None else []
                halt = "abc_proved" if abc_summaries else "proposer_halt"
                cert_payload = _build_cert_payload(
                    parent_run_id=run_id,
                    block_name=block_name_resolved,
                    iteration_summaries=abc_summaries,
                    bundle_path=str(bundle_path),
                )
                _emit(
                    "iteration_complete",
                    run_subtype="theorem_proving",
                    payload={
                        "iteration_index": -1,
                        "parent_run_id": run_id,
                        "halt_reason": halt,
                        "halt_reason_human": (
                            f"ABC deterministic optimization PROVED: "
                            f"{_abc_iteration.get('gold_cells')} -> {_abc_iteration.get('gate_cells')} cells "
                            f"({_abc_iteration.get('measured_delta_pct')}%)"
                        ) if abc_summaries else (
                            "kairos backend authentication failed — check API key "
                            "configuration. Run 'kairos doctor' to diagnose."
                            if proposal_run.is_auth_error
                            else (
                                f"The LLM proposer could not generate a valid optimization "
                                f"for this block ({proposal_run.halt_reason}). "
                                f"Try a different model or increase proposer_timeout_sec."
                            )
                        ),
                        "no_optimization_attempted": not abc_summaries,
                        "proposer_halt_reason": proposal_run.halt_reason,
                    },
                )
                if ctx is not None:
                    ctx.mark_pipeline_outcome(
                        "abc_proved" if abc_summaries else "no_optimization_attempted",
                        reason=(
                            f"ABC PROVED: {_abc_iteration.get('measured_delta_pct')}% area reduction"
                            if abc_summaries else
                            f"Proposer did not produce proposals: {proposal_run.halt_reason}"
                        ),
                    )
                return ClosedLoopResult(
                    parent_run_id=run_id,
                    halt_reason=halt,
                    iteration_summaries=abc_summaries,
                    cert_payload=cert_payload,
                    proposer_halt_reason=proposal_run.halt_reason,
                    proposer_halt_reason_class=proposal_run.halt_reason_class,
                )

            iteration_summaries: list[dict[str, Any]] = []
            if _abc_iteration is not None:
                iteration_summaries.append(_abc_iteration)
            import copy as _copy
            from concurrent.futures import ThreadPoolExecutor as _TPE, as_completed

            def _verify_one(i_proposal):
                i, proposal = i_proposal
                sig_copy = _copy.deepcopy(sig)
                return _emit_iteration_arc_for_proposal(
                    obs=obs_mod,
                    iteration_index=i,
                    proposal=proposal,
                    parent_run_id=run_id,
                    sig=sig_copy,
                    inputs_dir=bundle_path,
                    work_dir=work_dir_resolved,
                    bound=k_induction_bound,
                    timeout_sec=timeout_sec,
                    repo_root=repo_root,
                    max_proposer_inner_retries=max_proposer_inner_retries,
                    proposer_model=model,
                    proposer_timeout_sec=proposer_timeout_sec,
                    custom_engine=custom_engine,
                )

            # ATH-1078: filter proposals by allowed_transforms when set.
            # Conservative mode (REMOVE-only): exclude impl_swap class.
            # Aggressive mode (ALL): allow all classes through.
            if allowed_transforms is not None:
                from kairos.transforms import ADD_FOR_POWER as _AFP
                _has_add_transforms = bool(frozenset(t.value for t in _AFP) & allowed_transforms)
                if not _has_add_transforms:
                    pre_filter = len(proposal_run.proposals)
                    filtered = [
                        p for p in proposal_run.proposals
                        if p.transformation_class.value != "impl_swap"
                    ]
                    n_filtered = pre_filter - len(filtered)
                    if n_filtered:
                        from kairos.sec.closed_loop._proposer import ProposalRunResult
                        proposal_run = ProposalRunResult(
                            target_module=proposal_run.target_module,
                            proposals=filtered,
                            halt_reason=proposal_run.halt_reason,
                        )
                        _vlog(f"  [mode] Filtered {n_filtered}/{pre_filter} proposals (impl_swap excluded in conservative mode)")

            n_proposals = len(proposal_run.proposals)
            if _dialogue:
                for i, p in enumerate(proposal_run.proposals):
                    _dialogue.proposer(
                        f"{p.transformation_class.value}: {p.description[:120]}" if hasattr(p, "description") and p.description else f"{p.transformation_class.value}",
                        agent_id=str(i + 1),
                    )
            if n_proposals > 1:
                import contextvars as _ctxvars
                def _verify_in_context(args):
                    return _ctxvars.copy_context().run(_verify_one, args)
                with _TPE(max_workers=min(n_proposals, 5)) as pool:
                    futures = {
                        pool.submit(_verify_in_context, (i, p)): i
                        for i, p in enumerate(proposal_run.proposals)
                    }
                    results_by_idx: dict[int, dict] = {}
                    for fut in as_completed(futures):
                        idx = futures[fut]
                        try:
                            results_by_idx[idx] = fut.result()
                        except Exception as e:  # noqa: BLE001
                            results_by_idx[idx] = {
                                "iteration_index": idx,
                                "outcome": "errored",
                                "outcome_reason": _sanitize_error_for_customer(e, "parallel_verify_error"),
                                "transformation_class": "unknown",
                                "claimed_area_delta_pct": 0,
                                "bridges_used": [],
                                "property_verdicts": {},
                            }
                    iteration_summaries = [
                        results_by_idx[i] for i in range(n_proposals)
                    ]
                    _vlog("  Phase 3: Verification results:")
                    for s in iteration_summaries:
                        o = s.get("outcome", "?")
                        d = s.get("measured_delta_pct", s.get("claimed_area_delta_pct", "?"))
                        gc = s.get("gold_cells", "?")
                        gatec = s.get("gate_cells", "?")
                        _vlog(f"    [{s.get('iteration_index', '?')}] {o}: {d}% ({gc}->{gatec})")
                        if _dialogue:
                            if o == "accepted":
                                _dialogue.verifier(f"PROVED equivalent: {gc}→{gatec} cells ({d}%)", agent_id=str(s.get("iteration_index", 0) + 1))
                            elif o == "refuted":
                                _dialogue.reviewer(f"REFUTED: counterexample found", agent_id=str(s.get("iteration_index", 0) + 1))
                            elif o == "errored":
                                _dialogue.error(f"Verification error: {s.get('outcome_reason', '?')[:80]}")
            else:
                for i, proposal in enumerate(proposal_run.proposals):
                    iteration_summaries.append(_verify_one((i, proposal)))
    
            if any(s["outcome"] == "accepted" for s in iteration_summaries):
                halt = "proved_equivalent_variant_found"
                if _dialogue:
                    accepted = [s for s in iteration_summaries if s["outcome"] == "accepted"]
                    best = min(accepted, key=lambda s: s.get("measured_delta_pct", 0))
                    _dialogue.result(f"{best.get('measured_delta_pct', '?')}% area reduction, formally verified")
            else:
                halt = "no_proposal_closed"
                if _dialogue:
                    _dialogue.result("No optimization proved equivalent this round")
    
            from kairos.sec.closed_loop._run_result_builder import build_and_emit_result
            this_result = build_and_emit_result(
                run_id=run_id,
                halt=halt,
                iteration_summaries=iteration_summaries,
                bundle_path=bundle_path,
                repo_root=repo_root,
                work_dir=work_dir_resolved,
                sig=sig,
                target_module=target_module,
                block_name=block_name_resolved,
                model=model,
                emit_fn=_emit,
            )

            if best_result is None:
                best_result = this_result
            elif halt == "proved_equivalent_variant_found":
                best_result = this_result
            if halt == "proved_equivalent_variant_found":
                break

    return best_result or this_result


from kairos.sec.closed_loop.measurement import (
    measure_synthesis as _measure_synthesis,
    measure_toggle_power as _measure_toggle_power,
    sha256_of_file as _sha256_of_file,
    is_subpath as _is_subpath,
)
