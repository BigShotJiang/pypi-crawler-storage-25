"""ATH-1089 — generic inner-retry-with-feedback harness.

``with_inner_retry`` is the standalone primitive that every LLM-proposing
agent (proposer / miner / bridge-invariant-gen / cert-builder) wraps to
get bounded retry-with-feedback semantics.

Per Aidan no-wasted-effort + retry-budget directive 2026-05-07: every
LLM-proposing agent has a retry budget; a single-shot agent that fails on
a recoverable issue is wasted tokens. This module ships that budget as a
reusable, caller-agnostic primitive so each agent doesn't bake its own
ad-hoc loop.

## Retry semantics

* First iteration: ``call(None)`` — no prior feedback.
* Each subsequent iteration: ``call(feedback_extractor(prior_result))`` so
  the next attempt sees the prior failure's actionable detail.
* After EACH call, ``gate_predicate(result)`` classifies the outcome:

  - ``"PROVED"``         → halt immediately (success).
  - ``"REFUTED"``        → halt immediately, no retry (semantic divergence
    — the call is genuinely wrong about the design, not just transiently
    unreliable; retrying would waste budget).
  - ``"INCONCLUSIVE"``, ``"PARSE_ERROR"``, ``"EBMC_RUN_FAILURE"``,
    ``"REVISED_AFTER"``  → retry if budget remains, else halt.

## InnerRetryAttempt shape

This module defines its own :class:`InnerRetryAttempt` that is generic
(``artifact_summary`` instead of ``sva_text``). The mining-specific
dataclass in ``mine_assumptions.py`` is field-parallel; if you need to
move mining over to this harness, map ``sva_text → artifact_summary`` at
the call-site.

Cross-ref: :mod:`kairos.sec.closed_loop.mine_assumptions` —
``InnerRetryAttempt`` there has an SVA-specific ``sva_text`` field.

## cost_cap_usd

Accepted as a forward-pin parameter (Phase 1 stub). Callers may pass it
today; the harness stores whether it is set in the returned history so
future cost-tracker integration can gate without an API break. No billing
logic runs in Phase 1.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Generic, Literal, TypeVar

# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

InnerAttemptStatus = Literal[
    "PROVED",
    "REFUTED",
    "INCONCLUSIVE",
    "REVISED_AFTER",
    "PARSE_ERROR",
    "EBMC_RUN_FAILURE",
]

# The set of statuses that are retryable (recoverable failure; budget
# permitting, the harness will call again with updated feedback).
_RETRYABLE_STATUSES: frozenset[str] = frozenset(
    {"INCONCLUSIVE", "PARSE_ERROR", "EBMC_RUN_FAILURE", "REVISED_AFTER"}
)

# Type variables for the generic call/result/feedback contract.
CallResultT = TypeVar("CallResultT")
FeedbackT = TypeVar("FeedbackT")


@dataclass(frozen=True)
class InnerRetryAttempt(Generic[CallResultT]):
    """Record of a single attempt in the inner-retry loop.

    Generic over ``CallResultT`` so callers that need the raw result
    alongside the summary can store it.

    Fields
    ------
    attempt_index:
        Zero-based index (0 = first call, 1 = first retry, …).
    attempt_status:
        Gate verdict for this attempt.
    artifact_summary:
        Human-readable / loggable summary of the attempt artifact
        (e.g. the SVA text, the Lean term, the candidate proof). The
        harness does not interpret this field; callers populate it via
        their ``feedback_extractor`` summary or the call result repr.
    cost_cap_usd_set:
        True iff the caller passed a non-None ``cost_cap_usd`` to
        :func:`with_inner_retry`. Forward-pin for cost-tracker
        integration (Phase 1 stub).
    """

    attempt_index: int
    attempt_status: InnerAttemptStatus
    artifact_summary: str
    cost_cap_usd_set: bool = False


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def with_inner_retry(
    call: Callable[[FeedbackT | None], CallResultT],
    gate_predicate: Callable[[CallResultT], InnerAttemptStatus],
    feedback_extractor: Callable[[CallResultT], FeedbackT],
    *,
    max_retries: int,
    cost_cap_usd: float | None = None,
) -> tuple[CallResultT, tuple[InnerRetryAttempt[CallResultT], ...]]:
    """Run ``call`` up to ``max_retries + 1`` times until
    ``gate_predicate`` returns ``"PROVED"`` or the budget is exhausted.

    Each iteration after the first passes the prior result's feedback
    (extracted via ``feedback_extractor``) to the next call, so the
    callee can act on the previous failure's detail.

    Parameters
    ----------
    call:
        Callable that takes ``FeedbackT | None`` and returns
        ``CallResultT``.  First invocation receives ``None`` (no prior
        feedback); subsequent invocations receive the feedback extracted
        from the prior result.
    gate_predicate:
        Callable that maps ``CallResultT → InnerAttemptStatus``.
        ``"PROVED"`` halts with success; ``"REFUTED"`` halts without
        retry; all other statuses are retryable subject to budget.
    feedback_extractor:
        Callable that maps ``CallResultT → FeedbackT``.  Called between
        iterations to extract actionable feedback for the next call.
        NOT called before the first call or after the final call.
    max_retries:
        Maximum number of retries (attempts beyond the initial call).
        Total calls ≤ ``max_retries + 1``.
    cost_cap_usd:
        Optional spend hint (forward-pin). No billing logic in Phase 1;
        stored as ``cost_cap_usd_set`` flag on each
        :class:`InnerRetryAttempt` for future cost-tracker integration.

    Returns
    -------
    tuple[CallResultT, tuple[InnerRetryAttempt, ...]]
        ``(final_result, history)`` where ``history`` has one entry per
        call made (length between 1 and ``max_retries + 1`` inclusive).

    Notes
    -----
    * ``PROVED`` → halt immediately; history length = attempt_index + 1.
    * ``REFUTED`` → halt immediately, no retry.
    * Retryable statuses (``INCONCLUSIVE``, ``PARSE_ERROR``,
      ``EBMC_RUN_FAILURE``, ``REVISED_AFTER``) → retry while budget
      remains; final result is the last call's result.
    * ``cost_cap_usd`` is accepted today so callers can forward-pin
      their cap; actual enforcement is deferred to Phase 2.
    """
    cap_set = cost_cap_usd is not None
    history: list[InnerRetryAttempt[CallResultT]] = []
    feedback: FeedbackT | None = None
    result: CallResultT | None = None

    for attempt_idx in range(max_retries + 1):
        result = call(feedback)
        status = gate_predicate(result)

        # Derive a loggable summary from the feedback_extractor output.
        # We do NOT call feedback_extractor on the last iteration (or on
        # PROVED/REFUTED halts) unless it's also needed for the history
        # record — keep it as a str() of the result for the summary.
        history.append(
            InnerRetryAttempt(
                attempt_index=attempt_idx,
                attempt_status=status,
                artifact_summary=repr(result),
                cost_cap_usd_set=cap_set,
            )
        )

        # Halt immediately on decisive verdicts.
        if status == "PROVED" or status == "REFUTED":
            break

        # Retryable — extract feedback for the next iteration if budget
        # remains.
        if attempt_idx < max_retries:
            feedback = feedback_extractor(result)
        # else: budget exhausted — loop ends naturally.

    # result is always set because the loop runs at least once
    # (max_retries >= 0 is not enforced, but callers that pass 0 get
    # exactly 1 call which is correct).
    assert result is not None, "with_inner_retry loop must execute at least once"
    return result, tuple(history)


# ---------------------------------------------------------------------------
# Public exports
# ---------------------------------------------------------------------------

__all__ = [
    "InnerAttemptStatus",
    "InnerRetryAttempt",
    "with_inner_retry",
]
