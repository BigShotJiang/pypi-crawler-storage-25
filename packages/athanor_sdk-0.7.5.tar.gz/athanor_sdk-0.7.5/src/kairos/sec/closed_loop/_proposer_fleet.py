"""Claude subagent fleet for parallel proposal generation (ATH-1172).

Extracted from _orchestrator.py God Object decomposition (ATH-1415).
Spawns N parallel Claude subagents, each with a different optimization
strategy. Returns proposals ready for verification.
"""
from __future__ import annotations

import logging
from kairos.smart_orchestrator import run_subagents, OrchestratorConfig
from typing import Any

_log = logging.getLogger("kairos.proposer_fleet")


def spawn_claude_fleet(
    gold_text: str,
    sig: dict[str, Any],
    max_proposals: int,
    timeout_sec: int,
    target_module: str,
) -> tuple[list[Any], list[str]]:
    """Spawn parallel Claude subagents and collect proposals.

    Returns (proposals, auth_errors) where proposals is a list of
    TransformationProposal and auth_errors is a list of error strings.
    """
    from kairos.sec.closed_loop._proposer import (
        TransformationProposal,
        TransformationClass,
    )
    from kairos.sec.closed_loop.claude_proposer import (
        claude_propose,
        ProposerAuthenticationError,
    )
    import contextvars

    is_seq = bool(sig.get("clock_port"))
    seq_hint = "Sequential block. Try: encoding swap, pointer narrowing, register sharing." if is_seq else ""
    system_prompt = f"Optimize this RTL for area reduction. {seq_hint}"

    agent_configs = [
        ("proposer-conservative", "Focus on safe, minimal optimizations. preserve_datapath mode."),
        ("proposer-aggressive", "Maximize area reduction. Try bold restructuring."),
        ("proposer-specialist", "Look for XOR sharing, arithmetic sharing, encoding swaps."),
    ][:max_proposals]

    proposals: list[TransformationProposal] = []
    auth_errors: list[str] = []

    def _propose(agent_id_hint):
        aid, extra = agent_id_hint
        raw = claude_propose(
            gold_sv=gold_text, sig=sig,
            max_proposals=1,
            system_prompt=f"{system_prompt}\n\n## AGENT ROLE: {extra}",
            timeout_sec=timeout_sec,
        )
        results = []
        for r in raw:
            try:
                tc = TransformationClass(r.get("transformation_class", "structural"))
            except ValueError:
                tc = TransformationClass.STRUCTURAL
            results.append(TransformationProposal(
                target_module=target_module,
                gate_sv=r["gate_sv"],
                transformation_class=tc,
                claimed_area_delta_pct=r.get("claimed_area_delta_pct", -5.0),
                rationale=r.get("rationale", ""),
            ))
        return aid, results

    _log.info(f"Claude subagent fleet ({len(agent_configs)} agents, zero API cost)...")

    tasks = [(aid, lambda cfg=cfg: _propose(cfg)) for aid, cfg in
             [(aid, (aid, extra)) for aid, extra in agent_configs]]

    config = OrchestratorConfig(
        max_workers=min(len(agent_configs), 3),
        mode="wait_all",
        timeout_sec=timeout_sec + 10,
        good_enough=lambda r: r is not None and len(r[1]) > 0,
    )
    outcome = run_subagents(tasks, config)

    for sr in outcome.results:
        if sr.success and sr.result is not None:
            aid, props = sr.result
            proposals.extend(props)
            for p in props:
                _log.info(f"  [{aid}] {p.transformation_class.value}: {p.claimed_area_delta_pct:+.1f}%")
        elif sr.error and "AuthenticationError" in sr.error:
            auth_errors.append(sr.error)
        elif sr.error:
            _log.warning(f"  [{sr.agent_id}] failed: {sr.error}")

    if outcome.early_exit:
        _log.info(f"  Fleet: early exit — good-enough proposal found, {outcome.cancelled_count} agents cancelled")

    _log.info(f"Fleet: {len(proposals)} proposals from {len(agent_configs)} agents")
    return proposals, auth_errors
