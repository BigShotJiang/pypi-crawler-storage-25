"""ATH-1115 sub-2b: bundle loading, signature parsing, gold elaboration.

Extracted from _orchestrator.py. Handles everything between "customer
gives us a bundle path" and "orchestrator has a clean sig dict ready
for the propose-verify loop."
"""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Any

from kairos.security.env_allowlist import safe_env_for_yosys
from kairos.security.path_sanitizer import sanitize_yosys_path, validate_verilog_identifier


def load_signature(bundle_path: Path) -> dict[str, Any]:
    """Load and validate signature.json from a bundle directory."""
    sig_path = bundle_path / "signature.json"
    if not sig_path.is_file():
        raise FileNotFoundError(
            f"signature.json missing in bundle: {bundle_path}"
        )
    result: dict[str, Any] = json.loads(sig_path.read_text())
    return result


def detect_and_inject_pattern_invariants(
    sig: dict[str, Any],
    bundle_path: Path,
) -> list[Any]:
    """ATH-1114: detect structural patterns from gold RTL and inject
    inferred invariants into sig["proposer_hints"]."""
    try:
        from kairos.sec.closed_loop.pattern_invariants import (
            detect_patterns,
            format_for_proposer,
        )
        gold_path = (bundle_path / sig["gold_sv"]).resolve()
        if not gold_path.is_relative_to(bundle_path.resolve()):
            return []
        gold_text = gold_path.read_text()
        invariants = detect_patterns(gold_text)
        if invariants:
            pattern_context = format_for_proposer(invariants)
            existing_hints = sig.get("proposer_hints", [])
            existing_hints.append({
                "label": "structural_invariants",
                "hint": pattern_context,
            })
            sig["proposer_hints"] = existing_hints
        detected: list[Any] = invariants
        return detected
    except Exception:  # noqa: BLE001
        return []


def elaborate_gold_to_verilog(
    sig: dict[str, Any],
    bundle_path: Path,
    target_module: str,
    work_dir: Path,
) -> None:
    """Elaborate gold to clean Verilog-2001 via yosys.

    Modifies sig in-place: sets _gold_elab_sv, clears dep_files,
    sets _gold_pre_elaborated. The proposer reads the original
    gold_sv (human-readable); EBMC reads _gold_elab_sv (clean V2001).
    """
    yosys_bin = shutil.which("yosys")
    if yosys_bin is None:
        return

    gold_sv_path = (bundle_path / sig["gold_sv"]).resolve()
    if not gold_sv_path.is_relative_to(bundle_path.resolve()):
        raise ValueError(f"gold_sv escapes bundle directory: {sig['gold_sv']}")
    sanitize_yosys_path(gold_sv_path)
    dep_parts = []
    inc_dirs: set[str] = set()
    for d in sig.get("dep_files") or []:
        dp = (bundle_path / d).resolve()
        if not dp.is_relative_to(bundle_path.resolve()):
            raise ValueError(f"dep_file escapes bundle directory: {d}")
        sanitize_yosys_path(dp)
        if dp.suffix in (".inc", ".vh", ".svh"):
            inc_dirs.add(str(dp.parent))
        else:
            dep_parts.append(str(dp))
    dep_args = " ".join(dep_parts)
    inc_flags = " ".join(f"-I{d}" for d in sorted(inc_dirs))
    elab_dir = work_dir / "_gold_elab"
    elab_dir.mkdir(parents=True, exist_ok=True)
    elab_out = elab_dir / "gold_elab.v"

    validate_verilog_identifier(target_module, "module name")
    chparam_cmds = ""
    for p in sig.get("parameters", []):
        pname = p.get("name")
        pval = p.get("concrete_for_sec")
        if pname and pval is not None:
            validate_verilog_identifier(pname, "parameter name")
            chparam_cmds += f"chparam -set {pname} {pval} {target_module}; "

    r = subprocess.run(
        [yosys_bin, "-p",
         f"read_verilog -sv -formal {inc_flags} {dep_args} {gold_sv_path}; "
         f"{chparam_cmds}"
         f"hierarchy -check -top {target_module}; proc; opt; flatten; opt; "
         f"write_verilog -noattr {elab_out}"],
        capture_output=True, text=True, timeout=60,
        env=safe_env_for_yosys(),
    )
    if r.returncode == 0 and elab_out.is_file():
        # Store both paths: elaborated for EBMC, original for proposer.
        # Avoids LLM seeing yosys output with escaped identifiers.
        sig["_gold_elab_sv"] = str(elab_out.relative_to(bundle_path))
        sig["_original_dep_files"] = list(sig.get("dep_files") or [])
        sig["dep_files"] = []
        sig["_gold_pre_elaborated"] = True


def discover_dependencies(rtl_path: str | Path) -> list[Path]:
    """Discover sibling SV/V files that define modules instantiated in *rtl_path*."""
    import re as _re

    rtl = Path(rtl_path)
    if not rtl.is_file():
        return []
    text = rtl.read_text()
    instantiation_re = _re.compile(r"\b(\w+)\s+\w+\s*\(")
    candidates = set(instantiation_re.findall(text))
    sv_keywords = {
        "module", "endmodule", "input", "output", "inout", "wire", "reg",
        "logic", "always", "assign", "if", "else", "begin", "end",
        "initial", "function", "task", "for", "while", "case",
    }
    candidates -= sv_keywords
    if not candidates:
        return []
    deps: list[Path] = []
    parent = rtl.parent
    module_decl_re = _re.compile(r"\bmodule\s+(\w+)")
    for sibling in list(parent.glob("*.sv")) + list(parent.glob("*.v")):
        if sibling == rtl:
            continue
        if sibling.stem in candidates:
            deps.append(sibling)
            continue
        try:
            sibling_text = sibling.read_text()
        except OSError:
            continue
        defined_modules = set(module_decl_re.findall(sibling_text))
        if defined_modules & candidates:
            deps.append(sibling)
    return deps


__all__ = [
    "load_signature",
    "detect_and_inject_pattern_invariants",
    "elaborate_gold_to_verilog",
    "discover_dependencies",
]
