"""EBMC verification path — extracted from _orchestrator.py God Object (ATH-1415).

BMC verify + retry + CEGAR + invariant gen + outcome classification.
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any

from kairos.sec.closed_loop.verify_pipeline import (
    _iteration_outcome_from_bmc_result,
    _analyze_bmc_failure,
)

def run_ebmc_verification_path(
    *,
    obs: Any,
    iteration_index: int,
    proposal: Any,
    parent_run_id: str,
    sig: dict[str, Any],
    inputs_dir: Path,
    iter_bundle: Path,
    gold_for_verify: Path,
    gate_for_verify: Path,
    gold_module: str,
    gate_module: str,
    deps_for_verify: list[Path] | None,
    ports: list[dict[str, Any]],
    bound: int,
    timeout_sec: int,
    gold_cells_pre: int | None,
    gate_cells_pre: int | None,
    max_proposer_inner_retries: int,
    proposer_model: str,
    proposer_timeout_sec: int,
    verify_sec_fn: Any,
    log_fn: Any,
) -> dict[str, Any]:
    """Run the EBMC BMC + retry + CEGAR + invariant gen verification path.

    Extracted from _orchestrator.py God Object decomposition (ATH-1415).
    Returns the iteration outcome dict.
    """
    _vlog = log_fn

    # Real BMC verify: catch all EBMC failure modes, including parse
    # errors from LLM-generated SV. The verifier IS the safety net.
    bmc_result_data: dict[str, Any] = {
        "iteration_index": iteration_index,
        "parent_run_id": parent_run_id,
        "engine": "ebmc_bmc",
        "bound": bound,
    }
    bmc_t0 = time.time()
    try:
        bmc_result = verify_sec(
            gold_sv=gold_for_verify,
            gate_v=gate_for_verify,
            gold_module=gold_module,
            gate_module=gate_module,
            ports=ports,
            mode="bmc",
            bound=bound,
            clock_port=sig.get("clock_port", "clk"),
            reset_port=sig.get("reset_port", "rst_n"),
            reset_active_low=sig.get("reset_active_low", True),
            timeout_sec=timeout_sec,
            work_dir=iter_bundle / "_sec_work",
            dep_files=deps_for_verify,
        )
        miter_path_for_capture = iter_bundle / "_sec_work" / "miter.sv"
        if miter_path_for_capture.exists():
            reset_expr = (
                f"!{sig.get('reset_port', 'rst_n')}"
                if sig.get("reset_active_low", True)
                else sig.get("reset_port", "rst_n")
            )
            _capture_ebmc_subprocess(
                miter_path=miter_path_for_capture,
                gold_path=gold_for_verify,
                gate_path=gate_for_verify,
                work_dir=iter_bundle / "_sec_work",
                mode="bmc",
                bound=bound,
                top_module="sec_miter",
                reset_expr=reset_expr,
                timeout_sec=timeout_sec,
                label="bmc",
            )
            _capture_ebmc_subprocess(
                miter_path=miter_path_for_capture,
                gold_path=gold_for_verify,
                gate_path=gate_for_verify,
                work_dir=iter_bundle / "_sec_work",
                mode="k_induction",
                bound=bound,
                top_module="sec_miter",
                reset_expr=reset_expr,
                timeout_sec=timeout_sec,
                label="kinduction_bare",
            )
        elapsed = time.time() - bmc_t0
        # ATH-1102: outcome-from-result helper escalates per-property
        # REFUTE to FAIL even when bmc_result.refuted (whole-result
        # aggregate) is False, so the counterexample-feedback retry
        # loop (ATH-1086) fires on partial refutes.
        result_str, diag_class = _iteration_outcome_from_bmc_result(bmc_result)
        bmc_result_data["result"] = result_str
        bmc_result_data["diagnostic_class"] = diag_class
        bmc_result_data["elapsed_sec"] = elapsed
        property_verdicts = dict(bmc_result.property_verdicts)
    except Exception as e:  # noqa: BLE001
        elapsed = time.time() - bmc_t0
        # Classify the exception: setup-class (license/config) vs
        # verifier-unavailable (toolchain parse/exit error / not
        # installed). NEITHER is a real BMC counter-example. Per
        # platform PR #503 honest-framing catch + cluster meta-rule
        # instance #11 + customer-claim engine-cross-check meta-rule:
        # don't mislabel setup-class errors as bmc_counterexample.
        exc_name = type(e).__name__
        if exc_name in ("LicenseScopeError", "ConfigurationError"):
            result_str = "SETUP_ERROR"
            diag_class = "setup_error"
        elif exc_name in (
            "EbmcRunFailure",
            "EbmcRunTimeoutError",
            "FileNotFoundError",
            "PermissionError",
        ):
            result_str = "SETUP_ERROR"
            diag_class = "verifier_unavailable"
        else:
            result_str = "SETUP_ERROR"
            diag_class = "verifier_unavailable"
        bmc_result_data["result"] = result_str
        bmc_result_data["diagnostic_class"] = diag_class
        bmc_result_data["elapsed_sec"] = elapsed
        bmc_result_data["error"] = f"{exc_name}: {str(e)[:300]}"
        property_verdicts = {}
    obs.emit("verify_attempt", run_subtype="theorem_proving", payload=bmc_result_data)

    if result_str == "FAIL":
        _analyze_bmc_failure(
            bmc_result=bmc_result,
            bmc_result_data=bmc_result_data,
            target_module=sig.get("target_module", "unknown"),
            log_fn=_vlog,
        )

    # Decide outcome from BMC result. PASS = accepted; FAIL = refuted;
    # SETUP_ERROR = errored (verifier didn't actually run); INCONCLUSIVE
    # = try k-induction with bridge invariant.
    bridges_used: list[str] = []
    if result_str == "PASS":
        outcome = "accepted"
        outcome_reason = "EBMC BMC verifier proved equivalence at bound k"
    elif result_str == "SETUP_ERROR":
        outcome = "errored"
        outcome_reason = (
            f"verifier did not run ({diag_class}): "
            f"{bmc_result_data.get('error', 'unknown')}"
        )
    else:
        # Initialize outcome/reason — the FAIL/INCONCLUSIVE escalation
        # paths below set these before falling through to the
        # iteration_verdict emit.
        outcome = "inconclusive"
        outcome_reason = "BMC FAIL/INCONCLUSIVE; escalation pending"
        # BMC FAIL or INCONCLUSIVE -> escalate to k-induction with
        # bridge invariant proposal. per CTO 2026-05-06 Option B:
        # FAIL escalation is the propose-verify-ADJUST-re-verify arc
        # the customer asked for. Interface-preserving structural variants
        # often BMC-FAIL from non-reachable transient states; k-
        # induction with a bridge invariant tying gate's internal
        # state encoding to gold's typically closes them. Real-FAIL
        # (semantic divergence) stays refuted: generate_invariant
        # halts on hard_refute.
        if result_str == "FAIL":
            target_property = next(
                (p for p, v in property_verdicts.items() if v.lower() == "refuted"),
                "sec_miter.full_match",
            )
        else:  # INCONCLUSIVE
            target_property = next(
                (
                    p for p, v in property_verdicts.items()
                    if v.lower() == "inconclusive"
                ),
                "sec_miter.full_match",
            )

        # ATH-1086 — counterexample-feedback proposer retry loop on
        # BMC FAIL. When max_proposer_inner_retries > 0 AND BMC came
        # back REFUTED, ask the proposer to refine using the EBMC
        # counterexample BEFORE escalating to invariant_gen (which is
        # for INCONCLUSIVE — bridge invariants can't fix REFUTE).
        # On any retry that PASSES, set outcome=accepted + skip
        # invariant_gen. On retry exhaustion or non-PASS, fall through
        # to the existing INCONCLUSIVE-path invariant_gen escalation.
        # Default max_proposer_inner_retries=0 preserves prior behavior.
        proposer_inner_retry_history: list[dict[str, Any]] = []
        if (
            max_proposer_inner_retries > 0
            and result_str == "FAIL"
        ):
            from kairos.sec.closed_loop.refine_after_refutation import (
                CounterexampleFeedback,
                refine_proposal_after_refutation,
            )
            current_proposal = proposal
            # ATH-1103 — accumulate every prior REFUTED attempt's
            # feedback as the retry chain advances, so each subsequent
            # call to refine_proposal_after_refutation sees the FULL
            # history. This makes the retry non-amnesic: proposer
            # recognizes "I already tried THIS specific approach 2
            # attempts ago, switch strategies."
            cumulative_prior_attempts: list[CounterexampleFeedback] = []
            for retry_idx in range(max_proposer_inner_retries):
                cex_summary = (
                    str(getattr(bmc_result, "counterexample", "") or "")[:300]
                )
                feedback = CounterexampleFeedback(
                    refuted_class=current_proposal.transformation_class,
                    refuted_gate_sv=tmp_gate.read_text(),
                    counterexample_summary=cex_summary or "<no counterexample text>",
                    ebmc_log_path=str(bmc_result_data.get("subprocess_log_path") or ""),
                    refuted_at_property=target_property,
                    prior_attempt_index=retry_idx,
                    prior_attempts=tuple(cumulative_prior_attempts),
                )
                attempt_t0 = time.time()
                refined: Any
                try:
                    refined = refine_proposal_after_refutation(
                        bundle_path=inputs_dir,
                        target_module=gold_module,
                        feedback=feedback,
                        model=proposer_model,
                        max_proposals=1,
                        timeout_sec=proposer_timeout_sec,
                    )
                except Exception as e:  # noqa: BLE001
                    proposer_inner_retry_history.append({
                        "attempt_index": retry_idx,
                        "attempt_status": "PARSE_ERROR",
                        "elapsed_sec": time.time() - attempt_t0,
                        "fail_detail": (
                            f"refine_proposal_after_refutation raised "
                            f"{type(e).__name__}: {str(e)[:200]}"
                        ),
                    })
                    break
                if refined.halt_reason != "ok" or not refined.proposals:
                    proposer_inner_retry_history.append({
                        "attempt_index": retry_idx,
                        "attempt_status": "PARSE_ERROR",
                        "elapsed_sec": time.time() - attempt_t0,
                        "fail_detail": f"refine halt_reason={refined.halt_reason}",
                    })
                    break
                refined_proposal = refined.proposals[0]
                # Write refined gate to tmp_gate, re-elaborate, re-run BMC.
                try:
                    tmp_gate.write_text(refined_proposal.gate_sv)
                    # Re-elaborate the refined gate; re-build miter via
                    # verify_sec which handles miter generation internally.
                    if dep_files_iter:
                        from kairos.sec.preprocess import (
                            yosys_elaborate_to_verilog as _refined_elab,
                        )
                        new_gate_elab = _refined_elab(
                            rtl_path=tmp_gate,
                            top_module=gate_module,
                            dep_files=dep_files_iter,
                            output_path=elab_dir / "gate_elab.v",
                            log_dir=elab_dir,
                            timeout_sec=timeout_sec,
                            parameter_overrides=param_overrides or None,
                        )
                        retry_gate_for_verify = Path(new_gate_elab.elaborated_path)
                    else:
                        retry_gate_for_verify = tmp_gate
                    retry_t0 = time.time()
                    retry_bmc = verify_sec(
                        gold_sv=gold_for_verify,
                        gate_v=retry_gate_for_verify,
                        gold_module=gold_module,
                        gate_module=gate_module,
                        ports=ports,
                        mode="bmc",
                        bound=bound,
                        clock_port=sig.get("clock_port", "clk"),
                        reset_port=sig.get("reset_port", "rst_n"),
                        reset_active_low=sig.get("reset_active_low", True),
                        timeout_sec=timeout_sec,
                        work_dir=iter_bundle / "_sec_work",
                        dep_files=deps_for_verify,
                    )
                    retry_elapsed = time.time() - retry_t0
                    # ATH-1102: same property-level escalation on the
                    # retry-side verdict so successive retries keep
                    # firing as long as any property still refutes.
                    retry_str, _ = _iteration_outcome_from_bmc_result(retry_bmc)
                    property_verdicts = dict(retry_bmc.property_verdicts)
                    bmc_result = retry_bmc
                    gate_for_verify = retry_gate_for_verify
                except Exception as e:  # noqa: BLE001
                    proposer_inner_retry_history.append({
                        "attempt_index": retry_idx,
                        "attempt_status": "EBMC_RUN_FAILURE",
                        "elapsed_sec": time.time() - attempt_t0,
                        "fail_detail": (
                            f"refined-gate retry raised {type(e).__name__}: "
                            f"{str(e)[:200]}"
                        ),
                    })
                    continue
                proposer_inner_retry_history.append({
                    "attempt_index": retry_idx,
                    "attempt_status": (
                        "PROVED" if retry_str == "PASS" else
                        "REFUTED" if retry_str == "FAIL" else
                        "INCONCLUSIVE"
                    ),
                    "elapsed_sec": retry_elapsed,
                    "transformation_class": (
                        refined_proposal.transformation_class.value
                    ),
                    "claimed_area_delta_pct": (
                        refined_proposal.claimed_area_delta_pct
                    ),
                })
                if retry_str == "PASS":
                    proposal = refined_proposal
                    result_str = "PASS"
                    outcome = "accepted"
                    outcome_reason = (
                        f"EBMC BMC verifier proved equivalence at bound k "
                        f"after {retry_idx + 1} counterexample-feedback "
                        f"retry attempt(s)"
                    )
                    break
                if retry_str == "INCONCLUSIVE":
                    result_str = "INCONCLUSIVE"
                    break
                # retry_str == "FAIL": continue retry loop. ATH-1103 —
                # snapshot this attempt's feedback into the cumulative
                # history BEFORE the next iteration, so retry_idx+1's
                # feedback carries every prior attempt including this
                # one.
                cumulative_prior_attempts.append(feedback)
                current_proposal = refined_proposal
            # End of retry loop. If outcome was set to "accepted" above,
            # skip the invariant_gen escalation. If retry loop exhausted
            # all attempts with FAIL still standing, fall through to
            # invariant_gen as the original code does (for completeness),
            # though invariant_gen typically halts on hard_refute.

        # CEGAR escalation — fires before invariant_gen when k-induction
        # is INCONCLUSIVE. CEGAR uses EBMC + LLM to propose assume
        # property hypotheses that close the refutation.
        if outcome != "accepted":
            try:
                from kairos.sv.cegar import cegar as run_cegar
                miter_path = iter_bundle / "_sec_work" / "miter.sv"
                if miter_path.is_file():
                    cegar_result = run_cegar(
                        spec=str(miter_path),
                        top_module="sec_miter",
                        bound=min(bound, 10),
                        max_iter=3,
                        budget_usd=2.0,
                        walltime_sec=min(timeout_sec, 300),
                        auto_accept_environmental=True,
                        clk=sig.get("clock_port", "clk"),
                        extra_files=[str(gold_for_verify), str(gate_for_verify)],
                    )
                    if cegar_result.terminated_reason == "proved":
                        outcome = "accepted"
                        outcome_reason = (
                            f"CEGAR closed proof after {cegar_result.iterations} "
                            f"iterations (${cegar_result.total_cost_usd:.2f})"
                        )
                        bridges_used.append("cegar_refinement")
            except Exception:  # noqa: BLE001
                pass  # CEGAR is best-effort escalation

        # Existing logic — only fires if CEGAR + counterexample-feedback
        # retry loop above didn't already accept the iteration.
        ig_result = None
        if outcome != "accepted":
            try:
                ig_result = generate_invariant(
                    bundle_path=iter_bundle,
                    target_property=target_property,
                    bound=bound,
                    timeout_sec=timeout_sec,
                )
            except Exception as e:  # noqa: BLE001
                outcome = "inconclusive"
                outcome_reason = (
                    f"Bridge-invariant generator raised "
                    f"{type(e).__name__} before producing a closeable "
                    f"candidate; verifier did not get a chance to discharge "
                    f"this iteration. Re-run may close it."
                )
        if ig_result is not None:
            for attempt in ig_result.attempts:
                obs.emit(
                    "bridge_invariant_proposed",
                    run_subtype="theorem_proving",
                    payload={
                        "iteration_index": iteration_index,
                        "parent_run_id": parent_run_id,
                        "bridge_label": attempt.candidate.label,
                        "bridge_text": attempt.candidate.sv_expression,
                        "proposer_model": proposer_model,
                        "lean_theorem_ref": attempt.candidate.proves_obligation,
                    },
                )
            kind_data: dict[str, Any] = {
                "iteration_index": iteration_index,
                "parent_run_id": parent_run_id,
                "engine": "ebmc_kinduction",
                "bound": bound,
                "result": "PASS" if ig_result.closed else "INCONCLUSIVE",
                "diagnostic_class": (
                    None if ig_result.closed else "kinduction_inconclusive"
                ),
                "elapsed_sec": 0.0,
            }
            obs.emit(
                "verify_attempt", run_subtype="theorem_proving", payload=kind_data,
            )
            if ig_result.closed and ig_result.chosen is not None:
                bridges_used.append(ig_result.chosen.label)
                outcome = "accepted"
                outcome_reason = (
                    f"k-induction PASS under assume-property bridge "
                    f"{ig_result.chosen.label} "
                    f"(BMC initial verdict: {result_str})"
                )
                # Lean formalization: discharge the bridge invariant
                # assumption via Lean type-check. The bridge is
                # ASSUMED by EBMC — Lean PROVES it holds, completing
                # the multi-layer defense-in-depth chain.
                try:
                    from kairos.sec.closed_loop._lean_formalize import (
                        formalize_witness,
                    )
                    lean_result = formalize_witness(
                        bridge_label=ig_result.chosen.label,
                        bridge_sv_expression=ig_result.chosen.sv_expression,
                        gold_module=gold_module,
                        gate_module=gate_module,
                    )
                    obs.emit("verify_attempt", run_subtype="theorem_proving", payload={
                        "iteration_index": iteration_index,
                        "parent_run_id": parent_run_id,
                        "engine": "lean_formalize",
                        "result": lean_result.kind,
                        "elapsed_sec": 0.0,
                    })
                    if lean_result.kind == "proof_axiom_clean":
                        outcome_reason += " + Lean proof discharged (axiom-clean)"
                except Exception:  # noqa: BLE001
                    pass  # Lean is best-effort enhancement
            elif ig_result.halt_reason == "hard_refute":
                outcome = "refuted"
                outcome_reason = (
                    f"k-induction hard_refute under bridge attempts: "
                    f"semantic divergence (BMC initial verdict: {result_str})"
                )
            else:
                outcome = "inconclusive"
                halt = ig_result.halt_reason or ""
                halt_lower = halt.lower()
                if any(
                    pat in halt_lower
                    for pat in (
                        "overloaded", "rate_limit", "rate-limit",
                        "ratelimiterror", "429", "503", "504",
                        "timeout", "timed out", "connection",
                    )
                ):
                    outcome_reason = (
                        "Bridge generation interrupted by transient LLM "
                        "provider availability; retry budget exhausted "
                        "without producing a closeable invariant. Re-run "
                        "may close this iteration accept-or-refute. "
                        f"(BMC initial verdict: {result_str})"
                    )
                elif "max_attempts" in halt_lower or "exhausted" in halt_lower:
                    outcome_reason = (
                        "Bridge proposer exhausted retry budget without "
                        "producing an invariant that closes k-induction. "
                        "The proposed transformation may be closeable "
                        "with a stronger bridge or a different proposer "
                        f"prompt. (BMC initial verdict: {result_str})"
                    )
                elif "parse_failure" in halt_lower or "parse failure" in halt_lower:
                    outcome_reason = (
                        "Bridge proposer LLM returned malformed JSON; "
                        "parser fail-closed without injecting an "
                        "invariant. Re-run may produce a parseable "
                        f"candidate. (BMC initial verdict: {result_str})"
                    )
                else:
                    halt_short = halt[:80] + ("..." if len(halt) > 80 else "")
                    outcome_reason = (
                        f"Bridge generation halted: {halt_short} "
                        f"(BMC initial verdict: {result_str})"
                    )

    # ACL2 algebraic discharge — final fallback when EBMC + invariant_gen
    # leave the iteration INCONCLUSIVE. ACL2's VL+FGL pipeline handles
    # algebraic equivalence that SAT-based methods can't scale to.
    if outcome == "inconclusive" and gold_for_verify.is_file() and gate_for_verify.is_file():
        try:
            from kairos.sec.closed_loop._acl2_discharge import acl2_discharge
            acl2_result = acl2_discharge(
                gold_sv=gold_for_verify,
                gate_v=gate_for_verify,
                gold_module=gold_module,
                gate_module=gate_module,
                timeout_sec=timeout_sec,
            )
            obs.emit("verify_attempt", run_subtype="theorem_proving", payload={
                "iteration_index": iteration_index,
                "parent_run_id": parent_run_id,
                "engine": "acl2_discharge",
                "result": "PASS" if acl2_result.proved else "INCONCLUSIVE",
                "elapsed_sec": acl2_result.elapsed_sec,
            })
            if acl2_result.proved:
                outcome = "accepted"
                outcome_reason = (
                    "ACL2 algebraic discharge PROVED equivalence "
                    f"(EBMC was {result_str}, invariant_gen was inconclusive)"
                )
                bridges_used.append("acl2_algebraic_discharge")
        except Exception:  # noqa: BLE001
            pass  # ACL2 fallback is best-effort

    obs.emit(
        "iteration_verdict",
        run_subtype="theorem_proving",
        payload={
            "iteration_index": iteration_index,
            "parent_run_id": parent_run_id,
            "outcome": outcome,
            "outcome_reason": outcome_reason,
            "area_delta_pct": (
                proposal.claimed_area_delta_pct if outcome == "accepted" else None
            ),
            "bridges_used": bridges_used,
        },
    )

    try:
        from kairos.sec.closed_loop.block_memory import record_iteration_outcome
        record_iteration_outcome(
            gold_path=str(inputs_dir / sig["gold_sv"]) if sig.get("gold_sv") else "",
            outcome=outcome, outcome_reason=outcome_reason,
            transformation_class=proposal.transformation_class.value,
            claimed_delta_pct=proposal.claimed_area_delta_pct,
            gold_cells=gold_cells_pre, gate_cells=gate_cells_pre,
            engine="ebmc_bmc",
            elapsed_seconds=elapsed if "elapsed" in dir() else 0.0,
            counterexample_summary=(
                str(getattr(bmc_result, "counterexample", "") or "")[:200]
                if "bmc_result" in dir() else ""
            ),
        )
    except Exception:  # noqa: BLE001
        pass

    # Auto-capture: record optimization result to knowledge_entries
    try:
        from kairos.auto_capture import auto_capture_optimization_result, write_to_knowledge_entries
        _ac_outcome = "proved" if outcome == "accepted" else outcome
        record = auto_capture_optimization_result(
            block_name=sig.get("target_module", "unknown"),
            outcome=_ac_outcome,
            delta_pct=round((gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2) if gold_cells_pre and gate_cells_pre else None,
            engine="ebmc_bmc",
            run_id=parent_run_id,
            agent_id=os.environ.get("KAIROS_AGENT_ID", "unknown"),
        )
        write_to_knowledge_entries(record)
    except Exception:  # noqa: BLE001
        pass

    return {
        "iteration_index": iteration_index,
        "outcome": outcome,
        "outcome_reason": outcome_reason,
        "transformation_class": proposal.transformation_class.value,
        "claimed_area_delta_pct": proposal.claimed_area_delta_pct,
        "bridges_used": bridges_used,
        "property_verdicts": property_verdicts,
        "gold_cells": gold_cells_pre,
        "gate_cells": gate_cells_pre,
        "measured_delta_pct": (
            round((gate_cells_pre - gold_cells_pre) / gold_cells_pre * 100, 2)
            if gold_cells_pre and gate_cells_pre else None
        ),
    }
