"""Result persistence — extracted from God Object (ATH-1415)."""
from __future__ import annotations

import json as _json
from pathlib import Path
from typing import Any

from kairos.sec.closed_loop.measurement import (
    measure_synthesis,
    measure_toggle_power,
)


def save_accepted_results(
    *,
    iteration_summaries: list[dict[str, Any]],
    work_dir: Path,
    bundle_path: Path,
    sig: dict[str, Any],
    target_module: str,
    block_name: str,
    model: str,
) -> None:
    """Save accepted optimization results to result_store."""
    from kairos.sec.closed_loop.result_store import save_result

    for idx, s in enumerate(iteration_summaries):
        if s.get("outcome") != "accepted":
            continue
        gate_path = work_dir / f"iter_{idx}_bundle" / "gate.v"
        if not gate_path.is_file():
            gate_path = work_dir / "iter_0_bundle" / "gate.v"
        if not gate_path.is_file():
            continue

        gold_elab = work_dir / "_gold_elab" / "gold_elab.v"
        has_params = bool(sig.get("parameters"))
        if gold_elab.is_file():
            gold_sv_path: Path | None = gold_elab
        elif has_params:
            gold_sv_path = None
        else:
            gold_sv_path = bundle_path / sig.get("gold_sv", "")

        gate_elab = work_dir / f"iter_{idx}_bundle" / "_elab" / "gate_elab.v"
        gate_measure = gate_elab if gate_elab.is_file() else gate_path

        if gold_sv_path is None:
            gold_cells = 0
            gate_cells = 0
        else:
            gold_cells = measure_synthesis(gold_sv_path, target_module) or 0
            gate_cells = measure_synthesis(gate_measure, f"{target_module}_gate") or 0

        if gold_cells > 0:
            measured_delta = round((gate_cells - gold_cells) / gold_cells * 100, 2)
        else:
            measured_delta = s.get("claimed_area_delta_pct", 0)

        toggle_result = measure_toggle_power(
            gold_path=gold_sv_path,
            gate_path=gate_path,
            gold_module=target_module,
            gate_module=f"{target_module}_gate",
            sig=sig,
            work_dir=work_dir,
        )

        save_result(
            block_name=block_name,
            gate_sv=gate_path.read_text(),
            gold_cells=gold_cells,
            gate_cells=gate_cells,
            measured_delta_pct=measured_delta,
            verified=True,
            model=model,
            transformation_class=s.get("transformation_class", ""),
            rationale=_json.dumps(toggle_result) if toggle_result else "",
        )
