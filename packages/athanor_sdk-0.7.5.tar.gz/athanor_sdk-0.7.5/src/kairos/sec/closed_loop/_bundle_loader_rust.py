"""Rust-accelerated bundle loading via PyO3.

Falls back to pure Python if compiled module unavailable.
The Rust version is faster for yosys elaboration + JSON parsing.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

_RUST_AVAILABLE = False

try:
    from kairos_env_allowlist import py_safe_env_for_yosys as _rust_safe_env
    _RUST_AVAILABLE = True
except ImportError:
    pass


def is_rust_available() -> bool:
    return _RUST_AVAILABLE
