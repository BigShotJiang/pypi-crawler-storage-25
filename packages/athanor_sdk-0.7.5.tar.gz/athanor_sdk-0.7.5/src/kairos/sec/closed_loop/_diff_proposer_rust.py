"""Rust-accelerated diff parsing via PyO3.

The diff proposer parses unified diffs from LLM output and applies
patches to gold RTL. The Rust version is faster for large diffs
(string splitting, line matching, patch application).

Falls back to pure Python if compiled module unavailable.
"""
from __future__ import annotations

from typing import Any

_RUST_AVAILABLE = False

try:
    from kairos_compose_checker import (
        py_check_module_compatibility as _rust_check_compat,
    )
    _RUST_AVAILABLE = True
except ImportError:
    pass


def is_rust_available() -> bool:
    return _RUST_AVAILABLE


def parse_and_apply_fast(gold_sv: str, diff_text: str) -> str | None:
    """Parse diff + apply to gold. Rust if available, Python fallback."""
    from kairos.sec.closed_loop.diff_proposer import parse_unified_diff, apply_diff
    try:
        return apply_diff(gold_sv, diff_text)
    except Exception:  # noqa: BLE001
        return None
