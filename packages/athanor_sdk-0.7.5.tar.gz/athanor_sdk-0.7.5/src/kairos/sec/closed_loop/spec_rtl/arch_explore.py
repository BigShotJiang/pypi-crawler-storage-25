"""ATH-1515: Architecture exploration from formal specification.

Given a validated spec (SVA + JSON), generates multiple architecture
options with tradeoff analysis. Each option includes a block diagram
(JSON structure), estimated tradeoffs (area/timing/power), and
interface contracts (SVA assumes/guarantees for composition).

The customer reviews options, picks one, and feeds it into
`kairos generate --arch` for RTL scaffolding.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from kairos.sec.closed_loop.spec_rtl.spec_loader import SpecSignature


@dataclass
class ArchOption:
    """One architecture option generated from a spec."""
    name: str
    description: str
    tradeoffs: dict[str, str]
    block_diagram: dict[str, Any]
    interface_contracts: list[dict[str, str]]
    estimated_area: str = "unknown"
    estimated_timing: str = "unknown"
    estimated_power: str = "unknown"

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "tradeoffs": self.tradeoffs,
            "block_diagram": self.block_diagram,
            "interface_contracts": self.interface_contracts,
            "estimated_area": self.estimated_area,
            "estimated_timing": self.estimated_timing,
            "estimated_power": self.estimated_power,
        }


@dataclass
class ArchExploreResult:
    """Result of architecture exploration."""
    spec: SpecSignature
    options: list[ArchOption]
    recommendation: int = 0

    def summary(self) -> str:
        lines = [f"Architecture exploration: {len(self.options)} options generated"]
        for i, opt in enumerate(self.options):
            marker = " ← recommended" if i == self.recommendation else ""
            lines.append(f"  [{i+1}] {opt.name}: {opt.description}{marker}")
            lines.append(f"      Area: {opt.estimated_area} | "
                        f"Timing: {opt.estimated_timing} | "
                        f"Power: {opt.estimated_power}")
        return "\n".join(lines)

    def as_dict(self) -> dict[str, Any]:
        return {
            "spec": self.spec.as_dict(),
            "options": [o.as_dict() for o in self.options],
            "recommendation": self.recommendation,
        }


def arch_explore(
    spec: SpecSignature,
    *,
    n_options: int = 3,
    model: str | None = None,
) -> ArchExploreResult:
    """Generate architecture options from a formal specification.

    Uses pattern-based generation for known block types.
    """
    module_name = spec.target_module.removesuffix("_spec")

    options = _generate_options(module_name, spec, n_options)
    recommendation = _rank_options(options) if options else 0

    return ArchExploreResult(
        spec=spec,
        options=options,
        recommendation=recommendation,
    )


def _generate_options(
    module_name: str,
    spec: SpecSignature,
    n_options: int,
) -> list[ArchOption]:
    """Generate architecture options based on spec analysis."""
    import re
    module_lower = module_name.lower()

    if re.search(r"\bfifo\b", module_lower):
        return _fifo_options(module_name, spec, n_options)
    elif re.search(r"\bcounter\b", module_lower):
        return _counter_options(module_name, spec, n_options)
    elif re.search(r"\balu\b", module_lower):
        return _alu_options(module_name, spec, n_options)
    else:
        return _generic_options(module_name, spec, n_options)


def _fifo_options(name: str, spec: SpecSignature, n: int) -> list[ArchOption]:
    options = [
        ArchOption(
            name="register_file_fifo",
            description="Register-based FIFO with separate read/write pointers",
            tradeoffs={
                "area": "Higher — one flip-flop per bit per entry",
                "timing": "Best — single-cycle read/write, no arbitration",
                "power": "Higher — all registers toggle on write",
            },
            block_diagram={
                "type": "register_file",
                "subblocks": ["write_pointer", "read_pointer", "memory_array", "status_logic"],
                "data_flow": "write_pointer → memory_array ← read_pointer → data_out",
            },
            interface_contracts=[
                {"type": "guarantee", "property": "full |-> !push accepted"},
                {"type": "guarantee", "property": "empty |-> !pop accepted"},
                {"type": "guarantee", "property": "!(full && empty)"},
            ],
            estimated_area="O(DEPTH × WIDTH) flip-flops",
            estimated_timing="1 cycle latency",
            estimated_power="High (all entries are registers)",
        ),
        ArchOption(
            name="sram_fifo",
            description="SRAM-backed FIFO with pointer comparison for status",
            tradeoffs={
                "area": "Lowest — SRAM macro replaces flip-flops",
                "timing": "1-2 cycle read latency (SRAM access)",
                "power": "Lowest — only active entries consume dynamic power",
            },
            block_diagram={
                "type": "sram_backed",
                "subblocks": ["write_pointer", "read_pointer", "sram_array", "status_comparator"],
                "data_flow": "write_pointer → sram_array ← read_pointer → data_out",
            },
            interface_contracts=[
                {"type": "guarantee", "property": "full flag correct within 1 cycle of write"},
                {"type": "assume", "property": "SRAM read latency ≤ 2 cycles"},
            ],
            estimated_area="O(1) logic + SRAM macro",
            estimated_timing="1-2 cycle latency",
            estimated_power="Low (SRAM power gating)",
        ),
        ArchOption(
            name="shift_register_fifo",
            description="Shift-register FIFO — data shifts on every read, no pointers",
            tradeoffs={
                "area": "Medium — shift registers + mux tree",
                "timing": "1 cycle but high fan-out on shift",
                "power": "Highest — every read shifts all entries",
            },
            block_diagram={
                "type": "shift_register",
                "subblocks": ["shift_chain", "count_register", "status_logic"],
                "data_flow": "data_in → shift_chain[0] → ... → shift_chain[N-1] → data_out",
            },
            interface_contracts=[
                {"type": "guarantee", "property": "FIFO ordering preserved (first-in, first-out)"},
                {"type": "guarantee", "property": "count always equals number of valid entries"},
            ],
            estimated_area="O(DEPTH × WIDTH) registers + mux",
            estimated_timing="1 cycle, high fan-out",
            estimated_power="Highest (full shift on read)",
        ),
    ]
    return options[:n]


def _counter_options(name: str, spec: SpecSignature, n: int) -> list[ArchOption]:
    options = [
        ArchOption(
            name="binary_counter",
            description="Standard binary counter with carry chain",
            tradeoffs={"area": "Minimal", "timing": "Good for small widths", "power": "Low"},
            block_diagram={"type": "binary", "subblocks": ["adder", "register", "comparator"]},
            interface_contracts=[{"type": "guarantee", "property": "count monotonically increases when enabled"}],
            estimated_area="O(WIDTH) gates",
            estimated_timing="O(WIDTH) carry propagation",
            estimated_power="Low",
        ),
        ArchOption(
            name="gray_counter",
            description="Gray-code counter — only 1 bit toggles per increment",
            tradeoffs={"area": "Slightly more (binary↔gray conversion)", "timing": "Same", "power": "Lowest"},
            block_diagram={"type": "gray_code", "subblocks": ["gray_register", "gray_to_binary", "binary_to_gray"]},
            interface_contracts=[{"type": "guarantee", "property": "exactly 1 bit changes per clock cycle"}],
            estimated_area="O(WIDTH) + conversion logic",
            estimated_timing="O(WIDTH)",
            estimated_power="Minimal toggle activity",
        ),
    ]
    return options[:n]


def _alu_options(name: str, spec: SpecSignature, n: int) -> list[ArchOption]:
    options = [
        ArchOption(
            name="mux_based_alu",
            description="Parallel compute all operations, mux select result",
            tradeoffs={"area": "Higher (all units active)", "timing": "Best (single mux delay)", "power": "Higher"},
            block_diagram={"type": "parallel_mux", "subblocks": ["adder", "subtractor", "logic_unit", "output_mux"]},
            interface_contracts=[{"type": "guarantee", "property": "result valid 1 cycle after operands"}],
            estimated_area="O(N_OPS × WIDTH)",
            estimated_timing="1 mux delay after longest operation",
            estimated_power="All units active every cycle",
        ),
        ArchOption(
            name="shared_datapath_alu",
            description="Shared adder/subtractor with mode-selected operation",
            tradeoffs={"area": "Lowest", "timing": "Slightly worse (mode decode)", "power": "Lowest"},
            block_diagram={"type": "shared_datapath", "subblocks": ["shared_adder", "mode_decoder", "logic_unit"]},
            interface_contracts=[{"type": "guarantee", "property": "result valid 1 cycle after operands"}],
            estimated_area="O(WIDTH) shared",
            estimated_timing="1 cycle + mode decode",
            estimated_power="Only active unit consumes power",
        ),
    ]
    return options[:n]


def _generic_options(name: str, spec: SpecSignature, n: int) -> list[ArchOption]:
    import re
    safe_name = re.sub(r"[^a-zA-Z0-9_]", "_", name)
    return [
        ArchOption(
            name=f"{safe_name}_baseline",
            description=f"Baseline architecture for {safe_name}",
            tradeoffs={"area": "Moderate", "timing": "Moderate", "power": "Moderate"},
            block_diagram={"type": "baseline", "subblocks": ["datapath", "control", "status"]},
            interface_contracts=[
                {"type": "guarantee", "property": inv.text}
                for inv in spec.invariants[:3]
            ],
            estimated_area="To be determined after RTL generation",
            estimated_timing="To be determined",
            estimated_power="To be determined",
        ),
    ]


def _rank_options(options: list[ArchOption]) -> int:
    """Recommend the first option (index 0). Ranking logic is a stub."""
    return 0


__all__ = ["arch_explore", "ArchOption", "ArchExploreResult"]
