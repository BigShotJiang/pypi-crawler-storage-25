"""ATH-1506: Spec→RTL incremental refinement with verified equivalence.

Customers provide a specification (SVA properties, Lean theorems) and
RTL implementations at successive refinement levels. Each step is
verified: RTL_i satisfies the spec invariants. Verified steps become
assumptions for the next level, building a compositional proof chain.
"""
from __future__ import annotations

from kairos.sec.closed_loop.spec_rtl.spec_loader import (
    SpecFormat,
    SpecInvariant,
    SpecSignature,
    load_spec,
)
from kairos.sec.closed_loop.spec_rtl.refinement_chain import (
    RefinementStep,
    RefinementChainResult,
    run_refinement_chain,
)

__all__ = [
    "SpecFormat",
    "SpecInvariant",
    "SpecSignature",
    "load_spec",
    "RefinementStep",
    "RefinementChainResult",
    "run_refinement_chain",
]
