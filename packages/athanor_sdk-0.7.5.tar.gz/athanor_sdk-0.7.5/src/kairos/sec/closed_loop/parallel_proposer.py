"""ATH-1104 — parallel-N proposer sampling across model classes.

Move #3 of the 2026-05-07 8-move orchestration plan. Compounds with
ATH-1102 (property-level refute trigger) + ATH-1103 (cumulative-
context retry).

## Problem

Today's orchestrator runs proposals sequentially: ``max_proposals=3``
means 3 sequential LLM calls, each generating one proposal. Sequential
= slow + only one model class explored = single-blind-spot risk. The
2026-05-07 dogfood Phase 1 fire on AP_REG_FIFO_US dout_y_match
illustrated this exactly: Opus consistently failed on the same
encoding-blind-spot across multiple sequential attempts, with no
opportunity for a different model family to catch the indexing
divergence.

## Fix

Sample K proposals in parallel across multiple model classes via
:class:`concurrent.futures.ThreadPoolExecutor`. LLM calls are
I/O-bound (HTTPS to Azure-hosted Anthropic + Gemini) so threading
works fine. Each worker invokes :func:`propose_transformations`
with one model from the configured mix.

Default mix per Aidan 2026-05-07 directive ("Sonnet for mechanical,
Opus for hard reasoning, multi-model for blind-spot diversity"):

* 2× Opus (hard reasoning)
* 2× Sonnet 4.6 (cheap parallel mechanical)
* 1× Gemini Pro 3.1 (different blind-spot family)

Total = 5 parallel branches. Customer's MCP install can override
via :func:`run_closed_loop_orchestration`'s
``parallel_proposer_models`` kwarg.

## Compounding with retry

Combined with ATH-1103's 5-retry inner loop, total proposer attempts
per fire = K × 5 = up to 25 attempts. At a per-attempt close-rate
estimate of ~10-20% on the dout_y_match-class blind spot, ensemble
probability is meaningfully higher.

## Public API

* :func:`propose_in_parallel` — dispatch K parallel proposer calls.
* :class:`ParallelProposalResult` — merged results with per-branch
  model attribution.
* :class:`ParallelBranchResult` — per-branch outcome.
* :data:`DEFAULT_PARALLEL_MODELS` — the 5-model default mix.
"""
from __future__ import annotations

import concurrent.futures
import time
from dataclasses import dataclass
from pathlib import Path

from kairos.model_presets import DEFAULT_SEC_PROPOSER_MODEL
from kairos.sec.closed_loop._proposer import (
    TransformationProposal,
    propose_transformations,
)


DEFAULT_PARALLEL_MODELS: tuple[str, ...] = (
    DEFAULT_SEC_PROPOSER_MODEL,
    "azure_ai/kimi-k2.6-1",
    "azure_ai/kimi-k2.6-1",
    "azure/gpt-5.5-1",
    "gemini/gemini-2.5-flash",
)


@dataclass(frozen=True)
class ParallelBranchResult:
    """One parallel proposer branch's outcome.

    ``model`` is the model id used for this branch. ``proposals`` is
    the list of TransformationProposal that branch returned (empty on
    error). ``error`` is the exception class name if the branch
    failed, else None. ``elapsed_sec`` is wall-clock time for this
    branch's LLM call.
    """

    model: str
    proposals: tuple[TransformationProposal, ...]
    error: str | None
    elapsed_sec: float


@dataclass(frozen=True)
class ParallelProposalResult:
    """Merged result of all K parallel proposer branches.

    Attributes
    ----------
    branches:
        Per-branch outcome (one entry per model in the configured mix).
    proposals:
        Flattened tuple of every TransformationProposal across every
        successful branch. Caller (orchestrator) iterates these
        through verify_sec like a single proposer's output.
    halt_reason:
        ``"ok"`` if at least one branch returned proposals; otherwise
        the first branch's halt_reason or ``"all_branches_failed"``.
    elapsed_sec:
        Wall-clock for the parallel dispatch (max of branch elapsed,
        plus thread-pool overhead).
    """

    branches: tuple[ParallelBranchResult, ...]
    proposals: tuple[TransformationProposal, ...]
    halt_reason: str
    elapsed_sec: float

    @property
    def successful_branch_count(self) -> int:
        """Count of branches that returned at least one proposal."""
        return sum(1 for b in self.branches if b.error is None and b.proposals)


def _propose_one_branch(
    *,
    bundle_path: Path,
    target_module: str,
    model: str,
    timeout_sec: int,
    max_proposals: int,
) -> ParallelBranchResult:
    """Worker function — invoke propose_transformations for one model.

    Catches every exception and surfaces it as a branch-level error
    so a single model failure (e.g. routing AuthError, rate-limit)
    doesn't crash the parallel dispatch — other branches keep
    running.
    """
    t0 = time.time()
    try:
        run = propose_transformations(
            bundle_path=bundle_path,
            target_module=target_module,
            model=model,
            max_proposals=max_proposals,
            timeout_sec=timeout_sec,
        )
        elapsed = time.time() - t0
        if run.halt_reason != "ok" or not run.proposals:
            return ParallelBranchResult(
                model=model,
                proposals=(),
                error=f"halt_reason={run.halt_reason}",
                elapsed_sec=elapsed,
            )
        return ParallelBranchResult(
            model=model,
            proposals=tuple(run.proposals),
            error=None,
            elapsed_sec=elapsed,
        )
    except Exception as e:  # noqa: BLE001
        elapsed = time.time() - t0
        return ParallelBranchResult(
            model=model,
            proposals=(),
            error=f"{type(e).__name__}: {str(e)[:200]}",
            elapsed_sec=elapsed,
        )


def propose_in_parallel(
    *,
    bundle_path: Path | str,
    target_module: str,
    K: int = 5,
    models: tuple[str, ...] | None = None,
    timeout_sec: int = 360,
    max_proposals_per_branch: int = 1,
) -> ParallelProposalResult:
    """Dispatch K proposer calls in parallel across the configured model mix.

    Each call runs in its own thread (LLM calls are I/O-bound). The
    proposer's bundle reading + JSON parsing run inside the worker
    thread; only the LLM HTTP call is the actual parallelism win.
    Threads return ParallelBranchResult; the merger flattens
    successful-branch proposals into a single tuple the caller
    iterates.

    Parameters
    ----------
    bundle_path:
        SEC bundle directory.
    target_module:
        Top-level module being optimized.
    K:
        Number of parallel branches. Caps at len(models) — extra
        K beyond model-mix length is silently truncated. Default 5.
    models:
        Per-branch model id tuple. If None, uses
        :data:`DEFAULT_PARALLEL_MODELS`. ``models[i]`` is the model
        for branch i; if i >= len(models), branch i uses
        ``models[i % len(models)]`` (round-robin) so K can exceed
        unique-model count for ensemble parallelism on a single
        model.
    timeout_sec:
        Per-branch LLM-call wall-clock cap.
    max_proposals_per_branch:
        How many proposals each branch's LLM response should contain.
        Default 1 (one focused proposal per branch); caller can bump
        for wider sampling.

    Returns
    -------
    :class:`ParallelProposalResult` with merged proposals + per-branch
    metadata.

    Notes
    -----
    Thread pool sized to K. ThreadPoolExecutor handles cleanup on
    completion. Per-branch errors don't crash the dispatch — error
    surface is in ParallelBranchResult.error.
    """
    bundle = Path(bundle_path)
    mix = models if models is not None else DEFAULT_PARALLEL_MODELS
    if not mix:
        return ParallelProposalResult(
            branches=(),
            proposals=(),
            halt_reason="empty_model_mix",
            elapsed_sec=0.0,
        )
    # Round-robin through the mix if K > len(mix).
    branch_models = [mix[i % len(mix)] for i in range(K)]
    t0 = time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=K) as pool:
        futures = [
            pool.submit(
                _propose_one_branch,
                bundle_path=bundle,
                target_module=target_module,
                model=m,
                timeout_sec=timeout_sec,
                max_proposals=max_proposals_per_branch,
            )
            for m in branch_models
        ]
        branches: list[ParallelBranchResult] = []
        for fut in concurrent.futures.as_completed(futures):
            branches.append(fut.result())
    elapsed = time.time() - t0
    # Preserve branch-submit order in the result so callers can
    # correlate index-to-model deterministically.
    branches_by_model_seq: list[ParallelBranchResult] = []
    used = [False] * len(branches)
    for m in branch_models:
        for i, b in enumerate(branches):
            if not used[i] and b.model == m:
                branches_by_model_seq.append(b)
                used[i] = True
                break
    # Flatten proposals. Order: branch order × within-branch order.
    flat: list[TransformationProposal] = []
    for b in branches_by_model_seq:
        flat.extend(b.proposals)
    if not flat:
        # Every branch failed or returned empty.
        first_err = (
            branches_by_model_seq[0].error
            if branches_by_model_seq
            else "all_branches_failed"
        )
        halt_reason = f"all_branches_failed: {first_err}"
    else:
        halt_reason = "ok"
    return ParallelProposalResult(
        branches=tuple(branches_by_model_seq),
        proposals=tuple(flat),
        halt_reason=halt_reason,
        elapsed_sec=elapsed,
    )


__all__ = [
    "DEFAULT_PARALLEL_MODELS",
    "ParallelBranchResult",
    "ParallelProposalResult",
    "propose_in_parallel",
]
