"""ATH-1115 sub-4: one-command fire CLI for customer agents.

Usage:
    kairos optimize --rtl AP_ALU_US.sv --deps AP_MUX_US.v --params DATA_WIDTH=8

Auto-detects clock/reset ports, auto-elaborates, auto-selects
verification engine (combo vs sequential). Builds the bundle,
runs the orchestrator, reports results.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

from kairos.security.env_allowlist import safe_env_for_yosys, validate_yosys_path
from kairos.security.path_sanitizer import validate_verilog_identifier


def auto_detect_clock_reset(rtl_text: str) -> tuple[str, str, bool]:
    """Detect clock and reset ports from RTL source.

    Two-tier detection:
    1. Port declarations: input [wire|logic|reg] <name> matching clock/reset patterns
    2. Always blocks: posedge/negedge usage (definitive for sequential)

    Returns (clock_port, reset_port, reset_active_low).
    """
    clock_port = ""
    reset_port = ""
    reset_active_low = True

    _CLK_NAMES = re.compile(r"\b(\w*clk\w*|\w*clock\w*|aclk|pclk|hclk|fclk)\b", re.IGNORECASE)
    _RST_NAMES = {
        "reset_n": True, "rst_n": True, "rstn": True, "areset_n": True,
        "reset": False, "rst": False, "areset": False,
    }

    for line in rtl_text.splitlines():
        low = line.strip().lower()
        if re.search(r"\binput\b", low):
            m = _CLK_NAMES.search(low)
            if m and not clock_port:
                clock_port = m.group(1)
            for name, active_low in _RST_NAMES.items():
                if re.search(rf"\b{name}\b", low):
                    reset_port = name
                    reset_active_low = active_low
                    break

        m_posedge = re.search(r"posedge\s+(\w+)", low)
        if m_posedge:
            sig = m_posedge.group(1)
            if _CLK_NAMES.match(sig) and not clock_port:
                clock_port = sig

        m_negedge = re.search(r"negedge\s+(\w+)", low)
        if m_negedge:
            sig = m_negedge.group(1)
            if sig in _RST_NAMES:
                reset_port = sig
                reset_active_low = _RST_NAMES[sig]

    return clock_port, reset_port, reset_active_low


def auto_extract_module_name(rtl_text: str) -> str | None:
    """Extract the first module name from RTL source."""
    for line in rtl_text.splitlines():
        m = re.match(r"\s*module\s+(\w+)", line)
        if m:
            return m.group(1)
    return None


def auto_extract_params(rtl_text: str) -> dict[str, int]:
    """Extract parameter names and default values."""
    params = {}
    for m in re.finditer(r"parameter\s+(\w+)\s*=\s*(\d+)", rtl_text):
        params[m.group(1)] = int(m.group(2))
    return params


def build_bundle_from_rtl(
    *,
    rtl_path: str | Path,
    dep_paths: list[str | Path] | None = None,
    param_overrides: dict[str, int] | None = None,
    output_dir: str | Path | None = None,
) -> Path:
    """Build a kairos SEC bundle from raw RTL files.

    This is the customer-facing entry point. Auto-detects everything
    the orchestrator needs: module name, ports, clock/reset, parameters.
    """
    rtl = Path(rtl_path).resolve()
    if not rtl.is_file():
        raise FileNotFoundError(f"RTL file not found: {rtl}")

    try:
        rtl_text = rtl.read_text()
    except UnicodeDecodeError:
        print(f"Error: cannot read {rtl} (binary or non-UTF-8 file)", file=sys.stderr)
        sys.exit(2)

    import hashlib as _hl
    _hasher = _hl.sha256(rtl_text.encode())
    for ext in ("*.v", "*.sv", "*.inc", "*.vh", "*.svh"):
        for sibling in sorted(rtl.parent.glob(ext)):
            if sibling.resolve() != rtl:
                st = sibling.stat()
                _hasher.update(f"{sibling.name}:{st.st_size}:{int(st.st_mtime)}".encode())
    if dep_paths:
        for dp in sorted(str(d) for d in dep_paths):
            dp_path = Path(dp)
            if dp_path.is_file():
                st = dp_path.stat()
                _hasher.update(f"{dp}:{st.st_size}:{int(st.st_mtime)}".encode())
            else:
                _hasher.update(dp.encode())
    if param_overrides:
        _hasher.update(str(sorted(param_overrides.items())).encode())
    _content_hash = _hasher.hexdigest()[:16]
    _cache_dir = Path(tempfile.gettempdir()) / f"kairos_bundle_cache_{_content_hash}"
    if output_dir is None and _cache_dir.is_dir() and (_cache_dir / "signature.json").is_file():
        return _cache_dir

    module_name = auto_extract_module_name(rtl_text)
    if not module_name:
        print(
            f"Error: no module declaration found in {rtl}. "
            f"Ensure the file contains 'module <name>(...);' "
            f"(Verilog-2001 or SystemVerilog).",
            file=sys.stderr,
        )
        sys.exit(2)

    clock_port, reset_port, reset_active_low = auto_detect_clock_reset(rtl_text)

    default_params = auto_extract_params(rtl_text)
    concrete_params = {**default_params, **(param_overrides or {})}
    if not param_overrides:
        for k, v in list(concrete_params.items()):
            if isinstance(v, int) and v > 64:
                concrete_params[k] = 16

    if output_dir is None:
        output_dir = _cache_dir
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    inputs_dir = output_dir / "inputs"
    inputs_dir.mkdir(exist_ok=True)
    gold_dest = inputs_dir / rtl.name
    gold_dest.write_text(rtl_text)

    dep_list = []
    effective_deps = list(dep_paths or [])
    if not effective_deps:
        for ext in ("*.sv", "*.v", "*.inc", "*.vh", "*.svh"):
            for sibling in rtl.parent.glob(ext):
                if (sibling.resolve() != rtl
                        and sibling.name != rtl.name
                        and not sibling.stem.startswith("gate")):
                    effective_deps.append(sibling)
    else:
        for ext in ("*.inc", "*.vh", "*.svh"):
            for sibling in rtl.parent.glob(ext):
                if sibling.resolve() not in {Path(d).resolve() for d in effective_deps}:
                    effective_deps.append(sibling)
    for dep in effective_deps:
        dp = Path(dep).resolve()
        if dp.is_file():
            dest = inputs_dir / dp.name
            dest.write_text(dp.read_text())
            dep_list.append(f"inputs/{dp.name}")

    yosys_bin = shutil.which("yosys")
    ports: list[dict[str, Any]] = []
    if yosys_bin:
        validate_yosys_path(str(gold_dest))
        rtl_files = [str(gold_dest)]
        inc_dirs: set[str] = set()
        for d in dep_list:
            fp = inputs_dir / Path(d).name
            if fp.suffix in (".inc", ".vh", ".svh"):
                inc_dirs.add(str(fp.parent))
            else:
                rtl_files.append(str(fp))
        inc_flags = " ".join(f"-I{d}" for d in sorted(inc_dirs))
        chparam = ""
        if concrete_params:
            pstr = " ".join(f"-set {k} {v}" for k, v in concrete_params.items())
            chparam = f"chparam {pstr} {module_name}; "
        json_out = output_dir / "_yosys_ports.json"
        r = subprocess.run(
            [yosys_bin, "-p",
             f"read_verilog -sv {inc_flags} {' '.join(rtl_files)}; "
             f"{chparam}"
             f"hierarchy -check -top {module_name}; "
             f"proc; opt; write_json {json_out}"],
            capture_output=True, text=True, timeout=30,
            env=safe_env_for_yosys(),
        )
        if r.returncode == 0 and json_out.is_file():
            data = json.loads(json_out.read_text())
            mod_data = data.get("modules", {}).get(module_name, {})
            ports = [
                {"name": pn, "direction": pi["direction"],
                 "width": len(pi["bits"])}
                for pn, pi in mod_data.get("ports", {}).items()
            ]

    sig = {
        "target_module": module_name,
        "gold_module": module_name,
        "gate_module": f"{module_name}_gate",
        "gold_sv": f"inputs/{rtl.name}",
        "dep_files": dep_list,
        "ports": ports,
        "parameters": [
            {"name": k, "default": v, "concrete_for_sec": v}
            for k, v in concrete_params.items()
        ],
        "clock_port": clock_port,
        "reset_port": reset_port,
        "reset_active_low": reset_active_low,
        "formal_invariants_primer": [],
        "proposer_hints": [],
    }
    (output_dir / "signature.json").write_text(json.dumps(sig, indent=2))
    return output_dir


def _check_ollama() -> bool:
    """Check if ollama is running locally."""
    try:
        import urllib.request
        r = urllib.request.urlopen("http://localhost:11434/api/tags", timeout=2)
        return r.status == 200
    except Exception:  # noqa: BLE001
        return False


def detect_proposer_backend() -> str:
    """Auto-detect the best proposer backend for the current environment.

    Priority:
    0. KAIROS_PROPOSER_BACKEND env → explicit override
    1. OLLAMA_HOST or ollama running → local (customer RTL stays local)
    2. ANTHROPIC_API_KEY set → litellm (direct API)
    3. AWS_ACCESS_KEY_ID + AWS_DEFAULT_REGION set → litellm (Bedrock)
    4. claude CLI on PATH → claude-agent (zero API cost)
    5. None → raise with setup instructions
    """
    import os

    explicit = os.environ.get("KAIROS_PROPOSER_BACKEND")
    if explicit:
        return explicit

    if os.environ.get("OLLAMA_HOST") or _check_ollama():
        return "local"

    if os.environ.get("ANTHROPIC_API_KEY"):
        return "litellm"

    if os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("AWS_DEFAULT_REGION"):
        return "litellm"

    claude_bin = shutil.which("claude")
    if claude_bin:
        return "claude-agent"

    raise ValueError(
        "No proposer backend detected. kairos optimize needs one of:\n"
        "\n"
        "  Option 1 (local):     ollama serve (RTL never leaves your machine)\n"
        "  Option 2 (API key):   export ANTHROPIC_API_KEY=sk-ant-...\n"
        "  Option 3 (Bedrock):   export AWS_ACCESS_KEY_ID=... AWS_DEFAULT_REGION=...\n"
        "  Option 4 (Claude):    install Claude Code CLI (claude on PATH)\n"
        "\n"
        "Then re-run: kairos optimize <your-block.sv>\n"
        "Run 'kairos doctor' for a full environment check."
    )


def optimize(
    *,
    rtl_path: str | Path,
    dep_paths: list[str | Path] | None = None,
    param_overrides: dict[str, int] | None = None,
    config_path: str | Path | None = None,
    model: str | None = None,
    max_proposals: int | None = None,
    timeout_sec: int | None = None,
    engine: str | None = None,
    proposer_mode: str | None = None,
    proposer_backend: str | None = None,
    preset: str | None = None,
    allowed_transforms: frozenset[str] | None = None,
    k_induction_bound: int | None = None,
    **config_overrides: Any,
) -> Any:
    """One-command optimization: build bundle + run orchestrator.

    Requires paid license with 'solve' product access.

    Args:
        engine: Custom verification engine name (registered via
            ``kairos.register_engine``). If None, uses the default
            engine selection (yosys for combo, EBMC for sequential).
        proposer_mode: Proposer mode override ('full', 'diff',
            'preserve_datapath'). If None, uses flow_config default.

    Customer configures behavior via kairos.yaml or keyword args.
    Every parameter has a safe default with structural validation.
    """
    from kairos.sec.closed_loop.flow_config import load_flow_config, load_preset
    from kairos.sec.closed_loop.flow_guard import validate_flow

    if preset and not config_path:
        config = load_preset(preset, **config_overrides)
    else:
        config = load_flow_config(config_path=config_path, **config_overrides)

    advice = validate_flow(config)
    if not advice.valid:
        raise ValueError(
            f"Flow rejected by safety guard: {'; '.join(advice.errors)}. "
            f"Suggestions: {'; '.join(advice.suggestions)}"
        )

    # abc_only (max_cost_usd=0) uses only local yosys/ABC — no LLM,
    # no paid features. Skip license check for zero-cost evaluation.
    _skip_license = config.max_cost_usd == 0
    if not _skip_license:
        from kairos.license_scope import require_product
        require_product("solve")

    if proposer_backend is None:
        proposer_backend = detect_proposer_backend()

    bundle = build_bundle_from_rtl(
        rtl_path=rtl_path,
        dep_paths=dep_paths,
        param_overrides=param_overrides,
    )
    module_name = auto_extract_module_name(Path(rtl_path).read_text())
    if not module_name:
        raise ValueError(
            f"Could not extract a module name from {rtl_path}. "
            f"Ensure the file contains a valid Verilog/SystemVerilog "
            f"'module <name>' declaration."
        )

    from kairos.plan import plan_optimize, compare_plan_to_result
    plan = plan_optimize(rtl_path)
    import sys as _sys
    print(plan.summary(), file=_sys.stderr)
    if config_overrides.get("plan_only"):
        return plan

    from kairos.sec.closed_loop._orchestrator import run_closed_loop_orchestration
    effective_proposals = max_proposals or config.max_proposals
    if config.max_cost_usd == 0:
        effective_proposals = 0

    # ATH-1078: mode-driven k-bound override takes precedence over config.
    effective_k_bound = k_induction_bound if k_induction_bound is not None else config.k_induction_bound

    return run_closed_loop_orchestration(
        bundle_path=bundle,
        target_module=module_name,
        model=model or config.models[0],
        elaborate_gold=config.elaborate_gold,
        max_proposals=effective_proposals,
        max_proposer_inner_retries=config.max_inner_retries,
        k_induction_bound=effective_k_bound,
        timeout_sec=timeout_sec or config.verification_timeout_sec or 1800,
        proposer_timeout_sec=config.proposer_timeout_sec,
        proposer_mode=proposer_mode or config.proposer_mode or (
            "full" if len(rtl_text.splitlines()) < 50 else "diff"
        ),
        proposer_backend=proposer_backend,
        mine_before_propose=config.mine_before_propose,
        custom_engine=engine,
        allowed_transforms=allowed_transforms,
    )


__all__ = [
    "auto_detect_clock_reset",
    "auto_extract_module_name",
    "auto_extract_params",
    "build_bundle_from_rtl",
    "optimize",
]
