"""Persist optimization results so they never get lost.

Every proposal that measures below threshold is immediately saved
to a permanent directory with its metadata. No more tempdir losses.
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass
class SavedResult:
    """One saved optimization result."""
    block_name: str
    gate_path: Path
    gold_cells: int
    gate_cells: int
    measured_delta_pct: float
    verified: bool
    timestamp: str
    model: str = ""
    transformation_class: str = ""
    rationale: str = ""


RESULTS_DIR = Path.home() / ".kairos" / "optimization_results"


def save_result(
    *,
    block_name: str,
    gate_sv: str,
    gold_cells: int,
    gate_cells: int,
    measured_delta_pct: float,
    verified: bool,
    model: str = "",
    transformation_class: str = "",
    rationale: str = "",
) -> Path:
    """Save a gate file + metadata permanently. Returns the saved path."""
    block_dir = RESULTS_DIR / block_name
    block_dir.mkdir(parents=True, exist_ok=True)

    ts = time.strftime("%Y%m%d_%H%M%S")
    delta_str = f"{abs(measured_delta_pct):.1f}pct"
    status = "verified" if verified else "unverified"
    name = f"{ts}_{delta_str}_{status}"

    gate_path = block_dir / f"{name}_gate.v"
    meta_path = block_dir / f"{name}_meta.json"

    gate_path.write_text(gate_sv)
    meta_path.write_text(json.dumps({
        "block_name": block_name,
        "gold_cells": gold_cells,
        "gate_cells": gate_cells,
        "measured_delta_pct": measured_delta_pct,
        "verified": verified,
        "model": model,
        "transformation_class": transformation_class,
        "rationale": rationale[:500],
        "timestamp": ts,
        "gate_file": gate_path.name,
    }, indent=2))

    # Emit to Supabase/observe so results reach the DB
    _emit_result_event({
        "block_name": block_name,
        "gold_cells": gold_cells,
        "gate_cells": gate_cells,
        "measured_delta_pct": measured_delta_pct,
        "verified": verified,
        "model": model,
        "transformation_class": transformation_class,
        "gate_file": str(gate_path),
        "timestamp": ts,
    })

    return gate_path


def get_best_verified(block_name: str) -> Path | None:
    """Return the path to the best verified gate for a block, or None."""
    block_dir = RESULTS_DIR / block_name
    if not block_dir.is_dir():
        return None

    best_delta = 0.0
    best_path = None
    for meta in block_dir.glob("*_meta.json"):
        data = json.loads(meta.read_text())
        if data.get("verified") and data.get("measured_delta_pct", 0) < best_delta:
            best_delta = data["measured_delta_pct"]
            gate_file = block_dir / data["gate_file"]
            if gate_file.is_file():
                best_path = gate_file

    return best_path


__all__ = ["SavedResult", "save_result", "get_best_verified", "RESULTS_DIR"]


def _emit_result_event(result_meta: dict[str, Any]) -> None:
    """Best-effort emit to kairos.observe so results land in Supabase."""
    try:
        from kairos.observe import emit as obs_emit
        obs_emit(
            "optimization_result_saved",
            run_subtype="theorem_proving",
            payload={
                "block_name": result_meta.get("block_name"),
                "gold_cells": result_meta.get("gold_cells"),
                "gate_cells": result_meta.get("gate_cells"),
                "measured_delta_pct": result_meta.get("measured_delta_pct"),
                "verified": result_meta.get("verified"),
                "model": result_meta.get("model"),
                "transformation_class": result_meta.get("transformation_class"),
                "gate_file": result_meta.get("gate_file"),
                "timestamp": result_meta.get("timestamp"),
            },
        )
    except Exception:  # noqa: BLE001
        pass  # Best-effort — don't crash on emit failure
