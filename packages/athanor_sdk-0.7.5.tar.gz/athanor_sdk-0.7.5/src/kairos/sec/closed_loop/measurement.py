"""ATH-1115 sub-2: measurement utilities extracted from _orchestrator.py.

Synthesis cell count, toggle-activity power, cert tarball SHA-256.
Separated so each measurement function is independently testable
and the orchestrator delegates without inlining the implementation.
"""
from __future__ import annotations

import hashlib
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

from kairos.security.env_allowlist import safe_env_for_yosys
from kairos.security.path_sanitizer import (
    build_yosys_inc_flags,
    sanitize_yosys_path,
    validate_verilog_identifier,
)


def measure_synthesis(
    design_path: Path,
    module_name: str,
    deps: list[Path] | None = None,
    use_cache: bool = True,
) -> int | None:
    """Run yosys synth and return cell count, or None on failure.

    ATH-1115.1: callers must pass the ELABORATED gold (params baked in),
    never the raw parameterized source. The orchestrator enforces this
    by checking for gold_elab before calling.

    ATH-1471: results cached by file content hash. Gold synthesis is
    immutable within a run — cache hit avoids re-running yosys.
    """
    if use_cache:
        from kairos.ebmc_cache import get_synth_cache
        hit, cached = get_synth_cache().get(design_path, module_name)
        if hit:
            return cached

    yosys_bin = shutil.which("yosys")
    if yosys_bin is None:
        return None
    sanitize_yosys_path(design_path)
    validate_verilog_identifier(module_name, "module_name")
    safe_deps = []
    for dp in (deps or []):
        sanitize_yosys_path(dp)
        safe_deps.append(dp)
    inc_flags = build_yosys_inc_flags([design_path, *safe_deps])
    inc_prefix = f"{inc_flags} " if inc_flags else ""
    safe_design = str(Path(design_path).resolve())
    try:
        r = subprocess.run(
            [yosys_bin, "-p",
             f"read_verilog -sv -formal {inc_prefix}{safe_design}; "
             f"synth -flatten -top {module_name}; stat"],
            capture_output=True, text=True, timeout=60,
            env=safe_env_for_yosys(),
        )
        m = re.search(r"Number of cells:\s+(\d+)", r.stdout)
        result = int(m.group(1)) if m else None

        if use_cache:
            from kairos.ebmc_cache import get_synth_cache
            get_synth_cache().put(design_path, module_name, result)

        return result
    except Exception:  # noqa: BLE001
        return None


def measure_toggle_power(
    *,
    gold_path: Path,
    gate_path: Path,
    gold_module: str,
    gate_module: str,
    sig: dict[str, Any],
    work_dir: Path,
) -> dict[str, Any] | None:
    """Run toggle-activity power measurement, return summary dict or None."""
    try:
        from kairos.sec.closed_loop.toggle_power import (
            measure_toggle_power as _toggle,
        )
        ports = [
            {"name": p["name"], "direction": p["direction"],
             "width": p.get("width", 1)}
            for p in sig.get("ports", [])
        ]
        result = _toggle(
            gold_files=[gold_path],
            gate_files=[gate_path],
            gold_module=gold_module,
            gate_module=gate_module,
            ports=ports,
            clock_port=sig.get("clock_port", "clk"),
            reset_port=sig.get("reset_port", "rst_n"),
            reset_active_low=bool(sig.get("reset_active_low", True)),
            sim_cycles=200,
            work_dir=work_dir / "toggle_power",
        )
        return {
            "gold_toggles": result.gold_total,
            "gate_toggles": result.gate_total,
            "toggle_delta_pct": result.toggle_delta_pct,
        }
    except Exception:  # noqa: BLE001
        return None


def sha256_of_file(path: Path) -> str:
    """Hex sha256 digest of a file's bytes."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def is_subpath(child: Path, parent: Path) -> bool:
    """Check if child is under parent directory (resolves symlinks)."""
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def build_cert_payload(
    *,
    parent_run_id: str,
    block_name: str,
    iteration_summaries: list[dict[str, Any]],
    bundle_path: str,
) -> dict[str, Any]:
    """Build customer_block_certificate_complete payload from iteration trace.

    Honest framing: accepted AND refuted candidates both surface in the cert.
    """
    n_proposed = len(iteration_summaries)
    accepted = [s for s in iteration_summaries if s["outcome"] == "accepted"]
    refuted = [s for s in iteration_summaries if s["outcome"] == "refuted"]
    inconclusive = [
        s for s in iteration_summaries if s["outcome"] == "inconclusive"
    ]
    errored = [s for s in iteration_summaries if s["outcome"] == "errored"]
    # ATH-1502: compute final delta from actual yosys cell counts,
    # not the proposer's claimed_area_delta_pct.
    _measured_deltas = []
    for s in accepted:
        g = s.get("gold_cells", 0)
        t = s.get("gate_cells", 0)
        if g and g > 0:
            _measured_deltas.append(round((t - g) / g * 100, 2))
    final_delta = min(_measured_deltas) if _measured_deltas else 0.0

    per_property: list[dict[str, Any]] = []
    assumption_stack: list[str] = []
    for s in iteration_summaries:
        property_name = (
            f"iter_{s['iteration_index']}_{s['transformation_class']}"
        )
        verdict_label = {
            "accepted": "PROVED-with-assume" if s["bridges_used"] else "PROVED",
            "refuted": "REFUTED",
            "inconclusive": "INCONCLUSIVE",
            "errored": "ERRORED",
        }[s["outcome"]]
        per_property.append({
            "property": property_name,
            "verdict": verdict_label,
            "bridge_invariant": (
                f"bridges: {', '.join(s['bridges_used'])}"
                if s["bridges_used"]
                else None
            ),
            "bridge_label": s["bridges_used"][0] if s["bridges_used"] else None,
            "diagnostic_class": (
                "bmc_counterexample" if s["outcome"] == "refuted" else None
            ),
        })
        for label in s["bridges_used"]:
            assumption_stack.append(
                f"{label} (iter_{s['iteration_index']}) "
                f"[UNPROVEN -- assumed; v2.7 D-spike]",
            )

    return {
        "block_name": block_name,
        "verdict_summary": (
            f"{n_proposed} transformation(s) proposed -> "
            f"{len(accepted)} accepted, "
            f"{len(refuted)} refuted, {len(inconclusive)} inconclusive, "
            f"{len(errored)} errored. Final area delta: {final_delta:+.1f}%."
        ),
        "per_property_verdicts": per_property,
        "assumption_stack": assumption_stack,
        "lean_proves_obligations": [],
        "n_proved": len(accepted),
        "n_refuted": len(refuted),
        "n_inconclusive": len(inconclusive),
        "total_properties": n_proposed,
        "discharge_engine": (
            "EBMC BMC + k-induction with LLM-driven bridge invariants"
        ),
        "bundle_path": bundle_path,
    }


__all__ = [
    "measure_synthesis",
    "measure_toggle_power",
    "sha256_of_file",
    "build_cert_payload",
    "is_subpath",
]
