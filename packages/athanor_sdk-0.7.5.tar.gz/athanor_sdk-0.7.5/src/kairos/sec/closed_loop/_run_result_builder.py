"""Run result builder — extracted from God Object (ATH-1415).

Builds cert payload, emits events, creates ClosedLoopResult, saves results.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from kairos.sec.closed_loop.measurement import (
    sha256_of_file as _sha256_of_file,
    is_subpath as _is_subpath,
)
from kairos.sec.closed_loop.measurement import (
    build_cert_payload as _build_cert_payload,
)


_HALT_HUMAN: dict[str, str] = {
    "proved_equivalent_variant_found": (
        "Found a verified-equivalent optimization with area reduction."
    ),
    "no_proposal_closed": (
        "All proposals were tried but none passed formal equivalence "
        "verification. The block may already be near-optimal, or try "
        "a different proposer model or increase max_proposals."
    ),
    "max_iterations": (
        "Iteration cap reached before finding a verified optimization. "
        "Increase max_proposals in kairos.yaml to explore more candidates."
    ),
}


def build_and_emit_result(
    *,
    run_id: str,
    halt: str,
    iteration_summaries: list[dict[str, Any]],
    bundle_path: Path,
    repo_root: Path | None,
    work_dir: Path,
    sig: dict[str, Any],
    target_module: str,
    block_name: str,
    model: str,
    emit_fn: Any,
) -> Any:
    """Build cert payload, emit events, create ClosedLoopResult, save."""
    from kairos.sec.closed_loop._orchestrator import ClosedLoopResult

    emit_fn(
        "iteration_complete",
        run_subtype="theorem_proving",
        payload={
            "iteration_index": len(iteration_summaries) - 1,
            "parent_run_id": run_id,
            "halt_reason": halt,
            "halt_reason_human": _HALT_HUMAN.get(halt, halt),
        },
    )

    bundle_display = (
        str(bundle_path.relative_to(repo_root))
        if repo_root is not None and _is_subpath(bundle_path, repo_root)
        else str(bundle_path)
    )
    cert_payload = _build_cert_payload(
        parent_run_id=run_id,
        block_name=block_name,
        iteration_summaries=iteration_summaries,
        bundle_path=bundle_display,
    )

    try:
        from kairos.sec.closed_loop.cert_tarball import (
            CERT_TARBALL_FORMAT_VERSION,
            build_cert_tarball,
        )
        tarball_path = work_dir / f"{block_name}_kairos_cert.tar.gz"
        sec_work_root = bundle_path / "_sec_work"
        if sec_work_root.is_dir():
            build_cert_tarball(
                cert_payload=cert_payload,
                bundle_path=bundle_path,
                sec_work_dir=sec_work_root,
                output_path=tarball_path,
                iteration_count=cert_payload["total_properties"],
            )
            cert_payload["cert_tarball_path"] = str(tarball_path)
            cert_payload["cert_tarball_sha256"] = _sha256_of_file(tarball_path)
            cert_payload["cert_tarball_size_bytes"] = tarball_path.stat().st_size
            cert_payload["cert_tarball_format_version"] = CERT_TARBALL_FORMAT_VERSION
    except Exception:  # noqa: BLE001
        pass

    n_proved = sum(1 for s in iteration_summaries if s["outcome"] == "accepted")
    if n_proved > 0:
        emit_fn(
            "customer_block_certificate_complete",
            run_subtype="theorem_proving",
            payload=cert_payload,
        )

    result = ClosedLoopResult(
        parent_run_id=run_id,
        halt_reason=halt,
        iteration_summaries=iteration_summaries,
        cert_payload=cert_payload,
        proposer_halt_reason=None,
    )

    try:
        from kairos.sec.closed_loop._result_saver import save_accepted_results
        save_accepted_results(
            iteration_summaries=iteration_summaries,
            work_dir=work_dir,
            bundle_path=bundle_path,
            sig=sig,
            target_module=target_module,
            block_name=block_name,
            model=model,
        )
    except Exception:  # noqa: BLE001
        pass

    return result
