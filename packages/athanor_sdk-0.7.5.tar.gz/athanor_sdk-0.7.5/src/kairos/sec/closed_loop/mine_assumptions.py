r"""ATH-1087 Phase A — assumption mining for closed-loop SEC.

Per the customer's strategy realignment (ATH-1078) Phase 1a Step 1:
LLM proposes N structural assertions describing operating-mode invariants
(things that hold during normal use, NOT under adversarial inputs); EBMC
Mode 1 (no miter, single design + assert property) verifies each
candidate; PROVED keeps, REFUTED drops, INCONCLUSIVE retries.

**Mining vs bug-finding distinction (customer clarification
ts 1778163960):** existing assertions in the customer's RTL (any
``assert property`` statement already in the source) + signature.json
declared properties are treated as TRUE without re-proving. Mining
operates in the LAYER ABOVE: LLM proposes NEW invariants the customer
has not stated; EBMC Mode 1 proves each NEW assertion against the design
+ existing assertion set. REFUTED on a NEW assertion means the LLM was
wrong about the invariant, NOT that the customer's code has a bug. This
is explicitly NOT assertion-checking / bug-hunting mode.

The output assumption set is then used downstream by the proposer (as
prompt context: "you may assume these properties hold during your
proposed transformation") AND by the equivalence-miter (as
``assume property`` constraints, narrowing the input space EBMC
explores). This closes the gap that drove Phase 1's 0/6 close at
FIFO_DEPTH=4: LLM transformations are correct under realistic operating
conditions but unsound under adversarial inputs the assumption set
should be excluding.

Design discipline (per Aidan no-LLM-hallucination directive
2026-05-07 ts 1778160820 + CTO inner+outer-loop directive
ts ATH-1089): every LLM-proposed assertion passes through EBMC Mode 1
gate before joining the assumption set. Hallucinated assertions get
REFUTED + dropped — never become assumptions. Architecture-defense
via gate-on-LLM-output, not prompt-side sanitization.

Inner-loop retry per CTO ATH-1089 spec: when EBMC returns INCONCLUSIVE
or the assertion has a syntax error, the LLM gets ``max_inner_retries``
chances to revise (default 2 per miner = cost-priced cap). On REFUTED,
no retry — refuted means the assertion is wrong about the design,
not that the LLM phrased it badly.

Per platform-side render contract (V27IterationArcPanel
AssumptionsMinedSection per ATH-1079 delta 2): every mined attempt
appears on inner_retry_history with attempt_status (PROVED / REFUTED /
INCONCLUSIVE / REVISED_AFTER), counterexample summary, ebmc_log_path,
elapsed.

## Public API

* :func:`mine_assumptions` — entry. Calls LLM, runs EBMC Mode 1, returns
  :class:`AssumptionMiningResult`.
* :class:`AssumptionMiningResult` — frozen dataclass holding proved
  + refuted + inconclusive lists, total elapsed, model id.
* :class:`MinedAssumption` — per-assertion result with SVA literal,
  status, ebmc_log_path, counterexample, inner_retry_history.

## Cross-refs

* ATH-1087 (parent ticket; A=this SDK lib, B=schemas+MCP).
* ATH-1089 (inner-retry harness — ``with_inner_retry`` primitive).
* ATH-1090 (full-CEGAR + ACL2 + Lean — assumption mining feeds CEGAR
  abstraction set).
* Aidan 2026-05-07 directives (no-LLM-hallucination, retry-budget,
  inner+outer loop).
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Literal

from kairos.model_presets import DEFAULT_SEC_REASONING_MODEL


AssumptionStatus = Literal["PROVED", "REFUTED", "INCONCLUSIVE", "PARSE_ERROR", "GATE_BREAKS"]
InnerAttemptStatus = Literal[
    "PROVED",
    "REFUTED",
    "INCONCLUSIVE",
    "REVISED_AFTER",
    "PARSE_ERROR",
    "EBMC_RUN_FAILURE",
]


@dataclass(frozen=True)
class InnerRetryAttempt:
    """One inner-loop attempt — LLM proposes, EBMC Mode 1 verifies.

    Mirrors smoke-validation's ``k_attempt_matrix`` row pattern + the
    inner_retry_history shape platform locked in the ATH-1087 cross-arm
    contract review (Slack ts 1778159612).
    """

    attempt_index: int
    attempt_status: InnerAttemptStatus
    sva_text: str
    ebmc_log_path: str | None = None
    counterexample_summary: str | None = None
    elapsed_sec: float = 0.0


@dataclass(frozen=True)
class MinedAssumption:
    """One mined assertion's final outcome + the inner-retry path that produced it."""

    assertion_id: str
    sva_text: str
    status: AssumptionStatus
    ebmc_log_path: str | None
    counterexample_summary: str | None
    inner_retry_history: tuple[InnerRetryAttempt, ...]
    elapsed_sec: float


@dataclass(frozen=True)
class AssumptionMiningResult:
    """Full mining outcome — what the proposer + miter consume downstream.

    Attributes
    ----------
    bundle_path:
        Resolved absolute path to the bundle directory.
    target_module:
        Top-level module name the assertions were mined for.
    model:
        LLM model id used for proposal + revision (cost_tracker
        attribution).
    max_assertions:
        Cap on attempted assertions (LLM prompt ceiling).
    max_inner_retries:
        Cap on inner-retry-with-feedback per assertion. Default 2 per
        miner role (CTO ATH-1089 spec).
    k_bound:
        EBMC Mode 1 BMC bound (default 32 per Aidan k-bound fleet rule).
    proved:
        Tuple of :class:`MinedAssumption` entries that PROVED at EBMC
        Mode 1. These join the downstream assumption set.
    refuted:
        Tuple of :class:`MinedAssumption` entries that REFUTED. Dropped
        from the assumption set; emitted on the event payload so the
        engineer can audit which assertions the LLM got wrong.
    inconclusive:
        Tuple of :class:`MinedAssumption` entries that exhausted the
        inner-retry budget without a verdict. Dropped from the
        assumption set; engineer-facing flag.
    parse_errors:
        Tuple of :class:`MinedAssumption` entries that the LLM produced
        but EBMC's parser rejected as invalid SV.
    elapsed_sec_total:
        Wall-clock sum of per-assertion mining time.
    timestamp:
        UTC ISO-8601 of mining run start.
    """

    bundle_path: str
    target_module: str
    model: str
    max_assertions: int
    max_inner_retries: int
    k_bound: int
    proved: tuple[MinedAssumption, ...]
    refuted: tuple[MinedAssumption, ...]
    inconclusive: tuple[MinedAssumption, ...]
    parse_errors: tuple[MinedAssumption, ...]
    elapsed_sec_total: float
    timestamp: str

    def to_dict(self) -> dict[str, object]:
        """JSON-serializable dict for emit + cert-tarball + MCP return."""
        d = asdict(self)
        return d


_FENCED_JSON_RE = re.compile(r"```(?:json)?\n(.*?)\n```", re.DOTALL)
_SVA_ID_RE = re.compile(r"^[a-z][a-z0-9_]*$")


def _parse_assertions_from_llm(text: str) -> list[tuple[str, str]]:
    """Parse the LLM response — expect a fenced JSON block with
    ``assertions: [{"id": ..., "sva": ...}, ...]``.

    Returns list of (assertion_id, sva_text) tuples. Empty list when
    the response is unparseable (assertion-ID isn't kebab-case stable
    or sva is missing).
    """
    m = _FENCED_JSON_RE.search(text)
    if not m:
        return []
    try:
        obj = json.loads(m.group(1).strip())
    except json.JSONDecodeError:
        return []
    out: list[tuple[str, str]] = []
    raw_list = obj.get("assertions", [])
    if not isinstance(raw_list, list):
        return []
    for entry in raw_list:
        if not isinstance(entry, dict):
            continue
        aid = str(entry.get("id", "")).strip()
        sva = str(entry.get("sva", "")).strip()
        if not aid or not sva:
            continue
        if not _SVA_ID_RE.match(aid):
            continue
        out.append((aid, sva))
    return out


_SYSTEM_PROMPT = """You propose structural SystemVerilog assertions describing
operating-mode invariants for the given RTL module. These assertions encode
properties that hold during normal use (not under adversarial inputs), and
will be used downstream as `assume property` constraints in equivalence
checking.

You may assume any assertions ALREADY PRESENT in the design hold (the
customer's authored `assert property` statements + signature.json declared
properties are treated as TRUE without re-proving them). Propose ONLY NEW
invariants you believe hold but the customer has not yet stated. This is
NOT a bug-finding mode — refuted proposals mean YOU got the invariant
wrong, not that the customer's code has a bug. (Per the customer's
clarification, slack ts 1778163960 in #project-customer.)

Format response as a JSON object inside a fenced code block:

```json
{
  "assertions": [
    {
      "id": "stable_kebab_case_id",
      "sva": "<expr>"
    }
  ]
}
```

Rules:
- Each `id` must match ^[a-z][a-z0-9_]*$ (stable kebab-case identifier).
- Each `sva` must be a BARE EXPRESSION (not wrapped in assert property).
  Example: `fifo_count <= FIFO_DEPTH` NOT `assert property (@(posedge clk) ...)`.
  The tool wraps the expression in the correct assertion form automatically.
- Assertions should describe HOW THE DESIGN BEHAVES UNDER NORMAL USE,
  not architectural goals (e.g. "fifo_full_x is high only when the FIFO
  is full" not "throughput is at least N MHz").
- Propose only NEW invariants — do not restate existing assertions.
- Avoid redundant assertions (one per invariant class).
- PRIORITIZE assertions that ENABLE OPTIMIZATION:
  * Range bounds (e.g. "count <= DEPTH") — enables width narrowing
  * Mutual exclusion (e.g. "at most one of {a,b,c} is high") —
    enables parallel-OR replacement
  * Dead-state invariants (e.g. "state != 3'b111") — enables
    dead-branch elimination
  * Signal-value bounds (e.g. "shift_amt < 32") — enables
    barrel-shifter narrowing
  These are the assertions that unlock area reduction downstream.
- Output exactly the JSON shape above; no extra prose.

If you cannot propose any assertion (e.g. the design is too small),
return `{"assertions": []}`.
"""


def _build_user_prompt(
    *,
    rtl_text: str,
    target_module: str,
    clock_port: str,
    reset_port: str,
    reset_active_low: bool,
    max_assertions: int,
    prior_attempts: list[MinedAssumption] | None = None,
) -> str:
    """Build the user-message body. On retry, includes prior REFUTED /
    PARSE_ERROR attempts as anti-priors so the LLM doesn't repeat them.
    """
    reset_phrase = (
        f"disable iff (!{reset_port})"
        if reset_active_low
        else f"disable iff ({reset_port})"
    )
    prior_lines: list[str] = []
    if prior_attempts:
        prior_lines.append(
            "\nPRIOR ATTEMPTS THAT FAILED (do not propose these again):"
        )
        for a in prior_attempts:
            if a.status in ("REFUTED", "PARSE_ERROR"):
                prior_lines.append(
                    f"- id={a.assertion_id}: {a.status} "
                    f"({a.counterexample_summary or 'no detail'})"
                )
    return (
        f"Target module: {target_module}\n"
        f"Clock port: {clock_port}\n"
        f"Reset port: {reset_port} (active-{'low' if reset_active_low else 'high'})\n"
        f"Use {reset_phrase} on every assertion.\n"
        f"Propose UP TO {max_assertions} assertions covering operating-mode\n"
        f"invariants. Quality over quantity.\n"
        f"{chr(10).join(prior_lines)}\n\n"
        f"--- RTL source ---\n"
        f"{rtl_text[:8000]}\n"
        f"--- end RTL ---"
    )


def mine_assumptions(
    bundle_path: Path | str,
    target_module: str,
    *,
    model: str = DEFAULT_SEC_REASONING_MODEL,
    max_assertions: int = 8,
    max_inner_retries: int = 2,
    k_bound: int = 32,
    timeout_sec: int = 60,
) -> AssumptionMiningResult:
    """Mine assumptions for a bundle's gold module.

    Pipeline:

    1. Read bundle's signature.json + gold RTL.
    2. Build LLM prompt + call once for up to ``max_assertions``
       proposals.
    3. For each proposed assertion:

       a. Inject as standalone ``assert property`` into a copy of the
          gold module.
       b. Run :func:`kairos.ebmc.verify` in BMC mode (Mode 1, no miter)
          with bound = ``k_bound``.
       c. PROVED → keep; REFUTED → drop; INCONCLUSIVE → inner-retry
          (LLM refines based on counterexample) up to
          ``max_inner_retries``.

    4. Return :class:`AssumptionMiningResult` partitioning the assertions
       into proved / refuted / inconclusive / parse_errors.

    Per the no-LLM-hallucination defense: every mined assertion passes
    through EBMC's verifier before joining the proved set. PROVED is
    a structural witness, not LLM judgment.

    Phase A: SDK-side library only. cto-1087-B handles MCP binding +
    JSON schemas + emit hook for ``assumption_mining_complete`` event.
    """
    started_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    started = time.monotonic()

    bundle = Path(bundle_path).resolve()
    sig_path = bundle / "signature.json"
    if not sig_path.is_file():
        raise FileNotFoundError(f"signature.json missing in bundle: {bundle}")
    sig = json.loads(sig_path.read_text())
    gold_sv = sig.get("gold_sv")
    if not gold_sv:
        raise ValueError(
            f"signature.json missing gold_sv field for bundle {bundle}"
        )
    gold_path = bundle / gold_sv
    if not gold_path.is_file():
        raise FileNotFoundError(f"gold RTL not found: {gold_path}")

    clock_port = sig.get("clock_port", "clk")
    reset_port = sig.get("reset_port", "rst_n")
    reset_active_low = sig.get("reset_active_low", True)

    rtl_text = gold_path.read_text()

    # Step 1: inject existing assertions from
    # formal_invariants_primer as EBMC constraints BEFORE mining.
    # These are the customer's hand-written invariants that define
    # the block's operating assumptions. New mined assertions are
    # discovered UNDER these constraints.
    primer_entries = sig.get("formal_invariants_primer") or []
    if primer_entries:
        from kairos.sec.closed_loop._primer_inject import (
            render_primer_to_procedural_assume_block,
        )
        primer_blocks = []
        for entry in primer_entries:
            block = render_primer_to_procedural_assume_block(
                name=str(entry.get("name", "primer")),
                kind=str(entry.get("kind", "")),
                expr=str(entry.get("expr", "")),
                reset_port=reset_port,
                reset_active_low=reset_active_low,
            )
            if block:
                primer_blocks.append(block)
        if primer_blocks:
            # Inject before endmodule
            endmod_idx = rtl_text.rfind("endmodule")
            if endmod_idx >= 0:
                inject = (
                    "\n  // [mine_assumptions] existing assertions from"
                    " formal_invariants_primer (Step 1)\n"
                    + "".join(primer_blocks)
                )
                rtl_text = rtl_text[:endmod_idx] + inject + rtl_text[endmod_idx:]

    user_prompt = _build_user_prompt(
        rtl_text=rtl_text,
        target_module=target_module,
        clock_port=clock_port,
        reset_port=reset_port,
        reset_active_low=reset_active_low,
        max_assertions=max_assertions,
        prior_attempts=None,
    )

    # Try claude subagent first (zero API cost), fall back to litellm
    llm_response_text = ""
    try:
        import subprocess as _sp
        from kairos.sec.closed_loop.claude_proposer import _safe_env  # type: ignore[attr-defined]
        full_prompt = f"{_SYSTEM_PROMPT}\n\n{user_prompt}"
        sp_result = _sp.run(
            ["claude", "-p", full_prompt, "--output-format", "text", "--max-turns", "1"],
            capture_output=True, text=True, timeout=timeout_sec,
            env=_safe_env(),
        )
        llm_response_text = sp_result.stdout or ""
    except (FileNotFoundError, _sp.TimeoutExpired):
        pass

    if not llm_response_text:
        try:
            from kairos.model_client import get_client
            client = get_client(model)
            messages = client.format_messages(_SYSTEM_PROMPT, user_prompt)
            response = client.call(messages=messages, timeout=timeout_sec)
            if not getattr(response, "error", None):
                llm_response_text = getattr(response, "content", "")
        except Exception:  # noqa: BLE001
            pass

    if not llm_response_text:
        return AssumptionMiningResult(
            bundle_path=str(bundle),
            target_module=target_module,
            model=model,
            max_assertions=max_assertions,
            max_inner_retries=max_inner_retries,
            k_bound=k_bound,
            proved=(),
            refuted=(),
            inconclusive=(),
            parse_errors=(),
            elapsed_sec_total=time.monotonic() - started,
            timestamp=started_at,
        )
    proposals = _parse_assertions_from_llm(llm_response_text)

    proved: list[MinedAssumption] = []
    refuted: list[MinedAssumption] = []
    inconclusive: list[MinedAssumption] = []
    parse_errors: list[MinedAssumption] = []

    for assertion_id, sva_text in proposals[:max_assertions]:
        outcome = _verify_one_assertion(
            gold_path=gold_path,
            target_module=target_module,
            assertion_id=assertion_id,
            sva_text=sva_text,
            k_bound=k_bound,
            timeout_sec=timeout_sec,
            max_inner_retries=max_inner_retries,
            client=client,
            user_prompt_base=user_prompt,
            reset_port=reset_port,
        )
        if outcome.status == "PROVED":
            proved.append(outcome)
        elif outcome.status == "REFUTED":
            refuted.append(outcome)
        elif outcome.status == "INCONCLUSIVE":
            inconclusive.append(outcome)
        else:
            parse_errors.append(outcome)

    result = AssumptionMiningResult(
        bundle_path=str(bundle),
        target_module=target_module,
        model=model,
        max_assertions=max_assertions,
        max_inner_retries=max_inner_retries,
        k_bound=k_bound,
        proved=tuple(proved),
        refuted=tuple(refuted),
        inconclusive=tuple(inconclusive),
        parse_errors=tuple(parse_errors),
        elapsed_sec_total=time.monotonic() - started,
        timestamp=started_at,
    )
    _maybe_emit_assumption_mining_event(result)
    return result


def verify_assumptions_on_gate(
    proved_assumptions: tuple[MinedAssumption, ...],
    gate_path: Path | str,
    gate_module: str,
    *,
    k_bound: int = 32,
    timeout_sec: int = 60,
) -> tuple[list[MinedAssumption], list[MinedAssumption]]:
    """Dual-verify: check gold-proved assumptions against the proposed gate.

    Returns (gate_valid, gate_breaks) where:
    - gate_valid: assumptions that PROVE on both gold AND gate (safe to assume)
    - gate_breaks: assumptions that PROVED on gold but FAIL on gate
      (the optimization changed behavior the assumption relied on)

    Per CTO directive: assumptions must prove on BOTH sides
    before promotion to assume-property. Gold-only verification
    creates a vacuous-truth hole.
    """
    gate_valid: list[MinedAssumption] = []
    gate_breaks: list[MinedAssumption] = []

    for assumption in proved_assumptions:
        outcome = _verify_one_assertion(
            gold_path=Path(gate_path),
            target_module=gate_module,
            assertion_id=assumption.assertion_id,
            sva_text=assumption.sva_text,
            k_bound=k_bound,
            timeout_sec=timeout_sec,
            max_inner_retries=0,
            client=None,
            user_prompt_base="",
            reset_port="",
        )
        if outcome.status == "PROVED":
            gate_valid.append(assumption)
        else:
            gate_breaks.append(MinedAssumption(
                assertion_id=assumption.assertion_id,
                sva_text=assumption.sva_text,
                status="GATE_BREAKS",
                ebmc_log_path=None,
                counterexample_summary=outcome.counterexample_summary,
                inner_retry_history=(),
                elapsed_sec=outcome.elapsed_sec,
            ))

    return gate_valid, gate_breaks


def _maybe_emit_assumption_mining_event(result: AssumptionMiningResult) -> None:
    """Emit ``assumption_mining_complete`` event when fired inside an
    existing :func:`kairos.observe.observe` context.

    Mirrors :func:`kairos.sec.smoke._maybe_emit_smoke_event` exactly:
    silent-if-no-session under standalone callers; payload is
    :meth:`AssumptionMiningResult.to_dict` verbatim. Powers the
    platform-side AssumptionsMinedSection per ATH-1079 delta 2.
    Emit hook MUST NEVER break mining — exceptions swallowed; the
    structured result is the caller's contract.
    """
    try:
        from kairos.observe import emit
    except ImportError:
        return
    try:
        emit(
            "assumption_mining_complete",
            payload=result.to_dict(),
            silent_if_no_session=True,
        )
    except Exception:  # noqa: BLE001
        pass


def _verify_one_assertion(
    *,
    gold_path: Path,
    target_module: str,
    assertion_id: str,
    sva_text: str,
    k_bound: int,
    timeout_sec: int,
    max_inner_retries: int,
    client: Any,
    user_prompt_base: str,
    reset_port: str = "reset_n",
) -> MinedAssumption:
    """Run EBMC Mode 1 on the gold + assertion injection.

    Inner-retry loop: on INCONCLUSIVE, ask the LLM to refine the
    assertion using the counterexample / log; up to ``max_inner_retries``.
    On REFUTED, no retry (assertion is genuinely wrong about the design).
    """
    import tempfile
    from kairos.ebmc import verify as ebmc_verify
    from kairos.ebmc import EbmcRunFailure, EbmcRunTimeoutError

    history: list[InnerRetryAttempt] = []
    started = time.monotonic()
    current_sva = sva_text

    for attempt_idx in range(max_inner_retries + 1):
        td = Path(tempfile.mkdtemp(prefix=f"mine_{assertion_id}_a{attempt_idx}_"))
        injected_path = td / f"{gold_path.stem}_with_assertion.sv"
        # Injection: append the assertion as a property statement INSIDE
        # the target module (before its endmodule). Naive string-edit
        # works for typical signature.json gold modules.
        gold_text = gold_path.read_text()
        injected = _inject_assertion_into_module(
            gold_text, target_module, assertion_id, current_sva,
            reset_port=reset_port,
        )
        injected_path.write_text(injected)

        attempt_started = time.monotonic()
        try:
            raw = ebmc_verify(
                [str(injected_path)],
                top_module=target_module,
                bound=k_bound,
                mode="bmc",
                timeout_sec=timeout_sec,
            )
        except EbmcRunFailure as e:
            elapsed = time.monotonic() - attempt_started
            history.append(InnerRetryAttempt(
                attempt_index=attempt_idx,
                attempt_status="EBMC_RUN_FAILURE",
                sva_text=current_sva,
                counterexample_summary=str(e)[:200],
                elapsed_sec=elapsed,
            ))
            # Bad SV — treat as parse-error class; halt no further retries.
            return MinedAssumption(
                assertion_id=assertion_id,
                sva_text=current_sva,
                status="PARSE_ERROR",
                ebmc_log_path=None,
                counterexample_summary=str(e)[:200],
                inner_retry_history=tuple(history),
                elapsed_sec=time.monotonic() - started,
            )
        except EbmcRunTimeoutError as e:
            elapsed = time.monotonic() - attempt_started
            history.append(InnerRetryAttempt(
                attempt_index=attempt_idx,
                attempt_status="INCONCLUSIVE",
                sva_text=current_sva,
                counterexample_summary=str(e)[:200],
                elapsed_sec=elapsed,
            ))
            continue

        elapsed = time.monotonic() - attempt_started
        verdict = _classify_ebmc_verdict(raw)
        if verdict == "PROVED":
            history.append(InnerRetryAttempt(
                attempt_index=attempt_idx,
                attempt_status="PROVED",
                sva_text=current_sva,
                ebmc_log_path=None,
                elapsed_sec=elapsed,
            ))
            return MinedAssumption(
                assertion_id=assertion_id,
                sva_text=current_sva,
                status="PROVED",
                ebmc_log_path=None,
                counterexample_summary=None,
                inner_retry_history=tuple(history),
                elapsed_sec=time.monotonic() - started,
            )
        if verdict == "REFUTED":
            cex_summary = (raw.counterexample or "")[:200] or None
            history.append(InnerRetryAttempt(
                attempt_index=attempt_idx,
                attempt_status="REFUTED",
                sva_text=current_sva,
                counterexample_summary=cex_summary,
                elapsed_sec=elapsed,
            ))
            return MinedAssumption(
                assertion_id=assertion_id,
                sva_text=current_sva,
                status="REFUTED",
                ebmc_log_path=None,
                counterexample_summary=cex_summary,
                inner_retry_history=tuple(history),
                elapsed_sec=time.monotonic() - started,
            )

        # INCONCLUSIVE: inner-retry — ask LLM to refine using the log.
        history.append(InnerRetryAttempt(
            attempt_index=attempt_idx,
            attempt_status="INCONCLUSIVE",
            sva_text=current_sva,
            elapsed_sec=elapsed,
        ))
        if attempt_idx < max_inner_retries:
            # Cheap refinement: prepend a stronger reset guard or weaken
            # the property. For Phase A we just retry the same SVA; the
            # counterexample-driven refinement ships in ATH-1090 Phase 2
            # (counterexample-driven abstraction refinement).
            history.append(InnerRetryAttempt(
                attempt_index=attempt_idx,
                attempt_status="REVISED_AFTER",
                sva_text=current_sva,
                elapsed_sec=0.0,
            ))

    # Exhausted retries; fall through.
    return MinedAssumption(
        assertion_id=assertion_id,
        sva_text=current_sva,
        status="INCONCLUSIVE",
        ebmc_log_path=None,
        counterexample_summary=None,
        inner_retry_history=tuple(history),
        elapsed_sec=time.monotonic() - started,
    )


def _inject_assertion_into_module(
    rtl_text: str,
    target_module: str,
    assertion_label: str,
    sva_text: str,
    reset_port: str = "reset_n",
) -> str:
    """Insert an assertion before the target module's endmodule.

    Emits procedural form (``always @(*) if (reset) assert(expr)``)
    which parses cleanly through both yosys and EBMC, unlike the SVA
    clocked-property form that yosys 0.44 rejects. Returns
    the input unchanged (caller decides what to do).
    """
    # Match the END of the target module — find `module {target}` then
    # the next `endmodule` after it.
    mod_re = re.compile(
        rf"(\bmodule\s+{re.escape(target_module)}\b.*?)(\bendmodule\b)",
        re.DOTALL,
    )
    m = mod_re.search(rtl_text)
    if not m:
        return rtl_text
    # Strip any wrapping the LLM might have added despite the prompt.
    sva_clean = sva_text.strip().rstrip(";").strip()
    # Remove "assert property (...)" wrapper if present.
    import re as _re
    _wrap = _re.match(
        r"assert\s+property\s*\(\s*@\s*\(\s*posedge\s+\w+\s*\)\s*"
        r"(?:disable\s+iff\s*\(\s*!?\w+\s*\)\s*)?(.+)\)",
        sva_clean, _re.DOTALL,
    )
    if _wrap:
        sva_clean = _wrap.group(1).strip()
    # Emit procedural form that both yosys and EBMC accept.
    insertion = (
        f"\n  // [mine_assumptions] injected assertion {assertion_label}\n"
        f"  always @(*) begin\n"
        f"    if ({reset_port}) {assertion_label}_check : assert ({sva_clean});\n"
        f"  end\n"
    )
    return rtl_text.replace(
        m.group(2),
        insertion + m.group(2),
        1,
    )


def _classify_ebmc_verdict(raw: Any) -> str:
    """Classify an EbmcVerifyResult into PROVED / REFUTED / INCONCLUSIVE.

    For Mode 1 mining there's typically exactly one property; we scan
    raw.property_verdicts for any single non-PROVED verdict.
    """
    if not raw.property_verdicts:
        return "INCONCLUSIVE"
    verdicts = [v.upper() for v in raw.property_verdicts.values()]
    if all(v == "PROVED" for v in verdicts):
        return "PROVED"
    if any(v == "REFUTED" for v in verdicts):
        return "REFUTED"
    return "INCONCLUSIVE"


__all__ = [
    "AssumptionStatus",
    "InnerAttemptStatus",
    "InnerRetryAttempt",
    "MinedAssumption",
    "AssumptionMiningResult",
    "mine_assumptions",
]
