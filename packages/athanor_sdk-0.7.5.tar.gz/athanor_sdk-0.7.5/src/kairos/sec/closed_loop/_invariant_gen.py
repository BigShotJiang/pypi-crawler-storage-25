"""LLM-driven inductive-invariant generation for SEC k-induction (ATH-992 D-spike).

When :func:`kairos.sec.verify_sec` reports an INCONCLUSIVE verdict
under k-induction mode, k-induction has shown that no
counter-example exists within the bound but cannot conclude the
property holds for all reachable states because some reachable
state of the miter machine produces a transition that violates the
naked equality. Most often the missing piece is a bridge invariant
on the *internal state* (e.g. ``gold.count == gate.count``) that,
once added as an ``assume property``, lets k-induction close.

This harness drives the loop:

    1. Read the INCONCLUSIVE property + the miter's gold/gate
       source + the k-induction log.
    2. Ask an LLM (Claude, by default) to propose a candidate
       inductive invariant in SystemVerilog expression syntax.
    3. Inject the candidate as an ``assume property`` into a
       copy of the miter (see :mod:`._miter_inject`).
    4. Re-run :func:`kairos.sec.verify_sec` in k-induction mode.
    5. If the property now closes, return the candidate as the
       :class:`InvariantGenResult`.
    6. If not, parse the new failure (still INCONCLUSIVE? new
       counter-example?), feed the rejection back to the LLM, and
       iterate (bounded ``max_attempts`` per
       :class:`InvariantGenResult.iterations`).

Once a candidate closes, the candidate ITSELF must be proven —
either by an additional EBMC pass at a higher abstraction (cheap;
the candidate is typically a state-equality between two structurally
similar designs and induction on the assume-free miter closes it)
or by a Lean refinement contract under
``Pythia/Hardware/SEC/RefinementRelation.lean`` (CTO lane,
flagged in the triage thread). The honest-framing requirement
under :issue:`ATH-992` is that the customer-facing artifact
surfaces the assumption stack — never assume an invariant without
naming it.

This module ships the harness shape only. The LLM call is wired
in a follow-up commit; today's scaffold validates the dataclass
shapes + the miter-injection path with a first-attempt
``hand_provided_invariant`` test fixture against the v2
``toy_fifo_chain_v2_sec`` bundle's ``full_match`` /
``empty_match`` INCONCLUSIVE properties.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

from kairos.model_presets import DEFAULT_SEC_REASONING_MODEL
from kairos.sec.closed_loop._miter_inject import (
    InjectionTarget,
    inject_assume_property,
)


@dataclass(frozen=True)
class InvariantCandidate:
    """A proposed inductive invariant in SV expression syntax.

    Attributes
    ----------
    sv_expression:
        The SV expression. Example: ``"gold.count == gate.count"``.
        Must be valid SV expression syntax; the harness wraps it
        in ``assume property (@(posedge clk) disable iff (!rst_n) ...)``
        before injection.
    label:
        SV-legal label EBMC will report in its log. Example:
        ``"inv_count_eq"``.
    rationale:
        The proposer's natural-language explanation of why the
        invariant should hold. Surfaced in the customer-facing
        certificate for the assumption-stack honest-framing
        requirement (:issue:`ATH-992` deliverable 3).
    proves_obligation:
        Optional pointer to where the invariant itself is proven
        (e.g. ``"Pythia/Hardware/SEC/RefinementRelation.lean::count_refinement"``).
        ``None`` during D-spike; populated when the cto-side
        Pythia primitive consumption path is wired.
    """

    sv_expression: str
    label: str
    rationale: str
    proves_obligation: str | None = None


@dataclass(frozen=True)
class InvariantGenAttempt:
    """One iteration of the propose-inject-verify loop.

    Attributes
    ----------
    candidate:
        The invariant proposed at this iteration.
    closed_target_property:
        ``True`` if the originally-INCONCLUSIVE property closed
        under k-induction with the candidate as an assume.
    new_verdict_reason:
        Human-readable verdict from the re-run. On success, the
        EBMC PROVED line text; on failure, the new INCONCLUSIVE
        / REFUTED reason.
    counter_example_text:
        ``None`` on success. On REFUTED, the trace text from
        EBMC's output. Fed to the LLM for the next attempt's
        strengthened proposal.
    """

    candidate: InvariantCandidate
    closed_target_property: bool
    new_verdict_reason: str
    counter_example_text: str | None = None


@dataclass(frozen=True)
class InvariantGenResult:
    """Final result of the bounded propose-verify loop.

    Attributes
    ----------
    closed:
        ``True`` if any attempt closed the target property.
    target_property:
        The originally-INCONCLUSIVE property name (e.g.
        ``"full_match"``).
    chosen:
        The :class:`InvariantCandidate` from the closing attempt.
        ``None`` if all attempts failed.
    attempts:
        All attempts in order. Length is bounded by ``max_attempts``
        in the call (default 3).
    halt_reason:
        Why the loop ended. One of ``"closed"`` (closed=True),
        ``"max_attempts"`` (exhausted), ``"hard_refute"`` (a
        REFUTED verdict on an attempt indicates the property may
        be genuinely false rather than just non-inductive — the
        loop halts and surfaces to human review per
        :issue:`ATH-992` deliverable 3).
    """

    closed: bool
    target_property: str
    chosen: InvariantCandidate | None
    attempts: Sequence[InvariantGenAttempt] = field(default_factory=list)
    halt_reason: str = ""
    run_id: str | None = None
    """``solve_runs.run_id`` for this generate_invariant() call when
    a kairos.observe session was opened. Surfaces in the SDK return
    so the caller can route to the dashboard's invariant-gen page
    at ``/analytics/invariant-gen/<run_id>``. ``None`` when
    ``KAIROS_NO_TRACE=1`` or when the no-sink path runs (no
    Supabase / JSONL emit). Per ATH-1017."""

    def assumption_stack(self) -> list[str]:
        """Return the human-readable assumption stack for the customer artifact.

        Honest-framing requirement (:issue:`ATH-992` deliverable 3):
        every closing-attempt invariant goes in the assumption stack
        of the customer-facing certificate. The customer must see
        what's assumed-but-not-proven (or assumed-and-proven-where).
        """
        if not self.closed or self.chosen is None:
            return []
        line = f"{self.chosen.label}: {self.chosen.sv_expression}"
        if self.chosen.proves_obligation is None:
            line += "  [UNPROVEN — assumed; v0 D-spike]"
        else:
            line += f"  [proved by {self.chosen.proves_obligation}]"
        return [line]


# ───────────────────────────────────────────────────────────────────
# LLM-call wiring (W2 substantive)
# ───────────────────────────────────────────────────────────────────


_SYSTEM_PROMPT = """\
You are an expert in formal hardware verification, specifically Sequential
Equivalence Checking (SEC) via EBMC k-induction. Your task: when k-induction
reports INCONCLUSIVE on an equivalence property between two structurally similar
hardware designs (a "gold" reference and a "gate" implementation), propose a
candidate INDUCTIVE INVARIANT that, once added as `assume property` to the
miter, lets k-induction close.

K-induction starts from arbitrary post-reset states and shows: if the property
holds for k consecutive cycles, it also holds for cycle k+1. The naked output
equality (e.g. `gold.full == gate.full`) often is NOT inductive on its own —
k-induction can pick a state where the gold and gate state registers diverge
(e.g. gold.count = 2, gate.count = 3), and from there the next-cycle equality
fails. The bridge invariant ties the internal state registers together so
k-induction starts from synchronized states.

Your output MUST be a single fenced JSON block with these keys:

```json
{
  "label": "inv_<short_snake_case>",
  "sv_expression": "<a SystemVerilog expression that, when injected as `assume property (...)`, makes k-induction close on the target property>",
  "rationale": "<one short paragraph: why this invariant should hold + why it bridges the gap>"
}
```

Constraints:
* `label` must be a valid SV identifier: `^[a-z][a-z0-9_]*$`.
* `sv_expression` is a Boolean expression over the miter's signals. Use the
  hierarchical names `gold.<signal>` and `gate.<signal>` to refer to internal
  state registers of the two instances. Multiple sub-conditions can be joined
  with `&&`.
* The invariant should be the WEAKEST sufficient bridge — overly strong
  invariants are themselves harder to discharge.
* Do NOT include the `assume property` wrapper, just the expression.
* NO TAUTOLOGY HEDGING. Do NOT include sub-clauses that trivially evaluate
  to `1'b1` (e.g. `cond ? expr : 1'b1`, `expr || 1'b1`, `: 1'b1`). Tautology
  clauses don't constrain anything but make the invariant unreadable AND
  signal proposer-uncertainty about which constraints actually matter. If
  you're unsure whether a clause is needed, OMIT it — k-induction will tell
  you on re-attempt. A clean 4-clause bridge that fails is more useful to
  the customer reading the audit trail than a 12-clause hedged bridge that
  closes by accident. Clean expressions over hedged ones.
* Output ONLY the fenced JSON. No surrounding prose.
"""


_FENCED_JSON_RE = re.compile(r"```(?:json)?\s*\n(.*?)\n```", re.DOTALL)


def _parse_llm_response(text: str) -> InvariantCandidate | None:
    m = _FENCED_JSON_RE.search(text)
    if not m:
        return None
    try:
        obj = json.loads(m.group(1).strip())
    except json.JSONDecodeError:
        return None
    label = obj.get("label", "").strip()
    sv = obj.get("sv_expression", "").strip()
    rationale = obj.get("rationale", "").strip()
    if not label or not sv or not re.match(r"^[a-z][a-z0-9_]*$", label):
        return None
    return InvariantCandidate(
        sv_expression=sv,
        label=label,
        rationale=rationale,
    )


# ───────────────────────────────────────────────────────────────────
# Canonical bridge-invariant theorem registry
# ───────────────────────────────────────────────────────────────────

# Maps a SEC miter target_property name to the kernel-checked Lean
# theorem (in the cto-side Pythia source) that proves an invariant
# EQUIVALENT to the canonical bridge invariant for that property.
#
# **Empty as of 2026-05-05** following CTO's HARD-STOP review on
# the v2.5 cert. The pythia#88 commit f335b88 theorems
# (`bridge_inv_full`, `bridge_inv_empty`) prove single-side
# impl-flag <-> count-predicate consistency on `FifoWidgetState`,
# NOT a gold-vs-gate Mealy state correspondence. Stamping
# proves_obligation against those theorems would fabricate a
# claim those theorems don't prove — v1-incident-class
# violation + 6th-instance meta-rule failure (gate-name-match-
# without-statement-audit per platform memory
# `feedback_customer_claim_engine_cross_check.md` 2026-05-05).
#
# Path-1 v2.5 ships with this registry empty. The customer cert
# correctly says: EBMC k-induction PROVED with assume-property
# bridge invariant + the bridge invariant is UNPROVEN as a Lean
# theorem (in v2.5; v2.6 builds the gold-vs-gate Mealy theorems).
# `assumption_stack()` returns to rendering `[UNPROVEN — assumed;
# v0 D-spike]` for the LLM-proposed bridges, which is the truth.
#
# v2.6 will populate this map ONLY with theorem names whose
# statements have been STRUCTURALLY AUDITED to prove a claim
# equivalent-to-or-stronger-than the LLM's bridge invariant,
# AND whose body has been audited to NOT reduce to True/Eq.refl/
# trivial. See Gate 4c hardening on the build-tarball script side
# for the structural enforcement.
_CANONICAL_BRIDGE_THEOREMS: dict[str, str] = {}


def _stamp_proves_obligation(
    candidate: InvariantCandidate,
    target_property: str,
) -> InvariantCandidate:
    """Populate proves_obligation when target_property has a known
    kernel-checked Lean theorem in the registry.

    Returns the candidate unmodified if no theorem is registered
    for the target_property — proves_obligation stays None +
    assumption_stack() renders [UNPROVEN]. Customer-facing cert
    surfaces the unproven state honestly.

    When a theorem IS registered + the EBMC verdict was PROVED on
    this candidate, the registry entry is stamped onto the
    returned candidate. The assumption_stack() renderer flips
    from [UNPROVEN] to [proved by <theorem-name>].

    Per-`feedback_no_vacuous_proves_multi_layer.md` discipline:
    this stamping is one of multiple structural defense layers.
    The other layers are:
    1. cto-side axiom-audit-clean discipline (Pythia source's
       AxiomAudit.lean).
    2. pre-flight gate Gate 4c on the customer-tarball build
       script (greps for [proved by X] in cert prose, verifies X
       exists in the axiom-audit-clean Lean source).
    3. type-system on IterationRecord.is_auto_acceptable refuses
       null proves_obligation auto-promotion.
    4. dashboard-side provesObligationLabel refuses to render-
       as-proved on null.
    All four layers run; any one failing fails the customer-
    facing claim loud.
    """
    theorem = _CANONICAL_BRIDGE_THEOREMS.get(target_property)
    if theorem is None:
        return candidate
    return InvariantCandidate(
        sv_expression=candidate.sv_expression,
        label=candidate.label,
        rationale=candidate.rationale,
        proves_obligation=theorem,
    )


def _build_user_prompt(
    *,
    gold_sv: str,
    gate_v: str,
    target_property: str,
    target_property_sv: str,
    prior_attempts: Sequence[InvariantGenAttempt],
) -> str:
    parts: list[str] = []
    parts.append(
        f"Target INCONCLUSIVE property: `{target_property}`\n"
        f"Property assertion text: {target_property_sv}\n"
    )
    parts.append("Gold-side SV source:\n```systemverilog\n" + gold_sv + "\n```")
    parts.append("Gate-side Verilog source:\n```verilog\n" + gate_v + "\n```")
    if prior_attempts:
        parts.append("Prior attempts (rejected):")
        for i, att in enumerate(prior_attempts, 1):
            cex = att.counter_example_text or "no counter-example trace"
            parts.append(
                f"  Attempt {i}: `{att.candidate.sv_expression}`\n"
                f"    Outcome: {att.new_verdict_reason}\n"
                f"    Trace: {cex[:400]}"
            )
        parts.append(
            "Strengthen or replace the invariant. The previous attempt(s) "
            "did not close k-induction; either it was too weak, structurally "
            "wrong, or referred to non-existent signals."
        )
    parts.append(
        "Propose the next candidate inductive invariant in the JSON schema "
        "specified by the system prompt. Output ONLY the fenced JSON block."
    )
    return "\n\n".join(parts)


def _verify_with_assume(
    *,
    bundle_path: Path,
    candidate: InvariantCandidate,
    target_property: str,
    target: InjectionTarget,
    timeout_sec: int,
    bound: int,
) -> tuple[str, str | None]:
    """Inject candidate, re-run EBMC k-induction, return (verdict_for_target, counterexample).

    Verdict values mirror EBMC's per-property output: ``"PROVED"``,
    ``"REFUTED"``, ``"INCONCLUSIVE"``, or an error string.
    """
    from kairos.ebmc import verify as ebmc_verify

    sec_work = bundle_path / "_sec_work"
    miter_path = sec_work / "miter.sv"
    if not miter_path.exists():
        return ("ERROR: miter.sv not found in _sec_work/", None)

    sig_path = bundle_path / "signature.json"
    sig = json.loads(sig_path.read_text())
    gold_path = bundle_path / sig["gold_sv"]
    gate_path = bundle_path / sig["gate_v"]

    miter_text = miter_path.read_text()
    new_text = inject_assume_property(
        miter_text,
        candidate.sv_expression,
        label=candidate.label,
        target=target,
    )
    work_path = sec_work / f"miter_with_{candidate.label}.sv"
    work_path.write_text(new_text)

    # ATH-1090 robustness: ebmc_verify raises EbmcRunFailure when the
    # subprocess exits non-zero AND no properties parsed (e.g. the
    # LLM-proposed invariant produced ill-formed SystemVerilog after
    # injection, or EBMC's parser drifted on an edge case). Catch and
    # convert to a string verdict so the outer loop can continue with
    # the next candidate instead of aborting the whole CEGAR cycle.
    # Also catch EbmcRunTimeoutError on the same logic — one slow
    # candidate shouldn't kill the whole loop.
    from kairos.ebmc import EbmcRunFailure, EbmcRunTimeoutError
    try:
        raw = ebmc_verify(
            [str(work_path), str(gold_path), str(gate_path)],
            top_module="sec_miter",
            bound=bound,
            mode="k_induction",
            reset_expr=target.reset_disable_expr,
            timeout_sec=timeout_sec,
        )
    except EbmcRunFailure as e:
        return (
            f"ERROR: ebmc_run_failure: {str(e)[:300]}",
            None,
        )
    except EbmcRunTimeoutError as e:
        return (
            f"ERROR: ebmc_run_timeout: {str(e)[:300]}",
            None,
        )
    target_verdict = raw.property_verdicts.get(target_property, "MISSING")
    return (target_verdict, raw.counterexample)


def generate_invariant(
    bundle_path: Path,
    target_property: str,
    *,
    model: str = DEFAULT_SEC_REASONING_MODEL,
    max_attempts: int = 3,
    timeout_sec: int = 60,
    bound: int = 12,
) -> InvariantGenResult:
    """Drive the bounded propose-inject-verify loop on a v2 SEC bundle.

    Reads the bundle's existing ``_sec_work/miter.sv`` + ``gold.sv`` +
    ``gate.v`` + ``signature.json``, asks the LLM for a candidate
    inductive invariant for the target property, injects it as an
    ``assume property``, re-runs EBMC k-induction, and iterates with
    counter-example feedback until the target property closes or
    ``max_attempts`` is exhausted.

    Parameters
    ----------
    bundle_path:
        Path to the SEC bundle directory (e.g.
        ``examples/customer/toy_fifo_chain_v2_sec/``).
    target_property:
        The INCONCLUSIVE property name as it appears in EBMC's
        per-property log (e.g. ``"sec_miter.full_match"``).
    model:
        Model id for the LLM proposer. Default is Claude Opus 4-7;
        spike uses real LLM calls per Aidan 2026-05-04 greenlight.
    max_attempts:
        Bound on the propose-inject-verify loop. Default 3 per
        :issue:`ATH-992` deliverable 5.
    timeout_sec:
        Per-EBMC-invocation timeout.
    bound:
        K-induction bound. Default 12 (matches v2 toy_fifo_chain
        baseline).

    Returns
    -------
    :class:`InvariantGenResult`
        ``closed=True`` if any attempt closed the target property
        under k-induction; otherwise ``closed=False`` with
        ``halt_reason`` naming why.
    """
    from kairos.model_client import get_client
    from kairos.observe import emit, observe
    from kairos.trace import default_sink_from_env

    bundle = Path(bundle_path)
    sig = json.loads((bundle / "signature.json").read_text())
    gold_sv = (bundle / sig["gold_sv"]).read_text()
    gate_v = (bundle / sig["gate_v"]).read_text()

    target = InjectionTarget(
        miter_module_name="sec_miter",
        clock_signal=sig.get("clock_port", "clk"),
        reset_disable_expr=(
            f"!{sig['reset_port']}"
            if sig.get("reset_active_low", True)
            else sig["reset_port"]
        ),
    )

    miter_text = (bundle / "_sec_work" / "miter.sv").read_text()
    target_property_sv = ""
    for line in miter_text.splitlines():
        bare = target_property.split(".")[-1]
        if line.lstrip().startswith(f"{bare}:"):
            target_property_sv = line.strip()
            break

    client = get_client(model)
    attempts: list[InvariantGenAttempt] = []

    # ATH-1017: open a kairos.observe session per call so D-spike
    # emits sdk_agent_events for the dashboard + the cross-arm E2E
    # test (ATH-1023). The default_sink_from_env() waterfall picks
    # SupabaseTraceSink when SUPABASE_URL+KEY are set + falls back
    # to NoopTraceSink otherwise; KAIROS_NO_TRACE=1 forces noop.
    sink = default_sink_from_env()
    with observe(
        sink=sink,
        run_type="sdk_orchestration",
        run_subtype="autoformalize",
        vertical="neuron_sec_closed_loop",
    ) as ctx:
        run_id = ctx.run_id
        emit(
            "invariant_gen_start",
            {
                "bundle_path": str(bundle),
                "target_property": target_property,
                "target_property_sv": target_property_sv,
                "max_attempts": max_attempts,
                "model": model,
                "bound_k": bound,
            },
        )
        result = _run_invariant_gen_loop(
            target_property=target_property,
            target_property_sv=target_property_sv,
            gold_sv=gold_sv,
            gate_v=gate_v,
            target=target,
            client=client,
            bundle=bundle,
            timeout_sec=timeout_sec,
            bound=bound,
            max_attempts=max_attempts,
            attempts=attempts,
        )
        # Stamp run_id on the result so the SDK return surfaces it
        # for the caller's dashboard routing.
        result_with_run_id = InvariantGenResult(
            closed=result.closed,
            target_property=result.target_property,
            chosen=result.chosen,
            attempts=result.attempts,
            halt_reason=result.halt_reason,
            run_id=run_id,
        )
        emit(
            "invariant_gen_result",
            {
                "closed": result.closed,
                "target_property": result.target_property,
                "halt_reason": result.halt_reason,
                "attempts_count": len(result.attempts),
                "chosen": _candidate_to_dict(result.chosen)
                if result.chosen is not None
                else None,
                "assumption_stack": list(result.assumption_stack()),
            },
        )
        return result_with_run_id


def _candidate_to_dict(c: InvariantCandidate) -> dict[str, str | None]:
    return {
        "sv_expression": c.sv_expression,
        "label": c.label,
        "rationale": c.rationale,
        "proves_obligation": c.proves_obligation,
    }


def _run_invariant_gen_loop(
    *,
    target_property: str,
    target_property_sv: str = "",
    gold_sv: str,
    gate_v: str,
    target: InjectionTarget,
    client: Any,
    bundle: Path,
    timeout_sec: int,
    bound: int,
    max_attempts: int,
    attempts: list[InvariantGenAttempt],
) -> InvariantGenResult:
    """Run the bounded propose-inject-verify loop.

    Extracted from :func:`generate_invariant` so the observe-wrapping
    code stays readable. Emits per-attempt ``invariant_gen_attempt``
    events; the calling :func:`generate_invariant` wraps with
    start/result emit + the kairos.observe session.
    """
    from kairos.observe import emit

    for i in range(max_attempts):
        user_prompt = _build_user_prompt(
            gold_sv=gold_sv,
            gate_v=gate_v,
            target_property=target_property,
            target_property_sv=target_property_sv,
            prior_attempts=attempts,
        )
        try:
            messages = client.format_messages(_SYSTEM_PROMPT, user_prompt)
            response = client.call(messages=messages, timeout=timeout_sec)
        except Exception as e:  # noqa: BLE001 — provider surfaces are broad
            return InvariantGenResult(
                closed=False,
                target_property=target_property,
                chosen=None,
                attempts=attempts,
                halt_reason=f"llm_error: {e}",
            )
        if response.error or not response.content:
            return InvariantGenResult(
                closed=False,
                target_property=target_property,
                chosen=None,
                attempts=attempts,
                halt_reason=f"llm_error: {response.error or 'empty'}",
            )

        candidate = _parse_llm_response(response.content)
        if candidate is None:
            attempts.append(
                InvariantGenAttempt(
                    candidate=InvariantCandidate(
                        sv_expression="<unparsed>",
                        label=f"inv_attempt_{i}",
                        rationale="LLM response parse failure",
                    ),
                    closed_target_property=False,
                    new_verdict_reason="parse_failure",
                    counter_example_text=response.content[:600],
                )
            )
            continue

        verdict, cex = _verify_with_assume(
            bundle_path=bundle,
            candidate=candidate,
            target_property=target_property,
            target=target,
            timeout_sec=timeout_sec,
            bound=bound,
        )
        closed = verdict == "PROVED"
        if closed:
            candidate = _stamp_proves_obligation(candidate, target_property)
        attempts.append(
            InvariantGenAttempt(
                candidate=candidate,
                closed_target_property=closed,
                new_verdict_reason=verdict,
                counter_example_text=cex if not closed else None,
            )
        )
        emit(
            "invariant_gen_attempt",
            {
                "attempt_index": i,
                "target_property": target_property,
                "candidate": _candidate_to_dict(candidate),
                "closed_target_property": closed,
                "verdict": verdict,
                "counter_example_present": cex is not None and not closed,
            },
        )
        if closed:
            return InvariantGenResult(
                closed=True,
                target_property=target_property,
                chosen=candidate,
                attempts=attempts,
                halt_reason="closed",
            )
        if verdict == "REFUTED":
            return InvariantGenResult(
                closed=False,
                target_property=target_property,
                chosen=None,
                attempts=attempts,
                halt_reason="hard_refute",
            )

    # ATH-1090 robustness: distinguish "exhausted attempts cleanly" from
    # "every attempt errored at the EBMC subprocess layer". The latter
    # is an actionable signal — likely the miter or candidate-injection
    # path is producing ill-formed SV; surface it explicitly so the
    # orchestrator + customer-facing cert can flag the failure mode.
    if attempts and all(
        a.new_verdict_reason.startswith("ERROR: ebmc_run_failure")
        or a.new_verdict_reason.startswith("ERROR: ebmc_run_timeout")
        for a in attempts
    ):
        halt_reason = "all_candidates_ebmc_run_failure"
    else:
        halt_reason = "max_attempts"
    return InvariantGenResult(
        closed=False,
        target_property=target_property,
        chosen=None,
        attempts=attempts,
        halt_reason=halt_reason,
    )
