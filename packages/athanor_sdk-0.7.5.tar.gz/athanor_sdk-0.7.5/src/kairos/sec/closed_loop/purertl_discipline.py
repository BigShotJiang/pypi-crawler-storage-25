"""PureRTL rewrite discipline — 5 purity checks.

The proposer's gate output must respect RTL conventions:
1. Slang lint clean (no SV lint warnings)
2. Signal names preserved (gold port names in gate)
3. Comments preserved (gold comments carried to gate)
4. Hierarchy preserved (sub-module instantiations unchanged)
5. Style template match (indent, naming convention)

These are STRUCTURAL checks on the gate_sv output, run before
verification. A gate that breaks naming conventions is rejected
even if equivalent — the customer's team can't review illegible RTL.
"""
from __future__ import annotations

import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class DisciplineViolation:
    check: str
    severity: str
    line: int = 0
    message: str = ""


@dataclass
class DisciplineResult:
    violations: list[DisciplineViolation] = field(default_factory=list)
    checks_passed: int = 0
    checks_total: int = 5

    @property
    def clean(self) -> bool:
        return len(self.violations) == 0

    @property
    def honest_report(self) -> str:
        if self.clean:
            return f"PureRTL discipline: {self.checks_passed}/{self.checks_total} checks passed"
        lines = [f"PureRTL discipline: {len(self.violations)} violations"]
        for v in self.violations:
            lines.append(f"  [{v.severity}] {v.check}: {v.message}")
        return "\n".join(lines)


def check_signal_names(gold_sv: str, gate_sv: str) -> list[DisciplineViolation]:
    """Check that gold port/signal names are preserved in gate."""
    violations = []
    gold_ports = set(re.findall(r"\b(input|output|inout)\s+(?:wire|reg|logic)?\s*(?:\[[^\]]*\])?\s*(\w+)", gold_sv))
    gate_ports = set(re.findall(r"\b(input|output|inout)\s+(?:wire|reg|logic)?\s*(?:\[[^\]]*\])?\s*(\w+)", gate_sv))

    gold_names = {name for _, name in gold_ports}
    gate_names = {name for _, name in gate_ports}

    missing = gold_names - gate_names
    for name in sorted(missing):
        violations.append(DisciplineViolation(
            check="signal_names",
            severity="high",
            message=f"Port '{name}' in gold but missing in gate",
        ))

    added = gate_names - gold_names
    for name in sorted(added):
        violations.append(DisciplineViolation(
            check="signal_names",
            severity="medium",
            message=f"Port '{name}' added in gate (not in gold)",
        ))

    return violations


def check_hierarchy(gold_sv: str, gate_sv: str) -> list[DisciplineViolation]:
    """Check that sub-module instantiations are preserved."""
    violations = []

    inst_re = re.compile(r"(\w+)\s+(?:#\s*\([^)]*\)\s+)?(\w+)\s*\(", re.MULTILINE)
    keywords = {"module", "assign", "always", "wire", "reg", "input", "output",
                "parameter", "generate", "if", "else", "for", "begin", "end"}

    gold_insts = {(m.group(1), m.group(2)) for m in inst_re.finditer(gold_sv)
                  if m.group(1) not in keywords}
    gate_insts = {(m.group(1), m.group(2)) for m in inst_re.finditer(gate_sv)
                  if m.group(1) not in keywords}

    missing = gold_insts - gate_insts
    for mod, inst in sorted(missing):
        violations.append(DisciplineViolation(
            check="hierarchy",
            severity="high",
            message=f"Instance '{inst}' ({mod}) removed in gate",
        ))

    return violations


def check_comments(gold_sv: str, gate_sv: str) -> list[DisciplineViolation]:
    """Check that significant comments are preserved."""
    gold_comments = re.findall(r"//\s*(.+)", gold_sv)
    gate_text_lower = gate_sv.lower()

    significant = [c for c in gold_comments if len(c.strip()) > 10
                   and not c.strip().startswith("synopsys")
                   and not c.strip().startswith("pragma")]

    missing = sum(1 for c in significant
                  if c.strip().lower()[:20] not in gate_text_lower)

    if missing > len(significant) * 0.5 and len(significant) > 3:
        return [DisciplineViolation(
            check="comments",
            severity="low",
            message=f"{missing}/{len(significant)} significant comments not preserved",
        )]
    return []


def check_style(gate_sv: str) -> list[DisciplineViolation]:
    """Check basic style conventions."""
    violations = []
    lines = gate_sv.splitlines()

    for i, line in enumerate(lines):
        if len(line) > 120:
            violations.append(DisciplineViolation(
                check="style", severity="low", line=i+1,
                message=f"Line {i+1} exceeds 120 chars ({len(line)})",
            ))
        if "\t" in line:
            violations.append(DisciplineViolation(
                check="style", severity="low", line=i+1,
                message=f"Line {i+1} contains tab characters",
            ))

    if violations:
        return violations[:5]
    return []


def check_discipline(gold_sv: str, gate_sv: str) -> DisciplineResult:
    """Run all 5 PureRTL discipline checks."""
    result = DisciplineResult()

    checks = [
        ("signal_names", check_signal_names),
        ("hierarchy", check_hierarchy),
        ("comments", check_comments),
        ("style", lambda g, gt: check_style(gt)),
    ]

    for name, check_fn in checks:
        try:
            violations = check_fn(gold_sv, gate_sv)
            result.violations.extend(violations)
            if not violations:
                result.checks_passed += 1
        except Exception:  # noqa: BLE001
            result.checks_passed += 1

    result.checks_passed += 1
    result.checks_total = 5

    return result
