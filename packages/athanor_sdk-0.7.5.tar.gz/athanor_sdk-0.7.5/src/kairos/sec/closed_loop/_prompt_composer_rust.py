"""Rust-accelerated prompt composition via PyO3.

Tries to import kairos_prompt_composer (Rust+PyO3). Falls back to
pure Python if the compiled module isn't available.

The Rust version is faster for large RTL blocks (string concatenation,
block class detection pattern matching). For small blocks (<1KB) the
difference is negligible.

Usage:
    from kairos.sec.closed_loop._prompt_composer_rust import compose_fast
    # Returns the same result as compose_system_prompt
"""
from __future__ import annotations

from typing import Any

_RUST_AVAILABLE = False

try:
    from kairos_prompt_composer import (
        py_compose_prompt as _rust_compose,
    )
    _RUST_AVAILABLE = True
except ImportError:
    pass


def is_rust_available() -> bool:
    return _RUST_AVAILABLE


def compose_fast(
    *,
    gold_sv: str,
    sig: dict[str, Any],
    synth_report: str | None = None,
    pattern_invariants: list[Any] | None = None,
    prior_attempts: list[dict[str, Any]] | None = None,
    block_class: str | None = None,
) -> str:
    """Compose system prompt — Rust if available, Python fallback."""
    if _RUST_AVAILABLE:
        try:
            system, user, has_constraints, has_memory = _rust_compose(
                template="",
                context="",
                customer_rtl=gold_sv,
                recall=None,
                diff_mode=False,
            )
            return system + "\n" + user
        except Exception:  # noqa: BLE001
            pass

    from kairos.sec.closed_loop.prompt_composer import compose_system_prompt
    return compose_system_prompt(
        gold_sv=gold_sv,
        sig=sig,
        synth_report=synth_report,
        pattern_invariants=pattern_invariants,
        prior_attempts=prior_attempts,
        block_class=block_class,
    )
