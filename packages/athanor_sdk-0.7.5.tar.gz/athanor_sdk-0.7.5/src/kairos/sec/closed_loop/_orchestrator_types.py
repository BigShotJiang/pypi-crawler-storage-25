"""Orchestrator result types — extracted from God Object (ATH-1415)."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Literal, Sequence

_log = logging.getLogger("kairos.sec.closed_loop")

from kairos.sec.closed_loop._invariant_gen import InvariantGenResult
from kairos.sec.closed_loop._proposer import TransformationProposal
from kairos.sec.closed_loop._ranker import RankedTarget

# ── Enums and type aliases (must precede dataclasses that use them) ──

DisplayMode = Literal["chosen_on_top", "refuted_on_top", "equal_weight"]


class IterationState(str, Enum):
    """States the orchestrator's per-iteration cursor passes through."""

    RANKED = "ranked"
    PROPOSED = "proposed"
    BMC_BOUNDED = "bmc_bounded"
    KINDUCTION_TRIED = "kinduction_tried"
    INVARIANT_GEN_TRIED = "invariant_gen_tried"
    HALTED_PROVED = "halted_proved"
    HALTED_REFUTED = "halted_refuted"
    HALTED_HUMAN_REVIEW = "halted_human_review"


class OrchestratorHaltReason(str, Enum):
    """Why the whole orchestrator (not a single iteration) halted."""

    PROVED_EQUIVALENT_VARIANT_FOUND = "proved_equivalent_variant_found"
    NO_PROPOSAL_CLOSED = "no_proposal_closed"
    MAX_ITERATIONS = "max_iterations"
    HUMAN_REVIEW_NEEDED = "human_review_needed"


# ── Dataclasses ──

@dataclass(frozen=True)
class IterationRecord:
    """One iteration's full trace."""

    iteration_index: int
    target: RankedTarget
    proposal: TransformationProposal | None
    bmc_verdict: str
    kinduction_verdict: str
    invariant_gen_result: InvariantGenResult | None = None
    final_state: IterationState = IterationState.RANKED
    measured_area_delta_pct: float | None = None

    def is_auto_acceptable(self) -> bool:
        if self.final_state != IterationState.HALTED_PROVED:
            return False
        if self.invariant_gen_result is None:
            return True
        chosen_inv = self.invariant_gen_result.chosen
        if chosen_inv is None:
            return False
        return chosen_inv.proves_obligation is not None


@dataclass
class ClosedLoopResult:
    """Public result of run_closed_loop_orchestration."""

    parent_run_id: str
    halt_reason: str
    iteration_summaries: list[dict[str, Any]] = field(default_factory=list)
    cert_payload: dict[str, Any] = field(default_factory=dict)
    proposer_halt_reason: str | None = None
    proposer_halt_reason_class: str = ""

    def n_accepted(self) -> int:
        return sum(1 for s in self.iteration_summaries if s["outcome"] == "accepted")

    def n_refuted(self) -> int:
        return sum(1 for s in self.iteration_summaries if s["outcome"] == "refuted")

    def n_inconclusive(self) -> int:
        return sum(1 for s in self.iteration_summaries if s["outcome"] == "inconclusive")

    def n_errored(self) -> int:
        return sum(1 for s in self.iteration_summaries if s["outcome"] == "errored")

    def summary(self) -> str:
        """Customer-readable summary of the optimization result."""
        lines: list[str] = []
        if self.halt_reason == "proved_equivalent_variant_found":
            accepted = [s for s in self.iteration_summaries if s["outcome"] == "accepted"]
            best = min(accepted, key=lambda s: s.get("measured_delta_pct", 0))
            delta = best.get("measured_delta_pct", "?")
            gold = best.get("gold_cells", "?")
            gate = best.get("gate_cells", "?")
            lines.append(f"PROVED: {delta}% area reduction ({gold} -> {gate} cells)")
            lines.append(f"{len(accepted)} proposal(s) formally verified equivalent.")
        elif self.halt_reason == "no_proposal_closed":
            n = len(self.iteration_summaries)
            lines.append(f"No verified optimization found ({n} proposals tried).")
            reasons_seen: set[str] = set()
            for s in self.iteration_summaries:
                reason = s.get("outcome_reason", "")
                if "structural_gate_rejected" in reason and "structural" not in reasons_seen:
                    lines.append("  Suggestion: proposals did not reduce area after synthesis.")
                    reasons_seen.add("structural")
                elif "toggle_power_gate_rejected" in reason and "power" not in reasons_seen:
                    lines.append("  Suggestion: area improved but dynamic power increased. Try with --allow-power-increase.")
                    reasons_seen.add("power")
                elif "timing" in reason.lower() and "timing" not in reasons_seen:
                    lines.append("  Suggestion: optimization violated timing constraints. Try a less aggressive transformation.")
                    reasons_seen.add("timing")
                elif ("yosys combo equiv inconclusive" in reason or "unproven cells" in reason) and "equiv" not in reasons_seen:
                    lines.append("  Suggestion: equivalence checker could not close proof. Try --timeout <longer>.")
                    reasons_seen.add("equiv")
                elif ("ebmc_timeout" in reason or "EBMC" in reason) and "ebmc" not in reasons_seen:
                    lines.append("  Suggestion: EBMC verification timed out (design may be too large for current bound). Try --timeout <longer> or --k-bound <higher>.")
                    reasons_seen.add("ebmc")
                elif ("gate_elaborate_failed" in reason or "SETUP_ERROR" in reason) and "elab" not in reasons_seen:
                    lines.append("  Suggestion: proposed RTL did not compile. Check for missing dependencies (--deps).")
                    reasons_seen.add("elab")
                elif ("REFUTED" in s.get("outcome", "").upper() or "refuted" in reason.lower()) and "refuted" not in reasons_seen:
                    lines.append("  Proposal was functionally incorrect (NOT equivalent to gold).")
                    lines.append("  The SAT miter found an input where gold and gate produce different outputs.")
                    lines.append("  Suggestions:")
                    lines.append("    - Try --proposer-mode diff (smaller, more conservative changes)")
                    lines.append("    - Try --proposer-mode preserve_datapath (locks output assignments)")
                    lines.append("    - Increase --max-proposals for more candidates (best-of-N)")
                    reasons_seen.add("refuted")
        elif self.halt_reason == "proposer_halt":
            reason = self.proposer_halt_reason or "unknown"
            if self.proposer_halt_reason_class == "auth":
                lines.append("Authentication failed.")
                lines.append("  For direct API: check ANTHROPIC_API_KEY")
                lines.append("  For Azure: check ANTHROPIC_API_KEY + ANTHROPIC_BASE_URL")
                lines.append("  For Bedrock: check AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_REGION")
                lines.append("  Run 'kairos doctor' to diagnose.")
            elif "empty response" in reason:
                lines.append("LLM returned empty response. May be a transient issue; retry.")
            elif reason == "zero_budget":
                lines.append("Phase 2 skipped (abc_only preset -- no LLM proposals).")
            else:
                lines.append(f"Proposer failed: {reason[:200]}")
        else:
            lines.append(f"Optimization halted: {self.halt_reason}")
        return "\n".join(lines)


@dataclass
class OrchestratorRunResult:
    """Final result of one orchestrator invocation."""

    parent_run_id: str
    iterations: Sequence[IterationRecord] = field(default_factory=list)
    chosen: IterationRecord | None = None
    halt_reason: OrchestratorHaltReason = OrchestratorHaltReason.MAX_ITERATIONS
    display_mode: DisplayMode = "equal_weight"
    customer_report_path: str | None = None

    def closed_count(self) -> int:
        return sum(1 for r in self.iterations if r.final_state == IterationState.HALTED_PROVED)

    def refuted_count(self) -> int:
        return sum(1 for r in self.iterations if r.final_state == IterationState.HALTED_REFUTED)

    def human_review_count(self) -> int:
        return sum(1 for r in self.iterations if r.final_state == IterationState.HALTED_HUMAN_REVIEW)


@dataclass
class VerificationContext:
    """Shared state for the verification pipeline within one iteration."""
    sig: dict[str, Any]
    inputs_dir: Path
    work_dir: Path
    iter_bundle: Path
    gold_module: str
    gate_module: str
    gold_for_verify: Path
    gate_for_verify: Path
    deps_for_verify: list[Path]
    ports: list[dict[str, Any]]
    bound: int
    timeout_sec: int
    parent_run_id: str
    iteration_index: int
    proposer_model: str = ""
    custom_engine: str | None = None


def derive_display_mode(
    halt_reason: OrchestratorHaltReason,
    iterations: Sequence[IterationRecord],
) -> DisplayMode:
    """Derive the dashboard display mode from halt reason and iterations."""
    if halt_reason == OrchestratorHaltReason.PROVED_EQUIVALENT_VARIANT_FOUND:
        return "chosen_on_top"
    has_refuted_with_cex = any(
        getattr(r, "final_state", None) == IterationState.HALTED_REFUTED
        for r in iterations
    )
    if has_refuted_with_cex:
        return "refuted_on_top"
    return "equal_weight"


def _sanitize_error_for_customer(exc: Exception, context: str) -> str:
    """Format an exception for customer-visible outcome_reason fields."""
    from kairos.errors import KairosError
    msg = str(exc)
    if isinstance(exc, KairosError):
        return f"{context}: {msg}"
    for prefix in ("RuntimeError: ", "ValueError: ", "OSError: ", "Exception: "):
        if msg.startswith(prefix):
            msg = msg[len(prefix):]
    return f"{context}: {msg[:300]}"


def _poll_agent_messages(run_id: str) -> dict[str, list]:
    """Poll message queue at phase boundary. Returns messages by type."""
    try:
        from kairos.sec.closed_loop.message_queue import poll_messages
        msgs = poll_messages(run_id)
        result: dict[str, list] = {"hint": [], "config": [], "control": []}
        for m in msgs:
            result[m.msg_type].append(m)
            _log.info(f"  [msg] {m.msg_type} from {m.target}: {m.content[:80]}")
        return result
    except Exception:  # noqa: BLE001
        return {"hint": [], "config": [], "control": []}
