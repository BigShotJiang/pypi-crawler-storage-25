r"""kairos.sec.preprocess — yosys-elaborate-first preprocessing for EBMC.

Per ATH-1076: EBMC 5.10's SV preprocessor + parser doesn't accept
several SystemVerilog constructs that yosys parses cleanly (genvar
``++`` post-increment, ``\`include`` inside ``\`ifdef`` even when the
ifdef body should be skipped, generate-block label syntax, ``logic``
type without ``--systemverilog`` flag, etc.).

The fix is to elaborate via yosys before feeding to EBMC: yosys reads
the SV with ``-sv -formal`` flags, runs ``hierarchy -check -top``,
flattens module instantiations, and emits plain Verilog (post-proc,
post-flatten) that EBMC's stricter parser handles cleanly.

This preserves semantic equivalence — yosys elaboration is an
information-preserving transformation. Customer-trust contract: cert
tarball ships BOTH the original gold source AND the yosys-elaborated
form (verbatim engine input for EBMC). Customer can independently
re-run yosys-elaborate + ebmc verify to reproduce the verdict.

## Public API

* :func:`yosys_elaborate_to_verilog` — read SV file (+ optional
  dep files) via yosys, return path to the elaborated plain-Verilog
  output that EBMC can parse.

* :class:`YosysElaborateError` — raised on subprocess failure /
  yosys-binary-missing / parse failure.

## Pipeline shape

::

    yosys -p "
        read_verilog -sv -formal <dep_1>
        read_verilog -sv -formal <dep_N>
        read_verilog -sv -formal <rtl_path>
        hierarchy -check -top <top_module>
        proc; opt
        flatten
        opt
        write_verilog -noattr <output_path>
    "

The ``flatten`` step is critical for EBMC — without it, the elaborated
output retains hierarchical instantiations that EBMC's miter-build step
struggles with on multi-module gold-side designs.
"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path

from kairos.security.env_allowlist import safe_env_for_yosys
from kairos.security.path_sanitizer import sanitize_yosys_path


class YosysElaborateError(RuntimeError):
    """Raised when yosys elaboration to plain Verilog fails."""


@dataclass(frozen=True)
class YosysElaborateResult:
    """Result of one yosys-elaborate-to-verilog call.

    Attributes
    ----------
    elaborated_path:
        Absolute path to the yosys-emitted plain Verilog file.
    log_path:
        Absolute path to the yosys subprocess stdout/stderr capture.
        Ships in cert tarballs verbatim.
    exit_code:
        yosys subprocess exit code. 0 on success.
    runtime_sec:
        Wall-clock seconds for the yosys subprocess.
    """

    elaborated_path: str
    log_path: str
    exit_code: int
    runtime_sec: float


def preprocess_sv_for_yosys(text: str) -> str:
    """Rewrite SV constructs yosys 0.44 cannot handle.

    Currently: AP_LOG2(expr) → $clog2(expr). Yosys supports $clog2
    natively but cannot call file-scope functions in parameter defaults.
    """
    import re
    return re.sub(r'\bAP_LOG2\s*\(', '$clog2(', text)


def yosys_elaborate_to_verilog(
    rtl_path: Path | str,
    top_module: str,
    *,
    dep_files: list[Path | str] | None = None,
    output_path: Path | str | None = None,
    log_dir: Path | str | None = None,
    timeout_sec: int = 120,
    parameter_overrides: dict[str, str | int] | None = None,
    flatten: bool = True,
) -> YosysElaborateResult:
    """Elaborate a SystemVerilog design via yosys, emit plain Verilog.

    Parameters
    ----------
    rtl_path:
        Path to the SystemVerilog/Verilog file containing
        ``top_module``.
    top_module:
        Top-level module name. Passed to yosys ``hierarchy -check -top``.
    dep_files:
        Optional list of additional RTL files containing sub-module
        dependencies. Read by yosys BEFORE the top file so the
        ``hierarchy -check`` resolves all instantiations.
    output_path:
        Optional path where the elaborated Verilog is written. Default:
        ``<TMPDIR>/<rtl_stem>_elab.v``.
    log_dir:
        Where to write the yosys subprocess stdout/stderr capture.
        Default: ``<TMPDIR>``.
    timeout_sec:
        Wall-clock subprocess timeout. Default 120s.
    parameter_overrides:
        Optional mapping of parameter name to concrete value applied
        to ``top_module`` via yosys ``chparam`` BEFORE ``hierarchy
        -check``. Required when the bundle's ``signature.parameters``
        contains entries with ``must_override: true`` (e.g.
        ``FIFO_DEPTH`` defaults to 0 and degenerates without an
        override). Values may be int (treated as Verilog int) or
        str (treated as Verilog literal — caller passes the literal
        verbatim, e.g. ``"4"`` or ``"1'b0"``).

    Returns
    -------
    :class:`YosysElaborateResult` with elaborated_path + log_path.

    Raises
    ------
    :class:`YosysElaborateError`
        On any of: missing yosys binary, missing rtl_path / dep_files,
        subprocess timeout, nonzero exit, no output file produced.
    """
    from kairos.security.path_sanitizer import validate_verilog_identifier
    validate_verilog_identifier(top_module, "top_module")

    rtl = Path(rtl_path).resolve()
    if not rtl.is_file():
        raise YosysElaborateError(f"rtl_path not found: {rtl}")
    deps_resolved: list[Path] = []
    if dep_files:
        for dep in dep_files:
            dep_p = Path(dep).resolve()
            if not dep_p.is_file():
                raise YosysElaborateError(
                    f"dep_files entry not found: {dep_p}"
                )
            deps_resolved.append(dep_p)

    yosys_bin = shutil.which("yosys")
    if yosys_bin is None:
        raise YosysElaborateError(
            "yosys binary not found on $PATH. Install via apt "
            "('apt install yosys'), brew ('brew install yosys'), or "
            "from source (https://github.com/YosysHQ/yosys). The "
            "yosys-elaborate-first preprocessing required by ATH-1076 "
            "needs yosys; without it EBMC SV-compatibility blockers "
            "(genvar `++`, ifdef-include resolution, logic keyword) "
            "surface as parse failures."
        )

    if output_path is not None:
        out_path = Path(output_path).resolve()
        out_path.parent.mkdir(parents=True, exist_ok=True)
    else:
        tmp_dir = Path(tempfile.gettempdir())
        out_path = tmp_dir / f"{rtl.stem}_elab.v"

    if log_dir is not None:
        log_dir_p = Path(log_dir).resolve()
        log_dir_p.mkdir(parents=True, exist_ok=True)
    else:
        log_dir_p = Path(tempfile.gettempdir())
    log_path = log_dir_p / f"kairos_yosys_elab_{rtl.stem}.log"

    # Preprocess: rewrite SV constructs yosys cannot handle
    rtl_text = rtl.read_text()
    preprocessed = preprocess_sv_for_yosys(rtl_text)
    if preprocessed != rtl_text:
        tmp = Path(tempfile.mktemp(suffix=rtl.suffix, dir=str(rtl.parent)))
        tmp.write_text(preprocessed)
        rtl = tmp

    sanitize_yosys_path(rtl)
    include_dirs: set[str] = set()
    dep_reads_parts: list[str] = []
    for dep in deps_resolved:
        sanitize_yosys_path(dep)
        if dep.suffix in (".inc", ".vh", ".svh"):
            include_dirs.add(str(dep.parent))
        else:
            dep_reads_parts.append(f"read_verilog -sv -formal {dep}\n")
    inc_flags = " ".join(f"-I{d}" for d in sorted(include_dirs))
    dep_reads = "".join(dep_reads_parts)
    chparam_lines = ""
    if parameter_overrides:
        for name, value in parameter_overrides.items():
            # Yosys chparam syntax: chparam -set <param> <value> <module>.
            # int values are emitted bare; str values are passed verbatim
            # so the caller can pass Verilog literals like "1'b0" or
            # decimal strings like "4". Yosys lexes the value as a
            # constant expression — same rules as a parameter default.
            chparam_lines += (
                f"chparam -set {name} {value} {top_module}\n"
            )
    flatten_cmds = "flatten\nopt\n" if flatten else ""
    script = (
        f"{dep_reads}"
        f"read_verilog -sv -formal {inc_flags} {rtl}\n"
        f"{chparam_lines}"
        f"hierarchy -check -top {top_module}\n"
        f"proc; opt\n"
        f"{flatten_cmds}"
        f"write_verilog -noattr {out_path}\n"
    )

    start = time.monotonic()
    try:
        proc = subprocess.run(
            [yosys_bin, "-p", script],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
            env=safe_env_for_yosys(),
        )
    except subprocess.TimeoutExpired as exc:
        raise YosysElaborateError(
            f"yosys elaborate timed out after {timeout_sec}s on {rtl} "
            f"(top_module={top_module!r})"
        ) from exc

    runtime_sec = time.monotonic() - start
    combined = proc.stdout + "\n--- STDERR ---\n" + proc.stderr
    log_path.write_text(combined)

    if proc.returncode != 0:
        raise YosysElaborateError(
            f"yosys elaborate exited with code {proc.returncode} on "
            f"{rtl} (top_module={top_module!r}). Subprocess log captured "
            f"at {log_path}. Review the log for the specific error."
        )

    if not out_path.is_file():
        raise YosysElaborateError(
            f"yosys elaborate exited 0 but output file {out_path} was "
            f"not produced. Likely a yosys script bug or write_verilog "
            f"target-path-conflict. Check log at {log_path}."
        )

    return YosysElaborateResult(
        elaborated_path=str(out_path),
        log_path=str(log_path),
        exit_code=proc.returncode,
        runtime_sec=runtime_sec,
    )
