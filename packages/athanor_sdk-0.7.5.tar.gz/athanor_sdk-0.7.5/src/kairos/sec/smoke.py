r"""kairos.sec.smoke — pre-fire smoke validation pipeline (ATH-1077 Phase A).

Mechanical-only validation that a bundle is fire-ready BEFORE the engineer
spends LLM tokens on `kairos_optimize_block`. Three-step pipeline:

1. **yosys_elaborate** — read SV via :func:`kairos.sec.preprocess
   .yosys_elaborate_to_verilog`, emit plain Verilog. Catches SV-construct
   blockers that EBMC's parser doesn't handle (genvar `++`, `\`include`
   inside `\`ifdef`, `logic` keyword, named generate blocks).
2. **ebmc_parse_only** — `ebmc --show-modules` on the elaborated form.
   Catches any post-yosys-elab parser drift.
3. **identity_equivalence** — build a SEC miter against the gold-vs-renamed-
   gold-as-gate, run BMC at depth k over the bound ladder; identity must
   PROVED at some k in the ladder; refute or top-rung-INCONCLUSIVE
   surfaces as fail-loud per regression discipline. (BMC, not k-induction:
   see inline rationale at ``_step_identity_equivalence`` — k-induction
   struggles on flattened state-vector identity; BMC at depth k proves
   no-divergence-in-k-cycles which is sufficient for the fire-readiness
   gate and matches qa option-D PROVED-at-k=32 baseline.)

Per ATH-1077 spec (athanor-platform/docs/internal/kairos_smoke_validation_spec.md)
+ Aidan LLM-defense-thesis: every PASS/FAIL is mechanical determination
(binary exit code, exit string match, k-induction PROVED literal). No LLM
judgment anywhere. No paid surface.

## Public API

* :func:`smoke_validate` — run the 3-step pipeline; return
  :class:`SmokeValidationResult`.
* :class:`SmokeValidationResult` — frozen dataclass; per-step status +
  remediation + total elapsed.
* :class:`SmokeStepResult` — frozen dataclass; per-step status +
  fail_class + fail_detail + subprocess_log_path.

## Honest-framing rules (from spec)

- Setup-class FAILs (binary not found / dep missing) surface separately
  from bundle-class FAILs (parser error / identity refute) via
  ``fail_class``.
- No bare PASS — every PASS surface includes elapsed_sec + size /
  property-count signals so the engineer can verify smoke actually
  exercised something (not vacuous on empty input).
- ``identity_inconclusive_at_max_bound`` is NOT a PASS. k=32 inconclusive
  doesn't prove equivalence.
- No LLM judgment anywhere.

## Cross-refs

- ATH-1077 (this module's parent ticket)
- ATH-1076 yosys-elaborate-first (consumed)
- ATH-1078 customer strategy realignment (smoke is the on-ramp to
  `kairos_optimize_block`)
- athanor-platform/docs/internal/kairos_smoke_validation_spec.md
"""
from __future__ import annotations

import json as _json
import re
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from kairos.security.env_allowlist import safe_env_for_ebmc

StepName = Literal["yosys_elaborate", "ebmc_parse_only", "identity_equivalence"]
StepStatus = Literal["PASS", "FAIL", "SKIPPED"]
OverallStatus = Literal["PASS", "FAIL"]


@dataclass(frozen=True)
class SmokeStepResult:
    """One step's verdict + diagnostics.

    Per-step shape carries step-specific fields INLINE at the root
    (matching the ATH-1077 spec contract; render-side components
    consume them by name without indirection through an ``extras``
    dict). Step 1 sets ``elaborated_size_bytes`` + ``elaborated_path``;
    Step 2 sets ``module_identifier``; Step 3 sets ``bound_used`` +
    ``k_attempt_matrix`` + ``miter_top``.

    Unused fields stay ``None`` — the dataclass is shared across all
    three step types, but only one step populates each non-shared field.

    Attributes
    ----------
    step:
        ``"yosys_elaborate"`` / ``"ebmc_parse_only"`` /
        ``"identity_equivalence"``.
    status:
        ``"PASS"`` / ``"FAIL"`` / ``"SKIPPED"``. SKIPPED only fires
        under ``fail_fast=True`` after a prior step failed.
    elapsed_sec:
        Wall-clock for the step. 0.0 for SKIPPED.
    fail_class:
        Stable string identifier for the failure class (used by
        dashboard render contract for actionable messaging). ``None``
        on PASS / SKIPPED.
    fail_detail:
        Human-readable detail; first line of subprocess error output
        or a structured class summary. ``None`` on PASS / SKIPPED.
    subprocess_log_path:
        Path to verbatim subprocess stdout/stderr capture for
        customer-tarball reproduction. ``None`` for steps that don't
        spawn subprocesses (rare).
    elaborated_size_bytes:
        Step 1 only: byte count of the yosys-elaborated output.
    elaborated_path:
        Step 1 only: path to the elaborated ``.v`` file.
    module_identifier:
        Step 2 only: ``"Verilog::<top_module>"`` matched in
        ``ebmc --show-modules`` output. Confirms the elaborated form
        carries the requested top.
    bound_used:
        Step 3 only on PASS: lowest k in the bound ladder at which BMC
        proved the identity miter. ``None`` on FAIL.
    k_attempt_matrix:
        Step 3 only: per-k attempt rows (k / result / elapsed_sec /
        subprocess_log_path). Always non-empty when the step ran.
    miter_top:
        Step 3 only: name of the synthesized miter top module
        (``"sec_miter"`` for build_miter output). Render contract
        uses for cross-file navigation.
    """

    step: StepName
    status: StepStatus
    elapsed_sec: float
    fail_class: str | None = None
    fail_detail: str | None = None
    subprocess_log_path: str | None = None
    elaborated_size_bytes: int | None = None
    elaborated_path: str | None = None
    module_identifier: str | None = None
    bound_used: int | None = None
    k_attempt_matrix: tuple[dict[str, object], ...] | None = None
    miter_top: str | None = None


@dataclass(frozen=True)
class SmokeValidationResult:
    """Full smoke validation outcome.

    Attributes
    ----------
    bundle_path:
        Resolved absolute path to the bundle directory.
    top_module:
        Top-level module name validated.
    bound_default:
        Starting k for identity-equiv ladder.
    bound_ladder:
        Retry ladder of k values.
    fail_fast:
        Whether SKIPPED-on-prior-fail discipline was enabled.
    timestamp:
        UTC ISO-8601 of smoke run start.
    overall:
        ``"PASS"`` if every executed step PASS; otherwise ``"FAIL"``.
    elapsed_sec_total:
        Wall-clock sum across all executed steps.
    steps:
        Mapping of step name → :class:`SmokeStepResult`.
    remediation:
        Human-readable customer-facing actionable line on FAIL;
        ``None`` on PASS. Mirrors the 10-row remediation table from
        the spec.
    smoke_version:
        Schema version for the result envelope. ``"1.0"`` for
        ATH-1077 Phase A.
    """

    bundle_path: str
    top_module: str
    bound_default: int
    bound_ladder: tuple[int, ...]
    fail_fast: bool
    timestamp: str
    overall: OverallStatus
    elapsed_sec_total: float
    steps: dict[str, SmokeStepResult]
    remediation: str | None = None
    smoke_version: str = "1.0"

    def to_dict(self) -> dict[str, object]:
        """JSON-serializable dict for emit + cert-tarball + MCP return.

        Per-step shape inlines step-specific fields at the step root
        (matches ATH-1077 spec contract). Fields that are ``None`` are
        omitted to keep the rendered JSON clean for dashboard
        consumption.
        """
        def _step_dict(s: SmokeStepResult) -> dict[str, object]:
            base: dict[str, object] = {
                "step": s.step,
                "status": s.status,
                "elapsed_sec": s.elapsed_sec,
                "fail_class": s.fail_class,
                "fail_detail": s.fail_detail,
                "subprocess_log_path": s.subprocess_log_path,
            }
            if s.elaborated_size_bytes is not None:
                base["elaborated_size_bytes"] = s.elaborated_size_bytes
            if s.elaborated_path is not None:
                base["elaborated_path"] = s.elaborated_path
            if s.module_identifier is not None:
                base["module_identifier"] = s.module_identifier
            if s.bound_used is not None:
                base["bound_used"] = s.bound_used
            if s.k_attempt_matrix is not None:
                base["k_attempt_matrix"] = [
                    dict(row) for row in s.k_attempt_matrix
                ]
            if s.miter_top is not None:
                base["miter_top"] = s.miter_top
            return base

        return {
            "smoke_version": self.smoke_version,
            "bundle_path": self.bundle_path,
            "top_module": self.top_module,
            "bound_default": self.bound_default,
            "bound_ladder": list(self.bound_ladder),
            "fail_fast": self.fail_fast,
            "timestamp": self.timestamp,
            "overall": self.overall,
            "elapsed_sec_total": self.elapsed_sec_total,
            "steps": {
                name: _step_dict(s)
                for name, s in self.steps.items()
            },
            "remediation": self.remediation,
        }


_REMEDIATION_TABLE: dict[str, str] = {
    "yosys_binary_not_found": (
        "Install yosys (https://github.com/YosysHQ/yosys) and ensure "
        "it's on PATH. Smoke can't run without it."
    ),
    "ebmc_binary_not_found": (
        "Install ebmc (https://github.com/diffblue/hw-cbmc) and ensure "
        "it's on PATH. Smoke can't run without it."
    ),
    "dep_files_missing": (
        "Bundle inputs/ directory is empty or top file unreachable. "
        "Check bundle_path/inputs/ exists and contains the top RTL file."
    ),
    "yosys_parser_error": (
        "yosys couldn't parse the RTL. Check yosys_elaborate."
        "subprocess_log_path for the line/column. Likely a SV construct "
        "yosys doesn't support yet — file as ATH-1076-class regression."
    ),
    "elaborate_timeout": (
        "yosys ran past timeout_sec_per_step on this bundle. Likely "
        "pathological input; flag for CTO triage."
    ),
    "ebmc_parser_error": (
        "ebmc rejected the elaborated form. Likely an ATH-1076-class "
        "regression. Attach ebmc_parse_only.subprocess_log_path to a "
        "Linear bug. Bundle is NOT fire-ready."
    ),
    "top_module_not_found": (
        "Elaboration produced output without top_module. Possible silent "
        "rename; check yosys log for hierarchy issues."
    ),
    "identity_refuted": (
        "Identity equivalence REFUTED at k={k}. Preprocessor regression "
        "— gold and gate semantics diverge. Fail-loud per regression "
        "discipline; do NOT proceed to optimize."
    ),
    "identity_inconclusive_at_max_bound": (
        "Identity equivalence INCONCLUSIVE at every k in the ladder "
        "({ladder}). Bundle is not smoke-validatable at this ladder — "
        "widen bound_ladder or accept smoke can't confirm fire-readiness."
    ),
    "identity_setup_error": (
        "Failed to build the identity miter. Upstream preprocessor "
        "blocker; check earlier step logs for root cause."
    ),
}


def _resolve_dep_files(
    bundle_path: Path,
    sig: dict | None,
    explicit_dep_files: list[str | Path] | None,
    gold_sv_rel: str | None,
) -> list[Path]:
    """Resolve dep_files per ATH-1077 discovery order.

    Order: (a) explicit ``dep_files`` kwarg → (b) ``signature.dep_files``
    → (c) walk ``bundle_path/inputs/`` for ``.v``/``.sv`` files
    excluding the top.
    """
    if explicit_dep_files is not None:
        return [Path(d).resolve() for d in explicit_dep_files]
    if sig is not None and sig.get("dep_files"):
        real_bundle = bundle_path.resolve()
        resolved = []
        for d in sig["dep_files"]:
            dp = (bundle_path / d).resolve()
            if dp.is_relative_to(real_bundle):
                resolved.append(dp)
        return resolved
    inputs_dir = bundle_path / "inputs"
    if not inputs_dir.is_dir():
        return []
    top_filename = (
        Path(gold_sv_rel).name if gold_sv_rel else None
    )
    deps: list[Path] = []
    for p in sorted(inputs_dir.iterdir()):
        if p.suffix not in (".v", ".sv"):
            continue
        if top_filename is not None and p.name == top_filename:
            continue
        deps.append(p.resolve())
    return deps


def _resolve_top_rtl(bundle_path: Path, sig: dict | None) -> Path:
    """Find the top-level RTL file from signature.gold_sv or fallback."""
    if sig is not None and sig.get("gold_sv"):
        candidate = (bundle_path / sig["gold_sv"]).resolve()
        if candidate.is_file() and candidate.is_relative_to(bundle_path.resolve()):
            return candidate
    inputs_dir = bundle_path / "inputs"
    if inputs_dir.is_dir():
        for p in sorted(inputs_dir.iterdir()):
            if p.suffix in (".v", ".sv"):
                return p.resolve()
    raise FileNotFoundError(
        f"No top RTL file found in {bundle_path} (no signature.gold_sv "
        f"and no .v/.sv in inputs/)"
    )


def _step_yosys_elaborate(
    *,
    rtl_path: Path,
    top_module: str,
    dep_files: list[Path],
    work_dir: Path,
    timeout_sec: int,
) -> SmokeStepResult:
    from kairos.sec.preprocess import (
        YosysElaborateError,
        yosys_elaborate_to_verilog,
    )

    start = time.monotonic()
    try:
        r = yosys_elaborate_to_verilog(
            rtl_path=rtl_path,
            top_module=top_module,
            dep_files=dep_files,
            output_path=work_dir / "elab.v",
            log_dir=work_dir,
            timeout_sec=timeout_sec,
        )
        elaborated_size = Path(r.elaborated_path).stat().st_size
        if elaborated_size <= 100:
            return SmokeStepResult(
                step="yosys_elaborate",
                status="FAIL",
                elapsed_sec=time.monotonic() - start,
                fail_class="yosys_parser_error",
                fail_detail=(
                    f"Elaborated output suspiciously small "
                    f"({elaborated_size} bytes); likely a parse error "
                    f"that yosys swallowed."
                ),
                subprocess_log_path=r.log_path,
                elaborated_size_bytes=elaborated_size,
            )
        return SmokeStepResult(
            step="yosys_elaborate",
            status="PASS",
            elapsed_sec=r.runtime_sec,
            subprocess_log_path=r.log_path,
            elaborated_size_bytes=elaborated_size,
            elaborated_path=r.elaborated_path,
        )
    except YosysElaborateError as exc:
        elapsed = time.monotonic() - start
        msg = str(exc)
        if "yosys binary not found" in msg:
            fail_class = "yosys_binary_not_found"
        elif "rtl_path not found" in msg or "dep_files entry not found" in msg:
            fail_class = "dep_files_missing"
        elif "timed out" in msg:
            fail_class = "elaborate_timeout"
        else:
            fail_class = "yosys_parser_error"
        return SmokeStepResult(
            step="yosys_elaborate",
            status="FAIL",
            elapsed_sec=elapsed,
            fail_class=fail_class,
            fail_detail=msg[:500],
        )


def _step_ebmc_parse_only(
    *,
    elab_path: Path,
    top_module: str,
    work_dir: Path,
    timeout_sec: int,
) -> SmokeStepResult:
    ebmc_bin = shutil.which("ebmc")
    if ebmc_bin is None:
        return SmokeStepResult(
            step="ebmc_parse_only",
            status="FAIL",
            elapsed_sec=0.0,
            fail_class="ebmc_binary_not_found",
            fail_detail=(
                "ebmc not on $PATH. Install via apt / brew / "
                "https://github.com/diffblue/hw-cbmc."
            ),
        )

    log_path = work_dir / "ebmc_show_modules.log"
    start = time.monotonic()
    try:
        proc = subprocess.run(
            [ebmc_bin, "--show-modules", str(elab_path)],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
            env=safe_env_for_ebmc(),
        )
    except subprocess.TimeoutExpired:
        elapsed = time.monotonic() - start
        return SmokeStepResult(
            step="ebmc_parse_only",
            status="FAIL",
            elapsed_sec=elapsed,
            fail_class="ebmc_parser_error",
            fail_detail=f"ebmc --show-modules timed out after {timeout_sec}s",
        )
    elapsed = time.monotonic() - start
    log_path.write_text(proc.stdout + "\n--- STDERR ---\n" + proc.stderr)

    if proc.returncode != 0:
        return SmokeStepResult(
            step="ebmc_parse_only",
            status="FAIL",
            elapsed_sec=elapsed,
            fail_class="ebmc_parser_error",
            fail_detail=(
                f"ebmc --show-modules exited {proc.returncode}: "
                f"{(proc.stderr or proc.stdout).splitlines()[0][:300] if (proc.stderr or proc.stdout).strip() else 'no output'}"
            ),
            subprocess_log_path=str(log_path),
        )

    expected = f"Verilog::{top_module}"
    if expected not in proc.stdout:
        return SmokeStepResult(
            step="ebmc_parse_only",
            status="FAIL",
            elapsed_sec=elapsed,
            fail_class="top_module_not_found",
            fail_detail=(
                f"Expected '{expected}' in ebmc stdout; not present. "
                f"Possible silent rename during elaboration."
            ),
            subprocess_log_path=str(log_path),
        )

    return SmokeStepResult(
        step="ebmc_parse_only",
        status="PASS",
        elapsed_sec=elapsed,
        subprocess_log_path=str(log_path),
        module_identifier=expected,
    )


def _build_identity_miter_text(
    elab_path: Path,
    top_module: str,
    sig: dict | None,
) -> tuple[str, str]:
    """Build identity miter: rename gold→gate copy + miter SV body.

    Returns ``(combined_sv_text, miter_top_name)``.
    """
    elab_text = elab_path.read_text()
    gate_module = f"{top_module}_gate"
    elab_gate = elab_text.replace(
        f"module {top_module}", f"module {gate_module}", 1,
    )
    # Use the existing build_miter helper if signature has ports;
    # otherwise we can't construct the miter. For Phase A we require
    # signature.json with a ports list.
    from kairos.sec import build_miter
    from kairos.sec._adapter import _ports_from_signature

    if sig is None:
        raise ValueError(
            "identity_equivalence requires signature.json with ports[]"
        )
    ports = _ports_from_signature(sig)
    miter = build_miter(
        gold_module=top_module,
        gate_module=gate_module,
        ports=ports,
        clock_port=sig.get("clock_port", "clk"),
        reset_port=sig.get("reset_port", "rst_n"),
        reset_active_low=sig.get("reset_active_low", True),
    )
    combined = elab_text + "\n" + elab_gate + "\n" + miter.sv_text
    return combined, miter.miter_top


_REFUTED_RE = re.compile(r"\bREFUTED\b", re.IGNORECASE)
_PROVED_RE = re.compile(r"\bPROVED\b", re.IGNORECASE)
_INCONCLUSIVE_RE = re.compile(r"\bINCONCLUSIVE\b", re.IGNORECASE)


def _step_identity_equivalence(
    *,
    elab_path: Path,
    top_module: str,
    sig: dict | None,
    bound_ladder: tuple[int, ...],
    work_dir: Path,
    timeout_sec: int,
) -> SmokeStepResult:
    ebmc_bin = shutil.which("ebmc")
    if ebmc_bin is None:
        return SmokeStepResult(
            step="identity_equivalence",
            status="FAIL",
            elapsed_sec=0.0,
            fail_class="ebmc_binary_not_found",
            fail_detail="ebmc not on $PATH.",
        )

    start = time.monotonic()
    try:
        combined_text, miter_top = _build_identity_miter_text(
            elab_path, top_module, sig,
        )
    except Exception as exc:  # noqa: BLE001
        return SmokeStepResult(
            step="identity_equivalence",
            status="FAIL",
            elapsed_sec=time.monotonic() - start,
            fail_class="identity_setup_error",
            fail_detail=f"{type(exc).__name__}: {str(exc)[:300]}",
        )

    combined_path = work_dir / "identity_miter.sv"
    combined_path.write_text(combined_text)

    reset_port = sig.get("reset_port", "rst_n") if sig else "rst_n"
    reset_active_low = (
        sig.get("reset_active_low", True) if sig else True
    )
    reset_expr = f"!{reset_port}" if reset_active_low else reset_port

    k_attempt_matrix: list[dict[str, object]] = []
    final_log_path: str | None = None
    refuted_seen = False

    # Identity miter on the FLATTENED elaborated form: BMC mode (not
    # k-induction) is the right tool. K-induction struggles with
    # flattened state-vector identity because the inductive step has
    # to relate two representations of the same crunched state, which
    # yosys-flatten may reorder. BMC at depth k proves "no divergence
    # in k cycles" — sufficient for fire-readiness gate, and the
    # elaborated-form-PROVED-at-k=32 result matches the qa option-D
    # validated baseline on the unflattened form.
    for k in bound_ladder:
        k_log_path = work_dir / f"ebmc_bmc_k{k}.log"
        k_start = time.monotonic()
        try:
            proc = subprocess.run(
                [
                    ebmc_bin, str(combined_path),
                    "--bound", str(k),
                    "--reset", reset_expr,
                ],
                capture_output=True,
                text=True,
                timeout=timeout_sec,
                check=False,
                env=safe_env_for_ebmc(),
            )
        except subprocess.TimeoutExpired:
            k_log_path.write_text(
                f"timed out after {timeout_sec}s at k={k}\n"
            )
            k_attempt_matrix.append({
                "k": k,
                "result": "TIMEOUT",
                "elapsed_sec": time.monotonic() - k_start,
                "subprocess_log_path": str(k_log_path),
            })
            final_log_path = str(k_log_path)
            continue
        k_elapsed = time.monotonic() - k_start
        k_log_path.write_text(
            proc.stdout + "\n--- STDERR ---\n" + proc.stderr
        )
        final_log_path = str(k_log_path)

        if _REFUTED_RE.search(proc.stdout):
            k_attempt_matrix.append({
                "k": k,
                "result": "REFUTED",
                "elapsed_sec": k_elapsed,
                "subprocess_log_path": str(k_log_path),
            })
            refuted_seen = True
            break
        if _PROVED_RE.search(proc.stdout) and not _INCONCLUSIVE_RE.search(
            proc.stdout
        ):
            k_attempt_matrix.append({
                "k": k,
                "result": "PROVED",
                "elapsed_sec": k_elapsed,
                "subprocess_log_path": str(k_log_path),
            })
            return SmokeStepResult(
                step="identity_equivalence",
                status="PASS",
                elapsed_sec=time.monotonic() - start,
                subprocess_log_path=str(k_log_path),
                bound_used=k,
                k_attempt_matrix=tuple(k_attempt_matrix),
                miter_top=miter_top,
            )
        k_attempt_matrix.append({
            "k": k,
            "result": "INCONCLUSIVE",
            "elapsed_sec": k_elapsed,
            "subprocess_log_path": str(k_log_path),
        })

    if refuted_seen:
        # Pick the k at which REFUTE first surfaced for the customer-
        # facing remediation interpolation.
        refuted_k = next(
            (row["k"] for row in k_attempt_matrix if row["result"] == "REFUTED"),
            bound_ladder[0],
        )
        return SmokeStepResult(
            step="identity_equivalence",
            status="FAIL",
            elapsed_sec=time.monotonic() - start,
            fail_class="identity_refuted",
            fail_detail=(
                f"BMC REFUTED at k={refuted_k} on identity miter — "
                f"preprocessor regression; gold and gate semantics diverge."
            ),
            subprocess_log_path=final_log_path,
            k_attempt_matrix=tuple(k_attempt_matrix),
        )

    return SmokeStepResult(
        step="identity_equivalence",
        status="FAIL",
        elapsed_sec=time.monotonic() - start,
        fail_class="identity_inconclusive_at_max_bound",
        fail_detail=(
            f"BMC INCONCLUSIVE at every k in ladder "
            f"{list(bound_ladder)}."
        ),
        subprocess_log_path=final_log_path,
        k_attempt_matrix=tuple(k_attempt_matrix),
    )


def smoke_validate(
    bundle_path: Path | str,
    top_module: str | None = None,
    *,
    bound_default: int = 32,
    bound_ladder: tuple[int, ...] | list[int] = (32, 64, 128),
    fail_fast: bool = True,
    timeout_sec_per_step: int = 60,
    dep_files: list[str | Path] | None = None,
    work_dir: Path | str | None = None,
) -> SmokeValidationResult:
    """Run the 3-step smoke validation pipeline on a bundle.

    Parameters
    ----------
    bundle_path:
        Directory containing ``inputs/`` (RTL files) and optionally
        ``signature.json`` (port contract + dep_files manifest per
        ATH-1074).
    top_module:
        Top-level module name. When ``None``, derived from
        ``signature.json``'s ``gold_module`` / ``target_module`` field
        (or falls back to the bundle directory basename).
    bound_default:
        Starting k for identity-equiv ladder. Default 32 per Aidan
        k-bound fleet directive.
    bound_ladder:
        Retry ladder of k values. Default ``(32, 64, 128)`` matches
        qa option-D-validated escalation.
    fail_fast:
        Stop pipeline on first hard FAIL. Default ``True``.
    timeout_sec_per_step:
        Per-step subprocess timeout. Default 60.
    dep_files:
        Optional explicit override of dep_files. Takes precedence over
        signature.json's dep_files + bundle convention walk.
    work_dir:
        Directory for elaboration output + subprocess logs. Default:
        a fresh tempdir under ``$TMPDIR/kairos_smoke_<top>_<pid>/``.

    Returns
    -------
    :class:`SmokeValidationResult` with overall + per-step + remediation.
    """
    started_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    started_monotonic = time.monotonic()
    bundle = Path(bundle_path).resolve()

    sig_path = bundle / "signature.json"
    sig: dict | None = None
    if sig_path.is_file():
        sig = _json.loads(sig_path.read_text())

    resolved_top: str
    if top_module is not None:
        resolved_top = top_module
    elif sig is not None:
        resolved_top = (
            sig.get("gold_module")
            or sig.get("target_module")
            or bundle.name
        )
    else:
        resolved_top = bundle.name

    if work_dir is None:
        work = Path(tempfile.mkdtemp(prefix=f"kairos_smoke_{resolved_top}_"))
    else:
        work = Path(work_dir).resolve()
        work.mkdir(parents=True, exist_ok=True)

    try:
        gold_sv_rel = sig.get("gold_sv") if sig else None
        rtl_top_path = _resolve_top_rtl(bundle, sig)
    except FileNotFoundError as exc:
        result = SmokeValidationResult(
            bundle_path=str(bundle),
            top_module=resolved_top,
            bound_default=bound_default,
            bound_ladder=tuple(bound_ladder),
            fail_fast=fail_fast,
            timestamp=started_at,
            overall="FAIL",
            elapsed_sec_total=time.monotonic() - started_monotonic,
            steps={
                "yosys_elaborate": SmokeStepResult(
                    step="yosys_elaborate",
                    status="FAIL",
                    elapsed_sec=0.0,
                    fail_class="dep_files_missing",
                    fail_detail=str(exc)[:300],
                ),
                "ebmc_parse_only": SmokeStepResult(
                    step="ebmc_parse_only",
                    status="SKIPPED",
                    elapsed_sec=0.0,
                ),
                "identity_equivalence": SmokeStepResult(
                    step="identity_equivalence",
                    status="SKIPPED",
                    elapsed_sec=0.0,
                ),
            },
            remediation=_REMEDIATION_TABLE["dep_files_missing"],
        )
        _maybe_emit_smoke_event(result)
        return result

    deps = _resolve_dep_files(bundle, sig, dep_files, gold_sv_rel)

    steps: dict[str, SmokeStepResult] = {}

    step1 = _step_yosys_elaborate(
        rtl_path=rtl_top_path,
        top_module=resolved_top,
        dep_files=deps,
        work_dir=work,
        timeout_sec=timeout_sec_per_step,
    )
    steps["yosys_elaborate"] = step1

    if step1.status == "FAIL" and fail_fast:
        steps["ebmc_parse_only"] = SmokeStepResult(
            step="ebmc_parse_only", status="SKIPPED", elapsed_sec=0.0,
        )
        steps["identity_equivalence"] = SmokeStepResult(
            step="identity_equivalence", status="SKIPPED", elapsed_sec=0.0,
        )
        result = _finalize_result(
            bundle, resolved_top, bound_default, bound_ladder,
            fail_fast, started_at, started_monotonic, steps, step1,
        )
        _maybe_emit_smoke_event(result)
        return result

    elab_path: Path | None = None
    if step1.status == "PASS" and step1.elaborated_path is not None:
        elab_path = Path(step1.elaborated_path)

    if elab_path is not None:
        step2 = _step_ebmc_parse_only(
            elab_path=elab_path,
            top_module=resolved_top,
            work_dir=work,
            timeout_sec=timeout_sec_per_step,
        )
    else:
        step2 = SmokeStepResult(
            step="ebmc_parse_only",
            status="SKIPPED",
            elapsed_sec=0.0,
        )
    steps["ebmc_parse_only"] = step2

    if step2.status == "FAIL" and fail_fast:
        steps["identity_equivalence"] = SmokeStepResult(
            step="identity_equivalence", status="SKIPPED", elapsed_sec=0.0,
        )
        result = _finalize_result(
            bundle, resolved_top, bound_default, bound_ladder,
            fail_fast, started_at, started_monotonic, steps, step2,
        )
        _maybe_emit_smoke_event(result)
        return result

    if elab_path is not None and step2.status != "FAIL":
        step3 = _step_identity_equivalence(
            elab_path=elab_path,
            top_module=resolved_top,
            sig=sig,
            bound_ladder=tuple(bound_ladder),
            work_dir=work,
            timeout_sec=timeout_sec_per_step,
        )
    else:
        step3 = SmokeStepResult(
            step="identity_equivalence",
            status="SKIPPED",
            elapsed_sec=0.0,
        )
    steps["identity_equivalence"] = step3

    failing = next(
        (s for s in steps.values() if s.status == "FAIL"),
        None,
    )
    result = _finalize_result(
        bundle, resolved_top, bound_default, bound_ladder,
        fail_fast, started_at, started_monotonic, steps, failing,
    )
    _maybe_emit_smoke_event(result)
    return result


def _maybe_emit_smoke_event(result: SmokeValidationResult) -> None:
    """Emit a ``kairos_smoke_validation_complete`` event when fired
    inside an existing :func:`kairos.observe.observe` context.

    Smoke is callable both as a standalone CLI / one-shot helper AND
    inside a larger pipeline. When standalone (no observe context),
    we don't open one — emit silently no-ops, the structured result
    is the caller's contract. When inside observe, the event lands on
    sdk_agent_events with the full SmokeValidationResult dict as
    payload, powering the dashboard's KairosSmokeValidationPanel.

    Per spec: payload structure matches result.to_dict() exactly +
    standard EventEnvelope fields (run_subtype="pre_fire_check",
    run_type="sdk_smoke_validation"). Caller's observe-context
    fleet_agent_role + invocation_path flow through automatically.
    """
    try:
        from kairos.observe import emit
    except ImportError:
        return
    try:
        emit(
            "kairos_smoke_validation_complete",
            payload=result.to_dict(),
            silent_if_no_session=True,
        )
    except Exception:  # noqa: BLE001
        # Emit hook MUST NEVER break smoke. If observe is in a
        # malformed state, swallow the error — the structured
        # SmokeValidationResult is still returned to the caller.
        pass


def _finalize_result(
    bundle: Path,
    top_module: str,
    bound_default: int,
    bound_ladder: tuple[int, ...] | list[int],
    fail_fast: bool,
    started_at: str,
    started_monotonic: float,
    steps: dict[str, SmokeStepResult],
    failing_step: SmokeStepResult | None,
) -> SmokeValidationResult:
    # Fill SKIPPED for any unscheduled step under fail_fast
    for canonical in ("yosys_elaborate", "ebmc_parse_only", "identity_equivalence"):
        if canonical not in steps:
            steps[canonical] = SmokeStepResult(
                step=canonical,  # type: ignore[arg-type]
                status="SKIPPED",
                elapsed_sec=0.0,
            )

    overall: OverallStatus
    remediation: str | None
    if failing_step is None:
        overall = "PASS"
        remediation = None
    else:
        overall = "FAIL"
        template = (
            _REMEDIATION_TABLE.get(failing_step.fail_class or "")
            if failing_step.fail_class
            else None
        )
        if template is not None and "{" in template:
            # Per qa nit B: interpolate {k} from the refute/inconclusive
            # k_attempt_matrix and {ladder} from bound_ladder so customer
            # sees the actual numbers (matches ATH-1077 spec verbatim).
            k_value: object = "?"
            if failing_step.k_attempt_matrix:
                # For identity_refuted: pick the k where REFUTE first hit.
                # For identity_inconclusive_at_max_bound: pick the highest k.
                if failing_step.fail_class == "identity_refuted":
                    k_value = next(
                        (
                            row["k"] for row in failing_step.k_attempt_matrix
                            if row["result"] == "REFUTED"
                        ),
                        bound_ladder[0],
                    )
                else:
                    k_value = (
                        failing_step.k_attempt_matrix[-1]["k"]
                        if failing_step.k_attempt_matrix
                        else bound_ladder[-1]
                    )
            try:
                remediation = template.format(
                    k=k_value, ladder=list(bound_ladder),
                )
            except (KeyError, IndexError):
                remediation = template
        else:
            remediation = template

    return SmokeValidationResult(
        bundle_path=str(bundle),
        top_module=top_module,
        bound_default=bound_default,
        bound_ladder=tuple(bound_ladder),
        fail_fast=fail_fast,
        timestamp=started_at,
        overall=overall,
        elapsed_sec_total=time.monotonic() - started_monotonic,
        steps=steps,
        remediation=remediation,
    )


__all__ = [
    "SmokeStepResult",
    "SmokeValidationResult",
    "smoke_validate",
]
