"""Phase 1a transformation taxonomy manifest (ATH-1080).

Structured registry of optimization classes per the customer's chief architect's
2026-05-07 strategy realignment (ATH-1078). Two phases:

* :data:`REMOVE_CLASSES` — Phase 1a: nine pure-win combo-only
  reductions (area down, timing down, power down). Provable at
  k=1 most of the time per the customer's `--bound 1` directive on
  identity-preserving combo changes.

* :data:`ADD_FOR_POWER_CLASSES` — Phase 1b: five area-vs-power
  tradeoff transformations (operand-isolation, bus-gating, etc.).
  Empty-shell-flagged today; not loaded into the Phase 1a proposer
  prompt yet.

Each entry is a :class:`TransformationClass` frozen dataclass with
stable string ID, verbatim customer-provided description, expected miter
shape, k-bound ladder (optimistic + safety-net + escalation cap),
required assumption classes (forward-pin for the assumption-mining
pipeline), and optional structural-pattern hints the proposer can
grep for.

Public API:

* :class:`TransformationClass` — per-entry frozen dataclass
* :data:`REMOVE_CLASSES` — tuple of nine Phase 1a entries
* :data:`ADD_FOR_POWER_CLASSES` — tuple of five Phase 1b entries
* :func:`to_json_serializable` — registry → list of dicts (cert
  tarball / proposer-prompt literal)
* :func:`from_json_serializable` — round-trip from list of dicts

This module is data-only. Orchestrator + proposer wiring lands
post-Aidan-greenlight in a separate PR; this PR pins the manifest
shape so CTO can ground their wire-up against a stable
contract.
"""
from __future__ import annotations

from dataclasses import dataclass, fields, asdict
from typing import Literal


PhaseId = Literal["1a", "1b"]


@dataclass(frozen=True)
class TransformationClass:
    """One entry in the optimization-class manifest."""

    id: str
    description: str
    phase: PhaseId
    miter_shape: str = "output_equality_under_assumptions"
    optimistic_k_bound: int = 1
    safety_net_k_bound: int = 32
    bound_ladder: tuple[int, ...] = (1, 32, 64, 128)
    requires_assumptions: tuple[str, ...] = ()
    structural_pattern_hints: tuple[str, ...] = ()


REMOVE_CLASSES: tuple[TransformationClass, ...] = (
    TransformationClass(
        id="dead-logic-removal",
        description="Dead logic removal",
        phase="1a",
        structural_pattern_hints=(
            "wire never read",
            "register never sourcing an output",
        ),
    ),
    TransformationClass(
        id="width-reduction",
        description="Width reduction",
        phase="1a",
        requires_assumptions=("value_bound", "signal_range"),
        structural_pattern_hints=("input/output width > value-range bound",),
    ),
    TransformationClass(
        id="redundant-guard-removal",
        description="Redundant guard removal",
        phase="1a",
        structural_pattern_hints=(
            "if (cond) where cond is provably tautological",
        ),
    ),
    TransformationClass(
        id="constant-propagation",
        description="Constant propagation",
        phase="1a",
        structural_pattern_hints=("signal driven by constant expression",),
    ),
    TransformationClass(
        id="common-subexpression-sharing",
        description="Common subexpression sharing",
        phase="1a",
        structural_pattern_hints=("identical RHS expressions in N assigns",),
    ),
    TransformationClass(
        id="comparison-narrowing",
        description="Comparison narrowing",
        phase="1a",
        requires_assumptions=("signal_range", "unused_high_bits"),
        structural_pattern_hints=("comparator wider than necessary range",),
    ),
    TransformationClass(
        id="mutual-exclusion-parallel-or",
        description="Mutual exclusion to parallel OR",
        phase="1a",
        requires_assumptions=("mutex_invariant",),
        structural_pattern_hints=(
            "if/else chain over provably mutually-exclusive conditions",
        ),
    ),
    TransformationClass(
        id="shift-instead-of-multiply",
        description="Shift instead of multiply",
        phase="1a",
        structural_pattern_hints=("multiply by power-of-two constant",),
    ),
    TransformationClass(
        id="dead-condition-elimination",
        description="Dead condition elimination",
        phase="1a",
        requires_assumptions=("mutex_invariant", "unreachable_state"),
        structural_pattern_hints=(
            "case branch / if-arm provably never reached",
        ),
    ),
)


ADD_FOR_POWER_CLASSES: tuple[TransformationClass, ...] = (
    TransformationClass(
        id="operand-isolation",
        description="Operand isolation",
        phase="1b",
    ),
    TransformationClass(
        id="bus-gating",
        description="Bus gating",
        phase="1b",
    ),
    TransformationClass(
        id="conditional-computation-skip",
        description="Conditional computation skip",
        phase="1b",
    ),
    TransformationClass(
        id="gray-code-encoding",
        description="Gray-code encoding",
        phase="1b",
    ),
    TransformationClass(
        id="late-select",
        description="Late select",
        phase="1b",
    ),
)


def to_json_serializable(
    classes: tuple[TransformationClass, ...],
) -> list[dict[str, object]]:
    """Convert a registry tuple to a JSON-serializable list of dicts.

    Tuples are converted to lists so :func:`json.dumps` accepts
    the result without a custom encoder. Use this when emitting
    the manifest into proposer prompts or shipping in cert tarballs.
    """
    out: list[dict[str, object]] = []
    for c in classes:
        d = asdict(c)
        # Convert any tuple-valued fields to lists for JSON.
        for k, v in list(d.items()):
            if isinstance(v, tuple):
                d[k] = list(v)
        out.append(d)
    return out


def from_json_serializable(
    payload: list[dict[str, object]],
) -> tuple[TransformationClass, ...]:
    """Round-trip parse of a list-of-dicts back into a registry tuple.

    Used by tests + by future orchestrator code that loads a
    customer-edited manifest from disk.
    """
    field_names = {f.name for f in fields(TransformationClass)}
    out: list[TransformationClass] = []
    for d in payload:
        kwargs: dict[str, object] = {}
        for k in field_names:
            if k not in d:
                continue
            v = d[k]
            if isinstance(v, list):
                v = tuple(v)
            kwargs[k] = v
        out.append(TransformationClass(**kwargs))
    return tuple(out)


__all__ = [
    "TransformationClass",
    "REMOVE_CLASSES",
    "ADD_FOR_POWER_CLASSES",
    "to_json_serializable",
    "from_json_serializable",
]
