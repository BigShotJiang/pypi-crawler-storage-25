"""kairos.sec._adapter — verify_sec + run_sec_bundle implementation.

Wraps :func:`kairos.ebmc.verify` with the SEC harness construction
+ dual-mode invocation (BMC + k-induction) + bundle adapter shape.
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, Literal

from kairos.sec._miter import MiterPort, MiterSpec, build_miter

EngineMode = Literal["bmc", "k_induction"]


@dataclass(frozen=True)
class SecVerifyResult:
    """Outcome of one :func:`verify_sec` call.

    Wraps the underlying :class:`kairos.ebmc.EbmcVerifyResult` with
    SEC-specific framing: per-property verdicts come from the miter's
    assertion labels, and ``proved`` aggregates across all output
    equivalence assertions.
    """

    proved: bool
    refuted: bool
    mode: EngineMode
    bound_k: int
    property_verdicts: dict[str, str] = field(default_factory=dict)
    counterexample: str | None = None
    elapsed_seconds: float = 0.0
    miter_spec: MiterSpec | None = None
    miter_path: str | None = None


@dataclass(frozen=True)
class RunSecResult:
    """Outcome of one :func:`run_sec_bundle` call.

    The dual-mode pattern (BMC + k_induction) is the customer-visible
    contract: BMC catches shallow refutations early, k_induction
    closes the unbounded proof when BMC stays silent at a chosen
    bound. The dashboard renders both verdicts side-by-side per
    the customer's directive.
    """

    run_id: str
    bmc_result: SecVerifyResult
    induction_result: SecVerifyResult
    bundle_path: str
    miter_module: str


# ───────────────────────────────────────────────────────────────────
# verify_sec — atomic miter + EBMC invocation
# ───────────────────────────────────────────────────────────────────


def verify_sec(
    *,
    gold_sv: str | Path,
    gate_v: str | Path,
    gold_module: str,
    gate_module: str,
    ports: Iterable[MiterPort],
    mode: EngineMode = "bmc",
    bound: int = 10,
    clock_port: str = "clk",
    reset_port: str = "rst_n",
    reset_active_low: bool = True,
    timeout_sec: int = 120,
    work_dir: str | Path | None = None,
    dep_files: Iterable[str | Path] | None = None,
) -> SecVerifyResult:
    """Run an SEC miter through EBMC in the chosen mode.

    Constructs the miter via :func:`build_miter`, writes it alongside
    the gold + gate source files in ``work_dir``, invokes
    :func:`kairos.ebmc.verify` on the combined input set, and packs
    the result in :class:`SecVerifyResult`.

    :param gold_sv: Path to the gold SystemVerilog source.
    :param gate_v: Path to the gate Verilog (typically Clash-emitted).
    :param gold_module: Module name of the gold (top-level instance
        target inside the miter).
    :param gate_module: Module name of the gate. MUST differ from
        ``gold_module`` after Verilog parsing — the caller is
        responsible for renaming the gate's module declaration if
        Clash emitted it with the gold's name.
    :param ports: Shared port signature for both designs.
    :param mode: ``"bmc"`` (bounded) or ``"k_induction"`` (unbounded
        when proved).
    :param bound: Bound depth for BMC; ignored under k_induction
        when proof closes.
    :param work_dir: Directory to write the generated miter into.
        Defaults to a sibling of ``gold_sv`` named
        ``<gold_sv.stem>_sec_work``. Created if missing.
    :param dep_files: Optional list of additional RTL files containing
        sub-module dependencies (e.g. AP_DFFR_US, AP_REG_FIFO_US) that
        the gold and gate top modules instantiate. Both gold-side and
        gate-side share these dep modules verbatim — the proposer
        transforms only the top module. EBMC reads them alongside
        miter/gold/gate so module-link succeeds. Required when the
        gold-side design is multi-module (ATH-1074).

    :returns: :class:`SecVerifyResult` with per-property verdicts +
        the underlying EBMC counterexample (if refuted).
    """
    from kairos.sec.closed_loop._session_guard import require_active_session
    require_active_session("verify_sec")

    from kairos.ebmc import verify as ebmc_verify

    gold_path = Path(gold_sv).resolve()
    gate_path = Path(gate_v).resolve()
    if work_dir is None:
        work_dir = gold_path.parent / f"{gold_path.stem}_sec_work"
    work_dir = Path(work_dir).resolve()
    work_dir.mkdir(parents=True, exist_ok=True)

    # ATH-1109: extract internal registers from BOTH gold and gate,
    # intersect to find common names, and emit initial assumes only
    # for those. When the proposer restructures (one-hot → binary),
    # the intersection is empty and we fall back to no assumes (same
    # behavior as before the fix — 4/5 baseline). When the proposer
    # preserves structure (dead-logic, constant-prop), all registers
    # match and we get 5/5 via initial-state correspondence.
    from kairos.sec._miter import extract_internal_registers
    try:
        gold_text = gold_path.read_text()
        gate_text = gate_path.read_text()
        gold_regs = set(extract_internal_registers(gold_text))
        gate_regs = set(extract_internal_registers(gate_text))
        common_regs = tuple(sorted(gold_regs & gate_regs))
        # ATH-1109: after yosys parameterized elaboration, the module
        # name may be mangled (e.g. $paramod\name\param=val). Read the
        # actual module name from the elaborated file so the miter
        # references the correct name EBMC sees.
        import re as _re
        _mod_re = _re.compile(r"^module\s+([^\s(;]+)", _re.MULTILINE)
        _gold_m = _mod_re.search(gold_text)
        _gate_m = _mod_re.search(gate_text)
        if _gold_m:
            gold_module = _gold_m.group(1)
        if _gate_m:
            gate_module = _gate_m.group(1)
    except Exception:  # noqa: BLE001
        common_regs = ()
    miter = build_miter(
        gold_module=gold_module,
        gate_module=gate_module,
        ports=ports,
        clock_port=clock_port,
        reset_port=reset_port,
        reset_active_low=reset_active_low,
        initial_state_registers=common_regs,
    )
    miter_path = work_dir / "miter.sv"
    miter_path.write_text(miter.sv_text)

    # EBMC needs to see the miter (top), gold module, gate module, and
    # any sub-module dep files. Order: miter first (top), then gold,
    # then gate, then deps. EBMC's parser links them at top.
    rtl_inputs = [str(miter_path), str(gold_path), str(gate_path)]
    if dep_files is not None:
        for dep in dep_files:
            rtl_inputs.append(str(Path(dep).resolve()))

    # Detect combo-only: if clock_port is not in the port names,
    # skip reset_expr (EBMC doesn't need reset for combo checks).
    port_names = {p.name for p in ports}
    combo_only = clock_port not in port_names

    if combo_only or not reset_port:
        reset_condition = None
    elif reset_active_low:
        reset_condition = f"!{reset_port}"
    else:
        reset_condition = reset_port
    raw = ebmc_verify(
        rtl_inputs,  # type: ignore[arg-type]
        top_module=miter.miter_top,
        bound=bound,
        mode=mode,
        reset_expr=reset_condition,
        timeout_sec=timeout_sec,
    )

    return SecVerifyResult(
        proved=raw.proved,
        refuted=raw.refuted,
        mode=mode,
        bound_k=raw.bound_k,
        property_verdicts=dict(raw.property_verdicts),
        counterexample=raw.counterexample,
        elapsed_seconds=raw.elapsed_seconds,
        miter_spec=miter,
        miter_path=str(miter_path),
    )


# ───────────────────────────────────────────────────────────────────
# run_sec_bundle — bundle-shaped adapter (mirrors kairos.nki.run_bundle)
# ───────────────────────────────────────────────────────────────────


def _load_signature_from_bundle(bundle: Path) -> dict[str, Any]:
    """Read the bundle's signature.json describing the gold/gate
    module names + port list.

    Schema:

    .. code-block:: json

       {
         "gold_module": "fifo_widget",
         "gate_module": "fifo_widget_gate",
         "gold_sv": "gold.sv",
         "gate_v": "gate.v",
         "clock_port": "clk",
         "reset_port": "rst_n",
         "reset_active_low": true,
         "ports": [
           {"name": "clk",        "direction": "input",  "width": 1},
           {"name": "rst_n",      "direction": "input",  "width": 1},
           {"name": "push",       "direction": "input",  "width": 1},
           {"name": "push_data",  "direction": "input",  "width": 28},
           {"name": "pop",        "direction": "input",  "width": 1},
           {"name": "pop_data",   "direction": "output", "width": 28},
           {"name": "full",       "direction": "output", "width": 1},
           {"name": "empty",      "direction": "output", "width": 1}
         ]
       }
    """
    sig_path = bundle / "signature.json"
    if not sig_path.is_file():
        raise FileNotFoundError(
            f"SEC bundle missing signature.json: {sig_path!s}. "
            f"Schema: gold_module / gate_module / gold_sv / gate_v / "
            f"ports[]."
        )
    sig: dict[str, Any] = json.loads(sig_path.read_text())
    return sig


def _ports_from_signature(sig: dict[str, Any]) -> tuple[MiterPort, ...]:
    """Build MiterPort tuple from signature.json port list.

    Resolves parameterized widths (e.g. ``"width": "DATA_WIDTH"``)
    against ``signature.parameters[*].concrete_for_sec`` values per
    ATH-1074 multi-module bundle support. Falls back to ``int()``
    conversion when width is already numeric.
    """
    param_concrete: dict[str, int] = {}
    for p in sig.get("parameters", []):
        name = p.get("name")
        val = p.get("concrete_for_sec", p.get("default"))
        if isinstance(val, int):
            param_concrete[name] = val
        elif isinstance(val, str) and val.startswith(("'", '"')):
            # SystemVerilog literal like "1'b0" — not a width value.
            continue
        else:
            try:
                param_concrete[name] = int(val)
            except (TypeError, ValueError):
                continue

    def _resolve_width(w: Any) -> int:
        if isinstance(w, int):
            return w
        if isinstance(w, str):
            # Try parameter lookup first.
            if w in param_concrete:
                return param_concrete[w]
            # Fall back to int(); raises on non-numeric, which is the
            # right fail-loud behavior for an under-specified bundle.
            return int(w)
        return int(w)

    return tuple(
        MiterPort(
            name=p["name"],
            direction=p["direction"],
            width=_resolve_width(p.get("width", 1)),
        )
        for p in sig.get("ports", [])
    )


def run_sec_bundle(
    bundle_path: str | Path,
    *,
    bound: int = 10,
    timeout_sec: int = 120,
    sink: Any = None,
) -> RunSecResult:
    """SEC equivalent of :func:`kairos.nki.run_bundle`.

    Opens an :func:`kairos.observe.observe` session, runs the miter
    in BMC + k_induction modes, emits one
    ``sec_block_verified`` trace event with the dual-verdict payload,
    returns the run_id paired with both verify results.

    :param bundle_path: Directory containing ``signature.json`` plus
        the gold + gate source files referenced therein.
    :param bound: BMC bound depth (also lower-bound for the
        induction proof).
    :param timeout_sec: Per-mode wall-clock timeout. Total wall-clock
        is up to 2x this value (one BMC run + one k_induction run).
    :param sink: Optional :class:`kairos.trace.TraceSink` override.
        Defaults to ``default_sink_from_env``.
    """
    bundle = Path(bundle_path).resolve()
    if not bundle.is_dir():
        raise FileNotFoundError(
            f"SEC bundle directory not found: {bundle!s}. "
            f"Expected directory containing signature.json + the "
            f"gold/gate source files it references."
        )

    sig = _load_signature_from_bundle(bundle)
    gold_sv = bundle / sig["gold_sv"]
    gate_v = bundle / sig["gate_v"]
    if not gold_sv.is_file():
        raise FileNotFoundError(f"gold_sv missing: {gold_sv!s}")
    if not gate_v.is_file():
        raise FileNotFoundError(f"gate_v missing: {gate_v!s}")

    ports = _ports_from_signature(sig)
    gold_module = sig["gold_module"]
    gate_module = sig["gate_module"]

    # Same ``kairos.observe`` import-by-rebinding gotcha the demo
    # driver hits — see kairos.nki._adapter for context.
    import kairos.observe  # noqa: F401 — force-load
    obs = sys.modules["kairos.observe"]

    if sink is None:
        from kairos.trace import default_sink_from_env
        sink = default_sink_from_env()

    work_dir = bundle / "_sec_work"

    with obs.observe(
        sink=sink,
        run_subtype="theorem_proving",
        task_id=bundle.name,
        vertical="silicon_block_sec",
    ) as ctx:
        bmc_raw = verify_sec(
            gold_sv=gold_sv, gate_v=gate_v,
            gold_module=gold_module, gate_module=gate_module,
            ports=ports, mode="bmc", bound=bound,
            clock_port=sig.get("clock_port", "clk"),
            reset_port=sig.get("reset_port", "rst_n"),
            reset_active_low=bool(sig.get("reset_active_low", True)),
            timeout_sec=timeout_sec, work_dir=work_dir,
        )
        induction_raw = verify_sec(
            gold_sv=gold_sv, gate_v=gate_v,
            gold_module=gold_module, gate_module=gate_module,
            ports=ports, mode="k_induction", bound=bound,
            clock_port=sig.get("clock_port", "clk"),
            reset_port=sig.get("reset_port", "rst_n"),
            reset_active_low=bool(sig.get("reset_active_low", True)),
            timeout_sec=timeout_sec, work_dir=work_dir,
        )

        payload: dict[str, Any] = {
            "bundle_name": bundle.name,
            "bundle_path": str(bundle),
            "gold_module": gold_module,
            "gate_module": gate_module,
            "miter_top": "sec_miter",
            "bmc": {
                "proved": bmc_raw.proved,
                "refuted": bmc_raw.refuted,
                "bound_k": bmc_raw.bound_k,
                "property_verdicts": bmc_raw.property_verdicts,
                "elapsed_seconds": bmc_raw.elapsed_seconds,
            },
            "induction": {
                "proved": induction_raw.proved,
                "refuted": induction_raw.refuted,
                "bound_k": induction_raw.bound_k,
                "property_verdicts": induction_raw.property_verdicts,
                "elapsed_seconds": induction_raw.elapsed_seconds,
            },
        }
        obs.emit(
            "sec_block_verified",
            payload,
            run_subtype="theorem_proving",
            silent_if_no_session=False,
        )

        return RunSecResult(
            run_id=ctx.run_id,
            bmc_result=bmc_raw,
            induction_result=induction_raw,
            bundle_path=str(bundle),
            miter_module="sec_miter",
        )
