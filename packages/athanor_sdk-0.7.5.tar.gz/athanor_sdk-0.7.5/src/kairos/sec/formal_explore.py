"""kairos_formal_explore: EBMC capability assessment for customer agents.

Customer's agent asks "can I use X technique?" and gets a structured
answer: what EBMC supports, what it doesn't, closest alternatives,
and Lean theorem references where available.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class FormalCapability:
    name: str
    supported: bool
    ebmc_mechanism: str | None = None
    limitations: str | None = None
    alternative: str | None = None
    lean_theorem_ref: str | None = None


@dataclass(frozen=True)
class FormalExploreResult:
    query: str
    capabilities: list[FormalCapability]
    summary: str
    references: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "query": self.query,
            "summary": self.summary,
            "capabilities": [
                {
                    "name": c.name,
                    "supported": c.supported,
                    "ebmc_mechanism": c.ebmc_mechanism,
                    "limitations": c.limitations,
                    "alternative": c.alternative,
                    "lean_theorem_ref": c.lean_theorem_ref,
                }
                for c in self.capabilities
            ],
            "references": self.references,
        }


_CAPABILITY_DB: dict[str, list[FormalCapability]] = {
    "uninterpreted_functions": [
        FormalCapability(
            name="UF at SVA/property level",
            supported=False,
            limitations="EBMC checks properties against fully elaborated concrete transition system",
            alternative="Bridge invariants via assume-property to abstract module boundaries",
        ),
        FormalCapability(
            name="UF for Verilog functions",
            supported=False,
            limitations="EBMC fully inlines and bit-blasts all SV functions during elaboration",
            alternative="--cegar for automatic latch-level abstraction",
        ),
        FormalCapability(
            name="Arithmetic operators as UF",
            supported=False,
            limitations="No flag to treat +, *, / as uninterpreted. Always bit-blasted.",
            alternative="SMT2 backend emits to Z3/Boolector which support UFs, but EBMC never generates UF terms",
        ),
    ],
    "burch_dill": [
        FormalCapability(
            name="Burch-Dill flushing verification",
            supported=False,
            ebmc_mechanism=None,
            limitations="Requires UF abstraction for datapath operators, which EBMC does not support",
            alternative="Manual decomposition: verify control separately from datapath using assume-property bridges",
            lean_theorem_ref="BurchDillRefinement.burch_dill_n_steps (Pythia/Hardware/BurchDillRefinement.lean)",
        ),
        FormalCapability(
            name="UF preserves refinement (Burch-Dill + UF)",
            supported=False,
            ebmc_mechanism=None,
            limitations="EBMC cannot abstract operators as UFs; theorem proves the approach is sound if the tool supported it",
            alternative="kairos bridge invariants as manual abstraction layer",
            lean_theorem_ref="BurchDillUF.uf_preserves_refinement (Pythia/Hardware/BurchDillUF.lean, proved f1246eb)",
        ),
        FormalCapability(
            name="UF abstraction soundness for arithmetic",
            supported=False,
            ebmc_mechanism=None,
            limitations="Replacing +, *, / with UFs preserves congruence; EBMC cannot do this automatically",
            alternative="Feature request filed with Daniel Kroening (hw-cbmc maintainer)",
            lean_theorem_ref="BurchDillUF.uf_abstraction_sound (Pythia/Hardware/BurchDillUF.lean, proved f1246eb)",
        ),
    ],
    "bmc": [
        FormalCapability(
            name="Bounded model checking",
            supported=True,
            ebmc_mechanism="--bound K (default mode)",
            limitations="Only finds bugs up to bound K. Does not prove absence of bugs beyond K.",
            lean_theorem_ref="IC3PDRSoundness.bmc_sound (Pythia/Hardware/IC3PDRSoundness.lean)",
        ),
        FormalCapability(
            name="BMC completeness (depth guarantees)",
            supported=True,
            ebmc_mechanism="--bound K with sufficient depth",
            limitations="Complete only when bound >= diameter of the state space.",
            lean_theorem_ref="BMCCompleteness.bmc_depth_monotone + bmc_finite_complete + diameter_bounded_complete (Pythia/Hardware/BMCCompleteness.lean, proved 09f9176+8a7f3cf)",
        ),
    ],
    "k_induction": [
        FormalCapability(
            name="K-induction (unbounded proof)",
            supported=True,
            ebmc_mechanism="--k-induction",
            limitations="Requires inductive invariant. May need bridge invariants for complex designs.",
            lean_theorem_ref="KInductionSoundness.k_induction_sound (Pythia/Hardware/KInductionSoundness.lean)",
        ),
    ],
    "cegar": [
        FormalCapability(
            name="CEGAR abstraction-refinement",
            supported=True,
            ebmc_mechanism="--cegar",
            limitations="Latch-level abstraction only. Abstracts latches as nondeterministic, refines on counterexample.",
            lean_theorem_ref="CEGARSoundness.cegar_sound (Pythia/Hardware/CEGARSoundness.lean, proved PR#105)",
        ),
    ],
    "equivalence_checking": [
        FormalCapability(
            name="Combinational equivalence (miter)",
            supported=True,
            ebmc_mechanism="SAT miter via yosys equiv_opt or direct EBMC",
            lean_theorem_ref="Pythia/Hardware/ABCSynthesisSoundness.lean",
        ),
        FormalCapability(
            name="Sequential equivalence",
            supported=True,
            ebmc_mechanism="BMC + k-induction on miter",
            limitations="Sequential equivalence may require bridge invariants for state mapping",
        ),
    ],
    "interpolation": [
        FormalCapability(
            name="Craig interpolation for model checking",
            supported=False,
            ebmc_mechanism=None,
            limitations="EBMC does not implement interpolation-based model checking (McMillan 2003). Uses BMC + k-induction instead.",
            alternative="BMC for bug-finding, k-induction for unbounded proofs. Interpolation would enable automatic invariant generation.",
            lean_theorem_ref="Interpolation.craig_interpolation_sound (Pythia/Hardware/Interpolation.lean, proved 1c3b7dc)",
        ),
    ],
    "assume_guarantee": [
        FormalCapability(
            name="Assume-guarantee reasoning",
            supported=True,
            ebmc_mechanism="assume property (...) in SVA",
            limitations="Assumptions are trusted, not verified. Vacuity check recommended.",
            lean_theorem_ref=None,
        ),
    ],
}

_KEYWORD_MAP: dict[str, list[str]] = {
    "uninterpreted": ["uninterpreted_functions"],
    "uf": ["uninterpreted_functions"],
    "burch": ["burch_dill", "uninterpreted_functions"],
    "dill": ["burch_dill", "uninterpreted_functions"],
    "flushing": ["burch_dill"],
    "bmc": ["bmc"],
    "bounded": ["bmc"],
    "induction": ["k_induction"],
    "k-induction": ["k_induction"],
    "kinduction": ["k_induction"],
    "cegar": ["cegar"],
    "abstraction": ["cegar", "uninterpreted_functions"],
    "equivalence": ["equivalence_checking"],
    "miter": ["equivalence_checking"],
    "assume": ["assume_guarantee"],
    "guarantee": ["assume_guarantee"],
    "compositional": ["assume_guarantee"],
    "interpolation": ["interpolation"],
    "craig": ["interpolation"],
    "pipeline": ["burch_dill", "k_induction"],
    "pipelined": ["burch_dill", "k_induction"],
    "processor": ["burch_dill"],
    "depth": ["bmc"],
    "counterexample": ["bmc"],
    "state": ["burch_dill", "assume_guarantee"],
    "mapping": ["burch_dill"],
    "refinement": ["burch_dill"],
    "commit": ["burch_dill"],
    "spec": ["burch_dill", "equivalence_checking"],
    "implementation": ["burch_dill", "equivalence_checking"],
    "risc": ["burch_dill", "bmc", "k_induction"],
    "verify": ["bmc", "k_induction", "equivalence_checking"],
    "proof": ["k_induction", "bmc"],
    "formal": ["bmc", "k_induction", "cegar"],
    "invariant": ["k_induction", "assume_guarantee"],
    "bridge": ["assume_guarantee", "k_induction"],
    "abstract": ["cegar", "uninterpreted_functions"],
    "alu": ["uninterpreted_functions"],
    "datapath": ["uninterpreted_functions", "burch_dill"],
    "sound": ["bmc", "k_induction", "cegar"],
}


def formal_explore(query: str) -> FormalExploreResult:
    """Answer a formal verification capability question."""
    if not query:
        return FormalExploreResult(
            query=query or "",
            capabilities=[],
            summary="No query provided. Try asking about: BMC, k-induction, CEGAR, equivalence checking, uninterpreted functions, Burch-Dill, interpolation, or assume-guarantee.",
            references=[],
        )
    query_lower = query.lower()

    matched_topics: set[str] = set()
    for keyword, topics in _KEYWORD_MAP.items():
        if keyword in query_lower:
            matched_topics.update(topics)

    if not matched_topics:
        return FormalExploreResult(
            query=query,
            capabilities=[],
            summary="No matching formal verification capabilities found for this query. Try asking about: BMC, k-induction, CEGAR, equivalence checking, uninterpreted functions, Burch-Dill, interpolation, or assume-guarantee.",
            references=[],
        )

    capabilities: list[FormalCapability] = []
    for topic in sorted(matched_topics):
        capabilities.extend(_CAPABILITY_DB.get(topic, []))

    supported = [c for c in capabilities if c.supported]
    unsupported = [c for c in capabilities if not c.supported]

    if unsupported and not supported:
        summary = f"Not directly supported in EBMC. {len(unsupported)} capability(ies) checked, all unavailable. See alternatives."
    elif supported and not unsupported:
        summary = f"Fully supported. {len(supported)} capability(ies) available in EBMC."
    elif supported and unsupported:
        summary = f"{len(supported)} supported, {len(unsupported)} not supported. See per-capability details."
    else:
        summary = "No matching capabilities found for this query."

    refs = []
    for c in capabilities:
        if c.lean_theorem_ref:
            refs.append(c.lean_theorem_ref)

    return FormalExploreResult(
        query=query,
        capabilities=capabilities,
        summary=summary,
        references=refs,
    )
