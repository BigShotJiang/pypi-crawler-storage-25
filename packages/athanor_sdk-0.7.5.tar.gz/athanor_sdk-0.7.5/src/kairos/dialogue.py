"""Rich agent dialogue — customers see proposer/reviewer/verifier live.

Color-coded by role, streamed in real time. The inter-agent reasoning
is what differentiates kairos. Not debug logging — a selling feature.

Usage:
    from kairos.dialogue import Dialogue
    d = Dialogue()
    d.proposer("I propose removing DV_FORCE_RAND — synthesis-irrelevant, saves ~3.5%")
    d.reviewer("SAFE — DV params have no synthesis effect")
    d.verifier("PROVED equivalent at k=1 (0.3s)")
    d.result("-5% area, formally verified")

    # Quiet mode (one-line summaries):
    d = Dialogue(quiet=True)
"""
from __future__ import annotations

import sys
from dataclasses import dataclass


_COLORS = {
    "proposer": "\033[94m",   # blue
    "reviewer": "\033[93m",   # yellow
    "verifier": "\033[92m",   # green
    "result":   "\033[96m",   # cyan
    "error":    "\033[91m",   # red
    "dim":      "\033[90m",   # gray
    "reset":    "\033[0m",
    "bold":     "\033[1m",
}

_NO_COLOR = {k: "" for k in _COLORS}


def _supports_color() -> bool:
    if not hasattr(sys.stdout, "isatty"):
        return False
    return sys.stdout.isatty()


@dataclass
class DialogueEntry:
    role: str
    agent_id: str
    message: str


class Dialogue:
    """Streaming agent dialogue with color-coded roles."""

    def __init__(self, *, quiet: bool = False, color: bool | None = None):
        self.quiet = quiet
        self.entries: list[DialogueEntry] = []
        if color is None:
            self._c = _COLORS if _supports_color() else _NO_COLOR
        else:
            self._c = _COLORS if color else _NO_COLOR

    def _emit(self, role: str, agent_id: str, message: str) -> None:
        self.entries.append(DialogueEntry(role=role, agent_id=agent_id, message=message))
        if self.quiet:
            return
        c = self._c
        color = c.get(role, c["reset"])
        tag = f"{c['bold']}{color}[{role}]{c['reset']}"
        if agent_id:
            tag = f"{c['bold']}{color}[{role}-{agent_id}]{c['reset']}"
        print(f"{tag} {message}", flush=True)

    def proposer(self, message: str, *, agent_id: str = "") -> None:
        self._emit("proposer", agent_id, message)

    def reviewer(self, message: str, *, agent_id: str = "") -> None:
        self._emit("reviewer", agent_id, message)

    def verifier(self, message: str, *, agent_id: str = "") -> None:
        self._emit("verifier", agent_id, message)

    def result(self, message: str) -> None:
        self._emit("result", "", message)

    def error(self, message: str) -> None:
        self._emit("error", "", message)

    def phase(self, message: str) -> None:
        if self.quiet:
            return
        c = self._c
        print(f"\n{c['bold']}{c['dim']}── {message} ──{c['reset']}", flush=True)

    def summary(self) -> str:
        """One-line summary for quiet mode or logging."""
        proposers = [e for e in self.entries if e.role == "proposer"]
        results = [e for e in self.entries if e.role == "result"]
        if results:
            return results[-1].message
        if proposers:
            return f"{len(proposers)} proposals generated"
        return "no dialogue recorded"

    def format_plain(self) -> str:
        """Plain text (no color) for logs and reports."""
        lines = []
        for e in self.entries:
            tag = f"[{e.role}]" if not e.agent_id else f"[{e.role}-{e.agent_id}]"
            lines.append(f"{tag} {e.message}")
        return "\n".join(lines)
