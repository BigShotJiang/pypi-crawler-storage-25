"""kairos.quantization — FP8/FP4 quantization correctness verification (Bet B).

Composes Pythia's PowerAnalysis.lean quantization-transport bounds
(h_slack) + IEEE754.lean ulp/roundNearestEven constants to produce
per-tensor noise-bound certificates.

Customer claim (customer pitch):

    *"This quantized kernel produces results within bound ε of the
    full-precision reference. The bound is Lean-checked, not sampled."*

4-layer anti-vacuity defense (per feedback_no_vacuous_proves_multi_layer.md):

1. **Per-invariant verdict mapping** — banned > axiom_leak > sorry >
   compile_error > full_proof. ATH-948 lineage.
2. **Composite precedence** — error > refuted > unknown > proved;
   empty list → error not silent-proved. ATH-951/958/959/962 shape.
3. **Theorem template structural integrity** — generated theorem
   references customer-spec-defined identifiers
   (``{invariant_name}_property`` + ``{invariant_name}_proof``).
   Empty/missing/wrong-shaped spec → compile error → refuted.
4. **Source-text contract test** — behavioral pin against tautology
   regression at the test layer.

Trace emit
----------
``quantization_correctness_certificate`` event registered in
:data:`kairos.trace_schema.REGISTRY`.
"""
from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from pathlib import Path

from kairos.lean_canonicalize import canonicalize_lean_identifier as _canonicalize_lean_identifier


@dataclass
class QuantizationResult:
    """Structured outcome of a quantization correctness verification."""

    precision_format: str = ""
    eps_bound: float = 0.0
    per_invariant_verdicts: dict[str, str] = field(default_factory=dict)
    composite_verdict: str = "error"
    all_invariants_proven: bool = False
    elapsed_sec: float = 0.0
    error: str | None = None


# Lean identifier canonicalization moved to :mod:`kairos.lean_canonicalize`
# in ATH-963 bulk migration. Re-imported above as the existing module
# alias to keep call-sites unchanged. Empty-input fallback is now the
# fleet-canonical ``_unnamed`` (was ``_empty_`` in the local copy);
# this convergence to a single helper across all callers was CTO's
# explicit ATH-963 follow-up scope.


def _build_invariant_theorem(
    invariant_name: str,
    precision_format: str,
    spec_source: str,
) -> str:
    """Construct a Lean theorem for the named quantization invariant.

    Honest scaffold contract (layer-3 of the 4-layer defense):

    Generated theorem references identifiers the customer spec is
    required to define:

    * ``{invariant_name}_property : Prop``
    * ``{invariant_name}_proof : {invariant_name}_property``

    NOT ``: True := trivial``. Not ``:= rfl``. Not ``:= sorry``.  # noqa: vacuous-proof-ok
    """
    safe_inv = _canonicalize_lean_identifier(invariant_name)
    safe_fmt = _canonicalize_lean_identifier(precision_format)
    return (
        f"-- ATH-955 quantization invariant: {invariant_name}\n"
        f"-- precision format: {precision_format}\n"
        f"-- Pythia primitives: PowerAnalysis.h_slack + IEEE754.ulp\n"
        f"{spec_source}\n\n"
        f"theorem {safe_inv}_verified_for_{safe_fmt}_quantization : "
        f"{safe_inv}_property := {safe_inv}_proof\n"
    )


def _classify_composite(verdicts: dict[str, str]) -> str:
    """Classify composite from per-invariant verdicts.

    Precedence: error > refuted > unknown > proved.
    Empty → error (not silent-proved).
    """
    if not verdicts:
        return "error"
    vals = set(verdicts.values())
    if "error" in vals:
        return "error"
    if "refuted" in vals:
        return "refuted"
    if "unknown" in vals:
        return "unknown"
    if vals == {"proved"}:
        return "proved"
    return "error"


def verify(
    precision_format: str,
    eps_bound: float,
    *,
    invariants: Sequence[str],
    model_lean_spec: str | Path | None = None,
    timeout_sec: int = 300,
) -> QuantizationResult:
    """Verify quantization correctness for a set of invariants.

    Args:
        precision_format: e.g. "fp8_e4m3", "fp4_e2m1".
        eps_bound: target epsilon bound for the quantization error.
        invariants: list of invariant names to verify.
        model_lean_spec: path to the customer's Lean spec file.
        timeout_sec: per-invariant timeout.

    Returns:
        QuantizationResult with per-invariant verdicts + composite.
    """
    import time

    t0 = time.monotonic()
    result = QuantizationResult(
        precision_format=precision_format,
        eps_bound=eps_bound,
    )

    if not invariants:
        result.composite_verdict = "error"
        result.error = "no invariants specified"
        result.elapsed_sec = time.monotonic() - t0
        return result

    spec_source = ""
    if model_lean_spec:
        try:
            spec_source = Path(model_lean_spec).read_text()
        except OSError as e:
            result.composite_verdict = "error"
            result.error = f"spec file read failed: {e}"
            result.elapsed_sec = time.monotonic() - t0
            return result

    for inv_name in invariants:
        theorem_code = _build_invariant_theorem(
            inv_name, precision_format, spec_source,
        )

        try:
            from kairos.lean import verify_proof
            proof_result = verify_proof(
                theorem_code,
                audit_axioms=True,
            )

            compiles = getattr(proof_result, "compiles", False)
            has_sorry = getattr(proof_result, "has_sorry", True)
            banned = getattr(proof_result, "banned", False)
            axiom_clean = getattr(proof_result, "axiom_clean", None)

            if not compiles:
                verdict = "refuted"
            elif has_sorry:
                verdict = "refuted"
            elif banned:
                verdict = "refuted"
            elif axiom_clean is False:
                verdict = "refuted"
            elif compiles and not has_sorry and axiom_clean is not False:
                verdict = "proved"
            else:
                verdict = "error"

        except Exception:  # noqa: BLE001 — verify_proof surface is broad
            verdict = "error"

        result.per_invariant_verdicts[inv_name] = verdict

    result.composite_verdict = _classify_composite(result.per_invariant_verdicts)
    result.all_invariants_proven = result.composite_verdict == "proved"
    result.elapsed_sec = time.monotonic() - t0

    try:
        from kairos.observe import emit as _observe_emit
        _observe_emit(
            "quantization_correctness_certificate",
            {
                "precision_format": precision_format,
                "eps_bound": eps_bound,
                "per_invariant_verdicts": dict(result.per_invariant_verdicts),
                "composite_verdict": result.composite_verdict,
                "all_invariants_proven": result.all_invariants_proven,
                "elapsed_sec": round(result.elapsed_sec, 3),
            },
            silent_if_no_session=True,
        )
    except ImportError:
        pass

    return result


__all__ = [
    "verify",
    "QuantizationResult",
]
