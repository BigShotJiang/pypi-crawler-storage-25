"""kairos.certify — LLM-defensive certification surface for base SDK proofs.

Per the 2026-04-26 kairos-vs-pythia split with CTO:
pythia ships the engine (Lean library + Lean tactics + axiom audits);
kairos ships the dashboard (customer-facing orchestration). This
package is the kairos side of the ATH-718 Layer-3 work.

## Sub-modules

- `nl_roundtrip` (ATH-722): Lean term → English summary via BYO-LLM,
  with optional drift report against the customer's original hypothesis.
- `pythia_tactics` (ATH-723, pending): thin `lake build` wrappers that
  invoke the Pythia-side meta-tactics (`disprove`, `#validate_invoked_lemmas`,
  `#flag_concrete_constants`, `#minimize_hypotheses`, `#validate_types`)
  and parse their structured output.

The composite `kairos certify` CLI (ATH-719) aggregates these into the
8-check audit emitted to `~/.athanor/audit.jsonl`.

## Base SDK coupling fence

This package MUST NOT import from `kairos.fleet`, `kairos.prove`,
`kairos.sv.cegar`, `kairos.sv.swarm`, `kairos.sv.multi`, or
`kairos.sv.invariants` — those are paid-tier and base SDK callers
must remain decoupled. Verified by `tests/test_simple_prove.py`'s
import-independence regression class.
"""
from __future__ import annotations

from kairos.certify.nl_roundtrip import RoundtripResult, summarize

__all__ = ["RoundtripResult", "summarize"]
