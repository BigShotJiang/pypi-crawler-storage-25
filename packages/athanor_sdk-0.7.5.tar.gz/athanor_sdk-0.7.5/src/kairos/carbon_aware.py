"""kairos.carbon_aware — power-envelope + carbon-cost verifier (Bet I).

ATH-965. Composes on existing :mod:`Pythia.PowerAnalysis` Type-II
power-loss bounds + Pythia matrix-concentration primitives +
:func:`kairos.lean.verify_proof` to surface the customer claim:

    *"Your training job's carbon cost is provably within ε of the
    energy-accuracy Pareto-frontier."*

Architecture (now-canonical template across the vertical orchestrators)
-----------------------------------------------------------------------
Same shape as silicon_review / model_invariants / sparsity / security
/ inference_serving. Thin compose-existing-primitives only.

6-layer vacuous-proves defense
------------------------------
Per ``feedback_no_vacuous_proves_multi_layer.md``:

1. Per-invariant verdict mapping (banned > axiom_clean=False > sorry
   > compile_error > full_proof). ATH-948 lineage.
2. Composite precedence (error > refuted > unknown > proved; empty
   list → error not silent-proved).
3. Theorem template references customer-spec
   ``{invariant_name}_property`` + ``{invariant_name}_proof``.
4. Source-text + behavioral pins.
5. (ATH-960 cross-cutting CI lint, CTO).
6. Property-handle ``bool(subset) and all(...)`` guard against
   Python's ``all([]) == True`` silent-success.

Plus dot-aware identifier canonicalization (ATH-961/963 pattern).

Trace event
-----------
``carbon_aware_verify_complete`` registered in
:data:`kairos.trace_schema.REGISTRY` per ATH-932. Walker-visible emit.

Cross-ref
---------
* ``Pythia.PowerAnalysis`` — Type-II power-loss bound (h_slack).
* ``Pythia.MatrixBernstein`` — concentration over batch power draw.
* :func:`kairos.lean.verify_proof` — per-invariant proof checker.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

from kairos.lean_canonicalize import canonicalize_lean_identifier as _canonicalize_lean_identifier


KNOWN_SCHEDULE_POLICIES = (
    "fixed",                    # constant power envelope
    "carbon_aware_pareto",      # carbon-grid-aware scheduling
    "thermal_throttle",         # back off when thermals approach limit
    "spot_aware",               # AWS spot-pricing-aware
    "renewable_first",          # only schedule on renewable-grid windows
)


KNOWN_INVARIANT_KINDS = (
    "power_envelope_bounded",            # P(t) ≤ TDP for all t
    "energy_accuracy_pareto_frontier",   # schedule is Pareto-optimal vs accuracy
    "carbon_cost_bounded",               # ∫ carbon_intensity(t)·P(t) dt ≤ ε
    "thermal_safe",                      # T(t) ≤ T_max for all t
    "throttle_correctness",              # throttle decisions provably preserve invariants
)


# Lean identifier canonicalization moved to :mod:`kairos.lean_canonicalize`
# in ATH-963 bulk migration. Re-imported below as the existing module
# alias to keep call-sites unchanged.


@dataclass
class InvariantOutcome:
    invariant_name: str
    verdict: str
    proof_artifact_path: Path | None = None
    elapsed_sec: float = 0.0
    error_message: str | None = None
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class CarbonAwareResult:
    schedule_policy: str
    composite_verdict: str
    """``"proved" / "refuted" / "unknown" / "error"``."""

    power_envelope_safe: bool
    """True iff every power-class invariant returned ``proved``.
    bool(...) guard against Python all([]) silent-True."""

    carbon_efficient: bool
    """True iff every carbon / Pareto-class invariant returned
    ``proved``. Same bool(...) guard."""

    all_invariants_proven: bool
    invariant_outcomes: list[InvariantOutcome] = field(default_factory=list)
    total_elapsed_sec: float = 0.0
    error_message: str | None = None

    @property
    def proved_invariants(self) -> list[str]:
        return [o.invariant_name for o in self.invariant_outcomes if o.verdict == "proved"]

    @property
    def failed_invariants(self) -> list[str]:
        return [o.invariant_name for o in self.invariant_outcomes if o.verdict != "proved"]


# Disjoint-concerns design (per CTO 2026-05-03 ATH-964/966 review):
# property handles must NOT lump unrelated invariants into the same
# customer claim. `throttle_correctness` is control-loop correctness
# (a system-design invariant), NOT a power-envelope claim. A customer
# who enumerates only `throttle_correctness` and gets it proved must
# NOT see `power_envelope_safe=True` — that would over-credit the
# claim. Same disjoint-concerns pattern as ATH-962 security's
# `timing_safe` vs `no_cache_leak` (and the mistake ATH-966 fixes
# in inference_serving).
_POWER_INVARIANT_NAMES = frozenset({
    "power_envelope_bounded",
    "thermal_safe",  # thermal limits directly drive power throttling
})

_CARBON_INVARIANT_NAMES = frozenset({
    "energy_accuracy_pareto_frontier",
    "carbon_cost_bounded",
})

# Invariants outside both handles (visible in invariant_outcomes but
# not collapsed into a property-handle bool):
# * throttle_correctness — control-loop correctness, separate concern.


def _classify_composite(
    outcomes: Sequence[InvariantOutcome],
) -> tuple[str, bool]:
    """Layer-2: precedence error > refuted > unknown > proved; empty → error."""
    if not outcomes:
        return "error", False
    verdicts = [o.verdict for o in outcomes]
    if any(v == "error" for v in verdicts):
        return "error", False
    if any(v == "refuted" for v in verdicts):
        return "refuted", False
    if any(v == "unknown" for v in verdicts):
        return "unknown", False
    if all(v == "proved" for v in verdicts):
        return "proved", True
    return "error", False


def _compute_property_handles(
    outcomes: Sequence[InvariantOutcome],
) -> tuple[bool, bool]:
    """Layer-6: bool(subset) and all(...) guard against all([]) silent-True."""
    power_outcomes = [
        o for o in outcomes if o.invariant_name in _POWER_INVARIANT_NAMES
    ]
    carbon_outcomes = [
        o for o in outcomes if o.invariant_name in _CARBON_INVARIANT_NAMES
    ]
    power_envelope_safe = bool(power_outcomes) and all(
        o.verdict == "proved" for o in power_outcomes
    )
    carbon_efficient = bool(carbon_outcomes) and all(
        o.verdict == "proved" for o in carbon_outcomes
    )
    return power_envelope_safe, carbon_efficient


def _build_invariant_theorem(
    invariant_name: str,
    schedule_policy: str,
    spec_source: str,
) -> str:
    """Layer-3 honest scaffold contract (no tautology; references
    customer-spec identifiers)."""
    safe_inv = _canonicalize_lean_identifier(invariant_name)
    safe_pol = _canonicalize_lean_identifier(schedule_policy)
    return (
        f"{spec_source}\n\n"
        f"-- ATH-965 carbon_aware invariant: {invariant_name} for "
        f"{schedule_policy} schedule.\n"
        f"-- Honest scaffold contract: the spec is required to define\n"
        f"--   {safe_inv}_property : Prop\n"
        f"--   {safe_inv}_proof : {safe_inv}_property\n"
        f"-- Empty / missing / wrong-shaped spec → compile error → refuted.\n"
        f"theorem {safe_inv}_verified_for_{safe_pol}_schedule : "
        f"{safe_inv}_property := {safe_inv}_proof\n"
    )


def verify(
    schedule_policy: str,
    *,
    invariants: Sequence[str],
    schedule_lean_spec: str | Path | None = None,
    workdir: str | Path,
    lake_project: str | Path | None = None,
    timeout_sec_per_invariant: int = 300,
    emit_trace: bool = True,
) -> CarbonAwareResult:
    """Verify carbon-aware scheduling invariants.

    Args:
        schedule_policy: see :data:`KNOWN_SCHEDULE_POLICIES`.
        invariants: see :data:`KNOWN_INVARIANT_KINDS`.
        schedule_lean_spec: customer's Lean spec defining property
            + proof identifiers.
        workdir / lake_project / timeout_sec_per_invariant /
        emit_trace: same shape as siblings.
    """
    workdir_path = Path(workdir).resolve()
    workdir_path.mkdir(parents=True, exist_ok=True)

    if not invariants:
        result = CarbonAwareResult(
            schedule_policy=schedule_policy,
            composite_verdict="error",
            power_envelope_safe=False,
            carbon_efficient=False,
            all_invariants_proven=False,
            error_message="no invariants enumerated — verify() requires ≥1",
        )
        if emit_trace:
            _emit_complete(result)
        return result

    spec_source = ""
    if schedule_lean_spec is not None:
        spec_path = Path(schedule_lean_spec).resolve()
        if not spec_path.exists():
            return CarbonAwareResult(
                schedule_policy=schedule_policy,
                composite_verdict="error",
                power_envelope_safe=False,
                carbon_efficient=False,
                all_invariants_proven=False,
                error_message=f"schedule_lean_spec does not exist: {spec_path}",
            )
        spec_source = spec_path.read_text()

    t0 = time.monotonic()
    outcomes: list[InvariantOutcome] = []

    try:
        from kairos.lean import verify_proof
    except Exception as e:  # noqa: BLE001
        result = CarbonAwareResult(
            schedule_policy=schedule_policy,
            composite_verdict="error",
            power_envelope_safe=False,
            carbon_efficient=False,
            all_invariants_proven=False,
            error_message=f"kairos.lean unavailable: {e}",
        )
        if emit_trace:
            _emit_complete(result)
        return result

    for inv_name in invariants:
        inv_t0 = time.monotonic()
        theorem_source = _build_invariant_theorem(
            invariant_name=inv_name,
            schedule_policy=schedule_policy,
            spec_source=spec_source,
        )
        try:
            proof_result = verify_proof(
                theorem_source,
                lake_project=lake_project,
                timeout=timeout_sec_per_invariant,
            )
        except Exception as e:  # noqa: BLE001
            outcomes.append(InvariantOutcome(
                invariant_name=inv_name,
                verdict="error",
                elapsed_sec=round(time.monotonic() - inv_t0, 3),
                error_message=f"verify_proof raised: {e}",
            ))
            continue

        if not proof_result.compiles:
            verdict = "refuted"
            err = (
                (proof_result.errors or [""])[0][:200]
                if proof_result.errors
                else "lean compile error"
            )
        elif proof_result.has_sorry:
            verdict = "refuted"
            err = "proof has sorry — incomplete"
        elif proof_result.banned:
            verdict = "refuted"
            err = f"banned construct: {proof_result.banned}"
        elif proof_result.axiom_clean is False:
            verdict = "refuted"
            err = (
                f"axiom leak: {list(proof_result.forbidden_axioms or [])[:3]}"
            )
        elif proof_result.score >= 1.0:
            verdict = "proved"
            err = None
        else:
            verdict = "error"
            err = (
                f"unexpected ProofResult shape: compiles=True, no sorry, "
                f"no banned, axiom_clean!=False, score={proof_result.score}"
            )

        outcomes.append(InvariantOutcome(
            invariant_name=inv_name,
            verdict=verdict,
            elapsed_sec=round(time.monotonic() - inv_t0, 3),
            error_message=err,
            details={
                "compiles": proof_result.compiles,
                "has_sorry": proof_result.has_sorry,
                "score": proof_result.score,
                "axiom_clean": proof_result.axiom_clean,
            },
        ))

    composite_verdict, all_proven = _classify_composite(outcomes)
    power_envelope_safe, carbon_efficient = _compute_property_handles(outcomes)
    total_elapsed = round(time.monotonic() - t0, 3)

    result = CarbonAwareResult(
        schedule_policy=schedule_policy,
        composite_verdict=composite_verdict,
        power_envelope_safe=power_envelope_safe,
        carbon_efficient=carbon_efficient,
        all_invariants_proven=all_proven,
        invariant_outcomes=outcomes,
        total_elapsed_sec=total_elapsed,
    )

    if emit_trace:
        _emit_complete(result)

    return result


def _emit_complete(result: CarbonAwareResult) -> None:
    try:
        from kairos.observe import emit
        emit(
            "carbon_aware_verify_complete",
            {
                "schedule_policy": result.schedule_policy,
                "composite_verdict": result.composite_verdict,
                "power_envelope_safe": result.power_envelope_safe,
                "carbon_efficient": result.carbon_efficient,
                "all_invariants_proven": result.all_invariants_proven,
                "invariants_proved": result.proved_invariants,
                "invariants_failed": result.failed_invariants,
                "total_elapsed_sec": result.total_elapsed_sec,
            },
        )
    except Exception:  # noqa: BLE001
        pass


__all__ = [
    "InvariantOutcome",
    "CarbonAwareResult",
    "KNOWN_SCHEDULE_POLICIES",
    "KNOWN_INVARIANT_KINDS",
    "verify",
]
