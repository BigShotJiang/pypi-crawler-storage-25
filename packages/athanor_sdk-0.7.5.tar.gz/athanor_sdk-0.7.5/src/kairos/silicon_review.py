"""kairos.silicon_review — pre-tape-out silicon assurance orchestrator.

ATH-951 (W1 anchor for ATH-950 Bet E). Composes existing primitives —
:mod:`kairos.pure_rtl.roundtrip` + :mod:`kairos.sv.ebmc` + :mod:`kairos.acl2`
— into a single orchestrator that produces a tape-out-ready verdict per
silicon block.

This is the customer-facing pitch artifact for the W4-W6 the customer
leadership demo: *"every block of your next chip ships with a
downloadable formal-correctness proof — Athanor pre-tape-out
verification pays for itself if it prevents ONE mask respin per
generation."*

Architecture
------------
Composes existing modules; no new verifier logic. Same orchestration
pattern as :func:`kairos.pure_rtl.roundtrip.run_roundtrip` (which
composes Clash codegen + EQY equivalence).

The composite ``tape_out_ready`` verdict requires ALL THREE engines to
return a sound verdict — matches the silent-success-failure-mode
discipline locked in ATH-948 + ATH-949. A "kernel-accepted" outcome
on any engine is not enough; the audit must pass.

Verdict precedence (top-to-bottom, fail-safe):

* Any engine returns ``error`` → composite ``error``.
* Any engine returns ``refuted`` → composite ``refuted``.
* Any engine returns ``unknown`` (timeout, inconclusive) → composite
  ``unknown``.
* All engines return ``proved`` (and the audit gates pass on each) →
  composite ``proved`` AND ``tape_out_ready=True``.

Trace emit
----------
``silicon_review_complete`` event registered in
:data:`kairos.trace_schema.REGISTRY` per ATH-932 emit-registry gate.
Payload carries per-engine verdict + composite verdict +
``tape_out_ready`` boolean + total elapsed.

Cross-ref
---------
* :mod:`kairos.pure_rtl.roundtrip` — Lean → Clash → SV → EQY equivalence.
* :mod:`kairos.sv.ebmc` — SystemVerilog BMC + k-induction.
* :mod:`kairos.acl2` — ACL2 + FGL refinement.
* docs/internal/pure-rtl-qa-harness-draft.md — qa-harness corpus spec.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence


@dataclass
class SiliconReviewResult:
    """Composite outcome from one silicon-review pass on a single block."""

    block_name: str
    composite_verdict: str
    """``"proved" / "refuted" / "unknown" / "error"``."""

    tape_out_ready: bool
    """True iff every engine returned ``proved`` with audit-clean status.
    THIS is the customer-facing claim customer leadership cares about."""

    pure_rtl_verdict: str | None
    """Verdict from :func:`kairos.pure_rtl.roundtrip.run_roundtrip`.
    ``None`` when run_pure_rtl=False."""

    ebmc_verdict: str | None
    """Verdict from EBMC (BMC or k-induction). ``None`` when
    run_ebmc=False."""

    acl2_verdict: str | None
    """Verdict from ACL2 / FGL refinement. ``None`` when run_acl2=False."""

    pure_rtl_details: dict[str, Any] = field(default_factory=dict)
    ebmc_details: dict[str, Any] = field(default_factory=dict)
    acl2_details: dict[str, Any] = field(default_factory=dict)

    total_elapsed_sec: float = 0.0
    error_message: str | None = None


def _classify_composite(
    verdicts: list[str | None],
) -> tuple[str, bool]:
    """Map per-engine verdicts → (composite_verdict, tape_out_ready).

    Precedence: error > refuted > unknown > proved. tape_out_ready is
    True iff every executed engine returned ``proved``. Engines with
    ``None`` (not run) are skipped.

    The defensive read: ANY engine declining or hitting an unknown
    verdict drops tape_out_ready to False. Same architecture-defense
    pattern as ATH-947 + ATH-948 + ATH-949.
    """
    executed = [v for v in verdicts if v is not None]
    if not executed:
        return "error", False
    if any(v == "error" for v in executed):
        return "error", False
    if any(v == "refuted" for v in executed):
        return "refuted", False
    if any(v == "unknown" for v in executed):
        return "unknown", False
    if all(v == "proved" for v in executed):
        return "proved", True
    # Mixed proved + something-else — should be caught by the
    # error/refuted/unknown branches above. If we reach here, an
    # unexpected verdict string was returned by an engine.
    return "error", False


def review(
    sv_file: str | Path,
    *,
    block_name: str,
    top_module: str,
    workdir: str | Path,
    lean_spec: str | Path | None = None,
    clash_hs_file: str | Path | None = None,
    customer_properties: Sequence[Any] = (),
    acl2_script: str | Path | None = None,
    run_pure_rtl: bool = True,
    run_ebmc: bool = True,
    run_acl2: bool = True,
    timeout_sec_pure_rtl: int = 1200,
    timeout_sec_ebmc: int = 600,
    timeout_sec_acl2: int = 600,
    ebmc_bound: int = 30,
    ebmc_mode: str = "k_induction",
    emit_trace: bool = True,
) -> SiliconReviewResult:
    """Run pre-tape-out silicon review on ``sv_file``.

    Requires paid license with 'solve' product access.

    Composes the three engines and returns a composite verdict. Every
    engine is optional (``run_*=False``) so customers can stage their
    review (e.g., run EBMC first as a fast-path, then add pure_rtl +
    acl2 once the design stabilises).

    Args:
        sv_file: path to the SystemVerilog block under review.
        block_name: human-readable name (e.g. ``"cpu_adder"``,
            ``"neuron_core_systolic"``). Stamped into trace + result.
        top_module: top-module name in ``sv_file``. Required for
            EBMC + pure_rtl.
        workdir: scratch directory for per-engine artifacts.
        lean_spec: path to Lean source-of-truth for pure_rtl. Required
            when ``run_pure_rtl=True``.
        clash_hs_file: path to Clash-Haskell bridge for pure_rtl.
            Required when ``run_pure_rtl=True``.
        customer_properties: list passed through to pure_rtl
            two-gate validation (Bet E doesn't strictly require these
            since silicon equivalence is the primary claim).
        acl2_script: path to ACL2 .lisp script. Required when
            ``run_acl2=True``.
        run_pure_rtl / run_ebmc / run_acl2: per-engine toggles.
        timeout_sec_*: per-engine wall-clock caps.
        ebmc_bound: BMC depth (passed to EBMC). Default 30.
        ebmc_mode: ``"bmc"`` or ``"k_induction"``. Default
            ``"k_induction"`` for unbounded proofs.
        emit_trace: when True (default), emit
            ``silicon_review_complete`` on completion.

    Returns:
        :class:`SiliconReviewResult`. Never raises for missing
        toolchain or per-engine failure — those surface as
        ``composite_verdict='error'`` / per-engine verdict.
    """
    from kairos.license_scope import require_product
    require_product("solve")
    sv_path = Path(sv_file).resolve()
    workdir_path = Path(workdir).resolve()
    workdir_path.mkdir(parents=True, exist_ok=True)

    if not sv_path.exists():
        return SiliconReviewResult(
            block_name=block_name,
            composite_verdict="error",
            tape_out_ready=False,
            pure_rtl_verdict=None,
            ebmc_verdict=None,
            acl2_verdict=None,
            error_message=f"sv_file does not exist: {sv_path}",
        )

    t0 = time.monotonic()
    pure_rtl_verdict: str | None = None
    ebmc_verdict: str | None = None
    acl2_verdict: str | None = None
    pure_rtl_details: dict[str, Any] = {}
    ebmc_details: dict[str, Any] = {}
    acl2_details: dict[str, Any] = {}

    # ── pure_rtl roundtrip ─────────────────────────────────────────
    if run_pure_rtl:
        if clash_hs_file is None:
            pure_rtl_verdict = "error"
            pure_rtl_details = {"error": "clash_hs_file required when run_pure_rtl=True"}
        else:
            try:
                from kairos.pure_rtl.roundtrip import run_roundtrip
                rt = run_roundtrip(
                    block_name=block_name,
                    clash_hs_file=clash_hs_file,
                    original_sv=sv_path,
                    top_module=top_module,
                    workdir=workdir_path / "pure_rtl",
                    timeout_sec_codegen=timeout_sec_pure_rtl // 2,
                    timeout_sec_equiv=timeout_sec_pure_rtl // 2,
                    emit_trace=False,
                )
                pure_rtl_verdict = rt.verdict
                pure_rtl_details = {
                    "codegen_success": rt.codegen.success,
                    "regenerated_sv": (
                        str(rt.regenerated_sv) if rt.regenerated_sv else None
                    ),
                    "elapsed_sec": rt.total_elapsed_sec,
                }
            except Exception as e:  # noqa: BLE001 — engine surfaces are broad
                pure_rtl_verdict = "error"
                pure_rtl_details = {"error": f"run_roundtrip raised: {e}"}

    # ── ebmc ───────────────────────────────────────────────────────
    if run_ebmc:
        try:
            from kairos.sv.ebmc import run_ebmc as _run_ebmc
            ebmc_res = _run_ebmc(
                sv_path,
                top_module=top_module,
                bound=ebmc_bound,
                mode=ebmc_mode,
                timeout_sec=timeout_sec_ebmc,
            )
            if ebmc_res.timed_out:
                ebmc_verdict = "unknown"
            elif ebmc_res.refuted > 0:
                ebmc_verdict = "refuted"
            elif ebmc_res.proved > 0 and ebmc_res.refuted == 0:
                ebmc_verdict = "proved"
            else:
                ebmc_verdict = "unknown"
            ebmc_details = {
                "proved": ebmc_res.proved,
                "refuted": ebmc_res.refuted,
                "timed_out": ebmc_res.timed_out,
                "elapsed_sec": ebmc_res.elapsed_sec,
                "exit_code": ebmc_res.exit_code,
            }
        except Exception as e:  # noqa: BLE001
            ebmc_verdict = "error"
            ebmc_details = {"error": f"run_ebmc raised: {e}"}

    # ── acl2 ───────────────────────────────────────────────────────
    if run_acl2:
        if acl2_script is None:
            acl2_verdict = "error"
            acl2_details = {"error": "acl2_script required when run_acl2=True"}
        else:
            try:
                from kairos.acl2 import (
                    ACL2Error, ACL2NotFoundError, ACL2TheoremRefuted,
                    verify as acl2_verify,
                )
                acl2_res = acl2_verify(
                    acl2_script,
                    timeout_sec=timeout_sec_acl2,
                )
                # acl2_verify raises on failure; if we got here, it
                # proved cleanly.
                acl2_verdict = "proved"
                acl2_details = {
                    "elapsed_sec": acl2_res.elapsed_sec,
                    "theorems_proved": list(acl2_res.theorems_proved or []),
                }
            except ACL2NotFoundError as e:
                acl2_verdict = "error"
                acl2_details = {"error": f"acl2 binary not installed: {e}"}
            except ACL2TheoremRefuted as e:
                # ATH-953: genuine refutation -- a named theorem failed
                # to prove. Customer reads "refuted" as "your block has
                # a bug"; the remediation is to fix the design.
                acl2_verdict = "refuted"
                acl2_details = {"error": str(e)}
            except ACL2Error as e:
                # ATH-953: script / kernel error -- the proof attempt
                # could not run (book not found, syntax error, kernel
                # timeout, no Q.E.D. reported). Customer reads "error"
                # as "your script can't load"; remediation is to fix
                # the script. NOT a design refutation.
                acl2_verdict = "error"
                acl2_details = {"error": str(e)}
            except Exception as e:  # noqa: BLE001
                acl2_verdict = "error"
                acl2_details = {"error": f"acl2 raised: {e}"}

    composite_verdict, tape_out_ready = _classify_composite(
        [pure_rtl_verdict, ebmc_verdict, acl2_verdict]
    )
    total_elapsed = round(time.monotonic() - t0, 3)

    result = SiliconReviewResult(
        block_name=block_name,
        composite_verdict=composite_verdict,
        tape_out_ready=tape_out_ready,
        pure_rtl_verdict=pure_rtl_verdict,
        ebmc_verdict=ebmc_verdict,
        acl2_verdict=acl2_verdict,
        pure_rtl_details=pure_rtl_details,
        ebmc_details=ebmc_details,
        acl2_details=acl2_details,
        total_elapsed_sec=total_elapsed,
    )

    if emit_trace:
        try:
            from kairos.observe import emit
            emit(
                "silicon_review_complete",
                {
                    "block_name": block_name,
                    "top_module": top_module,
                    "sv_file": str(sv_path),
                    "composite_verdict": composite_verdict,
                    "tape_out_ready": tape_out_ready,
                    "pure_rtl_verdict": pure_rtl_verdict,
                    "ebmc_verdict": ebmc_verdict,
                    "acl2_verdict": acl2_verdict,
                    "total_elapsed_sec": total_elapsed,
                },
            )
        except Exception:  # noqa: BLE001 — trace emit must never break review()
            pass

    return result


__all__ = ["SiliconReviewResult", "review"]
