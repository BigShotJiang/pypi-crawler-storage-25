"""Container preflight — verify a scoring container works before using it.

Catches broken containers early with clear error messages.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path

from kairos.security.env_allowlist import safe_env_for_cedar


def _find_docker() -> str:
    docker_bin = shutil.which("docker") or shutil.which("podman")
    if not docker_bin:
        raise RuntimeError("Docker or Podman required. Install Docker and try again.")
    return docker_bin


def preflight(image: str) -> dict:
    """Run preflight checks on a scoring container image.

    Checks:
      1. Image can be pulled / exists locally
      2. Python is present at /root/.venv/bin/python
      3. /root_data/eval/scoring.py (or .so) exists
      4. /root_data/eval/configs/ exists with at least one task
      5. /workdir/data/ exists
      6. Scoring runs on at least one task (smoke test)

    Returns:
        Dict with keys:
          - image: the image string
          - passed: bool, all checks passed
          - checks: list of {name, passed, message}
          - task_count: number of tasks discovered
    """
    docker_bin = _find_docker()
    checks = []

    def check(name: str, cmd: list[str], timeout: int = 30) -> tuple[bool, str]:
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=safe_env_for_cedar())
            if result.returncode == 0:
                return True, result.stdout.strip()[:300]
            return False, (result.stderr or result.stdout).strip()[:300]
        except subprocess.TimeoutExpired:
            return False, f"timeout after {timeout}s"
        except Exception as e:  # noqa: BLE001 — guard returns False on any error
            return False, str(e)[:300]

    # 1. Image exists / can be inspected
    ok, msg = check("image_inspect", [docker_bin, "image", "inspect", image], timeout=15)
    checks.append({"name": "Image available", "passed": ok, "message": msg if not ok else "ok"})
    if not ok:
        # Try pulling
        pull_ok, pull_msg = check("image_pull", [docker_bin, "pull", image], timeout=300)
        checks.append({"name": "Image pull", "passed": pull_ok, "message": pull_msg if not pull_ok else "pulled"})
        if not pull_ok:
            return {"image": image, "passed": False, "checks": checks, "task_count": 0}

    # 2. Python venv present
    ok, msg = check("python_venv", [
        docker_bin, "run", "--rm", "--user", "root", image,
        "test", "-x", "/root/.venv/bin/python",
    ])
    checks.append({"name": "Python venv", "passed": ok, "message": "/root/.venv/bin/python exists" if ok else msg})

    # 3. scoring.py or scoring.so
    ok, msg = check("scoring_script", [
        docker_bin, "run", "--rm", "--user", "root", image,
        "bash", "-c", "ls /root_data/eval/scoring.py /root_data/eval/scoring.cpython*.so 2>/dev/null | head -1",
    ])
    has_scoring = bool(msg.strip()) if ok else False
    checks.append({"name": "Scoring script", "passed": has_scoring, "message": msg if has_scoring else "scoring.py/.so not found"})

    # 4. Task configs
    ok, msg = check("task_configs", [
        docker_bin, "run", "--rm", "--user", "root", image,
        "bash", "-c", "ls /root_data/eval/configs/*.json 2>/dev/null | wc -l",
    ])
    task_count = 0
    if ok:
        try:
            task_count = int(msg.strip())
        except ValueError:
            task_count = 0
    has_tasks = task_count > 0
    checks.append({"name": "Task configs", "passed": has_tasks, "message": f"{task_count} task configs"})

    # 5. /workdir/data writable
    ok, msg = check("workdir", [
        docker_bin, "run", "--rm", "--user", "root", image,
        "test", "-d", "/workdir/data",
    ])
    checks.append({"name": "Workdir", "passed": ok, "message": "/workdir/data exists" if ok else msg})

    # 6. Shim re-export — the Cython-compiled scoring module must expose
    #    its public API through the shim. If _compile_eval.py didn't
    #    generate the `from _scoring_impl import *` line, the shim is
    #    empty and every task silently scores 0.
    shim_ok = False
    shim_msg = "skipped"
    if has_scoring:
        shim_result = subprocess.run(
            [docker_bin, "run", "--rm", "--user", "root", image, "bash", "-c",
             "/root/.venv/bin/python -c \""
             "import sys; sys.path.insert(0, '/root_data/eval'); "
             "import scoring; syms = [s for s in dir(scoring) if not s.startswith('_')]; "
             "print(len(syms))\""],
            capture_output=True, text=True, timeout=30, env=safe_env_for_cedar(),
        )
        if shim_result.returncode == 0:
            try:
                sym_count = int(shim_result.stdout.strip())
                shim_ok = sym_count >= 3
                shim_msg = f"{sym_count} public symbols" if shim_ok else f"only {sym_count} symbols (shim broken?)"
            except ValueError:
                shim_msg = "could not parse symbol count"
        else:
            shim_msg = (shim_result.stderr or shim_result.stdout).strip()[:200]
    checks.append({"name": "Shim re-export", "passed": shim_ok, "message": shim_msg})

    # 7. Reward-leak probe — run scoring on ALL tasks using the
    #    container's built-in pristine student_data (no volume mount on
    #    /workdir/data). Every task MUST score exactly 0.0. A non-zero
    #    score means an RL agent submitting nothing gets free reward.
    leak_ok = False
    leak_msg = "skipped"
    if has_tasks and shim_ok:
        # List all task slugs
        slug_result = subprocess.run(
            [docker_bin, "run", "--rm", "--user", "root", image, "bash", "-c",
             "ls /root_data/eval/configs/*.json 2>/dev/null "
             "| xargs -n1 basename | sed 's/.json$//'"],
            capture_output=True, text=True, timeout=15, env=safe_env_for_cedar(),
        )
        slugs = [s.strip() for s in slug_result.stdout.strip().splitlines() if s.strip()]
        leaked = []
        scored = 0
        for slug in slugs:
            # Run scoring without mounting anything — uses container's
            # built-in /workdir/data (pristine stubs).
            score_result = subprocess.run(
                [docker_bin, "run", "--rm", "--user", "root",
                 "--network=none", "--memory=4g",
                 "--cap-drop=ALL", "--cap-add=SETUID", "--cap-add=SETGID",
                 image, "bash", "-c",
                 f"/root/.venv/bin/python /root_data/eval/scoring.py "
                 f"/root_data/eval/configs/{slug}.json /tmp/score.json 2>/dev/null; "
                 f"cat /tmp/score.json 2>/dev/null || echo '{{}}'"],
                capture_output=True, text=True, timeout=120, env=safe_env_for_cedar(),
            )
            stdout = score_result.stdout.strip()
            json_start = stdout.find("{")
            if json_start >= 0:
                try:
                    data = json.loads(stdout[json_start:])
                    score = data.get("score", 0.0)
                    scored += 1
                    if score is not None and score > 0:
                        leaked.append((slug, score))
                except json.JSONDecodeError:
                    pass  # count as not-scored, not leaked
        if scored == 0:
            leak_msg = "no tasks scored successfully"
        elif leaked:
            leak_msg = f"LEAK: {len(leaked)}/{scored} tasks scored >0 on pristine stubs"
            for slug, score in leaked[:3]:
                leak_msg += f"\n  {slug}: {score}"
        else:
            leak_ok = True
            leak_msg = f"{scored}/{len(slugs)} pristine stubs scored 0.0"
    checks.append({"name": "Reward-leak probe", "passed": leak_ok, "message": leak_msg})

    passed = all(c["passed"] for c in checks)
    return {
        "image": image,
        "passed": passed,
        "checks": checks,
        "task_count": task_count,
    }



__all__ = [
    "preflight",
    # ATH-737 fleet hard-gate.
    "fleet_gate", "FleetGateResult", "PreflightFailure", "PreflightSkipped",
    "DEFAULT_SMOKE_THEOREM", "DEFAULT_TOKEN_PATH", "DEFAULT_MAX_AGE_SECONDS",
]


# ─────────────────────────────────────────────────────────────────────
# ATH-737 fleet preflight hard-gate.
#
# Inlined here (rather than a separate module) because the SDK IP
# detector flags imports from underscore-prefixed modules in the
# public plugin surface. Public API stays unchanged:
# `from kairos.preflight import fleet_gate, FleetGateResult,
# PreflightFailure, PreflightSkipped`.
# ─────────────────────────────────────────────────────────────────────

import logging
import os
import time
from dataclasses import asdict, dataclass, field
from typing import Any, Optional, Sequence


_logger = logging.getLogger(__name__)


# Generic Lean 4 + Mathlib proof that any project with Mathlib in its
# import set can build. Used as the verify round-trip target when the
# caller doesn't supply their own. `linarith` is the cheapest tactic
# that exercises real elaboration — `rfl` would short-circuit too early
# to catch most lake-build issues.
DEFAULT_SMOKE_THEOREM = "example : (0 : ℝ) ≤ 1 := by linarith"
DEFAULT_TOKEN_PATH = "~/.kairos/preflight_pass.json"
DEFAULT_MAX_AGE_SECONDS = 600
DEFAULT_SMOKE_PROMPT = (
    "Reply with exactly one word: PING. No other content, no markdown."
)

# Env vars whose presence (NOT value) we snapshot in the token. Names
# carrying secrets get logged as `<name>=<set|unset>` only.
_ENV_VARS_TO_SNAPSHOT = (
    # Provider keys (presence-only).
    "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GEMINI_API_KEY",
    "GOOGLE_API_KEY", "AZURE_API_KEY", "AZURE_OPENAI_API_KEY",
    "ANTHROPIC_BASE_URL", "OPENAI_API_BASE", "AZURE_API_BASE",
    # Athanor knobs (full value, no secrets here).
    "KAIROS_TRACE_SINK", "ATHANOR_SYNC_TOKEN",
    "ATHANOR_TRACE_URL", "KAIROS_OFFLINE",
    "KAIROS_FLEET_NO_PREFLIGHT",
)


class PreflightFailure(RuntimeError):
    """Raised when fleet_gate cannot return a passing token. The
    `failures` attribute carries the structured per-check failure list
    so a caller's exception handler can act on the field-mismatch
    rather than a string."""
    def __init__(self, failures: list[dict]) -> None:
        self.failures = list(failures)
        msg = "fleet_gate: {} check(s) failed: {}".format(
            len(failures),
            "; ".join(
                f"{f.get('check', '?')}={f.get('reason', '?')}"
                for f in failures[:5]
            ),
        )
        super().__init__(msg)


class PreflightSkipped(UserWarning):
    """Issued when a caller bypasses fleet_gate via
    ``KAIROS_FLEET_NO_PREFLIGHT=1`` or ``allow_skip=True``. Loud by
    design — every call site that spends customer money downstream
    of a skipped gate emits this so the run log states `gate=SKIPPED`
    instead of leaving it implicit."""


@dataclass
class _ClientCheck:
    model_id: str
    passed: bool
    reason: Optional[str]
    completion_tokens: int = 0
    elapsed_seconds: float = 0.0


@dataclass
class _VerifyCheck:
    lake_project: Optional[str]
    module_path: Optional[str]
    passed: bool
    reason: Optional[str]
    elapsed_seconds: float = 0.0


@dataclass
class FleetGateResult:
    """Outcome of one ``fleet_gate`` invocation. ``passed=True`` iff
    every drafter smoke succeeded, the verify round-trip closed, and
    the token was written.

    Always produced — even on failure. Callers that want a hard error
    raise ``PreflightFailure(result.failures)`` from the False
    branch; ``fleet_gate`` does not raise from happy-path code."""
    passed: bool
    drafter_checks: list[_ClientCheck]
    verify_check: Optional[_VerifyCheck]
    env_snapshot: dict[str, str]
    fleet_id: str
    tested_at: float
    token_path: Optional[str]
    failures: list[dict] = field(default_factory=list)
    skipped: bool = False
    skipped_reason: Optional[str] = None

    @property
    def token(self) -> dict:
        """Serializable snapshot suitable for writing to the token
        JSON. Same shape the research-VM ``~/bin/preflight-gate.sh``
        Claude Code hook checks."""
        return {
            "fleet_id": self.fleet_id,
            "tested_at": self.tested_at,
            "passed": self.passed,
            "drafters": [asdict(c) for c in self.drafter_checks],
            "verify_ok": (
                self.verify_check.passed
                if self.verify_check is not None else None
            ),
            "env_snapshot": dict(self.env_snapshot),
            "failures": list(self.failures),
        }


def _snapshot_env() -> dict[str, str]:
    """Capture a shape-only env-var posture: presence for keys, full
    value for non-secret knobs. Never logs the value of any *_API_KEY
    or *_BASE_URL."""
    snap: dict[str, str] = {}
    for name in _ENV_VARS_TO_SNAPSHOT:
        val = os.environ.get(name)
        is_secret = name.endswith("_API_KEY") or name.endswith("_BASE_URL") or "TOKEN" in name
        if is_secret:
            snap[name] = "set" if val else "unset"
        else:
            snap[name] = val if val is not None else "unset"
    return snap


def _smoke_one_client(
    client: Any, *, smoke_prompt: str, max_tokens: int,
) -> _ClientCheck:
    """1-call smoke: dispatch a tiny prompt, assert the response has
    `.content` (not `.text`), `.error is None`, and a positive
    `completion_tokens`. Captures the actual fields when an assertion
    fails so the caller's PreflightFailure names the mismatch."""
    model_id = getattr(client, "model_id", None) or getattr(client, "model", "<unknown>")
    t0 = time.time()
    try:
        messages = client.format_messages(
            "You are a smoke-test responder.", smoke_prompt,
        ) if hasattr(client, "format_messages") else [
            {"role": "system", "content": "You are a smoke-test responder."},
            {"role": "user", "content": smoke_prompt},
        ]
        resp = client.call(
            messages=messages,
            temperature=0.0,
            max_tokens=max_tokens,
        )
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return _ClientCheck(
            model_id=model_id, passed=False,
            reason=f"client.call raised {type(e).__name__}: {e!s:.200}",
            elapsed_seconds=time.time() - t0,
        )

    if not hasattr(resp, "content"):
        actual_attrs = sorted(a for a in dir(resp) if not a.startswith("_"))[:8]
        return _ClientCheck(
            model_id=model_id, passed=False,
            reason=(
                f"response has no .content attribute; saw "
                f"{actual_attrs!r}. Did the adapter return a different "
                f"shape (e.g. .text)?"
            ),
            elapsed_seconds=time.time() - t0,
        )

    content = getattr(resp, "content", None)
    err = getattr(resp, "error", None)
    completion_tokens = int(getattr(resp, "completion_tokens", 0) or 0)
    elapsed = time.time() - t0

    if err is not None:
        return _ClientCheck(
            model_id=model_id, passed=False,
            reason=f"response.error: {err!s:.200}",
            completion_tokens=completion_tokens, elapsed_seconds=elapsed,
        )
    if completion_tokens <= 0:
        return _ClientCheck(
            model_id=model_id, passed=False,
            reason=(
                f"completion_tokens={completion_tokens} (expected > 0; "
                f"may indicate a reasoning model burned its budget on "
                f"reasoning_content — see ATH-740)"
            ),
            completion_tokens=completion_tokens, elapsed_seconds=elapsed,
        )
    if content is None or not str(content).strip():
        return _ClientCheck(
            model_id=model_id, passed=False,
            reason=(
                f"content was None/empty (completion_tokens={completion_tokens}, "
                f"reasoning_content_len={len(getattr(resp, 'reasoning_content', None) or '')}). "
                f"Reasoning model may need a higher max_tokens; see Kimi K2.5 reasoning floor."
            ),
            completion_tokens=completion_tokens, elapsed_seconds=elapsed,
        )

    return _ClientCheck(
        model_id=model_id, passed=True, reason=None,
        completion_tokens=completion_tokens, elapsed_seconds=elapsed,
    )


def _verify_round_trip(
    *, smoke_theorem: str, lake_project: Optional[str],
    module_path: Optional[str], timeout_seconds: int,
) -> _VerifyCheck:
    """Verify a known-good Lean proof closes against the customer's
    project. Catches lake-build issues (missing imports, wrong
    Mathlib pin, proofwidgets cache miss) before the main loop.

    When ``lake_project`` is None the round-trip is skipped — the
    caller is exercising the gate on the LLM smoke alone. Returned
    ``passed=True`` with ``reason='skipped'`` in that case so the
    token shape is uniform."""
    if lake_project is None:
        return _VerifyCheck(
            lake_project=None, module_path=None,
            passed=True, reason="skipped (no lake_project provided)",
        )
    if module_path is None:
        return _VerifyCheck(
            lake_project=str(lake_project), module_path=None,
            passed=False, reason="lake_project given but module_path missing",
        )
    try:
        from kairos.lean import verify_proof
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return _VerifyCheck(
            lake_project=str(lake_project), module_path=module_path,
            passed=False,
            reason=f"kairos.lean import failed: {type(e).__name__}: {e}",
        )

    t0 = time.time()
    try:
        result = verify_proof(
            smoke_theorem,
            lake_project=str(lake_project),
            module_path=module_path,
            timeout=timeout_seconds,
        )
    except Exception as e:  # noqa: BLE001 — guard returns fallback value on any error
        return _VerifyCheck(
            lake_project=str(lake_project), module_path=module_path,
            passed=False,
            reason=f"verify_proof raised {type(e).__name__}: {e!s:.200}",
            elapsed_seconds=time.time() - t0,
        )
    elapsed = time.time() - t0
    if not getattr(result, "compiles", False):
        errs = "; ".join((getattr(result, "errors", []) or [])[:3])
        return _VerifyCheck(
            lake_project=str(lake_project), module_path=module_path,
            passed=False,
            reason=f"verify_proof did not compile: {errs[:300]}",
            elapsed_seconds=elapsed,
        )
    if getattr(result, "has_sorry", False):
        return _VerifyCheck(
            lake_project=str(lake_project), module_path=module_path,
            passed=False, reason="verify_proof closed but has_sorry=True",
            elapsed_seconds=elapsed,
        )
    return _VerifyCheck(
        lake_project=str(lake_project), module_path=module_path,
        passed=True, reason=None, elapsed_seconds=elapsed,
    )


def _read_token(path: Path) -> Optional[dict]:
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return None


def _token_is_fresh(
    token: Optional[dict], max_age_seconds: int, fleet_id: str,
) -> bool:
    """True iff the on-disk token is for THIS fleet_id, was passing,
    and is younger than max_age_seconds. Mismatch on fleet_id forces
    a re-run so a customer who switches drafters mid-session doesn't
    inherit yesterday's gate."""
    if not isinstance(token, dict) or not token.get("passed"):
        return False
    if token.get("fleet_id") != fleet_id:
        return False
    tested_at = token.get("tested_at")
    if not isinstance(tested_at, (int, float)):
        return False
    return (time.time() - tested_at) < max_age_seconds


def _make_fleet_id(clients: Sequence[Any]) -> str:
    """Deterministic id from the model-id list. Same fleet → same id."""
    ids = sorted(
        getattr(c, "model_id", None) or getattr(c, "model", "<unknown>")
        for c in clients
    )
    return "fleet:" + ",".join(ids) if ids else "fleet:<empty>"


def fleet_gate(
    clients: Sequence[Any],
    *,
    smoke_theorem: str = DEFAULT_SMOKE_THEOREM,
    lake_project: Optional[str] = None,
    module_path: Optional[str] = None,
    max_age_seconds: int = DEFAULT_MAX_AGE_SECONDS,
    token_path: Optional[str] = DEFAULT_TOKEN_PATH,
    smoke_prompt: str = DEFAULT_SMOKE_PROMPT,
    smoke_max_tokens: int = 32,
    verify_timeout_seconds: int = 180,
    allow_skip: bool = False,
) -> FleetGateResult:
    """Hard preflight gate for an SDK fleet launch.

    Returns a :class:`FleetGateResult`. Never raises on a failed
    drafter or failed verify — those land in ``result.failures`` and
    ``result.passed=False`` so the caller decides whether to abort.
    Raises only on programming errors (non-list ``clients``, etc.).

    Honors ``KAIROS_FLEET_NO_PREFLIGHT=1`` (or ``allow_skip=True``)
    by emitting a :class:`PreflightSkipped` warning and returning a
    ``FleetGateResult(passed=True, skipped=True)`` so calling code can
    proceed but the run-log explicitly states the gate was bypassed.

    Args:
        clients: model-client instances (each must implement
            ``.call(messages, temperature, max_tokens) -> ModelResponse``
            and expose ``.model_id`` or ``.model``). Empty list is
            allowed but always fails.
        smoke_theorem: known-good Lean source to pipe through
            ``verify_proof``. Caller can override with their own
            project-shape smoke if Mathlib's ``linarith`` shape is
            wrong for their imports.
        lake_project: path to the customer's lake project root. When
            ``None`` the verify round-trip is skipped and the gate
            checks LLM smokes only.
        module_path: dotted module path used by ``verify_proof`` to
            place the smoke inside the project (e.g.
            ``"MyProj.Preflight"``). Required when ``lake_project``
            is set.
        max_age_seconds: if a fresh-enough passing token exists for
            this fleet at ``token_path``, the gate short-circuits and
            re-uses the token. Default 600s (10 min).
        token_path: where to write the passing-token JSON. ``None``
            disables the write (useful in stateless / read-only
            sandboxes). Default ``~/.kairos/preflight_pass.json``;
            ``~`` is expanded.
        smoke_prompt: user-message text the 1-call smoke sends. Kept
            short to keep the smoke ~$0.005 per launch.
        smoke_max_tokens: max_tokens budget for each smoke call. The
            adapter's ``min_tokens_for_reasoning`` floor will clamp
            up if the model is a reasoning shape (Kimi K2.5).
        verify_timeout_seconds: ceiling for the lake build during the
            verify round-trip. Default 180s — covers cold-start
            against an unbuilt project.
        allow_skip: programmatic equivalent of
            ``KAIROS_FLEET_NO_PREFLIGHT=1``. Returns a skipped
            FleetGateResult, emits PreflightSkipped, never blocks.
    """
    if not isinstance(clients, (list, tuple)):
        raise TypeError(
            f"fleet_gate: clients must be a list/tuple, got {type(clients).__name__}"
        )

    fleet_id = _make_fleet_id(clients)
    expanded_token_path: Optional[Path] = None
    if token_path is not None:
        expanded_token_path = Path(os.path.expanduser(token_path)).resolve()

    # Skip path — explicit (env var or kwarg).
    env_skip = os.environ.get("KAIROS_FLEET_NO_PREFLIGHT", "").strip()
    if allow_skip or env_skip in ("1", "true", "TRUE"):
        import warnings
        reason = "KAIROS_FLEET_NO_PREFLIGHT=1" if env_skip else "allow_skip=True"
        warnings.warn(
            f"fleet_gate skipped ({reason}); customer-money risk on this fleet "
            f"launch is on the caller. fleet_id={fleet_id}",
            PreflightSkipped, stacklevel=2,
        )
        return FleetGateResult(
            passed=True, drafter_checks=[], verify_check=None,
            env_snapshot=_snapshot_env(), fleet_id=fleet_id,
            tested_at=time.time(),
            token_path=str(expanded_token_path) if expanded_token_path else None,
            failures=[], skipped=True, skipped_reason=reason,
        )

    # Token short-circuit: a fresh-enough passing token for this fleet
    # lets the gate return without re-running the smoke.
    if expanded_token_path is not None:
        existing = _read_token(expanded_token_path)
        if _token_is_fresh(existing, max_age_seconds, fleet_id):
            _logger.info(
                "fleet_gate: reusing fresh token at %s (age %.0fs < %ds)",
                expanded_token_path,
                time.time() - existing["tested_at"], max_age_seconds,
            )
            # Re-hydrate a pass-shaped FleetGateResult from the token.
            drafter_checks = [
                _ClientCheck(**{k: v for k, v in d.items() if k in _ClientCheck.__annotations__})
                for d in (existing.get("drafters") or [])
            ]
            return FleetGateResult(
                passed=True, drafter_checks=drafter_checks,
                verify_check=None,
                env_snapshot=existing.get("env_snapshot") or {},
                fleet_id=fleet_id,
                tested_at=existing["tested_at"],
                token_path=str(expanded_token_path),
                failures=[],
            )

    # Run the actual gate.
    drafter_checks: list[_ClientCheck] = []
    failures: list[dict] = []

    if not clients:
        failures.append({
            "check": "fleet_size",
            "reason": "fleet_gate: no clients supplied (empty fleet)",
        })

    for c in clients:
        chk = _smoke_one_client(
            c, smoke_prompt=smoke_prompt, max_tokens=smoke_max_tokens,
        )
        drafter_checks.append(chk)
        if not chk.passed:
            failures.append({
                "check": "drafter_smoke",
                "model_id": chk.model_id,
                "reason": chk.reason,
            })

    verify_check = _verify_round_trip(
        smoke_theorem=smoke_theorem,
        lake_project=lake_project,
        module_path=module_path,
        timeout_seconds=verify_timeout_seconds,
    )
    if not verify_check.passed:
        failures.append({
            "check": "verify_round_trip",
            "lake_project": verify_check.lake_project,
            "module_path": verify_check.module_path,
            "reason": verify_check.reason,
        })

    passed = not failures
    result = FleetGateResult(
        passed=passed,
        drafter_checks=drafter_checks,
        verify_check=verify_check,
        env_snapshot=_snapshot_env(),
        fleet_id=fleet_id,
        tested_at=time.time(),
        token_path=str(expanded_token_path) if expanded_token_path else None,
        failures=failures,
    )

    # Token write happens only on pass. A failing token would invite
    # the wrong kind of caching — next call would short-circuit on a
    # bad token.
    if passed and expanded_token_path is not None:
        try:
            expanded_token_path.parent.mkdir(parents=True, exist_ok=True)
            expanded_token_path.write_text(json.dumps(result.token, indent=2))
        except OSError as e:
            _logger.warning(
                "fleet_gate: token write to %s failed (non-fatal): %s",
                expanded_token_path, e,
            )

    return result
