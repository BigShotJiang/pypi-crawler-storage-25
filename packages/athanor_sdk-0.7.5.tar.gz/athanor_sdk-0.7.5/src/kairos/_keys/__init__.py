"""ATH-686-keys — bundled Athanor GPG pubkey + expected fingerprint.

When the SDK ships with a real Athanor GPG key, `KEYS_PROVISIONED`
flips to `True`, `BUNDLED_PUBKEY_PATH` resolves to the bundled .pub
file, and `EXPECTED_FINGERPRINT` carries the 40-char uppercase-hex
fingerprint of that key. `kairos.license_scope.load_license` then
calls `kairos.sdk_security.verify_license_signature` against every
license file before accepting it.

## Grace period (current state, 2026-04-26)

`KEYS_PROVISIONED = False`. No real key has been provisioned by
Athanor leadership yet. License signature verification is *skipped*
during this period; the policy gate (`require_product`) alone
defends. This means a forged license.json with the right `products`
claim would silently pass.

## Provisioning checklist (Sam-OPS, blocks v1.0 launch)

1. Generate the Athanor GPG key on a hardware-secured machine.
   - Suggested params: ed25519, 4-year expiration, no subkeys, no
     comment field.
   - Real-name field: "Athanor AI License Authority".
   - Email: aidan@athanorl.com.
2. Export the pubkey: `gpg --export --armor <fpr> > athanor.pub`.
3. Replace `kairos/_keys/athanor.pub` (placeholder) with the export.
4. Edit this file:
   - Set `KEYS_PROVISIONED = True`.
   - Set `EXPECTED_FINGERPRINT = "<40 uppercase hex chars>"`.
5. Test the round-trip:
   - Sign a test license: `gpg --detach-sign --armor test_license.json`.
   - Run `python -c "from kairos import license_scope;
     license_scope.load_license(home=Path('/tmp/test'))"` and verify
     it accepts the signed test license + rejects a forged one.
6. Commit + ship in the next minor release.

Until step 6 lands, the SDK is in grace-period mode and the security
posture is *policy-gate only*. Customer install path therefore needs
the policy gate to be reliable — which the ATH-686 fail-closed dev-mode
change handles.

The private key NEVER leaves the air-gapped signing machine. License
issuance is manual: Sam takes a customer's intent + signs a
license.json + sends back via email. v1.1 may automate the issuance
flow but the signing key stays offline.
"""
from __future__ import annotations

from pathlib import Path

# ╔══════════════════════════════════════════════════════════════════╗
# ║  ⚠  DO NOT SHIP TO CUSTOMER UNTIL KEYS_PROVISIONED = True  ⚠     ║
# ║                                                                  ║
# ║  per CTO review on PR #221 (ATH-686 ts=1777186084):             ║
# ║  customer #1 onboarding is BLOCKED on Sam-OPS provisioning the   ║
# ║  real Athanor GPG key + flipping this flag. Until then:          ║
# ║    - SDK is fail-closed for missing license                      ║
# ║    - SDK skips signature verification with a WARNING log         ║
# ║    - Policy gate (require_product) alone defends                 ║
# ║  Forging license.json with the right `products` claim WILL       ║
# ║  pass during this grace period. NOT acceptable for production.   ║
# ║                                                                  ║
# ║  Sub-ticket tracking provisioning: ATH-686-keys (Sam-OPS lane).  ║
# ╚══════════════════════════════════════════════════════════════════╝
KEYS_PROVISIONED = False

# Resolves to a real .pub file once provisioned. Stays as a placeholder
# path during the grace period — `load_license` does not call into
# this when `KEYS_PROVISIONED=False`.
BUNDLED_PUBKEY_PATH = Path(__file__).parent / "athanor.pub"

# 40 uppercase hex chars, populated when the real key lands. The
# placeholder fails the `_GPG_FPR_RE` validator in `sdk_security.py`,
# so accidental import + use during the grace period would raise loudly.
EXPECTED_FINGERPRINT = "PLACEHOLDER-NOT-A-REAL-FINGERPRINT-YET--"


__all__ = [
    "KEYS_PROVISIONED",
    "BUNDLED_PUBKEY_PATH",
    "EXPECTED_FINGERPRINT",
]
