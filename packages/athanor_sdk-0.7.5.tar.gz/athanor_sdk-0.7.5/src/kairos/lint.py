"""ATH-382 Cython shim for the lint module.

The real implementation lives in `_lint_impl.pyx`, which compiles to a
Cython `.so`. This shim re-exports the public surface so existing
callers (`cli.py`, tests, customer code) don't need to change imports.

Why this pattern (vs keeping the source as `.py`):

- The `.pyx` source stays in our private repo but is NOT shipped in
  the customer wheel. Only the compiled `.so` ships.
- `cat lint.py` on a customer install shows this short shim, not the
  scoring-adjacent code. `inspect.getsource(lint_file)` raises
  OSError (compiled functions have no Python source).
- The `strings` utility on the `.so` binary might still leak some
  constants (the `BANNED_LEAN_CONSTRUCTS` regex patterns especially).
  Full mitigation is the broader ATH-382 work (e.g. computing BANNED
  at runtime from a seed).

Build: run `python3 build_cython.py` at the repo root to regenerate
`_lint_impl.cpython-*-x86_64-linux-gnu.so`. See that script's module
docstring for the full workflow.

Until the hatchling + Cython build integration lands (ATH-382 follow-
up), this module falls back to the `.pyx` source via `pyximport` when
the compiled `.so` is absent — which keeps dev/test workflows working
when `python3 build_cython.py` hasn't been run. In the shipped wheel
the `.pyx` is excluded and the `.so` is present, so the fallback path
only fires on in-repo development.
"""
from __future__ import annotations

try:
    from kairos._lint_impl import (  # type: ignore[import-not-found]
        BANNED_LEAN_CONSTRUCTS,
        lint_file,
        lint_lean,
    )
except (ImportError, OSError):
    # Pure-Python fallback: works without Cython/.so/gcc.
    from kairos._lint_fallback import (
        BANNED_LEAN_CONSTRUCTS,
        lint_file,
        lint_lean,
    )


__all__ = ["BANNED_LEAN_CONSTRUCTS", "lint_file", "lint_lean"]
