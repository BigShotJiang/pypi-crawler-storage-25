"""ATH-357 stream event schema — SDK-side mirror.

This file intentionally duplicates the contract defined in
`athanor-builder/solve/shared/stream_schema.py`. Both sides stay
independently importable; neither package runtime-imports the other
(per ATH-337 IP partitioning — the SDK must not force athanor-builder
to pull it as a dependency).

Keep this file byte-for-byte in sync with the builder copy. CI drift
check lives in `athanor-sdk/tests/test_stream_schema_mirror.py` (compares
the two files and fails if they diverge; tests/ expect the builder
source on a configured path, skips silently when unavailable).

Events flow as JSONL on the builder's stdout. The SDK reads them via
`athanor stream` (see cli_renderer.py).
"""
from __future__ import annotations

from typing import Literal, TypedDict

# -------------------------------------------------------------------
# Event type vocabulary.
#
# v1 (locked 2026-04-19 by cto + qa + platform):
#   phase_start, phase_summary, loop_tick, cost_tick, bug_found, verdict.
#
# v2 extensions (2026-04-20, ATH-396) for Claude-Code-style live UX —
# additive only; old emitters keep working. Builder-side mirror pending
# the ATH-396 coord PR:
#   thinking_start    — agent begins a model call
#   thinking_end      — agent receives the completion
#   tool_use          — agent invokes a tool (Bash, Read, Edit, etc.)
#   tool_result       — tool returns (paired with tool_use via tool_use_id)
#   subagent_spawn    — parent agent spawns a child (Phase-0 fan-out, triple-audit voices)
#   subagent_join     — child agent returns to the parent (success / fail)
#   token_tick        — running tokens_in + tokens_out counter
# -------------------------------------------------------------------
EventType = Literal[
    # v1
    "phase_start",
    "phase_summary",
    "loop_tick",
    "cost_tick",
    "bug_found",
    "verdict",
    # v2 (ATH-396)
    "thinking_start",
    "thinking_end",
    "tool_use",
    "tool_result",
    "subagent_spawn",
    "subagent_join",
    "token_tick",
]

Severity = Literal["critical", "warning", "info"]

# Canonical stage identifiers used by the neuron / sysverilog / bbr3
# fleet runs. Emit helper validates against this set; renderer accepts
# anything as a string (forward-compat).
Stage = Literal[
    "phase_neg1",
    "phase_0",
    "phase_1",
    "phase_2",
    "phase_3",
    "phase_4",
    "phase_5",
    "phase_6",
]

# Tool vocabulary — the atomic label the renderer uses to attribute the
# event to a specific verifier / prover / agent. Extending is safe; the
# renderer left-pads/truncates.
Tool = Literal[
    "opus",
    "sonnet",
    "kimi",
    "gemini",
    "lean",
    "ebmc",
    "hypothesis",
    "aristotle",
    "simulator",
    "mutation_sweep",
    "plan_validator",
    "arbiter",
]


class StreamEvent(TypedDict, total=False):
    """One JSONL line on the builder's streaming stdout.

    Required fields: event, ts, stage, tool, severity, headline.
    Optional fields: artifact_path, cost_usd, elapsed_sec, details.

    The renderer tolerates missing optional fields; the emit helper in
    athanor-builder enforces the required ones at emit time.
    """

    # Required.
    event: EventType
    ts: str           # ISO-8601 UTC
    stage: str        # stage enum value or free-form phase label
    tool: str         # tool enum value or free-form tool label
    severity: Severity
    headline: str     # <=100-char active-voice one-liner

    # Optional.
    artifact_path: str      # relative path from run workdir
    cost_usd: float         # running total (cost_tick) or per-phase (phase_summary)
    elapsed_sec: float      # phase_summary / verdict wall-clock
    details: dict           # free-form, rendered only under --verbose

    # ATH-396 additions — optional; populated only on the new event types.
    agent_id: str           # stable id for a running agent (thinking_*, tool_*, subagent_*)
    parent_agent_id: str    # parent in the subagent tree (subagent_spawn / tool_use)
    tool_name: str          # on tool_use / tool_result: Bash / Read / Edit / ebmc / ...
    tool_args: str          # on tool_use: pre-truncated arg summary (<=80 chars)
    tool_use_id: str        # pairing id: same on the matching tool_use + tool_result
    tool_result_ok: bool    # on tool_result: True = success, False = error
    tool_result_preview: str  # on tool_result: truncated output (<=200 chars)
    model: str              # on thinking_* / subagent_spawn: the LLM invoked
    tokens_in: int          # on token_tick: running input tokens
    tokens_out: int         # on token_tick: running output tokens


# -------------------------------------------------------------------
# Gating.
# -------------------------------------------------------------------
StreamMode = Literal["full", "terse", "quiet"]

# Terse mode suppresses noisy ticks; everything else still renders.
#
# On tool_use / tool_result pairing (CTO review on PR #51): either
# both render or neither does. Suppressing only tool_result would leave
# customers staring at orphaned "→ Bash(...)" lines with no visible
# success/fail — the pair is the signal. Tool calls are load-bearing
# content, not noise, so they both stay visible in terse.
#
# What terse drops: the true ticks (loop_tick, cost_tick, token_tick)
# and the thinking_end half of the thinking_start/end pair — the start
# already says "thinking..." and the end just confirms completion with
# elapsed time; terse callers prefer to see the next tool_use firing
# instead.
TERSE_SUPPRESSED: frozenset = frozenset({
    "loop_tick", "cost_tick", "token_tick", "thinking_end",
})

# Quiet mode suppresses everything except critical bugs + the final
# verdict. Used for internal fleet runs where stdout is being piped
# to a log.
QUIET_ALLOWED: frozenset = frozenset({"bug_found", "verdict"})


# -------------------------------------------------------------------
# Emit helpers (ATH-395, 2026-04-20).
# -------------------------------------------------------------------
# Legacy `cmd_solve` / `runner.run_solve` produces human-readable
# `print()` lines only. `athanor stream` can only render JSONL-shape
# events, so the non-`--vertical` path is invisible to the renderer.
# These helpers give the SDK-side caller one line per print-site to
# emit a properly-shaped event that flows through `athanor stream`
# exactly like the builder's events.
#
# Design mirror of athanor-builder/solve/shared/stream_schema.py's
# emit(), emit_phase_start(), etc. — kept semantically in sync, but
# not byte-for-byte (SDK uses TypedDict vs builder's dataclass).
#
# Mode gating (env `ATHANOR_STREAM_MODE` = full|terse|quiet) and the
# ATHANOR_QUIET=1 legacy toggle mirror the builder exactly so the
# mode set at process-launch gates both sides consistently.

import json as _json
import os as _os
import sys as _sys
from datetime import datetime as _dt
from datetime import timezone as _tz


_ENV_STREAM_MODE = "ATHANOR_STREAM_MODE"
_ENV_QUIET_LEGACY = "ATHANOR_QUIET"


def current_stream_mode() -> StreamMode:
    """Resolve the effective stream mode for the current process."""
    if _os.environ.get(_ENV_QUIET_LEGACY) == "1":
        return "quiet"
    mode = _os.environ.get(_ENV_STREAM_MODE, "full")
    if mode not in ("full", "terse", "quiet"):
        return "full"
    return mode  # type: ignore[return-value]


def _should_emit(event: str) -> bool:
    mode = current_stream_mode()
    if mode == "quiet":
        return event in QUIET_ALLOWED
    if mode == "terse" and event in TERSE_SUPPRESSED:
        return False
    return True


def emit(event: StreamEvent) -> None:
    """Write one JSONL event to stdout, mode-gated.

    Omits None-valued keys (TypedDict total=False; missing fields
    are legitimately absent, not null). 100-char headline truncation
    matches the builder's invariant.
    """
    if not _should_emit(event.get("event", "")):
        return
    d: dict = {k: v for k, v in event.items() if v is not None}
    h = d.get("headline", "")
    if len(h) > 100:
        d["headline"] = h[:97] + "..."
    _sys.stdout.write(_json.dumps(d, separators=(",", ":")) + "\n")
    _sys.stdout.flush()


def _now_iso() -> str:
    return _dt.now(_tz.utc).isoformat()


def emit_phase_start(stage: str, tool: str, headline: str) -> None:
    emit({
        "event": "phase_start", "ts": _now_iso(),
        "stage": stage, "tool": tool,
        "severity": "info", "headline": headline,
    })


def emit_phase_summary(
    stage: str,
    tool: str,
    headline: str,
    *,
    cost_usd: float | None = None,
    elapsed_sec: float | None = None,
    artifact_path: str | None = None,
) -> None:
    emit({
        "event": "phase_summary", "ts": _now_iso(),
        "stage": stage, "tool": tool,
        "severity": "info", "headline": headline,
        "cost_usd": cost_usd, "elapsed_sec": elapsed_sec,
        "artifact_path": artifact_path,
    })


def emit_verdict(
    stage: str,
    tool: str,
    headline: str,
    *,
    severity: Severity = "info",
    cost_usd: float | None = None,
    elapsed_sec: float | None = None,
    artifact_path: str | None = None,
) -> None:
    emit({
        "event": "verdict", "ts": _now_iso(),
        "stage": stage, "tool": tool,
        "severity": severity, "headline": headline,
        "cost_usd": cost_usd, "elapsed_sec": elapsed_sec,
        "artifact_path": artifact_path,
    })


def emit_loop_tick(
    stage: str,
    *,
    loop: int,
    loop_max: int,
    headline: str,
    tool: str = "sonnet",
) -> None:
    emit({
        "event": "loop_tick", "ts": _now_iso(),
        "stage": stage, "tool": tool,
        "severity": "info", "headline": headline,
    })


def emit_cost_tick(running_total: float, *, headline: str, tool: str = "sonnet") -> None:
    emit({
        "event": "cost_tick", "ts": _now_iso(),
        "stage": "phase_0", "tool": tool,
        "severity": "info", "headline": headline,
        "cost_usd": running_total,
    })


def emit_thinking_start(
    stage: str,
    tool: str,
    *,
    agent_id: str,
    model: str,
    headline: str = "thinking...",
) -> None:
    emit({
        "event": "thinking_start", "ts": _now_iso(),
        "stage": stage, "tool": tool,
        "severity": "info", "headline": headline,
        "agent_id": agent_id, "model": model,
    })


def emit_thinking_end(
    stage: str,
    tool: str,
    *,
    agent_id: str,
    headline: str = "thinking done",
    elapsed_sec: float | None = None,
) -> None:
    emit({
        "event": "thinking_end", "ts": _now_iso(),
        "stage": stage, "tool": tool,
        "severity": "info", "headline": headline,
        "agent_id": agent_id, "elapsed_sec": elapsed_sec,
    })


def emit_tool_use(
    stage: str,
    tool: str,
    *,
    agent_id: str,
    tool_use_id: str,
    tool_name: str,
    tool_args: str = "",
    headline: str | None = None,
) -> None:
    emit({
        "event": "tool_use", "ts": _now_iso(),
        "stage": stage, "tool": tool,
        "severity": "info",
        "headline": headline or f"→ {tool_name}({tool_args})",
        "agent_id": agent_id,
        "tool_use_id": tool_use_id,
        "tool_name": tool_name,
        "tool_args": tool_args[:80],
    })


def emit_tool_result(
    stage: str,
    tool: str,
    *,
    agent_id: str,
    tool_use_id: str,
    ok: bool,
    preview: str = "",
    headline: str | None = None,
) -> None:
    emit({
        "event": "tool_result", "ts": _now_iso(),
        "stage": stage, "tool": tool,
        "severity": "info" if ok else "warning",
        "headline": headline or ("← ok" if ok else "← error"),
        "agent_id": agent_id,
        "tool_use_id": tool_use_id,
        "tool_result_ok": ok,
        "tool_result_preview": preview[:200],
    })


def emit_token_tick(tokens_in: int, tokens_out: int, *, stage: str = "phase_0", tool: str = "sonnet") -> None:
    emit({
        "event": "token_tick", "ts": _now_iso(),
        "stage": stage, "tool": tool,
        "severity": "info",
        "headline": f"tokens: in={tokens_in} out={tokens_out}",
        "tokens_in": tokens_in, "tokens_out": tokens_out,
    })


def emit_bug_found(
    stage: str,
    tool: str,
    *,
    severity: Severity,
    headline: str,
    artifact_path: str | None = None,
) -> None:
    emit({
        "event": "bug_found", "ts": _now_iso(),
        "stage": stage, "tool": tool,
        "severity": severity, "headline": headline,
        "artifact_path": artifact_path,
    })


__all__ = [
    "EventType",
    "Severity",
    "Stage",
    "Tool",
    "StreamEvent",
    "StreamMode",
    "TERSE_SUPPRESSED",
    "QUIET_ALLOWED",
    # Emit helpers (ATH-395).
    "current_stream_mode",
    "emit",
    "emit_phase_start",
    "emit_phase_summary",
    "emit_verdict",
    "emit_loop_tick",
    "emit_cost_tick",
    "emit_thinking_start",
    "emit_thinking_end",
    "emit_tool_use",
    "emit_tool_result",
    "emit_token_tick",
    "emit_bug_found",
]
