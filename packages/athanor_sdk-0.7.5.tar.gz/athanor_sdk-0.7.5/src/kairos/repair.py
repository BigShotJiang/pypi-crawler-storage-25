"""kairos.repair — find + fix + verify pipeline.

One command: `kairos repair .` does the right thing.

Auto-detects:
- .lean file → sorry closure pipeline (L0-L3)
- .py file → review + fix + verify
- .rs file → review + fix + cargo check
- directory → batch parallel repair
- merge conflicts → rebase conflict resolution

`repair --review` = diagnose only
`repair --fix` = diagnose + fix + verify
`repair` = full pipeline including memory

The customer runs `kairos repair .` and kairos figures out what to do.
"""
from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from kairos.review import review, ReviewResult, ReviewFinding
from kairos.security.env_allowlist import safe_env_for_claude_subagent


@dataclass
class RepairResult:
    path: str
    findings: list[ReviewFinding] = field(default_factory=list)
    fixes_attempted: int = 0
    fixes_applied: int = 0
    fixes_verified: int = 0
    error: str | None = None


_FIX_SYSTEM_PROMPT = """\
You are a code repair agent. You receive a file and a specific finding
(bug, vulnerability, or issue) with a line number and description.

Your job: generate a MINIMAL fix. Change as few lines as possible.
Return ONLY the complete fixed file content. No explanation. No markdown
fences. Just the corrected source code.

Rules:
- Fix ONLY the specific finding described. Do not refactor.
- Preserve all existing behavior except the bug.
- If the fix requires adding an import, add it at the top.
- Do not add comments explaining the fix.
"""


def _auto_detect_verify_cmd(target: Path) -> str | None:
    """Auto-detect the verification command for the target file's project."""
    for candidate in [
        target.parent / "pytest.ini",
        target.parent / "pyproject.toml",
        target.parent / "setup.py",
    ]:
        if candidate.exists():
            return f"python -m pytest {target.parent / 'tests'} -x -q --timeout=30"
    cwd = Path.cwd()
    if (cwd / "pyproject.toml").exists() or (cwd / "pytest.ini").exists():
        return "python -m pytest tests/ -x -q --timeout=30"
    return None


def _has_merge_conflicts() -> bool:
    """Check if the current repo has merge conflicts."""
    try:
        r = subprocess.run(
            ["git", "diff", "--name-only", "--diff-filter=U"],
            capture_output=True, text=True, timeout=5,
        )
        return bool(r.stdout.strip())
    except Exception:  # noqa: BLE001
        return False


def _repair_directory(
    target: Path,
    *,
    fix: bool = True,
    focus: str | None = None,
) -> RepairResult:
    """Auto-detect and repair all files in a directory."""
    if _has_merge_conflicts():
        from kairos.repair_rebase import repair_rebase
        rebase_result = repair_rebase(dry_run=not fix)
        return RepairResult(
            path=str(target),
            fixes_attempted=rebase_result.conflicts_found,
            fixes_applied=rebase_result.conflicts_resolved,
            fixes_verified=rebase_result.conflicts_resolved,
            error=rebase_result.honest_report,
        )

    from kairos.repair_batch import repair_batch
    batch_result = repair_batch(target, fix=fix)
    return RepairResult(
        path=str(target),
        fixes_attempted=batch_result.total_findings,
        fixes_applied=batch_result.total_fixes,
        fixes_verified=batch_result.total_fixes,
        error=batch_result.honest_report,
    )


def repair(
    path: str | Path,
    *,
    fix: bool = True,
    focus: str | None = None,
    verify_cmd: str | None = None,
) -> RepairResult:
    """Find issues, fix them, and verify the fix. Verify is ALWAYS ON.

    Args:
        path: File to repair.
        fix: If True, generate and apply fixes. If False, diagnose only.
        focus: Review focus area.
        verify_cmd: Override verification command. Auto-detected if None.
    """
    target = Path(path)

    if target.is_dir():
        return _repair_directory(target, fix=fix, focus=focus)

    if not target.exists():
        return RepairResult(path=str(path), error=f"File not found: {path}")

    if not target.is_file():
        return RepairResult(path=str(path), error=f"Not a file: {path}")

    if target.suffix == ".lean":
        from kairos.lean_repair import repair_lean, LeanRepairResult
        lean_result = repair_lean(target, max_level=1 if fix else 0)
        return RepairResult(
            path=str(path),
            fixes_attempted=lean_result.total_sorrys - lean_result.escalated,
            fixes_applied=lean_result.closed,
            fixes_verified=lean_result.closed,
            error=lean_result.honest_report if lean_result.total_sorrys > 0 else None,
        )

    review_result = review(target, focus=focus)
    if review_result.error:
        return RepairResult(path=str(path), error=review_result.error)

    result = RepairResult(
        path=str(path),
        findings=review_result.findings,
    )

    if not fix or not review_result.findings:
        return result

    actionable = [
        f for f in review_result.findings
        if f.severity in ("critical", "high", "medium")
    ]

    if not actionable:
        return result

    claude_bin = shutil.which("claude")
    if not claude_bin:
        result.error = "claude CLI not found — cannot generate fixes"
        return result

    if verify_cmd is None:
        verify_cmd = _auto_detect_verify_cmd(target)

    if not verify_cmd:
        result.error = "no test runner detected — refusing to apply unverified fixes"
        return result

    original_content = target.read_text()

    for finding in actionable:
        result.fixes_attempted += 1
        fixed_content = _generate_fix(claude_bin, target, original_content, finding)
        if fixed_content is None:
            continue

        if not _verify_fix(target, fixed_content, verify_cmd):
            continue
        result.fixes_verified += 1

        target.write_text(fixed_content)
        original_content = fixed_content
        result.fixes_applied += 1

    return result


def _generate_fix(
    claude_bin: str,
    target: Path,
    content: str,
    finding: ReviewFinding,
) -> str | None:
    """Generate a fix for a single finding via Claude subagent."""
    prompt = (
        f"Fix this issue in {target.name}:\n\n"
        f"Line {finding.line}: [{finding.severity}] {finding.finding}\n"
        f"Suggested fix: {finding.suggestion}\n\n"
        f"File content:\n```\n{content}\n```\n\n"
        f"Return ONLY the complete fixed file. No markdown. No explanation."
    )

    try:
        result = subprocess.run(
            [claude_bin, "--print", "-p", prompt,
             "--append-system-prompt", _FIX_SYSTEM_PROMPT,
             "--max-turns", "1"],
            capture_output=True,
            text=True,
            timeout=60,
            env=safe_env_for_claude_subagent(),
        )
        output = result.stdout.strip()
        if output.startswith("```"):
            lines = output.splitlines()
            output = "\n".join(lines[1:-1] if lines[-1].startswith("```") else lines[1:])
        if len(output) < 10:
            return None
        return output
    except Exception:  # noqa: BLE001
        return None


def _verify_fix(
    target: Path,
    fixed_content: str,
    verify_cmd: str,
) -> bool:
    """Verify a fix by writing it to a temp file and running the verify command."""
    import shlex
    backup = target.with_suffix(target.suffix + ".repair_backup")
    original = target.read_text()
    backup.write_text(original)
    try:
        target.write_text(fixed_content)
        result = subprocess.run(
            shlex.split(verify_cmd),
            capture_output=True, text=True, timeout=120,
            cwd=target.parent,
        )
        return result.returncode == 0
    except Exception:  # noqa: BLE001
        return False
    finally:
        target.write_text(original)
        backup.unlink(missing_ok=True)


def format_repair(result: RepairResult) -> str:
    """Format RepairResult for terminal output."""
    if result.error:
        return f"Repair error: {result.error}"

    lines = [f"Repair: {result.path}"]
    lines.append(f"  Findings: {len(result.findings)}")
    if result.fixes_attempted > 0:
        lines.append(
            f"  Fixes: {result.fixes_applied}/{result.fixes_attempted} applied"
            f" ({result.fixes_verified} verified)"
        )
    for f in result.findings:
        icon = {"critical": "!!", "high": "!", "medium": "~", "low": "-"}.get(f.severity, "?")
        lines.append(f"  [{icon}] L{f.line} [{f.category}] {f.finding}")
    return "\n".join(lines)
