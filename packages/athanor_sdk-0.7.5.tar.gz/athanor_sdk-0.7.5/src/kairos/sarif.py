"""SARIF output for kairos verify/repair findings.

GitHub code scanning uses SARIF (Static Analysis Results Interchange
Format). This module converts kairos findings to SARIF for native
GitHub enforcement: inline PR annotations, security dashboard,
severity-based blocking.

Usage:
    kairos verify src/ --sarif > results.sarif
    kairos repair src/ --review --sarif > results.sarif

Then upload via github/codeql-action/upload-sarif in CI.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any


SARIF_VERSION = "2.1.0"
SARIF_SCHEMA = "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json"

TOOL_NAME = "kairos"
TOOL_VERSION = "0.6.4"


def findings_to_sarif(
    findings: list[dict[str, Any]],
    tool_name: str = TOOL_NAME,
) -> dict[str, Any]:
    """Convert kairos findings to SARIF format."""
    results = []
    rules = {}

    for i, f in enumerate(findings):
        rule_id = f.get("category", f.get("check", f"kairos-{i}"))
        severity = f.get("severity", "medium")
        message = f.get("finding", f.get("message", ""))
        file_path = f.get("file", f.get("path", ""))
        line = f.get("line", 1)
        suggestion = f.get("suggestion", f.get("fix", ""))

        if isinstance(line, str):
            line = int(line.split("-")[0]) if "-" in line else int(line) if line.isdigit() else 1

        sarif_level = {
            "critical": "error",
            "high": "error",
            "medium": "warning",
            "low": "note",
        }.get(severity, "warning")

        if rule_id not in rules:
            rules[rule_id] = {
                "id": rule_id,
                "name": rule_id.replace("_", " ").title(),
                "shortDescription": {"text": rule_id},
                "defaultConfiguration": {"level": sarif_level},
            }

        result = {
            "ruleId": rule_id,
            "level": sarif_level,
            "message": {"text": message},
            "locations": [{
                "physicalLocation": {
                    "artifactLocation": {"uri": file_path},
                    "region": {"startLine": max(1, line)},
                },
            }],
        }

        if suggestion:
            result["fixes"] = [{
                "description": {"text": suggestion},
                "artifactChanges": [],
            }]

        results.append(result)

    return {
        "$schema": SARIF_SCHEMA,
        "version": SARIF_VERSION,
        "runs": [{
            "tool": {
                "driver": {
                    "name": tool_name,
                    "version": TOOL_VERSION,
                    "rules": list(rules.values()),
                },
            },
            "results": results,
        }],
    }


def write_sarif(
    findings: list[dict[str, Any]],
    output_path: str | Path,
) -> None:
    """Write findings as SARIF to a file."""
    sarif = findings_to_sarif(findings)
    Path(output_path).write_text(
        json.dumps(sarif, indent=2),
        encoding="utf-8",
    )


def format_sarif(findings: list[dict[str, Any]]) -> str:
    """Return SARIF JSON as a string."""
    return json.dumps(findings_to_sarif(findings), indent=2)
