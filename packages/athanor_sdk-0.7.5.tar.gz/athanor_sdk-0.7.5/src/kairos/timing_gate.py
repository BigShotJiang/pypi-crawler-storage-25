"""ATH-1146: Timing gate — reject optimizations that break timing.

Area reduction that creates critical path violations is worse than
no optimization. This gate runs OpenSTA on gold and gate, compares
worst negative slack (WNS), and rejects if the gate is worse.

Lean backing:
  PhysicalDesign.timing_arc_monotone — delay is monotone in load
  PhysicalDesign.slack_preservation — removing gates on non-critical
    paths preserves critical path slack

Usage:
    from kairos.timing_gate import check_timing
    result = check_timing(gold_netlist, gate_netlist, lib_path)
    if not result.passed:
        print(f"REJECTED: timing degraded by {result.wns_delta_ns}ns")
"""
from __future__ import annotations

import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from kairos.security.env_allowlist import safe_env_for_yosys


@dataclass
class TimingResult:
    gold_wns_ns: float | None = None
    gate_wns_ns: float | None = None
    gold_tns_ns: float | None = None
    gate_tns_ns: float | None = None
    wns_delta_ns: float | None = None
    passed: bool = False
    reason: str = ""
    error: str | None = None

    @property
    def honest_report(self) -> str:
        if self.error:
            return f"Timing gate error: {self.error}"
        if self.passed:
            delta = f" (WNS improved by {abs(self.wns_delta_ns or 0):.3f}ns)" if self.wns_delta_ns else ""
            return f"Timing gate PASSED{delta}"
        return (
            f"Timing gate FAILED: gate WNS {self.gate_wns_ns:.3f}ns "
            f"worse than gold WNS {self.gold_wns_ns:.3f}ns "
            f"(degraded by {abs(self.wns_delta_ns or 0):.3f}ns)"
        )


def _find_opensta() -> str | None:
    return shutil.which("sta") or shutil.which("opensta") or shutil.which("OpenSTA")


def _run_sta(
    netlist: Path,
    lib_path: Path,
    clock_period_ns: float,
    module: str,
    timeout_sec: int = 60,
) -> tuple[float | None, float | None, str | None]:
    """Run OpenSTA and extract WNS + TNS.

    Returns (wns_ns, tns_ns, error).
    """
    from kairos.security.path_sanitizer import validate_verilog_identifier
    sta_bin = _find_opensta()
    if sta_bin is None:
        return None, None, "OpenSTA not found on PATH (install: apt install opensta)"

    validate_verilog_identifier(module, "module")
    for p in (lib_path, netlist):
        s = str(p)
        if any(c in s for c in ';[]{}$\\'):
            return None, None, f"unsafe characters in path: {s[:60]}"

    tcl_script = f"""\
read_liberty {lib_path}
read_verilog {netlist}
link_design {module}
create_clock -period {clock_period_ns} [get_ports clk]
report_checks -path_delay max -format short
report_tns
exit
"""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".tcl", delete=False) as f:
        f.write(tcl_script)
        tcl_path = f.name

    try:
        r = subprocess.run(
            [sta_bin, "-exit", tcl_path],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            env=safe_env_for_yosys(),
        )
        output = r.stdout + r.stderr

        wns = _extract_wns(output)
        tns = _extract_tns(output)
        return wns, tns, None
    except subprocess.TimeoutExpired:
        return None, None, f"OpenSTA timed out ({timeout_sec}s)"
    except Exception as e:  # noqa: BLE001 — best-effort cleanup
        return None, None, str(e)[:200]
    finally:
        Path(tcl_path).unlink(missing_ok=True)


def _extract_wns(output: str) -> float | None:
    m = re.search(r"wns\s+([-\d.]+)", output, re.IGNORECASE)
    if m:
        return float(m.group(1))
    m = re.search(r"slack\s*\(.*?\)\s*([-\d.]+)", output)
    if m:
        return float(m.group(1))
    return None


def _extract_tns(output: str) -> float | None:
    m = re.search(r"tns\s+([-\d.]+)", output, re.IGNORECASE)
    if m:
        return float(m.group(1))
    return None


def check_timing(
    gold_netlist: str | Path,
    gate_netlist: str | Path,
    lib_path: str | Path,
    *,
    module: str = "",
    clock_period_ns: float = 1.0,
    wns_tolerance_ns: float = 0.0,
    timeout_sec: int = 60,
) -> TimingResult:
    """Compare timing between gold and gate netlists.

    PASSES if gate WNS >= gold WNS - tolerance (gate is no worse).
    FAILS if gate has worse timing than gold beyond tolerance.
    """
    gold = Path(gold_netlist)
    gate = Path(gate_netlist)
    lib = Path(lib_path)

    if not gold.is_file():
        return TimingResult(error=f"Gold netlist not found: {gold}")
    if not gate.is_file():
        return TimingResult(error=f"Gate netlist not found: {gate}")
    if not lib.is_file():
        return TimingResult(error=f"Liberty file not found: {lib}")

    if not module:
        module = gold.stem

    gold_wns, gold_tns, err = _run_sta(gold, lib, clock_period_ns, module, timeout_sec)
    if err:
        return TimingResult(error=f"Gold STA failed: {err}")

    gate_wns, gate_tns, err = _run_sta(gate, lib, clock_period_ns, module, timeout_sec)
    if err:
        return TimingResult(error=f"Gate STA failed: {err}")

    if gold_wns is None or gate_wns is None:
        return TimingResult(
            gold_wns_ns=gold_wns,
            gate_wns_ns=gate_wns,
            error="Could not extract WNS from STA output",
        )

    wns_delta = gate_wns - gold_wns
    passed = wns_delta >= -wns_tolerance_ns

    return TimingResult(
        gold_wns_ns=gold_wns,
        gate_wns_ns=gate_wns,
        gold_tns_ns=gold_tns,
        gate_tns_ns=gate_tns,
        wns_delta_ns=wns_delta,
        passed=passed,
        reason="gate timing equal or better" if passed else "gate timing degraded",
    )


@dataclass
class TimingAnalysis:
    wns_ns: float | None = None
    tns_ns: float | None = None
    clock_period_ns: float = 1.0
    source: str = "OpenSTA"
    error: str | None = None

    @property
    def available(self) -> bool:
        return self.wns_ns is not None

    @property
    def meets_timing(self) -> bool:
        return self.wns_ns is not None and self.wns_ns >= 0

    def summary(self) -> str:
        if self.error:
            return f"not available ({self.error})"
        if self.wns_ns is None:
            return "not available (requires STA toolchain)"
        status = "MET" if self.meets_timing else "VIOLATED"
        return f"WNS {self.wns_ns:.3f}ns, TNS {self.tns_ns:.3f}ns ({status}, {self.source})"


def analyze_timing(
    netlist: str | Path,
    lib_path: str | Path,
    *,
    module: str = "",
    clock_period_ns: float = 1.0,
    timeout_sec: int = 60,
) -> TimingAnalysis:
    """Run standalone timing analysis on a single netlist.

    For use in arch-explore tradeoff analysis. Customer provides
    .lib (Liberty) + clock period, we return real WNS/TNS from OpenSTA.
    """
    netlist_p = Path(netlist)
    lib_p = Path(lib_path)

    if not netlist_p.is_file():
        return TimingAnalysis(error=f"netlist not found: {netlist}")
    if not lib_p.is_file():
        return TimingAnalysis(error=f"Liberty file not found: {lib_path}")
    if not module:
        module = netlist_p.stem

    sta_bin = _find_opensta()
    if sta_bin is None:
        return TimingAnalysis(error="OpenSTA not installed")

    wns, tns, err = _run_sta(netlist_p, lib_p, clock_period_ns, module, timeout_sec)
    if err:
        return TimingAnalysis(error=err, clock_period_ns=clock_period_ns)

    return TimingAnalysis(
        wns_ns=wns,
        tns_ns=tns,
        clock_period_ns=clock_period_ns,
    )
