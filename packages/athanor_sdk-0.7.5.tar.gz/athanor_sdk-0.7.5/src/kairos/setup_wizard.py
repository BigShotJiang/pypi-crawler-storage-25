"""ATH-1387: kairos setup — zero-config onboarding wizard.

Interactive setup: walks customer through proposer config in <30s.
Writes kairos.toml with correct defaults. Validates config works.

Usage:
    kairos setup              # interactive wizard
    kairos setup --check      # validate current config
"""
from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path


def setup(*, check_only: bool = False) -> int:
    """Run the setup wizard. Returns 0 on success."""
    if check_only:
        return _check_config()

    print("kairos setup — configure your optimization environment\n")

    backend = _detect_or_ask_backend()
    if backend is None:
        return 1

    model = _ask_model(backend)
    _write_config(backend, model)
    print(f"\nConfiguration saved to ~/.kairos/config.toml")
    print(f"  backend: {backend}")
    print(f"  model: {model}")
    print(f"\nRun: kairos optimize <your-block.sv>")
    return 0


def _detect_or_ask_backend() -> str | None:
    """Auto-detect or interactively select proposer backend."""
    from kairos.sec.closed_loop.optimize_cli import _check_ollama

    if _check_ollama():
        print("  [auto] ollama detected (local, RTL stays on-machine)")
        return "local"

    if os.environ.get("ANTHROPIC_API_KEY"):
        print("  [auto] ANTHROPIC_API_KEY detected")
        return "litellm"

    if os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("AWS_DEFAULT_REGION"):
        print("  [auto] AWS Bedrock credentials detected")
        return "litellm"

    claude_bin = shutil.which("claude")
    if claude_bin:
        print("  [auto] Claude Code CLI detected")
        return "claude-agent"

    print("No proposer backend detected.\n")
    print("Options:")
    print("  1. Install ollama (local, RTL stays on-machine)")
    print("     → curl -fsSL https://ollama.com/install.sh | sh")
    print("     → ollama pull deepseek-coder-v2")
    print("  2. Set ANTHROPIC_API_KEY")
    print("     → export ANTHROPIC_API_KEY=sk-ant-...")
    print("  3. Set AWS Bedrock credentials")
    print("     → export AWS_ACCESS_KEY_ID=... AWS_DEFAULT_REGION=...")
    print("  4. Install Claude Code CLI")
    print("     → npm install -g @anthropic-ai/claude-code")
    print()

    try:
        choice = input("Choose (1-4, or q to quit): ").strip()
    except (EOFError, KeyboardInterrupt):
        return None

    if choice == "1":
        print("\nInstall ollama, then re-run: kairos setup")
        return None
    if choice == "2":
        key = input("ANTHROPIC_API_KEY: ").strip()
        if key:
            os.environ["ANTHROPIC_API_KEY"] = key
            return "litellm"
    if choice == "3":
        return "litellm"
    if choice == "4":
        return "claude-agent"
    return None


def _ask_model(backend: str) -> str:
    """Select default model for the backend."""
    if backend == "local":
        return "ollama/deepseek-coder-v2"
    if backend == "claude-agent":
        return "claude-sonnet-4-20250514"
    return "claude-sonnet-4-20250514"


def _write_config(backend: str, model: str) -> None:
    """Write config to ~/.kairos/config.toml."""
    config_dir = Path.home() / ".kairos"
    config_dir.mkdir(parents=True, exist_ok=True)
    config_path = config_dir / "config.toml"
    config_path.write_text(
        f"[proposer]\nbackend = \"{backend}\"\nmodel = \"{model}\"\n"
    )


def _check_config() -> int:
    """Validate current configuration."""
    print("kairos setup --check\n")
    try:
        from kairos.sec.closed_loop.optimize_cli import detect_proposer_backend
        backend = detect_proposer_backend()
        print(f"  proposer backend: {backend}")
        print("  status: OK")
        return 0
    except ValueError as e:
        print(f"  error: {e}")
        return 1
