"""ATH-1463 B3: Thread-safe shared invariant cache.

When one proposal's verification discovers a bridge invariant,
it is cached here so other proposals can reuse it without
rediscovery. The cache is scoped to a single optimization run.

Thread-safe: uses threading.Lock for all mutations.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field


@dataclass(frozen=True)
class CachedInvariant:
    sva_text: str
    source_proposal: int
    source_property: str
    proved_at_bound: int


class InvariantCache:
    """Thread-safe cache of discovered bridge invariants."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._invariants: list[CachedInvariant] = []
        self._seen: set[str] = set()

    def add(self, inv: CachedInvariant) -> bool:
        """Add an invariant. Returns True if new, False if duplicate."""
        with self._lock:
            if inv.sva_text in self._seen:
                return False
            self._seen.add(inv.sva_text)
            self._invariants.append(inv)
            return True

    def get_all(self) -> list[CachedInvariant]:
        """Get all cached invariants (snapshot — safe to iterate)."""
        with self._lock:
            return list(self._invariants)

    def get_sva_texts(self) -> list[str]:
        """Get SVA text of all cached invariants."""
        with self._lock:
            return [inv.sva_text for inv in self._invariants]

    def __len__(self) -> int:
        with self._lock:
            return len(self._invariants)

    def clear(self) -> None:
        with self._lock:
            self._invariants.clear()
            self._seen.clear()


_global_cache = InvariantCache()


def get_global_cache() -> InvariantCache:
    """Get the global invariant cache for the current optimization run."""
    return _global_cache


def reset_global_cache() -> None:
    """Reset the global cache (call at start of each optimization run)."""
    _global_cache.clear()


__all__ = [
    "CachedInvariant",
    "InvariantCache",
    "get_global_cache",
    "reset_global_cache",
]
