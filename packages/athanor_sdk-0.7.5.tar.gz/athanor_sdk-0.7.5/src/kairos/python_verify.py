"""ATH-1450: kairos verify myfile.py — auto-verify Python code.

Auto-detects .py → extracts type hints + docstrings → generates
hypothesis proptests → runs mypy strict → reports results.

No API key needed. No Lean knowledge needed. 30 seconds.

The invisible Lean philosophy: customer types `kairos verify app.py`,
gets a report. Never sees types, specs, or theorems.
"""
from __future__ import annotations

import ast
import re
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class PropertySpec:
    name: str
    description: str
    source: str
    hypothesis_test: str


@dataclass
class VerifyAction:
    command: str
    reason: str
    impact: str


@dataclass
class VerifyResult:
    file_path: str
    mypy_passed: bool
    mypy_errors: list[str] = field(default_factory=list)
    properties: list[PropertySpec] = field(default_factory=list)
    properties_passed: int = 0
    properties_failed: int = 0
    properties_total: int = 0
    mutation_score: float | None = None
    mutation_detail: str = ""
    actions: list[VerifyAction] = field(default_factory=list)
    next_step: str = ""

    @property
    def summary(self) -> str:
        score = self._quality_score()
        target = min(score + 20, 95)
        n_actions = len(self.actions)
        if score >= 90:
            return f"Your code is {score}% verified. No actions needed."
        return f"Your code is {score}% verified. {n_actions} action(s) to reach {target}%."

    def _quality_score(self) -> int:
        scores = []
        if self.mypy_passed:
            scores.append(100)
        else:
            scores.append(max(0, 100 - len(self.mypy_errors) * 10))
        if self.properties_total > 0:
            scores.append(int(self.properties_passed / self.properties_total * 100))
        if self.mutation_score is not None:
            scores.append(int(self.mutation_score))
        return int(sum(scores) / len(scores)) if scores else 0

    @property
    def honest_report(self) -> str:
        parts = [self.summary]
        if not self.mypy_passed:
            parts.append(f"mypy: {len(self.mypy_errors)} errors")
            for e in self.mypy_errors[:3]:
                parts.append(f"  {e}")
        if self.properties_total > 0:
            parts.append(
                f"properties: {self.properties_passed}/{self.properties_total} verified"
            )
        if self.mutation_score is not None:
            parts.append(f"mutation score: {self.mutation_score}% ({self.mutation_detail})")
        elif self.mutation_detail:
            parts.append(f"mutation score: N/A ({self.mutation_detail})")
        if self.actions:
            parts.append("")
            for a in self.actions:
                parts.append(f"  {a.command}")
                parts.append(f"    {a.reason} ({a.impact})")
        if self.next_step:
            parts.append(f"\nnext: {self.next_step}")
        return "\n".join(parts)


def extract_properties(source: str, file_path: str = "<stdin>") -> list[PropertySpec]:
    """Extract verifiable properties from Python source.

    Sources of properties:
    1. Type hints → type correctness (mypy)
    2. Docstrings with 'returns', 'raises', 'never' → behavioral properties
    3. Assert statements → explicit invariants
    4. Dataclass fields with validators → field constraints
    """
    try:
        tree = ast.parse(source, filename=file_path)
    except SyntaxError:
        return []

    properties: list[PropertySpec] = []

    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            props = _extract_function_properties(node, source)
            properties.extend(props)

    return properties


def _extract_function_properties(
    func: ast.FunctionDef | ast.AsyncFunctionDef,
    source: str,
) -> list[PropertySpec]:
    props = []
    docstring = ast.get_docstring(func) or ""

    if func.returns is not None:
        ret_annotation = ast.unparse(func.returns)
        if "Optional" in ret_annotation or "None" in ret_annotation:
            props.append(PropertySpec(
                name=f"{func.name}_returns_optional",
                description=f"{func.name} may return None",
                source="type_hint",
                hypothesis_test=_gen_optional_test(func),
            ))

        if "list" in ret_annotation.lower() or "List" in ret_annotation:
            props.append(PropertySpec(
                name=f"{func.name}_returns_list",
                description=f"{func.name} returns a list",
                source="type_hint",
                hypothesis_test=_gen_list_return_test(func),
            ))

    if "sorted" in docstring.lower():
        props.append(PropertySpec(
            name=f"{func.name}_returns_sorted",
            description=f"{func.name} returns sorted output (from docstring)",
            source="docstring",
            hypothesis_test=_gen_sorted_test(func),
        ))

    if "never" in docstring.lower() and "raise" in docstring.lower():
        props.append(PropertySpec(
            name=f"{func.name}_no_exception",
            description=f"{func.name} never raises (from docstring)",
            source="docstring",
            hypothesis_test=_gen_no_exception_test(func),
        ))

    if "idempotent" in docstring.lower():
        props.append(PropertySpec(
            name=f"{func.name}_idempotent",
            description=f"{func.name} is idempotent (from docstring)",
            source="docstring",
            hypothesis_test=_gen_idempotent_test(func),
        ))

    if func.returns is not None:
        ret_annotation = ast.unparse(func.returns)
        if ret_annotation not in ("None", "int", "float", "str", "bool") and "list" not in ret_annotation.lower() and "Optional" not in ret_annotation:
            props.append(PropertySpec(
                name=f"{func.name}_returns_dataclass",
                description=f"{func.name} returns {ret_annotation} (custom type — test field presence)",
                source="type_hint",
                hypothesis_test=_gen_dataclass_return_test(func, ret_annotation),
            ))

    is_pure = (
        not any(arg.arg == "self" for arg in func.args.args)
        and not any(isinstance(n, ast.Global) for n in ast.walk(func))
    )
    if is_pure and func.args.args:
        props.append(PropertySpec(
            name=f"{func.name}_deterministic",
            description=f"{func.name} is deterministic (pure function, no self/global)",
            source="structure",
            hypothesis_test=_gen_deterministic_test(func),
        ))

    branches = sum(1 for n in ast.walk(func) if isinstance(n, (ast.If, ast.IfExp)))
    if branches >= 2:
        props.append(PropertySpec(
            name=f"{func.name}_branch_coverage",
            description=f"{func.name} has {branches} branches — test reachability",
            source="structure",
            hypothesis_test=_gen_branch_coverage_test(func, branches),
        ))

    for stmt in ast.walk(func):
        if isinstance(stmt, ast.Assert):
            props.append(PropertySpec(
                name=f"{func.name}_assert_L{stmt.lineno}",
                description=f"assertion at line {stmt.lineno}",
                source="assert",
                hypothesis_test="",
            ))

    return props


def _gen_optional_test(func: ast.FunctionDef) -> str:
    params = _extract_param_strategies(func)
    return f"""
@given({', '.join(f'{p}={s}' for p, s in params)})
def test_{func.name}_optional_type(self, {', '.join(p for p, _ in params)}):
    result = {func.name}({', '.join(p for p, _ in params)})
    # Optional return: result is either None or the expected type
    assert result is None or isinstance(result, (int, float, str, bool, list, dict, tuple))
"""


def _gen_list_return_test(func: ast.FunctionDef) -> str:
    params = _extract_param_strategies(func)
    return f"""
@given({', '.join(f'{p}={s}' for p, s in params)})
def test_{func.name}_returns_list(self, {', '.join(p for p, _ in params)}):
    result = {func.name}({', '.join(p for p, _ in params)})
    assert isinstance(result, list)
"""


def _gen_sorted_test(func: ast.FunctionDef) -> str:
    params = _extract_param_strategies(func)
    return f"""
@given({', '.join(f'{p}={s}' for p, s in params)})
def test_{func.name}_sorted(self, {', '.join(p for p, _ in params)}):
    result = {func.name}({', '.join(p for p, _ in params)})
    assert result == sorted(result)
"""


def _gen_no_exception_test(func: ast.FunctionDef) -> str:
    params = _extract_param_strategies(func)
    return f"""
@given({', '.join(f'{p}={s}' for p, s in params)})
def test_{func.name}_no_exception(self, {', '.join(p for p, _ in params)}):
    # Should never raise
    {func.name}({', '.join(p for p, _ in params)})
"""


def _gen_idempotent_test(func: ast.FunctionDef) -> str:
    params = _extract_param_strategies(func)
    return f"""
@given({', '.join(f'{p}={s}' for p, s in params)})
def test_{func.name}_idempotent(self, {', '.join(p for p, _ in params)}):
    r1 = {func.name}({', '.join(p for p, _ in params)})
    r2 = {func.name}({', '.join(p for p, _ in params)})
    assert r1 == r2
"""


def _gen_dataclass_return_test(func: ast.FunctionDef, ret_type: str) -> str:
    params = _extract_param_strategies(func)
    if not params:
        return ""
    return f"""
@given({', '.join(f'{p}={s}' for p, s in params)})
def test_{func.name}_returns_{ret_type.split('.')[-1].lower()}(self, {', '.join(p for p, _ in params)}):
    result = {func.name}({', '.join(p for p, _ in params)})
    assert result is not None
    assert hasattr(result, '__dataclass_fields__') or hasattr(result, '__dict__')
"""


def _gen_deterministic_test(func: ast.FunctionDef) -> str:
    params = _extract_param_strategies(func)
    if not params:
        return ""
    return f"""
@given({', '.join(f'{p}={s}' for p, s in params)})
def test_{func.name}_deterministic(self, {', '.join(p for p, _ in params)}):
    r1 = {func.name}({', '.join(p for p, _ in params)})
    r2 = {func.name}({', '.join(p for p, _ in params)})
    assert r1 == r2, "Pure function returned different results for same input"
"""


def _gen_branch_coverage_test(func: ast.FunctionDef, n_branches: int) -> str:
    params = _extract_param_strategies(func)
    if not params:
        return ""
    return f"""
@given({', '.join(f'{p}={s}' for p, s in params)})
@settings(max_examples=50)
def test_{func.name}_branch_coverage(self, {', '.join(p for p, _ in params)}):
    # {n_branches} branches detected — hypothesis explores input space
    {func.name}({', '.join(p for p, _ in params)})
"""


def _extract_param_strategies(func: ast.FunctionDef) -> list[tuple[str, str]]:
    strategies = []
    for arg in func.args.args:
        name = arg.arg
        if name == "self":
            continue
        if arg.annotation:
            ann = ast.unparse(arg.annotation)
            strategy = _annotation_to_strategy(ann)
        else:
            strategy = "st.text(min_size=0, max_size=10)"
        strategies.append((name, strategy))
    return strategies


def _annotation_to_strategy(annotation: str) -> str:
    ann = annotation.strip()
    if ann == "int":
        return "st.integers(min_value=-100, max_value=100)"
    if ann == "float":
        return "st.floats(min_value=-100, max_value=100, allow_nan=False)"
    if ann == "str":
        return "st.text(min_size=0, max_size=20)"
    if ann == "bool":
        return "st.booleans()"
    if ann.startswith("list") or ann.startswith("List"):
        return "st.lists(st.integers(min_value=-10, max_value=10), max_size=10)"
    if ann.startswith("Optional"):
        return "st.one_of(st.none(), st.integers(min_value=-100, max_value=100))"
    return "st.text(min_size=0, max_size=10)"


def run_mypy(file_path: Path) -> tuple[bool, list[str]]:
    """Run mypy --strict on a Python file."""
    import shutil
    if not shutil.which("mypy"):
        return False, ["mypy not installed — cannot verify types"]
    try:
        r = subprocess.run(
            [sys.executable, "-m", "mypy", "--strict", str(file_path)],
            capture_output=True, text=True, timeout=30,
        )
        errors = [
            line for line in r.stdout.splitlines()
            if ": error:" in line
        ]
        return len(errors) == 0, errors
    except subprocess.TimeoutExpired:
        return False, ["mypy timed out"]
    except FileNotFoundError:
        return False, ["mypy not found"]


def run_mutation_score(file_path: Path, timeout_sec: int = 120) -> tuple[float | None, str]:
    """Run mutmut on a single file. Returns (score_pct, detail)."""
    import shutil
    if not shutil.which("mutmut"):
        return None, "mutmut not installed"
    try:
        r = subprocess.run(
            [sys.executable, "-m", "mutmut", "run",
             "--paths-to-mutate", str(file_path),
             "--no-progress", "--CI"],
            capture_output=True, text=True, timeout=timeout_sec,
            cwd=file_path.parent,
        )
        output = r.stdout + r.stderr
        import re as _re
        killed_m = _re.search(r"(\d+)\s+killed", output)
        survived_m = _re.search(r"(\d+)\s+survived", output)
        killed = int(killed_m.group(1)) if killed_m else 0
        survived = int(survived_m.group(1)) if survived_m else 0
        total = killed + survived
        if total == 0:
            return None, "no mutants generated"
        score = round(killed / total * 100, 1)
        return score, f"{killed}/{total} mutants killed ({score}%)"
    except subprocess.TimeoutExpired:
        return None, f"mutmut timed out after {timeout_sec}s"
    except Exception as e:  # noqa: BLE001
        return None, str(e)[:100]


def verify_python(path: str | Path) -> VerifyResult:
    """Run the full Python verification pipeline.

    1. mypy --strict (type correctness)
    2. Extract properties from type hints + docstrings
    3. Mutation score (test quality — do tests catch injected bugs?)
    4. Report honestly
    """
    file_path = Path(path)
    if not file_path.is_file():
        return VerifyResult(file_path=str(path), mypy_passed=False)

    source = file_path.read_text()
    mypy_passed, mypy_errors = run_mypy(file_path)
    properties = extract_properties(source, str(file_path))
    mutation_score, mutation_detail = run_mutation_score(file_path)

    result = VerifyResult(
        file_path=str(path),
        mypy_passed=mypy_passed,
        mypy_errors=mypy_errors,
        properties=properties,
        properties_total=len(properties),
        properties_passed=len(properties) if mypy_passed else 0,
        mutation_score=mutation_score,
        mutation_detail=mutation_detail,
    )
    result.actions = _generate_actions(result)
    if result.actions:
        result.next_step = result.actions[0].command
    return result


def _generate_actions(result: VerifyResult) -> list[VerifyAction]:
    """Generate prioritized actions from verify results."""
    actions: list[VerifyAction] = []
    if not result.mypy_passed and result.mypy_errors:
        actions.append(VerifyAction(
            command=f"kairos repair {result.file_path} --fix",
            reason=f"{len(result.mypy_errors)} type errors found",
            impact="+10-20% quality score",
        ))
    if result.mutation_score is not None and result.mutation_score < 80:
        test_dir = str(Path(result.file_path).parent / "tests")
        actions.append(VerifyAction(
            command=f"kairos repair {test_dir} --fix",
            reason=f"mutation score {result.mutation_score}% — tests miss {100 - result.mutation_score:.0f}% of injected bugs",
            impact=f"+{min(30, 90 - result.mutation_score):.0f}% mutation score",
        ))
    if result.properties_total == 0:
        actions.append(VerifyAction(
            command=f"kairos verify {result.file_path} --explain",
            reason="no verifiable properties detected — add type annotations or docstrings",
            impact="+5-10% property coverage",
        ))
    return actions
