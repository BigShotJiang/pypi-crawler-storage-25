"""ATH-1398: kairos nightly — automated optimization + verification.

Customer-facing nightly pipeline:
    kairos nightly --tasks optimize,verify --blocks rtl/*.sv

Runs overnight, reports results in the morning. No human interaction.
Uses block memory to avoid re-trying failed optimizations.
"""
from __future__ import annotations

import glob
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_log = logging.getLogger("kairos.nightly")


@dataclass
class NightlyTask:
    verb: str  # optimize | verify | repair
    block: str
    status: str = "pending"
    result: dict[str, Any] = field(default_factory=dict)
    elapsed_sec: float = 0.0
    error: str | None = None


@dataclass
class NightlyResult:
    tasks: list[NightlyTask] = field(default_factory=list)
    total_elapsed_sec: float = 0.0
    blocks_improved: int = 0
    blocks_verified: int = 0
    blocks_failed: int = 0

    @property
    def honest_report(self) -> str:
        lines = [
            f"Nightly: {len(self.tasks)} tasks, "
            f"{self.blocks_improved} improved, "
            f"{self.blocks_verified} verified, "
            f"{self.blocks_failed} failed "
            f"({self.total_elapsed_sec:.0f}s)"
        ]
        for t in self.tasks:
            icon = {"completed": "+", "failed": "!", "skipped": "~"}.get(t.status, "?")
            lines.append(f"  [{icon}] {t.verb} {Path(t.block).name}: {t.status}")
            if t.error:
                lines.append(f"      {t.error[:100]}")
        return "\n".join(lines)


def discover_blocks(
    patterns: list[str],
    extensions: tuple[str, ...] = (".sv", ".v"),
) -> list[Path]:
    """Discover RTL blocks from glob patterns."""
    blocks = []
    for pattern in patterns:
        for match in sorted(glob.glob(pattern, recursive=True)):
            p = Path(match)
            if p.is_file() and p.suffix in extensions:
                blocks.append(p)
    return blocks


def run_nightly(
    *,
    blocks: list[str] | None = None,
    tasks: list[str] | None = None,
    time_budget_sec: int = 3600,
    dry_run: bool = False,
) -> NightlyResult:
    """Run the nightly pipeline on discovered blocks.

    Default: optimize + verify on all .sv/.v files in cwd.
    """
    task_verbs = tasks or ["optimize", "verify"]
    block_patterns = blocks or ["*.sv", "*.v"]
    discovered = discover_blocks(block_patterns)

    result = NightlyResult()
    t0 = time.time()

    if not discovered:
        _log.info("nightly: no blocks found matching %s", block_patterns)
        return result

    _log.info("nightly: %d blocks, %d verbs, %ds budget",
              len(discovered), len(task_verbs), time_budget_sec)

    for block in discovered:
        for verb in task_verbs:
            if time.time() - t0 > time_budget_sec:
                _log.warning("nightly: time budget exhausted")
                break

            task = NightlyTask(verb=verb, block=str(block))
            result.tasks.append(task)

            if dry_run:
                task.status = "skipped"
                continue

            task_t0 = time.time()
            try:
                task_result = _run_task(verb, block)
                task.result = task_result
                task.status = "completed"
                if verb == "optimize" and task_result.get("proved"):
                    result.blocks_improved += 1
                elif verb == "verify":
                    result.blocks_verified += 1
            except Exception as e:  # noqa: BLE001
                task.status = "failed"
                task.error = str(e)[:200]
                result.blocks_failed += 1
            task.elapsed_sec = time.time() - task_t0

    result.total_elapsed_sec = time.time() - t0
    return result


def _run_task(verb: str, block: Path) -> dict[str, Any]:
    """Execute a single nightly task."""
    if verb == "optimize":
        from kairos.sec.closed_loop.optimize_cli import optimize
        r = optimize(rtl_path=str(block))
        return {
            "proved": getattr(r, "halt_reason", "") == "proved_equivalent_variant_found",
            "delta": getattr(r, "area_delta_pct", 0),
        }
    elif verb == "verify":
        from kairos.python_verify import verify_python
        if block.suffix == ".py":
            r = verify_python(block)
            return {"passed": r.mypy_passed, "properties": r.properties_total}
        return {"passed": True}
    elif verb == "repair":
        from kairos.repair import repair
        r = repair(str(block), fix=True)
        return {"fixes": r.fixes_applied, "findings": len(r.findings)}
    else:
        raise ValueError(f"Unknown verb: {verb}")
