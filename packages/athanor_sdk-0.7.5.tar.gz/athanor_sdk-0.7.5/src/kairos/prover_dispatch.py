"""ATH-1463 B1: Property-type-aware prover dispatch.

Extends the file-format dispatch (sv/dispatch.py) with property-type
routing. Instead of routing by file extension alone, routes by what
the property is ABOUT:

- Temporal assertions (always, eventually) -> EBMC k-induction
- Combinational equivalence -> yosys equiv
- Arithmetic/algebraic properties -> Lean + Pythia
- Protocol invariants -> Dafny + Z3
- Data structure properties -> Verus

Simple dict, not a plugin system. Under 150 lines or kill it.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class PropertyType(Enum):
    TEMPORAL = auto()
    COMBINATIONAL = auto()
    ARITHMETIC = auto()
    PROTOCOL = auto()
    DATA_STRUCTURE = auto()
    TYPE_SAFETY = auto()
    UNKNOWN = auto()


@dataclass(frozen=True)
class ProverRoute:
    engine: str
    mode: str = ""
    fallback: str | None = None


PROPERTY_DISPATCH: dict[PropertyType, ProverRoute] = {
    PropertyType.TEMPORAL: ProverRoute(
        engine="ebmc", mode="k_induction", fallback="ebmc_bmc",
    ),
    PropertyType.COMBINATIONAL: ProverRoute(
        engine="yosys_equiv", fallback="ebmc_bmc",
    ),
    PropertyType.ARITHMETIC: ProverRoute(
        engine="lean", mode="pythia", fallback="z3",
    ),
    PropertyType.PROTOCOL: ProverRoute(
        engine="dafny", fallback="z3",
    ),
    PropertyType.DATA_STRUCTURE: ProverRoute(
        engine="verus", fallback="lean",
    ),
    PropertyType.TYPE_SAFETY: ProverRoute(
        engine="mypy", fallback="verus",
    ),
    PropertyType.UNKNOWN: ProverRoute(
        engine="ebmc", mode="bmc",
    ),
}


_TEMPORAL_KEYWORDS = frozenset({
    "always", "eventually", "until", "next", "posedge", "negedge",
    "assert property", "cover property", "assume property",
    "##", "|->", "|=>", "@(",
})

_ARITHMETIC_KEYWORDS = frozenset({
    "nat.add", "nat.mul", "int.add", " mod ", " div ", "gcd(",
    "inequality", "≤", "≥", "∀", "∃",
    "concentration", "tail_bound", "sub_gaussian",
    "forall", "exists",
})

_PROTOCOL_KEYWORDS = frozenset({
    "invariant", "fairness", "liveness", "starvation",
    "deadlock", "mutual_exclusion", "progress",
    "congestion", "flow_control", "ack",
})

_DATA_STRUCTURE_KEYWORDS = frozenset({
    "vec", "hashmap", "btree", "list", "queue", "stack",
    "push", "pop", "insert", "delete", "contains",
    "sorted", "balanced", "capacity",
})


def classify_property(text: str) -> PropertyType:
    """Classify a property/assertion by its content."""
    lower = text.lower()

    for kw in _TEMPORAL_KEYWORDS:
        if kw in lower:
            return PropertyType.TEMPORAL

    for kw in _ARITHMETIC_KEYWORDS:
        if kw in lower:
            return PropertyType.ARITHMETIC

    for kw in _PROTOCOL_KEYWORDS:
        if kw in lower:
            return PropertyType.PROTOCOL

    for kw in _DATA_STRUCTURE_KEYWORDS:
        if kw in lower:
            return PropertyType.DATA_STRUCTURE

    if "type" in lower or "mypy" in lower or "annotation" in lower:
        return PropertyType.TYPE_SAFETY

    if ".sv" in lower or ".v" in lower or "module" in lower:
        return PropertyType.COMBINATIONAL

    return PropertyType.UNKNOWN


def route_property(text: str) -> ProverRoute:
    """Route a property to the best prover based on content classification."""
    prop_type = classify_property(text)
    return PROPERTY_DISPATCH[prop_type]


__all__ = [
    "PropertyType",
    "ProverRoute",
    "PROPERTY_DISPATCH",
    "classify_property",
    "route_property",
]
