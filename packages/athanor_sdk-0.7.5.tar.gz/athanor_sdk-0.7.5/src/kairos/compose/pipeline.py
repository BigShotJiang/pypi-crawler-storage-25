"""ATH-1397: compose pipeline — cross-module interface verification.

Takes a top module + sub-modules, auto-detects interfaces between them,
verifies port compatibility (width, direction, connectivity).

Key invariant (per design review): NEVER false-positive. Better to
report 'cannot verify' than to claim safe when unsound.
"""
from __future__ import annotations

import logging
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from kairos.security.env_allowlist import safe_env_for_yosys
from kairos.security.path_sanitizer import build_yosys_inc_flags, sanitize_yosys_path

_log = logging.getLogger("kairos.compose")


@dataclass(frozen=True)
class PortInfo:
    """A module port."""
    name: str
    direction: str
    width: int


@dataclass(frozen=True)
class InterfaceMismatch:
    """A detected interface incompatibility."""
    source_module: str
    source_port: str
    target_module: str
    target_port: str
    reason: str
    severity: str = "error"


@dataclass(frozen=True)
class ComposeResult:
    """Full composition verification output."""
    top_module: str
    sub_modules: list[str] = field(default_factory=list)
    mismatches: list[InterfaceMismatch] = field(default_factory=list)
    unconnected: list[str] = field(default_factory=list)
    verified: bool = False
    error: str | None = None


def _extract_all_ports_yosys(
    sv_paths: list[Path],
    top_module: str,
) -> dict[str, list[PortInfo]]:
    """Extract port info for all modules via yosys JSON export."""
    yosys = shutil.which("yosys")
    if not yosys:
        return {}

    import tempfile
    json_out = Path(tempfile.mkstemp(suffix=".json")[1])
    for p in sv_paths:
        sanitize_yosys_path(p)
    inc_flags = build_yosys_inc_flags(sv_paths)
    inc_prefix = f"{inc_flags} " if inc_flags else ""
    files_str = " ".join(str(p) for p in sv_paths)
    try:
        result = subprocess.run(
            [yosys, "-p",
             f"read_verilog -sv {inc_prefix}{files_str}; "
             f"hierarchy -check -top {top_module}; "
             f"proc; write_json {json_out}"],
            capture_output=True, text=True, timeout=30,
            env=safe_env_for_yosys(),
        )
        if result.returncode != 0 or not json_out.is_file():
            return {}

        import json
        data = json.loads(json_out.read_text())
        all_ports: dict[str, list[PortInfo]] = {}
        for mod_name, mod_data in data.get("modules", {}).items():
            ports = []
            for pn, pi in mod_data.get("ports", {}).items():
                ports.append(PortInfo(
                    name=pn,
                    direction=pi.get("direction", "unknown"),
                    width=len(pi.get("bits", [])),
                ))
            all_ports[mod_name] = ports
        return all_ports
    except Exception:  # noqa: BLE001
        return {}
    finally:
        json_out.unlink(missing_ok=True)


def _extract_module_names(rtl_text: str) -> list[str]:
    """Extract all module names from RTL source."""
    return re.findall(r"^\s*module\s+(\w+)", rtl_text, re.MULTILINE)


def _detect_instantiations(rtl_text: str, module_name: str) -> list[str]:
    """Detect which sub-modules are instantiated in a given module."""
    instantiated: list[str] = []
    for m in re.finditer(r"(\w+)\s+\w+\s*\(", rtl_text):
        inst_name = m.group(1)
        if inst_name not in ("module", "assign", "always", "initial",
                             "if", "else", "begin", "end", "case",
                             "input", "output", "inout", "wire", "reg",
                             "logic", "parameter", "localparam"):
            if inst_name != module_name:
                instantiated.append(inst_name)
    return list(set(instantiated))


def _check_port_compatibility(
    parent_ports: list[PortInfo],
    child_ports: list[PortInfo],
    parent_name: str,
    child_name: str,
) -> list[InterfaceMismatch]:
    """Check for width mismatches between connected ports."""
    mismatches: list[InterfaceMismatch] = []
    child_by_name = {p.name: p for p in child_ports}

    for pp in parent_ports:
        if pp.name in child_by_name:
            cp = child_by_name[pp.name]
            if pp.width != cp.width:
                mismatches.append(InterfaceMismatch(
                    source_module=parent_name,
                    source_port=pp.name,
                    target_module=child_name,
                    target_port=cp.name,
                    reason=f"width mismatch: {parent_name}.{pp.name}[{pp.width}] vs {child_name}.{cp.name}[{cp.width}]",
                ))
    return mismatches


def compose(
    *rtl_paths: str | Path,
    top_module: str | None = None,
) -> ComposeResult:
    """Verify cross-module interface compatibility.

    Args:
        rtl_paths: Paths to RTL source files (top module first).
        top_module: Top module name. Auto-detected from first file if None.

    Returns:
        ComposeResult with mismatches, unconnected ports, and verdict.
    """
    if not rtl_paths:
        return ComposeResult(top_module="", error="No RTL files provided")

    paths = [Path(p) for p in rtl_paths]
    for p in paths:
        if not p.is_file():
            return ComposeResult(top_module=top_module or "", error=f"File not found: {p}")

    if top_module is None:
        from kairos.sec.closed_loop.optimize_cli import auto_extract_module_name
        top_module = auto_extract_module_name(paths[0].read_text())
        if not top_module:
            return ComposeResult(top_module="", error="No module declaration found in first file")

    _log.info(f"Composing {top_module} from {len(paths)} files")

    all_modules = _extract_all_ports_yosys(paths, top_module)
    for mod_name, ports in all_modules.items():
        _log.info(f"  {mod_name}: {len(ports)} ports")

    if top_module not in all_modules:
        return ComposeResult(
            top_module=top_module,
            sub_modules=list(all_modules.keys()),
            error=f"Top module {top_module} not found or yosys elaboration failed",
        )

    top_text = paths[0].read_text()
    instantiated = _detect_instantiations(top_text, top_module)
    sub_modules = [m for m in instantiated if m in all_modules]

    mismatches: list[InterfaceMismatch] = []
    for sub in sub_modules:
        mm = _check_port_compatibility(
            all_modules[top_module], all_modules[sub],
            top_module, sub,
        )
        mismatches.extend(mm)

    unconnected = [m for m in instantiated if m not in all_modules]

    verified = len(mismatches) == 0 and len(unconnected) == 0

    _log.info(f"Result: {'PASS' if verified else 'FAIL'} — {len(mismatches)} mismatches, {len(unconnected)} unresolved")

    return ComposeResult(
        top_module=top_module,
        sub_modules=sub_modules,
        mismatches=mismatches,
        unconnected=unconnected,
        verified=verified,
    )


__all__ = ["compose", "ComposeResult", "InterfaceMismatch"]
