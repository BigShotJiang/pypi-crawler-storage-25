"""kairos.compose — cross-module interface verification (ATH-1397).

Customer flow:
    kairos compose top.sv alu.sv regfile.sv

Auto-detects module boundaries, extracts interface signals, verifies
port width/direction compatibility, checks for unconnected ports.
Never false-positive (per design review: better to say 'cannot verify'
than to overclaim).
"""
from __future__ import annotations

from kairos.compose.pipeline import compose, ComposeResult, InterfaceMismatch

__all__ = ["compose", "ComposeResult", "InterfaceMismatch"]
