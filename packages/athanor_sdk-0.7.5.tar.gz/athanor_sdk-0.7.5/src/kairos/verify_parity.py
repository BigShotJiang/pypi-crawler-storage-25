"""kairos verify --parity — measure Python/Rust verification gap.

Compares what each verification layer covers for Python vs what
Verus+Lean provides for Rust. Reports the gap: properties that Rust
has formal proofs for but Python has no coverage.

Verification layers (Python → Rust equivalent):
  mypy          → Rust type system (stronger: lifetimes, ownership)
  hypothesis    → proptests (equivalent)
  mutation test → mutation test (equivalent)
  symbolic exec → Verus assertions (weaker: AST vs SMT)
  (missing)     → Verus pre/post conditions
  (missing)     → Verus loop invariants
  (missing)     → Verus ownership proofs

The gap = what Verus covers that Python layers don't.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class PropertyCoverage:
    """What a single function has verified."""
    name: str
    file: str
    line: int
    has_type_annotations: bool = False
    has_return_type: bool = False
    has_docstring: bool = False
    has_proptests: bool = False
    has_assertions: bool = False
    has_bounds_checks: bool = False
    has_none_guards: bool = False
    has_error_handling: bool = False
    has_input_validation: bool = False

    @property
    def coverage_score(self) -> float:
        checks = [
            self.has_type_annotations,
            self.has_return_type,
            self.has_proptests,
            self.has_assertions,
            self.has_bounds_checks,
            self.has_none_guards,
            self.has_error_handling,
            self.has_input_validation,
        ]
        return sum(checks) / len(checks) if checks else 0.0

    @property
    def missing_layers(self) -> list[str]:
        gaps = []
        if not self.has_type_annotations:
            gaps.append("type annotations (Rust: enforced by compiler)")
        if not self.has_return_type:
            gaps.append("return type (Rust: required)")
        if not self.has_assertions:
            gaps.append("assertions (Verus: pre/post conditions)")
        if not self.has_bounds_checks:
            gaps.append("bounds checks (Verus: overflow proofs)")
        if not self.has_none_guards:
            gaps.append("None guards (Rust: Option<T> forces handling)")
        if not self.has_input_validation:
            gaps.append("input validation (Verus: requires clauses)")
        return gaps


@dataclass
class ParityResult:
    path: str
    functions_analyzed: int = 0
    avg_coverage: float = 0.0
    functions: list[PropertyCoverage] = field(default_factory=list)
    error: str | None = None

    @property
    def parity_score(self) -> float:
        if not self.functions:
            return 0.0
        return sum(f.coverage_score for f in self.functions) / len(self.functions)

    @property
    def gap_summary(self) -> dict[str, int]:
        gaps: dict[str, int] = {}
        for f in self.functions:
            for g in f.missing_layers:
                key = g.split(" (")[0]
                gaps[key] = gaps.get(key, 0) + 1
        return dict(sorted(gaps.items(), key=lambda x: -x[1]))

    def summary(self) -> str:
        lines = [f"Parity: {self.path}"]
        if self.error:
            lines.append(f"  Error: {self.error}")
            return "\n".join(lines)
        lines.append(f"  Functions: {self.functions_analyzed}")
        lines.append(f"  Parity score: {self.parity_score:.0%} (100% = Rust-equivalent coverage)")
        lines.append(f"  Gap breakdown:")
        for gap, count in self.gap_summary.items():
            lines.append(f"    {count}/{self.functions_analyzed} missing {gap}")

        worst = sorted(self.functions, key=lambda f: f.coverage_score)[:5]
        if worst:
            lines.append(f"  Lowest coverage functions:")
            for f in worst:
                lines.append(f"    {f.name} ({f.coverage_score:.0%}) — L{f.line}")

        return "\n".join(lines)


def _analyze_function(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    file_path: str,
    test_content: str,
) -> PropertyCoverage:
    """Analyze a single function's verification coverage."""
    cov = PropertyCoverage(
        name=node.name,
        file=file_path,
        line=node.lineno,
    )

    annotated_args = sum(1 for a in node.args.args if a.annotation and a.arg != "self")
    total_args = sum(1 for a in node.args.args if a.arg != "self")
    cov.has_type_annotations = annotated_args == total_args and total_args > 0
    cov.has_return_type = node.returns is not None
    cov.has_docstring = ast.get_docstring(node) is not None

    cov.has_proptests = f"test_{node.name}" in test_content or f"test_{node.name.lstrip('_')}" in test_content

    for child in ast.walk(node):
        if isinstance(child, ast.Assert):
            cov.has_assertions = True
        if isinstance(child, ast.If):
            test_str = ast.unparse(child.test) if child.test else ""
            if "is None" in test_str or "is not None" in test_str:
                cov.has_none_guards = True
            if any(op in test_str for op in ("< 0", "> 0", "<= 0", ">= 0", "< len", "> len")):
                cov.has_bounds_checks = True
        if isinstance(child, ast.Raise):
            cov.has_error_handling = True
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)) and child is not node:
            break

    for child in ast.walk(node):
        if isinstance(child, ast.If) and child.lineno <= node.lineno + 5:
            test_str = ast.unparse(child.test)
            if "not " in test_str and ("isinstance" in test_str or "is_file" in test_str or "exists" in test_str):
                cov.has_input_validation = True
            if "raise" in ast.unparse(child):
                cov.has_input_validation = True

    return cov


def verify_parity(
    path: str | Path,
    tests_dir: str | Path = "tests",
) -> ParityResult:
    """Measure Python verification coverage vs Rust/Verus baseline."""
    target = Path(path)
    if not target.is_file():
        return ParityResult(path=str(path), error=f"File not found: {path}")
    if target.suffix != ".py":
        return ParityResult(path=str(path), error=f"Not a Python file: {path}")

    try:
        source = target.read_text()
        tree = ast.parse(source)
    except SyntaxError as e:
        return ParityResult(path=str(path), error=f"Syntax error: {e}")

    test_content = ""
    tests_path = Path(tests_dir)
    if tests_path.is_dir():
        for tf in tests_path.glob("test_*.py"):
            test_content += tf.read_text()

    result = ParityResult(path=str(path))
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name.startswith("_"):
                continue
            cov = _analyze_function(node, str(target), test_content)
            result.functions.append(cov)
            result.functions_analyzed += 1

    return result


def verify_parity_dir(
    src_dir: str | Path = "src/kairos",
    tests_dir: str | Path = "tests",
) -> ParityResult:
    """Measure parity across all Python files in a directory."""
    src = Path(src_dir)
    tests = Path(tests_dir)

    if not src.is_dir():
        return ParityResult(path=str(src_dir), error=f"Directory not found: {src_dir}")

    all_functions: list[PropertyCoverage] = []
    files_checked = 0

    for py_file in sorted(src.rglob("*.py")):
        if "__pycache__" in str(py_file) or py_file.name.startswith("_"):
            continue
        r = verify_parity(py_file, tests_dir=tests)
        if r.functions:
            all_functions.extend(r.functions)
            files_checked += 1

    result = ParityResult(
        path=str(src_dir),
        functions_analyzed=len(all_functions),
        functions=all_functions,
    )
    return result


def generate_gap_fixes(result: ParityResult, max_fixes: int = 20) -> list[GapFix]:
    """Generate specific, actionable fixes to close the parity gap."""
    fixes: list[GapFix] = []
    worst = sorted(result.functions, key=lambda f: f.coverage_score)

    for func in worst[:max_fixes]:
        if func.coverage_score >= 1.0:
            continue
        if not func.has_type_annotations:
            fixes.append(GapFix(
                function=func.name,
                file=func.file,
                line=func.line,
                category="type_annotations",
                rust_equivalent="Rust: all parameters have mandatory types",
                fix=f"Add type annotations to all parameters in {func.name}",
                priority="high" if not func.has_return_type else "medium",
            ))
        if not func.has_assertions:
            fixes.append(GapFix(
                function=func.name,
                file=func.file,
                line=func.line,
                category="preconditions",
                rust_equivalent="Verus: requires/ensures clauses",
                fix=f"Add assert statements for preconditions in {func.name}",
                priority="high",
            ))
        if not func.has_input_validation:
            fixes.append(GapFix(
                function=func.name,
                file=func.file,
                line=func.line,
                category="input_validation",
                rust_equivalent="Verus: requires clause + type system",
                fix=f"Add input validation (type/range checks) at entry of {func.name}",
                priority="high",
            ))
        if not func.has_none_guards and func.has_type_annotations:
            fixes.append(GapFix(
                function=func.name,
                file=func.file,
                line=func.line,
                category="null_safety",
                rust_equivalent="Rust: Option<T> forces match/unwrap",
                fix=f"Add None guards for Optional parameters in {func.name}",
                priority="medium",
            ))

    return sorted(fixes, key=lambda f: (0 if f.priority == "high" else 1, f.file, f.line))


@dataclass
class GapFix:
    function: str
    file: str
    line: int
    category: str
    rust_equivalent: str
    fix: str
    priority: str = "medium"
