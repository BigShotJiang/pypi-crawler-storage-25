"""ATH-1085 -- best-variant selector for compound optimization.

After compound optimization runs n rounds, the *last* round is not
necessarily the best.  This module picks the best variant: lowest
cell count among iterations that are PROVED EQUIVALENT (outcome ==
"accepted" AND property_verdicts all PROVED/PASS).

Two public helpers:

* ``select_best_variant(summaries)`` -- returns the best summary dict
  (or ``None`` when no proved variant exists).
* ``format_variant_report(summaries, best)`` -- honest plain-text
  report showing every variant + why ``best`` was chosen.
"""
from __future__ import annotations

from typing import Any


def _is_proved(summary: dict[str, Any]) -> bool:
    """Return True when a summary represents a formally proved variant.

    Proved means:
    1. outcome == "accepted"
    2. property_verdicts is non-empty and every verdict is PROVED or PASS

    This mirrors the ATH-1435 guard in the compound-loop gold
    replacement path (cli.py) -- same two conditions.
    """
    if summary.get("outcome") != "accepted":
        return False
    verdicts = summary.get("property_verdicts", {})
    if not verdicts:
        # No explicit verdicts but accepted -- treat as proved
        # (matches yosys-equiv path where verdicts dict may be empty
        # but outcome is "accepted" only on proven equivalence).
        return True
    return all(
        v.upper() in ("PROVED", "PASS")
        for v in verdicts.values()
    )


def select_best_variant(
    summaries: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Pick the best variant from a list of iteration summaries.

    "Best" = lowest ``gate_cells`` among variants where
    :func:`_is_proved` is True.  When ``gate_cells`` is missing or
    ``None``, falls back to ``measured_delta_pct`` (most negative wins).

    Returns ``None`` when no proved variant exists.
    """
    proved = [s for s in summaries if _is_proved(s)]
    if not proved:
        return None

    def _sort_key(s: dict[str, Any]) -> tuple[float, float]:
        # Primary: lowest gate_cells.  Secondary: most negative delta.
        gate = s.get("gate_cells")
        delta = s.get("measured_delta_pct", 0.0) or 0.0
        # Use a large sentinel when gate_cells is absent so those
        # entries sort last within the proved set.
        return (float(gate) if gate is not None else 1e18, delta)

    return min(proved, key=_sort_key)


def format_variant_report(
    summaries: list[dict[str, Any]],
    best: dict[str, Any] | None,
) -> str:
    """Build an honest plain-text report for all variants.

    The report lists every iteration with its outcome, cell counts,
    delta, and whether it was proved.  The chosen best variant is
    annotated with ``<-- BEST``.

    When ``best`` is ``None`` (no proved variant), the footer says so
    explicitly.
    """
    lines: list[str] = []
    lines.append("=== Variant Selection Report (ATH-1085) ===")
    lines.append("")
    lines.append(f"Total variants evaluated: {len(summaries)}")
    n_proved = sum(1 for s in summaries if _is_proved(s))
    lines.append(f"Proved equivalent: {n_proved}")
    lines.append("")

    hdr = f"{'Idx':>4}  {'Outcome':<14}  {'Gold':>6}  {'Gate':>6}  {'Delta':>8}  {'Proved':>6}  {'Transform'}"
    lines.append(hdr)
    lines.append("-" * len(hdr))

    for s in summaries:
        idx = s.get("iteration_index", "?")
        outcome = s.get("outcome", "?")
        gold = s.get("gold_cells", "-")
        gate = s.get("gate_cells", "-")
        delta = s.get("measured_delta_pct", s.get("claimed_area_delta_pct", "-"))
        if isinstance(delta, (int, float)):
            delta_str = f"{delta:+.1f}%"
        else:
            delta_str = str(delta)
        proved = "yes" if _is_proved(s) else "no"
        transform = s.get("transformation_class", "?")
        marker = "  <-- BEST" if (best is not None and s is best) else ""
        lines.append(
            f"{idx!s:>4}  {outcome:<14}  {gold!s:>6}  {gate!s:>6}  {delta_str:>8}  {proved:>6}  {transform}{marker}"
        )

    lines.append("")
    if best is not None:
        best_gate = best.get("gate_cells", "?")
        best_delta = best.get("measured_delta_pct", "?")
        best_idx = best.get("iteration_index", "?")
        lines.append(
            f"Selected: iteration {best_idx} "
            f"({best_gate} cells, {best_delta}% delta) -- "
            f"lowest cell count among proved-equivalent variants."
        )
    else:
        lines.append(
            "No proved-equivalent variant found. "
            "Cannot select a best variant without formal proof."
        )

    return "\n".join(lines)
