"""kairos.plan — planning stage for optimize and repair.

Before execution: analyze, strategize, present plan.
After execution: compare result to plan, verify claims.

The plan is the forcing function that prevents overclaiming.
The agent COMMITS to a plan. The plan is REVIEWABLE.
The result is COMPARED to the plan.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class OptimizePlan:
    block_name: str
    block_class: str
    line_count: int
    port_count: int
    is_sequential: bool
    strategies: list[str] = field(default_factory=list)
    expected_reduction_pct: float = 0.0
    risks: list[str] = field(default_factory=list)
    confidence: str = "medium"

    def summary(self) -> str:
        lines = [
            f"Plan: optimize {self.block_name}",
            f"  Class: {self.block_class} ({'sequential' if self.is_sequential else 'combinational'})",
            f"  Size: {self.line_count} lines, {self.port_count} ports",
            f"  Strategies: {', '.join(self.strategies)}",
            f"  Expected reduction: {self.expected_reduction_pct:.1f}%",
            f"  Confidence: {self.confidence}",
        ]
        if self.risks:
            lines.append(f"  Risks: {'; '.join(self.risks)}")
        return "\n".join(lines)


@dataclass
class RepairPlan:
    target_path: str
    findings_count: int
    fixable_count: int
    categories: list[str] = field(default_factory=list)
    estimated_fixes: int = 0
    risks: list[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [
            f"Plan: repair {self.target_path}",
            f"  Findings: {self.findings_count} ({self.fixable_count} fixable)",
            f"  Categories: {', '.join(self.categories)}",
            f"  Estimated fixes: {self.estimated_fixes}",
        ]
        if self.risks:
            lines.append(f"  Risks: {'; '.join(self.risks)}")
        return "\n".join(lines)


@dataclass
class PlanResult:
    planned: str
    actual: str
    achieved: bool
    delta: str = ""

    def comparison(self) -> str:
        icon = "+" if self.achieved else "!"
        return f"[{icon}] Planned: {self.planned} | Actual: {self.actual} | {self.delta}"


def plan_optimize(rtl_path: str | Path) -> OptimizePlan:
    """Analyze an RTL file and generate an optimization plan."""
    target = Path(rtl_path)
    if not target.is_file():
        return OptimizePlan(
            block_name=target.stem,
            block_class="unknown",
            line_count=0,
            port_count=0,
            is_sequential=False,
            risks=["file not found"],
        )

    content = target.read_text()
    lines = content.splitlines()
    line_count = len(lines)

    is_sequential = any(
        "posedge" in l or "negedge" in l or "always @(" in l
        for l in lines
    )

    port_count = sum(1 for l in lines if any(
        kw in l for kw in ("input", "output", "inout")
    ))

    if line_count < 50:
        block_class = "small"
        expected = -5.0
        confidence = "high"
        strategies = ["constant folding", "dead code elimination"]
    elif line_count < 200:
        block_class = "medium"
        expected = -3.0
        confidence = "medium"
        strategies = ["encoding swap", "structural sharing", "gate optimization"]
    else:
        block_class = "large"
        expected = -1.0
        confidence = "low"
        strategies = ["hierarchical decomposition", "targeted local optimization"]

    if is_sequential:
        strategies.append("register sharing")
        strategies.append("clock gating candidates")

    risks = []
    if line_count > 500:
        risks.append("file exceeds review limit — may need decomposition first")
    if port_count > 20:
        risks.append("high port count — interface-preserving constraint is tight")

    return OptimizePlan(
        block_name=target.stem,
        block_class=block_class,
        line_count=line_count,
        port_count=port_count,
        is_sequential=is_sequential,
        strategies=strategies,
        expected_reduction_pct=expected,
        risks=risks,
        confidence=confidence,
    )


def plan_repair(target_path: str | Path, findings: list[Any]) -> RepairPlan:
    """Generate a repair plan from review findings."""
    categories = list({f.category for f in findings if hasattr(f, "category")})
    fixable = [f for f in findings if hasattr(f, "severity") and f.severity in ("critical", "high", "medium")]

    risks = []
    if len(findings) > 10:
        risks.append("many findings — fixes may interact")
    if "security" in categories:
        risks.append("security findings require careful verification")

    return RepairPlan(
        target_path=str(target_path),
        findings_count=len(findings),
        fixable_count=len(fixable),
        categories=categories,
        estimated_fixes=len(fixable),
        risks=risks,
    )


def compare_plan_to_result(
    plan_description: str,
    actual_description: str,
    achieved: bool,
) -> PlanResult:
    """Compare planned outcome to actual result."""
    if achieved:
        delta = "plan achieved"
    else:
        delta = "plan NOT achieved — investigate why"
    return PlanResult(
        planned=plan_description,
        actual=actual_description,
        achieved=achieved,
        delta=delta,
    )
