"""kairos.claim_verifier — verify completion claims before reporting.

ATH-1447: Do not say done unless verified. Every claim about what kairos
achieved must be independently checkable. This module provides the
verification functions that run AFTER execution to confirm claims.

The pattern: execute -> claim -> verify claim -> report honestly.
If verify fails: report what actually happened, not what was planned.

Sign convention: delta is negative for area reduction (gate < gold).
  actual_delta = (gate_cells - gold_cells) / gold_cells * 100
  So -3.4% means gate is 3.4% smaller than gold.

Overclaim policy: a claim is rejected if the claimed magnitude
exceeds actual by more than OVERCLAIM_FACTOR (default 1.5x) AND
the absolute difference exceeds OVERCLAIM_ABS_THRESHOLD (default 2.0%).
These thresholds are configurable. Underclaiming (actual better than
claimed) is NOT flagged — conservative claims are acceptable.
"""
from __future__ import annotations

from dataclasses import dataclass

OVERCLAIM_FACTOR: float = 1.5
OVERCLAIM_ABS_THRESHOLD: float = 2.0


@dataclass
class ClaimVerdict:
    claim: str
    verified: bool
    evidence: str
    honest_report: str


def verify_optimization_claim(
    claimed_delta_pct: float,
    gold_cells: int | None,
    gate_cells: int | None,
    proved: bool,
    *,
    overclaim_factor: float = OVERCLAIM_FACTOR,
    overclaim_abs_threshold: float = OVERCLAIM_ABS_THRESHOLD,
) -> ClaimVerdict:
    """Verify an optimization claim against actual measurements."""
    if gold_cells is None or gate_cells is None:
        return ClaimVerdict(
            claim=f"claimed {claimed_delta_pct:.1f}% reduction",
            verified=False,
            evidence="cell counts not available — cannot verify",
            honest_report="optimization result unknown (synthesis unavailable)",
        )

    if gold_cells <= 0:
        return ClaimVerdict(
            claim=f"claimed {claimed_delta_pct:.1f}% reduction",
            verified=False,
            evidence=f"invalid baseline: gold_cells={gold_cells}",
            honest_report="cannot verify — gold cell count is zero or negative",
        )

    actual_delta = round((gate_cells - gold_cells) / gold_cells * 100, 2)
    claim_str = f"{claimed_delta_pct:.1f}% reduction"

    if not proved:
        return ClaimVerdict(
            claim=claim_str,
            verified=False,
            evidence=f"equivalence NOT proved (gold={gold_cells}, gate={gate_cells})",
            honest_report=f"gate has {actual_delta:+.1f}% delta but equivalence is NOT proved — result is UNVERIFIED",
        )

    if gate_cells >= gold_cells:
        return ClaimVerdict(
            claim=claim_str,
            verified=False,
            evidence=f"gate ({gate_cells}) >= gold ({gold_cells})",
            honest_report=f"no reduction achieved (gold={gold_cells}, gate={gate_cells}, delta={actual_delta:+.1f}%)",
        )

    overclaim = (
        abs(claimed_delta_pct) > abs(actual_delta) * overclaim_factor
        and abs(claimed_delta_pct - actual_delta) > overclaim_abs_threshold
    )
    if overclaim:
        return ClaimVerdict(
            claim=claim_str,
            verified=False,
            evidence=f"overclaim: proposer claimed {claimed_delta_pct:+.1f}% but actual is {actual_delta:+.1f}%",
            honest_report=f"PROVED EQUIVALENT but overclaimed: actual {actual_delta:+.1f}% vs claimed {claimed_delta_pct:+.1f}% ({gold_cells} -> {gate_cells} cells)",
        )

    return ClaimVerdict(
        claim=claim_str,
        verified=True,
        evidence=f"gold={gold_cells}, gate={gate_cells}, actual={actual_delta:+.1f}%, claimed={claimed_delta_pct:+.1f}%, proved={proved}",
        honest_report=f"PROVED: {actual_delta:+.1f}% reduction ({gold_cells} -> {gate_cells} cells)",
    )


def verify_repair_claim(
    claimed_fixes: int,
    actual_fixes_applied: int,
    actual_fixes_verified: int,
) -> ClaimVerdict:
    """Verify a repair claim against actual results."""
    if claimed_fixes < 0 or actual_fixes_applied < 0 or actual_fixes_verified < 0:
        return ClaimVerdict(
            claim=f"{claimed_fixes} fixes claimed",
            verified=False,
            evidence=f"invalid: negative count (claimed={claimed_fixes}, applied={actual_fixes_applied}, verified={actual_fixes_verified})",
            honest_report="invalid claim — negative fix count",
        )

    if claimed_fixes == 0 and actual_fixes_applied == 0:
        return ClaimVerdict(
            claim="0 fixes claimed",
            verified=True,
            evidence="no fixes attempted",
            honest_report="no fixes needed",
        )

    if claimed_fixes == 0 and actual_fixes_applied > 0:
        return ClaimVerdict(
            claim="0 fixes claimed",
            verified=False,
            evidence=f"claimed 0 but {actual_fixes_applied} applied",
            honest_report=f"claimed 0 fixes but {actual_fixes_applied} were applied — underclaim",
        )

    if actual_fixes_verified < actual_fixes_applied:
        return ClaimVerdict(
            claim=f"{claimed_fixes} fixes claimed",
            verified=False,
            evidence=f"applied={actual_fixes_applied}, verified={actual_fixes_verified}",
            honest_report=f"{actual_fixes_applied} fixes applied but only {actual_fixes_verified} verified — {actual_fixes_applied - actual_fixes_verified} UNVERIFIED",
        )

    if actual_fixes_applied < claimed_fixes:
        return ClaimVerdict(
            claim=f"{claimed_fixes} fixes claimed",
            verified=False,
            evidence=f"claimed={claimed_fixes}, applied={actual_fixes_applied}",
            honest_report=f"claimed {claimed_fixes} fixes but only {actual_fixes_applied} applied",
        )

    return ClaimVerdict(
        claim=f"{claimed_fixes} fixes",
        verified=True,
        evidence=f"applied={actual_fixes_applied}, verified={actual_fixes_verified}",
        honest_report=f"{actual_fixes_applied} fixes applied and verified",
    )


def verify_test_claim(
    claimed_passing: int,
    actual_passing: int,
    actual_failing: int,
) -> ClaimVerdict:
    """Verify a test suite claim."""
    if claimed_passing < 0 or actual_passing < 0 or actual_failing < 0:
        return ClaimVerdict(
            claim=f"{claimed_passing} tests passing",
            verified=False,
            evidence=f"invalid: negative count",
            honest_report="invalid claim — negative test count",
        )

    if actual_failing > 0:
        return ClaimVerdict(
            claim=f"{claimed_passing} tests passing",
            verified=False,
            evidence=f"passing={actual_passing}, failing={actual_failing}",
            honest_report=f"{actual_failing} tests FAILING ({actual_passing} passing)",
        )

    if actual_passing < claimed_passing:
        return ClaimVerdict(
            claim=f"{claimed_passing} tests passing",
            verified=False,
            evidence=f"claimed={claimed_passing}, actual={actual_passing}",
            honest_report=f"claimed {claimed_passing} passing but only {actual_passing} ran",
        )

    return ClaimVerdict(
        claim=f"{claimed_passing} tests passing",
        verified=True,
        evidence=f"passing={actual_passing}, failing={actual_failing}",
        honest_report=f"{actual_passing} tests passing, 0 failing",
    )


def format_verdict(v: ClaimVerdict) -> str:
    icon = "+" if v.verified else "!"
    return f"[{icon}] {v.honest_report}"
