"""ATH-1478: Validate LLM-generated SystemVerilog before execution.

Parses LLM output and rejects malformed or dangerous SV before it
reaches yosys/EBMC. Defense against LLM02 (Insecure Output Handling).

Checks:
1. Must contain exactly one module declaration
2. Module name must match expected (no name injection)
3. No `include directives (file inclusion attack)
4. No system tasks ($system, $fopen, $fwrite — file I/O)
5. No compiler directives that could alter behavior (`define with shell)
6. Reasonable size (no multi-MB output bombs)
"""
from __future__ import annotations

import re
from dataclasses import dataclass


@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    errors: list[str]


_MODULE_RE = re.compile(r"^\s*module\s+(\w+)", re.MULTILINE)
_INCLUDE_RE = re.compile(r"`include\s+", re.MULTILINE)
_SYSTEM_TASK_RE = re.compile(r"\$(?:system|fopen|fwrite|fclose|readmemh|readmemb)\b")
_DANGEROUS_DEFINE_RE = re.compile(r"`define\s+\w+.*(?:\$system|\bexec\b|\bshell\b)", re.IGNORECASE)

MAX_OUTPUT_SIZE = 500_000


def validate_llm_verilog(
    sv_text: str,
    expected_module: str | None = None,
) -> ValidationResult:
    """Validate LLM-generated SystemVerilog before yosys/EBMC execution.

    Returns ValidationResult with valid=True if safe to execute,
    or valid=False with list of specific errors.
    """
    errors: list[str] = []

    if not sv_text or not sv_text.strip():
        return ValidationResult(valid=False, errors=["empty output"])

    if len(sv_text) > MAX_OUTPUT_SIZE:
        errors.append(f"output too large ({len(sv_text)} bytes, max {MAX_OUTPUT_SIZE})")

    modules = _MODULE_RE.findall(sv_text)
    if not modules:
        errors.append("no module declaration found")
    elif expected_module and modules[0] != expected_module:
        errors.append(
            f"module name mismatch: expected '{expected_module}', "
            f"got '{modules[0]}'"
        )

    includes = _INCLUDE_RE.findall(sv_text)
    if includes:
        errors.append(f"`include directive found ({len(includes)} occurrences) — file inclusion blocked")

    system_tasks = _SYSTEM_TASK_RE.findall(sv_text)
    if system_tasks:
        errors.append(f"dangerous system tasks found: {system_tasks[:5]}")

    dangerous_defines = _DANGEROUS_DEFINE_RE.findall(sv_text)
    if dangerous_defines:
        errors.append(f"dangerous `define found: {dangerous_defines[:3]}")

    return ValidationResult(valid=len(errors) == 0, errors=errors)


def yosys_parse_check(sv_text: str, timeout_sec: int = 30) -> ValidationResult:
    """Level 2 defense: yosys parse-only dry run.

    Writes SV to a temp file and runs yosys read_verilog on it.
    If yosys rejects the syntax, the SV is malformed — reject before
    it reaches synthesis or verification.
    """
    import shutil
    import subprocess
    import tempfile
    from pathlib import Path
    from kairos.security.env_allowlist import safe_env_for_yosys

    yosys_bin = shutil.which("yosys")
    if not yosys_bin:
        return ValidationResult(valid=True, errors=[])

    with tempfile.NamedTemporaryFile(suffix=".sv", mode="w", delete=False) as f:
        f.write(sv_text)
        tmp_path = Path(f.name)

    try:
        r = subprocess.run(
            [yosys_bin, "-p", f"read_verilog -sv {tmp_path}"],
            capture_output=True, text=True, timeout=timeout_sec,
            env=safe_env_for_yosys(),
        )
        if r.returncode != 0:
            err_line = ""
            for line in r.stderr.splitlines():
                if "ERROR" in line:
                    err_line = line.strip()[:200]
                    break
            return ValidationResult(
                valid=False,
                errors=[f"yosys parse rejected: {err_line or 'nonzero exit'}"],
            )
        return ValidationResult(valid=True, errors=[])
    except subprocess.TimeoutExpired:
        return ValidationResult(valid=False, errors=["yosys parse timed out"])
    finally:
        tmp_path.unlink(missing_ok=True)


__all__ = ["validate_llm_verilog", "yosys_parse_check", "ValidationResult"]
