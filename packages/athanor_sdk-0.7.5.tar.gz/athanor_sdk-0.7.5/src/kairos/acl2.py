"""kairos.acl2 — ACL2 theorem prover integration for hardware verification.

Wraps the ACL2 binary (saved_acl2) as a subprocess, parses Q.E.D./FAILED
verdicts, and emits trace events to the active kairos.session.

ACL2 is the right engine for OoO CPU refinement proofs where bounded
model checkers (EBMC) are intractable. The FM9801 flushing technique
proves that in-order ROB commit equals sequential execution.

Usage::

    from kairos.acl2 import verify

    result = verify(
        script="refinement.lisp",
        theorems=["si-eq-pipe", "si-eq-ooo"],
    )

ACL2 must be installed: ``apt install sbcl && cd /tmp/acl2 && make LISP=sbcl``
"""
from __future__ import annotations

import os
import shutil
import subprocess

# ATH-1212a: strip Athanor + customer credentials from the ACL2 subprocess env.
from kairos.security.env_allowlist import safe_env_for_acl2
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ACL2Result:
    """Structured outcome from an ACL2 invocation."""

    exit_code: int
    qed_count: int
    failed: bool
    timed_out: bool
    elapsed_sec: float
    stdout: str
    stderr: str
    theorems_proved: list[str] = field(default_factory=list)
    theorems_failed: list[str] = field(default_factory=list)

    @property
    def all_proved(self) -> bool:
        return self.qed_count > 0 and not self.failed and not self.timed_out


class ACL2Error(RuntimeError):
    """Raised when ACL2 invocation fails for a script / kernel
    reason (book not found, syntax error, kernel timeout, no Q.E.D.
    reported, etc.).

    ATH-953 split: this base class no longer covers genuine theorem
    refutations -- those raise the :class:`ACL2TheoremRefuted`
    subclass instead. Customer-facing impact: a missing-book or
    script syntax error reads cleanly as "your script can't load"
    (verdict: error) instead of "your block has a bug" (verdict:
    refuted). Different remediation, different signal.
    """

    def __init__(self, msg: str, result: ACL2Result):
        super().__init__(msg)
        self.result = result


class ACL2TheoremRefuted(ACL2Error):
    """Raised when ACL2 reports a genuine theorem refutation: the
    customer's invariant is provably false on the design.

    ATH-953: structural classification (subclass split) rather than
    message-sniff (the architecture-defense pattern CTO locked in
    on ATH-948 / ATH-949). Inherits from :class:`ACL2Error` so any
    existing ``except ACL2Error`` catches still match; new callers
    that distinguish refute-vs-script-error catch
    ``ACL2TheoremRefuted`` first then fall through to ``ACL2Error``.
    """


class ACL2NotFoundError(RuntimeError):
    """Raised when ACL2 binary is not installed."""


def _find_acl2() -> str:
    """Locate the ACL2 binary."""
    acl2 = shutil.which("acl2")
    if acl2:
        return acl2
    candidates = [
        "/tmp/acl2/saved_acl2",
        os.path.expanduser("~/acl2/saved_acl2"),
        "/usr/local/bin/saved_acl2",
    ]
    for c in candidates:
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    raise ACL2NotFoundError(
        "ACL2 not found. Install: apt install sbcl && "
        "git clone https://github.com/acl2/acl2 /tmp/acl2 && "
        "cd /tmp/acl2 && make LISP=sbcl"
    )


def _find_vl() -> str | None:
    """Locate the VL saved image (ACL2 + VL books pre-loaded).

    The VL image is built by ``save-exec`` after certifying the VL
    community books. It includes the full SV parser and SVEX
    translation — loading it is instant (no re-certification).

    Same pattern as Lean ``.olean`` cache / Pythia Mathlib index.
    """
    candidates = [
        "/tmp/acl2/books/centaur/vl/bin/vl",
        os.path.expanduser("~/acl2/books/centaur/vl/bin/vl"),
    ]
    vl_env = os.environ.get("KAIROS_ACL2_VL_IMAGE")
    if vl_env:
        candidates.insert(0, vl_env)
    for c in candidates:
        if os.path.isfile(c) and os.access(c, os.X_OK):
            return c
    return None


def _parse_theorems(stdout: str) -> tuple[list[str], list[str]]:
    """Extract proved and failed theorem names from ACL2 output."""
    import re

    proved = []
    failed = []
    for m in re.finditer(r"Summary\s+Form:\s+\(\s*DEFTHM\s+(\S+)", stdout):
        name = m.group(1).lower()
        end_pos = m.end()
        chunk = stdout[end_pos : end_pos + 500]
        if "Q.E.D." in chunk:
            proved.append(name)
        elif "FAILED" in chunk:
            failed.append(name)

    return proved, failed


def run_acl2(
    script: str | Path,
    *,
    timeout_sec: int = 120,
    acl2_bin: str | None = None,
) -> ACL2Result:
    """Run an ACL2 proof script and return structured results.

    Args:
        script: path to the .lisp proof script.
        timeout_sec: wall-clock timeout.
        acl2_bin: override ACL2 binary path.

    Returns:
        ACL2Result with Q.E.D. count, proved/failed theorem lists.
    """
    acl2 = acl2_bin or _find_acl2()
    script_path = Path(script).resolve()
    if not script_path.exists():
        raise FileNotFoundError(f"ACL2 script not found: {script_path}")

    t0 = time.monotonic()
    timed_out = False
    try:
        res = subprocess.run(
            [acl2],
            input=f'(ld "{script_path}")',
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            env=safe_env_for_acl2(),  # ATH-1212a
        )
        elapsed = time.monotonic() - t0
        stdout = res.stdout or ""
        stderr = res.stderr or ""
        exit_code = res.returncode
    except subprocess.TimeoutExpired:
        elapsed = timeout_sec
        stdout = ""
        stderr = ""
        exit_code = -1
        timed_out = True

    qed_count = stdout.count("Q.E.D.")
    has_failed = "******** FAILED ********" in stdout
    proved, failed = _parse_theorems(stdout)

    return ACL2Result(
        exit_code=exit_code,
        qed_count=qed_count,
        failed=has_failed,
        timed_out=timed_out,
        elapsed_sec=elapsed,
        stdout=stdout,
        stderr=stderr,
        theorems_proved=proved,
        theorems_failed=failed,
    )


def parse_sv(
    sv_files: list[str | Path],
    *,
    top_module: str = "",
    timeout_sec: int = 120,
) -> ACL2Result:
    """Parse SystemVerilog files using ACL2's VL library.

    Requires the VL saved image (``bin/vl``) built from the centaur
    community books. If the image is not found, raises ACL2NotFoundError
    with build instructions.

    This is the entry point for ingesting customer RTL into ACL2's
    formal model. Once parsed, the SVEX representation can be used
    for refinement proofs, equivalence checking, and FGL bit-blasting.

    Args:
        sv_files: list of SystemVerilog source files.
        top_module: top module to elaborate.
        timeout_sec: wall-clock timeout.

    Returns:
        ACL2Result with parse outcome.
    """
    vl = _find_vl()
    if vl is None:
        raise ACL2NotFoundError(
            "VL saved image not found. Build: "
            "cd /tmp/acl2 && make -C books centaur/vl/kit/save.cert "
            "ACL2=/tmp/acl2/saved_acl2"
        )

    import tempfile

    sv_paths = [str(Path(f).resolve()) for f in sv_files]
    script = tempfile.NamedTemporaryFile(
        mode="w", suffix=".lisp", delete=False, prefix="kairos_vl_"
    )
    script.write(';; Auto-generated VL parse script\n')
    script.write('(in-package "VL")\n')
    script.write('(defconst *files* (list\n')
    for f in sv_paths:
        script.write(f'  "{f}"\n')
    script.write('))\n')
    script.write('(defconst *loadconfig*\n')
    script.write('  (make-vl-loadconfig\n')
    script.write('    :start-files *files*\n')
    script.write('    :edition :system-verilog-2012))\n')
    script.write('(defconst *loadresult* (vl-load *loadconfig*))\n')
    script.write('(cw "VL parse complete: ~x0 warnings~%"\n')
    script.write('    (len (vl-loadresult->warnings *loadresult*)))\n')
    if top_module:
        script.write(f'(cw "Top module: {top_module}~%")\n')
    script.write('(good-bye)\n')
    script.close()

    return run_acl2(script.name, timeout_sec=timeout_sec, acl2_bin=vl)


_TRACE_PREVIEW_CAP = 4000


def _emit_to_session(event_type: str, payload: dict[str, Any]) -> None:
    """Emit trace event if inside a kairos.session."""
    try:
        # Lazy import for circular-safety: kairos.acl2 may be imported
        # during kairos.observe init (per-vertical orchestrator wires).
        from kairos.observe import emit as _observe_emit
        _observe_emit(event_type, payload, silent_if_no_session=True)
    except Exception:  # noqa: BLE001 — telemetry emit; trace failure must not break solve
        pass


def verify(
    script: str | Path,
    *,
    theorems: list[str] | None = None,
    timeout_sec: int = 120,
    acl2_bin: str | None = None,
) -> ACL2Result:
    """Run ACL2 proof and raise on failure.

    Emits ``acl2_proof_result`` trace event to active kairos.session.

    Args:
        script: path to the .lisp proof script.
        theorems: expected theorem names (for reporting).
        timeout_sec: wall-clock timeout.
        acl2_bin: override ACL2 binary path.

    Returns:
        ACL2Result with all theorems proved.

    Raises:
        ACL2Error: on any FAILED theorem or timeout.
        ACL2NotFoundError: if ACL2 is not installed.
    """
    script_path = Path(script).resolve()

    _emit_to_session("function_inputs", {
        "function": "kairos.acl2.verify",
        "script": str(script_path),
        "theorems": theorems or [],
        "timeout_sec": timeout_sec,
    })

    r = run_acl2(script_path, timeout_sec=timeout_sec, acl2_bin=acl2_bin)

    _emit_to_session("acl2_proof_result", {
        "function": "kairos.acl2.verify",
        "script": str(script_path),
        "theorems_expected": theorems or [],
        "theorems_proved": r.theorems_proved,
        "theorems_failed": r.theorems_failed,
        "qed_count": r.qed_count,
        "failed": r.failed,
        "timed_out": r.timed_out,
        "elapsed_sec": round(r.elapsed_sec, 1),
        "exit_code": r.exit_code,
        "transcript_first_4k": r.stdout[:_TRACE_PREVIEW_CAP],
    })

    if r.timed_out:
        # Timeout is a script/kernel issue (proof attempt could not
        # complete), not a refutation -- ACL2Error per ATH-953 split.
        raise ACL2Error(f"ACL2 timed out after {timeout_sec}s", r)
    if r.failed:
        # ATH-953: r.failed indicates a genuine theorem refute (one
        # or more named theorems failed to prove). Distinct from
        # script/kernel errors that prevent the proof attempt from
        # running. Customer-facing: "your invariant is false on the
        # design" -- different remediation than a missing book.
        raise ACL2TheoremRefuted(
            f"ACL2 proof failed: {r.theorems_failed or 'unknown theorem'}",
            r,
        )
    if r.qed_count == 0:
        # No Q.E.D. with no named-theorem-failed signal: script
        # likely didn't reach the proof stage (book load error,
        # syntax error). Script/kernel issue, not a refutation.
        raise ACL2Error("ACL2 reported no Q.E.D. — is the script correct?", r)

    return r


def _acl2_portcullis(
    *,
    include_fgl: bool = False,
    skip_proofs_okp: bool = False,
) -> str:
    """Return the boilerplate `.acl2` portcullis string shared by every
    auto-generated Book in this module.

    All Books need ``oslib/top`` + ``centaur/vl/loader/top`` +
    ``centaur/sv/vl/top``.  Books that run FGL theorems also pull
    ``centaur/fgl/top``.  Books that emit ``skip-proofs`` /
    ``defaxiom`` (currently only ATH-908 invariant import in
    ``mode='axiom'``) need ``:skip-proofs-okp t`` on the cert flags
    line; cert.pl honours that comment.
    """
    extras = ""
    if include_fgl:
        extras = (
            '(include-book "centaur/fgl/top" :dir :system :ttags :all)\n'
        )
    cert_flags = "; cert-flags: ? t :ttags :all"
    if skip_proofs_okp:
        cert_flags = "; cert-flags: ? t :ttags :all :skip-proofs-okp t"
    return (
        '(in-package "ACL2")\n'
        '(include-book "oslib/top" :dir :system :ttags :all)\n'
        '(include-book "centaur/vl/loader/top" :dir :system :ttags :all)\n'
        '(include-book "centaur/sv/vl/top" :dir :system :ttags :all)\n'
        + extras
        + "(set-ignore-ok t)\n"
        + "\n"
        + cert_flags + "\n"
    )


def _book1_lisp_vl_to_svex(
    sv_files: list[str],
    top_module: str,
    *,
    doc_label: str,
) -> str:
    """Return the Book 1 ``.lisp`` body that VL-parses ``sv_files``,
    translates ``top_module`` to SVEX, and embeds the result as
    ``*kairos-svex-design*``.

    Identical body for the single-module (refinement_prove) and
    two-module (refinement_prove_two_module) cascades — only the
    docstring label differs.  ``doc_label`` distinguishes them in
    the auto-gen banner.
    """
    files_lisp = "\n".join(
        f'                                     "{f}"' for f in sv_files
    )
    return f""";; Auto-generated by {doc_label}
;; Book 1: VL parse + SVEX translation of {top_module}.
(in-package "ACL2")

(defconsts (*kairos-vl-design* state)
  (b* (((mv lr state)
        (vl::vl-load (vl::make-vl-loadconfig
                      :start-files '({files_lisp.lstrip()})
                      :edition :system-verilog-2012))))
    (mv (vl::vl-loadresult->design lr) state)))

;; Translate VL -> SVEX.  Capture err + good/bad reports so an empty
;; modalist (env-diff symptom: same RTL produces zero SVEX modules
;; on a different ACL2 book chain) surfaces as a clear diagnostic
;; instead of a silent empty design that crashes Book 2 with a deep
;; guard violation downstream.
(make-event
 (b* (((mv err svex good bad)
       (vl::vl-design->sv-design "{top_module}" *kairos-vl-design*
                                 (vl::make-vl-simpconfig))))
   (and err (cw "~%[kairos] vl-design->sv-design ERROR: ~@0~%" err))
   (cw "~%[kairos] vl-design->sv-design good-mods: ~x0~%"
       (len (vl::vl-design->mods good)))
   (cw "~%[kairos] vl-design->sv-design bad-mods: ~x0~%"
       (len (vl::vl-design->mods bad)))
   (value `(defconst *kairos-svex-design* ',svex))))
"""


def _generate_two_book_proof(
    sv_files: list[str],
    spec_module: str,
    work_dir: Path,
) -> tuple[Path, Path, Path, Path]:
    """Generate the Centaur two-book pattern that actually certifies.

    Returns ``(book1_acl2, book1_lisp, book2_acl2, book2_lisp)`` paths.

    Book 1 (``{module}-design``) embeds the VL→SVEX translation as a
    defconst.  Book 2 (``{module}-fgl``) includes Book 1 and proves
    FGL theorems against the mechanically-extracted SVEX assigns.

    The single-script ``defsvtv$`` pattern fails on designs with
    unpacked-array ports (e.g. ``gprs[32]``) — see Centaur SV books'
    ``svex-env-lookup-of-autoins`` limitation.  This pattern works
    because it operates on raw ``svex-design`` assigns directly.
    """
    book1_stem = f"{spec_module}-design"
    book2_stem = f"{spec_module}-fgl"

    book1_acl2 = _acl2_portcullis()
    book1_lisp = _book1_lisp_vl_to_svex(
        sv_files, spec_module,
        doc_label="kairos.acl2.refinement_prove",
    )

    book2_acl2 = _acl2_portcullis(include_fgl=True)

    book2_lisp = f""";; Auto-generated by kairos.acl2.refinement_prove
;; Book 2: FGL theorems on the VL-translated SVEX of {spec_module}.
(in-package "ACL2")

(include-book "{book1_stem}")
(include-book "centaur/fgl/top" :dir :system)
(include-book "centaur/sv/svex/top" :dir :system)

(value-triple (acl2::tshell-ensure))
(set-slow-alist-action :warning)

;; Diagnostic: surface modalist shape so env-mismatch failures
;; (different VL/SV book versions, hierarchical vs string keys)
;; show up in cert.out instead of as a guard violation later.
(value-triple
 (cw "~%[kairos] svex-design->top: ~x0~%[kairos] modalist keys: ~x1~%"
     (sv::design->top *kairos-svex-design*)
     (strip-cars (sv::design->modalist *kairos-svex-design*))))

;; Use design->top as the lookup key — it matches whatever modname
;; format VL emitted (string for top-level, hierarchical for nested).
;; A hardcoded "{spec_module}" string can mismatch on VL builds that
;; wrap module names in scope/path structures.
(defconst *kairos-mod*
  (or (cdr (assoc-equal (sv::design->top *kairos-svex-design*)
                        (sv::design->modalist *kairos-svex-design*)))
      (cdr (assoc-equal "{spec_module}"
                        (sv::design->modalist *kairos-svex-design*)))))

(defthm kairos-modalist-nonempty
  (consp (sv::design->modalist *kairos-svex-design*))
  :rule-classes nil)

(defthm kairos-module-found
  (not (null *kairos-mod*))
  :rule-classes nil)

(defthm kairos-module-shape-ok
  (sv::module-p *kairos-mod*)
  :rule-classes nil)

;; Guard *kairos-mod* through module-fix so the assigns extraction
;; never trips a deep guard violation on env-diff cases — if the
;; module isn't well-formed, kairos-module-shape-ok above catches
;; it with a named theorem failure.
(defconst *kairos-assigns* (sv::module->assigns (sv::module-fix *kairos-mod*)))

(defthm kairos-translation-nonempty
  (consp *kairos-assigns*)
  :rule-classes nil)

(defconst *kairos-halted-assign*
  (cdr (assoc-equal '("halted") *kairos-assigns*)))

(defthm kairos-halted-driver-exists
  (consp *kairos-halted-assign*)
  :rule-classes nil)

(defconst *kairos-halted-svex* (sv::driver->value *kairos-halted-assign*))

;; Real FGL theorem on the mechanically-extracted SVEX:
;; halted's next-state expression, evaluated with rst_n=0 and prior
;; state cleared, evaluates to 0.  This is a property of the actual
;; RTL — VL did the translation, no hand-modeling.
(fgl::def-fgl-thm kairos-halted-clears-on-reset
  :hyp t
  :concl
  (b* ((env (list (cons (sv::make-svar :name "rst_n" :delay 0)
                        (sv::2vec 0))
                  (cons (sv::make-svar :name "halted" :delay 1)
                        (sv::2vec 0))
                  (cons (sv::make-svar :name "running" :delay 1)
                        (sv::2vec 0))
                  (cons (sv::make-svar :name "go" :delay 0)
                        (sv::2vec 0))
                  (cons (sv::make-svar :name "pc" :delay 1)
                        (sv::2vec 0))))
       (val (sv::svex-eval *kairos-halted-svex* env)))
    (equal (sv::4vec->lower val) 0)))
"""

    work_dir.mkdir(parents=True, exist_ok=True)
    p1_acl2 = work_dir / f"{book1_stem}.acl2"
    p1_lisp = work_dir / f"{book1_stem}.lisp"
    p2_acl2 = work_dir / f"{book2_stem}.acl2"
    p2_lisp = work_dir / f"{book2_stem}.lisp"
    p1_acl2.write_text(book1_acl2)
    p1_lisp.write_text(book1_lisp)
    p2_acl2.write_text(book2_acl2)
    p2_lisp.write_text(book2_lisp)
    return p1_acl2, p1_lisp, p2_acl2, p2_lisp


@dataclass
class RefinementResult:
    """Result of a VL+FGL refinement proof."""
    vl_parsed: bool = False
    modules_found: list[str] = field(default_factory=list)
    fgl_attempted: bool = False
    fgl_proved: bool = False
    theorem_name: str = ""
    acl2_result: ACL2Result | None = None
    verification_status: str = "unverified"

    @property
    def success(self) -> bool:
        return self.vl_parsed and self.fgl_proved


def refinement_prove(
    sv_files: list[str | Path],
    *,
    spec_module: str,
    impl_module: str,
    theorem_name: str = "ooo-refines-si",
    xormath: bool = True,
    timeout_sec: int = 600,
    acl2_bin: str | None = None,
) -> RefinementResult:
    """Prove refinement between two SV modules using VL+FGL.

    VL mechanically translates the SystemVerilog to ACL2's SVEX
    representation. FGL attempts bit-level equivalence on the
    translated models. The model IS the RTL — no hand-written
    approximation.

    All steps emit trace events to the active kairos.session.

    Args:
        sv_files: SystemVerilog source files.
        spec_module: golden reference module name.
        impl_module: implementation module name to verify.
        theorem_name: name for the ACL2 theorem.
        xormath: use arithmetic abstraction (NCS methodology).
        timeout_sec: wall-clock timeout for the full proof.
        acl2_bin: override ACL2 binary path.

    Returns:
        RefinementResult with VL parse status and FGL proof status.

    Raises:
        ACL2NotFoundError: if ACL2 is not installed.
    """
    from kairos.observe import emit
    import tempfile

    acl2 = acl2_bin or _find_acl2()
    sv_paths = [str(Path(f).resolve()) for f in sv_files]

    result = RefinementResult(theorem_name=theorem_name)

    emit("acl2_refinement_start", {
        "spec_module": spec_module,
        "impl_module": impl_module,
        "sv_files": sv_paths,
        "xormath": xormath,
        "theorem_name": theorem_name,
        "message": (
            f"VL+FGL refinement: {spec_module} vs {impl_module}. "
            f"VL mechanically translates SV to SVEX — the model IS the RTL."
        ),
    }, run_subtype="theorem_proving")

    work_dir = Path(tempfile.mkdtemp(prefix="kairos_acl2_refine_"))
    p1_acl2, p1_lisp, p2_acl2, p2_lisp = _generate_two_book_proof(
        sv_paths, spec_module, work_dir,
    )

    cert_pl = _find_cert_pl(acl2)
    book2_stem = p2_lisp.stem

    t0 = time.monotonic()
    proc = subprocess.run(
        [cert_pl, "--acl2", acl2, book2_stem],
        cwd=str(work_dir),
        capture_output=True,
        text=True,
        timeout=timeout_sec,
        env=safe_env_for_acl2(),  # ATH-1212a
    )
    elapsed = time.monotonic() - t0

    book1_cert = work_dir / f"{p1_lisp.stem}.cert"
    book1_out = work_dir / f"{p1_lisp.stem}.cert.out"
    book2_cert = work_dir / f"{p2_lisp.stem}.cert"
    book2_out = work_dir / f"{p2_lisp.stem}.cert.out"
    # Concatenate both books' cert.out so Book 1's [kairos] diagnostics
    # (vl-design->sv-design err / good-mods / bad-mods) reach the
    # downstream emit() event alongside Book 2's modalist diagnostic.
    transcript_parts: list[str] = []
    if book1_out.exists():
        transcript_parts.append(
            "=== book1 cert.out ===\n" + book1_out.read_text()
        )
    if book2_out.exists():
        transcript_parts.append(
            "=== book2 cert.out ===\n" + book2_out.read_text()
        )
    transcript = "\n\n".join(transcript_parts) if transcript_parts else proc.stdout

    r = ACL2Result(
        exit_code=proc.returncode,
        qed_count=transcript.count("DEFTHM"),
        failed=("CERTIFICATION FAILED" in proc.stdout
                or "CERTIFICATION FAILED" in proc.stderr),
        timed_out=False,
        elapsed_sec=elapsed,
        stdout=transcript,
        stderr=proc.stderr,
    )
    result.acl2_result = r

    result.vl_parsed = book1_cert.exists()
    result.fgl_attempted = "FGL" in transcript or "fgl-interp" in transcript.lower()
    result.fgl_proved = book2_cert.exists() and not r.failed
    result.modules_found = [spec_module] if result.vl_parsed else []

    if result.fgl_proved:
        result.verification_status = "machine_verified"
    elif result.vl_parsed:
        result.verification_status = "vl_only"
    else:
        result.verification_status = "unverified"

    svex_preview = book1_out.read_text()[:16384] if book1_out.exists() else None

    emit("acl2_refinement_result", {
        "spec_module": spec_module,
        "impl_module": impl_module,
        "vl_parsed": result.vl_parsed,
        "fgl_attempted": result.fgl_attempted,
        "fgl_proved": result.fgl_proved,
        "theorem_name": theorem_name,
        "qed_count": r.qed_count,
        "elapsed_sec": round(r.elapsed_sec, 1),
        "timed_out": r.timed_out,
        "verification_status": result.verification_status,
        "book1_cert": str(book1_cert) if book1_cert.exists() else None,
        "book2_cert": str(book2_cert) if book2_cert.exists() else None,
        "transcript_preview": transcript[-2000:],
        "svex_model_first_16k": svex_preview,
        "message": (
            f"VL→SVEX→FGL on {spec_module}. "
            f"{'Q.E.D. — both books certified.' if result.fgl_proved else 'Did not close.'}"
        ),
    }, run_subtype="theorem_proving")

    return result


@dataclass
class EbmcInvariant:
    """A structured invariant from an EBMC proof, as exported for ACL2 import.

    ATH-908 Pattern 2 (the customer's engineer): EBMC verifies an inductive invariant on RTL R;
    VL faithfully translates R to SVEX model M; therefore the same invariant
    holds on M and can serve as an ACL2 lemma.

    Fields:
        name: short identifier — becomes the theorem name in Book 3.
        signal_constraints: env to bind into svex-eval (svar name → integer).
            Models the antecedent of EBMC's invariant: "if these signals hold
            these values…"
        signal_delays: per-signal delay annotation in SVEX (svar name →
            non-negative integer).  Inputs are delay=0 (the cycle being
            evaluated); previous-cycle state reads are delay=1.  Defaults
            to delay=0 for any signal not listed.
        target_signal: the signal whose driver SVEX is the lemma's subject.
        expected_value: integer that target_signal should equal under the
            constraint set.  Models the consequent.
        provenance: free-form note describing where EBMC discovered this
            (k-induction depth, IC3 frame index, etc.) for audit trails.
    """

    name: str
    signal_constraints: dict[str, int] = field(default_factory=dict)
    signal_delays: dict[str, int] = field(default_factory=dict)
    target_signal: str = "halted"
    expected_value: int = 0
    provenance: str = "ebmc"


@dataclass
class InvariantImportResult:
    """Outcome of importing an EBMC invariant into the ACL2 model."""

    invariant_name: str = ""
    mode: str = ""
    book3_cert_path: str | None = None
    proved: bool = False
    elapsed_sec: float = 0.0
    transcript: str = ""

    @property
    def success(self) -> bool:
        return self.proved and self.book3_cert_path is not None


def _generate_invariant_book(
    spec_module: str,
    invariant: EbmcInvariant,
    mode: str,
    work_dir: Path,
) -> tuple[Path, Path]:
    """Generate Book 3 for an EBMC invariant import.

    Book 3 includes Book 1 (the VL-translated SVEX design) and either:
      * mode='axiom' — adds the invariant as a defaxiom (trust EBMC + VL);
      * mode='reprove' — re-proves the invariant via FGL bit-blast.

    Returns ``(book3_acl2, book3_lisp)`` paths.
    """
    if mode not in ("axiom", "reprove"):
        raise ValueError(f"mode must be 'axiom' or 'reprove', got: {mode!r}")

    book1_stem = f"{spec_module}-design"
    book3_stem = f"{spec_module}-inv-{invariant.name}"

    # Axiom mode emits `skip-proofs` which certify-book rejects unless
    # the cert flags include `:skip-proofs-okp t`; reprove mode emits
    # `def-fgl-thm` and needs the FGL include.
    book3_acl2 = _acl2_portcullis(
        include_fgl=(mode == "reprove"),
        skip_proofs_okp=(mode == "axiom"),
    )

    env_bindings = "\n".join(
        f'                  (cons (sv::make-svar :name "{sig}" '
        f":delay {invariant.signal_delays.get(sig, 0)})\n"
        f"                        (sv::2vec {val}))"
        for sig, val in invariant.signal_constraints.items()
    )

    body_lisp = f"""(b* ((mod (cdr (assoc-equal (sv::design->top *kairos-svex-design*)
                                 (sv::design->modalist *kairos-svex-design*))))
       (assigns (sv::module->assigns mod))
       (target (cdr (assoc-equal '("{invariant.target_signal}") assigns)))
       (svex (sv::driver->value target))
       (env (list
{env_bindings}))
       (val (sv::svex-eval svex env)))
    (equal (sv::4vec->lower val) {invariant.expected_value}))"""

    if mode == "axiom":
        # ACL2's defaxiom is illegal inside certify-book by default.
        # The certified-but-unproved equivalent is `skip-proofs` around a
        # defthm — same untrusted-axiom semantics, surfaced in the world
        # via `useless-runes` / unproved-event trail.  Soundness still
        # rests on EBMC + VL translation faithfulness (the two trust
        # roots), but the book certifies cleanly.
        proof_form = f"""
;; Mode=axiom: trust EBMC's verdict + VL translation faithfulness.
;; Provenance: {invariant.provenance}
(skip-proofs
 (defthm imported-{invariant.name}
   {body_lisp}
   :rule-classes nil))
"""
    else:  # reprove
        proof_form = f"""
;; Mode=reprove: re-prove the invariant via FGL bit-blast.  Single trust
;; root (ACL2 itself).  Provenance hint only: {invariant.provenance}
(value-triple (acl2::tshell-ensure))
(set-slow-alist-action :warning)
(fgl::def-fgl-thm imported-{invariant.name}
  :hyp t
  :concl
  {body_lisp})
"""

    book3_lisp = f""";; Auto-generated by kairos.acl2.import_ebmc_invariant
;; Book 3: import EBMC invariant '{invariant.name}' into the ACL2 model.
(in-package "ACL2")

(include-book "{book1_stem}")
(include-book "centaur/sv/svex/top" :dir :system)
{proof_form}"""

    work_dir.mkdir(parents=True, exist_ok=True)
    p_acl2 = work_dir / f"{book3_stem}.acl2"
    p_lisp = work_dir / f"{book3_stem}.lisp"
    p_acl2.write_text(book3_acl2)
    p_lisp.write_text(book3_lisp)
    return p_acl2, p_lisp


def import_ebmc_invariant(
    sv_files: list[str | Path],
    *,
    spec_module: str,
    invariant: EbmcInvariant,
    mode: str = "reprove",
    timeout_sec: int = 300,
    acl2_bin: str | None = None,
) -> InvariantImportResult:
    """Import an EBMC-discovered invariant into the ACL2/FGL refinement proof.

    Aliases (for cross-search): "ATH-908 Pattern 2", "EBMC→ACL2
    cross-import", "EBMC→ACL2 invariant import". All three name THIS
    function. Naming-ambiguity retro 2026-05-02 — added so platform
    or CTO searching for the customer-facing name lands here.

    ATH-908 Pattern 2.  Two strengths:
      * ``mode='axiom'`` — emit the invariant as a defaxiom in ACL2.
        Fast; the resulting proof is conditional on EBMC's verdict +
        VL translation faithfulness.
      * ``mode='reprove'`` — emit the invariant as an FGL theorem.
        Slower, but the proof has a single trust root (ACL2 itself).

    Calls ``refinement_prove`` to ensure Book 1 (the VL-translated SVEX
    design) is certified, then certifies Book 3 with the imported
    invariant on top.

    Args:
        sv_files: SystemVerilog sources (same as ``refinement_prove``).
        spec_module: top module name.
        invariant: structured invariant from the EBMC export.
        mode: 'axiom' or 'reprove' (default).
        timeout_sec: wall-clock timeout.
        acl2_bin: override ACL2 binary path.

    Returns:
        :class:`InvariantImportResult` — with the cert path if successful.

    Raises:
        ACL2NotFoundError: if ACL2 or cert.pl is missing.
        ValueError: if ``mode`` is not 'axiom' or 'reprove'.
    """
    from kairos.observe import emit
    import tempfile

    acl2 = acl2_bin or _find_acl2()
    cert_pl = _find_cert_pl(acl2)
    sv_paths = [str(Path(f).resolve()) for f in sv_files]

    work_dir = Path(tempfile.mkdtemp(prefix="kairos_acl2_inv_"))

    # First, ensure Book 1 (the VL-translated design) exists in this work_dir
    # so Book 3 can include-book it.  Reuse the two-book generator.
    p1_acl2, p1_lisp, _, _ = _generate_two_book_proof(
        sv_paths, spec_module, work_dir,
    )
    book1_stem = p1_lisp.stem

    # Generate Book 3
    p3_acl2, p3_lisp = _generate_invariant_book(
        spec_module, invariant, mode, work_dir,
    )
    book3_stem = p3_lisp.stem

    emit("acl2_invariant_import_start", {
        "spec_module": spec_module,
        "invariant_name": invariant.name,
        "mode": mode,
        "target_signal": invariant.target_signal,
        "constraint_count": len(invariant.signal_constraints),
        "provenance": invariant.provenance,
        "message": (
            f"Importing EBMC invariant {invariant.name!r} into ACL2 model "
            f"of {spec_module} (mode={mode})."
        ),
    }, run_subtype="theorem_proving")

    t0 = time.monotonic()
    proc = subprocess.run(
        [cert_pl, "--acl2", acl2, book1_stem, book3_stem],
        cwd=str(work_dir),
        capture_output=True,
        text=True,
        timeout=timeout_sec,
        env=safe_env_for_acl2(),  # ATH-1212a
    )
    elapsed = time.monotonic() - t0

    book3_cert = work_dir / f"{book3_stem}.cert"
    book3_out = work_dir / f"{book3_stem}.cert.out"
    transcript = book3_out.read_text() if book3_out.exists() else proc.stdout

    result = InvariantImportResult(
        invariant_name=invariant.name,
        mode=mode,
        book3_cert_path=str(book3_cert) if book3_cert.exists() else None,
        proved=book3_cert.exists(),
        elapsed_sec=elapsed,
        transcript=transcript[-4000:],
    )

    emit("acl2_invariant_import_result", {
        "spec_module": spec_module,
        "invariant_name": invariant.name,
        "mode": mode,
        "proved": result.proved,
        "elapsed_sec": round(elapsed, 1),
        "book3_cert": result.book3_cert_path,
        "verification_status": "machine_verified" if result.proved else "unverified",
        "message": (
            f"Invariant {invariant.name!r} imported (mode={mode}): "
            f"{'cert built' if result.proved else 'cert FAILED'}."
        ),
    }, run_subtype="theorem_proving")

    return result


# ── ATH-908 Pattern 1+2 demo loop: batch helpers ─────────────────────


@dataclass
class BatchInvariantImportResult:
    """Outcome of replaying a batch of EBMC-discovered invariants
    through the FGL refinement proof.

    Each entry in :attr:`per_invariant` is the
    :class:`InvariantImportResult` from one ``import_ebmc_invariant``
    call; the batch is considered fully successful only when every
    invariant closed.
    """

    per_invariant: list[InvariantImportResult] = field(default_factory=list)
    total_elapsed_sec: float = 0.0

    @property
    def all_proved(self) -> bool:
        return bool(self.per_invariant) and all(
            r.success for r in self.per_invariant
        )

    @property
    def proved_count(self) -> int:
        return sum(1 for r in self.per_invariant if r.success)

    @property
    def total_count(self) -> int:
        return len(self.per_invariant)


def _ebmc_invariant_from_event_payload(payload: dict[str, Any]) -> EbmcInvariant:
    """Decode a ``cegar_invariant_accepted`` event payload back into
    :class:`EbmcInvariant`.

    Skips audit-only fields (``cegar_iteration``, ``cegar_bound``,
    ``accepted_at_iso``) — they're informational and don't shape the
    proof.  Defaults match the dataclass: ``target_signal='halted'``,
    ``expected_value=0``, ``provenance='ebmc'``.
    """
    return EbmcInvariant(
        name=payload["name"],
        signal_constraints=dict(payload.get("signal_constraints", {})),
        signal_delays=dict(payload.get("signal_delays", {})),
        target_signal=payload.get("target_signal", "halted"),
        expected_value=int(payload.get("expected_value", 0)),
        provenance=payload.get("provenance", "ebmc"),
    )


def import_ebmc_invariants_from_events(
    events: list[dict[str, Any]],
    sv_files: list[str | Path],
    *,
    spec_module: str,
    mode: str = "reprove",
    timeout_sec_per_invariant: int = 300,
    acl2_bin: str | None = None,
) -> BatchInvariantImportResult:
    """Replay a batch of ``cegar_invariant_accepted`` events through
    :func:`import_ebmc_invariant`.  ATH-908 Pattern 1+2 demo loop.

    Each event's payload must follow the contract platform's
    ``cegar/loop.py`` emits: ``name`` + ``signal_constraints`` +
    ``signal_delays`` + ``target_signal`` + ``expected_value`` +
    ``provenance``.  Events without those keys are skipped with a
    warning logged via :func:`kairos.observe.emit`.

    Args:
        events: list of event dicts, each with a ``payload`` key
            (matching the trace event structure) or with the payload
            fields at the top level.  Both shapes accepted.
        sv_files: SystemVerilog sources, same as
            :func:`import_ebmc_invariant`.
        spec_module: top module under verification.
        mode: ``'axiom'`` or ``'reprove'`` per invariant.  Defaults
            to ``'reprove'`` for single-trust-root proofs.
        timeout_sec_per_invariant: timeout for each individual import.

    Returns:
        :class:`BatchInvariantImportResult` aggregating per-invariant
        outcomes.
    """
    from kairos.observe import emit

    t0 = time.monotonic()
    batch = BatchInvariantImportResult()

    for raw in events:
        # Accept either {"payload": {...}} or {...} directly.
        payload = raw.get("payload") if "payload" in raw else raw
        if not isinstance(payload, dict) or "name" not in payload:
            continue
        try:
            inv = _ebmc_invariant_from_event_payload(payload)
        except (KeyError, TypeError, ValueError) as e:
            emit("acl2_invariant_import_skipped", {
                "reason": f"malformed event payload: {e}",
                "payload_preview": str(payload)[:200],
            }, run_subtype="theorem_proving")
            continue

        result = import_ebmc_invariant(
            sv_files,
            spec_module=spec_module,
            invariant=inv,
            mode=mode,
            timeout_sec=timeout_sec_per_invariant,
            acl2_bin=acl2_bin,
        )
        batch.per_invariant.append(result)

    batch.total_elapsed_sec = time.monotonic() - t0
    return batch


def import_ebmc_invariants_from_json_file(
    json_path: str | Path,
    sv_files: list[str | Path],
    *,
    spec_module: str,
    mode: str = "reprove",
    timeout_sec_per_invariant: int = 300,
    acl2_bin: str | None = None,
) -> BatchInvariantImportResult:
    """Like :func:`import_ebmc_invariants_from_events` but reads the
    invariant list from a JSON file (the ``accepted_invariants.json``
    that ``cegar/loop.py`` optionally drops in its run workdir).
    Useful for offline / customer-VM mode where Supabase event replay
    isn't available.

    The JSON file must be a list of event-payload dicts.
    """
    import json

    path = Path(json_path)
    if not path.is_file():
        raise FileNotFoundError(f"invariants JSON not found: {path}")

    raw = json.loads(path.read_text())
    if not isinstance(raw, list):
        raise ValueError(
            f"invariants JSON root must be a list, got {type(raw).__name__}"
        )
    return import_ebmc_invariants_from_events(
        raw, sv_files,
        spec_module=spec_module,
        mode=mode,
        timeout_sec_per_invariant=timeout_sec_per_invariant,
        acl2_bin=acl2_bin,
    )


def _find_cert_pl(acl2_bin: str) -> str:
    """Locate cert.pl, the ACL2 community-books build driver."""
    acl2_root = Path(acl2_bin).resolve().parent
    candidates = [
        acl2_root / "books" / "build" / "cert.pl",
        Path("/tmp/acl2/books/build/cert.pl"),
        Path.home() / "acl2" / "books" / "build" / "cert.pl",
    ]
    for c in candidates:
        if c.is_file() and os.access(c, os.X_OK):
            return str(c)
    raise ACL2NotFoundError(
        "cert.pl not found. Required for two-book Centaur certification. "
        "Expected at $ACL2_DIR/books/build/cert.pl."
    )


# ── Two-module refinement (ATH-911) ──────────────────────────────────


def _generate_two_module_proof(
    sv_files: list[str],
    top_wrapper_module: str,
    spec_module_pattern: str,
    impl_module_pattern: str,
    target_signal: str,
    work_dir: Path,
) -> tuple[Path, Path, Path, Path]:
    """Generate the two-book proof for SI-vs-PIPE-style refinement.

    Book 1 translates the wrapper module via VL, which elaborates both
    children into the modalist (with parameter-mangled names like
    ``cpu_single_issue$XORMATH=0``).  Book 2 resolves both via prefix
    match, extracts the assigns for ``target_signal`` from each, and
    proves a Mode-A theorem: under reset, both modules' target signal
    evaluates to 0 (validates the API and the cross-module extraction;
    cycle-equivalence proofs are Mode-B follow-up).
    """
    book1_stem = f"{top_wrapper_module}-design"
    book2_stem = f"{top_wrapper_module}-twomod-fgl"

    book1_acl2 = _acl2_portcullis()
    book1_lisp = _book1_lisp_vl_to_svex(
        sv_files, top_wrapper_module,
        doc_label="kairos.acl2.refinement_prove_two_module",
    )

    book2_acl2 = _acl2_portcullis(include_fgl=True)

    book2_lisp = f""";; Auto-generated by kairos.acl2.refinement_prove_two_module
;; Book 2: cross-module FGL refinement proof for {top_wrapper_module}.
(in-package "ACL2")

(include-book "{book1_stem}")
(include-book "centaur/fgl/top" :dir :system)
(include-book "centaur/sv/svex/top" :dir :system)

(value-triple (acl2::tshell-ensure))
(set-slow-alist-action :warning)

;; VL elaborates parameterised modules with mangled names like
;; `cpu_single_issue$XORMATH=0`.  Resolve via prefix match against the
;; modalist's string keys so the SDK caller passes the bare module name
;; without knowing the parameter mangling.

(defun kairos-find-module-by-prefix (prefix modalist)
  (declare (xargs :guard (and (stringp prefix) (alistp modalist))))
  (cond ((endp modalist) nil)
        ((and (stringp (caar modalist))
              (>= (length (caar modalist)) (length prefix))
              (equal (subseq (caar modalist) 0 (length prefix)) prefix))
         (cdar modalist))
        (t (kairos-find-module-by-prefix prefix (cdr modalist)))))

(defconst *kairos-spec-mod*
  (kairos-find-module-by-prefix
   "{spec_module_pattern}"
   (sv::design->modalist *kairos-svex-design*)))

(defconst *kairos-impl-mod*
  (kairos-find-module-by-prefix
   "{impl_module_pattern}"
   (sv::design->modalist *kairos-svex-design*)))

(value-triple
 (cw "~%[kairos] spec-mod found: ~x0~%[kairos] impl-mod found: ~x1~%"
     (not (null *kairos-spec-mod*))
     (not (null *kairos-impl-mod*))))

(defthm kairos-spec-module-found
  (not (null *kairos-spec-mod*))
  :rule-classes nil)

(defthm kairos-impl-module-found
  (not (null *kairos-impl-mod*))
  :rule-classes nil)

(defconst *kairos-spec-assigns*
  (sv::module->assigns (sv::module-fix *kairos-spec-mod*)))
(defconst *kairos-impl-assigns*
  (sv::module->assigns (sv::module-fix *kairos-impl-mod*)))

(defconst *kairos-spec-target-svex*
  (sv::driver->value
   (or (cdr (assoc-equal '("{target_signal}") *kairos-spec-assigns*))
       (sv::make-driver))))
(defconst *kairos-impl-target-svex*
  (sv::driver->value
   (or (cdr (assoc-equal '("{target_signal}") *kairos-impl-assigns*))
       (sv::make-driver))))

;; Mode-A theorem: under reset, both modules' target signal evaluates
;; to 0.  Cross-module — single FGL theorem covers BOTH SVEX models.
;; This is the API-validation milestone for ATH-911; cycle-equivalence
;; refinement proofs (Mode B) are Mode-A's follow-up.
(fgl::def-fgl-thm kairos-two-module-target-zero-on-reset
  :hyp t
  :concl
  (b* ((env (list (cons (sv::make-svar :name "rst_n" :delay 0)
                        (sv::2vec 0))
                  (cons (sv::make-svar :name "{target_signal}" :delay 1)
                        (sv::2vec 0))
                  (cons (sv::make-svar :name "running" :delay 1)
                        (sv::2vec 0))
                  (cons (sv::make-svar :name "go" :delay 0)
                        (sv::2vec 0))
                  (cons (sv::make-svar :name "pc" :delay 1)
                        (sv::2vec 0))))
       (val-spec (sv::svex-eval *kairos-spec-target-svex* env))
       (val-impl (sv::svex-eval *kairos-impl-target-svex* env)))
    (and (equal (sv::4vec->lower val-spec) 0)
         (equal (sv::4vec->lower val-impl) 0))))
"""

    work_dir.mkdir(parents=True, exist_ok=True)
    p1_acl2 = work_dir / f"{book1_stem}.acl2"
    p1_lisp = work_dir / f"{book1_stem}.lisp"
    p2_acl2 = work_dir / f"{book2_stem}.acl2"
    p2_lisp = work_dir / f"{book2_stem}.lisp"
    p1_acl2.write_text(book1_acl2)
    p1_lisp.write_text(book1_lisp)
    p2_acl2.write_text(book2_acl2)
    p2_lisp.write_text(book2_lisp)
    return p1_acl2, p1_lisp, p2_acl2, p2_lisp


@dataclass
class TwoModuleRefinementResult:
    """Result of a two-module SI-vs-PIPE refinement proof."""

    spec_module: str = ""
    impl_module: str = ""
    top_wrapper: str = ""
    target_signal: str = ""
    vl_parsed: bool = False
    spec_module_resolved: bool = False
    impl_module_resolved: bool = False
    cross_module_proved: bool = False
    elapsed_sec: float = 0.0
    book1_cert_path: str | None = None
    book2_cert_path: str | None = None
    transcript: str = ""
    qed_count: int = 0

    @property
    def success(self) -> bool:
        return (self.vl_parsed and self.spec_module_resolved
                and self.impl_module_resolved and self.cross_module_proved)


def refinement_prove_two_module(
    sv_files: list[str | Path],
    *,
    top_wrapper_module: str,
    spec_module_pattern: str,
    impl_module_pattern: str,
    target_signal: str = "halted",
    timeout_sec: int = 600,
    acl2_bin: str | None = None,
) -> TwoModuleRefinementResult:
    """Two-module refinement proof: prove a target signal matches across
    spec and impl modules, both elaborated from the same wrapper.

    ATH-911 follow-up to ATH-906.  Mode-A theorem (target=0 on reset
    for both modules) validates the cross-module extraction shape;
    cycle-equivalence Mode-B is the next iteration.

    Args:
        sv_files: SystemVerilog sources (must include the wrapper +
            both child modules + their package).
        top_wrapper_module: top-level wrapper that instantiates both.
            VL elaborates both children into the modalist.
        spec_module_pattern: prefix to resolve the spec module against
            the modalist (matches parameter-mangled names like
            ``cpu_single_issue$XORMATH=0``).
        impl_module_pattern: same, for the impl module.
        target_signal: signal name to compare across both modules
            (default ``halted``).
        timeout_sec: wall-clock timeout.
        acl2_bin: override ACL2 binary path.

    Returns:
        :class:`TwoModuleRefinementResult` with cross-module proof
        status and per-book cert paths.
    """
    from kairos.observe import emit
    import tempfile

    acl2 = acl2_bin or _find_acl2()
    cert_pl = _find_cert_pl(acl2)
    sv_paths = [str(Path(f).resolve()) for f in sv_files]

    work_dir = Path(tempfile.mkdtemp(prefix="kairos_acl2_twomod_"))
    p1_acl2, p1_lisp, p2_acl2, p2_lisp = _generate_two_module_proof(
        sv_paths, top_wrapper_module, spec_module_pattern,
        impl_module_pattern, target_signal, work_dir,
    )
    book2_stem = p2_lisp.stem

    emit("acl2_two_module_refinement_start", {
        "top_wrapper": top_wrapper_module,
        "spec_module": spec_module_pattern,
        "impl_module": impl_module_pattern,
        "target_signal": target_signal,
        "sv_files": sv_paths,
        "message": (
            f"Two-module VL+FGL refinement: {spec_module_pattern} vs "
            f"{impl_module_pattern} via wrapper {top_wrapper_module}."
        ),
    }, run_subtype="theorem_proving")

    t0 = time.monotonic()
    proc = subprocess.run(
        [cert_pl, "--acl2", acl2, book2_stem],
        cwd=str(work_dir),
        capture_output=True,
        text=True,
        timeout=timeout_sec,
        env=safe_env_for_acl2(),  # ATH-1212a
    )
    elapsed = time.monotonic() - t0

    book1_cert = work_dir / f"{p1_lisp.stem}.cert"
    book1_out = work_dir / f"{p1_lisp.stem}.cert.out"
    book2_cert = work_dir / f"{p2_lisp.stem}.cert"
    book2_out = work_dir / f"{p2_lisp.stem}.cert.out"

    transcript_parts: list[str] = []
    if book1_out.exists():
        transcript_parts.append(
            "=== book1 cert.out ===\n" + book1_out.read_text()
        )
    if book2_out.exists():
        transcript_parts.append(
            "=== book2 cert.out ===\n" + book2_out.read_text()
        )
    transcript = "\n\n".join(transcript_parts) if transcript_parts else proc.stdout

    result = TwoModuleRefinementResult(
        spec_module=spec_module_pattern,
        impl_module=impl_module_pattern,
        top_wrapper=top_wrapper_module,
        target_signal=target_signal,
        vl_parsed=book1_cert.exists(),
        spec_module_resolved="[kairos] spec-mod found: T" in transcript,
        impl_module_resolved="[kairos] impl-mod found: T" in transcript,
        cross_module_proved=book2_cert.exists(),
        elapsed_sec=elapsed,
        book1_cert_path=str(book1_cert) if book1_cert.exists() else None,
        book2_cert_path=str(book2_cert) if book2_cert.exists() else None,
        transcript=transcript[-4000:],
        qed_count=transcript.count("DEFTHM"),
    )

    emit("acl2_two_module_refinement_result", {
        "top_wrapper": top_wrapper_module,
        "spec_module": spec_module_pattern,
        "impl_module": impl_module_pattern,
        "target_signal": target_signal,
        "vl_parsed": result.vl_parsed,
        "spec_module_resolved": result.spec_module_resolved,
        "impl_module_resolved": result.impl_module_resolved,
        "cross_module_proved": result.cross_module_proved,
        "elapsed_sec": round(elapsed, 1),
        "qed_count": result.qed_count,
        "verification_status": "machine_verified" if result.success else "partial",
        "book1_cert": result.book1_cert_path,
        "book2_cert": result.book2_cert_path,
        "message": (
            f"Two-module {spec_module_pattern} vs {impl_module_pattern}: "
            f"{'Q.E.D.' if result.success else 'did not close'}."
        ),
    }, run_subtype="theorem_proving")

    return result


# ─── ATH-913: cycle-equivalence Mode B ──────────────────────────────


@dataclass
class CycleEquivalenceResult:
    """ATH-913 outcome: cycle-equivalence under arbitrary input traces.

    Two trust roots are supported:

    * ``ebmc-k-induction`` (default): drives BMC + k-induction via
      ``kairos.sv.cegar_incremental``.  Trust root chain: VL parser
      (in EBMC) + EBMC's k-induction algorithm.  Customer-defensible
      equivalence claim today.
    * ``acl2-fgl``: future single-trust-root variant via defsvtv$ +
      FGL.  Raises NotImplementedError until the SV books'
      unpacked-array-port limitation is worked around (the same
      blocker we hit for the cpu_single_issue defsvtv$ attempt in
      Phase 1).  Tracking ticket: this one.
    """

    spec_module: str
    impl_module: str
    top_wrapper: str
    bound: int
    trust_root: str
    proved: bool = False
    elapsed_sec: float = 0.0
    cegar_result: Any = None
    message: str = ""

    @property
    def success(self) -> bool:
        return self.proved


def refinement_prove_cycle_equivalence(
    sv_files: list[str | Path],
    *,
    top_wrapper_module: str,
    spec_module_pattern: str,
    impl_module_pattern: str,
    bound: int = 10,
    reset_expr: str | None = "!rst_n",
    extra_args: list[str] | None = None,
    timeout_sec: int = 1200,
    trust_root: str = "ebmc-k-induction",
    flatten: bool = True,
) -> CycleEquivalenceResult:
    """ATH-913 Mode B: prove cycle-equivalence between two modules
    (typically ``cpu_single_issue`` vs ``cpu_pipelined``) under
    arbitrary input traces.  Customer-facing equivalence claim.

    Args:
        sv_files: SV sources including the wrapper + both children +
            their package.
        top_wrapper_module: top-level wrapper that asserts equality
            between the two modules' observable signals.
        spec_module_pattern / impl_module_pattern: kept for
            ``CycleEquivalenceResult`` accounting (the actual proof
            runs against the wrapper's SVA assertions; module names
            don't shape the dispatch).
        bound: k-induction depth.
        reset_expr: reset signal expression (default ``!rst_n``).
        extra_args: extra EBMC flags (e.g. defines).
        timeout_sec: per-step timeout for the underlying CEGAR loop.
        trust_root: ``ebmc-k-induction`` (default, ships today) or
            ``acl2-fgl`` (future single-trust-root variant —
            currently raises NotImplementedError).
        flatten: preprocess via the SV flattener.

    Returns:
        :class:`CycleEquivalenceResult`.

    Raises:
        NotImplementedError: when ``trust_root='acl2-fgl'`` (deferred
            to a future ticket).
        ValueError: when ``trust_root`` is not one of the two
            recognised values.
    """
    from kairos.observe import emit

    valid_roots = {"ebmc-k-induction", "acl2-fgl"}
    if trust_root not in valid_roots:
        raise ValueError(
            f"trust_root must be one of {sorted(valid_roots)}, "
            f"got: {trust_root!r}"
        )

    emit("acl2_cycle_equivalence_start", {
        "top_wrapper": top_wrapper_module,
        "spec_module": spec_module_pattern,
        "impl_module": impl_module_pattern,
        "bound": bound,
        "trust_root": trust_root,
        "message": (
            f"Cycle-equivalence (Mode B): {spec_module_pattern} vs "
            f"{impl_module_pattern} via {top_wrapper_module} at "
            f"bound={bound}, trust_root={trust_root}."
        ),
    }, run_subtype="theorem_proving")

    if trust_root == "acl2-fgl":
        raise NotImplementedError(
            "trust_root='acl2-fgl' (single-trust-root cycle-equivalence "
            "via defsvtv$ + FGL) is not yet implemented.  Blocker: "
            "Centaur SV books' unpacked-array-port limitation (same "
            "issue we hit on cpu_single_issue defsvtv$ attempts in "
            "Phase 1).  Use trust_root='ebmc-k-induction' for the "
            "customer-defensible claim today."
        )

    # trust_root == "ebmc-k-induction"
    from kairos.sv.cegar_incremental import incremental_cegar

    t0 = time.monotonic()
    try:
        cegar = incremental_cegar(
            sv_files,
            top_module=top_wrapper_module,
            bound=bound,
            max_iter=1,  # single k-induction attempt; no LLM proposer
            reset_expr=reset_expr,
            extra_args=extra_args,
            flatten=flatten,
            proposer=None,
            timeout_per_step_sec=timeout_sec,
        )
    except Exception as e:  # noqa: BLE001 — broad-catch fallback
        elapsed = time.monotonic() - t0
        result = CycleEquivalenceResult(
            spec_module=spec_module_pattern,
            impl_module=impl_module_pattern,
            top_wrapper=top_wrapper_module,
            bound=bound,
            trust_root=trust_root,
            proved=False,
            elapsed_sec=elapsed,
            message=f"cegar dispatch failed: {e}",
        )
        emit("acl2_cycle_equivalence_result", {
            "top_wrapper": top_wrapper_module,
            "spec_module": spec_module_pattern,
            "impl_module": impl_module_pattern,
            "trust_root": trust_root,
            "proved": False,
            "elapsed_sec": round(elapsed, 1),
            "verification_status": "unverified",
            "message": result.message,
        }, run_subtype="theorem_proving")
        return result

    elapsed = time.monotonic() - t0
    result = CycleEquivalenceResult(
        spec_module=spec_module_pattern,
        impl_module=impl_module_pattern,
        top_wrapper=top_wrapper_module,
        bound=bound,
        trust_root=trust_root,
        proved=cegar.proved,
        elapsed_sec=elapsed,
        cegar_result=cegar,
        message=(
            f"k-induction at bound={bound}: "
            f"{'proved' if cegar.proved else 'did not close'}"
        ),
    )

    emit("acl2_cycle_equivalence_result", {
        "top_wrapper": top_wrapper_module,
        "spec_module": spec_module_pattern,
        "impl_module": impl_module_pattern,
        "trust_root": trust_root,
        "bound": bound,
        "proved": result.proved,
        "elapsed_sec": round(elapsed, 1),
        "verification_status": "machine_verified" if result.proved else "unverified",
        "iterations": cegar.iterations,
        "message": result.message,
    }, run_subtype="theorem_proving")

    return result
