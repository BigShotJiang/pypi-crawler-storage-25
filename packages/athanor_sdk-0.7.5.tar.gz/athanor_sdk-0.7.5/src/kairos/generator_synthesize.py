"""kairos.generator_synthesize — LLM-Lean generator synthesis loop (ATH-535).

Ships the iterate-refine loop platform's PLDI '27 paper-track Phase A
(ATH-531) needs: prompt a model for a Lean generator, sample terms,
verify each via :func:`kairos.lean.predicate_verify`, re-prompt with
failures if rejection rate > target, iterate.

Per platform's cedar-paper-track-reshape spec (msg ts=1776980870):

    kairos.generator_synthesize(
        spec_bundle, model, max_iters=5,
        target_rejection_rate=0.1, trace_sink,
    ) -> GeneratorResult

Default model = ``azure_ai/kimi-k2.6-1``. Sonnet escalation at
max_iters. Opus only on explicit flag (``escalate_opus=True``).
Every iteration emits a TraceEvent with
``event_type='generator_synthesis_round'`` carrying the per-round
stats, so customer dashboards + paper-replay analytics get full
observability.

## SpecBundle shape

Callers supply a :class:`SpecBundle` that fully describes the
synthesis target. The SDK does NOT assume any specific Cedar-micro
structure — callers pass their own predicate_name + imports +
workspace, and the SDK treats the whole thing as opaque. This keeps
the primitive usable against any Lean-Lake project with a decidable
predicate (cedar-spec-bridge today, full Cedar tomorrow, any future
vertical a customer brings).

## Sampling extension point

A fresh-from-the-LLM Lean generator is text. Running it inside the
container to actually produce concrete terms takes Lake + a
customer-specific driver script. The SDK doesn't assume a sampling
strategy — callers pass a ``sample_terms`` callable that knows how
to run their generator. The default implementation asks the LLM to
emit N concrete candidate terms alongside the generator source —
that works for the Phase A experiment platform described + stays
provider-agnostic.

Callers who want real Lean-side sampling (Palamedes-style
``generator_search`` running inside the container) plug in their
own ``sample_terms`` that shells into lake. See the integration
test for an example.

## Honest scope boundaries

* Does NOT compile or run the LLM-emitted generator Lean source
  directly. That's platform's Phase A orchestration lane (ATH-531)
  since it needs the kairos-cedar monolith image + Palamedes
  scaffolding. SDK hands off the generator + samples to the caller.
* Does NOT own the prompt engineering. The default prompt is
  documented + replaceable. Platform writes the "right" prompt for
  their Phase A corpus experiment.
* Does NOT currently support async. Follow-up when platform has an
  async consumer.

Cross-ref:

* ATH-535 — this work
* ATH-531 — platform Phase A (the consumer of this)
* ATH-534 / PR #139 — ``kairos.lean.predicate_verify`` (the oracle)
* ``feedback_large_max_tokens_for_fleet.md`` — why defaults are 200k
  for Anthropic + 8000+ for reasoning providers
"""
from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable
from uuid import uuid4

from kairos.lean import predicate_verify
from kairos.trace import NoopTraceSink, TraceEvent, TraceSink


_logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────
# Types
# ─────────────────────────────────────────────────────────────────────


@dataclass
class SpecBundle:
    """Describes the synthesis target. Fully caller-supplied — the SDK
    makes no Cedar-specific assumptions so the primitive works on any
    Lean-Lake project with a decidable predicate.

    Fields match the cedar-paper-track-reshape proposal + extend it
    with imports + optional opt-outs (``example_term``) that platform
    found useful when bootstrapping the first LLM prompt.
    """

    workspace: Path
    """Absolute path to a Lake project. Passed through to
    :func:`predicate_verify` on each sample."""

    module_scratch_prefix: str
    """Dotted Lean module namespace under which the SDK writes per-
    sample scratch theorems (e.g. ``"CedarBridge.KairosGen"``). The
    SDK appends an iteration + sample index to keep module paths
    unique across calls. Must be a valid Lean dotted identifier."""

    predicate_name: str
    """Lean predicate — called as ``predicate_name <term>``. Must be
    decidable + in scope for ``imports``."""

    predicate_imports: list[str] = field(default_factory=list)
    """Lean ``import`` statements the scratch theorem needs. Typically
    at least the module that defines ``predicate_name``."""

    term_type: str = ""
    """Lean type the generator is supposed to produce (e.g.
    ``"CedarMicro.Expr"``). Used in the LLM prompt to anchor what a
    valid sample looks like. Optional but strongly recommended."""

    example_term: str = ""
    """Optional hand-picked seed term the LLM can pattern-match on.
    Seeds the first iteration's prompt when present."""


@dataclass
class SampleTermsResult:
    """Optional richer return type for ``sample_terms`` callables (ATH-563).

    Callers that wrap :func:`kairos.lean.sample_generator` or a similar
    driver can return a :class:`SampleTermsResult` instead of a bare
    ``list[str]`` to flow diagnostic info back into the iteration
    summary. Fields:

    * ``terms`` — the sampled term strings (same as the legacy
      ``list[str]`` return shape).
    * ``error`` — one-line reason the sampler produced less-than-N
      terms (e.g. ``"lake build X failed (exit=1)"``). Empty string
      when the run was fully successful.
    * ``stdout_tail`` — trailing bytes of the sampler's captured
      stdout/stderr, for operator diagnosis when the run fails
      opaquely. Empty string when not captured.

    The dataclass is a drop-in — ``sample_terms`` can still return
    ``list[str]`` directly and the loop treats it as
    ``SampleTermsResult(terms=..., error="", stdout_tail="")``.
    """

    terms: list[str]
    error: str = ""
    stdout_tail: str = ""


@dataclass
class GeneratorIteration:
    """One round of the synthesis loop."""

    iteration: int
    model: str
    generator_source: str
    """LLM-emitted Lean source for the generator — opaque to the SDK;
    passed along to ``sample_terms`` + recorded for trace replay."""

    sampled_count: int
    rejected_count: int
    rejection_reasons: list[str]
    """Classified reasons from :class:`kairos.lean.PredicateResult`
    for the rejected samples. Capped at ``_MAX_REJECTION_REASONS``."""

    tokens_in: int
    tokens_out: int
    cost_usd: float
    elapsed_sec: float

    sample_terms_error: str = ""
    """ATH-563: diagnostic returned by the sampler when it produced
    fewer than ``n_samples`` terms. Populated from
    :class:`SampleTermsResult.error` when the sampler uses the richer
    return type, OR from an exception-catch when the sampler raises.
    Empty when the sampler succeeded or returned bare ``list[str]``."""

    sample_terms_stdout_tail: str = ""
    """ATH-563: last ~4KB of captured sampler output for operator
    diagnosis. Populated from :class:`SampleTermsResult.stdout_tail`.
    Empty when not captured."""

    @property
    def rejection_rate(self) -> float | None:
        """Rejected / total. ``None`` when no samples were drawn — the
        caller must distinguish "nothing sampled" (sampler error) from
        "sampled and all rejected" (real predicate failure). ATH-563
        refinement: pre-563 this returned 1.0 for both cases which
        misleadingly looked like a predicate-level failure."""
        if self.sampled_count <= 0:
            return None
        return self.rejected_count / self.sampled_count


@dataclass
class GeneratorResult:
    """Final output of :func:`generator_synthesize`."""

    converged: bool
    """True iff rejection_rate <= target_rejection_rate in some
    iteration. False when max_iters exhausted without convergence."""

    final_rejection_rate: float | None
    """ATH-563: ``None`` when ``iterations[-1]`` drew zero samples —
    distinguishes sampler failure from real predicate failure. Pre-563
    this field was always ``float`` (1.0 on empty), which conflated
    the two cases on dashboards."""

    iterations: list[GeneratorIteration]
    final_generator_source: str
    total_tokens_in: int
    total_tokens_out: int
    total_cost_usd: float

    @property
    def total_iterations(self) -> int:
        return len(self.iterations)


# Cap for the rejection-reason list carried in each TraceEvent —
# protects the SupabaseTraceSink row-size budget when a generator
# produces many distinctly-failing samples.
_MAX_REJECTION_REASONS = 30


# ─────────────────────────────────────────────────────────────────────
# Default LLM + sampling implementations
# ─────────────────────────────────────────────────────────────────────


def _default_sample_terms(
    generator_source: str,  # noqa: ARG001
    llm_response_text: str,
    n_samples: int,
) -> list[str]:
    """Default sampler: extract N candidate terms from the LLM's text.

    Looks for a ``SAMPLES:`` section in the response containing one
    term per line. Platform's Phase A prompts instruct the LLM to
    produce this section alongside the generator source. Customers
    who want real Lean-side sampling inject their own callable.

    Returns: list of up-to-N term source strings. Empty when the
    response has no SAMPLES block.
    """
    m = re.search(
        r"^\s*SAMPLES\s*:\s*\n(.+?)(?:\n\s*(?:END SAMPLES|EXPLANATION|$))",
        llm_response_text,
        flags=re.MULTILINE | re.DOTALL | re.IGNORECASE,
    )
    if not m:
        return []
    lines = [ln.strip() for ln in m.group(1).splitlines()]
    terms = []
    for ln in lines:
        if not ln or ln.startswith("#") or ln.startswith("--"):
            continue
        # Strip leading bullets / numbering like "1. " or "- ".
        ln = re.sub(r"^\s*(?:\d+\.\s+|-\s+|\*\s+)", "", ln)
        terms.append(ln)
        if len(terms) >= n_samples:
            break
    return terms


def _default_llm_call(
    prompt: str,
    model: str,
    *,
    max_tokens: int,
    timeout_sec: int,
) -> tuple[str, int, int, float]:
    """Default LLM dispatcher. Returns ``(response_text, tokens_in,
    tokens_out, cost_usd)``.

    Uses litellm to stay provider-agnostic. Customers with their own
    LLM client inject via the ``llm_call`` kwarg on
    :func:`generator_synthesize`.
    """
    from kairos.model_client.registry import get_client

    client = get_client(model)
    messages = [{"role": "user", "content": prompt}]
    resp = client.call(messages, max_tokens=max_tokens, timeout=timeout_sec)
    text = resp.assistant_turn().get("content", "")
    if not text:
        text = resp.assistant_turn().get("reasoning_content", "")
    tok_in = resp.prompt_tokens
    tok_out = resp.completion_tokens
    cost = getattr(resp, "cost_usd", 0.0) or 0.0
    return text, int(tok_in), int(tok_out), float(cost)


def _build_prompt(spec_bundle: SpecBundle, history: list[GeneratorIteration],
                  n_samples: int) -> str:
    """Build the per-iteration prompt. First iteration uses the seed
    example + predicate description; subsequent iterations include
    the previous failures as negative examples."""
    header = (
        f"You are synthesizing a Lean 4 generator for type "
        f"{spec_bundle.term_type!r} such that every produced term "
        f"satisfies the decidable predicate "
        f"`{spec_bundle.predicate_name}`.\n\n"
        f"Output ONE generator in Lean 4 syntax, then produce "
        f"{n_samples} concrete candidate terms that your generator "
        f"should produce.\n\n"
        f"Imports available in this project:\n"
        + "\n".join(f"  - {i}" for i in spec_bundle.predicate_imports)
        + "\n\n"
    )

    if spec_bundle.example_term:
        header += (
            f"Example term known to satisfy the predicate (seed your "
            f"generator on this shape):\n"
            f"```\n{spec_bundle.example_term}\n```\n\n"
        )

    history_block = ""
    if history:
        last = history[-1]
        rejected_preview = "\n".join(
            f"  - {r}" for r in last.rejection_reasons[:10]
        )
        # ATH-563: rate is None when sampler drew 0 terms. Show a
        # descriptive phrase instead of formatting None% so the LLM
        # sees the real state and can adjust generator shape.
        rate_phrase = (
            f"rate={last.rejection_rate:.1%}"
            if last.rejection_rate is not None
            else "rate=n/a (sampler produced 0 terms)"
        )
        history_block = (
            f"\nYour PREVIOUS iteration (attempt #{last.iteration+1}) had "
            f"{last.rejected_count}/{last.sampled_count} rejections "
            f"({rate_phrase}). Top reasons:\n"
            f"{rejected_preview}\n\n"
            f"DO NOT repeat those mistakes. Adjust the generator so "
            f"rejected terms are no longer produced.\n\n"
        )

    output_contract = (
        "Output format (STRICT, machine-parsed):\n"
        "\n"
        "GENERATOR:\n"
        "<one Lean 4 def that produces values of the target type>\n"
        "\n"
        "SAMPLES:\n"
        "<term 1>\n"
        "<term 2>\n"
        f"... up to {n_samples} terms, one per line\n"
        "\n"
        "END SAMPLES\n"
        "\n"
        "EXPLANATION:\n"
        "<short description of how the generator constructs terms>\n"
    )

    return header + history_block + output_contract


def _extract_generator_source(llm_response_text: str) -> str:
    """Extract the Lean generator block. Falls back to empty when the
    LLM doesn't emit the GENERATOR section (the loop tracks this
    as a malformed iteration).

    ATH-560: LLMs frequently wrap code in markdown fences (```lean / ```
    / ~~~ / etc.) inside the GENERATOR block. We strip matched outer
    fence pairs so ``lake build`` doesn't parse the backticks as Lean
    syntax. Mismatched / interior fences pass through untouched — the
    caller still sees the original text and can file a bug if it
    confuses the verifier.
    """
    # \Z (end of whole string) NOT $ (end-of-line under MULTILINE) —
    # otherwise the non-greedy .+? terminates on the first newline when
    # the body starts with a markdown fence line like ```lean. Pre-560
    # behaviour happened to work for single-line generators; ATH-560
    # broadens it to multi-line fenced bodies.
    m = re.search(
        r"^\s*GENERATOR\s*:\s*\n(.+?)(?:\n\s*SAMPLES\s*:|\Z)",
        llm_response_text,
        flags=re.MULTILINE | re.DOTALL | re.IGNORECASE,
    )
    if not m:
        return ""
    return _strip_markdown_fences(m.group(1).strip())


# Match an outer fenced-code block with optional language hint:
#
#     ```lean
#     def foo := ...
#     ```
#
# Also matches ~~~, ~~~lean, ```, ``` (no hint). Requires the fence
# length to match between open and close (so interior single-line
# "```inline```" inside the body doesn't fool the matcher).
_FENCE_RE = re.compile(
    r"\A(?P<fence>```+|~~~+)[^\n]*\n(?P<body>.*)\n(?P=fence)\s*\Z",
    flags=re.DOTALL,
)


def _strip_markdown_fences(text: str) -> str:
    """Remove a single outer ```...``` / ~~~...~~~ fence from ``text``
    if one exists. Returns the inner body stripped of leading/trailing
    whitespace, or the original ``text`` when no matching outer fence
    is present.
    """
    stripped = text.strip()
    m = _FENCE_RE.match(stripped)
    if m:
        return m.group("body").strip()
    return stripped


# ─────────────────────────────────────────────────────────────────────
# Main loop
# ─────────────────────────────────────────────────────────────────────


_SENTINEL: Any = object()


def generator_synthesize(
    spec_bundle: SpecBundle,
    *,
    model: str | None = None,
    max_iters: int = 5,
    target_rejection_rate: float = 0.1,
    n_samples: int = 20,
    trace_sink: Any = _SENTINEL,
    run_id: str | None = None,
    max_tokens: int = 32768,
    timeout_sec: int = 300,
    escalate_opus: bool = False,
    llm_call: Callable[..., tuple[str, int, int, float]] | None = None,
    sample_terms: Callable[[str, str, int], list[str]] | None = None,
) -> GeneratorResult:
    """Iterate LLM-generator-proposal → sample → predicate-verify → retry.

    See module docstring for full semantics. Summary:

    * First iteration: model is ``model`` arg (default kimi-k2.6-1).
      Subsequent iterations stay on the same model.
    * Last iteration escalates to sonnet unless already on a Claude
      model. Opus only on ``escalate_opus=True``.
    * Convergence: rejection_rate <= target_rejection_rate.
    * Per-iteration trace: ``TraceEvent(event_type=
      'generator_synthesis_round', payload={iteration, model,
      tokens_in, tokens_out, sampled_count, rejected_count,
      rejection_reasons})`` emitted to ``trace_sink``.

    Args:
        spec_bundle: the synthesis target.
        model: initial LLM. Default kimi-k2.6-1 via Azure-AI route.
        max_iters: retry budget. Default 5.
        target_rejection_rate: convergence floor. Default 0.1 (10%).
        n_samples: per-iteration sample count. Default 20.
        trace_sink: where to emit per-iteration TraceEvents. Default
            NoopTraceSink.
        run_id: caller-supplied UUID for trace continuity. Auto-
            generated when None.
        max_tokens: LLM budget per call. Default 32768 (reasoning-
            model headroom per ATH-529).
        timeout_sec: LLM call timeout. Default 300s (5 min).
        escalate_opus: allow Opus on final escalation iteration.
            Default False (Aidan cost directive).
        llm_call: custom dispatcher ``(prompt, model, *, max_tokens,
            timeout_sec) -> (text, tok_in, tok_out, cost)``. Defaults
            to :func:`_default_llm_call` via litellm.
        sample_terms: custom ``(generator_source, response_text,
            n_samples) -> list[str]`` extractor. Default parses the
            SAMPLES: block from the LLM response. Customers doing
            real Lean-side sampling (running the generator in Lake)
            inject their own.

    Returns:
        :class:`GeneratorResult`.
    """
    # ATH-550 + ATH-551: default-on tracing + auto-wrap session.
    #
    # The trace_sink arg has three modes:
    #   * _SENTINEL (default, kwarg omitted) → auto-detect:
    #       - If inside a kairos.session, use the session's sink.
    #       - Else use default_sink_from_env() (SupabaseTraceSink when env
    #         populated; NoopTraceSink when offline).
    #   * None (explicit) → NoopTraceSink (pre-ATH-550 opt-out preserved).
    #   * TraceSink instance → use it as-is.
    from kairos.trace import (
        default_sink_from_env as _default_sink,
        NoopTraceSink as _Noop,
    )
    from contextlib import nullcontext as _nullcontext

    # ATH-816: resolve default model from preset module so the literal
    # lives in one auditable place. Lazy import avoids a circular at
    # module-import time.
    if model is None:
        from kairos.model_presets import DEFAULT_GENERATOR_MODEL
        model = DEFAULT_GENERATOR_MODEL

    # ATH-971 Phase 4: detection routed through the canonical observe
    # context. The legacy CURRENT_SESSION read is removed (Phase 3
    # carried it as a deprecation-cycle fallback; Phase 4 closes the
    # cycle).
    # Lazy import for circular-import safety: kairos.observe pulls
    # heavy litellm wrapper machinery + may re-enter generator_synthesize
    # transitively during init.
    import sys as _sys_obs
    _observe_mod = _sys_obs.modules.get("kairos.observe")
    if _observe_mod is None:  # pragma: no cover
        from kairos import observe as _observe_mod  # type: ignore[no-redef, unused-ignore]
    _active_obs_ctx = _observe_mod.active_session_context()  # type: ignore[union-attr]

    if trace_sink is _SENTINEL:
        # Auto-detect. Active observe context's sink wins if present;
        # else env default.
        if _active_obs_ctx is not None and _active_obs_ctx.sink is not None:
            resolved_sink = _active_obs_ctx.sink
        else:
            resolved_sink = _default_sink()
    elif trace_sink is None:
        # Explicit opt-out.
        resolved_sink = NoopTraceSink()
    else:
        resolved_sink = trace_sink

    # ATH-551 / ATH-971 Phase 4: auto-wrap when no session is active
    # AND sink is non-Noop. The synthetic session fires the parent
    # solve_runs row + close-aggregates cost (ATH-545 + ATH-548), so
    # the run surfaces in /solve-runs with zero ceremony. Detection
    # uses the canonical _ObserveContext only -- the legacy
    # CURRENT_SESSION fallback was Phase 3 transitional.
    auto_wrap_session = (
        _active_obs_ctx is None
        and not isinstance(resolved_sink, _Noop)
    )

    # Local import to avoid circular (prove.py imports generator_synthesize
    # via its public surface re-exports downstream).
    if auto_wrap_session:
        # ATH-614 phase 2: keep the canonical name `session` so the static
        # gate (tools/check_sdk_sessions.py) sees the bracket. Alias-as
        # form was opaque to the AST scanner.
        from kairos.prove import session

        synthetic_ctx: Any = session(
            task_id=f"generator-synthesize-{uuid4().hex[:8]}",
            trace_sink=resolved_sink,
            vertical="other",
            builder_model=model,
        )
    else:
        synthetic_ctx = _nullcontext()

    resolved_llm = llm_call or _default_llm_call
    resolved_sampler = sample_terms or _default_sample_terms

    with synthetic_ctx as _synth_sess:
        # If we auto-wrapped, adopt the session's run_id so child events
        # join the parent row. Caller-supplied run_id wins only when not
        # auto-wrapping (caller is explicit about joining their own rows).
        if auto_wrap_session and _synth_sess is not None:
            resolved_run_id = _synth_sess.session_id
        else:
            resolved_run_id = run_id or str(uuid4())

        # ATH-819: capture call args before the loop fires so a customer
        # reading /solve-runs/[id] can see what generator_synthesize was
        # given (predicate_name, model, knobs, spec preview). Big strings
        # in the bundle (example_term, generator prefix) get reduced to
        # {sha256, length, preview_first_300} via reduce_long_arg.
        from kairos.trace import emit_function_inputs, reduce_long_arg
        emit_function_inputs(
            resolved_sink,
            run_id=resolved_run_id,
            run_subtype="generator_synthesis",
            function_name="kairos.generator_synthesize",
            args={
                "predicate_name": spec_bundle.predicate_name,
                "predicate_imports": list(spec_bundle.predicate_imports),
                "example_term": reduce_long_arg(
                    getattr(spec_bundle, "example_term", None),
                ),
                "model": model,
                "max_iters": max_iters,
                "target_rejection_rate": target_rejection_rate,
                "n_samples": n_samples,
                "max_tokens": max_tokens,
                "timeout_sec": timeout_sec,
                "escalate_opus": escalate_opus,
                "auto_wrapped_session": auto_wrap_session,
            },
        )

        return _run_generator_synthesize_loop(
            spec_bundle=spec_bundle,
            model=model,
            max_iters=max_iters,
            target_rejection_rate=target_rejection_rate,
            n_samples=n_samples,
            resolved_sink=resolved_sink,
            resolved_run_id=resolved_run_id,
            max_tokens=max_tokens,
            timeout_sec=timeout_sec,
            escalate_opus=escalate_opus,
            resolved_llm=resolved_llm,
            resolved_sampler=resolved_sampler,
        )


def _run_generator_synthesize_loop(
    *,
    spec_bundle: SpecBundle,
    model: str,
    max_iters: int,
    target_rejection_rate: float,
    n_samples: int,
    resolved_sink: TraceSink,
    resolved_run_id: str,
    max_tokens: int,
    timeout_sec: int,
    escalate_opus: bool,
    resolved_llm: Callable[..., tuple[str, int, int, float]],
    resolved_sampler: Callable[[str, str, int], list[str]],
) -> GeneratorResult:
    """Core generator_synthesize loop. Extracted so the public entry can
    wrap it in a synthetic kairos.session (ATH-551) without double-
    nesting the iteration logic."""

    iterations: list[GeneratorIteration] = []
    converged = False
    current_model = model
    seq = 0

    for iter_idx in range(max_iters):
        # Final-iter escalation path (only if not already on Claude).
        is_final = (iter_idx == max_iters - 1)
        if is_final and not current_model.startswith(("anthropic/", "azure_ai/claude")):
            # ATH-815: escalation POLICY (when to escalate) stays in
            # the primitive — that's protocol logic, not a model
            # choice. The model STRINGS live in
            # ``kairos.model_presets`` so the literal isn't baked
            # into the branch. Behavior is unchanged from the
            # pre-migration inline literals.
            from kairos.model_presets import (
                ESCALATION_OPUS,
                ESCALATION_SONNET,
            )
            current_model = (
                ESCALATION_OPUS
                if escalate_opus
                else ESCALATION_SONNET
            )
            _logger.info(
                "generator_synthesize: escalating to %s on final iteration",
                current_model,
            )

        prompt = _build_prompt(spec_bundle, iterations, n_samples)
        start = time.monotonic()
        text, tok_in, tok_out, cost = resolved_llm(
            prompt,
            current_model,
            max_tokens=max_tokens,
            timeout_sec=timeout_sec,
        )
        generator_source = _extract_generator_source(text)

        # ATH-563: catch sampler exceptions + unwrap SampleTermsResult
        # so the iteration summary surfaces WHY sample_terms returned 0
        # terms. Pre-563 any sampler failure disappeared as "1.0
        # rejection rate" with no diagnostic.
        sample_terms_error = ""
        sample_terms_stdout_tail = ""
        try:
            _sampler_return = resolved_sampler(
                generator_source, text, n_samples,
            )
        except Exception as exc:  # noqa: BLE001
            terms = []
            sample_terms_error = (
                f"sampler raised {type(exc).__name__}: {exc}"[:500]
            )
        else:
            if isinstance(_sampler_return, SampleTermsResult):
                terms = list(_sampler_return.terms)
                sample_terms_error = _sampler_return.error[:500]
                sample_terms_stdout_tail = _sampler_return.stdout_tail[:4000]
            elif isinstance(_sampler_return, list):
                terms = _sampler_return
            else:
                terms = []
                sample_terms_error = (
                    f"sampler returned {type(_sampler_return).__name__!r}; "
                    "expected list[str] or SampleTermsResult"
                )

        # Verify each sampled term.
        rejected_reasons: list[str] = []
        for i, term in enumerate(terms):
            try:
                r = predicate_verify(
                    workspace=spec_bundle.workspace,
                    module_path=(
                        f"{spec_bundle.module_scratch_prefix}"
                        f".Iter{iter_idx}S{i}"
                    ),
                    predicate_name=spec_bundle.predicate_name,
                    term_source=term,
                    imports=list(spec_bundle.predicate_imports),
                    timeout_sec=min(timeout_sec, 120),
                )
            except Exception as exc:  # noqa: BLE001
                rejected_reasons.append(
                    f"verifier raised {type(exc).__name__}: {exc}"[:200]
                )
                continue
            if not r.verified:
                rejected_reasons.append(r.reason[:200])

        sampled_count = len(terms)
        rejected_count = len(rejected_reasons)
        iteration = GeneratorIteration(
            iteration=iter_idx,
            model=current_model,
            generator_source=generator_source,
            sampled_count=sampled_count,
            rejected_count=rejected_count,
            rejection_reasons=rejected_reasons[:_MAX_REJECTION_REASONS],
            tokens_in=tok_in,
            tokens_out=tok_out,
            cost_usd=cost,
            elapsed_sec=time.monotonic() - start,
            sample_terms_error=sample_terms_error,
            sample_terms_stdout_tail=sample_terms_stdout_tail,
        )
        iterations.append(iteration)

        # ATH-536: emit per-iteration TraceEvent for paper reproducibility.
        _emit_synthesis_round(
            sink=resolved_sink,
            run_id=resolved_run_id,
            seq=seq,
            iteration=iteration,
        )
        seq += 1

        # ATH-563: rejection_rate is None when 0 samples drawn;
        # gate convergence on both a real rate and samples > 0.
        _rate = iteration.rejection_rate
        if (
            sampled_count > 0
            and _rate is not None
            and _rate <= target_rejection_rate
        ):
            converged = True
            break

    # ATH-563: final_rejection_rate follows the None-for-empty
    # convention too, so paper tables + dashboards can distinguish
    # "sampler gave us 0 terms" from "sampler gave us terms but they
    # all got rejected". Pre-563 this silently returned 1.0 for both.
    final_rate: float | None = None
    if iterations:
        final_rate = iterations[-1].rejection_rate

    final_generator_source = (
        iterations[-1].generator_source if iterations else ""
    )
    return GeneratorResult(
        converged=converged,
        final_rejection_rate=final_rate,
        iterations=iterations,
        final_generator_source=final_generator_source,
        total_tokens_in=sum(it.tokens_in for it in iterations),
        total_tokens_out=sum(it.tokens_out for it in iterations),
        total_cost_usd=sum(it.cost_usd for it in iterations),
    )


def _emit_synthesis_round(
    *,
    sink: TraceSink,
    run_id: str,
    seq: int,
    iteration: GeneratorIteration,
) -> None:
    """ATH-536: standardize the `generator_synthesis_round` event
    payload. Sink emit errors are swallowed (TraceSink Protocol
    contract — must not break the synthesis loop)."""
    event = TraceEvent(
        run_id=run_id,
        run_type="sdk_orchestration",
        run_subtype="autoformalize",
        event_type="generator_synthesis_round",
        sequence=seq,
        payload={
            "iteration": iteration.iteration,
            "model": iteration.model,
            "tokens_in": iteration.tokens_in,
            "tokens_out": iteration.tokens_out,
            "sampled_count": iteration.sampled_count,
            "rejected_count": iteration.rejected_count,
            "rejection_reasons": iteration.rejection_reasons,
            "cost_usd": round(iteration.cost_usd, 6),
            "elapsed_sec": round(iteration.elapsed_sec, 3),
            # ATH-563: None when sampler drew 0 terms. Dashboard
            # renders that as "—" / sampler-error, distinct from a
            # real 100% rejection rate on a well-populated sample.
            "rejection_rate": (
                round(iteration.rejection_rate, 4)
                if iteration.rejection_rate is not None
                else None
            ),
            # ATH-563: sampler diagnostics. Both empty-string when the
            # sampler returned a bare list[str] successfully.
            "sample_terms_error": iteration.sample_terms_error,
            "sample_terms_stdout_tail": iteration.sample_terms_stdout_tail,
        },
    )
    try:
        sink.emit(event)
    except Exception:  # noqa: BLE001
        _logger.exception(
            "generator_synthesize: TraceSink.emit raised — swallowing"
        )


__all__ = [
    "SpecBundle",
    "SampleTermsResult",
    "GeneratorIteration",
    "GeneratorResult",
    "generator_synthesize",
]
