"""ATH-1141: spec mining from simulation traces.

Customers have VCD/FST simulation traces but no formal specs.
kairos extracts formal properties automatically by observing
signal behavior patterns in the trace.

Usage:
    kairos verify --mine-specs trace.vcd
    from kairos.spec_mining import mine_specs
    specs = mine_specs("trace.vcd", module="fifo")

Properties mined:
- One-hot invariants (exactly one bit set)
- Monotone counters (never decreases)
- Mutual exclusion (never both high)
- Bounded signals (stays within range)
- Reset behavior (known state after reset)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class MinedProperty:
    signal: str
    property_type: str
    expression: str
    confidence: float
    occurrences: int = 0
    description: str = ""


@dataclass
class MiningResult:
    trace_file: str
    signals_analyzed: int = 0
    properties: list[MinedProperty] = field(default_factory=list)
    error: str | None = None

    @property
    def honest_report(self) -> str:
        if self.error:
            return f"Mining failed: {self.error}"
        return (
            f"Mined {len(self.properties)} properties from "
            f"{self.signals_analyzed} signals in {self.trace_file}"
        )


def parse_vcd_signals(vcd_text: str) -> dict[str, list[tuple[int, int]]]:
    """Parse VCD (Value Change Dump) signal transitions.

    Returns {signal_name: [(time, value), ...]}.
    """
    signals: dict[str, str] = {}
    traces: dict[str, list[tuple[int, int]]] = {}
    current_time = 0

    for line in vcd_text.splitlines():
        line = line.strip()
        if not line:
            continue

        if line.startswith("$var"):
            parts = line.split()
            if len(parts) >= 5:
                sig_id = parts[3]
                sig_name = parts[4]
                signals[sig_id] = sig_name
                traces[sig_name] = []

        elif line.startswith("#"):
            try:
                current_time = int(line[1:])
            except ValueError:
                pass

        elif len(line) >= 2 and line[0] in "01xzXZ":
            val_str = line[0]
            sig_id = line[1:]
            if sig_id in signals:
                if val_str in ("x", "X", "z", "Z"):
                    continue
                val = 1 if val_str == "1" else 0
                traces[signals[sig_id]].append((current_time, val))

        elif line.startswith("b"):
            parts = line.split()
            if len(parts) == 2 and parts[1] in signals:
                bits = parts[0][1:]
                if any(c in bits for c in "xzXZ"):
                    continue
                try:
                    val = int(bits, 2)
                except ValueError:
                    continue
                traces[signals[parts[1]]].append((current_time, val))

    return traces


def mine_onehot(traces: dict[str, list[tuple[int, int]]]) -> list[MinedProperty]:
    """Detect signals that are always one-hot."""
    props = []
    for sig, transitions in traces.items():
        if not transitions:
            continue
        values = [v for _, v in transitions]
        nonzero = [v for v in values if v > 0]
        if nonzero and all((v & (v - 1)) == 0 for v in nonzero):
            if len(nonzero) >= 3:
                props.append(MinedProperty(
                    signal=sig,
                    property_type="onehot",
                    expression=f"$onehot({sig})",
                    confidence=min(1.0, len(values) / 10),
                    occurrences=len(values),
                    description=f"{sig} is always one-hot ({len(values)} observations)",
                ))
    return props


def mine_monotone(traces: dict[str, list[tuple[int, int]]]) -> list[MinedProperty]:
    """Detect signals that never decrease (monotone counters)."""
    props = []
    for sig, transitions in traces.items():
        if len(transitions) < 3:
            continue
        values = [v for _, v in transitions]
        is_monotone = all(values[i] <= values[i+1] for i in range(len(values)-1))
        if is_monotone and values[-1] > values[0]:
            props.append(MinedProperty(
                signal=sig,
                property_type="monotone",
                expression=f"always @(posedge clk) {sig} >= $past({sig})",
                confidence=min(1.0, len(values) / 20),
                occurrences=len(values),
                description=f"{sig} never decreases ({len(values)} observations)",
            ))
    return props


def mine_mutual_exclusion(traces: dict[str, list[tuple[int, int]]]) -> list[MinedProperty]:
    """Detect pairs of signals that are never both high."""
    props = []
    sig_names = list(traces.keys())
    for i, sig_a in enumerate(sig_names):
        for sig_b in sig_names[i+1:]:
            trans_a = {t: v for t, v in traces[sig_a]}
            trans_b = {t: v for t, v in traces[sig_b]}
            common_times = set(trans_a.keys()) & set(trans_b.keys())
            if len(common_times) < 3:
                continue
            both_high = sum(1 for t in common_times if trans_a[t] == 1 and trans_b[t] == 1)
            if both_high == 0 and len(common_times) >= 5:
                props.append(MinedProperty(
                    signal=f"{sig_a},{sig_b}",
                    property_type="mutex",
                    expression=f"!({sig_a} && {sig_b})",
                    confidence=min(1.0, len(common_times) / 20),
                    occurrences=len(common_times),
                    description=f"{sig_a} and {sig_b} never both high",
                ))
    return props


def mine_specs(
    trace_path: str | Path,
    *,
    module: str | None = None,
) -> MiningResult:
    """Mine formal properties from a VCD simulation trace."""
    path = Path(trace_path)
    result = MiningResult(trace_file=str(path))

    if not path.is_file():
        result.error = f"Trace file not found: {path}"
        return result

    try:
        vcd_text = path.read_text(errors="replace")
    except Exception as e:  # noqa: BLE001 — best-effort cleanup
        result.error = str(e)[:200]
        return result

    traces = parse_vcd_signals(vcd_text)
    result.signals_analyzed = len(traces)

    result.properties.extend(mine_onehot(traces))
    result.properties.extend(mine_monotone(traces))
    result.properties.extend(mine_mutual_exclusion(traces))

    result.properties.sort(key=lambda p: -p.confidence)
    return result
