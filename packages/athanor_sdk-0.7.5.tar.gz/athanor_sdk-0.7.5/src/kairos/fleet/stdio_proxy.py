"""kairos.fleet.stdio_proxy — in-container ModelClient over stdio JSON-RPC.

Lives inside a fleet-drafter container (see containers/fleet-drafter/
Containerfile). Implements the same `format_messages` + `call(messages,
temperature, max_tokens) -> ModelResponse` contract as the rest of
`kairos.model_client`, but every `.call()` is a roundtrip over stdio
to the host's :class:`kairos.fleet.host_proxy.HostLLMProxy`. The
container never holds API credentials.

Wire shape: see :mod:`kairos.fleet.host_proxy` for the full protocol
spec. Briefly, this client writes one JSON line:

    {"method": "llm_call", "model_id": ...,
     "messages": [...], "temperature": float,
     "max_tokens": int, "request_id": str}

to ``request_pipe`` and reads one JSON response line:

    {"request_id": str, "content": str | None,
     "reasoning_content": str | None, "prompt_tokens": int,
     "completion_tokens": int, "finish_reason": str | None,
     "error": str | None}

from ``response_pipe``. Each call generates a fresh request_id (uuid4
hex) and refuses any response whose request_id doesn't match — this
keeps misordered or stale responses from being silently mis-attributed.

Usage from the drafter entrypoint (already wired in
containers/fleet-drafter/drafter_entrypoint.py):

    from kairos.fleet.stdio_proxy import StdioProxyClient
    client = StdioProxyClient(
        model_id="anthropic/claude-sonnet-4-6",
        request_pipe=sys.stdout,   # write llm_call requests here
        response_pipe=sys.stdin,   # read responses here
    )
    cycle_prove(target, drafter=client)

The pipes default to ``sys.stdout`` / ``sys.stdin`` so a typical
container entrypoint can construct without arguments.

The ModelResponse this returns is a plain dataclass-shaped object
mirroring kairos.model_client.base.ModelResponse — same field names so
cycle_prove and other consumers don't care whether the client is
direct or stdio-proxied.
"""
from __future__ import annotations

import json
import logging
import sys
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import IO, Any, Optional


_logger = logging.getLogger(__name__)


@dataclass
class _StdioProxyResponse:
    """ModelResponse-shaped value (mirrors kairos.model_client.base.
    ModelResponse field names) so cycle_prove + downstream consumers
    treat StdioProxyClient interchangeably with a direct client.

    Defined locally rather than imported to keep this module
    importable inside the drafter container even if the model_client
    package is sliced out of the in-container SDK install.
    """
    model: str
    content: Optional[str]
    reasoning_content: Optional[str] = None
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cache_creation_tokens: int = 0
    cache_read_tokens: int = 0
    reasoning_tokens: int = 0
    finish_reason: Optional[str] = None
    error: Optional[str] = None
    raw: Any = None

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens

    def assistant_turn(self) -> dict[str, Any]:
        msg: dict[str, Any] = {"role": "assistant"}
        if self.content is not None:
            msg["content"] = self.content
        if self.tool_calls:
            msg["tool_calls"] = self.tool_calls
        return msg


class StdioProxyError(RuntimeError):
    """Raised on protocol-level failures: unparseable response, EOF
    while waiting for response, request_id mismatch. Distinct from
    a model-side error which is reported through
    ``response.error`` (per-call non-fatal)."""


class StdioProxyClient:
    """ModelClient-compatible client that proxies every .call() out
    to a host-side :class:`kairos.fleet.host_proxy.HostLLMProxy`
    over a pair of stdio pipes.

    The constructor takes ``model_id``, ``request_pipe`` (writable
    text stream — typically the container's sys.stdout), and
    ``response_pipe`` (readable text stream — typically sys.stdin).
    Defaults match the entrypoint shape.

    Args:
        model_id: dotted model identifier passed through to the host
            proxy in every request (e.g. ``"anthropic/claude-sonnet-4-6"``).
        request_pipe: writable line-buffered text stream where
            ``llm_call`` JSON lines are written.
        response_pipe: readable line-buffered text stream where the
            corresponding response JSON lines arrive.
        timeout_seconds: max wall-clock to wait for one response
            line. Default 600s — covers reasoning models on long
            generations. ``None`` disables the deadline.
    """
    def __init__(
        self,
        model_id: str,
        *,
        request_pipe: Optional[IO[str]] = None,
        response_pipe: Optional[IO[str]] = None,
        timeout_seconds: Optional[float] = 600.0,
    ) -> None:
        self.model_id = model_id
        self._request_pipe = request_pipe if request_pipe is not None else sys.stdout
        self._response_pipe = response_pipe if response_pipe is not None else sys.stdin
        self._timeout = timeout_seconds
        # The proxy is single-threaded by contract (the drafter
        # entrypoint runs cycle_prove serially), but cycle_prove may
        # in some future revision parallelize round-internal calls;
        # protect the stdio with a lock so the JSON lines never
        # interleave even under concurrent calls.
        self._io_lock = threading.Lock()

    # ── ModelClient surface ────────────────────────────────────────

    def format_messages(
        self, system_prompt: str, user_prompt: str,
    ) -> list[dict[str, Any]]:
        """Standard system+user shape. Mirrors the AnthropicClient
        and OpenAICompatClient default."""
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ]

    def call(
        self,
        messages: list[dict[str, Any]],
        *,
        temperature: float = 0.0,
        max_tokens: int = 800,
        tools: Optional[list[dict[str, Any]]] = None,
        **_extra: Any,
    ) -> _StdioProxyResponse:
        """Send one llm_call over stdio and return the response.

        Extra kwargs (``tools``, ``top_p``, etc.) are dropped: the
        host proxy contract is intentionally narrow. The host can
        add fields by extending the protocol later; for now,
        cycle_prove only needs messages + temperature + max_tokens.
        """
        request_id = uuid.uuid4().hex
        request_obj: dict[str, Any] = {
            "method": "llm_call",
            "model_id": self.model_id,
            "messages": list(messages),
            "temperature": float(temperature),
            "max_tokens": int(max_tokens),
            "request_id": request_id,
        }
        if tools:
            request_obj["tools"] = list(tools)

        with self._io_lock:
            self._request_pipe.write(json.dumps(request_obj) + "\n")
            self._request_pipe.flush()
            response_obj = self._read_response_for(request_id)

        return self._parse_response(response_obj)

    # ── internals ──────────────────────────────────────────────────

    def _read_response_for(self, request_id: str) -> dict[str, Any]:
        """Read response lines until we see one with the matching
        request_id. Drop and warn on mismatched ids; raise on EOF or
        timeout.

        We scan rather than blindly take the next line because some
        host implementations may write log/debug lines. Today the
        contract is one-line-per-message but tolerating drift here
        is cheap and keeps the failure modes diagnosable.
        """
        deadline = (
            time.time() + self._timeout if self._timeout is not None else None
        )
        while True:
            if deadline is not None and time.time() >= deadline:
                raise StdioProxyError(
                    f"timeout after {self._timeout:.0f}s waiting for "
                    f"response to request_id={request_id}"
                )
            line = self._response_pipe.readline()
            if line == "":
                raise StdioProxyError(
                    f"host pipe EOF before response for request_id={request_id}"
                )
            line = line.rstrip("\n")
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as e:
                raise StdioProxyError(
                    f"unparseable JSON from host: {e}; first 200 bytes: {line[:200]!r}"
                ) from e
            if not isinstance(obj, dict):
                raise StdioProxyError(
                    f"host response was not a JSON object: {line[:200]!r}"
                )
            obj_id = obj.get("request_id")
            if obj_id != request_id:
                _logger.warning(
                    "stdio_proxy: discarding stale response request_id=%r "
                    "(expected %r)", obj_id, request_id,
                )
                continue
            return obj

    def _parse_response(self, obj: dict[str, Any]) -> _StdioProxyResponse:
        return _StdioProxyResponse(
            model=self.model_id,
            content=obj.get("content"),
            reasoning_content=obj.get("reasoning_content"),
            tool_calls=list(obj.get("tool_calls") or []),
            prompt_tokens=int(obj.get("prompt_tokens") or 0),
            completion_tokens=int(obj.get("completion_tokens") or 0),
            cache_creation_tokens=int(obj.get("cache_creation_tokens") or 0),
            cache_read_tokens=int(obj.get("cache_read_tokens") or 0),
            reasoning_tokens=int(obj.get("reasoning_tokens") or 0),
            finish_reason=obj.get("finish_reason"),
            error=obj.get("error"),
            raw=obj,
        )
