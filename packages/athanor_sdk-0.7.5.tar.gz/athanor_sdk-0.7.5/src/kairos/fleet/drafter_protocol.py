"""kairos.fleet.drafter_protocol — public Generic Protocol + BaseDrafter ABC.

ATH-1233 phase 2: lifts the private ``_DrafterProtocol`` from
``kairos.fleet.fleet_orchestrator`` into a public, importable contract
that customer-side and SDK-side drafter implementations both target.

## Why this module exists

Pre-ATH-1233, the only drafter shape was ``ContainerizedDrafter`` /
``FakeContainerizedDrafter``. The :class:`FleetOrchestrator` dispatched
to them via duck-typing through a private ``_DrafterProtocol`` (alias +
cycle_prove). Customers writing their own drafters (e.g. a vendor-
specific orchestrator wrapper, an in-process unit-test stub, a remote-
HTTP drafter facade) had to read the orchestrator's source to learn the
duck-type contract.

This module makes the contract public and extends it with the v1.2
field set needed for the orchestrator's preflight + cost-gate +
attribution paths:

- ``alias: str`` — short name for logs, audit, and the FleetRunSummary
  outcomes dict key. Must be unique within a single FleetOrchestrator
  instance (the orchestrator's ``__post_init__`` raises on duplicates).
- ``model_id: str`` — dotted LiteLLM-style model identifier. Used by
  the preflight gate to dedupe host-side ModelClient smokes when a
  fleet of {Sonnet, Sonnet, Kimi} drafters only needs to smoke two
  keys. Required for preflight participation; drafters without
  ``model_id`` still run, but the preflight gate emits a loud
  :class:`PreflightSkipped` warning per the 2026-04-27 research-smoke
  fallback.
- ``cycle_prove(target, *, max_rounds, temperature, max_tokens)``
  — synchronous proof attempt against one CycleTarget. Returns a
  CycleResult. Implementations may dispatch the actual work
  asynchronously / over the network / via a subprocess — the
  Orchestrator only sees the synchronous return value.

The BaseDrafter ABC below provides a concrete inheritance anchor for
implementations that want the contract enforced at class-definition
time (vs. relying on duck-typing). Customers can either:

1. Subclass :class:`BaseDrafter` — get the contract enforced; missing
   methods raise at instantiation.
2. Duck-type the :class:`DrafterProtocol` Protocol — looser but still
   type-checkable via ``isinstance(d, DrafterProtocol)`` with
   ``@runtime_checkable``.

Both routes flow into the same FleetOrchestrator dispatch.

## Composes with

- :class:`kairos.fleet.containerized_drafter.ContainerizedDrafter` —
  already satisfies the protocol; remains the canonical SDK-side
  implementation.
- :class:`kairos.fleet.fleet_orchestrator.FleetOrchestrator` — narrows
  its private ``_DrafterProtocol`` to import from here (ATH-1233 v1.2
  contract lift; see follow-up commit).

## ATH-1233 v1.2 design lock

Locked 2026-05-14 by CTO (ts 1778737865). Phase 1 was coverage uplift
on the three pre-existing fleet modules (host_proxy 100% +
containerized_drafter 98% + fleet_orchestrator 94%); phase 2 (this
commit) lifts the contract to public. Phase 3 follow-up commits expand
to the full 6-method shape (health_check / prepare_target / cost_estimate
/ cleanup) and 9-event taxonomy for the orchestrator's emit path.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Protocol, runtime_checkable

from kairos.lean_cycle import CycleResult, CycleTarget


@runtime_checkable
class DrafterProtocol(Protocol):
    """Public Generic Protocol every fleet drafter must satisfy.

    Marked ``@runtime_checkable`` so callers can use
    ``isinstance(d, DrafterProtocol)`` at runtime to filter a
    heterogeneous drafter list. The protocol shape is a SUPERSET of
    the v1.0 ``_DrafterProtocol`` from fleet_orchestrator.py: adds
    the ``model_id`` attribute that was previously consulted via
    ``getattr(d, "model_id", None)`` in the preflight gate.

    Drafters MAY expose additional methods + attributes; the protocol
    pins the minimum surface the orchestrator depends on.
    """

    alias: str
    """Short name for logs / audit / FleetRunSummary outcomes-dict
    key. Must be unique within a single FleetOrchestrator instance."""

    model_id: str
    """Dotted LiteLLM-style model identifier (e.g.
    ``anthropic/claude-sonnet-4-6``). Consulted by the preflight gate
    to dedupe host-side ModelClient smokes. Drafters without a
    meaningful model_id (e.g. fake test stubs) should set an empty
    string; the preflight gate gracefully degrades."""

    def cycle_prove(
        self,
        target: CycleTarget,
        *,
        max_rounds: int = ...,
        temperature: float = ...,
        max_tokens: int = ...,
    ) -> CycleResult:
        """Synchronous proof attempt against one CycleTarget.

        Returns a CycleResult on success OR failure (the
        FleetOrchestrator distinguishes failure-modes by inspecting
        ``CycleResult.closed`` and the per-round attempt list).
        Implementations may dispatch the actual work asynchronously /
        over the network / via a subprocess — the orchestrator only
        sees the synchronous return value.

        Raising from this method surfaces in
        ``FleetRunSummary.outcomes`` as ``{"error": "<type>: <msg>"}``;
        per-drafter exceptions do NOT abort the rest of the fleet
        (the orchestrator catches and continues).
        """
        ...

    # ─── ATH-1233 phase 3 commit 1 — full 6-method shape per v1.2 ───
    #
    # The 5 methods below complete the v1.2-locked DrafterProtocol
    # surface. Each method has a documented contract; concrete drafters
    # (ContainerizedDrafter + FakeContainerizedDrafter) ship default
    # implementations matching the same shape so back-compat holds for
    # callers that built against the v1.0/v1.1 alias+cycle_prove
    # contract.

    def health_check(self) -> bool:
        """Pre-flight readiness probe. Called by the FleetOrchestrator
        before fan-out (when ``preflight=True``) to skip drafters that
        won't be ready for cycle_prove.

        Returns ``True`` when the drafter is ready, ``False`` when not
        (e.g. container image not pulled, model adapter unreachable,
        license expired). MUST NOT raise — caller catches falsy returns
        and surfaces them via the existing preflight error-aggregation
        path.

        Default implementation returns ``True`` — the drafter is
        considered ready unless proven otherwise at cycle_prove time.
        """
        ...

    def prepare_target(self, target: CycleTarget) -> CycleTarget:
        """Per-drafter pre-processing pass on a CycleTarget. Called by
        the FleetOrchestrator (or directly by a customer fanning out)
        before ``cycle_prove`` to let the drafter expand imports,
        normalize the header, swap the lake_project mount path, etc.

        Returns the prepared CycleTarget. Implementations MUST return a
        valid CycleTarget (returning ``None`` or a different type is a
        contract violation that the orchestrator will surface as
        ``{"error": "..."}``).

        Default implementation returns the input target unchanged.
        """
        ...

    def cost_estimate(
        self,
        target: CycleTarget,
        *,
        max_rounds: int = ...,
        max_tokens: int = ...,
    ) -> float:
        """Pre-fan-out cost gate. Returns the expected USD cost of one
        cycle_prove call against the given target with the supplied
        kwargs. The FleetOrchestrator sums across the fleet to enforce
        a budget cap before any drafter spawns (when configured).

        Returns ``0.0`` to mean "unknown / opt-out of cost gating" —
        the orchestrator treats this as a soft-fail (logs a warning,
        proceeds without cost cap on this drafter).

        Default implementation returns ``0.0``.
        """
        ...

    def cleanup(self) -> None:
        """Release per-drafter resources after a fleet.run() completes.
        Called by the FleetOrchestrator once per drafter post-fan-out,
        regardless of success/failure outcome.

        Implementations should be IDEMPOTENT (safe to call multiple
        times) and MUST NOT raise — caller swallows exceptions and
        logs them.

        Default implementation is a no-op.
        """
        ...

    @property
    def name(self) -> str:
        """Pretty display name for dashboard / UI rendering. May differ
        from ``alias`` (e.g. ``alias="s4_6"`` vs ``name="Sonnet 4.6"``)
        when the audit-log key needs to be short but the customer-
        facing label benefits from a longer form.

        Default implementation returns ``alias`` unchanged.
        """
        ...


class BaseDrafter(ABC):
    """Concrete inheritance anchor for drafter implementations.

    Use this when you want the protocol contract enforced at
    class-definition time (subclassing raises ``TypeError`` if any
    ``@abstractmethod`` is missing). Use the :class:`DrafterProtocol`
    Protocol directly when you prefer duck-typing.

    Both routes flow into the same FleetOrchestrator dispatch — the
    orchestrator's only contract-check is the duck-type interface;
    inheriting from BaseDrafter is purely a tool for the IMPLEMENTOR
    to catch shape errors early.

    Args:
        alias: short name for logs / audit. Must be unique within a
            single FleetOrchestrator. Stored as
            :attr:`BaseDrafter.alias`.
        model_id: dotted LiteLLM-style model identifier. Stored as
            :attr:`BaseDrafter.model_id`.
    """

    alias: str
    model_id: str

    def __init__(self, *, alias: str, model_id: str) -> None:
        self.alias = alias
        self.model_id = model_id

    @abstractmethod
    def cycle_prove(
        self,
        target: CycleTarget,
        *,
        max_rounds: int = 4,
        temperature: float = 0.0,
        max_tokens: int = 800,
    ) -> CycleResult:
        """Implement the proof attempt. See
        :meth:`DrafterProtocol.cycle_prove` for the contract."""
        ...

    # ─── ATH-1233 phase 3 commit 1 — default implementations ───
    # The 5 methods below ship default implementations so BaseDrafter
    # subclasses get the v1.2-extended contract free + only override
    # what they need. Concrete subclasses (vs virtual-subclass
    # registrations) inherit these directly.

    def health_check(self) -> bool:
        """Default: ready. See :meth:`DrafterProtocol.health_check`."""
        return True

    def prepare_target(self, target: CycleTarget) -> CycleTarget:
        """Default: passthrough. See :meth:`DrafterProtocol.prepare_target`."""
        return target

    def cost_estimate(
        self,
        target: CycleTarget,
        *,
        max_rounds: int = 4,
        max_tokens: int = 800,
    ) -> float:
        """Default: unknown (0.0). See :meth:`DrafterProtocol.cost_estimate`."""
        return 0.0

    def cleanup(self) -> None:
        """Default: no-op. See :meth:`DrafterProtocol.cleanup`."""
        return None

    @property
    def name(self) -> str:
        """Default: alias. See :meth:`DrafterProtocol.name`."""
        return self.alias
