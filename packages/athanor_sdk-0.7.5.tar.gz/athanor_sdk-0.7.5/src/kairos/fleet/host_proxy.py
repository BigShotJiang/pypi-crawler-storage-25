"""kairos.fleet.host_proxy — host-side stdio JSON-RPC LLM proxy.

The container half of a ContainerizedDrafter runs cycle_prove inside a
sandboxed container. Whenever cycle_prove (via the in-container
StdioProxyClient) needs an LLM completion, it serializes the request
to its stdout. The host process — running this proxy — reads that
request, calls the real ModelClient with the host's API credentials,
and writes the response back to the container's stdin. The container
never holds API keys.

Protocol (one JSON object per line, both directions):

    container → host (during cycle):
        {"method": "llm_call",
         "model_id": str,
         "messages": list[dict],
         "temperature": float,
         "max_tokens": int,
         "request_id": str}

    host → container (response to llm_call):
        {"request_id": str,
         "content": str | None,
         "reasoning_content": str | None,
         "prompt_tokens": int,
         "completion_tokens": int,
         "finish_reason": str | None,
         "error": str | None}

    container → host (terminal):
        {"method": "cycle_result",
         "tid": str,
         "closed": bool,
         "rounds": list[dict],
         "total_wall_sec": float}

Public API:

    proxy = HostLLMProxy(client_factory=resolve_model_client,
                         cost_tracker=tracker, drafter_alias='sonnet')
    cycle_result_dict = proxy.run(stdin_pipe, stdout_pipe)

`stdin_pipe` is the writable end of the container's stdin (host writes
responses here); `stdout_pipe` is the readable end of the container's
stdout (host reads requests + the terminal cycle_result here). Both
are line-buffered text pipes — caller is responsible for setting up
the subprocess / docker run with text=True and bufsize=1.

`client_factory(model_id)` returns a ModelClient instance for the
requested model. Allows callers to inject a fake factory in tests +
plug provider keys at the host hop.

`cost_tracker`, when supplied, accumulates prompt + completion tokens
per llm_call. Required for the canonical solve/shared/cost_tracker.py
metering invariant — see ATH-519.
"""
from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import IO, Any, Callable, Optional

_logger = logging.getLogger(__name__)


@dataclass
class HostProxyStats:
    """Counters accumulated over one run() invocation."""
    llm_calls: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    errors: int = 0
    bad_messages: list[str] = field(default_factory=list)


class HostProxyError(RuntimeError):
    """Raised when the container terminates without a cycle_result, or
    sends an unparseable / unknown message. The message includes the
    last bad payload (truncated) so callers can diagnose."""


class HostLLMProxy:
    def __init__(
        self,
        client_factory: Callable[[str], Any],
        *,
        cost_tracker: Optional[Any] = None,
        drafter_alias: str = "drafter",
        max_message_bytes: int = 1_048_576,
    ) -> None:
        self._client_factory = client_factory
        self._cost_tracker = cost_tracker
        self._drafter_alias = drafter_alias
        self._max_message_bytes = max_message_bytes
        self._client_cache: dict[str, Any] = {}
        self.stats = HostProxyStats()

    def _get_client(self, model_id: str) -> Any:
        cached = self._client_cache.get(model_id)
        if cached is None:
            cached = self._client_factory(model_id)
            self._client_cache[model_id] = cached
        return cached

    def _dispatch_llm_call(self, msg: dict[str, Any]) -> dict[str, Any]:
        request_id = msg.get("request_id")
        model_id = msg.get("model_id")
        messages = msg.get("messages")
        temperature = float(msg.get("temperature", 0.0))
        max_tokens = int(msg.get("max_tokens", 0))
        if not isinstance(request_id, str) or not request_id:
            raise HostProxyError("llm_call: missing or invalid request_id")
        if not isinstance(model_id, str) or not model_id:
            return {
                "request_id": request_id,
                "content": None, "reasoning_content": None,
                "prompt_tokens": 0, "completion_tokens": 0,
                "finish_reason": None,
                "error": "host_proxy: missing or invalid model_id",
            }
        if not isinstance(messages, list):
            return {
                "request_id": request_id,
                "content": None, "reasoning_content": None,
                "prompt_tokens": 0, "completion_tokens": 0,
                "finish_reason": None,
                "error": "host_proxy: messages must be a list",
            }

        try:
            client = self._get_client(model_id)
            resp = client.call(
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
        except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            self.stats.errors += 1
            _logger.warning(
                "host_proxy[%s]: llm_call failed model=%s: %s: %s",
                self._drafter_alias, model_id, type(e).__name__, e,
            )
            return {
                "request_id": request_id,
                "content": None, "reasoning_content": None,
                "prompt_tokens": 0, "completion_tokens": 0,
                "finish_reason": None,
                "error": f"{type(e).__name__}: {e!s:.300}",
            }

        prompt_tokens = int(getattr(resp, "prompt_tokens", 0) or 0)
        completion_tokens = int(getattr(resp, "completion_tokens", 0) or 0)
        self.stats.llm_calls += 1
        self.stats.prompt_tokens += prompt_tokens
        self.stats.completion_tokens += completion_tokens
        if self._cost_tracker is not None:
            try:
                self._cost_tracker.record(
                    model=model_id,
                    prompt_tokens=prompt_tokens,
                    completion_tokens=completion_tokens,
                    cache_creation_tokens=int(getattr(resp, "cache_creation_tokens", 0) or 0),
                    cache_read_tokens=int(getattr(resp, "cache_read_tokens", 0) or 0),
                )
            except Exception as e:  # noqa: BLE001 — logged + recovered; broad catch is intentional
                _logger.debug(
                    "host_proxy: cost_tracker.record raised — %s: %s",
                    type(e).__name__, e,
                )

        return {
            "request_id": request_id,
            "content": getattr(resp, "content", None),
            "reasoning_content": getattr(resp, "reasoning_content", None),
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "finish_reason": getattr(resp, "finish_reason", None),
            "error": getattr(resp, "error", None),
        }

    def run(self, stdin_pipe: IO[str], stdout_pipe: IO[str]) -> dict[str, Any]:
        """Service llm_call messages until a cycle_result terminal
        message arrives. Returns the cycle_result dict as-is — caller
        deserializes into CycleResult.

        Raises HostProxyError on unparseable JSON, missing method,
        unknown method, or premature EOF.
        """
        for raw in stdout_pipe:
            line = raw.rstrip("\n")
            if not line:
                continue
            if len(line) > self._max_message_bytes:
                trunc = line[:200]
                self.stats.bad_messages.append(trunc)
                raise HostProxyError(
                    f"oversized message ({len(line)} bytes > "
                    f"{self._max_message_bytes}); first 200 bytes: {trunc!r}"
                )
            try:
                msg = json.loads(line)
            except json.JSONDecodeError as e:
                self.stats.bad_messages.append(line[:200])
                raise HostProxyError(
                    f"unparseable JSON from container: {e}; "
                    f"first 200 bytes: {line[:200]!r}"
                ) from e
            if not isinstance(msg, dict) or "method" not in msg:
                self.stats.bad_messages.append(line[:200])
                raise HostProxyError(
                    f"message missing 'method' field; "
                    f"first 200 bytes: {line[:200]!r}"
                )

            method = msg["method"]
            if method == "llm_call":
                response = self._dispatch_llm_call(msg)
                stdin_pipe.write(json.dumps(response) + "\n")
                stdin_pipe.flush()
            elif method == "cycle_result":
                return msg
            else:
                self.stats.bad_messages.append(line[:200])
                raise HostProxyError(
                    f"unknown method {method!r} from container; "
                    f"first 200 bytes: {line[:200]!r}"
                )

        raise HostProxyError(
            "container EOF without cycle_result terminal message"
        )
