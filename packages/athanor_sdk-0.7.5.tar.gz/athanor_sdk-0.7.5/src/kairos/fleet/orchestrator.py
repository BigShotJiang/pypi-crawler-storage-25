"""kairos.fleet.orchestrator — LLM-backed orchestration (ATH-570).

Replaces the old ``kairos.spec.defaults.OpusOrchestrator``. Two shapes:

1. :class:`Orchestrator` — ``OrchestratorPlugin`` implementation. Takes a
   ``model`` kwarg (default ``anthropic/claude-opus-4-6``) and
   optionally a ``worker_models`` list. When workers are supplied, the
   planner preferentially spreads them across tiers via the
   :attr:`OrchestrationChoice.model_selection` dict — that's the
   "plan + workers" pattern from Aidan 2026-04-24 05:10Z.

2. :func:`orchestrate` — one-line convenience that wires an
   :class:`Orchestrator` into a :class:`SpecPipeline` and runs it.

The class preserves the behavior of the old OpusOrchestrator: LLM call
at T=0.0 for determinism, cache keyed on (intent, tier_set, tool_set)
with 5-min TTL, graceful-degrade to
:class:`kairos.spec.defaults.DefaultRoundRobinOrchestrator` on LLM
failure, ``cost_usd`` attribute for SpecPipeline's budget gate.

Name / model decoupling (Aidan directive 23:10Z): the class name no
longer encodes the orchestrator model. Customers pass
``Orchestrator(model="openai/kimi-k2.6-1")`` or
``Orchestrator(model="gemini/gemini-3-pro-preview")`` without
subclassing.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time as _time
from typing import Any, Mapping, Sequence

from kairos.spec.types import (
    KairosConfig,
    ModelSelectorPlugin,
    OrchestrationChoice,
    OrchestrationInvalidPlugin,
    OrchestrationMalformed,
    PromptLoader,
    ToolRegistryPlugin,
)

logger = logging.getLogger(__name__)


# Default planner model. Aidan 2026-04-24 23:10Z: "default opus 4.6".
# Sourced from ``kairos.model_presets`` (ATH-816) so the literal lives
# in one auditable place.
from kairos.model_presets import DEFAULT_PLANNER_MODEL  # noqa: E402


# Prompt body contains example model names for the LLM, not
# code-level model selections (ATH-816).
# noqa: model-literal
_ORCHESTRATOR_PROMPT = """\
You are the orchestrator for an autoformalize pipeline. Decide the best
orchestration strategy for the following spec to land a verdict within
the stated USD budget.

# Input

## Spec intent
{intent_summary}

## Available verifier tiers (from tier_registry)
{tier_table}

## Available tools (from tool_registry)
{tool_list}

## Available worker models (spread across tiers in model_selection when >=2)
{worker_table}

## Budget
- usd cap: ${budget_usd}

# Output — strict JSON matching OrchestrationChoice:

{{
  "tier_dispatch":    ["lean_proved", "bmc_bounded", ...],
  "tool_selection":   ["lean-lsp-mcp", "ebmc", ...],
  "model_selection":  {{ "lean_proved": "anthropic/claude-opus-4-6", ... }},
  "prompt_selection": {{ "lean_proved": "default", ... }},
  "rationale":        "2-4 sentences explaining the choice"
}}

# Reasoning constraints

- Real-arithmetic claims (sqrt, log, transcendentals) -> lean_proved primary
- Bit-level / FSM / RTL claims -> bmc_bounded with appropriate bound_k
- Integer/array/DSL algorithmic claims -> empirical with Dafny/Z3 drafter
- Budget-constrained -> drop corroborating-only tiers, minimize review
- Conservative by default — never upgrade tier silently, never overwrite
  a safety signal
- When worker models are listed above, assign DIFFERENT workers to
  DIFFERENT tiers in model_selection where tiers have distinct
  specializations (Lean vs. BMC vs. tests). Use the planner model for
  tiers that aren't covered by a worker.
- When the spec describes lean-machines refinement levels (M0, M1, …)
  AND RTL, emit a `refinement_chain` list of `{{tier, lean_module |
  ebmc_target, proof_artifact_in, proof_artifact_out}}` instead of a
  flat tier_dispatch — `lean_machines_proved` for each Lean hop, and
  `bmc_kind` (or `bmc_bounded`) for the bottom RTL hop.
"""


class Orchestrator:
    """LLM-backed :class:`OrchestratorPlugin` — the only orchestrator in
    the SDK.

    :purity: IMPURE_DETERMINISTIC (LLM call at T=0.0)
    :idempotence: cache by (intent_hash, tier_set, tool_set) with TTL
    :side_effects: LLM call; trace emission via SpecPipeline's TraceSink

    The old ``OpusOrchestrator`` lived in ``kairos.spec.defaults`` and
    hard-coded the model into the class name. This class takes the
    model as a plain kwarg so customers can swap without subclassing.

    Args:
        model: planner / judge model. Default
            ``anthropic/claude-opus-4-6``. Accepts any litellm-compatible
            model id (``openai/kimi-k2.6-1``,
            ``gemini/gemini-3-pro-preview``, etc.). Used for the one
            orchestration prompt per ``orchestrate()`` call. The LLM
            call runs at temperature 0 for determinism.
        worker_models: optional list of worker model ids. When
            supplied, the orchestration prompt includes these as
            available workers and asks the planner to spread them
            across tiers via :attr:`OrchestrationChoice.model_selection`.
            When omitted or empty, the planner may still populate
            ``model_selection`` but isn't explicitly steered toward
            multi-worker. Example:
            ``worker_models=["anthropic/claude-sonnet-4-6",
            "openai/kimi-k2.6-1", "gemini/gemini-3-pro-preview"]``.
        config: optional :class:`KairosConfig` override. When None,
            a fresh ``KairosConfig()`` is used. Carries
            ``cache_ttl_sec`` + ``budget_usd`` + any legacy settings.
        llm_call_fn: injection seam for tests — receives the formatted
            prompt, returns raw JSON text. Production path uses
            :func:`litellm.completion` when None.

    Stream D (``kairos.spec.pipeline`` budget gate) reads ``cost_usd``.
    Populated from litellm usage on every successful LLM call.

    Tier classification: paid (requires the ``solve`` product).
    ``__init__`` calls :func:`kairos.license_scope.require_product`
    and raises :class:`kairos.license_scope.LicenseScopeError` when
    the loaded license is missing ``solve``. Base SDK callers
    should use :func:`kairos.simple_prove`.
    """

    def __init__(
        self,
        *,
        model: str = DEFAULT_PLANNER_MODEL,
        worker_models: Sequence[str] | None = None,
        config: KairosConfig | None = None,
        llm_call_fn: Any = None,
    ) -> None:
        # ATH-686 P1: paid-tier programmatic API → license gate. Run at
        # construction so the gate fails fast before any LLM-related
        # state is built (cache, tier dispatch, etc).
        from kairos.license_scope import require_product
        require_product("solve")

        self.model = model
        self.worker_models: tuple[str, ...] = tuple(worker_models or ())
        self._config = config if config is not None else KairosConfig()
        self._llm_call_fn = llm_call_fn
        # Cache keyed on (intent_hash, tier_set, tool_set).
        # Entries are (OrchestrationChoice, wall_time_inserted_at).
        self._cache: dict[str, tuple[OrchestrationChoice, float]] = {}
        # Stream D contract: SpecPipeline reads this to drive the
        # cost_budget_usd gate. Grows as LLM calls land. Round-robin
        # graceful-degrade path doesn't increment (no LLM).
        self.cost_usd: float = 0.0

    def orchestrate(
        self,
        intent: Any, /,
        *,
        tier_registry: Any,
        tool_registry: ToolRegistryPlugin,
        model_selector: ModelSelectorPlugin,
        prompt_loader: PromptLoader,
    ) -> OrchestrationChoice:
        """Return an :class:`OrchestrationChoice` for this intent.

        Same contract as the old OpusOrchestrator: resolve available
        tiers + tools from the registries, check the TTL-keyed cache,
        call the LLM with a strict-JSON prompt, validate the tier names
        against the registry, return. Graceful-degrade to round-robin
        on any LLM failure (network, JSON parse, hallucinated tier).
        """
        available_tiers = _registered_tiers(tier_registry)
        try:
            available_tools = list(tool_registry.list_tools())
        except Exception:  # noqa: BLE001 — broad-catch fallback
            available_tools = []

        cache_key = _cache_key(intent, available_tiers, available_tools)
        ttl = getattr(self._config, "cache_ttl_sec", 300)
        now = _time.time()
        if cache_key in self._cache:
            cached_choice, ts = self._cache[cache_key]
            if now - ts < ttl:
                return cached_choice

        try:
            choice = self._call_llm(
                intent=intent,
                available_tiers=available_tiers,
                available_tools=available_tools,
                tier_registry=tier_registry,
            )
        except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
            logger.warning(
                "Orchestrator(model=%s) LLM call failed (%s: %s); "
                "falling back to DefaultRoundRobinOrchestrator.",
                self.model, type(exc).__name__, exc,
            )
            # Lazy import to avoid a cycle — DefaultRoundRobinOrchestrator
            # lives in spec.defaults which imports from spec.types, not
            # from kairos.fleet.
            from kairos.spec.defaults import DefaultRoundRobinOrchestrator
            fallback = DefaultRoundRobinOrchestrator(self._config)
            choice = fallback.orchestrate(
                intent,
                tier_registry=tier_registry,
                tool_registry=tool_registry,
                model_selector=model_selector,
                prompt_loader=prompt_loader,
            )
            # ATH-818 G4: stamp fallback_reason on the choice so
            # SpecPipeline can emit an `orchestrator_fallback` trace
            # event. Customer reading /solve-runs/[id] sees WHY the
            # LLM-tier-planner didn't fire, not just that the
            # rule-based round-robin orchestrator picked the tiers.
            # Truncate exc message to keep payloads bounded.
            import dataclasses as _dataclasses
            _msg = str(exc)
            if len(_msg) > 300:
                _msg = _msg[:297] + "..."
            choice = _dataclasses.replace(
                choice,
                fallback_reason=f"{type(exc).__name__}: {_msg}",
            )

        self._cache[cache_key] = (choice, now)
        return choice

    def _call_llm(
        self,
        *,
        intent: Any,
        available_tiers: list[str],
        available_tools: list[str],
        tier_registry: Any,
    ) -> OrchestrationChoice:
        """Format the prompt + call the LLM + parse strict JSON."""
        intent_summary = (
            json.dumps(dict(intent), indent=2, sort_keys=True)
            if isinstance(intent, Mapping) else str(intent)
        )
        tier_table = _tier_table(available_tiers, tier_registry) or "(none registered)"
        tool_list = ", ".join(sorted(available_tools)) or "(none)"
        worker_table = _worker_table(self.worker_models)
        budget_usd = getattr(self._config, "budget_usd", 25.0)

        prompt = _ORCHESTRATOR_PROMPT.format(
            intent_summary=intent_summary,
            tier_table=tier_table,
            tool_list=tool_list,
            worker_table=worker_table,
            budget_usd=budget_usd,
        )

        raw = (
            self._llm_call_fn(prompt) if self._llm_call_fn is not None
            else self._default_llm_call(prompt)
        )

        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise OrchestrationMalformed(
                f"Orchestrator(model={self.model!r}) returned non-JSON: {exc}"
            ) from exc

        for t in data.get("tier_dispatch", []):
            if t not in available_tiers:
                raise OrchestrationInvalidPlugin(
                    f"Orchestrator(model={self.model!r}) hallucinated tier "
                    f"{t!r} not in registry (available: {sorted(available_tiers)})"
                )

        return OrchestrationChoice(**data)

    def _default_llm_call(self, prompt: str) -> str:
        """LLM completion via get_client(). ATH-1186 migration.

        Uses ``self.model`` + T=0.0 for determinism. Updates
        :attr:`cost_usd` from the response when present.
        """
        from kairos.model_client.registry import get_client

        temperature = getattr(self._config, "orchestrator_temperature", 0.0)
        client = get_client(self.model)
        resp = client.call(
            [{"role": "user", "content": prompt}],
            temperature=temperature,
            timeout=60,
        )
        cost = getattr(resp, "cost_usd", None)
        if isinstance(cost, (int, float)):
            self.cost_usd += float(cost)
        return resp.assistant_turn().get("content", "") or "{}"


# ── helpers ────────────────────────────────────────────────────────────


def _registered_tiers(tier_registry: Any) -> list[str]:
    if hasattr(tier_registry, "registered_tiers"):
        return list(tier_registry.registered_tiers())
    if isinstance(tier_registry, Mapping):
        return sorted(tier_registry.keys())
    return []


def _cache_key(
    intent: Any, tiers: list[str], tools: list[str],
) -> str:
    intent_blob = json.dumps(
        dict(intent) if isinstance(intent, Mapping) else {"intent": str(intent)},
        sort_keys=True, separators=(",", ":"),
    ).encode()
    return hashlib.sha256(
        intent_blob + repr(sorted(tiers)).encode()
        + repr(sorted(tools)).encode()
    ).hexdigest()


def _tier_table(available_tiers: list[str], tier_registry: Any) -> str:
    lines: list[str] = []
    for name in sorted(available_tiers):
        plugin = None
        if hasattr(tier_registry, "lookup"):
            try:
                plugin = tier_registry.lookup(name)
            except Exception:  # noqa: BLE001 — tier_registry.lookup may not be defined for all registry types
                pass
        elif isinstance(tier_registry, Mapping):
            plugin = tier_registry.get(name)
        if plugin is not None:
            evidence = getattr(plugin, "evidence_tier_when_primary", "unknown")
            lines.append(f"- {name}: evidence_tier={evidence}")
        else:
            lines.append(f"- {name}")
    return "\n".join(lines)


def _worker_table(worker_models: tuple[str, ...]) -> str:
    if not worker_models:
        return "(none — planner fills model_selection directly)"
    return "\n".join(f"- {m}" for m in worker_models)


# ═══════════════════════════════════════════════════════════════════════
# orchestrate() — one-line convenience wrapping SpecPipeline
# ═══════════════════════════════════════════════════════════════════════


def orchestrate(
    intent: Mapping[str, Any],
    /,
    *,
    model: str = DEFAULT_PLANNER_MODEL,
    worker_models: Sequence[str] | None = None,
    verifier_registry: Any = None,
    config: KairosConfig | None = None,
    run_id: str | None = None,
    cost_budget_usd: float | None = None,
) -> Any:
    """Run a full spec through an :class:`Orchestrator` + SpecPipeline.

    One-line fleet call. Builds an :class:`Orchestrator(model, worker_models)`,
    wires it into a :class:`kairos.spec.pipeline.SpecPipeline`, and runs
    the intent.

    Args:
        intent: the :class:`IntentV1` Mapping to run.
        model: planner / judge model id. Default
            ``anthropic/claude-opus-4-6``.
        worker_models: optional list of worker model ids spread across
            tiers via the planner's ``model_selection`` output. Typical
            multi-worker usage:
            ``["anthropic/claude-sonnet-4-6", "openai/kimi-k2.6-1",
            "gemini/gemini-3-pro-preview"]``.
        verifier_registry: optional :class:`VerifierRegistry`; defaults
            to :data:`kairos.spec.pipeline.DEFAULT_REGISTRY`.
        config: optional :class:`KairosConfig`.
        run_id: optional stable run id. Default is a fresh UUID.
        cost_budget_usd: optional cumulative spend cap — passed
            through to :meth:`SpecPipeline.run`.

    Returns:
        :class:`kairos.spec.pipeline.RunResult`.

    Tier classification: paid (requires the ``solve`` product).
    Raises :class:`kairos.license_scope.LicenseScopeError` at
    function entry (early-fail per ATH-677) when the license is
    missing or doesn't carry ``solve``.
    """
    # ATH-677 v1.2: explicit early-fail license gate. The downstream
    # ``Orchestrator.__init__`` already calls ``require_product("solve")``,
    # but raising here means missing-license callers get the
    # ``LicenseScopeError`` before any pipeline state (registry import,
    # config build) is constructed. Lower latency-to-rejection + cleaner
    # tracebacks (the failure points at the public entry, not at an
    # internal constructor). Base SDK callers should reach for
    # ``kairos.simple_prove`` instead.
    from kairos.license_scope import require_product
    require_product("solve")

    # Lazy imports keep kairos.fleet free of a hard dep on spec.pipeline
    # at package-import time (cycle protection + faster cold import).
    from kairos.spec.pipeline import DEFAULT_REGISTRY, SpecPipeline
    # ATH-614 phase 2: bracket the orchestration call in a kairos.session
    # so the planner LLM call (Orchestrator._default_llm_call) and any
    # downstream litellm.completion fired by SpecPipeline.run() emit
    # session_open / session_close into the trace stream. Without this
    # the platform UI shows raw call streams with no narrative
    # (Aidan's 2026-04-25 dashboard complaint).
    from kairos.prove import session

    intent_id = (
        intent.get("intent_id") if isinstance(intent, Mapping) else None
    ) or run_id or "fleet.orchestrate"
    with session(
        task_id=str(intent_id),
        name_for_display=f"fleet.orchestrate/{intent_id}",
        vertical="other",
        run_subtype="autoformalize",
    ):
        orch = Orchestrator(
            model=model, worker_models=worker_models, config=config,
        )
        pipeline = SpecPipeline(
            config=config if config is not None else KairosConfig(),
            orchestrator=orch,
            verifier_registry=verifier_registry or DEFAULT_REGISTRY,
        )
        return pipeline.run(
            intent, run_id=run_id, cost_budget_usd=cost_budget_usd,
        )


__all__ = [
    "DEFAULT_PLANNER_MODEL",
    "Orchestrator",
    "orchestrate",
]
