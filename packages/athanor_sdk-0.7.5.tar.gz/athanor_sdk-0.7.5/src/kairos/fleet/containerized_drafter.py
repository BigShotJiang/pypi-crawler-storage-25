"""kairos.fleet.containerized_drafter — host-side drafter handle.

A :class:`ContainerizedDrafter` is the host's view of one isolated
fleet drafter. It holds the configuration (model id, image, runtime
flags) but does not own a long-running container; instead each
``.cycle_prove(target)`` invocation:

    1. Serializes the target as a single JSON line.
    2. Spawns the drafter container with --network=none and the
       configured bind-mounts.
    3. Sends the cycle_target line on the container's stdin.
    4. Runs :class:`kairos.fleet.host_proxy.HostLLMProxy` against the
       container's stdio pair, servicing every llm_call request the
       drafter emits.
    5. Receives the terminal cycle_result message, terminates the
       container (or lets it exit on its own), and returns the dict
       parsed back into a :class:`kairos.lean_cycle.CycleResult`.

A :class:`FleetOrchestrator` composes multiple ContainerizedDrafters
and parallelizes them via ThreadPoolExecutor.

Fake / hermetic-test variant: :class:`FakeContainerizedDrafter` runs
the drafter entrypoint as a local subprocess (no docker), so unit
tests can exercise the full handshake without docker on the test
host. Use it everywhere docker is unavailable; the real
ContainerizedDrafter spec is locked behind the ``CI_DOCKER`` env in
integration tests.

ATH-749 sequencing: this module imports
:class:`kairos.fleet.host_proxy.HostLLMProxy` (shipped in the QA-side
PR). The two PRs land together.
"""
from __future__ import annotations

import json
import logging
import shutil
import subprocess
import sys
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Optional, Sequence

from kairos.lean_cycle import CycleAttempt, CycleResult, CycleTarget
from kairos.lean import ProofResult
from kairos.security.env_allowlist import safe_env_for_cedar


def _load_host_proxy() -> tuple[Any, Any]:
    """Lazy-import HostLLMProxy + HostProxyError. The QA-side PR
    (ATH-749 part A) ships these; this PR (part B) is structured so
    the package imports cleanly even before part A lands. The actual
    drafter run does need host_proxy and surfaces a clear ImportError
    at call time."""
    from kairos.fleet.host_proxy import HostLLMProxy, HostProxyError
    return HostLLMProxy, HostProxyError


_logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────
# Common surface
# ─────────────────────────────────────────────────────────────────────


@dataclass
class DrafterMounts:
    """Bind-mounts for the fleet-drafter runtime per the ATH-749
    anti-cheat scope.

    * ``readonly_lake``: pre-built lake project containing only the
      Mathlib oleans + public scaffold (NOT the reference proofs for
      whatever target the drafter is closing). Bind-mounted RO at
      ``/workspace/lake``.
    * ``writable_workdir``: a host directory the drafter can write
      its candidate `.lean` + LSP server state into. Each
      cycle_prove call gets a fresh tempdir; the drafter container
      mounts it RW at ``/workspace/work``.
    * ``audit_dir``: optional bind-mount at ``/workspace/audit`` for
      per-session JSONL logs. Mining cron picks them up off the host
      filesystem (per ATH-739). ``None`` disables audit logging.
    """
    readonly_lake: Path
    writable_workdir: Path
    audit_dir: Optional[Path] = None


def _attempt_from_dict(d: dict[str, Any]) -> CycleAttempt:
    """Re-hydrate a CycleAttempt + nested ProofResult from the JSON
    dict the drafter entrypoint writes. asdict() round-trips both
    dataclasses today; if a future ProofResult field gets added with
    a non-default value, add the corresponding kwarg here."""
    pr_d = d.get("proof_result") or {}
    proof_result = ProofResult(
        compiles=bool(pr_d.get("compiles", False)),
        has_sorry=bool(pr_d.get("has_sorry", False)),
        sorry_count=int(pr_d.get("sorry_count", 0)),
        score=float(pr_d.get("score", 0.0)),
        errors=list(pr_d.get("errors") or []),
        banned=pr_d.get("banned"),
        aristotle_project_id=pr_d.get("aristotle_project_id"),
        aristotle_status=pr_d.get("aristotle_status"),
    )
    return CycleAttempt(
        round=int(d.get("round", 0)),
        drafter_alias=d.get("drafter_alias", "drafter"),
        candidate=d.get("candidate", ""),
        proof_result=proof_result,
        wall_sec=float(d.get("wall_sec", 0.0)),
        drafter_resp_meta=dict(d.get("drafter_resp_meta") or {}),
    )


def _cycle_result_from_dict(payload: dict[str, Any]) -> CycleResult:
    rounds = [_attempt_from_dict(r) for r in payload.get("rounds") or []]
    final = rounds[-1] if rounds else None
    return CycleResult(
        tid=payload.get("tid", "<unknown>"),
        closed=bool(payload.get("closed", False)),
        final_attempt=final,
        rounds=rounds,
        total_wall_sec=float(payload.get("total_wall_sec", 0.0)),
    )


def _serialize_target(
    target: CycleTarget,
    *,
    model_id: str,
    drafter_alias: str,
    max_rounds: int,
    temperature: float,
    max_tokens: int,
    in_container_lake_path: str,
) -> str:
    """Build the single cycle_target stdin line. lake_project on the
    host is rewritten to the in-container path so verify_proof inside
    the drafter sees the bind-mounted location."""
    return json.dumps({
        "method": "cycle_target",
        "model_id": model_id,
        "drafter_alias": drafter_alias,
        "max_rounds": max_rounds,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "target": {
            "tid": target.tid,
            "imports": list(target.imports),
            "opens": list(target.opens),
            "header": target.header,
            "lake_project": in_container_lake_path,
            "module_path": target.module_path,
            "scratch_namespace": target.scratch_namespace,
            "timeout_per_attempt": target.timeout_per_attempt,
        },
    })


# ─────────────────────────────────────────────────────────────────────
# The real, docker-backed drafter
# ─────────────────────────────────────────────────────────────────────


@dataclass
class ContainerizedDrafter:
    """Real fleet drafter backed by a docker / podman container.

    Each ``.cycle_prove(target)`` call spawns a fresh container with
    ``--network=none`` and the configured bind-mounts, sends the
    target on stdin, services llm_call requests via HostLLMProxy,
    and parses the terminal cycle_result back into a CycleResult.
    The container exits on cycle_result; we wait for it then return.

    Use the real drafter when docker is available + the fleet-drafter
    image is built. Use :class:`FakeContainerizedDrafter` for
    hermetic unit tests.

    Args:
        alias: short name for logs / audit (e.g. "sonnet").
        model_id: dotted model id passed through to host proxy.
        image: container image tag, e.g.
            ``"ghcr.io/athanor-ai/fleet-drafter:2026.04.27"``.
        client_factory: callable ``(model_id) -> ModelClient`` used by
            HostLLMProxy when the container's StdioProxyClient
            requests an llm_call. Default lazily resolves to
            ``kairos.model_client.get_client``.
        cost_tracker: optional cost-tracker per fleet rule
            2026-04-17. Forwarded to HostLLMProxy.
        runtime: ``"docker"`` (default) or ``"podman"``. Resolved at
            call time via ``shutil.which`` so failures are
            diagnosable, not mysterious ImportErrors.
        in_container_lake_path: path inside the container where the
            readonly_lake mount appears. Default ``/workspace/lake``
            matches the Containerfile.
    """
    alias: str
    model_id: str
    image: str
    mounts: DrafterMounts
    client_factory: Optional[Callable[[str], Any]] = None
    cost_tracker: Optional[Any] = None
    runtime: str = "docker"
    in_container_lake_path: str = "/workspace/lake"
    extra_run_args: Sequence[str] = field(default_factory=tuple)

    def cycle_prove(
        self,
        target: CycleTarget,
        *,
        max_rounds: int = 4,
        temperature: float = 0.0,
        max_tokens: int = 800,
    ) -> CycleResult:
        runtime_bin = shutil.which(self.runtime)
        if runtime_bin is None:
            raise RuntimeError(
                f"ContainerizedDrafter[{self.alias}]: "
                f"{self.runtime!r} not found on PATH"
            )
        client_factory = self.client_factory or _default_client_factory

        cmd = [
            runtime_bin, "run", "--rm",
            "--network=none",
            "-i",  # accept stdin
            "-v", f"{self.mounts.readonly_lake}:{self.in_container_lake_path}:ro",
            "-v", f"{self.mounts.writable_workdir}:/workspace/work:rw",
        ]
        if self.mounts.audit_dir is not None:
            cmd.extend([
                "-v", f"{self.mounts.audit_dir}:/workspace/audit:rw",
                "-e", "DRAFTER_AUDIT_DIR=/workspace/audit",
            ])
        cmd.extend(self.extra_run_args)
        cmd.append(self.image)

        target_line = _serialize_target(
            target,
            model_id=self.model_id,
            drafter_alias=self.alias,
            max_rounds=max_rounds,
            temperature=temperature,
            max_tokens=max_tokens,
            in_container_lake_path=self.in_container_lake_path,
        )
        return _run_proxied_subprocess(
            cmd=cmd,
            target_line=target_line,
            client_factory=client_factory,
            cost_tracker=self.cost_tracker,
            drafter_alias=self.alias,
        )

    # ─── ATH-1233 phase 3 commit 1 — v1.2 5-method default impls ───
    # Mirror BaseDrafter defaults so this @dataclass class satisfies the
    # extended DrafterProtocol (post phase 3 commit 1) without forcing
    # callers that built against the v1.0/v1.1 alias+cycle_prove
    # contract to update. Container-specific overrides can replace
    # these in a follow-up commit once the docker-runtime hooks for
    # health probing + IAM cost estimation land.

    def health_check(self) -> bool:
        """Default: ``True`` (always-ready until cycle_prove proves
        otherwise). A container-specific override (docker daemon
        reachable + image present) lands in phase 3 commit 2."""
        return True

    def prepare_target(self, target: CycleTarget) -> CycleTarget:
        """Default: passthrough. Container-specific lake_project mount
        rewrite already happens inside cycle_prove via _serialize_target;
        keeping this as identity preserves that boundary."""
        return target

    def cost_estimate(
        self,
        target: CycleTarget,
        *,
        max_rounds: int = 4,
        max_tokens: int = 800,
    ) -> float:
        """Default: ``0.0`` (unknown — opt-out of cost gating).
        Per-model cost estimation lands once the cost-tracker
        integration covers per-call LLM USD."""
        return 0.0

    def cleanup(self) -> None:
        """Default: no-op. The docker subprocess is one-shot per
        cycle_prove and tears down via the entrypoint's normal exit;
        no persistent per-drafter resource to release here."""
        return None

    @property
    def name(self) -> str:
        """Default: ``alias`` (concise log/audit-friendly identifier
        is also the display name unless overridden)."""
        return self.alias


# ─────────────────────────────────────────────────────────────────────
# Hermetic fake drafter
# ─────────────────────────────────────────────────────────────────────


@dataclass
class FakeContainerizedDrafter:
    """Subprocess-only drafter — no docker. Runs the drafter
    entrypoint in a child Python process directly; the entrypoint
    talks the same JSON-RPC protocol over the subprocess's stdio.

    Use in unit tests + on hosts where docker isn't available. The
    isolation guarantees do NOT hold (the subprocess sees the host
    filesystem); only the protocol contract is exercised.

    Args:
        alias, model_id, client_factory, cost_tracker: same as
            :class:`ContainerizedDrafter`.
        entrypoint_module: dotted module path to the drafter
            entrypoint when invoked via ``python -m``. Defaults to
            the entrypoint installed by the QA-side PR; tests can
            override to point at a stub.
    """
    alias: str
    model_id: str
    entrypoint_module: str = "containers.fleet-drafter.drafter_entrypoint"
    client_factory: Optional[Callable[[str], Any]] = None
    cost_tracker: Optional[Any] = None
    python_executable: str = field(default_factory=lambda: sys.executable)

    def cycle_prove(
        self,
        target: CycleTarget,
        *,
        max_rounds: int = 4,
        temperature: float = 0.0,
        max_tokens: int = 800,
    ) -> CycleResult:
        client_factory = self.client_factory or _default_client_factory
        # Map the entrypoint module to a script path on disk. We use
        # `python -c "import importlib;..."` rather than `python -m`
        # because the entrypoint lives under a containers/ dir whose
        # name has a hyphen (containers/fleet-drafter/) — Python
        # rejects those as importable packages.
        target_line = _serialize_target(
            target,
            model_id=self.model_id,
            drafter_alias=self.alias,
            max_rounds=max_rounds,
            temperature=temperature,
            max_tokens=max_tokens,
            in_container_lake_path=str(target.lake_project),
        )
        cmd = self._resolve_entrypoint_cmd()
        return _run_proxied_subprocess(
            cmd=cmd,
            target_line=target_line,
            client_factory=client_factory,
            cost_tracker=self.cost_tracker,
            drafter_alias=self.alias,
        )

    def _resolve_entrypoint_cmd(self) -> list[str]:
        """If the entrypoint_module is a hyphen-bearing relative
        path under containers/, resolve it to a script path. Else
        defer to ``python -m``."""
        if "/" in self.entrypoint_module or "-" in self.entrypoint_module:
            # Try resolving relative to repo root.
            here = Path(__file__).resolve()
            repo_root = here.parents[3]  # src/kairos/fleet → repo
            script = (
                repo_root
                / "containers" / "fleet-drafter" / "drafter_entrypoint.py"
            )
            if script.is_file():
                return [self.python_executable, str(script)]
            # Fall through and let python -m fail with a clear message.
        return [self.python_executable, "-m", self.entrypoint_module]

    # ─── ATH-1233 phase 3 commit 1 — v1.2 5-method default impls ───
    # Same defaults as ContainerizedDrafter — test-stub variant doesn't
    # need different behavior on health_check / prepare_target /
    # cost_estimate / cleanup / name. Tests that need to override (e.g.
    # to simulate a not-ready drafter for fleet-skip-path coverage)
    # subclass FakeContainerizedDrafter and replace the relevant method.

    def health_check(self) -> bool:
        """Default: ``True``."""
        return True

    def prepare_target(self, target: CycleTarget) -> CycleTarget:
        """Default: passthrough."""
        return target

    def cost_estimate(
        self,
        target: CycleTarget,
        *,
        max_rounds: int = 4,
        max_tokens: int = 800,
    ) -> float:
        """Default: ``0.0`` (test stubs incur no LLM cost by default)."""
        return 0.0

    def cleanup(self) -> None:
        """Default: no-op."""
        return None

    @property
    def name(self) -> str:
        """Default: ``alias``."""
        return self.alias


# ─────────────────────────────────────────────────────────────────────
# Shared subprocess driver
# ─────────────────────────────────────────────────────────────────────


def _default_client_factory(model_id: str) -> Any:
    """Resolve the model id via kairos.model_client at host side. The
    factory is what HostLLMProxy uses to dispatch llm_call. Imported
    lazily so the fleet module can be loaded in environments without
    the model_client surface (e.g. inside a stripped-down container)."""
    from kairos.model_client import get_client
    return get_client(model_id)


def _run_proxied_subprocess(
    *,
    cmd: list[str],
    target_line: str,
    client_factory: Callable[[str], Any],
    cost_tracker: Optional[Any],
    drafter_alias: str,
) -> CycleResult:
    """Spawn ``cmd``, write ``target_line`` (newline-terminated) to
    its stdin, run :class:`HostLLMProxy` against its (stdin, stdout)
    pair, and parse the terminal cycle_result.

    On HostProxyError or non-zero exit, raises ``RuntimeError`` with
    captured stderr (truncated). The caller of cycle_prove sees a
    clear failure rather than a CycleResult with random fields.
    """
    proc = subprocess.Popen(
        cmd,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        env=safe_env_for_cedar(),
    )
    assert proc.stdin is not None and proc.stdout is not None
    # 1. Send the cycle_target on stdin.
    proc.stdin.write(target_line + "\n")
    proc.stdin.flush()

    # 2. Drain stderr in a background thread so the entrypoint can
    # write diagnostic logs without blocking the protocol pipe.
    stderr_buf: list[str] = []

    def _drain_stderr() -> None:
        assert proc.stderr is not None
        for line in proc.stderr:
            stderr_buf.append(line)
    stderr_thread = threading.Thread(target=_drain_stderr, daemon=True)
    stderr_thread.start()

    # 3. Run the host proxy. This blocks until cycle_result arrives
    # (or the container EOFs / sends a bad message → HostProxyError).
    HostLLMProxy, HostProxyError = _load_host_proxy()
    proxy = HostLLMProxy(
        client_factory=client_factory,
        cost_tracker=cost_tracker,
        drafter_alias=drafter_alias,
    )
    try:
        cycle_dict = proxy.run(proc.stdin, proc.stdout)
    except HostProxyError as e:
        # Drain the rest of stderr for diagnostics, kill the child,
        # re-raise.
        try:
            proc.kill()
        except Exception:  # noqa: BLE001 — proc.kill may race with proc-already-exited; OK
            pass
        proc.wait(timeout=5)
        stderr_thread.join(timeout=2)
        stderr_tail = "".join(stderr_buf[-40:])
        raise RuntimeError(
            f"ContainerizedDrafter[{drafter_alias}]: host proxy error: {e}\n"
            f"--- stderr (last 40 lines) ---\n{stderr_tail}"
        ) from e

    # 4. Wait for the child to exit cleanly.
    proc.stdin.close()
    rc = proc.wait(timeout=10)
    stderr_thread.join(timeout=2)
    if rc != 0:
        stderr_tail = "".join(stderr_buf[-40:])
        _logger.warning(
            "ContainerizedDrafter[%s]: subprocess exit %d (cycle_result already parsed; rc nonzero usually fine)\n"
            "--- stderr (last 40 lines) ---\n%s",
            drafter_alias, rc, stderr_tail,
        )

    return _cycle_result_from_dict(cycle_dict)


# ─────────────────────────────────────────────────────────────────────
# ATH-1233 phase 2 commit 3: BaseDrafter ABCMeta virtual-subclass
# registration (path B per CTO 2026-05-14 approval)
# ─────────────────────────────────────────────────────────────────────
#
# Both ``ContainerizedDrafter`` and ``FakeContainerizedDrafter`` satisfy
# the public ``DrafterProtocol`` Generic Protocol via duck-typing (alias
# + model_id + cycle_prove with the documented signature). They are
# ALSO registered as ABCMeta virtual subclasses of ``BaseDrafter`` so
# customer-side and SDK-side code that prefers ``isinstance(d, BaseDrafter)``
# for type-narrow filtering returns ``True`` without forcing either
# class to inherit ``BaseDrafter`` directly.
#
# Path-B rationale (CTO-approved 2026-05-14):
#   1. ``ContainerizedDrafter`` is a ``@dataclass`` with 9 fields; the
#      dataclass-generated ``__init__`` would override
#      ``BaseDrafter.__init__`` if we used true inheritance, breaking
#      the ABC's ``super().__init__(alias=, model_id=)`` contract.
#   2. The runtime ``isinstance`` check that callers care about is
#      already covered by ``DrafterProtocol.@runtime_checkable`` from
#      ``drafter_protocol.py`` commit 1.
#   3. The dataclass shape is load-bearing for
#      ``FakeContainerizedDrafter``'s field-default semantics + the
#      19-test surface in ``test_fleet_containerized_drafter.py``.
#   4. Compile-time abstractmethod enforcement (path A) is nice-to-have
#      but not load-bearing given the protocol-side coverage. Material
#      refactor cost outweighs the marginal compile-time gain.
#
# Trade-off documented honestly: ABCMeta.register() gains
# ``isinstance(d, BaseDrafter) is True`` for both concrete drafter
# classes, but Python skips abstractmethod enforcement for virtual
# subclasses. Mitigated by the Protocol-side coverage (commit 1 tests)
# plus the existing fleet test suite that exercises real
# ``cycle_prove`` invocation paths end-to-end.
from kairos.fleet.drafter_protocol import BaseDrafter as _BaseDrafter

_BaseDrafter.register(ContainerizedDrafter)
_BaseDrafter.register(FakeContainerizedDrafter)
