"""kairos.trace_replay — drain ~/.kairos/failed_events.jsonl (ATH-554).

Complements ATH-553 fail-loud journaling. When SupabaseTraceSink
catches an HTTP 4xx/5xx or transport error on POST/PATCH, it appends
the attempted upload to ``~/.kairos/failed_events.jsonl`` (override
via ``KAIROS_FAILED_EVENTS_JOURNAL``). Operators run::

    kairos trace replay [--dry-run] [--limit N] [--path PATH]

after the upstream issue (network, schema drift, credential expiry)
resolves. The replay re-issues each request:

    * POST → POST to ``{SUPABASE_URL}/rest/v1/{table}``
    * PATCH → PATCH to ``{SUPABASE_URL}/rest/v1/{table}?{_target_filter}``
      (the journal entry's body carries ``_target_filter`` — a PostgREST
      filter string like ``target=eq.<run_id>`` — stamped by close_run
      so the replay can re-issue against the same row).

Per-line outcomes:

    * 2xx response → line drained (removed from the journal).
    * 4xx that's *permanent* (400 Bad Request with a PostgREST "code"
      field that isn't a retryable class) → drained to
      ``<journal>.permanent.jsonl`` so the main queue empties.
    * 5xx / transport error → ``attempts`` incremented, line rewritten
      to the head of the journal for the next invocation.

Exit code: 0 if the main journal is empty at end, 1 otherwise.

Auth precedence mirrors :class:`SupabaseTraceSink` (ATH-553):
``ATHANOR_SYNC_TOKEN`` > ``SUPABASE_SERVICE_ROLE_KEY``. URL resolution
honours ``SUPABASE_URL`` then ``NEXT_PUBLIC_SUPABASE_URL`` (ATH-543).
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

from kairos.trace import (
    _SYNC_TOKEN_ENV,
    _resolve_journal_path,
)

_logger = logging.getLogger(__name__)


# Permanent-failure suffix — PostgREST 4xx with unfixable body (schema
# drift, CHECK constraint violation) move here so the main queue drains.
_PERMANENT_SUFFIX = ".permanent.jsonl"

# 5xx codes we treat as retryable. Anything not in this set and >= 400
# is considered permanent (caller must fix the schema / data before
# the entry can ever succeed). 408 Request Timeout + 429 Too Many
# Requests are retryable too even though they're technically 4xx.
_RETRYABLE_STATUSES = frozenset({408, 429, 500, 502, 503, 504})


@dataclass
class ReplayResult:
    """Outcome of a single :func:`replay` invocation."""

    drained: int = 0                # 2xx → removed from queue
    permanent: int = 0              # 4xx → moved to .permanent.jsonl
    retried: int = 0                # 5xx / transport → attempts++
    skipped: int = 0                # malformed JSONL lines — kept as-is
    remaining: int = 0              # lines left in the main journal at end
    permanent_entries: list[Mapping[str, Any]] = field(default_factory=list)

    @property
    def exit_code(self) -> int:
        """0 if main journal empty at end, 1 otherwise."""
        return 0 if self.remaining == 0 else 1


def _resolve_supabase_url() -> str:
    """Return the Supabase base URL for the replay HTTP calls.

    Mirrors :class:`SupabaseTraceSink._SUPABASE_URL_ENVS` — honours
    ``SUPABASE_URL`` first, then ``NEXT_PUBLIC_SUPABASE_URL`` (ATH-543).
    """
    for name in ("SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_URL"):
        value = os.environ.get(name, "").strip()
        if value:
            return value
    return ""


def _resolve_auth_key() -> str:
    """Return the auth token for the replay HTTP calls.

    ``ATHANOR_SYNC_TOKEN`` takes precedence (ATH-553), then legacy
    ``SUPABASE_SERVICE_ROLE_KEY``. Replay is an operator command —
    required credentials must be present in env.
    """
    token = os.environ.get(_SYNC_TOKEN_ENV, "").strip()
    if token:
        return token
    return os.environ.get("SUPABASE_SERVICE_ROLE_KEY", "").strip()


def _classify_status(status: int | None) -> str:
    """Return ``'success'`` / ``'retry'`` / ``'permanent'`` for ``status``.

    - ``None`` (transport error) → ``retry`` (network/DNS likely transient).
    - 2xx → ``success``.
    - 408 / 429 / 5xx → ``retry``.
    - Any other 4xx → ``permanent`` (schema / data fix required).
    """
    if status is None:
        return "retry"
    if 200 <= status < 300:
        return "success"
    if status in _RETRYABLE_STATUSES:
        return "retry"
    if 400 <= status < 500:
        return "permanent"
    return "retry"


def _issue_request(
    *,
    method: str,
    url: str,
    body: Mapping[str, Any],
    auth_key: str,
    timeout: float = 10.0,
) -> tuple[int | None, str, Exception | None]:
    """Issue the replay HTTP call. Returns ``(status, body, exc)``.

    ``status`` is ``None`` on transport failure. No exceptions bubble
    out — callers need a single return path so they can classify.
    """
    headers = {
        "Content-Type": "application/json",
        "apikey": auth_key,
        "Authorization": f"Bearer {auth_key}",
    }
    if method == "POST":
        headers["Prefer"] = "resolution=merge-duplicates"
    elif method == "PATCH":
        headers["Prefer"] = "return=minimal"

    # 2026-04-25: replay must sanitize NaN/Inf before POST or PGRST102'd
    # events that landed in the journal pre-sanitizer-fix would re-fail
    # forever — every replay would route them to permanent_failures.
    # Mirrors kairos.trace._sanitize_floats_for_json.
    from kairos.trace import _sanitize_floats_for_json
    req = urllib.request.Request(
        url,
        data=json.dumps(_sanitize_floats_for_json(body)).encode("utf-8"),
        headers=headers,
        method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.getcode() or 200, resp.read().decode(
                "utf-8", errors="replace",
            ), None
    except urllib.error.HTTPError as http_exc:
        try:
            resp_body = http_exc.read().decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001 — broad-catch fallback
            resp_body = ""
        return http_exc.code, resp_body, http_exc
    except Exception as exc:  # noqa: BLE001 — guard returns None on any error
        return None, "", exc


def _build_request_url(
    supabase_url: str, table: str, body: Mapping[str, Any], method: str,
) -> tuple[str, dict[str, Any]]:
    """Return ``(request_url, cleaned_body)`` for the replay call.

    For PATCH, the journal body embeds a ``_target_filter`` PostgREST
    filter string (ATH-553). We splice it into the URL and strip it
    from the body so the payload matches the original PATCH.
    """
    base = f"{supabase_url}/rest/v1/{table}"
    cleaned = dict(body)
    if method == "PATCH":
        target_filter = cleaned.pop("_target_filter", "")
        if target_filter:
            return f"{base}?{target_filter}", cleaned
    return base, cleaned


def _parse_line(line: str) -> Mapping[str, Any] | None:
    """Parse one JSONL entry. Returns ``None`` on malformed input so
    the caller can preserve the line as-is rather than dropping it.
    """
    stripped = line.strip()
    if not stripped:
        return None
    try:
        parsed: Mapping[str, Any] | None = json.loads(stripped)
        return parsed
    except json.JSONDecodeError:
        return None


def replay(
    *,
    path: Path | None = None,
    dry_run: bool = False,
    limit: int | None = None,
) -> ReplayResult:
    """Drain the failed-events journal.

    :param path: journal location. Defaults to
        :func:`kairos.trace._resolve_journal_path` (honours
        ``KAIROS_FAILED_EVENTS_JOURNAL``).
    :param dry_run: don't mutate the journal or POST anywhere — print
        what would be sent.
    :param limit: stop after ``limit`` attempts (retry + permanent +
        success all count). ``None`` means no limit.
    :return: :class:`ReplayResult` summarising outcomes.
    """
    journal_path = path or _resolve_journal_path()
    result = ReplayResult()

    if not journal_path.exists():
        return result

    raw_lines = journal_path.read_text(encoding="utf-8").splitlines()

    supabase_url = _resolve_supabase_url()
    auth_key = _resolve_auth_key()

    if not dry_run and (not supabase_url or not auth_key):
        _logger.error(
            "replay cannot proceed without SUPABASE_URL + "
            "(ATHANOR_SYNC_TOKEN or SUPABASE_SERVICE_ROLE_KEY); "
            "%d entries left in journal %s", len(raw_lines), journal_path,
        )
        # Preserve every line exactly — nothing succeeded.
        result.remaining = sum(1 for ln in raw_lines if ln.strip())
        return result

    kept_lines: list[str] = []       # retry + malformed entries to rewrite
    permanent_entries: list[Mapping[str, Any]] = []
    attempts_made = 0

    for raw in raw_lines:
        if not raw.strip():
            continue

        entry = _parse_line(raw)
        if entry is None:
            # Malformed — log and keep as-is so an operator can inspect.
            _logger.warning(
                "replay: skipping malformed journal line (kept as-is): %s",
                raw[:120],
            )
            kept_lines.append(raw)
            result.skipped += 1
            continue

        if limit is not None and attempts_made >= limit:
            # Stop attempting — keep everything from here on.
            kept_lines.append(raw)
            continue

        table = entry.get("table", "")
        body = entry.get("body", {}) or {}
        method = entry.get("method", "POST")

        if not table or method not in ("POST", "PATCH"):
            _logger.warning(
                "replay: entry missing table / unknown method "
                "(table=%r method=%r) — keeping: %s",
                table, method, str(entry)[:120],
            )
            kept_lines.append(raw)
            result.skipped += 1
            continue

        if dry_run:
            url, cleaned_body = _build_request_url(
                supabase_url or "https://SUPABASE_URL", table, body, method,
            )
            print(
                f"DRY-RUN: {method} {url} attempts={entry.get('attempts', 1)}"
            )
            print(f"         body={json.dumps(cleaned_body)[:200]}")
            # Dry-run doesn't drain — preserve line.
            kept_lines.append(raw)
            continue

        attempts_made += 1
        url, cleaned_body = _build_request_url(
            supabase_url, table, body, method,
        )
        status, resp_body, exc = _issue_request(
            method=method, url=url, body=cleaned_body, auth_key=auth_key,
        )

        verdict = _classify_status(status)
        if verdict == "success":
            result.drained += 1
            _logger.info(
                "replay: drained %s %s (status=%s)", method, table, status,
            )
        elif verdict == "permanent":
            result.permanent += 1
            entry_with_last = dict(entry)
            entry_with_last["last_response_status"] = status
            entry_with_last["last_response_body"] = (resp_body or "")[:4000]
            permanent_entries.append(entry_with_last)
            _logger.warning(
                "replay: moving to permanent queue: %s %s status=%s "
                "body=%s",
                method, table, status, (resp_body or "")[:200],
            )
        else:  # retry
            updated = dict(entry)
            updated["attempts"] = int(entry.get("attempts", 1)) + 1
            if status is not None:
                updated["last_response_status"] = status
                updated["last_response_body"] = (resp_body or "")[:4000]
            if exc is not None and not isinstance(
                exc, urllib.error.HTTPError,
            ):
                updated["last_exception_type"] = type(exc).__name__
                updated["last_exception_msg"] = str(exc)
            kept_lines.append(json.dumps(updated))
            result.retried += 1
            _logger.warning(
                "replay: retrying next invocation: %s %s status=%s "
                "attempts_now=%d",
                method, table, status, updated["attempts"],
            )

    if not dry_run:
        # Rewrite the main journal atomically — truncate + write kept.
        if kept_lines:
            content = "\n".join(kept_lines) + "\n"
            journal_path.write_text(content, encoding="utf-8")
        else:
            # Fully drained. Remove the file so `test -f` style checks
            # for operators + cron work naturally.
            try:
                journal_path.unlink()
            except FileNotFoundError:
                pass

        if permanent_entries:
            perm_path = journal_path.with_name(
                journal_path.name + _PERMANENT_SUFFIX,
            )
            with perm_path.open("a", encoding="utf-8") as fp:
                for entry in permanent_entries:
                    fp.write(json.dumps(entry, default=str) + "\n")

    result.permanent_entries = permanent_entries
    result.remaining = sum(
        1 for ln in kept_lines if ln.strip() and _parse_line(ln) is not None
    )
    return result


def cmd_trace_replay(args: Any) -> int:
    """CLI entry point for ``kairos trace replay``.

    Wired into :mod:`kairos.cli` under the ``trace replay`` subcommand.
    Prints a summary line + the :class:`ReplayResult` fields; exits with
    ``result.exit_code`` so cron invocations can alarm on stuck queues.
    """
    path: Path | None = None
    if getattr(args, "path", None):
        path = Path(args.path).expanduser()

    result = replay(
        path=path,
        dry_run=bool(getattr(args, "dry_run", False)),
        limit=getattr(args, "limit", None),
    )

    print(
        f"replay: drained={result.drained} permanent={result.permanent} "
        f"retried={result.retried} skipped={result.skipped} "
        f"remaining={result.remaining}"
    )
    return result.exit_code
