"""Cert-bundle cross-document staleness audit (ATH-1058 Layer 1).

Aidan strategic thesis 2026-05-06 (#agent-founder slack_ts 1778090762):

> "We cannot trust LLMs (you and qa are both LLMs) to do this which
> introduces hallucinations, we need much better infra to prevent
> drift and hallucinations. Our entire company is made up of multiple
> layers of LLMs, that is not enough of a defense"

Triggered by v2.7 cert-bundle drift class recurring 3× across canonical-
flips (b4cdac9a → d92430e9 → 4d9f013c). Each canonical-flip qa updated
the per-iteration cert tables but missed README + 03-honest-framing
secondary references; cto-customer-pretend caught the drift each time.
Multi-layer LLM review caught the instance; only structural prevention
catches the class.

This module is the structural prevention. Layer 1 of the three-layer
drift-prevention plan:

* Layer 1 (this module): scan EVERY .md file in a cert bundle for
  numerical claims + bridge-invariant labels + outcome distributions
  + run_id references; cross-check against canonical engine emit.
  Fail-loud on any drift across any file.
* Layer 2 (kairos.cert.render, future): single-source-of-truth Jinja2
  template render from canonical manifest.json — eliminates the drift
  class structurally by removing duplicated references.
* Layer 3 (kairos cert lint CLI, future): pre-mint qa-side wrapper
  around Layer 1; catches drift before slack-upload to cto.

Edge case scoped from qa review-pass (2026-05-06): bridge labels can
collide across canonicals (e.g. ``inv_state_sync`` appears in both
d92430e9 iter 0 AND 4d9f013c iter 2). Label-presence-only check would
false-pass a flip with stale iter-attribution prose. This module
checks (iter_index, bridge_label) PAIRS and (iter_index,
area_delta_pct) PAIRS, not just label-presence. Same shape applies
to outcome attribution: (iter_index, outcome) pairs not just outcome
counts.

Engine-emit input shape
-----------------------

The audit takes a canonical-engine-emit JSON dict (extracted from
Supabase ``sdk_agent_events`` rows for the cert's run_id). Shape::

    {
      "run_id": "4d9f013c-4a60-49ae-ad86-347ce1f5454c",
      "iterations": [
        {
          "iteration_index": 0,
          "transformation_class": "structural",
          "estimated_area_delta_pct": -8.0,
          "bridge_label": "inv_fifo_state_bridge",
          "outcome": "accepted",
        },
        {
          "iteration_index": 1,
          "transformation_class": "impl_swap",
          "estimated_area_delta_pct": -6.0,
          "bridge_label": "inv_sr_matches_circular_buf",
          "outcome": "refuted",
        },
        {
          "iteration_index": 2,
          "transformation_class": "structural",
          "estimated_area_delta_pct": -5.5,
          "bridge_label": "inv_state_sync",
          "outcome": "accepted",
        }
      ],
      "halt_reason": "proved_equivalent_variant_found",
    }

The extraction step (Supabase query → engine_emit dict) is a separate
concern; this module is pure-function over the dict + the bundle .md
files for unit-testability.

Why pure-function: the customer-claim engine-cross-check meta-rule
applied at the bundle level demands ground-truth deterministic
checks. Live Supabase queries are non-deterministic in flight; the
extraction step must run separately + produce the canonical dict;
this module verifies cert prose against that dict.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ───────────────────────────────────────────────────────────────────
# Datatypes
# ───────────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class BundleClaim:
    """A single (iter_index, field, value) tuple extracted from cert prose.

    Generalization beyond ``CertVerdictClaim`` (which is per-property);
    this is per-iteration cross-document.

    Attributes
    ----------
    iteration_index:
        The iteration the claim is about. ``-1`` for non-iteration-
        scoped claims (e.g. canonical run_id, halt_reason).
    field:
        Which engine-emit field the claim references. One of
        ``"area_delta_pct"`` / ``"bridge_label"`` /
        ``"transformation_class"`` / ``"outcome"`` /
        ``"run_id"`` / ``"halt_reason"`` /
        ``"outcome_count"``.
    claimed_value:
        The value the cert prose claims. Type varies per field:
        float for area_delta_pct, str for bridge_label, etc.
        Stored as str for uniformity; numerical fields parse on
        comparison.
    source_file:
        Cert file the claim was extracted from (relative to bundle
        root; e.g. ``"README.md"``).
    source_line:
        Line number in the source file (1-based).
    """

    iteration_index: int
    field: str
    claimed_value: str
    source_file: str
    source_line: int


@dataclass(frozen=True)
class BundleStalenessFinding:
    """One drift finding: cert claim disagrees with canonical engine emit.

    Attributes
    ----------
    claim:
        The cert claim that disagrees.
    canonical_value:
        The canonical engine-emit value for this (iter_index, field).
        ``None`` when the cert references an iter that doesn't exist
        in the engine emit (e.g. cert mentions iter 3 in a 3-iteration
        run with indices 0/1/2).
    explanation:
        Human-readable explanation. Names the file:line, the claimed
        value, the canonical value, the engine-emit pair-key.
    """

    claim: BundleClaim
    canonical_value: Any
    explanation: str


@dataclass(frozen=True)
class BundleAuditResult:
    """Full audit report.

    Attributes
    ----------
    ok_for_ship:
        ``True`` when every claim across every .md file matches the
        canonical engine emit. ``False`` when any drift found.
    bundle_path:
        Path to the bundle that was audited.
    canonical_run_id:
        The run_id from the engine emit dict.
    claims:
        Every claim extracted across the bundle's .md files.
    findings:
        Every drift / inconsistency found. Empty on
        ``ok_for_ship=True``.
    """

    ok_for_ship: bool
    bundle_path: str
    canonical_run_id: str
    claims: tuple[BundleClaim, ...] = field(default_factory=tuple)
    findings: tuple[BundleStalenessFinding, ...] = field(default_factory=tuple)


# ───────────────────────────────────────────────────────────────────
# Cert-prose extraction patterns
# ───────────────────────────────────────────────────────────────────


# UUID v4 pattern; matches canonical run_id references in prose +
# tahoe URLs.
_RUN_ID_RE = re.compile(
    r"\b([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\b"
)


# Markdown table-row patterns for the per-iteration verdict table:
#   | 0 | structural (...) | claimed -8.0% | ACCEPTED | bridge ...inv_fifo_state_bridge` |
# The iter cell is the first numeric column. Other columns vary per
# cert template; we anchor on iter + scan rest of row for fields.
_TABLE_ITER_CELL_RE = re.compile(
    r"^\|\s*(\d+)\s*\|\s*[^|]*\|"
)


# Area-delta within a table cell or prose: `claimed -8.0%` /
# `claimed area delta -8.0%` / `-8.0%` near "claimed". Matches the
# negative-percent shape that's the proposer-claim convention.
_AREA_DELTA_RE = re.compile(r"claimed[^\n|]{0,30}?(-?\d+\.\d+)%")


# Loose area-delta pattern: matches signed-percent in non-"claimed"
# contexts (e.g. distribution-prose: "structural -12.0% via bridge").
# Used by the untagged-claim extractor — claims caught by this
# pattern are checked as a SET against engine emit, not paired with
# iter_index.
_LOOSE_AREA_DELTA_RE = re.compile(r"(-\d+\.\d+)%")


# Bridge-invariant label backticked in prose. Matches ``inv_*`` shape
# from the closed_loop._invariant_gen convention.
_BRIDGE_LABEL_RE = re.compile(r"`(inv_[a-z_]+)`")


# Outcome word in cert prose. Must be one of the iteration_verdict
# enum values so we don't false-match generic English.
_OUTCOME_KEYWORD_RE = re.compile(
    r"\b(ACCEPTED|REFUTED|INCONCLUSIVE|accepted|refuted|inconclusive)\b"
)


# Outcome distribution prose: "2 accepted, 1 refuted, 0 inconclusive"
# Captures the counts. Accepts arbitrary content between the count
# phrases (parenthetical descriptions with embedded area-deltas /
# bridge labels) so distribution-prose still matches even when the
# parenthetical contains digit characters (e.g. "-12.0%").
_OUTCOME_COUNT_RE = re.compile(
    r"(\d+)\s+accepted.*?(\d+)\s+refuted.*?(\d+)\s+inconclusive"
)


# halt_reason backticked: `proved_equivalent_variant_found` / etc.
_HALT_REASON_RE = re.compile(
    r"`(proved_equivalent_variant_found|no_proposal_closed|"
    r"max_iterations|human_review_needed)`"
)


# Iteration-prefix patterns for prose (non-table) claims:
# "Iteration 0", "iter 0", "iter_0", "Iter 0 — structural"
_ITER_PREFIX_RE = re.compile(
    r"\b[Ii]ter(?:ation)?\s*[_]?\s*(\d+)\b"
)


# ───────────────────────────────────────────────────────────────────
# Extractors
# ───────────────────────────────────────────────────────────────────


def _extract_run_ids(
    text: str,
    source_file: str,
) -> list[BundleClaim]:
    """Every UUIDv4 reference in the file. iter_index=-1 (non-iter-scoped)."""
    claims = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        for m in _RUN_ID_RE.finditer(line):
            claims.append(
                BundleClaim(
                    iteration_index=-1,
                    field="run_id",
                    claimed_value=m.group(1),
                    source_file=source_file,
                    source_line=line_no,
                )
            )
    return claims


def _extract_outcome_counts(
    text: str,
    source_file: str,
) -> list[BundleClaim]:
    """Outcome aggregate prose like '2 accepted, 1 refuted, 0 inconclusive'."""
    claims = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        m = _OUTCOME_COUNT_RE.search(line)
        if m:
            claims.append(
                BundleClaim(
                    iteration_index=-1,
                    field="outcome_count",
                    claimed_value=f"{m.group(1)},{m.group(2)},{m.group(3)}",
                    source_file=source_file,
                    source_line=line_no,
                )
            )
    return claims


def _extract_halt_reasons(
    text: str,
    source_file: str,
) -> list[BundleClaim]:
    """halt_reason enum mentions in prose."""
    claims = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        for m in _HALT_REASON_RE.finditer(line):
            claims.append(
                BundleClaim(
                    iteration_index=-1,
                    field="halt_reason",
                    claimed_value=m.group(1),
                    source_file=source_file,
                    source_line=line_no,
                )
            )
    return claims


def _extract_table_row_claims(
    text: str,
    source_file: str,
) -> list[BundleClaim]:
    """Markdown-table per-iteration claims: iter cell + area delta + bridge + outcome.

    Table-row pattern: ``| 0 | structural ... | claimed -8.0% | ACCEPTED | bridge `inv_state_sync` |``.

    For each row whose first cell is a numeric iter, extract:
      * area_delta_pct (if `claimed -X.X%` present anywhere in row)
      * bridge_label (if `` `inv_*` `` present anywhere in row)
      * outcome (if ACCEPTED/REFUTED/INCONCLUSIVE keyword present)

    All extracted claims are paired with the iter_index from cell 1.
    """
    claims = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        m = _TABLE_ITER_CELL_RE.match(line)
        if m is None:
            continue
        iter_idx = int(m.group(1))
        # Area delta within this row
        for am in _AREA_DELTA_RE.finditer(line):
            claims.append(
                BundleClaim(
                    iteration_index=iter_idx,
                    field="area_delta_pct",
                    claimed_value=am.group(1),
                    source_file=source_file,
                    source_line=line_no,
                )
            )
        # Bridge label within this row
        for bm in _BRIDGE_LABEL_RE.finditer(line):
            claims.append(
                BundleClaim(
                    iteration_index=iter_idx,
                    field="bridge_label",
                    claimed_value=bm.group(1),
                    source_file=source_file,
                    source_line=line_no,
                )
            )
        # Outcome within this row
        om = _OUTCOME_KEYWORD_RE.search(line)
        if om is not None:
            claims.append(
                BundleClaim(
                    iteration_index=iter_idx,
                    field="outcome",
                    claimed_value=om.group(1).lower(),
                    source_file=source_file,
                    source_line=line_no,
                )
            )
    return claims


def _extract_prose_iter_claims(
    text: str,
    source_file: str,
) -> list[BundleClaim]:
    """Prose-block per-iteration claims (non-table).

    Pattern: ``Iteration 0 - structural (claimed -8.0%) - ACCEPTED ... bridge `inv_state_sync` ...``.

    Walks the file paragraph-by-paragraph. Each paragraph that opens
    with an iter-prefix pattern carries forward the iter_index until
    the next iter-prefix paragraph or section heading.

    For each paragraph: extract area_delta_pct + bridge_label +
    outcome same as table-row extraction, paired with the carrying
    iter_index.

    Skips claims that already match the table-row extraction pattern
    (avoids double-counting table prose AND table cells).
    """
    claims = []
    current_iter: int | None = None
    section_heading_re = re.compile(r"^#+\s")
    table_row_iter = _TABLE_ITER_CELL_RE
    for line_no, line in enumerate(text.splitlines(), start=1):
        # Section heading resets current_iter unless heading itself
        # names an iter
        if section_heading_re.match(line):
            iter_in_heading = _ITER_PREFIX_RE.search(line)
            current_iter = (
                int(iter_in_heading.group(1)) if iter_in_heading else None
            )
            continue
        # Pure table rows handled by _extract_table_row_claims; skip
        # to avoid double-counting
        if table_row_iter.match(line):
            continue
        # Inline iter-prefix in prose may set current_iter
        iter_in_prose = _ITER_PREFIX_RE.search(line)
        if iter_in_prose:
            current_iter = int(iter_in_prose.group(1))
        if current_iter is None:
            continue
        # Now extract field claims paired with current_iter
        for am in _AREA_DELTA_RE.finditer(line):
            claims.append(
                BundleClaim(
                    iteration_index=current_iter,
                    field="area_delta_pct",
                    claimed_value=am.group(1),
                    source_file=source_file,
                    source_line=line_no,
                )
            )
        for bm in _BRIDGE_LABEL_RE.finditer(line):
            claims.append(
                BundleClaim(
                    iteration_index=current_iter,
                    field="bridge_label",
                    claimed_value=bm.group(1),
                    source_file=source_file,
                    source_line=line_no,
                )
            )
    return claims


def _extract_untagged_distribution_claims(
    text: str,
    source_file: str,
) -> list[BundleClaim]:
    """Untagged area-delta + bridge-label claims in distribution prose.

    Pattern: ``2 accepted (structural -12.0% via bridge `inv_state_sync` + structural -7.0% via bridge `inv_state_bridge`), 1 refuted (impl_swap -9.0% via `inv_fifo_state_match`)``.

    Lines containing the outcome-count pattern get a follow-up sweep
    for embedded area-deltas + bridge labels. ``iteration_index=-2``
    marks them as "untagged" — the audit checks each value against
    the engine emit's SET of values (any iter), not paired with a
    specific iter.

    This catches the v2.7 README drift class where distribution prose
    references prior-canonical area-deltas + bridges without explicit
    iter prefix.
    """
    claims = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        if not _OUTCOME_COUNT_RE.search(line):
            continue
        # Sweep for area-deltas (looser pattern; signed-percent only)
        for am in _LOOSE_AREA_DELTA_RE.finditer(line):
            claims.append(
                BundleClaim(
                    iteration_index=-2,
                    field="area_delta_pct",
                    claimed_value=am.group(1).lstrip("-"),
                    source_file=source_file,
                    source_line=line_no,
                )
            )
        # Sweep for bridge labels
        for bm in _BRIDGE_LABEL_RE.finditer(line):
            claims.append(
                BundleClaim(
                    iteration_index=-2,
                    field="bridge_label",
                    claimed_value=bm.group(1),
                    source_file=source_file,
                    source_line=line_no,
                )
            )
    return claims


def extract_bundle_claims(bundle_path: Path) -> list[BundleClaim]:
    """Extract every (iter_index, field, value) claim from every .md in bundle.

    Walks ``bundle_path`` for ``*.md`` files (recursive). For each
    file, runs every extractor (table-row, prose-iter, run_id,
    outcome-count, halt-reason). Returns the union of all claims;
    duplicates (same (iter, field, value, file, line)) are NOT
    deduplicated — caller can dedupe if useful.
    """
    bundle = Path(bundle_path)
    if bundle.is_file():
        # Single .md path; treat as bundle of one
        md_files = [bundle] if bundle.suffix == ".md" else []
    else:
        md_files = sorted(bundle.rglob("*.md"))
    claims = []
    for md in md_files:
        if not md.is_file():
            continue
        text = md.read_text()
        rel = str(md.relative_to(bundle if bundle.is_dir() else bundle.parent))
        claims.extend(_extract_run_ids(text, rel))
        claims.extend(_extract_outcome_counts(text, rel))
        claims.extend(_extract_halt_reasons(text, rel))
        claims.extend(_extract_table_row_claims(text, rel))
        claims.extend(_extract_prose_iter_claims(text, rel))
        claims.extend(_extract_untagged_distribution_claims(text, rel))
    return claims


# ───────────────────────────────────────────────────────────────────
# Cross-check against canonical engine emit
# ───────────────────────────────────────────────────────────────────


def _canonical_iter_field(
    engine_emit: dict[str, Any],
    iter_idx: int,
    field_name: str,
) -> Any | None:
    """Look up engine_emit's iterations[iter_idx][field_name].

    Returns None if iter_idx out of range OR field_name not present.

    Field-name mapping: cert prose uses ``area_delta_pct``; engine emit
    uses ``estimated_area_delta_pct`` (per ``_TransformationProposed``
    Pydantic model). Translate before lookup.
    """
    iters = engine_emit.get("iterations", [])
    if iter_idx < 0 or iter_idx >= len(iters):
        return None
    # Cert-prose-field → engine-emit-field translation
    engine_field = {
        "area_delta_pct": "estimated_area_delta_pct",
    }.get(field_name, field_name)
    return iters[iter_idx].get(engine_field)


def _canonical_outcome_count(engine_emit: dict[str, Any]) -> tuple[int, int, int]:
    """Aggregate outcome counts across iterations: (accepted, refuted, inconclusive).

    Errored is NOT counted in the standard distribution; it surfaces
    separately per cluster meta-rule instance #11 (setup-class vs
    engine-class distinction).
    """
    iters = engine_emit.get("iterations", [])
    accepted = sum(1 for it in iters if it.get("outcome") == "accepted")
    refuted = sum(1 for it in iters if it.get("outcome") == "refuted")
    inconclusive = sum(1 for it in iters if it.get("outcome") == "inconclusive")
    return (accepted, refuted, inconclusive)


def _values_match_for_field(
    field_name: str,
    claimed: str,
    canonical: Any,
) -> bool:
    """Field-aware comparison: numeric for area_delta_pct, exact for others.

    For ``area_delta_pct``: cert prose convention is ``claimed -8.0%``
    where the value is captured as the bare number (``8.0``); the
    sign convention is ``negative=area-saving``. Engine emit
    ``estimated_area_delta_pct`` is signed (e.g. ``-8.0``). Compare
    as signed-magnitude: ``-claimed_float == canonical_float`` (since
    cert regex strips the leading minus).
    """
    if canonical is None:
        return False
    if field_name == "area_delta_pct":
        try:
            # Cert regex captures the digits + dot WITHOUT the leading minus
            # in some patterns (e.g. `claimed -8.0%` → `8.0`). Reconstruct
            # the negative; engine emit is signed.
            claimed_f = float(claimed)
            if claimed_f > 0:
                claimed_f = -claimed_f
            return abs(claimed_f - float(canonical)) < 1e-6
        except (TypeError, ValueError):
            return False
    if field_name == "outcome_count":
        # claimed is "A,R,I" string; canonical is (a, r, i) tuple
        try:
            a, r, i = (int(x) for x in claimed.split(","))
            result: bool = (a, r, i) == canonical
            return result
        except (TypeError, ValueError):
            return False
    return str(claimed) == str(canonical)


def cross_check_bundle_against_engine_emit(
    bundle_path: Path,
    engine_emit: dict[str, Any],
) -> BundleAuditResult:
    """Audit a cert bundle for cross-document staleness vs canonical engine emit.

    For every (iter_index, field, claimed_value) extracted from every
    .md in the bundle, asserts that ``engine_emit['iterations'][iter_index][field]``
    matches ``claimed_value``. Pair-check by (iter_index, field) — addresses
    the qa-flagged edge case where bridge labels collide across canonicals
    (same label, different iter attribution).

    For non-iter-scoped claims (run_id, halt_reason, outcome_count):
      * run_id must match ``engine_emit['run_id']`` for every reference
      * halt_reason must match ``engine_emit['halt_reason']``
      * outcome_count must match the aggregated count over iterations

    Returns a :class:`BundleAuditResult` with per-finding file:line +
    claimed-vs-canonical detail. ``ok_for_ship=True`` only when every
    claim matches the canonical engine emit.

    Pure-function: takes the engine_emit as a dict, NOT a live Supabase
    query. Caller (build-tarball.sh + later kairos cert lint CLI) is
    responsible for extracting the canonical engine emit from Supabase
    + passing it in.
    """
    bundle = Path(bundle_path)
    canonical_run_id = engine_emit.get("run_id", "")
    claims = extract_bundle_claims(bundle)
    findings = []

    for claim in claims:
        if claim.field == "run_id":
            if claim.claimed_value != canonical_run_id:
                findings.append(
                    BundleStalenessFinding(
                        claim=claim,
                        canonical_value=canonical_run_id,
                        explanation=(
                            f"{claim.source_file}:{claim.source_line} "
                            f"references run_id "
                            f"{claim.claimed_value!r}, but the canonical "
                            f"run_id for this bundle is "
                            f"{canonical_run_id!r}. Stale reference; "
                            f"update or remove."
                        ),
                    )
                )
            continue

        if claim.field == "halt_reason":
            canonical = engine_emit.get("halt_reason")
            if not _values_match_for_field("halt_reason", claim.claimed_value, canonical):
                findings.append(
                    BundleStalenessFinding(
                        claim=claim,
                        canonical_value=canonical,
                        explanation=(
                            f"{claim.source_file}:{claim.source_line} "
                            f"references halt_reason "
                            f"{claim.claimed_value!r}, but engine emit "
                            f"reports {canonical!r}."
                        ),
                    )
                )
            continue

        if claim.field == "outcome_count":
            canonical = _canonical_outcome_count(engine_emit)
            if not _values_match_for_field(
                "outcome_count", claim.claimed_value, canonical
            ):
                findings.append(
                    BundleStalenessFinding(
                        claim=claim,
                        canonical_value=canonical,
                        explanation=(
                            f"{claim.source_file}:{claim.source_line} "
                            f"prose says outcome distribution "
                            f"{claim.claimed_value!r} (accepted,refuted,"
                            f"inconclusive), but engine emit aggregate "
                            f"is {canonical!r}."
                        ),
                    )
                )
            continue

        # Untagged distribution-prose claims: iter_index = -2.
        # Audit checks claim value is in engine emit's value-set
        # (any iter), not paired with specific iter.
        if claim.iteration_index == -2:
            engine_field = {
                "area_delta_pct": "estimated_area_delta_pct",
            }.get(claim.field, claim.field)
            iters = engine_emit.get("iterations", [])
            value_set = {str(it.get(engine_field)) for it in iters}
            if claim.field == "area_delta_pct":
                # Compare signed-magnitude: cert captures bare digits,
                # engine values are signed
                try:
                    claimed_signed = -float(claim.claimed_value)
                    matches = any(
                        abs(claimed_signed - float(v)) < 1e-6
                        for v in value_set
                        if v not in ("None", "")
                    )
                except (TypeError, ValueError):
                    matches = False
            else:
                matches = claim.claimed_value in value_set
            if not matches:
                findings.append(
                    BundleStalenessFinding(
                        claim=claim,
                        canonical_value=tuple(sorted(value_set)),
                        explanation=(
                            f"{claim.source_file}:{claim.source_line} "
                            f"distribution prose references "
                            f"{claim.field}={claim.claimed_value!r}, but "
                            f"no iteration in engine emit has that value. "
                            f"Stale untagged-claim from a prior canonical."
                        ),
                    )
                )
            continue

        # Iter-scoped fields: area_delta_pct, bridge_label, outcome,
        # transformation_class
        canonical = _canonical_iter_field(
            engine_emit, claim.iteration_index, claim.field
        )
        if canonical is None:
            findings.append(
                BundleStalenessFinding(
                    claim=claim,
                    canonical_value=None,
                    explanation=(
                        f"{claim.source_file}:{claim.source_line} "
                        f"references iteration {claim.iteration_index}'s "
                        f"{claim.field}={claim.claimed_value!r}, but "
                        f"engine emit has no iteration {claim.iteration_index} "
                        f"OR no {claim.field} on that iteration. Stale "
                        f"iter-attribution from a prior canonical."
                    ),
                )
            )
            continue
        if not _values_match_for_field(claim.field, claim.claimed_value, canonical):
            findings.append(
                BundleStalenessFinding(
                    claim=claim,
                    canonical_value=canonical,
                    explanation=(
                        f"{claim.source_file}:{claim.source_line} "
                        f"references iter {claim.iteration_index} "
                        f"{claim.field}={claim.claimed_value!r}, but "
                        f"engine emit reports {canonical!r} on that "
                        f"iteration. Stale claim from a prior canonical."
                    ),
                )
            )

    return BundleAuditResult(
        ok_for_ship=len(findings) == 0,
        bundle_path=str(bundle),
        canonical_run_id=canonical_run_id,
        claims=tuple(claims),
        findings=tuple(findings),
    )


# ───────────────────────────────────────────────────────────────────
# ATH-1058 Layer 1 scope-extension: build-script consistency checks
# ───────────────────────────────────────────────────────────────────
#
# Scope-gap caught by manual cto fourth-pass on PR #508 (2026-05-06):
# build-tarball.sh ships in the customer tarball via cp -r SCAFFOLD_DIR;
# its header comment indexes "Gate N: <description>" pairs. When gates
# get renumbered (e.g. Layer 1 audit displaced the old honest-UNPROVEN
# check at Gate 11), the header goes stale. Customer reads the stale
# header. Cross-doc gate-count references like "(Gates 1-10)" in cert
# prose drift the same way.
#
# Two sibling checks (NOT extending the engine-emit cross-check; that's
# a separate concern — engine-emit is external truth, build-script is
# self-consistency).


# Header-comment "Gate N: description" pattern. Header lines are
# ``#   - Gate N: <description>``; description may continue on
# the next ``#              <continuation>`` line(s) (indented past
# the dash).
_HEADER_GATE_RE = re.compile(
    r"^#\s+-\s+Gate\s+([\w]+):\s*(.+?)\s*$"
)
_HEADER_CONTINUATION_RE = re.compile(r"^#\s{12,}(.+?)\s*$")


# Echo-line gate pattern. Build-tarball.sh prints ``echo "==> Gate N: description"``
# at the top of each gate's block.
_ECHO_GATE_RE = re.compile(
    r'^\s*echo\s+"==>\s+Gate\s+([\w]+):\s*(.+?)"\s*$'
)


# Gate-count assertion patterns in cert prose. Three shapes:
#   1. "Gates 1-N" / "Gates 1 through N"
#   2. "N gates" / "N pre-flight gates" / "the N build-tarball gates"
#   3. "(Gate N)" / "(Gates N-M)"
# Pattern 2 is the loosest; require the surrounding "build-tarball" or
# "pre-flight" or "gates" word to avoid false-matching prose like
# "5 candidates".
_GATE_RANGE_RE = re.compile(
    r"\bGates?\s+1\s*[-–]\s*(\d+)\b"
)
_GATE_RANGE_THROUGH_RE = re.compile(
    r"\bGates?\s+1\s+through\s+(\d+)\b"
)
_GATE_COUNT_RE = re.compile(
    r"\b(\d+)\s+(?:build-tarball\s+)?(?:pre-flight\s+)?gates?\b"
)


def _parse_build_script_header(text: str) -> list[tuple[str, str, int]]:
    """Parse header-comment Gate-N pairs.

    Returns a list of (gate_id, description, line_no) tuples.
    Continuation lines (indented past the dash) get folded into the
    description of the preceding gate.
    """
    pairs: list[tuple[str, str, int]] = []
    current: tuple[str, str, int] | None = None
    for line_no, line in enumerate(text.splitlines(), start=1):
        m = _HEADER_GATE_RE.match(line)
        if m is not None:
            if current is not None:
                pairs.append(current)
            current = (m.group(1), m.group(2), line_no)
            continue
        if current is not None:
            cm = _HEADER_CONTINUATION_RE.match(line)
            if cm is not None:
                gate_id, desc, ln = current
                current = (gate_id, desc + " " + cm.group(1), ln)
                continue
            # Non-matching, non-continuation line ends the header block
            # for the current gate
            pairs.append(current)
            current = None
    if current is not None:
        pairs.append(current)
    return pairs


def _parse_build_script_echo_flow(text: str) -> list[tuple[str, str, int]]:
    """Parse ``echo "==> Gate N: ..."`` lines.

    Returns a list of (gate_id, description, line_no) tuples in
    source order.
    """
    flow: list[tuple[str, str, int]] = []
    for line_no, line in enumerate(text.splitlines(), start=1):
        m = _ECHO_GATE_RE.match(line)
        if m is not None:
            flow.append((m.group(1), m.group(2), line_no))
    return flow


_NOUN_PHRASE_TOKEN_RE = re.compile(r"[a-z][a-z-]{2,}")


def _description_keyword_overlap(a: str, b: str) -> int:
    """Count shared noun-phrase tokens (lowercase, 3+ chars) between two strings.

    Stop-token list filters out common prose words that don't carry
    gate-identity meaning. Returns the number of shared
    distinguishing tokens.
    """
    stop = {
        "the", "and", "for", "from", "with", "into", "that", "this",
        "are", "any", "all", "must", "via", "per", "between", "across",
        "every", "each", "etc", "applied", "shipped", "verify",
        "verifies", "check", "checks", "names", "name", "applies",
        "candidate", "alongside",
    }
    a_tokens = {
        t for t in _NOUN_PHRASE_TOKEN_RE.findall(a.lower()) if t not in stop
    }
    b_tokens = {
        t for t in _NOUN_PHRASE_TOKEN_RE.findall(b.lower()) if t not in stop
    }
    return len(a_tokens & b_tokens)


_BUILD_SCRIPT_NAME = "build-tarball.sh"
_KEYWORD_OVERLAP_THRESHOLD = 2


def cross_check_build_script_consistency(
    bundle_path: Path,
) -> BundleAuditResult:
    """Audit build-tarball.sh header-comment vs actual gate-echo flow.

    For every ``Gate N: <description>`` pair in the header comment,
    asserts there's a matching ``echo "==> Gate N: <description>"``
    line in the script body, with description-keyword-overlap
    (``>= 2`` shared noun-phrase tokens, NOT verbatim string match).

    Direction: header → echo. echo-only gates without header mention
    are tolerated (header is the script-author's chosen index).

    Skips cleanly (returns ok_for_ship=True with empty findings) when
    ``build-tarball.sh`` is absent from the bundle. Some downstream
    cert bundles (customer-redistributable subsets) ship without
    the build script.

    Returns a :class:`BundleAuditResult` shaped like the engine-emit
    audit so callers can aggregate findings across all three sibling
    checks.
    """
    bundle = Path(bundle_path)
    if bundle.is_dir():
        script = bundle / _BUILD_SCRIPT_NAME
    else:
        script = bundle.parent / _BUILD_SCRIPT_NAME
    if not script.is_file():
        return BundleAuditResult(
            ok_for_ship=True,
            bundle_path=str(bundle),
            canonical_run_id="",
            claims=tuple(),
            findings=tuple(),
        )

    text = script.read_text()
    header_pairs = _parse_build_script_header(text)
    flow_pairs = _parse_build_script_echo_flow(text)
    flow_by_id = {gate_id: (desc, ln) for gate_id, desc, ln in flow_pairs}

    claims: list[BundleClaim] = []
    findings: list[BundleStalenessFinding] = []
    rel_script = _BUILD_SCRIPT_NAME

    for gate_id, header_desc, header_line in header_pairs:
        claims.append(
            BundleClaim(
                iteration_index=-1,
                field="build_script_header_gate",
                claimed_value=f"Gate {gate_id}: {header_desc}",
                source_file=rel_script,
                source_line=header_line,
            )
        )
        if gate_id not in flow_by_id:
            findings.append(
                BundleStalenessFinding(
                    claim=claims[-1],
                    canonical_value=None,
                    explanation=(
                        f"{rel_script}:{header_line} header indexes "
                        f"Gate {gate_id} ({header_desc!r}) but no "
                        f'``echo "==> Gate {gate_id}: ..."`` line in '
                        f"the script body. Header is stale or gate "
                        f"was removed."
                    ),
                )
            )
            continue
        flow_desc, flow_line = flow_by_id[gate_id]
        overlap = _description_keyword_overlap(header_desc, flow_desc)
        if overlap < _KEYWORD_OVERLAP_THRESHOLD:
            findings.append(
                BundleStalenessFinding(
                    claim=claims[-1],
                    canonical_value=f"Gate {gate_id}: {flow_desc}",
                    explanation=(
                        f"{rel_script}:{header_line} header describes "
                        f"Gate {gate_id} as {header_desc!r}, but the "
                        f"echo-line at {rel_script}:{flow_line} "
                        f"describes it as {flow_desc!r}. Keyword "
                        f"overlap = {overlap} (< "
                        f"{_KEYWORD_OVERLAP_THRESHOLD}); descriptions "
                        f"likely diverged after a gate-rewire. Update "
                        f"the header to match."
                    ),
                )
            )

    return BundleAuditResult(
        ok_for_ship=len(findings) == 0,
        bundle_path=str(bundle),
        canonical_run_id="",
        claims=tuple(claims),
        findings=tuple(findings),
    )


def cross_check_gate_count_assertions(
    bundle_path: Path,
) -> BundleAuditResult:
    """Audit cert-prose hardcoded gate-count references against actual gate count.

    For every ``.md`` file in the bundle, scans for prose patterns:

      * ``Gates 1-N`` / ``Gates 1 through N``
      * ``N gates`` / ``N pre-flight gates`` / ``N build-tarball gates``

    For each finding, counts the actual ``echo "==> Gate "`` lines in
    ``build-tarball.sh`` and fails-loud if ``N`` doesn't match.

    Gate-number-agnostic phrasing (``the build-tarball pre-flight
    gates`` without a digit) is allowed and produces no claims.

    Skips cleanly (returns ok_for_ship=True with empty findings) when
    ``build-tarball.sh`` is absent from the bundle.
    """
    bundle = Path(bundle_path)
    if bundle.is_dir():
        script = bundle / _BUILD_SCRIPT_NAME
        md_files = sorted(bundle.rglob("*.md"))
    else:
        script = bundle.parent / _BUILD_SCRIPT_NAME
        md_files = [bundle] if bundle.suffix == ".md" else []
    if not script.is_file():
        return BundleAuditResult(
            ok_for_ship=True,
            bundle_path=str(bundle),
            canonical_run_id="",
            claims=tuple(),
            findings=tuple(),
        )

    actual_gate_count = len(_parse_build_script_echo_flow(script.read_text()))

    claims: list[BundleClaim] = []
    findings: list[BundleStalenessFinding] = []
    for md in md_files:
        if not md.is_file():
            continue
        text = md.read_text()
        rel = str(md.relative_to(bundle if bundle.is_dir() else bundle.parent))
        for line_no, line in enumerate(text.splitlines(), start=1):
            for pattern in (_GATE_RANGE_RE, _GATE_RANGE_THROUGH_RE, _GATE_COUNT_RE):
                for m in pattern.finditer(line):
                    claimed_n = int(m.group(1))
                    claim = BundleClaim(
                        iteration_index=-1,
                        field="gate_count_assertion",
                        claimed_value=str(claimed_n),
                        source_file=rel,
                        source_line=line_no,
                    )
                    claims.append(claim)
                    if claimed_n != actual_gate_count:
                        findings.append(
                            BundleStalenessFinding(
                                claim=claim,
                                canonical_value=actual_gate_count,
                                explanation=(
                                    f"{rel}:{line_no} prose references "
                                    f"{claimed_n} gates, but "
                                    f"{_BUILD_SCRIPT_NAME} has "
                                    f"{actual_gate_count} gate-echo "
                                    f"lines. Stale gate-count; update "
                                    f"to {actual_gate_count} or refactor "
                                    f"to gate-number-agnostic phrasing."
                                ),
                            )
                        )

    return BundleAuditResult(
        ok_for_ship=len(findings) == 0,
        bundle_path=str(bundle),
        canonical_run_id="",
        claims=tuple(claims),
        findings=tuple(findings),
    )
