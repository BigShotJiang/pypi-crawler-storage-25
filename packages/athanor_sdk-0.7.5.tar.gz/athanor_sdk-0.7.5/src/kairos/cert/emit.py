"""Certificate emission from run results (ATH-999 Child H).

Bridges the gap between engine run results (RunSecResult,
ClosedLoopResult) and the typed cert pipeline (CertResult ->
gates -> templates -> markdown file).

Customer call:
    result = run_sec_bundle(bundle_path="my_block_v1")
    emit_certificate(result, out_dir="certs/", template=sec_block_certificate)
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable

from beartype import beartype  # type: ignore[import-not-found,import-untyped,unused-ignore]

from kairos.cert.gates import require_gates
from kairos.cert.templates import sec_block_certificate
from kairos.cert.verdict_tier import CertResult, PropertyVerdict, VerdictTier


def sec_result_to_cert(
    run_result: object,
    *,
    module_name: str | None = None,
) -> CertResult:
    """Convert a RunSecResult to a typed CertResult.

    Reads bmc_result and induction_result from the RunSecResult,
    maps per-property verdicts to VerdictTier values.
    """
    run_id = getattr(run_result, "run_id", "")
    bmc = getattr(run_result, "bmc_result", None)
    ind = getattr(run_result, "induction_result", None)
    mod: str = module_name or getattr(run_result, "miter_module", None) or "unknown"

    verdicts: list[PropertyVerdict] = []

    if ind is not None:
        for prop_name, verdict_str in getattr(ind, "property_verdicts", {}).items():
            tier = _map_ebmc_verdict(verdict_str, mode="induction")
            verdicts.append(PropertyVerdict(
                property_name=prop_name,
                tier=tier,
                engine="ebmc",
                details=f"k-induction, bound={getattr(ind, 'bound_k', '?')}",
            ))
    elif bmc is not None:
        for prop_name, verdict_str in getattr(bmc, "property_verdicts", {}).items():
            tier = _map_ebmc_verdict(verdict_str, mode="bmc")
            verdicts.append(PropertyVerdict(
                property_name=prop_name,
                tier=tier,
                engine="ebmc",
                details=f"bmc, bound={getattr(bmc, 'bound_k', '?')}",
                bound_depth=getattr(bmc, "bound_k", None),
            ))

    return CertResult(module_name=mod, verdicts=verdicts, run_id=run_id)


@beartype  # type: ignore[misc,untyped-decorator,unused-ignore]
def emit_certificate(
    run_result: object,
    *,
    out_dir: str | Path,
    template: Callable[[CertResult], str] = sec_block_certificate,
    module_name: str | None = None,
) -> Path:
    """Convert a run result to a cert, run gates, write markdown.

    Accepts either a RunSecResult (converted via sec_result_to_cert)
    or a CertResult directly (passed through unchanged).

    Returns the path to the written certificate file.
    Raises CertGateError if any gate fails.
    """
    if isinstance(run_result, CertResult):
        cert = run_result
    else:
        cert = sec_result_to_cert(run_result, module_name=module_name)
    require_gates(cert)
    md = template(cert)

    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    cert_path = out / f"{cert.module_name}_certificate.md"
    cert_path.write_text(md, encoding="utf-8")
    return cert_path


def _map_ebmc_verdict(verdict_str: str, *, mode: str) -> VerdictTier:
    v = verdict_str.upper()
    if v in ("PROVED", "SUCCESS", "TRUE"):
        if mode == "induction":
            return VerdictTier.EBMC_PROVED
        return VerdictTier.BOUNDED_PROVED
    if v in ("REFUTED", "FAILED", "FALSE"):
        return VerdictTier.REFUTED
    return VerdictTier.INCONCLUSIVE
