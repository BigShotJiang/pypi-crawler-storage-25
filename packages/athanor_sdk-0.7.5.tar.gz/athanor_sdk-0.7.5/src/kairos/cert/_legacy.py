"""kairos.cert — ProofCertificate bundle for third-party audit.

ATH-854 (Q3 of the 2026-04-28 anti-cheat design review).

The Q2 module :mod:`kairos.signing` produces a :class:`SignedVerdict`
(ECDSA signature over a canonicalized verdict shape). Q3 packages
that signature + the verdict + the proof source + a snapshot of the
JWKS into a single tarball that customers can hand to a third-party
auditor (compliance reviewer, regulator, paper reviewer). The
recipient runs ``kairos verify <cert.tar.gz>`` once — no kairos.io
network access needed, the JWKS snapshot inside the bundle is
self-contained.

## Bundle contents

::

    proof-cert.tar.gz
    ├── manifest.json       — version + sha256s + algorithm
    ├── verdict.json        — verdict shape (canonicalized)
    ├── signed_verdict.json — SignedVerdict.to_dict()
    ├── jwks.json           — snapshot of kairos.io's JWKS at sign-time
    └── proof_artifact.txt  — Lean source / SV spec that was verified

## Why a JWKS snapshot

Embedding the JWKS inside the bundle means verification is fully
offline. The auditor doesn't need to trust that kairos.io is up,
that the network reaches them, or that we haven't rotated keys
since the certificate was issued. As long as Q4's audit tab
publishes the same JWKS snapshot at the same point in time, the
embedded copy is verifiable against any contemporaneous mirror.

## Why a separate module from kairos.bundle

:mod:`kairos.bundle` packs whole-run artifacts for customer support
(run.json + proof.lean + counterexample, IP-leak gated). This
module packs a single PROVEN verdict for third-party audit. The
two have different shape, different size budgets, different
verification semantics. Separate modules keep both clear.

## Cross-links

* ATH-853 (Q2) — provides :class:`SignedVerdict` and the
  ``verify_signed_verdict`` primitive this module wraps.
* ATH-855 (L15) — tactic-vocabulary entropy detector; orthogonal to
  certificates, but its verdict will land in the verdict shape that
  Q3 signs over.
* 2026-04-28 anti-cheat review #dev-platform ts=1777398105.887289
"""
from __future__ import annotations

import hashlib
import io
import json
import logging
import os
import tarfile
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from kairos.signing import (
    SignedVerdict,
    canonicalize_verdict,
    verify_signed_verdict,
)


_logger = logging.getLogger(__name__)


CERT_FORMAT_VERSION = "1.0"
MANIFEST_FILENAME = "manifest.json"
VERDICT_FILENAME = "verdict.json"
SIGNED_VERDICT_FILENAME = "signed_verdict.json"
JWKS_FILENAME = "jwks.json"
PROOF_ARTIFACT_FILENAME = "proof_artifact.txt"

# Hard cap. Compliance bundles are small (verdict + sig + JWKS + a few
# kB of proof source). Anything over 50MB is either a pathological
# proof_artifact or adversarial.
MAX_CERT_BYTES = 50 * 1024 * 1024
MAX_PROOF_ARTIFACT_BYTES = 10 * 1024 * 1024


# ── Errors ───────────────────────────────────────────────────────────


class CertError(RuntimeError):
    """Base class for proof-certificate failures."""


class CertManifestError(CertError):
    """Manifest is missing, malformed, or has an unknown version."""


class CertChecksumMismatch(CertError):
    """A bundled file's sha256 doesn't match the manifest entry."""


class CertSignatureInvalid(CertError):
    """The SignedVerdict's signature didn't verify against the JWKS."""


class CertVerdictMismatch(CertError):
    """The signed verdict_json doesn't match verdict.json bytes."""


# ── Result type for verify_proof_certificate ─────────────────────────


@dataclass(frozen=True)
class ProofCertificateVerification:
    """Outcome of verifying a proof-certificate bundle.

    Attributes:
        verdict: The canonicalized verdict shape that was signed.
        signed_verdict: The :class:`SignedVerdict` extracted from
            the bundle.
        proof_artifact: The Lean source / SV spec the verdict was
            about. Useful for the auditor to inspect what was
            actually proven.
        kairos_key_id: Convenience accessor — same as
            ``signed_verdict.kairos_key_id``.
        bundle_format_version: Manifest version (``"1.0"`` for now).
    """
    verdict: dict[str, Any]
    signed_verdict: SignedVerdict
    proof_artifact: str
    kairos_key_id: str
    bundle_format_version: str


# ── Helpers ──────────────────────────────────────────────────────────


def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _add_bytes_to_tar(
    tar: tarfile.TarFile, name: str, data: bytes,
) -> None:
    """Append ``data`` to ``tar`` under ``name`` with deterministic
    metadata (mtime=0, mode=0o644, uid=0). Helps content-addressing
    work — two bundles signed over the same verdict produce identical
    tarball bytes."""
    info = tarfile.TarInfo(name=name)
    info.size = len(data)
    info.mtime = 0
    info.mode = 0o644
    info.uid = 0
    info.gid = 0
    info.uname = ""
    info.gname = ""
    tar.addfile(info, io.BytesIO(data))


def _read_member(tar: tarfile.TarFile, name: str) -> bytes:
    try:
        member = tar.getmember(name)
    except KeyError as exc:
        raise CertManifestError(
            f"bundle missing required file: {name}"
        ) from exc
    f = tar.extractfile(member)
    if f is None:
        raise CertManifestError(
            f"cannot extract {name} from bundle"
        )
    return f.read()


# ── JWKS snapshot ────────────────────────────────────────────────────


def _fetch_jwks_snapshot(
    jwks_url: str = "https://kairos.io/.well-known/signing-keys.json",
    *,
    timeout: int = 10,
) -> dict[str, Any]:
    """Fetch the live JWKS document for embedding in the bundle.

    Hits the network; the resulting dict is what gets embedded in
    ``jwks.json`` so the bundle becomes self-verifying offline.
    Distinct from :func:`kairos.signing._fetch_jwks` which uses an
    in-memory TTL cache for runtime verifies.
    """
    with urllib.request.urlopen(jwks_url, timeout=timeout) as resp:
        data: dict[str, Any] = json.loads(resp.read().decode("utf-8"))
        return data


# ── make_proof_certificate ───────────────────────────────────────────


def make_proof_certificate(
    *,
    verdict: dict[str, Any],
    signed_verdict: SignedVerdict,
    proof_artifact: str,
    output_path: str | Path,
    jwks: dict[str, Any] | None = None,
    jwks_url: str = "https://kairos.io/.well-known/signing-keys.json",
) -> Path:
    """Pack a proof-certificate tarball.

    Args:
        verdict: The structured verdict that was signed. Will be
            canonicalized before embedding.
        signed_verdict: The :class:`SignedVerdict` returned by
            :func:`kairos.signing.request_signed_verdict`.
        proof_artifact: The Lean source / SV spec the verdict is
            about.
        output_path: Where to write the ``.tar.gz``. Parent must
            exist.
        jwks: Optional pre-fetched JWKS snapshot. When None, fetches
            from ``jwks_url`` at bundle time. Customer pipelines that
            already cached a JWKS can pass it in to avoid the network
            round-trip.
        jwks_url: Endpoint to snapshot when ``jwks`` is None.

    Returns:
        :class:`Path` of the written bundle.

    Raises:
        :exc:`CertError`: when the bundle would exceed the size cap
            or the proof_artifact alone exceeds its cap.
        :exc:`urllib.error.URLError`: when ``jwks`` is None and
            ``jwks_url`` is unreachable.
    """
    proof_artifact_bytes = proof_artifact.encode("utf-8")
    if len(proof_artifact_bytes) > MAX_PROOF_ARTIFACT_BYTES:
        raise CertError(
            f"proof_artifact is {len(proof_artifact_bytes)} bytes; "
            f"max allowed is {MAX_PROOF_ARTIFACT_BYTES}"
        )

    verdict_canonical = canonicalize_verdict(verdict)
    verdict_bytes = verdict_canonical.encode("utf-8")
    signed_verdict_bytes = json.dumps(
        signed_verdict.to_dict(),
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")

    if jwks is None:
        jwks = _fetch_jwks_snapshot(jwks_url)
    jwks_bytes = json.dumps(
        jwks, sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")

    manifest = {
        "format_version": CERT_FORMAT_VERSION,
        "algorithm": signed_verdict.key_algorithm,
        "kairos_key_id": signed_verdict.kairos_key_id,
        "signed_at": signed_verdict.signed_at,
        "files": {
            VERDICT_FILENAME: {
                "sha256": _sha256_bytes(verdict_bytes),
                "size": len(verdict_bytes),
            },
            SIGNED_VERDICT_FILENAME: {
                "sha256": _sha256_bytes(signed_verdict_bytes),
                "size": len(signed_verdict_bytes),
            },
            JWKS_FILENAME: {
                "sha256": _sha256_bytes(jwks_bytes),
                "size": len(jwks_bytes),
            },
            PROOF_ARTIFACT_FILENAME: {
                "sha256": _sha256_bytes(proof_artifact_bytes),
                "size": len(proof_artifact_bytes),
            },
        },
        "jwks_url_at_sign_time": jwks_url,
    }
    manifest_bytes = json.dumps(
        manifest, sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")

    total = (
        len(manifest_bytes) + len(verdict_bytes)
        + len(signed_verdict_bytes) + len(jwks_bytes)
        + len(proof_artifact_bytes)
    )
    if total > MAX_CERT_BYTES:
        raise CertError(
            f"certificate would be {total} bytes; max allowed is "
            f"{MAX_CERT_BYTES}"
        )

    out = Path(output_path)
    with tarfile.open(out, "w:gz") as tar:
        _add_bytes_to_tar(tar, MANIFEST_FILENAME, manifest_bytes)
        _add_bytes_to_tar(tar, VERDICT_FILENAME, verdict_bytes)
        _add_bytes_to_tar(tar, SIGNED_VERDICT_FILENAME, signed_verdict_bytes)
        _add_bytes_to_tar(tar, JWKS_FILENAME, jwks_bytes)
        _add_bytes_to_tar(
            tar, PROOF_ARTIFACT_FILENAME, proof_artifact_bytes,
        )

    try:
        os.chmod(out, 0o600)
    except OSError:
        pass  # non-POSIX filesystem; best-effort
    return out


# ── verify_proof_certificate ─────────────────────────────────────────


def verify_proof_certificate(
    cert_path: str | Path,
    *,
    jwks_url: str | None = None,
) -> ProofCertificateVerification:
    """Verify a proof-certificate bundle locally.

    The default verification uses the JWKS embedded in the bundle —
    fully offline, no network. Pass ``jwks_url`` to instead fetch a
    live JWKS (useful when an auditor wants to confirm that the
    embedded snapshot matches what kairos.io publishes today, e.g.
    cross-checking against Q4's audit-tab publication).

    Args:
        cert_path: Path to the ``.tar.gz`` certificate bundle.
        jwks_url: When provided, fetch this URL instead of using the
            embedded JWKS. Live verification.

    Returns:
        :class:`ProofCertificateVerification` on success.

    Raises:
        :exc:`CertManifestError`: bundle is missing files / the
            manifest is malformed / unknown format version.
        :exc:`CertChecksumMismatch`: a bundled file's sha256 doesn't
            match the manifest entry.
        :exc:`CertVerdictMismatch`: ``signed_verdict.verdict_json``
            doesn't match the bytes of ``verdict.json``.
        :exc:`CertSignatureInvalid`: the ECDSA signature didn't
            verify under the resolved public key.
    """
    path = Path(cert_path)
    if not path.is_file():
        raise CertError(f"certificate not found: {path}")
    if path.stat().st_size > MAX_CERT_BYTES:
        raise CertError(
            f"certificate exceeds size cap "
            f"({path.stat().st_size} > {MAX_CERT_BYTES})"
        )

    with tarfile.open(path, "r:gz") as tar:
        manifest_bytes = _read_member(tar, MANIFEST_FILENAME)
        verdict_bytes = _read_member(tar, VERDICT_FILENAME)
        signed_verdict_bytes = _read_member(tar, SIGNED_VERDICT_FILENAME)
        jwks_bytes = _read_member(tar, JWKS_FILENAME)
        proof_artifact_bytes = _read_member(tar, PROOF_ARTIFACT_FILENAME)

    try:
        manifest = json.loads(manifest_bytes)
    except json.JSONDecodeError as exc:
        raise CertManifestError(
            f"manifest.json is not valid JSON: {exc}"
        ) from exc

    fmt_version = manifest.get("format_version")
    if fmt_version != CERT_FORMAT_VERSION:
        raise CertManifestError(
            f"unknown bundle format_version: {fmt_version!r} "
            f"(this kairos verifies version {CERT_FORMAT_VERSION!r})"
        )

    # Checksums.
    files_meta = manifest.get("files", {})
    for name, body in [
        (VERDICT_FILENAME, verdict_bytes),
        (SIGNED_VERDICT_FILENAME, signed_verdict_bytes),
        (JWKS_FILENAME, jwks_bytes),
        (PROOF_ARTIFACT_FILENAME, proof_artifact_bytes),
    ]:
        expected = files_meta.get(name, {}).get("sha256")
        actual = _sha256_bytes(body)
        if expected != actual:
            raise CertChecksumMismatch(
                f"{name}: sha256 mismatch "
                f"(manifest={expected!r}, actual={actual!r})"
            )

    # Reconstruct the SignedVerdict.
    sv_dict = json.loads(signed_verdict_bytes)
    sv = SignedVerdict.from_dict(sv_dict)

    # Verdict-bytes pin: signed_verdict.verdict_json MUST match
    # verdict.json bytes verbatim. Catches the "swap verdict.json
    # but keep the signature" attack.
    if sv.verdict_json != verdict_bytes.decode("utf-8"):
        raise CertVerdictMismatch(
            "signed_verdict.verdict_json does not match verdict.json "
            "bytes — bundle was tampered"
        )

    # Signature verification — uses embedded JWKS by default for
    # offline verification, or fetches live when jwks_url is set.
    if jwks_url is not None:
        ok = verify_signed_verdict(sv, jwks_url=jwks_url)
    else:
        # Inject the embedded JWKS into the signing module's cache so
        # verify_signed_verdict resolves the key offline. Use a
        # synthetic url scheme so we can't collide with a live URL.
        embedded_url = f"embedded:{path.name}"
        from kairos.signing import (
            _JWKS_CACHE,
            _JWKS_CACHE_LOCK,
            _JWKS_CACHE_TIMESTAMPS,
        )
        import time as _time
        embedded_jwks = json.loads(jwks_bytes)
        with _JWKS_CACHE_LOCK:
            _JWKS_CACHE[embedded_url] = embedded_jwks
            _JWKS_CACHE_TIMESTAMPS[embedded_url] = _time.time()
        ok = verify_signed_verdict(sv, jwks_url=embedded_url)

    if not ok:
        raise CertSignatureInvalid(
            f"ECDSA signature did not verify under key_id "
            f"{sv.kairos_key_id!r}"
        )

    return ProofCertificateVerification(
        verdict=json.loads(verdict_bytes),
        signed_verdict=sv,
        proof_artifact=proof_artifact_bytes.decode("utf-8"),
        kairos_key_id=sv.kairos_key_id,
        bundle_format_version=fmt_version,
    )


__all__ = [
    "CERT_FORMAT_VERSION",
    "CertChecksumMismatch",
    "CertError",
    "CertManifestError",
    "CertSignatureInvalid",
    "CertVerdictMismatch",
    "ProofCertificateVerification",
    "make_proof_certificate",
    "verify_proof_certificate",
]
