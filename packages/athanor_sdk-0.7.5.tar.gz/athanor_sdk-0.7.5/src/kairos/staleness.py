"""kairos.staleness — detect version drift across code, CI, containers, cache.

Catches the class of bugs where CI is broken but nobody notices (2-day
blind period), containers have stale binaries, or cache serves old results.

Usage:
    kairos verify --staleness
    from kairos.staleness import check_staleness
"""
from __future__ import annotations

import subprocess
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path


@dataclass
class StalenessCheck:
    name: str
    status: str  # "fresh" | "stale" | "error"
    detail: str = ""
    age_hours: float | None = None


@dataclass
class StalenessReport:
    checks: list[StalenessCheck] = field(default_factory=list)
    stale_count: int = 0
    error_count: int = 0

    @property
    def is_fresh(self) -> bool:
        return self.stale_count == 0 and self.error_count == 0


def check_staleness() -> StalenessReport:
    """Run all staleness checks and return a report."""
    report = StalenessReport()

    report.checks.append(_check_git_sync())
    report.checks.append(_check_ci_last_green())
    report.checks.append(_check_deps_installed())
    report.checks.append(_check_cython_built())

    report.stale_count = sum(1 for c in report.checks if c.status == "stale")
    report.error_count = sum(1 for c in report.checks if c.status == "error")
    return report


def _check_git_sync() -> StalenessCheck:
    """Check if local branch is behind remote."""
    git = shutil.which("git")
    if not git:
        return StalenessCheck("git_sync", "error", "git not found")
    try:
        fetch = subprocess.run([git, "fetch", "origin", "--quiet"], capture_output=True, timeout=15)
        if fetch.returncode != 0:
            return StalenessCheck("git_sync", "error", "git fetch failed")
        result = subprocess.run(
            [git, "rev-list", "--count", "HEAD..origin/main"],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return StalenessCheck("git_sync", "error", f"git rev-list failed: {result.stderr[:100]}")
        behind = int(result.stdout.strip() or "0")
        if behind > 0:
            return StalenessCheck("git_sync", "stale", f"{behind} commits behind origin/main")
        return StalenessCheck("git_sync", "fresh", "up to date with origin/main")
    except Exception as e:  # noqa: BLE001
        return StalenessCheck("git_sync", "error", str(e)[:200])


def _check_ci_last_green() -> StalenessCheck:
    """Check when CI last passed on main."""
    gh = shutil.which("gh")
    if not gh:
        return StalenessCheck("ci_last_green", "error", "gh CLI not found")
    try:
        result = subprocess.run(
            [gh, "api", "repos/{owner}/{repo}/actions/workflows/ci.yml/runs",
             "--jq", ".workflow_runs[] | select(.conclusion==\"success\") | .updated_at",
             ],
            capture_output=True, text=True, timeout=15,
        )
        if not result.stdout.strip():
            return StalenessCheck("ci_last_green", "stale", "no successful CI run found")
        last_green = result.stdout.strip().splitlines()[0]
        dt = datetime.fromisoformat(last_green.replace("Z", "+00:00"))
        age = (datetime.now(timezone.utc) - dt).total_seconds() / 3600
        if age > 24:
            return StalenessCheck("ci_last_green", "stale",
                                  f"last green: {age:.0f}h ago", age_hours=age)
        return StalenessCheck("ci_last_green", "fresh",
                              f"last green: {age:.1f}h ago", age_hours=age)
    except Exception as e:  # noqa: BLE001
        return StalenessCheck("ci_last_green", "error", str(e)[:200])


def _check_deps_installed() -> StalenessCheck:
    """Check that core deps are importable."""
    missing = []
    for mod in ["pydantic", "cryptography", "beartype", "litellm", "yaml"]:
        try:
            __import__(mod)
        except ImportError:
            missing.append(mod)
    if missing:
        return StalenessCheck("deps_installed", "stale",
                              f"missing: {', '.join(missing)}")
    return StalenessCheck("deps_installed", "fresh", "all core deps importable")


def _check_cython_built() -> StalenessCheck:
    """Check that Cython .so files exist."""
    kairos_dir = Path(__file__).resolve().parent
    so_files = list(kairos_dir.rglob("*.so"))
    if not so_files:
        return StalenessCheck("cython_built", "stale", "no .so files found (run build_cython.py)")
    return StalenessCheck("cython_built", "fresh", f"{len(so_files)} .so file(s)")


def format_staleness(report: StalenessReport) -> str:
    """Format report for terminal output."""
    lines = ["Staleness check:"]
    for c in report.checks:
        icon = {"fresh": "+", "stale": "!", "error": "?"}.get(c.status, "?")
        lines.append(f"  [{icon}] {c.name}: {c.detail}")
    if report.is_fresh:
        lines.append("\nAll checks fresh.")
    else:
        lines.append(f"\n{report.stale_count} stale, {report.error_count} errors.")
    return "\n".join(lines)
