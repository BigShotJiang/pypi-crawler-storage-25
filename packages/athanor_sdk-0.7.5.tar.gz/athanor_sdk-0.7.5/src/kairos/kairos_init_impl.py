"""kairos init --rtl <name> — scaffold a hardware verification project."""

import argparse
import os
import sys

SV_TEMPLATE = """\
module alu(
  // TODO: define ports
);
  // TODO: implement logic
endmodule
"""

LEAN_TEMPLATE = """\
-- ALU specification
-- TODO: define your ALU semantics

def alu_add (a b : BitVec 32) : BitVec 32 := a + b

theorem alu_add_comm (a b : BitVec 32) : alu_add a b = alu_add b a := by
  simp [alu_add, BitVec.add_comm]
"""

PROPOSER_TEMPLATE = """\
You are a hardware verification proposer.
-- TODO: customize for your design
"""

AUTOPILOT_TEMPLATE = """\
allowed_actions:
  - propose
  - check
require_before_main_merge:
  - proof
forbidden:
  - force-push
digest: sha256
"""

TOML_TEMPLATE = """\
project_name = "{name}"
rtl_dir = "rtl"
specs_dir = "specs"
prompts_dir = "prompts"
default_proposer_backend = "claude"
"""

FILES = [
    ("rtl/alu.sv", SV_TEMPLATE),
    ("specs/alu.lean", LEAN_TEMPLATE),
    ("prompts/proposer.txt", PROPOSER_TEMPLATE),
    ("autopilot.yaml", AUTOPILOT_TEMPLATE),
    ("kairos.toml", TOML_TEMPLATE),
]


def write_file(path: str, content: str, force: bool) -> bool:
    """Write content to path. Returns True if written, False if skipped."""
    if os.path.exists(path) and not force:
        print(f"  warn: {path} exists, skipping (use --force to overwrite)")
        return False
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(content)
    return True


def init_rtl(name: str, force: bool = False) -> None:
    """Create the project directory structure for RTL verification."""
    root = name

    if os.path.isdir(root) and not force:
        print(f"  note: directory '{root}' already exists, proceeding")

    os.makedirs(root, exist_ok=True)

    created = 0
    for rel_path, template in FILES:
        content = template.format(name=name) if "{name}" in template else template
        full_path = os.path.join(root, rel_path)
        if write_file(full_path, content, force):
            created += 1

    print(f"  created {created} file(s) in {root}/")


def main() -> None:
    parser = argparse.ArgumentParser(prog="kairos", description="Kairos CLI")
    sub = parser.add_subparsers(dest="command")

    init_parser = sub.add_parser("init", help="Initialize a new project")
    init_parser.add_argument("--rtl", action="store_true", help="RTL verification scaffold")
    init_parser.add_argument("--force", action="store_true", help="Overwrite existing files")
    init_parser.add_argument("name", help="Project name")

    args = parser.parse_args()

    if args.command != "init":
        parser.print_help()
        sys.exit(1)

    if not args.rtl:
        print("error: kairos init currently requires --rtl")
        sys.exit(1)

    init_rtl(args.name, force=args.force)


if __name__ == "__main__":
    main()
