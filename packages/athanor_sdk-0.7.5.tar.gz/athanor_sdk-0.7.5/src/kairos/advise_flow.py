"""ATH-1177: generative advise_flow — compose verification flows from NL.

Customer says what they want. kairos returns a runnable verification plan
using existing primitives. No LLM needed for the composition — rule-based
matching on problem structure.

Usage:
    from kairos.advise_flow import compose_flow
    flow = compose_flow("verify my Python API handles edge cases")
    print(flow.code)  # runnable Python snippet
    print(flow.explanation)  # what each step does
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class FlowStep:
    tool: str
    args: dict[str, str]
    explanation: str


@dataclass
class ComposedFlow:
    goal: str
    steps: list[FlowStep] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def code(self) -> str:
        lines = ["from kairos import verify, repair, optimize, explore\n"]
        for i, step in enumerate(self.steps, 1):
            args_str = ", ".join(f'{k}="{v}"' for k, v in step.args.items())
            lines.append(f"# Step {i}: {step.explanation}")
            lines.append(f"result_{i} = {step.tool}({args_str})")
            lines.append("")
        return "\n".join(lines)

    @property
    def explanation(self) -> str:
        parts = [f"Plan for: {self.goal}\n"]
        for i, step in enumerate(self.steps, 1):
            parts.append(f"  {i}. {step.explanation} ({step.tool})")
        if self.warnings:
            parts.append("\nWarnings:")
            for w in self.warnings:
                parts.append(f"  - {w}")
        return "\n".join(parts)


_PATTERNS = [
    {
        "keywords": ["python", "verify", "type", "test", "quality"],
        "steps": [
            FlowStep("verify", {"path": "{path}", "only": "types,properties,symbolic"}, "check types + properties + symbolic exec"),
            FlowStep("repair", {"path": "{path}", "fix": "true"}, "fix findings automatically"),
            FlowStep("verify", {"path": "{path}"}, "re-verify to confirm fixes"),
        ],
    },
    {
        "keywords": ["rtl", "optimize", "area", "silicon", "verilog", "systemverilog"],
        "steps": [
            FlowStep("explore", {"path": "{path}"}, "discover block structure + dependencies"),
            FlowStep("optimize", {"path": "{path}"}, "propose area-reducing transformations with formal proof"),
            FlowStep("verify", {"path": "{path}", "only": "drift"}, "check for security drift in optimized code"),
        ],
    },
    {
        "keywords": ["lean", "prove", "theorem", "sorry", "formal"],
        "steps": [
            FlowStep("repair", {"path": "{path}"}, "close sorry's with 4-level tactic pipeline"),
            FlowStep("verify", {"path": "{path}", "only": "specs"}, "check spec consistency"),
        ],
    },
    {
        "keywords": ["security", "injection", "taint", "vulnerability", "owasp"],
        "steps": [
            FlowStep("verify", {"path": "{path}", "only": "symbolic,drift"}, "taint analysis + security drift detection"),
            FlowStep("repair", {"path": "{path}", "focus": "security"}, "fix security findings"),
        ],
    },
    {
        "keywords": ["test", "mutation", "coverage", "quality"],
        "steps": [
            FlowStep("verify", {"path": "{path}", "only": "mutation,properties"}, "measure test quality via mutation score"),
            FlowStep("repair", {"path": "{path}/tests/", "fix": "true"}, "rewrite vacuous tests"),
            FlowStep("verify", {"path": "{path}", "only": "mutation"}, "re-measure mutation score"),
        ],
    },
    {
        "keywords": ["review", "code", "check", "audit"],
        "steps": [
            FlowStep("verify", {"path": "{path}"}, "full verification (all layers)"),
            FlowStep("repair", {"path": "{path}", "review": "true"}, "review findings without applying fixes"),
        ],
    },
]


def compose_flow(goal: str, path: str = ".") -> ComposedFlow:
    """Compose a verification flow from a natural language goal."""
    flow = ComposedFlow(goal=goal)
    goal_lower = goal.lower()

    best_match = None
    best_score = 0
    for pattern in _PATTERNS:
        score = sum(1 for kw in pattern["keywords"] if kw in goal_lower)
        if score > best_score:
            best_score = score
            best_match = pattern

    if best_match is None:
        flow.steps = [
            FlowStep("verify", {"path": path}, "full verification (all layers)"),
            FlowStep("repair", {"path": path, "fix": "true"}, "fix all findings"),
        ]
        flow.warnings.append("could not determine specific workflow — using full verify + repair")
    else:
        for step in best_match["steps"]:
            args = {k: v.replace("{path}", path) for k, v in step.args.items()}
            flow.steps.append(FlowStep(tool=step.tool, args=args, explanation=step.explanation))

    return flow


def validate_flow(flow: ComposedFlow) -> list[str]:
    """Validate a composed flow for structural correctness."""
    errors = []
    seen_tools = set()
    for step in flow.steps:
        if step.tool not in ("verify", "repair", "optimize", "explore"):
            errors.append(f"unknown tool: {step.tool}")
        seen_tools.add(step.tool)
    if "repair" in seen_tools and "verify" not in seen_tools:
        errors.append("repair without verify — add a verify step to confirm fixes")
    return errors
