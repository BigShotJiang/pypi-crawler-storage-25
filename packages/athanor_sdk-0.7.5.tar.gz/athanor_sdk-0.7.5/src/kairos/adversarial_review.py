"""ATH-1175: Fleet adversarial fix — steelman + fold-justification.

Every kairos review must include adversarial thinking:
1. Steelman: what's the STRONGEST argument against this optimization?
2. Fold-justification: why is it still worth doing despite the steelman?

This prevents the fleet from rubber-stamping its own output.
Sam directive: "be ruthless, not celebratory."

Usage (internal — called by review pipeline):
    from kairos.adversarial_review import adversarial_check
    result = adversarial_check(optimization_result)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AdversarialCheck:
    steelman: str
    fold_justification: str
    risk_level: str  # low | medium | high | critical
    recommendation: str  # accept | review | reject
    concerns: list[str] = field(default_factory=list)

    @property
    def honest_report(self) -> str:
        lines = [
            f"Adversarial review [{self.risk_level}]: {self.recommendation}",
            f"  Steelman: {self.steelman}",
            f"  Justification: {self.fold_justification}",
        ]
        for c in self.concerns:
            lines.append(f"  Concern: {c}")
        return "\n".join(lines)


def adversarial_check(
    *,
    claimed_delta_pct: float,
    proved: bool,
    transformation_class: str = "",
    gold_cells: int | None = None,
    gate_cells: int | None = None,
    timing_met: bool = True,
) -> AdversarialCheck:
    """Generate adversarial steelman + fold-justification."""
    concerns = []
    risk = "low"

    if not proved:
        concerns.append("Equivalence NOT proved — optimization may change behavior")
        risk = "critical"

    if claimed_delta_pct > -1.0 and claimed_delta_pct < 0:
        concerns.append(
            f"Reduction is tiny ({claimed_delta_pct:.1f}%) — may be within "
            f"synthesis noise. Re-synthesize with different seed to confirm."
        )
        risk = max(risk, "medium")

    if not timing_met:
        concerns.append("Timing constraint violated — area saved but setup time broken")
        risk = "critical"

    if transformation_class == "impl_swap":
        concerns.append(
            "impl_swap changes internal state encoding. Formal proof covers "
            "functional equivalence but NOT synthesis tool behavior — the gate "
            "may synthesize differently than expected."
        )
        risk = max(risk, "medium")

    if gold_cells and gate_cells and gate_cells > gold_cells * 0.99:
        concerns.append(
            f"Reduction < 1% ({gold_cells}→{gate_cells}). Synthesis tool "
            f"variability could erase this gain entirely."
        )

    steelman = _generate_steelman(concerns, transformation_class, claimed_delta_pct)
    justification = _generate_justification(proved, claimed_delta_pct, timing_met, concerns)

    if risk == "critical":
        recommendation = "reject"
    elif risk == "high" or len(concerns) >= 3:
        recommendation = "review"
    else:
        recommendation = "accept"

    return AdversarialCheck(
        steelman=steelman,
        fold_justification=justification,
        risk_level=risk,
        recommendation=recommendation,
        concerns=concerns,
    )


def _generate_steelman(
    concerns: list[str],
    transformation_class: str,
    claimed_delta: float,
) -> str:
    if not concerns:
        return "No significant concerns identified."
    return (
        f"Strongest argument against: {concerns[0]} "
        f"Additionally: the {transformation_class or 'unknown'} transformation "
        f"claims {claimed_delta:+.1f}% but real-world synthesis with different "
        f"settings/libraries may yield different results."
    )


def _generate_justification(
    proved: bool,
    claimed_delta: float,
    timing_met: bool,
    concerns: list[str],
) -> str:
    if not proved:
        return "Cannot justify — equivalence not proved."
    if not timing_met:
        return "Cannot justify — timing constraint violated."
    if not concerns:
        return (
            f"Optimization is proved equivalent, meets timing, "
            f"and achieves {claimed_delta:+.1f}% reduction."
        )
    return (
        f"Despite concerns, the optimization IS formally proved equivalent "
        f"({claimed_delta:+.1f}% reduction) and meets timing constraints. "
        f"The concerns are about synthesis variability, not correctness."
    )
