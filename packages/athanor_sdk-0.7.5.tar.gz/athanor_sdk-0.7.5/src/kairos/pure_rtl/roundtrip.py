"""kairos.pure_rtl.roundtrip — original SV ⟶ Clash-regenerated SV ⟶ EQY equivalence.

ATH-944 (PureRTL round-trip v0). The orchestrator that closes the customer's
2026-05-01 round-trip experiment loop on a single proven block:

    [Lean source-of-truth]
            ↓     (manual bridge in v0; Lean→Clash automation = future)
    Spec.hs (Clash)
            ↓     (kairos.pure_rtl.clash_codegen.generate_sv)
    regenerated.sv
            ↓     (kairos.eqy.verify against original_sv)
    PROVED / REFUTED / UNKNOWN

This module is intentionally thin: the load-bearing logic lives in
:mod:`kairos.pure_rtl.clash_codegen` and :mod:`kairos.eqy`. What
``run_roundtrip`` adds is:

* A single composite verdict that maps ``(codegen, equiv)`` →
  ``"proved" / "refuted" / "codegen_failed" / "error"``.
* One ``pure_rtl_roundtrip_complete`` trace event carrying the full
  decomposition + total elapsed time. This is what the platform
  renderer (deferred to v1) will eventually surface on
  ``/solve-runs/[id]``.
* A typed result container the customer demo + integration tests can
  pattern-match against without re-doing the verdict math.

Usage::

    from kairos.pure_rtl.roundtrip import run_roundtrip

    result = run_roundtrip(
        block_name="cpu_single_issue",
        clash_hs_file="examples/pure-rtl-roundtrip/Spec.hs",
        original_sv="examples/pure-rtl-roundtrip/cpu_single_issue.sv",
        top_module="cpu_single_issue",
        workdir="/tmp/roundtrip-cpu",
    )
    assert result.equivalent  # PROVED ≡

Cross-ref:
  * customer engagement discussion — round-trip experiment
    design.
  * :func:`kairos.eqy.verify` — equivalence verdict.
  * :func:`kairos.pure_rtl.clash_codegen.generate_sv` — codegen.
  * docs/internal/pure-rtl-qa-harness-draft.md — qa-harness corpus
    spec these orchestrator results feed into.
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from kairos.eqy import EqyResult, verify
from kairos.pure_rtl.clash_codegen import ClashCodegenResult, generate_sv


@dataclass
class RoundtripResult:
    """Composite outcome of one round-trip pass on a single block."""

    block_name: str
    verdict: str
    """One of ``"proved"``, ``"refuted"``, ``"codegen_failed"``, ``"error"``."""

    codegen: ClashCodegenResult
    equivalence: EqyResult | None
    """``None`` when codegen failed and equivalence was never run."""

    total_elapsed_sec: float

    @property
    def equivalent(self) -> bool:
        """``True`` iff the regenerated SV was proven equivalent."""
        return self.verdict == "proved"

    @property
    def regenerated_sv(self) -> Path | None:
        """Path to the Clash-regenerated SV, if codegen succeeded."""
        sv: Path | None = self.codegen.output_sv_file  # type: ignore[assignment,unused-ignore]
        return sv


def _classify_roundtrip(
    codegen: ClashCodegenResult,
    equivalence: EqyResult | None,
) -> str:
    """Map (codegen, equivalence) → composite round-trip verdict."""
    if not codegen.success:
        return "codegen_failed"
    if equivalence is None:
        return "error"
    if equivalence.verdict == "proved":
        return "proved"
    if equivalence.verdict == "refuted":
        return "refuted"
    # 'unknown' / 'error' from eqy → composite verdict 'error' so the
    # caller doesn't accidentally interpret silence as a pass.
    return "error"


def run_roundtrip(
    block_name: str,
    clash_hs_file: str | Path,
    original_sv: str | Path,
    *,
    top_module: str,
    workdir: str | Path,
    impl_top: str | None = None,
    timeout_sec_codegen: int = 600,
    timeout_sec_equiv: int = 600,
    extra_clash_args: Sequence[str] = (),
    extra_eqy_options: Sequence[str] = (),
    emit_trace: bool = True,
) -> RoundtripResult:
    """Run one round-trip pass: Clash-codegen the spec then EQY-verify.

    Args:
        block_name: human-readable name of the block under round-trip
            (e.g. ``"cpu_single_issue"``). Stamped into the trace event
            payload + the ``RoundtripResult``.
        clash_hs_file: path to the hand-authored Clash-Haskell module
            that mirrors the Lean source-of-truth. v0 = manual bridge;
            future ticket lands the Lean → Clash automation.
        original_sv: path to the original (pre-existing, already-
            proven) SystemVerilog source. This is the spec side of the
            equivalence check.
        top_module: top-module name on the original SV side. The
            generated SV's top is assumed to match unless ``impl_top``
            is set.
        workdir: directory used for codegen + EQY scratch. Created if
            missing. ``regenerated.sv`` lands under
            ``<workdir>/clash-out/`` and the EQY recipe under
            ``<workdir>/eqy/equiv.eqy``.
        impl_top: top-module name for the regenerated side, if it
            differs from ``top_module``.
        timeout_sec_codegen: cap on the Clash subprocess.
        timeout_sec_equiv: cap on the EQY subprocess.
        extra_clash_args: passed through to
            :func:`kairos.pure_rtl.clash_codegen.generate_sv`.
        extra_eqy_options: passed through to :func:`kairos.eqy.verify`.
        emit_trace: when True (default), emit a
            ``pure_rtl_roundtrip_complete`` trace event on completion.

    Returns:
        :class:`RoundtripResult` with the composite verdict + the
        underlying codegen + equivalence verdicts so callers can drill
        in. Never raises for missing toolchain — failures surface as
        ``verdict='codegen_failed'`` / ``'error'``.
    """
    workdir_path = Path(workdir).resolve()
    workdir_path.mkdir(parents=True, exist_ok=True)
    clash_out = workdir_path / "clash-out"
    eqy_workdir = workdir_path / "eqy"

    t0 = time.monotonic()

    codegen_result = generate_sv(
        clash_hs_file,
        top_module=impl_top or top_module,
        output_dir=clash_out,
        timeout_sec=timeout_sec_codegen,
        extra_args=extra_clash_args,
        emit_trace=emit_trace,
    )

    equiv_result: EqyResult | None = None
    if codegen_result.success and codegen_result.output_sv_file is not None:
        equiv_result = verify(
            original_sv,
            codegen_result.output_sv_file,
            top_module=top_module,
            spec_top=top_module,
            impl_top=impl_top,
            timeout_sec=timeout_sec_equiv,
            workdir=eqy_workdir,
            extra_options=extra_eqy_options,
            emit_trace=emit_trace,
        )

    total_elapsed = round(time.monotonic() - t0, 3)
    verdict = _classify_roundtrip(codegen_result, equiv_result)

    result = RoundtripResult(
        block_name=block_name,
        verdict=verdict,
        codegen=codegen_result,
        equivalence=equiv_result,
        total_elapsed_sec=total_elapsed,
    )

    if emit_trace:
        try:
            from kairos.observe import emit
            emit(
                "pure_rtl_roundtrip_complete",
                {
                    "block_name": block_name,
                    "verdict": verdict,
                    "top_module": top_module,
                    "original_sv": str(Path(original_sv).resolve()),
                    "regenerated_sv": (
                        str(codegen_result.output_sv_file)
                        if codegen_result.output_sv_file
                        else None
                    ),
                    "codegen_success": codegen_result.success,
                    "codegen_elapsed_sec": codegen_result.elapsed_sec,
                    "equivalence_verdict": (
                        equiv_result.verdict if equiv_result is not None else None
                    ),
                    "equivalence_elapsed_sec": (
                        equiv_result.elapsed_sec if equiv_result is not None else None
                    ),
                    "total_elapsed_sec": total_elapsed,
                },
            )
        except Exception:  # noqa: BLE001 — trace emit must never break run_roundtrip
            pass

    return result


__all__ = ["RoundtripResult", "run_roundtrip"]
