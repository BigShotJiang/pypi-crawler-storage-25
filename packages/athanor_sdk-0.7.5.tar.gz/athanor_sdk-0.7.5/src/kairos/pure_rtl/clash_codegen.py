"""kairos.pure_rtl.clash_codegen — Haskell/Clash → SystemVerilog codegen.

ATH-944 (PureRTL round-trip v0). Subprocess wrapper around the
``clash`` compiler (https://clash-lang.org/) so the round-trip
orchestrator can take a Clash-Haskell module — the bridge target for
the Lean source-of-truth — and produce SystemVerilog ready to feed
into :func:`kairos.eqy.verify` against the original RTL.

This is **codegen only**. The Lean → Clash bridge itself is a
deliberately manual step in v0 (CTO 2026-05-01 14:08); future
ticket lands the automatic Lean Mealy-machine → Clash translation.
For v0, the customer authors ``Spec.hs`` by hand referencing the Lean
spec, this module compiles it to SV, and :mod:`kairos.eqy` proves the
result equivalent to the original RTL.

Mirrors the call-shape of :func:`kairos.sv.ebmc.run_ebmc` and
:func:`kairos.eqy.verify`:

* :class:`ClashCodegenResult` — structured outcome (verdict, output
  SV path, transcript, timing).
* :func:`generate_sv` — the call. Subprocess + parse + trace emit.

Trace emit:

* ``pure_rtl_clash_codegen`` event (registered in
  :data:`kairos.trace_schema.REGISTRY`). Payload carries
  ``input_hs_file``, ``output_sv_file``, ``elapsed_sec``, ``success``,
  ``top_module``, ``exit_code``.

Errors:

* Missing ``clash`` binary → ``ClashCodegenResult(success=False,
  stderr=<msg>)``. Never raises FileNotFoundError; same contract as
  :func:`kairos.eqy.verify`.
"""
from __future__ import annotations

import shutil
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from kairos.security.env_allowlist import safe_env_for_eval_bash_host


@dataclass
class ClashCodegenResult:
    """Structured outcome from a single ``clash`` invocation."""

    success: bool
    """True when the SV file was produced AND clash exited cleanly."""

    output_sv_file: Path | None
    """Path to the generated SystemVerilog. ``None`` on failure."""

    exit_code: int
    elapsed_sec: float
    stdout: str
    stderr: str
    timed_out: bool = False


def _find_generated_sv(verilog_dir: Path, top_module: str) -> Path | None:
    """Locate the SV file Clash dropped under ``verilog_dir``.

    Clash writes to ``<verilog_dir>/<Module>.<top>/topEntity.sv`` (or
    similar — the exact layout depends on the Clash version and the
    Haskell module's ``$(makeTopEntity ...)`` setup). We search
    breadth-first for any ``*.sv`` file that mentions the top module
    name; if none, we return the first ``*.sv`` we find. ``None`` if
    no SV was emitted.
    """
    if not verilog_dir.exists():
        return None
    sv_files = sorted(verilog_dir.rglob("*.sv"))
    if not sv_files:
        # Clash older versions may emit ``.v`` instead of ``.sv``.
        sv_files = sorted(verilog_dir.rglob("*.v"))
        if not sv_files:
            return None
    # Prefer a file whose name includes the top module.
    for path in sv_files:
        if top_module.lower() in path.name.lower():
            return path
    return sv_files[0]


def generate_sv(
    hs_file: str | Path,
    *,
    top_module: str,
    output_dir: str | Path,
    timeout_sec: int = 600,
    extra_args: Sequence[str] = (),
    emit_trace: bool = True,
) -> ClashCodegenResult:
    """Compile a Clash-Haskell source to SystemVerilog.

    Args:
        hs_file: path to the Haskell module to compile. Must export a
            top-entity that Clash can synthesise (typically annotated
            with ``{-# ANN topEntity ... #-}``).
        top_module: top-module name as it should appear in the
            generated SV. Used both for the Clash invocation flag and
            for locating the emitted SV file inside ``output_dir``.
        output_dir: directory where Clash should drop the generated
            SV. Created if missing. ``ClashCodegenResult.output_sv_file``
            points into this dir.
        timeout_sec: hard wall-clock cap on the ``clash`` subprocess.
        extra_args: extra CLI args appended to the Clash command.
        emit_trace: when True (default), emit a
            ``pure_rtl_clash_codegen`` trace event on completion. Set
            to False for tests / nested invocations.

    Returns:
        :class:`ClashCodegenResult`. Never raises for missing binary
        or timeout — those surface as ``success=False`` /
        ``timed_out=True``.
    """
    hs_path = Path(hs_file).resolve()
    out_dir = Path(output_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    if not hs_path.exists():
        return ClashCodegenResult(
            success=False,
            output_sv_file=None,
            exit_code=-1,
            elapsed_sec=0.0,
            stdout="",
            stderr=f"hs_file does not exist: {hs_path}",
        )

    clash_bin = shutil.which("clash")
    if not clash_bin:
        return ClashCodegenResult(
            success=False,
            output_sv_file=None,
            exit_code=-1,
            elapsed_sec=0.0,
            stdout="",
            stderr="clash binary not found on PATH (install clash-ghc)",
        )

    cmd = [
        clash_bin,
        "--systemverilog",
        str(hs_path),
        "-outputdir",
        str(out_dir),
        *list(extra_args),
    ]

    t0 = time.monotonic()
    timed_out = False
    try:
        res = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            env=safe_env_for_eval_bash_host(),
        )
        elapsed = time.monotonic() - t0
        stdout = res.stdout or ""
        stderr = res.stderr or ""
        exit_code = res.returncode
    except subprocess.TimeoutExpired:
        elapsed = float(timeout_sec)
        stdout = ""
        stderr = f"clash timed out after {timeout_sec}s"
        exit_code = -1
        timed_out = True

    output_sv = _find_generated_sv(out_dir, top_module) if exit_code == 0 else None
    success = exit_code == 0 and output_sv is not None and not timed_out

    result = ClashCodegenResult(
        success=success,
        output_sv_file=output_sv,
        exit_code=exit_code,
        elapsed_sec=round(elapsed, 3),
        stdout=stdout,
        stderr=stderr,
        timed_out=timed_out,
    )

    if emit_trace:
        try:
            from kairos.observe import emit
            emit(
                "pure_rtl_clash_codegen",
                {
                    "input_hs_file": str(hs_path),
                    "output_sv_file": str(output_sv) if output_sv else None,
                    "top_module": top_module,
                    "success": success,
                    "elapsed_sec": result.elapsed_sec,
                    "exit_code": exit_code,
                    "timed_out": timed_out,
                },
            )
        except Exception:  # noqa: BLE001 — trace emit must never break codegen
            pass

    return result


__all__ = ["ClashCodegenResult", "generate_sv"]
