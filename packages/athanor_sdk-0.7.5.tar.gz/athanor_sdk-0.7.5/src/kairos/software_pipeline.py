"""ATH-1457 W5: customer UX for software verification.

One function the customer agent calls. Returns quality score,
actionable fixes, and next_step. The agent loops: verify → fix →
verify → score goes up.

Usage:
    from kairos.software_pipeline import run_software_pipeline
    result = run_software_pipeline("src/")
    print(result.summary)        # "72% verified. 3 actions."
    print(result.next_step)      # "kairos repair src/app.py --fix"
    # agent runs next_step, then calls again — score improves
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class PipelineAction:
    command: str
    reason: str
    impact: str
    priority: int = 0


@dataclass
class SoftwarePipelineResult:
    path: str
    quality_score: int = 0
    files_scanned: int = 0
    bugs_found: int = 0
    fixes_available: int = 0
    actions: list[PipelineAction] = field(default_factory=list)
    next_step: str = ""
    layer_scores: dict[str, int] = field(default_factory=dict)

    @property
    def summary(self) -> str:
        if self.quality_score >= 90:
            return f"{self.quality_score}% verified. Code is clean."
        n = len(self.actions)
        return f"{self.quality_score}% verified. {n} action(s) to improve."

    @property
    def honest_report(self) -> str:
        parts = [self.summary, ""]
        for name, score in self.layer_scores.items():
            icon = "+" if score >= 80 else "!"
            parts.append(f"  [{icon}] {name}: {score}%")
        if self.actions:
            parts.append("")
            parts.append("Actions (highest impact first):")
            for a in self.actions[:5]:
                parts.append(f"  $ {a.command}")
                parts.append(f"    {a.reason} ({a.impact})")
        if self.next_step:
            parts.append(f"\nnext: {self.next_step}")
        return "\n".join(parts)


def run_software_pipeline(
    path: str | Path,
    *,
    fix: bool = False,
) -> SoftwarePipelineResult:
    """Run the full software quality pipeline.

    1. Verify all layers
    2. Generate prioritized actions
    3. Optionally auto-fix
    4. Return quality score + next_step
    """
    target = Path(path)
    result = SoftwarePipelineResult(path=str(path))

    if target.is_file():
        _pipeline_file(target, result, fix)
    elif target.is_dir():
        py_files = sorted(
            f for f in target.rglob("*.py")
            if "__pycache__" not in str(f) and ".git" not in str(f)
        )[:30]
        result.files_scanned = len(py_files)
        for f in py_files:
            _pipeline_file(f, result, fix=False)
        if fix and result.bugs_found > 0:
            result.actions.insert(0, PipelineAction(
                command=f"kairos repair {path} --batch --fix",
                reason=f"{result.bugs_found} bugs across {result.files_scanned} files",
                impact=f"+{min(20, result.bugs_found * 3)}% quality score",
                priority=0,
            ))

    scores = list(result.layer_scores.values())
    result.quality_score = int(sum(scores) / len(scores)) if scores else 0

    result.actions.sort(key=lambda a: a.priority)
    if result.actions:
        result.next_step = result.actions[0].command

    return result


def _pipeline_file(path: Path, result: SoftwarePipelineResult, fix: bool) -> None:
    """Run pipeline on a single file."""
    try:
        from kairos.silent_verify import verify_silently
        v = verify_silently(path.read_text(), file_path=str(path))

        for layer in v.layers_run:
            current = result.layer_scores.get(layer, 100)
            if layer in v.layers_failed:
                result.layer_scores[layer] = min(current, 60)
            else:
                result.layer_scores[layer] = min(current, 100)

        high_bugs = [b for b in v.bugs if b.severity in ("critical", "high")]
        result.bugs_found += len(high_bugs)

        if high_bugs:
            result.fixes_available += len(high_bugs)
            result.actions.append(PipelineAction(
                command=f"kairos repair {path} --fix",
                reason=f"{len(high_bugs)} high-severity bugs",
                impact=f"+{min(15, len(high_bugs) * 5)}% quality score",
                priority=len(high_bugs),
            ))

        if not v.clean and fix:
            try:
                from kairos.software_repair import repair_and_verify
                repair_result = repair_and_verify(path, auto_apply=True)
                result.fixes_available = repair_result.fixes_verified
            except Exception:  # noqa: BLE001
                pass

    except Exception:  # noqa: BLE001
        result.layer_scores.setdefault("error", 0)
