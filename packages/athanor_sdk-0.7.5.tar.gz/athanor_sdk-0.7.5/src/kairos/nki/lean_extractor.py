"""kairos.nki.lean_extractor — NKI fork of the SV → Lean two-gate extractor.

Mirrors :mod:`kairos.pure_rtl.lean_extractor` but applied to NKI:

* **Input.**  An existing NKI kernel implementation (Python source) plus
  the customer's FV obligations as Lean theorems and a reference
  implementation that decides numerical correctness.

* **Output.**  A validated Lean source-of-truth for the kernel and a
  manually-bridged Python mock that the LLM proposed alongside it.

* **Gate 1 — numerical differential equivalence.**  The LLM-proposed
  Python kernel is dropped into a synthesized ``verify.py`` harness
  that diffs it against the customer's reference over a randomised
  sweep, and the harness is executed via :func:`kairos.nki.run_bundle`.
  ``verdict_outcome == "proved"`` is required.

* **Gate 2 — property preservation.**  Each customer property
  (``LeanProperty``) is verified against the proposed Lean spec via
  :func:`kairos.lean.verify_proof`, identical to the SV side.

This is the prototype shape; the real Bet B/Bet H integration upgrades
the gate-1 oracle (currently `run_bundle` against a Python reference)
to a true neuronxcc-simulated kernel run, and the LLM proposer to a
larger-context per-class prompt. The reused `_run_gate2` from
``kairos.pure_rtl.lean_extractor`` keeps the property-preservation
contract identical.
"""
from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Sequence

from kairos.nki._adapter import run_bundle as _run_bundle
from kairos.pure_rtl.lean_extractor import (
    LeanProperty,
    _run_gate2,
)


_logger = logging.getLogger(__name__)


# ── Public types ─────────────────────────────────────────────────────


@dataclass
class NkiIterationOutcome:
    """One LLM round + verdicts of both gates."""

    iteration: int
    proposed_lean: str
    proposed_python: str
    gate1_verdict: str
    """``"proved"`` (the proposed kernel agreed with the reference on
    every sweep input), ``"refuted"`` (numerical divergence on at
    least one input), ``"error"`` (harness failed to run), or
    ``"not_run"`` (the LLM response was malformed and gate 1 never
    started)."""

    gate1_reason: str
    gate2_property_verdicts: dict[str, str]
    """Per-property verdict map: name → ``"proved"`` / ``"refuted"`` /
    ``"error"``."""

    elapsed_sec: float
    feedback_for_next_iter: str | None


@dataclass
class NkiExtractionResult:
    verdict: str
    """``"extracted"`` / ``"rejected"`` / ``"error"``."""

    spec_lean_path: Path | None
    bridge_python_path: Path | None
    iterations: list[NkiIterationOutcome] = field(default_factory=list)
    elapsed_sec: float = 0.0
    error_message: str | None = None

    @property
    def extracted(self) -> bool:
        return self.verdict == "extracted"


# ── LLM proposer ─────────────────────────────────────────────────────


_SYSTEM_PROMPT = """\
You are a formal-methods engineer extracting a Lean 4 source-of-truth
specification for an existing NKI kernel implementation. Your output
is validated by two independent gates:

1. Numerical differential equivalence: the Python kernel you write
   alongside the spec must, when run against the customer's reference
   on a randomised input sweep, agree to within the customer's
   tolerance. This catches gate-level/numerical-implementation bugs.

2. Property preservation: the customer's Lean theorems referencing
   your spec must prove (no `sorry`, no axioms beyond
   `propext`/`Quot.sound`/`Classical.choice`).

Hard constraints on the Lean spec (gate 2 will refute if violated):

* DO NOT import Mathlib or any Mathlib submodule. Use Lean 4 core
  + std4 only. Mathlib imports are banned by the property gate's
  axiom audit and trigger automatic refutation.
* DO NOT declare any `axiom`. Every identifier must be `def` /
  `structure` / `theorem` / `theorem ... := by ...`.
* DO NOT use `unsafe`, `partial`, or `noncomputable` modifiers
  unless the customer property genuinely requires them.
* DO NOT write `sorry` ANYWHERE in your spec, including in helper
  theorems you add for clarity. Gate 2 checks the full proposed
  source for sorry-presence; one stray `sorry` in any helper
  refutes EVERY customer property. If you can't close a helper
  theorem without sorry, leave it out — only the customer's
  required properties need to hold.

A spec that is a literal transcription of the Python implementation
will pass gate 1 but is not the goal. Aim for a refinement-style spec
expressing the kernel's *intent*: pure functions over tile/input/
output records, per-element/per-tile correctness predicates factored
out from the loop. The Python alongside is the manually-bridged image
of that spec — the same shape as the Lean kernel function.

For the Python bridge: do not cast to a narrower dtype than the
reference. If the reference operates on Python `float` (double), do
NOT cast inputs to numpy float32 in your bridge — the precision loss
will cause gate 1 to refute on numerical divergence. Match the
reference's numeric behaviour exactly.

Output format: emit two fenced code blocks, in order, with these
exact fence labels:

```lean
-- Spec.lean
<your Lean source>
```

```python
# kernel.py
<your Python bridge of that spec>
```

The Python module must export a `kernel(*args, **kwargs)` function
matching the customer's reference signature (passed to you below).
No prose between or after the blocks.
"""


_USER_PROMPT_TEMPLATE = """\
Extract a Lean 4 spec for this NKI kernel.

Customer reference signature (your `kernel(...)` must match it):
```python
{reference_signature}
```

The reference's documented contract:
{reference_doc}

The customer's existing FV obligations (each must prove against your
spec):
{property_list}

{previous_iteration_feedback}
"""


_LEAN_FENCE_RE = re.compile(r"```lean\s*\n(.*?)\n```", re.DOTALL | re.IGNORECASE)
_PYTHON_FENCE_RE = re.compile(r"```python\s*\n(.*?)\n```", re.DOTALL | re.IGNORECASE)


def _extract_blocks(content: str) -> tuple[str | None, str | None]:
    lean = _LEAN_FENCE_RE.search(content)
    py = _PYTHON_FENCE_RE.search(content)
    return (
        lean.group(1).strip() if lean else None,
        py.group(1).strip() if py else None,
    )


def _build_property_list(properties: Sequence[LeanProperty]) -> str:
    if not properties:
        return "(none)"
    out = []
    for p in properties:
        out.append(f"- `{p.name}`:")
        out.append("```lean")
        out.append(p.statement.strip())
        out.append("```")
    return "\n".join(out)


def _build_user_prompt(
    *,
    reference_signature: str,
    reference_doc: str,
    properties: Sequence[LeanProperty],
    previous_feedback: str | None,
) -> str:
    feedback_block = ""
    if previous_feedback:
        feedback_block = (
            "Your previous proposal failed validation. Specific feedback:\n"
            f"{previous_feedback}\n\n"
            "Revise to address the failure. Keep what worked; change "
            "only what's needed."
        )
    return _USER_PROMPT_TEMPLATE.format(
        reference_signature=reference_signature.strip(),
        reference_doc=reference_doc.strip() or "(none provided)",
        property_list=_build_property_list(properties),
        previous_iteration_feedback=feedback_block,
    )


# ── Gate 1: numerical differential equivalence ───────────────────────


_HARNESS_TEMPLATE = """\
\"\"\"verify.py — auto-generated harness for NKI lean-extractor gate 1.

Diffs the LLM-proposed kernel against the customer reference over a
sweep loaded from inputs.json (one entry per trial). Each entry is
``{{"args": [...], "shape_label": "..."}}``. Emits summary.json +
test_report.json in the format kairos.nki._adapter expects, exits 0
iff every trial agreed.
\"\"\"
from __future__ import annotations
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import kernel  # the LLM-proposed bridge
import reference  # the customer's reference

ROOT = Path(__file__).resolve().parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(exist_ok=True)

TOL = {tol}
INPUTS = json.loads((ROOT / "inputs.json").read_text())

def _is_close(a, b, tol):
    if isinstance(a, (list, tuple)):
        if len(a) != len(b):
            return False
        return all(_is_close(x, y, tol) for x, y in zip(a, b))
    return math.isclose(float(a), float(b), abs_tol=tol, rel_tol=tol)

def _summarize(results):
    n = len(results)
    n_pass = sum(1 for r in results if r["passed"])
    return {{
        "passed": n_pass == n,
        "n_tests": n,
        "n_passed": n_pass,
        "n_failed": n - n_pass,
        "kernel": "lean_extractor_gate1",
    }}

def main():
    results = []
    for trial, entry in enumerate(INPUTS):
        args = entry["args"]
        label = entry.get("shape_label", f"trial_{{trial}}")
        try:
            got = kernel.kernel(*args)
            want = reference.reference(*args)
        except Exception as exc:
            results.append({{
                "test": f"trial_{{trial}}_{{label}}",
                "passed": False,
                "detail": f"raised {{type(exc).__name__}}: {{exc}}",
            }})
            continue
        ok = _is_close(got, want, TOL)
        results.append({{
            "test": f"trial_{{trial}}_{{label}}",
            "passed": ok,
            "detail": "ok" if ok else f"diverged: got={{got!r}} want={{want!r}}",
        }})
    summary = _summarize(results)
    summary["rationale"] = (
        f"Differential test on {{len(INPUTS)}} sweep inputs, "
        f"tolerance {{TOL}}. {{summary['n_passed']}}/{{summary['n_tests']}} passed."
    )
    (REPORTS / "summary.json").write_text(json.dumps(summary, indent=2))
    (REPORTS / "test_report.json").write_text(json.dumps({{"results": results}}, indent=2))
    sys.exit(0 if summary["passed"] else 1)

if __name__ == "__main__":
    main()
"""


def _run_gate1_nki(
    *,
    proposed_python: str,
    reference_source: str,
    iter_workdir: Path,
    sweep_inputs: Sequence[dict[str, Any]],
    tol: float,
) -> tuple[str, str]:
    """Diff the proposed kernel against the reference via run_bundle.

    Args:
        proposed_python: kernel.py source from the LLM.
        reference_source: reference.py source from the customer.
        iter_workdir: scratch dir for this iteration's bundle.
        sweep_inputs: list of ``{"args": [...], "shape_label": "..."}``
            dicts. Each ``args`` is passed positionally to both
            ``kernel(*args)`` and ``reference(*args)``. Generators in
            :mod:`kairos.nki.lean_extractor_sweeps` produce the right
            shape per kernel class.
        tol: numerical tolerance for the differential test.

    Returns:
        ``(verdict, reason)`` where verdict ∈
        ``{"proved","refuted","error","not_run"}``.
    """
    import json as _json

    bundle = iter_workdir / "bundle"
    bundle.mkdir(parents=True, exist_ok=True)
    (bundle / "kernel.py").write_text(proposed_python)
    (bundle / "reference.py").write_text(reference_source)
    (bundle / "inputs.json").write_text(_json.dumps(list(sweep_inputs)))
    harness = _HARNESS_TEMPLATE.format(tol=tol)
    (bundle / "verify.py").write_text(harness)

    try:
        res = _run_bundle(bundle_path=bundle, kernel_name="gate1")
    except Exception as exc:  # noqa: BLE001 — broad: harness/runtime variety
        return "error", f"run_bundle raised: {type(exc).__name__}: {exc}"

    outcome = getattr(res, "verdict_outcome", "unknown") or "unknown"
    reason = getattr(res, "verdict_reason", "") or ""
    if outcome == "proved":
        return "proved", "all sweep trials agreed within tolerance"
    if outcome == "refuted":
        return "refuted", reason
    return "error", reason or f"unexpected verdict: {outcome}"


# ── Iteration feedback ───────────────────────────────────────────────


def _build_feedback(
    *,
    gate1_verdict: str,
    gate1_reason: str,
    gate2_verdicts: dict[str, str],
) -> str | None:
    parts: list[str] = []
    if gate1_verdict == "not_run":
        parts.append(
            "Gate 1 did not run (LLM response missing one of the fenced blocks)."
        )
    elif gate1_verdict == "refuted":
        parts.append(f"Gate 1 (numerical equivalence) refuted: {gate1_reason}")
    elif gate1_verdict == "error":
        parts.append(f"Gate 1 errored: {gate1_reason}")

    failed = [n for n, v in gate2_verdicts.items() if v != "proved"]
    if failed:
        parts.append(
            "Gate 2 (property preservation) failed for: "
            + ", ".join(f"{n}={gate2_verdicts[n]}" for n in failed)
        )
    return "\n".join(parts) if parts else None


# ── Public extract entry point ───────────────────────────────────────


def extract_from_nki(
    *,
    reference_source: str,
    reference_signature: str,
    reference_doc: str,
    customer_properties: Sequence[LeanProperty],
    workdir: str | Path,
    llm_proposer: Callable[[str, str], tuple[str | None, str | None, str | None]],
    kernel_class: str = "elementwise",
    max_iterations: int = 5,
    n_trials: int = 32,
    tol: float = 1e-9,
    seed: int = 0,
    sweep_inputs: Sequence[dict[str, Any]] | None = None,
    lake_project: str | Path | None = None,
    timeout_sec_per_property: int = 300,
) -> NkiExtractionResult:
    """Run the NKI two-gate iterative extractor.

    Args:
        reference_source: Python source code for the customer's
            reference implementation. Saved as ``reference.py`` in
            each iteration's bundle.
        reference_signature: One-line signature of the reference
            (``def reference(a, b): ...``) shown to the LLM.
        reference_doc: Free-form contract text for the reference
            (what it computes, what tolerances are acceptable, etc.).
        customer_properties: ``LeanProperty`` list each must prove.
        workdir: Directory for per-iteration scratch
            (``iter-NN/bundle/``).
        llm_proposer: Callable ``(system_prompt, user_prompt) ->
            (lean_src, python_src, error)``. Lifted out as a parameter
            so the prototype can be tested with mock or real LLMs
            without depending on a particular client.
        max_iterations: Cap on LLM rounds.
        n_trials: Number of random sweep trials for gate 1.
        tile_sizes: Tile sizes the gate-1 sweep samples from.
        tol: Numerical tolerance for the differential test.
        seed: RNG seed for reproducible sweeps.
        lake_project: Optional pre-existing Lake project for gate 2.
        timeout_sec_per_property: Per-Lean-verification cap.

    Returns:
        :class:`NkiExtractionResult` with the verdict + iteration log.
    """
    workdir_path = Path(workdir).resolve()
    workdir_path.mkdir(parents=True, exist_ok=True)
    lake_path = Path(lake_project).resolve() if lake_project else None

    # Resolve sweep inputs once: caller-provided override > registry
    # generator. The kernel-class generator is the production path;
    # `sweep_inputs` is for tests + bespoke customer sweeps.
    if sweep_inputs is None:
        from kairos.nki.lean_extractor_sweeps import get as _get_gen

        gen = _get_gen(kernel_class)
        resolved_inputs: list[dict[str, Any]] = [
            {"args": list(s.args), "shape_label": s.shape_label}
            for s in gen(seed, n_trials)
        ]
    else:
        resolved_inputs = list(sweep_inputs)

    iterations: list[NkiIterationOutcome] = []
    feedback: str | None = None
    chosen_lean: str | None = None
    chosen_python: str | None = None
    t0 = time.monotonic()

    for i in range(1, max_iterations + 1):
        iter_workdir = workdir_path / f"iter-{i:02d}"
        iter_workdir.mkdir(parents=True, exist_ok=True)
        iter_t0 = time.monotonic()

        user_prompt = _build_user_prompt(
            reference_signature=reference_signature,
            reference_doc=reference_doc,
            properties=customer_properties,
            previous_feedback=feedback,
        )
        proposed_lean, proposed_python, llm_err = llm_proposer(
            _SYSTEM_PROMPT, user_prompt
        )

        if proposed_lean is None or proposed_python is None:
            iterations.append(
                NkiIterationOutcome(
                    iteration=i,
                    proposed_lean=proposed_lean or "",
                    proposed_python=proposed_python or "",
                    gate1_verdict="not_run",
                    gate1_reason=llm_err or "LLM response missing block",
                    gate2_property_verdicts={},
                    elapsed_sec=time.monotonic() - iter_t0,
                    feedback_for_next_iter=(
                        "Your response was missing one of the required "
                        "fenced blocks (```lean and ```python). Emit both."
                    ),
                )
            )
            feedback = iterations[-1].feedback_for_next_iter
            continue

        # Gate 1
        g1_verdict, g1_reason = _run_gate1_nki(
            proposed_python=proposed_python,
            reference_source=reference_source,
            iter_workdir=iter_workdir,
            sweep_inputs=resolved_inputs,
            tol=tol,
        )

        # Gate 2 — only run if gate 1 passed; otherwise feedback the
        # numerical divergence first to keep iteration costs down.
        if g1_verdict == "proved":
            g2_verdicts = _run_gate2(
                proposed_lean=proposed_lean,
                properties=customer_properties,
                iter_workdir=iter_workdir,
                lake_project=lake_path,
                timeout_sec_per_property=timeout_sec_per_property,
            )
        else:
            g2_verdicts = {}

        feedback = _build_feedback(
            gate1_verdict=g1_verdict,
            gate1_reason=g1_reason,
            gate2_verdicts=g2_verdicts,
        )
        iterations.append(
            NkiIterationOutcome(
                iteration=i,
                proposed_lean=proposed_lean,
                proposed_python=proposed_python,
                gate1_verdict=g1_verdict,
                gate1_reason=g1_reason,
                gate2_property_verdicts=g2_verdicts,
                elapsed_sec=time.monotonic() - iter_t0,
                feedback_for_next_iter=feedback,
            )
        )

        # Acceptance: gate 1 proved AND every property proved.
        if g1_verdict == "proved" and all(
            v == "proved" for v in g2_verdicts.values()
        ):
            chosen_lean = proposed_lean
            chosen_python = proposed_python
            break

    elapsed = time.monotonic() - t0

    if chosen_lean is None:
        return NkiExtractionResult(
            verdict="rejected",
            spec_lean_path=None,
            bridge_python_path=None,
            iterations=iterations,
            elapsed_sec=elapsed,
            error_message="iteration budget exhausted with at least one gate failing",
        )

    spec_path = workdir_path / "Spec.lean"
    spec_path.write_text(chosen_lean)
    bridge_path = workdir_path / "kernel.py"
    bridge_path.write_text(chosen_python or "")
    return NkiExtractionResult(
        verdict="extracted",
        spec_lean_path=spec_path,
        bridge_python_path=bridge_path,
        iterations=iterations,
        elapsed_sec=elapsed,
    )


__all__ = [
    "LeanProperty",
    "NkiExtractionResult",
    "NkiIterationOutcome",
    "extract_from_nki",
]
