"""kairos.nki.cost_model — NKI ISA cost annotations, version-pinned to
the neuronxcc release.

Per ATH-1100 Phase 2: single source of truth for the NKI ISA cycle costs
+ HBM byte accounting that previously lived (duplicated) in each bundle's
`bench.py`. When neuronxcc updates ISA cost annotations, this file is
the only edit point; all bench.py / verify scaffolding inherits.

Cost numbers are sourced from the NKI ISA reference at:
https://awsdocs-neuron.readthedocs-hosted.com/en/latest/nki/api/nki.isa.html

The values here track the FP32 path. BFloat16 costs (used by upstream
attn_fwd_v7+) live as separate functions — we explicitly version the
dtype branch in the function name rather than parameterizing it,
because the kernel-author is choosing dtype as a design point, not at
call-site.

Tile size constants (PMAX, FMAX_*) are also pinned here for parity with
``neuronxcc.nki.language.tile_size.*``. The constants here MUST equal
the runtime values; the compatibility check ``assert_runtime_consistent()``
verifies this when neuronxcc is importable.

Usage:

    >>> from kairos.nki.cost_model import isa_cost
    >>> isa_cost.NEURONXCC_VERSION_PINNED
    '2.23.6484'
    >>> isa_cost.PMAX
    128
    >>> isa_cost.nc_matmul_fp32(p=128, f_stationary=128, f_moving=512)
    2048
    >>> isa_cost.hbm_load_bytes(p=128, f=512, dtype="fp32")
    262144

Per-bundle bench.py becomes:

    from kairos.nki.cost_model import isa_cost

    def cost_v3_baseline(seqlen: int, d_head: int) -> dict:
        ...
        te_cycles = isa_cost.nc_matmul_fp32(...)
        hbm_bytes += isa_cost.hbm_load_bytes(...)
        ...
"""
from __future__ import annotations

import warnings
from typing import Final, Literal


# =============================================================================
# Version pin
# =============================================================================
# When neuronxcc updates ISA costs (or tile-size constants), bump this
# version + audit each cost function below. Any drift between this pin
# and the runtime neuronxcc surfaces via assert_runtime_consistent().
NEURONXCC_VERSION_PINNED: Final[str] = "2.23.6484"

# Source citation for cost constants:
NKI_ISA_REFERENCE_URL: Final[str] = (
    "https://awsdocs-neuron.readthedocs-hosted.com/en/latest/nki/api/nki.isa.html"
)


# =============================================================================
# Tile-size constants (parity with neuronxcc.nki.language.tile_size.*)
# =============================================================================
PMAX: Final[int] = 128                  # = nl.tile_size.pmax
FMAX_STATIONARY: Final[int] = 128       # = nl.tile_size.gemm_stationary_fmax
FMAX_MOVING: Final[int] = 512           # = nl.tile_size.gemm_moving_fmax


# =============================================================================
# Tensor Engine (TE) costs
# =============================================================================
def nc_matmul_fp32(p: int, f_stationary: int, f_moving: int) -> int:
    """Cycles for one ``nisa.nc_matmul`` on FP32 inputs.

    Formula: ``4 * max(min(64, N_stationary), N_moving)``.

    Per ISA reference: FP32 matmul is 4x cost of fp8/bf16/fp16/tfloat32.
    The ``min(64, N_stationary)`` cap reflects the PE-array geometry —
    above 64 partitions on the stationary side, the cost stops scaling
    (the array is wider than tall).

    Args:
        p: Partition-axis size of the inputs (= contraction dimension);
           ignored by the formula but checked at call sites for
           PMAX-bound enforcement (≤128).
        f_stationary: Free-axis size of the stationary input (≤128).
        f_moving: Free-axis size of the moving input (≤512).

    Returns:
        Tensor Engine cycles (average; assumes back-to-back identical
        matmuls — pipelining benefits not modeled).
    """
    if p > PMAX:
        raise ValueError(f"partition size {p} exceeds PMAX={PMAX}")
    if f_stationary > FMAX_STATIONARY:
        raise ValueError(
            f"f_stationary {f_stationary} exceeds FMAX_STATIONARY={FMAX_STATIONARY}"
        )
    if f_moving > FMAX_MOVING:
        raise ValueError(f"f_moving {f_moving} exceeds FMAX_MOVING={FMAX_MOVING}")
    return 4 * max(min(64, f_stationary), f_moving)


def nc_matmul_bf16(p: int, f_stationary: int, f_moving: int) -> int:
    """Cycles for ``nisa.nc_matmul`` on BFloat16 / fp16 / tfloat32 inputs.

    Formula: ``max(min(64, N_stationary), N_moving)`` (4x cheaper than
    FP32). Used by upstream attn_fwd_v7+/v8a kernels.
    """
    if p > PMAX:
        raise ValueError(f"partition size {p} exceeds PMAX={PMAX}")
    if f_stationary > FMAX_STATIONARY:
        raise ValueError(
            f"f_stationary {f_stationary} exceeds FMAX_STATIONARY={FMAX_STATIONARY}"
        )
    if f_moving > FMAX_MOVING:
        raise ValueError(f"f_moving {f_moving} exceeds FMAX_MOVING={FMAX_MOVING}")
    return max(min(64, f_stationary), f_moving)


def nc_transpose(p: int, f: int) -> int:
    """Cycles for ``nisa.nc_transpose``. Implemented via nc_matmul with
    identity matrix — same Tensor Engine cost shape as the matmul.
    """
    return 4 * max(min(64, p), f)


# =============================================================================
# Vector Engine (VE) + Scalar Engine (SE) costs
# =============================================================================
def tensor_copy(n: int) -> int:
    """Cycles for ``nisa.tensor_copy``. ~1 cycle per element per
    partition on the Scalar Engine."""
    if n < 0:
        raise ValueError(f"element count {n} cannot be negative")
    return n


def tensor_reduce(n: int) -> int:
    """Cycles for ``nisa.tensor_reduce``. ~N cycles per partition on
    the Vector Engine (tree-reduction over the free dimension)."""
    if n < 0:
        raise ValueError(f"element count {n} cannot be negative")
    return n


def tensor_scalar(n: int, dual_op: bool = False) -> int:
    """Cycles for ``nisa.tensor_scalar``. ~N cycles for the standard
    1-op form; 2N for the dual-op form.

    Args:
        n: Free-axis element count.
        dual_op: True if both op0 + op1 are provided (i.e. a fused
            ``(data op0 operand0) op1 operand1`` ALU sequence).
    """
    if n < 0:
        raise ValueError(f"element count {n} cannot be negative")
    return 2 * n if dual_op else n


def activation(n: int) -> int:
    """Cycles for ``nisa.activation`` (e.g. ``op=nl.exp``). ~N cycles
    on the Scalar Engine (with optional fused reduce — same cost)."""
    if n < 0:
        raise ValueError(f"element count {n} cannot be negative")
    return n


def reciprocal(n: int) -> int:
    """Cycles for ``nisa.reciprocal``. ~N cycles on the Vector Engine."""
    if n < 0:
        raise ValueError(f"element count {n} cannot be negative")
    return n


def scalar_tensor_tensor(n: int) -> int:
    """Cycles for ``nisa.scalar_tensor_tensor``. 2N cycles in the
    general FP32 case; with bf16 + ``op0=nl.subtract`` + ``op1=nl.multiply``
    + N even, the ISA reference quotes ``N`` (specialized fast path).

    For framework purposes we report the general 2N — the fast-path
    is a perf-tuning detail that bench reporting can re-narrow.
    """
    if n < 0:
        raise ValueError(f"element count {n} cannot be negative")
    return 2 * n


# =============================================================================
# HBM byte accounting
# =============================================================================
_DTYPE_BYTES: Final[dict[str, int]] = {
    "fp32": 4,
    "float32": 4,
    "bf16": 2,
    "bfloat16": 2,
    "fp16": 2,
    "float16": 2,
    "fp8": 1,
    "float8_e4m3": 1,
    "float8_e5m2": 1,
    "int32": 4,
    "int8": 1,
}

DType = Literal["fp32", "bf16", "fp16", "fp8", "int32", "int8"]


def hbm_load_bytes(p: int, f: int, dtype: str = "fp32") -> int:
    """HBM-side byte volume for one ``nl.load`` of a ``(p, f)``-shaped tile."""
    if dtype not in _DTYPE_BYTES:
        raise ValueError(f"unknown dtype {dtype!r}; known: {sorted(_DTYPE_BYTES)}")
    return p * f * _DTYPE_BYTES[dtype]


def hbm_store_bytes(p: int, f: int, dtype: str = "fp32") -> int:
    """HBM-side byte volume for one ``nl.store`` of a ``(p, f)``-shaped tile."""
    if dtype not in _DTYPE_BYTES:
        raise ValueError(f"unknown dtype {dtype!r}; known: {sorted(_DTYPE_BYTES)}")
    return p * f * _DTYPE_BYTES[dtype]


def dma_copy_bytes(p: int, f: int, dtype: str = "fp32") -> int:
    """Bytes moved by ``nisa.dma_copy``. Same as load+store volume —
    one full transit of the tile."""
    return hbm_load_bytes(p, f, dtype)


# =============================================================================
# Runtime-consistency check
# =============================================================================
def assert_runtime_consistent(strict: bool = False) -> bool:
    """Assert the pinned tile-size constants match the runtime
    neuronxcc.nki values.

    Drift surfaces here when neuronxcc bumps a tile-size const without
    a corresponding bump to ``NEURONXCC_VERSION_PINNED``. Returns
    ``True`` when consistent, ``False`` (or raises if ``strict``) when
    drift is detected.

    When neuronxcc isn't importable (e.g. CI image without
    aws-neuronx-tools), returns ``True`` after a single deprecation-
    style warning — not an error, since the cost-model is meant to be
    usable on hosts that don't have the runtime.
    """
    try:
        import neuronxcc.nki.language as nl  # type: ignore[import-untyped,import-not-found,unused-ignore]
    except ImportError:
        warnings.warn(
            "neuronxcc not importable; tile-size consistency check skipped. "
            "kairos.nki.cost_model trusts its pinned constants.",
            stacklevel=2,
        )
        return True

    drifts: list[str] = []
    if nl.tile_size.pmax != PMAX:
        drifts.append(f"PMAX: pinned={PMAX}, runtime={nl.tile_size.pmax}")
    if nl.tile_size.gemm_stationary_fmax != FMAX_STATIONARY:
        drifts.append(
            f"FMAX_STATIONARY: pinned={FMAX_STATIONARY}, "
            f"runtime={nl.tile_size.gemm_stationary_fmax}"
        )
    if nl.tile_size.gemm_moving_fmax != FMAX_MOVING:
        drifts.append(
            f"FMAX_MOVING: pinned={FMAX_MOVING}, "
            f"runtime={nl.tile_size.gemm_moving_fmax}"
        )

    if not drifts:
        return True

    msg = (
        f"kairos.nki.cost_model pinned to neuronxcc {NEURONXCC_VERSION_PINNED} "
        f"but runtime drift detected:\n  " + "\n  ".join(drifts)
    )
    if strict:
        raise RuntimeError(msg)
    warnings.warn(msg, stacklevel=2)
    return False


# =============================================================================
# Public namespace — `from kairos.nki.cost_model import isa_cost`
# =============================================================================
class _IsaCostNamespace:
    """Convenience namespace so callers can write
    ``isa_cost.nc_matmul_fp32(...)`` instead of importing each function
    individually. All attributes are read-only.
    """

    NEURONXCC_VERSION_PINNED = NEURONXCC_VERSION_PINNED
    NKI_ISA_REFERENCE_URL = NKI_ISA_REFERENCE_URL
    PMAX = PMAX
    FMAX_STATIONARY = FMAX_STATIONARY
    FMAX_MOVING = FMAX_MOVING

    nc_matmul_fp32 = staticmethod(nc_matmul_fp32)
    nc_matmul_bf16 = staticmethod(nc_matmul_bf16)
    nc_transpose = staticmethod(nc_transpose)
    tensor_copy = staticmethod(tensor_copy)
    tensor_reduce = staticmethod(tensor_reduce)
    tensor_scalar = staticmethod(tensor_scalar)
    activation = staticmethod(activation)
    reciprocal = staticmethod(reciprocal)
    scalar_tensor_tensor = staticmethod(scalar_tensor_tensor)
    hbm_load_bytes = staticmethod(hbm_load_bytes)
    hbm_store_bytes = staticmethod(hbm_store_bytes)
    dma_copy_bytes = staticmethod(dma_copy_bytes)
    assert_runtime_consistent = staticmethod(assert_runtime_consistent)


isa_cost = _IsaCostNamespace()


__all__ = [
    "NEURONXCC_VERSION_PINNED",
    "NKI_ISA_REFERENCE_URL",
    "PMAX",
    "FMAX_STATIONARY",
    "FMAX_MOVING",
    "nc_matmul_fp32",
    "nc_matmul_bf16",
    "nc_transpose",
    "tensor_copy",
    "tensor_reduce",
    "tensor_scalar",
    "activation",
    "reciprocal",
    "scalar_tensor_tensor",
    "hbm_load_bytes",
    "hbm_store_bytes",
    "dma_copy_bytes",
    "assert_runtime_consistent",
    "isa_cost",
    "DType",
]
