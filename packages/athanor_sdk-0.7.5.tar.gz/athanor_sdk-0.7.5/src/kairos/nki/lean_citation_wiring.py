"""ATH-1116 item 4: Lean citation wiring for NKI bundle specs.

Connects Pythia/Hardware Lean theorems to NKI kernel bundle specs
so the cert includes formal backing for optimization claims.

MixedPrecision.lean → BF16 mixed-precision kernel variants
FP8Conversion.lean → FP8 format conversion kernels
CausalMask.lean → attention mask correctness
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class NKILeanCitation:
    """Lean theorem citation for an NKI kernel bundle."""
    kernel_name: str
    theorem_name: str
    module_path: str
    claim: str
    proof_status: str  # "sorry_free" | "has_sorry" | "pending"


NKI_KERNEL_CITATIONS: dict[str, list[NKILeanCitation]] = {
    "softmax": [
        NKILeanCitation(
            kernel_name="softmax",
            theorem_name="Softmax.softmax_shift_invariant",
            module_path="Pythia/Numerical/Softmax.lean",
            claim="softmax(x) = softmax(x - c) for any c in R",
            proof_status="sorry_free",
        ),
    ],
    "fused_attention_softmax": [
        NKILeanCitation(
            kernel_name="fused_attention_softmax",
            theorem_name="LogSumExpStable.log_sum_exp_shift",
            module_path="Pythia/Numerical/Accelerator/LogSumExpStable.lean",
            claim="Online softmax equals offline via log-sum-exp shift stability",
            proof_status="sorry_free",
        ),
        NKILeanCitation(
            kernel_name="fused_attention_softmax",
            theorem_name="Softmax.softmax_shift_invariant",
            module_path="Pythia/Numerical/Softmax.lean",
            claim="softmax(x) = softmax(x - c) for any c in R",
            proof_status="sorry_free",
        ),
    ],
    "online_attention": [
        NKILeanCitation(
            kernel_name="online_attention",
            theorem_name="LogSumExpStable.log_sum_exp_shift",
            module_path="Pythia/Numerical/Accelerator/LogSumExpStable.lean",
            claim="Online softmax equals offline via log-sum-exp shift stability",
            proof_status="sorry_free",
        ),
        NKILeanCitation(
            kernel_name="online_attention",
            theorem_name="MixedPrecision.mixed_precision_inner_product_error",
            module_path="Pythia/Numerical/Accelerator/MixedPrecision.lean",
            claim="FP error bound for running-rescale recurrence: 8*TILE_COUNT*eps*max(|out|)",
            proof_status="sorry_free",
        ),
        NKILeanCitation(
            kernel_name="online_attention",
            theorem_name="Accelerator.softcap_lipschitz",
            module_path="Pythia/Numerical/Accelerator.lean",
            claim="softcap(x, c) is Lipschitz-1 for all c > 0",
            proof_status="sorry_free",
        ),
    ],
    "rope_attention": [
        NKILeanCitation(
            kernel_name="rope_attention",
            theorem_name="RoPE.rotation_transpose_mul_self",
            module_path="Pythia/Numerical/RoPE.lean",
            claim="RoPE rotation matrix is orthogonal: R^T * R = I",
            proof_status="sorry_free",
        ),
    ],
    "vector_add_relu": [
        NKILeanCitation(
            kernel_name="vector_add_relu",
            theorem_name="ReLU.pointwise_monotone",
            module_path="Pythia/Analysis/Activation.lean",
            claim="ReLU preserves element ordering (monotone)",
            proof_status="sorry_free",
        ),
    ],
    "matmul_bf16": [
        NKILeanCitation(
            kernel_name="matmul_bf16",
            theorem_name="MixedPrecision.mixed_precision_inner_product_error",
            module_path="Pythia/Numerical/Accelerator/MixedPrecision.lean",
            claim="BF16 accumulation error bounded by mixed-precision inner product theorem",
            proof_status="sorry_free",
        ),
    ],
    "matmul_fp8": [
        NKILeanCitation(
            kernel_name="matmul_fp8",
            theorem_name="FP8Conversion.fp8_fp32_roundtrip_error",
            module_path="Pythia/Hardware/FP8Conversion.lean",
            claim="FP8 E4M3 to FP32 upconversion is exact; FP32 to FP8 RNE error bounded",
            proof_status="sorry_free",
        ),
        NKILeanCitation(
            kernel_name="matmul_fp8",
            theorem_name="MixedPrecision.mixed_precision_inner_product_error",
            module_path="Pythia/Numerical/Accelerator/MixedPrecision.lean",
            claim="FP8+FP32 mixed-precision inner product error composition",
            proof_status="sorry_free",
        ),
    ],
}


def get_citations_for_kernel(kernel_name: str) -> list[NKILeanCitation]:
    """Look up Lean citations for an NKI kernel."""
    citations = NKI_KERNEL_CITATIONS.get(kernel_name, [])
    if not citations:
        for key, cites in NKI_KERNEL_CITATIONS.items():
            if key in kernel_name.lower():
                return cites
    return citations


def format_citations_for_bundle_spec(
    citations: list[NKILeanCitation],
) -> list[dict[str, str]]:
    """Format citations for inclusion in NKI bundle spec."""
    return [
        {
            "lean_theorem": c.theorem_name,
            "lean_module": c.module_path,
            "claim": c.claim,
            "proof_status": c.proof_status,
        }
        for c in citations
    ]


__all__ = [
    "NKILeanCitation",
    "NKI_KERNEL_CITATIONS",
    "get_citations_for_kernel",
    "format_citations_for_bundle_spec",
]
