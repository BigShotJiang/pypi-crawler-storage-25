"""ATH-1099 Part C: NKI miter property labels.

Registers 5 kernel-specific invariant assertions for EBMC k-induction.
These extend the standard equivalence miter with NKI-specific properties.

Each label maps to a formal invariant that EBMC proves via k-induction:
- running_max_monotone: monotonicity of attention max tracking
- running_sum_nonneg: non-negativity of softmax denominator
- psum_no_uninit_read: PSUM read-after-write ordering
- causal_skip_holds: causal mask skip correctness
- kv_cache_append_only: cache write-pointer discipline
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class NKIMiterProperty:
    label: str
    kind: str  # ASSERT_ALWAYS | ASSERT_NEVER
    sv_assertion: str
    description: str


def generate_nki_miter_properties(
    kernel_name: str,
    *,
    clock_port: str = "clk",
    reset_port: str = "rst_n",
) -> list[NKIMiterProperty]:
    """Generate the 5 NKI kernel-specific miter assertions."""
    prefix = f"nki_{kernel_name}"
    reset_guard = f"!{reset_port}"

    return [
        NKIMiterProperty(
            label=f"{prefix}_running_max_monotone",
            kind="ASSERT_ALWAYS",
            sv_assertion=(
                f"  {prefix}_running_max_monotone: assert property "
                f"(@(posedge {clock_port}) disable iff ({reset_guard})\n"
                f"    running_max >= $past(running_max));"
            ),
            description="running_max(tile) >= running_max(tile-1)",
        ),
        NKIMiterProperty(
            label=f"{prefix}_running_sum_nonneg",
            kind="ASSERT_ALWAYS",
            sv_assertion=(
                f"  {prefix}_running_sum_nonneg: assert property "
                f"(@(posedge {clock_port}) disable iff ({reset_guard})\n"
                f"    $signed(running_sum) >= 0);"
            ),
            description="running_sum >= 0 everywhere",
        ),
        NKIMiterProperty(
            label=f"{prefix}_psum_no_uninit_read",
            kind="ASSERT_NEVER",
            sv_assertion=(
                f"  {prefix}_psum_no_uninit_read: assert property "
                f"(@(posedge {clock_port}) disable iff ({reset_guard})\n"
                f"    psum_rd_en |-> psum_written[$past(psum_rd_addr)]);"
            ),
            description="no PSUM read before corresponding write",
        ),
        NKIMiterProperty(
            label=f"{prefix}_causal_skip_holds",
            kind="ASSERT_ALWAYS",
            sv_assertion=(
                f"  {prefix}_causal_skip_holds: assert property "
                f"(@(posedge {clock_port}) disable iff ({reset_guard})\n"
                f"    (i_tile_kv > i_tile_q) |-> !nc_matmul_active);"
            ),
            description="causal mask: kv > q implies no matmul",
        ),
        NKIMiterProperty(
            label=f"{prefix}_kv_cache_append_only",
            kind="ASSERT_ALWAYS",
            sv_assertion=(
                f"  {prefix}_kv_cache_append_only: assert property "
                f"(@(posedge {clock_port}) disable iff ({reset_guard})\n"
                f"    cache_wr_en |-> (cache_wr_addr == cache_next_slot));"
            ),
            description="cache writes only at next-slot index",
        ),
    ]


def format_miter_properties_sv(properties: list[NKIMiterProperty]) -> str:
    """Format properties as SV assertion block for injection into miter."""
    lines = ["\n  // NKI kernel-specific formal invariants"]
    for p in properties:
        lines.append(f"  // {p.description}")
        lines.append(p.sv_assertion)
    return "\n".join(lines)


def get_property_labels(properties: list[NKIMiterProperty]) -> list[str]:
    """Extract just the labels for EBMC verdict matching."""
    return [p.label for p in properties]
