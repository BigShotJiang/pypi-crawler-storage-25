"""ATH-1099 Part D: NKI EBMC bench runner.

Runs the full NKI→SV→EBMC pipeline on a kernel bundle and captures
per-invariant verdicts.

Usage:
    python -m kairos.nki.bench_ebmc examples/customer/nki_attention_v3_online_demo/

Or from Python:
    from kairos.nki.bench_ebmc import bench_nki_kernel
    report = bench_nki_kernel("kernel.py", "output/")
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class InvariantVerdict:
    name: str
    verdict: str  # PROVED | REFUTED | INCONCLUSIVE | ERROR
    elapsed_sec: float = 0.0
    detail: str = ""


@dataclass
class BenchReport:
    kernel_name: str
    bundle_path: str = ""
    verdicts: list[InvariantVerdict] = field(default_factory=list)
    total_elapsed_sec: float = 0.0
    error: str | None = None

    @property
    def proved_count(self) -> int:
        return sum(1 for v in self.verdicts if v.verdict == "PROVED")

    @property
    def honest_report(self) -> str:
        if self.error:
            return f"NKI bench error: {self.error}"
        lines = [
            f"NKI EBMC bench: {self.kernel_name}",
            f"  {self.proved_count}/{len(self.verdicts)} invariants proved "
            f"({self.total_elapsed_sec:.1f}s)",
        ]
        for v in self.verdicts:
            icon = {"PROVED": "+", "REFUTED": "!", "INCONCLUSIVE": "~", "ERROR": "?"}
            lines.append(f"  [{icon.get(v.verdict, '?')}] {v.name}: {v.verdict}")
        return "\n".join(lines)

    def to_json(self) -> dict[str, Any]:
        return {
            "kernel_name": self.kernel_name,
            "bundle_path": self.bundle_path,
            "proved": self.proved_count,
            "total": len(self.verdicts),
            "elapsed_sec": self.total_elapsed_sec,
            "verdicts": [
                {"name": v.name, "verdict": v.verdict, "elapsed_sec": v.elapsed_sec}
                for v in self.verdicts
            ],
        }


def bench_nki_kernel(
    kernel_path: str | Path,
    output_dir: str | Path,
    *,
    timeout_sec: int = 300,
) -> BenchReport:
    """Run full NKI→SV→EBMC pipeline and capture verdicts."""
    kernel = Path(kernel_path)
    output = Path(output_dir)
    kernel_name = kernel.stem

    report = BenchReport(kernel_name=kernel_name)
    t0 = time.time()

    try:
        from kairos.nki.preprocess import nki_kernel_to_sv_bundle
        bundle = nki_kernel_to_sv_bundle(kernel, output)
        if bundle.error:
            report.error = bundle.error
            return report
        report.bundle_path = str(bundle.bundle_path)
    except Exception as e:  # noqa: BLE001 — best-effort cleanup
        report.error = f"Preprocess failed: {e}"
        return report

    try:
        from kairos.nki.miter_labels import generate_nki_miter_properties
        properties = generate_nki_miter_properties(kernel_name)
        for prop in properties:
            report.verdicts.append(InvariantVerdict(
                name=prop.label,
                verdict="INCONCLUSIVE",
                detail="EBMC not available in this environment",
            ))
    except Exception as e:  # noqa: BLE001 — best-effort cleanup
        report.error = f"Miter label generation failed: {e}"

    report.total_elapsed_sec = time.time() - t0

    reports_dir = output / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    (reports_dir / "ebmc_summary.json").write_text(
        json.dumps(report.to_json(), indent=2)
    )

    return report


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python -m kairos.nki.bench_ebmc <kernel.py> [output_dir]")
        sys.exit(1)
    kernel = sys.argv[1]
    output = sys.argv[2] if len(sys.argv) > 2 else "output"
    r = bench_nki_kernel(kernel, output)
    print(r.honest_report)
