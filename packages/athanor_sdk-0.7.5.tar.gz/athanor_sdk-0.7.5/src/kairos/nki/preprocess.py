"""ATH-1099 Part A: NKI kernel → SV bundle preprocessing.

Wires the NKI→SV transpiler into kairos.sec.preprocess so NKI
kernels can be EBMC-verified end-to-end via smoke_validate.

    bundle = nki_kernel_to_sv_bundle("kernel.py", "output/")
    # → output/inputs/kernel.v + output/signature.json
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from kairos.nki.ebmc_transpiler import transpile_nki_to_sv, TranspileResult


@dataclass
class NKIBundleResult:
    bundle_path: Path | None = None
    signature: dict[str, Any] | None = None
    sv_path: Path | None = None
    error: str | None = None


_NKI_INVARIANTS = [
    {
        "name": "running_max_monotone",
        "kind": "ASSERT_ALWAYS",
        "description": "running_max(tile) >= running_max(tile-1)",
    },
    {
        "name": "running_sum_nonneg",
        "kind": "ASSERT_ALWAYS",
        "description": "running_sum >= 0 everywhere",
    },
    {
        "name": "psum_no_uninit_read",
        "kind": "ASSERT_NEVER",
        "description": "no PSUM read before corresponding write",
    },
    {
        "name": "causal_skip_holds",
        "kind": "ASSERT_ALWAYS",
        "description": "i_tile_kv > i_tile_q implies no nc_matmul executed",
    },
    {
        "name": "kv_cache_append_only",
        "kind": "ASSERT_ALWAYS",
        "description": "cache writes only at next-slot index",
    },
]


def nki_kernel_to_sv_bundle(
    kernel_path: str | Path,
    output_dir: str | Path,
    *,
    partition_size: int = 128,
    fmax_moving: int = 512,
) -> NKIBundleResult:
    """Transpile NKI kernel to a kairos.sec-compatible bundle."""
    kernel = Path(kernel_path)
    output = Path(output_dir)

    if not kernel.is_file():
        return NKIBundleResult(error=f"Kernel not found: {kernel}")

    source = kernel.read_text()
    kernel_name = kernel.stem

    result = transpile_nki_to_sv(source, kernel_name=kernel_name)
    if result.error:
        return NKIBundleResult(error=f"Transpile failed: {result.error}")
    if not result.sv_text:
        return NKIBundleResult(error="Transpiler produced empty output")

    inputs_dir = output / "inputs"
    inputs_dir.mkdir(parents=True, exist_ok=True)

    sv_path = inputs_dir / f"{kernel_name}.v"
    sv_path.write_text(result.sv_text)

    signature = gen_signature_for_nki_bundle(
        kernel_name=kernel_name,
        module=result.module,
        partition_size=partition_size,
        fmax_moving=fmax_moving,
        properties=result.properties,
    )

    sig_path = output / "signature.json"
    sig_path.write_text(json.dumps(signature, indent=2))

    return NKIBundleResult(
        bundle_path=output,
        signature=signature,
        sv_path=sv_path,
    )


def gen_signature_for_nki_bundle(
    *,
    kernel_name: str,
    module: Any | None = None,
    partition_size: int = 128,
    fmax_moving: int = 512,
    properties: list[str] | None = None,
) -> dict[str, Any]:
    """Generate kairos.sec signature.json for an NKI bundle."""
    ports = []
    if module:
        for sig in module.signals:
            ports.append({
                "name": sig.name,
                "width": sig.width,
                "direction": sig.direction,
            })

    params = {
        "PARTITION_SIZE": partition_size,
        "FMAX_MOVING": fmax_moving,
    }
    if module:
        params.update(module.params)

    invariants = []
    for inv in _NKI_INVARIANTS:
        invariants.append({
            "name": inv["name"],
            "kind": inv["kind"],
            "description": inv["description"],
            "property_label": f"nki_{kernel_name}_{inv['name']}",
        })

    return {
        "gold_module": kernel_name,
        "gate_module": f"{kernel_name}_gate",
        "gold_sv": f"inputs/{kernel_name}.v",
        "ports": ports,
        "parameters": params,
        "dep_files": [],
        "formal_invariants_primer": invariants,
        "source_type": "nki",
        "concrete_for_sec": params,
    }
