"""ATH-1427: kairos repair --batch — parallel repair across files.

Runs kairos repair on multiple files in parallel, aggregates results,
reports honestly.

Usage:
    kairos repair --batch src/kairos/          # all .py files
    kairos repair --batch src/ --workers 4     # 4 parallel workers
    kairos repair --batch src/ --fix           # auto-apply fixes
"""
from __future__ import annotations

import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class BatchFileResult:
    file: str
    findings_count: int = 0
    fixes_applied: int = 0
    elapsed_sec: float = 0.0
    error: str | None = None


@dataclass
class BatchResult:
    files_checked: int = 0
    total_findings: int = 0
    total_fixes: int = 0
    elapsed_sec: float = 0.0
    file_results: list[BatchFileResult] = field(default_factory=list)

    @property
    def honest_report(self) -> str:
        lines = [
            f"Batch repair: {self.files_checked} files, "
            f"{self.total_findings} findings, "
            f"{self.total_fixes} fixes applied "
            f"({self.elapsed_sec:.1f}s)"
        ]
        for r in sorted(self.file_results, key=lambda x: -x.findings_count):
            if r.findings_count > 0:
                icon = "!" if r.findings_count > 0 else "+"
                lines.append(
                    f"  [{icon}] {r.file}: {r.findings_count} findings"
                    f"{f', {r.fixes_applied} fixed' if r.fixes_applied else ''}"
                )
            if r.error:
                lines.append(f"  [?] {r.file}: {r.error[:100]}")
        clean = sum(1 for r in self.file_results if r.findings_count == 0 and not r.error)
        if clean > 0:
            lines.append(f"  {clean} files clean (no findings)")
        return "\n".join(lines)


def _repair_one(file_path: Path, fix: bool = False) -> BatchFileResult:
    """Repair a single file and return result."""
    t0 = time.time()
    try:
        from kairos.repair import repair
        result = repair(str(file_path), fix=fix)
        findings = len(result.findings) if hasattr(result, "findings") else 0
        fixes = getattr(result, "fixes_applied", 0) or 0
        error = result.error if hasattr(result, "error") else None
        return BatchFileResult(
            file=str(file_path),
            findings_count=findings,
            fixes_applied=fixes,
            elapsed_sec=time.time() - t0,
            error=error,
        )
    except Exception as e:  # noqa: BLE001
        return BatchFileResult(
            file=str(file_path),
            error=str(e)[:200],
            elapsed_sec=time.time() - t0,
        )


def discover_files(
    target: str | Path,
    extensions: tuple[str, ...] = (".py", ".lean", ".rs"),
    exclude_patterns: tuple[str, ...] = ("__pycache__", ".git", "node_modules", ".venv"),
) -> list[Path]:
    """Discover files to repair."""
    target = Path(target)
    if target.is_file():
        return [target]
    files = []
    resolved_target = target.resolve()
    for ext in extensions:
        for f in sorted(target.rglob(f"*{ext}")):
            if any(p in str(f) for p in exclude_patterns):
                continue
            if f.is_symlink():
                if not f.resolve().is_relative_to(resolved_target):
                    continue
            if f.stat().st_size > 0:
                files.append(f)
    return files


def repair_batch(
    target: str | Path,
    *,
    fix: bool = False,
    max_workers: int = 4,
    extensions: tuple[str, ...] = (".py",),
) -> BatchResult:
    """Run repair on all matching files in parallel."""
    t0 = time.time()
    files = discover_files(target, extensions=extensions)

    result = BatchResult(files_checked=len(files))
    if not files:
        result.elapsed_sec = time.time() - t0
        return result

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futures = {
            pool.submit(_repair_one, f, fix): f
            for f in files
        }
        for future in as_completed(futures):
            file_result = future.result()
            result.file_results.append(file_result)
            result.total_findings += file_result.findings_count
            result.total_fixes += file_result.fixes_applied

    result.elapsed_sec = time.time() - t0
    return result
