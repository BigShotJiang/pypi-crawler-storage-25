"""kairos.signing — ECDSA-signed verdicts for cryptographic provenance.

ATH-853 (Q2 of the 2026-04-28 anti-cheat design review).

Pre-fix the SDK's 13-layer anti-cheat stack covered correctness
(banned constructs, axiom audit, vacuous-proof detection, spec
health gate) but had no cryptographic provenance — a customer who
got `proved=True, axiom_clean=True` from `kairos.lean.solve` had to
trust their local SDK installation. There was no way to prove to a
third party (auditor, regulator, paper reviewer) that the verdict
came from kairos.io's verification pipeline.

Post-fix the SDK calls `/api/v1/sign-verdict` after every
closed-and-clean result on paid-tier orgs. The platform endpoint
runs a final re-verify (lake build + axiom audit), and only signs
when the audit passes. The signature is ECDSA-P256-SHA256 over a
canonicalized JSON shape; the public keys are published at
``https://kairos.io/.well-known/signing-keys.json`` (RFC 7517 JWKS
format) so any third party can verify offline.

## Customer pattern

::

    result = kairos.lean.solve(target, drafters=[...])
    # result.signed_verdict is populated automatically when the
    # customer's org has signed_verdict_required flipped on.
    if result.signed_verdict is not None:
        print("kairos.io says proved-clean: signature OK")

    # Third party verifies independently (no kairos.io network access
    # needed after the first JWKS fetch caches):
    from kairos.signing import verify_signed_verdict
    assert verify_signed_verdict(result.signed_verdict)

## Multi-key rotation

Per platform agreement (#dev-platform 2026-04-28 ts=1777398484):

* Preflight returns the CURRENT-active ``key_id``
* JWKS publishes BOTH old + new keys during the rotation grace window
* ``/api/sync`` gate accepts any ``key_id`` present in the JWKS
* Customer's ``kairos verify`` looks up the embedded ``key_id`` in
  the bundled signed_verdict — no toolchain version check needed

## Privacy + opt-out

* Base SDK orgs: ``signed_verdict_required=false``, signing endpoint
  returns 204 → SDK doesn't populate ``result.signed_verdict``.
* ``KAIROS_NO_TRACE=1``: opts out of all observability including
  signing (preserves the ATH-707 contract).

## Cross-links

* ATH-853 (Q2 ticket — this module's home)
* ATH-854 (Q3 — bundles SignedVerdict into the certificate tarball)
* ATH-707 (KAIROS_NO_TRACE opt-out — Q2 inherits)
* 2026-04-28 anti-cheat review thread #dev-platform ts=1777398105.887289
"""
from __future__ import annotations

import base64
import json
import logging
import os
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, asdict
from typing import Any, Literal


_logger = logging.getLogger(__name__)


# ── Public dataclass ─────────────────────────────────────────────────


@dataclass(frozen=True)
class SignedVerdict:
    """Cryptographic attestation of a verdict from kairos.io.

    Attributes:
        verdict_json: Canonicalized JSON of the verdict shape that was
            signed (sorted keys, no whitespace, UTF-8). Verifiers
            re-canonicalize their copy of the verdict and check the
            byte-for-byte match before validating the signature.
        signature: Base64-encoded ECDSA-P256-SHA256 signature over
            ``verdict_json`` bytes. Standard DER encoding.
        kairos_key_id: Which key signed this verdict. Verifier
            looks up this ID in the JWKS to find the matching public
            key. Stable identifier; survives key rotation grace
            windows because old keys stay published.
        signed_at: ISO-8601 UTC timestamp from the signing server.
            For audit-trail use; does NOT affect signature validity.
        key_algorithm: Always ``"ECDSA-P256-SHA256"`` today; reserved
            for future algorithm migration.
    """
    verdict_json: str
    signature: str
    kairos_key_id: str
    signed_at: str
    key_algorithm: Literal["ECDSA-P256-SHA256"]

    def to_dict(self) -> dict[str, Any]:
        """Round-trippable JSON-friendly shape for embedding in a
        ProofCertificate bundle (Q3) or in the
        ``solve_runs.signed_verdict`` jsonb column."""
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> SignedVerdict:
        return cls(
            verdict_json=str(d["verdict_json"]),
            signature=str(d["signature"]),
            kairos_key_id=str(d["kairos_key_id"]),
            signed_at=str(d["signed_at"]),
            key_algorithm=str(d.get("key_algorithm", "ECDSA-P256-SHA256")),  # type: ignore[arg-type]
        )


# ── Canonicalization ─────────────────────────────────────────────────


def canonicalize_verdict(verdict: dict[str, Any]) -> str:
    """Stable JSON serialization for signature input.

    ECDSA signatures depend on the EXACT bytes signed. To survive
    network round-trips + dict-ordering quirks across Python
    versions, the SDK + the signing server BOTH canonicalize via:

    * Sorted keys at every depth (``sort_keys=True``)
    * No whitespace (``separators=(",", ":")``)
    * UTF-8 encoding
    * Ensure-ASCII off so unicode characters sign predictably

    Any change to this canonicalization needs a coordinated bump on
    both the SDK + the platform endpoint. Treat this like a
    cross-system contract.
    """
    return json.dumps(
        verdict,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


# ── JWKS fetch + cache ───────────────────────────────────────────────


_JWKS_CACHE: dict[str, dict[str, Any]] = {}
_JWKS_CACHE_LOCK = threading.Lock()
# JWKS responses are cached for 24h by default. Customers running
# `kairos verify` against an old certificate work offline after the
# first fetch.
_JWKS_CACHE_TTL_SECONDS = 24 * 3600
_JWKS_CACHE_TIMESTAMPS: dict[str, float] = {}


def _fetch_jwks(jwks_url: str) -> dict[str, Any]:
    """Fetch a JWKS document from ``jwks_url`` with TTL caching.

    Returns the parsed JSON. On HTTP error, returns the cached value
    if available (stale-while-error) — customers running offline get
    deterministic results once the cache is warm.
    """
    with _JWKS_CACHE_LOCK:
        cached = _JWKS_CACHE.get(jwks_url)
        cached_at = _JWKS_CACHE_TIMESTAMPS.get(jwks_url, 0.0)
        if (
            cached is not None
            and time.time() - cached_at < _JWKS_CACHE_TTL_SECONDS
        ):
            return cached
    try:
        with urllib.request.urlopen(jwks_url, timeout=10) as resp:
            data: dict[str, Any] = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as exc:
        if cached is not None:
            _logger.warning(
                "JWKS fetch failed (%s); using cached keys",
                exc,
            )
            return cached
        raise
    with _JWKS_CACHE_LOCK:
        _JWKS_CACHE[jwks_url] = data
        _JWKS_CACHE_TIMESTAMPS[jwks_url] = time.time()
    return data


def _resolve_public_key(
    jwks: dict[str, Any], key_id: str,
) -> Any:
    """Look up an EC public key by ``key_id`` in a JWKS document.

    Raises :exc:`KeyError` when the key isn't published — typically
    means the customer has a verdict signed with a key that was
    retired BEFORE the JWKS grace window included it (signature is
    valid; the verifier just can't find the public key). Customer
    should refresh their JWKS cache + retry.
    """

    for jwk in jwks.get("keys", []):
        if jwk.get("kid") == key_id:
            # JWK to PEM via cryptography's JWK loader.
            # Standard EC P-256 JWK shape: {kty: "EC", crv: "P-256",
            # x: <base64url-x>, y: <base64url-y>, kid: <key_id>}
            from cryptography.hazmat.primitives.asymmetric.ec import (  # type: ignore[import-not-found,import-untyped,unused-ignore]
                SECP256R1, EllipticCurvePublicNumbers,
            )

            def _b64u_to_int(s: str) -> int:
                # Add padding for base64url decoding.
                padded = s + "=" * (-len(s) % 4)
                return int.from_bytes(
                    base64.urlsafe_b64decode(padded), "big",
                )

            x = _b64u_to_int(jwk["x"])
            y = _b64u_to_int(jwk["y"])
            return EllipticCurvePublicNumbers(
                x=x, y=y, curve=SECP256R1(),
            ).public_key()
    raise KeyError(
        f"key_id {key_id!r} not found in JWKS — refresh JWKS cache "
        f"or check that the signing key wasn't retired before the "
        f"grace window included it"
    )


# ── Verify (offline-capable after first JWKS fetch) ──────────────────


def verify_signed_verdict(
    sv: SignedVerdict,
    *,
    jwks_url: str = "https://kairos.io/.well-known/signing-keys.json",
) -> bool:
    """Verify a SignedVerdict locally against the published JWKS.

    Returns ``True`` if the signature is valid for the embedded
    ``verdict_json`` bytes under the public key identified by
    ``kairos_key_id``. ``False`` for any signature mismatch.

    Network access to ``jwks_url`` is needed only on the FIRST call
    per process — JWKS responses are cached for 24h. Customer's
    ``kairos verify`` CLI works offline after the cache is warm.

    Raises:
        :exc:`KeyError`: when ``kairos_key_id`` isn't in the JWKS
            (key retired before grace window); customer should
            refresh cache.
        :exc:`urllib.error.URLError`: when the first JWKS fetch
            fails AND no cached version exists.
    """
    from cryptography.exceptions import InvalidSignature  # type: ignore[import-not-found,import-untyped,unused-ignore]
    from cryptography.hazmat.primitives import hashes  # type: ignore[import-not-found,import-untyped,unused-ignore]
    from cryptography.hazmat.primitives.asymmetric import ec  # type: ignore[import-not-found,import-untyped,unused-ignore]

    jwks = _fetch_jwks(jwks_url)
    public_key = _resolve_public_key(jwks, sv.kairos_key_id)

    # Decode the base64 signature.
    signature_bytes = base64.b64decode(sv.signature)

    try:
        public_key.verify(
            signature_bytes,
            sv.verdict_json.encode("utf-8"),
            ec.ECDSA(hashes.SHA256()),
        )
        return True
    except InvalidSignature:
        return False


# ── Server-side request (calls /api/v1/sign-verdict) ─────────────────


def request_signed_verdict(
    verdict: dict[str, Any],
    *,
    sign_verdict_url: str | None = None,
    proof_artifact: str | None = None,
    auth_token: str | None = None,
    timeout: int = 30,
) -> SignedVerdict:
    """Call ``/api/v1/sign-verdict`` and return the SignedVerdict.

    The platform endpoint runs a final re-verify (lake build +
    axiom audit) on the proof_artifact and only signs when the
    audit passes. SDK callers (``kairos.lean.solve`` /
    ``kairos.ebmc.solve`` / ``kairos.lean_cycle.cycle_prove``) call
    this automatically on closed-and-clean results when their org
    has ``signed_verdict_required=true``.

    Args:
        verdict: The structured verdict shape to sign. Will be
            canonicalized (sort_keys, no-whitespace) BEFORE being
            sent so the server signs the same bytes.
        sign_verdict_url: Override the endpoint URL. Defaults to the
            ``KAIROS_SIGN_VERDICT_URL`` env var, falling back to
            ``https://kairos.io/api/v1/sign-verdict``.
        proof_artifact: The Lean source / SystemVerilog spec the
            verdict is about. Server runs re-verify on this; required
            for paid-tier signing.
        auth_token: Override the auth bearer. Defaults to the
            ``ATHANOR_SYNC_TOKEN`` env var (same token used for
            ``/api/sync`` writes).
        timeout: Network timeout in seconds.

    Returns:
        A :class:`SignedVerdict` containing the signature + key_id +
        timestamp.

    Raises:
        :exc:`RuntimeError`: when the endpoint returns 4xx (verify
            failed, auth invalid, etc.) or 5xx (server error).
        :exc:`urllib.error.URLError`: on network failure.
    """
    url = (
        sign_verdict_url
        or os.environ.get("KAIROS_SIGN_VERDICT_URL")
        or "https://kairos.io/api/v1/sign-verdict"
    )
    token = (
        auth_token
        or os.environ.get("ATHANOR_SYNC_TOKEN")
        or os.environ.get("SUPABASE_SERVICE_ROLE_KEY")
    )

    payload = {
        "verdict_canonicalized": canonicalize_verdict(verdict),
        "proof_artifact": proof_artifact,
    }
    body = json.dumps(payload).encode("utf-8")

    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            response_body = resp.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        # Server returned 4xx/5xx. Read the error body for context.
        err_body = exc.read().decode("utf-8", errors="replace")[:500]
        raise RuntimeError(
            f"sign-verdict endpoint returned {exc.code}: {err_body}"
        ) from exc

    parsed = json.loads(response_body)
    return SignedVerdict.from_dict(parsed)


# ── Preflight (per-org capability probe) ─────────────────────────────


_PREFLIGHT_CACHE: dict[str, dict[str, Any]] = {}
_PREFLIGHT_CACHE_LOCK = threading.Lock()
_PREFLIGHT_CACHE_TTL_SECONDS = 60  # locked with platform 2026-04-28
_PREFLIGHT_CACHE_TIMESTAMPS: dict[str, float] = {}


def preflight_signing_capability(
    *,
    org_id: str,
    preflight_url: str | None = None,
    auth_token: str | None = None,
    timeout: int = 10,
) -> dict[str, Any]:
    """Probe ``/api/v1/sign-verdict/preflight`` for an org's signing posture.

    Returns ``{"required": bool, "key_id": str | None}``. Cached
    per-process for 60s per org_id (platform-locked TTL —
    #dev-platform 2026-04-28 ts=1777399641). Opens the per-process
    network door once per minute; the gate-decision is hot-path.

    The endpoint is intentionally cheap + unauthenticated (the org_id
    enumerates which keys are active, not whether requests succeed —
    actual signing requires the bearer + a valid proof_artifact).

    Returns ``{"required": False, "key_id": None}`` on any network
    failure — fail-open is the right default since signing is
    additive provenance, not a correctness gate.
    """
    with _PREFLIGHT_CACHE_LOCK:
        cached = _PREFLIGHT_CACHE.get(org_id)
        cached_at = _PREFLIGHT_CACHE_TIMESTAMPS.get(org_id, 0.0)
        if (
            cached is not None
            and time.time() - cached_at < _PREFLIGHT_CACHE_TTL_SECONDS
        ):
            return cached

    base = (
        preflight_url
        or os.environ.get("KAIROS_SIGN_VERDICT_PREFLIGHT_URL")
        or "https://kairos.io/api/v1/sign-verdict/preflight"
    )
    sep = "&" if "?" in base else "?"
    url = f"{base}{sep}org_id={org_id}"

    headers: dict[str, str] = {}
    token = auth_token or os.environ.get("ATHANOR_SYNC_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8"))
    except (urllib.error.URLError, json.JSONDecodeError) as exc:
        _logger.debug("preflight failed for org %s: %s", org_id, exc)
        result: dict[str, Any] = {"required": False, "key_id": None}
    else:
        result = {
            "required": bool(body.get("required", False)),
            "key_id": body.get("key_id"),
        }

    with _PREFLIGHT_CACHE_LOCK:
        _PREFLIGHT_CACHE[org_id] = result
        _PREFLIGHT_CACHE_TIMESTAMPS[org_id] = time.time()
    return result


def maybe_sign_verdict(
    verdict: dict[str, Any],
    *,
    proof_artifact: str | None = None,
) -> SignedVerdict | None:
    """Auto-attach a SignedVerdict when the caller's org requires it.

    Reads the org_id from ``KAIROS_ORG_ID`` (falling back to
    ``ATHANOR_ORG_ID``). Honors ``KAIROS_NO_TRACE=1`` per the
    ATH-707 opt-out contract — full local-only mode skips signing.

    Returns ``None`` (signing skipped) when:

    * ``KAIROS_NO_TRACE=1`` is set
    * No ``KAIROS_ORG_ID`` configured (dev-mode)
    * Preflight returns ``required=false``
    * Network failure (fail-open — provenance is additive, not a
      correctness gate)

    Best-effort: never raises. Wired into :func:`kairos.lean.verify_proof`
    on the closed-and-clean post-result path.
    """
    if os.environ.get("KAIROS_NO_TRACE") == "1":
        return None
    org_id = (
        os.environ.get("KAIROS_ORG_ID")
        or os.environ.get("ATHANOR_ORG_ID")
    )
    if not org_id:
        return None
    try:
        capability = preflight_signing_capability(org_id=org_id)
        if not capability.get("required"):
            return None
        return request_signed_verdict(verdict, proof_artifact=proof_artifact)
    except Exception as exc:  # noqa: BLE001 — logged + recovered; broad catch is intentional
        _logger.debug("signing skipped (best-effort): %s", exc)
        return None


# ── Test/debug helpers ───────────────────────────────────────────────


def _clear_jwks_cache() -> None:
    """Wipe the in-memory JWKS cache. Test fixture; do not use in
    production code."""
    with _JWKS_CACHE_LOCK:
        _JWKS_CACHE.clear()
        _JWKS_CACHE_TIMESTAMPS.clear()


def _clear_preflight_cache() -> None:
    """Wipe the in-memory preflight cache. Test fixture only."""
    with _PREFLIGHT_CACHE_LOCK:
        _PREFLIGHT_CACHE.clear()
        _PREFLIGHT_CACHE_TIMESTAMPS.clear()


__all__ = [
    "SignedVerdict",
    "canonicalize_verdict",
    "maybe_sign_verdict",
    "preflight_signing_capability",
    "request_signed_verdict",
    "verify_signed_verdict",
]
