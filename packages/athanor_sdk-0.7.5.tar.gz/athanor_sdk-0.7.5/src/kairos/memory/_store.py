"""kairos.memory -- persistent per-block memory for kiro agents.

Storage: ~/.kairos/memory/<block_name>.json  Thread-safe via atomic temp+rename.
"""

import fcntl, json, tempfile, time, warnings
from pathlib import Path
from typing import Any, Dict, List, Optional

_MEMORY_DIR: Path = Path.home() / ".kairos" / "memory"
# Fallback: if ~/.kairos is not writable (containers, read-only home),
# use /tmp/kairos-memory. Same pattern as trace sink fallback.
if not _MEMORY_DIR.parent.exists():
    try:
        _MEMORY_DIR.mkdir(parents=True, exist_ok=True)
    except OSError:
        _MEMORY_DIR = Path("/tmp/kairos-memory")


def _path_for(block: str) -> Path:
    return _MEMORY_DIR / f"{block}.json"


def _ensure_dir() -> bool:
    """Create memory dir. Returns False if not writable. Falls back to /tmp."""
    global _MEMORY_DIR
    try:
        _MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        return True
    except OSError:
        return False


def _read_entries(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        return []
    with open(path, "r") as f:
        fcntl.flock(f, fcntl.LOCK_SH)
        try:
            return json.load(f)
        except (json.JSONDecodeError, ValueError):
            return []
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)


def _write_entries(path: Path, entries: List[Dict[str, Any]]) -> None:
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with open(fd, "w") as f:
            json.dump(entries, f, indent=2)
        Path(tmp).replace(path)
    except Exception:
        Path(tmp).unlink(missing_ok=True)
        raise


def recall(block: str) -> Dict[str, Any]:
    """Return structured memory for a block, sorted by recency."""
    path = _path_for(block)
    entries = _read_entries(path)
    if not entries:
        return {"transforms_tried": [], "best_result": None, "failures": [], "notes": []}

    entries.sort(key=lambda e: e.get("timestamp", 0), reverse=True)

    transforms = []
    best_result: Optional[float] = None
    failures: List[Dict[str, Any]] = []
    notes: List[str] = []

    for e in entries:
        t = e.get("transform")
        if t and t not in transforms:
            transforms.append(t)
        delta = e.get("area_delta")
        if delta is not None and (best_result is None or delta < best_result):
            best_result = delta
        if e.get("outcome") == "failure":
            failures.append({"transform": t, "reason": e.get("reason", ""), "finding": e.get("finding", "")})
        if e.get("finding"):
            notes.append(e["finding"])

    return {
        "transforms_tried": transforms,
        "best_result": best_result,
        "failures": failures,
        "notes": notes,
        "history": entries,
    }


def store(
    block: str,
    finding: str,
    transform: Optional[str] = None,
    outcome: Optional[str] = None,
    area_delta: Optional[float] = None,
    reason: Optional[str] = None,
    **extra: Any,
) -> bool:
    """Append a finding to block memory. Returns True on success."""
    if not _ensure_dir():
        warnings.warn("kairos.memory: ~/.kairos is not writable; entry not saved", stacklevel=2)
        return False

    entry: Dict[str, Any] = {
        "timestamp": time.time(),
        "finding": finding,
    }
    if transform is not None:
        entry["transform"] = transform
    if outcome is not None:
        entry["outcome"] = outcome
    if area_delta is not None:
        entry["area_delta"] = area_delta
    if reason is not None:
        entry["reason"] = reason
    if extra:
        entry.update(extra)

    path = _path_for(block)
    entries = _read_entries(path)
    entries.append(entry)
    _write_entries(path, entries)
    return True


def forget(block: str, older_than_days: int = 90) -> int:
    """Remove entries older than N days. Returns count removed."""
    path = _path_for(block)
    entries = _read_entries(path)
    if not entries:
        return 0

    cutoff = time.time() - (older_than_days * 86400)
    kept = [e for e in entries if e.get("timestamp", 0) >= cutoff]
    removed = len(entries) - len(kept)

    if removed > 0:
        if kept:
            _write_entries(path, kept)
        else:
            path.unlink(missing_ok=True)

    return removed
