"""Wire kairos.memory into the optimize pipeline.

Two hooks for the orchestrator:
  - enrich_prompt_with_memory(): prepend past findings to proposer prompt
  - store_run_result(): persist what we learned after verification
"""
from __future__ import annotations


def enrich_prompt_with_memory(block_name: str, base_prompt: str) -> str:
    """Prepend memory context (past successes/failures) to the proposer prompt.

    Returns base_prompt unchanged if memory is empty or unavailable.
    """
    try:
        from kairos.memory import recall
    except ImportError:
        return base_prompt

    mem = recall(block_name)
    if not mem or not any(mem.get(k) for k in ("transforms_tried", "failures", "notes")):
        return base_prompt

    lines = [f"## Memory for block `{block_name}`\n"]
    if mem.get("failures"):
        lines.append("**Failed approaches (DO NOT repeat):**")
        for f in mem["failures"][:10]:
            lines.append(f"- `{f.get('transform', '?')}` -- {f.get('reason') or 'unknown'}")
        lines.append("")
    if mem.get("best_result") is not None:
        lines.append(f"**Best area delta so far:** {mem['best_result']:.4f}\n")
    if mem.get("notes"):
        lines.append("**Notes from previous runs:**")
        for note in mem["notes"][:5]:
            lines.append(f"- {note}")
        lines.append("")
    if not any(l.strip() for l in lines[1:]):
        return base_prompt
    return "\n".join(lines) + "\n---\n\n" + base_prompt


def store_run_result(
    block_name: str,
    transform: str,
    outcome: str,
    area_delta: float = 0.0,
    reason: str = "",
) -> None:
    """Store the result of an optimization run for future reference."""
    try:
        from kairos.memory import store
    except ImportError:
        return
    finding = f"{outcome}: {transform}"
    if reason:
        finding += f" ({reason})"
    store(
        block_name,
        finding=finding,
        transform=transform,
        outcome=outcome,
        area_delta=area_delta if area_delta else None,
        reason=reason or None,
    )
