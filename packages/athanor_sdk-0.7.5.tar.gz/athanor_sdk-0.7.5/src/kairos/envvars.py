"""kairos.envvars — dual-accept environment variable helpers (ATH-407 layer 4).

The athanor-sdk → kairos rename changes the brand but we don't want
customer CI scripts to break the day they upgrade. This module provides
a `getenv_dual(name, default)` helper that reads `KAIROS_<name>` first,
falls back to `ATHANOR_<name>` (emitting a one-time DeprecationWarning),
then returns `default`.

Migration path for customers:

1. **Today** (transition): customer sets `ATHANOR_BUILDER_ROOT=/opt/...`.
   SDK reads via `getenv_dual("BUILDER_ROOT")`, picks up the ATHANOR_*
   value, emits a one-time DeprecationWarning pointing at the KAIROS_*
   name.
2. **Customer migrates** (typically next maintenance window): sets
   `KAIROS_BUILDER_ROOT=/opt/...`, unsets ATHANOR_*.
3. **Future SDK release** (N+2 minor versions from now): drop the
   ATHANOR_* fallback per standard deprecation policy.

Deprecation warnings fire at most once per (canonical_name, process)
pair to avoid log spam in CI.

Does NOT touch env vars that were never brand-prefixed (e.g.,
OPENAI_API_KEY, GEMINI_API_KEY) — those stay as-is.
"""
from __future__ import annotations

import os
import warnings
from typing import Any

# Tracks which ATHANOR_* env vars have already emitted a warning in this
# process. Customer scripts typically read ~5-10 vars total.
_WARNED: set[str] = set()

_KAIROS_PREFIX = "KAIROS_"
_ATHANOR_PREFIX = "ATHANOR_"


def getenv_dual(
    name: str,
    default: str | None = None,
    *,
    kairos_prefix: str = _KAIROS_PREFIX,
    athanor_prefix: str = _ATHANOR_PREFIX,
) -> str | None:
    """Return the env var value, checking KAIROS_ first then ATHANOR_.

    Args:
        name: Canonical name without prefix (e.g., "BUILDER_ROOT").
            `getenv_dual("BUILDER_ROOT")` reads `KAIROS_BUILDER_ROOT`
            first, then `ATHANOR_BUILDER_ROOT`, then returns `default`.
        default: Returned when neither variant is set.
        kairos_prefix / athanor_prefix: overridable for tests; don't
            touch in normal use.

    Returns:
        First non-None value from `KAIROS_<name>` / `ATHANOR_<name>`,
        else `default`.

    Side effect: emits one DeprecationWarning per ATHANOR_<name>
    fallback per process.
    """
    kairos_value = os.environ.get(kairos_prefix + name)
    if kairos_value is not None:
        return kairos_value

    athanor_value = os.environ.get(athanor_prefix + name)
    if athanor_value is not None:
        canonical = kairos_prefix + name
        if canonical not in _WARNED:
            _WARNED.add(canonical)
            warnings.warn(
                f"Reading {athanor_prefix}{name} — the athanor-sdk rename "
                f"to kairos moves this env var to {canonical}. "
                f"{athanor_prefix}{name} will be removed in a future release. "
                f"Set {canonical} to silence this warning.",
                DeprecationWarning,
                stacklevel=2,
            )
        return athanor_value

    return default


def getenv_dual_bool(
    name: str,
    default: bool = False,
    **kwargs: Any,
) -> bool:
    """Dual-accept bool env var. Truthy values: '1', 'true', 'yes', 'on'."""
    raw = getenv_dual(name, default=None, **kwargs)
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def reset_warning_cache() -> None:
    """For tests — clear the one-warning-per-process cache."""
    _WARNED.clear()


__all__ = ["getenv_dual", "getenv_dual_bool", "reset_warning_cache"]
