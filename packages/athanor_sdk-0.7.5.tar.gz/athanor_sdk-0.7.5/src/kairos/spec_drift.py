"""ATH-1433: Lean/Verus spec-impl drift detection.

Detects when a Rust crate's implementation changes but its
Lean/Verus spec hasn't been updated, or vice versa.

Usage:
    kairos verify --drift          # check all crates
    kairos verify --drift crate/   # check specific crate

The drift check compares file modification times and content
hashes between impl (src/lib.rs) and specs (verus/*.rs, lean/*.lean).
"""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class DriftFinding:
    crate_name: str
    category: str  # impl_newer | spec_newer | spec_missing | impl_missing
    impl_path: str
    spec_path: str
    message: str
    severity: str = "high"


@dataclass
class DriftReport:
    crates_checked: int = 0
    crates_clean: int = 0
    findings: list[DriftFinding] = field(default_factory=list)

    @property
    def honest_report(self) -> str:
        if not self.findings:
            return f"No drift detected across {self.crates_checked} crates."
        lines = [
            f"Drift detected in {len(self.findings)} crate(s) "
            f"({self.crates_clean}/{self.crates_checked} clean):"
        ]
        for f in self.findings:
            lines.append(f"  [{f.severity}] {f.crate_name}: {f.message}")
        return "\n".join(lines)


def _content_hash(path: Path) -> str:
    """SHA256 prefix of file content — used to confirm mtime drift is real."""
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


def _newest_file(directory: Path, glob: str) -> Path | None:
    files = [(f.stat().st_mtime, f) for f in directory.glob(glob) if f.is_file()]
    return max(files, key=lambda x: x[0])[1] if files else None


def _newest_mtime(directory: Path, glob: str) -> float:
    mtimes = [f.stat().st_mtime for f in directory.glob(glob) if f.is_file()]
    return max(mtimes) if mtimes else 0.0


def check_crate_drift(crate_dir: Path) -> list[DriftFinding]:
    """Check a single crate for spec-impl drift."""
    findings = []
    crate_name = crate_dir.name

    impl_file = crate_dir / "src" / "lib.rs"
    verus_dir = crate_dir / "verus"
    lean_dir = crate_dir / "lean"

    has_impl = impl_file.is_file() and impl_file.stat().st_size > 50
    has_verus = verus_dir.is_dir() and any(verus_dir.glob("*.rs"))
    has_lean = lean_dir.is_dir() and any(lean_dir.glob("*.lean"))

    if has_impl and not has_verus and not has_lean:
        findings.append(DriftFinding(
            crate_name=crate_name,
            category="spec_missing",
            impl_path=str(impl_file),
            spec_path="",
            message="implementation exists but no Verus or Lean spec",
            severity="medium",
        ))
        return findings

    if not has_impl and (has_verus or has_lean):
        findings.append(DriftFinding(
            crate_name=crate_name,
            category="impl_missing",
            impl_path="",
            spec_path=str(verus_dir if has_verus else lean_dir),
            message="spec exists but no implementation (stub crate)",
        ))
        return findings

    if not has_impl:
        return findings

    impl_mtime = impl_file.stat().st_mtime

    if has_verus:
        verus_mtime = _newest_mtime(verus_dir, "*.rs")
        if impl_mtime > verus_mtime + 86400:
            findings.append(DriftFinding(
                crate_name=crate_name,
                category="impl_newer",
                impl_path=str(impl_file),
                spec_path=str(verus_dir),
                message=(
                    f"impl modified after Verus spec "
                    f"(impl: {_fmt_age(impl_mtime)}, "
                    f"spec: {_fmt_age(verus_mtime)})"
                ),
            ))
        elif verus_mtime > impl_mtime + 86400:
            findings.append(DriftFinding(
                crate_name=crate_name,
                category="spec_newer",
                impl_path=str(impl_file),
                spec_path=str(verus_dir),
                message=(
                    f"Verus spec modified after impl "
                    f"(spec: {_fmt_age(verus_mtime)}, "
                    f"impl: {_fmt_age(impl_mtime)})"
                ),
                severity="medium",
            ))

    if has_lean:
        lean_mtime = _newest_mtime(lean_dir, "*.lean")
        if impl_mtime > lean_mtime + 86400:
            findings.append(DriftFinding(
                crate_name=crate_name,
                category="impl_newer",
                impl_path=str(impl_file),
                spec_path=str(lean_dir),
                message=(
                    f"impl modified after Lean spec "
                    f"(impl: {_fmt_age(impl_mtime)}, "
                    f"spec: {_fmt_age(lean_mtime)})"
                ),
            ))
        elif lean_mtime > impl_mtime + 86400:
            findings.append(DriftFinding(
                crate_name=crate_name,
                category="spec_newer",
                impl_path=str(impl_file),
                spec_path=str(lean_dir),
                message=(
                    f"Lean spec modified after impl "
                    f"(spec: {_fmt_age(lean_mtime)}, "
                    f"impl: {_fmt_age(impl_mtime)})"
                ),
                severity="medium",
            ))

    return findings


def _fmt_age(mtime: float) -> str:
    import time
    age = time.time() - mtime
    if age < 3600:
        return f"{age/60:.0f}m ago"
    if age < 86400:
        return f"{age/3600:.0f}h ago"
    return f"{age/86400:.0f}d ago"


def check_all_crates(crates_dir: Path) -> DriftReport:
    """Check all crates in a directory for spec-impl drift."""
    report = DriftReport()
    if not crates_dir.is_dir():
        return report

    for crate_dir in sorted(crates_dir.iterdir()):
        if not crate_dir.is_dir() or crate_dir.name.startswith("."):
            continue
        report.crates_checked += 1
        findings = check_crate_drift(crate_dir)
        if findings:
            report.findings.extend(findings)
        else:
            report.crates_clean += 1

    return report


def check_lean_specs_drift(specs_dir: Path, crates_dir: Path) -> list[DriftFinding]:
    """Check if Lean hardware specs are stale relative to Rust implementations.

    Lean specs in specs/lean/hardware/ should be updated when the
    corresponding Rust crate changes significantly.
    """
    findings = []
    if not specs_dir.is_dir() or not crates_dir.is_dir():
        return findings

    specs_mtime = _newest_mtime(specs_dir, "*.lean")

    for crate_dir in sorted(crates_dir.iterdir()):
        if not crate_dir.is_dir():
            continue
        impl_file = crate_dir / "src" / "lib.rs"
        if not impl_file.is_file():
            continue
        impl_mtime = impl_file.stat().st_mtime
        if impl_mtime > specs_mtime + 86400 * 7:
            findings.append(DriftFinding(
                crate_name=crate_dir.name,
                category="impl_newer",
                impl_path=str(impl_file),
                spec_path=str(specs_dir),
                message=(
                    f"impl modified >7 days after Lean specs last updated "
                    f"(impl: {_fmt_age(impl_mtime)}, "
                    f"specs: {_fmt_age(specs_mtime)})"
                ),
                severity="medium",
            ))

    return findings
