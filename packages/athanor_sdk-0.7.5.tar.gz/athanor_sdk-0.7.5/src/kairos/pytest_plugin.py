"""kairos.pytest_plugin — opt-in pytest plugins for the SDK test suite.

ATH-585 Subtask 3: ``no_journal`` gate. Fails a pytest session if the
SDK trace journal (``~/.kairos/failed_events.jsonl`` or the path at
``KAIROS_FAILED_EVENTS_JOURNAL``) contains any entries at session end.

Zero-data-loss rationale: non-empty journal means at least one event
was emitted by the SDK but never made it to Supabase. In prod that
indicates a real outage the operator needs to investigate via
``kairos trace replay``. In CI it's a smoke-test failure — tests
shouldn't leak trace writes to a real journal.

Intentional-failure tests (e.g. journal-drain replay coverage) tag
their emitted rows with ``"test_sentinel": true`` inside the body or
the surrounding entry so the gate skips them.

How to enable in your suite
---------------------------

Add to ``conftest.py``::

    pytest_plugins = ["kairos.pytest_plugin"]

Or per-test-run via ``-p kairos.pytest_plugin``.

Opt-out (don't enable for a local dev run that already has legitimate
journal entries pending replay)::

    KAIROS_SKIP_JOURNAL_GATE=1 pytest ...
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from collections.abc import Iterator
from typing import Any


_DEFAULT_JOURNAL = Path.home() / ".kairos" / "failed_events.jsonl"


def _journal_path() -> Path:
    """Resolve the journal path — env var wins, default otherwise."""
    override = os.environ.get("KAIROS_FAILED_EVENTS_JOURNAL", "").strip()
    return Path(override) if override else _DEFAULT_JOURNAL


def _iter_nonempty_lines(path: Path) -> Iterator[str]:
    """Yield non-empty lines from ``path``. Missing path → empty iter."""
    if not path.exists():
        return
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            stripped = line.strip()
            if stripped:
                yield stripped


def _is_sentinel(raw_line: str) -> bool:
    """True if ``raw_line`` parses to a journal entry that carries the
    ``test_sentinel: true`` marker — either at the top-level entry or
    nested inside its ``body``.

    Malformed lines are NOT treated as sentinels (they're legitimate
    drift we want to surface).
    """
    try:
        obj = json.loads(raw_line)
    except (ValueError, TypeError):
        return False
    if isinstance(obj, dict):
        if obj.get("test_sentinel") is True:
            return True
        body = obj.get("body")
        if isinstance(body, dict) and body.get("test_sentinel") is True:
            return True
    return False


def pytest_sessionfinish(session: Any, exitstatus: int) -> None:
    """ATH-585: fail the session if the journal has unexpected entries.

    Runs at the END of the test session (after all teardowns). Checks
    the journal file + fails the run with a pointer to `kairos trace
    replay` so the operator can drain. Sentinel-tagged entries are
    skipped so intentional-failure tests don't trigger the gate.

    The gate does not modify ``exitstatus`` when it fires — pytest
    already handles that — but it does print a clear reason to stdout
    + sets ``session.exitstatus = 1`` so CI picks up the failure.
    """
    if os.environ.get("KAIROS_SKIP_JOURNAL_GATE", "").strip():
        return

    path = _journal_path()
    live_entries: list[str] = []
    sentinel_count = 0
    for line in _iter_nonempty_lines(path):
        if _is_sentinel(line):
            sentinel_count += 1
        else:
            live_entries.append(line)

    if not live_entries:
        return

    # Non-empty with real entries → fail.
    preview = "\n".join(f"    {e[:200]}" for e in live_entries[:5])
    reporter = getattr(session.config, "pluginmanager", None)
    terminal = None
    if reporter is not None:
        terminal = reporter.get_plugin("terminalreporter")
    msg = (
        f"\n{'=' * 70}\n"
        f"ATH-585 JOURNAL GATE FAILURE\n"
        f"{'=' * 70}\n"
        f"Non-empty SDK trace journal at session end: {path}\n"
        f"  live entries     = {len(live_entries)}\n"
        f"  sentinel entries = {sentinel_count}\n"
        f"\n"
        f"First {min(5, len(live_entries))} entries:\n{preview}\n"
        f"\n"
        f"This means at least one event emitted by the SDK during the test\n"
        f"suite never reached Supabase. In CI this is a bug — drain the\n"
        f"journal + investigate via `kairos trace replay --help`.\n"
        f"\n"
        f"To suppress this gate for a known-pending local dev session:\n"
        f"  KAIROS_SKIP_JOURNAL_GATE=1 pytest ...\n"
        f"{'=' * 70}\n"
    )
    if terminal is not None:
        terminal.write_line(msg, red=True)
    else:  # pragma: no cover - fallback when terminalreporter unavailable
        print(msg)

    # Force non-zero exit so CI catches it even if all tests otherwise passed.
    session.exitstatus = 1
