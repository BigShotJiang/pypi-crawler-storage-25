"""ATH-1139: chip-level design space exploration.

Explore the Pareto frontier of area/timing/power across multiple
optimization strategies for a chip-level design.

Usage:
    kairos explore chip.sv --objectives area,timing,power
    kairos explore chip.sv --sweep FIFO_DEPTH=4,8,16 --sweep DATA_WIDTH=8,16,32

The explorer:
1. Discovers optimizable blocks in the design
2. Generates design points (parameter sweeps + optimization variants)
3. Evaluates each point (synthesize + measure)
4. Computes the Pareto frontier
5. Reports the efficient set with honest tradeoffs
"""
from __future__ import annotations

import itertools
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class DesignPoint:
    id: int
    params: dict[str, int]
    area: float | None = None
    timing_wns: float | None = None
    power: float | None = None
    verified: bool = False
    optimization: str = "baseline"

    @property
    def measured(self) -> bool:
        return self.area is not None


@dataclass
class ExplorationResult:
    design_points: list[DesignPoint] = field(default_factory=list)
    pareto_frontier: list[int] = field(default_factory=list)
    total_elapsed_sec: float = 0.0
    error: str | None = None

    @property
    def honest_report(self) -> str:
        if self.error:
            return f"Exploration failed: {self.error}"
        measured = sum(1 for dp in self.design_points if dp.measured)
        return (
            f"Explored {len(self.design_points)} design points, "
            f"{measured} measured, "
            f"{len(self.pareto_frontier)} on Pareto frontier"
        )


def generate_sweep(
    param_ranges: dict[str, list[int]],
) -> list[dict[str, int]]:
    """Generate all parameter combinations from sweep ranges."""
    if not param_ranges:
        return [{}]
    keys = sorted(param_ranges.keys())
    values = [param_ranges[k] for k in keys]
    return [
        dict(zip(keys, combo))
        for combo in itertools.product(*values)
    ]


def dominates(a: DesignPoint, b: DesignPoint) -> bool:
    """True if a dominates b on all measured objectives."""
    if a.area is None or b.area is None:
        return False
    a_vals = [a.area]
    b_vals = [b.area]
    if a.timing_wns is not None and b.timing_wns is not None:
        a_vals.append(-a.timing_wns)
        b_vals.append(-b.timing_wns)
    if a.power is not None and b.power is not None:
        a_vals.append(a.power)
        b_vals.append(b.power)
    return (
        all(av <= bv for av, bv in zip(a_vals, b_vals))
        and any(av < bv for av, bv in zip(a_vals, b_vals))
    )


def compute_pareto(points: list[DesignPoint]) -> list[int]:
    """Compute Pareto-optimal design points."""
    measured = [p for p in points if p.measured]
    frontier = []
    for i, p in enumerate(measured):
        is_dominated = any(
            dominates(other, p)
            for j, other in enumerate(measured) if i != j
        )
        if not is_dominated:
            frontier.append(p.id)
    return frontier


def explore(
    rtl_path: str | Path,
    *,
    param_ranges: dict[str, list[int]] | None = None,
    optimizations: list[str] | None = None,
    dry_run: bool = False,
) -> ExplorationResult:
    """Explore the design space for an RTL block."""
    path = Path(rtl_path)
    result = ExplorationResult()

    if not path.is_file():
        result.error = f"File not found: {path}"
        return result

    sweeps = generate_sweep(param_ranges or {})
    opt_strategies = optimizations or ["baseline", "structural", "impl_swap"]

    point_id = 0
    for params in sweeps:
        for opt in opt_strategies:
            dp = DesignPoint(
                id=point_id,
                params=params,
                optimization=opt,
            )
            result.design_points.append(dp)
            point_id += 1

    if dry_run:
        return result

    for dp in result.design_points:
        try:
            dp.area = _measure_area(path, dp.params)
        except Exception:  # noqa: BLE001
            pass

    result.pareto_frontier = compute_pareto(result.design_points)
    return result


def _measure_area(rtl_path: Path, params: dict[str, int]) -> float | None:
    """Measure area via yosys synthesis."""
    from kairos.sec.closed_loop.measurement import measure_synthesis
    from kairos.sec.closed_loop.optimize_cli import auto_extract_module_name

    text = rtl_path.read_text()
    module = auto_extract_module_name(text)
    if not module:
        return None

    cells = measure_synthesis(rtl_path, module)
    return float(cells) if cells else None
