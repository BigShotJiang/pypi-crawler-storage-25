"""athanor bootstrap — persistent VM state for BYOC customer setup (ATH-122).

Subcommands:
    athanor bootstrap               Interactive first-run setup
    athanor bootstrap set KEY=V ... Non-interactive env-file update
    athanor bootstrap refresh-ghcr  Re-fetch + docker login GHCR token
    athanor bootstrap start         Install + start systemd user service
    athanor bootstrap stop          Stop systemd user service
    athanor bootstrap status        Show service status
    athanor bootstrap reset         Wipe env file + service + logs

Env file: ~/.athanor-env  (plaintext KEY=value, mode 0600, by default)
          Use --encrypted to write a Fernet-encrypted file instead.
          NOTE: systemd EnvironmentFile= requires plaintext; --encrypted is
          incompatible with `athanor bootstrap start`.
Salt:     ~/.athanor/.salt  (only used in --encrypted mode)
Logs:     ~/.athanor/logs/runner.log
Unit:     ~/.config/systemd/user/athanor-runner.service
"""

import getpass
import json
import os

from kairos.envvars import getenv_dual
from kairos.security.env_allowlist import safe_env_for_eval_bash_host
import shutil
import subprocess
import sys
import urllib.request
import urllib.error
from pathlib import Path

from kairos import __version__ as _VERSION

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

ATHANOR_DIR = Path.home() / ".athanor"
ENV_FILE = Path.home() / ".athanor-env"
SALT_FILE = ATHANOR_DIR / ".salt"
LOG_DIR = ATHANOR_DIR / "logs"
LOG_FILE = LOG_DIR / "runner.log"
SYSTEMD_UNIT_DIR = Path.home() / ".config" / "systemd" / "user"
SYSTEMD_UNIT_FILE = SYSTEMD_UNIT_DIR / "athanor-runner.service"
UNIT_NAME = "athanor-runner"
BASHRC_SENTINEL = "# athanor-sdk bootstrap — sourced env file"
SOURCE_LINE = "[ -f ~/.athanor-env ] && . ~/.athanor-env"

SYSTEMD_UNIT_TEMPLATE = """\
[Unit]
Description=Athanor self-hosted runner
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart={athanor_bin} run --token ${{ATHANOR_TOKEN}}
Restart=always
RestartSec=10
EnvironmentFile={env_file}
StandardOutput=append:{log_file}
StandardError=append:{log_file}

[Install]
WantedBy=default.target
"""

# ---------------------------------------------------------------------------
# Encryption helpers
# ---------------------------------------------------------------------------

def _derive_key(passphrase: str, salt: bytes) -> bytes:
    """Derive a Fernet key from passphrase + salt via PBKDF2."""
    import base64
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes

    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=480000,
    )
    raw = kdf.derive(passphrase.encode())
    return base64.urlsafe_b64encode(raw)


def _get_or_create_salt() -> bytes:
    ATHANOR_DIR.mkdir(parents=True, exist_ok=True)
    if SALT_FILE.exists():
        return SALT_FILE.read_bytes()
    salt = os.urandom(16)
    SALT_FILE.write_bytes(salt)
    SALT_FILE.chmod(0o600)
    return salt


def _encrypt_env(env: dict, passphrase: str) -> bytes:
    """Encrypt env dict as KEY=VALUE lines using Fernet."""
    from cryptography.fernet import Fernet

    salt = _get_or_create_salt()
    key = _derive_key(passphrase, salt)
    f = Fernet(key)
    plaintext = _env_to_text(env).encode()
    return f.encrypt(plaintext)


def _decrypt_env(ciphertext: bytes, passphrase: str) -> dict:
    """Decrypt Fernet ciphertext back to env dict."""
    from cryptography.fernet import Fernet, InvalidToken

    salt = _get_or_create_salt()
    key = _derive_key(passphrase, salt)
    f = Fernet(key)
    try:
        plaintext = f.decrypt(ciphertext).decode()
    except InvalidToken:
        raise RuntimeError("Wrong passphrase or corrupted env file.")
    return _text_to_env(plaintext)


def _env_to_text(env: dict) -> str:
    lines = []
    for k, v in env.items():
        # Escape double-quotes in values
        escaped = v.replace("\\", "\\\\").replace('"', '\\"')
        lines.append(f'{k}="{escaped}"')
    return "\n".join(lines) + "\n"


def _text_to_env(text: str) -> dict:
    env = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            continue
        k, _, v = line.partition("=")
        k = k.strip()
        v = v.strip()
        # Strip surrounding quotes and unescape
        if (v.startswith('"') and v.endswith('"')):
            v = v[1:-1].replace('\\"', '"').replace("\\\\", "\\")
        elif (v.startswith("'") and v.endswith("'")):
            v = v[1:-1]
        env[k] = v
    return env


# ---------------------------------------------------------------------------
# Env file read / write
# ---------------------------------------------------------------------------

def _read_env_file(passphrase: str | None = None, plaintext: bool = False) -> dict:
    """Read and return the env dict from ~/.athanor-env.

    Returns empty dict if file doesn't exist.
    """
    if not ENV_FILE.exists():
        return {}
    data = ENV_FILE.read_bytes()
    if plaintext:
        return _text_to_env(data.decode())
    if passphrase is None:
        raise RuntimeError("Passphrase required to read encrypted env file.")
    return _decrypt_env(data, passphrase)


def _write_env_file(env: dict, passphrase: str | None = None, plaintext: bool = False):
    """Write env dict to ~/.athanor-env."""
    ATHANOR_DIR.mkdir(parents=True, exist_ok=True)
    if plaintext:
        content = _env_to_text(env).encode()
    else:
        if passphrase is None:
            raise RuntimeError("Passphrase required to write encrypted env file.")
        content = _encrypt_env(env, passphrase)
    ENV_FILE.write_bytes(content)
    ENV_FILE.chmod(0o600)


def _get_passphrase(confirm: bool = False, passphrase_env: str | None = None) -> str:
    """Prompt for passphrase. Reads ATHANOR_PASSPHRASE env var if set (for tests)."""
    if passphrase_env:
        return passphrase_env
    env_val = getenv_dual("PASSPHRASE")
    if env_val:
        return env_val
    pw = getpass.getpass("Encryption passphrase: ")
    if confirm:
        pw2 = getpass.getpass("Confirm passphrase: ")
        if pw != pw2:
            print("Error: passphrases do not match.", file=sys.stderr)
            sys.exit(1)
    return pw


# ---------------------------------------------------------------------------
# Shell RC injection
# ---------------------------------------------------------------------------

def _inject_shell_rc(rc_path: Path):
    """Idempotently append source line to shell rc file."""
    if not rc_path.exists():
        return
    text = rc_path.read_text()
    if BASHRC_SENTINEL in text:
        return  # already injected
    addition = f"\n{BASHRC_SENTINEL}\n{SOURCE_LINE}\n"
    with rc_path.open("a") as f:
        f.write(addition)
    print(f"  Updated {rc_path}")


def _inject_shell_rcs():
    _inject_shell_rc(Path.home() / ".bashrc")
    _inject_shell_rc(Path.home() / ".zshrc")


# ---------------------------------------------------------------------------
# GHCR token refresh (ATH-152)
# ---------------------------------------------------------------------------

def _refresh_ghcr(token: str, platform_url: str, ghcr_username: str):
    """Fetch GHCR token from platform and run docker login."""
    url = f"{platform_url.rstrip('/')}/api/runner/ghcr-token"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "User-Agent": f"athanor-cli/{_VERSION}",
        },
        method="GET",
    )
    try:
        resp = urllib.request.urlopen(req, timeout=30)
        data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode() if e.fp else ""
        raise RuntimeError(f"Failed to fetch GHCR token: HTTP {e.code} — {body[:200]}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Cannot reach platform at {platform_url}: {e.reason}")

    ghcr_token = data.get("token")
    registry = data.get("registry", "ghcr.io")
    username = data.get("username") or ghcr_username

    if not ghcr_token:
        raise RuntimeError(
            "Platform did not return a registry credential. "
            "Re-run with a fresh token."
        )

    docker_bin = shutil.which("docker") or shutil.which("podman")
    if not docker_bin:
        raise RuntimeError("Docker or Podman not found.")

    result = subprocess.run(
        [docker_bin, "login", registry, "-u", username, "--password-stdin"],
        input=ghcr_token.encode(),
        capture_output=True,
        env=safe_env_for_eval_bash_host(),
        timeout=60,
    )
    if result.returncode != 0:
        raise RuntimeError(f"docker login failed: {result.stderr.decode()[:200]}")
    print(f"  docker login {registry} succeeded")


# ---------------------------------------------------------------------------
# Ciphertext detection
# ---------------------------------------------------------------------------

def _is_encrypted_env_file(path: Path | None = None) -> bool:
    """Return True if the env file looks like Fernet ciphertext.

    Fernet tokens are base64url-encoded and always start with the bytes that
    decode from ``gAAAAA`` — i.e. the ASCII text of the file begins with
    ``gAAAAA``.  We check for that prefix rather than trying to base64-decode
    the whole file, so detection is O(1) and never raises.
    """
    p = path or ENV_FILE
    if not p.exists():
        return False
    try:
        header = p.read_bytes()[:6]
    except OSError:
        return False
    return header == b"gAAAAA"


# ---------------------------------------------------------------------------
# systemd helpers (Linux only)
# ---------------------------------------------------------------------------

def _is_linux() -> bool:
    return sys.platform.startswith("linux")


def _render_unit() -> str:
    athanor_bin = shutil.which("athanor") or "athanor"
    return SYSTEMD_UNIT_TEMPLATE.format(
        athanor_bin=athanor_bin,
        env_file=str(ENV_FILE),
        log_file=str(LOG_FILE),
    )


def _install_unit():
    SYSTEMD_UNIT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    SYSTEMD_UNIT_FILE.write_text(_render_unit())
    print(f"  Installed: {SYSTEMD_UNIT_FILE}")

    # Enable linger so service survives SSH disconnect
    user = getpass.getuser()
    subprocess.run(["loginctl", "enable-linger", user], check=True, env=safe_env_for_eval_bash_host(), timeout=60)

    subprocess.run(["systemctl", "--user", "daemon-reload"], check=True, env=safe_env_for_eval_bash_host(), timeout=60)
    subprocess.run(["systemctl", "--user", "enable", "--now", UNIT_NAME], check=True, env=safe_env_for_eval_bash_host(), timeout=60)


def _start_service():
    subprocess.run(["systemctl", "--user", "start", UNIT_NAME], check=True, env=safe_env_for_eval_bash_host(), timeout=60)
    print(f"  Started {UNIT_NAME}")


def _stop_service():
    subprocess.run(["systemctl", "--user", "stop", UNIT_NAME], check=False, env=safe_env_for_eval_bash_host(), timeout=60)
    print(f"  Stopped {UNIT_NAME}")


def _service_status():
    result = subprocess.run(
        ["systemctl", "--user", "status", UNIT_NAME],
        capture_output=False,
        env=safe_env_for_eval_bash_host(),
        timeout=60,
    )
    return result.returncode == 0


# ---------------------------------------------------------------------------
# Subcommand implementations
# ---------------------------------------------------------------------------

def cmd_bootstrap(args):
    """Interactive first-run setup."""
    encrypted = getattr(args, "encrypted", False)
    # plaintext flag is the legacy opt-in; for backwards compat it still works.
    # New default: plaintext=True unless --encrypted is specified.
    legacy_plaintext = getattr(args, "plaintext", False)
    plaintext = (not encrypted) or legacy_plaintext
    platform = getattr(args, "platform", "https://tahoe.athanor-ai.com")

    print("Athanor bootstrap — persistent VM setup")
    print()

    if plaintext and _is_linux():
        print(
            "Using plaintext ~/.athanor-env (0600) for systemd compatibility. "
            "Use --encrypted to force encrypted mode "
            "(incompatible with `athanor bootstrap start`)."
        )

    # Determine passphrase for encrypted mode
    passphrase = None
    existing_env = {}
    if not plaintext:
        if ENV_FILE.exists():
            if _is_encrypted_env_file():
                print("Existing encrypted env file found. Enter passphrase to update it.")
            else:
                print("Existing plaintext env file found. Converting to encrypted.")
            passphrase = _get_passphrase(confirm=False)
            try:
                existing_env = _read_env_file(passphrase=passphrase)
            except RuntimeError as e:
                # May be plaintext file being converted — try reading as plaintext
                try:
                    existing_env = _read_env_file(plaintext=True)
                except Exception:  # noqa: BLE001 — stderr-warned + recovered
                    print(f"Error: {e}", file=sys.stderr)
                    sys.exit(1)
        else:
            print("Creating new encrypted env file. Choose a passphrase.")
            passphrase = _get_passphrase(confirm=True)
    else:
        if ENV_FILE.exists():
            if _is_encrypted_env_file():
                print(
                    "  Note: existing ~/.athanor-env is encrypted. "
                    "Re-running bootstrap will overwrite it with a plaintext file. "
                    "To keep encrypted mode, use --encrypted."
                )
            existing_env = _read_env_file(plaintext=True) if not _is_encrypted_env_file() else {}

    def prompt(key: str, prompt_text: str, secret: bool = False, default: str = "") -> str:
        current = existing_env.get(key, default)
        display_current = ""
        if current:
            if secret:
                display_current = f" [current: {'*' * 8}]"
            else:
                display_current = f" [current: {current}]"
        full_prompt = f"  {prompt_text}{display_current}: "
        if secret:
            val = getpass.getpass(full_prompt)
        else:
            val = input(full_prompt)
        return val.strip() or current

    env = dict(existing_env)

    print("\n-- Required --")
    env["ATHANOR_TOKEN"] = prompt("ATHANOR_TOKEN", "ATHANOR_TOKEN", secret=True)
    env["ANTHROPIC_API_KEY"] = prompt("ANTHROPIC_API_KEY", "ANTHROPIC_API_KEY", secret=True)
    env["ANTHROPIC_BASE_URL"] = prompt(
        "ANTHROPIC_BASE_URL", "ANTHROPIC_BASE_URL",
        default="https://api.anthropic.com"
    )
    env["GHCR_USERNAME"] = prompt("GHCR_USERNAME", "GHCR_USERNAME (for docker login)")

    print("\n-- Optional model keys (press Enter to skip) --")
    for key, label in [
        ("OPENAI_API_KEY", "OPENAI_API_KEY"),
        ("MISTRAL_API_KEY", "MISTRAL_API_KEY"),
    ]:
        val = prompt(key, label, secret=True)
        if val:
            env[key] = val
        elif key in env and not val:
            # keep existing if user pressed enter with existing value (handled above)
            pass

    # Gemini: litellm reads GEMINI_API_KEY; some Google client libs read GOOGLE_API_KEY.
    # Prompt once and write both so all callers are covered (ATH-196).
    gemini_val = prompt(
        "GEMINI_API_KEY",
        "Gemini (GEMINI_API_KEY / GOOGLE_API_KEY)",
        secret=True,
    )
    if gemini_val:
        env["GEMINI_API_KEY"] = gemini_val
        env["GOOGLE_API_KEY"] = gemini_val
    elif "GEMINI_API_KEY" in env and not gemini_val:
        pass

    # Remove empty values
    env = {k: v for k, v in env.items() if v}

    _write_env_file(env, passphrase=passphrase, plaintext=plaintext)
    print(f"\n  Saved: {ENV_FILE}")

    # Inject shell rcs
    print("\n-- Shell RC --")
    _inject_shell_rcs()

    # Auto-refresh GHCR on bootstrap
    print("\n-- GHCR login --")
    try:
        _refresh_ghcr(
            token=env.get("ATHANOR_TOKEN", ""),
            platform_url=platform,
            ghcr_username=env.get("GHCR_USERNAME", "athanor-ai"),
        )
    except RuntimeError as e:
        print(f"  Warning: GHCR login failed: {e}")
        print("  Run `athanor bootstrap refresh-ghcr` later to retry.")

    print("\nBootstrap complete.")
    print("  Run `athanor bootstrap start` to install the systemd runner service.")
    print(f"  Source your shell or run: . {ENV_FILE}")


def cmd_bootstrap_set(args):
    """Non-interactive update: athanor bootstrap set KEY=V [KEY=V ...]"""
    plaintext = getattr(args, "plaintext", False)

    if not args.pairs:
        print("Usage: athanor bootstrap set KEY=VALUE [KEY=VALUE ...]", file=sys.stderr)
        sys.exit(1)

    passphrase = None
    if not plaintext:
        if not ENV_FILE.exists():
            print("No env file found. Run `athanor bootstrap` first, or use --plaintext.", file=sys.stderr)
            sys.exit(1)
        passphrase = _get_passphrase()
    try:
        existing_env = _read_env_file(passphrase=passphrase, plaintext=plaintext)
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    for pair in args.pairs:
        if "=" not in pair:
            print(f"Error: invalid KEY=VALUE pair: {pair!r}", file=sys.stderr)
            sys.exit(1)
        k, _, v = pair.partition("=")
        existing_env[k.strip()] = v.strip()

    _write_env_file(existing_env, passphrase=passphrase, plaintext=plaintext)
    print(f"Updated {ENV_FILE} ({len(args.pairs)} key(s))")


def cmd_bootstrap_refresh_ghcr(args):
    """Re-fetch GHCR token and docker login."""
    plaintext = getattr(args, "plaintext", False)
    platform = getattr(args, "platform", "https://tahoe.athanor-ai.com")

    passphrase = None
    if not plaintext and ENV_FILE.exists():
        passphrase = _get_passphrase()
    try:
        env = _read_env_file(passphrase=passphrase, plaintext=plaintext)
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    token = env.get("ATHANOR_TOKEN") or getenv_dual("TOKEN")
    ghcr_username = env.get("GHCR_USERNAME", "athanor-ai")

    if not token:
        print("Error: ATHANOR_TOKEN not found in env file or environment.", file=sys.stderr)
        sys.exit(1)

    try:
        _refresh_ghcr(token=token, platform_url=platform, ghcr_username=ghcr_username)
    except RuntimeError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_bootstrap_start(args):
    """Install + start systemd user service."""
    if not _is_linux():
        print("macOS launchd support coming in v1.1.")
        return

    if not ENV_FILE.exists():
        print("Error: run `athanor bootstrap` first to create the env file.", file=sys.stderr)
        sys.exit(1)

    if _is_encrypted_env_file():
        print(
            "Error: ~/.athanor-env is encrypted and cannot be read by systemd.\n"
            "Run 'athanor bootstrap' (the current default writes a plaintext file) "
            "to replace it, or run 'athanor bootstrap --encrypted' only if you do "
            "not intend to use the systemd runner.\n"
            "Migration: run `athanor bootstrap` — it will warn that an encrypted "
            "file exists and overwrite it with a plaintext 0600 file.",
            file=sys.stderr,
        )
        sys.exit(1)

    try:
        _install_unit()
        print(f"Runner service started. Logs: {LOG_FILE}")
        print("  Run `athanor bootstrap status` to check.")
    except subprocess.CalledProcessError as e:
        print(f"Error: systemd command failed: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_bootstrap_stop(args):
    """Stop systemd user service."""
    if not _is_linux():
        print("macOS launchd support coming in v1.1.")
        return
    _stop_service()


def cmd_bootstrap_status(args):
    """Show service status."""
    if not _is_linux():
        print("macOS launchd support coming in v1.1.")
        return
    _service_status()


def cmd_bootstrap_reset(args):
    """Wipe env file + service + logs."""
    if not _is_linux():
        # Still wipe file + logs on non-Linux
        pass
    else:
        # Stop + disable + remove unit
        try:
            subprocess.run(["systemctl", "--user", "stop", UNIT_NAME], check=False, env=safe_env_for_eval_bash_host(), timeout=60)
            subprocess.run(["systemctl", "--user", "disable", UNIT_NAME], check=False, env=safe_env_for_eval_bash_host(), timeout=60)
        except FileNotFoundError:
            pass  # systemctl not available
        if SYSTEMD_UNIT_FILE.exists():
            SYSTEMD_UNIT_FILE.unlink()
            print(f"  Removed: {SYSTEMD_UNIT_FILE}")
        try:
            subprocess.run(["systemctl", "--user", "daemon-reload"], check=False, env=safe_env_for_eval_bash_host(), timeout=60)
        except FileNotFoundError:
            pass

    if ENV_FILE.exists():
        ENV_FILE.unlink()
        print(f"  Removed: {ENV_FILE}")

    if SALT_FILE.exists():
        SALT_FILE.unlink()
        print(f"  Removed: {SALT_FILE}")

    if LOG_DIR.exists():
        shutil.rmtree(LOG_DIR)
        print(f"  Removed: {LOG_DIR}")

    print("Reset complete. Run `athanor bootstrap` to start fresh.")
