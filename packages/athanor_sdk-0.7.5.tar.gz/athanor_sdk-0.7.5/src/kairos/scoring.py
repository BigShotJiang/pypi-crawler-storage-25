"""ATH-382 Cython shim for the scoring module.

Real implementation in `_scoring_impl.pyx`, compiled to
`_scoring_impl.cpython-*-x86_64-linux-gnu.so`. This shim re-exports
the public surface so existing callers (`env.py`, tests, customer
code) don't need to change imports.

See `docs/ath-382-cython-design.md` for the end-to-end rationale.

Build: `python3 build_cython.py` at the repo root.
"""
from __future__ import annotations

try:
    from kairos._scoring_impl import (  # type: ignore[import-not-found]
        _find_docker,
        score,
    )
except (ImportError, OSError):
    # Pure-Python fallback: works without Cython/.so/gcc.
    # The .pyx is pure Python (shutil + subprocess) so the fallback is
    # functionally identical, just not Cython-compiled.
    import json as _json
    import shutil as _shutil
    import subprocess as _subprocess
    from pathlib import Path as _Path

    from kairos.types import ScoreResult as _ScoreResult

    def _find_docker() -> str:
        for name in ("docker", "podman"):
            path = _shutil.which(name)
            if path:
                return path
        raise FileNotFoundError(
            "Neither docker nor podman found on PATH. "
            "Install Docker: https://docs.docker.com/get-docker/"
        )

    def score(
        image: str,
        task_id: str,
        workdir: "_Path",
        *,
        timeout: int = 300,
        memory: str = "4g",
        pids_limit: int = 256,
    ) -> "_ScoreResult":
        docker_bin = _find_docker()
        data_dir = _Path(workdir) / "data"
        shared_dir = _Path(workdir) / "shared"
        cmd = [
            docker_bin, "run", "--rm", "--user", "root",
            "--network=none", f"--memory={memory}",
            f"--pids-limit={pids_limit}", "--cap-drop=ALL",
            "-v", f"{data_dir}:/workdir/data",
        ]
        if shared_dir.is_dir():
            cmd += ["-v", f"{shared_dir}:/workdir/shared:ro"]
        cmd += [
            image, "bash", "-c",
            f"/root/.venv/bin/python /root_data/eval/scoring.py "
            f"/root_data/eval/configs/{task_id}.json /tmp/score.json "
            f">/dev/null 2>&1; cat /tmp/score.json",
        ]
        result = _subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        stdout = result.stdout.strip()
        if not stdout:
            return _ScoreResult(score=0.0, metadata={"error": f"Container produced no output (exit {result.returncode})"})
        try:
            data = _json.loads(stdout)
        except _json.JSONDecodeError:
            return _ScoreResult(score=0.0, metadata={"error": f"Invalid JSON from container: {stdout[:200]}"})
        return _ScoreResult(score=data.get("score", 0.0), metadata=data.get("metadata", {}))


__all__ = ["score", "_find_docker"]
