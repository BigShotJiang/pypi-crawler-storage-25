"""Local config persistence for kairos.

Houses two responsibilities:

1. **Deployment mode** (ATH-388): `local` vs `platform`. Whether
   traces + run summaries POST to tahoe.athanor-ai.com (platform) or
   stay under `~/.athanor/runs/<id>/` (local, air-gapped).

2. **Bedrock-key persistence** (ATH-1199): customer enters their AWS
   Bedrock API key once via `kairos config set bedrock-key <key>`; the
   value lives in `~/.athanor/config.json` (chmod 600) and is read as
   a fallback when neither `ProviderConfig(api_key=...)` nor the
   `AWS_ACCESS_KEY_ID` env triad is set, for any `bedrock/*` model.

Storage: `~/.athanor/config.json`. One file, chmod 600 on every write
(both via this module and from CLI). Mode reads tolerate looser perms
(0644 is fine for a non-secret field); bedrock-key reads warn but
don't error.
"""
from __future__ import annotations

import json
import os
import stat

from kairos.envvars import getenv_dual
from pathlib import Path


MODE_LOCAL = "local"
MODE_PLATFORM = "platform"
_VALID_MODES = frozenset({MODE_LOCAL, MODE_PLATFORM})

_CONFIG_DIR_MODE = 0o700
_CONFIG_FILE_MODE = 0o600
_BEDROCK_KEY_FIELD = "bedrock_key"


def _config_path() -> Path:
    """Resolve config path lazily so tests can monkeypatch `Path.home()`."""
    return Path.home() / ".athanor" / "config.json"


def _load_config_dict() -> dict[str, object]:
    """Read the full config dict, or `{}` if file missing / malformed.

    Tolerant by design: a corrupt config file shouldn't bring down
    `kairos run` or `kairos solve`. The caller decides whether a
    missing key is an error.
    """
    path = _config_path()
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}
    return data if isinstance(data, dict) else {}


def _save_config_dict(cfg: dict[str, object]) -> None:
    """Write the config dict with chmod 600. Creates parent dir if needed.

    Atomic via write-then-rename to avoid a partial-write window in
    which the file exists but holds an invalid value (e.g., another
    process / shell tab reads mid-write).
    """
    path = _config_path()
    path.parent.mkdir(mode=_CONFIG_DIR_MODE, parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(cfg, indent=2) + "\n")
    os.chmod(tmp, _CONFIG_FILE_MODE)
    tmp.replace(path)
    # Belt-and-suspenders: some filesystems (NFS, certain FUSE mounts)
    # don't carry the source-file mode through `replace()`. Re-chmod on
    # the destination guarantees 0o600 lands even there. per CTO
    # 2026-05-14 customer-eye review on PR #649.
    os.chmod(path, _CONFIG_FILE_MODE)


def _read_config_mode() -> str | None:
    """Read `mode` from `~/.athanor/config.json` if present."""
    data = _load_config_dict()
    mode = data.get("mode")
    if isinstance(mode, str) and mode in _VALID_MODES:
        return mode
    return None


def current_mode() -> str:
    """Resolve the SDK deployment mode. Defaults to `"platform"`."""
    env_mode = (getenv_dual("MODE", "") or "").strip().lower()
    if env_mode in _VALID_MODES:
        return env_mode
    config_mode = _read_config_mode()
    if config_mode is not None:
        return config_mode
    return MODE_PLATFORM


def is_local_mode() -> bool:
    """True iff the SDK is configured to skip all platform uploads."""
    return current_mode() == MODE_LOCAL


# ============================================================
# Bedrock-key persistence (ATH-1199)
# ============================================================


def set_bedrock_key(key: str) -> None:
    """Persist a Bedrock API key to `~/.athanor/config.json` with chmod 600.

    Empty / whitespace-only keys raise ValueError — silent acceptance
    of a blank key would later present as a confusing "auth failed"
    error from litellm with no useful breadcrumb back to the CLI.
    """
    stripped = (key or "").strip()
    if not stripped:
        raise ValueError("bedrock-key cannot be empty")
    cfg = _load_config_dict()
    cfg[_BEDROCK_KEY_FIELD] = stripped
    _save_config_dict(cfg)


def unset_bedrock_key() -> bool:
    """Remove the persisted Bedrock key. Returns True iff a key was removed."""
    cfg = _load_config_dict()
    if _BEDROCK_KEY_FIELD not in cfg:
        return False
    del cfg[_BEDROCK_KEY_FIELD]
    _save_config_dict(cfg)
    return True


def get_bedrock_key() -> str | None:
    """Read the persisted Bedrock key, or None if unset.

    SECURITY: callers must not echo the returned value to logs / Slack /
    error messages. Use `bedrock_key_fingerprint()` for display.
    """
    value = _load_config_dict().get(_BEDROCK_KEY_FIELD)
    return value if isinstance(value, str) and value else None


def bedrock_key_fingerprint() -> str | None:
    """Display-safe fingerprint of the persisted Bedrock key.

    Returns the last 4 characters prefixed with `****`, or None if
    unset. Mirrors `model_client.base._mask_key` shape so doctor output
    and CLI output stay visually consistent.
    """
    key = get_bedrock_key()
    if not key:
        return None
    if len(key) <= 4:
        return "****"
    return "****" + key[-4:]


# Resolution-source labels. Tests and doctor pin against these strings;
# keep stable.
BEDROCK_SOURCE_EXPLICIT = "explicit"  # ProviderConfig(api_key=...) caller-supplied
BEDROCK_SOURCE_ENV = "env"            # AWS_ACCESS_KEY_ID triad in os.environ
BEDROCK_SOURCE_CONFIG = "config"      # ~/.athanor/config.json fallback
BEDROCK_SOURCE_UNSET = "unset"        # none of the above


def resolve_bedrock_source(
    *,
    explicit_api_key: str | None = None,
    environ: dict[str, str] | None = None,
) -> str:
    """Identify which auth source `bedrock/*` calls will resolve to.

    Resolution order matches the spec (ATH-1199 §Spec.5):
      1. caller-supplied ProviderConfig.api_key
      2. AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY env vars
      3. ~/.athanor/config.json fallback (this module's persisted key)
      4. unset

    Reports labels only; never returns the key itself. Use this for
    `kairos doctor` and for the CLI `config get bedrock-key` source-of-
    truth display. The `environ` arg defaults to `os.environ`; tests
    pass an explicit dict.
    """
    if explicit_api_key:
        return BEDROCK_SOURCE_EXPLICIT
    env = environ if environ is not None else os.environ
    if env.get("AWS_ACCESS_KEY_ID") and env.get("AWS_SECRET_ACCESS_KEY"):
        return BEDROCK_SOURCE_ENV
    if get_bedrock_key():
        return BEDROCK_SOURCE_CONFIG
    return BEDROCK_SOURCE_UNSET


def file_permissions_ok() -> bool:
    """True if the config file exists with mode 0o600 (no group/other access).

    Doctor uses this to warn on looser permissions. Returns True if the
    file doesn't exist (no perms to be wrong about); only a present
    file with bad perms returns False.
    """
    path = _config_path()
    if not path.is_file():
        return True
    mode = stat.S_IMODE(path.stat().st_mode)
    return mode == _CONFIG_FILE_MODE


# ============================================================
# S3 trace bucket persistence (ATH-1200)
# ============================================================

_S3_BUCKET_FIELD = "s3_trace_bucket"
_S3_REGION_FIELD = "s3_trace_region"


def _is_valid_s3_bucket_name(name: str) -> bool:
    """AWS S3 bucket name rules (subset enforced — covers customer typos).

    AWS spec at https://docs.aws.amazon.com/AmazonS3/latest/userguide/bucketnamingrules.html.
    We enforce: 3-63 chars; lowercase alphanumeric + hyphens + dots
    only; no consecutive dots; no leading/trailing hyphen-or-dot. Skips
    the IP-address-shape reservation rule (false-positive prone, the
    real validation lives behind boto3 in phase 2).
    """
    if not (3 <= len(name) <= 63):
        return False
    if name != name.lower():
        return False
    if not all(c.isalnum() or c in "-." for c in name):
        return False
    if not (name[0].isalnum() and name[-1].isalnum()):
        return False
    if ".." in name:
        return False
    return True


def set_s3_trace_bucket(bucket: str, region: str | None = None) -> None:
    """Persist the S3 trace-upload bucket (+ optional region) to config.

    Validation: bucket name must match AWS S3 naming rules (see
    `_is_valid_s3_bucket_name`); region is non-empty + lowercased.
    Empty bucket raises ValueError.
    """
    bucket_stripped = (bucket or "").strip()
    if not bucket_stripped:
        raise ValueError("s3 bucket cannot be empty")
    if not _is_valid_s3_bucket_name(bucket_stripped):
        raise ValueError(
            f"invalid S3 bucket name: {bucket_stripped!r}. Must be 3-63 "
            "chars, lowercase alphanumeric + hyphens + dots, no consecutive "
            "dots, no leading/trailing hyphen-or-dot."
        )
    cfg = _load_config_dict()
    cfg[_S3_BUCKET_FIELD] = bucket_stripped
    if region is not None:
        region_stripped = region.strip().lower()
        if not region_stripped:
            raise ValueError("s3 region cannot be empty if supplied")
        cfg[_S3_REGION_FIELD] = region_stripped
    _save_config_dict(cfg)


def unset_s3_trace_bucket() -> bool:
    """Remove persisted S3 bucket + region. Returns True iff anything removed."""
    cfg = _load_config_dict()
    had_field = _S3_BUCKET_FIELD in cfg or _S3_REGION_FIELD in cfg
    cfg.pop(_S3_BUCKET_FIELD, None)
    cfg.pop(_S3_REGION_FIELD, None)
    if had_field:
        _save_config_dict(cfg)
    return had_field


def get_s3_trace_bucket() -> dict[str, str | None] | None:
    """Read the persisted S3 trace config, or None if no bucket set.

    Returns `{"bucket": str, "region": str | None}` when configured.
    """
    cfg = _load_config_dict()
    bucket = cfg.get(_S3_BUCKET_FIELD)
    if not isinstance(bucket, str) or not bucket:
        return None
    region = cfg.get(_S3_REGION_FIELD)
    return {
        "bucket": bucket,
        "region": region if isinstance(region, str) and region else None,
    }


# ============================================================
# Postgres run-history conn string persistence (ATH-1201)
# ============================================================

_DB_URL_FIELD = "db_url"


def _validate_postgres_conn_string(conn: str) -> None:
    """Validate Postgres conn-string shape; raise ValueError on malformed.

    Accepts `postgres://` or `postgresql://` schemes with host (or unix
    socket path). Doesn't validate password content; doesn't check
    the server is reachable (that's verify-time, not persist-time).

    SECURITY: any conn-string fragment included in the raised
    ``ValueError`` message MUST be run through
    :func:`_redact_password_in_url` first. The validator runs on
    customer-typed input; a typo on the scheme (e.g.
    ``mysq://user:secret@host/db``) would otherwise leak the password
    to stderr / logs / CI build output via the caller's
    ``print(f"error: {e}")``. ATH-1242 strike (2).
    """
    if not conn or not conn.strip():
        raise ValueError("db conn string cannot be empty")
    stripped = conn.strip()
    if not (stripped.startswith("postgres://") or stripped.startswith("postgresql://")):
        # Redact BEFORE slicing — a urlparse-able value with a password
        # gets `user:****@host`; an unparseable one (the more common
        # case for a typo'd scheme) returns the literal "****" so we
        # never include the raw input.
        redacted = _redact_password_in_url(stripped)
        raise ValueError(
            f"invalid Postgres conn string: must start with "
            f"'postgres://' or 'postgresql://' (got: {redacted[:32]!r}...)"
        )
    from urllib.parse import urlparse
    parsed = urlparse(stripped)
    if not parsed.netloc and not parsed.path:
        raise ValueError(
            "invalid Postgres conn string: missing host (or unix socket path)"
        )


class InsecureTLSRefused(ValueError):
    """Raised when a customer-supplied DSN sets ``sslmode=disable`` (or
    a permissive variant) without an explicit ``allow_insecure_tls=True``
    opt-in. ATH-1242 strike (1): the original ATH-1201 implementation
    silently respected ``sslmode=disable``, contradicting the
    documented "SSL auto-enforced" invariant. This subclass of
    ValueError keeps the existing ``except ValueError`` paths in
    ``cmd_config`` working while letting callers distinguish the
    security-class error from a malformed-shape error.
    """


# sslmode values that downgrade or skip TLS verification. The
# permissive end (disable / allow / prefer) doesn't require server
# TLS; `prefer` is technically a downgrade-on-failure which is also
# unsafe for credential-bearing connections.
_PERMISSIVE_SSLMODES = frozenset({"disable", "allow", "prefer"})


def _extract_sslmode(conn: str) -> str | None:
    """Return the customer-supplied sslmode value, lowercase, or None
    if not present. Case-insensitive on the param name (Postgres accepts
    SSLMODE / sslmode / SslMode interchangeably)."""
    from urllib.parse import urlparse, parse_qs
    try:
        parsed = urlparse(conn)
    except ValueError:
        return None
    qs = parse_qs(parsed.query, keep_blank_values=True)
    for k, v in qs.items():
        if k.lower() == "sslmode" and v:
            return v[0].strip().lower()
    return None


def normalize_db_url(
    conn: str, *, allow_insecure_tls: bool = False
) -> str:
    """Return the canonical form of a Postgres conn-string WITHOUT
    persisting it. Used by the CLI to compute the would-be-stored DSN
    so verify_conn runs against the canonical form BEFORE persistence,
    closing the ATH-1242 strike (4) persist-before-verify gap.

    Runs the same shape validation + sslmode-refuse logic as
    :func:`set_db_url` but skips the config write. A caller that
    receives a successful return value can safely persist via
    ``set_db_url(conn, allow_insecure_tls=allow_insecure_tls)`` and
    expect the identical canonical form back.

    :raises ValueError: malformed conn-string shape (subclass-safe;
        callers can still ``except ValueError``).
    :raises InsecureTLSRefused: customer-supplied permissive sslmode
        without ``allow_insecure_tls=True`` opt-in.
    """
    stripped = (conn or "").strip()
    _validate_postgres_conn_string(stripped)
    sslmode_supplied = _extract_sslmode(stripped)
    if sslmode_supplied in _PERMISSIVE_SSLMODES and not allow_insecure_tls:
        raise InsecureTLSRefused(
            f"refused: customer-supplied sslmode={sslmode_supplied!r} "
            f"downgrades TLS for a credential-bearing connection. "
            "Athanor enforces sslmode=require by default. If your "
            "Postgres host genuinely cannot serve TLS (rare; local "
            "dev DB on loopback only), re-run with --allow-insecure-tls "
            "to acknowledge the risk. Production DSNs MUST use "
            "sslmode=require or stronger (verify-ca / verify-full)."
        )
    if "sslmode=" not in stripped:
        sep = "&" if "?" in stripped else "?"
        stripped = f"{stripped}{sep}sslmode=require"
    return stripped


def set_db_url(conn: str, *, allow_insecure_tls: bool = False) -> None:
    """Persist a Postgres connection string to the config file.

    The conn string is stored verbatim. Display surfaces use
    `db_url_redacted()`; the password is never echoed.

    SSL is enforced by default by appending `sslmode=require` if no
    `sslmode=` query param is already present.

    :param allow_insecure_tls: Customer-explicit opt-in to a permissive
        sslmode (``disable`` / ``allow`` / ``prefer``). ATH-1242
        strike (1): the pre-ATH-1242 implementation silently respected
        ``sslmode=disable`` — a security regression against the
        documented invariant. With this kwarg False (default), a
        permissive sslmode raises :class:`InsecureTLSRefused`. Pass
        ``True`` only when the caller has explicitly surfaced the
        opt-in to the customer (e.g. a ``--allow-insecure-tls`` CLI
        flag at the wizard / config command layer).
    """
    # Single chokepoint for shape + sslmode + canonicalization. Both
    # set_db_url and the CLI's pre-verify path go through this.
    stripped = normalize_db_url(conn, allow_insecure_tls=allow_insecure_tls)
    cfg = _load_config_dict()
    cfg[_DB_URL_FIELD] = stripped
    _save_config_dict(cfg)


def unset_db_url() -> bool:
    """Remove the persisted DB url. Returns True iff a value was removed."""
    cfg = _load_config_dict()
    if _DB_URL_FIELD not in cfg:
        return False
    del cfg[_DB_URL_FIELD]
    _save_config_dict(cfg)
    return True


def get_db_url() -> str | None:
    """Read the persisted DB conn string verbatim.

    SECURITY: callers MUST NOT echo the return value to logs/Slack/
    errors. The password is in plaintext. Use `db_url_redacted()`
    for display.
    """
    value = _load_config_dict().get(_DB_URL_FIELD)
    return value if isinstance(value, str) and value else None


def db_url_redacted() -> str | None:
    """Display-safe form of the persisted DB url.

    Replaces the password component with `****`. Returns None when no
    DB url is persisted.

    Example:
        postgresql://user:secret@host:5432/db
            -> postgresql://user:****@host:5432/db
    """
    url = get_db_url()
    if not url:
        return None
    return _redact_password_in_url(url)


def _redact_password_in_url(url: str) -> str:
    """Substitute the password component + credential query-params with `****`.

    ATH-1262: extended to scrub query-param credentials like ?password=...,
    ?api_key=..., ?secret=..., ?token=... in addition to the netloc password.
    """
    from urllib.parse import urlparse, urlunparse, quote, parse_qs, urlencode
    try:
        parsed = urlparse(url)
    except ValueError:
        return "****"

    # Scrub netloc password
    new_netloc = parsed.netloc
    if parsed.password is not None:
        user = parsed.username or ""
        host = parsed.hostname or ""
        port = f":{parsed.port}" if parsed.port else ""
        new_netloc = f"{quote(user)}:****@{host}{port}"

    # ATH-1262: scrub credential query-params
    sensitive_keys = {"password", "passwd", "api_key", "apikey", "secret",
                      "token", "access_token", "auth", "key", "credential"}
    query = parsed.query
    if query:
        params = parse_qs(query, keep_blank_values=True)
        redacted = False
        for k in list(params.keys()):
            if k.lower() in sensitive_keys:
                params[k] = ["****"]
                redacted = True
        if redacted:
            query = urlencode(params, doseq=True)

    if parsed.password is None and query == parsed.query:
        return url

    return urlunparse((
        parsed.scheme,
        new_netloc,
        parsed.path,
        parsed.params,
        query,
        parsed.fragment,
    ))


def db_url_engine_label(version_string: str | None) -> str:
    """Best-effort engine identification from a Postgres `version()` return.

    Aurora Postgres: 'PostgreSQL 14.9 ... Aurora Postgres'
    RDS Postgres:    'PostgreSQL 15.2 ... (RDS ...)'
    Plain Postgres:  'PostgreSQL 16.0 on x86_64-pc-linux-gnu ...'

    Returns: `aurora` / `rds` / `postgres` / `unknown`. Lowercase stable
    labels; doctor + tests pin against these.
    """
    if not version_string:
        return "unknown"
    s = version_string.lower()
    if "aurora" in s:
        return "aurora"
    if "rds" in s:
        return "rds"
    if "postgresql" in s or "postgres" in s:
        return "postgres"
    return "unknown"


__all__ = [
    "MODE_LOCAL",
    "MODE_PLATFORM",
    "current_mode",
    "is_local_mode",
    "set_bedrock_key",
    "unset_bedrock_key",
    "get_bedrock_key",
    "bedrock_key_fingerprint",
    "resolve_bedrock_source",
    "file_permissions_ok",
    "BEDROCK_SOURCE_EXPLICIT",
    "BEDROCK_SOURCE_ENV",
    "BEDROCK_SOURCE_CONFIG",
    "BEDROCK_SOURCE_UNSET",
    "set_s3_trace_bucket",
    "unset_s3_trace_bucket",
    "get_s3_trace_bucket",
    "set_db_url",
    "unset_db_url",
    "InsecureTLSRefused",
    "get_db_url",
    "db_url_redacted",
    "db_url_engine_label",
]
