"""ATH-1464 C1: Pythia integration with smart gating + signature cache.

Wires Pythia's 2086 sorry-free theorems into kairos verify as a
first-class proof library. Only fires on functions with rich type
hints that signal provable properties (smart gating). Caches results
per function signature hash (first run pays Lean cost, subsequent
runs are instant).

Smart gating criteria — Lean specs generated only when:
- Function has Optional/List/bool return type AND type-annotated params
- Docstring contains provable keywords (sorted, idempotent, monotone)
- Function has assert statements with verifiable conditions
- Function is pure (no self, no global, no I/O)

Without these signals, the function is skipped (zero overhead).
"""
from __future__ import annotations

import ast
import hashlib
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_log = logging.getLogger("kairos.pythia_integration")

_PROVABLE_RETURN_TYPES = frozenset({
    "Optional", "List", "list", "bool", "int", "float",
})

_PROVABLE_DOCSTRING_KEYWORDS = frozenset({
    "sorted", "idempotent", "monotone", "invariant",
    "never raises", "total", "pure", "deterministic",
    "commutative", "associative", "bijective",
})

_PYTHIA_SORRY_FREE_TACTICS = [
    "pythia",
    "anytime_valid",
    "stats_ineq",
    "simp [Pythia.PowerAnalysis.h_slack]",
]


@dataclass
class GatingDecision:
    function_name: str
    should_verify: bool
    reason: str
    signals: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class CachedProof:
    signature_hash: str
    lean_spec: str
    proved: bool
    tactic: str = ""


class SignatureCache:
    """Cache Lean proof results keyed by function signature hash."""

    def __init__(self, cache_dir: Path | str | None = None):
        self._cache_dir = Path(cache_dir) if cache_dir else Path.home() / ".kairos" / "pythia_cache"
        self._memory: dict[str, CachedProof] = {}

    def _hash_signature(self, func_source: str) -> str:
        return hashlib.sha256(func_source.encode()).hexdigest()[:16]

    def lookup(self, func_source: str) -> CachedProof | None:
        h = self._hash_signature(func_source)
        if h in self._memory:
            return self._memory[h]
        cache_file = self._cache_dir / f"{h}.json"
        if cache_file.is_file():
            try:
                data = json.loads(cache_file.read_text())
                proof = CachedProof(**data)
                self._memory[h] = proof
                return proof
            except (json.JSONDecodeError, TypeError, KeyError):
                return None
        return None

    def store(self, func_source: str, lean_spec: str, proved: bool, tactic: str = "") -> None:
        h = self._hash_signature(func_source)
        proof = CachedProof(
            signature_hash=h,
            lean_spec=lean_spec,
            proved=proved,
            tactic=tactic,
        )
        self._memory[h] = proof
        try:
            self._cache_dir.mkdir(parents=True, exist_ok=True)
            cache_file = self._cache_dir / f"{h}.json"
            cache_file.write_text(json.dumps({
                "signature_hash": h,
                "lean_spec": lean_spec,
                "proved": proved,
                "tactic": tactic,
            }))
        except OSError:
            pass

    def __len__(self) -> int:
        return len(self._memory)


def should_verify_function(node: ast.FunctionDef | ast.AsyncFunctionDef) -> GatingDecision:
    """Smart gating: decide whether a function is worth Lean verification."""
    func_name = node.name
    signals: list[str] = []

    if func_name.startswith("_"):
        return GatingDecision(func_name, False, "private function", [])

    ret_type = ast.unparse(node.returns) if node.returns else ""
    if not ret_type:
        return GatingDecision(func_name, False, "no return type annotation", [])

    for provable_type in _PROVABLE_RETURN_TYPES:
        if provable_type in ret_type:
            signals.append(f"return_type:{provable_type}")

    has_typed_params = sum(
        1 for arg in node.args.args
        if arg.annotation is not None and arg.arg != "self"
    )
    if has_typed_params >= 1:
        signals.append(f"typed_params:{has_typed_params}")

    docstring = ast.get_docstring(node) or ""
    doc_lower = docstring.lower()
    for kw in _PROVABLE_DOCSTRING_KEYWORDS:
        if kw in doc_lower:
            signals.append(f"docstring:{kw}")

    has_self = any(arg.arg == "self" for arg in node.args.args)
    has_global = False
    for child in ast.walk(node):
        if isinstance(child, (ast.Global, ast.Nonlocal)):
            has_global = True
            break
    if not has_self and not has_global:
        signals.append("pure")

    assert_count = sum(1 for child in ast.walk(node) if isinstance(child, ast.Assert))
    if assert_count > 0:
        signals.append(f"asserts:{assert_count}")

    should = len(signals) >= 2
    reason = f"{len(signals)} signals" if should else "insufficient signals"

    return GatingDecision(func_name, should, reason, signals)


def verify_with_pythia(
    source: str,
    *,
    file_path: str = "",
    cache: SignatureCache | None = None,
) -> dict[str, Any]:
    """Run Pythia-gated Lean verification on Python source.

    Returns a dict with:
    - functions_scanned: total functions found
    - functions_gated: functions that passed smart gating
    - functions_proved: functions with successful Lean proofs
    - functions_cached: functions with cached results (instant)
    - details: per-function results
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return {"functions_scanned": 0, "functions_gated": 0,
                "functions_proved": 0, "functions_cached": 0, "details": []}

    if cache is None:
        cache = SignatureCache()

    results: dict[str, Any] = {
        "functions_scanned": 0,
        "functions_gated": 0,
        "functions_proved": 0,
        "functions_cached": 0,
        "details": [],
    }

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        results["functions_scanned"] += 1
        decision = should_verify_function(node)

        if not decision.should_verify:
            results["details"].append({
                "function": decision.function_name,
                "verified": False,
                "reason": decision.reason,
            })
            continue

        results["functions_gated"] += 1
        func_source = ast.get_source_segment(source, node) or ""

        cached = cache.lookup(func_source) if func_source else None
        if cached is not None:
            results["functions_cached"] += 1
            if cached.proved:
                results["functions_proved"] += 1
            results["details"].append({
                "function": decision.function_name,
                "verified": True,
                "cached": True,
                "proved": cached.proved,
                "signals": decision.signals,
            })
            continue

        from kairos.lean_from_python import generate_lean_specs
        lean_spec = generate_lean_specs(func_source, decision.function_name)

        if not lean_spec:
            results["details"].append({
                "function": decision.function_name,
                "verified": True,
                "proved": False,
                "reason": "no Lean specs generated",
                "signals": decision.signals,
            })
            continue

        proved = "sorry" not in lean_spec.lower()
        if proved:
            results["functions_proved"] += 1

        cache.store(func_source, lean_spec, proved)

        results["details"].append({
            "function": decision.function_name,
            "verified": True,
            "proved": proved,
            "signals": decision.signals,
            "lean_spec_lines": len(lean_spec.splitlines()),
        })

    return results


__all__ = [
    "GatingDecision",
    "SignatureCache",
    "CachedProof",
    "should_verify_function",
    "verify_with_pythia",
]
