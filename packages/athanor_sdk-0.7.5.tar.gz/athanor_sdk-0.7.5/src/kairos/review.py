"""kairos.review — adversarial agent critique for RTL and code.

Spawns a Claude subagent with a review-specific system prompt.
Reads the target file, returns structured critique with file:line
citations, severity levels, and actionable suggestions.

This is the AGENT review (adversarial, qualitative).
For MACHINE verification (binary proved/refuted), use kairos verify.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

from kairos.security.env_allowlist import safe_env_for_claude_subagent


_REVIEW_SYSTEM_PROMPT_RTL = """\
You are an adversarial hardware design reviewer. Your job is to find
problems, risks, and improvement opportunities in RTL code.

For each finding, report:
- severity: critical | high | medium | low
- line: the line number (or range) in the source file
- category: timing | area | power | correctness | style | security
- finding: one-sentence description of the problem
- suggestion: one-sentence actionable fix
- kind: "bug" (will cause wrong behavior at runtime/synthesis) or "observation" (design choice, style, potential future issue)
- confidence: 0.0-1.0 (1.0 = certain this is a real issue, 0.5 = depends on context, 0.1 = informational)

Be specific. Cite line numbers. Do not praise — only critique.
Focus on what could go WRONG, not what is right.
Reserve "bug" for correctness issues that WILL produce wrong results.
Use "observation" for style, optimization opportunities, and context-dependent concerns.

Output valid JSON: {"findings": [{"severity": "...", "line": ..., "category": "...", "finding": "...", "suggestion": "...", "kind": "...", "confidence": ...}]}
"""

_REVIEW_SYSTEM_PROMPT_CODE = """\
You are an adversarial code reviewer. Your job is to find bugs, security
vulnerabilities, correctness issues, and improvement opportunities.

For each finding, report:
- severity: critical | high | medium | low
- line: the line number (or range) in the source file
- category: security | correctness | performance | error-handling | style | injection
- finding: one-sentence description of the problem
- suggestion: one-sentence actionable fix
- kind: "bug" (will crash, produce wrong results, or create a security hole) or "observation" (design choice, style, potential future issue)
- confidence: 0.0-1.0 (1.0 = certain this is a real issue, 0.5 = depends on context, 0.1 = informational)

Prioritize: command injection, path traversal, unchecked inputs, race conditions,
resource leaks, logic errors. Be specific. Cite line numbers. Do not praise.
Reserve "bug" for issues that WILL cause incorrect behavior or security vulnerabilities.
Use "observation" for style suggestions, design alternatives, and context-dependent concerns.

Output valid JSON: {"findings": [{"severity": "...", "line": ..., "category": "...", "finding": "...", "suggestion": "...", "kind": "...", "confidence": ...}]}
"""

_REVIEW_SYSTEM_PROMPT_CONFIG = """\
You are an adversarial infrastructure reviewer. Your job is to find
misconfigurations, security gaps, and correctness issues in configuration files.

For each finding, report:
- severity: critical | high | medium | low
- line: the line number (or range) in the source file
- category: security | correctness | permissions | secrets | compatibility
- finding: one-sentence description of the problem
- suggestion: one-sentence actionable fix
- kind: "bug" (will cause misconfiguration or security hole) or "observation" (hardening suggestion, style preference)
- confidence: 0.0-1.0 (1.0 = certain this is a real issue, 0.5 = depends on context, 0.1 = informational)

Prioritize: exposed secrets, overly permissive settings, missing validation,
version pinning issues, dependency confusion. Be specific. Cite line numbers.
Reserve "bug" for configurations that WILL cause failures or security issues.

Output valid JSON: {"findings": [{"severity": "...", "line": ..., "category": "...", "finding": "...", "suggestion": "...", "kind": "...", "confidence": ...}]}
"""

_RTL_EXTENSIONS = {".sv", ".v", ".vhd", ".vhdl", ".svh", ".vh"}
_CONFIG_EXTENSIONS = {".yml", ".yaml", ".toml", ".json", ".dockerfile", ".env", ".cfg", ".ini"}


def _select_prompt(path: Path) -> str:
    suffix = path.suffix.lower()
    name = path.name.lower()
    if suffix in _RTL_EXTENSIONS:
        return _REVIEW_SYSTEM_PROMPT_RTL
    if suffix in _CONFIG_EXTENSIONS or name in ("dockerfile", "containerfile", "makefile"):
        return _REVIEW_SYSTEM_PROMPT_CONFIG
    return _REVIEW_SYSTEM_PROMPT_CODE


@dataclass
class ReviewFinding:
    severity: str
    line: int | str
    category: str
    finding: str
    suggestion: str
    kind: str = "bug"
    confidence: float = 0.8


@dataclass
class ReviewResult:
    path: str
    findings: list[ReviewFinding] = field(default_factory=list)
    error: str | None = None
    raw_output: str = ""


def review(
    path: str | Path,
    *,
    focus: str | None = None,
    model: str | None = None,
    heuristic_only: bool = False,
) -> ReviewResult:
    """Run adversarial review on a file.

    Uses claude CLI as a subagent with a review-specific system prompt.
    Falls back to the corpus-based keyword matcher if claude is not available
    or if heuristic_only=True.
    """
    target = Path(path)
    if not target.is_file():
        return ReviewResult(path=str(path), error=f"File not found: {path}")

    content = target.read_text()
    if heuristic_only:
        return _fallback_review(str(path), content, focus)
    if len(content) > 100_000:
        return _review_chunked(target, content, focus=focus)

    claude_bin = shutil.which("claude")
    if not claude_bin:
        return _fallback_review(str(path), content, focus)

    focus_instruction = ""
    if focus:
        focus_instruction = f"\nFocus especially on: {focus}."

    prompt = (
        f"Review this file and return findings as JSON.\n"
        f"{focus_instruction}\n"
        f"File: {target.name}\n"
        f"```\n{content}\n```"
    )

    from kairos.subagent_trace import trace_subagent_call, complete_trace
    import time as _time
    trace = trace_subagent_call("review", f"adversarial review of {target.name}", f"{len(content)} chars, {focus or 'general'} focus")
    t0 = _time.time()

    try:
        result = subprocess.run(
            [claude_bin, "--print", "-p", prompt, "--append-system-prompt", _select_prompt(target)],
            capture_output=True,
            text=True,
            timeout=120,
            env=safe_env_for_claude_subagent(),
        )
        raw = result.stdout.strip()
        parsed = _parse_review_output(str(path), raw)
        n = len(parsed.findings)
        complete_trace(trace, f"{n} findings", "accepted" if n > 0 else "accepted (clean)", f"{n} findings in {target.name}", _time.time() - t0)
        return parsed
    except subprocess.TimeoutExpired:
        complete_trace(trace, "", "error", "timed out after 120s", _time.time() - t0)
        return ReviewResult(path=str(path), error="Review agent timed out (120s)")
    except Exception as e:  # noqa: BLE001
        complete_trace(trace, "", "error", str(e)[:200], _time.time() - t0)
        return ReviewResult(path=str(path), error=str(e)[:200])


def _parse_review_output(path: str, raw: str) -> ReviewResult:
    """Parse the Claude subagent's JSON output into ReviewResult."""
    json_start = raw.find("{")
    json_end = raw.rfind("}") + 1
    if json_start < 0 or json_end <= json_start:
        return ReviewResult(path=path, error="Review agent returned non-JSON output", raw_output=raw[:500])

    try:
        data = json.loads(raw[json_start:json_end])
    except json.JSONDecodeError:
        return ReviewResult(path=path, error="Review agent returned invalid JSON", raw_output=raw[:500])

    findings = []
    for f in data.get("findings", []):
        kind = f.get("kind", "")
        confidence = f.get("confidence", -1.0)
        severity = f.get("severity", "medium")
        category = f.get("category", "general")
        if not kind or kind not in ("bug", "observation"):
            kind = _infer_kind(severity, category)
        if confidence < 0:
            confidence = _infer_confidence(severity, category, kind)
        findings.append(ReviewFinding(
            severity=severity,
            line=f.get("line", "?"),
            category=category,
            finding=f.get("finding", ""),
            suggestion=f.get("suggestion", ""),
            kind=kind,
            confidence=confidence,
        ))

    return ReviewResult(path=path, findings=findings, raw_output=raw[:500])


_BUG_CATEGORIES = frozenset({"correctness", "security", "injection"})
_OBSERVATION_CATEGORIES = frozenset({"style", "performance", "area", "power"})


def _infer_kind(severity: str, category: str) -> str:
    """Infer finding kind when LLM doesn't return it."""
    if category in _BUG_CATEGORIES and severity in ("critical", "high"):
        return "bug"
    if category in _OBSERVATION_CATEGORIES:
        return "observation"
    if severity == "critical":
        return "bug"
    if severity == "low":
        return "observation"
    return "bug" if severity == "high" else "observation"


def _infer_confidence(severity: str, category: str, kind: str) -> float:
    """Infer confidence score when LLM doesn't return it."""
    if kind == "bug":
        if severity == "critical":
            return 0.95
        if severity == "high":
            return 0.8
        return 0.6
    if severity == "low":
        return 0.3
    return 0.5


_SECURITY_PATH_PATTERNS = ("sec/", "security/", "auth.py", "license_scope.py", "crypto", "subprocess")


def is_security_critical(path: str | Path) -> bool:
    """Return True if the file is on a security-critical path."""
    s = str(path).replace("\\", "/")
    return any(pat in s for pat in _SECURITY_PATH_PATTERNS)


def _fallback_review(path: str, content: str, focus: str | None) -> ReviewResult:
    """AST + pattern heuristic review — no LLM calls."""
    findings: list[ReviewFinding] = []
    lines = content.splitlines()

    is_python = path.endswith(".py")

    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        stripped_lower = stripped.lower()

        if is_python:
            if "subprocess" in stripped and "shell=True" in stripped:
                findings.append(ReviewFinding(
                    severity="high", line=i, category="security",
                    finding="subprocess call with shell=True",
                    suggestion="Use shell=False with a list of args to prevent command injection",
                ))
            if stripped.startswith("os.system(") or "os.system(" in stripped:
                findings.append(ReviewFinding(
                    severity="high", line=i, category="security",
                    finding="os.system() call — vulnerable to command injection",
                    suggestion="Use subprocess.run() with shell=False",
                ))
            if "eval(" in stripped and "literal_eval" not in stripped:
                findings.append(ReviewFinding(
                    severity="critical", line=i, category="security",
                    finding="eval() call — arbitrary code execution risk",
                    suggestion="Use ast.literal_eval() or a safer alternative",
                ))
            if "exec(" in stripped and "execute" not in stripped:
                findings.append(ReviewFinding(
                    severity="critical", line=i, category="security",
                    finding="exec() call — arbitrary code execution risk",
                    suggestion="Refactor to avoid dynamic code execution",
                ))
            if "pickle.loads" in stripped or "pickle.load(" in stripped:
                findings.append(ReviewFinding(
                    severity="high", line=i, category="security",
                    finding="pickle deserialization — arbitrary code execution on untrusted data",
                    suggestion="Use json or a safe serialization format",
                ))
            if "import *" in stripped:
                findings.append(ReviewFinding(
                    severity="low", line=i, category="style",
                    finding="Wildcard import pollutes namespace",
                    suggestion="Import specific names",
                    kind="observation", confidence=0.4,
                ))
            if "except:" in stripped and "#" not in stripped:
                findings.append(ReviewFinding(
                    severity="medium", line=i, category="error-handling",
                    finding="Bare except catches SystemExit and KeyboardInterrupt",
                    suggestion="Use 'except Exception:' at minimum",
                    kind="bug", confidence=0.7,
                ))
        else:
            if "always @(*)" in stripped_lower and "begin" not in stripped_lower:
                findings.append(ReviewFinding(
                    severity="medium", line=i, category="style",
                    finding="Combinational always block without begin/end",
                    suggestion="Add begin/end to prevent accidental scope bugs",
                    kind="observation", confidence=0.5,
                ))

    if is_python:
        try:
            import ast as _ast
            _ast.parse(content)
        except SyntaxError as e:
            findings.append(ReviewFinding(
                severity="critical", line=e.lineno or 1, category="correctness",
                finding=f"Syntax error: {e.msg}",
                suggestion="Fix the syntax error before merging",
            ))

    return ReviewResult(path=path, findings=findings)


@dataclass
class PRReviewResult:
    pr_number: int
    repo: str
    files_reviewed: int
    total_findings: int
    file_results: list[ReviewResult] = field(default_factory=list)
    error: str | None = None


def _fetch_changed_files_github(pr_number: int, repo: str) -> tuple[list[str], str | None]:
    """Fetch changed file list via gh CLI."""
    gh_bin = shutil.which("gh")
    if not gh_bin:
        return [], "gh CLI not found on PATH"
    cmd = [gh_bin, "pr", "diff", str(pr_number), "--name-only"]
    if repo:
        cmd += ["--repo", repo]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            return [], f"gh pr diff failed: {result.stderr.strip()[:200]}"
        return result.stdout.strip().splitlines(), None
    except Exception as e:  # noqa: BLE001
        return [], str(e)[:200]


def _fetch_changed_files_local(base_ref: str = "origin/main") -> tuple[list[str], str | None]:
    """Fetch changed file list via local git diff."""
    git_bin = shutil.which("git")
    if not git_bin:
        return [], "git not found on PATH"
    try:
        result = subprocess.run(
            [git_bin, "diff", "--name-only", base_ref],
            capture_output=True, text=True, timeout=15,
        )
        return result.stdout.strip().splitlines(), None
    except Exception as e:  # noqa: BLE001
        return [], str(e)[:200]


_REVIEWABLE_EXTENSIONS = (".py", ".sv", ".v", ".vh", ".lean", ".rs")


def review_pr(
    pr_number: int,
    *,
    repo: str = "",
    focus: str | None = None,
    model: str | None = None,
) -> PRReviewResult:
    """Review a GitHub PR by fetching its diff and reviewing changed files.

    Diff source is pluggable: uses gh CLI for GitHub PRs. Future adapters
    (CodeCommit, local diff) can replace _fetch_changed_files_github.
    """
    changed_files, err = _fetch_changed_files_github(pr_number, repo)
    if err:
        return PRReviewResult(
            pr_number=pr_number, repo=repo,
            files_reviewed=0, total_findings=0, error=err,
        )

    reviewable = [f for f in changed_files if f.endswith(_REVIEWABLE_EXTENSIONS)]

    file_results: list[ReviewResult] = []
    for filepath in reviewable:
        p = Path(filepath)
        if p.is_file():
            r = review(p, focus=focus, model=model)
            file_results.append(r)

    total = sum(len(r.findings) for r in file_results)
    return PRReviewResult(
        pr_number=pr_number,
        repo=repo,
        files_reviewed=len(file_results),
        total_findings=total,
        file_results=file_results,
    )


def format_pr_review(result: PRReviewResult) -> str:
    """Format PRReviewResult for terminal output."""
    if result.error:
        return f"PR #{result.pr_number} review error: {result.error}"

    lines = [
        f"PR #{result.pr_number} review: {result.files_reviewed} files, "
        f"{result.total_findings} findings\n"
    ]
    for fr in result.file_results:
        lines.append(format_review(fr))
        lines.append("")
    return "\n".join(lines)


def format_review(result: ReviewResult) -> str:
    """Format ReviewResult for terminal output."""
    if result.error:
        return f"Error: {result.error}"

    lines = [f"Review: {result.path} ({len(result.findings)} findings)\n"]
    for f in result.findings:
        icon = {"critical": "!!", "high": "!", "medium": "~", "low": "-"}.get(f.severity, "?")
        lines.append(f"  [{icon}] L{f.line} [{f.category}] {f.finding}")
        lines.append(f"       Fix: {f.suggestion}")
    return "\n".join(lines)


def _review_chunked(
    target: Path,
    content: str,
    *,
    focus: str | None = None,
    chunk_size: int = 80_000,
) -> ReviewResult:
    """Review a large file by splitting into chunks and reviewing each.

    Each chunk overlaps by 20 lines to catch cross-boundary issues.
    Findings are merged and deduplicated by line number.
    """
    lines = content.splitlines()
    total_lines = len(lines)
    chunk_lines = chunk_size // 80  # ~80 chars per line estimate
    overlap = 20

    all_findings: list[ReviewFinding] = []
    seen_lines: set[int] = set()
    chunks_reviewed = 0

    start = 0
    while start < total_lines:
        end = min(start + chunk_lines, total_lines)
        chunk = "\n".join(lines[start:end])

        # Write chunk to temp file with line offset info
        import tempfile
        tmp = Path(tempfile.mktemp(suffix=target.suffix))
        tmp.write_text(chunk)

        try:
            chunk_result = review(tmp, focus=focus)
            for f in chunk_result.findings:
                # Adjust line numbers to absolute position
                abs_line = (f.line if isinstance(f.line, int) else 0) + start
                if abs_line not in seen_lines:
                    seen_lines.add(abs_line)
                    all_findings.append(ReviewFinding(
                        severity=f.severity,
                        line=abs_line,
                        category=f.category,
                        finding=f.finding,
                        suggestion=f.suggestion,
                    ))
            chunks_reviewed += 1
        except Exception:  # noqa: BLE001
            pass
        finally:
            tmp.unlink(missing_ok=True)

        start = end - overlap if end < total_lines else total_lines

    return ReviewResult(
        path=str(target),
        findings=sorted(all_findings, key=lambda f: (
            {"critical": 0, "high": 1, "medium": 2, "low": 3}.get(f.severity, 4),
            f.line if isinstance(f.line, int) else 0,
        )),
    )
