"""ATH-1457 W3: production software repair pipeline.

Full loop: verify → find bugs → generate fix → verify fix → apply.
Integrates silent_verify (all 4 layers) with repair (LLM fix gen)
and re-verification (confirm the fix actually works).

Target: 8/10 auto-fixed correctly on real bugs.

Usage:
    from kairos.software_repair import repair_and_verify
    result = repair_and_verify("src/app.py")
    print(result.honest_report)
"""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class FixAttempt:
    bug_line: int
    bug_message: str
    fix_applied: bool = False
    fix_verified: bool = False
    fix_description: str = ""


@dataclass
class SoftwareRepairResult:
    file_path: str
    bugs_found: int = 0
    fixes_attempted: int = 0
    fixes_verified: int = 0
    fixes_applied: int = 0
    attempts: list[FixAttempt] = field(default_factory=list)

    @property
    def success_rate(self) -> float:
        return self.fixes_verified / self.fixes_attempted if self.fixes_attempted > 0 else 0.0

    @property
    def honest_report(self) -> str:
        parts = [f"Software repair: {self.file_path}"]
        parts.append(f"  Bugs found: {self.bugs_found}")
        parts.append(f"  Fixes attempted: {self.fixes_attempted}")
        parts.append(f"  Fixes verified: {self.fixes_verified} ({self.success_rate:.0%})")
        parts.append(f"  Fixes applied: {self.fixes_applied}")
        for a in self.attempts:
            icon = "+" if a.fix_verified else "x"
            parts.append(f"  [{icon}] L{a.bug_line}: {a.bug_message[:60]}")
            if a.fix_description:
                parts.append(f"       fix: {a.fix_description[:60]}")
        return "\n".join(parts)


def repair_and_verify(
    path: str | Path,
    *,
    auto_apply: bool = True,
    max_fixes: int = 10,
) -> SoftwareRepairResult:
    """Full repair loop: verify → find → fix → re-verify → apply."""
    file_path = Path(path)
    if not file_path.is_file():
        return SoftwareRepairResult(file_path=str(path))

    result = SoftwareRepairResult(file_path=str(path))

    from kairos.silent_verify import verify_silently
    verification = verify_silently(file_path.read_text(), file_path=str(file_path))

    actionable = [b for b in verification.bugs if b.severity in ("critical", "high")]
    result.bugs_found = len(actionable)

    if not actionable:
        return result

    claude_bin = shutil.which("claude")
    original = file_path.read_text()
    current = original

    for bug in actionable[:max_fixes]:
        result.fixes_attempted += 1
        attempt = FixAttempt(bug_line=bug.line, bug_message=bug.message)

        fixed = _generate_fix(claude_bin, file_path, current, bug)
        if fixed is None:
            result.attempts.append(attempt)
            continue

        if _verify_fix(file_path, fixed):
            attempt.fix_verified = True
            result.fixes_verified += 1
            attempt.fix_description = _describe_diff(current, fixed)

            if auto_apply:
                current = fixed
                attempt.fix_applied = True
                result.fixes_applied += 1

        result.attempts.append(attempt)

    if auto_apply and current != original:
        file_path.write_text(current)

    return result


def _generate_fix(
    claude_bin: str | None,
    target: Path,
    content: str,
    bug: Any,
) -> str | None:
    """Generate a fix for a single bug."""
    if claude_bin is None:
        return None

    prompt = (
        f"Fix this bug in {target.name}:\n\n"
        f"Line {bug.line}: [{bug.severity}] {bug.message}\n\n"
        f"File content:\n```python\n{content}\n```\n\n"
        f"Return ONLY the complete fixed file. No explanation. No markdown fences."
    )

    from kairos.security.env_allowlist import safe_env_for_claude_subagent
    try:
        r = subprocess.run(
            [claude_bin, "--print", "-p", prompt, "--max-turns", "1"],
            capture_output=True, text=True, timeout=60,
            env=safe_env_for_claude_subagent(),
        )
        output = r.stdout.strip()
        if output.startswith("```"):
            lines = output.splitlines()
            output = "\n".join(lines[1:-1] if lines[-1].startswith("```") else lines[1:])
        if len(output) < 10 or "sorry" in output.lower()[:50]:
            return None
        return output
    except Exception:  # noqa: BLE001
        return None


def _verify_fix(target: Path, fixed_content: str) -> bool:
    """Verify a fix by running silent_verify on the fixed content."""
    tmp = Path(tempfile.mktemp(suffix=target.suffix))
    try:
        tmp.write_text(fixed_content)
        from kairos.silent_verify import verify_silently
        result = verify_silently(fixed_content, file_path=str(tmp))
        high_bugs = [b for b in result.bugs if b.severity in ("critical", "high")]
        return len(high_bugs) == 0
    finally:
        tmp.unlink(missing_ok=True)


def _describe_diff(before: str, after: str) -> str:
    """One-line description of what changed."""
    before_lines = before.splitlines()
    after_lines = after.splitlines()
    changed = sum(1 for a, b in zip(before_lines, after_lines) if a != b)
    added = max(0, len(after_lines) - len(before_lines))
    removed = max(0, len(before_lines) - len(after_lines))
    parts = []
    if changed:
        parts.append(f"{changed} lines changed")
    if added:
        parts.append(f"{added} added")
    if removed:
        parts.append(f"{removed} removed")
    return ", ".join(parts) or "no diff"
