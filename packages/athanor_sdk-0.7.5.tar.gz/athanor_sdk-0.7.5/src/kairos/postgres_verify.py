"""ATH-1201 phase 2: lazy-imported psycopg2 helpers for `kairos config db`.

Customer flows:
- `kairos config db <conn>` calls `verify_conn()` which:
  1. psycopg2.connect with 5s timeout.
  2. SELECT version() → engine label (Aurora / RDS / Postgres).
  3. CREATE TABLE IF NOT EXISTS for the run-history schema (idempotent).
  4. INSERT then DELETE a smoke row to confirm CREATE/INSERT/DELETE privs.

psycopg2 is lazy-imported (matches the boto3 pattern in aws_s3_verify
+ litellm pattern in providers). Missing psycopg2 surfaces a friendly
hint pointing at the install command + `--no-verify` escape hatch.

Migrations are append-only: only CREATE TABLE IF NOT EXISTS and ADD
COLUMN IF NOT EXISTS allowed. No DROP / TRUNCATE / DELETE in the
schema-evolution path (customer data MUST NEVER be destroyed by an
SDK upgrade).
"""
from __future__ import annotations

from typing import Any


PSYCOPG2_MISSING_HINT = (
    "psycopg2 not installed. To use Postgres run-history persistence:\n"
    "    pip install psycopg2-binary\n"
    "Or install athanor-sdk with the [postgres] extra (when published):\n"
    "    pip install 'athanor-sdk[postgres]'\n"
    "If you intend to set the conn string WITHOUT running the psycopg2\n"
    "verification (e.g., in CI before DB credentials are available), use:\n"
    "    kairos config db <conn> --no-verify"
)


def _require_psycopg2() -> Any:
    """Lazy-import psycopg2; raise ImportError with friendly hint."""
    try:
        import psycopg2  # type: ignore[import-untyped,import-not-found,unused-ignore]  # noqa: F401
        return psycopg2
    except ImportError as e:
        raise ImportError(PSYCOPG2_MISSING_HINT) from e


def _extract_password_substring(conn_str: str) -> str | None:
    """Pull the literal password substring out of a postgres conn-string,
    or None if no password component. Used by :func:`verify_conn` as a
    belt-and-suspenders pass to scrub the exact substring from any
    error message string a downstream libpq returned — beyond the
    URL-shape redaction which only handles ``user:pwd@host`` forms.
    ATH-1242 strike (3).
    """
    from urllib.parse import urlparse
    try:
        parsed = urlparse(conn_str)
    except ValueError:
        return None
    return parsed.password


# ATH-1242 strike (5): forbidden DDL forms in the append-only migration
# path. The pre-ATH-1242 list covered DROP TABLE / TRUNCATE / DELETE /
# DROP COLUMN / DROP CONSTRAINT — but did NOT cover ALTER COLUMN TYPE
# (data-loss truncation possible: VARCHAR(255) -> VARCHAR(50)) or
# RENAME COLUMN (silent data-orphaning: every consumer reading the old
# name returns null until they're patched). Both compile cleanly under
# the old lint and could land in _IDEMPOTENT_SCHEMA_DDL during a future
# migration-append without anyone noticing.
_BANNED_DDL_SUBSTRINGS = (
    "DROP TABLE",
    "TRUNCATE",
    "DELETE FROM",
    "DROP COLUMN",
    "DROP CONSTRAINT",
    # ATH-1242 strike (5) additions:
    "ALTER COLUMN",  # blocks ALTER COLUMN ... TYPE / DROP NOT NULL.
                     # ALTER COLUMN ... SET DEFAULT is also blocked
                     # (acceptable — that change wants the safer
                     # fresh-column-plus-backfill pattern anyway).
    "RENAME COLUMN",
    "RENAME TO",  # ALTER TABLE x RENAME TO y — same orphan class.
)


def _assert_append_only_ddl(ddl: str) -> None:
    """Static lint pass on a DDL statement; raise ValueError on any
    banned form. Pure-string check, case-insensitive, no SQL parsing.

    ATH-1242 strike (5): extends the original DROP/TRUNCATE/DELETE
    rejection set to also block ALTER COLUMN and RENAME COLUMN /
    RENAME TO. Caller invokes defensively; the production runtime
    doesn't gate-check on every invocation (validated once via the
    unit-test surface against _IDEMPOTENT_SCHEMA_DDL at module import).
    """
    upper = ddl.upper()
    for banned in _BANNED_DDL_SUBSTRINGS:
        if banned in upper:
            raise ValueError(
                f"banned DDL form {banned!r} found in migration DDL. "
                "ATH-1201 + ATH-1242 require append-only migrations: "
                "no DROP / TRUNCATE / DELETE / ALTER COLUMN / RENAME. "
                "Customer data MUST NEVER be destroyed by an SDK upgrade. "
                f"Offending DDL: {ddl[:120]!r}"
            )


# Result-status labels. Pinned by tests + doctor; keep stable.
VERIFY_OK = "ok"
VERIFY_CONNECT_FAILED = "connect_failed"
VERIFY_AUTH_FAILED = "auth_failed"
VERIFY_SCHEMA_DENIED = "schema_denied"
VERIFY_OTHER_ERROR = "other_error"


# ATH-1201 §Spec.2.c: idempotent run-history schema migration.
# Append-only — only CREATE TABLE IF NOT EXISTS / ADD COLUMN IF NOT
# EXISTS allowed here. Never DROP / TRUNCATE / DELETE.
_IDEMPOTENT_SCHEMA_DDL = [
    """
    CREATE TABLE IF NOT EXISTS kairos_runs (
        run_id           TEXT PRIMARY KEY,
        vertical         TEXT,
        target           TEXT,
        status           TEXT,
        started_at       TIMESTAMPTZ DEFAULT NOW(),
        completed_at     TIMESTAMPTZ,
        token_cost_usd   NUMERIC(10, 4),
        organization_id  TEXT,
        pipeline_version TEXT
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS kairos_run_events (
        id           BIGSERIAL PRIMARY KEY,
        run_id       TEXT REFERENCES kairos_runs(run_id) ON DELETE CASCADE,
        event_id     TEXT,
        ts           TIMESTAMPTZ DEFAULT NOW(),
        role         TEXT,
        type         TEXT,
        payload      JSONB
    )
    """,
    """
    CREATE INDEX IF NOT EXISTS kairos_run_events_run_id_ts_idx
        ON kairos_run_events (run_id, ts)
    """,
]

_SMOKE_INSERT_SQL = """
    INSERT INTO kairos_runs (run_id, status)
    VALUES (%s, 'verify_smoke')
"""
_SMOKE_DELETE_SQL = "DELETE FROM kairos_runs WHERE run_id = %s"


def verify_conn(conn_str: str) -> dict[str, Any]:
    """Connect to the supplied Postgres URL, smoke schema + privileges.

    Returns a dict with at minimum:
    - `status`: one of VERIFY_* constants.
    - `detail`: human-readable explanation.
    - `fix_hint`: actionable next step.
    - `engine`: aurora / rds / postgres / unknown (from `version()`).
    - `version`: raw version string (truncated to 200 chars for log
      safety).

    Errors are NOT raised (caller can render structured CLI output);
    ImportError on missing psycopg2 IS raised so the caller sees the
    friendly install hint.
    """
    psycopg2 = _require_psycopg2()

    import uuid
    smoke_run_id = f"_athanor-verify-smoke-{uuid.uuid4().hex[:12]}"

    # ATH-1242 strike (3): psycopg2 OperationalError stringification can
    # embed the conninfo dict — including the password literal under
    # certain libpq versions / connection-failure modes. Route every
    # `str(e)` through the URL-redactor before stuffing into the result
    # dict, so a caller that logs/echoes the result dict cannot leak
    # the password. Use a per-call helper closed over the customer's
    # conn_str so we can scrub the exact password substring as a
    # belt-and-suspenders pass beyond URL-shape redaction.
    from kairos.config import _redact_password_in_url
    _password = _extract_password_substring(conn_str)

    def _scrub(text: str) -> str:
        """URL-shape redact + literal-password scrub. Truncation happens
        AFTER scrubbing so we never lose the prefix that proves the
        scrub fired."""
        out: str = _redact_password_in_url(text)
        if _password and _password in out:
            out = out.replace(_password, "****")
        return out

    try:
        conn = psycopg2.connect(conn_str, connect_timeout=5)
    except psycopg2.OperationalError as e:
        e_str = _scrub(str(e))
        msg = e_str.lower()
        if "authentication" in msg or "password" in msg:
            return {
                "status": VERIFY_AUTH_FAILED,
                "detail": "authentication failed (bad user / password / SSL config)",
                "fix_hint": (
                    "Check the conn-string username + password. Re-run:\n"
                    "  kairos config db <corrected-conn>"
                ),
                "engine": "unknown",
                "version": e_str[:200],
            }
        return {
            "status": VERIFY_CONNECT_FAILED,
            "detail": f"connection failed: {e_str[:160]}",
            "fix_hint": (
                "Check host:port reachability + SSL cert validity. "
                "If running from a VPC, confirm the security group allows "
                "ingress on the Postgres port (typically 5432)."
            ),
            "engine": "unknown",
            "version": e_str[:200],
        }
    except Exception as e:  # noqa: BLE001
        e_str = _scrub(str(e))
        return {
            "status": VERIFY_OTHER_ERROR,
            "detail": f"unexpected error connecting: {type(e).__name__}: {e_str[:160]}",
            "fix_hint": "Check the conn-string format + DB server logs.",
            "engine": "unknown",
            "version": e_str[:200],
        }

    try:
        from kairos.config import db_url_engine_label
        cursor = conn.cursor()
        cursor.execute("SELECT version()")
        version_row = cursor.fetchone()
        version_string = version_row[0] if version_row else None
        engine_label = db_url_engine_label(version_string)
        version_truncated = (version_string or "")[:200]

        # Idempotent schema migration.
        try:
            for ddl in _IDEMPOTENT_SCHEMA_DDL:
                cursor.execute(ddl)
            conn.commit()
        except Exception as e:  # noqa: BLE001
            conn.rollback()
            return {
                "status": VERIFY_SCHEMA_DENIED,
                "detail": (
                    f"schema-create denied: {type(e).__name__}: {_scrub(str(e))[:160]}"
                ),
                "fix_hint": (
                    "The DB user lacks CREATE on the public schema. Grant:\n"
                    "  GRANT CREATE ON SCHEMA public TO <db-user>;\n"
                    "  GRANT SELECT, INSERT, UPDATE, DELETE\n"
                    "    ON ALL TABLES IN SCHEMA public TO <db-user>;\n"
                    "  ALTER DEFAULT PRIVILEGES IN SCHEMA public\n"
                    "    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES\n"
                    "    TO <db-user>;"
                ),
                "engine": engine_label,
                "version": version_truncated,
            }

        # Smoke: INSERT + DELETE a row to confirm DML works end-to-end.
        try:
            cursor.execute(_SMOKE_INSERT_SQL, (smoke_run_id,))
            cursor.execute(_SMOKE_DELETE_SQL, (smoke_run_id,))
            conn.commit()
        except Exception as e:  # noqa: BLE001
            conn.rollback()
            return {
                "status": VERIFY_SCHEMA_DENIED,
                "detail": (
                    f"DML smoke (INSERT/DELETE) denied: "
                    f"{type(e).__name__}: {_scrub(str(e))[:160]}"
                ),
                "fix_hint": (
                    "The DB user can CREATE TABLE but lacks INSERT/DELETE. "
                    "Grant:\n"
                    "  GRANT INSERT, DELETE ON kairos_runs TO <db-user>;"
                ),
                "engine": engine_label,
                "version": version_truncated,
            }

        return {
            "status": VERIFY_OK,
            "detail": (
                f"{engine_label} reachable + run-history schema "
                "created + DML smoke passed"
            ),
            "fix_hint": "",
            "engine": engine_label,
            "version": version_truncated,
        }
    finally:
        try:
            conn.close()
        except Exception:  # noqa: BLE001
            pass


__all__ = [
    "PSYCOPG2_MISSING_HINT",
    "VERIFY_OK",
    "VERIFY_CONNECT_FAILED",
    "VERIFY_AUTH_FAILED",
    "VERIFY_SCHEMA_DENIED",
    "VERIFY_OTHER_ERROR",
    "verify_conn",
]
