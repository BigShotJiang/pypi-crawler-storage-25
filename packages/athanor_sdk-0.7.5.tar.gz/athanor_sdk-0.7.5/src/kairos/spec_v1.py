"""solve/shared/spec_v1.py — Customer-facing spec TypedDicts (ATH-358).

Mirrored byte-identical at `athanor-sdk/src/athanor/spec_v1.py`.
Schema ground truth lives in `spec_schema.json` (same directory).

Two TypedDicts in this module:

    SpecV1     — what the customer writes in spec.json. 4 required
                 fields + 6 defaulted. The TUI (qa/ath358-tui-wizard)
                 composes one of these; `athanor spec validate` lints
                 one of these; `athanor spec submit` starts here.

    IntentV1   — the neutral-intent contract emitted by
                 `spec_compile.compile(SpecV1) -> IntentV1`. Pure data,
                 no prompt strings. mode_fleet expands IntentV1 into
                 per-phase prompts using the private templates in
                 `solve/<vertical>/prompts/`.

ATH-337 IP boundary: SpecV1 and IntentV1 cross the SDK ↔ builder
boundary. Prompt templates do not. The compile step is a pure data
transform so it can live in either package; we put it in both (sdk
for customer composition convenience, builder for runtime consumption)
with byte-identical copies.
"""

from __future__ import annotations

import logging
from typing import List, Literal, TypedDict

logger = logging.getLogger(__name__)

# Keep the version string in lockstep with spec_schema.json. 1.1 is the
# current schema; 1.0 specs still load (LENIENT forward-compat per the
# 2026-04-23 ATH-492 scope-lock — semver minor-bump MUST stay backward-
# compat for 1.0 readers; only a 2.0 bump breaks readers).
SPEC_VERSION: str = "1.1"
SUPPORTED_SPEC_VERSIONS: frozenset[str] = frozenset({"1.0", "1.1"})

Vertical = Literal[
    "bbr3", "action_cred", "sysverilog", "neuron", "bio", "lean", "custom"
]
Priority = Literal["critical", "high", "medium", "low"]
TargetKind = Literal[
    # 1.0 values:
    "theorem", "property", "kernel", "rtl_fix", "top_module",
    # 1.1 addition (ATH-492): integration-shaped verification targets
    # where the verdict composes multiple tier-level proofs (e.g. Lean
    # primary + BMC fallback + empirical). Documented in
    # docs/spec-v1-migration-1.0-to-1.1.md.
    "integration",
]
ArtifactName = Literal[
    "proof", "counterexample", "bundle", "audit",
    "mutation_report", "property_report",
]
OnCounterexample = Literal["auto_revise", "halt", "ask_operator"]

# ─── Evidence tier registry (ATH-492 1.1 + plugin-API-day-1) ────────────
#
# `evidence_tier` is an OPEN string (not a closed Literal) so customer
# plugins can register new tiers at import time. Built-in tiers are
# seeded in KNOWN_TIERS; plugins call `register_tier()` to extend.
# Unknown tiers pass validation with a once-per-process warning
# (LENIENT behaviour, matches SUPPORTED_SPEC_VERSIONS semantics).
#
# Rationale: closing the tier set to a Literal would force a schema
# bump on the first plugin that ships a new tier (Coq, Isabelle, F*,
# customer-proprietary DSL, etc). The registry lets the SDK ship one
# canonical type while remaining extensible without a schema churn
# per plugin.
KNOWN_TIERS: set[str] = {
    "lean_proved",      # Lean 4 kernel + axiom-audit-match closure
    "bmc_bounded",      # EBMC / Z3 bounded model check; bound_k matters
    "kind_unbounded",   # k-induction unbounded safety (ATH-491 label)
    "empirical",        # property tests + simulator + mutation sweep
}

_WARNED_UNKNOWN_TIERS: set[str] = set()


def register_tier(tier_name: str) -> None:
    """Register a new evidence tier name (plugin authors call at import).

    Duplicate registration is a no-op. Registered tiers pass
    `validate_tier()` without a warning.
    """
    KNOWN_TIERS.add(tier_name)


def validate_tier(tier_name: str) -> str:
    """Return `tier_name` if well-formed. Emit a once-per-process warning
    for unknown tiers; do not raise (LENIENT). Returns the original
    string so callers can chain in a round-trip assignment.

    This is the runtime counterpart to the JSON Schema's open string —
    the schema lets any non-empty string through; this helper surfaces
    drift to operators watching logs without hard-failing 1.0 consumers
    or plugin-registered tiers.
    """
    if not isinstance(tier_name, str) or not tier_name:
        raise ValueError(
            f"evidence_tier must be a non-empty string; got {tier_name!r}"
        )
    if tier_name not in KNOWN_TIERS and tier_name not in _WARNED_UNKNOWN_TIERS:
        _WARNED_UNKNOWN_TIERS.add(tier_name)
        logger.warning(
            "SpecV1.evidence_tier=%r is not in KNOWN_TIERS=%s. "
            "Accepting lenient (ATH-492 1.1 forward-compat); register "
            "via kairos.spec_v1.register_tier() if you intend to use "
            "this tier in production.",
            tier_name,
            sorted(KNOWN_TIERS),
        )
    return tier_name


# ─── SpecV1 pieces ────────────────────────────────────────────────────────


class _Budget(TypedDict):
    wall_seconds: int
    usd: float


class _Hypothesis(TypedDict):
    name: str
    type: str


class _AcceptanceCriteria(TypedDict, total=False):
    zero_sorry: bool
    axiom_audit_match: List[str]
    zero_counterexample: bool
    kernel_verify_py_exits_zero: bool
    rtl_ebmc_no_refutation: bool


class _RetryPolicy(TypedDict, total=False):
    max_iterations: int
    on_counterexample: OnCounterexample


class _Hints(TypedDict, total=False):
    banned_tactics: List[str]
    preferred_lemmas: List[str]
    free_text: str


class _PhaseModelOverrides(TypedDict, total=False):
    phase_neg1_opus: str
    phase_0_builder: str
    phase_1_properties: str
    phase_4_aristotle: str
    phase_5_audit: str


class _Operational(TypedDict, total=False):
    customer_note: str
    correlation_id: str
    submitted_by: str


class _Meta(TypedDict, total=False):
    """ATH-492 1.1: spec-level metadata with integrity hash support.

    `integrity_hash` + `integrity_version` mirror the IntentV1-side
    integrity primitive (kairos.spec.integrity, ATH-493 PR #107) so
    a customer-composed SpecV1 can be hash-locked before compile and
    the hash round-trips unchanged into the IntentV1 that reaches
    Stage G. Rationale: customer demo feedback — "once a
    spec is formalized, the fleet cannot mess with it" — applies at
    the spec layer too, not just the compiled-intent layer.

    Both fields are optional. An un-signed SpecV1 passes validation;
    callers that want the guarantee explicitly sign via
    `kairos.spec.integrity.sign()` after composition.
    """

    integrity_hash: str
    integrity_version: str


class _Verification(TypedDict, total=False):
    property_tests: bool
    simulator: bool
    mutation_sweep: bool
    bmc: bool
    lean_proof: bool
    triple_audit: bool


class _Thresholds(TypedDict, total=False):
    mutation_kill_rate_min: float
    bmc_k_bound: int
    property_test_count: int
    aristotle_wall_seconds: int
    audit_voices: int


class SpecV1(TypedDict, total=False):
    """Customer-facing spec. Required fields at top; defaulted below.

    `total=False` on the class, but the validator enforces the four
    required fields (`spec_version`, `target_file`, `target_name`,
    `vertical`, `budget`) at runtime. TypedDict syntax doesn't express
    required-vs-optional per field without `NotRequired` (3.11+); we
    keep this flat and rely on the JSON Schema for enforcement so the
    module imports on older Python.
    """

    spec_version: str              # required, "1.0" or "1.1"
    target_file: str               # required, path
    target_name: str               # required
    vertical: Vertical             # required
    budget: _Budget                # required

    priority: Priority
    acceptance_criteria: _AcceptanceCriteria
    retry_policy: _RetryPolicy
    known_hypotheses: List[_Hypothesis]
    hints: _Hints
    phase_model_overrides: _PhaseModelOverrides
    artifacts_expected: List[ArtifactName]
    verification: _Verification
    thresholds: _Thresholds
    operational: _Operational
    extension: dict                # per-vertical, schema-loose

    # 1.1 additions (ATH-492). All optional — 1.0 specs read without
    # these fields and continue to work. See
    # docs/spec-v1-migration-1.0-to-1.1.md for the full rationale.
    target_kind: TargetKind        # 1.0 implicit default derives from `vertical`; 1.1 makes it explicit
    evidence_tier: str             # open; validate via validate_tier()
    bound_k: int                   # customer-declared ceiling for bounded-verdict escalation (trigger 2)
    meta: _Meta                    # integrity-hash support, mirrors IntentV1.meta


# ─── IntentV1 — output of compile(SpecV1) ─────────────────────────────────
#
# IntentV1 is what mode_fleet consumes at runtime. It carries
# everything a phase runner needs to render its private prompt
# template without ever seeing spec.json. The compile step is a pure
# re-shape: no new information, no LLM calls, no template rendering.

class _IntentTarget(TypedDict):
    file: str
    name: str
    kind: TargetKind


class _IntentGoal(TypedDict, total=False):
    # One of these is set based on the spec's `acceptance_criteria`
    # shape — zero_sorry+axiom_audit_match is the lean flavour;
    # kernel_verify is the neuron flavour; rtl_ebmc is the sysverilog
    # flavour. The planner dispatches on which key is populated.
    lemma_closed: bool
    zero_sorry_axiom_match: List[str]
    kernel_verified_no_cex: bool
    rtl_fixed_no_refutation: bool


class IntentV1(TypedDict, total=False):
    """Neutral-intent contract. Pure data. No prompt strings.

    Builder-side `mode_fleet` ingests one of these and expands into
    per-phase prompts using its private templates. SDK ships the
    TypedDict + compile() so customer code can synthesise IntentV1 and
    pipe it to a signed-tarball builder.
    """

    intent_version: str            # "1.0", lockstep with SPEC_VERSION
    planner_role: str              # e.g. "lean_theorem_prover", "nki_kernel_porter"
    target: _IntentTarget
    goal: _IntentGoal
    hypotheses: List[_Hypothesis]
    budget: _Budget
    vertical: Vertical
    vertical_hints: dict           # copy of spec.extension[vertical], narrowed
    banned_tactics: List[str]
    preferred_lemmas: List[str]
    free_text_hint: str
    artifacts_expected: List[ArtifactName]
    retry_policy: _RetryPolicy
    phase_model_overrides: _PhaseModelOverrides
    operational: _Operational
    verification: _Verification    # which layers the fleet should run
    thresholds: _Thresholds        # per-layer depth / acceptance gates


# ─── Defaults used by the validator + TUI ─────────────────────────────────

DEFAULT_BUDGET: _Budget = {"wall_seconds": 1800, "usd": 6.00}
DEFAULT_PRIORITY: Priority = "medium"
DEFAULT_BANNED_TACTICS = ["native_decide", "decide", "sorry", "admit"]
DEFAULT_ARTIFACTS: List[ArtifactName] = ["proof", "counterexample", "bundle", "audit"]
DEFAULT_AXIOM_AUDIT = ["propext", "Classical.choice", "Quot.sound"]
DEFAULT_MAX_ITERATIONS: int = 3
DEFAULT_ON_COUNTEREXAMPLE: OnCounterexample = "auto_revise"

# ATH-358 2026-04-19: all layers on by default (full verification).
# Customer can toggle individual layers off for faster/cheaper runs.
DEFAULT_VERIFICATION: _Verification = {
    "property_tests": True,
    "simulator":      True,
    "mutation_sweep": True,
    "bmc":            True,
    "lean_proof":     True,
    "triple_audit":   True,
}
DEFAULT_THRESHOLDS: _Thresholds = {
    "mutation_kill_rate_min": 0.75,
    "bmc_k_bound":            10,
    "property_test_count":    100,
    "aristotle_wall_seconds": 1200,
    "audit_voices":           3,
}

REQUIRED_FIELDS = ("spec_version", "target_file", "target_name", "vertical", "budget")


# ─── Vertical → planner_role mapping ──────────────────────────────────────

VERTICAL_TO_PLANNER_ROLE: dict[Vertical, str] = {
    "bbr3":         "lean_theorem_prover_bbr3",
    "action_cred":  "lean_theorem_prover_action_cred",
    "sysverilog":   "ebmc_property_closer",
    "neuron":       "nki_kernel_porter",
    "bio":          "python_simulation_closer",
    "lean":         "lean_theorem_prover_generic",
    "custom":       "generic_closer",
}

# Extension → target_kind auto-detect for the TUI. Maps a target_file
# extension to the most likely TargetKind. The TUI still prompts for
# confirmation; auto-detect is only a hint.

EXTENSION_TO_KIND: dict[str, TargetKind] = {
    ".lean":   "theorem",
    ".sv":     "rtl_fix",
    ".svh":    "rtl_fix",
    ".v":      "rtl_fix",
    ".dfy":    "theorem",
    ".py":     "kernel",
    ".nki":    "kernel",
}


# Extension → vertical auto-detect. The TUI fills this; validator
# checks consistency.

EXTENSION_TO_VERTICAL: dict[str, Vertical] = {
    ".lean":   "lean",
    ".sv":     "sysverilog",
    ".svh":    "sysverilog",
    ".v":      "sysverilog",
    ".dfy":    "lean",
    ".py":     "neuron",
}
