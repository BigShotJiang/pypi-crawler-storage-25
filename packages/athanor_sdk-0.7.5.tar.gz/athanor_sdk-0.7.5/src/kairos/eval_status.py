"""eval_status — single-command status of all eval runs in an env directory.

Replaces the ad-hoc pgrep|jq|python combos previously needed to answer
"is my eval making progress?", "what's the current spread?", "did anything
crash?", "are tasks fresh or stale?".

Pure-Python, no extra deps. Used by the `athanor eval-status` CLI command.

History: lifted from kairos-builder/shared/scripts/eval-status.py 2026-04-11
during the SDK migration. The shared/ copy can be deleted once all envs are
migrated to use `athanor eval-status` directly.
"""

import json
import subprocess
import time
from pathlib import Path
from typing import Any, Iterable

from kairos.security.env_allowlist import safe_env_for_cedar


# ANSI colors. Module-level so tests can patch them off.
GREEN = "\033[32m"
YELLOW = "\033[33m"
RED = "\033[31m"
GRAY = "\033[90m"
BOLD = "\033[1m"
NC = "\033[0m"


def find_active_evals() -> dict[str, dict[str, Any]]:
    """Return {run_file_basename: {pid, model, etime}} for live evaluate.py procs.

    Walks `pgrep -af "evaluate.py"` and parses each line to extract the model
    and run-file path. Keys on basename so the result joins cleanly with
    run files in the runs/ directory.

    Returns empty dict if pgrep finds no matches (or pgrep is unavailable —
    e.g. on Windows or non-Linux CI).
    """
    try:
        out = subprocess.check_output(
            ["pgrep", "-af", "evaluate.py"], text=True,
            env=safe_env_for_cedar(),
         timeout=300,)
    except (subprocess.CalledProcessError, FileNotFoundError):
        return {}
    active: dict[str, dict[str, Any]] = {}
    for line in out.strip().split("\n"):
        if not line or "/bin/bash" in line:
            continue
        parts = line.split(maxsplit=1)
        if len(parts) < 2:
            continue
        pid, cmd = parts
        model = None
        run_file = None
        toks = cmd.split()
        for i, t in enumerate(toks):
            if t == "--model" and i + 1 < len(toks):
                model = toks[i + 1]
            if t in ("-o", "--output") and i + 1 < len(toks):
                run_file = Path(toks[i + 1]).name
        if not run_file:
            continue
        try:
            etime = subprocess.check_output(
                ["ps", "-p", pid, "-o", "etime="], text=True,
                env=safe_env_for_cedar(),
             timeout=300,).strip()
        except (subprocess.CalledProcessError, FileNotFoundError):
            etime = "?"
        active[run_file] = {"pid": pid, "model": model, "etime": etime}
    return active


def load_run_file(path: Path) -> dict[str, Any]:
    """Read a run file. Returns {} on JSON error or missing file."""
    try:
        return dict(json.loads(path.read_text()))
    except Exception:  # noqa: BLE001 — guard returns empty container on any error
        return {}


def summarize_run(run_file: Path) -> dict[str, Any]:
    """Compute summary stats for one run file. Pure function — no IO except read.

    Returns:
        {
            "name": basename,
            "tasks": int (count),
            "mean": float,
            "below_05": int,
            "rejected": int (count of disallowed_tactic results),
            "mtime": float (epoch seconds),
            "age_seconds": int (seconds since modified),
            "results": list (raw results, for verbose mode),
        }
    """
    d = load_run_file(run_file)
    results = d.get("results", []) or []
    scores = [r.get("score", 0) or 0 for r in results]
    n = len(scores)
    return {
        "name": run_file.name,
        "tasks": n,
        "mean": sum(scores) / n if n else 0.0,
        "below_05": sum(1 for s in scores if s < 0.5),
        "rejected": sum(
            1 for r in results
            if (r.get("scoring_metadata", {}) or {}).get("cheat_category")
            == "disallowed_tactic"
        ),
        "mtime": run_file.stat().st_mtime if run_file.exists() else 0,
        "age_seconds": int(time.time() - run_file.stat().st_mtime) if run_file.exists() else 0,
        "results": results,
    }


def format_age(seconds: int) -> tuple[str, str]:
    """Return (color, text) for an age in seconds."""
    if seconds < 60:
        return GREEN, f"{seconds}s ago"
    if seconds < 3600:
        return YELLOW, f"{seconds // 60}m ago"
    return GRAY, f"{seconds // 3600}h ago"


def render_one(summary: dict[str, Any], active: dict[str, Any], verbose: bool = False) -> Iterable[str]:
    """Yield lines (no trailing newlines) for one run file's status block.

    Generator so tests can collect lines without IO. Caller does '\n'.join.
    """
    name = summary["name"]
    if summary["tasks"] == 0:
        yield f"  {RED}{name}{NC}: empty / failed to load"
        return

    age_color, age_str = format_age(summary["age_seconds"])
    is_active = name in active
    marker = (
        f"{GREEN}● ALIVE{NC} pid={active[name]['pid']} etime={active[name]['etime']}"
        if is_active else ""
    )

    yield (
        f"  {BOLD}{name}{NC}: {summary['tasks']} tasks, "
        f"mean={summary['mean']:.2f}, "
        f"{summary['below_05']}/{summary['tasks']} below 0.5, "
        f"{summary['rejected']} ban-rejected, "
        f"{age_color}touched {age_str}{NC}  {marker}".rstrip()
    )

    if verbose:
        sorted_r = sorted(summary["results"], key=lambda x: x.get("score", 0))
        for r in sorted_r:
            s = r.get("score", 0) or 0
            cat = (r.get("scoring_metadata", {}) or {}).get("cheat_category") or ""
            tag = f"[{cat}]" if cat else ""
            tc = r.get("tool_calls_total", 0) or 0
            color = GREEN if s >= 0.5 else (YELLOW if s > 0 else RED)
            yield f"    {color}{s:.2f}{NC}  {r['task']:32s} calls={tc:<3} {tag}"
        yield ""


def render_status(runs_dir: Path, verbose: bool = False) -> Iterable[str]:
    """Top-level renderer. Yields all output lines.

    Pure-ish (only file IO + pgrep). Tests can capture by collecting the
    iterable into a list.
    """
    if not runs_dir.exists():
        yield f"{RED}error: {runs_dir} does not exist{NC}"
        return

    run_files = sorted(runs_dir.glob("*_run1.json"))
    if not run_files:
        yield f"{YELLOW}no run files in {runs_dir}{NC}"
        return

    active = find_active_evals()
    yield f"{BOLD}eval-status{NC}: {len(run_files)} run files, {len(active)} active eval(s)"
    yield ""
    for f in run_files:
        s = summarize_run(f)
        yield from render_one(s, active, verbose=verbose)
