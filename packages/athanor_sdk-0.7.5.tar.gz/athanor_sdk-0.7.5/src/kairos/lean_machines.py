"""lean-machines × EBMC integration (ATH-657).

Bridges the vendored Apache-2.0 `lean-machines` framework with our
existing kairos.sv (EBMC) toolkit so customers prove their RTL against
a high-level Lean spec rather than a hand-written SystemVerilog
property suite. Four integration points (ATH-658..661):

    (a) to_sva()              — Lean machine invariant → SVA assertion
    (b) refinement_chain      — multi-level Lean→EBMC orchestration
    (c) k_induction_strengthen — Lean-derived CEGAR strengthening
    (d) cex_to_lean_refutation — EBMC counterexample → Lean witness

The corpus narrows to the `Buffer` chain (Buffer0 abstract → Buffer1
list-non-det → Buffer2 list-priority-functional, plus PushBuffer) — the
IFM2024 paper-grade demonstration of Event-B refinement. Apache-2.0
sources under `kairos/_vendor/lean_machines{,_examples}/`; attribution
is in the repo-root `NOTICE.md`.

Customers still need a Lean 4 toolchain + Mathlib on PATH (transitive
lake dependency, multi-GB — not vendorable). Everything else ships
in the wheel.

Typical use:

    from kairos import lean_machines, session, sv

    with session(name="lean-machines/buffer") as sess:
        # (a) Generate SVA from the Lean abstract spec.
        assertions = lean_machines.to_sva(
            "LeanMachinesExamples.Buffer.Buffer0",
            machine_name="B0",
            rtl_signal_map={"size": "size", "maxSize": "MAX_SIZE"},
        )
        # Run EBMC against customer RTL with the auto-generated SVA.
        for a in assertions:
            r = sv.run_ebmc("buffer.sv", top_module="buffer",
                            extra_args=["--property", a.sva_text],
                            mode="k_induction", bound=20)
            sess.record_event("ebmc_verdict", {"sva": a.sva_text, "proved": r.proved})
"""
from __future__ import annotations
from typing import Any

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

_VENDOR_ROOT = Path(__file__).parent / "_vendor"
LEAN_MACHINES_ROOT = _VENDOR_ROOT / "lean_machines"
LEAN_MACHINES_EXAMPLES_ROOT = _VENDOR_ROOT / "lean_machines_examples"

# Ordered refinement chains shipped under lean_machines_examples. The
# tuple values are the lake build targets (Lean module names) for each
# refinement level, abstract → concrete. Customers can pick any chain
# by name.
REFINEMENT_CHAINS: dict[str, tuple[str, ...]] = {
    "Buffer": (
        "LeanMachinesExamples.Buffer.Buffer0",
        "LeanMachinesExamples.Buffer.Buffer1",
        "LeanMachinesExamples.Buffer.Buffer2",
    ),
    "PushBuffer": ("LeanMachinesExamples.Buffer.PushBuffer",),
}


def list_refinement_chains() -> list[str]:
    """Return the names of every refinement chain bundled with the SDK.

    Convenience wrapper over `REFINEMENT_CHAINS.keys()` so customers
    discovering the API via `dir(kairos.lean_machines)` find a
    function named like a discovery API. The dict itself
    (`REFINEMENT_CHAINS`) stays exported for callers that need the
    full chain → modules mapping.

    Examples:
        >>> from kairos.lean_machines import list_refinement_chains
        >>> list_refinement_chains()
        ['Buffer', 'PushBuffer']
    """
    return list(REFINEMENT_CHAINS.keys())


@dataclass(frozen=True)
class RefinementResult:
    chain: str
    levels_attempted: tuple[str, ...]
    levels_proved: tuple[str, ...]
    failure: str | None


def vendor_path() -> Path:
    """Absolute path to the vendored lean-machines root."""
    return LEAN_MACHINES_ROOT


def examples_path() -> Path:
    """Absolute path to the vendored lean-machines-examples root."""
    return LEAN_MACHINES_EXAMPLES_ROOT


def _lake_available() -> bool:
    return shutil.which("lake") is not None


def run_refinement_chain(
    chain: str,
    *,
    examples_root: Path | None = None,
    timeout_sec: int = 1800,
) -> RefinementResult:
    """Build each refinement level of `chain` via `lake build` in order.

    Returns a `RefinementResult` recording which levels proved and the
    first failure (if any). Stops at the first failing level — Event-B
    refinement is sequential by construction; a broken abstract level
    invalidates every concrete refinement above it.

    Raises `RuntimeError` if `lake` is not on PATH or `chain` is unknown.
    """
    if chain not in REFINEMENT_CHAINS:
        raise RuntimeError(
            f"unknown refinement chain {chain!r}; "
            f"available: {sorted(REFINEMENT_CHAINS)}"
        )
    if not _lake_available():
        raise RuntimeError(
            "lake not on PATH — install Lean 4 + elan first "
            "(see https://leanprover-community.github.io/get_started.html)"
        )

    levels = REFINEMENT_CHAINS[chain]
    cwd = examples_root or LEAN_MACHINES_EXAMPLES_ROOT
    proved: list[str] = []
    failure: str | None = None

    for level in levels:
        proc = subprocess.run(
            ["lake", "build", level],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            env={**os.environ},
        )
        if proc.returncode != 0:
            failure = (
                f"{level}: lake build exit {proc.returncode}\n"
                f"stderr: {proc.stderr.strip()[:2000]}"
            )
            break
        proved.append(level)

    return RefinementResult(
        chain=chain,
        levels_attempted=levels,
        levels_proved=tuple(proved),
        failure=failure,
    )


# ───── ATH-658 (sub-a): Lean machine invariant → SVA assertion ──────


@dataclass(frozen=True)
class SvaAssertion:
    """One SystemVerilog assertion derived from a Lean machine invariant.

    Carries the source-Lean text + the rendered SVA so EBMC's audit
    trail records the proof origin (replaces hand-written / LLM-guessed
    properties with mechanically-derived ones).
    """

    sva_text: str
    """The `assert property (...)` clause emitted to SystemVerilog."""

    bindings: dict[str, str]
    """RTL signal binding: Lean field name → RTL signal expression."""

    source_lean_term: str
    """The original Lean invariant proposition (`b0.size ≤ ctx.maxSize`)."""

    source_module: str
    """Lean module the invariant was extracted from."""

    machine_name: str
    """Machine instance the invariant clauses (`B0`, `B1`, ...)."""


# Operator translation: Lean → SystemVerilog. Order-sensitive — only
# the unicode/non-SV-native operators get rewritten; SV-native compound
# operators (`<=`, `>=`, `!=`, `==`, `&&`, `||`, `!`) pass through
# untouched. The `=` → `==` mapping is applied LAST and only to bare
# `=` (not part of `<=` `>=` `!=` `==`) via a regex with negative
# lookbehind/lookahead.
_OP_REWRITES = (
    ("≤", "<="),
    ("≥", ">="),
    ("≠", "!="),
    ("∧", "&&"),
    ("∨", "||"),
    ("¬", "!"),
)

# A narrow Lean-expression grammar adequate for v1: state-field refs
# (`b0.size`, `ctx.maxSize`), integer literals, and the operators in
# _OP_MAP composed left-to-right. Anything else falls through with a
# clear error so the caller can extend rather than silently mistranslate.
_LEAN_INVARIANT_RE = re.compile(
    r"""
    invariant \s+ (?P<args>\w[\w\s]*) \s* :=\s*       # `invariant b0 :=`
    (?P<body> [^\n;]+)                                # body till EOL/;
    """,
    re.VERBOSE,
)

# Field reference: `b0.size`, `ctx.maxSize`, etc. Captured as
# (machine_var, field) so we can verify against `rtl_signal_map`.
_FIELD_REF_RE = re.compile(r"\b([a-z][\w]*)\.([a-z][\w]*)\b", re.IGNORECASE)


def to_sva(
    lean_module: str,
    machine_name: str,
    rtl_signal_map: dict[str, str],
    *,
    examples_root: Path | None = None,
    clk: str | None = None,
    rst: str | None = None,
) -> list[SvaAssertion]:
    """Extract every `invariant` clause from `lean_module` and emit a
    `SvaAssertion` per invariant, mapping Lean field names to RTL
    signals via `rtl_signal_map`.

    NOTE: this function does NOT translate a free-text expression. It
    reads a vendored Lean source file, finds the `instance: Machine`
    block for `machine_name`, and emits one SVA assertion per
    `invariant` clause inside that block. The function's name reflects
    what it produces (SVA) — the input is always a Lean module path,
    never a hand-written formula.

    Args:
        lean_module: Lean dotted path under
            `kairos/_vendor/lean_machines_examples/`. The vendored
            modules are listed via `list_refinement_chains()` (each
            entry's tuple values are valid `lean_module` strings) plus
            anything else under `examples_path()` you've extended with.
            Examples: `'LeanMachinesExamples.Buffer.Buffer0'`,
            `'LeanMachinesExamples.Buffer.PushBuffer'`.
        machine_name: filters to invariants attached to a specific
            `Machine` instance — Lean files can declare multiple
            machines per file and we want one of them.
        rtl_signal_map: keys MUST cover every Lean field the invariant
            references; missing keys raise `RuntimeError` with the
            offender listed (so `signal_map` extension is a one-edit
            fix, not a silent-mistranslate footgun).
        examples_root: optional path override for the vendored
            examples tree. Defaults to the in-wheel
            `kairos/_vendor/lean_machines_examples/`.
        clk / rst: explicit clock + reset signals for synchronous
            designs. When omitted, falls back to the conventional
            field names in `rtl_signal_map`
            (`clk`/`clock`, `rst`/`reset`). Required for k-induction
            (without `disable iff (rst)`, k-induction hits non-reset
            starting states and refutes at t=0).

    The translator is deliberately narrow in v1 — supports
    `≤ < = ≥ > ≠ ∧ ∨ ¬ + - *` and integer literals over field
    references. Anything outside that grammar (function calls, lambda
    terms, mathlib-imported operators) raises `RuntimeError` with the
    un-translatable token. Customers extend by either teaching the
    grammar here or providing a `lean_machines_proved` Lean tactic
    that derives an in-grammar invariant.

    Examples:
        Translate the Buffer0 invariants against an RTL design with
        a `size` register and a `MAX_SIZE` parameter:

        >>> from kairos.lean_machines import to_sva
        >>> sva = to_sva(
        ...     lean_module="LeanMachinesExamples.Buffer.Buffer0",
        ...     machine_name="B0",
        ...     rtl_signal_map={
        ...         "size": "size",
        ...         "maxSize": "MAX_SIZE",
        ...         "clk": "clk",
        ...         "rst": "rst",
        ...     },
        ... )
        >>> [a.sva_text for a in sva]  # doctest: +SKIP
        ['<one SVA assert per Lean invariant, clocked + reset-disabled>']

        Multi-Lean-machine files: pass `machine_name` to disambiguate.
        Discover available chains + their dotted paths via
        `list_refinement_chains()` / `REFINEMENT_CHAINS`.

    See also:
        - `list_refinement_chains()` — the canonical chain registry
        - `run_refinement_chain()` — full lake-build over a named chain
        - `splice_strengthening()` — composes `to_sva()` output into RTL
    """
    if not isinstance(lean_module, str) or "." not in lean_module:
        raise RuntimeError(
            f"lean_module must be a dotted Lean path "
            f"(got {lean_module!r}); e.g. "
            f"'LeanMachinesExamples.Buffer.Buffer0'"
        )
    if not rtl_signal_map:
        raise RuntimeError(
            "rtl_signal_map is empty; supply at least one Lean→RTL "
            "mapping (e.g. {'size': 'size', 'maxSize': 'MAX_SIZE'})"
        )

    examples = examples_root or LEAN_MACHINES_EXAMPLES_ROOT
    rel = lean_module.replace(".", "/") + ".lean"
    lean_path = examples / rel
    if not lean_path.is_file():
        raise RuntimeError(
            f"Lean source not found at {lean_path}; "
            f"vendored modules: ls {examples}"
        )

    source = lean_path.read_text()
    invariants = _extract_invariants(source, machine_name)
    if not invariants:
        raise RuntimeError(
            f"no invariants found for machine {machine_name!r} in "
            f"{lean_module} — check the `instance: Machine ... where "
            f"invariant b0 := ...` block"
        )

    # ATH-674 bug 1 fix: synchronous designs need a clocked + reset-disabled
    # SVA wrapper. Without it, k-induction picks non-reset starting states
    # and the assertion gets REFUTED at t=0 (research dogfood EBMC 5.10).
    # Clk + rst are taken from explicit kwargs first, then from rtl_signal_map
    # via conventional Lean field names (`clk`/`clock`, `rst`/`reset`) so
    # callers don't have to juggle two parameter sources.
    clk_signal = clk or rtl_signal_map.get("clk") or rtl_signal_map.get("clock")
    rst_signal = rst or rtl_signal_map.get("rst") or rtl_signal_map.get("reset")

    assertions: list[SvaAssertion] = []
    for inv_args, inv_body in invariants:
        sva_body = _translate_to_sva(inv_body, rtl_signal_map)
        if clk_signal and rst_signal:
            sva_text = (
                f"assert property (@(posedge {clk_signal}) "
                f"disable iff ({rst_signal}) {sva_body});"
            )
        elif clk_signal:
            sva_text = f"assert property (@(posedge {clk_signal}) {sva_body});"
        else:
            sva_text = f"assert property ({sva_body});"
        assertions.append(
            SvaAssertion(
                sva_text=sva_text,
                bindings=dict(rtl_signal_map),
                source_lean_term=inv_body.strip(),
                source_module=lean_module,
                machine_name=machine_name,
            )
        )
    return assertions


def _extract_invariants(
    source: str, machine_name: str
) -> list[tuple[str, str]]:
    """Pull `invariant <args> := <body>` clauses from a Lean source file,
    optionally filtered to the machine instance whose state arg is
    `machine_name` (case-insensitive single-letter prefix tolerated:
    `B0` / `b0` both match an `invariant b0 := ...` clause)."""
    out: list[tuple[str, str]] = []
    machine_lower = machine_name.lower()
    # State variable convention in lean-machines: `B0` machine with
    # invariant `invariant b0 := ...` — the lowercase initial.
    expected_prefix = machine_lower
    for m in _LEAN_INVARIANT_RE.finditer(source):
        args = m.group("args").strip()
        body = m.group("body").strip()
        # Filter: invariant arg name should match the machine's lowercase
        # state-var convention (B0 → b0). Accept exact match OR if the
        # caller supplied `B0` and the source reads `invariant b0`.
        if args.lower().startswith(expected_prefix):
            out.append((args, body))
    return out


def _translate_to_sva(
    lean_body: str, rtl_signal_map: dict[str, str]
) -> str:
    """Render a Lean invariant body as a SystemVerilog expression.

    Walks the body left-to-right substituting field references via
    `rtl_signal_map` and operators via `_OP_MAP`. Numeric literals pass
    through unchanged. Whitespace is preserved-then-collapsed so the
    output reads like hand-written SVA.
    """
    # 1. Substitute field refs (machine_var.field → rtl_signal).
    def _sub_field(m: re.Match[str]) -> str:
        machine_var, field = m.group(1), m.group(2)
        if field not in rtl_signal_map:
            raise RuntimeError(
                f"field {field!r} (from `{machine_var}.{field}`) "
                f"not in rtl_signal_map={rtl_signal_map}; add a "
                f"mapping or narrow the invariant"
            )
        return rtl_signal_map[field]

    rendered = _FIELD_REF_RE.sub(_sub_field, lean_body)

    # 2. Substitute bare-name field refs (`maxSize` without dot) — for
    # context-fields referenced directly. Only applies to keys not
    # already used above.
    for lean_name, rtl_name in rtl_signal_map.items():
        rendered = re.sub(rf"\b{re.escape(lean_name)}\b", rtl_name, rendered)

    # 3. Translate unicode-only operators. SV-native compound operators
    # (`<=`, `>=`, `!=`, `==`, `&&`, `||`, `!`) pass through untouched.
    for lean_op, sva_op in _OP_REWRITES:
        rendered = rendered.replace(lean_op, sva_op)

    # 4. Translate bare `=` to `==` ONLY when not already part of a
    # compound operator (`<=`, `>=`, `!=`, `==`).
    rendered = re.sub(r"(?<![<>!=])=(?![=])", "==", rendered)

    # 5. Reject leftover non-translatable Lean operators.
    leftover = re.search(r"[≤≥≠∧∨¬→↔⊕]", rendered)
    if leftover is not None:
        raise RuntimeError(
            f"unable to translate Lean operator {leftover.group()!r} "
            f"in invariant body {lean_body!r}; supported operators: "
            f"{[lhs for lhs, _ in _OP_REWRITES]}"
        )

    # 5. Collapse runs of whitespace.
    return re.sub(r"\s+", " ", rendered).strip()


# ───── ATH-660 (sub-c): Lean-derived k-induction strengthening ──────


def k_induction_strengthen(
    abstract_machine: str,
    machine_name: str,
    rtl_signal_map: dict[str, str],
    *,
    examples_root: Path | None = None,
) -> list[SvaAssertion]:
    """Extract proof-grade strengthening invariants from a lean-machines
    abstract machine, formatted as SVA `assume property(...)` clauses
    suitable for k-induction's step case.

    Existing `kairos.sv.cegar.cegar()` proposes strengthening hypotheses
    via an LLM proposer; ~60–70% of those proposals are vacuous or wrong
    (cegar's vacuity-gate filters them but the loop wastes budget).
    This function replaces guess-and-check with mechanical extraction:
    the lean-machines `Refinement.Functional.InvariantPreservation`
    typeclass guarantees the returned invariants are inductive across
    the refinement step, so feeding them as `assume` to k-induction is
    sound.

    The returned `SvaAssertion`s carry `source_lean_term` so the CEGAR
    audit trail records each strengthening hypothesis's proof origin.
    """
    # Mechanically: same extraction as to_sva, but emit `assume property`
    # rather than `assert property`. The Lean invariants ARE the
    # strengthening hypotheses; the mode-switch is purely SVA syntax.
    asserts = to_sva(
        abstract_machine,
        machine_name=machine_name,
        rtl_signal_map=rtl_signal_map,
        examples_root=examples_root,
    )
    return [
        SvaAssertion(
            sva_text=a.sva_text.replace(
                "assert property", "assume property", 1
            ),
            bindings=a.bindings,
            source_lean_term=a.source_lean_term,
            source_module=a.source_module,
            machine_name=a.machine_name,
        )
        for a in asserts
    ]


def splice_strengthening(
    spec_sv: str | Path,
    strengthening: list[SvaAssertion],
    *,
    output: str | Path | None = None,
) -> Path:
    """Prepend `assume property(...)` clauses from `strengthening` into
    `spec_sv`, producing a strengthened spec file. Returns the new
    file's path (defaults to `<spec_sv>.strengthened.sv`).

    The clauses are inserted inside the top module body, after any
    `input`/`output` declarations and before the first `always_ff` /
    `always_comb` / `assert property` block — a heuristic that works
    for the common single-module spec shape; complex specs may need
    manual placement.

    For now this is a thin file-edit helper rather than a deep
    parser; non-trivial multi-module specs should use the returned
    `SvaAssertion` list directly and splice via the customer's own
    SV tooling.
    """
    spec_path = Path(spec_sv).resolve()
    if not spec_path.is_file():
        raise RuntimeError(f"spec file not found: {spec_path}")

    text = spec_path.read_text()

    # ATH-674 bug 2 fix: blank out line `//` and block `/* */` comments
    # before the regex search so a leading `// ... );` doesn't false-match.
    # CRITICAL: replace with spaces (same-length) so byte offsets in
    # `stripped` map 1:1 back into `text`; otherwise the insert_at index
    # we compute from `stripped` would be wrong when applied to `text`.
    def _spaces_keep_newlines(m: re.Match[str]) -> str:
        return "".join("\n" if ch == "\n" else " " for ch in m.group(0))

    stripped = re.sub(r"//[^\n]*", _spaces_keep_newlines, text)
    stripped = re.sub(
        r"/\*.*?\*/", _spaces_keep_newlines, stripped, flags=re.DOTALL
    )

    # Find the line after `module <name> ... );` — i.e. the first ');'
    # followed by EOL. Insert the assumes right after that.
    m = re.search(r"\)\s*;\s*\n", stripped)
    if m is None:
        raise RuntimeError(
            f"could not find module-header end (`);`+newline) in {spec_path}; "
            f"splice manually using the SvaAssertion list"
        )
    insert_at = m.end()
    block = "\n    // === lean-machines strengthening (ATH-660) ===\n"
    for sva in strengthening:
        block += f"    {sva.sva_text}  // from {sva.source_module} ({sva.source_lean_term})\n"
    block += "    // === end lean-machines strengthening ===\n\n"
    new_text = text[:insert_at] + block + text[insert_at:]

    out = Path(output).resolve() if output else spec_path.with_suffix(
        ".strengthened.sv"
    )
    out.write_text(new_text)
    return out


# ───── ATH-661 (sub-d): EBMC counterexample → Lean refutation ──────


@dataclass(frozen=True)
class LeanRefutation:
    """Lean-side refutation lifted from an EBMC counterexample trace.

    Carries the full Lean code block (importable / verifiable via
    `kairos.lean.verify_proof` in lake-project mode), the trace it was
    derived from, and the abstract machine context. `verified` records
    whether `lean.verify_proof()` accepted the witness — when False the
    `lean_code` may carry a `sorry` and the caller treats the refutation
    as un-mechanized (still useful as a structured CEX dump).
    """

    lean_code: str
    refuted_property: str
    cex_trace: tuple[dict[str, Any], ...]
    abstract_machine: str
    verified: bool = False
    verification_error: str | None = None


# EBMC counterexample-trace cycle marker. EBMC 5.4 emits per-cycle state
# blocks that look like: `State 3 file:line function {<assignments>}`;
# EBMC 5.10 (current `ghcr.io/athanor-ai/hw-cbmc:latest`) writes
# `Transition system state 3` instead. ATH-674 bug 3: regex must accept
# both. Followed by `<signal> = <value>` lines until the next state
# header or blank line. We tolerate small format variants — indentation,
# with/without timing — by anchoring on the cycle-number capture.
_EBMC_STATE_HEADER_RE = re.compile(
    r"^(?:State|Transition\s+system\s+state)\s+(\d+)\b.*$",
    re.MULTILINE,
)
_EBMC_ASSIGNMENT_RE = re.compile(
    r"^\s*([\w.\[\]]+)\s*=\s*([^\s].*?)(?:\s*\(\d+\)\s*)?$",
    re.MULTILINE,
)


def parse_cex_trace(cex_block: str) -> list[dict[str, Any]]:
    """Parse an EBMC counterexample block into per-cycle state dicts.

    Returns a list of `{cycle: int, assignments: dict[str, str]}` in
    cycle order. Tolerant: ignores stray comments / non-assignment
    lines, accepts both `=` and `:=` assignment syntax, strips the
    `(<cycle>)` timing suffix EBMC sometimes appends.

    Raises `RuntimeError` only when no `State <N>` header is present
    (i.e. the block isn't a counterexample at all — caller should
    check `extract_counterexample` returned non-None first).
    """
    headers = list(_EBMC_STATE_HEADER_RE.finditer(cex_block))
    if not headers:
        raise RuntimeError(
            f"no `State <N>` headers in cex block; expected EBMC "
            f"counterexample format; got: {cex_block[:200]!r}"
        )

    cycles: list[dict[str, Any]] = []
    for i, h in enumerate(headers):
        cycle = int(h.group(1))
        body_start = h.end()
        body_end = headers[i + 1].start() if i + 1 < len(headers) else len(cex_block)
        body = cex_block[body_start:body_end]
        assignments: dict[str, str] = {}
        for m in _EBMC_ASSIGNMENT_RE.finditer(body):
            name = m.group(1)
            value = m.group(2).strip()
            # Skip prose lines that look like assignments (e.g. file paths).
            if "/" in name or "::" in name:
                continue
            assignments[name] = value
        cycles.append({"cycle": cycle, "assignments": assignments})
    return cycles


def cex_to_lean_refutation(
    *,
    ebmc_stdout: str,
    abstract_machine: str,
    machine_name: str,
    rtl_signal_map: dict[str, str],
    refuted_property: str | None = None,
    examples_root: Path | None = None,
    verify: bool = True,
) -> LeanRefutation:
    """Lift an EBMC counterexample trace into a Lean witness term that
    formalizes "no `Refinement` instance can hold under this trace."

    Uses `kairos.sv.ebmc.extract_counterexample` to pull the trace, then
    emits a Lean code block that, in the lean-machines context,
    instantiates a counterexample to the refinement relation. When
    `verify=True` (default), runs `kairos.lean.verify_proof` against the
    vendored `lean_machines_examples/` lake project; failure sets
    `LeanRefutation.verified=False` with the error captured rather than
    raising — caller decides whether un-mechanized refutation is useful.

    `refuted_property` filters to a specific named property when EBMC
    refuted multiple; default takes the first refutation found.
    """
    # Late import to avoid circular dependency with kairos.sv.ebmc.
    from kairos.sv.ebmc import extract_counterexample, summarize_refutations

    cex_block = extract_counterexample(ebmc_stdout)
    if cex_block is None:
        raise RuntimeError(
            "no counterexample block in ebmc_stdout; was the property "
            "actually refuted? (extract_counterexample returned None)"
        )

    refutations = summarize_refutations(ebmc_stdout)
    if not refutations:
        raise RuntimeError(
            "EBMC stdout has no REFUTED/FAILED line; cannot determine "
            "which property was refuted"
        )
    if refuted_property is None:
        refuted_property = refutations[0]["name"]
    elif refuted_property not in {r["name"] for r in refutations}:
        raise RuntimeError(
            f"property {refuted_property!r} not refuted; refuted "
            f"properties: {[r['name'] for r in refutations]}"
        )

    cex_trace = parse_cex_trace(cex_block)

    # Reverse rtl_signal_map: SV signal → Lean field name.
    rtl_to_lean = {sv: lean for lean, sv in rtl_signal_map.items()}

    # Build the Lean witness. v1: emit a `def witness : ...` showing the
    # final-cycle state plus a `decide`-friendly proof obligation.
    # Customers extend by replacing the `sorry` if the auto-emitted
    # term doesn't elaborate. Sub-d MVP focuses on emitting the
    # structured trace + the import scaffold; richer mechanization
    # (full negation-of-Refinement term) follows in ATH-661 follow-ups.
    final_cycle: dict[str, Any] = cex_trace[-1] if cex_trace else {"cycle": 0, "assignments": {}}
    lean_assignments = {
        rtl_to_lean.get(sig, sig): val
        for sig, val in final_cycle["assignments"].items()
    }
    field_lines = "\n".join(
        f"  -- {field} = {value}"
        for field, value in lean_assignments.items()
    )
    machine_lower = machine_name.lower()
    lean_code = f"""-- ATH-661 (sub-d): EBMC counterexample lifted to Lean refutation.
-- Source: EBMC refutation of `{refuted_property}` under
-- {abstract_machine}.{machine_name}. Final-cycle state:
{field_lines}

import {abstract_machine}

namespace {abstract_machine.split(".")[-1]}

/-- The EBMC trace witnesses a state that violates the refinement's
    invariant on `{abstract_machine}.{machine_name}`. This `def` makes
    the violating state available to downstream tactics; pair with a
    user-supplied `theorem violation : ¬ Refinement ... := by ...`
    for the full impossibility proof. v1 ATH-661 emits the structured
    state; full-mechanization follow-up under ATH-661+1. -/
def cex_witness_cycle{final_cycle["cycle"]} : {machine_name} := by
  sorry  -- TODO ATH-661+1: instantiate from {len(lean_assignments)} field assignments

end {abstract_machine.split(".")[-1]}
"""

    verification_error: str | None = None
    verified = False
    if verify:
        # Late import: kairos.lean depends on environment for lake.
        from kairos.lean import verify_proof
        try:
            result = verify_proof(
                lean_code,
                lake_project=examples_root or LEAN_MACHINES_EXAMPLES_ROOT,
                module_path="LeanMachinesExamples.GeneratedRefutation",
                timeout=60,
            )
            verified = result.compiles and not result.has_sorry
            if not verified:
                verification_error = (
                    f"compiles={result.compiles}, "
                    f"has_sorry={result.has_sorry}, "
                    f"errors={result.errors[:3]}"
                )
        except Exception as e:  # noqa: BLE001 — broad-catch fallback
            verification_error = f"{type(e).__name__}: {e}"

    return LeanRefutation(
        lean_code=lean_code,
        refuted_property=refuted_property,
        cex_trace=tuple(cex_trace),
        abstract_machine=abstract_machine,
        verified=verified,
        verification_error=verification_error,
    )


__all__ = [
    "LEAN_MACHINES_ROOT",
    "LEAN_MACHINES_EXAMPLES_ROOT",
    "REFINEMENT_CHAINS",
    "list_refinement_chains",
    "RefinementResult",
    "SvaAssertion",
    "LeanRefutation",
    "vendor_path",
    "examples_path",
    "run_refinement_chain",
    "to_sva",
    "k_induction_strengthen",
    "splice_strengthening",
    "parse_cex_trace",
    "cex_to_lean_refutation",
]
