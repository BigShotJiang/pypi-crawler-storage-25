"""ATH-1446: planning stage full workflow for kairos optimize & repair."""
from __future__ import annotations
import sys, select
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from kairos.plan import OptimizePlan, RepairPlan, PlanResult
from kairos.review import review
from kairos.transforms import REMOVE_ONLY, ADD_FOR_POWER
from kairos.memory import recall


def plan_optimize(block_path: str | Path) -> OptimizePlan:
    """Analyze RTL block, generate memory-aware optimization strategy."""
    target = Path(block_path)
    if not target.is_file():
        return OptimizePlan(block_name=target.stem, block_class="unknown",
                            line_count=0, port_count=0, is_sequential=False, risks=["file not found"])
    lines = target.read_text().splitlines()
    lc = len(lines)
    is_seq = any("posedge" in l or "negedge" in l for l in lines)
    ports = sum(1 for l in lines if any(k in l for k in ("input", "output", "inout")))
    mem = recall(target.stem)
    failed = {f["transform"] for f in mem.get("failures", []) if f.get("transform")}
    best_prior = mem.get("best_result")
    applicable = [t for t in REMOVE_ONLY if t.value not in failed]
    if is_seq:
        applicable += [t for t in ADD_FOR_POWER if t.value not in failed]
    if best_prior is not None:
        expected, conf = best_prior, "high"
    elif lc < 50:
        expected, conf = -5.0, "high"
    elif lc < 200:
        expected, conf = -3.0, "medium"
    else:
        expected, conf = -1.0, "low"
    bc = "small" if lc < 50 else ("medium" if lc < 200 else "large")
    risks = ["file exceeds review limit"] if lc > 500 else []
    if ports > 20: risks.append("high port count — tight interface constraint")
    if failed: risks.append(f"{len(failed)} transforms excluded (prior failures)")
    return OptimizePlan(block_name=target.stem, block_class=bc, line_count=lc,
                        port_count=ports, is_sequential=is_seq,
                        strategies=[t.value for t in applicable],
                        expected_reduction_pct=expected, risks=risks, confidence=conf)


def plan_repair(target_path: str | Path) -> RepairPlan:
    """Run live review (diagnose only), categorize findings, estimate fixable."""
    result = review(Path(target_path), focus=None)
    if result.error:
        return RepairPlan(target_path=str(target_path), findings_count=0,
                          fixable_count=0, risks=[f"review failed: {result.error}"])
    findings = result.findings
    cats = sorted({f.category for f in findings})
    fixable = [f for f in findings if f.severity in ("critical", "high", "medium")]
    risks: list[str] = []
    if len(findings) > 10: risks.append("many findings — fixes may interact")
    if any(f.category == "security" for f in findings):
        risks.append("security findings require manual verification")
    if any(f.severity == "critical" for f in findings):
        risks.append("critical issues present — review fixes carefully")
    return RepairPlan(target_path=str(target_path), findings_count=len(findings),
                      fixable_count=len(fixable), categories=cats,
                      estimated_fixes=len(fixable), risks=risks)


@dataclass
class ComparisonReport:
    items: list[PlanResult] = field(default_factory=list)
    over_estimation: float = 0.0
    def summary(self) -> str:
        out = ["Plan vs Result:"] + [f"  {i.comparison()}" for i in self.items]
        d = "over" if self.over_estimation > 0 else "under"
        out.append(f"  Bias: {abs(self.over_estimation):.1f}% {d}-estimated")
        return "\n".join(out)


def compare_plan_to_result(plan: OptimizePlan | RepairPlan,
                           result: dict[str, Any]) -> ComparisonReport:
    """Quantitative comparison: planned vs actual, with over/under metric."""
    rpt = ComparisonReport()
    if isinstance(plan, OptimizePlan):
        ap = result.get("actual_reduction_pct", 0.0)
        rpt.items.append(PlanResult(f"{plan.expected_reduction_pct:.1f}% reduction",
            f"{ap:.1f}% reduction", ap <= plan.expected_reduction_pct,
            f"delta {ap - plan.expected_reduction_pct:+.1f}pp"))
        ps, used = set(plan.strategies), set(result.get("strategies_used", []))
        rpt.items.append(PlanResult(f"{len(ps)} strategies", f"{len(ps & used)} worked",
            len(ps & used) > 0, f"unused: {', '.join(sorted(ps - used)) or 'none'}"))
        rpt.over_estimation = plan.expected_reduction_pct - ap
    elif isinstance(plan, RepairPlan):
        af = result.get("fixes_applied", 0)
        rpt.items.append(PlanResult(f"{plan.estimated_fixes} fixes", f"{af} fixes",
            af >= plan.estimated_fixes, f"delta {af - plan.estimated_fixes:+d}"))
        rpt.over_estimation = float(plan.estimated_fixes - af)
    return rpt


def interactive_confirm(plan: OptimizePlan | RepairPlan, *,
                        autopilot: bool = False, timeout: int = 10) -> bool:
    """Print plan summary, ask for confirmation. Auto-confirm in autopilot mode."""
    sep = "=" * 60
    print(f"\n{sep}\n{plan.summary()}")
    if plan.risks:
        print("  RISKS:\n" + "\n".join(f"    - {r}" for r in plan.risks))
    print(sep)
    if autopilot:
        print(f"[autopilot] Auto-confirming in {timeout}s...")
        ready, _, _ = select.select([sys.stdin], [], [], timeout)
        if ready and sys.stdin.readline().strip().lower() in ("n", "no", "abort"):
            print("[autopilot] User aborted."); return False
        print("[autopilot] Confirmed."); return True
    try:
        ans = input("\nProceed? [Y/n] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nAborted."); return False
    return ans in ("", "y", "yes")


def run_with_planning(block_path: str, autopilot: bool = False, timeout: int = 30):
    """Full workflow: plan → confirm → execute → compare. Wired end-to-end."""
    from kairos.sec.closed_loop.optimize_cli import optimize
    from kairos.memory import store
    import time

    target = Path(block_path).resolve()
    if not target.is_file():
        return {"status": "error", "reason": f"file not found: {block_path}"}
    block_path = str(target)

    # 1. Plan
    plan = plan_optimize(block_path)

    # 2. Confirm (blocks unless autopilot)
    if not interactive_confirm(plan, autopilot=autopilot, timeout=timeout):
        return {"status": "aborted", "reason": "user declined plan"}

    # 3. Execute
    start = time.time()
    result = optimize(rtl_path=block_path, max_proposals=getattr(plan, "max_proposals", 5))
    elapsed = time.time() - start

    # 4. Compare (WIRED — always runs after execution)
    actual_result = {
        "actual_reduction_pct": getattr(result, "area_delta_pct", 0.0) if hasattr(result, "area_delta_pct") else 0.0,
        "strategies_used": [s.get("transform_class", "unknown") for s in getattr(result, "iteration_summaries", [])],
        "elapsed_sec": elapsed,
    }
    comparison = compare_plan_to_result(plan, actual_result)

    # 5. Store comparison to memory (accountability persists)
    from pathlib import Path
    _over = getattr(comparison, "over_estimation", 0)
    _planned = getattr(plan, "expected_reduction_pct", 0)
    _actual = actual_result.get("actual_reduction_pct", 0)
    store(block=Path(block_path).stem, finding=f"Plan vs actual: over_estimation={_over:.1f}pp, planned={_planned:.1f}%, actual={_actual:.1f}%")

    return {
        "status": "completed",
        "plan": plan,
        "result": actual_result,
        "comparison": comparison,
    }
