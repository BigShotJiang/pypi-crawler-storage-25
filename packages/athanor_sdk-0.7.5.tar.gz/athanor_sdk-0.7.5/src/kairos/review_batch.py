"""Bulk triage test failures by category and root cause."""
import subprocess, re, json, sys
from collections import defaultdict
from pathlib import Path

FAILURE_PATTERNS = [  # priority order: first match wins
    ("missing_dependency", re.compile(r"No module named ['\"](\S+)['\"]")),
    ("stale_reference",    re.compile(r"cannot import name ['\"](\S+)['\"]")),
    ("import_errors",      re.compile(r"(ImportError|ModuleNotFoundError):\s*(.+)")),
    ("assertion_mismatch", re.compile(r"(AssertionError|assert\b).*(?:expected|!=|==)")),
]
FIX_SUGGESTIONS = {
    "missing_dependency": "Install missing package: pip install {d}",
    "stale_reference":    "Update import: name '{d}' was moved or renamed during refactor",
    "import_errors":      "Update import paths to reflect current module structure",
    "assertion_mismatch": "Review expected values; likely changed by recent refactor",
}

def _run_pytest(test_dir: str) -> str:
    r = subprocess.run(
        ["python", "-m", "pytest", test_dir, "--tb=short", "-q", "--no-header"],
        capture_output=True, text=True, timeout=300)
    return r.stdout + "\n" + r.stderr

def _parse_failures(output: str) -> list[dict]:
    failures = []
    seen = set()
    # FAILED lines: "FAILED path::test - Error: msg"
    for m in re.finditer(
        r"FAILED\s+(\S+?)(?:::(\S+))?\s*[-—]\s*(\w+(?:Error|Exception|Warning)?):?\s*(.*)", output
    ):
        fp, tn, ec, msg = m.groups()
        key = (fp, tn or "")
        if key not in seen:
            seen.add(key)
            failures.append({"file": fp, "test": tn or "", "error_class": ec, "message": msg.strip()})
    # Traceback blocks: "E   ImportError: ..."
    for m in re.finditer(r"(\S+\.py)::(\S+).*\n(?:.*\n)*?E\s+(\w+(?:Error|Exception)):\s*(.*)", output):
        fp, tn, ec, msg = m.groups()
        if (fp, tn) not in seen:
            seen.add((fp, tn))
            failures.append({"file": fp, "test": tn, "error_class": ec, "message": msg.strip()})
    return failures

def _categorize(failure: dict) -> tuple[str, str]:
    text = f"{failure['error_class']}: {failure['message']}"
    for cat, pat in FAILURE_PATTERNS:
        m = pat.search(text)
        if m:
            return cat, (m.group(1) if m.lastindex else "")
    return "other", failure["error_class"]

def _infer_root_cause(files: list[str]) -> str:
    if not files:
        return "unknown"
    stems = [Path(f).stem.replace("test_", "") for f in files]
    common = set(stems[0].split("_"))
    for s in stems[1:]:
        common &= set(s.split("_"))
    if common:
        return f"Shared component changed: {', '.join(sorted(common))}"
    parent = Path(files[0]).parent
    if all(Path(f).parent == parent for f in files):
        return f"All failures in {parent}/"
    return f"{len(files)} tests share same error pattern"

def review_batch(test_dir: str, max_workers: int = 4) -> dict:
    """Bulk triage test failures in a directory.

    Returns:
        {"total_failures": int,
         "categories": [{"name": str, "count": int, "files": [str, ...],
                         "root_cause": str, "suggested_fix": str}, ...]}
    """
    output = _run_pytest(test_dir)
    failures = _parse_failures(output)
    buckets = defaultdict(lambda: {"files": [], "details": []})
    for f in failures:
        cat, detail = _categorize(f)
        buckets[cat]["files"].append(f["file"])
        buckets[cat]["details"].append(detail)
    categories = []
    for name, bkt in sorted(buckets.items(), key=lambda kv: -len(kv[1]["files"])):
        d = max(set(bkt["details"]), key=bkt["details"].count) if bkt["details"] else ""
        suggestion = FIX_SUGGESTIONS.get(name, "Inspect failures manually")
        categories.append({
            "name": name, "count": len(bkt["files"]),
            "files": sorted(set(bkt["files"])),
            "root_cause": _infer_root_cause(bkt["files"]),
            "suggested_fix": suggestion.format(d=d),
        })
    return {"total_failures": len(failures), "categories": categories}

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "tests/"
    print(json.dumps(review_batch(target), indent=2))
