"""Consolidated verify — one command runs all layers."""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Sequence

@dataclass
class ConsolidatedResult:
    path: str
    layer_results: dict[str, dict] = field(default_factory=dict)
    total_findings: int = 0
    quality_score: int = 0

    @property
    def summary(self) -> str:
        n = len(self.layer_results)
        clean = sum(1 for v in self.layer_results.values() if v.get("passed"))
        if self.total_findings == 0:
            return f"Verified: {clean}/{n} layers passed. No issues."
        return f"{self.total_findings} issue(s) across {n - clean} layer(s). Quality: {self.quality_score}%."

    @property
    def honest_report(self) -> str:
        parts = [self.summary, ""]
        for name, lr in self.layer_results.items():
            icon = "+" if lr.get("passed") else "!"
            parts.append(f"  [{icon}] {name}: {lr.get('findings', 0)} findings")
            for d in lr.get("details", [])[:3]:
                parts.append(f"      {d}")
        return "\n".join(parts)

_ALL = ["types", "properties", "symbolic", "mutation", "drift", "specs"]

def verify_all(path: str | Path, *, only: Sequence[str] | None = None, skip_mutation: bool = True) -> ConsolidatedResult:
    target = Path(path)
    layers = list(only) if only else [l for l in _ALL if l != "mutation" or not skip_mutation]
    result = ConsolidatedResult(path=str(path))
    if target.is_file() and target.suffix == ".py":
        for layer in layers:
            _dispatch(layer, target, result)
    elif target.is_dir():
        py_files = sorted(f for f in target.rglob("*.py") if "__pycache__" not in str(f) and ".git" not in str(f))[:50]
        for layer in layers:
            if layer in ("types", "symbolic"):
                for f in py_files:
                    _dispatch(layer, f, result)
            else:
                _dispatch(layer, target, result)
    scores = [100 if v.get("passed") else max(0, 100 - v.get("findings", 0) * 10) for v in result.layer_results.values()]
    result.quality_score = int(sum(scores) / len(scores)) if scores else 0
    return result

def _dispatch(layer: str, path: Path, result: ConsolidatedResult) -> None:
    try:
        if layer == "types":
            from kairos.python_verify import run_mypy
            passed, errors = run_mypy(path)
            _merge(result, "types", passed, len(errors), errors[:3])
        elif layer == "symbolic":
            from kairos.symbolic_exec import analyze_file
            a = analyze_file(path)
            _merge(result, "symbolic", a.total_findings == 0, a.total_findings, [])
        elif layer == "properties":
            from kairos.python_verify import extract_properties
            src = path.read_text() if path.is_file() else ""
            props = extract_properties(src, str(path))
            _merge(result, "properties", len(props) > 0, 0 if props else 1, [f"{len(props)} properties"])
        elif layer == "drift":
            from kairos.verify_drift import verify_drift
            d = verify_drift(str(path))
            n = getattr(d, "security_findings", 0)
            _merge(result, "drift", n == 0, n, [])
        elif layer == "specs":
            from kairos.spec_drift import check_spec_consistency
            s = check_spec_consistency(str(path))
            n = getattr(s, "uncovered_count", 0)
            _merge(result, "specs", n == 0, min(n, 5), [])
        elif layer == "mutation":
            from kairos.python_verify import run_mutation_score
            score, detail = run_mutation_score(path)
            passed = score is not None and score >= 80
            _merge(result, "mutation", passed, 0 if passed else 1, [detail])
    except Exception:  # noqa: BLE001
        result.layer_results.setdefault(layer, {"passed": True, "findings": 0, "details": []})

def _merge(result: ConsolidatedResult, layer: str, passed: bool, findings: int, details: list) -> None:
    existing = result.layer_results.get(layer, {"passed": True, "findings": 0, "details": []})
    if not passed:
        existing["passed"] = False
    existing["findings"] = existing.get("findings", 0) + findings
    existing["details"] = existing.get("details", []) + details
    result.total_findings += findings
    result.layer_results[layer] = existing
