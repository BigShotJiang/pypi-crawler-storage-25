"""ATH-1445: symbolic execution + taint analysis for Python verification.

Structural analysis of Python code without running it:
- Dead code detection (unreachable branches after constant conditions)
- Taint tracking (user input → dangerous sink without sanitization)
- Null safety (Optional access without None check)
- Division by zero (denominator could be 0)

No LLM. No API key. Pure AST analysis. Deterministic.
"""
from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SymbolicFinding:
    file: str
    line: int
    category: str
    message: str
    severity: str = "medium"


@dataclass
class TaintFlow:
    source: str
    source_line: int
    sink: str
    sink_line: int
    sanitized: bool = False


@dataclass
class SymbolicResult:
    file_path: str
    dead_code: list[SymbolicFinding] = field(default_factory=list)
    taint_flows: list[TaintFlow] = field(default_factory=list)
    null_risks: list[SymbolicFinding] = field(default_factory=list)
    div_zero_risks: list[SymbolicFinding] = field(default_factory=list)

    @property
    def total_findings(self) -> int:
        return len(self.dead_code) + len(self.taint_flows) + len(self.null_risks) + len(self.div_zero_risks)

    @property
    def honest_report(self) -> str:
        if self.total_findings == 0:
            return f"symbolic exec: {self.file_path} — no issues found"
        parts = [f"symbolic exec: {self.file_path} — {self.total_findings} findings"]
        for f in self.dead_code:
            parts.append(f"  [dead] L{f.line}: {f.message}")
        for t in self.taint_flows:
            label = "sanitized" if t.sanitized else "UNSANITIZED"
            parts.append(f"  [taint] L{t.source_line}→L{t.sink_line}: {t.source}→{t.sink} ({label})")
        for f in self.null_risks:
            parts.append(f"  [null] L{f.line}: {f.message}")
        for f in self.div_zero_risks:
            parts.append(f"  [div0] L{f.line}: {f.message}")
        return "\n".join(parts)


_DANGEROUS_SINKS = frozenset({
    "subprocess.run", "subprocess.call", "subprocess.Popen",
    "os.system", "os.popen", "eval", "exec",
    "cursor.execute", "conn.execute",
})

_TAINT_SOURCES = frozenset({
    "input", "request.args", "request.form", "request.json",
    "sys.argv", "os.environ",
})

_SANITIZERS = frozenset({
    "shlex.quote", "html.escape", "urllib.parse.quote",
    "sanitize", "validate", "escape",
})


def analyze(source: str, file_path: str = "<stdin>") -> SymbolicResult:
    """Run symbolic analysis on Python source."""
    try:
        tree = ast.parse(source, filename=file_path)
    except SyntaxError:
        return SymbolicResult(file_path=file_path)

    result = SymbolicResult(file_path=file_path)
    result.dead_code = _detect_dead_code(tree, file_path)
    result.null_risks = _detect_null_risks(tree, file_path)
    result.div_zero_risks = _detect_div_zero(tree, file_path)
    result.taint_flows = _detect_taint(tree, source, file_path)
    return result


def _detect_dead_code(tree: ast.AST, file_path: str) -> list[SymbolicFinding]:
    findings = []
    for node in ast.walk(tree):
        if isinstance(node, ast.If):
            test = node.test
            if isinstance(test, ast.Constant):
                if not test.value:
                    findings.append(SymbolicFinding(
                        file=file_path, line=node.lineno,
                        category="dead_code",
                        message="if-block is dead code (condition is always False)",
                    ))
                elif test.value is True:
                    if node.orelse:
                        findings.append(SymbolicFinding(
                            file=file_path, line=node.orelse[0].lineno,
                            category="dead_code",
                            message="else-block is dead code (condition is always True)",
                        ))
    return findings


def _detect_null_risks(tree: ast.AST, file_path: str) -> list[SymbolicFinding]:
    findings = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            optional_params: set[str] = set()
            for arg in node.args.args:
                if arg.annotation:
                    ann = ast.unparse(arg.annotation)
                    if "Optional" in ann or "None" in ann:
                        optional_params.add(arg.arg)
            for child in ast.walk(node):
                if isinstance(child, ast.Attribute) and isinstance(child.value, ast.Name):
                    if child.value.id in optional_params:
                        guard = _has_none_guard(node, child.value.id, child.lineno)
                        if not guard:
                            findings.append(SymbolicFinding(
                                file=file_path, line=child.lineno,
                                category="null_risk",
                                message=f"'{child.value.id}' is Optional but accessed without None check",
                                severity="high",
                            ))
    return findings


def _has_none_guard(func: ast.AST, var_name: str, access_line: int) -> bool:
    """Check if there's a None guard before the access line."""
    for node in ast.walk(func):
        if isinstance(node, ast.If) and node.lineno < access_line:
            test_src = ast.unparse(node.test)
            if f"{var_name} is not None" in test_src or f"{var_name} is None" in test_src:
                return True
    return False


def _detect_div_zero(tree: ast.AST, file_path: str) -> list[SymbolicFinding]:
    findings = []
    path_typed = _collect_path_typed_names(tree)
    for node in ast.walk(tree):
        if isinstance(node, (ast.BinOp, ast.AugAssign)):
            op = node.op if isinstance(node, ast.BinOp) else node.op
            if isinstance(op, (ast.Div, ast.FloorDiv, ast.Mod)):
                left = node.left if isinstance(node, ast.BinOp) else node.target
                divisor = node.right if isinstance(node, ast.BinOp) else node.value
                if _is_path_division(left, divisor, path_typed):
                    continue
                if isinstance(divisor, ast.Name):
                    if _has_nonzero_guard(tree, divisor.id, node.lineno):
                        continue
                    if _has_nonzero_default(tree, divisor.id):
                        continue
                    findings.append(SymbolicFinding(
                        file=file_path,
                        line=node.lineno,
                        category="div_zero",
                        message=f"division by '{divisor.id}' — variable could be 0",
                        severity="medium",
                    ))
                elif isinstance(divisor, ast.Constant) and divisor.value == 0:
                    findings.append(SymbolicFinding(
                        file=file_path,
                        line=node.lineno,
                        category="div_zero",
                        message="division by literal 0",
                        severity="critical",
                    ))
    return findings


def _has_nonzero_guard(tree: ast.AST, var_name: str, use_line: int) -> bool:
    """Check if there's a >0 or !=0 guard before the division."""
    for node in ast.walk(tree):
        if isinstance(node, ast.If) and node.lineno <= use_line:
            test_src = ast.unparse(node.test)
            if any(pattern in test_src for pattern in [
                f"{var_name} > 0", f"{var_name} != 0", f"{var_name} >= 1",
                f"{var_name} > 0.0", f"{var_name} != 0.0",
                f"{var_name} <= 0", f"{var_name} == 0", f"{var_name} < 1",
                f"not {var_name} == 0", f"{var_name}:",
            ]):
                return True
        if isinstance(node, ast.IfExp) and node.lineno == use_line:
            test_src = ast.unparse(node.test)
            if f"{var_name} > 0" in test_src or f"{var_name} != 0" in test_src:
                return True
    return False


def _has_nonzero_default(tree: ast.AST, var_name: str) -> bool:
    """Check if the variable has a non-zero default parameter value."""
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for arg, default in zip(
                reversed(node.args.args),
                reversed(node.args.defaults),
            ):
                if arg.arg == var_name and isinstance(default, ast.Constant):
                    if default.value is not None and default.value != 0:
                        return True
    return False


def _collect_path_typed_names(tree: ast.AST) -> set[str]:
    """Collect variable names annotated as Path or assigned from Path()."""
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            ann = ast.unparse(node.annotation) if node.annotation else ""
            if "Path" in ann:
                names.add(node.target.id)
        if isinstance(node, ast.Assign):
            if isinstance(node.value, ast.Call):
                call_name = ast.unparse(node.value.func) if hasattr(node.value, "func") else ""
                if "Path" in call_name:
                    for t in node.targets:
                        if isinstance(t, ast.Name):
                            names.add(t.id)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for arg in node.args.args:
                if arg.annotation:
                    ann = ast.unparse(arg.annotation)
                    if "Path" in ann:
                        names.add(arg.arg)
    return names


def _is_path_division(left: ast.expr, right: ast.expr, path_typed: set[str]) -> bool:
    """Detect pathlib Path / str operations (not arithmetic division)."""
    if isinstance(right, ast.Constant) and isinstance(right.value, str):
        return True
    if isinstance(left, ast.Call):
        call_name = ast.unparse(left.func) if hasattr(left, "func") else ""
        if "Path" in call_name or "path" in call_name.lower() or "root" in call_name.lower() or "dir" in call_name.lower():
            return True
    if isinstance(left, ast.Name) and left.id in path_typed:
        return True
    if isinstance(left, ast.Name) and any(h in left.id.lower() for h in ("path", "dir", "root", "folder", "file")):
        return True
    if isinstance(left, ast.Attribute) and any(h in left.attr.lower() for h in ("path", "dir", "parent", "root")):
        return True
    if isinstance(left, ast.BinOp) and isinstance(left.op, ast.Div):
        return True
    if isinstance(left, ast.Subscript) or isinstance(left, ast.Call):
        left_str = ast.unparse(left) if hasattr(ast, "unparse") else ""
        if any(h in left_str.lower() for h in ("path", "dir", "root", "output", "folder")):
            return True
    return False


def _detect_taint(tree: ast.AST, source: str, file_path: str) -> list[TaintFlow]:
    flows = []
    import re as _re
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        call_name = _resolve_call_name(node)
        if not call_name:
            continue
        matched_sink = None
        for sink in _DANGEROUS_SINKS:
            if call_name == sink or call_name.endswith("." + sink.split(".")[-1]):
                matched_sink = sink
                break
        if not matched_sink:
            continue
        for arg in node.args:
            arg_str = ast.unparse(arg)
            for taint_src in _TAINT_SOURCES:
                parts = taint_src.split(".")
                pattern = r"\b" + r"\.".join(_re.escape(p) for p in parts) + r"\b"
                if _re.search(pattern, arg_str):
                    lines_before = "\n".join(source.splitlines()[:node.lineno])
                    sanitized = any(s in lines_before for s in _SANITIZERS)
                    flows.append(TaintFlow(
                        source=taint_src,
                        source_line=node.lineno,
                        sink=matched_sink,
                        sink_line=node.lineno,
                        sanitized=sanitized,
                    ))
    return flows


def _resolve_call_name(node: ast.Call) -> str:
    """Resolve a call node to its dotted name."""
    if isinstance(node.func, ast.Name):
        return node.func.id
    if isinstance(node.func, ast.Attribute):
        try:
            return ast.unparse(node.func)
        except (ValueError, AttributeError):
            return node.func.attr
    return ""


def analyze_file(path: str | Path) -> SymbolicResult:
    """Analyze a Python file."""
    p = Path(path)
    if not p.is_file():
        return SymbolicResult(file_path=str(path))
    return analyze(p.read_text(), str(path))
