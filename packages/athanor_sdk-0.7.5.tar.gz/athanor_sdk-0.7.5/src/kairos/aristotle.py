"""kairos.aristotle — Aristotle proof-service integration for the SDK.

Aristotle is a Harmonic-AI-hosted proof service that can close hard Lean
theorems that stdlib tactics can't. Per Aidan 2026-04-24 06:20Z:

    kairos.lean.verify_proof(code, aristotle=True, aristotle_timeout=1800)
    — "aristotle takes a long time, timeout should default to an hour.
    Make sure no agent sits around waiting for aristotle, it should be
    in the background. In most cases, a sonnet or whatever agent is
    used for lean should just close the prove themselves. aristotle
    should only be used for the hardest of solves that opus/sonnet
    cannot do."

Design: submit-and-return-pending.

* :func:`submit_tarball` packages the Lean proof + submits to Aristotle
  via the ``aristotle`` CLI. Returns a project_id immediately (submit is
  fast, ~2-5s). Caller does NOT block waiting for the proof to close.
* :func:`poll_project` fetches the current status/result for a
  previously-submitted project. Calling code (or the existing
  solve/shared/scripts/aristotle_sweep.py cron) does the polling.
* :func:`find_api_key` returns the Aristotle API key from env, or None.
  Callers with ``aristotle=True`` but no key log a WARNING and fall
  through to the non-Aristotle path — they do not silently no-op.

Zero cross-repo dep: this module duplicates the submit/poll logic from
``solve/shared/lean_gate.aristotle_submit_lean`` intentionally — the SDK
ships as a pip package and customers don't have solve/shared on their
machines (platform 2026-04-24 07:38Z design call). The solve/shared
version stays as the cron's submit path; this module is the SDK-side
equivalent.

The underlying ``aristotle`` CLI is Harmonic-provided; it reads
``ARISTOTLE_API_KEY`` from env. The SDK invokes it via subprocess — no
network calls directly from Python. If the binary is missing, calls
return :class:`AristotleCLIMissingError`.
"""

from __future__ import annotations

import logging
import os
import subprocess
import tarfile
import tempfile
from dataclasses import dataclass
from pathlib import Path

from kairos.security.env_allowlist import safe_env_for_claude_subagent

_logger = logging.getLogger(__name__)


# ── Env var + exception surface ──────────────────────────────────────


_ARISTOTLE_API_KEY_ENV = "ARISTOTLE_API_KEY"
_ARISTOTLE_BIN_DEFAULT = "aristotle"


class AristotleCLIMissingError(Exception):
    """Raised when the ``aristotle`` binary isn't on PATH. Callers should
    fall through to the non-Aristotle verification path rather than
    failing the caller."""


class AristotleMissingAPIKeyError(Exception):
    """Raised when ``ARISTOTLE_API_KEY`` is not set. Callers typically
    catch this + fall through to non-Aristotle."""


# ── Result dataclasses ────────────────────────────────────────────────


@dataclass(frozen=True)
class AristotleSubmission:
    """Result of :func:`submit_tarball`.

    ``project_id`` is non-None on success. On any failure, ``error``
    carries a human-readable reason and ``project_id`` is None.
    """

    project_id: str | None
    error: str | None = None

    @property
    def ok(self) -> bool:
        return self.project_id is not None


@dataclass(frozen=True)
class AristotlePollResult:
    """Result of :func:`poll_project`. ``status`` mirrors the
    aristotlelib 0.x enum values — terminal statuses carry a
    solution tarball path when ``status == "COMPLETE"``."""

    status: str
    solution_path: Path | None = None
    error: str | None = None

    @property
    def done(self) -> bool:
        return self.status in _TERMINAL_STATUSES


# Terminal statuses for poll_project. Keep in sync with
# solve/shared/lean_gate.py's aristotle integration.
_TERMINAL_STATUSES: frozenset[str] = frozenset({
    "COMPLETE",
    "COMPLETE_WITH_ERRORS",
    "FAILED",
    "OUT_OF_BUDGET",
    "CANCELED",
})


# ── Public API ────────────────────────────────────────────────────────


def find_api_key() -> str | None:
    """Return ``ARISTOTLE_API_KEY`` or None. Callers wanting a fail-loud
    check use :func:`require_api_key` instead."""
    key = os.environ.get(_ARISTOTLE_API_KEY_ENV, "").strip()
    return key or None


def require_api_key() -> str:
    """Return the key or raise :class:`AristotleMissingAPIKeyError`."""
    key = find_api_key()
    if not key:
        raise AristotleMissingAPIKeyError(
            f"{_ARISTOTLE_API_KEY_ENV} not set — Aristotle dispatch "
            "cannot proceed."
        )
    return key


def submit_tarball(
    lean_src: str,
    *,
    timeout_sec: int = 300,
    aristotle_bin: str = _ARISTOTLE_BIN_DEFAULT,
    extra_files: dict[str, str] | None = None,
) -> AristotleSubmission:
    """Submit ``lean_src`` to Aristotle as a tarball.

    Creates a temp tarball with ``Main.lean`` (the proof source) + any
    ``extra_files`` (e.g. ``lakefile.lean`` for Mathlib-using proofs),
    invokes ``aristotle submit`` (or equivalent subcommand), parses the
    returned project_id out of stdout.

    Args:
        lean_src: Lean 4 proof source to submit.
        timeout_sec: max subprocess wait for the submit call. Submit is
            typically <5s; 300s is generous to cover retries at the CLI
            layer.
        aristotle_bin: path to the ``aristotle`` binary. Default
            ``"aristotle"`` assumes it's on PATH.
        extra_files: optional dict of ``{relative_path: contents}`` to
            include in the tarball. Common case: ``{"lakefile.lean":
            ...}`` for Mathlib-using proofs.

    Returns:
        :class:`AristotleSubmission` with ``project_id`` on success or
        ``error`` on failure. Never raises on submit failures (returns
        :class:`AristotleSubmission` with error instead) — callers are
        expected to fall through to non-Aristotle on dispatch failures.

    Raises:
        :class:`AristotleMissingAPIKeyError`: when
            ``ARISTOTLE_API_KEY`` is not set.
        :class:`AristotleCLIMissingError`: when the binary isn't on PATH.
    """
    require_api_key()

    with tempfile.TemporaryDirectory(prefix="kairos-aristotle-") as tmp:
        tmp_path = Path(tmp)
        tarball = tmp_path / "submission.tar.gz"

        with tarfile.open(tarball, "w:gz") as tar:
            # Main.lean is the proof source.
            main_path = tmp_path / "Main.lean"
            main_path.write_text(lean_src, encoding="utf-8")
            tar.add(main_path, arcname="Main.lean")
            for rel, content in (extra_files or {}).items():
                f = tmp_path / rel.replace("/", "_")
                f.write_text(content, encoding="utf-8")
                tar.add(f, arcname=rel)

        try:
            proc = subprocess.run(
                [
                    aristotle_bin,
                    "submit",
                    "--tarball",
                    str(tarball),
                ],
                capture_output=True,
                text=True,
                timeout=timeout_sec,
                env=safe_env_for_claude_subagent(),
            )
        except FileNotFoundError as exc:
            raise AristotleCLIMissingError(
                f"aristotle CLI not found at {aristotle_bin!r}: {exc}"
            ) from exc
        except subprocess.TimeoutExpired:
            return AristotleSubmission(
                project_id=None,
                error=f"submit timeout after {timeout_sec}s",
            )

        log = (proc.stdout or "") + (proc.stderr or "")
        if proc.returncode != 0:
            return AristotleSubmission(
                project_id=None,
                error=f"aristotle exit {proc.returncode}: {log[-500:]}",
            )
        project_id = _parse_project_id(log)
        if not project_id:
            return AristotleSubmission(
                project_id=None,
                error=(
                    "aristotle returned 0 but no project_id in output: "
                    + log[-500:]
                ),
            )
        return AristotleSubmission(project_id=project_id)


def poll_project(
    project_id: str,
    *,
    destination: Path | None = None,
    timeout_sec: int = 300,
    aristotle_bin: str = _ARISTOTLE_BIN_DEFAULT,
) -> AristotlePollResult:
    """Fetch current status + (if terminal) solution for ``project_id``.

    Args:
        project_id: string id returned by :func:`submit_tarball`.
        destination: path to write the solution tarball when status is
            ``COMPLETE``. Defaults to a temp file managed by the caller.
        timeout_sec: max subprocess wait.
        aristotle_bin: path to the ``aristotle`` binary.

    Returns:
        :class:`AristotlePollResult` carrying the status + solution path
        (for COMPLETE) + optional error string.
    """
    require_api_key()

    if destination is None:
        with tempfile.NamedTemporaryFile(
            prefix="kairos-aristotle-result-",
            suffix=".tar.gz",
            delete=False,
        ) as f:
            destination = Path(f.name)

    try:
        proc = subprocess.run(
            [
                aristotle_bin,
                "result",
                "--project-id",
                project_id,
                "--destination",
                str(destination),
                "--wait=False",
            ],
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            env=safe_env_for_claude_subagent(),
        )
    except FileNotFoundError as exc:
        raise AristotleCLIMissingError(
            f"aristotle CLI not found at {aristotle_bin!r}: {exc}"
        ) from exc
    except subprocess.TimeoutExpired:
        return AristotlePollResult(
            status="UNKNOWN",
            error=f"poll timeout after {timeout_sec}s",
        )

    log = (proc.stdout or "") + (proc.stderr or "")
    status = _parse_status(log)
    if proc.returncode != 0:
        return AristotlePollResult(
            status=status or "UNKNOWN",
            error=f"aristotle exit {proc.returncode}: {log[-500:]}",
        )

    solution_path = None
    if status == "COMPLETE" and destination.exists() and destination.stat().st_size > 0:
        solution_path = destination
    return AristotlePollResult(status=status or "UNKNOWN", solution_path=solution_path)


# ── Parsing helpers (pure) ────────────────────────────────────────────


def _parse_project_id(log: str) -> str | None:
    """Extract the Aristotle project_id from CLI output.

    aristotlelib 0.x prints ``project_id: <uuid>`` or
    ``Project: <uuid>`` depending on version. Accept either. Return
    None when neither matches.
    """
    for line in log.splitlines():
        if "project_id" in line or "Project:" in line:
            parts = line.split(":")
            if len(parts) >= 2:
                candidate = parts[-1].strip()
                if candidate:
                    return candidate
    return None


def _parse_status(log: str) -> str:
    """Extract the terminal status enum from CLI output.

    aristotlelib 0.x prints ``Status: COMPLETE`` / ``FAILED`` /
    ``IN_PROGRESS`` / etc. Return the canonical enum string when
    matched, or ``"UNKNOWN"`` when not present.
    """
    known = {
        "COMPLETE", "COMPLETE_WITH_ERRORS", "FAILED", "OUT_OF_BUDGET",
        "CANCELED", "QUEUED", "IN_PROGRESS", "NOT_STARTED",
    }
    for line in log.splitlines():
        stripped = line.strip()
        # Accept "Status: COMPLETE" or "COMPLETE"-alone-on-a-line patterns.
        if stripped.startswith("Status:"):
            val = stripped.split(":", 1)[1].strip()
            if val in known:
                return val
        if stripped in known:
            return stripped
    return "UNKNOWN"


__all__ = [
    "AristotleSubmission",
    "AristotlePollResult",
    "AristotleCLIMissingError",
    "AristotleMissingAPIKeyError",
    "find_api_key",
    "require_api_key",
    "submit_tarball",
    "poll_project",
]
