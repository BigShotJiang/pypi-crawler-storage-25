"""Fleet-wide model pricing — best-effort estimates, NOT billing-reconciled.

**This file has a twin at `athanor-builder/shared/scripts/model_prices.py`.**
The duplication is intentional (distribution reasons):
  * The builder copy rides along with evaluate.py via `tools/sync.sh` into
    every env repo and the env-scaffold template.
  * This copy ships as part of the pip-installable `athanor` package.

Keep both in sync: any rate / model / cache-tier change MUST land in both.
CTO owns the consistency check — run `diff` after edits:

    diff athanor-builder/shared/scripts/model_prices.py \\
         athanor-sdk/src/kairos/model_prices.py

Usage:
    from kairos.model_prices import estimate_cost_usd
    cost = estimate_cost_usd(
        model="openai/kimi-k2.5",
        prompt_tokens=5000,
        completion_tokens=1200,
        cache_creation_tokens=800,   # anthropic only
        cache_read_tokens=400,       # anthropic + gemini
    )

Price updates: each entry carries `last_verified` + `source_url`. When you
refresh, bump both. CTO's fleet conventions include a monthly freshness
check; env-quality (research) lane owns the refresh process.

Values below are provider list prices (not negotiated Azure/enterprise
rates), intentionally — we'd rather over-estimate and reconcile down via
`--cost-calibration-factor` than under-report spend to founders.
"""

from __future__ import annotations

import logging
from typing import Any


_logger = logging.getLogger(__name__)

# Track which unknown model_ids we've already warned about, so the
# fallback WARNING doesn't spam the logs once per LLM call. Reset on
# every fresh process — which is the right granularity for surfacing
# silent fallback (ATH-538): agents notice during a run, not across
# process boundaries where the problem is invisible anyway.
_SEEN_FALLBACKS: set[str] = set()

# Rates in USD per 1,000,000 tokens.
# Each entry:
#   "input":         $/M for standard prompt tokens
#   "output":        $/M for completion tokens
#   "cache_read":    $/M for cached-read input (anthropic ~10% of input, gemini tier varies)
#   "cache_create":  $/M for cache-creation input (anthropic ~125% of input)
#   "last_verified": ISO date string — bump on refresh
#   "source_url":    where the price was pulled from
#
# Missing keys default to the standard rate. Unknown models fall back to a
# conservative "openai/gpt-4o"-ish rate so we NEVER silently return $0.
MODEL_PRICES: dict[str, dict[str, Any]] = {
    # Anthropic Claude Sonnet 4.6 — cache-aware, reasoning model
    "anthropic/claude-sonnet-4-6": {
        "input": 3.00,
        "output": 15.00,
        "cache_read": 0.30,       # 10% of input per Anthropic docs
        "cache_create": 3.75,     # 125% of input per Anthropic docs
        "last_verified": "2026-04-12",
        "source_url": "https://www.anthropic.com/pricing#api",
    },
    # Azure-hosted rewrite: same model, same prices (we route via Azure for RL traffic)
    "azure_ai/claude-sonnet-4-6": {
        "input": 3.00, "output": 15.00,
        "cache_read": 0.30, "cache_create": 3.75,
        "last_verified": "2026-04-12",
        "source_url": "Azure-approx, mirrors anthropic/claude-sonnet-4-6",
    },

    # Anthropic Claude Opus 4.6 — cache-aware, reasoning model.
    # Mode_fleet uses Opus for Phase -1 (plan) and Phase 5 (audit).
    "anthropic/claude-opus-4-6": {
        "input": 15.00,
        "output": 75.00,
        "cache_read": 1.50,       # 10% of input per Anthropic docs
        "cache_create": 18.75,    # 125% of input per Anthropic docs
        "last_verified": "2026-04-17",
        "source_url": "https://www.anthropic.com/pricing#api",
    },
    "azure_ai/claude-opus-4-6": {
        "input": 15.00, "output": 75.00,
        "cache_read": 1.50, "cache_create": 18.75,
        "last_verified": "2026-04-17",
        "source_url": "Azure-approx, mirrors anthropic/claude-opus-4-6",
    },
    # Anthropic Claude Opus 4.7 (1M context variant — used by mode_single
    # when invoked with --builder-model 'anthropic/claude-opus-4-7[1m]').
    # Same list price as Opus 4.6; bump last_verified when Anthropic publishes
    # a distinct 4.7 rate card.
    "anthropic/claude-opus-4-7": {
        "input": 15.00, "output": 75.00,
        "cache_read": 1.50, "cache_create": 18.75,
        "last_verified": "2026-04-17",
        "source_url": "Mirrors Opus 4.6 list price; verify on invoice.",
    },
    "azure_ai/claude-opus-4-7": {
        "input": 15.00, "output": 75.00,
        "cache_read": 1.50, "cache_create": 18.75,
        "last_verified": "2026-04-17",
        "source_url": "Azure-approx, mirrors anthropic/claude-opus-4-7",
    },
    # Claude Haiku 4.5 — cheap routing model (per memory: Haiku for mechanical CRUD).
    "anthropic/claude-haiku-4-5": {
        "input": 1.00, "output": 5.00,
        "cache_read": 0.10, "cache_create": 1.25,
        "last_verified": "2026-04-17",
        "source_url": "https://www.anthropic.com/pricing#api",
    },
    "azure_ai/claude-haiku-4-5": {
        "input": 1.00, "output": 5.00,
        "cache_read": 0.10, "cache_create": 1.25,
        "last_verified": "2026-04-17",
        "source_url": "Azure-approx, mirrors anthropic/claude-haiku-4-5",
    },

    # Google Gemini 3 Flash Preview — no cache-creation concept; cache_read is tier-based
    "gemini/gemini-3-flash-preview": {
        "input": 0.30,
        "output": 1.00,
        "cache_read": 0.075,      # ~25% of input
        "last_verified": "2026-04-12",
        "source_url": "https://ai.google.dev/pricing (Gemini 3 Flash Preview)",
    },
    "gemini/gemini-2.5-flash": {
        "input": 0.075,
        "output": 0.30,
        "cache_read": 0.019,
        "last_verified": "2026-04-12",
        "source_url": "https://ai.google.dev/pricing (Gemini 2.5 Flash)",
    },
    "gemini/gemini-3.1-pro-preview": {
        "input": 1.25,
        "output": 10.00,
        "cache_read": 0.31,
        "last_verified": "2026-04-12",
        "source_url": "https://ai.google.dev/pricing (Gemini 3 Pro Preview, ≤128K context)",
    },
    # ATH-586: research's drafter_sweep calls get_client("gemini/gemini-3-pro-preview")
    # (no ".1"); the registry resolves both names to the same underlying Pro
    # Preview tier. Duplicate rates rather than alias-indirection so
    # estimate_cost_usd stays a pure dict lookup. Reconcile from the first
    # Vertex invoice for 2026-04 drafter sweeps if Google publishes a delta.
    "gemini/gemini-3-pro-preview": {
        "input": 1.25,
        "output": 10.00,
        "cache_read": 0.31,
        "last_verified": "2026-04-24",
        "source_url": "https://ai.google.dev/pricing (Gemini 3 Pro Preview, ≤128K context) — mirrors gemini-3.1-pro-preview; verify on first Vertex invoice.",
    },

    # Moonshot Kimi K2.5 via Azure OpenAI-compatible endpoint
    "openai/kimi-k2.5": {
        "input": 1.00,
        "output": 3.00,
        "last_verified": "2026-04-12",
        "source_url": "Azure-approx. Moonshot list prices ~$1/$3 per M. Verify via Azure invoice.",
    },
    # Moonshot Kimi K2.6-1 (reasoning model; ATH-528) via Azure OpenAI-compat.
    # Same Azure-priced tier as K2.5 until Moonshot publishes a K2.6 delta;
    # bump after first Azure invoice lands for the Phase-A dogfood runs.
    "openai/kimi-k2.6-1": {
        "input": 1.00,
        "output": 3.00,
        "last_verified": "2026-04-23",
        "source_url": "Azure-approx, inherits K2.5 tier. Moonshot K2.6 release notes TBD — reconcile from first Phase-A invoice.",
    },
    # Same Kimi family exposed via the `azure_ai/` LiteLLM provider prefix
    # (ATH-528 — kairos.generator_synthesize defaults to azure_ai/kimi-k2.6-1).
    # Duplicate entries rather than alias-indirection so estimate_cost_usd
    # stays a pure dict lookup (no routing logic).
    "azure_ai/kimi-k2.5": {
        "input": 1.00,
        "output": 3.00,
        "last_verified": "2026-04-23",
        "source_url": "Mirror of openai/kimi-k2.5 rates for azure_ai/ provider prefix.",
    },
    "azure_ai/kimi-k2.6-1": {
        "input": 1.00,
        "output": 3.00,
        "last_verified": "2026-04-23",
        "source_url": "Mirror of openai/kimi-k2.6-1 rates for azure_ai/ provider prefix.",
    },
    # Mistral Large 3 via Azure OpenAI-compatible endpoint
    "openai/mistral-large-3": {
        "input": 2.00,
        "output": 6.00,
        "last_verified": "2026-04-12",
        "source_url": "Azure-approx. Mistral list ~$2/$6 per M. Verify via Azure invoice.",
    },
    # GPT-4o fallback
    "openai/gpt-4o": {
        "input": 2.50,
        "output": 10.00,
        "cache_read": 1.25,
        "last_verified": "2026-04-12",
        "source_url": "https://openai.com/api/pricing/",
    },
}


def _fallback_rate() -> dict[str, Any]:
    """Conservative fallback for unknown models — assumes GPT-4o-ish.

    Never returns $0 silently; we'd rather over-estimate unknown spend than
    under-report.
    """
    return {
        "input": 3.00,
        "output": 15.00,
        "cache_read": 0.30,
        "cache_create": 3.75,
        "last_verified": "fallback",
        "source_url": "unknown-model fallback (conservative GPT-4o/Sonnet-ish)",
    }


def _maybe_warn_unknown_model(model: str) -> None:
    """Emit a one-time WARNING for each unknown ``model`` that hits the
    fallback rate (ATH-538).

    De-duplicates via the module-level :data:`_SEEN_FALLBACKS` set so a
    single mistyped model_id used in a tight loop doesn't flood logs —
    one line, then silence for the rest of the process. Fresh process
    re-emits; that matches agents' actual observation window.
    """
    if model in _SEEN_FALLBACKS:
        return
    _SEEN_FALLBACKS.add(model)
    _logger.warning(
        "model_prices: %r has no entry in MODEL_PRICES — using "
        "conservative fallback ($3 in / $15 out per M). Costs for this "
        "model will over-report 3-15x vs the likely real rate. Add a "
        "real entry to kairos.model_prices.MODEL_PRICES (+ the builder "
        "twin) if you plan to use this model regularly. ATH-528 has the "
        "Kimi precedent.", model,
    )


def _reset_seen_fallbacks() -> None:
    """Test-only: clear the de-dup set so consecutive tests see the
    warning. NOT part of the public surface."""
    _SEEN_FALLBACKS.clear()


def estimate_cost_usd(
    model: str,
    prompt_tokens: int = 0,
    completion_tokens: int = 0,
    cache_creation_tokens: int = 0,
    cache_read_tokens: int = 0,
    calibration_factor: float = 1.0,
) -> float:
    """Estimate USD cost for one LLM phase/turn.

    Returns $ as float, rounded to 4 decimals. ALL inputs are token counts;
    pricing table handles the per-model rate math.

    Cache token handling:
      - Anthropic: prompt_tokens is NON-cached input. cache_read_tokens is
        billed at cache_read rate. cache_creation_tokens at cache_create rate.
      - Gemini: cache_read_tokens rolls into cache_read rate; cache_creation
        is not a billed concept (no cache_create rate).
      - Others: cache counts ignored (no cache semantics exposed).

    Not billing-reconciled. Use calibration_factor to tune toward actual
    invoice totals when we get them.

    ATH-538: when ``model`` is not in :data:`MODEL_PRICES`, we log a
    one-time-per-process WARNING before applying the conservative
    fallback. Silent fallback was the root cause of ATH-528 — Kimi K2.6
    quietly charged GPT-4o-ish rates for the entire Phase-A dogfood
    cycle because no entry existed. The warning is deliberately loud:
    over-reporting spend is a trust-breaker with founders.
    """
    rates = MODEL_PRICES.get(model)
    if rates is None:
        _maybe_warn_unknown_model(model)
        rates = _fallback_rate()

    in_rate = rates.get("input", 0.0)
    out_rate = rates.get("output", 0.0)
    cache_read_rate = rates.get("cache_read", in_rate)       # default: same as input
    cache_create_rate = rates.get("cache_create", in_rate)   # default: same as input

    # Standard input + output
    input_cost = (prompt_tokens * in_rate) / 1_000_000
    output_cost = (completion_tokens * out_rate) / 1_000_000

    # Cache-adjusted input (anthropic-style; gemini-style just feeds cache_read)
    cache_read_cost = (cache_read_tokens * cache_read_rate) / 1_000_000
    cache_create_cost = (cache_creation_tokens * cache_create_rate) / 1_000_000

    total = (input_cost + output_cost + cache_read_cost + cache_create_cost) * calibration_factor
    result: float = round(total, 4)
    return result


def describe_model(model: str) -> str:
    """Human-readable price + freshness for logging / --dry-run."""
    rates = MODEL_PRICES.get(model)
    if not rates:
        return f"{model}: UNKNOWN — using conservative fallback rate"
    parts = [f"${rates['input']:.2f}/M in", f"${rates['output']:.2f}/M out"]
    if "cache_read" in rates:
        parts.append(f"${rates['cache_read']:.3f}/M cache_read")
    if "cache_create" in rates:
        parts.append(f"${rates['cache_create']:.2f}/M cache_create")
    return f"{model}: {' · '.join(parts)} (verified {rates['last_verified']})"


if __name__ == "__main__":
    # Smoke test + printable price table
    print("MODEL_PRICES — Athanor fleet cost-estimate reference")
    print("=" * 60)
    for m in sorted(MODEL_PRICES):
        print(" ", describe_model(m))
    print()
    print("Example costs for 10K prompt + 2K completion:")
    for m in sorted(MODEL_PRICES):
        cost = estimate_cost_usd(m, prompt_tokens=10000, completion_tokens=2000)
        print(f"  {m:40s} ${cost:.4f}")
