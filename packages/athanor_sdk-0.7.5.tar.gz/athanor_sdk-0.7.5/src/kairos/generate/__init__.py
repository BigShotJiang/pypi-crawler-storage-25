"""kairos.generate — English description to verified RTL (ATH-1395).

Customer flow:
    kairos generate "4-stage pipelined ALU with forwarding"

Multi-agent pipeline:
    1. Parse spec (extract constraints, interfaces, behavior)
    2. Generate RTL (LLM proposer fleet, same pattern as optimize)
    3. Verify output (yosys elaboration + EBMC spec compliance)
    4. Emit certificate (generated.sv + proof + provenance)
"""
from __future__ import annotations

from kairos.generate.pipeline import generate, GenerateResult

__all__ = ["generate", "GenerateResult"]
