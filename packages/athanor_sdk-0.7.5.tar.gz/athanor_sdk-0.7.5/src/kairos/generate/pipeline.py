"""ATH-1395: generate pipeline — spec to verified RTL.

Same multi-agent pattern as optimize:
- Generator agents propose RTL from the spec
- Reviewer agent validates synthesizability
- Verifier proves spec compliance via EBMC

The spec can be:
- A string (English description)
- A .spec file (structured constraints)
- A companion comment block in an existing .sv file
"""
from __future__ import annotations

import json
import logging
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from kairos.security.env_allowlist import safe_env_for_yosys
from kairos.security.path_sanitizer import validate_verilog_identifier

_log = logging.getLogger("kairos.generate")


@dataclass(frozen=True)
class GenerateResult:
    """Output of a kairos generate run."""
    module_name: str
    rtl_path: str | None = None
    rtl_source: str = ""
    synthesizable: bool = False
    yosys_cells: int = 0
    spec_compliance: str = "unchecked"
    error: str | None = None
    proposals: list[dict[str, Any]] = field(default_factory=list)


def _validate_synthesizable(rtl: str, module_name: str) -> tuple[bool, int, str]:
    """Check if generated RTL is valid Verilog via yosys elaboration."""
    yosys = shutil.which("yosys")
    if not yosys:
        return False, 0, (
            "yosys not found on PATH. Install it with:\n"
            "  Ubuntu/Debian: sudo apt-get install yosys\n"
            "  macOS: brew install yosys\n"
            "  Or set PATH to include your yosys installation directory."
        )

    with tempfile.NamedTemporaryFile(suffix=".sv", mode="w", delete=False) as f:
        f.write(rtl)
        f.flush()
        sv_path = f.name

    try:
        result = subprocess.run(
            [yosys, "-p",
             f"read_verilog -sv {sv_path}; "
             f"hierarchy -check -top {module_name}; "
             f"proc; opt; stat"],
            capture_output=True, text=True, timeout=30,
            env=safe_env_for_yosys(),
        )
        if result.returncode != 0:
            return False, 0, (
                f"yosys elaboration failed (rc={result.returncode}):\n"
                f"  {result.stderr[:300].strip()}\n"
                "Fix: check that the generated RTL is valid SystemVerilog "
                "and that the module name matches the top-level declaration."
            )

        cells = 0
        for line in result.stdout.splitlines():
            if "Number of cells:" in line:
                try:
                    cells = int(line.split(":")[-1].strip())
                except ValueError:
                    pass
        return True, cells, ""
    except subprocess.TimeoutExpired:
        return False, 0, "yosys timed out (30s)"
    except Exception as e:  # noqa: BLE001
        return False, 0, str(e)[:200]
    finally:
        Path(sv_path).unlink(missing_ok=True)


def _verify_with_ebmc(sv_path: str | Path, module_name: str) -> tuple[bool, int, str]:
    """Run EBMC assertion-based verification on the generated RTL.

    Args:
        sv_path: Path to the synthesized SystemVerilog file.
        module_name: Top module name for EBMC.

    Returns:
        (proved, bound, details) where:
        - proved: True if all assertions pass or no assertions present.
        - bound: The k-bound used (0 if no assertions).
        - details: Human-readable status string.
    """
    sv_path = Path(sv_path)
    if not sv_path.exists():
        return False, 0, (
            f"RTL file not found at '{sv_path}'. "
            "This is likely an internal error — the synthesis step may have failed to write the file. "
            "Re-run with --verbose for more detail, or file a bug at https://github.com/athanor-ai/athanor-kairos/issues."
        )

    # Check if the RTL contains any assert statements worth verifying.
    rtl_text = sv_path.read_text()
    has_assertions = bool(re.search(
        r"\b(assert\s+property|assert\s*\()", rtl_text, re.IGNORECASE,
    ))
    if not has_assertions:
        return True, 0, "no assertions to verify"

    # Run EBMC at bound=1 for fast assertion checking.
    try:
        from kairos.sv.ebmc import run_ebmc
    except ImportError as exc:
        return False, 0, (
            f"kairos.sv.ebmc module could not be imported: {exc}\n"
            "Fix: reinstall kairos with EBMC support — run 'pip install --upgrade kairos[ebmc]'."
        )

    ebmc_bin = shutil.which("ebmc")
    if not ebmc_bin:
        return False, 0, (
            "ebmc not found on PATH. Install EBMC from https://www.cprover.org/ebmc/ "
            "and ensure the 'ebmc' binary is on your PATH, or run 'kairos doctor' to check prerequisites."
        )

    try:
        result = run_ebmc(
            sv_path,
            top_module=module_name,
            bound=1,
            mode="bmc",
            timeout_sec=30,
        )
    except Exception as exc:  # noqa: BLE001
        return False, 0, f"ebmc error: {type(exc).__name__}: {str(exc)[:200]}"

    if result.timed_out:
        return False, 0, "ebmc timed out (30s)"

    if result.refuted > 0:
        return False, 1, (
            f"ebmc refuted {result.refuted}/{result.total} assertion(s) at bound=1"
        )

    if result.proved > 0:
        return True, 1, (
            f"ebmc proved {result.proved} assertion(s) at bound=1"
        )

    # EBMC ran but found no properties (edge case: assert parsed but not
    # recognized by EBMC as a property).
    return True, 0, "no assertions to verify"


def generate(
    spec: str,
    *,
    module_name: str | None = None,
    output_dir: str | Path | None = None,
    proposer_backend: str | None = None,
    max_proposals: int = 3,
    timeout_sec: int = 300,
) -> GenerateResult:
    """Generate verified RTL from an English specification.

    Args:
        spec: English description of the desired hardware block.
        module_name: Output module name. Auto-derived from spec if None.
        output_dir: Where to write generated files. Default: temp dir.
        proposer_backend: LLM backend. Auto-detected if None.
        max_proposals: Number of RTL proposals to generate.
        timeout_sec: Per-proposal timeout.

    Returns:
        GenerateResult with the best synthesizable proposal.
    """
    if proposer_backend is None:
        from kairos.sec.closed_loop.optimize_cli import detect_proposer_backend
        proposer_backend = detect_proposer_backend()

    if module_name is None:
        words = spec.lower().split()[:3]
        module_name = "_".join(w for w in words if w.isalnum())[:32] or "generated_block"

    out = Path(output_dir) if output_dir else Path(tempfile.mkdtemp(prefix="kairos_gen_"))
    out.mkdir(parents=True, exist_ok=True)

    _log.info(f"Generating RTL for: {spec}")
    _log.info(f"Module: {module_name}, Backend: {proposer_backend}, Proposals: {max_proposals}")

    system_prompt = (
        "You are a hardware design engineer. Generate synthesizable "
        "SystemVerilog RTL that implements the specification below.\n\n"
        "STRICT REQUIREMENTS — the output MUST satisfy ALL of the following:\n"
        "1. Complete module declaration: `module " + module_name + " (...); ... endmodule`\n"
        "2. ALL ports declared with explicit direction (input/output/inout), "
        "type (wire/reg/logic), and bit-width (e.g. [7:0]). "
        "No implicit nets.\n"
        "3. NO pseudo-code, NO comments-only sections, NO placeholder logic. "
        "Every signal must be driven by real combinational or sequential logic.\n"
        "4. SYNTHESIZABLE constructs ONLY:\n"
        "   - NO `initial` blocks (use reset logic with an explicit rst signal instead)\n"
        "   - NO delays (`#10`, `#1step`, etc.)\n"
        "   - NO system tasks (`$display`, `$monitor`, `$finish`, `$readmemh`, etc.)\n"
        "   - NO `fork`/`join`, NO `wait`, NO `event` triggers\n"
        "   - Use `always_comb` for combinational logic and "
        "`always_ff @(posedge clk)` for sequential logic\n"
        "5. The module MUST be entirely self-contained:\n"
        "   - NO instantiations of undefined submodules\n"
        "   - NO `include directives\n"
        "   - All functionality implemented inline within this single module\n"
        "6. Use only standard SystemVerilog synthesis constructs: "
        "assign, always_comb, always_ff, case/casez, if/else, "
        "ternary operator, arithmetic/logical/bitwise operators, "
        "generate blocks (if needed for parameterized logic).\n\n"
        "Output ONLY the module source code in a fenced ```systemverilog block. "
        "No testbench, no explanation outside the code fence."
    )

    proposals: list[dict[str, Any]] = []

    if proposer_backend == "claude-agent":
        try:
            from kairos.sec.closed_loop.claude_proposer import claude_propose, ProposerAuthenticationError
            raw = claude_propose(
                gold_sv="",
                sig={"target_module": module_name, "parameters": []},
                max_proposals=max_proposals,
                system_prompt=system_prompt + f"\n\nSpecification: {spec}",
                timeout_sec=timeout_sec,
                max_turns=3,
            )
            for r in raw:
                proposals.append({"rtl": r.get("gate_sv", ""), "rationale": r.get("rationale", "")})
        except ProposerAuthenticationError as e:
            return GenerateResult(
                module_name=module_name,
                error=f"Claude authentication failed: {str(e)[:200]}. Run 'claude login' first.",
            )
        except Exception as e:  # noqa: BLE001
            return GenerateResult(
                module_name=module_name,
                error=(
                    f"Claude proposer failed ({type(e).__name__}): {str(e)[:200]}\n"
                    "Possible fixes:\n"
                    "  1. Check that 'claude' is on PATH and logged in: run 'claude login'\n"
                    "  2. Run 'kairos doctor' to diagnose Claude Code connectivity\n"
                    "  3. Switch backends: set KAIROS_PROPOSER_BACKEND=litellm and ANTHROPIC_API_KEY=sk-ant-..."
                ),
            )
    elif proposer_backend == "litellm":
        try:
            from kairos.model_client._backoff import call_with_backoff
            from kairos.model_presets import DEFAULT_SEC_PROPOSER_MODEL
            resp = call_with_backoff(
                model=DEFAULT_SEC_PROPOSER_MODEL,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"Specification: {spec}\n\nGenerate {max_proposals} distinct implementations."},
                ],
                timeout=timeout_sec,
            )
            text = resp.choices[0].message.content or ""
            blocks = re.findall(r"```(?:systemverilog|verilog|sv)?\n(.*?)```", text, re.DOTALL)
            for block in blocks[:max_proposals]:
                proposals.append({"rtl": block.strip(), "rationale": ""})
        except Exception as e:  # noqa: BLE001
            return GenerateResult(
                module_name=module_name,
                error=(
                    f"LLM call failed via litellm ({type(e).__name__}): {str(e)[:200]}\n"
                    "Possible fixes:\n"
                    "  1. Set your API key: export ANTHROPIC_API_KEY=sk-ant-...\n"
                    "  2. Check the model name: run 'kairos doctor' to verify backend config\n"
                    "  3. Check network/firewall — litellm must reach the provider API endpoint"
                ),
            )

    if not proposals:
        return GenerateResult(
            module_name=module_name,
            error=(
                "No proposals generated. Possible fixes:\n"
                "  1. Set API key: export ANTHROPIC_API_KEY=sk-ant-...\n"
                "  2. Or use Claude Code: ensure 'claude' is on PATH\n"
                "  3. Run 'kairos doctor' to diagnose\n"
            ),
        )

    best: GenerateResult | None = None
    for i, prop in enumerate(proposals):
        rtl = prop["rtl"]
        if not rtl:
            continue

        synth_ok, cells, synth_err = _validate_synthesizable(rtl, module_name)

        sv_path = out / f"{module_name}_v{i}.sv"
        sv_path.write_text(rtl)

        result = GenerateResult(
            module_name=module_name,
            rtl_path=str(sv_path),
            rtl_source=rtl,
            synthesizable=synth_ok,
            yosys_cells=cells,
            spec_compliance="unchecked",
            error=synth_err if not synth_ok else None,
            proposals=proposals,
        )

        if synth_ok and (best is None or cells < best.yosys_cells):
            best = result

        _log.info(f"  [{i}] {'PASS' if synth_ok else 'FAIL'}: {cells} cells{f' ({synth_err})' if synth_err else ''}")

    if best is not None:
        final_path = out / f"{module_name}.sv"
        final_path.write_text(best.rtl_source)
        _log.info(f"Best: {best.yosys_cells} cells → {final_path}")

        # EBMC assertion-based verification (v1: any assertions in the RTL).
        proved, bound, ebmc_details = _verify_with_ebmc(final_path, module_name)
        if bound == 0:
            spec_compliance = ebmc_details  # "no assertions to verify"
        elif proved:
            spec_compliance = f"proved (k={bound}): {ebmc_details}"
        else:
            spec_compliance = f"failed: {ebmc_details}"
        _log.info(f"Spec compliance: {spec_compliance}")

        return GenerateResult(
            module_name=module_name,
            rtl_path=str(final_path),
            rtl_source=best.rtl_source,
            synthesizable=True,
            yosys_cells=best.yosys_cells,
            spec_compliance=spec_compliance,
            proposals=proposals,
        )

    return GenerateResult(
        module_name=module_name,
        error=(
            "No synthesizable proposal found among the generated candidates.\n"
            "Possible fixes:\n"
            "  1. Make the specification more precise — add port names, bit-widths, or reset behavior\n"
            "  2. Increase --max-proposals to give the model more attempts\n"
            "  3. Ensure yosys is installed: run 'kairos doctor' to check synthesis prerequisites\n"
            "  4. Run with --verbose to see per-proposal yosys errors"
        ),
        proposals=proposals,
    )


__all__ = ["generate", "GenerateResult"]
