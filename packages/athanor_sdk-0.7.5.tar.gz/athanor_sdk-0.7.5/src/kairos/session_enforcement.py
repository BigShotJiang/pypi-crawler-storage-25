"""ATH-1380: session wrapper enforcement.

94.8% of run_ids have no session_open event. This module provides
runtime detection + warnings when code paths create run_ids without
wrapping in `with observe()`.

Usage:
    from kairos.session_enforcement import require_session
    require_session()  # warns if no observe session is active
"""
from __future__ import annotations

import logging
import os
import warnings

_log = logging.getLogger("kairos.session_enforcement")

_ENFORCEMENT_ENV = "KAIROS_SESSION_ENFORCEMENT"


def is_session_active() -> bool:
    """Check if an observe() session is currently active."""
    try:
        from kairos.observe import _current_context
        ctx = _current_context.get(None)
        return ctx is not None
    except (ImportError, AttributeError):
        return False


def require_session(context: str = "") -> None:
    """Warn if no observe() session is active.

    In strict mode (KAIROS_SESSION_ENFORCEMENT=strict), raises instead.
    """
    if is_session_active():
        return

    mode = os.environ.get(_ENFORCEMENT_ENV, "warn").lower()
    msg = (
        f"No observe() session active{f' ({context})' if context else ''}. "
        f"Traces will not be captured. Wrap in `with observe(...):`."
    )

    if mode == "strict":
        raise RuntimeError(msg)
    elif mode == "warn":
        _log.warning(msg)
        warnings.warn(msg, UserWarning, stacklevel=2)


def session_audit() -> dict[str, int]:
    """Return session enforcement statistics."""
    try:
        from kairos.observe import _ACTIVE_SESSIONS
        return {
            "active_sessions": _ACTIVE_SESSIONS,
            "enforcement_mode": os.environ.get(_ENFORCEMENT_ENV, "warn"),
        }
    except (ImportError, AttributeError):
        return {"active_sessions": 0, "enforcement_mode": "unknown"}
