"""kairos.autopilot.runner — the continuous improvement loop.

Thin orchestrator: memory recall/store, optimize/generate/prove/sweep,
Cedar guardrails, digest generation.
"""
from __future__ import annotations

import logging, time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

_log = logging.getLogger("kairos.autopilot")


@dataclass
class AutopilotConfig:
    tasks: list[str] = field(default_factory=lambda: ["optimize"])
    blocks: list[str] = field(default_factory=list)
    reflection_interval_sec: int = 1800
    max_iterations: int = 100
    require_before_main: list[str] = field(
        default_factory=lambda: ["ci_green", "peer_review", "dogfood_pass"])
    forbidden: list[str] = field(
        default_factory=lambda: ["delete_files", "modify_secrets", "force_push", "skip_tests"])
    digest_path: str | None = None

    @classmethod
    def from_yaml(cls, path: str | Path) -> "AutopilotConfig":
        p = Path(path)
        if not p.is_file():
            return cls()
        try:
            import yaml  # type: ignore[import-untyped]
            d = yaml.safe_load(p.read_text()) or {}
            _default = cls()
            return cls(
                tasks=d.get("tasks", _default.tasks),
                blocks=d.get("blocks", _default.blocks),
                reflection_interval_sec=d.get("reflection_interval_sec", _default.reflection_interval_sec),
                max_iterations=d.get("max_iterations", _default.max_iterations),
                require_before_main=d.get("require_before_main", _default.require_before_main),
                forbidden=d.get("forbidden", _default.forbidden),
                digest_path=d.get("digest", {}).get("path"),
            )
        except ImportError:
            return cls()


@dataclass
class AutopilotDigest:
    iterations_completed: int = 0
    improvements_found: int = 0
    failures: list[str] = field(default_factory=list)
    decisions: list[str] = field(default_factory=list)
    risks: list[str] = field(default_factory=list)
    duration_sec: float = 0.0

    def summary(self) -> str:
        lines = [f"Autopilot: {self.iterations_completed} iters, "
                 f"{self.improvements_found} improvements, {len(self.failures)} failures"]
        if self.decisions: lines.append(f"Decisions: {'; '.join(self.decisions[:5])}")
        if self.risks:     lines.append(f"Risks: {'; '.join(self.risks[:5])}")
        if self.failures:  lines.append(f"Failures: {'; '.join(self.failures[:5])}")
        return "\n".join(lines)


def _discover_blocks(patterns: list[str]) -> list[Path]:
    import glob
    blocks: list[Path] = []
    for pat in patterns:
        blocks.extend(Path(p) for p in glob.glob(pat) if p.endswith((".sv", ".v")))
    return blocks


def autopilot(
    config: AutopilotConfig | None = None,
    config_path: str | Path | None = None,
) -> AutopilotDigest:
    """Run kairos in autopilot mode."""
    if config is None:
        config = AutopilotConfig.from_yaml(config_path) if config_path else AutopilotConfig()

    blocks = _discover_blocks(config.blocks) if config.blocks else []
    digest = AutopilotDigest()
    t_start = time.monotonic()
    _log.info(f"Autopilot starting: {config.tasks} on {len(blocks)} blocks")

    forbidden = frozenset(config.forbidden)

    for iteration in range(config.max_iterations):
        _log.info(f"--- Iteration {iteration + 1} ---")
        for task in config.tasks:
            if task in forbidden:
                digest.failures.append(f"{task}: BLOCKED by forbidden list")
                _log.warning(f"Task '{task}' is in forbidden list — skipping")
                continue
            for block in blocks or [Path(".")]:
                try:
                    _run_task(task, block, config, digest)
                except Exception as e:  # noqa: BLE001
                    digest.failures.append(f"{task} on {block}: {str(e)[:100]}")
                    _log.warning(f"Task {task} on {block} failed: {e}")
        digest.iterations_completed += 1
        if iteration < config.max_iterations - 1:
            time.sleep(config.reflection_interval_sec)

    digest.duration_sec = time.monotonic() - t_start
    if config.digest_path:
        Path(config.digest_path).write_text(digest.summary())
    _log.info(digest.summary())
    return digest


def _run_task(task: str, block: Path, config: AutopilotConfig, digest: AutopilotDigest) -> None:
    """Execute one task on one block with memory integration."""
    from kairos.memory import recall, store

    try:
        ctx = recall(block=block.stem)
        if ctx.get("notes"):
            _log.info(f"  Memory: {len(ctx['notes'])} past findings for {block.stem}")
    except Exception:  # noqa: BLE001
        ctx = {}

    # ── optimize ──────────────────────────────────────────────
    if task == "optimize" and block.suffix in (".sv", ".v"):
        digest.decisions.append(f"Optimizing {block.name}")
        from kairos.sec.closed_loop.optimize_cli import optimize
        result = optimize(rtl_path=str(block), max_proposals=5, compound_rounds=3)
        if result and getattr(result, "halt_reason", "") == "proved_equivalent_variant_found":
            digest.improvements_found += 1
            store(block=block.stem, finding="optimization found verified improvement")

    # ── prove: EBMC BMC + k-induction via multi_verify ────────
    elif task == "prove" and block.suffix in (".sv", ".v"):
        digest.decisions.append(f"Proving {block.name}")
        import json
        from kairos.sec.closed_loop.optimize_cli import build_bundle_from_rtl
        from kairos.sec.closed_loop.multi_verify import verify_with_all_engines

        bundle = build_bundle_from_rtl(rtl_path=str(block))
        sig = json.loads((bundle / "signature.json").read_text())
        gold = bundle / sig["gold_sv"]
        mod = sig["target_module"]
        is_combo = not sig.get("clock_port", "")

        mv = verify_with_all_engines(
            gold_path=gold, gate_path=gold,
            gold_module=mod, gate_module=mod,
            clock_port=sig.get("clock_port", "clk"),
            reset_port=sig.get("reset_port", "rst_n"),
            reset_active_low=sig.get("reset_active_low", True),
            is_combo=is_combo,
        )
        _log.info(f"  Prove: {mv.summary}")
        store(block=block.stem,
              finding=f"prove verdict={mv.aggregate_verdict}: {mv.summary}",
              outcome="success" if mv.aggregate_verdict == "PROVED" else "failure")
        if mv.aggregate_verdict == "PROVED":
            digest.improvements_found += 1

    # ── generate: optimize in full-generation mode ────────────
    elif task == "generate" and block.suffix in (".sv", ".v"):
        digest.decisions.append(f"Generating from {block.name}")
        from kairos.sec.closed_loop.optimize_cli import optimize
        result = optimize(rtl_path=str(block), max_proposals=3, proposer_mode="full")
        accepted = getattr(result, "n_accepted", lambda: 0)()
        store(block=block.stem,
              finding=f"generate status={getattr(result, 'halt_reason', '?')}, accepted={accepted}",
              outcome="success" if accepted > 0 else "failure")
        if accepted > 0:
            digest.improvements_found += 1

    # ── sweep: DSE across sibling blocks + Pareto ranking ─────
    elif task == "sweep" and block.suffix in (".sv", ".v"):
        digest.decisions.append(f"Sweeping {block.name}")
        from kairos.sec.closed_loop.dse import sweep_design
        sr = sweep_design(rtl_dir=str(block.parent),
                          max_proposals_per_block=3, timeout_per_block=600)
        _log.info(f"  Sweep: {sr.summary()}")
        for br in sr.ranked[:3]:
            store(block=br.block,
                  finding=f"sweep: {br.area_delta_pct:+.1f}% area ({br.status})",
                  outcome="success" if br.status == "proved" else "failure",
                  area_delta=br.area_delta_pct)
        digest.improvements_found += sr.blocks_proved

    else:
        _log.info(f"  Skipping {task} on {block} (not applicable)")


__all__ = ["autopilot", "AutopilotConfig", "AutopilotDigest"]
