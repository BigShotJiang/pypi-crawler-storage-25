"""kairos.autopilot — continuous self-improving agent mode.

Customer types:
    kairos autopilot

The agent works autonomously within Cedar-enforced guardrails:
- Recalls past findings before each task (kairos.memory)
- Executes tasks (optimize, prove, generate, sweep)
- Stores results after verification
- Self-reflects at configurable intervals
- Produces morning digest for human review

Every mistake we made → a guardrail. Every lesson → a feature.
"""
from __future__ import annotations

from kairos.autopilot.runner import autopilot, AutopilotConfig, AutopilotDigest

__all__ = ["autopilot", "AutopilotConfig", "AutopilotDigest"]
