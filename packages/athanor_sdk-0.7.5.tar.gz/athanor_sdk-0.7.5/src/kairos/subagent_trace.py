"""kairos.subagent_trace — structured reasoning traces for subagent calls.

ATH-1442: When kairos spawns a subagent (review, proposer, verifier),
capture WHY it was spawned, WHAT it returned, and WHETHER the result
was used. This enables debugging false positives and understanding
the reasoning chain.

Every subagent call goes through trace_subagent_call which logs:
- intent: why the subagent was called
- input_summary: what it was given (truncated)
- output_summary: what it returned (truncated)
- outcome: accepted | rejected | error
- reasoning: why the outcome was chosen
"""
from __future__ import annotations

import logging
import threading
from collections import deque
from dataclasses import dataclass, field
from typing import Any

_log = logging.getLogger("kairos.subagent_trace")

_MAX_TRACES = 500


@dataclass
class SubagentTrace:
    agent_type: str
    intent: str
    input_summary: str
    output_summary: str = ""
    outcome: str = "pending"
    reasoning: str = ""
    elapsed_sec: float = 0.0
    error: str | None = None


_trace_lock = threading.Lock()
_trace_log: deque[SubagentTrace] = deque(maxlen=_MAX_TRACES)


def trace_subagent_call(
    agent_type: str,
    intent: str,
    input_summary: str,
) -> SubagentTrace:
    """Start tracing a subagent call. Returns a trace object to fill in."""
    safe_type = str(agent_type).replace("\n", " ")[:50]
    safe_intent = str(intent).replace("\n", " ")[:200]
    trace = SubagentTrace(
        agent_type=safe_type,
        intent=safe_intent,
        input_summary=str(input_summary)[:500],
    )
    with _trace_lock:
        _trace_log.append(trace)
    _log.info("[subagent:%s] %s", safe_type, safe_intent)
    return trace


_VALID_OUTCOMES = frozenset({"accepted", "rejected", "error", "pending"})


def complete_trace(
    trace: SubagentTrace,
    output_summary: str,
    outcome: str,
    reasoning: str,
    elapsed_sec: float = 0.0,
) -> None:
    """Complete a subagent trace with the result (thread-safe).

    Persists the completed trace to Supabase via the sdk_agent_events
    pipeline so the platform conversation trace viewer can render it.
    """
    if outcome not in _VALID_OUTCOMES:
        outcome = "error"
    with _trace_lock:
        trace.output_summary = str(output_summary)[:500]
        trace.outcome = outcome
        trace.reasoning = str(reasoning).replace("\n", " ")[:200]
        trace.elapsed_sec = elapsed_sec
    _log.info("[subagent:%s] %s: %s", trace.agent_type, outcome, str(reasoning)[:100])
    _emit_trace_event(trace)


def _emit_trace_event(trace: SubagentTrace) -> None:
    """Best-effort emit to sdk_agent_events so traces are visible on Tahoe."""
    try:
        from kairos.observe import emit as obs_emit
        obs_emit(
            "subagent_trace",
            payload={
                "agent_type": trace.agent_type,
                "intent": trace.intent,
                "input_summary": trace.input_summary,
                "output_summary": trace.output_summary,
                "outcome": trace.outcome,
                "reasoning": trace.reasoning,
                "elapsed_sec": trace.elapsed_sec,
                "error": trace.error,
            },
        )
    except Exception:  # noqa: BLE001 — best-effort emit must not crash the pipeline
        _log.debug("subagent trace emit failed (non-fatal)", exc_info=True)


def get_traces() -> list[SubagentTrace]:
    """Return all traces from this session (thread-safe snapshot)."""
    with _trace_lock:
        return list(_trace_log)


def clear_traces() -> None:
    """Clear all traces (thread-safe)."""
    with _trace_lock:
        _trace_log.clear()


def format_traces(traces: list[SubagentTrace] | None = None) -> str:
    """Format traces for display (thread-safe)."""
    if traces is None:
        with _trace_lock:
            traces = list(_trace_log)
    if not traces:
        return "No subagent traces recorded."
    lines = [f"Subagent traces ({len(traces)} calls):"]
    for i, t in enumerate(traces, 1):
        icon = {"accepted": "+", "rejected": "!", "error": "?", "pending": "~"}.get(t.outcome, "?")
        lines.append(f"  {i}. [{icon}] {t.agent_type}: {t.intent}")
        lines.append(f"     Input: {t.input_summary[:80]}...")
        if t.output_summary:
            lines.append(f"     Output: {t.output_summary[:80]}...")
        lines.append(f"     Outcome: {t.outcome} ({t.elapsed_sec:.1f}s)")
        if t.reasoning:
            lines.append(f"     Why: {t.reasoning[:100]}")
        if t.error:
            lines.append(f"     Error: {t.error[:100]}")
    return "\n".join(lines)
