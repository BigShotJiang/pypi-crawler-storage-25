"""Autoformalize pipeline types + protocol re-exports (Gate 9 scaffold).

**Post Gate 5 merge (2026-04-23, commit 7a29859), the 6 plugin Protocols
+ Verdict + OrchestrationChoice + related exceptions live canonically at
`kairos.spec.types`.** This module re-exports them so downstream code
that uses the autoformalize flow has a single import path, but the
definitions are single-sourced at `kairos.spec.types`.

Still defined here (autoformalize-specific):
- `ParsedNL` — R2 NL-parse stage output (premises, parameters, conclusion_shape)
- `TierSpec` — per-tier drafter output with first-class blind-spot declaration
  (R3 null-guard invariants) and R1 tri-state coverage_claim
- `ReviewConcern` / `CoverageGap` / `ReviewResult` — round-robin review
  structures with R5 NEW_DISCOVERY vs DRAFTER_DECLARED_DISPUTE classification
- `DrafterContext` / `ReviewContext` — per-stage context bundles
- `Score` — scoring-function output
- `KNOWN_TIERS` — frozenset of built-in tier names (plugins extend via
  their `evidence_tier_when_primary` property)

Re-exported from `kairos.spec.types` (platform Gate 5 canonical):
- 6 Protocols: `VerifierPlugin` / `OrchestratorPlugin` / `PromptLoader` /
  `ScoringFn` / `ToolRegistryPlugin` / `ModelSelectorPlugin`
- `Verdict` + `OrchestrationChoice` + `Purity` enum
- Exceptions: `PromptMissing` / `OrchestrationMalformed` /
  `OrchestrationInvalidPlugin`

Re-exported from `kairos.trace` (QA ATH-498 canonical):
- `TraceSink` Protocol
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

# ── Re-exports from kairos.spec.types (canonical: platform Gate 5) ──
from kairos.spec.types import (
    ModelSelectorPlugin,
    OrchestrationInvalidPlugin,
    OrchestrationMalformed,
    OrchestratorPlugin,
    PromptLoader,
    PromptMissing,
    ScoringFn,
    ToolRegistryPlugin,
    Verdict,
    VerifierPlugin,
)

# ── Re-exports from kairos.trace (canonical: QA ATH-498) ───────────
try:
    from kairos.trace import TraceSink
except ImportError:
    pass


# ── Autoformalize-specific types (not elsewhere) ───────────────────


@dataclass(frozen=True)
class ParsedNL:
    """Structured output of the R2 NL-parse stage.

    The orchestrator consumes this instead of raw prose so drafters
    receive premises-vs-parameters-vs-conclusion structure + no
    ambiguity about which phrase is a premise vs a parameter label.

    Surfaced as a first-class dataclass because R2 is a pre-dispatch
    pipeline stage (§2 architecture), not a private detail of
    OrchestratorPlugin.orchestrate().
    """
    premises: list[str]
    parameters: list[str]
    conclusion_shape: str
    raw_nl: str


@dataclass(frozen=True)
class TierSpec:
    """Per-tier drafter output — first-class honesty signal.

    Fields are shaped per §3 coverage-matrix requirements + R1 tri-state
    + R3 schema null-guards. The `coverage_claim` discriminates which
    branch the drafter lands on; null-guard invariants on
    `bound_k`/`formal_artifact`/`not_applicable_reason` are validated
    by Stage A (spec_validate) at pipeline entry.
    """
    tier: str                                      # 'lean_proved', 'bmc_bounded', 'empirical', 'corroborates_lean_proved'
    coverage_claim: Literal[
        "ACCEPT",
        "NOT_APPLICABLE",
        "UNKNOWN",
        "VERIFIED_NATIVELY",
        "VERIFIED_WITH_LOAD_BEARING_USER_AXIOMS",
    ]
    formal_artifact: str | None                    # Lean/SV/Dafny code; null on NOT_APPLICABLE (R3)
    blind_spots: list[str]                         # mandatory non-empty unless NOT_APPLICABLE w/ reason
    axioms_required: list[str]                     # irreducible only (R3); empty for NOT_APPLICABLE / UNKNOWN
    bound_k: int | None                            # R3 null-guard: required iff tier=='bmc_bounded'
    not_applicable_reason: str | None              # R3 null-guard: required iff coverage_claim=='NOT_APPLICABLE'


@dataclass(frozen=True)
class ReviewConcern:
    """Single concern raised by a round-robin reviewer (§4.2)."""
    type: Literal[
        "semantic_mismatch",
        "hidden_reformulation",
        "missing_blind_spot",
        "lazy_not_applicable",
        "fabricated_coverage",
        "axiom_soundness_unchecked",
        "tactic_brittleness",
        "hidden_weakening",
    ]
    detail: str
    severity: Literal["high", "medium", "low"]
    suggested_fix: str | None


@dataclass(frozen=True)
class CoverageGap:
    """Gap in reviewed tier's coverage (R5 classification enum per
    ATH-495 preview finding 2026-04-22)."""
    gap: str
    severity: Literal["high", "medium", "low"]
    classification: Literal["NEW_DISCOVERY", "DRAFTER_DECLARED_DISPUTE"]


@dataclass(frozen=True)
class ReviewResult:
    """Round-robin reviewer output per §4.2."""
    reviewer_tier: str
    reviewed_tier: str
    verdict: Literal["ACCEPT", "ACCEPT_WITH_CAVEATS", "REJECT", "REQUEST_REVISION"]
    concerns: list[ReviewConcern]
    coverage_gaps_identified: list[CoverageGap]


@dataclass(frozen=True)
class Score:
    """Output of ScoringFn — maps verdict state to a numeric score."""
    value: float                                   # in [0.0, 1.0]
    breakdown: dict[str, float]                    # per-outcome contribution for auditability


@dataclass(frozen=True)
class DrafterContext:
    """Non-NL context a drafter needs: ground-truth resources, workdir,
    budget envelope, tool access.
    """
    ground_truth_resources: list[str]              # paths to Lean files, SV shells, etc.
    workdir: str
    budget_usd: float
    budget_wall_sec: int
    tool_registry: ToolRegistryPlugin              # per-run tool access


@dataclass(frozen=True)
class ReviewContext:
    """Context a reviewer has: parsed NL + their own tier's drafter
    output + reviewed peer's draft.
    """
    parsed_nl: ParsedNL
    self_draft: TierSpec                           # the reviewer's own tier's draft (their priors)
    budget_usd: float


# ── KNOWN_TIERS registry ───────────────────────────────────────────

KNOWN_TIERS: frozenset[str] = frozenset({
    "lean_proved",
    "bmc_bounded",
    "empirical",
    "corroborates_lean_proved",                    # R1 tri-state (ATH-495 finding)
})


# ── Autoformalize-specific exceptions ──────────────────────────────


class BudgetExceeded(Exception):
    """Raised when a pipeline run exceeds its USD or wall-time budget.

    Platform-level auto-bail (not an escalation trigger).
    Customer opt-in override via `--budget-override` flag.
    """


class ToolAlreadyRegistered(ValueError):
    """Raised when ToolRegistryPlugin.register() hits a name collision."""


class ToolNotFound(KeyError):
    """Raised when ToolRegistryPlugin.lookup() can't find the tool."""


class UnknownTier(KeyError):
    """Raised when ModelSelectorPlugin.select() gets an unregistered tier."""
