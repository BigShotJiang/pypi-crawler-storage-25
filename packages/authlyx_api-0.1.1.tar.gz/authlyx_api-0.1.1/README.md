# AuthlyX Python SDK (PyPI)

This folder is the publish-ready PyPI package version of the AuthlyX Python SDK.

The package name is:

```bash
pip install authlyx-api
```

## Quick Start

```py
from authlyx_api import AuthlyX

AuthlyXApp = AuthlyX(
    ownerId="12345678",
    appName="MYAPP",
    version="1.0.0",
    secret="your-secret",
    debug=True,
    api="https://authly.cc/api/v2",
)

AuthlyXApp.Init()
```

## Optional Parameters

```py
AuthlyXApp = AuthlyX(
    ownerId="12345678",
    appName="MYAPP",
    version="1.0.0",
    secret="your-secret",
    debug=False,
    api="https://example.com/api/v2",
)
```

### Available options

- `debug`
  - Default: `True`
  - Set `False` to disable SDK logs

- `api`
  - Default: `https://authly.cc/api/v2`
  - Use this for your custom domain

## Available Methods

- `Init()`
- `Login(identifier, password=None, deviceType=None)`
- `Register(username, password, licenseKey, email="")`
- `ChangePassword(oldPassword, newPassword)`
- `ExtendTime(username, licenseKey)`
- `GetVariable(key)`
- `SetVariable(key, value)`
- `Log(message)`
- `GetChats(channelName, limit=100, cursor=None)`
- `SendChat(message, channelName=None)`
- `ValidateSession()`

## Authentication Example

```py
# Username + password
AuthlyXApp.Login("username", password="password")

# License key only
AuthlyXApp.Login("XXXXX-XXXXX-XXXXX-XXXXX-XXXXX")

# Device login
AuthlyXApp.Login("YOUR_DEVICE_ID", deviceType="motherboard")
```

## Variable Example

```py
AuthlyXApp.SetVariable("theme", "dark")

value = AuthlyXApp.GetVariable("theme")
print(value)
```

## Logging

By default, SDK logging is enabled.

Logs are written to:

`C:\ProgramData\AuthlyX\{AppName}\YYYY_MM_DD.log`

Sensitive values such as passwords, secrets, session IDs, request IDs, nonces, license keys, and hashes are masked automatically.
