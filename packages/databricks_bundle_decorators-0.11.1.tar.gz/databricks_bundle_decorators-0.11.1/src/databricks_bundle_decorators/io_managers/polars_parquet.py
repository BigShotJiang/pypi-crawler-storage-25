"""Cloud-agnostic Polars Parquet IoManager.

Reads and writes Polars DataFrames as Parquet files to any storage backend
supported by Polars (local, ``abfss://``, ``s3://``, ``gs://``, …).

Requires the ``polars`` optional dependency::

    uv add databricks-bundle-decorators[polars]
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, cast

from databricks_bundle_decorators.io_manager import (
    InputContext,
    IoManager,
    OutputContext,
    RetryConfig,
    _needs_backfill_key_col,
    _polars_apply_partition_filter,
    _polars_extract_partition_values,
    _resolve_backfill_key,
    _should_inject_backfill_key,
)


class PolarsParquetIoManager(IoManager):
    """Persist Polars DataFrames as Parquet on any cloud or local filesystem.

    Automatically dispatches based on return-value type:

    - `polars.DataFrame` → ``write_parquet`` / ``read_parquet``
    - `polars.LazyFrame` → ``sink_parquet`` / ``scan_parquet``

    On the **read** side, the downstream task's parameter type annotation
    determines the method used.  Annotate the parameter as
    ``pl.DataFrame`` to receive an eager read; otherwise (including
    unannotated parameters) a lazy ``scan_parquet`` is used by default.

    Parameters
    ----------
    base_path : str | Callable[[], str]
        Root URI for Parquet files.  Can be a local path (``/tmp/data``),
        an Azure URI (``abfss://container@account.dfs.core.windows.net/path``),
        an S3 URI (``s3://bucket/prefix``), a GCS URI (``gs://bucket/prefix``),
        or any other URI scheme that Polars supports.

        Can also be a **callable** that returns a string, resolved lazily
        at runtime.  Use this for multi-environment deployments where the
        path depends on job parameters::

            from databricks_bundle_decorators import params

            io = PolarsParquetIoManager(
                base_path=lambda: f"abfss://lake@{params['env']}account.dfs.core.windows.net/data",
            )
    storage_options : dict[str, str] | Callable[[], dict[str, str]] | None
        Credentials / options forwarded to Polars I/O calls.
        Can be a plain dict, a **callable** that returns a dict (resolved
        lazily on each read/write), or ``None``.

        Use a callable to defer credential lookup to runtime — this is
        essential when credentials come from ``get_dbutils`` which is only
        available on a Databricks cluster, not during local bundle deploy::

            from databricks_bundle_decorators import get_dbutils


            def _storage_options() -> dict[str, str]:
                dbutils = get_dbutils()
                key = dbutils.secrets.get(scope="kv", key="storage-key")
                return {"account_name": "myaccount", "account_key": key}


            io = PolarsParquetIoManager(
                base_path="abfss://lake@myaccount.dfs.core.windows.net/staging",
                storage_options=_storage_options,
            )

        A plain dict also works when credentials are known statically::

            {"account_name": "...", "account_key": "..."}  # Azure
            {"aws_access_key_id": "...", "aws_secret_access_key": "..."}  # S3

    write_options : dict[str, Any] | None
        Extra keyword arguments forwarded to the Polars write call
        (``write_parquet`` / ``sink_parquet``).  For example::

            {"compression": "zstd", "row_group_size": 100_000}

        Do **not** include ``storage_options`` here — use the
        dedicated parameter instead.
    read_options : dict[str, Any] | None
        Extra keyword arguments forwarded to the Polars read call
        (``read_parquet`` / ``scan_parquet``).
    retry : `RetryConfig` | None
        Optional retry configuration for write operations.  When set,
        failed writes are retried with exponential backoff (powered by
        `tenacity`).  Useful for handling transient write conflicts
        during concurrent backfill runs.  Defaults to ``None``
        (no retries).

    Example
    -------
    ::

        from databricks_bundle_decorators.io_managers import PolarsParquetIoManager

        io = PolarsParquetIoManager(
            base_path="abfss://lake@myaccount.dfs.core.windows.net/staging",
            storage_options={"account_name": "myaccount", "account_key": "***"},
        )


        @task(io_manager=io)
        def extract() -> pl.LazyFrame:  # sink_parquet on write
            return pl.LazyFrame({"a": [1, 2]})


        @task
        def transform(df: pl.LazyFrame):  # scan_parquet on read
            print(df.collect())
    """

    def __init__(
        self,
        base_path: str | Callable[[], str],
        storage_options: dict[str, str] | Callable[[], dict[str, str]] | None = None,
        write_options: dict[str, Any] | None = None,
        read_options: dict[str, Any] | None = None,
        *,
        auto_filter: bool = True,
        retry: RetryConfig | None = None,
    ) -> None:
        self._base_path = base_path
        self._storage_options = storage_options
        self._write_options = write_options or {}
        self._read_options = read_options or {}
        self.auto_filter = auto_filter
        self.retry = retry

    @property
    def base_path(self) -> str:
        """Resolve *base_path*, calling it first if it is a callable."""
        if isinstance(self._base_path, str):
            return self._base_path.rstrip("/")
        return self._base_path().rstrip("/")

    @property
    def storage_options(self) -> dict[str, str] | None:
        """Resolve *storage_options*, calling it first if it is a callable."""
        if callable(self._storage_options):
            return cast("Callable[[], dict[str, str]]", self._storage_options)()
        return self._storage_options

    def _uri(self, key: str) -> str:
        return f"{self.base_path}/{key}"

    def write(self, context: OutputContext, obj: Any) -> None:
        """Write a Polars DataFrame or LazyFrame to Parquet.

        - `polars.DataFrame` → ``write_parquet`` (native ``partition_by``)
        - `polars.LazyFrame` → ``sink_parquet`` (``pl.PartitionBy``)

        When ``partition_by`` is set on the ``@task`` decorator, writes
        to Hive-style partitioned directories.
        """
        import polars as pl  # noqa: PLC0415

        base_uri = self._uri(context.task_key)
        partition_by = context.partition_by

        # Inject backfill_key column if it's a partition column
        has_bk_col = isinstance(
            obj, (pl.DataFrame, pl.LazyFrame)
        ) and "backfill_key" in (
            obj.collect_schema().names()
            if isinstance(obj, pl.LazyFrame)
            else obj.columns
        )
        if _should_inject_backfill_key(partition_by, has_backfill_key_col=has_bk_col):
            bk = _resolve_backfill_key(context.backfill_key)
            obj = obj.with_columns(pl.lit(bk).alias("backfill_key"))

        if partition_by:
            # Extract partition values from data before writing
            self._last_partition_values = _polars_extract_partition_values(
                obj, partition_by
            )
            if isinstance(obj, pl.LazyFrame):
                obj.sink_parquet(
                    pl.PartitionBy(base_uri, key=partition_by),
                    mkdir=True,
                    storage_options=self.storage_options,
                    **self._write_options,
                )
            elif isinstance(obj, pl.DataFrame):
                obj.write_parquet(
                    base_uri,
                    partition_by=partition_by,
                    mkdir=True,
                    storage_options=self.storage_options,
                    **self._write_options,
                )
            else:
                msg = (
                    f"PolarsParquetIoManager.write() expects a polars.DataFrame or "
                    f"polars.LazyFrame, got {type(obj).__name__}"
                )
                raise TypeError(msg)
        else:
            uri = f"{base_uri}.parquet"
            if isinstance(obj, pl.LazyFrame):
                obj.sink_parquet(
                    uri, storage_options=self.storage_options, **self._write_options
                )
            elif isinstance(obj, pl.DataFrame):
                obj.write_parquet(
                    uri, storage_options=self.storage_options, **self._write_options
                )
            else:
                msg = (
                    f"PolarsParquetIoManager.write() expects a polars.DataFrame or "
                    f"polars.LazyFrame, got {type(obj).__name__}"
                )
                raise TypeError(msg)

    def read(self, context: InputContext) -> Any:
        """Read Parquet as a LazyFrame or DataFrame.

        If the downstream parameter is annotated as `polars.DataFrame`,
        returns ``read_parquet`` (eager).  Otherwise returns ``scan_parquet``
        (lazy `polars.LazyFrame`) — this is the default for
        unannotated parameters.

        When ``partition_by`` is set on the producing ``@task``, reads
        from the Hive-partitioned directory.  By default only the
        current ``backfill_key`` partition is returned; use
        `all_partitions()` on the upstream dependency or
        ``@task(all_partitions=True)`` on the consuming task to read
        all partitions.
        """
        import polars as pl  # noqa: PLC0415

        base_uri = self._uri(context.upstream_task_key)
        partition_by = context.partition_by

        if partition_by:
            glob_uri = f"{base_uri}/**/*.parquet"
            if context.expected_type is pl.DataFrame:
                result = pl.read_parquet(
                    glob_uri,
                    hive_partitioning=True,
                    storage_options=self.storage_options,
                    **self._read_options,
                )
            else:
                result = pl.scan_parquet(
                    glob_uri,
                    hive_partitioning=True,
                    storage_options=self.storage_options,
                    **self._read_options,
                )
            if context.partition_filter and not context.all_partitions:
                result = _polars_apply_partition_filter(
                    result, context.partition_filter
                )
            elif (
                self.auto_filter
                and _needs_backfill_key_col(partition_by)
                and not context.all_partitions
            ):
                result = result.filter(
                    pl.col("backfill_key")
                    == _resolve_backfill_key(context.backfill_key)
                )
            return result

        uri = f"{base_uri}.parquet"
        if context.expected_type is pl.DataFrame:
            return pl.read_parquet(
                uri, storage_options=self.storage_options, **self._read_options
            )
        return pl.scan_parquet(
            uri, storage_options=self.storage_options, **self._read_options
        )
