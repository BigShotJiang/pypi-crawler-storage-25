# qdrant-tensr-dev

Lightweight Python SDK for the Qdrant Dashboard external API.

- **Zero required dependencies** — uses `httpx`, `requests`, or stdlib `urllib` in that order
- **Single file** — copy `qdrant_tensr_dev.py` or install via pip
- **Mirrors the Qdrant client API** — familiar method names (`upsert`, `search`, `scroll`, …)

## Install

```bash
pip install qdrant-tensr-dev
# optional: bring your own HTTP library
pip install qdrant-tensr-dev[httpx]
pip install qdrant-tensr-dev[requests]
```

## Quick start

```python
from qdrant_tensr_dev import TensrClient

client = TensrClient(
    base_url="https://your-dashboard-host",
    api_key="YOUR_API_KEY",          # from Dashboard → Groups → API Keys
)

# List all collections in your group
cols = client.list_collections()
print(cols)
# {"group_id": "...", "collections": [{"name": "...", "vector_size": 384, "distance": "Cosine"}, ...]}

# Get detailed info for one collection
info = client.get_collection("my-collection")

# Upsert vectors
client.upsert("my-collection", points=[
    {
        "id": "550e8400-e29b-41d4-a716-446655440001",
        "vector": [0.1, 0.2, 0.3],
        "payload": {"text": "hello world", "source": "docs"},
    },
])

# Nearest-neighbour search
results = client.search("my-collection", vector=[0.1, 0.2, 0.3], limit=5)
for hit in results:
    print(hit["score"], hit["payload"])

# Cross-collection search across every collection in your group at once
hits = client.search_all(vector=[0.1, 0.2, 0.3], limit=10)
for hit in hits:
    print(hit["collection"], hit["score"], hit["payload"])

# Scroll (paginate) all points
offset = None
while True:
    page = client.scroll("my-collection", limit=100, offset=offset)
    for pt in page["points"]:
        print(pt["id"], pt["payload"])
    offset = page["next_offset"]
    if offset is None:
        break

# Get a single point
pt = client.get_point("my-collection", "550e8400-e29b-41d4-a716-446655440001")

# Count points
total = client.count("my-collection")

# Delete points
client.delete("my-collection", ids=["550e8400-e29b-41d4-a716-446655440001"])
```

## API reference

| Method | Description |
|---|---|
| `list_collections()` | List all active collections in your group |
| `get_collection(name)` | Get metadata + live stats for a collection |
| `upsert(collection, points)` | Insert or update points |
| `delete(collection, ids)` | Delete points by ID |
| `get_point(collection, point_id)` | Retrieve a single point |
| `scroll(collection, ...)` | Page through all points |
| `count(collection)` | Count total points |
| `search(collection, vector, ...)` | Nearest-neighbour search (single collection) |
| `search_all(vector, ...)` | Cross-collection search across all group collections |

All methods raise `TensrError(status_code, detail)` on HTTP errors.

## CLI smoke-test

```bash
python -m qdrant_tensr_dev --url https://your-host --key YOUR_KEY
```
