"""
qdrant-tensr-dev
================
Lightweight Python client for the Qdrant Dashboard external API.

Install:
    pip install qdrant-tensr-dev

Quick start:
    from qdrant_tensr_dev import TensrClient

    client = TensrClient(
        base_url="https://your-dashboard-host",
        api_key="your-api-key-here",
    )

    # List all collections in your group
    collections = client.list_collections()

    # Upsert vectors
    client.upsert("my-collection", points=[
        {"id": "550e8400-e29b-41d4-a716-446655440000", "vector": [0.1, 0.2, 0.3], "payload": {"text": "hello"}},
    ])

    # Search
    results = client.search("my-collection", vector=[0.1, 0.2, 0.3], limit=5)

    # Cross-collection search across every collection in your group
    hits = client.search_all(vector=[0.1, 0.2, 0.3], limit=10)
"""

from __future__ import annotations

import json
from typing import Any, Optional

# ---------------------------------------------------------------------------
# HTTP backend — prefer httpx, fall back to requests, then stdlib urllib
# ---------------------------------------------------------------------------
try:
    import httpx as _httpx  # type: ignore

    def _request(method: str, url: str, headers: dict, body: Any = None) -> tuple[int, Any]:
        resp = _httpx.request(method, url, headers=headers, json=body, timeout=30)
        return resp.status_code, resp.json()

except ImportError:
    try:
        import requests as _requests  # type: ignore

        def _request(method: str, url: str, headers: dict, body: Any = None) -> tuple[int, Any]:
            resp = _requests.request(method, url, headers=headers, json=body, timeout=30)
            return resp.status_code, resp.json()

    except ImportError:
        import urllib.request as _urllib
        import urllib.error

        def _request(method: str, url: str, headers: dict, body: Any = None) -> tuple[int, Any]:
            data = json.dumps(body).encode() if body is not None else None
            req = _urllib.Request(url, data=data, headers=headers, method=method)
            try:
                with _urllib.urlopen(req, timeout=30) as r:
                    return r.status, json.loads(r.read())
            except urllib.error.HTTPError as e:
                return e.code, json.loads(e.read())


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class TensrError(Exception):
    """Raised when the API returns a non-2xx response."""

    def __init__(self, status_code: int, detail: Any):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class TensrClient:
    """
    Python client for the Qdrant Dashboard external API.

    Parameters
    ----------
    base_url : str
        Base URL of the dashboard, e.g. ``"https://qdrant.example.com"``.
        No trailing slash.
    api_key : str
        API key obtained from the dashboard Groups → API Keys section.
    """

    def __init__(self, base_url: str, api_key: str):
        self._base = base_url.rstrip("/")
        self._headers = {
            "X-Api-Key": api_key,
            "Content-Type": "application/json",
        }

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _call(self, method: str, path: str, body: Any = None) -> Any:
        url = f"{self._base}{path}"
        status, data = _request(method, url, self._headers, body)
        if status >= 400:
            detail = data.get("detail", data) if isinstance(data, dict) else data
            raise TensrError(status, detail)
        return data

    # ------------------------------------------------------------------
    # Collections
    # ------------------------------------------------------------------

    def list_collections(self) -> dict:
        """
        List all active collections in the group tied to your API key.

        Returns
        -------
        dict
            ``{"group_id": "...", "collections": [{"name": ..., "vector_size": ..., "distance": ...}, ...]}``
        """
        return self._call("GET", "/api/v1/collections")

    def get_collection(self, name: str) -> dict:
        """
        Get detailed info about a single collection.

        Parameters
        ----------
        name : str
            Collection display name (as shown in the dashboard).

        Returns
        -------
        dict
            ``{"name": ..., "vector_size": ..., "distance": ..., "points_count": ..., "status": ...}``
        """
        return self._call("GET", f"/api/v1/collections/{name}")

    # ------------------------------------------------------------------
    # Points — write
    # ------------------------------------------------------------------

    def upsert(self, collection: str, points: list[dict]) -> dict:
        """
        Insert or update points in a collection.

        Each point must have:
        - ``id``      — UUID string or integer
        - ``vector``  — list of floats matching the collection's vector size
        - ``payload`` — optional dict of metadata

        Parameters
        ----------
        collection : str
            Collection display name.
        points : list[dict]
            e.g. ``[{"id": "uuid-...", "vector": [0.1, ...], "payload": {"key": "val"}}]``

        Returns
        -------
        dict
            ``{"upserted": <count>}``
        """
        return self._call("PUT", f"/api/v1/collections/{collection}/points", {"points": points})

    def delete(self, collection: str, ids: list) -> dict:
        """
        Delete points by ID from a collection.

        Parameters
        ----------
        collection : str
            Collection display name.
        ids : list
            List of point IDs (UUID strings or integers) to delete.

        Returns
        -------
        dict
            ``{"deleted": <count>}``
        """
        return self._call("POST", f"/api/v1/collections/{collection}/points/delete", {"ids": ids})

    # ------------------------------------------------------------------
    # Points — read
    # ------------------------------------------------------------------

    def get_point(self, collection: str, point_id: str, with_vectors: bool = False) -> dict:
        """
        Retrieve a single point by ID.

        Parameters
        ----------
        collection : str
            Collection display name.
        point_id : str
            UUID string or integer ID of the point.
        with_vectors : bool
            Include the vector in the response (default False).

        Returns
        -------
        dict
            ``{"id": ..., "payload": {...}, "vector": [...] | null}``
        """
        path = f"/api/v1/collections/{collection}/points/{point_id}"
        if with_vectors:
            path += "?with_vectors=true"
        return self._call("GET", path)

    def scroll(
        self,
        collection: str,
        limit: int = 20,
        offset: Optional[str] = None,
        with_payload: bool = True,
        with_vectors: bool = False,
    ) -> dict:
        """
        Page through all points in a collection.

        Parameters
        ----------
        collection : str
            Collection display name.
        limit : int
            Max points to return per page (default 20).
        offset : str, optional
            Cursor from a previous scroll response's ``next_offset`` field.
        with_payload : bool
            Include payloads (default True).
        with_vectors : bool
            Include vectors (default False).

        Returns
        -------
        dict
            ``{"points": [...], "next_offset": "..." | null}``

        Example
        -------
        ::

            offset = None
            while True:
                page = client.scroll("my-collection", limit=100, offset=offset)
                process(page["points"])
                offset = page["next_offset"]
                if offset is None:
                    break
        """
        body: dict[str, Any] = {
            "limit": limit,
            "with_payload": with_payload,
            "with_vectors": with_vectors,
        }
        if offset is not None:
            body["offset"] = offset
        return self._call("POST", f"/api/v1/collections/{collection}/points/scroll", body)

    def count(self, collection: str) -> int:
        """
        Return the total number of points in a collection.

        Parameters
        ----------
        collection : str
            Collection display name.

        Returns
        -------
        int
            Total point count.
        """
        return self._call("POST", f"/api/v1/collections/{collection}/points/count")["count"]

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(
        self,
        collection: str,
        vector: list[float],
        limit: int = 10,
        score_threshold: Optional[float] = None,
        with_payload: bool = True,
    ) -> list[dict]:
        """
        Nearest-neighbour vector search within a single collection.

        Parameters
        ----------
        collection : str
            Collection display name.
        vector : list[float]
            Query vector. Length must match the collection's ``vector_size``.
        limit : int
            Max results to return (default 10).
        score_threshold : float, optional
            Minimum similarity score. Results below this are excluded.
        with_payload : bool
            Include payloads in results (default True).

        Returns
        -------
        list[dict]
            Sorted by score descending.
            Each hit: ``{"id": ..., "score": ..., "payload": {...}}``
        """
        body: dict[str, Any] = {
            "vector": vector,
            "limit": limit,
            "with_payload": with_payload,
        }
        if score_threshold is not None:
            body["score_threshold"] = score_threshold
        resp = self._call("POST", f"/api/v1/collections/{collection}/points/search", body)
        return resp.get("results", [])

    def search_all(
        self,
        vector: list[float],
        limit: int = 10,
        score_threshold: Optional[float] = None,
    ) -> list[dict]:
        """
        Cross-collection search: searches **every** active collection in your
        group simultaneously and returns merged, re-ranked results.

        Parameters
        ----------
        vector : list[float]
            Query vector. All collections in the group must share the same
            vector size.
        limit : int
            Max total results to return (default 10).
        score_threshold : float, optional
            Minimum similarity score across all collections.

        Returns
        -------
        list[dict]
            Merged results sorted by score descending.
            Each hit: ``{"collection": "<name>", "id": ..., "score": ..., "payload": {...}}``
        """
        body: dict[str, Any] = {"vector": vector, "limit": limit}
        if score_threshold is not None:
            body["score_threshold"] = score_threshold
        resp = self._call("POST", "/api/v1/search", body)
        return resp.get("results", [])


# ---------------------------------------------------------------------------
# CLI smoke-test  →  python -m qdrant_tensr_dev --url https://... --key KEY
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="Smoke-test the qdrant-tensr-dev client")
    parser.add_argument("--url", required=True, help="Dashboard base URL")
    parser.add_argument("--key", required=True, help="API key")
    args = parser.parse_args()

    client = TensrClient(base_url=args.url, api_key=args.key)

    print("Listing collections …")
    try:
        result = client.list_collections()
        cols = result.get("collections", [])
        print(f"  Found {len(cols)} collection(s)")
        for c in cols:
            print(f"    • {c['name']}  ({c['vector_size']}d, {c['distance']})")
    except TensrError as e:
        print(f"  ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    print("Done.")
