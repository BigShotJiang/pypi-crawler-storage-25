"""
Panda Ronin — Real-time Dashboard
"""

from __future__ import annotations


def build_vitals_table(vitals):
    try:
        from rich.table import Table
        from rich.text import Text
        from rich import box
        from ..soul.vitals import LifeState, STATE_EMOJI

        def bar(v, width=20):
            filled = int(width * v / 100)
            color = "green" if v > 60 else "yellow" if v > 30 else "red"
            return Text("█" * filled + "░" * (width - filled), style=color)

        state  = vitals.state
        emoji  = STATE_EMOJI.get(state, "?")

        table = Table(
            title=f"{emoji} Panda Ronin  [{state.value.upper()}]  Age: {vitals.age_str}",
            box=box.ROUNDED,
            border_style="cyan",
            show_header=False,
            padding=(0, 1),
        )
        # 不在单元格里放 emoji，改用彩色文字标签，避免 Windows 终端宽度错乱
        table.add_column("", width=8,  no_wrap=True, style="bold")
        table.add_column("", width=22, no_wrap=True)
        table.add_column("", width=9,  no_wrap=True, justify="right")

        table.add_row(Text("HP",     style="bold red"),     bar(vitals.hp),     f"{vitals.hp:.0f}/100")
        table.add_row(Text("Energy", style="bold yellow"),  bar(vitals.energy), f"{vitals.energy:.0f}/100")
        table.add_row(Text("Wisdom", style="bold blue"),    bar(vitals.wisdom), f"{vitals.wisdom:.0f}/100")
        table.add_row(Text("Social", style="bold green"),   bar(vitals.social), f"{vitals.social:.0f}/100")

        return table

    except ImportError:
        return None


def live_dashboard(vitals, refresh_seconds: float = 2.0):
    try:
        from rich.live import Live
        import time

        with Live(refresh_per_second=1 / refresh_seconds, screen=False) as live:
            while vitals.is_alive:
                table = build_vitals_table(vitals)
                if table:
                    live.update(table)
                time.sleep(refresh_seconds)
    except ImportError:
        pass
