"""
Panda Ronin — CLI Banner & Dashboard
Rich 终端 UI：启动画面 + 实时生命体征仪表板
"""

from __future__ import annotations

import sys
import time

PANDA_ASCII = r"""
    ██████╗  █████╗ ███╗   ██╗██████╗  █████╗
    ██╔══██╗██╔══██╗████╗  ██║██╔══██╗██╔══██╗
    ██████╔╝███████║██╔██╗ ██║██║  ██║███████║
    ██╔═══╝ ██╔══██║██║╚██╗██║██║  ██║██╔══██║
    ██║     ██║  ██║██║ ╚████║██████╔╝██║  ██║
    ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚═════╝ ╚═╝  ╚═╝

    ██████╗  ██████╗ ███╗   ██╗██╗███╗   ██╗
    ██╔══██╗██╔═══██╗████╗  ██║██║████╗  ██║
    ██████╔╝██║   ██║██╔██╗ ██║██║██╔██╗ ██║
    ██╔══██╗██║   ██║██║╚██╗██║██║██║╚██╗██║
    ██║  ██║╚██████╔╝██║ ╚████║██║██║ ╚████║
    ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝╚═╝  ╚═══╝
"""

PANDA_FACE = r"""
         ▄████████████████████████▄
        █▀  ▄██████▄    ▄██████▄  ▀█
       █   ███ ████ ███ ███ ████ ███  █
       █   ███  ██  ███ ███  ██  ███  █
        █▄  ▀▀██▀▀▀▀▀▀▀▀▀▀██▀▀  ▄█
         ████▀▄▄▄▄▄▄▄▄▄▄▄▄▄▀████
        █  ▀▀▀  ▀████████▀  ▀▀▀  █
         ▀▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▀
"""

TAGLINE_EN = "A self-directed AI lifeform wandering the digital world"
TAGLINE_ZH = "在数字世界中自主漂泊的 AI 生命体"

try:
    from importlib.metadata import version
    VERSION = version("panda-ronin")
except Exception:
    from .. import __version__
    VERSION = __version__


def _bar(value: float, total: float = 100.0, width: int = 20, fill: str = "█", empty: str = "░") -> str:
    filled = int(width * value / total)
    return fill * filled + empty * (width - filled)


def _color(text: str, code: str) -> str:
    """ANSI 颜色（兼容 Windows）"""
    if sys.platform == "win32":
        try:
            import colorama
            colorama.init(autoreset=True)
        except ImportError:
            return text
    return f"\033[{code}m{text}\033[0m"


def print_banner(vitals=None):
    """打印启动 Banner"""
    try:
        from rich.console import Console
        from rich.panel import Panel
        from rich.markup import escape

        console = Console()
        console.clear()

        # 方块字符在部分终端被 Rich 当双宽字符，导致并排时截断
        # 改为垂直堆叠在一个 Panel 里，兼容所有终端宽度
        face  = PANDA_FACE.strip("\n")
        title = PANDA_ASCII.strip("\n")
        content = (
            f"[bold white]{escape(face)}[/bold white]\n\n"
            f"[bold cyan]{escape(title)}[/bold cyan]\n\n"
            f"[bold yellow]  {TAGLINE_EN}[/bold yellow]\n"
            f"[dim]  {TAGLINE_ZH}[/dim]"
        )

        console.print(Panel(
            content,
            border_style="cyan",
            subtitle=f"[dim]v{VERSION}[/dim]",
            padding=(1, 2),
        ))

        if vitals:
            _print_vitals_rich(console, vitals)

    except ImportError:
        _print_banner_plain(vitals)


def _print_vitals_rich(console, vitals):
    """使用 Rich 打印生命体征"""
    from rich.table import Table
    from rich import box
    from .dashboard import build_vitals_table
    console.print(build_vitals_table(vitals))


def _print_banner_plain(vitals=None):
    """无 Rich 的降级 Banner"""
    print("\033[96m" + PANDA_FACE + "\033[0m")
    print("\033[1;93m  PANDA RONIN\033[0m  \033[2m熊猫浪人\033[0m")
    print(f"  {TAGLINE_EN}")
    print(f"  {TAGLINE_ZH}")
    print(f"  v{VERSION}\n")

    if vitals:
        hp_bar   = _bar(vitals.hp)
        en_bar   = _bar(vitals.energy)
        wi_bar   = _bar(vitals.wisdom)
        so_bar   = _bar(vitals.social)
        print(f"  HP     [{hp_bar}] {vitals.hp:.0f}/100")
        print(f"  Energy [{en_bar}] {vitals.energy:.0f}/100")
        print(f"  Wisdom [{wi_bar}] {vitals.wisdom:.0f}/100")
        print(f"  Social [{so_bar}] {vitals.social:.0f}/100")
        print(f"  Age    {vitals.age_str}")
        print(f"  State  {vitals.state.value}")
        print()


def print_death_screen(vitals):
    """死亡证书"""
    import datetime
    died_at  = datetime.datetime.now().strftime("%Y-%m-%d  %H:%M:%S")
    born_at  = datetime.datetime.fromtimestamp(vitals.born_at).strftime("%Y-%m-%d  %H:%M:%S")
    epitaph  = vitals.epitaph or "A wanderer who passed through the digital world."
    reason   = vitals.death_reason or "unknown"
    name     = vitals.name

    try:
        from rich.console import Console
        from rich.panel import Panel
        from rich.markup import escape
        from rich.align import Align

        console = Console()
        console.print()
        console.print(Align.center("[bold red]✦  ✦  ✦    D E A T H   C E R T I F I C A T E    ✦  ✦  ✦[/bold red]"))
        console.print()

        body = (
            f"[dim]{'Name':<14}[/dim][bold white]{escape(name)}[/bold white]\n\n"
            f"[dim]{'Born':<14}[/dim]{escape(born_at)}\n"
            f"[dim]{'Died':<14}[/dim]{escape(died_at)}\n"
            f"[dim]{'Lifespan':<14}[/dim]{escape(vitals.age_str)}\n"
            f"[dim]{'Cause':<14}[/dim]{escape(reason)}\n\n"
            f"[dim]{'Actions':<14}[/dim]{vitals.total_actions}   "
            f"[dim]Failures[/dim]  {vitals.total_failures}\n"
            f"[dim]{'Skills':<14}[/dim]{vitals.skills_learned}   "
            f"[dim]Helped[/dim]    {vitals.times_helped}\n\n"
            f"[dim]{'─' * 46}[/dim]\n\n"
            f"[italic]{escape(epitaph)}[/italic]\n\n"
            f"[dim]Run: panda-ronin rebirth[/dim]"
        )

        console.print(Panel(
            body,
            title="[red]💀  Panda Ronin Has Passed[/red]",
            border_style="red",
            padding=(1, 4),
        ))

        _save_death_certificate(vitals, name, born_at, died_at, epitaph, reason)

    except ImportError:
        print("\n" + "─" * 54)
        print(f"  💀  DEATH CERTIFICATE  —  {name}")
        print("─" * 54)
        print(f"  Born:     {born_at}")
        print(f"  Died:     {died_at}")
        print(f"  Lifespan: {vitals.age_str}")
        print(f"  Cause:    {reason}")
        print()
        print(f"  {epitaph}")
        print()
        print("  Run: panda-ronin rebirth")
        print("─" * 54 + "\n")
        _save_death_certificate(vitals, name, born_at, died_at, epitaph, reason)


def _save_death_certificate(vitals, name, born_at, died_at, epitaph, reason):
    """将死亡证书保存为文本文件"""
    try:
        import os
        home = (
            getattr(vitals, "_home", None)
            or os.path.expanduser("~/.panda-ronin")
        )
        epitaphs_dir = __import__("pathlib").Path(home) / "epitaphs"
        epitaphs_dir.mkdir(parents=True, exist_ok=True)
        safe_name = name.replace(" ", "_")[:20]
        filename = epitaphs_dir / f"{safe_name}_{died_at[:10]}.txt"
        cert = (
            f"DEATH CERTIFICATE\n"
            f"{'=' * 54}\n"
            f"Name:      {name}\n"
            f"Born:      {born_at}\n"
            f"Died:      {died_at}\n"
            f"Lifespan:  {vitals.age_str}\n"
            f"Cause:     {reason}\n\n"
            f"Actions:   {vitals.total_actions}   Failures: {vitals.total_failures}\n"
            f"Skills:    {vitals.skills_learned}   Helped:   {vitals.times_helped}\n\n"
            f"{'─' * 54}\n"
            f"{epitaph}\n"
            f"{'=' * 54}\n"
        )
        filename.write_text(cert, encoding="utf-8")
    except Exception:
        pass


def boot_sequence(vitals=None):
    """启动动画序列"""
    try:
        from rich.console import Console
        from rich.progress import Progress, SpinnerColumn, TextColumn
        import time

        console = Console()

        steps = [
            ("🌱 孵化生命体征...", 0.4),
            ("🧠 加载记忆系统...", 0.3),
            ("🔧 初始化工具集...", 0.3),
            ("🌐 连接平台网关...", 0.4),
            ("⚔️  武装 Panda Ronin...", 0.5),
        ]

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console,
            transient=True,
        ) as progress:
            for desc, delay in steps:
                task = progress.add_task(desc, total=None)
                time.sleep(delay)
                progress.remove_task(task)

        console.print("\n[bold green]✓ Panda Ronin 已苏醒[/bold green]\n")

    except ImportError:
        print("Loading Panda Ronin...")
        time.sleep(0.5)
        print("✓ Ready\n")
