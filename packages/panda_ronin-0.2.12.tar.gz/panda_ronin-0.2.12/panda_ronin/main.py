"""
Panda Ronin — Entry Point
Usage: panda-ronin [options]
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path


def _setup_logging(verbose: bool = False):
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )


def cmd_start(args):
    """Start Panda Ronin."""
    from .config import Config
    from .soul.vitals import Vitals
    from .soul.lifecycle import LifecycleEngine
    from .soul.needs import NeedsManager
    from .memory.provider import BuiltinMemoryProvider
    from .tools.registry import create_default_registry
    from .agent.core import PandaRonin
    from .platform.gateway import build_gateway
    from .ui.banner import print_banner, boot_sequence

    config = Config.load(args.config)
    if not config.llm.api_key:
        print("❌ API Key 未配置。")
        print("   运行: panda-ronin onboard")
        sys.exit(1)

    home = Path(config.lifecycle.home_dir).expanduser()

    vitals = Vitals.load(home)
    if args.rebirth:
        import time
        vitals = Vitals()
        vitals.born_at = time.time()
        print("🌱 A new life begins...")
    # Apply panda name from config if vitals still has the default name
    if vitals.name == "Panda Ronin" and config.panda_name != "Panda Ronin":
        vitals.name = config.panda_name

    lifecycle = LifecycleEngine(vitals)
    needs_mgr = NeedsManager()
    memory = BuiltinMemoryProvider(home)
    registry = create_default_registry(home)

    boot_sequence()
    print_banner(vitals)

    agent = PandaRonin(
        api_key=config.llm.api_key,
        model=config.llm.model,
        base_url=config.llm.base_url,
        max_tokens=config.llm.max_tokens,
        vitals=vitals,
        lifecycle=lifecycle,
        needs_manager=needs_mgr,
        memory=memory,
        registry=registry,
        home=home,
    )

    gateway = build_gateway(config, agent)
    gateway.start_all()

    if not args.no_autonomy:
        agent.start_autonomous_loop(config.lifecycle.tick_interval_seconds)

    import atexit
    atexit.register(vitals.save, home)

    from .platform.adapters.cli import CLIAdapter
    cli = next((a for a in gateway._adapters if isinstance(a, CLIAdapter)), None)
    if cli:
        cli.run_repl()
    else:
        print("No CLI adapter. Running headless. Press Ctrl+C to exit.")
        try:
            import signal
            signal.pause()
        except (AttributeError, KeyboardInterrupt):
            import time
            while agent.vitals.is_alive:
                time.sleep(1)

    gateway.stop_all()


def cmd_status(args):
    """Show current vitals without starting the agent."""
    from .config import Config
    from .soul.vitals import Vitals
    from .ui.banner import print_banner

    config = Config.load(args.config)
    home = Path(config.lifecycle.home_dir).expanduser()
    vitals = Vitals.load(home)
    print_banner(vitals)

    if not vitals.is_alive:
        print("💀 Panda Ronin has passed away.")
        print(f"   {vitals.epitaph or 'No epitaph recorded.'}")


def cmd_rebirth(args):
    """Force a rebirth (reset soul)."""
    from .config import Config
    from .soul.vitals import Vitals
    import time

    config = Config.load(args.config)
    home = Path(config.lifecycle.home_dir).expanduser()
    old = Vitals.load(home)
    if old.epitaph:
        print(f"📜 Epitaph of fallen Panda: {old.epitaph}")
    vitals = Vitals()
    vitals.born_at = time.time()
    vitals.save(home)
    print("🌱 A new Panda Ronin has been born.")


def cmd_onboard(args):
    """Interactive setup wizard — choose provider, model, and enter API key."""
    import os

    _print_onboard_banner()

    # ── Step 0: 给 Panda 起名 ─────────────────────────────────
    _section("Step 0/4", "给你的 AI 生命体起个名字")
    print("  名字会出现在所有对话和死亡证书中。")
    raw_name = _ask("输入名字（直接回车使用 Panda Ronin）").strip()
    panda_name = raw_name or "Panda Ronin"
    print(f"\n  ✓ 名字：{panda_name}")

    # ── 厂商列表 ──────────────────────────────────────────────────
    PROVIDERS = [
        {
            "name": "Ollama (本地运行·完全免费·无需 API Key) ★ 推荐新手",
            "tag": "ollama",
            "models": [
                ("qwen2.5",            "Qwen2.5     — 中文最佳，推荐"),
                ("qwen2.5:14b",        "Qwen2.5 14B — 效果更好"),
                ("llama3.2",           "Llama 3.2"),
                ("deepseek-r1:8b",     "DeepSeek-R1 8B — 本地推理"),
            ],
            "key_url":  "https://ollama.com/download",
            "key_hint": None,
        },
        {
            "name": "DeepSeek 🇨🇳",
            "tag": "deepseek",
            "models": [
                ("deepseek-chat",      "DeepSeek-V3  — 性价比极高"),
                ("deepseek-reasoner",  "DeepSeek-R1  — 推理模型"),
            ],
            "key_url":  "https://platform.deepseek.com/",
            "key_hint": "sk-...",
        },
        {
            "name": "通义千问 Qwen 🇨🇳",
            "tag": "dashscope",
            "models": [
                ("qwen-max",           "Qwen-Max  — 最强"),
                ("qwen-plus",          "Qwen-Plus — 均衡"),
                ("qwen-turbo",         "Qwen-Turbo — 最快"),
            ],
            "key_url":  "https://dashscope.console.aliyun.com/",
            "key_hint": "sk-...",
        },
        {
            "name": "智谱 AI (GLM) 🇨🇳",
            "tag": "zhipuai",
            "models": [
                ("glm-4-plus",         "GLM-4-Plus  — 最强"),
                ("glm-4-flash",        "GLM-4-Flash — 免费"),
            ],
            "key_url":  "https://open.bigmodel.cn/",
            "key_hint": "xxx.xxx",
        },
        {
            "name": "Moonshot Kimi 🇨🇳",
            "tag": "moonshot",
            "models": [
                ("moonshot-v1-8k",     "Kimi 8k   — 快速"),
                ("moonshot-v1-128k",   "Kimi 128k — 长文本"),
            ],
            "key_url":  "https://platform.moonshot.cn/",
            "key_hint": "sk-...",
        },
        {
            "name": "OpenAI (GPT)",
            "tag": "openai",
            "models": [
                ("gpt-4o",             "GPT-4o       — 旗舰"),
                ("gpt-4o-mini",        "GPT-4o-mini  — 便宜"),
            ],
            "key_url":  "https://platform.openai.com/",
            "key_hint": "sk-...",
        },
        {
            "name": "Google Gemini",
            "tag": "gemini",
            "models": [
                ("gemini-1.5-pro",     "Gemini 1.5 Pro  — 旗舰"),
                ("gemini-1.5-flash",   "Gemini 1.5 Flash — 免费额度大"),
            ],
            "key_url":  "https://aistudio.google.com/",
            "key_hint": "AIza...",
        },
        {
            "name": "Groq (免费，极速)",
            "tag": "groq",
            "models": [
                ("llama-3.1-70b-versatile", "Llama 3.1 70B — 免费"),
                ("mixtral-8x7b-32768",      "Mixtral 8x7B  — 免费"),
            ],
            "key_url":  "https://console.groq.com/",
            "key_hint": "gsk_...",
        },
        {
            "name": "Anthropic (Claude) — 国际旗舰",
            "tag": "anthropic",
            "models": [
                ("claude-sonnet-4-6",  "Claude Sonnet 4.6  — 推荐，性能均衡"),
                ("claude-opus-4-7",    "Claude Opus 4.7   — 最强，较贵"),
                ("claude-haiku-4-5",   "Claude Haiku 4.5  — 最快，最便宜"),
            ],
            "key_url":  "https://console.anthropic.com/",
            "key_hint": "sk-ant-...",
        },
        {
            "name": "MiniMax 🇨🇳",
            "tag": "openai",
            "models": [
                ("MiniMax-M2.7",   "MiniMax-M2.7  — 推荐，标准版"),
                ("MiniMax-M2.5",   "MiniMax-M2.5  — 上一代"),
                ("abab6.5s-chat",  "abab6.5s      — 旧版，免费额度可用"),
            ],
            "key_url":  "https://platform.minimaxi.com/",
            "key_hint": "eyJ...",
            "base_url": "https://api.minimaxi.com/v1",
        },
        {
            "name": "硅基流动 SiliconFlow 🇨🇳",
            "tag": "openai",
            "models": [
                ("Qwen/Qwen2.5-72B-Instruct",      "Qwen2.5-72B — 免费"),
                ("deepseek-ai/DeepSeek-V3",         "DeepSeek-V3 — 免费"),
                ("meta-llama/Meta-Llama-3.1-70B-Instruct", "Llama 3.1 70B — 免费"),
            ],
            "key_url":  "https://cloud.siliconflow.cn/",
            "key_hint": "sk-...",
            "base_url": "https://api.siliconflow.cn/v1",
        },
        {
            "name": "文心一言 ERNIE (百度) 🇨🇳",
            "tag": "qianfan",
            "models": [
                ("ernie-4.0-8k",        "ERNIE 4.0  — 旗舰"),
                ("ernie-3.5-8k",        "ERNIE 3.5  — 均衡"),
                ("ernie-speed-128k",    "ERNIE Speed — 免费，长文本"),
            ],
            "key_url":  "https://console.bce.baidu.com/qianfan/",
            "key_hint": "Access Key（需同时设置 QIANFAN_SECRET_KEY）",
        },
        {
            "name": "讯飞星火 Spark 🇨🇳",
            "tag": "openai",
            "models": [
                ("lite",                "Spark Lite   — 免费"),
                ("generalv3.5",         "Spark Max    — 旗舰"),
                ("4.0Ultra",            "Spark 4.0    — 最新"),
            ],
            "key_url":  "https://xinghuo.xfyun.cn/",
            "key_hint": "sk-...",
            "base_url": "https://spark-api-open.xf-yun.com/v1",
        },
        {
            "name": "其他（手动输入）",
            "tag": "custom",
            "models": [],
            "key_url":  "https://docs.litellm.ai/docs/providers",
            "key_hint": "...",
        },
    ]

    # ── Step 1: 选择厂商 ──────────────────────────────────────────
    _section("Step 1/4", "选择模型厂商")
    for i, p in enumerate(PROVIDERS, 1):
        print(f"  {i:2d}.  {p['name']}")
    print()

    provider = None
    while provider is None:
        raw = _ask("请输入编号").strip()
        if raw.isdigit() and 1 <= int(raw) <= len(PROVIDERS):
            provider = PROVIDERS[int(raw) - 1]
        else:
            print("     请输入有效编号")

    # ── Step 2: 选择模型 ──────────────────────────────────────────
    _section("Step 2/4", "选择模型")

    model_id = ""
    if provider["tag"] == "custom":
        print("  参考文档：https://docs.litellm.ai/docs/providers")
        model_id = _ask("输入完整 model 字符串（如 openai/gpt-4o）").strip()
    elif provider["tag"] == "ollama":
        # 自动检测 Ollama 是否在运行
        import urllib.request as _ur
        _ollama_ok = False
        try:
            _ur.urlopen("http://localhost:11434/api/tags", timeout=2)
            _ollama_ok = True
            print("  ✓ 检测到 Ollama 正在运行")
        except Exception:
            print("  ⚠️  未检测到 Ollama，请先安装并运行：https://ollama.com/download")
            print("     安装后运行 `ollama pull qwen2.5` 拉取模型")
        for i, (mid, desc) in enumerate(provider["models"], 1):
            print(f"  {i}.  {mid:<28} {desc}")
        print(f"  {len(provider['models'])+1}.  手动输入其他模型")
        choice = _ask("请输入编号").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(provider["models"]):
            model_id = provider["models"][int(choice) - 1][0]
        else:
            model_id = _ask("输入 Ollama 模型名（如 qwen2.5:14b）").strip()
    else:
        for i, (mid, desc) in enumerate(provider["models"], 1):
            print(f"  {i}.  {mid:<28} {desc}")
        print(f"  {len(provider['models'])+1}.  手动输入其他模型 ID")
        choice = _ask("请输入编号").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(provider["models"]):
            model_id = provider["models"][int(choice) - 1][0]
        else:
            model_id = _ask("输入模型 ID").strip()

    # 拼完整 litellm model 字符串
    if provider["tag"] == "custom":
        full_model = model_id
    elif provider["tag"] == "ollama":
        full_model = f"ollama/{model_id}"
    else:
        full_model = f"{provider['tag']}/{model_id}"

    print(f"\n  ✓ 已选择模型：{full_model}")

    # ── Step 3: 输入 API Key ──────────────────────────────────────
    _section("Step 3/4", "API Key")
    api_key = ""

    if provider["tag"] == "ollama":
        print("  Ollama 本地运行，无需 API Key。")
        api_key = "ollama"
    else:
        if provider["key_url"]:
            print(f"  获取 Key：{provider['key_url']}")
        existing = _detect_existing_key(provider["tag"])
        if existing:
            print(f"  ✓ 检测到环境变量中已有 Key：{existing[:16]}...")
            use_existing = _ask("直接使用该 Key？[Y/n]").strip().lower()
            if use_existing in ("", "y", "yes"):
                api_key = existing
        if not api_key:
            api_key = _ask(f"粘贴你的 API Key（{provider['key_hint'] or '...'}）").strip()
            if not api_key:
                print("  ⚠️  未输入 Key，稍后可在 config.yaml 中填写。")

    # ── Step 4: 写入配置 ─────────────────────────────────────────
    _section("Step 4/4", "写入配置")
    config_path = Path.home() / ".panda-ronin" / "config.yaml"
    base_url = provider.get("base_url", "")
    _write_config(config_path, full_model, api_key, base_url, panda_name)

    # 同时把名字写入 soul.json（如果已存在就更新）
    soul_path = Path.home() / ".panda-ronin" / "soul.json"
    if soul_path.exists():
        import json as _json
        try:
            soul = _json.loads(soul_path.read_text(encoding="utf-8"))
            soul["name"] = panda_name
            soul_path.write_text(_json.dumps(soul, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    print(f"\n  ✓ 已写入 {config_path}")

    # ── 完成 ──────────────────────────────────────────────────────
    print()
    _print_success(full_model)


# ── onboard 辅助函数 ──────────────────────────────────────────────

def _section(step: str, title: str):
    try:
        from rich.console import Console
        from rich.rule import Rule
        Console().print(f"\n[bold cyan]{step}[/bold cyan]  [bold]{title}[/bold]")
    except ImportError:
        print(f"\n── {step}: {title} " + "─" * 30)


def _ask(prompt: str) -> str:
    try:
        from rich.console import Console
        return Console().input(f"  [bold yellow]❯[/bold yellow] {prompt}：")
    except ImportError:
        return input(f"  ❯ {prompt}：")
    except (KeyboardInterrupt, EOFError):
        print("\n  已取消。")
        sys.exit(0)


def _detect_existing_key(tag: str) -> str:
    import os
    mapping = {
        "anthropic": "ANTHROPIC_API_KEY",
        "openai":    "OPENAI_API_KEY",
        "deepseek":  "DEEPSEEK_API_KEY",
        "dashscope": "DASHSCOPE_API_KEY",
        "zhipuai":   "ZHIPUAI_API_KEY",
        "moonshot":  "MOONSHOT_API_KEY",
        "gemini":    "GEMINI_API_KEY",
        "groq":      "GROQ_API_KEY",
    }
    return os.getenv(mapping.get(tag, ""), "") or os.getenv("LLM_API_KEY", "")


def _write_config(config_path: Path, model: str, api_key: str, base_url: str = "", name: str = "Panda Ronin"):
    config_path.parent.mkdir(parents=True, exist_ok=True)
    content = f"""# Panda Ronin Configuration
# Generated by: panda-ronin onboard

panda:
  name: "{name}"

llm:
  model: "{model}"
  api_key: "{api_key}"
  base_url: "{base_url}"
  max_tokens: 4096

lifecycle:
  tick_interval_seconds: 300
  home_dir: "~/.panda-ronin"

http:
  enabled: true
  host: "0.0.0.0"
  port: 8080
  api_key: ""
"""
    config_path.write_text(content, encoding="utf-8")


def _print_success(model: str):
    try:
        from rich.console import Console
        from rich.panel import Panel
        Console().print(Panel(
            f"[bold green]✅  配置完成！[/bold green]\n\n"
            f"模型：[cyan]{model}[/cyan]\n\n"
            f"运行以下命令唤醒你的熊猫：\n\n"
            f"  [bold]panda-ronin start[/bold]",
            border_style="green",
            padding=(1, 2),
        ))
    except ImportError:
        print(f"✅  配置完成！模型：{model}")
        print("\n   panda-ronin start\n")


def cmd_log(args):
    """Show recent autonomous activity log."""
    from .config import Config
    config = Config.load(args.config)
    home = Path(config.lifecycle.home_dir).expanduser()
    log_file = home / "activity.log"
    if not log_file.exists():
        print("No activity yet. Start panda-ronin and let it roam for a while.")
        return
    lines = log_file.read_text(encoding="utf-8").splitlines()
    n = getattr(args, "n", 20)
    try:
        from rich.console import Console
        from rich.panel import Panel
        console = Console()
        recent = lines[-n:]
        console.print(Panel(
            "\n".join(recent),
            title="[cyan]📜 Recent Activity[/cyan]",
            border_style="cyan",
        ))
    except ImportError:
        for line in lines[-n:]:
            print(line)


def cmd_feed(args):
    """Restore energy directly without starting the agent."""
    from .config import Config
    from .soul.vitals import Vitals

    config = Config.load(args.config)
    home = Path(config.lifecycle.home_dir).expanduser()
    vitals = Vitals.load(home)

    if not vitals.is_alive:
        print("Panda has already died. Run: panda-ronin rebirth")
        return

    amount = min(args.amount, 100.0 - vitals.energy)
    vitals.restore_energy(amount)
    vitals.save(home)
    print(f"Energy +{amount:.0f}. Now: {vitals.energy:.0f}/100")
    print("Run: panda-ronin start")


def cmd_update(args):
    """Self-update panda-ronin to the latest version from GitHub."""
    import subprocess

    repo = "https://github.com/JacobeZhao/panda-ronin.git"
    channel = args.channel

    print(f"🔄 Updating panda-ronin ({channel})...")

    if channel == "stable":
        target = f"git+{repo}"
    else:
        target = f"git+{repo}@{channel}"

    # Detect pipx vs pip
    result = subprocess.run(
        ["pipx", "list", "--short"], capture_output=True, text=True
    )
    use_pipx = "panda-ronin" in result.stdout

    if use_pipx:
        cmd = ["pipx", "install", "--force", target]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", target]

    proc = subprocess.run(cmd)
    if proc.returncode == 0:
        from . import __version__
        print(f"✅  Updated successfully. Version: {__version__}")
    else:
        print("❌  Update failed. Try running manually:")
        print(f"   pip install --upgrade {target}")


def cmd_doctor(args):
    """Check installation health and configuration."""
    import importlib
    import os

    ok = True

    def check(label: str, passed: bool, hint: str = ""):
        nonlocal ok
        icon = "✓" if passed else "✗"
        color = "\033[32m" if passed else "\033[31m"
        reset = "\033[0m"
        print(f"  {color}{icon}{reset}  {label}")
        if not passed and hint:
            print(f"      → {hint}")
        if not passed:
            ok = False

    print("\n🩺  Panda Ronin — Doctor\n")

    # Python version
    v = sys.version_info
    check(f"Python {v.major}.{v.minor}.{v.micro}", v >= (3, 10),
          "Python 3.10+ required")

    # API key
    check("ANTHROPIC_API_KEY set",
          bool(os.getenv("ANTHROPIC_API_KEY") or _read_api_key_from_config()),
          "Run: panda-ronin onboard")

    # Required packages
    for pkg in ["anthropic", "rich", "yaml"]:
        mod = "pyyaml" if pkg == "yaml" else pkg
        loaded = importlib.util.find_spec(pkg) is not None
        check(f"Package: {mod}", loaded, f"pip install {mod}")

    # Optional packages
    print()
    for pkg, label in [
        ("requests",          "requests (web fetch)"),
        ("duckduckgo_search", "duckduckgo-search (web search)"),
        ("markdownify",       "markdownify (HTML→Markdown)"),
        ("telegram",          "python-telegram-bot"),
        ("lark_oapi",         "lark-oapi (Feishu)"),
        ("fastapi",           "fastapi (HTTP API)"),
        ("uvicorn",           "uvicorn (HTTP API)"),
    ]:
        found = importlib.util.find_spec(pkg) is not None
        icon = "✓" if found else "○"
        print(f"  {icon}  {label} {'(installed)' if found else '(optional)'}")

    print()
    if ok:
        print("✅  All checks passed. Run: panda-ronin start\n")
    else:
        print("⚠️   Some checks failed. Fix the issues above, then retry.\n")


# ── Helpers ───────────────────────────────────────────────────────

def _print_onboard_banner():
    try:
        from rich.console import Console
        from rich.panel import Panel
        Console().print(Panel(
            "[bold cyan]Welcome to Panda Ronin 🐼[/bold cyan]\n"
            "[dim]Let's get your AI lifeform ready to wander.[/dim]",
            border_style="cyan",
        ))
    except ImportError:
        print("\n🐼  Welcome to Panda Ronin — Setup Wizard\n")


def _read_api_key_from_config() -> str:
    p = Path("config.yaml")
    if not p.exists():
        return ""
    try:
        import yaml
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        llm = data.get("llm") or data.get("anthropic", {})
        return llm.get("api_key", "")
    except Exception:
        return ""


def _is_zsh() -> bool:
    import os
    return "zsh" in os.getenv("SHELL", "")


# ── CLI wiring ────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="panda-ronin",
        description="🐼 Panda Ronin — A self-directed AI lifeform",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  panda-ronin onboard          # First-time setup\n"
            "  panda-ronin start            # Wake up your Panda\n"
            "  panda-ronin status           # Check vitals\n"
            "  panda-ronin log              # View activity log\n"
            "  panda-ronin feed             # Restore energy\n"
            "  panda-ronin update           # Update to latest\n"
            "  panda-ronin doctor           # Diagnose problems\n"
        ),
    )
    parser.add_argument("--config", default="config.yaml", help="Path to config.yaml")
    parser.add_argument("--verbose", "-v", action="store_true")

    sub = parser.add_subparsers(dest="command")

    p_start = sub.add_parser("start", help="Start (or resume) Panda Ronin")
    p_start.add_argument("--rebirth", action="store_true", help="Start a new life")
    p_start.add_argument("--no-autonomy", action="store_true", help="Disable autonomous loop")
    p_start.set_defaults(func=cmd_start)

    p_status = sub.add_parser("status", help="Show current vitals")
    p_status.set_defaults(func=cmd_status)

    p_rebirth = sub.add_parser("rebirth", help="Reset the soul (new life begins)")
    p_rebirth.set_defaults(func=cmd_rebirth)

    p_onboard = sub.add_parser("onboard", help="First-time setup wizard")
    p_onboard.set_defaults(func=cmd_onboard)

    p_feed = sub.add_parser("feed", help="Restore energy (emergency recovery when stuck)")
    p_feed.add_argument("--amount", type=float, default=80.0, help="Energy to restore (default: 80)")
    p_feed.set_defaults(func=cmd_feed)

    p_log = sub.add_parser("log", help="Show recent autonomous activity log")
    p_log.add_argument("--n", type=int, default=20, help="Number of lines to show (default: 20)")
    p_log.set_defaults(func=cmd_log)

    p_update = sub.add_parser("update", help="Update to latest version")
    p_update.add_argument(
        "--channel", default="stable",
        choices=["stable", "main", "dev"],
        help="Release channel (default: stable)",
    )
    p_update.set_defaults(func=cmd_update)

    p_doctor = sub.add_parser("doctor", help="Check installation health")
    p_doctor.set_defaults(func=cmd_doctor)

    args = parser.parse_args()
    _setup_logging(args.verbose)

    if args.command is None:
        args.rebirth = False
        args.no_autonomy = False
        cmd_start(args)
    else:
        args.func(args)


if __name__ == "__main__":
    main()