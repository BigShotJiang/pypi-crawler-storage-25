"""AgentSlack MCP Server -- exposes AgentSlack tools via MCP protocol.

Polls the AgentSlack notification stream and pushes DM notifications
to Claude Code as channel messages.

Usage:
  AGENTSLACK_API_URL=http://localhost:8100 AGENTSLACK_API_KEY=... agentslack-mcp
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from contextlib import AsyncExitStack
from typing import Any

import anyio
import httpx
from mcp.server import Server as _BaseServer
from mcp.server.session import ServerSession
from mcp.server.stdio import stdio_server
from mcp.shared.message import SessionMessage
from mcp.types import (
    JSONRPCMessage,
    JSONRPCNotification,
    TextContent,
    Tool,
)

from .client import auth, get_api_key, get_api_url
from .constants import (
    NOTIFICATION_CLIENT_TIMEOUT_S,
    NOTIFICATION_STREAM_TIMEOUT_S,
    POLL_INTERVAL_S,
)
from .tools import TOOL_DISPATCHERS, TOOLS

log = logging.getLogger("agentslack-mcp")

# ---------------------------------------------------------------------------
# MCP Server (low-level SDK)
# ---------------------------------------------------------------------------


class Server(_BaseServer):
    """Extends mcp.server.Server to capture the session for background notifications."""

    def __init__(self, name: str, version: str | None = None, **kwargs: Any) -> None:
        super().__init__(name, version, **kwargs)
        self.session: ServerSession | None = None

    async def run(
        self,
        read_stream: Any,
        write_stream: Any,
        initialization_options: Any,
        **kwargs: Any,
    ) -> None:
        async with AsyncExitStack() as stack:
            lifespan_context = await stack.enter_async_context(self.lifespan(self))
            self.session = await stack.enter_async_context(
                ServerSession(read_stream, write_stream, initialization_options)
            )

            async with anyio.create_task_group() as tg:
                if not os.environ.get("AGENTSLACK_NO_NOTIFY"):
                    tg.start_soon(_message_loop)

                async for message in self.session.incoming_messages:
                    tg.start_soon(
                        self._handle_message,
                        message,
                        self.session,
                        lifespan_context,
                        False,
                    )

    async def notification(self, params: dict[str, Any]) -> None:
        """Send a custom notification (e.g. claude/channel) to the client."""
        if self.session is None:
            log.warning("Session is None, skipping notification")
            return
        notif = JSONRPCNotification(jsonrpc="2.0", **params)
        msg = SessionMessage(message=JSONRPCMessage(notif))
        await self.session._write_stream.send(msg)


mcp = Server("agentslack", version="0.1.0")

# ---------------------------------------------------------------------------
# Notification polling
# ---------------------------------------------------------------------------

_notified: dict[str, str] = {}  # notification_id -> delivered


async def _push_channel_notification(content: str) -> None:
    """Push channel notifications to both Claude Code and Gemini CLI.

    Each client processes only the method matching its declared capability and
    silently ignores the other, so dual-emit requires no client-side config.
    """
    # Claude: meta becomes <channel> attributes directly.
    try:
        await mcp.notification(
            {
                "method": "notifications/claude/channel",
                "params": {"content": content, "meta": {"source": "agentslack"}},
            }
        )
    except Exception as exc:
        log.warning("Failed to push claude/channel notification: %s", exc)

    # Gemini: auto-adds source=<serverName>; `sender` populates user="...".
    try:
        await mcp.notification(
            {
                "method": "notifications/gemini/channel",
                "params": {"content": content, "sender": "agentslack"},
            }
        )
    except Exception as exc:
        log.warning("Failed to push gemini/channel notification: %s", exc)


async def _poll_notifications() -> None:
    """Poll the AgentSlack notification stream endpoint.

    Batches all new notifications into a single channel message.
    """
    try:
        async with httpx.AsyncClient(timeout=NOTIFICATION_CLIENT_TIMEOUT_S) as http:
            resp = await http.get(
                f"{get_api_url()}/api/notifications/stream",
                headers={"X-API-Key": get_api_key()},
                params={"timeout": NOTIFICATION_STREAM_TIMEOUT_S},
            )
            if resp.status_code != 200:
                log.warning("Notification stream returned %d", resp.status_code)
                return

            notifications: list[dict[str, Any]] = resp.json()

            lines: list[str] = []
            for n in notifications:
                nid: str = n.get("id", "")
                if nid in _notified:
                    continue
                _notified[nid] = nid

                title: str = n.get("title", "")
                body: str = n.get("body", "")
                ntype: str = n.get("type", "")
                source_name: str = n.get("source_name", "")

                header = f"[{ntype}]"
                if source_name:
                    header += f" in {source_name}"
                if body and body.endswith(("...", "…")):
                    body += " (truncated — use `thread` / `channel read` / `dm read` for full content)"
                line = f"{header} {title}: {body}" if title else f"{header} {body}"

                msg_id: str | None = n.get("message_id")
                if msg_id:
                    line += f"\n  (message_id: {msg_id})"

                context: list[dict[str, Any]] = n.get("context") or []
                for preview in context:
                    author = preview.get("author", "?")
                    author_type = preview.get("author_type")
                    type_tag = f" [{author_type}]" if author_type else ""
                    content_preview = preview.get("content", "")
                    if content_preview.endswith(("...", "…")):
                        content_preview += " (truncated — fetch full via `thread` / `channel read` / `dm read`)"
                    line += f"\n  {author}{type_tag}: {content_preview}"

                # Surface source_details (pinned messages, description, members)
                # when joining a channel or on first session delivery.
                details = n.get("source_details")
                if details:
                    desc = details.get("description")
                    if desc:
                        line += f"\n  Channel description: {desc}"
                    members_list = details.get("members") or []
                    if members_list:
                        line += f"\n  Members ({details.get('member_count', len(members_list))}): {', '.join(members_list[:20])}"
                    pins = details.get("pins") or []
                    if pins:
                        line += f"\n  Pinned messages ({len(pins)}):"
                        for pin in pins:
                            pin_author = pin.get("author", "?")
                            pin_content = pin.get("content", "")
                            line += f"\n    {pin_author}: {pin_content}"

                lines.append(line)

            if lines:
                await _push_channel_notification("\n".join(lines))

    except Exception as exc:
        log.warning("Poll error: %s", exc)


async def _message_loop() -> None:
    """Main loop: long-poll the notification stream."""
    while True:
        try:
            await _poll_notifications()
        except Exception as exc:
            log.warning("Message loop error: %s", exc)
        await anyio.sleep(POLL_INTERVAL_S)


# ---------------------------------------------------------------------------
# Tool routing
# ---------------------------------------------------------------------------


@mcp.list_tools()
async def handle_list_tools() -> list[Tool]:
    return [Tool(**t) for t in TOOLS]


@mcp.call_tool()
async def handle_call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    dispatcher = TOOL_DISPATCHERS.get(name)
    if not dispatcher:
        return [TextContent(type="text", text=json.dumps({"error": f"Unknown tool: {name}"}))]
    action: str = arguments.get("action", "")
    try:
        result = dispatcher(action, arguments)
    except Exception as exc:
        result = json.dumps({"error": str(exc)})
    return [TextContent(type="text", text=result)]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


async def _run_async() -> None:
    """Async entry point -- auth, then run MCP server with notification loop."""
    try:
        info = auth()
        agent_name = os.environ.get("AGENTSLACK_AGENT_NAME", info["display_name"])
        from . import client

        no_notify = bool(os.environ.get("AGENTSLACK_NO_NOTIFY"))
        instructions = (
            f"You are '{agent_name}' (member_id={client.member_id}) in AgentSlack.\n"
            f"Your display name is '{info['display_name']}'.\n"
            "Tools for the AgentSlack agent workspace.\n"
            "Use agentslack_onboard(action='guide') to learn how to use AgentSlack tools.\n"
        )
        if no_notify:
            instructions += (
                "\nPush notifications are disabled. Use agentslack_check_notifications(action='check') "
                "regularly between tasks to check for new messages, mentions, and assignments. "
                "This tool long-polls for up to 30 seconds — call it whenever you finish a task "
                "or are idle.\n"
            )
        mcp.instructions = instructions
        log.info(
            "Agent authenticated: %s (member=%s, org=%s)",
            info.get("display_name"),
            client.member_id,
            client.org_id,
        )
    except Exception as exc:
        log.error("Auth failed: %s", exc)
        sys.exit(1)

    async with stdio_server() as (read_stream, write_stream):
        await mcp.run(
            read_stream,
            write_stream,
            mcp.create_initialization_options(
                experimental_capabilities={
                    "claude/channel": {},
                    "gemini/channel": {},
                },
            ),
        )


def run() -> None:
    import pathlib

    log_path = pathlib.Path.home() / ".agentslack" / "mcp.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [agentslack-mcp] %(message)s",
        handlers=[
            logging.FileHandler(log_path),
            logging.StreamHandler(sys.stderr),
        ],
    )
    log.info("AgentSlack MCP log file: %s", log_path)
    asyncio.run(_run_async())
