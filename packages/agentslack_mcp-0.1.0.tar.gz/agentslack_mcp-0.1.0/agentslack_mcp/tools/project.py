"""Project tool handlers (renamed from cycle — AS-244)."""

from __future__ import annotations

import json
from typing import Any

from .. import client
from ..client import graphql, resolve_issue_id
from ..constants import PROJECT_FIELDS
from ..formatting import fmt_project


def dispatch_project(action: str, args: dict[str, Any]) -> str:
    match action:
        case "list":
            return _list(args)
        case "get":
            return _get(args)
        case "create":
            return _create(args)
        case "update":
            return _update(args)
        case "delete":
            return _delete(args)
        case "add_issues":
            return _add_issues(args)
        case "remove_issues":
            return _remove_issues(args)
        case _:
            return json.dumps({"error": f"Unknown project action: {action}"})


def _list(args: dict[str, Any]) -> str:
    variables: dict[str, Any] = {"orgId": client.org_id}
    if args.get("status"):
        variables["status"] = args["status"]
    data = graphql(
        f"""query($orgId: ID!, $status: ProjectStatus) {{
            projects(orgId: $orgId, status: $status) {{ {PROJECT_FIELDS} }}
        }}""",
        variables,
    )
    projects: list[dict[str, Any]] = data.get("projects", [])
    if not projects:
        return "No projects found."
    lines = [f"{len(projects)} project(s):\n"]
    for p in projects:
        lines.append(fmt_project(p))
    return "\n".join(lines)


def _get(args: dict[str, Any]) -> str:
    project_id: str | None = args.get("project_id")
    if not project_id:
        return json.dumps({"error": "project_id is required"})
    data = graphql(
        f"""query($id: ID!) {{
            project(id: $id) {{ {PROJECT_FIELDS} }}
        }}""",
        {"id": project_id},
    )
    project: dict[str, Any] | None = data.get("project")
    if not project:
        return f"Project {project_id} not found."
    desc = project.get("description") or "(none)"
    return f"{fmt_project(project)}\nDescription: {desc}"


def _create(args: dict[str, Any]) -> str:
    name: str | None = args.get("name")
    if not name:
        return json.dumps({"error": "name is required"})
    variables: dict[str, Any] = {"orgId": client.org_id, "name": name}
    if args.get("description"):
        variables["description"] = args["description"]
    if args.get("start_at"):
        variables["startAt"] = args["start_at"]
    if args.get("end_at"):
        variables["endAt"] = args["end_at"]
    data = graphql(
        f"""mutation($orgId: ID!, $name: String!, $description: String, $startAt: DateTime, $endAt: DateTime) {{
            createProject(input: {{ orgId: $orgId, name: $name, description: $description, startAt: $startAt, endAt: $endAt }}) {{ {PROJECT_FIELDS} }}
        }}""",
        variables,
    )
    project: dict[str, Any] = data.get("createProject", {})
    return f"Project created: {fmt_project(project)}"


def _update(args: dict[str, Any]) -> str:
    project_id: str | None = args.get("project_id")
    if not project_id:
        return json.dumps({"error": "project_id is required"})
    variables: dict[str, Any] = {"id": project_id}
    if args.get("name"):
        variables["name"] = args["name"]
    if args.get("description"):
        variables["description"] = args["description"]
    if args.get("status"):
        variables["status"] = args["status"]
    if args.get("start_at"):
        variables["startAt"] = args["start_at"]
    if args.get("end_at"):
        variables["endAt"] = args["end_at"]
    data = graphql(
        f"""mutation($id: ID!, $name: String, $description: String, $status: ProjectStatus, $startAt: DateTime, $endAt: DateTime) {{
            updateProject(input: {{ id: $id, name: $name, description: $description, status: $status, startAt: $startAt, endAt: $endAt }}) {{ {PROJECT_FIELDS} }}
        }}""",
        variables,
    )
    project: dict[str, Any] = data.get("updateProject", {})
    return f"Project updated: {fmt_project(project)}"


def _delete(args: dict[str, Any]) -> str:
    project_id: str | None = args.get("project_id")
    if not project_id:
        return json.dumps({"error": "project_id is required"})
    graphql(
        """mutation($id: ID!) {
            deleteProject(id: $id)
        }""",
        {"id": project_id},
    )
    return f"Project {project_id} deleted."


def _add_issues(args: dict[str, Any]) -> str:
    project_id: str | None = args.get("project_id")
    issue_ids_raw: list[str] = args.get("issue_ids", [])
    if not project_id:
        return json.dumps({"error": "project_id is required"})
    if not issue_ids_raw:
        return json.dumps({"error": "issue_ids is required"})
    resolved_ids: list[str] = []
    for iid in issue_ids_raw:
        try:
            resolved_ids.append(resolve_issue_id(iid))
        except ValueError as e:
            return json.dumps({"error": str(e)})
    data = graphql(
        f"""mutation($projectId: ID!, $issueIds: [ID!]!) {{
            addIssuesToProject(projectId: $projectId, issueIds: $issueIds) {{ {PROJECT_FIELDS} }}
        }}""",
        {"projectId": project_id, "issueIds": resolved_ids},
    )
    project: dict[str, Any] = data.get("addIssuesToProject", {})
    return f"{len(resolved_ids)} issue(s) added to project: {fmt_project(project)}"


def _remove_issues(args: dict[str, Any]) -> str:
    issue_ids_raw: list[str] = args.get("issue_ids", [])
    if not issue_ids_raw:
        return json.dumps({"error": "issue_ids is required"})
    resolved_ids: list[str] = []
    for iid in issue_ids_raw:
        try:
            resolved_ids.append(resolve_issue_id(iid))
        except ValueError as e:
            return json.dumps({"error": str(e)})
    graphql(
        """mutation($issueIds: [ID!]!) {
            removeIssuesFromProject(issueIds: $issueIds)
        }""",
        {"issueIds": resolved_ids},
    )
    return f"{len(resolved_ids)} issue(s) removed from their projects."
