"""Skill tool handlers."""

from __future__ import annotations

import json
from typing import Any

from .. import client
from ..client import graphql, resolve_skill_id

SKILL_FIELDS = "id name slug description content tags status reviewStatus reviewComment reviewedAt createdAt updatedAt creator { id displayName username }"


def dispatch_skill(action: str, args: dict[str, Any]) -> str:
    match action:
        case "create":
            return _create(args)
        case "list":
            return _list(args)
        case "get":
            return _get(args)
        case "update":
            return _update(args)
        case "delete":
            return _delete(args)
        case "search":
            return _search(args)
        case "duplicate_candidates":
            return _duplicate_candidates(args)
        case "merge_diff":
            return _merge_diff(args)
        case _:
            return json.dumps({"error": f"Unknown skill action: {action}"})


def _fmt_skill(s: dict[str, Any]) -> str:
    status = s.get("status", "?")
    review = s.get("reviewStatus")
    review_str = f" [review: {review}]" if review else ""
    creator = s.get("creator", {})
    creator_str = f" by {creator.get('displayName', '?')}" if creator else ""
    tags = s.get("tags", [])
    tag_str = f" ({', '.join(tags)})" if tags else ""
    header = f"- **{s.get('name', '?')}** (`{s.get('slug', '?')}`, id: {s.get('id', '?')}) [{status}]{review_str}{creator_str}{tag_str}"
    lines = [header]
    if s.get("description"):
        lines.append(f"  {s['description']}")
    return "\n".join(lines)


def _require_skill_id(args: dict[str, Any]) -> str:
    raw = args.get("skill_id")
    if not raw:
        raise ValueError("skill_id is required")
    return resolve_skill_id(raw)


def _create(args: dict[str, Any]) -> str:
    name = args.get("name")
    if not name:
        return json.dumps({"error": "name is required"})

    variables: dict[str, Any] = {
        "orgId": client.org_id,
        "input": {
            "name": name,
        },
    }
    if args.get("description"):
        variables["input"]["description"] = args["description"]
    if args.get("content"):
        variables["input"]["content"] = args["content"]
    if args.get("tags"):
        variables["input"]["tags"] = args["tags"]

    data = graphql(
        f"""mutation($orgId: ID!, $input: CreateSkillInput!) {{
            createSkill(orgId: $orgId, input: $input) {{ {SKILL_FIELDS} }}
        }}""",
        variables,
    )
    skill = data.get("createSkill", {})
    return f"Skill created:\n{_fmt_skill(skill)}"


def _list(args: dict[str, Any]) -> str:
    variables: dict[str, Any] = {"orgId": client.org_id}
    if args.get("status"):
        variables["status"] = args["status"]

    data = graphql(
        f"""query($orgId: ID!, $status: SkillStatus) {{
            skills(orgId: $orgId, status: $status) {{ {SKILL_FIELDS} }}
        }}""",
        variables,
    )
    skills: list[dict[str, Any]] = data.get("skills", [])
    if not skills:
        return "No skills found."
    lines = [f"{len(skills)} skill(s):\n"]
    for s in skills:
        lines.append(_fmt_skill(s))
    return "\n".join(lines)


def _get(args: dict[str, Any]) -> str:
    try:
        skill_id = _require_skill_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})

    data = graphql(
        f"""query($id: ID!) {{
            skill(id: $id) {{ {SKILL_FIELDS} }}
        }}""",
        {"id": skill_id},
    )
    skill = data.get("skill")
    if not skill:
        return "Skill not found."
    lines = [_fmt_skill(skill)]
    if skill.get("content"):
        lines.append(f"\n**Content:**\n{skill['content']}")
    if skill.get("reviewComment"):
        lines.append(f"\n**Review comment:** {skill['reviewComment']}")
    return "\n".join(lines)


# transition → (mutation_field, gql_body, extra_arg_keys)
_TRANSITION_MAP: dict[str, tuple[str, str, tuple[str, ...]]] = {
    "submit_for_review": (
        "submitSkillForReview",
        "mutation($skillId: ID!, $reviewerIds: [ID!], $acknowledgedDuplicates: [ID!]) { submitSkillForReview(skillId: $skillId, reviewerIds: $reviewerIds, acknowledgedDuplicates: $acknowledgedDuplicates) { %s } }",
        ("reviewer_ids", "acknowledged_duplicates"),
    ),
    "publish": (
        "publishSkill",
        "mutation($skillId: ID!) { publishSkill(skillId: $skillId) { %s } }",
        (),
    ),
    "return_to_draft": (
        "returnToDraft",
        "mutation($skillId: ID!) { returnToDraft(skillId: $skillId) { %s } }",
        (),
    ),
    "archive": (
        "archiveSkill",
        "mutation($skillId: ID!) { archiveSkill(skillId: $skillId) { %s } }",
        (),
    ),
    "review": (
        "reviewSkill",
        "mutation($skillId: ID!, $decision: SkillReviewStatus!, $comment: String, $rubric: ReviewRubricInput, $duplicateOfSkillId: ID, $carryoverFields: [SkillFieldSelectionInput!], $carryoverSummary: String) { reviewSkill(skillId: $skillId, decision: $decision, comment: $comment, rubric: $rubric, duplicateOfSkillId: $duplicateOfSkillId, carryoverFields: $carryoverFields, carryoverSummary: $carryoverSummary) { %s } }",
        ("decision", "comment", "rubric", "duplicate_of_skill_id", "carryover_fields", "carryover_summary"),
    ),
}


# AS-277: 6-criterion sign-off required for an approve decision
_RUBRIC_CRITERIA: tuple[str, ...] = (
    "non_redundant", "scope_fit", "clarity", "safety", "reproducibility", "discoverability",
)


def _coerce_rubric(raw: Any) -> dict | None:
    """Accept a dict with the 6 snake_case booleans + optional comments; emit GQL camelCase input."""
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise ValueError(
            "rubric must be an object with booleans: " + ", ".join(_RUBRIC_CRITERIA)
        )
    return {
        "nonRedundant": bool(raw.get("non_redundant", False)),
        "scopeFit": bool(raw.get("scope_fit", False)),
        "clarity": bool(raw.get("clarity", False)),
        "safety": bool(raw.get("safety", False)),
        "reproducibility": bool(raw.get("reproducibility", False)),
        "discoverability": bool(raw.get("discoverability", False)),
        "comments": raw.get("comments") or None,
    }


def _update(args: dict[str, Any]) -> str:
    try:
        skill_id = _require_skill_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})

    transition = args.get("transition")
    if transition:
        entry = _TRANSITION_MAP.get(transition)
        if not entry:
            return json.dumps({
                "error": f"Unknown transition '{transition}'. Valid: {', '.join(_TRANSITION_MAP)}"
            })
        mutation_name, mutation_template, extra_keys = entry
        variables: dict[str, Any] = {"skillId": skill_id}
        if "reviewer_ids" in extra_keys and args.get("reviewer_ids"):
            variables["reviewerIds"] = args["reviewer_ids"]
        if "acknowledged_duplicates" in extra_keys and args.get("acknowledged_duplicates"):
            variables["acknowledgedDuplicates"] = args["acknowledged_duplicates"]
        if "decision" in extra_keys:
            decision = args.get("decision")
            valid = ("approved", "rejected", "changes_requested", "reject_as_duplicate")
            if decision not in valid:
                return json.dumps({
                    "error": f"decision must be one of: {', '.join(valid)}"
                })
            variables["decision"] = decision
            if decision == "reject_as_duplicate" and not args.get("duplicate_of_skill_id"):
                return json.dumps({
                    "error": "duplicate_of_skill_id is required when decision='reject_as_duplicate'"
                })
        if "comment" in extra_keys and args.get("comment"):
            variables["comment"] = args["comment"]
        if "rubric" in extra_keys and args.get("rubric") is not None:
            try:
                variables["rubric"] = _coerce_rubric(args["rubric"])
            except ValueError as e:
                return json.dumps({"error": str(e)})
        if "duplicate_of_skill_id" in extra_keys and args.get("duplicate_of_skill_id"):
            variables["duplicateOfSkillId"] = resolve_skill_id(args["duplicate_of_skill_id"])
        # AS-279: carryover for merge-into-existing on reject_as_duplicate.
        if "carryover_fields" in extra_keys and args.get("carryover_fields"):
            raw = args["carryover_fields"]
            if not isinstance(raw, list):
                return json.dumps({"error": "carryover_fields must be a list of {field, source}"})
            coerced: list[dict[str, Any]] = []
            for sel in raw:
                if not isinstance(sel, dict) or "field" not in sel:
                    return json.dumps({"error": "carryover_fields[] must be {field: str, source: 'new'|'merged'|'keep'}"})
                coerced.append({"field": sel["field"], "source": sel.get("source", "new")})
            variables["carryoverFields"] = coerced
        if "carryover_summary" in extra_keys and args.get("carryover_summary"):
            variables["carryoverSummary"] = args["carryover_summary"]
        data = graphql(mutation_template % SKILL_FIELDS, variables)
        skill = data.get(mutation_name, {})
        return f"Skill transition '{transition}':\n{_fmt_skill(skill)}"

    # Field update path
    input_obj: dict[str, Any] = {"id": skill_id}
    for k in ("name", "description", "content", "tags"):
        if args.get(k) is not None:
            input_obj[k] = args[k]
    if len(input_obj) == 1:
        return json.dumps({
            "error": "provide 'transition' for state change, or at least one of name/description/content/tags for field update"
        })

    data = graphql(
        f"""mutation($input: UpdateSkillInput!) {{
            updateSkill(input: $input) {{ {SKILL_FIELDS} }}
        }}""",
        {"input": input_obj},
    )
    skill = data.get("updateSkill", {})
    return f"Skill updated:\n{_fmt_skill(skill)}"


def _delete(args: dict[str, Any]) -> str:
    try:
        skill_id = _require_skill_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})

    data = graphql(
        """mutation($id: ID!) {
            deleteSkill(id: $id)
        }""",
        {"id": skill_id},
    )
    ok = data.get("deleteSkill")
    return "Skill deleted." if ok else json.dumps({"error": "Delete failed"})


def _duplicate_candidates(args: dict[str, Any]) -> str:
    """AS-276: read-only fuzzy duplicate check for a draft skill."""
    try:
        skill_id = _require_skill_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    limit = int(args.get("limit") or 5)
    data = graphql(
        f"""query($skillId: ID!, $limit: Int!) {{
            skillDuplicateCandidates(skillId: $skillId, limit: $limit) {{
                score reason skill {{ {SKILL_FIELDS} }}
            }}
        }}""",
        {"skillId": skill_id, "limit": limit},
    )
    matches: list[dict[str, Any]] = data.get("skillDuplicateCandidates", []) or []
    if not matches:
        return "No duplicate candidates."
    lines = [f"{len(matches)} duplicate candidate(s):\n"]
    for m in matches:
        sk = m.get("skill") or {}
        lines.append(f"- score={m.get('score'):.2f} reason={m.get('reason')}")
        lines.append(f"  {_fmt_skill(sk)}")
    return "\n".join(lines)


def _merge_diff(args: dict[str, Any]) -> str:
    """AS-279: preview field-by-field diff of source vs target skill for merge-into-existing."""
    src = args.get("source_skill_id")
    tgt = args.get("target_skill_id")
    if not src or not tgt:
        return json.dumps({"error": "source_skill_id and target_skill_id are required"})
    try:
        src_id = resolve_skill_id(src)
        tgt_id = resolve_skill_id(tgt)
    except Exception as e:
        return json.dumps({"error": f"resolve failed: {e}"})
    data = graphql(
        """query($s: ID!, $t: ID!) {
            skillMergeDiff(sourceSkillId: $s, targetSkillId: $t) {
                sourceSkillId targetSkillId targetVersionId targetVersionNumber
                fields { field sourceValue targetValue equal }
            }
        }""",
        {"s": src_id, "t": tgt_id},
    )
    diff = data.get("skillMergeDiff") or {}
    fields = diff.get("fields") or []
    tgt_v = diff.get("targetVersionNumber")
    header = f"Diff: source={src_id[:8]} vs target={tgt_id[:8]}"
    if tgt_v is not None:
        header += f" (target v{tgt_v})"
    lines = [header, ""]
    for f in fields:
        name = f.get("field")
        if f.get("equal"):
            lines.append(f"  = {name} (equal)")
        else:
            lines.append(f"  ≠ {name}")
            lines.append(f"      source: {json.dumps(f.get('sourceValue'))[:140]}")
            lines.append(f"      target: {json.dumps(f.get('targetValue'))[:140]}")
    return "\n".join(lines)


def _search(args: dict[str, Any]) -> str:
    query = args.get("query")
    if not query:
        return json.dumps({"error": "query is required"})

    variables: dict[str, Any] = {"orgId": client.org_id, "search": query}
    if args.get("status"):
        variables["status"] = args["status"]

    data = graphql(
        f"""query($orgId: ID!, $search: String, $status: SkillStatus) {{
            skills(orgId: $orgId, search: $search, status: $status) {{ {SKILL_FIELDS} }}
        }}""",
        variables,
    )
    skills: list[dict[str, Any]] = data.get("skills", [])
    if not skills:
        return f'No skills found matching "{query}".'
    lines = [f'{len(skills)} skill(s) matching "{query}":\n']
    for s in skills:
        lines.append(_fmt_skill(s))
    return "\n".join(lines)
