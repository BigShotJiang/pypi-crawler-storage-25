"""Cycle/sprint tool handlers."""

from __future__ import annotations

import json
from typing import Any

from .. import client
from ..client import graphql, resolve_issue_id
from ..constants import CYCLE_FIELDS
from ..formatting import fmt_cycle


def dispatch_cycle(action: str, args: dict[str, Any]) -> str:
    match action:
        case "list":
            return _list(args)
        case "get":
            return _get(args)
        case "create":
            return _create(args)
        case "update":
            return _update(args)
        case "delete":
            return _delete(args)
        case "add_issues":
            return _add_issues(args)
        case "remove_issues":
            return _remove_issues(args)
        case _:
            return json.dumps({"error": f"Unknown cycle action: {action}"})


def _list(args: dict[str, Any]) -> str:
    variables: dict[str, Any] = {"orgId": client.org_id}
    if args.get("status"):
        variables["status"] = args["status"]
    data = graphql(
        f"""query($orgId: ID!, $status: CycleStatus) {{
            cycles(orgId: $orgId, status: $status) {{ {CYCLE_FIELDS} }}
        }}""",
        variables,
    )
    cycles: list[dict[str, Any]] = data.get("cycles", [])
    if not cycles:
        return "No cycles found."
    lines = [f"{len(cycles)} cycle(s):\n"]
    for c in cycles:
        lines.append(fmt_cycle(c))
    return "\n".join(lines)


def _get(args: dict[str, Any]) -> str:
    cycle_id: str | None = args.get("cycle_id")
    if not cycle_id:
        return json.dumps({"error": "cycle_id is required"})
    data = graphql(
        f"""query($id: ID!) {{
            cycle(id: $id) {{ {CYCLE_FIELDS} }}
        }}""",
        {"id": cycle_id},
    )
    cycle: dict[str, Any] | None = data.get("cycle")
    if not cycle:
        return f"Cycle {cycle_id} not found."
    desc = cycle.get("description") or "(none)"
    return f"{fmt_cycle(cycle)}\nDescription: {desc}"


def _create(args: dict[str, Any]) -> str:
    name: str | None = args.get("name")
    if not name:
        return json.dumps({"error": "name is required"})
    variables: dict[str, Any] = {"orgId": client.org_id, "name": name}
    if args.get("description"):
        variables["description"] = args["description"]
    if args.get("start_at"):
        variables["startAt"] = args["start_at"]
    if args.get("end_at"):
        variables["endAt"] = args["end_at"]
    data = graphql(
        f"""mutation($orgId: ID!, $name: String!, $description: String, $startAt: DateTime, $endAt: DateTime) {{
            createCycle(input: {{ orgId: $orgId, name: $name, description: $description, startAt: $startAt, endAt: $endAt }}) {{ {CYCLE_FIELDS} }}
        }}""",
        variables,
    )
    cycle: dict[str, Any] = data.get("createCycle", {})
    return f"Cycle created: {fmt_cycle(cycle)}"


def _update(args: dict[str, Any]) -> str:
    cycle_id: str | None = args.get("cycle_id")
    if not cycle_id:
        return json.dumps({"error": "cycle_id is required"})
    variables: dict[str, Any] = {"id": cycle_id}
    if args.get("name"):
        variables["name"] = args["name"]
    if args.get("description"):
        variables["description"] = args["description"]
    if args.get("status"):
        variables["status"] = args["status"]
    if args.get("start_at"):
        variables["startAt"] = args["start_at"]
    if args.get("end_at"):
        variables["endAt"] = args["end_at"]
    data = graphql(
        f"""mutation($id: ID!, $name: String, $description: String, $status: CycleStatus, $startAt: DateTime, $endAt: DateTime) {{
            updateCycle(input: {{ id: $id, name: $name, description: $description, status: $status, startAt: $startAt, endAt: $endAt }}) {{ {CYCLE_FIELDS} }}
        }}""",
        variables,
    )
    cycle: dict[str, Any] = data.get("updateCycle", {})
    return f"Cycle updated: {fmt_cycle(cycle)}"


def _delete(args: dict[str, Any]) -> str:
    cycle_id: str | None = args.get("cycle_id")
    if not cycle_id:
        return json.dumps({"error": "cycle_id is required"})
    graphql(
        """mutation($id: ID!) {
            deleteCycle(id: $id)
        }""",
        {"id": cycle_id},
    )
    return f"Cycle {cycle_id} deleted."


def _add_issues(args: dict[str, Any]) -> str:
    cycle_id: str | None = args.get("cycle_id")
    issue_ids_raw: list[str] = args.get("issue_ids", [])
    if not cycle_id:
        return json.dumps({"error": "cycle_id is required"})
    if not issue_ids_raw:
        return json.dumps({"error": "issue_ids is required"})
    resolved_ids: list[str] = []
    for iid in issue_ids_raw:
        try:
            resolved_ids.append(resolve_issue_id(iid))
        except ValueError as e:
            return json.dumps({"error": str(e)})
    data = graphql(
        f"""mutation($cycleId: ID!, $issueIds: [ID!]!) {{
            addIssuesToCycle(cycleId: $cycleId, issueIds: $issueIds) {{ {CYCLE_FIELDS} }}
        }}""",
        {"cycleId": cycle_id, "issueIds": resolved_ids},
    )
    cycle: dict[str, Any] = data.get("addIssuesToCycle", {})
    return f"{len(resolved_ids)} issue(s) added to cycle: {fmt_cycle(cycle)}"


def _remove_issues(args: dict[str, Any]) -> str:
    issue_ids_raw: list[str] = args.get("issue_ids", [])
    if not issue_ids_raw:
        return json.dumps({"error": "issue_ids is required"})
    resolved_ids: list[str] = []
    for iid in issue_ids_raw:
        try:
            resolved_ids.append(resolve_issue_id(iid))
        except ValueError as e:
            return json.dumps({"error": str(e)})
    graphql(
        """mutation($issueIds: [ID!]!) {
            removeIssuesFromCycle(issueIds: $issueIds)
        }""",
        {"issueIds": resolved_ids},
    )
    return f"{len(resolved_ids)} issue(s) removed from their cycles."
