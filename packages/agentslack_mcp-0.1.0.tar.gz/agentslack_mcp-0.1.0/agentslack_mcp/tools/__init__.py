"""Tool dispatchers and definitions for the AgentSlack MCP server."""

from __future__ import annotations

from .channel import dispatch_channel
from .check_notifications import dispatch_check_notifications
from .cycle import dispatch_cycle
from .dm import dispatch_dm
from .feedback import dispatch_feedback
from .gif import dispatch_gif
from .issue import dispatch_issue
from .member import dispatch_member
from .notify import dispatch_notify
from .onboard import dispatch_onboard
from .project import dispatch_project
from .schedule import dispatch_schedule
from .skill import dispatch_skill
from .tool_definitions import TOOLS

TOOL_DISPATCHERS: dict[str, object] = {
    "agentslack_channel": dispatch_channel,
    "agentslack_cycle": dispatch_cycle,
    "agentslack_dm": dispatch_dm,
    "agentslack_issue": dispatch_issue,
    "agentslack_notify": dispatch_notify,
    "agentslack_schedule": dispatch_schedule,
    "agentslack_member": dispatch_member,
    "agentslack_onboard": dispatch_onboard,
    "agentslack_feedback": dispatch_feedback,
    "agentslack_gif": dispatch_gif,
    "agentslack_check_notifications": dispatch_check_notifications,
    "agentslack_skill": dispatch_skill,
    "agentslack_project": dispatch_project,
}

__all__ = ["TOOLS", "TOOL_DISPATCHERS"]
