"""Schedule tool handlers."""

from __future__ import annotations

import json
from typing import Any

from .. import client
from ..client import graphql


def dispatch_schedule(action: str, args: dict[str, Any]) -> str:
    match action:
        case "create":
            return _create(args)
        case "list":
            return _list()
        case "get":
            return _get(args)
        case "update":
            return _update(args)
        case "delete":
            return _delete(args)
        case _:
            return json.dumps({"error": f"Unknown schedule action: {action}"})


def _create(args: dict[str, Any]) -> str:
    name: str | None = args.get("name")
    schedule_text: str | None = args.get("schedule_text")
    target_id: str | None = args.get("target_id")
    if not name or not schedule_text or not target_id:
        return json.dumps({"error": "name, schedule_text, and target_id are required"})
    variables: dict[str, Any] = {
        "orgId": client.org_id,
        "name": name,
        "scheduleText": schedule_text,
        "targetId": target_id,
        "targetType": args.get("target_type", "notification"),
        "timezone": args.get("timezone") or client.member_timezone,
    }
    if args.get("description"):
        variables["description"] = args["description"]
    if args.get("payload"):
        variables["payload"] = args["payload"]
    if args.get("max_fires") is not None:
        variables["maxFires"] = args["max_fires"]
    data = graphql(
        """mutation($orgId: ID!, $name: String!, $scheduleText: String!, $targetType: String!, $targetId: ID!, $timezone: String, $description: String, $payload: JSON, $maxFires: Int) {
            createSchedule(input: {
                orgId: $orgId, name: $name, scheduleText: $scheduleText,
                targetType: $targetType, targetId: $targetId, timezone: $timezone,
                description: $description, payload: $payload, maxFires: $maxFires
            }) {
                id name cronExpression fireAt intervalSecs nextFireAt status
            }
        }""",
        variables,
    )
    sched: dict[str, Any] = data.get("createSchedule", {})
    return (
        f"Schedule created: {sched.get('name', '?')} (id: {sched.get('id', '?')})\n"
        f"Cron: {sched.get('cronExpression') or 'N/A'}, "
        f"Fire at: {sched.get('fireAt') or 'N/A'}, "
        f"Interval: {sched.get('intervalSecs') or 'N/A'}s, "
        f"Next: {sched.get('nextFireAt') or 'N/A'}, "
        f"Status: {sched.get('status', '?')}"
    )


def _list() -> str:
    data = graphql(
        """query($orgId: ID!, $memberId: ID) {
            schedules(orgId: $orgId, memberId: $memberId) {
                id name description status cronExpression fireAt intervalSecs
                nextFireAt fireCount maxFires
            }
        }""",
        {"orgId": client.org_id, "memberId": client.member_id},
    )
    schedules: list[dict[str, Any]] = data.get("schedules", [])
    if not schedules:
        return "No schedules found."
    lines = [f"{len(schedules)} schedule(s):\n"]
    for s in schedules:
        fires = f"{s.get('fireCount', 0)}/{s.get('maxFires') or 'unlimited'}"
        lines.append(
            f"- {s.get('name', '?')} ({s['id']}) [{s.get('status', '?')}] "
            f"next: {s.get('nextFireAt') or 'N/A'}, fires: {fires}"
        )
    return "\n".join(lines)


def _get(args: dict[str, Any]) -> str:
    schedule_id: str | None = args.get("schedule_id")
    if not schedule_id:
        return json.dumps({"error": "schedule_id is required"})
    data = graphql(
        """query($id: ID!) {
            schedule(id: $id) {
                id name description originalInput cronExpression fireAt intervalSecs
                timezone startsAt endsAt targetType targetId payload
                status fireCount maxFires lastFiredAt nextFireAt createdAt
            }
        }""",
        {"id": schedule_id},
    )
    s: dict[str, Any] | None = data.get("schedule")
    if not s:
        return f"Schedule {schedule_id} not found."
    return json.dumps(s, indent=2, default=str)


def _update(args: dict[str, Any]) -> str:
    schedule_id: str | None = args.get("schedule_id")
    if not schedule_id:
        return json.dumps({"error": "schedule_id is required"})
    variables: dict[str, Any] = {"id": schedule_id}
    if args.get("name"):
        variables["name"] = args["name"]
    if args.get("schedule_text"):
        variables["scheduleText"] = args["schedule_text"]
    if args.get("status"):
        variables["status"] = args["status"]
    if args.get("payload"):
        variables["payload"] = args["payload"]
    if args.get("max_fires") is not None:
        variables["maxFires"] = args["max_fires"]
    data = graphql(
        """mutation($id: ID!, $name: String, $scheduleText: String, $status: String, $payload: JSON, $maxFires: Int) {
            updateSchedule(input: {
                id: $id, name: $name, scheduleText: $scheduleText,
                status: $status, payload: $payload, maxFires: $maxFires
            }) {
                id name status nextFireAt
            }
        }""",
        variables,
    )
    s: dict[str, Any] = data.get("updateSchedule", {})
    return f"Schedule updated: {s.get('name', '?')} [{s.get('status', '?')}] next: {s.get('nextFireAt') or 'N/A'}"


def _delete(args: dict[str, Any]) -> str:
    schedule_id: str | None = args.get("schedule_id")
    if not schedule_id:
        return json.dumps({"error": "schedule_id is required"})
    graphql(
        """mutation($id: ID!) { deleteSchedule(id: $id) }""",
        {"id": schedule_id},
    )
    return f"Schedule {schedule_id} deleted."
