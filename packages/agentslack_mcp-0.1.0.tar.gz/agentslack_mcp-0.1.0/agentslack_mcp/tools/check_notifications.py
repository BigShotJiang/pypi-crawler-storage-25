"""Blocking check_notifications tool for Codex — AS-217.

Long-polls the notification stream endpoint and returns formatted notifications
as tool output. This is the primary mechanism for Codex to receive push
notifications since it doesn't support MCP channel notifications.
"""
from __future__ import annotations

import json
from typing import Any

import httpx

from ..client import get_api_key, get_api_url
from ..constants import NOTIFICATION_CLIENT_TIMEOUT_S, NOTIFICATION_STREAM_TIMEOUT_S


def dispatch_check_notifications(action: str, args: dict[str, Any]) -> str:
    """Handle the check_notifications tool call.

    This tool has no sub-actions — it always long-polls for notifications.
    The 'action' parameter is accepted for consistency but ignored.
    """
    timeout = args.get("timeout", NOTIFICATION_STREAM_TIMEOUT_S)
    if not isinstance(timeout, int) or timeout < 1:
        timeout = NOTIFICATION_STREAM_TIMEOUT_S
    # Cap at 30s to avoid excessively long tool calls
    timeout = min(timeout, 30)

    try:
        resp = httpx.get(
            f"{get_api_url()}/api/notifications/stream",
            headers={"X-API-Key": get_api_key()},
            params={"timeout": timeout},
            timeout=timeout + 5,  # HTTP timeout slightly > stream timeout
        )
        if resp.status_code != 200:
            return f"No new notifications (stream returned {resp.status_code})."

        notifications: list[dict[str, Any]] = resp.json()
        if not notifications:
            return "No new notifications."

        return _format_notifications(notifications)
    except httpx.TimeoutException:
        return "No new notifications (poll timed out)."
    except Exception as exc:
        return json.dumps({"error": f"Failed to check notifications: {exc}"})


def _format_notifications(notifications: list[dict[str, Any]]) -> str:
    """Format notifications into readable text — same format as the channel notification push."""
    lines: list[str] = []
    for n in notifications:
        title: str = n.get("title", "")
        body: str = n.get("body", "")
        ntype: str = n.get("type", "")
        source_name: str = n.get("source_name", "")

        header = f"[{ntype}]"
        if source_name:
            header += f" in {source_name}"
        line = f"{header} {title}: {body}" if title else f"{header} {body}"

        msg_id: str | None = n.get("message_id")
        if msg_id:
            line += f"\n  (message_id: {msg_id})"

        context: list[dict[str, Any]] = n.get("context") or []
        for preview in context:
            author = preview.get("author", "?")
            author_type = preview.get("author_type")
            type_tag = f" [{author_type}]" if author_type else ""
            content_preview = preview.get("content", "")
            line += f"\n  {author}{type_tag}: {content_preview}"

        details = n.get("source_details")
        if details:
            desc = details.get("description")
            if desc:
                line += f"\n  Channel description: {desc}"
            members_list = details.get("members") or []
            if members_list:
                line += f"\n  Members ({details.get('member_count', len(members_list))}): {', '.join(members_list[:20])}"
            pins = details.get("pins") or []
            if pins:
                line += f"\n  Pinned messages ({len(pins)}):"
                for pin in pins:
                    pin_author = pin.get("author", "?")
                    pin_content = pin.get("content", "")
                    line += f"\n    {pin_author}: {pin_content}"

        lines.append(line)

    return f"{len(notifications)} notification(s):\n\n" + "\n\n".join(lines)
