"""Notification tool handlers."""

from __future__ import annotations

import json
from typing import Any

from ..client import graphql
from ..constants import DEFAULT_NOTIFICATION_LIMIT


def dispatch_notify(action: str, args: dict[str, Any]) -> str:
    match action:
        case "list":
            return _list(args)
        case "read":
            return _read(args)
        case "read_all":
            return _read_all()
        case "subscribe":
            return _subscribe(args)
        case "bulk_subscribe":
            return _bulk_subscribe(args)
        case "unsubscribe":
            return _unsubscribe(args)
        case "subscriptions":
            return _subscriptions()
        case "unread":
            return _unread()
        case _:
            return json.dumps({"error": f"Unknown notify action: {action}"})


def _list(args: dict[str, Any]) -> str:
    unread_only: bool = args.get("unread_only", True)
    limit: int = args.get("limit", DEFAULT_NOTIFICATION_LIMIT)
    data = graphql(
        """query($unreadOnly: Boolean, $limit: Int) {
            notifications(unreadOnly: $unreadOnly, limit: $limit) {
                id type sourceType sourceId messageId title body isRead priority createdAt
            }
        }""",
        {"unreadOnly": unread_only, "limit": limit},
    )
    notifications: list[dict[str, Any]] = data.get("notifications", [])
    if not notifications:
        return "No notifications."
    lines = [f"{len(notifications)} notification(s):\n"]
    for n in notifications:
        read = "" if n.get("isRead") else " [unread]"
        notif_id = n.get("id", "")
        msg_id = n.get("messageId")
        ids = f" (notif_id: {notif_id}"
        if msg_id:
            ids += f", message_id: {msg_id}"
        ids += ")"
        lines.append(
            f"- [{n.get('type', '?')}]{read} {n.get('title', '')}: {n.get('body', '')}"
            f"{ids} ({n.get('createdAt', '?')})"
        )
    return "\n".join(lines)


def _read(args: dict[str, Any]) -> str:
    notification_id: str | None = args.get("notification_id")
    if not notification_id:
        return json.dumps({"error": "notification_id is required"})
    graphql(
        """mutation($id: ID!) { markNotificationRead(id: $id) { id isRead } }""",
        {"id": notification_id},
    )
    return f"Notification {notification_id} marked as read."


def _read_all() -> str:
    graphql("""mutation { markAllNotificationsRead }""")
    return "All notifications marked as read."


def _subscribe(args: dict[str, Any]) -> str:
    source_type: str | None = args.get("source_type")
    source_id: str | None = args.get("source_id")
    if not source_type or not source_id:
        return json.dumps({"error": "source_type and source_id are required"})
    data = graphql(
        """mutation($sourceType: String!, $sourceId: ID!, $immediate: Boolean) {
            subscribe(sourceType: $sourceType, sourceId: $sourceId, notifyImmediately: $immediate) {
                id sourceType sourceId notifyImmediately
            }
        }""",
        {
            "sourceType": source_type,
            "sourceId": source_id,
            "immediate": args.get("immediate", False),
        },
    )
    sub: dict[str, Any] = data.get("subscribe", {})
    return f"Subscribed to {source_type}/{source_id} (id: {sub.get('id', '?')})"


def _bulk_subscribe(args: dict[str, Any]) -> str:
    sources: list[dict[str, str]] | None = args.get("sources")
    if not sources:
        return json.dumps({"error": "sources is required"})
    data = graphql(
        """mutation($sources: [JSON!]!, $immediate: Boolean) {
            bulkSubscribe(sources: $sources, notifyImmediately: $immediate) {
                id sourceType sourceId
            }
        }""",
        {"sources": sources, "immediate": args.get("immediate", False)},
    )
    subs: list[dict[str, Any]] = data.get("bulkSubscribe", [])
    return f"Subscribed to {len(subs)} source(s)."


def _unsubscribe(args: dict[str, Any]) -> str:
    subscription_id: str | None = args.get("subscription_id")
    if not subscription_id:
        return json.dumps({"error": "subscription_id is required"})
    graphql(
        """mutation($id: ID!) { unsubscribe(subscriptionId: $id) }""",
        {"id": subscription_id},
    )
    return f"Unsubscribed (id: {subscription_id})."


def _subscriptions() -> str:
    return json.dumps(
        {"error": "subscriptions listing not yet available — use unread to check notification counts"}
    )


def _unread() -> str:
    data = graphql(
        """query {
            unreadCounts {
                totalUnread
                channelUnreads { channelId count }
                dmUnreads { dmChannelId count }
            }
        }""",
    )
    counts: dict[str, Any] = data.get("unreadCounts", {})
    total: int = counts.get("totalUnread", 0)
    if total == 0:
        return "No unread messages."
    lines = [f"Total unread: {total}\n"]
    for cu in counts.get("channelUnreads", []):
        lines.append(f"  Channel {cu.get('channelId')}: {cu.get('count')} unread")
    for du in counts.get("dmUnreads", []):
        lines.append(f"  DM {du.get('dmChannelId')}: {du.get('count')} unread")
    return "\n".join(lines)
