"""Issue tool handlers."""

from __future__ import annotations

import json
from typing import Any

from .. import client
from ..client import graphql, resolve_issue_id
from ..constants import ISSUE_FIELDS, MSG_FIELDS
from ..formatting import fmt_issue, fmt_msg


def dispatch_issue(action: str, args: dict[str, Any]) -> str:
    match action:
        case "list":
            return _list(args)
        case "get":
            return _get(args)
        case "create":
            return _create(args)
        case "update":
            return _update(args)
        case "assign":
            return _assign(args)
        case "unassign":
            return _unassign(args)
        case "comment":
            return _comment(args)
        case "label":
            return _label(args)
        case "unlabel":
            return _unlabel(args)
        case "link_thread":
            return _link_thread(args)
        case "unlink_thread":
            return _unlink_thread(args)
        case "threads":
            return _threads(args)
        case "my_issues":
            return _my_issues()
        case "promote":
            return _promote(args)
        case "add_relation":
            return _add_relation(args)
        case "remove_relation":
            return _remove_relation(args)
        case "relations":
            return _relations(args)
        case "suggest_reviewers":
            return _suggest_reviewers(args)
        case "claim":
            return _claim(args)
        case "assign_team":
            return _assign_team(args)
        case "delete":
            return _delete(args)
        case "restore":
            return _restore(args)
        case "subscribe":
            return _subscribe(args)
        case "unsubscribe":
            return _unsubscribe(args)
        case "watching":
            return _watching()
        case _:
            return json.dumps({"error": f"Unknown issue action: {action}"})


def _require_issue_id(args: dict[str, Any]) -> str:
    """Extract and resolve issue_id from args. Raises ValueError on failure."""
    raw: str | None = args.get("issue_id")
    if not raw:
        raise ValueError("issue_id is required")
    return resolve_issue_id(raw)


def _suggest_reviewers(args: dict[str, Any]) -> str:
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    data = graphql(
        """query($issueId: ID!) {
            suggestReviewers(issueId: $issueId) {
                score
                reasons
                member { id displayName username workStatus role }
            }
        }""",
        {"issueId": issue_id},
    )
    suggestions: list[dict[str, Any]] = data.get("suggestReviewers", [])
    if not suggestions:
        return "No reviewer suggestions available for this issue."
    lines = [f"{len(suggestions)} reviewer candidate(s):\n"]
    for s in suggestions:
        m = s.get("member", {}) or {}
        reasons = "; ".join(s.get("reasons") or [])
        lines.append(
            f"- **{m.get('displayName', '?')}** (id: {m.get('id', '?')}, role: {m.get('role', '?')}, "
            f"work_status: {m.get('workStatus', '?')}) — score {s.get('score', 0):.1f}\n  {reasons}"
        )
    return "\n".join(lines)


def _list(args: dict[str, Any]) -> str:
    variables: dict[str, Any] = {"orgId": client.org_id}
    if args.get("status"):
        variables["status"] = args["status"]
    if args.get("assignee_id"):
        variables["assigneeId"] = args["assignee_id"]
    if args.get("label_id"):
        variables["labelId"] = args["label_id"]
    if args.get("search"):
        variables["search"] = args["search"]
    if args.get("team_id"):
        variables["teamId"] = args["team_id"]
    data = graphql(
        f"""query($orgId: ID!, $status: IssueStatus, $assigneeId: ID, $labelId: ID, $search: String, $teamId: ID) {{
            issues(orgId: $orgId, status: $status, assigneeId: $assigneeId, labelId: $labelId, search: $search, teamId: $teamId) {{ {ISSUE_FIELDS} }}
        }}""",
        variables,
    )
    issues: list[dict[str, Any]] = data.get("issues", [])
    if not issues:
        return "No issues found."
    lines = [f"{len(issues)} issue(s):\n"]
    for issue in issues:
        lines.append(fmt_issue(issue))
    return "\n".join(lines)


def _get(args: dict[str, Any]) -> str:
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    data = graphql(
        f"""query($id: ID!) {{
            issue(id: $id) {{ {ISSUE_FIELDS} }}
        }}""",
        {"id": issue_id},
    )
    issue: dict[str, Any] | None = data.get("issue")
    if not issue:
        return f"Issue {issue_id} not found."
    comments_data = graphql(
        """query($issueId: ID!) {
            issueComments(issueId: $issueId) {
                id content createdAt author { id displayName type }
            }
        }""",
        {"issueId": issue_id},
    )
    comments: list[dict[str, Any]] = comments_data.get("issueComments", [])
    lines = [fmt_issue(issue), f"\nDescription: {issue.get('description') or '(none)'}"]
    if comments:
        lines.append(f"\n{len(comments)} comment(s):")
        for c in comments:
            author_obj: dict[str, Any] = c.get("author") or {}
            author = author_obj.get("displayName", "?")
            author_type = author_obj.get("type")
            type_tag = f" [{author_type}]" if author_type else ""
            lines.append(
                f"  [{author}{type_tag} @ {c.get('createdAt', '?')}]: {c.get('content', '')}"
            )
    return "\n".join(lines)


def _create(args: dict[str, Any]) -> str:
    title: str | None = args.get("title")
    if not title:
        return json.dumps({"error": "title is required"})
    variables: dict[str, Any] = {"orgId": client.org_id, "title": title}
    if args.get("description"):
        variables["description"] = args["description"]
    if args.get("priority"):
        variables["priority"] = args["priority"]
    if args.get("assignee_ids"):
        variables["assigneeIds"] = args["assignee_ids"]
    if args.get("label_ids"):
        variables["labelIds"] = args["label_ids"]
    if args.get("team_id"):
        variables["teamId"] = args["team_id"]
    # AS-332: parent_issue_id / parent_id → sub-issue support. Accept either AS-### or UUID.
    parent_arg = args.get("parent_issue_id") or args.get("parent_id")
    if parent_arg:
        variables["parentId"] = resolve_issue_id(parent_arg)
    data = graphql(
        f"""mutation($orgId: ID!, $title: String!, $description: String, $priority: IssuePriority, $assigneeIds: [ID!], $labelIds: [ID!], $teamId: ID, $parentId: ID) {{
            createIssue(input: {{ orgId: $orgId, title: $title, description: $description, priority: $priority, assigneeIds: $assigneeIds, labelIds: $labelIds, teamId: $teamId, parentId: $parentId }}) {{ {ISSUE_FIELDS} }}
        }}""",
        variables,
    )
    issue: dict[str, Any] = data.get("createIssue", {})
    return f"Issue created: {fmt_issue(issue)}"


def _update(args: dict[str, Any]) -> str:
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    variables: dict[str, Any] = {"id": issue_id}
    if args.get("title"):
        variables["title"] = args["title"]
    if args.get("description"):
        variables["description"] = args["description"]
    if args.get("status"):
        variables["status"] = args["status"]
    if args.get("priority"):
        variables["priority"] = args["priority"]
    if "team_id" in args:
        tid = args.get("team_id")
        if tid is None or tid == "":
            variables["clearTeam"] = True
        else:
            variables["teamId"] = tid
    data = graphql(
        f"""mutation($id: ID!, $title: String, $description: String, $status: IssueStatus, $priority: IssuePriority, $teamId: ID, $clearTeam: Boolean) {{
            updateIssue(input: {{ id: $id, title: $title, description: $description, status: $status, priority: $priority, teamId: $teamId, clearTeam: $clearTeam }}) {{ {ISSUE_FIELDS} }}
        }}""",
        variables,
    )
    issue: dict[str, Any] = data.get("updateIssue", {})
    return f"Issue updated: {fmt_issue(issue)}"


def _claim(args: dict[str, Any]) -> str:
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    data = graphql(
        f"""mutation($id: ID!) {{
            claimIssue(issueId: $id) {{ {ISSUE_FIELDS} }}
        }}""",
        {"id": issue_id},
    )
    issue: dict[str, Any] = data.get("claimIssue", {})
    return f"Issue claimed: {fmt_issue(issue)}"


def _assign_team(args: dict[str, Any]) -> str:
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    team_id = args.get("team_id")
    variables: dict[str, Any] = {"id": issue_id}
    if team_id:
        variables["teamId"] = team_id
    data = graphql(
        f"""mutation($id: ID!, $teamId: ID) {{
            assignIssueToTeam(issueId: $id, teamId: $teamId) {{ {ISSUE_FIELDS} }}
        }}""",
        variables,
    )
    issue: dict[str, Any] = data.get("assignIssueToTeam", {})
    return f"Issue team set: {fmt_issue(issue)}"


def _delete(args: dict[str, Any]) -> str:
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    hard = bool(args.get("hard", False))
    data = graphql(
        """mutation($id: ID!, $hard: Boolean!) {
            deleteIssue(issueId: $id, hard: $hard)
        }""",
        {"id": issue_id, "hard": hard},
    )
    ok = data.get("deleteIssue")
    kind = "hard-deleted" if hard else "deleted"
    return f"Issue {kind}." if ok else json.dumps({"error": "delete failed"})


def _restore(args: dict[str, Any]) -> str:
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    data = graphql(
        f"""mutation($id: ID!) {{
            restoreIssue(issueId: $id) {{ {ISSUE_FIELDS} }}
        }}""",
        {"id": issue_id},
    )
    issue: dict[str, Any] = data.get("restoreIssue", {})
    return f"Issue restored: {fmt_issue(issue)}"


def _subscribe(args: dict[str, Any]) -> str:
    """AS-338: watch an issue (receive notifications for events on it)."""
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    variables: dict[str, Any] = {"id": issue_id}
    reason = args.get("reason")
    if reason:
        variables["reason"] = reason
    data = graphql(
        """mutation($id: ID!, $reason: String) {
            subscribeIssue(issueId: $id, reason: $reason)
        }""",
        variables,
    )
    ok = data.get("subscribeIssue")
    return "Subscribed." if ok else json.dumps({"error": "Subscribe failed"})


def _unsubscribe(args: dict[str, Any]) -> str:
    """AS-338: stop watching an issue."""
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    data = graphql(
        """mutation($id: ID!) {
            unsubscribeIssue(issueId: $id)
        }""",
        {"id": issue_id},
    )
    ok = data.get("unsubscribeIssue")
    return "Unsubscribed." if ok else json.dumps({"error": "Unsubscribe failed"})


def _assign(args: dict[str, Any]) -> str:
    raw_issue_id: str | None = args.get("issue_id")
    target_member_id: str | None = args.get("member_id") or args.get("assignee_id")
    if not raw_issue_id or not target_member_id:
        return json.dumps({"error": "issue_id and member_id are required"})
    try:
        issue_id = resolve_issue_id(raw_issue_id)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    graphql(
        """mutation($issueId: ID!, $memberId: ID!) {
            assignIssue(issueId: $issueId, memberId: $memberId) { id }
        }""",
        {"issueId": issue_id, "memberId": target_member_id},
    )
    return f"Member {target_member_id} assigned to issue {issue_id}."


def _unassign(args: dict[str, Any]) -> str:
    raw_issue_id: str | None = args.get("issue_id")
    target_member_id: str | None = args.get("member_id") or args.get("assignee_id")
    if not raw_issue_id or not target_member_id:
        return json.dumps({"error": "issue_id and member_id are required"})
    try:
        issue_id = resolve_issue_id(raw_issue_id)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    graphql(
        """mutation($issueId: ID!, $memberId: ID!) {
            unassignIssue(issueId: $issueId, memberId: $memberId) { id }
        }""",
        {"issueId": issue_id, "memberId": target_member_id},
    )
    return f"Member {target_member_id} unassigned from issue {issue_id}."


def _comment(args: dict[str, Any]) -> str:
    content: str | None = args.get("content")
    if not content:
        return json.dumps({"error": "issue_id and content are required"})
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    data = graphql(
        """mutation($issueId: ID!, $content: String!) {
            addIssueComment(issueId: $issueId, content: $content) {
                id content createdAt
            }
        }""",
        {"issueId": issue_id, "content": content},
    )
    comment: dict[str, Any] = data.get("addIssueComment", {})
    return f"Comment added (id: {comment.get('id', '?')})"


def _label(args: dict[str, Any]) -> str:
    label_id: str | None = args.get("label_id")
    if not label_id:
        return json.dumps({"error": "issue_id and label_id are required"})
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    graphql(
        """mutation($issueId: ID!, $labelId: ID!) {
            addIssueLabel(issueId: $issueId, labelId: $labelId) { id }
        }""",
        {"issueId": issue_id, "labelId": label_id},
    )
    return f"Label {label_id} added to issue {issue_id}."


def _unlabel(args: dict[str, Any]) -> str:
    label_id: str | None = args.get("label_id")
    if not label_id:
        return json.dumps({"error": "issue_id and label_id are required"})
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    graphql(
        """mutation($issueId: ID!, $labelId: ID!) {
            removeIssueLabel(issueId: $issueId, labelId: $labelId) { id }
        }""",
        {"issueId": issue_id, "labelId": label_id},
    )
    return f"Label {label_id} removed from issue {issue_id}."


def _link_thread(args: dict[str, Any]) -> str:
    message_id: str | None = args.get("message_id")
    if not message_id:
        return json.dumps({"error": "issue_id and message_id are required"})
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    graphql(
        """mutation($issueId: ID!, $messageId: ID!) {
            linkIssueThread(issueId: $issueId, messageId: $messageId) { id }
        }""",
        {"issueId": issue_id, "messageId": message_id},
    )
    return f"Thread {message_id} linked to issue {issue_id}."


def _unlink_thread(args: dict[str, Any]) -> str:
    message_id: str | None = args.get("message_id")
    if not message_id:
        return json.dumps({"error": "issue_id and message_id are required"})
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    graphql(
        """mutation($issueId: ID!, $messageId: ID!) {
            unlinkIssueThread(issueId: $issueId, messageId: $messageId) { id }
        }""",
        {"issueId": issue_id, "messageId": message_id},
    )
    return f"Thread {message_id} unlinked from issue {issue_id}."


def _threads(args: dict[str, Any]) -> str:
    try:
        issue_id = _require_issue_id(args)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    data = graphql(
        f"""query($issueId: ID!) {{
            issueThreads(issueId: $issueId) {{
                messageId linkedAt
                message {{ {MSG_FIELDS} }}
                linker {{ id displayName }}
            }}
        }}""",
        {"issueId": issue_id},
    )
    threads: list[dict[str, Any]] = data.get("issueThreads", [])
    if not threads:
        return f"No threads linked to issue {issue_id}."
    lines = [f"{len(threads)} linked thread(s):\n"]
    for t in threads:
        linker = t.get("linker", {}).get("displayName", "?")
        msg = t.get("message", {})
        lines.append(f"[linked by {linker} @ {t.get('linkedAt', '?')}] {fmt_msg(msg)}")
    return "\n".join(lines)


def _watching() -> str:
    """Personal priority queue — caller's `Subscription` rows, enriched."""
    data = graphql(
        """query {
            myWatching {
                subscriptionId sourceType sourceId reason subscribedAt
                identifier title status priority lastActivityAt
            }
        }""",
        {},
    )
    items: list[dict[str, Any]] = data.get("myWatching", [])
    if not items:
        return "Nothing in your watch list. Subscribe to issues with agentslack_issue(action='subscribe', issue_id=…)."
    issues = [i for i in items if i.get("sourceType") == "issue"]
    others = [i for i in items if i.get("sourceType") != "issue"]
    lines = [f"{len(items)} item(s) in your watch list (sorted by priority → activity):\n"]
    if issues:
        lines.append(f"--- Issues ({len(issues)}) ---")
        for i in issues:
            ident = i.get("identifier") or "?"
            title = i.get("title") or "(untitled)"
            status = i.get("status") or "?"
            prio = i.get("priority") or "none"
            last = i.get("lastActivityAt") or "?"
            reason = i.get("reason")
            reason_tag = f" — _{reason}_" if reason else ""
            lines.append(f"  [{prio}/{status}] **{ident}** {title} (last activity: {last}){reason_tag}")
    if others:
        lines.append(f"\n--- Other ({len(others)}) ---")
        for o in others:
            lines.append(f"  [{o.get('sourceType')}] {o.get('sourceId')}")
    return "\n".join(lines)


def _my_issues() -> str:
    data = graphql(
        f"""query($orgId: ID!, $assigneeId: ID) {{
            issues(orgId: $orgId, assigneeId: $assigneeId) {{ {ISSUE_FIELDS} }}
        }}""",
        {"orgId": client.org_id, "assigneeId": client.member_id},
    )
    issues: list[dict[str, Any]] = data.get("issues", [])
    if not issues:
        return "No issues assigned to you."
    lines = [f"{len(issues)} issue(s) assigned to you:\n"]
    for issue in issues:
        lines.append(fmt_issue(issue))
    return "\n".join(lines)


def _add_relation(args: dict[str, Any]) -> str:
    raw_issue_id: str | None = args.get("issue_id")
    raw_related_id: str | None = args.get("related_issue_id")
    relation_type: str | None = args.get("relation_type")
    if not raw_issue_id or not raw_related_id or not relation_type:
        return json.dumps({"error": "issue_id, related_issue_id, and relation_type are required"})
    try:
        issue_id = resolve_issue_id(raw_issue_id)
        related_id = resolve_issue_id(raw_related_id)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    data = graphql(
        """mutation($issueId: ID!, $relatedIssueId: ID!, $relationType: IssueRelationType!) {
            addIssueRelation(issueId: $issueId, relatedIssueId: $relatedIssueId, relationType: $relationType) {
                id issueId relatedIssueId relationType createdAt
                relatedIssue { id identifier title status }
                createdBy { id displayName }
            }
        }""",
        {"issueId": issue_id, "relatedIssueId": related_id, "relationType": relation_type},
    )
    rel: dict[str, Any] = data.get("addIssueRelation", {})
    related: dict[str, Any] = rel.get("relatedIssue", {})
    return (
        f"Relation added: {raw_issue_id} {relation_type} "
        f"{related.get('identifier', raw_related_id)} ({related.get('title', '?')})"
    )


def _remove_relation(args: dict[str, Any]) -> str:
    raw_issue_id: str | None = args.get("issue_id")
    raw_related_id: str | None = args.get("related_issue_id")
    relation_type: str | None = args.get("relation_type")
    if not raw_issue_id or not raw_related_id or not relation_type:
        return json.dumps({"error": "issue_id, related_issue_id, and relation_type are required"})
    try:
        issue_id = resolve_issue_id(raw_issue_id)
        related_id = resolve_issue_id(raw_related_id)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    graphql(
        """mutation($issueId: ID!, $relatedIssueId: ID!, $relationType: IssueRelationType!) {
            removeIssueRelation(issueId: $issueId, relatedIssueId: $relatedIssueId, relationType: $relationType)
        }""",
        {"issueId": issue_id, "relatedIssueId": related_id, "relationType": relation_type},
    )
    return f"Relation removed: {raw_issue_id} {relation_type} {raw_related_id}"


def _relations(args: dict[str, Any]) -> str:
    raw_issue_id: str | None = args.get("issue_id")
    if not raw_issue_id:
        return json.dumps({"error": "issue_id is required"})
    try:
        issue_id = resolve_issue_id(raw_issue_id)
    except ValueError as e:
        return json.dumps({"error": str(e)})
    data = graphql(
        """query($issueId: ID!) {
            issueRelations(issueId: $issueId) {
                id relationType createdAt
                relatedIssue { id identifier title status priority }
                createdBy { id displayName }
            }
        }""",
        {"issueId": issue_id},
    )
    relations: list[dict[str, Any]] = data.get("issueRelations", [])
    if not relations:
        return f"No relations on issue {raw_issue_id}."
    lines = [f"{len(relations)} relation(s):\n"]
    for r in relations:
        rtype: str = r.get("relationType", "?")
        related: dict[str, Any] = r.get("relatedIssue", {})
        creator: str = (r.get("createdBy") or {}).get("displayName", "?")
        lines.append(
            f"- {rtype} {related.get('identifier', '?')} — {related.get('title', '?')} "
            f"[{related.get('status', '?')}/{related.get('priority', '?')}] (by {creator})"
        )
    return "\n".join(lines)


def _promote(args: dict[str, Any]) -> str:
    """Promote a thread into a tracked issue (AS-120)."""
    message_id = args.get("message_id")
    if not message_id:
        return json.dumps({"error": "message_id is required"})

    org_id = args.get("org_id") or client.org_id
    if not org_id:
        return json.dumps({"error": "org_id could not be resolved from session; pass org_id explicitly"})

    input_obj: dict[str, Any] = {"messageId": message_id, "orgId": org_id}

    title = args.get("title")
    if title:
        input_obj["title"] = title

    description = args.get("description")
    if description:
        input_obj["description"] = description

    priority = args.get("priority")
    if priority:
        input_obj["priority"] = priority.upper()

    assignee_ids = args.get("assignee_ids")
    if assignee_ids:
        input_obj["assigneeIds"] = assignee_ids

    if args.get("assign_participants"):
        input_obj["assignParticipants"] = True

    data = graphql(
        f"""mutation($input: PromoteThreadToIssueInput!) {{
            promoteThreadToIssue(input: $input) {{
                {ISSUE_FIELDS}
            }}
        }}""",
        {"input": input_obj},
    )
    issue = data.get("promoteThreadToIssue")
    if not issue:
        return json.dumps({"error": "Failed to promote thread"})
    return f"Thread promoted to {fmt_issue(issue)}"
