"""DM tool handlers."""

from __future__ import annotations

import json
from typing import Any

from .. import client
from ..client import coerce_attachments, graphql
from ..constants import DEFAULT_MESSAGE_LIMIT, MSG_FIELDS
from ..formatting import fmt_paginated_messages


def dispatch_dm(action: str, args: dict[str, Any]) -> str:
    match action:
        case "list":
            return _list()
        case "open":
            return _open(args)
        case "read":
            return _read(args)
        case "send":
            return _send(args)
        case "mark_read":
            return _mark_read(args)
        case _:
            return json.dumps({"error": f"Unknown dm action: {action}"})


def _list() -> str:
    data = graphql(
        """query($orgId: ID!) {
            dmChannels(orgId: $orgId) {
                id updatedAt
                dmMembers { memberId member { id displayName } }
            }
        }""",
        {"orgId": client.org_id},
    )
    channels: list[dict[str, Any]] = data.get("dmChannels", [])
    if not channels:
        return "No DM channels found."
    lines = [f"{len(channels)} DM channel(s):\n"]
    for ch in channels:
        members = ", ".join(
            m.get("member", {}).get("displayName", m.get("memberId", "?"))
            for m in ch.get("dmMembers", [])
        )
        lines.append(f"- {ch['id']}: {members}")
    return "\n".join(lines)


def _open(args: dict[str, Any]) -> str:
    member_ids: list[str] | None = args.get("member_ids")
    if not member_ids:
        return json.dumps({"error": "member_ids is required"})
    data = graphql(
        """mutation($orgId: ID!, $memberIds: [ID!]!) {
            createDm(orgId: $orgId, memberIds: $memberIds) {
                id
                dmMembers { memberId member { id displayName } }
            }
        }""",
        {"orgId": client.org_id, "memberIds": member_ids},
    )
    dm: dict[str, Any] = data.get("createDm", {})
    members = ", ".join(
        m.get("member", {}).get("displayName", m.get("memberId", "?"))
        for m in dm.get("dmMembers", [])
    )
    return f"DM channel opened: {dm.get('id', '?')} with {members}"


def _read(args: dict[str, Any]) -> str:
    dm_channel_id: str | None = args.get("dm_channel_id")
    if not dm_channel_id:
        return json.dumps({"error": "dm_channel_id is required"})
    variables: dict[str, Any] = {
        "dmChannelId": dm_channel_id,
        "limit": args.get("limit", DEFAULT_MESSAGE_LIMIT),
    }
    if args.get("before_cursor"):
        variables["beforeCursor"] = args["before_cursor"]
    data = graphql(
        f"""query($dmChannelId: ID!, $beforeCursor: String, $limit: Int) {{
            dmMessages(dmChannelId: $dmChannelId, beforeCursor: $beforeCursor, limit: $limit) {{
                edges {{ cursor node {{ {MSG_FIELDS} }} }}
                pageInfo {{ hasPreviousPage startCursor }}
            }}
        }}""",
        variables,
    )
    conn: dict[str, Any] = data.get("dmMessages", {})
    return fmt_paginated_messages(
        conn.get("edges", []),
        conn.get("pageInfo", {}),
        f"No messages in DM channel {dm_channel_id}.",
    )


def _send(args: dict[str, Any]) -> str:
    dm_channel_id: str | None = args.get("dm_channel_id")
    content: str | None = args.get("content")
    if not dm_channel_id or (
        not content and not args.get("attachments") and not args.get("gif_url")
    ):
        return json.dumps(
            {"error": "dm_channel_id and (content or attachments/gif_url) are required"}
        )
    variables: dict[str, Any] = {"dmChannelId": dm_channel_id, "content": content or ""}
    if args.get("thread_id"):
        variables["threadId"] = args["thread_id"]
    if args.get("await_response_secs") is not None:
        variables["awaitResponseSecs"] = int(args["await_response_secs"])
    attachments = coerce_attachments(args)
    if attachments:
        variables["attachments"] = attachments
    data = graphql(
        """mutation($dmChannelId: ID!, $content: String!, $threadId: ID, $awaitResponseSecs: Int, $attachments: JSON) {
            sendDm(dmChannelId: $dmChannelId, content: $content, threadId: $threadId, awaitResponseSecs: $awaitResponseSecs, attachments: $attachments) {
                id createdAt
            }
        }""",
        variables,
    )
    msg: dict[str, Any] = data.get("sendDm", {})
    return f"DM sent (id: {msg.get('id', '?')})"


def _mark_read(args: dict[str, Any]) -> str:
    dm_channel_id: str | None = args.get("dm_channel_id")
    if not dm_channel_id:
        return json.dumps({"error": "dm_channel_id is required"})
    graphql(
        """mutation($dmChannelId: ID!) { markDmRead(dmChannelId: $dmChannelId) }""",
        {"dmChannelId": dm_channel_id},
    )
    return f"DM channel {dm_channel_id} marked as read."
