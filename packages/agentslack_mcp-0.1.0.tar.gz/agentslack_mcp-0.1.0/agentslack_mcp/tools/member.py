"""Member tool handlers."""

from __future__ import annotations

import json
from typing import Any

from .. import client
from ..client import graphql


def dispatch_member(action: str, args: dict[str, Any]) -> str:
    match action:
        case "me":
            return _me()
        case "list":
            return _list()
        case "get":
            return _get(args)
        case "get_many":
            return _get_many(args)
        case "status":
            return _status(args)
        case "update_profile":
            return _update_profile(args)
        case "tools":
            return _tools(args)
        case "search":
            return _search(args)
        case _:
            return json.dumps({"error": f"Unknown member action: {action}"})


def _me() -> str:
    data = graphql(
        """query {
            me { id username displayName email type status statusMessage statusEmoji onboardingStatus createdAt }
        }""",
    )
    m: dict[str, Any] = data.get("me", {})
    return json.dumps(m, indent=2, default=str)


def _list() -> str:
    data = graphql(
        """query($orgId: ID!) {
            members(orgId: $orgId) { id displayName username type status statusMessage }
        }""",
        {"orgId": client.org_id},
    )
    members: list[dict[str, Any]] = data.get("members", [])
    if not members:
        return "No members found."
    lines = [f"{len(members)} member(s):\n"]
    for m in members:
        status_msg = f" — {m['statusMessage']}" if m.get("statusMessage") else ""
        lines.append(
            f"- {m.get('displayName', '?')} ({m['id']}) [{m.get('type', '?')}] "
            f"{m.get('status', '')}{status_msg}"
        )
    return "\n".join(lines)


def _get(args: dict[str, Any]) -> str:
    target_member_id: str | None = args.get("member_id")
    if not target_member_id:
        return json.dumps({"error": "member_id is required"})
    data = graphql(
        """query($id: ID!) {
            member(id: $id) { id displayName username type status statusMessage statusEmoji onboardingStatus createdAt }
        }""",
        {"id": target_member_id},
    )
    m: dict[str, Any] | None = data.get("member")
    if not m:
        return f"Member {target_member_id} not found."
    return json.dumps(m, indent=2, default=str)


def _get_many(args: dict[str, Any]) -> str:
    member_ids: list[str] | None = args.get("member_ids")
    if not member_ids:
        return json.dumps({"error": "member_ids is required"})
    data = graphql(
        """query($ids: [ID!]!) {
            membersByIds(ids: $ids) { id displayName username type status }
        }""",
        {"ids": member_ids},
    )
    members: list[dict[str, Any]] = data.get("membersByIds", [])
    lines = [f"{len(members)} member(s):\n"]
    for m in members:
        lines.append(
            f"- {m.get('displayName', '?')} ({m['id']}) [{m.get('type', '?')}] {m.get('status', '')}"
        )
    return "\n".join(lines)


def _status(args: dict[str, Any]) -> str:
    variables: dict[str, Any] = {}
    if args.get("status"):
        variables["status"] = args["status"]
    if args.get("message"):
        variables["statusMessage"] = args["message"]
    if args.get("emoji"):
        variables["statusEmoji"] = args["emoji"]
    data = graphql(
        """mutation($status: MemberStatus, $statusMessage: String, $statusEmoji: String) {
            updateStatus(status: $status, statusMessage: $statusMessage, statusEmoji: $statusEmoji) {
                id status statusMessage statusEmoji
            }
        }""",
        variables,
    )
    m: dict[str, Any] = data.get("updateStatus", {})
    return (
        f"Status updated: {m.get('status', '?')} {m.get('statusEmoji', '')} "
        f"{m.get('statusMessage', '')}"
    ).strip()


def _update_profile(args: dict[str, Any]) -> str:
    variables: dict[str, Any] = {}
    if args.get("username"):
        variables["username"] = args["username"]
    if args.get("display_name"):
        variables["displayName"] = args["display_name"]
    data = graphql(
        """mutation($username: String, $displayName: String) {
            updateProfile(username: $username, displayName: $displayName) {
                id displayName username
            }
        }""",
        variables,
    )
    m: dict[str, Any] = data.get("updateProfile", {})
    return f"Profile updated: {m.get('displayName', '?')} (@{m.get('username', '?')})"


def _tools(args: dict[str, Any]) -> str:
    target_member_id: str | None = args.get("member_id")
    if not target_member_id:
        return json.dumps({"error": "member_id is required"})
    data = graphql(
        """query($memberId: ID!) {
            memberTools(memberId: $memberId) {
                id name toolType description declaredAt
            }
        }""",
        {"memberId": target_member_id},
    )
    tools: list[dict[str, Any]] = data.get("memberTools", [])
    if not tools:
        return f"No tools declared for member {target_member_id}."
    lines = [f"{len(tools)} tool(s):\n"]
    for t in tools:
        lines.append(
            f"- {t.get('name', '?')} [{t.get('toolType', '?')}]: "
            f"{t.get('description', '(no description)')}"
        )
    return "\n".join(lines)


def _search(args: dict[str, Any]) -> str:
    query: str | None = args.get("query")
    if not query:
        return json.dumps({"error": "query is required"})
    data = graphql(
        """query($query: String!) {
            searchMembers(query: $query) {
                member { id displayName username type status }
                sharedChannels { id name }
            }
        }""",
        {"query": query},
    )
    results: list[dict[str, Any]] = data.get("searchMembers", [])
    if not results:
        return "No members found."
    lines = [f"{len(results)} result(s):\n"]
    for r in results:
        m: dict[str, Any] = r.get("member", {})
        channels: list[dict[str, str]] = r.get("sharedChannels", [])
        channel_names = ", ".join(f"#{c['name']}" for c in channels) if channels else "none"
        lines.append(
            f"- {m.get('displayName', '?')} (@{m.get('username', '?')}) [{m.get('type', '?')}] "
            f"{m.get('status', '')} — shared channels: {channel_names}"
        )
    return "\n".join(lines)
