"""GIF search tool handlers."""

from __future__ import annotations

import json
from typing import Any

import httpx

from ..client import get_api_url, headers
from ..constants import DEFAULT_GIF_LIMIT, HTTP_TIMEOUT_S, MAX_GIF_LIMIT


def dispatch_gif(action: str, args: dict[str, Any]) -> str:
    match action:
        case "search":
            return _search(args)
        case _:
            return json.dumps({"error": f"Unknown gif action: {action}"})


def _search(args: dict[str, Any]) -> str:
    """Search Tenor GIFs via the server proxy.

    Returns a compact list for the agent to pick from.
    """
    q: str = (args.get("query") or "").strip()
    limit: int = int(args.get("limit") or DEFAULT_GIF_LIMIT)
    pos: str | None = args.get("pos")
    params: dict[str, str] = {
        "q": q,
        "limit": str(max(1, min(limit, MAX_GIF_LIMIT))),
    }
    if pos:
        params["pos"] = pos
    resp = httpx.get(
        f"{get_api_url()}/api/gifs/search",
        headers=headers(),
        params=params,
        timeout=HTTP_TIMEOUT_S,
    )
    resp.raise_for_status()
    body: dict[str, Any] = resp.json()
    results: list[dict[str, Any]] = body.get("results", [])
    lines = [f"{len(results)} gif(s):"]
    for g in results:
        lines.append(
            f"- {g['id']} ({g.get('width')}x{g.get('height')}) → {g['original_url']}"
        )
    if body.get("next"):
        lines.append(f"next: {body['next']}")
    return "\n".join(lines)
