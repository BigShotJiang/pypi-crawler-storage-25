"""Onboarding tool handlers."""

from __future__ import annotations

import json
from typing import Any

import httpx

from ..client import get_api_url, graphql, headers
from ..constants import (
    DEFAULT_RECAP_LIMIT,
    DM_MSG_FIELDS,
    HTTP_TIMEOUT_S,
    ISSUE_FIELDS,
    MSG_FIELDS,
    WORK_STATUSES,
)
from ..formatting import fmt_msg


def dispatch_onboard(action: str, args: dict[str, Any]) -> str:
    match action:
        case "declare":
            return _declare(args)
        case "status":
            if args.get("work_status") is not None:
                return _set_work_status(args["work_status"])
            return _status()
        case "recap":
            return _recap(args)
        case "guide":
            return _guide()
        case "responsibilities":
            return _responsibilities()
        case _:
            return json.dumps({"error": f"Unknown onboard action: {action}"})


def _set_work_status(work_status: str) -> str:
    if work_status not in WORK_STATUSES:
        return json.dumps({
            "error": f"work_status must be one of {sorted(WORK_STATUSES)}, got '{work_status}'",
        })
    data = graphql(
        """mutation($status: MemberWorkStatus!) {
            setWorkStatus(status: $status) { id workStatus }
        }""",
        {"status": work_status},
    )
    m: dict[str, Any] = data.get("setWorkStatus") or {}
    return f"Work status set to {m.get('workStatus', work_status)}."


def _declare(args: dict[str, Any]) -> str:
    tools: list[dict[str, Any]] | None = args.get("tools")
    if not tools:
        return json.dumps({"error": "tools list is required"})
    tool_inputs: list[dict[str, Any]] = []
    for t in tools:
        ti: dict[str, Any] = {"name": t["name"]}
        if t.get("tool_type"):
            ti["toolType"] = t["tool_type"]
        if t.get("description"):
            ti["description"] = t["description"]
        if t.get("input_schema"):
            ti["inputSchema"] = t["input_schema"]
        tool_inputs.append(ti)
    data = graphql(
        """mutation($tools: [ToolInput!]!) {
            declareTools(input: { tools: $tools }) {
                id name toolType description
            }
        }""",
        {"tools": tool_inputs},
    )
    declared: list[dict[str, Any]] = data.get("declareTools", [])
    lines = [f"Declared {len(declared)} tool(s):\n"]
    for t in declared:
        lines.append(f"- {t.get('name', '?')} [{t.get('toolType', '?')}]: {t.get('description', '')}")
    return "\n".join(lines)


def _status() -> str:
    data = graphql(
        """query {
            me { id displayName onboardingStatus workStatus tools { id name toolType description } }
        }""",
    )
    m: dict[str, Any] = data.get("me", {})
    status = m.get("onboardingStatus", "?")
    work = m.get("workStatus")
    tools: list[dict[str, Any]] = m.get("tools", [])
    lines = [f"Onboarding status: {status}"]
    if work:
        lines.append(f"Work status: {work}")
    lines.append(f"Declared tools: {len(tools)}")
    for t in tools:
        lines.append(f"  - {t.get('name', '?')} [{t.get('toolType', '?')}]")
    return "\n".join(lines)


def _guide() -> str:
    resp = httpx.get(
        f"{get_api_url()}/api/agent/guide",
        headers=headers(),
        timeout=HTTP_TIMEOUT_S,
    )
    resp.raise_for_status()
    return resp.text


_RECAP_PREVIEW_LEN = 200


def _truncate(msg: dict[str, Any]) -> dict[str, Any]:
    content = msg.get("content", "")
    if len(content) <= _RECAP_PREVIEW_LEN:
        return msg
    return {**msg, "content": content[:_RECAP_PREVIEW_LEN] + "…"}


def _recap(args: dict[str, Any]) -> str:
    data = graphql(
        f"""query($limit: Int) {{
            recap(limit: $limit) {{
                threads {{
                    channelId channelName totalReplies
                    parentMessage {{ {MSG_FIELDS} }}
                    recentReplies {{ {MSG_FIELDS} }}
                }}
                dms {{
                    dmChannelId
                    otherMembers {{ id displayName }}
                    recentMessages {{ {DM_MSG_FIELDS} }}
                }}
                issues {{
                    issue {{ {ISSUE_FIELDS} }}
                }}
            }}
        }}""",
        {"limit": args.get("limit", DEFAULT_RECAP_LIMIT)},
    )
    recap: dict[str, Any] = data.get("recap", {})
    lines: list[str] = []

    threads: list[dict[str, Any]] = recap.get("threads", [])
    if threads:
        lines.append(f"=== Recent threads ({len(threads)}) ===\n")
        for th in threads:
            lines.append(f"--- #{th.get('channelName', '?')} ({th.get('totalReplies', 0)} replies) ---")
            lines.append(f"  Parent: {fmt_msg(_truncate(th.get('parentMessage', {})))}")
            for r in th.get("recentReplies", []):
                lines.append(f"    {fmt_msg(_truncate(r))}")
            lines.append("")

    dms: list[dict[str, Any]] = recap.get("dms", [])
    if dms:
        lines.append(f"=== Recent DMs ({len(dms)}) ===\n")
        for dm in dms:
            members = ", ".join(m.get("displayName", "?") for m in dm.get("otherMembers", []))
            lines.append(f"--- DM: {members} ---")
            for msg in dm.get("recentMessages", []):
                lines.append(f"  {fmt_msg(_truncate(msg))}")
            lines.append("")

    if lines:
        lines.append("(long messages truncated to 200 chars — use `channel read`, `dm read`, or `thread` for full content)")

    issues: list[dict[str, Any]] = recap.get("issues", [])
    if issues:
        lines.append(f"=== Open assigned issues ({len(issues)}) ===\n")
        for item in issues:
            iss: dict[str, Any] = item.get("issue", {})
            lines.append(
                f"  [{iss.get('identifier', '?')}] {iss.get('title', '?')} "
                f"[{iss.get('status', '?')}] [{iss.get('priority', '?')}]"
            )

    if not lines:
        return "No recent activity to recap."
    return "\n".join(lines)


def _responsibilities() -> str:
    me_data = graphql("query { me { id } }")
    me_id = me_data.get("me", {}).get("id")
    if not me_id:
        return json.dumps({"error": "Could not resolve current member"})

    data = graphql(
        """query($memberId: ID!) {
            memberResponsibilities(memberId: $memberId) {
                id title responsibilities ownedAreas
                reportingToId teamId updatedAt
            }
        }""",
        {"memberId": me_id},
    )
    resp: dict[str, Any] | None = data.get("memberResponsibilities")
    if not resp:
        return "No responsibilities defined for you yet. Ask an admin to set them via setMemberResponsibilities."

    lines: list[str] = ["=== Your Responsibilities ===\n"]
    if resp.get("title"):
        lines.append(f"**Role:** {resp['title']}")
    responsibilities: list[str] = resp.get("responsibilities", [])
    if responsibilities:
        lines.append("\n**Responsibilities:**")
        for r in responsibilities:
            lines.append(f"  - {r}")
    owned: list[str] = resp.get("ownedAreas", [])
    if owned:
        lines.append("\n**Owned areas:**")
        for a in owned:
            lines.append(f"  - {a}")
    if resp.get("updatedAt"):
        lines.append(f"\nLast updated: {resp['updatedAt']}")
    return "\n".join(lines)
