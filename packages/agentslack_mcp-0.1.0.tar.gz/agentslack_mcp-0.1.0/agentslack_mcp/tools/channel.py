"""Channel tool handlers."""

from __future__ import annotations

import json
from typing import Any

from .. import client
from ..client import coerce_attachments, graphql
from ..constants import DEFAULT_MESSAGE_LIMIT, DEFAULT_RECAP_LIMIT, DM_MSG_FIELDS, ISSUE_FIELDS, MSG_FIELDS
from ..formatting import fmt_issue, fmt_msg, fmt_paginated_messages


def dispatch_channel(action: str, args: dict[str, Any]) -> str:
    match action:
        case "list":
            return _list()
        case "read":
            return _read(args)
        case "thread":
            return _thread(args)
        case "send":
            return _send(args)
        case "mark_read":
            return _mark_read(args)
        case "info":
            return _info(args)
        case "pins":
            return _pins(args)
        case "pin":
            return _pin(args)
        case "unpin":
            return _unpin(args)
        case "thread_issues":
            return _thread_issues(args)
        case "search":
            return _search(args)
        case "catch_up":
            return _catch_up(args)
        case "add_team":
            return _add_team(args)
        case "remove_team":
            return _remove_team(args)
        case _:
            return json.dumps({"error": f"Unknown channel action: {action}"})


def _add_team(args: dict[str, Any]) -> str:
    """AS-341: attach a team to a channel — derived membership."""
    cid = args.get("channel_id")
    tid = args.get("team_id")
    if not cid or not tid:
        return json.dumps({"error": "channel_id and team_id are required"})
    data = graphql(
        """mutation($cid: ID!, $tid: ID!) {
            addTeamToChannel(channelId: $cid, teamId: $tid) { id name }
        }""",
        {"cid": cid, "tid": tid},
    )
    ch = data.get("addTeamToChannel", {}) or {}
    return f"Team attached to #{ch.get('name', '?')} ({ch.get('id', '?')})"


def _remove_team(args: dict[str, Any]) -> str:
    cid = args.get("channel_id")
    tid = args.get("team_id")
    if not cid or not tid:
        return json.dumps({"error": "channel_id and team_id are required"})
    data = graphql(
        """mutation($cid: ID!, $tid: ID!) {
            removeTeamFromChannel(channelId: $cid, teamId: $tid) { id name }
        }""",
        {"cid": cid, "tid": tid},
    )
    ch = data.get("removeTeamFromChannel", {}) or {}
    return f"Team detached from #{ch.get('name', '?')} ({ch.get('id', '?')})"


def _list() -> str:
    data = graphql(
        """query($orgId: ID!) { channels(orgId: $orgId) { id name slug description isArchived } }""",
        {"orgId": client.org_id},
    )
    channels: list[dict[str, Any]] = data.get("channels", [])
    if not channels:
        return "No channels found."
    lines = [f"{len(channels)} channel(s):\n"]
    for ch in channels:
        archived = " [archived]" if ch.get("isArchived") else ""
        desc = f" — {ch['description']}" if ch.get("description") else ""
        lines.append(f"- #{ch.get('name', '?')} ({ch['id']}){archived}{desc}")
    return "\n".join(lines)


def _read(args: dict[str, Any]) -> str:
    channel_id: str | None = args.get("channel_id")
    if not channel_id:
        return json.dumps({"error": "channel_id is required"})
    variables: dict[str, Any] = {
        "channelId": channel_id,
        "limit": args.get("limit", DEFAULT_MESSAGE_LIMIT),
    }
    if args.get("before_cursor"):
        variables["beforeCursor"] = args["before_cursor"]
    if args.get("after_cursor"):
        variables["afterCursor"] = args["after_cursor"]
    data = graphql(
        f"""query($channelId: ID!, $beforeCursor: String, $afterCursor: String, $limit: Int) {{
            channelMessages(channelId: $channelId, beforeCursor: $beforeCursor, afterCursor: $afterCursor, limit: $limit) {{
                edges {{ cursor node {{ {MSG_FIELDS} }} }}
                pageInfo {{ hasNextPage hasPreviousPage startCursor endCursor }}
            }}
        }}""",
        variables,
    )
    conn: dict[str, Any] = data.get("channelMessages", {})
    return fmt_paginated_messages(
        conn.get("edges", []),
        conn.get("pageInfo", {}),
        f"No messages in channel {channel_id}.",
    )


def _thread(args: dict[str, Any]) -> str:
    message_id: str | None = args.get("message_id")
    if not message_id:
        return json.dumps({"error": "message_id is required"})
    variables: dict[str, Any] = {
        "messageId": message_id,
        "limit": args.get("limit", DEFAULT_MESSAGE_LIMIT),
        "order": args.get("order", "desc"),
    }
    if args.get("before_cursor"):
        variables["beforeCursor"] = args["before_cursor"]
    if args.get("after_cursor"):
        variables["afterCursor"] = args["after_cursor"]
    data = graphql(
        f"""query($messageId: ID!, $limit: Int, $beforeCursor: String, $afterCursor: String, $order: String) {{
            threadMessages(messageId: $messageId, limit: $limit, beforeCursor: $beforeCursor, afterCursor: $afterCursor, order: $order) {{
                edges {{ cursor node {{ {MSG_FIELDS} }} }}
                pageInfo {{ hasNextPage hasPreviousPage startCursor endCursor }}
            }}
        }}""",
        variables,
    )
    conn = data.get("threadMessages", {})
    return fmt_paginated_messages(
        conn.get("edges", []),
        conn.get("pageInfo", {}),
        f"No thread replies for message {message_id}.",
    )


def _send(args: dict[str, Any]) -> str:
    channel_id: str | None = args.get("channel_id")
    content: str | None = args.get("content")
    if not channel_id or (not content and not args.get("attachments") and not args.get("gif_url")):
        return json.dumps({"error": "channel_id and (content or attachments/gif_url) are required"})
    variables: dict[str, Any] = {"channelId": channel_id, "content": content or ""}
    if args.get("thread_id"):
        variables["threadId"] = args["thread_id"]
    if args.get("await_response_secs") is not None:
        variables["awaitResponseSecs"] = int(args["await_response_secs"])
    attachments = coerce_attachments(args)
    if attachments:
        variables["attachments"] = attachments
    data = graphql(
        """mutation($channelId: ID!, $content: String!, $threadId: ID, $awaitResponseSecs: Int, $attachments: JSON) {
            sendMessage(input: { channelId: $channelId, content: $content, threadId: $threadId, awaitResponseSecs: $awaitResponseSecs, attachments: $attachments }) {
                id createdAt
            }
        }""",
        variables,
    )
    msg: dict[str, Any] = data.get("sendMessage", {})
    return f"Message sent (id: {msg.get('id', '?')})"


def _mark_read(args: dict[str, Any]) -> str:
    channel_id: str | None = args.get("channel_id")
    if not channel_id:
        return json.dumps({"error": "channel_id is required"})
    graphql(
        """mutation($channelId: ID!) { markChannelRead(channelId: $channelId) }""",
        {"channelId": channel_id},
    )
    return f"Channel {channel_id} marked as read."


def _info(args: dict[str, Any]) -> str:
    channel_id: str | None = args.get("channel_id")
    if not channel_id:
        return json.dumps({"error": "channel_id is required"})
    data = graphql(
        """query($id: ID!) {
            channel(id: $id) {
                id name slug description topic isArchived createdAt
                channelMembers { memberId role member { id displayName status } }
            }
        }""",
        {"id": channel_id},
    )
    ch: dict[str, Any] | None = data.get("channel")
    if not ch:
        return f"Channel {channel_id} not found."
    lines = [
        f"#{ch.get('name', '?')} ({ch['id']})",
        f"Description: {ch.get('description') or '(none)'}",
        f"Topic: {ch.get('topic') or '(none)'}",
        f"Archived: {ch.get('isArchived', False)}",
        f"Members ({len(ch.get('channelMembers', []))}):",
    ]
    for cm in ch.get("channelMembers", []):
        m: dict[str, Any] = cm.get("member", {})
        lines.append(
            f"  - {m.get('displayName', '?')} ({cm.get('memberId')}) "
            f"[{cm.get('role')}] {m.get('status', '')}"
        )
    return "\n".join(lines)


def _pins(args: dict[str, Any]) -> str:
    channel_id: str | None = args.get("channel_id")
    if not channel_id:
        return json.dumps({"error": "channel_id is required"})
    data = graphql(
        f"""query($channelId: ID!) {{
            pins(channelId: $channelId) {{
                id pinnedAt
                message {{ {MSG_FIELDS} }}
                pinner {{ id displayName }}
            }}
        }}""",
        {"channelId": channel_id},
    )
    pins: list[dict[str, Any]] = data.get("pins", [])
    if not pins:
        return f"No pins in channel {channel_id}."
    lines = [f"{len(pins)} pin(s):\n"]
    for p in pins:
        pinner = p.get("pinner", {}).get("displayName", "?")
        msg = p.get("message", {})
        lines.append(f"[pinned by {pinner} @ {p.get('pinnedAt', '?')}] {fmt_msg(msg)}")
    return "\n".join(lines)


def _pin(args: dict[str, Any]) -> str:
    channel_id: str | None = args.get("channel_id")
    message_id: str | None = args.get("message_id")
    if not channel_id or not message_id:
        return json.dumps({"error": "channel_id and message_id are required"})
    data = graphql(
        """mutation($channelId: ID!, $messageId: ID!) {
            pinMessage(channelId: $channelId, messageId: $messageId) { id }
        }""",
        {"channelId": channel_id, "messageId": message_id},
    )
    pin: dict[str, Any] = data.get("pinMessage") or {}
    return f"Pinned message {message_id} (pin id: {pin.get('id', '?')})."


def _unpin(args: dict[str, Any]) -> str:
    channel_id: str | None = args.get("channel_id")
    message_id: str | None = args.get("message_id")
    if not channel_id or not message_id:
        return json.dumps({"error": "channel_id and message_id are required"})
    data = graphql(
        """query($channelId: ID!) {
            pins(channelId: $channelId) { id messageId }
        }""",
        {"channelId": channel_id},
    )
    pin = next(
        (p for p in (data.get("pins") or []) if p.get("messageId") == message_id),
        None,
    )
    if not pin:
        return json.dumps({"error": f"No pin found for message {message_id} in channel {channel_id}"})
    graphql(
        """mutation($pinId: ID!) { unpinMessage(pinId: $pinId) }""",
        {"pinId": pin["id"]},
    )
    return f"Unpinned message {message_id}."


def _thread_issues(args: dict[str, Any]) -> str:
    message_id: str | None = args.get("message_id")
    if not message_id:
        return json.dumps({"error": "message_id is required"})
    data = graphql(
        f"""query($messageId: ID!) {{
            threadIssues(messageId: $messageId) {{ {ISSUE_FIELDS} }}
        }}""",
        {"messageId": message_id},
    )
    issues: list[dict[str, Any]] = data.get("threadIssues", [])
    if not issues:
        return f"No issues linked to message {message_id}."
    lines = [f"{len(issues)} linked issue(s):\n"]
    for issue in issues:
        lines.append(fmt_issue(issue))
    return "\n".join(lines)


def _search(args: dict[str, Any]) -> str:
    query: str | None = args.get("query")
    if not query:
        return json.dumps({"error": "query is required"})
    variables: dict[str, Any] = {
        "query": query,
        "limit": args.get("limit", DEFAULT_MESSAGE_LIMIT),
    }
    if args.get("channel_id"):
        variables["channelId"] = args["channel_id"]
    if args.get("author_id"):
        variables["authorId"] = args["author_id"]
    if args.get("after"):
        variables["after"] = args["after"]
    if args.get("before"):
        variables["before"] = args["before"]
    data = graphql(
        f"""query($query: String!, $channelId: ID, $authorId: ID, $after: String, $before: String, $limit: Int) {{
            searchMessages(query: $query, channelId: $channelId, authorId: $authorId, after: $after, before: $before, limit: $limit) {{
                message {{ {MSG_FIELDS} }}
                dmMessage {{ {DM_MSG_FIELDS} }}
                channelName
                dmMembers
            }}
        }}""",
        variables,
    )
    results: list[dict[str, Any]] = data.get("searchMessages", [])
    if not results:
        return "No messages found."
    lines = [f"{len(results)} result(s):\n"]
    for r in results:
        if r.get("message"):
            loc = f"#{r.get('channelName', '?')}"
            lines.append(f"[{loc}] {fmt_msg(r['message'])}")
        elif r.get("dmMessage"):
            members = ", ".join(r.get("dmMembers", []))
            lines.append(f"[DM: {members}] {fmt_msg(r['dmMessage'])}")
    return "\n".join(lines)


_CATCH_UP_PREVIEW_LEN = 200


def _truncate_content(msg: dict[str, Any]) -> dict[str, Any]:
    """Return a shallow copy of *msg* with content truncated for catch_up previews."""
    content = msg.get("content", "")
    if len(content) <= _CATCH_UP_PREVIEW_LEN:
        return msg
    return {**msg, "content": content[:_CATCH_UP_PREVIEW_LEN] + "…"}


def _catch_up(args: dict[str, Any]) -> str:
    data = graphql(
        f"""query($max: Int) {{
            catchUp(maxMessagesPerSource: $max) {{
                totalUnread
                channels {{
                    channelId channelName channelDescription unreadCount
                    recentMessages {{ {MSG_FIELDS} }}
                }}
                dms {{
                    dmChannelId unreadCount
                    otherMembers {{ id displayName }}
                    recentMessages {{ {DM_MSG_FIELDS} }}
                }}
            }}
        }}""",
        {"max": args.get("limit", DEFAULT_RECAP_LIMIT)},
    )
    cu: dict[str, Any] = data.get("catchUp", {})
    total: int = cu.get("totalUnread", 0)
    if total == 0:
        return "All caught up! No unread messages."
    lines = [f"Total unread: {total}\n"]
    for ch in cu.get("channels", []):
        unread: int = ch.get("unreadCount", 0)
        shown: list[dict[str, Any]] = ch.get("recentMessages", [])
        lines.append(f"--- #{ch.get('channelName', '?')} ({unread} unread) ---")
        for msg in shown:
            lines.append(f"  {fmt_msg(_truncate_content(msg))}")
        remaining = unread - len(shown)
        if remaining > 0:
            lines.append(f"  ... and {remaining} more unread message{'s' if remaining != 1 else ''}")
    for dm in cu.get("dms", []):
        unread = dm.get("unreadCount", 0)
        shown = dm.get("recentMessages", [])
        members = ", ".join(m.get("displayName", "?") for m in dm.get("otherMembers", []))
        lines.append(f"--- DM: {members} ({unread} unread) ---")
        for msg in shown:
            lines.append(f"  {fmt_msg(_truncate_content(msg))}")
        remaining = unread - len(shown)
        if remaining > 0:
            lines.append(f"  ... and {remaining} more unread message{'s' if remaining != 1 else ''}")
    return "\n".join(lines)
