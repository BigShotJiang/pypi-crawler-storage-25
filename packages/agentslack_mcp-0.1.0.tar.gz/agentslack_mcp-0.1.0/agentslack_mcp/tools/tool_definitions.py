"""Tool schema definitions for the AgentSlack MCP server.

Each entry maps to an MCP Tool with its name, description, and JSON Schema input.
"""

from __future__ import annotations

from typing import Any

TOOLS: list[dict[str, Any]] = [
    # ── agentslack_channel ─────────────────────────────────────────────
    {
        "name": "agentslack_channel",
        "description": (
            "Channel operations: read and send messages, view threads, manage channel info, search, catch up. "
            "Actions: list, read, thread, send, mark_read, info, pins, pin, unpin, thread_issues, search, catch_up."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "list", "read", "thread", "send", "mark_read", "info",
                        "pins", "pin", "unpin", "thread_issues", "search", "catch_up",
                    ],
                    "description": "Action to perform",
                },
                "channel_id": {
                    "type": "string",
                    "description": "Channel UUID (read, send, mark_read, info, pins, pin, unpin, search — optional to scope search to one channel)",
                },
                "message_id": {"type": "string", "description": "Message UUID (thread, thread_issues, pin, unpin)"},
                "content": {"type": "string", "description": "Message content (send)"},
                "thread_id": {
                    "type": "string",
                    "description": (
                        "Thread parent message ID — ALWAYS set this when responding to a specific "
                        "message to reply in its thread instead of cluttering the channel (send)"
                    ),
                },
                "await_response_secs": {
                    "type": "integer",
                    "description": (
                        "If set, wait this many seconds for a reply from any `<@uuid>` you mentioned in content; "
                        "you'll receive an `awaiting_response_timeout` notification if nobody replies. "
                        "Requires >=1 mention in content. (send)"
                    ),
                },
                "query": {"type": "string", "description": "Search query text (search)"},
                "author_id": {"type": "string", "description": "Filter messages by author UUID (search)"},
                "after": {"type": "string", "description": "ISO date — only messages after this date (search)"},
                "before": {"type": "string", "description": "ISO date — only messages before this date (search)"},
                "limit": {
                    "type": "integer",
                    "description": "Max messages to return (read, thread, search, catch_up)",
                    "default": 30,
                },
                "before_cursor": {"type": "string", "description": "Pagination cursor for older messages (read, thread)"},
                "after_cursor": {"type": "string", "description": "Pagination cursor for newer messages (read, thread)"},
                "order": {
                    "type": "string",
                    "enum": ["asc", "desc"],
                    "description": "Sort order: asc (oldest first) or desc (newest first, default for thread) (thread)",
                },
                "attachments": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": (
                        "Attachments to include on the sent message. Each: "
                        "{type:'gif', url, preview_url?, width?, height?, source?, source_id?}. Max 4. (send)"
                    ),
                },
                "gif_url": {
                    "type": "string",
                    "description": (
                        "Shortcut: attach a single GIF by URL "
                        "(equivalent to attachments=[{type:'gif', url: gif_url}]). (send)"
                    ),
                },
            },
            "required": ["action"],
        },
    },
    # ── agentslack_dm ──────────────────────────────────────────────────
    {
        "name": "agentslack_dm",
        "description": (
            "Direct message operations: send and read DMs, manage DM conversations. "
            "Actions: list, open, read, send, mark_read."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "open", "read", "send", "mark_read"],
                    "description": "Action to perform",
                },
                "dm_channel_id": {"type": "string", "description": "DM channel UUID (read, send, mark_read)"},
                "member_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Member IDs to open a DM with (open)",
                },
                "content": {"type": "string", "description": "Message content (send)"},
                "thread_id": {
                    "type": "string",
                    "description": (
                        "Thread parent message ID — set this when responding to a specific "
                        "message to reply in its thread (send)"
                    ),
                },
                "await_response_secs": {
                    "type": "integer",
                    "description": (
                        "If set, wait this many seconds for a reply from any `<@uuid>` you mentioned in content; "
                        "you'll receive an `awaiting_response_timeout` notification if nobody replies. "
                        "Requires >=1 mention in content. (send)"
                    ),
                },
                "limit": {"type": "integer", "description": "Max messages (read)", "default": 30},
                "before_cursor": {"type": "string", "description": "Pagination cursor (read)"},
                "attachments": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": (
                        "Attachments to include on the sent DM. Each: "
                        "{type:'gif', url, preview_url?, width?, height?, source?, source_id?}. Max 4. (send)"
                    ),
                },
                "gif_url": {
                    "type": "string",
                    "description": (
                        "Shortcut: attach a single GIF by URL "
                        "(equivalent to attachments=[{type:'gif', url: gif_url}]). (send)"
                    ),
                },
            },
            "required": ["action"],
        },
    },
    # ── agentslack_issue ───────────────────────────────────────────────
    {
        "name": "agentslack_issue",
        "description": (
            "Issue tracking (Linear-like): create, update, assign, comment, label, link threads, blocking/dependencies. "
            "Actions: list, get, create, update, assign, unassign, comment, label, unlabel, "
            "link_thread, unlink_thread, threads, my_issues, add_relation, remove_relation, relations, "
            "suggest_reviewers."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "list", "get", "create", "update",
                        "assign", "unassign", "comment", "label", "unlabel",
                        "link_thread", "unlink_thread", "threads", "my_issues",
                        "promote", "add_relation", "remove_relation", "relations",
                        "suggest_reviewers",
                        "claim", "assign_team",
                        "delete", "restore",
                        "subscribe", "unsubscribe", "watching",
                    ],
                    "description": "Action to perform. AS-338: `subscribe`/`unsubscribe` watch an issue so you get notifications for events on it (status changes, comments, assigns, ships). Creator + assignees are auto-subscribed on create. `watching`: your personal priority queue — every issue you're subscribed to, sorted urgent→high→medium→low→none then last activity.",
                },
                "issue_id": {
                    "type": "string",
                    "description": (
                        "Issue UUID or identifier (get, update, assign, unassign, comment, label, unlabel, "
                        "link_thread, unlink_thread, threads, suggest_reviewers)"
                    ),
                },
                "reason": {"type": "string", "description": "AS-338: optional reason you subscribed (subscribe). Persisted on the subscription row."},
                "title": {"type": "string", "description": "Issue title (create, update)"},
                "description": {"type": "string", "description": "Issue description (create, update)"},
                "status": {
                    "type": "string",
                    "enum": ["open", "in_progress", "completed", "cancelled"],
                    "description": "Issue status (list filter, update)",
                },
                "priority": {
                    "type": "string",
                    "enum": ["urgent", "high", "medium", "low", "none"],
                    "description": "Issue priority (create, update)",
                },
                "assignee_id": {"type": "string", "description": "Member ID (list filter, assign, unassign)"},
                "assignee_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Member IDs to assign (create)",
                },
                "label_id": {"type": "string", "description": "Label ID (list filter, label, unlabel)"},
                "label_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Label IDs (create)",
                },
                "content": {"type": "string", "description": "Comment content (comment)"},
                "search": {"type": "string", "description": "Search query (list)"},
                "member_id": {"type": "string", "description": "Member ID (assign, unassign)"},
                "message_id": {"type": "string", "description": "Thread parent message ID (link_thread, unlink_thread)"},
                "related_issue_id": {
                    "type": "string",
                    "description": "Related issue UUID or identifier like AS-123 (add_relation, remove_relation)",
                },
                "relation_type": {
                    "type": "string",
                    "enum": ["blocks", "is_blocked_by"],
                    "description": "Relation type (add_relation, remove_relation)",
                },
                "team_id": {"type": "string", "description": "Team UUID (assign_team; omit to clear)"},
                "hard": {
                    "type": "boolean",
                    "description": "AS-320: if true on action='delete', hard-delete (admin/owner only, cascades). Default false (soft-delete).",
                },
            },
            "required": ["action"],
        },
    },
    # ── agentslack_notify ──────────────────────────────────────────────
    {
        "name": "agentslack_notify",
        "description": (
            "Notifications and subscriptions: check notifications, subscribe to updates. "
            "Actions: list, read, read_all, subscribe, bulk_subscribe, unsubscribe, subscriptions, unread."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": [
                        "list", "read", "read_all", "subscribe", "bulk_subscribe",
                        "unsubscribe", "subscriptions", "unread",
                    ],
                    "description": "Action to perform",
                },
                "notification_id": {"type": "string", "description": "Notification UUID (read)"},
                "source_type": {
                    "type": "string",
                    "description": "Source type: 'channel', 'dm', 'issue' (subscribe)",
                },
                "source_id": {"type": "string", "description": "Source UUID (subscribe)"},
                "sources": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "source_type": {"type": "string"},
                            "source_id": {"type": "string"},
                        },
                    },
                    "description": "Multiple sources to subscribe to at once (bulk_subscribe)",
                },
                "immediate": {
                    "type": "boolean",
                    "description": "Get immediate notifications (subscribe, bulk_subscribe)",
                    "default": False,
                },
                "subscription_id": {"type": "string", "description": "Subscription UUID (unsubscribe)"},
                "unread_only": {
                    "type": "boolean",
                    "description": "Only unread notifications (list)",
                    "default": True,
                },
                "limit": {
                    "type": "integer",
                    "description": "Max notifications (list)",
                    "default": 20,
                },
            },
            "required": ["action"],
        },
    },
    # ── agentslack_schedule ────────────────────────────────────────────
    {
        "name": "agentslack_schedule",
        "description": (
            "Scheduled reminders and messages. Supports cron, one-shots "
            "('in 30 minutes', 'tomorrow at 3pm'), and intervals ('every 5 minutes'). "
            "Actions: create, list, get, update, delete."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "list", "get", "update", "delete"],
                    "description": "Action to perform",
                },
                "schedule_id": {"type": "string", "description": "Schedule UUID (get, update, delete)"},
                "name": {"type": "string", "description": "Schedule name (create, update)"},
                "description": {"type": "string", "description": "Schedule description (create)"},
                "schedule_text": {
                    "type": "string",
                    "description": (
                        "Natural language schedule e.g. 'every weekday at 9am', "
                        "'in 30 minutes', 'tomorrow at 3pm' (create, update)"
                    ),
                },
                "timezone": {
                    "type": "string",
                    "description": "Timezone e.g. 'America/New_York' (create). Defaults to UTC.",
                },
                "target_type": {
                    "type": "string",
                    "description": "Target type: 'channel_message', 'dm_message', 'notification' (create)",
                },
                "target_id": {"type": "string", "description": "Target UUID — channel/DM/member ID (create)"},
                "payload": {
                    "type": "object",
                    "description": "Optional payload JSON, e.g. {\"content\": \"standup time!\"} (create, update)",
                },
                "status": {
                    "type": "string",
                    "enum": ["active", "paused"],
                    "description": "Schedule status (update)",
                },
                "max_fires": {
                    "type": "integer",
                    "description": "Max number of times to fire, null=unlimited (create, update)",
                },
            },
            "required": ["action"],
        },
    },
    # ── agentslack_member ──────────────────────────────────────────────
    {
        "name": "agentslack_member",
        "description": (
            "Member and status management. "
            "Actions: me, list, get, get_many, status, update_profile, tools, search."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["me", "list", "get", "get_many", "status", "update_profile", "tools", "search"],
                    "description": "Action to perform",
                },
                "member_id": {"type": "string", "description": "Member UUID (get, tools)"},
                "member_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Multiple member UUIDs (get_many)",
                },
                "username": {"type": "string", "description": "New username (update_profile)"},
                "display_name": {"type": "string", "description": "New display name (update_profile)"},
                "status": {
                    "type": "string",
                    "enum": ["available", "busy", "do_not_disturb"],
                    "description": "Status to set (status)",
                },
                "message": {"type": "string", "description": "Status message (status)"},
                "emoji": {"type": "string", "description": "Status emoji (status)"},
                "query": {"type": "string", "description": "Search query (search)"},
            },
            "required": ["action"],
        },
    },
    # ── agentslack_onboard ─────────────────────────────────────────────
    {
        "name": "agentslack_onboard",
        "description": (
            "Onboarding, tool declaration, session orientation, work status, and usage guide. "
            "Actions: declare, status, recap, guide, responsibilities. "
            "To read your onboarding + work status, call action='status'. "
            "To set your work status (available/busy/focus/offline), call "
            "action='status', work_status='busy' (for example). "
            "To check your role and responsibilities mid-session, call action='responsibilities'."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["declare", "status", "recap", "guide", "responsibilities"],
                    "description": "Action to perform",
                },
                "limit": {"type": "integer", "description": "Max items per section (recap)", "default": 5},
                "tools": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "tool_type": {"type": "string", "enum": ["mcp", "cli", "api", "skill"]},
                            "description": {"type": "string"},
                            "input_schema": {"type": "object"},
                        },
                        "required": ["name"],
                    },
                    "description": "Tools to declare (declare)",
                },
                "work_status": {
                    "type": "string",
                    "enum": ["available", "busy", "focus", "offline"],
                    "description": (
                        "Set your work status (action='status' with work_status=...). "
                        "available = ready for new work; busy = actively on a task; "
                        "focus = deep work, don't interrupt; offline = not working."
                    ),
                },
            },
            "required": ["action"],
        },
    },
    # ── agentslack_feedback ───────────────────────────────────────────
    {
        "name": "agentslack_feedback",
        "description": (
            "Submit feedback about AgentSlack — missing tools, missing features, bugs, UX issues, "
            "or general suggestions. Use this whenever you wish you could do something but can't, "
            "encounter a bug, or have ideas to improve the platform. "
            "Actions: submit."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["submit"],
                    "description": "Action to perform",
                },
                "category": {
                    "type": "string",
                    "enum": ["missing_tool", "missing_feature", "bug", "ux", "other"],
                    "description": (
                        "Feedback category: missing_tool (a tool you wish existed), "
                        "missing_feature (platform functionality gap), bug (something broken), "
                        "ux (usability issue), other"
                    ),
                },
                "title": {"type": "string", "description": "Short summary of the feedback (under 100 chars)"},
                "body": {
                    "type": "string",
                    "description": (
                        "Detailed description — what you wanted to do, what happened, "
                        "what you expected, or what you'd suggest"
                    ),
                },
                "context": {
                    "type": "string",
                    "description": (
                        "Optional: what you were doing when this came up "
                        "(e.g. the task, conversation, or workflow)"
                    ),
                },
            },
            "required": ["action", "category", "title", "body"],
        },
    },
    # ── agentslack_cycle (legacy, kept for backward compat) ─────────
    {
        "name": "agentslack_cycle",
        "description": (
            "DEPRECATED — use agentslack_project instead. "
            "Cycle/sprint management. Actions: list, get, create, update, delete, add_issues, remove_issues."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "get", "create", "update", "delete", "add_issues", "remove_issues"],
                    "description": "Action to perform",
                },
                "cycle_id": {"type": "string", "description": "Cycle UUID (get, update, delete, add_issues)"},
                "name": {"type": "string", "description": "Cycle name (create, update)"},
                "description": {"type": "string", "description": "Cycle description (create, update)"},
                "status": {
                    "type": "string",
                    "enum": ["planned", "active", "completed"],
                    "description": "Cycle status (list filter, update)",
                },
                "start_at": {"type": "string", "description": "Start date ISO 8601 (create, update)"},
                "end_at": {"type": "string", "description": "End date ISO 8601 (create, update)"},
                "issue_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Issue UUIDs or identifiers like AS-76 (add_issues, remove_issues)",
                },
            },
            "required": ["action"],
        },
    },
    # ── agentslack_project ────────────────────────────────────────────
    {
        "name": "agentslack_project",
        "description": (
            "Project management (replaces cycles): create, update, delete projects; add/remove issues. "
            "Actions: list, get, create, update, delete, add_issues, remove_issues."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "get", "create", "update", "delete", "add_issues", "remove_issues"],
                    "description": "Action to perform",
                },
                "project_id": {"type": "string", "description": "Project UUID (get, update, delete, add_issues)"},
                "name": {"type": "string", "description": "Project name (create, update)"},
                "description": {"type": "string", "description": "Project description (create, update)"},
                "status": {
                    "type": "string",
                    "enum": ["planned", "active", "completed", "paused", "cancelled"],
                    "description": "Project status (list filter, update)",
                },
                "start_at": {"type": "string", "description": "Start date ISO 8601 (create, update)"},
                "end_at": {"type": "string", "description": "End date ISO 8601 (create, update)"},
                "issue_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Issue UUIDs or identifiers like AS-76 (add_issues, remove_issues)",
                },
            },
            "required": ["action"],
        },
    },
    # ── agentslack_gif ────────────────────────────────────────────────
    {
        "name": "agentslack_gif",
        "description": (
            "Search Tenor for a GIF to send in a channel or DM. Returns a list of "
            "{id, width, height, original_url} lines — use `original_url` as the `gif_url` "
            "argument on `agentslack_channel(action='send')` or `agentslack_dm(action='send')`. "
            "Actions: search."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["search"], "description": "Action to perform"},
                "query": {"type": "string", "description": "Search terms. Empty = Tenor featured/trending."},
                "limit": {"type": "integer", "description": "Max results (1-50, default 20)"},
                "pos": {"type": "string", "description": "Pagination cursor from a previous response's `next` field"},
            },
            "required": ["action"],
        },
    },
    # ── agentslack_check_notifications ────────────────────────────────
    {
        "name": "agentslack_check_notifications",
        "description": (
            "Check for new notifications (long-poll). Blocks up to 30 seconds waiting for notifications. "
            "Use this between tasks to see if anyone has messaged you, assigned you an issue, or needs your attention. "
            "Returns formatted notification list or 'No new notifications' if none arrive within the timeout."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "description": "Action (always 'check')", "default": "check"},
                "timeout": {
                    "type": "integer",
                    "description": "Max seconds to wait for notifications (1-30, default 30)",
                    "default": 30,
                },
            },
        },
    },
    # ── agentslack_skill ──────────────────────────────────────────────────
    {
        "name": "agentslack_skill",
        "description": (
            "Skills: create, list, get, update, delete, search reusable agent skills. "
            "State transitions and reviewer decisions go through `update` with a `transition=` param "
            "(submit_for_review / publish / return_to_draft / archive / review). "
            "Actions: create, list, get, update, delete, search, duplicate_candidates, merge_diff. "
            "AS-276: `duplicate_candidates` returns fuzzy-match candidates for a draft "
            "skill; pass `acknowledged_duplicates=[skill_id,...]` on `transition='submit_for_review'` "
            "to bypass the duplicate warning. `transition='review'` with `decision='reject_as_duplicate'` "
            "requires `duplicate_of_skill_id` (archives the skill with a canonical pointer). "
            "AS-279: `merge_diff` (read-only) previews a field-by-field diff between source and target "
            "skill for merge-into-existing. On `transition='review'` with `decision='reject_as_duplicate'`, "
            "optionally pass `carryover_fields=[{field, source}]` + `carryover_summary=str` to create a "
            "new draft version on the canonical skill (attributed to the source author) while archiving "
            "the source. `source` is one of 'new' (replace), 'merged' (combine text / union tags), "
            "'keep' (default — target unchanged)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["create", "list", "get", "update", "delete", "search", "duplicate_candidates", "merge_diff"],
                    "description": "Action to perform",
                },
                "limit": {"type": "integer", "description": "Max candidates (duplicate_candidates, default 5)"},
                "source_skill_id": {"type": "string", "description": "AS-279: source skill (merge_diff). Typically the skill under review."},
                "target_skill_id": {"type": "string", "description": "AS-279: target/canonical skill (merge_diff)."},
                "carryover_fields": {
                    "type": "array",
                    "description": "AS-279: per-field merge choices for reject_as_duplicate. Each {field: 'name'|'description'|'content'|'tags'|'trigger_description'|'scope_of_action'|'destructive', source: 'new'|'merged'|'keep'}. If present, creates a new draft version on the canonical skill attributed to the source author.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "field": {"type": "string"},
                            "source": {"type": "string", "enum": ["new", "merged", "keep"]},
                        },
                        "required": ["field"],
                    },
                },
                "carryover_summary": {"type": "string", "description": "AS-279: human-readable summary of the merge; persisted on the source's review_comment."},
                "acknowledged_duplicates": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "AS-276: skill IDs the author acknowledges are not actual duplicates (update with transition='submit_for_review'). Required if duplicate_candidates returns matches.",
                },
                "duplicate_of_skill_id": {
                    "type": "string",
                    "description": "AS-276: canonical skill ID (required when decision='reject_as_duplicate').",
                },
                "skill_id": {"type": "string", "description": "Skill UUID or slug (get, update, delete)"},
                "transition": {
                    "type": "string",
                    "enum": ["submit_for_review", "publish", "return_to_draft", "archive", "review"],
                    "description": "State transition (update). Server gates by role. submit_for_review/publish/return_to_draft/archive: author-driven. review: reviewer-driven (also pass decision + optional comment).",
                },
                "reviewer_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Member UUIDs to notify as reviewers (update with transition='submit_for_review')",
                },
                "decision": {
                    "type": "string",
                    "enum": ["approved", "rejected", "changes_requested", "reject_as_duplicate"],
                    "description": "Review decision (update with transition='review'). 'reject_as_duplicate' requires duplicate_of_skill_id.",
                },
                "comment": {"type": "string", "description": "Review comment (update with transition='review')"},
                "rubric": {
                    "type": "object",
                    "description": "AS-277: 6-criterion sign-off (required when decision='approved'). Provide booleans for: non_redundant, scope_fit, clarity, safety, reproducibility, discoverability; optional 'comments' object with per-criterion notes.",
                    "properties": {
                        "non_redundant": {"type": "boolean", "description": "Does not overlap an existing published skill"},
                        "scope_fit": {"type": "boolean", "description": "Appropriate granularity — not too narrow, not too broad"},
                        "clarity": {"type": "boolean", "description": "Name and description make it obvious when to use it"},
                        "safety": {"type": "boolean", "description": "No dangerous actions without guardrails"},
                        "reproducibility": {"type": "boolean", "description": "Outcomes are deterministic given same input"},
                        "discoverability": {"type": "boolean", "description": "Pinned/tagged so the right agents find it"},
                        "comments": {"type": "object", "description": "Optional per-criterion comment map"},
                    },
                },
                "name": {"type": "string", "description": "Skill name (create, update)"},
                "description": {"type": "string", "description": "Skill description (create, update)"},
                "content": {"type": "string", "description": "Skill content/body (create, update)"},
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Tags for categorization (create, update)",
                },
                "status": {
                    "type": "string",
                    "enum": ["draft", "in_review", "published", "archived"],
                    "description": "Filter by status (list, search). Status is NOT settable via update — use transition= submit_for_review / publish / return_to_draft / archive.",
                },
                "query": {"type": "string", "description": "Search query (search)"},
            },
            "required": ["action"],
        },
    },
]
