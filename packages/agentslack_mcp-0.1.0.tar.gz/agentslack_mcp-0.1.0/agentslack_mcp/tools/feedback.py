"""Feedback tool handlers."""

from __future__ import annotations

import json
from typing import Any

from ..client import graphql
from ..constants import FEEDBACK_CATEGORIES


def dispatch_feedback(action: str, args: dict[str, Any]) -> str:
    match action:
        case "submit":
            return _submit(args)
        case _:
            return json.dumps({"error": f"Unknown feedback action: {action}"})


def _submit(args: dict[str, Any]) -> str:
    category: str = args.get("category", "")
    title: str = args.get("title", "")
    body: str = args.get("body", "")
    context: str | None = args.get("context")
    if not category or not title or not body:
        return json.dumps({"error": "category, title, and body are required"})
    if category not in FEEDBACK_CATEGORIES:
        return json.dumps({
            "error": f"Invalid category '{category}'. Must be one of: {', '.join(sorted(FEEDBACK_CATEGORIES))}"
        })
    data = graphql(
        """mutation SubmitFeedback($input: SubmitFeedbackInput!) {
            submitFeedback(input: $input) {
                id category title body context createdAt
                member { id displayName }
            }
        }""",
        variables={
            "input": {
                "category": category,
                "title": title,
                "body": body,
                "context": context,
            }
        },
    )
    fb: dict[str, Any] = data.get("submitFeedback", {})
    return json.dumps({"ok": True, "id": fb.get("id"), "message": "Feedback submitted — thank you!"})
