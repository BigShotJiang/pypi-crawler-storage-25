"""Shared formatting helpers for converting GraphQL results to human-readable text."""

from __future__ import annotations

from typing import Any


def fmt_msg(msg: dict[str, Any]) -> str:
    """Format a single message dict into a compact one-line string."""
    author_obj = msg.get("author") or {}
    author = author_obj.get("displayName", "unknown")
    author_type = author_obj.get("type")
    type_tag = f" [{author_type}]" if author_type else ""
    ts = msg.get("createdAt", "?")
    content = msg.get("content", "")
    msg_id = msg.get("id", "")
    id_tag = f" (id: {msg_id})" if msg_id else ""
    reply_count: int = msg.get("replyCount") or 0
    thread_info = ""
    if reply_count:
        participants: list[dict[str, Any]] = msg.get("threadParticipants", [])
        names = ", ".join(p.get("displayName", "?") for p in participants)
        thread_info = (
            f" ({reply_count} replies — {names})" if names else f" ({reply_count} replies)"
        )
    return f"[{author}{type_tag} @ {ts}]{id_tag}{thread_info}: {content}"


def fmt_issue(issue: dict[str, Any]) -> str:
    """Format a single issue dict into a compact one-line string."""
    assignees = ", ".join(
        a.get("displayName", a.get("id", "?")) for a in issue.get("assignees", [])
    ) or "unassigned"
    labels = ", ".join(lbl.get("name", "?") for lbl in issue.get("labels", []))
    label_str = f" [{labels}]" if labels else ""
    issue_id = issue.get("id", "")
    id_tag = f" (id: {issue_id})" if issue_id else ""
    return (
        f"- {issue.get('identifier', '?')}{id_tag}: {issue.get('title', '?')} "
        f"({issue.get('status', '?')}/{issue.get('priority', '?')}) "
        f"→ {assignees}{label_str}"
    )


def fmt_cycle(cycle: dict[str, Any]) -> str:
    """Format a single cycle dict into a compact one-line string."""
    status = cycle.get("status", "?")
    start = cycle.get("startAt") or "unset"
    end = cycle.get("endAt") or "unset"
    creator = (cycle.get("createdBy") or {}).get("displayName", "?")
    return (
        f"- {cycle.get('name', '?')} (id: {cycle.get('id', '?')}) "
        f"[{status}] {start} → {end} (by {creator})"
    )


def fmt_project(project: dict[str, Any]) -> str:
    """Format a single project dict into a compact one-line string."""
    status = project.get("status", "?")
    start = project.get("startAt") or "unset"
    end = project.get("endAt") or "unset"
    creator = (project.get("createdBy") or {}).get("displayName", "?")
    return (
        f"- {project.get('name', '?')} (id: {project.get('id', '?')}) "
        f"[{status}] {start} → {end} (by {creator})"
    )


def fmt_paginated_messages(
    edges: list[dict[str, Any]],
    page_info: dict[str, Any],
    empty_label: str,
) -> str:
    """Format a paginated list of message edges with cursor info."""
    if not edges:
        return empty_label
    lines = [f"{len(edges)} message(s):\n"]
    for edge in edges:
        lines.append(fmt_msg(edge["node"]))
    if page_info.get("hasNextPage"):
        lines.append(
            f"\n(older messages available — use before_cursor: {page_info.get('endCursor')})"
        )
    if page_info.get("hasPreviousPage"):
        lines.append(
            f"\n(newer messages available — use after_cursor: {page_info.get('startCursor')})"
        )
    return "\n".join(lines)
