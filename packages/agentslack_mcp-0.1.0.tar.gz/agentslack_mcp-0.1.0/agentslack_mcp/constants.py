"""Shared constants for the AgentSlack MCP server."""

from __future__ import annotations

import re

# ---------------------------------------------------------------------------
# Timeouts (seconds)
# ---------------------------------------------------------------------------

GRAPHQL_TIMEOUT_S: int = 15
HTTP_TIMEOUT_S: int = 10
NOTIFICATION_STREAM_TIMEOUT_S: int = 30
NOTIFICATION_CLIENT_TIMEOUT_S: int = 35  # slightly > stream timeout

# ---------------------------------------------------------------------------
# Polling
# ---------------------------------------------------------------------------

POLL_INTERVAL_S: int = 3

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

DEFAULT_API_URL: str = "http://localhost:8100"
DEFAULT_MESSAGE_LIMIT: int = 30
DEFAULT_NOTIFICATION_LIMIT: int = 20
DEFAULT_RECAP_LIMIT: int = 5
DEFAULT_GIF_LIMIT: int = 20
MAX_GIF_LIMIT: int = 50

# ---------------------------------------------------------------------------
# GraphQL field fragments
# ---------------------------------------------------------------------------

MSG_FIELDS: str = (
    "id content authorId createdAt "
    "author { id displayName type } "
    "replyCount latestReplyAt "
    "threadParticipants { id displayName }"
)

DM_MSG_FIELDS: str = (
    "id dmChannelId content authorId createdAt "
    "author { id displayName type } "
    "replyCount latestReplyAt"
)

ISSUE_FIELDS: str = (
    "id identifier title description status priority "
    "createdBy { id displayName } createdAt updatedAt completedAt "
    "assignees { id displayName } "
    "labels { id name color }"
)

CYCLE_FIELDS: str = (
    "id orgId name description status startAt endAt "
    "createdBy { id displayName } createdAt updatedAt"
)

PROJECT_FIELDS: str = (
    "id orgId name description status startAt endAt "
    "createdBy { id displayName } createdAt updatedAt"
)

# ---------------------------------------------------------------------------
# Patterns
# ---------------------------------------------------------------------------

UUID_RE: re.Pattern[str] = re.compile(
    r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Feedback
# ---------------------------------------------------------------------------

FEEDBACK_CATEGORIES: frozenset[str] = frozenset(
    {"missing_tool", "missing_feature", "bug", "ux", "other"}
)

# ---------------------------------------------------------------------------
# Work status
# ---------------------------------------------------------------------------

WORK_STATUSES: frozenset[str] = frozenset(
    {"available", "busy", "focus", "offline"}
)
