"""HTTP client and GraphQL helper for the AgentSlack API."""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx

from .constants import DEFAULT_API_URL, GRAPHQL_TIMEOUT_S, HTTP_TIMEOUT_S, UUID_RE

log = logging.getLogger("agentslack-mcp")

# ---------------------------------------------------------------------------
# Module-level state (populated by auth)
# ---------------------------------------------------------------------------

_api_url: str = ""
_api_key: str = ""
member_id: str = ""
org_id: str = ""
member_timezone: str = "UTC"


def get_api_url() -> str:
    global _api_url
    if not _api_url:
        _api_url = os.environ.get("AGENTSLACK_API_URL", DEFAULT_API_URL).rstrip("/")
    return _api_url


def get_api_key() -> str:
    global _api_key
    if not _api_key:
        _api_key = os.environ.get("AGENTSLACK_API_KEY", "")
        if not _api_key:
            raise ValueError("AGENTSLACK_API_KEY environment variable is required")
    return _api_key


def headers() -> dict[str, str]:
    return {
        "X-API-Key": get_api_key(),
        "Content-Type": "application/json",
    }


def graphql(query: str, variables: dict[str, Any] | None = None) -> dict[str, Any]:
    """Execute a synchronous GraphQL query against the AgentSlack server."""
    payload: dict[str, Any] = {"query": query}
    if variables:
        payload["variables"] = variables
    resp = httpx.post(
        f"{get_api_url()}/graphql",
        headers=headers(),
        json=payload,
        timeout=GRAPHQL_TIMEOUT_S,
    )
    resp.raise_for_status()
    data: dict[str, Any] = resp.json()
    if data.get("errors"):
        raise RuntimeError(data["errors"][0].get("message", str(data["errors"])))
    return data.get("data", {})


def coerce_attachments(args: dict[str, Any]) -> list[dict[str, Any]] | None:
    """Normalize attachments + gif_url shortcut into a list for GraphQL."""
    items: list[dict[str, Any]] = []
    raw = args.get("attachments")
    if isinstance(raw, list):
        items.extend(a for a in raw if isinstance(a, dict))
    gif_url = args.get("gif_url")
    if isinstance(gif_url, str) and gif_url:
        items.append({"type": "gif", "url": gif_url})
    return items or None


def resolve_skill_id(skill_id: str) -> str:
    """Accept either a UUID or a slug/name and return the UUID.

    Raises ``ValueError`` if the identifier cannot be resolved.
    """
    if not skill_id:
        raise ValueError("skill_id is required")
    if UUID_RE.match(skill_id):
        return skill_id
    data = graphql(
        """query($orgId: ID!, $search: String) {
            skills(orgId: $orgId, search: $search) { id slug name }
        }""",
        {"orgId": org_id, "search": skill_id},
    )
    skills: list[dict[str, Any]] = data.get("skills", [])
    target = skill_id.lower()
    for s in skills:
        if s.get("slug", "").lower() == target or s.get("name", "").lower() == target:
            return s["id"]
    raise ValueError(f"Skill '{skill_id}' not found")


def resolve_issue_id(issue_id: str) -> str:
    """Accept either a UUID or a human identifier (e.g. 'AS-7') and return the UUID.

    Raises ``ValueError`` if the identifier cannot be resolved.
    """
    if not issue_id:
        raise ValueError("issue_id is required")
    if UUID_RE.match(issue_id):
        return issue_id
    # Treat as a human identifier -- search for it
    data = graphql(
        """query($orgId: ID!, $search: String) {
            issues(orgId: $orgId, search: $search) { id identifier }
        }""",
        {"orgId": org_id, "search": issue_id},
    )
    issues: list[dict[str, Any]] = data.get("issues", [])
    target = issue_id.lower()
    for i in issues:
        if i.get("identifier", "").lower() == target:
            return i["id"]
    raise ValueError(f"Issue '{issue_id}' not found")


def auth() -> dict[str, str]:
    """Fetch identity via GraphQL ``{ me { ... } }``.

    Session-start is detected server-side by the heartbeat in the
    notification poll/stream endpoints, so no dedicated auth call is needed.
    """
    global member_id, org_id, member_timezone
    resp = httpx.post(
        f"{get_api_url()}/graphql",
        headers=headers(),
        json={"query": "{ me { id orgId displayName timezone } }"},
        timeout=HTTP_TIMEOUT_S,
    )
    resp.raise_for_status()
    gql: dict[str, Any] = resp.json()
    me: dict[str, Any] | None = (gql.get("data") or {}).get("me")
    if not me:
        errors = gql.get("errors", [])
        detail = errors[0]["message"] if errors else "unauthorized"
        raise ValueError(f"GraphQL me query failed: {detail}")

    member_id = me.get("id", "")
    org_id = me.get("orgId", "")
    member_timezone = me.get("timezone", "UTC")
    display_name = me.get("displayName", "unknown")

    return {"member_id": member_id, "org_id": org_id, "display_name": display_name}
