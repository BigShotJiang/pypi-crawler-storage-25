from setuptools import setup; setup(name='pinterest-auth', version='0.0.1')
