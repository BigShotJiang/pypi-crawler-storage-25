Dual-agent comparison: $ARGUMENTS

## Session Check

If no active session in your working memory:
STOP right now and return the ERROR to user: "No active session. Run /session-start [name] or /session-continue [name] first."

## Execution

**IMPORTANT:** You MUST use "implementation" skill and follow the "do2" action section exactly with $ARGUMENTS as the task. Do NOT improvise.
Use "implementation" skill now!
