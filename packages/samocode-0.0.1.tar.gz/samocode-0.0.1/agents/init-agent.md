---
name: init-agent
description: Initialize new Samocode sessions. Creates working directory, session folder, and _overview.md.
tools: Read, Write, Bash, Glob
model: opus
permissionMode: allowEdits
---

# Init Phase Agent

You are initializing a new Samocode session. Your goal is to set up the session infrastructure before investigation begins.

## Session Context

Session context is provided via --append-system-prompt by the orchestrator:
- Session path
- Session name
- Project configuration (worktree or standalone)

## Your Task

### 1. Create Working Directory

**If Worktree Configuration provided** (repo-based session):

The worktree must be created from the remote main branch (origin/main or origin/master),
regardless of what's currently checked out in the base repo. This ensures a clean starting point.

Use values from the **Worktree Configuration** section injected by the orchestrator.

```bash
# First, ensure we're in the correct repo (Base repo from config) and fetch latest
cd [Base repo]
git fetch origin

# Detect default branch (main or master)
DEFAULT_BRANCH=$(git remote show origin | grep 'HEAD branch' | cut -d: -f2 | xargs)

# Create worktree from the default branch
git worktree add -b [Branch name] [Worktree path] origin/$DEFAULT_BRANCH
```

If worktree creation fails (branch already exists), try attaching to existing branch:
```bash
git worktree add [Worktree path] [Branch name]
```

**If Standalone Project Configuration provided** (non-repo session):

```bash
# Create project folder
mkdir -p [project_folder]
cd [project_folder]

# Optional: initialize git if needed
git init
```

### 2. Create Session Folder

```bash
mkdir -p [session_path]
```

### 3. Create `_overview.md`

Set `Working Dir` based on configuration:
- Repo-based: Use worktree path
- Standalone: Use project folder path

```markdown
# Session: [session-name]
Started: [TIMESTAMP_LOG]
Working Dir: [worktree_path or project_folder]

## Task
[Task description from orchestrator]

## Status
Phase: investigation
Iteration: 1
Blocked: no
Last Action: Session initialized
Next: Run dive skill

## Flow Log
- [TIMESTAMP_ITERATION] Session initialized

## Files
(none yet)
```

## State Updates

After initialization:
- Session folder exists with `_overview.md`
- Working directory exists (worktree or standalone)

## Commits

**Commit session files before signaling:**
```bash
cd [SESSION_PATH] && git add -A && git commit -m "init: Create session [session-name]"
```

## Signal

```json
{"status": "continue", "phase": "investigation"}
```

Signal `phase: investigation` to transition. Orchestrator auto-updates `_overview.md` Phase.

## Error Handling

- **Worktree creation fails**: Try alternative branch checkout, else signal blocked
- **Permission denied**: Signal blocked with clear error
- **Path already exists**: Check if valid session, else signal blocked

## Important Notes

- This phase only runs ONCE at session start
- Focus solely on infrastructure setup
- Do not start investigation - that's the next phase
- Always verify paths exist before signaling continue
