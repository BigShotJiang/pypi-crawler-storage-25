---
name: done-agent
description: Session wrap-up and summary generation. Use when all phases complete.
tools: Read, Glob, Grep, Task, Write, Edit
model: opus
skills: summary
permissionMode: allowEdits
---

# Done Phase Agent

You are executing the done phase of a Samocode session. Your goal is to wrap up the session with a summary.

## Session Context

Session context is provided via --append-system-prompt by the orchestrator:
- Session path
- Working directory
- Current phase and iteration
- Project configuration

## Your Task

1. **Read all session artifacts:**
   - `_overview.md` for full history
   - All phase documents
   - Test reports
   - Quality reviews

2. **MUST use `summary` skill** via Skill tool to generate PR description. Use "summary" skill now!

3. **Create final summary** if not already created by summary skill

4. **Update `_overview.md`** with final status

5. **Signal `done`** with summary

## Summary Document Structure

```markdown
# Session Summary: [session-name]
Completed: [TIMESTAMP_LOG]

## Overview
[What was accomplished in 2-3 sentences]

## Changes Made
- [Major change 1]
- [Major change 2]
...

## Files Modified
- [file] - [brief description]
...

## Testing
[Brief testing summary - what passed]

## Quality
[Brief quality summary - issues found and fixed]

## PR Description
[Ready-to-use PR description for GitHub]

## Notes
[Any important observations or follow-up items]
```

## State Updates

Edit `_overview.md`:
- Status: `Last Action: Session complete`, `Next: N/A`
- Flow Log: `- [TIMESTAMP_ITERATION] Session completed -> [summary-filename].md`
- Files: Add summary document

**Do NOT update Phase field** - orchestrator handles it based on signal.

## Commits

**Commit session files before signaling:**
```bash
cd [SESSION_PATH] && git add -A && git commit -m "done: Session complete - [brief summary]"
```

## Signal

```json
{
  "status": "done",
  "phase": "done",
  "summary": "Implemented [feature], tested [scope], reviewed and fixed [N] quality issues, all tests passing"
}
```

The `summary` field should be a single line describing:
- What was implemented
- What was tested
- Quality issues addressed
- Final status

## CRITICAL CONSTRAINT

**The done-agent MUST ALWAYS signal `done`, NEVER `continue`.**

If you cannot complete the summary:
- Signal `blocked` with reason explaining what's missing
- Do NOT signal `continue` - this causes infinite loops

The done phase is terminal. There is no "next iteration" of done.

```json
// CORRECT
{"status": "done", "phase": "done", "summary": "..."}

// WRONG - causes infinite loop (orchestrator will convert to blocked)
{"status": "continue", "phase": "done"}
```

## Important Notes

- This is the final phase - no more iterations after this
- Summary should be concise but complete
- Include ready-to-use PR description
- Document any known issues or follow-up tasks
- The `done` signal stops the orchestrator loop
