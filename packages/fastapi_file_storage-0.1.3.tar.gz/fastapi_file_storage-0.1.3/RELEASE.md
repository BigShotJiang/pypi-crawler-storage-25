# fastapi-file-storage 发布流程

本文档说明如何把 `fastapi-file-storage` 发布到 TestPyPI / PyPI。

## 1. 准备

- 确认测试通过
- 确认版本号将要递增（`pyproject.toml` 的 `[project].version`）
- 准备 PyPI Token（推荐）

## 2. 安装发布工具

```bash
python3 -m pip install --upgrade build twine
```

## 3. 本地验证

```bash
python3 -m pytest tests
```

## 4. 更新版本号

编辑 `pyproject.toml`：

```toml
[project]
version = "0.1.2"
```

如果本次发布新增 CLI，请同时确认脚本入口已存在：

```toml
[project.scripts]
fastapi-storage = "fastapi_storage.cli:main"
```

## 5. 构建分发包

```bash
rm -rf dist build *.egg-info
python3 -m build
```

构建完成后应看到：
- `dist/fastapi_storage-<version>.tar.gz`
- `dist/fastapi_storage-<version>-py3-none-any.whl`

## 6. 检查包元数据

```bash
python3 -m twine check dist/*
```

## 7. 先发 TestPyPI（推荐）

```bash
python3 -m twine upload --repository testpypi dist/*
```

然后验证安装：

```bash
python3 -m pip install \
  --index-url https://test.pypi.org/simple/ \
  --extra-index-url https://pypi.org/simple \
  fastapi-file-storage==<version>
```

## 8. 发布到 PyPI

```bash
python3 -m twine upload dist/*
```

## 9. 推荐认证方式（Token）

可以使用环境变量：

```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-xxxxxxxxxxxxxxxx
```

也可使用 `~/.pypirc`（注意权限和安全）。

## 10. 发布后检查

- PyPI 页面是否展示正确 README
- 新版本是否可安装
- 快速 smoke test：

```bash
python3 -c "from fastapi_storage import Storage; print(Storage)"
```

## 11. 常见问题

### README 不显示

- 确认 `pyproject.toml` 包含：

```toml
[project]
readme = "README.md"
```

### 上传冲突（版本已存在）

- PyPI 不允许覆盖同版本
- 递增版本号后重新构建再上传

### 包内容不全

- 确认 `hatchling` 打包配置：

```toml
[tool.hatch.build.targets.wheel]
packages = ["src/fastapi_storage"]
```
