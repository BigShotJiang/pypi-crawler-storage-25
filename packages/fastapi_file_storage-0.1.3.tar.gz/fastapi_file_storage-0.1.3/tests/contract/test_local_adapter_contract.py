from pathlib import Path

import pytest

from fastapi_storage.adapters.local import LocalAdapter
from fastapi_storage.config.models import LocalDiskConfig


@pytest.fixture
def adapter(tmp_path: Path) -> LocalAdapter:
    config = LocalDiskConfig(root=str(tmp_path), url="/storage")
    return LocalAdapter(config)


def test_local_adapter_contract(adapter: LocalAdapter, tmp_path: Path) -> None:
    source = tmp_path / "source.txt"
    source.write_text("world")

    assert adapter.put("a/test.txt", "hello") is True
    assert adapter.fput("a/from-file.txt", source) is True
    assert adapter.exists("a/test.txt") is True
    assert adapter.exists("a/from-file.txt") is True
    assert adapter.get("a/test.txt") == b"hello"
    assert adapter.get("a/from-file.txt") == b"world"
    assert adapter.size("a/test.txt") == 5
    assert adapter.url("a/test.txt") == "/storage/a/test.txt"
    assert adapter.internal_url("a/test.txt") == "/storage/a/test.txt"

    assert adapter.copy("a/test.txt", "a/copy.txt") is True
    assert adapter.exists("a/copy.txt") is True

    assert adapter.move("a/copy.txt", "a/moved.txt") is True
    assert adapter.exists("a/copy.txt") is False
    assert adapter.exists("a/moved.txt") is True

    assert adapter.delete(["a/test.txt", "a/from-file.txt", "a/moved.txt"]) is True
