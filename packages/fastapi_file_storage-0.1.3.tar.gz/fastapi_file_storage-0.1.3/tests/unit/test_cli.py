import tempfile
from pathlib import Path

from fastapi_storage import cli


def test_cli_init_creates_files() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        config_path = base / "src/config/filesystems.py"
        env_path = base / ".env.example"

        code = cli.main([
            "init",
            "--config-path",
            str(config_path),
            "--env-path",
            str(env_path),
        ])

        assert code == 0
        assert config_path.exists()
        assert env_path.exists()


def test_cli_init_skip_existing_without_force() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        config_path = base / "src/config/filesystems.py"
        env_path = base / ".env.example"

        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("old", encoding="utf-8")
        env_path.write_text("old", encoding="utf-8")

        code = cli.main([
            "init",
            "--config-path",
            str(config_path),
            "--env-path",
            str(env_path),
        ])

        assert code == 0
        assert config_path.read_text(encoding="utf-8") == "old"
        assert env_path.read_text(encoding="utf-8") == "old"


def test_cli_init_force_overwrites() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        config_path = base / "src/config/filesystems.py"
        env_path = base / ".env.example"

        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("old", encoding="utf-8")
        env_path.write_text("old", encoding="utf-8")

        code = cli.main([
            "init",
            "--force",
            "--config-path",
            str(config_path),
            "--env-path",
            str(env_path),
        ])

        assert code == 0
        assert "class Filesystems" in config_path.read_text(encoding="utf-8")
        assert "STORAGE_DEFAULT=local" in env_path.read_text(encoding="utf-8")


def test_cli_init_skip_both_returns_without_files() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        config_path = base / "src/config/filesystems.py"
        env_path = base / ".env.example"

        code = cli.main([
            "init",
            "--skip-config",
            "--skip-env",
            "--config-path",
            str(config_path),
            "--env-path",
            str(env_path),
        ])

        assert code == 0
        assert not config_path.exists()
        assert not env_path.exists()


def test_cli_storage_link_creates_symlink() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        link_path = base / "public/storage"
        target_path = base / "storage/app/public"

        code = cli.main([
            "storage:link",
            "--link",
            str(link_path),
            "--target",
            str(target_path),
        ])

        assert code == 0
        assert link_path.is_symlink()
        assert link_path.resolve() == target_path.resolve()


def test_cli_storage_link_conflict_returns_error() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        link_path = base / "public/storage"
        target_path = base / "storage/app/public"

        link_path.mkdir(parents=True, exist_ok=True)

        code = cli.main([
            "storage:link",
            "--force",
            "--link",
            str(link_path),
            "--target",
            str(target_path),
        ])

        assert code == 1


def test_cli_link_alias_creates_symlink() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        link_path = base / "public/storage"
        target_path = base / "storage/app/public"

        code = cli.main([
            "link",
            "--link",
            str(link_path),
            "--target",
            str(target_path),
        ])

        assert code == 0
        assert link_path.is_symlink()
        assert link_path.resolve() == target_path.resolve()
