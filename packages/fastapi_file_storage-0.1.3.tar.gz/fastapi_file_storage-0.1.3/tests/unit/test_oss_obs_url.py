from fastapi_storage.adapters.obs import ObsAdapter
from fastapi_storage.adapters.oss import OssAdapter
from fastapi_storage.config.models import ObsDiskConfig, OssDiskConfig


class Dummy:
    pass


def test_oss_url_config_without_scheme_defaults_to_https() -> None:
    config = OssDiskConfig(
        endpoint="oss-cn-hangzhou.aliyuncs.com",
        access_key="ak",
        secret_key="sk",
        bucket="my-bucket",
        url="cdn.example.com/storage",
    )
    adapter = OssAdapter(config, client=Dummy())
    assert adapter.url("a/b.txt") == "https://cdn.example.com/storage/a/b.txt"


def test_oss_cdn_domain_without_scheme_defaults_to_https() -> None:
    config = OssDiskConfig(
        endpoint="oss-cn-hangzhou.aliyuncs.com",
        access_key="ak",
        secret_key="sk",
        bucket="my-bucket",
        cdn_domain="cdn.example.com",
    )
    adapter = OssAdapter(config, client=Dummy())
    assert adapter.url("a/b.txt") == "https://cdn.example.com/a/b.txt"


def test_obs_url_config_without_scheme_defaults_to_https() -> None:
    config = ObsDiskConfig(
        server="obs.cn-east-3.myhuaweicloud.com",
        access_key_id="ak",
        secret_access_key="sk",
        bucket="my-bucket",
        url="obs.example.com/base",
    )
    adapter = ObsAdapter(config, client=Dummy())
    assert adapter.url("a/b.txt") == "https://obs.example.com/base/a/b.txt"


def test_oss_obs_url_empty_path_returns_empty_string() -> None:
    oss_config = OssDiskConfig(
        endpoint="oss-cn-hangzhou.aliyuncs.com",
        access_key="ak",
        secret_key="sk",
        bucket="my-bucket",
        url="cdn.example.com/storage",
    )
    obs_config = ObsDiskConfig(
        server="obs.cn-east-3.myhuaweicloud.com",
        access_key_id="ak",
        secret_access_key="sk",
        bucket="my-bucket",
        url="obs.example.com/base",
    )

    assert OssAdapter(oss_config, client=Dummy()).url("") == ""
    assert ObsAdapter(obs_config, client=Dummy()).url("") == ""
