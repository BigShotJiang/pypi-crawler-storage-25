import pytest

from fastapi_storage.adapters.base import PathPrefixer


def test_prefix_path_with_root() -> None:
    prefixer = PathPrefixer("storage/app")
    assert prefixer.prefix_path("avatars/a.png") == "storage/app/avatars/a.png"


def test_prefix_path_with_empty_path() -> None:
    prefixer = PathPrefixer("storage/app")
    assert prefixer.prefix_path("") == "storage/app"


def test_prefix_path_without_root() -> None:
    prefixer = PathPrefixer("")
    assert prefixer.prefix_path("avatars/a.png") == "avatars/a.png"
