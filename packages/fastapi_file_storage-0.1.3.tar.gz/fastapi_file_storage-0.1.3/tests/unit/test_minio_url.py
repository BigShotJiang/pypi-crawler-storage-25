from fastapi_storage.adapters.minio import MinioAdapter
from fastapi_storage.config.models import MinioDiskConfig


class DummyMinioClient:
    pass


def test_minio_url_uses_domain_when_present() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        domain="minio.example.com",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())
    assert adapter.url("audio/a.mp3") == "https://minio.example.com/uploads/audio/a.mp3"


def test_minio_url_uses_endpoint_when_domain_missing() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())
    assert adapter.url("audio/a.mp3") == "http://127.0.0.1:9000/uploads/audio/a.mp3"


def test_minio_internal_url_always_uses_endpoint() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        domain="minio.example.com",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())
    assert adapter.internal_url("audio/a.mp3") == "http://127.0.0.1:9000/uploads/audio/a.mp3"


def test_minio_url_empty_path_returns_empty_string() -> None:
    config = MinioDiskConfig(
        endpoint="127.0.0.1:9000",
        access_key="ak",
        secret_key="sk",
        bucket="uploads",
        domain="minio.example.com",
    )
    adapter = MinioAdapter(config, client=DummyMinioClient())
    assert adapter.url("") == ""
    assert adapter.internal_url("") == ""
