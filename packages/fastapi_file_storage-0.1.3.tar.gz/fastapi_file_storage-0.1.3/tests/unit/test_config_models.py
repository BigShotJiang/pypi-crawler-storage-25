import pytest

from fastapi_storage.config.loader import resolve_disk_config
from fastapi_storage.config.models import StorageSettings
from fastapi_storage.exceptions import DiskNotFoundError, StorageConfigurationError
from fastapi_storage.registry import DriverRegistry
from fastapi_storage.config.models import LocalDiskConfig


def test_resolve_disk_config_success() -> None:
    settings = StorageSettings.model_validate(
        {
            "default": "local",
            "disks": {
                "local": {"driver": "local", "root": "storage/app"},
            },
        }
    )
    registry = DriverRegistry()
    registry.register_config_model("local", LocalDiskConfig)

    config = resolve_disk_config("local", settings, registry)
    assert config.driver == "local"


def test_resolve_disk_config_missing_disk() -> None:
    settings = StorageSettings.model_validate({"disks": {}})
    registry = DriverRegistry()
    registry.register_config_model("local", LocalDiskConfig)

    with pytest.raises(DiskNotFoundError):
        resolve_disk_config("missing", settings, registry)


def test_resolve_disk_config_missing_driver() -> None:
    settings = StorageSettings.model_validate(
        {
            "disks": {
                "broken": {"root": "storage/app"},
            }
        }
    )
    registry = DriverRegistry()
    registry.register_config_model("local", LocalDiskConfig)

    with pytest.raises(StorageConfigurationError):
        resolve_disk_config("broken", settings, registry)
