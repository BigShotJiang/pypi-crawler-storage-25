from pathlib import Path

from pydantic import BaseModel

from fastapi_storage.manager import FilesystemManager


class MockDiskConfig(BaseModel):
    driver: str = "mock"


class MockAdapter:
    def __init__(self, config: MockDiskConfig) -> None:
        self.config = config

    def put(self, path: str, content: bytes | str, **kwargs: object) -> bool:
        return True

    def fput(self, path: str, file: str | Path, **kwargs: object) -> bool:
        return True

    def get(self, path: str) -> bytes:
        return b"ok"

    def exists(self, path: str) -> bool:
        return True

    def delete(self, paths: str | list[str]) -> bool:
        return True

    def url(self, path: str) -> str:
        return f"mock://{path}"

    def internal_url(self, path: str) -> str:
        return f"internal://{path}"

    def size(self, path: str) -> int:
        return 2

    def copy(self, src: str, dst: str) -> bool:
        return True

    def move(self, src: str, dst: str) -> bool:
        return True


def test_disk_cache_and_default(tmp_path: Path) -> None:
    settings = {
        "default": "local",
        "cloud": "local",
        "disks": {
            "local": {"driver": "local", "root": str(tmp_path), "url": "/storage"},
        },
    }
    manager = FilesystemManager(settings)
    disk1 = manager.disk()
    disk2 = manager.disk("local")
    assert disk1 is disk2


def test_extend_custom_driver() -> None:
    settings = {
        "default": "custom",
        "cloud": "custom",
        "disks": {
            "custom": {"driver": "mock"},
        },
    }
    manager = FilesystemManager(settings)
    manager.register_config_model("mock", MockDiskConfig)
    manager.extend("mock", lambda config: MockAdapter(config))

    disk = manager.disk("custom")
    assert disk.url("a.txt") == "mock://a.txt"


def test_build_temporary_disk(tmp_path: Path) -> None:
    manager = FilesystemManager(
        {
            "default": "local",
            "disks": {
                "local": {"driver": "local", "root": str(tmp_path)},
            },
        }
    )

    temp = manager.build({"driver": "local", "root": str(tmp_path / "temp")})
    assert temp.put("file.txt", "demo") is True
