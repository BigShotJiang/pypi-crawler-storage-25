import tempfile
from pathlib import Path

from fastapi_storage.scaffold.generator import create_storage_link, generate_scaffold


def test_generate_scaffold_creates_default_files() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        config_path = base / "src/config/filesystems.py"
        env_path = base / ".env.example"

        result = generate_scaffold(config_path=config_path, env_path=env_path)

        assert [item.status for item in result.files] == ["created", "created"]
        assert config_path.exists()
        assert env_path.exists()


def test_generate_scaffold_skips_existing_without_force() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        config_path = base / "src/config/filesystems.py"
        env_path = base / ".env.example"

        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("old", encoding="utf-8")
        env_path.write_text("old", encoding="utf-8")

        result = generate_scaffold(config_path=config_path, env_path=env_path, force=False)

        assert [item.status for item in result.files] == ["skipped", "skipped"]
        assert config_path.read_text(encoding="utf-8") == "old"
        assert env_path.read_text(encoding="utf-8") == "old"


def test_generate_scaffold_overwrites_with_force() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        config_path = base / "src/config/filesystems.py"
        env_path = base / ".env.example"

        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text("old", encoding="utf-8")
        env_path.write_text("old", encoding="utf-8")

        result = generate_scaffold(config_path=config_path, env_path=env_path, force=True)

        assert [item.status for item in result.files] == ["overwritten", "overwritten"]
        assert "class Filesystems" in config_path.read_text(encoding="utf-8")
        assert "STORAGE_DEFAULT=local" in env_path.read_text(encoding="utf-8")


def test_generate_scaffold_respects_skip_flags() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        config_path = base / "src/config/filesystems.py"
        env_path = base / ".env.example"

        result = generate_scaffold(
            config_path=config_path,
            env_path=env_path,
            skip_config=True,
            skip_env=False,
        )

        assert len(result.files) == 1
        assert result.files[0].path == env_path
        assert result.files[0].status == "created"
        assert not config_path.exists()
        assert env_path.exists()


def test_create_storage_link_creates_symlink() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        link_path = base / "public/storage"
        target_path = base / "storage/app/public"

        result = create_storage_link(link_path=link_path, target_path=target_path)

        assert result.status == "linked"
        assert link_path.is_symlink()
        assert link_path.resolve() == target_path.resolve()


def test_create_storage_link_skips_existing_without_force() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        link_path = base / "public/storage"
        target_path = base / "storage/app/public"

        first = create_storage_link(link_path=link_path, target_path=target_path)
        second = create_storage_link(link_path=link_path, target_path=target_path, force=False)

        assert first.status == "linked"
        assert second.status == "skipped"


def test_create_storage_link_overwrites_with_force() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        link_path = base / "public/storage"
        target_path = base / "storage/app/public"
        other_target = base / "storage/other/public"

        create_storage_link(link_path=link_path, target_path=target_path)
        result = create_storage_link(link_path=link_path, target_path=other_target, force=True)

        assert result.status == "overwritten"
        assert link_path.resolve() == other_target.resolve()


def test_create_storage_link_conflict_with_directory() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        base = Path(tmp)
        link_path = base / "public/storage"
        target_path = base / "storage/app/public"

        link_path.mkdir(parents=True, exist_ok=True)

        result = create_storage_link(link_path=link_path, target_path=target_path, force=True)

        assert result.status == "conflict"
        assert link_path.exists()
        assert link_path.is_dir()
