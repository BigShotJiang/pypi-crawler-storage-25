import anyio

from fastapi_storage.adapters.base import StorageAdapter


class DummyAdapter(StorageAdapter):
    def put(self, path: str, content: bytes | str, **kwargs: object) -> bool:
        self._last = (path, content, kwargs)
        return True

    def get(self, path: str) -> bytes:
        return b"ok"

    def exists(self, path: str) -> bool:
        return True

    def delete(self, paths: str | list[str]) -> bool:
        return True

    def url(self, path: str) -> str:
        return f"/{path}"

    def size(self, path: str) -> int:
        return 2

    def copy(self, src: str, dst: str) -> bool:
        return True

    def move(self, src: str, dst: str) -> bool:
        return True


async def _run_aput_with_kwargs() -> tuple[str, bytes | str, dict[str, object]]:
    adapter = DummyAdapter(config=type("C", (), {"root": "", "url": "/storage"})())
    ok = await adapter.aput("demo.txt", "hello", content_type="text/plain", visibility="public")
    assert ok is True
    return adapter._last


async def _run_afput_with_kwargs(source: str) -> tuple[str, bytes | str, dict[str, object]]:
    adapter = DummyAdapter(config=type("C", (), {"root": "", "url": "/storage"})())
    ok = await adapter.afput("demo.txt", source, content_type="text/plain", visibility="public")
    assert ok is True
    return adapter._last


async def _run_ainternal_url() -> str:
    adapter = DummyAdapter(config=type("C", (), {"root": "", "url": "/storage"})())
    return await adapter.ainternal_url("demo.txt")


def test_aput_passes_kwargs_in_async_wrapper() -> None:
    path, content, kwargs = anyio.run(_run_aput_with_kwargs)
    assert path == "demo.txt"
    assert content == "hello"
    assert kwargs == {"content_type": "text/plain", "visibility": "public"}


def test_afput_reads_file_and_passes_kwargs_in_async_wrapper(tmp_path) -> None:
    source = tmp_path / "source.txt"
    source.write_text("hello")

    path, content, kwargs = anyio.run(_run_afput_with_kwargs, str(source))
    assert path == "demo.txt"
    assert content == b"hello"
    assert kwargs == {"content_type": "text/plain", "visibility": "public"}


def test_ainternal_url_uses_base_fallback() -> None:
    assert anyio.run(_run_ainternal_url) == "/storage/demo.txt"
