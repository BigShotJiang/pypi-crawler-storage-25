from fastapi_storage.config.filesystems import Filesystems, filesystems


def test_filesystems_instance_and_defaults() -> None:
    assert isinstance(filesystems, Filesystems)
    assert filesystems.default == "local"
    assert filesystems.cloud == "local"
    assert "local" in filesystems.disks
    assert "public" in filesystems.disks
