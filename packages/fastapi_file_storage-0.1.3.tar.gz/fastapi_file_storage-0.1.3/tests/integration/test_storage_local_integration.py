from pathlib import Path

from fastapi_storage.facade import Storage
from fastapi_storage.manager import FilesystemManager


def test_storage_facade_integration(tmp_path: Path) -> None:
    settings = {
        "default": "local",
        "disks": {
            "local": {"driver": "local", "root": str(tmp_path), "url": "/storage"},
        },
    }

    manager = FilesystemManager(settings)
    Storage.configure(manager=manager)

    source = tmp_path / "source.txt"
    source.write_text("from-file")

    assert Storage.disk("local").put("demo.txt", "ok") is True
    assert Storage.disk("local").fput("copy.txt", source) is True
    assert Storage.disk("local").get("demo.txt") == b"ok"
    assert Storage.disk("local").get("copy.txt") == b"from-file"
    assert Storage.disk("local").internal_url("demo.txt") == "/storage/demo.txt"
