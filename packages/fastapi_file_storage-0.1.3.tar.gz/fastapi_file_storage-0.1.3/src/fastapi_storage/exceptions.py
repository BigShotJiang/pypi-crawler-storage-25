class StorageError(Exception):
    """Base exception for fastapi_storage."""


class StorageConfigurationError(StorageError):
    """Raised when storage settings are invalid."""


class DiskNotFoundError(StorageError):
    """Raised when a disk name is not configured."""


class DriverNotRegisteredError(StorageError):
    """Raised when a driver has no registered factory."""


class DependencyMissingError(StorageError):
    """Raised when an optional dependency is not installed."""


class ObjectNotFoundError(StorageError):
    """Raised when an object does not exist in the disk."""
