from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from fastapi_storage.manager import FilesystemManager
from fastapi_storage.types import AdapterProtocol, DriverFactory


class Storage:
    _manager: FilesystemManager | None = None

    @classmethod
    def configure(
        cls,
        settings: dict[str, Any] | None = None,
        manager: FilesystemManager | None = None,
    ) -> FilesystemManager:
        cls._manager = manager or FilesystemManager(settings=settings)
        return cls._manager

    @classmethod
    def manager(cls) -> FilesystemManager:
        if cls._manager is None:
            cls._manager = FilesystemManager()
        return cls._manager

    @classmethod
    def disk(cls, name: str | None = None) -> AdapterProtocol:
        return cls.manager().disk(name)

    @classmethod
    def drive(cls, name: str | None = None) -> AdapterProtocol:
        return cls.disk(name)

    @classmethod
    def cloud(cls) -> AdapterProtocol:
        return cls.manager().cloud()

    @classmethod
    def extend(cls, driver: str, factory: DriverFactory) -> None:
        cls.manager().extend(driver, factory)

    @classmethod
    def register_config_model(cls, driver: str, model: type[BaseModel]) -> None:
        cls.manager().register_config_model(driver, model)

    @classmethod
    def build(cls, config: dict[str, Any]) -> AdapterProtocol:
        return cls.manager().build(config)

    @classmethod
    def reset(cls, settings: dict[str, Any] | None = None) -> None:
        cls.manager().reset(settings)
