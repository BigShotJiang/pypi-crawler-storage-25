from pydantic import BaseModel

from fastapi_storage.exceptions import DriverNotRegisteredError
from fastapi_storage.types import DriverFactory


class DriverRegistry:
    def __init__(self) -> None:
        self._factories: dict[str, DriverFactory] = {}
        self._config_models: dict[str, type[BaseModel]] = {}

    def register_driver(self, driver: str, factory: DriverFactory) -> None:
        self._factories[driver] = factory

    def get_driver(self, driver: str) -> DriverFactory:
        factory = self._factories.get(driver)
        if factory is None:
            raise DriverNotRegisteredError(f"Storage driver '{driver}' is not registered.")
        return factory

    def register_config_model(self, driver: str, model: type[BaseModel]) -> None:
        self._config_models[driver] = model

    def get_config_model(self, driver: str) -> type[BaseModel] | None:
        return self._config_models.get(driver)

    def list_drivers(self) -> list[str]:
        return list(self._factories.keys())
