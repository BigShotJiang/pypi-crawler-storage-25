from __future__ import annotations

from typing import Any

from fastapi import Request

from fastapi_storage.config.models import StorageSettings
from fastapi_storage.facade import Storage
from fastapi_storage.manager import FilesystemManager


def init_storage(
    app: Any,
    settings: StorageSettings | dict[str, Any] | None = None,
) -> FilesystemManager:
    manager = FilesystemManager(settings=settings)
    app.state.storage = manager
    Storage.configure(manager=manager)
    return manager


def get_storage(request: Request) -> FilesystemManager:
    return request.app.state.storage
