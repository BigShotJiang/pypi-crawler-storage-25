from __future__ import annotations

from typing import Any

from pydantic import BaseModel

from fastapi_storage.adapters.local import LocalAdapter
from fastapi_storage.adapters.minio import MinioAdapter
from fastapi_storage.adapters.obs import ObsAdapter
from fastapi_storage.adapters.oss import OssAdapter
from fastapi_storage.config.loader import load_settings, resolve_disk_config
from fastapi_storage.config.models import (
    LocalDiskConfig,
    MinioDiskConfig,
    ObsDiskConfig,
    OssDiskConfig,
    StorageSettings,
)
from fastapi_storage.registry import DriverRegistry
from fastapi_storage.types import AdapterProtocol, DriverFactory


class FilesystemManager:
    def __init__(
        self,
        settings: StorageSettings | dict[str, Any] | None = None,
        registry: DriverRegistry | None = None,
    ) -> None:
        self.registry = registry or DriverRegistry()
        self.settings = load_settings(settings)
        self._disks: dict[str, AdapterProtocol] = {}
        self._register_builtin_config_models()
        self._register_builtin_drivers()

    def _register_builtin_config_models(self) -> None:
        self.registry.register_config_model("local", LocalDiskConfig)
        self.registry.register_config_model("minio", MinioDiskConfig)
        self.registry.register_config_model("oss", OssDiskConfig)
        self.registry.register_config_model("obs", ObsDiskConfig)

    def _register_builtin_drivers(self) -> None:
        self.registry.register_driver("local", lambda config: LocalAdapter(config))
        self.registry.register_driver("minio", lambda config: MinioAdapter(config))
        self.registry.register_driver("oss", lambda config: OssAdapter(config))
        self.registry.register_driver("obs", lambda config: ObsAdapter(config))

    def drive(self, name: str | None = None) -> AdapterProtocol:
        return self.disk(name)

    def disk(self, name: str | None = None) -> AdapterProtocol:
        target = name or self.settings.default
        disk = self._disks.get(target)
        if disk is None:
            disk = self.resolve(target)
            self._disks[target] = disk
        return disk

    def cloud(self) -> AdapterProtocol:
        target = self.settings.cloud or self.settings.default
        return self.disk(target)

    def resolve(self, name: str) -> AdapterProtocol:
        config = resolve_disk_config(name, self.settings, self.registry)
        factory = self.registry.get_driver(config.driver)
        return factory(config)

    def extend(self, driver: str, factory: DriverFactory) -> None:
        self.registry.register_driver(driver, factory)

    def register_config_model(self, driver: str, model: type[BaseModel]) -> None:
        self.registry.register_config_model(driver, model)

    def build(self, config: dict[str, Any]) -> AdapterProtocol:
        driver = config.get("driver")
        if not driver:
            raise ValueError("Temporary disk config must include 'driver'.")

        model = self.registry.get_config_model(driver)
        if model is None:
            raise ValueError(f"No config model registered for driver '{driver}'.")

        parsed = model.model_validate(config)
        factory = self.registry.get_driver(driver)
        return factory(parsed)

    def forget_disk(self, name: str) -> None:
        self._disks.pop(name, None)

    def reset(self, settings: StorageSettings | dict[str, Any] | None = None) -> None:
        self.settings = load_settings(settings)
        self._disks.clear()
