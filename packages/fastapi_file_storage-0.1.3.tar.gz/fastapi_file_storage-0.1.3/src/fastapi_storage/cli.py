from __future__ import annotations

import argparse

from fastapi_storage.scaffold.generator import create_storage_link, generate_scaffold


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="fastapi-storage")
    subparsers = parser.add_subparsers(dest="command")

    init_parser = subparsers.add_parser("init", help="Generate filesystems scaffold files")
    init_parser.add_argument("--force", action="store_true", help="Overwrite existing files")
    init_parser.add_argument(
        "--config-path",
        default="src/config/filesystems.py",
        help="Path to filesystems.py",
    )
    init_parser.add_argument(
        "--env-path",
        default=".env.example",
        help="Path to .env.example",
    )
    init_parser.add_argument("--skip-config", action="store_true", help="Skip filesystems.py generation")
    init_parser.add_argument("--skip-env", action="store_true", help="Skip .env.example generation")

    link_parser = subparsers.add_parser("storage:link", help="Create public storage symlink")
    link_parser.add_argument("--force", action="store_true", help="Overwrite existing symlink")
    link_parser.add_argument("--link", default="public/storage", help="Symlink path")
    link_parser.add_argument("--target", default="storage/app/public", help="Symlink target path")

    alias_link_parser = subparsers.add_parser("link", help="Alias of storage:link")
    alias_link_parser.add_argument("--force", action="store_true", help="Overwrite existing symlink")
    alias_link_parser.add_argument("--link", default="public/storage", help="Symlink path")
    alias_link_parser.add_argument("--target", default="storage/app/public", help="Symlink target path")

    return parser


def _handle_init(args: argparse.Namespace) -> int:
    if args.skip_config and args.skip_env:
        print("Nothing to generate: both --skip-config and --skip-env were set.")
        return 0

    result = generate_scaffold(
        config_path=args.config_path,
        env_path=args.env_path,
        force=args.force,
        skip_config=args.skip_config,
        skip_env=args.skip_env,
    )

    for item in result.files:
        print(f"{item.status.upper():>11} {item.path}")

    return 0


def _handle_storage_link(args: argparse.Namespace) -> int:
    result = create_storage_link(link_path=args.link, target_path=args.target, force=args.force)

    if result.status == "conflict":
        print(f"CONFLICT {result.path} exists as directory; remove it manually or choose --link path.")
        return 1

    print(f"{result.status.upper():>11} {result.path}")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "init":
        return _handle_init(args)
    if args.command in {"storage:link", "link"}:
        return _handle_storage_link(args)

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
