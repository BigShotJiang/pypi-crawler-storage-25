from typing import Any

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class BaseDiskConfig(BaseModel):
    driver: str
    root: str = ""
    url: str | None = None
    visibility: str | None = None
    directory_separator: str = "/"


class LocalDiskConfig(BaseDiskConfig):
    driver: str = "local"
    root: str = "storage/app"


class MinioDiskConfig(BaseDiskConfig):
    driver: str = "minio"
    endpoint: str
    access_key: str
    secret_key: str
    bucket: str
    region: str | None = None
    secure: bool = False
    domain: str | None = None


class OssDiskConfig(BaseDiskConfig):
    driver: str = "oss"
    endpoint: str
    access_key: str
    secret_key: str
    bucket: str
    is_cname: bool = False
    cdn_domain: str | None = None


class ObsDiskConfig(BaseDiskConfig):
    driver: str = "obs"
    server: str
    access_key_id: str
    secret_access_key: str
    bucket: str


class StorageSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="STORAGE_",
        env_nested_delimiter="__",
        extra="ignore",
    )

    default: str = "local"
    cloud: str | None = None
    disks: dict[str, dict[str, Any]] = Field(
        default_factory=lambda: {
            "local": {"driver": "local", "root": "storage/app"},
            "public": {
                "driver": "local",
                "root": "storage/app/public",
                "url": "/storage",
                "visibility": "public",
            },
        }
    )
