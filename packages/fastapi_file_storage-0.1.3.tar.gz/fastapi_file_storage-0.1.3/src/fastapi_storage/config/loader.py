from typing import Any

from pydantic import BaseModel, ValidationError

from fastapi_storage.config.models import BaseDiskConfig, StorageSettings
from fastapi_storage.exceptions import DiskNotFoundError, StorageConfigurationError
from fastapi_storage.registry import DriverRegistry


def load_settings(data: StorageSettings | dict[str, Any] | None = None) -> StorageSettings:
    if data is None:
        return StorageSettings()
    if isinstance(data, StorageSettings):
        return data
    return StorageSettings.model_validate(data)


def resolve_disk_config(name: str, settings: StorageSettings, registry: DriverRegistry) -> BaseDiskConfig:
    raw = settings.disks.get(name)
    if raw is None:
        raise DiskNotFoundError(f"Storage disk '{name}' is not configured.")

    if isinstance(raw, BaseModel):
        return raw

    driver = raw.get("driver")
    if not driver:
        raise StorageConfigurationError(f"Storage disk '{name}' is missing required 'driver'.")

    model = registry.get_config_model(driver)
    if model is None:
        raise StorageConfigurationError(f"Storage driver '{driver}' has no registered config model.")

    try:
        return model.model_validate(raw)
    except ValidationError as exc:
        raise StorageConfigurationError(f"Invalid config for disk '{name}': {exc}") from exc
