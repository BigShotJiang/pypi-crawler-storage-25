from __future__ import annotations

from typing import Any

from pydantic import Field

from fastapi_storage.config.models import StorageSettings


class Filesystems(StorageSettings):
    default: str = "local"
    cloud: str | None = "local"
    disks: dict[str, dict[str, Any]] = Field(
        default_factory=lambda: {
            "local": {
                "driver": "local",
                "root": "storage/app",
                "url": "/storage",
            },
            "public": {
                "driver": "local",
                "root": "storage/app/public",
                "url": "/storage",
                "visibility": "public",
            },
            "minio": {
                "driver": "minio",
                "endpoint": "127.0.0.1:9000",
                "access_key": "minioadmin",
                "secret_key": "minioadmin",
                "bucket": "app-bucket",
                "secure": False,
            },
            "oss": {
                "driver": "oss",
                "endpoint": "oss-cn-hangzhou.aliyuncs.com",
                "access_key": "your-access-key",
                "secret_key": "your-secret-key",
                "bucket": "your-bucket",
                "is_cname": False,
            },
            "obs": {
                "driver": "obs",
                "server": "obs.cn-east-3.myhuaweicloud.com",
                "access_key_id": "your-access-key-id",
                "secret_access_key": "your-secret-access-key",
                "bucket": "your-bucket",
            },
        }
    )


filesystems = Filesystems()
