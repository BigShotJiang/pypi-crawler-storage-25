from __future__ import annotations

from urllib.parse import urljoin

from fastapi_storage.adapters.base import StorageAdapter
from fastapi_storage.exceptions import DependencyMissingError, ObjectNotFoundError
from fastapi_storage.types import ContentType, DeleteTarget


class ObsAdapter(StorageAdapter):
    def __init__(self, config: object, client: object | None = None) -> None:
        super().__init__(config)
        self.bucket_name = getattr(config, "bucket")
        self.client = client or self._build_client(config)

    @staticmethod
    def _build_client(config: object) -> object:
        try:
            from obs import ObsClient
        except ImportError as exc:
            raise DependencyMissingError("Install obs extra: pip install fastapi-file-storage[obs]") from exc

        return ObsClient(
            access_key_id=getattr(config, "access_key_id"),
            secret_access_key=getattr(config, "secret_access_key"),
            server=getattr(config, "server"),
        )

    def put(self, path: str, content: ContentType, **kwargs: object) -> bool:
        key = self.prefixed_key(path)
        data = self.to_bytes(content)
        response = self.client.putContent(self.bucket_name, key, data)
        status = getattr(response, "status", 500)
        return 200 <= status < 300

    def get(self, path: str) -> bytes:
        key = self.prefixed_key(path)
        response = self.client.getObject(self.bucket_name, key, loadStreamInMemory=True)
        status = getattr(response, "status", 500)
        if not (200 <= status < 300):
            raise ObjectNotFoundError(f"Object '{path}' not found.")

        body = getattr(response, "body", None)
        if isinstance(body, bytes):
            return body
        if hasattr(body, "read"):
            return body.read()
        raise ObjectNotFoundError(f"Object '{path}' not found.")

    def exists(self, path: str) -> bool:
        key = self.prefixed_key(path)
        response = self.client.getObjectMetadata(self.bucket_name, key)
        status = getattr(response, "status", 500)
        return 200 <= status < 300

    def delete(self, paths: DeleteTarget) -> bool:
        targets = [paths] if isinstance(paths, str) else paths
        for target in targets:
            self.client.deleteObject(self.bucket_name, self.prefixed_key(target))
        return True

    def url(self, path: str) -> str:
        normalized = self.normalize_path(path)
        if not normalized:
            return ""

        configured = getattr(self.config, "url", None)
        if configured:
            base = configured.rstrip("/")
            if "://" not in base:
                base = f"https://{base}"
            return urljoin(base + "/", normalized)

        endpoint = getattr(self.config, "server")
        key = self.prefixed_key(path)
        return f"https://{self.bucket_name}.{endpoint}/{key}"

    def size(self, path: str) -> int:
        response = self.client.getObjectMetadata(self.bucket_name, self.prefixed_key(path))
        metadata = getattr(response, "body", {}) or {}
        return int(metadata.get("content-length", 0))

    def copy(self, src: str, dst: str) -> bool:
        response = self.client.copyObject(self.bucket_name, self.prefixed_key(src), self.bucket_name, self.prefixed_key(dst))
        status = getattr(response, "status", 500)
        return 200 <= status < 300

    def move(self, src: str, dst: str) -> bool:
        copied = self.copy(src, dst)
        if copied:
            self.delete(src)
        return copied
