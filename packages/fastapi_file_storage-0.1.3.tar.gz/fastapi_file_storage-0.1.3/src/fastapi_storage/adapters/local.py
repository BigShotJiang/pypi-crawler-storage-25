from __future__ import annotations

from pathlib import Path
import shutil

from fastapi_storage.adapters.base import StorageAdapter
from fastapi_storage.exceptions import ObjectNotFoundError
from fastapi_storage.types import ContentType, DeleteTarget


class LocalAdapter(StorageAdapter):
    def put(self, path: str, content: ContentType, **kwargs: object) -> bool:
        destination = self.resolve_local_path(path)
        destination.parent.mkdir(parents=True, exist_ok=True)
        data = self.to_bytes(content)
        destination.write_bytes(data)
        return True

    def get(self, path: str) -> bytes:
        source = self.resolve_local_path(path)
        if not source.exists():
            raise ObjectNotFoundError(f"Object '{path}' not found.")
        return source.read_bytes()

    def exists(self, path: str) -> bool:
        return self.resolve_local_path(path).exists()

    def delete(self, paths: DeleteTarget) -> bool:
        targets = [paths] if isinstance(paths, str) else paths
        success = True
        for target in targets:
            file_path = self.resolve_local_path(target)
            if file_path.exists():
                if file_path.is_dir():
                    shutil.rmtree(file_path)
                else:
                    file_path.unlink()
            else:
                success = False
        return success

    def url(self, path: str) -> str:
        return self.build_url(path)

    def size(self, path: str) -> int:
        target = self.resolve_local_path(path)
        if not target.exists():
            raise ObjectNotFoundError(f"Object '{path}' not found.")
        return target.stat().st_size

    def copy(self, src: str, dst: str) -> bool:
        source = self.resolve_local_path(src)
        destination = self.resolve_local_path(dst)
        if not source.exists():
            raise ObjectNotFoundError(f"Object '{src}' not found.")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        return True

    def move(self, src: str, dst: str) -> bool:
        source = self.resolve_local_path(src)
        destination = self.resolve_local_path(dst)
        if not source.exists():
            raise ObjectNotFoundError(f"Object '{src}' not found.")
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(source), str(destination))
        return True
