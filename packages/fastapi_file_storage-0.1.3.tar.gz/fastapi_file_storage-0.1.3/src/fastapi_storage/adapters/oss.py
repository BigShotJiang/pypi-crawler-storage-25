from __future__ import annotations

from urllib.parse import urljoin

from fastapi_storage.adapters.base import StorageAdapter
from fastapi_storage.exceptions import DependencyMissingError, ObjectNotFoundError
from fastapi_storage.types import ContentType, DeleteTarget


class OssAdapter(StorageAdapter):
    def __init__(self, config: object, client: object | None = None) -> None:
        super().__init__(config)
        self.bucket_name = getattr(config, "bucket")
        self.client = client or self._build_client(config)

    @staticmethod
    def _build_client(config: object) -> object:
        try:
            import oss2
        except ImportError as exc:
            raise DependencyMissingError("Install oss extra: pip install fastapi-file-storage[oss]") from exc

        auth = oss2.Auth(getattr(config, "access_key"), getattr(config, "secret_key"))
        return oss2.Bucket(
            auth,
            getattr(config, "endpoint"),
            getattr(config, "bucket"),
            is_cname=getattr(config, "is_cname", False),
        )

    def put(self, path: str, content: ContentType, **kwargs: object) -> bool:
        key = self.prefixed_key(path)
        data = self.to_bytes(content)
        self.client.put_object(key, data)
        return True

    def get(self, path: str) -> bytes:
        key = self.prefixed_key(path)
        try:
            response = self.client.get_object(key)
        except Exception as exc:
            raise ObjectNotFoundError(f"Object '{path}' not found.") from exc
        return response.read()

    def exists(self, path: str) -> bool:
        return bool(self.client.object_exists(self.prefixed_key(path)))

    def delete(self, paths: DeleteTarget) -> bool:
        targets = [paths] if isinstance(paths, str) else paths
        for target in targets:
            self.client.delete_object(self.prefixed_key(target))
        return True

    def url(self, path: str) -> str:
        normalized = self.normalize_path(path)
        if not normalized:
            return ""

        configured = getattr(self.config, "url", None)
        if configured:
            base = configured.rstrip("/")
            if "://" not in base:
                base = f"https://{base}"
            return urljoin(base + "/", normalized)

        cdn = getattr(self.config, "cdn_domain", None)
        if cdn:
            base = cdn.rstrip("/")
            if "://" not in base:
                base = f"https://{base}"
            return urljoin(base + "/", normalized)

        endpoint = getattr(self.config, "endpoint")
        key = self.prefixed_key(path)
        return f"https://{self.bucket_name}.{endpoint}/{key}"

    def size(self, path: str) -> int:
        header = self.client.head_object(self.prefixed_key(path))
        return int(getattr(header, "content_length"))

    def copy(self, src: str, dst: str) -> bool:
        self.client.copy_object(self.bucket_name, self.prefixed_key(src), self.prefixed_key(dst))
        return True

    def move(self, src: str, dst: str) -> bool:
        self.copy(src, dst)
        self.delete(src)
        return True
