from fastapi_storage.adapters.base import PathPrefixer, StorageAdapter
from fastapi_storage.adapters.local import LocalAdapter
from fastapi_storage.adapters.minio import MinioAdapter
from fastapi_storage.adapters.obs import ObsAdapter
from fastapi_storage.adapters.oss import OssAdapter

__all__ = [
    "PathPrefixer",
    "StorageAdapter",
    "LocalAdapter",
    "MinioAdapter",
    "OssAdapter",
    "ObsAdapter",
]
