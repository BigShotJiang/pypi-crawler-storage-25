from __future__ import annotations

from io import BytesIO

from fastapi_storage.adapters.base import StorageAdapter
from fastapi_storage.exceptions import DependencyMissingError, ObjectNotFoundError
from fastapi_storage.types import ContentType, DeleteTarget


class MinioAdapter(StorageAdapter):
    def __init__(self, config: object, client: object | None = None) -> None:
        super().__init__(config)
        self.bucket = getattr(config, "bucket")
        self.client = client or self._build_client(config)

    @staticmethod
    def _build_client(config: object) -> object:
        try:
            from minio import Minio
        except ImportError as exc:
            raise DependencyMissingError("Install minio extra: pip install fastapi-file-storage[minio]") from exc

        return Minio(
            endpoint=getattr(config, "endpoint"),
            access_key=getattr(config, "access_key"),
            secret_key=getattr(config, "secret_key"),
            region=getattr(config, "region", None),
            secure=getattr(config, "secure", False),
        )

    def put(self, path: str, content: ContentType, **kwargs: object) -> bool:
        key = self.prefixed_key(path)
        data = self.to_bytes(content)
        stream = BytesIO(data)
        content_type = kwargs.get("content_type") or "application/octet-stream"
        self.client.put_object(self.bucket, key, stream, len(data), content_type=content_type)
        return True

    def get(self, path: str) -> bytes:
        key = self.prefixed_key(path)
        try:
            response = self.client.get_object(self.bucket, key)
        except Exception as exc:
            raise ObjectNotFoundError(f"Object '{path}' not found.") from exc

        try:
            return response.read()
        finally:
            if hasattr(response, "close"):
                response.close()
            if hasattr(response, "release_conn"):
                response.release_conn()

    def exists(self, path: str) -> bool:
        key = self.prefixed_key(path)
        try:
            self.client.stat_object(self.bucket, key)
            return True
        except Exception:
            return False

    def delete(self, paths: DeleteTarget) -> bool:
        targets = [paths] if isinstance(paths, str) else paths
        for target in targets:
            self.client.remove_object(self.bucket, self.prefixed_key(target))
        return True

    def url(self, path: str) -> str:
        normalized = self.normalize_path(path)
        if not normalized:
            return ""

        domain = getattr(self.config, "domain", None)
        if domain:
            return f"https://{domain.rstrip('/')}/{self.bucket}/{normalized}"

        endpoint = getattr(self.config, "endpoint")
        return f"http://{endpoint.rstrip('/')}/{self.bucket}/{normalized}"

    def internal_url(self, path: str) -> str:
        normalized = self.normalize_path(path)
        if not normalized:
            return ""

        endpoint = getattr(self.config, "endpoint")
        return f"http://{endpoint.rstrip('/')}/{self.bucket}/{normalized}"

    def size(self, path: str) -> int:
        stat = self.client.stat_object(self.bucket, self.prefixed_key(path))
        return int(getattr(stat, "size"))

    def copy(self, src: str, dst: str) -> bool:
        try:
            from minio.commonconfig import CopySource
        except ImportError as exc:
            raise DependencyMissingError("Install minio extra: pip install fastapi-file-storage[minio]") from exc

        source = CopySource(self.bucket, self.prefixed_key(src))
        self.client.copy_object(self.bucket, self.prefixed_key(dst), source)
        return True

    def move(self, src: str, dst: str) -> bool:
        self.copy(src, dst)
        self.delete(src)
        return True
