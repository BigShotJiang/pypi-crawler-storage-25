from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from fastapi_storage.scaffold.templates import ENV_EXAMPLE_TEMPLATE, FILESYSTEMS_PY_TEMPLATE


@dataclass(slots=True)
class GeneratedFile:
    path: Path
    status: str


@dataclass(slots=True)
class ScaffoldResult:
    files: list[GeneratedFile] = field(default_factory=list)


def _write_template(path: Path, content: str, force: bool) -> str:
    exists = path.exists()
    if exists and not force:
        return "skipped"

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content.rstrip() + "\n", encoding="utf-8")
    return "overwritten" if exists else "created"


def generate_scaffold(
    config_path: str | Path = "src/config/filesystems.py",
    env_path: str | Path = ".env.example",
    *,
    force: bool = False,
    skip_config: bool = False,
    skip_env: bool = False,
) -> ScaffoldResult:
    result = ScaffoldResult()

    config_target = Path(config_path)
    env_target = Path(env_path)

    if not skip_config:
        status = _write_template(config_target, FILESYSTEMS_PY_TEMPLATE, force)
        result.files.append(GeneratedFile(path=config_target, status=status))

    if not skip_env:
        status = _write_template(env_target, ENV_EXAMPLE_TEMPLATE, force)
        result.files.append(GeneratedFile(path=env_target, status=status))

    return result


def create_storage_link(
    link_path: str | Path = "public/storage",
    target_path: str | Path = "storage/app/public",
    *,
    force: bool = False,
) -> GeneratedFile:
    link = Path(link_path)
    target = Path(target_path)

    target.mkdir(parents=True, exist_ok=True)
    link.parent.mkdir(parents=True, exist_ok=True)

    existed = link.exists() or link.is_symlink()
    if existed:
        if not force:
            return GeneratedFile(path=link, status="skipped")

        if link.is_symlink() or link.is_file():
            link.unlink()
        elif link.is_dir():
            return GeneratedFile(path=link, status="conflict")

    link.symlink_to(target.resolve())
    return GeneratedFile(path=link, status="overwritten" if existed else "linked")
