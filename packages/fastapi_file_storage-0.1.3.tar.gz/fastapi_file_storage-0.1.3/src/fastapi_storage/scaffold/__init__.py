from fastapi_storage.scaffold.generator import (
    GeneratedFile,
    ScaffoldResult,
    create_storage_link,
    generate_scaffold,
)
from fastapi_storage.scaffold.templates import ENV_EXAMPLE_TEMPLATE, FILESYSTEMS_PY_TEMPLATE

__all__ = [
    "GeneratedFile",
    "ScaffoldResult",
    "generate_scaffold",
    "create_storage_link",
    "FILESYSTEMS_PY_TEMPLATE",
    "ENV_EXAMPLE_TEMPLATE",
]
