FILESYSTEMS_PY_TEMPLATE = '''from __future__ import annotations

from typing import Any

from pydantic import Field

from fastapi_storage.config.models import StorageSettings


class Filesystems(StorageSettings):
    default: str = "local"
    cloud: str | None = "local"
    disks: dict[str, dict[str, Any]] = Field(
        default_factory=lambda: {
            "local": {
                "driver": "local",
                "root": "storage/app",
                "url": "/storage",
            },
            "public": {
                "driver": "local",
                "root": "storage/app/public",
                "url": "/storage",
                "visibility": "public",
            },
            "minio": {
                "driver": "minio",
                "endpoint": "127.0.0.1:9000",
                "access_key": "minioadmin",
                "secret_key": "minioadmin",
                "bucket": "app-bucket",
                "secure": False,
            },
            "oss": {
                "driver": "oss",
                "endpoint": "oss-cn-hangzhou.aliyuncs.com",
                "access_key": "your-access-key",
                "secret_key": "your-secret-key",
                "bucket": "your-bucket",
                "is_cname": False,
            },
            "obs": {
                "driver": "obs",
                "server": "obs.cn-east-3.myhuaweicloud.com",
                "access_key_id": "your-access-key-id",
                "secret_access_key": "your-secret-access-key",
                "bucket": "your-bucket",
            },
        }
    )


filesystems = Filesystems()
'''

ENV_EXAMPLE_TEMPLATE = '''# Storage settings
STORAGE_DEFAULT=local
STORAGE_CLOUD=local

# Local disk
STORAGE_DISKS__LOCAL__DRIVER=local
STORAGE_DISKS__LOCAL__ROOT=storage/app
STORAGE_DISKS__LOCAL__URL=/storage

# Public disk
STORAGE_DISKS__PUBLIC__DRIVER=local
STORAGE_DISKS__PUBLIC__ROOT=storage/app/public
STORAGE_DISKS__PUBLIC__URL=/storage
STORAGE_DISKS__PUBLIC__VISIBILITY=public

# MinIO disk
STORAGE_DISKS__MINIO__DRIVER=minio
STORAGE_DISKS__MINIO__ENDPOINT=127.0.0.1:9000
STORAGE_DISKS__MINIO__ACCESS_KEY=minioadmin
STORAGE_DISKS__MINIO__SECRET_KEY=minioadmin
STORAGE_DISKS__MINIO__BUCKET=app-bucket
STORAGE_DISKS__MINIO__SECURE=false

# OSS disk
STORAGE_DISKS__OSS__DRIVER=oss
STORAGE_DISKS__OSS__ENDPOINT=oss-cn-hangzhou.aliyuncs.com
STORAGE_DISKS__OSS__ACCESS_KEY=your-access-key
STORAGE_DISKS__OSS__SECRET_KEY=your-secret-key
STORAGE_DISKS__OSS__BUCKET=your-bucket
STORAGE_DISKS__OSS__IS_CNAME=false

# OBS disk
STORAGE_DISKS__OBS__DRIVER=obs
STORAGE_DISKS__OBS__SERVER=obs.cn-east-3.myhuaweicloud.com
STORAGE_DISKS__OBS__ACCESS_KEY_ID=your-access-key-id
STORAGE_DISKS__OBS__SECRET_ACCESS_KEY=your-secret-access-key
STORAGE_DISKS__OBS__BUCKET=your-bucket
'''
