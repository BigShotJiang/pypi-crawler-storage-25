import platform
import shutil
import subprocess
import sys
import os
import json
import urllib.request
from importlib.metadata import PackageNotFoundError, version

import psutil
from PyQt6 import QtCore, QtGui, QtWidgets

REQUIRED_PACKAGES = [
    "torch",
    "torchvision",
    "segmentation-models-pytorch",
    "opencv-python",
    "numpy",
    "scipy",
    "matplotlib",
    "psutil",
    "PyQt6",
    "nibabel",
]

MODEL_FILENAME = "brain_abnormality_segmentation.pth"
MODEL_DOWNLOAD_URL = "https://github.com/raselmandol/brainseg/releases/download/v1.6.1/brain_abnormality_segmentation.pth"
RELEASES_API_URL = "https://api.github.com/repos/raselmandol/brainseg/releases"
MODEL_EXTENSIONS = (
    ".pth", ".pt", ".tflite", ".tf", ".onnx", ".h5", ".keras",
    ".ckpt", ".pb", ".safetensors", ".bin", ".zip",
)


class ModelDownloadThread(QtCore.QThread):
    progressChanged = QtCore.pyqtSignal(int, str)
    completed = QtCore.pyqtSignal(str)
    failed = QtCore.pyqtSignal(str)

    def __init__(self, url: str, destination: str, parent=None):
        super().__init__(parent)
        self.url = url
        self.destination = destination

    def run(self):
        try:
            os.makedirs(os.path.dirname(self.destination), exist_ok=True)
            req = urllib.request.Request(self.url, headers={"User-Agent": "BrainSeg/1.6.1"})
            with urllib.request.urlopen(req, timeout=60) as response, open(self.destination, "wb") as f:
                total = response.getheader("Content-Length")
                total_bytes = int(total) if total and total.isdigit() else 0
                downloaded = 0
                chunk_size = 1024 * 256

                while True:
                    chunk = response.read(chunk_size)
                    if not chunk:
                        break
                    f.write(chunk)
                    downloaded += len(chunk)

                    if total_bytes > 0:
                        pct = int((downloaded * 100) / total_bytes)
                        self.progressChanged.emit(min(pct, 100), f"Downloading... {pct}%")
                    else:
                        mb = downloaded / (1024 * 1024)
                        self.progressChanged.emit(-1, f"Downloading... {mb:.1f} MB")

            self.progressChanged.emit(100, "Download complete")
            self.completed.emit(self.destination)
        except Exception as exc:
            try:
                if os.path.exists(self.destination):
                    os.remove(self.destination)
            except Exception:
                pass
            self.failed.emit(str(exc))


class ReleaseScanThread(QtCore.QThread):
    completed = QtCore.pyqtSignal(list)
    failed = QtCore.pyqtSignal(str)

    def __init__(self, api_url: str, extensions: tuple[str, ...], parent=None):
        super().__init__(parent)
        self.api_url = api_url
        self.extensions = tuple(ext.lower() for ext in extensions)

    def run(self):
        try:
            req = urllib.request.Request(self.api_url, headers={"User-Agent": "BrainSeg/1.6.1"})
            with urllib.request.urlopen(req, timeout=60) as response:
                payload = json.loads(response.read().decode("utf-8"))

            assets = []
            for release in payload if isinstance(payload, list) else []:
                tag = release.get("tag_name") or release.get("name") or "untagged"
                release_name = release.get("name") or tag
                for asset in release.get("assets", []) or []:
                    name = asset.get("name", "")
                    lower = name.lower()
                    if not any(lower.endswith(ext) for ext in self.extensions):
                        continue
                    assets.append({
                        "tag": tag,
                        "release_name": release_name,
                        "asset_name": name,
                        "download_url": asset.get("browser_download_url", ""),
                        "size": int(asset.get("size") or 0),
                    })

            self.completed.emit(assets)
        except Exception as exc:
            self.failed.emit(str(exc))


class SystemInfoWindow(QtWidgets.QWidget):
    closeRequested = QtCore.pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("EnvironmentReportPanel")
        self.setMinimumWidth(280)

        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(10)

        header = QtWidgets.QFrame()
        header.setObjectName("EnvironmentHeader")
        header_layout = QtWidgets.QHBoxLayout(header)
        header_layout.setContentsMargins(12, 10, 12, 10)
        header_layout.setSpacing(10)

        title_col = QtWidgets.QVBoxLayout()
        title_col.setSpacing(2)
        title = QtWidgets.QLabel("BrainSeg Environment Report")
        title.setStyleSheet("font-size: 14px; font-weight: 600;")
        self.subtitle = QtWidgets.QLabel("Runtime and dependency health summary")
        self.subtitle.setObjectName("EnvironmentSubtitle")
        title_col.addWidget(title)
        title_col.addWidget(self.subtitle)

        self.health_chip = QtWidgets.QLabel("Status: Checking...")
        self.health_chip.setObjectName("StatusChip")
        self.health_chip.setMinimumWidth(120)
        self.health_chip.setMaximumWidth(360)
        self.health_chip.setSizePolicy(QtWidgets.QSizePolicy.Policy.Maximum, QtWidgets.QSizePolicy.Policy.Fixed)
        self.health_chip.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignVCenter)
        title_col.addWidget(self.health_chip, 0, QtCore.Qt.AlignmentFlag.AlignLeft)

        header_layout.addLayout(title_col, 1)

        root.addWidget(header)

        self.tabs = QtWidgets.QTabWidget()
        root.addWidget(self.tabs, 1)

        self._build_overview_tab()
        self._build_gpu_tab()
        self._build_packages_tab()
        self._build_model_tab()

        self._report_cache = ""
        self._download_thread = None
        self._release_scan_thread = None
        self._release_download_thread = None
        self._release_assets = []
        self._model_expected_full = ""
        self._model_selected_full = ""

        actions = QtWidgets.QHBoxLayout()
        actions.addStretch(1)

        self.refresh_btn = QtWidgets.QPushButton("Refresh")
        self.refresh_btn.setFixedHeight(28)
        self.refresh_btn.setMinimumWidth(78)
        self.refresh_btn.clicked.connect(self.refresh_information)
        actions.addWidget(self.refresh_btn)

        self.copy_btn = QtWidgets.QPushButton("Copy")
        self.copy_btn.setFixedHeight(28)
        self.copy_btn.setMinimumWidth(72)
        self.copy_btn.clicked.connect(self._copy_to_clipboard)
        actions.addWidget(self.copy_btn)

        close_btn = QtWidgets.QPushButton("Close")
        close_btn.setFixedHeight(28)
        close_btn.setMinimumWidth(76)
        close_btn.clicked.connect(self.closeRequested.emit)
        actions.addWidget(close_btn)

        root.addLayout(actions)

        self.apply_theme_palette(theme="light", accent_color="#1a73e8", theme_color=None)
        self._set_health_chip_colors("#e9ecef", "#333333")

        self.refresh_information()

    def refresh_information(self):
        system_info = self._collect_system_info()
        python_info = self._collect_python_info()
        gpu_info = self._collect_gpu_info()
        pkg_info = self._collect_package_info()

        self._fill_overview(system_info, python_info, pkg_info)
        self._fill_gpu(gpu_info)
        self._fill_packages(pkg_info)
        self._refresh_model_status()
        self._update_health(pkg_info)
        self._report_cache = self._build_report_text(system_info, python_info, gpu_info, pkg_info)

    def _copy_to_clipboard(self):
        QtWidgets.QApplication.clipboard().setText(self._report_cache)

    def _build_overview_tab(self):
        page = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(page)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        self.system_table = self._create_kv_table()
        self.python_table = self._create_kv_table()

        sys_group = QtWidgets.QGroupBox("System")
        sys_layout = QtWidgets.QVBoxLayout(sys_group)
        sys_layout.addWidget(self.system_table)
        self.system_table.setMinimumHeight(240)

        py_group = QtWidgets.QGroupBox("Python")
        py_layout = QtWidgets.QVBoxLayout(py_group)
        py_layout.addWidget(self.python_table)
        self.python_table.setMinimumHeight(110)

        layout.addWidget(sys_group, 3)
        layout.addWidget(py_group, 2)

        self.tabs.addTab(page, "Overview")

    def _build_gpu_tab(self):
        page = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(page)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        self.gpu_table = self._create_kv_table()
        layout.addWidget(self.gpu_table)

        self.tabs.addTab(page, "GPU")

    def _build_packages_tab(self):
        page = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(page)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        self.packages_summary = QtWidgets.QLabel("Required packages")
        self.packages_summary.setObjectName("PackagesSummary")
        layout.addWidget(self.packages_summary)

        self.packages_table = QtWidgets.QTableWidget(0, 3)
        self.packages_table.setHorizontalHeaderLabels(["Package", "Status", "Version / Details"])
        self.packages_table.verticalHeader().setVisible(False)
        self.packages_table.setAlternatingRowColors(True)
        self.packages_table.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.NoSelection)
        self.packages_table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.packages_table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        self.packages_table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        self.packages_table.horizontalHeader().setSectionResizeMode(2, QtWidgets.QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.packages_table, 1)

        self.tabs.addTab(page, "Packages")

    def _build_model_tab(self):
        page = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(page)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        self.model_summary = QtWidgets.QLabel("Checks required model file availability and selected path")
        self.model_summary.setObjectName("PackagesSummary")
        layout.addWidget(self.model_summary)

        info_group = QtWidgets.QGroupBox("Model File")
        form = QtWidgets.QFormLayout(info_group)
        form.setLabelAlignment(QtCore.Qt.AlignmentFlag.AlignLeft | QtCore.Qt.AlignmentFlag.AlignTop)

        self.model_expected_path = QtWidgets.QLabel("-")
        self.model_expected_path.setWordWrap(True)
        self.model_expected_path.setTextInteractionFlags(QtCore.Qt.TextInteractionFlag.TextSelectableByMouse)
        form.addRow("Expected location", self.model_expected_path)

        self.model_selected_path = QtWidgets.QLabel("-")
        self.model_selected_path.setWordWrap(True)
        self.model_selected_path.setTextInteractionFlags(QtCore.Qt.TextInteractionFlag.TextSelectableByMouse)
        form.addRow("Current model path", self.model_selected_path)

        self.model_status_label = QtWidgets.QLabel("Checking...")
        self.model_status_label.setObjectName("StatusChip")
        form.addRow("Status", self.model_status_label)

        layout.addWidget(info_group)

        action_row = QtWidgets.QHBoxLayout()
        self.model_refresh_btn = QtWidgets.QPushButton("Refresh")
        self.model_refresh_btn.clicked.connect(self._refresh_model_status)
        action_row.addWidget(self.model_refresh_btn)

        self.model_browse_btn = QtWidgets.QPushButton("Browse...")
        self.model_browse_btn.clicked.connect(self._browse_model_file)
        action_row.addWidget(self.model_browse_btn)

        self.model_download_btn = QtWidgets.QPushButton("Download")
        self.model_download_btn.clicked.connect(self._download_model_file)
        action_row.addWidget(self.model_download_btn)
        action_row.addStretch(1)
        layout.addLayout(action_row)

        self.model_progress = QtWidgets.QProgressBar()
        self.model_progress.setRange(0, 100)
        self.model_progress.setValue(0)
        self.model_progress.setTextVisible(True)
        self.model_progress.hide()
        layout.addWidget(self.model_progress)

        self.model_progress_text = QtWidgets.QLabel("")
        self.model_progress_text.setObjectName("PackagesSummary")
        self.model_progress_text.hide()
        layout.addWidget(self.model_progress_text)

        releases_group = QtWidgets.QGroupBox("Release Models")
        releases_layout = QtWidgets.QVBoxLayout(releases_group)
        releases_layout.setSpacing(8)

        self.releases_status_label = QtWidgets.QLabel("Click Check Releases to find downloadable model assets.")
        self.releases_status_label.setObjectName("PackagesSummary")
        self.releases_status_label.setWordWrap(True)
        releases_layout.addWidget(self.releases_status_label)

        releases_actions = QtWidgets.QHBoxLayout()
        self.check_releases_btn = QtWidgets.QPushButton("Check Releases")
        self.check_releases_btn.clicked.connect(self._check_releases)
        releases_actions.addWidget(self.check_releases_btn)

        self.download_release_btn = QtWidgets.QPushButton("Download Selected")
        self.download_release_btn.setEnabled(False)
        self.download_release_btn.clicked.connect(self._download_selected_release_asset)
        releases_actions.addWidget(self.download_release_btn)
        releases_actions.addStretch(1)
        releases_layout.addLayout(releases_actions)

        self.releases_progress = QtWidgets.QProgressBar()
        self.releases_progress.setRange(0, 100)
        self.releases_progress.setValue(0)
        self.releases_progress.setTextVisible(True)
        self.releases_progress.hide()
        releases_layout.addWidget(self.releases_progress)

        self.releases_table = QtWidgets.QTableWidget(0, 6)
        self.releases_table.setHorizontalHeaderLabels(["Tag", "Asset", "Type", "Size", "Status", "Location"])
        self.releases_table.verticalHeader().setVisible(False)
        self.releases_table.verticalHeader().setDefaultSectionSize(26)
        self.releases_table.verticalHeader().setMinimumSectionSize(22)
        self.releases_table.setAlternatingRowColors(True)
        self.releases_table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectionBehavior.SelectRows)
        self.releases_table.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection)
        self.releases_table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        self.releases_table.setWordWrap(False)
        self.releases_table.setVerticalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.releases_table.setHorizontalScrollMode(QtWidgets.QAbstractItemView.ScrollMode.ScrollPerPixel)
        self.releases_table.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.releases_table.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        header = self.releases_table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(QtWidgets.QHeaderView.ResizeMode.Interactive)
        self.releases_table.setColumnWidth(0, 82)   # Tag
        self.releases_table.setColumnWidth(1, 300)  # Asset
        self.releases_table.setColumnWidth(2, 74)   # Type
        self.releases_table.setColumnWidth(3, 96)   # Size
        self.releases_table.setColumnWidth(4, 120)  # Status
        self.releases_table.setColumnWidth(5, 420)  # Location
        row_height = self.releases_table.verticalHeader().defaultSectionSize()
        header_height = self.releases_table.horizontalHeader().height()
        h_scroll = self.releases_table.horizontalScrollBar().sizeHint().height()
        frame = int(self.releases_table.frameWidth() * 2)
        min_height = header_height + (row_height * 4) + h_scroll + frame + 6
        self.releases_table.setMinimumHeight(min_height)
        self.releases_table.itemSelectionChanged.connect(self._update_release_download_button_state)
        releases_layout.addWidget(self.releases_table)

        layout.addWidget(releases_group, 2)
        self.tabs.addTab(page, "Model File")

    def _create_kv_table(self):
        table = QtWidgets.QTableWidget(0, 2)
        table.setHorizontalHeaderLabels(["Item", "Value"])
        table.verticalHeader().setVisible(False)
        table.setAlternatingRowColors(True)
        table.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.NoSelection)
        table.setEditTriggers(QtWidgets.QAbstractItemView.EditTrigger.NoEditTriggers)
        table.horizontalHeader().setSectionResizeMode(0, QtWidgets.QHeaderView.ResizeMode.ResizeToContents)
        table.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.ResizeMode.Stretch)
        return table

    def _fill_overview(self, system_info, python_info, package_info):
        self._fill_kv_table(self.system_table, system_info)
        self._fill_kv_table(self.python_table, python_info)
        checked = len(package_info["found"]) + len(package_info["missing"])
        self.subtitle.setText(
            f"Runtime and dependency health summary - checked {checked} required packages"
        )

    def _fill_gpu(self, gpu_info):
        self._fill_kv_table(self.gpu_table, gpu_info)

    def _fill_packages(self, package_info):
        rows = []
        for name, ver in package_info["found"]:
            rows.append((name, "Installed", ver))
        for name in package_info["missing"]:
            rows.append((name, "Missing", "Not installed"))

        self.packages_table.setRowCount(len(rows))
        for i, (pkg, status, details) in enumerate(rows):
            pkg_item = QtWidgets.QTableWidgetItem(pkg)
            status_item = QtWidgets.QTableWidgetItem(status)
            details_item = QtWidgets.QTableWidgetItem(details)

            if status == "Missing":
                status_item.setForeground(QtGui.QColor("#b42318"))
            else:
                status_item.setForeground(QtGui.QColor("#027a48"))

            self.packages_table.setItem(i, 0, pkg_item)
            self.packages_table.setItem(i, 1, status_item)
            self.packages_table.setItem(i, 2, details_item)

        missing_count = len(package_info["missing"])
        installed_count = len(package_info["found"])
        self.packages_summary.setText(
            f"Installed: {installed_count} | Missing: {missing_count} | Total required: {installed_count + missing_count}"
        )

    def _fill_kv_table(self, table, data):
        table.setRowCount(len(data))
        for i, (key, value) in enumerate(data):
            table.setItem(i, 0, QtWidgets.QTableWidgetItem(str(key)))
            table.setItem(i, 1, QtWidgets.QTableWidgetItem(str(value)))

    def _default_model_directory(self):
        home = os.path.expanduser("~")
        if sys.platform.startswith("win"):
            base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or os.path.join(home, "AppData", "Local")
            return os.path.join(base, "BrainSeg", "models")
        if sys.platform == "darwin":
            return os.path.join(home, "Library", "Caches", "brainseg", "models")
        xdg_cache = os.environ.get("XDG_CACHE_HOME") or os.path.join(home, ".cache")
        return os.path.join(xdg_cache, "brainseg", "models")

    def _expected_model_path(self):
        return os.path.join(self._default_model_directory(), MODEL_FILENAME)

    def _get_current_model_path(self):
        try:
            from . import model
            return getattr(model, "MODEL_PATH", "")
        except Exception:
            return ""

    def _refresh_model_status(self):
        expected = self._expected_model_path()
        current = self._get_current_model_path()
        exists_expected = os.path.exists(expected)
        exists_current = bool(current) and os.path.exists(current)

        self._model_expected_full = expected
        self._model_selected_full = current or "(not selected)"
        self._update_model_path_labels()

        if exists_expected:
            self.model_status_label.setText("Found in default location")
            self._set_chip_colors(self.model_status_label, "#ecfdf3", "#027a48")
        elif exists_current:
            self.model_status_label.setText("Using selected path")
            self._set_chip_colors(self.model_status_label, "#eff8ff", "#175cd3")
        else:
            self.model_status_label.setText("Not found")
            self._set_chip_colors(self.model_status_label, "#fff4ed", "#b42318")

        self.model_download_btn.setEnabled(not exists_expected)
        self._refresh_release_rows_status()

    def _update_model_path_labels(self):
        self._set_elided_label_text(self.model_expected_path, self._model_expected_full)
        self._set_elided_label_text(self.model_selected_path, self._model_selected_full)

    @staticmethod
    def _set_elided_label_text(label: QtWidgets.QLabel, text: str):
        if not text:
            label.setText("")
            return
        metrics = QtGui.QFontMetrics(label.font())
        available = max(40, label.width() - 6)
        elided = metrics.elidedText(text, QtCore.Qt.TextElideMode.ElideRight, available)
        label.setText(elided)
        label.setToolTip(text)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_model_path_labels()

    @staticmethod
    def _sanitize_tag(tag: str) -> str:
        if not tag:
            return "untagged"
        return "".join("_" if c in "<>:\\|?*\"/" else c for c in str(tag))

    def _release_asset_destination(self, tag: str, asset_name: str) -> str:
        release_dir = os.path.join(self._default_model_directory(), self._sanitize_tag(tag))
        return os.path.join(release_dir, asset_name)

    @staticmethod
    def _format_bytes(size: int) -> str:
        units = ["B", "KB", "MB", "GB"]
        value = float(size)
        idx = 0
        while value >= 1024.0 and idx < len(units) - 1:
            value /= 1024.0
            idx += 1
        return f"{value:.1f} {units[idx]}"

    def _asset_type(self, name: str) -> str:
        lower = name.lower()
        for ext in MODEL_EXTENSIONS:
            if lower.endswith(ext):
                return ext.lstrip(".").upper()
        return "MODEL"

    def _check_releases(self):
        self.check_releases_btn.setEnabled(False)
        self.download_release_btn.setEnabled(False)
        self.releases_progress.show()
        self.releases_progress.setRange(0, 0)
        self.releases_status_label.setText("Checking GitHub releases for model assets...")

        self._release_scan_thread = ReleaseScanThread(RELEASES_API_URL, MODEL_EXTENSIONS, self)
        self._release_scan_thread.completed.connect(self._on_releases_scanned)
        self._release_scan_thread.failed.connect(self._on_releases_scan_failed)
        self._release_scan_thread.start()

    def _on_releases_scanned(self, assets):
        self._release_assets = assets or []
        self.releases_progress.setRange(0, 100)
        self.releases_progress.setValue(100)

        self.releases_table.setRowCount(0)
        for row, asset in enumerate(self._release_assets):
            tag = asset.get("tag", "untagged")
            name = asset.get("asset_name", "")
            dest = self._release_asset_destination(tag, name)
            exists = os.path.exists(dest)

            self.releases_table.insertRow(row)
            tag_item = QtWidgets.QTableWidgetItem(tag)
            tag_item.setData(QtCore.Qt.ItemDataRole.UserRole, asset)
            self.releases_table.setItem(row, 0, tag_item)
            self.releases_table.setItem(row, 1, QtWidgets.QTableWidgetItem(name))
            self.releases_table.setItem(row, 2, QtWidgets.QTableWidgetItem(self._asset_type(name)))
            self.releases_table.setItem(row, 3, QtWidgets.QTableWidgetItem(self._format_bytes(int(asset.get("size", 0)))))

            status_item = QtWidgets.QTableWidgetItem("Downloaded" if exists else "Not downloaded")
            status_item.setForeground(QtGui.QColor("#027a48") if exists else QtGui.QColor("#b42318"))
            self.releases_table.setItem(row, 4, status_item)

            loc_item = QtWidgets.QTableWidgetItem(dest if exists else "-")
            self.releases_table.setItem(row, 5, loc_item)

        if self._release_assets:
            tags = {a.get("tag", "untagged") for a in self._release_assets}
            self.releases_status_label.setText(
                f"Found {len(self._release_assets)} model assets across {len(tags)} releases."
            )
            self.releases_table.selectRow(0)
        else:
            self.releases_status_label.setText(
                "No machine learning model assets found in GitHub releases (.pth, .tf, .tflite, etc.)."
            )

        self.check_releases_btn.setEnabled(True)
        self._update_release_download_button_state()

    def _on_releases_scan_failed(self, message):
        self.releases_progress.setRange(0, 100)
        self.releases_progress.setValue(0)
        self.releases_status_label.setText(f"Release check failed: {message}")
        self.check_releases_btn.setEnabled(True)
        self.download_release_btn.setEnabled(False)

    def _refresh_release_rows_status(self):
        rows = self.releases_table.rowCount() if hasattr(self, "releases_table") else 0
        for row in range(rows):
            asset_item = self.releases_table.item(row, 0)
            if asset_item is None:
                continue
            asset = asset_item.data(QtCore.Qt.ItemDataRole.UserRole) or {}
            dest = self._release_asset_destination(asset.get("tag", "untagged"), asset.get("asset_name", ""))
            exists = os.path.exists(dest)
            status_item = self.releases_table.item(row, 4)
            loc_item = self.releases_table.item(row, 5)
            if status_item is not None:
                status_item.setText("Downloaded" if exists else "Not downloaded")
                status_item.setForeground(QtGui.QColor("#027a48") if exists else QtGui.QColor("#b42318"))
            if loc_item is not None:
                loc_item.setText(dest if exists else "-")

    def _update_release_download_button_state(self):
        if not hasattr(self, "releases_table"):
            return
        selected = self.releases_table.selectionModel().selectedRows() if self.releases_table.selectionModel() else []
        if not selected:
            self.download_release_btn.setEnabled(False)
            return
        row = selected[0].row()
        asset_item = self.releases_table.item(row, 0)
        if asset_item is None:
            self.download_release_btn.setEnabled(False)
            return
        asset = asset_item.data(QtCore.Qt.ItemDataRole.UserRole) or {}
        dest = self._release_asset_destination(asset.get("tag", "untagged"), asset.get("asset_name", ""))
        self.download_release_btn.setEnabled(not os.path.exists(dest))

    def _download_selected_release_asset(self):
        selected = self.releases_table.selectionModel().selectedRows() if self.releases_table.selectionModel() else []
        if not selected:
            self.releases_status_label.setText("Select a release asset first.")
            return
        row = selected[0].row()
        asset_item = self.releases_table.item(row, 0)
        asset = asset_item.data(QtCore.Qt.ItemDataRole.UserRole) if asset_item is not None else None
        if not asset:
            self.releases_status_label.setText("Invalid release asset selection.")
            return

        url = asset.get("download_url", "")
        name = asset.get("asset_name", "")
        tag = asset.get("tag", "untagged")
        dest = self._release_asset_destination(tag, name)
        if not url:
            self.releases_status_label.setText("Selected asset does not contain a download URL.")
            return
        if os.path.exists(dest):
            self.releases_status_label.setText(f"Already downloaded: {dest}")
            self._update_release_download_button_state()
            return

        self.check_releases_btn.setEnabled(False)
        self.download_release_btn.setEnabled(False)
        self.releases_progress.show()
        self.releases_progress.setRange(0, 100)
        self.releases_progress.setValue(0)
        self.releases_status_label.setText(f"Downloading {name} from {tag}...")

        self._release_download_thread = ModelDownloadThread(url, dest, self)
        self._release_download_thread.progressChanged.connect(self._on_release_download_progress)
        self._release_download_thread.completed.connect(self._on_release_download_complete)
        self._release_download_thread.failed.connect(self._on_release_download_failed)
        self._release_download_thread.start()

    def _on_release_download_progress(self, pct, message):
        if pct < 0:
            self.releases_progress.setRange(0, 0)
        else:
            if self.releases_progress.maximum() == 0:
                self.releases_progress.setRange(0, 100)
            self.releases_progress.setValue(pct)
        self.releases_status_label.setText(message)

    def _on_release_download_complete(self, path):
        self.releases_progress.setRange(0, 100)
        self.releases_progress.setValue(100)
        self.releases_status_label.setText(f"Downloaded: {path}")
        self.check_releases_btn.setEnabled(True)
        self._refresh_release_rows_status()
        self._update_release_download_button_state()

    def _on_release_download_failed(self, message):
        self.releases_progress.setRange(0, 100)
        self.releases_progress.setValue(0)
        self.releases_status_label.setText(f"Download failed: {message}")
        self.check_releases_btn.setEnabled(True)
        self._update_release_download_button_state()

    def _browse_model_file(self):
        start_dir = self._default_model_directory()
        if not os.path.isdir(start_dir):
            start_dir = os.path.expanduser("~")
        fname, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select Model File",
            start_dir,
            "Model Files (*.pth)",
        )
        if not fname:
            return
        try:
            from .model import set_model_path
            set_model_path(fname)
            self.model_progress_text.setText(f"Selected model: {fname}")
            self.model_progress_text.show()
            self._refresh_model_status()
        except Exception as exc:
            QtWidgets.QMessageBox.warning(self, "Model Selection Error", str(exc))

    def _download_model_file(self):
        dest = self._expected_model_path()
        self.model_download_btn.setEnabled(False)
        self.model_browse_btn.setEnabled(False)
        self.model_refresh_btn.setEnabled(False)
        self.model_progress.show()
        self.model_progress.setRange(0, 100)
        self.model_progress.setValue(0)
        self.model_progress_text.setText("Starting download...")
        self.model_progress_text.show()

        self._download_thread = ModelDownloadThread(MODEL_DOWNLOAD_URL, dest, self)
        self._download_thread.progressChanged.connect(self._on_model_download_progress)
        self._download_thread.completed.connect(self._on_model_download_complete)
        self._download_thread.failed.connect(self._on_model_download_failed)
        self._download_thread.start()

    def _on_model_download_progress(self, pct, message):
        if pct < 0:
            self.model_progress.setRange(0, 0)
        else:
            if self.model_progress.maximum() == 0:
                self.model_progress.setRange(0, 100)
            self.model_progress.setValue(pct)
        self.model_progress_text.setText(message)

    def _on_model_download_complete(self, path):
        self.model_progress.setRange(0, 100)
        self.model_progress.setValue(100)
        self.model_progress_text.setText(f"Downloaded to: {path}")
        try:
            from .model import set_model_path
            set_model_path(path)
        except Exception:
            pass
        self.model_download_btn.setEnabled(True)
        self.model_browse_btn.setEnabled(True)
        self.model_refresh_btn.setEnabled(True)
        self._refresh_model_status()

    def _on_model_download_failed(self, error_message):
        self.model_progress.hide()
        self.model_progress_text.setText(f"Download failed: {error_message}")
        self.model_progress_text.show()
        self.model_download_btn.setEnabled(True)
        self.model_browse_btn.setEnabled(True)
        self.model_refresh_btn.setEnabled(True)
        QtWidgets.QMessageBox.warning(self, "Download Failed", error_message)

    def _update_health(self, package_info):
        missing_count = len(package_info["missing"])
        timestamp = QtCore.QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
        if missing_count == 0:
            self.health_chip.setText(f"Status: Healthy | {timestamp}")
            self._set_chip_colors(self.health_chip, "#ecfdf3", "#027a48")
        else:
            self.health_chip.setText(f"Status: Attention ({missing_count} missing) | {timestamp}")
            self._set_chip_colors(self.health_chip, "#fff4ed", "#b42318")

    def _set_health_chip_colors(self, bg, fg):
        self._set_chip_colors(self.health_chip, bg, fg)

    def _set_chip_colors(self, label, bg, fg):
        label.setStyleSheet(
            "padding: 2px 6px; border-radius: 8px; font-size: 10px; font-weight: 600;"
            f"background: {bg}; color: {fg};"
        )

    def apply_theme_palette(self, theme: str, accent_color: str, theme_color=None):
        if theme_color:
            panel_bg = theme_color
            header_bg = self._shade_color(theme_color, 0.92)
            table_bg = self._shade_color(theme_color, 0.96)
            button_bg = self._shade_color(theme_color, 0.9)
            button_hover = self._shade_color(theme_color, 1.06)
            border = self._shade_color(theme_color, 0.78)
            text = self._ideal_text_color(theme_color)
            muted = self._shade_color(text, 1.3 if text == "#111111" else 0.75)
        else:
            if theme == "dark":
                panel_bg = "#1f2630"
                header_bg = "#252f3b"
                table_bg = "#1b222b"
                button_bg = "#2a3442"
                button_hover = "#334154"
                border = "#3e4a5a"
                text = "#e8edf4"
                muted = "#b6c0cf"
            else:
                panel_bg = "#f8fafc"
                header_bg = "#eef3f8"
                table_bg = "#ffffff"
                button_bg = "#f4f6f8"
                button_hover = "#e9edf2"
                border = "#d6dde5"
                text = "#1f2937"
                muted = "#5b6574"

        self.setStyleSheet(
            "QWidget#EnvironmentReportPanel {"
            f"background: {panel_bg}; color: {text};"
            f"border: 1px solid {border}; border-radius: 10px;"
            "}"
            "QFrame#EnvironmentHeader {"
            f"background: {header_bg}; border: 1px solid {border}; border-radius: 8px;"
            "}"
            "QLabel#EnvironmentSubtitle {"
            f"color: {muted};"
            "}"
            "QLabel#PackagesSummary {"
            f"color: {muted};"
            "}"
            "QGroupBox { font-weight: 600; border: 1px solid transparent; margin-top: 8px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 4px; padding: 0 3px; }"
            "QTableWidget {"
            f"background: {table_bg}; border: 1px solid {border}; border-radius: 6px;"
            "gridline-color: #d9d9d9;"
            "}"
            "QHeaderView::section { font-weight: 600; }"
            "QPushButton {"
            f"background: {button_bg}; color: {text}; border: 1px solid {border};"
            "padding: 5px 12px; border-radius: 6px;"
            "}"
            "QPushButton:hover {"
            f"background: {button_hover}; border-color: {accent_color};"
            "}"
            "QTabWidget::pane {"
            f"border: 1px solid {border}; border-radius: 8px;"
            "top: -1px;"
            "}"
            "QTabBar::tab {"
            f"background: {button_bg}; border: 1px solid {border};"
            "padding: 6px 12px; margin-right: 4px; border-top-left-radius: 6px; border-top-right-radius: 6px;"
            "}"
            "QTabBar::tab:selected {"
            f"background: {table_bg}; border-color: {accent_color};"
            "}"
            "QLabel { font-size: 12px; }"
        )

    def _ideal_text_color(self, hex_color: str) -> str:
        r, g, b = self._hex_to_rgb(hex_color)
        luminance = (0.299 * r) + (0.587 * g) + (0.114 * b)
        return "#111111" if luminance > 186 else "#f5f5f5"

    def _shade_color(self, hex_color: str, factor: float) -> str:
        r, g, b = self._hex_to_rgb(hex_color)
        r = self._clamp(int(r * factor))
        g = self._clamp(int(g * factor))
        b = self._clamp(int(b * factor))
        return f"#{r:02x}{g:02x}{b:02x}"

    @staticmethod
    def _hex_to_rgb(hex_color: str):
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

    @staticmethod
    def _clamp(value: int, minimum: int = 0, maximum: int = 255) -> int:
        return max(minimum, min(maximum, value))

    def _build_report_text(self, system_info, python_info, gpu_info, package_info):
        lines = ["BrainSeg Environment Report", "=" * 28, ""]

        lines.append("System")
        lines.append("------")
        lines.extend([f"{k}: {v}" for k, v in system_info])
        lines.append("")

        lines.append("Python")
        lines.append("------")
        lines.extend([f"{k}: {v}" for k, v in python_info])
        lines.append("")

        lines.append("GPU")
        lines.append("---")
        lines.extend([f"{k}: {v}" for k, v in gpu_info])
        lines.append("")

        lines.append("Packages")
        lines.append("--------")
        for name, ver in package_info["found"]:
            lines.append(f"Installed - {name}: {ver}")
        for name in package_info["missing"]:
            lines.append(f"Missing - {name}")

        return "\n".join(lines)

    def _collect_system_info(self):
        physical_cores = psutil.cpu_count(logical=False)
        logical_cores = psutil.cpu_count(logical=True)
        total_ram_gb = psutil.virtual_memory().total / (1024 ** 3)

        return [
            ("OS", f"{platform.system()} {platform.release()}"),
            ("OS version", platform.version()),
            ("Platform", platform.platform()),
            ("Machine", platform.machine()),
            ("CPU", platform.processor() or "Unknown"),
            ("CPU cores", f"physical={physical_cores}, logical={logical_cores}"),
            ("Total RAM", f"{total_ram_gb:.2f} GB"),
        ]

    def _collect_python_info(self):
        return [
            ("Version", platform.python_version()),
            ("Executable", sys.executable),
            ("Prefix", sys.prefix),
        ]

    def _collect_gpu_info(self):
        details = []

        try:
            import torch

            details.append(("PyTorch", torch.__version__))
            if torch.cuda.is_available():
                count = torch.cuda.device_count()
                details.append(("CUDA available", "yes"))
                details.append(("CUDA devices", str(count)))
                for idx in range(count):
                    name = torch.cuda.get_device_name(idx)
                    details.append((f"GPU {idx}", name))
            else:
                details.append(("CUDA available", "no"))

            mps = getattr(torch.backends, "mps", None)
            if mps is not None:
                details.append(("Apple MPS available", "yes" if mps.is_available() else "no"))
        except Exception as exc:
            details.append(("PyTorch GPU probe", f"failed: {exc}"))

        smi = self._query_nvidia_smi()
        if smi:
            for i, line in enumerate(smi, start=1):
                details.append((f"nvidia-smi #{i}", line))

        if not details:
            details.append(("GPU", "No GPU information detected."))

        return details

    def _query_nvidia_smi(self):
        executable = shutil.which("nvidia-smi")
        if executable is None:
            return []

        cmd = [
            executable,
            "--query-gpu=name,driver_version,memory.total,memory.free",
            "--format=csv,noheader",
        ]
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=2,
                check=False,
            )
        except Exception:
            return []

        if result.returncode != 0:
            stderr_line = (result.stderr or "").strip()
            return [f"command returned exit code {result.returncode}", stderr_line] if stderr_line else []

        lines = [line.strip() for line in (result.stdout or "").splitlines() if line.strip()]
        return lines

    def _collect_package_info(self):
        found = []
        missing = []

        for pkg in REQUIRED_PACKAGES:
            try:
                found.append((pkg, version(pkg)))
            except PackageNotFoundError:
                missing.append(pkg)
            except Exception as exc:
                found.append((pkg, f"error: {exc}"))

        return {"found": found, "missing": missing}
