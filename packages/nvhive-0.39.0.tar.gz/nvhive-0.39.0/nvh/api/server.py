"""Council REST API server.

Dependencies (add to pyproject.toml):
    fastapi>=0.115
    uvicorn[standard]>=0.30
"""

from __future__ import annotations

import asyncio
import hmac
import inspect
import ipaddress
import json
import logging
import os
import time
import uuid
from collections import defaultdict
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from pathlib import Path as FilePath
from typing import Any
from urllib.parse import urlparse

from fastapi import (
    Depends,
    FastAPI,
    File,
    HTTPException,
    Path,
    Request,
    UploadFile,
    WebSocket,
    WebSocketDisconnect,
    status,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response, StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field, field_validator

from nvh.api.services import QueryService
from nvh.core.agents import generate_agents, get_preset_agents, list_presets
from nvh.core.engine import BudgetExceededError, Engine
from nvh.providers.base import (
    CompletionResponse,
    Message,
    ProviderError,
)

# Service-layer singletons. Stateless; safe to share across requests.
_query_service = QueryService()
from nvh.utils.gpu import (
    check_oom_risk,
    detect_gpu_status,
    detect_gpus,
    detect_system_memory,
    get_gpu_summary,
    get_ollama_optimizations,
    gpu_architecture_info,
    recommend_models,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Optional API key authentication
# ---------------------------------------------------------------------------

_bearer_scheme = HTTPBearer(auto_error=False)


def _get_council_api_key() -> str | None:
    """Return the HIVE_API_KEY env var if set, otherwise None (open mode)."""
    return os.environ.get("HIVE_API_KEY") or None


async def _get_current_user_optional(
    credentials: HTTPAuthorizationCredentials | None,
    x_key: str | None,
) -> Any | None:
    """Try to resolve a User from a bearer token if user auth is enabled.

    Returns the User object on success, None if user auth is not active or the
    token does not resolve to a user-based token.
    """
    from nvh.auth.auth import get_user_by_token, get_user_count
    try:
        if await get_user_count() == 0:
            return None  # no users registered — fall through to API key mode
    except Exception:
        return None

    token: str | None = None
    if credentials:
        token = credentials.credentials
    elif x_key:
        token = x_key

    if token is None:
        return None

    return await get_user_by_token(token)


async def require_auth(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
) -> Any:
    """FastAPI dependency that enforces authentication.

    Priority:
    1. User-based auth (when users table has entries): validates API tokens
       created via the /v1/auth/* endpoints.
    2. Simple HIVE_API_KEY env var (single-user, legacy).
    3. Open/local mode — when neither users nor HIVE_API_KEY are configured.

    Accepts credentials via:
    - ``Authorization: Bearer <token>`` header
    - ``X-Hive-API-Key: <key>`` header
    """
    x_key = request.headers.get("X-Hive-API-Key")

    # Try user-based auth first
    user = await _get_current_user_optional(credentials, x_key)
    if user is not None:
        if not user.is_active:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User account is disabled.",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return user

    # Fall back to simple API key
    expected = _get_council_api_key()
    if expected is None:
        # Open mode — no auth required
        return None

    # Check Bearer token
    if credentials and hmac.compare_digest(credentials.credentials, expected):
        return None

    # Check X-Hive-API-Key header
    if x_key and hmac.compare_digest(x_key, expected):
        return None

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=(
            "Authentication required. Provide a valid API key via "
            "'Authorization: Bearer <key>' or 'X-Hive-API-Key: <key>' header."
        ),
        headers={"WWW-Authenticate": "Bearer"},
    )


async def require_user_auth(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
) -> Any:
    """Strict user-based auth dependency — requires a valid user API token.

    Used for /v1/auth/* endpoints that manage users and tokens.
    """
    x_key = request.headers.get("X-Hive-API-Key")
    user = await _get_current_user_optional(credentials, x_key)
    if user is None or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Valid user authentication token required.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user


def require_scope(scope: str):
    """Dependency factory that enforces a required OAuth-style scope on the user."""
    async def _check(user: Any = Depends(require_user_auth)) -> Any:
        if hasattr(user, '_scopes') and scope not in user._scopes and "admin" not in user._scopes:
            raise HTTPException(status_code=403, detail=f"Insufficient scope: requires '{scope}'")
        return user
    return _check


# ---------------------------------------------------------------------------
# Rate limiting for auth endpoints
# ---------------------------------------------------------------------------

_auth_attempts: dict[str, list[float]] = defaultdict(list)
AUTH_RATE_LIMIT = 5  # attempts per minute


def _check_auth_rate_limit(client_ip: str) -> None:
    """Raise HTTP 429 if the client has exceeded the auth rate limit."""
    now = time.time()
    attempts = _auth_attempts[client_ip]
    # Remove attempts older than 60 seconds
    _auth_attempts[client_ip] = [t for t in attempts if now - t < 60]
    if len(_auth_attempts[client_ip]) >= AUTH_RATE_LIMIT:
        raise HTTPException(status_code=429, detail="Too many attempts. Try again in 60 seconds.")
    _auth_attempts[client_ip].append(now)


# ---------------------------------------------------------------------------
# WebSocket authentication helper
# ---------------------------------------------------------------------------

async def _authenticate_websocket(websocket: WebSocket) -> bool:
    """Validate WebSocket auth via query param or Authorization header."""
    # Check query param: ?token=xxx
    token = websocket.query_params.get("token")
    if not token:
        # Also check Authorization header (some WS clients support it)
        auth_header = websocket.headers.get("authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]

    if not token:
        # Check HIVE_API_KEY
        expected = os.environ.get("HIVE_API_KEY", "")
        if not expected:
            return True  # Open mode
        await websocket.close(code=4001, reason="Authentication required")
        return False

    # Validate against simple API key
    expected = os.environ.get("HIVE_API_KEY", "")
    if expected and hmac.compare_digest(token, expected):
        return True

    # Try user token
    try:
        from nvh.auth.auth import get_user_by_token
        user = await get_user_by_token(token)
        if user:
            return True
    except Exception:
        logger.warning("WebSocket auth: token validation failed", exc_info=True)

    await websocket.close(code=4003, reason="Invalid token")
    return False


# ---------------------------------------------------------------------------
# SSRF protection for webhook URLs
# ---------------------------------------------------------------------------

def _validate_webhook_url(url: str) -> None:
    """Raise ValueError if the URL is unsafe (private/loopback IPs, bad scheme, etc.)."""
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError("URL must use http or https")
    hostname = parsed.hostname
    if not hostname:
        raise ValueError("Invalid URL")
    # Block cloud metadata endpoints (check before IP parse)
    if hostname in ("169.254.169.254", "metadata.google.internal"):
        raise ValueError("Cannot send webhooks to cloud metadata endpoints")
    # Block internal/private IPs
    try:
        ip = ipaddress.ip_address(hostname)
        if ip.is_private or ip.is_loopback or ip.is_link_local:
            raise ValueError("Cannot send webhooks to private/internal addresses")
    except ValueError as exc:
        # Re-raise only our own explicit errors; a non-IP hostname is fine
        if "Cannot send webhooks" in str(exc):
            raise


# ---------------------------------------------------------------------------
# Shared engine instance
# ---------------------------------------------------------------------------

_engine: Engine | None = None


def get_engine() -> Engine:
    if _engine is None:
        raise RuntimeError("Engine not initialized. Server startup failed.")
    return _engine


async def _run_boot_preflight_on_startup(app: FastAPI) -> None:
    if os.environ.get("NVH_BOOT_PREFLIGHT", "1").lower() in {"0", "false", "off", "no"}:
        logger.info("Hive API: boot preflight disabled by NVH_BOOT_PREFLIGHT.")
        return
    try:
        from nvh.integrations.diagnostics.boot_preflight import run_boot_preflight

        result = await asyncio.to_thread(run_boot_preflight)
        app.state.boot_preflight = result
        logger.info("Hive API: boot preflight complete. %s", result.get("summary"))
    except Exception as exc:
        app.state.boot_preflight = {
            "summary": "Boot preflight failed",
            "error": str(exc),
            "changes": [],
            "agent_helper": {
                "offline_helper_ready": True,
                "local_agent_ready": False,
                "mode": "offline-deterministic",
                "recommended_action_id": "agent-lab",
                "summary": "Offline setup helper is still available.",
                "requirements": [],
            },
        }
        logger.warning("Hive API: boot preflight failed: %s", exc)


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    global _engine
    boot_task: asyncio.Task[None] | None = None
    from nvh.utils.logging import setup_logging
    json_mode = os.environ.get("HIVE_LOG_FORMAT", "text") == "json"
    setup_logging(level=os.environ.get("HIVE_LOG_LEVEL", "INFO"), json_format=json_mode)
    logger.info("Hive API: initializing engine...")
    try:
        _engine = Engine()
        enabled = await _engine.initialize()
        logger.info("Hive API: engine ready. Advisors: %s", ", ".join(enabled) or "none")
        boot_task = asyncio.create_task(_run_boot_preflight_on_startup(app))
        yield
    except Exception as exc:
        logger.error("Hive API: engine initialization error: %s", exc)
        boot_task = asyncio.create_task(_run_boot_preflight_on_startup(app))
        # Don't crash — partial init is fine; requests will fail gracefully.
        yield
    finally:
        if boot_task and not boot_task.done():
            boot_task.cancel()
        logger.info("Hive API: shutting down.")
        if _engine:
            if hasattr(_engine, 'webhooks') and _engine.webhooks:
                await _engine.webhooks.stop()
        from nvh.storage.repository import close_db
        await close_db()
        _engine = None


# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

app = FastAPI(
    title="Hive API",
    description="REST API for the Hive multi-LLM orchestration platform.",
    version="1.0.0",
    lifespan=lifespan,
)

_DEFAULT_CORS_ORIGINS = [
    # Common Next.js dev ports
    "http://localhost:3000", "http://127.0.0.1:3000",
    "http://localhost:3001", "http://127.0.0.1:3001",
    "http://localhost:3002", "http://127.0.0.1:3002",
    "http://localhost:8080", "http://127.0.0.1:8080",
    # `nvh webui` may bind port 80 and advertise the `nvhive` hostname
    "http://localhost", "http://127.0.0.1",
    "http://nvhive", "http://nvhive:3000", "http://nvhive:3001",
    "http://nvhive:3002", "http://nvhive:8080",
]
_cors_env = os.environ.get("HIVE_CORS_ORIGINS")
ALLOWED_ORIGINS = (
    [o.strip() for o in _cors_env.split(",") if o.strip()]
    if _cors_env
    else _DEFAULT_CORS_ORIGINS
)
LOCAL_WEBUI_ORIGIN_REGEX = os.environ.get(
    "HIVE_CORS_ORIGIN_REGEX",
    r"^http://(localhost|127\.0\.0\.1|nvhive|\[::1\])(:\d+)?$",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_origin_regex=LOCAL_WEBUI_ORIGIN_REGEX,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def request_logging_middleware(request: Request, call_next):
    """Attach a request id, log latency, and return safe unexpected errors."""
    from nvh.utils.logging import reset_request_id, set_request_id

    request_id = request.headers.get("x-request-id") or uuid.uuid4().hex
    token = set_request_id(request_id)
    start = time.perf_counter()
    try:
        response = await call_next(request)
        duration_ms = round((time.perf_counter() - start) * 1000, 2)
        level = logging.WARNING if response.status_code >= 500 else logging.INFO
        logger.log(
            level,
            "HTTP request complete",
            extra={
                "request_id": request_id,
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code,
                "duration_ms": duration_ms,
                "client": request.client.host if request.client else "",
            },
        )
        response.headers["X-Request-ID"] = request_id
        return response
    except Exception:
        duration_ms = round((time.perf_counter() - start) * 1000, 2)
        error_id = uuid.uuid4().hex[:12]
        logger.exception(
            "Unhandled API request error",
            extra={
                "request_id": request_id,
                "error_id": error_id,
                "method": request.method,
                "path": request.url.path,
                "status_code": 500,
                "duration_ms": duration_ms,
                "client": request.client.host if request.client else "",
            },
        )
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            headers={"X-Request-ID": request_id, "X-Error-ID": error_id},
            content={
                "status": "error",
                "error": {
                    "type": "internal_server_error",
                    "message": "Internal server error",
                    "request_id": request_id,
                    "error_id": error_id,
                },
                "detail": "Internal server error",
                "request_id": request_id,
            },
        )
    finally:
        reset_request_id(token)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _decimal_to_str(value: Decimal | None) -> str | None:
    """Serialize Decimal to string to preserve precision."""
    return str(value) if value is not None else None


def _response_envelope(data: Any) -> dict[str, Any]:
    return {"status": "success", "data": data}


def _serialize_completion(resp: CompletionResponse) -> dict[str, Any]:
    return {
        "content": resp.content,
        "model": resp.model,
        "provider": resp.provider,
        "usage": resp.usage.model_dump(),
        "cost_usd": _decimal_to_str(resp.cost_usd),
        "latency_ms": resp.latency_ms,
        "finish_reason": resp.finish_reason.value,
        "cache_hit": resp.cache_hit,
        "fallback_from": resp.fallback_from,
        "metadata": resp.metadata,
    }


# ---------------------------------------------------------------------------
# Request / Response Schemas
# ---------------------------------------------------------------------------

_AUTO_SELECTION_VALUES = {
    "auto",
    "auto-pick",
    "auto pick",
    "auto-pick best available",
    "recommended",
    "recommended model",
    "best available",
    "default",
    "none",
}


def _normalize_optional_selection(value: Any) -> str | None:
    """Treat UI placeholder choices as an omitted provider/model."""
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if text.lower() in _AUTO_SELECTION_VALUES:
        return None
    return text


class QueryAttachment(BaseModel):
    name: str = Field(default="", max_length=255)
    content: str = Field(..., min_length=1, max_length=25_000_000)
    mime_type: str | None = Field(default=None, max_length=120)
    is_image: bool = False


class QueryRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=500_000)
    provider: str | None = None
    model: str | None = None
    system_prompt: str | None = None
    temperature: float | None = Field(default=None, ge=0.0, le=2.0)
    max_tokens: int | None = Field(default=None, gt=0)
    stream: bool = False
    attachments: list[QueryAttachment] = Field(default_factory=list, max_length=6)

    @field_validator("provider", "model", mode="before")
    @classmethod
    def _normalize_provider_model(cls, value: Any) -> str | None:
        return _normalize_optional_selection(value)


def _request_has_image_attachments(request: QueryRequest) -> bool:
    return any(att.is_image for att in request.attachments)


def _query_user_content(request: QueryRequest) -> str | list[dict[str, Any]]:
    """Return text-only or OpenAI-style multimodal message content."""
    image_attachments = [att for att in request.attachments if att.is_image]
    if not image_attachments:
        return request.prompt

    parts: list[dict[str, Any]] = [{"type": "text", "text": request.prompt}]
    for att in image_attachments[:4]:
        parts.append({
            "type": "image_url",
            "image_url": {"url": att.content},
        })
    return parts


class CouncilRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=500_000)
    members: list[str] | None = None
    weights: dict[str, float] | None = None
    strategy: str | None = None
    auto_agents: bool = False
    preset: str | None = None
    num_agents: int | None = Field(default=None, gt=0, le=10)
    synthesize: bool = True
    system_prompt: str | None = None
    temperature: float | None = Field(default=None, ge=0.0, le=2.0)
    max_tokens: int | None = Field(default=None, gt=0)


class CompareRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=500_000)
    providers: list[str] | None = None
    system_prompt: str | None = None
    temperature: float | None = Field(default=None, ge=0.0, le=2.0)
    max_tokens: int | None = Field(default=None, gt=0)


class AgentAnalyzeRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=500_000)
    num_agents: int = Field(default=3, gt=0, le=10)
    preset: str | None = None


# ---------------------------------------------------------------------------
# Utilities — streaming
# ---------------------------------------------------------------------------

async def _sse_query_stream(
    engine: Engine,
    request: QueryRequest,
) -> AsyncGenerator:
    """Async generator that yields SSE-formatted bytes for a streaming query."""
    from nvh.providers.base import StreamChunk

    config = engine.config
    temp = request.temperature if request.temperature is not None else config.defaults.temperature
    max_tok = request.max_tokens or config.defaults.max_tokens
    sys_prompt = request.system_prompt or config.defaults.system_prompt or None

    # Budget and routing (reuse engine internals via a lightweight path)
    try:
        await engine.initialize()
        await engine._check_budget()
    except BudgetExceededError as exc:
        payload = json.dumps({"error": str(exc)})
        yield f"event: error\ndata: {payload}\n\n".encode()
        return
    except Exception as exc:
        logger.exception("Streaming query preflight failed")
        payload = json.dumps({
            "error": f"Local query preflight failed: {type(exc).__name__}: {exc}",
        })
        yield f"event: error\ndata: {payload}\n\n".encode()
        return

    try:
        decision = engine.router.route(
            query=request.prompt,
            provider_override=request.provider,
            model_override=request.model,
        )
    except Exception as exc:
        logger.exception("Streaming query routing failed")
        payload = json.dumps({
            "error": f"Could not choose an AI advisor: {type(exc).__name__}: {exc}",
        })
        yield f"event: error\ndata: {payload}\n\n".encode()
        return

    if not engine.registry.has(decision.provider):
        payload = json.dumps({"error": f"Provider '{decision.provider}' not available."})
        yield f"event: error\ndata: {payload}\n\n".encode()
        return

    provider = engine.registry.get(decision.provider)

    messages: list[Message] = []
    if sys_prompt:
        messages.append(Message(role="system", content=sys_prompt))
    messages.append(Message(role="user", content=_query_user_content(request)))

    accumulated = ""
    last_chunk: StreamChunk | None = None

    # Per-chunk stall timeout — local Ollama can spend a while loading a fresh
    # model into VRAM on first use, so give it more warmup room than cloud APIs.
    CHUNK_STALL_TIMEOUT = 180.0 if decision.provider == "ollama" else 45.0  # noqa: N806

    try:
        stream_result = provider.stream(
            messages=messages,
            model=decision.model or None,
            temperature=temp,
            max_tokens=max_tok,
            system_prompt=sys_prompt,
            prefer_vision=_request_has_image_attachments(request),
        )
        if inspect.isawaitable(stream_result):
            stream_result = await stream_result
        aiter = stream_result.__aiter__()

        while True:
            try:
                chunk = await asyncio.wait_for(
                    aiter.__anext__(),
                    timeout=CHUNK_STALL_TIMEOUT,
                )
            except StopAsyncIteration:
                break
            except TimeoutError as exc:
                raise TimeoutError(
                    f"Provider '{decision.provider}' stalled — no tokens for "
                    f"{CHUNK_STALL_TIMEOUT:.0f}s"
                ) from exc

            last_chunk = chunk
            if chunk.delta:
                accumulated += chunk.delta
                payload = json.dumps({
                    "delta": chunk.delta,
                    "accumulated": accumulated,
                })
                yield f"event: chunk\ndata: {payload}\n\n".encode()

            if chunk.is_final:
                break

        # Final done event
        done_payload: dict[str, Any] = {
            "content": accumulated,
            "provider": decision.provider,
            "model": decision.model,
        }
        if last_chunk:
            if last_chunk.usage:
                done_payload["usage"] = last_chunk.usage.model_dump()
            if last_chunk.cost_usd is not None:
                done_payload["cost_usd"] = _decimal_to_str(last_chunk.cost_usd)
            if last_chunk.finish_reason:
                done_payload["finish_reason"] = last_chunk.finish_reason.value

        yield f"event: done\ndata: {json.dumps(done_payload)}\n\n".encode()

    except Exception as exc:
        payload = json.dumps({"error": str(exc)})
        yield f"event: error\ndata: {payload}\n\n".encode()


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

# -- /v1/health ---------------------------------------------------------------

@app.get("/v1/health", summary="API health check")
async def health_check() -> dict[str, Any]:
    engine = get_engine()
    enabled = engine.registry.list_enabled()
    return _response_envelope({
        "status": "ok",
        "engine_initialized": engine._initialized,
        "providers_enabled": len(enabled),
    })


@app.get("/v1/ready", summary="Rootless workspace readiness check")
async def readiness_check(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return a compact readiness signal for launchers and setup clients."""
    try:
        from nvh.integrations.diagnostics.production_readiness import production_readiness_report

        report = production_readiness_report(home_dir=home_dir)
        payload = {
            "status": report.get("status", "blocked"),
            "ready": bool(report.get("pilot_ready")),
            "production_ready": bool(report.get("production_ready")),
            "summary": report.get("summary"),
            "counts": report.get("counts", {}),
            "next_actions": list(report.get("next_actions", []))[:3],
            "storage_home": report.get("inputs", {}).get("storage_home"),
        }
    except Exception as exc:
        logger.warning("Readiness check failed: %s", type(exc).__name__, exc_info=True)
        payload = {
            "status": "blocked",
            "ready": False,
            "production_ready": False,
            "summary": "Readiness check failed. Open Advanced Details for the diagnostic report.",
            "counts": {"passed": 0, "warnings": 0, "blocked": 1, "total": 1},
            "next_actions": ["Generate a support bundle and inspect the API logs."],
            "storage_home": None,
            "error": {"type": type(exc).__name__, "message": "Readiness check failed."},
        }
    return _response_envelope(payload)


# -- /metrics (Prometheus) ----------------------------------------------------


def _prom_escape(value: str) -> str:
    """Escape a label value for Prometheus text exposition format."""
    return value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


async def _build_prometheus_metrics() -> str:
    """Build Prometheus text exposition format from nvHive internal data."""
    from sqlalchemy import func as _fn
    from sqlalchemy import select as _sel

    from nvh.storage import repository as _metrics_repo
    from nvh.storage.models import QueryLog

    lines: list[str] = []
    engine = get_engine()

    # ------------------------------------------------------------------
    # 1) nvhive_queries_total — counter by provider, model, task_type (mode), status
    # ------------------------------------------------------------------
    try:
        from nvh.storage.repository import get_session as _get_sess

        async with _get_sess() as session:
            rows = (await session.execute(
                _sel(
                    QueryLog.provider,
                    QueryLog.model,
                    QueryLog.mode,
                    QueryLog.status,
                    _fn.count(QueryLog.id),
                ).group_by(QueryLog.provider, QueryLog.model, QueryLog.mode, QueryLog.status)
            )).all()

        lines.append("# HELP nvhive_queries_total Total queries processed")
        lines.append("# TYPE nvhive_queries_total counter")
        for prov, model, mode, st, cnt in rows:
            labels = (
                f'provider="{_prom_escape(prov)}",'
                f'model="{_prom_escape(model)}",'
                f'task_type="{_prom_escape(mode)}",'
                f'status="{_prom_escape(st)}"'
            )
            lines.append(f"nvhive_queries_total{{{labels}}} {cnt}")
    except Exception:
        logger.debug("metrics: failed to collect nvhive_queries_total", exc_info=True)

    # ------------------------------------------------------------------
    # 2) nvhive_query_latency_seconds — histogram approximation per provider
    #    We expose the sum and count; real histogram buckets would need
    #    in-process instrumentation.  Sum+count is still useful for rate().
    # ------------------------------------------------------------------
    try:
        async with _get_sess() as session:
            lat_rows = (await session.execute(
                _sel(
                    QueryLog.provider,
                    _fn.count(QueryLog.id),
                    _fn.sum(QueryLog.latency_ms),
                ).group_by(QueryLog.provider)
            )).all()

        lines.append("")
        lines.append("# HELP nvhive_query_latency_seconds Query latency in seconds")
        lines.append("# TYPE nvhive_query_latency_seconds histogram")
        for prov, cnt, total_ms in lat_rows:
            total_s = (total_ms or 0) / 1000.0
            lbl = f'provider="{_prom_escape(prov)}"'
            lines.append(f"nvhive_query_latency_seconds_count{{{lbl}}} {cnt}")
            lines.append(f"nvhive_query_latency_seconds_sum{{{lbl}}} {total_s:.3f}")
    except Exception:
        logger.debug("metrics: failed to collect nvhive_query_latency_seconds", exc_info=True)

    # ------------------------------------------------------------------
    # 3) nvhive_query_cost_usd — counter per provider
    # ------------------------------------------------------------------
    try:
        async with _get_sess() as session:
            cost_rows = (await session.execute(
                _sel(
                    QueryLog.provider,
                    _fn.coalesce(_fn.sum(QueryLog.cost_usd), 0),
                ).group_by(QueryLog.provider)
            )).all()

        lines.append("")
        lines.append("# HELP nvhive_query_cost_usd Total cost in USD")
        lines.append("# TYPE nvhive_query_cost_usd counter")
        for prov, cost in cost_rows:
            lbl = f'provider="{_prom_escape(prov)}"'
            lines.append(f"nvhive_query_cost_usd{{{lbl}}} {float(cost):.6f}")
    except Exception:
        logger.debug("metrics: failed to collect nvhive_query_cost_usd", exc_info=True)

    # ------------------------------------------------------------------
    # 4) nvhive_provider_health — gauge per provider (0.0-1.0)
    # ------------------------------------------------------------------
    try:
        enabled = engine.registry.list_enabled()
        lines.append("")
        lines.append("# HELP nvhive_provider_health Current health score per provider")
        lines.append("# TYPE nvhive_provider_health gauge")
        for prov_name in enabled:
            score = engine.rate_manager.get_health_score(prov_name)
            lbl = f'provider="{_prom_escape(prov_name)}"'
            lines.append(f"nvhive_provider_health{{{lbl}}} {score:.2f}")
    except Exception:
        logger.debug("metrics: failed to collect nvhive_provider_health", exc_info=True)

    # ------------------------------------------------------------------
    # 5) nvhive_council_queries_total — counter by strategy (mode=council)
    # ------------------------------------------------------------------
    try:
        async with _get_sess() as session:
            council_rows = (await session.execute(
                _sel(
                    QueryLog.mode,
                    _fn.count(QueryLog.id),
                ).where(QueryLog.mode == "council")
                .group_by(QueryLog.mode)
            )).all()

        lines.append("")
        lines.append("# HELP nvhive_council_queries_total Council queries processed")
        lines.append("# TYPE nvhive_council_queries_total counter")
        for strategy, cnt in council_rows:
            lbl = f'strategy="{_prom_escape(strategy)}"'
            lines.append(f"nvhive_council_queries_total{{{lbl}}} {cnt}")
        if not council_rows:
            lines.append('nvhive_council_queries_total{strategy="council"} 0')
    except Exception:
        logger.debug("metrics: failed to collect nvhive_council_queries_total", exc_info=True)

    # ------------------------------------------------------------------
    # 6) nvhive_fallback_total — counter by from_provider, to_provider
    # ------------------------------------------------------------------
    try:
        async with _get_sess() as session:
            fb_rows = (await session.execute(
                _sel(
                    QueryLog.fallback_from,
                    QueryLog.provider,
                    _fn.count(QueryLog.id),
                ).where(QueryLog.status == "fallback", QueryLog.fallback_from != "")
                .group_by(QueryLog.fallback_from, QueryLog.provider)
            )).all()

        lines.append("")
        lines.append("# HELP nvhive_fallback_total Fallback events")
        lines.append("# TYPE nvhive_fallback_total counter")
        for from_prov, to_prov, cnt in fb_rows:
            labels = (
                f'from_provider="{_prom_escape(from_prov)}",'
                f'to_provider="{_prom_escape(to_prov)}"'
            )
            lines.append(f"nvhive_fallback_total{{{labels}}} {cnt}")
        if not fb_rows:
            lines.append('nvhive_fallback_total{from_provider="",to_provider=""} 0')
    except Exception:
        logger.debug("metrics: failed to collect nvhive_fallback_total", exc_info=True)

    # ------------------------------------------------------------------
    # 7) nvhive_learning_observations_total — gauge
    # ------------------------------------------------------------------
    try:
        obs_count = await _metrics_repo.get_outcome_count()
        lines.append("")
        lines.append(
            "# HELP nvhive_learning_observations_total Total learning observations"
        )
        lines.append("# TYPE nvhive_learning_observations_total gauge")
        lines.append(f"nvhive_learning_observations_total {obs_count}")
    except Exception:
        logger.debug(
            "metrics: failed to collect nvhive_learning_observations_total",
            exc_info=True,
        )

    lines.append("")
    return "\n".join(lines)


@app.get("/metrics", summary="Prometheus metrics endpoint")
async def prometheus_metrics() -> Response:
    """Return nvHive metrics in Prometheus text exposition format."""
    body = await _build_prometheus_metrics()
    return Response(
        content=body,
        media_type="text/plain; version=0.0.4; charset=utf-8",
    )


@app.get("/v1/metrics", summary="Prometheus metrics endpoint (v1 alias)")
async def prometheus_metrics_v1() -> Response:
    """Alias for /metrics under the /v1/ prefix."""
    body = await _build_prometheus_metrics()
    return Response(
        content=body,
        media_type="text/plain; version=0.0.4; charset=utf-8",
    )


# -- /v1/system/gpu -----------------------------------------------------------

def _serialize_gpu_data() -> dict[str, Any]:
    """Detect GPUs and return serialisable dict. Never raises — returns empty on error."""
    try:
        gpu_status = detect_gpu_status()
        gpus = gpu_status["gpus"]
        sys_mem = detect_system_memory()
        summary = get_gpu_summary()
        total_vram_gb = round(sum(g.vram_mb for g in gpus) / 1024, 1) if gpus else 0.0

        gpu_list = []
        for g in gpus:
            arch = gpu_architecture_info(g)
            gpu_list.append(
                {
                    "name": g.name,
                    "vram_mb": g.vram_mb,
                    "vram_gb": g.vram_gb,
                    "memory_used_mb": g.memory_used_mb,
                    "memory_free_mb": g.memory_free_mb,
                    "memory_reserved_mb": max(g.vram_mb - g.memory_used_mb - g.memory_free_mb, 0),
                    "utilization_pct": g.utilization_pct,
                    "driver_version": g.driver_version,
                    "cuda_version": g.cuda_version,
                    "index": g.index,
                    "compute_capability": list(arch["compute_capability"]),
                    "compute_capability_source": arch["compute_capability_source"],
                    "architecture": arch["architecture"],
                    "architecture_heuristic": arch["heuristic"],
                }
            )

        return {
            "gpus": gpu_list,
            "summary": summary,
            "total_vram_gb": total_vram_gb,
            "detection": {
                "status": gpu_status.get("status"),
                "source": gpu_status.get("source"),
                "issues": gpu_status.get("issues", []),
                "device_files_present": gpu_status.get("device_files_present", False),
                "nvidia_smi": gpu_status.get("nvidia_smi", ""),
            },
            "system_ram": {
                "total_gb": sys_mem.total_ram_gb,
                "available_gb": sys_mem.available_ram_gb,
                "effective_for_llm_gb": sys_mem.effective_for_llm_gb,
            },
        }
    except Exception as exc:
        logger.warning("GPU detection failed: %s", exc)
        return {
            "gpus": [],
            "summary": "GPU detection unavailable",
            "total_vram_gb": 0.0,
            "detection": {
                "status": "error",
                "source": "exception",
                "issues": [{"source": "api", "code": "exception", "message": str(exc), "severity": "warning", "detail": ""}],
                "device_files_present": False,
                "nvidia_smi": "",
            },
            "system_ram": {"total_gb": 0.0, "available_gb": 0.0, "effective_for_llm_gb": 0.0},
        }


@app.get("/v1/system/gpu", summary="Detect NVIDIA GPUs and return hardware info")
async def system_gpu() -> dict[str, Any]:
    """Return detected GPU hardware info. Returns empty GPU list gracefully when
    nvidia-smi is not available (CPU-only host)."""
    return _response_envelope(_serialize_gpu_data())


# -- /v1/system/recommendations -----------------------------------------------

@app.get("/v1/system/recommendations", summary="Model recommendations based on detected GPU")
async def system_recommendations() -> dict[str, Any]:
    """Return Nemotron model recommendations and Ollama optimisation settings for
    the detected GPU. Safe to call on CPU-only hosts."""
    try:
        gpus = detect_gpus()
        recs = recommend_models(gpus)
        opts = get_ollama_optimizations(gpus)

        # OOM check for the main model sizes users commonly pull. These are
        # all registry-backed tags so the wizard does not recommend 404s.
        oom_models = {
            "nemotron-mini": 2.0,
            "qwen3:8b": 6.0,
            "llama3.2-vision": 7.0,
            "nemotron": 40.0,
        }
        oom_results = {name: check_oom_risk(vram, gpus) for name, vram in oom_models.items()}

        rec_data = [
            {
                "model": r.model,
                "reason": r.reason,
                "vram_required_gb": r.vram_required_gb,
                "tier": r.tier,
            }
            for r in recs
        ]

        opt_data = {
            "flash_attention": opts.flash_attention,
            "num_parallel": opts.num_parallel,
            "recommended_ctx": opts.recommended_ctx,
            "recommended_quant": opts.recommended_quant,
            "architecture": opts.architecture,
            "compute_capability": list(opts.compute_capability),
            "notes": opts.notes,
        }

        return _response_envelope({
            "recommendations": rec_data,
            "optimizations": opt_data,
            "oom_check": oom_results,
        })
    except Exception as exc:
        logger.warning("Recommendations endpoint error: %s", exc)
        return _response_envelope({
            "recommendations": [],
            "optimizations": {
                "flash_attention": False,
                "num_parallel": 1,
                "recommended_ctx": 2048,
                "recommended_quant": "Q4_K_M",
                "architecture": "Unknown",
                "compute_capability": [0, 0],
                "notes": ["GPU detection unavailable"],
            },
            "oom_check": {},
        })


class StorageConfigureRequest(BaseModel):
    home_dir: str | None = Field(
        default=None,
        description="Persistent NVH_HOME on a mounted user-writable volume",
    )
    min_free_gb: float = Field(default=200.0, ge=0)
    activate: bool = True

    @field_validator("home_dir")
    @classmethod
    def clean_home_dir(cls, value: str | None) -> str | None:
        if value is None:
            return None
        cleaned = value.strip()
        return cleaned or None


class SetupAssistantRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=2000)
    home_dir: str | None = Field(
        default=None,
        description="Optional NVH_HOME candidate to use while answering setup questions",
    )


class SetupHomeRequest(BaseModel):
    home_dir: str | None = Field(
        default=None,
        description="Optional NVH_HOME on the persistent mounted volume",
    )
    min_free_gb: float = Field(default=200.0, ge=0)


class SetupServiceActionRequest(BaseModel):
    service_id: str = Field(..., min_length=1, max_length=80)
    action_id: str = Field(..., min_length=1, max_length=80)
    home_dir: str | None = Field(
        default=None,
        description="Optional NVH_HOME on the persistent mounted volume",
    )


class WizardPlanRequest(BaseModel):
    profile: str = Field(default="student", description="Mission profile to plan")
    home_dir: str | None = Field(
        default=None,
        description="Optional NVH_HOME on the persistent mounted volume",
    )
    min_free_gb: float = Field(default=200.0, ge=0)


class WizardMissionBuildRequest(BaseModel):
    profile: str = Field(default="student", description="Mission profile to build")
    home_dir: str | None = Field(
        default=None,
        description="Optional NVH_HOME on the persistent mounted volume",
    )
    torch_profile: str = Field(
        default="nvidia-cu130",
        description="PyTorch install profile used when the mission includes ComfyUI",
    )
    force_update: bool = False
    min_free_gb: float = Field(default=200.0, ge=0)


class SupportSnapshotRequest(BaseModel):
    home_dir: str | None = Field(
        default=None,
        description="Optional NVH_HOME on the persistent mounted volume",
    )
    include_logs: bool = True
    min_free_gb: float = Field(default=200.0, ge=0)


class VaultInitRequest(BaseModel):
    home_dir: str | None = Field(
        default=None,
        description="Optional NVH_HOME on the persistent mounted volume",
    )


class VaultMemoryRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=120)
    body: str = Field(..., min_length=1, max_length=20000)
    category: str = Field(default="Wizard Memory", max_length=80)
    tags: list[str] = Field(default_factory=list)
    home_dir: str | None = Field(
        default=None,
        description="Optional NVH_HOME on the persistent mounted volume",
    )


class ObsidianInstallRequest(BaseModel):
    home_dir: str | None = Field(
        default=None,
        description="Optional NVH_HOME on the persistent mounted volume",
    )
    force_update: bool = False


@app.get("/v1/system/storage", summary="Inspect rootless persistent storage")
async def system_storage(
    home_dir: str | None = None,
    min_free_gb: float = 200.0,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the active rootless storage layout and preflight warnings."""
    from nvh.integrations.workspace.storage import storage_status

    return _response_envelope(
        storage_status(home_dir=home_dir, min_free_gb=min_free_gb).as_dict()
    )


@app.post("/v1/system/storage", summary="Configure rootless persistent storage")
async def configure_system_storage(
    request: StorageConfigureRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Create and activate the rootless NVH_HOME directory layout."""
    from nvh.integrations.workspace.storage import ensure_storage

    return _response_envelope(
        ensure_storage(
            request.home_dir,
            min_free_gb=request.min_free_gb,
            activate=request.activate,
        ).as_dict()
    )


@app.get("/v1/vault/status", summary="Inspect rootless nvHive Vault memory")
async def vault_status_endpoint(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the Markdown vault and optional Obsidian status."""
    from nvh.integrations.workspace.vault import vault_status

    return _response_envelope(vault_status(home_dir=home_dir))


@app.post("/v1/vault/init", summary="Create rootless nvHive Vault memory")
async def vault_init_endpoint(
    request: VaultInitRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Seed a durable Markdown vault under NVH_HOME."""
    from nvh.integrations.workspace.vault import init_vault

    return _response_envelope(init_vault(home_dir=request.home_dir))


@app.post("/v1/vault/memory", summary="Save a note into nvHive Vault")
async def vault_memory_endpoint(
    request: VaultMemoryRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Write a Markdown memory note without using a database or root path."""
    from nvh.integrations.workspace.vault import append_vault_memory

    return _response_envelope(
        append_vault_memory(
            request.title,
            request.body,
            category=request.category,
            tags=request.tags,
            home_dir=request.home_dir,
        )
    )


@app.post("/v1/vault/obsidian/install", summary="Install Obsidian rootlessly")
async def vault_obsidian_install_endpoint(
    request: ObsidianInstallRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Install the Obsidian AppImage under NVH_HOME/apps when supported."""
    from nvh.integrations.workspace.vault import install_obsidian

    return _response_envelope(
        install_obsidian(
            home_dir=request.home_dir,
            force_update=request.force_update,
        )
    )


@app.get("/v1/system/mount-autopilot", summary="Detect likely persistent mounts")
async def system_mount_autopilot(
    min_free_gb: float = 200.0,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Recommend a persistent NVH_HOME without requiring root access."""
    from nvh.integrations.workspace.mount_autopilot import mount_autopilot_report

    return _response_envelope(mount_autopilot_report(min_free_gb=min_free_gb))


@app.post("/v1/system/mount-autopilot/activate", summary="Activate the best persistent mount")
async def system_mount_autopilot_activate(
    request: SetupHomeRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Create and activate the highest-scoring discovered NVH_HOME."""
    from nvh.integrations.workspace.mount_autopilot import activate_recommended_mount

    return _response_envelope(
        activate_recommended_mount(
            min_free_gb=request.min_free_gb,
            extra_roots=[request.home_dir] if request.home_dir else None,
        )
    )


@app.get("/v1/system/runtime", summary="Inspect rootless runtime fallback status")
async def system_runtime(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Return whether nvHive can use Python venv/pip or needs micromamba fallback."""
    from nvh.integrations.services.runtime import runtime_status

    return _response_envelope(runtime_status().as_dict())


@app.get("/v1/wizard/passport", summary="Return the rootless Workspace Passport")
async def wizard_passport(
    home_dir: str | None = None,
    create: bool = True,
    min_free_gb: float = 200.0,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the canonical rootless workspace identity and durability state."""
    from nvh.integrations.workspace.passport import workspace_passport

    return _response_envelope(
        workspace_passport(
            home_dir=home_dir,
            create=create,
            min_free_gb=min_free_gb,
        )
    )


@app.get("/v1/system/passport", summary="Return the rootless Workspace Passport")
async def system_passport(
    home_dir: str | None = None,
    create: bool = True,
    min_free_gb: float = 200.0,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Alias for clients that group Workspace Passport under system state."""
    from nvh.integrations.workspace.passport import workspace_passport

    return _response_envelope(
        workspace_passport(
            home_dir=home_dir,
            create=create,
            min_free_gb=min_free_gb,
        )
    )


@app.post("/v1/system/passport/refresh", summary="Refresh the Workspace Passport")
async def system_passport_refresh(
    request: SetupHomeRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Refresh and persist the Workspace Passport under NVH_HOME/config."""
    from nvh.integrations.workspace.passport import workspace_passport

    return _response_envelope(
        workspace_passport(
            home_dir=request.home_dir,
            create=True,
            min_free_gb=request.min_free_gb,
        )
    )


@app.get("/v1/wizard/rootless-policy", summary="Return no-root policy gates")
async def wizard_rootless_policy(
    home_dir: str | None = None,
    min_free_gb: float = 200.0,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the shared rootless gate used by setup/install decisions."""
    from nvh.integrations.workspace.passport import rootless_policy_report

    return _response_envelope(
        rootless_policy_report(home_dir=home_dir, min_free_gb=min_free_gb)
    )


@app.get("/v1/wizard/plan", summary="Return a rootless wizard mission plan")
async def wizard_plan(
    profile: str = "student",
    home_dir: str | None = None,
    min_free_gb: float = 200.0,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Plan a no-root mission using action IDs the WebUI can run safely."""
    from nvh.integrations.workspace.passport import workspace_plan

    return _response_envelope(
        workspace_plan(
            profile=profile,
            home_dir=home_dir,
            min_free_gb=min_free_gb,
        )
    )


@app.get("/v1/wizard/mission-plan", summary="Return a concrete backend mission build plan")
async def wizard_mission_plan(
    profile: str = "student",
    min_free_gb: float = 200.0,
    torch_profile: str = "nvidia-cu130",
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the exact pack/model/ComfyUI stages a one-click mission will run."""
    from nvh.integrations.wizard.mission_builder import mission_profile_plan

    return _response_envelope(
        mission_profile_plan(
            profile,
            torch_profile=torch_profile,
            min_free_gb=min_free_gb,
            home_dir=home_dir,
        )
    )


@app.post("/v1/wizard/mission/job", summary="Start a backend-owned AI Wizard mission build")
async def wizard_mission_job(
    request: WizardMissionBuildRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Build an entire mission profile as one persistent cancellable job."""
    from nvh.integrations.services.jobs import start_job
    from nvh.integrations.wizard.mission_builder import MISSION_TITLES, install_mission_profile
    from nvh.integrations.workspace.storage import ensure_storage

    profile = request.profile.strip().lower() or "student"
    title = MISSION_TITLES.get(profile, profile.title())
    request_data = request.model_dump()
    if request.home_dir:
        storage = ensure_storage(
            request.home_dir,
            min_free_gb=request.min_free_gb,
            activate=True,
        )
        request_data["home_dir"] = str(storage.layout.home)
    job = start_job(
        kind="wizard-mission",
        title=f"Build {title}",
        request=request_data,
        source_factory=lambda: install_mission_profile(
            profile,
            torch_profile=request.torch_profile,
            force_update=request.force_update,
            home_dir=request_data.get("home_dir"),
            min_free_gb=request.min_free_gb,
        ),
    )
    return _response_envelope(job)


@app.post("/v1/wizard/support-snapshot", summary="Write a redacted support snapshot")
async def wizard_support_snapshot(
    request: SupportSnapshotRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Write a redacted support bundle under NVH_HOME/support."""
    from nvh.integrations.workspace.passport import support_snapshot

    return _response_envelope(
        support_snapshot(
            home_dir=request.home_dir,
            include_logs=request.include_logs,
            min_free_gb=request.min_free_gb,
        )
    )


@app.get("/v1/setup/helper", summary="Local setup helper recommendations")
async def setup_helper(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return offline setup recommendations for the student workstation wizard."""
    from nvh.integrations.wizard.setup_agent import setup_helper_report

    return _response_envelope(setup_helper_report(home_dir=home_dir))


@app.get("/v1/setup/services", summary="Return rootless service registry status")
async def setup_services(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return normalized status for nvHive apps, runtimes, URLs, ports, and logs."""
    from nvh.integrations.services.service_registry import list_service_statuses

    return _response_envelope(list_service_statuses(home_dir=home_dir))


@app.get("/v1/setup/service-health", summary="Return rootless service health report")
async def setup_service_health(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return service health, ports, next safe actions, and copyable support text."""
    from nvh.integrations.services.service_registry import service_health_report

    return _response_envelope(service_health_report(home_dir=home_dir))


@app.post("/v1/setup/service-action", summary="Run an allowlisted rootless service action")
async def setup_service_action(
    request: SetupServiceActionRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Run or route a small allowlisted rootless service action."""
    from nvh.integrations.services.service_registry import run_service_action

    try:
        result = run_service_action(
            request.service_id,
            request.action_id,
            home_dir=request.home_dir,
        )
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    return _response_envelope(result)


@app.get("/v1/setup/mission-control", summary="Return AI Wizard setup mission timeline")
async def setup_mission_control(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the combined boot, repair, model-fit, and smoke-test timeline."""
    from nvh.integrations.services.mission_control import mission_control_report

    return _response_envelope(mission_control_report(home_dir=home_dir))


@app.get("/v1/setup/auto-repair", summary="Preview safe rootless auto-repairs")
async def setup_auto_repair(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the safe repair queue without running installers or downloads."""
    from nvh.integrations.wizard.auto_repair import auto_repair_plan

    return _response_envelope(auto_repair_plan(home_dir=home_dir))


@app.post("/v1/setup/repair-workspace", summary="Run safe rootless workspace repairs")
async def setup_repair_workspace(
    request: SetupHomeRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Run idempotent repairs that leave user files, models, and app data intact."""
    from nvh.integrations.wizard.auto_repair import run_safe_repairs

    return _response_envelope(run_safe_repairs(home_dir=request.home_dir))


@app.get("/v1/wizard/diagnostics", summary="Active Wizard diagnostic findings + live context")
async def wizard_diagnostics(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the consolidated diagnostic findings the Wizard sees this turn.

    Powers the setup-page System Check section (one source of truth) and is
    the same data folded into the Wizard's system prompt — so a finding the
    user clicks on the setup page is the *exact* finding the Wizard would
    cite if asked. The setup page links each item to
    ``/wizard?issue=<finding.id>`` for a guided fix.

    Read-only and idempotent; safe to poll.
    """
    from nvh.integrations.wizard.context import wizard_context
    from nvh.integrations.wizard.findings import derive_findings

    snapshot = wizard_context(home_dir=home_dir)
    findings = derive_findings(snapshot)
    return _response_envelope({
        "findings": [f.to_dict() for f in findings],
        "context": snapshot,
        "counts": {
            "total": len(findings),
            "error": sum(1 for f in findings if f.severity == "error"),
            "warn": sum(1 for f in findings if f.severity == "warn"),
            "info": sum(1 for f in findings if f.severity == "info"),
        },
    })


@app.post("/v1/wizard/reconnect", summary="Wizard reconnect — preflight + auto-repair + UI-friendly summary")
async def wizard_reconnect(
    request: SetupHomeRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Run the boot-preflight reconnect routine and shape it for the WebUI.

    Returns the "Welcome back" payload: a one-line greeting, the facts that
    survived since last session, the facts that changed, the safe repairs
    that ran automatically, and the items that still need user action.
    Powers the chat-mount welcome panel and is read by the AI Wizard chat
    when greeting the user.
    """
    from nvh.integrations.wizard.reconnect import wizard_reconnect as run_reconnect

    return _response_envelope(run_reconnect(home_dir=request.home_dir))


class WizardChatTurn(BaseModel):
    role: str = Field(..., min_length=1, max_length=16)
    content: str = Field(..., max_length=20_000)


class WizardChatRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=20_000)
    history: list[WizardChatTurn] = Field(default_factory=list, max_length=40)
    home_dir: str | None = None
    # When set, the Wizard turn is persisted to the conversations store so
    # subsequent reconnects can resume the thread. Best-effort: a missing
    # conversation never breaks the chat reply.
    conversation_id: str | None = None
    # Optional named agent profile (e.g. "coder", "researcher"). Falls back
    # to the default Wizard persona when omitted or unknown.
    profile: str | None = None


@app.post("/v1/wizard/chat", summary="AI Wizard chat — live-state-grounded conversation")
async def wizard_chat_endpoint(
    request: WizardChatRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Answer a Wizard question grounded in the live workspace state.

    Returns the LLM-routed answer when any provider is healthy, falling
    back to the deterministic setup helper when no model is reachable.
    Either way the response shape is stable: ``{answer, mode, context, ...}``.
    """
    from nvh.integrations.wizard.chat import wizard_chat as _wizard_chat

    history = [{"role": t.role, "content": t.content} for t in request.history]
    result = await _wizard_chat(
        request.question,
        history=history,
        home_dir=request.home_dir,
        conversation_id=request.conversation_id,
        profile=request.profile,
    )
    return _response_envelope(result)


@app.post("/v1/wizard/chat/stream", summary="AI Wizard chat — Server-Sent Events stream")
async def wizard_chat_stream_endpoint(
    request: WizardChatRequest,
    _auth: None = Depends(require_auth),
) -> StreamingResponse:
    """Stream a Wizard turn as Server-Sent Events.

    Each event is a JSON object — see ``wizard_chat_stream`` for the event
    type taxonomy. Token events arrive as the LLM emits them so the UI can
    render text incrementally. Tool calls and results are interleaved as
    discrete events so the UI can show "Wizard is using X..." cards.
    """
    from nvh.integrations.wizard.chat import wizard_chat_stream

    history = [{"role": t.role, "content": t.content} for t in request.history]

    async def _event_source():
        try:
            async for event in wizard_chat_stream(
                request.question,
                history=history,
                home_dir=request.home_dir,
                conversation_id=request.conversation_id,
            ):
                yield f"data: {json.dumps(event)}\n\n".encode()
        except Exception as exc:
            # Streaming errors can't raise to FastAPI cleanly after headers
            # are flushed — emit them as a final event so the client sees
            # something actionable instead of a torn-off connection.
            yield f"data: {json.dumps({'type': 'error', 'error': str(exc)[:300]})}\n\n".encode()

    return StreamingResponse(
        _event_source(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.get("/v1/wizard/profiles", summary="List Wizard agent profiles (built-in + user-defined)")
async def wizard_profiles_list(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the agent-profile catalog so the UI can render a switcher.

    Built-in profiles always appear first; user-defined profiles follow.
    A user can override a built-in by saving a profile with the same name.
    """
    from nvh.integrations.wizard.profiles import list_profiles

    profiles = [p.to_dict() for p in list_profiles(home_dir=home_dir)]
    return _response_envelope({"profiles": profiles})


class WizardProfileUpsertRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=64)
    title: str = Field(..., max_length=128)
    description: str = Field(default="", max_length=400)
    system_prompt: str = Field(default="", max_length=8000)
    provider: str = ""
    model: str = ""
    temperature: float | None = None
    max_tokens: int | None = None
    tools_allowed: list[str] | None = None
    tags: list[str] = Field(default_factory=list)
    home_dir: str | None = None


@app.post("/v1/wizard/profiles", summary="Create or update a user-defined agent profile")
async def wizard_profiles_upsert(
    request: WizardProfileUpsertRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Persist a profile under ``$NVH_HOME/agent-profiles/<name>.yaml``.

    Saving a profile with the same name as a built-in is allowed and acts
    as an override — the user version wins at runtime.
    """
    from nvh.integrations.wizard.profiles import AgentProfile, save_user_profile

    profile = AgentProfile(
        name=request.name,
        title=request.title,
        description=request.description,
        system_prompt=request.system_prompt,
        provider=request.provider,
        model=request.model,
        temperature=request.temperature,
        max_tokens=request.max_tokens,
        tools_allowed=request.tools_allowed,
        tags=request.tags,
    )
    path = save_user_profile(profile, home_dir=request.home_dir)
    return _response_envelope({"saved": True, "path": str(path), "name": profile.name})


@app.delete("/v1/wizard/profiles/{name}", summary="Delete a user-defined agent profile")
async def wizard_profiles_delete(
    name: str = Path(..., description="Profile name"),
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Remove a user profile YAML. Built-in profiles can't be deleted —
    use the upsert path to override their behavior instead."""
    from nvh.integrations.wizard.profiles import delete_user_profile

    ok = delete_user_profile(name, home_dir=home_dir)
    if not ok:
        raise HTTPException(status_code=404, detail=f"User profile '{name}' not found")
    return _response_envelope({"deleted": True, "name": name})


@app.get("/v1/wizard/context", summary="AI Wizard live workspace context snapshot")
async def wizard_context_endpoint(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the unified workspace snapshot the Wizard reads on every turn.

    Useful for the WebUI to render hardware/storage/job state alongside the
    chat without three separate requests, and for debugging "what does the
    Wizard see right now?" questions.
    """
    from nvh.integrations.wizard.context import wizard_context

    return _response_envelope(wizard_context(home_dir=home_dir))


# Singleton Wizard tool registry — built lazily on first request.
_wizard_tool_registry = None


def _get_wizard_tools():
    """Lazy-init the Wizard tool registry. Importable so tests can replace it."""
    global _wizard_tool_registry
    if _wizard_tool_registry is None:
        from nvh.integrations.wizard.tools import default_registry

        _wizard_tool_registry = default_registry()
    return _wizard_tool_registry


@app.get("/v1/wizard/tools", summary="List AI Wizard tools available for natural-language action")
async def wizard_tools_list(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Return the publicly-exposed Wizard tool catalog.

    Each entry includes its safety_class so the UI knows whether to surface
    a confirmation card before calling /v1/wizard/tools/execute.
    """
    registry = _get_wizard_tools()
    tools = [tool.as_public_dict() for tool in registry.list_tools()]
    return _response_envelope({
        "tools": tools,
        "auto_count": sum(1 for t in tools if t["safety_class"] == "auto"),
        "confirm_count": sum(1 for t in tools if t["safety_class"] == "confirm"),
    })


class WizardToolExecuteRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=64)
    arguments: dict[str, Any] = Field(default_factory=dict)
    confirmed: bool = False


@app.post("/v1/wizard/tools/execute", summary="Execute an AI Wizard tool with safety enforcement")
async def wizard_tools_execute(
    request: WizardToolExecuteRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Run a Wizard tool. Safety enforcement happens server-side.

    Returns ``{ok, result?, error?, needs_confirmation?, tool?, ...}``. When
    ``needs_confirmation`` is true the UI should render a confirmation card
    with the included ``summary`` and re-call this endpoint with
    ``confirmed=true``.
    """
    registry = _get_wizard_tools()
    result = await registry.execute(
        request.name,
        arguments=request.arguments,
        confirmed=request.confirmed,
    )
    return _response_envelope(result)


class RagIngestRequest(BaseModel):
    path: str = Field(..., min_length=1)
    collection: str | None = None
    home_dir: str | None = None


@app.post("/v1/rag/ingest", summary="Walk a folder and store embeddings for RAG")
async def rag_ingest_endpoint(
    request: RagIngestRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Embed every text/source file under ``path`` into the local RAG index.

    Idempotent at the file level — re-ingesting the same folder replaces
    a source's chunks rather than appending duplicates. Returns counts so
    the caller can show "indexed N files, M chunks" without a second call.
    """
    from nvh.integrations.rag import ingest_folder

    result = await ingest_folder(
        request.path,
        collection=request.collection,
        home_dir=request.home_dir,
    )
    return _response_envelope(result)


class RagAskRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=4000)
    collection: str | None = None
    top_k: int = Field(default=5, ge=1, le=20)
    home_dir: str | None = None


@app.post("/v1/rag/ask", summary="Retrieve top-k RAG chunks for a question")
async def rag_ask_endpoint(
    request: RagAskRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the chunks most relevant to ``question`` from the local index.

    The Wizard chat layer wraps these chunks into a prompt; bare API
    callers receive ``{ok, chunks: [{source, chunk_index, text, score}]}``
    so they can build their own grounding step.
    """
    from nvh.integrations.rag import ask

    result = await ask(
        request.question,
        collection=request.collection,
        top_k=request.top_k,
        home_dir=request.home_dir,
    )
    return _response_envelope(result)


@app.post("/v1/rag/upload-ingest", summary="Upload files and ingest them into a RAG collection")
async def rag_upload_ingest_endpoint(
    files: list[UploadFile] = File(...),
    collection: str | None = None,
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Save uploaded files into the rootless workspace upload area, then run
    the standard RAG ingest walker against that directory.

    Designed for the WebUI's drag-drop surface: the browser ships file bytes
    over multipart, we land them under ``$NVH_HOME/rag/uploads/<timestamp>/``
    so they survive reconnect, then point the ingest walker at the folder.
    Same path users would get from a CLI ``rag ingest <dir>`` invocation.
    """
    from datetime import UTC, datetime
    from pathlib import Path as _Path

    from nvh.integrations.rag import ingest_folder
    from nvh.integrations.workspace.storage import nvh_home

    home, _ = nvh_home(home_dir)
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    upload_dir = home / "rag" / "uploads" / stamp
    upload_dir.mkdir(parents=True, exist_ok=True)

    saved: list[str] = []
    for upload in files:
        # UploadFile.filename can be any browser-supplied string. Strip path
        # components hard so a malicious "../foo" never escapes upload_dir.
        original = upload.filename or "file"
        safe_name = _Path(original).name or "file"
        dest = upload_dir / safe_name
        # If the same name appears twice in the batch, dedupe with a counter.
        suffix_idx = 1
        while dest.exists():
            dest = upload_dir / f"{dest.stem}-{suffix_idx}{dest.suffix}"
            suffix_idx += 1
        contents = await upload.read()
        dest.write_bytes(contents)
        saved.append(str(dest))

    result = await ingest_folder(
        upload_dir,
        collection=collection,
        home_dir=home_dir,
    )
    result.setdefault("uploaded_files", len(saved))
    result.setdefault("upload_dir", str(upload_dir))
    return _response_envelope(result)


@app.get("/v1/rag/collections", summary="List known RAG collections and chunk counts")
async def rag_collections_endpoint(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return ``[{name, chunks, sources}, ...]`` so the UI can render a picker."""
    from nvh.integrations.rag import list_collections

    return _response_envelope({"collections": list_collections(home_dir=home_dir)})


class RagVaultIngestRequest(BaseModel):
    home_dir: str | None = None


@app.post("/v1/rag/vault/ingest", summary="Index the nvHive Vault into the RAG store")
async def rag_vault_ingest_endpoint(
    request: RagVaultIngestRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Walk the Vault markdown directory and refresh the ``vault`` collection.

    Idempotent at the source-file level — running again just replaces each
    note's chunks. Useful as a periodic refresh after the user has been
    writing in Obsidian.
    """
    from nvh.integrations.rag import ingest_vault

    return _response_envelope(await ingest_vault(home_dir=request.home_dir))


class RagVaultAskRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=4000)
    top_k: int = Field(default=5, ge=1, le=20)
    home_dir: str | None = None


@app.post("/v1/rag/vault/ask", summary="Ask a question grounded in the nvHive Vault")
async def rag_vault_ask_endpoint(
    request: RagVaultAskRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Search the Vault collection; auto-index on first use.

    Returns the same shape as ``/v1/rag/ask`` with an extra ``auto_indexed``
    flag so the UI can surface "first call took longer — we just indexed
    your vault" without a second request.
    """
    from nvh.integrations.rag import ask_vault

    return _response_envelope(
        await ask_vault(request.question, top_k=request.top_k, home_dir=request.home_dir),
    )


class WebSearchRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=400)
    top_k: int = Field(default=5, ge=1, le=20)


@app.post("/v1/web-search", summary="Web search via the active backend (DDG/SearXNG/Brave)")
async def web_search_endpoint(
    request: WebSearchRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return top-k web hits for ``query`` via the active backend.

    Backend is selected per-call by environment: ``NVH_SEARXNG_URL`` wins
    if set, otherwise ``BRAVE_API_KEY``, otherwise the DuckDuckGo HTML
    fallback. The Wizard's `web_search` tool is a thin wrapper over this
    same call so chat and direct API consumers share one implementation.
    """
    from nvh.integrations.web_search import web_search

    result = await web_search(request.query, top_k=request.top_k)
    return _response_envelope(result)


@app.get("/v1/web-search/backend", summary="Report the active web-search backend")
async def web_search_backend_endpoint(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Return ``{backend}`` so the UI can show which path is live."""
    from nvh.integrations.web_search import active_backend

    return _response_envelope({"backend": active_backend()})


class ConversationPinRequest(BaseModel):
    pinned: bool = True


@app.post("/v1/conversations/{conversation_id}/pin", summary="Pin or unpin a conversation for resume")
async def conversation_pin_endpoint(
    conversation_id: str = Path(..., description="Conversation UUID"),
    request: ConversationPinRequest = None,  # type: ignore[assignment]
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Toggle the pinned flag. Pinned conversations survive list eviction and
    are surfaced in the reconnect-resume card on next session start."""
    from nvh.storage import repository as repo

    if request is None:
        request = ConversationPinRequest()
    ok = await repo.set_conversation_pinned(conversation_id, request.pinned)
    if not ok:
        raise HTTPException(
            status_code=404,
            detail=f"Conversation '{conversation_id}' not found.",
        )
    return _response_envelope({"conversation_id": conversation_id, "pinned": request.pinned})


@app.get("/v1/conversations/pinned", summary="List pinned conversations (resume targets)")
async def conversations_pinned_endpoint(
    limit: int = 20,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return conversations the user pinned for cross-session resume.

    These are the "pick up where you left off" candidates the reconnect-resume
    card uses on the next session start.
    """
    from nvh.storage import repository as repo

    pinned = await repo.list_pinned_conversations(limit=limit)
    return _response_envelope({
        "conversations": [
            {
                "id": c.id,
                "title": c.title,
                "provider": c.provider,
                "model": c.model,
                "updated_at": c.updated_at.isoformat() if c.updated_at else None,
                "message_count": c.message_count,
            }
            for c in pinned
        ],
    })


class SnapshotExportRequest(BaseModel):
    home_dir: str | None = None


@app.post("/v1/workspace/snapshot/export", summary="Bundle the workspace into a portable tarball")
async def workspace_snapshot_export_endpoint(
    request: SnapshotExportRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Export a tarball of vault + RAG index + config + receipts.

    Secrets, API keys, and model weights are deliberately excluded so the
    tarball is small and safe to mail/share. The user pulls model weights and
    pastes keys again on the destination — the bundle is configuration, not
    a disk image.
    """
    from nvh.integrations.workspace.snapshot import export_snapshot

    result = export_snapshot(home_dir=request.home_dir)
    return _response_envelope(result)


class SnapshotImportRequest(BaseModel):
    path: str = Field(..., min_length=1)
    home_dir: str | None = None
    overwrite: bool = False


@app.post("/v1/workspace/snapshot/import", summary="Restore a workspace snapshot tarball")
async def workspace_snapshot_import_endpoint(
    request: SnapshotImportRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Extract a previously-exported snapshot into the current workspace.

    Refuses to overwrite existing files unless ``overwrite=True``. Returns
    counts so the UI can show "12 paths restored, 3 skipped" without a
    second roundtrip.
    """
    from nvh.integrations.workspace.snapshot import import_snapshot

    result = import_snapshot(
        request.path,
        home_dir=request.home_dir,
        overwrite=request.overwrite,
    )
    return _response_envelope(result)


@app.get("/v1/web-search/recommendations", summary="Web-search backend upgrade recommendations")
async def web_search_recommendations_endpoint(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Return UI guidance on durable backend options.

    When the active backend is the DuckDuckGo HTML fallback, this returns
    a fragility nudge with concrete env vars and links the user can follow
    to move to SearXNG or Brave. When the active backend is already stable,
    durability is "stable" and `upgrades` is empty.
    """
    from nvh.integrations.web_search import backend_recommendation

    return _response_envelope(backend_recommendation())


@app.get("/v1/setup/smoke-tests", summary="Run lightweight app smoke checks")
async def setup_smoke_tests(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Check installed apps without running destructive actions."""
    from nvh.integrations.diagnostics.smoke_tests import smoke_test_report

    return _response_envelope(smoke_test_report(home_dir=home_dir))


@app.get("/v1/setup/model-fit", summary="Recommend models by VRAM and disk fit")
async def setup_model_fit(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the simplified student model queue and fit scores."""
    from nvh.integrations.diagnostics.model_fit import model_fit_report

    return _response_envelope(model_fit_report(home_dir=home_dir))


@app.get("/v1/setup/runtime-doctor", summary="Diagnose the rootless local AI runtime")
async def setup_runtime_doctor(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return a non-mutating Ollama/runtime diagnosis for AI Wizard."""
    from nvh.integrations.installs.studio_packs import ollama_runtime_doctor

    return _response_envelope(ollama_runtime_doctor(home_dir=home_dir))


@app.get("/v1/setup/workspace-state", summary="Return canonical setup readiness state")
async def setup_workspace_state(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return one compact readiness state for the setup wizard."""
    from nvh.integrations.diagnostics.workspace_state import workspace_state

    return _response_envelope(workspace_state(home_dir=home_dir))


@app.get("/v1/setup/production-readiness", summary="Return conservative production readiness gates")
async def setup_production_readiness(
    home_dir: str | None = None,
    target_vm_validated: bool | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Aggregate rootless, storage, model, smoke, and target-VM release gates."""
    from nvh.integrations.diagnostics.production_readiness import production_readiness_report

    return _response_envelope(
        production_readiness_report(
            home_dir=home_dir,
            target_vm_validated=target_vm_validated,
        )
    )


@app.get("/v1/setup/diagnostics", summary="Return a redacted setup diagnostics report")
async def setup_diagnostics(
    request: Request,
    home_dir: str | None = None,
    include_logs: bool = True,
    log_lines: int = 80,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Package rootless setup state, recent jobs, and redacted log warnings."""
    from nvh.integrations.diagnostics.report import diagnostics_report

    report = diagnostics_report(
        home_dir=home_dir,
        request_id=request.headers.get("x-request-id"),
        include_logs=include_logs,
        log_lines=log_lines,
    )
    logger.info(
        "Setup diagnostics report generated",
        extra={
            "request_id": report.get("request_id") or "",
            "path": request.url.path,
        },
    )
    return _response_envelope(report)


@app.post("/v1/setup/assistant", summary="Ask the local setup helper")
async def setup_assistant(
    request: SetupAssistantRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Answer setup questions with local state, receipts, and deterministic rules."""
    from nvh.integrations.wizard.setup_agent import setup_assistant_reply

    return _response_envelope(
        setup_assistant_reply(request.question, home_dir=request.home_dir)
    )


@app.get("/v1/setup/catalog", summary="Load the setup catalog")
async def setup_catalog(
    refresh: bool = False,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return remote/cache/bundled setup catalog data for the wizard."""
    from nvh.integrations.catalog import load_setup_catalog

    return _response_envelope(load_setup_catalog(refresh=refresh))


@app.get("/v1/setup/compatibility", summary="Inspect host/app compatibility")
async def setup_compatibility(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return host facts and per-app compatibility checks for AI Wizard."""
    from nvh.integrations.diagnostics.compatibility import compatibility_report

    return _response_envelope(compatibility_report(home_dir=home_dir))


@app.get("/v1/setup/boot-preflight", summary="Return boot-time VM image preflight")
async def setup_boot_preflight(
    home_dir: str | None = None,
    recheck: bool = False,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return the persisted boot preflight, running it if needed."""
    from nvh.integrations.diagnostics.boot_preflight import (
        boot_preflight_status,
        run_boot_preflight,
    )

    if recheck:
        result = await asyncio.to_thread(run_boot_preflight, home_dir=home_dir)
        app.state.boot_preflight = result
        return _response_envelope(result)

    cached = getattr(app.state, "boot_preflight", None)
    if cached and not home_dir:
        return _response_envelope(cached)
    result = await asyncio.to_thread(boot_preflight_status, home_dir=home_dir, run_if_missing=True)
    return _response_envelope(result)


@app.post("/v1/setup/boot-preflight/recheck", summary="Run boot-time VM image preflight now")
async def setup_boot_preflight_recheck(
    home_dir: str | None = None,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Force a boot preflight refresh after the user repairs something."""
    from nvh.integrations.diagnostics.boot_preflight import run_boot_preflight

    result = await asyncio.to_thread(run_boot_preflight, home_dir=home_dir)
    app.state.boot_preflight = result
    return _response_envelope(result)


@app.get("/v1/setup/receipts", summary="List rootless install receipts")
async def setup_receipts(
    kind: str | None = None,
    status_filter: str | None = None,
    limit: int = 100,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return install receipts written under NVH_HOME."""
    from nvh.integrations.services.receipts import list_receipts, receipt_summary

    safe_limit = max(1, min(limit, 500))
    receipts = list_receipts(kind=kind, status=status_filter, limit=safe_limit)
    summary = receipt_summary()
    return _response_envelope({
        "receipts": receipts,
        "count": len(receipts),
        "summary": {key: value for key, value in summary.items() if key != "receipts"},
    })


def _receipt_or_404(receipt_id: str) -> dict[str, Any]:
    from nvh.integrations.services.receipts import load_receipt

    try:
        return load_receipt(receipt_id)
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@app.get("/v1/setup/receipts/{receipt_id}", summary="Get one install receipt")
async def setup_receipt(
    receipt_id: str,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    return _response_envelope(_receipt_or_404(receipt_id))


@app.get("/v1/setup/receipts/{receipt_id}/repair-plan", summary="Preview receipt repair")
async def setup_receipt_repair_plan(
    receipt_id: str,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    from nvh.integrations.services.receipts import repair_plan

    _receipt_or_404(receipt_id)
    return _response_envelope(repair_plan(receipt_id))


@app.get("/v1/setup/receipts/{receipt_id}/uninstall-plan", summary="Preview receipt uninstall")
async def setup_receipt_uninstall_plan(
    receipt_id: str,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    from nvh.integrations.services.receipts import uninstall_plan

    _receipt_or_404(receipt_id)
    return _response_envelope(uninstall_plan(receipt_id))


# -- /v1/system/info ----------------------------------------------------------

@app.get("/v1/system/info", summary="Combined system status — GPU + providers + budget in one call")
async def system_info(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Dashboard-optimised endpoint: returns GPU info, provider counts, budget and
    cache stats in a single round-trip."""
    engine = get_engine()

    # GPU (never raises)
    gpu_data = _serialize_gpu_data()

    # Providers — best-effort, don't crash the whole endpoint on timeouts
    providers_online = 0
    providers_total = 0
    ollama_status = "disconnected"
    try:
        enabled = engine.registry.list_enabled()
        providers_total = len(enabled)

        async def _quick_check(name: str) -> bool:
            try:
                provider = engine.registry.get(name)
                hs = await asyncio.wait_for(provider.health_check(), timeout=5.0)
                return hs.healthy
            except Exception:
                return False

        results = await asyncio.gather(*[_quick_check(n) for n in enabled])
        providers_online = sum(results)

        if engine.registry.has("ollama"):
            try:
                ollama_provider = engine.registry.get("ollama")
                hs = await asyncio.wait_for(ollama_provider.health_check(), timeout=5.0)
                ollama_status = "connected" if hs.healthy else "disconnected"
            except Exception:
                ollama_status = "disconnected"
    except Exception:
        pass

    # Budget — best-effort
    budget_data: dict[str, Any] = {}
    try:
        raw_budget = await engine.get_budget_status()
        budget_data = {
            "daily_spend": str(raw_budget["daily_spend"]),
            "daily_limit": str(raw_budget["daily_limit"]),
            "monthly_spend": str(raw_budget["monthly_spend"]),
            "monthly_limit": str(raw_budget["monthly_limit"]),
            "daily_queries": raw_budget["daily_queries"],
            "monthly_queries": raw_budget["monthly_queries"],
        }
    except Exception:
        pass

    # Cache — best-effort
    cache_data: dict[str, Any] = {}
    try:
        cache_data = engine.cache.stats
    except Exception:
        pass

    return _response_envelope({
        "version": "0.1.0",
        "gpu": gpu_data,
        "providers_online": providers_online,
        "providers_total": providers_total,
        "budget": budget_data,
        "cache": cache_data,
        "ollama_status": ollama_status,
    })


# -- /v1/query ----------------------------------------------------------------

@app.post("/v1/query", summary="Single provider query")
async def query(request: QueryRequest, _auth: None = Depends(require_auth)) -> Any:
    engine = get_engine()

    if request.stream:
        return StreamingResponse(
            _sse_query_stream(engine, request),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
            },
        )

    try:
        if request.attachments:
            # Multimodal path stays inline for now — it pokes private engine
            # state. Tracked for migration in nvh/api/services/__init__.py.
            await engine.initialize()
            await engine._check_budget()
            config = engine.config
            temp = request.temperature if request.temperature is not None else config.defaults.temperature
            max_tok = request.max_tokens or config.defaults.max_tokens
            sys_prompt = request.system_prompt or config.defaults.system_prompt or None
            decision = engine.router.route(
                query=request.prompt,
                provider_override=request.provider,
                model_override=request.model,
            )
            if not engine.registry.has(decision.provider):
                raise ProviderError(f"Provider '{decision.provider}' not available.", provider=decision.provider)

            provider = engine.registry.get(decision.provider)
            messages: list[Message] = []
            if sys_prompt:
                messages.append(Message(role="system", content=sys_prompt))
            messages.append(Message(role="user", content=_query_user_content(request)))
            response = await provider.complete(
                messages=messages,
                model=decision.model or None,
                system_prompt=sys_prompt,
                temperature=temp,
                max_tokens=max_tok,
                prefer_vision=_request_has_image_attachments(request),
            )
            try:
                await engine._log_query(response, mode="simple")
            except Exception:
                logger.debug("Query logging failed for multimodal query", exc_info=True)
        else:
            response = await _query_service.execute(
                engine,
                prompt=request.prompt,
                provider=request.provider,
                model=request.model,
                system_prompt=request.system_prompt,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
            )
    except BudgetExceededError as exc:
        raise HTTPException(status_code=status.HTTP_402_PAYMENT_REQUIRED, detail=str(exc))
    except ProviderError as exc:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error in /v1/query")
        detail = f"{type(exc).__name__}: {str(exc)[:500]}"
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=detail)

    return _response_envelope(_serialize_completion(response))


# -- /v1/council --------------------------------------------------------------

@app.post("/v1/council", summary="Council mode — multi-LLM orchestration")
async def council_query(request: CouncilRequest, _auth: None = Depends(require_auth)) -> dict[str, Any]:
    engine = get_engine()

    try:
        result = await engine.run_council(
            prompt=request.prompt,
            members=request.members,
            weights=request.weights,
            strategy=request.strategy,
            system_prompt=request.system_prompt,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            synthesize=request.synthesize,
            auto_agents=request.auto_agents,
            agent_preset=request.preset,
            num_agents=request.num_agents,
        )
    except BudgetExceededError as exc:
        raise HTTPException(status_code=status.HTTP_402_PAYMENT_REQUIRED, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc))
    except ProviderError as exc:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc))
    except Exception:
        logger.exception("Unexpected error in /v1/council")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal server error")

    member_data = {
        label: _serialize_completion(resp)
        for label, resp in result.member_responses.items()
    }

    data: dict[str, Any] = {
        "member_responses": member_data,
        "failed_members": result.failed_members,
        "strategy": result.strategy,
        "total_cost_usd": _decimal_to_str(result.total_cost_usd),
        "total_latency_ms": result.total_latency_ms,
        "quorum_met": result.quorum_met,
        "agents_used": result.agents_used,
        "synthesis": _serialize_completion(result.synthesis) if result.synthesis else None,
        "members": [
            {
                "provider": m.provider,
                "model": m.model,
                "weight": m.weight,
                "persona": m.persona,
            }
            for m in result.members
        ],
    }

    return _response_envelope(data)


# -- /v1/compare --------------------------------------------------------------

@app.post("/v1/compare", summary="Compare multiple providers on the same prompt")
async def compare(request: CompareRequest, _auth: None = Depends(require_auth)) -> dict[str, Any]:
    engine = get_engine()

    try:
        results = await engine.compare(
            prompt=request.prompt,
            providers=request.providers,
            system_prompt=request.system_prompt,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
        )
    except BudgetExceededError as exc:
        raise HTTPException(status_code=status.HTTP_402_PAYMENT_REQUIRED, detail=str(exc))
    except ProviderError as exc:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc))
    except Exception:
        logger.exception("Unexpected error in /v1/compare")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal server error")

    return _response_envelope({
        provider: _serialize_completion(resp)
        for provider, resp in results.items()
    })


# -- /v1/advisors -------------------------------------------------------------

@app.get("/v1/advisors", summary="List configured advisors with health status")
async def list_providers(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    engine = get_engine()
    enabled = engine.registry.list_enabled()

    async def _check(name: str) -> dict[str, Any]:
        try:
            provider = engine.registry.get(name)
            hs = await asyncio.wait_for(provider.health_check(), timeout=10.0)
            return {
                "name": name,
                "healthy": hs.healthy,
                "latency_ms": hs.latency_ms,
                "models_available": hs.models_available,
                "error": hs.error,
            }
        except Exception as exc:
            return {
                "name": name,
                "healthy": False,
                "latency_ms": None,
                "models_available": 0,
                "error": str(exc),
            }

    checks = await asyncio.gather(*[_check(n) for n in enabled])
    return _response_envelope({"providers": list(checks)})


@app.get("/v1/advisors/{name}/health", summary="Health check for a specific advisor")
async def provider_health(
    name: str = Path(..., description="Advisor name, e.g. 'openai'"),
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    engine = get_engine()

    if not engine.registry.has(name):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Advisor '{name}' is not configured or enabled.",
        )

    try:
        provider = engine.registry.get(name)
        hs = await asyncio.wait_for(provider.health_check(), timeout=10.0)
    except TimeoutError:
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail=f"Health check for '{name}' timed out.",
        )
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc))

    return _response_envelope({
        "name": hs.provider,
        "healthy": hs.healthy,
        "latency_ms": hs.latency_ms,
        "models_available": hs.models_available,
        "error": hs.error,
    })


# -- /v1/models ---------------------------------------------------------------

# TTL cache of live model IDs per provider. The static capability catalog
# in capabilities.yaml drifts out of sync with what providers actually
# serve (e.g. Groq deprecated gemma2-9b-it but it still sits in the
# catalog), so we intersect against the provider's current list_models()
# result. Cached because hitting every provider on every dropdown open
# is both slow and rude.
_LIVE_MODELS_CACHE: dict[str, tuple[float, set[str] | None]] = {}
_LIVE_MODELS_TTL = 300.0  # 5 minutes


async def _get_live_model_ids(engine, provider_name: str) -> set[str] | None:
    """Return the set of live model IDs for a provider, or None if unknown.

    None means "we couldn't determine the live list" (timeout, error, no
    implementation) — callers should treat that as "don't filter this
    provider's catalog entries" so we never hide models because of a
    transient fetch failure.
    """
    now = time.monotonic()
    cached = _LIVE_MODELS_CACHE.get(provider_name)
    if cached is not None and (now - cached[0]) < _LIVE_MODELS_TTL:
        return cached[1]

    try:
        provider = engine.registry.get(provider_name)
    except Exception:
        return None

    try:
        live = await asyncio.wait_for(provider.list_models(), timeout=5.0)
    except Exception:
        # Negative cache so we don't keep retrying a broken provider —
        # shorter TTL (30s) so it recovers quickly once the provider
        # comes back.
        _LIVE_MODELS_CACHE[provider_name] = (now - _LIVE_MODELS_TTL + 30.0, None)
        return None

    ids = {m.model_id for m in live if getattr(m, "model_id", None)}
    _LIVE_MODELS_CACHE[provider_name] = (now, ids)
    return ids


@app.get("/v1/models", summary="List available models from the capability catalog")
async def list_models(provider: str | None = None, _auth: None = Depends(require_auth)) -> dict[str, Any]:
    engine = get_engine()
    models = engine.registry.list_models(provider=provider)

    # Group catalog entries by provider, then fetch live model IDs for
    # each provider in parallel (cached). Filter the catalog to only
    # include models the provider still serves; providers whose live
    # list we couldn't fetch pass through unfiltered so we never
    # blank out the dropdown on a transient error.
    catalog_providers: set[str] = {m.provider for m in models}
    live_sets: dict[str, set[str] | None] = {}
    if catalog_providers:
        results = await asyncio.gather(
            *[_get_live_model_ids(engine, p) for p in catalog_providers],
            return_exceptions=True,
        )
        for p, r in zip(catalog_providers, results):
            live_sets[p] = r if isinstance(r, set) else None

    def _is_available(m) -> bool:
        live = live_sets.get(m.provider)
        if live is None:
            return True  # unknown — keep it
        return m.model_id in live

    filtered = [m for m in models if _is_available(m)]

    model_data = [
        {
            "model_id": m.model_id,
            "provider": m.provider,
            "display_name": m.display_name,
            "context_window": m.context_window,
            "max_output_tokens": m.max_output_tokens,
            "supports_streaming": m.supports_streaming,
            "supports_tools": m.supports_tools,
            "supports_vision": m.supports_vision,
            "supports_json_mode": m.supports_json_mode,
            "input_cost_per_1m_tokens": _decimal_to_str(m.input_cost_per_1m_tokens),
            "output_cost_per_1m_tokens": _decimal_to_str(m.output_cost_per_1m_tokens),
            "typical_latency_ms": m.typical_latency_ms,
            "capability_scores": m.capability_scores,
            "status": m.status,
        }
        for m in filtered
    ]

    return _response_envelope({"models": model_data, "count": len(model_data)})


# -- /v1/budget/status --------------------------------------------------------

@app.get("/v1/budget/status", summary="Current budget usage and limits")
async def budget_status(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    engine = get_engine()
    try:
        await engine.initialize()
        data = await engine.get_budget_status()
    except Exception as exc:
        logger.exception("Error fetching budget status; returning local fallback")
        data = {
            "daily_spend": Decimal("0"),
            "daily_limit": getattr(engine.config.budget, "daily_limit_usd", Decimal("0")),
            "monthly_spend": Decimal("0"),
            "monthly_limit": getattr(engine.config.budget, "monthly_limit_usd", Decimal("0")),
            "daily_queries": 0,
            "monthly_queries": 0,
            "by_provider": {},
            "unavailable": True,
            "error": str(exc)[:200],
        }

    # Serialize Decimal values
    serialized = {
        "daily_spend": str(data.get("daily_spend", "0")),
        "daily_limit": str(data.get("daily_limit", "0")),
        "monthly_spend": str(data.get("monthly_spend", "0")),
        "monthly_limit": str(data.get("monthly_limit", "0")),
        "daily_queries": data.get("daily_queries", 0),
        "monthly_queries": data.get("monthly_queries", 0),
        "by_provider": {k: str(v) for k, v in (data.get("by_provider") or {}).items()},
        "unavailable": bool(data.get("unavailable", False)),
    }
    return _response_envelope(serialized)


# -- /v1/cache/stats & /v1/cache ----------------------------------------------

@app.get("/v1/cache/stats", summary="In-memory response cache statistics")
async def cache_stats(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    engine = get_engine()
    try:
        await engine.initialize()
    except Exception:
        logger.debug("Cache stats served before full engine initialization", exc_info=True)
    return _response_envelope(engine.cache.stats)


@app.delete("/v1/cache", summary="Clear the response cache")
async def clear_cache(provider: str | None = None, _auth: None = Depends(require_auth)) -> dict[str, Any]:
    engine = get_engine()
    cleared = await engine.cache.clear(provider=provider)
    return _response_envelope({"cleared": cleared, "provider": provider})


# -- /v1/analytics ------------------------------------------------------------

@app.get("/v1/analytics", summary="Usage analytics — query counts, cost breakdown, latency, savings")
async def analytics(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    from nvh.storage import repository as repo
    try:
        data = await repo.get_analytics()
    except Exception:
        logger.exception("Error fetching analytics")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal server error")
    return _response_envelope(data)


# -- /v1/smart — auto-detect intent and route appropriately -------------------

@app.post("/v1/smart", summary="Smart query — auto-detects actions, tasks, and questions")
async def smart_query(request: QueryRequest, _auth: None = Depends(require_auth)) -> Any:
    """Smart endpoint: detects if the prompt is an action, a multi-step task,
    or a question, and routes accordingly.

    - Actions (open, install, etc.) → execute immediately via tools
    - Tasks (setup X, take screenshot, etc.) → run agent loop
    - Questions → standard LLM query
    """
    engine = get_engine()
    prompt = request.prompt

    # 1. Check for system actions
    from nvh.core.action_detector import detect_action
    action = detect_action(prompt)
    if action:
        try:
            from nvh.core.tools import ToolRegistry
            tools = ToolRegistry()
            result = await tools.execute(action.tool_name, action.arguments)
            return _response_envelope({
                "type": "action",
                "action": action.tool_name,
                "output": result.output if result.success else result.error,
                "success": result.success,
            })
        except Exception as exc:
            return _response_envelope({
                "type": "action",
                "action": action.tool_name,
                "output": str(exc),
                "success": False,
            })

    # 2. Check for task-like inputs → agent loop
    from nvh.cli.repl import _is_task_input
    if _is_task_input(prompt):
        try:
            from nvh.core.agent_loop import run_agent_loop
            result = await run_agent_loop(
                task=prompt,
                engine=engine,
                max_iterations=15,
            )
            return _response_envelope({
                "type": "agent",
                "task": prompt,
                "output": result.final_response,
                "completed": result.completed,
                "steps": result.total_iterations,
                "tool_calls": result.total_tool_calls,
            })
        except Exception as exc:
            return _response_envelope({
                "type": "agent",
                "task": prompt,
                "output": str(exc),
                "completed": False,
            })

    # 3. Regular question → LLM query
    try:
        response = await engine.query(
            prompt=prompt,
            provider=request.provider,
            model=request.model,
            system_prompt=request.system_prompt,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            stream=False,
        )
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc))

    result = _serialize_completion(response)
    result["type"] = "query"
    return _response_envelope(result)


# -- /v1/agents ---------------------------------------------------------------

@app.get("/v1/agents/presets", summary="List available agent presets and their roles")
async def agent_presets(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    return _response_envelope({"presets": list_presets()})


@app.post("/v1/agents/analyze", summary="Preview which agents would be generated for a query")
async def agents_analyze(request: AgentAnalyzeRequest, _auth: None = Depends(require_auth)) -> dict[str, Any]:
    try:
        if request.preset:
            personas = get_preset_agents(request.preset, request.prompt)
        else:
            personas = generate_agents(request.prompt, num_agents=request.num_agents)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc))

    agent_data = [
        {
            "role": p.role,
            "expertise": p.expertise,
            "perspective": p.perspective,
            "system_prompt": p.system_prompt,
            "weight_boost": p.weight_boost,
        }
        for p in personas
    ]

    return _response_envelope({
        "agents": agent_data,
        "count": len(agent_data),
        "prompt_preview": request.prompt[:200] + ("..." if len(request.prompt) > 200 else ""),
    })


# -- /v1/ws/query -------------------------------------------------------------

@app.websocket("/v1/ws/query")
async def ws_query(websocket: WebSocket) -> None:
    """WebSocket endpoint for real-time single-provider streaming.

    Client sends one JSON message:
      {"type": "query_request", "prompt": "...", "provider": "...", ...}

    Server streams:
      {"type": "chunk", "delta": "...", "accumulated": "..."}
      {"type": "complete", "content": "...", "provider": "...", ...}
      {"type": "error", "error": "..."}
    """
    if not await _authenticate_websocket(websocket):
        return
    await websocket.accept()
    engine = get_engine()

    try:
        raw = await websocket.receive_json()
    except WebSocketDisconnect:
        return
    except Exception:
        await websocket.send_json({"type": "error", "error": "Invalid message format"})
        await websocket.close()
        return

    if raw.get("type") != "query_request":
        await websocket.send_json({"type": "error", "error": "Expected type 'query_request'"})
        await websocket.close()
        return

    from nvh.providers.base import Message, StreamChunk

    prompt = raw.get("prompt", "")
    provider_name = _normalize_optional_selection(raw.get("provider"))
    model_name = _normalize_optional_selection(raw.get("model"))
    sys_prompt = raw.get("system_prompt") or engine.config.defaults.system_prompt or None
    temperature = raw.get("temperature") or engine.config.defaults.temperature
    max_tokens = raw.get("max_tokens") or engine.config.defaults.max_tokens

    try:
        await engine.initialize()
        await engine._check_budget()
    except BudgetExceededError as exc:
        await websocket.send_json({"type": "error", "error": str(exc)})
        await websocket.close()
        return
    except Exception as exc:
        logger.exception("WebSocket query preflight failed")
        await websocket.send_json({
            "type": "error",
            "error": f"Local query preflight failed: {type(exc).__name__}: {exc}",
        })
        await websocket.close()
        return

    try:
        decision = engine.router.route(
            query=prompt,
            provider_override=provider_name,
            model_override=model_name,
        )
    except Exception as exc:
        logger.exception("WebSocket query routing failed")
        await websocket.send_json({
            "type": "error",
            "error": f"Could not choose an AI advisor: {type(exc).__name__}: {exc}",
        })
        await websocket.close()
        return

    if not engine.registry.has(decision.provider):
        await websocket.send_json({"type": "error", "error": f"Provider '{decision.provider}' not available."})
        await websocket.close()
        return

    provider = engine.registry.get(decision.provider)
    messages: list[Message] = []
    if sys_prompt:
        messages.append(Message(role="system", content=sys_prompt))
    messages.append(Message(role="user", content=prompt))

    accumulated = ""
    last_chunk: StreamChunk | None = None
    stream_succeeded = False

    try:
        stream_result = provider.stream(
            messages=messages,
            model=decision.model or None,
            temperature=temperature,
            max_tokens=max_tokens,
            system_prompt=sys_prompt,
        )
        if inspect.isawaitable(stream_result):
            stream_result = await stream_result
        async for chunk in stream_result:
            last_chunk = chunk
            if chunk.delta:
                accumulated += chunk.delta
                await websocket.send_json({
                    "type": "chunk",
                    "delta": chunk.delta,
                    "accumulated": accumulated,
                })
            if chunk.is_final:
                break

        stream_succeeded = True
        complete_payload: dict[str, Any] = {
            "type": "complete",
            "content": accumulated,
            "provider": decision.provider,
            "model": decision.model,
        }
        if last_chunk:
            if last_chunk.usage:
                complete_payload["usage"] = last_chunk.usage.model_dump()
            if last_chunk.cost_usd is not None:
                complete_payload["cost_usd"] = _decimal_to_str(last_chunk.cost_usd)
            if last_chunk.finish_reason:
                complete_payload["finish_reason"] = last_chunk.finish_reason.value

        await websocket.send_json(complete_payload)

        # Observability: tell the rate manager about the success so
        # circuit breakers track WS traffic, and log the query into
        # the analytics DB so it shows up in /v1/analytics and
        # /v1/budget/status. Without this the WebSocket path was a
        # blind spot in every dashboard.
        try:
            engine.rate_manager.record_success(decision.provider)
        except Exception as exc:
            logger.debug("rate_manager.record_success failed: %s", exc)

        if last_chunk:
            from nvh.providers.base import CompletionResponse, FinishReason, Usage
            resp = CompletionResponse(
                content=accumulated,
                model=last_chunk.model or decision.model,
                provider=decision.provider,
                usage=last_chunk.usage if last_chunk.usage else Usage(),
                cost_usd=last_chunk.cost_usd if last_chunk.cost_usd is not None else Decimal("0"),
                latency_ms=0,
                finish_reason=last_chunk.finish_reason or FinishReason.STOP,
            )
            try:
                await engine._log_query(resp, mode="simple")
            except Exception as exc:
                logger.debug("engine._log_query failed for ws_query: %s", exc)

    except WebSocketDisconnect:
        # Client hung up mid-stream. Still record the failure so the
        # rate manager sees it — a disconnect mid-stream is almost
        # always caused by provider stall, not a clean client exit.
        try:
            engine.rate_manager.record_failure(
                decision.provider,
                Exception("client disconnected mid-stream"),
            )
        except Exception as exc:
            logger.debug("rate_manager.record_failure failed: %s", exc)
        return
    except Exception as exc:
        logger.exception("Unexpected error in /v1/ws/query")
        try:
            engine.rate_manager.record_failure(decision.provider, exc)
        except Exception as rec_exc:
            logger.debug("rate_manager.record_failure failed: %s", rec_exc)
        try:
            await websocket.send_json({
                "type": "error",
                "error": f"{type(exc).__name__}: {str(exc)[:500]}",
            })
        except Exception as send_exc:
            logger.debug("error-send failed in ws_query: %s", send_exc)
    finally:
        if not stream_succeeded:
            logger.info(
                "ws_query terminated without success (provider=%s)",
                decision.provider,
            )
        try:
            await websocket.close()
        except Exception as exc:
            logger.debug("websocket.close failed in ws_query: %s", exc)


# -- /v1/ws/council -----------------------------------------------------------

@app.websocket("/v1/ws/council")
async def ws_council(websocket: WebSocket) -> None:
    """WebSocket endpoint for real-time council streaming.

    Client sends one JSON message:
      {
        "type": "council_request",
        "prompt": "...",
        "auto_agents": true,
        "preset": null,
        "strategy": "weighted_consensus",
        "members": null,
        "weights": null,
        "temperature": 1.0,
        "max_tokens": 4096,
        "system_prompt": null
      }

    Server streams a sequence of typed events (see CouncilOrchestrator.run_council_streaming).
    """
    if not await _authenticate_websocket(websocket):
        return
    await websocket.accept()
    engine = get_engine()

    try:
        raw = await websocket.receive_json()
    except WebSocketDisconnect:
        return
    except Exception:
        await websocket.send_json({"type": "error", "error": "Invalid message format"})
        await websocket.close()
        return

    if raw.get("type") != "council_request":
        await websocket.send_json({"type": "error", "error": "Expected type 'council_request'"})
        await websocket.close()
        return

    prompt = raw.get("prompt", "")
    auto_agents = bool(raw.get("auto_agents", False))
    preset = raw.get("preset") or None
    strategy = raw.get("strategy") or None
    members_override = raw.get("members") or None
    weights_override = raw.get("weights") or None
    temperature = float(raw.get("temperature") or engine.config.defaults.temperature)
    max_tokens = int(raw.get("max_tokens") or engine.config.defaults.max_tokens)
    system_prompt = raw.get("system_prompt") or engine.config.defaults.system_prompt or None

    try:
        await engine._check_budget()
    except BudgetExceededError as exc:
        await websocket.send_json({"type": "error", "error": str(exc)})
        await websocket.close()
        return

    async def _send(event: dict) -> None:
        """Send a single event over the WebSocket."""
        try:
            await websocket.send_json(event)
        except WebSocketDisconnect:
            pass  # client disconnected, expected
        except Exception:
            logger.debug("WebSocket send failed for event type=%s", event.get("type"))

    try:
        council_result = await engine.council.run_council_streaming(
            query=prompt,
            on_event=_send,
            members_override=members_override,
            weights_override=weights_override,
            strategy=strategy,
            system_prompt=system_prompt,
            temperature=temperature,
            max_tokens=max_tokens,
            synthesize=True,
            auto_agents=auto_agents,
            agent_preset=preset,
            budget_check=engine._check_budget,
        )

        # Observability: log every member response and the synthesis
        # into the analytics DB so WS councils show up in
        # /v1/analytics, /v1/budget/status, and conversation history.
        # Before this, council sessions run via WebSocket were
        # invisible to every dashboard — the HTTP council path logged,
        # but the WS path was a total blind spot.
        if council_result is not None:
            for resp in council_result.member_responses.values():
                try:
                    await engine._log_query(resp, mode="council")
                except Exception as log_exc:
                    logger.debug("engine._log_query (council member) failed: %s", log_exc)
            if council_result.synthesis is not None:
                try:
                    await engine._log_query(council_result.synthesis, mode="council")
                except Exception as log_exc:
                    logger.debug("engine._log_query (council synthesis) failed: %s", log_exc)

    except ValueError as exc:
        await _send({"type": "error", "error": str(exc)})
    except BudgetExceededError as exc:
        await _send({"type": "error", "error": str(exc)})
    except WebSocketDisconnect:
        return
    except Exception:
        logger.exception("Unexpected error in /v1/ws/council")
        await _send({"type": "error", "error": "Internal server error"})
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


# -- /v1/webhooks -------------------------------------------------------------

@app.get("/v1/webhooks", summary="List configured webhooks (secrets masked)")
async def list_webhooks(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    engine = get_engine()
    return _response_envelope({"webhooks": engine.webhooks.list_hooks()})


class WebhookTestRequest(BaseModel):
    url: str
    secret: str = ""


@app.post("/v1/webhooks/test", summary="Send a test event to a webhook URL")
async def test_webhook(request: WebhookTestRequest, _auth: None = Depends(require_auth)) -> dict[str, Any]:
    from nvh.core.webhooks import WebhookConfig, WebhookEvent, WebhookManager

    try:
        _validate_webhook_url(request.url)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))

    manager = WebhookManager()
    manager.register(WebhookConfig(
        url=request.url,
        events=[],  # empty = receive all
        secret=request.secret,
    ))

    try:
        payload_data = {"message": "This is a test webhook from Hive.", "url": request.url}
        await manager.emit(WebhookEvent.QUERY_COMPLETE, payload_data)
        # Drain immediately without starting background worker
        hook = manager._hooks[0]
        import time

        from nvh.core.webhooks import WebhookPayload
        wh_payload = WebhookPayload(event=WebhookEvent.QUERY_COMPLETE, timestamp=time.time(), data=payload_data)
        success = await manager._dispatch(hook, wh_payload)
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc))

    if not success:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Webhook delivery to '{request.url}' failed after retries.",
        )
    return _response_envelope({"delivered": True, "url": request.url})


# -- /v1/auth -----------------------------------------------------------------

class RegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=64)
    password: str = Field(..., min_length=8)
    email: str | None = None


class LoginRequest(BaseModel):
    username: str
    password: str


class CreateTokenRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=128)
    scopes: str = "query,council,compare"


@app.post("/v1/auth/register", summary="Register a new user (first user becomes admin)", status_code=status.HTTP_201_CREATED)
async def auth_register(request: RegisterRequest, req: Request) -> dict[str, Any]:
    """Create a new user. The very first user automatically receives the admin role."""
    from nvh.auth.auth import create_user, get_user_count

    _check_auth_rate_limit(req.client.host if req.client else "unknown")

    try:
        count = await get_user_count()
        role = "admin" if count == 0 else "user"
        user = await create_user(
            username=request.username,
            password=request.password,
            role=role,
            email=request.email,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))
    except Exception:
        logger.exception("Error creating user")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Internal server error")

    return _response_envelope({
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "role": user.role,
        "created_at": user.created_at.isoformat(),
    })


@app.post("/v1/auth/login", summary="Authenticate and receive an API token")
async def auth_login(request: LoginRequest, req: Request) -> dict[str, Any]:
    """Verify credentials and create a new API session token."""
    from nvh.auth.auth import authenticate_user, create_token_for_user

    _check_auth_rate_limit(req.client.host if req.client else "unknown")

    user = await authenticate_user(request.username, request.password)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    raw_token, token_record = await create_token_for_user(
        user_id=user.id,
        name="login_session",
        scopes="query,council,compare,admin" if user.role == "admin" else "query,council,compare",
        expires_at=datetime.now(UTC) + timedelta(hours=24),
    )

    return _response_envelope({
        "token": raw_token,
        "token_id": token_record.id,
        "user": {
            "id": user.id,
            "username": user.username,
            "role": user.role,
        },
        "note": "Save this token — it will not be shown again.",
    })


ALLOWED_SCOPES = {"ask", "convene", "poll", "read", "query", "council", "compare"}  # accept both old and new names

@app.post("/v1/auth/tokens", summary="Create a new API token", status_code=status.HTTP_201_CREATED)
async def auth_create_token(
    request: CreateTokenRequest,
    current_user: Any = Depends(require_scope("query")),
) -> dict[str, Any]:
    from nvh.auth.auth import create_token_for_user

    requested = set(request.scopes.split(","))
    is_admin = getattr(current_user, "role", None) == "admin"
    if not requested.issubset(ALLOWED_SCOPES | {"admin"}):
        raise HTTPException(400, "Invalid scopes. Allowed: query, council, compare, read")
    if "admin" in requested and not is_admin:
        raise HTTPException(403, "Only admins can create tokens with 'admin' scope")

    raw_token, token_record = await create_token_for_user(
        user_id=current_user.id,
        name=request.name,
        scopes=request.scopes,
    )
    return _response_envelope({
        "token": raw_token,
        "id": token_record.id,
        "name": token_record.name,
        "scopes": token_record.scopes,
        "created_at": token_record.created_at.isoformat(),
        "note": "Save this token — it will not be shown again.",
    })


@app.get("/v1/auth/tokens", summary="List user's API tokens")
async def auth_list_tokens(current_user: Any = Depends(require_user_auth)) -> dict[str, Any]:
    from nvh.auth.auth import list_user_tokens

    tokens = await list_user_tokens(current_user.id)
    return _response_envelope({
        "tokens": [
            {
                "id": t.id,
                "name": t.name,
                "scopes": t.scopes,
                "created_at": t.created_at.isoformat(),
                "last_used": t.last_used.isoformat() if t.last_used else None,
                "expires_at": t.expires_at.isoformat() if t.expires_at else None,
                "is_active": t.is_active,
            }
            for t in tokens
        ]
    })


@app.delete("/v1/auth/tokens/{token_id}", summary="Revoke an API token")
async def auth_revoke_token(
    token_id: str = Path(..., description="Token ID to revoke"),
    current_user: Any = Depends(require_user_auth),
) -> dict[str, Any]:
    from nvh.auth.auth import list_user_tokens, revoke_token

    # Verify the token belongs to the current user (unless admin)
    if current_user.role != "admin":
        user_tokens = await list_user_tokens(current_user.id)
        if not any(t.id == token_id for t in user_tokens):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="You can only revoke your own tokens.",
            )

    revoked = await revoke_token(token_id)
    if not revoked:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Token '{token_id}' not found.",
        )
    return _response_envelope({"revoked": True, "token_id": token_id})


@app.get("/v1/auth/me", summary="Get current authenticated user info")
async def auth_me(current_user: Any = Depends(require_user_auth)) -> dict[str, Any]:
    return _response_envelope({
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
        "role": current_user.role,
        "is_active": current_user.is_active,
        "created_at": current_user.created_at.isoformat(),
        "last_login": current_user.last_login.isoformat() if current_user.last_login else None,
    })


# ---------------------------------------------------------------------------
# Part 1: Ollama management endpoints
# ---------------------------------------------------------------------------

def _get_ollama_base_url() -> str:
    """Return the Ollama base URL from environment or default."""
    return os.environ.get("OLLAMA_HOST", "http://localhost:11434")


class OllamaPullRequest(BaseModel):
    model: str = Field(..., min_length=1, description="Model name to pull, e.g. 'llama3.2-vision'")


async def _ollama_pull_stream(model: str) -> AsyncGenerator:
    """Stream SSE events for an Ollama model pull."""
    import httpx

    base_url = _get_ollama_base_url()
    url = f"{base_url}/api/pull"

    try:
        async with httpx.AsyncClient(timeout=None) as client:
            async with client.stream(
                "POST",
                url,
                json={"name": model, "stream": True},
            ) as response:
                if response.status_code != 200:
                    err = await response.aread()
                    payload = json.dumps({"error": err.decode(errors="replace")[:500]})
                    yield f"event: error\ndata: {payload}\n\n".encode()
                    return

                async for line in response.aiter_lines():
                    if not line.strip():
                        continue
                    try:
                        data = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    ollama_status = data.get("status", "")

                    # Ollama sends a final {"status": "success"} when done
                    if ollama_status == "success":
                        payload = json.dumps({"status": "success", "model": model})
                        yield f"event: complete\ndata: {payload}\n\n".encode()
                        return

                    # Progress events carry completed/total byte counts
                    completed = data.get("completed")
                    total = data.get("total")
                    percent: float | None = None
                    if completed is not None and total and total > 0:
                        percent = round(completed / total * 100, 1)

                    progress_payload: dict[str, Any] = {
                        "status": "pulling",
                        "digest": data.get("digest", ""),
                        "ollama_status": ollama_status,
                    }
                    if completed is not None:
                        progress_payload["completed"] = completed
                    if total is not None:
                        progress_payload["total"] = total
                    if percent is not None:
                        progress_payload["percent"] = percent

                    yield f"event: progress\ndata: {json.dumps(progress_payload)}\n\n".encode()

    except Exception as exc:
        payload = json.dumps({"error": str(exc)})
        yield f"event: error\ndata: {payload}\n\n".encode()


@app.post("/v1/ollama/pull", summary="Pull an Ollama model (SSE progress stream)")
async def ollama_pull(
    request: OllamaPullRequest,
    _auth: None = Depends(require_auth),
) -> StreamingResponse:
    """Trigger an Ollama model pull.  Response is a Server-Sent Events stream.

    Events emitted:
    - ``event: progress`` — download progress with completed/total bytes and percent
    - ``event: complete`` — pull finished successfully
    - ``event: error``    — pull failed
    """
    return StreamingResponse(
        _ollama_pull_stream(request.model),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/v1/ollama/models", summary="List installed Ollama models with sizes")
async def ollama_list_models(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Return all models currently installed in Ollama with name, size, and digest."""
    import httpx

    base_url = _get_ollama_base_url()
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(f"{base_url}/api/tags")
            resp.raise_for_status()
            data = resp.json()
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Could not reach Ollama at {base_url}: {exc}",
        )

    models = []
    for m in data.get("models", []):
        models.append({
            "name": m.get("name", ""),
            "size_bytes": m.get("size", 0),
            "size_gb": round(m.get("size", 0) / (1024 ** 3), 2),
            "digest": m.get("digest", ""),
            "modified_at": m.get("modified_at", ""),
            "details": m.get("details", {}),
        })

    return _response_envelope({"models": models, "count": len(models)})


@app.delete("/v1/ollama/models/{name:path}", summary="Delete an installed Ollama model")
async def ollama_delete_model(
    name: str = Path(..., description="Model name, e.g. 'llama3.2-vision'"),
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Remove a model from Ollama's local store."""
    import httpx

    base_url = _get_ollama_base_url()
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.request(
                "DELETE",
                f"{base_url}/api/delete",
                json={"name": name},
            )
            if resp.status_code == 404:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail=f"Model '{name}' not found in Ollama.",
                )
            resp.raise_for_status()
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Could not reach Ollama at {base_url}: {exc}",
        )

    return _response_envelope({"deleted": True, "model": name})


@app.post("/v1/system/auto-setup", summary="Generate a setup plan: what models to pull, sizes, and estimated time")
async def system_auto_setup(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """One-shot setup planning endpoint for the web UI setup wizard.

    1. Detects GPU hardware via ``detect_gpus()``
    2. Gets model recommendations via ``recommend_models()``
    3. Checks which recommended models are already installed in Ollama
    4. Returns the plan: models to pull, estimated sizes, and estimated download time

    The UI can call this once, show the plan, then call ``POST /v1/ollama/pull``
    for each missing model to perform the actual downloads.
    """
    import httpx

    # --- GPU detection ---
    gpus = detect_gpus()
    recs = recommend_models(gpus)
    opts = get_ollama_optimizations(gpus)

    # --- Installed models ---
    base_url = _get_ollama_base_url()
    installed_names: set[str] = set()
    ollama_reachable = False
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(f"{base_url}/api/tags")
            resp.raise_for_status()
            data = resp.json()
            for m in data.get("models", []):
                raw = m.get("name", "")
                # Strip tag for loose matching: "llama3.2-vision:latest" -> "llama3.2-vision"
                installed_names.add(raw)
                installed_names.add(raw.split(":")[0])
            ollama_reachable = True
    except Exception:
        pass

    # --- Build plan ---
    # Rough size estimates in GB (used for ETA when exact size is unknown).
    # Only tags that actually exist on Ollama's registry — earlier entries
    # included invented high-tier tags which returned 404 on pull.
    size_estimates: dict[str, float] = {
        "nemotron-mini": 2.0,
        "llama3.1:8b": 4.7,
        "qwen3:8b": 6.0,
        "qwen2.5-coder:7b": 5.0,
        "qwen2.5-coder:32b": 18.0,
        "nemotron": 40.0,
        "codellama": 3.8,
        "llama3.2:3b": 2.0,
        "llama3.2-vision": 7.0,
        "minicpm-v": 5.0,
        "moondream": 2.0,
        "gemma3:4b": 3.0,
        "llama3.3:70b-instruct-q4_K_M": 40.0,
    }
    # Assume ~200 Mbps download (typical cloud / consumer broadband)
    download_mbps = 200.0

    to_pull = []
    already_installed = []

    for rec in recs:
        model_name = rec.model
        is_installed = model_name in installed_names or model_name.split(":")[0] in installed_names

        size_gb = size_estimates.get(model_name, rec.vram_required_gb or 4.0)
        size_bytes = int(size_gb * 1024 ** 3)
        eta_seconds = int((size_gb * 8 * 1024) / download_mbps)  # GB -> Gb -> Mb -> s

        entry: dict[str, Any] = {
            "model": model_name,
            "reason": rec.reason,
            "tier": rec.tier,
            "estimated_size_gb": size_gb,
            "estimated_size_bytes": size_bytes,
            "estimated_download_seconds": eta_seconds,
            "already_installed": is_installed,
        }

        if is_installed:
            already_installed.append(entry)
        else:
            to_pull.append(entry)

    gpu_data = [
        {
            "name": g.name,
            "vram_gb": g.vram_gb,
            "driver_version": g.driver_version,
            "cuda_version": g.cuda_version,
            "index": g.index,
        }
        for g in gpus
    ]

    return _response_envelope({
        "gpus": gpu_data,
        "gpu_count": len(gpus),
        "ollama_reachable": ollama_reachable,
        "ollama_url": base_url,
        "optimizations": {
            "flash_attention": opts.flash_attention,
            "num_parallel": opts.num_parallel,
            "recommended_ctx": opts.recommended_ctx,
            "recommended_quant": opts.recommended_quant,
            "architecture": opts.architecture,
            "notes": opts.notes,
        },
        "plan": {
            "to_pull": to_pull,
            "already_installed": already_installed,
            "total_to_pull": len(to_pull),
            "total_estimated_gb": round(sum(m["estimated_size_gb"] for m in to_pull), 1),
            "total_estimated_download_seconds": sum(m["estimated_download_seconds"] for m in to_pull),
        },
    })


# ---------------------------------------------------------------------------
# Part 1b: ComfyUI management endpoints
# ---------------------------------------------------------------------------

class ComfyUIInstallRequest(BaseModel):
    torch_profile: str = Field(
        default="nvidia-cu130",
        description="PyTorch install profile: nvidia-cu130, nvidia-cu121, cpu, or skip",
    )
    force_update: bool = False

    @field_validator("torch_profile")
    @classmethod
    def validate_torch_profile(cls, value: str) -> str:
        allowed = {"nvidia-cu130", "nvidia-cu121", "cpu", "skip"}
        if value not in allowed:
            raise ValueError(f"torch_profile must be one of: {', '.join(sorted(allowed))}")
        return value


class ComfyUIStartRequest(BaseModel):
    host: str = "127.0.0.1"
    port: int = Field(default=8188, ge=1024, le=65535)

    @field_validator("host")
    @classmethod
    def validate_host(cls, value: str) -> str:
        if value not in {"127.0.0.1", "localhost"}:
            raise ValueError("ComfyUI auto-start is restricted to localhost.")
        return value


class ComfyUIModelPlanRequest(BaseModel):
    example_ids: list[str] = Field(default_factory=list)


@app.get("/v1/comfyui/examples", summary="List curated ComfyUI workflow examples")
async def comfyui_examples(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Return nvHive's curated ComfyUI starter workflow manifest."""
    from nvh.integrations.installs.comfyui import examples_as_dicts

    examples = examples_as_dicts()
    sources = sorted({item["source_url"] for item in examples})
    return _response_envelope({
        "examples": examples,
        "count": len(examples),
        "sources": sources,
    })


@app.post("/v1/comfyui/model-plan", summary="Write a ComfyUI model download plan")
async def comfyui_model_plan(
    request: ComfyUIModelPlanRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Persist selected ComfyUI workflow model requirements and source links."""
    from nvh.integrations.installs.comfyui import comfyui_model_plan, write_model_plan

    plan_path = write_model_plan(request.example_ids or None)
    plan = comfyui_model_plan(request.example_ids or None)
    plan["plan_path"] = str(plan_path)
    return _response_envelope(plan)


@app.get("/v1/comfyui/status", summary="Detect local ComfyUI install and runtime status")
async def comfyui_status(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Return local ComfyUI install, process, and example-pack status."""
    from nvh.integrations.installs.comfyui import detect_comfyui

    return _response_envelope(detect_comfyui())


def _job_or_404(job_id: str) -> dict[str, Any]:
    from nvh.integrations.services.jobs import load_job

    try:
        return load_job(job_id)
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@app.get("/v1/jobs", summary="List persistent setup jobs")
async def setup_jobs(
    kind: str | None = None,
    status_filter: str | None = None,
    limit: int = 20,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return recent rootless install jobs persisted under NVH_HOME."""
    from nvh.integrations.services.jobs import list_jobs

    safe_limit = max(1, min(limit, 100))
    jobs = list_jobs(kind=kind, status=status_filter, limit=safe_limit)
    return _response_envelope({"jobs": jobs, "count": len(jobs)})


@app.get("/v1/jobs/{job_id}", summary="Get a persistent setup job")
async def setup_job(
    job_id: str,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return one persisted setup job by id."""
    return _response_envelope(_job_or_404(job_id))


@app.get("/v1/jobs/{job_id}/events", summary="Read persistent setup job events")
async def setup_job_events(
    job_id: str,
    after: int = 0,
    limit: int = 200,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return JSONL-backed setup job events after a sequence number."""
    from nvh.integrations.services.jobs import read_events

    _job_or_404(job_id)
    try:
        events = read_events(job_id, after=max(0, after), limit=max(1, min(limit, 500)))
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    return _response_envelope({"events": events, "count": len(events)})


@app.post("/v1/jobs/{job_id}/cancel", summary="Cancel a running setup job")
async def setup_job_cancel(
    job_id: str,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Request cancellation for an active setup job."""
    from nvh.integrations.services.jobs import cancel_job

    try:
        job = cancel_job(job_id)
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    return _response_envelope(job)


async def _comfyui_install_stream(
    request: ComfyUIInstallRequest,
) -> AsyncGenerator:
    """Stream SSE events for ComfyUI installation."""
    from nvh.integrations.installs.comfyui import install_comfyui

    async for event in install_comfyui(
        torch_profile=request.torch_profile,
        force_update=request.force_update,
    ):
        event_name = event.get("event", "progress")
        yield f"event: {event_name}\ndata: {json.dumps(event)}\n\n".encode()


@app.post("/v1/comfyui/install", summary="Install ComfyUI with nvHive examples")
async def comfyui_install(
    request: ComfyUIInstallRequest,
    _auth: None = Depends(require_auth),
) -> StreamingResponse:
    """Install or update ComfyUI and stream progress logs to the WebUI."""
    return StreamingResponse(
        _comfyui_install_stream(request),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.post("/v1/comfyui/start", summary="Start local ComfyUI")
async def comfyui_start(
    request: ComfyUIStartRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Start ComfyUI bound to localhost and return launch metadata."""
    from nvh.integrations.installs.comfyui import start_comfyui

    try:
        result = start_comfyui(host=request.host, port=request.port)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc))
    except Exception as exc:
        logger.warning("ComfyUI start failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc))

    return _response_envelope(result)


# ---------------------------------------------------------------------------
# Part 1c: Rootless AI Studio pack endpoints
# ---------------------------------------------------------------------------

class StudioPackInstallRequest(BaseModel):
    pack_ids: list[str] = Field(
        default_factory=lambda: ["starter"],
        description="Studio pack ids or bundle names: starter, all, llms, agents, comfy, game, creative, music",
    )
    force_update: bool = False

    @field_validator("pack_ids")
    @classmethod
    def validate_pack_ids(cls, value: list[str]) -> list[str]:
        if not value:
            raise ValueError("Select at least one studio pack.")
        return value


class StudioModelInstallRequest(BaseModel):
    model_ids: list[str] = Field(
        default_factory=list,
        description="Studio model ids or Ollama names selected in the setup wizard",
    )
    force_update: bool = False

    @field_validator("model_ids")
    @classmethod
    def validate_model_ids(cls, value: list[str]) -> list[str]:
        if not value:
            raise ValueError("Select at least one model.")
        return value


@app.get("/v1/studio/packs", summary="List rootless AI Studio packs")
async def studio_packs(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Return the no-root AI Studio pack catalog with local status."""
    from nvh.integrations.installs.studio_packs import catalog_with_status

    return _response_envelope(catalog_with_status())


@app.get("/v1/studio/models", summary="List recommended local models")
async def studio_models(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Return model-by-model recommendations and Ollama install status."""
    from nvh.integrations.installs.studio_packs import model_catalog_with_status

    return _response_envelope(model_catalog_with_status())


async def _studio_pack_install_stream(
    request: StudioPackInstallRequest,
) -> AsyncGenerator:
    """Stream SSE events for rootless AI Studio pack installation."""
    from nvh.integrations.installs.studio_packs import install_studio_packs

    async for event in install_studio_packs(
        request.pack_ids,
        force_update=request.force_update,
    ):
        event_name = event.get("event", "progress")
        yield f"event: {event_name}\ndata: {json.dumps(event)}\n\n".encode()


async def _studio_model_install_stream(
    request: StudioModelInstallRequest,
) -> AsyncGenerator:
    """Stream SSE events for selected model installation."""
    from nvh.integrations.installs.studio_packs import install_studio_models

    async for event in install_studio_models(
        request.model_ids,
        force_update=request.force_update,
    ):
        event_name = event.get("event", "progress")
        yield f"event: {event_name}\ndata: {json.dumps(event)}\n\n".encode()


@app.post("/v1/studio/install", summary="Install rootless AI Studio packs")
async def studio_pack_install(
    request: StudioPackInstallRequest,
    _auth: None = Depends(require_auth),
) -> StreamingResponse:
    """Install LLM, agent, ComfyUI, game-dev, creative, and music packs without root access."""
    return StreamingResponse(
        _studio_pack_install_stream(request),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.post("/v1/comfyui/install/job", summary="Start a background ComfyUI install job")
async def comfyui_install_job(
    request: ComfyUIInstallRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Install or update ComfyUI in the background with persistent progress."""
    from nvh.integrations.installs.comfyui import install_comfyui
    from nvh.integrations.services.jobs import start_job

    job = start_job(
        kind="comfyui-install",
        title="Install ComfyUI",
        request=request.model_dump(),
        source_factory=lambda: install_comfyui(
            torch_profile=request.torch_profile,
            force_update=request.force_update,
        ),
    )
    return _response_envelope(job)


@app.post("/v1/studio/models/install", summary="Install selected local models")
async def studio_model_install(
    request: StudioModelInstallRequest,
    _auth: None = Depends(require_auth),
) -> StreamingResponse:
    """Pull selected Ollama models using the rootless local runtime when needed."""
    return StreamingResponse(
        _studio_model_install_stream(request),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.post("/v1/studio/install/job", summary="Start a background AI Studio pack install job")
async def studio_pack_install_job(
    request: StudioPackInstallRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Install AI Studio packs in the background with persistent progress."""
    from nvh.integrations.installs.studio_packs import install_studio_packs
    from nvh.integrations.services.jobs import start_job

    job = start_job(
        kind="studio-pack-install",
        title="Install AI Studio packs",
        request=request.model_dump(),
        source_factory=lambda: install_studio_packs(
            request.pack_ids,
            force_update=request.force_update,
        ),
    )
    return _response_envelope(job)


@app.post("/v1/studio/models/install/job", summary="Start a background local model install job")
async def studio_model_install_job(
    request: StudioModelInstallRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Pull selected local models in the background with persistent progress."""
    from nvh.integrations.installs.studio_packs import install_studio_models
    from nvh.integrations.services.jobs import start_job

    job = start_job(
        kind="studio-model-install",
        title="Download local models",
        request=request.model_dump(),
        source_factory=lambda: install_studio_models(
            request.model_ids,
            force_update=request.force_update,
        ),
    )
    return _response_envelope(job)


# ---------------------------------------------------------------------------
# Part 2: Sandbox execution endpoints
# ---------------------------------------------------------------------------

# Module-level singleton so the Docker availability check is cached across
# requests for the lifetime of the process.
_sandbox_executor: Any = None


def _get_sandbox() -> Any:
    global _sandbox_executor
    if _sandbox_executor is None:
        from nvh.sandbox.executor import SandboxConfig, SandboxExecutor
        _sandbox_executor = SandboxExecutor(SandboxConfig())
    return _sandbox_executor


class SandboxExecuteRequest(BaseModel):
    code: str = Field(..., description="Source code to execute")
    language: str = Field(default="python", description="python, javascript, or bash")
    files: dict[str, str] | None = Field(
        default=None,
        description="Optional extra files: filename -> content (available alongside main code)",
    )


@app.post("/v1/sandbox/execute", summary="Execute code in an isolated sandbox container")
async def sandbox_execute(
    request: SandboxExecuteRequest,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Execute arbitrary code inside a sandboxed Docker container.

    - Network is disabled (``--network none``)
    - Memory is capped at 512 MB
    - Execution is time-limited to 30 s
    - Container runs as uid 1000, read-only filesystem with a small /tmp tmpfs
    - Falls back to a plain subprocess if Docker is unavailable
    """
    sandbox = _get_sandbox()

    try:
        result = await sandbox.execute(
            code=request.code,
            language=request.language,
            files=request.files,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Sandbox execution error: {exc}",
        )

    return _response_envelope({
        "stdout": result.stdout,
        "stderr": result.stderr,
        "exit_code": result.exit_code,
        "execution_time_ms": result.execution_time_ms,
        "timed_out": result.timed_out,
        "error": result.error,
        "files_created": result.files_created,
    })


@app.get("/v1/sandbox/status", summary="Sandbox availability and configuration")
async def sandbox_status(_auth: None = Depends(require_auth)) -> dict[str, Any]:
    """Return whether Docker is available for sandboxed execution and the active config."""
    sandbox = _get_sandbox()
    docker_available = await sandbox._check_docker()

    return _response_envelope({
        "docker_available": docker_available,
        "isolation_mode": "docker" if docker_available else "subprocess",
        "config": {
            "timeout_seconds": sandbox.config.timeout_seconds,
            "memory_limit_mb": sandbox.config.memory_limit_mb,
            "network_enabled": sandbox.config.network_enabled,
            "max_output_bytes": sandbox.config.max_output_bytes,
            "allowed_languages": sandbox.config.allowed_languages,
        },
    })


# ---------------------------------------------------------------------------
# File Lock Coordination
# ---------------------------------------------------------------------------

@app.get("/v1/locks", summary="Current file lock status")
async def get_lock_status(_auth: None = Depends(require_auth)):
    """Show all active file locks and which agents hold them."""
    from nvh.core.file_lock import get_file_lock_coordinator
    coordinator = get_file_lock_coordinator()
    status = await coordinator.get_status()
    return {"status": "success", "data": status}


class ConflictCheckRequest(BaseModel):
    changes: dict[str, str] = Field(
        ..., description="Mapping of agent_id to file_path they want to modify"
    )


@app.post("/v1/locks/check-conflicts", summary="Check for file modification conflicts")
async def check_conflicts(
    request: ConflictCheckRequest,
    _auth: None = Depends(require_auth),
):
    """Check if proposed file changes would conflict with existing locks."""
    from nvh.core.file_lock import get_file_lock_coordinator
    coordinator = get_file_lock_coordinator()
    conflicts = await coordinator.check_conflicts(request.changes)
    return {
        "status": "success",
        "data": {
            "has_conflicts": len(conflicts) > 0,
            "conflicts": [
                {
                    "file": c.file_path,
                    "holder": c.agent_a,
                    "requester": c.agent_b,
                    "lock_held": c.lock_type_held.value,
                    "lock_requested": c.lock_type_requested.value,
                }
                for c in conflicts
            ],
        },
    }


# ---------------------------------------------------------------------------
# Part 3: Conversations management endpoints
# ---------------------------------------------------------------------------

def _serialize_conversation(conv: Any) -> dict[str, Any]:
    return {
        "id": conv.id,
        "title": conv.title,
        "provider": conv.provider,
        "model": conv.model,
        "message_count": conv.message_count,
        "total_tokens": conv.total_tokens,
        "total_cost_usd": str(conv.total_cost_usd),
        "created_at": conv.created_at.isoformat() if conv.created_at else None,
        "updated_at": conv.updated_at.isoformat() if conv.updated_at else None,
    }


def _serialize_message(msg: Any) -> dict[str, Any]:
    return {
        "id": msg.id,
        "conversation_id": msg.conversation_id,
        "sequence": msg.sequence,
        "role": msg.role,
        "content": msg.content,
        "provider": msg.provider,
        "model": msg.model,
        "input_tokens": msg.input_tokens,
        "output_tokens": msg.output_tokens,
        "cost_usd": str(msg.cost_usd),
        "latency_ms": msg.latency_ms,
        "created_at": msg.created_at.isoformat() if msg.created_at else None,
    }


class ConversationQueryRequest(BaseModel):
    prompt: str
    provider: str | None = None
    model: str | None = None
    system_prompt: str | None = None
    temperature: float | None = Field(default=None, ge=0.0, le=2.0)
    max_tokens: int | None = Field(default=None, gt=0)


from nvh.storage import (
    repository as repo,  # noqa: E402 — after middleware setup to avoid circular import
)


@app.get("/v1/conversations", summary="List conversations with pagination")
async def list_conversations(
    limit: int = 20,
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return recent conversations ordered by last update, newest first."""
    try:
        convs = await repo.list_conversations(limit=min(limit, 200))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        )
    return _response_envelope([_serialize_conversation(c) for c in convs])


@app.get("/v1/conversations/{conversation_id}", summary="Get a single conversation with all messages")
async def get_conversation(
    conversation_id: str = Path(..., description="Conversation UUID"),
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Return a conversation and the full ordered message history."""
    try:
        conv = await repo.get_conversation(conversation_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        )

    if conv is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Conversation '{conversation_id}' not found.",
        )

    try:
        messages = await repo.get_messages(conversation_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        )

    data = _serialize_conversation(conv)
    data["messages"] = [_serialize_message(m) for m in messages]
    return _response_envelope(data)


@app.delete("/v1/conversations/{conversation_id}", summary="Delete a conversation and all its messages")
async def delete_conversation(
    conversation_id: str = Path(..., description="Conversation UUID"),
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Permanently remove a conversation and every message in it."""
    try:
        deleted = await repo.delete_conversation(conversation_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        )

    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Conversation '{conversation_id}' not found.",
        )

    return _response_envelope({"deleted": True, "conversation_id": conversation_id})


@app.post(
    "/v1/conversations/{conversation_id}/query",
    summary="Continue a conversation — send a message and receive a reply",
)
async def conversation_query(
    request: ConversationQueryRequest,
    conversation_id: str = Path(..., description="Conversation UUID"),
    _auth: None = Depends(require_auth),
) -> dict[str, Any]:
    """Send a new user message to an existing conversation and return the
    assistant response.  The full conversation history is included as context.

    If the ``conversation_id`` does not yet exist in the database it will be
    created automatically (useful for the UI which may generate the ID
    client-side before the first message).
    """
    engine = get_engine()

    try:
        response = await engine.query(
            prompt=request.prompt,
            provider=request.provider,
            model=request.model,
            system_prompt=request.system_prompt,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            stream=False,
            conversation_id=conversation_id,
        )
    except BudgetExceededError as exc:
        raise HTTPException(status_code=status.HTTP_402_PAYMENT_REQUIRED, detail=str(exc))
    except ProviderError as exc:
        raise HTTPException(status_code=status.HTTP_502_BAD_GATEWAY, detail=str(exc))
    except Exception as exc:
        logger.exception("Unexpected error in /v1/conversations/{id}/query")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(exc))

    return _response_envelope({
        "conversation_id": conversation_id,
        "response": _serialize_completion(response),
    })


# ---------------------------------------------------------------------------
# Entry point - `nvh serve`
# ---------------------------------------------------------------------------

def run_server(host: str = "0.0.0.0", port: int = 8000, reload: bool = False) -> None:
    """Start the Council API server with uvicorn.

    Called by the CLI via `nvh serve --host HOST --port PORT`.
    """
    import uvicorn

    os.environ["NVH_API_PORT"] = str(port)
    os.environ["NVH_API_SERVER_PROCESS"] = "1"

    uvicorn.run(
        "nvh.api.server:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info",
    )


# ---------------------------------------------------------------------------
# Context Files API
# ---------------------------------------------------------------------------

@app.get("/v1/context")
async def get_context_files(_auth: None = Depends(require_auth)):
    """List loaded COUNCIL.md context files."""
    from nvh.core.context_files import get_context_summary
    engine = get_engine()
    return {
        "status": "success",
        "data": {
            "files": get_context_summary(engine._context_files),
            "total": len(engine._context_files),
        },
    }


@app.post("/v1/context/reload")
async def reload_context(_auth: None = Depends(require_auth)):
    """Reload context files from disk."""
    from nvh.core.context_files import find_context_files
    engine = get_engine()
    engine._context_files = find_context_files()
    return {
        "status": "success",
        "data": {
            "files_loaded": len(engine._context_files),
            "names": [f.name for f in engine._context_files],
        },
    }


# ---------------------------------------------------------------------------
# Free Tier Setup API (for web UI setup wizard)
# ---------------------------------------------------------------------------

_PROVIDER_ENV_VAR_MAP = {
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "google": "GOOGLE_API_KEY",
    "groq": "GROQ_API_KEY",
    "mistral": "MISTRAL_API_KEY",
    "cohere": "COHERE_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "github": "GITHUB_TOKEN",
    "nvidia": "NVIDIA_API_KEY",
    "fireworks": "FIREWORKS_API_KEY",
    "cerebras": "CEREBRAS_API_KEY",
    "sambanova": "SAMBANOVA_API_KEY",
    "huggingface": "HUGGINGFACE_API_KEY",
    "ai21": "AI21_API_KEY",
    "siliconflow": "SILICONFLOW_API_KEY",
    "grok": "XAI_API_KEY",
    "perplexity": "PERPLEXITY_API_KEY",
    "together": "TOGETHER_API_KEY",
    "openrouter": "OPENROUTER_API_KEY",
    "llm7": "LLM7_API_KEY",
}

_PROVIDER_KEY_URLS = {
    "openai": "https://platform.openai.com/api-keys",
    "anthropic": "https://console.anthropic.com/settings/keys",
    "google": "https://aistudio.google.com/apikey",
    "groq": "https://console.groq.com/keys",
    "mistral": "https://console.mistral.ai/api-keys",
    "cohere": "https://dashboard.cohere.com/api-keys",
    "deepseek": "https://platform.deepseek.com/api_keys",
    "github": "https://github.com/settings/tokens",
    "nvidia": "https://build.nvidia.com/explore/discover",
    "fireworks": "https://fireworks.ai/account/api-keys",
    "cerebras": "https://cloud.cerebras.ai/",
    "sambanova": "https://cloud.sambanova.ai/",
    "huggingface": "https://huggingface.co/settings/tokens",
    "ai21": "https://studio.ai21.com/",
    "siliconflow": "https://cloud.siliconflow.cn/",
    "grok": "https://console.x.ai/",
    "perplexity": "https://www.perplexity.ai/settings/api",
    "together": "https://api.together.ai/settings/api-keys",
    "openrouter": "https://openrouter.ai/settings/keys",
    "llm7": "https://token.llm7.io/",
}

_PROVIDER_DOC_URLS = {
    "openai": "https://platform.openai.com/docs/overview",
    "anthropic": "https://docs.anthropic.com/",
    "google": "https://ai.google.dev/gemini-api/docs",
    "groq": "https://console.groq.com/docs/quickstart",
    "mistral": "https://docs.mistral.ai/",
    "cohere": "https://docs.cohere.com/",
    "deepseek": "https://api-docs.deepseek.com/",
    "github": "https://docs.github.com/en/github-models",
    "nvidia": "https://docs.nvidia.com/nim/",
    "fireworks": "https://docs.fireworks.ai/",
    "cerebras": "https://inference-docs.cerebras.ai/",
    "sambanova": "https://docs.sambanova.ai/",
    "huggingface": "https://huggingface.co/docs/api-inference/index",
    "ai21": "https://docs.ai21.com/",
    "siliconflow": "https://docs.siliconflow.cn/",
    "grok": "https://docs.x.ai/docs",
    "perplexity": "https://docs.perplexity.ai/",
    "together": "https://docs.together.ai/",
    "openrouter": "https://openrouter.ai/docs/quickstart",
    "llm7": "https://llm7.io/",
}

# Provider logo slugs for the @lobehub/icons CDN. Slug names match the
# lobehub icon ids; the frontend renders them from
# https://cdn.jsdelivr.net/npm/@lobehub/icons-static-png@latest/light/{slug}.png
# Returns None for providers without a brand mark there.
_PROVIDER_LOGO_SLUGS = {
    "openai": "openai",
    "anthropic": "anthropic",
    "google": "gemini",
    "groq": "groq",
    "mistral": "mistral",
    "cohere": "cohere",
    "deepseek": "deepseek",
    "github": "github",
    "nvidia": "nvidia",
    "fireworks": "fireworks",
    "cerebras": "cerebras",
    "sambanova": "sambanova",
    "huggingface": "huggingface",
    "ai21": "ai21",
    "siliconflow": "siliconflow",
    "grok": "grok",
    "perplexity": "perplexity",
    "together": "together",
    "openrouter": "openrouter",
    "ollama": "ollama",
    "llm7": None,
}

_PROVIDER_DEFAULT_CONFIG = {
    "openai": {"default_model": "gpt-4o", "fallback_model": "gpt-4o-mini"},
    "anthropic": {"default_model": "claude-sonnet-4-6", "fallback_model": "claude-haiku-4-5-20251001"},
    "google": {"default_model": "gemini/gemini-2.0-flash", "fallback_model": "gemini/gemini-2.0-flash"},
    "groq": {"default_model": "groq/llama-3.3-70b-versatile", "fallback_model": "groq/llama-3.1-8b-instant"},
    "mistral": {"default_model": "mistral/mistral-large-latest", "fallback_model": "mistral/mistral-small-latest"},
    "cohere": {"default_model": "command-r-plus", "fallback_model": "command-r"},
    "deepseek": {"default_model": "deepseek/deepseek-chat", "fallback_model": "deepseek/deepseek-chat", "base_url": "https://api.deepseek.com"},
    "github": {"default_model": "gpt-4o-mini", "fallback_model": "meta-llama-3.1-8b-instruct", "base_url": "https://models.inference.ai.azure.com"},
    "nvidia": {"default_model": "meta/llama-3.1-70b-instruct", "fallback_model": "meta/llama-3.1-8b-instruct", "base_url": "https://integrate.api.nvidia.com/v1"},
    "fireworks": {"default_model": "fireworks_ai/accounts/fireworks/models/llama-v3p1-70b-instruct", "fallback_model": "fireworks_ai/accounts/fireworks/models/llama-v3p1-8b-instruct"},
    "cerebras": {"default_model": "cerebras/llama3.1-70b", "fallback_model": "cerebras/llama3.1-8b"},
    "sambanova": {"default_model": "sambanova/Meta-Llama-3.1-70B-Instruct", "fallback_model": "sambanova/Meta-Llama-3.1-8B-Instruct"},
    "huggingface": {"default_model": "huggingface/meta-llama/Meta-Llama-3-8B-Instruct", "fallback_model": "huggingface/mistralai/Mistral-7B-Instruct-v0.3"},
    "ai21": {"default_model": "jamba-1.5-large", "fallback_model": "jamba-1.5-mini"},
    "siliconflow": {"default_model": "Qwen/Qwen2.5-7B-Instruct", "base_url": "https://api.siliconflow.cn/v1"},
    "grok": {"default_model": "xai/grok-2", "fallback_model": "xai/grok-2", "base_url": "https://api.x.ai/v1"},
    "perplexity": {"default_model": "perplexity/llama-3.1-sonar-large-128k-online", "fallback_model": "perplexity/llama-3.1-sonar-small-128k-online"},
    "together": {"default_model": "together_ai/meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo", "fallback_model": "together_ai/meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo"},
    "openrouter": {"default_model": "openrouter/meta-llama/llama-3.1-70b-instruct", "fallback_model": "openrouter/meta-llama/llama-3.1-8b-instruct"},
}


def _provider_env_var(provider_name: str) -> str:
    return _PROVIDER_ENV_VAR_MAP.get(provider_name, f"{provider_name.upper()}_API_KEY")


def _provider_docs_url(provider_name: str) -> str:
    return _PROVIDER_DOC_URLS.get(provider_name, "")


def _provider_key_is_configured(provider_name: str, env_var: str | None = None) -> bool:
    env_key = env_var or _provider_env_var(provider_name)
    return bool(env_key and os.environ.get(env_key))


@app.get("/v1/setup/free-providers")
async def get_free_providers(_auth: None = Depends(require_auth)):
    """List all free-tier providers and their setup status."""
    from nvh.core.advisor_profiles import ADVISOR_PROFILES
    from nvh.core.free_tier import FREE_TIER_ADVISORS, detect_available_free_advisors

    available = detect_available_free_advisors()
    available_names = {a.name for a in available}

    # Placeholder hints per provider
    key_placeholders = {
        "openai": "sk-...",
        "anthropic": "sk-ant-...",
        "google": "AIza...",
        "groq": "gsk_...",
        "mistral": "your-key...",
        "cohere": "your-key...",
        "github": "ghp_...",
        "grok": "xai-...",
    }

    providers = []
    for advisor in FREE_TIER_ADVISORS:
        profile = ADVISOR_PROFILES.get(advisor.name, None)
        requires_key = advisor.check_fn == "env"
        signup_tier = (
            "none" if not requires_key
            else "email" if advisor.priority <= 8
            else "account"
        )
        providers.append({
            "id": advisor.name,
            "name": profile.display_name if profile else advisor.name,
            "display_name": profile.display_name if profile else advisor.name,
            "daily_limit": advisor.daily_limit,
            "priority": advisor.priority,
            "configured": advisor.name in available_names or _provider_key_is_configured(advisor.name, advisor.env_var),
            "requires_signup": requires_key,
            "requires_key": requires_key,
            "signup_tier": signup_tier,
            "signup_url": _get_signup_url(advisor.name),
            "key_url": _get_signup_url(advisor.name),
            "docs_url": _provider_docs_url(advisor.name),
            "env_var": advisor.env_var,
            "env_key": advisor.env_var,
            "placeholder": key_placeholders.get(advisor.name, "your-key..."),
            "strengths": profile.strengths[:3] if profile else [],
            "free_tier_limits": profile.free_tier_limits if profile else "",
        })

    # Add zero-signup providers
    zero_signup = [
        {
            "id": "ollama",
            "name": "Ollama (Local AI)",
            "display_name": "Ollama (Local AI)",
            "daily_limit": "Unlimited (local GPU)",
            "priority": 1,
            "configured": "ollama" in available_names,
            "requires_signup": False,
            "requires_key": False,
            "signup_tier": "none",
            "signup_url": "",
            "key_url": "",
            "docs_url": "https://ollama.com/library",
            "env_var": "",
            "env_key": "",
            "placeholder": "",
            "strengths": ["Free", "Private", "Runs on your GPU"],
            "free_tier_limits": "Unlimited",
        },
        {
            "id": "llm7",
            "name": "LLM7 (Anonymous)",
            "display_name": "LLM7 (Anonymous)",
            "daily_limit": "30 RPM, no signup",
            "priority": 9,
            "configured": True,  # always available
            "requires_signup": False,
            "requires_key": False,
            "signup_tier": "none",
            "signup_url": "https://token.llm7.io/",
            "key_url": "https://token.llm7.io/",
            "docs_url": "https://llm7.io/",
            "env_var": "",
            "env_key": "",
            "placeholder": "",
            "strengths": ["No signup needed", "Anonymous access", "DeepSeek-R1 free"],
            "free_tier_limits": "30 RPM anonymous, 120 RPM with token (optional)",
        },
    ]

    # Add paid providers (not free-tier but users want to configure them)
    paid_providers = [
        {
            "id": "openai", "name": "OpenAI", "display_name": "OpenAI",
            "daily_limit": "Pay-as-you-go", "priority": 0,
            "configured": bool(os.environ.get("OPENAI_API_KEY")),
            "requires_signup": True, "requires_key": True,
            "signup_tier": "account", "signup_url": "https://platform.openai.com/api-keys",
            "key_url": "https://platform.openai.com/api-keys", "docs_url": "https://platform.openai.com/docs/overview",
            "env_var": "OPENAI_API_KEY", "env_key": "OPENAI_API_KEY",
            "placeholder": "sk-...",
            "strengths": ["GPT-4o", "Best all-around", "Function calling"],
            "free_tier_limits": "",
        },
        {
            "id": "anthropic", "name": "Anthropic", "display_name": "Anthropic",
            "daily_limit": "Pay-as-you-go", "priority": 0,
            "configured": bool(os.environ.get("ANTHROPIC_API_KEY")),
            "requires_signup": True, "requires_key": True,
            "signup_tier": "account", "signup_url": "https://console.anthropic.com/settings/keys",
            "key_url": "https://console.anthropic.com/settings/keys", "docs_url": "https://docs.anthropic.com/",
            "env_var": "ANTHROPIC_API_KEY", "env_key": "ANTHROPIC_API_KEY",
            "placeholder": "sk-ant-...",
            "strengths": ["Claude Sonnet", "Best for code", "200K context"],
            "free_tier_limits": "",
        },
        {
            "id": "deepseek", "name": "DeepSeek", "display_name": "DeepSeek",
            "daily_limit": "Pay-as-you-go (very cheap)", "priority": 0,
            "configured": bool(os.environ.get("DEEPSEEK_API_KEY")),
            "requires_signup": True, "requires_key": True,
            "signup_tier": "account", "signup_url": "https://platform.deepseek.com/api_keys",
            "key_url": "https://platform.deepseek.com/api_keys", "docs_url": "https://api-docs.deepseek.com/",
            "env_var": "DEEPSEEK_API_KEY", "env_key": "DEEPSEEK_API_KEY",
            "placeholder": "sk-...",
            "strengths": ["DeepSeek R1", "$0.07/M tokens", "Top reasoning"],
            "free_tier_limits": "",
        },
        {
            "id": "openrouter", "name": "OpenRouter", "display_name": "OpenRouter",
            "daily_limit": "Account required", "priority": 15,
            "configured": bool(os.environ.get("OPENROUTER_API_KEY")),
            "requires_signup": True, "requires_key": True,
            "signup_tier": "account", "signup_url": _get_signup_url("openrouter"),
            "key_url": _get_signup_url("openrouter"), "docs_url": _provider_docs_url("openrouter"),
            "env_var": "OPENROUTER_API_KEY", "env_key": "OPENROUTER_API_KEY",
            "placeholder": "sk-or-...",
            "strengths": ["Many models", "Fallback", "BYO credits"],
            "free_tier_limits": "",
        },
        {
            "id": "together", "name": "Together AI", "display_name": "Together AI",
            "daily_limit": "Account required", "priority": 16,
            "configured": bool(os.environ.get("TOGETHER_API_KEY")),
            "requires_signup": True, "requires_key": True,
            "signup_tier": "account", "signup_url": _get_signup_url("together"),
            "key_url": _get_signup_url("together"), "docs_url": _provider_docs_url("together"),
            "env_var": "TOGETHER_API_KEY", "env_key": "TOGETHER_API_KEY",
            "placeholder": "your-key...",
            "strengths": ["Open models", "Fast APIs", "Research friendly"],
            "free_tier_limits": "",
        },
        {
            "id": "perplexity", "name": "Perplexity", "display_name": "Perplexity",
            "daily_limit": "Account required", "priority": 17,
            "configured": bool(os.environ.get("PERPLEXITY_API_KEY")),
            "requires_signup": True, "requires_key": True,
            "signup_tier": "account", "signup_url": _get_signup_url("perplexity"),
            "key_url": _get_signup_url("perplexity"), "docs_url": _provider_docs_url("perplexity"),
            "env_var": "PERPLEXITY_API_KEY", "env_key": "PERPLEXITY_API_KEY",
            "placeholder": "pplx-...",
            "strengths": ["Search answers", "Citations", "Research"],
            "free_tier_limits": "",
        },
    ]

    # Merge, dedup by id, and sort
    seen = set()
    all_providers = []
    for p in zero_signup + providers + paid_providers:
        if p["id"] not in seen:
            seen.add(p["id"])
            all_providers.append(p)
    all_providers.sort(key=lambda p: p["priority"])

    # Attach a logo slug for the @lobehub/icons CDN. The frontend renders it
    # from https://cdn.jsdelivr.net/npm/@lobehub/icons-static-png@latest/light/{slug}.png
    # Falls back to a text initial when slug is null.
    for p in all_providers:
        p["logo_slug"] = _PROVIDER_LOGO_SLUGS.get(p["id"])

    return {
        "status": "success",
        "data": {
            "providers": all_providers,
            "configured_count": sum(1 for p in all_providers if p["configured"]),
            "total_count": len(all_providers),
        },
    }


_ALLOWED_PROVIDERS = {
    "openai", "anthropic", "google", "groq", "mistral",
    "cohere", "deepseek", "github", "nvidia", "fireworks",
    "cerebras", "sambanova", "huggingface", "ai21",
    "siliconflow", "grok", "perplexity", "together",
    "openrouter", "ollama",
}


class SaveKeyRequest(BaseModel):
    provider: str = Field(..., min_length=1, max_length=32)
    api_key: str = Field(..., min_length=10, max_length=500)

    @field_validator("provider")
    @classmethod
    def validate_provider(cls, v: str) -> str:
        if v not in _ALLOWED_PROVIDERS:
            raise ValueError(
                f"Unknown provider '{v}'. Allowed: "
                f"{', '.join(sorted(_ALLOWED_PROVIDERS))}"
            )
        return v


def _provider_env_file() -> FilePath:
    try:
        from nvh.integrations.workspace.storage import storage_layout
        layout = storage_layout()
        return FilePath(layout.config_dir) / ".env"
    except Exception:
        from nvh.config.settings import DEFAULT_CONFIG_DIR
        return FilePath(DEFAULT_CONFIG_DIR) / ".env"


def _provider_config_file() -> FilePath:
    try:
        from nvh.integrations.workspace.storage import storage_layout
        layout = storage_layout()
        return FilePath(layout.config_dir) / "config.yaml"
    except Exception:
        from nvh.config.settings import DEFAULT_CONFIG_PATH
        return FilePath(DEFAULT_CONFIG_PATH)


def _write_provider_env_key(env_key: str, api_key: str) -> FilePath:
    env_file = _provider_env_file()
    env_file.parent.mkdir(parents=True, exist_ok=True)
    lines = env_file.read_text(encoding="utf-8").splitlines() if env_file.exists() else []
    updated = False
    next_lines: list[str] = []
    for line in lines:
        if line.strip().startswith(f"{env_key}="):
            next_lines.append(f"{env_key}={api_key}")
            updated = True
        else:
            next_lines.append(line)
    if not updated:
        if next_lines and next_lines[-1].strip():
            next_lines.append("")
        next_lines.append(f"{env_key}={api_key}")
    env_file.write_text("\n".join(next_lines) + "\n", encoding="utf-8")
    try:
        env_file.chmod(0o600)
    except Exception:
        pass
    return env_file


def _enable_provider_in_config(provider: str, env_key: str) -> FilePath:
    import yaml

    config_file = _provider_config_file()
    config_file.parent.mkdir(parents=True, exist_ok=True)
    if config_file.exists():
        data = yaml.safe_load(config_file.read_text(encoding="utf-8")) or {}
        if not isinstance(data, dict):
            data = {}
    else:
        data = {}

    data.setdefault("version", "1")
    data.setdefault("defaults", {})
    section_name = "providers" if "providers" in data and "advisors" not in data else "advisors"
    providers_section = data.setdefault(section_name, {})
    if not isinstance(providers_section, dict):
        providers_section = {}
        data[section_name] = providers_section

    entry = providers_section.get(provider)
    if not isinstance(entry, dict):
        entry = {}
    defaults = _PROVIDER_DEFAULT_CONFIG.get(provider, {})
    entry["api_key"] = f"${{{env_key}}}"
    for key, value in defaults.items():
        entry.setdefault(key, value)
    entry["enabled"] = True
    providers_section[provider] = entry

    config_file.write_text(yaml.safe_dump(data, sort_keys=False), encoding="utf-8")
    return config_file


@app.post("/v1/setup/validate-key")
async def validate_provider_key(
    request: SaveKeyRequest,
    _auth: None = Depends(require_auth),
):
    """Validate an API key by health-checking the provider — does not save.

    Use this before save-key to give the user a real ✓/✗ instead of finding
    out a bad key at the first query. Temporarily sets the env var so the
    engine picks up the new key, runs the provider's health_check, then
    restores the original environment.

    Returns {"valid": bool, "error"?: str, "latency_ms"?: int, "model_count"?: int}.
    """
    env_key = _provider_env_var(request.provider)
    previous_value = os.environ.get(env_key)
    os.environ[env_key] = request.api_key

    global _engine
    try:
        if _engine is None:
            _engine = Engine()
        _engine._initialized = False
        await _engine.initialize()

        provider_obj = _engine.registry.get(request.provider)
        if provider_obj is None:
            return {
                "status": "success",
                "data": {
                    "valid": False,
                    "error": f"Provider '{request.provider}' is registered but didn't load with the new key.",
                },
            }

        health = await provider_obj.health_check()
        if health.healthy:
            return {
                "status": "success",
                "data": {
                    "valid": True,
                    "latency_ms": health.latency_ms,
                    "model_count": health.models_available,
                },
            }
        return {
            "status": "success",
            "data": {
                "valid": False,
                "error": health.error or "Provider rejected the key.",
            },
        }
    except Exception as exc:
        logger.warning("validate-key failed for %s: %s", request.provider, exc)
        return {
            "status": "success",
            "data": {"valid": False, "error": str(exc)[:300]},
        }
    finally:
        # Restore the previous env-var state so a failed validation doesn't
        # leak the new key into other request handlers.
        if previous_value is None:
            os.environ.pop(env_key, None)
        else:
            os.environ[env_key] = previous_value
        if _engine is not None:
            try:
                _engine._initialized = False
                await _engine.initialize()
            except Exception as exc:
                logger.debug("validate-key engine re-init failed: %s", exc)


@app.post("/v1/setup/save-key")
async def save_provider_key(
    request: SaveKeyRequest,
    _auth: None = Depends(require_auth),
):
    """Save an API key for a provider using rootless storage first.

    Also reinitializes the engine so the new provider is available
    immediately without restarting the server.
    """
    env_key = _provider_env_var(request.provider)
    stored_in: list[str] = []
    warnings: list[str] = []
    try:
        os.environ[env_key] = request.api_key
        env_file = _write_provider_env_key(env_key, request.api_key)
        stored_in.append(str(env_file))

        config_file = _enable_provider_in_config(request.provider, env_key)
        stored_in.append(str(config_file))

        try:
            import keyring
            keyring.set_password("nvhive", f"{request.provider}_api_key", request.api_key)
            stored_in.append("system keyring")
        except Exception as exc:
            warnings.append(f"Keyring skipped: {exc}")

        global _engine
        if _engine is not None:
            try:
                _engine._initialized = False
                await _engine.initialize()
            except Exception as exc:
                warnings.append(f"Provider saved, but engine refresh needs a retry: {exc}")

        return {
            "status": "success",
            "data": {
                "ok": True,
                "provider": request.provider,
                "env_key": env_key,
                "stored_in": stored_in,
                "warnings": warnings,
                "message": f"API key saved for {request.provider} under the rootless nvHive config.",
            },
        }
    except Exception as exc:
        logger.warning(f"Failed to save key for {request.provider}: {exc}")
        raise HTTPException(
            status_code=500,
            detail=f"Could not save {request.provider} key under NVH_HOME config: {exc}",
        )


@app.get("/v1/setup/status")
async def get_setup_status(_auth: None = Depends(require_auth)):
    """Check overall setup status — how many providers are ready."""
    from nvh.core.free_tier import detect_available_free_advisors

    available = detect_available_free_advisors()
    engine = get_engine()
    enabled = engine.registry.list_enabled() if engine else []

    return {
        "status": "success",
        "data": {
            "free_advisors_available": len(available),
            "total_advisors_enabled": len(enabled),
            "enabled_names": enabled,
            "free_names": [a.name for a in available],
            "ready": len(available) > 0 or len(enabled) > 0,
            "has_local": "ollama" in enabled or any(a.name == "ollama" for a in available),
        },
    }


def _get_signup_url(provider_name: str) -> str:
    """Get the signup URL for a provider."""
    return _PROVIDER_KEY_URLS.get(provider_name, "")


# ---------------------------------------------------------------------------
# OpenAI-Compatible Proxy  (/v1/proxy/*)
# ---------------------------------------------------------------------------
# Any tool or SDK that supports a custom OpenAI base URL can point at:
#   http://localhost:8000/v1/proxy
# and NVHive will handle routing, fallback, and cost optimisation transparently.
# ---------------------------------------------------------------------------

class _ProxyChatMessage(BaseModel):
    role: str
    content: Any  # str or list[dict] for vision


class _ProxyChatRequest(BaseModel):
    model: str = "auto"
    messages: list[_ProxyChatMessage]
    stream: bool = False
    temperature: float | None = Field(default=None, ge=0.0, le=2.0)
    max_tokens: int | None = Field(default=None, gt=0)
    # Legacy / passthrough fields — accepted but not forwarded
    top_p: float | None = None
    frequency_penalty: float | None = None
    presence_penalty: float | None = None
    stop: Any = None
    n: int | None = None
    user: str | None = None


class _ProxyCompletionsRequest(BaseModel):
    """Legacy /completions endpoint (text-in, text-out)."""
    model: str = "auto"
    prompt: str | list[str]
    stream: bool = False
    temperature: float | None = Field(default=None, ge=0.0, le=2.0)
    max_tokens: int | None = Field(default=None, gt=0)
    stop: Any = None
    user: str | None = None


@app.post(
    "/v1/proxy/chat/completions",
    summary="OpenAI-compatible chat completions",
    tags=["proxy"],
)
async def proxy_chat_completions(
    request: _ProxyChatRequest,
    raw_request: Request,
    _auth: Any = Depends(require_auth),
):
    """Drop-in replacement for POST https://api.openai.com/v1/chat/completions.

    Set ``base_url="http://localhost:8000/v1/proxy"`` in any OpenAI client and
    all requests will be routed through NVHive's multi-provider engine.

    Supported ``model`` values:
    - ``"auto"`` / ``"nvhive"`` — smart routing (default)
    - ``"safe"`` / ``"local"`` — Ollama only, stays on-device
    - ``"council"`` / ``"council:N"`` — multi-LLM consensus (N members)
    - ``"throwdown"`` — two-pass deep analysis with critique
    - Any real model ID (``"gpt-4o"``, ``"claude-3-5-sonnet-20241022"``, …)

    NemoClaw integration:
    - Set ``x-nvhive-privacy: local-only`` header to force local routing.
    """
    from nvh.api.proxy import (
        format_openai_response,
        is_throwdown_model,
        openai_messages_to_nvhive,
        openai_stream_generator,
        parse_council_model,
        resolve_provider_from_model,
    )

    engine = get_engine()

    # Convert messages list to plain dicts for the helper
    messages_dicts = [{"role": m.role, "content": m.content} for m in request.messages]
    prompt, system_prompt = openai_messages_to_nvhive(messages_dicts)

    if not prompt:
        raise HTTPException(status_code=400, detail="No user message content found.")

    # --- Privacy header (NemoClaw integration) ---
    # x-nvhive-privacy: local-only forces all routing through Ollama
    privacy_header = raw_request.headers.get("x-nvhive-privacy", "").lower().strip()
    force_local = privacy_header in ("local-only", "local", "private")

    if force_local:
        provider_override, model_override = "ollama", None
    else:
        provider_override, model_override = resolve_provider_from_model(request.model)

    # --- Council path ---
    council_size = parse_council_model(request.model)
    if council_size is not None and not force_local:
        from nvh.api.proxy import council_stream_generator

        # Streaming council
        if request.stream:
            return StreamingResponse(
                council_stream_generator(
                    engine=engine,
                    prompt=prompt,
                    system_prompt=system_prompt,
                    temperature=request.temperature,
                    max_tokens=request.max_tokens,
                    council_size=council_size,
                    requested_model=request.model,
                ),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
            )

        # Non-streaming council
        try:
            await engine._check_budget()
        except BudgetExceededError as exc:
            raise HTTPException(status_code=402, detail=str(exc))

        try:
            result = await engine.run_council(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                num_agents=council_size,
                auto_agents=True,
                privacy=force_local,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        except BudgetExceededError as exc:
            raise HTTPException(status_code=402, detail=str(exc))
        except Exception as exc:
            logger.error("proxy council error: %s", exc, exc_info=True)
            raise HTTPException(status_code=500, detail=str(exc))

        content = ""
        if result.synthesis:
            content = result.synthesis.content if hasattr(result.synthesis, "content") else str(result.synthesis)
        elif result.member_responses:
            first = next(iter(result.member_responses.values()))
            content = first.content if hasattr(first, "content") else str(first)

        responses = list(result.member_responses.values())
        total_input = sum(r.usage.input_tokens for r in responses if r.usage)
        total_output = sum(r.usage.output_tokens for r in responses if r.usage)

        return format_openai_response(
            content=content,
            model=f"council:{council_size}",
            provider="nvhive-council",
            prompt_tokens=total_input,
            completion_tokens=total_output,
            finish_reason="stop",
        )

    # --- Throwdown path ---
    if is_throwdown_model(request.model) and not force_local:
        from nvh.api.proxy import throwdown_stream_generator

        # Streaming throwdown
        if request.stream:
            return StreamingResponse(
                throwdown_stream_generator(
                    engine=engine,
                    prompt=prompt,
                    system_prompt=system_prompt,
                    temperature=request.temperature,
                    max_tokens=request.max_tokens,
                ),
                media_type="text/event-stream",
                headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
            )

        # Non-streaming throwdown
        try:
            await engine._check_budget()
        except BudgetExceededError as exc:
            raise HTTPException(status_code=402, detail=str(exc))

        try:
            result = await engine.run_council(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                auto_agents=True,
                strategy="throwdown",
                privacy=force_local,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        except BudgetExceededError as exc:
            raise HTTPException(status_code=402, detail=str(exc))
        except Exception as exc:
            logger.error("proxy throwdown error: %s", exc, exc_info=True)
            raise HTTPException(status_code=500, detail=str(exc))

        content = ""
        if result.synthesis:
            content = result.synthesis.content if hasattr(result.synthesis, "content") else str(result.synthesis)
        elif result.member_responses:
            first = next(iter(result.member_responses.values()))
            content = first.content if hasattr(first, "content") else str(first)

        responses = list(result.member_responses.values())
        total_input = sum(r.usage.input_tokens for r in responses if r.usage)
        total_output = sum(r.usage.output_tokens for r in responses if r.usage)

        return format_openai_response(
            content=content,
            model="throwdown",
            provider="nvhive-throwdown",
            prompt_tokens=total_input,
            completion_tokens=total_output,
            finish_reason="stop",
        )

    # --- Streaming path ---
    if request.stream:
        return StreamingResponse(
            openai_stream_generator(
                engine=engine,
                prompt=prompt,
                provider_override=provider_override,
                model_override=model_override,
                system_prompt=system_prompt,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                requested_model=request.model,
            ),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
            },
        )

    # --- Non-streaming path ---
    try:
        await engine._check_budget()
    except BudgetExceededError as exc:
        raise HTTPException(status_code=402, detail=str(exc))

    try:
        resp = await engine.query(
            prompt=prompt,
            provider=provider_override,
            model=model_override,
            system_prompt=system_prompt,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            stream=False,
        )
    except ProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("proxy_chat_completions error: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc))

    from nvh.api.proxy import format_openai_response
    return format_openai_response(
        content=resp.content,
        model=resp.model or request.model,
        provider=resp.provider or "nvhive",
        prompt_tokens=resp.usage.input_tokens if resp.usage else 0,
        completion_tokens=resp.usage.output_tokens if resp.usage else 0,
        finish_reason=resp.finish_reason.value if resp.finish_reason else "stop",
    )


@app.post(
    "/v1/proxy/completions",
    summary="OpenAI-compatible legacy text completions",
    tags=["proxy"],
)
async def proxy_completions(
    request: _ProxyCompletionsRequest,
    _auth: Any = Depends(require_auth),
):
    """Legacy text completions endpoint (OpenAI v1 style).

    Some older tools (LangChain text-based chains, scripts using the legacy
    ``openai.Completion.create`` API) hit ``/completions`` rather than
    ``/chat/completions``.  This endpoint bridges the gap.
    """
    from nvh.api.proxy import resolve_provider_from_model

    engine = get_engine()

    # Normalise prompt — can be str or list[str]
    prompt_text: str
    if isinstance(request.prompt, list):
        prompt_text = "\n".join(request.prompt)
    else:
        prompt_text = request.prompt

    provider_override, model_override = resolve_provider_from_model(request.model)

    try:
        await engine._check_budget()
    except BudgetExceededError as exc:
        raise HTTPException(status_code=402, detail=str(exc))

    try:
        resp = await engine.query(
            prompt=prompt_text,
            provider=provider_override,
            model=model_override,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
            stream=False,
        )
    except ProviderError as exc:
        raise HTTPException(status_code=502, detail=str(exc))
    except Exception as exc:
        logger.error("proxy_completions error: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail=str(exc))

    import time as _time
    import uuid as _uuid
    return {
        "id": f"cmpl-{_uuid.uuid4().hex[:24]}",
        "object": "text_completion",
        "created": int(_time.time()),
        "model": resp.model or request.model,
        "choices": [
            {
                "text": resp.content,
                "index": 0,
                "logprobs": None,
                "finish_reason": resp.finish_reason.value if resp.finish_reason else "stop",
            }
        ],
        "usage": {
            "prompt_tokens": resp.usage.input_tokens if resp.usage else 0,
            "completion_tokens": resp.usage.output_tokens if resp.usage else 0,
            "total_tokens": (resp.usage.total_tokens if resp.usage else 0),
        },
    }


@app.get(
    "/v1/proxy/models",
    summary="OpenAI-compatible models list",
    tags=["proxy"],
)
async def proxy_models(
    _auth: Any = Depends(require_auth),
):
    """Return available models in OpenAI's ``GET /v1/models`` format.

    Includes NVHive virtual routing models (``auto``, ``safe``, ``council``,
    ``throwdown``) and the real models exposed by each enabled provider.
    """
    from nvh.api.proxy import build_models_list
    engine = get_engine()
    return build_models_list(engine.registry)


@app.get(
    "/v1/proxy/health",
    summary="Proxy health check for NemoClaw/OpenShell integration",
    tags=["proxy"],
)
async def proxy_health():
    """Health endpoint for external orchestrators (NemoClaw, OpenShell, etc.).

    Returns provider availability, routing status, and supported virtual models
    so NemoClaw can verify this inference provider is alive and capable.
    """
    engine = get_engine()
    enabled = engine.registry.list_enabled() if hasattr(engine.registry, "list_enabled") else []

    # Check if local inference is available
    has_local = "ollama" in enabled

    return {
        "status": "ok",
        "provider": "nvhive",
        "version": engine.config.version if hasattr(engine.config, "version") else "1.0.0",
        "engine_initialized": engine._initialized,
        "providers_enabled": len(enabled),
        "providers": list(enabled),
        "has_local_inference": has_local,
        "supported_models": [
            "auto", "safe", "local",
            "council", "council:3", "council:5",
            "throwdown",
        ],
        "features": {
            "smart_routing": True,
            "council_consensus": True,
            "throwdown_analysis": True,
            "privacy_header": True,
            "streaming": True,
        },
    }


# ---------------------------------------------------------------------------
# Anthropic/Claude API Proxy  (/v1/anthropic/*)
# ---------------------------------------------------------------------------
# Drop-in replacement for the Anthropic Messages API.
# Set ANTHROPIC_BASE_URL=http://localhost:8000/v1/anthropic in any
# Anthropic SDK client and nvHive handles routing, fallback, and
# cost optimization.
#
# This is the zero-friction migration path for OpenClaw users.
# ---------------------------------------------------------------------------


class AnthropicMessageRequest(BaseModel):
    model: str = "auto"
    messages: list[dict[str, Any]]
    system: str | None = None
    max_tokens: int = Field(default=4096, gt=0)
    temperature: float | None = Field(default=None, ge=0.0, le=1.0)
    stream: bool = False
    metadata: dict[str, Any] | None = None


@app.post(
    "/v1/anthropic/messages",
    summary="Anthropic Messages API proxy",
    tags=["anthropic-proxy"],
)
async def anthropic_messages(
    request: AnthropicMessageRequest,
    raw_request: Request,
):
    """Anthropic Messages API compatible endpoint.

    Drop-in replacement for https://api.anthropic.com/v1/messages.
    Routes through nvHive's smart router with automatic fallback.

    Model routing:
      "auto" / "nvhive"  -> smart routing
      "claude-*"          -> Anthropic provider
      "council" / "council:N" -> multi-model consensus
      "throwdown"         -> two-pass deep analysis
      Any other model     -> nvHive routes to best provider
    """
    from nvh.api.proxy import (
        anthropic_messages_to_nvhive,
        anthropic_stream_generator,
        format_anthropic_response,
        is_throwdown_model,
        parse_council_model,
        resolve_provider_from_model,
    )

    engine = get_engine()
    prompt, system_prompt = anthropic_messages_to_nvhive(
        request.messages, request.system,
    )

    if not prompt:
        raise HTTPException(
            status_code=400,
            detail="No user message content found.",
        )

    # Check for council/throwdown virtual models
    council_size = parse_council_model(request.model)
    is_throwdown = is_throwdown_model(request.model)

    if request.stream and not council_size and not is_throwdown:
        provider_override, model_override = (
            resolve_provider_from_model(request.model)
        )
        return StreamingResponse(
            anthropic_stream_generator(
                engine=engine,
                prompt=prompt,
                provider_override=provider_override,
                model_override=model_override,
                system_prompt=system_prompt,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                requested_model=request.model,
            ),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
            },
        )

    # Non-streaming (or council/throwdown)
    try:
        if council_size:
            result = await engine.run_council(
                prompt=prompt,
                system_prompt=system_prompt,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
                auto_agents=True,
                num_agents=council_size,
            )
            content = (
                result.synthesis.content
                if result.synthesis
                else "Council produced no synthesis."
            )
            return format_anthropic_response(
                content=content,
                model=f"council({council_size})",
                provider="council",
                input_tokens=sum(
                    r.usage.input_tokens
                    for r in result.member_responses.values()
                ),
                output_tokens=sum(
                    r.usage.output_tokens
                    for r in result.member_responses.values()
                ),
            )

        if is_throwdown:
            pass1 = await engine.run_council(
                prompt=prompt,
                auto_agents=True,
                synthesize=True,
                temperature=request.temperature,
                max_tokens=request.max_tokens,
            )
            critique = (
                f"Original: {prompt}\n\n"
                f"Analysis:\n"
                f"{pass1.synthesis.content if pass1.synthesis else ''}"
                f"\n\nCritique and improve this analysis."
            )
            pass2 = await engine.run_council(
                prompt=critique,
                auto_agents=True,
                synthesize=True,
            )
            final = await engine.query(
                prompt=(
                    f"Original: {prompt}\n\n"
                    f"Pass 1:\n"
                    f"{pass1.synthesis.content if pass1.synthesis else ''}"
                    f"\n\nPass 2:\n"
                    f"{pass2.synthesis.content if pass2.synthesis else ''}"
                    f"\n\nFinal definitive answer:"
                ),
            )
            return format_anthropic_response(
                content=final.content,
                model="throwdown",
                provider=final.provider,
                input_tokens=final.usage.input_tokens,
                output_tokens=final.usage.output_tokens,
            )

        # Standard single query with smart routing
        provider_override, model_override = (
            resolve_provider_from_model(request.model)
        )
        resp = await engine.query(
            prompt=prompt,
            provider=provider_override,
            model=model_override,
            system_prompt=system_prompt,
            temperature=request.temperature,
            max_tokens=request.max_tokens,
        )
        return format_anthropic_response(
            content=resp.content,
            model=resp.model,
            provider=resp.provider,
            input_tokens=resp.usage.input_tokens,
            output_tokens=resp.usage.output_tokens,
        )

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail={
                "type": "api_error",
                "message": f"nvHive routing error: {type(exc).__name__}",
            },
        )


# ---------------------------------------------------------------------------
# Integrations API  (/v1/integrations/*)
# ---------------------------------------------------------------------------

@app.get(
    "/v1/integrations/scan",
    summary="Scan for installed AI platforms",
    tags=["integrations"],
)
async def integrations_scan():
    """Detect installed AI platforms and their connection status."""
    from nvh.integrations.diagnostics.detector import detect_platforms

    platforms = detect_platforms()
    results = []
    for p in platforms:
        results.append({
            "name": p.name,
            "display_name": p.display_name,
            "detected": p.detected,
            "already_configured": p.already_configured,
            "detection_method": p.detection_method,
            "config_path": p.config_path,
            "integration_type": p.integration_type,
            "notes": p.notes,
        })

    return _response_envelope({
        "platforms": results,
        "detected_count": sum(1 for p in platforms if p.detected),
        "configured_count": sum(
            1 for p in platforms if p.already_configured
        ),
        "total_count": len(platforms),
    })


class _ConnectRequest(BaseModel):
    platform: str
    host: str = "127.0.0.1"
    port: int = 8000


@app.post(
    "/v1/integrations/connect",
    summary="Connect nvHive to a platform",
    tags=["integrations"],
)
async def integrations_connect(
    request: _ConnectRequest,
    _auth: Any = Depends(require_auth),
):
    """Register nvHive with a detected platform."""
    from nvh.integrations.diagnostics.detector import (
        register_claude_code,
        register_claude_desktop,
        register_cursor,
        register_nemoclaw,
        register_openclaw,
    )

    handlers = {
        "nemoclaw": lambda: register_nemoclaw(
            request.host, request.port
        ),
        "openclaw": lambda: register_openclaw(),
        "claude_code": lambda: register_claude_code(),
        "cursor": lambda: register_cursor(),
        "claude_desktop": lambda: register_claude_desktop(),
    }

    handler = handlers.get(request.platform)
    if not handler:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown platform: {request.platform}",
        )

    success, message = handler()
    return _response_envelope({
        "platform": request.platform,
        "success": success,
        "message": message,
    })


class _ConnectAllRequest(BaseModel):
    host: str = "127.0.0.1"
    port: int = 8000


@app.post(
    "/v1/integrations/connect-all",
    summary="Auto-connect all detected platforms",
    tags=["integrations"],
)
async def integrations_connect_all(
    request: _ConnectAllRequest,
    _auth: Any = Depends(require_auth),
):
    """Scan and connect all detected platforms in one call."""
    from nvh.integrations.diagnostics.detector import (
        detect_platforms,
        register_claude_code,
        register_claude_desktop,
        register_cursor,
        register_nemoclaw,
        register_openclaw,
    )

    handlers = {
        "nemoclaw": lambda: register_nemoclaw(
            request.host, request.port
        ),
        "openclaw": lambda: register_openclaw(),
        "claude_code": lambda: register_claude_code(),
        "cursor": lambda: register_cursor(),
        "claude_desktop": lambda: register_claude_desktop(),
    }

    platforms = detect_platforms()
    results = []

    for p in platforms:
        if not p.detected or p.already_configured:
            results.append({
                "platform": p.name,
                "display_name": p.display_name,
                "action": "skipped",
                "reason": (
                    "already configured" if p.already_configured
                    else "not detected"
                ),
                "success": p.already_configured,
            })
            continue

        handler = handlers.get(p.name)
        if handler:
            success, message = handler()
            results.append({
                "platform": p.name,
                "display_name": p.display_name,
                "action": "connected" if success else "failed",
                "message": message,
                "success": success,
            })

    connected = sum(1 for r in results if r["success"])
    return _response_envelope({
        "results": results,
        "connected": connected,
        "total": len(results),
    })


# ---------------------------------------------------------------------------
# Quota Info API  (/v1/quota/*)
# ---------------------------------------------------------------------------

@app.get(
    "/v1/quota/{provider_name}",
    summary="Get quota and rate limit info for a provider",
    tags=["quota"],
)
async def get_provider_quota(provider_name: str):
    """Return quota details, rate limits, reset times, and upgrade links."""
    from nvh.providers.quota_info import get_quota_info

    info = get_quota_info(provider_name)
    return _response_envelope({
        "provider": info.provider,
        "tier": info.tier,
        "limit": info.limit_description,
        "reset": info.reset_hint,
        "upgrade_url": info.upgrade_url,
        "upgrade_hint": info.upgrade_hint,
    })


@app.get(
    "/v1/quota",
    summary="Get quota info for all configured providers",
    tags=["quota"],
)
async def get_all_quotas():
    """Return quota details for every enabled provider."""
    from nvh.providers.quota_info import get_quota_info

    engine = get_engine()
    enabled = (
        engine.registry.list_enabled()
        if hasattr(engine.registry, "list_enabled")
        else []
    )

    quotas = []
    for name in enabled:
        info = get_quota_info(name)
        quotas.append({
            "provider": info.provider,
            "tier": info.tier,
            "limit": info.limit_description,
            "reset": info.reset_hint,
            "upgrade_url": info.upgrade_url,
            "upgrade_hint": info.upgrade_hint,
        })

    return _response_envelope({"quotas": quotas})
