"""Bundled nvHive setup catalog."""
