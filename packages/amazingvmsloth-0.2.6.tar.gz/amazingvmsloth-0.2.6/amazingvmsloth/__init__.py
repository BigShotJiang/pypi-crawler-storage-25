import os

# Suppress transformers loading progress bars that can crash on Windows terminal
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")

from amazingvmsloth.lora import apply_lora, LoRAConfig
from amazingvmsloth.trainer import AmazingTrainer, TrainingConfig
from amazingvmsloth.quantization import quantize_model_4bit
from amazingvmsloth.attention import patch_attention
from amazingvmsloth.models import auto_patch_model
from amazingvmsloth.multi_gpu import setup_distributed
from amazingvmsloth.offload import apply_dispatch_offload, estimate_model_size_gb
from amazingvmsloth.cpu_trainer import CpuTrainer, CpuTrainingConfig

__version__ = "0.1.0"
__all__ = [
    "apply_lora",
    "LoRAConfig",
    "AmazingTrainer",
    "TrainingConfig",
    "quantize_model_4bit",
    "patch_attention",
    "auto_patch_model",
    "setup_distributed",
]
