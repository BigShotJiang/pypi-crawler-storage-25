import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Tuple, Set
from transformers import PreTrainedModel


@dataclass
class LoRAConfig:
    r: int = 16
    lora_alpha: int = 16
    lora_dropout: float = 0.0
    target_modules: List[str] = field(default_factory=lambda: [
        "q_proj", "k_proj", "v_proj", "o_proj",
        "gate_proj", "up_proj", "down_proj",
    ])
    bias: str = "none"
    layers_to_transform: Optional[List[int]] = None
    layers_pattern: Optional[str] = None
    rank_pattern: Optional[Dict[str, int]] = None
    alpha_pattern: Optional[Dict[str, int]] = None
    use_rslora: bool = True
    use_dora: bool = False
    loftq_bits: Optional[int] = None
    use_manual_gradients: bool = False
    merge_on_eval: bool = True
    scaling_mode: str = "rslora"


class LoRALayer(nn.Module):
    def __init__(
        self,
        base_layer: nn.Linear,
        config: LoRAConfig,
        adapter_name: str = "default",
    ):
        super().__init__()
        self.base_layer = base_layer
        self.config = config
        self.adapter_name = adapter_name
        self.in_features = base_layer.in_features
        self.out_features = base_layer.out_features

        self.lora_A = nn.ParameterDict()
        self.lora_B = nn.ParameterDict()
        self.lora_alpha = nn.ParameterDict()
        self.scaling = nn.ParameterDict()
        self.lora_dropout = nn.ModuleDict()

        self._active_adapter = adapter_name
        self._merged = False
        self._manual_grad_enabled = config.use_manual_gradients

        self.update_layer(adapter_name, config)

    def update_layer(self, adapter_name: str, config: LoRAConfig):
        r = config.r
        alpha = config.lora_alpha

        if r > 0:
            device = self._detect_device()
            self.lora_A[adapter_name] = nn.Parameter(
                torch.empty(r, self.in_features, dtype=torch.float32, device=device)
            )
            self.lora_B[adapter_name] = nn.Parameter(
                torch.zeros(self.out_features, r, dtype=torch.float32, device=device)
            )
            self.lora_alpha[adapter_name] = nn.Parameter(
                torch.tensor(float(alpha), requires_grad=False, device=device)
            )

            if config.use_rslora:
                scaling = alpha / math.sqrt(r)
            else:
                scaling = alpha / r

            self.scaling[adapter_name] = nn.Parameter(
                torch.tensor(float(scaling), requires_grad=False, device=device)
            )

            self.lora_dropout[adapter_name] = (
                nn.Dropout(p=config.lora_dropout) if config.lora_dropout > 0 else nn.Identity()
            )

            nn.init.kaiming_uniform_(self.lora_A[adapter_name], a=math.sqrt(5))

    def _detect_device(self) -> torch.device:
        if hasattr(self.base_layer, "weight") and self.base_layer.weight is not None:
            return self.base_layer.weight.device
        if hasattr(self.base_layer, "qweight"):
            return self.base_layer.qweight.device
        for param in self.base_layer.parameters():
            return param.device
        return torch.device("cpu")

    @property
    def active_adapter(self):
        return self._active_adapter

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self._merged:
            return self.base_layer(x)

        result = self.base_layer(x)

        adapter = self._active_adapter
        if adapter in self.lora_A and self.lora_A[adapter].shape[0] > 0:
            A = self.lora_A[adapter]
            B = self.lora_B[adapter]
            scale = self.scaling[adapter].item()

            if self.training and self.config.lora_dropout > 0:
                x = self.lora_dropout[adapter](x)

            # Cast LoRA weights to match input dtype (handles 4-bit base + float32 LoRA)
            if A.dtype != x.dtype:
                A = A.to(x.dtype)
                B = B.to(x.dtype)

            lora_out = (x @ A.T @ B.T) * scale
            result = result + lora_out

        return result

    def merge_adapter(self, adapter_name: Optional[str] = None):
        adapter = adapter_name or self._active_adapter
        if adapter not in self.lora_A:
            return

        A = self.lora_A[adapter].to(self.base_layer.weight.dtype)
        B = self.lora_B[adapter].to(self.base_layer.weight.dtype)
        scale = self.scaling[adapter].item()

        delta = B @ A * scale
        if self.base_layer.weight.shape == delta.shape:
            self.base_layer.weight.data += delta
        self._merged = True

    def unmerge_adapter(self, adapter_name: Optional[str] = None):
        adapter = adapter_name or self._active_adapter
        if adapter not in self.lora_A:
            return

        A = self.lora_A[adapter].to(self.base_layer.weight.dtype)
        B = self.lora_B[adapter].to(self.base_layer.weight.dtype)
        scale = self.scaling[adapter].item()

        delta = B @ A * scale
        if self.base_layer.weight.shape == delta.shape:
            self.base_layer.weight.data -= delta
        self._merged = False


class _LoRAContext(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, A, B, scale):
        ctx.save_for_backward(x, A, B)
        ctx.scale = scale
        return x @ A.T @ B.T * scale

    @staticmethod
    def backward(ctx, grad_output):
        x, A, B = ctx.saved_tensors
        scale = ctx.scale

        grad_output_f = grad_output.to(torch.float32)
        x_f = x.to(torch.float32)
        A_f = A.to(torch.float32)
        B_f = B.to(torch.float32)

        intermediate = x_f @ A_f.T

        grad_B = scale * (grad_output_f.transpose(-1, -2) @ intermediate).sum(0)

        d_intermediate = scale * (grad_output_f @ B_f)
        grad_A = (d_intermediate.transpose(-1, -2) @ x_f).sum(0)

        grad_input = (d_intermediate @ A_f).to(x.dtype)
        return grad_input, grad_A, grad_B, None


def _find_target_modules(model: PreTrainedModel, target_modules: List[str]) -> List[str]:
    target_names = []
    for name, module in model.named_modules():
        if isinstance(module, nn.Linear):
            for target in target_modules:
                if target in name:
                    target_names.append(name)
                    break
    return target_names


def apply_lora(
    model: PreTrainedModel,
    config: Optional[LoRAConfig] = None,
    target_modules: Optional[List[str]] = None,
    r: int = 16,
    lora_alpha: int = 16,
    lora_dropout: float = 0.0,
    use_rslora: bool = True,
    use_manual_gradients: bool = True,
) -> PreTrainedModel:
    if config is None:
        config = LoRAConfig(
            r=r,
            lora_alpha=lora_alpha,
            lora_dropout=lora_dropout,
            target_modules=target_modules or LoRAConfig.target_modules,
            use_rslora=use_rslora,
            use_manual_gradients=use_manual_gradients,
        )

    target_names = _find_target_modules(model, config.target_modules)

    if config.layers_to_transform is not None:
        filtered = []
        for name in target_names:
            layer_match = False
            for layer_idx in config.layers_to_transform:
                if f".{layer_idx}." in name:
                    layer_match = True
                    break
            if layer_match:
                filtered.append(name)
        target_names = filtered

    modules_dict = dict(model.named_modules())

    for name in target_names:
        if name not in modules_dict:
            continue
        module = modules_dict[name]
        if not isinstance(module, nn.Linear):
            continue

        lora_layer = LoRALayer(module, config)

        parts = name.rsplit(".", 1)
        if len(parts) == 2:
            parent_name, child_name = parts
            parent = modules_dict.get(parent_name)
            if parent is not None:
                setattr(parent, child_name, lora_layer)
        else:
            setattr(model, name, lora_layer)

    trainable_params = 0
    all_params = 0
    for name, param in model.named_parameters():
        all_params += param.numel()
        if param.requires_grad:
            trainable_params += param.numel()

    pct = 100 * trainable_params / all_params if all_params > 0 else 0
    print(f"[amazingvmsloth] LoRA applied: {trainable_params:,} trainable / {all_params:,} total ({pct:.2f}%)")
    print(f"[amazingvmsloth] Target layers: {len(target_names)}")

    return model


def get_lora_state_dict(model: PreTrainedModel) -> Dict[str, torch.Tensor]:
    lora_dict = {}
    for name, module in model.named_modules():
        if isinstance(module, LoRALayer):
            for adapter_name in module.lora_A:
                lora_dict[f"{name}.lora_A.{adapter_name}"] = module.lora_A[adapter_name].data
                lora_dict[f"{name}.lora_B.{adapter_name}"] = module.lora_B[adapter_name].data
                lora_dict[f"{name}.lora_alpha.{adapter_name}"] = module.lora_alpha[adapter_name].data
                lora_dict[f"{name}.scaling.{adapter_name}"] = module.scaling[adapter_name].data
    return lora_dict


def load_lora_weights(model: PreTrainedModel, checkpoint_path: str):
    """Load LoRA weights from a checkpoint file into an already-patched model."""
    state_dict = torch.load(checkpoint_path, map_location="cpu")
    # Flatten nested dicts (HuggingFace format compat)
    if isinstance(state_dict, dict) and any(isinstance(v, dict) for v in state_dict.values()):
        flat = {}
        for prefix, d in state_dict.items():
            for k, v in d.items():
                flat[f"{prefix}.{k}" if prefix else k] = v
        state_dict = flat

    # Collect expected keys per LoRALayer
    lora_keys = set()
    for name, module in model.named_modules():
        if isinstance(module, LoRALayer):
            for adapter_name in module.lora_A:
                lora_keys.add(f"{name}.lora_A.{adapter_name}")
                lora_keys.add(f"{name}.lora_B.{adapter_name}")
                lora_keys.add(f"{name}.lora_alpha.{adapter_name}")
                lora_keys.add(f"{name}.scaling.{adapter_name}")

    # Filter to only LoRA keys
    lora_state = {k: v for k, v in state_dict.items() if k in lora_keys}

    # Strip 'lora_model.' prefix used by PEFT
    if not lora_state:
        lora_state = {k.replace("lora_model.", ""): v for k, v in state_dict.items() if "lora_model." in k}

    # Load
    local_state = {}
    for name, module in model.named_modules():
        if isinstance(module, LoRALayer):
            for adapter_name in list(module.lora_A.keys()):
                prefix = f"{name}."
                for suffix, param in module.lora_A.items():
                    key = f"{prefix}lora_A.{suffix}"
                    if key in lora_state:
                        param.data.copy_(lora_state[key])
                for suffix, param in module.lora_B.items():
                    key = f"{prefix}lora_B.{suffix}"
                    if key in lora_state:
                        param.data.copy_(lora_state[key])
                for suffix, param in module.lora_alpha.items():
                    key = f"{prefix}lora_alpha.{suffix}"
                    if key in lora_state:
                        param.data.copy_(lora_state[key])
                for suffix, param in module.scaling.items():
                    key = f"{prefix}scaling.{suffix}"
                    if key in lora_state:
                        param.data.copy_(lora_state[key])

    loaded = len([k for k in lora_state if any(p in k for p in ("lora_A", "lora_B"))])
    print(f"[amazingvmsloth] Loaded {loaded} LoRA tensors from {checkpoint_path}")


def merge_and_unload(model: PreTrainedModel) -> PreTrainedModel:
    for name, module in list(model.named_modules()):
        if isinstance(module, LoRALayer):
            module.merge_adapter()
            parts = name.rsplit(".", 1)
            if len(parts) == 2:
                parent_name, child_name = parts
                parent = dict(model.named_modules()).get(parent_name)
                if parent is not None:
                    setattr(parent, child_name, module.base_layer)
    return model
