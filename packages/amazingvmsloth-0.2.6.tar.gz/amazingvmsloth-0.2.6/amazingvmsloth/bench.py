import time
import torch
import argparse
import os
from typing import Dict, Any

# Suppress transformers loading progress bars (can crash on Windows + cause UI issues)
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")

_unsloth_available = False
_unsloth_error = None


def _try_import_unsloth():
    """Lazy import unsloth only when unsloth benchmark is requested."""
    global _unsloth_available, _unsloth_error
    if _unsloth_available or _unsloth_error is not None:
        return _unsloth_available
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        try:
            import unsloth
            from unsloth import FastLanguageModel
            _unsloth_available = True
        except Exception as e:
            _unsloth_error = str(e)
    return _unsloth_available


def run_amazingvmsloth(model_name: str, dataset_name: str, max_samples: int, max_seq_length: int) -> Dict[str, Any]:
    from transformers import AutoTokenizer
    from datasets import load_dataset
    from amazingvmsloth import quantize_model_4bit, auto_patch_model, LoRAConfig, AmazingTrainer, TrainingConfig
    from amazingvmsloth.utils.banner import print_banner, get_system_info

    info = get_system_info()
    print_banner(info, model_name)

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    try:
        model = quantize_model_4bit(model_name)
    except (torch.OutOfMemoryError, RuntimeError) as e:
        if "out of memory" in str(e).lower() or "cuda" in str(e).lower():
            print(f"\n[bench] ERROR: GPU out of memory while loading {model_name}")
            print(f"[bench] This model may be too large for your GPU.")
            print(f"[bench] Try: --model Qwen/Qwen2.5-0.5B (smaller model)")
            print(f"[bench] Or:  --low-vram (auto-tune settings)")
            raise
        else:
            # Try pre-quantized unsloth model
            unsloth_model = f"unsloth/{model_name.split('/')[-1]}-bnb-4bit"
            print(f"[bench] Loading failed, trying pre-quantized: {unsloth_model}")
            model = quantize_model_4bit(unsloth_model)
    lora_config = LoRAConfig(r=16, lora_alpha=16, use_rslora=True, use_manual_gradients=False)
    model = auto_patch_model(model, apply_lora_patch=True, lora_config=lora_config)

    dataset = load_dataset(dataset_name, split="train")
    if max_samples > 0:
        dataset = dataset.select(range(min(max_samples, len(dataset))))

    def tokenize_fn(examples):
        texts = [
            f"### Instruction:\n{inst}\n\n### Response:\n{out}"
            for inst, out in zip(examples["instruction"], examples["output"])
        ]
        return tokenizer(texts, truncation=True, max_length=max_seq_length)

    tokenized = dataset.map(tokenize_fn, batched=True, remove_columns=dataset.column_names)
    tokenized = tokenized.map(lambda x: {"labels": x["input_ids"]}, batched=True)
    # Don't set_format("torch") — datasets' torch formatter crashes on Windows
    # because it tries to import torchvision.io.VideoReader which isn't available.
    # Our collator handles list->tensor conversion manually.

    # Pre-pack: concatenate all sequences, split into max_seq_length chunks.
    # This gives 2-5x fewer forward passes vs padding single short sequences.
    from amazingvmsloth.packing import prepack_dataset, BatchCollator
    packed = prepack_dataset(tokenized, tokenizer, max_seq_length=max_seq_length)
    print(f"[bench] Pre-packed {len(tokenized)} samples into {len(packed)} chunks ({max_seq_length} tokens each)")

    config = TrainingConfig(
        output_dir="./bench_amazingvmsloth",
        num_train_epochs=1,
        per_device_train_batch_size=1,
        gradient_accumulation_steps=1,
        learning_rate=2e-4,
        bf16=True,
        optim="paged_adamw_8bit",
        max_seq_length=max_seq_length,
        logging_steps=1,
        save_steps=999999,
        packing=False,  # Already pre-packed above
        compile_model=False,  # Compile overhead dominates on short runs despite pre-packing
        gradient_checkpointing=True,  # Enable for VRAM optimization (match unsloth's 2.3GB)
        chunked_loss=False,  # 512 seq fits full logits in 4GB, skip chunked overhead
        silent=True,  # Skip tqdm/postfix overhead in benchmark
    )

    trainer = AmazingTrainer(
        model=model,
        tokenizer=tokenizer,
        train_dataset=packed,
        config=config,
        data_collator=BatchCollator(),
    )

    start = time.time()
    result = trainer.train()
    elapsed = time.time() - start

    vram_peak = torch.cuda.max_memory_allocated(0) / 1024**3 if torch.cuda.is_available() else 0
    torch.cuda.reset_peak_memory_stats()

    return {
        "time_s": round(elapsed, 1),
        "vram_peak_gb": round(vram_peak, 2),
        "steps": result["global_step"],
        "loss": result["log_history"][-1]["loss"] if result["log_history"] else -1,
    }


def run_unsloth(model_name: str, dataset_name: str, max_samples: int, max_seq_length: int) -> Dict[str, Any]:
    if not _try_import_unsloth():
        msg = "unsloth not installed" if _unsloth_error is None else f"unsloth import failed: {_unsloth_error}"
        print(f"[bench] {msg}. Install with: pip install unsloth")
        return {"time_s": -1, "vram_peak_gb": -1, "steps": -1, "loss": -1, "error": msg}

    from unsloth import FastLanguageModel
    from trl import SFTTrainer
    from transformers import TrainingArguments
    from datasets import load_dataset

    try:
        model, tokenizer = FastLanguageModel.from_pretrained(
            model_name=model_name,
            max_seq_length=max_seq_length,
            dtype=None,
            load_in_4bit=True,
        )
    except (OSError, MemoryError) as e:
        err_msg = str(e)
        if "paging file" in err_msg.lower() or "memory" in err_msg.lower():
            print(f"[bench] unsloth failed: System out of memory (Windows paging file too small)")
            print(f"[bench] unsloth requires more RAM/virtual memory than your system has.")
            print(f"[bench] Tip: Increase Windows virtual memory or close other applications.")
        else:
            print(f"[bench] unsloth model loading failed: {err_msg}")
        return {"time_s": -1, "vram_peak_gb": -1, "steps": -1, "loss": -1, "error": err_msg}

    try:
        model = FastLanguageModel.get_peft_model(
            model,
            r=16,
            lora_alpha=16,
            lora_dropout=0,
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            use_rslora=True,
        )

        dataset = load_dataset(dataset_name, split="train")
        if max_samples > 0:
            dataset = dataset.select(range(min(max_samples, len(dataset))))

        def formatting_func(examples):
            return [
                f"### Instruction:\n{inst}\n\n### Response:\n{out}"
                for inst, out in zip(examples["instruction"], examples["output"])
            ]

        training_args = TrainingArguments(
            output_dir="./bench_unsloth",
            num_train_epochs=1,
            per_device_train_batch_size=1,
            gradient_accumulation_steps=8,
            learning_rate=2e-4,
            bf16=True,
            logging_steps=1,
            save_steps=999999,
            optim="paged_adamw_8bit",
            max_grad_norm=1.0,
            warmup_ratio=0.1,
            report_to="none",
        )

        trainer = SFTTrainer(
            model=model,
            tokenizer=tokenizer,
            train_dataset=dataset,
            formatting_func=formatting_func,
            max_seq_length=max_seq_length,
            args=training_args,
        )

        torch.cuda.reset_peak_memory_stats()
        start = time.time()
        trainer.train()
        elapsed = time.time() - start
    except Exception as e:
        elapsed = time.time() - start if 'start' in locals() else 0
        err_msg = str(e)
        if "paging file" in err_msg.lower() or "memory" in err_msg.lower() or "os error 1455" in err_msg.lower():
            print(f"[bench] unsloth failed: System out of memory")
            print(f"[bench] unsloth requires more RAM/virtual memory than your system has.")
        else:
            print(f"[bench] unsloth training failed: {err_msg}")
        return {
            "time_s": round(elapsed, 1) if elapsed > 0 else -1,
            "vram_peak_gb": -1,
            "steps": getattr(trainer.state, "global_step", 0) if 'trainer' in locals() else 0,
            "loss": -1,
            "error": err_msg,
        }

    vram_peak = torch.cuda.max_memory_allocated(0) / 1024**3 if torch.cuda.is_available() else 0
    torch.cuda.reset_peak_memory_stats()

    # Find last logged loss
    loss = -1
    for entry in reversed(trainer.state.log_history):
        if "loss" in entry:
            loss = entry["loss"]
            break

    return {
        "time_s": round(elapsed, 1),
        "vram_peak_gb": round(vram_peak, 2),
        "steps": trainer.state.global_step,
        "loss": round(loss, 4) if isinstance(loss, float) else -1,
    }


def main():
    parser = argparse.ArgumentParser(description="Benchmark: amazingvmsloth vs unsloth")
    parser.add_argument("--model", default="Qwen/Qwen2.5-1.5B", help="Model name")
    parser.add_argument("--dataset", default="tatsu-lab/alpaca", help="Dataset")
    parser.add_argument("--max-samples", type=int, default=500, help="Samples to use")
    parser.add_argument("--max-seq-length", type=int, default=512, help="Max seq length")
    parser.add_argument("--skip-unsloth", action="store_true", help="Skip unsloth benchmark")
    args = parser.parse_args()

    print(f"\n{'='*60}")
    print(f"  Benchmark: amazingvmsloth vs unsloth")
    print(f"{'='*60}")
    print(f"  Model:      {args.model}")
    print(f"  Dataset:    {args.dataset}")
    print(f"  Samples:    {args.max_samples}")
    print(f"  Seq length: {args.max_seq_length}")
    print(f"{'='*60}\n")

    print("[bench] Running amazingvmsloth...")
    av_result = run_amazingvmsloth(args.model, args.dataset, args.max_samples, args.max_seq_length)
    print(f"[bench] amazingvmsloth done: {av_result['time_s']}s, {av_result['vram_peak_gb']}GB peak VRAM\n")

    us_result = None
    if not args.skip_unsloth:
        print("[bench] Running unsloth...")
        us_result = run_unsloth(args.model, args.dataset, args.max_samples, args.max_seq_length)
        if us_result.get("error"):
            print(f"[bench] unsloth skipped: {us_result['error']}\n")
            us_result = None
        else:
            print(f"[bench] unsloth done: {us_result['time_s']}s, {us_result['vram_peak_gb']}GB peak VRAM\n")

    print(f"\n{'='*60}")
    print(f"  Results")
    print(f"{'='*60}")
    print(f"  {'Metric':<20} {'amazingvmsloth':>15} {'unsloth':>15}")
    print(f"  {'-'*20} {'-'*15} {'-'*15}")
    print(f"  {'Time (s)':<20} {av_result['time_s']:>15} {us_result['time_s'] if us_result else 'N/A':>15}")
    print(f"  {'Peak VRAM (GB)':<20} {av_result['vram_peak_gb']:>15} {us_result['vram_peak_gb'] if us_result else 'N/A':>15}")
    print(f"  {'Final Loss':<20} {av_result['loss']:>15} {us_result['loss'] if us_result else 'N/A':>15}")
    print(f"  {'Steps':<20} {av_result['steps']:>15} {us_result['steps'] if us_result else 'N/A':>15}")

    if us_result and us_result["time_s"] > 0 and av_result["time_s"] > 0:
        speedup = us_result["time_s"] / av_result["time_s"]
        vram_saved = us_result["vram_peak_gb"] - av_result["vram_peak_gb"]
        print(f"\n  Speedup:    {speedup:.2f}x")
        print(f"  VRAM saved: {vram_saved:.2f} GB")
        if speedup > 1:
            print(f"  amazingvmsloth is {speedup:.2f}x faster!")
        else:
            print(f"  unsloth is {1/speedup:.2f}x faster")

    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
