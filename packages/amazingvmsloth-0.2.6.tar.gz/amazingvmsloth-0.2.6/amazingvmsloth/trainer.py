import os
import time
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from typing import Optional, Dict, Any, Callable, List, Tuple, Union
from dataclasses import dataclass, field
from transformers import PreTrainedModel, PreTrainedTokenizer, get_cosine_schedule_with_warmup
from amazingvmsloth.optimizer import create_optimizer
from amazingvmsloth.gradient import (
    GradientAccumulator,
    enable_gradient_checkpointing,
    set_gradient_requirements,
)
from amazingvmsloth.packing import PackingCollator, SmartCollator
from amazingvmsloth.multi_gpu import (
    setup_distributed,
    wrap_model_ddp,
    is_main_process,
    barrier,
    cleanup_distributed,
    get_rank,
    get_world_size,
)


@dataclass
class TrainingConfig:
    output_dir: str = "./output"
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 2
    gradient_accumulation_steps: int = 4
    learning_rate: float = 2e-4
    weight_decay: float = 0.01
    warmup_ratio: float = 0.1
    warmup_steps: int = 0
    max_grad_norm: float = 1.0
    lr_scheduler_type: str = "cosine"
    logging_steps: int = 10
    save_steps: int = 500
    save_total_limit: int = 3
    bf16: bool = True
    fp16: bool = False
    gradient_checkpointing: bool = False
    optim: str = "paged_adamw_8bit"
    max_seq_length: int = 2048
    seed: int = 42
    dataloader_num_workers: int = 0
    dataloader_pin_memory: bool = True
    group_by_length: bool = True
    report_to: str = "none"
    multi_gpu_strategy: Optional[str] = None
    deepspeed_config: Optional[Dict] = None
    checkpoint_every_n_layers: int = 1
    eval_steps: int = 0
    eval_strategy: str = "no"
    packing: bool = True
    max_steps: int = 0
    padding_free: bool = True
    compile_model: bool = False
    max_samples: int = 0
    offload_layers: int = 0
    chunked_loss: bool = True
    loss_chunk_size: int = 128
    silent: bool = False


class AmazingTrainer:
    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizer,
        train_dataset: Dataset,
        eval_dataset: Optional[Dataset] = None,
        config: Optional[TrainingConfig] = None,
        data_collator: Optional[Callable] = None,
        callbacks: Optional[List[Callable]] = None,
    ):
        self.model = model
        self.tokenizer = tokenizer
        self.train_dataset = train_dataset
        self.eval_dataset = eval_dataset
        self.config = config or TrainingConfig()
        self.data_collator = data_collator
        self.callbacks = callbacks or []
        self._global_step = 0
        self._epoch = 0
        self._best_loss = float("inf")
        self._log_history: List[Dict] = []
        self._start_time = None
        self._trainable_params: List[torch.nn.Parameter] = []

    def _setup(self):
        self._setup_seed()
        self._setup_perf()
        self._setup_dtype()
        self._setup_collator()
        self._setup_model()
        self._setup_offloading()
        self._setup_distributed()
        self._setup_optimizer()
        self._setup_dataloader()
        self._setup_scheduler()
        self._setup_compile()

    def _setup_seed(self):
        seed = self.config.seed
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)

    def _setup_perf(self):
        if torch.cuda.is_available():
            torch.set_float32_matmul_precision("high")
            torch.backends.cudnn.benchmark = True
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True

    def _setup_dtype(self):
        if self.config.bf16 and torch.cuda.is_bf16_supported():
            self._dtype = torch.bfloat16
        elif self.config.fp16:
            self._dtype = torch.float16
        else:
            self._dtype = torch.float32

    def _setup_collator(self):
        if self.data_collator is not None:
            return

        pad_token_id = 0
        eos_token_id = 0
        if self.tokenizer is not None:
            pad_token_id = self.tokenizer.pad_token_id or self.tokenizer.eos_token_id or 0
            eos_token_id = self.tokenizer.eos_token_id or 0

        if self.config.packing:
            self.data_collator = PackingCollator(
                max_seq_length=self.config.max_seq_length,
                pad_token_id=pad_token_id,
                eos_token_id=eos_token_id,
            )
        else:
            self.data_collator = SmartCollator(
                max_seq_length=self.config.max_seq_length,
                pad_token_id=pad_token_id,
            )

    def _setup_model(self):
        if self.config.gradient_checkpointing:
            enable_gradient_checkpointing(
                self.model,
                checkpoint_every_n=self.config.checkpoint_every_n_layers,
            )

        set_gradient_requirements(self.model)
        self._cache_trainable_params()

    def _cache_trainable_params(self):
        self._trainable_params = [p for p in self.model.parameters() if p.requires_grad]

    def _setup_distributed(self):
        if self.config.multi_gpu_strategy:
            setup_distributed()
            if self.config.multi_gpu_strategy == "ddp":
                self.model = wrap_model_ddp(self.model)
            elif self.config.multi_gpu_strategy == "fsdp":
                from amazingvmsloth.multi_gpu import wrap_model_fsdp
                self.model = wrap_model_fsdp(self.model)
            elif self.config.multi_gpu_strategy == "deepspeed":
                from amazingvmsloth.multi_gpu import DeepSpeedConfig, setup_deepspeed
                ds_config = DeepSpeedConfig()
                if self.config.deepspeed_config:
                    for k, v in self.config.deepspeed_config.items():
                        setattr(ds_config, k, v)
                self.model, self.optimizer, self.lr_scheduler = setup_deepspeed(
                    self.model,
                    config=ds_config,
                )
                self._using_deepspeed = True
                return

        self._using_deepspeed = False

    def _setup_optimizer(self):
        if hasattr(self, "_using_deepspeed") and self._using_deepspeed:
            return
        self.optimizer = create_optimizer(
            self.model,
            optimizer_type=self.config.optim,
            lr=self.config.learning_rate,
            weight_decay=self.config.weight_decay,
        )

    def _setup_dataloader(self):
        sampler = None
        if self.config.multi_gpu_strategy and torch.distributed.is_initialized():
            from torch.utils.data.distributed import DistributedSampler
            sampler = DistributedSampler(
                self.train_dataset,
                num_replicas=get_world_size(),
                rank=get_rank(),
                shuffle=True,
                seed=self.config.seed,
            )

        self.dataloader = DataLoader(
            self.train_dataset,
            batch_size=self.config.per_device_train_batch_size,
            shuffle=(sampler is None),
            sampler=sampler,
            collate_fn=self.data_collator,
            num_workers=self.config.dataloader_num_workers,
            pin_memory=self.config.dataloader_pin_memory,
        )

    def _setup_scheduler(self):
        if hasattr(self, "_using_deepspeed") and self._using_deepspeed:
            return

        epoch_steps = max(1, len(self.dataloader) * self.config.num_train_epochs // self.config.gradient_accumulation_steps)
        if self.config.max_steps > 0:
            total_steps = self.config.max_steps
        else:
            total_steps = epoch_steps
        warmup = self.config.warmup_steps or max(1, int(total_steps * self.config.warmup_ratio))

        self.lr_scheduler = get_cosine_schedule_with_warmup(
            self.optimizer,
            num_warmup_steps=warmup,
            num_training_steps=total_steps,
        )
        self._total_steps = total_steps

    def _setup_compile(self):
        if self.config.compile_model and hasattr(torch, "compile"):
            self.model = torch.compile(self.model, mode="reduce-overhead")

    def _setup_offloading(self):
        if self.config.offload_layers > 0 and torch.cuda.is_available():
            from amazingvmsloth.offload import apply_dispatch_offload
            self.model = apply_dispatch_offload(
                self.model,
                max_gpu_layers=self.config.offload_layers,
                verbose=True,
            )
        self._offloader = None

    def train(self) -> Dict[str, Any]:
        self._setup()
        self._start_time = time.time()

        accumulator = GradientAccumulator(self.config.gradient_accumulation_steps)
        model = self.model
        optimizer = self.optimizer
        scheduler = self.lr_scheduler

        print(f"\n{'='*60}")
        print(f"  amazingvmsloth Training")
        print(f"{'='*60}")
        print(f"  Model dtype:   {self._dtype}")
        print(f"  Optimizer:     {self.config.optim}")
        print(f"  Packing:       {self.config.packing}")
        print(f"  Offload:       {self.config.offload_layers} GPU layers" if self.config.offload_layers > 0 else "  Offload:       disabled")
        print(f"  Batch size:    {self.config.per_device_train_batch_size}")
        print(f"  Grad accum:    {self.config.gradient_accumulation_steps}")
        if self.config.max_steps > 0:
            print(f"  Max steps:     {self.config.max_steps} (overrides epochs)")
        else:
            print(f"  Total steps:   {self._total_steps}")
        print(f"{'='*60}\n")

        should_stop = False
        for epoch in range(self.config.num_train_epochs):
            if should_stop:
                break
            self._epoch = epoch
            model.train()

            if hasattr(self.dataloader, "sampler") and hasattr(self.dataloader.sampler, "set_epoch"):
                self.dataloader.sampler.set_epoch(epoch)

            epoch_loss = 0.0
            step_count = 0
            data_step = 0
            n_batches = len(self.dataloader)

            if self.config.silent:
                batch_iter = iter(self.dataloader)
            elif self.config.max_steps > 0:
                # Step-based progress bar when max_steps is active
                from tqdm import tqdm
                pbar = tqdm(total=self.config.max_steps, desc=f"Training", unit="step", initial=self._global_step)
                batch_iter = iter(self.dataloader)
            else:
                from tqdm import tqdm
                pbar = tqdm(self.dataloader, total=n_batches, desc=f"Epoch {epoch+1}/{self.config.num_train_epochs}", unit="batch")
                batch_iter = None

            while True:
                try:
                    if batch_iter is not None:
                        batch = next(batch_iter)
                    else:
                        batch = next(iter(pbar))
                    data_step += 1
                except StopIteration:
                    break

                batch_dict = {
                    k: v.to(self._get_device()) if isinstance(v, torch.Tensor) else v
                    for k, v in batch.items()
                }

                with torch.autocast(device_type="cuda", dtype=self._dtype, enabled=self.config.bf16 or self.config.fp16):
                    if self.config.chunked_loss and "labels" in batch_dict:
                        labels = batch_dict.pop("labels")
                        outputs = model(**batch_dict)
                        logits = outputs.logits if hasattr(outputs, "logits") else outputs["logits"]
                        loss = self._compute_chunked_loss(logits, labels)
                    else:
                        outputs = model(**batch_dict)
                        loss = outputs.loss if hasattr(outputs, "loss") else outputs["loss"]

                scaled_loss = accumulator.accumulate(loss)
                scaled_loss.backward()

                if accumulator.should_step() or data_step == n_batches:
                    if self.config.max_grad_norm > 0:
                        nn.utils.clip_grad_norm_(
                            self._trainable_params,
                            self.config.max_grad_norm,
                        )

                    optimizer.step()
                    scheduler.step()
                    optimizer.zero_grad(set_to_none=True)

                    self._global_step += 1
                    epoch_loss += accumulator.mean_loss
                    step_count += 1
                    accumulator.reset()

                    if not self.config.silent and self.config.max_steps > 0 and hasattr(pbar, 'update'):
                        pbar.update(1)
                        avg_loss = epoch_loss / max(step_count, 1)
                        vram_alloc = torch.cuda.memory_allocated(0) / 1024**3 if torch.cuda.is_available() else 0
                        pbar.set_postfix({
                            "loss": f"{avg_loss:.4f}",
                            "vram": f"{vram_alloc:.1f}GB",
                        })
                    elif not self.config.silent and hasattr(pbar, 'set_postfix'):
                        avg_loss = epoch_loss / max(step_count, 1)
                        vram_alloc = torch.cuda.memory_allocated(0) / 1024**3 if torch.cuda.is_available() else 0
                        pbar.set_postfix({
                            "loss": f"{avg_loss:.4f}",
                            "vram": f"{vram_alloc:.1f}GB",
                        })

                    if self._global_step % self.config.logging_steps == 0 and is_main_process():
                        elapsed = time.time() - self._start_time
                        steps_per_sec = self._global_step / elapsed if elapsed > 0 else 0
                        lr = scheduler.get_last_lr()[0] if scheduler else self.config.learning_rate
                        avg_loss = epoch_loss / max(step_count, 1)
                        vram_alloc = torch.cuda.memory_allocated(0) / 1024**3 if torch.cuda.is_available() else 0
                        vram_res = torch.cuda.memory_reserved(0) / 1024**3 if torch.cuda.is_available() else 0

                        remaining_steps = self._total_steps - self._global_step
                        eta = remaining_steps / steps_per_sec if steps_per_sec > 0 else 0
                        eta_str = f"{int(eta)//60}m{int(eta)%60}s" if eta < 3600 else f"{int(eta)//3600}h{(int(eta)%3600)//60}m"

                        self._log_history.append({
                            "epoch": epoch,
                            "step": self._global_step,
                            "loss": round(avg_loss, 4),
                            "lr": lr,
                            "steps_per_sec": round(steps_per_sec, 2),
                        })

                        if not self.config.silent:
                            print(
                                f"Epoch [{epoch+1}/{self.config.num_train_epochs}] "
                                f"Step [{self._global_step}/{self._total_steps}] "
                                f"Loss: {avg_loss:.4f} | "
                                f"LR: {lr:.2e} | "
                            f"Speed: {steps_per_sec:.2f} steps/s | "
                            f"VRAM: {vram_alloc:.1f}/{vram_res:.1f}GB | "
                            f"ETA: {eta_str}"
                            )

                    if self.config.max_steps > 0 and self._global_step >= self.config.max_steps:
                        print(f"\n[amazingvmsloth] Max steps reached ({self.config.max_steps}). Stopping training.")
                        should_stop = True
                        if not self.config.silent and hasattr(pbar, 'close'):
                            pbar.close()
                        break

                    if self.config.save_steps > 0 and self._global_step % self.config.save_steps == 0:
                        self._save_checkpoint()

                if data_step % 50 == 0 and step_count > 0 and not self.config.max_steps > 0:
                    elapsed = time.time() - self._start_time
                    steps_per_sec = self._global_step / elapsed if elapsed > 0 else 0
                    avg_loss = epoch_loss / max(step_count, 1)
                    pct = data_step / n_batches * 100
                    print(
                        f"  [{data_step}/{n_batches}] ({pct:.0f}%) "
                        f"loss: {avg_loss:.4f} | {steps_per_sec:.2f} steps/s",
                        end="\r",
                    )

            if not self.config.silent and self.config.max_steps > 0 and hasattr(pbar, 'close'):
                pbar.close()

            avg_epoch_loss = epoch_loss / max(step_count, 1)
            if is_main_process():
                elapsed = time.time() - self._start_time
                print(
                    f"\nEpoch {epoch+1}/{self.config.num_train_epochs} completed | "
                    f"Avg loss: {avg_epoch_loss:.4f} | "
                    f"Time: {elapsed:.0f}s"
                )

        self._save_final()
        total_time = time.time() - self._start_time

        if is_main_process():
            print(f"\n{'='*60}")
            print(f"  Training complete in {total_time:.1f}s ({self._global_step} steps)")
            print(f"{'='*60}")

        return {
            "global_step": self._global_step,
            "training_time": total_time,
            "log_history": self._log_history,
        }

    def _get_device(self) -> torch.device:
        if hasattr(self.model, "device"):
            return self.model.device
        if torch.cuda.is_available():
            local_rank = int(os.environ.get("LOCAL_RANK", 0))
            return torch.device(f"cuda:{local_rank}")
        return torch.device("cpu")

    def _save_checkpoint(self):
        if not is_main_process():
            return

        ckpt_dir = os.path.join(self.config.output_dir, f"checkpoint-{self._global_step}")
        os.makedirs(ckpt_dir, exist_ok=True)

        model_to_save = self.model.module if hasattr(self.model, "module") else self.model
        if hasattr(model_to_save, "save_pretrained"):
            model_to_save.save_pretrained(ckpt_dir)
        if self.tokenizer:
            self.tokenizer.save_pretrained(ckpt_dir)
        torch.save({
            "global_step": self._global_step,
            "epoch": self._epoch,
            "optimizer_state_dict": self.optimizer.state_dict(),
            "lr_scheduler_state_dict": self.lr_scheduler.state_dict(),
            "log_history": self._log_history,
            "rng_state": torch.get_rng_state(),
        }, os.path.join(ckpt_dir, "trainer_state.pt"))
        print(f"  Checkpoint saved: {ckpt_dir}")

    def resume_from_checkpoint(self, checkpoint_path: str):
        """Resume training from a checkpoint directory."""
        if not os.path.isdir(checkpoint_path):
            raise ValueError(f"Checkpoint path not found: {checkpoint_path}")

        trainer_state_path = os.path.join(checkpoint_path, "trainer_state.pt")
        if not os.path.exists(trainer_state_path):
            raise ValueError(f"No trainer_state.pt found in {checkpoint_path}")

        state = torch.load(trainer_state_path, map_location="cpu")
        self._global_step = state.get("global_step", 0)
        self._epoch = state.get("epoch", 0)
        self._log_history = state.get("log_history", [])

        if "optimizer_state_dict" in state and hasattr(self, "optimizer"):
            self.optimizer.load_state_dict(state["optimizer_state_dict"])
        if "lr_scheduler_state_dict" in state and hasattr(self, "lr_scheduler"):
            self.lr_scheduler.load_state_dict(state["lr_scheduler_state_dict"])
        if "rng_state" in state:
            torch.set_rng_state(state["rng_state"])

        print(f"  Resumed from checkpoint: {checkpoint_path} (step {self._global_step}, epoch {self._epoch})")
        return self

    def _save_final(self):
        if not is_main_process():
            return

        os.makedirs(self.config.output_dir, exist_ok=True)
        model_to_save = self.model.module if hasattr(self.model, "module") else self.model

        # Save LoRA weights separately for adapter-only loading
        from amazingvmsloth.lora import get_lora_state_dict
        lora_dict = get_lora_state_dict(model_to_save)
        if lora_dict:
            torch.save(lora_dict, os.path.join(self.config.output_dir, "lora_weights.pt"))
            print(f"  LoRA weights saved ({len(lora_dict)} tensors)")

        # Merge LoRA into base weights so save_pretrained produces a clean model
        try:
            from amazingvmsloth.lora import merge_and_unload
            model_to_save = merge_and_unload(model_to_save)
        except Exception as e:
            print(f"  [warning] LoRA merge failed ({e}), saving patched model only")

        # Save base model name for inference loading
        base_name = getattr(model_to_save, "name_or_path", "unknown")
        with open(os.path.join(self.config.output_dir, "base_model.txt"), "w") as f:
            f.write(base_name)

        try:
            if hasattr(model_to_save, "save_pretrained"):
                model_to_save.save_pretrained(self.config.output_dir, safe_serialization=True)
        except (RuntimeError, NotImplementedError) as e:
            if "shared tensors" in str(e):
                state_dict = model_to_save.state_dict()
                seen = set()
                clean_dict = {}
                for k, v in state_dict.items():
                    if k not in seen:
                        clean_dict[k] = v
                        seen.add(k)
                torch.save(clean_dict, os.path.join(self.config.output_dir, "model.pt"))
                print(f"  Model state dict saved to {self.config.output_dir}/model.pt")
            else:
                print(f"  Full model save not supported for this model type ({type(e).__name__})")
                print(f"  Only LoRA weights were saved. Use --merge to combine with base model.")

        if self.tokenizer:
            self.tokenizer.save_pretrained(self.config.output_dir)

        print(f"  Model saved to {self.config.output_dir}")

    def _compute_chunked_loss(self, logits, labels):
        # Shift for causal LM: predict next token
        shift_logits = logits[:, :-1, :].contiguous()
        shift_labels = labels[:, 1:].contiguous()
        vocab_size = shift_logits.shape[-1]
        seq_len = shift_logits.shape[1]
        chunk_size = self.config.loss_chunk_size
        total_loss = 0.0
        n_tokens = 0
        for i in range(0, seq_len, chunk_size):
            chunk_logits = shift_logits[:, i:i+chunk_size, :].reshape(-1, vocab_size)
            chunk_labels = shift_labels[:, i:i+chunk_size].reshape(-1)
            valid_mask = chunk_labels != -100
            if valid_mask.any():
                chunk_loss = F.cross_entropy(
                    chunk_logits[valid_mask],
                    chunk_labels[valid_mask],
                    reduction="sum",
                )
                total_loss += chunk_loss
                n_tokens += valid_mask.sum().item()
        return total_loss / max(n_tokens, 1)
