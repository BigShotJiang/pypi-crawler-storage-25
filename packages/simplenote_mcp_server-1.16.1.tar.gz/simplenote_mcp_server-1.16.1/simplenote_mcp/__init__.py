# simplenote_mcp/__init__.py

"""Simplenote MCP Server - Connect Simplenote to Claude Desktop."""

__version__ = "1.16.1"
