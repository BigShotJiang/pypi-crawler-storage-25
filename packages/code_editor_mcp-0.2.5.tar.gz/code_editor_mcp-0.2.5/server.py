from __future__ import annotations

import logging
import os
import shutil
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from fnmatch import fnmatch
from pathlib import Path
from typing import Any, List, cast

from mcp.server.fastmcp import FastMCP
from tools import delete_guard
from tools import edit as edit_tools
from tools import filesystem as fs_tools
from tools.config import DEFAULT_IGNORE_PATTERNS, FILE_SIZE_LIMITS, get_root

logging.basicConfig(level=logging.INFO)

MTIME_EPSILON_NS = 10_000_000  # 10ms tolerance

server = FastMCP("code-editor")
ROOT = get_root()


# --- Helpers --------------------------------------------------------------

def _validate_path(path: str) -> Path:
    return fs_tools.validate_path(path)


def _check_expected_mtime(resolved: Path, expected_mtime: float | None) -> None:
    if expected_mtime is None:
        return
    if not resolved.exists():
        raise FileNotFoundError(f"File not found for mtime check: {resolved}")
    expected_ns = _normalize_expected_mtime(expected_mtime)
    current_ns = _current_mtime_ns(resolved)
    if expected_ns is not None and abs(current_ns - expected_ns) > MTIME_EPSILON_NS:
        raise RuntimeError(
            f"Conflict: File modified by another process. Expected mtime {expected_mtime}, got {current_ns / 1_000_000_000:.9f}."
        )


def _read_lines(file_path: Path, encoding: str) -> List[str]:
    return file_path.read_text(encoding=encoding).splitlines(keepends=True)


def _write_text(file_path: Path, content: str, encoding: str) -> None:
    fs_tools._atomic_write(file_path, content, encoding=encoding)


def _read_text(file_path: Path, encoding: str) -> str:
    return file_path.read_text(encoding=encoding)


def _normalize_encoding(encoding: str | None) -> str | None:
    if encoding is None:
        return None
    normalized = encoding.strip()
    if normalized == "" or normalized.lower() == "auto":
        return None
    return fs_tools.normalize_encoding(normalized)


def _normalize_encoding_required(encoding: str | None, default: str = "utf-8") -> str:
    """
    For tool handlers that require a concrete encoding, fallback to default when None/""/auto.
    """
    if encoding is None:
        return fs_tools.normalize_encoding(default)
    normalized = encoding.strip()
    if normalized == "" or normalized.lower() == "auto":
        return fs_tools.normalize_encoding(default)
    return fs_tools.normalize_encoding(normalized)


def _resolve_edit_blocks_encoding(
    resolved: Path,
    encoding: str | None,
    *,
    detected_encoding: object = None,
    detected_confidence: object = None,
) -> str:
    """
    Resolve the encoding used by edit_blocks for reading+writing.

    - If `encoding` is "auto"/empty/None: use detected encoding when possible.
    - Otherwise: normalize and enforce the supported encoding set.
    """
    enc_value = encoding if isinstance(encoding, str) else ""
    trimmed = enc_value.strip().lower()
    if trimmed == "" or trimmed == "auto":
        if isinstance(detected_encoding, str) and detected_encoding.strip():
            try:
                return fs_tools.normalize_encoding(detected_encoding)
            except ValueError:
                # Fall back to probing the supported encoding set. For short CJK files
                # charset detection can be ambiguous (e.g., GBK vs Big5), so prefer a
                # deterministic decode probe over hard-failing.
                pass

        # Probe decodability of a byte sample using supported encodings.
        sample_size = 200_000
        with open(resolved, "rb") as f:
            data = f.read(sample_size)
        for candidate in ("utf-8", "gb18030", "gbk", "gb2312"):
            try:
                data.decode(candidate, errors="strict")
                return fs_tools.normalize_encoding(candidate)
            except UnicodeDecodeError:
                continue

        confidence = (
            float(detected_confidence)
            if isinstance(detected_confidence, (int, float))
            else None
        )
        suffix = f" (confidence={confidence:.2f})" if confidence is not None else ""
        detected_hint = (
            f" Detected={detected_encoding!r}{suffix}." if detected_encoding else ""
        )
        raise ValueError(
            f"Encoding='auto' could not determine a supported encoding for {str(resolved)!r}."
            f"{detected_hint} Supported for edit_blocks: utf-8, gbk, gb2312, gb18030. "
            "Tip: pass encoding explicitly or run convert_file_encoding first."
        )
    return fs_tools.normalize_encoding(enc_value)


def _normalize_expected_mtime(expected: float | int | None) -> int | None:
    if expected is None:
        return None
    if expected > 1e12:  # assume nanoseconds
        return int(expected)
    return int(expected * 1_000_000_000)


def _current_mtime_ns(path: Path) -> int:
    stats = path.stat()
    return getattr(stats, "st_mtime_ns", int(stats.st_mtime * 1_000_000_000))


def _index_to_line_col(text: str, index: int) -> tuple[int, int]:
    line = text.count("\n", 0, index) + 1
    last_newline = text.rfind("\n", 0, index)
    column = index - last_newline
    return line, column


def _normalize_ignore_patterns(patterns: List[str] | str | None) -> List[str]:
    """
    Normalize user-supplied ignore patterns.

    Rules:
    - None: fall back to defaults.
    - Empty string/list: disable defaults entirely (show everything).
    - Non-string entries: reject.
    """
    if patterns is None:
        return list(DEFAULT_IGNORE_PATTERNS)
    if isinstance(patterns, str):
        cleaned = [p.strip() for p in patterns.split(",") if p.strip()]
        return cleaned  # empty string means no ignores
    items = list(patterns)
    if any(not isinstance(p, str) for p in items):
        raise ValueError("ignore_patterns elements must all be strings.")
    return items  # empty list => show all files


def _delete_confirm_token(resolved: Path) -> str:
    token_path = os.path.normcase(str(resolved))
    return f"delete:{token_path}"


def build_delete_confirm_token(dir_path: str) -> str:
    resolved = _validate_path(dir_path)
    return _delete_confirm_token(resolved)


def _is_directory_empty(resolved: Path) -> bool:
    try:
        return next(resolved.iterdir(), None) is None
    except OSError as exc:
        raise PermissionError(
            f"Cannot inspect directory contents for safety: {resolved}"
        ) from exc


# --- Tools ---------------------------------------------------------------

@server.tool()
def config_ops(action: str, path: str | None = None) -> dict | list[str] | str:
    """
    Config and metadata operations.

    Args:
        action:
            - "set_root": Add a directory to the allowed whitelist (requires path)
            - "list_roots": Return the current whitelist of allowed directories
            - "get_info": Get metadata for a file or directory (requires path)
        path: Target path for set_root/get_info.
    """
    if not isinstance(action, str):
        raise ValueError("action must be a string.")

    normalized_action = action.lower()

    if normalized_action == "set_root":
        if path is None:
            raise ValueError("path is required for set_root action.")
        global ROOT
        ROOT = fs_tools.set_root_path(path)
        return f"Active base path set to {ROOT}"

    if normalized_action == "list_roots":
        return [str(p) for p in fs_tools.list_allowed_roots()]

    if normalized_action == "get_info":
        if path is None:
            raise ValueError("path is required for get_info action.")
        return fs_tools.get_file_info(path)

    raise ValueError("action must be one of: set_root, list_roots, get_info.")


@server.tool()
def read_files(
    requests: List[dict],
    default_encoding: str = "auto",
    page_line_count: int = 400,
    max_snippets: int = 64,
    max_total_chars: int = 200_000,
    max_chars_per_snippet: int = 50_000,
    max_lines_per_snippet: int = 2000,
    parallelism: int = 4,
) -> dict:
    """
    LLM-optimized file reader that supports multiple snippets per file and cursor-based pagination.

    Requests are a list of dicts. Each element is either:
    - Cursor continuation:
        {"cursor": "<opaque>", "id": "..."}
    - Explicit snippet:
        {
          "path": "/abs/file",
          "mode": "range" | "tail" | "all",
          "start_line": 1,          # 1-based, required for range
          "line_count": 120,        # required for range; optional for all/tail
          "before_lines": 0,
          "after_lines": 0,
          "encoding": "auto|utf-8|gbk|gb2312|gb18030",
          "id": "..."
        }

    Returns a structured JSON object with per-request results (success/error) and optional next_cursor.
    """
    if not isinstance(requests, list) or len(requests) == 0:
        raise ValueError("requests must be a non-empty list.")
    if any(not isinstance(r, dict) for r in requests):
        raise ValueError("each request must be a dict.")

    if not isinstance(max_snippets, int) or max_snippets <= 0:
        raise ValueError("max_snippets must be a positive integer.")
    if len(requests) > max_snippets:
        raise ValueError(f"Too many requests: {len(requests)} (max_snippets={max_snippets}).")

    def _pos_int(value: object, name: str) -> int:
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError(f"{name} must be a positive integer.")
        return value

    page_lines = _pos_int(page_line_count, "page_line_count")
    max_total = _pos_int(max_total_chars, "max_total_chars")
    max_chars = _pos_int(max_chars_per_snippet, "max_chars_per_snippet")
    max_lines = _pos_int(max_lines_per_snippet, "max_lines_per_snippet")
    workers = max(1, min(_pos_int(parallelism, "parallelism"), 8))

    results: list[dict] = [None] * len(requests)  # type: ignore[list-item]

    def _read_one(req: dict) -> dict:
        try:
            return cast(
                dict,
                fs_tools.read_snippet_v2(
                    req,
                    default_encoding=default_encoding,
                    page_line_count=page_lines,
                    max_chars_per_snippet=max_chars,
                    max_lines_per_snippet=max_lines,
                ),
            )
        except Exception as exc:
            req_id = req.get("id") if isinstance(req.get("id"), str) else None
            req_path = req.get("path") if isinstance(req.get("path"), str) else None
            error_result: dict = {"id": req_id, "ok": False, "error": str(exc)}
            if req_path:
                error_result["path"] = req_path
            return error_result

    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_to_idx = {executor.submit(_read_one, req): idx for idx, req in enumerate(requests)}
        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            results[idx] = future.result()

    total_chars = 0
    budget_dropped = 0
    for item in results:
        if not isinstance(item, dict):
            continue
        if item.get("ok") is not True:
            continue
        content = item.get("content")
        if not isinstance(content, str):
            continue
        if total_chars + len(content) > max_total:
            budget_dropped += 1
            item["ok"] = False
            item["error"] = "max_total_chars budget exceeded; reduce requests or use pagination."
            item.pop("content", None)
            item.pop("sha256_utf8", None)
            item.pop("next_cursor", None)
            item.pop("next_start_line", None)
            continue
        total_chars += len(content)

    successful = sum(1 for r in results if isinstance(r, dict) and r.get("ok") is True)
    failed = len(results) - successful
    status = "success" if failed == 0 else ("partial" if successful > 0 else "error")
    message = f"Read {successful}/{len(results)} snippet(s)."
    if budget_dropped:
        message += f" Dropped {budget_dropped} snippet(s) due to max_total_chars."

    return {
        "status": status,
        "message": message,
        "total_requests": len(results),
        "successful": successful,
        "failed": failed,
        "total_chars": total_chars,
        "results": results,
    }


@server.tool()
def dir_ops(
    action: str,
    dir_path: str,
    depth: int = 2,
    format: str = "tree",
    ignore_patterns: List[str] | None = None,
    max_items: int | None = 1000,
    expected_mtime: float | None = None,
    confirm_token: str | None = None,
    allow_nonempty: bool | None = None,
    approval_token: str | None = None,
) -> list | str | dict[str, Any]:
    """
    Directory operations: create, list, or delete.

    Args:
        action: "create" | "list" | "delete"
        dir_path: Absolute path to the directory.
        depth: Listing depth (list only).
        format: "tree" | "flat" (list only).
        ignore_patterns: Glob patterns to exclude (list only).
        max_items: Max entries for flat listing.
        expected_mtime: Required for delete (conflict detection).
        confirm_token: Required for delete ("delete:<normalized_path>").
        allow_nonempty: Required for delete (explicit bool).
        approval_token: Optional one-time token for high-risk deletes.
    """
    if not isinstance(action, str):
        raise ValueError("action must be a string.")
    if not isinstance(dir_path, str):
        raise ValueError("dir_path must be a string.")

    normalized_action = action.lower()
    if normalized_action == "create":
        return _create_directory(dir_path)
    if normalized_action == "list":
        return _list_directory(dir_path, depth, format, ignore_patterns, max_items)
    if normalized_action == "delete":
        return _delete_directory(
            dir_path, expected_mtime, confirm_token, allow_nonempty, approval_token
        )
    raise ValueError("action must be one of: create, list, delete.")

def _create_directory(dir_path: str) -> str:
    fs_tools.create_directory(dir_path)
    return f"Successfully created directory {dir_path}"


def _list_directory(
    dir_path: str,
    depth: int = 2,
    format: str = "tree",
    ignore_patterns: List[str] | None = None,
    max_items: int | None = 1000,
) -> list:
    resolved = _validate_path(dir_path)
    if not resolved.exists():
        raise FileNotFoundError(f"Directory not found: {dir_path}")
    if not resolved.is_dir():
        raise NotADirectoryError(f"Not a directory: {dir_path}")

    fmt = format.lower()
    if fmt not in {"tree", "flat"}:
        raise ValueError("format must be 'tree' or 'flat'")

    patterns = _normalize_ignore_patterns(ignore_patterns)

    if fmt == "tree":
        return fs_tools.list_directory(str(resolved), depth, patterns)

    if max_items is not None and max_items <= 0:
        raise ValueError("max_items must be a positive integer or None.")

    entries = []
    total_visible = 0
    for entry in sorted(resolved.iterdir(), key=lambda p: p.name):
        if any(fnmatch(entry.name, pat) for pat in patterns):
            continue
        total_visible += 1
        info = {"name": entry.name, "is_dir": entry.is_dir()}
        if entry.is_file():
            info["size"] = entry.stat().st_size
        if max_items is None or len(entries) < max_items:
            entries.append(info)

    if max_items is not None and total_visible > max_items:
        entries.append(
            {
                "name": f"[WARNING] truncated: showing first {max_items} of {total_visible} items",
                "is_dir": False,
                "truncated": True,
                "total": total_visible,
                "shown": max_items,
            }
        )
    return entries


def _delete_directory(
    directory_path: str,
    expected_mtime: float | None,
    confirm_token: str | None,
    allow_nonempty: bool | None,
    approval_token: str | None,
) -> dict[str, Any]:
    resolved = _validate_path(directory_path)
    if not resolved.exists():
        raise FileNotFoundError(f"Directory not found: {directory_path}")
    if not resolved.is_dir():
        raise NotADirectoryError("delete only supports directories.")

    critical_block = delete_guard.get_critical_delete_block(resolved)
    if critical_block is not None:
        return critical_block

    root = get_root()
    if resolved == root or resolved in root.parents:
        return {
            "status": "blocked_critical",
            "risk_level": "extreme",
            "action_required": "stop_and_explain_risk",
            "delete_mode": "recycle_bin",
            "target_path": os.path.normcase(str(resolved)),
            "impact_summary": {
                "file_count": None,
                "total_bytes": None,
                "max_depth": None,
                "sample_paths": [],
                "is_directory": True,
            },
            "warning": (
                "This operation was blocked because deleting the active root or its ancestor "
                "can destroy the entire workspace."
            ),
            "llm_instruction": (
                "STOP. Do not retry deletion. Explain the risk to the user and request a safer path."
            ),
            "detail": "active_root_or_ancestor_blocked",
        }

    if expected_mtime is None:
        raise ValueError("expected_mtime is required for delete.")
    if confirm_token is None or not isinstance(confirm_token, str) or not confirm_token.strip():
        raise ValueError("confirm_token is required for delete.")
    if allow_nonempty is None or not isinstance(allow_nonempty, bool):
        raise ValueError("allow_nonempty is required for delete.")

    expected_token = _delete_confirm_token(resolved)
    if confirm_token.strip() != expected_token:
        raise PermissionError(
            "confirm_token mismatch. "
            f"Expected confirm_token to be '{expected_token}'."
        )

    if allow_nonempty is False and not _is_directory_empty(resolved):
        raise PermissionError(
            "Refusing to delete non-empty directory. "
            "Set allow_nonempty=True to proceed."
        )

    _check_expected_mtime(resolved, expected_mtime)
    policy = delete_guard.evaluate_delete_policy(resolved, approval_token=approval_token)
    if policy.get("status") != "allowed":
        return policy

    fs_tools.move_to_recycle_bin(str(resolved))
    return _build_delete_success_response(resolved, "directory", policy)


def _build_delete_success_response(
    resolved: Path, target_kind: str, policy: dict[str, Any]
) -> dict[str, Any]:
    impact = policy.get("impact_summary")
    if not isinstance(impact, dict):
        impact = {
            "file_count": 1 if target_kind == "file" else None,
            "total_bytes": None,
            "max_depth": 0 if target_kind == "file" else None,
            "sample_paths": [resolved.name],
            "is_directory": target_kind == "directory",
        }

    response: dict[str, Any] = {
        "status": "success",
        "risk_level": policy.get("risk_level", "low"),
        "action_required": "none",
        "delete_mode": "recycle_bin",
        "target_path": os.path.normcase(str(resolved)),
        "target_kind": target_kind,
        "message": f"Moved {resolved} to recycle bin.",
        "impact_summary": impact,
    }

    policy_summary = policy.get("policy_summary")
    if isinstance(policy_summary, dict):
        response["policy_summary"] = policy_summary

    approval = policy.get("approval")
    if isinstance(approval, dict):
        response["approval"] = approval

    return response


@server.tool()
def file_ops(
    action: str,
    file_path: str | None = None,
    content: str | None = None,
    source_path: str | None = None,
    destination_path: str | None = None,
    expected_mtime: float | None = None,
    encoding: str = "utf-8",
    approval_token: str | None = None,
) -> str | dict[str, Any]:
    """
    File operations: write, append, copy, move, or delete.

    Args:
        action: "write" | "append" | "copy" | "move" | "delete"
        file_path: Target path (write/append/delete).
        content: File content (write/append).
        source_path: Source path (copy/move).
        destination_path: Destination path (copy/move).
        expected_mtime: Conflict detection timestamp.
        encoding: Text encoding for write/append (utf-8, gbk, gb2312).
        approval_token: Optional one-time token for high-risk deletes.
    """
    if not isinstance(action, str):
        raise ValueError("action must be a string.")
    normalized_action = action.lower()

    if normalized_action in {"write", "append"}:
        if file_path is None:
            raise ValueError("file_path is required for write/append.")
        if content is None:
            raise ValueError("content is required for write/append.")
        enc = _normalize_encoding_required(encoding)
        mode = "rewrite" if normalized_action == "write" else "append"
        fs_tools.write_file(file_path, content, mode=mode, expected_mtime=expected_mtime, encoding=enc)
        return f"Successfully {mode}d {file_path}."

    if normalized_action == "delete":
        if file_path is None:
            raise ValueError("file_path is required for delete.")
        resolved = _validate_path(file_path)
        if not resolved.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        if resolved.is_dir():
            raise IsADirectoryError("delete only supports files.")
        _check_expected_mtime(resolved, expected_mtime)
        policy = delete_guard.evaluate_delete_policy(resolved, approval_token=approval_token)
        if policy.get("status") != "allowed":
            return policy
        fs_tools.move_to_recycle_bin(str(resolved))
        return _build_delete_success_response(resolved, "file", policy)

    if normalized_action in {"copy", "move"}:
        if source_path is None or destination_path is None:
            raise ValueError("source_path and destination_path are required for copy/move.")
        if normalized_action == "move":
            fs_tools.move_file(source_path, destination_path, expected_mtime)
            return f"Moved {source_path} to {destination_path}."

        source = _validate_path(source_path)
        dest = _validate_path(destination_path)
        if not source.exists():
            raise FileNotFoundError(f"Source not found: {source_path}")
        if not source.is_file():
            raise IsADirectoryError("copy only supports files.")
        if dest.exists():
            raise FileExistsError(f"Destination already exists: {destination_path}")

        _check_expected_mtime(source, expected_mtime)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, dest)
        return f"Copied {source_path} to {destination_path}."

    raise ValueError("action must be one of: write, append, copy, move, delete.")


@server.tool()
def edit_blocks(
    edits: dict | List[dict],
    error_policy: str = "fail-fast",
    encoding: str = "auto",
) -> dict[str, Any]:
    """
    Apply one or more **literal** search/replace edits in a single call.

    This tool is designed for LLM-safe edits with optimistic locking + encoding safety.

    Input formats:
    - **Single-edit mode**: pass a `dict` (supports large-file *streaming* replacement)
    - **Batch mode**: pass a `list[dict]` (multiple edits across one or more files)

    Each edit dict supports:
    - `file_path` (required, str): absolute path to the target file (**NOT** `path`)
    - `old_string` (required, str, non-empty): exact literal text to replace
    - `new_string` (required, str): replacement text (may be empty to delete)
    - `expected_replacements` (optional, int, default=1): fail if actual count differs
    - `expected_mtime` (optional, float|int): optimistic lock; use `config_ops(get_info)`
    - `ignore_whitespace` (optional, bool): whitespace-insensitive matching (small files only)
    - `normalize_escapes` (optional, bool): treat `\\n`, `\\t`, etc as escapes (small files only)

    Encoding:
    - `encoding="auto"` (default): use detected encoding when possible
    - Or pass an explicit encoding. Supported: `utf-8`, `gbk`, `gb2312`, `gb18030`

    Common pitfalls / 常见误用:
    - Missing `file_path` (LLMs sometimes send `path` from `read_files`)
    - UnicodeDecodeError: pass correct `encoding` (or keep `auto`) / 传错编码导致解码失败
    - Large files (> threshold): batch mode is rejected; use single-edit mode instead
    """
    if isinstance(edits, dict):
        return _handle_single_edit(edits, encoding)

    if isinstance(edits, list):
        if len(edits) == 0:
            raise ValueError("edits must be a non-empty list of edit specifications.")
        return _handle_multiple_edits(edits, error_policy, encoding)

    raise ValueError("edits must be a dict or a list of dicts.")


def _handle_single_edit(edit: dict, encoding: str) -> dict[str, Any]:
    file_path = edit.get("file_path")
    if not file_path or not isinstance(file_path, str):
        raise ValueError("file_path is required and must be a string (note: key is 'file_path', not 'path').")

    old_string = edit.get("old_string", "")
    new_string = edit.get("new_string", "")
    expected_replacements = edit.get("expected_replacements", 1)
    expected_mtime = edit.get("expected_mtime")
    ignore_whitespace = edit.get("ignore_whitespace", False)
    normalize_escapes = edit.get("normalize_escapes", False)

    resolved = _validate_path(file_path)
    stats = resolved.stat()
    meta = fs_tools._get_cached_file_metadata(resolved, stats)
    enc = _resolve_edit_blocks_encoding(
        resolved,
        encoding,
        detected_encoding=meta.get("encoding"),
        detected_confidence=meta.get("encodingConfidence"),
    )

    if meta.get("isBinary") or meta.get("isImage"):
        raise RuntimeError("Cannot edit binary or image files.")

    size_value = meta.get("size")
    if isinstance(size_value, (int, float)):
        size = int(size_value)
    else:
        size = int(stats.st_size)
    threshold = FILE_SIZE_LIMITS.get("LARGE_FILE_THRESHOLD", 10 * 1024 * 1024)

    if size > threshold:
        if ignore_whitespace or normalize_escapes:
            raise RuntimeError(
                "Large-file mode only supports strict literal replacement. "
                "Disable ignore_whitespace/normalize_escapes."
            )
        try:
            result = fs_tools.stream_replace(
                file_path,
                old_string,
                new_string,
                expected_replacements=expected_replacements,
                expected_mtime=expected_mtime,
                encoding=enc,
            )
        except UnicodeDecodeError as exc:
            raise ValueError(
                f"Failed to decode {file_path!r} with encoding {enc!r}: {exc}. "
                "Tip: use encoding='auto' or pass the correct encoding explicitly."
            ) from exc
        fs_tools._invalidate_file_cache(str(resolved))
        return result

    try:
        result = edit_tools.perform_search_replace(
            file_path,
            old_string,
            new_string,
            expected_replacements=expected_replacements,
            expected_mtime=expected_mtime,
            ignore_whitespace=ignore_whitespace,
            normalize_escapes=normalize_escapes,
            encoding=enc,
        )
    except UnicodeDecodeError as exc:
        raise ValueError(
            f"Failed to decode {file_path!r} with encoding {enc!r}: {exc}. "
            "Tip: use encoding='auto' or pass the correct encoding explicitly."
        ) from exc
    fs_tools._invalidate_file_cache(str(resolved))
    return cast(dict[str, Any], result)


def _handle_multiple_edits(edits: List[dict], error_policy: str, encoding: str) -> dict[str, Any]:
    policy = error_policy.lower()
    if policy not in {"fail-fast", "continue", "rollback"}:
        raise ValueError("error_policy must be one of: fail-fast, continue, rollback.")

    # Group edits by file for sequential processing
    from collections import defaultdict

    edits_by_file: dict = defaultdict(list)
    for idx, edit in enumerate(edits):
        if not isinstance(edit, dict):
            raise ValueError(f"Edit at index {idx} must be a dict.")
        file_path = edit.get("file_path")
        if not file_path or not isinstance(file_path, str):
            raise ValueError(
                f"Edit at index {idx} missing valid file_path (required key: 'file_path', not 'path')."
            )
        edits_by_file[file_path].append((idx, edit))

    results: list = [None] * len(edits)  # Preserve original order
    backups: dict = {}  # file_path -> {"content": str, "encoding": str} (for rollback)
    successful = 0
    failed = 0

    try:
        for file_path, file_edits in edits_by_file.items():
            resolved = _validate_path(file_path)
            meta = fs_tools._get_cached_file_metadata(resolved)
            if meta.get("isBinary") or meta.get("isImage"):
                raise RuntimeError("Cannot edit binary or image files.")
            enc = _resolve_edit_blocks_encoding(
                resolved,
                encoding,
                detected_encoding=meta.get("encoding"),
                detected_confidence=meta.get("encodingConfidence"),
            )

            # Check file size limit
            file_size = resolved.stat().st_size
            max_bytes = FILE_SIZE_LIMITS.get("LARGE_FILE_THRESHOLD", 10 * 1024 * 1024)
            if file_size > max_bytes:
                raise RuntimeError(
                    f"File {file_path} too large for edit_blocks: {file_size} bytes (limit {max_bytes} bytes). "
                    "Use single-edit mode (dict input) for large files or split the file."
                )

            # Read file once for all edits to this file
            try:
                content = fs_tools.read_file_internal(str(resolved), 0, 1 << 30, encoding=enc)
            except UnicodeDecodeError as exc:
                raise ValueError(
                    f"Failed to decode {file_path!r} with encoding {enc!r}: {exc}. "
                    "Tip: use encoding='auto' or pass the correct encoding explicitly."
                ) from exc

            if policy == "rollback":
                backups[file_path] = {"content": content, "encoding": enc}

            # Apply edits sequentially, tracking cumulative changes
            current_content = content

            for idx, edit in file_edits:
                try:
                    old_string = edit.get("old_string", "")
                    new_string = edit.get("new_string", "")
                    expected_reps = edit.get("expected_replacements", 1)
                    ignore_ws = edit.get("ignore_whitespace", False)
                    norm_esc = edit.get("normalize_escapes", False)

                    if not old_string:
                        raise ValueError("old_string cannot be empty.")

                    # Perform the edit on current_content (in-memory)
                    edit_result = edit_tools.perform_single_edit_in_memory(
                        current_content,
                        old_string,
                        new_string,
                        expected_reps,
                        ignore_ws,
                        norm_esc,
                        file_path,
                    )

                    current_content = edit_result["new_content"]
                    results[idx] = {
                        "status": "success",
                        "message": edit_result["message"],
                        "file_path": file_path,
                        "replacements": edit_result["replacements"],
                        "locations": edit_result["locations"],
                    }
                    successful += 1

                except Exception as e:
                    failed += 1
                    results[idx] = {
                        "status": "error",
                        "file_path": file_path,
                        "error": str(e),
                    }

                    if policy == "fail-fast":
                        # Write what we have so far for this file
                        if current_content != content:
                            fs_tools.write_file(
                                file_path, current_content, mode="rewrite", encoding=enc
                            )
                            fs_tools._invalidate_file_cache(str(resolved))

                        return {
                            "status": "partial",
                            "message": f"Stopped at edit {idx}: {e}",
                            "total_edits": len(edits),
                            "successful_edits": successful,
                            "failed_edits": failed,
                            "results": [r for r in results if r is not None],
                        }

                    elif policy == "rollback":
                        raise  # Will be caught by outer try/except

            # Write final content for this file
            if current_content != content:
                fs_tools.write_file(file_path, current_content, mode="rewrite", encoding=enc)
                fs_tools._invalidate_file_cache(str(resolved))

        status = "success" if failed == 0 else "partial"
        return {
            "status": status,
            "message": f"Completed {successful}/{len(edits)} edits",
            "total_edits": len(edits),
            "successful_edits": successful,
            "failed_edits": failed,
            "results": results,
        }

    except Exception as e:
        if policy == "rollback":
            # Restore all backed-up files
            for file_path, backup in backups.items():
                try:
                    original_content = backup.get("content")
                    original_encoding = backup.get("encoding")
                    if isinstance(original_content, str) and isinstance(original_encoding, str):
                        fs_tools.write_file(
                            file_path, original_content, mode="rewrite", encoding=original_encoding
                        )
                    fs_tools._invalidate_file_cache(file_path)
                except Exception:
                    pass  # Best effort rollback

            return {
                "status": "error",
                "message": f"Rolled back all changes due to error: {e}",
                "total_edits": len(edits),
                "successful_edits": 0,
                "failed_edits": failed,
                "results": [r for r in results if r is not None],
            }
        raise


@server.tool()
def convert_file_encoding(
    file_paths: List[str],
    source_encoding: str,
    target_encoding: str,
    error_handling: str = "strict",
    mismatch_policy: str = "warn-skip",
) -> list[dict]:
    """
    Convert files between encodings (utf-8, gbk, gb2312, gb18030).

    Args:
        file_paths: List of absolute file paths.
        source_encoding: Current encoding.
        target_encoding: Desired encoding.
        error_handling: "strict" | "replace" | "ignore"
        mismatch_policy: "warn-skip" | "fail-fast" | "force"
    """
    err = error_handling.lower()
    if err not in {"strict", "replace", "ignore"}:
        raise ValueError("error_handling must be one of: strict, replace, ignore.")
    policy = mismatch_policy.lower()
    if policy not in {"warn-skip", "fail-fast", "force"}:
        raise ValueError("mismatch_policy must be one of: warn-skip, fail-fast, force.")
    src = _normalize_encoding_required(source_encoding)
    tgt = _normalize_encoding_required(target_encoding)
    return fs_tools.convert_file_encoding(file_paths, src, tgt, err, policy)

if __name__ == "__main__":
    server.run()
