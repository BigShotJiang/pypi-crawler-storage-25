from __future__ import annotations

import hashlib
import os
import secrets
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Tuple

LARGE_DELETE_FILE_THRESHOLD = 50
LARGE_DELETE_SIZE_BYTES = 20 * 1024 * 1024
LARGE_DELETE_DEPTH_THRESHOLD = 3
APPROVAL_TOKEN_TTL_SECONDS = int(os.getenv("CODE_EDIT_DELETE_APPROVAL_TTL_SECONDS", "300"))
MAX_SAMPLE_PATHS = 8

DEFAULT_IMPORTANT_DIR_NAMES = {
    "windows",
    "program files",
    "program files (x86)",
    "programdata",
    "users",
}

PERMANENTLY_BLOCKED_ROOTS = {
    os.path.normcase("C:\\"),
    os.path.normcase("D:\\"),
    os.path.normcase("E:\\"),
}

_POSIX_ROOT = os.path.normcase(str(Path("/")))


@dataclass
class _ApprovalRecord:
    normalized_target_path: str
    fingerprint: str
    expires_at_epoch: float


_APPROVAL_TOKENS: Dict[str, _ApprovalRecord] = {}


def evaluate_delete_policy(target: Path, approval_token: str | None = None) -> dict[str, Any]:
    resolved = target.resolve()
    critical_block = get_critical_delete_block(resolved)
    if critical_block is not None:
        return critical_block

    profile = _build_delete_profile(resolved)
    requires_approval = _requires_approval(resolved, profile)
    if not requires_approval:
        return {
            "status": "allowed",
            "risk_level": "medium" if profile["is_large_scale"] else "low",
            "action_required": "none",
            "delete_mode": "recycle_bin",
            "target_path": profile["target_path"],
            "impact_summary": profile["impact_summary"],
            "policy_summary": profile["policy_summary"],
        }

    normalized_target = _normalize_path(resolved)
    fingerprint = str(profile["fingerprint"])
    if approval_token:
        approved, detail = _consume_and_validate_token(approval_token, normalized_target, fingerprint)
        if approved:
            return {
                "status": "allowed",
                "risk_level": "high",
                "action_required": "none",
                "delete_mode": "recycle_bin",
                "target_path": profile["target_path"],
                "impact_summary": profile["impact_summary"],
                "policy_summary": profile["policy_summary"],
                "approval": {
                    "token_validated": True,
                    "detail": detail,
                },
            }
        invalid_reason = detail
    else:
        invalid_reason = "approval_token_missing"

    token, expires_at = _issue_approval_token(normalized_target, fingerprint)
    return _needs_approval_response(profile, token, expires_at, invalid_reason)


def get_critical_delete_block(target: Path) -> dict[str, Any] | None:
    resolved = target.resolve()
    blocked_reason = _get_critical_block_reason(resolved)
    if blocked_reason is None:
        return None
    return _blocked_critical_response(resolved, blocked_reason)


def _build_delete_profile(target: Path) -> dict[str, Any]:
    if not target.exists():
        raise FileNotFoundError(f"Target not found: {target}")

    normalized_target = _normalize_path(target)
    important = _is_important_path(target)
    impact = _collect_impact_summary(target)
    file_count = int(impact["file_count"])
    total_bytes = int(impact["total_bytes"])
    max_depth = int(impact["max_depth"])
    large_scale = (
        file_count >= LARGE_DELETE_FILE_THRESHOLD
        or total_bytes >= LARGE_DELETE_SIZE_BYTES
        or max_depth >= LARGE_DELETE_DEPTH_THRESHOLD
    )

    return {
        "target_path": normalized_target,
        "is_important": important,
        "is_large_scale": large_scale,
        "fingerprint": str(impact["fingerprint"]),
        "impact_summary": {
            "file_count": file_count,
            "total_bytes": total_bytes,
            "max_depth": max_depth,
            "sample_paths": list(impact["sample_paths"]),
            "is_directory": bool(impact["is_directory"]),
        },
        "policy_summary": {
            "important_path": important,
            "large_scale_thresholds": {
                "file_count_gte": LARGE_DELETE_FILE_THRESHOLD,
                "total_bytes_gte": LARGE_DELETE_SIZE_BYTES,
                "max_depth_gte": LARGE_DELETE_DEPTH_THRESHOLD,
            },
            "matched_large_scale": large_scale,
            "approval_rule": "important_path_and_large_scale",
        },
    }


def _collect_impact_summary(target: Path) -> dict[str, Any]:
    hasher = hashlib.sha256()
    sample_paths: List[str] = []

    if target.is_file():
        stats = target.stat()
        hasher.update(f"F|{target.name}|{stats.st_size}|{stats.st_mtime_ns}".encode("utf-8"))
        return {
            "is_directory": False,
            "file_count": 1,
            "total_bytes": int(stats.st_size),
            "max_depth": 0,
            "sample_paths": [target.name],
            "fingerprint": hasher.hexdigest(),
        }

    if not target.is_dir():
        raise ValueError(f"Delete target is neither file nor directory: {target}")

    root_stats = target.stat()
    hasher.update(f"ROOT|{target.name}|{root_stats.st_mtime_ns}".encode("utf-8"))
    file_count = 0
    total_bytes = 0
    max_depth = 0

    for root, dir_names, file_names in os.walk(target, topdown=True, followlinks=False):
        dir_names.sort()
        file_names.sort()
        root_path = Path(root)
        for dir_name in dir_names:
            directory = root_path / dir_name
            relative = directory.relative_to(target).as_posix()
            depth = len(Path(relative).parts)
            max_depth = max(max_depth, depth)
            directory_stats = directory.stat()
            hasher.update(f"D|{relative}|{directory_stats.st_mtime_ns}".encode("utf-8"))
            if len(sample_paths) < MAX_SAMPLE_PATHS:
                sample_paths.append(relative)
        for file_name in file_names:
            file_path = root_path / file_name
            relative = file_path.relative_to(target).as_posix()
            depth = len(Path(relative).parts)
            max_depth = max(max_depth, depth)
            file_stats = file_path.stat()
            file_count += 1
            total_bytes += int(file_stats.st_size)
            hasher.update(
                f"F|{relative}|{file_stats.st_size}|{file_stats.st_mtime_ns}".encode("utf-8")
            )
            if len(sample_paths) < MAX_SAMPLE_PATHS:
                sample_paths.append(relative)

    return {
        "is_directory": True,
        "file_count": file_count,
        "total_bytes": total_bytes,
        "max_depth": max_depth,
        "sample_paths": sample_paths,
        "fingerprint": hasher.hexdigest(),
    }


def _requires_approval(target: Path, profile: dict[str, Any]) -> bool:
    return bool(profile["is_important"]) and bool(profile["is_large_scale"])


def _is_important_path(target: Path) -> bool:
    names = _important_dir_names()
    parts = [segment.lower() for segment in target.parts if segment and segment != target.anchor]
    return any(part in names for part in parts)


def _important_dir_names() -> set[str]:
    configured = os.getenv("CODE_EDIT_IMPORTANT_DIR_NAMES", "").strip()
    if not configured:
        return set(DEFAULT_IMPORTANT_DIR_NAMES)
    extra_names = {item.strip().lower() for item in configured.split(",") if item.strip()}
    return set(DEFAULT_IMPORTANT_DIR_NAMES).union(extra_names)


def _get_critical_block_reason(target: Path) -> str | None:
    normalized = _normalize_path(target)
    if normalized in PERMANENTLY_BLOCKED_ROOTS:
        return "Deleting Windows drive roots (C:\\, D:\\, E:\\) is permanently blocked."

    if target.anchor and target == Path(target.anchor):
        return "Deleting a filesystem root is permanently blocked."

    if normalized == _POSIX_ROOT:
        return "Deleting the Linux root directory (/) is permanently blocked."

    return None


def _blocked_critical_response(target: Path, reason: str) -> dict[str, Any]:
    normalized = _normalize_path(target)
    return {
        "status": "blocked_critical",
        "risk_level": "extreme",
        "action_required": "stop_and_explain_risk",
        "delete_mode": "recycle_bin",
        "target_path": normalized,
        "impact_summary": {
            "file_count": None,
            "total_bytes": None,
            "max_depth": None,
            "sample_paths": [],
            "is_directory": True,
        },
        "warning": (
            "This operation was permanently blocked because it could wipe critical system data. "
            "Potential harm includes full-drive data loss, broken development environments, and "
            "high-cost recovery."
        ),
        "llm_instruction": (
            "STOP. Do not execute this delete request again. Explain to the user that deleting "
            "a drive root can destroy the entire system or workspace."
        ),
        "detail": reason,
    }


def _needs_approval_response(
    profile: dict[str, Any], token: str, expires_at: float, invalid_reason: str
) -> dict[str, Any]:
    return {
        "status": "needs_approval",
        "risk_level": "high",
        "action_required": "ask_user_and_wait_for_explicit_approval",
        "delete_mode": "recycle_bin",
        "target_path": profile["target_path"],
        "impact_summary": profile["impact_summary"],
        "policy_summary": profile["policy_summary"],
        "approval": {
            "approval_token": token,
            "expires_at": _format_epoch(expires_at),
            "token_ttl_seconds": APPROVAL_TOKEN_TTL_SECONDS,
            "invalid_reason": invalid_reason,
        },
        "warning": (
            "High-risk delete detected on an important directory with large impact. "
            "User approval is required before any deletion can proceed."
        ),
        "llm_instruction": (
            "Pause automation now. Ask the user: 'Do you explicitly approve deleting this target?' "
            "Wait for a clear yes before retrying with approval_token."
        ),
    }


def _issue_approval_token(normalized_target: str, fingerprint: str) -> Tuple[str, float]:
    _cleanup_expired_tokens()
    token = secrets.token_urlsafe(24)
    expires_at = time.time() + APPROVAL_TOKEN_TTL_SECONDS
    _APPROVAL_TOKENS[token] = _ApprovalRecord(
        normalized_target_path=normalized_target,
        fingerprint=fingerprint,
        expires_at_epoch=expires_at,
    )
    return token, expires_at


def _consume_and_validate_token(
    token: str, normalized_target: str, fingerprint: str
) -> Tuple[bool, str]:
    _cleanup_expired_tokens()
    record = _APPROVAL_TOKENS.get(token)
    if record is None:
        return False, "approval_token_invalid_or_expired"
    if record.normalized_target_path != normalized_target:
        _APPROVAL_TOKENS.pop(token, None)
        return False, "approval_token_target_mismatch"
    if record.fingerprint != fingerprint:
        _APPROVAL_TOKENS.pop(token, None)
        return False, "approval_token_snapshot_mismatch"
    if record.expires_at_epoch < time.time():
        _APPROVAL_TOKENS.pop(token, None)
        return False, "approval_token_expired"

    _APPROVAL_TOKENS.pop(token, None)
    return True, "approval_token_valid"


def _cleanup_expired_tokens() -> None:
    now = time.time()
    expired_tokens = [
        token for token, record in _APPROVAL_TOKENS.items() if record.expires_at_epoch < now
    ]
    for token in expired_tokens:
        _APPROVAL_TOKENS.pop(token, None)


def _normalize_path(path: Path) -> str:
    return os.path.normcase(str(path.resolve()))


def _format_epoch(epoch_seconds: float) -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(epoch_seconds))
