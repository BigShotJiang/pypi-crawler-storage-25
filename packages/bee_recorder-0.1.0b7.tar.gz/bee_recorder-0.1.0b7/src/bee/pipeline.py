"""Processing pipeline: transcription -> diarization -> participant identification."""

import json
from pathlib import Path

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from bee.config import RECORDINGS_DIR, TRANSCRIPTS_DIR, ensure_dirs

console = Console()


def _make_segment(raw: dict):
    from bee.transcriber import Segment
    return Segment(
        start=raw["start"],
        end=raw["end"],
        text=raw["text"],
        source=raw.get("source", ""),
    )


def _load_live_transcript(rec_dir: Path) -> dict:
    path = rec_dir / "live_transcript.json"
    if not path.exists():
        return {"segments": [], "mic_offset": 0.0, "system_offset": 0.0, "system_source": None}
    with open(path) as f:
        return json.load(f)


def _transcribe_tail(audio_file: Path, offset: float, progress, task, label: str) -> list:
    """Transcribe only the segment after `offset`. Returns segments with absolute timestamps."""
    from bee.transcriber import transcribe
    import subprocess

    total = 0.0
    try:
        r = subprocess.run(
            ["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
             "-of", "csv=p=0", str(audio_file)],
            capture_output=True, text=True, timeout=10,
        )
        total = float(r.stdout.strip())
    except (ValueError, subprocess.TimeoutExpired):
        pass

    remaining = total - offset
    if remaining < 1.0:
        return []

    progress.update(task, description=f"Transcribing {label} (last {int(remaining)}s)...")

    tmp = audio_file.parent / f"_tail_{audio_file.stem}.wav"
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-ss", str(offset), "-i", str(audio_file),
             "-ar", "16000", "-ac", "1", str(tmp)],
            capture_output=True, timeout=60,
        )
        if not tmp.exists() or tmp.stat().st_size < 1000:
            return []
        segs = transcribe(tmp)
        for s in segs:
            s.start += offset
            s.end += offset
        return segs
    except (subprocess.TimeoutExpired, Exception):
        return []
    finally:
        tmp.unlink(missing_ok=True)


def process_recording(
    rec_id: str,
    skip_diarization: bool = False,
    num_speakers: int | None = None,
) -> dict:
    """Process a recording: transcribe, diarize, save JSON + Markdown."""
    ensure_dirs()
    rec_dir = RECORDINGS_DIR / rec_id
    metadata = _read_metadata(rec_dir)

    mic_file = rec_dir / "mic.wav"
    system_file = rec_dir / "system.wav"
    has_mic = mic_file.exists() and mic_file.stat().st_size > 1000
    has_system = system_file.exists() and system_file.stat().st_size > 1000

    if has_system:
        has_system = _has_audio_content(system_file)

    two_channel = has_mic and has_system

    if not has_mic and not has_system:
        audio_files = _resolve_audio_files(rec_dir, metadata)
        if not audio_files:
            raise FileNotFoundError(f"No audio file found in: {rec_dir}")

    live = _load_live_transcript(rec_dir)
    pre_segments = [
        _make_segment(s) for s in live.get("segments", [])
    ]
    mic_offset = live.get("mic_offset", 0.0)
    system_offset = live.get("system_offset", 0.0)

    # If the live-transcribed system sink differs from the one selected at stop,
    # discard the system pre-transcription.
    live_sys_source = live.get("system_source")
    best_sys_source = metadata.get("best_system_source")
    if live_sys_source and best_sys_source and live_sys_source != best_sys_source:
        pre_segments = [s for s in pre_segments if s.source == "mic"]
        system_offset = 0.0

    has_live = bool(pre_segments) or mic_offset > 0 or system_offset > 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:

        task = progress.add_task("Transcribing audio with Whisper...", total=None)
        from bee.transcriber import transcribe

        all_segments = list(pre_segments)

        if has_live:
            progress.update(task, description="Continuing live transcription...")

        if two_channel:
            tail_mic = _transcribe_tail(mic_file, mic_offset, progress, task, "microphone")
            for s in tail_mic:
                s.source = "mic"
            all_segments.extend(tail_mic)

            tail_sys = _transcribe_tail(system_file, system_offset, progress, task, "system")
            for s in tail_sys:
                s.source = "system"
            all_segments.extend(tail_sys)
        else:
            if has_mic:
                audio_file, offset = mic_file, mic_offset
            elif has_system:
                audio_file, offset = system_file, system_offset
            else:
                audio_file = _resolve_audio_files(rec_dir, metadata)[0]
                offset = 0.0

            if not has_live:
                progress.update(task, description=f"Transcribing {audio_file.name}...")
                segs = transcribe(audio_file)
                for s in segs:
                    s.source = audio_file.stem
                all_segments.extend(segs)
            else:
                tail = _transcribe_tail(audio_file, offset, progress, task, audio_file.stem)
                for s in tail:
                    s.source = audio_file.stem
                all_segments.extend(tail)

            if not has_system:
                console.print("[yellow]Warning: system audio is silent. Remote participants will be identified from the microphone bleed.[/yellow]")

        all_segments.sort(key=lambda s: s.start)
        segments = _deduplicate_segments(all_segments)
        progress.update(task, description=f"Transcription complete: {len(segments)} segments")
        progress.remove_task(task)

        if not skip_diarization:
            task = progress.add_task("Identifying participants...", total=None)
            from bee.diarizer import DiarizedSegment, diarize, merge_transcription_with_diarization

            mic_segments = [s for s in segments if s.source == "mic"]
            sys_segments = [s for s in segments if s.source == "system"]
            other_segments = [s for s in segments if s.source not in ("mic", "system")]

            diarized: list[DiarizedSegment] = []

            mic_target, sys_target = _split_speaker_count(num_speakers, has_mic, has_system)

            if has_mic and mic_segments:
                progress.update(task, description="Diarizing microphone audio...")
                mic_speakers = diarize(mic_file, num_speakers=mic_target, label_prefix="Mic")
                diarized.extend(merge_transcription_with_diarization(mic_segments, mic_speakers))

            if has_system and sys_segments:
                progress.update(task, description="Diarizing system audio...")
                sys_speakers = diarize(system_file, num_speakers=sys_target, label_prefix="Speaker")
                diarized.extend(merge_transcription_with_diarization(sys_segments, sys_speakers))

            if other_segments:
                # Single-source recording (neither tagged "mic" nor "system") — diarize the
                # whole audio file with a generic prefix.
                fallback_audio = _resolve_audio_files(rec_dir, metadata)[0]
                fb_speakers = diarize(fallback_audio, num_speakers=num_speakers, label_prefix="Speaker")
                diarized.extend(merge_transcription_with_diarization(other_segments, fb_speakers))

            diarized.sort(key=lambda s: s.start)
            speaker_count = len(set(s.speaker for s in diarized))
            progress.update(task, description=f"Identification complete: {speaker_count} speakers")
            progress.remove_task(task)
        else:
            from bee.diarizer import DiarizedSegment
            diarized = [
                DiarizedSegment(start=s.start, end=s.end, speaker="Speaker", text=s.text)
                for s in segments
            ]

        task = progress.add_task("Saving transcript...", total=None)
        from bee.formatter import resolve_transcript_paths, save_transcript

        started_at = _parse_started_at(metadata)
        display_name = metadata.get("display_name")

        existing_json = metadata.get("transcript_json")
        existing_md = metadata.get("transcript_md")
        if existing_json and existing_md and Path(existing_md).parent.exists():
            json_path = Path(existing_json)
            md_path = Path(existing_md)
        else:
            resolved = resolve_transcript_paths(TRANSCRIPTS_DIR, started_at, display_name)
            json_path = resolved["json_path"]
            md_path = resolved["md_path"]

        paths = save_transcript(
            diarized,
            rec_id,
            json_path,
            md_path,
            started_at=started_at,
            display_name=display_name,
        )
        progress.remove_task(task)

    metadata["status"] = "processed"
    metadata["transcript_json"] = paths["json_path"]
    metadata["transcript_md"] = paths["md_path"]
    _write_metadata(rec_dir, metadata)

    return {
        "segments": len(diarized),
        "speakers": len(set(s.speaker for s in diarized)),
        "json_path": paths["json_path"],
        "md_path": paths["md_path"],
    }


def get_speaker_previews(rec_id: str) -> dict[str, dict]:
    """Return detailed info for each speaker to help identify them."""
    rec_dir = RECORDINGS_DIR / rec_id
    metadata = _read_metadata(rec_dir) if rec_dir.exists() else {}
    transcript_json = _resolve_transcript_path(rec_id, metadata, ".json")
    if transcript_json is None or not transcript_json.exists():
        return {}

    raw = json.loads(transcript_json.read_text(encoding="utf-8"))
    segments = raw["segments"] if isinstance(raw, dict) and "segments" in raw else raw
    speakers: dict[str, dict] = {}

    for seg in segments:
        speaker = seg["speaker"]
        if speaker not in speakers:
            speakers[speaker] = {
                "quotes": [],
                "word_count": 0,
                "duration": 0.0,
                "segment_count": 0,
            }
        info = speakers[speaker]
        info["segment_count"] += 1
        info["word_count"] += len(seg["text"].split())
        info["duration"] += seg["end"] - seg["start"]
        text = seg["text"].strip()
        if text and len(text.split()) >= 3:
            info["quotes"].append(text)

    for info in speakers.values():
        info["quotes"] = sorted(info["quotes"], key=len, reverse=True)[:5]

    return speakers


def label_speakers(rec_id: str, labels: dict[str, str]) -> dict:
    """Replace speaker labels (e.g. Speaker_00 -> Alice) in the transcript."""
    ensure_dirs()

    rec_dir = RECORDINGS_DIR / rec_id
    metadata = _read_metadata(rec_dir) if rec_dir.exists() else {}

    json_path = _resolve_transcript_path(rec_id, metadata, ".json")
    if json_path is None or not json_path.exists():
        raise FileNotFoundError(f"Transcript not found: {rec_id}")
    md_path = _resolve_transcript_path(rec_id, metadata, ".md")
    if md_path is None:
        md_path = json_path.with_suffix(".md")

    raw = json.loads(json_path.read_text(encoding="utf-8"))
    segments = raw["segments"] if isinstance(raw, dict) and "segments" in raw else raw
    for seg in segments:
        if seg["speaker"] in labels:
            seg["speaker"] = labels[seg["speaker"]]

    from bee.diarizer import DiarizedSegment
    from bee.formatter import save_transcript

    diarized = [
        DiarizedSegment(start=s["start"], end=s["end"], speaker=s["speaker"], text=s["text"])
        for s in segments
    ]

    language = raw.get("metadata", {}).get("language_detected") if isinstance(raw, dict) else None
    started_at = _parse_started_at(metadata) if metadata else None
    display_name = metadata.get("display_name") if metadata else None
    written = save_transcript(
        diarized, rec_id, json_path, md_path,
        language=language, started_at=started_at, display_name=display_name,
    )

    if rec_dir.exists():
        metadata["speaker_labels"] = labels
        _write_metadata(rec_dir, metadata)

    return {
        "speakers": list(set(s["speaker"] for s in segments)),
        "md_path": written["md_path"],
        "json_path": written["json_path"],
    }


def set_display_name(rec_id: str, display_name: str) -> None:
    """Persist a meeting name onto an existing recording's metadata."""
    rec_dir = RECORDINGS_DIR / rec_id
    if not rec_dir.exists():
        raise FileNotFoundError(f"Recording not found: {rec_id}")
    metadata = _read_metadata(rec_dir)
    metadata["display_name"] = display_name
    _write_metadata(rec_dir, metadata)


def _split_speaker_count(
    total: int | None,
    has_mic: bool,
    has_system: bool,
) -> tuple[int | None, int | None]:
    """Split a total speaker count across mic and system tracks.

    Assumes the user is alone on the mic and remaining participants are on system
    (the common remote-meeting case). When only one channel is active, the count
    is applied to it as-is.
    """
    if total is None:
        return None, None
    if has_mic and has_system:
        return 1, max(1, total - 1)
    if has_mic:
        return total, None
    if has_system:
        return None, total
    return None, None


def _parse_started_at(metadata: dict) -> "datetime":
    """Return a datetime for `started_at`, falling back to now() if absent/invalid."""
    from datetime import datetime
    raw = metadata.get("started_at")
    if raw:
        try:
            return datetime.fromisoformat(raw)
        except ValueError:
            pass
    return datetime.now()


def _resolve_transcript_path(rec_id: str, metadata: dict, ext: str) -> Path | None:
    """Locate a transcript file: metadata pointer, else legacy flat path, else recursive search."""
    key = "transcript_json" if ext == ".json" else "transcript_md"
    pointer = metadata.get(key) if metadata else None
    if pointer:
        p = Path(pointer)
        if p.exists():
            return p
    legacy = TRANSCRIPTS_DIR / f"{rec_id}{ext}"
    if legacy.exists():
        return legacy
    matches = sorted(TRANSCRIPTS_DIR.glob(f"**/{rec_id}{ext}"))
    return matches[0] if matches else None


def summarize_transcript(transcript_path: Path) -> str:
    """Generate a summary for an existing transcript file (requires Claude CLI)."""
    from bee.summarizer import is_available, summarize

    if not is_available():
        raise RuntimeError("Claude CLI not found. Install Claude Code CLI to generate summaries.")

    transcript_text = transcript_path.read_text(encoding="utf-8")
    summary = summarize(transcript_text, transcript_path)

    summary_file = transcript_path.with_name(
        transcript_path.stem + "_summary.md"
    )
    summary_file.write_text(summary, encoding="utf-8")
    return summary


def _has_audio_content(audio_path: Path, threshold_db: float = -70.0) -> bool:
    """Check whether the audio file has audible content (i.e. it's not silence)."""
    import subprocess
    result = subprocess.run(
        ["ffmpeg", "-i", str(audio_path), "-af", "volumedetect", "-f", "null", "/dev/null"],
        capture_output=True, text=True,
    )
    for line in result.stderr.splitlines():
        if "max_volume:" in line:
            try:
                db = float(line.split("max_volume:")[1].strip().split()[0])
                return db > threshold_db
            except (ValueError, IndexError):
                pass
    return False


def _resolve_audio_files(rec_dir: Path, metadata: dict) -> list[Path]:
    """Return the list of audio files to transcribe."""
    files = []
    for name in ("mic.wav", "system.wav"):
        f = rec_dir / name
        if f.exists() and f.stat().st_size > 1000:
            files.append(f)
    if not files:
        combined = rec_dir / "combined.wav"
        if combined.exists():
            files.append(combined)
    return files


def _deduplicate_segments(segments: list) -> list:
    """Remove duplicate segments (overlapping in time with similar text)."""
    if not segments:
        return segments
    result = [segments[0]]
    for seg in segments[1:]:
        prev = result[-1]
        overlap = max(0, min(prev.end, seg.end) - max(prev.start, seg.start))
        min_duration = min(prev.end - prev.start, seg.end - seg.start)
        if min_duration > 0 and overlap / min_duration > 0.5:
            if _text_similarity(prev.text, seg.text) > 0.6:
                if len(seg.text) > len(prev.text):
                    result[-1] = seg
                continue
            result.append(seg)
            continue
        result.append(seg)
    return result


def _text_similarity(a: str, b: str) -> float:
    """Simple word-overlap similarity between two strings."""
    words_a = set(a.lower().split())
    words_b = set(b.lower().split())
    if not words_a or not words_b:
        return 0.0
    intersection = words_a & words_b
    return len(intersection) / min(len(words_a), len(words_b))


def _read_metadata(rec_dir: Path) -> dict:
    meta_file = rec_dir / "metadata.json"
    if not meta_file.exists():
        raise FileNotFoundError(f"Recording not found: {rec_dir.name}")
    with open(meta_file) as f:
        return json.load(f)


def _write_metadata(rec_dir: Path, metadata: dict):
    with open(rec_dir / "metadata.json", "w") as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)
