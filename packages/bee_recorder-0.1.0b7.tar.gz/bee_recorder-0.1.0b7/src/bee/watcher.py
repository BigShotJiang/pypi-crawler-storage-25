"""Watch the transcripts folder and auto-generate summaries for new transcripts."""

import subprocess
import time
from pathlib import Path

from rich.console import Console

from bee.config import TRANSCRIPTS_DIR, ensure_dirs

console = Console()


def start_watcher():
    """Watch TRANSCRIPTS_DIR and generate a summary when a new transcript appears."""
    ensure_dirs()

    console.print(f"Watching [cyan]{TRANSCRIPTS_DIR}[/cyan] for new transcripts...")
    console.print("Press Ctrl+C to stop.\n")

    if _has_inotifywait():
        _watch_with_inotify()
    else:
        _watch_with_polling()


def _has_inotifywait() -> bool:
    try:
        subprocess.run(["which", "inotifywait"], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def _is_transcript(name: str) -> bool:
    return name.endswith(".md") and not name.endswith("_summary.md")


def _watch_with_inotify():
    console.print("[dim]Using inotifywait for efficient watching[/dim]\n")

    while True:
        try:
            result = subprocess.run(
                [
                    "inotifywait",
                    "-r",
                    "-e", "close_write",
                    "-e", "moved_to",
                    "--format", "%w%f",
                    str(TRANSCRIPTS_DIR),
                ],
                capture_output=True,
                text=True,
            )
            full_path = result.stdout.strip()
            if not full_path:
                continue
            path = Path(full_path)
            if _is_transcript(path.name):
                _process_new_transcript(path)
        except KeyboardInterrupt:
            console.print("\n[yellow]Watcher stopped.[/yellow]")
            break


def _watch_with_polling():
    console.print("[dim]Using polling (install inotify-tools for more efficient watching)[/dim]\n")

    known_files: set[str] = {str(f) for f in TRANSCRIPTS_DIR.glob("**/*.md")}

    try:
        while True:
            current_files = {str(f) for f in TRANSCRIPTS_DIR.glob("**/*.md")}
            new_files = current_files - known_files

            for filename in sorted(new_files):
                path = Path(filename)
                if _is_transcript(path.name):
                    _process_new_transcript(path)

            known_files = current_files
            time.sleep(5)
    except KeyboardInterrupt:
        console.print("\n[yellow]Watcher stopped.[/yellow]")


def _process_new_transcript(transcript_path: Path):
    summary_path = transcript_path.with_name(transcript_path.stem + "_summary.md")
    if summary_path.exists():
        return

    console.print(f"New transcript detected: [cyan]{transcript_path.name}[/cyan]")
    console.print("Generating summary via Claude...\n")

    try:
        from bee.pipeline import summarize_transcript
        summarize_transcript(transcript_path)
        console.print(f"[green]Summary saved:[/green] {summary_path.name}\n")
    except Exception as e:
        console.print(f"[red]Failed to generate summary:[/red] {e}\n")
