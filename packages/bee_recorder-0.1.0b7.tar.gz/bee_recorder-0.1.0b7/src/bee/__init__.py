"""Bee — local-first meeting recorder with transcription and speaker diarization."""
