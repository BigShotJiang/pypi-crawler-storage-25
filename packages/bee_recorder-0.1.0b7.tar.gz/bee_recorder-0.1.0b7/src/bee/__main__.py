"""Allow `python -m bee` to invoke the CLI entry point."""

from bee.cli import main

if __name__ == "__main__":
    main()
