"""Optional summary generation via Claude Code CLI."""

import shutil
import subprocess
from pathlib import Path


SUMMARY_PROMPT = """Analyze the meeting transcript below and produce a structured summary.

Write the summary in the SAME language as the transcript itself.

Sections to include:

## Participants
List of participants identified in the meeting (use speaker labels if real names are not available).

## Overview
A short paragraph summarizing the meeting's purpose and outcome.

## Key Points
The most important topics discussed, with relevant detail.

## Decisions
Decisions made during the meeting.

## Action Items
Tasks/actions assigned, with the owner when identifiable.

## Next Steps
What was defined as the next steps.

---

TRANSCRIPT:

"""


def is_available() -> bool:
    return shutil.which("claude") is not None


def summarize(transcript_text: str, transcript_path: Path) -> str:
    if not is_available():
        raise RuntimeError("Claude CLI not found. Install Claude Code CLI to generate summaries.")

    prompt = SUMMARY_PROMPT + transcript_text

    result = subprocess.run(
        ["claude", "-p", prompt, "--output-format", "text"],
        capture_output=True,
        text=True,
        timeout=300,
    )

    if result.returncode != 0:
        raise RuntimeError(f"Claude CLI failed: {result.stderr}")

    return result.stdout.strip()
