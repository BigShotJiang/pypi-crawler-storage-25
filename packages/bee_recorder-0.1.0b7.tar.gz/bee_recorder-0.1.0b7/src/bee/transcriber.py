"""Audio transcription using faster-whisper."""

from dataclasses import dataclass
from pathlib import Path

from bee.config import WHISPER_DEVICE, WHISPER_LANGUAGE, WHISPER_MODEL

_model = None


@dataclass
class Segment:
    start: float
    end: float
    text: str
    source: str = ""


def _get_model(model_size: str):
    global _model
    if _model is None:
        from faster_whisper import WhisperModel

        device = WHISPER_DEVICE
        if device == "auto":
            import torch
            device = "cuda" if torch.cuda.is_available() else "cpu"

        compute_type = "float16" if device == "cuda" else "int8"
        _model = WhisperModel(model_size, device=device, compute_type=compute_type)
    return _model


def transcribe(audio_path: Path, model_size: str = WHISPER_MODEL, language: str | None = None) -> list[Segment]:
    """Transcribe an audio file and return segments with timestamps."""
    model = _get_model(model_size)

    lang = language or WHISPER_LANGUAGE
    if lang == "auto":
        lang = None

    segments_iter, info = model.transcribe(
        str(audio_path),
        language=lang,
        beam_size=5,
        word_timestamps=True,
        vad_filter=True,
        vad_parameters=dict(
            threshold=0.3,
            min_silence_duration_ms=800,
            speech_pad_ms=400,
            min_speech_duration_ms=250,
        ),
    )

    segments = list(segments_iter)

    if not segments:
        segments_iter, info = model.transcribe(
            str(audio_path),
            language=lang,
            beam_size=5,
            word_timestamps=True,
            vad_filter=False,
        )
        segments = list(segments_iter)

    return [
        Segment(start=seg.start, end=seg.end, text=seg.text.strip())
        for seg in segments
        if seg.text.strip()
    ]
