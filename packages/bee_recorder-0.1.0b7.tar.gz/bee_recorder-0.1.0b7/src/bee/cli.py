"""Bee command-line interface."""

import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


@click.group()
def main():
    """Bee — meeting recorder with transcription and speaker identification."""
    pass


@main.command()
@click.option("--name", "-n", default=None, help="Recording name (default: timestamp)")
@click.option("--no-mic", is_flag=True, help="Do not capture microphone (system audio only)")
@click.option("--monitor", "-m", default=None, help="Specific PulseAudio source to capture (override)")
def start(name: str | None, no_mic: bool, monitor: str | None):
    """Start a meeting recording."""
    from bee.recorder import get_active_recording, start_recording

    active = get_active_recording()
    if active:
        console.print(f"[red]A recording is already in progress:[/red] {active['id']}")
        console.print("Use [bold]bee stop[/bold] to stop the current recording.")
        sys.exit(1)

    metadata = start_recording(name=name, capture_mic=not no_mic, monitor_override=monitor)

    captures = metadata.get("system_captures", [])
    if len(captures) > 1:
        monitor_info = f"Capturing {len(captures)} audio outputs in parallel"
    elif captures:
        monitor_info = f"Monitor: {captures[0].get('monitor', '?')}"
    else:
        monitor_info = f"Monitor: {metadata.get('monitor_source', '?')}"

    console.print(Panel(
        f"[green bold]Recording started![/green bold]\n\n"
        f"ID: [cyan]{metadata['id']}[/cyan]\n"
        f"{monitor_info}\n"
        f"Microphone: {metadata['mic_source'] or 'disabled'}\n"
        f"Watcher: monitoring for new devices (e.g. AirPods)\n\n"
        f"Use [bold]bee stop[/bold] when the meeting ends.",
        title="Bee",
        border_style="green",
    ))


@main.command()
@click.option("--no-process", is_flag=True, help="Just stop, do not transcribe")
@click.option("--no-diarize", is_flag=True, help="Skip diarization (no speaker labels)")
@click.option("--no-identify", is_flag=True, help="Do not prompt for participant names")
@click.option("--no-name", is_flag=True, help="Do not prompt for a meeting name")
@click.option("--speakers", "-s", type=int, default=None,
              help="Number of participants (improves diarization accuracy)")
@click.option("--no-speakers-prompt", is_flag=True,
              help="Do not prompt for the participant count")
def stop(no_process: bool, no_diarize: bool, no_identify: bool, no_name: bool,
         speakers: int | None, no_speakers_prompt: bool):
    """Stop the recording and process it (transcription + participant identification)."""
    from bee.recorder import get_active_recording, stop_recording

    active = get_active_recording()
    if not active:
        console.print("[yellow]No active recording found.[/yellow]")
        sys.exit(1)

    rec_id = active["id"]
    console.print(f"Stopping recording [cyan]{rec_id}[/cyan]...")
    stop_recording(rec_id)
    console.print("[green]Recording stopped.[/green]\n")

    if no_process:
        console.print(f"Use [bold]bee process {rec_id}[/bold] to process it later.")
        return

    if not no_name:
        _prompt_meeting_name(rec_id)

    if speakers is None and not no_diarize and not no_speakers_prompt:
        speakers = _prompt_speaker_count()

    from bee.pipeline import process_recording
    result = process_recording(rec_id, skip_diarization=no_diarize, num_speakers=speakers)
    _print_result(rec_id, result)

    if not no_identify and not no_diarize:
        _interactive_identify(rec_id)


@main.command()
@click.argument("rec_id")
@click.option("--no-diarize", is_flag=True, help="Skip diarization")
@click.option("--no-identify", is_flag=True, help="Do not prompt for participant names")
@click.option("--no-name", is_flag=True, help="Do not prompt for a meeting name")
@click.option("--speakers", "-s", type=int, default=None,
              help="Number of participants (improves diarization accuracy)")
@click.option("--no-speakers-prompt", is_flag=True,
              help="Do not prompt for the participant count")
def process(rec_id: str, no_diarize: bool, no_identify: bool, no_name: bool,
            speakers: int | None, no_speakers_prompt: bool):
    """Process an existing recording (transcription + identification)."""
    from bee.pipeline import process_recording

    if not no_name:
        _prompt_meeting_name(rec_id)

    if speakers is None and not no_diarize and not no_speakers_prompt:
        speakers = _prompt_speaker_count()

    console.print(f"Processing recording [cyan]{rec_id}[/cyan]...\n")
    result = process_recording(rec_id, skip_diarization=no_diarize, num_speakers=speakers)
    _print_result(rec_id, result)

    if not no_identify and not no_diarize:
        _interactive_identify(rec_id)


@main.command()
@click.argument("transcript_path", type=click.Path(exists=True, path_type=Path))
def summarize(transcript_path: Path):
    """Generate a summary of an existing transcript via Claude CLI."""
    from bee.pipeline import summarize_transcript

    console.print(f"Generating summary for [cyan]{transcript_path.name}[/cyan]...\n")
    summary = summarize_transcript(transcript_path)

    from rich.markdown import Markdown
    console.print(Panel(Markdown(summary), title="Summary", border_style="yellow"))

    summary_file = transcript_path.with_name(transcript_path.stem + "_summary.md")
    console.print(f"\nSaved to [cyan]{summary_file}[/cyan]")


@main.command(name="_live-transcribe", hidden=True)
@click.argument("rec_id")
def _live_transcribe_cmd(rec_id: str):
    """Internal: run the chunked live transcriber for an active recording."""
    from bee.recorder import run_live_transcriber
    run_live_transcriber(rec_id)


@main.command(name="_sink-watch", hidden=True)
@click.argument("rec_id")
def _sink_watch_cmd(rec_id: str):
    """Internal: watch for new PulseAudio sinks during a recording."""
    from bee.recorder import run_sink_watcher
    run_sink_watcher(rec_id)


@main.command(name="list")
def list_recordings():
    """List all recordings."""
    from bee.recorder import list_recordings as _list_recordings

    recordings = _list_recordings()
    if not recordings:
        console.print("[yellow]No recordings found.[/yellow]")
        return

    table = Table(title="Recordings")
    table.add_column("ID", style="cyan")
    table.add_column("Started", style="green")
    table.add_column("Status", style="yellow")
    table.add_column("Audio")

    for rec in recordings:
        table.add_row(
            rec["id"],
            rec.get("started_at", "?")[:19].replace("T", " "),
            rec.get("status", "?"),
            rec.get("audio_file", "-"),
        )

    console.print(table)


@main.command()
@click.argument("rec_id")
@click.option("--transcript", "-t", is_flag=True, help="Show full transcript")
@click.option("--summary", "-s", is_flag=True, help="Show summary")
def show(rec_id: str, transcript: bool, summary: bool):
    """Show details of a recording."""
    from bee.config import RECORDINGS_DIR
    from bee.pipeline import _resolve_transcript_path

    rec_dir = RECORDINGS_DIR / rec_id
    if not rec_dir.exists():
        console.print(f"[red]Recording not found:[/red] {rec_id}")
        sys.exit(1)

    import json
    meta_file = rec_dir / "metadata.json"
    metadata: dict = {}
    if meta_file.exists():
        metadata = json.loads(meta_file.read_text())
        console.print(Panel(
            "\n".join(f"[bold]{k}:[/bold] {v}" for k, v in metadata.items()),
            title=f"Recording: {rec_id}",
            border_style="cyan",
        ))

    show_all = not transcript and not summary

    if transcript or show_all:
        transcript_file = _resolve_transcript_path(rec_id, metadata, ".md")
        if transcript_file and transcript_file.exists():
            from rich.markdown import Markdown
            console.print(Panel(
                Markdown(transcript_file.read_text(encoding="utf-8")),
                title="Transcript",
                border_style="green",
            ))

    if summary or show_all:
        transcript_file = _resolve_transcript_path(rec_id, metadata, ".md")
        summary_file = (
            transcript_file.with_name(transcript_file.stem + "_summary.md")
            if transcript_file else None
        )
        if summary_file and summary_file.exists():
            from rich.markdown import Markdown
            console.print(Panel(
                Markdown(summary_file.read_text(encoding="utf-8")),
                title="Summary",
                border_style="yellow",
            ))


@main.command()
@click.argument("rec_id")
@click.argument("mappings", nargs=-1, required=True)
def label(rec_id: str, mappings: tuple[str, ...]):
    """Assign real names to speaker labels.

    Example: bee label <rec_id> Speaker_00=Alice Mic_00="Bob (Acme)"

    Run 'bee speakers <rec_id>' first to see who's who.
    """
    from bee.pipeline import label_speakers

    labels = {}
    for m in mappings:
        if "=" not in m:
            console.print(f"[red]Invalid format:[/red] {m} (use Speaker_XX=Name)")
            sys.exit(1)
        key, value = m.split("=", 1)
        labels[key] = value

    console.print(f"Renaming speakers in [cyan]{rec_id}[/cyan]...")
    for old, new in labels.items():
        console.print(f"  {old} -> [green]{new}[/green]")

    result = label_speakers(rec_id, labels)

    console.print(f"\n[green]Transcript updated.[/green]")
    console.print(f"Speakers: {', '.join(result['speakers'])}")


@main.command()
@click.argument("rec_id")
def speakers(rec_id: str):
    """Show a preview of each speaker to help identify them."""
    from bee.pipeline import get_speaker_previews

    previews = get_speaker_previews(rec_id)
    if not previews:
        console.print(f"[yellow]No transcript found for {rec_id}.[/yellow]")
        sys.exit(1)

    console.print(f"\n[bold]Detected participants: {len(previews)}[/bold]\n")

    table = Table(title=f"Speakers — {rec_id}", show_lines=True)
    table.add_column("Speaker", style="cyan", width=14)
    table.add_column("Words", style="yellow", justify="right", width=8)
    table.add_column("Time", style="yellow", justify="right", width=8)
    table.add_column("Representative quotes", style="white")

    for speaker, info in previews.items():
        duration_str = f"{info['duration'] / 60:.1f} min"
        quotes = "\n".join(f'"{q}"' for q in info["quotes"][:3])
        table.add_row(speaker, str(info["word_count"]), duration_str, quotes or "(no substantial speech)")

    console.print(table)
    console.print(f"\nTo label: [bold]bee label {rec_id} Speaker_00=Name Mic_00=\"Name (Company)\"[/bold]")


@main.command()
def watch():
    """Watch the transcripts folder and auto-generate summaries."""
    from bee.watcher import start_watcher
    start_watcher()


@main.command()
def setup():
    """Run the first-time setup wizard."""
    from bee.setup_wizard import run_setup
    run_setup()


@main.command()
def doctor():
    """Check system health and diagnose issues."""
    from bee.doctor import run_doctor
    ok = run_doctor()
    if not ok:
        sys.exit(1)


@main.group()
def models():
    """Manage AI models (download, list, info)."""
    pass


@models.command(name="list")
def models_list():
    """List available and installed models."""
    from bee.models import list_models

    all_models = list_models()
    table = Table(title="Models")
    table.add_column("Model", style="cyan")
    table.add_column("Type")
    table.add_column("Size", justify="right")
    table.add_column("RAM", justify="right")
    table.add_column("Quality")
    table.add_column("Status")

    for name, info in all_models.items():
        status = "[green]installed[/green]" if info["status"] == "installed" else "[dim]available[/dim]"
        size = f"{info.get('size_mb', '?')} MB"
        ram = f"{info.get('ram_mb', '?')} MB"
        quality = info.get("quality", info.get("description", ""))
        table.add_row(name, info["type"], size, ram, quality, status)

    console.print(table)


@models.command(name="download")
@click.argument("model_name")
def models_download(model_name: str):
    """Download a specific model."""
    from bee.models import download_model, get_model_status, WHISPER_MODELS, DIARIZATION_MODELS

    known = {**WHISPER_MODELS, **DIARIZATION_MODELS}
    if model_name not in known:
        console.print(f"[red]Unknown model:[/red] {model_name}")
        console.print(f"Available: {', '.join(known.keys())}")
        sys.exit(1)

    status = get_model_status(model_name)
    if status == "installed":
        console.print(f"[green]Model '{model_name}' is already installed.[/green]")
        return

    console.print(f"Downloading [cyan]{model_name}[/cyan]...")
    from rich.progress import Progress, SpinnerColumn, TextColumn
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as progress:
        task = progress.add_task(f"Downloading {model_name}...", total=None)
        try:
            path = download_model(model_name)
            progress.update(task, description=f"[green]{model_name} ready[/green]")
            console.print(f"\nSaved to: [dim]{path}[/dim]")
        except Exception as e:
            progress.update(task, description=f"[red]Failed[/red]")
            console.print(f"[red]Error:[/red] {e}")
            sys.exit(1)


@models.command(name="usage")
def models_usage():
    """Show disk usage of downloaded models."""
    from bee.models import get_disk_usage

    usage = get_disk_usage()
    if not usage:
        console.print("[yellow]No models downloaded yet.[/yellow]")
        return

    table = Table(title="Model Disk Usage")
    table.add_column("Model", style="cyan")
    table.add_column("Size", justify="right")

    total = 0
    for name, size_bytes in usage.items():
        size_mb = size_bytes / (1024 * 1024)
        total += size_bytes
        table.add_row(name, f"{size_mb:.0f} MB")

    table.add_row("[bold]Total[/bold]", f"[bold]{total / (1024 * 1024):.0f} MB[/bold]")
    console.print(table)


def _print_result(rec_id: str, result: dict):
    json_path = result.get("json_path", "")
    md_path = result.get("md_path", "")

    console.print(Panel(
        f"[green bold]Processing complete![/green bold]\n\n"
        f"Segments: {result['segments']}\n"
        f"Detected participants: {result['speakers']}\n\n"
        f"JSON (LLM): [cyan]{json_path}[/cyan]\n"
        f"Markdown:   [cyan]{md_path}[/cyan]",
        title="Bee",
        border_style="green",
    ))


def _prompt_meeting_name(rec_id: str) -> None:
    """If the recording has no display_name yet and stdin is a TTY, prompt for one."""
    from bee.config import RECORDINGS_DIR
    from bee.pipeline import set_display_name

    rec_dir = RECORDINGS_DIR / rec_id
    meta_file = rec_dir / "metadata.json"
    if not meta_file.exists():
        return

    import json
    metadata = json.loads(meta_file.read_text())
    if metadata.get("display_name"):
        return
    if not sys.stdin.isatty():
        return

    try:
        name = click.prompt(
            "Meeting name (enter to skip and use the default timestamp)",
            default="",
            show_default=False,
        )
    except (click.Abort, EOFError):
        return

    name = name.strip()
    if name:
        set_display_name(rec_id, name)


def _prompt_speaker_count() -> int | None:
    """Ask for the number of participants. Returns None on Enter / non-TTY / invalid."""
    if not sys.stdin.isatty():
        return None
    try:
        raw = click.prompt(
            "How many participants? (enter to auto-detect)",
            default="",
            show_default=False,
        )
    except (click.Abort, EOFError):
        return None
    raw = raw.strip()
    if not raw:
        return None
    try:
        n = int(raw)
    except ValueError:
        console.print("[yellow]Invalid number, falling back to auto-detect.[/yellow]")
        return None
    if n < 1:
        return None
    return n


def _interactive_identify(rec_id: str):
    """Show speakers with context and prompt for real names."""
    from bee.pipeline import get_speaker_previews

    previews = get_speaker_previews(rec_id)
    if not previews:
        return

    console.print(f"\n[bold]Detected participants: {len(previews)}[/bold]\n")

    for speaker, info in previews.items():
        duration_min = info["duration"] / 60
        console.print(
            f"  [cyan bold]{speaker}[/cyan bold] — "
            f"{info['word_count']} words, {duration_min:.1f} min speaking"
        )
        for quote in info["quotes"][:3]:
            console.print(f"    [dim]\"{quote}\"[/dim]")
        console.print()

    if not sys.stdin.isatty():
        console.print(f"To label: [bold]bee label {rec_id} Speaker_00=Name ...[/bold]")
        return

    try:
        if not click.confirm("Identify participants now?", default=True):
            console.print(f"\nLabel later with: [bold]bee label {rec_id} Speaker_00=Name[/bold]")
            return
    except (click.Abort, EOFError):
        console.print(f"\nLabel later with: [bold]bee label {rec_id} Speaker_00=Name[/bold]")
        return

    console.print()
    labels = {}
    for speaker in previews:
        try:
            name = click.prompt(f"  {speaker} -> Name (enter to skip)", default="", show_default=False)
            if not name:
                continue
            company = click.prompt(f"  {speaker} -> Company (enter to skip)", default="", show_default=False)
            display = f"{name} ({company})" if company else name
            labels[speaker] = display
        except (click.Abort, EOFError):
            break

    if labels:
        from bee.pipeline import label_speakers
        result = label_speakers(rec_id, labels)
        console.print(f"\n[green]Participants labeled:[/green] {', '.join(result['speakers'])}")
        console.print(f"Transcript updated at [cyan]{result['md_path']}[/cyan]")
    else:
        console.print(f"\nLabel later with: [bold]bee label {rec_id} Speaker_00=Name[/bold]")
