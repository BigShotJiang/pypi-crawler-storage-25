"""Speaker diarization using SpeechBrain ECAPA-TDNN (local, no HF token required)."""

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from bee.config import MODELS_DIR
from bee.transcriber import Segment

_encoder = None
_vad_model = None
_SPEECHBRAIN_DIR = MODELS_DIR / "speechbrain-ecapa"


@dataclass
class DiarizedSegment:
    start: float
    end: float
    speaker: str
    text: str


def _get_encoder():
    global _encoder
    if _encoder is None:
        import torch
        from speechbrain.inference.speaker import EncoderClassifier

        device = "cuda" if torch.cuda.is_available() else "cpu"
        _SPEECHBRAIN_DIR.mkdir(parents=True, exist_ok=True)
        _encoder = EncoderClassifier.from_hparams(
            source="speechbrain/spkrec-ecapa-voxceleb",
            savedir=str(_SPEECHBRAIN_DIR),
            run_opts={"device": device},
        )
    return _encoder


def _get_vad():
    """Lazy-load Silero VAD (local ONNX model, no HuggingFace token required)."""
    global _vad_model
    if _vad_model is None:
        from silero_vad import load_silero_vad
        _vad_model = load_silero_vad()
    return _vad_model


def _silero_speech_segments(
    signal,
    fs: int,
    min_speech_ms: int = 400,
    min_silence_ms: int = 300,
) -> list[tuple[float, float]]:
    """Use Silero VAD to find speech regions. Returns list of (start_s, end_s)."""
    from silero_vad import get_speech_timestamps

    model = _get_vad()
    audio = signal.squeeze(0) if signal.dim() > 1 else signal
    ts = get_speech_timestamps(
        audio,
        model,
        sampling_rate=fs,
        min_speech_duration_ms=min_speech_ms,
        min_silence_duration_ms=min_silence_ms,
        return_seconds=True,
    )
    return [(s["start"], s["end"]) for s in ts]


def diarize(
    audio_path: Path,
    num_speakers: int | None = None,
    window_seconds: float = 2.5,
    hop_seconds: float = 1.25,
    label_prefix: str = "Speaker",
) -> list[tuple[float, float, str]]:
    """Identify who spoke in each portion of the audio.

    Pipeline: Silero VAD -> ECAPA-TDNN embeddings -> agglomerative clustering with
    centroid merge.
    """
    import soundfile as sf
    import torch
    import torchaudio.functional as TF

    encoder = _get_encoder()

    data, fs = sf.read(str(audio_path), dtype="float32", always_2d=True)
    signal = torch.from_numpy(data.T)
    if fs != 16000:
        signal = TF.resample(signal, fs, 16000)
        fs = 16000
    if signal.shape[0] > 1:
        signal = signal.mean(dim=0, keepdim=True)

    duration = signal.shape[1] / fs
    if duration < 1.0:
        return [(0.0, duration, f"{label_prefix}_00")]

    speech_regions = _silero_speech_segments(signal, fs)
    if not speech_regions:
        return [(0.0, duration, f"{label_prefix}_00")]

    window = int(window_seconds * fs)
    hop = int(hop_seconds * fs)
    min_window = int(0.8 * fs)
    chunk_target_s = 5.0
    chunk_max_s = 8.0

    bounds: list[tuple[float, float]] = []
    embeddings: list[np.ndarray] = []

    def _avg_embedding(start_sample: int, end_sample: int) -> np.ndarray | None:
        sub_len = end_sample - start_sample
        if sub_len < min_window:
            return None
        if sub_len <= window:
            chunk = signal[:, start_sample:end_sample]
            with torch.no_grad():
                return encoder.encode_batch(chunk).squeeze().cpu().numpy()
        partials = []
        for pos in range(start_sample, end_sample - window + 1, hop):
            chunk = signal[:, pos : pos + window]
            with torch.no_grad():
                partials.append(encoder.encode_batch(chunk).squeeze().cpu().numpy())
        if not partials:
            return None
        return np.mean(partials, axis=0)

    for region_start_s, region_end_s in speech_regions:
        region_len_s = region_end_s - region_start_s
        if region_len_s < 0.8:
            continue

        if region_len_s <= chunk_max_s:
            sub_regions = [(region_start_s, region_end_s)]
        else:
            sub_count = max(1, round(region_len_s / chunk_target_s))
            step = region_len_s / sub_count
            sub_regions = [
                (region_start_s + i * step, region_start_s + (i + 1) * step)
                for i in range(sub_count)
            ]

        for sub_start_s, sub_end_s in sub_regions:
            sub_start = int(sub_start_s * fs)
            sub_end = min(int(sub_end_s * fs), signal.shape[1])
            emb = _avg_embedding(sub_start, sub_end)
            if emb is None:
                continue
            bounds.append((sub_start / fs, sub_end / fs))
            embeddings.append(emb)

    if not embeddings:
        return [(0.0, duration, f"{label_prefix}_00")]
    if len(embeddings) == 1:
        return [(bounds[0][0], bounds[0][1], f"{label_prefix}_00")]

    matrix = np.array(embeddings)
    matrix = matrix / (np.linalg.norm(matrix, axis=1, keepdims=True) + 1e-9)

    if num_speakers is None and _is_single_speaker(matrix):
        labels = np.zeros(len(embeddings), dtype=int)
    else:
        labels = _cluster(matrix, num_speakers)
        if num_speakers is None:
            labels = _merge_close_centroids(matrix, labels, threshold=0.32)
            labels = _absorb_small_clusters(matrix, labels)

    raw = [(bounds[i][0], bounds[i][1], int(labels[i])) for i in range(len(bounds))]
    merged = _merge_consecutive(raw, label_prefix)
    return _normalize_speaker_labels(merged, label_prefix)


def _is_single_speaker(embeddings: np.ndarray, p90_threshold: float = 0.45) -> bool:
    """Check whether all embeddings come from one speaker.

    Computes the cosine distance from each embedding to the global centroid;
    if 90% of points sit within `p90_threshold` of the centroid, treat the
    audio as a single speaker. Catches the failure mode where ECAPA emits
    drifting embeddings for the same person over a long recording.
    """
    if len(embeddings) < 2:
        return True
    centroid = embeddings.mean(axis=0)
    norm = np.linalg.norm(centroid)
    if norm == 0:
        return True
    centroid = centroid / norm
    distances = 1.0 - embeddings @ centroid
    return float(np.percentile(distances, 90)) < p90_threshold


def _cluster(embeddings: np.ndarray, num_speakers: int | None) -> np.ndarray:
    from sklearn.cluster import AgglomerativeClustering

    n = len(embeddings)

    if num_speakers is not None:
        if num_speakers <= 1:
            return np.zeros(n, dtype=int)
        return AgglomerativeClustering(
            n_clusters=min(num_speakers, n),
            metric="cosine",
            linkage="average",
        ).fit(embeddings).labels_

    if n < 4:
        return np.zeros(n, dtype=int)

    from sklearn.metrics import silhouette_score

    best_score = -float("inf")
    best_labels = np.zeros(n, dtype=int)
    max_k = min(6, n - 1)
    parsimony_penalty = 0.05

    for k in range(2, max_k + 1):
        try:
            labels = AgglomerativeClustering(
                n_clusters=k,
                metric="cosine",
                linkage="average",
            ).fit(embeddings).labels_
            silhouette = silhouette_score(embeddings, labels, metric="cosine")
            adjusted = silhouette - parsimony_penalty * (k - 2)
            if adjusted > best_score:
                best_score = adjusted
                best_labels = labels
        except Exception:
            continue

    if best_score < 0.05:
        return np.zeros(n, dtype=int)
    return best_labels


def _absorb_small_clusters(
    embeddings: np.ndarray,
    labels: np.ndarray,
    min_fraction: float = 0.06,
    min_count: int = 3,
) -> np.ndarray:
    """Reassign points from clusters smaller than the threshold to their nearest surviving cluster.

    Catches the failure where a handful of noisy/echo windows form a fake "speaker"
    that's actually just channel artifacts on the same person's voice.
    """
    total = len(labels)
    if total == 0:
        return labels

    counts: dict[int, int] = {}
    for l in labels:
        counts[int(l)] = counts.get(int(l), 0) + 1

    floor = max(min_count, int(min_fraction * total))
    big = {c for c, n in counts.items() if n >= floor}

    if not big:
        return labels
    if len(big) == len(counts):
        return labels

    centroids = {}
    for c in big:
        mask = labels == c
        cent = embeddings[mask].mean(axis=0)
        norm = np.linalg.norm(cent)
        centroids[c] = cent / norm if norm > 0 else cent

    new_labels = labels.copy()
    for i, l in enumerate(labels):
        if int(l) in big:
            continue
        best = None
        best_sim = -float("inf")
        for c, cent in centroids.items():
            sim = float(embeddings[i] @ cent)
            if sim > best_sim:
                best_sim = sim
                best = c
        new_labels[i] = best

    return new_labels


def _merge_close_centroids(
    embeddings: np.ndarray,
    labels: np.ndarray,
    threshold: float = 0.25,
) -> np.ndarray:
    """Merge clusters whose centroids are within `threshold` cosine distance.

    Catches the common failure where one speaker gets split across two clusters
    due to varying volume, channel changes, or laughter/emphasis distortion.
    """
    unique = sorted(set(int(l) for l in labels))
    if len(unique) <= 1:
        return labels

    centroids = {}
    for c in unique:
        mask = labels == c
        cent = embeddings[mask].mean(axis=0)
        norm = np.linalg.norm(cent)
        if norm > 0:
            cent = cent / norm
        centroids[c] = cent

    parent = {c: c for c in unique}

    def find(c):
        while parent[c] != c:
            parent[c] = parent[parent[c]]
            c = parent[c]
        return c

    for i, a in enumerate(unique):
        for b in unique[i + 1 :]:
            dist = 1.0 - float(np.dot(centroids[a], centroids[b]))
            if dist < threshold:
                ra, rb = find(a), find(b)
                if ra != rb:
                    parent[rb] = ra

    return np.array([find(int(l)) for l in labels])


def _merge_consecutive(
    segments: list[tuple[float, float, int]],
    label_prefix: str,
    gap_tolerance: float = 0.75,
) -> list[tuple[float, float, str]]:
    if not segments:
        return []
    result = []
    cur_start, cur_end, cur_label = segments[0]
    for start, end, label in segments[1:]:
        if label == cur_label and start <= cur_end + gap_tolerance:
            cur_end = max(cur_end, end)
        else:
            result.append((cur_start, cur_end, f"{label_prefix}_{cur_label:02d}"))
            cur_start, cur_end, cur_label = start, end, label
    result.append((cur_start, cur_end, f"{label_prefix}_{cur_label:02d}"))
    return result


def _normalize_speaker_labels(
    segments: list[tuple[float, float, str]],
    label_prefix: str = "Speaker",
) -> list[tuple[float, float, str]]:
    label_map: dict[str, str] = {}
    counter = 0
    for _, _, speaker in segments:
        if speaker not in label_map:
            label_map[speaker] = f"{label_prefix}_{counter:02d}"
            counter += 1
    return [(start, end, label_map[speaker]) for start, end, speaker in segments]


def merge_transcription_with_diarization(
    transcript_segments: list[Segment],
    speaker_segments: list[tuple[float, float, str]],
) -> list[DiarizedSegment]:
    result = []
    for seg in transcript_segments:
        seg_mid = (seg.start + seg.end) / 2
        speaker = _find_speaker_at(seg_mid, speaker_segments)
        result.append(DiarizedSegment(
            start=seg.start,
            end=seg.end,
            speaker=speaker,
            text=seg.text,
        ))
    return result


def _find_speaker_at(
    timestamp: float,
    speaker_segments: list[tuple[float, float, str]],
    fallback: str = "Speaker_00",
) -> str:
    best_speaker = fallback
    best_dist = float("inf")
    for start, end, speaker in speaker_segments:
        if start <= timestamp <= end:
            return speaker
        dist = min(abs(timestamp - start), abs(timestamp - end))
        if dist < best_dist:
            best_dist = dist
            best_speaker = speaker
    return best_speaker
