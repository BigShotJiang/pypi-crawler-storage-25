"""Read hook helpers."""
from __future__ import annotations

from pathlib import Path
from typing import Any

from . import session
from .hooks_common import (
    CONTINUE,
    HookResponse,
    get_tool_input,
    pre_tool_use_with_context,
    pre_tool_use_with_update,
)  # noqa: E402
from .hooks_common import (
    LOG as _LOG,
)


def _handle_bash_read_equivalent(payload: dict[str, Any]) -> HookResponse | None:
    """Convert Bash read-equivalent commands to Read payload for recursive processing.

    Intercepts Bash tool invocations with read-like commands (cat, head, tail, bat, etc.)
    and synthesizes an equivalent Read tool payload so that image shrinking and session-hint
    logic apply identically to Bash-based reads as they do to direct Read calls.

    Args:
        payload: Hook payload dict with tool_name='Bash' and tool_input containing 'command'.

    Returns:
        A new payload dict with tool_name='Read' and adjusted tool_input (file_path, offset, limit),
        or None if the command is not recognized as a read-equivalent or parsing fails.
    """
    from . import bash_parser  # noqa: PLC0415

    tool_input = get_tool_input(payload)
    cmd = tool_input.get("command", "")
    intent = bash_parser.parse(cmd)
    if intent.kind != "read" or not intent.target_path:
        if intent.reason:
            _LOG.info("bash read near-miss: %s", intent.reason)
        return None

    read_payload = dict(payload)
    read_payload["tool_name"] = "Read"
    read_payload["tool_input"] = {
        "file_path": intent.target_path,
        "offset": intent.offset,
        "limit": intent.limit,
    }
    return read_payload


def _try_shrink_image(
    file_path: str, tool_input: dict[str, Any]
) -> HookResponse | None:
    """Attempt image shrinking and return hook-formatted response if successful.

    Compresses image files (PNG, JPEG, WebP, etc.) using cached shrinking, records
    token/byte savings to the stats DB, and returns a hook response that redirects
    the Read call to the shrunk copy. Non-image files are silently passed through as None.

    Args:
        file_path: Absolute or relative path to a file being read.
        tool_input: Read tool input dict (will be copied and file_path updated if
            shrinking succeeds).

    Returns:
        A hook response dict with updated file_path pointing to the shrunk image, or None if:
        - file_path is not an image file
        - shrinking returns None (already optimal, no temp space, etc.)
        - shrinking or stats recording raises an exception (logged but not re-raised)
    """
    from . import db, image_shrink  # noqa: PLC0415

    if not image_shrink.is_image_path(file_path):
        return None

    try:
        shrunken = image_shrink.shrink(Path(file_path))
        if shrunken is None:
            return None

        img_stats = image_shrink.stats_for(Path(file_path), shrunken)
        tokens_saved = max(0,
            image_shrink.vision_tokens(img_stats["orig_width"], img_stats["orig_height"])
            - image_shrink.vision_tokens(img_stats["out_width"], img_stats["out_height"])
        )
        db.record_stat(
            None,
            "image_shrink",
            bytes_saved=img_stats["bytes_saved"],
            tokens_saved=tokens_saved,
            detail=f"{file_path} -> {shrunken.name}",
        )

        shrink_response = dict(tool_input)
        shrink_response["file_path"] = str(shrunken)
        return pre_tool_use_with_update(
            shrink_response,
            (
                f"Note: image auto-shrunk by token-goat "
                f"({img_stats['src_bytes']:,} → {img_stats['out_bytes']:,} bytes, "
                f"~{img_stats['bytes_saved']:,} bytes saved). "
                f"Original: {file_path}"
            ),
        )
    except Exception:  # noqa: BLE001
        _LOG.exception("image-shrink failed during pre-read")
        return None


def _record_session_hint_impact(file_path: str, hint: str) -> None:
    """Record net impact of session hints: avoided re-reads minus injection overhead.

    Session hints warn the user about file content already in context, enabling them to
    skip redundant reads. This function records both the gross tokens/bytes saved
    (realized when user avoids the re-read) and the injection cost (the hint text itself).
    Net impact = savings - overhead.

    Args:
        file_path: Path of the file being read (recorded in stats detail).
        hint: ReadHint string instance with .tokens_saved attribute set.
    """
    from . import db  # noqa: PLC0415
    from .hints import CHARS_PER_TOKEN  # noqa: PLC0415

    realized_tokens = getattr(hint, "tokens_saved", 0)
    injection_cost_tokens = max(1, int(len(hint) / CHARS_PER_TOKEN))
    realized_bytes = realized_tokens * 4  # project convention: ~4 bytes/token
    injection_bytes = len(hint)

    db.record_stat(
        None,
        "session_hint",
        bytes_saved=realized_bytes,
        tokens_saved=realized_tokens,
        detail=file_path,
    )
    db.record_stat(
        None,
        "session_hint_overhead",
        bytes_saved=-injection_bytes,
        tokens_saved=-injection_cost_tokens,
        detail=file_path,
    )


def pre_read(payload: dict[str, Any]) -> HookResponse:
    """Pre-read hook: image shrinking and session-cache hints.

    Dispatches based on tool_name:
    - Bash: Convert read-equivalent commands (cat, head, etc.) to Read, then recurse.
    - Read: Attempt image shrinking, then emit session hints (if cached or large-file candidate).
    - Other: Pass through unchanged (CONTINUE).

    Returns hook response dict with optional updatedInput (image shrinking) or
    additionalContext (hint text).
    """
    from .hints import build_read_hint  # noqa: PLC0415

    tool_name = payload.get("tool_name")

    if tool_name == "Bash":
        read_payload = _handle_bash_read_equivalent(payload)
        if read_payload:
            return pre_read(read_payload)
        return CONTINUE()

    if tool_name != "Read":
        return CONTINUE()

    tool_input = get_tool_input(payload)
    file_path = tool_input.get("file_path")
    if not file_path:
        return CONTINUE()

    session_id = payload.get("session_id")
    cwd = payload.get("cwd")

    shrink_response = _try_shrink_image(file_path, tool_input)
    if shrink_response:
        return shrink_response

    cache = session.load(session_id) if session_id else None

    hint = build_read_hint(
        session_id=session_id,
        file_path=file_path,
        offset=tool_input.get("offset"),
        limit=tool_input.get("limit"),
        cwd=cwd,
        cache=cache,
    )
    if not hint:
        return CONTINUE()

    if hint.tokens_saved > 0:
        _record_session_hint_impact(file_path, hint)

    return pre_tool_use_with_context(str(hint))


def post_read(payload: dict[str, Any]) -> HookResponse:
    """Post-read hook: record file/symbol accesses to session cache.

    Logs Read, Grep, and Glob operations into the persistent session cache so that
    subsequent reads can detect overlaps and re-read attempts, enabling session hints
    on follow-up file accesses in the same session.

    Returns CONTINUE() after recording; never modifies tool input/output.
    """
    session_id = payload.get("session_id")
    if not session_id:
        return CONTINUE()

    cache = session.load(session_id)

    tool_name = payload.get("tool_name")
    tool_input = get_tool_input(payload)

    if tool_name == "Read":
        file_path = tool_input.get("file_path")
        if file_path:
            offset = tool_input.get("offset")
            limit = tool_input.get("limit")
            session.mark_file_read(session_id, file_path, offset, limit, cache=cache)
    elif tool_name == "Grep":
        pattern = tool_input.get("pattern")
        path = tool_input.get("path")
        result_count = payload.get("result_count")
        if pattern:
            session.mark_grep(session_id, pattern, path, result_count, cache=cache)
    elif tool_name == "Glob":
        pattern = tool_input.get("pattern")
        path = tool_input.get("path")
        # Sanitize user-controlled strings before logging to prevent log injection
        # via embedded newlines that would forge additional log records.
        safe_pattern = str(pattern).replace("\n", "\\n").replace("\r", "\\r") if pattern is not None else None
        safe_path = str(path).replace("\n", "\\n").replace("\r", "\\r") if path is not None else None
        _LOG.debug("post-read: Glob pattern=%s path=%s", safe_pattern, safe_path)

    return CONTINUE()
