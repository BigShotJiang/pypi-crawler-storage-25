---
name: tdstone2-hypermodel
description: Use when the user wants to train one scikit-learn pipeline per data partition (hyper-segmented model) inside Teradata Vantage with tdstone2 — classifier, regressor, or anomaly detection. Covers HyperModel construction from skl_pipeline_steps, train/score, retrieving predictions, and reloading by UUID. Does NOT cover ONNX export (see tdstone2-byom-onnx) or custom non-sklearn code (see tdstone2-custom-script).
---

# tdstone2 — HyperModel (sklearn)

A `HyperModel` is the sklearn-focused orchestrator. It auto-generates a per-partition training script from a list of `(name, estimator)` tuples and runs `model.fit()` independently on each partition's AMP.

## Prerequisite

`TDStone.setup()` must have been called once on this schema. See skill `tdstone2-setup`.

## Standard workflow

```python
import teradataml as tdml
from tdstone2.tdstone import TDStone
from tdstone2.tdshypermodel import HyperModel
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier

tdml.create_context(**Param)
sto = TDStone(schema_name=Param['database'], SEARCHUIFDBPATH=Param['user'])

steps = [
    ('scaler', StandardScaler()),
    ('clf',    RandomForestClassifier(max_depth=5, n_estimators=95)),
]

model = HyperModel(
    tdstone            = sto,
    metadata           = {'project': 'churn-fy26', 'owner': 'denis'},
    skl_pipeline_steps = steps,
    model_parameters   = {
        'target'            : 'Y2',
        'column_categorical': ['flag', 'Y2'],
        'column_names_X'    : ['X1', 'X2', ..., 'X9', 'flag'],
    },
    dataset            = tdml.in_schema(Param['database'], 'dataset_00'),
    id_row             = 'ID',
    id_partition       = 'Partition_ID',   # one model per unique value
    id_fold            = 'FOLD',
    fold_training      = 'train',
    convert_to_onnx    = False,
    store_pickle       = True,
)

model.train()
model.score()

preds  = model.get_model_predictions()              # denormalized (pivoted) view
preds_raw = model.get_model_predictions(denormalized_view=False)
models = model.get_trained_models()
```

## Auto-detection of pipeline type

`model_maker/scikit_learn.py` inspects the **last** estimator:

| Last estimator type        | Generated template       | Detection                         |
|----------------------------|--------------------------|-----------------------------------|
| `ClassifierMixin`          | classification template  | `sklearn.base.is_classifier()`    |
| `RegressorMixin`           | regression template      | `sklearn.base.is_regressor()`     |
| `OutlierMixin` (or other)  | anomaly-detection template | neither classifier nor regressor |

Templates compute appropriate metrics (f1/precision/recall/ROC-AUC for classification, MAE/MSE/RMSE/R² for regression) and emit `<target>_prediction` plus per-class `<target>_proba_<class>` columns.

## Required parameters

| Param                     | Purpose                                                                            |
|---------------------------|-------------------------------------------------------------------------------------|
| `tdstone`                 | `TDStone` instance                                                                  |
| `skl_pipeline_steps`      | List of `(name, estimator)` for sklearn `Pipeline`                                 |
| `model_parameters['target']`            | Target column name                                                |
| `model_parameters['column_names_X']`    | Feature column names (list)                                       |
| `model_parameters['column_categorical']`| Categorical columns (cast to pandas Categorical inside the script) |
| `dataset`                 | `tdml.in_schema(db, table)` or a table-name string                                 |
| `id_row`                  | Row identifier column                                                              |
| `id_partition`            | Partition column (one model per unique value); can be a comma-separated string     |
| `id_fold`, `fold_training`| Optional fold column + value identifying the training rows                        |

## Useful tricks

- **Inspect the generated SQL** before running:
  ```python
  print(model.mapper_training.generate_sto_query())
  print(model.mapper_scoring.generate_sto_query())
  ```
- **Inspect the generated Python code** (the BLOB stored in `TDS_CODE_REPOSITORY`):
  ```python
  sto.list_codes()    # find the most recent UUID
  # then SELECT CODE FROM TDS_CODE_REPOSITORY WHERE ID = '<uuid>'
  ```
- **Reload an existing HyperModel** by UUID — no retraining, no data movement:
  ```python
  existing = HyperModel(tdstone=sto)
  existing.download(id='0286d259-ecde-4cd0-ae4a-bcb3191383d1')
  existing.score()
  ```

## Caveats

- **Per-AMP libsvm safety**: `_preflight_fit` refuses to fit libsvm-backed estimators (`SVC`, `OneClassSVM` with rbf kernel) on >15 000 rows per partition — the O(n²) Gram matrix can segfault the AMP container.
- **`column_categorical` must include the target** when the target itself is categorical (it's used during `prepare_y`).
- **Pipeline serialisation is by source, not pickle.** The client only needs sklearn to construct estimators; training runs server-side with the server's sklearn.

## To export to ONNX for SQL-native inference

Set `convert_to_onnx=True` and continue with skill `tdstone2-byom-onnx`.
