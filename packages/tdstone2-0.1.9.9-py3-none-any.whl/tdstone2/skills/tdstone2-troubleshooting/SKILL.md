---
name: tdstone2-troubleshooting
description: Use when the user encounters errors or unexpected behaviour while running tdstone2 on Teradata Vantage — Apply / OAF / OFS / QueryBand failures (Error 6881, 3802, 9352, 4839, 3706), CLOB or VARCHAR truncation issues, ONNXPredict failures, slow scoring joins, hung embeddings, or missing in-database scripts after install.
---

# tdstone2 — Troubleshooting

A field guide to errors the framework produces or surfaces from Teradata. Match the symptom in the left column.

## Apply / OFS / VCL errors

| Symptom                                                          | Cause                                                                                          | Fix                                                                                                            |
|------------------------------------------------------------------|------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|
| **Error 6881** "Apply step is not eligible for ACC"              | A `CLOB` column on the on-clause view makes Apply ineligible for the Analytical Compute Cluster. | tdstone2 already chunks models as `VARCHAR(64000)` on VCL; check you're on a recent tdstone2 version. Confirm `MODEL_CHUNK_TOTAL > 1` in the trained-model table for large models. |
| **Error 6881 after a long wait**                                 | On VCL1, the user's compute group (`CG_BusGrpA_ANL` by default for `data_scientist`) auto-hibernated 01:33–09:00 UTC. Apply queued for ~1h then failed. | Set `QUERY_BAND = 'compute=<wakeful_group>;'` or run during waking hours.                                       |
| **Error 3802** "Database '…' does not exist" on `INSERT … SELECT FROM Apply(…)` | Pooled `teradataml` connection inherits a QueryBand that routes to the wrong compute against OFS targets. | tdstone2 uses a fresh `teradatasql.connect` cursor for Apply inserts (`utils._get_apply_conn`). If still failing, upgrade tdstone2.            |
| **Error 9352 / 3706** on repository DDL                          | OFS rejects temporal DDL (`PERIOD FOR ValidPeriod AS VALIDTIME`).                              | tdstone2 strips the temporal block on VCL automatically. If a hand-edited DDL still has it, drop the `VALIDTIME` clause and use `CREATION_DATE` only. |
| **Error 4839** when creating secondary index on OFS table        | OFS rejects NUSI.                                                                              | tdstone2 skips NUSI creation when `use_apply=True`. Don't re-add manually.                                     |
| **Apply scoring "Invalid Column Reference"**                     | `RETURNS()` column order mismatch.                                                             | Apply requires exact column order. Check `Mapper._generate_apply_query()` output via `print(mp.generate_sto_query())`. |
| **`getpwuid` crash in OAF container**                            | `transformers < 5` on OFS-backed containers.                                                   | Pin `transformers >= 5` in the OAF env.                                                                         |

## ONNX / BYOM errors

| Symptom                                                          | Cause                                                                                          | Fix                                                                                                            |
|------------------------------------------------------------------|------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|
| **ONNXPredict: "Invalid Client Locator"**                        | `skl2onnx` auto-picked `ai.onnx.ml` v4. `TRAINED_MODEL` BLOB is NULL.                          | Re-train with current tdstone2 — the opset is pinned to `{'': 12, 'ai.onnx.ml': 3}` in `tds_training.py`.       |
| **`TRAINED_MODEL` is NULL for some partitions, MODEL_TYPE=onnx** | sklearn estimator has no ONNX converter (e.g. unusual ensembling).                              | Check `STATUS` column for the failed partitions. Either remove the unsupported step or fall back to the pickle scoring path. |
| **ONNXPredict returns wrong shape**                              | Model trained on different feature columns than supplied to `ONNXPredict ON input_data`.       | Verify `Accumulate` and `ModelOutputFields` match `column_names_X` of the Model row.                            |

## Pickle / VARCHAR / CLOB

| Symptom                                                          | Cause                                                                                          | Fix                                                                                                            |
|------------------------------------------------------------------|------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|
| **Error 5764 / 7909** on `TRIM` or numeric cast                  | LOB cannot be cast or trimmed in SQL.                                                          | Cast through `CAST(... AS VARCHAR(64000))` first; or use the companion `V_…_PICKLE` view which handles reassembly. |
| **VARCHAR truncation in spool**                                  | Teradata reserves nominal width per VARCHAR; many large VARCHARs blow up spool.                | Reduce concurrent columns, or split the trained-model into smaller chunks (already done by tdstone2). |

## Scoring is slow

| Symptom                                                          | Cause                                                                                          | Fix                                                                                                            |
|------------------------------------------------------------------|------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|
| **Scoring SQL spool > 100 GB or hangs**                          | Missing stats on the trained-model table cause product joins.                                  | Recent tdstone2 calls `COLLECT STATISTICS` after each train. Otherwise run manually:`COLLECT STATISTICS COLUMN(ID_TRAINED_MODEL, <partition_cols>) ON <trained_model_table>;` Typical 3–5× spool reduction. |
| **Scoring pipe rate low (Apply)**                                | Input PACK adds GROUP BY cost > per-row savings. The working baseline is `pack=1`.            | Don't try input-side PACK on VCL Apply. Tune via partition co-location (`PI(Partition_ID)` on dataset).         |
| **Cross-cluster redistribute on OFS**                            | Dataset PI and trained-model PI differ.                                                        | Align primary indices.                                                                                          |

## Setup / install issues

| Symptom                                                          | Cause                                                                                          | Fix                                                                                                            |
|------------------------------------------------------------------|------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|
| **`tdpython3 ./db/tds_training.py: No such file`**               | VCE: `SEARCHUIFDBPATH` mismatch — script installed under a different DB than what STO searches. | Re-run `TDStone(SEARCHUIFDBPATH=...).setup()` with the correct DB.                                              |
| **OAF install times out, then `status(claim_id)` says PENDING**  | Cluster busy or async upload long.                                                             | tdstone2 already retries; otherwise increase retry count, or install during off-peak.                          |
| **Repository tables already exist, `setup()` errors**            | The `@execute_query` decorator swallows DDL errors; tables remain.                              | Check `sto.list_codes()` etc. — if the tables work, ignore the warning. Otherwise drop and re-`setup()`.        |

## HyperModel construction / training failures

| Symptom | Cause | Fix |
|---------|-------|-----|
| **`AttributeError: 'NoneType' object has no attribute 'id'`** at `model.train()` | `mapper_training` is `None` because `fold_training` was not passed to `HyperModel`. Without this param the entire mapper construction block is silently skipped. | Always pass both `id_fold='<fold_column>'` and `fold_training='<train_value>'`. If your data has no real fold, add a constant column to the training view: `'train' AS fold_col`, then set `id_fold='fold_col', fold_training='train'`. |
| **`Teradata error: SELECT * must have a FROM clause`** on `REPLACE VIEW … AS SELECT *, 'train' AS fold_col` | Teradata's parser rejects `SELECT *` alongside extra expressions in a view body. | Enumerate every column explicitly in the `REPLACE VIEW` — no `SELECT *` with extra columns. |

## Notebooks: "object is not subscriptable" / "no attribute"

Common when running with the wrong Python interpreter. On Windows, always use `.venv\Scripts\python.exe` for tdstone2 work — `.venv311` and system Python may lack `teradataml`.

## Last resort: inspect the generated SQL

Almost every problem above shows up in the generated query first. Before complaining:

```python
print(model.mapper_training.generate_sto_query())
print(model.mapper_scoring.generate_sto_query())
```

Run the printed query inside a SQL client (`EXPLAIN <query>`) to see plan + warnings.
