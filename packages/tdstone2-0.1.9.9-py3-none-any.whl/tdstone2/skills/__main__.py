"""
CLI entry point: ``python -m tdstone2.skills <command> [args]``.

Commands
--------
    list                                  Show bundled skill names.
    show <name>                           Print one skill's markdown to stdout.
    export <target_dir> [--overwrite]     Copy all bundled skills into target_dir.
                                           --overwrite : replace existing files
                                           --dry-run   : report without writing
                                           --only NAME : (repeatable) restrict to specific skills
    install [--global] [--overwrite]      Install skills into Claude Code's skills dir.
                                           default: project-local .claude/skills/
                                           --global    : user-wide ~/.claude/skills/
                                           --overwrite : replace existing files
                                           --dry-run   : report without writing
                                           --only NAME : (repeatable) restrict to specific skills
"""

from __future__ import annotations

import argparse
import sys

from . import export_skills, get_skill, install_skills, list_skills


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="python -m tdstone2.skills",
        description="Manage tdstone2 bundled agent skills.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("list", help="List bundled skill names.")

    p_show = sub.add_parser("show", help="Print a skill's markdown.")
    p_show.add_argument("name")

    p_export = sub.add_parser("export", help="Copy bundled skills to a target directory.")
    p_export.add_argument("target_dir", help="e.g. ~/.claude/skills or .claude/skills")
    p_export.add_argument("--overwrite", action="store_true", help="Replace existing files.")
    p_export.add_argument("--dry-run", action="store_true", help="Report what would be copied.")
    p_export.add_argument(
        "--only", action="append", default=None,
        help="Restrict to a specific skill name (repeatable).",
    )

    p_install = sub.add_parser(
        "install",
        help="Install skills into Claude Code's skills directory.",
    )
    p_install.add_argument(
        "--global", dest="global_scope", action="store_true",
        help="Install user-wide into ~/.claude/skills (default: project-local .claude/skills).",
    )
    p_install.add_argument("--overwrite", action="store_true", help="Replace existing files.")
    p_install.add_argument("--dry-run", action="store_true", help="Report what would be copied.")
    p_install.add_argument(
        "--only", action="append", default=None,
        help="Restrict to a specific skill name (repeatable).",
    )

    return p


def main(argv: list[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)

    if args.cmd == "list":
        for name in list_skills():
            print(name)
        return 0

    if args.cmd == "show":
        try:
            sys.stdout.write(get_skill(args.name))
        except FileNotFoundError as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1
        return 0

    if args.cmd == "export":
        try:
            export_skills(
                args.target_dir,
                overwrite=args.overwrite,
                names=args.only,
                dry_run=args.dry_run,
            )
        except (FileNotFoundError, ValueError) as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1
        return 0

    if args.cmd == "install":
        try:
            install_skills(
                scope="global" if args.global_scope else "local",
                overwrite=args.overwrite,
                names=args.only,
                dry_run=args.dry_run,
            )
        except (FileNotFoundError, ValueError) as exc:
            print(f"Error: {exc}", file=sys.stderr)
            return 1
        return 0

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
