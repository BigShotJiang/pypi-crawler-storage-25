---
name: tdstone2-setup
description: Use when the user is initialising tdstone2 for the first time on a Teradata Vantage system, choosing between Vantage Enterprise (VCE / STO) and Vantage Cloud Lake (VCL / Apply / OAF), wiring up a connection, calling TDStone.setup(), or troubleshooting why repository tables / installed scripts are missing.
---

# tdstone2 — setup

## Decide the backend first

| Environment | Constructor                                                                              | Backend       | Storage          |
|-------------|------------------------------------------------------------------------------------------|---------------|------------------|
| **VCE** (on-prem / cloud Vantage Enterprise) | `TDStone(schema_name=..., SEARCHUIFDBPATH=...)`                                          | STO (Script)  | Block + VALIDTIME |
| **VCL — legacy Script-on-Lake**             | `TDStone(schema_name=..., oaf_env='<env_name>')`                                         | STO via OAF   | OFS              |
| **VCL — Apply (recommended on Lake)**       | `TDStone(schema_name=..., use_apply=True, apply_env_name='tdstone2_sklearn')`            | Apply / OAF   | OFS              |

If the user is on Cloud Lake and unsure, default to `use_apply=True`. It is the actively maintained VCL path.

## Standard setup

```python
import teradataml as tdml
from tdstone2.tdstone import TDStone

tdml.create_context(**Param)   # standard teradataml connection

# VCE
sto = TDStone(
    schema_name      = Param['database'],
    SEARCHUIFDBPATH  = Param['user'],
)

# VCL Apply
# sto = TDStone(
#     schema_name     = Param['database'],
#     use_apply       = True,
#     apply_env_name  = 'tdstone2_sklearn',
# )

sto.setup()
```

`setup()` does two things, both one-time-per-schema:

1. **Creates the six repository tables** (`TDS_CODE_REPOSITORY`, `TDS_MODEL_REPOSITORY`, `TDS_MAPPER_REPOSITORY`, `TDS_HYPER_MODEL_REPOSITORY`, `TDS_FEATURE_ENGINEERING_PROCESS_REPOSITORY`, plus a `TDS_TRAINED_MODELS_<uuid>` table per Mapper).
2. **Installs the framework scripts** (`tds_training.py`, `tds_scoring.py`, `tds_feature_engineering*.py`, `tds_vector_embedding*.py`, `tds_seq2seq.py`, etc.) via `SYSUIF.INSTALL_FILE` (VCE) or `oaf.install_file` (VCL).

After this, **`install_file` is never called again** for any new model. Per-model code lives as BLOB rows in `TDS_CODE_REPOSITORY`.

## VCL connection pattern (PAT + PEM)

```python
import teradataml as tdml
tdml.create_context(host=host, base_url=base_url, pat_token=pat, pem_file=pem_path)
# Or username/password if PAT is unavailable
```

## Re-push scripts after an upgrade

If the user upgrades `tdstone2` and wants the in-database runners refreshed:

```python
sto.install_scripts()    # re-installs framework files only; repos untouched
```

## VCL extras

- On VCL Apply, ensure the OAF env has the required libs. tdstone2 will auto-create `tdstone2_sklearn` with `numpy`, `pandas`, `scikit-learn`, `skl2onnx`, `onnxruntime` if it doesn't exist (`DEFAULT_APPLY_LIBS` in `tdstone.py`).
- For GenAI / embeddings on VCL, use a dedicated env (e.g. `tdstone2_embeddings`) — see skill `tdstone2-genai`.

## Custom table names

Every repository name is overridable via kwargs:

```python
sto = TDStone(
    schema_name             = ...,
    code_repository         = 'MY_CODE',
    model_repository        = 'MY_MODELS',
    mapper_repository       = 'MY_MAPPERS',
    hyper_model_repository  = 'MY_HYPER_MODELS',
    feature_engineering_process_repository = 'MY_FE_PROCESSES',
)
```

## Common pitfalls

- **Forgot `tdml.create_context()`** — `TDStone.__init__` doesn't open the connection.
- **`SEARCHUIFDBPATH` not set on VCE** — `Script` won't find installed files; you'll get `OBJECT NOT FOUND` errors from `tdpython3 ./<db>/tds_training.py`.
- **VCL: connection pool inherits a QueryBand** — `INSERT … SELECT FROM Apply(…)` against OFS targets returns Error 3802. tdstone2 handles this internally by using a fresh `teradatasql` cursor; if you see 3802, check you're on a recent tdstone2 version.

## Next steps

- For an sklearn pipeline: skill `tdstone2-hypermodel`.
- For custom Python: skill `tdstone2-custom-script`.
- For embeddings: skill `tdstone2-genai`.
