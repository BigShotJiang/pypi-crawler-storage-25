---
name: tdstone2-custom-script
description: Use when the user wants to run arbitrary, non-sklearn Python code per partition inside Teradata Vantage with tdstone2 — registering custom Python source as a Code, binding arguments via Model, and running it through a Mapper without using the HyperModel sklearn convenience layer. Examples include custom anomaly algorithms, time-series feature extraction, validation rules, and PyTorch / TensorFlow inference loops.
---

# tdstone2 — Custom Python via Code + Model + Mapper

`HyperModel` is the sklearn convenience layer. The actual extension point of tdstone2 is the trio of lower-level primitives — `Code`, `Model`, `Mapper`. Use them directly when:

- The workload is not a sklearn pipeline (e.g. PyTorch, TensorFlow, statsmodels, custom NumPy).
- The user wants tight control over the in-database script (imports, batching, side effects).
- Different partitions need different *kinds* of models (heterogeneous workloads).

## Pattern

```python
from tdstone2.tdscode import Code
from tdstone2.tdsmodel import Model
from tdstone2.tdsmapper import Mapper

# 1. Register the Python source as a Code
code = Code(tdstone=sto, metadata={'project': 'anomaly-fy26'})
code.update_script('./my_detector.py')   # reads file → CODE BLOB
code.upload()                            # INSERT into TDS_CODE_REPOSITORY

# 2. Bind arguments
model = Model(tdstone=sto, metadata={'note': 'first run'})
model.attach_code(code.id)
model.update_arguments({
    'target'            : 'amount',
    'column_names_X'    : ['asset_id', 'month', 'category'],
    'column_categorical': ['category'],
    # any other kwargs your script reads from arguments
})
model.upload()

# 3. Wire to a dataset + execution
mp = Mapper(
    tdstone          = sto,
    mapper_type      = 'training',         # or 'scoring' / 'feature engineering'
    dataset_object   = tdml.in_schema(db, 'dataset_00'),
    col_id_row       = 'ID',
    col_id_partition = 'Partition_ID',
    col_fold         = 'FOLD',
    fold_training    = 'train',
)
mp.upload()                          # creates TDS_MAPPER_<uuid> + destination table
mp.fill_mapping_full(model_id=model.id)
mp.create_on_clause()
mp.create_sto_view()

# 4. Inspect before running
print(mp.generate_sto_query())

# 5. Run it
mp.execute_mapper()
```

No `HyperModel` row is written. Only `TDS_CODE_REPOSITORY`, `TDS_MODEL_REPOSITORY`, and `TDS_MAPPER_REPOSITORY` are touched, plus the per-Mapper destination table.

## Script contract

The script you upload must define a class — by convention `MyModel` — with the methods the chosen runner expects. The runner is determined by `mapper_type`:

| `mapper_type`                     | Runner script                              | Methods required on `MyModel`                  |
|-----------------------------------|--------------------------------------------|------------------------------------------------|
| `'training'`                      | `tds_training.py` (STO) / `_apply.py`      | `fit(df) -> dict`                              |
| `'scoring'`                       | `tds_scoring.py` (STO) / `_apply.py`       | `score(df) -> pandas.DataFrame`                |
| `'feature engineering'`           | `tds_feature_engineering.py`               | `transform(df) -> pandas.DataFrame`            |
| `'feature engineering reducer'`   | `tds_feature_engineering_reducer.py`       | `reduce(df) -> pandas.DataFrame`               |

Constructor receives `arguments` (the JSON dict you bound on the Model):

```python
# my_detector.py
class MyModel:
    def __init__(self, arguments):
        self.arguments = arguments
        self.threshold = arguments.get('threshold', 3.0)

    def fit(self, df):
        # return a dict — will be JSON-encoded into the trained-model row's STATUS / metrics
        return {'rows_fitted': len(df), 'partition_mean': float(df['amount'].mean())}

    def score(self, df):
        # return the input DataFrame with prediction columns appended
        df = df.copy()
        df['anomaly_score'] = (df['amount'] - df['amount'].mean()) / df['amount'].std()
        df['is_anomaly']    = df['anomaly_score'].abs() > self.threshold
        return df
```

To see the exact contract a runner enforces, read the corresponding file in `tdstone2/data/`.

## Reload a Mapper by UUID

```python
sto.list_mappers()
mp = Mapper(tdstone=sto)
mp.download(id='<uuid>')
mp.execute_mapper()
```

## Heterogeneous models per partition

Because the partition-mapping table (`TDS_MAPPER_<uuid>`) carries `ID_MODEL` per row, you can `UPDATE` it to route different partitions to different `Model` UUIDs. This is rarely needed but useful for cohort experiments (e.g. RandomForest in EU, XGBoost in NA).

## When to use this skill vs. HyperModel

| Need                                                                      | Skill                       |
|---------------------------------------------------------------------------|-----------------------------|
| Stock sklearn pipeline per partition                                      | `tdstone2-hypermodel`       |
| Custom Python, non-sklearn estimator                                      | **this skill**              |
| Per-partition feature engineering (with a custom script)                  | `tdstone2-feature-engineering` |
| HuggingFace / Seq2Seq inference                                           | `tdstone2-genai`            |

## Debugging

`Mapper.generate_sto_query()` returns the exact SQL that will run. Always inspect it before `execute_mapper()` — it catches bad column names, missing partition values, and JSON-quoting issues fast.
