"""
Bundled Claude Code / agent skills that teach an LLM agent when and how to use
tdstone2.

Public surface:

    from tdstone2.skills import export_skills, install_skills, list_skills, get_skill

    export_skills('~/.claude/skills')      # copy all bundled skills to any dir
    install_skills()                       # install into project .claude/skills (local)
    install_skills(scope='global')         # install into ~/.claude/skills (user-wide)
    list_skills()                          # → ['tdstone2', 'tdstone2-setup', ...]
    print(get_skill('tdstone2-hypermodel')) # raw markdown of a single skill

CLI:

    python -m tdstone2.skills list
    python -m tdstone2.skills export ~/.claude/skills
    python -m tdstone2.skills export .claude/skills --overwrite
    python -m tdstone2.skills install               # local (project)
    python -m tdstone2.skills install --global      # user-wide
    python -m tdstone2.skills install --overwrite
"""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path
from typing import Iterable

logger = logging.getLogger(__name__)

# Directory holding the bundled .md skill files (this package).
_SKILLS_DIR = Path(__file__).resolve().parent


def _bundled_skill_files() -> list[Path]:
    """Return SKILL.md paths from each skill subdirectory (sorted by skill name)."""
    return sorted(
        p / "SKILL.md"
        for p in _SKILLS_DIR.iterdir()
        if p.is_dir() and not p.name.startswith("_") and (p / "SKILL.md").is_file()
    )


def list_skills() -> list[str]:
    """
    Return the names of all bundled skills (the subdirectory name, e.g. 'tdstone2-hypermodel').
    """
    return [p.parent.name for p in _bundled_skill_files()]


def get_skill(name: str) -> str:
    """
    Return the raw markdown of a single bundled skill.

    Parameters
    ----------
    name : str
        The skill name without the '.md' extension (e.g. 'tdstone2-hypermodel').
    """
    path = _SKILLS_DIR / name / "SKILL.md"
    if not path.is_file():
        available = ", ".join(list_skills())
        raise FileNotFoundError(
            f"Skill '{name}' not found in tdstone2.skills. Available: {available}"
        )
    return path.read_text(encoding="utf-8")


def export_skills(
    target_dir: str | os.PathLike,
    overwrite: bool = False,
    names: Iterable[str] | None = None,
    dry_run: bool = False,
) -> list[Path]:
    """
    Copy bundled tdstone2 skills (.md files) into ``target_dir``.

    The target directory is typically a Claude Code skills folder such as
    ``~/.claude/skills`` (user-wide) or ``./.claude/skills`` (project-local).

    Parameters
    ----------
    target_dir : str or path
        Destination directory. ``~`` is expanded. Created if missing.
    overwrite : bool, default False
        If False, existing files are left alone and skipped (with a warning).
        If True, existing files are replaced.
    names : iterable of str, optional
        Subset of skill names to export. Defaults to all bundled skills.
    dry_run : bool, default False
        If True, report what *would* be copied without writing anything.

    Returns
    -------
    list of pathlib.Path
        The destination paths that were (or would be) written.
    """
    dest = Path(os.path.expanduser(os.fspath(target_dir))).resolve()

    if names is None:
        files = _bundled_skill_files()
    else:
        files = [_SKILLS_DIR / n / "SKILL.md" for n in names]
        missing = [str(f) for f in files if not f.is_file()]
        if missing:
            available = ", ".join(list_skills())
            raise FileNotFoundError(
                f"Skill files not found: {missing}. Available: {available}"
            )

    if not dry_run:
        dest.mkdir(parents=True, exist_ok=True)

    written: list[Path] = []
    skipped: list[Path] = []

    for src in files:
        out = dest / f"{src.parent.name}.md"  # SKILL.md → <skill-name>.md
        exists = out.exists()
        if exists and not overwrite:
            logger.warning("Skipped %s (already exists; pass overwrite=True to replace)", out)
            skipped.append(out)
            continue
        if dry_run:
            logger.info("(dry-run) would copy %s/SKILL.md -> %s", src.parent.name, out)
        else:
            shutil.copy2(src, out)
            logger.info("Exported %s/SKILL.md -> %s", src.parent.name, out)
        written.append(out)

    if written:
        action = "Would export" if dry_run else "Exported"
        print(f"{action} {len(written)} skill(s) to {dest}")
    if skipped:
        print(f"Skipped {len(skipped)} pre-existing file(s); pass overwrite=True to replace.")

    return written


def install_skills(
    scope: str = "local",
    project_dir: "str | os.PathLike | None" = None,
    overwrite: bool = False,
    names: "Iterable[str] | None" = None,
    dry_run: bool = False,
) -> list[Path]:
    """
    Install bundled tdstone2 skills into Claude Code's skills directory.

    Parameters
    ----------
    scope : {'local', 'global'}, default 'local'
        - ``'local'``  → ``<project_dir>/.claude/skills/`` (project-level)
        - ``'global'`` → ``~/.claude/skills/`` (user-wide)
    project_dir : str or path, optional
        Root directory for the local install. Defaults to the current working
        directory. Ignored when ``scope='global'``.
    overwrite : bool, default False
        Replace existing skill files.
    names : iterable of str, optional
        Subset of skill names to install. Defaults to all bundled skills.
    dry_run : bool, default False
        Report what would be written without actually writing anything.

    Returns
    -------
    list of pathlib.Path
        The destination paths that were (or would be) written.
    """
    if scope == "global":
        target = Path(os.path.expanduser("~/.claude/skills"))
    elif scope == "local":
        base = Path(os.fspath(project_dir)).resolve() if project_dir else Path.cwd()
        target = base / ".claude" / "skills"
    else:
        raise ValueError(f"scope must be 'local' or 'global', got '{scope}'")

    return export_skills(target, overwrite=overwrite, names=names, dry_run=dry_run)


__all__ = ["export_skills", "install_skills", "list_skills", "get_skill"]
