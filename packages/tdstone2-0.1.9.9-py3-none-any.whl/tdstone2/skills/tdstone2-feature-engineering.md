---
name: tdstone2-feature-engineering
description: Use when the user wants to compute features or run dimensionality reduction per partition inside Teradata Vantage using tdstone2 — either a built-in reducer or a custom Python transform script — with results stored in a governed feature repository.
---

# tdstone2 — Feature engineering

`FeatureEngineering` is a sibling of `HyperModel`. It reuses the same Code / Model / Mapper machinery but with one Mapper instead of two (no train/score split) and writes to a feature repository instead of a trained-model repository.

Two modes:

| `feature_engineering_type`        | What runs                                                            |
|-----------------------------------|----------------------------------------------------------------------|
| `'feature engineering reducer'`   | Built-in dimensionality reduction (auto-generated script)            |
| `'feature engineering'`           | Your custom Python transform script (`script_path=...`)              |

## Reducer mode — built-in dimensionality reduction

```python
from tdstone2.tdsfeature_engineering import FeatureEngineering

fe = FeatureEngineering(
    tdstone                  = sto,
    feature_engineering_type = 'feature engineering reducer',
    dataset                  = tdml.in_schema(db, 'dataset_00'),
    id_row                   = 'ID',
    id_partition             = 'Partition_ID',
    id_fold                  = 'FOLD',
    fold_training            = 'train',
)
fe.reduce()
reduced = fe.get_reduced_features()
```

## Custom-script mode

```python
fe2 = FeatureEngineering(
    tdstone                  = sto,
    feature_engineering_type = 'feature engineering',
    script_path              = 'Feature_Interactions.py',
    dataset                  = tdml.in_schema(db, 'dataset_00'),
    id_row                   = 'ID',
    id_partition             = 'Partition_ID',
)
fe2.transform()
features      = fe2.get_computed_features()
features_raw  = fe2.get_computed_features(denormalized_view=False)
```

The script at `script_path` is uploaded to `TDS_CODE_REPOSITORY` and executed by `tds_feature_engineering.py` on each partition's AMP.

## Script contract

The custom script must define a class (conventionally `MyModel`) with a `transform(df)` method returning a pandas DataFrame. The result is unpivoted into `(partition_cols, id_row, FEATURE_NAME, FEATURE_VALUE, FEATURE_TYPE)` tuples and stored in the feature repository.

A minimal example:

```python
# Feature_Interactions.py
class MyModel:
    def __init__(self, arguments):
        self.arguments = arguments

    def transform(self, df):
        df = df.copy()
        df['X1_X2'] = df['X1'] * df['X2']
        df['X1_sq'] = df['X1'] ** 2
        return df[['ID', 'Partition_ID', 'X1_X2', 'X1_sq']]
```

## Output

- **Denormalised view** (`get_computed_features(denormalized_view=True)`) — pivots features back into columns alongside original input columns. Good for downstream HyperModel consumption.
- **Raw view** (`denormalized_view=False`) — long-format `(FEATURE_NAME, FEATURE_VALUE, FEATURE_TYPE)` tuples. Good for stored-feature analytics.

## Reload by UUID

```python
sto.list_feature_engineering_models()
existing = FeatureEngineering(tdstone=sto)
existing.download(id='<uuid>')
existing.transform()
```

## When to chain FE + HyperModel

A common pattern is:

1. `FeatureEngineering(type='feature engineering reducer')` → reduces 200 features → 30.
2. `HyperModel(dataset=fe.get_reduced_features(), ...)` → trains per-partition models on the reduced features.

Both stages persist their lineage independently — you can audit which reducer fed which model.
