---
name: tdstone2
description: Use when the user wants to run machine learning, feature engineering, vector embeddings, or Seq2Seq inference inside Teradata Vantage with governance, hyper-segmented (one-model-per-partition) training, custom Python code, or BYOM-style ONNX inference. This is the entry / decision skill — it explains when to choose tdstone2 over teradataml's td_sklearn and routes you to the right sub-skill.
---

# tdstone2 — when and why

`tdstone2` is an open-source Python framework that operationalises ML on Teradata Vantage. It pushes user Python code to the database (one model per partition, in parallel) and persists everything — code, models, mappers, trained artifacts, lineage — in six governed repository tables.

## When to pick tdstone2 over `td_sklearn`

| Symptom in the user's request                                                         | Pick                |
|---------------------------------------------------------------------------------------|---------------------|
| "Run this sklearn pipeline in Vantage" (single global model, throwaway)               | `td_sklearn`        |
| One model per customer / region / asset / segment (hyper-segmentation)                | **tdstone2**        |
| Needs governance: who, when, with what code, on what data → which prediction          | **tdstone2**        |
| Custom Python (non-sklearn) per partition, or HuggingFace, ONNX, Seq2Seq              | **tdstone2**        |
| Client and server Python versions differ                                              | **tdstone2**        |
| ONNX export of the trained pipeline, callable from SQL via `ONNXPredict`              | **tdstone2**        |
| Point-in-time replay ("which model scored row X on day Y?")                           | **tdstone2** (VCE)  |
| Cloud Lake (VCL) with OFS-resident tables                                             | both supported      |

The two are compatible — they can coexist in the same notebook. `td_sklearn` is faster to type for prototyping. `tdstone2` pays off as soon as governance, hyper-segmentation, custom code, or non-sklearn workloads enter the picture.

## How tdstone2 actually works (one paragraph)

`TDStone.setup()` installs ~12 generic runner scripts (`tds_training.py`, `tds_scoring.py`, etc.) into Vantage **once** via `SYSUIF.INSTALL_FILE` (VCE) or OAF `env.install_file` (VCL). For every model afterward, the user's per-partition Python code is stored as a BLOB row in `TDS_CODE_REPOSITORY`. At runtime, a generated SQL view joins each dataset row to its matching code row, and the on-AMP runner `exec()`s the code text. No new file install per model — code lives in tables.

## The five core abstractions

```
Code  →  Model  →  Mapper  →  HyperModel        (sklearn-focused convenience)
                          ╲→  FeatureEngineering (transform / reducer flows)
```

- **Code** — Python source as a BLOB in `TDS_CODE_REPOSITORY`.
- **Model** — binds a Code to a JSON `ARGUMENTS` payload (target, columns, hyperparams).
- **Mapper** — owns the partition catalogue, dataset reference, ON-clause view, and the SQL that runs the STO/Apply job.
- **HyperModel** — composes Code + Model + 2 Mappers (training + scoring) for the sklearn case.
- **FeatureEngineering** — composes Code + Model + 1 Mapper for transforms / reducers.

## Route to the right sub-skill

| Task                                                                  | Skill                              |
|-----------------------------------------------------------------------|------------------------------------|
| Initial framework setup (TDStone, VCE vs VCL, connection)             | `tdstone2-setup`                   |
| Hyper-segmented sklearn pipeline (classifier/regressor/anomaly)       | `tdstone2-hypermodel`              |
| Export trained pipelines to ONNX, call `ONNXPredict` from SQL         | `tdstone2-byom-onnx`               |
| Per-partition feature engineering or dimensionality reduction         | `tdstone2-feature-engineering`     |
| Vector embeddings (BYOM on VCE, OAF on VCL) or Seq2Seq                | `tdstone2-genai`                   |
| Non-sklearn per-partition Python (custom Code + Mapper)               | `tdstone2-custom-script`           |
| Debugging Apply / OFS / QueryBand / chunked CLOB errors               | `tdstone2-troubleshooting`         |

## Source-of-truth files in the package

- `tdstone2/tdstone.py` — `TDStone`, framework setup, repository DDL
- `tdstone2/tdscode.py`, `tdsmodel.py`, `tdsmapper.py` — three core primitives
- `tdstone2/tdshypermodel.py` — sklearn orchestrator
- `tdstone2/tdsfeature_engineering.py` — FE orchestrator
- `tdstone2/tdsgenai.py` (VCE), `tdsgenai_lake.py` (VCL), `tdsgenai_seq2seq.py` — GenAI
- `tdstone2/model_maker/scikit_learn.py` — sklearn → per-partition script generator
- `tdstone2/data/tds_*.py` — runners that execute inside Vantage

## Always tell the user

- **Install once, register many.** After `TDStone.setup()`, new models are INSERTs into `TDS_CODE_REPOSITORY` — never another `install_file`.
- Every Code/Model/Mapper/HyperModel/FeatureEngineering has a UUID and a `METADATA JSON(32000)` column. Use them for project / run / owner tags.
- Repositories on VCE are temporal (`VALIDTIME`); on VCL/OFS they fall back to a `CREATION_DATE` column (OFS rejects temporal DDL).
