---
name: tdstone2-genai
description: Use when the user wants to compute vector embeddings or run Seq2Seq inference (summarisation, translation, language detection) inside Teradata Vantage using tdstone2 — HuggingFace / SentenceTransformer / ONNX models on Vantage Enterprise (BYOM via tdsgenai) or Cloud Lake (OAF via tdsgenai_lake), and flan-t5 / Seq2Seq via tdsgenai_seq2seq.
---

# tdstone2 — GenAI (embeddings, Seq2Seq)

tdstone2 ships three GenAI modules. All three bypass `HyperModel` and use the lower-level Code / Model / Mapper machinery directly — proof that the framework is not sklearn-bound.

| Module                          | Environment        | Backend            | Used for                                  |
|---------------------------------|--------------------|--------------------|-------------------------------------------|
| `tdstone2.tdsgenai`             | Vantage Enterprise | BYOM + STO         | HuggingFace embedding models (ONNX)       |
| `tdstone2.tdsgenai_lake`        | Vantage Cloud Lake | OAF / Apply        | HuggingFace embedding models              |
| `tdstone2.tdsgenai_seq2seq`     | Both (BYOM / OAF)  | STO or Apply       | flan-t5 summarisation, language detection |

Pick by the user's deployment.

## VCE — embeddings via BYOM (`tdsgenai`)

```python
from tdstone2.tdsgenai import (
    install_model_in_vantage_from_name,
    compute_vector_embedding_byom,
    list_installed_files_byom,
    get_model_dimension,
)

# 1. Install a HuggingFace model as ONNX in Vantage
install_model_in_vantage_from_name(
    model_name   = 'intfloat/multilingual-e5-small',
    model_task   = 'sentence-similarity',
    upload       = True,
    generate_zip = True,
)

# 2. Compute embeddings in-database
embeddings = compute_vector_embedding_byom(
    model              = 'tdstone2_emb_384_intfloat_multilingual_e5_small',
    dataset            = text_df,
    text_column        = 'content',
    accumulate_columns = ['id'],
    schema_name        = Param['database'],
    table_name         = 'embeddings',
    primary_index      = ['id'],
)

# 3. Inspect
print(get_model_dimension('tdstone2_emb_384_intfloat_multilingual_e5_small'))
list_installed_files_byom()
```

## VCL — embeddings via OAF (`tdsgenai_lake`)

```python
from tdstone2.tdsgenai_lake import (
    install_embedding_model,
    compute_vector_embedding,
    ensure_embedding_env,
)

# 1. Ensure OAF env exists with HF / torch / transformers / sentence-transformers
ensure_embedding_env(env_name='tdstone2_embeddings')

# 2. Install the model into the env
install_embedding_model(
    model_name = 'intfloat/multilingual-e5-small',
    env_name   = 'tdstone2_embeddings',
)

# 3. Compute embeddings via Apply
embeddings = compute_vector_embedding(
    dataset            = text_df,
    text_column        = 'content',
    accumulate_columns = ['id'],
    model_name         = 'intfloat/multilingual-e5-small',
    env_name           = 'tdstone2_embeddings',
    schema_name        = Param['database'],
    table_name         = 'embeddings',
)
```

## Seq2Seq — summarisation / language detection / translation

```python
from tdstone2.tdsgenai_seq2seq import install_seq2seq_model, run_seq2seq

install_seq2seq_model(
    model_name = 'google/flan-t5-small',
    model_task = 'summarization',     # or 'translation', 'language-detection'
    upload     = True,
)

results = run_seq2seq(
    dataset     = text_df,
    text_column = 'content',
    model       = 'tdstone2_seq2seq_google_flan_t5_small',
    schema_name = Param['database'],
)
```

## VCL OAF environment traps

- **torch CUDA pin**: VCL2 drivers expect `torch` built against CUDA 12.7 — pin `torch==2.9.1+cu128` (or whatever matches the cluster). Mismatched CUDA → silent CPU fallback or container start failure.
- **transformers ≥ 5**: required to avoid a `getpwuid` crash on OFS-backed containers.
- **sentence-transformers `modules.json` compat**: some HF models ship a JSON the OAF env's `sentence-transformers` version cannot parse. Pin both.
- **`cuda_strict` pre-flight**: tdsgenai_lake offers a pre-flight check that fails fast if CUDA isn't available.

## VCL1 compute group gotcha

On VCL1, the default compute group for `data_scientist` (`CG_BusGrpA_ANL`) auto-hibernates ~01:33–09:00 UTC. Apply jobs submitted in that window silently queue for up to an hour, then return Error 6881. If a user reports embeddings "hung", check the compute group state first.

## When to use HyperModel instead

If the task is *training* an sklearn-style classifier on partitioned data, use `HyperModel` (skill `tdstone2-hypermodel`). The GenAI modules are for *inference* with pre-trained HuggingFace / Seq2Seq models.

## When to roll your own with Code + Mapper

For a non-HuggingFace deep-learning model (e.g. a custom PyTorch encoder, a tokeniser-only flow), the GenAI modules are not the right surface. Use the lower-level building blocks instead — skill `tdstone2-custom-script`.
