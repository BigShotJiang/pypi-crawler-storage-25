---
name: tdstone2-byom-onnx
description: Use when the user wants to export a tdstone2 HyperModel's trained sklearn pipelines to ONNX so they can be scored from pure SQL via Teradata's ONNXPredict (BYOM) table operator, with no Python at inference time. Covers the convert_to_onnx flag, the auto-generated V_<repo>_BYOM_CATALOG view, get_byom_catalog(), and the ai.onnx.ml opset pin required by Vantage.
---

# tdstone2 — ONNX export & native BYOM inference

`tdstone2` can write each per-partition trained pipeline as **both** a pickle (for the Python scoring path) and an **ONNX** artifact (for SQL-native scoring through Teradata's `ONNXPredict` table operator). The framework auto-creates a `V_<repo>_BYOM_CATALOG` view in the exact shape `ONNXPredict` expects.

## When to recommend this

- The user wants production inference callable from any SQL tool / BI workload / federated query, with **no Python cold-start**.
- Their downstream team is a SQL / DBA team that does not want to depend on the OAF env.
- They already train hyper-segmented models with `tdstone2.HyperModel` and need a clean hand-off.

## Enable ONNX during training

```python
hm = HyperModel(
    tdstone           = sto,
    skl_pipeline_steps= steps,
    model_parameters  = {...},
    dataset           = ...,
    id_row            = 'ID',
    id_partition      = 'Partition_ID',
    convert_to_onnx   = True,     # <-- this turns on the ONNX path
    store_pickle      = True,     # keep pickle too; both can coexist
)
hm.train()
```

Internally, the in-database training script (`tdstone2/data/tds_training.py`) calls `skl2onnx.convert_sklearn` with a **hard opset pin**:

```python
onnx_model = convert_sklearn(
    model.model,
    initial_types=initial_type,
    target_opset={'': 12, 'ai.onnx.ml': 3},   # required for Vantage ONNXPredict
)
```

**Do not change this pin.** Teradata's `ONNXPredict` supports `ai.onnx.ml` up to **v3 only**. If `skl2onnx` auto-picks v4 the BLOB lands NULL in the trained-model repo and `ONNXPredict` raises *"Invalid Client Locator"* at scoring time.

## The three auto-generated views

The training Mapper creates three companion views over `TDS_TRAINED_MODELS_<uuid>`:

| View                          | Filter                  | Shape                                                  |
|-------------------------------|-------------------------|--------------------------------------------------------|
| `V_<repo>_PICKLE`             | `MODEL_TYPE = 'pickle'` | Chunked CLOB / VARCHAR + `MODEL_CHUNK_*` reassembly    |
| `V_<repo>_ONNX`               | `MODEL_TYPE = 'onnx'`   | base16-decoded raw `TRAINED_MODEL`                     |
| `V_<repo>_BYOM_CATALOG`       | latest ONNX per partition | `(model_id, model, <partition_cols>)` — **BYOM-ready** |

The catalog view's exact DDL:

```sql
REPLACE VIEW <schema>.V_<trained_model_repo>_BYOM_CATALOG AS
SELECT
    ID_TRAINED_MODEL AS model_id,
    TRAINED_MODEL    AS model,
    <partition_cols>
FROM <schema>.V_<trained_model_repo>_ONNX
QUALIFY row_number() OVER (
    PARTITION BY <partition_cols> ORDER BY TD_TIMECODE DESC
) = 1
```

## Access from Python

```python
catalog = hm.get_byom_catalog()      # tdml.DataFrame on V_<repo>_BYOM_CATALOG
print(catalog.columns)               # model_id, model, Partition_ID, ...
```

## Score via SQL — no Python at inference time

```sql
SELECT *
FROM mldb.ONNXPredict (
    ON input_data PARTITION BY Partition_ID
    ON <schema>.V_<trained_model_repo>_BYOM_CATALOG
         PARTITION BY Partition_ID DIMENSION
    USING
        Accumulate ('ID', 'Partition_ID')
        ModelOutputFields ('output_label', 'output_probability')
) AS dt;
```

The catalog view is already in BYOM shape — no need to copy it into a separate BYOM-managed table unless the user wants explicit `RetrieveBYOM` / `SaveBYOM` lifecycle.

## Two inference modes from one training run

| Mode                                   | Path                                                        |
|----------------------------------------|-------------------------------------------------------------|
| Python (pickle, full features + timing)| `hm.score()` → `tds_scoring.py` on STO/Apply                |
| SQL native (no Python)                 | `ONNXPredict` on `V_<repo>_BYOM_CATALOG`                    |

The user chooses per-call. The same `HyperModel` produced both.

## Contrast with td_sklearn

`td_sklearn` stores trained estimators only as pickle BLOBs in `opensourceml_models`. It cannot be invoked from `ONNXPredict` — every inference goes back through the Python wrapper. Use tdstone2 when SQL-native BYOM inference is required.

## Gotchas

- Some sklearn estimators have **no ONNX converter**. The training script will record the failure in `STATUS` for that partition; check `SELECT STATUS FROM TDS_TRAINED_MODELS_<uuid> WHERE MODEL_TYPE='onnx'`.
- ONNX is opset-locked to `ai.onnx.ml=3` — do not unpin it.
- The catalog view shows the **latest** ONNX per partition. To pin a specific historical training run, filter `TD_TIMECODE` on `V_<repo>_ONNX` directly or, on VCE, use `VALIDTIME AS OF TIMESTAMP …` on the underlying repos.
