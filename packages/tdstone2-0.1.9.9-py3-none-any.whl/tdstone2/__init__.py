__version__ = '0.1.9.9'

EMBEDDINGS_MODEL_CATALOG = 'TDS_EMBEDDINGS_MODEL_CATALOG'
EMBEDDINGS_TOKENIZER_CATALOG = 'TDS_EMBEDDINGS_TOKENIZER_CATALOG'

import logging
# Setup the logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',  # Format to include timestamp
    datefmt='%Y-%m-%d %H:%M:%S'  # Set the date/time format
)

logger = logging.getLogger(__name__)

from tdstone2.skills import export_skills, install_skills, list_skills, get_skill  # noqa: E402

__all__ = ["export_skills", "install_skills", "list_skills", "get_skill"]