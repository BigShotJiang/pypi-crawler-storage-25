# predictorsdk

The official Python client for the [PredictorSDK](https://predictorsdk.com) matching markets API.

## Installation

```bash
pip install predictorsdk
```

## Usage

```python
from predictorsdk import PredictorSDK

client = PredictorSDK(token="your-api-key")

response = client.get_sports_matching_markets(
    kalshi_event_ticker="KXMLB-25-NYM-COL-2025-04-03",
)
```

## Documentation

- [Docs](https://docs.predictorsdk.com)
- [API Reference](https://docs.predictorsdk.com/api-reference)

## License

[MIT](https://github.com/PredictorSDK/sdk-python/blob/main/LICENSE)
