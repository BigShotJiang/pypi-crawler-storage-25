"""Tests for the RetailClient sub-client (SDK 2.0)."""
from decimal import Decimal

import httpx
import pytest

from edge_sdk import EdgeClient
from edge_sdk.types import (
    MintTicketRequest,
    RetailCashoutRequest,
    RetailTradeRequest,
)


def _client(responses: list[tuple[int, dict]]) -> EdgeClient:
    calls = {"i": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        i = calls["i"]
        calls["i"] += 1
        status, body = responses[i]
        return httpx.Response(status, json=body, headers={"x-request-id": f"r{i}"})

    transport = httpx.MockTransport(handler)
    http = httpx.AsyncClient(
        transport=transport,
        base_url="https://api.test.com",
        headers={"X-API-Key": "k"},
    )
    return EdgeClient(base_url="https://api.test.com", api_key="k", http_client=http)


@pytest.mark.asyncio
async def test_mint_ticket():
    c = _client([
        (201, {
            "ticket_ref": "TKT-1",
            "user_external_id": "retail_user_1",
            "terminal_external_id": "term_01",
            "cashier_shift_external_id": "shift_01",
            "created_at": "2026-04-17T00:00:00Z",
        }),
    ])
    r = await c.retail.mint_ticket(MintTicketRequest(
        terminal_external_id="term_01",
        cashier_shift_external_id="shift_01",
    ))
    assert r.ticket_ref == "TKT-1"
    await c.close()


@pytest.mark.asyncio
async def test_execute_retail_trade():
    c = _client([
        (201, {
            "ticket_ref": "TKT-1",
            "contracts": "10.5",
            "cost": "5.0",
            "fee": "0.09",
            "avg_fill_price": "0.5",
            "new_balance": "95.0",
        }),
    ])
    r = await c.retail.execute_retail_trade(
        "TKT-1",
        RetailTradeRequest(market_id="mkt_abc", side="YES", amount=Decimal("5")),
    )
    assert r.contracts == Decimal("10.5")
    assert r.new_balance == Decimal("95.0")
    await c.close()


@pytest.mark.asyncio
async def test_redeem_ticket():
    c = _client([
        (200, {"ticket_ref": "TKT-1", "payout_amount": "100.00", "status": "redeemed"}),
    ])
    r = await c.retail.redeem_ticket("TKT-1")
    assert r.status == "redeemed"
    assert r.payout_amount == Decimal("100.00")
    await c.close()


@pytest.mark.asyncio
async def test_cashout_ticket():
    c = _client([
        (201, {
            "ticket_ref": "TKT-1",
            "contracts_sold": "10",
            "payout": "4",
            "fee": "0.08",
            "new_balance": "99",
        }),
    ])
    r = await c.retail.cashout_ticket(
        "TKT-1",
        RetailCashoutRequest(market_id="mkt_abc", side="YES"),
    )
    assert r.payout == Decimal("4")
    await c.close()


@pytest.mark.asyncio
async def test_get_ticket_status():
    c = _client([
        (200, {
            "ticket_ref": "TKT-1",
            "is_retail": True,
            "balance": "50.0",
            "position_count": 2,
            "redeemable": False,
        }),
    ])
    r = await c.retail.get_ticket_status("TKT-1")
    assert r.position_count == 2
    assert r.redeemable is False
    await c.close()
