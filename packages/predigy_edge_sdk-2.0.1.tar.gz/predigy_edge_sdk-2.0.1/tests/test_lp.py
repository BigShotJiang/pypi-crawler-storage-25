"""Tests for the LPClient sub-client (SDK 2.0)."""
import httpx
import pytest

from edge_sdk import EdgeClient
from edge_sdk.types import (
    LPConfigUpdateRequest,
    LPDesignateRequest,
    LPRevokeRequest,
)


def _client(responses: list[tuple[int, dict | list]]) -> EdgeClient:
    calls = {"i": 0, "requests": []}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["requests"].append(request)
        i = calls["i"]
        calls["i"] += 1
        status, body = responses[i]
        return httpx.Response(status, json=body, headers={"x-request-id": f"r{i}"})

    transport = httpx.MockTransport(handler)
    http = httpx.AsyncClient(
        transport=transport,
        base_url="https://api.test.com",
        headers={"X-API-Key": "k"},
    )
    c = EdgeClient(base_url="https://api.test.com", api_key="k", http_client=http)
    c._test_calls = calls  # type: ignore[attr-defined]
    return c


_DESIGNATED = {
    "user_external_id": "u1",
    "display_name": "LP One",
    "is_liquidity_provider": True,
    "lp_designated_at": "2026-04-17T00:00:00Z",
    "lp_config": {"tier": "gold"},
}

_USER = {
    "external_id": "u1",
    "display_name": "LP One",
    "balance": "100000",
    "is_liquidity_provider": True,
    "lp_config": {"tier": "gold"},
    "lp_designated_at": "2026-04-17T00:00:00Z",
}


@pytest.mark.asyncio
async def test_designate_lp():
    c = _client([(201, _DESIGNATED)])
    r = await c.lp.designate_lp(LPDesignateRequest(
        user_external_id="u1", lp_config={"tier": "gold"},
    ))
    assert r.is_liquidity_provider is True
    assert str(c._test_calls["requests"][0].url).endswith("/admin/lp/designate")
    await c.close()


@pytest.mark.asyncio
async def test_revoke_lp():
    c = _client([(200, {**_DESIGNATED, "is_liquidity_provider": False, "lp_config": None, "lp_designated_at": None})])
    r = await c.lp.revoke_lp(LPRevokeRequest(user_external_id="u1"))
    assert r.is_liquidity_provider is False
    await c.close()


@pytest.mark.asyncio
async def test_list_lps_returns_list():
    c = _client([(200, [_USER])])
    r = await c.lp.list_lps()
    assert len(r) == 1
    assert r[0].external_id == "u1"
    await c.close()


@pytest.mark.asyncio
async def test_update_lp_config_encodes_id():
    c = _client([(200, _USER)])
    await c.lp.update_lp_config(
        "user/1",
        LPConfigUpdateRequest(lp_config={"tier": "silver"}),
    )
    url = str(c._test_calls["requests"][0].url)
    assert "/admin/lp/users/user%2F1/config" in url
    assert c._test_calls["requests"][0].method == "PATCH"
    await c.close()


@pytest.mark.asyncio
async def test_get_dashboard_passes_user_id_query():
    c = _client([(200, {
        "total_trades": 10, "total_volume": 1000.0, "total_fees_paid": 20.0,
        "total_rebates": 5.0, "avg_fee_rate": 0.02, "markets_served": 3,
    })])
    r = await c.lp.get_dashboard("u1")
    assert r.total_trades == 10
    assert "user_external_id=u1" in str(c._test_calls["requests"][0].url)
    await c.close()


@pytest.mark.asyncio
async def test_get_activity_optional_limit():
    c = _client([(200, [])])
    await c.lp.get_activity("u1", limit=25)
    url = str(c._test_calls["requests"][0].url)
    assert "user_external_id=u1" in url
    assert "limit=25" in url
    await c.close()


@pytest.mark.asyncio
async def test_get_analytics():
    c = _client([(200, {
        "total_lp_users": 2, "active_lps": 1,
        "total_volume": 500.0, "total_rebates": 10.0,
    })])
    r = await c.lp.get_analytics()
    assert r.active_lps == 1
    await c.close()
