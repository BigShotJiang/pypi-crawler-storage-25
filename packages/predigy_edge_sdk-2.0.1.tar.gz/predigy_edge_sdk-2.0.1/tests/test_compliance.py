"""Tests for the ComplianceClient sub-client (SDK 2.0, 16 methods)."""
import httpx
import pytest

from edge_sdk import EdgeClient


def _client(responses: list[tuple[int, dict]]) -> EdgeClient:
    calls = {"i": 0, "requests": []}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["requests"].append(request)
        i = calls["i"]
        calls["i"] += 1
        status, body = responses[i]
        return httpx.Response(status, json=body, headers={"x-request-id": f"r{i}"})

    transport = httpx.MockTransport(handler)
    http = httpx.AsyncClient(
        transport=transport,
        base_url="https://api.test.com",
        headers={"X-API-Key": "k"},
    )
    c = EdgeClient(base_url="https://api.test.com", api_key="k", http_client=http)
    c._test_calls = calls  # type: ignore[attr-defined]
    return c


@pytest.mark.asyncio
async def test_exception_report_passes_date():
    c = _client([(200, {"exceptions": []})])
    r = await c.compliance.get_exception_report("2026-04-17")
    assert r == {"exceptions": []}
    req = c._test_calls["requests"][0]
    assert "date=2026-04-17" in str(req.url)
    await c.close()


@pytest.mark.asyncio
async def test_daily_transactions_includes_terminal_id():
    c = _client([(200, {"transactions": []})])
    await c.compliance.get_daily_transactions("2026-04-17", terminal_id=42)
    req = c._test_calls["requests"][0]
    url = str(req.url)
    assert "date=2026-04-17" in url
    assert "terminal_id=42" in url
    await c.close()


@pytest.mark.asyncio
async def test_daily_transactions_omits_missing_terminal():
    c = _client([(200, {"transactions": []})])
    await c.compliance.get_daily_transactions("2026-04-17")
    assert "terminal_id" not in str(c._test_calls["requests"][0].url)
    await c.close()


@pytest.mark.asyncio
async def test_accrual_recap_defaults_period_daily():
    c = _client([(200, {})])
    await c.compliance.get_accrual_recap("2026-04-17")
    assert "period=daily" in str(c._test_calls["requests"][0].url)
    await c.close()


@pytest.mark.asyncio
async def test_sport_statistics_monthly():
    c = _client([(200, {})])
    await c.compliance.get_sport_statistics(2026, month=4)
    url = str(c._test_calls["requests"][0].url)
    assert "year=2026" in url
    assert "month=4" in url
    assert "period=monthly" in url
    await c.close()


@pytest.mark.asyncio
async def test_customer_detail_defaults_daily():
    c = _client([(200, {})])
    await c.compliance.get_customer_detail(42)
    url = str(c._test_calls["requests"][0].url)
    assert "/admin/compliance/customer/42/detail" in url
    assert "period=daily" in url
    await c.close()


@pytest.mark.asyncio
async def test_shift_close_encodes_id():
    c = _client([(200, {})])
    await c.compliance.get_shift_close_report("shift/01")
    url = str(c._test_calls["requests"][0].url)
    # quote with safe='' encodes '/' as %2F
    assert "shift%2F01" in url
    await c.close()


@pytest.mark.asyncio
async def test_all_16_methods_are_callable():
    c = _client([(200, {})] * 16)
    await c.compliance.get_exception_report("2026-04-17")
    await c.compliance.get_daily_transactions("2026-04-17")
    await c.compliance.get_daily_results("2026-04-17")
    await c.compliance.get_daily_wagering_detail("2026-04-17")
    await c.compliance.get_daily_wagering_summary("2026-04-17")
    await c.compliance.get_past_post_report()
    await c.compliance.get_large_wagers()
    await c.compliance.get_structuring_alerts()
    await c.compliance.get_futures_reconciliation("2026-04-17")
    await c.compliance.get_accrual_recap("2026-04-17")
    await c.compliance.get_sport_statistics(2026, month=4)
    await c.compliance.get_customer_detail(1)
    await c.compliance.get_customer_summary(1)
    await c.compliance.get_cutoff_enforcement_log("2026-04-17")
    await c.compliance.get_operator_config_history()
    await c.compliance.get_shift_close_report("shift_01")
    assert c._test_calls["i"] == 16
    for req in c._test_calls["requests"]:
        assert "/admin/compliance/" in str(req.url)
    await c.close()
