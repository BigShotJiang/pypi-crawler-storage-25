"""Tests for the ParlayClient sub-client (SDK 2.0)."""
import httpx
import pytest

from edge_sdk import EdgeClient
from edge_sdk.types import (
    ParlayCreateRequest,
    ParlayLegCreate,
    ParlayLegResolveRequest,
)


def _client(responses: list[tuple[int, dict]]) -> EdgeClient:
    calls = {"i": 0, "requests": []}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["requests"].append(request)
        i = calls["i"]
        calls["i"] += 1
        status, body = responses[i]
        return httpx.Response(status, json=body, headers={"x-request-id": f"r{i}"})

    transport = httpx.MockTransport(handler)
    http = httpx.AsyncClient(
        transport=transport,
        base_url="https://api.test.com",
        headers={"X-API-Key": "k"},
    )
    c = EdgeClient(base_url="https://api.test.com", api_key="k", http_client=http)
    c._test_calls = calls  # type: ignore[attr-defined]
    return c


def _market_response() -> dict:
    return {
        "id": 1,
        "external_id": "mkt_parlay_1",
        "title": "2-leg parlay",
        "description": "",
        "category": "Sports",
        "subcategory": None,
        "event_start_time": None,
        "status": "OPEN",
        "prices": {"yes": 0.33, "no": 0.67},
        "volume": {"total": 0, "yes": 0, "no": 0},
        "lmsr_state": {"q_yes": 0, "q_no": 0, "b_effective": 1500, "b_base": 1500},
        "created_at": "2026-04-17T00:00:00Z",
        "total_fees_collected": 0.0,
    }


@pytest.mark.asyncio
async def test_create_parlay_posts_legs():
    c = _client([(201, _market_response())])
    r = await c.parlay.create_parlay(ParlayCreateRequest(
        legs=[
            ParlayLegCreate(description="Leg A", implied_probability=0.6),
            ParlayLegCreate(description="Leg B", implied_probability=0.55),
        ],
        category="Sports",
    ))
    assert r.external_id == "mkt_parlay_1"
    req = c._test_calls["requests"][0]
    assert req.method == "POST"
    assert str(req.url).endswith("/admin/markets/parlay")
    await c.close()


@pytest.mark.asyncio
async def test_resolve_parlay_leg_encodes_market_id():
    c = _client([(200, {"status": "leg_resolved"})])
    r = await c.parlay.resolve_parlay_leg(
        "mkt/parlay_1",
        ParlayLegResolveRequest(leg_number=2, outcome="WON"),
    )
    assert r["status"] == "leg_resolved"
    req = c._test_calls["requests"][0]
    # urllib.parse.quote(..., safe='') encodes '/' as %2F
    assert "mkt%2Fparlay_1" in str(req.url)
    await c.close()
