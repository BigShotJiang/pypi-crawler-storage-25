"""
Tests for EDGE Python SDK Client.
"""

import pytest

from edge_sdk.client import EdgeClient
from edge_sdk.exceptions import EdgeAPIError, EdgeAuthError, EdgeRateLimitError, EdgeValidationError
from edge_sdk.types import MarketListResponse, Market, QuoteResponse, TradeResponse, PortfolioSummary
from tests.conftest import MOCK_MARKET, MOCK_QUOTE, MOCK_TRADE, MOCK_PORTFOLIO


@pytest.mark.asyncio
async def test_list_markets(mock_client):
    client = mock_client([(200, {"markets": [MOCK_MARKET], "total": 1})])
    result = await client.list_markets()
    assert isinstance(result, MarketListResponse)
    assert result.total == 1
    assert result.markets[0].external_id == "mkt_abc123"
    await client.close()


@pytest.mark.asyncio
async def test_list_markets_with_filters(mock_client):
    client = mock_client([(200, {"markets": [], "total": 0})])
    result = await client.list_markets(status="OPEN", category="Sports", limit=10)
    assert result.total == 0
    await client.close()


@pytest.mark.asyncio
async def test_get_market(mock_client):
    client = mock_client([(200, MOCK_MARKET)])
    market = await client.get_market("mkt_abc123")
    assert isinstance(market, Market)
    assert market.title == "Will Team A win?"
    assert market.prices.yes == 0.55
    await client.close()


@pytest.mark.asyncio
async def test_create_market(mock_client):
    client = mock_client([(200, MOCK_MARKET)])
    market = await client.create_market(title="Test", category="Sports")
    assert isinstance(market, Market)
    await client.close()


@pytest.mark.asyncio
async def test_get_quote(mock_client):
    client = mock_client([(200, MOCK_QUOTE)])
    quote = await client.get_quote("mkt_abc123", side="YES", amount=100)
    assert isinstance(quote, QuoteResponse)
    assert quote.contracts == 180.5
    assert quote.fee_rate == 0.0175
    await client.close()


@pytest.mark.asyncio
async def test_execute_trade(mock_client):
    client = mock_client([(200, MOCK_TRADE)])
    trade = await client.execute_trade("mkt_abc123", side="YES", amount=100)
    assert isinstance(trade, TradeResponse)
    assert trade.trade_id == "trd_001"
    assert trade.new_balance == 1999898.25
    await client.close()


@pytest.mark.asyncio
async def test_execute_trade_with_slippage(mock_client):
    client = mock_client([(200, MOCK_TRADE)])
    trade = await client.execute_trade("mkt_abc123", side="YES", amount=100, max_avg_price=0.60)
    assert isinstance(trade, TradeResponse)
    await client.close()


@pytest.mark.asyncio
async def test_get_portfolio(mock_client):
    client = mock_client([(200, MOCK_PORTFOLIO)])
    portfolio = await client.get_portfolio()
    assert isinstance(portfolio, PortfolioSummary)
    assert portfolio.balance == 2000000
    await client.close()


@pytest.mark.asyncio
async def test_reset_sandbox(mock_client):
    client = mock_client([(200, {"status": "reset", "message": "Sandbox data cleared"})])
    result = await client.reset_sandbox()
    assert result["status"] == "reset"
    await client.close()


@pytest.mark.asyncio
async def test_health_check(mock_client):
    client = mock_client([(200, {"status": "healthy"})])
    result = await client.health_check()
    assert result["status"] == "healthy"
    await client.close()


# ── Error Handling ─────────────────────────────────────

@pytest.mark.asyncio
async def test_auth_error(mock_client):
    client = mock_client([(401, {"detail": "Invalid API key"})])
    with pytest.raises(EdgeAuthError) as exc_info:
        await client.list_markets()
    assert exc_info.value.status_code == 401
    assert "Invalid API key" in exc_info.value.detail
    await client.close()


@pytest.mark.asyncio
async def test_rate_limit_error(mock_client):
    client = mock_client([(429, {"detail": "Rate limit exceeded"})])
    with pytest.raises(EdgeRateLimitError):
        await client.list_markets()
    await client.close()


@pytest.mark.asyncio
async def test_validation_error(mock_client):
    client = mock_client([(422, {"detail": "Invalid input"})])
    with pytest.raises(EdgeValidationError):
        await client.create_market(title="", category="")
    await client.close()


@pytest.mark.asyncio
async def test_generic_api_error(mock_client):
    client = mock_client([(500, {"detail": "Internal server error"})])
    with pytest.raises(EdgeAPIError) as exc_info:
        await client.list_markets()
    assert exc_info.value.status_code == 500
    await client.close()


@pytest.mark.asyncio
async def test_context_manager():
    """Test async context manager protocol."""
    from tests.conftest import make_transport
    import httpx

    transport = make_transport([(200, {"markets": [], "total": 0})])
    http_client = httpx.AsyncClient(
        transport=transport,
        base_url="https://api.test.com",
        headers={"X-API-Key": "test", "Content-Type": "application/json"},
    )
    async with EdgeClient(base_url="https://api.test.com", api_key="test", http_client=http_client) as client:
        result = await client.list_markets()
        assert result.total == 0
