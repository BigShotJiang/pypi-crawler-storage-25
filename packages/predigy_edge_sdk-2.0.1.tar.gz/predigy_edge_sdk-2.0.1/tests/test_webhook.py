"""
Tests for EDGE Python SDK webhook signature verification.
"""

import hashlib
import hmac

import pytest

from edge_sdk.webhook import verify_signature


SECRET = "test-webhook-secret-abc123"


def _sign(payload: bytes, secret: str) -> str:
    """Compute an HMAC-SHA256 signature matching webhook_service.py."""
    sig = hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()
    return f"sha256={sig}"


def test_valid_signature():
    payload = b'{"event_type":"trade.executed","data":{}}'
    signature = _sign(payload, SECRET)
    assert verify_signature(payload, signature, SECRET) is True


def test_valid_signature_str_payload():
    payload_str = '{"event_type":"trade.executed","data":{}}'
    signature = _sign(payload_str.encode(), SECRET)
    assert verify_signature(payload_str, signature, SECRET) is True


def test_invalid_signature():
    payload = b'{"event_type":"trade.executed"}'
    bad_sig = "sha256=" + "0" * 64
    assert verify_signature(payload, bad_sig, SECRET) is False


def test_tampered_payload():
    original = b'{"event_type":"trade.executed"}'
    signature = _sign(original, SECRET)
    tampered = b'{"event_type":"TAMPERED"}'
    assert verify_signature(tampered, signature, SECRET) is False


def test_missing_prefix():
    payload = b'{"event_type":"trade.executed"}'
    sig = hmac.new(SECRET.encode(), payload, hashlib.sha256).hexdigest()
    # Missing "sha256=" prefix
    assert verify_signature(payload, sig, SECRET) is False


def test_empty_signature():
    assert verify_signature(b"payload", "", SECRET) is False
