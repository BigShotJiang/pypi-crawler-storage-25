"""Type-level tests for the SDK 2.0 WebhookEventName Literal union."""
from datetime import datetime, timezone
from typing import get_args

from pydantic import BaseModel

from edge_sdk.types import WebhookEventName, WebhookEventEnvelope


def test_event_name_union_matches_backend_valid_events():
    """WebhookEventName must exactly match the backend VALID_EVENTS set.

    Authoritative source: backend/src/services/webhook_service.py.
    The AuditLog action names (webhook.*, lp.config_updated) were
    included in 2.0.0 by mistake; they are NOT webhook events and are
    removed here.
    """
    from edge_sdk.types import (
        DispatchedWebhookEventName,
        ReservedWebhookEventName,
    )

    dispatched = set(get_args(DispatchedWebhookEventName))
    assert len(dispatched) == 12

    reserved = set(get_args(ReservedWebhookEventName))
    assert len(reserved) == 9

    names = set(get_args(WebhookEventName))
    assert len(names) == 21
    assert names == dispatched | reserved

    expected = {
        # Dispatched (fires today)
        "trade.executed",
        "market.created", "market.settled", "market.suspended", "market.unsuspended",
        "parlay.created", "parlay.leg_resolved",
        "lp.designated", "lp.revoked",
        "manipulation.detected",
        "feed.event_created", "feed.outcome_resolved",
        # Reserved (accepted for subscription, not yet dispatched)
        "surge.activated", "liquidity.adjusted",
        "risk.threshold_breached", "odds.drift_detected",
        "lp.trade_executed", "lp.balance_warning",
        "arbitrage.blocked",
        "compliance.large_wager", "compliance.structuring_alert",
    }
    assert names == expected


def test_webhook_envelope_with_typed_payload():
    class TradePayload(BaseModel):
        trade_id: str
        cost: float

    env: WebhookEventEnvelope[TradePayload] = WebhookEventEnvelope(
        event="trade.executed",
        payload=TradePayload(trade_id="trd_1", cost=10.0),
        timestamp=datetime.now(timezone.utc),
        operator_id=1,
    )
    assert env.event == "trade.executed"
    assert env.payload.cost == 10.0


def test_webhook_envelope_accepts_unparameterized_generic():
    """Unparameterized WebhookEventEnvelope accepts any payload type —
    used when the caller wants to pattern-match on event name before
    narrowing the payload."""
    env = WebhookEventEnvelope(
        event="compliance.structuring_alert",
        payload={"cumulative": 15000, "user_id": 42},
        timestamp=datetime.now(timezone.utc),
    )
    assert env.payload == {"cumulative": 15000, "user_id": 42}
