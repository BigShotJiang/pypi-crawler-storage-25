"""
EDGE SDK Exceptions

Typed error hierarchy for API, auth, and rate limit failures.
"""


class EdgeAPIError(Exception):
    """Base exception for EDGE API errors."""

    def __init__(self, status_code: int, detail: str, request_id: str | None = None):
        self.status_code = status_code
        self.detail = detail
        self.request_id = request_id
        super().__init__(f"EDGE API Error {status_code}: {detail}")


class EdgeAuthError(EdgeAPIError):
    """Raised on 401 Unauthorized responses."""

    def __init__(self, detail: str = "Invalid or missing API key", request_id: str | None = None):
        super().__init__(401, detail, request_id)


class EdgeRateLimitError(EdgeAPIError):
    """Raised on 429 Too Many Requests responses."""

    def __init__(
        self,
        detail: str = "Rate limit exceeded",
        retry_after: int | None = None,
        request_id: str | None = None,
    ):
        self.retry_after = retry_after
        super().__init__(429, detail, request_id)


class EdgeValidationError(EdgeAPIError):
    """Raised on 422 Unprocessable Entity responses."""

    def __init__(self, detail: str, request_id: str | None = None):
        super().__init__(422, detail, request_id)
