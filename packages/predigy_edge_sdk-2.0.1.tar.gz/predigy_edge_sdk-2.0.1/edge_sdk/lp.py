"""
LP sub-client (SDK 2.0).

Wraps /admin/lp/* endpoints for Liquidity Provider management:
designate, revoke, list, update config, per-LP dashboard/activity,
operator-wide analytics. Mirrors the JS ``client.lp.*`` surface.
"""
from __future__ import annotations

from urllib.parse import quote

from edge_sdk._http import HttpClient
from edge_sdk.types import (
    LPActivityItem,
    LPAnalyticsResponse,
    LPConfigUpdateRequest,
    LPDashboardResponse,
    LPDesignateRequest,
    LPDesignateResponse,
    LPRevokeRequest,
    LPUserResponse,
)


class LPClient:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def designate_lp(self, request: LPDesignateRequest) -> LPDesignateResponse:
        """Designate a user as a Liquidity Provider."""
        data = await self._http.request(
            "POST", "/admin/lp/designate", json=request.model_dump(mode="json")
        )
        return LPDesignateResponse.model_validate(data)

    async def revoke_lp(self, request: LPRevokeRequest) -> LPDesignateResponse:
        """Revoke LP status from a user."""
        data = await self._http.request(
            "POST", "/admin/lp/revoke", json=request.model_dump(mode="json")
        )
        return LPDesignateResponse.model_validate(data)

    async def list_lps(self) -> list[LPUserResponse]:
        """List all LP users for the current operator."""
        data = await self._http.request("GET", "/admin/lp/users")
        return [LPUserResponse.model_validate(u) for u in data]

    async def update_lp_config(
        self, user_external_id: str, request: LPConfigUpdateRequest
    ) -> LPUserResponse:
        """Update LP config (e.g. fee-tier, min_balance)."""
        data = await self._http.request(
            "PATCH",
            f"/admin/lp/users/{quote(user_external_id, safe='')}/config",
            json=request.model_dump(mode="json"),
        )
        return LPUserResponse.model_validate(data)

    async def get_dashboard(self, user_external_id: str) -> LPDashboardResponse:
        """Get LP performance dashboard for a specific LP user."""
        data = await self._http.request(
            "GET", "/admin/lp/dashboard",
            params={"user_external_id": user_external_id},
        )
        return LPDashboardResponse.model_validate(data)

    async def get_activity(
        self, user_external_id: str, limit: int | None = None
    ) -> list[LPActivityItem]:
        """Get recent LP trade activity."""
        data = await self._http.request(
            "GET", "/admin/lp/activity",
            params={"user_external_id": user_external_id, "limit": limit},
        )
        return [LPActivityItem.model_validate(item) for item in data]

    async def get_analytics(self) -> LPAnalyticsResponse:
        """Operator-wide LP analytics."""
        data = await self._http.request("GET", "/admin/lp/analytics")
        return LPAnalyticsResponse.model_validate(data)
