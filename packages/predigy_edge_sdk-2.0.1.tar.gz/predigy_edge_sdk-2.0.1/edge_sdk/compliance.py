"""
Compliance/MICS sub-client (SDK 2.0).

Wraps /admin/compliance/* — 16 MICS reports covering wagering detail,
cashier shift close, structuring alerts, large wagers, sport stats,
cutoff enforcement, customer transaction reports.

Reports return structured JSON that can vary in shape by period/date;
the SDK types them loosely as dict[str, Any] and leaves refinement to
the caller. LP/retail endpoints by contrast have strong Pydantic types.
"""
from __future__ import annotations

from typing import Any, Literal
from urllib.parse import quote

from edge_sdk._http import HttpClient

_Report = dict[str, Any]


class ComplianceClient:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def get_exception_report(self, date: str) -> _Report:
        return await self._http.request(
            "GET", "/admin/compliance/exception-report", params={"date": date}
        )

    async def get_daily_transactions(
        self, date: str, terminal_id: int | None = None
    ) -> _Report:
        return await self._http.request(
            "GET",
            "/admin/compliance/daily-transactions",
            params={"date": date, "terminal_id": terminal_id},
        )

    async def get_daily_results(self, date: str) -> _Report:
        return await self._http.request(
            "GET", "/admin/compliance/daily-results", params={"date": date}
        )

    async def get_daily_wagering_detail(
        self, date: str, terminal_id: int | None = None
    ) -> _Report:
        return await self._http.request(
            "GET",
            "/admin/compliance/daily-wagering-detail",
            params={"date": date, "terminal_id": terminal_id},
        )

    async def get_daily_wagering_summary(self, date: str) -> _Report:
        return await self._http.request(
            "GET", "/admin/compliance/daily-wagering-summary", params={"date": date}
        )

    async def get_past_post_report(
        self, date_from: str | None = None, date_to: str | None = None
    ) -> _Report:
        return await self._http.request(
            "GET",
            "/admin/compliance/past-post",
            params={"date_from": date_from, "date_to": date_to},
        )

    async def get_large_wagers(
        self, date_from: str | None = None, date_to: str | None = None
    ) -> _Report:
        return await self._http.request(
            "GET",
            "/admin/compliance/large-wagers",
            params={"date_from": date_from, "date_to": date_to},
        )

    async def get_structuring_alerts(
        self, date_from: str | None = None, date_to: str | None = None
    ) -> _Report:
        return await self._http.request(
            "GET",
            "/admin/compliance/structuring-alerts",
            params={"date_from": date_from, "date_to": date_to},
        )

    async def get_futures_reconciliation(self, date: str) -> _Report:
        return await self._http.request(
            "GET", "/admin/compliance/futures-reconciliation", params={"date": date}
        )

    async def get_accrual_recap(
        self, date: str, period: Literal["daily", "mtd"] = "daily"
    ) -> _Report:
        return await self._http.request(
            "GET",
            "/admin/compliance/accrual-recap",
            params={"date": date, "period": period},
        )

    async def get_sport_statistics(
        self,
        year: int,
        month: int | None = None,
        period: Literal["monthly", "ytd"] = "monthly",
    ) -> _Report:
        return await self._http.request(
            "GET",
            "/admin/compliance/sport-statistics",
            params={"year": year, "month": month, "period": period},
        )

    async def get_customer_detail(
        self,
        user_id: int,
        period: Literal["daily", "mtd", "ytd", "2year"] = "daily",
        date: str | None = None,
    ) -> _Report:
        return await self._http.request(
            "GET",
            f"/admin/compliance/customer/{user_id}/detail",
            params={"period": period, "date": date},
        )

    async def get_customer_summary(
        self,
        user_id: int,
        period: Literal["daily", "mtd", "ytd", "2year"] = "daily",
        date: str | None = None,
    ) -> _Report:
        return await self._http.request(
            "GET",
            f"/admin/compliance/customer/{user_id}/summary",
            params={"period": period, "date": date},
        )

    async def get_cutoff_enforcement_log(self, date: str) -> _Report:
        return await self._http.request(
            "GET",
            "/admin/compliance/cutoff-enforcement-log",
            params={"date": date},
        )

    async def get_operator_config_history(
        self, date_from: str | None = None, date_to: str | None = None
    ) -> _Report:
        return await self._http.request(
            "GET",
            "/admin/compliance/operator-config-history",
            params={"date_from": date_from, "date_to": date_to},
        )

    async def get_shift_close_report(self, shift_external_id: str) -> _Report:
        return await self._http.request(
            "GET",
            f"/admin/compliance/shift-close-report/{quote(shift_external_id, safe='')}",
        )
