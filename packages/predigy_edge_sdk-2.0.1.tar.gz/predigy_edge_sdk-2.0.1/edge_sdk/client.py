"""
EDGE by Predigy — Python SDK Client

Async HTTP client wrapping all EDGE API endpoints using httpx.
"""

from typing import Any, Literal

import httpx

from edge_sdk._http import HttpClient
from edge_sdk.compliance import ComplianceClient
from edge_sdk.lp import LPClient
from edge_sdk.parlay import ParlayClient
from edge_sdk.retail import RetailClient
from edge_sdk.types import (
    Market,
    MarketListResponse,
    QuoteResponse,
    TradeResponse,
    SellResponse,
    PortfolioSummary,
    PlatformStats,
    WebhookCreateResponse,
    WebhookResponse,
)


class EdgeClient:
    """
    Async client for the EDGE by Predigy API.

    Usage:
        async with EdgeClient(base_url="...", api_key="...") as client:
            markets = await client.list_markets()
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 30.0,
        http_client: httpx.AsyncClient | None = None,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self._owns_client = http_client is None
        self._client = http_client or httpx.AsyncClient(
            base_url=self.base_url,
            timeout=timeout,
            headers={
                "X-API-Key": api_key,
                "Content-Type": "application/json",
            },
        )

        # SDK 2.0 grouped sub-clients. Existing 1.x methods stay flat on
        # self; new retail/parlay/compliance/lp surfaces are grouped.
        self._http = HttpClient(self._client)
        self.retail = RetailClient(self._http)
        self.parlay = ParlayClient(self._http)
        self.compliance = ComplianceClient(self._http)
        self.lp = LPClient(self._http)

    async def __aenter__(self) -> "EdgeClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._owns_client:
            await self._client.aclose()

    # ── Internal Helpers ─────────────────────────────────────

    async def _request(
        self,
        method: str,
        path: str,
        json: dict | None = None,
        params: dict | None = None,
    ) -> Any:
        """Backward-compat shim for 1.x direct callers. New code (and
        all 2.0 sub-clients) route through ``self._http.request``
        directly; the two code paths are intentionally unified so
        error-mapping behavior stays in one place."""
        return await self._http.request(method, path, json=json, params=params)

    # ── Markets ──────────────────────────────────────────────

    async def list_markets(
        self,
        status: str | None = None,
        category: str | None = None,
        limit: int | None = None,
        offset: int | None = None,
    ) -> MarketListResponse:
        """List markets with optional filters."""
        data = await self._request(
            "GET", "/markets",
            params={"status": status, "category": category, "limit": limit, "offset": offset},
        )
        return MarketListResponse.model_validate(data)

    async def get_market(self, market_id: str) -> Market:
        """Get a single market by external ID."""
        data = await self._request("GET", f"/markets/{market_id}")
        return Market.model_validate(data)

    async def create_market(
        self,
        title: str,
        category: str,
        description: str | None = None,
        b_base: float | None = None,
        initial_price_yes: float | None = None,
    ) -> Market:
        """Create a new prediction market (admin)."""
        body: dict[str, Any] = {"title": title, "category": category}
        if description is not None:
            body["description"] = description
        if b_base is not None:
            body["b_base"] = b_base
        if initial_price_yes is not None:
            body["initial_price_yes"] = initial_price_yes
        data = await self._request("POST", "/admin/markets", json=body)
        return Market.model_validate(data)

    # ── Quotes & Trades ──────────────────────────────────────

    async def get_quote(
        self,
        market_id: str,
        side: Literal["YES", "NO"],
        amount: float,
    ) -> QuoteResponse:
        """Get a price quote for a trade."""
        data = await self._request(
            "POST", f"/markets/{market_id}/quote",
            json={"side": side, "amount": amount},
        )
        return QuoteResponse.model_validate(data)

    async def execute_trade(
        self,
        market_id: str,
        side: Literal["YES", "NO"],
        amount: float,
        max_avg_price: float | None = None,
    ) -> TradeResponse:
        """Execute a trade on a market."""
        body: dict[str, Any] = {"side": side, "amount": amount}
        if max_avg_price is not None:
            body["max_avg_price"] = max_avg_price
        data = await self._request("POST", f"/markets/{market_id}/trade", json=body)
        return TradeResponse.model_validate(data)

    async def sell_position(
        self,
        market_id: str,
        side: Literal["YES", "NO"],
        contracts: float,
    ) -> SellResponse:
        """Sell (cash out) contracts from a position."""
        data = await self._request(
            "POST", f"/markets/{market_id}/sell",
            json={"side": side, "contracts": contracts},
        )
        return SellResponse.model_validate(data)

    # ── Portfolio ────────────────────────────────────────────

    async def get_portfolio(self) -> PortfolioSummary:
        """Get the current user's portfolio."""
        data = await self._request("GET", "/portfolio")
        return PortfolioSummary.model_validate(data)

    # ── Admin ────────────────────────────────────────────────

    async def get_stats(self) -> PlatformStats:
        """Get platform statistics."""
        data = await self._request("GET", "/admin/stats")
        return PlatformStats.model_validate(data)

    async def settle_market(self, market_id: str, outcome: Literal["YES", "NO"]) -> dict:
        """Settle a market with an outcome (admin)."""
        return await self._request("POST", f"/admin/markets/{market_id}/settle", params={"outcome": outcome})

    async def reset_sandbox(self) -> dict:
        """Reset sandbox data for the current operator."""
        return await self._request("POST", "/admin/sandbox/reset")

    # ── Webhooks ─────────────────────────────────────────────

    async def create_webhook(
        self,
        url: str,
        events: list[str],
        description: str | None = None,
    ) -> WebhookCreateResponse:
        """Register a new webhook endpoint."""
        body: dict[str, Any] = {"url": url, "events": events}
        if description is not None:
            body["description"] = description
        data = await self._request("POST", "/webhooks", json=body)
        return WebhookCreateResponse.model_validate(data)

    async def list_webhooks(self) -> list[WebhookResponse]:
        """List all webhooks for the current operator."""
        data = await self._request("GET", "/webhooks")
        return [WebhookResponse.model_validate(w) for w in data]

    async def delete_webhook(self, webhook_id: str) -> None:
        """Delete a webhook by external ID."""
        await self._request("DELETE", f"/webhooks/{webhook_id}")

    # ── Health ───────────────────────────────────────────────

    async def health_check(self) -> dict:
        """Check API health."""
        return await self._request("GET", "/health")
