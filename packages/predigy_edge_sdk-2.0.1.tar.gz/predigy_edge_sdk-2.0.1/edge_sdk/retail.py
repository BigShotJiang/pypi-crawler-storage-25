"""
Retail sub-client (SDK 2.0).

Wraps /retail/* endpoints used by cashier flows: mint ticket, trade
against a ticket, redeem, cashout, status lookup. Mirrors the JS
SDK's ``client.retail.*`` surface.
"""
from __future__ import annotations

from urllib.parse import quote

from edge_sdk._http import HttpClient
from edge_sdk.types import (
    MintTicketRequest,
    MintTicketResponse,
    RetailCashoutRequest,
    RetailCashoutResponse,
    RetailRedeemResponse,
    RetailTicketStatusResponse,
    RetailTradeRequest,
    RetailTradeResponse,
)


class RetailClient:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def mint_ticket(self, request: MintTicketRequest) -> MintTicketResponse:
        """Mint a new retail ticket (ephemeral User) at a cashier terminal."""
        data = await self._http.request(
            "POST", "/retail/users", json=request.model_dump(mode="json")
        )
        return MintTicketResponse.model_validate(data)

    async def execute_retail_trade(
        self, ticket_ref: str, request: RetailTradeRequest
    ) -> RetailTradeResponse:
        """Execute a trade against a retail ticket. Debits ticket balance."""
        data = await self._http.request(
            "POST",
            f"/retail/tickets/{quote(ticket_ref, safe='')}/trade",
            json=request.model_dump(mode="json"),
        )
        return RetailTradeResponse.model_validate(data)

    async def redeem_ticket(self, ticket_ref: str) -> RetailRedeemResponse:
        """Redeem a winning retail ticket. Credits payout to ticket balance."""
        data = await self._http.request(
            "POST", f"/retail/tickets/{quote(ticket_ref, safe='')}/redeem"
        )
        return RetailRedeemResponse.model_validate(data)

    async def cashout_ticket(
        self, ticket_ref: str, request: RetailCashoutRequest
    ) -> RetailCashoutResponse:
        """Cash out the ticket's entire position on a given market+side."""
        data = await self._http.request(
            "POST",
            f"/retail/tickets/{quote(ticket_ref, safe='')}/cashout",
            json=request.model_dump(mode="json"),
        )
        return RetailCashoutResponse.model_validate(data)

    async def get_ticket_status(self, ticket_ref: str) -> RetailTicketStatusResponse:
        """Get current ticket status: balance, position count, redeemable."""
        data = await self._http.request(
            "GET", f"/retail/tickets/{quote(ticket_ref, safe='')}"
        )
        return RetailTicketStatusResponse.model_validate(data)
