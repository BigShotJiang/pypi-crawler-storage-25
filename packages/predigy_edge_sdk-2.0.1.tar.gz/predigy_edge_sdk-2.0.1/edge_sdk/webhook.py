"""
EDGE SDK — Webhook Signature Verification

Verifies HMAC-SHA256 signatures on incoming webhook deliveries.
Must match the signing logic in backend webhook_service.py:54-68.
"""

import hashlib
import hmac


def verify_signature(payload: bytes | str, signature: str, secret: str) -> bool:
    """
    Verify an EDGE webhook signature.

    The EDGE API signs payloads with HMAC-SHA256 and sends the signature
    in the ``X-Edge-Signature`` header as ``sha256=<hex_digest>``.

    Args:
        payload: Raw request body (bytes or str).
        signature: Value of the X-Edge-Signature header.
        secret: Your webhook signing secret (from webhook creation).

    Returns:
        True if the signature is valid, False otherwise.

    Example::

        from edge_sdk import verify_signature

        @app.post("/webhook")
        async def handle_webhook(request: Request):
            body = await request.body()
            sig = request.headers.get("X-Edge-Signature", "")
            if not verify_signature(body, sig, WEBHOOK_SECRET):
                raise HTTPException(401, "Invalid signature")
            # Process event...
    """
    if not signature or not signature.startswith("sha256="):
        return False

    expected_hex = signature[7:]  # Strip "sha256=" prefix

    if isinstance(payload, str):
        payload = payload.encode()

    computed = hmac.new(
        secret.encode(), payload, hashlib.sha256
    ).hexdigest()

    # Timing-safe comparison
    return hmac.compare_digest(computed, expected_hex)
