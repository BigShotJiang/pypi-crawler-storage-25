"""
EDGE SDK Types

Pydantic models mirroring the EDGE API response schemas.
"""

from datetime import datetime
from decimal import Decimal
from typing import Any, Generic, Literal, TypeVar

from pydantic import BaseModel, Field


class MarketPrices(BaseModel):
    yes: float
    no: float


class MarketVolume(BaseModel):
    total: float
    yes: float
    no: float


class LMSRState(BaseModel):
    q_yes: float
    q_no: float
    b_effective: float
    b_base: float


class Market(BaseModel):
    id: int
    external_id: str
    title: str
    description: str | None = None
    category: str
    subcategory: str | None = None
    event_start_time: datetime | None = None
    status: str
    prices: MarketPrices
    volume: MarketVolume
    lmsr_state: LMSRState
    created_at: datetime
    total_fees_collected: float


class MarketListResponse(BaseModel):
    markets: list[Market]
    total: int


class QuoteResponse(BaseModel):
    side: str
    amount: float
    contracts: float
    avg_fill_price: float
    fee: float
    fee_rate: float
    total_cost: float
    new_prices: MarketPrices
    potential_payout: float
    potential_return_pct: float
    slippage_bps: float = 0.0
    price_impact_pct: float = 0.0
    warning_level: str = "NONE"
    rebate_rate: float = 0.0
    rebate_amount: float = 0.0


class TradeResponse(BaseModel):
    trade_id: str
    market_id: str
    side: str
    contracts: float
    cost: float
    fee: float
    fee_rate: float
    price_at_trade: float
    avg_fill_price: float
    new_prices: MarketPrices
    new_balance: float
    risk_level: str = "NORMAL"


class SellResponse(BaseModel):
    trade_id: str
    market_id: str
    side: str
    contracts_sold: float
    gross_revenue: float
    fee: float
    fee_rate: float
    net_payout: float
    new_prices: MarketPrices
    new_balance: float


class Position(BaseModel):
    market_id: str
    market_external_id: str
    market_title: str
    side: str
    contracts: float
    avg_price: float
    total_cost: float
    current_price: float
    market_value: float
    unrealized_pnl: float
    unrealized_pnl_pct: float
    is_settled: bool


class PortfolioSummary(BaseModel):
    balance: float
    total_invested: float
    total_market_value: float
    total_unrealized_pnl: float
    positions: list[Position]


class PlatformStats(BaseModel):
    total_markets: int
    open_markets: int
    total_trades: int
    total_users: int
    total_volume: float
    total_fees_collected: float


class WebhookResponse(BaseModel):
    id: int
    external_id: str
    url: str
    events: list[str]
    is_active: bool
    description: str | None = None
    created_at: datetime
    updated_at: datetime


class WebhookCreateResponse(BaseModel):
    webhook: WebhookResponse
    secret: str = Field(description="HMAC signing secret — store securely, shown only once")


# ── Retail Types (SDK 2.0) ────────────────────────────────────


class MintTicketRequest(BaseModel):
    terminal_external_id: str
    cashier_shift_external_id: str
    customer_display_name: str = "Retail Customer"


class MintTicketResponse(BaseModel):
    ticket_ref: str
    user_external_id: str
    terminal_external_id: str
    cashier_shift_external_id: str
    created_at: datetime


class RetailTradeRequest(BaseModel):
    market_id: str
    side: Literal["YES", "NO"]
    amount: Decimal


class RetailTradeResponse(BaseModel):
    ticket_ref: str
    contracts: Decimal
    cost: Decimal
    fee: Decimal
    avg_fill_price: Decimal
    new_balance: Decimal


class RetailCashoutRequest(BaseModel):
    market_id: str
    side: Literal["YES", "NO"]


class RetailCashoutResponse(BaseModel):
    ticket_ref: str
    contracts_sold: Decimal
    payout: Decimal
    fee: Decimal
    new_balance: Decimal


class RetailRedeemResponse(BaseModel):
    ticket_ref: str
    payout_amount: Decimal
    status: Literal["redeemed", "loss"]


class RetailTicketStatusResponse(BaseModel):
    ticket_ref: str
    is_retail: bool
    balance: Decimal
    position_count: int
    redeemable: bool


# ── Parlay Types (SDK 2.0) ────────────────────────────────────


class ParlayLegCreate(BaseModel):
    description: str
    implied_probability: float | None = None
    american_odds: int | None = None
    event_ref: str | None = None
    linked_market_id: int | None = None


class ParlayCreateRequest(BaseModel):
    legs: list[ParlayLegCreate] = Field(..., min_length=2, max_length=3)
    title: str | None = None
    category: str = "Sports"
    subcategory: str | None = None
    b_base: float = 1500.0
    initial_price_yes_override: float | None = None


class ParlayLegResolveRequest(BaseModel):
    leg_number: int = Field(..., ge=1, le=3)
    outcome: Literal["WON", "LOST", "VOID"]


# ── LP Types (SDK 2.0) ────────────────────────────────────────


class LPDesignateRequest(BaseModel):
    user_external_id: str
    lp_config: dict[str, Any] | None = None


class LPRevokeRequest(BaseModel):
    user_external_id: str


class LPConfigUpdateRequest(BaseModel):
    lp_config: dict[str, Any] | None


class LPDesignateResponse(BaseModel):
    user_external_id: str
    display_name: str
    is_liquidity_provider: bool
    lp_designated_at: datetime | None
    lp_config: dict[str, Any] | None


class LPUserResponse(BaseModel):
    external_id: str
    display_name: str
    balance: Decimal
    is_liquidity_provider: bool
    lp_config: dict[str, Any] | None
    lp_designated_at: datetime | None


class LPDashboardResponse(BaseModel):
    total_trades: int
    total_volume: float
    total_fees_paid: float
    total_rebates: float
    avg_fee_rate: float
    markets_served: int


class LPActivityItem(BaseModel):
    trade_id: str
    market_id: str
    side: str
    contracts: Decimal
    cost: Decimal
    fee: Decimal
    created_at: datetime


class LPAnalyticsResponse(BaseModel):
    total_lp_users: int
    active_lps: int
    total_volume: float
    total_rebates: float


# ── Webhook Event Types (SDK 2.0) ─────────────────────────────
#
# Mirrors the backend's VALID_EVENTS set in
# backend/src/services/webhook_service.py — the authoritative list
# of event names an operator can subscribe to.
#
# Two subsets:
#   DispatchedWebhookEventName: fires in prod today (12). Grep confirms
#     a dispatch_event("<name>", ...) call site.
#   ReservedWebhookEventName: accepted by subscribe validation but not
#     yet dispatched (9). Subscribing now means your handler will start
#     receiving these the moment the server wires them up.
#
# AuditLog action names (webhook.*, lp.config_updated) are NOT webhook
# events — they land in /admin/compliance/operator-config-history
# reports, not on your webhook endpoint. They were included in 2.0.0
# by mistake and are removed here.

DispatchedWebhookEventName = Literal[
    "trade.executed",
    "market.created",
    "market.settled",
    "market.suspended",
    "market.unsuspended",
    "parlay.created",
    "parlay.leg_resolved",
    "lp.designated",
    "lp.revoked",
    "manipulation.detected",
    "feed.event_created",
    "feed.outcome_resolved",
]

ReservedWebhookEventName = Literal[
    "surge.activated",
    "liquidity.adjusted",
    "risk.threshold_breached",
    "odds.drift_detected",
    "lp.trade_executed",
    "lp.balance_warning",
    "arbitrage.blocked",
    "compliance.large_wager",
    "compliance.structuring_alert",
]

# Union of both categories — what a subscribe call will accept.
# `Literal[*A, *B]` isn't quite right at type-checker level, so we
# enumerate. Keep this in sync with the two constants above.
WebhookEventName = Literal[
    # Dispatched
    "trade.executed",
    "market.created",
    "market.settled",
    "market.suspended",
    "market.unsuspended",
    "parlay.created",
    "parlay.leg_resolved",
    "lp.designated",
    "lp.revoked",
    "manipulation.detected",
    "feed.event_created",
    "feed.outcome_resolved",
    # Reserved
    "surge.activated",
    "liquidity.adjusted",
    "risk.threshold_breached",
    "odds.drift_detected",
    "lp.trade_executed",
    "lp.balance_warning",
    "arbitrage.blocked",
    "compliance.large_wager",
    "compliance.structuring_alert",
]


TPayload = TypeVar("TPayload")


class WebhookEventEnvelope(BaseModel, Generic[TPayload]):
    """Envelope sent by EDGE for every webhook delivery. Payload shape
    is event-specific; parameterize on your own BaseModel subclass
    when you want strong typing. Parameterizing with ``dict`` is
    unsupported — use a plain ``dict[str, Any]`` attribute on your
    own subclass instead."""

    model_config = {"arbitrary_types_allowed": True}

    event: WebhookEventName
    payload: TPayload
    timestamp: datetime
    operator_id: int | None = None
