"""
Internal HTTP client for EdgeClient and all 2.0 sub-clients.

Kept in a leading-underscore module so it stays private. Sub-clients
receive an instance via constructor injection. Same status-code -> typed
error mapping the 1.x EdgeClient._request used, now shareable.
"""
from __future__ import annotations

from typing import Any

import httpx

from edge_sdk.exceptions import (
    EdgeAPIError,
    EdgeAuthError,
    EdgeRateLimitError,
    EdgeValidationError,
)


class HttpClient:
    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client

    @property
    def raw(self) -> httpx.AsyncClient:
        """Raw httpx client — exposed so EdgeClient.close() can reach it."""
        return self._client

    async def request(
        self,
        method: str,
        path: str,
        json: dict | None = None,
        params: dict | None = None,
    ) -> Any:
        """Make an authenticated API request with typed-error mapping."""
        if params:
            params = {k: v for k, v in params.items() if v is not None}

        response = await self._client.request(method, path, json=json, params=params)
        request_id = response.headers.get("x-request-id")

        if response.status_code == 401:
            raise EdgeAuthError(self._detail(response), request_id)
        if response.status_code == 429:
            retry_after = response.headers.get("retry-after")
            raise EdgeRateLimitError(
                self._detail(response),
                int(retry_after) if retry_after else None,
                request_id,
            )
        if response.status_code == 422:
            raise EdgeValidationError(self._detail(response), request_id)
        if response.status_code >= 400:
            raise EdgeAPIError(response.status_code, self._detail(response), request_id)

        if response.status_code == 204:
            return None
        return response.json()

    @staticmethod
    def _detail(response: httpx.Response) -> str:
        try:
            body = response.json()
            return body.get("detail", response.reason_phrase or "Unknown error")
        except Exception:
            return response.reason_phrase or "Unknown error"
