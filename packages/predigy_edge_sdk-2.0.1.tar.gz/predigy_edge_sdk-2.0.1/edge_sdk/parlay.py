"""
Parlay sub-client (SDK 2.0).

Wraps /admin/markets/parlay/* for creating 2-3 leg parlay markets
and resolving individual legs.
"""
from __future__ import annotations

from urllib.parse import quote
from typing import Any

from edge_sdk._http import HttpClient
from edge_sdk.types import Market, ParlayCreateRequest, ParlayLegResolveRequest


class ParlayClient:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def create_parlay(self, request: ParlayCreateRequest) -> Market:
        """Create a 2-3 leg parlay market."""
        data = await self._http.request(
            "POST", "/admin/markets/parlay", json=request.model_dump(mode="json")
        )
        return Market.model_validate(data)

    async def resolve_parlay_leg(
        self, market_id: str, request: ParlayLegResolveRequest
    ) -> dict[str, Any]:
        """Resolve one leg of an existing parlay market."""
        data = await self._http.request(
            "POST",
            f"/admin/markets/parlay/{quote(market_id, safe='')}/resolve-leg",
            json=request.model_dump(mode="json"),
        )
        return data
