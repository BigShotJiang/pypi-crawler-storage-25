from .trade import FuturesTrade
from .market import FuturesMarket

class Futures:
    """币安合约 API"""
    def __init__(self, client):
        self.client = client
        self.market = FuturesMarket(client)
        self.trade = FuturesTrade(client)

    def get_prices_futures(self, coin):
        """获取最新价格"""
        return self.market.get_prices_futures(coin)
    def get_coin_info_futures(self, coin):
        """获取代币合约交易状态"""
        return self.market.get_coin_info_futures(coin)

    def get_coin_config_futures(self, coin):
        """获取代币合约配置-杠杆配置信息"""
        return self.market.get_coin_config_futures(coin)

    def set_coin_lever_futures(self, coin, lever):
        """设置代币合约杠杆倍数"""
        return self.market.set_coin_lever_futures(coin, lever)

    def set_margin_type_futures(self, coin, margin_mode="ISOLATED"):
        """设置全仓/逐仓模式"""
        return self.market.set_margin_type_futures(coin, margin_mode)

    def order_futures(self, coin, side, order_type, size, stop_loss_price=None):
        """开仓下单"""
        return self.trade.order_futures(coin, side, order_type, size, stop_loss_price)

    def set_stop_loss_futures(self, coin, side, size, stop_price):
        """设置止损"""
        return self.trade.set_stop_loss_futures(coin, side, size, stop_price)

    def set_take_profit_futures(self, coin, side, size, tp_price):
        """设置止盈"""
        return self.trade.set_take_profit_futures(coin, side, size, tp_price)

    def update_stop_loss_futures(self, coin, side, size, stop_price):
        """修改止损"""
        return self.trade.update_stop_loss_futures(coin, side, size, stop_price)

    def update_take_profit_futures(self, coin, side, size, tp_price):
        """修改止盈"""
        return self.trade.update_take_profit_futures(coin, side, size, tp_price)

    def close_position_futures(self, coin, side, order_type, size):
        """平仓"""
        return self.trade.close_position_futures(coin, side, order_type, size)

    def get_position_futures(self, coin):
        """查询持仓"""
        return self.trade.get_position_futures(coin)

    def get_recent_pnl(self, coin):
        """获取最近一笔平仓的已实现盈亏"""
        return self.trade.get_recent_pnl(coin)