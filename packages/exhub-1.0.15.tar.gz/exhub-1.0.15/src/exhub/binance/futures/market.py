from decimal import Decimal
from loguru import logger
from exhub.common import Common

class FuturesMarket:
    """币安合约市场"""
    def __init__(self, client):
        self.client = client

    def get_prices_futures(self,coin):
        """
        获取指定代币对价格
        GET /fapi/v2/ticker/price
        https://developers.binance.com/docs/zh-CN/derivatives/usds-margined-futures/market-data/rest-api/Symbol-Price-Ticker-v2
        """
        path = "/fapi/v2/ticker/price"
        params = {"symbol": coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"}
        res = self.client.get(path, params=params, signed=False)
        logger.debug(res)
        if res:
            coin = res.get("symbol")
            price = res.get("price")
            ts = res.get("time")
            return Common().return_futures_price_struct("BINANCE", coin, price, ts)
        return None

    def get_coin_info_futures(self, coin):
        """
        获取合约交易规范信息(获取代币合约交易状态)
        GET /fapi/v1/exchangeInfo
        https://developers.binance.com/docs/zh-CN/derivatives/usds-margined-futures/market-data/rest-api/Exchange-Information
        """
        path = "/fapi/v1/exchangeInfo"
        params = {"symbol": coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"}
        res = self.client.get(path, params=params, signed=False)
        # logger.debug(res) # 数据太大 不放便打印
        data = res.get("symbols", [])
        for item in data:
            if item.get("symbol") == (coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"):
                logger.debug(item)
                coin = item.get("symbol")
                swap_status = item.get("status") == "TRADING"
                
                # 从 filters 中提取精度
                filters = item.get("filters", [])
                min_unit = "0.01" # 默认值
                price_unit = "0.01" # 默认值
                for f in filters:
                    if f.get("filterType") == "LOT_SIZE":
                        min_unit = f.get("stepSize")
                    elif f.get("filterType") == "PRICE_FILTER":
                        price_unit = f.get("tickSize")
                
                max_lever = 10
                min_lever = 1
                try:
                    lever_res = self.client.get("/fapi/v1/leverageBracket", signed=True)
                    if isinstance(lever_res, list):
                        for bracket_data in lever_res:
                            if bracket_data.get("symbol") == coin:
                                brackets = bracket_data.get("brackets", [])
                                if brackets:
                                    max_lever_val = max(b.get("initialLeverage", 1) for b in brackets)
                                    max_lever = max_lever_val
                                break
                except Exception as e:
                    logger.error(f"BINANCE 获取杠杆信息异常: {e}")

                return Common().return_futures_coin_info_struct("BINANCE", coin, swap_status, min_unit, price_unit, min_lever, max_lever, Decimal('1.0'))

        # 未找到匹配的合约
        return Common().return_futures_coin_info_struct("BINANCE", coin, False, "0.01", "0.01", 1, 125, Decimal('1.0'))

    def get_coin_config_futures(self, coin):
        """
        获取合约代币的配置-杠杆配置信息
        GET /fapi/v1/symbolConfig
        https://developers.binance.com/docs/zh-CN/derivatives/usds-margined-futures/account/rest-api/Symbol-Config
        :param coin:
        :return:
        """
        path = "/fapi/v1/symbolConfig"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        params = {"symbol": symbol}
        res = self.client.get(path, params=params, signed=True)
        logger.debug(res)
        leverage = 0
        margin_mode = "cross"
        if res:
            for item in res:
                if item.get("symbol") == symbol:
                    leverage = item.get("leverage", 0)
                    margin_mode_raw = item.get("marginType", "").lower()
                    if margin_mode_raw == "crossed": 
                        margin_mode = "cross"
                    else:
                        margin_mode = margin_mode_raw
        return Common().return_futures_coin_config_struct("BINANCE", coin, leverage, margin_mode)

    def set_margin_type_futures(self, coin, margin_mode="isolated"):
        """
        变换逐全仓模式
        :param coin:
        :param margin_mode: cross (全仓), isolated (逐仓)
        """
        path = "/fapi/v1/marginType"
        params = {
            "symbol": coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT",
            "marginType": "ISOLATED"
        }
        try:
            res = self.client.post(path, params=params, signed=True)
            logger.debug(f"BINANCE 设置逐仓模式: {res}")
            return res
        except Exception as e:
            if "No need to change margin type" in str(e) or "-4046" in str(e):
                logger.info(f"BINANCE {coin} 已经是逐仓模式，无需修改。")
                return {"msg": "already in isolated"}
            logger.error(f"BINANCE {coin} 设置逐仓模式异常: {e}")
            return None

    def set_coin_lever_futures(self, coin, lever):
        """设置杠杆倍数 (Binance 不区分多空方向)
        :param coin: 币名
        :param lever: 杠杆倍数
        """
        path = "/fapi/v1/leverage"
        params = {"symbol": coin.upper() if coin.endswith("USDT") else coin.upper()+"USDT", "leverage": int(lever)}
        res = self.client.post(path, params=params, signed=True)
        logger.debug(res)
        return self.get_coin_config_futures(coin)
