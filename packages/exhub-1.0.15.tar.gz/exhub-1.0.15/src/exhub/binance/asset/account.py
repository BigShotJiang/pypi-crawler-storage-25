from loguru import logger
from exhub.config import Config
from exhub.common import Common

class Account:
    """账户接口"""
    def __init__(self, client):
        self.client = client

    def get_balances(self, coin, asset_type):
        """
        查询用户钱包余额 (USER_DATA)
        :param coin: 计价资产 (如 USDT, ETH, USDC, BNB), 默认 BTC
        :param asset_type: 资产类型 ***
        """
        if asset_type == "spot":
            path = "/api/v3/account"
            res = self.client.get(path, signed=True)
            logger.debug(res)
            for type_data in res["balances"]:
                if type_data.get("asset") == coin:
                    return Common().return_asset_struct("BINANCE", asset_type, coin, type_data["free"])
        elif asset_type == "fund":
            path = "/sapi/v1/asset/get-funding-asset"
            params = {"asset": coin}
            res = self.client.post(path, params=params, signed=True)
            logger.debug(res)
            for type_data in res:
                if type_data.get("asset") == coin:
                    return Common().return_asset_struct("BINANCE", asset_type, coin, type_data["free"])
        elif asset_type == "futures":
            path = "/fapi/v3/balance"
            res = self.client.get(path, signed=True)
            logger.debug(res)
            for type_data in res:
                if type_data.get("asset") == coin:
                    return Common().return_asset_struct("BINANCE", asset_type, coin, type_data["balance"])
        return None



    def transfer(self, type_from, type_to, coin, amount, fromSymbol=None, toSymbol=None):
        """
        用户万向划转 (USER_DATA)
        POST /sapi/v1/asset/transfer
        """
        path = "/sapi/v1/asset/transfer"
        params = {
            "type": Config().unify_variables_transfer_type("BINANCE", type_from, type_to),
            "asset": coin,
            "amount": amount
        }
        if fromSymbol:
            params["fromSymbol"] = fromSymbol
        if toSymbol:
            params["toSymbol"] = toSymbol

        res = self.client.post(path, params=params, signed=True)
        return Common().return_transfer_struct("BINANCE", type_from, type_to, coin, amount,res)
