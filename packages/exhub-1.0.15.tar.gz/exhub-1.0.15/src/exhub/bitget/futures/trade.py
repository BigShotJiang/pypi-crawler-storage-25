from loguru import logger
from exhub.common import Common

class FuturesTrade:
    """Bitget 合约交易实现"""
    def __init__(self, client):
        self.client = client

    def order_futures(self, coin, side, order_type, size, stop_loss_price=None):
        """
        开仓下单 (TRADE)
        POST /api/v2/mix/order/place-order
        :param stop_loss_price: 仅作接口占位，Bitget 预设止损属于部分止损；
                                实际止损单由 hub 层在开仓成功后单独补挂 (pos_loss 全平模式)
        """
        path = "/api/v2/mix/order/place-order"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"

        body = {
            "symbol": symbol,
            "productType": "USDT-FUTURES",
            "marginMode": "isolated",
            "marginCoin": "USDT",
            "size": str(size),
            "side": side.lower(),
            "orderType": "market",
            "tradeSide": "open"
        }


        res = self.client.post(path, body=body)
        logger.debug(res)
        if res.get("code") == "00000":
            orderId = res.get("data")["orderId"]
            logger.success(f'开仓成功: {orderId}')
            return Common().return_futures_order_struct("BITGET", coin, side, order_type, size, orderId, res)
        else:
            raise Exception(res.get("msg", "Unknown error"))

    def close_position_futures(self, coin, side, order_type, size):
        """
        平仓 (Close Position)
        POST /api/v2/mix/order/place-order
        :param coin: 币本位合约 (如 BTCUSDT)
        :param side: 开仓方向 (BUY/SELL) 或持仓方向 (LONG/SHORT)
        :param order_type: 订单类型 market
        :param size: 数量
        """
        path = "/api/v2/mix/order/place-order"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"

        hold_side = self._normalize_hold_side(side)
        order_side = "buy" if hold_side == "long" else "sell"

        body = {
            "symbol": symbol,
            "productType": "USDT-FUTURES",
            "marginMode": "isolated",
            "marginCoin": "USDT",
            "size": str(size),
            "side": order_side,
            "orderType": "market",
            "tradeSide": "close",
            "posSide": hold_side
        }
        res = self.client.post(path, body=body)
        logger.debug(res)
        if res.get("code") == "00000":
            orderId = res.get("data")["orderId"]
            logger.success(f'平仓成功: {orderId}')
            return Common().return_futures_order_struct("BITGET", coin, side, order_type, size, orderId, res)
        else:
            raise Exception(res.get("msg", "Unknown error"))

    def get_position_futures(self, coin):
        """
        获取仓位信息 (Get Position)
        GET /api/v2/mix/position/single-position
        :param coin: 币本位合约 (如 BTCUSDT)
        :return: list of positions [dict] or []
        """
        path = "/api/v2/mix/position/single-position"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        params = {
            "symbol": symbol,
            "productType": "USDT-FUTURES",
            "marginCoin": "USDT"
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        
        pending_plans = []
        try:
            res_pending = self.client.get("/api/v2/mix/order/orders-plan-pending", params={"symbol": symbol, "productType": "USDT-FUTURES", "planType": "profit_loss"})
            if res_pending.get("code") == "00000" and res_pending.get("data") and res_pending["data"].get("entrustedList"):
                pending_plans = res_pending["data"]["entrustedList"]
        except Exception as e:
            logger.warning(f"Bitget 获取当前挂单(止盈止损)失败: {e}")

        positions = []
        if res.get("code") == "00000":
            for item in res["data"]:
                size = float(item.get("total", 0))
                if size != 0:
                    hold_side = item.get("holdSide", "")
                    pos_side = hold_side.upper()
                    entry_price = float(item.get("openPriceAvg", 0))
                    unrealized_profit = item.get("unrealizedPL", 0)
                    liquidation_price = item.get("liquidationPrice", 0)
                    
                    all_stop_loss_price = ""
                    all_take_profit_price = ""
                    partial_stop_loss = {"size": "0", "price": "0"}
                    partial_take_profit = {"size": "0", "price": "0"}
                    
                    for p in pending_plans:
                        if p.get("posSide") == hold_side:
                            ptype = p.get("planType")
                            trigger = p.get("triggerPrice", "")
                            sz = p.get("size", "")
                            if ptype == "pos_loss":
                                all_stop_loss_price = trigger
                            elif ptype == "pos_profit":
                                all_take_profit_price = trigger
                            elif ptype == "loss_plan":
                                partial_stop_loss = {"size": str(sz), "price": str(trigger)}
                            elif ptype == "profit_plan":
                                partial_take_profit = {"size": str(sz), "price": str(trigger)}
                    
                    pos_info = Common().return_futures_position_struct(
                        coin, size, entry_price, pos_side, unrealized_profit, liquidation_price, 
                        all_stop_loss_price, all_take_profit_price, partial_stop_loss, partial_take_profit, item
                    )
                    positions.append(pos_info)
        else:
            raise Exception(res.get("msg", "Unknown error"))
        return {"BITGET": positions}

    @staticmethod
    def _normalize_hold_side(side: str) -> str:
        """
        Bitget holdSide 只接受 long/short，兼容 BUY/SELL 与 LONG/SHORT 两种传参风格。
        BUY  → long，SELL → short，LONG → long，SHORT → short
        """
        s = side.upper()
        return "long" if s in ("BUY", "LONG") else "short"

    def set_stop_loss_futures(self, coin, side, size, stop_price):
        """
        设置/修改止损
        :param side: 持仓方向，兼容 BUY/SELL 与 LONG/SHORT
        :param size: 数量，如果不传则默认为持仓止损模式 (全平)
        """
        path = "/api/v2/mix/order/place-tpsl-order"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        hold_side = self._normalize_hold_side(side)

        body = {
            "symbol": symbol,
            "productType": "USDT-FUTURES",
            "marginCoin": "USDT",
            "triggerPrice": str(stop_price),
            "triggerType": "mark_price",
            "holdSide": hold_side,
            "executePrice": "0"
        }

        if size:
            body["planType"] = "loss_plan"  # 普通止损计划
            body["size"] = str(size)
        else:
            body["planType"] = "pos_loss"  # 持仓止损模式 (全平)

        res = self.client.post(path, body=body)
        logger.debug(f"Bitget set stop loss: {res}")
        status = res.get("code") == "00000"
        return Common().return_set_stop_loss_struct("BITGET", coin, status, res)

    def set_take_profit_futures(self, coin, side, size, tp_price):
        """
        设置/修改止盈
        :param side: 持仓方向，兼容 BUY/SELL 与 LONG/SHORT
        :param size: 数量，如果不传则默认为持仓止盈模式 (全平)
        """
        path = "/api/v2/mix/order/place-tpsl-order"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        #_normalize_hold_side 统一转换
        hold_side = self._normalize_hold_side(side)

        body = {
            "symbol": symbol,
            "productType": "USDT-FUTURES",
            "marginCoin": "USDT",
            "triggerPrice": str(tp_price),
            "triggerType": "mark_price",
            "holdSide": hold_side,
            "executePrice": "0"
        }

        if size:
            body["planType"] = "profit_plan"  # 普通止盈计划
            body["size"] = str(size)
        else:
            body["planType"] = "pos_profit"  # 持仓止盈模式 (全平)

        res = self.client.post(path, body=body)
        logger.debug(f"Bitget set take profit: {res}")
        status = res.get("code") == "00000"
        return Common().return_set_take_profit_struct("BITGET", coin, status, res)

    def update_take_profit_futures(self, coin, side, size, tp_price):
        """修改止盈 (自动覆盖)"""
        if size:
            symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
            hold_side = self._normalize_hold_side(side)
            try:
                params = {
                    "symbol": symbol,
                    "productType": "USDT-FUTURES",
                    "planType": "profit_loss"
                }
                res = self.client.get("/api/v2/mix/order/orders-plan-pending", params=params)
                if res.get("code") == "00000" and res.get("data") and res["data"].get("entrustedList"):
                    for o in res["data"]["entrustedList"]:
                        # 找到对应的部分止盈单并撤销
                        if o.get("planType") == "profit_plan" and o.get("posSide") == hold_side:
                            cancel_body = {
                                "symbol": symbol,
                                "productType": "USDT-FUTURES",
                                "marginCoin": "USDT",
                                "orderId": o["orderId"],
                                "planType": "profit_plan"
                            }
                            self.client.post("/api/v2/mix/order/cancel-plan-order", body=cancel_body)
            except Exception as e:
                logger.warning(f"Bitget 更新部分止盈撤旧单异常: {e}")

        return self.set_take_profit_futures(coin, side, size, tp_price)

    def get_recent_pnl(self, coin):
        """
        获取最近一笔平仓的已实现盈亏
        GET /api/v2/mix/position/history-position
        """
        path = "/api/v2/mix/position/history-position"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        params = {
            "symbol": symbol,
            "productType": "USDT-FUTURES",
            "marginCoin": "USDT",
            "limit": "1"
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        pnl = 0.0
        if res.get("code") == "00000" and res.get("data") and res["data"].get("list"):
            pnl = float(res["data"]["list"][0].get("netProfit", 0))
        return Common().return_pnl_struct("BITGET", coin, pnl)

    def update_stop_loss_futures(self, coin, side, size, stop_price):
        """
        修改止损：
        Bitget 的 pos_loss 模式（全部仓位）下，再次调用 place-tpsl-order 会自动覆盖之前的持仓止损。
        但在 loss_plan 模式（部分仓位）下，订单会累加。因此对于部分仓位更新，先查旧单并撤销。
        """
        if size:
            symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
            hold_side = self._normalize_hold_side(side)
            try:
                params = {
                    "symbol": symbol,
                    "productType": "USDT-FUTURES",
                    "planType": "profit_loss"
                }
                res = self.client.get("/api/v2/mix/order/orders-plan-pending", params=params)
                if res.get("code") == "00000" and res.get("data") and res["data"].get("entrustedList"):
                    for o in res["data"]["entrustedList"]:
                        # 找到对应的部分止损单并撤销
                        if o.get("planType") == "loss_plan" and o.get("posSide") == hold_side:
                            cancel_body = {
                                "symbol": symbol,
                                "productType": "USDT-FUTURES",
                                "marginCoin": "USDT",
                                "orderId": o["orderId"],
                                "planType": "loss_plan"
                            }
                            self.client.post("/api/v2/mix/order/cancel-plan-order", body=cancel_body)
            except Exception as e:
                logger.warning(f"Bitget 更新部分止损撤旧单异常: {e}")

        return self.set_stop_loss_futures(coin, side, size, stop_price)