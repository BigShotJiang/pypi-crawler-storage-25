from decimal import Decimal
import time
from loguru import logger
from exhub.common import Common

class FuturesMarket():
    """Bitget 合约市场"""
    def __init__(self, client):
        self.client = client

    def get_prices_futures(self, coin):
        """
        获取指定代币对价格
        GET /api/v2/mix/market/ticker
        https://www.bitget.com/zh-CN/api-doc/contract/market/Get-Tickers
        """
        path = "/api/v2/mix/market/ticker"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        params = {
            "symbol": symbol,
            "productType": "USDT-FUTURES"
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        if res and res.get("code") == "00000" and res.get("data"):
            data = res["data"][0] if res["data"] else {}
            if not data: return None
            
            coin_res = data.get("symbol", symbol)
            price = data.get("lastPr")
            ts = data.get("ts", int(time.time()*1000))
            return Common().return_futures_price_struct("BITGET", coin_res, price, ts)
        return None

    def get_coin_info_futures(self, coin):
        """
        获取合约交易规范信息
        GET /api/v2/mix/market/contracts
        https://www.bitget.com/zh-CN/api-doc/contract/market/Get-Contracts
        """
        path = "/api/v2/mix/market/contracts"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        params = {
            "productType": "USDT-FUTURES",
            "symbol": symbol
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        
        if res and res.get("code") == "00000" and res.get("data"):
            data = res["data"][0]
            coin_res = data.get("symbol", symbol)
            min_unit = data.get("sizeMultiplier", "0")
            min_size = data.get("minTradeNum", "1")
            price_place = int(data.get("pricePlace", "2"))
            price_unit = 10 ** -price_place
            
            swap_status = data.get("symbolStatus") == "normal"
            min_lever = data.get("minLever", "1")
            max_lever = data.get("maxLever", "10")
            return Common().return_futures_coin_info_struct("BITGET", coin, swap_status, Decimal(str(min_size)), Decimal(str(price_unit)), Decimal('1'), Decimal('125'), Decimal('1.0'))
        else:
            return Common().return_futures_coin_info_struct("BITGET", coin, False, "1", "0.01", 1, 125, Decimal('1.0'))

    def get_coin_config_futures(self, coin):
        """
        获取合约代币的配置-杠杆配置信息
        GET /api/v2/mix/account/account
        https://www.bitget.com/zh-CN/api-doc/contract/account/Get-Single-Account
        :param coin:
        :return:
        """
        path = "/api/v2/mix/account/account"
        params = {
            "productType": "USDT-FUTURES",
            "marginCoin": "USDT",
            "symbol": coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        leverage = 0
        margin_mode = "cross"
        if res and res.get("code") == "00000" and res.get("data"):
            data = res["data"]
            isolatedLongLever = data.get("isolatedLongLever", "0")
            isolatedShortLever = data.get("isolatedShortLever", "0")
            if isolatedLongLever == isolatedShortLever:
                leverage = int(isolatedLongLever)
            else:
                leverage = 1 # 随便一个与3不符的数字
            margin_mode_raw = data.get("marginMode", "").lower()
            if margin_mode_raw == "crossed":
                margin_mode = "cross"
            else:
                margin_mode = margin_mode_raw
        return Common().return_futures_coin_config_struct("BITGET", coin, leverage, margin_mode)

    def set_margin_type_futures(self, coin, margin_mode="isolated"):
        """设置仓位模式 (仅逐仓)"""
        path = "/api/v2/mix/account/set-margin-mode"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        body = {
            "symbol": symbol,
            "marginCoin": "USDT",
            "marginMode": "isolated",
            "productType": "USDT-FUTURES"
        }
        try:
            res = self.client.post(path, body=body)
            logger.debug(f"BITGET 设置逐仓模式: {res}")
            return res
        except Exception as e:
            if "already" in str(e).lower() or "40017" in str(e):
                logger.info(f"BITGET {coin} 已经是逐仓模式，无需修改。")
                return {"msg": "already in isolated"}
            logger.error(f"BITGET {coin} 设置逐仓模式异常: {e}")
            return None

    def set_coin_lever_futures(self, coin, lever):
        """设置杠杆倍数 (Bitget 逐仓时多空需分别设置)
        :param coin: 币名
        :param lever: 杠杆倍数
        """
        path = "/api/v2/mix/account/set-leverage"
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "USDT"
        for hs in ("long", "short"):
            body = {
                "symbol": symbol,
                "marginCoin": "USDT",
                "leverage": str(lever),
                "marginMode": "isolated",
                "holdSide": hs,
                "productType": "USDT-FUTURES"
            }
            try:
                res = self.client.post(path, body=body)
                logger.debug(f"BITGET set_leverage {hs}: {res}")
            except Exception as e:
                logger.warning(f"BITGET set_leverage {hs} 异常: {e}")

        return self.get_coin_config_futures(coin)


