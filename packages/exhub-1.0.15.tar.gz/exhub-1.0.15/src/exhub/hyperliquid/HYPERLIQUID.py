from hyperliquid.info import Info
from hyperliquid.exchange import Exchange
from eth_account import Account
from loguru import logger
from .futures import Futures
from .asset import Asset

MAINNET_API_URL = "https://api.hyperliquid.xyz"


class HYPERLIQUID:
    """Hyperliquid API 主类"""

    def __init__(self, private_key, account_address=None, base_url=MAINNET_API_URL):
        self.account = Account.from_key(private_key)
        self.address = account_address or self.account.address
        self._info = Info(base_url, skip_ws=True)
        self._exchange = Exchange(self.account, base_url, account_address=self.address)
        self.futures = Futures(self._info, self._exchange, self.address)
        self.asset = Asset(self._info, self.address)
        # logger.info(f"Hyperliquid 已初始化, 地址: {self.address}")
