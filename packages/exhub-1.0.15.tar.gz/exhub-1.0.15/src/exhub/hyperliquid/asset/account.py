from loguru import logger
from exhub.common import Common

EXCHANGE_TAG = "HYPERLIQUID"


def _to_hl_coin(coin: str) -> str:
    """BTCUSDT -> BTC, USDC -> USDC"""
    c = coin.upper()
    return c[:-4] if c.endswith("USDT") else c


class Account:
    """Hyperliquid 账户"""

    def __init__(self, info, address):
        self._info = info
        self._address = address

    def get_balances(self, coin, asset_type):
        try:
            asset_type_lower = str(asset_type).lower() if asset_type else "futures"

            # 合约余额
            if asset_type_lower == "futures":
                return self._get_perp_balance(coin, asset_type)

            # 现货余额
            if asset_type_lower == "spot":
                return self._get_spot_balance(coin, asset_type)

            # 资金账户: 返回合约余额
            return self._get_perp_balance(coin, asset_type)

        except Exception as e:
            logger.error(f"Hyperliquid 余额查询失败: {e}")
            return Common().return_asset_struct(EXCHANGE_TAG, asset_type, coin, "0")

    def _get_perp_balance(self, coin, asset_type):
        """查询合约账户余额"""
        hl_coin = _to_hl_coin(coin)
        user_state = self._info.user_state(self._address)

        # 先查持仓保证金
        for pos_obj in user_state.get("assetPositions", []):
            pos = pos_obj.get("position", {})
            if pos.get("coin") == hl_coin:
                margin_used = pos.get("marginUsed", "0")
                return Common().return_asset_struct(EXCHANGE_TAG, asset_type, coin, margin_used)

        # 无该币种持仓: 返回账户总净值 (USDC)
        margin_summary = user_state.get("marginSummary", {})
        account_value = margin_summary.get("accountValue", "0")
        return Common().return_asset_struct(EXCHANGE_TAG, asset_type, coin, account_value)

    def _get_spot_balance(self, coin, asset_type):
        """查询现货账户余额"""
        spot_state = self._info.spot_user_state(self._address)
        hl_coin = _to_hl_coin(coin)

        for balance in spot_state.get("balances", []):
            token_name = balance.get("coin", "")
            if token_name.upper() == hl_coin:
                bal = balance.get("total", balance.get("hold", "0"))
                return Common().return_asset_struct(EXCHANGE_TAG, asset_type, coin, bal)

        # 没找到对应币种，余额为0
        return Common().return_asset_struct(EXCHANGE_TAG, asset_type, coin, "0")
