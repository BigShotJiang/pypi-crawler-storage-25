from .account import Account


class Asset:
    """Hyperliquid 资产 API"""

    def __init__(self, info, address):
        self.account = Account(info, address)

    def get_balances(self, coin, asset_type):
        return self.account.get_balances(coin, asset_type)
