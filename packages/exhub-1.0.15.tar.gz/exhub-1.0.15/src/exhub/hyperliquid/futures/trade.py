from decimal import Decimal
from loguru import logger
from exhub.common import Common

EXCHANGE_TAG = "HYPERLIQUID"


def _to_hl_coin(coin: str) -> str:
    """BTCUSDT -> BTC"""
    c = coin.upper()
    return c[:-4] if c.endswith("USDT") else c


class FuturesTrade:
    """Hyperliquid 合约交易"""

    def __init__(self, info, exchange, address):
        self._info = info
        self._exchange = exchange
        self._address = address

    def _round_price(self, px: float, coin: str) -> float:
        """Hyperliquid 价格精度: 5位有效数字 -> 再按 szDecimals 舍入"""
        px5 = float(f"{px:.5g}")
        try:
            asset = self._info.name_to_asset(coin)
            sz_decimals = self._info.asset_to_sz_decimals.get(asset, 8)
            decimals = 6 - sz_decimals
            if decimals > 0:
                px5 = round(px5, decimals)
                logger.debug(f"Hyperliquid {coin} 止损价格精度矫正 {px} → {px5}")
        except Exception:
            pass
        return px5

    @staticmethod
    def _check_order_success(res) -> bool:
        if res is None:
            return False
        if isinstance(res, dict):
            if "error" in res and res["error"] is not None:
                return False
            if "response" in res:
                return True
            return True
        return True

    @staticmethod
    def _extract_order_id(res) -> str:
        try:
            if isinstance(res, dict) and "response" in res:
                data = res["response"].get("data", {})
                if isinstance(data, dict) and data.get("statuses"):
                    for s in data["statuses"]:
                        if "resting" in s and s["resting"]:
                            return str(s["resting"]["oid"])
                        if "filled" in s and s["filled"]:
                            return str(s["filled"]["oid"])
                if isinstance(data, dict) and "oid" in data:
                    return str(data["oid"])
            return str(res)
        except Exception:
            return str(res)

    def _get_position_size(self, hl_coin: str) -> float:
        """获取当前全仓数量"""
        user_state = self._info.user_state(self._address)
        for pos_obj in user_state.get("assetPositions", []):
            pos = pos_obj.get("position", {})
            if pos.get("coin") == hl_coin:
                return abs(float(pos.get("szi", 0)))
        return 0

    def _cancel_trigger_orders(self, hl_coin: str, tpsl_type: str, is_full: bool):
        """撤销指定币种和类型的止盈止损单
        is_full=True: 只撤销全仓; is_full=False: 只撤销部分
        """
        try:
            orders = self._info.frontend_open_orders(self._address)
            for o in orders:
                if o.get("coin") != hl_coin:
                    continue
                if not o.get("isTrigger"):
                    continue
                order_type = o.get("orderType", "")
                if tpsl_type == "sl" and "Stop" not in order_type:
                    continue
                if tpsl_type == "tp" and "Take" not in order_type:
                    continue
                # 判断该挂单是全仓还是部分
                order_sz = abs(float(o.get("origSz", 0)))
                pos_sz = self._get_position_size(hl_coin)
                order_is_full = order_sz >= pos_sz * 0.99
                if order_is_full != is_full:
                    continue
                oid = o.get("oid")
                if oid:
                    try:
                        self._exchange.cancel(hl_coin, oid)
                        logger.info(f"Hyperliquid 撤销{'全仓' if is_full else '部分'}{tpsl_type}单 oid={oid}")
                    except Exception as e:
                        logger.warning(f"Hyperliquid 撤销{tpsl_type}单失败 oid={oid}: {e}")
        except Exception as e:
            logger.warning(f"Hyperliquid 查询挂单异常: {e}")

    def order_futures(self, coin, side, order_type, size, stop_loss_price=None):
        hl_coin = _to_hl_coin(coin)
        s = side.upper()
        is_buy = s in ("BUY", "LONG")
        sz = abs(float(size))
        if sz == 0:
            raise Exception(f"Hyperliquid 下单数量为0: coin={coin} side={side}")

        try:
            res = self._exchange.market_open(hl_coin, is_buy, sz, slippage=0.02)
            logger.debug(f"Hyperliquid order: {res}")
        except Exception as e:
            logger.error(f"Hyperliquid 下单失败: {e}")
            raise

        order_id = self._extract_order_id(res)
        return Common().return_futures_order_struct(EXCHANGE_TAG, coin, side, order_type, size, order_id, res)

    def close_position_futures(self, coin, side, order_type, size):
        hl_coin = _to_hl_coin(coin)
        sz = abs(float(size)) if size else None
        try:
            res = self._exchange.market_close(hl_coin, sz=sz, slippage=0.02)
            logger.debug(f"Hyperliquid close: {res}")
        except Exception as e:
            logger.error(f"Hyperliquid 平仓失败: {e}")
            raise
        order_id = self._extract_order_id(res)
        return Common().return_futures_order_struct(EXCHANGE_TAG, coin, side, order_type, size or 0, order_id, res)

    def get_position_futures(self, coin):
        hl_coin = _to_hl_coin(coin)
        try:
            user_state = self._info.user_state(self._address)
        except Exception as e:
            logger.error(f"Hyperliquid 获取仓位失败: {e}")
            return {EXCHANGE_TAG: []}

        open_orders = []
        try:
            open_orders = self._info.frontend_open_orders(self._address)
        except Exception as e:
            logger.warning(f"Hyperliquid frontend_open_orders 失败: {e}")

        positions = []
        for pos_obj in user_state.get("assetPositions", []):
            pos = pos_obj.get("position", {})
            if pos.get("coin") != hl_coin:
                continue
            szi = float(pos.get("szi", 0))
            if szi == 0:
                continue
            side = "LONG" if szi > 0 else "SHORT"
            size_abs = abs(szi)
            entry_px = float(pos.get("entryPx", 0))
            unrealized = pos.get("unrealizedPnl", "0")
            liquidation_px = pos.get("liquidationPx", "0")

            all_sl = "0"
            all_tp = "0"
            partial_sl = {"size": "0", "price": "0"}
            partial_tp = {"size": "0", "price": "0"}

            for o in open_orders:
                if o.get("coin") != hl_coin:
                    continue
                if not o.get("isTrigger"):
                    continue
                order_type = o.get("orderType", "")
                trigger_px = str(o.get("triggerPx", "0"))
                order_sz = abs(float(o.get("origSz", 0)))

                if "Stop" in order_type:
                    if order_sz >= size_abs * 0.99:
                        all_sl = trigger_px
                    else:
                        partial_sl = {"size": str(order_sz), "price": trigger_px}
                elif "Take" in order_type:
                    if order_sz >= size_abs * 0.99:
                        all_tp = trigger_px
                    else:
                        partial_tp = {"size": str(order_sz), "price": trigger_px}

            pos_info = Common().return_futures_position_struct(
                coin, size_abs, entry_px, side, unrealized, liquidation_px,
                all_sl, all_tp, partial_sl, partial_tp, pos
            )
            positions.append(pos_info)

        return {EXCHANGE_TAG: positions}

    def set_stop_loss_futures(self, coin, side, size, stop_price):
        hl_coin = _to_hl_coin(coin)
        s = side.upper()
        is_buy = s in ("SELL", "SHORT")
        qty = abs(float(size)) if size and float(size) > 0 else self._get_position_size(hl_coin)
        if qty == 0:
            raise Exception(f"Hyperliquid 设置止损失败: {hl_coin} 无持仓")

        sl_px = self._round_price(float(stop_price), hl_coin)
        try:
            res = self._exchange.order(
                hl_coin, is_buy, qty,
                limit_px=sl_px,
                order_type={"trigger": {"triggerPx": sl_px, "isMarket": True, "tpsl": "sl"}},
                reduce_only=True,
            )
            logger.debug(f"Hyperliquid set_sl: {res}")
        except Exception as e:
            logger.error(f"Hyperliquid 设置止损失败: {e}")
            return Common().return_set_stop_loss_struct(EXCHANGE_TAG, coin, False, str(e))

        status = self._check_order_success(res)
        return Common().return_set_stop_loss_struct(EXCHANGE_TAG, coin, status, res)

    def set_take_profit_futures(self, coin, side, size, tp_price):
        hl_coin = _to_hl_coin(coin)
        s = side.upper()
        is_buy = s in ("SELL", "SHORT")
        qty = abs(float(size)) if size and float(size) > 0 else self._get_position_size(hl_coin)
        if qty == 0:
            raise Exception(f"Hyperliquid 设置止盈失败: {hl_coin} 无持仓")

        tp_px = self._round_price(float(tp_price), hl_coin)
        try:
            res = self._exchange.order(
                hl_coin, is_buy, qty,
                limit_px=tp_px,
                order_type={"trigger": {"triggerPx": tp_px, "isMarket": True, "tpsl": "tp"}},
                reduce_only=True,
            )
            logger.debug(f"Hyperliquid set_tp: {res}")
        except Exception as e:
            logger.error(f"Hyperliquid 设置止盈失败: {e}")
            return Common().return_set_take_profit_struct(EXCHANGE_TAG, coin, False, str(e))

        status = self._check_order_success(res)
        return Common().return_set_take_profit_struct(EXCHANGE_TAG, coin, status, res)

    def update_stop_loss_futures(self, coin, side, size, stop_price):
        hl_coin = _to_hl_coin(coin)
        # size为空/0=全仓，>0=部分
        is_full = not size or float(size) == 0
        self._cancel_trigger_orders(hl_coin, "sl", is_full)
        return self.set_stop_loss_futures(coin, side, size, stop_price)

    def update_take_profit_futures(self, coin, side, size, tp_price):
        hl_coin = _to_hl_coin(coin)
        is_full = not size or float(size) == 0
        self._cancel_trigger_orders(hl_coin, "tp", is_full)
        return self.set_take_profit_futures(coin, side, size, tp_price)

    def get_recent_pnl(self, coin):
        hl_coin = _to_hl_coin(coin)
        try:
            fills = self._info.user_fills(self._address)
            for i in range(len(fills) - 1, -1, -1):
                f = fills[i]
                if f.get("coin") != hl_coin:
                    continue
                if "Close" not in f.get("dir", ""):
                    continue
                pnl = Decimal(str(f.get("closedPnl", "0")))
                fee = Decimal(str(f.get("fee", "0")))
                close_sz = abs(float(f.get("sz", 0)))
                open_dir = f["dir"].replace("Close", "Open")
                for j in range(len(fills)):
                    if j == i:
                        continue
                    prev = fills[j]
                    if (prev.get("coin") == hl_coin
                            and prev.get("dir") == open_dir
                            and abs(float(prev.get("sz", 0))) == close_sz):
                        fee += Decimal(str(prev.get("fee", "0")))
                        break
                return Common().return_pnl_struct(EXCHANGE_TAG, coin, pnl - fee)
            return Common().return_pnl_struct(EXCHANGE_TAG, coin, "0")
        except Exception as e:
            logger.warning(f"Hyperliquid PNL 异常: {e}")
            return Common().return_pnl_struct(EXCHANGE_TAG, coin, "0")
