import math
import time
from decimal import Decimal
from loguru import logger
from exhub.common import Common

EXCHANGE_TAG = "HYPERLIQUID"


def _to_hl_coin(coin: str) -> str:
    """BTCUSDT -> BTC"""
    c = coin.upper()
    return c[:-4] if c.endswith("USDT") else c


def _calc_price_unit(price: float) -> Decimal:
    """根据 Hyperliquid 5位有效数字精度计算价格步进"""
    if price <= 0:
        return Decimal("0.000001")
    magnitude = math.floor(math.log10(abs(price)))
    step = 10 ** (magnitude - 4)
    return Decimal(str(max(step, 0.000001)))


class FuturesMarket:
    """Hyperliquid 合约行情"""

    def __init__(self, info, exchange, address):
        self._info = info
        self._exchange = exchange
        self._address = address
        # 缓存用户手动设置的杠杆/保证金模式，Hyperliquid 无持仓时链上读不到
        self._config_cache: dict[str, dict] = {}

    def get_prices_futures(self, coin):
        hl_coin = _to_hl_coin(coin)
        mids = self._info.all_mids()
        price = mids.get(hl_coin)
        if price is None:
            raise Exception(f"Hyperliquid: 未找到 {hl_coin} 的价格")
        ts = int(time.time() * 1000)
        return Common().return_futures_price_struct(EXCHANGE_TAG, coin, price, ts)

    def get_coin_info_futures(self, coin):
        hl_coin = _to_hl_coin(coin)
        try:
            meta, _ = self._info.meta_and_asset_ctxs()
            for spec in meta["universe"]:
                if spec["name"] == hl_coin:
                    sz_decimals = spec["szDecimals"]
                    min_unit = Decimal(str(10 ** (-sz_decimals)))
                    # 根据当前价格动态计算 price_unit (Hyperliquid 5位有效数字)
                    mids = self._info.all_mids()
                    cur_price = float(mids.get(hl_coin, 1))
                    price_unit = _calc_price_unit(cur_price)
                    max_lever = Decimal(str(spec.get("maxLeverage", 50)))
                    ct_val = Decimal("1.0")
                    return Common().return_futures_coin_info_struct(
                        EXCHANGE_TAG, coin, True, min_unit, price_unit,
                        Decimal("1"), max_lever, ct_val
                    )
        except Exception as e:
            logger.error(f"Hyperliquid get_coin_info 失败: {e}")
        return Common().return_futures_coin_info_struct(
            EXCHANGE_TAG, coin, False, "0.001", "0.01", 1, 50, Decimal("1.0")
        )

    def get_coin_config_futures(self, coin):
        hl_coin = _to_hl_coin(coin)
        # 1. 优先从链上持仓读取
        try:
            user_state = self._info.user_state(self._address)
            for pos_obj in user_state.get("assetPositions", []):
                pos = pos_obj.get("position", {})
                if pos.get("coin") == hl_coin:
                    leverage = pos.get("leverage", {})
                    lever_val = leverage.get("value", 1)
                    self._config_cache[hl_coin] = {"lever": lever_val, "margin_mode": "isolated"}
                    return Common().return_futures_coin_config_struct(
                        EXCHANGE_TAG, coin, lever_val, "isolated"
                    )
        except Exception as e:
            logger.warning(f"Hyperliquid get_coin_config 链上查询异常: {e}")

        # 2. 回退到缓存
        if hl_coin in self._config_cache:
            c = self._config_cache[hl_coin]
            return Common().return_futures_coin_config_struct(EXCHANGE_TAG, coin, c["lever"], "isolated")

        # 3. 都没有: 返回默认值
        logger.debug(f"Hyperliquid {hl_coin} 无持仓且无缓存，返回默认配置")
        return Common().return_futures_coin_config_struct(EXCHANGE_TAG, coin, 1, "isolated")

    def set_coin_lever_futures(self, coin, lever):
        hl_coin = _to_hl_coin(coin)
        try:
            self._exchange.update_leverage(int(lever), hl_coin, is_cross=False)
            logger.info(f"Hyperliquid 设置杠杆 {hl_coin} lever={lever} isolated")
        except Exception as e:
            logger.warning(f"Hyperliquid set_leverage 异常: {e}")

        self._config_cache[hl_coin] = {"lever": int(lever), "margin_mode": "isolated"}
        return Common().return_futures_coin_config_struct(EXCHANGE_TAG, coin, lever, "isolated")

    def set_margin_type_futures(self, coin, margin_mode="isolated"):
        """仅支持逐仓; 从缓存或链上获取当前杠杆后设置"""
        hl_coin = _to_hl_coin(coin)
        current = self.get_coin_config_futures(coin).get(EXCHANGE_TAG, {})
        cur_lever = int(current.get("cur_lever", 1))
        try:
            self._exchange.update_leverage(cur_lever, hl_coin, is_cross=False)
            logger.info(f"Hyperliquid 设置保证金模式 {hl_coin} -> isolated")
        except Exception as e:
            logger.warning(f"Hyperliquid set_margin_type 异常: {e}")
        self._config_cache[hl_coin] = {"lever": cur_lever, "margin_mode": "isolated"}
        return Common().return_futures_coin_config_struct(EXCHANGE_TAG, coin, cur_lever, "isolated")
