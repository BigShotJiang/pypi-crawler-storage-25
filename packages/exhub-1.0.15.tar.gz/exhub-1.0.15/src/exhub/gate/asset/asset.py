from .account import Account

class Asset:
    """Gate Asset 聚合接口"""
    def __init__(self, client):
        self.client = client
        self.account = Account(client)

    def get_balances(self, coin, asset_type=None):
        """查询余额"""
        return self.account.get_balances(coin, asset_type)

    def transfer(self, type_from, type_to, coin, amount, currency_pair=None, settle=None):
        """交易账户互转"""
        return self.account.transfer(type_from, type_to, coin, amount, currency_pair, settle)
