from loguru import logger
from exhub.config import Config
from exhub.common import Common
class Account:
    """资金 API 实现"""
    def __init__(self, client):
        self.client = client


    def get_balances(self, coin, asset_type=None):
        """
        查询余额
        :param coin: 币种
        :param asset_type: spot, fund, futures
        """
        asset_type = Config().unify_variables_asset_type("GATE", asset_type)
        
        if asset_type in ["spot", "fund"]:
            path = "/spot/accounts"
            params = {}
            if coin:
                params["currency"] = coin
            
            res = self.client.get(path, params=params, signed=True)
            logger.debug(res)
            if isinstance(res, list):
                for item in res:
                    if item.get("currency") == coin:
                        return Common().return_asset_struct("GATE", asset_type, coin, item.get("available"))

        elif asset_type == "futures":
            settle = "usdt"
            if coin.lower() == "btc":
                settle = "btc"
            
            path = f"/futures/{settle}/accounts"
            res = self.client.get(path, signed=True)
            logger.debug(res)
            if isinstance(res, dict):
                if res.get("currency") == coin:
                     return Common().return_asset_struct("GATE", asset_type, coin, res.get("available"))
        return None


    def transfer(self, type_from, type_to, coin, amount, currency_pair=None, settle=None):
        """
        交易账户互转
        POST /wallet/transfers
        :param currency: 转账货币 (如 USDT, BTC)
        :param from_account: 转出账户 (spot, margin, futures, delivery, options)
        :param to_account: 转入账户
        :param amount: 数量
        :param currency_pair: 杠杆交易对 (如 BTC_USDT, 仅杠杆账户需要)
        :param settle: 合约结算币种 (如 usdt, btc, 仅合约账户需要)
        """
        path = "/wallet/transfers"
        body = {
            "currency": coin,
            "from": type_from,
            "to": type_to,
            "amount": str(amount)
        }
        if currency_pair:
            body["currency_pair"] = currency_pair
        if settle:
            body["settle"] = settle
            
        res = self.client.post(path, body=body, signed=True)
        logger.debug(res)
        return Common().return_transfer_struct("GATE", type_from, type_to, coin, amount, res)

