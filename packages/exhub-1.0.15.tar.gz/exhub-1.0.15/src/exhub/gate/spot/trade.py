from loguru import logger
from exhub.config import Config
from exhub.common import Common
class SpotTrade:
    """Gate 现货交易实现"""
    def __init__(self, client):
        self.client = client

    def order(self, coin, side, order_type, amount):
        """
        现货下单 (POST /spot/orders)
        https://www.gate.com/docs/developers/apiv4/zh_CN/#%E4%B8%8B%E5%8D%95
        :param coin: 交易对的基础货币 (如 ETH)
        :param side: 买卖方向 (buy, sell)
        :param order_type: 订单类型 (limit, market)
        :param amount: 交易数量。
                       - 市价买单(market buy): 指的是计价货币数量 (花费的USDT数量)
                       - 市价卖单(market sell)和限价单(limit): 指的是基础货币数量 (买卖的ETH数量)
        """
        path = "/spot/orders"
        body = {
            "currency_pair": coin if coin.endswith("_USDT") else coin + "_USDT",
            "side": side.lower(),
            "type": order_type.lower(),
            "amount": str(amount),
            "account": "spot"
        }

        if body['type'] == 'market':
            body['time_in_force'] = 'ioc'
        else:
            body['time_in_force'] = 'gtc'


        res = self.client.post(path, body=body, signed=True)
        logger.debug(res)
        logger.success(f'下单成功: {res.get("id")}')
        return Common().return_order_struct("GATE", coin, side, order_type, amount,res.get("id"), "",res)

    def get_orders_status(self, coin, order_id):
        """
        查询订单状态
        GET /spot/orders/{order_id}
        https://www.gate.com/docs/developers/apiv4/zh_CN/#%E6%9F%A5%E8%AF%A2%E5%8D%95%E4%B8%AA%E8%AE%A2%E5%8D%95%E8%AF%A6%E6%83%85
        :param coin:
        :param order_id:
        :return:
        """
        path = f"/spot/orders/{order_id}"
        params = {
            "currency_pair": coin if coin.endswith("_USDT") else coin+"_USDT"
        }
        res = self.client.get(path, params=params, signed=True)
        logger.debug(res)
        if res.get("status") == "closed":
            order_status = "FILLED"
        elif res.get("status") in ["open"]:
            order_status = "PROCESSING"
        else:
            order_status = "FAILED"
        return Common().return_order_status_struct("GATE", res.get("currency_pair"), order_id, res.get("side"),res.get("type"),order_status,res)
    def get_order_info(self, coin, order_id):
        """
        查询订单信息
        GET /spot/orders/{order_id}
        https://www.gate.com/docs/developers/apiv4/zh_CN/#%E6%9F%A5%E8%AF%A2%E5%8D%95%E4%B8%AA%E8%AE%A2%E5%8D%95%E8%AF%A6%E6%83%85
        :param coin:
        :param order_id:
        :return:
        type为market时，根据买卖不同指代不同
            - side : buy 指代计价货币，BTC_USDT中指USDT
            - side : sell 指代交易货币，BTC_USDT中指BTC
        """
        path = f"/spot/orders/{order_id}"
        params = {
            "currency_pair": coin if coin.endswith("_USDT") else coin+"_USDT"
        }
        res = self.client.get(path, params=params, signed=True)
        logger.debug(res)
        return Common().return_order_info_struct("GATE", res.get("currency_pair"), res.get("amount"), order_id, res.get("filled_total"),res.get("avg_deal_price"),res)