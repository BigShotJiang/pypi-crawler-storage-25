from loguru import logger
from decimal import Decimal
class SpotMarket:
    """现货行情 API"""
    def __init__(self, client):
        self.client = client

    def get_coin_network_info(self, coin, network=None):
        """查询币种支持的链"""
        path = "/wallet/currency_chains"
        params = {"currency": coin}

        if network:
            return_data = {"GATE": {"withdraw_status": False, "deposit_status": False, "contract_address": None,"withdraw_fee": 0}}
        else:
            return_data = {"GATE": []}

        res = self.client.get(path, params=params, signed=False)
        # logger.debug(res)
        if res and isinstance(res, list):
            logger.info(f"{coin} 支持 {len(res)} 个链")
            for chain_data in res:
                chain_name = chain_data.get("chain")
                ct_addr = chain_data.get("contract_address") if chain_data.get("contract_address") else None
                can_wd = False if chain_data.get('is_withdraw_disabled') else True
                can_dep = False if chain_data.get('is_deposit_disabled') else True
                if chain_name == network:
                    return_data["GATE"]["withdraw_status"] = can_wd
                    return_data["GATE"]["deposit_status"] = can_dep
                    return_data["GATE"]["contract_address"] = ct_addr
                    logger.info(f"  - 链: {chain_name} ({chain_data.get('name_en')}), "
                                f"提现状态: {can_wd}, 充值状态: {can_dep}, "
                                f"合约地址: {ct_addr}")
                    return return_data
                else:
                    if not network:
                        new_entry = {
                            "dex_chain_name": None,
                            "cex_chain_name": chain_name,
                            "withdraw_status": can_wd,
                            "deposit_status": can_dep,
                            "contract_address": ct_addr,
                            "withdraw_fee": None,  # 没有数据
                        }
                        return_data["GATE"].append(new_entry)
                    logger.debug(f"  - 链: {chain_name} ({chain_data.get('name_en')}), "
                                 f"提现状态: {can_wd}, 充值状态: {can_dep}, "
                                 f"合约地址: {ct_addr}")

        return return_data

    def get_coin_info(self, coin):
        """查询单个交易对详情"""
        path = f"/spot/currency_pairs/{coin}_USDT"
        res = self.client.get(path, signed=False)
        logger.debug(res)
        return_data = {"GATE": {"swap_status": False,"min_unit": 0}}
        if res and res.get("trade_status") == "tradable" :
            return_data["GATE"]["swap_status"] = True
            return_data["GATE"]["min_unit"] = Decimal(10 ** - res["amount_precision"])
        return return_data

    def get_klines(self, coin, interval, limit=1):
        """K 线"""
        path = "/spot/candlesticks"
        params = {
            "currency_pair": coin+"_USDT",
            "interval": interval,
            "limit": limit
        }

        return_data = {"GATE": {"swap_volume": 0}}
        res = self.client.get(path, params=params, signed=False)
        logger.debug(res)
        if res and isinstance(res, list) and len(res) > 0:
            return_data["GATE"]["swap_volume"] = Decimal(res[0][1])
        return return_data
