import hmac
import hashlib
import time
import json
import requests
import urllib.parse
from loguru import logger

class GateClient:
    """Gate.io API V4 基础客户端"""
    def __init__(self, api_key, api_secret, base_url="https://api.gateio.ws", proxies=None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = base_url
        self.session = requests.Session()
        if proxies:
            self.session.proxies.update(proxies)
        
        self.session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })

    def _get_timestamp(self):
        """获取当前时间戳（秒级）"""
        return str(int(time.time()))

    def _get_sign(self, method, url, query_string, payload_string, timestamp):
        """生成签名"""
        m = hashlib.sha512()
        m.update(payload_string.encode('utf-8'))
        hashed_payload = m.hexdigest()

        signature_string = f"{method}\n{url}\n{query_string}\n{hashed_payload}\n{timestamp}"
        
        sign = hmac.new(
            self.api_secret.encode('utf-8'),
            signature_string.encode('utf-8'),
            hashlib.sha512
        ).hexdigest()
        
        return sign

    def _request(self, method, path, params=None, body=None, signed=False):
        """统一请求方法"""
        if not path.startswith("/api/v4"):
            full_path = "/api/v4" + path
        else:
            full_path = path
            
        full_url = self.base_url + full_path

        query_string = ""
        if params:
            sorted_params = sorted(params.items())
            query_string = urllib.parse.urlencode(sorted_params)

        payload_string = ""
        if body:
            payload_string = json.dumps(body)

        timestamp = self._get_timestamp()

        headers = {}
        if signed:
            signature = self._get_sign(method, full_path, query_string, payload_string, timestamp)
            headers.update({
                'KEY': self.api_key,
                'Timestamp': timestamp,
                'SIGN': signature
            })

        try:
            if method.upper() == 'GET':
                request_url = full_url
                if query_string:
                    request_url += "?" + query_string
                response = self.session.get(request_url, headers=headers)
            elif method.upper() == 'POST':
                request_url = full_url
                if query_string:
                    request_url += "?" + query_string
                response = self.session.post(request_url, headers=headers, data=payload_string)
            elif method.upper() == 'DELETE':
                request_url = full_url
                if query_string:
                    request_url += "?" + query_string
                response = self.session.delete(request_url, headers=headers, data=payload_string)
            else:
                raise ValueError(f"Unsupported method: {method}")

            if response.status_code in [200, 201, 202, 204]:
                return response.json() if response.text else {{}}
            else:
                try:
                    err = response.json()
                    logger.error(f"Gate Request Error: {response.status_code} - {err}")
                    raise Exception(f"Gate API Error: {err}")
                except ValueError:
                    logger.error(f"Request failed: {response.text}")
                    raise Exception(f"Request failed: {response.text}")


        except Exception as e:
            logger.error(f"Request failed: {e}")
            raise

    def get(self, path, params=None, signed=False):
        return self._request('GET', path, params=params, signed=signed)

    def post(self, path, params=None, body=None, signed=True):
        return self._request('POST', path, params=params, body=body, signed=signed)

    def delete(self, path, params=None, body=None, signed=True):
        """DELETE 请求，用于撤单等操作"""
        return self._request('DELETE', path, params=params, body=body, signed=signed)
