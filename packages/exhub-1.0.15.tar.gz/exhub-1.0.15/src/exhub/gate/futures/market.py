from decimal import Decimal
import time
from loguru import logger
from exhub.config import Config
from exhub.common import Common

class FuturesMarket:
    """Gate.io 合约市场"""
    def __init__(self, client):
        self.client = client
        self._info_cache = {}  # 缓存 get_coin_info_futures 结果

    def get_prices_futures(self, coin):
        """
        获取指定代币对价格
        GET /api/v4/futures/usdt/tickers
        https://www.gate.io/docs/developers/apiv4/zh_CN/#%E8%8E%B7%E5%8F%96%E5%90%88%E7%BA%A6%E8%A1%8C%E6%83%85
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")
            
        path = "/futures/usdt/tickers"
        params = {
            "contract": symbol
        }
        res = self.client.get(path, params=params, signed=False)
        logger.debug(res)
        if res and isinstance(res, list) and len(res) > 0:
            data = res[0]
            coin_res = data.get("contract", symbol).replace("_", "")
            price = data.get("last")
            ts = int(time.time() * 1000)
            return Common().return_futures_price_struct("GATE", coin_res, price, ts)
        return None

    def get_coin_info_futures(self, coin):
        """
        获取合约交易规范信息
        GET /api/v4/futures/usdt/contracts/{contract}
        """
        if coin in self._info_cache:
            return self._info_cache[coin]

        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")

        path = f"/futures/usdt/contracts/{symbol}"
        res = self.client.get(path, signed=False)
        logger.debug(res)
        
        result = None
        if res and isinstance(res, dict) and "name" in res:
            coin_res = res.get("name", symbol).replace("_", "")
            min_unit = Decimal("1")  # Gate 下单按张数, 1 张为最小单位
            ct_val = Decimal(str(res.get("quanto_multiplier", "1")))  # 1张 = quanto_multiplier 个币
            price_unit = res.get("order_price_round", "0.01")
            swap_status = res.get("in_delisting") is False
            min_lever = res.get("leverage_min", "1")
            max_lever = res.get("leverage_max", "10")
            result = Common().return_futures_coin_info_struct("GATE", coin_res, swap_status, min_unit, Decimal(price_unit), Decimal(min_lever), Decimal(max_lever), ct_val)
        else:
            result = Common().return_futures_coin_info_struct("GATE", coin, False, "1", "0.01", 1, 100, Decimal("1"))

        self._info_cache[coin] = result
        return result

    def get_coin_config_futures(self, coin):
        """
        获取合约代币的配置-杠杆配置信息
        GET /api/v4/futures/usdt/positions/{contract}
        https://www.gate.io/docs/developers/apiv4/zh_CN/#%E8%8E%B7%E5%8F%96%E5%8D%95%E4%B8%AA%E5%90%88%E7%BA%A6%E4%BB%93%E4%BD%8D
        :param coin:
        :return:
        """
        symbol = coin.upper() if coin.endswith("_USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")
            
        path = f"/futures/usdt/positions/{symbol}"
        try:
            res = self.client.get(path, signed=True)
        except Exception as e:
            # 从未开过仓的币种会返回 POSITION_NOT_FOUND
            if "POSITION_NOT_FOUND" in str(e):
                logger.debug(f"GATE {coin} 无历史仓位，返回默认配置")
                return Common().return_futures_coin_config_struct("GATE", coin, 0, "isolated")
            raise
        logger.debug(res)
        leverage = 0
        if isinstance(res, list):
            for data in res:
                if "lever" in data and data.get("lever"):
                    leverage = data.get("lever", 0)
                    break
        return Common().return_futures_coin_config_struct("GATE", coin, leverage, "isolated")

    def set_coin_lever_futures(self, coin, lever):
        """设置杠杆倍数 (逐仓)"""
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "_USDT"
        if not symbol.endswith("_USDT"):
            symbol = symbol.replace("USDT", "_USDT")

        path = f"/futures/usdt/positions/{symbol}/leverage"
        query = {"leverage": str(lever)}
        res = self.client.post(path, params=query, signed=True)
        logger.debug(f"GATE set_leverage lever={lever}: {res}")
        return self.get_coin_config_futures(coin)

    def set_margin_type_futures(self, coin, margin_mode="isolated"):
        """设置仓位模式-不需要单独设置,更改杠杆倍数自动设置为逐仓"""
        return {"msg": "isolated"}

