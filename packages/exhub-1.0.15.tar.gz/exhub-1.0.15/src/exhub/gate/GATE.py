from .common import GateClient
from .spot import Spot
from .asset.asset import Asset
from .futures.futures import Futures


class GATE:
    """Gate.io API 主类"""
    def __init__(self, api_key, api_secret):
        self.client = GateClient(api_key, api_secret)
        self.spot = Spot(self.client)
        self.asset = Asset(self.client)
        self.futures = Futures(self.client)
