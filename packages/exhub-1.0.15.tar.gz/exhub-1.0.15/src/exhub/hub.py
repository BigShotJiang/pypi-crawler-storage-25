import os
from decimal import Decimal
from exhub.binance import BINANCE
from exhub.bitget import BITGET
from exhub.okx import OKX
from exhub.gate import GATE
from exhub.hyperliquid import HYPERLIQUID
from exhub.db_manager import DatabaseManager
from loguru import logger
from dotenv import load_dotenv
load_dotenv()

class BaseHub:
    """分发器基类，按 exchange 参数定向分发"""
    def __init__(self, exchange_instances, db: DatabaseManager = None):
        self.exchanges = exchange_instances
        self.db = db

    def _dispatch(self, module_name, method_name, *args, **kwargs):
        """根据 exchange 参数分发请求"""
        target = kwargs.pop('exchange', None)
        
        if target is None or (isinstance(target, str) and target.upper() == "ALL"):
            selected_names = list(self.exchanges.keys())
        elif isinstance(target, str):
            selected_names = [target.lower()]
        elif isinstance(target, list):
            selected_names = [t.lower() for t in target]
        else:
            selected_names = []

        final_results = {}
        for name in selected_names:
            if name not in self.exchanges:
                logger.warning(f"ExHub: 交易所 {name} 未在配置中初始化，跳过调用。")
                continue
                
            ex = self.exchanges[name]
            try:
                module = getattr(ex, module_name)
                method = getattr(module, method_name)
                res = method(*args, **kwargs)
                if isinstance(res, dict):
                    final_results.update(res)
            except Exception as e:
                logger.error(f"ExHub分发失败 [{name}.{module_name}.{method_name}]: {e}")
                final_results[name.upper()] = {"status": False, "error": str(e)}
        return final_results

    def _calculate_size(self, amount, price, min_unit, ct_val=Decimal('1.0')):
        """计算下单数量"""
        try:
            amount, price, min_unit, ct_val = Decimal(str(amount)), Decimal(str(price)), Decimal(str(min_unit)), Decimal(str(ct_val))
            unit_value = price * ct_val
            if unit_value <= 0: return "0"
            raw_size = amount / unit_value
            steps = (raw_size / min_unit).quantize(Decimal('1'), rounding="ROUND_DOWN")
            size_val = steps * min_unit
            min_unit_str = f"{min_unit:.10f}".rstrip('0').rstrip('.')
            decimals = len(min_unit_str.split('.')[1]) if '.' in min_unit_str else 0
            return f"{size_val:.{decimals}f}"
        except:
            raise Exception("ExHub: 计算下单数量失败")

    def _round_step(self, value, step):
        """按步进进行价格舍入"""
        try:
            value, step = Decimal(str(value)), Decimal(str(step))
            if step <= 0: return value
            res = (value / step).quantize(Decimal('1'), rounding="ROUND_DOWN") * step
            return res.quantize(step.normalize(), rounding="ROUND_DOWN")
        except:
            raise Exception("ExHub: 舍入价格失败")

    def _correct_size(self, size, min_unit):
        """矫正止盈止损的部分仓位数量精度，size=0/None 为全仓不处理"""
        if not size or float(size) == 0:
            return size
        try:
            size_val = Decimal(str(size))
            min_unit_val = Decimal(str(min_unit))
            if min_unit_val <= 0:
                return size
            steps = (size_val / min_unit_val).quantize(Decimal('1'), rounding="ROUND_DOWN")
            corrected = steps * min_unit_val
            min_unit_str = f"{min_unit_val:.10f}".rstrip('0').rstrip('.')
            decimals = len(min_unit_str.split('.')[1]) if '.' in min_unit_str else 0
            return f"{corrected:.{decimals}f}"
        except Exception:
            return size

class FuturesHub(BaseHub):
    """合约聚合分发接口"""
    def order(self, *args, **kwargs):
        """
        合约下单
        :param exchange: 执行交易所
        :param coin: 币种
        :param side: 方向
        :param amount: 下单本金 (USDT)
        :param sl_percent: 止损百分比 (如 0.05 代表 5%)
        :param lever: 杠杆倍数 (可选。不传则查旧值；传了则对比，不符则修改)--准备不再使用
        """
        exchange = kwargs.get('exchange')
        coin = kwargs.get('coin')
        side = kwargs.get('side', '').upper()
        amount = kwargs.pop('amount', None)
        sl_percent = kwargs.pop('sl_percent', None)

        lever = kwargs.pop('lever', 3)
        kwargs.pop('tp_percent', None)
        kwargs['side'] = side
        # 1. 自动化计算逻辑
        if exchange and isinstance(exchange, str) and exchange.upper() != "ALL":
            ex_name = exchange.upper()

            # 1.1 先检查代币是否支持交易
            info_res = self.get_coin_info(exchange=exchange, coin=coin)
            swap_status = info_res.get(ex_name, {}).get("swap_status", False)
            if not swap_status:
                logger.warning(f"ExHub: {ex_name} {coin} 不支持交易或未找到合约信息")
                return {"status": False, "error": f"{ex_name} {coin} 不支持交易或未找到合约信息"}

            # 1.2 获取当前仓位、杠杆
            config_res = self.get_coin_config(exchange=exchange, coin=coin)
            current_lever = config_res.get(ex_name, {}).get("cur_lever")
            current_margin_mode = config_res.get(ex_name, {}).get("margin_mode", "").upper()
            target_margin_mode = "ISOLATED"

            # 1.3 仓位模式
            if current_margin_mode and current_margin_mode != target_margin_mode:
                logger.warning(f"ExHub: {ex_name} {coin} 仓位模式不符 ({current_margin_mode} -> {target_margin_mode})，执行设置。")
                self.set_margin_mode(exchange=exchange, coin=coin, margin_mode=target_margin_mode)
            elif current_margin_mode:
                logger.info(f"ExHub: {ex_name} {coin} 仓位模式已符合要求 ({target_margin_mode})，跳过设置。")

            # 1.4 杠杆
            if lever is None:
                lever = current_lever or 1
            elif current_lever is not None and int(lever) != int(current_lever):
                logger.warning(f"ExHub: {ex_name} {coin} 杠杆不符 ({current_lever} -> {lever})，执行设置。")
                self.set_lever(exchange=exchange, coin=coin, lever=lever)
            else:
                logger.info(f"ExHub: {ex_name} {coin} 杠杆已符合要求 ({lever})，跳过设置。")


            # 1.5 获取行情和计算数量/止损价
            if amount or sl_percent:
                price_res = self.get_prices(exchange=exchange, coin=coin)
                price = Decimal(str(price_res.get(ex_name, {}).get("price", 0)))
                min_unit = info_res.get(ex_name, {}).get("min_unit")
                price_unit = info_res.get(ex_name, {}).get("price_unit")
                ct_val = info_res.get(ex_name, {}).get("ct_val", Decimal('1.0'))

                if price > 0:
                    # 计算数量：名义价值 = 本金 * 最终确定的杠杆
                    if amount and min_unit:
                        notional_amount = Decimal(str(amount)) * Decimal(str(lever))
                        kwargs['size'] = self._calculate_size(notional_amount, price, min_unit, ct_val)

                    # 计算止损价格
                    if price_unit and sl_percent:
                        sl_raw = (
                            price * (1 + Decimal(str(sl_percent)))
                            if side in ["SELL", "SHORT"]
                            else price * (1 - Decimal(str(sl_percent)))
                        )
                        kwargs['stop_loss_price'] = self._round_step(sl_raw, price_unit)
                    logger.info(f"ExHub: {ex_name}-{coin} 下单数量:{kwargs['size']} 止损价:{kwargs['stop_loss_price']} (sl={sl_percent})")

        # 2. 执行原始下单
        res = self._dispatch("futures", "order_futures", *args, **kwargs)

        # 3. 开仓后补挂止损单（全仓）
        for ex_tag in ["BINANCE", "BITGET", "OKX", "GATE", "HYPERLIQUID"]:
            if ex_tag in res and res[ex_tag].get("status"):
                sl_price = kwargs.get('stop_loss_price')
                if sl_price:
                    self.set_stop_loss(
                        exchange=ex_tag,
                        coin=coin,
                        side=side,
                        size=None,  # None = 全仓止损
                        stop_price=sl_price,
                    )

        return res

    def set_stop_loss(self, *args, **kwargs):
        """
        设置止损单
        :param exchange: 交易所
        :param coin: 币种
        :param side: 开仓方向
        :param size: 数量，0/None=全仓，>0=部分仓位（自动矫正精度）
        :param stop_price: 止损价
        """
        exchange = kwargs.get('exchange')
        coin = kwargs.get('coin')
        size = kwargs.get('size')
        stop_price = kwargs.get('stop_price')
        if exchange and coin:
            ex_name = exchange.upper()
            info_res = self.get_coin_info(exchange=exchange, coin=coin)
            price_unit = info_res.get(ex_name, {}).get("price_unit")
            min_unit = info_res.get(ex_name, {}).get("min_unit")
            if price_unit and stop_price:
                corrected = self._round_step(stop_price, price_unit)
                if str(corrected) != str(stop_price):
                    logger.debug(f"ExHub: {ex_name} {coin} 止损价格精度矫正 {stop_price} → {corrected} (tick={price_unit})")
                kwargs['stop_price'] = corrected
            if min_unit and size:
                corrected = self._correct_size(size, min_unit)
                if str(corrected) != str(size):
                    logger.debug(f"ExHub: {ex_name} {coin} 止损数量精度矫正 {size} → {corrected} (unit={min_unit})")
                kwargs['size'] = corrected

        return self._dispatch("futures", "set_stop_loss_futures", *args, **kwargs)

    def set_take_profit(self, *args, **kwargs):
        """
        设置止盈单
        :param exchange: 交易所
        :param coin: 币种
        :param side: 开仓方向
        :param size: 数量，0/None=全仓，>0=部分仓位（自动矫正精度）
        :param tp_price: 止盈价，内部自动按交易所 tick size 矫正
        """
        exchange = kwargs.get('exchange')
        coin = kwargs.get('coin')
        tp_price = kwargs.get('tp_price')
        size = kwargs.get('size')

        if exchange and coin:
            ex_name = exchange.upper()
            info_res = self.get_coin_info(exchange=exchange, coin=coin)
            price_unit = info_res.get(ex_name, {}).get("price_unit")
            min_unit = info_res.get(ex_name, {}).get("min_unit")
            if price_unit and tp_price:
                corrected = self._round_step(tp_price, price_unit)
                if str(corrected) != str(tp_price):
                    logger.debug(f"ExHub: {ex_name} {coin} 止盈价格精度矫正 {tp_price} → {corrected} (tick={price_unit})")
                kwargs['tp_price'] = corrected
            if min_unit and size:
                corrected = self._correct_size(size, min_unit)
                if str(corrected) != str(size):
                    logger.debug(f"ExHub: {ex_name} {coin} 止盈数量精度矫正 {size} → {corrected} (unit={min_unit})")
                kwargs['size'] = corrected

        return self._dispatch("futures", "set_take_profit_futures", *args, **kwargs)

    def update_stop_loss(self, *args, **kwargs):
        """
        更新止损单
        :param exchange: 交易所
        :param coin: 币种
        :param side: 开仓方向
        :param size: 数量，0/None=全仓，>0=部分仓位（自动矫正精度）
        :param stop_price: 止损价，内部自动按交易所 tick size 矫正
        """
        exchange = kwargs.get('exchange')
        coin = kwargs.get('coin')
        stop_price = kwargs.get('stop_price')
        size = kwargs.get('size')

        if exchange and coin:
            ex_name = exchange.upper()
            info_res = self.get_coin_info(exchange=exchange, coin=coin)
            price_unit = info_res.get(ex_name, {}).get("price_unit")
            min_unit = info_res.get(ex_name, {}).get("min_unit")
            if price_unit and stop_price:
                corrected = self._round_step(stop_price, price_unit)
                if str(corrected) != str(stop_price):
                    logger.debug(f"ExHub: {ex_name} {coin} 止损价格精度矫正 {stop_price} → {corrected} (tick={price_unit})")
                kwargs['stop_price'] = corrected
            if min_unit and size:
                corrected = self._correct_size(size, min_unit)
                if str(corrected) != str(size):
                    logger.debug(f"ExHub: {ex_name} {coin} 止损数量精度矫正 {size} → {corrected} (unit={min_unit})")
                kwargs['size'] = corrected

        return self._dispatch("futures", "update_stop_loss_futures", *args, **kwargs)

    def update_take_profit(self, *args, **kwargs):
        """
        更新止盈单
        :param exchange: 交易所
        :param coin: 币种
        :param side: 开仓方向
        :param size: 数量，0/None=全仓，>0=部分仓位（自动矫正精度）
        :param tp_price: 止盈价，内部自动按交易所 tick size 矫正
        """
        exchange = kwargs.get('exchange')
        coin = kwargs.get('coin')
        tp_price = kwargs.get('tp_price')
        size = kwargs.get('size')

        if exchange and coin:
            ex_name = exchange.upper()
            info_res = self.get_coin_info(exchange=exchange, coin=coin)
            price_unit = info_res.get(ex_name, {}).get("price_unit")
            min_unit = info_res.get(ex_name, {}).get("min_unit")
            if price_unit and tp_price:
                corrected = self._round_step(tp_price, price_unit)
                if str(corrected) != str(tp_price):
                    logger.debug(f"ExHub: {ex_name} {coin} 止盈价格精度矫正 {tp_price} → {corrected} (tick={price_unit})")
                kwargs['tp_price'] = corrected
            if min_unit and size:
                corrected = self._correct_size(size, min_unit)
                if str(corrected) != str(size):
                    logger.debug(f"ExHub: {ex_name} {coin} 止盈数量精度矫正 {size} → {corrected} (unit={min_unit})")
                kwargs['size'] = corrected

        return self._dispatch("futures", "update_take_profit_futures", *args, **kwargs)
    def get_position(self, *args, **kwargs): return self._dispatch("futures", "get_position_futures", *args, **kwargs)
    def get_pnl(self, *args, **kwargs): return self._dispatch("futures", "get_recent_pnl", *args, **kwargs)
    def get_prices(self, *args, **kwargs): return self._dispatch("futures", "get_prices_futures", *args, **kwargs)
    def set_lever(self, *args, **kwargs): return self._dispatch("futures", "set_coin_lever_futures", *args, **kwargs)
    def set_margin_mode(self, *args, **kwargs): return self._dispatch("futures", "set_margin_type_futures", *args, **kwargs)
    def get_coin_info(self, *args, **kwargs):
        """
        获取合约交易规范信息
        """
        exchange = kwargs.get('exchange')
        coin = kwargs.get('coin')
        if self.db and exchange and coin:
            ex_name = exchange.upper() if isinstance(exchange, str) else exchange
            try:
                row = self.db.fetch_one(
                    "SELECT * FROM exchange_info_cache WHERE exchange=%s AND coin=%s",
                    (ex_name, coin.upper())
                )
                if row:
                    from exhub.common import Common
                    return Common().return_futures_coin_info_struct(
                        ex_name, coin,
                        bool(row.get("swap_status", 0)),
                        Decimal(str(row.get("min_unit", "1"))),
                        Decimal(str(row.get("price_unit", "0.01"))),
                        Decimal('1'), Decimal('200'),
                        Decimal(str(row.get("ct_val", "1.0")))
                    )
            except Exception as e:
                logger.warning(f"ExHub: 查询合约信息缓存失败: {e}")

        return self._dispatch("futures", "get_coin_info_futures", *args, **kwargs)

    def get_coin_config(self, *args, **kwargs):
        """
        获取合约配置
        """
        exchange = kwargs.get('exchange')
        coin = kwargs.get('coin')
        if self.db and exchange and coin:
            ex_name = exchange.upper() if isinstance(exchange, str) else exchange
            try:
                row = self.db.fetch_one(
                    "SELECT * FROM position_config_cache WHERE exchange=%s AND coin=%s",
                    (ex_name, coin.upper())
                )
                if row:
                    from exhub.common import Common
                    return Common().return_futures_coin_config_struct(
                        ex_name, coin,
                        row.get("leverage", 0),
                        row.get("margin_mode", "cross")
                    )
            except Exception as e:
                logger.warning(f"ExHub: 查询杠杆配置缓存失败: {e}")

        return self._dispatch("futures", "get_coin_config_futures", *args, **kwargs)
    def close_position(self, *args, **kwargs):
        exchange = kwargs.get('exchange')
        coin = kwargs.get('coin')
        size = kwargs.get('size')
        
        if exchange and coin and size:
            ex_name = exchange.upper()
            if ex_name == "OKX":
                info_res = self.get_coin_info(exchange=exchange, coin=coin)
                min_unit = info_res.get(ex_name, {}).get("min_unit")
                ct_val = info_res.get(ex_name, {}).get("ct_val", Decimal('1.0'))
                
                try:
                    s = Decimal(str(size)) / Decimal(str(ct_val))
                    if min_unit:
                        min_unit = Decimal(str(min_unit))
                        steps = (s / min_unit).quantize(Decimal('1'), rounding="ROUND_DOWN")
                        size_val = steps * min_unit
                        min_unit_str = f"{min_unit:.10f}".rstrip('0').rstrip('.')
                        decimals = len(min_unit_str.split('.')[1]) if '.' in min_unit_str else 0
                        kwargs['size'] = f"{size_val:.{decimals}f}"
                    else:
                        kwargs['size'] = str(s)
                except Exception as e:
                    logger.error(f"ExHub: 计算平仓数量失败 {e}")

        return self._dispatch("futures", "close_position_futures", *args, **kwargs)

class SpotHub(BaseHub):
    """现货聚合分发接口"""
    def get_coin_info(self, *args, **kwargs): return self._dispatch("spot", "get_coin_info", *args, **kwargs)
    def get_klines(self, *args, **kwargs): return self._dispatch("spot", "get_klines", *args, **kwargs)
    def get_network_info(self, *args, **kwargs): return self._dispatch("spot", "get_coin_network_info", *args, **kwargs)
    def order(self, *args, **kwargs): return self._dispatch("spot", "order", *args, **kwargs)
    def get_orders_status(self, *args, **kwargs): return self._dispatch("spot", "get_orders_status", *args, **kwargs)
    def get_order_info(self, *args, **kwargs): return self._dispatch("spot", "get_order_info", *args, **kwargs)

class AssetHub(BaseHub):
    """资产聚合分发接口"""
    def get_balance(self, *args, **kwargs): return self._dispatch("asset", "get_balances", *args, **kwargs)

class ExHub:
    """分发聚合器"""
    def __init__(self, config: dict = None):
        self._exchanges = {}
        self._db = None
        cfg = config or {}

        # 初始化数据库连接
        db_host = os.getenv("EXHUB_DB_HOST")
        db_user = os.getenv("EXHUB_DB_USER")
        db_password = os.getenv("EXHUB_DB_PASSWORD")
        db_port = int(os.getenv("EXHUB_DB_PORT", "3306"))
        db_name = os.getenv("EXHUB_DB_NAME", "exhub")
        if db_host and db_user and db_password:
            try:
                self._db = DatabaseManager(
                    database=db_name, host=db_host,
                    user=db_user, password=db_password, port=db_port
                )
            except Exception as e:
                logger.warning(f"ExHub: 数据库初始化失败: {e}")
                self._db = None
        else:
            logger.info("ExHub: 未配置数据库环境变量。")

        # 1. Binance
        binance_cfg = cfg.get("binance") or {"api_key": os.getenv("BINANCE_API_KEY"), "api_secret": os.getenv("BINANCE_API_SECRET")}
        if binance_cfg.get("api_key") and binance_cfg.get("api_secret"):
            self._exchanges["binance"] = BINANCE(**binance_cfg)
            logger.info("ExHub: Binance 已成功初始化。")
        else:
            logger.warning("ExHub: Binance 未初始化(缺少 BINANCE_API_KEY 或 BINANCE_API_SECRET)。")

        # 2. OKX
        okx_cfg = cfg.get("okx") or {"api_key": os.getenv("OKX_API_KEY"), "api_secret": os.getenv("OKX_API_SECRET"), "passphrase": os.getenv("OKX_PASSPHRASE")}
        if okx_cfg.get("api_key") and okx_cfg.get("api_secret"):
            self._exchanges["okx"] = OKX(**okx_cfg)
            logger.info("ExHub: OKX 已成功初始化。")
        else:
            logger.warning("ExHub: OKX 未初始化(缺少 OKX_API_KEY 、 OKX_API_SECRET 或 OKX_PASSPHRASE)。")

        # 3. Bitget
        bitget_cfg = cfg.get("bitget") or {"api_key": os.getenv("BITGET_API_KEY"), "api_secret": os.getenv("BITGET_API_SECRET"), "passphrase": os.getenv("BITGET_PASSPHRASE")}
        if bitget_cfg.get("api_key") and bitget_cfg.get("api_secret"):
            self._exchanges["bitget"] = BITGET(**bitget_cfg)
            logger.info("ExHub: Bitget 已成功初始化。")
        else:
            logger.warning("ExHub: Bitget 未初始化(缺少 BITGET_API_KEY 、 BITGET_API_SECRET 或 BITGET_PASSPHRASE)。")

        # 4.Gate
        gate_cfg = cfg.get("gate") or {"api_key": os.getenv("GATE_API_KEY"), "api_secret": os.getenv("GATE_API_SECRET")}
        if gate_cfg.get("api_key") and gate_cfg.get("api_secret"):
            self._exchanges["gate"] = GATE(**gate_cfg)
            logger.info("ExHub: Gate 已成功初始化。")
        else:
            logger.warning("ExHub: Gate 未初始化(缺少 GATE_API_KEY 或 GATE_API_SECRET)。")

        # 5. Hyperliquid
        hyper_cfg = cfg.get("hyperliquid") or {"private_key": os.getenv("HYPERLIQUID_PRIVATE_KEY"), "account_address": os.getenv("HYPERLIQUID_ACCOUNT_ADDRESS")}
        if hyper_cfg.get("private_key"):
            self._exchanges["hyperliquid"] = HYPERLIQUID(**hyper_cfg)
            logger.info(f"ExHub: Hyperliquid 已成功初始化,地址: {self._exchanges['hyperliquid'].address}")
        else:
            logger.warning("ExHub: Hyperliquid 未初始化(缺少 HYPERLIQUID_PRIVATE_KEY)。")

        self.futures = FuturesHub(self._exchanges, db=self._db)
        self.spot = SpotHub(self._exchanges)
        self.asset = AssetHub(self._exchanges)
        
        #self.binance = self._exchanges.get("binance")
        #self.okx = self._exchanges.get("okx")
        #self.bitget = self._exchanges.get("bitget")
        #self.gate = self._exchanges.get("gate")