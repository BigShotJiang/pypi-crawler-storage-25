import pymysql
from pymysql.cursors import DictCursor
from dbutils.pooled_db import PooledDB
from loguru import logger
import time
import ssl
from functools import wraps
from contextlib import contextmanager

def retry_on_db_error(max_retries=3, retry_delay=1):
    """数据库操作重试装饰器"""
    def decorator(func):
        @wraps(func)
        def wrapper(self, *args, **kwargs):
            for attempt in range(max_retries):
                try:
                    return func(self, *args, **kwargs)
                except (pymysql.Error, Exception) as e:
                    logger.warning(f"执行 {func.__name__} 失败 (尝试 {attempt + 1}/{max_retries}): {str(e)}")
                    if attempt < max_retries - 1:
                        time.sleep(retry_delay)
                        continue
                    else:
                        logger.error(f"{func.__name__} 执行失败，已达到最大重试次数: {str(e)}")
                        raise
            return None
        return wrapper
    return decorator

@contextmanager
def ignore_error():
    try:
        yield
    except Exception as e:
        pass

class DatabaseManager:
    def __init__(self, database, host, user, password, port, ca_path=None):
        """
        :param database: 数据库名称
        :param host: 数据库主机地址
        :param user: 数据库用户名
        :param password: 数据库密码
        :param port: 数据库端口
        :param ca_path: SSL证书路径[可选]
        """
        self.db_params = {
            'host': host,
            'user': user,
            'password': password,
            'database': database,
            'port': port,
            'charset': 'utf8mb4',
            'cursorclass': DictCursor,
            'connect_timeout': 60,
            'read_timeout': 30,
            'write_timeout': 30
        }
        self.ca_path = ca_path
        
        if self.ca_path:
            self._setup_ssl()

        # 初始化连接池
        self._init_pool()

    def _setup_ssl(self):
        """配置SSL连接"""
        try:
            # 忽略主机名匹配检查
            context = ssl.create_default_context(cafile=self.ca_path)
            context.check_hostname = False
            context.verify_mode = ssl.CERT_REQUIRED
            self.db_params['ssl'] = context
        except Exception as e:
            logger.warning(f"SSL配置失败: {str(e)}")

    def _init_pool(self):
        """初始化或重建连接池"""
        try:
            # 如果已存在连接池，先关闭
            if hasattr(self, 'pool') and self.pool:
                self.close()
            
            self.pool = PooledDB(
                creator=pymysql,  # 使用 pymysql
                maxconnections=10,  # 连接池允许的最大连接数
                mincached=2,       # 初始化时至少创建的空闲连接
                maxcached=5,       # 连接池中最多闲置的连接数
                blocking=True,     # 连接池满时阻塞等待
                ping=2,            # 检查连接是否可用 (2=execute时检测)
                **self.db_params
            )
            logger.info(f"数据库连接池初始化成功: {self.db_params['host']}-{self.db_params['database']}")
        except Exception as e:
            logger.error(f"数据库连接池初始化失败: {str(e)}")
            raise

    def switch_db(self, db_name):
        """切换数据库"""
        try:
            if self.db_params['database'] == db_name:
                return
            
            logger.info(f"正在切换数据库: {self.db_params['database']} -> {db_name}")
            self.db_params['database'] = db_name
            # 重建连接池以应用新的数据库设置
            self._init_pool()
            logger.info(f"成功切换到数据库: {db_name}")
        except Exception as e:
            logger.error(f"切换数据库失败: {str(e)}")
            raise

    @retry_on_db_error()
    def execute(self, sql, params=None):
        """执行SQL语句 (INSERT/UPDATE/DELETE)，返回影响行数"""
        conn = self.pool.connection()
        try:
            with conn.cursor() as cursor:
                rowcount = cursor.execute(sql, params)
                conn.commit()
                return rowcount
        finally:
            conn.close() # 归还连接给池

    @retry_on_db_error()
    def executemany(self, sql, params_list):
        """批量执行SQL语句"""
        conn = self.pool.connection()
        try:
            with conn.cursor() as cursor:
                rowcount = cursor.executemany(sql, params_list)
                conn.commit()
                return rowcount
        finally:
            conn.close()

    @retry_on_db_error()
    def fetch_one(self, query, params=None):
        """获取单条记录"""
        conn = self.pool.connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(query, params or ())
                return cursor.fetchone()
        finally:
            conn.close()

    @retry_on_db_error()
    def fetch_all(self, query, params=None):
        """获取所有记录"""
        conn = self.pool.connection()
        try:
            with conn.cursor() as cursor:
                cursor.execute(query, params or ())
                return cursor.fetchall()
        finally:
            conn.close()

    def close(self):
        """关闭连接池"""
        try:
            if hasattr(self, 'pool') and self.pool:
                self.pool.close()
                self.pool = None
        except Exception as e:
            logger.error(f"关闭数据库连接池失败: {str(e)}")

    def __enter__(self):
        """上下文管理器入口"""
        if not hasattr(self, 'pool') or not self.pool:
            self._init_pool()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """上下文管理器出口"""
        self.close()