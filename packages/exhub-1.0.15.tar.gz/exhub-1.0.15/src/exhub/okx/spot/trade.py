from decimal import Decimal

from loguru import logger
from exhub.common import Common
class SpotTrade:
    """OKX 现货交易实现"""
    def __init__(self, client):
        self.client = client

    def order(self, coin, side, order_type, amount):
        """
        下单 (POST /api/v5/trade/order)
        :param instId: 产品ID (如 BTC-USDT)
        :param side: 订单方向 (buy, sell)
        :param ordType: 订单类型 (market, limit, etc.)
        :param sz: 委托数量
        :param tdMode: 交易模式 (cash:非保证金, isolated:逐仓, cross:全仓). 现货默认 cash.
        :param kwargs: 其他可选参数 (px, clOrdId, etc.)
        """
        path = "/api/v5/trade/order"
        body = {
            "instId": coin if coin.endswith("-USDT") else coin+"-USDT",
            "side": side,
            "ordType": order_type,
            "sz": str(amount),
            "tdMode": "cash"
        }

        for k, v in body.items():
            if not isinstance(v, str):
                body[k] = str(v)

        res = self.client.post(path, body)
        logger.debug(res)
        if res.get("code") == "0":
            data = res.get("data", [])
            if data:
                logger.success(f"下单成功: {coin} {side} {amount}, ordId: {data[0].get('ordId')}")
                return Common().return_order_struct("OKX", coin, side, order_type, amount, data[0].get('ordId'), res)
        else:
            raise Exception(res.get("msg", "Unknown error"))

        return None

    def get_orders_status(self, coin, order_id):
        """
        GET /api/v5/trade/order
        https://www.okx.com/docs-v5/zh/#order-book-trading-trade-get-order-details
        :param coin:
        :param order_id:
        :return:
        """
        path = "/api/v5/trade/order"
        params = {"instId": coin if coin.endswith("-USDT") else coin+"-USDT", "ordId": order_id}
        res = self.client.get(path, params=params)
        logger.debug( res)
        if res.get("code") == "0":
            data = res.get("data", [])
            if data.get("status") == "filled":
                order_status = "FILLED"
            elif data.get("status") in ["live", "partially_filled"]:
                order_status = "PROCESSING"
            else:
                order_status = "FAILED"
            return Common().return_order_status_struct("OKX", data.get("instId"), order_id, data.get("side"),data.get("ordType"),order_status,res)
        else:
            raise Exception(res.get("msg", "Unknown error"))



    def get_order_info(self, coin, order_id):
        """
         GET /api/v5/trade/order
         https://www.okx.com/docs-v5/zh/#order-book-trading-trade-get-order-details
         :param coin:
         :param order_id:
         :return:
         """
        path = "/api/v5/trade/order"
        params = {"instId": coin if coin.endswith("-USDT") else coin+"-USDT", "ordId": order_id}
        res = self.client.get(path, params=params)
        logger.debug( res)
        if res.get("code") == "0":
            data = res.get("data", [])
            return Common().return_order_info_struct("OKX", data.get("instId"), data.get("size"), order_id,Decimal("0"), data.get("avgPx"), res)
        else:
            raise Exception(res.get("msg", "Unknown error"))
