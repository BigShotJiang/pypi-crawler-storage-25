from loguru import logger
from decimal import Decimal
from exhub.common import Common


class SpotMarket:
    """OKX 现货行情 API"""
    def __init__(self, client):
        self.client = client

    def get_coin_network_info(self, coin=None, network=None):
        """
        获取币种信息
        """
        path = "/api/v5/asset/currencies"
        params = {}
        if coin:
            params["ccy"] = coin

        res = self.client.get(path, params=params)
        logger.debug(res)
        
        if network:
            return_data = Common().return_coin_network_info_struct("OKX", False, False, None, 0)
        else:
            return_data = {"OKX": []}
            
        chain_ls = network.split(",") if network else []   # 链多个名称
        if res.get("code") == "0":
            data = res.get("data", [])
            logger.info(f'币种: {coin},获取到 {len(data)} 个币种信息')
            for coin_info in data:
                chain_name = coin_info.get("chain").split("-")[-1]
                ct_addr = coin_info.get("ctAddr") if coin_info.get("ctAddr") else None
                can_dep = coin_info.get("canDep") == "1" if isinstance(coin_info.get("canDep"), str) else bool(coin_info.get("canDep"))
                can_wd = coin_info.get("canWd") == "1" if isinstance(coin_info.get("canWd"), str) else bool(coin_info.get("canWd"))

                if chain_name in chain_ls:
                    return_data = Common().return_coin_network_info_struct("OKX", can_wd, can_dep, ct_addr, coin_info.get("fee", 0))
                    logger.info(
                        f'  - 链: {chain_name}, 可充值: {can_dep}, 可提币: {can_wd}, 合约地址: {ct_addr}, 提币费用: {coin_info.get("fee")}')
                else:
                    if not network:
                        new_entry = {
                            "dex_chain_name": None,
                            "cex_chain_name": chain_name,
                            "withdraw_status": can_wd,
                            "deposit_status": can_dep,
                            "contract_address": ct_addr,
                            "withdrawFee": coin_info.get("fee"),
                        }
                        return_data["OKX"].append(new_entry)
                    logger.debug(
                        f'  - 链: {chain_name}, 可充值: {can_dep}, 可提币: {can_wd}, 合约地址: {ct_addr}, 提币费用: {coin_info.get("fee")}')
            return return_data
        else:
            raise Exception(res.get("msg", "Unknown error"))

    def get_coin_info(self, coin):
        """
        获取所有可交易产品的信息列表
        https://www.okx.com/docs-v5/zh/#public-data-rest-api-get-instruments
        """
        path = "/api/v5/public/instruments"
        params = {"instType": "SPOT"}
        res = self.client.get(path, params=params)
        
        swap_status = False
        min_unit = 0
        
        if res.get("code") == "0":
            data = res.get("data", [])
            for item in data:
                if item["instId"] == coin+"-USDT":
                    logger.debug(item)
                    logger.info(f"  {coin} - 现货状态 :{True if item['state'] == 'live' else False}")
                    swap_status = True
                    min_unit = item["minSz"]
        else:
            logger.error(f"获取产品列表失败: {res.get('msg')}")
            raise Exception(res.get("msg"))

        return Common().return_coin_info_struct("OKX", swap_status, min_unit)

    def get_klines(self, coin, interval, limit=1):
        """
        获取K线数据
        """
        # OKX K线实现目前为空，返回统一空结构
        return Common().return_klines_struct("OKX", 0)

