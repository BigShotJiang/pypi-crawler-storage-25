from loguru import logger
from exhub.config import Config
from exhub.common import Common

class Account:
    """资金账户 API"""
    def __init__(self, client):
        self.client = client

    def get_balances(self, ccy, asset_type):
        """
        获取账户余额
        :param ccy: 货币，例如 "BTC"
        :param asset_type: 资产类型 (fund, spot, futures)
        """

        if asset_type == "fund":
            path = "/api/v5/asset/balances"
            params = {}
            if ccy:
                params["ccy"] = ccy

            res = self.client.get(path, params=params)
            logger.debug(res)

            if res.get("code") == "0":
                data = res.get("data", [])[0]
                logger.info(
                    f'ccy = {data.get("ccy")}, bal = {data.get("bal")}, availBal = {data.get("availBal")}, frozenBal = {data.get("frozenBal")}')
                return Common().return_asset_struct("OKX", "fund", ccy, data.get("availBal"))
            else:
                raise Exception(res.get("msg", "Unknown error"))

        elif asset_type in ["spot", "futures"]:
            path = "/api/v5/account/balance"
            params = {}
            if ccy:
                params["ccy"] = ccy

            res = self.client.get(path, params=params)
            logger.debug(res)

            if res.get("code") == "0":
                data = res.get("data", [])
                if data:
                    details = data[0].get("details", [])
                    for item in details:
                        if item.get("ccy") == ccy:
                            val = item.get("availBal") or item.get("availEq")
                            return Common().return_asset_struct("OKX", asset_type, ccy, val)
                return None
            else:
                raise Exception(res.get("msg", "Unknown error"))

        return None


    def transfer(self, coin, amount, type_from, type_to, tag = None,type="0", **kwargs):
        """
        资金划转 (POST /api/v5/asset/transfer)
        :param from_acct: 6:资金账户, 18:交易账户
        :param to_acct: 6:资金账户, 18:交易账户
        """

        path = "/api/v5/asset/transfer"
        body = {
            "ccy": coin,
            "amt": str(amount),
            "from": Config().unify_variables_transfer_type("OKX", f = str(type_from)),
            "to": Config().unify_variables_transfer_type("OKX", t = str(type_to)),
            "type": str(type)
        }
        if tag:
            body["rcvrInfo"] = tag
        body.update(kwargs)

        res = self.client.post(path, body)
        if res.get("code") == "0":
            return Common().return_transfer_struct("OKX", type_from, type_to, coin, amount)
        else:
            raise Exception(res.get("msg", "Unknown error"))