from decimal import Decimal
import time
from loguru import logger
from exhub.common import Common

class FuturesMarket():
    """OKX 合约市场"""
    def __init__(self, client):
        self.client = client

    def get_prices_futures(self, coin):
        """
        获取指定代币对价格
        GET /api/v5/market/ticker
        https://www.okx.com/docs-v5/zh/#public-data-rest-api-get-ticker
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        symbol = symbol.replace("USDT", "-USDT") if "USDT" in symbol and "-" not in symbol else symbol
        if symbol.endswith("-USDT"):
            symbol = symbol + "-SWAP"
            
        path = "/api/v5/market/ticker"
        params = {
            "instId": symbol
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        if res and res.get("code") == "0" and res.get("data"):
            data = res["data"][0]
            coin_res = data.get("instId", symbol).replace("-SWAP", "").replace("-", "")
            price = data.get("last")
            ts = data.get("ts", int(time.time()*1000))
            return Common().return_futures_price_struct("OKX", coin_res, price, ts)
        return None

    def get_coin_info_futures(self, coin):
        """
        获取合约交易规范信息
        GET /api/v5/public/instruments
        https://www.okx.com/docs-v5/zh/#public-data-rest-api-get-instruments
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        symbol = symbol.replace("USDT", "-USDT") if "USDT" in symbol and "-" not in symbol else symbol
        if symbol.endswith("-USDT"):
            symbol = symbol + "-SWAP"
            
        path = "/api/v5/public/instruments"
        params = {
            "instType": "SWAP",
            "instId": symbol
        }
        res = self.client.get(path, params=params)
        logger.debug(res)
        
        if res and res.get("code") == "0" and res.get("data"):
            data = res["data"][0]
            coin_res = data.get("instId", symbol).replace("-SWAP", "").replace("-", "")
            min_unit = data.get("lotSz", "1")  # OKX 使用 lotSz 作为下单最小单位（张数步进）
            price_unit = data.get("tickSz", "0.01") # 价格步进
            
            ct_val = data.get("ctVal", "1") # 合约面值
            swap_status = data.get("state") == "live"
            max_lever = data.get("lever", "10")
            min_lever = 1
            return Common().return_futures_coin_info_struct("OKX", coin_res, swap_status, Decimal(str(min_unit)), Decimal(str(price_unit)), Decimal(str(min_lever)), Decimal(str(max_lever)), Decimal(str(ct_val)))
        else:
            return Common().return_futures_coin_info_struct("OKX", coin, False, "1", "0.01", 1, 100, Decimal('1.0'))

    def get_coin_config_futures(self, coin):
        """
        获取合约代币的配置-杠杆配置信息
        GET /api/v5/account/leverage-info
        https://www.okx.com/docs-v5/zh/#custom-trading-rest-api-get-leverage
        :param coin:
        :return:
        """
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        symbol = symbol.replace("USDT", "-USDT") if "USDT" in symbol and "-" not in symbol else symbol
        if symbol.endswith("-USDT"):
            symbol = symbol + "-SWAP"
            
        path = "/api/v5/account/leverage-info"
        params = {"instId": symbol, "mgnMode": "isolated"}
        res = self.client.get(path, params=params)
        logger.debug(res)
        leverage = 0
        margin_mode = "cross"
        if res and res.get("code") == "0" and res.get("data"):
            longlever = 0
            shortlever = 0
            margin_mode = None
            for item in res["data"]:
                if item.get("posSide") == "long":
                    longlever = item.get("lever", leverage)
                elif item.get("posSide") == "short":
                    shortlever = item.get("lever", leverage)
                margin_mode = item.get("mgnMode", "cross")
            if longlever == shortlever:
                leverage = longlever
            else:
                leverage = 1 # 随便一个与3不符的数字
        return Common().return_futures_coin_config_struct("OKX", coin, leverage, margin_mode)

    def set_margin_type_futures(self, coin, margin_mode="isolated"):
        """仅逐仓, 无独立 API"""
        return {"msg": "isolated"}

    def set_coin_lever_futures(self, coin, lever):
        """设置杠杆倍数 (OKX 逐仓时多空需分别设置)"""
        symbol = coin.upper() if coin.endswith("USDT") else coin.upper() + "-USDT"
        symbol = symbol.replace("USDT", "-USDT") if "USDT" in symbol and "-" not in symbol else symbol
        if symbol.endswith("-USDT"):
            symbol = symbol + "-SWAP"
        path = "/api/v5/account/set-leverage"
        for ps in ("long", "short"):
            body = {
                "instId": symbol,
                "mgnMode": "isolated",
                "posSide": ps,
                "lever": str(lever)
            }
            try:
                res = self.client.post(path, body=body)
                logger.debug(f"OKX set_lever {ps}: {res}")
            except Exception as e:
                logger.warning(f"OKX set_lever {ps} 异常: {e}")

        return self.get_coin_config_futures(coin)

