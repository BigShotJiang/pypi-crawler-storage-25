__version__ = '0.42.6'         
__author__ = 'pengyeqin'

def hello():
    print("Hello from ub-clean-test!")