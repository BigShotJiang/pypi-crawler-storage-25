"""CLI entry point for agentevals.

Usage::

    agentevals run samples/helm.json --eval-set samples/eval_set_helm.json
    agentevals run samples/helm.json -m tool_trajectory_avg_score -m response_match_score
    agentevals run samples/helm.json --eval-set samples/eval_set_helm.json --output json
    agentevals evaluator list --source builtin
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from datetime import datetime, timezone

import click

from . import __version__
from .api.otlp_grpc import create_otlp_grpc_server, stop_otlp_grpc_server


def _relative_time(iso_str: str | None) -> str:
    """Format an ISO 8601 timestamp as a human-readable relative time string."""
    if not iso_str:
        return ""
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        delta = datetime.now(timezone.utc) - dt
        seconds = int(delta.total_seconds())
        if seconds < 0:
            return "just now"
        if seconds < 60:
            return f"{seconds}s ago"
        minutes = seconds // 60
        if minutes < 60:
            return f"{minutes}m ago"
        hours = minutes // 60
        if hours < 24:
            return f"{hours}h ago"
        days = hours // 24
        if days < 30:
            return f"{days}d ago"
        months = days // 30
        if months < 12:
            return f"{months}mo ago"
        years = days // 365
        return f"{years}y ago"
    except (ValueError, TypeError):
        return ""


@click.group()
@click.version_option(version=__version__, prog_name="agentevals")
@click.option(
    "-v",
    "--verbose",
    count=True,
    help="Increase verbosity (-v for INFO, -vv for DEBUG).",
)
def main(verbose: int) -> None:
    """agentevals: Evaluate agent traces using ADK's scoring framework."""
    level = logging.WARNING
    if verbose == 1:
        level = logging.INFO
    elif verbose >= 2:
        level = logging.DEBUG
    logging.basicConfig(
        level=level,
        format="%(levelname)s %(name)s: %(message)s",
    )


@main.command()
@click.argument("trace_files", nargs=-1, required=True, type=click.Path(exists=True))
@click.option(
    "--eval-set",
    "-e",
    type=click.Path(exists=True),
    default=None,
    help="Path to a golden eval set JSON file (ADK EvalSet format).",
)
@click.option(
    "--metric",
    "-m",
    multiple=True,
    default=None,
    help="Metric(s) to evaluate. Can be specified multiple times. Default: tool_trajectory_avg_score.",
)
@click.option(
    "--format",
    "-f",
    "trace_format",
    default=None,
    type=click.Choice(["jaeger-json", "otlp-json"], case_sensitive=False),
    help="Override the trace file format. Auto-detected from file contents when omitted.",
)
@click.option(
    "--judge-model",
    "-j",
    default=None,
    help="LLM model for judge-based metrics (default: gemini-2.5-flash).",
)
@click.option(
    "--threshold",
    "-t",
    type=float,
    default=None,
    help="Score threshold for pass/fail.",
)
@click.option(
    "--trajectory-match-type",
    type=click.Choice(["EXACT", "IN_ORDER", "ANY_ORDER"], case_sensitive=False),
    default=None,
    help="Match type for tool_trajectory_avg_score: EXACT (default), IN_ORDER, or ANY_ORDER.",
)
@click.option(
    "--output",
    "-o",
    type=click.Choice(["table", "json", "summary"]),
    default="table",
    help="Output format.",
)
@click.option(
    "--config",
    "-c",
    "config_file",
    type=click.Path(exists=True),
    default=None,
    help="Path to an eval config YAML file defining evaluators.",
)
def run(
    trace_files: tuple[str, ...],
    eval_set: str | None,
    metric: tuple[str, ...] | None,
    trace_format: str | None,
    judge_model: str | None,
    threshold: float | None,
    trajectory_match_type: str | None,
    output: str,
    config_file: str | None,
) -> None:
    """Evaluate trace file(s) against the configured evaluators."""
    from .config import EvalRunConfig, apply_builtin_overrides, make_builtin_evaluator_entries
    from .output import format_results
    from .runner import run_evaluation

    explicit_metrics = list(metric) if metric else []

    if config_file:
        from .eval_config_loader import load_eval_config

        config = load_eval_config(config_file)
        if explicit_metrics:
            cli_evaluators = make_builtin_evaluator_entries(
                explicit_metrics,
                judge_model=judge_model,
                threshold=threshold,
                trajectory_match_type=trajectory_match_type,
            )
            by_name = {e.name: e for e in config.evaluators}
            for ev in cli_evaluators:
                by_name[ev.name] = ev
            config.evaluators = list(by_name.values())
        elif judge_model is not None or threshold is not None or trajectory_match_type is not None:
            config.evaluators = apply_builtin_overrides(
                config.evaluators,
                judge_model=judge_model,
                threshold=threshold,
                trajectory_match_type=trajectory_match_type,
            )
    else:
        config = EvalRunConfig(
            trace_files=[],
            evaluators=make_builtin_evaluator_entries(
                explicit_metrics or None,
                judge_model=judge_model,
                threshold=threshold,
                trajectory_match_type=trajectory_match_type,
            ),
        )

    if trace_files:
        config.trace_files = list(trace_files)
    if eval_set is not None:
        config.eval_set_file = eval_set
    if trace_format is not None:
        config.trace_format = trace_format
    if output != "table":
        config.output_format = output

    result = asyncio.run(run_evaluation(config))
    formatted = format_results(result, fmt=config.output_format)
    click.echo(formatted)

    has_failure = any(mr.eval_status == "FAILED" or mr.error for tr in result.trace_results for mr in tr.metric_results)
    if has_failure or result.errors:
        sys.exit(1)


# ---------------------------------------------------------------------------
# agentevals evaluator ...
# ---------------------------------------------------------------------------


@main.group()
def evaluator() -> None:
    """Manage evaluators: scaffold, list, and discover."""


@evaluator.command("init")
@click.argument("name")
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(),
    default=".",
    help="Parent directory for the new evaluator folder (default: current directory).",
)
@click.option(
    "--runtime",
    "-r",
    default=None,
    help="Language runtime: py, js, ts (default: inferred from name or py).",
)
def evaluator_init(name: str, output_dir: str, runtime: str | None) -> None:
    """Scaffold a new evaluator with boilerplate code and an evaluator.yaml manifest.

    NAME is the evaluator name. If it ends with a recognized extension (.py, .js,
    .ts) the language is inferred automatically; otherwise use --runtime.

    \b
    Examples:
      agentevals evaluator init my_evaluator
      agentevals evaluator init my_evaluator.ts
      agentevals evaluator init my_evaluator --runtime js
    """
    from pathlib import Path as _Path

    from .evaluator.templates import scaffold_evaluator

    try:
        evaluator_dir = scaffold_evaluator(name, output_dir=_Path(output_dir), runtime=runtime)
    except (ValueError, OSError) as exc:
        raise click.ClickException(str(exc)) from exc

    click.echo(f"Created evaluator in {evaluator_dir}/")
    click.echo()
    click.echo("Files:")
    for f in sorted(evaluator_dir.iterdir()):
        click.echo(f"  {f.relative_to(evaluator_dir.parent)}")
    click.echo()
    click.echo("Next steps:")
    click.echo("  1. Implement your scoring logic in the generated code file")
    click.echo("  2. Add it to your eval_config.yaml under 'evaluators':")
    click.echo()

    code_files = [f for f in evaluator_dir.iterdir() if f.suffix in (".py", ".js", ".ts")]
    evaluator_name = evaluator_dir.name
    if code_files:
        rel = code_files[0].relative_to(evaluator_dir.parent)
        click.echo("     evaluators:")
        click.echo(f"       - name: {evaluator_name}")
        click.echo("         type: code")
        click.echo(f"         path: ./{rel}")
        click.echo("         threshold: 0.5")
    click.echo()
    click.echo("  3. Run: agentevals run <trace_file> --config eval_config.yaml")


@evaluator.command("runtimes")
def evaluator_runtimes() -> None:
    """Show supported language runtimes and execution environments."""
    from .custom_evaluators import _EXECUTOR_FACTORIES, get_runtimes

    click.echo("Language runtimes:\n")
    for rt in get_runtimes():
        exts = ", ".join(rt.extensions)
        available = "available" if rt.is_available() else "not found"
        click.echo(f"  {rt.name:<12}  extensions: {exts:<16}  ({available})")

    click.echo("\nExecutors:\n")
    for name in sorted(_EXECUTOR_FACTORIES):
        click.echo(f"  {name}")

    click.echo()


@evaluator.command("list")
@click.option(
    "--source",
    "-s",
    type=click.Choice(["all", "builtin", "github"]),
    default="all",
    help="Filter evaluators by source (default: all).",
)
@click.option(
    "--refresh",
    is_flag=True,
    default=False,
    help="Ignore cached results and fetch fresh data.",
)
def evaluator_list(source: str, refresh: bool) -> None:
    """List available evaluators from all registered sources."""
    from .evaluator.sources import _cache_dir, get_sources

    if refresh:
        import shutil

        cache = _cache_dir()
        if cache.exists():
            shutil.rmtree(cache, ignore_errors=True)

    sources = get_sources()
    if source != "all":
        sources = [s for s in sources if s.source_name == source]

    click.echo("  Fetching evaluators...", nl=False)
    all_evaluators = asyncio.run(_collect_evaluators(sources))
    click.echo("\r" + " " * 30 + "\r", nl=False)

    if not all_evaluators:
        click.echo("No evaluators found.")
        return

    max_name = max(len(g.name) for g in all_evaluators)
    max_src = max(len(g.source) for g in all_evaluators)

    has_updated = any(g.last_updated for g in all_evaluators)
    updated_col_width = 10 if has_updated else 0

    try:
        term_width = os.get_terminal_size().columns
    except OSError:
        term_width = 120

    overhead = max_name + max_src + 8
    if has_updated:
        overhead += updated_col_width + 2
    desc_width = max(20, term_width - overhead)

    hdr_updated = f"  {'UPDATED':<{updated_col_width}}" if has_updated else ""
    sep_updated = f"  {'-' * updated_col_width}" if has_updated else ""

    click.echo(f"  {'NAME':<{max_name}}  {'SOURCE':<{max_src}}{hdr_updated}  DESCRIPTION")
    click.echo(f"  {'-' * max_name}  {'-' * max_src}{sep_updated}  {'-' * min(40, desc_width)}")

    for g in sorted(all_evaluators, key=lambda x: (x.source, x.name)):
        lang = f" [{g.language}]" if g.language else ""
        desc = g.description + lang
        if len(desc) > desc_width:
            desc = desc[: desc_width - 3] + "..."
        col_updated = f"  {_relative_time(g.last_updated):<{updated_col_width}}" if has_updated else ""
        click.echo(f"  {g.name:<{max_name}}  {g.source:<{max_src}}{col_updated}  {desc}")

    click.echo(f"\n  {len(all_evaluators)} evaluator(s) found.")


async def _collect_evaluators(sources):
    """Gather evaluator lists from all sources concurrently."""
    import asyncio as _asyncio

    from .evaluator.sources import EvaluatorInfo

    results: list[EvaluatorInfo] = []
    tasks = [s.list_evaluators() for s in sources]
    for evaluators in await _asyncio.gather(*tasks, return_exceptions=True):
        if isinstance(evaluators, BaseException):
            click.echo(f"  Warning: failed to fetch from a source: {evaluators}", err=True)
            continue
        results.extend(evaluators)
    return results


@evaluator.command("config")
@click.argument("name")
@click.option(
    "--path",
    "-p",
    "evaluator_path",
    default=None,
    help="Path to the evaluator script (used for local code evaluators).",
)
@click.option(
    "--threshold",
    "-t",
    type=float,
    default=None,
    help="Score threshold (default: 0.5 for custom evaluators).",
)
def evaluator_config(name: str, evaluator_path: str | None, threshold: float | None) -> None:
    """Generate an eval_config.yaml snippet for an evaluator."""
    import yaml as _yaml

    from .builtin_metrics import METRICS_NEEDING_EXPECTED, METRICS_NEEDING_GCP, METRICS_NEEDING_LLM
    from .evaluator.sources import get_sources

    sources = get_sources()
    all_evaluators = asyncio.run(_collect_evaluators(sources))

    match = next((g for g in all_evaluators if g.name == name), None)

    if match and match.source == "builtin":
        needs_eval_set = name in METRICS_NEEDING_EXPECTED
        needs_llm = name in METRICS_NEEDING_LLM
        needs_gcp = name in METRICS_NEEDING_GCP

        entry: dict = {"name": name, "type": "builtin"}
        if threshold is not None:
            entry["threshold"] = threshold
        else:
            entry["threshold"] = 0.5
        if needs_llm:
            entry["judge_model"] = "gemini-2.5-flash"

        snippet: dict = {"evaluators": [entry]}

        notes: list[str] = []
        if needs_eval_set:
            notes.append("Requires --eval-set (golden eval set with expected responses)")
        if needs_llm:
            notes.append("Requires GOOGLE_API_KEY (or GEMINI_API_KEY) for LLM judge")
        if needs_gcp:
            notes.append("Requires GOOGLE_CLOUD_PROJECT and GOOGLE_CLOUD_LOCATION (Vertex AI)")

        comment = "# Add to your eval_config.yaml under 'evaluators':"
        if notes:
            comment += "\n#\n# Notes:\n" + "\n".join(f"#   - {n}" for n in notes)
    elif match and match.source != "builtin":
        entry: dict = {
            "name": name,
            "type": "remote",
            "source": match.source,
            "ref": match.ref or f"evaluators/{name}",
        }
        if threshold is not None:
            entry["threshold"] = threshold
        else:
            entry["threshold"] = 0.5
        entry["executor"] = "local"
        snippet = {"evaluators": [entry]}
        comment = "# Add to your eval_config.yaml under 'evaluators':"
    else:
        path_val = evaluator_path or f"./{name}/{name}.py"
        entry = {
            "name": name,
            "type": "code",
            "path": path_val,
        }
        if threshold is not None:
            entry["threshold"] = threshold
        else:
            entry["threshold"] = 0.5
        entry["executor"] = "local"
        snippet = {"evaluators": [entry]}
        comment = "# Add to your eval_config.yaml under 'evaluators':"

    rendered = _yaml.dump(snippet, default_flow_style=False, sort_keys=False)
    click.echo(f"\n{comment}\n")
    click.echo(rendered)


def _install_shared_exit_handler(
    *uvicorn_servers,
    grpc_server,
) -> None:
    """Install one exit handler that coordinates uvicorn and gRPC shutdown.

    Uvicorn installs per-server signal handlers; the last server's handler
    overwrites earlier ones.  This replaces handle_exit on every server with
    a shared callback that sets should_exit / force_exit on all of them and
    requests gRPC shutdown alongside the uvicorn servers.
    """
    import signal as _signal

    loop = asyncio.get_running_loop()
    shutdown_requested = False

    def _request_grpc_shutdown(force: bool) -> None:
        if loop.is_closed():
            return
        loop.create_task(stop_otlp_grpc_server(grpc_server, force=force))

    def _shared_exit(sig, frame):
        nonlocal shutdown_requested
        force = shutdown_requested and sig == _signal.SIGINT
        shutdown_requested = True

        for s in uvicorn_servers:
            if force:
                s.force_exit = True
            else:
                s.should_exit = True

        _request_grpc_shutdown(force)

    for s in uvicorn_servers:
        s.handle_exit = _shared_exit


async def _run_servers(
    host: str,
    port: int,
    otlp_http_port: int,
    otlp_grpc_port: int,
    *,
    mcp_port: int | None = None,
    log_level: str = "warning",
) -> None:
    """Start API, OTLP HTTP+gRPC receivers, and optional MCP (Streamable HTTP)."""
    import uvicorn

    from .api.app import create_app
    from .api.otlp_app import create_otlp_app
    from .streaming.ws_server import StreamingTraceManager

    shared_kwargs: dict = {
        "host": host,
        "log_level": log_level,
    }

    mgr = StreamingTraceManager()
    main_app = create_app(trace_manager=mgr, enable_streaming=True)
    otlp_app = create_otlp_app(trace_manager=mgr)

    main_server = uvicorn.Server(uvicorn.Config(main_app, port=port, **shared_kwargs))
    otlp_http_server = uvicorn.Server(uvicorn.Config(otlp_app, port=otlp_http_port, **shared_kwargs))
    uvicorn_servers: list = [main_server, otlp_http_server]

    if mcp_port is not None:
        from .mcp_server import create_server as create_mcp_server

        backend = (os.environ.get("AGENTEVALS_SERVER_URL") or f"http://127.0.0.1:{port}").rstrip("/")
        mcp_instance = create_mcp_server(
            server_url=backend,
            host=host,
            port=mcp_port,
        )
        mcp_app = mcp_instance.streamable_http_app()
        mcp_kwargs = {**shared_kwargs, "reload": False, "port": mcp_port}
        mcp_uvicorn = uvicorn.Server(uvicorn.Config(mcp_app, **mcp_kwargs))
        uvicorn_servers.append(mcp_uvicorn)

    otlp_grpc_server = create_otlp_grpc_server(host=host, port=otlp_grpc_port, manager=mgr)
    await otlp_grpc_server.start()

    _install_shared_exit_handler(
        *uvicorn_servers,
        grpc_server=otlp_grpc_server,
    )

    try:
        await asyncio.gather(*(s.serve() for s in uvicorn_servers))
    finally:
        # The shared exit handler only requests gRPC shutdown on SIGINT/SIGTERM.
        # We still await a final stop here so non-signal exits also clean up.
        await stop_otlp_grpc_server(otlp_grpc_server)


@main.command("serve")
@click.option(
    "--dev",
    is_flag=True,
    help="Enable dev mode with WebSocket support for live streaming.",
)
@click.option(
    "--host",
    default="0.0.0.0",
    help="Host to bind the server to.",
)
@click.option(
    "--port",
    "-p",
    default=8001,
    help="Port to bind the server to.",
)
@click.option(
    "--otlp-http-port",
    type=click.IntRange(min=1),
    default=4318,
    help="Port for OTLP HTTP receiver (default: 4318, standard OTLP HTTP port).",
)
@click.option(
    "--otlp-grpc-port",
    type=click.IntRange(min=1),
    default=4317,
    help="Port for OTLP gRPC receiver (default: 4317, standard OTLP gRPC port).",
)
@click.option(
    "--mcp-port",
    default=None,
    type=int,
    help="If set, expose the MCP interface over Streamable HTTP on this port (requires [live] extras).",
)
@click.option(
    "--eval-sets",
    type=click.Path(exists=True),
    default=None,
    help="Directory containing eval set JSON files to pre-load.",
)
@click.option(
    "--headless",
    is_flag=True,
    help="Run in headless mode (no browser launch).",
)
@click.option(
    "-v",
    "--verbose",
    count=True,
    help="Increase verbosity (-v for INFO, -vv for DEBUG).",
)
def serve(
    dev: bool,
    host: str,
    port: int,
    otlp_http_port: int,
    otlp_grpc_port: int,
    mcp_port: int | None,
    eval_sets: str | None,
    headless: bool,
    verbose: int,
) -> None:
    """Start the agentevals API server.

    Use --dev to enable live streaming mode for agent development.
    """
    from pathlib import Path

    level = logging.WARNING
    if verbose == 1:
        level = logging.INFO
    elif verbose >= 2:
        level = logging.DEBUG
    logging.basicConfig(
        level=level,
        format="%(levelname)s %(name)s: %(message)s",
    )

    if headless:
        os.environ["AGENTEVALS_HEADLESS"] = "1"

    static_dir = Path(__file__).parent / "_static"
    has_ui = static_dir.is_dir() and (static_dir / "index.html").exists()

    os.environ["AGENTEVALS_LIVE"] = "1"

    if mcp_port is not None:
        try:
            from . import mcp_server as _mcp_server_check  # noqa: F401
        except ImportError:
            click.echo('MCP HTTP requires the live extras: pip install "agentevals[live]"', err=True)
            raise SystemExit(1) from None

    if dev:
        click.echo("agentevals dev server starting...")
        click.echo(f"  OTLP HTTP: http://{host}:{otlp_http_port}  (OTEL_EXPORTER_OTLP_ENDPOINT default)")
        click.echo(f"  OTLP gRPC: {host}:{otlp_grpc_port}  (OTEL_EXPORTER_OTLP_PROTOCOL=grpc)")
        click.echo(f"  WebSocket: ws://{host}:{port}/ws/traces")
        click.echo(f"  API:       http://{host}:{port}/api")
        if mcp_port is not None:
            click.echo(f"  MCP:       http://{host}:{mcp_port}/mcp")
        click.echo("  Web UI:    http://localhost:5173")
        click.echo()

        if eval_sets:
            click.echo(f"  Eval sets: {eval_sets}")
            click.echo()

        click.echo("Waiting for agent connections...")
        click.echo()

        asyncio.run(
            _run_servers(
                host,
                port,
                otlp_http_port,
                otlp_grpc_port,
                mcp_port=mcp_port,
                log_level="info",
            )
        )
    elif has_ui and not headless:
        click.echo(f"agentevals: http://{host}:{port}")
        click.echo(f"  OTLP HTTP: http://{host}:{otlp_http_port}")
        click.echo(f"  OTLP gRPC: {host}:{otlp_grpc_port}")
        if mcp_port is not None:
            click.echo(f"  MCP (Streamable HTTP): http://{host}:{mcp_port}/mcp")
        click.echo()

        asyncio.run(_run_servers(host, port, otlp_http_port, otlp_grpc_port, mcp_port=mcp_port))
    else:
        click.echo(f"agentevals API:  http://{host}:{port}/api")
        click.echo(f"  OTLP HTTP: http://{host}:{otlp_http_port}")
        click.echo(f"  OTLP gRPC: {host}:{otlp_grpc_port}")
        if mcp_port is not None:
            click.echo(f"  MCP (Streamable HTTP): http://{host}:{mcp_port}/mcp")
        click.echo()

        asyncio.run(_run_servers(host, port, otlp_http_port, otlp_grpc_port, mcp_port=mcp_port))


# ---------------------------------------------------------------------------
# agentevals migrate ...
# ---------------------------------------------------------------------------


@main.group("migrate")
def migrate_group() -> None:
    """Manage the Postgres schema for AGENTEVALS_STORAGE_BACKEND=postgres."""


def _migrator_or_die() -> "object":
    from pydantic import ValidationError

    from .storage.config import StorageSettings
    from .storage.postgres.migrator import Migrator

    try:
        settings = StorageSettings.from_env()
    except ValidationError as exc:
        # Extract the first inner message so CLI users see "AGENTEVALS_..." rather
        # than the multi-line Pydantic dump.
        first = exc.errors()[0] if exc.errors() else {"msg": str(exc)}
        raise click.ClickException(first.get("msg", str(exc))) from exc
    except Exception as exc:
        raise click.ClickException(str(exc)) from exc
    if not settings.database_url:
        raise click.ClickException("AGENTEVALS_DATABASE_URL is required for migrations")
    return Migrator(
        dsn=settings.database_url,
        schema=settings.schema_name,
        lock_timeout_s=settings.migrate_lock_timeout_s,
    )


@migrate_group.command("up")
@click.option("--dry-run", is_flag=True, help="Print which migrations would apply without executing.")
def migrate_up(dry_run: bool) -> None:
    """Apply all pending migrations."""
    click.echo(
        "note: agentevals migrate is a preview feature. Schema may change incompatibly between minor releases.",
        err=True,
    )
    migrator = _migrator_or_die()
    try:
        applied = asyncio.run(migrator.up(dry_run=dry_run))
    except Exception as exc:
        raise click.ClickException(f"migration failed: {exc}") from exc
    if not applied:
        click.echo("Nothing to apply.")
    else:
        verb = "Would apply" if dry_run else "Applied"
        for v in applied:
            click.echo(f"{verb} {v:06d}")


@migrate_group.command("down")
@click.option("--steps", type=int, required=True, help="Number of migrations to roll back (>= 1).")
@click.confirmation_option(
    prompt="Rolling back migrations is destructive and may delete data. Continue?",
)
def migrate_down(steps: int) -> None:
    """Roll back the last N migrations. Prints SQL for each step before executing."""
    migrator = _migrator_or_die()
    try:
        rolled = asyncio.run(migrator.down(steps=steps))
    except Exception as exc:
        raise click.ClickException(f"rollback failed: {exc}") from exc
    if not rolled:
        click.echo("Nothing to roll back.")
    else:
        for version, name in rolled:
            click.echo(f"Rolled back {version:06d}_{name}")


@migrate_group.command("version")
def migrate_version() -> None:
    """Print the current schema version and the dirty flag."""
    migrator = _migrator_or_die()
    status = asyncio.run(migrator.status())
    if status.version is None:
        click.echo("schema not initialized (no migrations applied)")
    else:
        click.echo(f"version={status.version:06d} dirty={status.dirty}")


@migrate_group.command("force")
@click.argument("version", type=int)
def migrate_force(version: int) -> None:
    """Set the schema version and clear the dirty flag. Recovery only.

    Use after fixing a partially-applied migration manually. Does not run any
    SQL; only updates the schema_migrations row.
    """
    migrator = _migrator_or_die()
    asyncio.run(migrator.force(version))
    click.echo(f"forced version={version:06d} dirty=False")


@migrate_group.command("create")
@click.argument("name")
@click.option(
    "--output-dir",
    "-o",
    type=click.Path(file_okay=False),
    default=None,
    help="Where to write the new files (defaults to the in-tree migrations directory).",
)
def migrate_create(name: str, output_dir: str | None) -> None:
    """Generate an empty NNNNNN_<name>.up.sql + .down.sql pair."""
    import re as _re
    from pathlib import Path as _Path

    if not _re.match(r"^[a-z0-9_]+$", name):
        raise click.ClickException("name must match [a-z0-9_]+")

    from .storage.postgres.migrator import discover_migrations

    if output_dir is None:
        repo_path = _Path(__file__).resolve().parent / "storage" / "postgres" / "migrations"
        if not repo_path.is_dir():
            raise click.ClickException(
                f"migrations dir not found at {repo_path} (run 'create' from a checkout, not an installed wheel)"
            )
        target = repo_path
    else:
        target = _Path(output_dir)
        target.mkdir(parents=True, exist_ok=True)

    existing = discover_migrations()
    next_version = (max((m.version for m in existing), default=0) + 1) if existing else 1
    up_path = target / f"{next_version:06d}_{name}.up.sql"
    down_path = target / f"{next_version:06d}_{name}.down.sql"
    if up_path.exists() or down_path.exists():
        raise click.ClickException(f"{up_path.name} or {down_path.name} already exists")

    header = (
        f"-- Migration {next_version:06d}: {name}\n"
        "-- Once tagged in a release this file is immutable. Fix bugs by adding a NEW migration.\n\n"
    )
    up_path.write_text(header)
    down_path.write_text(header)
    click.echo(f"Created {up_path}")
    click.echo(f"Created {down_path}")


@main.command("mcp")
@click.option(
    "--server-url",
    default=None,
    help="agentevals server URL for session tools (default: http://localhost:8001 or AGENTEVALS_SERVER_URL).",
)
def mcp_command(server_url: str | None) -> None:
    """Start the MCP server on stdio for use with Claude Code and other MCP clients."""
    try:
        from .mcp_server import create_server
    except ImportError:
        click.echo('MCP requires the live extras: pip install "agentevals[live]"', err=True)
        sys.exit(1)

    create_server(server_url=server_url).run("stdio")


if __name__ == "__main__":
    main()
