"""jdcodec — thin Python wrapper that delegates to the JD Codec connector.

`pip install jdcodec` ships only this shim. All connector behaviour lives
in the npm package `jdcodec`, fetched and executed via `npx`. To pin a
specific version, set JDC_CONNECTOR_VERSION (e.g. `JDC_CONNECTOR_VERSION=1.5.0`);
otherwise npx resolves to latest."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys


def _resolve_npx() -> str:
    npx = shutil.which("npx")
    if npx:
        return npx
    sys.stderr.write(
        "jdcodec: Node.js (and `npx`) is required but was not found on PATH.\n"
        "        The Python `jdcodec` package is a thin wrapper around the\n"
        "        TypeScript connector, which runs on Node 22+. Install Node\n"
        "        from https://nodejs.org/ (or `brew install node` on macOS,\n"
        "        `apt install nodejs npm` on Debian/Ubuntu) and retry.\n"
    )
    sys.exit(127)


def main() -> int:
    npx = _resolve_npx()
    version = os.environ.get("JDC_CONNECTOR_VERSION", "").strip()
    pkg_spec = f"jdcodec@{version}" if version else "jdcodec"
    cmd = [npx, "--yes", pkg_spec, *sys.argv[1:]]
    try:
        return subprocess.run(cmd).returncode
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    sys.exit(main())
