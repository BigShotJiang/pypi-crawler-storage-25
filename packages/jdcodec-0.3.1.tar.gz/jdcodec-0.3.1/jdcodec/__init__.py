"""jdcodec — public Python distribution.

Thin wrapper around the JD Codec connector (npm package `jdcodec`). All
connector behaviour lives in the npm package; this Python package delegates
to it via `npx` so the same binary runs whether you install via pip or npm.
See `jdcodec.cli` for the entry point."""

__version__ = "0.3.0"
__all__ = []
