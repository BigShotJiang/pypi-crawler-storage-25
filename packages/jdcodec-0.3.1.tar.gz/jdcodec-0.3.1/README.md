# `jdcodec` — Python Distribution

```bash
pip install jdcodec
```

A privacy-first local proxy for browser-agent task pipelines. The Python distribution is a thin wrapper that delegates to the JD Codec connector — it gives you `pip install jdcodec` ergonomics with the connector running under the hood via Node.

## What it does

- Compresses browser-agent page snapshots so your agent's context window goes much further on long tasks.
- Scans every snapshot on your machine for PII (emails, phone numbers, credit cards, API keys, addresses, and more) and replaces them with category tokens before any bytes leave your network.
- Falls back to a local-only mode if the cloud service is unreachable — your agent never blocks on us.

## Requirements

- Python 3.8 or newer
- Node.js 22 or newer on your `PATH` (install from <https://nodejs.org/> or `brew install node` / `apt install nodejs npm`)
- An MCP-capable agent client (Claude Code, Cursor, or any client that speaks MCP stdio)
- A JD Codec API key — email `hello@jdcodec.com`

## Usage

```bash
pip install jdcodec
jdcodec --help          # general help
jdcodec start           # launches the local MCP proxy
jdcodec-audit           # environment audit / waitlist tool
```

The first invocation will fetch and cache the connector via `npx` — typically a few seconds, then instant on subsequent runs.

### Pinning a specific version

By default the wrapper resolves to the latest published connector. To pin:

```bash
JDC_CONNECTOR_VERSION=0.2.0 jdcodec start
```

## Wiring it into your agent

The Python wrapper exposes the same `jdcodec` command as the npm distribution. Point your MCP client config at `jdcodec` (not `npx @playwright/mcp`) and the connector takes over. Specific guides for Claude Code, Cursor, and generic MCP clients are available — email `hello@jdcodec.com` for access.

## Configuration

Set your API key either as an environment variable or in a config file:

```bash
export JDC_API_KEY='jdck_yourid.yoursecret'
```

Or:

```bash
mkdir -p ~/.jdcodec
cat > ~/.jdcodec/config.json <<EOF
{ "api_key": "jdck_yourid.yoursecret" }
EOF
chmod 600 ~/.jdcodec/config.json
```

The full env-var reference (`JDC_BYPASS`, `JDC_REGION`, `JDC_TRACE`, etc.) is documented in the npm package's README — `npm view jdcodec readme` or visit <https://www.npmjs.com/package/jdcodec>.

## Support

Email `hello@jdcodec.com` for alpha access, API keys, bug reports, or feature requests.
