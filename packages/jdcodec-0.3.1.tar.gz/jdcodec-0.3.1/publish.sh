#!/bin/bash

# JD Codec Python Publishing Script
# Ensures build/twine are available and handles the upload safely.

echo "🚀 Starting JD Codec Python Publish..."

# 1. Ensure build tools are present
echo "🔍 Checking for build tools..."
python3 -m pip install build twine --break-system-packages --quiet

# 2. Cleanup old build artifacts
echo "🧹 Cleaning dist/ folder..."
rm -rf dist/
rm -rf *.egg-info

# 3. Build the package
echo "📦 Building $(grep -E '^version' pyproject.toml | head -1)..."
python3 -m build

# 4. Upload to PyPI
echo "⬆️ Uploading to PyPI..."
echo "------------------------------------------------"
echo "Username: __token__"
echo "Password: (Paste your pypi- token)"
echo "------------------------------------------------"

python3 -m twine upload dist/*

echo "✅ Done! Visit https://pypi.org/project/jdcodec/ to verify."
