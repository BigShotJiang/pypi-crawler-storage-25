from typing import Any

from ._agently_compat import RuntimeEvent


def _create_observation_service_hooker(
    observation_service: Any,
    *,
    name: str = "ObservationChannelSinkHooker",
) -> type[Any]: ...


def _create_observation_upload_hooker(
    get_backend: Any,
    *,
    name: str = "ObservationBridgeHooker",
    should_upload: Any | None = None,
) -> type[Any]: ...


def _resolve_api_key(*, settings: Any, api_key: str | None) -> str | None: ...
def _resolve_event_center(target: Any) -> Any: ...
def _normalize_observation_path(path: str | None) -> str: ...
def _route_prefix_from_path(path: str | None) -> str: ...
def _resolve_observation_endpoint(
    endpoint: str | None,
    *,
    host: str | None = None,
    port: int | None = None,
    path: str | None = None,
) -> str: ...


class ObservationBridge:
    endpoint: str
    host: str
    port: int
    path: str
    app_id: str
    group_id: str | None
    environment: str
    timeout: float
    auto_watch: bool
    settings: Any

    def __init__(
        self,
        endpoint: str | None = None,
        *,
        host: str | None = None,
        port: int | None = None,
        path: str | None = None,
        api_key: str | None = None,
        app_id: str = "default",
        group_id: str | None = None,
        environment: str = "local",
        timeout: float = 5.0,
        auto_watch: bool = True,
        settings: Any | None = None,
    ) -> None: ...

    def reload(self) -> ObservationBridge: ...
    def watch(self, *targets: Any) -> ObservationBridge: ...
    def clear_watch(self) -> ObservationBridge: ...
    def register(self, event_center: Any) -> ObservationBridge: ...
    def unregister(self, event_center: Any) -> ObservationBridge: ...
    async def flush(self) -> ObservationBridge: ...
    @property
    def hooker(self) -> type[Any]: ...
    @property
    def api_key(self) -> str | None: ...
    def register_flow_definition(
        self,
        flow: Any,
        *,
        flow_name: str | None = None,
    ) -> ObservationBridge: ...
