from __future__ import annotations

import time

from agently_devtools._agently_compat import RuntimeEvent
from agently_devtools._event_aliases import matches_triggerflow_event_type


class RuntimeFlowRegistry:
    def __init__(self):
        self._definitions: dict[tuple[str, str | None, str], dict[str, object]] = {}

    def reset(self):
        self._definitions.clear()

    def _normalize_key(
        self,
        *,
        app_id: str | None,
        group_id: str | None,
        flow_name: str,
    ) -> tuple[str, str | None, str]:
        normalized_flow_name = flow_name.strip()
        if not normalized_flow_name:
            raise ValueError("Flow definition registration requires a non-empty `flow_name`.")
        normalized_app_id = (app_id or "default").strip() or "default"
        normalized_group_id = (group_id or "").strip() or None
        return normalized_app_id, normalized_group_id, normalized_flow_name

    def register(
        self,
        *,
        app_id: str | None,
        group_id: str | None,
        flow_name: str,
        definition: dict[str, object],
        mermaid: dict[str, str] | None = None,
    ) -> dict[str, object]:
        normalized_app_id, normalized_group_id, normalized_flow_name = self._normalize_key(
            app_id=app_id,
            group_id=group_id,
            flow_name=flow_name,
        )
        payload: dict[str, object] = {
            "app_id": normalized_app_id,
            "group_id": normalized_group_id,
            "flow_name": normalized_flow_name,
            "definition": definition,
            "registered_at": int(time.time() * 1000),
        }
        if mermaid:
            payload["mermaid"] = dict(mermaid)
        self._definitions[(normalized_app_id, normalized_group_id, normalized_flow_name)] = payload
        return payload

    def resolve(
        self,
        *,
        app_id: str | None,
        group_id: str | None,
        flow_name: str,
    ) -> dict[str, object] | None:
        normalized_app_id, normalized_group_id, normalized_flow_name = self._normalize_key(
            app_id=app_id,
            group_id=group_id,
            flow_name=flow_name,
        )
        for key in (
            (normalized_app_id, normalized_group_id, normalized_flow_name),
            (normalized_app_id, None, normalized_flow_name),
        ):
            payload = self._definitions.get(key)
            if payload is not None:
                return dict(payload)
        return None

    def capture_event(self, event: RuntimeEvent):
        if not matches_triggerflow_event_type(event.event_type, ["triggerflow.definition_declared"]):
            return
        payload = event.payload if isinstance(event.payload, dict) else None
        if payload is None:
            return
        flow_name = payload.get("flow_name")
        definition = payload.get("definition")
        mermaid = payload.get("mermaid")
        if not isinstance(flow_name, str) or not flow_name:
            if event.run is not None:
                meta_flow_name = event.run.meta.get("flow_name")
                flow_name = meta_flow_name if isinstance(meta_flow_name, str) else None
        if not isinstance(flow_name, str) or not flow_name or not isinstance(definition, dict):
            return
        normalized_mermaid: dict[str, str] | None = None
        if isinstance(mermaid, dict):
            captured_mermaid = {
                key: value
                for key, value in mermaid.items()
                if isinstance(key, str) and isinstance(value, str) and value.strip()
            }
            normalized_mermaid = captured_mermaid or None
        app_id = event.meta.get("app_id")
        group_id = event.meta.get("group_id")
        if event.run is not None:
            app_id = app_id or event.run.meta.get("app_id")
            group_id = group_id or event.run.meta.get("group_id")
        try:
            self.register(
                app_id=app_id if isinstance(app_id, str) else None,
                group_id=group_id if isinstance(group_id, str) else None,
                flow_name=flow_name,
                definition=definition,
                mermaid=normalized_mermaid,
            )
        except ValueError:
            return