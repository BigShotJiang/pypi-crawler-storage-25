import asyncio
import re
import uuid
from dataclasses import dataclass, field

from agently_devtools._agently_compat import RuntimeEvent
from agently_devtools._event_aliases import matches_triggerflow_event_type

from .Query import ObservationSubscriptionFilter


@dataclass
class _Subscriber:
    queue: asyncio.Queue[RuntimeEvent] = field(default_factory=asyncio.Queue)
    filter: ObservationSubscriptionFilter = field(default_factory=ObservationSubscriptionFilter)


class RuntimeObservationSubscription:
    def __init__(self, manager: "RuntimeObservationSubscriptions", subscription_id: str, queue: asyncio.Queue[RuntimeEvent]):
        self._manager = manager
        self.id = subscription_id
        self.queue = queue

    async def get(self, *, timeout: float | None = None) -> RuntimeEvent:
        if timeout is None:
            return await self.queue.get()
        return await asyncio.wait_for(self.queue.get(), timeout=timeout)

    async def iter_events(self):
        while True:
            yield await self.get()

    def close(self):
        self._manager.unsubscribe(self.id)


class RuntimeObservationSubscriptions:
    def __init__(self):
        self._subscribers: dict[str, _Subscriber] = {}

    def reset(self):
        self._subscribers.clear()

    def _matches_subscriber(self, event: RuntimeEvent, subscriber: _Subscriber):
        filter_spec = subscriber.filter
        if not matches_triggerflow_event_type(event.event_type, filter_spec.event_types):
            return False
        if filter_spec.source is not None and event.source != filter_spec.source:
            return False
        if filter_spec.level is not None and event.level != filter_spec.level:
            return False
        if filter_spec.app_id is not None and event.meta.get("app_id") != filter_spec.app_id:
            return False
        if filter_spec.app_id_pattern is not None:
            app_id = event.meta.get("app_id")
            if not isinstance(app_id, str):
                return False
            try:
                if re.search(filter_spec.app_id_pattern, app_id) is None:
                    return False
            except re.error:
                return False
        if filter_spec.run_id is not None:
            if event.run is None:
                return False
            if filter_spec.include_descendants:
                if event.run.run_id != filter_spec.run_id and event.run.root_run_id != filter_spec.run_id:
                    return False
            elif event.run.run_id != filter_spec.run_id:
                return False
        return True

    def publish(self, event: RuntimeEvent):
        for subscriber in self._subscribers.values():
            if not self._matches_subscriber(event, subscriber):
                continue
            if subscriber.queue.full():
                try:
                    subscriber.queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
            try:
                subscriber.queue.put_nowait(event.model_copy(deep=True))
            except asyncio.QueueFull:
                continue

    def subscribe(
        self,
        *,
        filter: ObservationSubscriptionFilter | None = None,
        event_types: str | list[str] | None = None,
        run_id: str | None = None,
        include_descendants: bool = True,
        source: str | None = None,
        level: str | None = None,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        maxsize: int = 100,
    ):
        subscription_id = uuid.uuid4().hex
        filter_spec = filter
        if filter_spec is None:
            normalized_event_types = None
            if event_types is not None:
                normalized_event_types = [event_types] if isinstance(event_types, str) else list(event_types)
            filter_spec = ObservationSubscriptionFilter(
                event_types=normalized_event_types,
                run_id=run_id,
                include_descendants=include_descendants,
                source=source,
                level=level,
                app_id=app_id,
                app_id_pattern=app_id_pattern,
            )
        queue: asyncio.Queue[RuntimeEvent] = asyncio.Queue(maxsize=maxsize)
        self._subscribers[subscription_id] = _Subscriber(
            queue=queue,
            filter=filter_spec,
        )
        return RuntimeObservationSubscription(self, subscription_id, queue)

    def unsubscribe(self, subscription_or_id: RuntimeObservationSubscription | str):
        subscription_id = subscription_or_id if isinstance(subscription_or_id, str) else subscription_or_id.id
        self._subscribers.pop(subscription_id, None)