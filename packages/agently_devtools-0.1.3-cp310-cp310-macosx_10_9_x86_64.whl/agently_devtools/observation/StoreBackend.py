# Copyright 2023-2026 AgentEra(Agently.Tech)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

from agently_devtools._agently_compat import RuntimeEvent
from agently_devtools.rust_core import build_rust_observation_store

from .RunStore import RunRecord, RunStatus, RuntimeRunStore

if TYPE_CHECKING:
    from agently.utils import Settings


@runtime_checkable
class ObservationStoreBackend(Protocol):
    backend_name: str

    def reset(self) -> None: ...

    def append_event(self, event: RuntimeEvent) -> None: ...

    def list_runs(
        self,
        *,
        run_id: str | None = None,
        root_run_id: str | None = None,
        parent_run_id: str | None = None,
        run_kind: str | None = None,
        status: RunStatus | None = None,
        agent_id: str | None = None,
        session_id: str | None = None,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        group_id: str | None = None,
        flow_name: str | None = None,
        search: str | None = None,
        since: int | None = None,
        until: int | None = None,
        limit: int | None = None,
    ) -> list[RunRecord]: ...

    def get_run(self, run_id: str) -> RunRecord | None: ...

    def get_run_children(self, run_id: str) -> list[RunRecord]: ...

    def collect_descendant_run_ids(self, run_id: str) -> list[str]: ...

    def get_run_events(
        self,
        run_id: str,
        *,
        limit: int | None = None,
        include_descendants: bool = False,
    ) -> list[RuntimeEvent]: ...

    def get_recent_events(self, *, limit: int | None = None) -> list[RuntimeEvent]: ...


class PythonObservationStoreAdapter:
    backend_name = "python"

    def __init__(self, *, max_events: int):
        self._store = RuntimeRunStore(max_events=max_events)

    def reset(self):
        self._store.reset()

    def append_event(self, event: RuntimeEvent):
        self._store.append_event(event)

    def list_runs(self, **kwargs):
        return self._store.list_runs(**kwargs)

    def get_run(self, run_id: str):
        return self._store.get_run(run_id)

    def get_run_children(self, run_id: str):
        return self._store.get_run_children(run_id)

    def collect_descendant_run_ids(self, run_id: str):
        return self._store._collect_descendant_run_ids(run_id)

    def get_run_events(
        self,
        run_id: str,
        *,
        limit: int | None = None,
        include_descendants: bool = False,
    ):
        return self._store.get_run_events(
            run_id,
            limit=limit,
            include_descendants=include_descendants,
        )

    def get_recent_events(self, *, limit: int | None = None):
        return self._store.get_recent_events(limit=limit)


def create_observation_store(*, settings: "Settings", max_events: int) -> ObservationStoreBackend:
    configured_backend = str(settings.get("observation.store.backend", "python") or "python").strip().lower()
    if configured_backend == "rust":
        rust_store = build_rust_observation_store(max_events=max_events)
        if rust_store is not None:
            return rust_store
    return PythonObservationStoreAdapter(max_events=max_events)
