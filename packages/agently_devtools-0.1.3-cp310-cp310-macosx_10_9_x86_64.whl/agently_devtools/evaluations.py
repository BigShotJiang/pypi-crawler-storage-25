from __future__ import annotations

import asyncio
import inspect
import uuid
from collections.abc import Awaitable, Callable, Sequence
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from threading import Lock
from typing import TYPE_CHECKING, Any, cast

from agently import Agently

from .app import DEFAULT_LOCAL_API_KEY, DEFAULT_ROUTE_PREFIX, build_local_base_url, ensure_local_devtools_listener
from .bridge import _resolve_api_key, _resolve_event_center
from .observation.backends import RemoteObservationBackend

if TYPE_CHECKING:
    from agently.core import EventCenter
    from agently.types.plugins import EventHooker
    from agently.utils import Settings

    from ._agently_compat import RuntimeEvent


_CURRENT_EVALUATION_CONTEXT: ContextVar["EvaluationRuntimeContext | None"] = ContextVar(
    "agently_devtools_evaluation_context",
    default=None,
)

EvaluationExecutor = Callable[["EvaluationCase"], Any | Awaitable[Any]]
EvaluationRuleEvaluator = Callable[["EvaluationRoundRecord"], Any]
EvaluationTargetConfigurator = Callable[[Any], Any]
EvaluationCaseConfigurator = Callable[["EvaluationCase"], "EvaluationCase"]
EvaluationTargetFactory = Callable[[], Any]


def _serialize_check_result(check: "EvaluationCheckResult"):
    return {
        "name": check.name,
        "passed": check.passed,
        "detail": check.detail,
        "meta": dict(check.meta),
    }


@dataclass(slots=True)
class EvaluationCase:
    case_id: str
    input: Any
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class EvaluationCheckResult:
    name: str
    passed: bool
    detail: str | None = None
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class EvaluationRule:
    name: str
    evaluator: EvaluationRuleEvaluator

    def evaluate(self, record: "EvaluationRoundRecord"):
        raw = self.evaluator(record)
        if isinstance(raw, EvaluationCheckResult):
            return raw
        if isinstance(raw, dict):
            return EvaluationCheckResult(
                name=str(raw.get("name", self.name)),
                passed=bool(raw.get("passed", False)),
                detail=raw.get("detail"),
                meta=dict(raw.get("meta", {})),
            )
        return EvaluationCheckResult(name=self.name, passed=bool(raw))


@dataclass(slots=True)
class EvaluationVariant:
    variant_id: str
    label: str | None = None
    kind: str = "mixed"
    meta: dict[str, Any] = field(default_factory=dict)
    executor: EvaluationExecutor | None = None
    prepare_executor: Callable[[Any], EvaluationExecutor] | None = None
    configure_target: EvaluationTargetConfigurator | None = None
    configure_case: EvaluationCaseConfigurator | None = None

    @property
    def display_label(self):
        return self.label or self.variant_id

    @classmethod
    def from_settings(
        cls,
        variant_id: str,
        *,
        settings: dict[str, Any],
        label: str | None = None,
        meta: dict[str, Any] | None = None,
    ):
        def configure_target(target: Any):
            setter = getattr(target, "set_settings", None)
            if not callable(setter):
                raise TypeError("Settings variants require a target with `.set_settings(...)`.")
            for key, value in settings.items():
                setter(key, value)
            return target

        return cls(
            variant_id=variant_id,
            label=label,
            kind="settings",
            meta=dict(meta or {}),
            configure_target=configure_target,
        )

    @classmethod
    def from_yaml_prompt(
        cls,
        variant_id: str,
        prompt: str,
        *,
        label: str | None = None,
        mappings: dict[str, Any] | None = None,
        prompt_key_path: str | None = None,
        meta: dict[str, Any] | None = None,
    ):
        def configure_target(target: Any):
            loader = getattr(target, "load_yaml_prompt", None)
            if not callable(loader):
                raise TypeError("YAML prompt variants require a target with `.load_yaml_prompt(...)`.")
            loader(prompt, mappings=mappings, prompt_key_path=prompt_key_path)
            return target

        variant_meta = dict(meta or {})
        variant_meta.setdefault("prompt_format", "yaml")
        return cls(
            variant_id=variant_id,
            label=label,
            kind="prompt",
            meta=variant_meta,
            configure_target=configure_target,
        )

    @classmethod
    def from_json_prompt(
        cls,
        variant_id: str,
        prompt: str,
        *,
        label: str | None = None,
        mappings: dict[str, Any] | None = None,
        prompt_key_path: str | None = None,
        meta: dict[str, Any] | None = None,
    ):
        def configure_target(target: Any):
            loader = getattr(target, "load_json_prompt", None)
            if not callable(loader):
                raise TypeError("JSON prompt variants require a target with `.load_json_prompt(...)`.")
            loader(prompt, mappings=mappings, prompt_key_path=prompt_key_path)
            return target

        variant_meta = dict(meta or {})
        variant_meta.setdefault("prompt_format", "json")
        return cls(
            variant_id=variant_id,
            label=label,
            kind="prompt",
            meta=variant_meta,
            configure_target=configure_target,
        )

    @classmethod
    def from_json_flow(
        cls,
        variant_id: str,
        flow_config: str,
        *,
        label: str | None = None,
        replace: bool = True,
        meta: dict[str, Any] | None = None,
    ):
        def configure_target(target: Any):
            loader = getattr(target, "load_json_flow", None)
            if not callable(loader):
                raise TypeError("JSON flow variants require a target with `.load_json_flow(...)`.")
            loader(flow_config, replace=replace)
            return target

        variant_meta = dict(meta or {})
        variant_meta.setdefault("flow_format", "json")
        return cls(
            variant_id=variant_id,
            label=label,
            kind="flow",
            meta=variant_meta,
            configure_target=configure_target,
        )

    @classmethod
    def from_yaml_flow(
        cls,
        variant_id: str,
        flow_config: str,
        *,
        label: str | None = None,
        replace: bool = True,
        meta: dict[str, Any] | None = None,
    ):
        def configure_target(target: Any):
            loader = getattr(target, "load_yaml_flow", None)
            if not callable(loader):
                raise TypeError("YAML flow variants require a target with `.load_yaml_flow(...)`.")
            loader(flow_config, replace=replace)
            return target

        variant_meta = dict(meta or {})
        variant_meta.setdefault("flow_format", "yaml")
        return cls(
            variant_id=variant_id,
            label=label,
            kind="flow",
            meta=variant_meta,
            configure_target=configure_target,
        )


@dataclass(slots=True)
class EvaluationRuntimeContext:
    execution_key: str
    suite_id: str
    case_id: str
    round_index: int
    target_type: str
    target_name: str
    app_id: str
    group_id: str | None
    variant_id: str | None = None
    variant_label: str | None = None
    variant_kind: str | None = None
    variant_meta: dict[str, Any] = field(default_factory=dict)

    def as_meta(self):
        meta = {
            "evaluation": {
                "suite_id": self.suite_id,
                "case_id": self.case_id,
                "round_index": self.round_index,
                "target_type": self.target_type,
                "target_name": self.target_name,
            },
            "suite_id": self.suite_id,
            "case_id": self.case_id,
            "round_index": self.round_index,
            "target_type": self.target_type,
            "target_name": self.target_name,
        }
        if self.variant_id is not None:
            meta["evaluation"]["variant_id"] = self.variant_id
            meta["variant_id"] = self.variant_id
        if self.variant_label is not None:
            meta["evaluation"]["variant_label"] = self.variant_label
            meta["variant_label"] = self.variant_label
        if self.variant_kind is not None:
            meta["evaluation"]["variant_kind"] = self.variant_kind
            meta["variant_kind"] = self.variant_kind
        if self.variant_meta:
            meta["evaluation"]["variant_meta"] = dict(self.variant_meta)
            meta["variant_meta"] = dict(self.variant_meta)
        return meta


@dataclass(slots=True)
class EvaluationRoundRecord:
    suite_id: str
    case_id: str
    round_index: int
    target_type: str
    target_name: str
    variant_id: str | None
    variant_label: str | None
    variant_kind: str | None
    input: Any
    output: Any = None
    error: str | None = None
    observed_run_ids: list[str] = field(default_factory=list)
    checks: list[EvaluationCheckResult] = field(default_factory=list)
    passed: bool = False
    meta: dict[str, Any] = field(default_factory=dict)
    variant_meta: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class EvaluationReport:
    suite_id: str
    target_type: str
    target_name: str
    rounds: list[EvaluationRoundRecord]

    @property
    def total_rounds(self):
        return len(self.rounds)

    @property
    def passed_rounds(self):
        return sum(1 for item in self.rounds if item.passed)

    @property
    def failed_rounds(self):
        return self.total_rounds - self.passed_rounds


@dataclass(slots=True)
class EvaluationBinding:
    bridge: "EvaluationBridge"
    suite_id: str
    target_type: str
    target_name: str
    executor: EvaluationExecutor
    target: Any | None = None
    target_factory: EvaluationTargetFactory | None = None
    target_executor_factory: Callable[[Any], EvaluationExecutor] | None = None

    def resolve_executor(self, variant: EvaluationVariant | None = None):
        if variant is None:
            return self.executor
        if variant.prepare_executor is not None:
            return variant.prepare_executor(self)
        if variant.executor is not None:
            return variant.executor
        if self.target_factory is not None and self.target_executor_factory is not None:
            target_factory = self.target_factory
            target_executor_factory = self.target_executor_factory

            def execute(case: EvaluationCase):
                target = target_factory()
                if variant.configure_target is not None:
                    target = variant.configure_target(target)
                return target_executor_factory(target)(case)

            return execute
        if variant.configure_target is not None and self.target is not None and self.target_executor_factory is not None:
            configured_target = variant.configure_target(self.target)
            return self.target_executor_factory(configured_target)
        return self.executor

    def resolve_case(self, case: EvaluationCase, variant: EvaluationVariant | None = None):
        if variant is None or variant.configure_case is None:
            return case
        configured_case = variant.configure_case(case)
        if not isinstance(configured_case, EvaluationCase):
            raise TypeError("`EvaluationVariant.configure_case` must return `EvaluationCase`.")
        return configured_case


class EvaluationBridge:
    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        app_id: str = "default",
        group_id: str | None = None,
        environment: str = "local",
        timeout: float = 5.0,
        observe: bool | str = "auto",
        ensure_listener: bool | str = "auto",
        route_prefix: str = DEFAULT_ROUTE_PREFIX,
        settings: "Settings | None" = None,
    ):
        self.settings = settings if settings is not None else Agently.settings
        self.base_url = (base_url or build_local_base_url()).rstrip("/")
        self.route_prefix = route_prefix
        self.endpoint = f"{self.base_url}{self.route_prefix}/ingest"
        self.app_id = app_id or "default"
        self.group_id = group_id
        self.environment = environment
        self.timeout = timeout
        self.observe = observe
        self.ensure_listener = ensure_listener
        self._api_key_override = api_key
        self._observed_run_ids: dict[str, list[str]] = {}
        self._observed_lock = Lock()
        self._backend = self._create_backend()
        self._hooker = self._create_evaluation_upload_hooker()
        self._registered_event_center: "EventCenter | None" = None
        self._maybe_prepare_listener()

    def _maybe_prepare_listener(self):
        if self.ensure_listener not in {True, "auto"}:
            return
        if self.ensure_listener == "auto" or self.observe in {True, "auto"}:
            ensure_local_devtools_listener(
                self.base_url,
                api_key=self.api_key,
                route_prefix=self.route_prefix,
            )

    def _create_backend(self):
        return RemoteObservationBackend(
            endpoint=self.endpoint,
            api_key=self.api_key,
            app_id=self.app_id,
            group_id=self.group_id,
            environment=self.environment,
            timeout=self.timeout,
        )

    def _remember_run_id(self, execution_key: str, run_id: str):
        with self._observed_lock:
            observed = self._observed_run_ids.setdefault(execution_key, [])
            if run_id not in observed:
                observed.append(run_id)

    def consume_observed_run_ids(self, execution_key: str):
        with self._observed_lock:
            return self._observed_run_ids.pop(execution_key, [])

    def _create_evaluation_upload_hooker(self):
        bridge = self

        class EvaluationBridgeHooker:
            DEFAULT_SETTINGS: dict[str, Any] = {}
            event_types: list[str] | None = None
            name = "EvaluationBridgeHooker"

            @staticmethod
            def _on_register():
                pass

            @staticmethod
            def _on_unregister():
                pass

            @staticmethod
            async def handler(event: "RuntimeEvent"):
                runtime_context = _CURRENT_EVALUATION_CONTEXT.get()
                normalized_event = event
                if runtime_context is not None:
                    merged_meta = dict(event.meta)
                    merged_meta.update(runtime_context.as_meta())
                    merged_meta.setdefault("app_id", bridge.app_id)
                    if bridge.group_id is not None:
                        merged_meta.setdefault("group_id", bridge.group_id)
                    normalized_event = event.model_copy(update={"meta": merged_meta})
                    if normalized_event.run is not None:
                        root_run_id = normalized_event.run.root_run_id or normalized_event.run.run_id
                        bridge._remember_run_id(runtime_context.execution_key, root_run_id)

                if bridge.observe in {True, "auto"}:
                    await bridge._backend.append_event(normalized_event)

        return cast("type[EventHooker]", EvaluationBridgeHooker)

    def register(self, event_center: "EventCenter | Any"):
        resolved_event_center = _resolve_event_center(event_center)
        resolved_event_center.register_hooker_plugin(self._hooker)
        self._registered_event_center = resolved_event_center
        return self

    def unregister(self, event_center: "EventCenter | Any | None" = None):
        active_event_center = (
            _resolve_event_center(event_center)
            if event_center is not None
            else self._registered_event_center
        )
        if active_event_center is not None:
            active_event_center.unregister_hooker_plugin(self._hooker)
        if active_event_center is self._registered_event_center:
            self._registered_event_center = None
        return self

    @property
    def hooker(self) -> type["EventHooker"]:
        return self._hooker

    @property
    def api_key(self):
        return _resolve_api_key(settings=self.settings, api_key=self._api_key_override)

    @contextmanager
    def runtime_context(
        self,
        *,
        suite_id: str,
        case_id: str,
        round_index: int,
        target_type: str,
        target_name: str,
        variant: EvaluationVariant | None = None,
    ):
        runtime_context = EvaluationRuntimeContext(
            execution_key=str(uuid.uuid4()),
            suite_id=suite_id,
            case_id=case_id,
            round_index=round_index,
            target_type=target_type,
            target_name=target_name,
            app_id=self.app_id,
            group_id=self.group_id,
            variant_id=variant.variant_id if variant is not None else None,
            variant_label=variant.display_label if variant is not None else None,
            variant_kind=variant.kind if variant is not None else None,
            variant_meta=dict(variant.meta) if variant is not None else {},
        )
        token = _CURRENT_EVALUATION_CONTEXT.set(runtime_context)
        try:
            yield runtime_context
        finally:
            _CURRENT_EVALUATION_CONTEXT.reset(token)

    def bind_callable(
        self,
        executor: EvaluationExecutor,
        *,
        suite_id: str,
        target_type: str,
        target_name: str,
    ):
        return EvaluationBinding(
            bridge=self,
            suite_id=suite_id,
            target_type=target_type,
            target_name=target_name,
            executor=executor,
        )

    def bind_agent(self, agent: Any, *, suite_id: str, target_name: str = "agent"):
        def build_executor(active_agent: Any):
            def execute(case: EvaluationCase):
                request = active_agent.input(case.input)
                return request.start()

            return execute

        return EvaluationBinding(
            bridge=self,
            suite_id=suite_id,
            target_type="agent",
            target_name=target_name,
            executor=build_executor(agent),
            target=agent,
            target_executor_factory=build_executor,
        )

    def bind_agent_factory(
        self,
        factory: EvaluationTargetFactory,
        *,
        suite_id: str,
        target_name: str = "agent",
    ):
        def build_executor(active_agent: Any):
            def execute(case: EvaluationCase):
                request = active_agent.input(case.input)
                return request.start()

            return execute

        return EvaluationBinding(
            bridge=self,
            suite_id=suite_id,
            target_type="agent",
            target_name=target_name,
            executor=build_executor(factory()),
            target_factory=factory,
            target_executor_factory=build_executor,
        )

    def bind_request(self, request: Any, *, suite_id: str, target_name: str = "request"):
        def build_executor(active_request: Any):
            def execute(case: EvaluationCase):
                target = active_request.input(case.input) if hasattr(active_request, "input") else active_request
                return target.start()

            return execute

        return EvaluationBinding(
            bridge=self,
            suite_id=suite_id,
            target_type="request",
            target_name=target_name,
            executor=build_executor(request),
            target=request,
            target_executor_factory=build_executor,
        )

    def bind_request_factory(
        self,
        factory: EvaluationTargetFactory,
        *,
        suite_id: str,
        target_name: str = "request",
    ):
        def build_executor(active_request: Any):
            def execute(case: EvaluationCase):
                target = active_request.input(case.input) if hasattr(active_request, "input") else active_request
                return target.start()

            return execute

        return EvaluationBinding(
            bridge=self,
            suite_id=suite_id,
            target_type="request",
            target_name=target_name,
            executor=build_executor(factory()),
            target_factory=factory,
            target_executor_factory=build_executor,
        )

    def bind_triggerflow(self, flow: Any, *, suite_id: str, target_name: str = "triggerflow"):
        def build_executor(active_flow: Any):
            def execute(case: EvaluationCase):
                return active_flow.start(case.input)

            return execute

        return EvaluationBinding(
            bridge=self,
            suite_id=suite_id,
            target_type="triggerflow",
            target_name=target_name,
            executor=build_executor(flow),
            target=flow,
            target_executor_factory=build_executor,
        )

    def bind_triggerflow_factory(
        self,
        factory: EvaluationTargetFactory,
        *,
        suite_id: str,
        target_name: str = "triggerflow",
    ):
        def build_executor(active_flow: Any):
            def execute(case: EvaluationCase):
                return active_flow.start(case.input)

            return execute

        return EvaluationBinding(
            bridge=self,
            suite_id=suite_id,
            target_type="triggerflow",
            target_name=target_name,
            executor=build_executor(factory()),
            target_factory=factory,
            target_executor_factory=build_executor,
        )


class EvaluationRunner:
    def __init__(
        self,
        *,
        bridge: EvaluationBridge | None = None,
        base_url: str | None = None,
        api_key: str | None = DEFAULT_LOCAL_API_KEY,
        app_id: str = "default",
        group_id: str | None = None,
        environment: str = "local",
        observe: bool | str = "auto",
        ensure_listener: bool | str = "auto",
        settings: "Settings | None" = None,
    ):
        self.bridge = bridge or EvaluationBridge(
            base_url=base_url,
            api_key=api_key,
            app_id=app_id,
            group_id=group_id,
            environment=environment,
            observe=observe,
            ensure_listener=ensure_listener,
            settings=settings,
        )

    async def _emit_round_result(
        self,
        event_center: "EventCenter",
        record: EvaluationRoundRecord,
    ):
        emitter = cast(Any, event_center).create_emitter("EvaluationRunner")
        await emitter.async_emit(
            "evaluation.round.result",
            level="INFO",
            message=(
                f"{record.suite_id}:{record.variant_id or 'default'}:{record.case_id}:"
                f"round {record.round_index} {'passed' if record.passed else 'failed'}"
            ),
            payload={
                "suite_id": record.suite_id,
                "case_id": record.case_id,
                "round_index": record.round_index,
                "target_type": record.target_type,
                "target_name": record.target_name,
                "variant_id": record.variant_id,
                "variant_label": record.variant_label,
                "variant_kind": record.variant_kind,
                "variant_meta": dict(record.variant_meta),
                "passed": record.passed,
                "error": record.error,
                "observed_run_ids": list(record.observed_run_ids),
                "checks": [_serialize_check_result(check) for check in record.checks],
            },
        )

    async def async_run(
        self,
        binding: EvaluationBinding,
        *,
        cases: Sequence[EvaluationCase],
        variants: Sequence[EvaluationVariant] | None = None,
        rules: Sequence[EvaluationRule | EvaluationRuleEvaluator] | None = None,
        rounds: int = 1,
        event_center: "EventCenter | None" = None,
    ):
        if rounds < 1:
            raise ValueError("`rounds` must be >= 1.")
        active_event_center = event_center or Agently.event_center
        self.bridge.register(active_event_center)
        normalized_rules = [
            rule if isinstance(rule, EvaluationRule) else EvaluationRule(name=f"rule_{index + 1}", evaluator=rule)
            for index, rule in enumerate(rules or [])
        ]
        normalized_variants = list(variants or [EvaluationVariant(variant_id="default", label="Default", kind="default")])
        round_records: list[EvaluationRoundRecord] = []

        try:
            for variant in normalized_variants:
                executor = binding.resolve_executor(variant)
                for case in cases:
                    active_case = binding.resolve_case(case, variant)
                    for round_index in range(1, rounds + 1):
                        async with _evaluation_execution_scope(
                            self.bridge,
                            suite_id=binding.suite_id,
                            case_id=active_case.case_id,
                            round_index=round_index,
                            target_type=binding.target_type,
                            target_name=binding.target_name,
                            variant=variant,
                        ) as runtime_context:
                            record = EvaluationRoundRecord(
                                suite_id=binding.suite_id,
                                case_id=active_case.case_id,
                                round_index=round_index,
                                target_type=binding.target_type,
                                target_name=binding.target_name,
                                variant_id=variant.variant_id,
                                variant_label=variant.display_label,
                                variant_kind=variant.kind,
                                input=active_case.input,
                                meta=dict(active_case.meta),
                                variant_meta=dict(variant.meta),
                            )
                            try:
                                outcome = executor(active_case)
                                if inspect.isawaitable(outcome):
                                    outcome = await outcome
                                record.output = outcome
                            except Exception as exc:
                                record.error = str(exc)
                            record.observed_run_ids = self.bridge.consume_observed_run_ids(runtime_context.execution_key)
                            record.checks = [rule.evaluate(record) for rule in normalized_rules]
                            record.passed = record.error is None and all(check.passed for check in record.checks)
                            await self._emit_round_result(active_event_center, record)
                            round_records.append(record)
        finally:
            self.bridge.unregister(active_event_center)

        return EvaluationReport(
            suite_id=binding.suite_id,
            target_type=binding.target_type,
            target_name=binding.target_name,
            rounds=round_records,
        )

    def run(
        self,
        binding: EvaluationBinding,
        *,
        cases: Sequence[EvaluationCase],
        variants: Sequence[EvaluationVariant] | None = None,
        rules: Sequence[EvaluationRule | EvaluationRuleEvaluator] | None = None,
        rounds: int = 1,
        event_center: "EventCenter | None" = None,
    ):
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(
                self.async_run(
                    binding,
                    cases=cases,
                    variants=variants,
                    rules=rules,
                    rounds=rounds,
                    event_center=event_center,
                )
            )
        raise RuntimeError("Use `await EvaluationRunner.async_run(...)` inside an active event loop.")


class _evaluation_execution_scope:
    def __init__(
        self,
        bridge: EvaluationBridge,
        *,
        suite_id: str,
        case_id: str,
        round_index: int,
        target_type: str,
        target_name: str,
        variant: EvaluationVariant | None = None,
    ):
        self.bridge = bridge
        self.kwargs = {
            "suite_id": suite_id,
            "case_id": case_id,
            "round_index": round_index,
            "target_type": target_type,
            "target_name": target_name,
            "variant": variant,
        }
        self._context = None
        self.runtime_context: EvaluationRuntimeContext | None = None

    async def __aenter__(self):
        self._context = self.bridge.runtime_context(**self.kwargs)
        self.runtime_context = self._context.__enter__()
        return self.runtime_context

    async def __aexit__(self, exc_type, exc, tb):
        assert self._context is not None
        self._context.__exit__(exc_type, exc, tb)
        return False


__all__ = [
    "EvaluationBinding",
    "EvaluationBridge",
    "EvaluationCase",
    "EvaluationCheckResult",
    "EvaluationReport",
    "EvaluationRoundRecord",
    "EvaluationRule",
    "EvaluationRunner",
    "EvaluationVariant",
]
