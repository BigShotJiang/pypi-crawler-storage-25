from typing import Annotated, Any

from fastapi import FastAPI, Header, HTTPException, Query


OptionalStrHeader = Annotated[str | None, Header()]
OptionalStrQuery = Annotated[str | None, Query()]
OptionalEventTypesQuery = Annotated[list[str] | None, Query()]
OptionalLevelsQuery = Annotated[list[str] | None, Query()]


def register_logs_routes(app: FastAPI, owner: Any):
    @app.get("/logs/stats")
    async def get_log_stats(
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        if owner.observation_service.log_service is None:
            raise HTTPException(status_code=503, detail="Log service is not enabled.")
        return owner._wrap_response(owner.observation_service.log_service.get_stats())

    @app.get("/logs/events")
    async def list_log_events(
        run_id: str | None = None,
        root_run_id: str | None = None,
        parent_run_id: str | None = None,
        run_kind: str | None = None,
        event_family: str | None = None,
        event_types: OptionalEventTypesQuery = None,
        event_type: str | None = None,
        source: str | None = None,
        levels: OptionalLevelsQuery = None,
        level: str | None = None,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        group_id: str | None = None,
        flow_name: str | None = None,
        search: str | None = None,
        since: int | None = None,
        until: int | None = None,
        limit: int | None = None,
        offset: int = 0,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        if owner.observation_service.log_service is None:
            raise HTTPException(status_code=503, detail="Log service is not enabled.")
        query = owner._build_log_query(
            run_id=run_id,
            root_run_id=root_run_id,
            parent_run_id=parent_run_id,
            run_kind=run_kind,
            event_family=event_family,
            event_types=event_types,
            event_type=event_type,
            source=source,
            levels=levels,
            level=level,
            app_id=app_id,
            app_id_pattern=app_id_pattern,
            group_id=group_id,
            flow_name=flow_name,
            search=search,
            since=since,
            until=until,
            limit=limit,
            offset=offset,
        )
        return owner._wrap_response(owner.observation_service.log_service.query_events(query))