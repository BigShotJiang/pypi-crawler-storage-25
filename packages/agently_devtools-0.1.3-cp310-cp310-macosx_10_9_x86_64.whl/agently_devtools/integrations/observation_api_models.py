# Copyright 2023-2026 AgentEra(Agently.Tech)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Any

from pydantic import BaseModel, Field

from agently_devtools._agently_compat import RuntimeEvent


class ObservationIngestRequest(BaseModel):
    app_id: str | None = None
    group_id: str | None = None
    environment: str | None = None
    events: list[RuntimeEvent] = Field(default_factory=list)


class LocalAuthUpdateRequest(BaseModel):
    enabled: bool = False
    api_key: str | None = None


class EvaluationCheckPayload(BaseModel):
    name: str
    passed: bool
    detail: str | None = None
    meta: dict[str, Any] = Field(default_factory=dict)


class EvaluationVariantSummaryPayload(BaseModel):
    variant_id: str
    variant_label: str | None = None
    variant_kind: str | None = None
    total_rounds: int
    passed_rounds: int
    failed_rounds: int
    case_count: int


class EvaluationRoundPayload(BaseModel):
    suite_id: str
    case_id: str
    round_index: int
    target_type: str
    target_name: str
    variant_id: str | None = None
    variant_label: str | None = None
    variant_kind: str | None = None
    variant_meta: dict[str, Any] = Field(default_factory=dict)
    passed: bool
    error: str | None = None
    checks: list[EvaluationCheckPayload] = Field(default_factory=list)
    observed_run_ids: list[str] = Field(default_factory=list)
    run_id: str | None = None
    root_run_id: str | None = None
    status: str | None = None
    started_at: int | None = None
    updated_at: int | None = None
    app_id: str | None = None
    group_id: str | None = None
    timestamp: int


class EvaluationSuiteSummaryPayload(BaseModel):
    suite_id: str
    target_type: str | None = None
    target_name: str | None = None
    app_id: str | None = None
    group_id: str | None = None
    total_rounds: int
    passed_rounds: int
    failed_rounds: int
    variant_count: int
    case_count: int
    updated_at: int | None = None
    latest_run_id: str | None = None
    variants: list[EvaluationVariantSummaryPayload] = Field(default_factory=list)


class EvaluationSuiteReportPayload(EvaluationSuiteSummaryPayload):
    rounds: list[EvaluationRoundPayload] = Field(default_factory=list)


class PlaygroundRequestRunRequest(BaseModel):
    app_id: str | None = None
    group_id: str | None = None
    surface_id: str | None = None
    request_name: str | None = None
    target_mode: str = "request"
    session_id: str | None = None
    flow_name: str | None = None
    flow_input: Any = None
    prompt_source: str = "slots"
    prompt_config: str | None = None
    prompt_mappings: dict[str, Any] = Field(default_factory=dict)
    prompt_key_path: str | None = None
    system: str | None = None
    developer: str | None = None
    instruct: str | None = None
    input: Any = None
    output: Any = None
    settings: dict[str, Any] = Field(default_factory=dict)


class PlaygroundRequestRunPayload(BaseModel):
    surface_id: str | None = None
    request_name: str
    target_mode: str = "request"
    app_id: str | None = None
    group_id: str | None = None
    session_id: str | None = None
    run_id: str | None = None
    root_run_id: str | None = None
    parent_run_id: str | None = None
    result: Any = None
    error: str | None = None
    prompt_text: str | None = None
    prompt: dict[str, Any] = Field(default_factory=dict)
    request_payload: dict[str, Any] = Field(default_factory=dict)
    model_meta: dict[str, Any] = Field(default_factory=dict)
    event_count: int = 0
    stream_text: str | None = None
    streaming_event_count: int = 0
    latest_event_type: str | None = None
    status: str | None = None
    started_at: int | None = None
    updated_at: int | None = None
    duration_ms: int | None = None


class FlowDefinitionRegistrationRequest(BaseModel):
    app_id: str | None = None
    group_id: str | None = None
    flow_name: str
    definition: dict[str, Any]
    mermaid: dict[str, str] | None = None


class FlowDefinitionPayload(FlowDefinitionRegistrationRequest):
    app_id: str | None = None
    registered_at: int


class FrameworkCompatibilityPayload(BaseModel):
    package_name: str
    installed_version: str | None = None
    required_specifier: str
    minimum_version: str
    compatible: bool
    level: str
    reason: str | None = None
    message: str
    upgrade_command: str