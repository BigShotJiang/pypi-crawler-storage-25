# Copyright 2023-2026 AgentEra(Agently.Tech)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Interactive wrapper for demo/testing UI.

The interactive object is itself a FastAPI app and starts a local server as soon
as the provider is wrapped.
"""
from __future__ import annotations

import asyncio
from contextlib import contextmanager
import html
import inspect
import json
import os
import threading
import time
import urllib.error
import urllib.request
import webbrowser
from pathlib import Path
from typing import Any, Callable, Protocol, TYPE_CHECKING, cast
import typing

from fastapi import HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse
from pydantic import BaseModel, Field

from agently.integrations.fastapi import FastAPIHelper
from agently.types.data import SerializableMapping
from agently.utils.FunctionShifter import FunctionShifter

if TYPE_CHECKING:
    from agently.core import BaseAgent, ModelRequest, TriggerFlow, TriggerFlowExecution


def _resolve_default_bridge_port() -> int:
    from agently_devtools.app import DEFAULT_BRIDGE_PORT

    return DEFAULT_BRIDGE_PORT


def _env_allows_auto_start(default: bool = True) -> bool:
    value = os.getenv("AGENTLY_INTERACTIVE_AUTOSTART")
    if value is None:
        return default
    return value.strip().lower() not in {"0", "false", "no", "off"}


def _resolve_web_dist_dir() -> Path | None:
    current_file = Path(__file__).resolve()
    candidates = [
        current_file.parents[4] / "apps" / "web" / "dist",
        current_file.parents[1] / "static",
    ]
    for candidate in candidates:
        if (
            candidate.exists()
            and candidate.is_dir()
            and (candidate / "index.html").exists()
        ):
            return candidate
    return None


def _inject_interactive_web_config(
    html_content: str,
    *,
    endpoint: str,
    metadata_path: str,
    chat_path: str,
    stream_path: str,
    studio_path: str,
    simple_path: str,
):
    config_script = (
        "<script>"
        f'window.__AGENTLY_DEVTOOLS_CONFIG__ = {json.dumps({"endpoint": endpoint, "surface": "interactive", "interactive": {"metadataPath": metadata_path, "chatPath": chat_path, "streamPath": stream_path, "studioPath": studio_path, "simplePath": simple_path}}, ensure_ascii=False)};'
        "</script>"
    )
    if "</head>" in html_content:
        return html_content.replace("</head>", f"{config_script}</head>", 1)
    return f"{config_script}{html_content}"


class InteractiveChatRequest(BaseModel):
    message: str | None = None
    input: Any = None
    session_id: str | None = Field(
        default=None, description="Session ID for multi-turn"
    )
    options: dict[str, Any] = Field(
        default_factory=dict, description="Provider options"
    )


class InteractiveChatResponse(BaseModel):
    status: int
    data: Any
    msg: str | None = None
    error: dict[str, Any] | None = None


class _SessionAwareAgent(Protocol):
    activated_session: Any | None

    def activate_session(self, *, session_id: str | None = None): ...

    def deactivate_session(self): ...

    def input(self, prompt: Any, mappings: dict[str, Any] | None = None, always: bool = False): ...

    async def async_start(self, **options: Any): ...

    def get_async_generator(self, **options: Any): ...


class InteractiveWrapper(FastAPIHelper):
    """
    DevTools-specialized interactive wrapper extending FastAPIHelper.

    The wrapper is also a FastAPI application. By default, wrapping a provider
    starts a local background server immediately, which makes direct script usage
    match Agently's integration style more closely.
    """

    def __init__(
        self,
        response_provider: "BaseAgent | ModelRequest | TriggerFlow | TriggerFlowExecution | Callable",
        *,
        response_warper: Callable | None = None,
        title: str | None = None,
        description: str | None = None,
        host: str = "127.0.0.1",
        port: int | None = None,
        ui_mode: str = "studio",
        ui_contract: dict[str, Any] | None = None,
        auto_start: bool | None = None,
        open_browser: bool = False,
        startup_timeout: float = 5.0,
        uvicorn_kwargs: dict[str, Any] | None = None,
    ):
        resolved_title = title or "Interactive Wrapper"
        resolved_description = description or ""
        super().__init__(
            response_provider=response_provider,
            response_warper=response_warper,
            title=resolved_title,
            description=resolved_description,
        )

        self.title = resolved_title
        self.description = resolved_description
        self.bind_host = host or "127.0.0.1"
        self.bind_port = _resolve_default_bridge_port() if port is None else port
        self.ui_mode = self._normalize_ui_mode(ui_mode)
        self.ui_contract = self._normalize_ui_contract(ui_contract)
        self.startup_timeout = startup_timeout
        self.open_browser = open_browser
        self._uvicorn_kwargs = (
            dict(uvicorn_kwargs) if uvicorn_kwargs is not None else {}
        )
        self._web_dist_dir = _resolve_web_dist_dir()
        self._server_thread: threading.Thread | None = None
        self._server_error: Exception | None = None
        self._server_lock = threading.Lock()
        self._last_opened_url: str | None = None

        self._configure_routes()

        self.auto_start = (
            _env_allows_auto_start(True) if auto_start is None else auto_start
        )
        if self.auto_start:
            self.ensure_started(open_browser=self.open_browser)

    @property
    def ui_url(self) -> str:
        return f"http://{self.bind_host}:{self.bind_port}/"

    @property
    def studio_ui_url(self) -> str:
        return f"http://{self.bind_host}:{self.bind_port}/studio"

    @property
    def simple_ui_url(self) -> str:
        return f"http://{self.bind_host}:{self.bind_port}/simple"

    @staticmethod
    def _normalize_ui_mode(value: str | None):
        normalized = (value or "studio").strip().lower()
        return "simple" if normalized == "simple" else "studio"

    @staticmethod
    def _normalize_contract_string(value: Any) -> str | None:
        if isinstance(value, str):
            trimmed = value.strip()
            if trimmed:
                return trimmed
        return None

    @staticmethod
    def _json_safe(value: Any):
        return json.loads(json.dumps(value, ensure_ascii=False, default=str))

    def _normalize_input_schema(self, input_schema: Any):
        if not isinstance(input_schema, dict):
            return None
        return self._json_safe(input_schema)

    def _schema_from_type(self, typ: Any) -> dict[str, Any] | None:
        try:
            from pydantic import BaseModel as PydanticBaseModel
        except Exception:
            PydanticBaseModel = None  # type: ignore

        # Handle Pydantic models
        try:
            if isinstance(typ, type) and PydanticBaseModel is not None and issubclass(typ, PydanticBaseModel):
                schema_method = getattr(typ, "model_json_schema", None)
                if callable(schema_method):
                    return self._json_safe(schema_method())
                return self._json_safe(typ.schema())
        except Exception:
            pass

        # If the type itself exposes a JSON-schema-like dict
        if isinstance(typ, dict):
            return self._normalize_input_schema(typ)

        origin = typing.get_origin(typ)
        args = typing.get_args(typ)

        # Lists / arrays
        if origin in (list, typing.List):
            item = args[0] if args else Any
            item_schema = self._schema_from_type(item) or {"type": "string"}
            return {"type": "array", "items": item_schema}

        # Dicts / objects
        if origin in (dict, typing.Dict):
            return {"type": "object", "additionalProperties": True}

        # Optional / Union
        if origin is typing.Union:
            arg_schemas = [self._schema_from_type(a) for a in args if a is not type(None)]
            arg_schemas = [s for s in arg_schemas if s is not None]
            if len(arg_schemas) == 1:
                return arg_schemas[0]
            if arg_schemas:
                return {"anyOf": arg_schemas}

        # Primitives
        if typ in (str,):
            return {"type": "string"}
        if typ in (int,):
            return {"type": "integer"}
        if typ in (float,):
            return {"type": "number"}
        if typ in (bool,):
            return {"type": "boolean"}

        # dataclass / TypedDict style annotations
        annotations = getattr(typ, "__annotations__", None)
        if isinstance(annotations, dict):
            props: dict[str, Any] = {}
            required: list[str] = []
            for name, ann in annotations.items():
                prop_schema = self._schema_from_type(ann) or {"type": "string"}
                props[name] = prop_schema
                required.append(name)
            return {"type": "object", "properties": props, "required": required}

        return None

    def _derive_input_schema_from_provider(self) -> dict[str, Any] | None:
        """Best-effort derivation of an input JSON Schema from the wrapped provider.

        Strategies (in order):
        - provider.ui_contract / provider.contract dicts with input_schema
        - provider.input_schema attribute
        - provider.input_model / input_type / initial_input_type (Pydantic/dataclass/typing)
        - callable provider: inspect first annotated parameter
        - fallback: None
        """
        try:
            provider = self.response_provider

            # 1) provider exposes ui_contract/contract with input_schema
            for attr in ("ui_contract", "contract", "spec"):
                candidate = getattr(provider, attr, None)
                if isinstance(candidate, dict):
                    schema = self._normalize_input_schema(candidate.get("input_schema"))
                    if schema:
                        return schema

            # 2) direct input_schema attribute
            direct = getattr(provider, "input_schema", None)
            schema = self._normalize_input_schema(direct)
            if schema:
                return schema

            # 3) candidate input model/type attributes
            for attr in ("input_model", "input_type", "initial_input_type"):
                typ = getattr(provider, attr, None)
                if typ is not None:
                    derived = self._schema_from_type(typ)
                    if derived is not None:
                        return self._json_safe(derived)

            # 4) if callable, inspect annotations
            if callable(provider):
                try:
                    sig = inspect.signature(provider)
                    for param in sig.parameters.values():
                        if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                            continue
                        ann = param.annotation
                        if ann is inspect._empty:
                            continue
                        derived = self._schema_from_type(ann)
                        if derived is not None:
                            return self._json_safe(derived)
                except Exception:
                    pass

        except Exception:
            pass
        return None

    def _normalize_ui_contract(self, ui_contract: dict[str, Any] | None):
        contract = dict(ui_contract or {})
        input_schema = self._normalize_input_schema(contract.get("input_schema"))
        # If no explicit schema provided, attempt best-effort derivation from the provider
        if input_schema is None:
            try:
                derived = self._derive_input_schema_from_provider()
                if isinstance(derived, dict):
                    input_schema = derived
            except Exception:
                input_schema = None

        input_mode = str(contract.get("input_mode") or "").strip().lower()
        if input_mode not in {"text", "json", "schema"}:
            input_mode = "schema" if input_schema is not None else "text"
        if input_mode == "schema" and input_schema is None:
            input_mode = "json"

        examples: list[dict[str, Any]] = []
        raw_examples = contract.get("examples")
        if isinstance(raw_examples, list):
            for index, item in enumerate(raw_examples):
                if isinstance(item, str):
                    trimmed = item.strip()
                    if not trimmed:
                        continue
                    examples.append(
                        {
                            "label": trimmed[:48],
                            "input": trimmed,
                            "description": None,
                        }
                    )
                    continue
                if isinstance(item, dict):
                    raw_input = item.get("input")
                    if raw_input is None:
                        raw_input = item.get("value", item.get("message", item.get("text")))
                    if raw_input is None:
                        continue
                    label = item.get("label")
                    if not isinstance(label, str) or not label.strip():
                        label = f"Example {index + 1}"
                    description = item.get("description")
                    examples.append(
                        {
                            "label": label.strip(),
                            "input": self._json_safe(raw_input),
                            "description": description if isinstance(description, str) else None,
                        }
                    )
                    continue
                examples.append(
                    {
                        "label": f"Example {index + 1}",
                        "input": self._json_safe(item),
                        "description": None,
                    }
                )

        welcome_message = contract.get("welcome_message")
        if not isinstance(welcome_message, str):
            welcome_message = self.description or "Send a request in the studio view, then keep the simple UI as an optional alternate surface."

        return {
            "input_mode": input_mode,
            "input_label": str(contract.get("input_label") or "Input"),
            "input_placeholder": str(contract.get("input_placeholder") or "Type your message or paste a JSON payload."),
            "submit_label": str(contract.get("submit_label") or "Send"),
            "session_label": str(contract.get("session_label") or "Session ID"),
            "options_label": str(contract.get("options_label") or "Options JSON"),
            "allow_session_id": bool(contract.get("allow_session_id", True)),
            "prompt_field": self._normalize_contract_string(contract.get("prompt_field")),
            "history_toggle_field": self._normalize_contract_string(contract.get("history_toggle_field")),
            "default_session_id": self._normalize_contract_string(contract.get("default_session_id")),
            "welcome_message": welcome_message,
            "input_schema": input_schema,
            "examples": examples,
        }

    def _render_studio_unavailable_ui(self) -> str:
        title = html.escape(self.title or "Interactive Wrapper")
        description = html.escape(self.description or "")
        studio_url = html.escape(self.studio_ui_url)
        simple_url = html.escape(self.simple_ui_url)
        return f"""
<!DOCTYPE html>
<html lang=\"en\">
<head>
  <meta charset=\"UTF-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
  <title>{title}</title>
  <style>
    body {{
      margin: 0;
      font-family: \"Avenir Next\", \"Segoe UI\", sans-serif;
      background: linear-gradient(160deg, #fcfaf5, #efebe3);
      color: #1c232b;
    }}
    .shell {{
      min-height: 100vh;
      display: grid;
      place-items: center;
      padding: 24px;
    }}
    .card {{
      max-width: 720px;
      border-radius: 24px;
      background: rgba(255,255,255,0.9);
      border: 1px solid rgba(28, 35, 43, 0.12);
      box-shadow: 0 24px 60px rgba(28, 35, 43, 0.08);
      padding: 28px;
    }}
    h1 {{
      margin: 0 0 10px;
      font-size: 36px;
      line-height: 0.95;
      letter-spacing: -0.05em;
      font-family: \"Iowan Old Style\", Georgia, serif;
    }}
    p {{
      color: #4d5b67;
      line-height: 1.6;
    }}
    .links {{
      display: flex;
      gap: 12px;
      flex-wrap: wrap;
      margin-top: 18px;
    }}
    a {{
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 10px 16px;
      border-radius: 999px;
      text-decoration: none;
      border: 1px solid rgba(28, 35, 43, 0.12);
      color: #1c232b;
      background: rgba(255,255,255,0.8);
    }}
  </style>
</head>
<body>
  <div class=\"shell\">
    <div class=\"card\">
      <h1>{title}</h1>
      <p>{description}</p>
      <p>The full Interactive Studio UI is the default view for this wrapper, but the bundled web assets are not available in the current environment.</p>
      <div class=\"links\">
        <a href=\"{studio_url}\">Retry Studio</a>
        <a href=\"{simple_url}\">Open Simple UI</a>
      </div>
    </div>
  </div>
</body>
</html>
"""

    def _render_studio_response(self, request: Request) -> HTMLResponse:
        if self._web_dist_dir is None:
            return HTMLResponse(self._render_studio_unavailable_ui())

        index_file = self._web_dist_dir / "index.html"
        if not index_file.exists() or not index_file.is_file():
            return HTMLResponse(self._render_studio_unavailable_ui())

        base_url = str(request.base_url).rstrip("/")
        index_html = index_file.read_text(encoding="utf-8")
        return HTMLResponse(
            _inject_interactive_web_config(
                index_html,
                endpoint=base_url,
                metadata_path="/api/metadata",
                chat_path="/api/chat",
                stream_path="/api/stream",
                studio_path="/studio",
                simple_path="/simple",
            )
        )

    def _resolve_asset_path(self, asset_path: str) -> Path | None:
        if self._web_dist_dir is None:
            return None
        assets_dir = (self._web_dist_dir / "assets").resolve()
        candidate = (assets_dir / asset_path).resolve()
        if not candidate.is_relative_to(assets_dir):
            return None
        if not candidate.exists() or not candidate.is_file():
            return None
        return candidate

    def _configure_routes(self) -> None:
        self.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        self.add_api_route(
            "/", self.index, methods=["GET"], response_class=HTMLResponse
        )
        self.add_api_route(
            "/studio", self.studio, methods=["GET"], response_class=HTMLResponse
        )
        self.add_api_route(
            "/simple", self.simple, methods=["GET"], response_class=HTMLResponse
        )
        self.add_api_route(
            "/assets/{asset_path:path}", self.assets, methods=["GET"]
        )
        self.add_api_route("/api/metadata", self.metadata, methods=["GET"])
        self.add_api_route(
            "/api/chat",
            self.chat,
            methods=["POST"],
            response_model=InteractiveChatResponse,
        )
        self.add_api_route("/api/stream", self.stream_response, methods=["POST"])

    async def index(self, request: Request) -> HTMLResponse:
        if self.ui_mode == "simple":
            return HTMLResponse(self.render_ui())
        return self._render_studio_response(request)

    async def studio(self, request: Request) -> HTMLResponse:
        return self._render_studio_response(request)

    async def simple(self) -> HTMLResponse:
        return HTMLResponse(self.render_ui())

    async def assets(self, asset_path: str):
        resolved = self._resolve_asset_path(asset_path)
        if resolved is None:
            raise HTTPException(status_code=404, detail="Asset not found.")
        return FileResponse(resolved)

    async def metadata(self) -> dict[str, Any]:
        return self.get_metadata()

    @staticmethod
    def _coalesce_callable_chunks(chunks: list[Any]):
        if not chunks:
            return ""
        if all(isinstance(chunk, str) for chunk in chunks):
            return "".join(chunks)
        return chunks

    @staticmethod
    def _is_agently_provider(provider: Any):
        from agently.core import BaseAgent, ModelRequest, TriggerFlow, TriggerFlowExecution

        return isinstance(
            provider,
            (BaseAgent, ModelRequest, TriggerFlow, TriggerFlowExecution),
        )

    @staticmethod
    def _is_base_agent_provider(provider: Any):
        from agently.core import BaseAgent

        return isinstance(provider, BaseAgent)

    def _should_handle_base_agent_directly(self, request_data: SerializableMapping):
        if not self._is_base_agent_provider(self.response_provider):
            return False

        payload_input = request_data.get("input")
        if not isinstance(payload_input, dict):
            return True

        input_mode = str(self.ui_contract.get("input_mode") or "").strip().lower()
        if input_mode == "schema":
            return True

        if self._normalize_contract_string(self.ui_contract.get("prompt_field")):
            return True

        if self._normalize_contract_string(self.ui_contract.get("history_toggle_field")):
            return True

        return False

    def _resolve_agent_prompt_field(self, input_payload: dict[str, Any]):
        explicit_field = self._normalize_contract_string(self.ui_contract.get("prompt_field"))
        if explicit_field:
            if explicit_field not in input_payload:
                raise ValueError(
                    f"InteractiveWrapper expected structured input field '{explicit_field}' for the agent prompt."
                )
            return explicit_field

        for candidate in ("message", "input", "prompt", "text"):
            if candidate in input_payload:
                return candidate

        history_field = self._resolve_history_toggle_field()
        non_control_keys = [key for key in input_payload.keys() if key != history_field]
        if len(non_control_keys) == 1:
            return non_control_keys[0]
        return None

    def _resolve_history_toggle_field(self) -> str:
        return self._normalize_contract_string(self.ui_contract.get("history_toggle_field")) or "use_history"

    def _resolve_agent_session_id(
        self,
        request_data: SerializableMapping,
        *,
        previous_session_id: str | None = None,
    ) -> str:
        explicit_session_id = self._normalize_contract_string(request_data.get("session_id"))
        if explicit_session_id:
            return explicit_session_id

        default_session_id = self._normalize_contract_string(self.ui_contract.get("default_session_id"))
        if default_session_id:
            return default_session_id

        if previous_session_id:
            return previous_session_id

        provider_name = self._normalize_contract_string(getattr(self.response_provider, "name", None))
        if provider_name:
            return provider_name

        title = self._normalize_contract_string(self.title)
        if title:
            return title

        return "interactive-session"

    def _resolve_base_agent_request(
        self,
        request_data: SerializableMapping,
    ) -> tuple[Any, dict[str, Any] | None, bool | None]:
        payload_input = request_data.get("input")
        history_toggle_field = self._resolve_history_toggle_field()
        use_history: bool | None = None

        if isinstance(payload_input, dict):
            toggle_value = payload_input.get(history_toggle_field)
            if isinstance(toggle_value, bool):
                use_history = toggle_value

            prompt_field = self._resolve_agent_prompt_field(payload_input)
            if prompt_field is None:
                raise ValueError(
                    "InteractiveWrapper could not determine which structured input field should be sent to the agent."
                )

            prompt_value = payload_input[prompt_field]
            mappings = {
                key: value
                for key, value in payload_input.items()
                if key not in {prompt_field, history_toggle_field}
            }
            return prompt_value, (mappings or None), use_history

        prompt_value = payload_input if payload_input is not None else request_data.get("message")
        if prompt_value is None:
            raise ValueError("InteractiveWrapper expected an input message for the agent request.")
        return prompt_value, None, None

    @contextmanager
    def _base_agent_session_scope(self, request_data: SerializableMapping):
        provider = cast(_SessionAwareAgent, self.response_provider)
        prompt_value, prompt_mappings, use_history = self._resolve_base_agent_request(request_data)
        previous_session = getattr(provider, "activated_session", None)
        previous_session_id = getattr(previous_session, "id", None) if previous_session is not None else None

        if use_history is None:
            provider.input(prompt_value, prompt_mappings)
            yield prompt_value, prompt_mappings
            return

        if use_history:
            target_session_id = self._resolve_agent_session_id(
                request_data,
                previous_session_id=previous_session_id,
            )
            if target_session_id != previous_session_id:
                provider.activate_session(session_id=target_session_id)
            provider.input(prompt_value, prompt_mappings)
            try:
                yield prompt_value, prompt_mappings
            finally:
                pass
            return

        provider.deactivate_session()
        try:
            provider.input(prompt_value, prompt_mappings)
            yield prompt_value, prompt_mappings
        finally:
            if previous_session_id is not None:
                try:
                    provider.activate_session(session_id=previous_session_id)
                except Exception:
                    pass

    async def _async_get_result(
        self,
        request_data: SerializableMapping,
        *,
        options: SerializableMapping | None = None,
    ):
        if self._should_handle_base_agent_directly(request_data):
            provider = cast(_SessionAwareAgent, self.response_provider)
            with self._base_agent_session_scope(request_data):
                return await FunctionShifter.auto_options_func(provider.async_start)(**(options or {}))
        return await super()._async_get_result(request_data, options=options)

    def _get_async_generator(
        self,
        request_data: SerializableMapping,
        *,
        options: SerializableMapping | None = None,
    ):
        if self._should_handle_base_agent_directly(request_data):
            provider = cast(_SessionAwareAgent, self.response_provider)

            async def managed_generator():
                with self._base_agent_session_scope(request_data):
                    generator = cast(
                        typing.AsyncGenerator[Any, None],
                        FunctionShifter.auto_options_func(provider.get_async_generator)(**(options or {})),
                    )
                    async for chunk in generator:
                        yield chunk

            return managed_generator()

        return super()._get_async_generator(request_data, options=options)

    def _uses_native_callable_provider(self):
        return callable(self.response_provider) and not self._is_agently_provider(
            self.response_provider
        )

    async def _run_native_callable(self, payload: dict[str, Any], *, options: dict[str, Any]):
        provider = cast(Callable[..., Any], self.response_provider)
        if inspect.isasyncgenfunction(provider):
            chunks: list[Any] = []
            async for chunk in provider(payload, **options):
                chunks.append(chunk)
            return self._coalesce_callable_chunks(chunks)
        if inspect.isgeneratorfunction(provider):
            return self._coalesce_callable_chunks(list(provider(payload, **options)))
        if inspect.iscoroutinefunction(provider):
            return await provider(payload, **options)
        return await asyncio.to_thread(provider, payload, **options)

    async def _stream_native_callable(self, payload: dict[str, Any], *, options: dict[str, Any]):
        provider = cast(Callable[..., Any], self.response_provider)
        if inspect.isasyncgenfunction(provider):
            async for chunk in provider(payload, **options):
                yield chunk
            return
        if inspect.isgeneratorfunction(provider):
            for chunk in provider(payload, **options):
                yield chunk
            return
        yield await self._run_native_callable(payload, options=options)

    async def chat(self, request: InteractiveChatRequest) -> Any:
        try:
            payload = self._build_request_payload(request)
            if self._uses_native_callable_provider():
                result = await self._run_native_callable(payload, options=request.options)
            else:
                result = await self._async_get_result(
                    payload,
                    options=request.options,
                )
            return self.response_warper(result)
        except Exception as error:
            return self.response_warper(error)

    async def stream_response(
        self, request: InteractiveChatRequest
    ) -> StreamingResponse:
        async def event_generator():
            try:
                payload = self._build_request_payload(request)
                if self._uses_native_callable_provider():
                    generator = self._stream_native_callable(payload, options=request.options)
                else:
                    generator = self._get_async_generator(
                        payload,
                        options=request.options,
                    )
                async for chunk in generator:
                    data = self._to_json_safe(chunk)
                    yield f"data: {json.dumps(data, ensure_ascii=False, default=str)}\n\n"
            except Exception as error:
                payload = self.response_warper(error)
                yield f"event: error\ndata: {json.dumps(payload, ensure_ascii=False, default=str)}\n\n"

        return StreamingResponse(event_generator(), media_type="text/event-stream")

    def _build_request_payload(self, request: InteractiveChatRequest) -> dict[str, Any]:
        payload_input = request.input if request.input is not None else request.message
        payload: dict[str, Any] = {"input": payload_input if payload_input is not None else ""}
        if request.session_id:
            payload["session_id"] = request.session_id
        return payload

    def _supports_streaming(self) -> bool:
        from agently.core import (
            BaseAgent,
            ModelRequest,
            TriggerFlow,
            TriggerFlowExecution,
        )

        if isinstance(
            self.response_provider,
            (BaseAgent, ModelRequest, TriggerFlow, TriggerFlowExecution),
        ):
            return True
        if callable(self.response_provider):
            return inspect.isgeneratorfunction(
                self.response_provider
            ) or inspect.isasyncgenfunction(self.response_provider)
        return False

    def get_metadata(self) -> dict[str, Any]:
        from agently.core import TriggerFlow, TriggerFlowExecution

        metadata: dict[str, Any] = {
            "title": self.title,
            "description": self.description,
            "provider_type": type(self.response_provider).__name__,
            "ui_url": self.ui_url,
            "studio_ui_url": self.studio_ui_url,
            "simple_ui_url": self.simple_ui_url,
            "auto_start": self.auto_start,
            "supports_streaming": self._supports_streaming(),
            "ui_mode": self.ui_mode,
            "available_ui_modes": ["studio", "simple"],
            "ui_contract": self._json_safe(self.ui_contract),
        }

        if isinstance(self.response_provider, (TriggerFlow, TriggerFlowExecution)):
            try:
                contract_metadata = self._get_triggerflow_contract_metadata()
                if contract_metadata:
                    metadata["contract"] = self._json_safe(contract_metadata)

                initial_input = self._get_triggerflow_contract_data_type()
                result_type = self._get_triggerflow_result_type()
                if initial_input is not None:
                    metadata["initial_input_type"] = str(initial_input)
                if result_type is not None:
                    metadata["result_type"] = str(result_type)
            except Exception:
                pass

        return metadata

    def render_ui(self) -> str:
        title = html.escape(self.title or "Interactive Wrapper")
        description = html.escape(
            self.description or "Interactive wrapper for Agent/TriggerFlow demo"
        )

        return """
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{title}</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{
                font-family: -apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif;
                background: #f5f5f5;
                color: #333;
            }}
            .container {{
                max-width: 1200px;
                margin: 0 auto;
                display: flex;
                flex-direction: column;
                height: 100vh;
            }}
            header {{
                background: white;
                border-bottom: 1px solid #e0e0e0;
                padding: 20px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            }}
            h1 {{
                font-size: 24px;
                margin-bottom: 8px;
            }}
            .description {{
                color: #666;
                font-size: 14px;
            }}
            .content {{
                flex: 1;
                display: flex;
                overflow: hidden;
            }}
            .chat-panel {{
                flex: 1;
                display: flex;
                flex-direction: column;
                background: white;
                margin: 20px;
                border-radius: 8px;
                box-shadow: 0 1px 3px rgba(0,0,0,0.1);
                overflow: hidden;
            }}
            .messages {{
                flex: 1;
                overflow-y: auto;
                padding: 20px;
            }}
            .message {{
                margin-bottom: 12px;
                padding: 12px;
                border-radius: 6px;
                word-wrap: break-word;
                white-space: pre-wrap;
            }}
            .user-message {{
                background: #e3f2fd;
                text-align: right;
            }}
            .assistant-message {{
                background: #f5f5f5;
                border-left: 3px solid #2196F3;
            }}
            .input-area {{
                padding: 20px;
                border-top: 1px solid #e0e0e0;
                display: flex;
                gap: 10px;
            }}
            input {{
                flex: 1;
                padding: 12px;
                border: 1px solid #ddd;
                border-radius: 6px;
                font-size: 14px;
            }}
            button {{
                padding: 12px 24px;
                background: #2196F3;
                color: white;
                border: none;
                border-radius: 6px;
                cursor: pointer;
                font-size: 14px;
                font-weight: 500;
            }}
            button:hover {{
                background: #1976D2;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <header>
                <h1>{title}</h1>
                <p class="description">{description}</p>
            </header>
            <div class="content">
                <div class="chat-panel">
                    <div class="messages" id="messages"></div>
                    <div class="input-area">
                        <input type="text" id="input" placeholder="Type your message..." />
                        <button onclick="sendMessage()">Send</button>
                    </div>
                </div>
            </div>
        </div>

        <script>
            const messagesDiv = document.getElementById('messages');
            const inputField = document.getElementById('input');

            function addMessage(text, isUser) {{
                const msg = document.createElement('div');
                msg.className = isUser ? 'message user-message' : 'message assistant-message';
                msg.textContent = text;
                messagesDiv.appendChild(msg);
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
                return msg;
            }}

            function scrollMessages() {{
                messagesDiv.scrollTop = messagesDiv.scrollHeight;
            }}

            function setMessageText(messageElement, text) {{
                messageElement.textContent = text;
                scrollMessages();
            }}

            function appendMessageText(messageElement, text) {{
                messageElement.textContent += text;
                scrollMessages();
            }}

            function parseSseEvent(rawEvent) {{
                const event = {{ event: 'message', data: '' }};
                for (const line of rawEvent.split('\\n')) {{
                    if (line.startsWith('event:')) {{
                        event.event = line.slice(6).trim() || 'message';
                    }} else if (line.startsWith('data:')) {{
                        const chunk = line.slice(5).trimStart();
                        event.data = event.data ? `${{event.data}}\\n${{chunk}}` : chunk;
                    }}
                }}
                if (!event.data) {{
                    return null;
                }}
                return event;
            }}

            function extractChunkText(payload) {{
                if (typeof payload === 'string') {{
                    return {{ text: payload, structured: false }};
                }}
                if (payload === null || payload === undefined) {{
                    return {{ text: '', structured: false }};
                }}
                if (Array.isArray(payload)) {{
                    return {{ text: JSON.stringify(payload, null, 2), structured: true }};
                }}
                if (typeof payload !== 'object') {{
                    return {{ text: String(payload), structured: false }};
                }}

                const candidates = [payload.delta, payload.content, payload.text, payload.message];
                if (payload.data && typeof payload.data === 'object') {{
                    candidates.push(
                        payload.data.delta,
                        payload.data.content,
                        payload.data.text,
                        payload.data.message,
                    );
                }}

                for (const candidate of candidates) {{
                    if (typeof candidate === 'string' && candidate.length > 0) {{
                        return {{ text: candidate, structured: false }};
                    }}
                }}

                return {{ text: JSON.stringify(payload, null, 2), structured: true }};
            }}

            async function loadMetadata() {{
                try {{
                    const response = await fetch('/api/metadata');
                    if (!response.ok) {{
                        return true;
                    }}
                    const metadata = await response.json();
                    return metadata.supports_streaming !== false;
                }} catch (error) {{
                    return true;
                }}
            }}

            async function requestWholeResponse(message, assistantMessage) {{
                const response = await fetch('/api/chat', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{
                        message,
                        session_id: null,
                        options: {{}}
                    }})
                }});
                const data = await response.json();
                if (data.status === 200) {{
                    setMessageText(assistantMessage, JSON.stringify(data.data, null, 2));
                    return;
                }}
                throw new Error(data.msg || data.error?.message || 'Unknown error');
            }}

            async function requestStream(message, assistantMessage) {{
                const response = await fetch('/api/stream', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{
                        message,
                        session_id: null,
                        options: {{}}
                    }})
                }});

                if (!response.ok || !response.body) {{
                    throw new Error('Streaming is unavailable.');
                }}

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';
                let chunkCount = 0;
                let renderedStructured = false;
                setMessageText(assistantMessage, '');

                while (true) {{
                    const {{ value, done }} = await reader.read();
                    buffer += decoder.decode(value || new Uint8Array(), {{ stream: !done }});

                    let boundary = buffer.indexOf('\\n\\n');
                    while (boundary !== -1) {{
                        const rawEvent = buffer.slice(0, boundary);
                        buffer = buffer.slice(boundary + 2);

                        const parsedEvent = parseSseEvent(rawEvent);
                        if (parsedEvent) {{
                            const payload = JSON.parse(parsedEvent.data);
                            if (parsedEvent.event === 'error') {{
                                throw new Error(payload.msg || payload.error?.message || 'Unknown error');
                            }}

                            const normalized = extractChunkText(payload);
                            if (normalized.structured) {{
                                if (!renderedStructured) {{
                                    setMessageText(assistantMessage, normalized.text);
                                    renderedStructured = true;
                                }} else {{
                                    appendMessageText(assistantMessage, `\\n${{normalized.text}}`);
                                }}
                            }} else if (renderedStructured) {{
                                appendMessageText(assistantMessage, `\\n${{normalized.text}}`);
                            }} else {{
                                appendMessageText(assistantMessage, normalized.text);
                            }}

                            chunkCount += 1;
                        }}

                        boundary = buffer.indexOf('\\n\\n');
                    }}

                    if (done) {{
                        break;
                    }}
                }}

                return chunkCount > 0;
            }}

            const metadataPromise = loadMetadata();

            async function sendMessage() {{
                const message = inputField.value.trim();
                if (!message) return;

                addMessage(message, true);
                inputField.value = '';
                const assistantMessage = addMessage('Receiving response...', false);

                try {{
                    const supportsStreaming = await metadataPromise;
                    if (supportsStreaming) {{
                        const streamed = await requestStream(message, assistantMessage);
                        if (!streamed) {{
                            await requestWholeResponse(message, assistantMessage);
                        }}
                    }} else {{
                        await requestWholeResponse(message, assistantMessage);
                    }}
                }} catch (error) {{
                    try {{
                        await requestWholeResponse(message, assistantMessage);
                    }} catch (fallbackError) {{
                        setMessageText(
                            assistantMessage,
                            'Error: ' + (fallbackError.message || error.message || 'Unknown error')
                        );
                    }}
                }}
            }}

            inputField.addEventListener('keypress', (event) => {{
                if (event.key === 'Enter') sendMessage();
            }});
        </script>
    </body>
    </html>
        """.format(
            title=title, description=description
        )

    def _run_server(self) -> None:
        try:
            import uvicorn
        except Exception as error:
            self._server_error = RuntimeError(
                "`uvicorn` is required to serve the interactive wrapper. Install with `pip install uvicorn`."
            )
            raise self._server_error from error

        config = uvicorn.Config(
            self,
            host=self.bind_host,
            port=self.bind_port,
            log_level="info",
            access_log=False,
            **self._uvicorn_kwargs,
        )
        server = uvicorn.Server(config)
        try:
            setattr(server, "install_signal_handlers", lambda: None)
        except Exception:
            pass

        try:
            server.run()
        except Exception as error:
            self._server_error = error
            raise

    def _probe_listener(self, timeout: float = 0.35) -> bool:
        try:
            with urllib.request.urlopen(
                f"{self.ui_url}api/metadata", timeout=timeout
            ) as response:
                if response.status >= 400:
                    return False
                payload = json.loads(response.read().decode("utf-8"))
        except (urllib.error.URLError, TimeoutError, ValueError, OSError):
            return False

        return (
            isinstance(payload, dict)
            and payload.get("provider_type") == type(self.response_provider).__name__
        )

    def _wait_until_ready(self, timeout: float) -> None:
        deadline = time.time() + timeout
        while time.time() < deadline:
            if self._probe_listener():
                return
            thread = self._server_thread
            if thread is not None and not thread.is_alive():
                break
            time.sleep(0.1)

        if self._server_error is not None:
            raise RuntimeError(
                f"Interactive wrapper failed to start on {self.ui_url.rstrip('/')}"
            ) from self._server_error
        raise RuntimeError(
            f"Timed out while starting interactive wrapper at {self.ui_url.rstrip('/')}."
        )

    def _maybe_open_browser(self) -> None:
        if self._last_opened_url == self.ui_url:
            return
        try:
            webbrowser.open(self.ui_url)
            self._last_opened_url = self.ui_url
        except Exception:
            pass

    def ensure_started(
        self,
        host: str | None = None,
        port: int | None = None,
        *,
        open_browser: bool | None = None,
        wait_timeout: float | None = None,
        uvicorn_kwargs: dict[str, Any] | None = None,
    ) -> threading.Thread:
        resolved_host = self.bind_host if host is None else host
        resolved_port = self.bind_port if port is None else port
        resolved_open_browser = (
            self.open_browser if open_browser is None else open_browser
        )
        resolved_wait_timeout = (
            self.startup_timeout if wait_timeout is None else wait_timeout
        )

        if uvicorn_kwargs is not None:
            self._uvicorn_kwargs.update(uvicorn_kwargs)

        with self._server_lock:
            thread = self._server_thread
            if thread is not None and thread.is_alive():
                if (resolved_host, resolved_port) != (self.bind_host, self.bind_port):
                    raise RuntimeError(
                        f"Interactive wrapper is already running on {self.bind_host}:{self.bind_port}; "
                        f"cannot move it to {resolved_host}:{resolved_port} without restarting the process."
                    )
                if resolved_open_browser:
                    self._maybe_open_browser()
                return thread

            self.bind_host = resolved_host
            self.bind_port = resolved_port
            self.open_browser = resolved_open_browser
            self._server_error = None
            self._server_thread = threading.Thread(
                target=self._run_server,
                name=f"InteractiveWrapperServer-{self.bind_host}:{self.bind_port}",
                daemon=True,
            )
            self._server_thread.start()

        self._wait_until_ready(resolved_wait_timeout)
        if resolved_open_browser:
            self._maybe_open_browser()
        return self._server_thread

    def wait(self) -> threading.Thread | None:
        thread = self._server_thread
        if thread is None:
            return None
        while thread.is_alive():
            thread.join(timeout=0.25)
        return thread

    def serve(
        self,
        host: str | None = None,
        port: int | None = None,
        *,
        open_browser: bool = True,
        block: bool = True,
        uvicorn_kwargs: dict[str, Any] | None = None,
    ) -> threading.Thread | None:
        thread = self.ensure_started(
            host=host,
            port=port,
            open_browser=open_browser,
            uvicorn_kwargs=uvicorn_kwargs,
        )
        if block:
            self.wait()
            return None
        return thread


__all__ = ["InteractiveWrapper"]
