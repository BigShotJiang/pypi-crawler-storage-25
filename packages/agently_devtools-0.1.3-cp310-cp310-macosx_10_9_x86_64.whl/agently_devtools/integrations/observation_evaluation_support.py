# Copyright 2023-2026 AgentEra(Agently.Tech)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from collections.abc import Callable, Sequence
from typing import Any

from agently_devtools._agently_compat import RuntimeEvent
from agently_devtools.integrations.observation_api_models import (
    EvaluationCheckPayload,
    EvaluationRoundPayload,
    EvaluationSuiteReportPayload,
    EvaluationSuiteSummaryPayload,
    EvaluationVariantSummaryPayload,
)
from agently_devtools.observation import RuntimeObservationService


class ObservationEvaluationSupport:
    def __init__(
        self,
        *,
        observation_service: RuntimeObservationService,
        build_event_query: Callable[..., Any],
    ):
        self._observation_service = observation_service
        self._build_event_query = build_event_query

    @staticmethod
    def normalize_evaluation_checks(value: Any):
        if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
            return []
        checks: list[EvaluationCheckPayload] = []
        for item in value:
            if not isinstance(item, dict):
                continue
            checks.append(
                EvaluationCheckPayload(
                    name=str(item.get("name", "check")),
                    passed=bool(item.get("passed", False)),
                    detail=item.get("detail"),
                    meta=(
                        dict(item.get("meta", {}))
                        if isinstance(item.get("meta", {}), dict)
                        else {}
                    ),
                )
            )
        return checks

    def resolve_evaluation_run(self, observed_run_ids: Sequence[str]):
        for run_id in observed_run_ids:
            run = self._observation_service.get_run(run_id)
            if run is not None:
                return run
        return None

    def build_evaluation_round_payload(self, event: RuntimeEvent):
        payload = event.payload if isinstance(event.payload, dict) else None
        if payload is None:
            return None

        suite_id = payload.get("suite_id")
        case_id = payload.get("case_id")
        target_type = payload.get("target_type")
        target_name = payload.get("target_name")
        if not isinstance(suite_id, str) or not suite_id:
            return None
        if not isinstance(case_id, str) or not case_id:
            return None
        if not isinstance(target_type, str) or not target_type:
            return None
        if not isinstance(target_name, str) or not target_name:
            return None

        raw_run_ids = payload.get("observed_run_ids", [])
        observed_run_ids = (
            [str(item) for item in raw_run_ids]
            if isinstance(raw_run_ids, Sequence)
            and not isinstance(raw_run_ids, (str, bytes))
            else []
        )
        linked_run = self.resolve_evaluation_run(observed_run_ids)
        linked_root_run_id = (
            linked_run.root_run_id
            if linked_run is not None
            else (observed_run_ids[0] if observed_run_ids else None)
        )
        linked_run_id = (
            linked_run.run_id if linked_run is not None else linked_root_run_id
        )
        app_id = event.meta.get("app_id")
        group_id = event.meta.get("group_id")
        if linked_run is not None:
            app_id = app_id or linked_run.meta.get("app_id")
            group_id = group_id or linked_run.meta.get("group_id")

        variant_meta = payload.get("variant_meta", {})
        if not isinstance(variant_meta, dict):
            variant_meta = {}

        return EvaluationRoundPayload(
            suite_id=suite_id,
            case_id=case_id,
            round_index=int(payload.get("round_index", 0) or 0),
            target_type=target_type,
            target_name=target_name,
            variant_id=(
                str(payload["variant_id"])
                if payload.get("variant_id") is not None
                else None
            ),
            variant_label=(
                str(payload["variant_label"])
                if payload.get("variant_label") is not None
                else None
            ),
            variant_kind=(
                str(payload["variant_kind"])
                if payload.get("variant_kind") is not None
                else None
            ),
            variant_meta=dict(variant_meta),
            passed=bool(payload.get("passed", False)),
            error=str(payload["error"]) if payload.get("error") is not None else None,
            checks=self.normalize_evaluation_checks(payload.get("checks", [])),
            observed_run_ids=observed_run_ids,
            run_id=linked_run_id,
            root_run_id=linked_root_run_id,
            status=linked_run.status if linked_run is not None else None,
            started_at=linked_run.started_at if linked_run is not None else None,
            updated_at=(
                linked_run.updated_at if linked_run is not None else event.timestamp
            ),
            app_id=str(app_id) if app_id is not None else None,
            group_id=str(group_id) if group_id is not None else None,
            timestamp=event.timestamp,
        )

    def list_evaluation_rounds(
        self,
        *,
        suite_id: str | None = None,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        group_id: str | None = None,
        search: str | None = None,
        since: int | None = None,
        until: int | None = None,
    ):
        query = self._build_event_query(
            event_types=["evaluation.round.result"],
            app_id=app_id,
            app_id_pattern=app_id_pattern,
            search=search,
            since=since,
            until=until,
            limit=None,
        )
        events = self._observation_service.query_events(query)
        rounds: list[EvaluationRoundPayload] = []
        for event in events:
            round_payload = self.build_evaluation_round_payload(event)
            if round_payload is None:
                continue
            if suite_id is not None and round_payload.suite_id != suite_id:
                continue
            if group_id is not None and round_payload.group_id != group_id:
                continue
            rounds.append(round_payload)
        return rounds

    @staticmethod
    def sort_evaluation_rounds(rounds: Sequence[EvaluationRoundPayload]):
        return sorted(
            rounds,
            key=lambda item: (
                item.variant_label or item.variant_id or "",
                item.case_id,
                item.round_index,
                item.timestamp,
            ),
        )

    def build_evaluation_suite_report(
        self, suite_id: str, rounds: Sequence[EvaluationRoundPayload]
    ):
        ordered_rounds = self.sort_evaluation_rounds(rounds)
        latest_round = max(ordered_rounds, key=lambda item: item.timestamp)
        variant_index: dict[str, dict[str, Any]] = {}
        case_ids = {item.case_id for item in ordered_rounds}
        for item in ordered_rounds:
            variant_key = item.variant_id or "default"
            variant_bucket = variant_index.setdefault(
                variant_key,
                {
                    "variant_id": variant_key,
                    "variant_label": item.variant_label,
                    "variant_kind": item.variant_kind,
                    "total_rounds": 0,
                    "passed_rounds": 0,
                    "failed_rounds": 0,
                    "case_ids": set(),
                },
            )
            variant_bucket["total_rounds"] += 1
            variant_bucket["passed_rounds"] += 1 if item.passed else 0
            variant_bucket["failed_rounds"] += 0 if item.passed else 1
            variant_bucket["case_ids"].add(item.case_id)

        variant_summaries = [
            EvaluationVariantSummaryPayload(
                variant_id=str(bucket["variant_id"]),
                variant_label=(
                    str(bucket["variant_label"])
                    if bucket["variant_label"] is not None
                    else None
                ),
                variant_kind=(
                    str(bucket["variant_kind"])
                    if bucket["variant_kind"] is not None
                    else None
                ),
                total_rounds=int(bucket["total_rounds"]),
                passed_rounds=int(bucket["passed_rounds"]),
                failed_rounds=int(bucket["failed_rounds"]),
                case_count=len(bucket["case_ids"]),
            )
            for bucket in sorted(
                variant_index.values(),
                key=lambda item: str(item["variant_label"] or item["variant_id"]),
            )
        ]

        return EvaluationSuiteReportPayload(
            suite_id=suite_id,
            target_type=latest_round.target_type,
            target_name=latest_round.target_name,
            app_id=latest_round.app_id,
            group_id=latest_round.group_id,
            total_rounds=len(ordered_rounds),
            passed_rounds=sum(1 for item in ordered_rounds if item.passed),
            failed_rounds=sum(1 for item in ordered_rounds if not item.passed),
            variant_count=len(variant_summaries),
            case_count=len(case_ids),
            updated_at=max(
                item.updated_at or item.timestamp for item in ordered_rounds
            ),
            latest_run_id=latest_round.run_id or latest_round.root_run_id,
            variants=variant_summaries,
            rounds=list(ordered_rounds),
        )

    def list_evaluation_suite_summaries(
        self,
        *,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        group_id: str | None = None,
        search: str | None = None,
        since: int | None = None,
        until: int | None = None,
        limit: int | None = None,
    ):
        rounds = self.list_evaluation_rounds(
            app_id=app_id,
            app_id_pattern=app_id_pattern,
            group_id=group_id,
            search=search,
            since=since,
            until=until,
        )
        suite_map: dict[str, list[EvaluationRoundPayload]] = {}
        for item in rounds:
            suite_map.setdefault(item.suite_id, []).append(item)
        suites = [
            EvaluationSuiteSummaryPayload.model_validate(
                self.build_evaluation_suite_report(suite_id, suite_rounds).model_dump(
                    mode="json", exclude={"rounds"}
                )
            )
            for suite_id, suite_rounds in suite_map.items()
        ]
        suites.sort(key=lambda item: (item.updated_at or 0), reverse=True)
        if limit is not None:
            suites = suites[:limit]
        return suites

    def get_evaluation_suite_report(
        self,
        suite_id: str,
        *,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        group_id: str | None = None,
        search: str | None = None,
        since: int | None = None,
        until: int | None = None,
    ):
        rounds = self.list_evaluation_rounds(
            suite_id=suite_id,
            app_id=app_id,
            app_id_pattern=app_id_pattern,
            group_id=group_id,
            search=search,
            since=since,
            until=until,
        )
        if not rounds:
            return None
        return self.build_evaluation_suite_report(suite_id, rounds)