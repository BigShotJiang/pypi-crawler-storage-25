# Copyright 2023-2026 AgentEra(Agently.Tech)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import contextlib
import uuid
from collections.abc import Awaitable, Callable, Sequence
from typing import Any, cast

from agently import Agently

from agently_devtools._agently_compat import RunContext, RuntimeEvent
from agently_devtools.integrations.observation_api_models import (
    PlaygroundRequestRunPayload,
    PlaygroundRequestRunRequest,
)
from agently_devtools.observation import RuntimeObservationService


class ObservationPlaygroundSupport:
    def __init__(self, *, observation_service: RuntimeObservationService):
        self._observation_service = observation_service

    @staticmethod
    def normalize_playground_request_name(request_name: str | None):
        normalized = (request_name or "").strip()
        return normalized or "playground-request"

    @staticmethod
    def normalize_playground_surface_id(surface_id: str | None):
        normalized = (surface_id or "request").strip().lower().replace(" ", "_")
        return normalized or "request"

    @staticmethod
    def normalize_playground_target_mode(target_mode: str | None):
        normalized = (target_mode or "request").strip().lower()
        return "agent" if normalized == "agent" else "request"

    @staticmethod
    def latest_event_by_type(events: Sequence[RuntimeEvent], event_type: str):
        for event in reversed(events):
            if event.event_type == event_type:
                return event
        return None

    def create_playground_root_run(
        self,
        *,
        surface_id: str,
        request_name: str,
        app_id: str,
        group_id: str | None,
        session_id: str | None = None,
    ):
        meta = {
            "app_id": app_id,
            "component": "playground",
            "playground_surface": surface_id,
            "flow_name": f"playground.{surface_id}",
            "request_name": request_name,
        }
        if group_id is not None:
            meta["group_id"] = group_id
        if session_id is not None:
            meta["session_id"] = session_id
        return RunContext.create(
            run_kind="workflow_execution",
            agent_name=request_name,
            execution_id=f"playground-request-{uuid.uuid4().hex[:12]}",
            meta=meta,
        )

    @staticmethod
    def extract_playground_stream_text(events: Sequence[RuntimeEvent]):
        chunks: list[str] = []
        completed_stream_text: str | None = None
        for event in events:
            if event.event_type == "model.streaming":
                payload = event.payload if isinstance(event.payload, dict) else {}
                delta = payload.get("delta")
                if isinstance(delta, str):
                    chunks.append(delta)
                elif isinstance(event.message, str) and event.message:
                    chunks.append(event.message)
                continue
            if event.event_type != "model.completed" or not isinstance(
                event.payload, dict
            ):
                continue
            streamed_text = event.payload.get("streamed_text")
            if isinstance(streamed_text, str) and streamed_text:
                completed_stream_text = streamed_text
        chunk_text = "".join(chunks)
        if completed_stream_text and len(completed_stream_text) >= len(chunk_text):
            return completed_stream_text
        return chunk_text or completed_stream_text

    async def collect_playground_observed_events(
        self,
        *,
        subscription: Any,
        observed_events: list[RuntimeEvent],
        seen_event_ids: set[str],
        known_run_ids: set[str],
        stop_signal: asyncio.Event,
        on_runtime_event: Callable[[RuntimeEvent], Awaitable[None]] | None = None,
    ):
        try:
            while True:
                timeout = 0.12 if not stop_signal.is_set() else 0.02
                try:
                    event = await subscription.get(timeout=timeout)
                except (TimeoutError, asyncio.TimeoutError):
                    if stop_signal.is_set():
                        with contextlib.suppress(asyncio.QueueEmpty):
                            while True:
                                drained_event = subscription.queue.get_nowait()
                                if not self.should_capture_playground_event(
                                    drained_event, known_run_ids
                                ):
                                    continue
                                if drained_event.event_id in seen_event_ids:
                                    continue
                                if drained_event.run is not None:
                                    known_run_ids.add(drained_event.run.run_id)
                                seen_event_ids.add(drained_event.event_id)
                                observed_events.append(drained_event)
                                if on_runtime_event is not None:
                                    await on_runtime_event(drained_event)
                        break
                    continue
                if not self.should_capture_playground_event(event, known_run_ids):
                    continue
                if event.event_id in seen_event_ids:
                    continue
                if event.run is not None:
                    known_run_ids.add(event.run.run_id)
                seen_event_ids.add(event.event_id)
                observed_events.append(event)
                if on_runtime_event is not None:
                    await on_runtime_event(event)
        finally:
            subscription.close()

    @staticmethod
    def should_capture_playground_event(
        event: RuntimeEvent, known_run_ids: set[str]
    ):
        run = event.run
        if run is None:
            return False
        return (
            run.run_id in known_run_ids
            or (run.parent_run_id is not None and run.parent_run_id in known_run_ids)
            or (run.root_run_id is not None and run.root_run_id in known_run_ids)
        )

    def start_playground_event_collector(
        self,
        *,
        observed_events: list[RuntimeEvent],
        seen_event_ids: set[str],
        known_run_ids: set[str],
        stop_signal: asyncio.Event,
        on_runtime_event: Callable[[RuntimeEvent], Awaitable[None]] | None = None,
    ):
        subscription = self._observation_service.subscribe(maxsize=2048)
        return asyncio.create_task(
            self.collect_playground_observed_events(
                subscription=subscription,
                observed_events=observed_events,
                seen_event_ids=seen_event_ids,
                known_run_ids=known_run_ids,
                stop_signal=stop_signal,
                on_runtime_event=on_runtime_event,
            )
        )

    def apply_playground_prompt(
        self, target: Any, body: PlaygroundRequestRunRequest, *, target_mode: str
    ):
        prompt_source = (body.prompt_source or "slots").strip().lower()
        if prompt_source == "yaml":
            loader = getattr(target, "load_yaml_prompt", None)
            if not callable(loader):
                raise TypeError(
                    "Current playground target does not support YAML prompt config."
                )
            loader(
                body.prompt_config or "",
                mappings=body.prompt_mappings or None,
                prompt_key_path=body.prompt_key_path,
            )
            return
        if prompt_source == "json":
            loader = getattr(target, "load_json_prompt", None)
            if not callable(loader):
                raise TypeError(
                    "Current playground target does not support JSON prompt config."
                )
            loader(
                body.prompt_config or "",
                mappings=body.prompt_mappings or None,
                prompt_key_path=body.prompt_key_path,
            )
            return

        prompt_target = (
            getattr(target, "request", target) if target_mode == "agent" else target
        )
        setter = getattr(prompt_target, "set_prompt", None)
        if not callable(setter):
            raise TypeError(
                "Current playground target does not support prompt slot configuration."
            )
        if body.system is not None:
            setter("system", body.system)
        if body.developer is not None:
            setter("developer", body.developer)
        if body.instruct is not None:
            setter("instruct", body.instruct)
        if body.input is not None:
            setter("input", body.input)
        if body.output is not None:
            setter("output", body.output)

    def build_playground_request(self, body: PlaygroundRequestRunRequest):
        request_name = self.normalize_playground_request_name(body.request_name)
        target_mode = self.normalize_playground_target_mode(body.target_mode)
        target = (
            cast(Any, Agently).create_agent(request_name)
            if target_mode == "agent"
            else cast(Any, Agently).create_request(request_name)
        )
        for key, value in body.settings.items():
            target.set_settings(str(key), value)
        self.apply_playground_prompt(target, body, target_mode=target_mode)
        return request_name, target_mode, target

    def build_playground_request_run_payload(
        self,
        *,
        surface_id: str,
        request_name: str,
        target_mode: str,
        app_id: str,
        group_id: str | None,
        result: Any = None,
        error: str | None = None,
        primary_run: RunContext | None = None,
        events: Sequence[RuntimeEvent] | None = None,
    ):
        observed_events = list(events or [])
        primary_run_id = primary_run.run_id if primary_run is not None else None
        stored_run = (
            self._observation_service.get_run(primary_run_id)
            if primary_run_id is not None
            else None
        )

        prompt_event = self.latest_event_by_type(observed_events, "prompt.built")
        requesting_event = self.latest_event_by_type(
            observed_events, "model.requesting"
        )
        meta_event = self.latest_event_by_type(observed_events, "model.meta")
        latest_event = observed_events[-1] if observed_events else None

        prompt_payload = (
            prompt_event.payload
            if prompt_event is not None and isinstance(prompt_event.payload, dict)
            else {}
        )
        requesting_payload = (
            requesting_event.payload
            if requesting_event is not None
            and isinstance(requesting_event.payload, dict)
            else {}
        )
        meta_payload = (
            meta_event.payload
            if meta_event is not None and isinstance(meta_event.payload, dict)
            else {}
        )

        prompt = (
            dict(prompt_payload.get("prompt", {}))
            if isinstance(prompt_payload.get("prompt", {}), dict)
            else {}
        )
        request_payload = (
            dict(requesting_payload.get("request", {}))
            if isinstance(requesting_payload.get("request", {}), dict)
            else {}
        )
        model_meta = (
            dict(meta_payload.get("meta", {}))
            if isinstance(meta_payload.get("meta", {}), dict)
            else {}
        )

        return PlaygroundRequestRunPayload(
            surface_id=surface_id,
            request_name=request_name,
            target_mode=target_mode,
            app_id=app_id,
            group_id=group_id,
            run_id=primary_run_id,
            root_run_id=primary_run.root_run_id if primary_run is not None else None,
            parent_run_id=(
                primary_run.parent_run_id if primary_run is not None else None
            ),
            result=result,
            error=error,
            prompt_text=(
                str(prompt_payload["prompt_text"])
                if prompt_payload.get("prompt_text") is not None
                else None
            ),
            prompt=prompt,
            request_payload=request_payload,
            model_meta=model_meta,
            event_count=(
                len(observed_events)
                if observed_events
                else (stored_run.event_count if stored_run is not None else 0)
            ),
            stream_text=self.extract_playground_stream_text(observed_events),
            streaming_event_count=sum(
                1 for event in observed_events if event.event_type == "model.streaming"
            ),
            latest_event_type=(
                latest_event.event_type
                if latest_event is not None
                else stored_run.latest_event_type if stored_run is not None else None
            ),
            status=stored_run.status if stored_run is not None else None,
            started_at=stored_run.started_at if stored_run is not None else None,
            updated_at=stored_run.updated_at if stored_run is not None else None,
            duration_ms=(
                (stored_run.updated_at - stored_run.started_at)
                if stored_run is not None
                and stored_run.started_at is not None
                and stored_run.updated_at is not None
                else None
            ),
        )

    async def run_playground_request(
        self,
        body: PlaygroundRequestRunRequest,
        *,
        on_runtime_event: Callable[[RuntimeEvent], Awaitable[None]] | None = None,
    ):
        request_name, target_mode, target = self.build_playground_request(body)
        surface_id = self.normalize_playground_surface_id(body.surface_id)
        app_id = body.app_id or "default"
        group_id = body.group_id
        root_run = self.create_playground_root_run(
            surface_id=surface_id,
            request_name=request_name,
            app_id=app_id,
            group_id=group_id,
        )
        emitter = cast(Any, Agently.event_center).create_emitter(
            "DevToolsPlayground",
            base_meta={
                "app_id": app_id,
                "group_id": group_id,
                "component": "playground",
                "playground_surface": surface_id,
                "request_name": request_name,
            },
            base_run=root_run,
        )

        primary_run: RunContext | None = None
        result: Any = None
        error: str | None = None
        observed_events: list[RuntimeEvent] = []
        seen_event_ids: set[str] = set()
        known_run_ids: set[str] = {root_run.run_id}
        stop_signal = asyncio.Event()
        collector_tasks: list[asyncio.Task[None]] = [
            self.start_playground_event_collector(
                observed_events=observed_events,
                seen_event_ids=seen_event_ids,
                known_run_ids=known_run_ids,
                stop_signal=stop_signal,
                on_runtime_event=on_runtime_event,
            )
        ]

        try:
            await emitter.async_emit(
                "playground.request.started",
                message=f"Playground request '{ request_name }' started.",
                payload={"request_name": request_name},
            )
            response = cast(Any, target).get_response(parent_run_context=root_run)
            primary_run = getattr(response, "agent_turn_run_context", None) or getattr(
                response, "run_context", None
            )
            if primary_run is not None:
                known_run_ids.add(primary_run.run_id)
            if body.output is not None:
                result = await response.async_get_data()
            else:
                result = await response.async_get_text()
            await emitter.async_emit(
                "playground.request.completed",
                message=f"Playground request '{ request_name }' completed.",
                payload={
                    "request_name": request_name,
                    "request_run_id": (
                        primary_run.run_id if primary_run is not None else None
                    ),
                },
            )
        except Exception as exc:
            error = str(exc)
            await emitter.async_emit(
                "playground.request.failed",
                level="ERROR",
                message=f"Playground request '{ request_name }' failed.",
                payload={
                    "request_name": request_name,
                    "request_run_id": (
                        primary_run.run_id if primary_run is not None else None
                    ),
                },
                error=exc,
            )
        finally:
            stop_signal.set()
            with contextlib.suppress(asyncio.CancelledError):
                await asyncio.gather(*collector_tasks)
        return self.build_playground_request_run_payload(
            surface_id=surface_id,
            request_name=request_name,
            target_mode=target_mode,
            app_id=app_id,
            group_id=group_id,
            result=result,
            error=error,
            primary_run=primary_run,
            events=observed_events,
        )