from typing import Annotated, Any

from fastapi import FastAPI, Header, Query

from agently_devtools.integrations.observation_api_models import LocalAuthUpdateRequest


OptionalStrHeader = Annotated[str | None, Header()]
OptionalStrQuery = Annotated[str | None, Query()]


def register_settings_routes(app: FastAPI, owner: Any):
    @app.get("/devtools/settings")
    async def get_devtools_settings(
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        return owner._wrap_response(owner.get_local_settings())

    @app.put("/devtools/settings/local-auth")
    async def update_devtools_local_auth(
        body: LocalAuthUpdateRequest,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        return owner._wrap_response(
            owner.update_local_auth(
                enabled=body.enabled,
                api_key=body.api_key,
            )
        )