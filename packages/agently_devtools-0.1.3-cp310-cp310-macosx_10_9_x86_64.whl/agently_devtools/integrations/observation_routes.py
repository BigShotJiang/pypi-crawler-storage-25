from typing import Annotated, Any

from fastapi import FastAPI, Header, HTTPException, Query

from agently_devtools._agently_compat import RuntimeEvent
from agently_devtools.integrations.observation_api_models import (
    FlowDefinitionRegistrationRequest,
    ObservationIngestRequest,
)
from agently_devtools.observation.RunStore import RunStatus


OptionalStrHeader = Annotated[str | None, Header()]
OptionalStrQuery = Annotated[str | None, Query()]
OptionalEventTypesQuery = Annotated[list[str] | None, Query()]


def register_observation_routes(app: FastAPI, owner: Any, prefix: str):
    @app.post(f"{prefix}/ingest")
    async def ingest_events(
        body: ObservationIngestRequest,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        normalized_events: list[RuntimeEvent] = []
        for event in body.events:
            event_meta = dict(event.meta)
            if "app_id" not in event_meta:
                event_meta["app_id"] = body.app_id or "default"
            if body.group_id is not None and "group_id" not in event_meta:
                event_meta["group_id"] = body.group_id
            if body.environment is not None and "environment" not in event_meta:
                event_meta["environment"] = body.environment
            normalized_events.append(event.model_copy(update={"meta": event_meta}))
        ingested = await owner.observation_service.append_events(normalized_events)
        return owner._wrap_response({"ingested": ingested})

    @app.get(f"{prefix}/runs")
    async def list_runs(
        run_id: str | None = None,
        root_run_id: str | None = None,
        parent_run_id: str | None = None,
        run_kind: str | None = None,
        status: RunStatus | None = None,
        agent_id: str | None = None,
        session_id: str | None = None,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        group_id: str | None = None,
        flow_name: str | None = None,
        search: str | None = None,
        since: int | None = None,
        until: int | None = None,
        limit: int | None = None,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        query = owner._build_run_query(
            run_id=run_id,
            root_run_id=root_run_id,
            parent_run_id=parent_run_id,
            run_kind=run_kind,
            status=status,
            agent_id=agent_id,
            session_id=session_id,
            app_id=app_id,
            app_id_pattern=app_id_pattern,
            group_id=group_id,
            flow_name=flow_name,
            search=search,
            since=since,
            until=until,
            limit=limit,
        )
        return owner._wrap_response(owner.observation_service.query_runs(query))

    @app.get(f"{prefix}/runs/{{run_id}}")
    async def get_run(
        run_id: str,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        run = owner.observation_service.get_run(run_id)
        if run is None:
            raise HTTPException(status_code=404, detail=f"Run '{ run_id }' not found.")
        return owner._wrap_response(run)

    @app.get(f"{prefix}/runs/{{run_id}}/children")
    async def get_run_children(
        run_id: str,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        return owner._wrap_response(owner.observation_service.get_run_children(run_id))

    @app.get(f"{prefix}/runs/{{run_id}}/tree")
    async def get_run_tree(
        run_id: str,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        run_tree = owner.observation_service.get_run_tree(run_id)
        if run_tree is None:
            raise HTTPException(status_code=404, detail=f"Run '{ run_id }' not found.")
        return owner._wrap_response(run_tree)

    @app.get(f"{prefix}/runs/{{run_id}}/events")
    async def get_run_events(
        run_id: str,
        include_descendants: bool = False,
        event_types: OptionalEventTypesQuery = None,
        source: str | None = None,
        level: str | None = None,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        search: str | None = None,
        since: int | None = None,
        until: int | None = None,
        limit: int | None = None,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        query = owner._build_event_query(
            run_id=run_id,
            include_descendants=include_descendants,
            event_types=event_types,
            source=source,
            level=level,
            app_id=app_id,
            app_id_pattern=app_id_pattern,
            search=search,
            since=since,
            until=until,
            limit=limit,
        )
        return owner._wrap_response(owner.observation_service.query_events(query))

    @app.get(f"{prefix}/events/recent")
    async def get_recent_events(
        event_types: OptionalEventTypesQuery = None,
        source: str | None = None,
        level: str | None = None,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        search: str | None = None,
        since: int | None = None,
        until: int | None = None,
        limit: int | None = None,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        query = owner._build_event_query(
            event_types=event_types,
            source=source,
            level=level,
            app_id=app_id,
            app_id_pattern=app_id_pattern,
            search=search,
            since=since,
            until=until,
            limit=limit,
        )
        return owner._wrap_response(owner.observation_service.query_events(query))

    @app.post(f"{prefix}/flows/register")
    async def register_flow_definition(
        body: FlowDefinitionRegistrationRequest,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        return owner._wrap_response(
            owner.observation_service.register_flow_definition(
                app_id=body.app_id,
                group_id=body.group_id,
                flow_name=body.flow_name,
                definition=body.definition,
                mermaid=body.mermaid,
            )
        )

    @app.get(f"{prefix}/flows/resolve")
    async def get_flow_definition(
        flow_name: str,
        app_id: str | None = None,
        group_id: str | None = None,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        payload = owner.observation_service.resolve_flow_definition(
            app_id=app_id,
            group_id=group_id,
            flow_name=flow_name,
        )
        if payload is None:
            raise HTTPException(
                status_code=404,
                detail=f"Flow definition '{ flow_name }' not found.",
            )
        return owner._wrap_response(payload)
