import json
from typing import Annotated, Any

from fastapi import FastAPI, Header, Query, WebSocket
from fastapi.responses import StreamingResponse

from agently_devtools.integrations.observation_http_support import coerce_bool


OptionalStrHeader = Annotated[str | None, Header()]
OptionalStrQuery = Annotated[str | None, Query()]
OptionalEventTypesQuery = Annotated[list[str] | None, Query()]


def register_observation_stream_routes(app: FastAPI, owner: Any, prefix: str):
    @app.get(f"{prefix}/stream")
    async def stream_events(
        run_id: str | None = None,
        include_descendants: bool = True,
        event_types: OptionalEventTypesQuery = None,
        source: str | None = None,
        level: str | None = None,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        limit: int | None = None,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        filter_spec = owner._build_subscription_filter(
            run_id=run_id,
            include_descendants=include_descendants,
            event_types=event_types,
            source=source,
            level=level,
            app_id=app_id,
            app_id_pattern=app_id_pattern,
        )
        subscription = owner.observation_service.subscribe(filter=filter_spec)

        async def event_stream():
            emitted = 0
            try:
                while True:
                    event = await subscription.get(timeout=None)
                    payload = json.dumps(
                        owner._to_json_safe(event.model_dump(mode="json")),
                        ensure_ascii=False,
                        default=str,
                    )
                    yield f"data: { payload }\n\n"
                    emitted += 1
                    if limit is not None and emitted >= limit:
                        break
            finally:
                subscription.close()

        return StreamingResponse(event_stream(), media_type="text/event-stream")

    @app.websocket(f"{prefix}/ws")
    async def websocket_events(websocket: WebSocket):
        if not await owner._authenticate_websocket(websocket):
            return
        await websocket.accept()
        event_types = websocket.query_params.getlist("event_type")
        run_id = websocket.query_params.get("run_id")
        include_descendants = coerce_bool(
            websocket.query_params.get("include_descendants", "true"),
            True,
        )
        source = websocket.query_params.get("source")
        level = websocket.query_params.get("level")
        app_id = websocket.query_params.get("app_id")
        app_id_pattern = websocket.query_params.get("app_id_pattern")
        limit = websocket.query_params.get("limit")
        max_events = int(limit) if isinstance(limit, str) and limit.isdigit() else None
        filter_spec = owner._build_subscription_filter(
            run_id=run_id,
            include_descendants=include_descendants,
            event_types=event_types or None,
            source=source,
            level=level,
            app_id=app_id,
            app_id_pattern=app_id_pattern,
        )
        subscription = owner.observation_service.subscribe(filter=filter_spec)
        try:
            emitted = 0
            while True:
                event = await subscription.get(timeout=None)
                await websocket.send_json(owner._to_json_safe(event.model_dump(mode="json")))
                emitted += 1
                if max_events is not None and emitted >= max_events:
                    break
        finally:
            subscription.close()