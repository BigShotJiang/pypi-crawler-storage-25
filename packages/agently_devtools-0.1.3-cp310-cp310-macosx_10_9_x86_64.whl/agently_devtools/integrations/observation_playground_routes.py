import asyncio
import contextlib
import json
from typing import Annotated, Any

from fastapi import FastAPI, Header, Query
from fastapi.responses import StreamingResponse

from agently_devtools.integrations.observation_api_models import (
    PlaygroundRequestRunRequest,
)


OptionalStrHeader = Annotated[str | None, Header()]
OptionalStrQuery = Annotated[str | None, Query()]


def register_playground_routes(app: FastAPI, owner: Any):
    @app.post("/playground/request/run")
    async def run_playground_request(
        body: PlaygroundRequestRunRequest,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        return owner._wrap_response(await owner._run_playground_request(body))

    @app.post("/playground/request/stream")
    async def stream_playground_request(
        body: PlaygroundRequestRunRequest,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue()

        async def publish(message: dict[str, Any]):
            await queue.put(message)

        async def worker():
            try:
                await publish(
                    {
                        "type": "status",
                        "data": {
                            "status": "starting",
                            "request_name": owner._normalize_playground_request_name(
                                body.request_name
                            ),
                            "surface_id": owner._normalize_playground_surface_id(
                                body.surface_id
                            ),
                        },
                    }
                )
                payload = await owner._run_playground_request(
                    body,
                    on_runtime_event=lambda event: publish(
                        {
                            "type": "runtime_event",
                            "data": owner._to_json_safe(
                                event.model_dump(mode="json")
                            ),
                        }
                    ),
                )
                await publish(
                    {
                        "type": "result",
                        "data": owner._to_json_safe(payload.model_dump(mode="json")),
                    }
                )
            except Exception as exc:
                await publish(
                    {
                        "type": "error",
                        "data": {
                            "message": str(exc),
                        },
                    }
                )
            finally:
                await queue.put(None)

        worker_task = asyncio.create_task(worker())

        async def event_stream():
            try:
                while True:
                    message = await queue.get()
                    if message is None:
                        break
                    payload = json.dumps(
                        owner._to_json_safe(message),
                        ensure_ascii=False,
                        default=str,
                    )
                    yield f"data: {payload}\n\n"
            finally:
                if not worker_task.done():
                    worker_task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await worker_task

        return StreamingResponse(event_stream(), media_type="text/event-stream")