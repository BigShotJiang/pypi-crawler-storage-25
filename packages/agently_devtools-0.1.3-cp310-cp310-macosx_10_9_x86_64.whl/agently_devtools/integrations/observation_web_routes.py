from pathlib import Path
from typing import Any, Callable

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse


def register_web_routes(
    app: FastAPI,
    owner: Any,
    *,
    inject_web_config: Callable[..., str],
    render_console: Callable[..., str],
):
    @app.get("/", response_class=HTMLResponse)
    async def observation_console(request: Request):
        base_url = str(request.base_url).rstrip("/")
        if owner._web_dist_dir is not None:
            index_file = owner._web_dist_dir / "index.html"
            if index_file.exists() and index_file.is_file():
                index_html = index_file.read_text(encoding="utf-8")
                return HTMLResponse(
                    inject_web_config(
                        index_html,
                        endpoint=base_url,
                        api_key=owner._default_console_api_key,
                        route_prefix=owner.route_prefix,
                    )
                )
        fallback_html = render_console(
            route_prefix=owner.route_prefix,
            default_api_key=owner._default_console_api_key,
        )
        return HTMLResponse(
            inject_web_config(
                fallback_html,
                endpoint=base_url,
                api_key=owner._default_console_api_key,
                route_prefix=owner.route_prefix,
            )
        )

    @app.get("/assets/{asset_path:path}")
    async def observation_assets(asset_path: str):
        if owner._web_dist_dir is None:
            raise HTTPException(status_code=404, detail="Frontend assets are not built.")
        target = (owner._web_dist_dir / "assets" / asset_path).resolve()
        assets_root = (owner._web_dist_dir / "assets").resolve()
        try:
            target.relative_to(assets_root)
        except ValueError as error:
            raise HTTPException(status_code=404, detail="Asset not found.") from error
        if not target.exists() or not target.is_file():
            raise HTTPException(status_code=404, detail="Asset not found.")
        return FileResponse(Path(target))

    @app.get("/healthz")
    async def healthz():
        return owner._wrap_response({"ok": True, "route_prefix": owner.route_prefix})