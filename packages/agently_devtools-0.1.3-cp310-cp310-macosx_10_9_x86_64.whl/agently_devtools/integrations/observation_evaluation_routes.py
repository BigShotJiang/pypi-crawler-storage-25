from typing import Annotated, Any

from fastapi import FastAPI, Header, HTTPException, Query


OptionalStrHeader = Annotated[str | None, Header()]
OptionalStrQuery = Annotated[str | None, Query()]


def register_evaluation_routes(app: FastAPI, owner: Any):
    @app.get("/evaluations/suites")
    async def list_evaluation_suites(
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        group_id: str | None = None,
        search: str | None = None,
        since: int | None = None,
        until: int | None = None,
        limit: int | None = 50,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        return owner._wrap_response(
            owner._list_evaluation_suite_summaries(
                app_id=app_id,
                app_id_pattern=app_id_pattern,
                group_id=group_id,
                search=search,
                since=since,
                until=until,
                limit=limit,
            )
        )

    @app.get("/evaluations/suites/{suite_id}")
    async def get_evaluation_suite(
        suite_id: str,
        app_id: str | None = None,
        app_id_pattern: str | None = None,
        group_id: str | None = None,
        search: str | None = None,
        since: int | None = None,
        until: int | None = None,
        authorization: OptionalStrHeader = None,
        x_api_key: OptionalStrHeader = None,
        api_key: OptionalStrQuery = None,
    ):
        owner._resolve_http_token(authorization, x_api_key, api_key)
        report = owner._get_evaluation_suite_report(
            suite_id,
            app_id=app_id,
            app_id_pattern=app_id_pattern,
            group_id=group_id,
            search=search,
            since=since,
            until=until,
        )
        if report is None:
            raise HTTPException(
                status_code=404,
                detail=f"Evaluation suite '{ suite_id }' not found.",
            )
        return owner._wrap_response(report)