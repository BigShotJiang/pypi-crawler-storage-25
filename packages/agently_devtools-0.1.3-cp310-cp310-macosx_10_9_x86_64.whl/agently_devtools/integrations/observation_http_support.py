# Copyright 2023-2026 AgentEra(Agently.Tech)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
from pathlib import Path
from typing import Sequence


def coerce_bool(value: object, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"true", "1", "yes", "on"}:
            return True
        if normalized in {"false", "0", "no", "off"}:
            return False
    return default


def normalize_api_keys(api_keys: str | Sequence[str] | None) -> set[str]:
    if api_keys is None:
        return set()
    if isinstance(api_keys, str):
        return {api_keys} if api_keys else set()
    return {key for key in api_keys if isinstance(key, str) and key}


def extract_bearer_token(authorization: str | None) -> str | None:
    if authorization is None:
        return None
    parts = authorization.strip().split(" ", 1)
    if len(parts) == 2 and parts[0].lower() == "bearer" and parts[1]:
        return parts[1]
    return authorization.strip() or None


def normalize_cors_origins(value: object) -> list[str]:
    if isinstance(value, str):
        if not value:
            return []
        if value == "*":
            return ["*"]
        return [item.strip() for item in value.split(",") if item.strip()]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [str(item).strip() for item in value if str(item).strip()]
    return []


def resolve_web_dist_dir(current_file: str | Path) -> Path | None:
    resolved_file = Path(current_file).resolve()
    candidates = [
        resolved_file.parents[4] / "apps" / "web" / "dist",
        resolved_file.parents[1] / "static",
    ]
    for candidate in candidates:
        if (
            candidate.exists()
            and candidate.is_dir()
            and (candidate / "index.html").exists()
        ):
            return candidate
    return None


def inject_web_config(
    html: str,
    *,
    endpoint: str,
    api_key: str,
    route_prefix: str,
):
    config_script = (
        "<script>"
        f'window.__AGENTLY_DEVTOOLS_CONFIG__ = {json.dumps({"endpoint": endpoint, "apiKey": api_key, "routePrefix": route_prefix}, ensure_ascii=False)};'
        "</script>"
    )
    if "</head>" in html:
        return html.replace("</head>", f"{config_script}</head>", 1)
    return f"{config_script}{html}"