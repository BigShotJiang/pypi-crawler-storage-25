import argparse
import asyncio
import webbrowser

from ._framework_compat import get_agently_compatibility_status
from .app import (
    DEFAULT_HOST,
    DEFAULT_LOCAL_API_KEY,
    DEFAULT_PORT,
    create_local_observation_app,
    emit_startup_run,
)
from .bridge import _normalize_observation_path, _route_prefix_from_path


def build_parser():
    parser = argparse.ArgumentParser(prog="agently-devtools")
    subparsers = parser.add_subparsers(dest="command")

    start_parser = subparsers.add_parser(
        "start", help="Launch local observation API and web console"
    )
    start_parser.add_argument("--host", default=DEFAULT_HOST, help="Host to bind")
    start_parser.add_argument(
        "--port", type=int, default=DEFAULT_PORT, help="Port to bind"
    )
    start_parser.add_argument(
        "--api-key",
        default=DEFAULT_LOCAL_API_KEY,
        help="API key for local observation API",
    )
    start_parser.add_argument(
        "--route-prefix",
        default="/observation",
        help="Route prefix for observation API",
    )
    start_parser.add_argument("--path", default=None, help="Observation API path")
    start_parser.add_argument(
        "--no-open", action="store_true", help="Do not open browser automatically"
    )

    init_parser = subparsers.add_parser("init", help="Scaffold a new Agently project")
    init_parser.add_argument(
        "project_name",
        nargs="?",
        default=None,
        help="Project folder name to create under current directory (default: create ./agently_project if omitted)",
    )
    init_parser.add_argument(
        "--path",
        default=None,
        help="Explicit project path (fallback if project_name not provided)",
    )
    init_parser.add_argument(
        "--template",
        default="default",
        choices=["default", "playground"],
        help="Template to use",
    )
    init_parser.add_argument(
        "--language", default="en", choices=["en", "zh"], help="Template language"
    )
    init_parser.add_argument(
        "--force", action="store_true", help="Overwrite existing files"
    )

    # keep old-style `help` subcommand for compatibility
    subparsers.add_parser("help", help="Show this help message")

    parser.set_defaults(
        command="start",
        host=DEFAULT_HOST,
        port=DEFAULT_PORT,
        api_key=DEFAULT_LOCAL_API_KEY,
        route_prefix="/observation",
        path=None,
        no_open=False,
    )
    return parser


def _run_start(args):
    route_prefix = (
        _route_prefix_from_path(args.path)
        if args.path is not None
        else args.route_prefix
    )
    ingest_path = _normalize_observation_path(args.path or route_prefix)

    from uvicorn import run

    app, _bridge = create_local_observation_app(
        api_key=args.api_key,
        route_prefix=route_prefix,
    )
    asyncio.run(emit_startup_run())

    url = f"http://{args.host}:{args.port}/"
    print(f"Agently DevTools: {url}")
    print(f"Observation API: {url.rstrip('/')}{route_prefix}/runs")
    print(f"Observation ingest: {url.rstrip('/')}{ingest_path}")
    print(f"API key: {args.api_key if args.api_key else 'disabled (local mode)'}")
    compatibility = get_agently_compatibility_status()
    if not compatibility.compatible:
        print(
            "Framework compatibility warning: "
            f"{compatibility.message} Upgrade with `{compatibility.upgrade_command}`."
        )

    if not args.no_open:
        webbrowser.open(url)

    run(app, host=args.host, port=args.port)
    return 0


def _run_init(args):
    from .project_init import init_project

    if getattr(args, "rollback", False):
        print(
            "Rollback via CLI has been removed; just delete project folder if needed, or use project_init.rollback_project() directly."
        )
        return 0

    from pathlib import Path

    if args.project_name:
        project_path = Path(args.project_name)
    elif args.path:
        project_path = Path(args.path)
    else:
        project_path = Path("agently_project")
        print(
            "No project name provided; creating project under current directory: "
            f"{(Path.cwd() / project_path).resolve()}"
        )

    if not project_path.is_absolute():
        project_path = Path.cwd() / project_path

    # If the requested path is the current directory, create a named project folder instead.
    if project_path.resolve() == Path.cwd().resolve():
        project_path = Path.cwd() / "agently_project"
        print(
            "Project path resolves to current directory; creating project folder instead: "
            f"{project_path.resolve()}"
        )

    result = init_project(
        path=project_path,
        template=args.template,
        overwrite=args.force,
        language=args.language,
    )
    print(f"Project successfully initialized: {project_path}")
    manifest = result.get("manifest")
    if manifest is not None:
        print(f"Manifest written: {manifest}")
    return 0


def main():
    parser = build_parser()
    args = parser.parse_args()

    command = args.command or "start"

    if command == "help":
        parser.print_help()
        return 0

    if command == "init":
        return _run_init(args)

    return _run_start(args)


if __name__ == "__main__":
    raise SystemExit(main())
