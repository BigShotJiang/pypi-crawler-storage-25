from __future__ import annotations

from importlib import import_module
from types import ModuleType
from typing import Any


def load_rust_core_module() -> ModuleType | None:
    try:
        module = import_module("agently_devtools_rust")
    except ImportError:
        return None
    return module


def rust_observation_store_is_ready() -> bool:
    module = load_rust_core_module()
    if module is None:
        return False
    checker = getattr(module, "observation_store_ready", None)
    if not callable(checker):
        return False
    try:
        return bool(checker())
    except Exception:
        return False


def build_rust_observation_store(*, max_events: int) -> Any | None:
    module = load_rust_core_module()
    if module is None or not rust_observation_store_is_ready():
        return None
    store_class = getattr(module, "RustObservationStore", None)
    if store_class is None:
        return None
    try:
        return store_class(max_events=max_events)
    except Exception:
        return None
