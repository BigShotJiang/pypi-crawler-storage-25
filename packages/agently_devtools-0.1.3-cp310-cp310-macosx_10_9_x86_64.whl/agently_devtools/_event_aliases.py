# Copyright 2023-2026 AgentEra(Agently.Tech)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from collections.abc import Iterable


_TRIGGERFLOW_WORKFLOW_SUFFIXES = frozenset(
    {
        "definition_declared",
        "execution_started",
        "execution_completed",
        "execution_failed",
        "execution_sealed",
        "execution_unsealed",
        "execution_closed",
        "execution_resumed",
        "interrupt_raised",
        "stream_item_emitted",
        "stream_item_rejected",
        "stream_closed",
        "event_rejected",
        "continue_rejected",
        "unseal_rejected",
        "pending_tasks_cancelled",
        "auto_close_timeout",
        "result_set",
    }
)

_TRIGGERFLOW_NATIVE_SUFFIXES = frozenset(
    {
        "signal",
        "handler_dispatch",
        "annotation",
    }
)

_TRIGGERFLOW_ALL_SUFFIXES = _TRIGGERFLOW_WORKFLOW_SUFFIXES | _TRIGGERFLOW_NATIVE_SUFFIXES


def normalize_triggerflow_event_type(event_type: str | None):
    if not isinstance(event_type, str) or not event_type:
        return event_type
    if event_type.startswith("triggerflow."):
        suffix = event_type[len("triggerflow.") :]
        return event_type if suffix in _TRIGGERFLOW_ALL_SUFFIXES else event_type
    if event_type.startswith("workflow."):
        suffix = event_type[len("workflow.") :]
        if suffix in _TRIGGERFLOW_WORKFLOW_SUFFIXES:
            return f"triggerflow.{ suffix }"
        return event_type
    if event_type.startswith("trigger_flow."):
        suffix = event_type[len("trigger_flow.") :]
        if suffix in _TRIGGERFLOW_NATIVE_SUFFIXES:
            return f"triggerflow.{ suffix }"
        return event_type
    return event_type


def get_triggerflow_event_aliases(event_type: str | None):
    if not isinstance(event_type, str) or not event_type:
        return set()
    normalized = normalize_triggerflow_event_type(event_type)
    aliases = {event_type}
    if not isinstance(normalized, str) or not normalized.startswith("triggerflow."):
        return aliases
    suffix = normalized[len("triggerflow.") :]
    aliases.add(normalized)
    if suffix in _TRIGGERFLOW_WORKFLOW_SUFFIXES:
        aliases.add(f"workflow.{ suffix }")
    if suffix in _TRIGGERFLOW_NATIVE_SUFFIXES:
        aliases.add(f"trigger_flow.{ suffix }")
    return aliases


def matches_triggerflow_event_type(event_type: str | None, expected_event_types: Iterable[str] | None):
    if expected_event_types is None:
        return True
    aliases = get_triggerflow_event_aliases(event_type)
    return any(expected in aliases for expected in expected_event_types)


def expand_triggerflow_event_types(event_types: Iterable[str] | None):
    if event_types is None:
        return None
    expanded: set[str] = set()
    for event_type in event_types:
        expanded.update(get_triggerflow_event_aliases(event_type))
    return sorted(expanded)


def expand_triggerflow_event_family(event_family: str | None):
    if not isinstance(event_family, str) or not event_family:
        return []
    if event_family in {"triggerflow", "workflow", "trigger_flow"}:
        return ["triggerflow", "workflow", "trigger_flow"]
    return [event_family]
