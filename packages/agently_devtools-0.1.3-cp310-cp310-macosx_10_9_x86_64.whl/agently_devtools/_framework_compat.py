from __future__ import annotations

from dataclasses import asdict, dataclass
from importlib import metadata
from pathlib import Path
import re
from typing import Any

from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.version import InvalidVersion, Version


DEFAULT_AGENTLY_SPECIFIER = ">=4.1.0.2,<4.2.0"
DEFAULT_AGENTLY_MIN_VERSION = "4.1.0.2"
TRIGGERFLOW_COMPATIBILITY_REASON = (
    "TriggerFlow `triggerflow.*` runtime events and Mermaid definition snapshots require a newer `agently`."
)


@dataclass(frozen=True)
class FrameworkCompatibilityStatus:
    package_name: str
    installed_version: str | None
    required_specifier: str
    minimum_version: str
    compatible: bool
    level: str
    reason: str | None
    message: str
    upgrade_command: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def _resolve_agently_requirement_specifier() -> str:
    pyproject_specifier = _resolve_agently_requirement_from_pyproject()
    if pyproject_specifier:
        return pyproject_specifier

    try:
        requirements = metadata.requires("agently-devtools") or []
    except metadata.PackageNotFoundError:
        return DEFAULT_AGENTLY_SPECIFIER

    for entry in requirements:
        try:
            requirement = Requirement(entry)
        except Exception:
            continue
        if requirement.name == "agently":
            specifier = str(requirement.specifier).strip()
            if specifier:
                return specifier
    return DEFAULT_AGENTLY_SPECIFIER


def _resolve_agently_requirement_from_pyproject() -> str | None:
    pyproject_path = Path(__file__).resolve().parents[1] / "pyproject.toml"
    if not pyproject_path.exists():
        return None
    try:
        content = pyproject_path.read_text(encoding="utf-8")
    except OSError:
        return None
    match = re.search(r'["\']agently(?=[<>=!~])([^"\']+)["\']', content)
    if not match:
        return None
    specifier = match.group(1).strip()
    return specifier or None


def _resolve_installed_version(package_name: str) -> str | None:
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        return None


def _resolve_minimum_version(specifier: str) -> str:
    minimum = DEFAULT_AGENTLY_MIN_VERSION
    try:
        parsed = SpecifierSet(specifier)
    except Exception:
        return minimum
    for item in parsed:
        if item.operator == ">=":
            if Version(item.version) > Version(minimum):
                minimum = item.version
    return minimum


def get_agently_compatibility_status() -> FrameworkCompatibilityStatus:
    package_name = "agently"
    installed_version = _resolve_installed_version(package_name)
    required_specifier = _resolve_agently_requirement_specifier()
    minimum_version = _resolve_minimum_version(required_specifier)
    upgrade_command = f'pip install -U "agently{required_specifier}"'

    if installed_version is None:
        return FrameworkCompatibilityStatus(
            package_name=package_name,
            installed_version=None,
            required_specifier=required_specifier,
            minimum_version=minimum_version,
            compatible=False,
            level="error",
            reason="missing",
            message=(
                f"`agently` is not installed. Agently DevTools requires `{package_name}{required_specifier}`."
            ),
            upgrade_command=upgrade_command,
        )

    try:
        compatible = Version(installed_version) in SpecifierSet(required_specifier)
    except (InvalidVersion, Exception):
        compatible = False

    if compatible:
        return FrameworkCompatibilityStatus(
            package_name=package_name,
            installed_version=installed_version,
            required_specifier=required_specifier,
            minimum_version=minimum_version,
            compatible=True,
            level="info",
            reason=None,
            message=f"`agently` {installed_version} satisfies `{required_specifier}`.",
            upgrade_command=upgrade_command,
        )

    return FrameworkCompatibilityStatus(
        package_name=package_name,
        installed_version=installed_version,
        required_specifier=required_specifier,
        minimum_version=minimum_version,
        compatible=False,
        level="warning",
        reason="outdated",
        message=(
            f"`agently` {installed_version} is below the required range `{required_specifier}`. "
            f"{TRIGGERFLOW_COMPATIBILITY_REASON}"
        ),
        upgrade_command=upgrade_command,
    )
