import json


def render_observation_console(
    *,
    route_prefix: str = "/observation",
    default_api_key: str = "",
):
    route_prefix_json = json.dumps(route_prefix.rstrip("/") or "/observation")
    api_key_json = json.dumps(default_api_key)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Agently DevTools</title>
  <style>
    :root {{
      --bg: #f2efe8;
      --panel: rgba(255,255,255,0.82);
      --line: rgba(30, 32, 37, 0.12);
      --text: #1d2128;
      --muted: #6a727f;
      --accent: #0e7a6d;
      --accent-soft: rgba(14,122,109,0.12);
      --danger: #c9493d;
      --shadow: 0 20px 70px rgba(22, 28, 45, 0.08);
      --radius: 22px;
      font-family: "Iowan Old Style", "Palatino Linotype", "Book Antiqua", Palatino, Georgia, serif;
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      color: var(--text);
      background:
        radial-gradient(circle at top left, rgba(14,122,109,0.14), transparent 28%),
        radial-gradient(circle at top right, rgba(204,116,55,0.16), transparent 22%),
        linear-gradient(180deg, #f6f3eb 0%, var(--bg) 100%);
    }}
    .shell {{
      min-height: 100vh;
      padding: 28px;
      display: grid;
      grid-template-columns: 340px 1fr;
      gap: 20px;
    }}
    .panel {{
      background: var(--panel);
      border: 1px solid var(--line);
      border-radius: var(--radius);
      box-shadow: var(--shadow);
      backdrop-filter: blur(14px);
    }}
    .sidebar {{
      padding: 18px;
      display: flex;
      flex-direction: column;
      gap: 16px;
      min-height: calc(100vh - 56px);
    }}
    .main {{
      display: grid;
      grid-template-rows: auto auto 1fr;
      gap: 20px;
    }}
    .hero {{
      padding: 22px 24px;
    }}
    .hero h1 {{
      margin: 0 0 8px;
      font-size: 34px;
      line-height: 1.05;
      letter-spacing: -0.03em;
    }}
    .hero p {{
      margin: 0;
      color: var(--muted);
      font-size: 15px;
      line-height: 1.5;
    }}
    .grid {{
      display: grid;
      grid-template-columns: 1.1fr 1fr;
      gap: 20px;
      min-height: 0;
    }}
    .card {{
      padding: 18px;
      min-height: 0;
      overflow: hidden;
    }}
    .section-title {{
      margin: 0 0 14px;
      font-size: 15px;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: var(--muted);
    }}
    .field {{
      display: flex;
      flex-direction: column;
      gap: 8px;
    }}
    label {{
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: var(--muted);
    }}
    input, button, select {{
      font: inherit;
    }}
    input {{
      width: 100%;
      border: 1px solid var(--line);
      border-radius: 14px;
      padding: 12px 14px;
      background: rgba(255,255,255,0.9);
      color: var(--text);
    }}
    button {{
      border: none;
      border-radius: 999px;
      padding: 11px 16px;
      background: var(--accent);
      color: white;
      cursor: pointer;
      transition: transform .15s ease, opacity .15s ease;
    }}
    button.secondary {{
      background: rgba(29,33,40,0.08);
      color: var(--text);
    }}
    button:hover {{ transform: translateY(-1px); }}
    button:disabled {{ opacity: .5; cursor: not-allowed; transform: none; }}
    .row {{
      display: flex;
      gap: 10px;
      align-items: center;
      flex-wrap: wrap;
    }}
    .status {{
      font-size: 13px;
      color: var(--muted);
      padding: 8px 12px;
      background: rgba(29,33,40,0.04);
      border-radius: 999px;
    }}
    .snippet {{
      margin-top: 14px;
      padding: 14px;
      border-radius: 16px;
      background: #1b1f27;
      color: #edf2f7;
      font-family: "SFMono-Regular", Menlo, Consolas, monospace;
      font-size: 12px;
      line-height: 1.6;
      white-space: pre-wrap;
      overflow: auto;
    }}
    .runs, .events {{
      overflow: auto;
      display: flex;
      flex-direction: column;
      gap: 10px;
      min-height: 0;
      padding-right: 6px;
    }}
    .run-item, .event-item {{
      border: 1px solid var(--line);
      border-radius: 16px;
      padding: 12px 14px;
      background: rgba(255,255,255,0.72);
    }}
    .run-item {{
      cursor: pointer;
      transition: border-color .15s ease, background .15s ease;
    }}
    .run-item:hover, .run-item.active {{
      border-color: rgba(14,122,109,0.4);
      background: var(--accent-soft);
    }}
    .run-title, .event-title {{
      display: flex;
      justify-content: space-between;
      gap: 10px;
      align-items: center;
      font-size: 14px;
      font-weight: 700;
    }}
    .pill {{
      border-radius: 999px;
      padding: 4px 9px;
      font-size: 11px;
      text-transform: uppercase;
      letter-spacing: .08em;
      background: rgba(29,33,40,0.08);
      color: var(--muted);
      white-space: nowrap;
    }}
    .pill.running {{ background: rgba(14,122,109,0.14); color: var(--accent); }}
    .pill.completed {{ background: rgba(14,122,109,0.14); color: var(--accent); }}
    .pill.failed {{ background: rgba(201,73,61,0.14); color: var(--danger); }}
    .pill.waiting {{ background: rgba(204,116,55,0.14); color: #b6601a; }}
    .meta {{
      margin-top: 8px;
      color: var(--muted);
      font-size: 12px;
      line-height: 1.5;
      word-break: break-word;
    }}
    .detail-grid {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      min-height: 0;
    }}
    .detail-block {{
      border: 1px solid var(--line);
      border-radius: 16px;
      padding: 14px;
      background: rgba(255,255,255,0.74);
      min-height: 0;
      overflow: auto;
    }}
    .detail-block pre {{
      margin: 0;
      white-space: pre-wrap;
      word-break: break-word;
      font-size: 12px;
      line-height: 1.55;
      color: #29313d;
      font-family: "SFMono-Regular", Menlo, Consolas, monospace;
    }}
    .empty {{
      color: var(--muted);
      font-size: 14px;
      padding: 14px;
      border: 1px dashed var(--line);
      border-radius: 16px;
      background: rgba(255,255,255,0.54);
    }}
    @media (max-width: 1080px) {{
      .shell {{
        grid-template-columns: 1fr;
      }}
      .sidebar {{
        min-height: auto;
      }}
      .grid, .detail-grid {{
        grid-template-columns: 1fr;
      }}
    }}
  </style>
</head>
<body>
  <div class="shell">
    <aside class="panel sidebar">
      <div>
        <div class="section-title">Connection</div>
        <div class="field">
          <label for="api-key">API Key</label>
          <input id="api-key" type="password" placeholder="Enter API key" />
        </div>
        <div class="row" style="margin-top:12px;">
          <button id="connect-btn">Connect</button>
          <button id="refresh-btn" class="secondary">Refresh</button>
          <span id="conn-status" class="status">idle</span>
        </div>
      </div>
      <div>
        <div class="section-title">Local Setup</div>
        <div class="snippet" id="setup-snippet"></div>
      </div>
      <div style="display:flex; flex-direction:column; min-height:0;">
        <div class="section-title">Runs</div>
        <div id="runs" class="runs"></div>
      </div>
    </aside>
    <main class="main">
      <section class="panel hero">
        <h1>Agently DevTools</h1>
        <p>Local-first observation service and UI for Agently runtime events. This page connects to the same FastAPI app that serves the observation API.</p>
      </section>
      <section class="grid">
        <section class="panel card">
          <div class="section-title">Selected Run</div>
          <div id="run-summary" class="empty">Select a run from the left to inspect its lineage and event timeline.</div>
          <div class="detail-grid" style="margin-top:14px;">
            <div class="detail-block">
              <div class="section-title">Run Tree</div>
              <pre id="run-tree">No run selected.</pre>
            </div>
            <div class="detail-block">
              <div class="section-title">Live Feed</div>
              <div id="live-feed" class="events"></div>
            </div>
          </div>
        </section>
        <section class="panel card" style="display:flex; flex-direction:column;">
          <div class="section-title">Events</div>
          <div id="run-events" class="events"></div>
        </section>
      </section>
    </main>
  </div>
  <script>
    const ROUTE_PREFIX = {route_prefix_json};
    const DEFAULT_API_KEY = {api_key_json};
    const state = {{
      apiKey: localStorage.getItem("agently-devtools-api-key") || DEFAULT_API_KEY,
      runs: [],
      selectedRunId: null,
      stream: null,
    }};

    const apiKeyInput = document.getElementById("api-key");
    const connectButton = document.getElementById("connect-btn");
    const refreshButton = document.getElementById("refresh-btn");
    const statusNode = document.getElementById("conn-status");
    const runsNode = document.getElementById("runs");
    const summaryNode = document.getElementById("run-summary");
    const treeNode = document.getElementById("run-tree");
    const eventsNode = document.getElementById("run-events");
    const liveFeedNode = document.getElementById("live-feed");
    const snippetNode = document.getElementById("setup-snippet");

    apiKeyInput.value = state.apiKey;

    function escapeHtml(text) {{
      return String(text ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;");
    }}

    function formatTime(ts) {{
      if (!ts) return "n/a";
      return new Date(ts).toLocaleString();
    }}

    function authHeaders() {{
      return state.apiKey ? {{ Authorization: `Bearer ${{state.apiKey}}` }} : {{}};
    }}

    function setStatus(text, kind = "idle") {{
      statusNode.textContent = text;
      statusNode.style.color = kind === "error" ? "var(--danger)" : "var(--muted)";
      statusNode.style.background = kind === "error" ? "rgba(201,73,61,0.1)" : "rgba(29,33,40,0.04)";
    }}

    function updateSetupSnippet() {{
      const origin = window.location.origin;
      const lines = [
        'from agently import Agently',
        'from agently_devtools import ObservationBridge',
        '',
      ];
      if (state.apiKey || DEFAULT_API_KEY) {{
        lines.push(`Agently.set_api_key("${{state.apiKey || DEFAULT_API_KEY}}")`, '');
      }}
      lines.push(
        'bridge = ObservationBridge(',
        `    host="${{window.location.hostname}}",`,
        `    port=${{window.location.port || (window.location.protocol === "https:" ? "443" : "80")}},`,
        `    path="${{ROUTE_PREFIX}}/ingest",`,
        ')',
        'bridge.register(Agently)',
      );
      snippetNode.textContent = lines.join("\\n");
    }}

    async function fetchJson(path) {{
      const response = await fetch(path, {{ headers: authHeaders() }});
      if (!response.ok) {{
        throw new Error(`HTTP ${{response.status}}`);
      }}
      return await response.json();
    }}

    function renderRuns() {{
      if (!state.runs.length) {{
        runsNode.innerHTML = '<div class="empty">No runs yet. Send runtime events to the local ingest endpoint.</div>';
        return;
      }}
      runsNode.innerHTML = state.runs.map((run) => `
        <article class="run-item ${{run.run_id === state.selectedRunId ? "active" : ""}}" data-run-id="${{escapeHtml(run.run_id)}}">
          <div class="run-title">
            <span>${{escapeHtml(run.agent_name || run.run_kind || run.run_id)}}</span>
            <span class="pill ${{escapeHtml(run.status)}}">${{escapeHtml(run.status)}}</span>
          </div>
          <div class="meta">
            <div><strong>kind:</strong> ${{escapeHtml(run.run_kind)}}</div>
            <div><strong>updated:</strong> ${{escapeHtml(formatTime(run.updated_at))}}</div>
            <div><strong>event:</strong> ${{escapeHtml(run.latest_event_type || "n/a")}}</div>
          </div>
        </article>
      `).join("");
      for (const node of runsNode.querySelectorAll(".run-item")) {{
        node.addEventListener("click", () => {{
          state.selectedRunId = node.dataset.runId;
          renderRuns();
          loadSelectedRun();
        }});
      }}
    }}

    function renderEventList(targetNode, events, emptyText) {{
      if (!events.length) {{
        targetNode.innerHTML = `<div class="empty">${{escapeHtml(emptyText)}}</div>`;
        return;
      }}
      targetNode.innerHTML = events.map((event) => `
        <article class="event-item">
          <div class="event-title">
            <span>${{escapeHtml(event.event_type)}}</span>
            <span class="pill">${{escapeHtml(event.level || "INFO")}}</span>
          </div>
          <div class="meta">
            <div><strong>source:</strong> ${{escapeHtml(event.source || "unknown")}}</div>
            <div><strong>time:</strong> ${{escapeHtml(formatTime(event.timestamp))}}</div>
            <div><strong>message:</strong> ${{escapeHtml(event.message || "")}}</div>
          </div>
        </article>
      `).join("");
    }}

    async function loadRuns() {{
      const payload = await fetchJson(`${{ROUTE_PREFIX}}/runs?limit=100`);
      state.runs = payload.data || [];
      if (!state.selectedRunId && state.runs.length) {{
        state.selectedRunId = state.runs[0].run_id;
      }}
      renderRuns();
      await loadSelectedRun();
    }}

    async function loadSelectedRun() {{
      if (!state.selectedRunId) {{
        summaryNode.innerHTML = 'Select a run from the left to inspect its lineage and event timeline.';
        treeNode.textContent = 'No run selected.';
        renderEventList(eventsNode, [], 'No events for the selected run.');
        return;
      }}

      const [runPayload, treePayload, eventsPayload] = await Promise.all([
        fetchJson(`${{ROUTE_PREFIX}}/runs/${{encodeURIComponent(state.selectedRunId)}}`),
        fetchJson(`${{ROUTE_PREFIX}}/runs/${{encodeURIComponent(state.selectedRunId)}}/tree`),
        fetchJson(`${{ROUTE_PREFIX}}/runs/${{encodeURIComponent(state.selectedRunId)}}/events?include_descendants=true&limit=200`),
      ]);
      const run = runPayload.data;
      summaryNode.innerHTML = `
        <div class="run-title">
          <span>${{escapeHtml(run.agent_name || run.run_kind || run.run_id)}}</span>
          <span class="pill ${{escapeHtml(run.status)}}">${{escapeHtml(run.status)}}</span>
        </div>
        <div class="meta">
          <div><strong>run_id:</strong> ${{escapeHtml(run.run_id)}}</div>
          <div><strong>root_run_id:</strong> ${{escapeHtml(run.root_run_id)}}</div>
          <div><strong>parent_run_id:</strong> ${{escapeHtml(run.parent_run_id || "n/a")}}</div>
          <div><strong>session_id:</strong> ${{escapeHtml(run.session_id || "n/a")}}</div>
          <div><strong>updated:</strong> ${{escapeHtml(formatTime(run.updated_at))}}</div>
        </div>
      `;
      treeNode.textContent = JSON.stringify(treePayload.data, null, 2);
      renderEventList(eventsNode, eventsPayload.data || [], 'No events for the selected run.');
    }}

    function prependLiveEvent(event) {{
      const wrapper = document.createElement("article");
      wrapper.className = "event-item";
      wrapper.innerHTML = `
        <div class="event-title">
          <span>${{escapeHtml(event.event_type)}}</span>
          <span class="pill">${{escapeHtml(event.level || "INFO")}}</span>
        </div>
        <div class="meta">
          <div><strong>source:</strong> ${{escapeHtml(event.source || "unknown")}}</div>
          <div><strong>time:</strong> ${{escapeHtml(formatTime(event.timestamp))}}</div>
          <div><strong>message:</strong> ${{escapeHtml(event.message || "")}}</div>
        </div>
      `;
      liveFeedNode.prepend(wrapper);
      while (liveFeedNode.children.length > 30) {{
        liveFeedNode.removeChild(liveFeedNode.lastChild);
      }}
    }}

    function connectStream() {{
      if (state.stream) {{
        state.stream.close();
      }}
      if (!state.apiKey) {{
        return;
      }}
      const url = new URL(`${{window.location.origin}}${{ROUTE_PREFIX}}/stream`);
      url.searchParams.set("api_key", state.apiKey);
      state.stream = new EventSource(url);
      state.stream.onopen = () => setStatus("connected", "ok");
      state.stream.onerror = () => setStatus("stream disconnected", "error");
      state.stream.onmessage = async (message) => {{
        const event = JSON.parse(message.data);
        prependLiveEvent(event);
        if (event.run && (!state.selectedRunId || event.run.run_id === state.selectedRunId || event.run.root_run_id === state.selectedRunId)) {{
          await loadRuns();
        }}
      }};
    }}

    async function connect() {{
      state.apiKey = apiKeyInput.value.trim();
      localStorage.setItem("agently-devtools-api-key", state.apiKey);
      updateSetupSnippet();
      setStatus("connecting...");
      try {{
        await loadRuns();
        connectStream();
        setStatus("connected", "ok");
      }} catch (error) {{
        console.error(error);
        setStatus(`connection failed: ${{error.message}}`, "error");
      }}
    }}

    connectButton.addEventListener("click", connect);
    refreshButton.addEventListener("click", async () => {{
      try {{
        await loadRuns();
      }} catch (error) {{
        console.error(error);
        setStatus(`refresh failed: ${{error.message}}`, "error");
      }}
    }});

    updateSetupSnippet();
    renderEventList(liveFeedNode, [], 'Live events will appear here after connection.');
    connect();
  </script>
</body>
</html>
"""
