# Copyright 2023-2026 AgentEra(Agently.Tech)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import json
import re
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Sequence

from pydantic import BaseModel

from agently_devtools._agently_compat import RuntimeEvent
from agently_devtools._event_aliases import expand_triggerflow_event_family, expand_triggerflow_event_types
from agently.utils import DataFormatter

from .Query import LogEventQuery

if TYPE_CHECKING:
    from agently.utils import Settings


def _coerce_int_setting(value: object, default: int) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    if isinstance(value, str):
        try:
            return int(value)
        except ValueError:
            return default
    return default


class RuntimeLogStats(BaseModel):
    enabled: bool
    root_path: str
    index_path: str
    segment_count: int
    event_count: int
    newest_timestamp: int | None = None


@dataclass
class _SegmentState:
    name: str
    path: Path
    event_count: int
    line_number: int


class RuntimeLogService:
    def __init__(self, settings: "Settings"):
        self.settings = settings
        self._enabled = bool(self.settings.get("logs.enabled", True))
        configured_root = self.settings.get("logs.storage.path", str(Path.home() / ".agently-devtools" / "logs"))
        self.root_path = Path(str(configured_root)).expanduser()
        self.segment_limit = _coerce_int_setting(self.settings.get("logs.storage.segment_event_limit", 1000), 1000)
        self.index_path = self.root_path / "index.sqlite3"
        self.segments_path = self.root_path / "segments"
        self._lock = asyncio.Lock()
        self._segment: _SegmentState | None = None
        self._sequence = 0
        if self._enabled:
            self._initialize_storage()

    def _connect(self):
        connection = sqlite3.connect(self.index_path)
        connection.row_factory = sqlite3.Row
        return connection

    def _initialize_storage(self):
        self.root_path.mkdir(parents=True, exist_ok=True)
        self.segments_path.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS log_events (
                    event_id TEXT PRIMARY KEY,
                    timestamp INTEGER NOT NULL,
                    event_type TEXT NOT NULL,
                    source TEXT NOT NULL,
                    level TEXT NOT NULL,
                    message TEXT,
                    run_id TEXT,
                    root_run_id TEXT,
                    parent_run_id TEXT,
                    run_kind TEXT,
                    agent_name TEXT,
                    session_id TEXT,
                    response_id TEXT,
                    execution_id TEXT,
                    app_id TEXT,
                    group_id TEXT,
                    flow_name TEXT,
                    environment TEXT,
                    segment_name TEXT NOT NULL,
                    segment_path TEXT NOT NULL,
                    line_number INTEGER NOT NULL,
                    search_text TEXT NOT NULL,
                    event_json TEXT NOT NULL
                )
                """
            )
            indexes = [
                "CREATE INDEX IF NOT EXISTS idx_log_events_timestamp ON log_events(timestamp DESC)",
                "CREATE INDEX IF NOT EXISTS idx_log_events_run_id ON log_events(run_id)",
                "CREATE INDEX IF NOT EXISTS idx_log_events_root_run_id ON log_events(root_run_id)",
                "CREATE INDEX IF NOT EXISTS idx_log_events_parent_run_id ON log_events(parent_run_id)",
                "CREATE INDEX IF NOT EXISTS idx_log_events_run_kind ON log_events(run_kind)",
                "CREATE INDEX IF NOT EXISTS idx_log_events_event_type ON log_events(event_type)",
                "CREATE INDEX IF NOT EXISTS idx_log_events_app_id ON log_events(app_id)",
                "CREATE INDEX IF NOT EXISTS idx_log_events_group_id ON log_events(group_id)",
                "CREATE INDEX IF NOT EXISTS idx_log_events_flow_name ON log_events(flow_name)",
            ]
            table_columns = {
                str(row["name"])
                for row in connection.execute("PRAGMA table_info(log_events)").fetchall()
            }
            self._ensure_log_event_columns(
                connection,
                table_columns,
                {
                    "app_id": "TEXT",
                    "group_id": "TEXT",
                    "flow_name": "TEXT",
                    "environment": "TEXT",
                },
            )
            if "project_id" in table_columns:
                connection.execute(
                    """
                    UPDATE log_events
                    SET group_id = COALESCE(group_id, project_id)
                    WHERE project_id IS NOT NULL
                    """
                )
            for statement in indexes:
                connection.execute(statement)
            state = connection.execute(
                """
                SELECT segment_name, segment_path, COUNT(*) AS event_count, MAX(line_number) AS line_number
                FROM log_events
                GROUP BY segment_name, segment_path
                ORDER BY MAX(timestamp) DESC
                LIMIT 1
                """
            ).fetchone()
            latest_segment_name = None
            if state is not None:
                latest_segment_name = str(state["segment_name"])
                self._segment = _SegmentState(
                    name=latest_segment_name,
                    path=Path(str(state["segment_path"])),
                    event_count=int(state["event_count"] or 0),
                    line_number=int(state["line_number"] or 0),
                )
            latest_sequence = connection.execute(
                "SELECT MAX(CAST(substr(segment_name, -4) AS INTEGER)) AS sequence FROM log_events"
            ).fetchone()
            if latest_sequence is not None and latest_sequence["sequence"] is not None:
                self._sequence = int(latest_sequence["sequence"])
            if self._segment is not None and self._segment.event_count >= self.segment_limit:
                self._segment = None

    @staticmethod
    def _ensure_log_event_columns(
        connection: sqlite3.Connection,
        table_columns: set[str],
        required_columns: dict[str, str],
    ):
        for column_name, column_type in required_columns.items():
            if column_name in table_columns:
                continue
            connection.execute(f"ALTER TABLE log_events ADD COLUMN {column_name} {column_type}")
            table_columns.add(column_name)

    def _next_segment(self):
        self._sequence += 1
        segment_name = f"{int(time.time() * 1000):013d}-{self._sequence:04d}"
        segment_path = self.segments_path / f"{segment_name}.jsonl"
        self._segment = _SegmentState(
            name=segment_name,
            path=segment_path,
            event_count=0,
            line_number=0,
        )
        return self._segment

    @staticmethod
    def _serialize_event(event: RuntimeEvent):
        return DataFormatter.sanitize(event.model_dump(mode="json"))

    @staticmethod
    def _build_search_text(serialized_event: dict[str, Any]):
        parts: list[str] = []
        for key in ("event_id", "event_type", "source", "level", "message"):
            value = serialized_event.get(key)
            if value:
                parts.append(str(value))
        run = serialized_event.get("run")
        if isinstance(run, dict):
            for key in (
                "run_id",
                "root_run_id",
                "parent_run_id",
                "run_kind",
                "agent_name",
                "session_id",
                "response_id",
                "execution_id",
            ):
                value = run.get(key)
                if value:
                    parts.append(str(value))
            meta = run.get("meta")
            if meta is not None:
                parts.append(json.dumps(meta, ensure_ascii=False, default=str, sort_keys=True))
        for key in ("payload", "error", "meta"):
            value = serialized_event.get(key)
            if value is not None:
                parts.append(json.dumps(value, ensure_ascii=False, default=str, sort_keys=True))
        return " ".join(parts).casefold()

    def _append_events_sync(self, events: Sequence[RuntimeEvent]):
        if not self._enabled or not events:
            return

        with self._connect() as connection:
            inserts: list[tuple[Any, ...]] = []
            segment_writes: dict[Path, list[str]] = {}
            for event in events:
                segment = self._segment
                if segment is None or segment.event_count >= self.segment_limit:
                    segment = self._next_segment()
                serialized_event = self._serialize_event(event)
                event_json = json.dumps(serialized_event, ensure_ascii=False)
                line = event_json + "\n"
                segment_writes.setdefault(segment.path, []).append(line)
                segment.event_count += 1
                segment.line_number += 1
                run = serialized_event.get("run") if isinstance(serialized_event.get("run"), dict) else {}
                event_meta = serialized_event.get("meta") if isinstance(serialized_event.get("meta"), dict) else {}
                inserts.append(
                    (
                        serialized_event.get("event_id"),
                        serialized_event.get("timestamp"),
                        serialized_event.get("event_type"),
                        serialized_event.get("source"),
                        serialized_event.get("level"),
                        serialized_event.get("message"),
                        run.get("run_id"),
                        run.get("root_run_id"),
                        run.get("parent_run_id"),
                        run.get("run_kind"),
                        run.get("agent_name"),
                        run.get("session_id"),
                        run.get("response_id"),
                        run.get("execution_id"),
                        event_meta.get("app_id"),
                        event_meta.get("group_id"),
                        run.get("meta", {}).get("flow_name") if isinstance(run.get("meta"), dict) else None,
                        event_meta.get("environment"),
                        segment.name,
                        str(segment.path),
                        segment.line_number,
                        self._build_search_text(serialized_event),
                        event_json,
                    )
                )

            for segment_path, lines in segment_writes.items():
                segment_path.parent.mkdir(parents=True, exist_ok=True)
                with segment_path.open("a", encoding="utf-8") as file:
                    file.writelines(lines)

            connection.executemany(
                """
                INSERT OR REPLACE INTO log_events (
                    event_id, timestamp, event_type, source, level, message,
                    run_id, root_run_id, parent_run_id, run_kind, agent_name, session_id, response_id, execution_id,
                    app_id, group_id, flow_name, environment,
                    segment_name, segment_path, line_number, search_text, event_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                inserts,
            )
            connection.commit()

    async def append_event(self, event: RuntimeEvent):
        await self.append_events([event])

    async def append_events(self, events: Sequence[RuntimeEvent]):
        if not self._enabled or not events:
            return
        async with self._lock:
            await asyncio.to_thread(self._append_events_sync, list(events))

    @staticmethod
    def _row_to_event(row: sqlite3.Row):
        return RuntimeEvent.model_validate(json.loads(str(row["event_json"])))

    @staticmethod
    def _event_matches_app_id_pattern(event: RuntimeEvent, pattern: str):
        app_id = event.meta.get("app_id") if isinstance(event.meta, dict) else None
        if not isinstance(app_id, str):
            return False
        try:
            return re.search(pattern, app_id) is not None
        except re.error:
            return False

    def query_events(self, query: LogEventQuery | None = None, **kwargs):
        if not self._enabled:
            return []
        if query is None:
            query = LogEventQuery(**kwargs)

        clauses: list[str] = []
        params: list[Any] = []

        def add_equals(field: str, value: Any):
            if value is None:
                return
            clauses.append(f"{field} = ?")
            params.append(value)

        def add_in(field: str, values: Sequence[Any] | None):
            if not values:
                return
            placeholders = ", ".join("?" for _ in values)
            clauses.append(f"{field} IN ({placeholders})")
            params.extend(values)

        if query.run_ids:
            placeholders = ", ".join("?" for _ in query.run_ids)
            clauses.append(f"run_id IN ({placeholders})")
            params.extend(query.run_ids)
        if query.event_types:
            add_in("event_type", expand_triggerflow_event_types(query.event_types))
        if query.levels:
            placeholders = ", ".join("?" for _ in query.levels)
            clauses.append(f"level IN ({placeholders})")
            params.extend(query.levels)
        add_equals("run_id", query.run_id)
        add_equals("root_run_id", query.root_run_id)
        add_equals("parent_run_id", query.parent_run_id)
        add_equals("run_kind", query.run_kind)
        if query.event_type is not None:
            add_in("event_type", expand_triggerflow_event_types([query.event_type]))
        if query.event_family:
            family_clauses = ["event_type LIKE ?" for _ in expand_triggerflow_event_family(query.event_family)]
            clauses.append(f"({' OR '.join(family_clauses)})")
            params.extend([f"{family}.%" for family in expand_triggerflow_event_family(query.event_family)])
        add_equals("source", query.source)
        add_equals("level", query.level)
        add_equals("app_id", query.app_id)
        add_equals("group_id", query.group_id)
        add_equals("flow_name", query.flow_name)
        if query.search:
            clauses.append("search_text LIKE ?")
            params.append(f"%{query.search.strip().casefold()}%")
        if query.since is not None:
            clauses.append("timestamp >= ?")
            params.append(query.since)
        if query.until is not None:
            clauses.append("timestamp <= ?")
            params.append(query.until)

        where_clause = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        unbounded_run_history = query.limit is None and (
            bool(query.run_ids)
            or query.run_id is not None
            or query.root_run_id is not None
            or query.parent_run_id is not None
        )
        # Run detail views need the full history so early prompt/request events
        # are not truncated after many model.streaming chunks.
        limit = (
            -1
            if unbounded_run_history
            else query.limit if query.limit is not None else 200
        )
        offset = max(query.offset, 0)
        sql_limit = limit
        sql_offset = offset
        if query.app_id_pattern:
            sql_limit = 10000
            sql_offset = 0
        sql = f"""
            SELECT event_json
            FROM log_events
            {where_clause}
            ORDER BY timestamp DESC, rowid DESC
            LIMIT ? OFFSET ?
        """
        params.extend([sql_limit, sql_offset])
        with self._connect() as connection:
            rows = connection.execute(sql, params).fetchall()
        events = [self._row_to_event(row) for row in rows]
        if query.app_id_pattern:
            events = [event for event in events if self._event_matches_app_id_pattern(event, query.app_id_pattern)]
            if offset:
                events = events[offset:]
            events = events[:limit]
        return events

    def get_stats(self):
        if not self._enabled:
            return RuntimeLogStats(
                enabled=False,
                root_path=str(self.root_path),
                index_path=str(self.index_path),
                segment_count=0,
                event_count=0,
            )
        with self._connect() as connection:
            counts = connection.execute(
                "SELECT COUNT(*) AS event_count, COUNT(DISTINCT segment_name) AS segment_count, MAX(timestamp) AS newest_timestamp FROM log_events"
            ).fetchone()
        return RuntimeLogStats(
            enabled=True,
            root_path=str(self.root_path),
            index_path=str(self.index_path),
            segment_count=int(counts["segment_count"] or 0) if counts is not None else 0,
            event_count=int(counts["event_count"] or 0) if counts is not None else 0,
            newest_timestamp=int(counts["newest_timestamp"]) if counts is not None and counts["newest_timestamp"] is not None else None,
        )
