# Copyright 2023-2026 AgentEra(Agently.Tech)
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from pydantic import BaseModel


class LogEventQuery(BaseModel):
    run_ids: list[str] | None = None
    run_id: str | None = None
    root_run_id: str | None = None
    parent_run_id: str | None = None
    run_kind: str | None = None
    event_types: list[str] | None = None
    event_type: str | None = None
    event_family: str | None = None
    source: str | None = None
    level: str | None = None
    levels: list[str] | None = None
    app_id: str | None = None
    app_id_pattern: str | None = None
    group_id: str | None = None
    flow_name: str | None = None
    search: str | None = None
    since: int | None = None
    until: int | None = None
    limit: int | None = None
    offset: int = 0
