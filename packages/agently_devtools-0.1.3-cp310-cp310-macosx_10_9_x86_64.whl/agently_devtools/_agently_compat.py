from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    class RunContext:
        run_id: str
        root_run_id: str | None
        parent_run_id: str | None
        run_kind: str
        agent_id: str | None
        agent_name: str | None
        session_id: str | None
        response_id: str | None
        execution_id: str | None
        meta: dict[str, Any]

        @classmethod
        def create(cls, *args: Any, **kwargs: Any) -> "RunContext": ...

        def create_child(self, *args: Any, **kwargs: Any) -> "RunContext": ...

        def model_copy(self, *args: Any, **kwargs: Any) -> "RunContext": ...

        def model_dump(self, *args: Any, **kwargs: Any) -> dict[str, Any]: ...


    class RuntimeEvent:
        event_id: str
        event_type: str
        source: str
        level: str
        message: str | None
        payload: Any
        error: Any
        run: RunContext | None
        meta: dict[str, Any]
        timestamp: int

        def __init__(self, *args: Any, **kwargs: Any) -> None: ...

        def model_copy(self, *args: Any, **kwargs: Any) -> "RuntimeEvent": ...

        def model_dump(self, *args: Any, **kwargs: Any) -> dict[str, Any]: ...

        @classmethod
        def model_validate(cls, *args: Any, **kwargs: Any) -> "RuntimeEvent": ...

else:
    try:
        from agently.types.data import RunContext, RuntimeEvent
    except ImportError:  # Compatibility for published agently wheel variants.
        from agently.types.data.event import RunContext, RuntimeEvent

__all__ = ["RunContext", "RuntimeEvent"]
