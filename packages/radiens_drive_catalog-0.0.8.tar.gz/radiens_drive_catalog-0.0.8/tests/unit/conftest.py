"""Shared fixtures for radiens-drive-catalog unit tests."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING
from unittest.mock import MagicMock

import pytest

from radiens_drive_catalog.config import Config

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from radiens_drive_catalog.drive import DatasetEntry, DriveItem


@pytest.fixture
def make_drive_item() -> Callable[[str, str, str], DriveItem]:
    """Factory fixture that returns a DriveItem dict."""

    def _make(id: str, name: str, mime_type: str) -> DriveItem:
        return {"id": id, "name": name, "mimeType": mime_type}

    return _make


@pytest.fixture
def minimal_dataset_entry() -> DatasetEntry:
    """A single DatasetEntry with all 3 file IDs and local_path=None."""
    return {
        "base_name": "rat01_session1",
        "drive_path": "2026-02-15_batch/reaching",
        "drive_file_ids": {
            "data": "file_id_data",
            "meta": "file_id_meta",
            "timestamp": "file_id_timestamp",
        },
        "local_path": None,
    }


@pytest.fixture
def two_catalog_entries() -> list[DatasetEntry]:
    """Two DatasetEntry dicts used by catalog tests."""
    return [
        {
            "base_name": "rat01_session1",
            "drive_path": "2026-02-15_batch/reaching",
            "drive_file_ids": {"data": "id1", "meta": "id2", "timestamp": "id3"},
            "local_path": None,
        },
        {
            "base_name": "rat02_session1",
            "drive_path": "2026-03-01_cohort2",
            "drive_file_ids": {"data": "id4", "meta": "id5", "timestamp": "id6"},
            "local_path": None,
        },
    ]


@pytest.fixture
def tmp_catalog_file(tmp_path: Path, two_catalog_entries: list[DatasetEntry]) -> Path:
    """Write two_catalog_entries to tmp_path/catalog.json and return the path."""
    catalog_path = tmp_path / "catalog.json"
    with open(catalog_path, "w") as f:
        json.dump(two_catalog_entries, f)
    return catalog_path


@pytest.fixture
def make_config(tmp_path: Path) -> Callable[..., Config]:
    """Factory fixture returning a Config pointing at tmp_path."""

    def _make(**overrides: str) -> Config:
        defaults = {
            "credentials_path": str(tmp_path / "fake_creds.json"),
            "root_folder_id": "root_folder_id",
            "local_data_dir": str(tmp_path / "data"),
            "catalog_path": str(tmp_path / "catalog.json"),
        }
        defaults.update(overrides)
        return Config(**defaults)

    return _make


@pytest.fixture
def mock_drive_service() -> MagicMock:
    """A MagicMock Drive service wired to return an empty page by default."""
    service = MagicMock()
    service.files.return_value.list.return_value.execute.return_value = {
        "files": [],
    }
    return service
