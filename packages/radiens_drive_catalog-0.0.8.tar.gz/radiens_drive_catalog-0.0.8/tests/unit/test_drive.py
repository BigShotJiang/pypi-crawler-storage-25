"""Tests for radiens_drive_catalog.drive."""

from __future__ import annotations

from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

from radiens_drive_catalog.drive import (
    AssetEntry,
    DatasetEntry,
    DriveItem,
    _classify_item,
    _download_file,
    _extract_base_name,
    _list_all_files,
    _list_folder,
    _resolve_path_components,
    download_asset,
    download_dataset,
    scan_drive,
    scan_drive_flat,
)


class TestExtractBaseName:
    def test_data_suffix(self) -> None:
        assert _extract_base_name("rat01_data.xdat") == "rat01"

    def test_meta_suffix(self) -> None:
        assert _extract_base_name("rat01.xdat.json") == "rat01"

    def test_timestamp_suffix(self) -> None:
        assert _extract_base_name("rat01_timestamp.xdat") == "rat01"

    def test_unrecognized_suffix_returns_none(self) -> None:
        assert _extract_base_name("rat01.csv") is None

    def test_empty_string_returns_none(self) -> None:
        assert _extract_base_name("") is None

    def test_partial_match_returns_none(self) -> None:
        assert _extract_base_name("_data.xdatextra") is None

    def test_complex_base_name(self) -> None:
        assert _extract_base_name("rat01_2026-02-14_probe1_data.xdat") == "rat01_2026-02-14_probe1"

    def test_base_name_with_dots_and_dashes(self) -> None:
        assert _extract_base_name("exp.v2-rat3_timestamp.xdat") == "exp.v2-rat3"

    def test_txt_file_returns_none(self) -> None:
        assert _extract_base_name("notes.txt") is None

    def test_folder_like_name_returns_none(self) -> None:
        assert _extract_base_name("2026-02-15_batch") is None


class TestClassifyItem:
    # --- folders ---

    def test_folder_at_depth0_is_skip(self) -> None:
        assert _classify_item("2026-02-15_batch", is_folder=True, depth=0) == "skip"

    def test_folder_at_depth1_is_skip(self) -> None:
        assert _classify_item("reaching", is_folder=True, depth=1) == "skip"

    def test_folder_at_depth2_is_folder_asset(self) -> None:
        assert _classify_item("logs", is_folder=True, depth=2) == "folder_asset"

    def test_folder_at_depth3_is_folder_asset(self) -> None:
        assert _classify_item("probe1", is_folder=True, depth=3) == "folder_asset"

    # --- xdat files ---

    def test_xdat_data_file_is_dataset(self) -> None:
        assert _classify_item("rat01_data.xdat", is_folder=False, depth=1) == "dataset"

    def test_xdat_meta_file_is_dataset(self) -> None:
        assert _classify_item("rat01.xdat.json", is_folder=False, depth=2) == "dataset"

    def test_xdat_timestamp_file_is_dataset(self) -> None:
        assert _classify_item("rat01_timestamp.xdat", is_folder=False, depth=3) == "dataset"

    def test_xdat_always_dataset_regardless_of_depth(self) -> None:
        for depth in (0, 1, 2, 3, 5):
            assert _classify_item("rat01_data.xdat", is_folder=False, depth=depth) == "dataset"

    # --- non-xdat files ---

    def test_non_xdat_at_depth1_is_file_asset(self) -> None:
        assert _classify_item("notes.txt", is_folder=False, depth=1) == "file_asset"

    def test_non_xdat_at_depth2_is_file_asset(self) -> None:
        assert _classify_item("slides.pptx", is_folder=False, depth=2) == "file_asset"

    def test_non_xdat_at_depth0_is_skip(self) -> None:
        assert _classify_item("readme.txt", is_folder=False, depth=0) == "skip"

    def test_non_xdat_at_depth3_is_skip(self) -> None:
        assert _classify_item("log_entry.txt", is_folder=False, depth=3) == "skip"

    def test_non_xdat_at_depth4_is_skip(self) -> None:
        assert _classify_item("deep.csv", is_folder=False, depth=4) == "skip"


class TestListFolder:
    def _make_service(self, pages: list[dict[str, object]]) -> MagicMock:
        """Build a mock service whose execute() returns pages in sequence."""
        service = MagicMock()
        if len(pages) == 1:
            service.files.return_value.list.return_value.execute.return_value = pages[0]
        else:
            service.files.return_value.list.return_value.execute.side_effect = pages
        return service

    def test_empty_folder(self) -> None:
        service = self._make_service([{"files": []}])
        assert _list_folder(service, "folder_id") == []

    def test_single_page_returns_all_items(self, make_drive_item: Callable[[str, str, str], DriveItem]) -> None:
        items = [
            make_drive_item("id1", "rat01_data.xdat", "application/octet-stream"),
            make_drive_item("id2", "rat01.xdat.json", "application/json"),
        ]
        service = self._make_service([{"files": items}])
        result = _list_folder(service, "folder_id")
        assert len(result) == 2
        assert result[0] == {"id": "id1", "name": "rat01_data.xdat", "mimeType": "application/octet-stream"}

    def test_pagination_two_pages(self, make_drive_item: Callable[[str, str, str], DriveItem]) -> None:
        page1: dict[str, object] = {
            "files": [make_drive_item("id1", "file1_data.xdat", "application/octet-stream")],
            "nextPageToken": "tok1",
        }
        page2: dict[str, object] = {
            "files": [make_drive_item("id2", "file2_data.xdat", "application/octet-stream")],
        }
        service = self._make_service([page1, page2])
        result = _list_folder(service, "folder_id")
        assert len(result) == 2
        assert result[0]["id"] == "id1"
        assert result[1]["id"] == "id2"

    def test_pagination_three_pages(self, make_drive_item: Callable[[str, str, str], DriveItem]) -> None:
        pages: list[dict[str, object]] = [
            {"files": [make_drive_item(f"id{i}", f"f{i}_data.xdat", "x")], "nextPageToken": f"tok{i}"}
            for i in range(1, 3)
        ]
        pages.append({"files": [make_drive_item("id3", "f3_data.xdat", "x")]})
        service = self._make_service(pages)
        result = _list_folder(service, "folder_id")
        assert len(result) == 3

    def test_item_missing_id_is_skipped(self) -> None:
        service = self._make_service([{"files": [{"name": "rat01_data.xdat", "mimeType": "x"}]}])
        assert _list_folder(service, "folder_id") == []

    def test_item_missing_name_is_skipped(self) -> None:
        service = self._make_service([{"files": [{"id": "id1", "mimeType": "x"}]}])
        assert _list_folder(service, "folder_id") == []

    def test_item_missing_mimetype_is_skipped(self) -> None:
        service = self._make_service([{"files": [{"id": "id1", "name": "rat01_data.xdat"}]}])
        assert _list_folder(service, "folder_id") == []

    def test_item_with_non_string_id_is_skipped(self) -> None:
        service = self._make_service([{"files": [{"id": 123, "name": "rat01_data.xdat", "mimeType": "x"}]}])
        assert _list_folder(service, "folder_id") == []

    def test_non_string_next_page_token_stops_pagination(
        self, make_drive_item: Callable[[str, str, str], DriveItem]
    ) -> None:
        # nextPageToken is an int — should not be used, stop after one page
        service = self._make_service([{"files": [make_drive_item("id1", "f_data.xdat", "x")], "nextPageToken": 42}])
        result = _list_folder(service, "folder_id")
        assert len(result) == 1
        # Only one execute() call should have been made
        assert service.files.return_value.list.return_value.execute.call_count == 1

    def test_correct_query_string_passed(self) -> None:
        service = self._make_service([{"files": []}])
        _list_folder(service, "myfolder123")
        list_call = service.files.return_value.list.call_args
        assert list_call.kwargs["q"] == "'myfolder123' in parents and trashed = false"

    def test_non_dict_items_in_files_list_skipped(self) -> None:
        service = self._make_service([{"files": ["not_a_dict", 42, None]}])
        assert _list_folder(service, "folder_id") == []


class TestScanDrive:
    """Tests for scan_drive(), patching _list_folder to avoid real API calls."""

    def _folder_item(self, id: str, name: str) -> DriveItem:
        return {"id": id, "name": name, "mimeType": "application/vnd.google-apps.folder"}

    def _file_item(self, id: str, name: str, mime: str = "application/octet-stream") -> DriveItem:
        return {"id": id, "name": name, "mimeType": mime}

    def test_empty_root(self) -> None:
        with patch("radiens_drive_catalog.drive._list_folder", return_value=[]):
            datasets, assets = scan_drive(MagicMock(), "root_id")
        assert datasets == []
        assert assets == []

    def test_dataset_at_depth1(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02-15_batch")
        files = [
            self._file_item("d_id", "rat01_data.xdat"),
            self._file_item("m_id", "rat01.xdat.json"),
            self._file_item("t_id", "rat01_timestamp.xdat"),
        ]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            return files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, assets = scan_drive(MagicMock(), "root_id")

        assert len(datasets) == 1
        entry = datasets[0]
        assert entry["base_name"] == "rat01"
        assert entry["drive_path"] == "2026-02-15_batch"
        assert assets == []

    def test_dataset_at_depth2(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02-15_batch")
        exp_folder = self._folder_item("exp_id", "reaching")
        files = [self._file_item("d_id", "rat01_data.xdat")]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [exp_folder]
            return files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, _assets = scan_drive(MagicMock(), "root_id")

        assert len(datasets) == 1
        assert datasets[0]["drive_path"] == "2026-02-15_batch/reaching"

    def test_dataset_at_depth3(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02-15_batch")
        exp_folder = self._folder_item("exp_id", "reaching")
        sub_folder = self._folder_item("sub_id", "probe1")
        files = [self._file_item("d_id", "rat01_data.xdat")]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [exp_folder]
            if folder_id == "exp_id":
                return [sub_folder]
            return files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, _assets = scan_drive(MagicMock(), "root_id")

        entry = datasets[0]
        assert entry["drive_path"] == "2026-02-15_batch/reaching/probe1"

    def test_multiple_datasets_same_folder(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02-15_batch")
        files = [
            self._file_item("a1", "rat01_data.xdat"),
            self._file_item("b1", "rat02_data.xdat"),
        ]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            return [date_folder] if folder_id == "root_id" else files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, _ = scan_drive(MagicMock(), "root_id")

        base_names = {e["base_name"] for e in datasets}
        assert base_names == {"rat01", "rat02"}

    def test_same_base_name_different_paths_are_separate_entries(self) -> None:
        # Two folders each with a file of the same base_name — both should be cataloged
        date_folder = self._folder_item("date_id", "2026-02")
        exp1 = self._folder_item("exp1_id", "session1")
        exp2 = self._folder_item("exp2_id", "session2")
        files = [self._file_item("d_id", "rat01_data.xdat")]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [exp1, exp2]
            return files  # both experiment folders contain rat01_data.xdat

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, _ = scan_drive(MagicMock(), "root_id")

        assert len(datasets) == 2
        paths = {e["drive_path"] for e in datasets}
        assert paths == {"2026-02/session1", "2026-02/session2"}
        assert all(e["base_name"] == "rat01" for e in datasets)

    def test_all_three_files_merged(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02")
        files = [
            self._file_item("d_id", "rat01_data.xdat"),
            self._file_item("m_id", "rat01.xdat.json"),
            self._file_item("t_id", "rat01_timestamp.xdat"),
        ]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            return [date_folder] if folder_id == "root_id" else files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, _ = scan_drive(MagicMock(), "root_id")

        assert len(datasets) == 1
        ids = datasets[0]["drive_file_ids"]
        assert set(ids.keys()) == {"data", "meta", "timestamp"}
        assert ids["data"] == "d_id"
        assert ids["meta"] == "m_id"
        assert ids["timestamp"] == "t_id"

    def test_partial_dataset_one_file(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02")
        files = [self._file_item("d_id", "rat01_data.xdat")]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            return [date_folder] if folder_id == "root_id" else files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, _ = scan_drive(MagicMock(), "root_id")

        assert len(datasets) == 1
        assert datasets[0]["drive_file_ids"] == {"data": "d_id"}

    def test_partial_dataset_two_files(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02")
        files = [
            self._file_item("d_id", "rat01_data.xdat"),
            self._file_item("m_id", "rat01.xdat.json"),
        ]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            return [date_folder] if folder_id == "root_id" else files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, _ = scan_drive(MagicMock(), "root_id")

        ids = datasets[0]["drive_file_ids"]
        assert set(ids.keys()) == {"data", "meta"}

    def test_non_xdat_file_in_date_folder_becomes_file_asset(self) -> None:
        # Non-xdat files directly inside a date folder are cataloged as file assets
        date_folder = self._folder_item("date_id", "2026-02")
        files = [
            self._file_item("n1", "notes.txt"),
            self._file_item("n2", "analysis.csv"),
        ]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            return [date_folder] if folder_id == "root_id" else files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, assets = scan_drive(MagicMock(), "root_id")

        assert datasets == []
        assert len(assets) == 2
        assert all(a["asset_type"] == "file" for a in assets)
        assert {a["asset_name"] for a in assets} == {"notes.txt", "analysis.csv"}

    def test_non_xdat_file_in_experiment_folder_becomes_file_asset(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02-15_batch")
        exp_folder = self._folder_item("exp_id", "reaching")
        files = [self._file_item("p1", "notes.pptx", "application/vnd.ms-powerpoint")]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [exp_folder]
            return files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, assets = scan_drive(MagicMock(), "root_id")

        assert datasets == []
        assert len(assets) == 1
        asset = assets[0]
        assert asset["asset_name"] == "notes.pptx"
        assert asset["asset_type"] == "file"
        assert asset["drive_path"] == "2026-02-15_batch/reaching"
        assert asset["drive_id"] == "p1"

    def test_subfolder_of_experiment_becomes_folder_asset(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02-15_batch")
        exp_folder = self._folder_item("exp_id", "reaching")
        logs_folder = self._folder_item("logs_id", "logs")

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [exp_folder]
            if folder_id == "exp_id":
                return [logs_folder]
            return []  # logs/ is empty

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, assets = scan_drive(MagicMock(), "root_id")

        assert datasets == []
        assert len(assets) == 1
        asset = assets[0]
        assert asset["asset_name"] == "logs"
        assert asset["asset_type"] == "folder"
        assert asset["drive_path"] == "2026-02-15_batch/reaching"
        assert asset["drive_id"] == "logs_id"

    def test_folder_asset_is_also_recursed_for_datasets(self) -> None:
        # A folder asset at depth 3 can still contain xdat datasets
        date_folder = self._folder_item("date_id", "2026-02-15_batch")
        exp_folder = self._folder_item("exp_id", "reaching")
        probe_folder = self._folder_item("probe_id", "probe1")
        xdat_files = [self._file_item("d_id", "rat01_data.xdat")]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [exp_folder]
            if folder_id == "exp_id":
                return [probe_folder]
            return xdat_files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, assets = scan_drive(MagicMock(), "root_id")

        # probe1 is both a folder asset and the parent of a dataset
        assert len(datasets) == 1
        assert datasets[0]["base_name"] == "rat01"
        assert len(assets) == 1
        assert assets[0]["asset_name"] == "probe1"

    def test_folder_asset_inside_nested_experiment_folder(self) -> None:
        # Nested hierarchy: date_folder/sub_folder/stim_sweep/logs/
        date_folder = self._folder_item("date_id", "2026-03-23_batch")
        sub_folder = self._folder_item("sub_id", "2.StimulationRound1")
        stim_sweep = self._folder_item("stim_id", "stim_sweep_170011")
        logs_folder = self._folder_item("logs_id", "logs")

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [sub_folder]
            if folder_id == "sub_id":
                return [stim_sweep]
            if folder_id == "stim_id":
                return [logs_folder]
            return []

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            _datasets, assets = scan_drive(MagicMock(), "root_id")

        asset_by_name = {a["asset_name"]: a for a in assets}
        assert "logs" in asset_by_name
        logs_asset = asset_by_name["logs"]
        assert logs_asset["drive_path"] == "2026-03-23_batch/2.StimulationRound1/stim_sweep_170011"
        assert logs_asset["asset_type"] == "folder"

    def test_non_xdat_file_deeper_than_experiment_not_cataloged_as_asset(self) -> None:
        # Files at depth >= 4 (inside a subfolder of experiment) are NOT separate assets
        date_folder = self._folder_item("date_id", "2026-02-15_batch")
        exp_folder = self._folder_item("exp_id", "reaching")
        logs_folder = self._folder_item("logs_id", "logs")
        deep_file = self._file_item("f1", "log_entry.txt")

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [exp_folder]
            if folder_id == "exp_id":
                return [logs_folder]
            return [deep_file]  # inside logs/

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            _datasets, assets = scan_drive(MagicMock(), "root_id")

        asset_names = {a["asset_name"] for a in assets}
        assert "log_entry.txt" not in asset_names  # only logs/ itself is an asset
        assert "logs" in asset_names

    def test_mixed_xdat_and_non_xdat_in_experiment(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02")
        exp_folder = self._folder_item("exp_id", "reaching")
        items = [
            self._file_item("d_id", "rat01_data.xdat"),
            self._file_item("n1", "notes.txt"),
        ]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [exp_folder]
            return items

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, assets = scan_drive(MagicMock(), "root_id")

        assert len(datasets) == 1
        assert datasets[0]["base_name"] == "rat01"
        assert len(assets) == 1
        assert assets[0]["asset_name"] == "notes.txt"

    def test_all_dataset_entries_have_local_path_none(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02")
        files = [self._file_item("d_id", "rat01_data.xdat")]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            return [date_folder] if folder_id == "root_id" else files

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, _assets = scan_drive(MagicMock(), "root_id")

        assert all(e["local_path"] is None for e in datasets)

    def test_all_asset_entries_have_local_path_none(self) -> None:
        date_folder = self._folder_item("date_id", "2026-02")
        exp_folder = self._folder_item("exp_id", "reaching")
        items = [self._file_item("p1", "slides.pptx")]

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [exp_folder]
            return items

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            _, assets = scan_drive(MagicMock(), "root_id")

        assert all(a["local_path"] is None for a in assets)

    def test_date_folder_not_cataloged_as_folder_asset(self) -> None:
        # Top-level date folders are not assets
        date_folder = self._folder_item("date_id", "2026-02-15_batch")

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            return []

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, assets = scan_drive(MagicMock(), "root_id")

        assert datasets == []
        assert assets == []

    def test_experiment_folder_not_cataloged_as_folder_asset(self) -> None:
        # Depth-2 experiment folders are not assets
        date_folder = self._folder_item("date_id", "2026-02-15_batch")
        exp_folder = self._folder_item("exp_id", "reaching")

        def fake_list(service: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "root_id":
                return [date_folder]
            if folder_id == "date_id":
                return [exp_folder]
            return []

        with patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list):
            datasets, assets = scan_drive(MagicMock(), "root_id")

        assert datasets == []
        assert assets == []


class TestDownloadDataset:
    def _make_dataset(self, base_name: str, file_ids: dict[str, str], drive_path: str = "2026-02") -> DatasetEntry:
        return {
            "base_name": base_name,
            "drive_path": drive_path,
            "drive_file_ids": file_ids,
            "local_path": None,
        }

    def test_creates_local_dir(self, tmp_path: Path) -> None:
        dest = tmp_path / "new_subdir"
        dataset = self._make_dataset("rat01", {"data": "id1"})
        service = MagicMock()

        with patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl:
            mock_dl.return_value.next_chunk.return_value = (None, True)
            download_dataset(service, dataset, str(dest))

        # mkdir(parents=True) creates dest AND dest/2026-02
        assert (dest / "2026-02").exists()

    def test_returns_path_with_drive_path(self, tmp_path: Path) -> None:
        dataset = self._make_dataset("rat01", {"data": "id1"}, drive_path="2026-02/reaching")
        service = MagicMock()

        with patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl:
            mock_dl.return_value.next_chunk.return_value = (None, True)
            result = download_dataset(service, dataset, str(tmp_path))

        assert result == str(tmp_path / "2026-02" / "reaching")

    def test_calls_get_media_for_each_file(self, tmp_path: Path) -> None:
        dataset = self._make_dataset("rat01", {"data": "id_d", "meta": "id_m", "timestamp": "id_t"})
        service = MagicMock()

        with patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl:
            mock_dl.return_value.next_chunk.return_value = (None, True)
            download_dataset(service, dataset, str(tmp_path))

        assert service.files.return_value.get_media.call_count == 3
        called_ids = {c.kwargs["fileId"] for c in service.files.return_value.get_media.call_args_list}
        assert called_ids == {"id_d", "id_m", "id_t"}

    def test_partial_dataset_one_file(self, tmp_path: Path) -> None:
        dataset = self._make_dataset("rat01", {"data": "id_d"})
        service = MagicMock()

        with patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl:
            mock_dl.return_value.next_chunk.return_value = (None, True)
            download_dataset(service, dataset, str(tmp_path))

        assert service.files.return_value.get_media.call_count == 1

    def test_existing_dir_does_not_raise(self, tmp_path: Path) -> None:
        dataset = self._make_dataset("rat01", {"data": "id1"})
        service = MagicMock()
        # Create the full path that download_dataset would create
        (tmp_path / "2026-02").mkdir(parents=True, exist_ok=True)

        with patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl:
            mock_dl.return_value.next_chunk.return_value = (None, True)
            download_dataset(service, dataset, str(tmp_path))  # should not raise

    def test_correct_filenames_written_to_drive_path_subdir(self, tmp_path: Path) -> None:
        dataset = self._make_dataset(
            "rat01", {"data": "id_d", "meta": "id_m", "timestamp": "id_t"}, drive_path="2026-02/reaching"
        )
        service = MagicMock()

        with patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl:
            mock_dl.return_value.next_chunk.return_value = (None, True)
            download_dataset(service, dataset, str(tmp_path))

        subdir = tmp_path / "2026-02" / "reaching"
        expected = {
            subdir / "rat01_data.xdat",
            subdir / "rat01.xdat.json",
            subdir / "rat01_timestamp.xdat",
        }
        actual = set(subdir.iterdir())
        assert actual == expected

    def test_quiet_passed_to_tqdm(self, tmp_path: Path) -> None:
        dataset = self._make_dataset("rat01", {"data": "id1"})
        service = MagicMock()

        with (
            patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl,
            patch("radiens_drive_catalog.drive.tqdm") as mock_tqdm,
        ):
            mock_dl.return_value.next_chunk.return_value = (None, True)
            mock_tqdm.return_value.__enter__ = MagicMock(return_value=MagicMock())
            mock_tqdm.return_value.__exit__ = MagicMock(return_value=False)
            download_dataset(service, dataset, str(tmp_path), quiet=True)

        assert mock_tqdm.call_args.kwargs.get("disable") is True


class TestDownloadFile:
    def test_quiet_false_passes_disable_false(self, tmp_path: Path) -> None:
        dest = tmp_path / "file.xdat"
        service = MagicMock()

        with (
            patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl,
            patch("radiens_drive_catalog.drive.tqdm") as mock_tqdm,
        ):
            mock_dl.return_value.next_chunk.return_value = (None, True)
            mock_tqdm.return_value.__enter__ = MagicMock(return_value=MagicMock())
            mock_tqdm.return_value.__exit__ = MagicMock(return_value=False)
            _download_file(service, "file_id", dest, quiet=False)

        assert mock_tqdm.call_args.kwargs.get("disable") is False

    def test_quiet_true_passes_disable_true(self, tmp_path: Path) -> None:
        dest = tmp_path / "file.xdat"
        service = MagicMock()

        with (
            patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl,
            patch("radiens_drive_catalog.drive.tqdm") as mock_tqdm,
        ):
            mock_dl.return_value.next_chunk.return_value = (None, True)
            mock_tqdm.return_value.__enter__ = MagicMock(return_value=MagicMock())
            mock_tqdm.return_value.__exit__ = MagicMock(return_value=False)
            _download_file(service, "file_id", dest, quiet=True)

        assert mock_tqdm.call_args.kwargs.get("disable") is True


class TestDownloadAsset:
    def _make_file_asset(self, asset_name: str, drive_id: str, drive_path: str = "2026-02/reaching") -> AssetEntry:
        return {
            "asset_name": asset_name,
            "asset_type": "file",
            "drive_path": drive_path,
            "drive_id": drive_id,
            "mime_type": "application/octet-stream",
            "local_path": None,
        }

    def _make_folder_asset(self, asset_name: str, drive_id: str, drive_path: str = "2026-02/reaching") -> AssetEntry:
        return {
            "asset_name": asset_name,
            "asset_type": "folder",
            "drive_path": drive_path,
            "drive_id": drive_id,
            "mime_type": "application/vnd.google-apps.folder",
            "local_path": None,
        }

    def test_file_asset_downloaded_to_correct_path(self, tmp_path: Path) -> None:
        asset = self._make_file_asset("notes.pptx", "file_id_1")
        service = MagicMock()

        with patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl:
            mock_dl.return_value.next_chunk.return_value = (None, True)
            result = download_asset(service, asset, str(tmp_path))

        expected = tmp_path / "assets" / "2026-02" / "reaching" / "notes.pptx"
        assert result == str(expected)
        assert expected.exists()

    def test_folder_asset_creates_directory(self, tmp_path: Path) -> None:
        asset = self._make_folder_asset("logs", "folder_id_1")
        service = MagicMock()
        # _list_folder returns empty (no sub-items)
        with patch("radiens_drive_catalog.drive._list_folder", return_value=[]):
            result = download_asset(service, asset, str(tmp_path))

        expected = tmp_path / "assets" / "2026-02" / "reaching" / "logs"
        assert result == str(expected)
        assert expected.is_dir()

    def test_file_asset_calls_get_media(self, tmp_path: Path) -> None:
        asset = self._make_file_asset("notes.pptx", "file_id_42")
        service = MagicMock()

        with patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl:
            mock_dl.return_value.next_chunk.return_value = (None, True)
            download_asset(service, asset, str(tmp_path))

        service.files.return_value.get_media.assert_called_once_with(fileId="file_id_42")

    def test_folder_asset_recurses_into_subfolders(self, tmp_path: Path) -> None:
        asset = self._make_folder_asset("logs", "logs_id")
        service = MagicMock()

        subfolder: DriveItem = {"id": "sub_id", "name": "2026", "mimeType": "application/vnd.google-apps.folder"}
        subfile: DriveItem = {"id": "f_id", "name": "log.txt", "mimeType": "text/plain"}

        def fake_list(svc: object, folder_id: str) -> list[DriveItem]:
            if folder_id == "logs_id":
                return [subfolder]
            if folder_id == "sub_id":
                return [subfile]
            return []

        with (
            patch("radiens_drive_catalog.drive._list_folder", side_effect=fake_list),
            patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl,
        ):
            mock_dl.return_value.next_chunk.return_value = (None, True)
            download_asset(service, asset, str(tmp_path))

        subfolder_dir = tmp_path / "assets" / "2026-02" / "reaching" / "logs" / "2026"
        assert subfolder_dir.is_dir()

    def test_asset_with_empty_drive_path(self, tmp_path: Path) -> None:
        # Asset directly under root (drive_path is empty string)
        asset: AssetEntry = {
            "asset_name": "readme.txt",
            "asset_type": "file",
            "drive_path": "",
            "drive_id": "f_id",
            "mime_type": "text/plain",
            "local_path": None,
        }
        service = MagicMock()

        with patch("radiens_drive_catalog.drive.MediaIoBaseDownload") as mock_dl:
            mock_dl.return_value.next_chunk.return_value = (None, True)
            result = download_asset(service, asset, str(tmp_path))

        expected = tmp_path / "assets" / "readme.txt"
        assert result == str(expected)


# ---------------------------------------------------------------------------
# Flat-scan fallback tests
# ---------------------------------------------------------------------------


class TestListAllFiles:
    """Tests for _list_all_files() — paginated flat listing of all visible files."""

    def _make_service(self, pages: list[dict[str, object]]) -> MagicMock:
        service = MagicMock()
        if len(pages) == 1:
            service.files.return_value.list.return_value.execute.return_value = pages[0]
        else:
            service.files.return_value.list.return_value.execute.side_effect = pages
        return service

    def test_empty_listing(self) -> None:
        service = self._make_service([{"files": []}])
        assert _list_all_files(service) == []

    def test_single_page(self) -> None:
        items: list[dict[str, object]] = [
            {"id": "id1", "name": "rat01_data.xdat", "mimeType": "application/octet-stream", "parents": ["root"]},
        ]
        service = self._make_service([{"files": items}])
        result = _list_all_files(service)
        assert len(result) == 1
        assert result[0]["id"] == "id1"
        assert result[0].get("parents") == ["root"]

    def test_pagination_two_pages(self) -> None:
        page1: dict[str, object] = {
            "files": [{"id": "id1", "name": "f1_data.xdat", "mimeType": "x", "parents": ["p1"]}],
            "nextPageToken": "tok1",
        }
        page2: dict[str, object] = {
            "files": [{"id": "id2", "name": "f2_data.xdat", "mimeType": "x", "parents": ["p2"]}],
        }
        service = self._make_service([page1, page2])
        result = _list_all_files(service)
        assert len(result) == 2
        assert result[0]["id"] == "id1"
        assert result[1]["id"] == "id2"

    def test_pagesize_1000_passed(self) -> None:
        service = self._make_service([{"files": []}])
        _list_all_files(service)
        call_kwargs = service.files.return_value.list.call_args.kwargs
        assert call_kwargs["pageSize"] == 1000

    def test_parents_field_requested(self) -> None:
        service = self._make_service([{"files": []}])
        _list_all_files(service)
        fields = service.files.return_value.list.call_args.kwargs["fields"]
        assert "parents" in fields

    def test_item_without_parents_key(self) -> None:
        items: list[dict[str, object]] = [
            {"id": "id1", "name": "f1.xdat", "mimeType": "x"},
        ]
        service = self._make_service([{"files": items}])
        result = _list_all_files(service)
        assert len(result) == 1
        assert "parents" not in result[0]

    def test_item_with_non_list_parents_ignored(self) -> None:
        items: list[dict[str, object]] = [
            {"id": "id1", "name": "f1.xdat", "mimeType": "x", "parents": "not_a_list"},
        ]
        service = self._make_service([{"files": items}])
        result = _list_all_files(service)
        assert len(result) == 1
        assert "parents" not in result[0]

    def test_item_missing_id_skipped(self) -> None:
        service = self._make_service([{"files": [{"name": "f.xdat", "mimeType": "x"}]}])
        assert _list_all_files(service) == []

    def test_incomplete_search_warns(self) -> None:
        service = self._make_service([{"files": [], "incompleteSearch": True}])
        with patch("radiens_drive_catalog.drive._log") as mock_log:
            _list_all_files(service)
        mock_log.warning.assert_called_once()
        assert "incomplete search" in mock_log.warning.call_args[0][0].lower()

    def test_no_warning_when_search_complete(self) -> None:
        service = self._make_service([{"files": [], "incompleteSearch": False}])
        # Should not warn — no assertion needed beyond not raising
        _list_all_files(service)


class TestResolvePathComponents:
    """Tests for _resolve_path_components() — parent-chain path resolution."""

    FOLDER = "application/vnd.google-apps.folder"

    def test_file_at_depth1(self) -> None:
        # root → date_folder → file
        id_map: dict[str, DriveItem] = {
            "date_id": {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            "file_id": {"id": "file_id", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["date_id"]},
        }
        path = _resolve_path_components("file_id", id_map, "root")
        assert path == ["2026-02"]

    def test_file_at_depth2(self) -> None:
        # root → date → experiment → file
        id_map: dict[str, DriveItem] = {
            "date_id": {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            "exp_id": {"id": "exp_id", "name": "reaching", "mimeType": self.FOLDER, "parents": ["date_id"]},
            "file_id": {"id": "file_id", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["exp_id"]},
        }
        path = _resolve_path_components("file_id", id_map, "root")
        assert path == ["2026-02", "reaching"]

    def test_file_at_depth3(self) -> None:
        id_map: dict[str, DriveItem] = {
            "date_id": {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            "exp_id": {"id": "exp_id", "name": "reaching", "mimeType": self.FOLDER, "parents": ["date_id"]},
            "sub_id": {"id": "sub_id", "name": "probe1", "mimeType": self.FOLDER, "parents": ["exp_id"]},
            "file_id": {"id": "file_id", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["sub_id"]},
        }
        path = _resolve_path_components("file_id", id_map, "root")
        assert path == ["2026-02", "reaching", "probe1"]

    def test_root_in_id_map_is_excluded(self) -> None:
        # Root folder IS in the map — should NOT appear in path
        id_map: dict[str, DriveItem] = {
            "root": {"id": "root", "name": "MyRoot", "mimeType": self.FOLDER, "parents": ["drive_root"]},
            "date_id": {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            "file_id": {"id": "file_id", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["date_id"]},
        }
        path = _resolve_path_components("file_id", id_map, "root")
        assert path == ["2026-02"]

    def test_root_not_in_map_stops_at_boundary(self) -> None:
        # Root not in map — walk stops when parent is unknown
        id_map: dict[str, DriveItem] = {
            "date_id": {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["unknown_root"]},
            "file_id": {"id": "file_id", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["date_id"]},
        }
        path = _resolve_path_components("file_id", id_map, "actual_root")
        assert path == ["2026-02"]

    def test_item_with_no_parents_key(self) -> None:
        id_map: dict[str, DriveItem] = {
            "file_id": {"id": "file_id", "name": "orphan.xdat", "mimeType": "x"},
        }
        path = _resolve_path_components("file_id", id_map, "root")
        assert path == []

    def test_item_not_in_map(self) -> None:
        id_map: dict[str, DriveItem] = {}
        path = _resolve_path_components("missing_id", id_map, "root")
        assert path == []

    def test_file_directly_under_root(self) -> None:
        # File whose parent IS root → empty path (depth 0)
        id_map: dict[str, DriveItem] = {
            "file_id": {"id": "file_id", "name": "orphan.xdat", "mimeType": "x", "parents": ["root"]},
        }
        path = _resolve_path_components("file_id", id_map, "root")
        assert path == []


class TestScanDriveFlat:
    """Tests for scan_drive_flat() — flat listing with path reconstruction."""

    FOLDER = "application/vnd.google-apps.folder"

    def test_empty_listing(self) -> None:
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=[]):
            datasets, assets = scan_drive_flat(MagicMock(), "root")
        assert datasets == []
        assert assets == []

    def test_dataset_at_depth1(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "d_id", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["date_id"]},
            {"id": "m_id", "name": "rat01.xdat.json", "mimeType": "x", "parents": ["date_id"]},
            {"id": "t_id", "name": "rat01_timestamp.xdat", "mimeType": "x", "parents": ["date_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            datasets, assets = scan_drive_flat(MagicMock(), "root")

        assert len(datasets) == 1
        entry = datasets[0]
        assert entry["base_name"] == "rat01"
        assert entry["drive_path"] == "2026-02"
        assert set(entry["drive_file_ids"].keys()) == {"data", "meta", "timestamp"}
        assert assets == []

    def test_dataset_at_depth2(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "exp_id", "name": "reaching", "mimeType": self.FOLDER, "parents": ["date_id"]},
            {"id": "d_id", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["exp_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            datasets, _assets = scan_drive_flat(MagicMock(), "root")

        assert len(datasets) == 1
        assert datasets[0]["drive_path"] == "2026-02/reaching"

    def test_dataset_at_depth3(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "exp_id", "name": "reaching", "mimeType": self.FOLDER, "parents": ["date_id"]},
            {"id": "sub_id", "name": "probe1", "mimeType": self.FOLDER, "parents": ["exp_id"]},
            {"id": "d_id", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["sub_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            datasets, _assets = scan_drive_flat(MagicMock(), "root")

        assert len(datasets) == 1
        assert datasets[0]["drive_path"] == "2026-02/reaching/probe1"

    def test_same_base_name_different_paths_are_separate_entries(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "exp1_id", "name": "session1", "mimeType": self.FOLDER, "parents": ["date_id"]},
            {"id": "exp2_id", "name": "session2", "mimeType": self.FOLDER, "parents": ["date_id"]},
            {"id": "d1", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["exp1_id"]},
            {"id": "d2", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["exp2_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            datasets, _ = scan_drive_flat(MagicMock(), "root")

        assert len(datasets) == 2
        paths = {d["drive_path"] for d in datasets}
        assert paths == {"2026-02/session1", "2026-02/session2"}

    def test_folder_asset_at_depth2(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "exp_id", "name": "reaching", "mimeType": self.FOLDER, "parents": ["date_id"]},
            {"id": "logs_id", "name": "logs", "mimeType": self.FOLDER, "parents": ["exp_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            _datasets, assets = scan_drive_flat(MagicMock(), "root")

        assert len(assets) == 1
        assert assets[0]["asset_name"] == "logs"
        assert assets[0]["asset_type"] == "folder"
        assert assets[0]["drive_path"] == "2026-02/reaching"

    def test_file_asset_at_depth1(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "f_id", "name": "notes.txt", "mimeType": "text/plain", "parents": ["date_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            datasets, assets = scan_drive_flat(MagicMock(), "root")

        assert datasets == []
        assert len(assets) == 1
        assert assets[0]["asset_name"] == "notes.txt"
        assert assets[0]["asset_type"] == "file"
        assert assets[0]["drive_path"] == "2026-02"

    def test_file_asset_at_depth2(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "exp_id", "name": "reaching", "mimeType": self.FOLDER, "parents": ["date_id"]},
            {"id": "f_id", "name": "notes.pptx", "mimeType": "application/vnd.ms-powerpoint", "parents": ["exp_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            _, assets = scan_drive_flat(MagicMock(), "root")

        assert len(assets) == 1
        assert assets[0]["asset_name"] == "notes.pptx"
        assert assets[0]["drive_path"] == "2026-02/reaching"

    def test_non_xdat_file_at_depth3_not_asset(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "exp_id", "name": "reaching", "mimeType": self.FOLDER, "parents": ["date_id"]},
            {"id": "logs_id", "name": "logs", "mimeType": self.FOLDER, "parents": ["exp_id"]},
            {"id": "f_id", "name": "log.txt", "mimeType": "text/plain", "parents": ["logs_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            datasets, assets = scan_drive_flat(MagicMock(), "root")

        assert datasets == []
        asset_names = {a["asset_name"] for a in assets}
        assert "log.txt" not in asset_names
        assert "logs" in asset_names

    def test_folder_asset_inside_nested_experiment_folder(self) -> None:
        # Nested hierarchy: date_folder/sub_folder/stim_sweep/logs/
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-03-23_batch", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "sub_id", "name": "2.StimulationRound1", "mimeType": self.FOLDER, "parents": ["date_id"]},
            {"id": "stim_id", "name": "stim_sweep_170011", "mimeType": self.FOLDER, "parents": ["sub_id"]},
            {"id": "logs_id", "name": "logs", "mimeType": self.FOLDER, "parents": ["stim_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            _datasets, assets = scan_drive_flat(MagicMock(), "root")

        asset_by_name = {a["asset_name"]: a for a in assets}
        assert "logs" in asset_by_name
        logs_asset = asset_by_name["logs"]
        assert logs_asset["drive_path"] == "2026-03-23_batch/2.StimulationRound1/stim_sweep_170011"
        assert logs_asset["asset_type"] == "folder"

    def test_multiple_datasets_same_folder(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "d1", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["date_id"]},
            {"id": "d2", "name": "rat02_data.xdat", "mimeType": "x", "parents": ["date_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            datasets, _ = scan_drive_flat(MagicMock(), "root")

        assert {d["base_name"] for d in datasets} == {"rat01", "rat02"}

    def test_all_entries_have_local_path_none(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "d_id", "name": "rat01_data.xdat", "mimeType": "x", "parents": ["date_id"]},
            {"id": "exp_id", "name": "reaching", "mimeType": self.FOLDER, "parents": ["date_id"]},
            {"id": "f_id", "name": "notes.txt", "mimeType": "text/plain", "parents": ["exp_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            datasets, assets = scan_drive_flat(MagicMock(), "root")

        assert all(d["local_path"] is None for d in datasets)
        assert all(a["local_path"] is None for a in assets)

    def test_date_folder_not_cataloged_as_asset(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            datasets, assets = scan_drive_flat(MagicMock(), "root")

        assert datasets == []
        assert assets == []

    def test_experiment_folder_not_cataloged_as_asset(self) -> None:
        items: list[DriveItem] = [
            {"id": "date_id", "name": "2026-02", "mimeType": self.FOLDER, "parents": ["root"]},
            {"id": "exp_id", "name": "reaching", "mimeType": self.FOLDER, "parents": ["date_id"]},
        ]
        with patch("radiens_drive_catalog.drive._list_all_files", return_value=items):
            datasets, assets = scan_drive_flat(MagicMock(), "root")

        assert datasets == []
        assert assets == []
