"""Tests for radiens_drive_catalog.catalog."""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

from radiens_drive_catalog.catalog import Catalog, ScanResult
from radiens_drive_catalog.exceptions import CatalogError, EntryNotFoundError

if TYPE_CHECKING:
    from collections.abc import Callable

    from radiens_drive_catalog.config import Config
    from radiens_drive_catalog.drive import AssetEntry, DatasetEntry


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FOUR_ENTRIES: list[DatasetEntry] = [
    {
        "base_name": "rat01_s1",
        "drive_path": "2026-02/reaching",
        "drive_file_ids": {"data": "d1", "meta": "m1", "timestamp": "t1"},
        "local_path": None,
    },
    {
        "base_name": "rat02_s1",
        "drive_path": "2026-02/baseline",
        "drive_file_ids": {"data": "d2", "meta": "m2", "timestamp": "t2"},
        "local_path": None,
    },
    {
        "base_name": "rat03_s1",
        "drive_path": "2026-02/reaching",
        "drive_file_ids": {"data": "d3", "meta": "m3", "timestamp": "t3"},
        "local_path": None,
    },
    {
        "base_name": "rat04_s1",
        "drive_path": "2026-03/reaching",
        "drive_file_ids": {"data": "d4", "meta": "m4", "timestamp": "t4"},
        "local_path": None,
    },
]

TWO_ASSETS: list[AssetEntry] = [
    {
        "asset_name": "logs",
        "asset_type": "folder",
        "drive_path": "2026-02/reaching",
        "drive_id": "logs_drive_id",
        "mime_type": "application/vnd.google-apps.folder",
        "local_path": None,
    },
    {
        "asset_name": "notes.pptx",
        "asset_type": "file",
        "drive_path": "2026-03/reaching",
        "drive_id": "pptx_drive_id",
        "mime_type": "application/vnd.ms-powerpoint",
        "local_path": None,
    },
]


def _write_catalog_legacy(path: Path, entries: list[DatasetEntry]) -> None:
    """Write old flat-list catalog format (for migration tests)."""
    with open(path, "w") as f:
        json.dump(entries, f)


def _write_catalog(path: Path, datasets: list[DatasetEntry], assets: list[AssetEntry] | None = None) -> None:
    """Write new-format catalog JSON."""
    with open(path, "w") as f:
        json.dump({"datasets": datasets, "assets": assets or []}, f)


def _make_catalog(config: Config) -> Catalog:
    """Return a Catalog with _service pre-injected so Drive API is never called."""
    catalog = Catalog(config)
    catalog._service = MagicMock()
    return catalog


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestCatalogInit:
    def test_service_is_none_before_first_use(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = Catalog(config)
        assert catalog._service is None

    def test_df_cache_is_none_before_first_access(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = Catalog(config)
        assert catalog._df is None

    def test_assets_df_cache_is_none_before_first_access(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = Catalog(config)
        assert catalog._assets_df is None

    def test_quiet_defaults_to_false(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = Catalog(config)
        assert catalog._quiet is False

    def test_quiet_stored_when_set(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = Catalog(config, quiet=True)
        assert catalog._quiet is True

    def test_quiet_threaded_to_download_dataset(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)
        catalog._quiet = True

        with patch("radiens_drive_catalog.catalog.download_dataset", return_value="/dl") as mock_dl:
            catalog.download_dataset(FOUR_ENTRIES[0]["drive_path"], FOUR_ENTRIES[0]["base_name"])

        mock_dl.assert_called_once()
        assert mock_dl.call_args.kwargs.get("quiet") is True

    def test_quiet_threaded_to_download_asset(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)
        catalog._quiet = True

        with patch("radiens_drive_catalog.catalog._download_asset_entry", return_value="/dl") as mock_dl:
            catalog.download_asset(TWO_ASSETS[0]["drive_path"], TWO_ASSETS[0]["asset_name"])

        mock_dl.assert_called_once()
        assert mock_dl.call_args.kwargs.get("quiet") is True


class TestLoadCatalog:
    def test_loads_valid_new_format(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:2], TWO_ASSETS[:1])
        catalog = _make_catalog(config)
        datasets, assets = catalog._load_catalog()
        assert len(datasets) == 2
        assert datasets[0]["base_name"] == "rat01_s1"
        assert len(assets) == 1
        assert assets[0]["asset_name"] == "logs"

    def test_legacy_format_migrated_to_datasets(self, make_config: Callable[..., Config]) -> None:
        # Old flat-list format — treated as datasets with empty assets
        config = make_config()
        _write_catalog_legacy(Path(config.catalog_path), FOUR_ENTRIES[:2])
        catalog = _make_catalog(config)
        datasets, assets = catalog._load_catalog()
        assert len(datasets) == 2
        assert assets == []

    def test_raises_if_top_level_is_unexpected_type(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        with open(config.catalog_path, "w") as f:
            json.dump("a string", f)
        catalog = _make_catalog(config)
        with pytest.raises(CatalogError):
            catalog._load_catalog()

    def test_raises_if_entry_not_dict(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        with open(config.catalog_path, "w") as f:
            json.dump(["not_a_dict"], f)
        catalog = _make_catalog(config)
        with pytest.raises(CatalogError, match="must be an object"):
            catalog._load_catalog()

    def test_raises_if_base_name_missing(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        bad: dict[str, object] = {"drive_path": "x", "drive_file_ids": {}}
        with open(config.catalog_path, "w") as f:
            json.dump([bad], f)
        catalog = _make_catalog(config)
        with pytest.raises(CatalogError, match="base_name"):
            catalog._load_catalog()

    def test_raises_if_base_name_wrong_type(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        bad: dict[str, object] = {"base_name": 123, "drive_path": "x", "drive_file_ids": {}}
        with open(config.catalog_path, "w") as f:
            json.dump([bad], f)
        catalog = _make_catalog(config)
        with pytest.raises(CatalogError, match="base_name"):
            catalog._load_catalog()

    def test_raises_if_drive_path_missing(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        bad: dict[str, object] = {"base_name": "rat01", "drive_file_ids": {}}
        with open(config.catalog_path, "w") as f:
            json.dump([bad], f)
        catalog = _make_catalog(config)
        with pytest.raises(CatalogError, match="drive_path"):
            catalog._load_catalog()

    def test_raises_if_local_path_wrong_type(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        bad: dict[str, object] = {"base_name": "r", "drive_path": "x", "drive_file_ids": {}, "local_path": 42}
        with open(config.catalog_path, "w") as f:
            json.dump([bad], f)
        catalog = _make_catalog(config)
        with pytest.raises(CatalogError, match="local_path"):
            catalog._load_catalog()

    def test_raises_if_drive_file_ids_not_dict(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        bad: dict[str, object] = {"base_name": "r", "drive_path": "x", "drive_file_ids": "oops"}
        with open(config.catalog_path, "w") as f:
            json.dump([bad], f)
        catalog = _make_catalog(config)
        with pytest.raises(CatalogError, match="drive_file_ids"):
            catalog._load_catalog()

    def test_raises_if_drive_file_ids_value_not_string(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        bad: dict[str, object] = {"base_name": "r", "drive_path": "x", "drive_file_ids": {"data": 123}}
        with open(config.catalog_path, "w") as f:
            json.dump([bad], f)
        catalog = _make_catalog(config)
        with pytest.raises(CatalogError, match="drive_file_ids"):
            catalog._load_catalog()

    def test_null_local_path_accepted(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        entry: dict[str, object] = {"base_name": "r", "drive_path": "x", "drive_file_ids": {}, "local_path": None}
        with open(config.catalog_path, "w") as f:
            json.dump([entry], f)
        catalog = _make_catalog(config)
        datasets, _ = catalog._load_catalog()
        assert datasets[0]["local_path"] is None

    def test_legacy_date_folder_experiment_fields_silently_ignored(self, make_config: Callable[..., Config]) -> None:
        # Old catalog entries with date_folder/experiment are accepted without error
        config = make_config()
        old_entry: dict[str, object] = {
            "base_name": "r",
            "date_folder": "2026-02",
            "experiment": "reaching",
            "drive_path": "2026-02/reaching",
            "drive_file_ids": {},
            "local_path": None,
        }
        with open(config.catalog_path, "w") as f:
            json.dump([old_entry], f)
        catalog = _make_catalog(config)
        datasets, _ = catalog._load_catalog()
        assert datasets[0]["base_name"] == "r"
        assert datasets[0]["drive_path"] == "2026-02/reaching"

    def test_raises_if_asset_name_missing(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        bad_asset: dict[str, object] = {
            "asset_type": "file",
            "drive_path": "x",
            "drive_id": "id1",
            "mime_type": "text/plain",
        }
        with open(config.catalog_path, "w") as f:
            json.dump({"datasets": [], "assets": [bad_asset]}, f)
        catalog = _make_catalog(config)
        with pytest.raises(CatalogError, match="asset_name"):
            catalog._load_catalog()

    def test_raises_if_asset_type_invalid(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        bad_asset: dict[str, object] = {
            "asset_name": "logs",
            "asset_type": "unknown",
            "drive_path": "x",
            "drive_id": "id1",
            "mime_type": "text/plain",
        }
        with open(config.catalog_path, "w") as f:
            json.dump({"datasets": [], "assets": [bad_asset]}, f)
        catalog = _make_catalog(config)
        with pytest.raises(CatalogError, match="asset_type"):
            catalog._load_catalog()


class TestDfProperty:
    def test_returns_dataframe(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:2])
        catalog = _make_catalog(config)
        assert isinstance(catalog.df, pd.DataFrame)

    def test_correct_columns(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)
        expected = {"base_name", "drive_path", "drive_file_ids", "local_path"}
        assert expected.issubset(set(catalog.df.columns))

    def test_no_date_folder_or_experiment_columns(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)
        assert "date_folder" not in catalog.df.columns
        assert "experiment" not in catalog.df.columns

    def test_cached_after_first_access(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)
        df1 = catalog.df
        df2 = catalog.df
        assert df1 is df2

    def test_cache_cleared_by_invalidate(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)
        _ = catalog.df  # populate cache
        catalog._invalidate_cache()
        assert catalog._df is None


class TestAssetsDfProperty:
    def test_returns_dataframe(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)
        assert isinstance(catalog.assets_df, pd.DataFrame)

    def test_correct_columns(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)
        expected = {
            "asset_name",
            "asset_type",
            "drive_path",
            "drive_id",
            "mime_type",
            "local_path",
        }
        assert expected.issubset(set(catalog.assets_df.columns))

    def test_no_date_folder_or_experiment_columns(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)
        assert "date_folder" not in catalog.assets_df.columns
        assert "experiment" not in catalog.assets_df.columns

    def test_cached_after_first_access(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)
        adf1 = catalog.assets_df
        adf2 = catalog.assets_df
        assert adf1 is adf2

    def test_cache_cleared_by_invalidate(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)
        _ = catalog.assets_df
        catalog._invalidate_cache()
        assert catalog._assets_df is None


class TestListDatasets:
    def test_no_filters_returns_all(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES)
        catalog = _make_catalog(config)
        result = catalog.list_datasets()
        assert len(result) == 4

    def test_exact_drive_path(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES)
        catalog = _make_catalog(config)
        result = catalog.list_datasets(drive_path="2026-02/reaching")
        assert len(result) == 2
        assert all(result["drive_path"] == "2026-02/reaching")

    def test_drive_path_prefix(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES)
        catalog = _make_catalog(config)
        result = catalog.list_datasets(drive_path_prefix="2026-02")
        assert len(result) == 3

    def test_drive_path_contains(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES)
        catalog = _make_catalog(config)
        result = catalog.list_datasets(drive_path_contains="reaching")
        assert len(result) == 3

    def test_multiple_filters_are_anded(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES)
        catalog = _make_catalog(config)
        result = catalog.list_datasets(drive_path_prefix="2026-02", drive_path_contains="reaching")
        assert len(result) == 2
        assert all(result["drive_path"] == "2026-02/reaching")

    def test_no_matches_returns_empty_dataframe(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES)
        catalog = _make_catalog(config)
        result = catalog.list_datasets(drive_path="nonexistent/path")
        assert len(result) == 0

    def test_index_is_reset(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES)
        catalog = _make_catalog(config)
        result = catalog.list_datasets(drive_path_contains="reaching")
        assert list(result.index) == list(range(len(result)))


class TestListAssets:
    def test_no_filters_returns_all(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)
        result = catalog.list_assets()
        assert len(result) == 2

    def test_exact_drive_path(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)
        result = catalog.list_assets(drive_path="2026-02/reaching")
        assert len(result) == 1
        assert result.iloc[0]["asset_name"] == "logs"

    def test_drive_path_prefix(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)
        result = catalog.list_assets(drive_path_prefix="2026-02")
        assert len(result) == 1

    def test_drive_path_contains(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)
        result = catalog.list_assets(drive_path_contains="reaching")
        assert len(result) == 2

    def test_asset_type_folder(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)
        result = catalog.list_assets(asset_type="folder")
        assert len(result) == 1
        assert result.iloc[0]["asset_type"] == "folder"

    def test_asset_type_file(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)
        result = catalog.list_assets(asset_type="file")
        assert len(result) == 1
        assert result.iloc[0]["asset_type"] == "file"

    def test_multiple_filters_are_anded(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)
        result = catalog.list_assets(drive_path_contains="reaching", asset_type="file")
        assert len(result) == 1
        assert result.iloc[0]["asset_name"] == "notes.pptx"

    def test_no_matches_returns_empty_dataframe(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)
        result = catalog.list_assets(drive_path="nonexistent/path")
        assert len(result) == 0

    def test_index_is_reset(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)
        result = catalog.list_assets(asset_type="file")
        assert list(result.index) == list(range(len(result)))


class TestScan:
    def test_writes_catalog_json(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = _make_catalog(config)
        new_datasets = FOUR_ENTRIES[:2]

        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=(new_datasets, [])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert len(saved["datasets"]) == 2
        assert saved["assets"] == []

    def test_writes_assets_to_catalog(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = _make_catalog(config)

        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([], TWO_ASSETS)):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert len(saved["assets"]) == 2

    def test_preserves_existing_dataset_local_paths(self, tmp_path: Path, make_config: Callable[..., Config]) -> None:
        config = make_config()
        recorded_dir = tmp_path / "recorded_data"
        recorded_dir.mkdir()
        existing: list[DatasetEntry] = [{**FOUR_ENTRIES[0], "local_path": str(recorded_dir)}]
        _write_catalog(Path(config.catalog_path), existing)
        catalog = _make_catalog(config)

        new_entry: DatasetEntry = {**FOUR_ENTRIES[0], "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([new_entry], [])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["datasets"][0]["local_path"] == str(recorded_dir)

    def test_preserves_existing_asset_local_paths(self, tmp_path: Path, make_config: Callable[..., Config]) -> None:
        config = make_config()
        recorded_dir = tmp_path / "recorded_logs"
        recorded_dir.mkdir()
        existing_assets: list[AssetEntry] = [{**TWO_ASSETS[0], "local_path": str(recorded_dir)}]
        _write_catalog(Path(config.catalog_path), [], existing_assets)
        catalog = _make_catalog(config)

        new_asset: AssetEntry = {**TWO_ASSETS[0], "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([], [new_asset])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["assets"][0]["local_path"] == str(recorded_dir)

    def test_new_dataset_has_null_local_path(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = _make_catalog(config)
        new_entry: DatasetEntry = {**FOUR_ENTRIES[0], "local_path": None}

        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([new_entry], [])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["datasets"][0]["local_path"] is None

    def test_scan_invalidates_df_cache(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)
        _ = catalog.df  # populate cache
        assert catalog._df is not None

        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=(FOUR_ENTRIES[:1], [])):
            catalog.scan()

        assert catalog._df is None

    def test_scan_invalidates_assets_df_cache(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)
        _ = catalog.assets_df  # populate cache
        assert catalog._assets_df is not None

        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=(FOUR_ENTRIES[:1], TWO_ASSETS[:1])):
            catalog.scan()

        assert catalog._assets_df is None

    def test_scan_works_with_no_existing_catalog(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = _make_catalog(config)
        assert not Path(config.catalog_path).exists()

        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=(FOUR_ENTRIES[:1], [])):
            catalog.scan()  # should not raise

        assert Path(config.catalog_path).exists()

    def test_scan_drops_stale_entries(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:2])
        catalog = _make_catalog(config)

        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([FOUR_ENTRIES[1]], [])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert len(saved["datasets"]) == 1
        assert saved["datasets"][0]["base_name"] == FOUR_ENTRIES[1]["base_name"]

    def test_scan_migrates_legacy_catalog_format(self, tmp_path: Path, make_config: Callable[..., Config]) -> None:
        config = make_config()
        recorded_dir = tmp_path / "legacy_data"
        recorded_dir.mkdir()
        existing: list[DatasetEntry] = [{**FOUR_ENTRIES[0], "local_path": str(recorded_dir)}]
        _write_catalog_legacy(Path(config.catalog_path), existing)
        catalog = _make_catalog(config)

        new_entry: DatasetEntry = {**FOUR_ENTRIES[0], "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([new_entry], [])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        # Now saved in new format; local_path preserved from legacy
        assert isinstance(saved, dict)
        assert saved["datasets"][0]["local_path"] == str(recorded_dir)

    def test_scan_recursive_flag_uses_recursive_scanner(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = _make_catalog(config)

        with patch("radiens_drive_catalog.catalog.scan_drive", return_value=(FOUR_ENTRIES[:1], [])) as rec_mock:
            catalog.scan(flat=False)

        rec_mock.assert_called_once()
        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert len(saved["datasets"]) == 1

    # ------------------------------------------------------------------
    # Disk reconciliation: catalog deleted or stale recorded paths
    # ------------------------------------------------------------------

    def test_scan_discovers_dataset_on_disk_when_no_catalog(
        self, tmp_path: Path, make_config: Callable[..., Config]
    ) -> None:
        config = make_config()
        # Create data at the canonical expected location
        ds = FOUR_ENTRIES[0]
        expected_dir = Path(config.local_data_dir) / ds["drive_path"]
        expected_dir.mkdir(parents=True)
        assert not Path(config.catalog_path).exists()
        catalog = _make_catalog(config)

        new_entry: DatasetEntry = {**ds, "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([new_entry], [])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["datasets"][0]["local_path"] == str(expected_dir)

    def test_scan_null_dataset_local_path_when_no_catalog_and_no_disk(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        assert not Path(config.catalog_path).exists()
        catalog = _make_catalog(config)

        new_entry: DatasetEntry = {**FOUR_ENTRIES[0], "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([new_entry], [])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["datasets"][0]["local_path"] is None

    def test_scan_clears_stale_dataset_local_path(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        existing: list[DatasetEntry] = [{**FOUR_ENTRIES[0], "local_path": "/definitely/does/not/exist"}]
        _write_catalog(Path(config.catalog_path), existing)
        catalog = _make_catalog(config)

        new_entry: DatasetEntry = {**FOUR_ENTRIES[0], "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([new_entry], [])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["datasets"][0]["local_path"] is None

    def test_scan_recovers_dataset_from_expected_path_when_recorded_stale(
        self, make_config: Callable[..., Config]
    ) -> None:
        config = make_config()
        # Catalog says one path, but the expected canonical path has the data
        ds = FOUR_ENTRIES[0]
        existing: list[DatasetEntry] = [{**ds, "local_path": "/definitely/does/not/exist"}]
        _write_catalog(Path(config.catalog_path), existing)
        expected_dir = Path(config.local_data_dir) / ds["drive_path"]
        expected_dir.mkdir(parents=True)
        catalog = _make_catalog(config)

        new_entry: DatasetEntry = {**ds, "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([new_entry], [])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["datasets"][0]["local_path"] == str(expected_dir)

    def test_scan_discovers_asset_on_disk_when_no_catalog(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        asset = TWO_ASSETS[0]
        expected_path = Path(config.local_data_dir) / "assets" / asset["drive_path"] / asset["asset_name"]
        expected_path.mkdir(parents=True)
        assert not Path(config.catalog_path).exists()
        catalog = _make_catalog(config)

        new_asset: AssetEntry = {**asset, "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([], [new_asset])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["assets"][0]["local_path"] == str(expected_path)

    def test_scan_null_asset_local_path_when_no_catalog_and_no_disk(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        assert not Path(config.catalog_path).exists()
        catalog = _make_catalog(config)

        new_asset: AssetEntry = {**TWO_ASSETS[0], "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([], [new_asset])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["assets"][0]["local_path"] is None

    def test_scan_clears_stale_asset_local_path(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        existing_assets: list[AssetEntry] = [{**TWO_ASSETS[0], "local_path": "/definitely/does/not/exist"}]
        _write_catalog(Path(config.catalog_path), [], existing_assets)
        catalog = _make_catalog(config)

        new_asset: AssetEntry = {**TWO_ASSETS[0], "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([], [new_asset])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["assets"][0]["local_path"] is None

    def test_scan_recovers_asset_from_expected_path_when_recorded_stale(
        self, make_config: Callable[..., Config]
    ) -> None:
        config = make_config()
        asset = TWO_ASSETS[0]
        existing_assets: list[AssetEntry] = [{**asset, "local_path": "/definitely/does/not/exist"}]
        _write_catalog(Path(config.catalog_path), [], existing_assets)
        expected_path = Path(config.local_data_dir) / "assets" / asset["drive_path"] / asset["asset_name"]
        expected_path.mkdir(parents=True)
        catalog = _make_catalog(config)

        new_asset: AssetEntry = {**asset, "local_path": None}
        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=([], [new_asset])):
            catalog.scan()

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["assets"][0]["local_path"] == str(expected_path)

    def test_scan_returns_scan_result(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = _make_catalog(config)

        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=(FOUR_ENTRIES[:2], TWO_ASSETS[:1])):
            result = catalog.scan()

        assert isinstance(result, ScanResult)
        # No prior catalog — all entries are new
        assert result.datasets_new == 2
        assert result.datasets_existing == 0
        assert result.datasets_removed == 0
        assert result.assets_new == 1
        assert result.assets_existing == 0
        assert result.assets_removed == 0

    def test_scan_result_counts_new_existing_removed(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        # Pre-populate with entries [0] and [1]; rescan returns [1] and [2] → [0] removed, [2] new, [1] existing
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:2])
        catalog = _make_catalog(config)

        with patch("radiens_drive_catalog.catalog.scan_drive_flat", return_value=(FOUR_ENTRIES[1:3], [])):
            result = catalog.scan()

        assert result.datasets_new == 1
        assert result.datasets_existing == 1
        assert result.datasets_removed == 1
        assert result.assets_new == 0
        assert result.assets_existing == 0
        assert result.assets_removed == 0

    def test_scan_result_str(self) -> None:
        result = ScanResult(
            datasets_new=3,
            datasets_existing=5,
            datasets_removed=1,
            assets_new=2,
            assets_existing=4,
            assets_removed=0,
        )
        s = str(result)
        assert "datasets" in s
        assert "assets" in s
        assert "new" in s
        assert "existing" in s
        assert "removed" in s
        # spot-check values appear
        assert "3" in s
        assert "5" in s


class TestDownloadDataset:
    def test_returns_local_path(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)

        with patch("radiens_drive_catalog.catalog.download_dataset", return_value="/downloaded"):
            result = catalog.download_dataset(FOUR_ENTRIES[0]["drive_path"], FOUR_ENTRIES[0]["base_name"])

        assert result == "/downloaded"

    def test_updates_local_path_in_catalog(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)

        with patch("radiens_drive_catalog.catalog.download_dataset", return_value="/downloaded"):
            catalog.download_dataset(FOUR_ENTRIES[0]["drive_path"], FOUR_ENTRIES[0]["base_name"])

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["datasets"][0]["local_path"] == "/downloaded"

    def test_download_invalidates_df_cache(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)
        _ = catalog.df  # populate cache
        assert catalog._df is not None

        with patch("radiens_drive_catalog.catalog.download_dataset", return_value="/dl"):
            catalog.download_dataset(FOUR_ENTRIES[0]["drive_path"], FOUR_ENTRIES[0]["base_name"])

        assert catalog._df is None

    def test_raises_for_unknown_dataset(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)

        with pytest.raises(EntryNotFoundError, match="not found"):
            catalog.download_dataset("nonexistent/path", "nonexistent_dataset")


class TestGetDatasetPath:
    def test_returns_existing_local_path(self, tmp_path: Path, make_config: Callable[..., Config]) -> None:
        config = make_config()
        local_dir = tmp_path / "existing_data"
        local_dir.mkdir()
        entry: DatasetEntry = {**FOUR_ENTRIES[0], "local_path": str(local_dir)}
        _write_catalog(Path(config.catalog_path), [entry])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset") as mock_dl:
            result = catalog.get_dataset_path(FOUR_ENTRIES[0]["drive_path"], FOUR_ENTRIES[0]["base_name"])

        assert result == str(local_dir)
        mock_dl.assert_not_called()

    def test_downloads_if_local_path_is_none(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        entry: DatasetEntry = {**FOUR_ENTRIES[0], "local_path": None}
        _write_catalog(Path(config.catalog_path), [entry])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset", return_value="/dl") as mock_dl:
            catalog.get_dataset_path(FOUR_ENTRIES[0]["drive_path"], FOUR_ENTRIES[0]["base_name"])

        mock_dl.assert_called_once_with(FOUR_ENTRIES[0]["drive_path"], FOUR_ENTRIES[0]["base_name"])

    def test_downloads_if_path_does_not_exist(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        entry: DatasetEntry = {**FOUR_ENTRIES[0], "local_path": "/definitely/does/not/exist"}
        _write_catalog(Path(config.catalog_path), [entry])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset", return_value="/dl") as mock_dl:
            catalog.get_dataset_path(FOUR_ENTRIES[0]["drive_path"], FOUR_ENTRIES[0]["base_name"])

        mock_dl.assert_called_once()

    def test_does_not_download_if_path_exists(self, tmp_path: Path, make_config: Callable[..., Config]) -> None:
        config = make_config()
        local_dir = tmp_path / "data"
        local_dir.mkdir()
        entry: DatasetEntry = {**FOUR_ENTRIES[0], "local_path": str(local_dir)}
        _write_catalog(Path(config.catalog_path), [entry])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset") as mock_dl:
            catalog.get_dataset_path(FOUR_ENTRIES[0]["drive_path"], FOUR_ENTRIES[0]["base_name"])

        mock_dl.assert_not_called()

    def test_raises_for_unknown_dataset(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES[:1])
        catalog = _make_catalog(config)

        with pytest.raises(EntryNotFoundError, match="not found"):
            catalog.get_dataset_path("nonexistent/path", "nonexistent")


class TestDownloadAsset:
    def test_returns_local_path(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)

        with patch("radiens_drive_catalog.catalog._download_asset_entry", return_value="/assets/logs"):
            result = catalog.download_asset(TWO_ASSETS[0]["drive_path"], TWO_ASSETS[0]["asset_name"])

        assert result == "/assets/logs"

    def test_updates_local_path_in_catalog(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)

        with patch("radiens_drive_catalog.catalog._download_asset_entry", return_value="/assets/logs"):
            catalog.download_asset(TWO_ASSETS[0]["drive_path"], TWO_ASSETS[0]["asset_name"])

        with open(config.catalog_path) as f:
            saved = json.load(f)
        assert saved["assets"][0]["local_path"] == "/assets/logs"

    def test_download_asset_invalidates_cache(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)
        _ = catalog.assets_df
        assert catalog._assets_df is not None

        with patch("radiens_drive_catalog.catalog._download_asset_entry", return_value="/dl"):
            catalog.download_asset(TWO_ASSETS[0]["drive_path"], TWO_ASSETS[0]["asset_name"])

        assert catalog._assets_df is None

    def test_raises_for_unknown_asset(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)

        with pytest.raises(EntryNotFoundError, match="not found"):
            catalog.download_asset("nonexistent/path", "nonexistent_asset")


class TestGetAssetPath:
    def test_returns_existing_local_path(self, tmp_path: Path, make_config: Callable[..., Config]) -> None:
        config = make_config()
        local_path = tmp_path / "assets" / "logs"
        local_path.mkdir(parents=True)
        asset: AssetEntry = {**TWO_ASSETS[0], "local_path": str(local_path)}
        _write_catalog(Path(config.catalog_path), [], [asset])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_asset") as mock_dl:
            result = catalog.get_asset_path(TWO_ASSETS[0]["drive_path"], TWO_ASSETS[0]["asset_name"])

        assert result == str(local_path)
        mock_dl.assert_not_called()

    def test_downloads_if_local_path_is_none(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        asset: AssetEntry = {**TWO_ASSETS[0], "local_path": None}
        _write_catalog(Path(config.catalog_path), [], [asset])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_asset", return_value="/dl") as mock_dl:
            catalog.get_asset_path(TWO_ASSETS[0]["drive_path"], TWO_ASSETS[0]["asset_name"])

        mock_dl.assert_called_once_with(TWO_ASSETS[0]["drive_path"], TWO_ASSETS[0]["asset_name"])

    def test_downloads_if_path_does_not_exist(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        asset: AssetEntry = {**TWO_ASSETS[0], "local_path": "/definitely/does/not/exist"}
        _write_catalog(Path(config.catalog_path), [], [asset])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_asset", return_value="/dl") as mock_dl:
            catalog.get_asset_path(TWO_ASSETS[0]["drive_path"], TWO_ASSETS[0]["asset_name"])

        mock_dl.assert_called_once()

    def test_raises_for_unknown_asset(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS[:1])
        catalog = _make_catalog(config)

        with pytest.raises(EntryNotFoundError, match="not found"):
            catalog.get_asset_path("bad/path", "nonexistent")


class TestPrefetch:
    """Tests for Catalog.prefetch() — bulk, idempotent download."""

    def test_empty_catalog_returns_all_zeros(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], [])
        catalog = _make_catalog(config)

        with (
            patch.object(catalog, "download_dataset") as mock_ds,
            patch.object(catalog, "download_asset") as mock_asset,
        ):
            result = catalog.prefetch()

        assert result.datasets_downloaded == 0
        assert result.datasets_skipped == 0
        assert result.assets_downloaded == 0
        assert result.assets_skipped == 0
        mock_ds.assert_not_called()
        mock_asset.assert_not_called()

    def test_no_filters_downloads_everything(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES, TWO_ASSETS)
        catalog = _make_catalog(config)

        with (
            patch.object(catalog, "download_dataset", return_value="/dl") as mock_ds,
            patch.object(catalog, "download_asset", return_value="/dl") as mock_asset,
        ):
            result = catalog.prefetch()

        assert result.datasets_downloaded == 4
        assert result.assets_downloaded == 2
        assert mock_ds.call_count == 4
        assert mock_asset.call_count == 2

    def test_skips_already_local_datasets(self, make_config: Callable[..., Config], tmp_path: Path) -> None:
        config = make_config()
        existing = tmp_path / "existing"
        existing.mkdir()
        ds_entries: list[DatasetEntry] = [
            {**FOUR_ENTRIES[0], "local_path": str(existing)},
            FOUR_ENTRIES[1],
        ]
        _write_catalog(Path(config.catalog_path), ds_entries, [])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset", return_value="/dl") as mock_ds:
            result = catalog.prefetch()

        assert result.datasets_downloaded == 1
        assert result.datasets_skipped == 1
        mock_ds.assert_called_once_with(FOUR_ENTRIES[1]["drive_path"], FOUR_ENTRIES[1]["base_name"])

    def test_skips_already_local_assets(self, make_config: Callable[..., Config], tmp_path: Path) -> None:
        config = make_config()
        existing = tmp_path / "existing_asset"
        existing.mkdir()
        asset_entries: list[AssetEntry] = [
            {**TWO_ASSETS[0], "local_path": str(existing)},
            TWO_ASSETS[1],
        ]
        _write_catalog(Path(config.catalog_path), [], asset_entries)
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_asset", return_value="/dl") as mock_asset:
            result = catalog.prefetch()

        assert result.assets_downloaded == 1
        assert result.assets_skipped == 1
        mock_asset.assert_called_once_with(TWO_ASSETS[1]["drive_path"], TWO_ASSETS[1]["asset_name"])

    def test_local_path_set_but_missing_triggers_download(self, make_config: Callable[..., Config]) -> None:
        # local_path is set but the path doesn't exist on disk — should redownload
        config = make_config()
        entry: DatasetEntry = {**FOUR_ENTRIES[0], "local_path": "/definitely/not/there"}
        _write_catalog(Path(config.catalog_path), [entry], [])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset", return_value="/dl") as mock_ds:
            result = catalog.prefetch()

        assert result.datasets_downloaded == 1
        assert result.datasets_skipped == 0
        mock_ds.assert_called_once()

    def test_datasets_false_skips_dataset_downloads(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES, TWO_ASSETS)
        catalog = _make_catalog(config)

        with (
            patch.object(catalog, "download_dataset") as mock_ds,
            patch.object(catalog, "download_asset", return_value="/dl") as mock_asset,
        ):
            result = catalog.prefetch(datasets=False)

        mock_ds.assert_not_called()
        assert result.datasets_downloaded == 0
        assert mock_asset.call_count == 2
        assert result.assets_downloaded == 2

    def test_assets_false_skips_asset_downloads(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES, TWO_ASSETS)
        catalog = _make_catalog(config)

        with (
            patch.object(catalog, "download_dataset", return_value="/dl") as mock_ds,
            patch.object(catalog, "download_asset") as mock_asset,
        ):
            result = catalog.prefetch(assets=False)

        mock_asset.assert_not_called()
        assert result.assets_downloaded == 0
        assert mock_ds.call_count == 4
        assert result.datasets_downloaded == 4

    def test_drive_path_exact_filter(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES, [])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset", return_value="/dl") as mock_ds:
            result = catalog.prefetch(drive_path="2026-02/reaching")

        assert result.datasets_downloaded == 2
        called_paths = {c.args[0] for c in mock_ds.call_args_list}
        assert called_paths == {"2026-02/reaching"}

    def test_drive_path_prefix_filter(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES, [])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset", return_value="/dl") as mock_ds:
            result = catalog.prefetch(drive_path_prefix="2026-02")

        assert result.datasets_downloaded == 3
        assert mock_ds.call_count == 3

    def test_drive_path_contains_filter(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES, [])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset", return_value="/dl") as mock_ds:
            result = catalog.prefetch(drive_path_contains="reaching")

        assert result.datasets_downloaded == 3
        assert mock_ds.call_count == 3

    def test_asset_type_filter(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        _write_catalog(Path(config.catalog_path), [], TWO_ASSETS)
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_asset", return_value="/dl") as mock_asset:
            result = catalog.prefetch(asset_type="folder")

        assert result.assets_downloaded == 1
        mock_asset.assert_called_once_with(TWO_ASSETS[0]["drive_path"], TWO_ASSETS[0]["asset_name"])

    def test_filters_compose_across_datasets_and_assets(self, make_config: Callable[..., Config]) -> None:
        # Same drive_path filters apply to both categories
        config = make_config()
        _write_catalog(Path(config.catalog_path), FOUR_ENTRIES, TWO_ASSETS)
        catalog = _make_catalog(config)

        with (
            patch.object(catalog, "download_dataset", return_value="/dl") as mock_ds,
            patch.object(catalog, "download_asset", return_value="/dl") as mock_asset,
        ):
            result = catalog.prefetch(drive_path="2026-02/reaching")

        assert result.datasets_downloaded == 2
        assert result.assets_downloaded == 1  # only logs/ is at 2026-02/reaching
        assert mock_ds.call_count == 2
        assert mock_asset.call_count == 1

    def test_idempotent_second_call_is_noop(self, make_config: Callable[..., Config], tmp_path: Path) -> None:
        # All entries already local → second call downloads nothing
        config = make_config()
        existing_ds = tmp_path / "ds_local"
        existing_ds.mkdir()
        existing_asset = tmp_path / "asset_local"
        existing_asset.mkdir()

        ds_entries: list[DatasetEntry] = [{**FOUR_ENTRIES[0], "local_path": str(existing_ds)}]
        asset_entries: list[AssetEntry] = [{**TWO_ASSETS[0], "local_path": str(existing_asset)}]
        _write_catalog(Path(config.catalog_path), ds_entries, asset_entries)
        catalog = _make_catalog(config)

        with (
            patch.object(catalog, "download_dataset") as mock_ds,
            patch.object(catalog, "download_asset") as mock_asset,
        ):
            result = catalog.prefetch()

        mock_ds.assert_not_called()
        mock_asset.assert_not_called()
        assert result.datasets_skipped == 1
        assert result.assets_skipped == 1

    def test_force_downloads_even_when_already_local(self, make_config: Callable[..., Config], tmp_path: Path) -> None:
        config = make_config()
        existing_ds = tmp_path / "ds_local"
        existing_ds.mkdir()
        existing_asset = tmp_path / "asset_local"
        existing_asset.mkdir()

        ds_entries: list[DatasetEntry] = [{**FOUR_ENTRIES[0], "local_path": str(existing_ds)}]
        asset_entries: list[AssetEntry] = [{**TWO_ASSETS[0], "local_path": str(existing_asset)}]
        _write_catalog(Path(config.catalog_path), ds_entries, asset_entries)
        catalog = _make_catalog(config)

        with (
            patch.object(catalog, "download_dataset", return_value="/dl") as mock_ds,
            patch.object(catalog, "download_asset", return_value="/dl") as mock_asset,
        ):
            result = catalog.prefetch(force=True)

        mock_ds.assert_called_once()
        mock_asset.assert_called_once()
        assert result.datasets_downloaded == 1
        assert result.datasets_skipped == 0
        assert result.assets_downloaded == 1
        assert result.assets_skipped == 0

    def test_force_false_is_default_behavior(self, make_config: Callable[..., Config], tmp_path: Path) -> None:
        config = make_config()
        existing_ds = tmp_path / "ds_local"
        existing_ds.mkdir()
        ds_entries: list[DatasetEntry] = [{**FOUR_ENTRIES[0], "local_path": str(existing_ds)}]
        _write_catalog(Path(config.catalog_path), ds_entries, [])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset") as mock_ds:
            result = catalog.prefetch(force=False)

        mock_ds.assert_not_called()
        assert result.datasets_skipped == 1
        assert result.datasets_downloaded == 0

    def test_force_with_prefix_filter_only_affects_matching(
        self, make_config: Callable[..., Config], tmp_path: Path
    ) -> None:
        config = make_config()
        existing = tmp_path / "existing"
        existing.mkdir()
        # FOUR_ENTRIES has entries under 2026-02/* and 2026-03/*
        ds_entries: list[DatasetEntry] = [
            {**FOUR_ENTRIES[0], "local_path": str(existing)},  # 2026-02/reaching
            {**FOUR_ENTRIES[3], "local_path": str(existing)},  # 2026-03/reaching
        ]
        _write_catalog(Path(config.catalog_path), ds_entries, [])
        catalog = _make_catalog(config)

        with patch.object(catalog, "download_dataset", return_value="/dl") as mock_ds:
            result = catalog.prefetch(drive_path_prefix="2026-02", force=True)

        # Only the 2026-02 entry is re-downloaded; 2026-03 is outside the filter
        assert result.datasets_downloaded == 1
        assert result.datasets_skipped == 0
        called_paths = {c.args[0] for c in mock_ds.call_args_list}
        assert called_paths == {"2026-02/reaching"}


class TestDriveProperty:
    def test_lazy_init(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = Catalog(config)

        with patch("radiens_drive_catalog.catalog.build_drive_service") as mock_bds:
            mock_bds.return_value = MagicMock()
            _ = catalog._drive
            _ = catalog._drive

        assert mock_bds.call_count == 1

    def test_uses_credentials_path(self, make_config: Callable[..., Config]) -> None:
        config = make_config()
        catalog = Catalog(config)

        with patch("radiens_drive_catalog.catalog.build_drive_service") as mock_bds:
            mock_bds.return_value = MagicMock()
            _ = catalog._drive

        mock_bds.assert_called_once_with(config.credentials_path)
