"""
config.py
---------
Configuration management for radiens-drive-catalog.

Config is loaded from a JSON file. The file is located using the following
resolution order (first match wins):

1. Explicit *path* argument to ``Config.from_file()``.
2. ``RADIENS_DRIVE_CATALOG_CONFIG`` environment variable.
3. ``.secrets/config.json`` in the current working directory.
4. ``config.json`` in the current working directory.

Example config JSON:
{
    "credentials_path": "/path/to/service_account.json",
    "root_folder_id": "1aBcDeFgHiJkLmNoPqRsTuVw",
    "local_data_dir": "/data/neural",
    "catalog_path": "/data/neural/catalog.json"
}
"""

import json
import os
from dataclasses import dataclass
from pathlib import Path

CONFIG_ENV_VAR = "RADIENS_DRIVE_CATALOG_CONFIG"

_WELL_KNOWN_PATHS = (
    ".secrets/config.json",
    "config.json",
    "~/.config/radiens-drive/config.json",
    "/etc/radiens-drive/config.json",
)


def _resolve_path(path: str) -> str:
    """Expand environment variables and ~ then resolve to an absolute path."""
    return str(Path(os.path.expandvars(path)).expanduser().resolve())


def _discover_config() -> str:
    """Locate a config file using the standard resolution order.

    Returns:
        Resolved path to the first config file found.

    Raises:
        FileNotFoundError: If no config file can be located.
    """
    env_path = os.environ.get(CONFIG_ENV_VAR)
    if env_path is not None:
        return env_path

    cwd = Path.cwd()
    for relative in _WELL_KNOWN_PATHS:
        candidate = cwd / relative
        if candidate.is_file():
            return str(candidate)

    searched = ", ".join(_WELL_KNOWN_PATHS)
    raise FileNotFoundError(
        f"No config file found. Searched: {CONFIG_ENV_VAR} env var, "
        f"{searched} (in {cwd}). "
        f"Pass a path explicitly or set {CONFIG_ENV_VAR}=/path/to/config.json."
    )


@dataclass
class Config:
    """Configuration for radiens-drive-catalog.

    All path fields (`credentials_path`, `local_data_dir`, `catalog_path`) support
    `~` and `$ENV_VAR` expansion and are resolved to absolute paths on construction.
    Typically created via `Config.from_file()` rather than directly.

    Attributes:
        credentials_path: Path to the Google service account credentials JSON file.
        root_folder_id: Google Drive folder ID of the data root folder.
        local_data_dir: Local directory where datasets will be downloaded.
        catalog_path: Path to the catalog JSON file (created by `Catalog.scan()`).
    """

    credentials_path: str
    root_folder_id: str
    local_data_dir: str
    catalog_path: str

    def __post_init__(self) -> None:
        """Expand ~ and $ENV_VARS in all path fields and resolve to absolute paths."""
        self.credentials_path = _resolve_path(self.credentials_path)
        self.local_data_dir = _resolve_path(self.local_data_dir)
        self.catalog_path = _resolve_path(self.catalog_path)

    @classmethod
    def from_file(cls, path: str | None = None) -> "Config":
        """Load config from a JSON file.

        Resolution order when *path* is ``None``:

        1. ``RADIENS_DRIVE_CATALOG_CONFIG`` environment variable.
        2. ``.secrets/config.json`` in the current working directory.
        3. ``config.json`` in the current working directory.
        4. ``~/.config/radiens-drive/config.json`` in the user's home directory.
        5. ``/etc/radiens-drive/config.json``.

        Args:
            path: Path to the config JSON file. When ``None``, the resolution
                order above is used.

        Returns:
            A `Config` instance with all paths expanded and resolved.

        Raises:
            FileNotFoundError: If no config file can be located.
            json.JSONDecodeError: If the config file is not valid JSON.
            TypeError: If the JSON fields do not match the `Config` field names.
        """
        if path is None:
            path = _discover_config()
        path = _resolve_path(path)
        with open(path) as f:
            data = json.load(f)
        return cls(**data)
