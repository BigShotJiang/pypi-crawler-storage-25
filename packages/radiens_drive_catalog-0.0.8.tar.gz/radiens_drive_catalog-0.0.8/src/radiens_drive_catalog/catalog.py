"""
catalog.py
----------
The main interface for radiens-drive-catalog. The Catalog class wraps Drive
scanning, local caching, and downloading behind a simple API.

Typical usage:
    from radiens_drive_catalog import Catalog, Config

    config = Config.from_file("config.json")
    catalog = Catalog(config)

    # Build or refresh the catalog from Drive
    catalog.scan()

    # Query using convenience methods or pandas directly
    df = catalog.list_datasets(drive_path_prefix="2026-02-15_batch")
    assets = catalog.list_assets(asset_type="folder")

    # Get a local path, downloading if needed
    path = catalog.get_dataset_path("2026-02-15_batch/reaching", "rat01_2026-02-14_probe1")
    path = catalog.get_asset_path("2026-02-15_batch/reaching", "logs")

    # Download explicitly
    catalog.download_dataset("2026-02-15_batch/reaching", "rat01_2026-02-14_probe1")
    catalog.download_asset("2026-02-15_batch/reaching", "logs")

    # Bulk prefetch (idempotent — skips items already on disk)
    result = catalog.prefetch(drive_path_prefix="2026-02-15_batch")

    # Access the raw DataFrames
    catalog.df
    catalog.assets_df
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path

import pandas as pd
from tqdm import tqdm

from .auth import build_drive_service
from .config import Config
from .drive import (
    AssetEntry,
    DatasetEntry,
    DriveService,
    download_dataset,
    scan_drive,
    scan_drive_flat,
)
from .drive import (
    download_asset as _download_asset_entry,
)
from .exceptions import CatalogError, EntryNotFoundError

_log = logging.getLogger(__name__)


@dataclass
class PrefetchResult:
    """Summary of a :meth:`Catalog.prefetch` call.

    Attributes:
        datasets_downloaded: Number of datasets fetched from Drive.
        datasets_skipped: Number of datasets already available locally.
        assets_downloaded: Number of assets fetched from Drive.
        assets_skipped: Number of assets already available locally.
    """

    datasets_downloaded: int
    datasets_skipped: int
    assets_downloaded: int
    assets_skipped: int

    def __str__(self) -> str:
        headers = ("downloaded", "skipped")
        rows = (
            ("datasets", self.datasets_downloaded, self.datasets_skipped),
            ("assets", self.assets_downloaded, self.assets_skipped),
        )
        col_w = max(len(h) for h in headers)
        label_w = max(len(r[0]) for r in rows)
        header_line = " " * (label_w + 2) + "  ".join(h.rjust(col_w) for h in headers)
        row_lines = [f"  {label:<{label_w}}  " + "  ".join(str(v).rjust(col_w) for v in vals) for label, *vals in rows]
        return "Prefetch results:\n" + header_line + "\n" + "\n".join(row_lines)


@dataclass
class ScanResult:
    """Summary of a :meth:`Catalog.scan` call.

    Attributes:
        datasets_new: Datasets found on Drive that were not in the previous catalog.
        datasets_existing: Datasets found on Drive that were already in the catalog.
        datasets_removed: Datasets in the previous catalog that were not found on Drive.
        assets_new: Assets found on Drive that were not in the previous catalog.
        assets_existing: Assets found on Drive that were already in the catalog.
        assets_removed: Assets in the previous catalog that were not found on Drive.
    """

    datasets_new: int
    datasets_existing: int
    datasets_removed: int
    assets_new: int
    assets_existing: int
    assets_removed: int

    def __str__(self) -> str:
        headers = ("new", "existing", "removed")
        rows = (
            ("datasets", self.datasets_new, self.datasets_existing, self.datasets_removed),
            ("assets", self.assets_new, self.assets_existing, self.assets_removed),
        )
        col_w = max(len(h) for h in headers)
        label_w = max(len(r[0]) for r in rows)
        header_line = " " * (label_w + 2) + "  ".join(h.rjust(col_w) for h in headers)
        row_lines = [f"  {label:<{label_w}}  " + "  ".join(str(v).rjust(col_w) for v in vals) for label, *vals in rows]
        return "Scan results:\n" + header_line + "\n" + "\n".join(row_lines)


class Catalog:
    """Main interface for radiens-drive-catalog.

    Wraps Google Drive scanning, local JSON catalog management, and file
    download. Querying is done directly on the ``df`` and ``assets_df``
    DataFrames using standard pandas operations.

    Recordings are uniquely identified by ``(drive_path, base_name)`` where
    ``drive_path`` is the slash-joined path from the Drive root to the
    containing folder.

    Example:
        ```python
        from radiens_drive_catalog import Catalog, Config

        config = Config.from_file("config.json")
        catalog = Catalog(config)

        catalog.scan()
        hits = catalog.list_datasets(drive_path_prefix="2026-02")
        path = catalog.get_dataset_path("2026-02/reaching", "rat01")
        catalog.prefetch(drive_path_prefix="2026-02")
        ```
    """

    def __init__(self, config: Config | None = None, *, quiet: bool = False) -> None:
        """Initialize a Catalog.

        Args:
            config: Package configuration. When omitted, ``Config.from_file()``
                is called and the config file is located via the standard
                resolution order (env var → well-known paths).
            quiet: If ``True``, suppress tqdm progress bars during downloads.
        """
        if config is None:
            config = Config.from_file()
        self.config = config
        self._quiet = quiet
        self._service: DriveService | None = None  # lazy-initialized Drive client
        self._df: pd.DataFrame | None = None  # in-memory cache for datasets
        self._assets_df: pd.DataFrame | None = None  # in-memory cache for assets

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @property
    def _drive(self) -> DriveService:
        """Lazy-initialize the Drive API service."""
        if self._service is None:
            self._service = build_drive_service(self.config.credentials_path)
        return self._service

    def _invalidate_cache(self) -> None:
        self._df = None
        self._assets_df = None

    def _load_catalog(self) -> tuple[list[DatasetEntry], list[AssetEntry]]:
        """Read the catalog JSON from disk.

        Supports both the current format (``{"datasets": [...], "assets": [...]}``)
        and the legacy format (a bare list of dataset entries). Legacy catalogs
        are treated as having an empty assets list.

        Unknown fields in catalog entries (e.g. ``date_folder``, ``experiment``
        from older catalog versions) are silently ignored.
        """
        with open(self.config.catalog_path) as f:
            data = json.load(f)

        # Legacy format: bare list of dataset entries
        if isinstance(data, list):
            datasets_raw = data
            assets_raw: list[object] = []
        elif isinstance(data, dict):
            datasets_raw = data.get("datasets", [])
            assets_raw = data.get("assets", [])
            if not isinstance(datasets_raw, list):
                raise CatalogError("Catalog 'datasets' must be a list.")
            if not isinstance(assets_raw, list):
                raise CatalogError("Catalog 'assets' must be a list.")
        else:
            raise CatalogError("Catalog JSON must be an object or a list.")

        datasets = self._parse_datasets(datasets_raw)
        assets = self._parse_assets(assets_raw)
        return datasets, assets

    def _parse_datasets(self, raw: list[object]) -> list[DatasetEntry]:
        entries: list[DatasetEntry] = []
        for item in raw:
            if not isinstance(item, dict):
                raise CatalogError("Catalog dataset entry must be an object.")

            base_name = item.get("base_name")
            drive_path = item.get("drive_path")
            drive_file_ids_raw = item.get("drive_file_ids")
            local_path = item.get("local_path")

            if not isinstance(base_name, str):
                raise CatalogError("Catalog entry missing string 'base_name'.")
            if not isinstance(drive_path, str):
                raise CatalogError("Catalog entry missing string 'drive_path'.")
            if local_path is not None and not isinstance(local_path, str):
                raise CatalogError("'local_path' must be a string or null.")
            if not isinstance(drive_file_ids_raw, dict):
                raise CatalogError("Catalog entry missing object 'drive_file_ids'.")

            drive_file_ids: dict[str, str] = {}
            for key, value in drive_file_ids_raw.items():
                if isinstance(key, str) and isinstance(value, str):
                    drive_file_ids[key] = value
                else:
                    raise CatalogError("'drive_file_ids' keys and values must be strings.")

            entries.append(
                {
                    "base_name": base_name,
                    "drive_path": drive_path,
                    "drive_file_ids": drive_file_ids,
                    "local_path": local_path,
                }
            )
        return entries

    def _parse_assets(self, raw: list[object]) -> list[AssetEntry]:
        entries: list[AssetEntry] = []
        for item in raw:
            if not isinstance(item, dict):
                raise CatalogError("Catalog asset entry must be an object.")

            asset_name = item.get("asset_name")
            asset_type = item.get("asset_type")
            drive_path = item.get("drive_path")
            drive_id = item.get("drive_id")
            mime_type = item.get("mime_type")
            local_path = item.get("local_path")

            if not isinstance(asset_name, str):
                raise CatalogError("Asset entry missing string 'asset_name'.")
            if asset_type not in ("folder", "file"):
                raise CatalogError("'asset_type' must be 'folder' or 'file'.")
            if not isinstance(drive_path, str):
                raise CatalogError("Asset entry missing string 'drive_path'.")
            if not isinstance(drive_id, str):
                raise CatalogError("Asset entry missing string 'drive_id'.")
            if not isinstance(mime_type, str):
                raise CatalogError("Asset entry missing string 'mime_type'.")
            if local_path is not None and not isinstance(local_path, str):
                raise CatalogError("Asset 'local_path' must be a string or null.")

            entries.append(
                {
                    "asset_name": asset_name,
                    "asset_type": asset_type,
                    "drive_path": drive_path,
                    "drive_id": drive_id,
                    "mime_type": mime_type,
                    "local_path": local_path,
                }
            )
        return entries

    def _save_catalog(self, datasets: list[DatasetEntry], assets: list[AssetEntry]) -> None:
        """Write the catalog JSON to disk."""
        Path(self.config.catalog_path).parent.mkdir(parents=True, exist_ok=True)
        with open(self.config.catalog_path, "w") as f:
            json.dump({"datasets": datasets, "assets": assets}, f, indent=2)

    def _get_dataset_entry(self, drive_path: str, base_name: str) -> DatasetEntry:
        datasets, _ = self._load_catalog()
        for entry in datasets:
            if entry["drive_path"] == drive_path and entry["base_name"] == base_name:
                return entry
        raise EntryNotFoundError(f"Dataset '{base_name}' at '{drive_path}' not found in catalog.")

    def _get_asset_entry(self, drive_path: str, asset_name: str) -> AssetEntry:
        _, assets = self._load_catalog()
        for entry in assets:
            if entry["drive_path"] == drive_path and entry["asset_name"] == asset_name:
                return entry
        raise EntryNotFoundError(f"Asset '{asset_name}' at '{drive_path}' not found in catalog.")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scan(self, *, flat: bool = True) -> ScanResult:
        """Scan Drive and rebuild the catalog JSON.

        Any existing local_path entries are preserved so a rescan doesn't
        forget which datasets or assets have already been downloaded.

        Args:
            flat: If ``True`` (the default), use a flat scan of all files
                visible to the service account — faster and works even when
                the root folder is inaccessible. Set to ``False`` for a
                recursive traversal from the root folder.

        Returns:
            A :class:`ScanResult` with new/existing/removed counts for
            datasets and assets.
        """
        _log.info("Scanning Google Drive...")
        if flat:
            new_datasets, new_assets = scan_drive_flat(self._drive, self.config.root_folder_id, quiet=self._quiet)
        else:
            new_datasets, new_assets = scan_drive(self._drive, self.config.root_folder_id, quiet=self._quiet)

        # Preserve local_path values from the previous catalog
        # keyed by (drive_path, base_name) to match the new identity model
        existing_dataset_paths: dict[tuple[str, str], str | None] = {}
        existing_asset_paths: dict[tuple[str, str], str | None] = {}
        if Path(self.config.catalog_path).exists():
            old_datasets, old_assets = self._load_catalog()
            for ds in old_datasets:
                existing_dataset_paths[(ds["drive_path"], ds["base_name"])] = ds.get("local_path")
            for asset in old_assets:
                old_key = (asset["drive_path"], asset["asset_name"])
                existing_asset_paths[old_key] = asset.get("local_path")

        # Compute new/existing/removed counts
        old_dataset_keys = set(existing_dataset_paths.keys())
        new_dataset_keys = {(ds["drive_path"], ds["base_name"]) for ds in new_datasets}
        old_asset_keys = set(existing_asset_paths.keys())
        new_asset_keys = {(a["drive_path"], a["asset_name"]) for a in new_assets}

        for ds in new_datasets:
            key = (ds["drive_path"], ds["base_name"])
            recorded = existing_dataset_paths.get(key)
            expected = Path(self.config.local_data_dir) / ds["drive_path"]
            if recorded is not None and Path(recorded).exists():
                ds["local_path"] = recorded
            elif expected.exists():
                ds["local_path"] = str(expected)
            else:
                ds["local_path"] = None
        for asset in new_assets:
            key = (asset["drive_path"], asset["asset_name"])
            recorded = existing_asset_paths.get(key)
            asset_base = Path(self.config.local_data_dir) / "assets"
            dp = asset["drive_path"]
            expected = (asset_base / dp / asset["asset_name"]) if dp else (asset_base / asset["asset_name"])
            if recorded is not None and Path(recorded).exists():
                asset["local_path"] = recorded
            elif expected.exists():
                asset["local_path"] = str(expected)
            else:
                asset["local_path"] = None

        self._save_catalog(new_datasets, new_assets)
        self._invalidate_cache()

        ds_new = len(new_dataset_keys - old_dataset_keys)
        ds_existing = len(new_dataset_keys & old_dataset_keys)
        ds_removed = len(old_dataset_keys - new_dataset_keys)
        a_new = len(new_asset_keys - old_asset_keys)
        a_existing = len(new_asset_keys & old_asset_keys)
        a_removed = len(old_asset_keys - new_asset_keys)

        _log.info(
            "Scan complete: %d datasets (%d new, %d existing, %d removed), "
            "%d assets (%d new, %d existing, %d removed).",
            len(new_datasets),
            ds_new,
            ds_existing,
            ds_removed,
            len(new_assets),
            a_new,
            a_existing,
            a_removed,
        )
        return ScanResult(
            datasets_new=ds_new,
            datasets_existing=ds_existing,
            datasets_removed=ds_removed,
            assets_new=a_new,
            assets_existing=a_existing,
            assets_removed=a_removed,
        )

    @property
    def df(self) -> pd.DataFrame:
        """
        The full dataset catalog as a pandas DataFrame. Columns:
            base_name, drive_path, drive_file_ids, local_path
        """
        if self._df is None:
            datasets, _ = self._load_catalog()
            self._df = pd.DataFrame(datasets)
        return self._df

    @property
    def assets_df(self) -> pd.DataFrame:
        """
        The full assets catalog as a pandas DataFrame. Columns:
            asset_name, asset_type, drive_path, drive_id, mime_type, local_path
        """
        if self._assets_df is None:
            _, assets = self._load_catalog()
            self._assets_df = pd.DataFrame(assets)
        return self._assets_df

    def list_datasets(
        self,
        drive_path: str | None = None,
        drive_path_prefix: str | None = None,
        drive_path_contains: str | None = None,
    ) -> pd.DataFrame:
        """
        Query the dataset catalog and return a filtered DataFrame.

        All filters are applied together (AND semantics). Omitting all
        arguments returns the full catalog.

        Args:
            drive_path: Exact ``drive_path`` match
                (e.g. ``"2026-02-15_batch/reaching"``).
            drive_path_prefix: Return only rows whose ``drive_path`` starts
                with this string (e.g. ``"2026-02-15_batch"``).
            drive_path_contains: Return only rows whose ``drive_path`` contains
                this substring (e.g. ``"reaching"``).

        Examples:
            catalog.list_datasets()                                          # everything
            catalog.list_datasets(drive_path="2026-02-15_batch/reaching")   # exact folder
            catalog.list_datasets(drive_path_prefix="2026-02-15_batch")     # subtree
            catalog.list_datasets(drive_path_contains="reaching")           # any depth
        """
        result = self.df

        if drive_path is not None:
            result = result[result["drive_path"] == drive_path]
        if drive_path_prefix is not None:
            result = result[result["drive_path"].str.startswith(drive_path_prefix)]
        if drive_path_contains is not None:
            result = result[result["drive_path"].str.contains(drive_path_contains, regex=False)]

        return result.reset_index(drop=True)

    def list_assets(
        self,
        drive_path: str | None = None,
        drive_path_prefix: str | None = None,
        drive_path_contains: str | None = None,
        asset_type: str | None = None,
    ) -> pd.DataFrame:
        """
        Query the asset catalog and return a filtered DataFrame.

        All filters are applied together (AND semantics). Omitting all
        arguments returns the full asset catalog.

        Args:
            drive_path: Exact ``drive_path`` match for the asset's parent folder
                (e.g. ``"2026-02-15_batch/reaching"``).
            drive_path_prefix: Return only rows whose ``drive_path`` starts
                with this string (e.g. ``"2026-02-15_batch"``).
            drive_path_contains: Return only rows whose ``drive_path`` contains
                this substring (e.g. ``"reaching"``).
            asset_type: Filter by ``"folder"`` or ``"file"``. When ``None``
                both types are returned.

        Examples:
            catalog.list_assets()                                             # everything
            catalog.list_assets(drive_path="2026-02-15_batch/reaching")      # exact parent folder
            catalog.list_assets(drive_path_prefix="2026-02-15_batch")        # subtree
            catalog.list_assets(asset_type="folder")                         # folders only
        """
        result = self.assets_df

        if drive_path is not None:
            result = result[result["drive_path"] == drive_path]
        if drive_path_prefix is not None:
            result = result[result["drive_path"].str.startswith(drive_path_prefix)]
        if drive_path_contains is not None:
            result = result[result["drive_path"].str.contains(drive_path_contains, regex=False)]
        if asset_type is not None:
            result = result[result["asset_type"] == asset_type]

        return result.reset_index(drop=True)

    def download_dataset(self, drive_path: str, base_name: str) -> str:
        """Download the xdat files for a dataset to the local data directory.

        Files are stored under ``{local_data_dir}/{drive_path}/``, mirroring
        the Drive folder hierarchy. After a successful download, persists the
        ``local_path`` back to the catalog JSON.

        Args:
            drive_path: The slash-joined path to the folder containing the
                dataset (as shown in ``df["drive_path"]``).
            base_name: The dataset identifier (shared filename stem).

        Returns:
            The local directory path where the files were written.

        Raises:
            EntryNotFoundError: If the dataset is not found in the catalog.
        """
        dataset = self._get_dataset_entry(drive_path, base_name)
        _log.info("Downloading '%s' from '%s'...", base_name, drive_path)
        local_path = download_dataset(self._drive, dataset, self.config.local_data_dir, quiet=self._quiet)

        # Persist the local_path back to the catalog
        datasets, assets = self._load_catalog()
        for entry in datasets:
            if entry["drive_path"] == drive_path and entry["base_name"] == base_name:
                entry["local_path"] = local_path
                break
        self._save_catalog(datasets, assets)
        self._invalidate_cache()

        _log.info("Done. Files saved to: %s", local_path)
        return local_path

    def get_dataset_path(self, drive_path: str, base_name: str) -> str:
        """Return the local directory path for a dataset, downloading if needed.

        If the dataset has not been downloaded yet, or if the recorded
        ``local_path`` no longer exists on disk, the download is triggered
        automatically.

        Args:
            drive_path: The slash-joined path to the folder containing the
                dataset (as shown in ``df["drive_path"]``).
            base_name: The dataset identifier (shared filename stem).

        Returns:
            The local directory path where the xdat files reside.

        Raises:
            EntryNotFoundError: If the dataset is not found in the catalog.
        """
        entry = self._get_dataset_entry(drive_path, base_name)
        local_path = entry["local_path"]
        if local_path is not None and Path(local_path).exists():
            return local_path

        _log.info("'%s' is not available locally — downloading.", base_name)
        return self.download_dataset(drive_path, base_name)

    def download_asset(self, drive_path: str, asset_name: str) -> str:
        """Download an asset (file or folder) to the local assets directory.

        Assets are stored under ``{local_data_dir}/assets/{drive_path}/{asset_name}``.
        For folder assets the entire subtree is downloaded recursively.

        After a successful download, persists the ``local_path`` back to the
        catalog JSON.

        Args:
            drive_path: The slash-joined path to the asset's *parent* folder
                (e.g. ``"2026-02-15_batch/reaching"``). Shown in
                ``assets_df["drive_path"]``.
            asset_name: The file or folder name (e.g. ``"logs"``).

        Returns:
            The local path to the downloaded file or folder.

        Raises:
            EntryNotFoundError: If the asset is not found in the catalog.
        """
        asset = self._get_asset_entry(drive_path, asset_name)
        _log.info("Downloading asset '%s'...", asset_name)
        local_path = _download_asset_entry(self._drive, asset, self.config.local_data_dir, quiet=self._quiet)

        datasets, assets = self._load_catalog()
        for entry in assets:
            if entry["drive_path"] == drive_path and entry["asset_name"] == asset_name:
                entry["local_path"] = local_path
                break
        self._save_catalog(datasets, assets)
        self._invalidate_cache()

        _log.info("Done. Asset saved to: %s", local_path)
        return local_path

    def get_asset_path(self, drive_path: str, asset_name: str) -> str:
        """Return the local path for an asset, downloading if needed.

        If the asset has not been downloaded yet, or if the recorded
        ``local_path`` no longer exists on disk, the download is triggered
        automatically.

        Args:
            drive_path: The slash-joined path to the asset's *parent* folder
                (e.g. ``"2026-02-15_batch/reaching"``).
            asset_name: The file or folder name (e.g. ``"logs"``).

        Returns:
            The local path to the downloaded file or folder.

        Raises:
            EntryNotFoundError: If the asset is not found in the catalog.
        """
        entry = self._get_asset_entry(drive_path, asset_name)
        local_path = entry["local_path"]
        if local_path is not None and Path(local_path).exists():
            return local_path

        _log.info("Asset '%s' is not available locally — downloading.", asset_name)
        return self.download_asset(drive_path, asset_name)

    @staticmethod
    def _path_matches(
        path: str,
        exact: str | None,
        prefix: str | None,
        contains: str | None,
    ) -> bool:
        """Return True if ``path`` satisfies all non-None filters."""
        return (
            (exact is None or path == exact)
            and (prefix is None or path.startswith(prefix))
            and (contains is None or contains in path)
        )

    def prefetch(
        self,
        drive_path: str | None = None,
        drive_path_prefix: str | None = None,
        drive_path_contains: str | None = None,
        *,
        datasets: bool = True,
        assets: bool = True,
        asset_type: str | None = None,
        force: bool = False,
    ) -> PrefetchResult:
        """Bulk-download matching datasets and assets, skipping already-local items.

        Idempotent by default: entries whose recorded ``local_path`` already
        exists on disk are skipped. Running twice in a row issues no downloads
        on the second call. This makes ``prefetch`` safe to use both for
        proactive ("pre-warm before going offline") and reactive ("ensure
        everything under X is available") workflows.

        The ``drive_path`` filters have the same semantics as
        :meth:`list_datasets` / :meth:`list_assets`: AND-combined, any omitted
        filter is a wildcard.

        Args:
            drive_path: Exact ``drive_path`` match.
            drive_path_prefix: Match rows whose ``drive_path`` starts with
                this string.
            drive_path_contains: Match rows whose ``drive_path`` contains this
                substring.
            datasets: When ``False``, no datasets are downloaded.
            assets: When ``False``, no assets are downloaded.
            asset_type: Restrict to ``"folder"`` or ``"file"`` assets.
            force: When ``True``, download every matching entry regardless of
                whether it is already present on disk. Useful for refreshing
                stale or incomplete local copies. Defaults to ``False``.

        Returns:
            A :class:`PrefetchResult` with per-category download and skip counts.

        Examples:
            catalog.prefetch()                                             # everything
            catalog.prefetch(drive_path_prefix="2026-02")                  # subtree
            catalog.prefetch(drive_path_prefix="2026-02", assets=False)    # datasets only
            catalog.prefetch(drive_path_prefix="2026-02", asset_type="folder")
            catalog.prefetch(force=True)                                   # re-download everything
            catalog.prefetch(drive_path_prefix="2026-02", force=True)      # re-download a subtree
        """
        catalog_datasets, catalog_assets = self._load_catalog()
        ds_downloaded = ds_skipped = a_downloaded = a_skipped = 0

        # Pre-filter to build the work lists so we know the total for tqdm
        ds_to_process: list[DatasetEntry] = []
        if datasets:
            for ds in catalog_datasets:
                if self._path_matches(ds["drive_path"], drive_path, drive_path_prefix, drive_path_contains):
                    ds_to_process.append(ds)

        assets_to_process: list[AssetEntry] = []
        if assets:
            for asset in catalog_assets:
                if not self._path_matches(asset["drive_path"], drive_path, drive_path_prefix, drive_path_contains):
                    continue
                if asset_type is not None and asset["asset_type"] != asset_type:
                    continue
                assets_to_process.append(asset)

        total = len(ds_to_process) + len(assets_to_process)
        with tqdm(total=total, desc="Prefetching", unit=" item", disable=self._quiet) as pbar:
            for ds in ds_to_process:
                pbar.set_postfix_str(ds["base_name"])
                local_path = ds["local_path"]
                if not force and local_path is not None and Path(local_path).exists():
                    ds_skipped += 1
                else:
                    self.download_dataset(ds["drive_path"], ds["base_name"])
                    ds_downloaded += 1
                pbar.update(1)

            for asset in assets_to_process:
                pbar.set_postfix_str(asset["asset_name"])
                local_path = asset["local_path"]
                if not force and local_path is not None and Path(local_path).exists():
                    a_skipped += 1
                else:
                    self.download_asset(asset["drive_path"], asset["asset_name"])
                    a_downloaded += 1
                pbar.update(1)

        _log.info(
            "Prefetch complete: %d datasets downloaded, %d skipped; %d assets downloaded, %d skipped.",
            ds_downloaded,
            ds_skipped,
            a_downloaded,
            a_skipped,
        )
        return PrefetchResult(
            datasets_downloaded=ds_downloaded,
            datasets_skipped=ds_skipped,
            assets_downloaded=a_downloaded,
            assets_skipped=a_skipped,
        )
