"""
exceptions.py
-------------
Public exception hierarchy for radiens-drive-catalog.
"""


class CatalogError(Exception):
    """Base class for all radiens-drive-catalog errors."""


class EntryNotFoundError(CatalogError):
    """Raised when a dataset or asset cannot be found in the catalog."""
