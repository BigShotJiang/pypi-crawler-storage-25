"""
radiens-drive-catalog
---------------------
Programmatic catalog and sync tool for xdat neural datasets stored on
Google Drive. Datasets are uniquely identified by (drive_path, base_name)
and queryable by drive path exact match, prefix, or substring.
"""

from .catalog import Catalog, PrefetchResult, ScanResult
from .config import Config
from .drive import AssetEntry, DatasetEntry
from .exceptions import CatalogError, EntryNotFoundError

__all__ = [
    "AssetEntry",
    "Catalog",
    "CatalogError",
    "Config",
    "DatasetEntry",
    "EntryNotFoundError",
    "PrefetchResult",
    "ScanResult",
]
