"""
drive.py
--------
Google Drive API interactions: recursive scanning and file download.

xdat dataset file naming convention (3 files per base_name):
    {base_name}_data.xdat
    {base_name}.xdat.json
    {base_name}_timestamp.xdat
"""

import logging
from pathlib import Path
from typing import Literal, NotRequired, Protocol, TypedDict

from googleapiclient.http import MediaIoBaseDownload
from tqdm import tqdm

_log = logging.getLogger(__name__)

# Maps each file suffix to a short type label used in drive_file_ids
XDAT_SUFFIXES: dict[str, str] = {
    "_data.xdat": "data",
    ".xdat.json": "meta",
    "_timestamp.xdat": "timestamp",
}

FOLDER_MIME = "application/vnd.google-apps.folder"


class DriveItem(TypedDict):
    """A single item returned by the Drive API ``files.list`` endpoint.

    ``id``, ``name``, and ``mimeType`` are always present in well-formed
    responses.  ``parents`` is only populated when explicitly requested
    in the ``fields`` parameter (used by the flat-scan fallback).
    """

    id: str
    name: str
    mimeType: str
    parents: NotRequired[list[str]]


class DatasetEntry(TypedDict):
    """One xdat dataset record stored in the catalog.

    Represents a single neural recording dataset. The three xdat files
    (``_data.xdat``, ``.xdat.json``, ``_timestamp.xdat``) share a common
    ``base_name`` stem.

    Attributes:
        base_name: Shared filename stem across all three xdat files.
            Note: ``base_name`` is not globally unique; the pair
            ``(drive_path, base_name)`` uniquely identifies a recording.
        drive_path: Slash-joined path from the root folder to the folder
            containing the dataset files (e.g.
            ``"2026-02-15_batch/reaching/probe1"``).
        drive_file_ids: Maps file type labels (``"data"``, ``"meta"``,
            ``"timestamp"``) to their Google Drive file IDs. May contain fewer
            than three keys if only some files were found during scanning.
        local_path: Absolute path to the local directory where the dataset has
            been downloaded, or ``None`` if not yet downloaded.
    """

    base_name: str
    drive_path: str
    drive_file_ids: dict[str, str]
    local_path: str | None


class AssetEntry(TypedDict):
    """One non-xdat asset record stored in the catalog.

    Represents a single file or folder found on Drive that is not an xdat
    dataset — for example a ``logs/`` directory, a PowerPoint, or a writeup.

    Attributes:
        asset_name: The file or folder name as it appears on Drive
            (e.g. ``"logs"``, ``"notes.pptx"``).
        asset_type: ``"folder"`` or ``"file"``.
        drive_path: Slash-joined path from the root folder to the *parent*
            folder of this asset (e.g. ``"2026-02-15_batch/reaching"``).
            Together with ``asset_name``, this uniquely identifies an asset.
        drive_id: Google Drive ID of this file or folder.
        mime_type: MIME type as reported by the Drive API.
        local_path: Absolute local path to the downloaded file or folder, or
            ``None`` if not yet downloaded.
    """

    asset_name: str
    asset_type: Literal["folder", "file"]
    drive_path: str
    drive_id: str
    mime_type: str
    local_path: str | None


class _DriveListRequest(Protocol):
    def execute(self) -> dict[str, object]: ...


class _DriveMediaRequest(Protocol):
    pass


class _DriveFilesResource(Protocol):
    def list(
        self,
        *,
        q: str,
        fields: str,
        pageToken: str | None = None,
        pageSize: int | None = None,
    ) -> _DriveListRequest: ...

    def get_media(self, *, fileId: str) -> _DriveMediaRequest: ...


class DriveService(Protocol):
    def files(self) -> _DriveFilesResource: ...


def _extract_base_name(filename: str) -> str | None:
    """
    Return the base_name for a recognized xdat filename, or None
    if the file doesn't match any known suffix.
    """
    for suffix in XDAT_SUFFIXES:
        if filename.endswith(suffix):
            return filename[: -len(suffix)]
    return None


def _classify_item(
    name: str,
    is_folder: bool,
    depth: int,
) -> Literal["dataset", "folder_asset", "file_asset", "skip"]:
    """Classify a Drive item for cataloging purposes.

    Args:
        name: The item's filename or folder name.
        is_folder: True if the item is a Drive folder.
        depth: Number of path components from the root to the item's *parent*
            folder (0 = item is directly inside the root folder).

    Returns:
        ``"dataset"``      — xdat file; merge into a DatasetEntry.
        ``"folder_asset"`` — subfolder of an experiment or deeper; catalog as an asset.
        ``"file_asset"``   — non-xdat file inside a date or experiment folder.
        ``"skip"``         — top-level folders, or deep non-xdat files inside a
                             folder asset subtree.
    """
    if is_folder:
        return "folder_asset" if depth >= 2 else "skip"
    if _extract_base_name(name) is not None:
        return "dataset"
    if depth in (1, 2):
        return "file_asset"
    return "skip"


def _list_folder(service: DriveService, folder_id: str) -> list[DriveItem]:
    """Return all non-trashed items (files and subfolders) in a Drive folder.

    Handles pagination automatically by following `nextPageToken` until
    exhausted. Items missing any of `id`, `name`, or `mimeType` are silently
    skipped.

    Args:
        service: Authenticated Drive API service.
        folder_id: Google Drive folder ID to list.

    Returns:
        List of `DriveItem` dicts for all items in the folder.
    """
    items: list[DriveItem] = []
    page_token: str | None = None

    while True:
        response = (
            service.files()
            .list(
                q=f"'{folder_id}' in parents and trashed = false",
                fields="nextPageToken, files(id, name, mimeType)",
                pageToken=page_token,
            )
            .execute()
        )
        files_obj = response.get("files")
        if isinstance(files_obj, list):
            for item in files_obj:
                if not isinstance(item, dict):
                    continue
                item_id = item.get("id")
                name = item.get("name")
                mime_type = item.get("mimeType")
                if isinstance(item_id, str) and isinstance(name, str) and isinstance(mime_type, str):
                    items.append({"id": item_id, "name": name, "mimeType": mime_type})
        next_token = response.get("nextPageToken")
        page_token = next_token if isinstance(next_token, str) else None
        if not page_token:
            break

    return items


def scan_drive(
    service: DriveService, root_folder_id: str, *, quiet: bool = False
) -> tuple[list[DatasetEntry], list[AssetEntry]]:
    """Recursively scan Drive and return xdat datasets and non-xdat assets.

    Traverses the full subtree rooted at ``root_folder_id``.

    **Dataset collection**: xdat files are recognized at any depth by their
    suffix and merged by ``(drive_path, base_name)`` into
    :class:`DatasetEntry` records.

    **Asset collection**: Non-xdat content is cataloged according to depth:

    - Folders encountered *inside* an experiment folder (depth ≥ 3 from root)
      are cataloged as ``"folder"`` assets and also recursed into so that any
      xdat files they contain are still found.
    - Non-xdat files encountered inside a date folder or experiment folder
      (depths 2-3 from root) are cataloged as ``"file"`` assets.
    - Content deeper than the experiment level is not separately cataloged
      (it is part of a parent folder asset and downloaded with it).

    Args:
        service: Authenticated Drive API service.
        root_folder_id: Google Drive folder ID of the root folder to scan.

    Returns:
        A tuple ``(datasets, assets)`` where ``datasets`` is a list of
        :class:`DatasetEntry` dicts and ``assets`` is a list of
        :class:`AssetEntry` dicts. All entries have ``local_path=None``.
    """
    # keyed by (drive_path, base_name) to handle non-unique base_names
    datasets: dict[tuple[str, str], DatasetEntry] = {}
    # keyed by (drive_path, asset_name) to deduplicate across recursive calls
    _asset_dict: dict[tuple[str, str], AssetEntry] = {}

    def _recurse(folder_id: str, path_components: list[str]) -> None:
        depth = len(path_components)
        if depth == 1:
            _log.debug("Scanning Drive folder: '%s'", path_components[0])
        items = _list_folder(service, folder_id)

        for item in items:
            is_folder = item["mimeType"] == FOLDER_MIME
            classification = _classify_item(item["name"], is_folder, depth)

            if is_folder:
                if classification == "folder_asset":
                    drive_path = "/".join(path_components)
                    key = (drive_path, item["name"])
                    if key not in _asset_dict:
                        _asset_dict[key] = {
                            "asset_name": item["name"],
                            "asset_type": "folder",
                            "drive_path": drive_path,
                            "drive_id": item["id"],
                            "mime_type": item["mimeType"],
                            "local_path": None,
                        }
                # Always recurse into folders at any depth
                _recurse(item["id"], [*path_components, item["name"]])
            elif classification == "dataset":
                base_name = _extract_base_name(item["name"])
                assert base_name is not None
                suffix = next(s for s in XDAT_SUFFIXES if item["name"].endswith(s))
                file_type = XDAT_SUFFIXES[suffix]
                drive_path_str = "/".join(path_components)
                ds_key = (drive_path_str, base_name)
                if ds_key not in datasets:
                    datasets[ds_key] = {
                        "base_name": base_name,
                        "drive_path": drive_path_str,
                        "drive_file_ids": {},
                        "local_path": None,
                    }
                datasets[ds_key]["drive_file_ids"][file_type] = item["id"]
            elif classification == "file_asset":
                drive_path = "/".join(path_components)
                key = (drive_path, item["name"])
                if key not in _asset_dict:
                    _asset_dict[key] = {
                        "asset_name": item["name"],
                        "asset_type": "file",
                        "drive_path": drive_path,
                        "drive_id": item["id"],
                        "mime_type": item["mimeType"],
                        "local_path": None,
                    }

    _recurse(root_folder_id, [])
    return list(datasets.values()), list(_asset_dict.values())


# ------------------------------------------------------------------
# Flat-scan fallback (no root folder access required)
# ------------------------------------------------------------------


def _list_all_files(service: DriveService, *, quiet: bool = False) -> list[DriveItem]:
    """Return every non-trashed file visible to the authenticated account.

    Unlike :func:`_list_folder`, this does **not** filter by parent folder.
    It requests the ``parents`` field so callers can reconstruct folder paths.
    Pagination is handled automatically (``pageSize=1000``).

    A :mod:`warnings` warning is emitted when the Drive API reports an
    incomplete search (``incompleteSearch=true`` in the response).

    Args:
        service: Authenticated Drive API service.

    Returns:
        List of :class:`DriveItem` dicts including the ``parents`` key
        (when the API supplies it).
    """
    items: list[DriveItem] = []
    page_token: str | None = None

    with tqdm(desc="Scanning Drive", unit=" files", dynamic_ncols=True, disable=quiet) as pbar:
        while True:
            response = (
                service.files()
                .list(
                    q="trashed = false",
                    fields="nextPageToken, incompleteSearch, files(id, name, mimeType, parents)",
                    pageSize=1000,
                    pageToken=page_token,
                )
                .execute()
            )

            incomplete = response.get("incompleteSearch")
            if incomplete is True:
                _log.warning("Drive API reported an incomplete search. Some files may be missing from the catalog.")

            files_obj = response.get("files")
            if isinstance(files_obj, list):
                for item in files_obj:
                    if not isinstance(item, dict):
                        continue
                    item_id = item.get("id")
                    name = item.get("name")
                    mime_type = item.get("mimeType")
                    if not (isinstance(item_id, str) and isinstance(name, str) and isinstance(mime_type, str)):
                        continue
                    drive_item: DriveItem = {"id": item_id, "name": name, "mimeType": mime_type}
                    raw_parents = item.get("parents")
                    if isinstance(raw_parents, list) and all(isinstance(p, str) for p in raw_parents):
                        drive_item["parents"] = raw_parents
                    items.append(drive_item)
                    pbar.update(1)

            next_token = response.get("nextPageToken")
            page_token = next_token if isinstance(next_token, str) else None
            if not page_token:
                break

    return items


def _resolve_path_components(
    item_id: str,
    id_to_item: dict[str, DriveItem],
    root_folder_id: str,
) -> list[str]:
    """Walk the ``parents`` chain upward and return folder names top-down.

    Stops when the parent equals *root_folder_id* (path anchor) **or** when
    the parent is not present in *id_to_item* (share boundary / inaccessible
    root).  The root folder itself is never included in the returned path.

    Args:
        item_id: Drive ID of the item whose path to resolve.
        id_to_item: Lookup table built from :func:`_list_all_files` output.
        root_folder_id: Drive ID of the logical root folder (stop sentinel).

    Returns:
        List of folder names from shallowest to deepest, e.g.
        ``["2026-02-15_batch", "reaching"]``.
    """
    item = id_to_item.get(item_id)
    if item is None:
        return []

    parents = item.get("parents")
    if not parents:
        return []

    components: list[str] = []
    current_id = parents[0]

    while current_id != root_folder_id and current_id in id_to_item:
        components.append(id_to_item[current_id]["name"])
        next_parents = id_to_item[current_id].get("parents")
        if not next_parents:
            break
        current_id = next_parents[0]

    return list(reversed(components))


def scan_drive_flat(
    service: DriveService,
    root_folder_id: str,
    *,
    quiet: bool = False,
) -> tuple[list[DatasetEntry], list[AssetEntry]]:
    """Scan Drive without traversing from a root folder.

    This is the **fallback** used when the service account cannot access
    *root_folder_id* (404 / 403).  It flat-lists every file visible to the
    account, reconstructs folder paths via the ``parents`` field, and applies
    the same depth-based classification rules as :func:`scan_drive`.

    Args:
        service: Authenticated Drive API service.
        root_folder_id: The *logical* root folder ID.  Not used for API
            calls — only as a stop sentinel when resolving paths so that
            depth assignments match the recursive scan.

    Returns:
        Same ``(datasets, assets)`` tuple as :func:`scan_drive`.
    """
    all_items = _list_all_files(service, quiet=quiet)
    id_to_item: dict[str, DriveItem] = {item["id"]: item for item in all_items}

    # keyed by (drive_path, base_name) to handle non-unique base_names
    datasets: dict[tuple[str, str], DatasetEntry] = {}
    _asset_dict: dict[tuple[str, str], AssetEntry] = {}

    for item in all_items:
        is_folder = item["mimeType"] == FOLDER_MIME

        # Resolve the path to this item's *parent* folder (mirrors _recurse's
        # path_components, which is the path from root to the folder being listed).
        path_components = _resolve_path_components(item["id"], id_to_item, root_folder_id)
        depth = len(path_components)
        classification = _classify_item(item["name"], is_folder, depth)

        if classification == "folder_asset":
            drive_path = "/".join(path_components)
            key = (drive_path, item["name"])
            if key not in _asset_dict:
                _asset_dict[key] = {
                    "asset_name": item["name"],
                    "asset_type": "folder",
                    "drive_path": drive_path,
                    "drive_id": item["id"],
                    "mime_type": item["mimeType"],
                    "local_path": None,
                }
        elif classification == "dataset":
            base_name = _extract_base_name(item["name"])
            assert base_name is not None
            suffix = next(s for s in XDAT_SUFFIXES if item["name"].endswith(s))
            file_type = XDAT_SUFFIXES[suffix]
            drive_path_str = "/".join(path_components)
            ds_key = (drive_path_str, base_name)
            if ds_key not in datasets:
                datasets[ds_key] = {
                    "base_name": base_name,
                    "drive_path": drive_path_str,
                    "drive_file_ids": {},
                    "local_path": None,
                }
            datasets[ds_key]["drive_file_ids"][file_type] = item["id"]
        elif classification == "file_asset":
            drive_path = "/".join(path_components)
            key = (drive_path, item["name"])
            if key not in _asset_dict:
                _asset_dict[key] = {
                    "asset_name": item["name"],
                    "asset_type": "file",
                    "drive_path": drive_path,
                    "drive_id": item["id"],
                    "mime_type": item["mimeType"],
                    "local_path": None,
                }

    return list(datasets.values()), list(_asset_dict.values())


def _download_file(
    service: DriveService,
    file_id: str,
    dest_path: Path,
    desc: str | None = None,
    quiet: bool = False,
) -> None:
    """Download a single Drive file to ``dest_path``, showing a tqdm progress bar."""
    request = service.files().get_media(fileId=file_id)
    with open(dest_path, "wb") as fh:
        downloader = MediaIoBaseDownload(fh, request)
        done = False
        with tqdm(
            total=None,
            unit="B",
            unit_scale=True,
            desc=desc or dest_path.name,
            leave=True,
            disable=quiet,
        ) as pbar:
            while not done:
                status, done = downloader.next_chunk()
                if status is not None:
                    if pbar.total is None and status.total_size:
                        pbar.total = status.total_size
                        pbar.refresh()
                    pbar.update(int(status.resumable_progress) - int(pbar.n))


def _download_folder_recursive(
    service: DriveService,
    folder_id: str,
    local_dir: Path,
    quiet: bool = False,
) -> None:
    """Recursively download all contents of a Drive folder into ``local_dir``."""
    local_dir.mkdir(parents=True, exist_ok=True)
    for item in _list_folder(service, folder_id):
        if item["mimeType"] == FOLDER_MIME:
            _download_folder_recursive(service, item["id"], local_dir / item["name"], quiet=quiet)
        else:
            _download_file(service, item["id"], local_dir / item["name"], quiet=quiet)


def download_dataset(
    service: DriveService,
    dataset: DatasetEntry,
    local_data_dir: str,
    quiet: bool = False,
) -> str:
    """Download the xdat files for a dataset into a path-mirrored local directory.

    Files are stored under ``{local_data_dir}/{drive_path}/``, mirroring the
    Drive folder hierarchy:

    ```
    {local_data_dir}/{drive_path}/{base_name}_data.xdat
    {local_data_dir}/{drive_path}/{base_name}.xdat.json
    {local_data_dir}/{drive_path}/{base_name}_timestamp.xdat
    ```

    The directory is created if it does not already exist.

    Args:
        service: Authenticated Drive API service.
        dataset: The `DatasetEntry` whose files should be downloaded.
        local_data_dir: Root local data directory.
        quiet: If ``True``, suppress tqdm progress bars.

    Returns:
        The absolute path to the directory where the files were written.
    """
    local_dir = Path(local_data_dir) / dataset["drive_path"]
    local_dir.mkdir(parents=True, exist_ok=True)

    # Reverse the suffix map so we can reconstruct filenames from file_type
    type_to_suffix = {v: k for k, v in XDAT_SUFFIXES.items()}

    for file_type, file_id in dataset["drive_file_ids"].items():
        suffix = type_to_suffix[file_type]
        filename = dataset["base_name"] + suffix
        dest_path = local_dir / filename

        _download_file(service, file_id, dest_path, quiet=quiet)

    return str(local_dir)


def download_asset(
    service: DriveService,
    asset: AssetEntry,
    local_data_dir: str,
    quiet: bool = False,
) -> str:
    """Download an asset (file or folder) into the assets subdirectory.

    Assets are stored under ``{local_data_dir}/assets/{drive_path}/{asset_name}``,
    keeping them separate from the xdat dataset files.

    For folder assets the entire subtree is downloaded recursively, mirroring
    the Drive folder structure under the asset's local directory.

    Args:
        service: Authenticated Drive API service.
        asset: The :class:`AssetEntry` to download.
        local_data_dir: Root local data directory (same as used for datasets).
        quiet: If ``True``, suppress tqdm progress bars.

    Returns:
        The absolute path to the downloaded file or folder as a string.
    """
    asset_local_path = Path(local_data_dir) / "assets"
    if asset["drive_path"]:
        asset_local_path = asset_local_path / asset["drive_path"]
    asset_local_path = asset_local_path / asset["asset_name"]

    if asset["asset_type"] == "folder":
        _download_folder_recursive(service, asset["drive_id"], asset_local_path, quiet=quiet)
    else:
        asset_local_path.parent.mkdir(parents=True, exist_ok=True)
        _download_file(service, asset["drive_id"], asset_local_path, quiet=quiet)

    return str(asset_local_path)
