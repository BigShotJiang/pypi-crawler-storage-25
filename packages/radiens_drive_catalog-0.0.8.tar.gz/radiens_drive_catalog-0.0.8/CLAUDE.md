# radiens-drive-catalog

A Python package for programmatically managing large neural datasets stored on Google Drive. The package handles Drive scanning, local cataloging, and selective dataset download. Analysis itself is done locally in Python — this package is purely about data management.

## Background

Neural data is stored as xdat filesets (NeuroNexus format) on a shared Google Drive. The Drive hierarchy is irregular: top-level folders are date-prefixed, and within them datasets may be nested 1–3 levels deep inside experiment and sub-experiment folders. There is no structured metadata beyond what can be inferred from folder names and filenames.

Alongside xdat datasets, Drive folders may contain other content — logs directories, PowerPoint slides, writeups, etc. These are tracked as **assets** and managed alongside datasets.

## xdat Dataset Convention

Each dataset consists of exactly 3 files sharing a common `base_name`:

```
{base_name}_data.xdat
{base_name}.xdat.json
{base_name}_timestamp.xdat
```

The `base_name` is the canonical identifier for a dataset throughout this package.

## Drive Folder Structure

The root Drive folder contains date-prefixed folders at depth 1. Within those, nesting is variable:

```
root/
  2026-02-15_experiment_batch/        ← date_folder (always present)
    reaching/                         ← experiment (optional, depth 2)
      probe1/                         ← sub_experiment (optional, depth 3)
        rat01_session3_data.xdat
        rat01_session3.xdat.json
        rat01_session3_timestamp.xdat
      logs/                           ← folder asset (depth 3)
        log_20260215.txt
      notes.pptx                      ← file asset (depth 3)
      rat02_session1_data.xdat        ← data can also live at experiment level
      ...
    rat03_baseline_data.xdat          ← or directly in the date_folder
  2026-03-01_cohort2/
    ...
```

Datasets can appear at any depth. The full path from root to the containing folder is recorded as `drive_path`. Querying is done directly on the pandas DataFrame using standard operations.

## Architecture

```
src/radiens_drive_catalog/
  config.py      — Config dataclass (credentials path, root folder ID, local data dir, catalog path)
  auth.py        — Builds authenticated Drive API service from a service account credentials file
  drive.py       — Recursive Drive scanner and file downloader; xdat suffix logic and asset detection
  catalog.py     — Catalog class: the main user-facing interface
  exceptions.py  — Public exception hierarchy: CatalogError, EntryNotFoundError
```

## Catalog Design

The catalog is a JSON file on disk with two top-level keys: `"datasets"` and `"assets"`. Both are loaded into pandas DataFrames at runtime for querying.

**Dataset fields** (`DatasetEntry`):

| Field | Type | Description |
|---|---|---|
| `base_name` | str | Filename stem; not globally unique — `(drive_path, base_name)` is the unique identity |
| `drive_path` | str | Slash-joined path from root to the containing folder |
| `drive_file_ids` | dict[str, str] | Maps `"data"`, `"meta"`, `"timestamp"` to Drive file IDs |
| `local_path` | str \| None | Local directory path if downloaded, else None |

**Asset fields** (`AssetEntry`):

| Field | Type | Description |
|---|---|---|
| `asset_name` | str | File or folder name (e.g. `"logs"`, `"notes.pptx"`) |
| `asset_type` | `"folder"` \| `"file"` | Whether the asset is a directory or a file |
| `drive_path` | str | Slash-joined path to the asset's *parent* folder |
| `drive_id` | str | Google Drive ID of this file or folder |
| `mime_type` | str | MIME type as reported by Drive |
| `local_path` | str \| None | Local path if downloaded, else None |

**Catalog JSON format:**

```json
{
  "datasets": [...],
  "assets": [...]
}
```

Legacy catalogs (bare list) are automatically migrated on the next `scan()`.

## Asset Discovery Rules

During `scan_drive()`, non-xdat content is cataloged based on depth from root:

- **Depth 2+ files** (inside a date folder or any deeper folder): cataloged as file assets
- **Depth 3+ folders** (subfolders of an experiment folder or deeper): cataloged as folder assets; also recursed for xdat datasets

Date folders (depth 1) and experiment folders (depth 2) are not cataloged as assets themselves.

This handles both flat hierarchies (`date_folder/experiment/logs/`) and nested ones where
experiment sessions live inside a sub-folder (`date_folder/round1/stim_sweep/logs/`).

Date folders (depth 1) and experiment folders (depth 2) are never cataloged as assets.

## Local Storage

**Datasets** are stored under `local_data_dir/{drive_path}/`, mirroring the Drive folder hierarchy.

**Assets** are stored under `local_data_dir/assets/{drive_path}/{asset_name}`.

```
local_data_dir/
  2026-02-15_batch/
    reaching/
      rat01_session3_data.xdat      ← dataset (path-mirrored)
      rat01_session3.xdat.json
      rat01_session3_timestamp.xdat
  assets/
    2026-02-15_batch/
      reaching/
        logs/                       ← folder asset (full subtree downloaded)
          log_20260215.txt
        notes.pptx                  ← file asset
```

## Authentication

Uses a Google service account for collaboration. The credentials JSON file is shared among collaborators and referenced via config. The relevant Drive folder must be shared with the service account's email address.

## Public API

```python
from radiens_drive_catalog import (
    AssetEntry,
    Catalog,
    CatalogError,
    Config,
    DatasetEntry,
    EntryNotFoundError,
    PrefetchResult,
)

config = Config.from_file("config.json")   # or Config.from_file() to use RADIENS_DRIVE_CATALOG_CONFIG env var
catalog = Catalog(config)                  # or Catalog() to use config auto-discovery
catalog = Catalog(config, quiet=True)      # suppress tqdm progress bars during downloads

# Datasets
catalog.scan()                             # rebuild catalog from Drive (discovers datasets + assets)
catalog.df                                 # full dataset catalog as a DataFrame; query with pandas directly
catalog.list_datasets()                    # filtered DataFrame; supports drive_path, drive_path_prefix, drive_path_contains
catalog.download_dataset("2026-02-15_batch/reaching", "rat01_session3")   # download 3 xdat files
catalog.get_dataset_path("2026-02-15_batch/reaching", "rat01_session3")   # local path, downloading if needed

# Assets (non-xdat files and folders)
catalog.assets_df                          # full asset catalog as a DataFrame; query with pandas directly
catalog.list_assets()                      # filtered DataFrame; same drive_path filters plus asset_type="folder"|"file"
catalog.download_asset("2026-02-15_batch/reaching", "logs")   # download to assets subdir
catalog.get_asset_path("2026-02-15_batch/reaching", "logs")   # local path, downloading if needed

# Bulk prefetch (idempotent — skips entries already on disk)
catalog.prefetch()                                                  # everything
catalog.prefetch(drive_path_prefix="2026-02")                       # subtree
catalog.prefetch(drive_path_prefix="2026-02", assets=False)         # datasets only
catalog.prefetch(drive_path_prefix="2026-02", asset_type="folder")  # narrow assets
catalog.prefetch(force=True)                                        # re-download everything
catalog.prefetch(drive_path_prefix="2026-02", force=True)           # re-download a subtree
# Returns PrefetchResult(datasets_downloaded, datasets_skipped, assets_downloaded, assets_skipped)

# Exceptions
# EntryNotFoundError (subclass of CatalogError) — raised when dataset/asset not found
# CatalogError — raised for malformed catalog JSON
```

### Query semantics

Use the convenience methods for common queries, or operate on the raw DataFrames directly:

```python
# Convenience methods (AND semantics across all filters)
catalog.list_datasets(drive_path="2026-02-15_batch/reaching")       # exact folder
catalog.list_datasets(drive_path_prefix="2026-02")                  # subtree
catalog.list_datasets(drive_path_contains="reaching")               # any depth
catalog.list_assets(asset_type="folder")                            # folders only
catalog.list_assets(drive_path_prefix="2026-02", asset_type="file") # combined

# Raw DataFrame access (when you need more complex filtering)
catalog.df[catalog.df["drive_path"] == "2026-02-15_batch/reaching"]
catalog.df[catalog.df["drive_path"].str.startswith("2026-02")]
catalog.assets_df[catalog.assets_df["drive_path"].str.contains("reaching")]
```

**Dataset identity:** Recordings are uniquely identified by `(drive_path, base_name)`. `base_name` alone is not globally unique.

**Asset identification:** Assets are uniquely identified by `(drive_path, asset_name)`. `drive_path` is the slash-joined path to the *parent* folder (e.g. `"2026-02-15_batch/reaching"`), visible in `assets_df["drive_path"]`. Two `logs/` folders from different paths have different `drive_path` values.

## Tooling

- Package manager: `uv`
- Type checking: `mypy` (strict mode)
- Linting: `ruff`
- Testing: `pytest`
- Python: `>=3.12`

## Running Checks

Use the bundled check script to run all quality gates in one command:

```bash
./scripts/check.sh
```

What it runs (in order):

- `uv run ruff check`
- `uv run ruff format --check`
- `uv run mypy --strict`
- `uv run pytest tests/unit/ -v`

The script prints a pass/fail summary at the end and exits with status `1` if any step fails.
