from radiens_drive_catalog.catalog import Catalog

catalog = Catalog()
catalog.scan()
