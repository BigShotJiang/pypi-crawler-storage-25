from pprint import pprint

from radiens_drive_catalog import Catalog, Config

config = Config.from_file()
catalog = Catalog(config)

# Scan Drive and rebuild the catalog
catalog.scan()

# Query datasets using pandas directly
pprint(catalog.df)

catalog.list()  # everything
catalog.list(drive_path="2026-02-15_batch/reaching")  # exact folder
catalog.list(drive_path_prefix="2026-02-15_batch")  # full date subtree
catalog.list(drive_path_contains="reaching")  # any depth

# Download a dataset (3 xdat files) and get its local path
catalog.download("2026-02-15_batch/reaching", "rat01_session3")
path = catalog.get_path("2026-02-15_batch/reaching", "rat01_session3")

# Query assets (logs folders, PowerPoints, etc.)
pprint(catalog.assets_df)

# Download an asset and get its local path
catalog.download_asset("2026-02-15_batch/reaching", "logs")
asset_path = catalog.get_asset_path("2026-02-15_batch/reaching", "logs")
