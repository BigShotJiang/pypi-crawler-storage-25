# BMC — Biomimetic Cell

## A Python library for biomimetic cell models in neural networks

Refer to the three papers: 
- [Bio-mimetic approach in digital artificial neuro-science](https://ieeexplore.ieee.org/document/7560120)
- [Biomimetic Cells: A New Frontier in Brain Informatics](https://ieeexplore.ieee.org/abstract/document/8603044)
- [Advanced Biomimetic Cells Architecture for Parallel Operations in Artificial Intelligence](https://ieeexplore.ieee.org/abstract/document/8851116)

[Check it out on PyPl!](https://pypi.org/project/biomimetic-framework/)
---

A gradient-free machine learning framework built on geodesic lookup tables.

Instead of learned weights, BMC stores empirical probability distributions in Voronoi cells ordered along a geodesic path through the data manifold. No backpropagation. No loss functions. No optimizer. Just geometry.

---

## Installation

```bash
pip install biomimetic-framework
```

For image observation space support:
```bash
pip install biomimetic-framework[image]
```

## Quick Start

### Classification

```python
from bmc import BMCClassifier

clf = BMCClassifier(n_clusters=128)
clf.fit(X_train, y_train)
predictions = clf.predict(X_test)
probabilities = clf.predict_proba(X_test)
```

### Regression

```python
from bmc import BMCRegressor

reg = BMCRegressor(n_clusters=128)
reg.fit(X_train, y_train)
predictions = reg.predict(X_test)
```

### Full Control

```python
from bmc import (
    ImageObservationSpace, BMCLayer, BMCNetwork, BMCCell,
    L2Metric, SplineInterpolator,
)

# Define how to decompose inputs
obs = ImageObservationSpace(image_size=28, pool_size=10, grid_n=5, output_size=5)

# Build a 2-layer network
net = BMCNetwork([
    BMCLayer(obs, n_clusters=128, metric=L2Metric()),
    BMCCell(n_clusters=128),  # prediction head
])
net.fit(X_train, y_train, n_classes=10)
predictions = net.predict(X_test)
```

## How It Works

```
raw input
    └── ObservationSpace.extract()  →  (N_zones, M, D)  zone feature vectors
            └── BMCLayer.fit()      →  N_zones independent BMCCells
                    └── BMCLayer.transform()  →  (M, N_zones, C)  vote matrix
                            └── BMCNetwork  →  prediction head refines votes
                                    └── argmax  →  (M,)  predictions
```

**Training** (per BMCCell):
1. K-means++ initialization + Lloyd's iteration → K converged cluster centers
2. Voronoi assignment → each sample assigned to nearest center
3. LUT construction → `P(class | cell)` from empirical counts
4. TSP geodesic ordering → binary addresses with geometric meaning
5. Interpolator fitting → smooth predictions across cell boundaries

**Inference**: find nearest seed → look up stored distribution → done.

## Architecture

| Component | Role |
|---|---|
| `BMCCell` | Atomic primitive. One zone, K Voronoi cells, one LUT. |
| `BMCLayer` | N cells in parallel, one per zone. Soft voting. |
| `BMCNetwork` | Arbitrary depth. Layer 2+ acts as a prediction head. |
| `BMCClassifier` | Easy path. Auto zones + prediction head. |
| `BMCRegressor` | Continuous targets. Mean values at cells + interpolation. |

### Observation Spaces

| Space | Input | Zones |
|---|---|---|
| `TabularObservationSpace` | `(M, F)` flat features | Feature subsets |
| `ImageObservationSpace` | `(M, H, W)` grayscale | Overlapping patch grid |
| `TimeSeriesObservationSpace` | `(M, T)` or `(M, T, F)` | Sliding windows |
| `TextObservationSpace` | `(M, seq_len, embed_dim)` | Contiguous chunks |

### Metrics

`L2Metric`, `CosineMetric`, `FrobeniusMetric`, `SpectralMetric`, `NuclearMetric`

### Interpolators

| Interpolator | Space | Use case |
|---|---|---|
| `LinearInterpolator` | Arc-length | Fast default for regression |
| `SplineInterpolator` | Arc-length | Smooth C2 for classification |
| `KernelInterpolator` | Arc-length | IDW or RBF |
| `RDDAInterpolator` | Feature-space | Best regression accuracy (k=5, sensitivity='vc') |

## FPGA Deployment

BMC's inference pipeline (distance → argmin → LUT → argmax) maps directly to digital logic. The `export_for_fpga` function takes a trained `BMCCell` and generates a complete FPGA build: parameterized Verilog, quantized ROM files, testbench, and Makefile.

```python
from bmc import BMCCell, L2Metric, export_for_fpga

cell = BMCCell(n_clusters=128, metric=L2Metric())
cell.fit(X_train, y_train, n_classes=10)

result = export_for_fpga(cell, "build/", X_test=X_test, y_test=y_test)
# result["quantized_accuracy"] → 0.97
```

```bash
cd build/
make sim    # simulate with Icarus Verilog
make synth  # gate-level synthesis with Yosys
```

| Dataset | Accuracy | Model Size | Clusters |
|---|---|---|---|
| Digits (8x8, 10 classes) | 97% | 9.5 KB | K=128 |
| Accelerometer (4 states) | 100% | 48 B | K=4 |

See **[FPGA Guide](docs/BMC_FPGA_Guide.md)** for the full hardware deployment workflow.

## Documentation

- **[API Reference](docs/BMC_API_Reference.md)** — full parameter and method documentation
- **[FPGA Guide](docs/BMC_FPGA_Guide.md)** — hardware deployment, Verilog architecture, simulation
- **[Conceptual Guide](https://SariItani.github.io/bmc)** — theory, architecture, design rationale

## Notebooks

| Notebook | Observation Space | Dataset |
|---|---|---|
| [01 Tabular](notebooks/01_Tabular_BreastCancer.ipynb) | `TabularObservationSpace` | Breast Cancer (569x30) |
| [02 Image](notebooks/02_Image_Digits.ipynb) | `ImageObservationSpace` | Digits (1797x8x8) |
| [03 Time Series](notebooks/03_TimeSeries_ECG.ipynb) | `TimeSeriesObservationSpace` | ECG5000 (5000x140) |
| [04 Text](notebooks/04_Text_Newsgroups.ipynb) | `TextObservationSpace` | 20 Newsgroups (3729 docs) |
| [MNIST Demo](notebooks/BMC_MNIST_Demo.ipynb) | `ImageObservationSpace` | MNIST (60K/10K, 28x28) |

## Benchmark Results

### Classification (sklearn datasets, 70/30 split)

| Dataset | BMC | KNN | Random Forest | SVM |
|---|---|---|---|---|
| Breast Cancer (30D, 2 classes) | 96.5% | 97.1% | 93.6% | 97.7% |
| Digits (64D, 10 classes) | 97.2% | 98.7% | 96.7% | 98.9% |
| ECG5000 (140D, 5 classes) | 95.2% | 94.9% | 95.0% | 95.1% |
| 20 Newsgroups (256D, 4 classes) | 79.6% | 67.4% | 85.3% | 87.5% |

### Regression (BMCRegressor with prediction head)

| Dataset | BMC (MAE%) | KNN | Linear Reg | GBR |
|---|---|---|---|---|
| Linear | 1.4% | 2.4% | 0.8% | 0.8% |
| Sinusoidal | 1.8% | 1.9% | 17.6% | 1.8% |
| Housing-like | 3.4% | 4.8% | 2.3% | 2.3% |

## Requirements

- Python >= 3.9
- NumPy >= 1.24
- SciPy >= 1.10

Optional: Pillow, PyTorch, OpenCV (for image pooling methods)

## License

MIT
