# tests/test_backend.py
"""
Tests for the device backend abstraction.

Tests run on CPU. When CUDA is available, tests also verify GPU results
match CPU results. On machines without CUDA, GPU-specific tests are
automatically skipped.
"""

import numpy as np
import pytest

from bmc.backend import get_backend, resolve_device, CPUBackend, CUDABackend
from bmc.metrics.l2 import L2Metric
from bmc.metrics.cosine import CosineMetric
from bmc.metrics.frobenius import FrobeniusMetric
from bmc.metrics.base import SimilarityMetric

# ── check CUDA availability once ─────────────────────────────────────────────

try:
    import torch
    HAS_CUDA = torch.cuda.is_available()
except ImportError:
    HAS_CUDA = False

requires_cuda = pytest.mark.skipif(not HAS_CUDA, reason="No CUDA GPU available")


# ── resolve_device tests ────────────────────────────────────────────────────

class TestResolveDevice:

    def test_cpu_always_resolves(self):
        assert resolve_device("cpu") == "cpu"

    def test_auto_resolves_to_something(self):
        result = resolve_device("auto")
        assert result in ("cpu", "cuda")

    def test_none_resolves_like_auto(self):
        assert resolve_device(None) == resolve_device("auto")

    def test_invalid_device_raises(self):
        with pytest.raises(ValueError, match="Unknown device"):
            resolve_device("tpu")

    @requires_cuda
    def test_cuda_resolves_when_available(self):
        assert resolve_device("cuda") == "cuda"

    def test_cuda_raises_without_gpu(self):
        if HAS_CUDA:
            pytest.skip("CUDA is available on this machine")
        with pytest.raises(RuntimeError, match="no CUDA GPU"):
            resolve_device("cuda")


# ── get_backend tests ───────────────────────────────────────────────────────

class TestGetBackend:

    def test_cpu_returns_cpu_backend(self):
        backend = get_backend("cpu")
        assert backend is CPUBackend
        assert backend.device == "cpu"

    @requires_cuda
    def test_cuda_returns_cuda_backend(self):
        backend = get_backend("cuda")
        assert backend is CUDABackend
        assert backend.device == "cuda"


# ── CPU backend correctness ─────────────────────────────────────────────────

class TestCPUBackendOps:

    def setup_method(self):
        rng = np.random.default_rng(42)
        self.A = rng.standard_normal((50, 10)).astype(np.float32)
        self.B = rng.standard_normal((30, 10)).astype(np.float32)

    def test_pairwise_l2_shape(self):
        result = CPUBackend.pairwise_l2(self.A, self.B)
        assert result.shape == (50, 30)
        assert result.dtype == np.float32

    def test_pairwise_l2_nonnegative(self):
        result = CPUBackend.pairwise_l2(self.A, self.B)
        assert np.all(result >= 0)

    def test_pairwise_l2_self_diagonal_zero(self):
        result = CPUBackend.pairwise_l2(self.A, self.A)
        np.testing.assert_allclose(np.diag(result), 0.0, atol=1e-5)

    def test_pairwise_l2_symmetric(self):
        d_ab = CPUBackend.pairwise_l2(self.A, self.B)
        d_ba = CPUBackend.pairwise_l2(self.B, self.A)
        np.testing.assert_allclose(d_ab, d_ba.T, atol=1e-5)

    def test_pairwise_cosine_shape(self):
        result = CPUBackend.pairwise_cosine(self.A, self.B)
        assert result.shape == (50, 30)

    def test_pairwise_cosine_range(self):
        result = CPUBackend.pairwise_cosine(self.A, self.B)
        assert np.all(result >= -0.01)  # small float tolerance
        assert np.all(result <= 2.01)

    def test_pairwise_frobenius_matches_l2_for_flat(self):
        l2 = CPUBackend.pairwise_l2(self.A, self.B)
        frob = CPUBackend.pairwise_frobenius(self.A, self.B)
        np.testing.assert_allclose(l2, frob, atol=1e-5)

    def test_argmin(self):
        dists = CPUBackend.pairwise_l2(self.A, self.B)
        result = CPUBackend.argmin(dists, axis=1)
        expected = np.argmin(dists, axis=1).astype(np.int32)
        np.testing.assert_array_equal(result, expected)

    def test_bincount(self):
        x = np.array([0, 1, 1, 2, 2, 2], dtype=np.int32)
        result = CPUBackend.bincount(x, minlength=5)
        np.testing.assert_array_equal(result, [1, 2, 3, 0, 0])


# ── metric device parameter ─────────────────────────────────────────────────

class TestMetricDevice:

    def test_l2_default_is_cpu(self):
        m = L2Metric()
        assert m.device == "cpu"

    def test_l2_to_method(self):
        m = L2Metric()
        ret = m.to("cpu")
        assert ret is m  # returns self
        assert m.device == "cpu"

    def test_l2_device_in_repr(self):
        m = L2Metric(device="auto")
        # auto resolves to cpu on this machine, so repr won't show device
        # but explicitly setting cuda would show it
        m2 = L2Metric()
        assert "L2Metric()" in repr(m2)

    def test_cosine_accepts_device(self):
        m = CosineMetric(device="cpu")
        assert m.device == "cpu"

    def test_frobenius_accepts_device(self):
        m = FrobeniusMetric(device="cpu")
        assert m.device == "cpu"

    def test_l2_cpu_produces_correct_results(self):
        m = L2Metric(device="cpu")
        A = np.array([[1.0, 0.0], [0.0, 1.0]], dtype=np.float32)
        B = np.array([[1.0, 0.0]], dtype=np.float32)
        dists = m.pairwise(A, B)
        assert dists.shape == (2, 1)
        np.testing.assert_allclose(dists[0, 0], 0.0, atol=1e-5)
        np.testing.assert_allclose(dists[1, 0], np.sqrt(2), atol=1e-4)

    def test_metric_call_uses_backend(self):
        m = L2Metric(device="cpu")
        a = np.array([1.0, 0.0], dtype=np.float32)
        b = np.array([0.0, 1.0], dtype=np.float32)
        d = m(a, b)
        np.testing.assert_allclose(d, np.sqrt(2), atol=1e-4)


# ── GPU-specific tests (skipped without CUDA) ───────────────────────────────

@requires_cuda
class TestCUDABackendOps:
    """Verify GPU results match CPU results."""

    def setup_method(self):
        rng = np.random.default_rng(42)
        self.A = rng.standard_normal((100, 25)).astype(np.float32)
        self.B = rng.standard_normal((64, 25)).astype(np.float32)

    def test_pairwise_l2_matches_cpu(self):
        cpu = CPUBackend.pairwise_l2(self.A, self.B)
        gpu = CUDABackend.pairwise_l2(self.A, self.B)
        np.testing.assert_allclose(gpu, cpu, atol=1e-4)

    def test_pairwise_cosine_matches_cpu(self):
        cpu = CPUBackend.pairwise_cosine(self.A, self.B)
        gpu = CUDABackend.pairwise_cosine(self.A, self.B)
        np.testing.assert_allclose(gpu, cpu, atol=1e-4)

    def test_pairwise_frobenius_matches_cpu(self):
        cpu = CPUBackend.pairwise_frobenius(self.A, self.B)
        gpu = CUDABackend.pairwise_frobenius(self.A, self.B)
        np.testing.assert_allclose(gpu, cpu, atol=1e-4)

    def test_argmin_matches_cpu(self):
        dists = CPUBackend.pairwise_l2(self.A, self.B)
        cpu = CPUBackend.argmin(dists)
        gpu = CUDABackend.argmin(dists)
        np.testing.assert_array_equal(gpu, cpu)

    def test_l2_metric_with_device_cuda(self):
        m_cpu = L2Metric(device="cpu")
        m_gpu = L2Metric(device="cuda")
        cpu = m_cpu.pairwise(self.A, self.B)
        gpu = m_gpu.pairwise(self.A, self.B)
        np.testing.assert_allclose(gpu, cpu, atol=1e-4)

    def test_full_cell_fit_on_gpu(self):
        """End-to-end: BMCCell with GPU metric produces valid predictions."""
        from bmc.core.cell import BMCCell

        rng = np.random.default_rng(42)
        X = rng.standard_normal((500, 10)).astype(np.float32)
        y = (X[:, 0] > 0).astype(np.int32)

        cell = BMCCell(n_clusters=32, metric=L2Metric(device="cuda"),
                       rng=np.random.default_rng(42))
        cell.fit(X, y, n_classes=2)
        preds = cell.predict(X)
        assert preds.shape == (500,)
        assert set(preds.tolist()).issubset({0, 1})
        # should get reasonable accuracy on this simple split
        assert (preds == y).mean() > 0.8
