# tests/test_fpga_export.py
"""
Test FPGA export: train a BMCCell, export to hex + Verilog,
verify quantized accuracy and file integrity.
"""

import numpy as np
import pytest
import os
import subprocess

from bmc.core.cell import BMCCell
from bmc.metrics.l2 import L2Metric
from bmc.fpga.export import export_for_fpga


@pytest.fixture
def trained_cell():
    """Small trained BMCCell on synthetic Gaussian clusters."""
    rng = np.random.default_rng(42)
    centers = np.array([
        [0, 0, 0, 0, 5, 5, 5, 5],
        [5, 5, 5, 5, 0, 0, 0, 0],
        [10, 10, 0, 0, 10, 10, 0, 0],
        [0, 0, 10, 10, 0, 0, 10, 10],
    ], dtype=np.float32)
    X, y = [], []
    for c, center in enumerate(centers):
        X.append(center + rng.normal(0, 0.8, (40, 8)).astype(np.float32))
        y.extend([c] * 40)
    X = np.vstack(X)
    y = np.array(y, dtype=np.int32)

    cell = BMCCell(n_clusters=16, metric=L2Metric())
    cell.fit(X, y, n_classes=4)
    return cell, X, y


def test_export_creates_files(trained_cell, tmp_path):
    """Export produces all expected files."""
    cell, X, y = trained_cell
    out = tmp_path / "fpga_build"

    result = export_for_fpga(cell, str(out), X_test=X[:20], y_test=y[:20])

    assert (out / "rom" / "seeds.hex").exists()
    assert (out / "rom" / "lut.hex").exists()
    assert (out / "rom" / "test_vectors.hex").exists()
    assert (out / "rom" / "test_labels.hex").exists()
    assert (out / "rtl" / "bmc_inference.v").exists()
    assert (out / "tb" / "tb_bmc_inference.v").exists()
    assert (out / "Makefile").exists()


def test_export_metadata(trained_cell, tmp_path):
    """Returned metadata matches the cell."""
    cell, X, y = trained_cell
    result = export_for_fpga(cell, str(tmp_path), X_test=X[:20], y_test=y[:20])

    assert result["K"] == 16
    assert result["D"] == 8
    assert result["C"] == 4
    assert result["model_bytes"] == 16 * 8 + 16 * 4
    assert result["n_test"] == 20
    assert result["quantized_accuracy"] >= 0.9


def test_export_rom_sizes(trained_cell, tmp_path):
    """Hex files have the correct number of lines."""
    cell, X, y = trained_cell
    export_for_fpga(cell, str(tmp_path), X_test=X[:10], y_test=y[:10])

    seeds_lines = (tmp_path / "rom" / "seeds.hex").read_text().strip().split("\n")
    lut_lines = (tmp_path / "rom" / "lut.hex").read_text().strip().split("\n")
    test_lines = (tmp_path / "rom" / "test_vectors.hex").read_text().strip().split("\n")

    assert len(seeds_lines) == 16 * 8  # K * D
    assert len(lut_lines) == 16 * 4    # K * C
    assert len(test_lines) == 10 * 8   # N_test * D


def test_export_quantized_accuracy(trained_cell, tmp_path):
    """Quantized accuracy is close to float accuracy."""
    cell, X, y = trained_cell
    result = export_for_fpga(cell, str(tmp_path), X_test=X, y_test=y)

    # Well-separated Gaussians: quantized accuracy should be near-perfect
    assert result["quantized_accuracy"] >= 0.95


def test_export_unfitted_raises():
    """Exporting an unfitted cell raises ValueError."""
    cell = BMCCell(n_clusters=4)
    with pytest.raises(ValueError, match="not fitted"):
        export_for_fpga(cell, "/tmp/should_not_exist")


def test_export_verilog_parameterized(trained_cell, tmp_path):
    """Generated Verilog contains correct parameters."""
    cell, X, y = trained_cell
    export_for_fpga(cell, str(tmp_path))

    verilog = (tmp_path / "rtl" / "bmc_inference.v").read_text()
    assert "parameter K      = 16" in verilog
    assert "parameter D      = 8" in verilog
    assert "parameter C      = 4" in verilog


@pytest.mark.skipif(
    subprocess.run(["which", "iverilog"], capture_output=True).returncode != 0,
    reason="iverilog not installed"
)
def test_export_simulates_correctly(trained_cell, tmp_path):
    """Full round-trip: export → iverilog → simulate → check accuracy."""
    cell, X, y = trained_cell
    rng = np.random.default_rng(99)
    idx = rng.permutation(len(X))
    X_test, y_test = X[idx[:40]], y[idx[:40]]

    result = export_for_fpga(cell, str(tmp_path), X_test=X_test, y_test=y_test)

    # Compile
    compile_result = subprocess.run(
        ["iverilog", "-o", "tb_bmc.vvp", "-Irom",
         "rtl/bmc_inference.v", "tb/tb_bmc_inference.v"],
        cwd=str(tmp_path), capture_output=True, text=True
    )
    assert compile_result.returncode == 0, compile_result.stderr

    # Simulate
    sim_result = subprocess.run(
        ["vvp", "tb_bmc.vvp"],
        cwd=str(tmp_path), capture_output=True, text=True, timeout=30
    )
    assert sim_result.returncode == 0, sim_result.stderr

    # Parse accuracy from output
    for line in sim_result.stdout.split("\n"):
        if "Total:" in line and "correct" in line:
            # e.g. "  Total: 38 / 40 correct (95%)"
            parts = line.strip().split()
            correct = int(parts[1])
            total = int(parts[3])
            assert correct / total >= 0.9, f"FPGA sim accuracy {correct}/{total}"
            break
    else:
        pytest.fail(f"Could not parse accuracy from simulation output:\n{sim_result.stdout}")
