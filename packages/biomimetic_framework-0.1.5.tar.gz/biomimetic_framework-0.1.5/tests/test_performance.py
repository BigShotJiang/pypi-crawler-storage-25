# tests/test_performance.py
"""
Performance regression tests for the optimized BMC training pipeline.

Each test asserts wall-clock time stays within a generous budget
(~2x the expected optimized time) so that regressions are caught
but normal variance doesn't cause flaky failures.
"""

import time
import numpy as np
import pytest

from bmc.metrics.l2 import L2Metric
from bmc.core.seeding import kmeanspp_init, assign_clusters
from bmc.core.geodesic import build_tsp_path, tour_length
from bmc.core.cell import BMCCell, _compute_arc_lengths
from bmc.composition.layer import BMCLayer
from bmc.observation.tabular import TabularObservationSpace


# ── shared data ──────────────────────────────────────────────────────────────

M, D, K, C = 5000, 25, 256, 10


@pytest.fixture(scope="module")
def dataset():
    rng = np.random.default_rng(42)
    centers = rng.standard_normal((C, D)).astype(np.float32) * 5
    vecs, labels = [], []
    for c in range(C):
        n = M // C
        vecs.append(centers[c] + rng.standard_normal((n, D)).astype(np.float32) * 0.5)
        labels.extend([c] * n)
    X = np.vstack(vecs)
    y = np.array(labels, dtype=np.int32)
    return X, y


# ── correctness guards ───────────────────────────────────────────────────────

class TestCorrectnessAfterOptimization:
    """Ensure optimizations preserve numerical results."""

    def test_kmeanspp_produces_k_seeds(self, dataset):
        X, y = dataset
        seeds = kmeanspp_init(X, K, np.random.default_rng(42), L2Metric())
        assert seeds.shape == (K, D)
        assert seeds.dtype == np.float32

    def test_tsp_path_is_valid_permutation(self, dataset):
        X, _ = dataset
        seeds = kmeanspp_init(X, K, np.random.default_rng(42), L2Metric())
        dist_matrix = L2Metric().pairwise(seeds, seeds)
        path = build_tsp_path(dist_matrix)
        assert len(path) == K
        assert set(path.tolist()) == set(range(K))

    def test_tsp_tour_quality(self, dataset):
        """2-opt should produce a tour no worse than nearest-neighbor."""
        from bmc.core.geodesic import tsp_nearest_neighbor
        X, _ = dataset
        seeds = kmeanspp_init(X, K, np.random.default_rng(42), L2Metric())
        dist_matrix = L2Metric().pairwise(seeds, seeds)

        nn_path = tsp_nearest_neighbor(dist_matrix)
        nn_length = tour_length(np.array(nn_path), dist_matrix)

        opt_path = build_tsp_path(dist_matrix)
        opt_length = tour_length(opt_path, dist_matrix)

        assert opt_length <= nn_length + 1e-6

    def test_arc_lengths_monotonic_and_normalized(self, dataset):
        X, _ = dataset
        seeds = kmeanspp_init(X, K, np.random.default_rng(42), L2Metric())
        dist_matrix = L2Metric().pairwise(seeds, seeds)
        path = build_tsp_path(dist_matrix)
        ordered = seeds[path]

        arc = _compute_arc_lengths(ordered, L2Metric())
        assert arc[0] == 0.0
        assert abs(arc[-1] - 1.0) < 1e-10
        assert np.all(np.diff(arc) >= -1e-12)  # monotonically non-decreasing

    def test_lloyd_vectorized_matches_accuracy(self, dataset):
        """Vectorized Lloyd's must produce same cluster quality."""
        X, y = dataset
        idx = np.random.default_rng(99).permutation(M)
        X_s, y_s = X[idx], y[idx]
        X_train, X_test = X_s[:3500], X_s[3500:]
        y_train, y_test = y_s[:3500], y_s[3500:]

        cell = BMCCell(n_clusters=K, metric=L2Metric(), rng=np.random.default_rng(42))
        cell.fit(X_train, y_train, n_classes=C)
        preds = cell.predict(X_test)
        acc = (preds == y_test).mean()
        # well-separated clusters → should be near-perfect
        assert acc >= 0.95

    def test_parallel_layer_accuracy(self, dataset):
        """Parallel zone fitting must preserve accuracy."""
        X, y = dataset
        idx = np.random.default_rng(99).permutation(M)
        X_s, y_s = X[idx], y[idx]
        X_train, X_test = X_s[:3500], X_s[3500:]
        y_train, y_test = y_s[:3500], y_s[3500:]

        obs = TabularObservationSpace(n_features=D, n_zones=25)
        layer = BMCLayer(obs, n_clusters=K, metric=L2Metric(), rng=np.random.default_rng(42))
        layer.fit(X_train, y_train, n_classes=C)
        preds = layer.predict(X_test)
        acc = (preds == y_test).mean()
        assert acc >= 0.95


# ── timing tests ─────────────────────────────────────────────────────────────

class TestPerformance:
    """Wall-clock budgets. Generous limits to avoid flakiness."""

    def test_kmeanspp_under_2s(self, dataset):
        X, _ = dataset
        t0 = time.perf_counter()
        kmeanspp_init(X, K, np.random.default_rng(42), L2Metric())
        elapsed = time.perf_counter() - t0
        print(f"\nkmeanspp_init: {elapsed:.3f}s")
        assert elapsed < 2.0, f"kmeanspp_init took {elapsed:.3f}s (budget: 2.0s)"

    def test_tsp_under_0_5s(self, dataset):
        X, _ = dataset
        seeds = kmeanspp_init(X, K, np.random.default_rng(42), L2Metric())
        dist_matrix = L2Metric().pairwise(seeds, seeds)
        t0 = time.perf_counter()
        build_tsp_path(dist_matrix)
        elapsed = time.perf_counter() - t0
        print(f"\nbuild_tsp_path: {elapsed:.3f}s")
        assert elapsed < 0.5, f"build_tsp_path took {elapsed:.3f}s (budget: 0.5s)"

    def test_arc_lengths_under_1ms(self, dataset):
        X, _ = dataset
        seeds = kmeanspp_init(X, K, np.random.default_rng(42), L2Metric())
        dist_matrix = L2Metric().pairwise(seeds, seeds)
        path = build_tsp_path(dist_matrix)
        ordered = seeds[path]
        t0 = time.perf_counter()
        _compute_arc_lengths(ordered, L2Metric())
        elapsed = time.perf_counter() - t0
        print(f"\n_compute_arc_lengths: {elapsed*1000:.2f}ms")
        assert elapsed < 0.001, f"_compute_arc_lengths took {elapsed*1000:.2f}ms (budget: 1ms)"

    def test_cell_fit_under_2s(self, dataset):
        X, y = dataset
        t0 = time.perf_counter()
        cell = BMCCell(n_clusters=K, metric=L2Metric(), rng=np.random.default_rng(42))
        cell.fit(X, y, n_classes=C)
        elapsed = time.perf_counter() - t0
        print(f"\nBMCCell.fit: {elapsed:.3f}s")
        assert elapsed < 2.0, f"BMCCell.fit took {elapsed:.3f}s (budget: 2.0s)"

    def test_layer_fit_under_15s(self, dataset):
        X, y = dataset
        obs = TabularObservationSpace(n_features=D, n_zones=25)
        t0 = time.perf_counter()
        layer = BMCLayer(obs, n_clusters=K, metric=L2Metric(), rng=np.random.default_rng(42))
        layer.fit(X, y, n_classes=C)
        elapsed = time.perf_counter() - t0
        print(f"\nBMCLayer.fit (25 zones): {elapsed:.3f}s")
        assert elapsed < 15.0, f"BMCLayer.fit took {elapsed:.3f}s (budget: 15.0s)"
