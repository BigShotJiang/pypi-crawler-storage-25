# tests/test_scale.py
"""
Performance-at-scale tests.

Validates that the BMC toolkit handles realistic workloads within
acceptable time bounds and produces correct results at scale.

Covers:
- Large sample counts (10K, 50K)
- Large cluster counts (K=512, K=1024)
- High dimensionality (D=500, D=1000)
- Many parallel zones (20 zones)
- Deep networks at scale
- Inference-only scaling (large batch prediction)
- Memory: no OOM on reasonable workloads

These tests use generous time budgets (2-3x observed times) to avoid
flaky failures on slower CI machines.
"""

import time
import numpy as np
import pytest
from bmc.core.cell import BMCCell
from bmc.core.seeding import kmeanspp_init, assign_clusters
from bmc.core.geodesic import build_tsp_path
from bmc.core.lut import build_lut
from bmc.composition.layer import BMCLayer
from bmc.composition.sequential import BMCNetwork
from bmc.observation.tabular import TabularObservationSpace
from bmc.metrics.l2 import L2Metric


def _make_binary(M, D, separation=5.0, rng_seed=42):
    rng = np.random.default_rng(rng_seed)
    half = M // 2
    X = rng.normal(0, 1, (M, D)).astype(np.float32)
    X[:half] += separation
    y = np.array([0] * half + [1] * (M - half), dtype=np.int32)
    return X, y


def _make_multiclass(M, D, C, separation=5.0, rng_seed=42):
    rng = np.random.default_rng(rng_seed)
    per_class = M // C
    Xs, ys = [], []
    for c in range(C):
        center = np.zeros(D, dtype=np.float32)
        center[:min(D, 10)] = c * separation
        Xs.append(rng.normal(0, 0.5, (per_class, D)).astype(np.float32) + center)
        ys.extend([c] * per_class)
    return np.vstack(Xs), np.array(ys, dtype=np.int32)


# ══════════════════════════════════════════════════════════════════════════════
# Large sample count
# ══════════════════════════════════════════════════════════════════════════════

def test_10k_samples_fit_and_predict():
    X, y = _make_binary(10_000, 50)
    cell = BMCCell(n_clusters=128)
    t0 = time.time()
    cell.fit(X, y, n_classes=2)
    preds = cell.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 30, f"took {elapsed:.1f}s"
    assert preds.shape == (10_000,)
    assert np.mean(preds == y) >= 0.95


def test_50k_samples_fit_and_predict():
    X, y = _make_binary(50_000, 30)
    cell = BMCCell(n_clusters=256)
    t0 = time.time()
    cell.fit(X, y, n_classes=2)
    preds = cell.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 60, f"took {elapsed:.1f}s"
    assert preds.shape == (50_000,)
    assert np.mean(preds == y) >= 0.95


# ══════════════════════════════════════════════════════════════════════════════
# Large cluster count
# ══════════════════════════════════════════════════════════════════════════════

def test_k512_clusters():
    X, y = _make_binary(10_000, 50)
    cell = BMCCell(n_clusters=512)
    t0 = time.time()
    cell.fit(X, y, n_classes=2)
    preds = cell.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 60, f"took {elapsed:.1f}s"
    assert cell.seeds_.shape == (512, 50)
    assert cell.lut_.shape == (512, 2)
    assert np.mean(preds == y) >= 0.95


def test_k1024_clusters():
    X, y = _make_binary(10_000, 50)
    cell = BMCCell(n_clusters=1024)
    t0 = time.time()
    cell.fit(X, y, n_classes=2)
    preds = cell.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 120, f"took {elapsed:.1f}s"
    assert cell.seeds_.shape == (1024, 50)
    assert np.allclose(cell.lut_.sum(axis=1), 1.0)


# ══════════════════════════════════════════════════════════════════════════════
# High dimensionality
# ══════════════════════════════════════════════════════════════════════════════

def test_d500_dimensions():
    X, y = _make_binary(5_000, 500, separation=3.0)
    cell = BMCCell(n_clusters=64)
    t0 = time.time()
    cell.fit(X, y, n_classes=2)
    preds = cell.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 30, f"took {elapsed:.1f}s"
    assert cell.seeds_.shape == (64, 500)
    assert np.mean(preds == y) >= 0.90


def test_d1000_dimensions():
    X, y = _make_binary(3_000, 1000, separation=3.0)
    cell = BMCCell(n_clusters=32)
    t0 = time.time()
    cell.fit(X, y, n_classes=2)
    preds = cell.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 30, f"took {elapsed:.1f}s"
    assert preds.shape == (3_000,)
    assert np.mean(preds == y) >= 0.85


# ══════════════════════════════════════════════════════════════════════════════
# Many parallel zones
# ══════════════════════════════════════════════════════════════════════════════

def test_20_zones():
    X, y = _make_binary(5_000, 60)
    obs = TabularObservationSpace(n_features=60, n_zones=20)
    layer = BMCLayer(obs, n_clusters=32)
    t0 = time.time()
    layer.fit(X, y, n_classes=2)
    preds = layer.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 30, f"took {elapsed:.1f}s"
    assert len(layer.layers_) == 20
    assert np.mean(preds == y) >= 0.90


def test_many_zones_vote_matrix_shape():
    X, y = _make_binary(2_000, 40)
    obs = TabularObservationSpace(n_features=40, n_zones=10)
    layer = BMCLayer(obs, n_clusters=16)
    layer.fit(X, y, n_classes=2)
    vm = layer.transform(X)
    assert vm.shape == (2_000, 10, 2)
    assert np.allclose(vm.sum(axis=2), 1.0, atol=1e-5)


# ══════════════════════════════════════════════════════════════════════════════
# Deep network at scale
# ══════════════════════════════════════════════════════════════════════════════

def test_3layer_network_at_scale():
    X, y = _make_binary(5_000, 40)
    obs = TabularObservationSpace(n_features=40, n_zones=8)
    net = BMCNetwork([
        BMCLayer(obs, n_clusters=64),
        BMCCell(n_clusters=32),
        BMCCell(n_clusters=16),
    ])
    t0 = time.time()
    net.fit(X, y, n_classes=2)
    preds = net.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 30, f"took {elapsed:.1f}s"
    assert preds.shape == (5_000,)
    assert np.mean(preds == y) >= 0.85


def test_4layer_network_at_scale():
    X, y = _make_binary(5_000, 40)
    obs = TabularObservationSpace(n_features=40, n_zones=8)
    net = BMCNetwork([
        BMCLayer(obs, n_clusters=64),
        BMCCell(n_clusters=32),
        BMCCell(n_clusters=16),
        BMCCell(n_clusters=8),
    ])
    t0 = time.time()
    net.fit(X, y, n_classes=2)
    preds = net.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 30, f"took {elapsed:.1f}s"
    assert preds.shape == (5_000,)


# ══════════════════════════════════════════════════════════════════════════════
# Inference-only scaling (large batch prediction)
# ══════════════════════════════════════════════════════════════════════════════

def test_large_batch_inference():
    """Train on small data, predict on large batch."""
    X_train, y_train = _make_binary(1_000, 30)
    cell = BMCCell(n_clusters=64)
    cell.fit(X_train, y_train, n_classes=2)

    rng = np.random.default_rng(99)
    X_test = rng.normal(0, 1, (50_000, 30)).astype(np.float32)
    t0 = time.time()
    preds = cell.predict(X_test)
    elapsed = time.time() - t0
    assert elapsed < 15, f"inference took {elapsed:.1f}s"
    assert preds.shape == (50_000,)


def test_large_batch_inference_layer():
    """BMCLayer inference on large batch."""
    X_train, y_train = _make_binary(2_000, 40)
    obs = TabularObservationSpace(n_features=40, n_zones=8)
    layer = BMCLayer(obs, n_clusters=32)
    layer.fit(X_train, y_train, n_classes=2)

    rng = np.random.default_rng(99)
    X_test = rng.normal(0, 1, (20_000, 40)).astype(np.float32)
    t0 = time.time()
    preds = layer.predict(X_test)
    elapsed = time.time() - t0
    assert elapsed < 15, f"inference took {elapsed:.1f}s"
    assert preds.shape == (20_000,)


# ══════════════════════════════════════════════════════════════════════════════
# Multiclass at scale
# ══════════════════════════════════════════════════════════════════════════════

def test_10_classes_at_scale():
    X, y = _make_multiclass(10_000, 50, C=10)
    cell = BMCCell(n_clusters=256)
    t0 = time.time()
    cell.fit(X, y, n_classes=10)
    preds = cell.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 30, f"took {elapsed:.1f}s"
    assert cell.lut_.shape == (256, 10)
    # with 10 well-separated classes, should beat random (10%)
    assert np.mean(preds == y) >= 0.70


def test_50_classes_at_scale():
    X, y = _make_multiclass(5_000, 100, C=50, separation=8.0)
    cell = BMCCell(n_clusters=256)
    t0 = time.time()
    cell.fit(X, y, n_classes=50)
    preds = cell.predict(X)
    elapsed = time.time() - t0
    assert elapsed < 60, f"took {elapsed:.1f}s"
    assert cell.lut_.shape == (256, 50)
    assert np.mean(preds == y) >= 0.30  # well above chance (2%)


# ══════════════════════════════════════════════════════════════════════════════
# Geodesic TSP scaling
# ══════════════════════════════════════════════════════════════════════════════

def test_tsp_k256():
    rng = np.random.default_rng(42)
    seeds = rng.normal(0, 1, (256, 20)).astype(np.float32)
    metric = L2Metric()
    dists = metric.pairwise(seeds, seeds)
    t0 = time.time()
    path = build_tsp_path(dists)
    elapsed = time.time() - t0
    assert elapsed < 10, f"TSP K=256 took {elapsed:.1f}s"
    assert sorted(path.tolist()) == list(range(256))


def test_tsp_k512():
    rng = np.random.default_rng(42)
    seeds = rng.normal(0, 1, (512, 20)).astype(np.float32)
    metric = L2Metric()
    dists = metric.pairwise(seeds, seeds)
    t0 = time.time()
    path = build_tsp_path(dists)
    elapsed = time.time() - t0
    assert elapsed < 60, f"TSP K=512 took {elapsed:.1f}s"
    assert sorted(path.tolist()) == list(range(512))


# ══════════════════════════════════════════════════════════════════════════════
# Seeding scaling
# ══════════════════════════════════════════════════════════════════════════════

def test_seeding_50k_samples():
    rng = np.random.default_rng(42)
    X = rng.normal(0, 1, (50_000, 30)).astype(np.float32)
    t0 = time.time()
    seeds = kmeanspp_init(X, 256, rng)
    elapsed = time.time() - t0
    assert elapsed < 60, f"seeding took {elapsed:.1f}s"
    assert seeds.shape == (256, 30)


# ══════════════════════════════════════════════════════════════════════════════
# LUT invariants hold at scale
# ══════════════════════════════════════════════════════════════════════════════

def test_lut_invariants_at_scale():
    """All mathematical invariants must hold at scale, not just on toy data."""
    X, y = _make_multiclass(10_000, 50, C=5)
    cell = BMCCell(n_clusters=256)
    cell.fit(X, y, n_classes=5)

    # LUT rows sum to 1.0
    assert np.allclose(cell.lut_.sum(axis=1), 1.0, atol=1e-10)
    # LUT values non-negative
    assert np.all(cell.lut_ >= 0)
    # TSP path is valid permutation
    assert sorted(cell.tsp_path_.tolist()) == list(range(256))
    # Purity in valid range
    purities = cell.purity()
    assert np.all(purities >= 1.0 / 5 - 1e-10)
    assert np.all(purities <= 1.0 + 1e-10)
    # Transform rows sum to 1.0
    dists = cell.transform(X[:100])
    assert np.allclose(dists.sum(axis=1), 1.0, atol=1e-5)
