# bmc/backend.py
"""
Device backend for the BMC framework.

Provides a thin abstraction over NumPy (CPU) and PyTorch (GPU) for the
operations that dominate training time: pairwise distances, argmin,
bincount, and matrix multiply.

Usage:
    from bmc.backend import get_backend

    xp = get_backend("cuda")   # GPU via PyTorch
    xp = get_backend("cpu")    # NumPy (default)

    # All backend functions accept and return NumPy arrays at the boundary.
    # Internally they use the appropriate device.

The backend is NOT a full array library — it only wraps the specific
operations that are hot in the BMC training loop. Everything else
stays in NumPy.
"""

import numpy as np
from typing import Optional

_TORCH_AVAILABLE = None
_CUDA_AVAILABLE = None


def _check_torch():
    global _TORCH_AVAILABLE, _CUDA_AVAILABLE
    if _TORCH_AVAILABLE is None:
        try:
            import torch
            _TORCH_AVAILABLE = True
            _CUDA_AVAILABLE = torch.cuda.is_available()
        except ImportError:
            _TORCH_AVAILABLE = False
            _CUDA_AVAILABLE = False
    return _TORCH_AVAILABLE, _CUDA_AVAILABLE


def resolve_device(device: Optional[str] = None) -> str:
    """
    Resolve a device string to an actual usable device.

    Parameters
    ----------
    device : str or None
        "cuda", "cpu", or None (auto-detect).

    Returns
    -------
    device : str
        "cuda" or "cpu".
    """
    has_torch, has_cuda = _check_torch()

    if device is None or device == "auto":
        return "cuda" if has_cuda else "cpu"
    if device == "cuda":
        if not has_torch:
            raise RuntimeError(
                "device='cuda' requires PyTorch. Install with: pip install torch"
            )
        if not has_cuda:
            raise RuntimeError(
                "device='cuda' requested but no CUDA GPU is available. "
                "Use device='cpu' or device='auto'."
            )
        return "cuda"
    if device == "cpu":
        return "cpu"
    raise ValueError(f"Unknown device: {device!r}. Use 'cpu', 'cuda', or 'auto'.")


# ── CPU backend (NumPy) ─────────────────────────────────────────────────────

class CPUBackend:
    """NumPy-based backend. Zero overhead — just wraps existing operations."""

    device = "cpu"

    @staticmethod
    def pairwise_l2(A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """(M, D) x (K, D) -> (M, K) L2 distances."""
        A = np.asarray(A, dtype=np.float64)
        B = np.asarray(B, dtype=np.float64)
        if A.ndim > 2:
            A = A.reshape(len(A), -1)
        if B.ndim > 2:
            B = B.reshape(len(B), -1)
        sq_A = (A ** 2).sum(axis=1, keepdims=True)
        sq_B = (B ** 2).sum(axis=1, keepdims=True).T
        cross = A @ B.T
        dist2 = np.maximum(sq_A + sq_B - 2.0 * cross, 0.0)
        return np.sqrt(dist2).astype(np.float32)

    @staticmethod
    def pairwise_cosine(A: np.ndarray, B: np.ndarray, eps: float = 1e-8) -> np.ndarray:
        """(M, D) x (K, D) -> (M, K) cosine distances."""
        A = np.asarray(A, dtype=np.float32).reshape(len(A), -1)
        B = np.asarray(B, dtype=np.float32).reshape(len(B), -1)
        A_norm = A / (np.linalg.norm(A, axis=1, keepdims=True) + eps)
        B_norm = B / (np.linalg.norm(B, axis=1, keepdims=True) + eps)
        similarity = np.clip(A_norm @ B_norm.T, -1.0, 1.0)
        return (1.0 - similarity).astype(np.float32)

    @staticmethod
    def pairwise_frobenius(A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """(M, ...) x (K, ...) -> (M, K) Frobenius distances."""
        A = np.asarray(A, dtype=np.float64).reshape(len(A), -1)
        B = np.asarray(B, dtype=np.float64).reshape(len(B), -1)
        sq_A = (A ** 2).sum(axis=1, keepdims=True)
        sq_B = (B ** 2).sum(axis=1, keepdims=True).T
        cross = A @ B.T
        dist2 = np.maximum(sq_A + sq_B - 2.0 * cross, 0.0)
        return np.sqrt(dist2).astype(np.float32)

    @staticmethod
    def argmin(dists: np.ndarray, axis: int = 1) -> np.ndarray:
        return np.argmin(dists, axis=axis).astype(np.int32)

    @staticmethod
    def bincount(x: np.ndarray, weights: Optional[np.ndarray] = None,
                 minlength: int = 0) -> np.ndarray:
        return np.bincount(x, weights=weights, minlength=minlength)


# ── GPU backend (PyTorch) ───────────────────────────────────────────────────

class CUDABackend:
    """
    PyTorch CUDA backend.

    Accepts NumPy arrays, moves them to GPU, runs the operation,
    and returns NumPy arrays. The GPU tensors are freed after each call.

    For large M*K products (the pairwise distance matrix), this is
    dramatically faster than CPU — matrix multiply is the canonical
    GPU workload.
    """

    device = "cuda"

    @staticmethod
    def _to_gpu(arr, dtype=None):
        import torch
        if dtype is None:
            dtype = torch.float32
        return torch.as_tensor(np.ascontiguousarray(arr), dtype=dtype, device="cuda")

    @staticmethod
    def pairwise_l2(A: np.ndarray, B: np.ndarray) -> np.ndarray:
        import torch
        A_flat = np.asarray(A, dtype=np.float32).reshape(len(A), -1)
        B_flat = np.asarray(B, dtype=np.float32).reshape(len(B), -1)

        At = CUDABackend._to_gpu(A_flat)
        Bt = CUDABackend._to_gpu(B_flat)

        # ||a - b||^2 = ||a||^2 + ||b||^2 - 2*a·b
        sq_A = (At ** 2).sum(dim=1, keepdim=True)
        sq_B = (Bt ** 2).sum(dim=1, keepdim=True).t()
        cross = At @ Bt.t()
        dist2 = torch.clamp(sq_A + sq_B - 2.0 * cross, min=0.0)
        result = torch.sqrt(dist2)
        return result.cpu().numpy()

    @staticmethod
    def pairwise_cosine(A: np.ndarray, B: np.ndarray, eps: float = 1e-8) -> np.ndarray:
        import torch
        A_flat = np.asarray(A, dtype=np.float32).reshape(len(A), -1)
        B_flat = np.asarray(B, dtype=np.float32).reshape(len(B), -1)

        At = CUDABackend._to_gpu(A_flat)
        Bt = CUDABackend._to_gpu(B_flat)

        At = At / (At.norm(dim=1, keepdim=True) + eps)
        Bt = Bt / (Bt.norm(dim=1, keepdim=True) + eps)
        similarity = torch.clamp(At @ Bt.t(), -1.0, 1.0)
        return (1.0 - similarity).cpu().numpy()

    @staticmethod
    def pairwise_frobenius(A: np.ndarray, B: np.ndarray) -> np.ndarray:
        # Frobenius on flat vectors is identical to L2
        return CUDABackend.pairwise_l2(A, B)

    @staticmethod
    def argmin(dists: np.ndarray, axis: int = 1) -> np.ndarray:
        import torch
        t = CUDABackend._to_gpu(dists)
        result = torch.argmin(t, dim=axis)
        return result.cpu().numpy().astype(np.int32)

    @staticmethod
    def bincount(x: np.ndarray, weights: Optional[np.ndarray] = None,
                 minlength: int = 0) -> np.ndarray:
        # bincount is not a GPU win — keep on CPU
        return np.bincount(x, weights=weights, minlength=minlength)


# ── factory ──────────────────────────────────────────────────────────────────

_BACKENDS = {
    "cpu": CPUBackend,
    "cuda": CUDABackend,
}


def get_backend(device: Optional[str] = None):
    """
    Return the backend for the given device.

    Parameters
    ----------
    device : str or None
        "cpu", "cuda", or None (auto-detect).

    Returns
    -------
    backend : CPUBackend or CUDABackend
    """
    resolved = resolve_device(device)
    return _BACKENDS[resolved]
