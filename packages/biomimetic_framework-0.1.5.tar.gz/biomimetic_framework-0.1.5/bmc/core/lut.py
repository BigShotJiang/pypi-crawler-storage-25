# bmc/core/lut.py
"""
Lookup Table (LUT) construction and management.

The LUT is the compiled knowledge of a BMC layer. It maps each Voronoi
cell (identified by its binary address — its position in the TSP tour)
to a probability distribution over output classes.

Construction is purely empirical — no optimization, no gradients.
For each cluster, count how many training samples of each class fell
into it, then normalize to a probability distribution. This is a
maximum likelihood estimate of P(class | cell).

The TSP reordering step assigns binary addresses to cells by permuting
LUT rows so that row i corresponds to the i-th seed on the geodesic.
After reordering, adjacent binary addresses correspond to adjacent
positions on the manifold — a property exploited by the interpolation layer.

LUT2 (second-layer LUT) applies the same construction one level up:
the input is the flattened vote matrix (25 zones × N_CLASSES), and
the output is a refined probability distribution. The algorithm is
identical — only the input space changes.
"""

import numpy as np


def build_lut(
    assignments: np.ndarray,
    labels: np.ndarray,
    n_clusters: int,
    n_classes: int,
) -> np.ndarray:
    """
    Build a lookup table from cluster assignments and labels.

    For each cluster k, compute the empirical distribution over classes:
        lut[k, c] = count(labels == c AND assignments == k) / count(assignments == k)

    Empty clusters receive a uniform distribution (maximum entropy default).

    Parameters
    ----------
    assignments : np.ndarray, shape (M,), dtype int
        Cluster index for each training sample. Values in [0, n_clusters).
    labels : np.ndarray, shape (M,), dtype int
        Class label for each training sample. Values in [0, n_classes).
    n_clusters : int
        Total number of clusters K.
    n_classes : int
        Total number of output classes C.

    Returns
    -------
    lut : np.ndarray, shape (K, C), dtype float64
        lut[k] is a probability distribution over C classes.
        Each row sums to 1.0.
    """
    lut = np.zeros((n_clusters, n_classes), dtype=np.float64)
    uniform = np.full(n_classes, 1.0 / n_classes, dtype=np.float64)

    for k in range(n_clusters):
        mask = assignments == k
        count = mask.sum()
        if count == 0:
            lut[k] = uniform
        else:
            counts = np.bincount(labels[mask], minlength=n_classes).astype(np.float64)
            lut[k] = counts / counts.sum()

    return lut


def reorder_lut(
    lut: np.ndarray,
    tsp_path: np.ndarray,
) -> np.ndarray:
    """
    Reorder LUT rows according to the TSP geodesic path.

    After reordering, lut[i] corresponds to the i-th seed on the geodesic.
    The binary address of a cell equals its index in the reordered LUT.

    Parameters
    ----------
    lut : np.ndarray, shape (K, C)
        Original LUT with arbitrary row ordering.
    tsp_path : np.ndarray, shape (K,), dtype int
        TSP-ordered seed indices from build_tsp_path.

    Returns
    -------
    reordered : np.ndarray, shape (K, C)
        LUT with rows permuted so row i = original row tsp_path[i].
    """
    return lut[tsp_path]


def build_lut2(
    vote_matrix: np.ndarray,
    labels: np.ndarray,
    n_clusters: int,
    metric: "bmc.metrics.base.SimilarityMetric" = None,
    rng: np.random.Generator = None,
) -> tuple:
    """
    Build the second-layer LUT from the vote matrix.

    The vote matrix encodes each training sample as the concatenated
    probability distributions from all parallel zones. This is a point
    in R^(N_zones * N_classes). LUT2 clusters these points and builds
    a second LUT mapping voting-pattern clusters to class distributions.

    Parameters
    ----------
    vote_matrix : np.ndarray, shape (M, N_zones * N_classes) or (M, N_zones, N_classes)
        Flattened or unflattened vote matrix for all training samples.
    labels : np.ndarray, shape (M,), dtype int
        Class labels for training samples.
    n_clusters : int
        Number of second-layer clusters K2.
    metric : SimilarityMetric, optional
        Distance metric for clustering. Defaults to L2.
    rng : np.random.Generator, optional
        Random generator. Defaults to default_rng(42).

    Returns
    -------
    seeds2 : np.ndarray, shape (K2, D2)
        Second-layer cluster seeds.
    lut2 : np.ndarray, shape (K2, N_classes)
        Second-layer lookup table.
    tsp_path2 : np.ndarray, shape (K2,)
        TSP ordering of second-layer seeds.
    """
    from bmc.core.seeding import kmeanspp_init, assign_clusters
    from bmc.core.geodesic import build_tsp_path

    if metric is None:
        from bmc.metrics.l2 import L2Metric
        metric = L2Metric()
    if rng is None:
        rng = np.random.default_rng(42)

    # flatten if needed
    V = vote_matrix.reshape(len(vote_matrix), -1).astype(np.float32)
    n_classes = labels.max() + 1

    # seed and assign
    seeds2 = kmeanspp_init(V, n_clusters, rng, metric)
    assignments2 = assign_clusters(V, seeds2, metric)

    # build LUT2
    lut2 = build_lut(assignments2, labels, n_clusters, n_classes)

    # TSP ordering
    dist_matrix = metric.pairwise(seeds2, seeds2)
    tsp_path2 = build_tsp_path(dist_matrix)

    # reorder
    seeds2 = seeds2[tsp_path2]
    lut2 = reorder_lut(lut2, tsp_path2)

    return seeds2, lut2, tsp_path2


def lut_purity(lut: np.ndarray) -> np.ndarray:
    """
    Compute the purity of each LUT row.

    Purity = max probability across classes. A pure cluster has
    purity = 1.0 (all samples belong to one class). A completely
    mixed cluster has purity = 1/n_classes.

    Parameters
    ----------
    lut : np.ndarray, shape (K, C)

    Returns
    -------
    purities : np.ndarray, shape (K,)
        Per-cluster purity values in [1/C, 1.0].
    """
    return lut.max(axis=1)


def lut_dominant_class(lut: np.ndarray) -> np.ndarray:
    """
    Return the dominant (most probable) class for each LUT row.

    Parameters
    ----------
    lut : np.ndarray, shape (K, C)

    Returns
    -------
    dominant : np.ndarray, shape (K,), dtype int
        dominant[k] = argmax(lut[k]).
    """
    return np.argmax(lut, axis=1).astype(np.int32)
