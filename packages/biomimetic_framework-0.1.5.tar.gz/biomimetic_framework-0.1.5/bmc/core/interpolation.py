# bmc/core/interpolation.py
"""
Geodesic interpolation — the theoretically complete inference mechanism.

This module implements the parametric manifold interpolation step that
makes the BMC framework a continuous approximation of the ideal infinite
lookup table, rather than a discrete nearest-neighbor retrieval.

The core idea: when a query point falls inside a Voronoi cell, instead
of returning that cell's LUT row unchanged, we find where along the
geodesic segment [p_i, p_{i+1}] the query projects, and blend the
two adjacent LUT rows proportionally.

This gives the prediction head continuity across cell boundaries —
the output glides along the manifold instead of snapping between
discrete distributions at Voronoi boundaries.

Mathematical basis:
Given query x assigned to seed p_i with TSP neighbor p_{i+1}:
    t = project_onto_segment(x, p_i, p_{i+1})   # t in [0, 1]
    f(x) = (1 - t) * lut[i] + t * lut[i+1]

Boundary conditions:
    t = 0 => f(x) = lut[i]       (x is at p_i)
    t = 1 => f(x) = lut[i+1]     (x is at p_{i+1})
    t = 0.5 => f(x) = mean(lut[i], lut[i+1])

The projection is clamped to [0, 1] so queries outside the segment
are handled gracefully.
"""

import numpy as np


def project_onto_segment(
    query: np.ndarray,
    p0: np.ndarray,
    p1: np.ndarray,
) -> float:
    """
    Project a query point onto the line segment [p0, p1].

    Returns the scalar t in [0, 1] such that the projection of query
    onto the segment is p0 + t * (p1 - p0).

    t = 0 means the projection is at p0.
    t = 1 means the projection is at p1.
    Values outside [0, 1] are clamped — the projection is always
    within the segment bounds.

    Parameters
    ----------
    query : np.ndarray, shape (D,)
        The query point to project.
    p0 : np.ndarray, shape (D,)
        Start of the segment.
    p1 : np.ndarray, shape (D,)
        End of the segment.

    Returns
    -------
    t : float
        Projection parameter in [0, 1].

    Notes
    -----
    For a zero-length segment (p0 == p1), returns 0.0.
    """
    query = np.asarray(query, dtype=np.float64).flatten()
    p0 = np.asarray(p0, dtype=np.float64).flatten()
    p1 = np.asarray(p1, dtype=np.float64).flatten()

    direction = p1 - p0
    seg_len_sq = float(np.dot(direction, direction))

    if seg_len_sq < 1e-12:
        # degenerate segment — p0 and p1 are the same point
        return 0.0

    t = float(np.dot(query - p0, direction) / seg_len_sq)
    return float(np.clip(t, 0.0, 1.0))


def project_onto_segment_batch(
    queries: np.ndarray,
    p0: np.ndarray,
    p1: np.ndarray,
) -> np.ndarray:
    """
    Project a batch of query points onto the segment [p0, p1].

    Vectorized version of project_onto_segment.

    Parameters
    ----------
    queries : np.ndarray, shape (M, D)
    p0 : np.ndarray, shape (D,)
    p1 : np.ndarray, shape (D,)

    Returns
    -------
    t : np.ndarray, shape (M,), float64
        Per-query projection parameters, clamped to [0, 1].
    """
    queries = np.asarray(queries, dtype=np.float64)
    p0 = np.asarray(p0, dtype=np.float64).flatten()
    p1 = np.asarray(p1, dtype=np.float64).flatten()

    direction = p1 - p0
    seg_len_sq = float(np.dot(direction, direction))

    if seg_len_sq < 1e-12:
        return np.zeros(len(queries), dtype=np.float64)

    # (M, D) - (D,) -> (M, D), then dot with direction -> (M,)
    t = (queries.reshape(len(queries), -1) - p0) @ direction / seg_len_sq
    return np.clip(t, 0.0, 1.0)


def interpolate_distributions(
    lut_i: np.ndarray,
    lut_j: np.ndarray,
    t: float,
) -> np.ndarray:
    """
    Linearly interpolate between two LUT rows.

    Parameters
    ----------
    lut_i : np.ndarray, shape (C,)
        Distribution at the first seed (t=0 endpoint).
    lut_j : np.ndarray, shape (C,)
        Distribution at the second seed (t=1 endpoint).
    t : float
        Interpolation parameter in [0, 1].

    Returns
    -------
    blended : np.ndarray, shape (C,)
        (1 - t) * lut_i + t * lut_j.
        Guaranteed to be a valid probability distribution if both
        lut_i and lut_j are valid probability distributions.
    """
    t = float(np.clip(t, 0.0, 1.0))
    return (1.0 - t) * np.asarray(lut_i, dtype=np.float64) + t * np.asarray(lut_j, dtype=np.float64)


def interpolate_distributions_batch(
    lut_i: np.ndarray,
    lut_j: np.ndarray,
    t: np.ndarray,
) -> np.ndarray:
    """
    Batch linear interpolation between two LUT rows.

    Parameters
    ----------
    lut_i : np.ndarray, shape (C,)
    lut_j : np.ndarray, shape (C,)
    t : np.ndarray, shape (M,)

    Returns
    -------
    blended : np.ndarray, shape (M, C)
    """
    t = np.clip(np.asarray(t, dtype=np.float64), 0.0, 1.0)
    lut_i = np.asarray(lut_i, dtype=np.float64)
    lut_j = np.asarray(lut_j, dtype=np.float64)
    # (M, 1) * (C,) broadcasting
    return (1.0 - t[:, np.newaxis]) * lut_i + t[:, np.newaxis] * lut_j


def lookup_interpolated_single_zone(
    vectors: np.ndarray,
    seeds: np.ndarray,
    lut: np.ndarray,
    tsp_path: np.ndarray,
    metric: "bmc.metrics.base.SimilarityMetric",
) -> np.ndarray:
    """
    Interpolated LUT lookup for a single zone.

    For each query:
    1. Find nearest seed p_i (Voronoi assignment)
    2. Select the closer TSP neighbor j* from {i-1, i+1} (symmetric)
    3. Project query onto segment [p_i, p_{j*}] to get t
    4. Interpolate lut[i] and lut[j*] by t

    The neighbor selection is symmetric: the query is blended toward
    whichever geodesic neighbor it is closer to, not always toward
    p_{i+1}. This correctly handles queries on either side of p_i
    in the Voronoi cell.

    The interpolation weight uses segment projection (not distance ratio)
    so that t measures the query's position along the geodesic segment,
    not its raw distance. This prevents over-blending in high dimensions
    where neighboring seeds are close in absolute distance.

    Parameters
    ----------
    vectors : np.ndarray, shape (M, D)
    seeds : np.ndarray, shape (K, D)
        Seeds in TSP order (already reordered by reorder_lut).
    lut : np.ndarray, shape (K, C)
        LUT in TSP order (already reordered).
    tsp_path : np.ndarray, shape (K,)
        TSP path — used to identify geodesic neighbors.
        After reordering, the neighbors of seed i are (i-1) % K and (i+1) % K.
    metric : SimilarityMetric

    Returns
    -------
    distributions : np.ndarray, shape (M, C)
        Interpolated distributions for each query.
    """
    dists = metric.pairwise(vectors, seeds)    # (M, K)
    nearest_idx = np.argmin(dists, axis=1)     # (M,) — index in TSP order

    K = len(seeds)
    M = len(vectors)
    C = lut.shape[1]
    result = np.zeros((M, C), dtype=np.float64)

    for m in range(M):
        i = int(nearest_idx[m])
        j_prev = (i - 1) % K
        j_next = (i + 1) % K

        d_prev = float(dists[m, j_prev])
        d_next = float(dists[m, j_next])

        # symmetric neighbor selection — which direction to blend
        j = j_prev if d_prev <= d_next else j_next

        # projection-based blending — how far along that segment
        p_i = seeds[i].flatten().astype(np.float64)
        p_j = seeds[j].flatten().astype(np.float64)
        q = vectors[m].flatten().astype(np.float64)
        t = project_onto_segment(q, p_i, p_j)

        result[m] = interpolate_distributions(lut[i], lut[j], t)

    return result


def forward_interpolated(
    zone_vectors: np.ndarray,
    zone_seeds: np.ndarray,
    zone_luts: np.ndarray,
    zone_tsp_paths: np.ndarray,
    metric: "bmc.metrics.base.SimilarityMetric",
    return_distributions: bool = False,
):
    """
    Full interpolated forward pass through a parallel BMC layer.

    Parameters
    ----------
    zone_vectors : np.ndarray, shape (N_zones, M, D)
    zone_seeds : np.ndarray, shape (N_zones, K, D)
        Seeds in TSP order per zone.
    zone_luts : np.ndarray, shape (N_zones, K, C)
        LUTs in TSP order per zone.
    zone_tsp_paths : np.ndarray, shape (N_zones, K)
    metric : SimilarityMetric
    return_distributions : bool

    Returns
    -------
    predictions : np.ndarray, shape (M,), dtype int32
    distributions : np.ndarray, shape (M, C), optional
    """
    N_zones, M, D = zone_vectors.shape
    C = zone_luts.shape[2]

    zone_dists = np.zeros((N_zones, M, C), dtype=np.float64)

    for z in range(N_zones):
        zone_dists[z] = lookup_interpolated_single_zone(
            zone_vectors[z],
            zone_seeds[z],
            zone_luts[z],
            zone_tsp_paths[z],
            metric,
        )

    accumulated = zone_dists.sum(axis=0)
    predictions = np.argmax(accumulated, axis=1).astype(np.int32)

    if return_distributions:
        return predictions, accumulated
    return predictions
