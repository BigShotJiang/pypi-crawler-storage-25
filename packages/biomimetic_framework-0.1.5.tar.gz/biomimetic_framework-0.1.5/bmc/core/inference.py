# bmc/core/inference.py
"""
Inference — mapping inputs to predictions via Voronoi lookup.

This module implements the forward pass of a BMC layer.
Given a set of trained seeds and a LUT, inference proceeds as:

1. For each input vector, compute distances to all seeds
2. Find the nearest seed (Voronoi assignment)
3. Retrieve the probability distribution stored at that seed's LUT row
4. Accumulate distributions across all parallel zones
5. Return argmax as the hard prediction, or the full distribution

The hard inference (nearest-neighbor snap) is the current default.
The interpolated inference (predict_interpolated in interpolation.py)
is the theoretically complete version — it will produce softer
predictions by blending adjacent LUT rows based on the input's
position on the geodesic segment.
"""

import numpy as np
from typing import Optional


def lookup_single_zone(
    vectors: np.ndarray,
    seeds: np.ndarray,
    lut: np.ndarray,
    metric: "bmc.metrics.base.SimilarityMetric",
) -> np.ndarray:
    """
    Run a single-zone LUT lookup for a batch of input vectors.

    Parameters
    ----------
    vectors : np.ndarray, shape (M, D)
        Input vectors for this zone.
    seeds : np.ndarray, shape (K, D)
        Trained seed vectors for this zone.
    lut : np.ndarray, shape (K, C)
        Lookup table for this zone.
    metric : SimilarityMetric
        Distance metric for nearest-seed lookup.

    Returns
    -------
    distributions : np.ndarray, shape (M, C)
        distributions[i] = lut[nearest_seed_to_vectors[i]]
    """
    dists = metric.pairwise(vectors, seeds)    # (M, K)
    nearest = np.argmin(dists, axis=1)         # (M,)
    return lut[nearest]                         # (M, C)


def accumulate_zones(
    zone_distributions: np.ndarray,
) -> np.ndarray:
    """
    Accumulate probability distributions across parallel zones.

    Soft voting: sum the distributions from all zones, then
    the argmax of the sum is the final prediction. This is
    equivalent to log-linear opinion pooling under equal zone weights.

    Parameters
    ----------
    zone_distributions : np.ndarray, shape (N_zones, M, C)
        Per-zone probability distributions for each sample.

    Returns
    -------
    accumulated : np.ndarray, shape (M, C)
        Sum of distributions across all zones. Not normalized —
        use argmax directly or normalize explicitly.
    """
    return zone_distributions.sum(axis=0)


def predict(
    accumulated: np.ndarray,
) -> np.ndarray:
    """
    Convert accumulated distributions to hard class predictions.

    Parameters
    ----------
    accumulated : np.ndarray, shape (M, C)
        Accumulated (summed) probability distributions.

    Returns
    -------
    predictions : np.ndarray, shape (M,), dtype int32
        Predicted class index for each sample.
    """
    return np.argmax(accumulated, axis=1).astype(np.int32)


def forward(
    zone_vectors: np.ndarray,
    zone_seeds: np.ndarray,
    zone_luts: np.ndarray,
    metric: "bmc.metrics.base.SimilarityMetric",
    return_distributions: bool = False,
) -> np.ndarray:
    """
    Full forward pass through a parallel BMC layer.

    Parameters
    ----------
    zone_vectors : np.ndarray, shape (N_zones, M, D)
        Input vectors per zone.
    zone_seeds : np.ndarray, shape (N_zones, K, D)
        Seeds per zone.
    zone_luts : np.ndarray, shape (N_zones, K, C)
        LUT per zone.
    metric : SimilarityMetric
        Distance metric.
    return_distributions : bool
        If True, return the full (M, C) accumulated distribution
        in addition to the (M,) predictions.

    Returns
    -------
    predictions : np.ndarray, shape (M,), dtype int32
        Hard class predictions.
    distributions : np.ndarray, shape (M, C), optional
        Only returned if return_distributions=True.
        Accumulated probability distributions (unnormalized sum).
    """
    N_zones, M, D = zone_vectors.shape
    C = zone_luts.shape[2]

    zone_dists = np.zeros((N_zones, M, C), dtype=np.float64)

    for z in range(N_zones):
        zone_dists[z] = lookup_single_zone(
            zone_vectors[z], zone_seeds[z], zone_luts[z], metric
        )

    accumulated = accumulate_zones(zone_dists)   # (M, C)
    preds = predict(accumulated)

    if return_distributions:
        return preds, accumulated
    return preds


def normalize_distributions(distributions: np.ndarray) -> np.ndarray:
    """
    Normalize accumulated distributions to valid probability vectors.

    Parameters
    ----------
    distributions : np.ndarray, shape (M, C)
        Accumulated (unnormalized) distributions.

    Returns
    -------
    normalized : np.ndarray, shape (M, C)
        Row-normalized distributions summing to 1.0.
    """
    totals = distributions.sum(axis=1, keepdims=True)
    # guard against zero-sum rows (shouldn't happen in practice)
    totals = np.where(totals == 0, 1.0, totals)
    return distributions / totals
