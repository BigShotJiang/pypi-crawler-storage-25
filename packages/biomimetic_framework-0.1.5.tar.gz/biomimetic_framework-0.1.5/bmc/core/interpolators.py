# bmc/core/interpolators.py
"""
Interpolator abstractions for the BMC framework.

An interpolator maps arc-length positions on the geodesic to output values.
It is fitted once at training time (after TSP ordering) and evaluated at
inference time for each query.

Three implementations:

- LinearInterpolator: piecewise-linear blend between adjacent prototypes.
  Fast, O(1) per query. The original BMC interpolation mechanism.

- SplineInterpolator: cubic spline through all prototypes. C2 continuous.
  Respects the smooth manifold structure. One scipy call at fit time.

- KernelInterpolator: inverse distance weighting or RBF interpolation.
  Heavier but more flexible for irregular prototype spacing.
"""

import numpy as np
from abc import ABC, abstractmethod
from typing import Optional


class Interpolator(ABC):
    """
    Abstract base for geodesic interpolators.

    An interpolator is fitted to (arc_length, value) pairs at the K prototypes
    along the geodesic, then evaluated at arbitrary arc-length positions.
    """

    @abstractmethod
    def fit(self, t_values: np.ndarray, y_values: np.ndarray) -> "Interpolator":
        """
        Fit the interpolator to prototype positions and stored values.

        Parameters
        ----------
        t_values : np.ndarray, shape (K,)
            Arc-length positions of the K prototypes, normalized to [0, 1].
        y_values : np.ndarray, shape (K,) or (K, D)
            Stored values at each prototype. For classification: (K, C)
            probability distributions. For regression: (K,) or (K, D_out)
            mean target values.

        Returns
        -------
        self
        """
        ...

    @abstractmethod
    def evaluate(self, t: np.ndarray) -> np.ndarray:
        """
        Evaluate the interpolant at arc-length positions.

        Parameters
        ----------
        t : np.ndarray, shape (M,)
            Arc-length positions to evaluate at.

        Returns
        -------
        values : np.ndarray, shape (M,) or (M, D)
            Interpolated values.
        """
        ...

    @abstractmethod
    def get_state(self) -> dict:
        """Return serializable state."""
        ...

    @abstractmethod
    def set_state(self, state: dict) -> "Interpolator":
        """Restore from state dict."""
        ...


class LinearInterpolator(Interpolator):
    """
    Piecewise-linear interpolation between adjacent prototypes.

    This is the original BMC interpolation mechanism. For each query position t,
    finds the bracketing prototypes and linearly blends their values.

    Fast and simple. No fit-time computation beyond storing the data.
    """

    def __init__(self):
        self.t_values_: Optional[np.ndarray] = None
        self.y_values_: Optional[np.ndarray] = None

    def fit(self, t_values: np.ndarray, y_values: np.ndarray) -> "LinearInterpolator":
        self.t_values_ = np.asarray(t_values, dtype=np.float64)
        self.y_values_ = np.asarray(y_values, dtype=np.float64)
        return self

    def evaluate(self, t: np.ndarray) -> np.ndarray:
        t = np.asarray(t, dtype=np.float64)
        t = np.clip(t, self.t_values_[0], self.t_values_[-1])

        # Find bracketing indices
        indices = np.searchsorted(self.t_values_, t, side='right') - 1
        indices = np.clip(indices, 0, len(self.t_values_) - 2)

        t_lo = self.t_values_[indices]
        t_hi = self.t_values_[indices + 1]
        span = t_hi - t_lo
        # Avoid division by zero for coincident prototypes
        alpha = np.where(span > 1e-12, (t - t_lo) / span, 0.0)

        if self.y_values_.ndim == 1:
            y_lo = self.y_values_[indices]
            y_hi = self.y_values_[indices + 1]
            return (1 - alpha) * y_lo + alpha * y_hi
        else:
            y_lo = self.y_values_[indices]       # (M, D)
            y_hi = self.y_values_[indices + 1]   # (M, D)
            alpha = alpha[:, np.newaxis]          # (M, 1)
            return (1 - alpha) * y_lo + alpha * y_hi

    def get_state(self) -> dict:
        return {
            "interpolator_class": "LinearInterpolator",
            "t_values_": self.t_values_,
            "y_values_": self.y_values_,
        }

    def set_state(self, state: dict) -> "LinearInterpolator":
        self.t_values_ = state["t_values_"]
        self.y_values_ = state["y_values_"]
        return self

    def __repr__(self):
        return "LinearInterpolator()"


class SplineInterpolator(Interpolator):
    """
    Cubic spline interpolation through all prototypes. C2 continuous.

    Fits scipy.interpolate.CubicSpline at training time. One evaluation
    call per query at inference. This respects the smooth manifold structure
    and avoids the curvature penalty of piecewise-linear approximation.

    For multidimensional outputs (e.g. probability distributions), a separate
    spline is fitted per output dimension.
    """

    def __init__(self, bc_type: str = 'not-a-knot'):
        """
        Parameters
        ----------
        bc_type : str
            Boundary condition for the spline. Default 'not-a-knot'.
            Options: 'not-a-knot', 'clamped', 'natural', 'periodic'.
        """
        self.bc_type = bc_type
        self._spline = None
        self.t_values_: Optional[np.ndarray] = None
        self.y_values_: Optional[np.ndarray] = None

    def fit(self, t_values: np.ndarray, y_values: np.ndarray) -> "SplineInterpolator":
        from scipy.interpolate import CubicSpline

        self.t_values_ = np.asarray(t_values, dtype=np.float64)
        self.y_values_ = np.asarray(y_values, dtype=np.float64)

        # Check if t_values are strictly increasing (required by CubicSpline)
        diffs = np.diff(self.t_values_)
        is_strictly_increasing = np.all(diffs > 0)

        if len(self.t_values_) < 4 or not is_strictly_increasing:
            # Too few points or degenerate arc-lengths — fall back to linear
            self._spline = None
            return self

        self._spline = CubicSpline(
            self.t_values_, self.y_values_,
            bc_type=self.bc_type,
            extrapolate=False,
        )
        return self

    def evaluate(self, t: np.ndarray) -> np.ndarray:
        t = np.asarray(t, dtype=np.float64)
        t = np.clip(t, self.t_values_[0], self.t_values_[-1])

        if self._spline is None:
            # Fallback to linear for <4 prototypes
            lin = LinearInterpolator()
            lin.fit(self.t_values_, self.y_values_)
            return lin.evaluate(t)

        return self._spline(t)

    def get_state(self) -> dict:
        return {
            "interpolator_class": "SplineInterpolator",
            "bc_type": self.bc_type,
            "t_values_": self.t_values_,
            "y_values_": self.y_values_,
        }

    def set_state(self, state: dict) -> "SplineInterpolator":
        self.bc_type = state["bc_type"]
        self.t_values_ = state["t_values_"]
        self.y_values_ = state["y_values_"]
        # Refit the spline from stored data
        if len(self.t_values_) >= 4:
            from scipy.interpolate import CubicSpline
            self._spline = CubicSpline(
                self.t_values_, self.y_values_,
                bc_type=self.bc_type,
                extrapolate=False,
            )
        else:
            self._spline = None
        return self

    def __repr__(self):
        return f"SplineInterpolator(bc_type='{self.bc_type}')"


class KernelInterpolator(Interpolator):
    """
    Kernel-based interpolation using inverse distance weighting or RBF.

    Heavier than linear/spline but more flexible for irregular prototype spacing.

    Parameters
    ----------
    method : str
        'idw' — inverse distance weighting (no dependencies)
        'rbf' — radial basis function (requires scipy)
    power : float
        Exponent for IDW weighting. Default 2.0. Only used for method='idw'.
    """

    def __init__(self, method: str = 'idw', power: float = 2.0):
        if method not in ('idw', 'rbf'):
            raise ValueError(f"method must be 'idw' or 'rbf', got '{method}'")
        self.method = method
        self.power = power
        self.t_values_: Optional[np.ndarray] = None
        self.y_values_: Optional[np.ndarray] = None
        self._rbf = None

    def fit(self, t_values: np.ndarray, y_values: np.ndarray) -> "KernelInterpolator":
        self.t_values_ = np.asarray(t_values, dtype=np.float64)
        self.y_values_ = np.asarray(y_values, dtype=np.float64)

        if self.method == 'rbf':
            from scipy.interpolate import RBFInterpolator
            self._rbf = RBFInterpolator(
                self.t_values_[:, np.newaxis],
                self.y_values_,
                kernel='thin_plate_spline',
            )
        return self

    def evaluate(self, t: np.ndarray) -> np.ndarray:
        t = np.asarray(t, dtype=np.float64)
        t = np.clip(t, self.t_values_[0], self.t_values_[-1])

        if self.method == 'rbf':
            return self._rbf(t[:, np.newaxis])

        # IDW
        # distances from each query to each prototype
        dists = np.abs(t[:, np.newaxis] - self.t_values_[np.newaxis, :])  # (M, K)
        # handle exact matches
        exact = dists < 1e-12
        has_exact = exact.any(axis=1)

        weights = np.where(dists > 1e-12, 1.0 / (dists ** self.power), 0.0)
        weight_sums = weights.sum(axis=1, keepdims=True)
        weight_sums = np.where(weight_sums == 0, 1.0, weight_sums)
        weights = weights / weight_sums

        if self.y_values_.ndim == 1:
            result = weights @ self.y_values_
            # For exact matches, use the prototype value directly
            for i in np.where(has_exact)[0]:
                result[i] = self.y_values_[exact[i]][0]
            return result
        else:
            result = weights @ self.y_values_   # (M, D)
            for i in np.where(has_exact)[0]:
                result[i] = self.y_values_[exact[i]][0]
            return result

    def get_state(self) -> dict:
        return {
            "interpolator_class": "KernelInterpolator",
            "method": self.method,
            "power": self.power,
            "t_values_": self.t_values_,
            "y_values_": self.y_values_,
        }

    def set_state(self, state: dict) -> "KernelInterpolator":
        self.method = state["method"]
        self.power = state["power"]
        self.t_values_ = state["t_values_"]
        self.y_values_ = state["y_values_"]
        if self.method == 'rbf':
            from scipy.interpolate import RBFInterpolator
            self._rbf = RBFInterpolator(
                self.t_values_[:, np.newaxis],
                self.y_values_,
                kernel='thin_plate_spline',
            )
        return self

    def __repr__(self):
        return f"KernelInterpolator(method='{self.method}', power={self.power})"


# ── RDDA — Feature-Space Interpolator ────────────────────────────────────────
#
# RDDA operates in the original feature space, NOT in arc-length space.
# It does not conform to the Interpolator base class because:
#   - fit() takes seeds (K, D) + values, not arc-length positions
#   - evaluate() takes raw query vectors (M, D), not arc-length scalars
#
# BMCCell and _RegressionCell detect RDDAInterpolator by isinstance check
# and route raw vectors to it instead of computing arc-length projections.


def _estimate_gradients_feature_space(
    seeds: np.ndarray,
    values: np.ndarray,
    metric,
) -> np.ndarray:
    """
    Estimate gradient of f at each seed in feature space.

    For each seed p_i, finds its two nearest neighbors in feature space
    and estimates grad_f(p_i) via weighted finite differences:
        grad_i = sum_j w_j * (f(p_j) - f(p_i)) / ||p_j - p_i|| * (p_j - p_i) / ||p_j - p_i||

    Parameters
    ----------
    seeds : (K, D) seed positions in feature space
    values : (K,) or (K, C) stored values
    metric : SimilarityMetric

    Returns
    -------
    grads : (K, D) gradient vectors if values is 1D
            (K, C, D) gradient vectors if values is 2D
    """
    K, D = seeds.shape
    dists = metric.pairwise(seeds.astype(np.float32), seeds.astype(np.float32))  # (K, K)

    is_1d = values.ndim == 1

    if is_1d:
        grads = np.zeros((K, D), dtype=np.float64)
    else:
        C = values.shape[1]
        grads = np.zeros((K, C, D), dtype=np.float64)

    for i in range(K):
        # find nearest neighbors (exclude self)
        d_i = dists[i].copy()
        d_i[i] = np.inf
        n_nbr = min(6, K - 1)  # use up to 6 nearest neighbors
        if n_nbr == 0:
            continue
        nbr_idx = np.argpartition(d_i, n_nbr)[:n_nbr]

        for j in nbr_idx:
            dist_ij = float(d_i[j])
            if dist_ij < 1e-12:
                continue
            direction = (seeds[j].astype(np.float64) - seeds[i].astype(np.float64)) / dist_ij
            weight = 1.0 / (dist_ij + 1e-12)

            if is_1d:
                df = float(values[j] - values[i])
                grads[i] += weight * (df / dist_ij) * direction
            else:
                df = values[j] - values[i]  # (C,)
                for c in range(C):
                    grads[i, c] += weight * (df[c] / dist_ij) * direction

        # normalize by total weight
        total_w = sum(1.0 / (float(d_i[j]) + 1e-12) for j in nbr_idx if d_i[j] > 1e-12)
        if total_w > 1e-12:
            grads[i] /= total_w

    return grads


class RDDAInterpolator:
    """
    Rectified Discriminatory Delta-Adjust interpolation in feature space.

    Unlike the arc-length interpolators (Linear, Spline, Kernel), RDDA
    operates directly in the original feature space. It computes:
        f_hat(x) = sum_i w_i * [f(p_i) + nabla_f(p_i) . (x - p_i)]
    where the gradient is estimated in feature space and the sensitivity
    weights modulate neighbor influence based on local gradient magnitude.

    This class does NOT inherit from Interpolator because it has a
    different interface:
    - fit(seeds, values, metric) — takes seeds in feature space
    - evaluate(queries, seeds, metric) — takes raw query vectors

    BMCCell and _RegressionCell detect this class and route accordingly.

    Parameters
    ----------
    sensitivity : str
        - 'fixed' : constant sensitivity
        - 'sa'    : Sensitivity Analysis — from local value variance
        - 'vc'    : Vector Calculus — from gradient magnitude (best overall)
        - 'hod'   : Higher-Order Derivative — from curvature
    k_neighbors : int or None
        Nearest seeds per query in feature space. None = all K.
    rectify : bool
        Clamp adjustments so they don't go below prototype value.
    """

    # Flag for isinstance detection
    is_feature_space_interpolator = True

    def __init__(
        self,
        sensitivity: str = 'vc',
        k_neighbors: int = 5,
        rectify: bool = True,
    ):
        if sensitivity not in ('fixed', 'sa', 'vc', 'hod'):
            raise ValueError(
                f"sensitivity must be 'fixed', 'sa', 'vc', or 'hod', got '{sensitivity}'"
            )
        self.sensitivity = sensitivity
        self.k_neighbors = k_neighbors
        self.rectify = rectify

        self.seeds_: Optional[np.ndarray] = None
        self.values_: Optional[np.ndarray] = None
        self.grads_: Optional[np.ndarray] = None
        self.sens_: Optional[np.ndarray] = None

    def fit(self, seeds: np.ndarray, values: np.ndarray, metric) -> "RDDAInterpolator":
        """
        Fit RDDA on seed positions and stored values.

        Parameters
        ----------
        seeds : (K, D) seed positions in feature space
        values : (K,) or (K, C) stored values at each seed
        metric : SimilarityMetric for distance computation
        """
        self.seeds_ = np.asarray(seeds, dtype=np.float64)
        self.values_ = np.asarray(values, dtype=np.float64)
        K = len(seeds)

        # Estimate gradients in feature space
        self.grads_ = _estimate_gradients_feature_space(seeds, values, metric)

        # Compute sensitivity per seed
        eps = 1e-8
        if self.sensitivity == 'sa':
            # local variance of values among nearest neighbors
            dists = metric.pairwise(seeds.astype(np.float32), seeds.astype(np.float32))
            v_flat = values.reshape(K, -1) if values.ndim > 1 else values[:, np.newaxis]
            self.sens_ = np.ones(K, dtype=np.float64)
            for i in range(K):
                d_i = dists[i].copy(); d_i[i] = np.inf
                n = min(6, K - 1)
                if n == 0: continue
                nbr = np.argpartition(d_i, n)[:n]
                window = np.vstack([v_flat[i:i+1], v_flat[nbr]])
                self.sens_[i] = 1.0 / (window.var(axis=0).mean() + eps)

        elif self.sensitivity == 'vc':
            # gradient magnitude
            if self.grads_.ndim == 2:  # (K, D) — scalar output
                grad_mag = np.sqrt((self.grads_ ** 2).sum(axis=1))
            else:  # (K, C, D) — vector output
                grad_mag = np.sqrt((self.grads_ ** 2).sum(axis=(1, 2)))
            self.sens_ = 1.0 / (grad_mag + eps)

        elif self.sensitivity == 'hod':
            # approximate curvature from gradient variation among neighbors
            dists = metric.pairwise(seeds.astype(np.float32), seeds.astype(np.float32))
            self.sens_ = np.ones(K, dtype=np.float64)
            g_flat = self.grads_.reshape(K, -1)
            for i in range(K):
                d_i = dists[i].copy(); d_i[i] = np.inf
                n = min(6, K - 1)
                if n == 0: continue
                nbr = np.argpartition(d_i, n)[:n]
                window = np.vstack([g_flat[i:i+1], g_flat[nbr]])
                curv = window.var(axis=0).mean()
                self.sens_[i] = 1.0 / (curv + eps)

        else:  # 'fixed'
            self.sens_ = np.ones(K, dtype=np.float64)

        return self

    def evaluate(self, queries: np.ndarray, seeds: np.ndarray, metric) -> np.ndarray:
        """
        Evaluate RDDA predictions for query vectors.

        Parameters
        ----------
        queries : (M, D) raw query vectors in feature space
        seeds : (K, D) seed vectors (same as fit)
        metric : SimilarityMetric

        Returns
        -------
        predictions : (M,) or (M, C)
        """
        queries = np.asarray(queries, dtype=np.float64)
        K = len(self.seeds_)
        M = len(queries)
        is_1d = self.values_.ndim == 1
        out_shape = (M,) if is_1d else (M, self.values_.shape[1])
        result = np.zeros(out_shape, dtype=np.float64)

        # Distances in feature space
        dists = metric.pairwise(
            queries.astype(np.float32), seeds.astype(np.float32)
        )  # (M, K)

        k_nbr = K if (self.k_neighbors is None or self.k_neighbors >= K) else self.k_neighbors

        for m in range(M):
            d_m = dists[m]  # (K,)

            # select k neighbors
            if k_nbr < K:
                neighbor_idx = np.argpartition(d_m, k_nbr)[:k_nbr]
            else:
                neighbor_idx = np.arange(K)

            # displacement vectors in feature space
            displacements = queries[m] - self.seeds_[neighbor_idx]  # (k, D)

            # delta adjustments: f(p_i) + grad_f(p_i) . (x - p_i)
            if is_1d:
                # grads: (K, D), displacements: (k, D)
                deltas = np.array([
                    self.grads_[j] @ displacements[idx]
                    for idx, j in enumerate(neighbor_idx)
                ])
                adjustments = self.values_[neighbor_idx] + deltas
                if self.rectify:
                    adjustments = np.maximum(adjustments, self.values_[neighbor_idx])
            else:
                C = self.values_.shape[1]
                adjustments = np.zeros((len(neighbor_idx), C), dtype=np.float64)
                for idx, j in enumerate(neighbor_idx):
                    # grads[j] is (C, D), displacement is (D,)
                    delta = self.grads_[j] @ displacements[idx]  # (C,)
                    adjustments[idx] = self.values_[j] + delta
                if self.rectify:
                    adjustments = np.maximum(adjustments, self.values_[neighbor_idx])

            # sensitivity-weighted distances
            sens_i = self.sens_[neighbor_idx]
            weighted_dists = d_m[neighbor_idx] / (sens_i + 1e-12)
            weights = 1.0 / (weighted_dists ** 2 + 1e-12)
            weights /= weights.sum()

            if is_1d:
                result[m] = (weights * adjustments).sum()
            else:
                result[m] = (weights[:, np.newaxis] * adjustments).sum(axis=0)

        return result

    def get_state(self) -> dict:
        return {
            "interpolator_class": "RDDAInterpolator",
            "sensitivity": self.sensitivity,
            "k_neighbors": self.k_neighbors,
            "rectify": self.rectify,
            "seeds_": self.seeds_,
            "values_": self.values_,
            "sens_": self.sens_,
            "grads_": self.grads_,
        }

    def set_state(self, state: dict) -> "RDDAInterpolator":
        self.sensitivity = state["sensitivity"]
        self.k_neighbors = state["k_neighbors"]
        self.rectify = state["rectify"]
        self.seeds_ = state["seeds_"]
        self.values_ = state["values_"]
        self.sens_ = state["sens_"]
        self.grads_ = state.get("grads_")
        return self

    def __repr__(self):
        return (
            f"RDDAInterpolator("
            f"sensitivity='{self.sensitivity}', "
            f"k_neighbors={self.k_neighbors}, "
            f"rectify={self.rectify})"
        )


# ── Factory for restoring from state ─────────────────────────────────────────

_INTERPOLATOR_REGISTRY = {
    "LinearInterpolator": LinearInterpolator,
    "SplineInterpolator": SplineInterpolator,
    "KernelInterpolator": KernelInterpolator,
    "RDDAInterpolator": RDDAInterpolator,
}


def restore_interpolator(state: dict) -> Interpolator:
    """Restore an interpolator from a state dict."""
    cls_name = state["interpolator_class"]
    if cls_name not in _INTERPOLATOR_REGISTRY:
        raise ValueError(f"Unknown interpolator class: {cls_name}")
    cls = _INTERPOLATOR_REGISTRY[cls_name]
    instance = cls.__new__(cls)
    instance.set_state(state)
    return instance
