# bmc/core/seeding.py
"""
Manifold seeding — finding K representative points from a data distribution.

This module is fully data-agnostic. It operates on (M, D) float32 arrays
and returns (K, D) seed arrays. The similarity metric is passed in as a
callable, decoupling seeding from any particular geometry.

The core algorithm is kmeans++ initialization: seeds are selected
sequentially, each new seed chosen with probability proportional to its
squared distance from the nearest already-chosen seed. This produces
well-spread seeds that approximate the support of the data distribution,
which is the finite-sample approximation of manifold seeding described
in the TAI framework.
"""

import numpy as np
from typing import Callable


def kmeanspp_init(
    vectors: np.ndarray,
    k: int,
    rng: np.random.Generator,
    metric: "bmc.metrics.base.SimilarityMetric" = None,
    max_iter: int = 50,
    tol: float = 1e-4,
) -> np.ndarray:
    """
    Initialize K seeds via kmeans++ then refine with Lloyd's algorithm.

    Phase 1 (kmeans++ init): seeds are selected sequentially, each new
    seed chosen with probability proportional to its squared distance
    from the nearest already-chosen seed.

    Phase 2 (Lloyd's iteration): seeds are iteratively refined by
    assigning all vectors to the nearest seed, then recomputing each
    seed as the mean of its assigned vectors. Iteration stops when
    seeds move less than `tol` or `max_iter` is reached.

    Parameters
    ----------
    vectors : np.ndarray, shape (M, D)
        Data points to seed from. float32.
    k : int
        Number of seeds to select.
    rng : np.random.Generator
        Seeded random generator for reproducibility.
    metric : SimilarityMetric, optional
        Distance metric for computing inter-point distances.
        Defaults to L2 if None.
    max_iter : int
        Maximum number of Lloyd's iterations. Default: 50.
    tol : float
        Convergence tolerance on seed movement. Default: 1e-4.

    Returns
    -------
    seeds : np.ndarray, shape (K, D)
        Converged seed vectors.

    Notes
    -----
    Phase 1 complexity: O(K * M) distance computations.
    Phase 2 complexity: O(max_iter * K * M).
    """
    if metric is None:
        from bmc.metrics.l2 import L2Metric
        metric = L2Metric()

    M, D = vectors.shape
    if k > M:
        raise ValueError(
            f"Cannot select {k} seeds from {M} vectors. k must be <= M."
        )
    if k <= 0:
        raise ValueError(f"k must be positive, got {k}.")

    # ── Phase 1: kmeans++ initialization ─────────────────────────────────

    # choose first seed uniformly at random
    idx = rng.integers(0, M)
    seeds = [vectors[idx]]

    # initial min-distances: distance from each point to seed 0
    min_dists = _distances_to_seed(vectors, seeds[0], metric)

    for _ in range(k - 1):
        # sample next seed proportional to squared distance
        sq = min_dists ** 2
        total = sq.sum()
        if total == 0:
            # all points are identical — choose uniformly
            idx = rng.integers(0, M)
        else:
            probs = sq / total
            idx = rng.choice(M, p=probs)

        new_seed = vectors[idx]
        seeds.append(new_seed)

        # update min-distances
        new_dists = _distances_to_seed(vectors, new_seed, metric)
        min_dists = np.minimum(min_dists, new_dists)

    seeds = np.stack(seeds).astype(np.float64)

    # ── Phase 2: Lloyd's iteration ───────────────────────────────────────

    vectors_f64 = vectors.astype(np.float64)

    for _ in range(max_iter):
        # assign each vector to nearest seed
        assignments = assign_clusters(vectors, seeds.astype(vectors.dtype), metric)

        # recompute seeds as cluster means — vectorized via bincount
        new_seeds = np.empty_like(seeds)
        counts = np.bincount(assignments, minlength=k)
        for d in range(D):
            sums = np.bincount(assignments, weights=vectors_f64[:, d], minlength=k)
            new_seeds[:, d] = sums
        # normalize non-empty, keep old seed for empty clusters
        nonempty = counts > 0
        new_seeds[nonempty] /= counts[nonempty, np.newaxis]
        new_seeds[~nonempty] = seeds[~nonempty]

        # check convergence
        shift = np.sqrt(((new_seeds - seeds) ** 2).sum(axis=1)).max()
        seeds = new_seeds
        if shift < tol:
            break

    return seeds.astype(vectors.dtype)


def assign_clusters(
    vectors: np.ndarray,
    seeds: np.ndarray,
    metric: "bmc.metrics.base.SimilarityMetric",
) -> np.ndarray:
    """
    Assign each vector to its nearest seed (Voronoi assignment).

    Streams through seeds one at a time, tracking only the running
    minimum distance per sample. Workspace is O(M) regardless of K,
    avoiding the O(M*K) allocation of a full pairwise distance matrix.

    Parameters
    ----------
    vectors : np.ndarray, shape (M, D)
    seeds : np.ndarray, shape (K, D)
    metric : SimilarityMetric

    Returns
    -------
    assignments : np.ndarray, shape (M,), dtype int32
        assignments[i] = index of nearest seed to vectors[i].
    """
    K = len(seeds)
    M = len(vectors)

    best_dist = _distances_to_seed(vectors, seeds[0], metric)
    best_idx = np.zeros(M, dtype=np.int32)

    for k in range(1, K):
        d = _distances_to_seed(vectors, seeds[k], metric)
        mask = d < best_dist
        best_dist[mask] = d[mask]
        best_idx[mask] = k

    return best_idx


# ── internal helpers ──────────────────────────────────────────────────────────

def _distances_to_seed(
    vectors: np.ndarray,
    seed: np.ndarray,
    metric: "bmc.metrics.base.SimilarityMetric",
) -> np.ndarray:
    """
    Compute distance from each vector to a single seed.

    Parameters
    ----------
    vectors : (M, D)
    seed    : (D,)
    metric  : SimilarityMetric

    Returns
    -------
    dists : (M,) float32
    """
    # pairwise expects (M, D) x (K, D) -> (M, K)
    seed_2d = seed[np.newaxis, :]             # (1, D)
    dists = metric.pairwise(vectors, seed_2d) # (M, 1)
    return dists[:, 0]                        # (M,)
