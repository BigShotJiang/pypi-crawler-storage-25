# bmc/core/geodesic.py
"""
Geodesic ordering of seeds via TSP approximation.

Given K seeds in a representation space, the TSP tour through those
seeds approximates the geodesic — the shortest path that visits all
seeds and returns to the start. In the limit of dense data, this
path converges to the geodesic on the data manifold.

The binary address of each seed is its position in the TSP tour.
Adjacent binary addresses correspond to adjacent positions on the
geodesic, giving the lookup table a geometrically meaningful structure:
a 1-bit address error routes to a nearby point on the manifold, not
to an arbitrary one.

Algorithm:
1. Nearest-neighbor heuristic — greedy O(K^2) construction
2. 2-opt improvement — iterative O(K^2) local search

For K <= 1024 this runs in under 1 second.
"""

import numpy as np
from typing import List


def tsp_nearest_neighbor(
    dists_matrix: np.ndarray,
    start: int = 0,
) -> List[int]:
    """
    Construct a TSP tour using the nearest-neighbor greedy heuristic.

    Starts at `start`, always moves to the nearest unvisited node.
    Returns a Hamiltonian path (open tour) visiting all K nodes once.

    Parameters
    ----------
    dists_matrix : np.ndarray, shape (K, K)
        Pairwise distance matrix. dists_matrix[i, j] = distance from i to j.
    start : int
        Index of the starting node. Default 0.

    Returns
    -------
    path : list of int, length K
        Ordered node indices forming the tour.

    Notes
    -----
    Time complexity: O(K^2).
    This is an open tour — does not return to the start node.
    """
    K = len(dists_matrix)
    if K == 0:
        return []
    if K == 1:
        return [start]

    dists = np.array(dists_matrix, dtype=np.float64)
    visited = np.zeros(K, dtype=bool)
    path = [start]
    visited[start] = True

    for _ in range(K - 1):
        current = path[-1]
        row = dists[current].copy()
        row[visited] = np.inf
        best_next = int(np.argmin(row))
        path.append(best_next)
        visited[best_next] = True

    return path


def two_opt(
    path: List[int],
    dists_matrix: np.ndarray,
) -> List[int]:
    """
    Improve a TSP path using 2-opt local search.

    Iteratively reverses sub-paths between indices i and j if doing so
    reduces the total tour length. Terminates when no improving swap exists.

    Parameters
    ----------
    path : list of int, length K
        Initial tour (from tsp_nearest_neighbor or any other method).
    dists_matrix : np.ndarray, shape (K, K)
        Pairwise distance matrix.

    Returns
    -------
    path : list of int, length K
        Improved tour. Tour length is guaranteed to be <= input tour length.

    Notes
    -----
    Time complexity: O(K^2) per improvement pass, multiple passes.
    In practice converges quickly — usually 2-5 passes for K <= 256.
    """
    path_arr = np.array(path, dtype=np.int64)
    K = len(path_arr)
    if K < 4:
        return list(path_arr)

    dists = np.asarray(dists_matrix, dtype=np.float64)

    improved = True
    while improved:
        improved = False
        for i in range(1, K - 1):
            # Vectorized: evaluate all j > i at once
            p_im1 = path_arr[i - 1]
            p_i = path_arr[i]

            # old costs for edges (i-1 -> i) and (j-1 -> j) for all j in [i+1, K)
            cost_im1_i = dists[p_im1, p_i]
            j_indices = np.arange(i + 1, K)
            p_jm1 = path_arr[j_indices - 1]
            p_j = path_arr[j_indices]

            old_costs = cost_im1_i + dists[p_jm1, p_j]

            # new costs: (i-1 -> j-1) and (i -> j)
            new_costs = dists[p_im1, p_jm1] + dists[p_i, p_j]

            gains = old_costs - new_costs
            best_idx = np.argmax(gains)
            if gains[best_idx] > 1e-10:
                j = int(j_indices[best_idx])
                path_arr[i:j] = path_arr[i:j][::-1]
                improved = True

    return list(path_arr)


def build_tsp_path(
    dists_matrix: np.ndarray,
    start: int = 0,
) -> np.ndarray:
    """
    Build an optimized TSP path from a pairwise distance matrix.

    Runs nearest-neighbor initialization followed by 2-opt improvement.

    Parameters
    ----------
    dists_matrix : np.ndarray, shape (K, K)
        Pairwise distance matrix between K seeds.
    start : int
        Starting node index. Default 0.

    Returns
    -------
    path : np.ndarray, shape (K,), dtype int
        TSP-ordered seed indices. path[i] is the i-th seed on the geodesic.
        The binary address of a seed is its position in this array.
    """
    path = tsp_nearest_neighbor(dists_matrix, start=start)
    path = two_opt(path, dists_matrix)
    return np.array(path, dtype=np.int64)


def tour_length(path: np.ndarray, dists_matrix: np.ndarray) -> float:
    """
    Compute the total length of a tour.

    Parameters
    ----------
    path : array-like, length K
    dists_matrix : (K, K)

    Returns
    -------
    length : float
    """
    path = list(path)
    K = len(path)
    if K <= 1:
        return 0.0
    total = sum(
        dists_matrix[path[i], path[i + 1]]
        for i in range(K - 1)
    )
    return float(total)
