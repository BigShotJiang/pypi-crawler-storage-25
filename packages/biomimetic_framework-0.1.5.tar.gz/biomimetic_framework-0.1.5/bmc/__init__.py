# bmc/__init__.py
"""
bmc — Biomimetic Lookup Cell framework.

The easy path:
    from bmc import BMCClassifier, BMCRegressor
    clf = BMCClassifier()
    clf.fit(X_train, y_train)
    preds = clf.predict(X_test)

The full control path:
    from bmc.observation.image import ImageObservationSpace
    from bmc.composition.sequential import BMCNetwork, SequentialBMC
    from bmc.composition.layer import BMCLayer
    from bmc.metrics.frobenius import FrobeniusMetric
    from bmc.core.cell import BMCCell
    from bmc.model.persistence import save, load
"""

# high-level API — easy path
from bmc.model.classifier import BMCClassifier
from bmc.model.regressor import BMCRegressor
from bmc.model.persistence import save, load

# composition
from bmc.composition.layer import BMCLayer
from bmc.composition.sequential import BMCNetwork, SequentialBMC

# primitive
from bmc.core.cell import BMCCell

# interpolators
from bmc.core.interpolators import (
    LinearInterpolator,
    SplineInterpolator,
    KernelInterpolator,
    RDDAInterpolator,
)

# observation spaces
from bmc.observation.image import ImageObservationSpace
from bmc.observation.tabular import TabularObservationSpace
from bmc.observation.timeseries import TimeSeriesObservationSpace
from bmc.observation.text import TextObservationSpace

# metrics
from bmc.metrics.l2 import L2Metric
from bmc.metrics.frobenius import FrobeniusMetric
from bmc.metrics.cosine import CosineMetric
from bmc.metrics.spectral import SpectralMetric
from bmc.metrics.nuclear import NuclearMetric

# fpga export
from bmc.fpga.export import export_for_fpga

__version__ = "0.1.5"

__all__ = [
    # easy path
    "BMCClassifier",
    "BMCRegressor",
    "save",
    "load",
    # composition
    "BMCLayer",
    "BMCNetwork",
    "SequentialBMC",
    # primitive
    "BMCCell",
    # interpolators
    "LinearInterpolator",
    "SplineInterpolator",
    "KernelInterpolator",
    "RDDAInterpolator",
    # observation spaces
    "ImageObservationSpace",
    "TabularObservationSpace",
    "TimeSeriesObservationSpace",
    "TextObservationSpace",
    # metrics
    "L2Metric",
    "FrobeniusMetric",
    "CosineMetric",
    "SpectralMetric",
    "NuclearMetric",
    # fpga
    "export_for_fpga",
]