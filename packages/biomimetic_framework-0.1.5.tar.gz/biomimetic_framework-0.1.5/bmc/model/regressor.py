# bmc/model/regressor.py
"""
BMCRegressor — high-level fit/predict interface for regression.

The regressor stores the mean target value at each Voronoi cell,
then uses geodesic interpolation to predict continuous values.
No bin discretization — the LUT stores actual target means, and
the interpolator (linear, spline, or kernel) evaluates on the
continuous output manifold.

Architecture:
- Each zone's BMCCell has a LUT of shape (K, 1) storing mean target values
- At inference: find nearest seed, interpolate along the geodesic
- The interpolator operates in continuous target space, not discrete bins
"""

import numpy as np
from typing import Optional, Union

from bmc.model.base import BMCModel
from bmc.observation.base import ObservationSpace
from bmc.observation.tabular import TabularObservationSpace
from bmc.core.cell import BMCCell
from bmc.core.seeding import kmeanspp_init, assign_clusters
from bmc.core.geodesic import build_tsp_path
from bmc.core.cell import _compute_arc_lengths
from bmc.core.interpolators import (
    Interpolator, SplineInterpolator, LinearInterpolator, RDDAInterpolator,
)
from bmc.core.interpolators import RDDAInterpolator as _RDDACheck
from bmc.metrics.base import SimilarityMetric
from bmc.metrics.l2 import L2Metric


class _RegressionCell:
    """
    Internal regression cell — stores mean target values instead of
    class distributions.

    Not exposed publicly. Used by BMCRegressor to build the per-zone
    regression pipeline.
    """

    def __init__(
        self,
        n_clusters: int,
        metric: Optional[SimilarityMetric] = None,
        interpolator: Optional[Interpolator] = None,
        rng: Optional[np.random.Generator] = None,
    ):
        self.n_clusters = n_clusters
        self.metric = metric if metric is not None else L2Metric()
        self.interpolator = interpolator
        self.rng = rng if rng is not None else np.random.default_rng(42)

        self.seeds_: Optional[np.ndarray] = None
        self.means_: Optional[np.ndarray] = None
        self.tsp_path_: Optional[np.ndarray] = None
        self.arc_lengths_: Optional[np.ndarray] = None
        self.global_mean_: Optional[float] = None
        self.is_fitted_: bool = False

    def fit(
        self,
        vectors: np.ndarray,
        targets: np.ndarray,
    ) -> "_RegressionCell":
        vectors = np.asarray(vectors, dtype=np.float32)
        targets = np.asarray(targets, dtype=np.float64)

        self.global_mean_ = float(targets.mean())

        # 1. seed initialization + Lloyd's refinement
        seeds = kmeanspp_init(vectors, self.n_clusters, self.rng, self.metric)

        # 2. assignment
        assignments = assign_clusters(vectors, seeds, self.metric)

        # 3. compute mean target per cell
        means = np.full(self.n_clusters, self.global_mean_, dtype=np.float64)
        for k in range(self.n_clusters):
            mask = assignments == k
            if mask.sum() > 0:
                means[k] = targets[mask].mean()

        # 4. TSP geodesic ordering
        dist_matrix = self.metric.pairwise(seeds, seeds)
        tsp_path = build_tsp_path(dist_matrix)

        # 5. reorder by TSP
        self.seeds_ = seeds[tsp_path].astype(np.float32)
        self.means_ = means[tsp_path]
        self.tsp_path_ = tsp_path

        # 6. arc-length positions and fit interpolator
        self.arc_lengths_ = _compute_arc_lengths(self.seeds_, self.metric)

        if self.interpolator is not None:
            if isinstance(self.interpolator, RDDAInterpolator):
                self.interpolator.fit(self.seeds_, self.means_, self.metric)
            else:
                self.interpolator.fit(self.arc_lengths_, self.means_)

        self.is_fitted_ = True
        return self

    def predict(self, vectors: np.ndarray) -> np.ndarray:
        """Return continuous predictions for input vectors."""
        vectors = np.asarray(vectors, dtype=np.float32)

        if self.interpolator is None:
            # Hard lookup — return cell mean
            dists = self.metric.pairwise(vectors, self.seeds_)
            nearest = np.argmin(dists, axis=1)
            return self.means_[nearest]

        # RDDA operates in feature space directly
        if isinstance(self.interpolator, RDDAInterpolator):
            return self.interpolator.evaluate(vectors, self.seeds_, self.metric)

        return self._predict_interpolated(vectors)

    def _predict_interpolated(self, vectors: np.ndarray) -> np.ndarray:
        from bmc.core.interpolation import project_onto_segment

        dists = self.metric.pairwise(vectors, self.seeds_)
        nearest_idx = np.argmin(dists, axis=1)

        K = len(self.seeds_)
        M = len(vectors)

        query_arc = np.zeros(M, dtype=np.float64)
        for m in range(M):
            i = int(nearest_idx[m])
            j_prev = (i - 1) % K
            j_next = (i + 1) % K

            d_prev = float(dists[m, j_prev])
            d_next = float(dists[m, j_next])
            j = j_prev if d_prev <= d_next else j_next

            p_i = self.seeds_[i].flatten().astype(np.float64)
            p_j = self.seeds_[j].flatten().astype(np.float64)
            q = vectors[m].flatten().astype(np.float64)
            t_local = project_onto_segment(q, p_i, p_j)

            arc_i = self.arc_lengths_[i]
            arc_j = self.arc_lengths_[j]
            query_arc[m] = arc_i + t_local * (arc_j - arc_i)

        return self.interpolator.evaluate(query_arc)


class BMCRegressor(BMCModel):
    """
    High-level BMC regressor with sklearn-compatible interface.

    Stores mean target values at each Voronoi cell and uses geodesic
    interpolation to predict continuous values. No bin discretization.

    For multi-zone inputs, each zone independently predicts via its own
    regression cell, and predictions are averaged across zones.

    Parameters
    ----------
    observation_space : ObservationSpace, optional
        How to decompose inputs into zones. If None and input is 2D tabular,
        auto-created with n_zones = min(n_features, 10).
    n_clusters : int
        Voronoi cells per zone. Default: 128.
    n_clusters_l2 : int, str, or None
        Number of clusters for the prediction head — a second-layer
        _RegressionCell that operates on the zone prediction matrix.
        Defaults to "auto" (same as n_clusters). Set to None to disable
        the prediction head and use raw zone averaging instead.
    metric : SimilarityMetric, optional
    interpolate : bool
        If True, uses SplineInterpolator. Default: True for regression.
    interpolator : Interpolator, optional
        Explicit interpolation strategy. Overrides interpolate flag.
    rng : np.random.Generator, optional
    """

    def __init__(
        self,
        observation_space: Optional[ObservationSpace] = None,
        n_clusters: int = 128,
        n_clusters_l2: Union[int, str, None] = "auto",
        metric: Optional[SimilarityMetric] = None,
        interpolate: bool = True,
        interpolator: Optional[Interpolator] = None,
        rng: Optional[np.random.Generator] = None,
    ):
        self.observation_space = observation_space
        self.n_clusters = n_clusters
        self.n_clusters_l2 = n_clusters_l2
        self.metric = metric if metric is not None else L2Metric()
        self.interpolate = interpolate
        self.rng = rng if rng is not None else np.random.default_rng(42)

        # Resolve interpolators:
        # - Zone cells (Layer 1) always interpolate for smooth representations
        # - Prediction head (Layer 2) uses the user's interpolate setting
        self._zone_interpolator_template = LinearInterpolator()  # always on for zones

        if interpolator is not None:
            self._head_interpolator_template = interpolator
        elif interpolate:
            self._head_interpolator_template = LinearInterpolator()
        else:
            self._head_interpolator_template = None

        self._obs: Optional[ObservationSpace] = None
        self._cells: Optional[list] = None
        self._cell_l2: Optional[_RegressionCell] = None
        self.is_fitted_: bool = False

    def fit(self, X: np.ndarray, y: np.ndarray) -> "BMCRegressor":
        """
        Fit the regressor.

        For each zone, builds a _RegressionCell that stores mean target
        values at each Voronoi cell and fits an interpolator along the
        geodesic.

        Parameters
        ----------
        X : np.ndarray, shape (M, ...)
        y : np.ndarray, shape (M,), continuous

        Returns
        -------
        self
        """
        X = np.asarray(X)
        y = np.asarray(y, dtype=np.float64)

        self._y_min = float(y.min())
        self._y_max = float(y.max())

        # Resolve observation space
        if self.observation_space is None:
            if X.ndim == 2:
                n_features = X.shape[1]
                n_zones = min(n_features, 10)
                self._obs = TabularObservationSpace(n_features, n_zones=n_zones)
            else:
                raise ValueError(
                    "observation_space must be specified for non-tabular inputs."
                )
        else:
            self._obs = self.observation_space

        # Resolve n_clusters_l2
        n_clusters_l2 = self.n_clusters_l2
        if n_clusters_l2 == "auto":
            n_clusters_l2 = self.n_clusters

        # Extract zone vectors
        zone_vectors = self._obs.extract(X)  # (N_zones, M, D)
        N_zones = zone_vectors.shape[0]

        # Build one regression cell per zone — always interpolated
        # for smooth representations feeding the prediction head
        import copy
        self._cells = []
        for z in range(N_zones):
            interp = copy.deepcopy(self._zone_interpolator_template)
            cell = _RegressionCell(
                n_clusters=self.n_clusters,
                metric=self.metric,
                interpolator=interp,
                rng=np.random.default_rng(int(self.rng.integers(0, 2**31))),
            )
            cell.fit(zone_vectors[z], y)
            self._cells.append(cell)

        # Optional prediction head on zone prediction matrix
        if n_clusters_l2 is not None:
            zone_preds_train = np.column_stack([
                cell.predict(zone_vectors[z])
                for z, cell in enumerate(self._cells)
            ])  # (M, N_zones)

            if self._head_interpolator_template is not None:
                interp_l2 = copy.deepcopy(self._head_interpolator_template)
            else:
                interp_l2 = None

            self._cell_l2 = _RegressionCell(
                n_clusters=n_clusters_l2,
                metric=self.metric,
                interpolator=interp_l2,
                rng=np.random.default_rng(int(self.rng.integers(0, 2**31))),
            )
            self._cell_l2.fit(zone_preds_train, y)

        self.is_fitted_ = True
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict continuous values.

        Averages predictions across all zones.

        Parameters
        ----------
        X : np.ndarray

        Returns
        -------
        predictions : np.ndarray, shape (M,), float64
        """
        self._check_fitted()
        X = np.asarray(X)
        zone_vectors = self._obs.extract(X)  # (N_zones, M, D)

        if self._cell_l2 is not None:
            # Layer 2: get zone prediction matrix, pass through L2 cell
            zone_preds = np.column_stack([
                cell.predict(zone_vectors[z])
                for z, cell in enumerate(self._cells)
            ])  # (M, N_zones)
            preds = self._cell_l2.predict(zone_preds)
        else:
            # Fallback: average predictions across zones
            preds = np.zeros(len(X), dtype=np.float64)
            for z, cell in enumerate(self._cells):
                preds += cell.predict(zone_vectors[z])
            preds /= len(self._cells)

        # Clamp to training target range — spline extrapolation can overshoot
        preds = np.clip(preds, self._y_min, self._y_max)

        return preds

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Not applicable for the continuous regressor.

        Returns per-zone predictions as columns for inspection.

        Parameters
        ----------
        X : np.ndarray

        Returns
        -------
        zone_predictions : np.ndarray, shape (M, N_zones)
            Each column is one zone's continuous prediction.
        """
        self._check_fitted()
        X = np.asarray(X)
        zone_vectors = self._obs.extract(X)

        result = np.zeros((len(X), len(self._cells)), dtype=np.float64)
        for z, cell in enumerate(self._cells):
            result[:, z] = cell.predict(zone_vectors[z])

        return result

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("BMCRegressor is not fitted. Call fit() first.")

    def __repr__(self) -> str:
        status = "fitted" if self.is_fitted_ else "unfitted"
        interp_str = repr(self._head_interpolator_template) if self._head_interpolator_template else "None"
        l2_str = f", n_clusters_l2={self.n_clusters_l2}" if self.n_clusters_l2 else ""
        return (
            f"BMCRegressor("
            f"n_clusters={self.n_clusters}{l2_str}, "
            f"interpolator={interp_str}, "
            f"status={status})"
        )
