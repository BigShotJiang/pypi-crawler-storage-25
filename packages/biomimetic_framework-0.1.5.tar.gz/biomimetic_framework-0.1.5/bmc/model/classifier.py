# bmc/model/classifier.py
"""
BMCClassifier — high-level fit/predict interface for classification.

This is the easy path. A researcher who does not want to manually
configure observation spaces, metrics, and composition can use this
class with sensible defaults.

Under the hood it builds a SequentialBMC (BMCLayer + LUT2)
with default settings, but every component is configurable.

Usage (easy path):
    clf = BMCClassifier()
    clf.fit(X_train, y_train)
    preds = clf.predict(X_test)

Usage (full control):
    clf = BMCClassifier(
        observation_space=ImageObservationSpace(28, 10, 5, 5),
        n_clusters=256,
        n_clusters_l2=128,
        metric=FrobeniusMetric(),
        interpolate=True,
    )
    clf.fit(X_train, y_train)
"""

import numpy as np
from typing import Optional, Union

from bmc.model.base import BMCModel
from bmc.observation.base import ObservationSpace
from bmc.observation.tabular import TabularObservationSpace
from bmc.composition.layer import BMCLayer
from bmc.composition.sequential import SequentialBMC
from bmc.metrics.base import SimilarityMetric
from bmc.metrics.l2 import L2Metric


class BMCClassifier(BMCModel):
    """
    High-level BMC classifier with sklearn-compatible interface.

    Combines an observation space, parallel BMC layer, and optional
    second-layer LUT into a single fit/predict API.

    Parameters
    ----------
    observation_space : ObservationSpace, optional
        How to decompose inputs into zones. If None, defaults to
        TabularObservationSpace with n_zones=min(n_features, 10).
        Set explicitly for images, time series, or text.
    n_clusters : int
        Voronoi cells per zone in layer 1. Default: 128.
    n_clusters_l2 : int or None
        Voronoi cells in the prediction head (layer 2). Defaults to
        n_clusters (same capacity as layer 1). Set to None to disable
        the prediction head and use raw zone voting instead.
    metric : SimilarityMetric, optional
        Distance metric for all layers. Default: L2Metric().
    interpolate : bool
        Use geodesic interpolation. Default: False.
    rng : np.random.Generator, optional
    """

    def __init__(
        self,
        observation_space: Optional[ObservationSpace] = None,
        n_clusters: int = 128,
        n_clusters_l2: Union[int, str, None] = "auto",
        metric: Optional[SimilarityMetric] = None,
        interpolate: bool = False,
        rng: Optional[np.random.Generator] = None,
    ):
        self.observation_space = observation_space
        self.n_clusters = n_clusters
        self.n_clusters_l2 = n_clusters_l2
        self.metric = metric if metric is not None else L2Metric()
        self.interpolate = interpolate
        self.rng = rng if rng is not None else np.random.default_rng(42)

        self._model = None
        self._obs = None
        self.is_fitted_ = False
        self.n_classes_: Optional[int] = None

    def fit(self, X: np.ndarray, y: np.ndarray) -> "BMCClassifier":
        """
        Fit the classifier.

        Parameters
        ----------
        X : np.ndarray, shape (M, ...)
        y : np.ndarray, shape (M,), dtype int

        Returns
        -------
        self
        """
        X = np.asarray(X)
        y = np.asarray(y, dtype=np.int32)
        n_classes = int(y.max()) + 1
        self.n_classes_ = n_classes

        # resolve observation space
        if self.observation_space is None:
            if X.ndim == 2:
                n_features = X.shape[1]
                n_zones = min(n_features, 10)
                self._obs = TabularObservationSpace(n_features, n_zones=n_zones)
            else:
                raise ValueError(
                    "observation_space must be specified for non-tabular inputs. "
                    "Use ImageObservationSpace, TimeSeriesObservationSpace, etc."
                )
        else:
            self._obs = self.observation_space

        # Resolve n_clusters_l2
        n_clusters_l2 = self.n_clusters_l2
        if n_clusters_l2 == "auto":
            n_clusters_l2 = self.n_clusters

        # Layer 1 always uses interpolation — smooth representations
        # feed the prediction head more precise patterns.
        # The prediction head uses the user's interpolate setting.
        l1 = BMCLayer(
            observation_space=self._obs,
            n_clusters=self.n_clusters,
            metric=self.metric,
            interpolate=True,
            rng=np.random.default_rng(int(self.rng.integers(0, 2**31))),
        )

        if n_clusters_l2 is not None:
            self._model = SequentialBMC(
                l1,
                n_clusters_l2=n_clusters_l2,
                metric_l2=self.metric,
                interpolate_l2=self.interpolate,
                rng=np.random.default_rng(int(self.rng.integers(0, 2**31))),
            )
        else:
            self._model = l1

        self._model.fit(X, y, n_classes=n_classes)
        self.is_fitted_ = True
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        self._check_fitted()
        return self._model.predict(X)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        self._check_fitted()
        return self._model.predict_proba(X)

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("BMCClassifier is not fitted. Call fit() first.")

    def __repr__(self) -> str:
        status = "fitted" if self.is_fitted_ else "unfitted"
        return (
            f"BMCClassifier("
            f"n_clusters={self.n_clusters}, "
            f"n_clusters_l2={self.n_clusters_l2}, "
            f"metric={self.metric}, "
            f"status={status})"
        )
