# bmc/model/persistence.py
"""
Model persistence — save and load trained BMC models.

Models are serialized using numpy's .npz format for arrays and
Python's built-in json for metadata. This avoids pickle entirely,
making saved models safe to load, version-stable, and inspectable.

The .bmc file format is a zip archive containing:
    - metadata.json  : model class, version, hyperparameters
    - arrays/        : all numpy arrays (seeds, luts, tsp_paths)

Usage:
    from bmc.model.persistence import save, load

    save(model, 'my_model.bmc')
    model = load('my_model.bmc', observation_space=obs)

Note: the observation_space is not serialized (it may contain
large state or external dependencies). The user must provide it
when loading.
"""

import json
import zipfile
import io
import numpy as np
from pathlib import Path
from typing import Union


_FORMAT_VERSION = "1.0"


def save(model, path: Union[str, Path]) -> None:
    """
    Save a trained BMC model to a .bmc file.

    Parameters
    ----------
    model : BMCClassifier, BMCRegressor, BMCLayer, or SequentialBMC
        A fitted model.
    path : str or Path
        Destination file path. Extension .bmc is conventional.

    Raises
    ------
    RuntimeError
        If the model is not fitted.
    """
    path = Path(path)

    if hasattr(model, 'is_fitted_') and not model.is_fitted_:
        raise RuntimeError("Cannot save an unfitted model.")

    state = _get_state(model)

    # inject model_class at the root of state so it survives serialization
    state['model_class'] = model.__class__.__name__

    arrays, metadata = _serialize_state(state)

    with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        # write metadata
        zf.writestr('metadata.json', json.dumps(metadata, indent=2))

        # write each array
        for key, arr in arrays.items():
            buf = io.BytesIO()
            np.save(buf, arr)
            zf.writestr(f'arrays/{key}.npy', buf.getvalue())


def load(path: Union[str, Path], observation_space=None):
    """
    Load a trained BMC model from a .bmc file.

    Parameters
    ----------
    path : str or Path
        Path to the .bmc file.
    observation_space : ObservationSpace, optional
        Required when loading BMCLayer, SequentialBMC,
        BMCClassifier, or BMCRegressor (any model that uses zones).

    Returns
    -------
    model
        A fitted model of the appropriate class.
    """
    path = Path(path)

    with zipfile.ZipFile(path, 'r') as zf:
        metadata = json.loads(zf.read('metadata.json'))

        arrays = {}
        for name in zf.namelist():
            if name.startswith('arrays/') and name.endswith('.npy'):
                key = name[len('arrays/'):-len('.npy')]
                buf = io.BytesIO(zf.read(name))
                arrays[key] = np.load(buf, allow_pickle=False)

    # extract model_class before deserializing (it's a plain string, not an array)
    model_class = metadata['model_class']
    state = _deserialize_state(metadata, arrays)
    model = _restore_model(model_class, state, observation_space)
    return model


# ── internal helpers ──────────────────────────────────────────────────────────

def _get_state(model) -> dict:
    """Extract serializable state from a model."""
    if hasattr(model, 'get_state'):
        return model.get_state()
    raise TypeError(f"Model type {type(model)} does not support get_state()")


def _serialize_state(state: dict) -> tuple:
    """
    Split state into JSON-serializable metadata and numpy arrays.

    Returns (arrays_dict, metadata_dict).
    """
    arrays = {}
    metadata = {}

    def _process(obj, prefix=""):
        if isinstance(obj, np.ndarray):
            key = prefix.strip('/')
            arrays[key] = obj
            return f"__array__:{key}"
        elif isinstance(obj, dict):
            return {k: _process(v, f"{prefix}/{k}") for k, v in obj.items()}
        elif isinstance(obj, list):
            return [_process(v, f"{prefix}/{i}") for i, v in enumerate(obj)]
        else:
            return obj

    metadata = _process(state)
    metadata['_format_version'] = _FORMAT_VERSION
    return arrays, metadata


def _deserialize_state(metadata: dict, arrays: dict) -> dict:
    """Reconstruct state dict from metadata and arrays."""

    def _process(obj):
        if isinstance(obj, str) and obj.startswith("__array__:"):
            key = obj[len("__array__:"):]
            return arrays[key]
        elif isinstance(obj, dict):
            return {k: _process(v) for k, v in obj.items()
                    if k != '_format_version'}
        elif isinstance(obj, list):
            return [_process(v) for v in obj]
        else:
            return obj

    return _process(metadata)


def _restore_model(model_class: str, state: dict, observation_space):
    """Instantiate and restore the correct model class."""

    if model_class == "BMCCell":
        from bmc.core.cell import BMCCell
        model = BMCCell(n_clusters=state['n_clusters'])
        model.set_state(state)
        return model

    elif model_class == "BMCLayer":
        from bmc.composition.layer import BMCLayer
        if observation_space is None:
            raise ValueError(
                "observation_space is required to load a BMCLayer model."
            )
        model = BMCLayer(observation_space, n_clusters=state['n_clusters'])
        model.set_state(state, observation_space)
        return model

    elif model_class in ("BMCNetwork", "SequentialBMC"):
        from bmc.composition.sequential import BMCNetwork
        model = BMCNetwork.__new__(BMCNetwork)
        model.layers = []
        model.is_fitted_ = False
        model.set_state(state, observation_space)
        return model

    elif model_class == "BMCClassifier":
        from bmc.model.classifier import BMCClassifier
        clf = BMCClassifier()
        clf._obs = observation_space
        # restore inner model
        inner_class = state.get('inner_model_class', 'BMCLayer')
        clf._model = _restore_model(inner_class, state['inner_model_state'], observation_space)
        clf.n_classes_ = state.get('n_classes_')
        clf.is_fitted_ = True
        return clf

    elif model_class == "BMCRegressor":
        from bmc.model.regressor import BMCRegressor
        reg = BMCRegressor()
        reg._obs = observation_space
        inner_class = state.get('inner_model_class', 'BMCLayer')
        reg._model = _restore_model(inner_class, state['inner_model_state'], observation_space)
        reg._bin_centers = state.get('bin_centers_')
        reg._bin_edges = state.get('bin_edges_')
        reg.is_fitted_ = True
        return reg

    else:
        raise ValueError(f"Unknown model class: {model_class}")
