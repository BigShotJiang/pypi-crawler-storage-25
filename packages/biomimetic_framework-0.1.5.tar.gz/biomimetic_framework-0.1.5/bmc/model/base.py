# bmc/model/base.py
"""
Abstract base class for high-level BMC models.

BMCClassifier and BMCRegressor inherit from this.
Provides the sklearn-compatible fit/predict interface.
"""

from abc import ABC, abstractmethod
import numpy as np


class BMCModel(ABC):
    """
    Abstract base for high-level BMC models.

    All models expose a fit/predict/predict_proba interface
    compatible with scikit-learn conventions.
    """

    @abstractmethod
    def fit(self, X: np.ndarray, y: np.ndarray) -> "BMCModel":
        """Fit the model on training data. Returns self."""
        ...

    @abstractmethod
    def predict(self, X: np.ndarray) -> np.ndarray:
        """Return hard predictions for X."""
        ...

    @abstractmethod
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Return probability distributions for X."""
        ...

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}()"
