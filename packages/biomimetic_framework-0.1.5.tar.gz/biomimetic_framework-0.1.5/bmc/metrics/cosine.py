# bmc/metrics/cosine.py
"""
Cosine distance metric.

Cosine similarity between two vectors a and b is:
    cos(a, b) = (a · b) / (||a|| * ||b||)

Cosine distance is defined as:
    d_cos(a, b) = 1 - cos(a, b)

This gives a value in [0, 2], where 0 means identical direction,
1 means orthogonal, and 2 means opposite direction.

Cosine distance is useful when the magnitude of feature vectors is
not meaningful — only the direction matters. This is common in
text embeddings and normalized feature spaces.

Note: inputs with zero norm are handled gracefully by adding a small
epsilon before normalization, producing a distance of 1.0 (orthogonal)
to any non-zero vector.
"""

import numpy as np
from typing import Optional
from .base import SimilarityMetric


class CosineMetric(SimilarityMetric):
    """
    Cosine distance: 1 - cosine_similarity.

    Range: [0, 2]. Inputs are flattened before computation.

    Parameters
    ----------
    eps : float
        Small value added to norms to prevent division by zero.
        Default: 1e-8.
    device : str or None
        "cpu" (default), "cuda", or "auto".

    Examples
    --------
    >>> metric = CosineMetric()
    >>> A = np.array([[1.0, 0.0]])
    >>> B = np.array([[0.0, 1.0]])
    >>> metric.pairwise(A, B)
    array([[1.0]])   # orthogonal vectors
    """

    def __init__(self, eps: float = 1e-8, device: Optional[str] = None):
        super().__init__(device=device)
        self.eps = eps

    def pairwise(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """
        Compute pairwise cosine distances.

        Parameters
        ----------
        A : (M, ...) float array
        B : (K, ...) float array

        Returns
        -------
        dists : (M, K) float32, values in [0, 2]
        """
        from bmc.backend import get_backend
        backend = get_backend(self._device)
        return backend.pairwise_cosine(A, B, eps=self.eps)
