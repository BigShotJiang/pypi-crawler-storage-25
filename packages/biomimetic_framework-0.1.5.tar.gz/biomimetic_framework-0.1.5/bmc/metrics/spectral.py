# bmc/metrics/spectral.py
"""
Spectral norm distance metric.

The spectral norm of a matrix A is its largest singular value:
    ||A||_2 = sigma_max(A)

The spectral distance between two matrices A and B is:
    d_spec(A, B) = ||A - B||_2 = sigma_max(A - B)

The spectral norm captures the maximum "amplification" the difference
matrix can apply to any unit vector. It is sensitive to the dominant
direction of variation between two matrices, making it appropriate
when the principal component of a patch difference is meaningful.

Note: this metric requires computing an SVD per pair, which is O(D^3)
for (D x D) matrices. For large D it is slower than L2 or Frobenius.
There is no closed-form expand trick — the pairwise method loops over K.
For K = 256 and (5x5) matrices this is fast. For K = 1024 it is slower.
"""

import numpy as np
from typing import Optional
from .base import SimilarityMetric


class SpectralMetric(SimilarityMetric):
    """
    Spectral norm distance between matrix-shaped features.

    Inputs must be at least 2D per sample — shape (M, H, W) or (M, D).
    For (M, D) inputs the "matrix" is treated as a (1, D) row vector,
    and the spectral norm equals the L2 norm.

    Parameters
    ----------
    device : str or None
        Currently spectral norm requires per-pair SVD and runs on CPU
        regardless of the device setting. The parameter is accepted
        for API consistency.

    Examples
    --------
    >>> metric = SpectralMetric()
    >>> A = np.zeros((2, 4, 4), dtype=np.float32)
    >>> B = np.eye(4, dtype=np.float32)[np.newaxis]  # (1, 4, 4)
    >>> metric.pairwise(A, B).shape
    (2, 1)
    """

    def __init__(self, device: Optional[str] = None):
        super().__init__(device=device)

    def pairwise(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """
        Compute pairwise spectral distances.

        Parameters
        ----------
        A : (M, ...) float array
        B : (K, ...) float array

        Returns
        -------
        dists : (M, K) float32
        """
        A = np.asarray(A, dtype=np.float32)
        B = np.asarray(B, dtype=np.float32)

        M = len(A)
        K = len(B)
        dists = np.zeros((M, K), dtype=np.float32)

        for k in range(K):
            diff = A - B[k]                    # (M, ...)
            diff_flat = diff.reshape(M, -1)    # (M, D)

            # for each sample compute largest singular value of diff matrix
            for m in range(M):
                d = diff_flat[m]
                # treat as (1, D) — singular values are just ||d||
                # for true matrix inputs reshape accordingly
                if A.ndim == 2:
                    # flat vector: spectral norm == L2 norm
                    dists[m, k] = float(np.linalg.norm(d))
                else:
                    # matrix input: reshape and compute SVD
                    mat_shape = A.shape[1:]
                    mat = diff[m].reshape(mat_shape)
                    sv = np.linalg.svd(mat, compute_uv=False)
                    dists[m, k] = float(sv[0])

        return dists
