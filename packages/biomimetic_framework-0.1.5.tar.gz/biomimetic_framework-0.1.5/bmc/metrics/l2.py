# bmc/metrics/l2.py
"""
L2 (Euclidean) distance metric.

For flat vectors, L2 and Frobenius norm are identical — both reduce to
the square root of the sum of squared element-wise differences.
L2 is defined here for flat (1D per sample) feature vectors.

Implementation uses the expand trick for full vectorization:
    ||a - b||^2 = ||a||^2 + ||b||^2 - 2 * a @ b.T

This avoids constructing any (M, K, D) intermediate tensors.

When device="cuda", the pairwise computation runs on GPU via PyTorch.
"""

import numpy as np
from typing import Optional
from .base import SimilarityMetric


class L2Metric(SimilarityMetric):
    """
    Euclidean (L2) distance between flat feature vectors.

    Parameters
    ----------
    device : str or None
        "cpu" (default), "cuda", or "auto".

    Examples
    --------
    >>> metric = L2Metric()
    >>> A = np.array([[1.0, 0.0], [0.0, 1.0]])
    >>> B = np.array([[1.0, 0.0]])
    >>> metric.pairwise(A, B)
    array([[0.], [1.4142...]])

    >>> metric = L2Metric(device="cuda")  # GPU-accelerated
    """

    def __init__(self, device: Optional[str] = None):
        super().__init__(device=device)

    def pairwise(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """
        Compute pairwise L2 distances.

        Parameters
        ----------
        A : (M, D) float array
        B : (K, D) float array

        Returns
        -------
        dists : (M, K) float32
        """
        from bmc.backend import get_backend
        backend = get_backend(self._device)
        return backend.pairwise_l2(A, B)
