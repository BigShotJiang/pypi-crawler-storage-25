# bmc/metrics/frobenius.py
"""
Frobenius norm distance metric.

The Frobenius norm of a matrix A is defined as:
    ||A||_F = sqrt(sum_{i,j} A_{ij}^2)

For the distance between two matrices A and B:
    d_F(A, B) = ||A - B||_F

When applied to flat vectors (1D), Frobenius and L2 are identical.
The Frobenius metric is meaningful when features are naturally
matrix-shaped (e.g. 2D image patches, covariance matrices) and
the element-wise difference carries geometric meaning.

This implementation preserves matrix structure — it does NOT flatten
inputs before computing distances. If you want flat-vector L2, use L2Metric.
"""

import numpy as np
from typing import Optional
from .base import SimilarityMetric


class FrobeniusMetric(SimilarityMetric):
    """
    Frobenius norm distance between matrix-shaped features.

    Operates natively on (M, H, W) inputs — no flattening required.
    For (M, D) inputs it reduces to L2.

    Parameters
    ----------
    device : str or None
        "cpu" (default), "cuda", or "auto".

    Examples
    --------
    >>> metric = FrobeniusMetric()
    >>> A = np.zeros((2, 3, 3), dtype=np.float32)
    >>> B = np.ones((4, 3, 3), dtype=np.float32)
    >>> metric.pairwise(A, B).shape
    (2, 4)
    """

    def __init__(self, device: Optional[str] = None):
        super().__init__(device=device)

    def pairwise(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """
        Compute pairwise Frobenius distances.

        Parameters
        ----------
        A : (M, ...) float array — M samples of any shape
        B : (K, ...) float array — K samples of same shape as A

        Returns
        -------
        dists : (M, K) float32
        """
        from bmc.backend import get_backend
        backend = get_backend(self._device)
        return backend.pairwise_frobenius(A, B)
