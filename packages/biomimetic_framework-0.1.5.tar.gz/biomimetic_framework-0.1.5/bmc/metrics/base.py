# bmc/metrics/base.py
"""
Abstract base class for similarity metrics.

All metrics in the bmc library are first-class objects, not string keys.
This mirrors PyTorch's design for loss functions — you instantiate a metric
and pass it wherever a distance function is needed.

A metric must implement two methods:
    - __call__(a, b) -> scalar distance between two vectors
    - pairwise(A, B) -> (M, K) distance matrix between two sets of vectors

The pairwise method is the performance-critical path — it must be
fully vectorized with no Python loops over M or K.

All metrics accept an optional `device` parameter ("cpu", "cuda", or "auto")
to control whether pairwise computation runs on CPU (NumPy) or GPU (PyTorch).
"""

from abc import ABC, abstractmethod
from typing import Optional
import numpy as np


class SimilarityMetric(ABC):
    """
    Abstract base class for all similarity metrics.

    Parameters
    ----------
    device : str or None
        Compute device for pairwise operations.
        "cpu" (default), "cuda" (requires PyTorch + CUDA GPU),
        or "auto" (use GPU if available, else CPU).

    Subclasses must implement `pairwise`. The `__call__` method
    is provided as a convenience wrapper over `pairwise` for
    computing single pairwise distances.
    """

    def __init__(self, device: Optional[str] = None):
        self._device = device

    @property
    def device(self) -> str:
        from bmc.backend import resolve_device
        return resolve_device(self._device)

    @device.setter
    def device(self, value: Optional[str]):
        self._device = value

    def to(self, device: str) -> "SimilarityMetric":
        """
        Return this metric configured for the given device.

        Parameters
        ----------
        device : str
            "cpu", "cuda", or "auto".

        Returns
        -------
        self : SimilarityMetric
            Returns self for chaining.
        """
        self._device = device
        return self

    @abstractmethod
    def pairwise(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """
        Compute pairwise distances between all rows of A and all rows of B.

        Parameters
        ----------
        A : np.ndarray, shape (M, D)
        B : np.ndarray, shape (K, D)

        Returns
        -------
        dists : np.ndarray, shape (M, K), float32
            dists[i, j] = distance between A[i] and B[j].
        """
        ...

    def __call__(self, a: np.ndarray, b: np.ndarray) -> float:
        """
        Compute distance between two vectors.

        Parameters
        ----------
        a : np.ndarray, shape (D,)
        b : np.ndarray, shape (D,)

        Returns
        -------
        dist : float
        """
        a2 = np.atleast_2d(a)
        b2 = np.atleast_2d(b)
        return float(self.pairwise(a2, b2)[0, 0])

    def __repr__(self) -> str:
        if self._device is not None and self._device != "cpu":
            return f"{self.__class__.__name__}(device={self._device!r})"
        return f"{self.__class__.__name__}()"
