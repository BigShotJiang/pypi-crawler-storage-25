# bmc/metrics/nuclear.py
"""
Nuclear norm distance metric.

The nuclear norm of a matrix A is the sum of its singular values:
    ||A||_* = sum_i sigma_i(A)

The nuclear distance between two matrices A and B is:
    d_nuc(A, B) = ||A - B||_* = sum_i sigma_i(A - B)

The nuclear norm is the convex envelope of the matrix rank — it measures
the total "spread" of the difference matrix across all directions.
It is the dual norm of the spectral norm.

Nuclear distance is appropriate when the full singular value spectrum
of the difference is meaningful, not just the dominant direction.
For image patches, it captures differences in all spatial frequency bands.

Note: like spectral, this requires SVD per pair — O(D^3) per element.
"""

import numpy as np
from typing import Optional
from .base import SimilarityMetric


class NuclearMetric(SimilarityMetric):
    """
    Nuclear norm distance between matrix-shaped features.

    Inputs must be at least 2D per sample — shape (M, H, W) or (M, D).
    For flat (M, D) inputs the nuclear norm equals the L2 norm (single
    singular value).

    Parameters
    ----------
    device : str or None
        Currently nuclear norm requires per-pair SVD and runs on CPU
        regardless of the device setting. The parameter is accepted
        for API consistency.

    Examples
    --------
    >>> metric = NuclearMetric()
    >>> A = np.zeros((2, 4, 4), dtype=np.float32)
    >>> B = np.eye(4, dtype=np.float32)[np.newaxis]
    >>> metric.pairwise(A, B).shape
    (2, 1)
    """

    def __init__(self, device: Optional[str] = None):
        super().__init__(device=device)

    def pairwise(self, A: np.ndarray, B: np.ndarray) -> np.ndarray:
        """
        Compute pairwise nuclear distances.

        Parameters
        ----------
        A : (M, ...) float array
        B : (K, ...) float array

        Returns
        -------
        dists : (M, K) float32
        """
        A = np.asarray(A, dtype=np.float32)
        B = np.asarray(B, dtype=np.float32)

        M = len(A)
        K = len(B)
        dists = np.zeros((M, K), dtype=np.float32)

        for k in range(K):
            diff = A - B[k]   # (M, ...)

            for m in range(M):
                if A.ndim == 2:
                    # flat: nuclear norm == L2 norm
                    dists[m, k] = float(np.linalg.norm(diff[m]))
                else:
                    mat_shape = A.shape[1:]
                    mat = diff[m].reshape(mat_shape)
                    sv = np.linalg.svd(mat, compute_uv=False)
                    dists[m, k] = float(sv.sum())

        return dists
