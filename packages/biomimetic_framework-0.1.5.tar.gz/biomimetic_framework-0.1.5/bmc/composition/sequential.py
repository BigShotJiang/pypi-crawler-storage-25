# bmc/composition/sequential.py
"""
BMCNetwork — general N-layer composable BMC network.

Any layer that implements the (fit, transform, predict) contract can be
stacked in sequence. Each layer's transform() output becomes the next
layer's input. Labels are always passed through unchanged — every layer
is supervised by the same ground-truth labels.

Supported layer types:
    - BMCCell   : single-zone lookup (transform → (M, C))
    - BMCLayer          : multi-zone parallel voting (transform → (M, N_zones, C))

The key insight: BMCLayer.transform() returns (M, N_zones, C), which is
automatically flattened to (M, N_zones*C) before being fed to the next layer.
This makes it legal to place a BMCLayer at any position in the network,
not just position 0.

Example topologies:

  # Classic 2-layer (what SequentialBMC was hardcoded to):
  net = BMCNetwork([
      BMCLayer(obs, n_clusters=1024),
      BMCCell(n_clusters=256),
  ])

  # 3-layer: parallel → parallel → single
  net = BMCNetwork([
      BMCLayer(obs_image, n_clusters=1024),
      BMCLayer(obs_tabular_auto, n_clusters=256),
      BMCCell(n_clusters=64),
  ])

  # 4-layer:
  net = BMCNetwork([
      BMCLayer(obs, n_clusters=1024),
      BMCCell(n_clusters=256),
      BMCCell(n_clusters=64),
      BMCCell(n_clusters=16),
  ])

The network is fitted greedily layer by layer on the training data.
No backpropagation. No gradients.

SequentialBMC is kept as a convenience constructor for the common
2-layer case (BMCLayer → BMCCell).
"""

import numpy as np
from typing import List, Optional, Union

from bmc.core.cell import BMCCell
from bmc.metrics.base import SimilarityMetric
from bmc.metrics.l2 import L2Metric
from bmc.core.inference import predict, normalize_distributions
from bmc.observation.tabular import TabularObservationSpace


# ── protocol check ────────────────────────────────────────────────────────────

def _check_layer_contract(layer, position: int):
    for method in ('fit', 'transform', 'predict'):
        if not hasattr(layer, method):
            raise TypeError(
                f"Layer at position {position} ({type(layer).__name__}) "
                f"does not implement '{method}()'. "
                f"All BMCNetwork layers must implement fit, transform, and predict."
            )


def _flatten_output(X: np.ndarray) -> np.ndarray:
    """
    Flatten any multi-dimensional layer output to (M, D) float32.
    BMCLayer.transform() → (M, N_zones, C)  needs flattening.
    BMCCell.transform() → (M, C)     already flat.
    """
    X = np.asarray(X, dtype=np.float32)
    if X.ndim == 2:
        return X
    return X.reshape(len(X), -1)


# ── BMCNetwork ────────────────────────────────────────────────────────────────

class BMCNetwork:
    """
    General N-layer composable BMC network.

    Layers are fitted and executed in sequence. Each layer's transform()
    output is flattened to (M, D) and passed as input to the next layer.
    Labels are passed unchanged to every layer's fit() call.

    Parameters
    ----------
    layers : list
        Ordered list of layers. Each must implement fit(), transform(),
        and predict(). The first layer receives the raw input. All
        subsequent layers receive the flattened transform() output of
        the previous layer.

    Attributes (after fit())
    ----------
    layers_ : list
        The fitted layers in order.
    n_classes_ : int
    is_fitted_ : bool

    Notes
    -----
    A layer that is already fitted when fit() is called will NOT be
    re-fitted — its transform() is used as-is. This allows pre-trained
    layers to be inserted into the network.

    If a BMCLayer appears at position > 0, its observation_space is
    automatically replaced with a TabularObservationSpace matching the
    input dimension, unless it is already a compatible TabularObservationSpace.
    """

    def __init__(self, layers: List):
        if len(layers) == 0:
            raise ValueError("BMCNetwork requires at least one layer.")
        for i, layer in enumerate(layers):
            _check_layer_contract(layer, i)

        self.layers = layers
        self.layers_: Optional[List] = None
        self.n_classes_: Optional[int] = None
        self.is_fitted_: bool = False

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        n_classes: Optional[int] = None,
    ) -> "BMCNetwork":
        """
        Fit all layers sequentially on training data.

        Parameters
        ----------
        X : np.ndarray
            Raw training input for layer 0.
        y : np.ndarray, shape (M,), dtype int
        n_classes : int, optional

        Returns
        -------
        self
        """
        y = np.asarray(y, dtype=np.int32)
        if n_classes is None:
            n_classes = int(y.max()) + 1
        self.n_classes_ = n_classes

        self.layers_ = list(self.layers)
        current_X = X

        for i, layer in enumerate(self.layers_):
            if i > 0:
                current_X = _flatten_output(current_X)
                layer = _maybe_rewrap_layer(layer, current_X, i)
                self.layers_[i] = layer

            if not getattr(layer, 'is_fitted_', False):
                layer.fit(current_X, y, n_classes=n_classes)

            current_X = layer.transform(current_X)

        self.is_fitted_ = True
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        """
        Run the full forward pass and return the final layer's output.

        Parameters
        ----------
        X : np.ndarray

        Returns
        -------
        output : np.ndarray, shape (M, C)
        """
        self._check_fitted()
        current_X = X
        for i, layer in enumerate(self.layers_):
            if i > 0:
                current_X = _flatten_output(current_X)
            current_X = layer.transform(current_X)
        return current_X

    def transform_at(self, X: np.ndarray, depth: int) -> np.ndarray:
        """
        Run the forward pass up to and including layer `depth`.

        Parameters
        ----------
        X : np.ndarray
        depth : int
            0-indexed. depth=0 returns output of layer 0 only.

        Returns
        -------
        output : np.ndarray
        """
        self._check_fitted()
        if depth < 0 or depth >= len(self.layers_):
            raise IndexError(
                f"depth={depth} out of range for {len(self.layers_)}-layer network."
            )
        current_X = X
        for i, layer in enumerate(self.layers_):
            if i > 0:
                current_X = _flatten_output(current_X)
            current_X = layer.transform(current_X)
            if i == depth:
                break
        return current_X

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict class labels.

        Returns
        -------
        predictions : np.ndarray, shape (M,), dtype int32
        """
        output = _flatten_output(self.transform(X))
        return predict(output)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Return normalized probability distributions.

        Returns
        -------
        probabilities : np.ndarray, shape (M, C)
        """
        output = _flatten_output(self.transform(X))
        return normalize_distributions(output)

    def predict_at(self, X: np.ndarray, depth: int) -> np.ndarray:
        """
        Return predictions using only layers 0..depth (inclusive).

        Parameters
        ----------
        X : np.ndarray
        depth : int

        Returns
        -------
        predictions : np.ndarray, shape (M,), dtype int32
        """
        output = _flatten_output(self.transform_at(X, depth))
        return predict(output)

    def get_state(self) -> dict:
        """Return serializable state."""
        self._check_fitted()
        return {
            "model_class": self.__class__.__name__,
            "n_classes_": self.n_classes_,
            "n_layers": len(self.layers_),
            "layers_": [layer.get_state() for layer in self.layers_],
        }

    def set_state(
        self,
        state: dict,
        observation_spaces: Union[list, object, None] = None,
    ) -> "BMCNetwork":
        """
        Restore state from a dict produced by get_state().

        Parameters
        ----------
        state : dict
        observation_spaces : ObservationSpace, list of ObservationSpace, or None
            Provide one per layer that requires one (BMCLayer layers).
            A single ObservationSpace is applied to layer 0; the rest default
            to None (which is correct for BMCCell layers).
        """
        from bmc.composition.layer import BMCLayer

        self.n_classes_ = state["n_classes_"]
        n_layers = state["n_layers"]

        if observation_spaces is None:
            obs_list = [None] * n_layers
        elif not isinstance(observation_spaces, list):
            obs_list = [observation_spaces] + [None] * (n_layers - 1)
        else:
            obs_list = list(observation_spaces)
            while len(obs_list) < n_layers:
                obs_list.append(None)

        self.layers_ = []
        for i, layer_state in enumerate(state["layers_"]):
            layer_class = layer_state.get("model_class", "BMCCell")
            obs = obs_list[i]

            if layer_class == "BMCLayer":
                if obs is None:
                    raise ValueError(
                        f"Layer {i} is a BMCLayer but no observation_space "
                        f"was provided at index {i} in observation_spaces."
                    )
                layer = BMCLayer(obs, n_clusters=layer_state["n_clusters"])
                layer.set_state(layer_state, obs)
            else:
                layer = BMCCell(n_clusters=layer_state["n_clusters"])
                layer.set_state(layer_state)

            self.layers_.append(layer)

        self.is_fitted_ = True
        return self

    def __len__(self) -> int:
        layers = self.layers_ if self.layers_ is not None else self.layers
        return len(layers)

    def __getitem__(self, idx: int):
        layers = self.layers_ if self.layers_ is not None else self.layers
        return layers[idx]

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("BMCNetwork is not fitted. Call fit() first.")

    def __repr__(self) -> str:
        status = "fitted" if self.is_fitted_ else "unfitted"
        layers = self.layers_ if self.layers_ is not None else self.layers
        layer_reprs = " → ".join(type(l).__name__ for l in layers)
        return f"BMCNetwork([{layer_reprs}], status={status})"


# ── auto-rewrap helper ────────────────────────────────────────────────────────

def _maybe_rewrap_layer(layer, X_flat: np.ndarray, position: int):
    """
    If a BMCLayer at position > 0 has an observation space that does not
    match the flat input dimension, replace it with a TabularObservationSpace
    that automatically partitions the features.
    """
    from bmc.composition.layer import BMCLayer
    if not isinstance(layer, BMCLayer):
        return layer

    n_features = X_flat.shape[1]
    obs = layer.observation_space

    if isinstance(obs, TabularObservationSpace) and obs.n_features == n_features:
        return layer  # already compatible

    n_zones = obs.n_zones
    new_obs = TabularObservationSpace(n_features=n_features, n_zones=n_zones)
    layer.observation_space = new_obs
    layer.is_fitted_ = False  # must refit since obs changed
    return layer


# ── SequentialBMC — backward-compatible 2-layer convenience ──────────────────

class SequentialBMC(BMCNetwork):
    """
    Convenience constructor for the common 2-layer topology:
        BMCLayer → BMCCell

    Equivalent to:
        BMCNetwork([bmc_layer, BMCCell(n_clusters_l2, ...)])

    For deeper or more flexible networks, use BMCNetwork directly.

    Parameters
    ----------
    bmc_layer : BMCLayer
        First layer. If already fitted, it will not be re-fitted.
    n_clusters_l2 : int
        Clusters for the second-layer BMCCell.
    metric_l2 : SimilarityMetric, optional
    interpolate_l2 : bool
    rng : np.random.Generator, optional
    """

    def __init__(
        self,
        bmc_layer,
        n_clusters_l2: int,
        metric_l2: Optional[SimilarityMetric] = None,
        interpolate_l2: bool = False,
        rng: Optional[np.random.Generator] = None,
    ):
        rng = rng if rng is not None else np.random.default_rng(42)
        metric_l2 = metric_l2 if metric_l2 is not None else L2Metric()

        layer2 = BMCCell(
            n_clusters=n_clusters_l2,
            metric=metric_l2,
            interpolate=interpolate_l2,
            rng=np.random.default_rng(int(rng.integers(0, 2**31))),
        )

        super().__init__([bmc_layer, layer2])

        self.n_clusters_l2 = n_clusters_l2
        self.metric_l2 = metric_l2
        self.interpolate_l2 = interpolate_l2

    @property
    def layer1_(self):
        layers = self.layers_ if self.layers_ is not None else self.layers
        return layers[0] if layers else None

    @property
    def layer2_(self):
        layers = self.layers_ if self.layers_ is not None else self.layers
        return layers[1] if len(layers) > 1 else None

    def predict_l1(self, X: np.ndarray) -> np.ndarray:
        """Return layer-1 only predictions (baseline)."""
        self._check_fitted()
        return self.layers_[0].predict(X)

    def __repr__(self) -> str:
        status = "fitted" if self.is_fitted_ else "unfitted"
        layers = self.layers_ if self.layers_ is not None else self.layers
        n_l1 = getattr(layers[0], 'n_clusters', '?')
        return (
            f"SequentialBMC("
            f"n_clusters_l1={n_l1}, "
            f"n_clusters_l2={self.n_clusters_l2}, "
            f"status={status})"
        )
