# bmc/observation/timeseries.py
"""
Time series observation space.

Decomposes a time series into overlapping or non-overlapping windows.
Each window becomes a zone, and the flattened window values form the
feature vector.

This enables the BMC framework to handle sequential data by treating
local temporal patterns as the atomic observation unit.
"""

import numpy as np
from typing import Optional
from .base import ObservationSpace


class TimeSeriesObservationSpace(ObservationSpace):
    """
    Observation space for 1D time series data.

    Extracts sliding windows of fixed length as zones.

    Parameters
    ----------
    series_length : int
        Length of each input time series.
    window_size : int
        Length of each window (zone).
    stride : int
        Step between consecutive window start positions.
        stride=1 gives maximum overlap (dense windows).
        stride=window_size gives non-overlapping windows.
    n_features : int, optional
        Number of features per time step (for multivariate series).
        Default: 1 (univariate).

    Examples
    --------
    Univariate, length=100, window=10, stride=5:
        >>> obs = TimeSeriesObservationSpace(100, window_size=10, stride=5)
        >>> obs.n_zones
        19
        >>> obs.feature_dim
        10

    Multivariate, 3 features per step:
        >>> obs = TimeSeriesObservationSpace(100, window_size=10, stride=5, n_features=3)
        >>> obs.feature_dim
        30
    """

    def __init__(
        self,
        series_length: int,
        window_size: int,
        stride: int = 1,
        n_features: int = 1,
    ):
        if window_size > series_length:
            raise ValueError(
                f"window_size ({window_size}) must be <= series_length ({series_length})"
            )
        if stride < 1:
            raise ValueError(f"stride must be >= 1, got {stride}")

        self.series_length = series_length
        self.window_size = window_size
        self.stride = stride
        self.n_features_per_step = n_features

        # compute window start positions
        self._starts = list(range(0, series_length - window_size + 1, stride))
        self._n_zones = len(self._starts)
        self._feature_dim = window_size * n_features

    @property
    def n_zones(self) -> int:
        return self._n_zones

    @property
    def feature_dim(self) -> int:
        return self._feature_dim

    def extract(self, inputs: np.ndarray) -> np.ndarray:
        """
        Extract sliding window feature vectors from time series.

        Parameters
        ----------
        inputs : np.ndarray
            Shape (M, T) for univariate, (M, T, F) for multivariate.

        Returns
        -------
        zone_vectors : np.ndarray, shape (N_zones, M, D)
        """
        inputs = np.asarray(inputs, dtype=np.float32)

        if inputs.ndim == 2:
            # (M, T) -> (M, T, 1)
            inputs = inputs[:, :, np.newaxis]

        if inputs.ndim != 3:
            raise ValueError(f"Expected (M, T) or (M, T, F), got {inputs.shape}")

        M, T, F = inputs.shape
        if T != self.series_length:
            raise ValueError(
                f"Input series length {T} does not match "
                f"configured series_length {self.series_length}"
            )

        D = self._feature_dim
        result = np.zeros((self._n_zones, M, D), dtype=np.float32)

        for z, start in enumerate(self._starts):
            window = inputs[:, start:start + self.window_size, :]  # (M, W, F)
            result[z] = window.reshape(M, -1)

        return result

    def window_starts(self):
        """Return the list of window start positions."""
        return list(self._starts)
