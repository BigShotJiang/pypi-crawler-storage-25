# bmc/observation/tabular.py
"""
Tabular observation space.

For tabular data with F features, zones are defined as subsets of
features. Each zone observes a contiguous or explicitly specified
group of features.

Two modes:
1. Automatic partitioning: split F features into N_zones equal groups
2. Manual partitioning: user specifies which feature indices per zone

This allows the BMC framework to operate on tabular data without any
domain-specific knowledge — each zone learns a local distribution
over its feature subset.
"""

import numpy as np
from typing import List, Optional
from .base import ObservationSpace


class TabularObservationSpace(ObservationSpace):
    """
    Observation space for tabular (flat feature vector) data.

    Decomposes a feature vector into N_zones subsets, each of which
    becomes an independent zone with its own LUT.

    Parameters
    ----------
    n_features : int
        Total number of features in the input.
    n_zones : int, optional
        Number of zones for automatic equal partitioning.
        Mutually exclusive with zone_indices.
    zone_indices : list of list of int, optional
        Explicit feature indices per zone.
        zone_indices[z] = list of feature indices for zone z.
        Mutually exclusive with n_zones.

    Examples
    --------
    Automatic:
        >>> obs = TabularObservationSpace(n_features=20, n_zones=4)
        # zones: [0..4], [5..9], [10..14], [15..19]

    Manual:
        >>> obs = TabularObservationSpace(
        ...     n_features=20,
        ...     zone_indices=[[0, 1, 2], [3, 4, 5], [0, 3, 6, 9]]
        ... )
        # zones can overlap
    """

    def __init__(
        self,
        n_features: int,
        n_zones: Optional[int] = None,
        zone_indices: Optional[List[List[int]]] = None,
    ):
        if n_zones is None and zone_indices is None:
            raise ValueError("Either n_zones or zone_indices must be specified.")
        if n_zones is not None and zone_indices is not None:
            raise ValueError("Only one of n_zones or zone_indices may be specified.")

        self.n_features = n_features

        if zone_indices is not None:
            # validate
            for z, indices in enumerate(zone_indices):
                for idx in indices:
                    if idx < 0 or idx >= n_features:
                        raise ValueError(
                            f"zone_indices[{z}] contains invalid index {idx} "
                            f"for n_features={n_features}"
                        )
            self._zone_indices = [list(z) for z in zone_indices]
            self._n_zones = len(zone_indices)
        else:
            # automatic equal partitioning
            if n_zones < 1:
                raise ValueError(f"n_zones must be >= 1, got {n_zones}")
            self._n_zones = n_zones
            indices_per_zone = np.array_split(np.arange(n_features), n_zones)
            self._zone_indices = [list(z) for z in indices_per_zone]

        # feature_dim is the size of the largest zone
        self._feature_dim = max(len(z) for z in self._zone_indices)

    @property
    def n_zones(self) -> int:
        return self._n_zones

    @property
    def feature_dim(self) -> int:
        return self._feature_dim

    def extract(self, inputs: np.ndarray) -> np.ndarray:
        """
        Extract zone feature vectors from tabular inputs.

        Parameters
        ----------
        inputs : np.ndarray, shape (M, F)

        Returns
        -------
        zone_vectors : np.ndarray, shape (N_zones, M, D)
            Zones with fewer features than D are zero-padded on the right.
        """
        inputs = np.asarray(inputs, dtype=np.float32)
        if inputs.ndim == 1:
            inputs = inputs.reshape(1, -1)
        if inputs.ndim != 2:
            raise ValueError(f"Expected (M, F), got {inputs.shape}")

        M = len(inputs)
        D = self._feature_dim
        result = np.zeros((self._n_zones, M, D), dtype=np.float32)

        for z, indices in enumerate(self._zone_indices):
            zone_data = inputs[:, indices]                 # (M, len(indices))
            result[z, :, :len(indices)] = zone_data

        return result

    def zone_feature_counts(self) -> List[int]:
        """Return the number of features in each zone."""
        return [len(z) for z in self._zone_indices]
