# bmc/observation/base.py
"""
Abstract base class for observation spaces.

An observation space defines how raw input data is decomposed into
a set of local feature vectors that the BMC layers operate on.

In the EMNIST experiment, the observation space was:
- Input: (1, 28, 28) image
- Zones: 25 overlapping 10x10 regions on a 5x5 grid
- Features: each region pooled to a 5x5 vector via Lanczos

A different domain (e.g. time series) would have a different
zone decomposition and different pooling strategy, but the interface
remains the same: given a batch of inputs, return a batch of
zone feature vectors.

Implementing a custom observation space requires only:
1. Subclassing ObservationSpace
2. Implementing extract(inputs) -> (N_zones, M, D)

The library ships with:
- ImageObservationSpace  (2D grids with configurable pooling)
- TabularObservationSpace (feature subsets as zones)
- TimeSeriesObservationSpace (sliding windows as zones)
- TextObservationSpace (embedding chunks as zones)
"""

from abc import ABC, abstractmethod
import numpy as np


class ObservationSpace(ABC):
    """
    Abstract base class for observation spaces.

    An observation space is responsible for decomposing raw inputs
    into a structured set of zone feature vectors.

    All subclasses must implement `extract()`.

    Properties
    ----------
    n_zones : int
        Number of parallel zones this observation space produces.
    feature_dim : int
        Dimensionality of each zone's feature vector (D).
    """

    @property
    @abstractmethod
    def n_zones(self) -> int:
        """Number of zones (parallel channels) this space produces."""
        ...

    @property
    @abstractmethod
    def feature_dim(self) -> int:
        """Dimensionality of each zone's feature vector."""
        ...

    @abstractmethod
    def extract(self, inputs: np.ndarray) -> np.ndarray:
        """
        Extract zone feature vectors from a batch of inputs.

        Parameters
        ----------
        inputs : np.ndarray
            Batch of raw inputs. Shape depends on domain:
            - Images: (M, H, W) or (M, C, H, W)
            - Time series: (M, T) or (M, T, features)
            - Tabular: (M, F)
            - Text: (M, seq_len, embed_dim)

        Returns
        -------
        zone_vectors : np.ndarray, shape (N_zones, M, D)
            zone_vectors[z, i] is the D-dimensional feature vector
            for sample i in zone z.
        """
        ...

    def __call__(self, inputs: np.ndarray) -> np.ndarray:
        """Convenience: call extract() via the instance."""
        return self.extract(inputs)

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"n_zones={self.n_zones}, "
            f"feature_dim={self.feature_dim})"
        )
