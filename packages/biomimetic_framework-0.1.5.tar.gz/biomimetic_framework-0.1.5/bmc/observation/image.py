# bmc/observation/image.py
"""
Image observation space.

Decomposes a 2D grayscale image into a grid of overlapping patches,
each pooled down to a fixed-size feature vector.

Grid layout:
    Given image size H x W, pool size P x P, and grid dimension G:
    G^2 overlapping patches are extracted at evenly-spaced positions.
    Positions are computed as: round(i * (H - P) / (G - 1)) for i in 0..G-1

Pooling methods:
    - 'lanczos'  : PIL Lanczos resampling (high quality, CPU only)
    - 'bilinear' : torch F.interpolate bilinear
    - 'bicubic'  : torch F.interpolate bicubic
    - 'avg'      : adaptive average pooling
    - 'max'      : adaptive max pooling
    - 'area'     : OpenCV area interpolation (anti-aliased)
    - 'gaussian' : Gaussian blur then area

Output shape: (G*G, M, output_size*output_size)
"""

import numpy as np
from .base import ObservationSpace


_SUPPORTED_METHODS = ('lanczos', 'bilinear', 'bicubic', 'avg', 'max', 'area', 'gaussian')


class ImageObservationSpace(ObservationSpace):
    """
    Observation space for 2D grayscale images.

    Extracts G*G overlapping patches from each image and pools each
    patch to an output_size x output_size feature vector.

    Parameters
    ----------
    image_size : int
        Height and width of the input images (assumed square).
    pool_size : int
        Height and width of each extracted patch.
    grid_n : int
        Number of grid positions per axis. Total zones = grid_n^2.
    output_size : int
        Height and width of each pooled feature vector.
        Feature dimension D = output_size^2.
    method : str
        Pooling method. One of: 'lanczos', 'bilinear', 'bicubic',
        'avg', 'max', 'area', 'gaussian'.

    Examples
    --------
    >>> obs = ImageObservationSpace(image_size=28, pool_size=10,
    ...                             grid_n=5, output_size=5)
    >>> images = np.random.rand(100, 28, 28).astype(np.float32)
    >>> zones = obs.extract(images)
    >>> zones.shape
    (25, 100, 25)
    """

    def __init__(
        self,
        image_size: int = 28,
        pool_size: int = 10,
        grid_n: int = 5,
        output_size: int = 5,
        method: str = 'lanczos',
    ):
        if method not in _SUPPORTED_METHODS:
            raise ValueError(f"method must be one of {_SUPPORTED_METHODS}, got '{method}'")
        if grid_n < 2:
            raise ValueError(f"grid_n must be >= 2, got {grid_n}")
        if pool_size > image_size:
            raise ValueError(f"pool_size ({pool_size}) must be <= image_size ({image_size})")

        self.image_size = image_size
        self.pool_size = pool_size
        self.grid_n = grid_n
        self.output_size = output_size
        self.method = method

        # precompute grid start positions
        self._starts = [
            round(i * (image_size - pool_size) / (grid_n - 1))
            for i in range(grid_n)
        ]

    @property
    def n_zones(self) -> int:
        return self.grid_n ** 2

    @property
    def feature_dim(self) -> int:
        return self.output_size ** 2

    def extract(self, inputs: np.ndarray) -> np.ndarray:
        """
        Extract and pool patches from a batch of images.

        Parameters
        ----------
        inputs : np.ndarray
            Shape (M, H, W) or (M, 1, H, W). Values in [0, 1].

        Returns
        -------
        zone_vectors : np.ndarray, shape (N_zones, M, D)
        """
        inputs = np.asarray(inputs, dtype=np.float32)

        # normalize shape to (M, H, W)
        if inputs.ndim == 4:
            inputs = inputs[:, 0, :, :]
        if inputs.ndim != 3:
            raise ValueError(f"Expected (M, H, W) or (M, 1, H, W), got {inputs.shape}")

        M = len(inputs)
        N_zones = self.n_zones
        D = self.feature_dim
        result = np.zeros((N_zones, M, D), dtype=np.float32)

        zone_idx = 0
        for gi in range(self.grid_n):
            for gj in range(self.grid_n):
                r = self._starts[gi]
                c = self._starts[gj]
                patches = inputs[:, r:r + self.pool_size, c:c + self.pool_size]
                pooled = self._pool_batch(patches)
                result[zone_idx] = pooled.reshape(M, -1)
                zone_idx += 1

        return result

    def _pool_batch(self, patches: np.ndarray) -> np.ndarray:
        """
        Pool a batch of patches to output_size x output_size.

        Parameters
        ----------
        patches : np.ndarray, shape (M, P, P)

        Returns
        -------
        pooled : np.ndarray, shape (M, output_size, output_size)
        """
        method = self.method
        M = len(patches)
        out = self.output_size

        if method == 'lanczos':
            return self._pool_lanczos(patches)
        elif method in ('bilinear', 'bicubic'):
            return self._pool_torch_interpolate(patches, method)
        elif method == 'avg':
            return self._pool_torch_adaptive(patches, mode='avg')
        elif method == 'max':
            return self._pool_torch_adaptive(patches, mode='max')
        elif method == 'area':
            return self._pool_cv2(patches, 'area')
        elif method == 'gaussian':
            return self._pool_gaussian(patches)
        else:
            raise ValueError(f"Unknown method: {method}")

    def _pool_lanczos(self, patches: np.ndarray) -> np.ndarray:
        try:
            from PIL import Image as PILImage
        except ImportError:
            raise ImportError("Pillow is required for lanczos pooling: pip install Pillow")

        out = self.output_size
        result = np.zeros((len(patches), out, out), dtype=np.float32)
        for i, p in enumerate(patches):
            arr = (p * 255).astype(np.uint8)
            pil = PILImage.fromarray(arr).convert('L')
            pil = pil.resize((out, out), PILImage.LANCZOS)
            result[i] = np.array(pil, dtype=np.float32) / 255.0
        return result

    def _pool_torch_interpolate(self, patches: np.ndarray, mode: str) -> np.ndarray:
        try:
            import torch
            import torch.nn.functional as F
        except ImportError:
            raise ImportError("PyTorch is required for bilinear/bicubic pooling: pip install torch")

        out = self.output_size
        t = torch.from_numpy(patches).unsqueeze(1)   # (M, 1, P, P)
        pooled = F.interpolate(t, size=(out, out), mode=mode, align_corners=False)
        return pooled.squeeze(1).numpy()

    def _pool_torch_adaptive(self, patches: np.ndarray, mode: str) -> np.ndarray:
        try:
            import torch
            import torch.nn.functional as F
        except ImportError:
            raise ImportError("PyTorch is required for avg/max pooling: pip install torch")

        out = self.output_size
        t = torch.from_numpy(patches).unsqueeze(1)
        if mode == 'avg':
            pooled = F.adaptive_avg_pool2d(t, out)
        else:
            pooled = F.adaptive_max_pool2d(t, out)
        return pooled.squeeze(1).numpy()

    def _pool_cv2(self, patches: np.ndarray, interp: str) -> np.ndarray:
        try:
            import cv2
        except ImportError:
            raise ImportError("OpenCV is required for area pooling: pip install opencv-python")

        out = self.output_size
        result = np.zeros((len(patches), out, out), dtype=np.float32)
        for i, p in enumerate(patches):
            arr = (p * 255).astype(np.uint8)
            resized = cv2.resize(arr, (out, out), interpolation=cv2.INTER_AREA)
            result[i] = resized.astype(np.float32) / 255.0
        return result

    def _pool_gaussian(self, patches: np.ndarray) -> np.ndarray:
        try:
            import cv2
        except ImportError:
            raise ImportError("OpenCV is required for gaussian pooling: pip install opencv-python")

        out = self.output_size
        result = np.zeros((len(patches), out, out), dtype=np.float32)
        for i, p in enumerate(patches):
            arr = (p * 255).astype(np.uint8)
            blurred = cv2.GaussianBlur(arr, (5, 5), sigmaX=1.0)
            resized = cv2.resize(blurred, (out, out), interpolation=cv2.INTER_AREA)
            result[i] = resized.astype(np.float32) / 255.0
        return result

    def grid_starts(self):
        """Return the list of patch start positions for inspection."""
        return list(self._starts)
