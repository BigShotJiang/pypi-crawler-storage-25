# bmc/observation/text.py
"""
Text embedding observation space.

For text data represented as sequences of embeddings (e.g. from a
transformer encoder), zones are defined as chunks of the embedding
sequence. Each chunk is flattened into a feature vector.

This allows BMC to operate on contextual embeddings without
knowing anything about the tokenization or model architecture.
The user provides the embeddings; this observation space
handles the chunking.
"""

import numpy as np
from typing import Optional
from .base import ObservationSpace


class TextObservationSpace(ObservationSpace):
    """
    Observation space for text represented as embedding sequences.

    Input: (M, seq_len, embed_dim) — M samples, each a sequence of embeddings.
    Zones: seq_len // chunk_size non-overlapping embedding chunks.

    Parameters
    ----------
    seq_len : int
        Length of the input embedding sequence (number of tokens/positions).
    embed_dim : int
        Dimensionality of each token embedding.
    chunk_size : int
        Number of consecutive embeddings per zone.
        Must divide seq_len evenly.
    stride : int, optional
        Step between chunks. Default: chunk_size (non-overlapping).
        Set stride < chunk_size for overlapping zones.

    Examples
    --------
    >>> obs = TextObservationSpace(seq_len=128, embed_dim=768, chunk_size=16)
    >>> obs.n_zones
    8
    >>> obs.feature_dim
    12288  # 16 * 768
    """

    def __init__(
        self,
        seq_len: int,
        embed_dim: int,
        chunk_size: int,
        stride: Optional[int] = None,
    ):
        if chunk_size > seq_len:
            raise ValueError(
                f"chunk_size ({chunk_size}) must be <= seq_len ({seq_len})"
            )
        if stride is None:
            stride = chunk_size
        if stride < 1:
            raise ValueError(f"stride must be >= 1, got {stride}")

        self.seq_len = seq_len
        self.embed_dim = embed_dim
        self.chunk_size = chunk_size
        self.stride = stride

        # compute chunk start positions
        self._starts = list(range(0, seq_len - chunk_size + 1, stride))
        self._n_zones = len(self._starts)
        self._feature_dim = chunk_size * embed_dim

    @property
    def n_zones(self) -> int:
        return self._n_zones

    @property
    def feature_dim(self) -> int:
        return self._feature_dim

    def extract(self, inputs: np.ndarray) -> np.ndarray:
        """
        Extract embedding chunks as zone feature vectors.

        Parameters
        ----------
        inputs : np.ndarray, shape (M, seq_len, embed_dim)

        Returns
        -------
        zone_vectors : np.ndarray, shape (N_zones, M, D)
        """
        inputs = np.asarray(inputs, dtype=np.float32)

        if inputs.ndim != 3:
            raise ValueError(f"Expected (M, seq_len, embed_dim), got {inputs.shape}")

        M, T, E = inputs.shape
        if T != self.seq_len:
            raise ValueError(
                f"Input seq_len {T} does not match configured seq_len {self.seq_len}"
            )
        if E != self.embed_dim:
            raise ValueError(
                f"Input embed_dim {E} does not match configured embed_dim {self.embed_dim}"
            )

        D = self._feature_dim
        result = np.zeros((self._n_zones, M, D), dtype=np.float32)

        for z, start in enumerate(self._starts):
            chunk = inputs[:, start:start + self.chunk_size, :]  # (M, C, E)
            result[z] = chunk.reshape(M, -1)

        return result

    def chunk_starts(self):
        """Return the list of chunk start positions."""
        return list(self._starts)
