# bmc/fpga/export.py
"""
Export a trained BMCCell to FPGA-ready Verilog + ROM hex files.

Usage:
    from bmc import BMCCell, L2Metric
    from bmc.fpga import export_for_fpga

    cell = BMCCell(n_clusters=128, metric=L2Metric())
    cell.fit(X_train, y_train, n_classes=10)
    result = export_for_fpga(cell, "build/", X_test=X_test, y_test=y_test)
    print(result)  # {'accuracy': 0.98, 'model_bytes': 9472, ...}
"""

import os
import numpy as np
from pathlib import Path
from typing import Optional

from bmc.fpga.verilog import (
    generate_inference,
    generate_testbench,
    generate_makefile,
)


def _quantize_to_uint8(data, data_min, data_max):
    """Map float data to 0-255 unsigned range."""
    span = data_max - data_min
    if span == 0:
        return np.zeros_like(data, dtype=np.uint8), 0.0, data_min
    scale = 255.0 / span
    q = np.round((data - data_min) * scale).astype(np.int32)
    return np.clip(q, 0, 255).astype(np.uint8), scale, data_min


def _write_hex(path, array_flat):
    """Write a flat uint8 array as one hex value per line."""
    with open(path, 'w') as f:
        for val in array_flat:
            f.write(f"{int(val):02x}\n")


def _integer_accuracy(X_test_q, seeds_q, lut_q, y_test, K, D, C):
    """Verify accuracy using pure integer arithmetic (matches FPGA exactly)."""
    correct = 0
    for i in range(len(X_test_q)):
        best_dist = None
        best_k = 0
        for k in range(K):
            d = 0
            for dim in range(D):
                diff = int(X_test_q[i, dim]) - int(seeds_q[k, dim])
                d += diff * diff
            if best_dist is None or d < best_dist:
                best_dist = d
                best_k = k
        pred = np.argmax(lut_q[best_k])
        if pred == y_test[i]:
            correct += 1
    return correct, len(X_test_q)


def export_for_fpga(
    cell,
    output_dir: str,
    X_test: Optional[np.ndarray] = None,
    y_test: Optional[np.ndarray] = None,
    data_min: Optional[float] = None,
    data_max: Optional[float] = None,
) -> dict:
    """
    Export a fitted BMCCell to FPGA-ready files.

    Generates a complete build directory with Verilog RTL, ROM hex files,
    a testbench, and a Makefile. Run ``make sim`` in the output directory
    to simulate with Icarus Verilog.

    Parameters
    ----------
    cell : BMCCell
        A fitted BMCCell (must have ``seeds_`` and ``lut_`` attributes).
    output_dir : str or Path
        Directory to write all generated files into. Created if missing.
    X_test : np.ndarray, optional
        Test vectors for the testbench. Shape ``(N, D)``.
    y_test : np.ndarray, optional
        Test labels. Shape ``(N,)``.
    data_min : float, optional
        Minimum value for quantization range. Inferred from seeds if omitted.
    data_max : float, optional
        Maximum value for quantization range. Inferred from seeds if omitted.

    Returns
    -------
    info : dict
        Export metadata: ``K``, ``D``, ``C``, ``model_bytes``,
        ``quantized_accuracy`` (if test data provided), ``output_dir``.

    Raises
    ------
    ValueError
        If the cell is not fitted.
    """
    if not hasattr(cell, 'seeds_') or cell.seeds_ is None:
        raise ValueError("Cell is not fitted. Call cell.fit() first.")

    seeds = cell.seeds_
    lut = cell.lut_
    K, D = seeds.shape
    C = lut.shape[1]

    # Determine quantization range
    if data_min is None:
        data_min = float(seeds.min())
        if X_test is not None:
            data_min = min(data_min, float(X_test.min()))
    if data_max is None:
        data_max = float(seeds.max())
        if X_test is not None:
            data_max = max(data_max, float(X_test.max()))

    # Quantize seeds
    seeds_q, scale, offset = _quantize_to_uint8(seeds, data_min, data_max)

    # Quantize LUT (probabilities → 0-255)
    lut_q = np.round(lut * 255).astype(np.uint8)

    # Create directory structure
    out = Path(output_dir)
    (out / "rtl").mkdir(parents=True, exist_ok=True)
    (out / "tb").mkdir(exist_ok=True)
    (out / "rom").mkdir(exist_ok=True)

    # Write ROMs
    _write_hex(out / "rom" / "seeds.hex", seeds_q.flatten())
    _write_hex(out / "rom" / "lut.hex", lut_q.flatten())

    # Quantize and write test data
    N_TEST = 0
    quant_acc = None
    if X_test is not None and y_test is not None:
        X_test_q, _, _ = _quantize_to_uint8(X_test, data_min, data_max)
        y_test_i = y_test.astype(np.int32)
        N_TEST = len(X_test)

        _write_hex(out / "rom" / "test_vectors.hex", X_test_q.flatten())
        _write_hex(out / "rom" / "test_labels.hex", y_test_i)

        # Verify with integer-only arithmetic
        correct, total = _integer_accuracy(
            X_test_q, seeds_q, lut_q, y_test_i, K, D, C
        )
        quant_acc = correct / total

    # Write Verilog
    (out / "rtl" / "bmc_inference.v").write_text(generate_inference(K, D, C))
    if N_TEST > 0:
        (out / "tb" / "tb_bmc_inference.v").write_text(
            generate_testbench(K, D, C, N_TEST)
        )
    (out / "Makefile").write_text(generate_makefile())

    info = {
        "K": K,
        "D": D,
        "C": C,
        "model_bytes": K * D + K * C,
        "seeds_bytes": K * D,
        "lut_bytes": K * C,
        "quantization_scale": float(scale),
        "quantization_offset": float(offset),
        "output_dir": str(out),
    }
    if quant_acc is not None:
        info["quantized_accuracy"] = quant_acc
        info["test_correct"] = correct
        info["test_total"] = total
    if N_TEST > 0:
        info["n_test"] = N_TEST

    return info
