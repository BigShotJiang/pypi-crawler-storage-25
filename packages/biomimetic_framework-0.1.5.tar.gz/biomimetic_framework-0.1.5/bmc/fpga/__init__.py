# bmc/fpga/__init__.py
"""
FPGA export and Verilog generation for BMC models.

Quick start:
    from bmc.fpga import export_for_fpga

    cell = BMCCell(n_clusters=128)
    cell.fit(X_train, y_train, n_classes=10)
    export_for_fpga(cell, "output_dir/")

This generates:
    - ROM hex files (seeds, LUT, optional test vectors)
    - Parameterized Verilog modules (inference and/or training)
    - A Makefile for simulation (iverilog) and synthesis (yosys)
"""

from bmc.fpga.export import export_for_fpga

__all__ = ["export_for_fpga"]
