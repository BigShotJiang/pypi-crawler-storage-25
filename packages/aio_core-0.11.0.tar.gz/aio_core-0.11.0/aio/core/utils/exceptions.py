

class ExtractError(Exception):
    pass
