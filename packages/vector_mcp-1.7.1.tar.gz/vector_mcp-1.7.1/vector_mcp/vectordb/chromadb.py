#!/usr/bin/python

import os
from typing import Any

from agent_utilities import create_embedding_model
from llama_index.core import (
    Document as LIDocument,
)
from llama_index.core import (
    StorageContext,
    VectorStoreIndex,
)

from vector_mcp.vectordb.base import Document, ItemID, QueryResults, VectorDB
from vector_mcp.vectordb.db_utils import (
    get_logger,
    optional_import_block,
    require_optional_import,
)

with optional_import_block():
    import chromadb
    from llama_index.vector_stores.chroma import ChromaVectorStore

logger = get_logger(__name__)


@require_optional_import(["chromadb", "llama_index"], "chromadb")
class ChromaVectorDB(VectorDB):
    """A vector database that uses ChromaDB as the backend via LlamaIndex."""

    def __init__(
        self,
        *,
        client: Any | None = None,
        path: str | None = None,
        embed_model: Any | None = None,
        collection_name: str = "memory",
        metadata: dict | None = None,
        **kwargs,
    ) -> None:
        """Initialize the vector database.

        Args:
           client: chromadb.Client | Existing client
           path: str | Path for persistent client
           collection_name: str | Collection name
        """
        self.embed_model = embed_model or create_embedding_model()
        self.active_collection = None
        self.type = ""
        self.collection_name = collection_name
        self.metadata = metadata or {}

        if client:
            self.client = client
        else:
            if path:
                self.path = path
                self.client = chromadb.PersistentClient(path=self.path)
            else:
                self.path = os.path.expanduser("~/Documents/ChromaDB")
                self.client = chromadb.PersistentClient(path=self.path)

        self.chroma_collection = self.client.get_or_create_collection(
            self.collection_name
        )
        self.vector_store = ChromaVectorStore(chroma_collection=self.chroma_collection)
        self.storage_context = StorageContext.from_defaults(
            vector_store=self.vector_store
        )
        self.active_collection = collection_name
        self.type = "chroma"
        self._index = None

    def _get_index(self) -> VectorStoreIndex:
        if self._index is None:
            self._index = VectorStoreIndex.from_vector_store(
                self.vector_store,
                storage_context=self.storage_context,
                embed_model=self.embed_model,
            )
        return self._index

    def create_collection(
        self, collection_name: str, overwrite: bool = False, _get_or_create: bool = True
    ) -> Any:
        self.collection_name = collection_name
        if overwrite:
            try:
                self.client.delete_collection(collection_name)
            except Exception as e:
                logger.info(f"Unable to retrieve toolset: {e}")
                pass

        self.chroma_collection = self.client.get_or_create_collection(collection_name)
        self.vector_store = ChromaVectorStore(chroma_collection=self.chroma_collection)
        self.storage_context = StorageContext.from_defaults(
            vector_store=self.vector_store
        )
        self.active_collection = collection_name
        self._index = None
        return self.chroma_collection

    def get_collection(self, collection_name: str | None = None) -> Any:
        name = collection_name or self.collection_name
        return self.client.get_collection(name)

    def insert_documents(
        self,
        docs: list[Document],
        collection_name: str | None = None,
        _upsert: bool = False,
        **kwargs,
    ) -> None:
        if collection_name:
            self.create_collection(collection_name)

        li_docs = []
        for doc in docs:
            metadata = doc.get("metadata", {}) or {}
            li_docs.append(
                LIDocument(text=doc["content"], doc_id=doc["id"], metadata=metadata)
            )

        index = self._get_index()
        index = self._get_index()
        for li_doc in li_docs:
            index.insert(li_doc)

    def semantic_search(
        self,
        queries: list[str],
        collection_name: str | None = None,
        n_results: int = 10,
        distance_threshold: float = -1,
        **kwargs: Any,
    ) -> QueryResults:
        if collection_name:
            self.create_collection(collection_name)

        index = self._get_index()
        results = []
        retriever = index.as_retriever(similarity_top_k=n_results)

        for query in queries:
            nodes = retriever.retrieve(query)
            query_result = []
            for node_match in nodes:
                if distance_threshold >= 0 and node_match.score < distance_threshold:
                    continue

                doc = Document(
                    id=node_match.node.node_id,
                    content=node_match.node.text,
                    metadata=node_match.node.metadata,
                    embedding=node_match.node.embedding,
                )
                query_result.append((doc, 1.0 - (node_match.score or 0.0)))
            results.append(query_result)
        return results

    def get_documents_by_ids(
        self,
        ids: list[ItemID] | None = None,
        collection_name: str | None = None,
        include=None,
        **kwargs,
    ) -> list[Document]:
        collection = self.get_collection(collection_name)

        # LlamaIndex stores our original IDs in metadata as 'doc_id'
        # So we need to query by metadata instead of primary IDs
        if ids:
            # Get all documents and filter by metadata
            results = collection.get(include=include or ["metadatas", "documents"])
            docs = []
            if results and results["ids"]:
                for i, _id in enumerate(results["ids"]):
                    metadata = results["metadatas"][i] if results["metadatas"] else {}
                    doc_id = metadata.get("doc_id")
                    if doc_id in ids:
                        docs.append(
                            Document(
                                id=doc_id,  # Return the original ID
                                content=(
                                    results["documents"][i]
                                    if results["documents"]
                                    else ""
                                ),
                                metadata=metadata,
                            )
                        )
            return docs
        else:
            # Return all documents
            results = collection.get(include=include or ["metadatas", "documents"])
            docs = []
            if results and results["ids"]:
                for i, _id in enumerate(results["ids"]):
                    metadata = results["metadatas"][i] if results["metadatas"] else {}
                    doc_id = metadata.get(
                        "doc_id", _id
                    )  # Use doc_id from metadata or fall back to UUID
                    docs.append(
                        Document(
                            id=doc_id,
                            content=(
                                results["documents"][i] if results["documents"] else ""
                            ),
                            metadata=metadata,
                        )
                    )
            return docs

    def update_documents(
        self, docs: list[Document], collection_name: str | None = None, **kwargs
    ) -> None:
        self.insert_documents(docs, collection_name, upsert=True, **kwargs)

    def delete_documents(
        self, ids: list[ItemID], collection_name: str | None = None, **kwargs
    ) -> None:
        if collection_name:
            self.create_collection(collection_name)
        self.vector_store.delete_nodes(ids)

    def delete_collection(self, collection_name: str) -> None:
        self.client.delete_collection(collection_name)
        if self.active_collection == collection_name:
            self.active_collection = ""

    def get_collections(self) -> Any:
        return self.client.list_collections()

    def lexical_search(
        self,
        queries: list[str],
        collection_name: str | None = None,
        n_results: int = 10,
        **kwargs: Any,
    ) -> QueryResults:
        collection = self.get_collection(collection_name)
        results = []
        for query in queries:
            query_res = collection.get(
                where_document={"$contains": query},
                include=["documents", "metadatas"],
                limit=n_results,
            )

            query_result = []
            if query_res and query_res["ids"]:
                for i, _id in enumerate(query_res["ids"]):
                    doc = Document(
                        id=_id,
                        content=(
                            query_res["documents"][i] if query_res["documents"] else ""
                        ),
                        metadata=(
                            query_res["metadatas"][i] if query_res["metadatas"] else {}
                        ),
                        embedding=None,
                    )
                    query_result.append((doc, 1.0))
            results.append(query_result)
        return results
