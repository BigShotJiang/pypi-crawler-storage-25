#!/usr/bin/python

import os
from typing import Any

from agent_utilities import create_embedding_model
from llama_index.core import (
    Document as LIDocument,
)
from llama_index.core import (
    SimpleDirectoryReader,
    StorageContext,
    VectorStoreIndex,
)

from vector_mcp.vectordb.base import Document, ItemID, QueryResults, VectorDB
from vector_mcp.vectordb.db_utils import (
    get_logger,
    optional_import_block,
    require_optional_import,
)

with optional_import_block():
    from llama_index.vector_stores.postgres import PGVectorStore
    from sqlalchemy import make_url, text

logger = get_logger(__name__)


@require_optional_import(
    ["llama_index.vector_stores.postgres", "psycopg", "llama_index"], "postgres"
)
class PostgreSQL(VectorDB):
    """A vector database that uses PGVector as the backend via LlamaIndex."""

    def __init__(
        self,
        *,
        connection_string: str | None = None,
        host: str | int | None = None,
        port: str | int | None = None,
        dbname: str | None = None,
        username: str | None = None,
        password: str | None = None,
        embed_model: Any | None = None,
        collection_name: str = "memory",
        metadata: dict[str, Any] | None = None,
        **kwargs,
    ) -> None:
        """Initialize the vector database with LlamaIndex PGVectorStore.

        Args:
            connection_string: str | Full connection string
            host, port, dbname, username, password: Connection details if no connection_string
            embed_model: BaseEmbedding | Custom embedding model
            collection_name: str | Name of the table/collection
            metadata: dict | HNSW index params
        """
        self.embed_model = embed_model or create_embedding_model()
        self.collection_name = collection_name
        self.metadata = metadata or {
            "hnsw_m": 16,
            "hnsw_ef_construction": 64,
            "hnsw_ef_search": 40,
        }

        self.dimension = len(self.embed_model.get_text_embedding("test"))

        if connection_string:
            url = make_url(connection_string)
            self._db_params = {
                "database": url.database,
                "host": url.host,
                "password": url.password,
                "port": url.port or 5432,
                "user": url.username,
            }
        else:
            self._db_params = {
                "database": dbname,
                "host": str(host),
                "password": password,
                "port": int(port) if port else 5432,
                "user": username,
            }

        self.vector_store = PGVectorStore.from_params(
            **self._db_params,
            table_name=self.collection_name,
            embed_dim=self.dimension,
            hnsw_kwargs=self.metadata,
            **kwargs,
        )
        self.storage_context = StorageContext.from_defaults(
            vector_store=self.vector_store
        )
        self.active_collection = collection_name
        self.type = "postgres"

        self._index = None

    def _get_index(self) -> VectorStoreIndex:
        if self._index is None:
            self._index = VectorStoreIndex.from_vector_store(
                self.vector_store,
                storage_context=self.storage_context,
                embed_model=self.embed_model,
            )
        return self._index

    def create_collection(
        self, collection_name: str, overwrite: bool = False, _get_or_create: bool = True
    ) -> Any:
        self.collection_name = collection_name
        if collection_name != self.vector_store.table_name:
            self.vector_store = PGVectorStore.from_params(
                **self._db_params,
                table_name=collection_name,
                embed_dim=self.dimension,
                hnsw_kwargs=self.metadata,
            )
            self.storage_context = StorageContext.from_defaults(
                vector_store=self.vector_store
            )
            self._index = None

        if overwrite:
            pass

        try:
            collections = self.get_collections()
            if collection_name not in collections:
                doc_dir = os.environ.get(
                    "DOCUMENT_DIRECTORY", os.path.normpath("/documents")
                )
                loaded_docs = []
                if os.path.exists(doc_dir) and os.listdir(doc_dir):
                    try:
                        logger.info(
                            f"Loading documents from {doc_dir} for new collection {collection_name}"
                        )
                        reader = SimpleDirectoryReader(input_dir=doc_dir)
                        loaded_docs = reader.load_data()
                    except Exception as e:
                        logger.warning(f"Failed to load documents from {doc_dir}: {e}")

                if loaded_docs:
                    index = self._get_index()
                    for doc in loaded_docs:
                        index.insert(doc)
                    logger.info(
                        f"Initialized collection {collection_name} with {len(loaded_docs)} documents."
                    )
                else:
                    dummy_doc = LIDocument(
                        text="initialization", doc_id="init_doc", metadata={}
                    )
                    index = self._get_index()
                    index.insert(dummy_doc)
                    index.delete_ref_doc("init_doc", delete_from_docstore=True)
                    logger.info(f"Initialized empty collection {collection_name}.")
        except Exception as e:
            logger.warning(f"Failed to force create table: {e}")

        self.active_collection = collection_name
        return self.vector_store

    def get_collection(self, collection_name: str | None = None) -> Any:
        name = collection_name or self.active_collection
        if name != self.collection_name:
            self.create_collection(name)
        return self.vector_store

    def delete_collection(self, collection_name: str) -> Any:
        pass

    def insert_documents(
        self,
        docs: list[Document],
        collection_name: str | None = None,
        _upsert: bool = False,
        **kwargs,
    ) -> None:
        if collection_name:
            self.create_collection(collection_name)

        li_docs = []
        for doc in docs:
            metadata = doc.get("metadata", {}) or {}
            li_docs.append(
                LIDocument(text=doc["content"], doc_id=doc["id"], metadata=metadata)
            )

        index = self._get_index()
        for li_doc in li_docs:
            index.insert(li_doc)

    def semantic_search(
        self,
        queries: list[str],
        collection_name: str | None = None,
        n_results: int = 10,
        distance_threshold: float = -1,
        **kwargs: Any,
    ) -> QueryResults:
        if collection_name:
            self.create_collection(collection_name)

        index = self._get_index()
        results = []
        retriever = index.as_retriever(similarity_top_k=n_results)

        for query in queries:
            nodes = retriever.retrieve(query)
            query_result = []
            for node_match in nodes:
                # node_match.score is already a distance from PGVector (COSINE distance)
                distance = node_match.score or 0.0
                if distance_threshold >= 0 and distance > distance_threshold:
                    continue

                doc = Document(
                    id=node_match.node.node_id,
                    content=node_match.node.text,
                    metadata=node_match.node.metadata,
                    embedding=node_match.node.embedding,
                )
                query_result.append((doc, 1.0 - distance))
            results.append(query_result)
        return results

    def get_documents_by_ids(
        self,
        ids: list[ItemID] | None = None,
        collection_name: str | None = None,
        include: list[str] | None = None,
        **kwargs: Any,
    ) -> list[Document]:
        # LlamaIndex stores our original IDs in metadata as 'doc_id'
        # PostgreSQL/PGVectorStore stores metadata in JSONB format in the metadata_ column
        # Table name is 'data_' + collection_name
        collection_name = collection_name or self.collection_name

        try:
            # Get the database connection from the vector store

            # Get the engine from the vector store
            engine = self.vector_store._engine

            # The table name is 'data_' + collection_name
            table_name = f"data_{collection_name}"

            with engine.connect() as conn:
                if ids:
                    # Build query to find documents where metadata_->>'doc_id' is in our ids list
                    # Use DISTINCT ON to get only one row per doc_id
                    query = text(f"""
                        SELECT DISTINCT ON (metadata_->>'doc_id') id, text, metadata_
                        FROM {table_name}
                        WHERE metadata_->>'doc_id' = ANY(:ids)
                    """)  # nosec B608

                    result = conn.execute(query, {"ids": ids})
                else:
                    # Get all documents
                    query = text(f"""
                        SELECT DISTINCT ON (metadata_->>'doc_id') id, text, metadata_
                        FROM {table_name}
                    """)  # nosec B608

                    result = conn.execute(query)

                rows = result.fetchall()

            docs = []
            for row in rows:
                # row[0]: id (BIGINT), row[1]: text (VARCHAR), row[2]: metadata_ (JSON)
                metadata_json = row[2] or {}
                doc_id = metadata_json.get("doc_id", "")
                doc_text = row[1] or ""

                # Extract metadata from the metadata_ JSON, filtering out LlamaIndex internal fields
                doc_metadata = {
                    k: v
                    for k, v in metadata_json.items()
                    if not k.startswith("_")
                    and k not in ["doc_id", "ref_doc_id", "document_id"]
                }

                docs.append(
                    Document(
                        id=doc_id,
                        content=doc_text,
                        metadata=doc_metadata,
                    )
                )

            return docs

        except Exception as e:
            logger.error(f"Error in get_documents_by_ids: {e}")
            # Fallback: try using LlamaIndex's ref_doc info if available
            try:
                # Try to get documents through the index
                index = self._get_index()
                # This might not work directly, but let's try

                # Alternative: use docstore if available
                if hasattr(index, "docstore") and index.docstore and ids:
                    docs = []
                    for doc_id in ids:
                        try:
                            ref_doc = index.docstore.get_ref_document(doc_id)
                            if ref_doc:
                                docs.append(
                                    Document(
                                        id=doc_id,
                                        content=ref_doc.text,
                                        metadata=ref_doc.metadata or {},
                                    )
                                )
                        except Exception: # nosec B112
                            continue
                    return docs
            except Exception as fallback_error:
                logger.warning(f"Fallback also failed: {fallback_error}")

            return []

    def update_documents(
        self, docs: list[Document], collection_name: str | None = None, **kwargs
    ) -> None:
        self.insert_documents(docs, collection_name, upsert=True)

    def delete_documents(
        self, ids: list[ItemID], collection_name: str | None = None, **kwargs
    ) -> None:
        if collection_name:
            self.create_collection(collection_name)
        self.vector_store.delete_nodes(ids)

    def get_collections(self) -> Any:
        try:
            engine = None
            if hasattr(self.vector_store, "_engine") and self.vector_store._engine:
                engine = self.vector_store._engine

            if not engine:
                from sqlalchemy import create_engine

                conn_str = self._db_params.get("connection_string")
                if not conn_str:
                    conn_str = f"postgresql://{self._db_params['user']}:{self._db_params['password']}@{self._db_params['host']}:{self._db_params['port']}/{self._db_params['database']}"

                url = make_url(conn_str)
                engine = create_engine(url)

            schema_name = "public"
            if hasattr(self.vector_store, "schema_name"):
                schema_name = self.vector_store.schema_name

            with engine.connect() as connection:
                query = text("""
                    SELECT table_name
                    FROM information_schema.tables
                    WHERE table_schema = :schema
                    AND table_type = 'BASE TABLE'
                """)  # nosec B608
                result = connection.execute(query, {"schema": schema_name})
                tables = []
                for row in result:
                    name = row[0]
                    if name.startswith("data_"):
                        name = name[5:]
                    tables.append(name)
                return tables

        except Exception as e:
            logger.error(f"Failed to list collections: {e}")
            return []

    def lexical_search(
        self,
        queries: list[str],
        collection_name: str | None = None,
        n_results: int = 10,
        **kwargs: Any,
    ) -> QueryResults:
        if collection_name:
            self.create_collection(collection_name)

        if not hasattr(self.vector_store, "_engine"):
            logger.warning(
                "PGVectorStore engine not accessible. Cannot run BM25 search."
            )
            return [[] for _ in queries]

        results = []
        with self.vector_store._engine.connect() as connection:
            for query in queries:
                table_name = f"data_{self.collection_name}"

                try:
                    sql = text(f"""
                        SELECT id, text, metadata_, paradedb.bm25(text, :q) as score
                        FROM {table_name}
                        WHERE paradedb.bm25(text, :q) > 0
                        ORDER BY score DESC
                        LIMIT :k
                    """)  # nosec B608

                    result_proxy = connection.execute(sql, {"q": query, "k": n_results})
                    query_result = []
                    for row in result_proxy:
                        doc = Document(
                            id=row[0],
                            content=row[1],
                            metadata=row[2],
                            embedding=None,
                        )
                        query_result.append((doc, float(row[3])))
                    results.append(query_result)

                except Exception as e:
                    logger.warning(
                        f"ParadeDB BM25 failed, falling back to Postgres native FTS: {e}"
                    )
                    try:
                        sql_fallback = text(f"""
                            SELECT id, text, metadata_, ts_rank(to_tsvector('english', text), plainto_tsquery('english', :q)) as score
                            FROM {table_name}
                            WHERE to_tsvector('english', text) @@ plainto_tsquery('english', :q)
                            ORDER BY score DESC
                            LIMIT :k
                        """)  # nosec B608
                        result_proxy = connection.execute(
                            sql_fallback, {"q": query, "k": n_results}
                        )
                        query_result = []
                        for row in result_proxy:
                            doc = Document(
                                id=row[0],
                                content=row[1],
                                metadata=row[2],
                                embedding=None,
                            )
                            query_result.append((doc, float(row[3])))
                        results.append(query_result)
                    except Exception as e2:
                        logger.error(f"Text search failed: {e2}")
                        results.append([])

        return results
