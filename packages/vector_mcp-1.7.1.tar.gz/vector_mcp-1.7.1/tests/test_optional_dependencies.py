import sys

sys.modules["llama_index.embeddings.huggingface"] = None  # type: ignore
sys.modules["llama_index.vector_stores.postgres"] = None  # type: ignore
sys.modules["qdrant_client"] = None  # type: ignore
sys.modules["llama_index.vector_stores.qdrant"] = None  # type: ignore

print("Checking vector_mcp.vector_mcp import...")
try:

    print("Success: vector_mcp.vector_mcp imported.")
except Exception as e:
    print(f"Failed: vector_mcp.vector_mcp import raised {e}")
    sys.exit(1)

print("Checking vector_mcp.retriever import...")
try:

    print("Success: vector_mcp.retriever imported.")
except Exception as e:
    print(f"Failed: vector_mcp.retriever import raised {e}")
    sys.exit(1)

print("All chain checks passed.")
