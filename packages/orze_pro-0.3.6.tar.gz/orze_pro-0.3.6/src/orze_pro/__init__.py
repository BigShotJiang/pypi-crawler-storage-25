"""orze-pro — autopilot for GPU experiments."""
__version__ = "0.3.5"

from orze_pro.license import is_licensed, license_info, check_license
