# Changelog

All notable changes to this project will be documented in this file.

## [0.2.4] - 2026-04-10

### Documentation

- update CHANGELOG.md for v0.2.3

### Fixed

- expand ~ in data_dir config path + show server status in `rtfm status`
- replace full source= line for -bin wheel URL
- retry PyPI wheel URL lookup, disable fail-fast for AUR matrix
## [0.2.3] - 2026-04-09

### Added

- async ingest pipeline with multiprocess embedding

### Documentation

- update CHANGELOG.md for v0.2.2

### Fixed

- skip per-framework clear when clear_all already ran on rebuild
- run storage writes in thread to avoid blocking event loop
- limit concurrent embedding sources via semaphore
- single Ctrl+C exits immediately without hanging
- suppress worker traceback spam on Ctrl+C
- use absolute SSH paths and accept-new for Arch container

### Miscellaneous

- bump version to 0.2.3
## [0.2.2] - 2026-04-09

### Documentation

- update CHANGELOG.md for v0.2.1

### Fixed

- VACUUM after remove, add hidden nuke command
- run AUR updates in Arch container with namcap validation
- resolve hash-based PyPI wheel URL for -bin package

### Miscellaneous

- bump version to 0.2.2
## [0.2.1] - 2026-04-09

### Documentation

- update CHANGELOG.md for v0.2.0

### Fixed

- remove broken sed on PKGBUILD source URLs

### Miscellaneous

- bump version to 0.2.1
## [0.2.0] - 2026-04-09

### CI

- add git-cliff changelog generation to release pipeline

### Miscellaneous

- bump version to 0.2.0

### Other

- Add systemd user service, pacman hook, and AUR packaging improvements
- Add type-dominance and template-stub penalties to health score
- Auto-update python-chromadb-bin AUR package weekly
- Add badges and LICENSE file
- Update all 3 AUR packages on release (stable, bin, git)
- Auto-update AUR package on release
- Fix install instructions: use PyPI package name
## [0.1.1] - 2026-04-09

### Other

- Add PyPI metadata: readme, urls, classifiers, keywords
## [0.1.0] - 2026-04-09

### Other

- Switch PyPI publish to Trusted Publisher (no token needed)
- Rename to agent-rtfm, add CI + release workflows
- Remove .claude and issues from repo, add to .gitignore
- Update README for v0.1.0 — agent-first CLI, doc-system parsers, health score
- Initial commit — rtfm v0.1.0

