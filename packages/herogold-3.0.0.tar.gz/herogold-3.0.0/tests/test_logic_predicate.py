from herogold.logic.predicate import Predicate, predicate


def test_predicate_call_and_repr() -> None:
    def is_even(n: int) -> bool:
        return n % 2 == 0

    p = Predicate(is_even, 4)
    assert p() is True
    r = repr(p)
    assert "Predicate(" in r
    assert "is_even" in r


def test_predicate_combinators_and_not() -> None:
    p_true = Predicate(lambda: True)
    p_false = Predicate(lambda: False)

    assert (p_true & p_true)() is True
    assert (p_true & p_false)() is False
    assert (p_true | p_false)() is True
    assert (~p_true)() is False

def test_predicate_decorator_only_args() -> None:
    @predicate(5, 6, threshold=10)
    def sum_greater_than(x: int, y: int, threshold: int = 10) -> bool:
        return (x + y) > threshold

    # decorator returns a factory that when called returns a Predicate
    p = sum_greater_than()
    assert isinstance(p, Predicate)
    assert p() is True

def test_predicate_decorator_no_args_accepts_required_arguments() -> None:
    @predicate()
    def requires_x(x: int, y: int = 0) -> bool:
        return x > y

    # decorator with no outer args should still return a factory
    # that accepts the required positional argument(s).
    p = requires_x(2)
    assert isinstance(p, Predicate)
    assert p() is True


def test_predicate_decorator_merges_args_kwargs() -> None:
    @predicate(2)
    def greater_than(x: int, y: int = 0) -> bool:
        return x > y

    # decorator returns a factory that when called returns a Predicate
    p = greater_than(1)
    assert isinstance(p, Predicate)
    # args merged: earlier 2 then 1 -> function receives (2, 1)
    assert p() is True

def test_combining_predicates() -> None:
    p1 = Predicate(lambda: True)
    p2 = Predicate(lambda: False)

    p_and = p1 & p2
    p_or = p1 | p2
    p_not = ~p2

    assert isinstance(p_and, Predicate)
    assert isinstance(p_or, Predicate)
    assert isinstance(p_not, Predicate)

    assert p_and() is False
    assert p_or() is True
    assert p_not() is True

def test_combining_predicate_wrappers() -> None:
    @predicate(3)
    def greater_than(x: int, y: int = 0) -> bool:
        return x > y

    p1 = greater_than(2)  # 3 > 2 -> True
    p2 = greater_than(4)  # 3 > 4 -> False

    p_and = p1 & p2
    p_or = p1 | p2
    p_not = ~p2

    assert isinstance(p_and, Predicate)
    assert isinstance(p_or, Predicate)
    assert isinstance(p_not, Predicate)

    assert p_and() is False
    assert p_or() is True
    assert p_not() is True
