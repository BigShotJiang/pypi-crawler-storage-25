"""Curses rendering engine — the only file that touches curses."""
from __future__ import annotations
import curses
from dataclasses import dataclass, field
from notispf import __version__


# Custom color IDs (above the 8 standard colors)
_COLOR_DARK_OLIVE = 20  # #2d4a1e

# Color pair IDs
_CP_STATUS   = 1   # status bar
_CP_PREFIX   = 2   # prefix column (line numbers)
_CP_SEP      = 3   # separator between prefix and text
_CP_TEXT     = 4   # normal text
_CP_MODIFIED = 5   # modified-line indicator in prefix
_CP_MSG      = 6   # message line
_CP_CMD      = 7   # command input line
_CP_RULER    = 9   # column ruler
_CP_HIGHLIGHT = 10  # found pattern highlight
_CP_FKEY     = 11  # function key bar


@dataclass
class ViewState:
    top_line: int               # index of first visible line
    cursor_line: int            # absolute buffer line index
    cursor_col: int             # column within the text area
    screen_rows: int
    screen_cols: int
    pending_prefixes: dict[int, str] = field(default_factory=dict)
    open_block_line: int | None = None
    open_block_cmd: str = ""
    message: str = ""
    command_input: str = ""
    command_mode: bool = False  # True when cursor is in command line
    show_command: bool = True   # True when command bar row is visible
    prefix_mode: bool = False   # True when cursor is in prefix column
    prefix_input: str = ""      # what user has typed in prefix column so far
    show_cols: bool = False     # True when column ruler is visible
    col_offset: int = 0        # horizontal scroll offset (columns shifted left)
    highlight_pattern: str = "" # pattern to highlight (empty = none)
    help_mode: bool = False     # True when help screen is visible
    help_scroll: int = 0        # top line of help screen
    hex_mode: bool = False      # True when HEX ON is active


# Layout constants
PREFIX_WIDTH = 6
SEP_WIDTH = 1                   # the "|" separator
TEXT_OFFSET = PREFIX_WIDTH + SEP_WIDTH

# Sentinel indices — virtual rows that bracket the real buffer
TOP_SENTINEL = -1   # row above line 0  (******* / TOP OF DATA)
BOT_SENTINEL = -2   # row below last line (******* / BOTTOM OF DATA)


class Display:
    def __init__(self, stdscr):
        self.stdscr = stdscr
        self._init_curses()

    def _init_curses(self):
        curses.curs_set(1)
        curses.start_color()
        curses.use_default_colors()

        if curses.can_change_color():
            curses.init_color(_COLOR_DARK_OLIVE, 176, 290, 118)
            cmd_bg = _COLOR_DARK_OLIVE
        else:
            cmd_bg = curses.COLOR_GREEN

        curses.init_pair(_CP_STATUS,   curses.COLOR_BLACK,  curses.COLOR_CYAN)
        curses.init_pair(_CP_PREFIX,   curses.COLOR_CYAN,   -1)
        curses.init_pair(_CP_SEP,      curses.COLOR_CYAN,   -1)
        curses.init_pair(_CP_TEXT,     -1,                  -1)
        curses.init_pair(_CP_MODIFIED, curses.COLOR_YELLOW, -1)
        curses.init_pair(_CP_MSG,      curses.COLOR_BLACK,  curses.COLOR_YELLOW)
        curses.init_pair(_CP_CMD,      curses.COLOR_WHITE,  cmd_bg)
        curses.init_pair(_CP_RULER,    curses.COLOR_BLACK,  curses.COLOR_WHITE)
        curses.init_pair(_CP_HIGHLIGHT, curses.COLOR_BLACK,  curses.COLOR_YELLOW)
        curses.init_pair(_CP_FKEY,     curses.COLOR_BLACK,  curses.COLOR_WHITE)

        self.stdscr.keypad(True)

    _FKEY_ITEMS = [
        ("F1",  "HELP"),
        ("F3",  "SAVE"),
        ("F5",  "RFIND"),
        ("F6",  "CMD"),
        ("F7",  "UP"),
        ("F8",  "DOWN"),
        ("F10", "LEFT"),
        ("F11", "RIGHT"),
        ("F12", "QUIT"),
    ]

    def render(self, buffer, prefix_area, vs: ViewState) -> None:
        self.stdscr.erase()
        rows, cols = self.stdscr.getmaxyx()
        vs.screen_rows = rows
        vs.screen_cols = cols

        self._render_status(buffer, vs, cols)
        if vs.help_mode:
            self._render_help(vs, rows, cols)
            self._render_fkey_bar(rows, cols)
            self._render_bottom(vs, rows, cols)
        else:
            if vs.show_command:
                self._render_command_bar(vs, cols)
            self._render_content(buffer, prefix_area, vs, rows, cols)
            self._render_fkey_bar(rows, cols)
            self._render_bottom(vs, rows, cols)
            self._place_cursor(buffer, vs, rows)

        self.stdscr.noutrefresh()
        curses.doupdate()

    # ------------------------------------------------------------------
    # Status bar (row 0)
    # ------------------------------------------------------------------

    def _render_status(self, buffer, vs: ViewState, cols: int) -> None:
        filename = buffer.filepath or "[No File]"
        modified = " [+]" if buffer.modified else ""
        hex_ind = " [HEX]" if vs.hex_mode else ""
        if vs.cursor_line == TOP_SENTINEL:
            position = "  TOP OF DATA  "
        elif vs.cursor_line == BOT_SENTINEL:
            position = "  BOTTOM OF DATA  "
        else:
            position = f"  Line {vs.cursor_line + 1}/{len(buffer)}  Col {vs.cursor_col + 1}"
        left = f" notispf {__version__}  {filename}{modified}{hex_ind}"
        right = position + "  "
        padding = cols - len(left) - len(right)
        if padding < 0:
            padding = 0
        line = left + " " * padding + right
        self._addstr_clipped(0, 0, line[:cols], curses.color_pair(_CP_STATUS))

    # ------------------------------------------------------------------
    # Content area (rows 1..rows-2)
    # ------------------------------------------------------------------

    @staticmethod
    def build_view(buffer, top_line: int, content_rows: int) -> list:
        """Build a view list from top_line filling up to content_rows entries.

        Each entry is one of:
          ('top',)
          ('line', buf_idx)
          ('fold', start_idx, end_idx, count)
          ('bot',)
        """
        entries = []
        if top_line == 0 and content_rows > 0:
            entries.append(('top',))
        i = top_line
        while i < len(buffer) and len(entries) < content_rows:
            if not buffer.lines[i].excluded:
                entries.append(('line', i))
                i += 1
            else:
                start = i
                while i < len(buffer) and buffer.lines[i].excluded:
                    i += 1
                entries.append(('fold', start, i - 1, i - start))
        if i >= len(buffer) and len(entries) < content_rows:
            entries.append(('bot',))
        return entries

    @staticmethod
    def _build_ruler(width: int) -> str:
        """Build an ISPF-style column ruler for the given text width."""
        ruler = []
        for col in range(1, width + 1):
            if col % 10 == 0:
                ruler.append(str(col // 10 % 10))
            elif col % 5 == 0:
                ruler.append('+')
            else:
                ruler.append('-')
        return ''.join(ruler)

    def _render_command_bar(self, vs: ViewState, cols: int) -> None:
        prompt = "===> "
        content = (prompt + vs.command_input).ljust(cols)[:cols]
        self._addstr_clipped(1, 0, content, curses.color_pair(_CP_CMD))

    def _render_content(self, buffer, prefix_area, vs: ViewState,
                        rows: int, cols: int) -> None:
        cmd_offset = 1 if vs.show_command else 0
        content_rows = rows - 3 - cmd_offset
        first_row = 1 + cmd_offset
        text_width = cols - TEXT_OFFSET
        ruler_offset = 1 if vs.show_cols else 0
        view = self.build_view(buffer, vs.top_line, content_rows - ruler_offset)

        if vs.show_cols:
            ruler = self._build_ruler(vs.col_offset + text_width)
            ruler_slice = ruler[vs.col_offset:vs.col_offset + text_width]
            self._addstr_clipped(first_row, 0, "COLS  ", curses.color_pair(_CP_RULER))
            self._addstr_clipped(first_row, PREFIX_WIDTH, "|", curses.color_pair(_CP_RULER))
            self._addstr_clipped(first_row, TEXT_OFFSET, ruler_slice, curses.color_pair(_CP_RULER))

        for screen_row in range(content_rows - ruler_offset):
            row = screen_row + first_row + ruler_offset

            if screen_row >= len(view):
                # Past end of file
                self._addstr_clipped(row, 0, " " * PREFIX_WIDTH,
                                     curses.color_pair(_CP_PREFIX))
                self._addstr_clipped(row, PREFIX_WIDTH, "|",
                                     curses.color_pair(_CP_SEP))
                self._addstr_clipped(row, TEXT_OFFSET, "~",
                                     curses.color_pair(_CP_PREFIX))
                continue

            entry = view[screen_row]

            if entry[0] in ('top', 'bot'):
                is_top = entry[0] == 'top'
                sentinel_key = TOP_SENTINEL if is_top else BOT_SENTINEL
                label = "- - - TOP OF DATA - - -" if is_top \
                    else "- - - BOTTOM OF DATA - - -"
                pfx = vs.pending_prefixes.get(sentinel_key, "")
                overlay = (pfx + "******"[len(pfx):])[:PREFIX_WIDTH] \
                    if pfx else "******"
                self._addstr_clipped(row, 0, overlay,
                                     curses.color_pair(_CP_MODIFIED))
                self._addstr_clipped(row, PREFIX_WIDTH, "|",
                                     curses.color_pair(_CP_SEP))
                self._addstr_clipped(row, TEXT_OFFSET,
                                     label.ljust(text_width)[:text_width],
                                     curses.color_pair(_CP_MODIFIED))
                continue

            if entry[0] == 'fold':
                _, start_idx, end_idx, count = entry
                # Prefix shows fold count
                fold_prefix = f"-{count}-".center(6)[:6]
                self._addstr_clipped(row, 0, fold_prefix,
                                     curses.color_pair(_CP_MODIFIED))
                self._addstr_clipped(row, PREFIX_WIDTH, "|",
                                     curses.color_pair(_CP_SEP))
                fold_text = f" - - - {count} line(s) not displayed - - -"
                fold_text = fold_text.ljust(text_width)[:text_width]
                self._addstr_clipped(row, TEXT_OFFSET, fold_text,
                                     curses.color_pair(_CP_MODIFIED))
                continue

            # Normal line
            _, buf_idx = entry
            prefix_content = self._get_prefix_display(buf_idx, buf_idx + 1,
                                                       prefix_area, vs)
            prefix_attr = curses.color_pair(_CP_MODIFIED) \
                if buffer.lines[buf_idx].modified \
                else curses.color_pair(_CP_PREFIX)
            self._addstr_clipped(row, 0, f"{prefix_content:>6}"[:6], prefix_attr)

            self._addstr_clipped(row, PREFIX_WIDTH, "|",
                                 curses.color_pair(_CP_SEP))

            text = buffer.lines[buf_idx].text
            base_attr = curses.color_pair(_CP_TEXT)
            self._render_line_text(row, text, vs.col_offset, text_width,
                                   base_attr, vs.highlight_pattern)

    def _render_line_text(self, row: int, text: str, col_offset: int,
                         text_width: int, base_attr: int,
                         highlight_pattern: str) -> None:
        """Render one line's text area, highlighting all pattern occurrences."""
        # Build the padded display string for the visible window
        visible = text[col_offset:col_offset + text_width].ljust(text_width)

        if not highlight_pattern:
            self._addstr_clipped(row, TEXT_OFFSET, visible, base_attr)
            return

        # Find all match spans within the full text, clipped to visible window
        needle = highlight_pattern.lower()
        haystack = text.lower()
        matches: list[tuple[int, int]] = []
        start = 0
        while True:
            idx = haystack.find(needle, start)
            if idx == -1:
                break
            matches.append((idx, idx + len(highlight_pattern)))
            start = idx + len(highlight_pattern)

        if not matches:
            self._addstr_clipped(row, TEXT_OFFSET, visible, base_attr)
            return

        hi_attr = curses.color_pair(_CP_HIGHLIGHT)
        sc = 0  # screen column within text area
        for match_start, match_end in matches:
            # Characters before this match
            before_start = match_start - col_offset
            before_end = match_end - col_offset
            seg_start = max(sc, 0)
            seg_end = min(before_start, text_width)
            if seg_start < seg_end:
                self._addstr_clipped(row, TEXT_OFFSET + seg_start,
                                     visible[seg_start:seg_end], base_attr)
            sc = max(sc, before_start)
            # Highlighted match characters
            hi_start = max(sc, 0)
            hi_end = min(before_end, text_width)
            if hi_start < hi_end:
                self._addstr_clipped(row, TEXT_OFFSET + hi_start,
                                     visible[hi_start:hi_end], hi_attr)
            sc = max(sc, before_end)
            if sc >= text_width:
                break

        # Remaining text after last match
        if sc < text_width:
            self._addstr_clipped(row, TEXT_OFFSET + sc, visible[sc:], base_attr)

    def _get_prefix_display(self, buf_idx: int, line_number: int,
                             prefix_area, vs: ViewState) -> str:
        if buf_idx in vs.pending_prefixes:
            return vs.pending_prefixes[buf_idx][:6]
        if vs.open_block_line == buf_idx:
            return vs.open_block_cmd[:6]
        return prefix_area.get_display_content(buf_idx, line_number)

    # ------------------------------------------------------------------
    # Help screen
    # ------------------------------------------------------------------

    _HELP_LINES = [
        "  notispf — Help                                          Press any key to exit",
        "",
        "  COMMAND LINE  (always shown; F6 to focus or hide)",
        "  " + "─" * 60,
        "  SAVE                   Save file",
        "  FILE                   Save and exit",
        "  CANCEL / QUIT / CAN    Exit without saving",
        "  COPY filename          Copy buffer to another file",
        "  FIND / F  'pat' [col]  Find next occurrence (col = start column)",
        "  CHANGE / C  'o' 'n' [opts]  Change text  (opts: ALL, col, .lbl .lbl)",
        "  EXCLUDE 'pat' [ALL|n]  Exclude matching lines from view",
        "  SHOW ALL               Un-exclude all lines",
        "  DELETE 'pat' [ALL|n]   Delete lines matching pattern",
        "  DELETE X ALL           Delete all excluded lines",
        "  DELETE NX ALL          Delete all non-excluded lines",
        "  UNDO                   Undo last change",
        "  REDO                   Redo last undone change",
        "  HEX ON                 Convert entire file to hex display",
        "  HEX OFF                Convert hex display back to text",
        "  COLS                   Toggle column ruler",
        "  CLEAR / RESET / RES    Clear search/change highlighting",
        "  HELP                   Show this screen",
        "",
        "  PREFIX COMMANDS  (Tab to reach prefix area)",
        "  " + "─" * 60,
        "  D / Dn    Delete line(s)          DD        Delete block",
        "  I / In    Insert blank line(s)",
        "  R / Rn    Repeat line             RR        Repeat block",
        "  C / Cn    Copy line(s)            CC        Copy block",
        "  M / Mn    Move line(s)            MM        Move block",
        "  A         Paste after this line",
        "  B         Paste before this line",
        "  O / On    Overlay clipboard       OO        Overlay block",
        "  X / Xn    Exclude line(s)         XX        Exclude block",
        "  S / Sn    Show (un-exclude)       SS        Show block",
        "  )n        Indent right n cols     ))n       Indent block right n cols",
        "  (n        Indent left n cols      ((n       Indent block left n cols",
        "  HEX       Replace line with hex   HEXB      Insert hex copy below",
        "  HEXA      Convert hex line to ASCII",
        "  UC / UCn  Uppercase line(s)        LC / LCn  Lowercase line(s)",
        "",
        "  FUNCTION KEYS",
        "  " + "─" * 60,
        "  F1          Help                  F3        Save and exit",
        "  F5          Repeat last FIND",
        "  F6          Focus/hide command bar F12       Exit without saving",
        "  Ctrl+Z      Undo                  Ctrl+Y    Redo",
        "  F7  / PgUp  Scroll up             F8/PgDn   Scroll down",
        "  MAX (or M) + F7  Top of data         MAX + F8  Bottom of data",
        "  F10         Scroll left           F11       Scroll right",
        "  Tab         Move down into prefix  Shift+Tab Move up into prefix",
        "  Tab (cmd)   Go to prefix of line 1  Down (cmd) Return to text",
        "",
        "  NAVIGATION",
        "  " + "─" * 60,
        "  Arrow keys  Move cursor           End / Ctrl-E  End of line",
        "  Left (col 0)  Enter prefix mode   Right (prefix) Return to text",
        "  Home        Focus command bar     Ctrl-A    Start of line",
        "  Up (top line)  Go to command bar  Shift+Tab (top) Go to command bar",
        "",
    ]

    def _render_help(self, vs: ViewState, rows: int, cols: int) -> None:
        content_rows = rows - 3
        lines = self._HELP_LINES
        for screen_row in range(content_rows):
            row = screen_row + 1
            line_idx = vs.help_scroll + screen_row
            if line_idx < len(lines):
                text = lines[line_idx][:cols].ljust(cols)[:cols]
                attr = curses.color_pair(_CP_STATUS) if screen_row == 0 \
                    else curses.color_pair(_CP_TEXT)
                self._addstr_clipped(row, 0, text, attr)
            else:
                self._addstr_clipped(row, 0, " " * cols,
                                     curses.color_pair(_CP_TEXT))

    # ------------------------------------------------------------------
    # Function key bar (second-to-last row)
    # ------------------------------------------------------------------

    def _render_fkey_bar(self, rows: int, cols: int) -> None:
        row = rows - 2
        text = "  ".join(f"{k}-{v}" for k, v in self._FKEY_ITEMS)
        text = text.ljust(cols)[:cols]
        self._addstr_clipped(row, 0, text, curses.color_pair(_CP_FKEY))

    # ------------------------------------------------------------------
    # Bottom row: message or command input
    # ------------------------------------------------------------------

    def _render_bottom(self, vs: ViewState, rows: int, cols: int) -> None:
        row = rows - 1
        msg = vs.message[:cols].ljust(cols)[:cols]
        attr = curses.color_pair(_CP_MSG) if vs.message \
            else curses.color_pair(_CP_TEXT)
        self._addstr_clipped(row, 0, msg, attr)

    # ------------------------------------------------------------------
    # Cursor placement
    # ------------------------------------------------------------------

    def _place_cursor(self, buffer, vs: ViewState, rows: int) -> None:
        cmd_offset    = 1 if vs.show_command else 0
        ruler_offset  = 1 if vs.show_cols else 0
        first_row     = 1 + cmd_offset + ruler_offset
        # Top sentinel occupies one row when top_line == 0
        sentinel_offset = 1 if vs.top_line == 0 else 0

        if vs.command_mode:
            prompt_len = len("===> ")
            col = min(prompt_len + len(vs.command_input), vs.screen_cols - 1)
            try:
                self.stdscr.move(1, col)
            except curses.error:
                pass

        elif vs.prefix_mode:
            if vs.cursor_line == TOP_SENTINEL:
                screen_row = first_row
            elif vs.cursor_line == BOT_SENTINEL:
                content_rows = rows - 3 - cmd_offset - ruler_offset
                view = Display.build_view(buffer, vs.top_line, content_rows)
                pos = next((i for i, e in enumerate(view) if e[0] == 'bot'), -1)
                if pos == -1:
                    return
                screen_row = first_row + pos
            else:
                screen_row = vs.cursor_line - vs.top_line + first_row + sentinel_offset
            screen_col = min(len(vs.prefix_input), PREFIX_WIDTH - 1)
            if 0 < screen_row < rows - 1:
                try:
                    self.stdscr.move(screen_row, screen_col)
                except curses.error:
                    pass

        else:
            if vs.cursor_line < 0:  # on a sentinel — no text cursor
                return
            screen_row = vs.cursor_line - vs.top_line + first_row + sentinel_offset
            screen_col = TEXT_OFFSET + vs.cursor_col - vs.col_offset
            if 0 < screen_row < rows - 1 and TEXT_OFFSET <= screen_col < vs.screen_cols:
                try:
                    self.stdscr.move(screen_row, screen_col)
                except curses.error:
                    pass

    # ------------------------------------------------------------------
    # Helper
    # ------------------------------------------------------------------

    def _addstr_clipped(self, row: int, col: int, text: str,
                        attr: int = 0) -> None:
        rows, cols = self.stdscr.getmaxyx()
        if row < 0 or row >= rows or col >= cols:
            return
        available = cols - col
        if available <= 0:
            return
        text = text[:available]
        try:
            self.stdscr.addstr(row, col, text, attr)
        except curses.error:
            pass   # writing to last cell of last row raises harmlessly

    def close(self) -> None:
        pass  # curses.wrapper handles endwin() on exit
