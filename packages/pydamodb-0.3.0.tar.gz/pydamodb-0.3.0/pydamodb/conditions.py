"""DynamoDB condition expression primitives.

This module defines small, composable objects that represent DynamoDB
condition expressions. These are consumed by the expression builder to
produce a DynamoDB `ConditionExpression` string.
"""

from __future__ import annotations

from typing import Any, ClassVar, Literal

from pydamodb.exceptions import InsufficientConditionsError


class Condition:
    """Base class for all DynamoDB condition expressions.

    Provides operator overloading for combining conditions:
    - & (__and__): Combine with AND
    - | (__or__): Combine with OR
    - ~ (__invert__): Negate with NOT

    Example:
        condition1 = User.attr("age") > 18
        condition2 = User.attr("status") == "active"
        combined = condition1 & condition2  # AND
        negated = ~condition1  # NOT

    """

    def __and__(self, other: Condition) -> And:
        return And(self, other)

    def __or__(self, other: Condition) -> Or:
        return Or(self, other)

    def __invert__(self) -> Not:
        return Not(self)


class ComparisonCondition(Condition):
    """Base class for comparison conditions."""

    operator: ClassVar[Literal["=", "<>", "<", "<=", ">", ">="]]

    def __init__(self, field: str, value: Any) -> None:
        self.field = field
        self.value = value

    def __repr__(self) -> str:
        return f"{self.field} {self.operator} {self.value!r}"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ComparisonCondition):
            return NotImplemented
        return (
            self.field == other.field
            and self.operator == other.operator
            and self.value == other.value
        )


class Eq(ComparisonCondition):
    """Equality condition: field = value"""

    operator = "="


class Ne(ComparisonCondition):
    """Not equal condition: field <> value"""

    operator = "<>"


class Lt(ComparisonCondition):
    """Less than condition: field < value"""

    operator = "<"


class Lte(ComparisonCondition):
    """Less than or equal condition: field <= value"""

    operator = "<="


class Gt(ComparisonCondition):
    """Greater than condition: field > value"""

    operator = ">"


class Gte(ComparisonCondition):
    """Greater than or equal condition: field >= value"""

    operator = ">="


class Between(Condition):
    """Between condition: field BETWEEN low AND high."""

    def __init__(self, field: str, low: Any, high: Any) -> None:
        self.field = field
        self.low = low
        self.high = high

    def __repr__(self) -> str:
        return f"{self.field} BETWEEN {self.low!r} AND {self.high!r}"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Between):
            return NotImplemented
        return self.field == other.field and self.low == other.low and self.high == other.high


class BeginsWith(Condition):
    """Begins with condition: begins_with(field, prefix).

    Only applicable to string fields.
    """

    def __init__(self, field: str, prefix: str) -> None:
        self.field = field
        self.prefix = prefix

    def __repr__(self) -> str:
        return f"begins_with({self.field}, {self.prefix!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, BeginsWith):
            return NotImplemented
        return self.field == other.field and self.prefix == other.prefix


class Contains(Condition):
    """Contains condition: contains(field, value).

    For strings: checks if the string contains the substring.
    For sets/lists: checks if the collection contains the element.
    """

    def __init__(self, field: str, value: Any) -> None:
        self.field = field
        self.value = value

    def __repr__(self) -> str:
        return f"contains({self.field}, {self.value!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Contains):
            return NotImplemented
        return self.field == other.field and self.value == other.value


class In(Condition):
    """IN condition: field IN (value1, value2, ...).

    Checks if the field value matches any value in the provided list.
    """

    def __init__(self, field: str, values: list[Any]) -> None:
        self.field = field
        self.values = values

    def __repr__(self) -> str:
        values_repr = ", ".join(repr(v) for v in self.values)
        return f"{self.field} IN ({values_repr})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, In):
            return NotImplemented
        return self.field == other.field and self.values == other.values


class SizeCondition(Condition):
    """Base class for size() function conditions.

    Used internally to represent size(field) comparisons.
    """

    operator: ClassVar[Literal["=", "<>", "<", "<=", ">", ">="]]

    def __init__(self, field: str, value: int) -> None:
        self.field = field
        self.value = value

    def __repr__(self) -> str:
        return f"size({self.field}) {self.operator} {self.value}"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, SizeCondition):
            return NotImplemented
        return (
            self.field == other.field
            and self.operator == other.operator
            and self.value == other.value
        )


class SizeEq(SizeCondition):
    """Size equals condition: size(field) = value"""

    operator = "="


class SizeNe(SizeCondition):
    """Size not equals condition: size(field) <> value"""

    operator = "<>"


class SizeLt(SizeCondition):
    """Size less than condition: size(field) < value"""

    operator = "<"


class SizeLte(SizeCondition):
    """Size less than or equals condition: size(field) <= value"""

    operator = "<="


class SizeGt(SizeCondition):
    """Size greater than condition: size(field) > value"""

    operator = ">"


class SizeGte(SizeCondition):
    """Size greater than or equals condition: size(field) >= value"""

    operator = ">="


class Size:
    """Size function wrapper for building size(field) conditions.

    The size() function in DynamoDB returns the size of an attribute:
    - For strings: character count
    - For binary: byte count
    - For lists: element count
    - For maps: attribute count
    - For sets: element count

    Use comparison operators on Size instances to create size conditions.

    Example:
        Check if a list has elements:
        User.attr("tags").size() > 0

        Validate string length:
        User.attr("name").size() >= 3

        Check map size:
        User.attr("metadata").size() < 10

    """

    def __init__(self, field: str) -> None:
        self.field = field

    def __eq__(self, other: int) -> SizeEq:  # ty: ignore[invalid-method-override]
        return SizeEq(field=self.field, value=other)

    def __ne__(self, other: int) -> SizeNe:  # ty: ignore[invalid-method-override]
        return SizeNe(field=self.field, value=other)

    def __lt__(self, other: int) -> SizeLt:
        return SizeLt(field=self.field, value=other)

    def __le__(self, other: int) -> SizeLte:
        return SizeLte(field=self.field, value=other)

    def __gt__(self, other: int) -> SizeGt:
        return SizeGt(field=self.field, value=other)

    def __ge__(self, other: int) -> SizeGte:
        return SizeGte(field=self.field, value=other)


class AttributeExists(Condition):
    """Attribute exists condition: attribute_exists(field)."""

    def __init__(self, field: str) -> None:
        self.field = field

    def __repr__(self) -> str:
        return f"attribute_exists({self.field})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, AttributeExists):
            return NotImplemented
        return self.field == other.field


class AttributeNotExists(Condition):
    """Attribute not exists condition: attribute_not_exists(field)."""

    def __init__(self, field: str) -> None:
        self.field = field

    def __repr__(self) -> str:
        return f"attribute_not_exists({self.field})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, AttributeNotExists):
            return NotImplemented
        return self.field == other.field


class And(Condition):
    """Logical AND of two or more conditions.

    All conditions must be satisfied for the overall condition to be true.
    Can be created using the & operator on condition objects or by calling And() directly.

    Args:
        *conditions: Two or more condition objects.

    Raises:
        InsufficientConditionsError: If fewer than two conditions are provided.

    Example:
        Using operator:
        condition = (User.attr("age") > 18) & (User.attr("status") == "active")

        Using constructor:
        condition = And(
            User.attr("age") > 18,
            User.attr("status") == "active",
            User.attr("verified") == True,
        )

    """

    def __init__(self, *conditions: Condition) -> None:
        if len(conditions) < 2:
            raise InsufficientConditionsError(operator="And", count=len(conditions))
        self.conditions = conditions

    def __repr__(self) -> str:
        return " AND ".join(f"({c!r})" for c in self.conditions)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, And):
            return NotImplemented
        return self.conditions == other.conditions

    def __and__(self, other: Condition) -> And:
        if isinstance(other, And):
            return And(*self.conditions, *other.conditions)
        return And(*self.conditions, other)


class Or(Condition):
    """Logical OR of two or more conditions.

    At least one condition must be satisfied for the overall condition to be true.
    Can be created using the | operator on condition objects or by calling Or() directly.

    Args:
        *conditions: Two or more condition objects.

    Raises:
        InsufficientConditionsError: If fewer than two conditions are provided.

    Example:
        Using operator:
        condition = (User.attr("role") == "admin") | (User.attr("role") == "moderator")

        Using constructor:
        condition = Or(
            User.attr("status") == "active",
            User.attr("status") == "pending",
            User.attr("status") == "trial",
        )

    """

    def __init__(self, *conditions: Condition) -> None:
        if len(conditions) < 2:
            raise InsufficientConditionsError(operator="Or", count=len(conditions))
        self.conditions = conditions

    def __repr__(self) -> str:
        return " OR ".join(f"({c!r})" for c in self.conditions)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Or):
            return NotImplemented
        return self.conditions == other.conditions

    def __or__(self, other: Condition) -> Or:
        if isinstance(other, Or):
            return Or(*self.conditions, *other.conditions)
        return Or(*self.conditions, other)


class Not(Condition):
    """Logical NOT of a single condition.

    Negates a condition - the result is true when the inner condition is false.
    Can be created using the ~ operator on condition objects or by calling Not() directly.

    Args:
        condition: The condition to negate.

    Example:
        Using operator:
        condition = ~(User.attr("status") == "deleted")

        Using constructor:
        condition = Not(User.attr("email").exists())

    """

    def __init__(self, condition: Condition) -> None:
        self.condition = condition

    def __repr__(self) -> str:
        return f"NOT ({self.condition!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Not):
            return NotImplemented
        return self.condition == other.condition


__all__ = [
    "And",
    "AttributeExists",
    "AttributeNotExists",
    "BeginsWith",
    "Between",
    "ComparisonCondition",
    "Condition",
    "Contains",
    "Eq",
    "Gt",
    "Gte",
    "In",
    "Lt",
    "Lte",
    "Ne",
    "Not",
    "Or",
    "Size",
    "SizeCondition",
    "SizeEq",
    "SizeGt",
    "SizeGte",
    "SizeLt",
    "SizeLte",
    "SizeNe",
]
