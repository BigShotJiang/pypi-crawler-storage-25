# suneord

`suneord` is a minimal Python library for creating Discord bots with asyncio.
It is intentionally simple and beginner-friendly.

## Installation

```bash
pip install suneord
```

## Example

```python
from suneord import Bot, Command

bot = Bot(prefix="!", status="dnd", activity="keord 0.1.3.post1")

@bot.event
async def on_ready():
    print("Bot is ready")

@bot.command()
async def ping(ctx):
    await ctx.send("Pong!")

bot.run("TOKEN")
```

## Features (MVP)

- Event registration with `@bot.event`
- Command registration with `@bot.command()`
- Gateway connection (`HELLO`, `IDENTIFY`, `HEARTBEAT`, `DISPATCH`)
- Ready event support
- Message command handling by prefix
- Message sending through Discord REST API using `aiohttp`

## Publish to PyPI

```bash
python -m build
python -m twine upload dist/*
```
