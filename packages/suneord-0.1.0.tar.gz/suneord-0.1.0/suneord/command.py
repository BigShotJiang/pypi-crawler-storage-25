from __future__ import annotations

from dataclasses import dataclass
from typing import Awaitable, Callable


CommandCallback = Callable[..., Awaitable[None]]


@dataclass
class Command:
    """Stores command metadata and callback."""

    name: str
    callback: CommandCallback
