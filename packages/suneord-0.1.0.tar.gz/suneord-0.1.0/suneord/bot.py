from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable

import aiohttp

from .command import Command
from .context import Context
from .gateway import Gateway
from .http import DiscordHTTP


EventCallback = Callable[..., Awaitable[None]]
CommandCallback = Callable[[Context], Awaitable[None]]


class Bot:
    """Minimal Discord bot client."""

    def __init__(self, prefix: str = "!", status: str = "online", activity: str = "suneord") -> None:
        self.prefix = prefix
        self.status = status
        self.activity = activity

        self._events: dict[str, EventCallback] = {}
        self._commands: dict[str, Command] = {}
        self._http: DiscordHTTP | None = None
        self._token = ""

    def event(self, func: EventCallback) -> EventCallback:
        """Register an event callback by function name (e.g. on_ready)."""
        self._events[func.__name__] = func
        return func

    def command(self, name: str | None = None) -> Callable[[CommandCallback], CommandCallback]:
        """Register a command callback."""

        def decorator(func: CommandCallback) -> CommandCallback:
            command_name = (name or func.__name__).lower()
            self._commands[command_name] = Command(name=command_name, callback=func)
            return func

        return decorator

    def run(self, token: str) -> None:
        """Start bot."""
        self._token = token
        asyncio.run(self._start())

    async def _start(self) -> None:
        async with aiohttp.ClientSession() as session:
            self._http = DiscordHTTP(token=self._token, session=session)
            gateway = Gateway(
                token=self._token,
                status=self.status,
                activity=self.activity,
                on_ready=self._on_ready_dispatch,
                on_message=self._on_message_create,
            )
            try:
                await gateway.connect()
            except Exception as error:
                print(f"[Bot] Gateway error: {error}")

    async def _on_ready_dispatch(self, _: dict[str, Any]) -> None:
        callback = self._events.get("on_ready")
        if callback:
            await callback()

    async def _on_message_create(self, message: dict[str, Any]) -> None:
        author = message.get("author", {})
        if author.get("bot"):
            return

        content = str(message.get("content", ""))
        if not content.startswith(self.prefix):
            return

        command_line = content[len(self.prefix) :].strip()
        if not command_line:
            return

        command_name = command_line.split()[0].lower()
        command = self._commands.get(command_name)
        if command is None:
            return

        if self._http is None:
            print("[Bot] HTTP client is not initialized")
            return

        ctx = Context(message=message, http=self._http)
        try:
            await command.callback(ctx)
        except Exception as error:
            print(f"[Bot] Command '{command_name}' failed: {error}")
