from __future__ import annotations

from typing import Any

from .http import DiscordHTTP


class Context:
    """Command execution context."""

    def __init__(self, message: dict[str, Any], http: DiscordHTTP) -> None:
        self.message = message
        self.channel_id = str(message["channel_id"])
        self._http = http

    async def send(self, content: str) -> None:
        await self._http.send_message(self.channel_id, content)
