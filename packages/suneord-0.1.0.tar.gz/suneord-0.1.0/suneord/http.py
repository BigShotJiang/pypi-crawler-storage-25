from __future__ import annotations

from typing import Any

import aiohttp


class DiscordHTTP:
    """Minimal Discord REST API wrapper."""

    BASE_URL = "https://discord.com/api/v10"

    def __init__(self, token: str, session: aiohttp.ClientSession) -> None:
        self.token = token
        self.session = session

    async def send_message(self, channel_id: str, content: str) -> dict[str, Any]:
        url = f"{self.BASE_URL}/channels/{channel_id}/messages"
        headers = {
            "Authorization": f"Bot {self.token}",
            "Content-Type": "application/json",
        }
        payload = {"content": content}

        async with self.session.post(url, json=payload, headers=headers) as response:
            data = await response.json(content_type=None)
            if response.status >= 400:
                print(f"[HTTP] Failed to send message: {response.status} {data}")
            return data
