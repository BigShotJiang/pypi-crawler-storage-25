from __future__ import annotations

import asyncio
from typing import Any


def create_task(coro: Any) -> asyncio.Task[Any]:
    """Create asyncio task with a small safety wrapper."""
    return asyncio.create_task(coro)


def safe_int(value: Any, default: int = 0) -> int:
    """Convert value to int safely."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
