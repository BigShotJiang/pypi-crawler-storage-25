from __future__ import annotations

import asyncio
import json
from typing import Any, Awaitable, Callable

import websockets

from .utils import create_task, safe_int


ReadyHandler = Callable[[dict[str, Any]], Awaitable[None]]
MessageHandler = Callable[[dict[str, Any]], Awaitable[None]]


class Gateway:
    """Minimal Discord Gateway client."""

    GATEWAY_URL = "wss://gateway.discord.gg/?v=10&encoding=json"

    def __init__(
        self,
        token: str,
        status: str,
        activity: str,
        on_ready: ReadyHandler,
        on_message: MessageHandler,
    ) -> None:
        self.token = token
        self.status = status
        self.activity = activity
        self.on_ready = on_ready
        self.on_message = on_message

        self.ws: Any | None = None
        self.sequence: int | None = None
        self.heartbeat_interval = 0.0
        self._heartbeat_task: asyncio.Task[Any] | None = None

    async def connect(self) -> None:
        print("[Gateway] Connecting to Discord Gateway...")
        async with websockets.connect(self.GATEWAY_URL) as websocket:
            self.ws = websocket
            await self._listen()

    async def _listen(self) -> None:
        if self.ws is None:
            return

        async for raw_message in self.ws:
            payload = json.loads(raw_message)
            op = payload.get("op")
            event_name = payload.get("t")
            data = payload.get("d")
            sequence = payload.get("s")

            if sequence is not None:
                self.sequence = safe_int(sequence, default=0)

            if op == 10:
                await self._handle_hello(data)
                continue

            if op == 1:
                await self._send_heartbeat()
                continue

            if op == 11:
                print("[Gateway] HEARTBEAT ACK")
                continue

            if op == 0:
                await self._handle_dispatch(event_name, data)
                continue

    async def _handle_hello(self, data: dict[str, Any]) -> None:
        self.heartbeat_interval = safe_int(data.get("heartbeat_interval"), default=45000) / 1000
        print(f"[Gateway] HELLO received. Heartbeat interval: {self.heartbeat_interval}s")

        await self._identify()
        self._heartbeat_task = create_task(self._heartbeat_loop())

    async def _identify(self) -> None:
        if self.ws is None:
            return

        payload = {
            "op": 2,
            "d": {
                "token": self.token,
                "intents": (1 << 9) | (1 << 12) | (1 << 15),
                "properties": {
                    "$os": "windows",
                    "$browser": "suneord",
                    "$device": "suneord",
                },
                "presence": {
                    "status": self.status,
                    "activities": [{"name": self.activity, "type": 0}],
                    "afk": False,
                    "since": None,
                },
            },
        }
        await self.ws.send(json.dumps(payload))
        print("[Gateway] IDENTIFY sent")

    async def _heartbeat_loop(self) -> None:
        while True:
            await asyncio.sleep(self.heartbeat_interval)
            await self._send_heartbeat()

    async def _send_heartbeat(self) -> None:
        if self.ws is None:
            return

        payload = {"op": 1, "d": self.sequence}
        await self.ws.send(json.dumps(payload))
        print("[Gateway] HEARTBEAT sent")

    async def _handle_dispatch(self, event_name: str | None, data: dict[str, Any]) -> None:
        if event_name == "READY":
            print("[Gateway] READY event")
            await self.on_ready(data)
            return

        if event_name == "MESSAGE_CREATE":
            await self.on_message(data)
