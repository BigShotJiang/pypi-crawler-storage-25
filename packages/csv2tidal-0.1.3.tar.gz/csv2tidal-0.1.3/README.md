<p align="center">
  <img src="https://img.shields.io/pypi/v/csv2tidal?style=for-the-badge&logo=pypi&logoColor=white" alt="PyPI Version">
  <img src="https://img.shields.io/pypi/pyversions/csv2tidal?style=for-the-badge&logo=python&logoColor=white" alt="Python Versions">
  <img src="https://img.shields.io/pypi/l/csv2tidal?style=for-the-badge&color=97CA00" alt="License">
</p>

<h1 align="center">csv2tidal</h1>

<p align="center"><code>csv2tidal</code> is a standalone CLI for transferring Exportify CSV playlists and similar Spotify-style exports to TIDAL with two matching modes.</p>

## Transfer Modes

- `Fast`: quicker matching for large playlist transfers
- `Accurate`: stronger album and version-aware matching for safer results

## Features

- Import Exportify `.csv` files directly
- Windows file picker in interactive mode
- Match using title, artists, album, ISRC, year, and duration
- Penalize compilation, acoustic, remix, live, and other mismatched editions
- Handle duplicate TIDAL quality editions intelligently
- Transfer accepted matches to TIDAL favorites or a new TIDAL playlist
- Optional JSON report output controlled from settings
- Quiet `Ctrl+C` handling and cancel support during matching

## Requirements

Before using `csv2tidal`, make sure you have:

- Python 3.9 or newer
- a TIDAL account
- an Exportify-format CSV playlist export
- access to [Exportify](https://exportify.app/) to generate the CSV file

## Documentation

- [Usage Guide](docs/USAGE.md)
- [FAQ](docs/FAQ.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)
- [Tips & Tricks](docs/TIPS.md)

## Install

```bash
pip install csv2tidal
```

For local development:

```bash
pip install -e .
```

## Usage

Launch the interactive app:

```bash
csv2tidal
```

> [!NOTE]
> Interactive defaults:
> - pressing `Enter` at the transfer destination prompt selects `Playlist`
> - the CSV filename is used as the default playlist name
> - JSON report creation depends on the saved `Generate JSON report?` setting

## Notes

> [!TIP]
> - Exportify CSV from [exportify.app](https://exportify.app/) is the primary supported input format.
> - The CSV filename is used as the fallback collection or playlist name when the file itself does not include one.
> - TIDAL login uses OAuth in your browser and stores a local session for reuse.
> - Existing `tidal-transfer` settings and session data are migrated automatically to the new `csv2tidal` app-data folder on first run.
