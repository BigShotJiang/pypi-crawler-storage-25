"""Apple Notes MCP server."""
