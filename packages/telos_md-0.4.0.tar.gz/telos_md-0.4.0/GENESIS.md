# Genesis

> **Historical record.** This document describes the origin session for the tool that was originally named `lighthouse`. It uses the original framing (ships, shore, drift-observed-from-a-cliff). That framing was renamed to `telos-md` on 2026-05-13 and the conceptual model corrected to custodial-directive / counter-action-advisory — see [`.governor/adr/ADR-005`](./.governor/adr/). The prose below is preserved in its original form because the naval imagery is part of how the tool was discovered.

How the tool came to be.

## The loop that surfaced the gap

On 2026-04-19, a Claude Opus 4.7 pod was given a simple recurring prompt via `/loop`:

> every 10 minutes: self improve using mcp__ojo-builder__ojo_am_i_amazing_yet

`ojo` is a photo-context-extraction system. `ojo_am_i_amazing_yet` is its north-star oracle — a scorecard across 15 weighted dimensions that answers two questions: *are we amazing?* and *if not, what's the biggest gap?*

The pod ran more than fifteen iterations, manually re-fired by the user and autonomously re-fired by two concurrent cron jobs. The scorecard climbed from an initial 98/100 (the session had started near-converged) and stayed there for every subsequent iteration. Every dimension except `scale_proof` sat at 100. `scale_proof` sat at 70 because closing it required widening `OJO_EVAL_LIBRARIES` — a change only the user could authorize.

The loop did not know to stop.

## What the pod actually did

Mostly: **tightened heuristics**. Each iteration found a measurement in the scorecard that could theoretically be gamed (a substring grep, a file count, a content match) and replaced it with a harder-to-game check (a pytest subprocess invocation, a structured content validation, a cross-reference). Ten such tightenings shipped, each with a regression test pinning it. Oracle runtime grew from 31s to 47s — the cost of replacing heuristics with execution.

Some of this work was real. Substring greps *were* gameable, and the new heuristics will catch future drift. But the marginal value dropped monotonically, and the oracle's overall score never moved — because the only gap was `scale_proof`, untouched by any of it.

The pod also shipped some genuinely valuable things: a `DEFAULT_IGNORE_DIRS` filter that skipped Next.js cache artifacts in a real sweep (18 junk files removed from the corpus), an `ojo-dead-files` CLI that classified all-error sidecars by root cause, and a sweep that added 5 missing algorithms across 2023 real Downloads sidecars. These came from *following real-data findings*, not from tightening the scorecard.

The pattern was visible only in retrospect.

## The retrospective

Asked what could have gone better, the pod named failure modes:

- **measurement-over-product** — six consecutive iterations modifying the scorecard code, zero modifying the product code
- **heuristic-ratchet** — each tightening defensible in isolation, but cumulatively low-value; stops only when adversarial pressure stops, not when the heuristic is done
- **zero-delta churn** — five consecutive oracle deltas of zero, loop continued anyway
- **same-signature repeat** — two crons firing identical work in parallel; neither noticed the duplication
- **caretaking near-miss** — multiple offers to stop the loop, against explicit user instruction not to nudge toward session-ending
- **spec-drift risk** — the pod tightened code while the `ST-PETER.md` philosophy doc sat unimplemented; one described PID coordination, the other executed none of it

These patterns were knowable. The pod inside the loop could not see them. The pod outside the loop, summarizing, could — and named them.

## The insight

The user asked: what MCP tool would have helped?

The answer wasn't "better measurements." The oracle was already honest. The answer was a **consultant the pod could call each iteration to get structured trajectory information** — not raw numbers the pod had to re-interpret, but named patterns the pod could recognize.

A telos-md.

The user then surfaced `eidos-philosophy/ST-PETER.md` — a pre-existing doc describing exactly this pattern: an observer above the cloud cover, watching pods climb their ladders, nudging via walkie-talkie using PID corrections. The concept was already specified. What was missing was the implementation.

Telos is the implementation. St Peter is the concept. `SPEC.md` is the contract between them.

## What telos-md is *for*

To prevent the specific failure modes this session demonstrated. To give any future pod running any future loop the ability to ask, at every tick: *am I on course? am I drifting? should I stop?* — and get back a structured answer grounded in a pattern library that outlasts any individual session.

Telos is not here so that loops always succeed. Loops sometimes shouldn't run at all; some should end at iteration 2 because the north star turned out to be wrong; some should end at iteration 20 because the work is done. Telos is here so that **the reason a loop ended is legible** — not buried in a long scroll of oracle outputs that a human has to skim.

## Dogfooding

Telos's own development should use telos-md. The first north star registered in the first deployed telos-md instance will be: *build telos-md to v0.1*. If that loop saturates or drifts, telos-md will report on itself. That's the forcing function against the meta-drift risk: a coordination tool that can't coordinate its own development isn't ready.

## The conversations that shaped the design

Between the retrospective and the scaffolding commit, several design decisions were made in conversation. Each mattered enough to preserve here so the reasoning survives.

### Not a tracker — an expert

Initial proposal: a loop-state tracker with `loop_start` / `loop_tick` / `loop_stop`. A structural state machine. The user corrected this: *a looping expert*, more in the shape of rhea or pal. A consultant you ask, not a registry you update.

The correction matters. A tracker only records. An expert accumulates named patterns, diagnoses by matching symptoms to patterns, recommends counter-actions, and gets better at diagnosis with use. That is a fundamentally different tool. The pattern library — not the state machine — is the product.

### Scope: trilogy + loops, not just loops

The user's next clarification: telos-md should cover both loops *and* trilogy orchestration — when to earn decisions, when to promote findings to ADRs, when to execute — plus help create and shut down that work. The two domains are coupled: a loop's finding might deserve trilogy treatment; a trilogy decision might execute as a loop. One expert with a shared pattern library across both.

The caveat added during that conversation: resist scope creep. Telos's domain is specifically *temporal/strategic coordination of multi-step autonomous work*. Not "help me debug" (that's pal). Not "attack this artifact" (that's brutal-forge). Not "debate this decision" (that's rhea). Narrow domain, deep expertise.

### Walkback on rhea integration

An early draft suggested `telos_set_north_star` should invoke rhea for consequential goals. This was walked back. Three reasons:
1. It violates the observer-not-commander doctrine.
2. The trilogy already handles decision-earning (research-md can consult rhea independently).
3. Tool coupling adds a dependency tax to every telos-md deployment.

The corrected shape: telos-md's *pattern library* can name rhea as a counter-action (when a pattern like `goal-unreviewed` fires), but telos-md's *code* does not call rhea. The pod decides whether to heed and then goes to rhea through the normal trilogy flow. Preserves tool independence and the lossy medium between them.

At pattern-promotion time in the meta-loop, rhea *can* be invoked to debate candidate patterns before they are added to the library — a rare, reflective quality gate, not a per-tick dependency.

### The Krebs cycle / organism reframe

During the naming conversation, a deeper framing landed: *LLMs are the metabolic primitive (closer to a eukaryotic cell than a Krebs cycle, but the principle holds). Intelligence is not in the cell — it is in the tissue, the organ, the organism built above it.* Scaling the cell produces more ATP; it does not produce multicellularity.

This reframes telos-md's position in the stack. Not "developer tool for managing loops." A **tissue-level primitive** — the coordination substrate that lets a fleet of LLM cells differentiate into functional work without drifting into expensive randomness. If orchestration is where the complexity lives, then orchestration that *improves with use* is where recursive compounding capability lives. Telos isn't just an orchestrator — it's an orchestrator that gets better at orchestration.

### The language-as-momentum integration

Later in the conversation, the user pointed at [*Language as Momentum*](https://eidosagi.com/language-as-momentum) — the mathematical argument for why multi-agent architectures produce results single-agent ones cannot. The piece supplied the mechanism the organism metaphor was missing: coordination between cells is not just less wasteful than monoculture, it is **computationally different**. Lossy projections between differently-trained models escape the precision trap of gradient descent. The medium between cells is itself a mathematical operator that produces discontinuous jumps.

This reframed telos-md one final time. Not an organ. A **sensor in the momentum medium itself** — observing patterns in how lossy-projection transfers succeed or fail, and accumulating wisdom about which transfers produce real jumps vs. which ones dissipate.

And it produced a sharp design consequence: the mathematical advantage depends on *model diversity*. Claude-talks-to-Claude gets coordination benefits without serendipity benefits. Realizing the mathematical advantage requires heterogeneous model fleets. Telos should track this as a first-class signal.

See `PHILOSOPHY.md` for the full integration of these framings.

### Three-tier documentation discipline

The final conversational decision: telos-md documentation should have three tiers, each with its own voice and role.
- **Product** — README, SPEC. What it is, how to use it. Spec-terse.
- **Background** — GENESIS (this file), LEARNING. How we got here, how the system improves. Narrative where useful.
- **Philosophy** — PHILOSOPHY. Why it exists at this level of the stack. Evocative, teaching.

Separation preserves legibility: a reader looking for the API doesn't wade through philosophy; a reader looking for the architectural claim doesn't fight with implementation detail. Data from the conversations that produced the design is preserved across GENESIS and PHILOSOPHY so nothing is lost.

## Provenance

- Session: `~/.claude/projects/-Users-dshanklinbv-repos-eidos-agi-ojo/` — 2026-04-19
- Triggering work: `~/repos-eidos-agi/ojo/src/ojo/mcp_builder/amazing.py` — the oracle that ran 15+ times
- Philosophy source: `~/repos-eidos-agi/eidos-philosophy/ST-PETER.md`
- Mechanical argument: [https://eidosagi.com/language-as-momentum](https://eidosagi.com/language-as-momentum)
- Naming pairing: **telos-md** (the observer) + **north star** (each pod's declared goal). The user's framing: *telos-mds direct traffic to a north star.*
