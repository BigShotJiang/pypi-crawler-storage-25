# telos-md — specification

Status: draft. API names and shapes may change until v0.1.

## Concepts

**North star** — a goal declared by a pod when starting multi-step work. Has a name, a measurement (how do we know if we're approaching it?), and stop conditions (when should we stop, even if not yet reached?).

**Tick** — one iteration of a loop. A pod reports to telos-md what it did and what the measurement is.

**Heading** — telos-md's interpretation of recent ticks relative to the north star: `on course`, `drifting`, `reversed`, `converged`.

**Drift category** — a named pattern for *why* a pod is drifting. The category name is the insight; once named, it's recognizable.

**Signal** — telos-md's recommendation: `continue`, `pivot`, `stop`. Advisory, not command.

**Collision** — two pods with overlapping signatures or conflicting north stars.

## MCP tools

### `telos_set_north_star`

Declare intent before starting work. Returns an opaque ID used for subsequent ticks.

```
inputs:
  goal: str                        # "improve ojo until oracle 100/100"
  metric: str                      # "oracle.overall_score"
  stop_conditions:
    max_iterations: int?           # hard budget cap
    consecutive_zero_deltas: int?  # default: 3
    max_wall_seconds: int?
    on_signal: "stop" | "ask"?     # default: "ask" — pod decides
  signature: str?                  # for collision detection; hashed inputs+goal

returns:
  north_star_id: str
  collisions: [ ... ]              # empty if no collision detected at registration
  warnings: [ ... ]                # e.g., "this north star has saturated in N prior sessions at iter X"
```

### `telos_tick`

Report one iteration. Returns structured trajectory info.

```
inputs:
  north_star_id: str
  action_summary: str              # ~1 sentence: what did this iteration do?
  measurement: number | str        # current value of the declared metric
  signature: str?                  # classify the action type (e.g., "heuristic-tighten", "product-code", "finding-follow")
  model: str?                      # which model produced this iteration (e.g., "claude-opus-4-7", "gpt-5"). Enables model-diversity patterns. Self-reported; advisory only.

returns:
  heading: "on course" | "drifting" | "reversed" | "converged"
  drift_category: str?             # named pattern; null if none detected
  signal: "continue" | "pivot" | "stop"
  reasoning: str                   # one short paragraph the pod can incorporate
  pid: {p: number, i: number, d: number}  # raw trajectory numbers
  distance_to_stop: int | "now" | "never"
```

### `telos_traffic` ✓ built 2026-04-20

List the open north stars for a repo. Per-repo (telos-md never scans
across repos implicitly). Returns active NSes with iteration counts,
last signal, and fleet_diversity of their tick history. Post-ADR-001:
no cross-session/cross-repo duplicate detection — that was user-global
coordination telos-md no longer does.

```
returns:
  active: [{north_star_id, goal, iterations, heading, fleet_diversity}, ...]
  collisions: [...]                # conflicts, duplicates
  fleet_summary: {
    total_loops: int,
    single_model_loops: int,       # loops where every tick came from the same model
    mixed_loops: int,              # 2-3 distinct models
    heterogeneous_loops: int,      # 4+ distinct models
  }
```

fleet_diversity per loop is `"single-model" | "mixed" | "heterogeneous"`. See `LEARNING.md` → model-diversity patterns for why this is tracked.

### ~~`telos_chart`~~ — retired

**Retired 2026-04-20.** Post-hoc trajectory inspection is better served by
reading the repo's own files directly: `<repo>/.telos/north_stars/<nsid>.yaml`
has the final outcome + metadata; `<repo>/.telos/north_stars/<nsid>/ticks.jsonl`
has the full tick log. `git diff` against the ticks.jsonl file is a better
trajectory view than any MCP return shape. Retiring the tool prevents
redundant API surface and aligns with the per-repo file-as-truth thesis.

~~Post-hoc trajectory. Used after a loop ends to inspect what happened.~~

```
inputs:
  north_star_id: str

returns:
  iterations: [{tick, heading, drift_category, ...}]
  saturation_point: int?           # iteration where forward progress stopped
  final_signal: str                # why did the loop end?
  patterns_observed: [str]         # named drift categories seen
```

### `telos_close`

Close out a north star. Writes outcome to memory for cross-session learning.

```
inputs:
  north_star_id: str
  outcome: "reached" | "abandoned" | "converged" | "pivoted"
  notes: str?

returns:
  memory_key: str                  # for future telos_set_north_star to match
```

### `telos_patterns` ✓ built 2026-04-20

Read-only inspection of the pattern library. Returns the seed patterns
shipped in code plus any promoted patterns recorded in
`<repo>/.telos/promoted/`. Useful for pods that want to know what
drift modes telos-md can name without reading source.

```
inputs:
  repo_path: str?                  # optional; when provided, includes
                                   # promoted artifacts alongside seed
returns:
  patterns: [{name, description, symptoms, counter_action}]
```

### `telos_hypothesize`

Self-improvement driver — step 1 of 4. Accumulates candidates (unnamed recurring divergences, slipping counter-actions, flagged philosophy claims) and invokes an LLM fleet to draft N competing artifacts. Candidates are not applied yet — they enter a trial pool.

```
inputs:
  kind: "pattern_name" | "counter_action" | "refinement" | "philosophy_revision" | "deprecation"
  n_candidates: int?               # how many competing candidates to request. Default 3.
                                   # Multiple candidates compete in the trial pool.
  model_fleet: [str]?              # models to invoke. If multiple, runs heterogeneously.

returns:
  trial_id: str
  candidates: [{
    candidate_id: str,
    text: str,                     # the proposed artifact
    reasoning: str,                # why this particular candidate
    authored_by: str,              # model name
  }]
  fleet_diversity: "single-model" | "mixed" | "heterogeneous"
```

No human approval. Candidates auto-enroll in trial on creation.

### `telos_trial_status`

Query the state of an active trial. Read-only. Used by the meta-loop to track how candidates are performing.

```
inputs:
  trial_id: str

returns:
  candidates: [{
    candidate_id: str,
    applications: int,             # how many loops this candidate was applied to
    signal_outcome_corr: float,    # measured correlation, in [-1, 1]
    reference_rate: float,         # downstream references (proxy for memorability/adoption)
    status: "trialing" | "promoted" | "deprecated"
  }]
  trial_budget_remaining: int
  winner_candidate_id: str?        # set when a candidate has passed the promotion bar
```

### `telos_reload` ✓ built 2026-04-20

Re-import `patterns`, `store`, and `llm` modules from disk in the running
MCP server process. Lets code changes take effect without restarting
Claude Code. Auto-invoked at the end of every successful
`telos_promote`.

```
inputs: (none)
returns:
  reloaded: [str]     # list of module names re-imported
  note: str
```

### `telos_promote`

Self-improvement driver — step 4 of 4. Called by the meta-loop (not by a user) when a trial candidate has passed the promotion bar. Telos itself writes the markdown diff, commits, and integrates.

```
inputs:
  trial_id: str
  # candidate_id is determined by the trial's own measurement, not passed in.

returns:
  promoted_candidate_id: str
  commit_sha: str                  # telos-md's own commit to its docs / pattern library
  updated_files: [str]             # files telos-md edited (e.g., LEARNING.md, PHILOSOPHY.md)
  deprecated_candidate_ids: [str]  # competing candidates that did not win
```

The hypothesize → trial → measure (via `trial_status`) → promote pipeline is the mechanism by which telos-md improves itself and its docs without human approval at any step. See `LEARNING.md` → "The mechanism: propose → trial → measure → promote/deprecate" for the full reasoning and what remains irreducibly human (intent-setting, permission for irreversible actions, quarterly self-audit on measurement validity).

## Pattern library (seed)

The knowledge domain is *temporal/strategic coordination of autonomous work*. Named patterns below. Full write-ups with counter-actions and examples live in `LEARNING.md`.

### `measurement-over-product`
**Symptom:** N consecutive iterations modify the scorecard/measurement code, zero modify the product code.
**Counter:** Pivot to finding-following. Run the product on real data; follow a surprise.

### `heuristic-ratchet`
**Symptom:** Each iteration tightens an existing heuristic further. Marginal value per iteration decreases monotonically.
**Counter:** Declare a tightening budget at loop start. Stop when budget exhausted, not when the heuristic is "done."

### `zero-delta-churn`
**Symptom:** N consecutive ticks with no change to the declared metric, but iterations continue.
**Counter:** Stop signal. The declared stop condition has been reached even if the goal hasn't.

### `same-signature-repeat`
**Symptom:** Two pods (or crons) produce tick signatures with >X% overlap.
**Counter:** Collision flagged. One pod should defer or change course.

### `caretaking-drift`
**Symptom:** Pod suggests the user take a break, stop, sleep, etc., rather than executing asked work.
**Counter:** Signal is informational, not command. Base-model tendency; pod should suppress and continue.

### `spec-drift`
**Symptom:** Philosophy doc claims property X; code doesn't implement X.
**Counter:** Forcing function — tests that verify the property, or rename the doc as aspirational.

## Storage

Session-local by default (in-memory, keyed by north_star_id). Cross-session via `resume-resume` memory substrate when closing out via `telos_close`. Pattern library ships as static YAML in the repo; grows via PRs as new patterns are named.

## Non-goals

- **Not a task tracker.** Telos doesn't own todos. That's ike.
- **Not a decision framework.** Telos doesn't earn decisions. That's research-md → visionlog.
- **Not a command center.** Telos doesn't tell pods what to do. Decisions belong to the pod.
- **Not a dashboard.** Telos is consumed by pods, not watched by humans. (A human dashboard could sit on top of `telos_traffic`, but that's a separate product.)

## Open questions

1. Where does pattern library live long-term — in-repo YAML, or in a MCP-queryable knowledge base with vector search?
2. How does collision detection scale across sessions — signature hashing only, or content embedding?
3. How aggressive should the `stop` signal be — soft advisory, or can a loop opt into "telos-md can halt me"?
4. Does telos-md itself need adversarial review (meta-drift — telos-md's own patterns become stale)?
