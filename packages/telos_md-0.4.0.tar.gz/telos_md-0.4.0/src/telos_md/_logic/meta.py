"""Meta-loop: traffic inspection, pattern library, reload, promote.

Pure logic extracted from telos_md.tools v0.3.0.
"""

from __future__ import annotations

import importlib
import json
import subprocess
from pathlib import Path

from .. import llm, patterns, store


def reload_modules() -> list[str]:
    """Re-import patterns, store, llm from disk in the running process.

    Returns the list of module names whose on-disk source is now in
    effect. Intended to close the gap between 'telos promoted a fix'
    and 'the running process reflects the fix'.
    """
    reloaded = []
    for mod_name, mod in (
        ("telos_md.patterns", patterns),
        ("telos_md.store", store),
        ("telos_md.llm", llm),
    ):
        try:
            importlib.reload(mod)
            reloaded.append(mod_name)
        except Exception:
            pass
    return reloaded


def patterns_library(repo_path: str | None = None) -> dict:
    """Inspect the pattern library.

    Returns the seed patterns shipped in code plus any promoted patterns
    recorded in <repo>/.telos/promoted/ when `repo_path` is given.
    """
    seed = [
        {"name": name, "kind": "seed", "source": "src/telos_md/patterns.py"}
        for name in patterns.SEED_PATTERNS.keys()
    ]
    promoted: list[dict] = []
    if repo_path:
        promoted_dir = Path(repo_path) / ".telos" / "promoted"
        if promoted_dir.exists():
            for f in sorted(promoted_dir.glob("*.md")):
                promoted.append(
                    {
                        "name": f.stem,
                        "kind": "promoted",
                        "source": str(f.relative_to(repo_path)),
                    }
                )
    return {"seed": seed, "promoted": promoted, "total": len(seed) + len(promoted)}


def traffic(repo_path: str) -> dict:
    """List the open north stars for a repo.

    Per-repo (telos never scans across repos implicitly). Returns active
    NSes with iteration counts, last signal, and fleet_diversity of their
    tick history.
    """
    ns_dir = Path(repo_path) / ".telos" / "north_stars"
    active: list[dict] = []
    if ns_dir.exists():
        for f in ns_dir.glob("*.yaml"):
            ns = store._parse_yaml_flat(f.read_text())
            if ns.get("closed_at"):
                continue
            nsid = ns.get("id")
            if not nsid:
                continue
            tfile = ns_dir / nsid / "ticks.jsonl"
            iters = 0
            last_signal = None
            models: set[str] = set()
            if tfile.exists():
                for ln in tfile.read_text().splitlines():
                    if not ln.strip():
                        continue
                    try:
                        t = json.loads(ln)
                    except json.JSONDecodeError:
                        continue
                    iters += 1
                    last_signal = t.get("signal")
                    if t.get("model"):
                        models.add(t["model"])
            if len(models) == 1:
                diversity = "single-model"
            elif len(models) >= 4:
                diversity = "heterogeneous"
            elif len(models) >= 2:
                diversity = "mixed"
            else:
                diversity = "unknown"
            active.append(
                {
                    "north_star_id": nsid,
                    "goal": ns.get("goal"),
                    "iterations": iters,
                    "last_signal": last_signal,
                    "fleet_diversity": diversity,
                }
            )
    return {"active": active, "count": len(active), "repo_path": repo_path}


def reload() -> dict:
    """Re-import patterns / store / llm modules from disk."""
    reloaded = reload_modules()
    return {
        "reloaded": reloaded,
        "note": (
            "patterns / store / llm re-imported from disk; "
            "changes on disk are now in effect in this server process"
        ),
    }


def promote(candidate_id: str, repo_path: str | None = None) -> dict:
    """Promote a trial winner.

    Gated on: applications ≥ 5, signal_outcome_score ≥ 0.2, lift ≥ 0.4
    over null, regression_test passes via pytest, cross_model_review
    verdict=approved for pattern/refinement/counter_action kinds,
    strictly-best sibling on the rank cascade. Writes
    <repo>/.telos/promoted/<date>-<id>.md and appends to AUTONOMY.md.
    Auto-reloads patterns/store/llm afterward.
    """
    # Pre-gate: if the candidate declares a regression_test, run it.
    # Refuses promotion when the claimed behavior isn't embodied in
    # a passing test — directly closes the "promoted-text and
    # promoted-behavior disagree" gap.
    regression_test = None
    if repo_path:
        cand_file = store._find_candidate_file(repo_path, candidate_id)
        if cand_file:
            d = store._parse_candidate_file(cand_file)
            regression_test = d.get("regression_test")
    if regression_test:
        r = subprocess.run(
            ["python", "-m", "pytest", regression_test, "-q"],
            capture_output=True,
            text=True,
            cwd=repo_path,
        )
        if r.returncode != 0:
            return {
                "promoted": False,
                "reason": "regression_test_failed",
                "detail": {
                    "candidate_id": candidate_id,
                    "regression_test": regression_test,
                    "exit_code": r.returncode,
                    "stdout_tail": (r.stdout or "")[-800:],
                    "stderr_tail": (r.stderr or "")[-400:],
                },
            }
    try:
        result = store.promote_candidate(candidate_id, repo_path=repo_path)
    except store.PromotionBlocked as e:
        return {"promoted": False, "reason": e.reason, "detail": e.detail}
    # Auto-reload so the just-promoted artifact's logic — if it was
    # integrated into patterns.py between the trial window and this
    # promote — takes effect in the same process that promoted it.
    reloaded = reload_modules()
    return {
        "promoted": True,
        "promoted_candidate_id": candidate_id,
        "signal_outcome_corr": result["signal_outcome_corr"],
        "applications": result["applications"],
        "siblings": result["siblings"],
        "updated_files": result.get("updated_files", []),
        "reloaded_modules": reloaded,
    }
