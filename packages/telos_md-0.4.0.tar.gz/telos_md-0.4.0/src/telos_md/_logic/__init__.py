"""Pure-logic layer for telos-md.

Each module exposes plain Python functions that take typed kwargs and return
`dict | list | str` — no MCP or CLI dependency. The MCP dispatcher in
`telos_md.tools` and the (forthcoming) Typer CLI both call into these.

Stage A extraction of the v0.3.0 inline handlers. Behavior unchanged.
"""
