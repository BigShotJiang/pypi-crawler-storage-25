"""Propose pipeline: hypothesize candidates, inspect trial state.

Pure logic extracted from telos_md.tools v0.3.0.
"""

from __future__ import annotations

from .. import llm, store


def hypothesize(
    kind: str,
    context: str,
    n_candidates: int = 3,
    model: str | None = None,
    target_pattern: str | None = None,
    target_drift_category: str | None = None,
    candidates: list[dict] | None = None,
    repo_path: str | None = None,
) -> dict:
    """Draft N competing candidates of the given kind and enroll in a trial.

    `kind` ∈ {pattern_name, counter_action, refinement, philosophy_revision,
    deprecation}. When the caller provides `candidates` (preferred — fan
    out across model families upstream), those are used directly; otherwise
    falls back to built-in Claude drafting via llm.py.
    """
    if candidates:
        candidates_out = [dict(c) for c in candidates]
    else:
        candidates_out = llm.draft_candidates(
            kind=kind,
            context=context,
            n=n_candidates,
            model=model,
        )
    if target_pattern or target_drift_category:
        for cand in candidates_out:
            cand.setdefault("target_pattern", target_pattern)
            cand.setdefault("target_drift_category", target_drift_category)
    trial_id = store.insert_trial_candidates(
        kind=kind,
        candidates=candidates_out,
        repo_path=repo_path,
    )
    authors = {c.get("authored_by") for c in candidates_out}
    if len(authors) == 1:
        diversity = "single-model"
    elif len(authors) >= 4:
        diversity = "heterogeneous"
    else:
        diversity = "mixed"
    return {
        "trial_id": trial_id,
        "kind": kind,
        "candidates": candidates_out,
        "fleet_diversity": diversity,
        "source": "caller-provided" if candidates else "built-in (llm.py / claude -p)",
    }


def trial_status(trial_id: str) -> dict:
    """Read-only inspection of a trial's candidates + metrics."""
    rows = store.trial_candidates(trial_id)
    return {"trial_id": trial_id, "candidates": rows}
