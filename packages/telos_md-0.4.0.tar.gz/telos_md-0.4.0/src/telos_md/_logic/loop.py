"""North-star lifecycle: set, tick, close.

Pure logic extracted from telos_md.tools v0.3.0. Functions return dicts;
no string formatting, no MCP/CLI dependency.
"""

from __future__ import annotations

import re

from .. import patterns, store


# ── Helpers (moved from tools.py; only set_north_star uses them) ──────────────


_COUNTER_METRIC_PATTERNS = (
    re.compile(r"\d+\s*/\s*\d+"),  # "3/5", "steps_done/5"
    re.compile(r"\w+\s*/\s*\d+"),  # "steps/5", "tasks_done/5"
    re.compile(r"\b(done|not done|complete|incomplete)\b", re.I),
    re.compile(r"\b(pass|fail)\b", re.I),
    re.compile(r"\bchecklist\b", re.I),
    re.compile(r"\b(completed|todo|todos_remaining)\b", re.I),
)


def _looks_like_counter_metric(metric: str) -> bool:
    if not metric:
        return False
    return any(p.search(metric) for p in _COUNTER_METRIC_PATTERNS)


# ── Lifecycle ─────────────────────────────────────────────────────────────────


def set_north_star(
    goal: str,
    metric: str | None = None,
    stop_max_iters: int | None = None,
    stop_zero_delta_n: int = 3,
    signature: str | None = None,
    repo_path: str | None = None,
) -> dict:
    """Register a north star — a goal for multi-step autonomous work.

    Returns a dict containing the north_star_id and any warnings.
    """
    # Warnings that need to run BEFORE register writes the NS file
    # (otherwise the NS's own goal text would match itself).
    pre_warnings: list[dict] = []
    if repo_path and patterns.goal_unreviewed(repo_path, goal or ""):
        pre_warnings.append(
            {
                "kind": "goal-unreviewed",
                "detail": (
                    "Goal has no matching entry in this repo's "
                    "`.research-md/`, `.visionlog/`, or `.telos/`. "
                    "Consequential work should be earned via research.md "
                    "and recorded as an ADR in visionlog before execution "
                    "begins. If this goal is small/obvious, ignore. If it "
                    "spawns substantial work, pause and go upstream."
                ),
            }
        )
    nsid = store.register_north_star(
        goal=goal,
        metric=metric,
        stop_max_iters=stop_max_iters,
        stop_zero_delta_n=stop_zero_delta_n,
        signature=signature,
        repo_path=repo_path,
    )
    msg = "north star registered"
    autonomy_present = bool(store.read_autonomy(repo_path))
    if autonomy_present:
        msg += "; AUTONOMY.md detected — settled decisions will surface on each tick"
    warnings: list[dict] = []
    if _looks_like_counter_metric(metric or ""):
        warnings.append(
            {
                "kind": "counter_metric",
                "detail": (
                    f"metric {metric!r} looks like a checklist/counter, not "
                    "a trajectory. Counter metrics leave no room for drift "
                    "detection — every tick is +1 toward a fixed target. "
                    "Consider a trajectory metric (e.g. a continuous quality "
                    "score, latency, token cost, coverage %) so telos_md "
                    "can observe direction and divergence."
                ),
            }
        )
    warnings.extend(pre_warnings)
    return {
        "north_star_id": nsid,
        "message": msg,
        "autonomy_available": autonomy_present,
        "warnings": warnings,
    }


def tick(
    north_star_id: str,
    action_summary: str,
    measurement,
    signature: str | None = None,
    model: str | None = None,
    override_stop: bool = False,
    repo_path: str | None = None,
) -> dict:
    """Report one iteration of the loop. Returns heading + signal + reasoning."""
    history = store.recent_ticks(north_star_id, n=20, repo_path=repo_path)
    ns_record = store.get_north_star(north_star_id, repo_path=repo_path)
    match = patterns.match(
        history
        + [
            {
                "measurement": measurement,
                "signature": signature,
                "model": model,
                "action_summary": action_summary,
            }
        ],
        goal=(ns_record.get("goal") if ns_record else None),
    )
    heading = (
        "converged"
        if match and match["signal"] == "stop"
        else ("drifting" if match else "on course")
    )
    try:
        iteration = store.record_tick(
            north_star_id,
            action_summary=action_summary,
            measurement=measurement,
            signature=signature,
            model=model,
            heading=heading,
            drift_category=match["drift_category"] if match else None,
            signal=match["signal"] if match else "continue",
            override_stop=bool(override_stop),
            repo_path=repo_path,
        )
    except store.StopSignalIgnored as e:
        return {
            "accepted": False,
            "reason": "stop_signal_ignored",
            "message": str(e),
            "hint": "call telos_close, or retry this tick with override_stop=true",
        }
    except store.LoopBudgetExceeded as e:
        return {
            "accepted": False,
            "reason": "loop_budget_exceeded",
            "message": str(e),
            "hint": "call telos_close; register a new north_star for follow-on work",
        }
    ns = store.get_north_star(north_star_id, repo_path=repo_path)
    autonomy = store.read_autonomy((ns.get("repo_path") if ns else None) or repo_path)
    autonomy_hint = None
    if autonomy:
        lines = [ln for ln in autonomy.splitlines() if ln.startswith("- ")]
        if lines:
            autonomy_hint = (
                f"{len(lines)} settled decisions in this repo's "
                f"AUTONOMY.md — act consistent with them without re-asking."
            )
    # Silence on null — per ojo-session feedback (2026-04-20):
    # boilerplate "autonomy granted" text on every no-drift tick
    # trained pods to skim past telos_md output. Return null
    # reasoning when nothing specific fires; only surface the
    # autonomy hint when an AUTONOMY.md exists AND has real
    # content to point at.
    return {
        "iteration": iteration,
        "heading": heading,
        "drift_category": match["drift_category"] if match else None,
        "signal": match["signal"] if match else "continue",
        "reasoning": match["reasoning"] if match else (autonomy_hint or None),
        "settled_autonomy": autonomy_hint,
    }


def close(
    north_star_id: str,
    outcome: str,
    notes: str | None = None,
    repo_path: str | None = None,
) -> dict:
    """Close a north star with a terminal outcome.

    Outcome: reached | abandoned | converged | pivoted. Triggers
    empirical-validation metrics for any trial candidates applied during
    this loop.
    """
    return store.close_north_star(
        north_star_id,
        outcome=outcome,
        notes=notes,
        repo_path=repo_path,
    )
