"""Typer CLI for telos-md. Entry point: ``telos-md``.

The CLI is the primary substrate. The MCP server (``telos-md mcp serve``)
is a razor-thin wrapper exposing a single ``help`` tool that returns
this command tree.

Discovery: ``telos-md --help`` shows the tree; ``telos-md <cmd> --help``
drills in. Every subcommand accepts ``--json`` for machine-readable output.
"""

from __future__ import annotations

from ._app import app, main


__all__ = ["app", "main"]
