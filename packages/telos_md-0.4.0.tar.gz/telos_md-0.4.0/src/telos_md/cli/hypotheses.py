"""Propose pipeline subcommands: hypothesize, trial-status."""

from __future__ import annotations

import json
from typing import Annotated, Optional

import typer

from .._logic import hypotheses as _hyp


def register(app: typer.Typer) -> None:
    @app.command("hypothesize")
    def cmd_hypothesize(
        kind: Annotated[
            str,
            typer.Option(
                help="pattern_name | counter_action | refinement | philosophy_revision | deprecation"
            ),
        ],
        context: Annotated[
            str, typer.Option(help="Evidence motivating the hypothesis.")
        ],
        n_candidates: Annotated[
            int, typer.Option(help="How many competing candidates to draft.")
        ] = 3,
        model: Annotated[
            Optional[str], typer.Option(help="Which model to ask. Omit for default.")
        ] = None,
        target_pattern: Annotated[
            Optional[str],
            typer.Option(
                help="For refinement/counter_action: parent pattern this candidate modifies."
            ),
        ] = None,
        target_drift_category: Annotated[
            Optional[str],
            typer.Option(
                help="For refinement/counter_action: drift_category this candidate targets."
            ),
        ] = None,
        candidates_json: Annotated[
            Optional[str],
            typer.Option(
                "--candidates-json",
                help="Caller-provided heterogeneous candidates as a JSON array. Each: {text, authored_by, ...}.",
            ),
        ] = None,
        repo_path: Annotated[
            Optional[str], typer.Option(help="Absolute path to the watched repo.")
        ] = None,
        json_: Annotated[
            bool, typer.Option("--json", "-J", help="JSON output.")
        ] = False,
    ) -> None:
        """Draft N competing candidates and enroll them in a trial."""
        from ._app import emit

        caller_candidates: Optional[list] = None
        if candidates_json:
            try:
                caller_candidates = json.loads(candidates_json)
            except json.JSONDecodeError as e:
                typer.echo(f"--candidates-json is not valid JSON: {e}", err=True)
                raise typer.Exit(code=2)
        result = _hyp.hypothesize(
            kind=kind,
            context=context,
            n_candidates=n_candidates,
            model=model,
            target_pattern=target_pattern,
            target_drift_category=target_drift_category,
            candidates=caller_candidates,
            repo_path=repo_path,
        )
        emit(result, json_mode=json_)

    @app.command("trial-status")
    def cmd_trial_status(
        trial_id: Annotated[
            str, typer.Option(help="Trial ID returned by hypothesize.")
        ],
        json_: Annotated[
            bool, typer.Option("--json", "-J", help="JSON output.")
        ] = False,
    ) -> None:
        """Read-only inspection of a trial's candidates + metrics."""
        from ._app import emit

        result = _hyp.trial_status(trial_id=trial_id)
        emit(result, json_mode=json_)
