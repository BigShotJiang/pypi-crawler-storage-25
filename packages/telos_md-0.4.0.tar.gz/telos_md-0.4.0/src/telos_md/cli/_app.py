"""Typer app root + shared output formatting.

Every subcommand returns its `_logic`-layer result (a dict/list/str) and
calls `emit(result, json_mode)` which prints either pretty JSON or a
human-readable form.
"""

from __future__ import annotations

import json as _json
import sys
from typing import Annotated

import typer


# ── Output mode ───────────────────────────────────────────────────────────────


def _emit(result, *, json_mode: bool) -> None:
    """Print the result. JSON mode = indented JSON; default = readable."""
    if json_mode:
        typer.echo(_json.dumps(result, indent=2, default=str))
        return
    if isinstance(result, str):
        typer.echo(result)
    elif isinstance(result, (dict, list)):
        # Readable default: pretty JSON. We avoid bespoke formatting until a
        # specific subcommand has a clearly better human-readable shape.
        typer.echo(_json.dumps(result, indent=2, default=str))
    else:
        typer.echo(str(result))


# Re-exported for subcommand modules.
emit = _emit


# ── Root app ──────────────────────────────────────────────────────────────────


app = typer.Typer(
    name="telos-md",
    help=(
        "telos-md — Custodian of the project's telos.\n"
        "\n"
        "CUSTODY:  telos-md set-north-star ...   |   telos-md close ...\n"
        "DRIFT:    telos-md tick ...\n"
        "META:     telos-md hypothesize ... | trial-status | promote | reload | patterns | traffic\n"
        "\n"
        "Every subcommand supports --json for machine-readable output.\n"
        "Use `telos-md mcp serve` to launch the (razor-thin) MCP server.\n"
    ),
    no_args_is_help=True,
    add_completion=False,
)


# Subcommand groups attached in their own modules to avoid circular imports.
from . import loop as _loop_cmd  # noqa: E402
from . import hypotheses as _hypotheses_cmd  # noqa: E402
from . import meta as _meta_cmd  # noqa: E402
from . import mcp as _mcp_cmd  # noqa: E402


_loop_cmd.register(app)
_hypotheses_cmd.register(app)
_meta_cmd.register(app)
app.add_typer(_mcp_cmd.app, name="mcp", help="MCP server controls.")


JSONFlag = Annotated[
    bool,
    typer.Option("--json", "-J", help="Emit machine-readable JSON instead of text."),
]


def main() -> None:
    """Console-script entry point. Wraps `app()` so SystemExit codes flow."""
    try:
        app()
    except KeyboardInterrupt:
        sys.exit(130)
