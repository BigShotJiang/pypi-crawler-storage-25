"""Meta-loop subcommands: patterns, traffic, reload, promote."""

from __future__ import annotations

from typing import Annotated, Optional

import typer

from .._logic import meta as _meta


def register(app: typer.Typer) -> None:
    @app.command("patterns")
    def cmd_patterns(
        repo_path: Annotated[
            Optional[str],
            typer.Option(
                help="Optional repo path; includes promoted patterns when set."
            ),
        ] = None,
        json_: Annotated[
            bool, typer.Option("--json", "-J", help="JSON output.")
        ] = False,
    ) -> None:
        """Inspect the pattern library (seed + promoted)."""
        from ._app import emit

        result = _meta.patterns_library(repo_path=repo_path)
        emit(result, json_mode=json_)

    @app.command("traffic")
    def cmd_traffic(
        repo_path: Annotated[str, typer.Option(help="Absolute path to the repo.")],
        json_: Annotated[
            bool, typer.Option("--json", "-J", help="JSON output.")
        ] = False,
    ) -> None:
        """List open north stars for a repo."""
        from ._app import emit

        result = _meta.traffic(repo_path=repo_path)
        emit(result, json_mode=json_)

    @app.command("reload")
    def cmd_reload(
        json_: Annotated[
            bool, typer.Option("--json", "-J", help="JSON output.")
        ] = False,
    ) -> None:
        """Re-import patterns / store / llm from disk in the running process."""
        from ._app import emit

        result = _meta.reload()
        emit(result, json_mode=json_)

    @app.command("promote")
    def cmd_promote(
        candidate_id: Annotated[str, typer.Option(help="Candidate ID to promote.")],
        repo_path: Annotated[
            Optional[str],
            typer.Option(
                help="Absolute path; writes promoted artifacts to <repo>/.telos/promoted/."
            ),
        ] = None,
        json_: Annotated[
            bool, typer.Option("--json", "-J", help="JSON output.")
        ] = False,
    ) -> None:
        """Promote a trial winner (gated)."""
        from ._app import emit

        result = _meta.promote(candidate_id=candidate_id, repo_path=repo_path)
        emit(result, json_mode=json_)
