"""North-star lifecycle subcommands: set-north-star, tick, close."""

from __future__ import annotations

from typing import Annotated, Optional

import typer

from .._logic import loop as _loop


def register(app: typer.Typer) -> None:
    @app.command("set-north-star")
    def cmd_set_north_star(
        goal: Annotated[
            str, typer.Option(help="What this loop is trying to accomplish.")
        ],
        metric: Annotated[
            Optional[str], typer.Option(help="How success is measured. Free text.")
        ] = None,
        stop_max_iters: Annotated[
            Optional[int], typer.Option(help="Hard cap on iterations.")
        ] = None,
        stop_zero_delta_n: Annotated[
            int, typer.Option(help="Stop after N consecutive zero-delta ticks.")
        ] = 3,
        signature: Annotated[
            Optional[str], typer.Option(help="Optional hash of the work type.")
        ] = None,
        repo_path: Annotated[
            Optional[str],
            typer.Option(help="Absolute path to the repo this loop operates on."),
        ] = None,
        json_: Annotated[
            bool, typer.Option("--json", "-J", help="JSON output.")
        ] = False,
    ) -> None:
        """Register a north star — a custody act. Returns the north_star_id."""
        from ._app import emit

        result = _loop.set_north_star(
            goal=goal,
            metric=metric,
            stop_max_iters=stop_max_iters,
            stop_zero_delta_n=stop_zero_delta_n,
            signature=signature,
            repo_path=repo_path,
        )
        emit(result, json_mode=json_)

    @app.command("tick")
    def cmd_tick(
        north_star_id: Annotated[
            str, typer.Option(help="ID returned by set-north-star.")
        ],
        action_summary: Annotated[
            str, typer.Option(help="~1 sentence on what this iteration did.")
        ],
        measurement: Annotated[
            str,
            typer.Option(
                help="Current value of the declared metric. Numeric or string."
            ),
        ],
        signature: Annotated[
            Optional[str], typer.Option(help="Classify the action type.")
        ] = None,
        model: Annotated[
            Optional[str], typer.Option(help="Which model produced this iteration.")
        ] = None,
        override_stop: Annotated[
            bool, typer.Option(help="Proceed even if prior tick returned signal=stop.")
        ] = False,
        repo_path: Annotated[
            Optional[str], typer.Option(help="Absolute path to the repo.")
        ] = None,
        json_: Annotated[
            bool, typer.Option("--json", "-J", help="JSON output.")
        ] = False,
    ) -> None:
        """Report one iteration. Returns heading, drift_category, signal, reasoning."""
        from ._app import emit

        # Try to coerce numeric measurements
        m: object = measurement
        try:
            m = int(measurement)
        except (TypeError, ValueError):
            try:
                m = float(measurement)
            except (TypeError, ValueError):
                pass
        result = _loop.tick(
            north_star_id=north_star_id,
            action_summary=action_summary,
            measurement=m,
            signature=signature,
            model=model,
            override_stop=override_stop,
            repo_path=repo_path,
        )
        emit(result, json_mode=json_)

    @app.command("close")
    def cmd_close(
        north_star_id: Annotated[
            str, typer.Option(help="ID returned by set-north-star.")
        ],
        outcome: Annotated[
            str, typer.Option(help="reached | abandoned | converged | pivoted")
        ],
        notes: Annotated[
            Optional[str], typer.Option(help="Free-text closing notes.")
        ] = None,
        repo_path: Annotated[
            Optional[str], typer.Option(help="Absolute path to the repo.")
        ] = None,
        json_: Annotated[
            bool, typer.Option("--json", "-J", help="JSON output.")
        ] = False,
    ) -> None:
        """Discharge custody with a terminal outcome."""
        from ._app import emit

        result = _loop.close(
            north_star_id=north_star_id,
            outcome=outcome,
            notes=notes,
            repo_path=repo_path,
        )
        emit(result, json_mode=json_)
