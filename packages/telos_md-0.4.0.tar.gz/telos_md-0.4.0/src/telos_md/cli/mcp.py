"""`telos-md mcp serve` — boots the razor-thin MCP server.

The MCP server exposes ONE tool: `help`. Discovery happens through that
tool's structured response; all real work happens via the CLI subcommands.
"""

from __future__ import annotations

import typer


app = typer.Typer(help="MCP server controls.", no_args_is_help=True)


@app.command("serve")
def cmd_serve() -> None:
    """Run the telos MCP server over stdio (for use by Claude Code, etc.)."""
    from ..mcp_server import run

    run()
