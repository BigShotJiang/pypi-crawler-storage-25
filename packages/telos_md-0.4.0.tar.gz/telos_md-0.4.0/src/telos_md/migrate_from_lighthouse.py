"""telos-migrate — migrate a project to current telos-md state.

Handles three transitions, idempotently, in one sweep:

    v0.2.x (lighthouse) → v0.3.0 (telos-md): rename .lighthouse/ → .telos/,
        config.yaml's project field, mcp__lighthouse__ → mcp__telos__,
        mcp__telos__lighthouse_* → mcp__telos__telos_*, .mcp.json server
        name + commands.

    v0.3.0 (MCP-fat) → v0.4.0 (CLI-first razor-thin MCP): collapse all
        mcp__telos__* allowlist entries to a single mcp__telos__help;
        insert Bash(telos-md:*) if absent. (Per the CLI-first ADR-006.)

Run inside a project directory or pass --root to sweep a tree. Dry-run
by default; pass --apply to actually rewrite.

Files NEVER touched:
    - Markdown content inside .lighthouse/ or .telos/ (only the dir is renamed)
    - Files outside the project root
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Plan:
    project_root: Path
    actions: list[tuple[str, str]]

    def add(self, description: str, detail: str = "") -> None:
        self.actions.append((description, detail))

    def is_empty(self) -> bool:
        return not self.actions


def _safe_sub(content: str, pattern: str, replacement: str) -> tuple[str, int]:
    new_content, n = re.subn(pattern, replacement, content)
    return new_content, n


def plan_for_project(project_root: Path) -> Plan:
    plan = Plan(project_root, [])
    lh_dir = project_root / ".lighthouse"
    telos_dir = project_root / ".telos"

    if lh_dir.is_dir() and not telos_dir.exists():
        plan.add(f"rename {lh_dir.name}/ -> {telos_dir.name}/")

    # config.yaml — update project field if it references the brand
    cfg = lh_dir / "config.yaml" if lh_dir.is_dir() else None
    if cfg and cfg.is_file():
        content = cfg.read_text()
        if "project: " in content and (
            "lighthouse" in content or "Lighthouse" in content
        ):
            plan.add("  config.yaml: set project: telos-md (was lighthouse)")

    # Claude settings allowlist — three transitions are handled idempotently:
    #   mcp__lighthouse__*               -> mcp__telos__*       (v0.3.0 server prefix)
    #   mcp__telos__lighthouse_*         -> mcp__telos__telos_* (v0.3.0 brand-prefixed tool names)
    #   ALL mcp__telos__* (any verb)     -> mcp__telos__help    (v0.4.0 CLI-first collapse)
    #   plus: ensure Bash(telos-md:*) is present (v0.4.0)
    settings = project_root / ".claude" / "settings.local.json"
    if settings.is_file():
        try:
            data = json.loads(settings.read_text())
        except json.JSONDecodeError:
            data = None
        if isinstance(data, dict):
            allow = data.get("permissions", {}).get("allow", [])
            telos_entries = [
                e
                for e in allow
                if isinstance(e, str)
                and e.startswith("mcp__telos__")
                or e.startswith("mcp__lighthouse__")
            ]
            already_help = any(e == "mcp__telos__help" for e in allow)
            bash_pattern_present = any(
                isinstance(e, str) and e.startswith("Bash(telos-md") for e in allow
            )
            if telos_entries and (not already_help or len(telos_entries) > 1):
                plan.add(
                    f"collapse {len(telos_entries)} mcp__(telos|lighthouse)__* allowlist entries → single mcp__telos__help (CLI-first; v0.4.0)"
                )
            if not bash_pattern_present:
                plan.add("add Bash(telos-md:*) to allowlist (CLI-first)")

    # .mcp.json server name + commands
    mcp_json = project_root / ".mcp.json"
    if mcp_json.is_file():
        content = mcp_json.read_text()
        change_count = 0
        _, n = _safe_sub(content, r'"lighthouse"\s*:', '"telos":')
        change_count += n
        _, n = _safe_sub(content, r'"lighthouse-mcp"', '"telos"')
        change_count += n
        _, n = _safe_sub(content, r'"lighthouse-md"', '"telos-md"')
        change_count += n
        _, n = _safe_sub(content, r"lighthouse\.", "telos_md.")
        change_count += n
        _, n = _safe_sub(
            content, r'"command"\s*:\s*"lighthouse-mcp"', '"command": "telos"'
        )
        change_count += n
        if change_count:
            plan.add(
                f"edit .mcp.json: {change_count} lighthouse identifier(s) -> telos"
            )

    return plan


def apply_plan(plan: Plan) -> None:
    project_root = plan.project_root
    lh_dir = project_root / ".lighthouse"
    telos_dir = project_root / ".telos"

    # 1. Rename .lighthouse/ -> .telos/
    if lh_dir.is_dir() and not telos_dir.exists():
        lh_dir.rename(telos_dir)

    # 2. Fix config.yaml's project field
    cfg = telos_dir / "config.yaml"
    if cfg.is_file():
        content = cfg.read_text()
        new = re.sub(
            r'(project:\s*["\']?)lighthouse(\.md)?(["\']?)',
            r"\1telos-md\3",
            content,
            flags=re.IGNORECASE,
        )
        if new != content:
            cfg.write_text(new)

    # 3. Claude settings allowlist (see plan_for_project for the three transitions)
    settings = project_root / ".claude" / "settings.local.json"
    if settings.is_file():
        try:
            data = json.loads(settings.read_text())
        except json.JSONDecodeError:
            data = None
        if isinstance(data, dict):
            allow = data.get("permissions", {}).get("allow", [])
            # 3a. Drop any mcp__lighthouse__* and mcp__telos__* entries
            #     (we're collapsing them to one).
            new_allow = [
                e
                for e in allow
                if not (
                    isinstance(e, str)
                    and (
                        e.startswith("mcp__telos__")
                        or e.startswith("mcp__lighthouse__")
                    )
                )
            ]
            collapsed = len(allow) != len(new_allow)
            # 3b. Add the single mcp__telos__help entry if not already present
            if not any(e == "mcp__telos__help" for e in new_allow):
                new_allow.append("mcp__telos__help")
                collapsed = True
            # 3c. Ensure Bash(telos-md:*) is present
            if not any(
                isinstance(e, str) and e.startswith("Bash(telos-md") for e in new_allow
            ):
                new_allow.append("Bash(telos-md:*)")
                collapsed = True
            if collapsed:
                data.setdefault("permissions", {})["allow"] = new_allow
                settings.write_text(json.dumps(data, indent=2))

    # 4. .mcp.json
    mcp_json = project_root / ".mcp.json"
    if mcp_json.is_file():
        content = mcp_json.read_text()
        new = content
        new, _ = _safe_sub(new, r'"lighthouse"\s*:', '"telos":')
        new, _ = _safe_sub(new, r'"lighthouse-mcp"', '"telos"')
        new, _ = _safe_sub(new, r'"lighthouse-md"', '"telos-md"')
        new, _ = _safe_sub(new, r"lighthouse\.", "telos_md.")
        new, _ = _safe_sub(
            new, r'"command"\s*:\s*"lighthouse-mcp"', '"command": "telos"'
        )
        if new != content:
            mcp_json.write_text(new)


def find_projects(root: Path) -> list[Path]:
    found = []
    # Catch both: pre-v0.3 (.lighthouse exists, needs full rename) and
    # post-v0.3 (.telos exists, may still need the v0.4 allowlist collapse).
    seen: set[Path] = set()
    for marker in (".lighthouse", ".telos"):
        for path in root.rglob(marker):
            if path.is_dir():
                parent = path.parent
                if parent in seen:
                    continue
                seen.add(parent)
                found.append(parent)
    return sorted(found)


def _legacy_find_projects_for_lighthouse_only(root: Path) -> list[Path]:
    """Old version, retained for reference. Use find_projects() above."""
    found = []
    for path in root.rglob(".lighthouse"):
        if path.is_dir():
            parent = path.parent
            if (parent / ".telos").exists():
                continue
            found.append(parent)
    return sorted(found)


def main() -> int:
    p = argparse.ArgumentParser(
        prog="telos-migrate",
        description="Migrate a project from lighthouse state to telos-md state.",
    )
    p.add_argument(
        "--root",
        type=Path,
        default=None,
        help="Sweep all projects under this root. Default: just the current directory.",
    )
    p.add_argument(
        "--apply",
        action="store_true",
        help="Actually rewrite. Without this, runs as a dry-run.",
    )
    args = p.parse_args()

    if args.root:
        if not args.root.is_dir():
            print(f"--root {args.root} is not a directory", file=sys.stderr)
            return 2
        projects = find_projects(args.root)
        if not projects:
            print(f"No .lighthouse/ or .telos/ directories under {args.root}.")
            return 0
        print(
            f"Found {len(projects)} project(s) with .lighthouse/ or .telos/ under {args.root}.\n"
        )
    else:
        cwd = Path.cwd()
        if not ((cwd / ".lighthouse").is_dir() or (cwd / ".telos").is_dir()):
            print(f"No .lighthouse/ or .telos/ in {cwd}. Nothing to migrate.")
            print("Use --root to sweep a directory tree.")
            return 0
        projects = [cwd]

    plans = [plan_for_project(p) for p in projects]
    nonempty = [pl for pl in plans if not pl.is_empty()]

    if not nonempty:
        print("Nothing to migrate.")
        return 0

    for plan in nonempty:
        print(f"\n=== {plan.project_root} ===")
        for desc, _ in plan.actions:
            print(f"  • {desc}")

    if not args.apply:
        print(f"\n(dry-run; pass --apply to rewrite {len(nonempty)} project(s))")
        return 0

    for plan in nonempty:
        apply_plan(plan)
        print(f"migrated: {plan.project_root}")

    print(f"\nDone. Migrated {len(nonempty)} project(s).")
    print(
        "Restart any active Claude Code sessions so they pick up the renamed MCP server."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
