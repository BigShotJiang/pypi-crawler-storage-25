"""telos_md — loop and trilogy coordination for autonomous agent work.

See README.md for the concept pitch, SPEC.md for the API, LEARNING.md
for the self-improvement mechanism, and PHILOSOPHY.md for why
telos_md sits at this level of the stack.
"""

__version__ = "0.1.0a0"
