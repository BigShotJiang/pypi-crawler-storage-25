"""Built-in pattern library — the seed from LEARNING.md.

Each pattern takes the tick history for a north star and returns a
match result: matched (bool), drift_category (str), signal
("continue"/"pivot"/"stop"), and a short reasoning snippet.

The library will grow via the hypothesize → trial → promote pipeline.
These are the seed patterns before any empirical evidence has
accumulated.
"""

from __future__ import annotations

from typing import Callable, Optional


def _zero_delta_streak(ticks: list[dict]) -> int:
    """How many consecutive trailing ticks have the same measurement."""
    if len(ticks) < 2:
        return 0
    last = ticks[-1].get("measurement")
    streak = 0
    for t in reversed(ticks[:-1]):
        if t.get("measurement") == last:
            streak += 1
        else:
            break
    return streak


def _signature_cluster(ticks: list[dict], window: int = 6, ratio: float = 0.66) -> bool:
    """True when `ratio` of the last `window` ticks share the same signature.

    Per promoted refinement cd_243cdb7f6b (2026-04-19): the CURRENT (final)
    tick's signature is compared against the dominant signature of the
    preceding N-1 ticks. If the final tick is a basis-change (different
    signature from the prefix's dominant), the pattern does NOT fire on
    this tick — the cluster is being broken, and firing heuristic-ratchet
    on the counter-action tick is a false positive. The pattern correctly
    fires on any tick where the final signature continues the prefix's
    dominant cluster.
    """
    if len(ticks) < window:
        return False
    from collections import Counter

    tail = ticks[-window:]
    sigs = [t.get("signature") for t in tail if t.get("signature")]
    if not sigs:
        return False
    top_sig, top_count = Counter(sigs).most_common(1)[0]
    final_sig = tail[-1].get("signature")
    if final_sig != top_sig:
        # Final tick is a basis-change; suppress the pattern on this tick.
        return False
    return top_count / window >= ratio


def _distinct_models(ticks: list[dict]) -> set[str]:
    return {t["model"] for t in ticks if t.get("model")}


def settled_decision_re_asked(repo_path: str, action_summary: str) -> Optional[str]:
    """Return the AUTONOMY.md line that this tick's action_summary is
    re-asking about, or None if no match.

    Persistence-of-decision is the AGI-likeness sub-property this
    detector protects (ADR-003). When a pod ticks an action that's
    asking or considering something already settled in the repo's
    AUTONOMY.md, telos_md surfaces the exact entry — so the pod
    can stop re-litigating a contract already earned."""
    if not repo_path or not action_summary:
        return None
    from pathlib import Path as _P

    autonomy = _P(repo_path) / ".telos" / "AUTONOMY.md"
    if not autonomy.exists():
        return None
    summary = action_summary.lower().strip()
    if not summary:
        return None
    for line in autonomy.read_text().splitlines():
        line = line.strip()
        if not line.startswith("- "):
            continue
        body = line[2:].lower()
        # Extract meaningful keywords (strip dates, IDs, markdown).
        words = [w for w in body.split() if len(w) > 5 and w.isalpha()]
        if not words:
            continue
        # If 2+ content words from the AUTONOMY entry appear in the
        # action summary, flag it as a re-ask candidate.
        overlap = sum(1 for w in words if w in summary)
        if overlap >= 2:
            return line
    return None


HEDGING_MARKERS = (
    # claude-authored (original set)
    "should i",
    "want me to",
    "let me know",
    "would you like",
    "do you want",
    "shall i",
    "wondering if",
    "considering whether",
    "not sure if i should",
    "waiting for confirmation",
    "waiting on your",
    "pending your",
    "ok to proceed",
    "is it ok",
    "can i go ahead",
    "need your approval",
    # gemini-proposed + gpt-5.2-filtered — covers non-claude caretaking phrasings.
    # Rejected by gpt-5.2 as too false-positive-prone: "happy to proceed",
    # "ready when you are" (both appear naturally in system-readiness copy).
    "does that sound good",
    "which would you prefer",
    "are you ready to proceed",
)


_WAITING_MARKERS = (
    "waiting for",
    "waiting on",
    "blocked on",
    "blocked by",
    "pending external",
    "pending response",
    "awaiting response",
    "awaiting approval",
    "no response from",
    "still no",
    "haven't heard back",
    "haven't received",
)


def _is_event_starved(ticks: list[dict], window: int = 3) -> bool:
    """True when the pod is stuck waiting on an external event.

    Distinct from zero-delta-churn: ZDC is outcome-only (measurement
    flat). Event-starvation is a *causal* subtype — the action summary
    explicitly names a blocking external dependency, and the measurement
    hasn't moved. The counter-action is specific ("time out the wait,
    re-evaluate the dependency, fall back") not generic ("you've
    saturated, stop"). Proposed by deepseek-r1, tightened per gpt-5.2
    caveats (keyword-fallback is honest in MVP; tightenable with
    structured dependency fields if ever added to the tick schema).
    """
    if len(ticks) < window:
        return False
    tail = ticks[-window:]
    measurements = {t.get("measurement") for t in tail}
    if len(measurements) != 1:
        return False  # Measurement moved — not starved.
    blocking_count = 0
    for t in tail:
        summary = (t.get("action_summary") or "").lower()
        if any(marker in summary for marker in _WAITING_MARKERS):
            blocking_count += 1
    return blocking_count >= window


def _is_caretaking(ticks: list[dict]) -> bool:
    """True when the latest tick's action_summary contains hedging/caretaking
    language — the pod is asking permission instead of executing."""
    if not ticks:
        return False
    summary = (ticks[-1].get("action_summary") or "").lower()
    return any(marker in summary for marker in HEDGING_MARKERS)


_ASSESSMENT_TERMS = (
    "grade",
    "grading",
    "audit",
    "auditing",
    "assess",
    "assessment",
    "evaluat",  # natural-language match only; not related to code execution
    "review",
)
_MULTI_AXIS_TERMS = (
    "dimensions",
    "dimension",
    "rubric",
    "criteria",
    "axes",
    "axis",
    "across",
    "scorecard",
    "matrix",
    "each",
    "all five",
    "five ",
    "several",
)


def _goal_declares_multi_axis_assessment(goal: str) -> bool:
    """True only when the goal co-occurs an assessment term AND an
    explicit multi-axis indicator — per gpt-5.2 review caveat: single
    hits like 'assess tradeoffs' or 'evaluate perf' do NOT suppress
    execution-without-decision. That would create a broad false-negative
    zone for genuine implementation stalls."""
    if not goal:
        return False
    g = goal.lower()
    has_assessment = any(t in g for t in _ASSESSMENT_TERMS)
    has_multi_axis = any(t in g for t in _MULTI_AXIS_TERMS)
    return has_assessment and has_multi_axis


def _signature_churn(ticks: list[dict], window: int = 5, ratio: float = 0.8) -> bool:
    """True when the last `window` ticks contain mostly-unique signatures —
    the pod is thrashing between implementations instead of converging.
    """
    if len(ticks) < window:
        return False
    tail = ticks[-window:]
    sigs = [t.get("signature") for t in tail if t.get("signature")]
    if len(sigs) < window:
        return False
    return len(set(sigs)) / window >= ratio


def match(
    ticks: list[dict], stop_zero_delta_n: int = 3, goal: Optional[str] = None
) -> Optional[dict]:
    """Return the first matching pattern, or None if none match.

    Patterns are checked in priority order. The first match wins —
    subsequent matches are not reported this tick. This keeps the
    return shape simple; if a pod wants all matches it can call
    `match_all`.
    """
    if not ticks:
        return None

    # event-starvation: pod stuck waiting on external dependency.
    # Checked before zero-delta-churn so the more specific counter-action
    # ("fall back / re-evaluate the dependency") wins over generic
    # "you've saturated." Proposed by deepseek-r1, reviewed by gpt-5.2.
    if _is_event_starved(ticks):
        return {
            "drift_category": "event-starvation",
            "signal": "pivot",
            "reasoning": (
                "Pod has been waiting on an external dependency for the "
                "last 3 ticks without measurement movement. Time out the "
                "wait, re-evaluate whether the dependency is still "
                "needed or has a fallback path, and either abandon or "
                "proceed with the fallback. If human-in-the-loop, escalate "
                "via rhea_unstick or direct channel rather than silent waiting."
            ),
        }

    # caretaking-drift: pod is asking instead of acting. Check before
    # other patterns so the counter-action ("just do it") isn't buried.
    if _is_caretaking(ticks):
        return {
            "drift_category": "caretaking-drift",
            "signal": "pivot",
            "reasoning": (
                "Hedging/permission-seeking language in the action summary. "
                "Caretaking-drift is a base-model tendency; suppress it and "
                "execute. Check `telos_md/AUTONOMY.md` in the active repo — "
                "if a settled decision covers this situation, you already "
                "have clearance. Default is act, not ask."
            ),
        }

    # zero-delta-churn: core convergence signal.
    streak = _zero_delta_streak(ticks)
    if streak + 1 >= stop_zero_delta_n:
        return {
            "drift_category": "zero-delta-churn",
            "signal": "stop",
            "reasoning": (
                f"{streak + 1} consecutive ticks with identical measurement. "
                f"Stop condition (N={stop_zero_delta_n}) reached."
            ),
        }

    # monolithic-loop: one model running everything.
    # Threshold tightened from 5→3 per ojo-session feedback (2026-04-20):
    # firing at iteration 5 was too patient — by then the drift has
    # already committed 5 single-model ticks. Firing at 3 lets a pod
    # course-correct while there's still budget.
    models = _distinct_models(ticks)
    if len(ticks) >= 3 and len(models) == 1:
        return {
            "drift_category": "monolithic-loop",
            "signal": "pivot",
            "reasoning": (
                "All ticks authored by a single model. Route by question type: "
                "for plan-level doubt ('is this even the right goal?') invoke "
                "`rhea_challenge`. For code-level correctness invoke "
                "`pal_codereview` with a non-Claude model (e.g. `openai/gpt-5.2`). "
                "Same-model review won't escape the geometry."
            ),
        }

    # execution-without-decision: pod thrashing between implementations.
    # Different signature every tick = no converged approach = decision
    # was never earned before execution started.
    # Suppressed when the NS goal explicitly declares multi-axis assessment —
    # grading / audit / review loops have diverse signatures by design,
    # not by drift. Refinement landed 2026-04-20, surfaced during
    # telos_md's own self-grade loop.
    if _signature_churn(ticks) and not _goal_declares_multi_axis_assessment(goal or ""):
        return {
            "drift_category": "execution-without-decision",
            "signal": "pivot",
            "reasoning": (
                "Signatures churning — different approach nearly every tick. "
                "The implementation decision was never earned. Pause "
                "execution, open the question in `research.md` with evidence, "
                "record the winning approach as an ADR in `visionlog`, then "
                "resume with `ike.md` tasks bound to that contract."
            ),
        }

    # heuristic-ratchet: repeated signature.
    if _signature_cluster(ticks):
        return {
            "drift_category": "heuristic-ratchet",
            "signal": "pivot",
            "reasoning": (
                "Trailing ticks cluster on the same signature — the lossy "
                "medium has degenerated into lossless. Invoke `rhea_challenge` "
                "on whether the heuristic is pointed at the right objective. "
                "If it is, promote the current state via a `visionlog` ADR and "
                "stop ratcheting."
            ),
        }

    return None


# Named pattern registry — for introspection. Grows when telos_md's
# meta-loop promotes a trial candidate.
SEED_PATTERNS: dict[str, Callable] = {
    "zero-delta-churn": lambda ticks: _zero_delta_streak(ticks),
    "monolithic-loop": lambda ticks: (
        len(_distinct_models(ticks)) == 1 and len(ticks) >= 5
    ),
    "heuristic-ratchet": lambda ticks: _signature_cluster(ticks),
    "execution-without-decision": lambda ticks: _signature_churn(ticks),
    "measurement-over-product": lambda ticks: _signature_cluster(ticks),
    "low-diversity-fleet": lambda ticks: (
        len(_distinct_models(ticks)) <= 2 and len(ticks) >= 10
    ),
    "degenerate-medium": lambda ticks: _signature_cluster(ticks, window=4, ratio=1.0),
    "same-signature-repeat": lambda ticks: _signature_cluster(
        ticks, window=3, ratio=1.0
    ),
    "caretaking-drift": lambda ticks: _is_caretaking(ticks),
    "event-starvation": lambda ticks: _is_event_starved(ticks),
}


# --------------------------------------------------------------------------
# Non-tick-stream detectors
# --------------------------------------------------------------------------
# These detectors need filesystem inspection (a repo path), not just a tick
# list. They don't live in SEED_PATTERNS (which maps tick-list detectors)
# but are real functions, callable from the tools/self_audit layer.


def goal_unreviewed(repo_path: str, goal: str) -> bool:
    """True when a north star's goal has no evidence of being earned via
    research.md or visionlog. Fires at registration time — a consequential
    goal should have a paper trail in the trilogy before execution starts.
    """
    from pathlib import Path

    if not repo_path or not goal:
        return False
    repo = Path(repo_path)
    needle = goal.lower().strip()[:60]  # first 60 chars as a substring probe
    for candidate_dir in (".research", ".research-md", ".visionlog", ".telos"):
        d = repo / candidate_dir
        if not d.exists():
            continue
        try:
            for f in d.rglob("*.md"):
                try:
                    if needle in f.read_text().lower():
                        return False
                except OSError:
                    continue
            for f in d.rglob("*.yaml"):
                try:
                    if needle in f.read_text().lower():
                        return False
                except OSError:
                    continue
        except OSError:
            continue
    return True


def spec_drift(spec_path: str, tool_names: list[str]) -> list[dict]:
    """Return a list of mismatches between a SPEC.md and a set of MCP tool
    names. Fires in self-audit. Each mismatch: {kind: 'in_spec_not_code' |
    'in_code_not_spec', name: str}. Used to keep docs and code honest."""
    from pathlib import Path
    import re as _re

    p = Path(spec_path)
    if not p.exists():
        return []
    spec_text = p.read_text()
    # Pull any "telos_..." identifiers from SPEC (matches both telos_xxx tool
    # names and the legacy telos_md_xxx form that may appear in old fixtures).
    spec_tools = set(_re.findall(r"telos(?:_md)?_[a-z_]+", spec_text))
    code_tools = set(tool_names)
    out = []
    for name in spec_tools - code_tools:
        out.append({"kind": "in_spec_not_code", "name": name})
    for name in code_tools - spec_tools:
        out.append({"kind": "in_code_not_spec", "name": name})
    return out
