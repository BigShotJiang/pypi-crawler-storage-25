"""Razor-thin MCP server for telos-md.

Exposes ONE tool: ``help``. Every other operation happens via the CLI
(``telos-md set-north-star``, ``telos-md tick``, etc.). This is the
CLI-first / razor-thin-MCP shape — see ADR-006 in governor.md/.governor/adr/.

Discovery flow:
  1. Agent calls ``mcp__telos__help()`` — gets the full command tree.
  2. Agent calls ``mcp__telos__help(subcommand="tick")`` — gets the
     specific subcommand's --help output.
  3. Agent invokes the actual work via Bash: ``telos-md tick ... --json``.
"""

from __future__ import annotations

import asyncio
import io
import sys

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool


server = Server("telos")


HELP_DESCRIPTION = (
    "REQUIRED at session start for any telos-md work: returns the full "
    "telos-md command tree. Call with no args for the top-level surface, "
    "or with subcommand='<name>' for that subcommand's full --help. All "
    "real work happens via Bash: `telos-md <subcommand> [--json] [opts]`. "
    "This MCP server is razor-thin by design."
)


HELP_TOOL = Tool(
    name="help",
    description=HELP_DESCRIPTION,
    inputSchema={
        "type": "object",
        "properties": {
            "subcommand": {
                "type": "string",
                "description": (
                    "Optional subcommand name (e.g. 'tick', 'set-north-star', "
                    "'promote'). When set, returns that subcommand's full "
                    "--help. When omitted, returns the top-level command tree."
                ),
            },
        },
    },
)


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [HELP_TOOL]


def _capture_help(argv: list[str]) -> str:
    """Run the Typer app with the given argv, capturing --help stdout."""
    from .cli import app

    # Typer/Click exit(0) after printing --help. Capture and convert.
    buf = io.StringIO()
    real_stdout = sys.stdout
    sys.stdout = buf
    try:
        try:
            app(argv, standalone_mode=False)
        except SystemExit:
            pass
        except Exception as e:
            return f"error rendering help: {type(e).__name__}: {e}"
    finally:
        sys.stdout = real_stdout
    return buf.getvalue()


def _build_top_level_help() -> str:
    """Return the canonical telos-md surface description.

    Hand-curated so the SESSION-START framing is right; subcommand list
    derived from Typer's introspection so it doesn't drift.
    """
    from .cli import app

    # Pull subcommand names from the Typer app
    commands = []
    for cmd in app.registered_commands:
        commands.append((cmd.name or cmd.callback.__name__, cmd.help or ""))
    groups = []
    for g in app.registered_groups:
        groups.append((g.name, g.typer_instance.info.help or ""))

    lines = [
        "telos-md — Custodian of the project's telos. Drift-guard for earned commitments.",
        "",
        "USAGE:  telos-md <subcommand> [--json] [options]",
        "",
        "CUSTODY (open / close the contract):",
        "  telos-md set-north-star   # register a goal; returns north_star_id",
        "  telos-md close            # discharge with an outcome",
        "",
        "DRIFT (per-iteration):",
        "  telos-md tick             # report one iteration; returns heading + signal",
        "",
        "META (introspection + self-improvement):",
        "  telos-md patterns         # inspect the seed + promoted pattern library",
        "  telos-md traffic          # list open north stars for a repo",
        "  telos-md hypothesize      # propose competing candidates (step 1 of 4)",
        "  telos-md trial-status     # read trial pool state (step 2 of 4)",
        "  telos-md promote          # promote a trial winner (step 4 of 4; gated)",
        "  telos-md reload           # re-import patterns/store/llm in the running process",
        "",
        "MCP:",
        "  telos-md mcp serve        # boots this MCP server (you're talking to it now)",
    ]
    return "\n".join(lines) + (
        "\n\nDRILL IN:    telos-md <subcommand> --help    "
        "OR    mcp__telos__help(subcommand='<name>')\n"
        "JSON MODE:   add --json to any subcommand for machine-readable output"
    )


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name != "help":
        return [TextContent(type="text", text=f"unknown tool: {name!r}")]
    sub = (arguments or {}).get("subcommand")
    if sub:
        # Drill down: render `telos-md <sub> --help` text.
        text = _capture_help([sub, "--help"])
        if not text.strip():
            text = f"no help available for subcommand {sub!r}"
        return [TextContent(type="text", text=text)]
    return [TextContent(type="text", text=_build_top_level_help())]


async def _main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream, write_stream, server.create_initialization_options()
        )


def run() -> None:
    """Entry point used by ``telos-md mcp serve``."""
    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        sys.exit(0)
