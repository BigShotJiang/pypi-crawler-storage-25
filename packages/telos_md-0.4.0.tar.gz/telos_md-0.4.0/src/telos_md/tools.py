"""MCP tool definitions and dispatcher for telos_md.

This file is the MCP-facing layer only. All business logic lives in
``telos_md._logic`` (see Stage A refactor v0.3.x). The dispatcher
(``handle_tool`` / ``_handle_tool_inner``) routes named tool calls into
the pure-logic functions and wraps them with per-repo MCP-call logging.

Tools (9):

- telos_set_north_star   — register a goal (one-shot)
- telos_tick              — report an iteration; get heading + signal
- telos_close             — terminal close with outcome
- telos_hypothesize       — draft N competing candidates
- telos_trial_status      — read the trial pool state
- telos_patterns          — read-only inspection of the pattern library
- telos_traffic           — list open north stars for a repo
- telos_reload            — re-import patterns / store / llm
- telos_promote           — promote a trial winner (gated)
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path as _PathLogger

from mcp.types import Tool

from . import store
from ._logic import hypotheses as _hypotheses
from ._logic import loop as _loop
from ._logic import meta as _meta


# ── MCP-call logging (per-repo audit trail) ───────────────────────────────────


def _resolve_repo_for_logging(name: str, arguments: dict):
    """Figure out which repo an MCP call belongs to, for per-repo logging.

    1. Explicit `repo_path` in arguments.
    2. `north_star_id` — look up the NS's yaml file to find its repo.
    Returns None for unscoped operational calls.
    """
    repo = arguments.get("repo_path")
    if repo:
        return repo
    nsid = arguments.get("north_star_id")
    if nsid:
        ns = store.get_north_star(nsid)
        if ns and ns.get("repo_path"):
            return ns["repo_path"]
    return None


def _log_mcp_call(name, arguments, result, error, started_at):
    """Append an MCP call to <repo>/.telos/log/YYYY-MM-DD.jsonl.

    Per-repo, append-only JSONL. Inbound arguments + outbound result
    (or error) per line. Lets future sessions measure organic
    applications, calibrate thresholds against real data, and detect
    systemic false positives across the log."""
    repo = _resolve_repo_for_logging(name, arguments)
    if not repo:
        return
    date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    log_dir = _PathLogger(repo) / ".telos" / "log"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
    except OSError:
        return
    log_file = log_dir / f"{date}.jsonl"
    entry = {
        "started_at": started_at,
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "tool": name,
        "arguments": arguments,
        "result": result,
        "error": error,
    }
    try:
        with log_file.open("a") as f:
            f.write(json.dumps(entry, default=str) + "\n")
    except OSError:
        pass  # logging is best-effort; must not break the tool call


# ── MCP tool descriptors (the static `tools/list` response) ───────────────────


TOOLS: list[Tool] = [
    Tool(
        name="telos_set_north_star",
        description=(
            "Register a north star — a goal for multi-step autonomous work. "
            "Returns a north_star_id used in subsequent tick calls."
        ),
        inputSchema={
            "type": "object",
            "required": ["goal"],
            "properties": {
                "goal": {
                    "type": "string",
                    "description": "What this loop/trilogy-flow is trying to accomplish.",
                },
                "metric": {
                    "type": "string",
                    "description": "How success is measured. Free-text.",
                },
                "stop_max_iters": {
                    "type": "integer",
                    "description": "Hard cap on iterations.",
                },
                "stop_zero_delta_n": {
                    "type": "integer",
                    "description": "Stop after N consecutive zero-delta ticks. Default 3.",
                },
                "signature": {
                    "type": "string",
                    "description": "Optional hash of the work type; used for collision detection.",
                },
                "repo_path": {
                    "type": "string",
                    "description": "Absolute path to the repo this loop operates on. When set, telos_md reads <repo>/telos_md/AUTONOMY.md on every tick and surfaces settled decisions in reasoning.",
                },
            },
        },
    ),
    Tool(
        name="telos_tick",
        description=(
            "Report one iteration. Returns heading (on course / drifting / "
            "reversed / converged), a drift_category if a pattern matches, "
            "a signal (continue/pivot/stop), and short reasoning."
        ),
        inputSchema={
            "type": "object",
            "required": ["north_star_id", "action_summary", "measurement"],
            "properties": {
                "north_star_id": {"type": "string"},
                "action_summary": {
                    "type": "string",
                    "description": "~1 sentence on what this iteration did.",
                },
                "measurement": {
                    "description": "Current value of the declared metric. Numeric or string."
                },
                "signature": {
                    "type": "string",
                    "description": "Classify the action type (e.g., 'heuristic-tighten', 'product-code').",
                },
                "model": {
                    "type": "string",
                    "description": "Which model produced this iteration. Enables fleet-diversity signals.",
                },
                "override_stop": {
                    "type": "boolean",
                    "description": "When true, proceed even if the prior tick returned signal=stop. Overriding is audited: frequent overrides are evidence the stop heuristic misfired.",
                },
                "repo_path": {
                    "type": "string",
                    "description": "Absolute path to the repo. Telos is per-repo: state is read from and written to <repo>/.telos/cache.db and related files. Cross-repo aggregation is never implicit.",
                },
            },
        },
    ),
    Tool(
        name="telos_close",
        description=(
            "Close a north star with a terminal outcome. Outcome must be "
            "one of: reached, abandoned, converged, pivoted. Closing "
            "triggers empirical-validation metrics for any trial candidates "
            "that were applied during this loop."
        ),
        inputSchema={
            "type": "object",
            "required": ["north_star_id", "outcome"],
            "properties": {
                "north_star_id": {"type": "string"},
                "outcome": {
                    "type": "string",
                    "enum": ["reached", "abandoned", "converged", "pivoted"],
                },
                "notes": {"type": "string"},
                "repo_path": {
                    "type": "string",
                    "description": "Absolute path to the repo. Telos is per-repo; supply the repo and the close writes to <repo>/.telos/cache.db + north_stars/<nsid>.yaml.",
                },
            },
        },
    ),
    Tool(
        name="telos_hypothesize",
        description=(
            "Self-improvement step 1 of 4. Draft N competing candidates for "
            "a kind of artifact (pattern_name, counter_action, refinement, "
            "philosophy_revision, deprecation). Candidates auto-enroll in a "
            "trial pool — no human ratification. Returns trial_id."
        ),
        inputSchema={
            "type": "object",
            "required": ["kind", "context"],
            "properties": {
                "kind": {
                    "type": "string",
                    "enum": [
                        "pattern_name",
                        "counter_action",
                        "refinement",
                        "philosophy_revision",
                        "deprecation",
                    ],
                },
                "context": {
                    "type": "string",
                    "description": "Evidence motivating the hypothesis — e.g., the recurring divergence signature the meta-loop surfaced.",
                },
                "n_candidates": {
                    "type": "integer",
                    "description": "How many competing candidates to draft. Default 3.",
                },
                "model": {
                    "type": "string",
                    "description": "Which model to ask. Omit for default.",
                },
                "target_pattern": {
                    "type": "string",
                    "description": "For kind=refinement or counter_action: the parent pattern name this candidate modifies (e.g. 'heuristic-ratchet'). Scopes attribution.",
                },
                "target_drift_category": {
                    "type": "string",
                    "description": "For kind=refinement or counter_action: the drift_category this candidate targets. Refinement candidates only accrue applications on ticks where drift_category matches.",
                },
                "repo_path": {
                    "type": "string",
                    "description": "Absolute path to the watched repo. When set, candidates are also written to <repo>/.telos/trials/<trial_id>/<candidate_id>.md — the repo becomes the durable source of truth.",
                },
                "candidates": {
                    "type": "array",
                    "description": "Caller-provided heterogeneous candidates. When present, telos_md skips its built-in (Claude-only) drafting and uses these directly. Preferred path: the caller fans out across 3+ model families via pal/mcp and submits the union here.",
                    "items": {
                        "type": "object",
                        "required": ["text", "authored_by"],
                        "properties": {
                            "text": {"type": "string"},
                            "reasoning": {"type": "string"},
                            "authored_by": {"type": "string"},
                            "target_pattern": {"type": "string"},
                            "target_drift_category": {"type": "string"},
                            "regression_test": {
                                "type": "string",
                                "description": "pytest path (e.g. 'tests/test_x.py::test_y') that must pass at promote time. When set, telos_promote runs this test via subprocess and refuses promotion if it fails.",
                            },
                            "cross_model_review": {
                                "type": "string",
                                "description": 'JSON blob (or verdict=approved;reasoning=... form) from a non-Claude model review via pal_codereview or similar. Required for pattern_name/refinement/counter_action/philosophy_revision kinds to pass the promote gate. Example: {"reviewer_model": "openai/gpt-5.2", "verdict": "approved", "reasoning": "", "reviewed_at": "2026-04-20T..."}',
                            },
                        },
                    },
                },
            },
        },
    ),
    Tool(
        name="telos_trial_status",
        description="Read the state of an active trial. Read-only.",
        inputSchema={
            "type": "object",
            "required": ["trial_id"],
            "properties": {"trial_id": {"type": "string"}},
        },
    ),
    Tool(
        name="telos_patterns",
        description=(
            "Read-only inspection of the pattern library. Returns the "
            "seed patterns shipped in code plus any promoted patterns "
            "recorded in <repo>/.telos/promoted/. Useful for pods "
            "that want to know what drift modes telos_md can name "
            "without reading source."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "repo_path": {
                    "type": "string",
                    "description": "Optional repo path — when provided, includes the repo's promoted-pattern artifacts alongside the seed library.",
                },
            },
        },
    ),
    Tool(
        name="telos_traffic",
        description=(
            "List the open north stars for a repo. Per-repo (telos_md "
            "never scans across repos implicitly). Returns active NSes "
            "with iteration counts, last signal, and fleet_diversity of "
            "their tick history."
        ),
        inputSchema={
            "type": "object",
            "required": ["repo_path"],
            "properties": {
                "repo_path": {"type": "string"},
            },
        },
    ),
    Tool(
        name="telos_reload",
        description=(
            "Re-import telos_md's own modules (patterns, store) from disk "
            "in the running MCP server process. Lets code changes take "
            "effect without restarting Claude Code. Auto-invoked at the "
            "end of every successful telos_promote."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
    Tool(
        name="telos_promote",
        description=(
            "Self-improvement step 4 of 4. Called by the meta-loop when a "
            "candidate has passed the promotion bar. Marks the winner, "
            "deprecates competitors, and — when repo_path is provided — "
            "writes durable artifacts: <repo>/telos_md/promoted/<id>.md "
            "and appends to <repo>/telos_md/AUTONOMY.md. AUTONOMY.md "
            "records autonomy earned on the project so future pods stop "
            "re-asking about settled decisions."
        ),
        inputSchema={
            "type": "object",
            "required": ["candidate_id"],
            "properties": {
                "candidate_id": {"type": "string"},
                "repo_path": {
                    "type": "string",
                    "description": "Absolute path to a repo. When set, telos_md writes durable promotion artifacts under <repo>/telos_md/.",
                },
            },
        },
    ),
]


# ── Dispatcher ────────────────────────────────────────────────────────────────


async def handle_tool(name: str, arguments: dict):
    """MCP dispatcher with per-repo logging wrapper.

    Every call inbound and its outbound result (or error) get appended
    to <repo>/.telos/log/YYYY-MM-DD.jsonl for the repo the call
    belongs to. Unscoped operational calls (reload, no-args patterns)
    are not logged — they have no per-repo home.
    """
    started = datetime.now(timezone.utc).isoformat()
    result = None
    error = None
    try:
        result = await _handle_tool_inner(name, arguments)
        return result
    except Exception as e:
        error = {"type": type(e).__name__, "message": str(e)}
        raise
    finally:
        try:
            _log_mcp_call(name, arguments, result, error, started)
        except Exception:
            pass  # logging failure must never propagate


async def _handle_tool_inner(name: str, arguments: dict):
    """Route an inbound MCP tool call to the corresponding _logic function.

    Thin shim — all business logic lives in `telos_md._logic`.
    """
    if name == "telos_set_north_star":
        return _loop.set_north_star(**arguments)

    if name == "telos_tick":
        return _loop.tick(**arguments)

    if name == "telos_close":
        return _loop.close(**arguments)

    if name == "telos_hypothesize":
        return _hypotheses.hypothesize(**arguments)

    if name == "telos_trial_status":
        return _hypotheses.trial_status(**arguments)

    if name == "telos_patterns":
        return _meta.patterns_library(**arguments)

    if name == "telos_traffic":
        return _meta.traffic(**arguments)

    if name == "telos_reload":
        return _meta.reload(**arguments)

    if name == "telos_promote":
        return _meta.promote(**arguments)

    raise ValueError(f"unknown tool: {name!r}")
