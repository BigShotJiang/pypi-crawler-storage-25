"""File-based state for telos_md.

Every project's state lives under ``<repo>/.telos/``:

- ``config.yaml`` — project UUID + metadata (matches .ike/ike.json and
  .visionlog/config.yaml conventions)
- ``AUTONOMY.md`` — settled decisions earned by this project
- ``north_stars/<nsid>.yaml`` — per-NS config + outcome
- ``north_stars/<nsid>/ticks.jsonl`` — append-only tick log
- ``north_stars/<nsid>/applications.jsonl`` — tick→candidate applications
- ``trials/<trial_id>/<candidate_id>.md`` — candidate + metrics in
  YAML frontmatter (applications, signal_outcome_score, etc.)
- ``promoted/<date>-<candidate_id>.md`` — durable promotion records

Cross-project: only ``~/.telos/projects.yaml`` exists, and only as
a directory of known repo paths for tools like the self-audit cron to
enumerate. It holds no state; it is rebuildable by scanning for
``<repo>/.telos/config.yaml`` files.

No SQLite. No binary state files. Every artifact is git-diffable.
"""

from __future__ import annotations

import json
import os
import tempfile
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

VALID_OUTCOMES = ("reached", "abandoned", "converged", "pivoted")
VALID_SIGNALS = ("continue", "pivot", "stop")
APPLICABLE_KINDS = ("pattern_name", "counter_action", "refinement")

PROMOTE_MIN_APPLICATIONS = 5
PROMOTE_MIN_CORR = 0.2
PROMOTE_MIN_LIFT = 0.4

# Kinds that require a non-Claude cross-model review before promotion.
# The tool's own monolithic-loop pattern applies to its own library —
# claude-authored patterns getting promoted without external eyeballing
# is exactly the drift mode the tool critiques in others.
KINDS_REQUIRING_CROSS_MODEL_REVIEW = (
    "pattern_name",
    "refinement",
    "counter_action",
    "philosophy_revision",
)


class PromotionBlocked(Exception):
    def __init__(self, reason: str, detail: dict):
        super().__init__(reason)
        self.reason = reason
        self.detail = detail


class StopSignalIgnored(Exception):
    pass


class LoopBudgetExceeded(Exception):
    pass


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _lh(repo_path: str) -> Path:
    return Path(repo_path) / ".telos"


def _atomic_write(path: Path, content: str) -> None:
    """Write a file atomically via tempfile + rename. Safe under crashes
    and concurrent readers."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp-", text=True)
    try:
        with os.fdopen(fd, "w") as f:
            f.write(content)
        os.replace(tmp, str(path))
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _yaml_val(v) -> str:
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    return '"' + str(v).replace('"', '\\"') + '"'


def _parse_yaml_flat(text: str) -> dict:
    """Parse a flat key: value YAML string. Values are scalars only."""
    d: dict = {}
    for line in text.splitlines():
        if ":" not in line or line.strip().startswith("#"):
            continue
        k, _, v = line.partition(":")
        k = k.strip()
        v = v.strip()
        if v in ("null", ""):
            d[k] = None
        elif v == "true":
            d[k] = True
        elif v == "false":
            d[k] = False
        elif v.startswith('"') and v.endswith('"'):
            d[k] = v[1:-1].replace('\\"', '"')
        else:
            try:
                d[k] = int(v)
            except ValueError:
                try:
                    d[k] = float(v)
                except ValueError:
                    d[k] = v
    return d


# ---------------------------------------------------------------------------
# Project identity
# ---------------------------------------------------------------------------


def ensure_project(repo_path: str) -> str:
    """Return the project_id for repo_path, creating it if absent.

    Writes ``<repo>/.telos/config.yaml`` with a stable UUID. That's
    the entire scope of project identity. Telos has no user-level
    registry, no cross-repo index, no knowledge of any other project.
    """
    repo = Path(repo_path).resolve()
    config = _lh(str(repo)) / "config.yaml"
    if config.exists():
        d = _parse_yaml_flat(config.read_text())
        pid = d.get("id")
        if pid:
            return pid
    pid = str(uuid.uuid4())
    config.parent.mkdir(parents=True, exist_ok=True)
    _atomic_write(
        config, (f'id: "{pid}"\nproject: "{repo.name}"\ncreated: "{_now()}"\n')
    )
    return pid


# ---------------------------------------------------------------------------
# North stars
# ---------------------------------------------------------------------------


def register_north_star(
    goal: str,
    metric: Optional[str] = None,
    stop_max_iters: Optional[int] = None,
    stop_zero_delta_n: int = 3,
    signature: Optional[str] = None,
    repo_path: Optional[str] = None,
    # Accept legacy db_path as an alias for repo_path to ease tests.
    db_path: Optional[Path] = None,
) -> str:
    repo_path = _resolve_repo(repo_path, db_path)
    nsid = f"ns_{uuid.uuid4().hex[:12]}"
    project_id = ensure_project(repo_path)
    _write_north_star_file(
        repo_path,
        nsid,
        {
            "id": nsid,
            "project_id": project_id,
            "goal": goal,
            "metric": metric,
            "stop_max_iters": stop_max_iters,
            "stop_zero_delta_n": stop_zero_delta_n,
            "signature": signature,
            "created_at": _now(),
            "closed_at": None,
            "outcome": None,
            "repo_path": repo_path,
        },
    )
    return nsid


def _resolve_repo(repo_path: Optional[str], db_path) -> str:
    """Tests pass db_path for compatibility; treat it as a repo. Production
    callers pass repo_path directly."""
    if repo_path:
        return repo_path
    if db_path:
        return _resolve_repo_loose(db_path)
    raise ValueError("repo_path required — telos_md is per-repo")


def _resolve_repo_loose(db_path) -> str:
    """Loose resolution: db_path can be a SQLite file path (legacy) or a
    directory. Directory → use as-is. File with suffix → use parent."""
    p = Path(str(db_path))
    return str(p.parent) if p.suffix else str(p)


def _ns_file(repo: str, nsid: str) -> Path:
    return _lh(repo) / "north_stars" / f"{nsid}.yaml"


def _write_north_star_file(repo: str, nsid: str, data: dict) -> None:
    out = _ns_file(repo, nsid)
    lines = []
    for k in (
        "id",
        "project_id",
        "goal",
        "metric",
        "stop_max_iters",
        "stop_zero_delta_n",
        "signature",
        "created_at",
        "closed_at",
        "outcome",
        "repo_path",
        "notes",
    ):
        if k in data:
            lines.append(f"{k}: {_yaml_val(data.get(k))}")
    _atomic_write(out, "\n".join(lines) + "\n")


def get_north_star(
    north_star_id: str, repo_path: Optional[str] = None, db_path: Optional[Path] = None
) -> Optional[dict]:
    repo = repo_path or (_resolve_repo_loose(db_path) if db_path else None)
    if repo:
        f = _ns_file(repo, north_star_id)
        if f.exists():
            return _parse_yaml_flat(f.read_text())
        return None
    # Telos is per-repo. If the caller didn't supply a repo, we
    # cannot guess. Return None so callers fall through to clear
    # error paths rather than silently scanning other projects.
    return None


def active_north_stars(
    repo_path: Optional[str] = None, db_path: Optional[Path] = None
) -> list[dict]:
    repo = _resolve_repo(repo_path, db_path)
    ns_dir = _lh(repo) / "north_stars"
    if not ns_dir.exists():
        return []
    out = []
    for f in sorted(ns_dir.glob("*.yaml")):
        d = _parse_yaml_flat(f.read_text())
        if not d.get("closed_at"):
            out.append(d)
    return out


def close_north_star(
    north_star_id: str,
    outcome: str,
    notes: Optional[str] = None,
    repo_path: Optional[str] = None,
    db_path: Optional[Path] = None,
) -> dict:
    if outcome not in VALID_OUTCOMES:
        raise ValueError(f"outcome must be one of {VALID_OUTCOMES}; got {outcome!r}")
    repo = repo_path or (_resolve_repo_loose(db_path) if db_path else None)
    ns = get_north_star(north_star_id, repo_path=repo)
    if ns is None:
        raise ValueError(f"unknown north_star {north_star_id}")
    if ns.get("closed_at"):
        raise ValueError(f"north_star {north_star_id} already closed")
    repo = ns.get("repo_path") or repo
    if not repo:
        raise ValueError("cannot locate north star's repo")
    ns["closed_at"] = _now()
    ns["outcome"] = outcome
    if notes is not None:
        ns["notes"] = notes
    _write_north_star_file(repo, north_star_id, ns)
    updated = _recompute_candidate_metrics_for_loop(repo, north_star_id)
    return {
        "north_star_id": north_star_id,
        "outcome": outcome,
        "notes": notes,
        "candidates_updated": updated,
    }


# ---------------------------------------------------------------------------
# Ticks
# ---------------------------------------------------------------------------


def record_tick(
    north_star_id: str,
    action_summary: str,
    measurement,
    *,
    signature: Optional[str] = None,
    model: Optional[str] = None,
    heading: Optional[str] = None,
    drift_category: Optional[str] = None,
    signal: Optional[str] = None,
    override_stop: bool = False,
    repo_path: Optional[str] = None,
    db_path: Optional[Path] = None,
) -> int:
    repo = repo_path or (_resolve_repo_loose(db_path) if db_path else None)
    ns = get_north_star(north_star_id, repo_path=repo)
    if ns is None:
        raise ValueError(f"unknown north_star {north_star_id}")
    if ns.get("closed_at"):
        raise ValueError(f"north_star {north_star_id} is closed; no further ticks")
    repo = ns.get("repo_path") or repo
    if not repo:
        raise ValueError("cannot locate north star's repo")
    # Check stop / budget pre-conditions from the tick log.
    ticks = _read_tick_log(repo, north_star_id)
    last = ticks[-1] if ticks else None
    iteration = len(ticks) + 1
    max_iters = ns.get("stop_max_iters")
    if max_iters is not None and iteration > int(max_iters):
        raise LoopBudgetExceeded(
            f"iteration {iteration} exceeds stop_max_iters={max_iters} "
            f"for {north_star_id}; close the loop or register a new one"
        )
    if last and last.get("signal") == "stop" and not override_stop:
        raise StopSignalIgnored(
            f"previous tick on {north_star_id} returned signal=stop; "
            f"close the loop, or tick again with override_stop=true to "
            f"explicitly proceed against telos_md's advice"
        )
    tick = {
        "tick_id": iteration,
        "iteration": iteration,
        "north_star_id": north_star_id,
        "action_summary": action_summary,
        "measurement": measurement,
        "signature": signature,
        "model": model,
        "heading": heading,
        "drift_category": drift_category,
        "signal": signal,
        "created_at": _now(),
    }
    _append_tick_file(repo, north_star_id, tick)
    if drift_category is not None:
        _apply_candidates(repo, north_star_id, iteration, drift_category)
    return iteration


def _tick_path(repo: str, nsid: str) -> Path:
    return _lh(repo) / "north_stars" / nsid / "ticks.jsonl"


def _app_path(repo: str, nsid: str) -> Path:
    return _lh(repo) / "north_stars" / nsid / "applications.jsonl"


def _append_tick_file(repo: str, nsid: str, tick: dict) -> None:
    out = _tick_path(repo, nsid)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("a") as f:
        f.write(json.dumps(tick, default=str) + "\n")


def _append_application_file(repo: str, nsid: str, application: dict) -> None:
    out = _app_path(repo, nsid)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("a") as f:
        f.write(json.dumps(application, default=str) + "\n")


def _read_tick_log(repo: str, nsid: str) -> list[dict]:
    p = _tick_path(repo, nsid)
    if not p.exists():
        return []
    return [json.loads(ln) for ln in p.read_text().splitlines() if ln.strip()]


def recent_ticks(
    north_star_id: str,
    n: int = 10,
    repo_path: Optional[str] = None,
    db_path: Optional[Path] = None,
) -> list[dict]:
    repo = repo_path or (_resolve_repo_loose(db_path) if db_path else None)
    if repo is None:
        ns = get_north_star(north_star_id)
        repo = ns.get("repo_path") if ns else None
    if not repo:
        return []
    ticks = _read_tick_log(repo, north_star_id)
    return ticks[-n:]


def _apply_candidates(repo: str, nsid: str, tick_id: int, drift_category: str) -> None:
    """For every trialing candidate in this repo, record an application
    if the candidate's attribution rule matches."""
    trials_dir = _lh(repo) / "trials"
    if not trials_dir.exists():
        return
    already = _read_application_candidates(repo, nsid, tick_id)
    for cand_file in trials_dir.glob("*/*.md"):
        d = _parse_candidate_file(cand_file)
        if d.get("status") != "trialing":
            continue
        kind = d.get("kind")
        if kind not in APPLICABLE_KINDS:
            continue
        if kind == "refinement":
            if d.get("target_drift_category") != drift_category:
                continue
        cid = d.get("candidate_id")
        if cid in already:
            continue
        _append_application_file(
            repo,
            nsid,
            {
                "tick_id": tick_id,
                "candidate_id": cid,
                "drift_category": drift_category,
                "created_at": _now(),
            },
        )
        # Bump the candidate's applications counter in its frontmatter.
        _update_candidate_fields(
            cand_file,
            {
                "applications": (d.get("applications") or 0) + 1,
            },
        )


def _read_application_candidates(repo: str, nsid: str, tick_id: int) -> set[str]:
    p = _app_path(repo, nsid)
    if not p.exists():
        return set()
    out: set[str] = set()
    for ln in p.read_text().splitlines():
        if not ln.strip():
            continue
        d = json.loads(ln)
        if d.get("tick_id") == tick_id:
            out.add(d.get("candidate_id"))
    return out


# ---------------------------------------------------------------------------
# Trials
# ---------------------------------------------------------------------------


def insert_trial_candidates(
    kind: str,
    candidates: list[dict],
    repo_path: Optional[str] = None,
    db_path: Optional[Path] = None,
) -> str:
    repo = _resolve_repo(repo_path, db_path)
    ensure_project(repo)
    trial_id = f"tr_{uuid.uuid4().hex[:12]}"
    for cand in candidates:
        cid = f"cd_{uuid.uuid4().hex[:10]}"
        cand["candidate_id"] = cid
        path = _lh(repo) / "trials" / trial_id / f"{cid}.md"
        path.parent.mkdir(parents=True, exist_ok=True)
        _atomic_write(
            path,
            _render_candidate_file(
                {
                    "candidate_id": cid,
                    "trial_id": trial_id,
                    "kind": kind,
                    "authored_by": cand.get("authored_by", ""),
                    "target_pattern": cand.get("target_pattern", ""),
                    "target_drift_category": cand.get("target_drift_category", ""),
                    "regression_test": cand.get("regression_test", ""),
                    "cross_model_review": cand.get("cross_model_review", ""),
                    "created_at": _now(),
                    "status": "trialing",
                    "applications": 0,
                    "signal_outcome_score": None,
                    "null_baseline_score": None,
                    "reference_rate": None,
                    "promoted_at": "",
                    "text": cand["text"],
                    "reasoning": cand.get("reasoning", ""),
                }
            ),
        )
    return trial_id


def _render_candidate_file(d: dict) -> str:
    frontmatter = "\n".join(
        f"{k}: {_yaml_val(d.get(k))}"
        for k in (
            "candidate_id",
            "trial_id",
            "kind",
            "authored_by",
            "target_pattern",
            "target_drift_category",
            "regression_test",
            "cross_model_review",
            "created_at",
            "status",
            "applications",
            "signal_outcome_score",
            "null_baseline_score",
            "reference_rate",
            "promoted_at",
            "staged",  # per ADR-004: flags promotions whose applications were author-scripted
        )
    )
    return (
        f"---\n{frontmatter}\n---\n\n"
        f"## Candidate text\n\n{d['text']}\n\n"
        f"## Reasoning\n\n{d.get('reasoning', '')}\n"
    )


def _parse_candidate_file(path: Path) -> dict:
    text = path.read_text()
    if not text.startswith("---\n"):
        return {"text": text, "reasoning": ""}
    try:
        _, frontmatter, body = text.split("---\n", 2)
    except ValueError:
        return {"text": text, "reasoning": ""}
    d = _parse_yaml_flat(frontmatter)
    # Back-compat alias.
    if "signal_outcome_score" in d and "signal_outcome_corr" not in d:
        d["signal_outcome_corr"] = d["signal_outcome_score"]
    sections = {"text": "", "reasoning": ""}
    current = None
    buf: list[str] = []
    for ln in body.splitlines():
        if ln.startswith("## Candidate text"):
            if current and buf:
                sections[current] = "\n".join(buf).strip()
            current, buf = "text", []
        elif ln.startswith("## Reasoning"):
            if current and buf:
                sections[current] = "\n".join(buf).strip()
            current, buf = "reasoning", []
        elif current:
            buf.append(ln)
    if current and buf:
        sections[current] = "\n".join(buf).strip()
    d.update(sections)
    return d


def _update_candidate_fields(path: Path, updates: dict) -> None:
    d = _parse_candidate_file(path)
    d.update(updates)
    _atomic_write(path, _render_candidate_file(d))


def _find_candidate_file(repo: str, candidate_id: str) -> Optional[Path]:
    for f in (_lh(repo) / "trials").rglob(f"{candidate_id}.md"):
        return f
    return None


def trial_candidates(
    trial_id: str,
    repo_path: Optional[str] = None,
    db_path: Optional[Path] = None,
) -> list[dict]:
    repo = _resolve_repo(repo_path, db_path)
    trial_dir = _lh(repo) / "trials" / trial_id
    if not trial_dir.exists():
        return []
    files = sorted(
        trial_dir.glob("*.md"),
        key=lambda p: _parse_candidate_file(p).get("created_at", ""),
    )
    return [_parse_candidate_file(f) for f in files]


# ---------------------------------------------------------------------------
# Metrics + promotion
# ---------------------------------------------------------------------------


def _parse_cross_model_review(review: str) -> Optional[str]:
    """Return the verdict ('approved' / 'rejected' / ...) from the
    stored review blob, or None if unparseable or absent. Accepts
    JSON or a simple 'verdict=approved' key=value form."""
    if not review:
        return None
    review = review.strip()
    if review.startswith("{"):
        try:
            d = json.loads(review)
            return str(d.get("verdict", "")) or None
        except json.JSONDecodeError:
            return None
    # Key=value fallback.
    for part in review.split(";"):
        if "=" in part:
            k, _, v = part.partition("=")
            if k.strip().lower() == "verdict":
                return v.strip().strip('"')
    return None


def _signal_validated(signal: Optional[str], outcome: str) -> Optional[bool]:
    if signal is None:
        return None
    if signal == "pivot":
        return outcome in ("pivoted", "converged")
    if signal == "stop":
        return outcome == "converged"
    if signal == "continue":
        return outcome == "reached"
    return None


def _null_baseline_score(
    applications: list[tuple[Optional[str], str]],
) -> Optional[float]:
    if not applications:
        return None
    total = 0.0
    count = 0
    for _sig, outcome in applications:
        accum = 0
        scorable = 0
        for s in VALID_SIGNALS:
            v = _signal_validated(s, outcome)
            if v is None:
                continue
            scorable += 1
            accum += 1 if v else -1
        if scorable:
            total += accum / scorable
            count += 1
    return (total / count) if count else None


def _recompute_candidate_metrics_for_loop(repo: str, north_star_id: str) -> list[dict]:
    """After a north star closes, refresh metrics for every candidate
    applied during the loop. Pure file scans."""
    apps = _read_applications_for_ns(repo, north_star_id)
    if not apps:
        return []
    cand_ids = sorted({a["candidate_id"] for a in apps})
    updated = []
    for cid in cand_ids:
        cand_file = _find_candidate_file(repo, cid)
        if cand_file is None:
            continue
        # Build the candidate's scored applications across ALL closed NSes
        # in this repo — one evidence point per (candidate, loop), taking
        # the last-applied tick's signal in each loop.
        pairs = _pairs_for_candidate(repo, cid)
        total = 0
        validated = 0
        invalidated = 0
        for _sig, _out in pairs:
            v = _signal_validated(_sig, _out)
            if v is None:
                continue
            total += 1
            if v:
                validated += 1
            else:
                invalidated += 1
        score = ((validated - invalidated) / total) if total else None
        null_base = _null_baseline_score(pairs) if pairs else None
        d = _parse_candidate_file(cand_file)
        created = d.get("created_at", "")
        loops_seen = len(
            {
                pair_id
                for pair_id, _ in _iter_candidate_loops(repo, cid)
                if _is_ns_closed(repo, pair_id)
            }
        )
        loops_possible = sum(
            1 for ns in _iter_closed_ns(repo) if (ns.get("closed_at") or "") >= created
        )
        ref_rate = (loops_seen / loops_possible) if loops_possible > 0 else 0.0
        _update_candidate_fields(
            cand_file,
            {
                "applications": d.get("applications", 0),
                "signal_outcome_score": score,
                "null_baseline_score": null_base,
                "reference_rate": ref_rate,
            },
        )
        updated.append(
            {
                "candidate_id": cid,
                "applications_scored": total,
                "signal_outcome_score": score,
                "null_baseline_score": null_base,
                "signal_lift": (score - null_base)
                if (score is not None and null_base is not None)
                else None,
                "reference_rate": ref_rate,
            }
        )
    return updated


def _read_applications_for_ns(repo: str, nsid: str) -> list[dict]:
    p = _app_path(repo, nsid)
    if not p.exists():
        return []
    return [json.loads(ln) for ln in p.read_text().splitlines() if ln.strip()]


def _iter_candidate_loops(repo: str, candidate_id: str):
    """Yield (nsid, last_tick_id) for every loop in which the candidate
    was applied. Last tick wins (dedup per loop)."""
    ns_dir = _lh(repo) / "north_stars"
    if not ns_dir.exists():
        return
    for sub in ns_dir.iterdir():
        if not sub.is_dir():
            continue
        app_file = sub / "applications.jsonl"
        if not app_file.exists():
            continue
        max_tick = None
        for ln in app_file.read_text().splitlines():
            if not ln.strip():
                continue
            d = json.loads(ln)
            if d.get("candidate_id") != candidate_id:
                continue
            if max_tick is None or d["tick_id"] > max_tick:
                max_tick = d["tick_id"]
        if max_tick is not None:
            yield (sub.name, max_tick)


def _is_ns_closed(repo: str, nsid: str) -> bool:
    ns = get_north_star(nsid, repo_path=repo)
    return bool(ns and ns.get("closed_at"))


def _iter_closed_ns(repo: str):
    ns_dir = _lh(repo) / "north_stars"
    if not ns_dir.exists():
        return
    for f in ns_dir.glob("*.yaml"):
        d = _parse_yaml_flat(f.read_text())
        if d.get("closed_at"):
            yield d


def _pairs_for_candidate(
    repo: str, candidate_id: str
) -> list[tuple[Optional[str], str]]:
    """(signal, outcome) pairs — one per (candidate, closed loop)."""
    pairs = []
    for nsid, tick_id in _iter_candidate_loops(repo, candidate_id):
        ns = get_north_star(nsid, repo_path=repo)
        if not ns or not ns.get("closed_at"):
            continue
        outcome = ns.get("outcome")
        if not outcome:
            continue
        ticks = _read_tick_log(repo, nsid)
        signal = None
        for t in ticks:
            if t.get("tick_id") == tick_id or t.get("iteration") == tick_id:
                signal = t.get("signal")
                break
        pairs.append((signal, outcome))
    return pairs


def promote_candidate(
    candidate_id: str,
    repo_path: Optional[str] = None,
    db_path: Optional[Path] = None,
) -> dict:
    repo = _resolve_repo(repo_path, db_path)
    cand_file = _find_candidate_file(repo, candidate_id)
    if cand_file is None:
        raise ValueError(f"unknown candidate {candidate_id}")
    d = _parse_candidate_file(cand_file)
    if d.get("status") != "trialing":
        raise ValueError(
            f"candidate {candidate_id} is not trialing (status={d.get('status')})"
        )
    trial_id = d.get("trial_id")
    siblings = trial_candidates(trial_id, repo_path=repo)
    sibling_view = [
        {
            "candidate_id": s.get("candidate_id"),
            "applications": s.get("applications"),
            "signal_outcome_corr": s.get("signal_outcome_score"),
            "signal_outcome_score": s.get("signal_outcome_score"),
            "null_baseline_score": s.get("null_baseline_score"),
            "reference_rate": s.get("reference_rate"),
            "status": s.get("status"),
            "created_at": s.get("created_at"),
        }
        for s in siblings
    ]
    apps = d.get("applications") or 0
    corr = d.get("signal_outcome_score")
    if apps < PROMOTE_MIN_APPLICATIONS:
        raise PromotionBlocked(
            reason=f"candidate has {apps} applications; need >= {PROMOTE_MIN_APPLICATIONS}",
            detail={
                "candidate_id": candidate_id,
                "applications": apps,
                "min_required": PROMOTE_MIN_APPLICATIONS,
                "siblings": sibling_view,
            },
        )
    if corr is None or corr < PROMOTE_MIN_CORR:
        raise PromotionBlocked(
            reason=f"candidate signal_outcome_corr={corr}; need >= {PROMOTE_MIN_CORR}",
            detail={
                "candidate_id": candidate_id,
                "signal_outcome_corr": corr,
                "min_required": PROMOTE_MIN_CORR,
                "siblings": sibling_view,
            },
        )
    # Cross-model review gate. Promotions of pattern_name / refinement /
    # counter_action / philosophy_revision require an external
    # non-Claude review so telos_md doesn't promote its own blind
    # spots into its own library. Counter-the-monoculture-it-preaches.
    if d.get("kind") in KINDS_REQUIRING_CROSS_MODEL_REVIEW:
        review = d.get("cross_model_review") or ""
        verdict = _parse_cross_model_review(review)
        if verdict != "approved":
            raise PromotionBlocked(
                reason=(
                    "cross_model_review required for kind="
                    f"{d.get('kind')} — found: {verdict or 'missing'}"
                ),
                detail={
                    "candidate_id": candidate_id,
                    "kind": d.get("kind"),
                    "cross_model_review": review,
                    "siblings": sibling_view,
                    "hint": (
                        "populate with JSON: "
                        '{"reviewer_model": "openai/gpt-5.2", '
                        '"verdict": "approved", '
                        '"reasoning": "why", "reviewed_at": "..."}'
                    ),
                },
            )
    null_base = d.get("null_baseline_score")
    lift = (corr - null_base) if (null_base is not None) else None
    if lift is not None and lift < PROMOTE_MIN_LIFT:
        raise PromotionBlocked(
            reason=(
                f"candidate signal_lift={lift:.3f} (score={corr}, "
                f"null_baseline={null_base:.3f}); need lift >= {PROMOTE_MIN_LIFT}"
            ),
            detail={
                "candidate_id": candidate_id,
                "signal_outcome_corr": corr,
                "null_baseline_score": null_base,
                "signal_lift": lift,
                "min_lift_required": PROMOTE_MIN_LIFT,
                "siblings": sibling_view,
            },
        )

    def _rank_key(s: dict):
        return (
            -(
                s.get("signal_outcome_score")
                if s.get("signal_outcome_score") is not None
                else -float("inf")
            ),
            -(s.get("reference_rate") or 0.0),
            -(s.get("applications") or 0),
            s.get("created_at") or "",
        )

    my_key = _rank_key(d)
    for s in siblings:
        if s.get("candidate_id") == candidate_id:
            continue
        sk = _rank_key(s)
        if sk < my_key:
            raise PromotionBlocked(
                reason=(
                    f"sibling {s.get('candidate_id')} ranks strictly higher "
                    f"(score={s.get('signal_outcome_score')}, "
                    f"ref_rate={s.get('reference_rate')}, "
                    f"apps={s.get('applications')})"
                ),
                detail={
                    "candidate_id": candidate_id,
                    "signal_outcome_corr": corr,
                    "siblings": sibling_view,
                },
            )
        if sk == my_key:
            raise PromotionBlocked(
                reason=(
                    f"sibling {s.get('candidate_id')} is indistinguishable on "
                    f"every tiebreak (score, ref_rate, apps, created_at)."
                ),
                detail={
                    "candidate_id": candidate_id,
                    "signal_outcome_corr": corr,
                    "siblings": sibling_view,
                },
            )

    # Check again that no sibling was promoted while we were checking —
    # the file rename in _update_candidate_fields below is atomic, but
    # we still need to guarantee at-most-one-winner-per-trial.
    for s in siblings:
        if s.get("candidate_id") != candidate_id and s.get("status") == "promoted":
            raise PromotionBlocked(
                reason="trial already has a promoted winner",
                detail={
                    "candidate_id": candidate_id,
                    "trial_id": trial_id,
                    "siblings": sibling_view,
                },
            )
    _update_candidate_fields(cand_file, {"status": "promoted", "promoted_at": _now()})
    for s in siblings:
        if s.get("candidate_id") == candidate_id:
            continue
        if s.get("status") == "trialing":
            sf = _find_candidate_file(repo, s["candidate_id"])
            if sf:
                _update_candidate_fields(sf, {"status": "deprecated"})

    written = _write_promotion_artifacts(repo, d, corr, apps, sibling_view)
    return {
        "candidate_id": candidate_id,
        "signal_outcome_corr": corr,
        "applications": apps,
        "siblings": sibling_view,
        "updated_files": written,
    }


def _write_promotion_artifacts(
    repo: str,
    d: dict,
    corr: float,
    apps: int,
    sibling_view: list[dict],
) -> list[str]:
    repo_p = Path(repo)
    out_dir = _lh(repo) / "promoted"
    out_dir.mkdir(parents=True, exist_ok=True)
    date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    cid = d["candidate_id"]
    artifact = out_dir / f"{date}-{cid}.md"
    artifact.write_text(
        f"# Promoted candidate {cid}\n\n"
        f"- **Kind:** `{d.get('kind')}`\n"
        f"- **Authored by:** `{d.get('authored_by')}`\n"
        f"- **Promoted at:** {_now()}\n"
        f"- **Applications:** {apps}\n"
        f"- **signal_outcome_score:** {corr}\n"
        f"- **Reference rate:** {d.get('reference_rate')}\n\n"
        f"## Artifact text\n\n{d.get('text', '')}\n\n"
        f"## Original reasoning\n\n{d.get('reasoning', '')}\n\n"
        f"## Sibling evidence at promotion\n\n"
        + "\n".join(
            f"- `{s['candidate_id']}` status={s['status']} "
            f"apps={s['applications']} score={s.get('signal_outcome_score')}"
            for s in sibling_view
        )
        + "\n"
    )
    autonomy = _lh(repo) / "AUTONOMY.md"
    if not autonomy.exists():
        autonomy.write_text(
            "# Autonomy earned on this project\n\n"
            "Every entry below is a decision or pattern that passed "
            "telos_md's empirical-validation bar. Future pods working "
            "in this repo should treat these as settled — do not re-ask, "
            "do not re-litigate, just act consistent with them.\n\n"
            "## Promoted artifacts\n\n"
        )
    with autonomy.open("a") as f:
        f.write(
            f"- {date} — **{d.get('kind')}** `{cid}` — "
            f"score={corr}, apps={apps} "
            f"[details](promoted/{date}-{cid}.md)\n"
        )
    return [str(artifact.relative_to(repo_p)), str(autonomy.relative_to(repo_p))]


# ---------------------------------------------------------------------------
# AUTONOMY reader
# ---------------------------------------------------------------------------


def read_autonomy(repo_path: Optional[str]) -> Optional[str]:
    if not repo_path:
        return None
    try:
        p = _lh(repo_path) / "AUTONOMY.md"
        if p.exists():
            return p.read_text()
    except OSError:
        return None
    return None
