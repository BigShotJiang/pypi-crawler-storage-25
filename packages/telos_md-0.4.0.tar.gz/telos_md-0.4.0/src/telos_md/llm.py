"""LLM invocation via `claude -p` subprocess.

Per eidos-agi policy: no direct anthropic SDK. Use fixed-cost tools —
`claude -p` CLI or claude_agent_sdk. This module uses the CLI for
simplicity; it's appropriate for one-shot prompts like drafting
candidate pattern names.

If `claude` is not on PATH, hypothesize() returns a single
placeholder candidate and flags that no real LLM was consulted —
telos_md should never silently produce dummy candidates without
the consumer knowing.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from typing import Optional


def _claude_available() -> bool:
    return shutil.which("claude") is not None


def draft_candidates(
    kind: str,
    context: str,
    n: int = 3,
    model: Optional[str] = None,
) -> list[dict]:
    """Invoke claude -p with a prompt asking for N candidates.

    Returns a list of {text, reasoning, authored_by} dicts.
    When claude isn't available, returns a single placeholder dict
    with authored_by="none-available" so the caller can detect it.
    """
    if not _claude_available():
        return [
            {
                "text": f"[placeholder — no LLM available to draft a {kind}]",
                "reasoning": "claude CLI not on PATH; install claude-code or use an agent SDK path.",
                "authored_by": "none-available",
            }
        ]

    prompt = (
        f"You are proposing {n} competing candidate {kind}s for telos_md's "
        f"pattern library. Each candidate will be trialed empirically — the "
        f"best-performing one is promoted. Be terse.\n\n"
        f"Context:\n{context}\n\n"
        f"Respond with a JSON array of exactly {n} objects, each with keys "
        f'"text" (the candidate artifact itself) and "reasoning" (one sentence '
        f"on why this candidate is worth trialing). Return only the JSON — no "
        f"prose outside it."
    )
    cmd = ["claude", "-p", prompt]
    if model:
        cmd.extend(["--model", model])
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired:
        return [
            {
                "text": f"[timeout drafting a {kind}]",
                "reasoning": "claude -p timed out after 120s",
                "authored_by": model or "claude-unknown",
            }
        ]
    body = (out.stdout or "").strip()
    # Locate the JSON array in the response (claude sometimes wraps).
    start = body.find("[")
    end = body.rfind("]")
    if start == -1 or end == -1:
        return [
            {
                "text": body[:400] or f"[unparsed response for {kind}]",
                "reasoning": "claude -p returned non-JSON; inserting raw.",
                "authored_by": model or "claude-unknown",
            }
        ]
    try:
        parsed = json.loads(body[start : end + 1])
    except json.JSONDecodeError:
        return [
            {
                "text": body[:400],
                "reasoning": "claude -p returned unparseable JSON.",
                "authored_by": model or "claude-unknown",
            }
        ]
    return [
        {
            "text": str(p.get("text", "")),
            "reasoning": str(p.get("reasoning", "")),
            "authored_by": model or "claude",
        }
        for p in parsed
        if isinstance(p, dict)
    ]
