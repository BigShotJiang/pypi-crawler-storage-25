"""Telos per-repo self-audit.

Run as ``python -m telos_md.self_audit --repo /abs/path/to/repo``.
Reports:

1. Trial candidates that clear PROMOTE_MIN_APPLICATIONS / _CORR and
   are the strictly-best sibling — ready for promote_candidate().
2. North stars that are open but have emitted signal=stop or exceeded
   stop_max_iters — candidates to close.
3. Recent ticks where heading != 'on course' but drift_category was
   null — evidence of an unnamed pattern.
4. Tool-name mismatches between SPEC.md and the running tool surface.

Diagnosis only; no mutations. Destructive choices stay in pod control.
Scans ONE repo at a time — telos_md is per-repo and has no cross-project
registry. To audit multiple repos, invoke this once per repo.

Returns exit code 0 if nothing needs attention, 1 otherwise.
"""

from __future__ import annotations

import json
import sys

from . import store


def _scan_trials(repo: str) -> list[dict]:
    trials_dir = store._lh(repo) / "trials"
    if not trials_dir.exists():
        return []
    # Group candidates by trial_id.
    by_trial: dict[str, list[dict]] = {}
    for f in trials_dir.glob("*/*.md"):
        d = store._parse_candidate_file(f)
        by_trial.setdefault(d.get("trial_id"), []).append(d)
    promotable = []
    for trial_id, siblings in by_trial.items():
        for s in siblings:
            if s.get("status") != "trialing":
                continue
            apps = s.get("applications") or 0
            corr = s.get("signal_outcome_score")
            if apps < store.PROMOTE_MIN_APPLICATIONS:
                continue
            if corr is None or corr < store.PROMOTE_MIN_CORR:
                continue

            # Strictly best among trialing siblings?
            def _rank(x):
                return (
                    -(
                        x.get("signal_outcome_score")
                        if x.get("signal_outcome_score") is not None
                        else -float("inf")
                    ),
                    -(x.get("reference_rate") or 0.0),
                    -(x.get("applications") or 0),
                    x.get("created_at") or "",
                )

            my_rank = _rank(s)
            blocked = False
            for other in siblings:
                if other.get("candidate_id") == s.get("candidate_id"):
                    continue
                if _rank(other) <= my_rank:
                    blocked = True
                    break
            if not blocked:
                promotable.append(
                    {
                        "candidate_id": s.get("candidate_id"),
                        "trial_id": trial_id,
                        "kind": s.get("kind"),
                        "applications": apps,
                        "signal_outcome_score": corr,
                    }
                )
    return promotable


def _scan_stuck(repo: str) -> list[dict]:
    ns_dir = store._lh(repo) / "north_stars"
    if not ns_dir.exists():
        return []
    stuck = []
    for f in ns_dir.glob("*.yaml"):
        ns = store._parse_yaml_flat(f.read_text())
        if ns.get("closed_at"):
            continue
        nsid = ns.get("id")
        ticks = store._read_tick_log(repo, nsid)
        iters = len(ticks)
        last = ticks[-1] if ticks else None
        reason = None
        if last and last.get("signal") == "stop":
            reason = "last signal was stop"
        max_iters = ns.get("stop_max_iters")
        if max_iters is not None and iters >= int(max_iters):
            reason = f"iterations {iters} >= stop_max_iters {max_iters}"
        if reason:
            stuck.append(
                {
                    "north_star_id": nsid,
                    "goal": ns.get("goal"),
                    "iters": iters,
                    "reason": reason,
                }
            )
    return stuck


def _scan_unnamed(repo: str, lookback: int = 200) -> dict:
    ns_dir = store._lh(repo) / "north_stars"
    if not ns_dir.exists():
        return {"ticks_scanned": 0, "unnamed_drift_ticks": 0}
    all_ticks = []
    for sub in ns_dir.iterdir():
        if not sub.is_dir():
            continue
        tfile = sub / "ticks.jsonl"
        if not tfile.exists():
            continue
        for ln in tfile.read_text().splitlines():
            if ln.strip():
                all_ticks.append(json.loads(ln))
    all_ticks.sort(key=lambda t: t.get("created_at", ""), reverse=True)
    tail = all_ticks[:lookback]
    unnamed = sum(
        1
        for t in tail
        if t.get("heading") not in (None, "on course") and not t.get("drift_category")
    )
    return {"ticks_scanned": len(tail), "unnamed_drift_ticks": unnamed}


def _agi_likeness_score(repo: str) -> dict:
    """Score a repo on five AGI-like sub-properties per ADR-003.

    Each sub-property returns a scalar in [0, 1] plus a short evidence
    string. The full vector is returned as a dict; consumers can
    summarize as they see fit (weighted average, min, min-over-critical).
    Weights are uniform in v0.2.0 — calibration against real
    cross-consumer data over time will tune them.
    """
    import json as _json
    from pathlib import Path
    from . import store

    lh = store._lh(repo)

    # 1. Persistence of decision — AUTONOMY.md entries as proxy.
    autonomy = lh / "AUTONOMY.md"
    autonomy_entries = 0
    if autonomy.exists():
        autonomy_entries = sum(
            1
            for ln in autonomy.read_text().splitlines()
            if ln.strip().startswith("- ") and len(ln.strip()) > 10
        )
    # Saturates at 10+ entries; a repo with 10+ settled decisions has
    # real institutional memory.
    persistence = min(1.0, autonomy_entries / 10.0)

    # 2. Heterogeneity — distinct models across recent ticks.
    models: set[str] = set()
    ticks_scanned = 0
    ns_dir = lh / "north_stars"
    if ns_dir.exists():
        for sub in ns_dir.iterdir():
            if not sub.is_dir():
                continue
            tfile = sub / "ticks.jsonl"
            if not tfile.exists():
                continue
            for ln in tfile.read_text().splitlines()[-50:]:
                if not ln.strip():
                    continue
                try:
                    t = _json.loads(ln)
                except _json.JSONDecodeError:
                    continue
                m = t.get("model")
                if m:
                    models.add(m)
                ticks_scanned += 1
    # Saturates at 4+ distinct models (heterogeneous fleet threshold).
    heterogeneity = min(1.0, len(models) / 4.0)

    # 3. Contract-earning — trilogy presence as proxy.
    # A repo with .visionlog/ AND .research-md/ AND .ike/ is fully
    # contract-earning-capable; partial presence is partial score.
    # Accept either `.research` (research-md tool's on-disk name) or
    # `.research-md` for forward compatibility.
    trilogy_present = 0
    for d in (".visionlog", ".ike"):
        if (Path(repo) / d).exists():
            trilogy_present += 1
    if (Path(repo) / ".research").exists() or (Path(repo) / ".research-md").exists():
        trilogy_present += 1
    contract_earning = trilogy_present / 3.0

    # 4. Empirical validation — ORGANIC promoted artifacts count.
    # Per ADR-004 (rhea adjudication): staged promotions (applications
    # driven by author-scripted simulated ticks) are captured-metric
    # artifacts, not capability evidence. They're tracked separately
    # and do NOT count toward the empirical_validation score. Only
    # promotions whose trial candidate files lack `staged: true` count.
    promoted_dir = lh / "promoted"
    organic_promoted = 0
    staged_promoted = 0
    trials_dir = lh / "trials"
    staged_cids: set[str] = set()
    if trials_dir.exists():
        from . import store

        for f in trials_dir.glob("*/*.md"):
            d = store._parse_candidate_file(f)
            if d.get("staged") is True or d.get("staged") == "True":
                staged_cids.add(d.get("candidate_id"))
    if promoted_dir.exists():
        for f in promoted_dir.glob("*.md"):
            # Filename pattern: <date>-<candidate_id>.md
            stem_cid = f.stem.split("-", 3)[-1] if f.stem.count("-") >= 3 else f.stem
            if stem_cid in staged_cids:
                staged_promoted += 1
            else:
                organic_promoted += 1
    # Saturates at 5 organic promoted artifacts.
    empirical_validation = min(1.0, organic_promoted / 5.0)

    # 5. Self-observation — drift signals that changed behavior.
    # Proxy: ratio of ticks where a drift fired AND a subsequent tick
    # had a different signature (evidence the pod pivoted). Coarse.
    pivots_observed = 0
    drift_fires = 0
    if ns_dir.exists():
        for sub in ns_dir.iterdir():
            if not sub.is_dir():
                continue
            tfile = sub / "ticks.jsonl"
            if not tfile.exists():
                continue
            ticks = []
            for ln in tfile.read_text().splitlines():
                if ln.strip():
                    try:
                        ticks.append(_json.loads(ln))
                    except _json.JSONDecodeError:
                        continue
            for i, t in enumerate(ticks[:-1]):
                if t.get("drift_category"):
                    drift_fires += 1
                    nxt = ticks[i + 1]
                    if nxt.get("signature") != t.get("signature"):
                        pivots_observed += 1
    self_observation = (pivots_observed / drift_fires) if drift_fires else 0.0

    return {
        "persistence_of_decision": {
            "score": round(persistence, 3),
            "evidence": f"{autonomy_entries} AUTONOMY.md entries",
        },
        "heterogeneity": {
            "score": round(heterogeneity, 3),
            "evidence": f"{len(models)} distinct models across recent {ticks_scanned} ticks",
        },
        "contract_earning": {
            "score": round(contract_earning, 3),
            "evidence": f"{trilogy_present}/3 trilogy dirs present",
        },
        "empirical_validation": {
            "score": round(empirical_validation, 3),
            "evidence": (
                f"{organic_promoted} organic promoted artifacts"
                f" ({staged_promoted} additional staged — per ADR-004, excluded from score)"
            ),
        },
        "self_observation": {
            "score": round(self_observation, 3),
            "evidence": f"{pivots_observed}/{drift_fires} drift signals produced a pivot",
        },
        "aggregate": round(
            (
                persistence
                + heterogeneity
                + contract_earning
                + empirical_validation
                + self_observation
            )
            / 5.0,
            3,
        ),
        "disclaimer": (
            "Per ADR-004 (rhea adjudication): self-reported aggregate is "
            "instrumentation under captured-metric conditions until the "
            "session's falsification conditions are met. Scores are "
            "infrastructure-verified, not capability-validated."
        ),
    }


def _scan_spec_drift(repo: str) -> list[dict]:
    """Detect mismatches between this repo's SPEC.md tool names and the
    running telos_md tool surface. Only meaningful for the telos_md
    repo itself; returns [] for consumer repos that don't have SPEC.md."""
    from pathlib import Path
    from . import patterns, tools

    spec_path = Path(repo) / "SPEC.md"
    if not spec_path.exists():
        return []
    tool_names = [t.name for t in tools.TOOLS]
    return patterns.spec_drift(str(spec_path), tool_names)


def run(repo_path: str) -> dict:
    """Audit a single repo. Telos is per-repo — to scan multiple
    repos, callers invoke run() once per repo (or parallelize) with the
    relevant repo_path. No cross-repo registry is consulted.
    """
    if not repo_path:
        raise ValueError("repo_path is required — telos_md is per-repo")
    return {
        "repo_path": repo_path,
        "promotable_candidates": _scan_trials(repo_path),
        "stuck_north_stars": _scan_stuck(repo_path),
        "unnamed_drift": _scan_unnamed(repo_path),
        "spec_drift": _scan_spec_drift(repo_path),
        "agi_likeness": _agi_likeness_score(repo_path),
    }


def main() -> int:
    import argparse

    ap = argparse.ArgumentParser(description="Telos per-repo self-audit")
    ap.add_argument("--repo", required=True, help="Absolute path to the repo to audit")
    args = ap.parse_args()
    findings = run(args.repo)
    print(json.dumps(findings, indent=2, default=str))
    any_findings = (
        bool(findings.get("promotable_candidates"))
        or bool(findings.get("stuck_north_stars"))
        or findings.get("unnamed_drift", {}).get("unnamed_drift_ticks", 0) > 0
    )
    return 1 if any_findings else 0


if __name__ == "__main__":
    sys.exit(main())
