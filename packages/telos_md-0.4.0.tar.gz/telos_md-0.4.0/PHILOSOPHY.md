# Philosophy

Why telos-md exists at this level of the stack, and why that level matters.

This document is teaching, not selling. If you want the API, read `SPEC.md`. If you want the origin story, read `GENESIS.md`. This document answers a deeper question: *what is telos-md a primitive of?*

## The frame: LLMs as metabolic substrate, orchestration as organism

Most of the public AGI discourse is stuck on "scale the primitive." Bigger base model = smarter agent. The empirical record of the last ~24 months quietly rejects this: GPT-4-class models with good scaffolding routinely outperform larger models with worse scaffolding. The Cambrian explosion in agent capability did not come from raw model-size growth — it came from architectural novelty above the inference call. Tool use, memory, agent loops, multi-agent coordination, persistent state. Everything around the LLM, not inside it.

The right frame: **LLMs are a metabolic primitive**. A cell. A ribosome. Commodity substrate that performs a specific, narrow, highly general operation (next-token prediction over a learned distribution). Intelligence is not in the cell. It's in the tissue, the organ, the organism built *on top of* the cell.

Scaling the cell produces more ATP. It does not produce multicellularity. Multicellularity requires a different architectural move — not more cells, but **structures between them**: signaling, persistent memory, differentiation into specialized roles, coordination of cell populations, feedback loops at the organ level. This is where eidos-agi places its bets. Trilogy, forges, rhea, brutal-forge, telos-md — none of these are "better LLMs." They are **organ-system primitives** running on commodity metabolic substrate. Building the organism, not tuning the cells.

Telos is one such primitive. This document stakes what level of the organism telos-md occupies.

## Why coordination produces more intelligence than the sum of cells

The reduction-of-waste argument is too weak. It gives you efficiency, not emergence. Ten cells coordinating efficiently are still ten cells.

The actual mechanism is revealed in a piece called [*Language as Momentum*](https://eidosagi.com/language-as-momentum) — the math behind multi-agent serendipity. The argument, compressed:

- Gradient descent is trapped by its own precision. Continuous updates to a single model can't escape that model's loss landscape. Local minima are real, and scaling doesn't change the topology.
- When Model A sends language to Model B, three things happen: **project down** (A compresses its high-dim state into tokens, destroying local gradient information), **change basis** (tokens travel to B, which has an entirely different learned geometry), **unproject up** (B reconstructs in its own landscape from tokens, landing at a point with no mathematical relationship to A's origin).
- This is a **discontinuous operation**. The landing point in B's space is not reachable from A's gradient descent. A lossy, blocky, language-mediated transfer between differently-trained models kicks the receiver into regions the sender could never reach.
- Serendipity is not luck. It is structural — produced by the math of lossy inter-model communication between differently-optimized landscapes.

This is the answer to the emergence question. Coordination between cells is not just less wasteful. It performs computation *no single cell can perform*. The medium between cells (language) is not just a transfer mechanism — it is a mathematical operator that produces discontinuous jumps escaping the precision trap of any single cell's optimization history.

**Coordination is computation.** The organism is smarter than the cell not because it has more cells, but because the cell-to-cell transfers are themselves a form of reasoning the cells could not perform alone.

## Where telos-md sits

Telos is not adjacent to the language-transfer medium. Telos is **a sensor in that medium**.

Every pod running a loop or a trilogy flow is participating in the lossy projection — either between pods (multi-agent) or between iterations of its own reasoning (intra-model). Each tick a pod reports is an instance of projection. Each transition between trilogy stages (research → visionlog → ike) is a projection into a different basis. Telos observes these projections and accumulates patterns about which produce real jumps and which dissipate into noise.

The pattern library is not a list of "how autonomous work fails." It is more specific: **it is a list of how lossy projections through the language-transfer medium succeed or fail**. Every named pattern is a pattern *in the medium itself*.

- `measurement-over-product`: a pod's ticks produce projections that all land in the same narrow neighborhood of the same geometry. No momentum. Gradient descent in disguise.
- `heuristic-ratchet`: successive projections fail to change basis because the receiving context is the same as the sending context. The lossy medium has degenerated into a lossless one.
- `low-diversity-fleet`: a multi-agent architecture where every cell is the same model. The mathematical operation still happens, but the landing point is in nearly-the-same geometry. You get coordination benefits without serendipity benefits.
- `monolithic-loop`: one cell doing all iterations. No inter-cell transfer at all. Efficiency without emergence.

Each of these is a *mode of failure in the momentum medium*. Telos observes them because it sits where the projections happen.

This also clarifies why telos-md's improvement matters so much. If the pattern library is a library of how the momentum medium succeeds or fails, then improving it is improving the quality of computation the organism performs. Not efficiency gains. Emergent-capability gains. That is the thesis for why self-improving coordination is a candidate for what brings near-AGI into existence: it sharpens the medium in which inter-cell reasoning happens, and that reasoning is where intelligence above the cell actually lives.

## The practical implication — heterogeneous model fleets

The language-as-momentum argument has a sharp design consequence that telos-md should not ignore:

**The mathematical advantage of multi-agent architectures depends on model diversity.** The lossy projection still happens when Claude talks to Claude, but the landing point is in nearly-the-same geometry as the origin. Same-model ensembles are weak multi-agent systems — they get coordination benefits without serendipity benefits. Realizing the mathematical advantage requires genuinely different models: different trainers, different training data, different optimization histories.

Most current multi-agent work — including, at time of writing, most of eidos-agi — runs on monoculture. This is a floor, not a ceiling. The mathematical advantage is larger than it appears as long as the fleet homogenizes, and it unlocks further as the fleet diversifies.

Telos should track this as a first-class signal:
- `telos_traffic` reports fleet diversity (single-model / mixed / heterogeneous)
- A loop running in a monoculture fleet gets a `low-diversity-fleet` warning when the work would benefit from cross-geometry transfer
- The pattern library, at the meta-loop, tracks whether heterogeneous-fleet loops show measurably different convergence behavior than monoculture loops

This is a testable claim. If the argument holds, heterogeneous fleets produce qualitatively different pattern distributions than monoculture ones. Telos's data is what can falsify or confirm it empirically.

## Custodial-directive, counter-action-advisory

The ST-PETER.md doctrine is PID-without-command: observe globally, nudge locally, decisions belong to the pod. This is not just a preference. It is required by the mechanism — but with a sharper boundary than "observer, not commander" suggests. Telos has **two roles** that need to be kept distinct:

**At the contract boundary, Telos is directive.** When `telos_set_north_star` registers a goal, that registration is a *custody act*. The contract is now Telos's responsibility. Until `telos_close` discharges it, the tool refuses to silently accept ticks that abandon the commitment. If `AUTONOMY.md` has already settled a decision and a tick's `action_summary` re-asks it, Telos flags the prior entry and the pod cannot proceed without acknowledging it. This is not commanding — it is *holding the line on what was already earned upstream in `research.md` and `governor`*. The contract Telos refuses to drop is a contract the pod itself agreed to.

**At the counter-action boundary, Telos is advisory.** When drift fires — `monolithic-loop`, `heuristic-ratchet`, `zero-delta-churn` — Telos names the pattern and points at a counter-action. But the pod runs the response in its *own* Socratic dialogue. If Telos commanded the response ("thou shalt debate before proceeding"), it would flatten the language-transfer medium. Commanded pods stop doing projection — they do compliance. The lossy medium degrades into a one-directional control channel, and the discontinuous jumps that produced multi-agent serendipity stop happening because there is no longer a genuinely different geometry receiving the projection; there is only a geometry being steered toward the commander's preferred point.

Both halves are required. Drop custody (the directive half) and Telos becomes a recommendation engine the pod can ignore mid-loop — and an autonomous pod under stress will ignore it. Drop advisory (the counter-action half) and Telos commands the pod's response — and the language-transfer medium degenerates.

This is also why Telos does not invoke rhea directly in its critical path, even though rhea clearly belongs in the ecosystem. Tool boundaries matter. If Telos imported rhea and ran debates inside ticks, the medium between Telos and the pod would degrade into "Telos + rhea speaking as one." Two tools becoming one tool reduces the diversity of the projection landscape. Keeping them independent — and having Telos *name rhea as a counter-action* when a pattern indicates a pod skipped a decision-earning step — preserves the separate geometries that make the architecture work.

## What this doesn't claim

The strongest version of the language-as-momentum argument says single-model AGI is impossible. Telos's philosophy does not require that claim. A weaker version is sufficient for the design: **multi-agent architectures have a structural mathematical advantage that single-agent has to somehow approximate**. That weaker claim is safe, testable, and supported by the mechanism.

Similarly, telos-md's improvement is a *candidate* for what brings near-AGI into existence — probably on the short list of 2-3 necessary ingredients, not the sole ingredient. Capable base models, adversarial challenge primitives, contract/decision flow, pattern-naming capability, distributed-pod runtime — several pieces have to land. Telos is one piece. The highest-leverage one that is currently tractable and unsolved, which is why it is worth building first.

## Tool boundaries — telos-md alongside the others

- **rhea**: adversarial debate (Dreamer / Doubter / Decider). Where consequential *decisions* get stress-tested before commitment. Telos observes trajectories; rhea tests destinations.
- **brutal-forge**: adversarial audit of artifacts. Where shipped work gets attacked to find what's wrong. Telos observes the journey; brutal-forge attacks the artifact.
- **research-md → visionlog → ike** (trilogy): decision-earning, contract-recording, execution. The standard pipeline for consequential work. Telos watches pods using the trilogy — and flags when a pod skipped a stage (pattern: `goal-unreviewed`).
- **pal**: meta-consultant. Recommends which tool to use for a problem. Telos is invoked directly by pods for in-flight trajectory information.
- **resume-resume**: session continuity / memory. Telos's pattern library persists via the same memory substrate — so wisdom compounds across sessions.

Each tool has a narrow, legible domain. The lossy medium between tools (users and agents invoking them independently) is itself part of what makes the stack work. Over-integration flattens the medium.

## Further reading

- `GENESIS.md` — the specific session that surfaced the need for this tool
- `LEARNING.md` — how telos-md improves with use
- `SPEC.md` — the API contract
- External: [Language as Momentum](https://eidosagi.com/language-as-momentum) — the mathematical argument this doc builds on
- External: [ST-PETER.md](../eidos-philosophy/ST-PETER.md) — the PID-coordination doctrine telos-md implements
