# Using telos-md

**Telos is AGI-substrate discipline for per-project loops.** It exists to make the running system containing it more AGI-like — along five measurable sub-properties: persistence of decision, heterogeneity, contract-earning, empirical validation, and self-observation (see [`ADR-003`](./.governor/adr/) for the thesis).

At the pod level, this shows up as **directional fidelity**: you declare a goal, tick your progress, and telos-md tells you when you've drifted off course. Every drift pattern maps to protecting one of the five sub-properties. `self_audit` emits the score vector for any repo so you can see which dimensions are thin and work on them.

## Quickstart

Three tools, one flow:

```python
# 1. Declare your destination
ns = mcp.telos_set_north_star(
    goal="reduce p95 request latency to under 200ms",
    metric="p95_latency_ms",                # a trajectory metric, not a checklist
    stop_max_iters=40,                       # hard budget
    stop_zero_delta_n=3,                     # stop after 3 no-change ticks
    repo_path="/abs/path/to/your/repo",      # per-repo; telos-md never crosses
)

# 2. Tick each step
result = mcp.telos_tick(
    north_star_id=ns["north_star_id"],
    action_summary="added query hints to the slow path",
    measurement=215,                         # current value of the declared metric
    signature="schema-change",               # categorize the kind of work
    model="claude-opus-4-7",                 # enables fleet-diversity signals
    repo_path="/abs/path/to/your/repo",
)
# result["signal"] is "continue" | "pivot" | "stop"
# result["drift_category"] names a matched pattern or None
# result["reasoning"] is either a specific counter-action OR null (silence on null)
# result["settled_autonomy"] surfaces AUTONOMY.md entries when present

# 3. Close with an outcome when done (or stuck, or pivoted)
mcp.telos_close(
    north_star_id=ns["north_star_id"],
    outcome="reached",                       # or abandoned | converged | pivoted
    notes="landed; latency settled at 180ms",
    repo_path="/abs/path/to/your/repo",
)
```

## Per-repo, never cross-project

Everything telos-md writes lands in `<repo>/.telos/`. No shared DB, no user-global state. Moving a repo moves its telos-md history with it. A pod working on repo A cannot see repo B's loops unless explicitly queried.

Directory layout:

```
<repo>/.telos/
├── config.yaml                                   # project UUID + metadata
├── AUTONOMY.md                                   # settled decisions earned here
├── north_stars/
│   ├── ns_<id>.yaml                              # per-NS config + outcome
│   └── ns_<id>/
│       ├── ticks.jsonl                           # append-only tick log
│       └── applications.jsonl                    # tick → candidate attributions
├── trials/
│   └── tr_<id>/
│       └── cd_<id>.md                            # candidate + metrics (frontmatter)
├── promoted/
│   └── <date>-<candidate_id>.md                  # durable promotion record
└── log/
    └── YYYY-MM-DD.jsonl                          # per-day MCP call audit log — inbound args + outbound result
```

The `log/` directory records every MCP call that has a resolvable
`repo_path`. Each line is a JSON object with `started_at`,
`finished_at`, `tool`, `arguments`, `result`, and `error`. Use it to:

- Measure **organic applications** for trial candidates against the log, not staged dummy runs.
- Calibrate promotion gate thresholds against real usage statistics.
- Detect systemic false positives by scanning the log for patterns that fire repeatedly but never get acted on.
- Reconstruct "how was telos-md used on this project?" across any time window.

The log is the empirical substrate the promotion gates were always
supposed to measure against — not session-internal staging.

All plain text. `git diff` shows your loop as it unfolds. Another agent opening this directory can read the full history without schema knowledge.

## Drift patterns — what telos-md watches for

When a tick comes in, telos-md checks the trajectory against named drift modes. When one fires, `drift_category` is set and `signal` is `pivot` or `stop`. The counter-action points at a specific next move.

| Pattern | Fires when | Counter-action |
|---|---|---|
| `zero-delta-churn` | N consecutive identical measurements | Stop. Close with `converged` outcome. |
| `monolithic-loop` | ≥3 ticks all authored by the same model | Invoke `rhea_challenge` (plan-level doubt) or `pal_codereview` with a non-Claude model (code-level). Same-model review can't escape the geometry. |
| `heuristic-ratchet` | Trailing ticks cluster on the same signature | Invoke `rhea_challenge` on whether the heuristic is pointed at the right objective. If it is, promote via a `visionlog` ADR and stop ratcheting. |
| `execution-without-decision` | Signature churn — different approach nearly every tick | Pause. Move the question to `research.md`, record the winning approach as an ADR in `visionlog`, resume with `ike.md` tasks bound to that contract. |
| `caretaking-drift` | Hedging/permission-seeking language in the tick's action_summary | Suppress it and execute. Check `AUTONOMY.md` — if a settled decision covers this, you have clearance. Default is act, not ask. |
| `same-signature-repeat` | Two pods / crons producing overlapping signatures | Collision. One defers or changes course. |

## Trilogy composition

Telos is one layer of the coordination stack, not the whole stack:

- **`research.md`** — earn a consequential decision with evidence BEFORE execution. If a goal spawns substantial work, start here.
- **`visionlog`** — record the decision as an ADR; set vision; declare guardrails and SOPs. The contracts all execution honors.
- **`ike.md`** — track the execution tasks that honor those contracts.
- **`telos-md`** — watch the execution itself for drift; close the loop with an honest outcome.
- **`hone`** — the per-tick reflective ceremony inside the loop. Each iteration: `hone_tick` to start, observe before, propose at most one delta, `hone_write_turn` to retain (even on `no-op`). Telos measures *trajectory across many ticks*; hone enforces *presence at each tick*. Pair them — one without the other leaves a hole the other cannot fill. See [`TELOS_CUSTODY.md`](./TELOS_CUSTODY.md) for the visual mental model of how these compose.

Telos will actively route you back to the trilogy:
- `execution-without-decision` sends you to `research.md` + `visionlog` + `ike.md`.
- `heuristic-ratchet` sends promoted outcomes to `visionlog` ADRs.
- `goal-unreviewed` warns at registration time if your north star's goal has no matching entry in `.research-md/`, `.visionlog/`, or `.telos/`.
- `caretaking-drift` points at `AUTONOMY.md` for clearance on settled questions.

If telos-md fires a trilogy-routing pattern and you ignore it, you're committing to re-learn the same thing the trilogy was designed to record once.

## Self-improvement pipeline

Telos improves its own pattern library via propose→trial→promote:

1. **`telos_hypothesize`** — draft candidate patterns, refinements, or counter-actions. Can take caller-provided heterogeneous candidates (preferred) or fall back to built-in claude drafting. Kinds: `pattern_name`, `counter_action`, `refinement`, `philosophy_revision`, `deprecation`.
2. **Trial** — candidates auto-enroll in a trial pool. As ticks fire drift, matching candidates accrue applications. No human ratification.
3. **`telos_trial_status`** — read-only inspection of a trial's candidates + metrics.
4. **`telos_promote`** — commits a candidate as a permanent library entry. Blocks unless ALL of:
   - `applications >= 5` — minimum evidence volume
   - `signal_outcome_score >= 0.2` — minimum raw validation rate
   - `signal_lift >= 0.4` — the signal beats a random-signal null baseline by ≥0.4
   - `regression_test` (if declared) passes via pytest subprocess
   - `cross_model_review` verdict is `approved` for pattern_name / refinement / counter_action / philosophy_revision kinds
   - Strictly best sibling on the rank cascade (score → ref_rate → applications → created_at)

If the gate blocks, the response includes a structured `reason` and sibling metrics so the caller can see why.

5. **`telos_reload`** — forces the MCP server to re-import patterns / store / llm from disk. Auto-invoked at the end of a successful promote, so code changes take effect without a Claude Code restart.

## Per-repo only — no cross-repo state

Telos has no user-level registry, no shared database, no knowledge of any project other than the one whose `repo_path` you pass. A pod working on project A cannot see project B's loops, and vice versa. Each repo is self-contained: clone it and its telos-md history comes with it; delete it and nothing orphans.

If you want "scan all my projects" behavior, write it yourself — it's a loop over a list you maintain:

```bash
# ~/bin/telos-md-audit-all
for repo in \
    ~/repos/telos-md \
    ~/repos/email-classifier \
    ~/repos/ojo; do
  echo "=== $repo ==="
  python -m telos-md.self_audit --repo "$repo"
done
```

Run that on a cron, pipe to a file, consume the results however fits your workflow. Cross-project aggregation is a user-level orchestration concern — not telos-md's job. Keeping it outside the tool is why telos-md can stay clean and honest about its scope.

## Empirical honesty, not editorial

Telos refuses to promote by advocacy. Every gate above exists because a specific failure mode was observed or reasoned about:
- The applications gate prevents low-N promotions.
- The corr gate is a raw-accuracy floor.
- The lift gate prevents "accuracy masquerading as correlation" — a continue→reached loop scores perfect without the signal being informative.
- The regression-test gate prevents promoting markdown claims that aren't embodied in code.
- The cross-model review gate prevents telos-md from promoting its own Claude-authored blind spots into its own library.
- The strict-best tiebreak prevents deadlock-by-tie.

No force-promote path. No override at per-candidate level. The gates decide. Auditing the gates themselves is a coarse, quarterly activity, not per-item.

## When to consult telos-md, when to skip it

Consult when:
- You're starting a multi-step autonomous loop (anything >3 iterations).
- You're doing consequential architectural work and want to be observable.
- You expect to be tempted by drift (scope creep, ratcheting, permission-seeking).
- You're running hours-long work and want an external check on whether you're still pointed at the declared goal.

Skip when:
- The task is one-shot (single edit, single query).
- The goal is a checklist with no room for trajectory (counter metrics trigger a warning at registration for this reason).
- You're in a pure ambient operation mode (reading, not changing).

## Failure modes telos-md does not catch

- **Lying in the action_summary.** A pod that ticks "shipped thing X" without having shipped it is believed. Telos trusts the pod's self-report.
- **Model identity spoofing.** The `model` field is self-reported; no verification. `low-diversity-fleet` signals are advisory.
- **Goals that were unearned at registration.** `telos-md` guards earned commitments. If the commitment was unearned (didn't route through `research.md` first), `telos-md` inherits that error and dutifully helps you toward whatever the registered goal was. `goal-unreviewed` fires at `set_north_star` time as a warning (not a block) when no upstream trilogy artifacts back the goal — pause then and route through `research.md` before continuing.
- **Pattern library gaps.** If your drift mode isn't in the current library, telos-md won't flag it. Growth comes from `hypothesize → trial → promote` across many real loops.

Telos sharpens with use. A session producing no candidates and no promotions is a session where telos-md learned nothing — the tool's value compounds across multi-repo, multi-agent use over weeks.
