# Telos Custody — the mental model

`telos-md` operates on two axes. Both are mechanical; no extended metaphor is required.

```
                  ┌─────────────────────────────────────────┐
                  │  CUSTODY AXIS                           │
                  │                                         │
   (registration) │  telos_set_north_star ───────► contract │ (closure)
                  │                       held              │  telos_close
                  │                                         │
                  └─────────────────────────────────────────┘
                                     │
                                     │  measured against
                                     ▼
                  ┌─────────────────────────────────────────┐
                  │  DRIFT AXIS                             │
                  │                                         │
       (tick N)   │  telos_tick ──► named drift pattern ──► │  (counter-action
                  │                 + signal +              │   handled in pod)
                  │                 reasoning               │
                  │                                         │
                  └─────────────────────────────────────────┘
```

## The custody axis — directive

The first axis is registration-to-closure. When a pod calls `telos_set_north_star`, the tool records:

- the goal text (earned upstream in `research.md`, locked in `governor`)
- a trajectory metric the pod will report against each iteration
- a set of stop conditions: when does this loop end?
- the `repo_path` and project_id this north star belongs to

That record is a **contract**. From this moment until `telos_close`, the contract is the tool's responsibility. Every tick is measured against it. The tool refuses to silently accept ticks that abandon the contract — it surfaces them as drift and names the failure mode.

This axis is **directive**. The tool does not negotiate at this boundary. If `AUTONOMY.md` has already settled a decision and a tick's `action_summary` re-asks it, the tool flags the autonomy entry and the pod cannot proceed without acknowledging the prior contract. Custody is custody.

## The drift axis — advisory

The second axis runs tick-by-tick. Every iteration the pod calls `telos_tick` with:

- a `measurement` against the trajectory metric
- an `action_summary` describing what the pod did
- a `signature` (model + reasoning shape) so heterogeneity can be measured
- optional metadata (model name, candidate attributions, etc.)

The tool measures the tick against the contract and the recent history of ticks. It returns:

- a `heading`: how far is the pod from custody discharge?
- a `drift_category`: name of any matched failure-mode pattern (or `clear`)
- a `signal`: `continue` / `pivot` / `stop`
- reasoning the pod can read

This axis is **advisory**. The tool does not execute the counter-action — that happens in the pod's own geometry, with the pod's own choice of next move. If the tool fired `monolithic-loop`, the counter-action might be `rhea_challenge` or a basis-change to a different model family. The tool names the pattern; the pod runs the response.

## Why two axes, mechanism not metaphor

The original framing of this tool was naval — "lighthouse on a cliff, ships pass with their own declared north stars, the lighthouse observes drift." That metaphor leaked at the custody boundary. The tool *records* the north star; ships don't "declare" it to the tool from outside. The mechanism is more honest:

- **Custody is registration-to-closure.** What goes in is the contract; what comes out is its discharge.
- **Drift is tick-by-tick.** What goes in is an iteration; what comes out is a signal.

Both axes pass through the same per-repo `.telos/` directory. Both axes use the same MCP surface. The 9 tools split cleanly between them: `set_north_star` and `close` live on the custody axis; `tick`, `traffic`, `patterns` live on the drift axis; `hypothesize`, `trial_status`, `promote`, `reload` belong to the meta-loop that lets the tool's pattern library improve over time.

## The pairing with `hone` (future `praxis-md`)

Where `telos-md` measures *trajectory across many ticks*, `hone` enforces *presence at each individual tick* — observe before, propose at most one delta, retain the turn. They are paired primitives, not redundant. Skip `telos-md` and a loop loses course. Skip `hone` and each individual tick loses honesty about what changed.

The eidosagi.com homepage names this pairing: **Telos pulls. Praxis steers.** `telos-md` is the pull; `hone` (renaming to `praxis-md`) is the steering force per tick.

## When to consult `telos-md`

Three entry points:

1. **At the start of a multi-iteration loop**: `telos_set_north_star`. Custody opens.
2. **Once per iteration**: `telos_tick`. Drift detection runs.
3. **At loop end** (any outcome — success, abandonment, pivot, convergence): `telos_close`. Custody discharges, empirical metrics for any active trials get recorded.

A pod that calls only `telos_tick` without a registered north star will get a clear answer: "you have no custodied contract; either register one or stop calling me." The tool refuses to operate on the drift axis without something to drift from.

## Failure modes the custody/drift model does NOT catch

- **Goals that were wrong at registration.** `telos-md` guards earned commitments. If the goal was unearned (didn't route through `research.md` + `governor` first), `telos-md` inherits that error. Counter: the `goal-unreviewed` pattern fires at `set_north_star` time when no trilogy artifacts back the goal; pod should pause and run the goal through `research.md`.
- **Pod-internal incoherence within a single tick.** That's `hone`'s job, not telos-md's.
- **Cross-pod coordination.** `telos-md` is per-repo. Two pods working on the same repo with the same north star will compete; the `same-signature-repeat` pattern catches the symmetric case (two pods doing identical work) but not the asymmetric one (two pods running with different north stars in the same codebase). Mitigation lives at the orchestrator layer, not here.
