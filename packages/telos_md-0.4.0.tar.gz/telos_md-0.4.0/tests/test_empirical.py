"""End-to-end tests for the empirical-validation pipeline.

Exercises register -> ticks-with-drift -> close(outcome) -> metrics
recomputed -> promote gated by applications/score/strict-best-sibling.

Also contains regression tests for three critical bugs surfaced in the
gpt-5.2 cross-model review of the initial implementation:
- applications counter inflation on duplicate INSERT OR IGNORE
- per-loop scoring amplification (N ticks credited per outcome)
- reference_rate exceeding 1.0 (numerator/denominator mismatch)
"""

from __future__ import annotations

from pathlib import Path

import pytest

from telos_md import store


@pytest.fixture
def db_path(tmp_path: Path) -> str:
    """Back-compat alias. Returns the repo path; the name ``db_path`` is
    retained for historical reasons but the value is a repo directory,
    not a SQLite file."""
    return str(tmp_path)


def _apply_tick_with_drift(
    db_path, ns_id, signal, drift="monolithic-loop", measurement=1
):
    """Record a tick that will cause trialing candidates to be applied."""
    return store.record_tick(
        ns_id,
        action_summary="test tick",
        measurement=measurement,
        signature="test",
        model="claude-opus-4-7",
        heading="drifting",
        drift_category=drift,
        signal=signal,
        repo_path=db_path,
    )


_APPROVED = '{"reviewer_model": "openai/gpt-5.2", "verdict": "approved", "reasoning": "test fixture default"}'


def _trial_two(db_path):
    return store.insert_trial_candidates(
        kind="pattern_name",
        candidates=[
            {
                "text": "cand-A",
                "reasoning": "",
                "authored_by": "claude",
                "cross_model_review": _APPROVED,
            },
            {
                "text": "cand-B",
                "reasoning": "",
                "authored_by": "gpt",
                "cross_model_review": _APPROVED,
            },
        ],
        repo_path=db_path,
    )


def test_applications_counter_matches_distinct_ticks(db_path):
    """Regression: INSERT OR IGNORE used to increment applications even
    when no row was inserted. Applications must equal the number of
    (tick, candidate) rows actually written."""
    trial_id = _trial_two(db_path)
    ns_id = store.register_north_star(goal="t", db_path=db_path)
    for _ in range(4):
        _apply_tick_with_drift(db_path, ns_id, signal="pivot")
    rows = store.trial_candidates(trial_id, db_path=db_path)
    for r in rows:
        assert r["applications"] == 4, (
            f"candidate {r['candidate_id']} has {r['applications']}, expected 4"
        )


def test_per_loop_scoring_dedup(db_path):
    """Regression: a 5-tick loop must contribute exactly ONE evidence
    point per candidate, not 5. Otherwise a single favorable outcome
    dominates the score."""
    _trial_two(db_path)
    ns_id = store.register_north_star(goal="t", db_path=db_path)
    # 5 ticks, all pivot, then loop pivots -> each candidate gets 5 apps,
    # but should score as +1 (one validated application), not +5.
    for _ in range(5):
        _apply_tick_with_drift(db_path, ns_id, signal="pivot")
    result = store.close_north_star(ns_id, outcome="pivoted", db_path=db_path)
    for u in result["candidates_updated"]:
        assert u["applications_scored"] == 1, (
            f"expected 1 scored app per loop (dedup), got {u['applications_scored']}"
        )
        assert u["signal_outcome_score"] == 1.0


def test_reference_rate_stays_in_unit_interval(db_path):
    """Regression: numerator used to include open loops while denominator
    was closed-only, letting ref_rate exceed 1.0."""
    trial_id = _trial_two(db_path)
    ns1 = store.register_north_star(goal="t1", db_path=db_path)
    _apply_tick_with_drift(db_path, ns1, signal="pivot")
    store.close_north_star(ns1, outcome="pivoted", db_path=db_path)
    # Second loop stays open — must NOT count in numerator since it isn't closed.
    ns2 = store.register_north_star(goal="t2", db_path=db_path)
    _apply_tick_with_drift(db_path, ns2, signal="pivot")
    # Third closed loop with no applications to pad the denominator.
    ns3 = store.register_north_star(goal="t3", db_path=db_path)
    store.close_north_star(ns3, outcome="abandoned", db_path=db_path)
    for r in store.trial_candidates(trial_id, db_path=db_path):
        assert r["reference_rate"] is not None
        assert 0.0 <= r["reference_rate"] <= 1.0, (
            f"ref_rate={r['reference_rate']} outside [0, 1]"
        )


def test_signal_outcome_score_valid_loop_gives_positive(db_path):
    trial_id = _trial_two(db_path)
    ns = store.register_north_star(goal="t", db_path=db_path)
    _apply_tick_with_drift(db_path, ns, signal="pivot")
    store.close_north_star(ns, outcome="pivoted", db_path=db_path)
    rows = store.trial_candidates(trial_id, db_path=db_path)
    for r in rows:
        assert r["signal_outcome_corr"] == 1.0


def test_signal_outcome_score_invalid_loop_gives_negative(db_path):
    trial_id = _trial_two(db_path)
    ns = store.register_north_star(goal="t", db_path=db_path)
    _apply_tick_with_drift(db_path, ns, signal="pivot")
    # Pivot signaled, but loop actually reached — signal was wrong.
    store.close_north_star(ns, outcome="reached", db_path=db_path)
    rows = store.trial_candidates(trial_id, db_path=db_path)
    for r in rows:
        assert r["signal_outcome_corr"] == -1.0


def test_promote_blocks_below_min_applications(db_path):
    trial_id = _trial_two(db_path)
    ns = store.register_north_star(goal="t", db_path=db_path)
    _apply_tick_with_drift(db_path, ns, signal="pivot")
    store.close_north_star(ns, outcome="pivoted", db_path=db_path)
    rows = store.trial_candidates(trial_id, db_path=db_path)
    # apps=1 which is below PROMOTE_MIN_APPLICATIONS=5 even though score=1.0
    with pytest.raises(store.PromotionBlocked) as exc:
        store.promote_candidate(rows[0]["candidate_id"], db_path=db_path)
    assert "applications" in exc.value.reason


def test_promote_succeeds_above_bar_and_deprecates_siblings(db_path):
    trial_id = _trial_two(db_path)
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", db_path=db_path)
        _apply_tick_with_drift(db_path, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", db_path=db_path)
    rows = store.trial_candidates(trial_id, db_path=db_path)
    a, b = rows
    # Both are at corr=1.0, apps=5, identical ref_rate. Tiebreak cascade
    # resolves on created_at — A was inserted first, so A wins.
    result = store.promote_candidate(a["candidate_id"], db_path=db_path)
    assert result["candidate_id"] == a["candidate_id"]
    statuses = {
        r["candidate_id"]: r["status"]
        for r in store.trial_candidates(trial_id, db_path=db_path)
    }
    assert statuses[a["candidate_id"]] == "promoted"
    assert statuses[b["candidate_id"]] == "deprecated"


def test_promote_blocks_when_sibling_ranks_strictly_higher(db_path):
    """Sibling with higher corr blocks regardless of tiebreaks."""
    trial_id = _trial_two(db_path)
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", db_path=db_path)
        _apply_tick_with_drift(db_path, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", db_path=db_path)
    rows = store.trial_candidates(trial_id, db_path=db_path)
    a, _b = rows
    # Lower A's corr so B is strictly better. A should be blocked.
    store._update_candidate_fields(
        store._find_candidate_file(db_path, a["candidate_id"]),
        {"signal_outcome_score": 0.3},
    )
    with pytest.raises(store.PromotionBlocked) as exc:
        store.promote_candidate(a["candidate_id"], db_path=db_path)
    assert "ranks strictly higher" in exc.value.reason


def test_promote_is_idempotent_per_trial(db_path):
    """Atomic-promotion regression: once a trial has a winner, a second
    promote call for a different candidate must fail."""
    trial_id = _trial_two(db_path)
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", db_path=db_path)
        _apply_tick_with_drift(db_path, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", db_path=db_path)
    rows = store.trial_candidates(trial_id, db_path=db_path)
    a, b = rows
    store._update_candidate_fields(
        store._find_candidate_file(db_path, b["candidate_id"]),
        {"signal_outcome_score": 0.0},
    )
    store.promote_candidate(a["candidate_id"], db_path=db_path)
    # Try to promote B (which was deprecated) — should block.
    with pytest.raises((store.PromotionBlocked, ValueError)):
        store.promote_candidate(b["candidate_id"], db_path=db_path)


def test_closed_north_star_rejects_further_ticks(db_path):
    ns = store.register_north_star(goal="t", db_path=db_path)
    store.close_north_star(ns, outcome="reached", db_path=db_path)
    with pytest.raises(ValueError, match="closed"):
        store.record_tick(ns, action_summary="late", measurement=1, db_path=db_path)


def test_cannot_close_twice(db_path):
    ns = store.register_north_star(goal="t", db_path=db_path)
    store.close_north_star(ns, outcome="reached", db_path=db_path)
    with pytest.raises(ValueError, match="already closed"):
        store.close_north_star(ns, outcome="abandoned", db_path=db_path)


def test_promote_writes_durable_artifacts_to_repo(tmp_path):
    """Promote must write <repo>/.telos/promoted/<id>.md and append to
    AUTONOMY.md. This is how autonomy earned on a project becomes durable
    for future pods."""
    repo = str(tmp_path / "fake_repo")
    (tmp_path / "fake_repo").mkdir()
    trial_id = _trial_two(repo)
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", repo_path=repo)
        _apply_tick_with_drift(repo, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", repo_path=repo)
    rows = store.trial_candidates(trial_id, repo_path=repo)
    a, b = rows
    store._update_candidate_fields(
        store._find_candidate_file(repo, b["candidate_id"]),
        {"signal_outcome_score": 0.0},
    )
    result = store.promote_candidate(a["candidate_id"], repo_path=repo)
    assert "updated_files" in result
    assert len(result["updated_files"]) == 2
    artifact = Path(repo) / ".telos" / "promoted"
    autonomy = Path(repo) / ".telos" / "AUTONOMY.md"
    assert autonomy.exists()
    contents = autonomy.read_text()
    assert "Autonomy earned" in contents
    assert a["candidate_id"] in contents
    promoted_files = list(artifact.glob(f"*{a['candidate_id']}.md"))
    assert len(promoted_files) == 1
    body = promoted_files[0].read_text()
    assert "Applications:** 5" in body
    assert a["text"] in body


def test_null_baseline_is_computed_and_lift_gated(db_path):
    """With all signals=pivot and outcomes=pivoted, observed score is 1.0.
    Under uniform-random signals the baseline is -1/3 (only pivot validates
    pivoted out of 3 signals). Lift = 1.0 − (−0.333) ≈ 1.333 >> the
    PROMOTE_MIN_LIFT threshold, so promotion should succeed on lift."""
    trial_id = _trial_two(db_path)
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", db_path=db_path)
        _apply_tick_with_drift(db_path, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", db_path=db_path)
    rows = store.trial_candidates(trial_id, db_path=db_path)
    a = rows[0]
    # Null baseline must have been written.
    cand = store._parse_candidate_file(
        store._find_candidate_file(db_path, a["candidate_id"])
    )
    assert cand["null_baseline_score"] is not None
    assert abs(cand["null_baseline_score"] - (-1 / 3)) < 0.01
    # Promote should succeed because lift = 1.0 − (-0.333) >> 0.4.
    result = store.promote_candidate(a["candidate_id"], db_path=db_path)
    assert result["candidate_id"] == a["candidate_id"]


def test_promote_blocks_when_lift_below_threshold(db_path):
    """A candidate whose raw score just barely clears PROMOTE_MIN_CORR
    but whose lift over null is below PROMOTE_MIN_LIFT must be blocked.
    This is the gate that stops "accuracy masquerading as correlation"."""
    trial_id = _trial_two(db_path)
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", db_path=db_path)
        _apply_tick_with_drift(db_path, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", db_path=db_path)
    rows = store.trial_candidates(trial_id, db_path=db_path)
    a = rows[0]
    # Set corr just above PROMOTE_MIN_CORR but null_baseline close to it
    # so lift is tiny.
    store._update_candidate_fields(
        store._find_candidate_file(db_path, a["candidate_id"]),
        {"signal_outcome_score": 0.25, "null_baseline_score": 0.2},
    )
    with pytest.raises(store.PromotionBlocked) as exc:
        store.promote_candidate(a["candidate_id"], db_path=db_path)
    assert "signal_lift" in exc.value.reason


def test_promote_blocks_without_cross_model_review(db_path):
    """Pattern_name / refinement / counter_action / philosophy_revision
    candidates require a cross-model review before promotion. This
    guards against telos_md promoting its own Claude-authored blind
    spots into its own library."""
    trial_id = store.insert_trial_candidates(
        kind="refinement",
        candidates=[
            {
                "text": "cand-A",
                "reasoning": "",
                "authored_by": "claude",
                "target_drift_category": "monolithic-loop",
            },
            {
                "text": "cand-B",
                "reasoning": "",
                "authored_by": "claude",
                "target_drift_category": "monolithic-loop",
            },
        ],
        repo_path=db_path,
    )
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", repo_path=db_path)
        _apply_tick_with_drift(db_path, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", repo_path=db_path)
    rows = store.trial_candidates(trial_id, repo_path=db_path)
    a = rows[0]
    # Metrics clear; but no review → blocked.
    with pytest.raises(store.PromotionBlocked) as exc:
        store.promote_candidate(a["candidate_id"], repo_path=db_path)
    assert "cross_model_review" in exc.value.reason


def test_promote_succeeds_with_approved_cross_model_review(db_path):
    """When a candidate carries an approved non-Claude review, the
    cross-model gate passes and promotion proceeds normally."""
    trial_id = store.insert_trial_candidates(
        kind="refinement",
        candidates=[
            {
                "text": "cand-A",
                "reasoning": "",
                "authored_by": "claude",
                "target_drift_category": "monolithic-loop",
                "cross_model_review": '{"reviewer_model": "openai/gpt-5.2", "verdict": "approved", "reasoning": "sound"}',
            },
            {
                "text": "cand-B",
                "reasoning": "",
                "authored_by": "claude",
                "target_drift_category": "monolithic-loop",
                "cross_model_review": '{"reviewer_model": "openai/gpt-5.2", "verdict": "approved", "reasoning": "sound"}',
            },
        ],
        repo_path=db_path,
    )
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", repo_path=db_path)
        _apply_tick_with_drift(db_path, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", repo_path=db_path)
    rows = store.trial_candidates(trial_id, repo_path=db_path)
    a = rows[0]
    result = store.promote_candidate(a["candidate_id"], repo_path=db_path)
    assert result["candidate_id"] == a["candidate_id"]


def test_promote_blocks_with_rejected_cross_model_review(db_path):
    trial_id = store.insert_trial_candidates(
        kind="pattern_name",
        candidates=[
            {
                "text": "cand-A",
                "authored_by": "claude",
                "cross_model_review": '{"reviewer_model": "openai/gpt-5.2", "verdict": "rejected", "reasoning": "unclear"}',
            },
            {
                "text": "cand-B",
                "authored_by": "claude",
                "cross_model_review": '{"reviewer_model": "openai/gpt-5.2", "verdict": "rejected", "reasoning": "unclear"}',
            },
        ],
        repo_path=db_path,
    )
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", repo_path=db_path)
        _apply_tick_with_drift(db_path, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", repo_path=db_path)
    rows = store.trial_candidates(trial_id, repo_path=db_path)
    with pytest.raises(store.PromotionBlocked) as exc:
        store.promote_candidate(rows[0]["candidate_id"], repo_path=db_path)
    assert "cross_model_review" in exc.value.reason


def test_promote_blocks_when_regression_test_fails(db_path):
    """Counterfactual-nonzero gate: promoted refinements must name a
    regression_test that actually passes. A promoted candidate whose
    claim isn't embodied in a passing test must be refused."""
    import asyncio
    from telos_md import tools as lh_tools

    trial_id = store.insert_trial_candidates(
        kind="refinement",
        candidates=[
            {
                "text": "candA",
                "reasoning": "",
                "authored_by": "claude",
                "regression_test": "tests/definitely_not_a_real_test.py::nothing",
            },
            {
                "text": "candB",
                "reasoning": "",
                "authored_by": "gpt",
                "regression_test": "tests/definitely_not_a_real_test.py::nothing",
            },
        ],
        repo_path=db_path,
    )
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", repo_path=db_path)
        _apply_tick_with_drift(db_path, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", repo_path=db_path)
    rows = store.trial_candidates(trial_id, repo_path=db_path)
    a = rows[0]
    result = asyncio.run(
        lh_tools.handle_tool(
            "telos_promote",
            {
                "candidate_id": a["candidate_id"],
                "repo_path": db_path,
            },
        )
    )
    assert result["promoted"] is False
    assert result["reason"] == "regression_test_failed"


def test_trial_candidate_file_carries_metrics_after_recompute(tmp_path):
    """After a loop closes, each trial candidate's .md frontmatter must
    reflect the updated applications / signal_outcome_score."""
    repo = str(tmp_path / "demo")
    (tmp_path / "demo").mkdir()
    trial_id = store.insert_trial_candidates(
        kind="pattern_name",
        candidates=[{"text": "cand-x", "reasoning": "", "authored_by": "claude"}],
        repo_path=repo,
    )
    ns = store.register_north_star(goal="t", repo_path=repo)
    store.record_tick(
        ns,
        action_summary="t",
        measurement=1,
        drift_category="monolithic-loop",
        signal="pivot",
        repo_path=repo,
    )
    store.close_north_star(ns, outcome="pivoted", repo_path=repo)
    rows = store.trial_candidates(trial_id, repo_path=repo)
    assert rows[0]["applications"] == 1
    assert rows[0]["signal_outcome_score"] == 1.0
    f = Path(repo) / ".telos" / "trials" / trial_id / (rows[0]["candidate_id"] + ".md")
    body = f.read_text()
    assert "applications: 1" in body
    assert "signal_outcome_score: 1.0" in body


def test_trial_candidates_reads_from_repo_files(tmp_path):
    """Candidate files in <repo>/.telos/trials/ are the source of
    truth. No SQLite to contradict."""
    repo = tmp_path / "demo"
    repo.mkdir()
    trial_id = store.insert_trial_candidates(
        kind="pattern_name",
        candidates=[{"text": "x", "authored_by": "claude"}],
        repo_path=str(repo),
    )
    rows = store.trial_candidates(trial_id, repo_path=str(repo))
    assert rows[0]["text"] == "x"


def test_north_star_is_written_to_repo_file(tmp_path):
    """register_north_star with repo_path must write .telos/north_stars/<nsid>.yaml."""
    repo = str(tmp_path / "demo_repo")
    (tmp_path / "demo_repo").mkdir()
    nsid = store.register_north_star(
        goal="ship thing",
        metric="percent",
        stop_max_iters=10,
        repo_path=repo,
    )
    ns_file = Path(repo) / ".telos" / "north_stars" / f"{nsid}.yaml"
    assert ns_file.exists()
    body = ns_file.read_text()
    assert f'id: "{nsid}"' in body
    assert 'goal: "ship thing"' in body
    assert "stop_max_iters: 10" in body


def test_ticks_are_appended_to_jsonl(tmp_path):
    import json as _json

    repo = str(tmp_path / "demo_repo")
    (tmp_path / "demo_repo").mkdir()
    nsid = store.register_north_star(goal="t", repo_path=repo)
    store.record_tick(
        nsid, action_summary="a", measurement=1, signature="work", repo_path=repo
    )
    store.record_tick(
        nsid, action_summary="b", measurement=2, signature="work", repo_path=repo
    )
    jsonl = Path(repo) / ".telos" / "north_stars" / nsid / "ticks.jsonl"
    assert jsonl.exists()
    lines = jsonl.read_text().strip().splitlines()
    assert len(lines) == 2
    rec = _json.loads(lines[0])
    assert rec["action_summary"] == "a"


def test_close_updates_north_star_file_with_outcome(tmp_path):
    repo = str(tmp_path / "demo_repo")
    (tmp_path / "demo_repo").mkdir()
    nsid = store.register_north_star(goal="t", repo_path=repo)
    store.close_north_star(nsid, outcome="reached", notes="done", repo_path=repo)
    ns_file = Path(repo) / ".telos" / "north_stars" / f"{nsid}.yaml"
    body = ns_file.read_text()
    assert 'outcome: "reached"' in body
    assert "closed_at:" in body


def test_ensure_project_writes_only_to_repo(tmp_path):
    """Confirm telos_md writes ONLY to <repo>/.telos/config.yaml
    and nothing under the user home. Per-repo, no cross-repo side effects."""
    repo = tmp_path / "demo"
    repo.mkdir()
    pid = store.ensure_project(str(repo))
    assert (repo / ".telos" / "config.yaml").exists()
    assert pid in (repo / ".telos" / "config.yaml").read_text()


def test_project_config_is_written_on_first_use(tmp_path):
    """ensure_project must write .telos/config.yaml with a stable UUID,
    matching the convention set by .ike/ike.json and .visionlog/config.yaml."""
    repo = str(tmp_path / "demo_repo")
    (tmp_path / "demo_repo").mkdir()
    pid1 = store.ensure_project(repo)
    config = Path(repo) / ".telos" / "config.yaml"
    assert config.exists()
    assert pid1 in config.read_text()
    pid2 = store.ensure_project(repo)
    assert pid1 == pid2


def test_insert_trial_candidates_writes_repo_files(db_path, tmp_path):
    """When repo_path is passed, each candidate becomes a .md file in the
    repo — the repo is the durable source of truth."""
    repo = tmp_path / "demo_repo"
    repo.mkdir()
    trial_id = store.insert_trial_candidates(
        kind="refinement",
        candidates=[
            {
                "text": "cand-x",
                "reasoning": "why x",
                "authored_by": "openai/gpt-5.2",
                "target_pattern": "heuristic-ratchet",
                "target_drift_category": "heuristic-ratchet",
            },
        ],
        db_path=db_path,
        repo_path=str(repo),
    )
    trial_dir = repo / ".telos" / "trials" / trial_id
    files = list(trial_dir.glob("*.md"))
    assert len(files) == 1
    body = files[0].read_text()
    assert "candidate_id:" in body
    assert 'authored_by: "openai/gpt-5.2"' in body
    assert 'target_drift_category: "heuristic-ratchet"' in body
    assert "cand-x" in body


def test_self_audit_finds_promotable_candidates(db_path):
    from telos_md import self_audit as sa

    trial_id = _trial_two(db_path)
    for i in range(5):
        ns = store.register_north_star(goal=f"t{i}", repo_path=db_path)
        _apply_tick_with_drift(db_path, ns, signal="pivot")
        store.close_north_star(ns, outcome="pivoted", repo_path=db_path)
    rows = store.trial_candidates(trial_id, repo_path=db_path)
    a, b = rows
    store._update_candidate_fields(
        store._find_candidate_file(db_path, b["candidate_id"]),
        {"signal_outcome_score": 0.0},
    )
    findings = sa.run(repo_path=db_path)
    assert len(findings["promotable_candidates"]) == 1
    assert findings["promotable_candidates"][0]["candidate_id"] == a["candidate_id"]


def test_self_audit_finds_stuck_north_stars(db_path):
    from telos_md import self_audit as sa

    ns = store.register_north_star(goal="stuck", repo_path=db_path)
    store.record_tick(
        ns, action_summary="last", measurement=1, signal="stop", repo_path=db_path
    )
    findings = sa.run(repo_path=db_path)
    assert any(s["north_star_id"] == ns for s in findings["stuck_north_stars"])


def test_agi_likeness_score_vector_structure(tmp_path):
    """ADR-003: self_audit emits a 5-dimension AGI-likeness vector.
    Each dimension has a score in [0,1] and an evidence string; there
    is an aggregate summarizing all five."""
    from telos_md import self_audit as sa

    repo = str(tmp_path / "scorable")
    (tmp_path / "scorable").mkdir()
    store.ensure_project(repo)
    result = sa.run(repo)
    assert "agi_likeness" in result
    score = result["agi_likeness"]
    for key in (
        "persistence_of_decision",
        "heterogeneity",
        "contract_earning",
        "empirical_validation",
        "self_observation",
    ):
        assert key in score
        assert "score" in score[key]
        assert 0.0 <= score[key]["score"] <= 1.0
        assert "evidence" in score[key]
    assert 0.0 <= score["aggregate"] <= 1.0


def test_agi_likeness_persistence_rewards_autonomy_entries(tmp_path):
    from telos_md import self_audit as sa

    repo = str(tmp_path / "demo")
    (tmp_path / "demo" / ".telos").mkdir(parents=True)
    # No AUTONOMY.md yet → score 0.
    (Path(repo) / ".telos" / "config.yaml").write_text('id: "x"\nproject: "demo"\n')
    assert sa.run(repo)["agi_likeness"]["persistence_of_decision"]["score"] == 0.0
    # 5 entries → 0.5 (halfway to the saturation point at 10).
    (Path(repo) / ".telos" / "AUTONOMY.md").write_text(
        "# Autonomy earned\n\n" + "\n".join(f"- entry {i}" * 3 for i in range(5))
    )
    assert sa.run(repo)["agi_likeness"]["persistence_of_decision"]["score"] == 0.5


def test_settled_decision_re_asked_detector_matches_autonomy_keywords(tmp_path):
    from telos_md import patterns

    repo = str(tmp_path / "demo")
    (Path(repo) / ".telos").mkdir(parents=True)
    (Path(repo) / ".telos" / "AUTONOMY.md").write_text(
        "# Autonomy earned\n\n"
        "- **storage-is-files** — storage architecture is files, never sqlite\n"
    )
    match = patterns.settled_decision_re_asked(
        repo, "should we consider switching to sqlite for storage architecture?"
    )
    assert match is not None and "storage-is-files" in match


def test_settled_decision_re_asked_no_match_on_unrelated_action(tmp_path):
    from telos_md import patterns

    repo = str(tmp_path / "demo")
    (Path(repo) / ".telos").mkdir(parents=True)
    (Path(repo) / ".telos" / "AUTONOMY.md").write_text(
        "- **some-decision** — keywords here nothing related\n"
    )
    match = patterns.settled_decision_re_asked(
        repo, "adding a regression test for ticks handling"
    )
    assert match is None


def test_persistence_survives_telos_md_dir_preserved(tmp_path):
    """Regression for the manyhats/ojo data loss this session.

    Scenario that caused the loss: state lived only in a per-repo
    SQLite cache; a cleanup step deleted cache.db without backfilling
    its contents into files. When the DB is removed, the repo has no
    way to answer "what was my history?".

    After the file-only rewrite, there is no cache.db — state is
    files. This test asserts the invariant directly: register + tick +
    close; then wipe any transient caches (none should exist); then
    confirm the NS yaml and ticks.jsonl survive in .telos/."""
    repo = str(tmp_path / "survivor")
    (tmp_path / "survivor").mkdir()
    nsid = store.register_north_star(
        goal="survive the purge",
        metric="data_points_retained",
        repo_path=repo,
    )
    store.record_tick(
        nsid, action_summary="step 1", measurement=1, signature="work", repo_path=repo
    )
    store.record_tick(
        nsid, action_summary="step 2", measurement=2, signature="work", repo_path=repo
    )
    store.close_north_star(
        nsid, outcome="reached", notes="check survival", repo_path=repo
    )
    # Simulate a naive cleanup: delete anything cache-shaped.
    for cache_name in ("cache.db", "state.db"):
        for found in Path(repo).rglob(cache_name):
            found.unlink()
    # State must still be present as files.
    ns_file = Path(repo) / ".telos" / "north_stars" / f"{nsid}.yaml"
    tick_log = Path(repo) / ".telos" / "north_stars" / nsid / "ticks.jsonl"
    config = Path(repo) / ".telos" / "config.yaml"
    assert ns_file.exists(), "NS yaml must survive cache deletion"
    assert tick_log.exists(), "tick log must survive cache deletion"
    assert config.exists(), "project config must survive cache deletion"
    body = ns_file.read_text()
    assert 'outcome: "reached"' in body
    assert 'goal: "survive the purge"' in body
    ticks = tick_log.read_text().strip().splitlines()
    assert len(ticks) == 2


def test_persistence_atomic_write_does_not_leave_partials(tmp_path):
    """_atomic_write uses tempfile + rename. Interrupted writes must not
    leave the destination in a partial state."""
    target = tmp_path / ".telos" / "test.yaml"
    store._atomic_write(target, 'id: "12345"\nname: "full"\n')
    # No .tmp-* siblings should remain after a successful write.
    siblings = list(target.parent.glob(".tmp-*"))
    assert siblings == []
    assert target.read_text() == 'id: "12345"\nname: "full"\n'


def test_invalid_outcome_rejected(db_path):
    ns = store.register_north_star(goal="t", db_path=db_path)
    with pytest.raises(ValueError, match="outcome"):
        store.close_north_star(ns, outcome="finished", db_path=db_path)


def test_stop_signal_blocks_next_tick_unless_overridden(db_path):
    ns = store.register_north_star(goal="t", db_path=db_path)
    store.record_tick(
        ns, action_summary="a", measurement=1, signal="stop", db_path=db_path
    )
    with pytest.raises(store.StopSignalIgnored):
        store.record_tick(ns, action_summary="b", measurement=2, db_path=db_path)
    # Override works and lets the loop proceed.
    n = store.record_tick(
        ns, action_summary="b", measurement=2, override_stop=True, db_path=db_path
    )
    assert n == 2


def test_tick_surfaces_autonomy_hint_when_repo_has_autonomy_md(tmp_path):
    import asyncio
    from telos_md import tools as lh_tools, store as lh_store

    repo = tmp_path / "watched"
    (repo / ".telos").mkdir(parents=True)
    (repo / ".telos" / "AUTONOMY.md").write_text(
        "# Autonomy earned\n\n"
        "- 2026-04-19 — **decision_A** — don't ask about X\n"
        "- 2026-04-19 — **decision_B** — don't ask about Y\n"
    )
    nsid = lh_store.register_north_star(goal="t", repo_path=str(repo))

    async def call():
        return await lh_tools.handle_tool(
            "telos_tick",
            {
                "north_star_id": nsid,
                "action_summary": "doing work",
                "measurement": 1,
                "repo_path": str(repo),
            },
        )

    result = asyncio.run(call())
    assert result["settled_autonomy"] is not None
    assert "2 settled decisions" in result["settled_autonomy"]
    assert "AUTONOMY.md" in result["reasoning"]


def test_tick_has_no_autonomy_hint_when_repo_lacks_autonomy_md(tmp_path):
    import asyncio
    from telos_md import tools as lh_tools, store as lh_store

    repo = tmp_path / "watched"
    repo.mkdir()
    nsid = lh_store.register_north_star(goal="t", repo_path=str(repo))

    async def call():
        return await lh_tools.handle_tool(
            "telos_tick",
            {
                "north_star_id": nsid,
                "action_summary": "doing work",
                "measurement": 1,
                "repo_path": str(repo),
            },
        )

    result = asyncio.run(call())
    assert result["settled_autonomy"] is None


def test_refinement_only_applied_when_drift_category_matches_target(db_path):
    """Refinement candidates accrue applications only when their
    target_drift_category matches the tick's drift_category. This is
    how refinements compete on relevance instead of ambient drift volume."""
    trial_id = store.insert_trial_candidates(
        kind="refinement",
        candidates=[
            {
                "text": "ref-for-ratchet",
                "reasoning": "",
                "authored_by": "openai/gpt-5.2",
                "target_pattern": "heuristic-ratchet",
                "target_drift_category": "heuristic-ratchet",
            },
            {
                "text": "ref-for-monolithic",
                "reasoning": "",
                "authored_by": "google/gemini-2.5-pro",
                "target_pattern": "monolithic-loop",
                "target_drift_category": "monolithic-loop",
            },
        ],
        db_path=db_path,
    )
    ns = store.register_north_star(goal="t", db_path=db_path)
    # Tick fires with heuristic-ratchet drift. Only the ratchet-targeted
    # refinement should accrue an application.
    store.record_tick(
        ns,
        action_summary="test",
        measurement=1,
        drift_category="heuristic-ratchet",
        signal="pivot",
        db_path=db_path,
    )
    rows = store.trial_candidates(trial_id, db_path=db_path)
    by_text = {r["text"]: r for r in rows}
    assert by_text["ref-for-ratchet"]["applications"] == 1
    assert by_text["ref-for-monolithic"]["applications"] == 0


def test_pattern_name_candidate_still_applies_broadly(db_path):
    """pattern_name candidates don't have targets — they continue to
    accrue applications on any drift. Regression guard against breaking
    the prior behavior for non-refinement kinds."""
    trial_id = store.insert_trial_candidates(
        kind="pattern_name",
        candidates=[
            {"text": "name-candidate", "reasoning": "", "authored_by": "claude"}
        ],
        db_path=db_path,
    )
    ns = store.register_north_star(goal="t", db_path=db_path)
    store.record_tick(
        ns,
        action_summary="test",
        measurement=1,
        drift_category="monolithic-loop",
        signal="pivot",
        db_path=db_path,
    )
    rows = store.trial_candidates(trial_id, db_path=db_path)
    assert rows[0]["applications"] == 1


def test_loop_budget_enforced_on_record_tick(db_path):
    ns = store.register_north_star(
        goal="t",
        stop_max_iters=2,
        db_path=db_path,
    )
    store.record_tick(ns, action_summary="a", measurement=1, db_path=db_path)
    store.record_tick(ns, action_summary="b", measurement=2, db_path=db_path)
    with pytest.raises(store.LoopBudgetExceeded):
        store.record_tick(ns, action_summary="c", measurement=3, db_path=db_path)
