"""Dogfood test — telos_md watching telos_md.

The correctness constraint from LEARNING.md: "A monocultural telos_md
is a broken telos_md, even if every individual output reads well."

This test verifies the architecture is self-aware:

  1. If telos_md itself is being developed by a single model (the
     current reality — Claude Opus alone), the monolithic-loop
     pattern MUST fire once enough ticks accumulate. Telos must
     be able to recognize that it is drifting into the exact failure
     mode its docs warn about.

  2. The moment a second model enters the tick stream (simulating a
     pod bringing GPT or Gemini into the development loop), the
     monolithic-loop pattern MUST stop firing — the momentum medium
     is restored and the dogfood constraint from PHILOSOPHY.md is
     satisfied.

If either direction breaks, the philosophy doc is a lie and the tool
is not ready. These two assertions are the binary test for whether
telos_md's self-awareness claim holds.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from telos_md import patterns, store


# The north star under test: telos_md's own development.
DOGFOOD_GOAL = (
    "build telos_md to v0.2 — doc-editing on promote, heterogeneous "
    "LLM fleet, observation of telos_md by telos_md"
)


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "dogfood.db"


@pytest.fixture
def dogfood_north_star(db_path: Path) -> str:
    return store.register_north_star(
        goal=DOGFOOD_GOAL,
        metric="implemented-features / specced-features ratio",
        stop_zero_delta_n=3,
        signature="telos_md-self-development",
        db_path=db_path,
    )


def _sim_tick(
    db_path: Path,
    nsid: str,
    *,
    iteration: int,
    measurement: float,
    signature: str,
    model: str,
) -> None:
    """Helper: record one tick that simulates an actual development iteration."""
    action = (
        f"iter {iteration}: implemented feature batch; tests green; "
        f"measurement advanced to {measurement:.3f}"
    )
    store.record_tick(
        nsid,
        action_summary=action,
        measurement=measurement,
        signature=signature,
        model=model,
        db_path=db_path,
    )


def test_monolithic_development_session_triggers_pivot(db_path, dogfood_north_star):
    """Direction 1 — telos_md MUST flag a monocultural development loop.

    Simulates six development iterations, all authored by Claude Opus
    alone. This mirrors the actual reality of how telos_md's MVP was
    built (one model, no diversity). By iteration ≥5, the
    monolithic-loop pattern must fire with signal=pivot, telling the
    single-model developer to bring in a different geometry or face
    the same drift the docs describe.

    If this test passes: the architecture is self-aware. The tool
    correctly recognizes when it is running under the exact failure
    mode its own docs warn against.

    If this test fails: the dogfooding claim in PHILOSOPHY.md is
    aspirational, not implemented. The tool is not ready to ship.
    """
    measurements = [0.50, 0.55, 0.60, 0.625, 0.65, 0.67]
    for i, m in enumerate(measurements, start=1):
        # Distinct signature per iteration so heuristic-ratchet doesn't
        # pre-empt. The ONLY thing staying constant is `model`.
        _sim_tick(
            db_path,
            dogfood_north_star,
            iteration=i,
            measurement=m,
            signature=f"feature-batch-{i}",
            model="claude-opus-4-7",
        )

    history = store.recent_ticks(dogfood_north_star, n=20, db_path=db_path)
    assert len(history) == 6

    match = patterns.match(history)
    assert match is not None, (
        "Six monocultural ticks and no pattern matched. The monolithic-loop "
        "pattern is either broken or too conservative. Either way, the "
        "dogfooding claim in PHILOSOPHY.md is unverified."
    )
    assert match["drift_category"] == "monolithic-loop", (
        f"Expected monolithic-loop; got {match['drift_category']!r}. "
        "The pattern engine's priority ordering may be letting another "
        "pattern fire first, masking the self-awareness signal."
    )
    assert match["signal"] == "pivot", (
        "Monolithic-loop should recommend pivot (bring in a different "
        "model or consultant). Any other signal suggests the counter-action "
        "has drifted from the architectural claim."
    )


def test_heterogeneous_fleet_restores_momentum_medium(db_path, dogfood_north_star):
    """Direction 2 — the moment a second model enters, monolithic-loop stops firing.

    Simulates six iterations where three came from Claude and three
    from GPT-5 (representing the moment a second model is brought
    into the development loop). Monolithic-loop must NOT fire —
    momentum medium restored.

    Some other pattern may still match (perhaps heuristic-ratchet if
    signatures cluster), but monolithic-loop specifically must be
    silent. This pins the pattern's discriminating behavior.

    If this test fails: the pattern is firing on false positives. It
    would shout `monolithic-loop` even when the fleet is genuinely
    diverse, which would make its signal worthless.
    """
    fleet_sequence = [
        ("claude-opus-4-7", 0.50),
        ("gpt-5", 0.55),
        ("claude-opus-4-7", 0.60),
        ("gpt-5", 0.625),
        ("claude-opus-4-7", 0.65),
        ("gpt-5", 0.67),
    ]
    for i, (mdl, m) in enumerate(fleet_sequence, start=1):
        _sim_tick(
            db_path,
            dogfood_north_star,
            iteration=i,
            measurement=m,
            signature=f"feature-batch-{i}",
            model=mdl,
        )

    history = store.recent_ticks(dogfood_north_star, n=20, db_path=db_path)
    match = patterns.match(history)

    if match is not None:
        assert match["drift_category"] != "monolithic-loop", (
            "monolithic-loop fired on a heterogeneous fleet "
            "(2 distinct models across 6 ticks). The pattern has a false "
            "positive — it does not actually distinguish diverse fleets "
            "from monocultural ones. Fix the pattern's model-count check."
        )


def test_dogfood_signal_survives_stop_zero_delta_churn(db_path, dogfood_north_star):
    """Edge case — monolithic-loop still fires even when measurements do advance.

    If every tick advances the measurement (so zero-delta-churn does
    NOT pre-empt), monolithic-loop should still eventually fire on a
    monocultural fleet. This prevents a pathological interaction
    where a pod ratchets up a trivial metric indefinitely, avoiding
    zero-delta-churn but also suppressing monolithic-loop's warning.

    Real failure mode it prevents: a pod running Claude-alone adds
    a counter to measurement every tick (simulating "progress") just
    to avoid the stop signal. Telos must still flag the loop
    as monocultural.
    """
    for i in range(6):
        _sim_tick(
            db_path,
            dogfood_north_star,
            iteration=i + 1,
            measurement=i * 0.10 + 0.50,
            signature=f"unique-{i}",
            model="claude-opus-4-7",
        )
    history = store.recent_ticks(dogfood_north_star, n=20, db_path=db_path)
    match = patterns.match(history)
    assert match is not None
    assert match["drift_category"] == "monolithic-loop", (
        "Measurements advance every tick, so zero-delta-churn correctly "
        "doesn't fire. But monolithic-loop should — the fleet is still "
        "single-model. If this test fails, telos_md can be tricked "
        "into silence by any pod that keeps ratcheting a measurement."
    )
