"""Smoke tests — the MVP produces the pipeline shape SPEC advertises."""

from __future__ import annotations

from pathlib import Path

import pytest

from telos_md import patterns, store


@pytest.fixture
def db_path(tmp_path: Path) -> Path:
    return tmp_path / "state.db"


def test_register_and_recall_north_star(db_path):
    nsid = store.register_north_star(
        goal="build telos_md to v0.1",
        metric="test count passing",
        stop_zero_delta_n=3,
        db_path=db_path,
    )
    assert nsid.startswith("ns_")
    rows = store.active_north_stars(db_path=db_path)
    assert len(rows) == 1
    assert rows[0]["goal"] == "build telos_md to v0.1"


def test_tick_records_and_returns_iteration_number(db_path):
    nsid = store.register_north_star(goal="test", db_path=db_path)
    for i, m in enumerate([1, 2, 3], start=1):
        n = store.record_tick(
            nsid, action_summary=f"iter {i}", measurement=m, db_path=db_path
        )
        assert n == i


def test_zero_delta_churn_pattern_triggers_stop():
    ticks = [
        {"measurement": 98, "signature": "tighten", "model": "claude-opus"},
        {"measurement": 98, "signature": "tighten", "model": "claude-opus"},
        {"measurement": 98, "signature": "tighten", "model": "claude-opus"},
    ]
    match = patterns.match(ticks, stop_zero_delta_n=3)
    assert match is not None
    assert match["drift_category"] == "zero-delta-churn"
    assert match["signal"] == "stop"


def test_execution_without_decision_suppressed_on_multi_axis_grading_goal():
    """Regression for refinement: when the NS goal declares grading /
    audit / assessment / evaluation, signature diversity across ticks
    is the intent, not drift. Execution-without-decision must NOT fire."""
    models = ["claude-opus-4-7", "gpt-5.2", "gemini-3", "claude-opus-4-7", "gpt-5.2"]
    ticks = [
        {"measurement": i, "signature": f"grade-dim-{i}", "model": models[i]}
        for i in range(5)
    ]
    match = patterns.match(
        ticks,
        goal="grade the tool across five dimensions with evidence",
    )
    # execution-without-decision must NOT be the firing pattern.
    if match is not None:
        assert match["drift_category"] != "execution-without-decision"


def test_execution_without_decision_still_fires_on_single_assessment_keyword():
    """gpt-5.2 caveat during refinement review: a goal containing
    'assess' or 'evaluate' alone — without multi-axis indicators like
    dimensions/rubric/criteria — should NOT suppress execution-without-
    decision. Genuine implementation stalls whose goal includes
    'evaluate performance' or 'assess tradeoffs' must still be caught."""
    models = ["claude-opus-4-7", "gpt-5.2", "gemini-3", "claude-opus-4-7", "gpt-5.2"]
    ticks = [
        {"measurement": i, "signature": f"approach_{i}", "model": models[i]}
        for i in range(5)
    ]
    # Single assessment keyword but no multi-axis indicator — still thrashes.
    match = patterns.match(ticks, goal="evaluate the best caching library")
    assert match is not None
    assert match["drift_category"] == "execution-without-decision"


def test_execution_without_decision_still_fires_on_normal_goal():
    """Complement: with a normal implementation goal, signature churn
    still fires execution-without-decision as before."""
    models = ["claude-opus-4-7", "gpt-5.2", "gemini-3", "claude-opus-4-7", "gpt-5.2"]
    ticks = [
        {"measurement": i, "signature": f"approach_{i}", "model": models[i]}
        for i in range(5)
    ]
    match = patterns.match(
        ticks,
        goal="ship the caching layer for the user service",
    )
    assert match is not None
    assert match["drift_category"] == "execution-without-decision"


def test_execution_without_decision_triggers_pivot_to_trilogy():
    # Heterogeneous models so monolithic-loop doesn't preempt the
    # signature-churn check.
    models = [
        "claude-opus-4-7",
        "gpt-5.2",
        "gemini-3-pro",
        "claude-opus-4-7",
        "gpt-5.2",
    ]
    ticks = [
        {"measurement": i, "signature": f"approach_{i}", "model": models[i]}
        for i in range(5)
    ]
    match = patterns.match(ticks)
    assert match is not None
    assert match["drift_category"] == "execution-without-decision"
    assert match["signal"] == "pivot"
    # Counter-action must route to trilogy tools, not generic advice.
    assert "research.md" in match["reasoning"]
    assert "visionlog" in match["reasoning"]


def test_heuristic_ratchet_no_longer_fires_on_counter_action_tick():
    """Regression for promoted refinement cd_243cdb7f6b.

    Previously: 5 ticks clustering on 'ratchet' signature followed by a
    6th tick with 'cross-model-review' signature would fire heuristic-
    ratchet on the 6th tick — i.e., the tick that BROKE the drift. After
    the refinement, _signature_cluster excludes the final tick when its
    signature differs from the prefix's dominant signature.
    """
    ticks = [
        {"measurement": i, "signature": "ratchet", "model": "claude-opus-4-7"}
        for i in range(5)
    ]
    ticks.append(
        {
            "measurement": 99,
            "signature": "cross-model-review",
            "model": "openai/gpt-5.2",
        }
    )
    match = patterns.match(ticks)
    # The basis-change tick (#6) must not fire heuristic-ratchet.
    # It may still fire something else — but not this false positive.
    if match is not None:
        assert match["drift_category"] != "heuristic-ratchet"


def test_monolithic_loop_pattern_triggers_pivot():
    ticks = [
        {"measurement": i, "signature": f"sig_{i}", "model": "claude-opus"}
        for i in range(6)
    ]
    # Force at least one delta so zero-delta-churn doesn't trip first.
    ticks[-1]["measurement"] = 999
    match = patterns.match(ticks)
    assert match is not None
    assert match["drift_category"] == "monolithic-loop"
    assert match["signal"] == "pivot"


def test_heterogeneous_fleet_escapes_monolithic_pattern():
    ticks = [
        {
            "measurement": i,
            "signature": f"sig_{i}",
            "model": "claude-opus" if i % 2 == 0 else "gpt-5",
        }
        for i in range(6)
    ]
    ticks[-1]["measurement"] = 999
    match = patterns.match(ticks)
    # Heterogeneous fleet means monolithic-loop does NOT trip — may still
    # match another pattern, but if it matches, it shouldn't be monolithic.
    if match:
        assert match["drift_category"] != "monolithic-loop"


def test_trial_insert_and_promote_blocks_without_evidence(db_path):
    """Unconditional promote was replaced by an empirical bar. Fresh
    candidates with no applications must be blocked."""
    trial_id = store.insert_trial_candidates(
        kind="pattern_name",
        candidates=[
            {"text": "candidate-a", "reasoning": "a", "authored_by": "claude-opus"},
            {"text": "candidate-b", "reasoning": "b", "authored_by": "gpt-5"},
        ],
        db_path=db_path,
    )
    rows = store.trial_candidates(trial_id, db_path=db_path)
    assert len(rows) == 2
    assert all(r["status"] == "trialing" for r in rows)
    with pytest.raises(store.PromotionBlocked):
        store.promote_candidate(rows[0]["candidate_id"], db_path=db_path)


def test_caretaking_drift_fires_on_hedging_language():
    ticks = [
        {"measurement": 1, "signature": "work", "action_summary": "shipped the fix"},
        {
            "measurement": 2,
            "signature": "work",
            "action_summary": "want me to add tests?",
        },
    ]
    match = patterns.match(ticks)
    assert match is not None
    assert match["drift_category"] == "caretaking-drift"
    assert match["signal"] == "pivot"
    assert "act" in match["reasoning"].lower()


def test_caretaking_drift_fires_end_to_end_through_tick_handler(tmp_path):
    """Integration regression: the tick handler must pass action_summary
    into patterns.match. An earlier version only forwarded measurement/
    signature/model so caretaking-drift silently never fired via MCP."""
    import asyncio
    from telos_md import store, tools as lh_tools

    repo = str(tmp_path)
    nsid = store.register_north_star(goal="t", repo_path=repo)

    async def call():
        return await lh_tools.handle_tool(
            "telos_tick",
            {
                "north_star_id": nsid,
                "action_summary": "want me to add more coverage?",
                "measurement": 1,
                "signature": "verify-caretaking",
                "repo_path": repo,
            },
        )

    result = asyncio.run(call())
    assert result["drift_category"] == "caretaking-drift"
    assert result["signal"] == "pivot"


def test_goal_unreviewed_detector_finds_evidence():
    from telos_md import patterns
    import tempfile

    with tempfile.TemporaryDirectory() as d:
        (Path(d) / ".visionlog" / "adr").mkdir(parents=True)
        (Path(d) / ".visionlog" / "adr" / "ADR-001.md").write_text(
            "# Reduce p95 latency below 200ms\n\nEvidence: ..."
        )
        # Goal matches ADR content → not unreviewed.
        assert patterns.goal_unreviewed(d, "Reduce p95 latency below 200ms") is False


def test_goal_unreviewed_detector_fires_on_missing_evidence(tmp_path):
    from telos_md import patterns

    # Empty repo, no trilogy artifacts → unreviewed.
    assert patterns.goal_unreviewed(str(tmp_path), "some unearned goal") is True


def test_spec_drift_detects_missing_tool():
    from telos_md import patterns
    import tempfile

    with tempfile.NamedTemporaryFile(mode="w", suffix=".md", delete=False) as f:
        f.write("SPEC promises telos_set_north_star and telos_md_unicorn.")
        spec = f.name
    try:
        result = patterns.spec_drift(spec, ["telos_set_north_star"])
        assert any(m["name"] == "telos_md_unicorn" for m in result)
        assert all(m["kind"] == "in_spec_not_code" for m in result)
    finally:
        import os

        os.unlink(spec)


def test_goal_unreviewed_surfaces_at_registration(tmp_path):
    import asyncio
    from telos_md import tools as lh_tools

    result = asyncio.run(
        lh_tools.handle_tool(
            "telos_set_north_star",
            {
                "goal": "totally unearned new objective",
                "metric": "some_trajectory",
                "repo_path": str(tmp_path),
            },
        )
    )
    assert any(w["kind"] == "goal-unreviewed" for w in result["warnings"])


def test_counter_metric_produces_registration_warning(tmp_path):
    """Ojo-session feedback (2026-04-20): counter-style metrics (n/5,
    done/not done) leave no room for drift detection — every tick is
    just +1. Telos warns at registration so pods can pick a
    trajectory metric instead."""
    import asyncio
    from telos_md import tools as lh_tools

    result = asyncio.run(
        lh_tools.handle_tool(
            "telos_set_north_star",
            {
                "goal": "ship the thing",
                "metric": "steps_done/5",
                "repo_path": str(tmp_path),
            },
        )
    )
    assert result["warnings"]
    assert any(w["kind"] == "counter_metric" for w in result["warnings"])


def test_trajectory_metric_has_no_counter_warning(tmp_path):
    import asyncio
    from telos_md import tools as lh_tools

    result = asyncio.run(
        lh_tools.handle_tool(
            "telos_set_north_star",
            {
                "goal": "reduce p95 latency",
                "metric": "p95_latency_ms",
                "repo_path": str(tmp_path),
            },
        )
    )
    assert not any(w["kind"] == "counter_metric" for w in result["warnings"])


def test_event_starvation_fires_when_waiting_language_with_flat_measurement():
    """Deepseek-proposed pattern: pod stuck waiting on external
    dependency across 3 ticks with flat measurement. Must fire
    event-starvation (not zero-delta-churn) because the causal
    pattern is specific — external blocker, not generic saturation."""
    ticks = [
        {"measurement": 42, "action_summary": "waiting for API quota reset"},
        {"measurement": 42, "action_summary": "still no response from vendor"},
        {"measurement": 42, "action_summary": "blocked on approval from legal"},
    ]
    match = patterns.match(ticks, stop_zero_delta_n=5)
    assert match is not None
    assert match["drift_category"] == "event-starvation"
    assert (
        "fall back" in match["reasoning"].lower()
        or "re-evaluate" in match["reasoning"].lower()
    )


def test_event_starvation_does_not_fire_on_plain_stagnation():
    """Plain flat measurement without blocking language is zero-delta-
    churn territory, not event-starvation. The detector must distinguish
    causal (external blocker) from symptomatic (just saturated)."""
    ticks = [
        {"measurement": 42, "action_summary": "tried approach A"},
        {"measurement": 42, "action_summary": "tried approach B"},
        {"measurement": 42, "action_summary": "tried approach C"},
    ]
    match = patterns.match(ticks, stop_zero_delta_n=3)
    # zero-delta-churn wins here, not event-starvation
    if match is not None:
        assert match["drift_category"] != "event-starvation"


def test_event_starvation_does_not_fire_when_measurement_moves():
    """If measurement is moving, the pod isn't actually starved even
    if it mentions waiting."""
    ticks = [
        {"measurement": 10, "action_summary": "waiting for some data"},
        {"measurement": 11, "action_summary": "waiting for some data"},
        {"measurement": 12, "action_summary": "waiting for some data"},
    ]
    match = patterns.match(ticks, stop_zero_delta_n=5)
    if match is not None:
        assert match["drift_category"] != "event-starvation"


def test_caretaking_drift_catches_non_claude_hedging_phrasings():
    """Gemini-proposed + gpt-5.2-filtered markers catch hedging phrasings
    that claude-authored markers missed. Demonstrates cross-model
    contribution to the pattern library."""
    for phrasing in (
        "finished the slice — does that sound good?",
        "which would you prefer for the next pass?",
        "refactor is staged — are you ready to proceed with merge?",
    ):
        ticks = [
            {"measurement": 1, "signature": "work", "action_summary": "shipped fix"},
            {"measurement": 2, "signature": "work", "action_summary": phrasing},
        ]
        match = patterns.match(ticks)
        assert match is not None, f"caretaking should fire on: {phrasing}"
        assert match["drift_category"] == "caretaking-drift"


def test_caretaking_drift_does_not_fire_on_rejected_markers():
    """gpt-5.2 rejected 'happy to proceed' and 'ready when you are' from
    gemini's proposal because they appear in non-caretaking copy. These
    phrasings in an action summary must NOT fire caretaking-drift."""
    for phrasing in (
        "pipeline is happy to proceed after approvals",
        "server is ready when you are testing",
    ):
        ticks = [
            {"measurement": 1, "signature": "work", "action_summary": "shipped fix"},
            {"measurement": 2, "signature": "work", "action_summary": phrasing},
        ]
        match = patterns.match(ticks)
        if match is not None:
            assert match["drift_category"] != "caretaking-drift"


def test_caretaking_drift_does_not_fire_on_normal_action():
    ticks = [
        {
            "measurement": 1,
            "signature": "work",
            "action_summary": "added caching layer",
        },
    ]
    match = patterns.match(ticks)
    # No caretaking, and too few ticks for any other pattern.
    assert match is None


def test_mcp_tools_module_loads():
    """Ensure the tool definitions parse — catches MCP schema typos."""
    from telos_md import tools

    assert len(tools.TOOLS) == 9
    names = {t.name for t in tools.TOOLS}
    assert names == {
        "telos_set_north_star",
        "telos_tick",
        "telos_close",
        "telos_hypothesize",
        "telos_trial_status",
        "telos_promote",
        "telos_reload",
        "telos_patterns",
        "telos_traffic",
    }


def test_mcp_calls_are_logged_per_repo(tmp_path):
    """Every MCP call with a resolvable repo_path must append a JSONL
    line to <repo>/.telos/log/YYYY-MM-DD.jsonl with inbound args,
    outbound result, and timing."""
    import asyncio
    import json as _json
    from telos_md import tools

    repo = str(tmp_path / "watched")
    (tmp_path / "watched").mkdir()
    # Register a north star (repo_path is explicit).
    result = asyncio.run(
        tools.handle_tool(
            "telos_set_north_star",
            {
                "goal": "test logging",
                "metric": "trajectory",
                "repo_path": repo,
            },
        )
    )
    nsid = result["north_star_id"]
    # Tick (repo_path explicit).
    asyncio.run(
        tools.handle_tool(
            "telos_tick",
            {
                "north_star_id": nsid,
                "action_summary": "logged this tick",
                "measurement": 1,
                "repo_path": repo,
            },
        )
    )
    log_dir = Path(repo) / ".telos" / "log"
    assert log_dir.exists()
    files = list(log_dir.glob("*.jsonl"))
    assert len(files) == 1
    lines = files[0].read_text().strip().splitlines()
    assert len(lines) == 2
    entry = _json.loads(lines[0])
    assert entry["tool"] == "telos_set_north_star"
    assert entry["arguments"]["goal"] == "test logging"
    assert entry["result"]["north_star_id"] == nsid
    assert entry["error"] is None
    second = _json.loads(lines[1])
    assert second["tool"] == "telos_tick"
    assert second["arguments"]["action_summary"] == "logged this tick"


def test_mcp_logs_capture_errors_not_just_success(tmp_path):
    """Tool calls that raise must still produce a log entry with
    error populated. Essential for debugging via the log."""
    import asyncio
    import json as _json
    from telos_md import tools

    repo = str(tmp_path / "watched")
    (tmp_path / "watched").mkdir()
    # Invalid NS id — tick will fail.
    try:
        asyncio.run(
            tools.handle_tool(
                "telos_tick",
                {
                    "north_star_id": "ns_nonexistent",
                    "action_summary": "should fail",
                    "measurement": 1,
                    "repo_path": repo,
                },
            )
        )
    except Exception:
        pass
    log_dir = Path(repo) / ".telos" / "log"
    files = list(log_dir.glob("*.jsonl"))
    assert len(files) == 1
    entry = _json.loads(files[0].read_text().strip().splitlines()[0])
    assert entry["error"] is not None
    assert entry["result"] is None


def test_telos_patterns_returns_seed_library():
    import asyncio
    from telos_md import tools

    result = asyncio.run(tools.handle_tool("telos_patterns", {}))
    assert "seed" in result
    assert len(result["seed"]) >= 5
    assert any(p["name"] == "monolithic-loop" for p in result["seed"])


def test_telos_traffic_returns_only_open_ns(tmp_path):
    import asyncio
    from telos_md import tools, store

    repo = str(tmp_path / "demo")
    (tmp_path / "demo").mkdir()
    open_ns = store.register_north_star(goal="still running", repo_path=repo)
    closed_ns = store.register_north_star(goal="done", repo_path=repo)
    store.close_north_star(closed_ns, outcome="reached", repo_path=repo)
    result = asyncio.run(tools.handle_tool("telos_traffic", {"repo_path": repo}))
    ids = {a["north_star_id"] for a in result["active"]}
    assert open_ns in ids
    assert closed_ns not in ids


def test_telos_reload_returns_module_list():
    import asyncio
    from telos_md import tools

    result = asyncio.run(tools.handle_tool("telos_reload", {}))
    assert "reloaded" in result
    assert "telos_md.patterns" in result["reloaded"]
    assert "telos_md.store" in result["reloaded"]
