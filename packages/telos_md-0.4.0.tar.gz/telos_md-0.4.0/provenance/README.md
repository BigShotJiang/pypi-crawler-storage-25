# provenance

Raw conversation exports and session artifacts that produced lighthouse. These are primary sources — the actual dialogues, not summaries.

The user's explicit concern during design: *"We spent time to generate these insights. I don't want to lose data."*

`GENESIS.md` at the repo root is the curated story. This directory is the unabridged record behind it — available for anyone (human or agent) who wants to see how decisions were actually reached, not just what conclusions were canonized.

## Contents

### `2026-04-19-genesis-session.jsonl` (10.3 MB)

The raw Claude Code session transcript in JSONL format — native ground truth. Every user message, assistant message, tool call, and tool result in chronological order. One JSON object per line.

Includes: the 15+ iteration ojo self-improve loop, the retrospective that named the drift modes, the MCP tool brainstorm and convergence on *lighthouse + north star* as the name, the St Peter integration, the Krebs/organism metaphor discussion, the reading of `eidosagi.com/language-as-momentum` and its integration, the HITL-to-empirical-validation correction, the MVP scaffolding, the dogfood test.

The `/export` slash command produced 0-byte files for this session — likely size-related. This JSONL was copied directly from `~/.claude/projects/-Users-dshanklinbv-repos-eidos-agi-ojo/<session-id>.jsonl`.

### `2026-04-19-genesis-transcript.md` (285 KB)

Human-readable markdown extraction of the same session. Tool calls and tool results stripped; only user messages and assistant text responses remain. 242 turns. Skim-able in an afternoon; the JSONL is not.

Generated from the JSONL by pulling `type: "user" | "assistant"` records and collapsing consecutive same-role turns. `<system-reminder>` blocks removed since they are not user-authored content.

## Format and caveats

- **Private data.** The JSONL includes tool outputs that reference real files from the user's machine (paths, filenames from `~/Downloads`, including items like a background-check authorization PDF). This repo is private for that reason among others. Do not publish either file without a review pass.
- **Unredacted.** No sensitive-string scrubbing was applied. If a secret or API key happened to land in a tool output or message, it is in these files as-is.
- **Ground truth.** When the curated docs and the raw record disagree, the raw record wins for the question *"what did we actually say?"* The curated docs win for *"what did we decide was durable."* Both are valid, neither subsumes the other.

## Why preserved

Future decisions may contradict what's in the curated docs. When that happens, the question "but what did they *actually* decide and why?" is answerable only if the raw record survives. This is also a hedge against our own summarization — curated docs smooth out the corrections, walkbacks, and wrong turns that themselves encode useful information.

Example already in this transcript: the HITL-ratification design was added, committed, and then reversed in a single exchange when the user pointed out it was a regression. The curated `LEARNING.md` shows only the corrected design. The transcript shows both and the argument that flipped one to the other. That argument is the thing worth being able to re-read.

See `LEARNING.md` → "Pattern discovery — unexpected drift" for the related mechanism: candidate patterns that couldn't be matched get their raw signatures preserved for naming. Same principle here, for whole sessions.
