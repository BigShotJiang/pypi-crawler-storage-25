---
id: ADR-005
title: Rename lighthouse → telos-md and correct the mental model
status: accepted
date: 2026-05-13
supersedes: []
superseded_by: []
related: [ADR-003]
---

# ADR-005: Rename `lighthouse` → `telos-md` and correct the mental model

## Status

Accepted 2026-05-13.

## Context

This tool was originally named `lighthouse`, with a naval mental model built up across `README.md`, `SHIPS_AND_SHORE.md`, `PHILOSOPHY.md`, and `USING_LIGHTHOUSE.md`. The model: ships (trilogies of `research.md` / `governor` / `docket.md`) declare their own north star; the lighthouse-on-shore observes traffic relative to those declared courses; it signals drift, "does not row, does not set the destination, watches and nudges via walkie-talkie."

That framing under-described what the tool actually does. `lighthouse_set_north_star` was always a **custody act** — the tool *records* the goal, the trajectory metric, and the stop conditions; from that moment until `lighthouse_close` it holds the contract. The naval metaphor read this as "observation of a ship's declared course," but in mechanism the registration is what creates the contract the rest of the loop is measured against. The tool was always doing two things — custody and drift — and the metaphor only described one of them.

Concurrently, the eidosagi.com homepage canonicalized the architecture as **Telos pulls. Praxis steers.** Telos = the unchanging vision the project is for; Praxis = the steering loop that returns trajectories to it. Lighthouse-the-tool implements what the homepage calls Telos. Lighthouse-the-name didn't.

## Decision

Rename the package, the module, the dotfile directory, and all MCP tool function names. Replace the naval mental model with a mechanism-first description.

### Identifier changes

| Layer | Before | After |
|---|---|---|
| PyPI package | `lighthouse` (name was taken by an unrelated project; never published under that name) | `telos-md` (new on PyPI, org-owned by eidos-agi via the Nov 2025 PyPI org-level Pending Trusted Publisher feature) |
| Python module | `lighthouse` (`src/lighthouse/`) | `telos_md` (`src/telos_md/`) |
| GitHub repo | `eidos-agi/lighthouse` | `eidos-agi/telos.md` |
| MCP server identity | `Server("lighthouse")` | `Server("telos")` (consumers see `mcp__telos__*`) |
| CLI entry | `lighthouse-mcp` | `telos` |
| Dotfile state directory | `<repo>/.lighthouse/` | `<repo>/.telos/` |
| Tool function names | `lighthouse_set_north_star`, `lighthouse_tick`, `lighthouse_close`, `lighthouse_hypothesize`, `lighthouse_trial_status`, `lighthouse_patterns`, `lighthouse_traffic`, `lighthouse_reload`, `lighthouse_promote` | `telos_set_north_star`, `telos_tick`, `telos_close`, `telos_hypothesize`, `telos_trial_status`, `telos_patterns`, `telos_traffic`, `telos_reload`, `telos_promote` |
| Version | 0.2.1 | 0.3.0 |

### Conceptual changes

The naval Ships-and-Shore mental model is retired. Replaced with a **two-axis mechanism description**:

- **Custody axis (registration → closure):** `telos_set_north_star` records the contract; `telos_close` discharges it. Between those, the contract is the tool's responsibility. The tool refuses to silently accept ticks that abandon the contract.
- **Drift axis (tick by tick):** `telos_tick` measures the iteration against the contract and the recent history, names matched failure-mode patterns, and points at counter-actions.

The load-bearing rule that replaces "observer, not commander":

> **Custodial-directive, counter-action-advisory.**
>
> At the contract boundary, Telos is directive — the contract it holds is the contract; the tool will not silently let it drop. At the counter-action boundary, Telos is advisory — when drift fires, the tool names the pattern and points at a counter-action, but the pod runs the response in its own Socratic dialogue. Drop the directive half and the tool becomes a recommendation engine the pod can ignore mid-loop. Drop the advisory half and the language-transfer medium degenerates into compliance.

Both halves are required.

### Documents

- `README.md` — substantially rewritten around the two-axis mechanism; new opening establishes custodial-directive / counter-action-advisory as the load-bearing distinction.
- `SHIPS_AND_SHORE.md` — **deleted.** Replaced with `TELOS_CUSTODY.md` (two-axis ASCII diagram, no ships, no shore, no waves).
- `PHILOSOPHY.md` — surgical reframe of the "Why lighthouse is observer, not commander" section into "Custodial-directive, counter-action-advisory." Language-as-momentum thesis preserved unchanged.
- `USING_LIGHTHOUSE.md` → `USING_TELOS.md` — renamed; identifier sweep; the "goals wrong at registration" passage reframed as "goals unearned at registration" with the corrective routing back to `research.md`.
- `GENESIS.md` — preserved as historical record with a banner noting the original framing and that the rename happened.
- `LEARNING.md`, `SPEC.md` — surgical identifier sweep; mechanism docs unaffected.

## Preserved unchanged

- The 9 MCP tools and their semantics (only names change).
- The 5 AGI-substrate sub-properties from ADR-003: persistence of decision, heterogeneity, contract-earning, empirical validation, self-observation.
- The named drift patterns: `monolithic-loop`, `heuristic-ratchet`, `zero-delta-churn`, `caretaking-drift`, `execution-without-decision`, `same-signature-repeat`.
- The empirical promotion gates: applications ≥ 5, signal_outcome_score ≥ 0.2, lift ≥ 0.4 over null, regression test passes, cross-model review approved, strictly-best sibling on the rank cascade.
- ADR-001 (file-only storage), ADR-002 (empirical promotion gates), ADR-003 (AGI-substrate thesis), ADR-004 (session-internal scores) — all stand. The thesis text in ADR-003 ("lighthouse exists to make the system containing it more AGI-like") will get an editor's note via this ADR; the conceptual anchor is unchanged.

## Discarded

- The "Ships and Shore" mental model. `SHIPS_AND_SHORE.md` was deleted, not preserved as a deprecated mirror — GENESIS.md already serves as the historical record of the original framing. Preserving two mental-model docs would create a fork in the doc tree where every future reader has to figure out which is authoritative.
- The "lighthouse does not set the destination" framing in `PHILOSOPHY.md`. That sentence was the load-bearing under-description: the tool *is* the custodian of the destination once `set_north_star` runs.
- Backward-compat MCP tool aliases (`mcp__lighthouse__*`). Same playbook as the ike→docket and visionlog→governor renames: cut clean per [`feedback_no_codename_brand_splits_at_solo_scale`] — two names = forever friction at solo scale. The `telos-migrate` companion tool sweeps consumer settings allowlists and `.lighthouse/` directories.

## Companion rename pending

`hone → praxis-md` is the parallel rename that completes the Telos / Praxis pair from the eidosagi.com homepage:

- `telos-md` (this package) = the custody-and-drift discipline = what the homepage calls Telos
- `praxis-md` (the future rename of `hone`) = the per-tick action-and-reflection ceremony = what the homepage calls Praxis

That rename is not done in this ADR. Two reasons to defer: (a) `hone` is more widely deployed than lighthouse was, so the migration blast radius is larger; (b) one open question — whether `telos_tick` belongs on the Telos side or migrates to Praxis when `hone` is renamed — should be answered as part of the hone→praxis decision, not pre-empted here. The `tick` verb arguably belongs to Praxis (per-tick discipline) more than Telos (custodian of the unchanging). Flagging for the future ADR.

## Migration steps already taken in this ADR's commits

1. `src/lighthouse/` → `src/telos_md/` (git mv + sed sweep)
2. `pyproject.toml`: name, version, scripts, urls, packages
3. `.lighthouse/` → `.telos/` (plain mv; gitignored)
4. `.gitignore`: `.lighthouse/` → `.telos/`
5. Tool function names renamed in `src/telos_md/tools.py`
6. Tests updated; 75/75 passing
7. `patterns.spec_drift` regex widened to `r"telos(?:_md)?_[a-z_]+"` to match both old fixture forms and new tool names
8. `src/telos_md/migrate_from_lighthouse.py` added (CLI: `telos-migrate`)
9. `.github/workflows/ci.yml` + `publish.yml` added (repo previously had no CI)
10. Docs rewritten/renamed/deleted per the per-doc disposition above
11. This ADR recorded

## Migration steps remaining (Daniel-actions)

1. Rename GitHub repo `eidos-agi/lighthouse` → `eidos-agi/telos.md`
2. Set up org-level Pending Trusted Publisher on PyPI: org `eidos-agi`, package `telos-md`, repo `eidos-agi/telos.md`, workflow `publish.yml`, environment `pypi`
3. Tag and push `v0.3.0`
4. Once published: `uv tool install telos-md` locally; run `telos-migrate --root ~/repos-eidos-agi --apply` and `--root ~/repos-eidos-capital --apply` to sweep all 15 consumer projects + 6 known external repos with `mcp__lighthouse__*` allowlist references
5. Swap `claude mcp` config: remove `lighthouse` server entry, add `telos`
6. Restart any active Claude Code sessions so the `mcp__telos__*` tools resolve

## Falsification record

- The naval mental model was load-bearing for one specific under-description: "lighthouse does not set the destination." If a future review finds that the *custodial* half of the corrected model also has an under-description that this ADR missed, that finding supersedes this ADR.
- The decision to delete `SHIPS_AND_SHORE.md` rather than preserve it depends on `GENESIS.md` being sufficient as the historical record. If a future reader wants to recover the naval mental model in detail, `provenance/2026-04-19-genesis-transcript.md` has the original framing in extended form.
- The hone→praxis rename is conjectured to follow the same playbook. If that rename runs into friction this one didn't (different blast radius, different consumer surface), this ADR's "same playbook" assumption is wrong and the hone ADR should record the divergence.

## References

- [`.governor/adr/ADR-001`](./ADR-001-storage-is-files-not-sqlite-per-repo-git-diffable-.md) — file-only storage
- [`.governor/adr/ADR-002`](./ADR-002-promotion-gates-require-empirical-evidence-not-edi.md) — empirical promotion gates
- [`.governor/adr/ADR-003`](./ADR-003-thesis-sharpening-lighthouse-is-agi-substrate-disc.md) — AGI-substrate thesis (the conceptual anchor; identifier-renamed but text intact)
- [`.governor/adr/ADR-004`](./ADR-004-session-internal-scores-are-captured-metrics-not-c.md) — session-internal scores
- `feedback_no_codename_brand_splits_at_solo_scale` in cockpit-eidos memory — the rule that justifies cutting clean without backward-compat aliases at solo scale
- `cockpit-eidos/decisions/2026-05-11-trilogy-rename-visionlog-to-governor-ike-to-docket.md` (precedent)
- `eidosagi.com/src/pages/index.astro` — homepage architecture diagram naming "Telos pulls. Praxis steers."
