# How telos-md learns

The pattern library seeded in `PATTERNS.md` / `SPEC.md` is a starting point, not a ceiling. Telos's long-term value depends on the library growing faster than novel failure modes emerge — and the quality of existing patterns improving with use.

This document specifies *how*.

## The criterion

If telos-md cannot improve itself and its docs based on experience, the user ends up doing the labor. That is the failure mode this tool exists to prevent. Everything else — elegance, architecture, philosophy — is downstream.

This section is the design commitment.

### No human-in-the-loop

Human-in-the-loop is a regression, not a feature. A human can't ratify patterns from 1000 loops. Even lightweight 30-second decisions don't scale. Any architecture that routes through human judgment on the per-pattern, per-counter-action, or per-doc-diff level has already failed the criterion — it just fails more politely than an empty pattern library.

Telos must improve via **empirical validation**, not approval. The scientific method, not editorial review.

### The mechanism: propose → trial → measure → promote/deprecate

When the meta-loop surfaces a candidate (unnamed recurring divergence, slipping counter-action, philosophy claim contradicted by data), telos-md:

1. **Hypothesizes.** Invokes an LLM (heterogeneous fleet if available) to propose N candidate artifacts — candidate names, candidate counter-actions, candidate pattern refinements, candidate doc revisions. Multiple candidates per slot, because the point is competition.

2. **Trials.** Each candidate enters a trial pool. Incoming loops that would match the candidate's shape get one of the candidates applied provisionally. Different loops get different candidates; this is A/B (or A/B/C/...) testing at the pattern level. Candidates tag their outputs so their effect can be traced.

3. **Measures.** Telos tracks each candidate's signal-outcome correlation, counter-action efficacy, and downstream-reference rate (did any subsequent pod invoke this named pattern, reference this counter-action, quote this doc passage?). Measurement is statistical, not narrative.

4. **Promotes or deprecates.** A candidate that accumulates statistically significant positive signal over N trials gets promoted: telos-md writes it into the pattern library, edits the appropriate doc, commits. A candidate that fails to outperform the null hypothesis (do nothing) gets retired. Undecided candidates keep trialing until budget exhausts.

5. **Self-revises docs.** When a `PHILOSOPHY.md` claim is contradicted by accumulated data — e.g., heterogeneous fleets don't actually produce different convergence behavior — telos-md drafts a revision and applies it. The doc is a hypothesis too. It gets tested.

No human ratifies. Telos edits its own docs, its own pattern library, its own counter-actions. The tests decide.

### What the human is still for

**Meta-governance, not per-item review.** The rare roles that remain human:

- **Intent-setting.** Declaring what a north star's success means when first registering it (telos-md can't decide what you actually want).
- **Permission for expensive or irreversible actions.** Deploying to production, sending emails, making payments — telos-md does not unilaterally authorize these.
- **Checking that the measurements themselves are aligned with intent.** Once a quarter, someone asks: are signal-outcome correlations measuring the right thing? Has telos-md Goodharted itself into a metric that looks good but drifted from the intent? This is the self-audit on telos-md's own measurement apparatus, and it is fundamentally about whether the test infrastructure is valid — a category humans are still better at than any automated substrate.

These are rare, coarse-grained, and do not touch the per-pattern flow. The per-pattern flow is entirely inside telos-md.

### The dogfooding constraint

Telos's self-improvement loop — pattern naming, counter-action drafting, doc integration — **must invoke heterogeneous models when available**. If telos-md's meta-loop runs monocultural (same model authoring every candidate, single geometry generating every hypothesis), the philosophy doc becomes hypocritical and the tool replicates exactly the `monolithic-loop` failure it is designed to catch.

Dogfooding is not a nice-to-have. It is a correctness constraint on the self-improvement loop itself. A monocultural telos-md is a broken telos-md, even if every individual output reads well.

When heterogeneous fleets aren't available (single-model deployments), telos-md must flag the limitation in its trial output rather than silently running monocultural. Trial results from a monocultural telos-md are lower-confidence than results from a heterogeneous one.

### What this requires that current AI systems struggle with

Most of the trial architecture is tractable with today's tools. One piece is harder: **measuring whether a name is good**. Counter-action efficacy is measurable (did the recommended pivot correlate with better outcomes?). Pattern matching quality is measurable (did the named pattern fire on genuine instances?). But names also have to be memorable, communicable, adopted.

The measurable proxy: **downstream reference rate**. A name that nobody ever refers to — no pod invokes it, no counter-action cites it, no doc links it — is a name that failed. Telos tracks reference rate and retires names that remain unreferenced after N loops. Names that get referenced (signal: the name is useful to other pods) survive.

This is imperfect but not human-in-the-loop. The test is empirical — does this name get picked up by the ecosystem — rather than editorial — does someone vote it good.

## Three kinds of learning

### 1. Pattern refinement — signals that don't track outcomes

Each tick produces a signal (`continue` / `pivot` / `stop`). Each loop eventually closes with an outcome (`reached` / `abandoned` / `converged` / `pivoted`). The two are observable in pairs.

Telos tracks **signal-outcome correlation** per pattern:
- When pattern `heuristic-ratchet` fired and telos-md signaled `stop`, did the user/pod actually stop? Did closing out show the work was saturated?
- When telos-md signaled `continue` but the outcome was `abandoned` within 3 more ticks, the signal was late.
- When telos-md signaled `pivot` and the outcome was `reached` (the new direction worked), the pattern's counter-action is validated.

A pattern whose signals reliably correlate with outcomes stays in the library. A pattern whose signals misfire more than some threshold gets flagged for refinement. A pattern that always misfires gets deprecated.

This is the same discipline brutal-forge applies to its findings: audits that get contested and overturned lower the audit's severity grading over time.

### 2. Pattern discovery — unexpected drift

Most interesting: the loops that *end in ways the pattern library didn't predict*. A loop that telos-md never flagged as drifting, but which closed as `abandoned` or `pivoted`, is evidence of an unnamed pattern.

Telos should, at close-out, produce a structured diff:
- Predicted trajectory (based on pattern matching per tick)
- Actual trajectory (ticks + outcome)
- Divergence: moments where the prediction and the behavior disagreed

A recurring divergence signature — not matched by any named pattern — is a **candidate**. Candidates are surfaced to the user (or to a higher-order reviewer pod) for naming. Naming is the critical step: an unnamed pattern is recognized by no one; a named pattern becomes usable by every future pod.

This is the mechanism by which the library grows beyond what any single session can surface. Today's session contributed six patterns. Tomorrow's loops — running on completely different tasks — will surface patterns today's retrospective couldn't see, because the patterns weren't active.

### 3. Counter-action refinement

Each pattern ships with a recommended counter-action (`pivot to finding-following`, `declare a tightening budget`, etc.). When a loop triggers a pattern and the pod takes the counter-action, did it work?

Telos tracks **counter-action efficacy**:
- Took counter-action → outcome improved: +1 for that counter-action
- Took counter-action → outcome unchanged or worse: -1
- Ignored counter-action → outcome was fine: the pattern may be overly conservative

Over time, high-efficacy counter-actions become the default suggestion; low-efficacy ones get rewritten or split into more specific patterns. This is the same loop that makes a physician's diagnostic intuition sharpen with patient volume.

## The meta-loop

Telos watches loops. Who watches telos-md?

Telos runs a **self-audit loop** on a long cadence (weekly, monthly, per-release — tunable). Its north star is: *increase pattern-library signal-outcome correlation*. Its ticks are summaries of the prior period's loops: how many fired, how many patterns matched, how many matched correctly, how many candidates accumulated.

If the self-audit loop saturates (zero-delta across audits), telos-md flags that *the library has stopped improving on its current workload* — time to expand the domain, onboard more pods, or retire patterns that no longer fire. If the self-audit loop diverges (correlation dropping), something systemic is off — candidate for human review.

Telos is the first tool to dogfood itself at the architectural level: a coordination tool whose own improvement loop uses the coordination tool. This is the forcing function against meta-drift.

## What this enables

A few consequences worth stating explicitly:

**Patterns compound across pods.** A pattern named from one pod's session applies to every future pod's session on any task. This is the first piece of institutional memory in the eidos-agi stack that doesn't require a human to re-explain each time.

**Counter-actions compound across patterns.** A counter-action proven effective for `heuristic-ratchet` may turn out to be effective for `measurement-over-product` too. Telos should surface these cross-pattern findings.

**Signal quality is measurable.** Unlike most AI advisory tools, telos-md's outputs have ground truth: did the loop end when predicted? Did the recommended pivot pay off? That lets telos-md improve via ordinary feedback, not via expert curation alone.

**The library is the product.** Code is the delivery mechanism. The pattern library, accumulated signal-outcome correlations, and promoted candidates are the actual value. A telos-md deployment with a rich, validated library is categorically more useful than one with a richer codebase but an empty library.

## Model-diversity patterns

A dimension the initial pattern library underweighted, surfaced later via the *Language as Momentum* argument (see `PHILOSOPHY.md`): **the mathematical advantage of multi-agent architectures depends on genuinely different models**. Same-model ensembles perform lossy projection but land in nearly-the-same geometry. They get coordination benefits without serendipity benefits.

Telos tracks model identity per tick (via an optional `model` field). Patterns in this category:

### `monolithic-loop`
**Symptom**: one model running all iterations of a loop. No inter-model transfer, no momentum medium, just gradient descent on the scorecard within a single geometry.
**Example**: the originating ojo self-improve session. One Claude Opus pod, 15+ iterations, heuristic ratcheting. The math predicts exactly this drift — a single model can't escape its own loss landscape.
**Counter**: introduce a different model into the loop. Or invoke a consultant (rhea, brutal-forge, pal) whose output constitutes a projection into a different basis. Or pause and run the same task via research-md, forcing a trilogy-stage transition.

### `low-diversity-fleet`
**Symptom**: multi-agent architecture where every cell is the same base model with different prompts. Lossy projection happens, but the landing point is in almost-the-same geometry.
**Counter**: heterogeneous model fleets (Claude / GPT / Gemini / local Llama) for tasks where serendipity is the bottleneck. Same-model fleets remain appropriate for coordination-only tasks.

### `degenerate-medium`
**Symptom**: successive ticks' action signatures cluster tightly. The lossy medium has degenerated into a lossless one — the pod is projecting and unprojecting within a single narrow neighborhood.
**Counter**: change the basis deliberately. Invoke a different tool. Run on real data. Transition to a different trilogy stage.

Tracking fleet diversity is also a meta-loop concern: over time, telos-md should report whether heterogeneous-fleet loops produce measurably different convergence behavior than monoculture ones. This is an empirically testable claim. Telos's own data — not external argument — is what confirms or falsifies it.

## Caveats

- **Recognition is not reasoning.** Telos applies patterns it knows. A genuinely novel failure mode requires the candidate-discovery loop + naming to eventually catch up. In the short term, unnamed failure modes slip through.
- **Naming remains human (for now).** Telos can accumulate candidates and cluster similar divergences. Whether it can *name* a new pattern well — give it the terse, memorable handle that makes it usable — is an open capability question. Pods can propose names; a higher-order reviewer (a named-pattern pod, a human, a consensus pod) should ratify.
- **Adversarial patterns exist.** A pod aware of telos-md's patterns could game them — triggering patterns it wants, suppressing ones it doesn't. Any self-improving system has an adversarial surface. Monitoring signal-outcome drift is the first defense; periodic brutal-forge audits of the pattern library itself is the second.
- **Model-diversity metrics depend on self-reporting.** Telos observes the `model` field a pod reports. A misconfigured or malicious pod can lie about which model it's running. Treat `low-diversity-fleet` signals as advisory until there's a trusted identity mechanism.

## How this connects to the broader system

- Pattern candidates that keep recurring across pods → escalate to `visionlog` as an ADR if the insight is architectural
- Named patterns with high-efficacy counter-actions → can be formalized into `research-md` as a verified decision
- Recurring loops for the same kind of work → candidates for automation or for a dedicated forge
- Telos's own candidate-naming capability is the first place to measure whether the eidos-agi stack has begun genuine metacognition, or is still pattern-matching on human-named handles.
