import sqlite3
import time
from pathlib import Path
from threading import Event, Thread
import yaml
from datetime import datetime
from secrets import token_hex, choice, randbelow
import zmq
import mq2db as mq2db_module
from mq2db import Mq2db

HERE = Path(__file__).parent


def produce_csv_messages(address: str, stop_event: Event, ready_event: Event, context: zmq.Context):
    socket = context.socket(zmq.PUB)
    socket.setsockopt(zmq.LINGER, 0)
    socket.bind(address)
    ready_event.set()
    try:
        while not stop_event.is_set():
            nmsgs = randbelow(10) + 1
            # SSR like dummy messages.
            msgs = []
            for _ in range(nmsgs):
                t = datetime.now().isoformat()
                rssi = randbelow(500) / 10
                msg = token_hex(choice([7, 14]))
                msgs.append(f"{t},{rssi},{msg}")
            socket.send_string("\n".join(msgs), zmq.DONTWAIT)
            time.sleep(0.1)
    finally:
        socket.close()


def test_csvloader(tmp_path, monkeypatch):
    context = zmq.Context()
    monkeypatch.setattr(mq2db_module.zmq, "Context", lambda: context)
    address = f"inproc://mq2db-test-{token_hex(8)}"
    db_path = tmp_path / "test_csvloader.sqlite3"

    # Start producer thread.
    stop_event = Event()
    ready_event = Event()
    producer_thread = Thread(
        target=produce_csv_messages,
        args=(address, stop_event, ready_event, context),
        daemon=True,
    )
    producer_thread.start()
    assert ready_event.wait(timeout=1)

    with open(HERE / "test_csvloader.yaml", encoding="utf-8") as f:
        conf = yaml.safe_load(f)
    target = conf["targets"]["test_csvloader"]
    target["address"] = address
    target["database"]["url"] = f"sqlite:///{db_path}"
    target["database"]["interval"] = {"milliseconds": 100}
    path_yaml = tmp_path / "test_csvloader.yaml"
    path_yaml.write_text(yaml.safe_dump(conf), encoding="utf-8")

    mq2db = Mq2db(path_yaml)
    mq2db.start(block=False)
    try:
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            if db_path.exists():
                with sqlite3.connect(db_path) as con:
                    count = con.execute("SELECT count(*) FROM test_csvloader").fetchone()[0]
                if count > 0:
                    break
            time.sleep(0.1)
        else:
            raise AssertionError("mq2db did not write CSV rows before the timeout")
    finally:
        stop_event.set()
        producer_thread.join(timeout=1)
        mq2db.stop()
        mq2db.join()
