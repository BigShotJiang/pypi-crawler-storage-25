from pathlib import Path
import yaml
from mq2db import Mq2db

HERE = Path(__file__).parent


def test_section(tmp_path):
    with open(HERE / "test_section.yaml", encoding="utf-8") as f:
        conf = yaml.safe_load(f)
    target = conf["mq2db"]["specific"]["configurations"]["targets"]["test_section"]
    target["database"]["url"] = f"sqlite:///{tmp_path / 'test_section.sqlite3'}"
    path_yaml = tmp_path / "test_section.yaml"
    path_yaml.write_text(yaml.safe_dump(conf), encoding="utf-8")

    mq2db = Mq2db(path_yaml, "mq2db.specific.configurations")
    try:
        assert str(mq2db) == "test_section: ipc:///tmp/mq2db-test_csvloader (SUB, connect)"
    finally:
        mq2db.close()
