# Changelog

All notable changes to this project are documented here.

## 1.0.0

- Add PyPI-oriented project metadata.
- Add MIT license metadata.
- Add CI for tests and distribution builds.
- Add tag-based PyPI release workflow.
- Add source distribution manifest for examples, changelog, and test fixtures.
- Add non-blocking mq2db startup support for tests and embedding.
- Close ZeroMQ resources explicitly when workers finish.
- Make the CSV loader integration test terminate on its own.

## 2025.09.15

- Add unique constraint configuration.
- Add `_timestamp_` automatic column support.

## 2025.09.09

- Initial public package structure and examples.
