"""Comprehensive test of all vaal features."""
import os
import sys
import json
import tempfile
import shutil

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
os.chdir(os.path.join(os.path.dirname(__file__), ".."))

R = {}

def t(name, cond):
    R[name] = bool(cond)
    print(f'  {"OK" if cond else "FAIL"}: {name}')


# ── TOOLS ──────────────────────────────────────────────

td = tempfile.mkdtemp(prefix="vt_")
os.makedirs(os.path.join(td, "src"))
hp = os.path.join(td, "src/hello.py")
open(hp, "w").write('def greet(name):\n    return f"Hello, {name}!"\nclass Foo:\n    pass\n')
open(os.path.join(td, "src/util.py"), "w").write("import os\ndef get_cwd():\n    return os.getcwd()\n")
open(os.path.join(td, "notes.md"), "w").write("# Notes\n")

print("=== BASH ===")
from vaal.tools.bash_tool import bash_tool
t("bash:echo", "hello" in bash_tool(command="echo hello"))
t("bash:ver", "Python" in bash_tool(command="python --version"))

print("=== FILE TOOLS ===")
from vaal.tools.file_tools import read_tool, write_tool, edit_tool
t("read", "def greet" in read_tool(file_path=hp))
t("read:miss", "error" in read_tool(file_path="/no/file").lower())
nf = os.path.join(td, "o.txt")
write_tool(file_path=nf, content="ok")
t("write", open(nf).read() == "ok")
edit_tool(file_path=hp, old_string="Hello", new_string="Hi")
t("edit", "Hi" in open(hp).read())
t("edit:miss", "not found" in edit_tool(file_path=hp, old_string="ZZ", new_string="x").lower())

print("=== SEARCH ===")
from vaal.tools.search_tools import glob_tool, grep_tool
t("glob", "hello.py" in glob_tool(pattern="**/*.py", path=td))
t("grep", "hello.py" in grep_tool(pattern="def greet", path=td))

print("=== LSP ===")
from vaal.tools.lsp_tools import find_definition, find_references, list_symbols, file_tree
t("lsp:def", "greet" in find_definition(symbol="greet", path=td))
t("lsp:refs", "greet" in find_references(symbol="greet", path=td))
t("lsp:sym", "greet" in list_symbols(file_path=hp))
t("lsp:tree", "src" in file_tree(path=td))

print("=== DIFF ===")
from vaal.tools.diff_tools import show_diff
f1, f2 = os.path.join(td, "a.txt"), os.path.join(td, "b.txt")
open(f1, "w").write("a\nb\n")
open(f2, "w").write("a\nc\n")
r = show_diff(file_a=f1, file_b=f2)
t("diff", "b" in r or "c" in r)

print("=== WEB ===")
from vaal.tools.web_tools import web_fetch, web_search
t("web:fetch", len(web_fetch(url="https://httpbin.org/get")) > 10)
t("web:search", len(web_search(query="python")) > 10)

print("=== MEMORY TOOLS ===")
from vaal.tools.memory_tools import save_memory_tool, search_memory_tool, list_memories_tool
save_memory_tool(name="_vt", content="t", memory_type="project", description="t")
t("mem:save", True)
t("mem:list", len(list_memories_tool()) >= 0)
t("mem:search", True)

print("=== NOTEBOOK ===")
from vaal.tools.notebook_tools import run_python, notebook_read, notebook_edit
t("py:print", "4" in run_python(code="print(2+2)"))
t("py:err", "Error" in run_python(code="1/0"))
t("py:expr", "[1, 2, 3]" in run_python(code="[1,2,3]"))
nbp = os.path.join(td, "t.ipynb")
json.dump({"nbformat": 4, "nbformat_minor": 5, "metadata": {}, "cells": [
    {"cell_type": "code", "metadata": {}, "source": ["x=1"], "execution_count": None, "outputs": []}
]}, open(nbp, "w"))
t("nb:read", "x=1" in notebook_read(path=nbp))
notebook_edit(path=nbp, action="insert_after", cell_index="0", content="y=2")
t("nb:edit", "2 cells" in notebook_read(path=nbp))
notebook_edit(path=nbp, action="replace", cell_index="0", content="z=3")
t("nb:replace", "z=3" in notebook_read(path=nbp, cell_index="0"))
notebook_edit(path=nbp, action="delete", cell_index="1")
t("nb:delete", "1 cells" in notebook_read(path=nbp))

print("=== SSH ===")
from vaal.tools.ssh_tools import ssh_exec
t("ssh:nc", "not connected" in ssh_exec(command="hi").lower())

print("=== TODO ===")
from vaal.core.task_manager import reset_task_manager
from vaal.tools.todo_tools import todo_create, todo_update, todo_list
reset_task_manager()
r = json.loads(todo_create(title="T"))
t("todo:create", r["status"] == "pending")
r2 = json.loads(todo_update(id=r["id"], status="completed"))
t("todo:update", r2["status"] == "completed")
t("todo:list", len(json.loads(todo_list())["todos"]) == 1)

print("=== AGENT TOOLS ===")
from vaal.tools.agent_tools import check_agent, list_agents, AGENT_TYPES
t("agent:types", len(AGENT_TYPES) == 5)
t("agent:list", "agents" in json.loads(list_agents()))
t("agent:miss", "error" in json.loads(check_agent(agent_id="xx")))

print("=== API ===")
from vaal.tools.api_tools import api_request, handle_api_command
t("api:get", len(api_request(method="GET", url="https://httpbin.org/get")) > 10)
t("api:hist", isinstance(handle_api_command("history"), str))

print("=== DB ===")
from vaal.tools.db_tools import handle_db_command
t("db:cmd", len(handle_db_command("")) > 0)

# ── CORE ──────────────────────────────────────────────

print("\n=== SESSION ===")
from vaal.core.session import Session
s = Session(model="test")
s.add_message("user", "hello")
s.add_message("assistant", "hi")
t("session:add", len(s.messages) == 2)
t("session:chat", len(s.get_chat_messages()) == 2)
s.save()
s2 = Session.load(s.session_id)
t("session:load", len(s2.messages) == 2)
t("session:list", isinstance(Session.list_sessions(), list))

print("=== CONTEXT ===")
from vaal.core.context import ContextManager, estimate_tokens, estimate_messages_tokens
cm = ContextManager(max_tokens=1000)
t("ctx:est", estimate_tokens("hello world") > 0)
t("ctx:pct", cm.usage_pct([{"role": "user", "content": "hi"}]) >= 0)

print("=== COST ===")
from vaal.core.cost_tracker import CostTracker
ct = CostTracker()
ct.record(label="t", input_tokens=100, output_tokens=50)
t("cost:total", ct.total_tokens == 150)
t("cost:summary", len(ct.summary()) > 0)

print("=== HISTORY ===")
from vaal.core.history import record_prompt, load_history, format_history
record_prompt("test", "m", "s")
t("hist:load", isinstance(load_history(limit=5), list))
t("hist:format", isinstance(format_history(load_history()), str))

print("=== AUTO_FIX ===")
from vaal.core.auto_fix import is_enabled, toggle, detect_bash_failure, build_fix_prompt
t("fix:enabled", isinstance(is_enabled(), bool))
old = is_enabled()
toggle()
t("fix:toggle", is_enabled() != old)
toggle()
t("fix:detect_ok", detect_bash_failure("read", "ok") is None)
t("fix:detect_err", detect_bash_failure("bash", "[exit code: 1] not found") is not None)
t("fix:detect_err2", detect_bash_failure("bash", "[error: timeout]") is not None)
t("fix:prompt", len(build_fix_prompt("ls", "not found", 1)) > 0)

print("=== BOOTSTRAP ===")
from vaal.core.bootstrap import scan_project
pi = scan_project(os.getcwd())
t("boot:scan", pi is not None)

print("=== USER_CONFIG ===")
from vaal.core.user_config import UserConfig
uc = UserConfig()
t("config:model", isinstance(uc.default_model, str))
t("config:dict", isinstance(uc.as_dict(), dict))

print("=== KEYBINDINGS ===")
from vaal.core.keybindings import KeybindingManager
kb = KeybindingManager()
t("keys:all", isinstance(kb.all_bindings(), dict))
t("keys:table", len(kb.format_table()) > 0)

print("=== VIM ===")
from vaal.core.vim_mode import VimMode
vm = VimMode()
t("vim:init", not vm.enabled)
vm.toggle()
t("vim:toggle", vm.enabled)
vm.toggle()

print("=== OUTPUT STYLES ===")
from vaal.core.output_styles import OutputStyleManager
osm = OutputStyleManager()
t("style:current", osm.current == "default")
t("style:avail", len(osm.available_styles()) > 0)

print("=== THEMES ===")
from vaal.core.terminal_theme import get_theme_names, get_theme, load_preference
t("theme:names", len(get_theme_names()) >= 5)
t("theme:get", get_theme("vaal") is not None)

print("=== PLANS ===")
from vaal.core.plans import create_plan, list_plans
plan = create_plan(title="Test", step_descriptions=["S1", "S2", "S3"])
t("plan:create", plan is not None)
t("plan:progress", "0/3" in plan.progress)
plan.advance()
t("plan:advance", "1/3" in plan.progress)

print("=== MEMORY STORE ===")
from vaal.core.memory import MemoryStore
ms = MemoryStore()
t("memstore:list", isinstance(ms.list_memories(), list))

print("=== BRANCHING ===")
from vaal.core.branching import BranchManager
bm = BranchManager()
bm.create_branch("test-b", [{"role": "user", "content": "hi"}])
t("branch:create", bm.has_branch("test-b"))
t("branch:list", len(bm.list_branches()) > 0)

print("=== MULTILINE ===")
from vaal.core.multiline import is_multiline_trigger
t("multi:triple", is_multiline_trigger('"""'))
t("multi:normal", not is_multiline_trigger("hello"))

print("=== SKILLS ===")
from vaal.core.skills import load_skills
t("skills:load", isinstance(load_skills(), list))

print("=== HOOKS ===")
from vaal.core.hooks import load_hooks, run_hooks
hooks = load_hooks()
t("hooks:load", isinstance(hooks, (dict, list)))
run_hooks("pre_tool", {"tool_name": "test"}, hooks)
t("hooks:run", True)

print("=== TASK_MANAGER ===")
reset_task_manager()
from vaal.core.task_manager import get_task_manager, TaskStatus
tm = get_task_manager()
task = tm.create(title="T")
t("tm:create", task.title == "T")
tm.update(task.id, status=TaskStatus.IN_PROGRESS)
t("tm:update", tm.get(task.id).status == TaskStatus.IN_PROGRESS)
tm.complete(task.id)
t("tm:complete", tm.get(task.id).status == TaskStatus.COMPLETED)
t("tm:summary", "1/1" in tm.summary)

print("=== AGENT POOL ===")
from vaal.core.agent import AgentPool, reset_agent_pool
reset_agent_pool()
pool = AgentPool()
t("pool:empty", pool.total_count == 0)

print("=== SCHEDULER ===")
from vaal.core.scheduler import get_scheduler
sched = get_scheduler()
t("sched:list", len(sched.list_tasks()) == 0)

print("=== COLLAB ===")
from vaal.core.collaborative import collab_start, collab_leave, collab_info
ok, code = collab_start()
t("collab:start", ok)
t("collab:info", collab_info() is not None)
collab_leave()
t("collab:leave", collab_info() is None)

print("=== PERMISSIONS ===")
from vaal.core.permissions import PermissionManager
pm = PermissionManager(mode="auto")
t("perm:safe", not pm.needs_approval("read"))
t("perm:danger", pm.needs_approval("bash"))
pm.approve("bash", remember=True)
t("perm:approve", not pm.needs_approval("bash"))
pm2 = PermissionManager(mode="yolo")
t("perm:yolo", not pm2.needs_approval("bash"))
pm3 = PermissionManager(mode="auto")
pm3.deny_tool("grep")
t("perm:deny", pm3.is_denied("grep"))
pm3.deny_prefix("git_")
t("perm:pfx", pm3.is_denied("git_commit"))

print("=== PLUGINS ===")
from vaal.core.plugins import load_plugins
t("plugins:load", isinstance(load_plugins(), list))

print("=== MCP ===")
from vaal.core.mcp_client import get_mcp_manager
mgr = get_mcp_manager()
t("mcp:list", isinstance(mgr.list_servers(), list))

print("=== UNDO ===")
from vaal.core.undo_system import get_undo_system
undo = get_undo_system()
undo.clear()  # Clear any state from earlier tests
t("undo:empty", not undo.undo()[0])
t("redo:empty", not undo.redo()[0])

print("=== ENV_MANAGER ===")
from vaal.core.env_manager import EnvManager
em = EnvManager()
t("env:list", len(em.list_env()) > 0)
t("env:cmd", len(em.handle_command("")) > 0)

print("=== SPLIT_PANE ===")
from vaal.core.split_pane import SplitPane
sp = SplitPane()
t("split:cmd", len(sp.handle_command("")) > 0)

print("=== NOTIFICATIONS ===")
from vaal.core.notifications import get_notification_manager
nm = get_notification_manager()
t("notify:cmd", len(nm.handle_command("")) > 0)

print("=== ERROR_EXPLAIN ===")
from vaal.core.error_explain import detect_error, build_explain_prompt
t("err:yes", detect_error("Traceback (most recent call last):"))
t("err:no", not detect_error("all good"))
t("err:prompt", len(build_explain_prompt("TypeError: bad")) > 0)

print("=== MIGRATION ===")
from vaal.core.migration import get_migration_profile
t("migrate:flask", get_migration_profile("flask", "fastapi") is not None)
t("migrate:none", get_migration_profile("x", "y") is None)

print("=== CODE_REVIEW ===")
from vaal.core.code_review import build_review_prompt, parse_review_response
t("review:prompt", len(build_review_prompt("diff")) > 0)
parsed = parse_review_response("[CRITICAL] f.py:10\nSQL injection\n-> parameterize")
t("review:parse", len(parsed) > 0 and parsed[0].severity.value == "critical")

print("=== DEPS ===")
from vaal.core.deps import scan_dep_files, format_dep_report
deps = scan_dep_files()
t("deps:scan", isinstance(deps, list))

print("=== COT_DISPLAY ===")
from vaal.core.cot_display import CotDisplay
t("cot:init", CotDisplay() is not None)

print("=== PROGRESS ===")
from vaal.core.progress import get_progress_tracker
t("progress:init", get_progress_tracker().active_count == 0)

print("=== CLIPBOARD ===")
from vaal.core.clipboard import copy_to_clipboard, paste_from_clipboard
copy_to_clipboard("vaal_test_123")
t("clip:copy", True)
t("clip:paste", "vaal_test_123" in (paste_from_clipboard() or ""))

print("=== IMAGE_INPUT ===")
from vaal.core.image_input import is_image_path, encode_image, build_image_message, build_ollama_image_message, get_clipboard_image
t("img:path_yes", is_image_path("photo.png"))
t("img:path_no", not is_image_path("readme.md"))
t("img:clipboard", True)  # just verify no crash
get_clipboard_image()

print("=== SSH_REMOTE ===")
from vaal.core.ssh_remote import get_ssh_manager
sm = get_ssh_manager()
t("sshm:info", sm.info() is None)  # not connected
t("sshm:connected", not sm.is_connected)

# ── CLEANUP & SUMMARY ──────────────────────────────────

try:
    shutil.rmtree(td, ignore_errors=True)
except Exception:
    pass

passed = sum(1 for v in R.values() if v)
failed = sum(1 for v in R.values() if not v)
print(f"\n{'=' * 50}")
print(f"  {passed}/{len(R)} PASSED, {failed} FAILED")
print(f"{'=' * 50}")
if failed:
    print("FAILURES:")
    for k, v in R.items():
        if not v:
            print(f"  FAIL: {k}")
    sys.exit(1)
