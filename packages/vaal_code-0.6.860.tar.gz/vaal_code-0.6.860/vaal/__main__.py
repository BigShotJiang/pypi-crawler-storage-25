"""Vaal CLI entry point — python -m vaal"""

import argparse
import sys
import os

# Force UTF-8 output on Windows
if sys.platform == "win32":
    os.system("")  # Enable VT100 escape sequences
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

from . import __version__


def _is_piped_input() -> bool:
    """Check if stdin is piped (not a TTY)."""
    try:
        return not sys.stdin.isatty()
    except Exception:
        return False


def _run_single_shot(prompt: str, model: str, json_output: bool, think: bool):
    """Run a single prompt, print response, exit. No REPL."""
    import json
    import time
    from .core.config import load_project_instructions
    from .core.llm import (
        chat_with_tools_stream, build_system_prompt, check_connection,
        get_ollama_tools,
    )
    from .core.tool_executor import execute_tool, format_tool_result
    from .core.permissions import PermissionManager
    from .core.history import record_prompt
    from .tools import bash_tool, file_tools, search_tools
    from .tools.registry import all_tools

    if not check_connection():
        print("Error: Cannot connect to Ollama at localhost:11434", file=sys.stderr)
        sys.exit(1)

    project_instructions = load_project_instructions()
    system_prompt = build_system_prompt(project_instructions=project_instructions)
    ollama_tools = get_ollama_tools(all_tools())
    permissions = PermissionManager(mode="yolo")  # Non-interactive = auto-approve

    session_id = "single"
    record_prompt(prompt, model, session_id)

    cwd = os.getcwd().replace("\\", "/")
    augmented = f"[CWD: {cwd}]\n{prompt}"

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": augmented},
    ]

    max_rounds = 15
    final_content = ""

    def auto_approve(name, params):
        return True

    for _ in range(max_rounds):
        content = ""
        tool_calls = []

        for chunk in chat_with_tools_stream(messages, ollama_tools, model=model, think=think):
            if chunk.get("content"):
                token = chunk["content"]
                # Skip think tags
                if "<think>" not in token and "</think>" not in token:
                    content += token
            if chunk.get("tool_calls"):
                tool_calls.extend(chunk["tool_calls"])

        content = content.strip()
        final_content = content

        if not tool_calls:
            break

        # Build assistant message with tool_use content blocks for Anthropic
        if "anthropic" in model.lower() or "claude" in model.lower():
            assistant_content = []
            if content:
                assistant_content.append({"type": "text", "text": content})
            for tc in tool_calls:
                func = tc.get("function", {})
                assistant_content.append({
                    "type": "tool_use",
                    "id": tc.get("id", f"tool_{func.get('name', 'unknown')}"),
                    "name": func.get("name", ""),
                    "input": func.get("arguments", {}),
                })
            messages.append({"role": "assistant", "content": assistant_content})
        else:
            messages.append({"role": "assistant", "content": content or "(tool calls)"})

        for tc in tool_calls:
            func = tc.get("function", {})
            tool_name = func.get("name", "")
            tool_args = func.get("arguments", {})
            tool_use_id = tc.get("id", f"tool_{tool_name}")

            result, executed = execute_tool(tool_name, tool_args, permissions, auto_approve)
            formatted = format_tool_result(tool_name, result)
            messages.append({"role": "tool", "tool_use_id": tool_use_id, "content": formatted})

    if json_output:
        output = {
            "model": model,
            "prompt": prompt,
            "response": final_content,
            "timestamp": time.time(),
        }
        print(json.dumps(output, indent=2))
    else:
        print(final_content)


def main():
    parser = argparse.ArgumentParser(
        prog="vaal",
        description="Vaal — Local LLM coding assistant",
    )
    parser.add_argument("--version", action="version", version=f"vaal {__version__}")
    parser.add_argument("-m", "--model", default=None, help="Model to use (default: qwen3:8b)")
    parser.add_argument("--mode", choices=["ask", "auto", "yolo"], default="auto",
                        help="Permission mode (default: auto)")
    parser.add_argument("--resume", "-r", default=None, help="Resume a session by ID")
    parser.add_argument("--think", action="store_true", help="Enable thinking/reasoning mode")
    parser.add_argument("--sessions", action="store_true", help="List saved sessions")
    parser.add_argument("--models", action="store_true", help="List available models")
    parser.add_argument("--json", action="store_true", dest="json_output",
                        help="Output response as structured JSON (single-shot mode)")
    parser.add_argument("--server", action="store_true", help="Start OpenAI-compatible API server")
    parser.add_argument("--port", type=int, default=8484, help="Server port (default: 8484)")
    parser.add_argument("--history", action="store_true", help="Show prompt history")
    parser.add_argument("prompt", nargs="*", help="Prompt (if provided, runs single-shot without REPL)")

    args = parser.parse_args()

    # ── --history: show prompt history and exit ──────────────────────
    if args.history:
        from .core.history import load_history, format_history
        entries = load_history(limit=20)
        print(format_history(entries))
        return

    # ── --sessions: list sessions and exit ───────────────────────────
    if args.sessions:
        from .core.session import Session
        from rich.console import Console
        console = Console()
        sessions = Session.list_sessions()
        if not sessions:
            console.print("[dim]No saved sessions.[/dim]")
        for s in sessions[:20]:
            console.print(f"  [cyan]{s['id']}[/cyan] | {s['model']} | {s['messages']} msgs")
        return

    # ── --models: list models and exit ───────────────────────────────
    if args.models:
        from .core.llm import list_models
        from rich.console import Console
        console = Console()
        models = list_models()
        if not models:
            console.print("[red]Cannot connect to Ollama.[/red]")
            return
        for m in models:
            console.print(f"  [cyan]{m}[/cyan]")
        return

    # ── --server: start API server ───────────────────────────────────
    if args.server:
        from .core.config import DEFAULT_MODEL
        from .core.server import run_server
        model = args.model or DEFAULT_MODEL
        run_server(port=args.port, model=model)
        return

    from .core.config import DEFAULT_MODEL
    model = args.model or DEFAULT_MODEL

    # ── Piped stdin: read prompt from pipe ───────────────────────────
    if _is_piped_input():
        piped_text = sys.stdin.read().strip()
        if args.prompt:
            # Combine: positional args as prefix, piped as context
            prompt = " ".join(args.prompt) + "\n\n" + piped_text
        else:
            prompt = piped_text
        if not prompt:
            print("Error: No input provided.", file=sys.stderr)
            sys.exit(1)
        _run_single_shot(prompt, model, args.json_output, args.think)
        return

    # ── Positional prompt args: single-shot mode ─────────────────────
    if args.prompt:
        prompt = " ".join(args.prompt)
        # Clear screen only for interactive, not single-shot
        _run_single_shot(prompt, model, args.json_output, args.think)
        return

    # ── Interactive REPL ─────────────────────────────────────────────
    if sys.platform == "win32":
        w = sys.stdout.write
        w("\033[2J\033[H")              # Clear screen, cursor to top
        w("\033]0;corrupted\007")       # Set window title
        sys.stdout.flush()

    # Apply saved terminal theme (or default Vaal Orb theme)
    from .core.terminal_theme import apply_theme, load_preference
    saved_theme = load_preference()
    apply_theme(saved_theme)

    # Auto-install Windows Terminal profile + icon on first run
    if sys.platform == "win32":
        from .core.terminal_profile import install_profile, get_icon_path
        from pathlib import Path
        icon = Path(get_icon_path())
        if not icon.exists():
            # Generate the Vaal Orb icon
            try:
                from .core.generate_icon import generate_vaal_icon
                generate_vaal_icon()
            except Exception:
                pass
        # Install/update profile silently
        try:
            install_profile()
        except Exception:
            pass

    from .core.repl import run_repl
    run_repl(
        model=model,
        permission_mode=args.mode,
        resume=args.resume,
        think=args.think,
    )


if __name__ == "__main__":
    main()
