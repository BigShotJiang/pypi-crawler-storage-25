"""Vaal — Local LLM coding assistant CLI."""
__version__ = "0.6.860"
