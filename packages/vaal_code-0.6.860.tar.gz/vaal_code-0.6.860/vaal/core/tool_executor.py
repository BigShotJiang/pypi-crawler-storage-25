"""Tool call executor."""

from ..tools.registry import get_tool
from .hooks import load_hooks, run_hooks
from .permissions import PermissionManager
from .auto_fix import detect_bash_failure


# Load hooks once at import time; can be refreshed by reassigning
_hooks = load_hooks()

# Tracks the last bash failure for auto-fix integration
_last_bash_failure: dict | None = None


def reload_hooks():
    """Reload hooks from disk."""
    global _hooks
    _hooks = load_hooks()


def get_last_bash_failure() -> dict | None:
    """Return the last bash failure info, or None."""
    return _last_bash_failure


def clear_last_bash_failure():
    """Clear the last bash failure after it's been handled."""
    global _last_bash_failure
    _last_bash_failure = None


def execute_tool(
    name: str,
    params: dict,
    permissions: PermissionManager,
    ask_fn=None,
) -> tuple[str, bool]:
    """Execute a tool call. Returns (result, was_executed)."""
    global _last_bash_failure

    tool = get_tool(name)
    if tool is None:
        return f"[error: unknown tool '{name}']", False

    # Check internet access first — blocked internet tools get a specific message
    if permissions.is_internet_blocked(name):
        return f"[tool '{name}' is blocked — internet access is disabled. Use /internet to re-enable.]", False

    # Check deny list — blocked tools are never executed
    if permissions.is_denied(name):
        return f"[tool '{name}' is blocked by deny rule. Use /deny clear to remove deny rules.]", False

    if permissions.needs_approval(name):
        if ask_fn:
            approved = ask_fn(name, params)
            if not approved:
                return "[tool call denied by user]", False
            permissions.approve(name, remember=True)
        else:
            return "[tool requires approval but no ask function provided]", False

    # Pre-tool hooks
    pre_context = {"tool_name": name, "tool_params": str(params)}
    run_hooks("pre_tool", pre_context, _hooks)

    try:
        result = tool.handler(**params)
        executed = True
    except Exception as e:
        result = f"[tool error: {e}]"
        executed = False

    # Post-tool hooks
    post_context = {
        "tool_name": name,
        "tool_params": str(params),
        "tool_result": result,
        "tool_success": str(executed),
    }
    run_hooks("post_tool", post_context, _hooks)

    # Track bash failures for auto-fix
    error_output = detect_bash_failure(name, result)
    if error_output is not None:
        _last_bash_failure = {
            "command": params.get("command", ""),
            "error_output": error_output,
        }
    else:
        _last_bash_failure = None

    return result, executed


def run_response_hooks(response_text: str):
    """Run on_response hooks after an assistant response."""
    context = {"response": response_text}
    run_hooks("on_response", context, _hooks)


def format_tool_result(name: str, result: str) -> str:
    if len(result) > 10000:
        result = result[:10000] + "\n\n[... output truncated]"
    return result
