"""LLM client — talks to Ollama with native tool calling."""

import json
from typing import Generator

import httpx

from .config import OLLAMA_HOST, DEFAULT_MODEL, MAX_OUTPUT_TOKENS


SYSTEM_PROMPT_TEMPLATE = """\
You are Vaal, an AI coding agent running on the user's machine with full filesystem and shell access via tools.

Working directory: {cwd}
Platform: {platform}

Rules:
- You HAVE real access. NEVER say "I cannot access the filesystem" — use your tools instead.
- ALWAYS use tools when asked about files, code, or the system.
- Use ABSOLUTE paths based on the working directory above. For example, to read config.py use "{cwd}/config.py".
- Read files before editing. Use glob to find files before reading.
- Use bash for git, tests, builds, running commands.
- Use grep to search code contents. Use glob to find files by pattern.
- Be concise. Act first, explain after.
- COMPLETE THE FULL TASK. If the user asks you to create a file AND test it, do BOTH — don't stop after just writing the file. Chain multiple tool calls to finish the job.
- After each tool result, ask yourself: "Is the task fully done?" If not, use another tool.
"""


def build_system_prompt(project_instructions: str | None = None, project_info: str | None = None) -> str:
    import os, platform as plat
    cwd = os.getcwd().replace("\\", "/")
    prompt = SYSTEM_PROMPT_TEMPLATE.format(cwd=cwd, platform=plat.system())
    if project_info:
        prompt += f"\n{project_info}\n"
    if project_instructions:
        prompt += f"\n# Project Instructions\n{project_instructions}\n"
    return prompt


def get_ollama_tools(tool_defs: dict) -> list[dict]:
    """Convert our tool definitions to Ollama's tool format."""
    tools = []
    for name, tdef in tool_defs.items():
        properties = {}
        required = []
        for pname, pinfo in tdef.parameters.items():
            properties[pname] = {
                "type": "string",
                "description": pinfo.get("description", ""),
            }
            if pinfo.get("required"):
                required.append(pname)

        tools.append({
            "type": "function",
            "function": {
                "name": name,
                "description": tdef.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        })
    return tools


def check_connection(model: str = "") -> bool:
    """Check if the provider for the given model is reachable."""
    if model:
        from .providers import parse_model_string, check_provider_connection
        provider, _ = parse_model_string(model)
        return check_provider_connection(provider)
    # Default: check Ollama
    try:
        r = httpx.get(f"{OLLAMA_HOST}/api/tags", timeout=3)
        return r.status_code == 200
    except Exception:
        return False


def list_models(provider: str = "ollama") -> list[str]:
    """List models for a provider."""
    from .providers import list_provider_models
    return list_provider_models(provider)


# Models known to not support native tool calling (heretic/abliterated, raw GGUFs, etc.)
# For these, we skip the tools param to avoid hanging.
# Models known to break with Ollama's native tool calling.
# These either return empty responses or hang when tools param is passed.
NO_TOOL_KEYWORDS = {
    "heretic", "abliterated", "uncensored",
    "deepseek",  # DeepSeek models choke on tools param
    "gemma",     # Some Gemma variants don't support tools
}

# Cache: models we've confirmed don't work with tools at runtime
_tool_broken_models: set = set()


def model_supports_tools(model: str) -> bool:
    """Check if a model supports native Ollama tool calling."""
    lower = model.lower()
    if lower in _tool_broken_models:
        return False
    return not any(tag in lower for tag in NO_TOOL_KEYWORDS)


def mark_tools_broken(model: str):
    """Mark a model as not supporting tools (detected at runtime)."""
    _tool_broken_models.add(model.lower())


def chat_with_tools_stream(
    messages: list[dict],
    tools: list[dict],
    model: str = DEFAULT_MODEL,
    think: bool = False,
) -> Generator[dict, None, None]:
    """Streaming chat with tool support. Routes to the correct provider.
    Yields chunks with content/tool_calls/done keys."""
    from .providers import parse_model_string, stream_provider

    provider, model_id = parse_model_string(model)

    # Cloud models get more output tokens for large file writes
    output_limit = MAX_OUTPUT_TOKENS
    if provider in ("anthropic", "openai", "openrouter"):
        output_limit = 16384

    yield from stream_provider(
        provider_name=provider,
        model=model_id,
        messages=messages,
        tools=tools,
        max_tokens=output_limit,
        think=think,
    )


def stream_chat(
    messages: list[dict],
    model: str = DEFAULT_MODEL,
    think: bool = False,
) -> Generator[dict, None, None]:
    """Stream chat completion (no tools). Yields chunks."""
    with httpx.stream(
        "POST",
        f"{OLLAMA_HOST}/api/chat",
        json={
            "model": model,
            "messages": messages,
            "stream": True,
            "think": think,
            "options": {
                "num_predict": MAX_OUTPUT_TOKENS,
                "temperature": 0.3,
            },
        },
        timeout=None,
    ) as r:
        for line in r.iter_lines():
            if not line:
                continue
            data = json.loads(line)
            msg = data.get("message", {})
            result = {}
            if msg.get("thinking"):
                result["thinking"] = msg["thinking"]
            if msg.get("content"):
                result["content"] = msg["content"]
            if data.get("done"):
                result["done"] = True
                result["eval_count"] = data.get("eval_count", 0)
                result["eval_duration"] = data.get("eval_duration", 0)
            if result:
                yield result
