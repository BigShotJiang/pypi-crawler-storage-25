"""Vaal configuration."""

from pathlib import Path
import json

VAAL_DIR = Path.home() / ".vaal"
SESSIONS_DIR = VAAL_DIR / "sessions"
PLUGINS_DIR = VAAL_DIR / "plugins"
SKILLS_DIR = VAAL_DIR / "skills"
MEMORY_DIR = VAAL_DIR / "memory"
PLANS_DIR = VAAL_DIR / "plans"
HISTORY_FILE = VAAL_DIR / "history.jsonl"

OLLAMA_HOST = "http://localhost:11434"
DEFAULT_MODEL = "qwen3:8b"

MAX_CONTEXT_TOKENS = 8192
MAX_OUTPUT_TOKENS = 4096

# Turn budget defaults
MAX_TURNS_PER_MESSAGE = 200  # max tool-call rounds per user message
MAX_SESSION_TOKENS = 100000  # max total tokens per session

# Tools that require user confirmation
DANGEROUS_TOOLS = {"bash", "write", "edit"}

# Tools that require internet access
INTERNET_TOOLS = {"web_fetch", "web_search", "api_request", "ssh_exec"}

# Permission modes
PERMISSION_MODES = {
    "ask": "Ask before every tool use",
    "auto": "Auto-approve safe tools, ask for dangerous ones",
    "yolo": "Auto-approve everything (dangerous)",
}
DEFAULT_PERMISSION_MODE = "auto"


def ensure_dirs():
    VAAL_DIR.mkdir(exist_ok=True)
    SESSIONS_DIR.mkdir(exist_ok=True)
    PLUGINS_DIR.mkdir(exist_ok=True)
    SKILLS_DIR.mkdir(exist_ok=True)
    MEMORY_DIR.mkdir(exist_ok=True)
    PLANS_DIR.mkdir(exist_ok=True)


def load_project_instructions() -> str | None:
    """Load VAAL.md from current directory or parents."""
    cwd = Path.cwd()
    for d in [cwd, *cwd.parents]:
        f = d / "VAAL.md"
        if f.exists():
            return f.read_text(encoding="utf-8", errors="replace")
    return None
