"""Vaal theme — Claude Code style, blue variant."""

from rich.theme import Theme

# Blue palette
VAAL_BLUE = "#5769f7"         # Primary blue
VAAL_BLUE_LIGHT = "#7b8bf9"   # Lighter blue
VAAL_BLUE_DIM = "#3a4bc4"     # Darker blue
VAAL_CYAN = "#5bc0be"         # Teal/cyan for stats and accents
VAAL_GREEN = "#2c7a39"        # Success
VAAL_RED = "#ab2b3f"          # Error
VAAL_YELLOW = "#966c1e"       # Warning
VAAL_DIM = "#888888"          # Dim/subtle text
VAAL_DIMMER = "#555555"       # Even dimmer

# Theme for rich console
VAAL_THEME = Theme({
    "vaal.prompt": f"bold {VAAL_BLUE}",
    "vaal.user_label": "bold white",
    "vaal.assistant_label": f"bold {VAAL_BLUE}",
    "vaal.tool_prefix": f"{VAAL_DIM}",
    "vaal.tool_name": f"bold {VAAL_BLUE}",
    "vaal.tool_output": f"{VAAL_DIM}",
    "vaal.success": f"{VAAL_GREEN}",
    "vaal.error": f"{VAAL_RED}",
    "vaal.warning": f"{VAAL_YELLOW}",
    "vaal.dim": f"{VAAL_DIM}",
    "vaal.dimmer": f"{VAAL_DIMMER}",
    "vaal.status": f"{VAAL_DIM}",
    "vaal.stats": f"{VAAL_CYAN}",
    "vaal.spinner": f"{VAAL_BLUE}",
    "vaal.permission": f"bold {VAAL_BLUE}",
    "vaal.key": f"bold {VAAL_DIM}",
    # Markdown overrides
    "markdown.h1": f"bold {VAAL_BLUE}",
    "markdown.h2": f"bold {VAAL_BLUE}",
    "markdown.h3": f"bold {VAAL_BLUE}",
    "markdown.link": f"{VAAL_CYAN} underline",
    "markdown.item.number": f"bold {VAAL_CYAN}",
    "markdown.item.bullet": f"{VAAL_CYAN}",
    "markdown.code": f"bold #e0e0e0 on #1a1a2e",
})

# Tool output prefix (Claude's ⎿ character)
TOOL_PREFIX = "  ⎿  "

# Spinner frames
SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
