"""Command palette — fuzzy-matched slash command menu with arrow key navigation."""

import sys

ESC = "\033"
HIDE_CURSOR = f"{ESC}[?25l"
SHOW_CURSOR = f"{ESC}[?25h"
CLEAR_SCREEN = f"{ESC}[2J{ESC}[H"
CLEAR_LINE = f"{ESC}[2K"
RESET = f"{ESC}[0m"
BOLD = f"{ESC}[1m"
ALT_SCREEN_ON = f"{ESC}[?1049h"
ALT_SCREEN_OFF = f"{ESC}[?1049l"
C_BLUE = f"{ESC}[38;5;63m"
C_CYAN = f"{ESC}[38;5;80m"
C_DIM = f"{ESC}[38;5;242m"
C_WHITE = f"{ESC}[37m"
C_BOLD_WHITE = f"{ESC}[1;37m"
C_BG_SELECT = f"{ESC}[48;5;236m"

COMMANDS = [
    ("/help", "Show all commands"),
    ("/quit", "Exit and save session"),
    ("/clear", "Clear conversation history"),
    ("/model", "Switch model"),
    ("/models", "Browse and download models"),
    ("/login", "Login with API key / OAuth"),
    ("/logout", "Disconnect provider"),
    ("/provider", "List/configure API providers"),
    ("/pull", "Download a model"),
    ("/remove", "Remove a model"),
    ("/history", "Show recent prompts"),
    ("/changelog", "Prompt history with file changes"),
    ("/yolo", "Auto-approve all tools"),
    ("/internet", "Toggle internet access (web/api/ssh)"),
    ("/session", "Show session info"),
    ("/sessions", "List saved sessions"),
    ("/compact", "Compress history"),
    ("/cost", "Token usage breakdown"),
    ("/keys", "Keyboard shortcuts"),
    ("/vim", "Toggle vim mode"),
    ("/style", "Switch output style"),
    ("/theme", "Terminal color theme picker"),
    ("/font", "Terminal font picker"),
    ("/icon", "Set terminal icon (instructions)"),
    ("/copy", "Copy last response to clipboard"),
    ("/paste", "Paste clipboard content as input"),
    ("/memory", "List/search persistent memories"),
    ("/plan", "Create an implementation plan"),
    ("/plans", "List all plans"),
    ("/resume", "Interactive session picker"),
    ("/autofix", "Toggle auto-fix on bash errors"),
    ("/watch", "Watch files and re-run command on change"),
    ("/branch", "Fork conversation into a new branch"),
    ("/branches", "List all conversation branches"),
    ("/switch", "Switch to a different branch"),
    ("/merge", "Merge a branch into current conversation"),
    ("/image", "Send an image for analysis"),
    ("/paste-image", "Paste image from clipboard"),
    ("/voice", "Toggle voice input mode"),
    ("/mcp", "Connect/list/disconnect MCP servers"),
    ("/schedule", "Run a prompt on a recurring interval"),
    ("/split", "File preview pane above prompt"),
    ("/notify", "Toggle desktop notifications"),
    ("/undo", "Undo last file change"),
    ("/redo", "Redo last undone change"),
    ("/db", "Database tools (connect/query/schema)"),
    ("/api", "HTTP API testing (GET/POST/PUT/DELETE)"),
    ("/env", "Environment variable management"),
    ("/collab", "Collaborative sessions (start/join/leave)"),
    ("/review", "Code review on uncommitted changes"),
    ("/review-pr", "Review a GitHub pull request"),
    ("/deps", "Scan and audit project dependencies"),
    ("/ssh", "SSH remote execution (connect/run/disconnect)"),
    ("/explain", "Explain an error or stack trace"),
    ("/migrate", "Guided framework/language migration"),
    ("/register", "Create a vaal account"),
    ("/remote", "Remote control from web browser"),
    ("/task", "Manage tasks (create/update/complete)"),
    ("/tasks", "Show all tasks with status"),
    ("/agents", "Show all sub-agents"),
    ("/init", "Generate VAAL.md for current project"),
    ("/plugin", "Manage plugins (list/create/remove/reload)"),
    ("/plugins", "Manage plugins (list/create/remove/reload)"),
    ("/agentmodel", "Set model for subagents"),
    ("/preview", "Live preview with interactive inspector"),
    ("/doctor", "System health diagnostics"),
    ("/deny", "Block a tool by name or prefix"),
    ("/directory", "Change working directory"),
    ("/cd", "Change working directory (alias)"),
    ("/effort", "Set inference effort level"),
    ("/add-dir", "Add directory to context"),
    ("/summary", "Generate session summary"),
    ("/stats", "Detailed usage statistics"),
    ("/rewind", "Branch from a past message"),
    ("/debug-tool", "Toggle verbose tool output"),
    ("/pin", "Pin a file to always include in context"),
    ("/unpin", "Remove a pinned file from context"),
    ("/cost", "Show running cost estimate"),
    ("/commit", "Auto-generate commit message and commit"),
    ("/test", "Detect framework and run tests"),
    ("/pr", "Create a pull request"),
    ("/diff", "Show uncommitted changes"),
]


def _write(s):
    sys.stdout.write(s)
    sys.stdout.flush()


def _read_key():
    if sys.platform == "win32":
        import msvcrt
        key = msvcrt.getwch()
        if key in ("\x00", "\xe0"):
            key2 = msvcrt.getwch()
            if key2 == "H": return "up"
            elif key2 == "P": return "down"
            return "special"
        elif key == "\r": return "enter"
        elif key == "\x1b": return "escape"
        elif key == "\x08": return "backspace"
        elif key == "\x03": return "escape"
        elif key == "\t": return "tab"
        return key
    else:
        import tty, termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                ch2 = sys.stdin.read(1)
                if ch2 == "[":
                    ch3 = sys.stdin.read(1)
                    if ch3 == "A": return "up"
                    elif ch3 == "B": return "down"
                return "escape"
            elif ch == "\r": return "enter"
            elif ch == "\x7f" or ch == "\x08": return "backspace"
            elif ch == "\x03": return "escape"
            elif ch == "\t": return "tab"
            return ch
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _fuzzy_match(query, text):
    qi = 0
    ql, tl = query.lower(), text.lower()
    for ch in tl:
        if qi < len(ql) and ch == ql[qi]:
            qi += 1
    return qi == len(ql)


def _highlight(text, query):
    if not query:
        return f"{C_WHITE}{text}{RESET}"
    result = ""
    qi = 0
    ql, tl = query.lower(), text.lower()
    for i, ch in enumerate(text):
        if qi < len(ql) and tl[i] == ql[qi]:
            result += f"{C_CYAN}{BOLD}{ch}{RESET}"
            qi += 1
        else:
            result += f"{C_WHITE}{ch}{RESET}"
    return result


def command_palette(initial_text: str = "") -> str | None:
    """Interactive command palette using alternate screen buffer."""
    query = initial_text
    selected = 0

    # Switch to alternate screen — clean slate, original screen preserved
    _write(ALT_SCREEN_ON)
    _write(HIDE_CURSOR)

    try:
        while True:
            # Filter and sort: exact prefix first, then fuzzy
            if query:
                q = query.lower()
                matches = [(c, d) for c, d in COMMANDS if _fuzzy_match(query, c + " " + d)]
                # Sort: exact command match first, then startswith, then rest
                def _sort_key(item):
                    cmd = item[0].lower()
                    if cmd == "/" + q:
                        return (0, cmd)
                    if cmd.startswith("/" + q):
                        return (1, cmd)
                    return (2, cmd)
                filtered = sorted(matches, key=_sort_key)
            else:
                filtered = list(COMMANDS)
            if selected >= len(filtered):
                selected = max(0, len(filtered) - 1)

            # Full redraw from top
            _write(CLEAR_SCREEN)

            # Title
            _write(f"\n  {C_BLUE}{BOLD}Command Palette{RESET}\n\n")

            # Search box
            _write(f"  {C_BLUE}{BOLD}/{RESET}{C_WHITE}{query}{RESET}{C_DIM}{'_' if not query else ''}{RESET}\n\n")

            # List
            max_show = min(len(filtered), 15)
            scroll_start = max(0, selected - max_show + 1)
            visible = filtered[scroll_start:scroll_start + max_show]

            for i, (cmd, desc) in enumerate(visible):
                idx = scroll_start + i
                name_hl = _highlight(cmd, query)
                if idx == selected:
                    _write(f"  {C_BG_SELECT}{C_CYAN}❯{RESET} {C_BG_SELECT}{name_hl} {C_BG_SELECT}{C_DIM}{desc}{RESET}\n")
                else:
                    _write(f"    {name_hl} {C_DIM}{desc}{RESET}\n")

            if not filtered:
                _write(f"    {C_DIM}no matching commands{RESET}\n")

            # Footer
            _write(f"\n  {C_DIM}↑↓ navigate  {RESET}{C_CYAN}enter{RESET} {C_DIM}select  {RESET}{C_CYAN}esc{RESET} {C_DIM}cancel  {len(filtered)}/{len(COMMANDS)}{RESET}")

            # Input
            key = _read_key()

            if key == "up":
                selected = max(0, selected - 1)
            elif key == "down":
                selected = min(len(filtered) - 1, selected + 1)
            elif key == "enter":
                _write(ALT_SCREEN_OFF)
                _write(SHOW_CURSOR)
                return filtered[selected][0] if filtered else None
            elif key == "escape":
                _write(ALT_SCREEN_OFF)
                _write(SHOW_CURSOR)
                return None
            elif key == "backspace":
                if query:
                    query = query[:-1]
                    selected = 0
                else:
                    _write(ALT_SCREEN_OFF)
                    _write(SHOW_CURSOR)
                    return None
            elif key == "tab":
                if filtered:
                    query = filtered[selected][0][1:]
                    selected = 0
            elif len(key) == 1 and key.isprintable():
                query += key
                selected = 0

    except Exception:
        _write(ALT_SCREEN_OFF)
        _write(SHOW_CURSOR)
        return None
    finally:
        _write(ALT_SCREEN_OFF)
        _write(SHOW_CURSOR)
