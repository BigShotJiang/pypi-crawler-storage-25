import asyncio
from aiogram import Bot

async def main():
    bot = Bot(token="8265458665:AAEc9QmqH17IOY3RHUl3BE14GhHn_YsWDTQ")
    updates = await bot.get_updates(limit=10)
    for u in updates:
        print(u)
    await bot.session.close()

asyncio.run(main())
