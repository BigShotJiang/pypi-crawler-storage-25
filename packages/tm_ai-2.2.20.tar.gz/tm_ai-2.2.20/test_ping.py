import asyncio
from aiogram import Bot

async def main():
    bot = Bot(token="8265458665:AAEc9QmqH17IOY3RHUl3BE14GhHn_YsWDTQ")
    await bot.send_message(1867562203, "/status")
    await bot.session.close()

asyncio.run(main())
