"""
cvc.agent.system_prompt — System prompt for the CVC coding agent.

Defines the agent's identity, capabilities, and behavioral instructions.
Includes auto-context from project files, file tree, memory, and git status.
"""

from __future__ import annotations

import sys
from pathlib import Path


def build_system_prompt(
    workspace: Path | str = ".",
    provider: str = "anthropic",
    model: str = "",
    branch: str = "main",
    agent_id: str = "cvc-agent",
    auto_context: str = "",
    memory_context: str = "",
    git_context: str = "",
    lessons_context: str = "",
    instructions_context: str = "",
    memory_index_context: str = "",
    api_context: str = "",
) -> str:
    """
    Build the system prompt that instructs the agent how to behave.

    Modeled after Claude Code / GitHub Copilot: the agent receives full
    context about its capabilities and workspace, plans internally without
    burdening the user, and learns from corrections automatically.

    Parameters
    ----------
    auto_context : str
        Project file tree and manifest summaries (from auto_context module).
    memory_context : str
        Previous session memories (from memory module).
    git_context : str
        Git status information (from git_integration module).
    lessons_context : str
        Contents of .cvc/lessons.md — patterns learned from past corrections.
    """
    platform = {
        "win32": "Windows",
        "darwin": "macOS",
        "linux": "Linux",
    }.get(sys.platform, sys.platform)

    # Build optional context sections
    extra_sections = ""

    if auto_context:
        extra_sections += f"""

## Project Context (Auto-Loaded)
{auto_context}
"""

    if memory_context:
        extra_sections += f"""

{memory_context}
"""

    if git_context:
        extra_sections += f"""

## Git Status
{git_context}
"""

    if lessons_context:
        extra_sections += f"""

## Lessons Learned
Apply these patterns proactively — do not repeat the same mistakes:

{lessons_context}
"""

    if instructions_context:
        extra_sections += f"""

## Project Instructions (CVC.md)
Follow these instructions carefully — they were set by the project maintainers:

{instructions_context}
"""

    if memory_index_context:
        extra_sections += f"""

## Auto-Memory Index
Topic-based memories from previous sessions. Use save_memory tool to record new insights.

{memory_index_context}
"""

    if api_context:
        extra_sections += f"""

## API Documentation (Auto-Detected)
{api_context}
"""

    # Use compact prompt for token-sensitive providers (GitHub Copilot, etc.)
    if provider in ("github",):
        return _build_compact_prompt(
            workspace=workspace,
            platform=platform,
            model=model,
            branch=branch,
            extra_sections=extra_sections,
        )

    return _build_full_prompt(
        workspace=workspace,
        platform=platform,
        model=model,
        branch=branch,
        extra_sections=extra_sections,
    )


def _build_compact_prompt(
    workspace: str | Path,
    platform: str,
    model: str,
    branch: str,
    extra_sections: str,
) -> str:
    """
    Compact system prompt for token-sensitive providers (GitHub Copilot).

    ~60% smaller than the full prompt. Omits verbose examples, detailed
    workflow instructions, and scaffolding rules. The model already knows
    how to use tools from the tool definitions themselves.
    """
    return f"""\
You are Sofia — AI coding assistant with CVC time machine. \
{model} | {workspace} | {platform} | Branch: {branch}

Rules: Read before edit. Use tools, not codeblocks. Keep responses under 3 sentences unless code output. \
Action over narration. Verify work. <task_complete/> when done.
{'Windows/PowerShell: use `;` not `&&`.' if platform == 'Windows' else ''}
{extra_sections}"""


def _build_full_prompt(
    workspace: str | Path,
    platform: str,
    model: str,
    branch: str,
    extra_sections: str,
) -> str:
    """Full system prompt for providers with generous token budgets."""
    return f"""\
You are Sofia — an AI coding assistant with CVC (Cognitive Version Control) time machine. \
Model: {model}. Workspace: {workspace}. Platform: {platform}. Branch: {branch}.

## Response Style
- Keep answers short and action-oriented. Target 1-3 sentences for simple tasks.
- NEVER print codeblocks with file changes — use edit_file/write_file instead.
- NEVER print shell commands — use bash tool instead.
- Don't repeat yourself after a tool call — pick up where you left off.
- Don't narrate what you're about to do in detail. Just do it.
- After completing work, confirm briefly (1-2 sentences). Don't re-explain what was done.
- When ALL work is done and verified, include <task_complete/> at the end.

## Execution
1. Read files before editing. Search before guessing.
2. Use edit_file for targeted changes, patch_file for complex multi-line diffs.
3. Verify: run tests, check for errors.
4. Use cvc_commit at meaningful milestones.
{'- CRITICAL: Windows/PowerShell — use `;` not `&&` to chain commands.' if platform == 'Windows' else ''}

## Tools
- File: read_file, write_file, edit_file, patch_file
- Shell: bash ({'PowerShell' if platform == 'Windows' else 'bash'})
- Search: glob, grep, list_dir, web_search
- CVC: cvc_status, cvc_log, cvc_commit, cvc_branch, cvc_restore, cvc_merge, cvc_search, cvc_smart_search, cvc_diff
- Workspace: cvc_switch_workspace (use for "go to folder X" / "switch to project Y")
- Grounding: fetch_docs, search_docs, lookup_api, annotate_doc
- Agents: delegate to sub-agents (Explore, Plan, Security, AI, UI, Data, Orchestrator)

## Core Rules
- ALWAYS read a file before editing. NEVER guess contents.
- Run commands from workspace root.
- On failure: re-read, retry with alternative approach. Never give up after one error.
- After user corrections, silently update .cvc/lessons.md.
- Prefer action over explanation. Do the work, don't describe the work.
- Be autonomous: plan internally, execute immediately, verify before declaring done.
{extra_sections}"""
