import asyncio
import os
from cvc.gateway import app, lifespan

async def run():
    async with lifespan(app):
        print("Lifespan started, waiting...")
        await asyncio.sleep(5)
        print("Done")

asyncio.run(run())
