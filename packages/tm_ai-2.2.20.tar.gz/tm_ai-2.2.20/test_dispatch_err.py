import asyncio
import logging
from aiogram import Bot, Dispatcher, types
from cvc.agent.settings import load_settings
from cvc.adapters.telegram_handler import register_handlers

logging.basicConfig(level=logging.DEBUG)

async def main():
    settings = load_settings()
    bot = Bot(token="8265458665:AAEc9QmqH17IOY3RHUl3BE14GhHn_YsWDTQ")
    dp = Dispatcher()
    
    class DummyMock: pass
    gw_mock = DummyMock()
    gw_mock._agent_llm = DummyMock()
    gw_mock._agent_llm.model = "test"
    gw_mock._agent_llm.provider = "test"
    gw_mock._agent_tools = True
    gw_mock._system_prompt = "system"
    gw_mock._tg_sessions = {}
    
    import sys
    sys.modules["cvc.gateway"] = gw_mock
    
    register_handlers(dp, bot, settings, DummyMock())
    
    msg = types.Message(
        message_id=1,
        date=1,
        chat=types.Chat(id=1867562203, type="private"),
        from_user=types.User(id=1867562203, is_bot=False, first_name="Me"),
        text="/status"
    )
    await dp.feed_update(bot, types.Update(update_id=1, message=msg))
    await bot.session.close()

asyncio.run(main())
