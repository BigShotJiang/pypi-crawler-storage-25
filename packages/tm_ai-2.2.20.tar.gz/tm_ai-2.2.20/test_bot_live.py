import asyncio
from cvc.agent.settings import load_settings
from cvc.adapters.telegram_gateway import start_telegram_gateway
from cvc.workspace_manager import WorkspaceManager
from pathlib import Path

async def main():
    settings = load_settings()
    wm = WorkspaceManager()
    wm.switch_to(Path.cwd())
    print("Starting bot...")
    await start_telegram_gateway(settings, wm)
    print("Bot started, waiting 15 seconds for you to send a message...")
    await asyncio.sleep(15)
    print("Done waiting.")
    from cvc.adapters.telegram_gateway import stop_telegram_gateway
    await stop_telegram_gateway()

asyncio.run(main())
