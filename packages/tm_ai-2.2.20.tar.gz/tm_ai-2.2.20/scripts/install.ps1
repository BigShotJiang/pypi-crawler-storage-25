# =============================================================================
# CVC (Cognitive Version Control) — Exact Windows Installer Style
# Usage:  irm https://jaimeena.com/cvc/install.ps1 | iex
# =============================================================================

$ErrorActionPreference = "SilentlyContinue"

# Fetch the latest version from PyPI to display
try {
    $version = (Invoke-RestMethod https://pypi.org/pypi/tm-ai/json -UseBasicParsing).info.version
} catch {
    $version = "latest"
}

# Output: * Installing CVC vX.X.X...
Write-Host "* Installing " -ForegroundColor Red -NoNewline
Write-Host "CVC v$version" -ForegroundColor Red -NoNewline
Write-Host "..." -ForegroundColor DarkRed

# 1. Install uv if missing (silently)
if (-Not (Get-Command uv -ErrorAction SilentlyContinue)) {
    try {
        Set-ExecutionPolicy Bypass -Scope Process -Force
        $uvScript = Invoke-RestMethod -Uri "https://astral.sh/uv/install.ps1"
        Invoke-Expression $uvScript | Out-Null
        $env:PATH = [System.Environment]::GetEnvironmentVariable("Path", "User") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    } catch { }
}

# 2. Install or Upgrade CVC (silently)
$toolExists = uv tool list 2>&1 | Select-String "tm-ai"
if ($toolExists) {
    uv tool upgrade tm-ai --refresh 2>&1 | Out-Null
} else {
    uv tool install tm-ai[all] 2>&1 | Out-Null
}

# Output: * CVC installed successfully.
Write-Host "* CVC installed successfully." -ForegroundColor Red

# Output: Run cvc to start.
Write-Host ""
Write-Host "Run " -ForegroundColor Gray -NoNewline
Write-Host "cvc" -ForegroundColor Red -NoNewline
Write-Host " to start." -ForegroundColor Gray
Write-Host ""