# agentshield-client

Alias for [`agentshield-guard`](https://pypi.org/project/agentshield-guard/) — the official AgentShield Python SDK.

```bash
pip install agentshield-client
# Equivalent to:
pip install agentshield-guard
```

Import path is unchanged:

```python
from agentshield import AgentShield
```

See: https://agentshield.pro
