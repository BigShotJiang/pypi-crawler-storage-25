import datetime
import re
from abc import ABC, abstractmethod
from decimal import Decimal
from enum import Enum
from typing import List
from zoneinfo import ZoneInfo

from sirius import common, wise
from sirius.common import DataClass, Currency
from sirius.constants import SiriusEnvironmentSecretKey
from sirius.http_requests import AsyncHTTPSession, HTTPResponse


class AccountName(Enum):
    pass


class CashAccountName(AccountName):
    WISE = "Wise"
    IBKR = "Interactive Brokers"


class Transaction(DataClass):
    description: str
    date: datetime.date
    amount: Decimal

    @staticmethod
    async def get_all() -> List["Transaction"]:
        wise_transactions_list: List[Transaction] = await WiseAccount.get_all_transactions()
        ibkr_transactions_list: List[Transaction] = await IBKRAccount.get_all_transactions()

        return wise_transactions_list + ibkr_transactions_list


class Account(DataClass, ABC):
    name: AccountName
    currency: Currency
    transaction_list: List[Transaction] = []

    @property
    def balance(self) -> Decimal:
        balance: Decimal = sum([transaction.amount for transaction in self.transaction_list])  # type: ignore[assignment]
        return balance if isinstance(self.name, CashAccountName) else -balance

    @staticmethod
    @abstractmethod
    async def get_all_transactions() -> List[Transaction]:
        ...

    @staticmethod
    @abstractmethod
    async def get_cash_account() -> "Account":
        ...


class WiseAccount(Account):

    @staticmethod
    async def get_all_transactions() -> List[Transaction]:
        wise_account: wise.WiseAccount = await wise.WiseAccount.get()
        account_list: List[wise.Account] = await wise_account.business_profile.account_list
        account: wise.Account = next(filter(lambda a: a.type == wise.AccountType.STANDARD, account_list))
        from_datetime = datetime.datetime.combine(datetime.date(2026, 4, 1), datetime.time.min, tzinfo=ZoneInfo("Pacific/Auckland"))
        to_datetime = datetime.datetime.combine(datetime.date.today(), datetime.time.min, tzinfo=ZoneInfo("Pacific/Auckland"))

        transaction_list: List[Transaction] = [
            Transaction(
                description=transaction.description,
                date=transaction.timestamp.date(),
                amount=transaction.amount,
            ) for transaction in await account.get_transactions(from_datetime, to_datetime)]

        transaction_list.sort(key=lambda x: x.date)
        return transaction_list

    @staticmethod
    async def get_cash_account() -> "Account":
        return WiseAccount(
            name=CashAccountName.WISE,
            currency=Currency.USD,
            transaction_list=await WiseAccount.get_all_transactions()
        )


class IBKRAccount(Account):

    @staticmethod
    async def get_all_transactions() -> List[Transaction]:
        transaction_list: List[Transaction] = []
        session: AsyncHTTPSession = AsyncHTTPSession("https://ndcdyn.interactivebrokers.com")
        flex_query_token: str = await common.get_environmental_secret(SiriusEnvironmentSecretKey.IBKR_FLEX_QUERY_TOKEN)
        flex_query_id: str = await common.get_environmental_secret(SiriusEnvironmentSecretKey.IBKR_FLEX_QUERY_ID)
        reference_code_response: HTTPResponse = await session.get(f"https://ndcdyn.interactivebrokers.com/AccountManagement/FlexWebService/SendRequest?t={flex_query_token}&q={flex_query_id}&v=3")
        reference_code: str = re.search(r"<ReferenceCode>(.*?)</ReferenceCode>", reference_code_response.response_text).group(1)  # type: ignore[call-overload]

        transaction_response: HTTPResponse = await session.get(f"https://ndcdyn.interactivebrokers.com/AccountManagement/FlexWebService/GetStatement?t={flex_query_token}&q={reference_code}&v=3")
        for transaction_response_data in transaction_response.data.split("\n")[1:-1]:  # type: ignore[attr-defined]
            transaction_response_str_list: List[str] = [s.replace("\"", "").replace("'", "") for s in transaction_response_data.split(",")]
            description: str = transaction_response_str_list[31]
            date: datetime.date = datetime.datetime.strptime(transaction_response_str_list[28], "%Y-%m-%d").date()
            total_amount: Decimal = Decimal(transaction_response_str_list[43])
            activity_code: str = transaction_response_str_list[30]
            id: str = transaction_response_str_list[47]

            if activity_code == "":
                continue

            if activity_code == "BUY":
                cost_of_trade: Decimal = Decimal(transaction_response_str_list[38])
                commission: Decimal = total_amount - cost_of_trade

                transaction_list.append(Transaction(
                    description=description,
                    amount=cost_of_trade,
                    date=date
                ))
                transaction_list.append(Transaction(
                    description=f"IBKR Commission: {description}",
                    amount=commission,
                    date=date
                ))

            else:
                transaction_list.append(Transaction(
                    description=description,
                    amount=total_amount,
                    date=date
                ))

        transaction_list.sort(key=lambda x: x.date)
        return transaction_list

    @staticmethod
    async def get_cash_account() -> "Account":
        return IBKRAccount(
            name=CashAccountName.IBKR,
            currency=Currency.USD,
            transaction_list=await IBKRAccount.get_all_transactions()
        )
