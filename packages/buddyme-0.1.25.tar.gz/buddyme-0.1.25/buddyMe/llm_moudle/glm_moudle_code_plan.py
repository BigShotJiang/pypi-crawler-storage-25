"""
GLM Anthropic 模块 - 智谱 GLM Anthropic 兼容客户端

使用示例:
    from llm_moudle.glm_moudle_code_plan import GLMAnthropicClient

    client = GLMAnthropicClient()
    response = await client.chat([{"role": "user", "content": "你好"}])
    print(response["content"][0]["text"])
"""
import asyncio
import logging

from buddyMe.llm_moudle import model_config
from buddyMe.llm_moudle.anthropic_code_plan_base import AnthropicCodePlanClient

logger = logging.getLogger(__name__)


class GLMAnthropicClient(AnthropicCodePlanClient):
    """智谱 GLM Anthropic 兼容客户端"""

    def __init__(self, model_name: str = "glm", max_tokens: int = 131072):
        super().__init__(
            model_name=model_name,
            api_key=model_config.ModelConfig.get_api_key("glm"),
            base_url="https://open.bigmodel.cn/api/anthropic",
            model=model_config.ModelConfig.get_api_model(model_name),
            max_tokens=max_tokens,
            timeout_read=1800.0,
            timeout_write=360.0,
        )


if __name__ == '__main__':
    print("=" * 60)
    print("GLM Anthropic 接口测试")
    print("=" * 60)

    async def run_test():
        try:
            client = GLMAnthropicClient()

            print("\n--- 测试: 基本对话 ---")
            messages = [
                {"role": "system", "content": "你是一个有帮助的助手。"},
                {"role": "user", "content": "你好，请用一句话介绍自己"}
            ]
            response = await client.chat(messages=messages)
            texts = [b["text"] for b in response["content"] if b["type"] == "text"]
            print("助手:", "\n".join(texts))

            client.close()
        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"\n错误: {e}")

    asyncio.run(run_test())
