"""
================================================================================
GLM 模块 - 智谱 GLM 模型客户端
================================================================================

智谱 AI 开放平台: https://open.bigmodel.cn/

支持的模型:
    - glm-5-turbo (默认)
    - glm-5
    - glm-4

使用示例:
    from llm_moudle import create_client

    client = create_client("glm")
    response = await client.chat([{"role": "user", "content": "你好"}])
    print(response["content"][0]["text"])

================================================================================
"""
import logging
from typing import Any, Dict, List, Optional

from buddyMe.anthropic_standard.basic_anthropic_client import OpenAICompatibleClient

logger = logging.getLogger(__name__)


class GLMClient(OpenAICompatibleClient):
    """
    智谱 GLM 模型客户端

    继承 OpenAICompatibleClient，复用 HTTP 请求和响应解析逻辑。
    仅覆盖模型特定的配置差异。

    配置 (config.yaml):
        models:
          glm:
            api_key: "your-api-key"
            url: "https://open.bigmodel.cn/api/paas/v4/chat/completions"
            model: "glm-5-turbo"

    响应格式 (遵循 anthropic_standard.py 规范):
        {
            "content": [
                {"type": "text", "text": "..."},
                {"type": "tool_use", "id": "...", "name": "...", "input": {...}}
            ],
            "stop_reason": "stop" | "tool_use",
            "usage": {...}
        }
    """

    def __init__(
        self,
        model_name: str = "glm",
        max_tokens: int = 131072
    ):
        super().__init__(
            model_name=model_name,
            max_tokens=max_tokens,
        )



# ==============================================================================
# 模块测试
# ==============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("GLM 模型测试")
    print("输入 'quit' 退出")
    print("=" * 60)

    import asyncio

    async def run_test():
        try:
            client = GLMClient()
            messages = [
                {"role": "system", "content": "你是一个有帮助的助手。"},
                {"role": "user", "content": "你好，请介绍一下自己"}
            ]

            response = await client.chat(messages=messages)
            texts = [b["text"] for b in response["content"] if b["type"] == "text"]
            print("\n助手:", "\n".join(texts) or "[无回复]")

            client.close()

        except Exception as e:
            print(f"\n错误: {e}")

    asyncio.run(run_test())
