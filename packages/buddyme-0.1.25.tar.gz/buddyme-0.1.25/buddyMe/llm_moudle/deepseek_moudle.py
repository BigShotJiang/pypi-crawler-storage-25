"""
================================================================================
DeepSeek 模块 - DeepSeek 模型客户端
================================================================================

DeepSeek 开放平台: https://platform.deepseek.com/

支持的模型:
    - deepseek
    - deepseek-v4-flash

使用示例:
    from llm_moudle.deepseek_moudle import DeepSeekClient

    client = DeepSeekClient()
    response = await client.chat([{"role": "user", "content": "你好"}])
    print(response["content"][0]["text"])

================================================================================
"""
import json
import logging
import random
import asyncio
from typing import Any, Dict, List, Optional

import httpx

from buddyMe.anthropic_standard.basic_anthropic_client import OpenAICompatibleClient, convert_to_sdk_format

logger = logging.getLogger(__name__)


class DeepSeekClient(OpenAICompatibleClient):
    """
    DeepSeek 模型客户端

    继承 OpenAICompatibleClient，复用 HTTP 请求和响应解析逻辑。
    仅覆盖 chat 方法，关闭思考模式以避免 reasoning_content 回传问题。
    """

    def __init__(
        self,
        model_name: str = "deepseek",
        max_tokens: int = 393216
    ):
        super().__init__(
            model_name=model_name,
            max_tokens=max_tokens,
        )

    async def chat(
        self,
        messages: List[Dict[str, Any]],
        tools: Optional[List[Dict[str, Any]]] = None,
        temperature: float = 0.0,
        **kwargs
    ) -> Dict[str, Any]:
        client = await self._get_client()

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }

        formatted_messages = convert_to_sdk_format(messages)

        payload: Dict[str, Any] = {
            "model": self.model,
            "messages": formatted_messages,
            "max_tokens": self.max_tokens,
            # 关闭思考模式
            "thinking": {"type": "disabled"},
        }

        # 思考模式下 temperature 不生效，但关闭后可以传
        payload["temperature"] = temperature

        if tools:
            payload["tools"] = tools

        # 指数退避重试
        _BASE_RETRY_DELAY = 5
        _MAX_RETRY_DELAY = 120
        max_retries = 5
        last_error = None

        for attempt in range(max_retries):
            try:
                response = await client.post(self.base_url, headers=headers, json=payload)
                response.raise_for_status()
                result = response.json()
                return self._parse_response(result)

            except httpx.HTTPStatusError as e:
                status_code = e.response.status_code
                error_msg = f"[{self.model_name}] HTTP 错误 {status_code}"
                try:
                    error_detail = e.response.json()
                    error_msg += f": {json.dumps(error_detail, ensure_ascii=False)}"
                except Exception:
                    error_msg += f": {e.response.text}"

                if status_code in (429, 500, 502, 503, 529):
                    last_error = RuntimeError(error_msg)
                    delay = min(_BASE_RETRY_DELAY * (2 ** attempt), _MAX_RETRY_DELAY)
                    jitter = delay * random.uniform(0.75, 1.25)
                    logger.warning(f"{error_msg} (第{attempt + 1}/{max_retries}次，{jitter:.1f}s 后重试)")
                    await asyncio.sleep(jitter)
                    continue
                logger.error(error_msg)
                raise RuntimeError(error_msg)

            except httpx.ReadTimeout:
                last_error = RuntimeError(f"[{self.model_name}] 请求超时")
                delay = min(_BASE_RETRY_DELAY * (2 ** attempt), _MAX_RETRY_DELAY)
                jitter = delay * random.uniform(0.75, 1.25)
                logger.warning(f"[{self.model_name}] 请求超时 (第{attempt + 1}/{max_retries}次，{jitter:.1f}s 后重试)")
                await asyncio.sleep(jitter)
                continue

            except httpx.ConnectError as e:
                last_error = RuntimeError(f"[{self.model_name}] 连接失败: {e}")
                delay = min(_BASE_RETRY_DELAY * (2 ** attempt), _MAX_RETRY_DELAY)
                jitter = delay * random.uniform(0.75, 1.25)
                logger.warning(f"[{self.model_name}] 连接失败 (第{attempt + 1}/{max_retries}次，{jitter:.1f}s 后重试): {e}")
                self._client = None
                client = await self._get_client()
                await asyncio.sleep(jitter)
                continue

            except Exception as e:
                logger.error(f"[{self.model_name}] 请求失败: {e}")
                self._client = None
                raise

        logger.error(f"[{self.model_name}] 已重试{max_retries}次，全部失败")
        raise last_error


# ==============================================================================
# 模块测试
# ==============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("DeepSeek 模型测试（思考模式已关闭）")
    print("=" * 60)

    import asyncio

    async def run_test():
        try:
            client = DeepSeekClient()

            # 测试1: 基本对话
            print("\n--- 测试1: 基本对话 ---")
            messages = [
                {"role": "system", "content": "你是一个有帮助的助手。"},
                {"role": "user", "content": "你好，请用一句话介绍自己"}
            ]
            response = await client.chat(messages=messages)
            texts = [b["text"] for b in response["content"] if b["type"] == "text"]
            print("助手:", "\n".join(texts))
            print("stop_reason:", response["stop_reason"])

            # 测试2: 工具调用
            print("\n--- 测试2: 工具调用 ---")
            tools = [
                {
                    "type": "function",
                    "function": {
                        "name": "get_weather",
                        "description": "获取指定城市的天气信息",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "city": {"type": "string", "description": "城市名称"}
                            },
                            "required": ["city"]
                        }
                    }
                }
            ]
            messages2 = [
                {"role": "user", "content": "北京今天天气怎么样？"}
            ]
            response2 = await client.chat(messages=messages2, tools=tools)
            print("stop_reason:", response2["stop_reason"])
            for block in response2["content"]:
                if block["type"] == "tool_use":
                    print(f"工具调用: {block['name']}({block['input']})")
                elif block["type"] == "text":
                    print(f"文本: {block['text']}")

            client.close()

        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"\n错误: {e}")

    asyncio.run(run_test())
