"""
================================================================================
Xiaomi MiMo 模块 - 小米 MiMo 模型客户端
================================================================================

小米 MiMo API 开放平台: https://api.xiaomimimo.com/

支持的模型:
    - xiaomi (默认)

使用示例:
    from llm_moudle.xiaomi_moudle import XiaomiClient

    client = XiaomiClient()
    response = await client.chat([{"role": "user", "content": "你好"}])
    print(response["content"][0]["text"])

================================================================================
"""
import json
import logging
import os
from typing import Any, Dict, List, Optional

from buddyMe.anthropic_standard.basic_anthropic_client import OpenAICompatibleClient

logger = logging.getLogger(__name__)


class XiaomiClient(OpenAICompatibleClient):
    """
    小米 MiMo 模型客户端

    继承 OpenAICompatibleClient，复用 HTTP 请求和响应解析逻辑。
    覆盖差异: MiMo API 返回 tool_calls: null（而非缺失字段），需兼容处理。

    配置 (model_config.py):
        "xiaomi": {
            "api_key": "your-api-key",
            "base_url": "https://api.xiaomimimo.com/v1/chat/completions"
        }

    响应格式 (遵循 anthropic_standard.py 规范):
        {
            "content": [
                {"type": "text", "text": "..."},
                {"type": "tool_use", "id": "...", "name": "...", "input": {...}}
            ],
            "stop_reason": "stop" | "tool_use",
            "usage": {...}
        }
    """

    def __init__(
        self,
        model_name: str = "xiaomi",
        max_tokens: int = 128000
    ):
        super().__init__(
            model_name=model_name,
            max_tokens=max_tokens,
        )

    def _parse_response(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """
        解析 MiMo 响应 → 统一标准格式。
        覆盖父类方法，处理 MiMo 特有差异: tool_calls 返回 null 而非缺失。
        """
        content = []
        stop_reason = "stop"

        if "choices" in result and result["choices"]:
            choice = result["choices"][0]
            message = choice.get("message", {})
            message_content = message.get("content")
            # MiMo 差异: tool_calls 可能为 null，需强制转为 []
            tool_calls = message.get("tool_calls") or []

            if message_content:
                content.append({
                    "type": "text",
                    "text": message_content
                })

            for tc in tool_calls:
                func = tc.get("function", {})
                arguments_str = func.get("arguments", "{}")

                try:
                    args = json.loads(arguments_str) if isinstance(arguments_str, str) else arguments_str
                except json.JSONDecodeError:
                    args = {}

                content.append({
                    "type": "tool_use",
                    "id": tc.get("id", f"{self.model_name}_{id(tc)}"),
                    "name": func.get("name", ""),
                    "input": args
                })

            finish_reason = choice.get("finish_reason", "stop")
            stop_reason = "tool_use" if finish_reason == "tool_calls" else finish_reason

        return {
            "content": content,
            "stop_reason": stop_reason,
            "usage": result.get("usage", {})
        }


# ==============================================================================
# 模块测试
# ==============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("Xiaomi MiMo 模型测试")
    print("输入 'quit' 退出")
    print("=" * 60)

    import asyncio

    async def run_test():
        try:
            client = XiaomiClient()
            messages = [
                {"role": "system", "content": "你是MiMo，是小米公司研发的AI智能助手。"},
                {"role": "user", "content": "你好，请介绍一下自己"}
            ]

            response = await client.chat(messages=messages)
            texts = [b["text"] for b in response["content"] if b["type"] == "text"]
            output = "\n".join(texts) or "[无回复]"
            print("\n助手:", output.encode("utf-8", errors="replace").decode("utf-8"))

            client.close()

        except Exception as e:
            import traceback
            traceback.print_exc()
            print(f"\n错误: {e}")

    asyncio.run(run_test())
