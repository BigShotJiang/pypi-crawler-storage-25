"""
================================================================================
Ernie 模块 - 百度千帆平台模型客户端
================================================================================

百度千帆平台: https://qianfan.baidubce.com/v2/chat/completions

支持的模型:
    - ernie (默认)
    - ernie-4.5
    - deepseek-v3
    - deepseek-r1

使用示例:
    from llm_moudle import create_client

    client = create_client("ernie")
    response = await client.chat([{"role": "user", "content": "你好"}])
    print(response["content"][0]["text"])

================================================================================
"""
import logging
from typing import Any, Dict, List, Optional

from buddyMe.anthropic_standard.basic_anthropic_client import OpenAICompatibleClient

logger = logging.getLogger(__name__)


class ErnieClient(OpenAICompatibleClient):
    """
    百度千帆平台模型客户端

    继承 OpenAICompatibleClient，复用 HTTP 请求和响应解析逻辑。
    覆盖差异: 默认超时 180 秒、自动添加 tool_choice: "auto"。

    配置 (config.yaml):
        models:
          ernie:
            api_key: "your-api-key"
            url: "https://qianfan.baidubce.com/v2/chat/completions"
            model: "ernie"

    响应格式 (遵循 anthropic_standard.py 规范):
        {
            "content": [
                {"type": "text", "text": "..."},
                {"type": "tool_use", "id": "...", "name": "...", "input": {...}}
            ],
            "stop_reason": "stop" | "tool_use",
            "usage": {...}
        }
    """

    def __init__(
        self,
        model_name: str = "ernie",
        max_tokens: int = 65536
    ):
        super().__init__(
            model_name=model_name,
            max_tokens=max_tokens
        )

    def _get_default_timeout(self) -> float:
        """Ernie 默认超时 180 秒"""
        return 180.0

    def _prepare_payload(
        self,
        payload: Dict[str, Any],
        tools: Optional[List[Dict[str, Any]]],
        kwargs: Dict[str, Any]
    ):
        """千帆平台: 当有 tools 时自动添加 tool_choice: "auto" """
        super()._prepare_payload(payload, tools, kwargs)
        if tools and "tool_choice" not in payload:
            payload["tool_choice"] = "auto"


# ==============================================================================
# 模块测试
# ==============================================================================

if __name__ == '__main__':
    print("=" * 60)
    print("Ernie 模型测试 - 百度千帆")
    print("输入 'quit' 退出")
    print("=" * 60)

    import asyncio

    async def run_test():
        try:
            client = ErnieClient()
            messages = [
                {"role": "system", "content": "你是一个有帮助的助手。"},
                {"role": "user", "content": "你好，请介绍一下自己"}
            ]

            response = await client.chat(messages=messages)
            texts = [b["text"] for b in response["content"] if b["type"] == "text"]
            print("\n助手:", "\n".join(texts) or "[无回复]")

            client.close()

        except Exception as e:
            print(f"\n错误: {e}")

    asyncio.run(run_test())
