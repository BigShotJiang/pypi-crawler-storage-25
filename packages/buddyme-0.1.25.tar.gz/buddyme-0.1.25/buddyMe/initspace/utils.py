"""
================================================================================
utils.py - 公共工具函数
================================================================================

供 contextbuild、memorybuild、memory_extractor、use_memory 共用的基础函数。

导出:
    _load_md(md_path)   — 读取 .md 文件（支持绝对/相对/项目根路径）
    _extract_json(text)  — 从 LLM 回复中提取第一个 JSON 对象
    _PROJECT_ROOT        — 项目根目录绝对路径

================================================================================
"""

import json
import os
import re

_PROJECT_ROOT = os.path.join(os.path.expanduser("~"), ".buddyme")


def _load_md(md_path: str) -> str:
    """读取指定的 .md 文件内容。

    路径解析策略：
        1. 先按原始路径解析（支持绝对路径和 cwd 相对路径）
        2. 若找不到，再按项目根目录解析（兼容从任意目录运行）

    Args:
        md_path: 文件路径（绝对路径、相对路径均可）

    Returns:
        文件内容字符串；文件不存在时返回空字符串。
    """
    abs_path = os.path.abspath(md_path)
    if not os.path.exists(abs_path):
        abs_path = os.path.join(_PROJECT_ROOT, md_path)
    if not os.path.exists(abs_path):
        return ""
    with open(abs_path, "r", encoding="utf-8") as f:
        return f.read().strip()


def _extract_json(text: str) -> dict:
    """从 LLM 回复中提取第一个 JSON 对象。"""
    match = re.search(r"\{[\s\S]*\}", text)
    if match:
        try:
            return json.loads(match.group())
        except json.JSONDecodeError:
            return {}
    return {}
