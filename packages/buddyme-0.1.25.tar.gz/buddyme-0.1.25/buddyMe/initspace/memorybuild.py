"""
memorybuild.py — 对话记录持久化

以 JSON 格式存储所有对话，日期为主 key。
"""

import json
import logging
import os
import re
from datetime import datetime
from typing import Any, Dict, List

from buddyMe.initspace.utils import _load_md

logger = logging.getLogger(__name__)


def _extract_facts(text: str) -> Dict[str, Any]:
    """从文本中提取结构化关键事实（纯正则，零LLM开销）。

    提取内容：
      - 文件路径（.html/.py/.md/.json/.txt/.css/.js/.csv/.xlsx/.pdf）
      - URL
      - 日期（YYYY-MM-DD / YYYY/MM/DD）
      - 模型名称
    """
    facts: Dict[str, Any] = {}

    file_paths = re.findall(
        r'[a-zA-Z0-9_/\-\\]+\.(?:html|py|md|json|txt|css|js|csv|xlsx|pdf)',
        text,
    )
    if file_paths:
        facts["files"] = list(set(file_paths))[:10]

    urls = re.findall(r'https?://[^\s<>"\']+', text)
    if urls:
        facts["urls"] = urls[:5]

    dates = re.findall(r'\d{4}[-/]\d{1,2}[-/]\d{1,2}', text)
    if dates:
        facts["dates"] = list(set(dates))

    model_names = re.findall(
        r'(?<![./\w])(?:glm|ernie|xiaomi|qwen|minimax|deepseek|claude|gpt)[\w.\-]*(?![/\w])',
        text, re.IGNORECASE,
    )
    if model_names:
        facts["models"] = list(set(m.lower() for m in model_names))[:3]

    return facts


#对话的记忆
class ConversationLogger:
    """对话记录器 — 追加式写入，按日期归档，支持情景记忆检索。"""

    def __init__(self, log_path: str = "memorys/conversation_log.json"):
        self.log_path = os.path.abspath(log_path)
        os.makedirs(os.path.dirname(self.log_path), exist_ok=True)
        self._init_log_file()

    def _init_log_file(self):
        """初始化日志文件，不存在则创建"""
        if not os.path.exists(self.log_path):
            with open(self.log_path, "w", encoding="utf-8") as f:
                json.dump({}, f, ensure_ascii=False, indent=2)

    def log(self, query: str, response: str,
            tool_calls: List[Dict[str, Any]] = None,
            model: str = "", extra: Dict[str, Any] = None) -> None:
        """
        追加一条对话记录。

        Args:
            query: 用户输入
            response: 助手回复
            tool_calls: 工具调用列表
            model: 模型名称
            extra: 补充信息（支持 task_type, execute_status, quality_score 等情景记忆字段）
        """
        date_key = datetime.now().strftime("%Y-%m-%d")

        record = {
            "time": datetime.now().strftime("%H:%M:%S"),
            "model": model,
            "query": query,
            "response": response,
            "response_summary": response[:500] if len(response) > 500 else response,
            "facts": _extract_facts(response),
            "tool_calls": tool_calls or [],
            **(extra or {}),
        }

        data = self._load()
        if date_key not in data:
            data[date_key] = []
        data[date_key].append(record)
        self._save(data)

    def _load(self) -> Dict:
        if os.path.exists(self.log_path):
            with open(self.log_path, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if not content:
                    return {}
                return json.loads(content)
        return {}

    def _save(self, data: Dict) -> None:
        with open(self.log_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
