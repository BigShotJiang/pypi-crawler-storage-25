# 用户画像

## 基本信息
- **称呼**: xiaohua
- **系统**: Windows（桌面路径 C:/Users/xiaohua/Desktop/）
- **Python 环境**: miniconda（C:/miniconda/python.exe）
- **身份**: 开发者，正在构建 buddyMe 多模型智能体项目

## 核心偏好
- 喜欢先看方案再决定是否执行，不喜欢直接改代码（"先回答我，我来决定"）
- 偏好 HTML 格式展示结果（导览图、攻略等）
- 注重代码整洁，会主动要求检查冗余代码
- 倾向于 CLI 风格操作，追求简洁的命令交互（如 /model --switch）
- 希望项目可发布到 PyPI，用 pip install 方式分发

## 沟通风格
- 中文为主，偶尔用英文测试
- 指令明确，会直接指出问题（如"你写到哪里去了"）
- 喜欢分步推进：先方案→确认→执行
- 会粘贴日志/报错让模型分析，期望精准诊断

## 模型使用
- **主力模型**: deepseek（使用频率最高）
- **已接入模型**: glm、ernie、qwen、xiaomi、minimax、claude、deepseek
- **模型切换**: 通过 /model --switch 命令切换，支持 --list 查看可用模型
- **项目路径**: buddyMe 项目位于 Desktop/buddyMe/buddyMe/，另有 AIPlayground、llmAgentBook 等项目
