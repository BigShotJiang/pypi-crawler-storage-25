"""buddyMe 本地开发入口 — 所有数据读写都在项目目录内"""

try:
    from buddyMe.agent_moudle import agent
except ImportError:
    from agent_moudle import agent

import os
import time

# 项目根目录（main.py 所在目录的上一级）
_PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

print("=" * 60)
print("buddyMe — 本地开发模式")
print(f"数据目录: {_PROJECT_ROOT}")
print("输入 /help 查看可用命令")
print("=" * 60)

model_name = "deepseek"
ag = agent.AgentMain(model_name=model_name, data_dir=_PROJECT_ROOT)

try:
    from buddyMe.tool_moudle.baidu_search_tool import BaiduSearchTool
except ImportError:
    from tool_moudle.baidu_search_tool import BaiduSearchTool
ag.register_tool(BaiduSearchTool())
ag.start_heartbeat()
#帮我做一个5月4日的博览馆攻略，根据北京的天气给出攻略，使用html展示，做完了自动打开。
while True:
    time.sleep(1)
    inp = input("query: ")
    reply = ag.invoke(inp)
    if reply:
        print(reply)
