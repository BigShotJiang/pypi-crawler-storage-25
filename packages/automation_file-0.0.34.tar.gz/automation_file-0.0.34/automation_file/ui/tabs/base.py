"""Shared base class for UI tabs.

Each tab gets a reference to the main window's :class:`LogPanel` plus a
:class:`QThreadPool` so long-running actions stay off the GUI thread.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from PySide6.QtCore import QThreadPool
from PySide6.QtWidgets import (
    QFileDialog,
    QGroupBox,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from automation_file.ui.log_widget import LogPanel
from automation_file.ui.worker import ActionWorker


class BaseTab(QWidget):
    """Common helpers for every feature tab."""

    def __init__(self, log: LogPanel, pool: QThreadPool) -> None:
        super().__init__()
        self._log = log
        self._pool = pool

    @staticmethod
    def make_button(label: str, handler: Callable[[], Any]) -> QPushButton:
        """Build a ``QPushButton`` wired to ``handler`` — the cloud tab idiom."""
        button = QPushButton(label)
        button.clicked.connect(handler)
        return button

    def run_action(
        self,
        target: Callable[..., Any],
        label: str,
        args: tuple[Any, ...] | None = None,
        kwargs: dict[str, Any] | None = None,
    ) -> None:
        worker = ActionWorker(target, args=args, kwargs=kwargs, label=label)
        worker.signals.log.connect(self._log.append_line)
        worker.signals.finished.connect(
            lambda result: self._log.append_line(f"result:  {label} -> {result!r}")
        )
        self._pool.start(worker)

    @staticmethod
    def path_picker_row(
        line_edit: QLineEdit,
        button_text: str,
        pick: Callable[[QWidget], str | None],
    ) -> QHBoxLayout:
        row = QHBoxLayout()
        row.addWidget(line_edit)
        button = QPushButton(button_text)

        def _on_click() -> None:
            chosen = pick(line_edit)
            if chosen:
                line_edit.setText(chosen)

        button.clicked.connect(_on_click)
        row.addWidget(button)
        return row

    @staticmethod
    def pick_existing_file(parent: QWidget) -> str | None:
        path, _ = QFileDialog.getOpenFileName(parent, "Select file")
        return path or None

    @staticmethod
    def pick_save_file(parent: QWidget) -> str | None:
        path, _ = QFileDialog.getSaveFileName(parent, "Save as")
        return path or None

    @staticmethod
    def pick_directory(parent: QWidget) -> str | None:
        path = QFileDialog.getExistingDirectory(parent, "Select directory")
        return path or None


class RemoteBackendTab(BaseTab):
    """Shared layout template for cloud/SFTP tabs.

    Subclasses supply ``_init_group`` (credentials / session setup) and
    ``_ops_group`` (file transfer actions). The base class places each
    group on its own inner sub-tab ("Credentials" / "Operations") so
    the two concerns aren't crammed together on a single vertical page.
    """

    def __init__(self, log: LogPanel, pool: QThreadPool) -> None:
        super().__init__(log, pool)
        root = QVBoxLayout(self)
        root.setContentsMargins(12, 12, 12, 12)
        root.setSpacing(12)

        inner = QTabWidget()
        inner.addTab(self._page(self._init_group()), "Credentials")
        inner.addTab(self._page(self._ops_group()), "Operations")
        root.addWidget(inner)

    def _init_group(self) -> QGroupBox:
        raise NotImplementedError

    def _ops_group(self) -> QGroupBox:
        raise NotImplementedError

    @staticmethod
    def _page(group: QGroupBox) -> QWidget:
        """Wrap a group box in a padded page so the sub-tab has breathing room."""
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(12)
        layout.addWidget(group)
        layout.addStretch()
        return page
