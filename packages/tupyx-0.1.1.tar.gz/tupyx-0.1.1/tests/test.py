import os
import sys
import subprocess
from pathlib import Path

# Diretório raiz
ROOT_DIR = Path.cwd()

# Pastas ignoradas
IGNORE_DIRS = {".venv", ".egg-info", "__pycache__", ".git", ".idea", ".vscode"}

# Filtrar extensões (None = tudo)
INCLUDE_EXTENSIONS = {".py"}  # recomendo deixar só .py

def should_ignore(path: Path):
    return any(part in IGNORE_DIRS for part in path.parts)

def build_tree(root: Path):
    lines = []

    def walk(dir_path, prefix=""):
        items = [p for p in sorted(dir_path.iterdir(), key=lambda x: (x.is_file(), x.name.lower()))
                 if not should_ignore(p)]

        for i, item in enumerate(items):
            connector = "└── " if i == len(items) - 1 else "├── "
            lines.append(prefix + connector + item.name)

            if item.is_dir():
                extension = "    " if i == len(items) - 1 else "│   "
                walk(item, prefix + extension)

    walk(root)
    return "\n".join(lines)

def get_files_content(root: Path):
    output = []

    for path in sorted(root.rglob("*")):
        if should_ignore(path) or path.is_dir():
            continue

        if INCLUDE_EXTENSIONS and path.suffix not in INCLUDE_EXTENSIONS:
            continue

        try:
            content = path.read_text(encoding="utf-8")
        except Exception:
            continue

        relative_path = path.relative_to(root)

        output.append(f"\n{'='*50}")
        output.append(f"{relative_path}")
        output.append(f"{'='*50}\n")
        output.append(content)

    return "\n".join(output)

def copy_to_clipboard(text: str):
    try:
        if sys.platform == "win32":
            subprocess.run("clip", input=text, text=True, check=True)
        elif sys.platform == "darwin":
            subprocess.run("pbcopy", input=text, text=True, check=True)
        else:
            # Linux (precisa ter xclip ou xsel instalado)
            subprocess.run("xclip -selection clipboard", input=text, text=True, shell=True, check=True)
    except Exception:
        print("⚠️ Não consegui copiar automaticamente. Vou salvar em arquivo.")
        with open("project_dump.txt", "w", encoding="utf-8") as f:
            f.write(text)
        print("📄 Salvo em project_dump.txt")

def main():
    result = []

    result.append("PROJECT TREE:\n")
    result.append(build_tree(ROOT_DIR))

    result.append("\n\nFILES CONTENT:\n")
    result.append(get_files_content(ROOT_DIR))

    final_text = "\n".join(result)

    copy_to_clipboard(final_text)

    print("✅ Pronto!")

if __name__ == "__main__":
    main()