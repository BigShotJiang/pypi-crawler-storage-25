"""
tupyx.ui.router.router
----------------------
Sistema de roteamento de páginas do tupyx.

Como funciona:
- `@page("/rota")` registra uma função como página para aquela rota.
- `Router` é um componente que, quando renderizado, executa a função
  correta com base na URL atual.
- `_autodiscover()` importa automaticamente todos os arquivos .py da
  pasta `pages/` para que seus `@page(...)` sejam registrados.

Rotas dinâmicas (com parâmetros):
    @page("/usuario/{id}")
    def perfil(id):
        return Div(f"Perfil do usuário: {id}")

Redirect (página padrão ao abrir "/"):
    @page("/dash", redirect=True)
    def dashboard():
        ...
    # Ao abrir http://localhost:8000/, o browser é redirecionado para /dash
"""

import os
import importlib
import re
from tupyx.ui.html.tag import Tag
from tupyx.colors import Colors
from tupyx.ui.reactive.reactive import _begin_scope

# Dicionário de rotas: "/caminho" → função de página
routes = {}

# Caminho atual da requisição — atualizado pelo servidor a cada request
_current_path = "/"

# Caminho para redirecionar quando nenhuma rota combina (ex: ao abrir "/")
_redirect_path = None


def page(path: str, redirect: bool = False):
    """
    Decorator que registra uma função como página para a rota `path`.

    Parâmetros:
        path     — URL da página, ex: "/", "/dashboard", "/usuario/{id}"
        redirect — se True, esta rota é o destino do redirect automático
                   quando o usuário abre "/" ou uma rota não encontrada

    Exemplo básico:
        @page("/")
        def home():
            return Div(H1("Bem-vindo!"))

    Exemplo com redirect (página padrão):
        @page("/dash", redirect=True)
        def dashboard():
            return Div("Dashboard principal")

    Exemplo com parâmetro dinâmico:
        @page("/produto/{id}")
        def produto(id):
            return Div(f"Produto #{id}")
    """
    def decorator(func):
        global _redirect_path

        routes[path] = func

        if redirect:
            _redirect_path = path

        return func
    return decorator


def _match_route(path: str):
    """
    Encontra a função de página correspondente ao `path` recebido.

    Suporta rotas com parâmetros dinâmicos: `/produto/{id}` combina com `/produto/42`.
    Retorna (função, dict_de_params) ou (None, {}) se não encontrar.

    Exemplo:
        _match_route("/produto/42")
        # → (função_produto, {"id": "42"})
    """
    for route_pattern, func in routes.items():
        # Converte {param} em grupo nomeado de regex: (?P<param>[^/]+)
        regex = re.sub(r"\{(\w+)\}", r"(?P<\1>[^/]+)", route_pattern)
        regex = f"^{regex}$"

        match = re.match(regex, path)
        if match:
            return func, match.groupdict()

    return None, {}


def _autodiscover(ignore: list = ["app.py", "setup.py"]):
    """
    Importa automaticamente todos os arquivos .py do projeto
    para registrar suas rotas `@page(...)`.

    Evita reimportar o próprio pacote `tupyx` e pastas de ambiente (.venv, etc.).
    Chamado automaticamente pela função `run()` ao iniciar o servidor.
    """
    ignore_dirs = {".venv", "__pycache__", ".git", "tupyx"}

    for root, dirs, files in os.walk("."):
        dirs[:] = [d for d in dirs if d not in ignore_dirs]

        for filename in files:
            if filename.endswith(".py") and filename not in ignore and not filename.startswith("_"):
                filepath = os.path.join(root, filename)
                # Converte "./pages/home.py" → "pages.home"
                module_name = filepath \
                    .replace(os.sep, ".") \
                    .lstrip(".") \
                    [:-3]

                try:
                    importlib.import_module(module_name)
                except Exception as e:
                    print(f"{Colors.YELLOW}⚠ erro ao importar {module_name}: {e}{Colors.RESET}")


class Router(Tag):
    """
    Componente que renderiza a página correta com base na URL atual.

    Coloque `Router()` no `Body()` do seu app para que o sistema de
    roteamento funcione:

        def app():
            return Html(
                Head(Title("Meu App")),
                Body(Router()).sx(margin="0"),
            )

        run(app)

    O Router cria um escopo de render único por rota, o que garante
    que os Reactive() criados dentro das páginas tenham chaves estáveis
    e seus valores sejam preservados entre renders.
    """

    def __init__(self, **attrs):
        super().__init__("div", **attrs)

    def render(self) -> str:
        import tupyx.ui.router.router as _router

        path = _router._current_path
        func, params = _match_route(path)

        if func:
            # Escopo único e estável: garante que Reactive() tenha sempre a mesma chave
            scope = f"route:{path}:{func.__name__}"

            try:
                _begin_scope(scope)
                return str(func(**params))
            finally:
                # Limpa o escopo após render para não vazar entre requests
                _begin_scope(None)

        return "<div>404 — página não encontrada</div>"
