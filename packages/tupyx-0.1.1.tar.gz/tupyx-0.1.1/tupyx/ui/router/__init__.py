from .router import (
    routes,
    _current_path,
    Router,
    page,
    _autodiscover
)


__all__ = [
    "_current_path",
    "routes",
    "Router",
    "page",
    "_autodiscover"
]