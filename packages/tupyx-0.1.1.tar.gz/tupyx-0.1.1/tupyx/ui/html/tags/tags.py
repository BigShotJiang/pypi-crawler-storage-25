"""
tupyx.ui.html.tags.tags
-----------------------
Todos os elementos HTML prontos para uso.

Cada nome (Div, P, H1, Button…) é um atalho para `Tag.create("nome")`.
Basta chamar como função, passando filhos e/ou atributos:

    Div("Olá")                          # → <div>Olá</div>
    P("Texto", id="meu-p")             # → <p id="meu-p">Texto</p>

Componentes especiais definidos aqui:
- `InputTag`  — <input> com suporte a .bind(reactive)
- `SelectTag` — <select> com suporte a .bind(reactive)
- `NavLink`   — navegação entre rotas sem recarregar a página
    H1("Título").sx(font_size="32px")  # → <h1 style="font-size:32px">Título</h1>

Além das tags simples, este módulo define:
- `InputTag` — input com suporte a `.bind(reactive)` e estado reativo
- `SelectTag` — select com suporte a `.bind(reactive)` e marca a option correta
"""

from tupyx.ui.html.tag import Tag


# ── Registro global de inputs/selects ─────────────────────────────────────────
#
# Quando um evento dispara no browser, o servidor recebe os valores de todos
# os inputs. Para saber qual InputTag/SelectTag Python atualizar, usamos
# esses registros indexados pelo id do elemento.

_input_registry  = {}   # id → InputTag
_name_registry   = {}   # name → InputTag (para formulários com name)
_select_registry = {}   # id → SelectTag


# ── InputTag ──────────────────────────────────────────────────────────────────

class InputTag(Tag):
    """
    Elemento `<input>` com suporte a reatividade.

    Parâmetros:
        type        — tipo do input: "text", "number", "email", "password", etc.
        value       — valor inicial (ou um Reactive para binding bidirecional)
        placeholder — texto de dica quando vazio
        name        — atributo `name` para formulários
        required    — se True, adiciona o atributo `required`
        disabled    — se True, adiciona o atributo `disabled`

    Binding reativo (recomendado):
        ano = Reactive("2024")
        Input(type="text").bind(ano)
        # O input mostra o valor de `ano` e atualiza `ano` automaticamente
        # quando o usuário digitar.

    Exemplo sem binding:
        Input(type="email", placeholder="seu@email.com")
    """

    def __init__(
        self,
        *children,
        type="text",
        value=None,
        placeholder=None,
        name=None,
        required=False,
        disabled=False,
        **attrs
    ):
        super().__init__("input", *children, **attrs)

        self.type         = type
        self.value        = value
        self.placeholder  = placeholder
        self.input_name   = name
        self.required     = required
        self.disabled     = disabled
        self._bound_reactive = None  # Reactive linkado via .bind()

        # Registra pelo id para o servidor encontrar este input nos eventos
        _input_registry[self.attrs["id"]] = self

        if name:
            _name_registry[name] = self

    # ── Setters encadeáveis ───────────────────────────────────────────────────

    def set_type(self, type: str):
        """Altera o tipo do input. Retorna self para encadeamento."""
        self.type = type
        return self

    def set_placeholder(self, placeholder: str):
        """Define o placeholder do input."""
        self.placeholder = placeholder
        return self

    def set_value(self, value):
        """
        Define o valor do input e atualiza o Reactive linkado (se houver).
        Chamado automaticamente pelo servidor quando o usuário digita.
        """
        self.value = value
        if self._bound_reactive is not None:
            self._bound_reactive.set(value)
        return self

    def set_name(self, name: str):
        """Define o atributo `name` e registra no _name_registry."""
        self.input_name = name
        _name_registry[name] = self
        return self

    def set_required(self, required=True):
        """Marca o campo como obrigatório."""
        self.required = required
        return self

    def set_disabled(self, disabled=True):
        """Desabilita o campo."""
        self.disabled = disabled
        return self

    def get_value(self):
        """Retorna o valor atual (do Reactive se houver binding, senão o value direto)."""
        if self._bound_reactive is not None:
            return self._bound_reactive.get()
        return self.value

    def bind(self, reactive):
        """
        Conecta este input a um Reactive para sincronização bidirecional.

        - O input exibe o valor atual do Reactive.
        - Quando o usuário digita, o Reactive é atualizado automaticamente.
        - Registra um on_change automático para disparar a atualização.

        Exemplo:
            filtro = Reactive("2024")
            Input(type="text").bind(filtro)
        """
        self._bound_reactive = reactive
        self.value = reactive
        # Registra evento on_change com função vazia — o servidor atualizará
        # o Reactive com o valor do input antes de re-renderizar
        self.on_change(lambda: None)
        return self

    def render(self) -> str:
        """Renderiza o <input> com todos os atributos aplicados."""
        if self.input_name:
            self.attrs["name"] = self.input_name

        if self.type:
            self.attrs["type"] = self.type

        if self.placeholder:
            self.attrs["placeholder"] = self.placeholder

        if self.value is not None:
            # Se o valor for um Reactive, lê o valor atual
            if hasattr(self.value, "get"):
                self.attrs["value"] = self.value.get()
            else:
                self.attrs["value"] = self.value

        if self.required:
            self.attrs["required"] = "true"

        if self.disabled:
            self.attrs["disabled"] = "true"

        return super().render()


# ── SelectTag ─────────────────────────────────────────────────────────────────

class SelectTag(Tag):
    """
    Elemento `<select>` com suporte a reatividade.

    Filhos devem ser criados com `Option("texto", value="valor")`.
    O SelectTag marca automaticamente a `<option>` correta como `selected`
    baseado no valor atual do Reactive linkado.

    Exemplo:
        ano = Reactive("2024")

        Select(
            Option("2024", value="2024"),
            Option("2023", value="2023"),
        ).bind(ano)

        # Quando o usuário muda o select, `ano` é atualizado automaticamente.
    """

    def __init__(self, *options, value=None, name=None, disabled=False, **attrs):
        super().__init__("select", *options, **attrs)

        self.value           = value
        self.select_name     = name
        self.disabled        = disabled
        self._bound_reactive = None

        # Registra para o servidor encontrar este select nos eventos
        _select_registry[self.attrs["id"]] = self

        if name:
            _name_registry[name] = self

    def bind(self, reactive):
        """
        Conecta este select a um Reactive.

        - O select exibe a opção correspondente ao valor atual do Reactive.
        - Quando o usuário muda, o Reactive é atualizado automaticamente.

        Exemplo:
            cor = Reactive("azul")
            Select(
                Option("Azul", value="azul"),
                Option("Vermelho", value="vermelho"),
            ).bind(cor)
        """
        self._bound_reactive = reactive
        self.value = reactive
        self.on_change(lambda: None)
        return self

    def set_value(self, value):
        """
        Define o valor selecionado e atualiza o Reactive (se houver).
        Chamado automaticamente pelo servidor quando o usuário muda a seleção.
        """
        self.value = value
        if self._bound_reactive is not None:
            self._bound_reactive.set(value)
        return self

    def get_value(self):
        """Retorna o valor atual selecionado."""
        if self._bound_reactive is not None:
            return self._bound_reactive.get()
        return self.value

    def set_name(self, name: str):
        """Define o atributo `name` do select."""
        self.select_name = name
        _name_registry[name] = self
        return self

    def set_disabled(self, disabled=True):
        """Desabilita o select."""
        self.disabled = disabled
        return self

    def render(self) -> str:
        """
        Renderiza o <select> marcando a <option> correta como `selected`
        com base no valor atual do Reactive linkado (ou do valor direto).
        """
        if self.select_name:
            self.attrs["name"] = self.select_name

        if self.disabled:
            self.attrs["disabled"] = "true"

        # Valor atual: lê do Reactive ou usa o valor direto
        current = self.value.get() if hasattr(self.value, "get") else self.value

        # Percorre as options e marca a correta como selected
        resolved_children = []
        for child in self.children:
            if isinstance(child, Tag) and child.name == "option":
                opt_val = child.attrs.get("value", "")
                if str(opt_val) == str(current):
                    child.attrs["selected"] = "selected"
                else:
                    child.attrs.pop("selected", None)
            resolved_children.append(child)
        self.children = resolved_children

        return super().render()


# ── NavLink ───────────────────────────────────────────────────────────────────

class NavLink(Tag):
    """
    Link de navegação entre rotas tupyx sem recarregar a página.

    Funciona como um `<a>` normal (acessível, funciona com Ctrl+clique,
    aparece no histórico do browser), mas ao clicar faz um fetch da rota,
    substitui apenas o conteúdo do root e atualiza a URL com pushState.

    O botão voltar/avançar do browser também funciona corretamente —
    o servidor injeta um listener de `popstate` em todas as páginas.

    Parâmetros:
        *children — conteúdo do link (texto, ícone, etc.)
        to        — rota de destino (ex: "/dashboard", "/sobre")
        **attrs   — atributos HTML extras (class, target, etc.)

    Exemplo:
        NavLink("Ir para o dashboard", to="/dashboard")

        NavLink(
            Span("← Voltar"),
            to="/",
        ).sx(color="#2563eb", text_decoration="none", font_size="14px")

    Com estilo de botão:
        NavLink("Ver relatório", to="/relatorio").sx(
            background="#2563eb",
            color="white",
            padding="8px 16px",
            border_radius="8px",
            text_decoration="none",
            display="inline-block",
        )
    """

    def __init__(self, *children, to: str, **attrs):
        super().__init__("a", *children, **attrs)

        # href normal para acessibilidade (Ctrl+clique, SEO, etc.)
        self.attrs["href"] = to

        # JS que intercepta o clique, faz fetch e troca o conteúdo sem reload
        self.attrs["onclick"] = (
            f"(function(e){{"
            f"e.preventDefault();"
            f"const path='{to}';"
            f"fetch(path)"
            f".then(r=>r.text())"
            f".then(html=>{{"
            f"  const doc=new DOMParser().parseFromString(html,'text/html');"
            f"  const newRoot=doc.querySelector('[data-tupyx-root]');"
            f"  const root=document.querySelector('[data-tupyx-root]');"
            f"  if(root&&newRoot){{root.replaceWith(newRoot);}}"
            # Atualiza a URL no browser sem recarregar
            f"  history.pushState(null,'',path);"
            f"}});"
            f"}})(event)"
        )


# ── Atalhos de tags HTML ───────────────────────────────────────────────────────
# Uso: Div("conteúdo"), P("texto"), H1("Título"), etc.

# Layout básico
Div      = Tag.create("div")
Span     = Tag.create("span")
P        = Tag.create("p")
A        = Tag.create("a")
Img      = Tag.create("img")
Button   = Tag.create("button")
Input    = InputTag            # usa a versão com suporte a binding
Form     = Tag.create("form")
Label    = Tag.create("label")
Textarea = Tag.create("textarea")
Select   = SelectTag           # usa a versão com suporte a binding
Option   = Tag.create("option")

# Títulos
H1 = Tag.create("h1")
H2 = Tag.create("h2")
H3 = Tag.create("h3")
H4 = Tag.create("h4")
H5 = Tag.create("h5")
H6 = Tag.create("h6")

# Listas
Ul = Tag.create("ul")
Ol = Tag.create("ol")
Li = Tag.create("li")

# Semântica / Layout
Header  = Tag.create("header")
Footer  = Tag.create("footer")
Main    = Tag.create("main")
Section = Tag.create("section")
Article = Tag.create("article")
Nav     = Tag.create("nav")
Aside   = Tag.create("aside")

# Mídia
Video  = Tag.create("video")
Audio  = Tag.create("audio")
Source = Tag.create("source")
Canvas = Tag.create("canvas")
Svg    = Tag.create("svg")

# Tabelas
Table   = Tag.create("table")
Thead   = Tag.create("thead")
Tbody   = Tag.create("tbody")
Tfoot   = Tag.create("tfoot")
Tr      = Tag.create("tr")
Th      = Tag.create("th")
Td      = Tag.create("td")
Caption = Tag.create("caption")

# Documento HTML
Html   = Tag.create("html")
Head   = Tag.create("head")
Body   = Tag.create("body")
Title  = Tag.create("title")
Meta   = Tag.create("meta")
Link   = Tag.create("link")
Script = Tag.create("script")
Style  = Tag.create("style")

# Texto inline
Strong = Tag.create("strong")
Em     = Tag.create("em")
Small  = Tag.create("small")
Br     = Tag.create("br")
Hr     = Tag.create("hr")
Code   = Tag.create("code")
Pre    = Tag.create("pre")
