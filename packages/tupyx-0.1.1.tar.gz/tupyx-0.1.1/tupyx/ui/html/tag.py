"""
tupyx.ui.html.tag
-----------------
Classe base `Tag` — o coração de todos os componentes tupyx.

Cada elemento HTML (Div, H1, Button, etc.) é uma instância de `Tag`.
Você raramente vai usar `Tag` diretamente; use os atalhos em `tags.py`.

Como funciona:
- Você cria uma tag passando filhos e atributos no construtor.
- `.sx(**estilos)` aplica CSS inline (usando snake_case → kebab-case).
- `.on_click(fn)`, `.on_change(fn)` etc. registram eventos que chamam o servidor.
- `.render()` converte tudo para uma string HTML final.

Segurança:
- Filhos de texto são escapados automaticamente via `html.escape()`.
- Para inserir HTML cru e confiável use `safe("...")`.
"""

from __future__ import annotations

from typing import Callable
import uuid
from tupyx.ui.events import add_event
from tupyx.ui.html.sxtypes import SxTypes
import html

try:
    from typing import Unpack
except ImportError:
    from typing_extensions import Unpack


# Tags HTML que não têm tag de fechamento (ex: <br>, <img>)
VOID_TAGS = {
    "input", "img", "br", "hr", "meta", "link", "source"
}


# ── Conteúdo HTML seguro ───────────────────────────────────────────────────────

class SafeString(str):
    """
    Marca uma string como HTML já seguro.
    Strings normais são escapadas; SafeString é inserida como está.
    """
    pass


def safe(value: str) -> SafeString:
    """
    Marca `value` como HTML confiável para não ser escapado no render.

    Use quando você já construiu a string HTML manualmente e tem certeza
    que não há conteúdo malicioso (ex: SVG interno de gráficos).

    Exemplo:
        svg_code = "<circle cx='50' cy='50' r='40'/>"
        Div(safe(svg_code))   # renderiza o SVG sem escapar os < e >
    """
    return SafeString(value)


# ── Classe base Tag ────────────────────────────────────────────────────────────

class Tag:
    """
    Representa um elemento HTML genérico.

    Parâmetros:
        _name     — nome da tag HTML (ex: "div", "p", "button")
        *children — filhos: outros Tags, strings, ou Reactive
        **attrs   — atributos HTML (ex: href="/", class_="btn")

    Exemplo:
        Tag("p", "Olá!", id="meu-p")
        # → <p id="meu-p">Olá!</p>
    """

    def __init__(self, _name: str, *children, **attrs):
        self.name = _name
        self.children = []
        self.attrs = attrs
        self.styles = {}
        self._pseudo_styles = []  # estilos de :hover, :focus, :active

        # Cada tag recebe um ID único automático para o sistema de eventos funcionar
        self.attrs["id"] = str(uuid.uuid4())

        if children:
            self.add(*children)

    @classmethod
    def create(cls, name: str):
        """
        Cria uma função factory para uma tag com nome fixo.

        Usado internamente para criar os atalhos (Div, P, H1…):
            Div = Tag.create("div")
            Div("conteúdo")  # equivale a Tag("div", "conteúdo")
        """
        def factory(*children, **attrs):
            return cls(name, *children, **attrs)
        return factory

    # ── Eventos ───────────────────────────────────────────────────────────────
    #
    # Cada método `.on_*()` registra uma função Python no servidor.
    # Quando o evento dispara no browser, o JS faz um fetch para o servidor,
    # que chama a função e devolve o HTML atualizado.

    def on_click(self, func: Callable):
        """Executa `func` quando o elemento é clicado."""
        return self.__on("onclick", func)

    def on_dblclick(self, func: Callable):
        """Executa `func` no duplo clique."""
        return self.__on("ondblclick", func)

    def on_mouseover(self, func: Callable):
        """Executa `func` quando o mouse entra no elemento."""
        return self.__on("onmouseover", func)

    def on_mouseout(self, func: Callable):
        """Executa `func` quando o mouse sai do elemento."""
        return self.__on("onmouseout", func)

    def on_mouseenter(self, func: Callable):
        """Executa `func` quando o mouse entra (não propaga para filhos)."""
        return self.__on("onmouseenter", func)

    def on_mouseleave(self, func: Callable):
        """Executa `func` quando o mouse sai (não propaga para filhos)."""
        return self.__on("onmouseleave", func)

    def on_keydown(self, func: Callable):
        """Executa `func` quando uma tecla é pressionada."""
        return self.__on("onkeydown", func)

    def on_keyup(self, func: Callable):
        """Executa `func` quando uma tecla é solta."""
        return self.__on("onkeyup", func)

    def on_input(self, func: Callable):
        """Executa `func` a cada caractere digitado em um input."""
        return self.__on("oninput", func)

    def on_change(self, func: Callable):
        """Executa `func` quando o valor de um input/select muda e perde o foco."""
        return self.__on("onchange", func)

    def on_submit(self, func: Callable):
        """Executa `func` quando um formulário é enviado."""
        return self.__on("onsubmit", func)

    def on_focus_event(self, func: Callable):
        """Executa `func` quando o elemento recebe foco."""
        return self.__on("onfocus", func)

    def on_blur(self, func: Callable):
        """Executa `func` quando o elemento perde o foco."""
        return self.__on("onblur", func)

    def on_js(self, event: str, js: str):
        """
        Insere JavaScript puro diretamente no atributo de evento,
        sem passar pelo servidor tupyx.

        Útil para efeitos puramente visuais (animações, toggles CSS)
        que não precisam atualizar estado Python.

        Exemplo:
            Button("Toggle").on_js("onclick", "this.classList.toggle('ativo')")
        """
        self.attrs[event] = js
        return self

    def __on(self, event: str, func: Callable):
        """Registra `func` como handler do `event` e gera o JS de fetch."""
        path: str = add_event(func)
        self.__set_event(event, path)
        return self

    def __set_event(self, type: str, path: str):
        """
        Gera o atributo de evento com o JS que:
        1. Coleta todos os valores de inputs e selects na página.
        2. Faz fetch para o servidor com esses valores.
        3. Substitui o root do DOM com o HTML atualizado.

        Isso implementa a reatividade: a cada evento, a página inteira
        (ou pelo menos o root) é re-renderizada com o novo estado.
        """
        element_id = self.attrs.get("id")

        if not element_id:
            raise Exception("Elemento precisa ter um id para usar evento")

        self.attrs[type] = (
            f"(function(e){{"
            f"const el = e.currentTarget;"
            # Encontra o container root mais próximo para substituição parcial
            f"const root = el.closest('[data-tupyx-root]');"

            # Coleta todos os inputs e selects da página para enviar ao servidor
            f"const inputs = document.querySelectorAll('input, select');"
            f"let params = 'current_path=' + encodeURIComponent(window.location.pathname);"
            f"inputs.forEach(inp => {{"
            f"  if(inp.id) params += '&' + inp.id + '=' + encodeURIComponent(inp.value);"
            f"}});"

            # Faz o fetch para o servidor com o path do evento e os valores dos inputs
            f"fetch('{path}?' + params)"
            f".then(res => res.text())"
            f".then(html => {{"
            f"  const parser = new DOMParser();"
            f"  const doc = parser.parseFromString(html, 'text/html');"
            f"  const newRoot = doc.querySelector('[data-tupyx-root]');"

            # Substitui o root antigo pelo novo renderizado
            f"  if(root && newRoot) {{"
            f"    root.replaceWith(newRoot);"
            f"  }}"
            f"}});"

            f"}})(event)"
        )

    # ── Filhos ────────────────────────────────────────────────────────────────

    def add(self, *children):
        """
        Adiciona filhos à tag.

        Filhos podem ser: outras Tags, strings, Reactive, ou qualquer callable.

        Exemplo:
            div = Div()
            div.add(P("Parágrafo"), "texto simples")
        """
        for child in children:
            self.children.append(child)
        return self

    def set_content(self, content: str):
        """Substitui todos os filhos por um único conteúdo de texto."""
        self.children = [content]
        return self

    # ── Estilos ───────────────────────────────────────────────────────────────

    def sx(self, **props: Unpack[SxTypes]):
        """
        Aplica estilos CSS inline usando Python snake_case.

        Converte automaticamente underline em hífen:
            font_size="16px"  →  font-size: 16px

        Exemplo:
            Div("Olá").sx(
                background="#f0f7ff",
                border_radius="8px",
                padding="16px",
                font_size="14px",
            )
        """
        for key, value in props.items():
            css_key = key.replace("_", "-")
            self.styles[css_key] = str(value)
        return self

    def on_hover(self, **props):
        """
        Aplica estilos CSS no estado :hover (mouse sobre o elemento).

        Exemplo:
            Button("Clique").on_hover(background="#2563eb", color="white")
        """
        css = self._build_pseudo_css(":hover", props)
        self._pseudo_styles.append(css)
        return self

    def on_focus(self, **props):
        """Aplica estilos CSS no estado :focus (elemento com foco)."""
        css = self._build_pseudo_css(":focus", props)
        self._pseudo_styles.append(css)
        return self

    def on_active(self, **props):
        """Aplica estilos CSS no estado :active (durante o clique)."""
        css = self._build_pseudo_css(":active", props)
        self._pseudo_styles.append(css)
        return self

    def _build_pseudo_css(self, pseudo: str, props: dict) -> str:
        """Gera a regra CSS para um pseudosseletor usando o id único do elemento."""
        element_id = self.attrs.get("id")
        rules = "; ".join(
            f"{k.replace('_', '-')}: {v}" for k, v in props.items()
        )
        return f"#{element_id}{pseudo} {{ {rules} }}"

    # ── Render ────────────────────────────────────────────────────────────────

    def _escape_attr(self, value):
        """
        Escapa o valor de um atributo HTML.
        SafeString não é escapada (já é confiável).
        """
        if isinstance(value, SafeString):
            return str(value)
        return html.escape(str(value), quote=True)

    def _render_attrs(self) -> str:
        """Constrói a string de atributos HTML: id="..." style="..." etc."""
        attrs = self.attrs.copy()

        # Adiciona o style inline se houver estilos definidos via .sx()
        if self.styles:
            style_str = "; ".join(f"{k}: {v}" for k, v in self.styles.items())
            attrs["style"] = style_str

        if not attrs:
            return ""

        return " ".join(f'{k}="{self._escape_attr(v)}"' for k, v in attrs.items())

    def render(self) -> str:
        """
        Converte esta tag e todos os filhos em uma string HTML.

        Regras de escaping:
        - Strings normais são escapadas (protege contra XSS).
        - SafeString é inserida como está.
        - Reactive e callables são resolvidos antes de escapar.
        """
        attrs = self._render_attrs()

        def resolve(child):
            # Outro Tag: renderiza recursivamente
            if isinstance(child, Tag):
                return child.render()

            # Reactive ou callable: obtém o valor atual
            if hasattr(child, "get"):
                value = child.get()
            elif callable(child):
                value = child()
            else:
                value = child

            # SafeString: já é HTML confiável, não escapa
            if isinstance(value, SafeString):
                return str(value)

            # String normal: escapa para segurança
            return html.escape(str(value))

        content = "".join(resolve(child) for child in self.children)

        # Tags void (<br>, <img>, etc.) não têm conteúdo nem tag de fechamento
        if self.name in VOID_TAGS:
            return f"<{self.name} {attrs}>".strip()

        if attrs:
            return f"<{self.name} {attrs}>{content}</{self.name}>"
        else:
            return f"<{self.name}>{content}</{self.name}>"

    def _collect_pseudo_styles(self) -> list:
        """Coleta recursivamente os estilos de :hover/:focus/:active de toda a árvore."""
        result = list(self._pseudo_styles)
        for child in self.children:
            if isinstance(child, Tag):
                result.extend(child._collect_pseudo_styles())
        return result

    def render_with_styles(self) -> str:
        """
        Render completo: HTML + estilos de pseudosseletores injetados no <head>
        (ou como <style> antes do conteúdo se não houver <head>).

        Também envolve o conteúdo em um div com `data-tupyx-root` para que
        o sistema de eventos saiba qual parte do DOM substituir após um evento.

        Este método é chamado automaticamente pelo servidor.
        """
        html_output = self.render()
        styles = "".join(self._collect_pseudo_styles())

        root_id = self.attrs.get("id")

        # O atributo data-tupyx-root é o marcador que o JS usa para
        # encontrar e substituir o conteúdo após cada evento
        wrapped = f'<div data-tupyx-root="{root_id}">{html_output}</div>'

        if not styles:
            return wrapped

        # Injeta os estilos pseudo no <head> se existir, senão antes do root
        if "<head>" in wrapped:
            return wrapped.replace("<head>", f"<head><style>{styles}</style>")

        return f"<style>{styles}</style>{wrapped}"

    def __str__(self):
        return self.render()
