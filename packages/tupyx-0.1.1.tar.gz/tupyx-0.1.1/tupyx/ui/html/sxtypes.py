from typing import TypedDict

class SxTypes(TypedDict, total=False):

    # ── Layout
    display: str
    position: str
    top: str
    right: str
    bottom: str
    left: str
    z_index: str
    float: str
    clear: str
    overflow: str
    overflow_x: str
    overflow_y: str
    visibility: str
    clip: str
    clip_path: str

    # ── Flexbox
    flex: str
    flex_direction: str
    flex_wrap: str
    flex_shrink: str
    flex_grow: str
    flex_basis: str
    flex_flow: str
    align_items: str
    align_self: str
    align_content: str
    justify_content: str
    justify_items: str
    justify_self: str
    gap: str
    row_gap: str
    column_gap: str
    order: str

    # ── Grid
    grid: str
    grid_template: str
    grid_template_columns: str
    grid_template_rows: str
    grid_template_areas: str
    grid_column: str
    grid_column_start: str
    grid_column_end: str
    grid_row: str
    grid_row_start: str
    grid_row_end: str
    grid_area: str
    grid_auto_columns: str
    grid_auto_rows: str
    grid_auto_flow: str

    # ── Tamanho
    width: str
    height: str
    min_width: str
    min_height: str
    max_width: str
    max_height: str
    box_sizing: str
    aspect_ratio: str

    # ── Margin
    margin: str
    margin_top: str
    margin_right: str
    margin_bottom: str
    margin_left: str
    margin_block: str
    margin_block_start: str
    margin_block_end: str
    margin_inline: str
    margin_inline_start: str
    margin_inline_end: str

    # ── Padding
    padding: str
    padding_top: str
    padding_right: str
    padding_bottom: str
    padding_left: str
    padding_block: str
    padding_block_start: str
    padding_block_end: str
    padding_inline: str
    padding_inline_start: str
    padding_inline_end: str

    # ── Tipografia
    font_family: str
    font_size: str
    font_weight: str
    font_style: str
    font_variant: str
    font_stretch: str
    font_kerning: str
    line_height: str
    letter_spacing: str
    word_spacing: str
    text_align: str
    text_align_last: str
    text_decoration: str
    text_decoration_color: str
    text_decoration_style: str
    text_decoration_line: str
    text_decoration_thickness: str
    text_transform: str
    text_indent: str
    text_overflow: str
    text_shadow: str
    text_wrap: str
    white_space: str
    word_break: str
    word_wrap: str
    overflow_wrap: str
    line_clamp: str
    vertical_align: str
    direction: str
    writing_mode: str
    hyphens: str
    tab_size: str
    color: str

    # ── Background
    background: str
    background_color: str
    background_image: str
    background_size: str
    background_position: str
    background_position_x: str
    background_position_y: str
    background_repeat: str
    background_attachment: str
    background_origin: str
    background_clip: str
    background_blend_mode: str

    # ── Borda
    border: str
    border_top: str
    border_right: str
    border_bottom: str
    border_left: str
    border_radius: str
    border_top_left_radius: str
    border_top_right_radius: str
    border_bottom_left_radius: str
    border_bottom_right_radius: str
    border_color: str
    border_top_color: str
    border_right_color: str
    border_bottom_color: str
    border_left_color: str
    border_width: str
    border_top_width: str
    border_right_width: str
    border_bottom_width: str
    border_left_width: str
    border_style: str
    border_top_style: str
    border_right_style: str
    border_bottom_style: str
    border_left_style: str
    border_image: str
    border_collapse: str
    border_spacing: str
    outline: str
    outline_color: str
    outline_style: str
    outline_width: str
    outline_offset: str

    # ── Sombra e efeitos
    box_shadow: str
    opacity: str
    filter: str
    backdrop_filter: str
    mix_blend_mode: str
    isolation: str

    # ── Transformação
    transform: str
    transform_origin: str
    transform_style: str
    perspective: str
    perspective_origin: str
    backface_visibility: str

    # ── Transição e animação
    transition: str
    transition_property: str
    transition_duration: str
    transition_timing_function: str
    transition_delay: str
    animation: str
    animation_name: str
    animation_duration: str
    animation_timing_function: str
    animation_delay: str
    animation_iteration_count: str
    animation_direction: str
    animation_fill_mode: str
    animation_play_state: str

    # ── Interação
    cursor: str
    pointer_events: str
    user_select: str
    touch_action: str
    scroll_behavior: str
    scroll_snap_type: str
    scroll_snap_align: str
    resize: str
    appearance: str
    caret_color: str

    # ── Tabela
    table_layout: str
    caption_side: str
    empty_cells: str

    # ── Lista
    list_style: str
    list_style_type: str
    list_style_position: str
    list_style_image: str

    # ── Coluna
    columns: str
    column_count: str
    column_width: str
    column_gap: str
    column_rule: str
    column_rule_color: str
    column_rule_style: str
    column_rule_width: str
    column_span: str
    column_fill: str

    # ── SVG
    fill: str
    fill_opacity: str
    stroke: str
    stroke_width: str
    stroke_opacity: str
    stroke_dasharray: str
    stroke_dashoffset: str
    stroke_linecap: str
    stroke_linejoin: str

    # ── Misc
    content: str
    counter_reset: str
    counter_increment: str
    quotes: str
    object_fit: str
    object_position: str
    will_change: str
    contain: str
    container: str
    container_type: str
    container_name: str
    print_color_adjust: str
    forced_color_adjust: str
    color_scheme: str
    accent_color: str
    inset: str
    inset_block: str
    inset_inline: str