"""
tupyx.ui.events.event
---------------------
Registro global de eventos Python ↔ browser.

Quando você escreve `.on_click(minha_funcao)`, o tupyx:
1. Gera uma URL única como `/event/minha_funcao_a1b2c3d4`
2. Armazena `minha_funcao` nessa URL no dicionário `events`
3. Coloca um atributo `onclick="fetch('/event/...')"` no HTML

Quando o usuário clica, o browser faz o fetch. O servidor vê a URL,
encontra a função em `events`, executa, e re-renderiza a página.

Estabilidade de eventos entre renders:
    A cada render, as funções são re-criadas (closures novas).
    Para não gerar URLs novas a cada render (o que quebraria o JS),
    o sistema detecta se já existe um evento com a mesma origem
    (mesmo arquivo + linha + nome) e reutiliza a URL existente,
    apenas atualizando o ponteiro da função para capturar o estado atual.
"""

import uuid
import inspect
import re
from typing import Callable

# Dicionário global: "/event/nome_uuid" → função Python
events = {}


def add_event(func: Callable) -> str:
    """
    Registra `func` como handler de evento e retorna o path da URL.

    Se a função já foi registrada antes (mesmo arquivo/linha), reutiliza
    o path existente e atualiza o ponteiro da função (para pegar a closure
    mais recente com os valores atuais dos reativos).

    Retorna o path no formato `/event/nome_uuid`.
    """

    # Se a função já tem um path registrado, reutiliza diretamente
    if hasattr(func, "__event_path__"):
        return func.__event_path__

    # Gera uma chave estável baseada em onde a função foi definida no código
    # (arquivo:linha:nome) — não depende de identidade de objeto, persiste entre renders
    try:
        frame = inspect.stack()[2]
        stable_key = f"{frame.filename}:{frame.lineno}:{func.__name__}"
    except Exception:
        stable_key = None

    # Verifica se já existe um evento com esta chave estável
    if stable_key:
        for path, registered_func in events.items():
            if getattr(registered_func, "__stable_key__", None) == stable_key:
                # Atualiza para a closure mais recente (valores dos reativos atualizados)
                events[path] = func
                func.__event_path__ = path
                return path

    # Novo evento: gera um path único e salva no registro
    # re.sub garante que o nome da função seja URL-safe (ex: <lambda> → _lambda_)
    name = re.sub(r"[^\w-]", "_", func.__name__)
    uid  = str(uuid.uuid4())
    path = f"/event/{name}_{uid}"

    func.__stable_key__  = stable_key
    func.__event_path__  = path
    events[path] = func

    return path
