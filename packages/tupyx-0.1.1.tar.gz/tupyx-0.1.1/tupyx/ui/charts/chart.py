"""
tupyx.ui.charts.chart
---------------------
Classe base `Chart` — herdada por todos os gráficos do tupyx.

Fornece:
- Paleta de cores padrão e paleta de séries
- Sistema de tamanho (canvas interno SVG + CSS externo)
- Helpers para construir SVG: _make_svg, _wrap_svg, _make_tooltip
- Header (título + subtítulo) e legenda de séries
- Card externo com borda e border-radius
- Método `.sx()` estendido com flags de gráfico (hide_tooltip, hide_legend, etc.)
- `_resolve()` — converte MeasureCard / callable / DataFrame / Series para Python puro
- `_esc()` — escapa strings antes de inserir em innerHTML de tooltips (segurança XSS)

Você não usa `Chart` diretamente. Use os subtipos:
    BarChart, LineChart, AreaChart, ScatterChart,
    HorizontalBarChart, DonutChart, PieChart, TableChart
"""

from tupyx.ui.html.tag import Tag
from tupyx.ui.html.tags.tags import Div
import uuid
import re
import html as _html


# ── Paleta visual padrão ──────────────────────────────────────────────────────

CHART_PALETTE = {
    "bg":      "#ffffff",   # fundo do card
    "surface": "#f0f7ff",   # fundo de destaque (hover de linha, etc.)
    "border":  "#dbeafe",   # bordas e grid
    "blue":    "#2563eb",   # cor principal
    "yellow":  "#facc15",   # cor de destaque
    "text":    "#0f172a",   # texto principal
    "muted":   "#64748b",   # texto secundário
    "muted2":  "#94a3b8",   # texto terciário (labels de eixo)
}

# Cores sequenciais para múltiplas séries
SERIES_COLORS = [
    "#2563eb",  # azul
    "#facc15",  # amarelo
    "#16a34a",  # verde
    "#f97316",  # laranja
    "#7c3aed",  # roxo
    "#dc2626",  # vermelho
]

# Tamanho padrão do canvas SVG interno (em pixels lógicos do viewBox)
DEFAULT_CANVAS_W = 500
DEFAULT_CANVAS_H = 260


def _parse_size(value, default: int) -> tuple[int, str | None]:
    """
    Interpreta um valor de tamanho e retorna (tamanho_canvas_int, css_string).

    O `tamanho_canvas_int` é usado nas coordenadas internas do SVG (viewBox).
    O `css_string` é o valor CSS aplicado ao container externo.

    Exemplos:
        "100%"  → (500, "100%")    # canvas default, CSS relativo
        "600px" → (600, "600px")   # canvas e CSS em px
        "50vw"  → (500, "50vw")    # canvas default, CSS viewport
        600     → (600, "600px")   # número puro tratado como px
        None    → (500, None)      # usa o default, sem CSS explícito
    """
    if value is None:
        return default, None

    s = str(value).strip()

    # Número puro → px
    if re.fullmatch(r"\d+(\.\d+)?", s):
        n = int(float(s))
        return n, f"{n}px"

    # Termina em "px"
    m = re.fullmatch(r"(\d+(?:\.\d+)?)px", s)
    if m:
        n = int(float(m.group(1)))
        return n, f"{n}px"

    # Qualquer outra unidade CSS (%, vw, vh, rem…) — canvas usa o default
    return default, s


class Chart(Tag):
    """
    Classe base para todos os gráficos do tupyx.

    Herda de Tag para poder ser inserida no layout como qualquer componente.
    Subclasses devem implementar o método `render()`.

    Opções comuns via `.sx()`:
        .sx(width="100%")          # largura relativa
        .sx(width="600px")         # largura fixa
        .sx(height="300px")        # altura
        .sx(hide_tooltip=True)     # desativa tooltip
        .sx(hide_legend=True)      # desativa legenda
        .sx(legend_position="right") # posição: "top", "bottom", "left", "right"
        .sx(legend_align="start")  # alinhamento: "start", "center", "end"
    """

    def __init__(self):
        super().__init__("div")

        self.styles  = {}
        self.palette = dict(CHART_PALETTE)

        # ID único para escopar CSS e IDs de elementos SVG deste gráfico
        self._uid = f"tupyx-{uuid.uuid4().hex[:8]}"

        # Tamanho do canvas SVG interno (coordenadas) e CSS externo
        self._canvas_w: int      = DEFAULT_CANVAS_W
        self._canvas_h: int      = DEFAULT_CANVAS_H
        self._css_w:    str|None = None
        self._css_h:    str|None = None

        # Configurações de exibição
        self._show_tooltip    = True
        self._show_legend     = True
        self._legend_position = "bottom"
        self._legend_align    = "center"

    # ── Tamanho ───────────────────────────────────────────────────────────────

    def _set_size(self, key: str, value):
        """Atualiza as dimensões do canvas e do CSS a partir de um valor de tamanho."""
        if key == "width":
            self._canvas_w, self._css_w = _parse_size(value, DEFAULT_CANVAS_W)
        elif key == "height":
            self._canvas_h, self._css_h = _parse_size(value, DEFAULT_CANVAS_H)

    def _get_px(self, key: str, default: int) -> int:
        """Retorna a dimensão em pixels inteiros para uso nos cálculos do SVG."""
        if key == "width":
            return self._canvas_w
        if key == "height":
            return self._canvas_h
        raw = self.styles.get(key, str(default))
        return int(str(raw).replace("px", "").split(".")[0])

    # ── Cores ─────────────────────────────────────────────────────────────────

    def _color(self, key: str) -> str:
        """Retorna uma cor da paleta por nome (ex: "border", "text", "muted")."""
        return self.palette.get(key, CHART_PALETTE.get(key, "#000"))

    def _series_color(self, idx: int) -> str:
        """Retorna a cor da série pelo índice (cicla se tiver mais séries que cores)."""
        return SERIES_COLORS[idx % len(SERIES_COLORS)]

    def _el_id(self, name: str) -> str:
        """Gera um ID único para um elemento interno do gráfico (ex: tooltip, vline)."""
        return f"{self._uid}-{name}"

    @property
    def _font(self) -> str:
        """Stack de fontes padrão usada em todos os textos do gráfico."""
        return "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif"

    # ── SVG helpers ───────────────────────────────────────────────────────────

    def _make_svg(self, canvas_w: int, canvas_h: int) -> Tag:
        """
        Cria o elemento <svg> com viewBox e preserveAspectRatio configurados.

        O SVG usa width/height="100%" para se adaptar ao container CSS,
        mas mantém as coordenadas internas de canvas_w × canvas_h.
        """
        svg = Tag("svg")
        svg.attrs["viewBox"]             = f"0 0 {canvas_w} {canvas_h}"
        svg.attrs["preserveAspectRatio"] = "xMidYMid meet"
        svg.attrs["width"]               = "100%"
        svg.attrs["height"]              = "100%"
        return svg

    def _wrap_svg(self, svg: Tag, tooltip: Tag | None = None) -> Tag:
        """
        Envolve o SVG em um div com dimensões CSS corretas e posição relativa.
        O `position: relative` é necessário para o tooltip funcionar.
        """
        css_w = self._css_w or f"{self._canvas_w}px"
        css_h = self._css_h or f"{self._canvas_h}px"
        children = [svg] + ([tooltip] if tooltip else [])
        return Div(*children).sx(position="relative", width=css_w, height=css_h)

    def _make_tooltip(self, tooltip_id: str) -> Tag:
        """
        Cria o elemento de tooltip flutuante.
        Fica oculto por padrão (display:none) e é mostrado pelo JS do hover.
        """
        t = Div().sx(
            position="absolute",
            background=self._color("text"),
            color="#ffffff",
            padding="6px 10px",
            font_size="11px",
            border_radius="8px",
            display="none",
            pointer_events="none",   # não interfere nos eventos do mouse
            white_space="nowrap",
            line_height="1.7",
            box_shadow="0 2px 8px rgba(0,0,0,0.15)",
        )
        t.attrs["id"] = tooltip_id
        return t

    def _make_legend(self, labels: list[str]) -> Tag | None:
        """
        Cria a legenda de séries com bolinhas coloridas e nomes.
        Retorna None se a legenda estiver desativada ou sem labels.
        """
        if not self._show_legend or not labels:
            return None

        align_map = {"start": "flex-start", "center": "center", "end": "flex-end"}
        direction = "column" if self._legend_position in ("left", "right") else "row"

        wrapper = Div().sx(
            display="flex",
            flex_direction=direction,
            justify_content=align_map.get(self._legend_align, "center"),
            align_items="center",
            gap="16px",
            padding="8px 0 2px",
        )

        for idx, label in enumerate(labels):
            color = self._series_color(idx)
            dot   = Div().sx(
                width="8px", height="8px", border_radius="50%",
                background=color, flex_shrink="0",
            )
            text = Tag("span")
            text.add(label)
            text.sx(font_size="11px", color=self._color("muted"))
            wrapper.add(Div(dot, text).sx(display="flex", align_items="center", gap="6px"))

        return wrapper

    def _make_header(self, title, subtitle) -> Tag | None:
        """
        Cria o header do gráfico com título e subtítulo.
        Retorna None se ambos forem vazios/None.
        """
        if not title and not subtitle:
            return None
        children = []
        if title:
            t = Tag("p")
            t.add(title)
            t.sx(margin="0 0 2px", font_size="14px", font_weight="600",
                 color=self._color("text"), font_family=self._font)
            children.append(t)
        if subtitle:
            s = Tag("p")
            s.add(subtitle)
            s.sx(margin="0", font_size="12px", color=self._color("muted2"),
                 font_family=self._font)
            children.append(s)
        return Div(*children).sx(margin_bottom="20px")

    def _make_card(self, *children) -> Tag:
        """
        Card externo do gráfico: borda, border-radius, padding e fundo branco.
        A largura usa _css_w se definido, senão canvas + padding interno (28px cada lado).
        """
        css_w = self._css_w or f"{self._canvas_w + 56}px"

        return Div(*children).sx(
            background=self._color("bg"),
            border=f"1px solid {self._color('border')}",
            border_radius="16px",
            padding="24px 28px 20px",
            display="block",
            font_family=self._font,
            width=css_w,
            box_sizing="border-box",
        )

    # ── Tooltip JS ────────────────────────────────────────────────────────────

    def _js_tooltip_move(self, tooltip_id: str) -> str:
        """
        Gera o JS inline que reposiciona o tooltip conforme o mouse se move.
        O tooltip segue o cursor com um offset de 12px horizontal e 38px vertical.
        """
        return (
            f"var t=document.getElementById('{tooltip_id}');"
            f"var w=t.parentElement.getBoundingClientRect();"
            f"t.style.left=(event.clientX-w.left+12)+'px';"
            f"t.style.top=(event.clientY-w.top-38)+'px';"
        )

    # ── sx estendido ──────────────────────────────────────────────────────────

    def sx(self, **styles):
        """
        Aplica estilos e configurações ao gráfico.

        Aceita todas as propriedades CSS normais do `.sx()` base, mais:
            hide_tooltip    — desativa o tooltip ao passar o mouse
            show_tooltip    — ativa o tooltip (padrão)
            hide_legend     — esconde a legenda de séries
            show_legend     — mostra a legenda (padrão)
            legend_position — "top" | "bottom" | "left" | "right"
            legend_align    — "start" | "center" | "end"
            width           — largura: "100%", "600px", 600, "50vw"…
            height          — altura: "300px", 300…
        """
        _flag_map = {
            "hide_tooltip": ("_show_tooltip", False),
            "show_tooltip": ("_show_tooltip", True),
            "hide_legend":  ("_show_legend",  False),
            "show_legend":  ("_show_legend",  True),
        }
        for k, v in styles.items():
            if k in _flag_map:
                attr, val = _flag_map[k]
                setattr(self, attr, val)
            elif k == "legend_position":
                self._legend_position = v
            elif k == "legend_align":
                self._legend_align = v
            elif k in ("width", "height"):
                self._set_size(k, v)
            else:
                self.styles[k] = v
        return self

    # ── Helpers de segurança e dados ──────────────────────────────────────────

    @staticmethod
    def _esc(s) -> str:
        """
        Escapa caracteres HTML especiais em `s` para uso seguro em innerHTML.

        Protege contra XSS quando labels ou valores do usuário são inseridos
        no tooltip via JavaScript.

        Exemplo: _esc('<script>') → '&lt;script&gt;'
        """
        return _html.escape(str(s))

    @staticmethod
    def _resolve(value):
        """
        Converte diferentes tipos de dados para listas Python puras.

        Aceita:
        - MeasureCard / callable   → chama a função e retorna o resultado
        - pandas DataFrame         → converte para lista de dicts
        - pandas Series            → converte para lista de valores
        - qualquer outro           → retorna como está

        Isso permite passar medidas reativas diretamente para gráficos:
            BarChart(y=minha_medida)   # minha_medida é um MeasureCard
            BarChart(y=meu_dataframe)  # pandas DataFrame
        """
        if callable(value):
            value = value()

        t = type(value).__name__

        if t == "DataFrame":
            return value.to_dict("records")

        if t == "Series":
            return value.tolist()

        return value

    def render(self) -> str:
        raise NotImplementedError(
            f"{type(self).__name__} precisa implementar o método render()"
        )
