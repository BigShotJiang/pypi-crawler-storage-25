from tupyx.ui.charts.chart import Chart
from tupyx.ui.html.tag import safe
import math


class DonutChart(Chart):

    def __init__(self, data, labels=None, title=None, subtitle=None):
        super().__init__()

        if data is None:
            raise ValueError("data é obrigatório")

        data   = self._resolve(data) or []
        labels = self._resolve(labels)

        self.data     = data
        self.labels   = labels or [f"Item {i+1}" for i in range(len(data))]
        self.title    = title
        self.subtitle = subtitle

        self._inner_radius = 0.55
        self._show_label   = False

    def sx(self, **styles):
        remaining = {}
        for k, v in styles.items():
            if k == "inner_radius":
                self._inner_radius = float(v)
            elif k == "show_label":
                self._show_label = True
            else:
                remaining[k] = v

        super().sx(**remaining)
        return self

    def render(self):
        if not self.data:
            from tupyx.ui.html.tags.tags import Div
            parts = []
            if (h := self._make_header(self.title, self.subtitle)):
                parts.append(h)
            parts.append(
                Div("Sem dados disponíveis").sx(
                    text_align="center", color="#94a3b8",
                    font_size="13px", padding="40px 0",
                )
            )
            return self._make_card(*parts).render()

        cw, ch = self._canvas_w, self._canvas_h
        cx, cy = cw / 2, ch / 2
        r = min(cw, ch) / 2 - 10
        r_inner = r * self._inner_radius

        total = sum(self.data) or 1

        tooltip_id = self._el_id("tooltip")

        paths = ""
        hover_paths = ""

        start_angle = 0

        for i, val in enumerate(self.data):
            angle = (val / total) * 360
            end_angle = start_angle + angle

            def polar(deg, radius):
                return (
                    cx + radius * math.cos(math.radians(deg)),
                    cy + radius * math.sin(math.radians(deg))
                )

            x1, y1 = polar(start_angle, r)
            x2, y2 = polar(end_angle, r)
            x3, y3 = polar(end_angle, r_inner)
            x4, y4 = polar(start_angle, r_inner)

            large_arc = 1 if angle > 180 else 0
            color = self._series_color(i)

            path = f"""
            M {x1},{y1}
            A {r},{r} 0 {large_arc},1 {x2},{y2}
            L {x3},{y3}
            A {r_inner},{r_inner} 0 {large_arc},0 {x4},{y4}
            Z
            """

            label = self.labels[i]
            tip_html = f"<b>{self._esc(label)}</b>: {self._esc(val)}"

            show = ""
            hide = ""
            move = ""

            if self._show_tooltip:
                show = (
                    f"var t=document.getElementById('{tooltip_id}');"
                    f"t.innerHTML=`{tip_html}`;t.style.display='block';"
                )
                hide = f"document.getElementById('{tooltip_id}').style.display='none';"
                move = self._js_tooltip_move(tooltip_id)

            paths += f'<path d="{path}" fill="{color}"/>'

            hover_paths += (
                f'<path d="{path}" fill="transparent" '
                f'onmouseenter="{show}" '
                f'onmouseleave="{hide}" '
                f'onmousemove="{move}" />'
            )

            start_angle = end_angle

        svg = self._make_svg(cw, ch)
        svg.attrs["onmouseleave"] = (
            f"document.getElementById('{tooltip_id}').style.display='none';"
        )

        svg.add(safe(paths), safe(hover_paths))

        parts = []

        if (h := self._make_header(self.title, self.subtitle)):
            parts.append(h)

        parts.append(self._wrap_svg(svg, self._make_tooltip(tooltip_id)))

        if self.labels:
            leg = self._make_legend(self.labels)
            leg.sx(margin_top="14px")
            parts.append(leg)

        return self._make_card(*parts).render()