from tupyx.ui.charts.donut_chart import DonutChart


class PieChart(DonutChart):

    def __init__(self, data, labels=None, title=None, subtitle=None):
        super().__init__(data, labels, title, subtitle)
        self._inner_radius = 0