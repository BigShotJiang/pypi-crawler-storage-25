from tupyx.ui.charts.chart import Chart
from tupyx.ui.html.tag import safe


class HorizontalBarChart(Chart):

    def __init__(self, y, labels=None, title=None, subtitle=None):
        super().__init__()

        if y is None:
            raise ValueError("y é obrigatório")

        y      = self._resolve(y) or []
        labels = self._resolve(labels)

        self.series   = [y] if (not y or not isinstance(y[0], (list, tuple))) else y
        self.labels   = labels or [str(i) for i in range(len(self.series[0]))]
        self.title    = title
        self.subtitle = subtitle

        self._show_label = False
        self._show_grid  = True 

    def sx(self, **styles):
        remaining = {}

        for k, v in styles.items():
            if k == "show_label":
                self._show_label = True
            elif k == "show_grid":
                self._show_grid = bool(v)
            else:
                remaining[k] = v

        super().sx(**remaining)
        return self

    def render(self):
        all_y = [v for s in self.series for v in s]
        if not all_y:
            from tupyx.ui.html.tags.tags import Div
            parts = []
            if (h := self._make_header(self.title, self.subtitle)):
                parts.append(h)
            parts.append(
                Div("Sem dados disponíveis").sx(
                    text_align="center", color="#94a3b8",
                    font_size="13px", padding="40px 0",
                )
            )
            return self._make_card(*parts).render()

        cw, ch = self._canvas_w, self._canvas_h

        pt, pr, pb, pl = 20, 40, 30, 80
        iW = cw - pl - pr
        iH = ch - pt - pb

        max_val = max(all_y) or 1

        tooltip_id = self._el_id("tooltip")

        bars = ""
        hover = ""
        labels_svg = ""
        grid = ""

        step_y = iH / len(self.series[0])

        # =========================
        # GRIDLINES (EIXO X)
        # =========================
        if self._show_grid:
            steps = 5
            for i in range(steps + 1):
                x = pl + (i / steps) * iW
                val = (i / steps) * max_val

                grid += (
                    f'<line x1="{x}" y1="{pt}" x2="{x}" y2="{pt+iH}" '
                    f'stroke="#e5e7eb" stroke-width="1"/>'
                )

                grid += (
                    f'<text x="{x}" y="{pt+iH+14}" '
                    f'text-anchor="middle" font-size="10" fill="#6b7280">'
                    f'{round(val, 2)}</text>'
                )

        # =========================
        # BARRAS
        # =========================
        for i, val in enumerate(self.series[0]):
            y = pt + i * step_y
            h = step_y * 0.6
            w = (val / max_val) * iW

            color = self._series_color(i)

            bars += (
                f'<rect x="{pl}" y="{y}" width="{w}" height="{h}" '
                f'fill="{color}" rx="4"/>'
            )

            labels_svg += (
                f'<text x="{pl-6}" y="{y + h/2}" '
                f'text-anchor="end" dominant-baseline="middle" '
                f'font-size="10" fill="#374151">{self.labels[i]}</text>'
            )

            # =========================
            # TOOLTIP
            # =========================
            tip_html = f"{self._esc(self.labels[i])}: <b>{self._esc(val)}</b>"

            show = ""
            hide = ""
            move = ""

            if self._show_tooltip:
                show = (
                    f"var t=document.getElementById('{tooltip_id}');"
                    f"t.innerHTML=`{tip_html}`;t.style.display='block';"
                )
                hide = f"document.getElementById('{tooltip_id}').style.display='none';"
                move = self._js_tooltip_move(tooltip_id)

            hover += (
                f'<rect x="{pl}" y="{y}" width="{iW}" height="{step_y}" '
                f'fill="transparent" '
                f'onmouseenter="{show}" '
                f'onmouseleave="{hide}" '
                f'onmousemove="{move}"/>'
            )

        svg = self._make_svg(cw, ch)
        svg.attrs["onmouseleave"] = (
            f"document.getElementById('{tooltip_id}').style.display='none';"
        )

        svg.add(safe(grid), safe(bars), safe(labels_svg), safe(hover))

        parts = []

        if (h := self._make_header(self.title, self.subtitle)):
            parts.append(h)

        parts.append(self._wrap_svg(svg, self._make_tooltip(tooltip_id)))

        return self._make_card(*parts).render()