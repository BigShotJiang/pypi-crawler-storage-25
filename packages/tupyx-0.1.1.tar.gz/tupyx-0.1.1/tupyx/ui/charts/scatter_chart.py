from tupyx.ui.html.tag import safe
from tupyx.ui.charts.chart import Chart


class ScatterChart(Chart):
    """
    Gráfico de dispersão (scatter) e bolhas (bubble).

    Uso scatter — lista de (x, y):
        ScatterChart([(1, 2), (3, 4), (5, 1)])

    Múltiplas séries:
        ScatterChart([[(1,2),(3,4)], [(2,5),(4,2)]], legends=["A","B"])

    Bolhas — lista de (x, y, tamanho):
        ScatterChart([(1, 2, 10), (3, 4, 30), (5, 1, 20)])
    """

    def __init__(self, data, legends=None, title=None, subtitle=None):
        super().__init__()

        if data is None:
            raise ValueError("data é obrigatório")

        data = self._resolve(data)

        # normaliza para lista de séries
        # cada ponto pode ser (x, y) ou (x, y, size)
        if isinstance(data[0], (list, tuple)) and isinstance(data[0][0], (list, tuple)):
            self.series = data
        else:
            self.series = [data]

        self.legends  = legends or []
        self.title    = title
        self.subtitle = subtitle

        self._show_x      = True
        self._show_y      = True
        self._show_grid_x = True
        self._show_grid_y = True
        self._point_r     = 5      # raio base dos pontos
        self._bubble_max  = 28     # raio máximo para bolhas (quando há size)
        self._show_labels = False

    def sx(self, **styles):
        _flags = {
            "hide_x":      ("_show_x",      False),
            "hide_y":      ("_show_y",      False),
            "hide_grid_x": ("_show_grid_x", False),
            "hide_grid_y": ("_show_grid_y", False),
            "show_labels": ("_show_labels", True),
        }
        remaining = {}
        for k, v in styles.items():
            if k in _flags and v:
                attr, val = _flags[k]
                setattr(self, attr, val)
            elif k == "point_r":
                self._point_r = int(v)
            elif k == "bubble_max":
                self._bubble_max = int(v)
            else:
                remaining[k] = v
        super().sx(**remaining)
        return self

    def _is_bubble(self):
        """Verdadeiro se algum ponto tem 3 componentes (x, y, size)."""
        for serie in self.series:
            for pt in serie:
                if len(pt) >= 3:
                    return True
        return False

    def render(self) -> str:
        cw = self._canvas_w
        ch = self._canvas_h

        pt, pr, pb, pl = 20, 20, 36, 44
        iW = cw - pl - pr
        iH = ch - pt - pb

        # ── limites dos eixos ─────────────────────────────────────────────────
        all_x = [p[0] for s in self.series for p in s]
        all_y = [p[1] for s in self.series for p in s]

        x_min, x_max = min(all_x), max(all_x)
        y_min, y_max = min(all_y), max(all_y)

        x_span = (x_max - x_min) or 1
        y_span = (y_max - y_min) or 1

        x_pad  = x_span * 0.10
        y_pad  = y_span * 0.15

        x_bot, x_top = x_min - x_pad, x_max + x_pad
        y_bot, y_top = y_min - y_pad, y_max + y_pad

        def nx(v): return pl + (v - x_bot) / (x_top - x_bot) * iW
        def ny(v): return pt + (1 - (v - y_bot) / (y_top - y_bot)) * iH

        # raio para bolhas
        is_bubble = self._is_bubble()
        if is_bubble:
            all_sizes = [p[2] for s in self.series for p in s if len(p) >= 3]
            max_size  = max(all_sizes) if all_sizes else 1

        tooltip_id = self._el_id("tooltip")
        border     = self._color("border")
        muted2     = self._color("muted2")
        font       = self._font

        # ── grid Y ────────────────────────────────────────────────────────────
        grid_y = y_labels = ""
        for i in range(5):
            val   = y_min + (y_max - y_min) * i / 4
            y_pos = ny(val)

            if self._show_grid_y:
                grid_y += (
                    f'<line x1="{pl}" y1="{y_pos:.1f}"'
                    f' x2="{cw - pr}" y2="{y_pos:.1f}"'
                    f' stroke="{border}" stroke-width="1"/>'
                )
            if self._show_y:
                label = str(int(val)) if val == int(val) else f"{val:.1f}"
                y_labels += (
                    f'<text x="{pl - 6}" y="{y_pos:.1f}"'
                    f' font-size="10" fill="{muted2}" font-family="{font}"'
                    f' text-anchor="end" dominant-baseline="middle">{label}</text>'
                )

        # ── grid X + labels X ─────────────────────────────────────────────────
        grid_x = x_labels = ""
        for i in range(5):
            val   = x_min + (x_max - x_min) * i / 4
            x_pos = nx(val)

            if self._show_grid_x:
                grid_x += (
                    f'<line x1="{x_pos:.1f}" y1="{pt}"'
                    f' x2="{x_pos:.1f}" y2="{ch - pb}"'
                    f' stroke="{border}" stroke-width="1"/>'
                )
            if self._show_x:
                label = str(int(val)) if val == int(val) else f"{val:.1f}"
                x_labels += (
                    f'<text x="{x_pos:.1f}" y="{ch - 8}"'
                    f' font-size="10" fill="{muted2}" font-family="{font}"'
                    f' text-anchor="middle">{label}</text>'
                )

        # ── pontos ────────────────────────────────────────────────────────────
        points_svg = ""

        for s_idx, serie in enumerate(self.series):
            color = self._series_color(s_idx)
            label_s = self.legends[s_idx] if s_idx < len(self.legends) else f"série {s_idx+1}"

            for pt_data in serie:
                px_val, py_val = pt_data[0], pt_data[1]
                px = nx(px_val)
                py = ny(py_val)

                if is_bubble and len(pt_data) >= 3:
                    size = pt_data[2]
                    r    = max(4, int((size / max_size) * self._bubble_max))
                else:
                    r = self._point_r

                tip_html = (
                    f"<div style='display:flex;align-items:center;gap:6px'>"
                    f"<span style='width:8px;height:8px;border-radius:50%;background:{color}'></span>"
                    f"<span><b>{self._esc(label_s)}</b></span></div>"
                    f"<div style='font-size:10px;color:#94a3b8;padding-top:2px'>"
                    f"x: {self._esc(px_val)} &nbsp; y: {self._esc(py_val)}"
                    + (f" &nbsp; Ø: {self._esc(pt_data[2])}" if is_bubble and len(pt_data) >= 3 else "")
                    + "</div>"
                )

                show = (
                    f"var t=document.getElementById('{tooltip_id}');"
                    f"t.innerHTML=`{tip_html}`;t.style.display='block';"
                )
                hide = f"document.getElementById('{tooltip_id}').style.display='none';"
                move = self._js_tooltip_move(tooltip_id)

                points_svg += (
                    f'<circle cx="{px:.1f}" cy="{py:.1f}" r="{r}"'
                    f' fill="{color}" fill-opacity="0.85"'
                    f' stroke="white" stroke-width="1.5"'
                    f' style="cursor:default"'
                    f' onmouseenter="{show}" onmouseleave="{hide}" onmousemove="{move}"/>'
                )

        # ── SVG ───────────────────────────────────────────────────────────────
        svg = self._make_svg(cw, ch)
        svg.add(
            safe(grid_y), safe(grid_x),
            safe(y_labels), safe(x_labels),
            safe(points_svg),
        )

        legend_labels = self.legends or (
            [f"série {i+1}" for i in range(len(self.series))]
            if len(self.series) > 1 else []
        )
        legend = self._make_legend(legend_labels)

        parts = []
        header = self._make_header(self.title, self.subtitle)
        if header: parts.append(header)
        parts.append(self._wrap_svg(svg, self._make_tooltip(tooltip_id)))
        if legend:
            legend.sx(margin_top="14px")
            parts.append(legend)

        return self._make_card(*parts).render()