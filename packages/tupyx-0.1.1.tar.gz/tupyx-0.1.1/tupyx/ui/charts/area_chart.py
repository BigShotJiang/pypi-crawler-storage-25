from tupyx.ui.html.tag import safe
from tupyx.ui.charts.chart import Chart


class AreaChart(Chart):
    """
    Grafico de area — identico ao LineChart mas com fill_area=True por padrao
    e fill_opacity configuravel. Suporta multiplas series com areas sobrepostas.

    Uso:
        AreaChart([[10,20,30],[15,25,20]], x=["Jan","Fev","Mar"],
                  legends=["A","B"], title="Comparativo")
        .sx(width="500px", opacity="0.15")
    """

    def __init__(self, y, x=None, legends=None, title=None, subtitle=None):
        super().__init__()

        if y is None:
            raise ValueError("y e obrigatorio")

        y = self._resolve(y) or []
        x = self._resolve(x)

        self.series   = [y] if (not y or not isinstance(y[0], (list, tuple))) else y
        self.x        = x if x is not None else list(range(len(self.series[0])))
        self.legends  = legends or []
        self.title    = title
        self.subtitle = subtitle

        self.is_multiline = len(self.series) > 1

        self._show_x         = True
        self._show_y         = True
        self._show_crosshair = True
        self._show_points    = True
        self._show_grid_y    = True
        self._show_grid_x    = False
        self._show_label     = False
        self._label_offset   = 10
        self._fill_opacity   = 0.10   # opacidade da area

    def sx(self, **styles):
        _flags = {
            "hide_x":        ("_show_x",         False),
            "hide_y":        ("_show_y",         False),
            "hide_crosshair":("_show_crosshair", False),
            "hide_points":   ("_show_points",    False),
            "hide_grid_y":   ("_show_grid_y",    False),
            "show_grid_x":   ("_show_grid_x",    True),
            "show_label":    ("_show_label",     True),
        }
        remaining = {}
        for k, v in styles.items():
            if k in _flags and v:
                setattr(self, _flags[k][0], _flags[k][1])
            elif k == "fill_opacity":
                self._fill_opacity = float(v)
            elif k == "label_offset":
                self._label_offset = v
            else:
                remaining[k] = v
        super().sx(**remaining)
        return self

    def render(self):
        cw = self._canvas_w
        ch = self._canvas_h
        pt, pr, pb, pl = 16, 20, 32, 40
        iW = cw - pl - pr
        iH = ch - pt - pb

        all_y   = [v for s in self.series for v in s]
        max_y   = max(all_y)
        min_y   = min(all_y)
        y_span  = (max_y - min_y) or max_y or 1
        y_pad   = y_span * 0.12
        y_top   = max_y + y_pad
        y_bot   = min_y - y_pad
        y_range = (y_top - y_bot) or 1

        def nx(i): return pl + (i / max(len(self.x) - 1, 1)) * iW
        def ny(v): return pt + iH * (1 - (v - y_bot) / y_range)

        tooltip_id = self._el_id("tooltip")
        vline_id   = self._el_id("vline")
        border     = self._color("border")
        muted2     = self._color("muted2")
        font       = self._font

        # grid Y + labels
        grid_y = y_labels = ""
        for i in range(5):
            val   = min_y + (max_y - min_y) * i / 4
            y_pos = ny(val)
            if self._show_grid_y:
                grid_y += (
                    f'<line x1="{pl}" y1="{y_pos:.1f}" x2="{cw-pr}" y2="{y_pos:.1f}"'
                    f' stroke="{border}" stroke-width="1"/>'
                )
            if self._show_y:
                lbl = str(int(val)) if val == int(val) else f"{val:.1f}"
                y_labels += (
                    f'<text x="{pl-6}" y="{y_pos:.1f}" font-size="10" fill="{muted2}"'
                    f' font-family="{font}" text-anchor="end" dominant-baseline="middle">'
                    f'{lbl}</text>'
                )

        # grid X + labels X
        grid_x = x_labels = ""
        for i, val in enumerate(self.x):
            xp = nx(i)
            if self._show_grid_x:
                grid_x += (
                    f'<line x1="{xp:.1f}" y1="{pt}" x2="{xp:.1f}" y2="{ch-pb}"'
                    f' stroke="{border}" stroke-width="1"/>'
                )
            if self._show_x:
                x_labels += (
                    f'<text x="{xp:.1f}" y="{ch-6}" font-size="10" fill="{muted2}"'
                    f' font-family="{font}" text-anchor="middle">{val}</text>'
                )

        # areas + linhas (ordem: areas primeiro, depois linhas, depois pontos)
        areas = lines = circles = ""
        base_y = ch - pb

        # areas desenhadas de tras pra frente (ultima serie fica na frente)
        for idx in range(len(self.series) - 1, -1, -1):
            serie  = self.series[idx]
            color  = self._series_color(idx)
            coords = [(nx(i), ny(yv)) for i, yv in enumerate(serie)]
            pts    = " ".join(f"{x:.1f},{y:.1f}" for x, y in coords)
            fill_pts = (
                pts
                + f" {coords[-1][0]:.1f},{base_y}"
                + f" {coords[0][0]:.1f},{base_y}"
            )
            areas += f'<polygon points="{fill_pts}" fill="{color}" fill-opacity="{self._fill_opacity}"/>'

        # linhas e pontos (frente pra tras para hierarquia visual)
        for idx, serie in enumerate(self.series):
            color  = self._series_color(idx)
            coords = [(nx(i), ny(yv)) for i, yv in enumerate(serie)]
            pts    = " ".join(f"{x:.1f},{y:.1f}" for x, y in coords)
            lines += (
                f'<polyline fill="none" stroke="{color}" stroke-width="2.2"'
                f' stroke-linejoin="round" stroke-linecap="round" points="{pts}"/>'
            )
            if self._show_points:
                for i, (px, py) in enumerate(coords):
                    circles += (
                        f'<circle cx="{px:.1f}" cy="{py:.1f}" r="3.5"'
                        f' fill="{color}" stroke="white" stroke-width="2"/>'
                    )
                    if self._show_label:
                        yt = py - self._label_offset
                        circles += (
                            f'<text x="{px:.1f}" y="{yt:.1f}" font-size="10"'
                            f' text-anchor="middle" fill="{color}" font-family="{font}">'
                            f'{serie[i]}</text>'
                        )

        # crosshair
        vline = ""
        if self._show_crosshair:
            vline = (
                f'<line id="{vline_id}" x1="0" y1="{pt}" x2="0" y2="{ch-pb}"'
                f' stroke="{muted2}" stroke-width="1" stroke-dasharray="4 3" opacity="0"/>'
            )

        # hover rects
        step_x      = iW / max(len(self.x) - 1, 1)
        hover_rects = ""

        for i in range(len(self.x)):
            px = nx(i)
            tip_html = ""
            for idx, serie in enumerate(self.series):
                color = self._series_color(idx)
                label = self.legends[idx] if idx < len(self.legends) else (
                    f"serie {idx+1}" if self.is_multiline else str(self.x[i])
                )
                tip_html += (
                    f"<div style='display:flex;align-items:center;gap:5px'>"
                    f"<span style='width:7px;height:7px;border-radius:50%;"
                    f"background:{color};display:inline-block'></span>"
                    f"<span>{self._esc(label)}: <b>{self._esc(serie[i])}</b></span></div>"
                )

            show = hide = move = ""
            if self._show_crosshair:
                show += (
                    f"var vl=document.getElementById('{vline_id}');"
                    f"vl.setAttribute('x1','{px:.1f}');vl.setAttribute('x2','{px:.1f}');"
                    f"vl.setAttribute('opacity','1');"
                )
                hide += f"document.getElementById('{vline_id}').setAttribute('opacity','0');"
            if self._show_tooltip:
                show += (
                    f"var t=document.getElementById('{tooltip_id}');"
                    f"t.innerHTML=`{tip_html}`;t.style.display='block';"
                )
                hide += f"document.getElementById('{tooltip_id}').style.display='none';"
                move  = self._js_tooltip_move(tooltip_id)

            rx = (px - step_x / 2) if i > 0 else pl
            hover_rects += (
                f'<rect x="{rx:.1f}" y="{pt}" width="{step_x:.1f}" height="{iH}"'
                f' fill="transparent" onmouseenter="{show}" onmouseleave="{hide}" onmousemove="{move}"/>'
            )

        svg = self._make_svg(cw, ch)
        svg.attrs["onmouseleave"] = (
            f"document.getElementById('{tooltip_id}').style.display='none';"
            f"document.getElementById('{vline_id}').setAttribute('opacity','0');"
        )
        svg.add(
            safe(grid_y), safe(grid_x),
            safe(y_labels), safe(x_labels),
            safe(areas), safe(lines), safe(vline),
            safe(hover_rects), safe(circles),
        )

        legend_labels = self.legends or (
            [f"serie {i+1}" for i in range(len(self.series))] if self.is_multiline else []
        )

        parts = []
        if (h := self._make_header(self.title, self.subtitle)): parts.append(h)
        parts.append(self._wrap_svg(svg, self._make_tooltip(tooltip_id)))
        if (leg := self._make_legend(legend_labels)):
            leg.sx(margin_top="14px"); parts.append(leg)

        return self._make_card(*parts).render()