from tupyx.ui.html.tag import safe
from tupyx.ui.charts.chart import Chart


class LineChart(Chart):

    def __init__(self, y, x=None, legends=None, title=None, subtitle=None):
        super().__init__()

        if y is None:
            raise ValueError("y é obrigatório")

        y = self._resolve(y) or []
        x = self._resolve(x)

        self.series   = [y] if (not y or not isinstance(y[0], (list, tuple))) else y
        self.x        = x if x is not None else list(range(len(self.series[0])))
        self.legends  = legends or []
        self.title    = title
        self.subtitle = subtitle

        self.is_multiline = len(self.series) > 1

        self._show_x                  = True
        self._show_y                  = True
        self._show_crosshair          = True
        self._show_points             = True
        self._show_grid_x             = False
        self._show_grid_y             = True
        self._show_label              = False
        self._label_position          = "top"
        self._label_offset            = 10
        self._crosshair_vertical_only = self.is_multiline
        self._fill_area               = False

    # ── sx ────────────────────────────────────────────────────────────────────

    def sx(self, **styles):
        _flags = {
            "hide_x":                  ("_show_x",                  False),
            "hide_y":                  ("_show_y",                  False),
            "hide_crosshair":          ("_show_crosshair",          False),
            "hide_points":             ("_show_points",             False),
            "hide_grid_x":             ("_show_grid_x",             False),
            "hide_grid_y":             ("_show_grid_y",             False),
            "show_grid_x":             ("_show_grid_x",             True),
            "show_label":              ("_show_label",              True),
            "fill_area":               ("_fill_area",               True),
            "crosshair_vertical_only": ("_crosshair_vertical_only", True),
        }
        remaining = {}
        for k, v in styles.items():
            if k in _flags and v:
                attr, val = _flags[k]
                setattr(self, attr, val)
            elif k == "label_position":
                self._label_position = v
            elif k == "label_offset":
                self._label_offset = v
            else:
                remaining[k] = v
        super().sx(**remaining)
        return self

    # ── render ────────────────────────────────────────────────────────────────

    def render(self) -> str:
        all_y = [v for s in self.series for v in s]
        if not all_y:
            from tupyx.ui.html.tags.tags import Div
            parts = []
            if (h := self._make_header(self.title, self.subtitle)):
                parts.append(h)
            parts.append(
                Div("Sem dados disponíveis").sx(
                    text_align="center", color="#94a3b8",
                    font_size="13px", padding="40px 0",
                )
            )
            return self._make_card(*parts).render()

        cw = self._canvas_w
        ch = self._canvas_h

        pt, pr, pb, pl = 16, 20, 32, 40
        iW = cw - pl - pr
        iH = ch - pt - pb

        max_y = max(all_y)
        min_y = min(all_y)

        # margem de 10% acima e abaixo para os dados não colarem nas bordas
        y_span  = (max_y - min_y) or max_y or 1
        y_pad   = y_span * 0.10
        y_top   = max_y + y_pad
        y_bot   = min_y - y_pad
        y_range = (y_top - y_bot) or 1

        def nx(i): return pl + (i / max(len(self.x) - 1, 1)) * iW
        def ny(v): return pt + iH * (1 - (v - y_bot) / y_range)

        tooltip_id = self._el_id("tooltip")
        vline_id   = self._el_id("vline")
        border     = self._color("border")
        muted2     = self._color("muted2")
        font       = self._font

        # ── grid Y + labels Y ─────────────────────────────────────────────────
        grid_y = y_labels = ""
        for i in range(5):
            val   = min_y + (max_y - min_y) * i / 4
            y_pos = ny(val)

            if self._show_grid_y:
                grid_y += (
                    f'<line x1="{pl}" y1="{y_pos:.1f}"'
                    f' x2="{cw - pr}" y2="{y_pos:.1f}"'
                    f' stroke="{border}" stroke-width="1"/>'
                )
            if self._show_y:
                label = str(int(val)) if val == int(val) else f"{val:.1f}"
                y_labels += (
                    f'<text x="{pl - 6}" y="{y_pos:.1f}"'
                    f' font-size="10" fill="{muted2}" font-family="{font}"'
                    f' text-anchor="end" dominant-baseline="middle">'
                    f'{label}</text>'
                )

        # ── grid X + labels X ─────────────────────────────────────────────────
        grid_x = x_labels = ""
        for i, val in enumerate(self.x):
            x_pos = nx(i)
            if self._show_grid_x:
                grid_x += (
                    f'<line x1="{x_pos:.1f}" y1="{pt}"'
                    f' x2="{x_pos:.1f}" y2="{ch - pb}"'
                    f' stroke="{border}" stroke-width="1"/>'
                )
            if self._show_x:
                x_labels += (
                    f'<text x="{x_pos:.1f}" y="{ch - 6}"'
                    f' font-size="10" fill="{muted2}" font-family="{font}"'
                    f' text-anchor="middle">{val}</text>'
                )

        # ── área + polyline ────────────────────────────────────────────────────
        polylines = ""
        for idx, serie in enumerate(self.series):
            color  = self._series_color(idx)
            coords = [(nx(i), ny(yv)) for i, yv in enumerate(serie)]
            pts    = " ".join(f"{x:.1f},{y:.1f}" for x, y in coords)

            if self._fill_area:
                base_y   = ch - pb
                fill_pts = pts + f" {coords[-1][0]:.1f},{base_y} {coords[0][0]:.1f},{base_y}"
                polylines += f'<polygon points="{fill_pts}" fill="{color}" fill-opacity="0.07"/>'

            polylines += (
                f'<polyline fill="none" stroke="{color}" stroke-width="2.2"'
                f' stroke-linejoin="round" stroke-linecap="round" points="{pts}"/>'
            )

        # ── crosshair ─────────────────────────────────────────────────────────
        vline = ""
        if self._show_crosshair:
            vline = (
                f'<line id="{vline_id}" x1="0" y1="{pt}" x2="0" y2="{ch - pb}"'
                f' stroke="{muted2}" stroke-width="1" stroke-dasharray="4 3" opacity="0"/>'
            )

        # ── círculos + hover rects ────────────────────────────────────────────
        circles = hover_rects = value_labels = ""
        step_x  = iW / max(len(self.x) - 1, 1)

        for i in range(len(self.x)):
            px = nx(i)

            for idx, serie in enumerate(self.series):
                py    = ny(serie[i])
                color = self._series_color(idx)

                if self._show_points:
                    circles += (
                        f'<circle cx="{px:.1f}" cy="{py:.1f}" r="4"'
                        f' fill="{color}" stroke="white" stroke-width="2"/>'
                    )

                if self._show_label:
                    offset = self._label_offset
                    y_txt  = py - offset if self._label_position == "top" else py + offset + 10
                    value_labels += (
                        f'<text x="{px:.1f}" y="{y_txt:.1f}" font-size="10"'
                        f' text-anchor="middle" fill="{color}" font-family="{font}">'
                        f'{serie[i]}</text>'
                    )

            tip_html = ""
            for idx, serie in enumerate(self.series):
                color = self._series_color(idx)
                label = self.legends[idx] if idx < len(self.legends) else (
                    f"série {idx + 1}" if self.is_multiline else str(self.x[i])
                )
                tip_html += (
                    f"<div style='display:flex;align-items:center;gap:5px'>"
                    f"<span style='width:7px;height:7px;border-radius:50%;"
                    f"background:{color};display:inline-block'></span>"
                    f"<span>{self._esc(label)}: <b>{self._esc(serie[i])}</b></span></div>"
                )

            show = hide = move = ""

            if self._show_crosshair:
                show += (
                    f"var vl=document.getElementById('{vline_id}');"
                    f"vl.setAttribute('x1','{px:.1f}');vl.setAttribute('x2','{px:.1f}');"
                    f"vl.setAttribute('opacity','1');"
                )
                hide += f"document.getElementById('{vline_id}').setAttribute('opacity','0');"

            if self._show_tooltip:
                show += (
                    f"var t=document.getElementById('{tooltip_id}');"
                    f"t.innerHTML=`{tip_html}`;"
                    f"t.style.display='block';"
                )
                hide += f"document.getElementById('{tooltip_id}').style.display='none';"
                move  = self._js_tooltip_move(tooltip_id)

            rect_x = (px - step_x / 2) if i > 0 else pl
            hover_rects += (
                f'<rect x="{rect_x:.1f}" y="{pt}" width="{step_x:.1f}" height="{iH}"'
                f' fill="transparent"'
                f' onmouseenter="{show}"'
                f' onmouseleave="{hide}"'
                f' onmousemove="{move}"/>'
            )

        # ── SVG + card ────────────────────────────────────────────────────────
        svg = self._make_svg(cw, ch)
        svg.attrs["onmouseleave"] = (
            f"document.getElementById('{tooltip_id}').style.display='none';"
            f"document.getElementById('{vline_id}').setAttribute('opacity','0');"
        )
        svg.add(
            safe(grid_y), safe(grid_x),
            safe(y_labels), safe(x_labels),
            safe(polylines), safe(vline),
            safe(hover_rects), safe(circles), safe(value_labels),
        )

        svg_wrap = self._wrap_svg(svg, self._make_tooltip(tooltip_id))
        header   = self._make_header(self.title, self.subtitle)

        legend_labels = self.legends or (
            [f"série {i + 1}" for i in range(len(self.series))] if self.is_multiline else []
        )
        legend = self._make_legend(legend_labels)

        parts = []
        if header: parts.append(header)
        parts.append(svg_wrap)
        if legend:
            legend.sx(margin_top="14px")
            parts.append(legend)

        return self._make_card(*parts).render()