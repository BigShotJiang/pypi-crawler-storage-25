from tupyx.ui.html.tag import safe
from tupyx.ui.html.tags.tags import Div
from tupyx.ui.charts.chart import Chart


class TableChart(Chart):
    """
    Tabela estilo BI — mesma linguagem visual dos outros charts.

    Aceita lista de dicts (colunas extraídas automaticamente):
        TableChart(data=[{"Mês": "Jan", "Vendas": 320}, ...])

    Ou lista de listas com colunas explícitas:
        TableChart(data=[[320, 300], [480, 400]], columns=["Vendas", "Meta"])

    Compatível com MeasureCard e qualquer callable:
        TableChart(data=minha_medida, title="Resumo")
    """

    def __init__(self, data, columns=None, title=None, subtitle=None):
        super().__init__()

        data    = self._resolve(data)    or []
        columns = self._resolve(columns)

        if data and isinstance(data[0], dict):
            self._columns = columns or list(data[0].keys())
            self._rows    = [
                [row.get(col, "") for col in self._columns]
                for row in data
            ]
        else:
            n_cols        = len(data[0]) if data else 0
            self._columns = columns or [f"Col {i + 1}" for i in range(n_cols)]
            self._rows    = [list(r) for r in data]

        self.title    = title
        self.subtitle = subtitle

    # ── helpers ───────────────────────────────────────────────────────────────

    def _is_numeric(self, val) -> bool:
        return isinstance(val, (int, float))

    def _fmt(self, val) -> str:
        if isinstance(val, float):
            return f"{val:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
        if isinstance(val, int):
            return f"{val:,}".replace(",", ".")
        return str(val) if val is not None else "—"

    def _numeric_cols(self) -> set:
        result = set()
        for ci in range(len(self._columns)):
            col_vals = [row[ci] for row in self._rows if ci < len(row)]
            if col_vals and all(self._is_numeric(v) for v in col_vals):
                result.add(ci)
        return result

    # ── render ────────────────────────────────────────────────────────────────

    def render(self) -> str:
        if not self._rows:
            parts = []
            if (h := self._make_header(self.title, self.subtitle)):
                parts.append(h)
            parts.append(
                Div("Sem dados disponíveis").sx(
                    text_align="center", color="#94a3b8",
                    font_size="13px", padding="40px 0",
                )
            )
            return self._make_table_card(*parts).render()

        font    = self._font
        c       = self.palette
        uid     = self._uid
        numeric = self._numeric_cols()

        css = (
            f"#{uid}-tbl{{width:100%;border-collapse:collapse;font-family:{font};}}"
            f"#{uid}-tbl thead tr{{border-bottom:2px solid {c['border']};}}"
            f"#{uid}-tbl th{{padding:10px 16px;font-size:11px;font-weight:600;"
            f"color:{c['muted']};text-transform:uppercase;letter-spacing:.06em;"
            f"white-space:nowrap;text-align:left;}}"
            f"#{uid}-tbl th.r{{text-align:right;}}"
            f"#{uid}-tbl td{{padding:10px 16px;font-size:13px;color:{c['text']};"
            f"border-bottom:1px solid {c['border']};text-align:left;}}"
            f"#{uid}-tbl td.r{{text-align:right;font-variant-numeric:tabular-nums;"
            f"font-family:ui-monospace,monospace;letter-spacing:-.01em;}}"
            f"#{uid}-tbl tbody tr:last-child td{{border-bottom:none;}}"
            f"#{uid}-tbl tbody tr:hover td{{background:{c['surface']};}}"
        )

        def th(ci, col):
            cls = ' class="r"' if ci in numeric else ""
            return f"<th{cls}>{col}</th>"

        def td(ci, val):
            cls = ' class="r"' if ci in numeric else ""
            return f"<td{cls}>{self._fmt(val)}</td>"

        ths = "".join(th(ci, col) for ci, col in enumerate(self._columns))

        trs = "".join(
            "<tr>" + "".join(td(ci, val) for ci, val in enumerate(row)) + "</tr>"
            for row in self._rows
        )

        table_html = (
            f"<style>{css}</style>"
            f'<div style="overflow-x:auto">'
            f'<table id="{uid}-tbl">'
            f"<thead><tr>{ths}</tr></thead>"
            f"<tbody>{trs}</tbody>"
            f"</table></div>"
        )

        parts = []
        if (h := self._make_header(self.title, self.subtitle)):
            parts.append(h)
        parts.append(Div(safe(table_html)))

        return self._make_table_card(*parts).render()

    def _make_table_card(self, *children):
        css_w = self._css_w or "100%"
        return Div(*children).sx(
            background=self._color("bg"),
            border=f"1px solid {self._color('border')}",
            border_radius="16px",
            padding="24px 28px 20px",
            display="block",
            font_family=self._font,
            width=css_w,
            box_sizing="border-box",
        )
