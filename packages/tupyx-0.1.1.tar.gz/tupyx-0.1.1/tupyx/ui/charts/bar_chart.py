from tupyx.ui.html.tag import safe
from tupyx.ui.charts.chart import Chart


class BarChart(Chart):

    def __init__(self, y, x=None, legends=None, title=None, subtitle=None):
        super().__init__()

        if y is None:
            raise ValueError("y e obrigatorio")

        y = self._resolve(y) or []
        x = self._resolve(x)

        self.series   = [y] if (not y or not isinstance(y[0], (list, tuple))) else y
        self.x        = x if x is not None else list(range(len(self.series[0])))
        self.legends  = legends or []
        self.title    = title
        self.subtitle = subtitle

        self.is_multiline = len(self.series) > 1

        self._show_x         = True
        self._show_y         = True
        self._show_grid_y    = True
        self._show_label     = False
        self._label_offset   = 8
        self._show_crosshair = True

        # border-radius das barras (px)
        self._bar_radius = 4

        self._padding = {"top": 16, "right": 40, "bottom": 32, "left": 40}

    def sx(self, **styles):
        _flags = {
            "hide_x":         ("_show_x",         False),
            "hide_y":         ("_show_y",         False),
            "hide_grid_y":    ("_show_grid_y",    False),
            "show_label":     ("_show_label",     True),
            "hide_crosshair": ("_show_crosshair", False),
        }
        remaining = {}
        for k, v in styles.items():
            if k in _flags and v:
                setattr(self, _flags[k][0], _flags[k][1])
            elif k == "label_offset":
                self._label_offset = v
            elif k == "bar_radius":
                self._bar_radius = int(v)
            elif k.startswith("padding_"):
                side = k.split("_")[1]
                if side in self._padding:
                    self._padding[side] = int(v)
            else:
                remaining[k] = v
        super().sx(**remaining)
        return self

    def _bar_path(self, x, y, w, h, r):
        """
        Rect com border-radius apenas nos cantos superiores —
        visual moderno sem quebrar quando a barra e muito pequena.
        """
        r = min(r, w / 2, max(h, 0.1))
        if h <= 0:
            return ""
        return (
            f"M{x:.1f},{y+r:.1f} "
            f"Q{x:.1f},{y:.1f} {x+r:.1f},{y:.1f} "
            f"L{x+w-r:.1f},{y:.1f} "
            f"Q{x+w:.1f},{y:.1f} {x+w:.1f},{y+r:.1f} "
            f"L{x+w:.1f},{y+h:.1f} "
            f"L{x:.1f},{y+h:.1f} "
            f"Z"
        )

    def _empty_card(self):
        from tupyx.ui.html.tags.tags import Div
        parts = []
        if (h := self._make_header(self.title, self.subtitle)):
            parts.append(h)
        parts.append(
            Div("Sem dados disponíveis").sx(
                text_align="center", color="#94a3b8",
                font_size="13px", padding="40px 0",
            )
        )
        return self._make_card(*parts).render()

    def render(self):
        all_y = [v for s in self.series for v in s]
        if not all_y:
            return self._empty_card()

        cw = self._canvas_w
        ch = self._canvas_h
        pt = self._padding["top"]
        pr = self._padding["right"]
        pb = self._padding["bottom"]
        pl = self._padding["left"]
        iW = cw - pl - pr
        iH = ch - pt - pb

        max_y   = max(all_y)
        y_top   = max_y * 1.12
        y_range = y_top or 1

        def ny(v): return pt + iH * (1 - v / y_range)

        tooltip_id = self._el_id("tooltip")
        vline_id   = self._el_id("vline")
        border     = self._color("border")
        muted2     = self._color("muted2")
        font       = self._font

        # grid Y + labels Y
        grid_y = y_labels = ""
        for i in range(5):
            val   = max_y * i / 4
            y_pos = ny(val)
            if self._show_grid_y:
                grid_y += (
                    f'<line x1="{pl}" y1="{y_pos:.1f}" x2="{cw-pr}" y2="{y_pos:.1f}"'
                    f' stroke="{border}" stroke-width="1"/>'
                )
            if self._show_y:
                lbl = str(int(val)) if val == int(val) else f"{val:.1f}"
                y_labels += (
                    f'<text x="{pl-6}" y="{y_pos:.1f}" font-size="10" fill="{muted2}"'
                    f' font-family="{font}" text-anchor="end" dominant-baseline="middle">'
                    f'{lbl}</text>'
                )

        # barras
        x_labels = bars = value_labels = hover_rects = ""
        n       = len(self.x)
        group_w = iW / n

        for i in range(n):
            group_x  = pl + i * group_w
            x_center = group_x + group_w / 2

            n_series = len(self.series)
            usable   = group_w * 0.78
            gap_px   = 3 if n_series > 1 else 0
            bar_w    = (usable - gap_px * (n_series - 1)) / n_series
            bar_w    = max(bar_w, 2)
            offset   = (group_w - (bar_w * n_series + gap_px * (n_series - 1))) / 2

            if self._show_x:
                x_labels += (
                    f'<text x="{x_center:.1f}" y="{ch-6}" font-size="10" fill="{muted2}"'
                    f' font-family="{font}" text-anchor="middle">{self.x[i]}</text>'
                )

            for idx, serie in enumerate(self.series):
                value  = serie[i]
                color  = self._series_color(idx)
                x_bar  = group_x + offset + idx * (bar_w + gap_px)
                y_bar  = ny(value)
                h_bar  = (ch - pb) - y_bar

                d = self._bar_path(x_bar, y_bar, bar_w, h_bar, self._bar_radius)
                if d:
                    bars += f'<path d="{d}" fill="{color}"/>'

                if self._show_label:
                    lx = x_bar + bar_w / 2
                    value_labels += (
                        f'<text x="{lx:.1f}" y="{y_bar - self._label_offset:.1f}"'
                        f' font-size="10" text-anchor="middle" fill="{color}"'
                        f' font-family="{font}">{value}</text>'
                    )

            # tooltip + hover
            tip_html = ""
            for idx, serie in enumerate(self.series):
                color = self._series_color(idx)
                label = self.legends[idx] if idx < len(self.legends) else f"serie {idx+1}"
                tip_html += (
                    f"<div style='display:flex;align-items:center;gap:5px'>"
                    f"<span style='width:7px;height:7px;border-radius:50%;"
                    f"background:{color};display:inline-block'></span>"
                    f"<span>{self._esc(label)}: <b>{self._esc(serie[i])}</b></span></div>"
                )

            show = hide = move = ""
            cx = x_center
            if self._show_crosshair:
                show += (
                    f"var vl=document.getElementById('{vline_id}');"
                    f"vl.setAttribute('x1','{cx:.1f}');vl.setAttribute('x2','{cx:.1f}');"
                    f"vl.setAttribute('opacity','1');"
                )
                hide += f"document.getElementById('{vline_id}').setAttribute('opacity','0');"

            if self._show_tooltip:
                show += (
                    f"var t=document.getElementById('{tooltip_id}');"
                    f"t.innerHTML=`{tip_html}`;t.style.display='block';"
                )
                hide += f"document.getElementById('{tooltip_id}').style.display='none';"
                move  = self._js_tooltip_move(tooltip_id)

            hover_rects += (
                f'<rect x="{group_x:.1f}" y="{pt}" width="{group_w:.1f}" height="{iH}"'
                f' fill="transparent" onmouseenter="{show}" onmouseleave="{hide}" onmousemove="{move}"/>'
            )

        # crosshair
        vline = ""
        if self._show_crosshair:
            vline = (
                f'<line id="{vline_id}" x1="0" y1="{pt}" x2="0" y2="{ch-pb}"'
                f' stroke="{muted2}" stroke-width="1" stroke-dasharray="4 3" opacity="0"/>'
            )

        svg = self._make_svg(cw, ch)
        svg.attrs["onmouseleave"] = (
            f"document.getElementById('{tooltip_id}').style.display='none';"
            f"document.getElementById('{vline_id}').setAttribute('opacity','0');"
        )
        svg.add(
            safe(grid_y), safe(y_labels), safe(x_labels),
            safe(bars), safe(vline), safe(hover_rects), safe(value_labels),
        )

        legend_labels = self.legends or (
            [f"serie {i+1}" for i in range(len(self.series))] if self.is_multiline else []
        )

        parts = []
        if (h := self._make_header(self.title, self.subtitle)): parts.append(h)
        parts.append(self._wrap_svg(svg, self._make_tooltip(tooltip_id)))
        if (leg := self._make_legend(legend_labels)):
            leg.sx(margin_top="14px"); parts.append(leg)

        return self._make_card(*parts).render()