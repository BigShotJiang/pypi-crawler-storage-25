def filter(*args):

    def decorator(func):
        return func

    return decorator
