"""
tupyx.ui.decorators.measure
----------------------------
Decorator `@measure` — transforma funções em KPI cards reativos.

O card é re-calculado a cada render, então sempre reflete o estado
atual dos reativos que a função lê internamente.

Uso básico:
    @measure(label="Total de Vendas", prefix="R$ ", color="blue")
    def total():
        return sum(d["valor"] for d in dados)

    # No layout:
    Div(total)          # → renderiza como card visual
    BarChart(y=total)   # → passa o valor para um gráfico
    total()             # → valor numérico puro (para expressões Python)

Cores disponíveis: "blue", "green", "yellow", "red", "purple", "gray"
"""

from tupyx.ui.html.tag import Tag
from tupyx.ui.html.tags.tags import Div

_FONT = "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif"

# Paleta de cores para os cards: nome → (cor_acento, cor_fundo, cor_borda)
_COLORS = {
    "blue":   ("#2563eb", "#eff6ff", "#bfdbfe"),
    "green":  ("#16a34a", "#f0fdf4", "#bbf7d0"),
    "yellow": ("#ca8a04", "#fefce8", "#fde68a"),
    "red":    ("#dc2626", "#fef2f2", "#fecaca"),
    "purple": ("#7c3aed", "#f5f3ff", "#ddd6fe"),
    "gray":   ("#475569", "#f8fafc", "#e2e8f0"),
}


def _format(value) -> str:
    """
    Formata números para exibição no padrão brasileiro.

    - float: separador de milhar com ponto, duas casas decimais (ex: 1.320,50)
    - int: separador de milhar com ponto (ex: 1.320)
    - outros: converte para string normalmente
    """
    if isinstance(value, float):
        return f"{value:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    if isinstance(value, int):
        return f"{value:,}".replace(",", ".")
    return str(value)


class MeasureCard(Tag):
    """
    Card visual de KPI gerado pelo decorator `@measure`.

    Você normalmente não cria esta classe diretamente — use `@measure`.

    A classe herda de `Tag` para poder ser inserida no layout HTML como
    qualquer outro componente. Chamar `medida()` retorna o valor bruto
    para uso em expressões Python ou passagem para gráficos.
    """

    def __init__(self, fn, label: str, prefix: str = "", suffix: str = "", color: str = "blue"):
        super().__init__("div")
        self._fn     = fn       # função que calcula o valor
        self._label  = label    # título do card (ex: "Total de Vendas")
        self._prefix = prefix   # texto antes do número (ex: "R$ ")
        self._suffix = suffix   # texto depois do número (ex: " unidades")
        self._color  = color    # nome da cor do card

    def __call__(self):
        """
        Retorna o valor bruto calculado pela função.

        Permite usar a medida em expressões Python:
            if total() > 1000:
                ...
            BarChart(y=total)  # gráfico usa o valor diretamente
        """
        return self._fn()

    def _build_card(self, value) -> Tag:
        """Constrói o elemento HTML visual do card com o valor formatado."""
        accent, bg, border_color = _COLORS.get(self._color, _COLORS["blue"])

        # Formata o valor com prefixo e sufixo
        display = f"{self._prefix}{_format(value)}{self._suffix}"

        # Elemento do valor numérico (destaque visual)
        value_el = Tag("p")
        value_el.add(display)
        value_el.sx(
            margin="0",
            font_size="26px",
            font_weight="700",
            color=accent,
            font_family=_FONT,
            line_height="1.1",
        )

        # Label opcional acima do valor
        if self._label:
            label_el = Tag("p")
            label_el.add(self._label)
            label_el.sx(
                margin="0 0 6px",
                font_size="11px",
                font_weight="600",
                color="#64748b",
                font_family=_FONT,
                text_transform="uppercase",
                letter_spacing="0.06em",
            )
            content = Div(label_el, value_el).sx(flex="1")
        else:
            content = Div(value_el).sx(flex="1")

        # Barra colorida vertical à esquerda
        bar = Div().sx(
            width="3px",
            background=accent,
            border_radius="2px",
            flex_shrink="0",
            align_self="stretch",
        )

        return Div(bar, content).sx(
            background=bg,
            border=f"1px solid {border_color}",
            border_radius="12px",
            padding="16px 20px",
            display="inline-flex",
            align_items="center",
            gap="14px",
            min_width="160px",
            box_sizing="border-box",
            font_family=_FONT,
        )

    def render(self) -> str:
        """Re-executa a função e renderiza o card com o valor atual."""
        return self._build_card(self._fn()).render()


def measure(label: str = "", prefix: str = "", suffix: str = "", color: str = "blue"):
    """
    Decorator que transforma uma função em um KPI card reativo.

    Parâmetros:
        label  — título exibido acima do valor (ex: "Total de Vendas")
        prefix — texto antes do número (ex: "R$ ", "$ ")
        suffix — texto depois do número (ex: " kg", " unidades")
        color  — cor do card: "blue" | "green" | "yellow" | "red" | "purple" | "gray"

    A função decorada:
    - NÃO recebe parâmetros
    - Pode ler Reactive com `.get()` para ser reativa a filtros
    - Retorna um número, string, ou qualquer valor formatável

    Exemplos:

        # KPI simples
        @measure(label="Receita Total", prefix="R$ ", color="green")
        def receita():
            return sum(d["valor"] for d in vendas)

        # KPI reativo a um filtro
        ano = Reactive("2024")

        @measure(label="Vendas", color="blue")
        def vendas_ano():
            return sum(d["val"] for d in dados if d["ano"] == ano.get())

        # Usar no layout:
        Div(receita, vendas_ano).sx(display="flex", gap="16px")

        # Usar em gráfico:
        BarChart(y=vendas_ano)

        # Usar em expressão:
        if receita() > 10000:
            ...
    """
    def decorator(fn):
        return MeasureCard(fn, label=label, prefix=prefix, suffix=suffix, color=color)
    return decorator
