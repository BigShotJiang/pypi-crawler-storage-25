from typing import Dict, Callable, Any, Optional
from tupyx.ui.reactive.reactive import Reactive

class ReactiveForm:

    def __init__(self, schema: Dict[str, Any]):
        self._fields: Dict[str, Reactive] = {}

        for name, initial in schema.items():
            self._fields[name] = Reactive(initial)
            setattr(self, name, self._fields[name])

    def set(self, key: str, value: Any):
        if key in self._fields:
            self._fields[key].set(value)

    def get(self, key: str):
        if key in self._fields:
            return self._fields[key].get()
        return None

    def values(self) -> Dict[str, Any]:
        return {name: field.get() for name, field in self._fields.items()}

    def __getitem__(self, key: str) -> Reactive:
        return self._fields[key]