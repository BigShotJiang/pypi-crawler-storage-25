"""
tupyx.ui.reactive.reactive
--------------------------
Sistema de estado reativo do tupyx.

Como funciona:
- `Reactive(valor_inicial)` cria uma variável de estado.
- `.get()` lê o valor atual.
- `.set(novo_valor)` atualiza o valor e notifica os assinantes.
- `.update(fn)` aplica uma função ao valor atual (útil para incrementar, etc.).
- `.subscribe(fn)` registra um callback chamado em toda atualização.

O estado é compartilhado entre requests HTTP (vive no processo Python).
Cada thread tem seu próprio contexto de render (via threading.local),
mas o store de valores é compartilhado e protegido por Lock.

Exemplo de uso:
    contador = Reactive(0)

    @page("/")
    def home():
        def incrementar():
            contador.update(lambda v: v + 1)

        return Div(
            P(contador),
            Button("+1").on_click(incrementar),
        )
"""

from typing import Callable, TypeVar, Generic, Dict, List, Any
import threading

T = TypeVar("T")

# ── Estado global compartilhado ───────────────────────────────────────────────

# Dicionário principal: chave → valor atual
_state_store: Dict[str, Any] = {}

# Dicionário de callbacks: chave → lista de funções a chamar quando o valor muda
_listeners: Dict[str, List[Callable[[Any], None]]] = {}

# Lock para garantir thread-safety: múltiplas requests simultâneas não corrompem o estado
_state_lock = threading.Lock()

# ── Contexto de render por thread ─────────────────────────────────────────────
#
# Cada request HTTP é processada em uma thread separada.
# `_thread_local` guarda o "escopo" atual da thread (qual página está sendo
# renderizada) e um índice de hook para gerar chaves únicas por Reactive.

_thread_local = threading.local()


def _begin_scope(scope: str | None):
    """
    Inicia um novo escopo de render para a thread atual.

    Deve ser chamado antes de renderizar uma página e
    `_begin_scope(None)` deve ser chamado no finally para limpar.

    O `scope` é uma string única que identifica a rota + função sendo renderizada.
    O `hook_index` é resetado a zero para que cada Reactive() na função
    sempre receba a mesma chave (mesmo comportamento entre renders).
    """
    _thread_local.current_scope = scope
    _thread_local.hook_index    = 0


def _use_key() -> str:
    """
    Gera e retorna a chave única para o próximo Reactive() chamado.

    A chave é formada por `escopo:índice`, onde o índice aumenta
    a cada Reactive() criado dentro do mesmo escopo.

    Isso garante que `Reactive("2024")` na linha 5 sempre tenha
    a mesma chave entre renders, desde que o escopo não mude.

    Lança RuntimeError se chamado fora de um escopo ativo.
    """
    scope = getattr(_thread_local, "current_scope", None)

    if scope is None:
        raise RuntimeError(
            "Reactive() só pode ser criado dentro de uma função de página "
            "decorada com @page(). Certifique-se de que o Reactive está "
            "dentro do corpo da função, não no nível do módulo."
        )

    idx = getattr(_thread_local, "hook_index", 0)
    _thread_local.hook_index = idx + 1

    return f"{scope}:{idx}"


# ── Classe Reactive ────────────────────────────────────────────────────────────

class Reactive(Generic[T]):
    """
    Variável de estado reativa.

    Crie dentro de uma função de página para que o valor persista
    entre renders da mesma rota.

    Parâmetros:
        value — valor inicial (qualquer tipo Python)

    Exemplo:
        nome = Reactive("mundo")

        # Exibir o valor diretamente em HTML:
        P("Olá, ", nome)

        # Ler programaticamente:
        nome.get()        # → "mundo"

        # Atualizar:
        nome.set("tupyx")
        nome.update(lambda v: v.upper())
    """

    def __init__(self, value: T = None):
        # Gera uma chave estável para este Reactive dentro do escopo atual
        self._key = _use_key()

        with _state_lock:
            # Só inicializa se ainda não existe (preserva valor entre renders)
            if self._key not in _state_store:
                _state_store[self._key] = value
                _listeners[self._key]   = []

    # ── Leitura e escrita ─────────────────────────────────────────────────────

    def get(self) -> T:
        """Retorna o valor atual de forma thread-safe."""
        with _state_lock:
            return _state_store[self._key]

    def set(self, value: T):
        """
        Define um novo valor e notifica todos os assinantes.

        Exemplo:
            ano.set("2023")
        """
        with _state_lock:
            _state_store[self._key] = value
        self._notify()

    def update(self, fn: Callable[[T], T]):
        """
        Aplica uma função ao valor atual e salva o resultado.

        Útil para modificações baseadas no valor anterior.

        Exemplo:
            contador.update(lambda v: v + 1)
            lista.update(lambda v: v + ["novo item"])
        """
        with _state_lock:
            _state_store[self._key] = fn(_state_store[self._key])
        self._notify()

    # ── Reatividade ───────────────────────────────────────────────────────────

    def subscribe(self, fn: Callable[[T], None]):
        """
        Registra um callback chamado sempre que o valor mudar.

        O callback recebe o novo valor como argumento.

        Exemplo:
            total.subscribe(lambda v: print(f"Novo total: {v}"))
        """
        _listeners[self._key].append(fn)

    def _notify(self):
        """Chama todos os callbacks registrados com o valor atual."""
        for fn in _listeners[self._key]:
            fn(_state_store[self._key])

    # ── Render ────────────────────────────────────────────────────────────────

    def render(self) -> str:
        """
        Converte o valor atual para string HTML.

        - None → string vazia
        - list/tuple → elementos concatenados como string
        - qualquer outro → str()
        """
        v = self.get()

        if v is None:
            return ""

        if isinstance(v, (list, tuple)):
            return "".join(map(str, v))

        return str(v)

    # ── Utilitários ───────────────────────────────────────────────────────────

    def __str__(self):
        """Permite usar o Reactive diretamente em f-strings: f"Olá {nome}" """
        return self.render()

    def __repr__(self):
        return f"Reactive({self.get()!r})"

    def __call__(self) -> T:
        """Permite chamar o Reactive como função: nome() == nome.get()"""
        return self.get()
