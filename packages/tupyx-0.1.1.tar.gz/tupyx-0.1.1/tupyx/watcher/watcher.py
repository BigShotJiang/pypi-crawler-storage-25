"""
tupyx.watcher.watcher
---------------------
Hot-reload: monitora arquivos .py e reinicia o servidor ao detectar mudanças.

Chamado pelo comando `tupyx run app.py`.

Como funciona:
1. Registra o tempo de modificação (mtime) de todos os .py do projeto.
2. Inicia o servidor em um subprocesso separado.
3. A cada 200ms verifica se algum arquivo mudou.
4. Se mudou, mata o processo atual e inicia um novo.
5. O browser detecta a reconexão via SSE (__reload__) e recarrega.
"""

import os
import time
import subprocess
import sys
from tupyx.colors import Colors
from datetime import datetime


def get_mtimes(folder: str) -> dict:
    """
    Retorna um dicionário {caminho_arquivo: timestamp_modificacao}
    para todos os arquivos .py encontrados recursivamente em `folder`.

    Ignora pastas que não precisam ser monitoradas.
    """
    mtimes = {}
    for root, dirs, files in os.walk(folder):
        # Ignora pastas desnecessárias para não monitorar dependências instaladas
        dirs[:] = [d for d in dirs if d not in ("__pycache__", ".venv", ".git")]
        for file in files:
            if file.endswith(".py"):
                path = os.path.join(root, file)
                mtimes[path] = os.path.getmtime(path)
    return mtimes


def watch(script: str, debounce: float = 0.5):
    """
    Inicia o `script` como subprocesso e monitora mudanças nos arquivos .py.

    Parâmetros:
        script   — caminho para o arquivo principal (ex: "app.py")
        debounce — segundos de espera após a última mudança antes de reiniciar
                   (evita reinícios múltiplos ao salvar vários arquivos)

    Ao detectar mudança:
    1. Aguarda `debounce` segundos sem novas mudanças.
    2. Mata o processo atual.
    3. Inicia um novo processo com o mesmo script.
    """
    now = datetime.now()

    # Snapshot inicial dos mtimes
    mtimes  = get_mtimes(".")
    # -u = unbuffered: garante que os prints do servidor aparecem imediatamente no terminal
    process = subprocess.Popen([sys.executable, "-u", script])

    changed     = False
    last_change = None

    while True:
        time.sleep(0.2)  # verifica a cada 200ms

        new_mtimes = get_mtimes(".")

        # Compara com o snapshot anterior
        if new_mtimes != mtimes:
            changed_files = [f for f in new_mtimes if new_mtimes[f] != mtimes.get(f)]
            for f in changed_files:
                print(
                    f"{Colors.WHITE}[{now.strftime('%d/%m/%Y %H:%M:%S')}]: "
                    f"{Colors.YELLOW}Changed file: {f}"
                )
            mtimes      = new_mtimes
            changed     = True
            last_change = time.time()

        # Reinicia após debounce (quando parou de salvar arquivos)
        if changed and (time.time() - last_change) >= debounce:
            changed = False
            process.kill()
            process.wait()
            process = subprocess.Popen([sys.executable, "-u", script])
            print(
                f"{Colors.WHITE}[{now.strftime('%d/%m/%Y %H:%M:%S')}]: "
                f"{Colors.BGREEN}Reloaded!"
            )
