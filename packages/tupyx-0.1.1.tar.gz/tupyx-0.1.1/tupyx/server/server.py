"""
tupyx.server.server
-------------------
Servidor HTTP do tupyx baseado em `ThreadingHTTPServer`.

Responsabilidades:
1. Servir as páginas HTML renderizadas pelo Python.
2. Receber eventos do browser (cliques, inputs, etc.) e re-renderizar.
3. Injetar o script de hot-reload em cada resposta.
4. Redirecionar rotas desconhecidas para a rota padrão (redirect=True).

Como usar (no seu app.py):
    from tupyx.server import run

    run(app)            # passa uma função que retorna a tag raiz
    run()               # usa o Router automático (recomendado com @page)
    run(port=3000)      # muda a porta
"""

from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from tupyx.ui.html.tag import Tag
from typing import Callable, Union, Optional
from tupyx.ui.events import events
from urllib.parse import urlparse, parse_qs
from tupyx.colors import Colors
from tupyx.ui.router.router import _autodiscover
import tupyx.ui.router.router as router
import time
from datetime import datetime

# Script injetado em todas as páginas para detectar reconexão do servidor
# e recarregar o browser automaticamente no hot-reload.
RELOAD_SCRIPT = """
<script>
    const es = new EventSource('/__reload__');
    es.onerror = () => {
        es.close();
        const retry = setInterval(() => {
            fetch(window.location.pathname).then(() => {
                clearInterval(retry);
                location.reload();
            }).catch(() => {});
        }, 500);
    };
</script>
"""

# Script injetado em todas as páginas para suporte ao botão voltar/avançar
# do browser quando se usa NavLink para navegar entre rotas.
# Quando o browser dispara `popstate` (voltar/avançar), fazemos fetch da
# rota anterior e substituímos o conteúdo sem recarregar a página.
POPSTATE_SCRIPT = """
<script>
    window.addEventListener('popstate', function() {
        fetch(window.location.pathname)
            .then(r => r.text())
            .then(html => {
                const doc = new DOMParser().parseFromString(html, 'text/html');
                const newRoot = doc.querySelector('[data-tupyx-root]');
                const root = document.querySelector('[data-tupyx-root]');
                if (root && newRoot) root.replaceWith(newRoot);
            });
    });
</script>
"""


def run(
    content: Optional[Union[Tag, Callable[[], Tag]]] = None,
    address: str = "localhost",
    port: int = 8000,
) -> None:
    """
    Inicia o servidor tupyx.

    Parâmetros:
        content — tag raiz ou função que retorna a tag raiz.
                  Se None, usa um Router automático com Html/Body.
        address — endereço de bind (padrão: "localhost")
        port    — porta (padrão: 8000)

    Exemplos:

        # Modo simples (sem roteamento):
        run(lambda: Html(Body(H1("Olá!"))))

        # Modo com roteamento (recomendado):
        @page("/")
        def home():
            return Div(H1("Home"))

        def app():
            return Html(Head(Title("Meu App")), Body(Router()))

        run(app)

        # Porta customizada:
        run(app, port=3000)
    """

    # Importa todos os arquivos .py do projeto para registrar os @page(...)
    _autodiscover()

    # Se não foi passado conteúdo, usa o Router com Html/Body padrão
    if content is None:
        from tupyx.ui.router.router import Router
        from tupyx.ui.html.tags.tags import Html, Body
        _content = lambda: Html(Body(Router()))
    else:
        _content = content

    def render(result):
        """
        Renderiza o resultado final para string HTML.
        Usa render_with_styles() para incluir estilos de :hover/:focus
        e envolver o conteúdo com data-tupyx-root (necessário para eventos).
        """
        if hasattr(result, "render_with_styles"):
            return result.render_with_styles()
        return str(result)

    class MyHandler(BaseHTTPRequestHandler):

        def log_message(self, format, *args):
            # Silencia o log padrão do servidor HTTP (muito verboso)
            pass

        def do_GET(self):
            parsed      = urlparse(self.path)
            path        = parsed.path
            query_params = parse_qs(parsed.query)

            # ── Hot Reload (SSE) ──────────────────────────────────────────────
            # O browser abre uma conexão persistente aqui.
            # Quando o servidor reinicia (por mudança de arquivo), a conexão
            # cai e o browser detecta via es.onerror, disparando o reload.
            if path == "/__reload__":
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                try:
                    while True:
                        self.wfile.write(b"data: ping\n\n")
                        self.wfile.flush()
                        time.sleep(1)
                except (ConnectionError, BrokenPipeError, OSError):
                    # Conexão fechada normalmente (browser fechado ou reload)
                    return

            # ── Eventos ───────────────────────────────────────────────────────
            # Chamados pelo JS do browser quando o usuário interage com a página.
            # A URL tem o formato: /event/nome_uuid?input_id=valor&...
            elif path.startswith("/event/"):
                func = events.get(path)

                if not func:
                    self.send_response(404)
                    self.end_headers()
                    self.wfile.write(b"Event not found")
                    return

                from tupyx.ui.html.tags.tags import _input_registry, _select_registry, _name_registry

                # Atualiza os Reactives ligados aos inputs/selects da página
                for input_id, values in query_params.items():
                    if input_id == "current_path":
                        continue
                    if input_id in _input_registry:
                        _input_registry[input_id].set_value(values[0])
                    if input_id in _select_registry:
                        _select_registry[input_id].set_value(values[0])
                    if input_id in _name_registry:
                        _name_registry[input_id].set_value(values[0])

                # Restaura o path da rota atual (o browser envia junto)
                current_path = query_params.get("current_path", ["/"])[0]
                router._current_path = current_path

                # Executa o handler do evento (ex: função de clique)
                func()

                # Re-renderiza a página inteira com o novo estado
                result = _content() if callable(_content) else _content
                html   = self._inject_reload(render(result))

                self.send_response(200)
                self.send_header("Content-type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(html.encode("utf-8"))
                return

            # ── Rotas normais ─────────────────────────────────────────────────
            else:
                router._current_path = path

                # Se a rota não existe e há um redirect configurado, redireciona
                func, _ = router._match_route(path)
                if func is None and router._redirect_path:
                    self.send_response(302)
                    self.send_header("Location", router._redirect_path)
                    self.end_headers()
                    return

                result = _content() if callable(_content) else _content
                html   = self._inject_reload(render(result))

                self.send_response(200)
                self.send_header("Content-type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(html.encode("utf-8"))
                return

        def _inject_reload(self, html: str) -> str:
            """
            Injeta o script de hot-reload e o listener de popstate
            (para o botão voltar/avançar funcionar com NavLink)
            antes do </body>, ou no final se não houver </body>.
            """
            scripts = RELOAD_SCRIPT + POPSTATE_SCRIPT
            if "</body>" in html:
                return html.replace("</body>", f"{scripts}</body>")
            return html + scripts

    httpd = ThreadingHTTPServer((address, port), MyHandler)

    now = datetime.now()
    print(
        f"{Colors.WHITE}[{now.strftime('%d/%m/%Y %H:%M:%S')}]: "
        f"{Colors.BGREEN}Server is running on http://{address}:{port}{Colors.RESET}"
    )
    httpd.serve_forever()
