"""
tupyx — Framework Python para dashboards reativos.

Este é o ponto de entrada principal da biblioteca.
Importando `tupyx` você já tem acesso a todos os componentes,
gráficos, reativos e à função `run`.

Exemplo de uso mínimo:
    from tupyx import *

    run(lambda: Html(Body(H1("Olá, mundo!"))))
"""

# Exporta tudo do módulo de UI (tags, gráficos, reativos, roteador, decoradores)
from tupyx.ui import *

# Exporta a função que inicia o servidor web
from tupyx.server import run
