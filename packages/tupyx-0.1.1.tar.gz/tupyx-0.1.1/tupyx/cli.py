"""
tupyx.cli
---------
Interface de linha de comando do tupyx.

Comandos disponíveis:
    tupyx init <nome>     — Cria um novo projeto com estrutura básica
    tupyx run <arquivo>   — Inicia o servidor com hot-reload

Uso:
    $ tupyx init meu-dashboard
    $ cd meu-dashboard
    $ tupyx run app.py
"""

import sys
import os
from tupyx.colors import Colors


# ── Templates de arquivos gerados pelo `tupyx init` ───────────────────────────

# app.py — ponto de entrada do servidor
APP_PY = '''\
from tupyx.ui import *
from tupyx.server import run


def app():
    """
    Função raiz do app — define a estrutura HTML principal.
    O Router renderiza automaticamente a página certa com base na URL.
    """
    return Html(
        Head(Title("{name}")),
        Body(Router()).sx(margin="0", background="#f8fafc"),
    )


run(app)
'''

# pages/home.py — primeira página do projeto, com rota "/"
# Usa a default_page visual de boas-vindas (gerada abaixo)
DEFAULT_PAGE_PY = '''\
from tupyx.ui import *

# Cores e fontes do design system
BG      = "#ffffff"
SURFACE = "#f0f7ff"
BORDER  = "#dbeafe"
BLUE    = "#2563eb"
YELLOW  = "#facc15"
TEXT    = "#0f172a"
MUTED   = "#64748b"
MUTED2  = "#94a3b8"
SERIF   = "Georgia, serif"
MONO    = "\'Courier New\', monospace"
SANS    = "-apple-system, BlinkMacSystemFont, \'Segoe UI\', sans-serif"


@page("/", redirect=True)
def home():
    """Página de boas-vindas gerada automaticamente pelo `tupyx init`."""

    def code_line(content, color=MUTED):
        return P(content).sx(
            font_family=MONO,
            font_size="0.8rem",
            line_height="1.9",
            color=color,
            white_space="nowrap",
        )

    def step_card(number, title, code, desc):
        return Div(
            Div(
                Span(number).sx(
                    font_family=MONO, font_size="0.7rem",
                    font_weight="bold", color=BLUE,
                )
            ).sx(
                width="28px", height="28px", border_radius="50%",
                background=SURFACE, border=f"1.5px solid {BORDER}",
                display="flex", align_items="center",
                justify_content="center", margin_bottom="1rem",
            ),
            P(title).sx(
                font_family=SANS, font_size="0.8rem",
                font_weight="600", color=TEXT,
                margin_bottom="0.5rem", letter_spacing="-0.01em",
            ),
            Div(
                code_line(code, BLUE),
            ).sx(
                background=SURFACE, border=f"1px solid {BORDER}",
                border_radius="6px", padding="0.5rem 0.8rem",
                margin_bottom="0.6rem",
            ),
            P(desc).sx(
                font_family=SANS, font_size="0.75rem",
                color=MUTED, line_height="1.6",
            ),
        ).sx(
            padding="1.25rem", border=f"1px solid {BORDER}",
            border_radius="10px", background=BG, flex="1",
        )

    return Html(
        Head(Title("tupyx — welcome")),
        Body(

            # HEADER
            Header(
                Div(
                    Div(
                        Span("●").sx(color=BLUE, font_size="1rem"),
                        Span("tupyx").sx(
                            font_family=MONO, font_size="0.85rem",
                            font_weight="bold", letter_spacing="0.1em", color=TEXT,
                        ),
                    ).sx(display="flex", align_items="center", gap="0.5rem"),
                    Div(
                        Span("● ").sx(color="#22c55e", font_size="0.6rem"),
                        Span("servidor rodando").sx(
                            font_family=MONO, font_size="0.65rem",
                            letter_spacing="0.1em", color=MUTED,
                        ),
                    ).sx(
                        display="flex", align_items="center", gap="0.3rem",
                        background=SURFACE, border=f"1px solid {BORDER}",
                        padding="0.3rem 0.8rem", border_radius="999px",
                    ),
                ).sx(
                    max_width="860px", margin="0 auto", padding="0 2rem",
                    display="flex", justify_content="space-between", align_items="center",
                ),
            ).sx(
                border_bottom=f"1px solid {BORDER}",
                padding="1.1rem 0", background=BG,
            ),

            # HERO
            Div(
                Div(
                    Span("Python · Web · Zero JS").sx(
                        font_family=MONO, font_size="0.65rem",
                        letter_spacing="0.15em", color=BLUE,
                        background=SURFACE, border=f"1px solid {BORDER}",
                        padding="0.3rem 0.9rem", border_radius="999px",
                        display="inline-block", margin_bottom="2rem",
                    ),

                    H1(
                        Span("Seu projeto está").sx(
                            display="block", color=YELLOW, font_weight="normal",
                        ),
                        Span("pronto para rodar.").sx(display="block", color=BLUE),
                    ).sx(
                        font_family=SERIF,
                        font_size="clamp(2.5rem, 6vw, 4.5rem)",
                        line_height="1.1", letter_spacing="-0.02em",
                        margin_bottom="1.5rem", font_weight="normal",
                    ),

                    P(
                        "Edite pages/home.py e comece a construir "
                        "sua interface 100% em Python."
                    ).sx(
                        font_family=SANS, font_size="1rem",
                        color=MUTED, line_height="1.7",
                        max_width="44ch", margin_bottom="3rem",
                    ),

                    # Bloco de código decorativo
                    Div(
                        Div(
                            Div(
                                Div().sx(width="10px", height="10px", border_radius="50%", background="#fca5a5"),
                                Div().sx(width="10px", height="10px", border_radius="50%", background="#fde68a"),
                                Div().sx(width="10px", height="10px", border_radius="50%", background="#bbf7d0"),
                            ).sx(display="flex", gap="6px", align_items="center"),
                            Span("pages/home.py").sx(
                                font_family=MONO, font_size="0.65rem",
                                color=MUTED2, letter_spacing="0.1em",
                            ),
                            Div().sx(width="60px"),
                        ).sx(
                            display="flex", justify_content="space-between",
                            align_items="center", padding="0.7rem 1rem",
                            border_bottom=f"1px solid {BORDER}",
                        ),
                        Div(
                            code_line("from tupyx.ui import *", BLUE),
                            code_line(" "),
                            code_line("nome = Reactive(\'mundo\')", TEXT),
                            code_line(" "),
                            code_line("@page(\'/\')", TEXT),
                            code_line("def home():", TEXT),
                            Div(
                                code_line("return Div(", TEXT),
                                Div(
                                    code_line("H1(\'Olá, \', nome),", TEXT),
                                    code_line("P(\'feito em Python puro\')", MUTED),
                                ).sx(padding_left="1rem"),
                                code_line(")", TEXT),
                            ).sx(padding_left="1rem"),
                        ).sx(padding="1rem 1.2rem"),
                    ).sx(
                        background=SURFACE, border=f"1px solid {BORDER}",
                        border_radius="10px", overflow="hidden",
                        margin_bottom="4rem", max_width="480px",
                    ),

                ).sx(
                    max_width="860px", margin="0 auto",
                    padding="5rem 2rem 3rem",
                ),
            ).sx(background=BG),

            # STEPS
            Div(
                Div(
                    Span("Como começar").sx(
                        font_family=SANS, font_size="0.65rem",
                        letter_spacing="0.2em", text_transform="uppercase",
                        color=MUTED2, display="block", margin_bottom="1.5rem",
                        font_weight="500",
                    ),
                    Div(
                        step_card("1", "Instale a lib",
                                  "pip install tupyx",
                                  "Disponível no PyPI. Recomendamos usar um virtualenv."),
                        step_card("2", "Crie seu app",
                                  "tupyx init meu-app",
                                  "Gera a estrutura inicial com app.py e a pasta pages/."),
                        step_card("3", "Rode com hot reload",
                                  "tupyx run app.py",
                                  "Salve o arquivo e o browser atualiza automaticamente."),
                    ).sx(display="flex", gap="1rem"),
                ).sx(
                    max_width="860px", margin="0 auto", padding="3rem 2rem",
                ),
            ).sx(
                background=SURFACE,
                border_top=f"1px solid {BORDER}",
                border_bottom=f"1px solid {BORDER}",
            ),

            # FOOTER
            Div(
                Div(
                    Div(
                        Span("●").sx(color=BLUE),
                        Span("tupyx").sx(
                            font_family=MONO, font_size="0.75rem",
                            font_weight="bold", color=TEXT,
                        ),
                        Span("v0.1.0").sx(
                            font_family=MONO, font_size="0.65rem", color=MUTED2,
                        ),
                    ).sx(display="flex", align_items="center", gap="0.5rem"),
                    Span("localhost:8000").sx(
                        font_family=MONO, font_size="0.65rem", color=MUTED2,
                    ),
                ).sx(
                    max_width="860px", margin="0 auto", padding="0 2rem",
                    display="flex", justify_content="space-between", align_items="center",
                ),
            ).sx(
                border_top=f"1px solid {BORDER}",
                padding="1.5rem 0", background=BG,
            ),

        ).sx(
            background=BG, color=TEXT,
            min_height="100vh", margin="0", padding="0",
        ),
    )
'''

# pyproject.toml — configuração do projeto Python
PYPROJECT_TOML = '''\
[project]
name = "{name}"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = ["tupyx"]
'''

# .gitignore — arquivos a ignorar no controle de versão
GITIGNORE = '''\
__pycache__/
.venv/
*.pyc
*.pyo
.env
.DS_Store
'''


# ── Comando init ──────────────────────────────────────────────────────────────

def init(name: str):
    """
    Cria a estrutura de um novo projeto tupyx:

        <nome>/
        ├── app.py              ← ponto de entrada (run)
        ├── pages/
        │   └── home.py         ← página inicial com rota "/"
        ├── pyproject.toml
        └── .gitignore

    Parâmetros:
        name — nome do projeto (também é o nome da pasta criada)
    """
    project_dir = os.path.join(os.getcwd(), name)

    if os.path.exists(project_dir):
        print(f"{Colors.YELLOW}Pasta '{name}' já existe.{Colors.RESET}")
        sys.exit(1)

    # Pastas a criar
    folders = [
        project_dir,
        os.path.join(project_dir, "pages"),
    ]

    # Arquivos a criar com seus conteúdos
    files = {
        os.path.join(project_dir, "app.py"):
            APP_PY.replace("{name}", name),

        os.path.join(project_dir, "pages", "home.py"):
            DEFAULT_PAGE_PY,

        os.path.join(project_dir, "pyproject.toml"):
            PYPROJECT_TOML.replace("{name}", name),

        os.path.join(project_dir, ".gitignore"):
            GITIGNORE,
    }

    for folder in folders:
        os.makedirs(folder, exist_ok=True)

    for path, content in files.items():
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)

    print(f"\n{Colors.BGREEN}✓ Projeto '{name}' criado!{Colors.RESET}\n")
    print(f"  {Colors.WHITE}cd {name}{Colors.RESET}")
    print(f"  {Colors.WHITE}tupyx run app.py{Colors.RESET}\n")


# ── Entrypoint principal ───────────────────────────────────────────────────────

def main():
    """
    Ponto de entrada do comando `tupyx` no terminal.
    Chamado pelo script definido em pyproject.toml.
    """
    args = sys.argv[1:]

    if not args:
        _print_help()
        sys.exit(0)

    command = args[0]

    if command == "run":
        if len(args) < 2:
            print(f"{Colors.YELLOW}Uso: tupyx run app.py{Colors.RESET}")
            sys.exit(1)
        from tupyx.watcher import watch
        watch(args[1])

    elif command == "init":
        if len(args) < 2:
            print(f"{Colors.YELLOW}Uso: tupyx init <nome-do-projeto>{Colors.RESET}")
            sys.exit(1)
        init(args[1])

    else:
        print(f"{Colors.YELLOW}Comando '{command}' não reconhecido.{Colors.RESET}")
        _print_help()
        sys.exit(1)


def _print_help():
    print(f"""
{Colors.BGREEN}tupyx{Colors.RESET} — framework Python para dashboards reativos

{Colors.WHITE}Comandos:{Colors.RESET}

  {Colors.BGREEN}tupyx init{Colors.RESET} <nome>     Cria um novo projeto
  {Colors.BGREEN}tupyx run{Colors.RESET}  <arquivo>   Inicia o servidor com hot-reload
""")
