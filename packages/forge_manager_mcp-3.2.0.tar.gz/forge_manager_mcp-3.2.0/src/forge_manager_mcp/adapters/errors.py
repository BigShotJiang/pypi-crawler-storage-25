"""Common exception hierarchy for the PlatformAdapter contract (3.0 / Phase 2).

Renames the 2.4.0-line ``GitHubUnavailableError`` to
``ForgeUnavailableError`` per OQ6 — the 3.0 abstraction sits above
multiple platforms, so a GitHub-named exception is no longer correct.
The semantics are unchanged: every adapter raises ``ForgeUnavailableError``
for service-availability failures (suspension, rate limit, network),
and adapters / handlers can use ``is_forge_unavailable(exc)`` to
decide whether to fall back / queue replay.

Adapters MAY raise additional, more specific exceptions that subclass
``ForgeError``. The ``is_forge_unavailable`` predicate accepts any
exception type and returns False for non-forge errors.
"""
from __future__ import annotations

import httpx


class ForgeError(RuntimeError):
    """Base for any adapter-raised error.

    Carries optional ``status_code`` (HTTP status when applicable) and
    ``body`` (response body for diagnosis) fields, matching the 2.x
    GitHubError shape. Adapters may subclass for backend-specific
    error categories (rate-limit, validation, etc.).
    """

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        body: str = "",
    ):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class ForgeUnavailableError(ForgeError):
    """Raised when a forge backend is unreachable or returning service-
    availability errors.

    Subclass of ``ForgeError``, so existing ``except ForgeError`` clauses
    catch it. Phase 2's ``with_local_fallback`` decorator (refactored in
    Phase 6 to per-adapter dispatch) catches this specifically.

    Triggered by:
      - HTTP 401 / 403 (unauthorized / forbidden — could be account suspension)
      - HTTP 429 (rate limit)
      - HTTP 5xx service responses (502 / 503 / 504)
      - Network errors (timeout, DNS, connect refused)

    Reserved for "we couldn't talk to the backend." Caller-fault errors
    (404 / 422 / malformed query) raise base ``ForgeError`` and are NOT
    classified as unavailable — those propagate.
    """

    pass


class InvalidArtifactRefError(ForgeError):
    """Raised when an ArtifactRef does not resolve on the backend.

    The fix is client-side (caller passed a stale or bogus ref). Tool
    layer must NOT buffer the failing operation — retry would fail
    identically. Distinct from ``ForgeUnavailableError`` because
    fallback wouldn't help.
    """

    def __init__(self, param_name: str, value: str):
        self.param_name = param_name
        self.value = value
        super().__init__(
            f"{param_name} does not resolve to a reachable forge artifact: `{value}`"
        )


# Status codes the predicate classifies as "service unavailable"
# rather than caller-fault.
_UNAVAILABLE_STATUS_CODES = frozenset({401, 403, 429, 502, 503, 504})


def is_forge_unavailable(exc: BaseException) -> bool:
    """Predicate: should this exception trigger fallback / replay queue?

    Returns True for failures classified as backend-side service /
    availability problems. Returns False for caller-fault errors
    (404 not-found, 422 validation, malformed query) and for any
    non-forge exception class.

    Phase 2 (#266) — used by adapter-routing logic to decide whether
    to switch to a different replication target on a failed call.
    Phase 6 (#270) extends this to per-adapter state-machine
    transitions.
    """
    # Direct subclass match — anything explicitly raised as unavailable.
    if isinstance(exc, ForgeUnavailableError):
        return True
    # Status-code match — covers ForgeError raised with a known
    # status_code field. Defensive; current code raises the subclass
    # directly, but the predicate must still recognize a base-class
    # error with a service-class status.
    if isinstance(exc, ForgeError):
        if exc.status_code in _UNAVAILABLE_STATUS_CODES:
            return True
        # Network-error case: ForgeError raised from httpx without
        # a status code, with the underlying httpx exception linked
        # via __cause__ (raise X from exc semantics).
        if exc.status_code is None and exc.__cause__ is not None:
            if isinstance(exc.__cause__, httpx.TimeoutException):
                return True
            if isinstance(exc.__cause__, httpx.RequestError):
                return True
    return False
