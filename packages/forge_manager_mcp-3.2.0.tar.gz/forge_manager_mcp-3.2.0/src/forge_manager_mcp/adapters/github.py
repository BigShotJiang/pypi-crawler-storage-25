"""GitHubAdapter — PlatformAdapter implementation for github.com (3.0 / Phase 2 sub-run B).

Thin wrapper over the existing ``forge_manager_mcp.github.*`` modules.
Each method delegates to the corresponding pre-3.0 GraphQL function and
shapes the response into the canonical ``adapters/types.py`` shapes.

Token handling matches the 2.x convention: ``gh auth token`` subprocess
invocation. No token-file override; if the operator wants a non-default
token, set ``GH_TOKEN`` in the environment before MCP server start.

Project-board operations (add_to_project / move_project_item) are
GitHub-specific. Other adapters (Forgejo, GitLab, LocalStore) implement
them as no-ops or via their own project surfaces — see those adapters'
docstrings.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any, ClassVar

from . import errors as _errors
from ..github import discussions as _gh_discussions
from ..github import issues as _gh_issues
from ..github import projects as _gh_projects
from ..github import recovery as _gh_recovery
from ..github import resolvers as _gh_resolvers
from ..github import scaffold as _gh_scaffold
from ..github import triage as _gh_triage
from ..parsers import parse_owner_repo
from .types import (
    ArtifactRef,
    BootstrapResult,
    Comment,
    Discussion,
    DriftReport,
    Issue,
    Milestone,
    RecoveryBundle,
    Release,
    RemoteChange,
    SearchResult,
)


# GitHub's default Status options on a freshly-created ProjectV2 board.
# Mirrors the constant in infra.py — adapter-local copy avoids the
# leaf-clean rule violation that importing from server.handlers would
# entail. If we see exactly this set on an existing board it's safe to
# clobber with the canonical STATUS_OPTIONS; anything else is custom
# operator state and we surface a manual-step note instead.
_GITHUB_PROJECT_V2_DEFAULT_STATUS: frozenset[str] = frozenset(
    {"Todo", "In Progress", "Done"}
)


# Discussion categories every GitHub-bootstrapped project needs on
# the dev repo. ``Announcements`` is GitHub's default and auto-created
# when Discussions is enabled, so it's not in this list — present-
# detection at bootstrap-time relies on Announcements showing up
# automatically. The four below are operator-creates (GitHub has no
# API for category creation; bootstrap pauses with a copy-pasteable
# instruction block when any are missing).
_GITHUB_REQUIRED_CATEGORIES: tuple[str, ...] = (
    "Architecture",
    "UX / UI",
    "Ideas",
    "claude-use-only",
)

# Standard label catalogue seeded on every GitHub-bootstrapped repo
# pair. Mirrors the server.helpers STANDARD_LABELS set; duplicated
# here rather than imported because adapters must stay leaf-clean
# (helpers.py pulls in the handler stack).
_GITHUB_STANDARD_LABELS: tuple[tuple[str, str, str], ...] = (
    ("bug", "d73a4a", "Something isn't working"),
    ("feature", "a2eeef", "New feature or enhancement"),
    ("refactor", "ededed", "Internal restructure with no external behaviour change"),
    ("rfc", "fbca04", "RFC for a significant change"),
    ("chore", "cccccc", "Tooling, deps, config, CI"),
    ("area:skill", "0e8a16", "Changes to the forge-manager skill prose"),
    ("area:mcp", "0e8a16", "Changes to MCP server code or behaviour"),
    ("area:public-mirror", "5319e7", "Triaged from or targeted at a public mirror"),
    ("area:bootstrap", "5319e7", "Bootstrap sequence"),
)


class GitHubAdapter:
    """PlatformAdapter for github.com via GraphQL + REST.

    Constructed with a config dict from ``forge-config.json.platforms[]``.
    Token retrieved lazily via ``gh auth token``; matches existing 2.x
    behavior.
    """

    platform_id: ClassVar[str] = "github"
    has_scaffold: ClassVar[bool] = True
    """C2 fully absorbed: ``bootstrap_project`` creates the repo trio,
    seeds the standard label set, ensures Discussions enabled +
    canonical categories present (pause-and-instruct on missing),
    creates the ProjectV2 board with read-diff-write Status field,
    and seeds the Project Index + Session Lock Discussions. The
    legacy ``server/handlers/infra.py::scaffold_project`` retains
    forge-config.json emission + CLAUDE.md generation +
    .mcp.json wiring — those are project-state concerns rather than
    GitHub-state, so they stay handler-side; the multi-platform
    ``scaffold_project_multi`` orchestrates."""
    has_session_event_surface: ClassVar[bool] = False
    """Session events on GitHub are Discussion comments on the Session
    Lock Discussion — addressed by the handler via append_comment /
    list_comments rather than a dedicated Protocol surface."""

    def __init__(self, *, token: str, owner: str | None = None, repo: str | None = None):
        self._token = token
        self._default_owner = owner
        self._default_repo = repo

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "GitHubAdapter":
        """Construct from a forge-config.json platform entry.

        Expected shape:

            {"id": "github", "owner": "...", "private": "...-dev",
             "public": "...", "docs": "...-docs"}

        Token comes from ``gh auth token`` (existing 2.x convention).
        """
        # Lazy import — avoid circular at module-load time.
        from ..config import get_github_token

        token = get_github_token()
        return cls(
            token=token,
            owner=config.get("owner"),
            repo=config.get("private"),
        )

    # =====================================================================
    # Repo-level reads
    # =====================================================================

    async def get_repo_node_id(self, owner: str, repo: str) -> str:
        return await _gh_resolvers.get_repo_node_id(self._token, owner, repo)

    async def get_repo_visibility(self, owner: str, repo: str) -> str | None:
        # PAR-3: Protocol method delegates to the existing GraphQL helper.
        return await _gh_resolvers.get_repo_visibility(
            self._token, owner, repo,
        )

    async def list_milestones(
        self, owner: str, repo: str, state: str = "all"
    ) -> list[Milestone]:
        raw = await _gh_recovery.list_milestones_with_progress(
            self._token, owner=owner, repo=repo, state=state,
        )
        return [_milestone_from_dict(m) for m in raw]

    async def find_milestone(
        self, owner: str, repo: str, name_or_number: str | int
    ) -> Milestone | None:
        if isinstance(name_or_number, int):
            # Number-based — fetch the milestone list and filter.
            for m in await self.list_milestones(owner, repo, state="all"):
                if m.number == name_or_number:
                    return m
            return None
        # Title-based.
        m_dict = await _gh_recovery.get_milestone_by_title(
            self._token, owner=owner, repo=repo, title=name_or_number,
        )
        return _milestone_from_dict(m_dict) if m_dict else None

    # =====================================================================
    # Issue operations
    # =====================================================================

    async def create_issue(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        body: str,
        labels: list[str],
        milestone: str | int | None = None,
    ) -> Issue:
        # Resolve repo + label + milestone IDs in a single gather. Mirrors
        # the pre-#274 handler shape (#179, #180, #232) — one round-trip
        # for all lookups instead of (repo) → (labels) → (milestone).
        import asyncio

        lookups: list = [_gh_resolvers.get_repo_node_id(self._token, owner, repo)]
        lookups.extend(
            _gh_issues.get_label_id(self._token, owner, repo, name) for name in labels
        )
        if milestone is not None:
            lookups.append(
                _gh_resolvers.find_milestone_node_id(self._token, owner, repo, milestone)
            )

        results = await asyncio.gather(*lookups)
        repo_id = results[0]
        label_ids = list(results[1 : 1 + len(labels)])
        milestone_id = results[1 + len(labels)] if milestone is not None else None

        raw = await _gh_issues.create_issue(
            self._token, repo_id, title, body, list(label_ids),
            milestone_id=milestone_id,
        )
        return _issue_from_dict(raw, owner=owner, repo=repo, labels=labels, milestone=str(milestone) if milestone is not None else None)

    async def get_issue(self, owner: str, repo: str, number: int) -> Issue:
        # github layer doesn't have a get_issue-by-number; fetch via search.
        # Calls _gh_recovery.search_issues directly (returns the raw
        # dict shape) rather than self.search_issues (returns
        # SearchResult) — this is an internal helper, not the public
        # adapter method.
        raw = await _gh_recovery.search_issues(
            self._token,
            user_query=f"repo:{owner}/{repo} type:issue {number}",
            owner=owner, repo=repo,
            state="all", labels=None, milestone=None,
            limit=1,
        )
        for hit in raw.get("results", []):
            if hit.get("number") == number:
                return _issue_from_dict(hit, owner=owner, repo=repo)
        raise _errors.InvalidArtifactRefError("issue number", str(number))

    async def get_issue_body(self, ref: ArtifactRef) -> str:
        # Wraps the existing get_issue_body GraphQL helper. Returns
        # the body string verbatim — handler layer applies the size
        # guardrail.
        return await _gh_issues.get_issue_body(self._token, ref.native_id)

    async def update_issue_body(
        self, ref: ArtifactRef, new_body: str, force: bool = False
    ) -> None:
        # Size-guardrail enforcement happens at the handler layer (utils.check_overwrite_size).
        await _gh_issues.update_issue_body(self._token, ref.native_id, new_body)

    async def close_issue(
        self, ref: ArtifactRef, state_reason: str = "completed"
    ) -> Issue:
        # _gh_issues.close_issue returns {"url", "closed_at"} from the
        # GraphQL closeIssue mutation. Shape into the canonical Issue
        # — title/body aren't returned, so they default to empty;
        # callers needing them can follow up with get_issue_by_ref
        # (Phase C1).
        from datetime import datetime, timezone
        raw = await _gh_issues.close_issue(
            self._token, ref.native_id, state_reason=state_reason,
        )
        closed_at_str = raw.get("closed_at") or raw.get("closedAt")
        if closed_at_str:
            try:
                closed_at = datetime.fromisoformat(
                    closed_at_str.replace("Z", "+00:00"),
                )
            except (ValueError, AttributeError):
                closed_at = datetime.now(timezone.utc)
        else:
            closed_at = datetime.now(timezone.utc)
        return Issue(
            ref=ref,
            title="",
            body="",
            state="closed",
            url=raw.get("url", "") or "",
            updated_at=closed_at,
        )

    async def add_label(self, ref: ArtifactRef, label_name: str) -> None:
        # Resolve to label ID then add. Matches close_triaged_public_issues pattern.
        from ..github.triage import add_label_to_issue
        label_id = await _gh_issues.get_label_id(
            self._token, ref.owner, ref.repo, label_name,
        )
        await add_label_to_issue(self._token, ref.native_id, label_id)

    async def remove_label(self, ref: ArtifactRef, label_name: str) -> None:
        # Not yet wrapped in github/*; raise so callers know to add the wrapper.
        raise NotImplementedError(
            "remove_label not yet implemented in github layer; "
            "add github.issues.remove_label_from_issue first."
        )

    async def search_issues(
        self,
        *,
        owner: str,
        repo: str,
        query: str = "",
        state: str = "all",
        labels: list[str] | None = None,
        milestone: str | None = None,
        limit: int = 30,
    ) -> SearchResult:
        raw = await _gh_recovery.search_issues(
            self._token,
            user_query=query, owner=owner, repo=repo,
            state=state, labels=labels, milestone=milestone, limit=limit,
        )
        return SearchResult(
            results=[
                _issue_from_dict(hit, owner=owner, repo=repo)
                for hit in raw.get("results", [])
            ],
            total_count=int(raw.get("total_count", 0)),
            query=raw.get("query", "") or query,
        )

    async def list_open_issues(
        self, *, owner: str, repo: str, limit: int = 100
    ) -> list[Issue]:
        raw = await _gh_recovery.list_open_issues(
            self._token, owner=owner, repo=repo, limit=limit,
        )
        return [_issue_from_dict(item, owner=owner, repo=repo) for item in raw]

    # =====================================================================
    # Discussion operations
    # =====================================================================

    async def create_discussion(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        body: str,
        category: str | None = None,
    ) -> Discussion:
        # GitHub Discussions need a category node ID. Phase 2 leaves the
        # category-name → category-ID mapping to the handler layer (which
        # has ctx.config.discussion_categories). The adapter accepts a
        # category NAME and the handler-layer caller pre-resolves to an ID
        # via ctx.config before calling. For cleaner separation, a future
        # iteration could move the mapping into the adapter via from_config.
        raise NotImplementedError(
            "GitHubAdapter.create_discussion needs category resolution from "
            "ctx.config.discussion_categories — currently performed at the "
            "handler layer. Either pass the category node ID directly or "
            "extend GitHubAdapter.from_config to accept a category map."
        )

    async def get_discussion(
        self, owner: str, repo: str, number: int
    ) -> Discussion:
        raise NotImplementedError(
            "github layer doesn't have a get_discussion-by-number wrapper; "
            "add github.discussions.get_discussion_by_number first."
        )

    async def get_discussion_body(self, ref: ArtifactRef) -> str:
        return await _gh_discussions.get_discussion_body(self._token, ref.native_id)

    async def update_discussion_body(
        self, ref: ArtifactRef, new_body: str, force: bool = False
    ) -> None:
        await _gh_discussions.update_discussion_body(self._token, ref.native_id, new_body)

    async def list_recent_discussions(
        self, *, owner: str, repo: str, since_days: int = 7
    ) -> list[Discussion]:
        raw = await _gh_recovery.list_recent_discussions(
            self._token, owner=owner, repo=repo, since_days=since_days,
        )
        return [_discussion_from_dict(d, owner=owner, repo=repo) for d in raw]

    async def mark_decided(self, ref: ArtifactRef) -> None:
        # 3.0 generalizes "decided" to a portable label that works on
        # every backend. GitHub's comment-level Answer feature lives
        # on `mark_answer` — callers that want both call both.
        await self.add_label(ref, "decided")

    async def mark_answer(self, comment_ref: ArtifactRef) -> None:
        if comment_ref.kind != "comment":
            raise ValueError(
                f"mark_answer expects ref.kind=='comment', got {comment_ref.kind!r}"
            )
        await _gh_discussions.mark_discussion_answer(
            self._token, comment_ref.native_id,
        )

    # =====================================================================
    # Comment operations
    # =====================================================================

    async def append_comment(self, target: ArtifactRef, body: str) -> Comment:
        if target.kind == "discussion":
            raw = await _gh_discussions.add_discussion_comment(
                self._token, target.native_id, body,
            )
        elif target.kind == "issue":
            raw = await _gh_issues.add_issue_comment(
                self._token, target.native_id, body,
            )
        else:
            raise ValueError(f"append_comment: unsupported target.kind={target.kind!r}")
        return _comment_from_dict(raw, parent=target)

    async def list_comments(
        self,
        target: ArtifactRef,
        *,
        since_days: int | None = None,
        limit: int | None = None,
    ) -> list[Comment]:
        if target.kind == "discussion":
            raw = await _gh_discussions.get_discussion_comments(
                self._token, target.native_id,
            )
        else:
            raw = await _gh_recovery.list_thread_comments(
                self._token,
                thread_id=target.native_id,
                thread_type=target.kind,
                since_days=since_days,
            )
        comments = [_comment_from_dict(c, parent=target) for c in raw]
        if limit is not None and len(comments) > limit:
            # Most-recent N after the chronological order from the
            # underlying read.
            comments = comments[-limit:]
        return comments

    # =====================================================================
    # Label management
    # =====================================================================

    async def ensure_label(
        self,
        *,
        owner: str,
        repo: str,
        name: str,
        color: str = "0E8A16",
        description: str = "",
    ) -> str:
        from ..github.triage import ensure_fixedin_label
        # ensure_fixedin_label is generalized — works for any label name.
        # For now use it; future cleanup may rename.
        existing = await _gh_triage.find_label_id_or_none(
            self._token, owner=owner, repo=repo, name=name,
        )
        if existing is not None:
            return existing
        return await _gh_scaffold.create_label(
            self._token, owner=owner, repo=repo,
            name=name, color=color, description=description,
        )

    # =====================================================================
    # Release operations
    # =====================================================================

    async def create_release(
        self,
        *,
        owner: str,
        repo: str,
        tag: str,
        name: str,
        body: str = "",
        prerelease: bool = False,
        draft: bool = False,
    ) -> Release:
        """Create a GitHub Release page via ``gh release create`` (#282).

        Wraps the subprocess-based :func:`forge_manager_mcp.github.
        releases.create_github_release` helper. Body is written to a
        temp file (gh CLI takes ``--notes-file``, not inline notes).
        Runs from a tempdir cwd with ``--repo owner/repo`` so the
        adapter doesn't need a local clone — gh hits the API
        directly when ``--repo`` is set.

        ``prerelease`` and ``draft`` map to the corresponding gh
        flags. ``created_at`` is left None — gh release create does
        not echo the creation timestamp; callers that need it can
        re-fetch via the API.
        """
        import tempfile
        from pathlib import Path

        from ..github import releases as _gh_releases

        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".md", delete=False, encoding="utf-8"
        ) as notes_fh:
            notes_fh.write(body)
            notes_path = Path(notes_fh.name)
        try:
            # `gh release create` is happy outside a git repo when
            # --repo is set; cwd just needs to exist.
            cwd = Path(tempfile.gettempdir())
            url = _gh_releases.create_github_release(
                cwd=cwd,
                tag=tag,
                title=name,
                notes_path=notes_path,
                repo_full=f"{owner}/{repo}",
                prerelease=prerelease,
                draft=draft,
            )
        finally:
            try:
                notes_path.unlink()
            except OSError:
                pass
        return Release(
            tag=tag,
            name=name,
            body=body,
            prerelease=prerelease,
            url=url,
        )

    def get_clone_url(self, owner: str, repo: str) -> str:
        """github.com clone URL (#282)."""
        return f"https://github.com/{owner}/{repo}.git"

    def noreply_email(
        self, login: str, user_id: int | None = None
    ) -> str:
        """GitHub-conventional noreply email (#282).

        With ``user_id`` provided uses the post-2017 form
        ``{user_id}+{login}@users.noreply.github.com``; without
        ``user_id`` falls back to the legacy
        ``{login}@users.noreply.github.com`` form. GitHub accepts
        both for commit attribution.
        """
        if user_id is not None:
            return f"{user_id}+{login}@users.noreply.github.com"
        return f"{login}@users.noreply.github.com"

    async def delete_release(
        self, *, owner: str, repo: str, tag: str,
    ) -> None:
        """Delete the GitHub Release page for ``tag`` (#294 Phase A).

        Wraps ``gh release delete <tag> --repo <owner>/<repo> --yes``.
        Idempotent — exits 0 on already-deleted; surfaces
        ``Not Found`` from gh as a clean no-op rather than raising.
        """
        import subprocess
        import tempfile
        from pathlib import Path

        from ..github import releases as _gh_releases

        cwd = Path(tempfile.gettempdir())
        cmd = [
            "gh", "release", "delete", tag,
            "--repo", f"{owner}/{repo}",
            "--yes",
        ]
        try:
            _gh_releases._run(cmd, cwd=cwd, timeout=_gh_releases._GH_TIMEOUT)
        except subprocess.CalledProcessError as exc:
            stderr = (exc.stderr or "").lower()
            if "not found" in stderr or "release not found" in stderr:
                return  # idempotent — already deleted
            raise
        except _gh_releases.ReleaseCommandError as exc:
            msg = str(exc).lower()
            if "not found" in msg:
                return
            raise

    # =====================================================================
    # File-content reads
    # =====================================================================

    async def fetch_file_content(
        self, *, owner: str, repo: str, path: str, ref: str = "main"
    ) -> str | None:
        return await _gh_resolvers.get_file_content(
            self._token, owner=owner, repo=repo, path=path, ref=ref,
        )

    # =====================================================================
    # Bundled reads (Phase C5)
    # =====================================================================

    async def bundle_recover_context(
        self,
        *,
        owner: str,
        repo: str,
        toc_discussion_id: str,
        since_days: int = 7,
        issue_limit: int = 100,
    ) -> RecoveryBundle:
        # Native override: aliased GraphQL multi-query collapses every
        # recover_context read into one round-trip (#181). Convert the
        # raw shape into the canonical RecoveryBundle.
        raw = await _gh_recovery.fetch_recover_context_bundle(
            self._token, owner, repo, toc_discussion_id,
            since_days=since_days, issue_limit=issue_limit,
        )
        return RecoveryBundle(
            toc_body=raw.get("toc_body"),
            open_issues=[
                _issue_from_dict(d, owner=owner, repo=repo)
                for d in raw.get("open_issues", [])
            ],
            recent_discussions=[
                _discussion_from_dict(d, owner=owner, repo=repo)
                for d in raw.get("recent_discussions", [])
            ],
            milestones=[
                _milestone_from_dict(d) for d in raw.get("milestones", [])
            ],
        )

    # =====================================================================
    # Bootstrap (multi-platform scaffold C2 — first stage)
    # =====================================================================

    async def bootstrap_project(
        self,
        *,
        owner: str,
        project_name: str,
        description: str,
        existing_state: dict | None = None,
    ) -> BootstrapResult:
        """Bootstrap a GitHub-canonical project (C2 stages 1 + 2a).

        Creates the repo trio under ``<owner>/`` — dev (private),
        public mirror (public), docs (public) — seeds the standard
        label catalogue on dev and public, and ensures Discussions
        is enabled on the dev repo with the canonical category set
        present. Idempotent at every step: re-runs probe live state
        first (``get_repo_node_id``, ``get_repo_discussions_state``)
        and no-op when already satisfied.

        Returns ``phase = "awaiting_manual"`` when:
          * the org doesn't exist (caller creates manually,
            ``settings/organizations``);
          * required Discussion categories are missing (GitHub
            exposes no API for category creation; operator must
            click through the dev repo's Discussions settings UI).

        Returns ``phase = "awaiting_manual"`` with a generic
        legacy-completion-path note when categories are present
        but Project board + Project Index + Session Lock seeding
        haven't been absorbed yet (C2 stage 2b).
        """
        if not owner.strip():
            raise _errors.ForgeError(
                "GitHubAdapter.bootstrap_project: owner must not be empty."
            )
        if not project_name.strip():
            raise _errors.ForgeError(
                "GitHubAdapter.bootstrap_project: project_name must not be empty."
            )

        manual_steps: list[str] = []
        artifacts: dict = {}

        org_id = await _gh_scaffold.get_organization_id(self._token, owner)
        if org_id is None:
            return BootstrapResult(
                platform_id=self.platform_id,
                artifacts={"owner": owner, "org_id": None},
                manual_steps=[
                    f"Organization '{owner}' does not exist. GitHub has no "
                    "API for creating organisations. Create it manually at "
                    "https://github.com/settings/organizations and re-run "
                    "the scaffold."
                ],
                phase="awaiting_manual",
            )
        artifacts["org_id"] = org_id

        dev_repo = await self._ensure_repo(
            owner=owner, org_id=org_id, name=f"{project_name}-dev",
            visibility="PRIVATE",
            description=description or f"{project_name} — private dev, design, and archive",
        )
        public_repo = await self._ensure_repo(
            owner=owner, org_id=org_id, name=project_name,
            visibility="PUBLIC",
            description=description or f"{project_name} — public mirror",
        )
        docs_repo = await self._ensure_repo(
            owner=owner, org_id=org_id, name=f"{project_name}-docs",
            visibility="PUBLIC",
            description=description or f"{project_name} — rendered docs site",
        )
        artifacts["dev_repo"] = dev_repo
        artifacts["public_repo"] = public_repo
        artifacts["docs_repo"] = docs_repo

        labels_seeded = {
            dev_repo["name_with_owner"]: await self._seed_labels(dev_repo["id"]),
            public_repo["name_with_owner"]: await self._seed_labels(public_repo["id"]),
        }
        artifacts["labels_seeded"] = labels_seeded

        # C2 stage 2a — ensure Discussions enabled + canonical
        # categories present on the dev repo. Discussion categories
        # have no creation API (GitHub UI-only), so a missing-category
        # detection here surfaces a manual-steps pause with copy-
        # pasteable instructions.
        discussions_state = await _gh_scaffold.get_repo_discussions_state(
            self._token, dev_repo["id"],
        )
        discussions_enabled_now = False
        if not discussions_state.get("enabled"):
            await _gh_scaffold.enable_discussions(self._token, dev_repo["id"])
            discussions_enabled_now = True
            # Re-fetch so categories reflect the just-enabled state
            # (GitHub auto-creates Announcements at enable time).
            discussions_state = await _gh_scaffold.get_repo_discussions_state(
                self._token, dev_repo["id"],
            )
        artifacts["discussions"] = {
            "enabled": True,
            "enabled_now": discussions_enabled_now,
            "categories": dict(discussions_state.get("categories") or {}),
        }

        present_categories = set((discussions_state.get("categories") or {}).keys())
        missing_categories = [
            name for name in _GITHUB_REQUIRED_CATEGORIES
            if name not in present_categories
        ]
        if missing_categories:
            categories_url = (
                f"https://github.com/{dev_repo['name_with_owner']}"
                "/discussions/categories"
            )
            manual_steps.append(
                f"Discussion categories missing on {dev_repo['name_with_owner']}: "
                f"{', '.join(missing_categories)}. GitHub has no API for "
                f"category creation — create them manually at {categories_url} "
                f"with formats: Architecture (Q&A), UX / UI (Open-ended), "
                f"Ideas (Open-ended), claude-use-only (Open-ended). Then "
                f"re-run scaffold."
            )
            return BootstrapResult(
                platform_id=self.platform_id,
                artifacts=artifacts,
                manual_steps=manual_steps,
                phase="awaiting_manual",
            )

        # C2 stage 2b-i — Project board absorption. Idempotent via
        # list_owner_projects (match by title); status field gets the
        # canonical option set via read-diff-write. Pre-existing
        # boards with custom Status options surface a manual-step
        # note rather than getting clobbered.
        project_board, board_manual_step = await self._ensure_project_board(
            org_id=org_id,
            project_title=project_name,
            dev_repo_id=dev_repo["id"],
            public_repo_id=public_repo["id"],
        )
        artifacts["project_board"] = project_board
        if board_manual_step is not None:
            manual_steps.append(board_manual_step)

        # C2 stage 2b-ii — Project Index + Session Lock Discussion
        # seeding absorption. Idempotency comes via existing_state:
        # callers (multi-platform handler reading forge-config.json)
        # pass prior IDs in ``existing_state["github"]``; the adapter
        # reuses them when present, creates otherwise. Without
        # existing_state threading, a re-run creates duplicates —
        # this is the same pre-3.0 behavior of the legacy handler
        # before its existing_config check was added, and matches
        # the legacy convention that idempotency-state lives in
        # forge-config.json, not in GitHub.
        gh_state = (existing_state or {}).get("github", {}) or {}
        announcements_id = (
            discussions_state.get("categories", {}).get(
                "Announcements", {},
            ).get("id")
        )
        if not announcements_id:
            # The Announcements category is GitHub's default and
            # should auto-create with Discussions; if it's missing
            # we can't seed. Surface as manual-step.
            manual_steps.append(
                "Announcements Discussion category missing from "
                f"{dev_repo['name_with_owner']} — Project Index + "
                "Session Lock Discussions cannot be seeded. Verify "
                "Discussions is enabled on the repo and the default "
                "Announcements category exists."
            )
            return BootstrapResult(
                platform_id=self.platform_id,
                artifacts=artifacts,
                manual_steps=manual_steps,
                phase="awaiting_manual",
            )

        project_discussion_id = gh_state.get("project_discussion_id")
        project_discussion_created_now = False
        if not project_discussion_id:
            disc = await _gh_discussions.create_discussion(
                self._token,
                dev_repo["id"],
                announcements_id,
                f"{project_name} — Project",
                (
                    "Project Discussion (navigation hub).\n\n"
                    "The server's `update_project_toc` will populate this "
                    "post with the living Discussions + Issues TOC on the "
                    "next turn that touches a tracked thread."
                ),
            )
            project_discussion_id = disc["id"]
            project_discussion_created_now = True

        session_lock_discussion_id = gh_state.get("session_lock_discussion_id")
        session_lock_created_now = False
        if not session_lock_discussion_id:
            disc = await _gh_discussions.create_discussion(
                self._token,
                dev_repo["id"],
                announcements_id,
                f"{project_name} — Session Lock",
                (
                    "Session Lock Discussion.\n\n"
                    "`open_session` posts a session-opened comment here; "
                    "`close_session` posts a session-closed comment with "
                    "the session summary. One session at a time, "
                    "serialised through this discussion."
                ),
            )
            session_lock_discussion_id = disc["id"]
            session_lock_created_now = True

        artifacts["project_discussion_id"] = project_discussion_id
        artifacts["session_lock_discussion_id"] = session_lock_discussion_id
        artifacts["project_discussion_created_now"] = project_discussion_created_now
        artifacts["session_lock_created_now"] = session_lock_created_now

        # C2 fully absorbed. The handler-side scaffold_project_multi
        # can now drive GitHub bootstrap end-to-end via this method;
        # the legacy infra.py::scaffold_project becomes a deprecation
        # candidate. Phase = complete (modulo any manual step the
        # status-field path emitted above).
        phase = "awaiting_manual" if manual_steps else "complete"
        return BootstrapResult(
            platform_id=self.platform_id,
            artifacts=artifacts,
            manual_steps=manual_steps,
            phase=phase,
        )

    async def _ensure_project_board(
        self,
        *,
        org_id: str,
        project_title: str,
        dev_repo_id: str,
        public_repo_id: str,
    ) -> tuple[dict, str | None]:
        """Idempotent ProjectV2 board ensure.

        Returns ``(project_board_descriptor, manual_step_or_None)``.
        The manual_step is non-None when a pre-existing board has
        custom Status options that don't match the canonical
        ``STATUS_OPTIONS`` and don't match GitHub's default fresh-
        project options either — clobbering would lose existing
        Status assignments, so the operator gets a UI hint instead.
        """
        existing = [
            p for p in await _gh_projects.list_owner_projects(self._token, org_id)
            if p.get("title") == project_title
        ]
        if existing:
            project = existing[0]
            project_created_now = False
        else:
            project = await _gh_projects.create_projectv2(
                self._token, org_id, project_title,
            )
            project_created_now = True

        await _gh_projects.link_projectv2_to_repo(
            self._token, project["id"], dev_repo_id,
        )
        await _gh_projects.link_projectv2_to_repo(
            self._token, project["id"], public_repo_id,
        )

        status_field = await _gh_projects.get_project_status_field(
            self._token, project["id"],
        )
        current_names = set(status_field["options"].keys())
        desired_names = set(_gh_projects.STATUS_OPTIONS)
        manual_step: str | None = None
        if current_names == desired_names:
            pass  # already correct
        elif project_created_now or current_names == _GITHUB_PROJECT_V2_DEFAULT_STATUS:
            status_field = await _gh_projects.update_projectv2_status_options(
                self._token, project["id"], status_field["field_id"],
                _gh_projects.STATUS_OPTIONS,
            )
        else:
            manual_step = (
                f"Project board {project.get('url', '')} has custom Status "
                f"options ({sorted(current_names)}). Expected: "
                f"{list(_gh_projects.STATUS_OPTIONS)}. Update them manually "
                f"under the board's ⋯ → Settings → Fields → Status."
            )

        descriptor = {
            "id": project["id"],
            "number": project["number"],
            "url": project.get("url", ""),
            "status_field_id": status_field["field_id"],
            "status_options": dict(status_field["options"]),
            "created_now": project_created_now,
        }
        return descriptor, manual_step

    async def _ensure_repo(
        self,
        *,
        owner: str,
        org_id: str,
        name: str,
        visibility: str,
        description: str,
    ) -> dict:
        """Idempotent repo creation. Probes via
        ``resolvers.get_repo_node_id``; on miss, creates via
        ``scaffold.create_repository`` mutation. Returns the
        descriptor dict shape that ``server/handlers/infra.py::
        _ensure_repo`` returns — handlers consume both paths through
        the same shape."""
        try:
            node_id = await _gh_resolvers.get_repo_node_id(self._token, owner, name)
            return {
                "id": node_id,
                "name_with_owner": f"{owner}/{name}",
                "url": f"https://github.com/{owner}/{name}",
                "created_now": False,
            }
        except _errors.ForgeError:
            pass
        # The github backend layer raises GitHubError (which is the
        # un-renamed parent of ForgeError under the 3.0 errors hierarchy).
        # Catch both for compatibility while the rename is in flight.
        except Exception:
            pass
        repo = await _gh_scaffold.create_repository(
            self._token,
            owner_id=org_id,
            name=name,
            visibility=visibility,
            description=description,
        )
        return {
            "id": repo["id"],
            "name_with_owner": repo["name_with_owner"],
            "url": repo["url"],
            "created_now": True,
        }

    async def _seed_labels(self, repo_id: str) -> list[str]:
        """Create the standard label set on a repo. Already-exists
        errors swallow silently (idempotent)."""
        created: list[str] = []
        for label_name, color, label_desc in _GITHUB_STANDARD_LABELS:
            try:
                await _gh_scaffold.create_label(
                    self._token, repo_id, label_name, color, label_desc,
                )
                created.append(label_name)
            except (_errors.ForgeError, ValueError):
                pass
        return created

    # =====================================================================
    # Health + drift (Phase 6)
    # =====================================================================

    async def probe(self) -> bool:
        try:
            from ..github.core import _graphql
            await _graphql(self._token, "{ viewer { login } }")
            return True
        except _errors.ForgeUnavailableError:
            return False
        except Exception:
            # Other forge errors (auth, etc.) still indicate the backend
            # is reachable but there's a config issue — treat as not-ok.
            return False

    async def compute_drift(self, snapshot: dict) -> DriftReport:
        # Phase 6 deliverable. For now, return a clean report — drift
        # detection logic lands when the ReplicationManager is wired.
        return DriftReport(platform_id=self.platform_id, is_clean=True)

    async def fetch_remote_changes(
        self, *, since: datetime, owner: str, repo: str,
    ) -> list[RemoteChange]:
        """Aliased GraphQL scan of issues + discussions + comments (#279).

        One round-trip selects Repository.issues + Repository.discussions
        ordered by UPDATED_AT_DESC, plus comments edges (depth-1) under
        each. Pagination: walk via ``endCursor`` while the latest item
        on the page has ``updatedAt >= since``; bail when the cursor
        falls below the watermark. Comments are filtered client-side
        on ``createdAt >= since`` because GraphQL doesn't expose a
        per-comment ``since`` filter.

        Operation detection mirrors the REST adapters:

        * ``createdAt >= since`` → ``create_issue`` / ``create_discussion``
        * ``state == CLOSED`` and ``closedAt >= since`` → ``close_issue``
        * Otherwise → ``update_body``

        Live conformance lights up when the GitHub suspension lifts;
        the implementation lands here so the live test fires
        automatically with no code change.
        """
        changes: list[RemoteChange] = []
        try:
            issues = await self._fetch_gh_artifacts_since(
                owner=owner, repo=repo, since=since, kind="issues",
            )
            discussions = await self._fetch_gh_artifacts_since(
                owner=owner, repo=repo, since=since, kind="discussions",
            )
        except _errors.ForgeUnavailableError as exc:
            return [_rate_limited_sentinel(self.platform_id, str(exc))]
        except _errors.ForgeError as exc:
            return [_rate_limited_sentinel(self.platform_id, str(exc))]

        for raw, kind in [(i, "issue") for i in issues] + [
            (d, "discussion") for d in discussions
        ]:
            ref = _make_ref(
                native_id=raw.get("id", ""),
                kind=kind,
                owner=owner,
                repo=repo,
                number=raw.get("number"),
            )
            created_at = _gh_parse_iso(raw.get("createdAt"))
            closed_at = _gh_parse_iso(raw.get("closedAt"))
            updated_at = _gh_parse_iso(raw.get("updatedAt")) or datetime.now(
                timezone.utc
            )
            state = (raw.get("state") or "OPEN").upper()
            if created_at is not None and created_at >= since:
                changes.append(
                    RemoteChange(
                        source_platform_id=self.platform_id,
                        ref=ref,
                        operation=(
                            "create_issue" if kind == "issue"
                            else "create_discussion"
                        ),
                        observed_at=created_at,
                        payload={
                            "title": raw.get("title", "") or "",
                            "body": raw.get("body", "") or "",
                            "labels": _gh_labels_from_raw(raw),
                        },
                    )
                )
            elif (
                kind == "issue"
                and state == "CLOSED"
                and closed_at is not None
                and closed_at >= since
            ):
                changes.append(
                    RemoteChange(
                        source_platform_id=self.platform_id,
                        ref=ref,
                        operation="close_issue",
                        observed_at=closed_at,
                        payload={"state_reason": "completed"},
                    )
                )
            else:
                changes.append(
                    RemoteChange(
                        source_platform_id=self.platform_id,
                        ref=ref,
                        operation="update_body",
                        observed_at=updated_at,
                        payload={"new_body": raw.get("body", "") or ""},
                    )
                )

            # Comments — depth-1, filter client-side by createdAt.
            for comment in raw.get("comments", {}).get("nodes", []) or []:
                c_created = _gh_parse_iso(comment.get("createdAt"))
                if c_created is None or c_created < since:
                    continue
                comment_ref = _make_ref(
                    native_id=comment.get("id", ""),
                    kind="comment",
                    owner=owner,
                    repo=repo,
                )
                changes.append(
                    RemoteChange(
                        source_platform_id=self.platform_id,
                        ref=comment_ref,
                        operation="add_comment",
                        observed_at=c_created,
                        payload={
                            "parent_number": ref.number,
                            "parent_kind": kind,
                            "body": comment.get("body", "") or "",
                            "author": (
                                comment.get("author", {}).get("login", "")
                                if isinstance(comment.get("author"), dict)
                                else ""
                            ),
                        },
                    )
                )

        return changes

    async def _fetch_gh_artifacts_since(
        self,
        *,
        owner: str,
        repo: str,
        since: datetime,
        kind: str,  # "issues" or "discussions"
    ) -> list[dict]:
        """Walk Repository.{issues,discussions} cursor pages until the
        bottom of the page falls below ``since`` (#279).

        Returns the raw GraphQL nodes — shaping into RemoteChange is
        the caller's job. Comments are pulled depth-1 via the same
        query so we get them in one round-trip per page.
        """
        from ..github.core import _graphql

        page_size = 50
        nodes: list[dict] = []
        cursor: str | None = None
        max_pages = 200
        for _ in range(max_pages):
            after = f', after: "{cursor}"' if cursor else ""
            comments_field = (
                'comments(first: 30) { nodes { id createdAt body author { login } } }'
            )
            if kind == "issues":
                query = f"""
                  query {{
                    repository(owner: "{owner}", name: "{repo}") {{
                      issues(first: {page_size}{after},
                             orderBy: {{ field: UPDATED_AT, direction: DESC }}) {{
                        pageInfo {{ endCursor hasNextPage }}
                        nodes {{
                          id number title body
                          state createdAt updatedAt closedAt
                          labels(first: 20) {{ nodes {{ name }} }}
                          {comments_field}
                        }}
                      }}
                    }}
                  }}
                """
            else:
                query = f"""
                  query {{
                    repository(owner: "{owner}", name: "{repo}") {{
                      discussions(first: {page_size}{after},
                                  orderBy: {{ field: UPDATED_AT, direction: DESC }}) {{
                        pageInfo {{ endCursor hasNextPage }}
                        nodes {{
                          id number title body
                          createdAt updatedAt
                          labels(first: 20) {{ nodes {{ name }} }}
                          {comments_field}
                        }}
                      }}
                    }}
                  }}
                """
            data = await _graphql(self._token, query)
            connection = (
                data.get("repository", {}).get(kind, {})
                if isinstance(data, dict)
                else {}
            )
            page = connection.get("nodes", []) or []
            if not page:
                break
            nodes.extend(page)
            # Bail when the oldest node on the page falls below since —
            # subsequent pages are even older.
            tail = page[-1]
            tail_updated = _gh_parse_iso(tail.get("updatedAt"))
            if tail_updated is not None and tail_updated < since:
                break
            page_info = connection.get("pageInfo", {}) or {}
            if not page_info.get("hasNextPage"):
                break
            cursor = page_info.get("endCursor")
            if not cursor:
                break

        # Filter to ``updatedAt >= since`` — the tail of the last page
        # may include older items past the watermark.
        kept: list[dict] = []
        for node in nodes:
            updated = _gh_parse_iso(node.get("updatedAt"))
            if updated is None or updated >= since:
                kept.append(node)
        return kept


# ---------------------------------------------------------------------------
# Internal: dict-to-canonical-type shapers
# ---------------------------------------------------------------------------

def _make_ref(
    *,
    native_id: str,
    kind: str,
    owner: str,
    repo: str,
    number: int | None = None,
) -> ArtifactRef:
    return ArtifactRef(
        platform_id="github",
        native_id=native_id,
        kind=kind,  # type: ignore[arg-type]
        owner=owner,
        repo=repo,
        number=number,
    )


def _issue_from_dict(
    d: dict,
    *,
    owner: str,
    repo: str,
    labels: list[str] | None = None,
    milestone: str | None = None,
) -> Issue:
    """Shape an Issue dict (from github/issues.py or github/recovery.py) into
    the canonical Issue type.

    Source dicts vary in shape across call sites. This shaper accepts the
    union of fields and fills in defaults for the rest.
    """
    return Issue(
        ref=_make_ref(
            native_id=d.get("id", ""),
            kind="issue",
            owner=owner,
            repo=repo,
            number=d.get("number"),
        ),
        title=d.get("title", ""),
        body=d.get("body", "") or "",
        state=("closed" if d.get("state", "open").lower() == "closed" else "open"),
        labels=(
            labels
            if labels is not None
            else [n if isinstance(n, str) else n.get("name", "") for n in d.get("labels", [])]
        ),
        milestone=milestone or _milestone_from_field(d.get("milestone")),
        author=d.get("author", "") or "",
        url=d.get("url", "") or "",
    )


def _discussion_from_dict(
    d: dict,
    *,
    owner: str,
    repo: str,
) -> Discussion:
    return Discussion(
        ref=_make_ref(
            native_id=d.get("id", ""),
            kind="discussion",
            owner=owner,
            repo=repo,
            number=d.get("number"),
        ),
        title=d.get("title", ""),
        body=d.get("body", "") or "",
        category=d.get("category"),
        labels=[n if isinstance(n, str) else n.get("name", "") for n in d.get("labels", [])],
        author=d.get("author", "") or "",
        url=d.get("url", "") or "",
    )


def _comment_from_dict(d: dict, *, parent: ArtifactRef) -> Comment:
    from datetime import datetime, timezone
    created_str = d.get("createdAt") or d.get("created_at")
    if created_str:
        try:
            created_at = datetime.fromisoformat(created_str.replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            created_at = datetime.now(timezone.utc)
    else:
        created_at = datetime.now(timezone.utc)
    return Comment(
        ref=_make_ref(
            native_id=d.get("id", ""),
            kind="comment",
            owner=parent.owner,
            repo=parent.repo,
        ),
        body=d.get("body", "") or "",
        author=d.get("author", "") or "",
        created_at=created_at,
        parent=parent,
        url=d.get("url", "") or "",
    )


def _milestone_from_dict(d: dict) -> Milestone:
    return Milestone(
        title=d.get("title", ""),
        number=d.get("number", 0),
        state=("closed" if d.get("state", "open").lower() == "closed" else "open"),
        description=d.get("description", "") or "",
        percent_complete=float(d.get("percent_complete", 0.0) or 0.0),
    )


def _milestone_from_field(field: Any) -> str | None:
    """Extract the milestone title from a recovery-bundle Issue dict's
    `milestone` field, which may be None / dict / string."""
    if field is None:
        return None
    if isinstance(field, str):
        return field
    if isinstance(field, dict):
        return field.get("title")
    return None


# ---------------------------------------------------------------------------
# fetch_remote_changes helpers (#279)
# ---------------------------------------------------------------------------


def _gh_parse_iso(text: str | None) -> datetime | None:
    """Parse a GraphQL ISO-8601 timestamp into a tz-aware datetime."""
    if not text:
        return None
    from datetime import timezone as _tz
    try:
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=_tz.utc)
    return dt


def _gh_labels_from_raw(raw: dict) -> list[str]:
    """Extract label names from a GraphQL Issue / Discussion node."""
    labels = raw.get("labels", {})
    if not isinstance(labels, dict):
        return []
    nodes = labels.get("nodes", []) or []
    return [n.get("name", "") for n in nodes if n.get("name")]


def _rate_limited_sentinel(platform_id: str, message: str) -> RemoteChange:
    """A RemoteChange that signals the fetch was truncated (#279).

    Mirrors the Forgejo / GitLab sentinels; the consumer (#294
    backfill step) detects ``operation == "rate_limited"`` and
    surfaces a manual_steps entry pointing the operator at re-running
    with a tighter ``since`` watermark.
    """
    from datetime import timezone as _tz

    sentinel_ref = ArtifactRef(
        platform_id=platform_id,
        native_id="<rate_limited>",
        kind="issue",
        owner="<unknown>",
        repo="<unknown>",
    )
    return RemoteChange(
        source_platform_id=platform_id,
        ref=sentinel_ref,
        operation="rate_limited",
        observed_at=datetime.now(_tz.utc),
        payload={"message": message},
    )
