"""Shared HTTP plumbing for REST-over-httpx adapters (DRY-B).

``ForgejoAdapter`` and ``GitLabAdapter`` both speak pure REST over
``httpx.AsyncClient`` and shared 100% of their request/response
machinery aside from three differences:

  * Auth header scheme — Forgejo uses ``token`` (Gitea convention),
    GitLab uses ``Bearer``.
  * API path prefix — Forgejo mounts under ``/api/v1``, GitLab under
    ``/api/v4``.
  * Adapter name in error messages — for telemetry.

This module lifts the shared shape into ``RestAdapterBase``;
subclasses set three class attrs (``_AUTH_SCHEME``, ``_API_PATH``,
``_ADAPTER_NAME``) and inherit ``_headers``, ``_get_client``,
``_request``, ``aclose``, plus the ``DEFAULT_TIMEOUT_S`` /
``_UNAVAILABLE_CODES`` constants.

Per-backend semantics that DON'T trivially parameterize — endpoint
path templates with platform-specific URL encoding (Forgejo's
``/repos/{owner}/{repo}``, GitLab's ``/projects/{quote(...)}``),
pagination param names (``limit`` vs ``per_page``), label-color
defaults — stay inline at the call site. Lifting them would add
template-attr complexity without saving much code.
"""
from __future__ import annotations

from typing import Any, ClassVar

import httpx

from . import errors as _errors


DEFAULT_TIMEOUT_S = 30.0
"""Httpx request timeout (seconds). Liberal for the slow paths
(GraphQL composite reads, pagination over large repos)."""


_UNAVAILABLE_CODES: frozenset[int] = frozenset({401, 403, 429, 502, 503, 504})
"""HTTP status codes that map to ``ForgeUnavailableError`` (the
ReplicationManager treats these as transient and falls through to
the next adapter). Other 4xx / 5xx map to ``ForgeError``."""


class RestAdapterBase:
    """Mixin/base class for adapters that speak pure REST over httpx.

    Subclasses must set the three ClassVar attrs below and provide a
    ``self._token`` and ``self._api_base`` instance attribute pair
    (``__init__`` stores them).
    """

    _AUTH_SCHEME: ClassVar[str]
    """Authorization header scheme — e.g. ``"token"`` (Gitea/Forgejo)
    or ``"Bearer"`` (GitLab, GitHub)."""

    _API_PATH: ClassVar[str]
    """REST API path prefix below ``self._api_base`` — e.g.
    ``"/api/v1"`` (Forgejo) or ``"/api/v4"`` (GitLab). Concatenated
    with the base URL when the httpx client is built."""

    _ADAPTER_NAME: ClassVar[str]
    """Adapter name used in error messages (so the operator can tell
    a Forgejo timeout from a GitLab timeout in logs)."""

    # Type stubs — subclasses set these in their own __init__ and the
    # methods below access them through self.
    _token: str
    _api_base: str
    _client: httpx.AsyncClient | None

    # ------------------------------------------------------------------
    # HTTP client lifecycle
    # ------------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"{self._AUTH_SCHEME} {self._token}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=f"{self._api_base}{self._API_PATH}",
                timeout=DEFAULT_TIMEOUT_S,
                headers=self._headers(),
            )
        return self._client

    async def aclose(self) -> None:
        """Close the underlying httpx client. Tests + lifecycle hooks
        should call this; otherwise GC handles it."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    # ------------------------------------------------------------------
    # Request dispatch
    # ------------------------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any = None,
        allow_404_as_none: bool = False,
    ) -> Any:
        """Issue an authenticated REST call; classify failures.

        Returns parsed JSON on 2xx, ``None`` on 404 if
        ``allow_404_as_none``. Raises ``ForgeUnavailableError`` on the
        service-unavailable status set, ``ForgeError`` otherwise.
        """
        client = await self._get_client()
        try:
            response = await client.request(method, path, params=params, json=json)
        except httpx.TimeoutException as exc:
            raise _errors.ForgeUnavailableError(
                f"{self._ADAPTER_NAME}: timeout calling {method} {path}",
            ) from exc
        except httpx.RequestError as exc:
            raise _errors.ForgeUnavailableError(
                f"{self._ADAPTER_NAME}: network error calling "
                f"{method} {path}: {exc}",
            ) from exc

        status = response.status_code
        if 200 <= status < 300:
            if status == 204 or not response.content:
                return None
            try:
                return response.json()
            except ValueError:
                return response.text

        body_text = response.text[:4096]
        if status == 404 and allow_404_as_none:
            return None
        if status in _UNAVAILABLE_CODES:
            raise _errors.ForgeUnavailableError(
                f"{self._ADAPTER_NAME}: HTTP {status} from {method} {path}",
                status_code=status,
                body=body_text,
            )
        raise _errors.ForgeError(
            f"{self._ADAPTER_NAME}: HTTP {status} from {method} {path}",
            status_code=status,
            body=body_text,
        )
