"""ForgejoAdapter — PlatformAdapter implementation for Forgejo / Codeberg
(3.0 / Phase 3 sub-run A).

One adapter class handles every Forgejo deployment:

  * Hosted Codeberg at ``https://codeberg.org``
    (``platform_id="codeberg"``, token at ``~/.codeberg-token``)
  * Self-hosted Forgejo at any URL
    (``platform_id="forgejo"``, token at ``~/.forgejo-token``)

Identity is selected via ``platform_id`` in the
``forge-config.json.platforms[]`` config blob, with ``url`` providing
the API base for self-hosted instances. Codeberg's URL is hard-coded
when ``platform_id == "codeberg"`` because there is exactly one
codeberg.org.

The Forgejo REST API is Gitea-derived; this adapter speaks pure REST
over httpx.AsyncClient. Auth header is ``Authorization: token <T>``
(Gitea/Forgejo convention, distinct from GitHub's ``Bearer``).

Forgejo has no native Discussions surface. Per OQ1, Discussions are
modeled as Issues with the reserved ``kind:discussion`` + ``category:*``
labels. The adapter transparently presents them through the canonical
``Discussion`` type.
"""
from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, ClassVar

import httpx

from . import errors as _errors
from . import _recovery
from ._common import (
    find_milestone_by_title_in_list as _find_milestone_by_title_in_list,
    label_names_from_api as _label_names_from_api,
    milestone_title_from_api as _milestone_title_from_api,
    parse_iso as _parse_iso,
)
from . import _rest_base
from .types import (
    ArtifactRef,
    BootstrapResult,
    Comment,
    Discussion,
    DriftReport,
    Issue,
    Milestone,
    RecoveryBundle,
    Release,
    RemoteChange,
    SearchResult,
)


# Label catalogue every Forgejo-bootstrapped project gets. Mirrors the
# top-level STANDARD_LABELS set in server/helpers.py — duplicated here
# rather than imported because helpers.py pulls in the MCP server
# stack (handlers, dispatch) and adapters must stay leaf-clean. Kept
# as a tuple so a config-time override can prepend project-specific
# labels without mutating the canonical set.
_FORGEJO_STANDARD_LABELS: tuple[tuple[str, str, str], ...] = (
    ("bug", "d73a4a", "Something isn't working"),
    ("feature", "a2eeef", "New feature or enhancement"),
    ("refactor", "ededed", "Internal restructure with no external behaviour change"),
    ("rfc", "fbca04", "RFC for a significant change"),
    ("chore", "cccccc", "Tooling, deps, config, CI"),
    ("area:skill", "0e8a16", "Changes to the forge-manager skill prose"),
    ("area:mcp", "0e8a16", "Changes to MCP server code or behaviour"),
    ("area:public-mirror", "5319e7", "Triaged from or targeted at a public mirror"),
    ("area:bootstrap", "5319e7", "Bootstrap sequence"),
)

# Forgejo has no native Discussions surface; Issues with these
# reserved labels substitute (per OQ1). Bootstrap seeds the canonical
# subset so create_discussion has the labels it needs.
_FORGEJO_DISCUSSION_LABELS: tuple[tuple[str, str, str], ...] = (
    ("kind:discussion", "0075ca", "Issue used as a Discussion (OQ1)"),
    ("category:Architecture", "1d76db", "System design decisions"),
    ("category:Ideas", "1d76db", "Early exploration, what-ifs"),
    ("category:UX_UI", "1d76db", "Interface, API shape, naming"),
    ("category:Announcements", "1d76db", "Project Index / Session Lock / running-log Discussions"),
    ("category:claude-use-only", "1d76db", "Session locks, bootstrap logs"),
    ("decided", "0e8a16", "Discussion has reached Decided ✓"),
)


CODEBERG_API_BASE = "https://codeberg.org"
"""Hosted Codeberg's API root. Self-hosted Forgejo passes ``url`` in
its config blob and overrides this default."""


class ForgejoAdapter(_rest_base.RestAdapterBase):
    """PlatformAdapter for any Forgejo deployment via REST.

    Construction:
      * For hosted Codeberg, pass ``platform_id="codeberg"`` to
        ``from_config``; the API base is fixed to codeberg.org and the
        token comes from ``~/.codeberg-token``.
      * For self-hosted, pass ``platform_id="forgejo"`` plus ``url``;
        token comes from ``~/.forgejo-token`` (or a custom env-var
        path via ``token_env``).

    The class accepts both because the implementation is identical;
    the only differences are the API base URL and the token-file
    convention. ``platform_id`` stays as whichever name was used so
    ``ArtifactRef.platform_id`` round-trips back to the same adapter
    in a multi-replication setting.
    """

    # Default; overridden per-instance in __init__ since the same class
    # serves both 'codeberg' and 'forgejo' identities.
    platform_id: ClassVar[str] = "forgejo"
    has_scaffold: ClassVar[bool] = True
    has_session_event_surface: ClassVar[bool] = False
    """Session events on Forgejo / Codeberg are comments on the
    Issues-as-Discussions Project Index Issue — addressed by the
    handler via append_comment, not a dedicated surface."""

    # RestAdapterBase parameterization (DRY-B).
    _AUTH_SCHEME: ClassVar[str] = "token"        # Gitea/Forgejo convention
    _API_PATH: ClassVar[str] = "/api/v1"
    _ADAPTER_NAME: ClassVar[str] = "ForgejoAdapter"

    def __init__(
        self,
        *,
        token: str,
        api_base: str,
        platform_id: str = "forgejo",
    ):
        self._token = token
        self._api_base = api_base.rstrip("/")
        # Per-instance override of the ClassVar to support both
        # 'codeberg' and 'forgejo' identities from the same class.
        self.platform_id = platform_id  # type: ignore[misc]
        self._client: httpx.AsyncClient | None = None

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> "ForgejoAdapter":
        """Construct from a forge-config.json platform entry.

        Expected shapes:

          Codeberg:
            {"id": "codeberg",
             "owner": "...",
             "private": "...-dev",
             "public": "...",
             "docs": "...-docs"}

          Self-hosted Forgejo:
            {"id": "forgejo",
             "url": "http://localhost:3000",
             "owner": "...",
             "private": "...-dev",
             "public": "...",
             "docs": "...-docs"}

        Tokens are read from ``~/.codeberg-token`` or ``~/.forgejo-token``
        depending on ``id`` (mode 600 expected; not enforced). A custom
        token-file path can be passed via ``token_path``.
        """
        platform_id = config.get("id", "forgejo")
        if platform_id == "codeberg":
            api_base = CODEBERG_API_BASE
        elif platform_id == "forgejo":
            api_base = config.get("url") or "http://localhost:3000"
        else:
            raise _errors.ForgeError(
                f"ForgejoAdapter: unsupported platform_id={platform_id!r}; "
                f"expected 'codeberg' or 'forgejo'."
            )

        # Token discovery delegated to the unified dispatcher (#283).
        # Precedence (matching pre-#283 semantics): env vars first via
        # the dispatcher's chain (CODEBERG_TOKEN / FORGEJO_TOKEN, plus
        # any platforms[].token_env override), then the legacy
        # ``token_path`` field as a fallback for explicit paths the
        # dispatcher doesn't know.
        from ..config import get_platform_token  # noqa: PLC0415

        token: str | None = get_platform_token(
            platform_id, token_env_override=config.get("token_env"),
        )
        if token is None:
            legacy_token_path = config.get("token_path")
            if legacy_token_path:
                path = Path(legacy_token_path).expanduser()
                if path.is_file():
                    content = path.read_text(encoding="utf-8").strip()
                    if content:
                        token = content
        if token is None:
            env_name = (
                "CODEBERG_TOKEN" if platform_id == "codeberg" else "FORGEJO_TOKEN"
            )
            default_path = (
                "~/.codeberg-token" if platform_id == "codeberg"
                else "~/.forgejo-token"
            )
            raise _errors.ForgeError(
                f"ForgejoAdapter: no token found for platform_id={platform_id!r}. "
                f"Set ${env_name}, create {default_path} (chmod 600, single-line "
                f"PAT), or set platforms[].token_env to a custom env-var name."
            )

        return cls(token=token, api_base=api_base, platform_id=platform_id)

    # _headers, _get_client, _request, aclose lifted into
    # RestAdapterBase (DRY-B). DEFAULT_TIMEOUT_S and the
    # service-unavailable status set are also there.

    # =====================================================================
    # Repo-level reads
    # =====================================================================

    async def get_repo_node_id(self, owner: str, repo: str) -> str:
        data = await self._request("GET", f"/repos/{owner}/{repo}")
        repo_id = data.get("id")
        if repo_id is None:
            raise _errors.InvalidArtifactRefError("repo", f"{owner}/{repo}")
        return str(repo_id)

    async def get_repo_visibility(self, owner: str, repo: str) -> str | None:
        """Return ``"PUBLIC"`` / ``"PRIVATE"`` / ``None``. Forgejo has no
        ``INTERNAL`` visibility (org-internal is GitHub-specific). The
        REST shape exposes a boolean ``private`` flag. (PAR-3)
        """
        data = await self._request(
            "GET", f"/repos/{owner}/{repo}", allow_404_as_none=True,
        )
        if data is None:
            return None
        return "PRIVATE" if data.get("private") else "PUBLIC"

    async def list_milestones(
        self, owner: str, repo: str, state: str = "all"
    ) -> list[Milestone]:
        params = {"state": state, "limit": 50}
        data = await self._request(
            "GET", f"/repos/{owner}/{repo}/milestones", params=params,
        ) or []
        return [_milestone_from_api(m) for m in data]

    async def find_milestone(
        self, owner: str, repo: str, name_or_number: str | int
    ) -> Milestone | None:
        if isinstance(name_or_number, int):
            data = await self._request(
                "GET",
                f"/repos/{owner}/{repo}/milestones/{name_or_number}",
                allow_404_as_none=True,
            )
            return _milestone_from_api(data) if data else None
        # Title-based: linear search via the shared helper (DRY-E).
        return await _find_milestone_by_title_in_list(
            self.list_milestones, owner, repo, name_or_number,
        )

    # =====================================================================
    # Issue operations
    # =====================================================================

    async def create_issue(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        body: str,
        labels: list[str],
        milestone: str | int | None = None,
    ) -> Issue:
        # Forgejo's create-issue endpoint takes label IDs (ints), not
        # names. Resolve names → IDs via ensure_label so unknown labels
        # get created on the fly.
        label_ids: list[int] = []
        for name in labels:
            label_ids.append(int(await self.ensure_label(
                owner=owner, repo=repo, name=name,
            )))

        milestone_id: int | None = None
        if milestone is not None:
            ms = await self.find_milestone(owner, repo, milestone)
            if ms is None:
                raise _errors.InvalidArtifactRefError(
                    "milestone", str(milestone),
                )
            milestone_id = ms.number

        payload: dict[str, Any] = {"title": title, "body": body, "labels": label_ids}
        if milestone_id is not None:
            payload["milestone"] = milestone_id

        data = await self._request(
            "POST", f"/repos/{owner}/{repo}/issues", json=payload,
        )
        return _issue_from_api(data, owner=owner, repo=repo, platform_id=self.platform_id)

    async def get_issue(self, owner: str, repo: str, number: int) -> Issue:
        data = await self._request(
            "GET",
            f"/repos/{owner}/{repo}/issues/{number}",
            allow_404_as_none=True,
        )
        if data is None:
            raise _errors.InvalidArtifactRefError("issue number", str(number))
        return _issue_from_api(data, owner=owner, repo=repo, platform_id=self.platform_id)

    async def get_issue_body(self, ref: ArtifactRef) -> str:
        if ref.number is None:
            raise _errors.InvalidArtifactRefError(
                "ref.number",
                "ForgejoAdapter.get_issue_body requires ref.number; "
                "node-ID-only refs from other adapters cannot be resolved "
                "via the Forgejo REST API.",
            )
        data = await self._request(
            "GET",
            f"/repos/{ref.owner}/{ref.repo}/issues/{ref.number}",
            allow_404_as_none=True,
        )
        if data is None:
            raise _errors.InvalidArtifactRefError(
                "issue number", str(ref.number),
            )
        return data.get("body", "") or ""

    async def update_issue_body(
        self, ref: ArtifactRef, new_body: str, force: bool = False
    ) -> None:
        await self._request(
            "PATCH",
            f"/repos/{ref.owner}/{ref.repo}/issues/{ref.number}",
            json={"body": new_body},
        )

    async def close_issue(
        self, ref: ArtifactRef, state_reason: str = "completed"
    ) -> Issue:
        # Forgejo doesn't model state_reason; pass through state only.
        # The PATCH response carries the updated issue in full — shape
        # it into the canonical Issue.
        data = await self._request(
            "PATCH",
            f"/repos/{ref.owner}/{ref.repo}/issues/{ref.number}",
            json={"state": "closed"},
        )
        return _issue_from_api(
            data, owner=ref.owner, repo=ref.repo,
            platform_id=self.platform_id,
        )

    async def add_label(self, ref: ArtifactRef, label_name: str) -> None:
        label_id = int(await self.ensure_label(
            owner=ref.owner, repo=ref.repo, name=label_name,
        ))
        await self._request(
            "POST",
            f"/repos/{ref.owner}/{ref.repo}/issues/{ref.number}/labels",
            json={"labels": [label_id]},
        )

    async def remove_label(self, ref: ArtifactRef, label_name: str) -> None:
        # Resolve name → id, then DELETE the labelled-id endpoint.
        existing = await self._find_label_id(
            owner=ref.owner, repo=ref.repo, name=label_name,
        )
        if existing is None:
            return  # label not present on repo; treat as no-op
        await self._request(
            "DELETE",
            f"/repos/{ref.owner}/{ref.repo}/issues/{ref.number}/labels/{existing}",
        )

    async def search_issues(
        self,
        *,
        owner: str,
        repo: str,
        query: str = "",
        state: str = "all",
        labels: list[str] | None = None,
        milestone: str | None = None,
        limit: int = 30,
    ) -> SearchResult:
        params: dict[str, Any] = {
            "type": "issues",
            "state": state,
            "limit": limit,
        }
        if query:
            params["q"] = query
        if labels:
            params["labels"] = ",".join(labels)
        if milestone:
            ms = await self.find_milestone(owner, repo, milestone)
            if ms is not None:
                params["milestones"] = ms.title

        data = await self._request(
            "GET", f"/repos/{owner}/{repo}/issues", params=params,
        ) or []
        results = [
            _issue_from_api(item, owner=owner, repo=repo, platform_id=self.platform_id)
            for item in data
        ]
        # Forgejo's REST endpoint doesn't return a total count alongside
        # the paged result; report the result length as the floor.
        return SearchResult(
            results=results,
            total_count=len(results),
            query=query,
        )

    async def list_open_issues(
        self, *, owner: str, repo: str, limit: int = 100
    ) -> list[Issue]:
        result = await self.search_issues(
            owner=owner, repo=repo, state="open", limit=limit,
        )
        return list(result.results)

    # =====================================================================
    # Discussion operations (Issues with kind:discussion + category:* labels)
    # =====================================================================

    async def create_discussion(
        self,
        *,
        owner: str,
        repo: str,
        title: str,
        body: str,
        category: str | None = None,
    ) -> Discussion:
        labels = ["kind:discussion"]
        if category:
            labels.append(f"category:{_normalize_category(category)}")
        issue = await self.create_issue(
            owner=owner, repo=repo, title=title, body=body, labels=labels,
        )
        return _discussion_from_issue(issue, category=category)

    async def get_discussion(
        self, owner: str, repo: str, number: int
    ) -> Discussion:
        issue = await self.get_issue(owner, repo, number)
        if "kind:discussion" not in issue.labels:
            raise _errors.InvalidArtifactRefError(
                "discussion number",
                f"{number} (resolved to issue without kind:discussion)",
            )
        category = _category_from_labels(issue.labels)
        return _discussion_from_issue(issue, category=category)

    async def get_discussion_body(self, ref: ArtifactRef) -> str:
        # Forgejo models Discussions as Issues with kind:discussion +
        # category:* labels (per OQ1) — same REST endpoint as
        # get_issue_body.
        return await self.get_issue_body(ref)

    async def update_discussion_body(
        self, ref: ArtifactRef, new_body: str, force: bool = False
    ) -> None:
        await self.update_issue_body(ref, new_body, force=force)

    async def list_recent_discussions(
        self, *, owner: str, repo: str, since_days: int = 7
    ) -> list[Discussion]:
        # Forgejo doesn't have a since-days filter on /issues directly,
        # but `since` accepts an ISO timestamp. We list with kind:discussion
        # label filter then trim by created_at locally.
        cutoff = datetime.now(timezone.utc).timestamp() - since_days * 86400
        params = {
            "type": "issues",
            "state": "all",
            "labels": "kind:discussion",
            "limit": 50,
        }
        data = await self._request(
            "GET", f"/repos/{owner}/{repo}/issues", params=params,
        ) or []
        result: list[Discussion] = []
        for item in data:
            created = _parse_iso(item.get("created_at"))
            if created is not None and created.timestamp() < cutoff:
                continue
            issue = _issue_from_api(
                item, owner=owner, repo=repo, platform_id=self.platform_id,
            )
            result.append(_discussion_from_issue(
                issue, category=_category_from_labels(issue.labels),
            ))
        return result

    async def mark_decided(self, ref: ArtifactRef) -> None:
        # Multi-dim state per OQ1: render `decided` as a label.
        await self.add_label(ref, "decided")

    async def mark_answer(self, comment_ref: ArtifactRef) -> None:
        # Forgejo has no comment-level "answer" surface. Callers that
        # want a portable "decided" mark should use mark_decided
        # against the parent discussion instead.
        raise NotImplementedError(
            "ForgejoAdapter.mark_answer: Forgejo has no comment-level "
            "answer feature. Use mark_decided(parent_ref) for the "
            "portable `decided` label on the parent discussion."
        )

    # =====================================================================
    # Comment operations
    # =====================================================================

    async def append_comment(self, target: ArtifactRef, body: str) -> Comment:
        # Discussions are Issues here; both kinds use the same endpoint.
        if target.kind not in ("issue", "discussion"):
            raise ValueError(f"append_comment: unsupported target.kind={target.kind!r}")
        data = await self._request(
            "POST",
            f"/repos/{target.owner}/{target.repo}/issues/{target.number}/comments",
            json={"body": body},
        )
        return _comment_from_api(data, parent=target, platform_id=self.platform_id)

    async def list_comments(
        self,
        target: ArtifactRef,
        *,
        since_days: int | None = None,
        limit: int | None = None,
    ) -> list[Comment]:
        if target.kind not in ("issue", "discussion"):
            raise ValueError(f"list_comments: unsupported target.kind={target.kind!r}")
        params: dict[str, Any] = {}
        if since_days is not None:
            since_dt = datetime.now(timezone.utc).timestamp() - since_days * 86400
            params["since"] = datetime.fromtimestamp(
                since_dt, tz=timezone.utc,
            ).isoformat().replace("+00:00", "Z")
        data = await self._request(
            "GET",
            f"/repos/{target.owner}/{target.repo}/issues/{target.number}/comments",
            params=params or None,
        ) or []
        comments = [
            _comment_from_api(c, parent=target, platform_id=self.platform_id)
            for c in data
        ]
        if limit is not None and len(comments) > limit:
            comments = comments[-limit:]
        return comments

    # =====================================================================
    # Label management
    # =====================================================================

    async def ensure_label(
        self,
        *,
        owner: str,
        repo: str,
        name: str,
        color: str = "0E8A16",
        description: str = "",
    ) -> str:
        existing = await self._find_label_id(owner=owner, repo=repo, name=name)
        if existing is not None:
            return str(existing)
        # Forgejo accepts color with or without leading '#'; normalize.
        normalized_color = color if color.startswith("#") else f"#{color}"
        data = await self._request(
            "POST",
            f"/repos/{owner}/{repo}/labels",
            json={"name": name, "color": normalized_color, "description": description},
        )
        return str(data["id"])

    async def _find_label_id(
        self, *, owner: str, repo: str, name: str
    ) -> int | None:
        # Paginate through repo labels to find by name. Repos rarely
        # exceed 50 labels so a single page is normally enough.
        page = 1
        while True:
            data = await self._request(
                "GET",
                f"/repos/{owner}/{repo}/labels",
                params={"page": page, "limit": 50},
            ) or []
            for label in data:
                if label.get("name") == name:
                    return int(label["id"])
            if len(data) < 50:
                return None
            page += 1

    async def _paginate_get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        page_size: int = 50,
        max_pages: int = 200,
    ) -> list[dict]:
        """Walk paginated GET results until the response is shorter than
        ``page_size`` or ``max_pages`` is reached (#279).

        Forgejo / Gitea pagination is page-number based with ``page=N``
        + ``limit=N``; the API returns up to ``limit`` rows per page
        and an empty / short list signals the end. ``max_pages`` is a
        circuit breaker — fetch_remote_changes against a years-old
        ``since`` could otherwise loop indefinitely against a busy
        repo. Callers handle the truncation by raising the ``since``
        watermark and re-running.
        """
        results: list[dict] = []
        page = 1
        merged: dict[str, Any] = {"page": page, "limit": page_size}
        if params:
            merged.update(params)
        while page <= max_pages:
            merged["page"] = page
            data = await self._request("GET", path, params=dict(merged)) or []
            if not isinstance(data, list):
                break
            results.extend(data)
            if len(data) < page_size:
                break
            page += 1
        return results

    # =====================================================================
    # Release operations
    # =====================================================================

    async def create_release(
        self,
        *,
        owner: str,
        repo: str,
        tag: str,
        name: str,
        body: str = "",
        prerelease: bool = False,
        draft: bool = False,
    ) -> Release:
        payload = {
            "tag_name": tag,
            "name": name,
            "body": body,
            "prerelease": prerelease,
            "draft": draft,
        }
        data = await self._request(
            "POST", f"/repos/{owner}/{repo}/releases", json=payload,
        )
        return Release(
            tag=data.get("tag_name", tag),
            name=data.get("name", name),
            body=data.get("body", body) or "",
            prerelease=bool(data.get("prerelease", prerelease)),
            created_at=_parse_iso(data.get("created_at")),
            url=data.get("html_url", "") or "",
        )

    def get_clone_url(self, owner: str, repo: str) -> str:
        """Forgejo clone URL — base from the configured ``api_base`` (#282).

        ``api_base`` includes the ``/api/v1`` suffix; strip it to get
        the front-end URL. e.g. ``https://codeberg.org/api/v1`` →
        ``https://codeberg.org/{owner}/{repo}.git``.
        """
        host = self._api_base
        if host.endswith("/api/v1"):
            host = host[: -len("/api/v1")]
        host = host.rstrip("/")
        return f"{host}/{owner}/{repo}.git"

    def noreply_email(
        self, login: str, user_id: int | None = None
    ) -> str:
        """Forgejo / Codeberg-conventional noreply email (#282).

        Form: ``{login}@noreply.{host}`` where ``host`` is the
        front-end hostname (codeberg.org, etc.). The ``user_id`` arg
        is accepted for Protocol uniformity but Forgejo doesn't
        embed it in the noreply form.
        """
        del user_id  # not used on Forgejo; accepted for Protocol uniformity
        host = self._api_base
        if host.endswith("/api/v1"):
            host = host[: -len("/api/v1")]
        # Strip scheme and trailing slash to extract pure host.
        host = host.split("://", 1)[-1].rstrip("/")
        return f"{login}@noreply.{host}"

    async def delete_release(
        self, *, owner: str, repo: str, tag: str,
    ) -> None:
        """Delete a Forgejo Release page (#294 Phase A).

        Two-step lookup: GET the release by tag → DELETE by id.
        Forgejo's REST surface keys releases by numeric id, not tag,
        so the GET resolves the id from the tag. Idempotent —
        404 on either GET or DELETE is treated as already-deleted.
        """
        release = await self._request(
            "GET",
            f"/repos/{owner}/{repo}/releases/tags/{tag}",
            allow_404_as_none=True,
        )
        if release is None:
            return  # already deleted
        release_id = release.get("id")
        if release_id is None:
            return
        await self._request(
            "DELETE",
            f"/repos/{owner}/{repo}/releases/{release_id}",
            allow_404_as_none=True,
        )

    # =====================================================================
    # File-content reads
    # =====================================================================

    async def fetch_file_content(
        self, *, owner: str, repo: str, path: str, ref: str = "main"
    ) -> str | None:
        data = await self._request(
            "GET",
            f"/repos/{owner}/{repo}/raw/{path}",
            params={"ref": ref},
            allow_404_as_none=True,
        )
        if data is None:
            return None
        # _request returns parsed JSON for application/json or text
        # otherwise; the raw endpoint yields text.
        return data if isinstance(data, str) else None

    # =====================================================================
    # Bundled reads (Phase C5)
    # =====================================================================

    async def bundle_recover_context(
        self,
        *,
        owner: str,
        repo: str,
        toc_discussion_id: str,
        since_days: int = 7,
        issue_limit: int = 100,
    ) -> RecoveryBundle:
        # Forgejo has no aliased multi-query surface — delegate to the
        # shared decomposed default.
        return await _recovery.default_bundle_recover_context(
            self, owner=owner, repo=repo,
            toc_discussion_id=toc_discussion_id,
            since_days=since_days, issue_limit=issue_limit,
        )

    # =====================================================================
    # Health + drift
    # =====================================================================

    async def probe(self) -> bool:
        # /api/v1/version is unauthenticated and cheap.
        try:
            data = await self._request("GET", "/version")
            return isinstance(data, dict) and "version" in data
        except _errors.ForgeUnavailableError:
            return False
        except _errors.ForgeError:
            return False

    async def compute_drift(self, snapshot: dict) -> DriftReport:
        """Diff this adapter's remote state against the canonical
        ``snapshot`` (typically produced by ``LocalStoreAdapter.snapshot``).

        The snapshot dict must carry ``owner`` and ``repo`` fields so we
        know which Forgejo project to inspect. Set-based comparison only
        for Phase 6 sub-run B — body-content divergence detection lands
        in a follow-up.
        """
        owner = snapshot.get("owner") or ""
        repo = snapshot.get("repo") or ""
        if not owner or not repo:
            return DriftReport(
                platform_id=self.platform_id,
                is_clean=False,
                notes=["snapshot missing owner/repo; cannot diff remote"],
            )

        local_issues: dict = snapshot.get("issues", {})
        local_discussions: dict = snapshot.get("discussions", {})

        # Fetch every issue (including discussions, which are
        # kind:discussion-labeled issues per OQ1). We use the listing
        # endpoint with state=all to capture closed items too.
        try:
            raw_issues = await self._request(
                "GET",
                f"/repos/{owner}/{repo}/issues",
                params={"type": "issues", "state": "all", "limit": 50},
            ) or []
        except _errors.ForgeUnavailableError:
            return DriftReport(
                platform_id=self.platform_id,
                is_clean=False,
                notes=["compute_drift: remote unreachable; report inconclusive"],
            )

        # Partition remote items by kind via the kind:discussion label.
        remote_issues: dict[int, dict] = {}
        remote_discussions: dict[int, dict] = {}
        for item in raw_issues:
            number = item.get("number")
            if number is None:
                continue
            label_objs = item.get("labels") or []
            label_names = [
                l if isinstance(l, str) else (l.get("name") or "")
                for l in label_objs
            ]
            entry = {
                "state": (
                    "closed" if (item.get("state") or "open").lower() == "closed"
                    else "open"
                ),
                "labels": [n for n in label_names if n],
            }
            if "kind:discussion" in label_names:
                remote_discussions[int(number)] = entry
            else:
                remote_issues[int(number)] = entry

        # Set-based diffs — issues.
        local_issue_nums = {int(k) for k in local_issues}
        remote_issue_nums = set(remote_issues)
        issues_only_local = sorted(local_issue_nums - remote_issue_nums)
        issues_only_remote = sorted(remote_issue_nums - local_issue_nums)
        issues_diverged: list[int] = []
        for n in local_issue_nums & remote_issue_nums:
            if local_issues[n].get("state") != remote_issues[n]["state"]:
                issues_diverged.append(n)
                continue
            if set(local_issues[n].get("labels") or []) != set(remote_issues[n]["labels"]):
                issues_diverged.append(n)

        # Set-based diffs — discussions.
        local_disc_nums = {int(k) for k in local_discussions}
        remote_disc_nums = set(remote_discussions)
        discussions_only_local = sorted(local_disc_nums - remote_disc_nums)
        discussions_only_remote = sorted(remote_disc_nums - local_disc_nums)
        discussions_diverged: list[int] = []
        for n in local_disc_nums & remote_disc_nums:
            if local_discussions[n].get("state") != remote_discussions[n]["state"]:
                discussions_diverged.append(n)
                continue
            if set(local_discussions[n].get("labels") or []) != set(remote_discussions[n]["labels"]):
                discussions_diverged.append(n)

        is_clean = (
            not issues_only_local
            and not issues_only_remote
            and not issues_diverged
            and not discussions_only_local
            and not discussions_only_remote
            and not discussions_diverged
        )
        return DriftReport(
            platform_id=self.platform_id,
            is_clean=is_clean,
            issues_only_local=issues_only_local,
            issues_only_remote=issues_only_remote,
            issues_diverged=sorted(issues_diverged),
            discussions_only_local=discussions_only_local,
            discussions_only_remote=discussions_only_remote,
            discussions_diverged=sorted(discussions_diverged),
        )

    # =====================================================================
    # Bootstrap (multi-platform scaffold C3)
    # =====================================================================

    async def bootstrap_project(
        self,
        *,
        owner: str,
        project_name: str,
        description: str,
        existing_state: dict | None = None,
    ) -> BootstrapResult:
        """Bootstrap a Forgejo / Codeberg-canonical project.

        Idempotent. For each step the adapter inspects live state first:

          1. Ensure the dev repo ``<owner>/<project>-dev`` (private).
          2. Ensure the public mirror ``<owner>/<project>`` (public).
          3. Seed the standard label catalogue + Discussions-as-Issues
             reserved labels on the dev repo.

        Forgejo has no native Discussions surface; the ``kind:discussion``
        + ``category:*`` label set substitutes per OQ1. Forgejo also has
        no Projects v2 analogue; that capability stays GitHub-specific
        until the project-board adapter design lands.

        ``existing_state`` is accepted for Protocol parity. Future
        commits may use prior adapters' artifacts (e.g., a docs_repo_path
        from LocalStoreAdapter) to stamp into the Project Index Issue
        body — out of scope for C3.
        """
        if not owner.strip():
            raise _errors.ForgeError(
                "ForgejoAdapter.bootstrap_project: owner must not be empty."
            )
        if not project_name.strip():
            raise _errors.ForgeError(
                "ForgejoAdapter.bootstrap_project: project_name must not be empty."
            )

        manual_steps: list[str] = []
        artifacts: dict = {}

        dev_repo, dev_existed = await self._ensure_repo(
            owner=owner,
            name=f"{project_name}-dev",
            private=True,
            description=description or f"{project_name} — private dev, design, and archive",
        )
        public_repo, public_existed = await self._ensure_repo(
            owner=owner,
            name=project_name,
            private=False,
            description=description or f"{project_name} — public mirror",
        )

        artifacts["dev_repo"] = {
            "full_name": f"{owner}/{project_name}-dev",
            "id": dev_repo.get("id"),
            "html_url": dev_repo.get("html_url", ""),
            "existed": dev_existed,
        }
        artifacts["public_repo"] = {
            "full_name": f"{owner}/{project_name}",
            "id": public_repo.get("id"),
            "html_url": public_repo.get("html_url", ""),
            "existed": public_existed,
        }

        labels_seeded: list[str] = []
        catalogue = _FORGEJO_STANDARD_LABELS + _FORGEJO_DISCUSSION_LABELS
        for label_name, color, label_desc in catalogue:
            await self.ensure_label(
                owner=owner, repo=f"{project_name}-dev",
                name=label_name, color=color, description=label_desc,
            )
            labels_seeded.append(label_name)
        artifacts["labels_seeded"] = labels_seeded

        return BootstrapResult(
            platform_id=self.platform_id,
            artifacts=artifacts,
            manual_steps=manual_steps,
            phase="complete" if not manual_steps else "awaiting_manual",
        )

    async def _ensure_repo(
        self,
        *,
        owner: str,
        name: str,
        private: bool,
        description: str,
    ) -> tuple[dict, bool]:
        """Idempotently create a Forgejo repo. Returns (repo_dict, existed).

        Probe-then-create: ``GET /repos/<owner>/<name>`` → if 200, no-op
        and return the existing repo with ``existed=True``. On 404,
        attempt org-namespace creation (``POST /orgs/<owner>/repos``);
        fall back to user-namespace creation (``POST /user/repos``)
        only when the org route returns 404 (i.e., ``<owner>`` resolves
        as a user account, not an org). Other non-2xx statuses on the
        org route propagate so a 422 (duplicate name in org, etc.) is
        not silently routed under a different owner.
        """
        existing = await self._request(
            "GET", f"/repos/{owner}/{name}", allow_404_as_none=True,
        )
        if existing is not None:
            return existing, True

        payload = {
            "name": name,
            "description": description,
            "private": private,
            "auto_init": True,
            "default_branch": "main",
        }
        created = await self._request(
            "POST", f"/orgs/{owner}/repos", json=payload,
            allow_404_as_none=True,
        )
        if created is None:
            created = await self._request("POST", "/user/repos", json=payload)
        return created, False

    async def fetch_remote_changes(
        self, *, since: datetime, owner: str, repo: str,
    ) -> list[RemoteChange]:
        """Paginated REST scan of issues + comments updated since ``since`` (#279).

        Implementation follows the smallest-unblock pattern from the
        issue body:

        1. ``GET /repos/{owner}/{repo}/issues?since=<iso>&state=all``
           — paginated; Forgejo's ``since`` filter matches on
           ``updated_at >=``. Filter out PR rows (Forgejo's /issues
           endpoint includes them; the ``pull_request`` field is
           non-null on PRs).
        2. Per-op detection on each row:
             * ``created_at >= since`` → ``create_issue`` (apply
               side ignores; surfaced for visibility in import report).
             * ``state == "closed"`` and ``closed_at >= since``
               → ``close_issue``.
             * Otherwise → ``update_body`` carrying the current body.
        3. ``GET /repos/{owner}/{repo}/issues/comments?since=<iso>``
           depth-1 — one ``add_comment`` RemoteChange per result.
        4. Rate-limit / quota exhaustion → swallow with a sentinel
           ``rate_limited`` RemoteChange so the caller can surface a
           ``manual_steps`` entry.
        """
        changes: list[RemoteChange] = []
        since_iso = since.astimezone(timezone.utc).isoformat()
        try:
            issues = await self._paginate_get(
                f"/repos/{owner}/{repo}/issues",
                params={
                    "since": since_iso,
                    "state": "all",
                    "type": "issues",
                },
            )
        except _errors.ForgeUnavailableError as exc:
            return [_rate_limited_sentinel(self.platform_id, str(exc))]

        for item in issues:
            # Skip PRs — Forgejo lumps them into /issues but the
            # canonical Issue surface doesn't include them.
            if item.get("pull_request"):
                continue
            issue = _issue_from_api(
                item, owner=owner, repo=repo, platform_id=self.platform_id,
            )
            created_at = _parse_iso(item.get("created_at"))
            closed_at = _parse_iso(item.get("closed_at"))
            updated_at = _parse_iso(item.get("updated_at")) or datetime.now(timezone.utc)
            if created_at is not None and created_at >= since:
                changes.append(
                    RemoteChange(
                        source_platform_id=self.platform_id,
                        ref=issue.ref,
                        operation="create_issue",
                        observed_at=created_at,
                        payload={
                            "title": issue.title,
                            "body": issue.body,
                            "labels": list(issue.labels),
                        },
                    )
                )
                continue  # newly-created — no separate update/close to emit
            if (
                issue.state == "closed"
                and closed_at is not None
                and closed_at >= since
            ):
                changes.append(
                    RemoteChange(
                        source_platform_id=self.platform_id,
                        ref=issue.ref,
                        operation="close_issue",
                        observed_at=closed_at,
                        payload={"state_reason": "completed"},
                    )
                )
                continue
            changes.append(
                RemoteChange(
                    source_platform_id=self.platform_id,
                    ref=issue.ref,
                    operation="update_body",
                    observed_at=updated_at,
                    payload={"new_body": issue.body},
                )
            )

        # Comments — depth-1, one add_comment per row.
        try:
            comments = await self._paginate_get(
                f"/repos/{owner}/{repo}/issues/comments",
                params={"since": since_iso},
            )
        except _errors.ForgeUnavailableError as exc:
            changes.append(_rate_limited_sentinel(self.platform_id, str(exc)))
            return changes

        for c in comments:
            issue_url = c.get("issue_url") or ""
            issue_number = _issue_number_from_comment_url(issue_url)
            if issue_number is None:
                continue
            parent_ref = _make_ref(
                platform_id=self.platform_id,
                native_id=str(c.get("issue_id", "")),
                kind="issue",
                owner=owner,
                repo=repo,
                number=issue_number,
            )
            comment = _comment_from_api(
                c, parent=parent_ref, platform_id=self.platform_id,
            )
            changes.append(
                RemoteChange(
                    source_platform_id=self.platform_id,
                    ref=comment.ref,
                    operation="add_comment",
                    observed_at=comment.created_at,
                    payload={
                        "parent_number": issue_number,
                        "body": c.get("body", "") or "",
                        "author": comment.author,
                    },
                )
            )

        return changes


# ---------------------------------------------------------------------------
# Internal: API-dict-to-canonical-type shapers
# ---------------------------------------------------------------------------

def _make_ref(
    *,
    platform_id: str,
    native_id: str,
    kind: str,
    owner: str,
    repo: str,
    number: int | None = None,
) -> ArtifactRef:
    return ArtifactRef(
        platform_id=platform_id,
        native_id=native_id,
        kind=kind,  # type: ignore[arg-type]
        owner=owner,
        repo=repo,
        number=number,
    )


def _issue_from_api(
    d: dict,
    *,
    owner: str,
    repo: str,
    platform_id: str,
) -> Issue:
    """Shape a Forgejo /issues/* response into the canonical Issue type."""
    user = d.get("user") or {}
    return Issue(
        ref=_make_ref(
            platform_id=platform_id,
            native_id=str(d.get("id", "")),
            kind="issue",
            owner=owner,
            repo=repo,
            number=d.get("number"),
        ),
        title=d.get("title", "") or "",
        body=d.get("body", "") or "",
        state=("closed" if (d.get("state") or "open").lower() == "closed" else "open"),
        labels=[n for n in _label_names_from_api(d) if n],
        milestone=_milestone_title_from_api(d),
        author=user.get("login", "") or "",
        created_at=_parse_iso(d.get("created_at")),
        updated_at=_parse_iso(d.get("updated_at")),
        url=d.get("html_url", "") or "",
    )


def _discussion_from_issue(issue: Issue, *, category: str | None) -> Discussion:
    """Convert a canonical Issue (with kind:discussion label) into a
    canonical Discussion. The ``ref`` is re-emitted with ``kind="discussion"``
    so downstream callers can dispatch correctly."""
    new_ref = ArtifactRef(
        platform_id=issue.ref.platform_id,
        native_id=issue.ref.native_id,
        kind="discussion",
        owner=issue.ref.owner,
        repo=issue.ref.repo,
        number=issue.ref.number,
    )
    decided = "decided" in issue.labels
    return Discussion(
        ref=new_ref,
        title=issue.title,
        body=issue.body,
        state=issue.state,
        category=category,
        labels=issue.labels,
        decided=decided,
        author=issue.author,
        created_at=issue.created_at,
        url=issue.url,
    )


def _comment_from_api(
    d: dict, *, parent: ArtifactRef, platform_id: str,
) -> Comment:
    user = d.get("user") or {}
    created = _parse_iso(d.get("created_at")) or datetime.now(timezone.utc)
    return Comment(
        ref=_make_ref(
            platform_id=platform_id,
            native_id=str(d.get("id", "")),
            kind="comment",
            owner=parent.owner,
            repo=parent.repo,
        ),
        body=d.get("body", "") or "",
        author=user.get("login", "") or "",
        created_at=created,
        parent=parent,
        url=d.get("html_url", "") or "",
    )


def _milestone_from_api(d: dict) -> Milestone:
    return Milestone(
        title=d.get("title", "") or "",
        number=d.get("id", 0) or 0,
        state=("closed" if (d.get("state") or "open").lower() == "closed" else "open"),
        description=d.get("description", "") or "",
        due_on=_parse_iso(d.get("due_on")),
    )


def _normalize_category(category: str) -> str:
    """Folder-friendly form for category labels: lowercased,
    spaces and slashes collapsed to underscores. Mirrors LocalStoreAdapter."""
    return category.lower().replace(" / ", "_").replace(" ", "_")


def _category_from_labels(labels: list[str]) -> str | None:
    """Extract the category:* label and return the human-readable name."""
    for label in labels:
        if label.startswith("category:"):
            return label.split(":", 1)[1]
    return None


# ---------------------------------------------------------------------------
# fetch_remote_changes helpers (#279)
# ---------------------------------------------------------------------------


def _rate_limited_sentinel(platform_id: str, message: str) -> RemoteChange:
    """A RemoteChange that signals the fetch was truncated by rate
    limit / quota / unavailability (#279).

    Callers (ReplicationManager.import_remote_changes; the #294
    backfill step) detect this sentinel by inspecting
    ``operation == "rate_limited"`` and surface a manual_steps entry
    pointing the operator at re-running with a tighter ``since``
    watermark or waiting for the rate-limit window.
    """
    sentinel_ref = ArtifactRef(
        platform_id=platform_id,
        native_id="<rate_limited>",
        kind="issue",
        owner="<unknown>",
        repo="<unknown>",
    )
    return RemoteChange(
        source_platform_id=platform_id,
        ref=sentinel_ref,
        operation="rate_limited",
        observed_at=datetime.now(timezone.utc),
        payload={"message": message},
    )


def _issue_number_from_comment_url(url: str) -> int | None:
    """Extract the issue number from a Forgejo comment's ``issue_url``.

    Shape: ``https://<host>/api/v1/repos/<owner>/<repo>/issues/<n>``.
    Returns None when the URL doesn't match — the caller then drops
    the comment.
    """
    if not url:
        return None
    parts = url.rstrip("/").split("/")
    if len(parts) < 2:
        return None
    if parts[-2] != "issues":
        return None
    try:
        return int(parts[-1])
    except ValueError:
        return None
