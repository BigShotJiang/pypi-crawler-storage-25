"""Shared low-level utilities used by multiple adapter implementations.

Pure helpers only — no httpx, no Protocol, no PlatformAdapter. The
adapters import from here rather than re-implementing identical
shapes per backend (the audit-time motivation: ForgejoAdapter and
GitLabAdapter each had their own ``_parse_iso`` line-for-line).

Keep this module lean: anything that touches the HTTP client or the
canonical types belongs in a different module (``adapters._recovery``
for cross-adapter recovery, a future ``adapters._rest_base`` for the
REST base class).
"""
from __future__ import annotations

from datetime import datetime
from typing import Any


def parse_iso(value: Any) -> datetime | None:
    """Parse an ISO-8601 timestamp string into a tz-aware ``datetime``.

    Returns ``None`` on falsy or unparseable input. The ``Z`` suffix
    common in REST APIs is normalized to ``+00:00`` since
    ``datetime.fromisoformat`` rejects ``Z`` until Python 3.11+
    (kept explicit for behavioral consistency).
    """
    if not value or not isinstance(value, str):
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def label_names_from_api(d: dict) -> list[str]:
    """Extract label names from a Forgejo / GitLab REST issue payload.

    Both backends serialize labels as either:
      * a list of strings (GitLab default),
      * a list of ``{"name": ..., ...}`` objects (Forgejo, GitLab with
        ``include_label_details=true``).

    Returns a list of label-name strings, dropping empty entries.
    Used by the per-backend ``_issue_from_api`` shape converters
    (DRY-D follow-on from the 3.0.1 punchlist item #4 — partial
    parameterization; the diverging fields, ``body`` vs ``description``
    and ``number`` vs ``iid``, stay per-backend).
    """
    label_objs = d.get("labels") or []
    return [
        l if isinstance(l, str) else (l.get("name") or "")
        for l in label_objs
        if l  # drop falsy entries
    ]


async def find_milestone_by_title_in_list(
    list_milestones_fn,
    owner: str,
    repo: str,
    title: str,
):
    """Linear-search milestones from ``list_milestones_fn`` for an
    exact-title match.

    Used by adapters whose backend exposes per-id REST lookups but
    no dedicated by-title endpoint (Forgejo, GitLab today). The
    list_milestones call provides the full list; we filter
    client-side. Pattern saved per call site: 4 lines.

    The callable signature is ``async (owner, repo, state) ->
    list[Milestone]`` — matches every adapter's
    ``list_milestones`` shape.

    Returns the matching ``Milestone`` or ``None``.
    """
    for m in await list_milestones_fn(owner, repo, "all"):
        if m.title == title:
            return m
    return None


def milestone_title_from_api(d: dict) -> str | None:
    """Extract a milestone title from a Forgejo / GitLab REST issue payload.

    Both backends accept milestone in two shapes:
      * ``{"milestone": {"title": "v3.0.0", ...}}`` — most common.
      * ``{"milestone": "v3.0.0"}`` — string-only when filtered.
      * ``{"milestone": null}`` — when no milestone is assigned.

    Returns the title string or None.
    """
    milestone = d.get("milestone")
    if isinstance(milestone, dict):
        title = milestone.get("title")
        return title if isinstance(title, str) else None
    if isinstance(milestone, str):
        return milestone
    return None
