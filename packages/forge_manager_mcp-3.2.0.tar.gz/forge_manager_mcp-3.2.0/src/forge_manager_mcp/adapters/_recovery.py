"""Default decomposed implementation of ``bundle_recover_context``
(#274 Phase C5; PAR-5 parallelization).

Adapters without a native multi-query batching surface (Forgejo,
GitLab, LocalStore) call this helper from their
``bundle_recover_context`` method. The four reads —
``list_open_issues``, ``list_recent_discussions``,
``list_milestones``, ``get_discussion_body`` — fire concurrently
via ``asyncio.gather`` so the bundle's wall-clock cost is one
round-trip's worth of latency rather than four.

GitHubAdapter overrides ``bundle_recover_context`` directly to use
the existing ``_gh_recovery.fetch_recover_context_bundle`` aliased
GraphQL query (#181) which collapses all four reads into one
round-trip *server-side*. The default helper is for everyone else.
"""
from __future__ import annotations

import asyncio

from . import errors as _errors
from .types import ArtifactRef, RecoveryBundle


async def default_bundle_recover_context(
    adapter,
    *,
    owner: str,
    repo: str,
    toc_discussion_id: str,
    since_days: int = 7,
    issue_limit: int = 100,
) -> RecoveryBundle:
    """Decomposed default for ``bundle_recover_context``.

    All four reads fire in parallel via ``asyncio.gather``. The TOC
    body fetch is best-effort — failures (network glitches,
    permission errors, missing discussion) leave ``toc_body`` as
    ``None`` rather than poisoning the rest of the bundle. Other
    component failures propagate so the caller can distinguish
    "TOC unreachable but session usable" from "session start
    blocked".
    """
    toc_ref = ArtifactRef(
        platform_id=adapter.platform_id,
        native_id=toc_discussion_id,
        kind="discussion",
        owner=owner,
        repo=repo,
    )

    # PAR-5: parallel fan-out. ``return_exceptions=True`` on the TOC
    # leg lets us catch its failure without sinking the bundle; the
    # other three legs still propagate via the second gather call so
    # session-start blocking errors aren't swallowed.
    toc_task = asyncio.gather(
        adapter.get_discussion_body(toc_ref), return_exceptions=True,
    )
    open_issues, recent_discussions, milestones, toc_result = await asyncio.gather(
        adapter.list_open_issues(owner=owner, repo=repo, limit=issue_limit),
        adapter.list_recent_discussions(
            owner=owner, repo=repo, since_days=since_days,
        ),
        adapter.list_milestones(owner, repo, state="all"),
        toc_task,
    )

    # toc_result is a 1-tuple from the inner gather (return_exceptions=True).
    toc_value = toc_result[0]
    if isinstance(toc_value, _errors.ForgeError):
        toc_body: str | None = None
    elif isinstance(toc_value, BaseException):
        # Non-ForgeError exceptions propagate (matches pre-PAR-5 semantics
        # where only ForgeError was suppressed).
        raise toc_value
    else:
        toc_body = toc_value

    return RecoveryBundle(
        toc_body=toc_body,
        open_issues=open_issues,
        recent_discussions=recent_discussions,
        milestones=milestones,
    )
