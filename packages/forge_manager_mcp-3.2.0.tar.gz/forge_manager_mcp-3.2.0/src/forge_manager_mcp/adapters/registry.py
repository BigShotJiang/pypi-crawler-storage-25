"""Platform adapter registry.

Maps ``forge-config.json.platforms[*].id`` (also: ``replication_order``
entries) to the adapter class that handles it. ForgejoAdapter serves
both the hosted Codeberg backend and self-hosted Forgejo instances —
they share an implementation; the platform_id distinguishes routing.

Lives in a leaf module so both ``server.build`` (constructs the
ReplicationManager from config) and ``server.handlers.infra``
(multi-platform scaffold dispatch C1) can import without creating a
handler ↔ build cycle.
"""
from __future__ import annotations

from .forgejo import ForgejoAdapter
from .github import GitHubAdapter
from .gitlab import GitLabAdapter
from .local_store import LocalStoreAdapter
from .protocol import PlatformAdapter


PLATFORM_ADAPTERS: dict[str, type[PlatformAdapter]] = {
    "github": GitHubAdapter,
    "codeberg": ForgejoAdapter,
    "forgejo": ForgejoAdapter,
    "gitlab": GitLabAdapter,
    "local": LocalStoreAdapter,
}
