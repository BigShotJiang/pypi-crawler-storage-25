"""Local docs-repo helpers.

The docs repo is the canonical source the SiteRenderer reads from.
Bootstrap (``scaffold_project`` — Gap A) and migration (``migrate_to_3_0``
— G6) both create a local clone at ``~/<project>-docs/``. This module
provides the pure, side-effect-free building blocks both code paths
compose so the resulting repo layout stays identical.

No dependencies beyond stdlib so the helpers are cheap to import from
the migration runner without dragging in the full handler stack.
"""
from __future__ import annotations

import subprocess
from pathlib import Path


class DocsRepoOriginConflict(RuntimeError):
    """Raised when ``~/<project>-docs/`` already contains a git repo
    whose ``origin`` remote points somewhere other than the target
    URL the bootstrap is trying to set.

    The conventional path collides with users who already keep a
    docs / notes directory at that name. Silent re-binding of an
    unrelated repo's origin is a foot-gun (FIX-6); raise so the
    caller can surface a manual-step note rather than corrupting
    the user's existing repo state.
    """


def default_docs_repo_path(project_name: str) -> Path:
    """Return the conventional ``~/<project>-docs/`` path.

    Extracted so callers (and tests) can monkeypatch this single
    function without having to mock ``Path.home`` globally.
    """
    return (Path.home() / f"{project_name}-docs").resolve()


def docs_repo_readme(project_name: str) -> str:
    """Default README content for a fresh docs repo."""
    return (
        f"# {project_name}-docs\n\n"
        f"Canonical source for the {project_name} project's rendered "
        "site. Read by the SiteRenderer (Hugo) at build time.\n\n"
        "## Layout\n\n"
        "- `projects/<n>/` — per-Issue and per-Discussion pages\n"
        "- `tags/` — tag pages\n"
        "- `theme/` — Hugo theme override (optional)\n"
        "\n"
        "Bootstrapped by forge-manager scaffold_project.\n"
    )


def seed_docs_repo_readme(path: Path, project_name: str) -> bool:
    """Write README.md if absent. Returns True iff written."""
    readme = path / "README.md"
    if readme.exists():
        return False
    readme.write_text(docs_repo_readme(project_name), encoding="utf-8")
    return True


def git_init_if_absent(path: Path) -> bool:
    """Run ``git init -q -b main`` in ``path`` if no .git/ directory exists.

    Returns True iff init was run, False if .git/ already existed.
    Raises subprocess.CalledProcessError on git failure.
    """
    if (path / ".git").exists():
        return False
    subprocess.run(
        ["git", "init", "-q", "-b", "main"],
        cwd=path,
        check=True,
        capture_output=True,
    )
    return True


def git_set_origin(path: Path, remote_url: str) -> str:
    """Add the ``origin`` remote, refusing to clobber an existing one.

    Returns one of: ``"added"`` (no origin existed), ``"unchanged"``
    (origin already pointed at ``remote_url``).

    Raises ``DocsRepoOriginConflict`` if an ``origin`` already exists
    pointing at a different URL — the caller can then surface a
    manual-step note rather than silently re-binding an unrelated
    repo (FIX-6: e.g., a user with a personal notes directory at
    ``~/<project>-docs/``).
    """
    probe = subprocess.run(
        ["git", "remote", "get-url", "origin"],
        cwd=path,
        capture_output=True,
        text=True,
    )
    if probe.returncode != 0:
        subprocess.run(
            ["git", "remote", "add", "origin", remote_url],
            cwd=path,
            check=True,
            capture_output=True,
        )
        return "added"
    existing = probe.stdout.strip()
    if existing == remote_url:
        return "unchanged"
    raise DocsRepoOriginConflict(
        f"git origin at {path} is {existing!r}; would-be target is "
        f"{remote_url!r}. Refusing to overwrite. Either: (a) confirm "
        f"this is the right repo and run `git remote set-url origin "
        f"{remote_url}` manually, or (b) move the existing repo aside "
        f"and re-run bootstrap so a fresh clone is created."
    )


def ensure_local_docs_repo(
    docs_path: Path,
    *,
    project_name: str,
    remote_url: str | None,
) -> dict[str, str]:
    """Compose the full docs-repo bootstrap: dir + README + git init + remote.

    Idempotent. Re-running on a populated docs repo is a no-op for each
    independent step. Returns a dict of action codes for each step:

      * ``dir``: ``"created"`` | ``"existed"``
      * ``readme``: ``"written"`` | ``"existed"``
      * ``git``: ``"init"`` | ``"existed"``
      * ``remote``: ``"added"`` | ``"updated"`` | ``"unchanged"`` |
        ``"skipped"`` (when ``remote_url`` is None)
    """
    dir_action = "existed" if docs_path.exists() else "created"
    docs_path.mkdir(parents=True, exist_ok=True)
    readme_action = (
        "written" if seed_docs_repo_readme(docs_path, project_name) else "existed"
    )
    git_action = "init" if git_init_if_absent(docs_path) else "existed"
    remote_action = (
        git_set_origin(docs_path, remote_url) if remote_url else "skipped"
    )
    return {
        "dir": dir_action,
        "readme": readme_action,
        "git": git_action,
        "remote": remote_action,
    }
