"""Gate evaluator entry point — runtime side of the registry (#287).

Companion to ``forge_manager_mcp.gate_registry`` (the static registry).
This module turns a gate name into an evaluation result by composing a
four-layer interceptor stack (state → override → extension → default
evaluator) and running it via :func:`forge_manager_mcp.interceptors.aexecute`.

#288 lands the project-rules layering surface — when ``project_rules``
is a :class:`forge_manager_mcp.project_rules.ProjectRules` instance the
state / override / extension layers are populated by the rules' converters;
when ``project_rules`` is None those layers stay empty and the chain
reduces to the registered default evaluator alone.

Public surface:

- :func:`evaluate_gate` — the entry point handlers call.
- :func:`build_gate_chain` — composes the interceptor stack.
- :func:`register_default_evaluator` — registers an interceptor as the
  inner-most layer for a named gate.
- :exc:`UnknownGate` — raised when ``gate_name`` is not in the registry.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any

from ..interceptors import Interceptor, aexecute
from ..project_rules import (
    ProjectRules,
    build_extension_interceptors,
    build_override_interceptors,
    build_state_interceptors,
)

if TYPE_CHECKING:
    from ..context import ServerContext
    from ..gate_registry import Gate


class UnknownGate(Exception):
    """Raised by :func:`evaluate_gate` when ``gate_name`` is not registered."""


# Async default evaluators are stored by gate name. Each takes a
# Context (the interceptor Context, not ServerContext) and returns a
# new Context — same shape as any interceptor enter handler. This is
# intentionally a module-level dict rather than a ctx attribute so the
# registration call is the same regardless of how many ServerContexts
# exist; concurrent build_server() instances share the registrations.
_DEFAULT_EVALUATORS: dict[str, Interceptor] = {}


def register_default_evaluator(gate_name: str, evaluator: Interceptor) -> None:
    """Register the default-evaluator interceptor for a gate.

    The evaluator is the inner-most layer of the chain — it's what runs
    when no project state-closure / override / extension interceptors
    short-circuit it. Re-registering for the same gate replaces the
    prior entry (last-wins, intentional — supports test fixtures and
    runtime swaps).
    """
    _DEFAULT_EVALUATORS[gate_name] = evaluator


def clear_default_evaluators() -> None:
    """Empty the default-evaluator registry. Intended for test isolation."""
    _DEFAULT_EVALUATORS.clear()


def get_default_evaluator(gate_name: str) -> Interceptor | None:
    """Return the registered default evaluator for ``gate_name`` or None."""
    return _DEFAULT_EVALUATORS.get(gate_name)


def build_gate_chain(
    gate: "Gate",
    project_rules: ProjectRules | None,
) -> list[Interceptor]:
    """Compose the four-layer interceptor stack for evaluating ``gate``.

    Outer-to-inner:

    1. state interceptors (from project_rules; close → halt)
    2. override interceptors (from project_rules; replace → halt)
    3. extension interceptors (from project_rules; layer/tighten/loosen)
    4. default evaluator (from the gate-name registration)

    With ``project_rules=None`` the first three layers are empty and
    the chain reduces to the default evaluator (or a no-op if nothing
    is registered for this gate).
    """
    chain: list[Interceptor] = []
    if project_rules is not None:
        chain.extend(build_state_interceptors(gate, project_rules))
        chain.extend(build_override_interceptors(gate, project_rules))
        chain.extend(build_extension_interceptors(gate, project_rules))
    default = get_default_evaluator(gate.name)
    if default is not None:
        chain.append(default)
    return chain


async def evaluate_gate(
    ctx: "ServerContext",
    gate_name: str,
    request: Mapping[str, Any] | None = None,
    *,
    project_rules: ProjectRules | None = None,
) -> Mapping[str, Any]:
    """Evaluate a named gate; return the response mapping.

    Builds the interceptor stack from the gate-registry record + project
    rules and runs the chain via :func:`aexecute`. On a chain-internal
    error (handler raised, no recovery), the exception is re-raised.

    When ``project_rules`` is omitted the function falls back to
    ``ctx.project_rules`` so handlers don't have to plumb it through
    every call site. Pass an explicit value to override (test fixtures;
    rule-set switching mid-session).

    Raises :exc:`UnknownGate` when ``gate_name`` isn't in the registry,
    or when the registry isn't loaded (pre-bootstrap or YAML missing).
    """
    if ctx.gate_registry is None:
        raise UnknownGate(
            f"gate registry not loaded; cannot evaluate {gate_name!r}"
        )
    gate = ctx.gate_registry.get_gate(gate_name)
    if gate is None:
        raise UnknownGate(gate_name)
    effective_rules = project_rules if project_rules is not None else ctx.project_rules
    chain = build_gate_chain(gate, effective_rules)
    final = await aexecute(chain, request=request or {})
    if final.error is not None:
        raise final.error
    return final.response


__all__ = [
    "UnknownGate",
    "build_gate_chain",
    "clear_default_evaluators",
    "evaluate_gate",
    "get_default_evaluator",
    "register_default_evaluator",
]
