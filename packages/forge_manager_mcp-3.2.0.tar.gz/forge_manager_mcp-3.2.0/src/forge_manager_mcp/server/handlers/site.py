"""Site-renderer handlers (3.0 / Phase 5): build_site, serve_site,
deploy_site. Wraps the SiteRenderer abstraction (HugoRenderer is the
3.0 default per OQ7).

The docs repo path used as the canonical source is resolved from
``ctx.config.docs_repo_path`` when set; otherwise from the
``$FORGE_MANAGER_DOCS_REPO`` env var; otherwise from the conventional
``~/<project>-docs/`` location. The build/serve/deploy operations are
all rooted at this single canonical path.
"""
from __future__ import annotations

import asyncio
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from mcp.types import TextContent

from ...context import ServerContext
from ...site_renderer import HugoRenderer
from ..helpers import ok


def _resolve_docs_repo(ctx: ServerContext) -> Path:
    """Decide which docs-repo path to render.

    Resolution order:
      1. ``ctx.config.docs_repo_path`` — set by ``scaffold_project``
         when bootstrap created a docs repo.
      2. ``$FORGE_MANAGER_DOCS_REPO`` — operator override.
      3. ``~/<project>-docs/`` — conventional location.
      4. ``~/telejester-claude-skills-docs/`` — last-resort fallback
         for the project family that predates docs-repo bootstrap.
    """
    if ctx.config is not None and ctx.config.docs_repo_path:
        return Path(ctx.config.docs_repo_path).expanduser().resolve()
    env_path = os.environ.get("FORGE_MANAGER_DOCS_REPO")
    if env_path:
        return Path(env_path).expanduser().resolve()
    project_name = ctx.project_dir.name
    candidate = Path.home() / f"{project_name}-docs"
    if not candidate.exists():
        candidate = Path.home() / "telejester-claude-skills-docs"
    return candidate.resolve()


async def build_site(
    ctx: ServerContext,
    target_dir: str,
    base_url: str = "/",
) -> list[TextContent]:
    """Render the docs repo into a static site at ``target_dir``."""
    docs_repo = _resolve_docs_repo(ctx)
    out = Path(target_dir).expanduser().resolve()

    renderer = HugoRenderer()
    if not await renderer.probe():
        return ok({
            "success": False,
            "error": "hugo CLI not reachable; install with `dnf install hugo` or equivalent",
            "docs_repo": str(docs_repo),
            "target_dir": str(out),
        })

    try:
        await renderer.build(
            docs_repo=docs_repo, target_dir=out, base_url=base_url,
        )
    except Exception as exc:
        return ok({
            "success": False,
            "error": str(exc),
            "docs_repo": str(docs_repo),
            "target_dir": str(out),
        })

    file_count = sum(1 for _ in out.rglob("*") if _.is_file())
    return ok({
        "success": True,
        "docs_repo": str(docs_repo),
        "target_dir": str(out),
        "files_emitted": file_count,
        "renderer": renderer.renderer_id,
    })


async def serve_site(
    ctx: ServerContext,
    port: int = 1313,
    bind: str = "127.0.0.1",
) -> list[TextContent]:
    """Start a local Hugo dev server in the background.

    The process runs detached; the operator stops it with the returned
    PID (`kill <pid>`). Calling serve_site again starts a *second*
    server — port collisions surface as Hugo errors at startup.
    """
    docs_repo = _resolve_docs_repo(ctx)
    renderer = HugoRenderer()
    if not await renderer.probe():
        return ok({
            "success": False,
            "error": "hugo CLI not reachable",
            "docs_repo": str(docs_repo),
        })

    # Generate the site_input + theme link first so hugo serve has
    # everything it needs.
    from ...site_renderer.frontmatter import generate_site_input

    site_input = docs_repo / "_site_input"
    generate_site_input(docs_repo=docs_repo, output_dir=site_input)

    themes_dir = site_input / "themes"
    themes_dir.mkdir(exist_ok=True)
    theme_link = themes_dir / "forge-manager-default"
    if theme_link.exists() or theme_link.is_symlink():
        if theme_link.is_symlink():
            theme_link.unlink()
        else:
            shutil.rmtree(theme_link)
    theme_link.symlink_to(renderer._theme_dir)

    from ...site_renderer.hugo import HUGO_CONFIG_TEMPLATE
    (site_input / "hugo.toml").write_text(
        HUGO_CONFIG_TEMPLATE.format(base_url="/"), encoding="utf-8",
    )

    # Spawn detached via subprocess.Popen; we don't await — caller
    # gets PID + URL back and can kill manually.
    log_path = site_input / "hugo-serve.log"
    log_fp = log_path.open("ab")
    proc = subprocess.Popen(
        ["hugo", "serve",
         "--source", str(site_input),
         "--port", str(port),
         "--bind", bind],
        stdout=log_fp,
        stderr=log_fp,
        start_new_session=True,
    )
    return ok({
        "success": True,
        "pid": proc.pid,
        "url": f"http://{bind}:{port}/",
        "log_file": str(log_path),
        "docs_repo": str(docs_repo),
    })


async def deploy_site(
    ctx: ServerContext,
    platform_id: str,
    branch: str,
    repo_url: str | None = None,
    commit_message: str = "site: rebuild",
) -> list[TextContent]:
    """Build the site, then push it to a Pages-hosting branch on the
    target repo.

    Strategy: build into a tmp dir, clone the target repo into another
    tmp dir at the deploy branch, replace contents, commit + push.

    ``repo_url`` defaults to the configured public mirror for the
    platform when ``ctx.config`` carries it; otherwise must be passed
    explicitly. Auth uses the operator's ambient git credentials
    (whatever ``git push`` would normally use against the URL); the
    handler does no token injection of its own.
    """
    if not repo_url:
        # Config integration is platform-config-specific; for Phase 5
        # we require explicit repo_url. Future iteration can pull from
        # ctx.config.platforms[platform_id].public.
        return ok({
            "success": False,
            "error": (
                "deploy_site requires explicit `repo_url`. Future Phase-6 "
                "work will read this from forge-config.json.platforms."
            ),
            "platform_id": platform_id,
        })

    docs_repo = _resolve_docs_repo(ctx)
    renderer = HugoRenderer()
    if not await renderer.probe():
        return ok({
            "success": False,
            "error": "hugo CLI not reachable",
        })

    with tempfile.TemporaryDirectory(prefix="forge-manager-deploy-") as tmpdir:
        build_dir = Path(tmpdir) / "build"
        clone_dir = Path(tmpdir) / "clone"

        # 1. Build.
        try:
            await renderer.build(
                docs_repo=docs_repo, target_dir=build_dir, base_url="/",
            )
        except Exception as exc:
            return ok({
                "success": False,
                "stage": "build",
                "error": str(exc),
            })

        # 2. Clone target repo's deploy branch.
        clone_proc = await asyncio.create_subprocess_exec(
            "git", "clone", "--branch", branch, "--single-branch",
            "--depth", "1", repo_url, str(clone_dir),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await clone_proc.communicate()
        if clone_proc.returncode != 0:
            # Branch may not exist yet — try cloning default + switching.
            clone_proc = await asyncio.create_subprocess_exec(
                "git", "clone", repo_url, str(clone_dir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await clone_proc.communicate()
            if clone_proc.returncode != 0:
                return ok({
                    "success": False,
                    "stage": "clone",
                    "error": stderr.decode("utf-8", "replace")[:2000],
                })
            # Create orphan deploy branch.
            await _git(clone_dir, "checkout", "--orphan", branch)
            await _git(clone_dir, "rm", "-rf", "--cached", ".")

        # 3. Replace contents with built site (preserve .git/).
        for entry in clone_dir.iterdir():
            if entry.name == ".git":
                continue
            if entry.is_dir():
                shutil.rmtree(entry)
            else:
                entry.unlink()
        for entry in build_dir.iterdir():
            dest = clone_dir / entry.name
            if entry.is_dir():
                shutil.copytree(entry, dest)
            else:
                shutil.copy2(entry, dest)

        # 4. Commit + push (skip if no changes).
        await _git(clone_dir, "add", "-A")
        status = await _git_check_output(clone_dir, "status", "--porcelain")
        if not status.strip():
            return ok({
                "success": True,
                "no_changes": True,
                "platform_id": platform_id,
                "branch": branch,
                "repo_url": repo_url,
            })

        await _git(clone_dir, "commit", "-m", commit_message)
        push_proc = await asyncio.create_subprocess_exec(
            "git", "push", "origin", branch,
            cwd=str(clone_dir),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await push_proc.communicate()
        if push_proc.returncode != 0:
            return ok({
                "success": False,
                "stage": "push",
                "error": stderr.decode("utf-8", "replace")[:2000],
            })

    return ok({
        "success": True,
        "platform_id": platform_id,
        "branch": branch,
        "repo_url": repo_url,
    })


async def _git(cwd: Path, *args: str) -> None:
    proc = await asyncio.create_subprocess_exec(
        "git", *args, cwd=str(cwd),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(
            f"git {' '.join(args)} failed: {stderr.decode('utf-8', 'replace')}"
        )


async def _git_check_output(cwd: Path, *args: str) -> str:
    proc = await asyncio.create_subprocess_exec(
        "git", *args, cwd=str(cwd),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, _ = await proc.communicate()
    return stdout.decode("utf-8", "replace")
