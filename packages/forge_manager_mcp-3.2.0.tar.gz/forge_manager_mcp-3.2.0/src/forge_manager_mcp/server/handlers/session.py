"""Session lifecycle handlers: open_session, close_session, recover_context."""
from __future__ import annotations

import asyncio
import secrets
from datetime import datetime, timezone

from mcp.types import TextContent

from ... import __version__
from ...automemory import commit_session_state
from ...buffer import has_pending
from ...context import ServerContext
from ...models import GithubConfig, RepoShapeEntry, SessionState, TocDrift
from ...parsers import parse_owner_repo, parse_skill_version
from ...toc_drift import compute_toc_drift
# Late binding for monkey-patch interception (#82 Phase 2b): tests
# reassign attributes on `forge_manager_mcp.server`, so handlers
# must look up github/classifier helpers through the package at call
# time rather than via early-bound `from ...github.foo import bar`.
from forge_manager_mcp import server as _s
from ..helpers import (
    fetch_project_toc_body,
    fetch_upstream_skill_text,
    ok,
    resolve_local_skill_path,
)
from ...utils import compose_session_summary


def _read_local_skill_version(project_dir) -> str | None:
    """Parse the local skill file's `**Version:**` header, or None on miss.

    Mirrors the resolve+parse flow used by check_skill_version (#60) so
    open_session reports the same version that drift checks would.
    """
    local_path = resolve_local_skill_path(project_dir)
    if local_path is None:
        return None
    try:
        return parse_skill_version(local_path.read_text(encoding="utf-8"))
    except OSError:
        return None


async def _read_latest_skill_version(
    token: str, public_repo: str, dev_repo: str
) -> str | None:
    """Fetch the upstream skill file's text, parse its version.

    Probes multiple candidate (repo, path) pairs — see helpers
    `fetch_upstream_skill_text` for the order. Returns None if every
    candidate fails (network, missing file, parse miss). (#159)
    """
    text = await fetch_upstream_skill_text(token, public_repo, dev_repo)
    if not text:
        return None
    return parse_skill_version(text)


def _build_repo_shape_targets(
    config: GithubConfig,
) -> list[tuple[str, str]]:
    """Return [(role, owner/name)] for every managed repo to audit."""
    targets: list[tuple[str, str]] = []
    targets.append(("publish_target", config.repos.public))
    targets.append(("dev", config.repos.private))
    for related in config.related_repos:
        if related.relationship == "subsystem":
            targets.append(("subsystem", related.repo))
        elif related.relationship == "publish_target":
            targets.append(("subsystem_publish", related.repo))
    return targets


def _evaluate_compliance(
    role: str,
    path: str,
    visibility: str,
    config: GithubConfig,
) -> tuple[bool, str | None]:
    """Apply §Step 3.5 compliance rules to a single repo entry.

    Rules:
    - role=dev: must be PRIVATE. Anything else is drift.
    - role=publish_target / subsystem_publish: ABSENT or PRIVATE permitted
      pre-release; PUBLIC always permitted. Outside-org placement permitted
      only if `publish_target_outside_org=True` is set.
    - role=subsystem: visibility unconstrained (subsystem repos can be
      public or private depending on project's release state).
    - For all roles: ABSENT is non-compliant unless explicitly allowed
      above.

    "Pre-release" is defined as: `publish_target_outside_org` flag is
    irrelevant; the absence/private state is permitted regardless.
    Tightening this to "no public release tag" is left to a future
    refinement when the repo-shape audit gains release-history visibility.
    """
    if role == "dev":
        if visibility == "PRIVATE":
            return True, None
        if visibility == "ABSENT":
            return False, f"dev repo not found at {path}"
        return False, f"dev repo is {visibility}; must be PRIVATE"

    if role in ("publish_target", "subsystem_publish"):
        # Cross-owner check first (org-membership of owner)
        org_owner = config.owner.lower()
        path_owner = path.split("/", 1)[0].lower()
        if path_owner != org_owner and not config.publish_target_outside_org:
            return False, (
                f"{path} owner '{path_owner}' is not the project's org "
                f"'{org_owner}'; set publish_target_outside_org=true in "
                "github-config.json if intentional"
            )
        # Visibility check — PUBLIC, PRIVATE, ABSENT all allowed.
        # INTERNAL is a no-op for now (no release-state to compare against).
        if visibility in ("PUBLIC", "PRIVATE", "ABSENT", "INTERNAL"):
            return True, None
        return False, f"unexpected visibility {visibility} for {path}"

    if role == "subsystem":
        if visibility == "ABSENT":
            return False, f"subsystem repo not found at {path}"
        return True, None

    return False, f"unknown role {role!r} for {path}"


async def _audit_one_repo(
    token: str,
    role: str,
    path: str,
    config: GithubConfig,
) -> RepoShapeEntry:
    """Per-target audit; safe to run concurrently with peers (#178).

    Each call is one `get_repo_visibility` GraphQL read plus a pure-CPU
    compliance evaluation. Returns a fully-formed RepoShapeEntry —
    including the "path malformed" and "GitHub returned ABSENT" sad
    paths — so the caller can simply `gather` and concatenate.
    """
    try:
        owner, name = parse_owner_repo(path)
    except ValueError:
        return RepoShapeEntry(
            path=path,
            role=role,
            visibility="ABSENT",
            compliant=False,
            compliance_note=f"path {path!r} is not in owner/name form",
        )
    try:
        visibility = await _s.get_repo_visibility(token, owner, name)
    except _s.GitHubError:
        visibility = None
    if visibility is None:
        visibility = "ABSENT"
    compliant, note = _evaluate_compliance(role, path, visibility, config)
    return RepoShapeEntry(
        path=path,
        role=role,
        visibility=visibility,
        compliant=compliant,
        compliance_note=note,
    )


async def _audit_repo_shape(
    token: str,
    config: GithubConfig,
) -> list[RepoShapeEntry]:
    """Query GitHub for each managed repo's visibility; evaluate compliance.

    #178 — every target is independent (no shared state between
    visibility lookups), so dispatch them in parallel via
    `asyncio.gather`. Wall time drops from N×round-trip to
    ~max-of-N. Order of returned entries matches the targets list.
    """
    targets = _build_repo_shape_targets(config)
    return list(
        await asyncio.gather(
            *(_audit_one_repo(token, role, path, config) for role, path in targets)
        )
    )


async def _audit_toc_drift(
    token: str,
    config: GithubConfig,
) -> TocDrift | None:
    """Detect Project Discussion TOC drift against current repo state (#194).

    Fetches the active TOC body plus every issue + discussion number
    in the dev repo (in parallel via `asyncio.gather`) and composes a
    `TocDrift` report. Surface is advisory: any failure
    (`GitHubError`, malformed `repos.private`, etc.) returns None and
    `open_session` proceeds — drift detection never gates a session.
    """
    try:
        owner, repo = parse_owner_repo(config.repos.private)
    except ValueError:
        return None
    try:
        toc_body, issue_numbers, discussion_numbers = await asyncio.gather(
            _s.get_discussion_body(token, config.project_discussion_id),
            _s.list_all_issue_numbers(token, owner, repo),
            _s.list_all_discussion_numbers(token, owner, repo),
        )
    except _s.GitHubError:
        return None
    drift = compute_toc_drift(toc_body, issue_numbers, discussion_numbers)
    return TocDrift(**drift)


async def open_session(ctx: ServerContext) -> list[TextContent]:
    session_id = secrets.token_hex(8)
    timestamp = datetime.now(timezone.utc).isoformat()
    mirror_failures: list[str] = []

    # Best-effort canonical-side session-event recording. Gated on
    # the Protocol capability flag from the session-event surface:
    # ``has_session_event_surface`` is True only on adapters with a
    # native session-lock surface (LocalStore today). For 2.x-shape
    # configs (single-GitHub canonical, has_session_event_surface=False)
    # this no-ops silently — the GitHub comment-write below is the
    # only persistence path.
    canonical = ctx.replication.canonical() if ctx.replication is not None else None
    if canonical is not None and getattr(
        canonical, "has_session_event_surface", False
    ):
        try:
            await canonical.record_session_event(
                session_id=session_id,
                event="opened",
                body=f"timestamp={timestamp} skill_version={__version__}",
            )
        except Exception as exc:  # noqa: BLE001 — best-effort
            mirror_failures.append(
                f"{canonical.platform_id}: record_session_event failed: {exc}"
            )

    # Read prior-session state from GitHub when reachable; tolerate
    # failure so a degraded mirror doesn't gate session_id assignment.
    # When the GitHub read fails, default prior_clean=True (assume
    # clean) — the operator can re-investigate via context recovery
    # once access is restored.
    prior_clean = True
    prior_timestamp = None
    try:
        comments = await _s.get_discussion_comments(
            ctx.github_token, ctx.config.session_lock_discussion_id, last_n=5
        )
        for comment in reversed(comments):
            body = comment["body"]
            if "**Session opened**" in body:
                prior_clean = False
                prior_timestamp = comment.get("createdAt")
                break
            if "**Session closed**" in body:
                prior_timestamp = comment.get("createdAt")
                break
    except _s.GitHubError as exc:
        mirror_failures.append(f"github: prior-session read failed: {exc}")

    # Write session-opened comment to the GitHub Session Lock Discussion.
    # Best-effort — failure surfaces in mirror_failures and does NOT
    # poison the response. session_id has already been minted and the
    # canonical write (if applicable) has already succeeded above.
    body = (
        f"**Session opened**\n"
        f"Time: {timestamp}\n"
        f"Session ID: {session_id}\n"
        f"Skill version: {__version__}"
    )
    try:
        await _s.add_discussion_comment(
            ctx.github_token, ctx.config.session_lock_discussion_id, body
        )
    except _s.GitHubError as exc:
        mirror_failures.append(f"github: session-opened write failed: {exc}")

    pending_notice = ""
    if has_pending(ctx.project_dir):
        pending_notice = " ⚠️ Pending buffer has unresolved operations."

    skill_version = _read_local_skill_version(ctx.project_dir)
    # The three GitHub-bound startup reads — upstream skill version,
    # repo-shape compliance audit (#178), TOC drift detection (#194) —
    # are independent. Dispatch them in parallel so wall time is the
    # max of the three rather than the sum. Each helper already
    # tolerates GitHubError internally and returns None / [] / None;
    # the outer try wraps the unlikely case where one of them raises
    # an unexpected error so a single failure doesn't gate the
    # session.
    latest_skill_version: str | None = None
    repo_shape: list[RepoShapeEntry] = []
    toc_drift = None
    try:
        latest_skill_version, repo_shape, toc_drift = await asyncio.gather(
            _read_latest_skill_version(
                ctx.github_token,
                ctx.config.repos.public,
                ctx.config.repos.private,
            ),
            _audit_repo_shape(ctx.github_token, ctx.config),
            _audit_toc_drift(ctx.github_token, ctx.config),
        )
    except _s.GitHubError as exc:
        mirror_failures.append(f"github: advisory reads failed: {exc}")

    state = SessionState(
        session_id=session_id,
        prior_session_clean=prior_clean,
        prior_session_timestamp=prior_timestamp,
        project_discussion_id=ctx.config.project_discussion_id,
        session_lock_discussion_id=ctx.config.session_lock_discussion_id,
        category_architecture_id=ctx.config.discussion_categories.Architecture.id,
        category_ux_ui_id=ctx.config.discussion_categories.UX_UI.id,
        category_ideas_id=ctx.config.discussion_categories.Ideas.id,
        category_claude_use_only_id=ctx.config.discussion_categories.claude_use_only.id,
        project_board_id=ctx.config.project_board.id,
        account_type=ctx.config.account_type,
        skill_version=skill_version,
        mcp_server_version=__version__,
        latest_skill_version=latest_skill_version,
        repo_shape=repo_shape,
        toc_drift=toc_drift,
    )

    result = state.model_dump()
    result["pending_notice"] = pending_notice
    result["mirror_failures"] = mirror_failures
    ctx.current_session = dict(result)
    return ok(result)


async def close_session(
    ctx: ServerContext,
    summary: str | None,
    skill_update_candidates: int,
    update_memory: bool = True,
) -> list[TextContent]:
    pending = has_pending(ctx.project_dir)
    effective = summary.strip() if isinstance(summary, str) else ""
    if not effective:
        effective = compose_session_summary(
            ctx.activity, skill_update_candidates, pending
        )

    timestamp = datetime.now(timezone.utc).isoformat()
    body = (
        f"**Session closed**\n"
        f"Time: {timestamp}\n"
        f"Summary: {effective}\n"
        f"Skill update candidates: {skill_update_candidates}"
    )

    # Best-effort GitHub-side comment write — same tolerance as
    # open_session's f4853e7 fix. Failures land in close_failures so
    # the response surfaces the degradation without dropping the
    # close itself.
    close_failures: list[str] = []
    try:
        await _s.add_discussion_comment(
            ctx.github_token, ctx.config.session_lock_discussion_id, body
        )
    except _s.GitHubError as exc:
        close_failures.append(f"github: session-closed write failed: {exc}")

    # Canonical-side session-event for the close. Same gating as
    # open_session — only LocalStore canonical with the session-event
    # surface. 2.x configs no-op silently.
    canonical = ctx.replication.canonical() if ctx.replication is not None else None
    if canonical is not None and getattr(
        canonical, "has_session_event_surface", False,
    ):
        session_id = (ctx.current_session or {}).get("session_id", "")
        if session_id:
            try:
                await canonical.record_session_event(
                    session_id=session_id, event="closed", body=effective,
                )
            except Exception as exc:  # noqa: BLE001
                close_failures.append(
                    f"{canonical.platform_id}: record_session_event failed: {exc}"
                )

    # Live-update flush (#16): if a SiteRebuilder is configured, run
    # any pending rebuild before the session ends so the rendered
    # site reflects the last-second writes. Best-effort — flush
    # failures land in close_failures alongside the GitHub close.
    rebuild_status: dict = {"flushed": False, "skipped_reason": "no_rebuilder"}
    if ctx.site_rebuilder is not None:
        try:
            flushed = await ctx.site_rebuilder.flush()
            rebuild_status = {
                "flushed": flushed is True,
                "build_attempted": flushed is not None,
                "skipped_reason": (
                    "nothing_pending" if flushed is None else None
                ),
            }
        except Exception as exc:  # noqa: BLE001
            close_failures.append(f"site_rebuilder: flush failed: {exc}")

    # Auto-memory commit (#161). Best-effort — the GitHub-side
    # session-close has already happened; a memory-write failure does
    # NOT fail close_session.
    memory_status: dict = {"committed": False, "skipped_reason": "disabled"}
    if update_memory:
        memory_status = commit_session_state(
            ctx.config, ctx.activity, skill_update_candidates, pending
        )

    return ok({
        "summary": effective,
        "memory": memory_status,
        "site_rebuild": rebuild_status,
        "close_failures": close_failures,
    })


async def recover_context(
    ctx: ServerContext,
    days: int,
    include_toc_body: bool = True,
    include_open_issues: bool = True,
    include_recent_discussions: bool = True,
    include_milestones: bool = True,
    max_open_issues: int = 100,
) -> list[TextContent]:
    """Bundled context-recovery read with optional component opt-outs (#222).

    Component opt-out flags let callers skip sections they don't need.
    Defaults reproduce the pre-2.3 behavior — every component included.

    `max_open_issues` caps the open-Issues list defensively (1–100); the
    underlying GraphQL query limits at the same range. The original
    auto-spill / file-path output proposal (#222 v1) was descoped per
    the #235 reframe cascade — the dominant byte contributor (the
    unbounded ## Issues table in the Project TOC) drops out via #235
    + #241, so the inline payload fits comfortably without auto-spill.
    """
    if max_open_issues < 1 or max_open_issues > 100:
        raise ValueError("max_open_issues must be between 1 and 100.")

    if ctx.current_session is None:
        await open_session(ctx)
    session_snapshot = ctx.current_session

    owner_name, private_repo = parse_owner_repo(ctx.config.repos.private)

    # #181 — single round-trip via aliased GraphQL on GitHub; other
    # adapters decompose into separate calls per the default helper.
    # #274 Phase C5 — dispatch through the canonical adapter.
    # #222 — component opt-outs filter the response shape after the
    # bundle returns. Sub-query elision is a future optimization.
    bundle = await ctx.replication.read(
        lambda adapter: adapter.bundle_recover_context(
            owner=owner_name,
            repo=private_repo,
            toc_discussion_id=ctx.config.project_discussion_id,
            since_days=days,
            issue_limit=max_open_issues,
        ),
        operation_name="bundle_recover_context",
    )

    response: dict = {
        "session": session_snapshot,
        # #98 — surface the typed multi-repo graph so Claude's
        # cross-repo decisions at session start don't rely on
        # memory or a second config read. Always included; tiny.
        "related_repos": [
            r.model_dump() for r in ctx.config.related_repos
        ],
    }
    if include_toc_body:
        response["project_toc_body"] = bundle.toc_body
    if include_open_issues:
        response["open_issues"] = [_issue_to_recovery_dict(i) for i in bundle.open_issues]
    if include_recent_discussions:
        response["recent_discussions"] = [
            _discussion_to_recovery_dict(d) for d in bundle.recent_discussions
        ]
    if include_milestones:
        response["milestones"] = [
            _milestone_to_recovery_dict(m) for m in bundle.milestones
        ]

    return ok(response)


def _issue_to_recovery_dict(issue) -> dict:
    """Reshape a canonical Issue to the legacy recovery-bundle dict
    shape (#274 Phase C5). Preserves the {number, title, url,
    updated_at, labels} keys callers expect."""
    return {
        "number": issue.ref.number,
        "title": issue.title,
        "url": issue.url,
        "updated_at": issue.updated_at.isoformat() if issue.updated_at else "",
        "labels": list(issue.labels),
    }


def _discussion_to_recovery_dict(disc) -> dict:
    """Reshape a canonical Discussion to legacy recovery-bundle shape
    {number, title, url, updated_at, category}."""
    # Discussions don't carry an updated_at on the canonical type
    # today; created_at is the closest proxy. Empty string when the
    # backend doesn't report a timestamp.
    return {
        "number": disc.ref.number,
        "title": disc.title,
        "url": disc.url,
        "updated_at": disc.created_at.isoformat() if disc.created_at else "",
        "category": disc.category,
    }


def _milestone_to_recovery_dict(ms) -> dict:
    """Reshape a canonical Milestone to legacy recovery-bundle shape
    {title, due_on, percent_complete}."""
    return {
        "title": ms.title,
        "due_on": ms.due_on.isoformat() if ms.due_on else None,
        "percent_complete": ms.percent_complete,
    }
