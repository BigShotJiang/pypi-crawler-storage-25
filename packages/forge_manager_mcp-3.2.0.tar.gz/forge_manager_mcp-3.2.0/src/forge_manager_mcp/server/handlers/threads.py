"""Thread handlers: post_turn, create_thread, fork_discussion,
update_project_toc, mark_discussion_decided, get_thread_comments.

Extended beyond #82's `{post_turn, create_thread, fork_discussion}`
spec to also host the orphan Discussion-side tools
(update_project_toc, mark_discussion_decided) and the general thread
reader (get_thread_comments). Keeping all Discussion-side tools
together matches the natural grouping of their github.discussions
dependencies and keeps issues.py focused on Issue-side workflow.
"""
from __future__ import annotations

from pathlib import Path

from mcp.types import TextContent

from ...context import ServerContext
from ...models import CreateThreadResult, ForkResult, PostTurnResult
from ...toc_composer import compose_post_reframe_toc
from ...utils import check_overwrite_size, resolve_new_body
# Late binding — see helpers.py docstring.
from forge_manager_mcp import server as _s
from ..helpers import fetch_project_toc_body, make_canonical_ref, ok
from ._issue_creation import create_issue_via_replication


async def post_turn(
    ctx: ServerContext,
    thread_id: str,
    thread_type: str,
    speaker: str,
    body: str,
    proj_dir: Path,
) -> list[TextContent]:
    prefix = "**Claude:**" if speaker == "claude" else "**User:**"
    formatted = f"{prefix} {body}"

    # #274 — comment append dispatches through the ReplicationManager.
    # GitHubAdapter.append_comment uses target.kind to dispatch
    # add_discussion_comment vs add_issue_comment; here we just hand
    # it a typed parent ref.
    parent_kind = "discussion" if thread_type == "discussion" else "issue"
    parent_ref = make_canonical_ref(ctx, kind=parent_kind, native_id=thread_id)
    comment = await ctx.replication.write(
        lambda adapter: adapter.append_comment(parent_ref, formatted),
        operation_name="append_comment",
    )

    ctx.activity.turns_posted += 1
    ctx.activity.turns_by_thread[thread_id] = (
        ctx.activity.turns_by_thread.get(thread_id, 0) + 1
    )

    toc_body = None
    if thread_id == ctx.config.project_discussion_id:
        toc_body = await fetch_project_toc_body(
            ctx.github_token, ctx.config.project_discussion_id
        )

    return ok(
        PostTurnResult(
            comment_id=comment.ref.native_id,
            comment_url=comment.url,
            project_toc_body=toc_body,
        ).model_dump()
    )


async def create_thread(
    ctx: ServerContext,
    thread_type: str,
    category_or_label: str,
    title: str,
    opening_body: str,
    discussion_origin_id: str,
    owner: str,
    repo: str,
    milestone: str | int | None = None,
) -> list[TextContent]:
    if thread_type == "discussion":
        # #232 — milestones are an Issue concept; reject for Discussions
        # rather than silently dropping (caught at the boundary).
        if milestone is not None:
            raise ValueError(
                "milestone parameter is not supported for type='discussion'. "
                "GitHub Discussions cannot be assigned to milestones; pass "
                "milestone only when type='issue'."
            )
        # Single-RPC lookup phase — discussion creation needs only the
        # repo node ID before the create mutation.
        repo_id = await _s.get_repo_node_id(ctx.github_token, owner, repo)
        cat_map = {
            "Architecture": ctx.config.discussion_categories.Architecture.id,
            "UX / UI": ctx.config.discussion_categories.UX_UI.id,
            "Ideas": ctx.config.discussion_categories.Ideas.id,
        }
        # #191 — `Announcements` is the running-log category designated
        # by the skill protocol (CLAUDE.md §Running-Log Discussion
        # Placement). `Project` is the legacy alias used by pre-2.0.0a2
        # bootstraps; both names resolve to whichever category the
        # config actually has populated.
        announcements = ctx.config.discussion_categories.Announcements
        project = ctx.config.discussion_categories.Project
        running_log_id = (
            announcements.id if announcements is not None
            else project.id if project is not None
            else None
        )
        if running_log_id is not None:
            cat_map["Announcements"] = running_log_id
            cat_map["Project"] = running_log_id
        category_id = cat_map.get(category_or_label)
        if not category_id:
            raise ValueError(
                f"Unknown Discussion category: {category_or_label!r}. "
                "Must be one of: Architecture, UX / UI, Ideas, "
                "Announcements (or its legacy alias Project)"
            )
        result = await _s.create_discussion(
            ctx.github_token, repo_id, category_id, title, opening_body
        )
        ctx.activity.discussions_created += 1
        return ok(
            CreateThreadResult(
                thread_id=result["id"],
                thread_number=result["number"],
                thread_url=result["url"],
                type="discussion",
                project_toc_body=await fetch_project_toc_body(
                    ctx.github_token, ctx.config.project_discussion_id
                ),
            ).model_dump()
        )

    # #274 — Issue branch dispatches through `create_issue_via_replication`,
    # the shared helper used by both create_thread and create_issue_tool.
    issue, _project_item_id = await create_issue_via_replication(
        ctx,
        owner=owner, repo=repo, title=title, body=opening_body,
        labels=[category_or_label], milestone=milestone,
    )
    return ok(
        CreateThreadResult(
            thread_id=issue.ref.native_id,
            thread_number=issue.ref.number,
            thread_url=issue.url,
            type="issue",
            project_toc_body=await fetch_project_toc_body(
                ctx.github_token, ctx.config.project_discussion_id
            ),
        ).model_dump()
    )


async def fork_discussion(
    ctx: ServerContext,
    arguments: dict,
    owner: str,
    repo: str,
) -> list[TextContent]:
    """Execute fork sequence. Not atomic — GitHub has no transaction API.
    Partial failures are reported so the caller can retry."""
    original_id = arguments["original_id"]
    fork_point_comment_id = arguments["fork_point_comment_id"]  # noqa: F841 — reserved
    new_title = arguments["new_title"]
    category_name = arguments["category_name"]
    summary = arguments["summary"]
    original_url = arguments["original_discussion_url"]
    fork_point_url = arguments["fork_point_url"]

    cat_map = {
        "Architecture": ctx.config.discussion_categories.Architecture.id,
        "UX / UI": ctx.config.discussion_categories.UX_UI.id,
        "Ideas": ctx.config.discussion_categories.Ideas.id,
    }
    category_id = cat_map.get(category_name)
    if not category_id:
        raise ValueError(f"Unknown category: {category_name!r}")

    repo_id = await _s.get_repo_node_id(ctx.github_token, owner, repo)

    new_opening = (
        f"## Forked from: [{original_url}]({original_url})\n"
        f"Fork point: [{fork_point_url}]({fork_point_url})\n\n"
        f"## Context Summary\n{summary}\n\n"
        f"---\n*Conversation continues from here.*"
    )
    new_disc = await _s.create_discussion(
        ctx.github_token, repo_id, category_id, new_title, new_opening
    )
    new_disc_id = new_disc["id"]
    new_disc_url = new_disc["url"]

    await _s.get_discussion_comments(ctx.github_token, original_id, last_n=1)
    fork_notice = (
        f"> ⚠️ This thread was partially forked.\n"
        f"> Content from [{fork_point_url}]({fork_point_url}) onward "
        f"continues in: **[{new_title}]({new_disc_url})**\n\n"
    )
    original_updated = False
    try:
        await _s.add_discussion_comment(ctx.github_token, original_id, fork_notice)
        original_updated = True
    except _s.GitHubError:
        original_updated = False

    fork_comment_body = (
        f"---\n"
        f"*Thread continues in [{new_title}]({new_disc_url}) from this point.*\n"
        f"---"
    )
    fork_comment = await _s.add_discussion_comment(
        ctx.github_token, original_id, fork_comment_body
    )

    ctx.activity.forks_executed += 1
    return ok(
        ForkResult(
            new_discussion_id=new_disc_id,
            new_discussion_url=new_disc_url,
            original_updated=original_updated,
            fork_comment_id=fork_comment["id"],
            project_toc_body=await fetch_project_toc_body(
                ctx.github_token, ctx.config.project_discussion_id
            ),
        ).model_dump()
    )


async def update_project_toc(
    ctx: ServerContext,
    new_body: str | None,
    new_body_path: str | None,
    force: bool,
) -> list[TextContent]:
    body = resolve_new_body(new_body, new_body_path)
    ref = make_canonical_ref(
        ctx, kind="discussion",
        native_id=ctx.config.project_discussion_id,
    )
    # Read + write both go through the canonical adapter (#274 Phase C1).
    current_body = await ctx.replication.read(
        lambda adapter: adapter.get_discussion_body(ref),
        operation_name="get_discussion_body",
    )
    check_overwrite_size(current_body, body, force)
    await ctx.replication.write(
        lambda adapter: adapter.update_discussion_body(ref, body, force=force),
        operation_name="update_discussion_body",
    )
    return ok("Project Discussion TOC updated.")


async def update_discussion_body_tool(
    ctx: ServerContext,
    discussion_id: str,
    new_body: str | None,
    new_body_path: str | None,
    force: bool,
) -> list[TextContent]:
    """Replace the opening post body of an arbitrary Discussion (#231).

    Mirrors `update_issue_toc` and `update_project_toc` — same fetch-
    then-replace semantics with size guardrail (#48), `new_body_path`
    file-path alternative for large bodies (#193 Phase A), and
    auto-buffer-on-failure dispatch wrapper.

    `update_project_toc` is the specialization for the configured
    Project Index Discussion. This tool is the generalization for any
    other Discussion — running-log Discussions in particular
    (Hermeticity log, Test coverage log, Protocol-rules-to-MCP-tools
    maps), where the opening post evolves session-by-session.
    """
    body = resolve_new_body(new_body, new_body_path)
    ref = make_canonical_ref(ctx, kind="discussion", native_id=discussion_id)
    # Read + write both go through the canonical adapter (#274 Phase C1).
    current_body = await ctx.replication.read(
        lambda adapter: adapter.get_discussion_body(ref),
        operation_name="get_discussion_body",
    )
    check_overwrite_size(current_body, body, force)
    await ctx.replication.write(
        lambda adapter: adapter.update_discussion_body(ref, body, force=force),
        operation_name="update_discussion_body",
    )
    return ok("Discussion opening post updated.")


async def compose_post_reframe_toc_tool(
    ctx: ServerContext,
    project_name: str,
    preamble: str,
    releases: str,
    milestones: str,
    discussions: str,
    cross_repo_activity: str,
    project_board_url: str,
    repos: str,
    pointer_line: str | None,
) -> list[TextContent]:
    """Compose the post-reframe TOC body from caller-supplied section
    markdown (#237, per Discussion #235).

    Pure-layout MCP wrapper around `toc_composer.compose_post_reframe_toc`.
    No GraphQL reads, no IO — the caller assembles per-section content
    from whatever sources fit (CHANGELOG.md for releases, GraphQL
    milestone reads, existing TOC for cross-repo activity, etc.) and
    this tool just enforces the canonical layout per #235.

    Returns:
      ``{"body": str, "size_bytes": int}``

    The body is suitable for direct round-trip through `update_project_toc(
    new_body=body, force=True)` — the post-reframe shrink will trip the
    size guardrail, which `force=True` bypasses legitimately.
    """
    body = compose_post_reframe_toc(
        project_name=project_name,
        preamble=preamble,
        releases=releases,
        milestones=milestones,
        discussions=discussions,
        cross_repo_activity=cross_repo_activity,
        project_board_url=project_board_url,
        repos=repos,
        pointer_line=pointer_line,
    )
    return ok({"body": body, "size_bytes": len(body)})


async def mark_decided(
    ctx: ServerContext,
    discussion_id: str,
    decision_comment_id: str,
    category_name: str,
) -> list[TextContent]:
    cat_map = {
        "Architecture": ctx.config.discussion_categories.Architecture,
        "UX / UI": ctx.config.discussion_categories.UX_UI,
        "Ideas": ctx.config.discussion_categories.Ideas,
    }
    category = cat_map.get(category_name)
    answer_marked = False

    # #274 Phase C6 — mark the comment as the canonical Answer if the
    # category supports it (GitHub Q&A surface). Adapters without a
    # comment-level answer concept (Forgejo / GitLab / LocalStore)
    # raise NotImplementedError, which the ReplicationManager wraps
    # as ReplicationWriteError; both fall through to the
    # answer_marked=False path so the handler keeps the legacy
    # graceful-degradation contract.
    if category and category.is_answerable:
        from ...replication.errors import ReplicationWriteError
        comment_ref = make_canonical_ref(
            ctx, kind="comment", native_id=decision_comment_id,
        )
        try:
            await ctx.replication.write(
                lambda adapter: adapter.mark_answer(comment_ref),
                operation_name="mark_answer",
            )
            answer_marked = True
        except (ReplicationWriteError, _s.GitHubError, NotImplementedError):
            answer_marked = False

    ctx.activity.discussions_decided += 1
    return ok(
        {
            "answer_marked": answer_marked,
            "message": (
                "Discussion marked as decided."
                if answer_marked
                else "Decision comment posted. Category does not support Answer marking."
            ),
            "project_toc_body": await fetch_project_toc_body(
                ctx.github_token, ctx.config.project_discussion_id
            ),
        }
    )


async def get_thread_comments(
    ctx: ServerContext,
    thread_id: str,
    thread_type: str,
    limit: int,
) -> list[TextContent]:
    parent_kind = "discussion" if thread_type == "discussion" else "issue"
    ref = make_canonical_ref(ctx, kind=parent_kind, native_id=thread_id)
    # #274 Phase C3 — adapter.list_comments takes a limit kwarg.
    # Handler reshapes canonical Comment objects back to the legacy
    # `{comment_id, author, created_at, body}` dict shape so existing
    # callers don't see an API shift.
    comments = await ctx.replication.read(
        lambda adapter: adapter.list_comments(ref, limit=limit),
        operation_name="list_comments",
    )
    legacy = [
        {
            "comment_id": c.ref.native_id,
            "author": c.author,
            "created_at": c.created_at.isoformat() if c.created_at else "",
            "body": c.body,
        }
        for c in comments
    ]
    return ok({"comments": legacy})
