"""Shared Issue-creation orchestration (#274 follow-up; DRY refactor).

`create_issue_tool` (issues.py) and `create_thread` Issue branch
(threads.py) both need the same four-step sequence:

  1. Dispatch through ``ctx.replication.write`` → ``adapter.create_issue``.
  2. Attach the new Issue to the GitHub Projects v2 board.
  3. Increment ``ctx.activity.issues_created``.

Factored here so the test surface is one helper, not two near-
duplicate handler call sites. The result-model shaping
(``CreateIssueResult`` vs ``CreateThreadResult``) and the
project-TOC-body fetch stay at the call sites — those genuinely
diverge between the two handlers.

The project-board attachment stays on ``_s.add_item_to_project``
because GitHub Projects v2 has no portable sub-protocol yet — when
that lands, only this helper changes; the call sites stay put.
"""
from __future__ import annotations

# Late binding via the server namespace keeps test monkey-patching of
# `forge_manager_mcp.server.add_item_to_project` working uniformly
# with the rest of the handler test surface.
from forge_manager_mcp import server as _s

from ...adapters.types import Issue
from ...context import ServerContext


async def create_issue_via_replication(
    ctx: ServerContext,
    *,
    owner: str,
    repo: str,
    title: str,
    body: str,
    labels: list[str],
    milestone: str | int | None = None,
) -> tuple[Issue, str]:
    """Create an Issue through the canonical ReplicationManager and
    attach it to the project board.

    Returns ``(issue, project_item_id)``. Increments
    ``ctx.activity.issues_created`` only after both the adapter call
    and the board attachment succeed — partial-success states (Issue
    created on GitHub but not on the board) leave the counter at its
    prior value so the operator-visible activity tally matches the
    fully-attached set.

    Failure semantics:

      * Adapter ``create_issue`` raises (typically wrapped as
        ``ReplicationWriteError``) → propagates; board attach is
        skipped; counter unchanged.
      * Adapter succeeds but board attach raises → the underlying
        ``GitHubError`` propagates; counter unchanged. The Issue
        exists in the canonical store and on GitHub, just not on
        the board — operator can re-attach manually.

    Caller is responsible for any ``ok(...)`` / ``err(...)`` shaping
    around the return value.
    """
    issue = await ctx.replication.write(
        lambda adapter: adapter.create_issue(
            owner=owner,
            repo=repo,
            title=title,
            body=body,
            labels=labels,
            milestone=milestone,
        ),
        operation_name="create_issue",
    )
    project_item_id = await _s.add_item_to_project(
        ctx.github_token,
        ctx.config.project_board.id,
        issue.ref.native_id,
    )
    ctx.activity.issues_created += 1
    return issue, project_item_id
