"""audit_project_prose handler (#290).

Thin MCP-tool wrapper over :mod:`forge_manager_mcp.audit_prose`. The
audit module is pure — no IO beyond reading project files; no
network. The handler adds context resolution (gate registry from
ServerContext) and parses the optional apply-finding-id branch.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

from mcp.types import TextContent

from ...audit_prose import (
    DEFAULT_EXCLUDE,
    DEFAULT_INCLUDE,
    AuditError,
    apply_finding,
    audit_prose,
)
from ...context import ServerContext
from ..helpers import err, ok
from ...models import OperationError


async def audit_project_prose(
    ctx: ServerContext,
    *,
    include: list[str] | None = None,
    exclude: list[str] | None = None,
    since: str | None = None,
    apply_finding_id: str | None = None,
) -> list[TextContent]:
    """Run the prose audit and return the report or applied migration.

    The gate registry is sourced from ``ctx.gate_registry``; when it
    isn't loaded the handler returns a clear error so the operator
    knows to fix bootstrap before running an audit.

    ``apply_finding_id`` short-circuits the report path: the audit
    runs, the matching finding is located, and its
    :attr:`audit_prose.Finding.suggested_text` is returned. If the
    finding has no suggested text (concept-redefinition / identity-
    in-rules-doc reverse-moves), an :class:`AuditError` surfaces.
    """
    if ctx.gate_registry is None:
        return err(
            OperationError(
                success=False,
                error=(
                    "audit_project_prose requires a loaded gate registry. "
                    "Make sure .claude/skills/forge-manager/gates.yaml exists "
                    "and parses cleanly."
                ),
                buffered=False,
                buffer_file=None,
                retry_tool=None,
                retry_args=None,
            )
        )

    since_dt: datetime | None = None
    if since is not None:
        try:
            since_dt = datetime.fromisoformat(since)
        except ValueError as exc:
            return err(
                OperationError(
                    success=False,
                    error=f"invalid `since` timestamp (expected ISO-8601): {exc}",
                    buffered=False,
                    buffer_file=None,
                    retry_tool=None,
                    retry_args=None,
                )
            )

    report = audit_prose(
        ctx.project_dir,
        ctx.gate_registry,
        include=tuple(include) if include else DEFAULT_INCLUDE,
        exclude=tuple(exclude) if exclude else DEFAULT_EXCLUDE,
        since=since_dt,
    )

    if apply_finding_id is None:
        return ok(report.model_dump())

    for finding in report.findings:
        if finding.id == apply_finding_id:
            try:
                migrated = apply_finding(finding, ctx.gate_registry)
            except AuditError as exc:
                return err(
                    OperationError(
                        success=False,
                        error=str(exc),
                        buffered=False,
                        buffer_file=None,
                        retry_tool=None,
                        retry_args=None,
                    )
                )
            return ok({
                "finding_id": finding.id,
                "category": finding.category,
                "file": finding.file,
                "line_range": list(finding.line_range),
                "migrated_text": migrated,
                "suggested_action": finding.suggested_action,
            })
    return err(
        OperationError(
            success=False,
            error=f"no finding with id {apply_finding_id!r}",
            buffered=False,
            buffer_file=None,
            retry_tool=None,
            retry_args=None,
        )
    )
