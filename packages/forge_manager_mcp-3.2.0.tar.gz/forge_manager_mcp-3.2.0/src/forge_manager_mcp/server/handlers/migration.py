"""Migration handlers: migrate_to_3_0, migrate_to_3_0_rollback,
add_backend (3.0 / Phase 7).

The handlers are thin wrappers over the ``forge_manager_mcp.migration``
package — detector + runner — plus a small ``add_backend`` shim that
appends a platform entry to the project's forge-config.json.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mcp.types import TextContent

from ...context import ServerContext
from ...flows.migration import build_migration_chain
from ...interceptors import aexecute
from ...migration import (
    detect_legacy_state,
    rollback_plan as _rollback_plan,
)
from ..helpers import ok


# Map MigrationPlan step.kind → chain interceptor's response key. The
# chain wrappers locate their target step in plan.steps by `kind`; this
# dict reverses that for the response-shape reconstruction.
_KIND_TO_CHAIN_STEP: dict[str, str] = {
    "translate_config_schema": "translate_schema",
    "rename_skill_dir": "rename_skill_dir",
    "bootstrap_docs_repo": "bootstrap_docs_repo",
    "update_claude_md": "rewrite_claude_md",
}


def _reconstruct_steps_list(
    plan: Any, response: dict[str, Any], apply: bool,
) -> list[dict[str, Any]]:
    """Project chain-step responses back onto the plan-step list.

    The pre-#294 handler returned ``result["steps"]`` from
    ``_apply_plan``, where each entry was
    ``{"kind", "description", "executed"}`` (with ``"dry_run": True``
    in dry-run mode). The chain stores per-step state in
    ``ctx.response[<chain-step-name>]``; this helper re-projects that
    into the response shape the existing tests + downstream consumers
    expect.
    """
    out: list[dict[str, Any]] = []
    for step in plan.steps:
        chain_name = _KIND_TO_CHAIN_STEP.get(step.kind)
        chain_state = response.get(chain_name, {}) if chain_name else {}
        status = chain_state.get("status")
        entry: dict[str, Any] = {
            "kind": step.kind,
            "description": step.description,
        }
        if not apply:
            entry["executed"] = False
            entry["dry_run"] = True
        else:
            entry["executed"] = status == "ok"
            if status not in ("ok", None):
                entry["error"] = chain_state.get(
                    "error", f"status={status}",
                )
        out.append(entry)
    return out


_FORGE_CONFIG = Path(".claude/forge-config.json")
_LEGACY_CONFIG = Path(".claude/github-config.json")


# Manual-step notes attached to migrate_to_3_0 responses (G7-G10).
# These cover the parts of the 2.x → 3.0 migration the runner can't
# automate either because they're operator-environment-specific
# (PyPI, env vars, shell config) or because they touch the live
# project beyond the .claude/ directory the migration owns.
_POST_MIGRATION_MANUAL_STEPS: tuple[str, ...] = (
    # G7 — replication_order is a default; operator may want to reorder
    # or extend it once they've added Forgejo / GitLab platforms.
    "Review `.claude/forge-config.json` `replication_order` (defaults to "
    "`[\"local\", \"github\"]`). To add a non-GitHub backend, run "
    "`add_backend` with the platform_id (`forgejo` / `gitlab` / `codeberg`) "
    "and the platform-specific config dict. Reorder `replication_order` "
    "manually to choose canonical / fan-out order.",
    # G8 — skill prose itself isn't translated; the rename only moves the
    # directory. Operator must re-install the 3.0 skill bundle.
    "Re-install the 3.0 skill bundle into "
    "`.claude/skills/forge-manager/` (the migration renamed the directory "
    "but kept its contents — content still references the 2.x name in "
    "places). Download the latest `forge-manager.md` from the public "
    "mirror's release assets and write it to "
    "`.claude/skills/forge-manager/SKILL.md`.",
    # G9 — env var rename / new defaults.
    "If you previously set `$ACTIVE_CLAUDE_GITHUB_DOCS_REPO` (rare — was "
    "not a documented 2.x var), rename it to `$FORGE_MANAGER_DOCS_REPO`. "
    "If you want the docs repo at a non-default location, set "
    "`$FORGE_MANAGER_DOCS_REPO` in your shell profile.",
    # G10 — PyPI package + .mcp.json command rename.
    "Update the MCP install: `pipx uninstall active-claude-github-mcp && "
    "pipx install forge-manager-mcp` (or `pip` equivalent). Edit "
    "`.mcp.json` so the entry's `command` is `forge-manager-mcp` (was "
    "`active-claude-github-mcp` in 2.x). Restart Claude Code so it "
    "picks up the new server binary.",
)


async def migrate_to_3_0(
    ctx: ServerContext,
    apply: bool = False,
) -> list[TextContent]:
    """Detect 2.x legacy state in ctx.project_dir and produce/apply a
    migration plan.

    ``apply=False`` (default) → dry-run; returns the steps the
    migration would take without modifying the filesystem.

    ``apply=True`` → creates a backup of .claude/ and applies each
    step in order. The returned dict carries the backup path; use
    it with ``migrate_to_3_0_rollback`` to revert.
    """
    plan = detect_legacy_state(ctx.project_dir)
    if plan.is_clean:
        return ok({
            "success": True,
            "is_clean": True,
            "summary": plan.summary(),
            "manual_steps": [],
        })

    # ----- Dispatch via migration chain (#294 Phase B) ----------------------
    # The chain wraps backup_claude_dir → detect_legacy_state →
    # translate_schema → rename_skill_dir → bootstrap_docs_repo →
    # rewrite_claude_md → finalize as compensating-transaction
    # interceptors per Discussion #3 §"Per-flow application table —
    # migrate_to_3_0". RAII pattern on backup_claude_dir: success path
    # deletes the tarball; error path preserves it for rollback. The
    # backfill_canonical_from_remote step is excluded today — backfill
    # is a separate operator-driven flow via import_remote_changes.
    chain = build_migration_chain(apply=apply, include_backfill=False)
    final_ctx = await aexecute(
        chain,
        request={
            "project_dir": ctx.project_dir,
            "apply": apply,
            "plan": plan,
        },
    )

    backup_path = final_ctx.response.get(
        "backup_claude_dir", {},
    ).get("backup_path")

    if final_ctx.error is not None:
        return ok({
            "success": False,
            "error": str(final_ctx.error),
            "summary": plan.summary(),
            "backup_path": str(backup_path) if backup_path else None,
        })

    return ok({
        "success": True,
        "applied": apply,
        "summary": plan.summary(),
        # G7-G10: post-migration operator checklist that the runner can't
        # automate — replication_order tuning, skill-prose re-install,
        # env var rename, PyPI/MCP wiring update.
        "manual_steps": list(_POST_MIGRATION_MANUAL_STEPS),
        "project_dir": str(plan.project_dir),
        "steps": _reconstruct_steps_list(plan, final_ctx.response, apply),
        "backup_path": str(backup_path) if backup_path else None,
        "warnings": list(plan.warnings),
    })


async def migrate_to_3_0_rollback(
    ctx: ServerContext,
    backup_path: str,
) -> list[TextContent]:
    """Restore .claude/ from a backup produced by migrate_to_3_0(apply=True)."""
    try:
        result = _rollback_plan(
            project_dir=ctx.project_dir,
            backup_path=Path(backup_path),
        )
    except Exception as exc:
        return ok({"success": False, "error": str(exc)})
    return ok({"success": True, **result})


async def add_backend(
    ctx: ServerContext,
    platform_id: str,
    config: dict[str, Any],
) -> list[TextContent]:
    """Append a new platform entry to the project's forge-config.json
    platforms list.

    The handler validates that the new platform_id isn't already
    registered (idempotent — second call with same platform_id is a
    no-op + reports already-present), and writes the updated config
    back. Token validation is deferred to the next session start;
    surfacing it here would require the adapter classes which are a
    separate import surface.
    """
    config_path = ctx.project_dir / _FORGE_CONFIG
    if not config_path.is_file():
        # Fall back to the legacy config path; common during partial
        # migration windows.
        legacy_path = ctx.project_dir / _LEGACY_CONFIG
        if legacy_path.is_file():
            return ok({
                "success": False,
                "error": (
                    "Project still on legacy github-config.json. Run "
                    "migrate_to_3_0 with apply=True before adding "
                    "additional backends."
                ),
            })
        return ok({
            "success": False,
            "error": f"forge-config.json not found at {config_path}",
        })

    try:
        existing = json.loads(config_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        return ok({"success": False, "error": f"could not parse forge-config: {exc}"})

    platforms = existing.setdefault("platforms", [])
    for entry in platforms:
        if entry.get("id") == platform_id:
            return ok({
                "success": True,
                "already_present": True,
                "platform_id": platform_id,
                "platforms": platforms,
            })

    new_entry = {"id": platform_id, **config}
    platforms.append(new_entry)

    # Replication order — append the new platform if not already there.
    repl_order = existing.setdefault("replication_order", ["local"])
    if platform_id not in repl_order:
        repl_order.append(platform_id)

    config_path.write_text(
        json.dumps(existing, indent=2) + "\n", encoding="utf-8",
    )
    return ok({
        "success": True,
        "added": True,
        "platform_id": platform_id,
        "platforms": platforms,
        "replication_order": repl_order,
    })
