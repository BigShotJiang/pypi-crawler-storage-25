"""Server construction and dispatch.

`build_server` wires MCP's `list_tools` / `call_tool` decorators to
handler functions living in `.handlers.*`. Each handler accepts
`ctx: ServerContext` as its first parameter; dispatch passes `ctx`
explicitly.
"""
from __future__ import annotations

from pathlib import Path

from mcp.server import Server
from mcp.types import TextContent, Tool

# Late binding — see helpers.py docstring. `build_server` reads
# exception classes (GitHubError, ClassificationError,
# InvalidNodeIdError) via _s so tests can monkey-patch them if needed,
# matching pre-split behaviour.
from forge_manager_mcp import server as _s
from ..buffer import write_pending
from ..config import (
    ConfigError,
    ConfigMissingError,
    get_github_token,
    load_config,
    require_env,
)
from ..adapters.github import GitHubAdapter
from ..adapters.local_store import LocalStoreAdapter
from ..adapters.protocol import PlatformAdapter
from ..adapters.registry import PLATFORM_ADAPTERS as _PLATFORM_ADAPTERS
from ..context import ServerContext
from ..gate_registry import (
    GateRegistry,
    GateRegistryError,
    ProcessRegistry,
    load_gates,
    load_processes,
)
from ..models import GithubConfig, OperationError
from ..parsers import parse_owner_repo
from ..project_rules import (
    ProjectRules,
    ProjectRulesError,
    load_project_rules,
    validate_against_registry,
)
from ..replication.errors import ReplicationWriteError
from ..replication.manager import ReplicationManager
from ..site_renderer.rebuilder import SiteRebuilder
from .helpers import (
    err,
    ok,
    preflight_cross_repo_mutation,
    resolve_thread_identifier,
    validate_tool_node_ids,
)
from .preflight import CrossRepoMutationBlocked
from .handlers import audit as audit_handlers
from .handlers import infra as infra_handlers
from .handlers import issues as issues_handlers
from .handlers import meta as meta_handlers
from .handlers import migration as migration_handlers
from .handlers import release as release_handlers
from .handlers import session as session_handlers
from .handlers import site as site_handlers
from .handlers import threads as threads_handlers
from .handlers import verify as verify_handlers
from .tool_schemas import all_tool_schemas


def _build_replication(
    config: GithubConfig | None, github_token: str
) -> ReplicationManager | None:
    """Construct the per-server ReplicationManager from project config (#274).

    Two paths:

    * **3.0 multi-platform** — ``config.platforms`` is non-empty and
      ``config.replication_order`` lists at least one platform_id.
      Build the manager by walking ``replication_order`` in order;
      for each ID, find the matching ``platforms[*]`` entry (or
      synthesize a default for ``local``, which is implicit) and
      construct via the adapter's ``from_config`` classmethod. First
      entry is canonical per OQ3.
    * **2.x single-GitHub fallback** — used when ``platforms`` is
      empty (legacy ``github-config.json`` configs that haven't run
      the 2.x → 3.0 migration tool). Wraps a single ``GitHubAdapter``
      in a one-element ``ReplicationManager``.

    Pre-bootstrap mode (config is None) returns None.
    """
    if config is None:
        return None

    # Multi-platform path is gated on `schema_version == "3.0"` rather
    # than the presence of either field individually — that way an
    # inconsistent config (one of platforms / replication_order
    # populated but not the other) fails loudly inside
    # `_build_replication_from_platforms` rather than silently falling
    # back to the 2.x single-GitHub wrapper.
    if config.schema_version == "3.0":
        return _build_replication_from_platforms(config, github_token)

    # 2.x single-GitHub fallback.
    adapter = GitHubAdapter(token=github_token)
    return ReplicationManager([("github", adapter)])


def _build_replication_from_platforms(
    config: GithubConfig, github_token: str
) -> ReplicationManager:
    """Assemble the ReplicationManager from a 3.0 forge-config (#274 Phase D).

    Walks ``config.replication_order`` in order. Each entry is a
    platform_id matched against ``config.platforms[*]['id']``; the
    matching entry is passed to that platform's adapter
    ``from_config`` classmethod.

    ``local`` is implicit — if it appears in ``replication_order``
    but no ``platforms[id=local]`` entry exists, synthesize a default
    config (LocalStoreAdapter falls back to env var + home dir).
    """
    platforms_by_id = {entry.get("id", ""): entry for entry in config.platforms}
    adapters: list[tuple[str, PlatformAdapter]] = []
    for platform_id in config.replication_order:
        adapter_cls = _PLATFORM_ADAPTERS.get(platform_id)
        if adapter_cls is None:
            raise ConfigError(
                f"Unknown platform_id {platform_id!r} in "
                f"replication_order. Known: {sorted(_PLATFORM_ADAPTERS)}."
            )
        platform_config = platforms_by_id.get(platform_id)
        if platform_config is None:
            if platform_id == "local":
                # Local is implicit — synthesize a default config.
                platform_config = {"id": "local"}
            else:
                raise ConfigError(
                    f"replication_order references {platform_id!r} but no "
                    "matching entry in platforms[]."
                )
        adapter = adapter_cls.from_config(platform_config)
        adapters.append((platform_id, adapter))

    if not adapters:
        raise ConfigError(
            "replication_order is non-empty but no adapters were "
            "constructed. Check forge-config.json shape."
        )
    return ReplicationManager(adapters)


def _build_site_rebuilder(
    config: GithubConfig | None, replication: ReplicationManager | None,
) -> SiteRebuilder | None:
    """Construct the live-update SiteRebuilder when configured.

    Returns None when:
      * config is None (pre-bootstrap), or
      * config.site is None (no live-update block), or
      * config.site.auto_rebuild is False (opt-in flag absent), or
      * replication is None or its canonical adapter isn't a LocalStore
        (live-update only makes sense when LocalStore is canonical —
        we read the docs-repo path from the canonical adapter).

    Otherwise constructs a SiteRebuilder pointed at the canonical
    LocalStoreAdapter's ``path`` for the docs repo and ``config.site
    .target_dir`` for the rendered output. The caller (build_server)
    re-wires the ReplicationManager with the rebuilder's notify hook
    by replacing the manager via a fresh construction — see
    build_server below for the integration point.
    """
    if config is None or config.site is None or replication is None:
        return None
    if not config.site.auto_rebuild:
        return None
    canonical = replication.canonical()
    if not isinstance(canonical, LocalStoreAdapter):
        # Live-update without a LocalStore canonical means we'd be
        # rendering from a remote backend — out of scope. The
        # rebuilder needs a filesystem path to read.
        return None
    deploy_target = (
        config.site.deploy_target if config.site.auto_deploy else None
    )
    return SiteRebuilder(
        docs_repo=canonical.path,
        target_dir=Path(config.site.target_dir).expanduser(),
        debounce_seconds=config.site.debounce_seconds,
        deploy_target=deploy_target if deploy_target else None,
    )


_DEFAULT_SKILL_DIR = Path(".claude") / "skills" / "forge-manager"


def _load_registries(
    project_dir: Path,
) -> tuple[GateRegistry | None, ProcessRegistry | None]:
    """Load gate + process registries from the project's skill directory (#287).

    Returns ``(None, None)`` for either when the matching YAML file is
    absent or fails to parse. Failures log a warning rather than aborting
    server startup so a malformed registry doesn't take the whole server
    down — handlers that call ``evaluate_gate`` see ``UnknownGate`` and
    handle it like any other gate-not-registered case.
    """
    import logging

    logger = logging.getLogger(__name__)
    skill_dir = project_dir / _DEFAULT_SKILL_DIR

    gates_path = skill_dir / "gates.yaml"
    processes_path = skill_dir / "processes.yaml"

    gate_registry: GateRegistry | None = None
    if gates_path.exists():
        try:
            gate_registry = load_gates(gates_path)
        except GateRegistryError as exc:
            logger.warning("gate_registry: failed to load %s: %s", gates_path, exc)

    process_registry: ProcessRegistry | None = None
    if processes_path.exists():
        try:
            process_registry = load_processes(processes_path)
        except GateRegistryError as exc:
            logger.warning(
                "process_registry: failed to load %s: %s", processes_path, exc
            )

    return gate_registry, process_registry


def _load_project_rules(
    project_dir: Path, gate_registry: GateRegistry | None
) -> ProjectRules | None:
    """Load .claude/project-rules.md when present and validate against the
    gate registry (#288).

    Returns None when the file is absent (no rules, default-only chains)
    or when the file fails to parse / validate. Like
    ``_load_registries``, parse / validation failure logs a warning and
    starts the server in degraded mode rather than aborting.

    The validation step runs only when ``gate_registry`` is non-None.
    Without a registry there's no truth source to validate references
    against — the rules still parse and attach so independent rules
    (which don't reference gates) remain accessible.
    """
    import logging

    logger = logging.getLogger(__name__)
    rules_path = project_dir / ".claude" / "project-rules.md"
    if not rules_path.exists():
        return None
    try:
        rules = load_project_rules(rules_path)
    except ProjectRulesError as exc:
        logger.warning("project_rules: failed to parse %s: %s", rules_path, exc)
        return None
    if gate_registry is not None:
        try:
            validate_against_registry(rules, gate_registry)
        except ProjectRulesError as exc:
            logger.warning(
                "project_rules: %s references unknown gates: %s. "
                "Loading anyway; evaluate_gate will skip the unknown layers.",
                rules_path,
                exc,
            )
    return rules


def _resolve_public_face(
    config: GithubConfig | None, replication: ReplicationManager | None,
) -> "PlatformAdapter | None":
    """Resolve the configured public-face adapter (#280).

    Returns None when:
      * config is None (pre-bootstrap), or
      * config.public_face is None (no public face configured), or
      * replication is None (2.x-compat fallback or pre-bootstrap), or
      * the named platform_id has no matching adapter in the chain.

    Otherwise returns the PlatformAdapter from the replication chain
    whose ``platform_id`` matches ``config.public_face``. Handlers that
    touch the public face dispatch through ``ctx.public_face`` rather
    than hardcoding GitHub-specific paths.
    """
    if config is None or config.public_face is None or replication is None:
        return None
    target_id = config.public_face
    for _name, adapter in replication.entries():
        if getattr(adapter, "platform_id", None) == target_id:
            return adapter
    return None


def build_server(
    project_dir: Path,
) -> tuple[Server, GithubConfig | None, str, str]:
    """Build and configure the MCP server.

    Fails immediately (ConfigError) if config is malformed, fails
    validation, ANTHROPIC_API_KEY is unset, or a GitHub token is
    unavailable.

    If `.claude/github-config.json` is *absent* (pre-bootstrap), the
    server starts in **degraded mode** (#156): only `scaffold_project`
    and `check_skill_version` are callable; every other tool returns a
    bootstrap-required error. After bootstrap completes the operator
    must restart Claude Code so the next session loads the new config.

    Returns (server, config_or_None, github_token, anthropic_api_key).
    """
    pre_bootstrap = False
    try:
        config: GithubConfig | None = load_config(project_dir)
    except ConfigMissingError:
        config = None
        pre_bootstrap = True

    github_token = get_github_token()
    anthropic_api_key = require_env("ANTHROPIC_API_KEY")

    server = Server("forge-manager")

    replication = _build_replication(config, github_token)
    site_rebuilder = _build_site_rebuilder(config, replication)
    if site_rebuilder is not None and replication is not None:
        # Wire the live-update hook now that both halves exist.
        replication.set_on_canonical_write(site_rebuilder.notify)

    public_face = _resolve_public_face(config, replication)
    gate_registry, process_registry = _load_registries(project_dir)
    project_rules = _load_project_rules(project_dir, gate_registry)

    ctx = ServerContext(
        config=config,
        github_token=github_token,
        anthropic_api_key=anthropic_api_key,
        project_dir=project_dir,
        pre_bootstrap=pre_bootstrap,
        replication=replication,
        site_rebuilder=site_rebuilder,
        public_face=public_face,
        gate_registry=gate_registry,
        process_registry=process_registry,
        project_rules=project_rules,
    )

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return all_tool_schemas()

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        # Pre-bootstrap mode (#156): only `scaffold_project` and
        # `check_skill_version` are config-independent. Other tools
        # would crash on `ctx.config.*` access; instead, return a clear
        # bootstrap-required error so the operator sees what to do.
        _PRE_BOOTSTRAP_SAFE = {
            "scaffold_project",
            "scaffold_project_multi",
            "check_skill_version",
        }
        if ctx.pre_bootstrap and name not in _PRE_BOOTSTRAP_SAFE:
            ctx.activity.tool_errors += 1
            return err(
                OperationError(
                    success=False,
                    error=(
                        f"Tool {name!r} requires .claude/github-config.json. "
                        "This project has not been bootstrapped yet. Run "
                        "`scaffold_project` first (or follow §Self-Bootstrap). "
                        "After bootstrap completes, restart Claude Code so "
                        "the next session picks up the generated config."
                    ),
                    buffered=False,
                    buffer_file=None,
                    retry_tool=None,
                    retry_args=None,
                )
            )

        # Pre-bootstrap-safe handlers don't read ctx.config; full-mode
        # handlers do. Resolve owner/repo only in full mode to avoid a
        # None.repos crash on the pre-bootstrap path.
        if ctx.config is not None:
            owner, private_repo = parse_owner_repo(ctx.config.repos.private)
        else:
            owner, private_repo = "", ""

        try:
            await validate_tool_node_ids(name, arguments, ctx.github_token)

            # Cross-repo mutation preflight (#98). No-op unless the
            # caller passed explicit owner/repo targeting a cousin /
            # foreign repo per related_repos. Skipped pre-bootstrap.
            if ctx.config is not None:
                preflight_cross_repo_mutation(ctx.config, arguments)

            if name == "open_session":
                return await session_handlers.open_session(ctx)

            if name == "recover_context":
                return await session_handlers.recover_context(
                    ctx,
                    int(arguments.get("days", 7)),
                    include_toc_body=bool(arguments.get("include_toc_body", True)),
                    include_open_issues=bool(arguments.get("include_open_issues", True)),
                    include_recent_discussions=bool(
                        arguments.get("include_recent_discussions", True)
                    ),
                    include_milestones=bool(arguments.get("include_milestones", True)),
                    max_open_issues=int(arguments.get("max_open_issues", 100)),
                )

            if name == "scaffold_project":
                return await infra_handlers.scaffold_project(
                    ctx,
                    arguments["org"],
                    arguments["project_name"],
                    arguments.get("description", ""),
                )

            if name == "scaffold_project_multi":
                return await infra_handlers.scaffold_project_multi(
                    ctx,
                    project_name=arguments["project_name"],
                    description=arguments.get("description", ""),
                    platforms=list(arguments.get("platforms") or []),
                    replication_order=list(
                        arguments.get("replication_order") or []
                    ),
                    require_bazel_builds=bool(
                        arguments.get("require_bazel_builds", False)
                    ),
                    require_maximal_coverage=bool(
                        arguments.get("require_maximal_coverage", False)
                    ),
                    enable_llm_verifier=arguments.get("enable_llm_verifier"),
                    custom_running_log=arguments.get("custom_running_log"),
                )

            if name == "classify_and_create":
                return await meta_handlers.classify_and_create(
                    ctx,
                    arguments["text"],
                    arguments.get("auto_create_threshold", "high"),
                    bool(arguments.get("also_post_turn", True)),
                    arguments.get("opening_body", ""),
                    owner,
                    private_repo,
                )

            if name == "check_skill_version":
                return await infra_handlers.check_skill_version(ctx)

            if name == "replay_pending":
                targets = arguments.get("targets")
                inspect_only = bool(arguments.get("inspect_only", False))
                return await infra_handlers.replay_pending(
                    ctx, call_tool,
                    targets=targets,
                    inspect_only=inspect_only,
                )

            if name == "close_issue_with_comment":
                issue_id = await resolve_thread_identifier(
                    ctx.github_token,
                    arguments,
                    primary_id_param="issue_id",
                    kind="issue",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await issues_handlers.close_issue_with_comment(
                    ctx,
                    issue_id,
                    arguments["comment"],
                    arguments.get("state_reason", "completed"),
                )

            if name == "close_triaged_public_issues":
                return await issues_handlers.close_triaged_public_issues(
                    ctx,
                    arguments["version"],
                    bool(arguments.get("dry_run", True)),
                    bool(arguments.get("skip_pre_release", True)),
                )

            if name == "get_thread_comments":
                return await threads_handlers.get_thread_comments(
                    ctx,
                    arguments["thread_id"],
                    arguments["thread_type"],
                    int(arguments.get("limit", 20)),
                )

            if name == "close_session":
                return await session_handlers.close_session(
                    ctx,
                    arguments.get("summary"),
                    int(arguments.get("skill_update_candidates", 0)),
                    bool(arguments.get("update_memory", True)),
                )

            if name == "post_turn":
                thread_type = arguments["thread_type"]
                thread_id = await resolve_thread_identifier(
                    ctx.github_token,
                    arguments,
                    primary_id_param="thread_id",
                    kind=thread_type,
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await threads_handlers.post_turn(
                    ctx,
                    thread_id,
                    thread_type,
                    arguments["speaker"],
                    arguments["body"],
                    ctx.project_dir,
                )

            if name == "create_thread":
                return await threads_handlers.create_thread(
                    ctx,
                    arguments["type"],
                    arguments["category_or_label"],
                    arguments["title"],
                    arguments["opening_body"],
                    arguments.get("discussion_origin_id", ""),
                    owner,
                    private_repo,
                    milestone=arguments.get("milestone"),
                )

            if name == "classify_turn":
                return await meta_handlers.classify_turn(ctx, arguments["text"])

            if name == "detect_theme_change":
                return await meta_handlers.detect_theme_change(
                    ctx,
                    arguments["thread_id"],
                    arguments["new_turn_text"],
                )

            if name == "fork_discussion":
                original_id = await resolve_thread_identifier(
                    ctx.github_token,
                    arguments,
                    primary_id_param="original_id",
                    kind="discussion",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                fork_args = dict(arguments)
                fork_args["original_id"] = original_id
                return await threads_handlers.fork_discussion(
                    ctx, fork_args, owner, private_repo
                )

            if name == "create_issue":
                # Accept either `labels: List[str]` (#55) or the deprecated
                # single `label: str` form. Exactly one must be provided.
                raw_labels = arguments.get("labels")
                legacy_label = arguments.get("label")
                if raw_labels is not None and legacy_label:
                    raise ValueError(
                        "Provide either `labels` or `label`, not both. "
                        "`label` is deprecated."
                    )
                if raw_labels is None and not legacy_label:
                    raise ValueError(
                        "Either `labels` (list) or `label` (deprecated "
                        "single value) must be provided."
                    )
                labels_list = (
                    [legacy_label] if legacy_label else list(raw_labels or [])
                )
                return await issues_handlers.create_issue_tool(
                    ctx,
                    arguments["title"],
                    arguments["body"],
                    labels_list,
                    arguments.get("discussion_origin_id", ""),
                    owner,
                    private_repo,
                    milestone=arguments.get("milestone"),
                )

            if name == "update_issue_toc":
                issue_id = await resolve_thread_identifier(
                    ctx.github_token,
                    arguments,
                    primary_id_param="issue_id",
                    kind="issue",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await issues_handlers.update_issue_toc(
                    ctx,
                    issue_id,
                    arguments.get("new_body"),
                    arguments.get("new_body_path"),
                    bool(arguments.get("force", False)),
                )

            if name == "move_project_item":
                issue_id = await resolve_thread_identifier(
                    ctx.github_token,
                    arguments,
                    primary_id_param="issue_id",
                    kind="issue",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await issues_handlers.move_project_item(
                    ctx,
                    arguments["column_name"],
                    issue_id,
                )

            if name == "update_project_toc":
                return await threads_handlers.update_project_toc(
                    ctx,
                    arguments.get("new_body"),
                    arguments.get("new_body_path"),
                    bool(arguments.get("force", False)),
                )

            if name == "update_discussion_body":
                discussion_id = await resolve_thread_identifier(
                    ctx.github_token,
                    arguments,
                    primary_id_param="discussion_id",
                    kind="discussion",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await threads_handlers.update_discussion_body_tool(
                    ctx,
                    discussion_id,
                    arguments.get("new_body"),
                    arguments.get("new_body_path"),
                    bool(arguments.get("force", False)),
                )

            if name == "search_issues":
                # Allow caller to override repo scope (e.g., search the
                # public mirror instead of the dev repo). Defaults to dev.
                search_owner = arguments.get("owner") or owner
                search_repo = arguments.get("repo") or private_repo
                return await issues_handlers.search_issues_tool(
                    ctx,
                    arguments.get("query", ""),
                    arguments.get("state", "all"),
                    arguments.get("labels"),
                    arguments.get("milestone"),
                    search_owner,
                    search_repo,
                    int(arguments.get("limit", 50)),
                )

            if name == "compose_post_reframe_toc":
                return await threads_handlers.compose_post_reframe_toc_tool(
                    ctx,
                    arguments["project_name"],
                    arguments.get("preamble", ""),
                    arguments.get("releases", ""),
                    arguments.get("milestones", ""),
                    arguments.get("discussions", ""),
                    arguments.get("cross_repo_activity", ""),
                    arguments.get("project_board_url", ""),
                    arguments.get("repos", ""),
                    arguments.get("pointer_line"),
                )

            if name == "generate_changelog":
                return await release_handlers.generate_changelog(
                    ctx,
                    bool(arguments.get("write", False)),
                )

            if name == "validate_release":
                return await release_handlers.validate_release(
                    ctx,
                    arguments["version"],
                    bool(arguments.get("skip_bazel", False)),
                )

            if name == "verify_plan_completeness":
                return await verify_handlers.verify_plan_completeness(
                    ctx,
                    arguments["plan_body"],
                )

            if name == "verify_existing_code_assumptions":
                return await verify_handlers.verify_existing_code_assumptions(
                    ctx,
                    arguments["plan_body"],
                    arguments["pr_diff"],
                    arguments.get("repo_root"),
                    arguments.get("model", "claude-sonnet-4-6"),
                    int(arguments.get("token_budget", 100_000)),
                )

            if name == "verify_diff_covers_plan":
                # `project_rules` is intentionally optional at the
                # tool surface — callers that omit it inherit the
                # default rule set (#192) composed from the project's
                # configured fields. Explicit lists from operators
                # override the default so projects can experiment
                # without touching config.
                project_rules = arguments.get("project_rules")
                return await verify_handlers.verify_diff_covers_plan(
                    ctx,
                    arguments["plan_body"],
                    arguments["diff_text"],
                    arguments.get("evidence_text", ""),
                    project_rules,
                )

            if name == "release_project":
                return await release_handlers.release_project(
                    ctx,
                    arguments["version"],
                    bool(arguments.get("dry_run", True)),
                    arguments.get("stop_after", "release_notes"),
                    bool(arguments.get("approve_version_bump", False)),
                    bool(arguments.get("skip_bazel", False)),
                    pypi_only=bool(arguments.get("pypi_only", False)),
                )

            if name == "mark_discussion_decided":
                discussion_id = await resolve_thread_identifier(
                    ctx.github_token,
                    arguments,
                    primary_id_param="discussion_id",
                    kind="discussion",
                    default_owner=owner,
                    default_repo=private_repo,
                )
                return await threads_handlers.mark_decided(
                    ctx,
                    discussion_id,
                    arguments["decision_comment_id"],
                    arguments["category_name"],
                )

            if name == "migrate_to_3_0":
                return await migration_handlers.migrate_to_3_0(
                    ctx,
                    bool(arguments.get("apply", False)),
                )

            if name == "migrate_to_3_0_rollback":
                return await migration_handlers.migrate_to_3_0_rollback(
                    ctx,
                    arguments["backup_path"],
                )

            if name == "add_backend":
                return await migration_handlers.add_backend(
                    ctx,
                    arguments["platform_id"],
                    arguments["config"],
                )

            if name == "build_site":
                return await site_handlers.build_site(
                    ctx,
                    arguments["target_dir"],
                    arguments.get("base_url", "/"),
                )

            if name == "serve_site":
                return await site_handlers.serve_site(
                    ctx,
                    int(arguments.get("port", 1313)),
                    arguments.get("bind", "127.0.0.1"),
                )

            if name == "deploy_site":
                return await site_handlers.deploy_site(
                    ctx,
                    arguments["platform_id"],
                    arguments["branch"],
                    arguments.get("repo_url"),
                    arguments.get("commit_message", "site: rebuild"),
                )

            if name == "audit_project_prose":
                return await audit_handlers.audit_project_prose(
                    ctx,
                    include=arguments.get("include"),
                    exclude=arguments.get("exclude"),
                    since=arguments.get("since"),
                    apply_finding_id=arguments.get("apply_finding_id"),
                )

            return ok(f"Unknown tool: {name}")

        except _s.InvalidNodeIdError as exc:
            # Client-side error — do NOT buffer. Retrying the same bad
            # ID would fail identically and clog the buffer (#51).
            ctx.activity.tool_errors += 1
            return err(
                OperationError(
                    success=False,
                    error=str(exc),
                    buffered=False,
                    buffer_file=None,
                    retry_tool=None,
                    retry_args=None,
                )
            )

        except CrossRepoMutationBlocked as exc:
            # Protocol gate, not a transient error (#98). Not buffered —
            # retrying without user permission would fail identically.
            ctx.activity.tool_errors += 1
            return err(
                OperationError(
                    success=False,
                    error=(
                        f"{exc.relationship}-repo mutation blocked: "
                        f"{exc.target_repo}"
                    ),
                    buffered=False,
                    buffer_file=None,
                    retry_tool=None,
                    retry_args=None,
                    manual_step=exc.manual_step,
                )
            )

        except (
            ValueError,
            _s.GitHubError,
            _s.ClassificationError,
            ReplicationWriteError,
        ) as exc:
            # ReplicationWriteError wraps backend errors raised by the
            # canonical adapter (#274). The wrapped cause is typically
            # a GitHubError for the GitHub-canonical 2.x config path;
            # handling them here means the buffered-error envelope
            # surfaces the same retry semantics regardless of which
            # layer threw.
            ctx.activity.tool_errors += 1
            buffer_path = write_pending(
                ctx.project_dir, name, arguments, str(exc)
            )
            return err(
                OperationError(
                    success=False,
                    error=str(exc),
                    buffered=True,
                    buffer_file=str(buffer_path),
                    retry_tool=name,
                    retry_args=arguments,
                )
            )

    # Expose the registered handlers for test harnesses (#65).
    server.list_tools_handler = list_tools  # type: ignore[attr-defined]
    server.call_tool_handler = call_tool  # type: ignore[attr-defined]

    return server, config, github_token, anthropic_api_key
