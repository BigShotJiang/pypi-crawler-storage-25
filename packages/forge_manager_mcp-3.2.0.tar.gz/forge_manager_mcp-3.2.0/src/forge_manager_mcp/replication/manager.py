"""ReplicationManager — coordinates writes + reads across the
configured PlatformAdapters (3.0 / Phase 6).

Design principles (from OQ3 + OQ6):

  * **Local store is canonical.** Every write hits LocalStoreAdapter
    first; only after that succeeds does the manager fan out to
    remote mirrors. A failed local write is fatal; a failed remote
    write degrades that adapter but doesn't fail the call.

  * **Read-path failover.** ``read(...)`` tries adapters in
    ``replication_order``; first one that returns wins. Per-adapter
    classified-unavailable failures (``ForgeUnavailableError``)
    cascade to the next adapter; any other exception propagates.

  * **Per-adapter state machine.** Each adapter carries a state
    (HEALTHY / DEGRADED / RECONCILING). A failed remote write moves
    that one adapter to DEGRADED; the others stay HEALTHY. State
    is in-memory per process; persistence is Phase 7+ work.

The manager is intentionally small at this sub-run — orchestration
shape only. Method coverage on the wrapped adapters is restricted to
the Protocol surface defined in ``adapters.protocol.PlatformAdapter``;
the operations supported here mirror that surface one-for-one.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Awaitable, Callable, TypeVar

from ..adapters import errors as _adapter_errors
from ..adapters.protocol import PlatformAdapter
from ..adapters.types import (
    ArtifactKind,
    HistoryEntry,
    ImportConflict,
    ImportReport,
    RemoteChange,
)
from .errors import AllAdaptersFailedError, ReplicationWriteError


T = TypeVar("T")


class AdapterState(str, Enum):
    """Per-adapter state used by ``ReplicationManager`` to decide
    whether to attempt an operation and how to interpret failures.

    Values are strings so they serialize cleanly into log output and
    future persistence formats.
    """

    HEALTHY = "healthy"
    """All recent operations against this adapter succeeded; the
    next operation is attempted normally."""

    DEGRADED = "degraded"
    """A recent operation failed with a classified-unavailable error
    (token expired, 5xx, network). Read-path skips this adapter on
    the way to a healthy one; write fan-out queues operations for
    later replay."""

    RECONCILING = "reconciling"
    """An adapter is being brought back from DEGRADED — drift detection
    + import_remote_changes are running. Reads + writes are paused
    against this adapter while reconciliation completes."""


_PendingOp = Callable[[PlatformAdapter], Awaitable[Any]]


@dataclass
class _AdapterEntry:
    """Internal record per configured adapter."""

    platform_id: str
    adapter: PlatformAdapter
    state: AdapterState = AdapterState.HEALTHY
    last_error: BaseException | None = None
    pending_writes: list[tuple[str, _PendingOp]] = field(default_factory=list)
    """Writes that failed on this adapter while in HEALTHY/DEGRADED;
    drained by ``replay_pending_writes``. Each entry is the
    ``(operation_name, op_callable)`` tuple — the same callable the
    original ``write()`` was given so replay can re-issue it without
    needing to reconstruct args."""


class ReplicationManager:
    """Coordinator across multiple PlatformAdapters.

    Construction:
      * ``adapters`` — ordered list of (platform_id, adapter) pairs.
        First entry is the canonical store (LocalStoreAdapter
        conventionally). Order is also the read-failover order.

    The manager doesn't introspect adapter types; it just routes
    operations through the Protocol's methods. This keeps it
    backend-neutral by construction.
    """

    def __init__(
        self,
        adapters: list[tuple[str, PlatformAdapter]],
        *,
        on_canonical_write: Callable[[str], None] | None = None,
    ):
        """Construct the manager.

        ``on_canonical_write`` is an optional sync callback invoked
        once after every successful canonical write — wiring point for
        the SiteRebuilder live-update hook. The callback receives the
        ``operation_name`` string. Failures inside the callback are
        swallowed (the canonical write is the authoritative outcome;
        a broken hook should not poison it).
        """
        if not adapters:
            raise ValueError(
                "ReplicationManager requires at least one adapter "
                "(typically the canonical LocalStoreAdapter)."
            )
        self._entries: list[_AdapterEntry] = [
            _AdapterEntry(platform_id=pid, adapter=a)
            for pid, a in adapters
        ]
        self._on_canonical_write = on_canonical_write

    # -----------------------------------------------------------------------
    # Introspection
    # -----------------------------------------------------------------------

    def set_on_canonical_write(
        self, callback: Callable[[str], None] | None,
    ) -> None:
        """Replace the canonical-write hook post-construction.

        Used by ``build_server`` to attach the SiteRebuilder live-
        update hook AFTER the manager + canonical adapter are
        constructed (the rebuilder needs the canonical's docs path
        to be known). Pass ``None`` to detach.
        """
        self._on_canonical_write = callback

    def states(self) -> dict[str, AdapterState]:
        """Snapshot the current per-adapter state map."""
        return {e.platform_id: e.state for e in self._entries}

    def healthy_adapters(self) -> list[str]:
        return [e.platform_id for e in self._entries if e.state == AdapterState.HEALTHY]

    def pending_count(self, platform_id: str) -> int:
        for e in self._entries:
            if e.platform_id == platform_id:
                return len(e.pending_writes)
        raise KeyError(f"unknown platform_id={platform_id!r}")

    def canonical(self) -> PlatformAdapter:
        """The first entry — by convention the local-canonical store
        per OQ3. Used by handlers that bypass the manager when the
        operation is purely local-bound."""
        return self._entries[0].adapter

    def entries(self) -> list[tuple[str, PlatformAdapter]]:
        """Ordered ``(platform_id, adapter)`` pairs (canonical first).

        Used by callers that need to look up a specific adapter by
        platform_id — e.g., ``_resolve_public_face`` (#280) and the
        diagnostic surfaces that report per-backend state.
        """
        return [(e.platform_id, e.adapter) for e in self._entries]

    # -----------------------------------------------------------------------
    # Read-path failover
    # -----------------------------------------------------------------------

    async def read(
        self,
        op: Callable[[PlatformAdapter], Awaitable[T]],
        *,
        operation_name: str = "read",
    ) -> T:
        """Try ``op`` against each adapter in order; return the first
        one that responds.

        Adapters in DEGRADED or RECONCILING state are skipped. A
        ``ForgeUnavailableError`` from a HEALTHY adapter degrades it
        and falls through to the next. Any other exception propagates
        immediately (caller-fault errors don't benefit from failover).

        If every adapter is skipped or fails with unavailable,
        ``AllAdaptersFailedError`` is raised.
        """
        errors: dict[str, BaseException] = {}
        for entry in self._entries:
            if entry.state in (AdapterState.DEGRADED, AdapterState.RECONCILING):
                errors[entry.platform_id] = _adapter_errors.ForgeUnavailableError(
                    f"adapter in state={entry.state.value}; skipped",
                )
                continue
            try:
                return await op(entry.adapter)
            except _adapter_errors.ForgeUnavailableError as exc:
                entry.state = AdapterState.DEGRADED
                entry.last_error = exc
                errors[entry.platform_id] = exc
                continue
        raise AllAdaptersFailedError(errors)

    # -----------------------------------------------------------------------
    # Write-path fan-out (local-first)
    # -----------------------------------------------------------------------

    async def write(
        self,
        op: Callable[[PlatformAdapter], Awaitable[T]],
        *,
        operation_name: str = "write",
    ) -> T:
        """Run ``op`` against the canonical adapter first; on success,
        fan out to every other adapter in order. The canonical result
        is what gets returned to the caller — remote results aren't
        merged because they're mirrors of the same logical artifact.

        Behavior on failure:
          * Canonical adapter fails → ``ReplicationWriteError`` raised;
            no remote fan-out. The local store IS the source of
            truth, so a failed local write is fatal.
          * Remote adapter fails with ``ForgeUnavailableError`` →
            adapter moves to DEGRADED; the failed call is recorded
            for later replay; the manager continues to the next
            adapter. Caller doesn't see the failure.
          * Remote adapter fails with any other error → re-raised
            (caller-fault errors propagate so the caller can fix
            the underlying problem, e.g., a malformed body).
        """
        canonical_entry = self._entries[0]
        try:
            result = await op(canonical_entry.adapter)
        except BaseException as exc:
            canonical_entry.state = AdapterState.DEGRADED
            canonical_entry.last_error = exc
            raise ReplicationWriteError(
                canonical_entry.platform_id,
                operation_name,
                exc,
            ) from exc

        # Canonical succeeded; invoke the live-update hook (e.g.,
        # SiteRebuilder.notify) before fanning out to mirrors so the
        # rendered site reflects this write even if remote fan-out
        # subsequently fails. Hook errors are swallowed — the
        # canonical write is authoritative.
        if self._on_canonical_write is not None:
            try:
                self._on_canonical_write(operation_name)
            except Exception:  # noqa: BLE001 — see docstring
                pass

        # Canonical succeeded; fan out to mirrors.
        for entry in self._entries[1:]:
            if entry.state in (AdapterState.DEGRADED, AdapterState.RECONCILING):
                # Already-degraded adapter: queue the write for replay
                # without attempting it (would fail again immediately).
                entry.pending_writes.append((operation_name, op))
                continue
            try:
                await op(entry.adapter)
            except _adapter_errors.ForgeUnavailableError as exc:
                entry.state = AdapterState.DEGRADED
                entry.last_error = exc
                entry.pending_writes.append((operation_name, op))
                continue
            # Other exceptions propagate — caller-fault errors
            # shouldn't be silently swallowed.
        return result

    # -----------------------------------------------------------------------
    # State transitions (Phase 6 sub-run B will add reconciliation glue)
    # -----------------------------------------------------------------------

    def mark_healthy(self, platform_id: str) -> None:
        """Force an adapter back to HEALTHY — used by external probes
        (e.g., the conformance run wrapper) that have independently
        verified the adapter is reachable."""
        for entry in self._entries:
            if entry.platform_id == platform_id:
                entry.state = AdapterState.HEALTHY
                entry.last_error = None
                return
        raise KeyError(f"unknown platform_id={platform_id!r}")

    def mark_reconciling(self, platform_id: str) -> None:
        for entry in self._entries:
            if entry.platform_id == platform_id:
                entry.state = AdapterState.RECONCILING
                return
        raise KeyError(f"unknown platform_id={platform_id!r}")

    # -----------------------------------------------------------------------
    # Replay (Phase D — drain DEGRADED-adapter pending_writes)
    # -----------------------------------------------------------------------

    async def replay_pending_writes(self) -> dict[str, dict]:
        """Drain ``pending_writes`` on every non-canonical adapter.

        For each adapter with queued writes:

          * Probe the adapter via ``adapter.probe()``. If still
            unavailable, leave the queue intact and report
            ``probe_failed`` for that platform.
          * On a successful probe: re-issue each pending op against
            the adapter in queued order. Successful ops drop from
            the queue; ops that still raise ``ForgeUnavailableError``
            stay queued (the adapter went down again mid-replay).
            Other exceptions propagate immediately so caller-fault
            errors don't silently disappear.
          * After a clean drain, mark the adapter HEALTHY again.

        Returns a per-platform report:

            {
              "<platform_id>": {
                  "queued_before": int,
                  "replayed": int,
                  "failed": int,
                  "still_pending": int,
                  "probe_failed": bool,
              }, ...
            }

        Canonical adapter is excluded from the drain — the canonical
        store is the source of truth and shouldn't have pending
        writes (a canonical-write failure raises
        ``ReplicationWriteError`` and never reaches the queue).
        """
        report: dict[str, dict] = {}
        for entry in self._entries[1:]:  # skip canonical
            queued_before = len(entry.pending_writes)
            if queued_before == 0:
                continue

            row: dict[str, Any] = {
                "queued_before": queued_before,
                "replayed": 0,
                "failed": 0,
                "still_pending": queued_before,
                "probe_failed": False,
            }
            report[entry.platform_id] = row

            try:
                ok = await entry.adapter.probe()
            except _adapter_errors.ForgeUnavailableError:
                ok = False
            if not ok:
                row["probe_failed"] = True
                continue

            # Probe passed; replay queued ops in order. Build a fresh
            # queue for ones that still fail with unavailable so the
            # original list isn't mutated mid-iteration.
            remaining: list[tuple[str, _PendingOp]] = []
            for op_name, op in entry.pending_writes:
                try:
                    await op(entry.adapter)
                    row["replayed"] += 1
                except _adapter_errors.ForgeUnavailableError as exc:
                    entry.last_error = exc
                    remaining.append((op_name, op))
                    row["failed"] += 1
            entry.pending_writes = remaining
            row["still_pending"] = len(remaining)
            if not remaining:
                # Fully drained — adapter is back online.
                entry.state = AdapterState.HEALTHY
                entry.last_error = None
        return report

    # -----------------------------------------------------------------------
    # Local change-set queries (Phase D — time-window complement to drift)
    # -----------------------------------------------------------------------

    async def local_changes_since(
        self,
        *,
        since: datetime,
        kind: ArtifactKind | None = None,
        owner: str = "",
        repo: str = "",
    ) -> list[HistoryEntry]:
        """Return canonical-store history entries newer than ``since``.

        Time-window complement to ``compute_drifts``: instead of "what
        diverges between canonical and remote", this answers "what
        changed locally in the last N hours". Useful for replay
        decisions (which writes might still be propagating?), drift-
        recheck cadences (skip when no local changes), and
        ``import_remote_changes`` reconciliation (knowing local
        history before merging remote state).

        Delegates to the canonical adapter's
        ``aggregate_history_since`` if present. Adapters without a
        history surface (typical of remote backends) raise
        ``NotImplementedError`` — callers should fall back to a
        decomposed approach in that case. The current implementation
        only wires LocalStoreAdapter.
        """
        canonical = self._entries[0].adapter
        method = getattr(canonical, "aggregate_history_since", None)
        if method is None:
            raise NotImplementedError(
                f"Canonical adapter {self._entries[0].platform_id!r} "
                "doesn't expose aggregate_history_since. Time-window "
                "history queries require a history-tracking canonical "
                "(currently LocalStoreAdapter)."
            )
        return await method(since=since, kind=kind, owner=owner, repo=repo)

    # -----------------------------------------------------------------------
    # Drift detection (Phase 6 sub-run B)
    # -----------------------------------------------------------------------

    async def compute_drifts(
        self, *, owner: str, repo: str,
        since: datetime | None = None,
    ) -> dict[str, Any]:
        """Compute the drift between the local-canonical state and
        every remote adapter.

        Returns a mapping of ``platform_id`` → ``DriftReport``. The
        canonical adapter is excluded from the result (it can't drift
        against itself). Adapters in DEGRADED or RECONCILING state are
        skipped with a placeholder report.

        ``since`` (Phase D drift improvement) narrows the scope: when
        set, the canonical snapshot only contains artifacts that
        changed locally since the cutoff. Drift computed against this
        narrowed snapshot answers "what diverges among recent local
        changes" rather than the full set. Pairs with
        ``aggregate_history_since`` for time-window drift checks.

        The canonical adapter must implement an async ``snapshot(owner, repo)``
        method that returns a dict the remote adapters' ``compute_drift``
        understands (currently: LocalStoreAdapter only). Adapters whose
        ``snapshot`` doesn't accept ``since`` get the keyword passed
        through anyway — ``LocalStoreAdapter.snapshot`` honors it; if
        a future canonical adapter doesn't, callers will see a
        ``TypeError`` from the unsupported kwarg, which is the correct
        signal that the adapter needs the extension.
        """
        canonical = self._entries[0].adapter
        snapshot_fn = getattr(canonical, "snapshot", None)
        if snapshot_fn is None or not callable(snapshot_fn):
            raise TypeError(
                f"canonical adapter {self._entries[0].platform_id!r} "
                f"must implement snapshot(owner, repo) for compute_drifts"
            )
        snapshot_kwargs: dict[str, Any] = {"owner": owner, "repo": repo}
        if since is not None:
            snapshot_kwargs["since"] = since
        snapshot = await snapshot_fn(**snapshot_kwargs)

        results: dict[str, Any] = {}
        for entry in self._entries[1:]:
            if entry.state in (AdapterState.DEGRADED, AdapterState.RECONCILING):
                continue
            try:
                results[entry.platform_id] = await entry.adapter.compute_drift(
                    snapshot,
                )
            except _adapter_errors.ForgeUnavailableError as exc:
                entry.state = AdapterState.DEGRADED
                entry.last_error = exc
                # Drift unavailable for this adapter; caller can re-run
                # after the adapter's state recovers.
                continue
        return results

    # -----------------------------------------------------------------------
    # Import remote changes (Phase D — OQ4 foundation)
    # -----------------------------------------------------------------------

    async def import_remote_changes(
        self,
        *,
        source_platform_id: str,
        since: datetime,
        owner: str = "",
        repo: str = "",
    ) -> ImportReport:
        """Pull changes from one configured adapter into the canonical
        store (#274 Phase D foundation for OQ4).

        Steps:

          1. Look up the source adapter by ``source_platform_id`` —
            must be one of the manager's non-canonical adapters.
          2. Call ``source.fetch_remote_changes(since=...)``. Adapters
            without a live implementation raise ``NotImplementedError``;
            propagate that so callers can see exactly which backend
            blocked the import.
          3. Apply each change to the canonical adapter via
            ``apply_remote_change``. Conflicts (local divergence after
            the watermark) accumulate in the report; clean applies go
            in ``applied``; canonical-side declines (unsupported op,
            missing artifact) go in ``skipped``.

        Returns the ``ImportReport`` so callers can surface conflicts
        for manual resolution.
        """
        # Find the source adapter.
        source_entry = next(
            (e for e in self._entries if e.platform_id == source_platform_id),
            None,
        )
        if source_entry is None:
            raise KeyError(
                f"No adapter configured for source_platform_id="
                f"{source_platform_id!r}; known platforms: "
                f"{[e.platform_id for e in self._entries]}"
            )
        if source_entry is self._entries[0]:
            raise ValueError(
                "Cannot import from the canonical adapter — that's "
                "the sink, not a source."
            )

        # Canonical must support apply_remote_change.
        canonical = self._entries[0].adapter
        apply_method = getattr(canonical, "apply_remote_change", None)
        if apply_method is None:
            raise NotImplementedError(
                f"Canonical adapter {self._entries[0].platform_id!r} "
                "doesn't implement apply_remote_change. Import requires "
                "a write-supporting canonical (currently LocalStoreAdapter)."
            )

        # Fetch the changes — propagates NotImplementedError if the
        # source adapter hasn't implemented fetch_remote_changes yet.
        changes = await source_entry.adapter.fetch_remote_changes(
            since=since, owner=owner, repo=repo,
        )

        applied: list[RemoteChange] = []
        conflicts: list[ImportConflict] = []
        skipped: list[RemoteChange] = []
        for change in changes:
            try:
                result = await apply_method(change)
            except _adapter_errors.InvalidArtifactRefError:
                skipped.append(change)
                continue
            if result is None:
                applied.append(change)
            else:
                conflicts.append(result)

        return ImportReport(
            source_platform_id=source_platform_id,
            since=since,
            applied=applied,
            conflicts=conflicts,
            skipped=skipped,
        )
