"""Replication-layer exceptions."""
from __future__ import annotations


class ReplicationError(RuntimeError):
    """Base for any replication-layer error.

    Subclasses provide more specific failure modes; callers can catch
    ``ReplicationError`` for the broad case.
    """


class AllAdaptersFailedError(ReplicationError):
    """Raised by read-path failover when every configured adapter
    fails (network, auth, 5xx, etc.). Carries the list of per-adapter
    errors so the caller can diagnose.
    """

    def __init__(self, errors: dict[str, BaseException]):
        self.errors = errors
        causes = "; ".join(
            f"{platform}: {exc.__class__.__name__}: {exc}"
            for platform, exc in errors.items()
        )
        super().__init__(
            f"All replication adapters failed during read-path failover. "
            f"Causes: {causes}"
        )


class ReplicationWriteError(ReplicationError):
    """Raised when a write operation fails on the local-canonical
    adapter (local-first invariant per OQ3). Remote-adapter failures
    during the write fan-out do NOT raise; they're recorded as
    DEGRADED state and reconciled on a later replay.
    """

    def __init__(
        self,
        platform_id: str,
        operation: str,
        cause: BaseException,
    ):
        self.platform_id = platform_id
        self.operation = operation
        self.cause = cause
        super().__init__(
            f"Replication write failed on canonical adapter "
            f"({platform_id}) during {operation}: "
            f"{cause.__class__.__name__}: {cause}"
        )
