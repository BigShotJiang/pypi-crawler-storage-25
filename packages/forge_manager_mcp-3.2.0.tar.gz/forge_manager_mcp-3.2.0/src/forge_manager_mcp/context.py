"""Per-session server context (#82 Phase 2a).

ServerContext bundles the state that `build_server` previously held in
its closure. Introducing it is a prerequisite for Phase 2b, where the
inner async handlers move out of `build_server` into their own modules
and receive `ctx` as an explicit parameter instead of closing over it.

Phase 2a itself is behavior-neutral: the handlers still live inside
`build_server`, still capture `ctx` by closure, and still read / mutate
the same underlying state — just through attribute access on `ctx`
rather than separate closure variables.

Concurrency model matches `SessionActivity`: one instance per
`build_server()` call (i.e. per MCP stdio subprocess). Serialized
handler dispatch means no locking is needed as long as that assumption
holds.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

from .models import GithubConfig
from .utils import SessionActivity

if TYPE_CHECKING:
    # Type-only import — keeps :context's runtime dep closure small.
    # The :replication target carries httpx via :adapters_protocol's
    # transitive imports; declaring it as a TYPE_CHECKING reference
    # means tests that only exercise context.py don't pull it in.
    from .adapters.protocol import PlatformAdapter
    from .gate_registry import GateRegistry, ProcessRegistry
    from .project_rules import ProjectRules
    from .replication.manager import ReplicationManager
    from .site_renderer.rebuilder import SiteRebuilder


@dataclass
class ServerContext:
    """Per-session server state.

    `config` is `None` only in pre-bootstrap mode (#156): the project
    has no `.claude/github-config.json` yet because `scaffold_project`
    has not run. The dispatch in `build_server` rejects every tool
    that requires config in this mode, allowing only `scaffold_project`
    and `check_skill_version` (which operate without config) through.

    `replication` is `None` in pre-bootstrap mode (no config → no
    adapters) and during tests that don't exercise the adapter path.
    Handlers migrated onto `ctx.adapter.<method>` dispatch (#274) call
    methods through `replication.write(...)` / `replication.read(...)`
    so writes hit the canonical local store first and fan out to
    remote mirrors per the 3.0 ReplicationManager contract.
    """
    config: GithubConfig | None
    github_token: str
    anthropic_api_key: str
    project_dir: Path
    current_session: dict | None = None
    activity: SessionActivity = field(default_factory=SessionActivity)
    pre_bootstrap: bool = False
    replication: "ReplicationManager | None" = None
    site_rebuilder: "SiteRebuilder | None" = None
    """Optional Hugo live-update wrapper. Set by ``build_server``
    when ``config.site.auto_rebuild`` is True. ``close_session``
    calls ``flush()`` on it before the session closes so last-second
    canonical writes hit the rendered site."""

    public_face: "PlatformAdapter | None" = None
    """Configured public-facing platform adapter (#280). Resolved at
    server startup from ``config.public_face`` by looking up the matching
    adapter in the replication chain. None when ``config.public_face`` is
    None or when ``replication`` is None (pre-bootstrap or 2.x-compat
    fallback). Handlers that touch the public face (release mirror-sync
    in #282, public-Issue triage in #281) dispatch via this attribute
    rather than hardcoding GitHub-specific paths."""

    gate_registry: "GateRegistry | None" = None
    """Loaded gate registry (#287). Populated at server startup from
    ``.claude/skills/forge-manager/gates.yaml``. None when the YAML file
    is absent or fails to load — the server logs a warning and starts
    in degraded mode where ``evaluate_gate`` raises UnknownGate for
    every name."""

    process_registry: "ProcessRegistry | None" = None
    """Loaded process registry (#287). Populated at server startup from
    ``.claude/skills/forge-manager/processes.yaml``. None when the YAML
    file is absent or fails to load. Process records are reference-only
    today; runtime behavior is deferred to follow-up Issues."""

    project_rules: "ProjectRules | None" = None
    """Parsed project-rules surface (#288). Populated at server startup
    from ``.claude/project-rules.md`` when present. ``evaluate_gate``
    consumes this to compose the four-layer interceptor chain (state /
    override / extension / default). None means no project-specific
    layering — gates evaluate against the default evaluator alone."""
