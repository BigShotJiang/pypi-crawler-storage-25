"""Validators — deterministic checks against plan/RFC bodies (#184–#186, #192).

Each module here exposes a single async tool entry point that the MCP
server registers. Verifiers consume the YAML-frontmatter contract
defined in `validation.md` (#183).

Modules:
- ``plan`` — `verify_plan_completeness` (#184).

Future:
- ``diff`` — `verify_diff_covers_plan` (#185).
- ``llm`` — `verify_existing_code_assumptions` (#187, 2.2.0).
"""
