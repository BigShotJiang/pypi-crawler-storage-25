"""Interceptor library — stack-based execution with three-effect model.

Provides a minimal runtime for chained interceptor execution following the
Pedestal / Re-frame model (enter / leave / error triple). Each handler is
a pure function over an immutable Context; chains compose by listing
Interceptor records; the runtime navigates queue → stack → unwind with
first-class error propagation, RAII cleanup, and short-circuit semantics.

Concepts
--------

- **Context** — immutable frozen dataclass carrying the request, response,
  queue (pending interceptors), stack (interceptors with completed enter),
  optional error, halt flag, and steps_taken audit list. Mutation prevented
  at the type level (frozen + slots; response and steps_taken typed as
  Mapping / tuple, not dict / list).

- **Interceptor** — frozen dataclass with optional enter / leave / error
  handlers and an optional name. Each handler is ``(Context) -> Context``;
  handlers never mutate input. The ``display_name`` property falls back
  to the first non-None handler's ``__qualname__`` for logging.

- **Handler** — pure function ``Context -> Context``. Returns a new Context
  via ``dataclasses.replace``; the original is untouched. Async variant:
  ``(Context) -> Coroutine[Any, Any, Context]``.

The four operator-facing patterns
---------------------------------

1. **leave is RAII.** Every ``enter`` that successfully adds a resource to
   context (temp file, open connection, allocated lock, generated artifact)
   is responsible for a ``leave`` handler that releases that resource.
   Leave runs whether the chain succeeded normally or recovered from error.
   Convention: every resource-allocating ``enter`` has a ``leave`` even
   when no-op (the no-op is documented as deliberate, not oversight).

2. **error is recovery + propagation.** Three options per error handler:

   - **Compensate and propagate** — undo my world-side-effects, leave
     ``ctx.error`` set, prior interceptors' error handlers also fire.
   - **Compensate and recover** — undo what's appropriate, **clear
     ``ctx.error``** (return ``replace(ctx, error=None, ...)``), switch
     subsequent unwinding from error-path to normal-leave-path.
   - **Pass through** — error isn't from my domain, do nothing, let other
     handlers deal with it.

   The cleared-error case is the elegant one — once ``ctx.error is None``,
   subsequent unwinding runs ``leave`` not ``error``.

3. **response accumulates.** Each ``enter`` contributes to ``ctx.response``
   mapping. Convention: each step uses a single top-level key in
   ``ctx.response`` named after the step; sub-fields under that key
   describe what the step produced; steps don't write to keys owned by
   other steps.

4. **steps_taken is the audit list.** Each ``enter`` appends to
   ``ctx.steps_taken`` (an ordered tuple). Error handlers MAY append a
   ``compensated`` marker entry. Leave handlers DON'T append (steps_taken
   reflects forward work, not unwinding). Entry shape:
   ``{step: str, at: timestamp, detail: dict, compensated?: bool}``. Step
   names stable across forward and compensation entries so a reader can
   pair them.

Worked example — 3-interceptor chain
------------------------------------

The example below combines all four patterns: a temp-workspace step
(resource allocation + RAII cleanup), an LLM-verifier step (error with
recovery via fallback), and a deterministic-check step (read-only). Note
the ``replace()`` calls at every state transition.

::

    from datetime import datetime
    from dataclasses import replace
    from forge_manager_mcp.interceptors import (
        Context, Interceptor, execute,
    )

    # Step 1: temp workspace — resource allocation + RAII cleanup.
    def temp_workspace_enter(ctx):
        path = create_temp_dir()
        return replace(
            ctx,
            response={**ctx.response, "temp_workspace": {"path": path}},
            steps_taken=ctx.steps_taken + (
                {"step": "temp_workspace", "at": datetime.utcnow().isoformat(),
                 "detail": {"path": path}},
            ),
        )

    def temp_workspace_leave(ctx):
        # RAII: release the resource we allocated, regardless of success path
        path = ctx.response.get("temp_workspace", {}).get("path")
        if path:
            delete_temp_dir(path)
        return ctx

    def temp_workspace_error(ctx):
        # Same cleanup as leave — temp dir always wants deletion
        return temp_workspace_leave(ctx)

    temp_workspace = Interceptor(
        enter=temp_workspace_enter,
        leave=temp_workspace_leave,
        error=temp_workspace_error,
    )

    # Step 2: LLM verifier — recovery via fallback (clear error).
    def llm_verify_enter(ctx):
        try:
            verdict = call_llm(ctx.request["payload"])
        except APIError as e:
            # Capture and let error handler decide whether to recover
            return replace(ctx, error=e)
        return replace(
            ctx,
            response={**ctx.response, "llm_verify": {"verdict": verdict}},
            steps_taken=ctx.steps_taken + (
                {"step": "llm_verify", "at": datetime.utcnow().isoformat(),
                 "detail": {"verdict": verdict}},
            ),
        )

    def llm_verify_error(ctx):
        # Recovery pattern: try deterministic fallback, clear error on success
        if not isinstance(ctx.error, APIError):
            return ctx  # pass-through; not our domain
        try:
            verdict = deterministic_fallback(ctx.request["payload"])
        except Exception:
            return ctx  # fallback failed; let error propagate
        return replace(
            ctx,
            error=None,  # ← clear error — switch unwind to leave path
            response={**ctx.response, "llm_verify": {
                "verdict": verdict, "via": "fallback",
            }},
            steps_taken=ctx.steps_taken + (
                {"step": "llm_verify", "at": datetime.utcnow().isoformat(),
                 "detail": {"verdict": verdict, "via": "fallback"},
                 "compensated": False},
            ),
        )

    llm_verify = Interceptor(
        enter=llm_verify_enter,
        error=llm_verify_error,
    )

    # Step 3: deterministic check — read-only, no resources, no compensation.
    def det_check_enter(ctx):
        passes = check_deterministic(ctx.request["payload"])
        return replace(
            ctx,
            response={**ctx.response, "det_check": {"passes": passes}},
            steps_taken=ctx.steps_taken + (
                {"step": "det_check", "at": datetime.utcnow().isoformat(),
                 "detail": {"passes": passes}},
            ),
        )

    det_check = Interceptor(enter=det_check_enter)

    # Compose and execute. Order: outer-to-inner.
    final = execute(
        [temp_workspace, llm_verify, det_check],
        request={"payload": ...},
    )

    # final.response has all three steps' contributions.
    # final.steps_taken is the ordered audit log.
    # final.error is None (chain succeeded, possibly via recovery).

Sync / async
------------

``execute`` runs sync handlers; ``aexecute`` runs async handlers. Mixing
sync and async in one chain raises ``ChainError`` at chain entry — the
two runtimes don't mix because the handler-await pattern differs.

Threading and reentrance
------------------------

Handlers are pure functions over Context; the runtime holds no shared
mutable state. ``execute`` is reentrant (call from within a handler is
safe, though usually a code smell). Same for ``aexecute``.

Logging
-------

Every enter / leave / error transition is logged at DEBUG with the
interceptor's ``display_name``. Production callers should configure a
DEBUG handler if chain tracing is desired; default INFO logging produces
no chain output.
"""

from __future__ import annotations

import inspect
import logging
from collections.abc import Callable, Coroutine, Mapping
from dataclasses import dataclass, field, replace
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

class ChainError(Exception):
    """Raised when interceptor chain composition or execution is malformed.

    Distinct from handler-raised exceptions (which are caught and surfaced
    via ``ctx.error``). ChainError signals a structural problem — e.g., a
    sync chain containing async handlers — and is raised eagerly at
    ``execute`` / ``aexecute`` entry, before any handler runs.
    """


@dataclass(frozen=True, slots=True)
class Context:
    """Immutable interceptor execution context.

    Handlers receive a Context and return a new one via
    ``dataclasses.replace``. Mutation is prevented at the type level
    (frozen + slots; ``response`` and ``steps_taken`` are typed as
    immutable containers).

    Attributes
    ----------
    request:
        Caller-provided input mapping. Read-only across the chain.
    response:
        Accumulating result mapping. Each step contributes a single
        top-level key named after itself.
    queue:
        Pending interceptors. Head is next to enter.
    stack:
        Interceptors whose ``enter`` has completed. Top is most recent.
    error:
        Most recent unhandled exception, or None.
    halt:
        Short-circuit flag. When True, descent stops without an error;
        unwinding still runs (via ``leave`` handlers since no error).
    steps_taken:
        Ordered audit list. Each ``enter`` appends a forward entry;
        ``error`` handlers may append a compensation marker.
    """

    request: Mapping[str, Any] = field(default_factory=dict)
    response: Mapping[str, Any] = field(default_factory=dict)
    queue: tuple["Interceptor", ...] = ()
    stack: tuple["Interceptor", ...] = ()
    error: BaseException | None = None
    halt: bool = False
    steps_taken: tuple[Mapping[str, Any], ...] = ()


Handler = Callable[[Context], Context]
AsyncHandler = Callable[[Context], Coroutine[Any, Any, Context]]


@dataclass(frozen=True, slots=True)
class Interceptor:
    """Stack-positioned three-effect handler triple.

    Each callback is optional; a missing callback is an explicit no-op
    for that phase. The ``name`` field is optional; when None,
    ``display_name`` falls back to the first non-None handler's
    ``__qualname__`` (then ``__name__``, then ``"<anonymous>"``).
    """

    enter: Handler | AsyncHandler | None = None
    leave: Handler | AsyncHandler | None = None
    error: Handler | AsyncHandler | None = None
    name: str | None = None

    @property
    def display_name(self) -> str:
        """Stable identifier for logging and error messages.

        Resolution order:

        1. Explicit ``name`` if provided
        2. First non-None handler's ``__qualname__``
        3. First non-None handler's ``__name__``
        4. ``"<anonymous>"``
        """
        if self.name:
            return self.name
        for cb in (self.enter, self.leave, self.error):
            if cb is None:
                continue
            qn = getattr(cb, "__qualname__", None)
            if qn:
                return qn
            nm = getattr(cb, "__name__", None)
            if nm:
                return nm
        return "<anonymous>"


# ---------------------------------------------------------------------------
# Internal helpers — exception capture into ctx.error
# ---------------------------------------------------------------------------

def _caged(handler: Handler | None, ctx: Context) -> Context:
    """Run sync handler with exception capture; always return a new Context.

    If handler is None, returns ctx unchanged (None case is the explicit
    no-op contract). On exception, returns ``replace(ctx, error=exc)``.
    The original ctx is never mutated — including in the exception path.
    """
    if handler is None:
        return ctx
    try:
        return handler(ctx)
    except BaseException as exc:  # noqa: BLE001 — runtime-level capture
        logger.debug(
            "caged exception in handler %s: %r",
            getattr(handler, "__qualname__", "?"),
            exc,
        )
        return replace(ctx, error=exc)


async def _acaged(handler: AsyncHandler | None, ctx: Context) -> Context:
    """Async variant of ``_caged``."""
    if handler is None:
        return ctx
    try:
        return await handler(ctx)
    except BaseException as exc:  # noqa: BLE001 — runtime-level capture
        logger.debug(
            "acaged exception in handler %s: %r",
            getattr(handler, "__qualname__", "?"),
            exc,
        )
        return replace(ctx, error=exc)


# ---------------------------------------------------------------------------
# Internal helpers — chain validation
# ---------------------------------------------------------------------------

def _validate_chain(chain: list[Interceptor], *, require_async: bool) -> None:
    """Validate that all handlers in chain are sync or all async.

    Mixing the two is a structural error; the two runtimes can't run a
    mixed chain because the handler-await pattern differs. Raises
    ChainError on any mismatch.
    """
    expectation = "async" if require_async else "sync"
    for ic in chain:
        for cb in (ic.enter, ic.leave, ic.error):
            if cb is None:
                continue
            is_coro = inspect.iscoroutinefunction(cb)
            if require_async and not is_coro:
                raise ChainError(
                    f"aexecute requires async handlers; {ic.display_name} "
                    f"has sync handler {getattr(cb, '__qualname__', cb)}"
                )
            if not require_async and is_coro:
                raise ChainError(
                    f"execute requires sync handlers; {ic.display_name} "
                    f"has async handler {getattr(cb, '__qualname__', cb)}"
                )


# ---------------------------------------------------------------------------
# Sync runtime
# ---------------------------------------------------------------------------

def _enter(ctx: Context) -> Context:
    """Descent phase: pop queue head, push to stack, run enter, repeat.

    Halt conditions: empty queue, ``ctx.error`` set, ``ctx.halt`` set.
    """
    while ctx.queue and ctx.error is None and not ctx.halt:
        head = ctx.queue[0]
        rest = ctx.queue[1:]
        ctx = replace(
            ctx,
            queue=rest,
            stack=ctx.stack + (head,),
        )
        logger.debug("enter %s", head.display_name)
        ctx = _caged(head.enter, ctx)
    return ctx


def _leave(ctx: Context) -> Context:
    """Unwind phase: pop stack top, run leave or error, repeat.

    Calls ``error`` if ``ctx.error`` is set; calls ``leave`` otherwise.
    Stack pop happens before the handler runs so a handler that itself
    raises doesn't loop indefinitely on the same interceptor.

    The cleared-error pattern: an error handler can return a Context
    with ``error=None``. Subsequent iterations see ``ctx.error is None``
    and run ``leave`` handlers instead of ``error`` handlers.
    """
    while ctx.stack:
        top = ctx.stack[-1]
        ctx = replace(ctx, stack=ctx.stack[:-1])
        if ctx.error is not None:
            logger.debug("error %s", top.display_name)
            ctx = _caged(top.error, ctx)
        else:
            logger.debug("leave %s", top.display_name)
            ctx = _caged(top.leave, ctx)
    return ctx


def execute(
    chain: list[Interceptor],
    request: Mapping[str, Any] | None = None,
) -> Context:
    """Execute a sync interceptor chain against an initial request.

    Returns the final Context. Caller inspects ``ctx.response``,
    ``ctx.steps_taken``, and ``ctx.error`` to reason about the result.

    Guarantees
    ----------
    - All handlers must be sync; mixing async raises :class:`ChainError`
      eagerly at chain entry.
    - Each ``enter`` that successfully completes is matched by exactly
      one ``leave`` or ``error`` invocation during unwinding.
    - ``ctx.error`` cleared by an error handler switches subsequent
      unwinding from error-path to leave-path.
    - ``ctx.halt`` is a non-error short-circuit; descent stops, unwind
      runs via leave handlers (not error).

    Raises
    ------
    ChainError
        If chain composition is invalid (e.g., mixed sync/async).
    """
    _validate_chain(chain, require_async=False)
    initial = Context(
        request=request or {},
        queue=tuple(chain),
    )
    after_enter = _enter(initial)
    after_leave = _leave(after_enter)
    return after_leave


# ---------------------------------------------------------------------------
# Async runtime
# ---------------------------------------------------------------------------

async def _aenter(ctx: Context) -> Context:
    """Async descent phase. Same semantics as ``_enter``."""
    while ctx.queue and ctx.error is None and not ctx.halt:
        head = ctx.queue[0]
        rest = ctx.queue[1:]
        ctx = replace(
            ctx,
            queue=rest,
            stack=ctx.stack + (head,),
        )
        logger.debug("aenter %s", head.display_name)
        ctx = await _acaged(head.enter, ctx)
    return ctx


async def _aleave(ctx: Context) -> Context:
    """Async unwind phase. Same semantics as ``_leave``."""
    while ctx.stack:
        top = ctx.stack[-1]
        ctx = replace(ctx, stack=ctx.stack[:-1])
        if ctx.error is not None:
            logger.debug("aerror %s", top.display_name)
            ctx = await _acaged(top.error, ctx)
        else:
            logger.debug("aleave %s", top.display_name)
            ctx = await _acaged(top.leave, ctx)
    return ctx


async def aexecute(
    chain: list[Interceptor],
    request: Mapping[str, Any] | None = None,
) -> Context:
    """Execute an async interceptor chain against an initial request.

    Same semantics as :func:`execute`, but every handler must be async.
    Raises :class:`ChainError` if any handler is sync.
    """
    _validate_chain(chain, require_async=True)
    initial = Context(
        request=request or {},
        queue=tuple(chain),
    )
    after_enter = await _aenter(initial)
    after_leave = await _aleave(after_enter)
    return after_leave


# ---------------------------------------------------------------------------
# Convenience: result extraction
# ---------------------------------------------------------------------------

def result(ctx: Context) -> Mapping[str, Any]:
    """Return ``ctx.response`` if no error, else raise ``ctx.error``.

    For chains where the caller wants get-or-raise rather than manual
    error inspection. Equivalent to::

        if ctx.error is not None:
            raise ctx.error
        return ctx.response
    """
    if ctx.error is not None:
        raise ctx.error
    return ctx.response


__all__ = [
    "AsyncHandler",
    "ChainError",
    "Context",
    "Handler",
    "Interceptor",
    "aexecute",
    "execute",
    "result",
]
