"""Audit prose surfaces for project-rules muddling (#290).

The skill's gate registry (#287) and project-rules schema (#288) give
projects a clean attachment surface. But projects that adopted the
skill mid-life carry prose — CLAUDE.md, README, contributing guides
— with rules and overrides written before the framework existed.
This module scans those prose surfaces and reports findings the
operator can review and migrate.

Operator-driven only. The tool reports; never auto-rewrites. Apply
mode generates migrated text for a given finding, but the operator
commits it.

Detection categories
--------------------

Each finding is tagged with one of six categories:

1. ``gate_extension_candidate`` — prose tightening a known gate
   without using the formal § Gate extensions framework. HIGH when
   the section heading explicitly says ``Extends §X`` or
   ``Extends \`gate.name\```; MEDIUM when keyword overlap from the
   gate's summary appears alongside qualifier words ("must",
   "always", "required", "before"); LOW when only one signal is
   present.

2. ``gate_override_candidate`` — prose replacing or contradicting a
   known gate's default behavior. HIGH on explicit ``Overrides §X``;
   MEDIUM on "skip / disable / don't run" + gate keyword.

3. ``gate_closure_candidate`` — prose disabling a known gate /
   process for the project. HIGH when "verifier:llm-skip", "skip
   verifier", "ANTHROPIC_API_KEY not set" appears alongside gate
   keywords; MEDIUM when "not applicable" + gate keyword.

4. ``protocol_concept_redefinition`` — prose redefining a skill-
   protocol concept (``Discussion category``, ``running-log``,
   ``session lock``, ``two-turn rule``, ``kind:*``, ``category:*``)
   in project-specific terms. MEDIUM by default — judgment-call
   territory.

5. ``identity_in_rules_doc`` — non-rule content (project facts,
   repo layout, member lists) in ``.claude/project-rules.md``.
   Suggest move to CLAUDE.md.

6. ``rules_in_identity_doc`` — rule content in CLAUDE.md identity
   sections (typically under ``## Overrides``). Suggest move to
   ``.claude/project-rules.md``. HIGH for any section under
   ``## Overrides`` (heading-based; no semantic analysis needed).

Confidence rubric
-----------------

The three confidence levels are calibrated for operator workflow:

- ``high`` — review-then-apply. The match is unambiguous (explicit
  extension language, dedicated ``## Overrides`` heading, etc.).
  Operator can apply with minimal scrutiny.

- ``medium`` — review-then-decide. The match could be a real
  finding or a false positive. Operator inspects the snippet
  before applying.

- ``low`` — informational. Surfacing in case the operator wants to
  audit broader patterns. Apply mode is supported but rarely the
  right call.

Apply mode
----------

:func:`apply_finding` takes a parsed :class:`Finding` plus the gate
registry and returns a string suitable for pasting into ``.claude/
project-rules.md``. It does not write to disk; the operator commits.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Iterable, Literal

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from .gate_registry import Gate, GateRegistry


# ---------------------------------------------------------------------------
# Public types
# ---------------------------------------------------------------------------

Category = Literal[
    "gate_extension_candidate",
    "gate_override_candidate",
    "gate_closure_candidate",
    "protocol_concept_redefinition",
    "identity_in_rules_doc",
    "rules_in_identity_doc",
]

Confidence = Literal["high", "medium", "low"]


class AuditError(Exception):
    """Raised on audit-tool failure (apply-mode finding-id mismatch, etc)."""


class Finding(BaseModel):
    """One audit finding."""

    model_config = {"frozen": True, "extra": "forbid"}

    id: str = Field(..., description="Stable identifier — file:line_start.")
    category: Category
    file: str
    line_range: tuple[int, int]
    snippet: str
    suspected_gate: str | None = Field(
        None,
        description=(
            "Gate the finding is associated with, when applicable. "
            "Categories 4-6 leave this None."
        ),
    )
    confidence: Confidence
    suggested_action: str
    suggested_text: str | None = Field(
        None,
        description=(
            "Pre-rendered project-rules.md entry. None for categories "
            "where there's no clean migration text (concept redefinition; "
            "identity-in-rules-doc reverse moves)."
        ),
    )


class AuditSummary(BaseModel):
    """Summary block of an :class:`AuditReport`."""

    model_config = {"frozen": True, "extra": "forbid"}

    total_findings: int
    by_category: dict[str, int]
    by_confidence: dict[str, int]


class AuditReport(BaseModel):
    """Top-level audit output."""

    model_config = {"frozen": True, "extra": "forbid"}

    findings: tuple[Finding, ...]
    summary: AuditSummary
    next_steps: tuple[str, ...]


# ---------------------------------------------------------------------------
# Prose-surface walking
# ---------------------------------------------------------------------------

DEFAULT_INCLUDE: tuple[str, ...] = (
    "CLAUDE.md",
    "README.md",
    "CONTRIBUTING.md",
    ".claude/project-rules.md",
    "docs/**/*.md",
    "*.md",
)

DEFAULT_EXCLUDE: tuple[str, ...] = (
    "CHANGELOG.md",
    "node_modules/**",
    ".git/**",
    "build/**",
    "dist/**",
    "bazel-*/**",
    ".claude/skills/**",  # the skill prose itself; not project rules
)


def _iter_prose_files(
    project_root: Path,
    include: tuple[str, ...],
    exclude: tuple[str, ...],
    since: datetime | None,
) -> Iterable[Path]:
    """Yield paths to prose files under ``project_root`` matching include /
    exclude globs and the ``since`` mtime cutoff."""
    seen: set[Path] = set()
    for pattern in include:
        for match in project_root.glob(pattern):
            if not match.is_file():
                continue
            if any(match.match(ex) for ex in exclude):
                continue
            if any(match.relative_to(project_root).match(ex) for ex in exclude):
                continue
            if since is not None:
                mtime = datetime.fromtimestamp(match.stat().st_mtime)
                if mtime < since:
                    continue
            if match in seen:
                continue
            seen.add(match)
            yield match


# ---------------------------------------------------------------------------
# Top-level audit entry point
# ---------------------------------------------------------------------------


def audit_prose(
    project_root: Path,
    gate_registry: "GateRegistry",
    *,
    include: tuple[str, ...] = DEFAULT_INCLUDE,
    exclude: tuple[str, ...] = DEFAULT_EXCLUDE,
    since: datetime | None = None,
) -> AuditReport:
    """Walk prose surfaces and return an :class:`AuditReport`.

    The gate registry provides keyword vocabulary for category 1-3
    detectors and the universe of valid gate names for cross-references.
    """
    findings: list[Finding] = []
    for path in _iter_prose_files(project_root, include, exclude, since):
        rel = str(path.relative_to(project_root))
        text = path.read_text(encoding="utf-8")
        findings.extend(_audit_file(rel, text, gate_registry))
    summary = _build_summary(findings)
    next_steps = _build_next_steps(findings)
    return AuditReport(
        findings=tuple(findings),
        summary=summary,
        next_steps=tuple(next_steps),
    )


def _audit_file(
    rel_path: str, text: str, gate_registry: "GateRegistry"
) -> list[Finding]:
    """Run every applicable detector against a single file."""
    findings: list[Finding] = []
    sections = _split_into_sections(text)
    is_claude_md = rel_path.endswith("CLAUDE.md")
    is_project_rules = rel_path.endswith(".claude/project-rules.md")

    for section in sections:
        # Categories 1-3 inspect the section content for gate-related
        # signals.
        findings.extend(
            _detect_gate_extensions(rel_path, section, gate_registry)
        )
        findings.extend(
            _detect_gate_overrides(rel_path, section, gate_registry)
        )
        findings.extend(
            _detect_gate_closures(rel_path, section, gate_registry)
        )

        # Category 4 — protocol concept redefinition. Always run.
        findings.extend(_detect_concept_redefinition(rel_path, section))

        # Category 5 — identity-in-rules-doc.
        if is_project_rules:
            findings.extend(_detect_identity_in_rules_doc(rel_path, section))

        # Category 6 — rules-in-identity-doc. Heading-based detection
        # specifically for CLAUDE.md ## Overrides sub-sections.
        if is_claude_md:
            findings.extend(
                _detect_rules_in_identity_doc(rel_path, section, gate_registry)
            )
    return findings


# ---------------------------------------------------------------------------
# Section parsing — light-weight markdown segmentation.
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class _Section:
    """One markdown section: heading + body, with line-position tracking."""

    level: int
    heading: str
    line_start: int
    line_end: int
    body: str
    parents: tuple[str, ...] = ()

    @property
    def all_text(self) -> str:
        """Heading + body — combined corpus for keyword matching."""
        return f"{self.heading}\n{self.body}"


_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*?)(?:\s+\{#[^}]+\})?\s*$")


def _split_into_sections(text: str) -> list[_Section]:
    """Walk markdown and emit one Section per heading.

    A section's ``body`` is every line up to the next heading at the
    same or shallower depth. ``parents`` tracks the heading chain so
    sub-sections can reference their context (e.g., ``"## Overrides
    > ### Maximal Test Coverage"``).
    """
    lines = text.splitlines()
    headings: list[tuple[int, int, str]] = []
    for i, line in enumerate(lines):
        match = _HEADING_RE.match(line)
        if match:
            level = len(match.group(1))
            heading = match.group(2).strip()
            headings.append((i, level, heading))

    sections: list[_Section] = []
    stack: list[tuple[int, str]] = []
    for idx, (start, level, heading) in enumerate(headings):
        # Update parent chain.
        while stack and stack[-1][0] >= level:
            stack.pop()
        parents = tuple(p[1] for p in stack)
        # End is the next heading at <= level, or end-of-file.
        end = len(lines)
        for next_start, next_level, _ in headings[idx + 1:]:
            if next_level <= level:
                end = next_start
                break
        body = "\n".join(lines[start + 1:end]).strip()
        sections.append(
            _Section(
                level=level,
                heading=heading,
                line_start=start + 1,
                line_end=end,
                body=body,
                parents=parents,
            )
        )
        stack.append((level, heading))
    return sections


# ---------------------------------------------------------------------------
# Detectors — categories 1-3
# ---------------------------------------------------------------------------

_QUALIFIER_RE = re.compile(
    r"\b(must|always|required|before any|do not|never|every)\b",
    re.IGNORECASE,
)
_OVERRIDE_LANG_RE = re.compile(
    r"\b(overrides?|replaces?|skip|disable|don't run|do not run)\b",
    re.IGNORECASE,
)
_CLOSURE_LANG_RE = re.compile(
    r"\b(not applicable|skip(?:ped)?|disabled|llm-skip|"
    r"key not set|not configured|exempt|out of scope)\b",
    re.IGNORECASE,
)


def _gate_keywords(gate: "Gate") -> tuple[str, ...]:
    """Extract keyword vocabulary for matching against prose.

    Pulls non-trivial words from ``gate.summary`` and the first line of
    ``gate.notes``. Stop-words and dot-namespace fragments are excluded.
    """
    raw = gate.summary
    if gate.notes:
        first_notes_line = gate.notes.split("\n", 1)[0]
        raw = f"{raw} {first_notes_line}"
    words = re.findall(r"[a-zA-Z][a-zA-Z_-]{2,}", raw.lower())
    stop = {
        "the", "and", "for", "with", "this", "that", "from", "any",
        "all", "have", "has", "had", "into", "onto", "than", "then",
        "been", "their", "but", "are", "can", "will", "may", "should",
    }
    return tuple({w for w in words if w not in stop and len(w) > 3})


def _explicit_extension_match(section: _Section, gate: "Gate") -> bool:
    """True when the section explicitly declares it extends ``gate``."""
    text = section.all_text.lower()
    # Look for "Extends §X" / "Extends `gate.name`" / "extends the X gate"
    if f"extends `{gate.name}`" in text:
        return True
    # §<heading-keyword> matching against the gate's prose location
    # (e.g. "Extends §Commit Rules" should catch commit.test_coverage
    # whose location is commit-rules.md#commit.test_coverage).
    section_keywords = _section_keywords_from_gate(gate)
    for kw in section_keywords:
        if f"extends §{kw}" in text:
            return True
    return False


def _section_keywords_from_gate(gate: "Gate") -> tuple[str, ...]:
    """Heading-style keywords inferred from a gate's location anchor.

    Maps ``commit-rules.md#commit.test_coverage`` to keywords like
    ``"commit rules"`` so prose that says "Extends §Commit Rules" can
    associate with the gate.
    """
    if "#" not in gate.location:
        return ()
    file_part, _ = gate.location.split("#", 1)
    base = file_part.removesuffix(".md").replace("-", " ").lower()
    return (base,)


def _keyword_overlap_count(text: str, keywords: tuple[str, ...]) -> int:
    """Count distinct keywords from ``keywords`` that appear in ``text``."""
    lowered = text.lower()
    return sum(1 for kw in keywords if kw in lowered)


def _detect_gate_extensions(
    rel_path: str, section: _Section, gate_registry: "GateRegistry"
) -> list[Finding]:
    """Category 1 — find gate-extension candidates."""
    findings: list[Finding] = []
    for gate in gate_registry.list_gates():
        keywords = _gate_keywords(gate)
        explicit = _explicit_extension_match(section, gate)
        overlap = _keyword_overlap_count(section.all_text, keywords)
        qualifier = bool(_QUALIFIER_RE.search(section.all_text))

        confidence: Confidence | None = None
        if explicit:
            confidence = "high"
        elif overlap >= 2 and qualifier:
            confidence = "medium"
        elif overlap >= 1 and qualifier:
            confidence = "low"

        if confidence is None:
            continue

        findings.append(
            Finding(
                id=f"{rel_path}:{section.line_start}:ext:{gate.name}",
                category="gate_extension_candidate",
                file=rel_path,
                line_range=(section.line_start, section.line_end),
                snippet=_truncate(section.all_text, 400),
                suspected_gate=gate.name,
                confidence=confidence,
                suggested_action=(
                    f"Move to .claude/project-rules.md "
                    f"§ Gate extensions § Extends `{gate.name}`"
                ),
                suggested_text=_render_extension_template(section, gate),
            )
        )
    return findings


def _detect_gate_overrides(
    rel_path: str, section: _Section, gate_registry: "GateRegistry"
) -> list[Finding]:
    """Category 2 — find gate-override candidates."""
    findings: list[Finding] = []
    if not _OVERRIDE_LANG_RE.search(section.all_text):
        return findings
    for gate in gate_registry.list_gates():
        keywords = _gate_keywords(gate)
        if _keyword_overlap_count(section.all_text, keywords) < 1:
            continue
        text_lower = section.all_text.lower()
        explicit = (
            f"overrides `{gate.name}`" in text_lower
            or any(
                f"overrides §{kw}" in text_lower
                for kw in _section_keywords_from_gate(gate)
            )
        )
        confidence: Confidence = "high" if explicit else "medium"
        findings.append(
            Finding(
                id=f"{rel_path}:{section.line_start}:ovr:{gate.name}",
                category="gate_override_candidate",
                file=rel_path,
                line_range=(section.line_start, section.line_end),
                snippet=_truncate(section.all_text, 400),
                suspected_gate=gate.name,
                confidence=confidence,
                suggested_action=(
                    f"Move to .claude/project-rules.md "
                    f"§ Gate overrides § Overrides `{gate.name}`"
                ),
                suggested_text=_render_override_template(section, gate),
            )
        )
    return findings


def _detect_gate_closures(
    rel_path: str, section: _Section, gate_registry: "GateRegistry"
) -> list[Finding]:
    """Category 3 — find gate-closure candidates."""
    findings: list[Finding] = []
    if not _CLOSURE_LANG_RE.search(section.all_text):
        return findings
    for gate in gate_registry.list_gates():
        keywords = _gate_keywords(gate)
        if _keyword_overlap_count(section.all_text, keywords) < 1:
            continue
        findings.append(
            Finding(
                id=f"{rel_path}:{section.line_start}:close:{gate.name}",
                category="gate_closure_candidate",
                file=rel_path,
                line_range=(section.line_start, section.line_end),
                snippet=_truncate(section.all_text, 400),
                suspected_gate=gate.name,
                confidence="medium",
                suggested_action=(
                    f"Move to .claude/project-rules.md "
                    f"§ Gate state declarations § Closes `{gate.name}`"
                ),
                suggested_text=_render_closure_template(section, gate),
            )
        )
    return findings


# ---------------------------------------------------------------------------
# Detectors — categories 4-6
# ---------------------------------------------------------------------------

_PROTOCOL_TERMS: tuple[str, ...] = (
    "Discussion category",
    "Discussion categories",
    "running-log",
    "running log",
    "session lock",
    "session-lock",
    "two-turn rule",
    "two-turn",
    "kind:discussion",
    "kind:rfc",
    "kind:issue",
    "category:architecture",
    "category:ideas",
    "category:ux",
    "Project Index",
    "Session Lock Discussion",
)


def _detect_concept_redefinition(
    rel_path: str, section: _Section
) -> list[Finding]:
    """Category 4 — surface protocol-concept mentions for operator review."""
    findings: list[Finding] = []
    text = section.all_text
    matched_terms = [t for t in _PROTOCOL_TERMS if t.lower() in text.lower()]
    if not matched_terms:
        return findings
    findings.append(
        Finding(
            id=f"{rel_path}:{section.line_start}:concept",
            category="protocol_concept_redefinition",
            file=rel_path,
            line_range=(section.line_start, section.line_end),
            snippet=_truncate(text, 400),
            suspected_gate=None,
            confidence="medium",
            suggested_action=(
                "Review whether this section redefines a skill-protocol "
                "concept ({terms}) or simply cross-references the skill. "
                "If redefined, consider migrating to project-rules.md."
            ).format(terms=", ".join(matched_terms[:3])),
            suggested_text=None,
        )
    )
    return findings


_IDENTITY_MARKERS_RE = re.compile(
    r"^(repo|owner|account type|version|members?|stakeholders?)\s*:",
    re.IGNORECASE | re.MULTILINE,
)


def _detect_identity_in_rules_doc(
    rel_path: str, section: _Section
) -> list[Finding]:
    """Category 5 — non-rule content in .claude/project-rules.md."""
    findings: list[Finding] = []
    if not _IDENTITY_MARKERS_RE.search(section.body):
        return findings
    findings.append(
        Finding(
            id=f"{rel_path}:{section.line_start}:identity-in-rules",
            category="identity_in_rules_doc",
            file=rel_path,
            line_range=(section.line_start, section.line_end),
            snippet=_truncate(section.all_text, 400),
            suspected_gate=None,
            confidence="medium",
            suggested_action=(
                "Move project facts (repo, owner, account type, etc.) "
                "to CLAUDE.md identity sections."
            ),
            suggested_text=None,
        )
    )
    return findings


def _detect_rules_in_identity_doc(
    rel_path: str, section: _Section, gate_registry: "GateRegistry"
) -> list[Finding]:
    """Category 6 — rule content under CLAUDE.md ## Overrides.

    Heading-based: any level-3 section whose parent chain includes
    ``Overrides`` is a candidate. Confidence is HIGH because the
    placement under ``## Overrides`` is itself the signal.
    """
    findings: list[Finding] = []
    is_under_overrides = any(
        p.strip().lower() == "overrides" for p in section.parents
    )
    if not is_under_overrides:
        return findings
    if section.level <= 2:
        # The umbrella "## Overrides" itself isn't a rule — only its
        # sub-sections.
        return findings
    suspected_gate = _guess_gate_for_overrides_subsection(section, gate_registry)
    findings.append(
        Finding(
            id=f"{rel_path}:{section.line_start}:rules-in-identity",
            category="rules_in_identity_doc",
            file=rel_path,
            line_range=(section.line_start, section.line_end),
            snippet=_truncate(section.all_text, 400),
            suspected_gate=suspected_gate,
            confidence="high",
            suggested_action=(
                "Move to .claude/project-rules.md — this is rule content "
                "in CLAUDE.md identity surface."
            ),
            suggested_text=_render_overrides_subsection_template(
                section, suspected_gate, gate_registry
            ),
        )
    )
    return findings


def _guess_gate_for_overrides_subsection(
    section: _Section, gate_registry: "GateRegistry"
) -> str | None:
    """Try to pick the most likely gate for a CLAUDE.md ## Overrides subsection.

    Picks the gate whose keyword overlap with the section is highest;
    returns None when no gate scores above zero.
    """
    best_gate: str | None = None
    best_score = 0
    for gate in gate_registry.list_gates():
        keywords = _gate_keywords(gate)
        score = _keyword_overlap_count(section.all_text, keywords)
        if _explicit_extension_match(section, gate):
            score += 5  # explicit reference dominates keyword overlap
        if score > best_score:
            best_score = score
            best_gate = gate.name
    return best_gate


# ---------------------------------------------------------------------------
# Apply mode — render migrated text
# ---------------------------------------------------------------------------


def apply_finding(
    finding: Finding, gate_registry: "GateRegistry"
) -> str:
    """Return the migrated project-rules.md text for a finding.

    Pure function — never writes to disk. The operator is responsible
    for placing the returned text in ``.claude/project-rules.md`` and
    committing the change.
    """
    if finding.suggested_text is not None:
        return finding.suggested_text
    raise AuditError(
        f"finding {finding.id} has no suggested_text — not migration-ready"
    )


def _render_extension_template(section: _Section, gate: "Gate") -> str:
    body = section.body.strip()
    extension_one_liner = _first_sentence(body) or section.heading
    return (
        f"### Extends `{gate.name}`\n"
        f"**Extension:** {extension_one_liner}\n"
        f"**Why:** [explain project-specific rationale]\n"
        f"\n"
        f"{body}"
    )


def _render_override_template(section: _Section, gate: "Gate") -> str:
    body = section.body.strip()
    replacement_one_liner = _first_sentence(body) or section.heading
    return (
        f"### Overrides `{gate.name}`\n"
        f"**Replacement:** {replacement_one_liner}\n"
        f"**Why:** [explain project-specific rationale]\n"
        f"\n"
        f"{body}"
    )


def _render_closure_template(section: _Section, gate: "Gate") -> str:
    body = section.body.strip()
    return (
        f"### Closes `{gate.name}`\n"
        f"**Reason:** [why this gate doesn't apply to this project]\n"
        f"**Re-open when:** [condition under which the gate should fire]\n"
        f"\n"
        f"{body}"
    )


def _render_overrides_subsection_template(
    section: _Section,
    suspected_gate: str | None,
    gate_registry: "GateRegistry",
) -> str:
    if suspected_gate is None:
        # Independent rule — unknown gate.
        return (
            f"### {section.heading}\n"
            f"\n"
            f"{section.body.strip()}\n"
        )
    gate = gate_registry.get_gate(suspected_gate)
    if gate is None:
        return (
            f"### {section.heading}\n"
            f"\n"
            f"{section.body.strip()}\n"
        )
    return _render_extension_template(section, gate)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _truncate(text: str, limit: int) -> str:
    text = text.strip()
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "…"


def _first_sentence(text: str) -> str | None:
    text = text.strip()
    if not text:
        return None
    match = re.match(r"(.+?[.!?])\s+", text)
    if match:
        return match.group(1).strip()
    # Fall back to the first line.
    return text.splitlines()[0].strip()


def _build_summary(findings: list[Finding]) -> AuditSummary:
    by_cat: dict[str, int] = {}
    by_conf: dict[str, int] = {}
    for f in findings:
        by_cat[f.category] = by_cat.get(f.category, 0) + 1
        by_conf[f.confidence] = by_conf.get(f.confidence, 0) + 1
    return AuditSummary(
        total_findings=len(findings),
        by_category=by_cat,
        by_confidence=by_conf,
    )


def _build_next_steps(findings: list[Finding]) -> list[str]:
    if not findings:
        return ["No findings — no migration needed."]
    high = sum(1 for f in findings if f.confidence == "high")
    medium = sum(1 for f in findings if f.confidence == "medium")
    low = sum(1 for f in findings if f.confidence == "low")
    return [
        f"Review {high} high-confidence findings; these have unambiguous "
        "migration targets and clean suggested_text.",
        f"Review {medium} medium-confidence findings; verify the heuristic "
        "match before applying.",
        f"Review {low} low-confidence findings; mostly informational.",
        "For each finding the operator chooses to migrate, copy the "
        "`suggested_text` into `.claude/project-rules.md` under the named "
        "section, then remove the source prose. Commit the migration.",
    ]


__all__ = [
    "AuditError",
    "AuditReport",
    "AuditSummary",
    "Category",
    "Confidence",
    "DEFAULT_EXCLUDE",
    "DEFAULT_INCLUDE",
    "Finding",
    "apply_finding",
    "audit_prose",
]
