"""HugoRenderer — invokes ``hugo`` CLI as subprocess to render the
docs repo into a static site (3.0 / Phase 5).

Architecture:
  1. ``generate_site_input`` walks the canonical docs repo and emits
     a transient Hugo content tree at ``<docs_repo>/_site_input/``.
  2. The theme at ``<package>/themes/forge-manager-default/`` is
     symlinked into the content tree's ``themes/`` dir.
  3. ``hugo`` is invoked against the content tree; output lands at
     ``<target_dir>``.

The renderer is async-but-mostly-synchronous: subprocess invocations
use ``asyncio.create_subprocess_exec`` so the SiteRenderer Protocol
stays consistent with the rest of forge-manager's async surface.
"""
from __future__ import annotations

import asyncio
import shutil
from pathlib import Path
from typing import ClassVar

from .frontmatter import generate_site_input


HUGO_CONFIG_TEMPLATE = """\
baseURL = "{base_url}"
title = "forge-manager docs"
theme = "forge-manager-default"
languageCode = "en-us"
defaultContentLanguage = "en"

[taxonomies]
  label = "labels"
  category = "categories"
  milestone = "milestones"
  # Note: 'kind' would conflict with Hugo's reserved page-kind field;
  # the per-artifact-type listing is provided by content sections
  # (/issues/, /discussions/, /milestones/, /releases/) instead.

[params]
  description = "forge-manager project docs"
  github_style = true

[markup]
  [markup.goldmark]
    [markup.goldmark.renderer]
      unsafe = true  # comment <section> blocks need raw HTML
"""


def _theme_root() -> Path:
    """Locate the bundled theme dir relative to this package."""
    # site_renderer/hugo.py → site_renderer/ → forge_manager_mcp/ →
    # mcp-server/ → mcp-server/themes/forge-manager-default/
    here = Path(__file__).resolve().parent
    candidates = [
        here.parent.parent.parent / "themes" / "forge-manager-default",
        here.parent.parent / "themes" / "forge-manager-default",
    ]
    for c in candidates:
        if c.exists():
            return c
    raise FileNotFoundError(
        "HugoRenderer: bundled theme directory not found. Expected at "
        f"{candidates[0]} or {candidates[1]}."
    )


class HugoRenderer:
    """SiteRenderer implementation that wraps the Hugo CLI.

    Constructed with no required args; the bundled theme + the
    canonical content-tree layout are discovered relative to the
    package on first use.
    """

    renderer_id: ClassVar[str] = "hugo"

    def __init__(
        self,
        *,
        hugo_binary: str = "hugo",
        theme_dir: Path | None = None,
    ):
        self._hugo = hugo_binary
        self._theme_dir = theme_dir or _theme_root()

    async def build(
        self,
        *,
        docs_repo: Path,
        target_dir: Path,
        base_url: str = "/",
    ) -> Path:
        docs_repo = docs_repo.resolve()
        target_dir = target_dir.resolve()
        site_input = docs_repo / "_site_input"

        # 1. Walk docs repo → transient Hugo content tree.
        generate_site_input(docs_repo=docs_repo, output_dir=site_input)

        # 2. Stage theme inside the content tree.
        themes_dir = site_input / "themes"
        themes_dir.mkdir(exist_ok=True)
        theme_link = themes_dir / "forge-manager-default"
        if theme_link.exists() or theme_link.is_symlink():
            if theme_link.is_symlink():
                theme_link.unlink()
            else:
                shutil.rmtree(theme_link)
        theme_link.symlink_to(self._theme_dir)

        # 3. Write hugo.toml.
        config = HUGO_CONFIG_TEMPLATE.format(base_url=base_url)
        (site_input / "hugo.toml").write_text(config, encoding="utf-8")

        # 4. Invoke hugo.
        target_dir.mkdir(parents=True, exist_ok=True)
        await self._run_hugo(
            "--source", str(site_input),
            "--destination", str(target_dir),
            "--minify",
        )
        return target_dir

    async def serve(
        self,
        *,
        docs_repo: Path,
        port: int = 1313,
        bind: str = "127.0.0.1",
    ) -> None:
        docs_repo = docs_repo.resolve()
        site_input = docs_repo / "_site_input"

        # Same prep as build, minus the destination dir.
        generate_site_input(docs_repo=docs_repo, output_dir=site_input)

        themes_dir = site_input / "themes"
        themes_dir.mkdir(exist_ok=True)
        theme_link = themes_dir / "forge-manager-default"
        if theme_link.exists() or theme_link.is_symlink():
            if theme_link.is_symlink():
                theme_link.unlink()
            else:
                shutil.rmtree(theme_link)
        theme_link.symlink_to(self._theme_dir)

        config = HUGO_CONFIG_TEMPLATE.format(base_url="/")
        (site_input / "hugo.toml").write_text(config, encoding="utf-8")

        # `hugo serve` blocks until killed; the caller's task handles
        # cancellation (KeyboardInterrupt during ad-hoc CLI use).
        await self._run_hugo(
            "serve",
            "--source", str(site_input),
            "--port", str(port),
            "--bind", bind,
        )

    async def probe(self) -> bool:
        """Returns True iff `hugo version` succeeds."""
        try:
            proc = await asyncio.create_subprocess_exec(
                self._hugo, "version",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            return await proc.wait() == 0
        except (FileNotFoundError, OSError):
            return False

    # -----------------------------------------------------------------------

    async def _run_hugo(self, *args: str) -> None:
        """Run ``hugo`` with the given args; raise on non-zero exit."""
        proc = await asyncio.create_subprocess_exec(
            self._hugo, *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(
                f"hugo {' '.join(args)} failed (exit {proc.returncode})\n"
                f"stdout:\n{stdout.decode('utf-8', 'replace')}\n"
                f"stderr:\n{stderr.decode('utf-8', 'replace')}"
            )
