"""SiteRenderer Protocol — abstracts the static-site renderer choice
per OQ7. Hugo is the 3.0 default; alternative renderers (Zola, etc.)
land as new implementations of this Protocol without touching the
calling code.
"""
from __future__ import annotations

from pathlib import Path
from typing import ClassVar, Protocol, runtime_checkable


@runtime_checkable
class SiteRenderer(Protocol):
    """Renders a docs repo as a public-facing static site.

    The Protocol's contract is intentionally narrow — three operations
    that the ``site_*`` MCP tools call. Implementations decide their
    own template language, theme layout, and build invocation.
    """

    renderer_id: ClassVar[str]
    """Stable identifier ('hugo', 'zola', ...). Used in
    ``forge-config.json.site_renderer`` and in error messages."""

    async def build(
        self,
        *,
        docs_repo: Path,
        target_dir: Path,
        base_url: str = "/",
    ) -> Path:
        """Render the canonical docs repo into a static site.

        Implementations must:
          1. Walk ``docs_repo`` (issues/, discussions/, milestones/,
             releases/) and produce an intermediate Hugo-/Zola-
             compatible content tree.
          2. Run the renderer's build command against that tree.
          3. Place the output at ``target_dir`` (created if missing).

        Returns the path to the populated ``target_dir`` for caller
        convenience.
        """
        ...

    async def serve(
        self,
        *,
        docs_repo: Path,
        port: int = 1313,
        bind: str = "127.0.0.1",
    ) -> None:
        """Run the renderer's local development server. Blocks until
        the caller cancels (KeyboardInterrupt or task cancellation).
        Used by the ``serve_site`` MCP tool for ad-hoc browsing without
        a Pages deploy. Live-reload is implementation-specific."""
        ...

    async def probe(self) -> bool:
        """Cheap health check — returns ``True`` if the renderer's CLI
        is reachable and reports its version. ``False`` on missing
        binary, version mismatch, or any classified failure."""
        ...
