"""YIQ contrast computation — derives a readable text color for a
given label background hex. Used by the front-matter generator so
each rendered label pill embeds an accurate ``--label-text-color``
CSS custom property without runtime JS or fancy CSS.

The YIQ formula matches GitHub's Primer convention for label text:

    y = (r * 299 + g * 587 + b * 114) / 1000
    text = "#000000" if y >= 128 else "#ffffff"

GitHub itself uses a slightly different threshold (128 vs 150
depending on epoch), but 128 is the widely-cited cutoff and
produces the same result on the labels we observe in practice.
"""
from __future__ import annotations


_BLACK = "#000000"
_WHITE = "#ffffff"


def yiq_text_color(hex_color: str) -> str:
    """Return ``"#000000"`` or ``"#ffffff"`` for legible text on the
    given background hex.

    ``hex_color`` accepts ``"abcdef"``, ``"#abcdef"``, ``"abc"``,
    ``"#abc"`` (3- or 6-digit forms, leading hash optional).
    Returns black on light backgrounds, white on dark.

    Raises ``ValueError`` on malformed input.
    """
    hex_clean = hex_color.lstrip("#").strip().lower()
    if len(hex_clean) == 3:
        # Expand 3-digit shorthand: 'abc' → 'aabbcc'
        hex_clean = "".join(ch * 2 for ch in hex_clean)
    if len(hex_clean) != 6:
        raise ValueError(
            f"yiq_text_color: expected 3- or 6-digit hex, got {hex_color!r}"
        )
    try:
        r = int(hex_clean[0:2], 16)
        g = int(hex_clean[2:4], 16)
        b = int(hex_clean[4:6], 16)
    except ValueError as exc:
        raise ValueError(
            f"yiq_text_color: hex {hex_color!r} contains non-hex chars"
        ) from exc
    yiq = (r * 299 + g * 587 + b * 114) / 1000
    return _BLACK if yiq >= 128 else _WHITE
