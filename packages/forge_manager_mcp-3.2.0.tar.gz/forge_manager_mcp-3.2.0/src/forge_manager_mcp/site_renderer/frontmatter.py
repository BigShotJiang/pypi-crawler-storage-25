"""Front-matter generator — walks the docs repo and produces Hugo-
compatible content (markdown with TOML/YAML front matter) without
modifying the canonical source.

Schema mapping (canonical → Hugo content tree):

  ``docs_repo/issues/<N>/``  → ``_site_input/content/issues/<N>.md``
  ``docs_repo/discussions/<N>/`` → ``_site_input/content/discussions/<N>.md``
  ``docs_repo/milestones/<X.Y.Z>.md`` → ``_site_input/content/milestones/<X.Y.Z>.md``
  ``docs_repo/releases/<X.Y.Z>/...`` → ``_site_input/content/releases/<X.Y.Z>.md``

Front matter for an issue carries:

  title, number, state, labels (list), label_colors (map name→hex),
  label_text_colors (map name→#000/#fff via YIQ), milestone, kind,
  category, decided, comments[], created_at, author.

The resulting content can be built by ``hugo`` directly; comments
are inlined into the body as section blocks for the ``issue.html``
layout to render.
"""
from __future__ import annotations

import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import Any

from .contrast import yiq_text_color


# Default label color when a label has no explicit color in the docs
# repo. Matches Hugo's `default` taxonomy color so the rendering
# stays neutral.
_DEFAULT_LABEL_COLOR = "#d0d7de"

# Hugo content sections — each maps to a canonical docs-repo subdir.
_SECTIONS = {
    "issues": "issues",
    "discussions": "discussions",
    "milestones": "milestones",
    "releases": "releases",
}


def generate_site_input(
    *,
    docs_repo: Path,
    output_dir: Path,
    label_colors: dict[str, str] | None = None,
    changed_artifacts: dict[str, list] | None = None,
) -> Path:
    """Walk ``docs_repo`` and emit a Hugo content tree under
    ``output_dir``. Returns the populated ``output_dir``.

    ``label_colors`` is an optional pre-resolved mapping of label
    name → hex color (without leading ``#``). Labels not in the
    map fall back to the default neutral color. Future iteration:
    pull from the canonical labels.json or from the LocalStoreAdapter.

    ``changed_artifacts`` controls full-vs-incremental emission:

    * ``None`` (default) — full walk: every issue / discussion /
      milestone / release re-emitted; the home page rebuilt; the
      output_dir wiped first. Backward-compatible with pre-3.x
      callers.
    * non-None — incremental walk: only the artifacts named in
      ``changed_artifacts`` re-emit. ``output_dir`` is NOT wiped;
      existing entries persist. Shape:

          {"issues": [1, 5, 7], "discussions": [3], "milestones": ["v3.0.0"], "releases": ["v3.0.0"]}

      Keys absent from the dict skip their section entirely. The
      home page is re-emitted unconditionally on incremental runs
      (it derives from full-state aggregates and is cheap to
      regenerate). Tests live alongside.

    Incremental mode is the foundation for the live-update
    subset-rebuild — the SiteRebuilder hook will eventually thread
    canonical-write payloads through to a per-mutation
    changed_artifacts dict, so a single create_issue triggers
    only the affected page emit + Hugo rebuild rather than a full
    docs-repo walk.
    """
    label_colors = label_colors or {}
    docs_repo = docs_repo.resolve()
    output_dir = output_dir.resolve()

    incremental = changed_artifacts is not None
    if not incremental:
        if output_dir.exists():
            shutil.rmtree(output_dir)
        output_dir.mkdir(parents=True)
        content_dir = output_dir / "content"
        content_dir.mkdir()
    else:
        content_dir = output_dir / "content"
        content_dir.mkdir(parents=True, exist_ok=True)

    if incremental:
        for n in (changed_artifacts or {}).get("issues", []):
            _emit_one_issue(docs_repo, content_dir, int(n), label_colors)
        for n in (changed_artifacts or {}).get("discussions", []):
            _emit_one_discussion(docs_repo, content_dir, int(n), label_colors)
        for title in (changed_artifacts or {}).get("milestones", []):
            _emit_one_milestone(docs_repo, content_dir, str(title))
        for tag in (changed_artifacts or {}).get("releases", []):
            _emit_one_release(docs_repo, content_dir, str(tag))
    else:
        _emit_issues(docs_repo, content_dir, label_colors)
        _emit_discussions(docs_repo, content_dir, label_colors)
        _emit_milestones(docs_repo, content_dir)
        _emit_releases(docs_repo, content_dir)

    # Home page re-emits in both modes — it aggregates over the full
    # docs repo state, not just the changed artifacts.
    _emit_home(docs_repo, content_dir)

    return output_dir


# ---------------------------------------------------------------------------
# Per-section emitters
# ---------------------------------------------------------------------------

def _emit_issues(
    docs_repo: Path, content_dir: Path, label_colors: dict[str, str],
) -> None:
    src = docs_repo / "issues"
    if not src.exists():
        return
    out = content_dir / "issues"
    out.mkdir(parents=True, exist_ok=True)

    for entry in sorted(src.iterdir(), key=lambda e: e.name):
        if not entry.is_dir():
            continue
        try:
            number = int(entry.name)
        except ValueError:
            continue
        front_matter, body = _shape_artifact(
            kind="issue",
            number=number,
            artifact_dir=entry,
            label_colors=label_colors,
        )
        _write_md(out / f"{number}.md", front_matter, body)


def _emit_discussions(
    docs_repo: Path, content_dir: Path, label_colors: dict[str, str],
) -> None:
    src = docs_repo / "discussions"
    if not src.exists():
        return
    out = content_dir / "discussions"
    out.mkdir(parents=True, exist_ok=True)

    for entry in sorted(src.iterdir(), key=lambda e: e.name):
        if not entry.is_dir():
            continue
        try:
            number = int(entry.name)
        except ValueError:
            continue
        front_matter, body = _shape_artifact(
            kind="discussion",
            number=number,
            artifact_dir=entry,
            label_colors=label_colors,
        )
        _write_md(out / f"{number}.md", front_matter, body)


def _emit_one_issue(
    docs_repo: Path, content_dir: Path, number: int,
    label_colors: dict[str, str],
) -> None:
    """Single-artifact emitter for incremental rebuild. Mirrors the
    inner loop body of ``_emit_issues`` for one issue number. Skips
    silently when the artifact dir doesn't exist (deletion case)."""
    src = docs_repo / "issues" / str(number)
    out = content_dir / "issues"
    out.mkdir(parents=True, exist_ok=True)
    target = out / f"{number}.md"
    if not src.is_dir():
        # Deletion: artifact dir gone → remove the rendered page too.
        if target.exists():
            target.unlink()
        return
    front_matter, body = _shape_artifact(
        kind="issue",
        number=number,
        artifact_dir=src,
        label_colors=label_colors,
    )
    _write_md(target, front_matter, body)


def _emit_one_discussion(
    docs_repo: Path, content_dir: Path, number: int,
    label_colors: dict[str, str],
) -> None:
    """Single-artifact emitter for incremental rebuild."""
    src = docs_repo / "discussions" / str(number)
    out = content_dir / "discussions"
    out.mkdir(parents=True, exist_ok=True)
    target = out / f"{number}.md"
    if not src.is_dir():
        if target.exists():
            target.unlink()
        return
    front_matter, body = _shape_artifact(
        kind="discussion",
        number=number,
        artifact_dir=src,
        label_colors=label_colors,
    )
    _write_md(target, front_matter, body)


def _emit_one_milestone(
    docs_repo: Path, content_dir: Path, title: str,
) -> None:
    """Single-milestone emitter for incremental rebuild."""
    src = docs_repo / "milestones" / f"{title}.md"
    out = content_dir / "milestones"
    out.mkdir(parents=True, exist_ok=True)
    target = out / f"{title}.md"
    if not src.is_file():
        if target.exists():
            target.unlink()
        return
    body = src.read_text(encoding="utf-8")
    front_matter = {"title": title, "type": "milestone"}
    _write_md(target, front_matter, body)


def _emit_one_release(
    docs_repo: Path, content_dir: Path, tag: str,
) -> None:
    """Single-release emitter for incremental rebuild."""
    out = content_dir / "releases"
    out.mkdir(parents=True, exist_ok=True)
    target = out / f"{tag}.md"
    # releases/<tag>/notes.md takes precedence over releases/<tag>.md
    dir_form = docs_repo / "releases" / tag
    file_form = docs_repo / "releases" / f"{tag}.md"
    if dir_form.is_dir() and (dir_form / "notes.md").exists():
        body = (dir_form / "notes.md").read_text(encoding="utf-8")
        front_matter = {"title": tag, "type": "release"}
        _write_md(target, front_matter, body)
        return
    if file_form.is_file():
        body = file_form.read_text(encoding="utf-8")
        front_matter = {"title": tag, "type": "release"}
        _write_md(target, front_matter, body)
        return
    if target.exists():
        target.unlink()


def _emit_milestones(docs_repo: Path, content_dir: Path) -> None:
    src = docs_repo / "milestones"
    if not src.exists():
        return
    out = content_dir / "milestones"
    out.mkdir(parents=True, exist_ok=True)

    for entry in sorted(src.iterdir()):
        if not (entry.is_file() and entry.suffix == ".md"):
            continue
        title = entry.stem
        body = entry.read_text(encoding="utf-8")
        front_matter = {
            "title": title,
            "type": "milestone",
        }
        _write_md(out / entry.name, front_matter, body)


def _emit_releases(docs_repo: Path, content_dir: Path) -> None:
    src = docs_repo / "releases"
    if not src.exists():
        return
    out = content_dir / "releases"
    out.mkdir(parents=True, exist_ok=True)

    for entry in sorted(src.iterdir()):
        if entry.is_dir():
            # releases/<X.Y.Z>/notes.md convention
            notes = entry / "notes.md"
            if notes.exists():
                front_matter = {
                    "title": entry.name,
                    "type": "release",
                }
                body = notes.read_text(encoding="utf-8")
                _write_md(out / f"{entry.name}.md", front_matter, body)
        elif entry.is_file() and entry.suffix == ".md":
            title = entry.stem
            front_matter = {
                "title": title,
                "type": "release",
            }
            body = entry.read_text(encoding="utf-8")
            _write_md(out / entry.name, front_matter, body)


def _emit_home(docs_repo: Path, content_dir: Path) -> None:
    """Emit the home page (_index.md) — a brief landing pulling from
    the docs repo's CONVENTIONS.md / README.md if present."""
    pieces: list[str] = []
    readme = docs_repo / "README.md"
    conventions = docs_repo / "CONVENTIONS.md"
    if readme.exists():
        pieces.append(readme.read_text(encoding="utf-8"))
    elif conventions.exists():
        pieces.append(conventions.read_text(encoding="utf-8"))
    body = "\n\n".join(pieces) if pieces else "# forge-manager docs site\n"
    front_matter = {"title": "Home", "type": "home"}
    _write_md(content_dir / "_index.md", front_matter, body)


# ---------------------------------------------------------------------------
# Per-artifact shaper
# ---------------------------------------------------------------------------

def _shape_artifact(
    *,
    kind: str,
    number: int,
    artifact_dir: Path,
    label_colors: dict[str, str],
) -> tuple[dict[str, Any], str]:
    """Read an issue/discussion directory and return (front_matter, body)."""
    title = _read_text(artifact_dir / "title.md").strip() or f"#{number}"
    body = _read_text(artifact_dir / "body.md")
    state_lines = _read_text(artifact_dir / "state.txt").strip().splitlines()
    states = [s.strip() for s in state_lines if s.strip()]
    state = states[0] if states else "open"
    decided = "decided" in states

    label_lines = _read_text(artifact_dir / "labels.txt").strip().splitlines()
    labels = [l.strip() for l in label_lines if l.strip()]

    meta = _read_json(artifact_dir / "meta.json") or {}
    created_at = meta.get("created_at", "")
    author = meta.get("created_by", "") or meta.get("author", "")
    milestone = meta.get("milestone", "")
    category = meta.get("category", "") or _category_from_labels(labels)

    color_map = {l: label_colors.get(l, _DEFAULT_LABEL_COLOR.lstrip("#"))
                 for l in labels}
    text_color_map = {
        l: yiq_text_color(c) for l, c in color_map.items()
    }

    front_matter: dict[str, Any] = {
        "title": title,
        # 'kind' would collide with Hugo's reserved page-kind field; we
        # use the canonical 'type' alone (which Hugo also uses for
        # layout selection) and let content sections (/issues/,
        # /discussions/) carry the artifact-kind grouping.
        "type": kind,
        "number": number,
        "state": state,
        "decided": decided,
        "labels": labels,
        "label_colors": color_map,
        "label_text_colors": text_color_map,
        "milestone": milestone,
        "category": category,
        "author": author,
        "date": _normalize_date(created_at),
        "url": f"/{kind}s/{number}/",
    }

    comments_block = _comments_block(artifact_dir / "comments")
    if comments_block:
        body = body.rstrip() + "\n\n" + comments_block

    return front_matter, body


def _comments_block(comments_dir: Path) -> str:
    if not comments_dir.exists():
        return ""
    parts: list[str] = []
    for entry in sorted(comments_dir.iterdir()):
        if not (entry.is_file() and entry.suffix == ".md"):
            continue
        # Filename convention: <utc-ts>-<author>.md
        stem = entry.stem
        ts, _, author = stem.partition("-")
        body = entry.read_text(encoding="utf-8").rstrip()
        parts.append(
            f"\n\n<section class=\"comment\" data-author=\"{author}\" "
            f"data-timestamp=\"{ts}\">\n\n{body}\n\n</section>"
        )
    if not parts:
        return ""
    return "## Comments\n" + "".join(parts)


# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def _category_from_labels(labels: list[str]) -> str:
    for label in labels:
        if label.startswith("category:"):
            return label.split(":", 1)[1]
    return ""


def _normalize_date(raw: str) -> str:
    """Best-effort ISO-date emission for Hugo's `date` field."""
    if not raw:
        return ""
    raw = raw.strip()
    # Already ISO?
    try:
        datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return raw
    except ValueError:
        pass
    # Date only?
    try:
        d = datetime.strptime(raw, "%Y-%m-%d")
        return d.date().isoformat()
    except ValueError:
        return raw


def _read_text(path: Path) -> str:
    if not path.exists():
        return ""
    return path.read_text(encoding="utf-8")


def _read_json(path: Path) -> dict[str, Any] | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _write_md(
    path: Path, front_matter: dict[str, Any], body: str,
) -> None:
    """Write Hugo-style markdown with YAML front matter."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fm_yaml = _to_yaml(front_matter)
    text = f"---\n{fm_yaml}---\n\n{body}\n"
    path.write_text(text, encoding="utf-8")


def _to_yaml(d: dict[str, Any]) -> str:
    """Minimal YAML emitter for the front-matter shapes we produce.

    Avoids pulling in PyYAML as a dependency. Handles the value
    shapes we actually emit: str, int, float, bool, list[str],
    dict[str, str]. Nested complexity is not supported.
    """
    lines: list[str] = []
    for k, v in d.items():
        lines.append(_yaml_kv(k, v))
    return "\n".join(lines) + "\n"


def _yaml_kv(key: str, value: Any) -> str:
    if isinstance(value, bool):
        return f"{key}: {'true' if value else 'false'}"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return f"{key}: {value}"
    if value is None or value == "":
        return f'{key}: ""'
    if isinstance(value, str):
        return f"{key}: {_yaml_string(value)}"
    if isinstance(value, list):
        if not value:
            return f"{key}: []"
        items = "\n".join(f"  - {_yaml_string(str(item))}" for item in value)
        return f"{key}:\n{items}"
    if isinstance(value, dict):
        if not value:
            return f"{key}: {{}}"
        items = "\n".join(
            f"  {_yaml_string(str(k))}: {_yaml_string(str(v))}"
            for k, v in value.items()
        )
        return f"{key}:\n{items}"
    return f"{key}: {_yaml_string(str(value))}"


def _yaml_string(s: str) -> str:
    """Quote a string when it contains characters that would confuse
    a YAML parser; plain otherwise. Heuristic, not a full YAML
    serializer."""
    if not s:
        return '""'
    needs_quote = any(c in s for c in (":", "#", "{", "}", "[", "]", ",", "&", "*",
                                        "!", "|", ">", "'", '"', "%", "@", "`"))
    if needs_quote or s.startswith((" ", "-")) or s != s.strip():
        return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return s
