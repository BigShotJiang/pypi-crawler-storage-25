"""Live-update wrapper around the Hugo SiteRenderer.

Foundation for the live-updating Hugo system filed as a bug at session
start. Wraps HugoRenderer with debounced rebuild scheduling so the
ReplicationManager can notify on every canonical write without
spawning a Hugo subprocess per mutation — a debounce window coalesces
rapid-succession writes (e.g. create_issue + add_label + comment from
one tool call) into a single rebuild.

This commit ships the foundation: SiteRebuilder class + the
ReplicationManager hook plumbing. Auto-deploy after rebuild and
forge-config schema integration land in follow-up commits — the bug's
acceptance criteria #2 (auto-deploy) and #4 (no regression on existing
tools) explicitly span multiple slices.

Lifecycle: SiteRebuilder is constructed once at server start and
lives for the process lifetime. `notify()` is sync (called from the
canonical-write hook); the actual rebuild runs in a background
asyncio.Task spawned by the most recent notify(). Each notify cancels
any prior pending task, so the debounce window resets on every
notification — exactly the coalescing behavior the bug calls for.
"""
from __future__ import annotations

import asyncio
import logging
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Awaitable, Callable

from .hugo import HugoRenderer


_LOGGER = logging.getLogger(__name__)


class SiteRebuilder:
    """Debounced live-update wrapper around a SiteRenderer.

    Construct once at server boot; pass ``notify`` as the
    ``on_canonical_write`` hook to ReplicationManager. The rebuilder
    schedules a background asyncio Task per notification batch;
    successive notifies within ``debounce_seconds`` cancel the prior
    task and start fresh, so a sequence of rapid writes generates one
    rebuild after the dust settles.

    Failures (Hugo not installed, build errors, etc.) are logged and
    optionally fed to ``on_failure`` for downstream surfacing — they
    never raise back into the canonical-write call site, since the
    contract is that a failed rebuild does NOT poison the originating
    tool call (per the bug's acceptance criterion #3).
    """

    def __init__(
        self,
        *,
        docs_repo: Path,
        target_dir: Path,
        renderer: HugoRenderer | None = None,
        debounce_seconds: float = 1.5,
        deploy_target: str | None = None,
        deploy_branch: str = "pages",
        on_failure: Callable[[Exception], None] | None = None,
    ):
        if debounce_seconds < 0:
            raise ValueError("debounce_seconds must be >= 0")
        self._docs_repo = docs_repo
        self._target_dir = target_dir
        self._renderer = renderer or HugoRenderer()
        self._debounce_seconds = debounce_seconds
        self._deploy_target = deploy_target
        self._deploy_branch = deploy_branch
        self._on_failure = on_failure
        self._pending_task: asyncio.Task | None = None
        self._last_operations: list[str] = []
        self._last_build_succeeded: bool | None = None
        self._last_deploy_succeeded: bool | None = None

    # ------------------------------------------------------------------
    # Hook surface
    # ------------------------------------------------------------------

    def notify(self, operation_name: str) -> None:
        """Record one canonical-write event. Schedules a background
        rebuild after the debounce window expires. Cheap (sync,
        non-blocking) — safe to call from the ReplicationManager.write
        hot path.

        Idempotent within the debounce window: calls after the first
        bump the same task's deadline rather than spawning a parallel
        rebuild. Operation names accumulate so the eventual rebuild
        can log what triggered it.
        """
        self._last_operations.append(operation_name)
        # Cancel any pending task — we'll re-arm with a fresh deadline.
        if self._pending_task is not None and not self._pending_task.done():
            self._pending_task.cancel()
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            # No running loop — caller is sync-only or running outside
            # an event loop. Drop the notification rather than spawning
            # a task we can't manage. Tests that exercise the
            # rebuild path arrange a loop explicitly via flush().
            return
        self._pending_task = loop.create_task(self._delayed_rebuild())

    async def flush(self) -> bool | None:
        """Run any pending rebuild immediately. Blocks until done.

        Returns True if a rebuild succeeded, False if it failed,
        None if there was nothing pending. Used by tests + by
        ``close_session`` to ensure the rendered site reflects every
        write before the process exits.
        """
        if self._pending_task is None or self._pending_task.done():
            if not self._last_operations:
                return None
            # Drain any operations that were queued without an active
            # task (e.g., notify() called outside a running loop).
            return await self._do_rebuild()
        # Cancel the debounce wait and trigger immediately.
        self._pending_task.cancel()
        try:
            await self._pending_task
        except asyncio.CancelledError:
            pass
        return await self._do_rebuild()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _delayed_rebuild(self) -> None:
        """Wait debounce_seconds, then rebuild. Cancellation during
        the sleep just exits silently — a fresh notify() spawned a
        replacement task."""
        try:
            await asyncio.sleep(self._debounce_seconds)
        except asyncio.CancelledError:
            return
        await self._do_rebuild()

    async def _do_rebuild(self) -> bool:
        """Run the renderer + optionally the deploy push. Reset the
        dirty-state. Returns True on rebuild success (deploy success
        is reported separately on ``last_deploy_succeeded``), False
        on rebuild failure. Failures are logged; ``on_failure`` is
        invoked with the exception so callers can surface a
        structured warning. Never re-raises — the rebuilder's
        contract is that a failed rebuild doesn't poison the
        canonical write."""
        operations = list(self._last_operations)
        self._last_operations.clear()
        try:
            await self._renderer.build(
                docs_repo=self._docs_repo,
                target_dir=self._target_dir,
            )
            self._last_build_succeeded = True
            _LOGGER.info(
                "site rebuilt after %d ops: %s",
                len(operations), ", ".join(operations[:5]),
            )
        except Exception as exc:  # noqa: BLE001 — see docstring
            self._last_build_succeeded = False
            _LOGGER.warning("site rebuild failed: %s", exc)
            if self._on_failure is not None:
                try:
                    self._on_failure(exc)
                except Exception:  # noqa: BLE001
                    _LOGGER.exception("on_failure callback itself raised")
            return False

        # Rebuild succeeded; if a deploy target is configured, push.
        # Deploy failures are observability events — last_deploy_succeeded
        # records the outcome; on_failure receives the exception. The
        # rebuild itself is still considered successful.
        if self._deploy_target is not None:
            try:
                await self._do_deploy()
                self._last_deploy_succeeded = True
                _LOGGER.info(
                    "site deployed to %s (branch: %s)",
                    self._deploy_target, self._deploy_branch,
                )
            except Exception as exc:  # noqa: BLE001
                self._last_deploy_succeeded = False
                _LOGGER.warning("site deploy failed: %s", exc)
                if self._on_failure is not None:
                    try:
                        self._on_failure(exc)
                    except Exception:  # noqa: BLE001
                        _LOGGER.exception("on_failure callback itself raised")
        return True

    async def _do_deploy(self) -> None:
        """Push the rendered ``target_dir`` to ``deploy_target`` /
        ``deploy_branch``.

        Convention: ``target_dir`` is a git working copy whose
        ``origin`` (or some named remote) is the publish target —
        operator initializes this once at bootstrap. The deploy step
        adds every file in target_dir, commits with a timestamped
        message, and pushes ``HEAD`` to ``<deploy_branch>`` on the
        configured remote.

        ``deploy_target`` semantics:
          * ``"<remote-name>"`` (e.g., ``"origin"``) → push to that
            named remote on ``deploy_branch``.
          * ``"<URL>"`` → push to the URL directly. The URL must
            already be reachable (token / SSH-key configured).

        Raises subprocess.CalledProcessError on git failure.
        """
        if not self._target_dir.is_dir():
            raise FileNotFoundError(
                f"deploy: target_dir {self._target_dir} does not exist"
            )
        if not (self._target_dir / ".git").exists():
            raise FileNotFoundError(
                f"deploy: target_dir {self._target_dir} is not a git repo. "
                "Initialize it once at bootstrap with `git init` + "
                "`git remote add <name> <url>` against the publish target."
            )

        ts = datetime.now(timezone.utc).isoformat()
        commit_message = f"site rebuild {ts}"
        # Run git commands sequentially in target_dir.
        await self._run_git("add", "-A")
        await self._run_git(
            "commit", "--allow-empty", "-m", commit_message,
        )
        # Push HEAD to deploy_branch on the named remote (or URL).
        await self._run_git(
            "push", self._deploy_target or "origin",
            f"HEAD:{self._deploy_branch}",
        )

    async def _run_git(self, *args: str) -> None:
        """Run a git subcommand in ``target_dir``. Errors raise.

        Wrapped as a method so tests can monkey-patch a single
        choke-point rather than every subprocess call.
        """
        proc = await asyncio.create_subprocess_exec(
            "git", "-C", str(self._target_dir), *args,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise subprocess.CalledProcessError(
                proc.returncode, ["git", "-C", str(self._target_dir), *args],
                output=stdout, stderr=stderr,
            )

    # ------------------------------------------------------------------
    # Inspection (tests + diagnostics)
    # ------------------------------------------------------------------

    @property
    def last_build_succeeded(self) -> bool | None:
        """True / False after the most recent rebuild; None before
        the first rebuild has run."""
        return self._last_build_succeeded

    @property
    def last_deploy_succeeded(self) -> bool | None:
        """True / False after the most recent deploy push; None
        before any deploy has run (or when deploy_target is unset)."""
        return self._last_deploy_succeeded

    @property
    def has_pending(self) -> bool:
        """True iff a rebuild is queued or in flight."""
        return self._pending_task is not None and not self._pending_task.done()
