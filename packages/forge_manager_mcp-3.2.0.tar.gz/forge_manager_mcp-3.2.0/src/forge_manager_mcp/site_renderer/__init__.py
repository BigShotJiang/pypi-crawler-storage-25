"""Static-site rendering layer for forge-manager (3.0 / Phase 5).

Public surface:

  * ``SiteRenderer`` — Protocol every renderer implements (per OQ7).
  * ``HugoRenderer`` — concrete implementation invoking the Hugo CLI.
  * ``generate_site_input`` — walks the docs repo and emits Hugo-
    compatible markdown with front matter into a transient build dir.
  * ``yiq_text_color`` — auto-contrast text color computation for
    GitHub-style label pills.
"""
from __future__ import annotations

from .contrast import yiq_text_color
from .frontmatter import generate_site_input
from .hugo import HugoRenderer
from .protocol import SiteRenderer

__all__ = [
    "HugoRenderer",
    "SiteRenderer",
    "generate_site_input",
    "yiq_text_color",
]
