"""Migration runner — applies a MigrationPlan with a backup, and
rolls back from a backup on demand (3.0 / Phase 7).

Backups are full directory snapshots placed under
``<project_dir>/.claude/backups/migration-<utc-ts>/``. The runner
records the path of the backup it created so the caller can pass it
back to ``rollback_plan`` for clean reversal.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .detector import MigrationPlan, MigrationStep


_BACKUP_DIRNAME = "backups"
_LEGACY_SKILL_NAME = "active-claude-github"
_NEW_SKILL_NAME = "forge-manager"


def apply_plan(
    plan: MigrationPlan,
    *,
    apply: bool = False,
) -> dict[str, Any]:
    """Execute a MigrationPlan.

    ``apply=False`` (default) → dry run; returns the steps with
    ``executed=False`` and no filesystem changes.

    ``apply=True`` → creates a backup of the .claude/ directory,
    then executes each step. Returns the steps with their executed
    status, the backup path, and any per-step diagnostics.

    Raises ``MigrationError`` (subclass of RuntimeError) if a step
    fails after the backup is created — the operator can then call
    ``rollback_plan`` with the returned ``backup_path``.
    """
    result: dict[str, Any] = {
        "project_dir": str(plan.project_dir),
        "applied": apply,
        "steps": [],
        "backup_path": None,
        "warnings": list(plan.warnings),
    }

    if not apply:
        for step in plan.steps:
            result["steps"].append({
                "kind": step.kind,
                "description": step.description,
                "executed": False,
                "dry_run": True,
            })
        return result

    if not plan.steps:
        return result

    backup_path = _create_backup(plan.project_dir)
    result["backup_path"] = str(backup_path)

    for step in plan.steps:
        try:
            _execute_step(plan.project_dir, step)
            result["steps"].append({
                "kind": step.kind,
                "description": step.description,
                "executed": True,
            })
        except Exception as exc:
            result["steps"].append({
                "kind": step.kind,
                "description": step.description,
                "executed": False,
                "error": f"{exc.__class__.__name__}: {exc}",
            })
            raise MigrationError(
                f"step {step.kind!r} failed; backup at {backup_path}"
            ) from exc

    return result


def rollback_plan(
    *,
    project_dir: Path,
    backup_path: Path,
) -> dict[str, Any]:
    """Restore the project's .claude/ directory from ``backup_path``.

    The backup must have been produced by ``apply_plan(plan, apply=True)``.
    Existing .claude/ is replaced atomically (via rename to
    ``.claude.pre-rollback-<ts>/`` then promote backup to .claude/).

    Returns a dict reporting the rollback outcome.
    """
    project_dir = project_dir.resolve()
    backup_path = backup_path.resolve()
    if not backup_path.is_dir():
        raise MigrationError(f"backup not found at {backup_path}")
    claude_dir = project_dir / ".claude"
    if not claude_dir.exists():
        raise MigrationError(f"{claude_dir} does not exist; nothing to roll back")

    pre_rollback_ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    pre_rollback_dir = project_dir / f".claude.pre-rollback-{pre_rollback_ts}"
    claude_dir.rename(pre_rollback_dir)

    # Backup is typically inside the just-renamed .claude/ tree; resolve
    # against the new location if so. Otherwise (operator pointed at an
    # external backup) use the path as given.
    try:
        rel_inside_claude = backup_path.relative_to(claude_dir)
        effective_backup = pre_rollback_dir / rel_inside_claude
    except ValueError:
        effective_backup = backup_path

    # Backup includes the contents of `.claude/` from the time of
    # apply; promote it back into place.
    shutil.copytree(effective_backup, claude_dir)

    return {
        "project_dir": str(project_dir),
        "backup_path": str(backup_path),
        "pre_rollback_dir": str(pre_rollback_dir),
        "restored": True,
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class MigrationError(RuntimeError):
    """Raised when a migration step fails after the backup is created."""


def _create_backup(project_dir: Path) -> Path:
    """Snapshot .claude/ into .claude/backups/migration-<utc-ts>/."""
    claude_dir = project_dir / ".claude"
    backups_root = claude_dir / _BACKUP_DIRNAME
    backups_root.mkdir(exist_ok=True)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    backup_dir = backups_root / f"migration-{ts}"
    # Copy the full .claude/ tree EXCEPT the backups/ subdir itself.
    backup_dir.mkdir()
    for entry in claude_dir.iterdir():
        if entry == backups_root:
            continue
        dest = backup_dir / entry.name
        if entry.is_dir():
            shutil.copytree(entry, dest)
        else:
            shutil.copy2(entry, dest)
    return backup_dir


def _execute_step(project_dir: Path, step: MigrationStep) -> None:
    if step.kind == "rename_skill_dir":
        src = project_dir / step.source  # type: ignore[arg-type]
        tgt = project_dir / step.target  # type: ignore[arg-type]
        tgt.parent.mkdir(parents=True, exist_ok=True)
        src.rename(tgt)
        return

    if step.kind == "translate_config_schema":
        tgt = project_dir / step.target  # type: ignore[arg-type]
        translated: dict[str, Any] = step.payload["translated_data"]
        tgt.write_text(
            json.dumps(translated, indent=2) + "\n", encoding="utf-8",
        )
        # Remove the legacy file after the new one is in place.
        src = project_dir / step.source  # type: ignore[arg-type]
        if src.exists():
            src.unlink()
        return

    if step.kind == "rename_config_file":
        src = project_dir / step.source  # type: ignore[arg-type]
        tgt = project_dir / step.target  # type: ignore[arg-type]
        src.rename(tgt)
        return

    if step.kind == "update_claude_md":
        tgt = project_dir / step.target  # type: ignore[arg-type]
        original = tgt.read_text(encoding="utf-8")
        updated = _replace_skill_mentions(original)
        tgt.write_text(updated, encoding="utf-8")
        return

    if step.kind == "bootstrap_docs_repo":
        # Shared docs-repo helpers — the same code scaffold_project
        # (Gap A) uses, so the migration path produces a structurally-
        # identical local docs repo. (G6)
        from ..docs_repo import DocsRepoOriginConflict, ensure_local_docs_repo

        docs_path = Path(step.payload["docs_path"])
        project_name = step.payload.get("project_name") or docs_path.name
        docs_repo_full = step.payload.get("docs_repo_full") or ""
        remote_url = (
            f"https://github.com/{docs_repo_full}.git"
            if docs_repo_full else None
        )
        try:
            ensure_local_docs_repo(
                docs_path,
                project_name=project_name,
                remote_url=remote_url,
            )
        except DocsRepoOriginConflict as exc:
            # Pre-existing docs repo with a different origin (e.g.,
            # forgejo for projects whose canonical docs lives there
            # rather than GitHub). The dir / README / git init are
            # already in place; only the remote-set raised. Treat as
            # a non-fatal warning — the operator can reconcile origin
            # manually if a GitHub mirror is desired later. The
            # canonical store is still usable as-is.
            #
            # Record on step.payload so the response can surface it;
            # the runner's caller (migrate_to_3_0 handler) reads
            # ``manual_step_notes`` from the executed steps after
            # apply.
            step.payload["manual_step_note"] = (
                f"docs-repo origin already set on {docs_path} and "
                f"differs from the GitHub-mirror URL {remote_url}. "
                f"Migration left the existing origin in place. To "
                f"reconcile manually: ``git -C {docs_path} remote "
                f"set-url origin <desired-url>``. Conflict detail: "
                f"{exc}"
            )
            return
        except (OSError, subprocess.CalledProcessError, RuntimeError) as exc:
            raise MigrationError(
                f"docs-repo bootstrap failed at {docs_path}: {exc}"
            ) from exc
        return

    if step.kind == "noop":
        return

    raise MigrationError(f"unsupported step kind: {step.kind!r}")


# Replace non-historical mentions of "active-claude-github" with
# "forge-manager". Historical mentions are inside backticks-quoted
# blocks discussing the rename itself, recognized by surrounding
# parenthetical/quote context. The heuristic: bare identifiers
# (word boundaries) get replaced; quoted strings inside
# parenthetical "Pre-X.Y..." asides are left alone.
_LEGACY_RE = re.compile(rf"\b{re.escape(_LEGACY_SKILL_NAME)}\b")


def _replace_skill_mentions(content: str) -> str:
    """Replace 2.x skill mentions with the 3.0 name, line-by-line, but
    skip lines containing 'Pre-' which conventionally introduce
    historical references that shouldn't be retroactively edited."""
    out_lines: list[str] = []
    for line in content.splitlines(keepends=True):
        if "Pre-" in line or "(pre-" in line.lower():
            out_lines.append(line)
            continue
        out_lines.append(_LEGACY_RE.sub(_NEW_SKILL_NAME, line))
    return "".join(out_lines)
