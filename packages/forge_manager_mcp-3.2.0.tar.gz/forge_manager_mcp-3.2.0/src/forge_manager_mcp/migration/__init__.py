"""Migration tooling for 2.x → 3.0 project upgrades and incremental
backend addition (3.0 / Phase 7).

Public surface:

  * ``MigrationPlan`` — structured description of changes the
    migration tool will apply.
  * ``detect_legacy_state`` — walks a project dir and produces a
    MigrationPlan.
  * ``apply_plan`` / ``rollback_plan`` — execute the plan with a
    backup, or restore from a backup.
"""
from __future__ import annotations

from .detector import MigrationPlan, MigrationStep, detect_legacy_state
from .runner import apply_plan, rollback_plan

__all__ = [
    "MigrationPlan",
    "MigrationStep",
    "apply_plan",
    "detect_legacy_state",
    "rollback_plan",
]
