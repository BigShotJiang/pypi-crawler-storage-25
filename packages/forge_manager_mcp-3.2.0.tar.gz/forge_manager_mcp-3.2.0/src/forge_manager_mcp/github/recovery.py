"""Context-recovery helpers — read-only list queries (#58, #83)."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from .core import GitHubError, _graphql


async def list_thread_comments(
    token: str,
    thread_id: str,
    thread_type: str,
    limit: int = 20,
) -> list[dict]:
    """Return comments on an Issue or Discussion with author info.

    Each entry: {"comment_id": str, "author": str,
                 "created_at": str, "body": str}

    Ordered oldest → newest.
    """
    if not thread_id.strip():
        raise ValueError("thread_id must not be empty.")
    if thread_type not in ("issue", "discussion"):
        raise ValueError(
            f"thread_type must be 'issue' or 'discussion', got: {thread_type!r}"
        )
    if limit < 1 or limit > 100:
        raise ValueError("limit must be between 1 and 100.")

    fragment = "Discussion" if thread_type == "discussion" else "Issue"
    query = (
        "query($id: ID!, $last: Int!) {\n"
        "  node(id: $id) {\n"
        f"    ... on {fragment} {{\n"
        "      comments(last: $last) {\n"
        "        nodes { id body createdAt author { login } }\n"
        "      }\n"
        "    }\n"
        "  }\n"
        "}\n"
    )
    data = await _graphql(token, query, {"id": thread_id, "last": limit})
    node = data.get("node")
    if not node:
        raise GitHubError(
            f"{fragment} {thread_id} not found."
        )
    nodes = (node.get("comments") or {}).get("nodes") or []
    return [
        {
            "comment_id": n["id"],
            "author": (n.get("author") or {}).get("login", ""),
            "created_at": n["createdAt"],
            "body": n["body"],
        }
        for n in nodes
    ]


async def list_open_issues(
    token: str,
    owner: str,
    repo: str,
    limit: int = 100,
) -> list[dict]:
    """Return open Issues in the repo ordered by updated_at descending.

    Each entry: {"number": int, "title": str, "url": str,
                 "updated_at": str, "labels": list[str]}
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")
    if limit < 1 or limit > 100:
        raise ValueError("limit must be between 1 and 100.")

    query = """
    query($owner: String!, $repo: String!, $limit: Int!) {
      repository(owner: $owner, name: $repo) {
        issues(
          states: [OPEN],
          first: $limit,
          orderBy: {field: UPDATED_AT, direction: DESC}
        ) {
          nodes {
            number
            title
            url
            updatedAt
            labels(first: 20) { nodes { name } }
          }
        }
      }
    }
    """
    data = await _graphql(
        token, query, {"owner": owner, "repo": repo, "limit": limit}
    )
    repo_node = data.get("repository") or {}
    issues = (repo_node.get("issues") or {}).get("nodes") or []
    return [
        {
            "number": n["number"],
            "title": n["title"],
            "url": n["url"],
            "updated_at": n["updatedAt"],
            "labels": [
                lb["name"] for lb in (n.get("labels") or {}).get("nodes") or []
            ],
        }
        for n in issues
    ]


async def list_recent_discussions(
    token: str,
    owner: str,
    repo: str,
    since_days: int = 7,
    limit: int = 50,
) -> list[dict]:
    """Return Discussions updated within the last `since_days` days.

    Each entry: {"number": int, "title": str, "url": str,
                 "updated_at": str, "category": str}
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")
    if since_days < 1:
        raise ValueError("since_days must be positive.")
    if limit < 1 or limit > 100:
        raise ValueError("limit must be between 1 and 100.")

    query = """
    query($owner: String!, $repo: String!, $limit: Int!) {
      repository(owner: $owner, name: $repo) {
        discussions(
          first: $limit,
          orderBy: {field: UPDATED_AT, direction: DESC}
        ) {
          nodes {
            number
            title
            url
            updatedAt
            category { name }
          }
        }
      }
    }
    """
    data = await _graphql(
        token, query, {"owner": owner, "repo": repo, "limit": limit}
    )
    repo_node = data.get("repository") or {}
    nodes = (repo_node.get("discussions") or {}).get("nodes") or []

    # Filter by since_days client-side
    cutoff = datetime.now(timezone.utc) - timedelta(days=since_days)
    out: list[dict] = []
    for n in nodes:
        updated_at_str = n["updatedAt"]
        try:
            updated_at = datetime.fromisoformat(
                updated_at_str.replace("Z", "+00:00")
            )
        except ValueError:
            # Unparseable timestamps fall through (treated as recent).
            updated_at = datetime.now(timezone.utc)
        if updated_at < cutoff:
            # List is ordered DESC — anything older than cutoff means
            # the rest are older too.
            break
        out.append(
            {
                "number": n["number"],
                "title": n["title"],
                "url": n["url"],
                "updated_at": updated_at_str,
                "category": (n.get("category") or {}).get("name", ""),
            }
        )
    return out


async def list_milestones_with_progress(
    token: str,
    owner: str,
    repo: str,
) -> list[dict]:
    """Return open Milestones with completion percentage.

    Each entry: {"title": str, "due_on": str | None,
                 "percent_complete": float}
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")

    query = """
    query($owner: String!, $repo: String!) {
      repository(owner: $owner, name: $repo) {
        milestones(first: 20, states: [OPEN]) {
          nodes {
            title
            dueOn
            progressPercentage
          }
        }
      }
    }
    """
    data = await _graphql(token, query, {"owner": owner, "repo": repo})
    repo_node = data.get("repository") or {}
    nodes = (repo_node.get("milestones") or {}).get("nodes") or []
    return [
        {
            "title": n["title"],
            "due_on": n.get("dueOn"),
            "percent_complete": float(n.get("progressPercentage") or 0.0),
        }
        for n in nodes
    ]


async def fetch_recover_context_bundle(
    token: str,
    owner: str,
    repo: str,
    toc_discussion_id: str,
    since_days: int = 7,
    issue_limit: int = 100,
    discussion_limit: int = 50,
    milestone_limit: int = 20,
) -> dict[str, Any]:
    """Fetch all four `recover_context` payloads in a single GraphQL round-trip (#181).

    Aliases the four reads (`tocDiscussion`, `openIssues`,
    `recentDiscussions`, `milestones`) under one query so the wall-time
    cost drops from N round-trips (sequential) or ~max-of-N
    (gather, #177) to one round-trip — typically ~100ms total.

    Returns a dict with the same per-list shapes the individual
    functions return:

      ``{
          "toc_body": str | None,
          "open_issues": list[dict],
          "recent_discussions": list[dict],
          "milestones": list[dict],
      }``

    The individual `list_*` and `fetch_project_toc_body` helpers stay
    available for callers other than `recover_context`.
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")
    if not toc_discussion_id.strip():
        raise ValueError("toc_discussion_id must not be empty.")
    if since_days < 1:
        raise ValueError("since_days must be positive.")
    for limit_name, limit_value in (
        ("issue_limit", issue_limit),
        ("discussion_limit", discussion_limit),
        ("milestone_limit", milestone_limit),
    ):
        if limit_value < 1 or limit_value > 100:
            raise ValueError(f"{limit_name} must be between 1 and 100.")

    query = """
    query($owner: String!, $repo: String!, $tocId: ID!,
          $issueLimit: Int!, $discussionLimit: Int!, $milestoneLimit: Int!) {
      tocDiscussion: node(id: $tocId) {
        ... on Discussion { body }
      }
      repository(owner: $owner, name: $repo) {
        openIssues: issues(
          states: [OPEN],
          first: $issueLimit,
          orderBy: {field: UPDATED_AT, direction: DESC}
        ) {
          nodes {
            number
            title
            url
            updatedAt
            labels(first: 20) { nodes { name } }
          }
        }
        recentDiscussions: discussions(
          first: $discussionLimit,
          orderBy: {field: UPDATED_AT, direction: DESC}
        ) {
          nodes {
            number
            title
            url
            updatedAt
            category { name }
          }
        }
        milestones(first: $milestoneLimit, states: [OPEN]) {
          nodes {
            title
            dueOn
            progressPercentage
          }
        }
      }
    }
    """
    data = await _graphql(
        token,
        query,
        {
            "owner": owner,
            "repo": repo,
            "tocId": toc_discussion_id,
            "issueLimit": issue_limit,
            "discussionLimit": discussion_limit,
            "milestoneLimit": milestone_limit,
        },
    )

    # toc_body — None if Discussion not found (best-effort; the handler
    # currently treats a missing TOC as a soft signal, not a hard error).
    toc_node = data.get("tocDiscussion") or {}
    toc_body = toc_node.get("body")

    repo_node = data.get("repository") or {}

    # Open issues — same shape as list_open_issues.
    issue_nodes = (repo_node.get("openIssues") or {}).get("nodes") or []
    open_issues = [
        {
            "number": n["number"],
            "title": n["title"],
            "url": n["url"],
            "updated_at": n["updatedAt"],
            "labels": [
                lb["name"] for lb in (n.get("labels") or {}).get("nodes") or []
            ],
        }
        for n in issue_nodes
    ]

    # Recent discussions — apply the same since_days filter as
    # list_recent_discussions (server returns ordered DESC by
    # updatedAt; filter client-side and bail on first stale entry).
    cutoff = datetime.now(timezone.utc) - timedelta(days=since_days)
    discussion_nodes = (repo_node.get("recentDiscussions") or {}).get("nodes") or []
    recent_discussions: list[dict] = []
    for n in discussion_nodes:
        updated_at_str = n["updatedAt"]
        try:
            updated_at = datetime.fromisoformat(
                updated_at_str.replace("Z", "+00:00")
            )
        except ValueError:
            updated_at = datetime.now(timezone.utc)
        if updated_at < cutoff:
            break
        recent_discussions.append(
            {
                "number": n["number"],
                "title": n["title"],
                "url": n["url"],
                "updated_at": updated_at_str,
                "category": (n.get("category") or {}).get("name", ""),
            }
        )

    # Milestones — same shape as list_milestones_with_progress.
    milestone_nodes = (repo_node.get("milestones") or {}).get("nodes") or []
    milestones = [
        {
            "title": n["title"],
            "due_on": n.get("dueOn"),
            "percent_complete": float(n.get("progressPercentage") or 0.0),
        }
        for n in milestone_nodes
    ]

    return {
        "toc_body": toc_body,
        "open_issues": open_issues,
        "recent_discussions": recent_discussions,
        "milestones": milestones,
    }


def _build_search_query(
    user_query: str,
    owner: str,
    repo: str,
    state: str,
    labels: list[str] | None,
    milestone: str | None,
) -> str:
    """Compose the GitHub search-syntax query string for `search_issues` (#236).

    Always scopes to `is:issue repo:<owner>/<repo>`. Appends user-provided
    text verbatim (the caller can include their own search operators —
    e.g. `in:body author:colliderwriter`). Then layers structured filters.
    """
    parts: list[str] = ["is:issue", f"repo:{owner}/{repo}"]
    if state != "all":
        parts.append(f"state:{state}")
    for label in labels or []:
        # Quote labels containing spaces — GitHub search syntax requires it.
        # Labels containing colons (`area:mcp`) don't need quotes; spaces do.
        if " " in label:
            parts.append(f'label:"{label}"')
        else:
            parts.append(f"label:{label}")
    if milestone is not None:
        parts.append(f'milestone:"{milestone}"')
    if user_query.strip():
        parts.append(user_query.strip())
    return " ".join(parts)


async def search_issues(
    token: str,
    user_query: str,
    owner: str,
    repo: str,
    state: str = "all",
    labels: list[str] | None = None,
    milestone: str | None = None,
    limit: int = 50,
) -> dict:
    """Search GitHub Issues via the GraphQL `search` query (#236).

    Wraps `gh search issues` semantics in shaped JSON output. The
    structured params are layered onto the user's free-text `user_query`
    to produce the final GitHub search-syntax string; the resolved
    string is included in the response so callers can debug their
    queries without a separate roundtrip.

    Returns:
      ``{"results": [SearchIssueHit dict, ...], "total_count": int,
         "query": "<resolved search query>"}``
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")
    if state not in ("open", "closed", "all"):
        raise ValueError(
            f"state must be 'open', 'closed', or 'all'; got: {state!r}"
        )
    if limit < 1 or limit > 100:
        raise ValueError("limit must be between 1 and 100.")

    query_string = _build_search_query(
        user_query=user_query,
        owner=owner,
        repo=repo,
        state=state,
        labels=labels,
        milestone=milestone,
    )

    gql = """
    query($q: String!, $first: Int!) {
      search(query: $q, type: ISSUE, first: $first) {
        issueCount
        nodes {
          ... on Issue {
            number
            title
            url
            state
            createdAt
            updatedAt
            labels(first: 20) { nodes { name } }
            milestone { title }
            repository { nameWithOwner }
          }
        }
      }
    }
    """
    data = await _graphql(
        token, gql, {"q": query_string, "first": limit}
    )
    search_node = data.get("search") or {}
    nodes = search_node.get("nodes") or []
    results: list[dict] = []
    for n in nodes:
        if not n:
            # Non-Issue nodes (PRs, etc.) come back as empty dicts when
            # the inline fragment doesn't match. Filter defensively.
            continue
        labels_list = [
            lab["name"]
            for lab in (n.get("labels") or {}).get("nodes") or []
        ]
        milestone_obj = n.get("milestone") or {}
        repo_obj = n.get("repository") or {}
        results.append(
            {
                "number": n["number"],
                "title": n["title"],
                "url": n["url"],
                "state": n["state"],
                "labels": labels_list,
                "milestone": milestone_obj.get("title") if milestone_obj else None,
                "repository": repo_obj.get("nameWithOwner", ""),
                "created_at": n["createdAt"],
                "updated_at": n["updatedAt"],
            }
        )
    return {
        "results": results,
        "total_count": int(search_node.get("issueCount", 0)),
        "query": query_string,
    }


async def get_milestone_by_title(
    token: str,
    owner: str,
    repo: str,
    title: str,
) -> dict | None:
    """Look up a milestone by exact-match title; return its state and open issues.

    Returns None when no milestone matches `title`. Otherwise:

    ``{"number": int, "title": str, "state": "OPEN"|"CLOSED",
       "open_issues": [{"number": int, "title": str, "url": str}, ...]}``

    Backing query for `validate_release`'s `milestone_closed` check (#107).
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")
    if not title.strip():
        raise ValueError("title must not be empty.")

    query = """
    query($owner: String!, $repo: String!) {
      repository(owner: $owner, name: $repo) {
        milestones(first: 50, states: [OPEN, CLOSED]) {
          nodes {
            number
            title
            state
            issues(first: 100, states: [OPEN]) {
              nodes { number title url }
            }
          }
        }
      }
    }
    """
    data = await _graphql(token, query, {"owner": owner, "repo": repo})
    repo_node = data.get("repository") or {}
    nodes = (repo_node.get("milestones") or {}).get("nodes") or []
    for n in nodes:
        if n["title"] == title:
            open_issues = [
                {"number": i["number"], "title": i["title"], "url": i["url"]}
                for i in (n.get("issues") or {}).get("nodes") or []
            ]
            return {
                "number": n["number"],
                "title": n["title"],
                "state": n["state"],
                "open_issues": open_issues,
            }
    return None


# ----- TOC drift queries (#194) ---------------------------------------------

# Reasonable upper bound on what `open_session` will pull at startup.
# 20 pages × 100 = 2000 items per surface; far above the size at which
# a project's TOC remains operationally useful, well below GraphQL
# rate-limit concerns on a per-session-open call. Beyond this the
# helper truncates and the caller treats the result as advisory.
_DRIFT_MAX_PAGES = 20
_DRIFT_PAGE_SIZE = 100


async def list_all_issue_numbers(
    token: str,
    owner: str,
    repo: str,
) -> list[int]:
    """Return every Issue number in the repo (OPEN + CLOSED), paginated.

    Used by `open_session`'s TOC drift detection (#194) to enumerate
    the universe of issues against which the Project TOC body is
    compared. Caps at `_DRIFT_MAX_PAGES * _DRIFT_PAGE_SIZE` items;
    callers treat the result as advisory in projects beyond that scale.
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")

    query = """
    query($owner: String!, $repo: String!, $cursor: String) {
      repository(owner: $owner, name: $repo) {
        issues(
          states: [OPEN, CLOSED],
          first: 100,
          after: $cursor,
          orderBy: {field: CREATED_AT, direction: ASC}
        ) {
          pageInfo { hasNextPage endCursor }
          nodes { number }
        }
      }
    }
    """
    numbers: list[int] = []
    cursor: str | None = None
    for _ in range(_DRIFT_MAX_PAGES):
        data = await _graphql(
            token, query, {"owner": owner, "repo": repo, "cursor": cursor}
        )
        repo_node = data.get("repository") or {}
        issues = repo_node.get("issues") or {}
        nodes = issues.get("nodes") or []
        numbers.extend(int(n["number"]) for n in nodes)
        page_info = issues.get("pageInfo") or {}
        if not page_info.get("hasNextPage"):
            break
        cursor = page_info.get("endCursor")
    return numbers


async def list_all_discussion_numbers(
    token: str,
    owner: str,
    repo: str,
) -> list[int]:
    """Return every Discussion number in the repo, paginated.

    Companion to `list_all_issue_numbers`; same semantics around
    pagination cap.
    """
    if not owner.strip() or not repo.strip():
        raise ValueError("owner and repo must not be empty.")

    query = """
    query($owner: String!, $repo: String!, $cursor: String) {
      repository(owner: $owner, name: $repo) {
        discussions(
          first: 100,
          after: $cursor,
          orderBy: {field: CREATED_AT, direction: ASC}
        ) {
          pageInfo { hasNextPage endCursor }
          nodes { number }
        }
      }
    }
    """
    numbers: list[int] = []
    cursor: str | None = None
    for _ in range(_DRIFT_MAX_PAGES):
        data = await _graphql(
            token, query, {"owner": owner, "repo": repo, "cursor": cursor}
        )
        repo_node = data.get("repository") or {}
        discussions = repo_node.get("discussions") or {}
        nodes = discussions.get("nodes") or []
        numbers.extend(int(n["number"]) for n in nodes)
        page_info = discussions.get("pageInfo") or {}
        if not page_info.get("hasNextPage"):
            break
        cursor = page_info.get("endCursor")
    return numbers
