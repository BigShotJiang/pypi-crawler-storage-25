"""GitHub API operations, split by object type (#83).

Submodules:
  core         — _graphql, GitHubError, InvalidNodeIdError
  resolvers    — validate_node_id, get_repo_node_id, resolve_thread_id, get_file_content
  discussions  — create_discussion, add_discussion_comment, …
  issues       — create_issue, close_issue, get_label_id, …
  projects     — add_item_to_project, move_project_item, …
  recovery     — list_* read-only helpers
  scaffold     — get_organization_id, create_repository, create_label

Intentionally empty (no re-exports). Each call site imports directly
from the submodule it needs, so Bazel's per-py_library dep graph
matches the actual import graph — a test that only exercises Issues
doesn't drag Discussions, Projects, etc. into its dep closure.
"""
