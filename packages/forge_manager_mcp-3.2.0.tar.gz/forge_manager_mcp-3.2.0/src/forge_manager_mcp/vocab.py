"""Reserved vocabulary for forge-manager (3.0 / Phase 1b.3).

Defines the protocol's closed-taxonomy reserved label namespace and the
state-axis vocabulary. Open-set labels (everything outside these reserved
sets) flow through unchanged — adapters render them on each backend's
surface without translation.

Per Discussion #1 OQ1 (multi-dim state) + OQ2 (kind:* internal namespace
with bare-type-label presentation preserved on git ops + GitHub):

- ``KIND_LABELS`` is the internal vocabulary (`kind:bug`, `kind:rfc`,
  `kind:feature`, `kind:refactor`, `kind:chore`, `kind:discussion`,
  `kind:answer`). Adapters render these to bare-type form on backends
  that prefer it.
- ``CATEGORY_LABELS`` (`category:architecture`, `category:ideas`,
  `category:ux`) apply only to ``kind:discussion`` items, replacing
  pre-3.0 GitHub Discussion categories.
- State is multi-dimensional. Three orthogonal axes: lifecycle
  (open/closed/merged), decision (decided/<absent>), archive
  (archived/<absent>). An item can hold multiple axis values
  simultaneously (e.g., ``open + decided`` for a Discussion that
  reached resolution but stays in the open set as a reference).
"""
from __future__ import annotations

from typing import Final, Literal


# ---------------------------------------------------------------------------
# Reserved labels — closed taxonomy
# ---------------------------------------------------------------------------

KIND_LABELS: Final[frozenset[str]] = frozenset({
    "kind:bug",
    "kind:rfc",
    "kind:feature",
    "kind:refactor",
    "kind:chore",
    "kind:discussion",
    "kind:answer",
})
"""Type label for every Issue. Exactly one ``kind:*`` per item."""

KindLabel = Literal[
    "kind:bug",
    "kind:rfc",
    "kind:feature",
    "kind:refactor",
    "kind:chore",
    "kind:discussion",
    "kind:answer",
]


CATEGORY_LABELS: Final[frozenset[str]] = frozenset({
    "category:architecture",
    "category:ideas",
    "category:ux",
})
"""Discussion-category labels. Apply only to ``kind:discussion`` items."""

CategoryLabel = Literal[
    "category:architecture",
    "category:ideas",
    "category:ux",
]


BARE_TYPE_LABELS: Final[frozenset[str]] = frozenset({
    "bug",
    "rfc",
    "feature",
    "refactor",
    "chore",
})
"""Pre-3.0 bare-type-label presentation. Adapters render ``kind:*``
labels in this form on backends that prefer it (per OQ2 — preserves
GitHub's ``label:bug`` search ergonomics + existing tooling)."""


def kind_to_bare(kind_label: str) -> str:
    """Map a ``kind:*`` label to its bare presentation form.

    >>> kind_to_bare("kind:bug")
    'bug'
    >>> kind_to_bare("area:mcp")  # not a kind label; pass through
    'area:mcp'
    """
    if kind_label.startswith("kind:"):
        return kind_label[len("kind:"):]
    return kind_label


def bare_to_kind(bare_label: str) -> str:
    """Inverse of ``kind_to_bare``.

    >>> bare_to_kind("bug")
    'kind:bug'
    >>> bare_to_kind("area:mcp")  # not a bare type; pass through
    'area:mcp'
    """
    if bare_label in BARE_TYPE_LABELS:
        return f"kind:{bare_label}"
    return bare_label


# ---------------------------------------------------------------------------
# State axes — multi-dimensional per OQ1
# ---------------------------------------------------------------------------

LIFECYCLE_STATES: Final[frozenset[str]] = frozenset({
    "open", "closed", "merged",
})
"""Lifecycle axis. Mutually exclusive within axis (one of these per item).
``merged`` applies only to PRs; Issues use open/closed only."""


DECISION_STATES: Final[frozenset[str]] = frozenset({
    "decided",
})
"""Decision axis (presence-as-state). Absence = undecided."""


ARCHIVE_STATES: Final[frozenset[str]] = frozenset({
    "archived",
})
"""Archive axis (presence-as-state). Absence = active. Archived items
are excluded from default views."""


ALL_RESERVED_STATES: Final[frozenset[str]] = (
    LIFECYCLE_STATES | DECISION_STATES | ARCHIVE_STATES
)
"""Union of every state value the protocol pre-defines. Items may also
hold backend-specific state values (e.g., GitHub-specific lock states)
which adapters add as needed."""


def parse_state_file(content: str) -> set[str]:
    """Parse a multi-line ``state.txt`` body into a set of state values.

    Blank lines and ``#``-prefixed comments are ignored. Empty input
    yields an empty set.

    >>> sorted(parse_state_file("open\\ndecided\\n"))
    ['decided', 'open']
    >>> parse_state_file("")
    set()
    """
    states: set[str] = set()
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        states.add(stripped)
    return states


def render_state_file(states: set[str] | frozenset[str] | list[str]) -> str:
    """Render a state set/list as a multi-line ``state.txt`` body.

    Output is sorted by axis (lifecycle → decision → archive → other)
    for stable diffs across edits. Trailing newline included.

    >>> render_state_file({"decided", "open"})
    'open\\ndecided\\n'
    >>> render_state_file([])
    '\\n'
    """
    state_set = set(states)
    sorted_states = (
        sorted(s for s in state_set if s in LIFECYCLE_STATES)
        + sorted(s for s in state_set if s in DECISION_STATES)
        + sorted(s for s in state_set if s in ARCHIVE_STATES)
        + sorted(s for s in state_set if s not in ALL_RESERVED_STATES)
    )
    return "\n".join(sorted_states) + "\n"


# ---------------------------------------------------------------------------
# Predicates over state sets
# ---------------------------------------------------------------------------

def is_open(states: set[str] | frozenset[str]) -> bool:
    """Item is in the open lifecycle state."""
    return "open" in states


def is_closed(states: set[str] | frozenset[str]) -> bool:
    """Item is closed (lifecycle)."""
    return "closed" in states


def is_merged(states: set[str] | frozenset[str]) -> bool:
    """PR is merged (lifecycle)."""
    return "merged" in states


def is_decided(states: set[str] | frozenset[str]) -> bool:
    """Item has reached decided state (orthogonal to open/closed/merged)."""
    return "decided" in states


def is_archived(states: set[str] | frozenset[str]) -> bool:
    """Item is archived (excluded from default views)."""
    return "archived" in states
