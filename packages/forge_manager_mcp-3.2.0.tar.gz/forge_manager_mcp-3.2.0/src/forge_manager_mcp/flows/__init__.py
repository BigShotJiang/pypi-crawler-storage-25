"""Compensating-transaction interceptor flows (#294).

Per-flow modules implementing Discussion #3's three-effect interceptor
patterns for the project's most operationally-fraught orchestrators.
Each sub-package composes a chain of step interceptors that wrap the
existing imperative ``_run_*`` callables; the chain provides automatic
compensation on failure via per-step ``error`` handlers.

Sub-packages:

- :mod:`forge_manager_mcp.flows.release` — release_project chain
  (validate / dev_tag / mirror_sync / mirror_tag / release_notes /
  pypi_publish).
- :mod:`forge_manager_mcp.flows.migration` — migrate_to_3_0 chain
  (Phase B; lands in a follow-up commit per the staged #294 rollout).

Design contract: Discussion #3 (three-effect interceptor patterns
for compensating transactions in complex flows). Implementation does
not re-derive the design; if the design is unclear, the Discussion
is the source of truth.
"""
