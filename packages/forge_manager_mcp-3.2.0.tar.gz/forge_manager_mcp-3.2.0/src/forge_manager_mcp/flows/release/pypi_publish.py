"""Step ``pypi_publish`` for the release chain (#294 Phase A).

State-mutating step: ``python -m build`` + ``twine upload`` against
the PyPI Trusted Publisher binding for the project. PyPI releases
are **yankable but not deletable** — the canonical compensation is
a yank, which marks the release unavailable for new installs but
preserves history per PyPI policy.

Per Discussion #3 §"Yankable steps", pypi_publish's error handler
yanks the release then propagates the error so the operator sees
the original failure context. The yank itself is idempotent —
re-yanking an already-yanked release returns 200.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor

from .validate import ReleaseStepFailed


def make_pypi_publish_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        from ...server.handlers.release import _run_pypi_publish

        request = ctx.request
        server_ctx = request["server_ctx"]
        version = request["version"]
        repo_role = request["repo_role"]
        dry_run = request.get("dry_run", True)

        step = _run_pypi_publish(
            server_ctx.project_dir, version, repo_role, dry_run,
        )
        out_response = {**ctx.response, "pypi_publish": dict(step)}
        out_steps = ctx.steps_taken + (
            {
                "step": "pypi_publish",
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {"status": step["status"]},
            },
        )
        out = replace(ctx, response=out_response, steps_taken=out_steps)
        if step["status"] == "failed":
            return replace(
                out, error=ReleaseStepFailed("pypi_publish failed")
            )
        return out

    async def error(ctx: Context) -> Context:
        # Compensation: yank the release if it actually published.
        # twine has no native yank; PyPI's REST surface is the path,
        # but it requires the same token as upload. We surface as
        # failed_compensations for now — operator runs
        # `pip download <pkg>==<version>` to confirm publish state,
        # then yanks via the PyPI web UI or the REST API.
        recorded = ctx.response.get("pypi_publish", {})
        if recorded.get("status") != "ok":
            return ctx

        compensation_detail = {
            "step": "pypi_publish",
            "at": datetime.now(timezone.utc).isoformat(),
            "compensated": False,
            "detail": {
                "action": "manual",
                "reason": (
                    "PyPI yank requires the project's PyPI token + "
                    "the PyPI REST yank endpoint, which isn't yet on "
                    "the adapter surface. Operator action: log in to "
                    "PyPI, navigate to the project's release page, "
                    "and click 'Yank release'. Yank preserves history "
                    "but marks the release unavailable for new "
                    "installs — strictly better than leaving a "
                    "broken release reachable via the default "
                    "install path."
                ),
            },
        }
        failed = ctx.response.get("failed_compensations", ())
        return replace(
            ctx,
            response={
                **ctx.response,
                "failed_compensations": (
                    *failed,
                    {
                        "step": "pypi_publish",
                        "reason": compensation_detail["detail"]["reason"],
                    },
                ),
            },
            steps_taken=ctx.steps_taken + (compensation_detail,),
        )

    return Interceptor(
        enter=enter, error=error, name="release.pypi_publish",
    )
