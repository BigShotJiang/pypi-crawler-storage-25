"""Step ``validate`` for the release chain (#294 Phase A).

Read-only validator interceptor. Wraps the existing
``handlers.release._run_validate``. Per Discussion #3 §"Read-only
steps go first", validate runs before any state-mutating step so a
failure halts the chain before any state change.

Compensation: **no-op** — read-only step, nothing to undo.

ctx.request fields consumed:
- ``version`` (str)
- ``skip_bazel`` (bool)
- ``pypi_only`` (bool, default False)

ctx.response fields produced under ``validate``:
- ``status`` — "ok" / "failed"
- ``checks`` — full checks list
- ``repo_role`` — "skill" / "mcp" / "monorepo"
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor


class ReleaseStepFailed(Exception):
    """Raised by an enter handler to halt the chain on a step's
    canonical-failure mode (e.g. validate's ``status: failed``).

    The error handler chain unwinds; per-step compensations fire in
    reverse stack order. The exception is caught by the handler that
    invokes :func:`aexecute`; ``ctx.error`` carries it back so the
    handler can shape the final tool-response.
    """


def make_validate_interceptor() -> Interceptor:
    """Build the validate-step Interceptor (#294 Phase A)."""

    async def enter(ctx: Context) -> Context:
        # Lazy import to avoid the flows ↔ handlers circular dep at
        # module-load time. The handler module imports the flow chain
        # from server/build dispatch; the flow steps import
        # _run_validate at handler-call time.
        from ...server.handlers.release import _run_validate

        request = ctx.request
        server_ctx = request["server_ctx"]
        version = request["version"]
        skip_bazel = request.get("skip_bazel", False)
        pypi_only = request.get("pypi_only", False)

        step, checks, repo_role = await _run_validate(
            server_ctx, version, skip_bazel, pypi_only=pypi_only,
        )

        # response.validate carries the structured shape the handler
        # needs to compose the tool-response.
        new_response = {
            **ctx.response,
            "validate": {
                "status": step["status"],
                "checks": checks,
                "repo_role": repo_role,
                "step": step,
            },
        }
        new_steps = ctx.steps_taken + (
            {
                "step": "validate",
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {
                    "status": step["status"],
                    "repo_role": repo_role,
                },
            },
        )

        # Forward repo_role onto the request so subsequent steps can
        # consume it without re-detecting.
        new_request = {**request, "repo_role": repo_role}

        out = replace(
            ctx,
            request=new_request,
            response=new_response,
            steps_taken=new_steps,
        )
        if step["status"] == "failed":
            return replace(
                out,
                error=ReleaseStepFailed(
                    f"validate failed: "
                    f"{[c['name'] for c in checks if c['severity'] == 'fail' and not c['ok']]}"
                ),
            )
        return out

    async def error(ctx: Context) -> Context:
        # Read-only step — no compensation. Pass-through error.
        return ctx

    return Interceptor(enter=enter, error=error, name="release.validate")
