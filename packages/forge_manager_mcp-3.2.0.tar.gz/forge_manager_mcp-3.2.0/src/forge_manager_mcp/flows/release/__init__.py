"""release_project compensating-transaction interceptor chain (#294 Phase A).

Composes per-step interceptors into the release_chain; each step wraps
the existing ``_run_*`` callable in handlers/release.py. The handler-
side rewrite (release_project calling build_release_chain) lands in
a follow-up commit; #294 Phase A delivers the module structure +
per-step interceptors as parallel infrastructure that the existing
handler doesn't yet consume.

Per-step semantics per Discussion #3 §"Per-flow application table —
release_project":

============================ ======================== ==================================
Step                          Mode                     Compensation
============================ ======================== ==================================
validate                      read-only                no-op (state unchanged)
dev_tag                       state-mutating           delete-tag (idempotent)
mirror_sync                   state-mutating           force-push prior ref (idempotent)
mirror_tag                    state-mutating           delete-tag (idempotent)
release_notes                 state-mutating           delete-or-mark-draft
pypi_publish                  yankable                 yank + propagate
============================ ======================== ==================================

Read-only steps come first per Discussion #3 §"Read-only steps go
first" so failures during validation halt before any state change.

Chain composition is mode-aware:

- ``dry_run=True``: every step's enter checks ctx.request and returns
  a "would-have-done" response; compensation is a no-op.
- ``pypi_only=True``: chain is ``[validate, pypi_publish]`` only —
  every GitHub-coupled step is skipped.
- ``stop_after=<step>``: chain truncates after the named step.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from ...interceptors import Interceptor

from .validate import make_validate_interceptor
from .dev_tag import make_dev_tag_interceptor
from .mirror_sync import make_mirror_sync_interceptor
from .mirror_tag import make_mirror_tag_interceptor
from .release_notes import make_release_notes_interceptor
from .pypi_publish import make_pypi_publish_interceptor


_STEP_FACTORIES = {
    "validate": make_validate_interceptor,
    "dev_tag": make_dev_tag_interceptor,
    "mirror_sync": make_mirror_sync_interceptor,
    "mirror_tag": make_mirror_tag_interceptor,
    "release_notes": make_release_notes_interceptor,
    "pypi_publish": make_pypi_publish_interceptor,
}

_FULL_RELEASE_ORDER: tuple[str, ...] = (
    "validate",
    "dev_tag",
    "mirror_sync",
    "mirror_tag",
    "release_notes",
)

_POST_VALIDATE_ORDER: tuple[str, ...] = (
    "dev_tag",
    "mirror_sync",
    "mirror_tag",
    "release_notes",
)

_PYPI_ONLY_ORDER: tuple[str, ...] = ("validate", "pypi_publish")

_POST_VALIDATE_PYPI_ONLY: tuple[str, ...] = ("pypi_publish",)


def build_release_chain(
    *,
    pypi_only: bool = False,
    stop_after: str = "release_notes",
) -> list[Interceptor]:
    """Compose the release_chain per the configured mode (#294 Phase A).

    Returns the ordered list of step interceptors. Caller invokes via
    :func:`forge_manager_mcp.interceptors.aexecute`.

    ``pypi_only=True`` overrides ``stop_after`` — the pypi-direct path
    is always validate → pypi_publish.
    """
    if pypi_only:
        order = _PYPI_ONLY_ORDER
    else:
        order = _FULL_RELEASE_ORDER
        if stop_after in order:
            cutoff = order.index(stop_after) + 1
            order = order[:cutoff]
    return [_STEP_FACTORIES[name]() for name in order]


def build_post_validate_chain(
    *,
    pypi_only: bool = False,
    stop_after: str = "release_notes",
) -> list[Interceptor]:
    """Like :func:`build_release_chain` but skips ``validate`` (#294 Phase A).

    The handler runs ``_run_validate`` directly before this chain because
    the validate result drives version-bump propose-and-approve and
    CHANGELOG-auto-populate branches that don't fit the chain pattern
    (mid-flow re-validation, conditional handler-side mutation).

    ``mirror_tag`` is always paired with ``mirror_sync`` (no
    ``stop_after="mirror_tag"`` exists per the existing handler). When
    ``stop_after="release_notes"`` (the default) the full post-validate
    chain runs.
    """
    if pypi_only:
        order = _POST_VALIDATE_PYPI_ONLY
    else:
        order = _POST_VALIDATE_ORDER
        if stop_after in order:
            cutoff = order.index(stop_after) + 1
            order = order[:cutoff]
    return [_STEP_FACTORIES[name]() for name in order]


__all__ = ["build_release_chain", "build_post_validate_chain"]
