"""Step ``mirror_sync`` for the release chain (#294 Phase A).

State-mutating step: builds the curated squashed commit and force-
pushes to the public mirror. Compensation: force-push the prior ref
back (idempotent — if the mirror is already at the prior ref, no-op).

The prior-ref watermark must be captured by ``enter`` before the
push so ``error`` knows what to restore.

ctx.request fields consumed: ``version``, ``notes``, ``repo_role``
(threaded by validate), ``dry_run``.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor

from .validate import ReleaseStepFailed


def make_mirror_sync_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        from ...server.handlers.release import _run_mirror_sync

        request = ctx.request
        server_ctx = request["server_ctx"]
        version = request["version"]
        notes = request.get("notes", "")
        repo_role = request["repo_role"]
        dry_run = request.get("dry_run", True)

        step, mirror_clone = _run_mirror_sync(
            server_ctx, version, notes, repo_role, dry_run,
        )
        # Stash the mirror_clone path on the request so subsequent steps
        # (mirror_tag, release_notes) can reuse it without re-cloning.
        new_request = {**request, "mirror_clone": mirror_clone}

        out_response = {**ctx.response, "mirror_sync": dict(step)}
        out_steps = ctx.steps_taken + (
            {
                "step": "mirror_sync",
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {"status": step["status"]},
            },
        )
        out = replace(
            ctx,
            request=new_request,
            response=out_response,
            steps_taken=out_steps,
        )
        if step["status"] == "failed":
            return replace(
                out, error=ReleaseStepFailed("mirror_sync failed")
            )
        return out

    async def error(ctx: Context) -> Context:
        # Compensation: surface that mirror state may need manual
        # reconciliation. Force-push compensation requires capturing
        # the pre-push ref, which the current _run_mirror_sync doesn't
        # expose in its return shape — surface as failed_compensations
        # rather than silently losing the signal.
        recorded = ctx.response.get("mirror_sync", {})
        if recorded.get("status") != "ok":
            return ctx
        failed = ctx.response.get("failed_compensations", ())
        compensation_detail = {
            "step": "mirror_sync",
            "at": datetime.now(timezone.utc).isoformat(),
            "compensated": False,
            "detail": {
                "action": "manual",
                "reason": (
                    "mirror_sync compensation requires the pre-push "
                    "mirror ref; today _run_mirror_sync doesn't "
                    "capture it. Operator action: inspect mirror's "
                    "log, force-push the prior ref back, and remove "
                    "the squashed-release commit if appropriate."
                ),
            },
        }
        return replace(
            ctx,
            response={
                **ctx.response,
                "failed_compensations": (
                    *failed,
                    {
                        "step": "mirror_sync",
                        "reason": compensation_detail["detail"]["reason"],
                    },
                ),
            },
            steps_taken=ctx.steps_taken + (compensation_detail,),
        )

    return Interceptor(enter=enter, error=error, name="release.mirror_sync")
