"""Step ``mirror_tag`` for the release chain (#294 Phase A).

State-mutating step: tags the mirror at the squashed-release commit
and pushes the tag. Compensation: delete-tag (idempotent).
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor

from .validate import ReleaseStepFailed


def make_mirror_tag_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        from ...server.handlers.release import _run_mirror_tag

        request = ctx.request
        version = request["version"]
        notes = request.get("notes", "")
        mirror_clone = request.get("mirror_clone")
        dry_run = request.get("dry_run", True)

        # _run_mirror_tag signature: (mirror_clone, version, notes, dry_run)
        step = _run_mirror_tag(mirror_clone, version, notes, dry_run)
        out_response = {**ctx.response, "mirror_tag": dict(step)}
        out_steps = ctx.steps_taken + (
            {
                "step": "mirror_tag",
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {"status": step["status"]},
            },
        )
        out = replace(ctx, response=out_response, steps_taken=out_steps)
        if step["status"] == "failed":
            return replace(out, error=ReleaseStepFailed("mirror_tag failed"))
        return out

    async def error(ctx: Context) -> Context:
        from ...github import releases as releases_mod

        recorded = ctx.response.get("mirror_tag", {})
        if recorded.get("status") != "ok":
            return ctx
        tag = recorded.get("data", {}).get("tag")
        request = ctx.request
        mirror_clone = request.get("mirror_clone")
        if tag is None or mirror_clone is None:
            return ctx

        compensation_detail = {
            "step": "mirror_tag",
            "at": datetime.now(timezone.utc).isoformat(),
            "compensated": True,
            "detail": {"action": "delete_tag", "tag": tag},
        }
        try:
            # (#294 Phase A primitive) delete_tag idempotent — tolerates
            # already-deleted on both local and remote sides.
            releases_mod.delete_tag(mirror_clone, "origin", tag)
            return replace(
                ctx, steps_taken=ctx.steps_taken + (compensation_detail,)
            )
        except Exception as exc:  # noqa: BLE001
            failed = ctx.response.get("failed_compensations", ())
            return replace(
                ctx,
                response={
                    **ctx.response,
                    "failed_compensations": (
                        *failed,
                        {"step": "mirror_tag", "error": str(exc), "tag": tag},
                    ),
                },
                steps_taken=ctx.steps_taken + (compensation_detail,),
            )

    return Interceptor(enter=enter, error=error, name="release.mirror_tag")
