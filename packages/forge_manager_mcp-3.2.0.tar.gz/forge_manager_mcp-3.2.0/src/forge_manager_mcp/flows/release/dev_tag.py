"""Step ``dev_tag`` for the release chain (#294 Phase A).

State-mutating step: creates an annotated tag on the dev repo and
pushes to origin. Compensation: delete-tag (idempotent — tolerates
"tag doesn't exist" responses).

ctx.request fields consumed:
- ``version`` (str)
- ``notes`` (str — release-notes body for the tag annotation)
- ``dry_run`` (bool)

ctx.response fields produced under ``dev_tag``:
- ``status`` — "ok" / "dry_run_preview" / "failed"
- ``tag``, ``sha``, ``would_push``
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor

from .validate import ReleaseStepFailed


def make_dev_tag_interceptor() -> Interceptor:
    """Build the dev_tag-step Interceptor (#294 Phase A)."""

    async def enter(ctx: Context) -> Context:
        from ...server.handlers.release import _run_dev_tag

        request = ctx.request
        server_ctx = request["server_ctx"]
        version = request["version"]
        notes = request.get("notes", "")
        dry_run = request.get("dry_run", True)

        step = _run_dev_tag(server_ctx, version, notes, dry_run)
        out_response = {**ctx.response, "dev_tag": dict(step)}
        out_steps = ctx.steps_taken + (
            {
                "step": "dev_tag",
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {
                    "status": step["status"],
                    "tag": step.get("data", {}).get("tag", f"v{version}"),
                },
            },
        )
        out = replace(ctx, response=out_response, steps_taken=out_steps)
        if step["status"] == "failed":
            return replace(out, error=ReleaseStepFailed("dev_tag failed"))
        return out

    async def error(ctx: Context) -> Context:
        # Compensation: delete the dev tag if it was created. Read
        # the tag name from the step's recorded response so we only
        # attempt deletion of a tag this enter actually wrote.
        from ...github import releases as releases_mod

        recorded = ctx.response.get("dev_tag", {})
        if recorded.get("status") != "ok":
            # Either the step never ran successfully or it was a
            # dry-run preview — nothing to compensate.
            return ctx

        tag = recorded.get("data", {}).get("tag")
        request = ctx.request
        server_ctx = request.get("server_ctx")
        if tag is None or server_ctx is None:
            return ctx

        compensation_detail: dict = {
            "step": "dev_tag",
            "at": datetime.now(timezone.utc).isoformat(),
            "compensated": True,
            "detail": {"action": "delete_tag", "tag": tag},
        }
        try:
            # delete_tag is idempotent — tolerates already-deleted
            # locally and remotely. (#294 Phase A primitive.)
            releases_mod.delete_tag(
                server_ctx.project_dir, "origin", tag,
            )
            return replace(
                ctx, steps_taken=ctx.steps_taken + (compensation_detail,)
            )
        except Exception as exc:  # noqa: BLE001 — record + propagate
            failed = ctx.response.get("failed_compensations", ())
            compensation_detail["detail"]["error"] = str(exc)
            return replace(
                ctx,
                response={
                    **ctx.response,
                    "failed_compensations": (
                        *failed,
                        {"step": "dev_tag", "error": str(exc), "tag": tag},
                    ),
                },
                steps_taken=ctx.steps_taken + (compensation_detail,),
            )

    return Interceptor(enter=enter, error=error, name="release.dev_tag")
