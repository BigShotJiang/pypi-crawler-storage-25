"""Step ``bootstrap_docs_repo`` for the migration chain (#294 Phase B).

State-mutating: creates ``<project>-docs/`` adjacent to the dev repo
or adopts an existing docs repo. Compensation is **context-aware**:
delete the docs repo if migration created it; leave it alone if
migration adopted an existing one.

Adoption signal: the runner records ``manual_step_note`` on the
step's payload when ``ensure_local_docs_repo`` raises
``DocsRepoOriginConflict`` — the dir already existed with a
non-matching origin, and the runner left it in place.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor

from .backup_claude_dir import MigrationStepFailed
from .translate_schema import (
    _record_dry_run, _record_ok, _record_skip,
)


def make_bootstrap_docs_repo_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        from ...migration.runner import _execute_step

        request = ctx.request
        plan = request.get("plan")
        project_dir = request["project_dir"]
        apply = request.get("apply", False)
        if plan is None:
            return _record_skip(ctx, "bootstrap_docs_repo", "no plan")

        target_step = next(
            (s for s in plan.steps if s.kind == "bootstrap_docs_repo"),
            None,
        )
        if target_step is None:
            return _record_skip(
                ctx, "bootstrap_docs_repo", "no bootstrap_docs_repo step",
            )

        docs_path = target_step.payload.get("docs_path")
        existed_before = docs_path and (
            __import__("pathlib").Path(docs_path).exists()
        )

        detail = {
            "docs_path": str(docs_path) if docs_path else None,
            "existed_before": bool(existed_before),
        }
        if not apply:
            return _record_dry_run(ctx, "bootstrap_docs_repo", detail)

        try:
            _execute_step(project_dir, target_step)
        except Exception as exc:  # noqa: BLE001
            return replace(
                ctx,
                error=MigrationStepFailed(
                    f"bootstrap_docs_repo failed: {exc}"
                ),
            )
        # Surface the adoption signal if the runner recorded it.
        if "manual_step_note" in target_step.payload:
            detail["adopted_existing"] = True
            detail["manual_step_note"] = (
                target_step.payload["manual_step_note"]
            )
        return _record_ok(ctx, "bootstrap_docs_repo", detail)

    async def error(ctx: Context) -> Context:
        # Context-aware compensation: only delete if we created.
        import shutil
        from pathlib import Path

        recorded = ctx.response.get("bootstrap_docs_repo", {})
        if recorded.get("status") != "ok":
            return ctx
        if recorded.get("existed_before") or recorded.get("adopted_existing"):
            # We adopted; don't undo.
            compensation_detail = {
                "step": "bootstrap_docs_repo",
                "at": datetime.now(timezone.utc).isoformat(),
                "compensated": False,
                "detail": {
                    "action": "preserve",
                    "reason": (
                        "docs repo was adopted (pre-existed); not "
                        "deleting on rollback to avoid touching "
                        "operator-owned content."
                    ),
                },
            }
            return replace(
                ctx, steps_taken=ctx.steps_taken + (compensation_detail,)
            )

        # We created — remove the dir we made.
        docs_path = recorded.get("docs_path")
        if not docs_path:
            return ctx
        try:
            shutil.rmtree(Path(docs_path), ignore_errors=True)
            return replace(
                ctx,
                steps_taken=ctx.steps_taken + (
                    {
                        "step": "bootstrap_docs_repo",
                        "at": datetime.now(timezone.utc).isoformat(),
                        "compensated": True,
                        "detail": {"action": "delete_dir", "path": docs_path},
                    },
                ),
            )
        except Exception as exc:  # noqa: BLE001
            failed = ctx.response.get("failed_compensations", ())
            return replace(
                ctx,
                response={
                    **ctx.response,
                    "failed_compensations": (
                        *failed,
                        {
                            "step": "bootstrap_docs_repo",
                            "error": str(exc),
                            "path": docs_path,
                        },
                    ),
                },
            )

    return Interceptor(
        enter=enter, error=error, name="migration.bootstrap_docs_repo",
    )
