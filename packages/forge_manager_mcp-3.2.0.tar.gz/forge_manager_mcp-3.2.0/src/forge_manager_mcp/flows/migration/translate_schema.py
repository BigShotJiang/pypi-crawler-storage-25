"""Step ``translate_schema`` for the migration chain (#294 Phase B).

State-mutating: translates ``.claude/github-config.json`` (2.x) into
``.claude/forge-config.json`` (3.0). Compensation: no per-step undo
— restoration goes through the backup tarball preserved by the
backup_claude_dir step.

Note: the current runner combines schema translation with file
renaming via the ``translate_config_schema`` step kind. The per-step
interceptor here finds and executes that single step from the plan.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor

from .backup_claude_dir import MigrationStepFailed


def make_translate_schema_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        from ...migration.runner import _execute_step

        request = ctx.request
        plan = request.get("plan")
        project_dir = request["project_dir"]
        apply = request.get("apply", False)
        if plan is None:
            # No plan — detect_legacy_state didn't run. Treat as no-op.
            return _record_skip(ctx, "translate_schema", "no plan")

        # Find the translate_config_schema step kind in the plan.
        target_step = next(
            (s for s in plan.steps if s.kind == "translate_config_schema"),
            None,
        )
        if target_step is None:
            return _record_skip(
                ctx, "translate_schema", "no translate_config_schema step",
            )

        if not apply:
            return _record_dry_run(
                ctx, "translate_schema",
                {"source": str(target_step.source),
                 "target": str(target_step.target)},
            )

        try:
            _execute_step(project_dir, target_step)
        except Exception as exc:  # noqa: BLE001
            return replace(
                ctx,
                error=MigrationStepFailed(f"translate_schema failed: {exc}"),
            )

        return _record_ok(
            ctx, "translate_schema",
            {"source": str(target_step.source),
             "target": str(target_step.target)},
        )

    async def error(ctx: Context) -> Context:
        # Per-step compensation goes through the backup tarball.
        return _record_backup_compensation(ctx, "translate_schema")

    return Interceptor(
        enter=enter, error=error, name="migration.translate_schema",
    )


# ---------------------------------------------------------------------------
# Shared helpers — small enough to inline; kept here rather than promoting to
# a flows/migration/_helpers module since these are migration-step-specific.
# ---------------------------------------------------------------------------

def _record_ok(ctx: Context, step_name: str, detail: dict) -> Context:
    return replace(
        ctx,
        response={**ctx.response, step_name: {"status": "ok", **detail}},
        steps_taken=ctx.steps_taken + (
            {
                "step": step_name,
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": detail,
            },
        ),
    )


def _record_dry_run(ctx: Context, step_name: str, detail: dict) -> Context:
    return replace(
        ctx,
        response={
            **ctx.response,
            step_name: {"status": "dry_run_preview", **detail},
        },
        steps_taken=ctx.steps_taken + (
            {
                "step": step_name,
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {"status": "dry_run_preview", **detail},
            },
        ),
    )


def _record_skip(ctx: Context, step_name: str, reason: str) -> Context:
    return replace(
        ctx,
        response={
            **ctx.response,
            step_name: {"status": "skipped", "reason": reason},
        },
        steps_taken=ctx.steps_taken + (
            {
                "step": step_name,
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {"status": "skipped", "reason": reason},
            },
        ),
    )


def _record_backup_compensation(ctx: Context, step_name: str) -> Context:
    """For state-mutating migration steps, per-step compensation
    delegates to the backup tarball preserved by backup_claude_dir.
    Surface a steps_taken entry naming the recovery path."""
    recorded = ctx.response.get(step_name, {})
    if recorded.get("status") != "ok":
        return ctx
    compensation_detail = {
        "step": step_name,
        "at": datetime.now(timezone.utc).isoformat(),
        "compensated": False,  # backup is preserved, not auto-restored
        "detail": {
            "action": "delegate_to_backup",
            "rollback_path": (
                "Operator action: call "
                "migrate_to_3_0_rollback(backup_path=...) using the "
                "backup_path recorded in response.backup_claude_dir."
            ),
        },
    }
    return replace(
        ctx, steps_taken=ctx.steps_taken + (compensation_detail,)
    )
