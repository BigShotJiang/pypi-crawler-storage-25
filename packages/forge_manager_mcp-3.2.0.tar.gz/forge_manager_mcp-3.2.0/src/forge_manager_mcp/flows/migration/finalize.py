"""Step ``finalize`` for the migration chain (#294 Phase B).

Success marker. The actual cleanup work (delete backup tarball)
happens in ``backup_claude_dir.leave`` per the RAII pattern; this
step just records the migration's overall completion in the response
+ steps_taken.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor


def make_finalize_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        # Compute summary of the chain's progress so the handler doesn't
        # have to re-walk ctx.response.
        completed_steps = [
            key for key, val in ctx.response.items()
            if isinstance(val, dict) and val.get("status") == "ok"
        ]
        skipped_steps = [
            key for key, val in ctx.response.items()
            if isinstance(val, dict) and val.get("status") == "skipped"
        ]
        new_response = {
            **ctx.response,
            "finalize": {
                "status": "ok",
                "completed_steps": completed_steps,
                "skipped_steps": skipped_steps,
            },
        }
        new_steps = ctx.steps_taken + (
            {
                "step": "finalize",
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {
                    "completed": len(completed_steps),
                    "skipped": len(skipped_steps),
                },
            },
        )
        return replace(ctx, response=new_response, steps_taken=new_steps)

    async def error(ctx: Context) -> Context:
        # If the chain reached finalize at all, an upstream step had
        # already set ctx.error during forward traversal. finalize's
        # error is a pass-through.
        return ctx

    return Interceptor(
        enter=enter, error=error, name="migration.finalize",
    )
