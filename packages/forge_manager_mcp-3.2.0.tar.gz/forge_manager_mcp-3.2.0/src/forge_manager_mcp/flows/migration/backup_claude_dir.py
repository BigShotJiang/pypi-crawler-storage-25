"""Step ``backup_claude_dir`` for the migration chain (#294 Phase B).

RAII safety net — creates a tarball backup of ``.claude/`` before
any state-mutating step runs. ``leave`` (success path) deletes the
backup once the chain completes successfully; ``error`` preserves
the backup so the operator can call ``migrate_to_3_0_rollback`` to
restore from it.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor


class MigrationStepFailed(Exception):
    """Halt the migration chain; per-step compensations fire on unwind."""


def make_backup_claude_dir_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        from ...migration.runner import _create_backup

        request = ctx.request
        project_dir = request["project_dir"]
        apply = request.get("apply", False)

        if not apply:
            # Dry-run: surface "would have backed up" without writing.
            new_response = {
                **ctx.response,
                "backup_claude_dir": {
                    "status": "dry_run_preview",
                    "would_create_backup": True,
                },
            }
            new_steps = ctx.steps_taken + (
                {
                    "step": "backup_claude_dir",
                    "at": datetime.now(timezone.utc).isoformat(),
                    "detail": {"status": "dry_run_preview"},
                },
            )
            return replace(ctx, response=new_response, steps_taken=new_steps)

        try:
            backup_path = _create_backup(project_dir)
        except Exception as exc:  # noqa: BLE001
            return replace(
                ctx, error=MigrationStepFailed(f"backup failed: {exc}")
            )

        new_request = {**request, "backup_path": backup_path}
        new_response = {
            **ctx.response,
            "backup_claude_dir": {
                "status": "ok",
                "backup_path": str(backup_path),
            },
        }
        new_steps = ctx.steps_taken + (
            {
                "step": "backup_claude_dir",
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {"backup_path": str(backup_path)},
            },
        )
        return replace(
            ctx,
            request=new_request,
            response=new_response,
            steps_taken=new_steps,
        )

    async def leave(ctx: Context) -> Context:
        # RAII: success path — delete the backup. The migration is
        # known-good at this point so the operator doesn't need it.
        # Per Discussion #3 OQ-B / OQ-C, keep the backup if any
        # failed_compensations entries appeared along the way; the
        # operator may want it for reconciliation.
        import shutil

        recorded = ctx.response.get("backup_claude_dir", {})
        backup_path = recorded.get("backup_path")
        if not backup_path:
            return ctx
        if ctx.response.get("failed_compensations"):
            # Keep the backup as a safety net for the operator.
            return ctx
        try:
            from pathlib import Path
            shutil.rmtree(Path(backup_path), ignore_errors=True)
        except Exception:  # noqa: BLE001
            # Best-effort cleanup; don't fail the chain on cleanup
            # errors — the backup will accumulate but the migration
            # itself is already complete.
            pass
        return ctx

    async def error(ctx: Context) -> Context:
        # Error path: preserve the backup; surface its location in the
        # response so the operator can call migrate_to_3_0_rollback.
        recorded = ctx.response.get("backup_claude_dir", {})
        backup_path = recorded.get("backup_path")
        if not backup_path:
            return ctx
        compensation_detail = {
            "step": "backup_claude_dir",
            "at": datetime.now(timezone.utc).isoformat(),
            "compensated": False,  # backup is preserved, not undone
            "detail": {
                "action": "preserve_backup",
                "backup_path": backup_path,
                "rollback_command": (
                    f"migrate_to_3_0_rollback(backup_path={backup_path!r})"
                ),
            },
        }
        return replace(
            ctx, steps_taken=ctx.steps_taken + (compensation_detail,)
        )

    return Interceptor(
        enter=enter, leave=leave, error=error,
        name="migration.backup_claude_dir",
    )
