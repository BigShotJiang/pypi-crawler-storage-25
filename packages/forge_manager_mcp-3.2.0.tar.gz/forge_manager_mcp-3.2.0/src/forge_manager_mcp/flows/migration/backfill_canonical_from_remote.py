"""Step ``backfill_canonical_from_remote`` for the migration chain (#294 Phase B).

State-mutating but **user data** — calls
``ReplicationManager.import_remote_changes`` (#279) to populate the
canonical local store with pre-migration history from a remote
backend. Compensation is **pass-through** per Discussion #3 §"Don't
undo user data" — once imported, the records belong to the operator
and shouldn't be deleted on a flow-level rollback.

Pre-#279 this step was a no-op stub. Post-#279, the actual backfill
runs when the chain receives ``backfill_since`` + ``backfill_remote``
in ctx.request. Today the underlying ReplicationManager call still
hits NotImplementedError on GitHub (live impl deferred per memory)
but the chain wiring is in place — when GitHub access returns, the
step lights up automatically.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor


def make_backfill_canonical_from_remote_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        request = ctx.request
        backfill_since = request.get("backfill_since")
        backfill_remote = request.get("backfill_remote")
        replication = request.get("replication")
        apply = request.get("apply", False)

        if backfill_since is None:
            # Default: skip backfill (greenfield migration).
            return _record(
                ctx, "skipped",
                {"reason": "no backfill_since requested"},
            )
        if not apply:
            return _record(
                ctx, "dry_run_preview",
                {
                    "since": str(backfill_since),
                    "remote": backfill_remote,
                },
            )
        if replication is None:
            return _record(
                ctx, "skipped",
                {"reason": "no ReplicationManager available"},
            )

        try:
            report = await replication.import_remote_changes(
                since=backfill_since, source_platform_id=backfill_remote,
            )
        except NotImplementedError as exc:
            # The remote adapter doesn't implement fetch_remote_changes
            # yet. Surface as a manual_step rather than failing the
            # whole migration — the canonical store starts empty and
            # the operator runs backfill later via direct
            # import_remote_changes once the backend supports it.
            return _record(
                ctx, "deferred",
                {
                    "reason": (
                        f"backend doesn't support fetch_remote_changes "
                        f"yet: {exc}"
                    ),
                },
            )
        except Exception as exc:  # noqa: BLE001
            # Don't halt migration — pass-through, surface degradation.
            return _record(
                ctx, "degraded",
                {"error": str(exc)},
            )

        return _record(
            ctx, "ok",
            {
                "imported": len(report.applied),
                "conflicts": len(report.conflicts),
                "skipped": len(report.skipped),
            },
        )

    async def error(ctx: Context) -> Context:
        # Pass-through — imported user data isn't undone on chain
        # rollback. Surface the policy in steps_taken.
        recorded = ctx.response.get(
            "backfill_canonical_from_remote", {}
        )
        if recorded.get("status") not in ("ok", "degraded"):
            return ctx
        compensation_detail = {
            "step": "backfill_canonical_from_remote",
            "at": datetime.now(timezone.utc).isoformat(),
            "compensated": False,
            "detail": {
                "action": "passthrough",
                "reason": (
                    "Imported records are user data; not undone on "
                    "chain rollback. Operator can manually inspect / "
                    "delete entries from the canonical store if "
                    "desired."
                ),
            },
        }
        return replace(
            ctx, steps_taken=ctx.steps_taken + (compensation_detail,)
        )

    return Interceptor(
        enter=enter, error=error,
        name="migration.backfill_canonical_from_remote",
    )


def _record(ctx: Context, status: str, detail: dict) -> Context:
    return replace(
        ctx,
        response={
            **ctx.response,
            "backfill_canonical_from_remote": {
                "status": status,
                **detail,
            },
        },
        steps_taken=ctx.steps_taken + (
            {
                "step": "backfill_canonical_from_remote",
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {"status": status, **detail},
            },
        ),
    )
