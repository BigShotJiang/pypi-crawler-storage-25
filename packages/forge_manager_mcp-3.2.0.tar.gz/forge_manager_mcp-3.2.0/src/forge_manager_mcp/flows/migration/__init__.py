"""migrate_to_3_0 compensating-transaction interceptor chain (#294 Phase B).

Mirrors the Phase A pattern (forge_manager_mcp.flows.release): each
step wraps the existing migration runner / detector primitives via
lazy import; the chain composer assembles them in canonical order.
The handler-side rewire (migrate_to_3_0 calling build_migration_chain)
is **not** in this commit — it's a clean follow-up that keeps the
existing migration-handler tests as the regression boundary.

Per-step semantics per Discussion #3 §"Per-flow application table —
migrate_to_3_0":

================================ ============================== =====================================
Step                              Mode                           Compensation
================================ ============================== =====================================
backup_claude_dir                 RAII safety net                leave deletes on full success;
                                                                 error preserves backup for rollback
detect_legacy_state               read-only                      pass-through (no state to undo)
translate_schema                  state-mutating                 restore from backup
rename_skill_dir                  state-mutating                 reverse-rename
bootstrap_docs_repo               state-mutating                 context-aware (created vs adopted)
rewrite_claude_md                 state-mutating                 restore from backup
backfill_canonical_from_remote    state-mutating (user data)     pass-through; don't undo user data
finalize                          success marker                 no-op
================================ ============================== =====================================

Read-only step (detect_legacy_state) goes after the RAII backup so
the backup is in place before any inspection that might mutate the
filesystem (today detect_legacy_state is purely read-only, but the
RAII-first ordering keeps the contract robust for future detector
extensions that read+write probe files).

The chain delegates to the existing ``migration.runner._execute_step``
dispatcher for the four state-mutating runner steps; per-step
compensation is bounded by the ``rollback_plan`` semantics — for
the bulk of compensations, the operator-callable
``migrate_to_3_0_rollback`` (which restores from the backup tarball)
is the last-resort path. Per-step compensations layered on top
narrow the rollback blast radius from "restore everything" to
"reverse just this step."
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from ...interceptors import Interceptor

from .backup_claude_dir import make_backup_claude_dir_interceptor
from .detect_legacy_state import make_detect_legacy_state_interceptor
from .translate_schema import make_translate_schema_interceptor
from .rename_skill_dir import make_rename_skill_dir_interceptor
from .bootstrap_docs_repo import make_bootstrap_docs_repo_interceptor
from .rewrite_claude_md import make_rewrite_claude_md_interceptor
from .backfill_canonical_from_remote import (
    make_backfill_canonical_from_remote_interceptor,
)
from .finalize import make_finalize_interceptor


_STEP_FACTORIES = {
    "backup_claude_dir": make_backup_claude_dir_interceptor,
    "detect_legacy_state": make_detect_legacy_state_interceptor,
    "translate_schema": make_translate_schema_interceptor,
    "rename_skill_dir": make_rename_skill_dir_interceptor,
    "bootstrap_docs_repo": make_bootstrap_docs_repo_interceptor,
    "rewrite_claude_md": make_rewrite_claude_md_interceptor,
    "backfill_canonical_from_remote":
        make_backfill_canonical_from_remote_interceptor,
    "finalize": make_finalize_interceptor,
}

_FULL_MIGRATION_ORDER: tuple[str, ...] = (
    "backup_claude_dir",
    "detect_legacy_state",
    "translate_schema",
    "rename_skill_dir",
    "bootstrap_docs_repo",
    "rewrite_claude_md",
    "backfill_canonical_from_remote",
    "finalize",
)


def build_migration_chain(
    *,
    apply: bool = False,
    include_backfill: bool = True,
) -> list[Interceptor]:
    """Compose the migration chain (#294 Phase B).

    ``apply=False`` (dry-run) → every step's enter checks
    ``ctx.request['apply']`` and returns a "would-have-done" response
    without mutating state; compensation is no-op. ``apply=True``
    runs the real flow.

    ``include_backfill=False`` skips the backfill step — useful for
    greenfield 2.x → 3.0 migrations where there's no remote history
    to backfill, or when the operator runs migration first and
    backfill later as a separate ``import_remote_changes`` call.
    """
    order = list(_FULL_MIGRATION_ORDER)
    if not include_backfill:
        order = [s for s in order if s != "backfill_canonical_from_remote"]
    return [_STEP_FACTORIES[name]() for name in order]


__all__ = ["build_migration_chain"]
