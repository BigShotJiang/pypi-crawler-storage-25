"""Step ``detect_legacy_state`` for the migration chain (#294 Phase B).

Read-only inspection of the project's ``.claude/`` directory to
build the MigrationPlan. Pass-through compensation — nothing to
undo on a read.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor

from .backup_claude_dir import MigrationStepFailed


def make_detect_legacy_state_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        from ...migration.detector import detect_legacy_state

        request = ctx.request
        project_dir = request["project_dir"]
        try:
            plan = detect_legacy_state(project_dir)
        except Exception as exc:  # noqa: BLE001
            return replace(
                ctx,
                error=MigrationStepFailed(f"detect_legacy_state failed: {exc}"),
            )

        # Stash the plan on the request so subsequent steps can read
        # it; expose summary fields on the response for the handler.
        new_request = {**request, "plan": plan}
        new_response = {
            **ctx.response,
            "detect_legacy_state": {
                "status": "ok",
                "step_count": len(plan.steps),
                "warnings": list(plan.warnings),
                "step_kinds": [s.kind for s in plan.steps],
            },
        }
        new_steps = ctx.steps_taken + (
            {
                "step": "detect_legacy_state",
                "at": datetime.now(timezone.utc).isoformat(),
                "detail": {"step_count": len(plan.steps)},
            },
        )
        return replace(
            ctx,
            request=new_request,
            response=new_response,
            steps_taken=new_steps,
        )

    async def error(ctx: Context) -> Context:
        # Read-only — pass-through.
        return ctx

    return Interceptor(
        enter=enter, error=error, name="migration.detect_legacy_state",
    )
