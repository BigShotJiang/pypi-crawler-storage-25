"""Step ``rewrite_claude_md`` for the migration chain (#294 Phase B).

State-mutating: rewrites CLAUDE.md to replace ``active-claude-github``
mentions with ``forge-manager``. Compensation goes through the
backup tarball.
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor

from .backup_claude_dir import MigrationStepFailed
from .translate_schema import (
    _record_backup_compensation, _record_dry_run, _record_ok, _record_skip,
)


def make_rewrite_claude_md_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        from ...migration.runner import _execute_step

        request = ctx.request
        plan = request.get("plan")
        project_dir = request["project_dir"]
        apply = request.get("apply", False)
        if plan is None:
            return _record_skip(ctx, "rewrite_claude_md", "no plan")

        target_step = next(
            (s for s in plan.steps if s.kind == "update_claude_md"),
            None,
        )
        if target_step is None:
            return _record_skip(
                ctx, "rewrite_claude_md", "no update_claude_md step",
            )

        detail = {"target": str(target_step.target)}
        if not apply:
            return _record_dry_run(ctx, "rewrite_claude_md", detail)

        try:
            _execute_step(project_dir, target_step)
        except Exception as exc:  # noqa: BLE001
            return replace(
                ctx,
                error=MigrationStepFailed(
                    f"rewrite_claude_md failed: {exc}"
                ),
            )
        return _record_ok(ctx, "rewrite_claude_md", detail)

    async def error(ctx: Context) -> Context:
        return _record_backup_compensation(ctx, "rewrite_claude_md")

    return Interceptor(
        enter=enter, error=error, name="migration.rewrite_claude_md",
    )
