"""Step ``rename_skill_dir`` for the migration chain (#294 Phase B).

State-mutating: renames ``.claude/skills/active-claude-github/`` to
``.claude/skills/forge-manager/``. Compensation: reverse-rename
(idempotent — tolerates target already existing).
"""
from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

from ...interceptors import Context, Interceptor

from .backup_claude_dir import MigrationStepFailed
from .translate_schema import (
    _record_dry_run, _record_ok, _record_skip,
)


def make_rename_skill_dir_interceptor() -> Interceptor:

    async def enter(ctx: Context) -> Context:
        from ...migration.runner import _execute_step

        request = ctx.request
        plan = request.get("plan")
        project_dir = request["project_dir"]
        apply = request.get("apply", False)
        if plan is None:
            return _record_skip(ctx, "rename_skill_dir", "no plan")

        target_step = next(
            (s for s in plan.steps if s.kind == "rename_skill_dir"),
            None,
        )
        if target_step is None:
            return _record_skip(
                ctx, "rename_skill_dir", "no rename_skill_dir step",
            )

        detail = {
            "source": str(target_step.source),
            "target": str(target_step.target),
        }
        if not apply:
            return _record_dry_run(ctx, "rename_skill_dir", detail)

        try:
            _execute_step(project_dir, target_step)
        except Exception as exc:  # noqa: BLE001
            return replace(
                ctx,
                error=MigrationStepFailed(f"rename_skill_dir failed: {exc}"),
            )
        return _record_ok(ctx, "rename_skill_dir", detail)

    async def error(ctx: Context) -> Context:
        # Per-step compensation: reverse-rename if the rename succeeded.
        recorded = ctx.response.get("rename_skill_dir", {})
        if recorded.get("status") != "ok":
            return ctx
        from pathlib import Path

        source = recorded.get("source")
        target = recorded.get("target")
        request = ctx.request
        project_dir = request.get("project_dir")
        if not source or not target or project_dir is None:
            return ctx

        compensation_detail = {
            "step": "rename_skill_dir",
            "at": datetime.now(timezone.utc).isoformat(),
            "compensated": True,
            "detail": {
                "action": "reverse_rename",
                "from": target,
                "to": source,
            },
        }
        try:
            tgt = Path(project_dir) / target
            src = Path(project_dir) / source
            if tgt.exists() and not src.exists():
                tgt.rename(src)
            return replace(
                ctx, steps_taken=ctx.steps_taken + (compensation_detail,)
            )
        except Exception as exc:  # noqa: BLE001
            failed = ctx.response.get("failed_compensations", ())
            return replace(
                ctx,
                response={
                    **ctx.response,
                    "failed_compensations": (
                        *failed,
                        {
                            "step": "rename_skill_dir",
                            "error": str(exc),
                            "from": target,
                            "to": source,
                        },
                    ),
                },
                steps_taken=ctx.steps_taken + (compensation_detail,),
            )

    return Interceptor(
        enter=enter, error=error, name="migration.rename_skill_dir",
    )
