"""Tests for the shared ``default_bundle_recover_context`` helper
(adapters/_recovery.py).

Covers the parallel-fan-out + TOC-error-suppression contract that
PAR-5 added on top of the original Phase C5 default. The shape is
verified against a stub adapter; integration tests against real
backends live in tests/conformance/.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from forge_manager_mcp.adapters import errors as _errors
from forge_manager_mcp.adapters._recovery import default_bundle_recover_context
from forge_manager_mcp.adapters.types import (
    ArtifactRef, Discussion, Issue, Milestone,
)


def _stub_issue(number: int = 1) -> Issue:
    return Issue(
        ref=ArtifactRef(
            platform_id="stub", native_id=f"I_{number}",
            kind="issue", owner="o", repo="r", number=number,
        ),
        title="t", body="b", state="open", labels=[],
        url=f"https://example/{number}",
    )


def _stub_discussion(number: int = 1) -> Discussion:
    return Discussion(
        ref=ArtifactRef(
            platform_id="stub", native_id=f"D_{number}",
            kind="discussion", owner="o", repo="r", number=number,
        ),
        title="t", body="b", state="open", labels=[],
        url=f"https://example/d/{number}",
        created_at=datetime.now(timezone.utc),
    )


def _make_adapter_stub(
    *,
    open_issues: list[Issue] | None = None,
    recent_discussions: list[Discussion] | None = None,
    milestones: list[Milestone] | None = None,
    toc_body_returns: str | Exception = "TOC body content",
):
    """Mock adapter exposing the four read methods the helper hits."""
    ns = SimpleNamespace(platform_id="stub")
    ns.list_open_issues = AsyncMock(
        return_value=open_issues if open_issues is not None else [_stub_issue(1)],
    )
    ns.list_recent_discussions = AsyncMock(
        return_value=(
            recent_discussions if recent_discussions is not None
            else [_stub_discussion(2)]
        ),
    )
    ns.list_milestones = AsyncMock(
        return_value=(
            milestones if milestones is not None
            else [Milestone(title="3.0.1", number=1, state="open")]
        ),
    )
    if isinstance(toc_body_returns, Exception):
        ns.get_discussion_body = AsyncMock(side_effect=toc_body_returns)
    else:
        ns.get_discussion_body = AsyncMock(return_value=toc_body_returns)
    return ns


class TestDefaultBundleRecoverContext:
    @pytest.mark.asyncio
    async def test_assembles_full_bundle_on_happy_path(self):
        adapter = _make_adapter_stub()
        bundle = await default_bundle_recover_context(
            adapter,
            owner="o", repo="r", toc_discussion_id="D_toc",
        )
        assert bundle.toc_body == "TOC body content"
        assert len(bundle.open_issues) == 1
        assert len(bundle.recent_discussions) == 1
        assert len(bundle.milestones) == 1

    @pytest.mark.asyncio
    async def test_toc_forge_error_returns_none_body(self):
        """ForgeError on the TOC fetch must NOT poison the rest of the
        bundle — ``toc_body`` becomes ``None`` and the other three
        legs return their values."""
        adapter = _make_adapter_stub(
            toc_body_returns=_errors.ForgeError("toc unreachable"),
        )
        bundle = await default_bundle_recover_context(
            adapter,
            owner="o", repo="r", toc_discussion_id="D_toc",
        )
        assert bundle.toc_body is None
        # Other legs unaffected.
        assert len(bundle.open_issues) == 1

    @pytest.mark.asyncio
    async def test_non_forge_error_propagates(self):
        """A bug in the adapter (e.g., AttributeError) shouldn't be
        silently swallowed — only ForgeError represents the
        "remote degraded but session usable" case."""
        adapter = _make_adapter_stub(
            toc_body_returns=AttributeError("bad ref"),
        )
        with pytest.raises(AttributeError):
            await default_bundle_recover_context(
                adapter,
                owner="o", repo="r", toc_discussion_id="D_toc",
            )

    @pytest.mark.asyncio
    async def test_legs_run_concurrently(self):
        """PAR-5: the four reads should fan out via asyncio.gather, so
        a slow leg doesn't serialize the others. Use deterministic
        ordering of started-events to verify all four launch before
        any complete."""
        started: list[str] = []

        async def slow_open_issues(**kwargs):
            started.append("open_issues")
            await asyncio.sleep(0)  # yield
            return []

        async def slow_recent_discussions(**kwargs):
            started.append("recent_discussions")
            await asyncio.sleep(0)
            return []

        async def slow_milestones(*args, **kwargs):
            started.append("milestones")
            await asyncio.sleep(0)
            return []

        async def slow_toc(_ref):
            started.append("toc")
            await asyncio.sleep(0)
            return "body"

        adapter = SimpleNamespace(
            platform_id="stub",
            list_open_issues=slow_open_issues,
            list_recent_discussions=slow_recent_discussions,
            list_milestones=slow_milestones,
            get_discussion_body=slow_toc,
        )

        await default_bundle_recover_context(
            adapter,
            owner="o", repo="r", toc_discussion_id="D_toc",
        )

        # All four legs entered before any awaited completion — proves
        # they were scheduled concurrently rather than sequentially.
        assert sorted(started) == [
            "milestones", "open_issues", "recent_discussions", "toc",
        ]


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
