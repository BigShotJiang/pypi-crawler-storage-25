"""Unit tests for LocalStoreAdapter's append-only history log
(3.0 / Phase 6 sub-run C).

Verifies that each mutation (body update, state transition, label
add/remove, decision) writes a timestamped JSON entry under the
artifact's ``history/`` directory without disturbing the
authoritative current-state files.
"""
from __future__ import annotations

import asyncio
import json
import subprocess
from pathlib import Path

import pytest

from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
from forge_manager_mcp.adapters.types import ArtifactRef


# ---------------------------------------------------------------------------
# Fixture builders
# ---------------------------------------------------------------------------

def _build_repo(root: Path) -> Path:
    subprocess.run(["git", "init", "-q", "-b", "main"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.email", "t@e.com"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=root, check=True)
    subprocess.run(
        ["git", "commit", "-q", "--allow-empty", "-m", "initial"],
        cwd=root, check=True,
    )
    return root


def _seed_issue(repo: Path, number: int = 1) -> Path:
    issue_dir = repo / "issues" / str(number)
    issue_dir.mkdir(parents=True)
    (issue_dir / "title.md").write_text("Title\n")
    (issue_dir / "body.md").write_text("Original body\n")
    (issue_dir / "state.txt").write_text("open\n")
    (issue_dir / "labels.txt").write_text("kind:bug\n")
    (issue_dir / "meta.json").write_text(json.dumps({"number": number}))
    subprocess.run(["git", "add", "."], cwd=repo, check=True)
    subprocess.run(
        ["git", "commit", "-q", "-m", f"seed issue {number}"],
        cwd=repo, check=True,
    )
    return issue_dir


def _ref(adapter: LocalStoreAdapter, number: int) -> ArtifactRef:
    return ArtifactRef(
        platform_id="local",
        native_id=f"issues/{number}",
        kind="issue",
        owner="o", repo="r",
        number=number,
    )


# ---------------------------------------------------------------------------
# History entry shape
# ---------------------------------------------------------------------------

class TestHistoryAppend:
    @pytest.mark.asyncio
    async def test_update_body_appends_history_entry(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.update_issue_body(_ref(adapter, 1), "New body content")

        history_dir = issue_dir / "history"
        assert history_dir.is_dir()
        entries = list(history_dir.iterdir())
        assert len(entries) == 1
        entry = json.loads(entries[0].read_text(encoding="utf-8"))
        assert entry["operation"] == "update_body"
        assert entry["prior_length"] == len("Original body\n")
        assert entry["new_length"] == len("New body content")
        assert "timestamp" in entry

    @pytest.mark.asyncio
    async def test_close_issue_appends_history_entry(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.close_issue(_ref(adapter, 1), state_reason="completed")

        history_dir = issue_dir / "history"
        entries = list(history_dir.iterdir())
        assert len(entries) == 1
        entry = json.loads(entries[0].read_text(encoding="utf-8"))
        assert entry["operation"] == "close_issue"
        assert "open" in entry["prior_state"]
        assert "closed" in entry["new_state"]
        assert entry["state_reason"] == "completed"
        # Authoritative state file also updated.
        assert "closed" in (issue_dir / "state.txt").read_text(encoding="utf-8")

    @pytest.mark.asyncio
    async def test_add_label_appends_history_entry(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.add_label(_ref(adapter, 1), "priority:high")

        entries = list((issue_dir / "history").iterdir())
        assert len(entries) == 1
        entry = json.loads(entries[0].read_text(encoding="utf-8"))
        assert entry["operation"] == "add_label"
        assert entry["label"] == "priority:high"
        assert "kind:bug" in entry["labels_after"]
        assert "priority:high" in entry["labels_after"]

    @pytest.mark.asyncio
    async def test_add_label_no_op_skips_history(self, tmp_path: Path):
        # Adding a label that already exists shouldn't write history.
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # kind:bug is already present from the fixture.
        await adapter.add_label(_ref(adapter, 1), "kind:bug")

        history_dir = issue_dir / "history"
        # Either no dir created or no entries.
        if history_dir.exists():
            assert list(history_dir.iterdir()) == []

    @pytest.mark.asyncio
    async def test_remove_label_appends_history_entry(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.remove_label(_ref(adapter, 1), "kind:bug")

        entries = list((issue_dir / "history").iterdir())
        assert len(entries) == 1
        entry = json.loads(entries[0].read_text(encoding="utf-8"))
        assert entry["operation"] == "remove_label"
        assert entry["label"] == "kind:bug"
        assert "kind:bug" not in entry["labels_after"]

    @pytest.mark.asyncio
    async def test_remove_label_no_op_skips_history(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # Label that doesn't exist on the issue.
        await adapter.remove_label(_ref(adapter, 1), "never:applied")

        history_dir = issue_dir / "history"
        if history_dir.exists():
            assert list(history_dir.iterdir()) == []

    @pytest.mark.asyncio
    async def test_mark_decided_on_discussion_appends_history(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        # Seed a discussion via append_comment-like manual setup.
        disc_dir = repo / "discussions" / "1"
        disc_dir.mkdir(parents=True)
        (disc_dir / "title.md").write_text("Design decision\n")
        (disc_dir / "body.md").write_text("\n")
        (disc_dir / "state.txt").write_text("open\n")
        (disc_dir / "labels.txt").write_text("kind:discussion\n")
        (disc_dir / "meta.json").write_text(json.dumps({"number": 1}))
        subprocess.run(["git", "add", "."], cwd=repo, check=True)
        subprocess.run(["git", "commit", "-q", "-m", "seed disc"],
                       cwd=repo, check=True)

        adapter = LocalStoreAdapter(docs_repo_path=repo)
        ref = ArtifactRef(
            platform_id="local",
            native_id="discussions/1",
            kind="discussion",
            owner="o", repo="r", number=1,
        )
        await adapter.mark_decided(ref)

        entries = list((disc_dir / "history").iterdir())
        assert len(entries) == 1
        entry = json.loads(entries[0].read_text(encoding="utf-8"))
        assert entry["operation"] == "mark_decided"
        assert "decided" in entry["new_state"]

    @pytest.mark.asyncio
    async def test_multiple_mutations_accumulate(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # Three distinct ops.
        await adapter.update_issue_body(_ref(adapter, 1), "Updated.")
        # Tiny sleep so the microsecond-precision timestamps don't collide.
        await asyncio.sleep(0.001)
        await adapter.add_label(_ref(adapter, 1), "priority:high")
        await asyncio.sleep(0.001)
        await adapter.close_issue(_ref(adapter, 1))

        entries = sorted((issue_dir / "history").iterdir())
        assert len(entries) == 3
        ops = [json.loads(e.read_text(encoding="utf-8"))["operation"] for e in entries]
        assert ops == ["update_body", "add_label", "close_issue"]

    @pytest.mark.asyncio
    async def test_history_entries_are_chronological(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.update_issue_body(_ref(adapter, 1), "v1")
        await asyncio.sleep(0.001)
        await adapter.update_issue_body(_ref(adapter, 1), "v2")
        await asyncio.sleep(0.001)
        await adapter.update_issue_body(_ref(adapter, 1), "v3")

        # Filename sort = chronological sort (UTC ts prefix).
        entries = sorted((issue_dir / "history").iterdir())
        timestamps = [
            json.loads(e.read_text(encoding="utf-8"))["timestamp"]
            for e in entries
        ]
        assert timestamps == sorted(timestamps)


# ---------------------------------------------------------------------------
# Authoritative-files invariant
# ---------------------------------------------------------------------------

class TestAuthoritativeFilesPreserved:
    """History is defense-in-depth — current-state files (body.md,
    state.txt, labels.txt) remain the authoritative quick-read surface
    and aren't replaced by history reconstruction."""

    @pytest.mark.asyncio
    async def test_body_md_still_authoritative_after_update(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.update_issue_body(_ref(adapter, 1), "New body content")

        # Authoritative file reflects the new body.
        body = (issue_dir / "body.md").read_text(encoding="utf-8")
        assert body == "New body content"

    @pytest.mark.asyncio
    async def test_labels_txt_still_authoritative_after_add(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.add_label(_ref(adapter, 1), "priority:high")

        labels = (issue_dir / "labels.txt").read_text(encoding="utf-8")
        assert "kind:bug" in labels
        assert "priority:high" in labels


class TestHistoryQuery:
    """#274 Phase D — query_history is the read counterpart to
    _append_history. Returns typed HistoryEntry records, oldest-first,
    optionally filtered by since-timestamp or operation."""

    @pytest.mark.asyncio
    async def test_returns_empty_list_when_no_history(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)  # seeded but never mutated → no history
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        entries = await adapter.query_history(_ref(adapter, 1))
        assert entries == []

    @pytest.mark.asyncio
    async def test_returns_entries_in_chronological_order(
        self, tmp_path: Path
    ):
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import HistoryEntry

        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # Three mutations; each writes a history entry.
        await adapter.update_issue_body(_ref(adapter, 1), "first edit")
        # Tiny delay so timestamps don't collide on fast filesystems.
        await asyncio.sleep(0.001)
        await adapter.update_issue_body(_ref(adapter, 1), "second edit")
        await asyncio.sleep(0.001)
        await adapter.close_issue(_ref(adapter, 1))

        entries = await adapter.query_history(_ref(adapter, 1))
        assert len(entries) == 3
        # All HistoryEntry instances.
        assert all(isinstance(e, HistoryEntry) for e in entries)
        # Oldest first, newest last.
        for prev, curr in zip(entries, entries[1:]):
            assert prev.timestamp <= curr.timestamp
        # Operations come through verbatim.
        ops = [e.operation for e in entries]
        assert ops == ["update_body", "update_body", "close_issue"]

    @pytest.mark.asyncio
    async def test_filter_by_operation(self, tmp_path: Path):
        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.update_issue_body(_ref(adapter, 1), "edit 1")
        await asyncio.sleep(0.001)
        await adapter.update_issue_body(_ref(adapter, 1), "edit 2")
        await asyncio.sleep(0.001)
        await adapter.close_issue(_ref(adapter, 1))

        update_only = await adapter.query_history(
            _ref(adapter, 1), operation="update_body",
        )
        assert len(update_only) == 2
        assert all(e.operation == "update_body" for e in update_only)

        close_only = await adapter.query_history(
            _ref(adapter, 1), operation="close_issue",
        )
        assert len(close_only) == 1
        assert close_only[0].operation == "close_issue"

    @pytest.mark.asyncio
    async def test_filter_by_since_timestamp(self, tmp_path: Path):
        from datetime import datetime, timezone

        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.update_issue_body(_ref(adapter, 1), "first")
        await asyncio.sleep(0.001)
        # Take a marker timestamp between the two writes.
        marker = datetime.now(timezone.utc)
        await asyncio.sleep(0.001)
        await adapter.update_issue_body(_ref(adapter, 1), "second")

        recent = await adapter.query_history(_ref(adapter, 1), since=marker)
        assert len(recent) == 1
        assert recent[0].payload["new_length"] == len("second")

    @pytest.mark.asyncio
    async def test_payload_carries_op_specific_fields(
        self, tmp_path: Path
    ):
        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.update_issue_body(_ref(adapter, 1), "new body")
        entries = await adapter.query_history(_ref(adapter, 1))

        assert len(entries) == 1
        # update_body shape: {prior_length, new_length}
        assert entries[0].payload["prior_length"] == len("Original body\n")
        assert entries[0].payload["new_length"] == len("new body")
        # timestamp / operation are top-level on the model, not in
        # the payload dict.
        assert "timestamp" not in entries[0].payload
        assert "operation" not in entries[0].payload

    @pytest.mark.asyncio
    async def test_malformed_json_entry_skipped(self, tmp_path: Path):
        """A corrupt JSON file in history/ is best-effort skipped
        rather than failing the whole query."""
        repo = _build_repo(tmp_path)
        issue_dir = _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # Real entry from a real mutation.
        await adapter.update_issue_body(_ref(adapter, 1), "real edit")

        # Inject a malformed entry alongside.
        history_dir = issue_dir / "history"
        (history_dir / "20990101T000000000000Z-bogus.json").write_text(
            "this is { not valid json", encoding="utf-8",
        )

        entries = await adapter.query_history(_ref(adapter, 1))
        # Only the real entry comes back.
        assert len(entries) == 1
        assert entries[0].operation == "update_body"


class TestAggregateHistorySince:
    """#274 Phase D — time-window complement to compute_drift's
    set-based view. Walks every artifact's history/ and merges the
    results sorted oldest-first."""

    @pytest.mark.asyncio
    async def test_returns_entries_across_all_artifacts(
        self, tmp_path: Path
    ):
        from datetime import datetime, timezone, timedelta

        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)
        _seed_issue(repo, 2)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # Mutate both issues.
        await adapter.update_issue_body(_ref(adapter, 1), "edit on 1")
        await asyncio.sleep(0.001)
        await adapter.update_issue_body(_ref(adapter, 2), "edit on 2")
        await asyncio.sleep(0.001)
        await adapter.close_issue(_ref(adapter, 1))

        # Cutoff well in the past — return everything.
        cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
        entries = await adapter.aggregate_history_since(since=cutoff)

        # Three mutations across two issues, merged + sorted.
        assert len(entries) == 3
        # Sorted oldest-first across artifact boundaries.
        for prev, curr in zip(entries, entries[1:]):
            assert prev.timestamp <= curr.timestamp
        # Each entry's ref points at its artifact.
        nums = {e.ref.number for e in entries}
        assert nums == {1, 2}

    @pytest.mark.asyncio
    async def test_since_filter_excludes_older_entries(
        self, tmp_path: Path
    ):
        from datetime import datetime, timezone

        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.update_issue_body(_ref(adapter, 1), "first")
        await asyncio.sleep(0.001)
        marker = datetime.now(timezone.utc)
        await asyncio.sleep(0.001)
        await adapter.update_issue_body(_ref(adapter, 1), "second")

        # Only the post-marker entry comes back.
        recent = await adapter.aggregate_history_since(since=marker)
        assert len(recent) == 1
        assert recent[0].payload["new_length"] == len("second")

    @pytest.mark.asyncio
    async def test_kind_filter_restricts_to_one_artifact_kind(
        self, tmp_path: Path
    ):
        from datetime import datetime, timezone, timedelta

        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)
        # Seed a discussion alongside the issue.
        disc_dir = repo / "discussions" / "1"
        disc_dir.mkdir(parents=True)
        (disc_dir / "title.md").write_text("Disc title\n")
        (disc_dir / "body.md").write_text("Disc body\n")
        (disc_dir / "state.txt").write_text("open\n")
        (disc_dir / "labels.txt").write_text("kind:discussion\n")
        (disc_dir / "meta.json").write_text(
            json.dumps({"number": 1}), encoding="utf-8",
        )
        subprocess.run(["git", "add", "."], cwd=repo, check=True)
        subprocess.run(
            ["git", "commit", "-q", "-m", "seed discussion"],
            cwd=repo, check=True,
        )
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        await adapter.update_issue_body(_ref(adapter, 1), "issue edit")
        await asyncio.sleep(0.001)
        disc_ref = ArtifactRef(
            platform_id="local", native_id="discussions/1",
            kind="discussion", owner="o", repo="r", number=1,
        )
        await adapter.update_discussion_body(disc_ref, "disc edit")

        cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
        only_issues = await adapter.aggregate_history_since(
            since=cutoff, kind="issue",
        )
        only_discs = await adapter.aggregate_history_since(
            since=cutoff, kind="discussion",
        )
        assert len(only_issues) == 1
        assert only_issues[0].ref.kind == "issue"
        assert len(only_discs) == 1
        assert only_discs[0].ref.kind == "discussion"

    @pytest.mark.asyncio
    async def test_empty_store_returns_empty_list(self, tmp_path: Path):
        from datetime import datetime, timezone, timedelta

        repo = _build_repo(tmp_path)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        cutoff = datetime.now(timezone.utc) - timedelta(hours=1)
        entries = await adapter.aggregate_history_since(since=cutoff)
        assert entries == []


class TestApplyRemoteChange:
    """#274 Phase D — write side of the import_remote_changes flow.
    Foundation only: the live remote-fetch implementations are
    deferred. Tests construct RemoteChange records directly and
    exercise the canonical-store apply + conflict-detection logic."""

    @pytest.mark.asyncio
    async def test_clean_apply_writes_to_canonical(self, tmp_path: Path):
        from datetime import datetime, timezone, timedelta
        from forge_manager_mcp.adapters.types import RemoteChange

        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # Watermark before any local mutation; remote change body update.
        watermark = datetime.now(timezone.utc) - timedelta(seconds=1)
        change = RemoteChange(
            source_platform_id="github",
            ref=_ref(adapter, 1),
            operation="update_body",
            observed_at=watermark,
            payload={"new_body": "from remote import"},
        )
        result = await adapter.apply_remote_change(change)
        # Clean apply.
        assert result is None
        body = (repo / "issues" / "1" / "body.md").read_text(encoding="utf-8")
        assert body == "from remote import"

    @pytest.mark.asyncio
    async def test_local_mutation_after_watermark_creates_conflict(
        self, tmp_path: Path
    ):
        from datetime import datetime, timezone, timedelta
        from forge_manager_mcp.adapters.types import RemoteChange

        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # 1. Watermark BEFORE the local mutation.
        watermark = datetime.now(timezone.utc) - timedelta(seconds=1)
        # 2. Local mutation lands AFTER the watermark.
        await adapter.update_issue_body(_ref(adapter, 1), "local edit")
        # 3. Remote tries to import a change observed at the (now-stale)
        #    watermark — local diverged, conflict.
        change = RemoteChange(
            source_platform_id="github",
            ref=_ref(adapter, 1),
            operation="update_body",
            observed_at=watermark,
            payload={"new_body": "remote edit"},
        )
        result = await adapter.apply_remote_change(change)
        assert result is not None
        assert "newer than" in result.reason
        assert len(result.local_history) == 1
        # The local body wasn't overwritten by the conflict.
        body = (repo / "issues" / "1" / "body.md").read_text(encoding="utf-8")
        assert body == "local edit"

    @pytest.mark.asyncio
    async def test_missing_artifact_returns_conflict(self, tmp_path: Path):
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import ArtifactRef, RemoteChange

        repo = _build_repo(tmp_path)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # Reference an issue that was never created locally.
        bogus_ref = ArtifactRef(
            platform_id="github", native_id="I_unknown",
            kind="issue", owner="o", repo="r", number=999,
        )
        change = RemoteChange(
            source_platform_id="github",
            ref=bogus_ref,
            operation="update_body",
            observed_at=datetime.now(timezone.utc),
            payload={"new_body": "x"},
        )
        result = await adapter.apply_remote_change(change)
        assert result is not None
        assert "not found" in result.reason or "missing" in result.reason

    @pytest.mark.asyncio
    async def test_unsupported_operation_is_no_op(self, tmp_path: Path):
        from datetime import datetime, timezone, timedelta
        from forge_manager_mcp.adapters.types import RemoteChange

        repo = _build_repo(tmp_path)
        _seed_issue(repo, 1)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        watermark = datetime.now(timezone.utc) - timedelta(seconds=1)
        change = RemoteChange(
            source_platform_id="github",
            ref=_ref(adapter, 1),
            operation="add_comment",  # not yet wired in apply
            observed_at=watermark,
            payload={"body": "x"},
        )
        # Returns None (clean) but the body is unchanged — no-op.
        result = await adapter.apply_remote_change(change)
        assert result is None
        # Body unchanged — no apply happened.
        body = (repo / "issues" / "1" / "body.md").read_text(encoding="utf-8")
        assert body == "Original body\n"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
