"""Unit tests for site_renderer.contrast (3.0 / Phase 5).

YIQ-derived auto-contrast text color for GitHub-style label pills.
"""
from __future__ import annotations

import pytest

from forge_manager_mcp.site_renderer.contrast import yiq_text_color


class TestYiqTextColor:
    def test_white_bg_returns_black_text(self):
        assert yiq_text_color("#ffffff") == "#000000"

    def test_black_bg_returns_white_text(self):
        assert yiq_text_color("#000000") == "#ffffff"

    def test_github_red_label_bug(self):
        # GitHub's default 'bug' label color: dark red.
        assert yiq_text_color("#d73a4a") == "#ffffff"

    def test_github_green_label_enhancement(self):
        # GitHub's default 'enhancement' label: light blue, light bg.
        assert yiq_text_color("#a2eeef") == "#000000"

    def test_github_purple_label_help_wanted(self):
        # GitHub's 'help wanted' label.
        assert yiq_text_color("#008672") == "#ffffff"

    def test_3_digit_shorthand_expands(self):
        # 'fff' should equal '#ffffff' → black.
        assert yiq_text_color("fff") == "#000000"
        # '000' should equal '#000000' → white.
        assert yiq_text_color("000") == "#ffffff"

    def test_leading_hash_optional(self):
        assert yiq_text_color("d73a4a") == "#ffffff"
        assert yiq_text_color("#d73a4a") == "#ffffff"

    def test_uppercase_hex_accepted(self):
        assert yiq_text_color("#D73A4A") == "#ffffff"

    def test_threshold_boundary(self):
        # YIQ exactly 128 → black (>= threshold).
        # Color where r=g=b such that yiq = 128: r=g=b → yiq = r * (299+587+114)/1000 = r
        # So r=g=b=128 gives yiq=128 → black.
        assert yiq_text_color("#808080") == "#000000"
        # Just below threshold.
        assert yiq_text_color("#7f7f7f") == "#ffffff"

    def test_invalid_length_raises(self):
        with pytest.raises(ValueError, match="3- or 6-digit hex"):
            yiq_text_color("ffff")
        with pytest.raises(ValueError, match="3- or 6-digit hex"):
            yiq_text_color("#fffff")

    def test_non_hex_chars_raise(self):
        with pytest.raises(ValueError, match="non-hex"):
            yiq_text_color("#zzzzzz")


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
