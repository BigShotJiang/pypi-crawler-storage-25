"""Unit tests for drift detection (3.0 / Phase 6 sub-run B).

Covers:
  - LocalStoreAdapter.snapshot() shape against a fixture docs repo
  - ForgejoAdapter.compute_drift() set-based diffs (mocked HTTP via
    httpx.MockTransport)
  - ReplicationManager.compute_drifts() orchestration (mock canonical
    adapter + mock remotes)
"""
from __future__ import annotations

import asyncio
import json
import subprocess
from pathlib import Path
from typing import Any

import httpx
import pytest

from forge_manager_mcp.adapters import errors as _adapter_errors
from forge_manager_mcp.adapters.forgejo import ForgejoAdapter
from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
from forge_manager_mcp.adapters.types import ArtifactRef, DriftReport
from forge_manager_mcp.replication import (
    AdapterState,
    ReplicationManager,
)


def _fixture_docs_repo(root: Path) -> Path:
    """Build a minimal fixture docs repo for snapshot tests."""
    subprocess.run(["git", "init", "-q", "-b", "main"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.email", "t@e.com"], cwd=root, check=True)
    subprocess.run(["git", "config", "user.name", "t"], cwd=root, check=True)
    subprocess.run(
        ["git", "commit", "-q", "--allow-empty", "-m", "initial"],
        cwd=root, check=True,
    )

    # Issue #1 — open with two labels.
    issue1 = root / "issues" / "1"
    issue1.mkdir(parents=True)
    (issue1 / "title.md").write_text("First\n")
    (issue1 / "body.md").write_text("Body\n")
    (issue1 / "state.txt").write_text("open\n")
    (issue1 / "labels.txt").write_text("kind:bug\nfeature\n")
    (issue1 / "meta.json").write_text(json.dumps({"number": 1}))

    # Issue #2 — closed with no labels.
    issue2 = root / "issues" / "2"
    issue2.mkdir(parents=True)
    (issue2 / "title.md").write_text("Closed one\n")
    (issue2 / "body.md").write_text("\n")
    (issue2 / "state.txt").write_text("closed\n")
    (issue2 / "labels.txt").write_text("\n")
    (issue2 / "meta.json").write_text(json.dumps({"number": 2}))

    # Discussion #1 — decided.
    disc1 = root / "discussions" / "1"
    disc1.mkdir(parents=True)
    (disc1 / "title.md").write_text("Design\n")
    (disc1 / "body.md").write_text("Body\n")
    (disc1 / "state.txt").write_text("open\ndecided\n")
    (disc1 / "labels.txt").write_text("kind:discussion\ncategory:architecture\n")
    (disc1 / "meta.json").write_text(json.dumps({"number": 1}))

    # Milestone.
    ms_dir = root / "milestones"
    ms_dir.mkdir()
    (ms_dir / "3.0.0.md").write_text("# 3.0.0\n")

    return root


# ---------------------------------------------------------------------------
# LocalStoreAdapter.snapshot()
# ---------------------------------------------------------------------------

class TestLocalSnapshot:
    @pytest.mark.asyncio
    async def test_emits_canonical_shape(self, tmp_path: Path):
        repo = _fixture_docs_repo(tmp_path)
        adapter = LocalStoreAdapter(docs_repo_path=repo)
        snap = await adapter.snapshot(owner="o", repo="r")
        assert snap["platform_id"] == "local"
        assert snap["owner"] == "o"
        assert snap["repo"] == "r"
        # Issues — keyed by number.
        assert 1 in snap["issues"]
        assert 2 in snap["issues"]
        assert snap["issues"][1]["state"] == "open"
        assert snap["issues"][2]["state"] == "closed"
        assert "kind:bug" in snap["issues"][1]["labels"]
        # Discussions — keyed by number, with multi-dim state preserving the lifecycle axis.
        assert 1 in snap["discussions"]
        assert snap["discussions"][1]["state"] == "open"
        assert "kind:discussion" in snap["discussions"][1]["labels"]
        # Milestones — title list.
        assert "3.0.0" in snap["milestones"]
        # since unset → key carries None
        assert snap["since"] is None

    @pytest.mark.asyncio
    async def test_since_filter_narrows_to_recent_artifacts(
        self, tmp_path: Path
    ):
        """#274 Phase D drift improvement: ``since`` narrows the
        snapshot to artifacts that changed locally after the cutoff,
        leveraging the history-log foundation."""
        from datetime import datetime, timezone, timedelta

        repo = _fixture_docs_repo(tmp_path)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # Mark a watermark; only mutate issue #1 after it.
        await asyncio.sleep(0.001)
        watermark = datetime.now(timezone.utc)
        await asyncio.sleep(0.001)
        ref_1 = ArtifactRef(
            platform_id="local", native_id="issues/1",
            kind="issue", owner="o", repo="r", number=1,
        )
        await adapter.update_issue_body(ref_1, "post-watermark edit")

        snap = await adapter.snapshot(
            owner="o", repo="r", since=watermark,
        )
        # Only issue 1 — issue 2 didn't change after the watermark.
        assert 1 in snap["issues"]
        assert 2 not in snap["issues"]
        # Discussions also filtered (none changed → empty map).
        assert snap["discussions"] == {}
        # Milestones aren't time-filtered (no per-artifact history).
        assert "3.0.0" in snap["milestones"]
        # since echoed in ISO form for caller traceability.
        assert snap["since"] is not None
        assert "T" in snap["since"]

    @pytest.mark.asyncio
    async def test_since_in_far_past_returns_full_snapshot(
        self, tmp_path: Path
    ):
        """Sanity: a watermark before any local activity yields the
        full set, equivalent to since=None."""
        from datetime import datetime, timezone, timedelta

        repo = _fixture_docs_repo(tmp_path)
        adapter = LocalStoreAdapter(docs_repo_path=repo)

        # Mutate so history exists for all seeded issues.
        ref_1 = ArtifactRef(
            platform_id="local", native_id="issues/1",
            kind="issue", owner="o", repo="r", number=1,
        )
        ref_2 = ArtifactRef(
            platform_id="local", native_id="issues/2",
            kind="issue", owner="o", repo="r", number=2,
        )
        await adapter.update_issue_body(ref_1, "edit-1")
        await adapter.update_issue_body(ref_2, "edit-2")

        far_past = datetime.now(timezone.utc) - timedelta(days=30)
        snap = await adapter.snapshot(owner="o", repo="r", since=far_past)
        assert 1 in snap["issues"]
        assert 2 in snap["issues"]


# ---------------------------------------------------------------------------
# ForgejoAdapter.compute_drift() with MockTransport
# ---------------------------------------------------------------------------

def _forgejo_with_mock(handler) -> ForgejoAdapter:
    adapter = ForgejoAdapter(
        token="fake", api_base="http://forgejo.test", platform_id="forgejo",
    )
    adapter._client = httpx.AsyncClient(
        base_url=f"{adapter._api_base}/api/v1",
        transport=httpx.MockTransport(handler),
        headers=adapter._headers(),
    )
    return adapter


def _remote_issues_response(items: list[dict]) -> httpx.Response:
    return httpx.Response(200, json=items)


class TestForgejoComputeDrift:
    @pytest.mark.asyncio
    async def test_clean_when_local_and_remote_match(self):
        # Local: issue 1 open with kind:bug. Remote: same.
        snapshot = {
            "platform_id": "local",
            "owner": "o", "repo": "r",
            "issues": {1: {"state": "open", "labels": ["kind:bug"]}},
            "discussions": {},
            "milestones": [],
        }
        remote_items = [
            {
                "id": 100, "number": 1, "state": "open",
                "labels": [{"id": 1, "name": "kind:bug"}],
            },
        ]
        adapter = _forgejo_with_mock(lambda req: _remote_issues_response(remote_items))
        try:
            report = await adapter.compute_drift(snapshot)
            assert isinstance(report, DriftReport)
            assert report.is_clean is True
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_only_local_when_remote_missing_issue(self):
        snapshot = {
            "platform_id": "local",
            "owner": "o", "repo": "r",
            "issues": {1: {"state": "open", "labels": []}, 2: {"state": "open", "labels": []}},
            "discussions": {},
            "milestones": [],
        }
        # Remote only has issue 1.
        remote_items = [
            {"id": 100, "number": 1, "state": "open", "labels": []},
        ]
        adapter = _forgejo_with_mock(lambda req: _remote_issues_response(remote_items))
        try:
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is False
            assert report.issues_only_local == [2]
            assert report.issues_only_remote == []
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_only_remote_when_local_missing_issue(self):
        snapshot = {
            "platform_id": "local",
            "owner": "o", "repo": "r",
            "issues": {1: {"state": "open", "labels": []}},
            "discussions": {},
            "milestones": [],
        }
        # Remote has both 1 and 5.
        remote_items = [
            {"id": 100, "number": 1, "state": "open", "labels": []},
            {"id": 105, "number": 5, "state": "open", "labels": []},
        ]
        adapter = _forgejo_with_mock(lambda req: _remote_issues_response(remote_items))
        try:
            report = await adapter.compute_drift(snapshot)
            assert report.issues_only_local == []
            assert report.issues_only_remote == [5]
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_diverged_state(self):
        snapshot = {
            "platform_id": "local",
            "owner": "o", "repo": "r",
            "issues": {1: {"state": "open", "labels": []}},
            "discussions": {},
            "milestones": [],
        }
        # Remote has 1 but closed.
        remote_items = [
            {"id": 100, "number": 1, "state": "closed", "labels": []},
        ]
        adapter = _forgejo_with_mock(lambda req: _remote_issues_response(remote_items))
        try:
            report = await adapter.compute_drift(snapshot)
            assert report.issues_diverged == [1]
            assert report.is_clean is False
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_diverged_labels(self):
        snapshot = {
            "platform_id": "local",
            "owner": "o", "repo": "r",
            "issues": {1: {"state": "open", "labels": ["kind:bug"]}},
            "discussions": {},
            "milestones": [],
        }
        remote_items = [
            {
                "id": 100, "number": 1, "state": "open",
                "labels": [{"name": "kind:feature"}],
            },
        ]
        adapter = _forgejo_with_mock(lambda req: _remote_issues_response(remote_items))
        try:
            report = await adapter.compute_drift(snapshot)
            assert report.issues_diverged == [1]
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_discussions_partition_by_kind_discussion_label(self):
        # An issue with kind:discussion label belongs to the
        # "discussions" partition in the remote view, not "issues".
        snapshot = {
            "platform_id": "local",
            "owner": "o", "repo": "r",
            "issues": {},
            "discussions": {1: {"state": "open", "labels": ["kind:discussion"]}},
            "milestones": [],
        }
        remote_items = [
            {
                "id": 200, "number": 1, "state": "open",
                "labels": [{"name": "kind:discussion"}],
            },
        ]
        adapter = _forgejo_with_mock(lambda req: _remote_issues_response(remote_items))
        try:
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is True
            # No issue-side drift (the item didn't enter the "issues" set).
            assert report.issues_only_local == []
            assert report.issues_only_remote == []
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_missing_owner_in_snapshot_returns_inconclusive(self):
        snapshot = {"issues": {}, "discussions": {}, "milestones": []}  # no owner/repo
        adapter = ForgejoAdapter(token="t", api_base="http://x")
        try:
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is False
            assert any("owner/repo" in n for n in report.notes)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_unavailable_remote_returns_inconclusive(self):
        snapshot = {
            "platform_id": "local",
            "owner": "o", "repo": "r",
            "issues": {}, "discussions": {}, "milestones": [],
        }
        adapter = _forgejo_with_mock(lambda req: httpx.Response(503))
        try:
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is False
            assert any("unreachable" in n.lower() for n in report.notes)
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# ReplicationManager.compute_drifts() orchestration
# ---------------------------------------------------------------------------

class _MockCanonical:
    platform_id = "local"

    async def snapshot(self, *, owner: str, repo: str) -> dict:
        return {
            "platform_id": "local",
            "owner": owner, "repo": repo,
            "issues": {1: {"state": "open", "labels": []}},
            "discussions": {},
            "milestones": [],
        }


class _MockRemote:
    def __init__(self, platform_id: str, *, fail_with: BaseException | None = None,
                 report: DriftReport | None = None):
        self.platform_id = platform_id
        self.fail_with = fail_with
        self.report = report or DriftReport(platform_id=platform_id, is_clean=True)
        self.snapshot_seen: dict | None = None

    async def compute_drift(self, snapshot: dict) -> DriftReport:
        self.snapshot_seen = snapshot
        if self.fail_with is not None:
            raise self.fail_with
        return self.report


class TestComputeDrifts:
    @pytest.mark.asyncio
    async def test_returns_per_remote_reports(self):
        canonical = _MockCanonical()
        r1 = _MockRemote("github", report=DriftReport(platform_id="github", is_clean=True))
        r2 = _MockRemote("codeberg", report=DriftReport(
            platform_id="codeberg", is_clean=False, issues_only_remote=[42],
        ))
        m = ReplicationManager([("local", canonical), ("github", r1), ("codeberg", r2)])  # type: ignore[arg-type]
        results = await m.compute_drifts(owner="o", repo="r")
        assert "github" in results
        assert "codeberg" in results
        # Canonical not in results (can't drift against itself).
        assert "local" not in results
        assert results["codeberg"].issues_only_remote == [42]

    @pytest.mark.asyncio
    async def test_passes_snapshot_to_remote(self):
        canonical = _MockCanonical()
        r1 = _MockRemote("github")
        m = ReplicationManager([("local", canonical), ("github", r1)])  # type: ignore[arg-type]
        await m.compute_drifts(owner="org", repo="proj")
        assert r1.snapshot_seen is not None
        assert r1.snapshot_seen["owner"] == "org"
        assert r1.snapshot_seen["repo"] == "proj"

    @pytest.mark.asyncio
    async def test_skips_degraded_adapters(self):
        canonical = _MockCanonical()
        r1 = _MockRemote("github")
        r2 = _MockRemote("codeberg")
        m = ReplicationManager([("local", canonical), ("github", r1), ("codeberg", r2)])  # type: ignore[arg-type]
        m._entries[1].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        results = await m.compute_drifts(owner="o", repo="r")
        assert "github" not in results
        assert "codeberg" in results
        assert r1.snapshot_seen is None  # not invoked

    @pytest.mark.asyncio
    async def test_unavailable_during_drift_degrades_adapter(self):
        canonical = _MockCanonical()
        r1 = _MockRemote(
            "github",
            fail_with=_adapter_errors.ForgeUnavailableError("auth-fail"),
        )
        m = ReplicationManager([("local", canonical), ("github", r1)])  # type: ignore[arg-type]
        results = await m.compute_drifts(owner="o", repo="r")
        # Adapter excluded from results, marked degraded.
        assert "github" not in results
        assert m.states()["github"] == AdapterState.DEGRADED

    @pytest.mark.asyncio
    async def test_canonical_without_snapshot_method_raises(self):
        # A canonical adapter that doesn't implement snapshot() must
        # surface a clear TypeError, not a confusing AttributeError later.
        class _NoSnapshot:
            platform_id = "weird-canonical"
        m = ReplicationManager([("weird-canonical", _NoSnapshot())])  # type: ignore[arg-type]
        with pytest.raises(TypeError, match="snapshot"):
            await m.compute_drifts(owner="o", repo="r")


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
