"""Unit tests for ReplicationManager (3.0 / Phase 6 sub-run A).

Covers the orchestration shape: read-path failover ordering, write-
path local-first invariant, per-adapter state-machine transitions,
DEGRADED-skip behavior, and the queueing semantics for failed remote
writes. Real adapters aren't needed — the tests construct minimal
mock adapters that record calls.
"""
from __future__ import annotations

from typing import Any, ClassVar

import pytest

from forge_manager_mcp.adapters import errors as _adapter_errors
from forge_manager_mcp.replication import (
    AdapterState,
    AllAdaptersFailedError,
    ReplicationError,
    ReplicationManager,
    ReplicationWriteError,
)


# ---------------------------------------------------------------------------
# Mock adapter helpers
# ---------------------------------------------------------------------------

class _MockAdapter:
    """Minimal stand-in for a PlatformAdapter — records every method
    call on `.calls` so tests can assert on order + count."""

    def __init__(
        self,
        platform_id: str,
        *,
        fail_with: BaseException | None = None,
        return_value: Any = "ok",
    ):
        self.platform_id: str = platform_id
        self.fail_with = fail_with
        self.return_value = return_value
        self.calls: list[str] = []

    async def some_op(self, *args, **kwargs) -> Any:
        self.calls.append("some_op")
        if self.fail_with is not None:
            raise self.fail_with
        return self.return_value


def _manager_with(*adapters: _MockAdapter) -> ReplicationManager:
    return ReplicationManager(
        [(a.platform_id, a) for a in adapters],  # type: ignore[arg-type]
    )


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestConstruction:
    def test_empty_adapters_raises(self):
        with pytest.raises(ValueError, match="at least one adapter"):
            ReplicationManager([])

    def test_initial_states_all_healthy(self):
        m = _manager_with(_MockAdapter("local"), _MockAdapter("remote"))
        states = m.states()
        assert states == {"local": AdapterState.HEALTHY, "remote": AdapterState.HEALTHY}

    def test_canonical_returns_first(self):
        local = _MockAdapter("local")
        remote = _MockAdapter("remote")
        m = _manager_with(local, remote)
        assert m.canonical() is local


# ---------------------------------------------------------------------------
# Read-path failover
# ---------------------------------------------------------------------------

class TestReadFailover:
    @pytest.mark.asyncio
    async def test_first_healthy_wins(self):
        local = _MockAdapter("local", return_value="local-result")
        remote = _MockAdapter("remote", return_value="remote-result")
        m = _manager_with(local, remote)
        result = await m.read(lambda a: a.some_op())
        assert result == "local-result"
        assert local.calls == ["some_op"]
        assert remote.calls == []  # short-circuited

    @pytest.mark.asyncio
    async def test_unavailable_falls_through_to_next(self):
        local = _MockAdapter(
            "local",
            fail_with=_adapter_errors.ForgeUnavailableError("offline"),
        )
        remote = _MockAdapter("remote", return_value="remote-saved-the-day")
        m = _manager_with(local, remote)
        result = await m.read(lambda a: a.some_op())
        assert result == "remote-saved-the-day"
        # Local was tried + degraded; remote took over.
        assert m.states()["local"] == AdapterState.DEGRADED
        assert m.states()["remote"] == AdapterState.HEALTHY

    @pytest.mark.asyncio
    async def test_caller_fault_error_propagates(self):
        # Caller-fault error (not unavailable) must NOT trigger failover —
        # next adapter would fail identically; raise immediately so the
        # caller can fix the underlying problem.
        local = _MockAdapter(
            "local",
            fail_with=_adapter_errors.InvalidArtifactRefError("issue", "9999"),
        )
        remote = _MockAdapter("remote", return_value="remote-result")
        m = _manager_with(local, remote)
        with pytest.raises(_adapter_errors.InvalidArtifactRefError):
            await m.read(lambda a: a.some_op())
        assert remote.calls == []  # remote never consulted

    @pytest.mark.asyncio
    async def test_all_adapters_unavailable_raises_all_failed(self):
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.ForgeUnavailableError("a"),
        )
        remote = _MockAdapter(
            "remote", fail_with=_adapter_errors.ForgeUnavailableError("b"),
        )
        m = _manager_with(local, remote)
        with pytest.raises(AllAdaptersFailedError) as exc_info:
            await m.read(lambda a: a.some_op())
        # Both per-adapter errors captured.
        assert "local" in exc_info.value.errors
        assert "remote" in exc_info.value.errors

    @pytest.mark.asyncio
    async def test_degraded_adapters_skipped(self):
        local = _MockAdapter("local")
        remote = _MockAdapter("remote", return_value="should-not-reach")
        m = _manager_with(local, remote)
        # Pre-degrade local; should skip to remote.
        m._entries[0].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        result = await m.read(lambda a: a.some_op())
        assert result == "should-not-reach"  # i.e., remote did get called
        assert local.calls == []


# ---------------------------------------------------------------------------
# Write-path fan-out
# ---------------------------------------------------------------------------

class TestWriteFanOut:
    @pytest.mark.asyncio
    async def test_canonical_first_then_mirrors(self):
        local = _MockAdapter("local", return_value="canonical-result")
        m1 = _MockAdapter("mirror1")
        m2 = _MockAdapter("mirror2")
        m = _manager_with(local, m1, m2)
        result = await m.write(lambda a: a.some_op())
        assert result == "canonical-result"
        # All three got the call, local first.
        assert local.calls == ["some_op"]
        assert m1.calls == ["some_op"]
        assert m2.calls == ["some_op"]

    @pytest.mark.asyncio
    async def test_canonical_failure_is_fatal(self):
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.ForgeUnavailableError("local-down"),
        )
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        with pytest.raises(ReplicationWriteError) as exc_info:
            await m.write(lambda a: a.some_op(), operation_name="create_issue")
        assert exc_info.value.platform_id == "local"
        assert exc_info.value.operation == "create_issue"
        # Mirror was NOT attempted — local is canonical, fatal failure.
        assert mirror.calls == []
        assert m.states()["local"] == AdapterState.DEGRADED

    @pytest.mark.asyncio
    async def test_mirror_unavailable_does_not_fail_call(self):
        # A mirror going down should not affect the caller — the
        # canonical write succeeded, the mirror's failure becomes a
        # queued replay.
        local = _MockAdapter("local", return_value="local-ok")
        mirror = _MockAdapter(
            "mirror", fail_with=_adapter_errors.ForgeUnavailableError("mirror-down"),
        )
        m = _manager_with(local, mirror)
        result = await m.write(
            lambda a: a.some_op(), operation_name="update_issue_body",
        )
        assert result == "local-ok"
        assert m.states()["mirror"] == AdapterState.DEGRADED
        assert m.pending_count("mirror") == 1

    @pytest.mark.asyncio
    async def test_mirror_caller_fault_propagates(self):
        # A 422 / 404 from a mirror is real and shouldn't be silently
        # swallowed — re-raise so caller sees what's wrong.
        local = _MockAdapter("local")
        mirror = _MockAdapter(
            "mirror", fail_with=_adapter_errors.InvalidArtifactRefError("repo", "x"),
        )
        m = _manager_with(local, mirror)
        with pytest.raises(_adapter_errors.InvalidArtifactRefError):
            await m.write(lambda a: a.some_op())

    @pytest.mark.asyncio
    async def test_pre_degraded_mirror_queues_without_call(self):
        local = _MockAdapter("local")
        mirror = _MockAdapter("mirror")
        m = _manager_with(local, mirror)
        # Pre-degrade the mirror.
        m._entries[1].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        await m.write(lambda a: a.some_op())
        # Mirror not called (already known degraded), but operation queued.
        assert mirror.calls == []
        assert m.pending_count("mirror") == 1


class TestOnCanonicalWriteHook:
    """The Hugo live-update hook fires once after every successful
    canonical write — wiring point for SiteRebuilder.notify."""

    @pytest.mark.asyncio
    async def test_hook_fires_after_canonical_success(self):
        local = _MockAdapter("local", return_value="ok")
        captured: list[str] = []
        m = ReplicationManager(
            [("local", local)],  # type: ignore[arg-type]
            on_canonical_write=captured.append,
        )
        await m.write(lambda a: a.some_op(), operation_name="create_issue")
        assert captured == ["create_issue"]

    @pytest.mark.asyncio
    async def test_hook_does_not_fire_on_canonical_failure(self):
        local = _MockAdapter(
            "local", fail_with=_adapter_errors.ForgeUnavailableError("down"),
        )
        captured: list[str] = []
        m = ReplicationManager(
            [("local", local)],  # type: ignore[arg-type]
            on_canonical_write=captured.append,
        )
        with pytest.raises(ReplicationWriteError):
            await m.write(lambda a: a.some_op(), operation_name="create_issue")
        # Hook MUST NOT fire on failure — rebuild on a failed write
        # would publish stale state.
        assert captured == []

    @pytest.mark.asyncio
    async def test_hook_error_doesnt_poison_canonical_write(self):
        """A broken hook (raising callback) doesn't fail the
        underlying write — the canonical store IS authoritative."""
        local = _MockAdapter("local", return_value="ok")

        def broken(name):
            raise RuntimeError("hook is broken")

        m = ReplicationManager(
            [("local", local)],  # type: ignore[arg-type]
            on_canonical_write=broken,
        )
        # Write completes cleanly despite the broken hook.
        result = await m.write(lambda a: a.some_op(), operation_name="create_issue")
        assert result == "ok"


# ---------------------------------------------------------------------------
# State machine transitions
# ---------------------------------------------------------------------------

class TestStateTransitions:
    def test_mark_healthy(self):
        local = _MockAdapter("local")
        m = _manager_with(local)
        m._entries[0].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        m._entries[0].last_error = ValueError("x")  # type: ignore[attr-defined]
        m.mark_healthy("local")
        assert m.states()["local"] == AdapterState.HEALTHY
        assert m._entries[0].last_error is None  # type: ignore[attr-defined]

    def test_mark_reconciling(self):
        m = _manager_with(_MockAdapter("local"))
        m.mark_reconciling("local")
        assert m.states()["local"] == AdapterState.RECONCILING

    def test_mark_unknown_platform_raises(self):
        m = _manager_with(_MockAdapter("local"))
        with pytest.raises(KeyError):
            m.mark_healthy("nonexistent")

    @pytest.mark.asyncio
    async def test_reconciling_skipped_in_read(self):
        local = _MockAdapter("local")
        remote = _MockAdapter("remote", return_value="from-remote")
        m = _manager_with(local, remote)
        m.mark_reconciling("local")
        result = await m.read(lambda a: a.some_op())
        assert result == "from-remote"


# ---------------------------------------------------------------------------
# Healthy-adapters introspection
# ---------------------------------------------------------------------------

class TestIntrospection:
    def test_healthy_adapters_filters_out_degraded(self):
        m = _manager_with(_MockAdapter("a"), _MockAdapter("b"), _MockAdapter("c"))
        m._entries[1].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        m._entries[2].state = AdapterState.RECONCILING  # type: ignore[attr-defined]
        assert m.healthy_adapters() == ["a"]


# ---------------------------------------------------------------------------
# Error types
# ---------------------------------------------------------------------------

class TestErrorTypes:
    def test_replication_write_error_is_replication_error(self):
        assert issubclass(ReplicationWriteError, ReplicationError)

    def test_all_adapters_failed_is_replication_error(self):
        assert issubclass(AllAdaptersFailedError, ReplicationError)

    def test_all_adapters_failed_message_lists_causes(self):
        errors = {
            "local": _adapter_errors.ForgeUnavailableError("net"),
            "remote": _adapter_errors.ForgeUnavailableError("auth"),
        }
        exc = AllAdaptersFailedError(errors)
        msg = str(exc)
        assert "local" in msg and "remote" in msg
        assert exc.errors == errors


class TestReplayPendingWrites:
    """#274 Phase D — drain DEGRADED-adapter pending_writes once the
    backend is reachable again."""

    @staticmethod
    def _toggleable_adapter(platform_id: str):
        """A mock adapter whose probe()/some_op() can be flipped from
        unavailable → healthy mid-test by toggling ``self.online``."""
        class _T:
            def __init__(self, pid: str):
                self.platform_id = pid
                self.online = False
                self.replays: list[str] = []

            async def probe(self) -> bool:
                return self.online

            async def some_op(self, marker: str) -> str:
                if not self.online:
                    raise _adapter_errors.ForgeUnavailableError("offline")
                self.replays.append(marker)
                return marker
        return _T(platform_id)

    @pytest.mark.asyncio
    async def test_drains_when_probe_passes(self):
        canonical = _MockAdapter("local")
        remote = self._toggleable_adapter("remote")
        manager = _manager_with(canonical, remote)  # type: ignore[arg-type]

        # Two writes hit the canonical, fan out to remote which is
        # unavailable → both queue in pending_writes.
        for marker in ("first", "second"):
            await manager.write(
                lambda a, m=marker: a.some_op(m),
                operation_name="some_op",
            )
        assert manager.pending_count("remote") == 2
        assert manager.states()["remote"] == AdapterState.DEGRADED

        # Bring the remote back online and replay.
        remote.online = True
        report = await manager.replay_pending_writes()

        assert report["remote"]["queued_before"] == 2
        assert report["remote"]["replayed"] == 2
        assert report["remote"]["still_pending"] == 0
        assert manager.pending_count("remote") == 0
        # The op callable carried the original markers — replay
        # observed both.
        assert remote.replays == ["first", "second"]
        # Drain restored the adapter to HEALTHY.
        assert manager.states()["remote"] == AdapterState.HEALTHY

    @pytest.mark.asyncio
    async def test_probe_failure_leaves_queue_intact(self):
        canonical = _MockAdapter("local")
        remote = self._toggleable_adapter("remote")
        manager = _manager_with(canonical, remote)  # type: ignore[arg-type]

        await manager.write(
            lambda a: a.some_op("payload"),
            operation_name="some_op",
        )
        assert manager.pending_count("remote") == 1

        # Probe still fails — don't drain.
        report = await manager.replay_pending_writes()
        assert report["remote"]["probe_failed"] is True
        assert report["remote"]["replayed"] == 0
        assert report["remote"]["still_pending"] == 1
        assert manager.pending_count("remote") == 1
        # State stays DEGRADED.
        assert manager.states()["remote"] == AdapterState.DEGRADED

    @pytest.mark.asyncio
    async def test_canonical_excluded_from_drain(self):
        """The canonical store never has pending_writes (failed
        canonical writes raise immediately), so the report should
        omit it even when explicitly asked."""
        canonical = _MockAdapter("local")
        remote = self._toggleable_adapter("remote")
        manager = _manager_with(canonical, remote)  # type: ignore[arg-type]

        report = await manager.replay_pending_writes()
        assert "local" not in report

    @pytest.mark.asyncio
    async def test_partial_drain_when_replay_re_fails(self):
        """If the adapter probes healthy but a replayed op still
        fails with unavailable, that entry stays queued for next
        replay — it's not dropped."""
        canonical = _MockAdapter("local")

        class _Flaky:
            def __init__(self):
                self.platform_id = "remote"
                self.online = True
                self.fail_first = True

            async def probe(self) -> bool:
                return self.online

            async def some_op(self, *args, **kwargs):
                if self.fail_first:
                    self.fail_first = False
                    raise _adapter_errors.ForgeUnavailableError("flaky")
                return "ok"

        remote = _Flaky()
        manager = _manager_with(canonical, remote)  # type: ignore[arg-type]

        # Force two pending writes (set state DEGRADED so the writes
        # queue without trying).
        manager.mark_reconciling("remote")
        manager._entries[1].state = AdapterState.DEGRADED  # type: ignore[attr-defined]
        for _ in range(2):
            await manager.write(
                lambda a: a.some_op(),
                operation_name="some_op",
            )
        assert manager.pending_count("remote") == 2

        report = await manager.replay_pending_writes()
        assert report["remote"]["queued_before"] == 2
        # First op fails, second succeeds.
        assert report["remote"]["replayed"] == 1
        assert report["remote"]["failed"] == 1
        assert report["remote"]["still_pending"] == 1
        # Adapter still DEGRADED because the queue isn't fully drained.
        assert manager.states()["remote"] == AdapterState.DEGRADED


class TestLocalChangesSince:
    """#274 Phase D — time-window complement to compute_drifts.
    Delegates to canonical adapter's aggregate_history_since when
    available; raises NotImplementedError when canonical doesn't
    expose history (i.e., remote-only canonical configurations)."""

    @pytest.mark.asyncio
    async def test_delegates_to_canonical_when_method_present(self):
        from datetime import datetime, timezone

        class _HistoricalAdapter:
            platform_id = "local"

            def __init__(self):
                self.calls: list[dict] = []

            async def aggregate_history_since(
                self, *, since, kind=None, owner="", repo="",
            ):
                self.calls.append({
                    "since": since, "kind": kind,
                    "owner": owner, "repo": repo,
                })
                return ["sentinel-entry"]

        canonical = _HistoricalAdapter()
        manager = _manager_with(canonical)  # type: ignore[arg-type]

        marker = datetime.now(timezone.utc)
        result = await manager.local_changes_since(
            since=marker, kind="issue", owner="o", repo="r",
        )
        assert result == ["sentinel-entry"]
        assert len(canonical.calls) == 1
        assert canonical.calls[0]["since"] == marker
        assert canonical.calls[0]["kind"] == "issue"

    @pytest.mark.asyncio
    async def test_raises_when_canonical_lacks_method(self):
        from datetime import datetime, timezone

        # Plain _MockAdapter has no aggregate_history_since attribute.
        canonical = _MockAdapter("remote-canonical")
        manager = _manager_with(canonical)

        with pytest.raises(NotImplementedError, match="aggregate_history_since"):
            await manager.local_changes_since(since=datetime.now(timezone.utc))


class TestImportRemoteChanges:
    """#274 Phase D — orchestrator for the OQ4 import_remote_changes
    flow. Foundation only: tests use mocked source adapters; live
    fetch_remote_changes implementations are deferred per the
    project-level GitHub-defer directive."""

    @staticmethod
    def _stub_source(platform_id: str, changes: list):
        """Mock a remote source adapter with a configurable change feed."""

        class _Source:
            def __init__(self, pid, payload):
                self.platform_id = pid
                self._changes = list(payload)
                self.fetch_calls: list[dict] = []

            async def fetch_remote_changes(
                self, *, since, owner="", repo="",
            ):
                self.fetch_calls.append({
                    "since": since, "owner": owner, "repo": repo,
                })
                return list(self._changes)

        return _Source(platform_id, changes)

    @staticmethod
    def _stub_canonical():
        """Mock a canonical adapter with apply_remote_change. The mock
        records each change applied; configurable conflict-mode lets
        the test return ImportConflict for specific operations."""
        from forge_manager_mcp.adapters.types import ImportConflict

        class _Canonical:
            def __init__(self):
                self.platform_id = "local"
                self.applied: list = []
                self.conflict_on_op: str | None = None

            async def apply_remote_change(self, change):
                if self.conflict_on_op and change.operation == self.conflict_on_op:
                    return ImportConflict(
                        change=change,
                        reason="synthetic conflict for test",
                    )
                self.applied.append(change)
                return None

        return _Canonical()

    @pytest.mark.asyncio
    async def test_routes_changes_from_source_to_canonical(self):
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import ArtifactRef, RemoteChange

        ref = ArtifactRef(
            platform_id="github", native_id="I_x",
            kind="issue", owner="o", repo="r", number=1,
        )
        ts = datetime.now(timezone.utc)
        change = RemoteChange(
            source_platform_id="github", ref=ref,
            operation="update_body", observed_at=ts,
            payload={"new_body": "imported"},
        )

        canonical = self._stub_canonical()
        source = self._stub_source("github", [change])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        report = await manager.import_remote_changes(
            source_platform_id="github", since=ts,
        )
        assert len(report.applied) == 1
        assert report.applied[0].operation == "update_body"
        assert report.conflicts == []
        assert canonical.applied == [change]
        # Source got the right since/owner/repo.
        assert source.fetch_calls[0]["since"] == ts

    @pytest.mark.asyncio
    async def test_conflicts_route_to_conflicts_list(self):
        from datetime import datetime, timezone
        from forge_manager_mcp.adapters.types import ArtifactRef, RemoteChange

        ref = ArtifactRef(
            platform_id="github", native_id="I_x",
            kind="issue", owner="o", repo="r", number=1,
        )
        ts = datetime.now(timezone.utc)
        clean = RemoteChange(
            source_platform_id="github", ref=ref,
            operation="update_body", observed_at=ts,
        )
        conflicting = RemoteChange(
            source_platform_id="github", ref=ref,
            operation="close_issue", observed_at=ts,
        )

        canonical = self._stub_canonical()
        canonical.conflict_on_op = "close_issue"
        source = self._stub_source("github", [clean, conflicting])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        report = await manager.import_remote_changes(
            source_platform_id="github", since=ts,
        )
        assert len(report.applied) == 1
        assert len(report.conflicts) == 1
        assert report.conflicts[0].change.operation == "close_issue"

    @pytest.mark.asyncio
    async def test_unknown_source_platform_raises(self):
        from datetime import datetime, timezone

        canonical = self._stub_canonical()
        source = self._stub_source("github", [])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(KeyError, match="bitbucket"):
            await manager.import_remote_changes(
                source_platform_id="bitbucket",
                since=datetime.now(timezone.utc),
            )

    @pytest.mark.asyncio
    async def test_canonical_as_source_raises(self):
        """Importing from the canonical itself is a programmer error
        — the canonical is the sink, not a remote source."""
        from datetime import datetime, timezone

        canonical = self._stub_canonical()
        source = self._stub_source("github", [])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(ValueError, match="canonical adapter"):
            await manager.import_remote_changes(
                source_platform_id="local",
                since=datetime.now(timezone.utc),
            )

    @pytest.mark.asyncio
    async def test_canonical_without_apply_method_raises(self):
        from datetime import datetime, timezone

        # Plain _MockAdapter has no apply_remote_change.
        canonical = _MockAdapter("local")
        source = self._stub_source("github", [])
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(NotImplementedError, match="apply_remote_change"):
            await manager.import_remote_changes(
                source_platform_id="github",
                since=datetime.now(timezone.utc),
            )

    @pytest.mark.asyncio
    async def test_source_not_implemented_propagates(self):
        from datetime import datetime, timezone

        class _UnimplementedSource:
            platform_id = "github"
            async def fetch_remote_changes(self, *, since, owner="", repo=""):
                raise NotImplementedError("no fetch implementation yet")

        canonical = self._stub_canonical()
        source = _UnimplementedSource()
        manager = _manager_with(canonical, source)  # type: ignore[arg-type]

        with pytest.raises(NotImplementedError, match="no fetch"):
            await manager.import_remote_changes(
                source_platform_id="github",
                since=datetime.now(timezone.utc),
            )


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
