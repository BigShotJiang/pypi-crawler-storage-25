"""Unit tests for github.py — Issue operations.

Covers create_issue, get_issue_body, close_issue.
"""
from __future__ import annotations

import json
import httpx
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from forge_manager_mcp.github.core import GitHubError
from forge_manager_mcp.github.issues import (
    close_issue,
    create_issue,
    get_issue_body,
)


TOKEN = "ghp_test_token"


def _mock_response(data: dict, status_code: int = 200):
    mock = MagicMock()
    mock.status_code = status_code
    mock.json.return_value = data
    mock.text = json.dumps(data)
    return mock


class TestCreateIssue:
    @pytest.mark.asyncio
    async def test_success(self):
        response_data = {
            "data": {
                "createIssue": {
                    "issue": {
                        "id": "I_issue123",
                        "number": 3,
                        "url": "https://github.com/owner/repo/issues/3",
                    }
                }
            }
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            result = await create_issue(
                TOKEN, "R_repo123", "Bug title", "Bug body", ["LA_label123"]
            )
        assert result["number"] == 3

    @pytest.mark.asyncio

    async def test_empty_title_raises(self):
        with pytest.raises(ValueError, match="title"):
            await create_issue(TOKEN, "R_repo123", "", "body", [])

    @pytest.mark.asyncio
    async def test_with_milestone_id_passes_to_mutation(self):
        """#232 — milestone_id flows through to the GraphQL mutation as
        the milestoneId variable."""
        response_data = {
            "data": {
                "createIssue": {
                    "issue": {"id": "I_x", "number": 5, "url": "https://x"}
                }
            }
        }
        captured = {}

        def _capture(url, *, headers=None, json=None, **_):
            captured["query"] = json["query"]
            captured["variables"] = json["variables"]
            return _mock_response(response_data)

        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(side_effect=_capture)):
            await create_issue(
                TOKEN, "R_repo", "Title", "Body", ["LA_x"],
                milestone_id="MI_milestone10",
            )

        assert captured["variables"]["milestoneId"] == "MI_milestone10"
        assert "$milestoneId: ID" in captured["query"]
        assert "milestoneId: $milestoneId" in captured["query"]

    @pytest.mark.asyncio
    async def test_without_milestone_id_passes_null(self):
        """#232 — default milestone_id=None becomes JSON null (== no
        assignment) without breaking the existing call signature."""
        response_data = {
            "data": {
                "createIssue": {
                    "issue": {"id": "I_x", "number": 6, "url": "https://x"}
                }
            }
        }
        captured = {}

        def _capture(url, *, headers=None, json=None, **_):
            captured["variables"] = json["variables"]
            return _mock_response(response_data)

        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(side_effect=_capture)):
            await create_issue(TOKEN, "R_repo", "Title", "Body", ["LA_x"])

        assert captured["variables"]["milestoneId"] is None


class TestGetIssueBody:
    @pytest.mark.asyncio
    async def test_success(self):
        response_data = {"data": {"node": {"body": "## Overview\nsubtasks..."}}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            body = await get_issue_body(TOKEN, "I_abc123")
        assert "Overview" in body

    @pytest.mark.asyncio

    async def test_missing_issue_raises(self):
        response_data = {"data": {"node": None}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(GitHubError, match="not found"):
                await get_issue_body(TOKEN, "I_missing")

    @pytest.mark.asyncio

    async def test_empty_id_raises(self):
        with pytest.raises(ValueError, match="issue_id"):
            await get_issue_body(TOKEN, "")


class TestCloseIssue:
    @pytest.mark.asyncio
    async def test_completed(self):
        response_data = {
            "data": {
                "closeIssue": {
                    "issue": {
                        "url": "https://github.com/o/r/issues/42",
                        "closedAt": "2026-04-23T17:00:00Z",
                    }
                }
            }
        }
        captured = {}

        def _capture(url, *, headers=None, json=None, **_):
            captured["variables"] = json.get("variables", {})
            return _mock_response(response_data)

        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(side_effect=_capture)):
            out = await close_issue(TOKEN, "I_abc", state_reason="completed")
        assert out["url"].endswith("/42")
        assert out["closed_at"].startswith("2026-04-23")
        assert captured["variables"]["reason"] == "COMPLETED"

    @pytest.mark.asyncio

    async def test_not_planned(self):
        response_data = {
            "data": {
                "closeIssue": {
                    "issue": {
                        "url": "https://github.com/o/r/issues/43",
                        "closedAt": "2026-04-23T18:00:00Z",
                    }
                }
            }
        }
        captured = {}

        def _capture(url, *, headers=None, json=None, **_):
            captured["variables"] = json.get("variables", {})
            return _mock_response(response_data)

        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(side_effect=_capture)):
            await close_issue(TOKEN, "I_abc", state_reason="not_planned")
        assert captured["variables"]["reason"] == "NOT_PLANNED"

    @pytest.mark.asyncio

    async def test_empty_issue_id_raises(self):
        with pytest.raises(ValueError, match="issue_id"):
            await close_issue(TOKEN, "", state_reason="completed")

    @pytest.mark.asyncio

    async def test_invalid_state_reason_raises(self):
        with pytest.raises(ValueError, match="state_reason"):
            await close_issue(TOKEN, "I_abc", state_reason="bogus")
if __name__ == "__main__":
    import sys
    import pytest
    sys.exit(pytest.main([__file__, "-v"]))
