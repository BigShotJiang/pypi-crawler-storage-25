"""Per-step unit tests for the release flow interceptor wrappers (#294 Phase A).

Mock-context pattern per #292: each test passes a synthetic
``Context`` to the step's enter or error handler and asserts the
resulting Context's response / steps_taken / error shape. The
underlying ``_run_*`` callables in handlers/release.py are
monkey-patched per-test so the wrappers' pass-through semantics
test in isolation from the handler's real GitHub / git / pypi work.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from forge_manager_mcp.flows.release import build_release_chain
from forge_manager_mcp.flows.release.dev_tag import make_dev_tag_interceptor
from forge_manager_mcp.flows.release.mirror_sync import (
    make_mirror_sync_interceptor,
)
from forge_manager_mcp.flows.release.mirror_tag import (
    make_mirror_tag_interceptor,
)
from forge_manager_mcp.flows.release.pypi_publish import (
    make_pypi_publish_interceptor,
)
from forge_manager_mcp.flows.release.release_notes import (
    make_release_notes_interceptor,
)
from forge_manager_mcp.flows.release.validate import (
    ReleaseStepFailed,
    make_validate_interceptor,
)
from forge_manager_mcp.interceptors import Context


def _server_ctx_stub(tmp_path: Path) -> SimpleNamespace:
    """A SimpleNamespace masquerading as a ServerContext for the
    enter handlers' field accesses (project_dir, github_token,
    config.repos, etc.). The wrapper tests don't run the underlying
    _run_* — those are stubbed — so the namespace just carries enough
    fields for argument extraction."""
    return SimpleNamespace(
        project_dir=tmp_path,
        github_token="ghp_test",
        config=SimpleNamespace(
            repos=SimpleNamespace(
                public="o/repo",
                private="o/repo-dev",
                docs="o/repo-docs",
            ),
        ),
    )


def _request(server_ctx, **kwargs) -> dict:
    base = {
        "server_ctx": server_ctx,
        "version": "9.9.9",
        "notes": "test notes",
        "skip_bazel": False,
        "pypi_only": False,
        "dry_run": True,
    }
    base.update(kwargs)
    return base


# ---------------------------------------------------------------------------
# validate
# ---------------------------------------------------------------------------

class TestValidateStep:
    @pytest.mark.asyncio
    async def test_enter_records_response_and_repo_role(
        self, tmp_path: Path, monkeypatch
    ):
        run_validate = AsyncMock(
            return_value=(
                {"step": "validate", "status": "ok",
                 "data": {"checks": []}},
                [],
                "skill",
            )
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_validate",
            run_validate,
        )

        ic = make_validate_interceptor()
        ctx = Context(request=_request(_server_ctx_stub(tmp_path)))
        result = await ic.enter(ctx)

        assert result.error is None
        assert "validate" in result.response
        assert result.response["validate"]["status"] == "ok"
        assert result.response["validate"]["repo_role"] == "skill"
        # repo_role threaded onto request for downstream steps.
        assert result.request["repo_role"] == "skill"
        # steps_taken records the forward entry.
        assert result.steps_taken[-1]["step"] == "validate"

    @pytest.mark.asyncio
    async def test_enter_failure_sets_chain_error(
        self, tmp_path: Path, monkeypatch
    ):
        run_validate = AsyncMock(
            return_value=(
                {"step": "validate", "status": "failed", "data": {}},
                [{"name": "milestone_closed", "ok": False, "severity": "fail"}],
                "monorepo",
            )
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_validate",
            run_validate,
        )

        ic = make_validate_interceptor()
        ctx = Context(request=_request(_server_ctx_stub(tmp_path)))
        result = await ic.enter(ctx)

        assert isinstance(result.error, ReleaseStepFailed)
        assert "validate failed" in str(result.error)
        # Response still records the validate state for the chain
        # unwind / handler to surface.
        assert result.response["validate"]["status"] == "failed"

    @pytest.mark.asyncio
    async def test_error_is_passthrough(self, tmp_path: Path):
        ic = make_validate_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            error=ReleaseStepFailed("upstream"),
        )
        result = await ic.error(ctx)
        # validate is read-only — no compensation, error passes through.
        assert result.error is ctx.error


# ---------------------------------------------------------------------------
# dev_tag
# ---------------------------------------------------------------------------

class TestDevTagStep:
    @pytest.mark.asyncio
    async def test_enter_dry_run(self, tmp_path: Path, monkeypatch):
        run_dev_tag = MagicMock(
            return_value={
                "step": "dev_tag",
                "status": "dry_run_preview",
                "data": {"tag": "v9.9.9", "sha": "abc"},
            }
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_dev_tag",
            run_dev_tag,
        )
        ic = make_dev_tag_interceptor()
        ctx = Context(request=_request(_server_ctx_stub(tmp_path)))
        result = await ic.enter(ctx)
        assert result.error is None
        assert result.response["dev_tag"]["status"] == "dry_run_preview"

    @pytest.mark.asyncio
    async def test_error_no_compensation_when_step_didnt_succeed(
        self, tmp_path: Path,
    ):
        ic = make_dev_tag_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={"dev_tag": {"status": "dry_run_preview"}},
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        # No compensation appended for non-ok dev_tag state.
        forward_steps = [s for s in result.steps_taken if not s.get("compensated")]
        compensation = [s for s in result.steps_taken if s.get("compensated")]
        assert compensation == []

    @pytest.mark.asyncio
    async def test_error_calls_delete_tag_compensation(
        self, tmp_path: Path, monkeypatch,
    ):
        # delete_tag exists in releases_mod (#294 Phase A primitive).
        # Compensation invokes it; the test asserts the call rather
        # than the failed_compensations fallback the placeholder
        # used to surface pre-primitive.
        delete_tag = MagicMock()
        monkeypatch.setattr(
            "forge_manager_mcp.github.releases.delete_tag", delete_tag,
        )
        ic = make_dev_tag_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={
                "dev_tag": {
                    "status": "ok",
                    "data": {"tag": "v9.9.9"},
                }
            },
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        delete_tag.assert_called_once()
        args = delete_tag.call_args.args
        # Wrapper passes (project_dir, "origin", tag).
        assert args[1] == "origin"
        assert args[2] == "v9.9.9"
        # No failed_compensations — compensation succeeded cleanly.
        assert "failed_compensations" not in result.response
        # Compensated marker landed in steps_taken.
        assert any(
            s.get("compensated") and s["step"] == "dev_tag"
            for s in result.steps_taken
        )

    @pytest.mark.asyncio
    async def test_error_records_failed_compensation_on_delete_failure(
        self, tmp_path: Path, monkeypatch,
    ):
        # delete_tag exists but raises (e.g., not a git repo). The
        # wrapper surfaces a failed_compensations entry so the
        # operator sees the gap.
        delete_tag = MagicMock(side_effect=RuntimeError("not a git repo"))
        monkeypatch.setattr(
            "forge_manager_mcp.github.releases.delete_tag", delete_tag,
        )
        ic = make_dev_tag_interceptor()
        ctx = Context(
            request=_request(_server_ctx_stub(tmp_path)),
            response={
                "dev_tag": {
                    "status": "ok",
                    "data": {"tag": "v9.9.9"},
                }
            },
            error=ReleaseStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        assert "failed_compensations" in result.response
        failed = result.response["failed_compensations"]
        assert any(f["step"] == "dev_tag" for f in failed)


# ---------------------------------------------------------------------------
# mirror_sync / mirror_tag / release_notes / pypi_publish — minimal coverage
# ---------------------------------------------------------------------------

class TestMirrorSyncStep:
    @pytest.mark.asyncio
    async def test_enter_threads_mirror_clone(
        self, tmp_path: Path, monkeypatch,
    ):
        clone_path = tmp_path / "mirror"
        run_mirror_sync = MagicMock(
            return_value=(
                {"step": "mirror_sync", "status": "ok", "data": {}},
                clone_path,
            )
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_mirror_sync",
            run_mirror_sync,
        )
        ic = make_mirror_sync_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path), repo_role="skill"
            )
        )
        result = await ic.enter(ctx)
        assert result.request["mirror_clone"] == clone_path
        assert result.response["mirror_sync"]["status"] == "ok"


class TestMirrorTagStep:
    @pytest.mark.asyncio
    async def test_enter_consumes_mirror_clone_from_request(
        self, tmp_path: Path, monkeypatch,
    ):
        run_mirror_tag = MagicMock(
            return_value={
                "step": "mirror_tag",
                "status": "ok",
                "data": {"tag": "v9.9.9"},
            }
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_mirror_tag",
            run_mirror_tag,
        )
        ic = make_mirror_tag_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path),
                repo_role="skill",
                mirror_clone=tmp_path / "mirror",
            )
        )
        result = await ic.enter(ctx)
        assert result.response["mirror_tag"]["status"] == "ok"
        # _run_mirror_tag received the mirror_clone we threaded in.
        # Real signature: (mirror_clone, version, notes, dry_run) — so
        # mirror_clone is positional arg 0.
        run_mirror_tag.assert_called_once()
        kwargs_or_args = run_mirror_tag.call_args
        assert kwargs_or_args.args[0] == tmp_path / "mirror"


class TestReleaseNotesStep:
    @pytest.mark.asyncio
    async def test_enter_pass_through(
        self, tmp_path: Path, monkeypatch,
    ):
        run_release_notes = MagicMock(
            return_value={
                "step": "release_notes",
                "status": "ok",
                "data": {},
            }
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_release_notes",
            run_release_notes,
        )
        ic = make_release_notes_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path), repo_role="skill",
            )
        )
        result = await ic.enter(ctx)
        assert result.response["release_notes"]["status"] == "ok"


class TestPypiPublishStep:
    @pytest.mark.asyncio
    async def test_enter_pass_through(
        self, tmp_path: Path, monkeypatch,
    ):
        run_pypi = MagicMock(
            return_value={
                "step": "pypi_publish",
                "status": "ok",
                "data": {},
            }
        )
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_pypi_publish",
            run_pypi,
        )
        ic = make_pypi_publish_interceptor()
        ctx = Context(
            request=_request(
                _server_ctx_stub(tmp_path),
                repo_role="mcp",
            )
        )
        result = await ic.enter(ctx)
        assert result.response["pypi_publish"]["status"] == "ok"


# ---------------------------------------------------------------------------
# Chain composer
# ---------------------------------------------------------------------------

class TestBuildReleaseChain:
    def test_full_chain_ordering(self):
        chain = build_release_chain()
        names = [ic.name for ic in chain]
        assert names == [
            "release.validate",
            "release.dev_tag",
            "release.mirror_sync",
            "release.mirror_tag",
            "release.release_notes",
        ]

    def test_pypi_only_chain_skips_github_steps(self):
        chain = build_release_chain(pypi_only=True)
        names = [ic.name for ic in chain]
        assert names == ["release.validate", "release.pypi_publish"]

    def test_stop_after_truncates_chain(self):
        chain = build_release_chain(stop_after="dev_tag")
        names = [ic.name for ic in chain]
        assert names == ["release.validate", "release.dev_tag"]

    def test_pypi_only_overrides_stop_after(self):
        chain = build_release_chain(pypi_only=True, stop_after="dev_tag")
        names = [ic.name for ic in chain]
        # pypi_only path is always validate → pypi_publish, regardless
        # of stop_after.
        assert names == ["release.validate", "release.pypi_publish"]


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
