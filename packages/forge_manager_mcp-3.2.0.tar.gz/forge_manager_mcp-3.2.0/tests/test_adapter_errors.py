"""Unit tests for the adapter error hierarchy + is_forge_unavailable predicate (3.0 / Phase 2)."""
from __future__ import annotations

import httpx
import pytest

from forge_manager_mcp.adapters.errors import (
    ForgeError,
    ForgeUnavailableError,
    InvalidArtifactRefError,
    is_forge_unavailable,
)


class TestSubclassRelationship:
    def test_unavailable_is_a_forge_error(self):
        assert isinstance(ForgeUnavailableError("x"), ForgeError)

    def test_invalid_ref_is_a_forge_error(self):
        assert isinstance(InvalidArtifactRefError("ref", "bad"), ForgeError)

    def test_base_forge_error_not_unavailable(self):
        assert not isinstance(ForgeError("x"), ForgeUnavailableError)

    def test_unavailable_carries_status(self):
        exc = ForgeUnavailableError("rate limit", status_code=429, body="...")
        assert exc.status_code == 429
        assert exc.body == "..."


class TestIsForgeUnavailableTrue:
    """Cases that SHOULD trigger fallback / replay queueing."""

    def test_explicit_unavailable_subclass(self):
        assert is_forge_unavailable(ForgeUnavailableError("any"))

    @pytest.mark.parametrize("status", [401, 403, 429, 502, 503, 504])
    def test_status_codes_classified_as_unavailable(self, status):
        exc = ForgeError("HTTP error", status_code=status, body="")
        assert is_forge_unavailable(exc), (
            f"status {status} should classify as unavailable"
        )

    def test_timeout_chained_via_httpx(self):
        underlying = httpx.TimeoutException("read timeout")
        exc = ForgeError("API request timed out.")
        exc.__cause__ = underlying
        assert is_forge_unavailable(exc)

    def test_connect_error_chained(self):
        underlying = httpx.ConnectError("DNS failed")
        exc = ForgeError("API network error.")
        exc.__cause__ = underlying
        assert is_forge_unavailable(exc)

    def test_user_subclass_of_unavailable(self):
        class CustomOutage(ForgeUnavailableError):
            pass

        assert is_forge_unavailable(CustomOutage("custom"))


class TestIsForgeUnavailableFalse:
    """Cases that should NOT trigger fallback (caller-fault)."""

    @pytest.mark.parametrize("status", [400, 404, 405, 409, 422, 500, 501])
    def test_caller_fault_codes_not_unavailable(self, status):
        exc = ForgeError("HTTP error", status_code=status)
        assert not is_forge_unavailable(exc)

    def test_no_status_no_cause_is_caller_fault(self):
        exc = ForgeError("opaque failure")
        assert not is_forge_unavailable(exc)

    def test_invalid_ref_error_not_unavailable(self):
        # Stale/bad refs are caller-fault; retrying with the same ref
        # would fail identically.
        exc = InvalidArtifactRefError("issue_id", "I_kwDObogus")
        assert not is_forge_unavailable(exc)

    def test_arbitrary_chained_cause_not_unavailable(self):
        exc = ForgeError("opaque")
        exc.__cause__ = ValueError("non-httpx cause")
        assert not is_forge_unavailable(exc)

    def test_value_error_not_unavailable(self):
        assert not is_forge_unavailable(ValueError("not a forge error"))

    def test_runtime_error_not_unavailable(self):
        # ForgeError inherits from RuntimeError, but a bare RuntimeError
        # isn't a ForgeError and shouldn't match.
        assert not is_forge_unavailable(RuntimeError("generic"))


class TestEdgeCases:
    def test_none_returns_false(self):
        assert not is_forge_unavailable(None)  # type: ignore[arg-type]

    def test_string_returns_false(self):
        assert not is_forge_unavailable("not an exception")  # type: ignore[arg-type]


class TestInvalidArtifactRefError:
    def test_message_includes_param_name_and_value(self):
        exc = InvalidArtifactRefError("issue_id", "I_kwDObogus")
        assert "issue_id" in str(exc)
        assert "I_kwDObogus" in str(exc)
        assert exc.param_name == "issue_id"
        assert exc.value == "I_kwDObogus"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
