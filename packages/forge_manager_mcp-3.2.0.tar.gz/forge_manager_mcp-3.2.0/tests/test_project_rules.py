"""Unit tests for forge_manager_mcp.project_rules (#288).

Covers:

* Markdown parser — happy path, each section type, malformed entries.
* validate_against_registry — unknown-gate rejection.
* Project-rule → Interceptor conversion — per-section semantics.
* Independent rules don't compose into chains.
* Multiple extensions on the same gate chain in declaration order.
* Opens declarations produce no interceptor.
"""
from __future__ import annotations

import asyncio
import textwrap
from dataclasses import replace
from pathlib import Path

import pytest

from forge_manager_mcp.gate_registry import Gate, GateRegistry
from forge_manager_mcp.interceptors import Context, aexecute
from forge_manager_mcp.project_rules import (
    GateExtension,
    GateOverride,
    GateStateDeclaration,
    IndependentRule,
    ProjectRules,
    ProjectRulesError,
    all_referenced_gate_names,
    build_extension_interceptors,
    build_override_interceptors,
    build_state_interceptors,
    load_project_rules,
    parse_project_rules,
    validate_against_registry,
)


def _make_gate(name: str = "commit.test_coverage") -> Gate:
    return Gate(
        name=name,
        type="pre-commit",
        location=f"c.md#{name}",
        summary=name,
        default_state="open",
        extension_semantics="tighten",
        override_semantics="replace",
        state_change_semantics="open_close",
        rationale_doc=f"c.md#{name}",
        introduced_in="1.0.0",
    )


# ---------------------------------------------------------------------------
# Parser tests
# ---------------------------------------------------------------------------


_FULL_RULES = textwrap.dedent("""\
    # Project Rules — testproj

    ## Independent rules
    Project-internal, no skill interaction.

    ### Use Bazel for all build and test
    Every language uses Bazel. No language-native runners.

    ## Gate extensions
    Tighter rules.

    ### Extends `commit.test_coverage`
    **Extension:** Maximal coverage — every new code path tested in same commit.
    **Why:** Past incident with mocked tests passing while prod broke.
    **Cross-link:** Discussion #70

    ### Extends `commit.diff_covers_plan`
    **Extension:** Skill-prose paired-edit signal must be present.

    ## Gate overrides

    ### Overrides `release.bazel_tests_green`
    **Replacement:** Use the project's wrapper that probes mcp-server/MODULE.bazel.
    **Why:** Monorepo layout.

    ## Gate state declarations

    ### Closes `commit.llm_verifier`
    **Reason:** ANTHROPIC_API_KEY not configured.
    **Re-open when:** key is provisioned.

    ### Opens `commit.plan_validation`
    **Reason:** Always-on for this project.
""")


class TestParser:
    def test_full_document(self) -> None:
        rules = parse_project_rules(_FULL_RULES)
        # Independent
        assert len(rules.independent) == 1
        assert rules.independent[0].name == "Use Bazel for all build and test"
        # Extensions
        assert "commit.test_coverage" in rules.extensions
        assert "commit.diff_covers_plan" in rules.extensions
        ext = rules.extensions["commit.test_coverage"][0]
        assert ext.extension.startswith("Maximal coverage")
        assert ext.why is not None
        assert ext.cross_link == "Discussion #70"
        # Overrides
        assert "release.bazel_tests_green" in rules.overrides
        ovr = rules.overrides["release.bazel_tests_green"][0]
        assert "wrapper" in ovr.replacement
        # State declarations — Closes is captured, Opens is filtered out
        assert "commit.llm_verifier" in rules.state_declarations
        assert "commit.plan_validation" not in rules.state_declarations
        decl = rules.state_declarations["commit.llm_verifier"]
        assert decl.state == "closed"
        assert decl.reason and "ANTHROPIC" in decl.reason

    def test_empty_document(self) -> None:
        rules = parse_project_rules("# Project Rules\n")
        assert rules.independent == ()
        assert rules.extensions == {}
        assert rules.overrides == {}
        assert rules.state_declarations == {}

    def test_malformed_extension_heading(self) -> None:
        body = textwrap.dedent("""\
            ## Gate extensions

            ### Extends commit.test_coverage
            **Extension:** missing backticks
        """)
        with pytest.raises(ProjectRulesError, match="malformed"):
            parse_project_rules(body)

    def test_extension_missing_required_field(self) -> None:
        body = textwrap.dedent("""\
            ## Gate extensions

            ### Extends `commit.test_coverage`
            **Why:** no extension field present
        """)
        with pytest.raises(ProjectRulesError, match="Extension"):
            parse_project_rules(body)

    def test_override_missing_required_field(self) -> None:
        body = textwrap.dedent("""\
            ## Gate overrides

            ### Overrides `commit.test_coverage`
            **Why:** no replacement field
        """)
        with pytest.raises(ProjectRulesError, match="Replacement"):
            parse_project_rules(body)

    def test_wrong_verb_in_section(self) -> None:
        body = textwrap.dedent("""\
            ## Gate overrides

            ### Extends `commit.test_coverage`
            **Replacement:** ...
        """)
        with pytest.raises(ProjectRulesError, match="Overrides"):
            parse_project_rules(body)

    def test_multiple_extensions_same_gate(self) -> None:
        body = textwrap.dedent("""\
            ## Gate extensions

            ### Extends `commit.test_coverage`
            **Extension:** First.

            ### Extends `commit.test_coverage`
            **Extension:** Second.
        """)
        rules = parse_project_rules(body)
        exts = rules.extensions["commit.test_coverage"]
        assert len(exts) == 2
        assert exts[0].extension == "First."
        assert exts[1].extension == "Second."

    def test_duplicate_state_declaration_raises(self) -> None:
        body = textwrap.dedent("""\
            ## Gate state declarations

            ### Closes `commit.llm_verifier`
            **Reason:** First.

            ### Closes `commit.llm_verifier`
            **Reason:** Second.
        """)
        with pytest.raises(ProjectRulesError, match="duplicate"):
            parse_project_rules(body)

    def test_unknown_section_silently_skipped(self) -> None:
        body = textwrap.dedent("""\
            ## Project notes
            arbitrary commentary

            ## Gate extensions

            ### Extends `commit.test_coverage`
            **Extension:** rule
        """)
        rules = parse_project_rules(body)
        assert "commit.test_coverage" in rules.extensions

    def test_load_missing_file(self, tmp_path: Path) -> None:
        with pytest.raises(ProjectRulesError, match="not found"):
            load_project_rules(tmp_path / "absent.md")

    def test_load_round_trip(self, tmp_path: Path) -> None:
        path = tmp_path / "project-rules.md"
        path.write_text(_FULL_RULES)
        rules = load_project_rules(path)
        assert "commit.test_coverage" in rules.extensions


# ---------------------------------------------------------------------------
# Validation tests
# ---------------------------------------------------------------------------


class TestValidateAgainstRegistry:
    def test_known_gates_pass(self) -> None:
        rules = parse_project_rules(_FULL_RULES)
        registry = GateRegistry([
            _make_gate("commit.test_coverage"),
            _make_gate("commit.diff_covers_plan"),
            _make_gate("release.bazel_tests_green"),
            _make_gate("commit.llm_verifier"),
        ])
        validate_against_registry(rules, registry)  # does not raise

    def test_unknown_gate_in_extension(self) -> None:
        rules = parse_project_rules(_FULL_RULES)
        registry = GateRegistry([_make_gate("commit.test_coverage")])
        with pytest.raises(ProjectRulesError, match="unknown gates"):
            validate_against_registry(rules, registry)

    def test_lists_all_unknown(self) -> None:
        rules = parse_project_rules(_FULL_RULES)
        registry = GateRegistry([])
        with pytest.raises(ProjectRulesError) as exc_info:
            validate_against_registry(rules, registry)
        msg = str(exc_info.value)
        assert "Extends `commit.test_coverage`" in msg
        assert "Overrides `release.bazel_tests_green`" in msg
        assert "Closes `commit.llm_verifier`" in msg


# ---------------------------------------------------------------------------
# Interceptor conversion tests
# ---------------------------------------------------------------------------


class TestStateInterceptors:
    def test_closed_produces_halting_interceptor(self) -> None:
        rules = parse_project_rules(_FULL_RULES)
        gate = _make_gate("commit.llm_verifier")
        chain = build_state_interceptors(gate, rules)
        assert len(chain) == 1
        # Run the chain with a placeholder downstream evaluator that
        # would write a passing response — the closed interceptor
        # should halt before that runs.
        async def downstream(ctx: Context) -> Context:
            return replace(
                ctx, response={**ctx.response, gate.name: {"verdict": "passed"}}
            )
        from forge_manager_mcp.interceptors import Interceptor

        downstream_ic = Interceptor(enter=downstream)
        ctx = asyncio.run(aexecute(chain + [downstream_ic]))
        assert ctx.halt is True
        gate_resp = ctx.response[gate.name]
        assert gate_resp["state"] == "closed"
        assert gate_resp["source"] == "project_rules.state_declarations"
        assert "ANTHROPIC" in gate_resp["reason"]
        # Halt prevented downstream from contributing "verdict: passed"
        assert "verdict" not in gate_resp

    def test_no_decl_produces_empty_chain(self) -> None:
        rules = parse_project_rules(_FULL_RULES)
        gate = _make_gate("commit.test_coverage")  # has extension, no closure
        chain = build_state_interceptors(gate, rules)
        assert chain == []


class TestOverrideInterceptors:
    def test_override_halts_with_replacement(self) -> None:
        rules = parse_project_rules(_FULL_RULES)
        gate = _make_gate("release.bazel_tests_green")
        chain = build_override_interceptors(gate, rules)
        assert len(chain) == 1
        ctx = asyncio.run(aexecute(chain))
        assert ctx.halt is True
        gate_resp = ctx.response[gate.name]
        assert gate_resp["verdict"] == "override"
        assert "wrapper" in gate_resp["replacement"]


class TestExtensionInterceptors:
    def test_extension_augments_request_and_response(self) -> None:
        rules = parse_project_rules(_FULL_RULES)
        gate = _make_gate("commit.test_coverage")
        chain = build_extension_interceptors(gate, rules)
        assert len(chain) == 1

        captured: dict = {}

        async def capture_request(ctx: Context) -> Context:
            captured["request_extensions"] = list(ctx.request.get("extensions", ()))
            return replace(
                ctx,
                response={**ctx.response, gate.name: {"verdict": "default"}},
            )

        from forge_manager_mcp.interceptors import Interceptor

        inner = Interceptor(enter=capture_request)
        ctx = asyncio.run(aexecute(chain + [inner]))
        # enter saw the augmented request
        assert len(captured["request_extensions"]) == 1
        assert captured["request_extensions"][0]["gate"] == "commit.test_coverage"
        # leave appended to the gate's response
        gate_resp = ctx.response["commit.test_coverage"]
        assert gate_resp["verdict"] == "default"
        assert len(gate_resp["extensions"]) == 1
        assert "Maximal coverage" in gate_resp["extensions"][0]["extension"]

    def test_multiple_extensions_chain_in_declaration_order(self) -> None:
        body = textwrap.dedent("""\
            ## Gate extensions

            ### Extends `commit.test_coverage`
            **Extension:** First.

            ### Extends `commit.test_coverage`
            **Extension:** Second.
        """)
        rules = parse_project_rules(body)
        gate = _make_gate("commit.test_coverage")
        chain = build_extension_interceptors(gate, rules)
        assert len(chain) == 2

        async def downstream(ctx: Context) -> Context:
            return replace(
                ctx,
                response={**ctx.response, gate.name: {"verdict": "default"}},
            )

        from forge_manager_mcp.interceptors import Interceptor

        ctx = asyncio.run(aexecute(chain + [Interceptor(enter=downstream)]))
        gate_resp = ctx.response[gate.name]
        ext_records = gate_resp["extensions"]
        assert len(ext_records) == 2
        # Innermost (Second) leaves first; outermost (First) leaves last —
        # because leave runs in reverse stack order, the response has
        # Second's record first then First's record.
        assert ext_records[0]["extension"] == "Second."
        assert ext_records[1]["extension"] == "First."

    def test_no_extensions_empty_chain(self) -> None:
        rules = parse_project_rules(_FULL_RULES)
        gate = _make_gate("commit.ac_completeness")  # not in fixture
        chain = build_extension_interceptors(gate, rules)
        assert chain == []


class TestAllReferencedGateNames:
    def test_yields_unique_set(self) -> None:
        rules = parse_project_rules(_FULL_RULES)
        names = set(all_referenced_gate_names(rules))
        assert names == {
            "commit.test_coverage",
            "commit.diff_covers_plan",
            "release.bazel_tests_green",
            "commit.llm_verifier",
        }


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
