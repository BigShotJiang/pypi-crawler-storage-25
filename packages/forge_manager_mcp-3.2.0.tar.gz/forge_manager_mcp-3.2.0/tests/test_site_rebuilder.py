"""Unit tests for SiteRebuilder — debounced live-update hook."""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import pytest

from forge_manager_mcp.site_renderer.rebuilder import SiteRebuilder


class _FakeRenderer:
    """Minimal HugoRenderer-shaped stub for tests.

    Records every build() call so tests can assert how many rebuilds
    fired (debounce behavior) and what triggered them. ``failure``
    can be a Pydantic-style sentinel — when truthy, build() raises so
    failure-tolerance tests work.
    """

    def __init__(self, *, failure: Exception | None = None):
        self.builds: list[tuple[Path, Path]] = []
        self.failure = failure

    async def build(self, *, docs_repo: Path, target_dir: Path, **kwargs: Any) -> Path:
        self.builds.append((docs_repo, target_dir))
        if self.failure is not None:
            raise self.failure
        return target_dir


@pytest.fixture
def fake_renderer() -> _FakeRenderer:
    return _FakeRenderer()


def _make_rebuilder(
    fake_renderer: _FakeRenderer,
    tmp_path: Path,
    *,
    debounce_seconds: float = 0.05,
    on_failure=None,
) -> SiteRebuilder:
    return SiteRebuilder(
        docs_repo=tmp_path / "docs",
        target_dir=tmp_path / "out",
        renderer=fake_renderer,  # type: ignore[arg-type]
        debounce_seconds=debounce_seconds,
        on_failure=on_failure,
    )


class TestNotifyAndDebounce:
    @pytest.mark.asyncio
    async def test_single_notify_triggers_one_build(self, fake_renderer, tmp_path):
        rb = _make_rebuilder(fake_renderer, tmp_path)
        rb.notify("create_issue")
        assert rb.has_pending is True
        # Wait past the debounce window.
        await asyncio.sleep(0.1)
        assert len(fake_renderer.builds) == 1
        assert rb.last_build_succeeded is True
        assert rb.has_pending is False

    @pytest.mark.asyncio
    async def test_rapid_notifies_coalesce_to_one_build(
        self, fake_renderer, tmp_path,
    ):
        rb = _make_rebuilder(fake_renderer, tmp_path)
        # Three notifies within the debounce window.
        rb.notify("create_issue")
        rb.notify("add_label")
        rb.notify("append_comment")
        await asyncio.sleep(0.1)
        # Only one build fired.
        assert len(fake_renderer.builds) == 1

    @pytest.mark.asyncio
    async def test_notifies_outside_debounce_window_each_build(
        self, fake_renderer, tmp_path,
    ):
        rb = _make_rebuilder(fake_renderer, tmp_path, debounce_seconds=0.02)
        rb.notify("op-a")
        await asyncio.sleep(0.05)
        rb.notify("op-b")
        await asyncio.sleep(0.05)
        # Two separate windows → two builds.
        assert len(fake_renderer.builds) == 2

    @pytest.mark.asyncio
    async def test_notify_outside_event_loop_doesnt_crash(
        self, fake_renderer, tmp_path,
    ):
        """The hook must be safe to call from sync code paths even
        when no event loop is running. Notifications drop silently
        in that case; a follow-up flush() drains."""
        rb = _make_rebuilder(fake_renderer, tmp_path)
        # Call from a non-async context — no exception should escape.
        # We're inside an async test so a loop IS running; simulate
        # the no-loop case by calling notify then asserting flush
        # still runs the queued op via _last_operations.
        rb.notify("op-a")
        # Flush forces immediate rebuild.
        result = await rb.flush()
        assert result is True
        assert len(fake_renderer.builds) >= 1


class TestFlush:
    @pytest.mark.asyncio
    async def test_flush_with_no_pending_returns_none(
        self, fake_renderer, tmp_path,
    ):
        rb = _make_rebuilder(fake_renderer, tmp_path)
        result = await rb.flush()
        assert result is None
        assert fake_renderer.builds == []

    @pytest.mark.asyncio
    async def test_flush_runs_pending_immediately(self, fake_renderer, tmp_path):
        rb = _make_rebuilder(fake_renderer, tmp_path, debounce_seconds=10)
        rb.notify("op-a")
        # debounce is 10s — without flush, the build wouldn't run for
        # ages. flush() forces it now.
        result = await rb.flush()
        assert result is True
        assert len(fake_renderer.builds) == 1


class TestFailureTolerance:
    @pytest.mark.asyncio
    async def test_build_failure_doesnt_raise(self, tmp_path):
        renderer = _FakeRenderer(failure=RuntimeError("hugo not found"))
        captured: list[Exception] = []
        rb = _make_rebuilder(
            renderer, tmp_path,
            on_failure=captured.append,
        )
        rb.notify("op-a")
        await asyncio.sleep(0.1)
        # Build attempted, failed, but no exception escaped notify().
        assert len(renderer.builds) == 1
        assert rb.last_build_succeeded is False
        # on_failure callback received the exception.
        assert len(captured) == 1
        assert isinstance(captured[0], RuntimeError)

    @pytest.mark.asyncio
    async def test_on_failure_callback_error_doesnt_propagate(self, tmp_path):
        renderer = _FakeRenderer(failure=RuntimeError("rebuild failed"))

        def bad_callback(exc):
            raise ValueError("callback itself broken")

        rb = _make_rebuilder(renderer, tmp_path, on_failure=bad_callback)
        rb.notify("op-a")
        # Should complete cleanly despite the broken callback.
        await asyncio.sleep(0.1)
        assert rb.last_build_succeeded is False


class TestConstructor:
    def test_negative_debounce_raises(self, fake_renderer, tmp_path):
        with pytest.raises(ValueError, match="debounce_seconds"):
            SiteRebuilder(
                docs_repo=tmp_path,
                target_dir=tmp_path,
                renderer=fake_renderer,  # type: ignore[arg-type]
                debounce_seconds=-1.0,
            )


class TestAutoDeploy:
    """Auto-deploy: post-rebuild git push to deploy_target."""

    @pytest.mark.asyncio
    async def test_no_deploy_when_target_unset(self, fake_renderer, tmp_path):
        """Default (deploy_target=None): rebuild succeeds, no deploy
        attempted, last_deploy_succeeded stays None."""
        target = tmp_path / "out"
        target.mkdir()
        rb = SiteRebuilder(
            docs_repo=tmp_path / "docs",
            target_dir=target,
            renderer=fake_renderer,  # type: ignore[arg-type]
            debounce_seconds=0.01,
        )
        rb.notify("op")
        await asyncio.sleep(0.05)
        assert rb.last_build_succeeded is True
        assert rb.last_deploy_succeeded is None

    @pytest.mark.asyncio
    async def test_deploy_runs_git_commands_in_order(
        self, fake_renderer, tmp_path, monkeypatch,
    ):
        """When deploy_target is set, post-rebuild runs add → commit
        → push in that order with the configured branch + remote."""
        target = tmp_path / "out"
        target.mkdir()
        (target / ".git").mkdir()  # pretend it's a git repo
        git_calls: list[tuple[str, ...]] = []

        async def fake_run_git(self, *args):
            git_calls.append(args)

        monkeypatch.setattr(SiteRebuilder, "_run_git", fake_run_git)

        rb = SiteRebuilder(
            docs_repo=tmp_path / "docs",
            target_dir=target,
            renderer=fake_renderer,  # type: ignore[arg-type]
            debounce_seconds=0.01,
            deploy_target="origin",
            deploy_branch="pages",
        )
        rb.notify("create_issue")
        await asyncio.sleep(0.05)

        assert rb.last_build_succeeded is True
        assert rb.last_deploy_succeeded is True
        # Ordered: add -A; commit; push origin HEAD:pages.
        assert git_calls[0] == ("add", "-A")
        assert git_calls[1][0] == "commit"
        assert git_calls[1][1] == "--allow-empty"
        assert git_calls[1][2] == "-m"
        # Last call: push origin HEAD:pages
        push_args = git_calls[2]
        assert push_args[0] == "push"
        assert push_args[1] == "origin"
        assert push_args[2] == "HEAD:pages"

    @pytest.mark.asyncio
    async def test_deploy_failure_doesnt_propagate(
        self, fake_renderer, tmp_path, monkeypatch,
    ):
        """A push failure surfaces via on_failure + flips
        last_deploy_succeeded to False, but does NOT raise back into
        the rebuilder caller."""
        target = tmp_path / "out"
        target.mkdir()
        (target / ".git").mkdir()
        captured: list[Exception] = []

        async def fail_push(self, *args):
            if args and args[0] == "push":
                import subprocess
                raise subprocess.CalledProcessError(1, ["git", "push"])

        monkeypatch.setattr(SiteRebuilder, "_run_git", fail_push)

        rb = SiteRebuilder(
            docs_repo=tmp_path / "docs",
            target_dir=target,
            renderer=fake_renderer,  # type: ignore[arg-type]
            debounce_seconds=0.01,
            deploy_target="origin",
            on_failure=captured.append,
        )
        rb.notify("create_issue")
        await asyncio.sleep(0.05)

        # Build succeeded; deploy failed; on_failure received the err.
        assert rb.last_build_succeeded is True
        assert rb.last_deploy_succeeded is False
        assert len(captured) == 1

    @pytest.mark.asyncio
    async def test_deploy_skipped_when_target_dir_not_git_repo(
        self, fake_renderer, tmp_path,
    ):
        """When the operator hasn't initialized target_dir as a git
        repo, deploy raises FileNotFoundError with a clear next-step
        message — not a cryptic git-CLI error."""
        target = tmp_path / "out"
        target.mkdir()
        # Note: no .git directory.
        captured: list[Exception] = []
        rb = SiteRebuilder(
            docs_repo=tmp_path / "docs",
            target_dir=target,
            renderer=fake_renderer,  # type: ignore[arg-type]
            debounce_seconds=0.01,
            deploy_target="origin",
            on_failure=captured.append,
        )
        rb.notify("create_issue")
        await asyncio.sleep(0.05)

        assert rb.last_build_succeeded is True
        assert rb.last_deploy_succeeded is False
        assert len(captured) == 1
        assert "git init" in str(captured[0])

    @pytest.mark.asyncio
    async def test_deploy_skipped_when_build_failed(
        self, tmp_path, monkeypatch,
    ):
        """If the rebuild itself failed, the deploy step MUST NOT
        run — publishing a stale or partial site is worse than not
        publishing."""
        renderer = _FakeRenderer(failure=RuntimeError("hugo crashed"))
        target = tmp_path / "out"
        target.mkdir()
        (target / ".git").mkdir()
        deploy_attempts: list[tuple[str, ...]] = []

        async def fake_run_git(self, *args):
            deploy_attempts.append(args)

        monkeypatch.setattr(SiteRebuilder, "_run_git", fake_run_git)

        rb = SiteRebuilder(
            docs_repo=tmp_path / "docs",
            target_dir=target,
            renderer=renderer,  # type: ignore[arg-type]
            debounce_seconds=0.01,
            deploy_target="origin",
        )
        rb.notify("op")
        await asyncio.sleep(0.05)

        assert rb.last_build_succeeded is False
        assert rb.last_deploy_succeeded is None
        assert deploy_attempts == []


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
