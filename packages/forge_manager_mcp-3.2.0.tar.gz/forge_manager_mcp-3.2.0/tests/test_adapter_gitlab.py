"""Unit tests for GitLabAdapter (3.0 / Phase 4).

Covers:
  - platform_id ClassVar
  - from_config token-file + env-var resolution
  - _project_path URL-encoding (slash → %2F, nested groups)
  - shape converters (issue with iid, discussion, comment, milestone)
  - GitLab-specific state mapping ('opened' → 'open', 'active' → 'open')
  - _request error classification
  - probe() returns False on classified-unavailable status
  - Bearer auth header (not GitHub's token convention)

Live integration is covered by the cross-adapter conformance suite
parameterized for gitlab.
"""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import httpx
import pytest

from forge_manager_mcp.adapters import errors as _errors
from forge_manager_mcp.adapters.gitlab import (
    GITLAB_API_BASE,
    GitLabAdapter,
    _category_from_labels,
    _comment_from_api,
    _discussion_from_issue,
    _issue_from_api,
    _make_ref,
    _milestone_from_api,
    _normalize_category,
    _parse_iso,
    _project_path,
)
from forge_manager_mcp.adapters.types import (
    ArtifactRef,
    Comment,
    Issue,
    Milestone,
)


# ---------------------------------------------------------------------------
# platform_id
# ---------------------------------------------------------------------------

class TestPlatformId:
    def test_classvar(self):
        assert GitLabAdapter.platform_id == "gitlab"

    def test_instance(self):
        adapter = GitLabAdapter(token="t")
        assert adapter.platform_id == "gitlab"

    def test_has_scaffold_true_from_c4(self):
        assert GitLabAdapter.has_scaffold is True

    def test_has_session_event_surface_false(self):
        assert GitLabAdapter.has_session_event_surface is False


# ---------------------------------------------------------------------------
# _project_path URL-encoding
# ---------------------------------------------------------------------------

class TestProjectPath:
    def test_simple_path(self):
        assert _project_path("alice", "repo") == "alice%2Frepo"

    def test_nested_groups(self):
        # Nested groups: 'parent/child/repo' → 'parent%2Fchild%2Frepo'
        assert _project_path("parent/child", "repo") == "parent%2Fchild%2Frepo"

    def test_special_chars_encoded(self):
        # Space → %20, dot stays.
        assert _project_path("with space", "repo.name") == "with%20space%2Frepo.name"


# ---------------------------------------------------------------------------
# from_config
# ---------------------------------------------------------------------------

class TestFromConfig:
    def test_token_from_file(self, tmp_path: Path, monkeypatch):
        # Make sure no env var leaks in.
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        token_file = tmp_path / ".gitlab-token"
        token_file.write_text("ABC123\n")
        adapter = GitLabAdapter.from_config({
            "id": "gitlab",
            "token_path": str(token_file),
        })
        assert adapter.platform_id == "gitlab"
        assert adapter._api_base == GITLAB_API_BASE
        assert adapter._token == "ABC123"

    def test_token_from_env_overrides_file(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("GITLAB_TOKEN", "FROM_ENV")
        token_file = tmp_path / ".gitlab-token"
        token_file.write_text("FROM_FILE\n")
        adapter = GitLabAdapter.from_config({
            "id": "gitlab",
            "token_path": str(token_file),
        })
        assert adapter._token == "FROM_ENV"

    def test_self_hosted_url(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        token_file = tmp_path / "t"
        token_file.write_text("X")
        adapter = GitLabAdapter.from_config({
            "id": "gitlab",
            "url": "https://gitlab.example.com",
            "token_path": str(token_file),
        })
        assert adapter._api_base == "https://gitlab.example.com"

    def test_unsupported_platform_id_raises(self):
        with pytest.raises(_errors.ForgeError, match="unsupported platform_id"):
            GitLabAdapter.from_config({"id": "github"})

    def test_missing_token_file_raises(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        monkeypatch.setenv("HOME", str(tmp_path))  # no ~/.gitlab-token here
        with pytest.raises(_errors.ForgeError, match="no token found"):
            GitLabAdapter.from_config({
                "id": "gitlab",
                "token_path": str(tmp_path / "nope"),
            })

    def test_empty_token_file_raises(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        monkeypatch.setenv("HOME", str(tmp_path))
        token_file = tmp_path / "empty"
        token_file.write_text("   \n")
        with pytest.raises(_errors.ForgeError, match="no token found"):
            GitLabAdapter.from_config({
                "id": "gitlab",
                "token_path": str(token_file),
            })

    def test_strips_trailing_slash_from_url(self, tmp_path: Path, monkeypatch):
        monkeypatch.delenv("GITLAB_TOKEN", raising=False)
        token_file = tmp_path / "t"
        token_file.write_text("X")
        adapter = GitLabAdapter.from_config({
            "id": "gitlab",
            "url": "https://gitlab.example.com/",
            "token_path": str(token_file),
        })
        assert adapter._api_base == "https://gitlab.example.com"


# ---------------------------------------------------------------------------
# Headers
# ---------------------------------------------------------------------------

class TestHeaders:
    def test_bearer_auth(self):
        adapter = GitLabAdapter(token="ABC123")
        headers = adapter._headers()
        # GitLab uses Bearer (OAuth-style), distinct from Forgejo's "token <T>"
        # and GitHub's GraphQL Bearer (close cousin but separate adapter).
        assert headers["Authorization"] == "Bearer ABC123"


# ---------------------------------------------------------------------------
# Shape converters
# ---------------------------------------------------------------------------

class TestMakeRef:
    def test_basic(self):
        ref = _make_ref(
            platform_id="gitlab",
            native_id="42",
            kind="issue",
            owner="o",
            repo="r",
            number=7,
        )
        assert ref.platform_id == "gitlab"
        assert ref.native_id == "42"
        assert ref.number == 7


class TestIssueFromApi:
    def test_iid_maps_to_ref_number(self):
        # GitLab gotcha: iid is the user-facing project-scoped number;
        # id is the global database-row id.
        d = {
            "id": 100, "iid": 7, "title": "t", "description": "b",
            "state": "opened",
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.ref.number == 7
        assert issue.ref.native_id == "100"

    def test_state_opened_maps_to_open(self):
        d = {"id": 1, "iid": 1, "title": "t", "description": "", "state": "opened"}
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.state == "open"

    def test_state_closed_passes_through(self):
        d = {"id": 1, "iid": 1, "title": "t", "description": "", "state": "closed"}
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.state == "closed"

    def test_description_field_maps_to_body(self):
        # GitLab uses 'description' where GitHub/Forgejo use 'body'.
        d = {"id": 1, "iid": 1, "title": "t", "description": "hello world", "state": "opened"}
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.body == "hello world"

    def test_labels_as_strings(self):
        d = {
            "id": 1, "iid": 1, "title": "t", "description": "",
            "state": "opened",
            "labels": ["kind:bug", "priority:high"],
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.labels == ["kind:bug", "priority:high"]

    def test_milestone_dict_extracts_title(self):
        d = {
            "id": 1, "iid": 1, "title": "t", "description": "",
            "state": "opened",
            "milestone": {"id": 1, "title": "v1.0", "state": "active"},
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.milestone == "v1.0"

    def test_author_username(self):
        d = {
            "id": 1, "iid": 1, "title": "t", "description": "",
            "state": "opened",
            "author": {"username": "alice", "id": 100},
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.author == "alice"

    def test_web_url_maps_to_url(self):
        # GitLab uses 'web_url' (not 'html_url' like GitHub/Forgejo).
        d = {
            "id": 1, "iid": 1, "title": "t", "description": "",
            "state": "opened",
            "web_url": "https://gitlab.com/o/r/-/issues/1",
        }
        issue = _issue_from_api(d, owner="o", repo="r", platform_id="gitlab")
        assert issue.url == "https://gitlab.com/o/r/-/issues/1"


class TestDiscussionFromIssue:
    def test_re_emits_ref_with_discussion_kind(self):
        issue = _issue_from_api(
            {
                "id": 1, "iid": 7, "title": "t", "description": "b",
                "state": "opened",
                "labels": ["kind:discussion"],
            },
            owner="o", repo="r", platform_id="gitlab",
        )
        disc = _discussion_from_issue(issue, category=None)
        assert disc.ref.kind == "discussion"
        assert disc.ref.number == 7

    def test_decided_label_lifts(self):
        issue = _issue_from_api(
            {
                "id": 1, "iid": 1, "title": "t", "description": "",
                "state": "opened",
                "labels": ["kind:discussion", "decided"],
            },
            owner="o", repo="r", platform_id="gitlab",
        )
        disc = _discussion_from_issue(issue, category=None)
        assert disc.decided is True


class TestCommentFromApi:
    def test_basic(self):
        parent = ArtifactRef(
            platform_id="gitlab", native_id="1", kind="issue",
            owner="o", repo="r", number=7,
        )
        d = {
            "id": 200, "body": "hello",
            "author": {"username": "bob"},
            "created_at": "2026-04-29T10:00:00Z",
        }
        comment = _comment_from_api(d, parent=parent, platform_id="gitlab")
        assert isinstance(comment, Comment)
        assert comment.body == "hello"
        assert comment.author == "bob"


class TestMilestoneFromApi:
    def test_active_state_maps_to_open(self):
        # GitLab milestone state is 'active' / 'closed' (not 'open').
        d = {"id": 1, "title": "v1.0", "state": "active"}
        m = _milestone_from_api(d)
        assert isinstance(m, Milestone)
        assert m.state == "open"

    def test_closed_state_passes_through(self):
        d = {"id": 1, "title": "v1.0", "state": "closed"}
        m = _milestone_from_api(d)
        assert m.state == "closed"


class TestNormalizeCategory:
    def test_lowercase(self):
        assert _normalize_category("Architecture") == "architecture"


class TestCategoryFromLabels:
    def test_finds_category(self):
        assert _category_from_labels(["kind:discussion", "category:ux_ui"]) == "ux_ui"

    def test_returns_none_when_absent(self):
        assert _category_from_labels(["kind:discussion"]) is None


class TestParseIso:
    def test_z_suffix(self):
        result = _parse_iso("2026-04-29T12:00:00Z")
        assert result is not None
        assert result.year == 2026

    def test_none(self):
        assert _parse_iso(None) is None

    def test_garbage(self):
        assert _parse_iso("not-a-timestamp") is None


# ---------------------------------------------------------------------------
# _request error classification (MockTransport)
# ---------------------------------------------------------------------------

def _adapter_with_mock(handler) -> GitLabAdapter:
    adapter = GitLabAdapter(
        token="fake", api_base="http://gitlab.test", platform_id="gitlab",
    )
    adapter._client = httpx.AsyncClient(
        base_url=f"{adapter._api_base}/api/v4",
        transport=httpx.MockTransport(handler),
        headers=adapter._headers(),
    )
    return adapter


class TestRequestErrorClassification:
    @pytest.mark.asyncio
    async def test_5xx_raises_unavailable(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(503, text="down"))
        try:
            with pytest.raises(_errors.ForgeUnavailableError) as e:
                await adapter._request("GET", "/version")
            assert e.value.status_code == 503
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_401_raises_unavailable(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(401, text="auth"))
        try:
            with pytest.raises(_errors.ForgeUnavailableError):
                await adapter._request("GET", "/user")
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_404_with_allow_returns_none(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(404))
        try:
            result = await adapter._request(
                "GET", "/projects/foo/issues/9999",
                allow_404_as_none=True,
            )
            assert result is None
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_404_without_allow_raises_forge_error(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(404))
        try:
            with pytest.raises(_errors.ForgeError) as e:
                await adapter._request("GET", "/projects/foo")
            assert not isinstance(e.value, _errors.ForgeUnavailableError)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_2xx_json_parses(self):
        adapter = _adapter_with_mock(
            lambda req: httpx.Response(200, json={"version": "19.0.0"})
        )
        try:
            result = await adapter._request("GET", "/version")
            assert result == {"version": "19.0.0"}
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_204_returns_none(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(204))
        try:
            result = await adapter._request("DELETE", "/projects/foo/issues/1")
            assert result is None
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# get_issue_body / get_discussion_body (Phase C1)
# ---------------------------------------------------------------------------

class TestGetBodyByRef:
    """#274 Phase C1 — node-ID-based body fetch. GitLab REST is
    number-based; node-ID-only refs surface a clear
    InvalidArtifactRefError."""

    @pytest.mark.asyncio
    async def test_get_issue_body_returns_description_on_200(self):
        # GitLab uses "description" not "body" — the adapter normalizes.
        def handler(req):
            return httpx.Response(200, json={
                "iid": 7, "id": 1007,
                "description": "current description",
                "title": "t", "author": {"username": "u"},
                "labels": [], "state": "opened",
                "created_at": "2024-01-01T00:00:00Z",
                "updated_at": "2024-01-01T00:00:00Z",
                "web_url": "http://gitlab.test/x/y/-/issues/7",
            })
        adapter = _adapter_with_mock(handler)
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="1007",
                kind="issue", owner="x", repo="y", number=7,
            )
            body = await adapter.get_issue_body(ref)
            assert body == "current description"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_body_404_raises_invalid_ref(self):
        adapter = _adapter_with_mock(
            lambda req: httpx.Response(404, text="not found")
        )
        try:
            ref = ArtifactRef(
                platform_id="gitlab", native_id="9999",
                kind="issue", owner="x", repo="y", number=9999,
            )
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue_body(ref)
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_get_issue_body_missing_number_raises(self):
        adapter = _adapter_with_mock(
            lambda req: httpx.Response(500, text="should never be called")
        )
        try:
            ref = ArtifactRef(
                platform_id="github", native_id="I_x",
                kind="issue", owner="x", repo="y", number=None,
            )
            with pytest.raises(_errors.InvalidArtifactRefError):
                await adapter.get_issue_body(ref)
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# probe()
# ---------------------------------------------------------------------------

class TestProbe:
    @pytest.mark.asyncio
    async def test_returns_true_on_version_response(self):
        adapter = _adapter_with_mock(
            lambda req: httpx.Response(200, json={"version": "19.0.0"})
        )
        try:
            assert await adapter.probe() is True
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_returns_false_on_401(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(401))
        try:
            assert await adapter.probe() is False
        finally:
            await adapter.aclose()


# ---------------------------------------------------------------------------
# compute_drift stub
# ---------------------------------------------------------------------------

class TestComputeDrift:
    """PAR-4: GitLab compute_drift diffs remote against the canonical
    snapshot (mirrors Forgejo's pattern). Pre-PAR-4 this returned
    is_clean=True unconditionally — silent gap."""

    @pytest.mark.asyncio
    async def test_inconclusive_without_owner_repo_in_snapshot(self):
        adapter = GitLabAdapter(token="t")
        report = await adapter.compute_drift({})
        assert report.platform_id == "gitlab"
        assert report.is_clean is False
        assert any("owner/repo" in n for n in report.notes)

    @pytest.mark.asyncio
    async def test_clean_when_remote_matches_snapshot(self):
        def handler(req):
            # GitLab uses iid for project-internal numbers.
            return httpx.Response(200, json=[
                {"iid": 1, "state": "opened", "labels": ["bug"]},
                {"iid": 2, "state": "closed", "labels": ["chore"]},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            snapshot = {
                "owner": "g", "repo": "r",
                "issues": {
                    1: {"state": "open", "labels": ["bug"]},
                    2: {"state": "closed", "labels": ["chore"]},
                },
                "discussions": {},
            }
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is True
            assert report.issues_only_local == []
            assert report.issues_only_remote == []
            assert report.issues_diverged == []
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_detects_remote_only_issue(self):
        def handler(req):
            return httpx.Response(200, json=[
                {"iid": 1, "state": "opened", "labels": []},
                {"iid": 5, "state": "opened", "labels": []},  # remote-only
            ])
        adapter = _adapter_with_mock(handler)
        try:
            snapshot = {
                "owner": "g", "repo": "r",
                "issues": {1: {"state": "open", "labels": []}},
                "discussions": {},
            }
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is False
            assert report.issues_only_remote == [5]
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_detects_state_divergence(self):
        # Local says open, remote says closed → diverged.
        def handler(req):
            return httpx.Response(200, json=[
                {"iid": 1, "state": "closed", "labels": []},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            snapshot = {
                "owner": "g", "repo": "r",
                "issues": {1: {"state": "open", "labels": []}},
                "discussions": {},
            }
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is False
            assert report.issues_diverged == [1]
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_partitions_discussions_via_kind_label(self):
        # An item with kind:discussion lands in discussions, not issues.
        def handler(req):
            return httpx.Response(200, json=[
                {"iid": 7, "state": "opened",
                 "labels": ["kind:discussion", "category:Architecture"]},
            ])
        adapter = _adapter_with_mock(handler)
        try:
            snapshot = {
                "owner": "g", "repo": "r",
                "issues": {},
                "discussions": {
                    7: {
                        "state": "open",
                        "labels": ["kind:discussion", "category:Architecture"],
                    },
                },
            }
            report = await adapter.compute_drift(snapshot)
            assert report.is_clean is True
            # Issue side untouched.
            assert report.issues_only_local == []
            assert report.issues_only_remote == []
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_unreachable_remote_reports_inconclusive(self):
        def handler(req):
            return httpx.Response(503, text="upstream down")
        adapter = _adapter_with_mock(handler)
        try:
            report = await adapter.compute_drift(
                {"owner": "g", "repo": "r"}
            )
            assert report.is_clean is False
            assert any("inconclusive" in n for n in report.notes)
        finally:
            await adapter.aclose()


class TestRepoVisibility:
    """PAR-3: get_repo_visibility upper-cases GitLab's lowercase
    ``visibility`` field so the Protocol-level alphabet is consistent
    with GitHub (PUBLIC/PRIVATE/INTERNAL)."""

    @pytest.mark.asyncio
    async def test_public_repo(self):
        def handler(req):
            return httpx.Response(
                200, json={"id": 1, "visibility": "public"},
            )
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "PUBLIC"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_internal_repo(self):
        def handler(req):
            return httpx.Response(
                200, json={"id": 1, "visibility": "internal"},
            )
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "INTERNAL"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_private_repo(self):
        def handler(req):
            return httpx.Response(
                200, json={"id": 1, "visibility": "private"},
            )
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") == "PRIVATE"
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_missing_repo_returns_none(self):
        def handler(req):
            return httpx.Response(404, text="not found")
        adapter = _adapter_with_mock(handler)
        try:
            assert await adapter.get_repo_visibility("o", "r") is None
        finally:
            await adapter.aclose()


class TestBootstrapProject:
    """Multi-platform scaffold C4 — GitLabAdapter.bootstrap_project."""

    def test_has_scaffold_classvar_true(self):
        assert GitLabAdapter.has_scaffold is True

    @pytest.mark.asyncio
    async def test_bootstrap_creates_project_pair_and_seeds_labels(self):
        labels_created: list[str] = []

        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path

            # Namespace lookup: returns the matching group.
            if method == "GET" and path == "/api/v4/namespaces":
                return httpx.Response(200, json=[
                    {"id": 99, "name": "myorg", "path": "myorg", "kind": "group"},
                ])

            # Probe: project doesn't exist (404 with allow_404_as_none).
            if method == "GET" and path.startswith("/api/v4/projects/myorg/") \
                    and "/labels" not in path:
                return httpx.Response(404)

            # Create: returns the project.
            if method == "POST" and path == "/api/v4/projects":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                # Verify namespace_id was passed (group creation).
                assert body.get("namespace_id") == 99
                return httpx.Response(201, json={
                    "id": 200 if body["name"] == "widgets-dev" else 201,
                    "name": body["name"],
                    "path_with_namespace": f"myorg/{body['name']}",
                    "web_url": f"http://gitlab.test/myorg/{body['name']}",
                    "visibility": body["visibility"],
                })

            # Label probe (always-empty paginated → trigger create).
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                labels_created.append(body["name"])
                return httpx.Response(201, json={"id": len(labels_created)})

            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="myorg", project_name="widgets",
                description="widgets project",
            )
        finally:
            await adapter.aclose()

        assert result.platform_id == "gitlab"
        assert result.phase == "complete"
        assert result.artifacts["dev_project"]["existed"] is False
        assert result.artifacts["public_project"]["existed"] is False
        assert result.artifacts["namespace_id"] == 99
        # Standard labels.
        assert "bug" in labels_created
        assert "rfc" in labels_created
        assert "area:mcp" in labels_created
        # Discussions-as-Issues reserved.
        assert "kind:discussion" in labels_created
        assert "category:Architecture" in labels_created
        assert "decided" in labels_created

    @pytest.mark.asyncio
    async def test_bootstrap_idempotent_when_projects_exist(self):
        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path

            if method == "GET" and path == "/api/v4/namespaces":
                return httpx.Response(200, json=[
                    {"id": 99, "name": "myorg", "path": "myorg", "kind": "group"},
                ])

            # Both projects exist (200).
            if method == "GET" and path.startswith("/api/v4/projects/myorg/") \
                    and "/labels" not in path:
                return httpx.Response(200, json={
                    "id": 42, "name": "widgets",
                    "path_with_namespace": "myorg/widgets",
                    "web_url": "http://gitlab.test/myorg/widgets",
                    "visibility": "private",
                })

            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                return httpx.Response(201, json={"id": 1})

            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="myorg", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert result.phase == "complete"
        assert result.artifacts["dev_project"]["existed"] is True
        assert result.artifacts["public_project"]["existed"] is True

    @pytest.mark.asyncio
    async def test_bootstrap_falls_back_to_user_namespace_when_lookup_misses(self):
        """When the owner doesn't match any namespace (user-account case),
        the create POST omits namespace_id; GitLab places the project
        under the authenticated user's default namespace."""
        def handler(req: httpx.Request) -> httpx.Response:
            method = req.method
            path = req.url.path
            if method == "GET" and path == "/api/v4/namespaces":
                return httpx.Response(200, json=[])  # no match
            if method == "GET" and path.startswith("/api/v4/projects/") \
                    and "/labels" not in path:
                return httpx.Response(404)
            if method == "POST" and path == "/api/v4/projects":
                import json as _json
                body = _json.loads(req.content) if req.content else {}
                # No namespace_id in payload → user-namespace fallback.
                assert "namespace_id" not in body
                return httpx.Response(201, json={
                    "id": 7, "name": body["name"],
                    "path_with_namespace": f"alice/{body['name']}",
                    "web_url": f"http://gitlab.test/alice/{body['name']}",
                    "visibility": body["visibility"],
                })
            if method == "GET" and path.endswith("/labels"):
                return httpx.Response(200, json=[])
            if method == "POST" and path.endswith("/labels"):
                return httpx.Response(201, json={"id": 1})
            return httpx.Response(500, text=f"unhandled {method} {path}")

        adapter = _adapter_with_mock(handler)
        try:
            result = await adapter.bootstrap_project(
                owner="alice", project_name="widgets", description="",
            )
        finally:
            await adapter.aclose()

        assert result.phase == "complete"
        assert result.artifacts["namespace_id"] is None

    @pytest.mark.asyncio
    async def test_bootstrap_rejects_empty_owner(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(500))
        try:
            with pytest.raises(_errors.ForgeError, match="owner"):
                await adapter.bootstrap_project(
                    owner="  ", project_name="widgets", description="",
                )
        finally:
            await adapter.aclose()

    @pytest.mark.asyncio
    async def test_bootstrap_rejects_empty_project_name(self):
        adapter = _adapter_with_mock(lambda req: httpx.Response(500))
        try:
            with pytest.raises(_errors.ForgeError, match="project_name"):
                await adapter.bootstrap_project(
                    owner="myorg", project_name="", description="",
                )
        finally:
            await adapter.aclose()


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
