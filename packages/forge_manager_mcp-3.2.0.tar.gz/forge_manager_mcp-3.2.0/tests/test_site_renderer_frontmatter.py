"""Unit tests for site_renderer.frontmatter (3.0 / Phase 5).

Walks a fixture docs repo and verifies the emitted Hugo content tree.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from forge_manager_mcp.site_renderer.frontmatter import (
    _yaml_string,
    generate_site_input,
)


# ---------------------------------------------------------------------------
# Fixture builder
# ---------------------------------------------------------------------------

def _build_fixture_docs_repo(root: Path) -> Path:
    """Construct a minimal docs repo with one issue, one discussion,
    one milestone, one release."""
    # Issue #1 — open, two labels, one comment.
    issue_dir = root / "issues" / "1"
    issue_dir.mkdir(parents=True)
    (issue_dir / "title.md").write_text("First issue\n", encoding="utf-8")
    (issue_dir / "body.md").write_text("This is the body.\n", encoding="utf-8")
    (issue_dir / "state.txt").write_text("open\n", encoding="utf-8")
    (issue_dir / "labels.txt").write_text("kind:bug\nfeature\n", encoding="utf-8")
    (issue_dir / "meta.json").write_text(
        json.dumps({
            "number": 1,
            "created_at": "2026-04-29",
            "created_by": "telejester",
            "milestone": "3.0.0",
        }),
        encoding="utf-8",
    )
    comments_dir = issue_dir / "comments"
    comments_dir.mkdir()
    (comments_dir / "20260429T120000Z-bot.md").write_text(
        "First comment.\n", encoding="utf-8",
    )

    # Discussion #1 — decided, with category.
    disc_dir = root / "discussions" / "1"
    disc_dir.mkdir(parents=True)
    (disc_dir / "title.md").write_text("Design decision\n", encoding="utf-8")
    (disc_dir / "body.md").write_text("Design body.\n", encoding="utf-8")
    (disc_dir / "state.txt").write_text("open\ndecided\n", encoding="utf-8")
    (disc_dir / "labels.txt").write_text(
        "kind:discussion\ncategory:architecture\n", encoding="utf-8",
    )
    (disc_dir / "meta.json").write_text(
        json.dumps({"number": 1, "category": "architecture"}),
        encoding="utf-8",
    )

    # Milestone.
    ms_dir = root / "milestones"
    ms_dir.mkdir()
    (ms_dir / "3.0.0.md").write_text("# 3.0.0\n\nRelease milestone.\n",
                                     encoding="utf-8")

    # Release.
    rel_dir = root / "releases" / "3.0.0"
    rel_dir.mkdir(parents=True)
    (rel_dir / "notes.md").write_text("# 3.0.0\n\nRelease notes.\n",
                                       encoding="utf-8")

    return root


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestGenerateSiteInput:
    def test_emits_content_tree(self, tmp_path: Path):
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        result = generate_site_input(
            docs_repo=docs_repo, output_dir=output_dir,
        )
        assert result == output_dir.resolve()
        assert (output_dir / "content").is_dir()

    def test_issue_emitted(self, tmp_path: Path):
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        issue_md = output_dir / "content" / "issues" / "1.md"
        assert issue_md.exists()
        content = issue_md.read_text(encoding="utf-8")
        assert content.startswith("---\n")
        assert "title: First issue" in content
        assert "type: issue" in content
        assert "kind:bug" in content
        assert "feature" in content
        assert "state: open" in content
        assert "decided: false" in content
        assert "First comment." in content

    def test_discussion_emitted_with_decided_true(self, tmp_path: Path):
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        disc_md = output_dir / "content" / "discussions" / "1.md"
        assert disc_md.exists()
        content = disc_md.read_text(encoding="utf-8")
        assert "type: discussion" in content
        assert "decided: true" in content
        assert "category: architecture" in content

    def test_label_colors_with_yiq_text_colors(self, tmp_path: Path):
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        # Pre-resolved label colors (in the real flow this comes from
        # the canonical label store).
        generate_site_input(
            docs_repo=docs_repo, output_dir=output_dir,
            label_colors={"kind:bug": "d73a4a", "feature": "a2eeef"},
        )
        content = (output_dir / "content" / "issues" / "1.md").read_text(
            encoding="utf-8",
        )
        # Per-label color and YIQ-derived text color present.
        assert "d73a4a" in content  # kind:bug fill
        assert "a2eeef" in content  # feature fill
        assert "#ffffff" in content  # white text on red kind:bug
        assert "#000000" in content  # black text on light cyan feature

    def test_missing_color_falls_back_to_neutral(self, tmp_path: Path):
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        content = (output_dir / "content" / "issues" / "1.md").read_text(
            encoding="utf-8",
        )
        # Default neutral color (without the leading #).
        assert "d0d7de" in content

    def test_milestone_emitted(self, tmp_path: Path):
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        ms_md = output_dir / "content" / "milestones" / "3.0.0.md"
        assert ms_md.exists()
        content = ms_md.read_text(encoding="utf-8")
        assert "type: milestone" in content
        assert "Release milestone." in content

    def test_release_emitted_from_subdir(self, tmp_path: Path):
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        rel_md = output_dir / "content" / "releases" / "3.0.0.md"
        assert rel_md.exists()
        content = rel_md.read_text(encoding="utf-8")
        assert "type: release" in content
        assert "Release notes." in content

    def test_home_page_emitted(self, tmp_path: Path):
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        # README/CONVENTIONS optional — emit a default home if absent.
        output_dir = tmp_path / "out"
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        home = output_dir / "content" / "_index.md"
        assert home.exists()
        assert "title: Home" in home.read_text(encoding="utf-8")

    def test_existing_output_dir_replaced(self, tmp_path: Path):
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        output_dir.mkdir()
        (output_dir / "stale.md").write_text("stale", encoding="utf-8")
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        # Stale file gone.
        assert not (output_dir / "stale.md").exists()
        # Fresh content present.
        assert (output_dir / "content" / "issues" / "1.md").exists()

    def test_handles_empty_docs_repo(self, tmp_path: Path):
        docs_repo = tmp_path / "empty-docs"
        docs_repo.mkdir()
        output_dir = tmp_path / "out"
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        # Should not raise; empty content tree + home stub.
        assert (output_dir / "content").is_dir()
        assert (output_dir / "content" / "_index.md").exists()


class TestYamlString:
    def test_plain_string_passes_through(self):
        assert _yaml_string("hello") == "hello"

    def test_string_with_colon_quoted(self):
        result = _yaml_string("hello: world")
        assert result.startswith('"') and result.endswith('"')

    def test_empty_string_double_quoted(self):
        assert _yaml_string("") == '""'

    def test_string_with_quote_escaped(self):
        # An embedded double-quote must be escaped within the wrapper.
        result = _yaml_string('say "hi"')
        assert '\\"' in result


class TestIncrementalEmit:
    """Hugo subset-rebuild — generate_site_input(changed_artifacts=...)
    re-emits only the listed artifacts; full mode (changed_artifacts=
    None) preserves the pre-existing wipe-and-rebuild behavior."""

    def test_full_mode_wipes_output_dir(self, tmp_path: Path):
        """Default mode (changed_artifacts=None) wipes output_dir
        before re-emitting. Verifies a stale leftover from a prior
        run gets cleaned up."""
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        output_dir.mkdir()
        # Drop a stale file that should NOT survive the full rebuild.
        (output_dir / "stale.txt").write_text("from prior run", encoding="utf-8")

        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)

        assert not (output_dir / "stale.txt").exists()

    def test_incremental_mode_preserves_existing(self, tmp_path: Path):
        """Incremental mode (changed_artifacts non-None) does NOT
        wipe output_dir. Pre-existing entries persist."""
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        # First do a full emit so issue #1 / discussion #1 / milestone /
        # release land.
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        original_disc = (output_dir / "content" / "discussions" / "1.md").read_text()

        # Add issue #2 to the docs repo and incrementally emit only it.
        issue_dir = docs_repo / "issues" / "2"
        issue_dir.mkdir()
        (issue_dir / "title.md").write_text("Second issue\n", encoding="utf-8")
        (issue_dir / "body.md").write_text("body 2\n", encoding="utf-8")
        (issue_dir / "state.txt").write_text("open\n", encoding="utf-8")
        (issue_dir / "labels.txt").write_text("", encoding="utf-8")
        (issue_dir / "meta.json").write_text(
            json.dumps({"number": 2, "created_at": "2026-05-01", "created_by": "x"}),
            encoding="utf-8",
        )

        generate_site_input(
            docs_repo=docs_repo, output_dir=output_dir,
            changed_artifacts={"issues": [2]},
        )

        # Issue #2 emitted.
        assert (output_dir / "content" / "issues" / "2.md").exists()
        # Discussion #1 still there with the same content (not wiped).
        assert (output_dir / "content" / "discussions" / "1.md").read_text() == original_disc

    def test_incremental_emits_only_listed_kinds(self, tmp_path: Path):
        """When the incremental dict only mentions ``issues``, the
        ``discussions`` / ``milestones`` / ``releases`` sections are
        not re-touched."""
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)

        # Mutate disc #1 in the docs repo without listing it in the
        # changed_artifacts dict — incremental emit shouldn't pick up
        # the change.
        (docs_repo / "discussions" / "1" / "body.md").write_text(
            "MUTATED BODY\n", encoding="utf-8",
        )

        generate_site_input(
            docs_repo=docs_repo, output_dir=output_dir,
            changed_artifacts={"issues": [1]},
        )

        # Discussion page on disk still reflects the PRE-mutation body
        # (incremental emit didn't touch discussions).
        emitted = (output_dir / "content" / "discussions" / "1.md").read_text()
        assert "MUTATED BODY" not in emitted

    def test_incremental_handles_deletion(self, tmp_path: Path):
        """When the artifact dir is gone (deletion case), the emitted
        page is removed from the output content tree."""
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        target = output_dir / "content" / "issues" / "1.md"
        assert target.exists()

        # Delete issue #1 from the docs repo, then incrementally
        # re-emit naming it as changed.
        import shutil
        shutil.rmtree(docs_repo / "issues" / "1")

        generate_site_input(
            docs_repo=docs_repo, output_dir=output_dir,
            changed_artifacts={"issues": [1]},
        )

        # Page removed from content tree.
        assert not target.exists()

    def test_incremental_runs_home_unconditionally(self, tmp_path: Path):
        """The home page re-emits even on incremental runs since it
        aggregates over the full docs-repo state and is cheap."""
        docs_repo = _build_fixture_docs_repo(tmp_path / "docs")
        output_dir = tmp_path / "out"
        generate_site_input(docs_repo=docs_repo, output_dir=output_dir)
        home = output_dir / "content" / "_index.md"
        assert home.exists()

        # Delete the home page, then run an incremental emit. The home
        # file should be re-emitted.
        home.unlink()

        generate_site_input(
            docs_repo=docs_repo, output_dir=output_dir,
            changed_artifacts={"issues": [1]},
        )

        assert home.exists()


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
