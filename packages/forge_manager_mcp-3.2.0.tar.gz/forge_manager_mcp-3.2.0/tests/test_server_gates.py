"""Unit tests for forge_manager_mcp.server.gates (#287 evaluator).

Covers:

* evaluate_gate against a registered default evaluator.
* evaluate_gate raises UnknownGate when name not registered or registry
  not loaded.
* build_gate_chain composes only the registered default evaluator when
  project_rules is None.
* register / clear / get default-evaluator surface.
* error propagation: a default evaluator that captures ctx.error
  surfaces it back through evaluate_gate.
"""
from __future__ import annotations

import asyncio
import textwrap
from dataclasses import replace
from pathlib import Path

import pytest

from forge_manager_mcp.context import ServerContext
from forge_manager_mcp.gate_registry import Gate, GateRegistry
from forge_manager_mcp.interceptors import Context, Interceptor
from forge_manager_mcp.project_rules import parse_project_rules
from forge_manager_mcp.server.gates import (
    UnknownGate,
    build_gate_chain,
    clear_default_evaluators,
    evaluate_gate,
    get_default_evaluator,
    register_default_evaluator,
)


@pytest.fixture(autouse=True)
def _isolate_default_evaluators():
    """Ensure each test sees an empty default-evaluator registry."""
    clear_default_evaluators()
    yield
    clear_default_evaluators()


def _make_gate(name: str = "commit.test_coverage", gtype: str = "pre-commit") -> Gate:
    return Gate(
        name=name,
        type=gtype,
        location=f"c.md#{name}",
        summary=name,
        default_state="open",
        extension_semantics="tighten",
        override_semantics="replace",
        state_change_semantics="open_close",
        rationale_doc=f"c.md#{name}",
        introduced_in="1.0.0",
    )


def _make_ctx(*, gates: list[Gate] | None = None) -> ServerContext:
    return ServerContext(
        config=None,
        github_token="test-token",
        anthropic_api_key="test-key",
        project_dir=Path("/tmp/x"),
        gate_registry=GateRegistry(gates or []),
    )


class TestRegisterDefaultEvaluator:
    def test_register_then_lookup(self) -> None:
        async def evaluator_enter(ctx: Context) -> Context:
            return ctx
        ic = Interceptor(enter=evaluator_enter)
        register_default_evaluator("commit.x", ic)
        assert get_default_evaluator("commit.x") is ic

    def test_clear_empties_registry(self) -> None:
        async def evaluator_enter(ctx: Context) -> Context:
            return ctx
        ic = Interceptor(enter=evaluator_enter)
        register_default_evaluator("commit.x", ic)
        clear_default_evaluators()
        assert get_default_evaluator("commit.x") is None

    def test_re_registration_overwrites(self) -> None:
        async def first_enter(ctx: Context) -> Context:
            return ctx
        async def second_enter(ctx: Context) -> Context:
            return ctx
        register_default_evaluator("commit.x", Interceptor(enter=first_enter))
        register_default_evaluator("commit.x", Interceptor(enter=second_enter))
        ic = get_default_evaluator("commit.x")
        assert ic is not None
        assert ic.enter is second_enter


class TestBuildGateChain:
    def test_default_only_when_project_rules_none(self) -> None:
        async def evaluator_enter(ctx: Context) -> Context:
            return ctx
        register_default_evaluator(
            "commit.x", Interceptor(enter=evaluator_enter)
        )
        gate = _make_gate(name="commit.x")
        chain = build_gate_chain(gate, project_rules=None)
        assert len(chain) == 1
        assert chain[0].enter is evaluator_enter

    def test_empty_chain_when_nothing_registered(self) -> None:
        gate = _make_gate(name="commit.x")
        chain = build_gate_chain(gate, project_rules=None)
        assert chain == []

    def test_empty_project_rules_collapse_to_default(self) -> None:
        # #288 — empty ProjectRules layers produce no interceptors;
        # the chain reduces to the default evaluator.
        async def evaluator_enter(ctx: Context) -> Context:
            return ctx
        register_default_evaluator(
            "commit.x", Interceptor(enter=evaluator_enter)
        )
        gate = _make_gate(name="commit.x")
        empty_rules = parse_project_rules("")
        chain = build_gate_chain(gate, project_rules=empty_rules)
        assert len(chain) == 1


class TestEvaluateGate:
    def test_evaluator_response_surfaces(self) -> None:
        async def evaluator_enter(ctx: Context) -> Context:
            return replace(
                ctx,
                response={**ctx.response, "commit.test": {"passed": True}},
            )
        register_default_evaluator(
            "commit.test", Interceptor(enter=evaluator_enter)
        )
        ctx = _make_ctx(gates=[_make_gate("commit.test")])
        response = asyncio.run(evaluate_gate(ctx, "commit.test"))
        assert response == {"commit.test": {"passed": True}}

    def test_unknown_gate_raises(self) -> None:
        ctx = _make_ctx(gates=[_make_gate("commit.test")])
        with pytest.raises(UnknownGate):
            asyncio.run(evaluate_gate(ctx, "commit.unknown"))

    def test_unloaded_registry_raises(self) -> None:
        ctx = ServerContext(
            config=None,
            github_token="test-token",
            anthropic_api_key="test-key",
            project_dir=Path("/tmp/x"),
            gate_registry=None,
        )
        with pytest.raises(UnknownGate, match="registry not loaded"):
            asyncio.run(evaluate_gate(ctx, "any.gate"))

    def test_handler_exception_propagates(self) -> None:
        async def failing_enter(ctx: Context) -> Context:
            raise ValueError("evaluator failed")
        register_default_evaluator(
            "commit.test", Interceptor(enter=failing_enter)
        )
        ctx = _make_ctx(gates=[_make_gate("commit.test")])
        with pytest.raises(ValueError, match="evaluator failed"):
            asyncio.run(evaluate_gate(ctx, "commit.test"))

    def test_request_passes_through(self) -> None:
        captured: dict = {}

        async def capture_enter(ctx: Context) -> Context:
            captured["request"] = dict(ctx.request)
            return ctx
        register_default_evaluator(
            "commit.test", Interceptor(enter=capture_enter)
        )
        ctx = _make_ctx(gates=[_make_gate("commit.test")])
        asyncio.run(
            evaluate_gate(ctx, "commit.test", request={"diff": "+foo"})
        )
        assert captured["request"] == {"diff": "+foo"}

    def test_no_default_evaluator_returns_empty(self) -> None:
        # Default-state "open" with no evaluator and no project rules
        # produces an empty response — chain has zero interceptors.
        ctx = _make_ctx(gates=[_make_gate("commit.test")])
        response = asyncio.run(evaluate_gate(ctx, "commit.test"))
        assert response == {}


# ---------------------------------------------------------------------------
# #288 — end-to-end project-rules layering through evaluate_gate
# ---------------------------------------------------------------------------


_RULES_BODY = """\
## Gate extensions

### Extends `commit.test_coverage`
**Extension:** Tighten — every branch tested in same commit.

## Gate overrides

### Overrides `release.bazel_tests_green`
**Replacement:** Wrapper that probes monorepo MODULE.bazel.

## Gate state declarations

### Closes `commit.llm_verifier`
**Reason:** ANTHROPIC_API_KEY not set in this environment.
"""


def _make_ctx_with_rules(gates: list[Gate], rules_body: str) -> ServerContext:
    rules = parse_project_rules(rules_body)
    ctx = _make_ctx(gates=gates)
    return replace(ctx, project_rules=rules)


class TestEndToEndLayering:
    def test_extension_layered_with_default(self) -> None:
        async def default_enter(ctx: Context) -> Context:
            return replace(
                ctx,
                response={
                    **ctx.response,
                    "commit.test_coverage": {"verdict": "passed"},
                },
            )
        register_default_evaluator(
            "commit.test_coverage", Interceptor(enter=default_enter)
        )
        ctx = _make_ctx_with_rules(
            gates=[_make_gate("commit.test_coverage")],
            rules_body=_RULES_BODY,
        )
        response = asyncio.run(
            evaluate_gate(ctx, "commit.test_coverage")
        )
        gate_resp = response["commit.test_coverage"]
        assert gate_resp["verdict"] == "passed"
        # Extension's leave appended its record after the default ran.
        assert len(gate_resp["extensions"]) == 1
        assert "Tighten" in gate_resp["extensions"][0]["extension"]

    def test_override_halts_default(self) -> None:
        # Default would write "passed"; override halts before it runs.
        ran: list[bool] = []

        async def default_enter(ctx: Context) -> Context:
            ran.append(True)
            return replace(
                ctx,
                response={
                    **ctx.response,
                    "release.bazel_tests_green": {"verdict": "passed"},
                },
            )
        register_default_evaluator(
            "release.bazel_tests_green", Interceptor(enter=default_enter)
        )
        ctx = _make_ctx_with_rules(
            gates=[_make_gate("release.bazel_tests_green", gtype="pre-tag")],
            rules_body=_RULES_BODY,
        )
        response = asyncio.run(
            evaluate_gate(ctx, "release.bazel_tests_green")
        )
        # Default never ran.
        assert ran == []
        gate_resp = response["release.bazel_tests_green"]
        assert gate_resp["verdict"] == "override"
        assert "Wrapper" in gate_resp["replacement"]

    def test_closed_state_halts_at_outermost(self) -> None:
        # Closes interceptor sits outermost; nothing else runs.
        ran: list[bool] = []

        async def default_enter(ctx: Context) -> Context:
            ran.append(True)
            return ctx
        register_default_evaluator(
            "commit.llm_verifier", Interceptor(enter=default_enter)
        )
        ctx = _make_ctx_with_rules(
            gates=[_make_gate("commit.llm_verifier")],
            rules_body=_RULES_BODY,
        )
        response = asyncio.run(evaluate_gate(ctx, "commit.llm_verifier"))
        assert ran == []
        gate_resp = response["commit.llm_verifier"]
        assert gate_resp["state"] == "closed"
        assert "ANTHROPIC" in gate_resp["reason"]

    def test_explicit_project_rules_overrides_ctx(self) -> None:
        # Pass explicit project_rules to evaluate_gate — should override
        # ctx.project_rules.
        async def default_enter(ctx: Context) -> Context:
            return replace(
                ctx,
                response={
                    **ctx.response,
                    "commit.test_coverage": {"verdict": "passed"},
                },
            )
        register_default_evaluator(
            "commit.test_coverage", Interceptor(enter=default_enter)
        )
        # ctx has rules that close the gate; explicit override skips them.
        closed_rules = parse_project_rules(textwrap.dedent("""\
            ## Gate state declarations

            ### Closes `commit.test_coverage`
            **Reason:** project default.
        """))
        ctx = _make_ctx(gates=[_make_gate("commit.test_coverage")])
        ctx_closed = replace(ctx, project_rules=closed_rules)
        # With ctx.project_rules: state-closed halts first.
        resp_closed = asyncio.run(evaluate_gate(ctx_closed, "commit.test_coverage"))
        assert resp_closed["commit.test_coverage"]["state"] == "closed"
        # Now override with empty rules — default evaluator runs.
        empty_rules = parse_project_rules("")
        resp_open = asyncio.run(
            evaluate_gate(
                ctx_closed,
                "commit.test_coverage",
                project_rules=empty_rules,
            )
        )
        assert resp_open["commit.test_coverage"]["verdict"] == "passed"


class TestRecoveryPattern:
    """The cleared-error pattern from Discussion #3 — extension's error
    handler clears ctx.error after a fallback succeeds; subsequent
    unwinding runs leave handlers; gate evaluation returns the fallback
    result. Verifies that #292's three-effect model composes cleanly
    through #288's project-rule layering.
    """

    def test_extension_recovers_from_default_failure(self) -> None:
        # Default evaluator fails; we layer a custom extension whose
        # error handler runs a fallback and clears the error. The
        # fallback's response should reach the caller cleanly.

        async def default_enter(ctx: Context) -> Context:
            raise ValueError("default evaluator broke")

        # Manual chain composition — the project-rules path doesn't
        # currently let projects declare error handlers in markdown
        # (that's a future surface). For now we verify the pattern at
        # the chain layer by composing a custom Interceptor outside
        # build_gate_chain — same chain shape as evaluate_gate would
        # produce.
        async def fallback_enter(ctx: Context) -> Context:
            return ctx

        async def fallback_error(ctx: Context) -> Context:
            # Recovery: deterministic fallback verdict; clear error.
            return replace(
                ctx,
                error=None,
                response={
                    **ctx.response,
                    "commit.test_coverage": {
                        "verdict": "fallback_passed",
                        "via": "deterministic",
                    },
                },
            )

        async def fallback_leave(ctx: Context) -> Context:
            return ctx

        recovery_ic = Interceptor(
            enter=fallback_enter,
            error=fallback_error,
            leave=fallback_leave,
        )
        default_ic = Interceptor(enter=default_enter)
        from forge_manager_mcp.interceptors import aexecute as _aexecute
        ctx = asyncio.run(_aexecute([recovery_ic, default_ic], request={}))
        # Error was cleared by the recovery handler.
        assert ctx.error is None
        gate_resp = ctx.response["commit.test_coverage"]
        assert gate_resp["verdict"] == "fallback_passed"
        assert gate_resp["via"] == "deterministic"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
