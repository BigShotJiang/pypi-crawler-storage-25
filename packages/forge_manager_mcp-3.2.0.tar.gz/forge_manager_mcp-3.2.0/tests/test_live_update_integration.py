"""Integration test for the Hugo live-update chain.

Exercises the full create_issue → SiteRebuilder.notify → debounced
build → flush() chain through real ReplicationManager + LocalStore-
Adapter + SiteRebuilder construction (build_server-shape) against a
stubbed renderer. Catches wiring regressions that unit tests on
each component miss — specifically:
  * _build_site_rebuilder honors the gating conditions and constructs
    a working rebuilder.
  * ReplicationManager.set_on_canonical_write fires the hook on every
    successful canonical write.
  * close_session-style flush() drains pending rebuilds.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Any

import pytest

from forge_manager_mcp.adapters.local_store import LocalStoreAdapter
from forge_manager_mcp.replication.manager import ReplicationManager
from forge_manager_mcp.site_renderer.rebuilder import SiteRebuilder


class _StubRenderer:
    """Records every build() call so the integration test can assert
    rebuilds fired without invoking real Hugo. Tests can set
    ``renderer.failure = SomeException`` to force build failures."""

    def __init__(self):
        self.builds: list[tuple[Path, Path]] = []
        self.failure: Exception | None = None

    async def build(self, *, docs_repo: Path, target_dir: Path, **kwargs: Any) -> Path:
        self.builds.append((docs_repo, target_dir))
        if self.failure is not None:
            raise self.failure
        return target_dir


def _build_chain(tmp_path: Path, *, debounce_seconds: float = 0.05):
    """Construct the full live-update chain for an integration test.

    Mirrors what build_server does in production: create LocalStore
    adapter, wrap in ReplicationManager, construct SiteRebuilder
    pointed at the same docs path, wire the hook.
    """
    docs_repo = tmp_path / "docs"
    docs_repo.mkdir()
    target_dir = tmp_path / "out"

    local = LocalStoreAdapter(docs_repo_path=docs_repo)
    replication = ReplicationManager([("local", local)])  # type: ignore[arg-type]

    renderer = _StubRenderer()
    rebuilder = SiteRebuilder(
        docs_repo=docs_repo,
        target_dir=target_dir,
        renderer=renderer,  # type: ignore[arg-type]
        debounce_seconds=debounce_seconds,
    )
    replication.set_on_canonical_write(rebuilder.notify)
    return docs_repo, replication, rebuilder, renderer


class TestLiveUpdateChain:
    @pytest.mark.asyncio
    async def test_canonical_write_triggers_rebuild_after_debounce(
        self, tmp_path,
    ):
        """One create_issue → notify fires → debounce expires →
        renderer.build() fires once."""
        docs_repo, replication, rebuilder, renderer = _build_chain(tmp_path)

        await replication.write(
            lambda a: a.create_issue(
                owner="test", repo="repo",
                title="t", body="b", labels=["kind:bug"],
            ),
            operation_name="create_issue",
        )
        # Notify scheduled — wait past debounce.
        await asyncio.sleep(0.1)
        assert len(renderer.builds) == 1
        assert renderer.builds[0][0] == docs_repo

    @pytest.mark.asyncio
    async def test_multiple_writes_coalesce_to_one_rebuild(self, tmp_path):
        """Three rapid writes within the debounce window → one build."""
        docs_repo, replication, rebuilder, renderer = _build_chain(tmp_path)

        for i in range(3):
            await replication.write(
                lambda a, n=i: a.create_issue(
                    owner="t", repo="r", title=f"t{n}", body="", labels=[],
                ),
                operation_name="create_issue",
            )
        await asyncio.sleep(0.1)
        assert len(renderer.builds) == 1

    @pytest.mark.asyncio
    async def test_flush_runs_pending_rebuild_immediately(self, tmp_path):
        """close_session-style flush() drains a pending rebuild
        without waiting for the debounce window."""
        docs_repo, replication, rebuilder, renderer = _build_chain(
            tmp_path, debounce_seconds=10.0,  # long debounce
        )
        await replication.write(
            lambda a: a.create_issue(
                owner="t", repo="r", title="t", body="", labels=[],
            ),
            operation_name="create_issue",
        )
        # Without flush, a 10s debounce means no build for 10s. flush
        # forces it now.
        result = await rebuilder.flush()
        assert result is True
        assert len(renderer.builds) == 1

    @pytest.mark.asyncio
    async def test_failed_canonical_write_does_not_trigger_rebuild(
        self, tmp_path,
    ):
        """When the canonical write itself raises, the on_canonical_write
        hook MUST NOT fire — rebuilding on a failed write would publish
        stale state. Verified at the ReplicationManager level by
        forcing a write that raises."""
        from forge_manager_mcp.replication.errors import ReplicationWriteError
        from forge_manager_mcp.adapters import errors as _errs

        docs_repo, replication, rebuilder, renderer = _build_chain(tmp_path)

        async def _fail(adapter):
            raise _errs.ForgeUnavailableError("simulated canonical failure")

        with pytest.raises(ReplicationWriteError):
            await replication.write(_fail, operation_name="create_issue")
        await asyncio.sleep(0.1)
        # No build attempted.
        assert len(renderer.builds) == 0
        assert rebuilder.last_build_succeeded is None


def _build_chain_with_deploy(
    tmp_path: Path, *, debounce_seconds: float = 0.05,
):
    """Same as _build_chain but the SiteRebuilder is configured with
    a deploy_target so post-rebuild deploys fire."""
    docs_repo = tmp_path / "docs"
    docs_repo.mkdir()
    target_dir = tmp_path / "out"
    target_dir.mkdir()
    (target_dir / ".git").mkdir()  # pretend it's a git working copy

    local = LocalStoreAdapter(docs_repo_path=docs_repo)
    replication = ReplicationManager([("local", local)])  # type: ignore[arg-type]

    renderer = _StubRenderer()
    rebuilder = SiteRebuilder(
        docs_repo=docs_repo,
        target_dir=target_dir,
        renderer=renderer,  # type: ignore[arg-type]
        debounce_seconds=debounce_seconds,
        deploy_target="origin",
        deploy_branch="pages",
    )
    replication.set_on_canonical_write(rebuilder.notify)
    return docs_repo, replication, rebuilder, renderer


class TestLiveUpdateChainWithAutoDeploy:
    @pytest.mark.asyncio
    async def test_canonical_write_triggers_rebuild_then_deploy(
        self, tmp_path, monkeypatch,
    ):
        """The full chain: create_issue → notify → debounce → build →
        git push. Mocks _run_git so the test runs hermetically."""
        git_calls: list[tuple[str, ...]] = []

        async def fake_run_git(self, *args):
            git_calls.append(args)

        monkeypatch.setattr(SiteRebuilder, "_run_git", fake_run_git)

        docs_repo, replication, rebuilder, renderer = _build_chain_with_deploy(
            tmp_path,
        )

        await replication.write(
            lambda a: a.create_issue(
                owner="test", repo="repo",
                title="t", body="b", labels=["kind:bug"],
            ),
            operation_name="create_issue",
        )
        await asyncio.sleep(0.1)

        # Build ran exactly once.
        assert len(renderer.builds) == 1
        assert rebuilder.last_build_succeeded is True
        # Deploy ran post-build: add → commit → push origin HEAD:pages.
        assert len(git_calls) == 3
        assert git_calls[0] == ("add", "-A")
        assert git_calls[1][0] == "commit"
        assert git_calls[2] == ("push", "origin", "HEAD:pages")
        assert rebuilder.last_deploy_succeeded is True

    @pytest.mark.asyncio
    async def test_deploy_failure_does_not_propagate_into_canonical(
        self, tmp_path, monkeypatch,
    ):
        """A failed git push must NOT poison the canonical write —
        the create_issue call returns successfully even though the
        deploy step blew up. last_deploy_succeeded captures the
        deploy outcome separately for diagnostics."""
        import subprocess
        captured: list[Exception] = []

        async def fail_push(self, *args):
            if args and args[0] == "push":
                raise subprocess.CalledProcessError(1, ["git", "push"])

        monkeypatch.setattr(SiteRebuilder, "_run_git", fail_push)

        docs_repo, replication, rebuilder, renderer = _build_chain_with_deploy(
            tmp_path,
        )
        # Override on_failure so we capture the deploy failure.
        rebuilder._on_failure = captured.append  # type: ignore[attr-defined]

        # Canonical write succeeds — the deploy failure must not surface
        # back here.
        result = await replication.write(
            lambda a: a.create_issue(
                owner="t", repo="r", title="t", body="", labels=[],
            ),
            operation_name="create_issue",
        )
        assert result.title == "t"  # canonical happy-path
        await asyncio.sleep(0.1)

        # Build succeeded; deploy failed; on_failure received the err.
        assert rebuilder.last_build_succeeded is True
        assert rebuilder.last_deploy_succeeded is False
        assert len(captured) == 1

    @pytest.mark.asyncio
    async def test_build_failure_short_circuits_deploy(
        self, tmp_path, monkeypatch,
    ):
        """When the build step itself fails, the deploy step MUST
        NOT run — pushing a stale or partial site is worse than not
        pushing."""
        deploy_attempts: list[tuple[str, ...]] = []

        async def fake_run_git(self, *args):
            deploy_attempts.append(args)

        monkeypatch.setattr(SiteRebuilder, "_run_git", fake_run_git)

        docs_repo, replication, rebuilder, renderer = _build_chain_with_deploy(
            tmp_path,
        )
        # Force the renderer to fail.
        renderer.failure = RuntimeError("hugo crashed")  # type: ignore[attr-defined]

        await replication.write(
            lambda a: a.create_issue(
                owner="t", repo="r", title="t", body="", labels=[],
            ),
            operation_name="create_issue",
        )
        await asyncio.sleep(0.1)

        assert rebuilder.last_build_succeeded is False
        assert rebuilder.last_deploy_succeeded is None
        assert deploy_attempts == []


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
