"""Unit tests for PlatformAdapter canonical types (3.0 / Phase 2)."""
from __future__ import annotations

from datetime import datetime

import pytest
from pydantic import ValidationError

from forge_manager_mcp.adapters.types import (
    ArtifactRef,
    BootstrapResult,
    Comment,
    Discussion,
    DriftReport,
    Issue,
    Label,
    Milestone,
    Release,
    SessionEvent,
)


# ---------------------------------------------------------------------------
# ArtifactRef
# ---------------------------------------------------------------------------

class TestArtifactRef:
    def test_basic_construction(self):
        ref = ArtifactRef(
            platform_id="github",
            native_id="I_kwDO123",
            kind="issue",
            owner="org", repo="proj",
            number=42,
        )
        assert ref.platform_id == "github"
        assert ref.kind == "issue"
        assert ref.number == 42

    def test_frozen(self):
        ref = ArtifactRef(
            platform_id="local", native_id="issues/1",
            kind="issue", owner="o", repo="r", number=1,
        )
        with pytest.raises(ValidationError):
            ref.platform_id = "github"  # type: ignore

    def test_extra_forbid(self):
        with pytest.raises(ValidationError):
            ArtifactRef(
                platform_id="local", native_id="x",
                kind="issue", owner="o", repo="r",
                bogus_field="oops",  # type: ignore
            )

    def test_kind_literal(self):
        with pytest.raises(ValidationError):
            ArtifactRef(
                platform_id="local", native_id="x",
                kind="not-a-kind",  # type: ignore
                owner="o", repo="r",
            )

    def test_number_optional(self):
        # Comments don't have repo-scoped numbers.
        ref = ArtifactRef(
            platform_id="github",
            native_id="DC_abc",
            kind="comment",
            owner="o", repo="r",
            # number omitted
        )
        assert ref.number is None


# ---------------------------------------------------------------------------
# Issue
# ---------------------------------------------------------------------------

class TestIssue:
    def test_minimal_construction(self):
        ref = ArtifactRef(
            platform_id="github", native_id="x", kind="issue",
            owner="o", repo="r", number=1,
        )
        issue = Issue(
            ref=ref,
            title="t",
            body="b",
            state="open",
        )
        assert issue.title == "t"
        assert issue.labels == []
        assert issue.milestone is None

    def test_full_construction(self):
        ref = ArtifactRef(
            platform_id="github", native_id="x", kind="issue",
            owner="o", repo="r", number=42,
        )
        now = datetime.now()
        issue = Issue(
            ref=ref,
            title="big",
            body="body",
            state="open",
            labels=["kind:bug", "area:mcp"],
            milestone="3.0.0",
            author="claude",
            created_at=now,
            updated_at=now,
            url="https://github.com/o/r/issues/42",
        )
        assert "kind:bug" in issue.labels
        assert issue.url == "https://github.com/o/r/issues/42"

    def test_state_literal(self):
        ref = ArtifactRef(
            platform_id="local", native_id="x", kind="issue",
            owner="o", repo="r", number=1,
        )
        with pytest.raises(ValidationError):
            Issue(ref=ref, title="t", body="b", state="weird")  # type: ignore


# ---------------------------------------------------------------------------
# Discussion
# ---------------------------------------------------------------------------

class TestDiscussion:
    def test_with_category(self):
        ref = ArtifactRef(
            platform_id="github", native_id="x", kind="discussion",
            owner="o", repo="r", number=10,
        )
        d = Discussion(
            ref=ref,
            title="t",
            body="b",
            category="Architecture",
        )
        assert d.category == "Architecture"
        assert d.decided is False
        assert d.state == "open"

    def test_decided_flag(self):
        ref = ArtifactRef(
            platform_id="github", native_id="x", kind="discussion",
            owner="o", repo="r", number=10,
        )
        d = Discussion(
            ref=ref,
            title="t",
            body="b",
            decided=True,
        )
        assert d.decided is True


# ---------------------------------------------------------------------------
# Comment
# ---------------------------------------------------------------------------

class TestComment:
    def test_construction(self):
        parent = ArtifactRef(
            platform_id="github", native_id="x", kind="issue",
            owner="o", repo="r", number=1,
        )
        comment_ref = ArtifactRef(
            platform_id="github", native_id="DC_a", kind="comment",
            owner="o", repo="r",
        )
        c = Comment(
            ref=comment_ref,
            body="hello",
            author="claude",
            created_at=datetime.now(),
            parent=parent,
        )
        assert c.parent.kind == "issue"
        assert c.author == "claude"


# ---------------------------------------------------------------------------
# Label / Milestone / Release / DriftReport
# ---------------------------------------------------------------------------

class TestLabel:
    def test_default_color(self):
        l = Label(name="kind:bug")
        assert l.color == "0E8A16"
        assert l.description == ""


class TestMilestone:
    def test_minimal(self):
        m = Milestone(title="3.0.0", number=1, state="open")
        assert m.due_on is None
        assert m.state == "open"


class TestRelease:
    def test_default_not_prerelease(self):
        r = Release(tag="v3.0.0", name="3.0.0")
        assert r.prerelease is False


class TestDriftReport:
    def test_clean_report(self):
        d = DriftReport(platform_id="github", is_clean=True)
        assert d.issues_only_local == []
        assert d.issues_diverged == []
        assert d.notes == []

    def test_dirty_report(self):
        d = DriftReport(
            platform_id="codeberg",
            is_clean=False,
            issues_only_local=[42],
            issues_diverged=[7],
            notes=["state mismatch on #7"],
        )
        assert 42 in d.issues_only_local
        assert "state mismatch on #7" in d.notes


class TestSessionEvent:
    def test_minimal(self):
        ts = datetime(2026, 5, 1, 12, 0, 0)
        e = SessionEvent(session_id="abc", event="opened", timestamp=ts)
        assert e.body == ""
        assert e.timestamp == ts

    def test_frozen(self):
        e = SessionEvent(
            session_id="abc", event="opened",
            timestamp=datetime(2026, 5, 1),
        )
        with pytest.raises(ValidationError):
            e.event = "closed"  # type: ignore[misc]


class TestBootstrapResult:
    def test_minimal_complete(self):
        r = BootstrapResult(platform_id="local")
        assert r.platform_id == "local"
        assert r.artifacts == {}
        assert r.manual_steps == []
        assert r.phase == "complete"

    def test_awaiting_manual_with_steps(self):
        r = BootstrapResult(
            platform_id="github",
            artifacts={"repo_node_id": "R_x"},
            manual_steps=["Create Discussion category 'Architecture'"],
            phase="awaiting_manual",
        )
        assert r.phase == "awaiting_manual"
        assert len(r.manual_steps) == 1
        assert r.artifacts["repo_node_id"] == "R_x"

    def test_phase_rejects_unknown(self):
        with pytest.raises(ValidationError):
            BootstrapResult(platform_id="local", phase="bogus")

    def test_frozen(self):
        r = BootstrapResult(platform_id="local")
        with pytest.raises(ValidationError):
            r.platform_id = "github"  # type: ignore[misc]


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
