"""End-to-end test of the example interceptor chain (#292).

Exercises the chain in `tests/fixtures/example_chain.py` to verify all
four operator-facing patterns work simultaneously. Serves as a regression
check that the patterns are implementable end-to-end through the runtime,
and as a teaching-artifact verification that the docstring example
actually runs.
"""

from __future__ import annotations

import pytest

from forge_manager_mcp.interceptors import execute, result
from tests.fixtures.example_chain import (
    allocated,
    build_chain,
    released,
    reset_state,
)


@pytest.fixture(autouse=True)
def _reset_fixture_state():
    """Clear module-level state between tests so each starts clean."""
    reset_state()
    yield
    reset_state()


class TestExampleChainSuccessPath:
    """Primary verifier succeeds; chain runs forward + clean unwind."""

    def test_chain_executes_without_error(self):
        ctx = execute(build_chain(), request={})
        assert ctx.error is None

    def test_response_accumulates_three_top_level_keys(self):
        ctx = execute(build_chain(), request={})
        assert set(ctx.response.keys()) == {
            "temp_workspace", "verify_with_fallback", "det_check",
        }

    def test_verify_used_primary_path(self):
        ctx = execute(build_chain(), request={})
        # No fallback triggered; entry says primary
        assert ctx.response["verify_with_fallback"]["verdict"] == "passed-via-primary"

    def test_steps_taken_records_three_forward_entries(self):
        ctx = execute(build_chain(), request={})
        step_names = [entry["step"] for entry in ctx.steps_taken]
        assert step_names == [
            "temp_workspace", "verify_with_fallback", "det_check",
        ]
        # No compensated markers — clean success
        assert all("compensated" not in entry for entry in ctx.steps_taken)

    def test_raii_cleanup_runs_on_success_path(self):
        execute(build_chain(), request={})
        # temp_workspace allocated 1 path; leave released it
        assert len(allocated()) == 1
        assert len(released()) == 1
        assert allocated() == released()

    def test_result_returns_response(self):
        ctx = execute(build_chain(), request={})
        out = result(ctx)
        assert out is ctx.response


class TestExampleChainRecoveryPath:
    """Primary verifier fails; fallback recovers; unwind via leave."""

    def test_chain_executes_without_error_after_recovery(self):
        ctx = execute(build_chain(), request={"force_primary_failure": True})
        # Fallback ran and cleared ctx.error
        assert ctx.error is None

    def test_verify_used_fallback_path(self):
        ctx = execute(build_chain(), request={"force_primary_failure": True})
        verdict = ctx.response["verify_with_fallback"]
        assert verdict["verdict"] == "passed-via-fallback"
        assert verdict["via"] == "fallback"

    def test_det_check_skipped_when_recovery_via_error_handler(self):
        """When verify_with_fallback's enter sets ctx.error, descent halts.
        det_check (which would have come after) never enters. Recovery in
        verify_with_fallback's error handler clears the error, so unwind
        runs leave handlers — but det_check was never on the stack to
        begin with, so it doesn't run at all.
        """
        ctx = execute(build_chain(), request={"force_primary_failure": True})
        assert "det_check" not in ctx.response

    def test_raii_cleanup_runs_on_recovery_path(self):
        """Critical: temp_workspace.leave fires after recovery. RAII
        cleanup is the same on success and recovered-error paths.
        """
        execute(build_chain(), request={"force_primary_failure": True})
        assert len(allocated()) == 1
        assert len(released()) == 1, "RAII cleanup runs after recovery"

    def test_steps_taken_records_fallback_entry(self):
        ctx = execute(build_chain(), request={"force_primary_failure": True})
        step_names = [entry["step"] for entry in ctx.steps_taken]
        # temp_workspace (forward) + verify_with_fallback (fallback marker)
        assert "temp_workspace" in step_names
        assert "verify_with_fallback" in step_names
        # The fallback entry is documented as compensated=False (recovery
        # is not compensation — it's an alternate path that succeeded)
        verify_entries = [
            e for e in ctx.steps_taken if e["step"] == "verify_with_fallback"
        ]
        assert len(verify_entries) == 1
        assert verify_entries[0]["detail"]["via"] == "fallback"


if __name__ == "__main__":
    raise SystemExit(pytest.main([__file__, "-v"]))
