"""Unit tests for the 2.x → 3.0 migration tooling (3.0 / Phase 7).

Covers:
  - detect_legacy_state against a fixture 2.x project layout
  - Schema translation (github-config → forge-config shape)
  - apply_plan dry-run vs apply
  - Backup creation + rollback round-trip
  - Idempotence (running on an already-3.0 project is_clean)
  - CLAUDE.md mention rewrite preserves Pre- historical lines
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest

from forge_manager_mcp.migration import (
    MigrationPlan,
    apply_plan,
    detect_legacy_state,
    rollback_plan,
)
from forge_manager_mcp.migration.detector import _translate_config_schema
from forge_manager_mcp.migration.runner import (
    MigrationError,
    _replace_skill_mentions,
)


# ---------------------------------------------------------------------------
# Fixture builders
# ---------------------------------------------------------------------------

def _build_legacy_project(root: Path) -> Path:
    """Construct a fixture 2.x project layout."""
    claude_dir = root / ".claude"
    claude_dir.mkdir()

    skill_dir = claude_dir / "skills" / "active-claude-github"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("# active-claude-github skill\n")

    config = {
        "owner": "telejester",
        "repos": {
            "private": "telejester/proj-dev",
            "public": "telejester/proj",
            "docs": "telejester/proj-docs",
        },
        "project_id": "PROJ_123",
        "session_lock_discussion_id": "DIS_lock",
        "project_discussion_id": "DIS_proj",
    }
    (claude_dir / "github-config.json").write_text(
        json.dumps(config, indent=2),
        encoding="utf-8",
    )

    (root / "CLAUDE.md").write_text(
        "# CLAUDE.md\n"
        "## Skill Reference\n"
        "Invoke /active-claude-github at session start. The active-claude-github "
        "skill records every turn.\n"
        "\n"
        "(Pre-2.0 versions referenced @skill which doesn't work; 2.0 fixed this.)\n",
        encoding="utf-8",
    )
    return root


def _build_clean_3_0_project(root: Path) -> Path:
    """Construct a fixture project that's already fully on 3.0."""
    claude_dir = root / ".claude"
    claude_dir.mkdir()
    skill_dir = claude_dir / "skills" / "forge-manager"
    skill_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("# forge-manager skill\n")
    (claude_dir / "forge-config.json").write_text(
        json.dumps({"schema_version": "3.0", "platforms": []}),
        encoding="utf-8",
    )
    (root / "CLAUDE.md").write_text("# CLAUDE.md (forge-manager)\n")
    return root


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------

class TestDetector:
    def test_legacy_project_yields_three_steps(self, tmp_path: Path):
        proj = _build_legacy_project(tmp_path)
        plan = detect_legacy_state(proj)
        kinds = [s.kind for s in plan.steps]
        assert "rename_skill_dir" in kinds
        assert "translate_config_schema" in kinds
        assert "update_claude_md" in kinds
        assert plan.is_clean is False

    def test_clean_3_0_project_is_clean(self, tmp_path: Path):
        proj = _build_clean_3_0_project(tmp_path)
        plan = detect_legacy_state(proj)
        assert plan.is_clean is True
        assert plan.steps == []

    def test_partial_migration_only_lists_remaining_steps(self, tmp_path: Path):
        # Skill already renamed but config still legacy — only the
        # config + CLAUDE.md (if it has legacy mentions) steps should
        # appear.
        claude_dir = tmp_path / ".claude"
        (claude_dir / "skills" / "forge-manager").mkdir(parents=True)
        (claude_dir / "github-config.json").write_text(
            json.dumps({"owner": "x", "repos": {"private": "x/y"}}),
        )
        plan = detect_legacy_state(tmp_path)
        kinds = [s.kind for s in plan.steps]
        assert "rename_skill_dir" not in kinds
        assert "translate_config_schema" in kinds

    def test_both_skill_dirs_present_warns_no_step(self, tmp_path: Path):
        # Defensive: never auto-rename if both old + new exist; warn instead.
        proj = _build_legacy_project(tmp_path)
        # Add the new skill dir alongside the legacy one.
        (proj / ".claude" / "skills" / "forge-manager").mkdir()
        plan = detect_legacy_state(proj)
        kinds = [s.kind for s in plan.steps]
        assert "rename_skill_dir" not in kinds
        assert any("manual review" in w for w in plan.warnings)

    def test_missing_claude_md_warns(self, tmp_path: Path):
        # A project without CLAUDE.md still migrates — just no
        # mention-update step.
        claude_dir = tmp_path / ".claude"
        (claude_dir / "skills" / "active-claude-github").mkdir(parents=True)
        plan = detect_legacy_state(tmp_path)
        # Skill rename step still emitted.
        assert any(s.kind == "rename_skill_dir" for s in plan.steps)
        # CLAUDE.md absence flagged as warning.
        assert any("CLAUDE.md" in w for w in plan.warnings)

    def test_summary_human_readable(self, tmp_path: Path):
        proj = _build_legacy_project(tmp_path)
        plan = detect_legacy_state(proj)
        summary = plan.summary()
        assert "Migration plan" in summary
        assert "step" in summary

    def test_clean_summary(self, tmp_path: Path):
        proj = _build_clean_3_0_project(tmp_path)
        plan = detect_legacy_state(proj)
        assert "already on 3.0" in plan.summary()


# ---------------------------------------------------------------------------
# Schema translation
# ---------------------------------------------------------------------------

class TestSchemaTranslation:
    def test_emits_platforms_list(self):
        legacy = {
            "owner": "telejester",
            "repos": {"private": "x/y-dev", "public": "x/y"},
        }
        translated = _translate_config_schema(legacy)
        assert "platforms" in translated
        assert translated["platforms"][0]["id"] == "github"
        assert translated["platforms"][0]["owner"] == "telejester"
        assert translated["platforms"][0]["private"] == "x/y-dev"

    def test_replication_order_includes_local_and_github(self):
        legacy = {"owner": "x", "repos": {"private": "x/y"}}
        translated = _translate_config_schema(legacy)
        assert translated["replication_order"] == ["local", "github"]

    def test_schema_version_set(self):
        translated = _translate_config_schema({"owner": "x", "repos": {}})
        assert translated["schema_version"] == "3.0"

    def test_preserves_legacy_top_level_fields(self):
        legacy = {
            "owner": "x",
            "repos": {"private": "x/y"},
            "project_id": "PROJ_ABC",
            "session_lock_discussion_id": "DIS_xyz",
        }
        translated = _translate_config_schema(legacy)
        assert translated["project_id"] == "PROJ_ABC"
        assert translated["session_lock_discussion_id"] == "DIS_xyz"

    def test_skill_rewritten_to_forge_manager(self):
        """G1: 2.x configs literally have skill='active-claude-github';
        the translator rewrites it to the canonical 3.0 name."""
        legacy = {
            "owner": "x",
            "repos": {"private": "x/y"},
            "skill": "active-claude-github",
        }
        translated = _translate_config_schema(legacy)
        assert translated["skill"] == "forge-manager"

    def test_skill_already_renamed_left_alone(self):
        """A re-run translator (idempotency) on an already-3.0 config
        leaves the skill field at forge-manager."""
        legacy = {
            "owner": "x",
            "repos": {"private": "x/y"},
            "skill": "forge-manager",
        }
        translated = _translate_config_schema(legacy)
        assert translated["skill"] == "forge-manager"

    def test_skill_unset_not_added(self):
        """If the legacy config somehow has no skill key, the translator
        doesn't synthesize one — the model validator catches the
        missing-required-field case downstream."""
        legacy = {"owner": "x", "repos": {"private": "x/y"}}
        translated = _translate_config_schema(legacy)
        assert "skill" not in translated

    def test_docs_repo_synthesized_from_public_basename(self, monkeypatch):
        """G6: translator synthesizes ``repos.docs`` and
        ``docs_repo_path`` from ``repos.public`` basename."""
        monkeypatch.setattr(Path, "home", lambda: Path("/tmp/fake-home"))
        legacy = {
            "owner": "myorg",
            "repos": {"public": "myorg/widgets", "private": "myorg/widgets-dev"},
        }
        translated = _translate_config_schema(legacy)
        assert translated["repos"]["docs"] == "myorg/widgets-docs"
        assert translated["docs_repo_path"] == "/tmp/fake-home/widgets-docs"

    def test_docs_repo_preserves_existing_docs_field(self, monkeypatch):
        """G6: when the legacy config already names ``repos.docs``, the
        translator preserves it (no clobber)."""
        monkeypatch.setattr(Path, "home", lambda: Path("/tmp/fake-home"))
        legacy = {
            "owner": "myorg",
            "repos": {
                "public": "myorg/widgets",
                "docs": "myorg/widgets-docs-explicit",
            },
        }
        translated = _translate_config_schema(legacy)
        assert translated["repos"]["docs"] == "myorg/widgets-docs-explicit"

    def test_docs_repo_skipped_when_project_name_underivable(self, monkeypatch):
        """G6: when neither ``repos.public`` nor ``repos.private`` carry
        a project basename and no project_dir is supplied, the
        translator skips synthesizing docs fields."""
        monkeypatch.setattr(Path, "home", lambda: Path("/tmp/fake-home"))
        legacy = {"owner": "myorg", "repos": {}}
        translated = _translate_config_schema(legacy)
        assert "docs_repo_path" not in translated
        # repos may or may not exist depending on setdefault behavior;
        # the docs key must not be present.
        assert "docs" not in (translated.get("repos") or {})

    def test_docs_repo_uses_project_dir_fallback(self, monkeypatch, tmp_path):
        """G6: when repos doesn't carry a slash-form name but
        ``project_dir`` is supplied, fall back to the dir name."""
        monkeypatch.setattr(Path, "home", lambda: Path("/tmp/fake-home"))
        monkeypatch.delenv("FORGE_MANAGER_DOCS_REPO", raising=False)
        legacy = {"owner": "myorg", "repos": {}}
        proj = tmp_path / "widgets"
        proj.mkdir()
        translated = _translate_config_schema(legacy, project_dir=proj)
        assert translated["docs_repo_path"] == "/tmp/fake-home/widgets-docs"

    def test_docs_repo_path_honors_env_override(self, monkeypatch):
        """FIX-5: when ``$FORGE_MANAGER_DOCS_REPO`` is set, the
        translator emits that path rather than the conventional
        ``~/<project>-docs/`` default. The env var is the documented
        override for the SiteRenderer's resolver; migration must
        respect it rather than silently overwrite."""
        monkeypatch.setattr(Path, "home", lambda: Path("/tmp/fake-home"))
        monkeypatch.setenv(
            "FORGE_MANAGER_DOCS_REPO", "/custom/docs/location",
        )
        legacy = {
            "owner": "myorg",
            "repos": {"public": "myorg/widgets"},
        }
        translated = _translate_config_schema(legacy)
        assert translated["docs_repo_path"] == "/custom/docs/location"

    def test_docs_repo_path_env_override_uses_expanduser(
        self, monkeypatch, tmp_path,
    ):
        """FIX-5: a tilde in ``$FORGE_MANAGER_DOCS_REPO`` expands to
        the home directory so operators can write portable values.
        ``Path.expanduser`` reads ``$HOME`` (not ``Path.home``); patch
        the env var so the test isolates from the real home dir."""
        fake_home = tmp_path / "fake-home"
        fake_home.mkdir()
        monkeypatch.setenv("HOME", str(fake_home))
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", "~/my-docs-folder")
        legacy = {
            "owner": "myorg",
            "repos": {"public": "myorg/widgets"},
        }
        translated = _translate_config_schema(legacy)
        # Tilde expanded then resolved against the patched $HOME.
        assert translated["docs_repo_path"] == str(
            (fake_home / "my-docs-folder").resolve()
        )

    def test_docs_repo_path_empty_env_falls_back_to_default(self, monkeypatch):
        """FIX-5: an empty / whitespace-only env var doesn't count;
        treat it as unset so the default path applies."""
        monkeypatch.setattr(Path, "home", lambda: Path("/tmp/fake-home"))
        monkeypatch.setenv("FORGE_MANAGER_DOCS_REPO", "   ")
        legacy = {
            "owner": "myorg",
            "repos": {"public": "myorg/widgets"},
        }
        translated = _translate_config_schema(legacy)
        assert translated["docs_repo_path"] == "/tmp/fake-home/widgets-docs"


class TestDocsRepoStepDetection:
    """G6: detector emits ``bootstrap_docs_repo`` for a 2.x project."""

    def test_legacy_project_emits_docs_step(self, tmp_path, monkeypatch):
        # Fresh home — the bootstrap step fires when ~/<proj>-docs is absent.
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: fake_home)

        proj = _build_legacy_project(tmp_path)
        plan = detect_legacy_state(proj)
        kinds = [s.kind for s in plan.steps]
        assert "bootstrap_docs_repo" in kinds

        step = next(s for s in plan.steps if s.kind == "bootstrap_docs_repo")
        # Path resolves under the (faked) home, not the real one.
        assert step.payload["docs_path"].startswith(str(fake_home))
        # Project name derived from repos.public basename (fixture: "proj").
        assert step.payload["project_name"] == "proj"
        # docs_repo_full carries the GitHub coords for the remote.
        assert step.payload["docs_repo_full"] == "telejester/proj-docs"

    def test_skipped_when_local_docs_already_initialized(
        self, tmp_path, monkeypatch,
    ):
        """G6: if ~/<proj>-docs/.git/ already exists, the runner doesn't
        need to bootstrap it again — detector skips the step."""
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: fake_home)
        # Simulate an existing local docs repo at ~/proj-docs/.git/.
        existing = fake_home / "proj-docs"
        (existing / ".git").mkdir(parents=True)

        proj = _build_legacy_project(tmp_path)
        plan = detect_legacy_state(proj)
        kinds = [s.kind for s in plan.steps]
        assert "bootstrap_docs_repo" not in kinds


class TestDocsRepoStepRunner:
    """G6: runner executes the ``bootstrap_docs_repo`` step end-to-end."""

    def test_apply_creates_local_docs_repo(self, tmp_path, monkeypatch):
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: fake_home)

        proj = _build_legacy_project(tmp_path)
        plan = detect_legacy_state(proj)
        result = apply_plan(plan, apply=True)

        assert result["applied"] is True
        # Backup created.
        assert result["backup_path"] is not None
        # Local docs repo materialized.
        docs = fake_home / "proj-docs"
        assert (docs / ".git").is_dir()
        assert (docs / "README.md").is_file()
        assert "proj-docs" in (docs / "README.md").read_text()

    def test_origin_conflict_in_step_runner_records_note_not_fatal(
        self, tmp_path,
    ):
        """Direct test of the runner's bootstrap_docs_repo step
        handler when ensure_local_docs_repo raises
        DocsRepoOriginConflict. The detector's gate skips the step
        when .git exists, so this path is reachable only by direct
        step injection (defensive runner code for an exotic race
        between detect and apply)."""
        import subprocess as _sp
        from forge_manager_mcp.migration.detector import MigrationStep
        from forge_manager_mcp.migration.runner import _execute_step

        # Pre-create a docs repo with a different origin set.
        docs = tmp_path / "proj-docs"
        docs.mkdir()
        _sp.run(["git", "init", "-q", "-b", "main"], cwd=docs, check=True)
        _sp.run(
            ["git", "remote", "add", "origin",
             "https://forgejo.example/owner/proj-docs.git"],
            cwd=docs, check=True,
        )

        # Inject a bootstrap_docs_repo step pointing at the
        # already-initialized repo with a conflicting target URL.
        step = MigrationStep(
            kind="bootstrap_docs_repo",
            description="conflict-path probe",
            source=None,
            target=str(docs),
            payload={
                "docs_path": str(docs),
                "project_name": "proj-docs",
                "docs_repo_full": "telejester/proj-docs",  # github URL
            },
        )
        # Should NOT raise; should record manual_step_note in payload.
        _execute_step(tmp_path, step)
        note = step.payload.get("manual_step_note", "")
        assert "origin already set" in note
        assert "git remote set-url" in note

        # Origin preserved — runner did not overwrite.
        existing = _sp.run(
            ["git", "remote", "get-url", "origin"],
            cwd=docs, capture_output=True, text=True, check=True,
        )
        assert "forgejo.example" in existing.stdout

    def test_dry_run_does_not_create_docs_repo(self, tmp_path, monkeypatch):
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        monkeypatch.setattr(Path, "home", lambda: fake_home)

        proj = _build_legacy_project(tmp_path)
        plan = detect_legacy_state(proj)
        result = apply_plan(plan, apply=False)

        assert result["applied"] is False
        # Filesystem untouched.
        assert not (fake_home / "proj-docs").exists()



# ---------------------------------------------------------------------------
# CLAUDE.md mention rewrite
# ---------------------------------------------------------------------------

class TestReplaceSkillMentions:
    def test_replaces_bare_mentions(self):
        original = "Invoke /active-claude-github at session start.\n"
        out = _replace_skill_mentions(original)
        assert "/forge-manager" in out
        assert "active-claude-github" not in out

    def test_preserves_pre_2_0_historical_line(self):
        # Lines starting with 'Pre-' or containing parenthetical
        # 'pre-X.Y' get left alone — they document the rename history.
        original = "(Pre-2.0 versions of active-claude-github did Z.)\n"
        out = _replace_skill_mentions(original)
        assert "active-claude-github" in out  # preserved
        assert "Pre-" in out

    def test_multiple_lines_mixed(self):
        original = (
            "active-claude-github does X.\n"
            "(Pre-2.0 active-claude-github did Y.)\n"
            "active-claude-github also does Z.\n"
        )
        out = _replace_skill_mentions(original)
        lines = out.splitlines()
        assert "forge-manager" in lines[0]
        assert "active-claude-github" in lines[1]  # historical preserved
        assert "forge-manager" in lines[2]


# ---------------------------------------------------------------------------
# Runner — dry-run + apply + rollback
# ---------------------------------------------------------------------------

class TestApplyPlanDryRun:
    def test_dry_run_does_not_mutate(self, tmp_path: Path):
        proj = _build_legacy_project(tmp_path)
        plan = detect_legacy_state(proj)
        result = apply_plan(plan, apply=False)
        assert result["applied"] is False
        # No backup created.
        assert result["backup_path"] is None
        # Filesystem untouched.
        assert (proj / ".claude" / "skills" / "active-claude-github").is_dir()
        assert (proj / ".claude" / "github-config.json").is_file()
        # Steps reported with executed=False.
        assert all(s["executed"] is False for s in result["steps"])


class TestApplyPlanApply:
    @pytest.fixture(autouse=True)
    def _isolate_home(self, tmp_path_factory, monkeypatch):
        """Sandbox the docs-repo home for every test in this class so
        the bootstrap_docs_repo step (G6) writes only into a tmp dir,
        never the real ``$HOME``."""
        fake_home = tmp_path_factory.mktemp("fake-home")
        monkeypatch.setattr(Path, "home", lambda: fake_home)

    def test_full_migration_round_trip(self, tmp_path: Path):
        proj = _build_legacy_project(tmp_path)
        plan = detect_legacy_state(proj)
        result = apply_plan(plan, apply=True)
        assert result["applied"] is True
        assert result["backup_path"] is not None
        # New skill dir present, old gone.
        assert (proj / ".claude" / "skills" / "forge-manager").is_dir()
        assert not (proj / ".claude" / "skills" / "active-claude-github").exists()
        # New config present, old gone.
        assert (proj / ".claude" / "forge-config.json").is_file()
        assert not (proj / ".claude" / "github-config.json").exists()
        # New config has 3.0 schema fields.
        new_config = json.loads(
            (proj / ".claude" / "forge-config.json").read_text(encoding="utf-8")
        )
        assert new_config["schema_version"] == "3.0"
        assert new_config["platforms"][0]["id"] == "github"
        # CLAUDE.md updated for non-historical mentions.
        claude_md = (proj / "CLAUDE.md").read_text(encoding="utf-8")
        # The Pre-2.0 line is preserved.
        assert "Pre-2.0 versions" in claude_md

    def test_clean_project_apply_is_noop(self, tmp_path: Path):
        proj = _build_clean_3_0_project(tmp_path)
        plan = detect_legacy_state(proj)
        result = apply_plan(plan, apply=True)
        assert result["applied"] is True
        assert result["backup_path"] is None
        assert result["steps"] == []

    def test_backup_contains_legacy_state(self, tmp_path: Path):
        proj = _build_legacy_project(tmp_path)
        plan = detect_legacy_state(proj)
        result = apply_plan(plan, apply=True)
        backup = Path(result["backup_path"])
        # Backup snapshot includes the legacy skill dir + config.
        assert (backup / "skills" / "active-claude-github").is_dir()
        assert (backup / "github-config.json").is_file()


class TestRollback:
    @pytest.fixture(autouse=True)
    def _isolate_home(self, tmp_path_factory, monkeypatch):
        fake_home = tmp_path_factory.mktemp("fake-home")
        monkeypatch.setattr(Path, "home", lambda: fake_home)

    def test_round_trip_restores_legacy_state(self, tmp_path: Path):
        proj = _build_legacy_project(tmp_path)
        plan = detect_legacy_state(proj)
        result = apply_plan(plan, apply=True)
        backup = Path(result["backup_path"])

        # State is now 3.0.
        assert (proj / ".claude" / "skills" / "forge-manager").is_dir()

        rollback_result = rollback_plan(
            project_dir=proj, backup_path=backup,
        )
        assert rollback_result["restored"] is True

        # State restored to legacy.
        assert (proj / ".claude" / "skills" / "active-claude-github").is_dir()
        assert (proj / ".claude" / "github-config.json").is_file()
        # Pre-rollback dir holds the 3.0 state for forensic review.
        pre_rollback = Path(rollback_result["pre_rollback_dir"])
        assert pre_rollback.is_dir()

    def test_rollback_with_missing_backup_raises(self, tmp_path: Path):
        proj = _build_legacy_project(tmp_path)
        with pytest.raises(MigrationError, match="backup not found"):
            rollback_plan(project_dir=proj, backup_path=tmp_path / "no-such-dir")


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
