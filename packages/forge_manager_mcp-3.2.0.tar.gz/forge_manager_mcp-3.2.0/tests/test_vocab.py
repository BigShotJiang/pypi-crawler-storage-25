"""Unit tests for the reserved vocabulary module (3.0 / Phase 1b.3).

Covers the kind:* / category:* label namespace, multi-dim state
axis parsing/rendering, and the predicate helpers. Pure-stdlib;
no GitHub or filesystem.
"""
from __future__ import annotations

import pytest

from forge_manager_mcp.vocab import (
    ALL_RESERVED_STATES,
    ARCHIVE_STATES,
    BARE_TYPE_LABELS,
    CATEGORY_LABELS,
    DECISION_STATES,
    KIND_LABELS,
    LIFECYCLE_STATES,
    bare_to_kind,
    is_archived,
    is_closed,
    is_decided,
    is_merged,
    is_open,
    kind_to_bare,
    parse_state_file,
    render_state_file,
)


# ---------------------------------------------------------------------------
# Reserved-set membership
# ---------------------------------------------------------------------------

class TestKindLabels:
    def test_canonical_set(self):
        assert "kind:bug" in KIND_LABELS
        assert "kind:rfc" in KIND_LABELS
        assert "kind:feature" in KIND_LABELS
        assert "kind:refactor" in KIND_LABELS
        assert "kind:chore" in KIND_LABELS
        assert "kind:discussion" in KIND_LABELS
        assert "kind:answer" in KIND_LABELS

    def test_size(self):
        assert len(KIND_LABELS) == 7

    def test_excludes_non_kind_labels(self):
        assert "bug" not in KIND_LABELS
        assert "category:architecture" not in KIND_LABELS
        assert "area:mcp" not in KIND_LABELS


class TestCategoryLabels:
    def test_canonical_set(self):
        assert "category:architecture" in CATEGORY_LABELS
        assert "category:ideas" in CATEGORY_LABELS
        assert "category:ux" in CATEGORY_LABELS

    def test_size(self):
        assert len(CATEGORY_LABELS) == 3


class TestBareTypeLabels:
    def test_canonical_set(self):
        assert "bug" in BARE_TYPE_LABELS
        assert "rfc" in BARE_TYPE_LABELS
        assert "feature" in BARE_TYPE_LABELS
        assert "refactor" in BARE_TYPE_LABELS
        assert "chore" in BARE_TYPE_LABELS

    def test_size(self):
        assert len(BARE_TYPE_LABELS) == 5

    def test_excludes_kind_only_kinds(self):
        # discussion + answer are kind:-only — no bare equivalent.
        assert "discussion" not in BARE_TYPE_LABELS
        assert "answer" not in BARE_TYPE_LABELS


# ---------------------------------------------------------------------------
# kind ↔ bare translation
# ---------------------------------------------------------------------------

class TestKindToBare:
    @pytest.mark.parametrize("kind,bare", [
        ("kind:bug", "bug"),
        ("kind:rfc", "rfc"),
        ("kind:feature", "feature"),
        ("kind:refactor", "refactor"),
        ("kind:chore", "chore"),
    ])
    def test_round_trip(self, kind, bare):
        assert kind_to_bare(kind) == bare
        assert bare_to_kind(bare) == kind

    def test_non_kind_passes_through(self):
        assert kind_to_bare("area:mcp") == "area:mcp"
        assert kind_to_bare("priority:high") == "priority:high"
        assert kind_to_bare("plain") == "plain"

    def test_non_bare_passes_through_to_kind(self):
        # Open-set labels passed to bare_to_kind don't get a kind: prefix.
        assert bare_to_kind("area:mcp") == "area:mcp"
        assert bare_to_kind("priority:high") == "priority:high"

    def test_kind_discussion_no_bare_form(self):
        # discussion and answer are kind:-only labels. kind_to_bare
        # mechanically strips the prefix even though the result isn't
        # in BARE_TYPE_LABELS — adapters that need the bare form
        # consult BARE_TYPE_LABELS to know whether the result is valid.
        assert kind_to_bare("kind:discussion") == "discussion"
        assert "discussion" not in BARE_TYPE_LABELS


# ---------------------------------------------------------------------------
# State axes
# ---------------------------------------------------------------------------

class TestStateAxes:
    def test_lifecycle_set(self):
        assert LIFECYCLE_STATES == {"open", "closed", "merged"}

    def test_decision_set(self):
        assert DECISION_STATES == {"decided"}

    def test_archive_set(self):
        assert ARCHIVE_STATES == {"archived"}

    def test_axes_disjoint(self):
        assert LIFECYCLE_STATES.isdisjoint(DECISION_STATES)
        assert LIFECYCLE_STATES.isdisjoint(ARCHIVE_STATES)
        assert DECISION_STATES.isdisjoint(ARCHIVE_STATES)

    def test_all_reserved_is_union(self):
        assert (
            ALL_RESERVED_STATES
            == LIFECYCLE_STATES | DECISION_STATES | ARCHIVE_STATES
        )


# ---------------------------------------------------------------------------
# parse_state_file
# ---------------------------------------------------------------------------

class TestParseStateFile:
    def test_single_line(self):
        assert parse_state_file("open\n") == {"open"}

    def test_multi_line(self):
        assert parse_state_file("open\ndecided\n") == {"open", "decided"}

    def test_empty_input(self):
        assert parse_state_file("") == set()

    def test_blank_lines_ignored(self):
        assert parse_state_file("\nopen\n\ndecided\n\n") == {"open", "decided"}

    def test_comments_ignored(self):
        assert parse_state_file("# this is a comment\nopen\n") == {"open"}

    def test_whitespace_stripped(self):
        assert parse_state_file("  open  \n  decided  \n") == {"open", "decided"}

    def test_dedupes_via_set_semantics(self):
        # If a file accidentally has the same state twice, parse to one entry.
        assert parse_state_file("open\nopen\ndecided\n") == {"open", "decided"}

    def test_open_only_2x_compat(self):
        # 2.x state.txt files are single-line; they parse cleanly.
        assert parse_state_file("open") == {"open"}


# ---------------------------------------------------------------------------
# render_state_file
# ---------------------------------------------------------------------------

class TestRenderStateFile:
    def test_single_state(self):
        assert render_state_file({"open"}) == "open\n"

    def test_multi_state_axis_ordered(self):
        # Lifecycle first, then decision, then archive, then other.
        result = render_state_file({"decided", "open", "archived"})
        # Axis order: open (lifecycle) → decided (decision) → archived (archive).
        assert result == "open\ndecided\narchived\n"

    def test_empty_set(self):
        assert render_state_file(set()) == "\n"

    def test_open_set_label_sorted_at_end(self):
        result = render_state_file({"open", "custom-axis"})
        # Lifecycle "open" comes first; "custom-axis" (non-reserved) at end.
        assert result == "open\ncustom-axis\n"

    def test_round_trip(self):
        # parse → render produces the canonical-axis-order form.
        original = "decided\nopen\n"
        rendered = render_state_file(parse_state_file(original))
        # Re-rendered form has the canonical order.
        assert rendered == "open\ndecided\n"

    def test_accepts_list_input(self):
        # API accepts list/set/frozenset.
        assert render_state_file(["open"]) == "open\n"
        assert render_state_file(frozenset({"open"})) == "open\n"


# ---------------------------------------------------------------------------
# Predicates
# ---------------------------------------------------------------------------

class TestPredicates:
    def test_is_open_true(self):
        assert is_open({"open"})
        assert is_open({"open", "decided"})

    def test_is_open_false(self):
        assert not is_open({"closed"})
        assert not is_open(set())

    def test_is_closed(self):
        assert is_closed({"closed"})
        assert not is_closed({"open"})

    def test_is_merged(self):
        assert is_merged({"merged"})
        assert not is_merged({"closed"})

    def test_is_decided(self):
        assert is_decided({"decided"})
        assert is_decided({"open", "decided"})
        assert not is_decided({"open"})

    def test_is_archived(self):
        assert is_archived({"archived"})
        assert not is_archived({"closed"})

    def test_orthogonal_axes(self):
        # Open + decided is a valid combination — they're orthogonal.
        states = {"open", "decided"}
        assert is_open(states)
        assert is_decided(states)
        assert not is_archived(states)

    def test_open_plus_archived(self):
        # Archived can coexist with any lifecycle state.
        states = {"open", "archived"}
        assert is_open(states)
        assert is_archived(states)


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
