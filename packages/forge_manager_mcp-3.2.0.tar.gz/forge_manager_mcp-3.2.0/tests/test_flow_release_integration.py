"""Integration test for the release flow chain (#294 Phase A).

Composes the real chain via build_release_chain, runs synthetic
failure injections at each step, and asserts:

* Compensation runs in correct reverse order on failure.
* response carries expected per-step + recovery markers.
* steps_taken contains forward + compensated entries paired correctly.
* Recovered-error path runs leaves not errors after the recovery.

Underlying _run_* callables are stubbed via monkeypatch — the
integration test exercises the chain runtime + per-step
interceptor composition, not the actual GitHub / git / pypi work.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from forge_manager_mcp.flows.release import build_release_chain
from forge_manager_mcp.interceptors import aexecute


def _server_ctx_stub(tmp_path: Path) -> SimpleNamespace:
    return SimpleNamespace(
        project_dir=tmp_path,
        github_token="ghp_test",
        config=SimpleNamespace(
            repos=SimpleNamespace(
                public="o/repo",
                private="o/repo-dev",
                docs="o/repo-docs",
            ),
        ),
    )


def _stub_all_runs_ok(monkeypatch, mirror_clone: Path):
    """Patch every _run_* in handlers.release to return an ok step."""
    monkeypatch.setattr(
        "forge_manager_mcp.server.handlers.release._run_validate",
        AsyncMock(
            return_value=(
                {"step": "validate", "status": "ok", "data": {"checks": []}},
                [],
                "monorepo",
            )
        ),
    )
    monkeypatch.setattr(
        "forge_manager_mcp.server.handlers.release._run_dev_tag",
        MagicMock(
            return_value={
                "step": "dev_tag",
                "status": "ok",
                "data": {"tag": "v9.9.9", "sha": "abc"},
            }
        ),
    )
    monkeypatch.setattr(
        "forge_manager_mcp.server.handlers.release._run_mirror_sync",
        MagicMock(
            return_value=(
                {"step": "mirror_sync", "status": "ok", "data": {}},
                mirror_clone,
            )
        ),
    )
    monkeypatch.setattr(
        "forge_manager_mcp.server.handlers.release._run_mirror_tag",
        MagicMock(
            return_value={
                "step": "mirror_tag",
                "status": "ok",
                "data": {"tag": "v9.9.9"},
            }
        ),
    )
    monkeypatch.setattr(
        "forge_manager_mcp.server.handlers.release._run_release_notes",
        MagicMock(
            return_value={"step": "release_notes", "status": "ok", "data": {}}
        ),
    )
    monkeypatch.setattr(
        "forge_manager_mcp.server.handlers.release._run_pypi_publish",
        MagicMock(
            return_value={"step": "pypi_publish", "status": "ok", "data": {}}
        ),
    )


def _request(server_ctx, **kwargs) -> dict:
    base = {
        "server_ctx": server_ctx,
        "version": "9.9.9",
        "notes": "test notes",
        "skip_bazel": False,
        "pypi_only": False,
        "dry_run": True,
    }
    base.update(kwargs)
    return base


class TestFullSuccessPath:
    @pytest.mark.asyncio
    async def test_dry_run_full_chain_records_every_step(
        self, tmp_path: Path, monkeypatch,
    ):
        _stub_all_runs_ok(monkeypatch, tmp_path / "mirror")
        chain = build_release_chain()
        ctx = await aexecute(
            chain, request=_request(_server_ctx_stub(tmp_path)),
        )
        assert ctx.error is None
        # Every step's response key present.
        for step_name in (
            "validate", "dev_tag", "mirror_sync", "mirror_tag",
            "release_notes",
        ):
            assert step_name in ctx.response, (
                f"missing response key {step_name}"
            )
        # steps_taken records every forward step.
        forward_steps = [
            s["step"] for s in ctx.steps_taken if not s.get("compensated")
        ]
        assert forward_steps == [
            "validate", "dev_tag", "mirror_sync", "mirror_tag", "release_notes"
        ]
        # No compensation on success.
        compensated = [
            s for s in ctx.steps_taken if s.get("compensated")
        ]
        assert compensated == []


class TestSingleStepFailure:
    @pytest.mark.asyncio
    async def test_validate_failure_halts_chain_no_compensation(
        self, tmp_path: Path, monkeypatch,
    ):
        # validate fails first; no state-mutating step ran, so no
        # compensation should fire.
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_validate",
            AsyncMock(
                return_value=(
                    {"step": "validate", "status": "failed", "data": {}},
                    [
                        {
                            "name": "milestone_closed",
                            "ok": False,
                            "severity": "fail",
                        }
                    ],
                    "monorepo",
                )
            ),
        )
        chain = build_release_chain()
        ctx = await aexecute(
            chain, request=_request(_server_ctx_stub(tmp_path)),
        )
        # Chain halted — error set on validate.
        assert ctx.error is not None
        assert "validate failed" in str(ctx.error)
        # Only validate is in response — subsequent steps never ran.
        assert "validate" in ctx.response
        assert "dev_tag" not in ctx.response
        assert "mirror_sync" not in ctx.response
        # No compensation entries — read-only step.
        compensated = [
            s for s in ctx.steps_taken if s.get("compensated")
        ]
        assert compensated == []

    @pytest.mark.asyncio
    async def test_mirror_sync_failure_compensates_dev_tag(
        self, tmp_path: Path, monkeypatch,
    ):
        # validate + dev_tag succeed; mirror_sync fails. dev_tag's
        # error handler should fire to record compensation intent.
        _stub_all_runs_ok(monkeypatch, tmp_path / "mirror")
        # Override mirror_sync to fail.
        monkeypatch.setattr(
            "forge_manager_mcp.server.handlers.release._run_mirror_sync",
            MagicMock(
                return_value=(
                    {
                        "step": "mirror_sync",
                        "status": "failed",
                        "data": {"error": "push rejected"},
                    },
                    None,
                )
            ),
        )
        chain = build_release_chain()
        ctx = await aexecute(
            chain, request=_request(_server_ctx_stub(tmp_path)),
        )
        assert ctx.error is not None
        # dev_tag's compensation surfaced as failed_compensations
        # because delete_tag isn't on releases_mod yet.
        failed = ctx.response.get("failed_compensations", ())
        assert any(f["step"] == "dev_tag" for f in failed), (
            f"expected dev_tag compensation entry; got {failed}"
        )
        # Compensation records appear in steps_taken.
        compensated = [
            s for s in ctx.steps_taken if s.get("compensated")
        ]
        # dev_tag compensation fires (recorded as compensated=True even
        # though the actual delete is unavailable).
        assert any(s["step"] == "dev_tag" for s in compensated)


class TestPypiOnlyPath:
    @pytest.mark.asyncio
    async def test_pypi_only_chain_runs_validate_then_publish(
        self, tmp_path: Path, monkeypatch,
    ):
        _stub_all_runs_ok(monkeypatch, tmp_path / "mirror")
        chain = build_release_chain(pypi_only=True)
        ctx = await aexecute(
            chain,
            request=_request(
                _server_ctx_stub(tmp_path), pypi_only=True,
            ),
        )
        assert ctx.error is None
        assert "validate" in ctx.response
        assert "pypi_publish" in ctx.response
        # GitHub-coupled steps never ran.
        assert "dev_tag" not in ctx.response
        assert "mirror_sync" not in ctx.response
        assert "mirror_tag" not in ctx.response
        assert "release_notes" not in ctx.response


class TestStopAfter:
    @pytest.mark.asyncio
    async def test_stop_after_truncates_chain(
        self, tmp_path: Path, monkeypatch,
    ):
        _stub_all_runs_ok(monkeypatch, tmp_path / "mirror")
        chain = build_release_chain(stop_after="dev_tag")
        ctx = await aexecute(
            chain, request=_request(_server_ctx_stub(tmp_path)),
        )
        assert ctx.error is None
        assert "validate" in ctx.response
        assert "dev_tag" in ctx.response
        assert "mirror_sync" not in ctx.response


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
