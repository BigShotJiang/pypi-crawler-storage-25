"""Per-step unit tests for the migration flow interceptor wrappers (#294 Phase B).

Mirrors the test pattern from tests/test_flow_release_steps.py: each
step's enter / error / leave handler tested in isolation via
mock-context. Underlying migration runner / detector primitives are
stubbed via monkeypatch.
"""
from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import pytest

from forge_manager_mcp.flows.migration import build_migration_chain
from forge_manager_mcp.flows.migration.backfill_canonical_from_remote import (
    make_backfill_canonical_from_remote_interceptor,
)
from forge_manager_mcp.flows.migration.backup_claude_dir import (
    MigrationStepFailed,
    make_backup_claude_dir_interceptor,
)
from forge_manager_mcp.flows.migration.bootstrap_docs_repo import (
    make_bootstrap_docs_repo_interceptor,
)
from forge_manager_mcp.flows.migration.detect_legacy_state import (
    make_detect_legacy_state_interceptor,
)
from forge_manager_mcp.flows.migration.finalize import (
    make_finalize_interceptor,
)
from forge_manager_mcp.flows.migration.rename_skill_dir import (
    make_rename_skill_dir_interceptor,
)
from forge_manager_mcp.flows.migration.rewrite_claude_md import (
    make_rewrite_claude_md_interceptor,
)
from forge_manager_mcp.flows.migration.translate_schema import (
    make_translate_schema_interceptor,
)
from forge_manager_mcp.interceptors import Context


def _request(project_dir: Path, **kwargs) -> dict:
    base = {"project_dir": project_dir, "apply": False}
    base.update(kwargs)
    return base


def _step(kind: str, source: str = "", target: str = "", **payload):
    return SimpleNamespace(
        kind=kind, source=source, target=target, payload=dict(payload),
    )


# ---------------------------------------------------------------------------
# backup_claude_dir
# ---------------------------------------------------------------------------

class TestBackupClaudeDir:
    @pytest.mark.asyncio
    async def test_dry_run_skips_backup(self, tmp_path: Path):
        ic = make_backup_claude_dir_interceptor()
        result = await ic.enter(Context(request=_request(tmp_path)))
        assert result.error is None
        assert result.response["backup_claude_dir"]["status"] == "dry_run_preview"

    @pytest.mark.asyncio
    async def test_apply_creates_backup(self, tmp_path: Path, monkeypatch):
        backup = tmp_path / "_backup"
        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._create_backup",
            MagicMock(return_value=backup),
        )
        ic = make_backup_claude_dir_interceptor()
        result = await ic.enter(
            Context(request=_request(tmp_path, apply=True))
        )
        assert result.error is None
        assert result.request["backup_path"] == backup
        assert result.response["backup_claude_dir"]["status"] == "ok"

    @pytest.mark.asyncio
    async def test_error_preserves_backup_with_rollback_command(
        self, tmp_path: Path,
    ):
        ic = make_backup_claude_dir_interceptor()
        ctx = Context(
            request=_request(tmp_path, apply=True),
            response={
                "backup_claude_dir": {
                    "status": "ok",
                    "backup_path": str(tmp_path / "_backup"),
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        compensation = result.steps_taken[-1]
        assert compensation["compensated"] is False  # backup preserved
        assert "migrate_to_3_0_rollback" in compensation["detail"][
            "rollback_command"
        ]


# ---------------------------------------------------------------------------
# detect_legacy_state
# ---------------------------------------------------------------------------

class TestDetectLegacyState:
    @pytest.mark.asyncio
    async def test_threads_plan_onto_request(
        self, tmp_path: Path, monkeypatch,
    ):
        plan = SimpleNamespace(
            steps=[_step("translate_config_schema")], warnings=[],
        )
        monkeypatch.setattr(
            "forge_manager_mcp.migration.detector.detect_legacy_state",
            MagicMock(return_value=plan),
        )
        ic = make_detect_legacy_state_interceptor()
        result = await ic.enter(Context(request=_request(tmp_path)))
        assert result.error is None
        assert result.request["plan"] is plan
        assert result.response["detect_legacy_state"]["step_count"] == 1


# ---------------------------------------------------------------------------
# translate_schema / rename_skill_dir / rewrite_claude_md
# ---------------------------------------------------------------------------

class TestTranslateSchema:
    @pytest.mark.asyncio
    async def test_skip_when_no_plan(self, tmp_path: Path):
        ic = make_translate_schema_interceptor()
        result = await ic.enter(Context(request=_request(tmp_path)))
        assert result.response["translate_schema"]["status"] == "skipped"

    @pytest.mark.asyncio
    async def test_apply_calls_runner_execute_step(
        self, tmp_path: Path, monkeypatch,
    ):
        target_step = _step(
            "translate_config_schema",
            source=".claude/github-config.json",
            target=".claude/forge-config.json",
            translated_data={"schema_version": "3.0"},
        )
        plan = SimpleNamespace(steps=[target_step], warnings=[])
        execute_step = MagicMock()
        monkeypatch.setattr(
            "forge_manager_mcp.migration.runner._execute_step",
            execute_step,
        )
        ic = make_translate_schema_interceptor()
        ctx = Context(request=_request(tmp_path, plan=plan, apply=True))
        result = await ic.enter(ctx)
        execute_step.assert_called_once()
        assert result.response["translate_schema"]["status"] == "ok"


class TestRenameSkillDir:
    @pytest.mark.asyncio
    async def test_compensation_reverses_rename(self, tmp_path: Path):
        # Set up a real on-disk rename — enter ran, wrote target;
        # compensation should reverse-rename target → source.
        source_rel = "skills/forge-manager"
        target_rel = "skills/active-claude-github"  # arbitrary
        # Pre-stage: target exists, source doesn't.
        target_dir = tmp_path / target_rel
        target_dir.mkdir(parents=True)
        ic = make_rename_skill_dir_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "rename_skill_dir": {
                    "status": "ok",
                    "source": source_rel,
                    "target": target_rel,
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        # Source dir exists post-compensation; target gone.
        assert (tmp_path / source_rel).is_dir()
        assert not (tmp_path / target_rel).exists()
        # Compensation entry recorded.
        assert any(
            s["step"] == "rename_skill_dir" and s.get("compensated")
            for s in result.steps_taken
        )


# ---------------------------------------------------------------------------
# bootstrap_docs_repo
# ---------------------------------------------------------------------------

class TestBootstrapDocsRepo:
    @pytest.mark.asyncio
    async def test_compensation_preserves_when_adopted(self, tmp_path: Path):
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "bootstrap_docs_repo": {
                    "status": "ok",
                    "docs_path": str(tmp_path / "docs"),
                    "existed_before": True,
                    "adopted_existing": True,
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        compensation = result.steps_taken[-1]
        assert compensation["compensated"] is False
        assert "adopted" in compensation["detail"]["reason"]

    @pytest.mark.asyncio
    async def test_compensation_deletes_when_created(self, tmp_path: Path):
        docs = tmp_path / "docs"
        docs.mkdir()
        (docs / "marker.txt").write_text("hi")
        ic = make_bootstrap_docs_repo_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "bootstrap_docs_repo": {
                    "status": "ok",
                    "docs_path": str(docs),
                    "existed_before": False,
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        # docs dir deleted by compensation.
        assert not docs.exists()
        compensation = result.steps_taken[-1]
        assert compensation["compensated"] is True


# ---------------------------------------------------------------------------
# backfill_canonical_from_remote
# ---------------------------------------------------------------------------

class TestBackfillCanonicalFromRemote:
    @pytest.mark.asyncio
    async def test_skip_when_no_since(self, tmp_path: Path):
        ic = make_backfill_canonical_from_remote_interceptor()
        result = await ic.enter(Context(request=_request(tmp_path)))
        assert (
            result.response["backfill_canonical_from_remote"]["status"]
            == "skipped"
        )

    @pytest.mark.asyncio
    async def test_compensation_is_passthrough(self, tmp_path: Path):
        ic = make_backfill_canonical_from_remote_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "backfill_canonical_from_remote": {
                    "status": "ok",
                    "imported": 5,
                    "conflicts": 0,
                    "skipped": 0,
                }
            },
            error=MigrationStepFailed("downstream"),
        )
        result = await ic.error(ctx)
        compensation = result.steps_taken[-1]
        # User data is not undone.
        assert compensation["compensated"] is False
        assert "user data" in compensation["detail"]["reason"]


# ---------------------------------------------------------------------------
# finalize
# ---------------------------------------------------------------------------

class TestFinalize:
    @pytest.mark.asyncio
    async def test_summarises_completed_and_skipped(self, tmp_path: Path):
        ic = make_finalize_interceptor()
        ctx = Context(
            request=_request(tmp_path),
            response={
                "translate_schema": {"status": "ok"},
                "rename_skill_dir": {"status": "ok"},
                "bootstrap_docs_repo": {"status": "skipped"},
            },
        )
        result = await ic.enter(ctx)
        f = result.response["finalize"]
        assert f["status"] == "ok"
        assert "translate_schema" in f["completed_steps"]
        assert "rename_skill_dir" in f["completed_steps"]
        assert "bootstrap_docs_repo" in f["skipped_steps"]


# ---------------------------------------------------------------------------
# Chain composer
# ---------------------------------------------------------------------------

class TestBuildMigrationChain:
    def test_full_chain_ordering(self):
        chain = build_migration_chain()
        names = [ic.name for ic in chain]
        assert names == [
            "migration.backup_claude_dir",
            "migration.detect_legacy_state",
            "migration.translate_schema",
            "migration.rename_skill_dir",
            "migration.bootstrap_docs_repo",
            "migration.rewrite_claude_md",
            "migration.backfill_canonical_from_remote",
            "migration.finalize",
        ]

    def test_skip_backfill(self):
        chain = build_migration_chain(include_backfill=False)
        names = [ic.name for ic in chain]
        assert "migration.backfill_canonical_from_remote" not in names
        # Ordering preserved otherwise.
        assert names[0] == "migration.backup_claude_dir"
        assert names[-1] == "migration.finalize"


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
