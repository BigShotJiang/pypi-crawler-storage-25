"""Unit tests for LocalStoreAdapter (3.0 / Phase 2 sub-run C).

Tests filesystem-backed adapter against a tmp_path-rooted docs repo.
Covers all PlatformAdapter Protocol methods.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest

from forge_manager_mcp.adapters.errors import ForgeError, InvalidArtifactRefError
from forge_manager_mcp.adapters.local_store import (
    DEFAULT_DOCS_REPO_ENV,
    LocalStoreAdapter,
)
from forge_manager_mcp.adapters.types import (
    ArtifactRef,
    Comment,
    Discussion,
    Issue,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def docs_repo(tmp_path: Path) -> Path:
    """Empty git-init'd docs repo at tmp_path."""
    subprocess.run(
        ["git", "init", "-q", "-b", "main"], cwd=tmp_path, check=True,
    )
    subprocess.run(
        ["git", "config", "user.email", "test@example.com"],
        cwd=tmp_path, check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"], cwd=tmp_path, check=True,
    )
    # Initial empty commit so subsequent commits have a base.
    subprocess.run(
        ["git", "commit", "-q", "--allow-empty", "-m", "initial"],
        cwd=tmp_path, check=True,
    )
    return tmp_path


@pytest.fixture
def adapter(docs_repo: Path) -> LocalStoreAdapter:
    return LocalStoreAdapter(docs_repo_path=docs_repo)


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------

class TestConstruction:
    def test_platform_id_classvar(self):
        assert LocalStoreAdapter.platform_id == "local"

    def test_from_config_with_explicit_path(self, docs_repo: Path):
        a = LocalStoreAdapter.from_config({"id": "local", "path": str(docs_repo)})
        assert a.path == docs_repo

    def test_from_config_with_env_var(self, docs_repo: Path, monkeypatch):
        monkeypatch.setenv(DEFAULT_DOCS_REPO_ENV, str(docs_repo))
        a = LocalStoreAdapter.from_config({"id": "local"})
        assert a.path == docs_repo

    def test_from_config_missing_repo_raises(self, tmp_path: Path):
        bogus = tmp_path / "not_a_repo"
        with pytest.raises(ForgeError, match="not found"):
            LocalStoreAdapter.from_config({"id": "local", "path": str(bogus)})


# ---------------------------------------------------------------------------
# Issue operations
# ---------------------------------------------------------------------------

class TestCreateIssue:
    @pytest.mark.asyncio
    async def test_creates_issue_files(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r",
            title="test issue", body="body content",
            labels=["kind:bug", "area:mcp"],
        )
        assert issue.ref.number == 1
        assert issue.ref.platform_id == "local"
        assert issue.title == "test issue"
        assert issue.body == "body content"
        assert issue.state == "open"
        assert "kind:bug" in issue.labels

        issue_dir = docs_repo / "issues" / "1"
        assert (issue_dir / "title.md").read_text() == "test issue\n"
        assert (issue_dir / "body.md").read_text() == "body content"
        assert (issue_dir / "state.txt").read_text() == "open\n"
        assert "kind:bug" in (issue_dir / "labels.txt").read_text()

    @pytest.mark.asyncio
    async def test_consecutive_numbering(self, adapter):
        i1 = await adapter.create_issue(
            owner="o", repo="r", title="t1", body="", labels=["kind:bug"],
        )
        i2 = await adapter.create_issue(
            owner="o", repo="r", title="t2", body="", labels=["kind:bug"],
        )
        i3 = await adapter.create_issue(
            owner="o", repo="r", title="t3", body="", labels=["kind:bug"],
        )
        assert i1.ref.number == 1
        assert i2.ref.number == 2
        assert i3.ref.number == 3

    @pytest.mark.asyncio
    async def test_milestone_persisted(self, adapter, docs_repo):
        await adapter.create_issue(
            owner="o", repo="r", title="t", body="",
            labels=["kind:bug"], milestone="3.0.0",
        )
        meta = json.loads((docs_repo / "issues" / "1" / "meta.json").read_text())
        assert meta["milestone"] == "3.0.0"

    @pytest.mark.asyncio
    async def test_auto_commits(self, adapter, docs_repo):
        await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        log = subprocess.run(
            ["git", "log", "--oneline"],
            cwd=docs_repo, capture_output=True, text=True, check=True,
        )
        assert "create_issue #1" in log.stdout


class TestGetAndUpdateIssue:
    @pytest.mark.asyncio
    async def test_get_issue_round_trip(self, adapter):
        created = await adapter.create_issue(
            owner="o", repo="r", title="round-trip", body="body",
            labels=["kind:bug"],
        )
        fetched = await adapter.get_issue("o", "r", created.ref.number)
        assert fetched.title == "round-trip"
        assert fetched.body == "body"

    @pytest.mark.asyncio
    async def test_get_missing_issue_raises(self, adapter):
        with pytest.raises(InvalidArtifactRefError):
            await adapter.get_issue("o", "r", 999)

    @pytest.mark.asyncio
    async def test_update_issue_body(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="old", labels=["kind:bug"],
        )
        await adapter.update_issue_body(issue.ref, "new body")
        assert (docs_repo / "issues" / "1" / "body.md").read_text() == "new body"

    @pytest.mark.asyncio
    async def test_get_issue_body_round_trip(self, adapter):
        """#274 Phase C1 — get_issue_body(ref) reads back what
        update_issue_body wrote, so an update→read cycle is the
        identity within a session."""
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="hello",
            labels=["kind:bug"],
        )
        assert await adapter.get_issue_body(issue.ref) == "hello"
        await adapter.update_issue_body(issue.ref, "rewritten")
        assert await adapter.get_issue_body(issue.ref) == "rewritten"

    @pytest.mark.asyncio
    async def test_get_issue_body_missing_dir_raises(self, adapter):
        from forge_manager_mcp.adapters.types import ArtifactRef
        bogus = ArtifactRef(
            platform_id="local", native_id="issues/9999",
            kind="issue", owner="o", repo="r", number=9999,
        )
        with pytest.raises(InvalidArtifactRefError):
            await adapter.get_issue_body(bogus)

    @pytest.mark.asyncio
    async def test_close_issue_returns_canonical_issue(self, adapter):
        """#274 Phase C2 — close_issue returns the closed Issue."""
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        closed = await adapter.close_issue(issue.ref)
        assert closed.state == "closed"
        assert closed.ref.number == issue.ref.number
        assert closed.title == issue.title  # title unchanged

    @pytest.mark.asyncio
    async def test_search_issues_returns_search_result(self, adapter):
        """#274 Phase C4 — search_issues returns SearchResult with
        total_count counting the full match set even when results is
        capped by limit."""
        # Create three matching Issues, then search with limit=2.
        for n in range(3):
            await adapter.create_issue(
                owner="o", repo="r", title=f"hit {n}",
                body="searchable", labels=["kind:bug"],
            )
        result = await adapter.search_issues(
            owner="o", repo="r", query="searchable", limit=2,
        )
        assert len(result.results) == 2
        # total_count reflects the full set, not just `len(results)`.
        assert result.total_count == 3
        assert result.query == "searchable"

    @pytest.mark.asyncio
    async def test_list_comments_limit(self, adapter):
        """#274 Phase C3 — limit kwarg keeps the most-recent N
        comments after the chronological order."""
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        # Three comments; with limit=2, expect the 2 most recent.
        await adapter.append_comment(issue.ref, "first")
        await adapter.append_comment(issue.ref, "second")
        await adapter.append_comment(issue.ref, "third")
        all_three = await adapter.list_comments(issue.ref)
        assert len(all_three) == 3
        last_two = await adapter.list_comments(issue.ref, limit=2)
        assert len(last_two) == 2
        assert last_two[-1].body == "third"

    @pytest.mark.asyncio
    async def test_close_issue(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        await adapter.close_issue(issue.ref)
        state_text = (docs_repo / "issues" / "1" / "state.txt").read_text()
        assert "closed" in state_text
        assert "open" not in state_text


class TestLabelOps:
    @pytest.mark.asyncio
    async def test_add_label(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="", labels=["kind:bug"],
        )
        await adapter.add_label(issue.ref, "priority:high")
        labels_text = (docs_repo / "issues" / "1" / "labels.txt").read_text()
        assert "priority:high" in labels_text
        assert "kind:bug" in labels_text  # original preserved

    @pytest.mark.asyncio
    async def test_remove_label(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="",
            labels=["kind:bug", "area:mcp"],
        )
        await adapter.remove_label(issue.ref, "area:mcp")
        labels_text = (docs_repo / "issues" / "1" / "labels.txt").read_text()
        assert "area:mcp" not in labels_text
        assert "kind:bug" in labels_text

    @pytest.mark.asyncio
    async def test_ensure_label_returns_synthetic_id(self, adapter):
        result = await adapter.ensure_label(
            owner="o", repo="r", name="kind:bug",
        )
        assert result.startswith("local-label://")


class TestSearchAndList:
    @pytest.mark.asyncio
    async def test_list_open_issues(self, adapter):
        for i in range(3):
            await adapter.create_issue(
                owner="o", repo="r", title=f"issue {i}", body="",
                labels=["kind:bug"],
            )
        # Close one so it's no longer open.
        i2 = await adapter.get_issue("o", "r", 2)
        await adapter.close_issue(i2.ref)

        open_issues = await adapter.list_open_issues(owner="o", repo="r")
        nums = sorted(i.ref.number for i in open_issues)
        assert nums == [1, 3]

    @pytest.mark.asyncio
    async def test_search_by_label(self, adapter):
        await adapter.create_issue(
            owner="o", repo="r", title="bug-1", body="", labels=["kind:bug"],
        )
        await adapter.create_issue(
            owner="o", repo="r", title="feat-1", body="", labels=["kind:feature"],
        )
        result = await adapter.search_issues(
            owner="o", repo="r", labels=["kind:bug"],
        )
        # #274 Phase C4 — search_issues returns SearchResult.
        assert len(result.results) == 1
        assert result.results[0].title == "bug-1"
        assert result.total_count == 1

    @pytest.mark.asyncio
    async def test_search_by_query(self, adapter):
        await adapter.create_issue(
            owner="o", repo="r", title="alpha", body="x", labels=["kind:bug"],
        )
        await adapter.create_issue(
            owner="o", repo="r", title="beta", body="x", labels=["kind:bug"],
        )
        result = await adapter.search_issues(
            owner="o", repo="r", query="alpha",
        )
        assert len(result.results) == 1
        assert result.results[0].title == "alpha"
        assert result.query == "alpha"


# ---------------------------------------------------------------------------
# Discussion operations
# ---------------------------------------------------------------------------

class TestDiscussions:
    @pytest.mark.asyncio
    async def test_create_discussion_with_category(self, adapter, docs_repo):
        d = await adapter.create_discussion(
            owner="o", repo="r",
            title="design discussion",
            body="markdown",
            category="Architecture",
        )
        assert d.category == "Architecture"
        labels_text = (docs_repo / "discussions" / "1" / "labels.txt").read_text()
        assert "kind:discussion" in labels_text
        assert "category:architecture" in labels_text

    @pytest.mark.asyncio
    async def test_get_discussion_round_trip(self, adapter):
        created = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b", category="Ideas",
        )
        fetched = await adapter.get_discussion("o", "r", created.ref.number)
        assert fetched.title == "t"
        assert fetched.category == "Ideas"

    @pytest.mark.asyncio
    async def test_mark_decided(self, adapter, docs_repo):
        d = await adapter.create_discussion(
            owner="o", repo="r", title="t", body="b", category="Architecture",
        )
        await adapter.mark_decided(d.ref)
        state_text = (docs_repo / "discussions" / "1" / "state.txt").read_text()
        assert "decided" in state_text
        assert "open" in state_text  # multi-dim — both axes present

        # Re-read; decided flag should be set.
        fetched = await adapter.get_discussion("o", "r", 1)
        assert fetched.decided is True


# ---------------------------------------------------------------------------
# Comment operations
# ---------------------------------------------------------------------------

class TestComments:
    @pytest.mark.asyncio
    async def test_append_comment_to_issue(self, adapter, docs_repo):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        comment = await adapter.append_comment(issue.ref, "Hello!")
        assert comment.body == "Hello!"
        comments_dir = docs_repo / "issues" / "1" / "comments"
        assert comments_dir.exists()
        files = list(comments_dir.iterdir())
        assert len(files) == 1
        assert files[0].read_text() == "Hello!"

    @pytest.mark.asyncio
    async def test_append_to_unknown_target_goes_to_orphan(self, adapter, docs_repo):
        # Synthetic ref to nonexistent target.
        ghost_ref = ArtifactRef(
            platform_id="github",
            native_id="I_kwDObogus",
            kind="issue", owner="o", repo="r", number=999,
        )
        comment = await adapter.append_comment(ghost_ref, "orphan!")
        orphan_dir = docs_repo / "_orphan-comments"
        assert orphan_dir.exists()
        files = list(orphan_dir.iterdir())
        assert len(files) == 1
        assert files[0].read_text() == "orphan!"

    @pytest.mark.asyncio
    async def test_list_comments_chronological(self, adapter):
        issue = await adapter.create_issue(
            owner="o", repo="r", title="t", body="b", labels=["kind:bug"],
        )
        # Two appends at different times.
        await adapter.append_comment(issue.ref, "first")
        await adapter.append_comment(issue.ref, "second")

        comments = await adapter.list_comments(issue.ref)
        assert len(comments) == 2
        bodies = [c.body for c in comments]
        assert bodies == ["first", "second"]


# ---------------------------------------------------------------------------
# Misc / health
# ---------------------------------------------------------------------------

class TestMiscOps:
    @pytest.mark.asyncio
    async def test_probe_returns_true(self, adapter):
        assert await adapter.probe() is True

    @pytest.mark.asyncio
    async def test_probe_after_dir_removed_returns_false(self, tmp_path: Path):
        a = LocalStoreAdapter(docs_repo_path=tmp_path / "ghost")
        assert await a.probe() is False

    @pytest.mark.asyncio
    async def test_compute_drift_clean(self, adapter):
        report = await adapter.compute_drift({})
        assert report.is_clean is True
        assert report.platform_id == "local"

    @pytest.mark.asyncio
    async def test_get_repo_node_id_synthetic(self, adapter):
        node_id = await adapter.get_repo_node_id("o", "r")
        assert node_id == "local://o/r"

    @pytest.mark.asyncio
    async def test_get_repo_visibility_public_when_path_exists(self, adapter):
        # PAR-3: LocalStore reports PUBLIC by convention since
        # filesystem permissions, not a visibility flag, gate access.
        assert await adapter.get_repo_visibility("o", "r") == "PUBLIC"

    @pytest.mark.asyncio
    async def test_get_repo_visibility_none_when_path_missing(self, tmp_path: Path):
        a = LocalStoreAdapter(docs_repo_path=tmp_path / "ghost")
        assert await a.get_repo_visibility("o", "r") is None

    @pytest.mark.asyncio
    async def test_create_release_writes_file(self, adapter, docs_repo):
        rel = await adapter.create_release(
            owner="o", repo="r", tag="v3.0.0", name="3.0.0",
            body="release notes", prerelease=False,
        )
        assert rel.tag == "v3.0.0"
        rel_file = docs_repo / "releases" / "v3.0.0.md"
        assert rel_file.exists()
        assert "release notes" in rel_file.read_text()

    @pytest.mark.asyncio
    async def test_create_release_persists_prerelease_and_created_at(
        self, adapter, docs_repo,
    ):
        """PAR-2: prerelease + created_at land in YAML frontmatter so a
        future round-trip read can recover them. Pre-fix the file body
        was ``# {name}\\n{body}`` only — both fields were lost on disk."""
        rel = await adapter.create_release(
            owner="o", repo="r", tag="v3.0.1a1",
            name="3.0.1 alpha 1", body="alpha notes",
            prerelease=True,
        )
        rel_file = docs_repo / "releases" / "v3.0.1a1.md"
        text = rel_file.read_text(encoding="utf-8")
        # Frontmatter at the top of the file.
        assert text.startswith("---\n")
        # Both lossy-pre-fix fields are now persisted.
        assert "prerelease: true" in text
        assert "tag: v3.0.1a1" in text
        # created_at frontmatter matches the returned Release.
        assert f"created_at: {rel.created_at.isoformat()}" in text
        # Existing body behaviour preserved (H1 heading + body content).
        assert "# 3.0.1 alpha 1" in text
        assert "alpha notes" in text

    @pytest.mark.asyncio
    async def test_create_release_prerelease_false_round_trips(
        self, adapter, docs_repo,
    ):
        """The non-prerelease default also persists explicitly so
        ``prerelease: false`` is grep-able rather than absent."""
        await adapter.create_release(
            owner="o", repo="r", tag="v3.0.0", name="3.0.0",
            body="ga notes", prerelease=False,
        )
        rel_file = docs_repo / "releases" / "v3.0.0.md"
        assert "prerelease: false" in rel_file.read_text()

    @pytest.mark.asyncio
    async def test_fetch_file_content_returns_content_when_present(
        self, adapter, docs_repo,
    ):
        (docs_repo / "README.md").write_text("hello world")
        content = await adapter.fetch_file_content(
            owner="o", repo="r", path="README.md",
        )
        assert content == "hello world"

    @pytest.mark.asyncio
    async def test_fetch_file_content_returns_none_when_missing(self, adapter):
        content = await adapter.fetch_file_content(
            owner="o", repo="r", path="does-not-exist.md",
        )
        assert content is None


class TestSessionEvents:
    """Canonical-side session-lock surface — groundwork for the
    open_session handler fix the GitHub-down bug calls for."""

    def test_has_session_event_surface_classvar_true(self):
        assert LocalStoreAdapter.has_session_event_surface is True

    @pytest.mark.asyncio
    async def test_record_session_event_writes_json(
        self, adapter, docs_repo: Path,
    ):
        evt = await adapter.record_session_event(
            session_id="sess-abc", event="opened", body="boot",
        )
        assert evt.session_id == "sess-abc"
        assert evt.event == "opened"
        assert evt.body == "boot"
        sessions_dir = docs_repo / "sessions" / "sess-abc"
        assert sessions_dir.is_dir()
        files = list(sessions_dir.iterdir())
        assert len(files) == 1
        payload = json.loads(files[0].read_text(encoding="utf-8"))
        assert payload["session_id"] == "sess-abc"
        assert payload["event"] == "opened"
        assert payload["body"] == "boot"

    @pytest.mark.asyncio
    async def test_record_session_event_rejects_empty_session_id(self, adapter):
        with pytest.raises(ForgeError, match="session_id"):
            await adapter.record_session_event(
                session_id="  ", event="opened",
            )

    @pytest.mark.asyncio
    async def test_record_session_event_rejects_empty_event(self, adapter):
        with pytest.raises(ForgeError, match="event"):
            await adapter.record_session_event(
                session_id="sess", event="",
            )

    @pytest.mark.asyncio
    async def test_read_session_events_empty_when_no_history(self, adapter):
        events = await adapter.read_session_events()
        assert events == []

    @pytest.mark.asyncio
    async def test_read_session_events_orders_oldest_first(self, adapter):
        # Two events on one session, then a third on a different session.
        await adapter.record_session_event(session_id="s1", event="opened")
        await adapter.record_session_event(session_id="s1", event="closed")
        await adapter.record_session_event(session_id="s2", event="opened")
        events = await adapter.read_session_events()
        assert len(events) == 3
        # Oldest-first.
        timestamps = [e.timestamp for e in events]
        assert timestamps == sorted(timestamps)
        # All three sessions visible.
        kinds = [(e.session_id, e.event) for e in events]
        assert ("s1", "opened") in kinds
        assert ("s1", "closed") in kinds
        assert ("s2", "opened") in kinds

    @pytest.mark.asyncio
    async def test_read_session_events_last_n_clamps(self, adapter):
        for i in range(5):
            await adapter.record_session_event(
                session_id=f"sess-{i}", event="opened",
            )
        events = await adapter.read_session_events(last_n=2)
        assert len(events) == 2
        # The two most-recent.
        assert events[0].session_id == "sess-3"
        assert events[1].session_id == "sess-4"

    @pytest.mark.asyncio
    async def test_read_session_events_skips_malformed_files(
        self, adapter, docs_repo: Path,
    ):
        await adapter.record_session_event(session_id="ok", event="opened")
        # Drop a malformed peer next to the good entry.
        malformed_dir = docs_repo / "sessions" / "broken"
        malformed_dir.mkdir(parents=True, exist_ok=True)
        (malformed_dir / "garbage.json").write_text("not-json", encoding="utf-8")
        # Same dir as the good entry: an entry with valid JSON but no timestamp.
        (docs_repo / "sessions" / "ok" / "no-ts.json").write_text(
            '{"session_id":"ok","event":"opened"}', encoding="utf-8",
        )
        events = await adapter.read_session_events()
        # Only the well-formed entry survives.
        assert len(events) == 1
        assert events[0].session_id == "ok"


class TestBootstrapProject:
    """Multi-platform scaffold C1 — LocalStoreAdapter.bootstrap_project."""

    def test_has_scaffold_classvar_true(self):
        assert LocalStoreAdapter.has_scaffold is True

    @pytest.mark.asyncio
    async def test_bootstrap_creates_dir_git_readme_placeholders(
        self, tmp_path: Path,
    ):
        target = tmp_path / "fresh-docs"
        a = LocalStoreAdapter(docs_repo_path=target)
        result = await a.bootstrap_project(
            owner="acme", project_name="fresh", description="x",
        )
        assert result.platform_id == "local"
        assert result.phase == "complete"
        assert result.manual_steps == []
        assert target.is_dir()
        assert (target / ".git").is_dir()
        assert (target / "README.md").exists()
        assert "fresh-docs" in (target / "README.md").read_text(encoding="utf-8")
        for placeholder in ("issues", "discussions", "milestones"):
            assert (target / placeholder).is_dir()
        # artifacts dict carries per-step action codes for diagnostics.
        assert result.artifacts["docs_repo_path"] == str(target)
        assert result.artifacts["dir"] == "created"
        assert result.artifacts["readme"] == "written"
        assert result.artifacts["git"] == "init"
        assert "issues" in result.artifacts["placeholders"]

    @pytest.mark.asyncio
    async def test_bootstrap_idempotent(self, tmp_path: Path):
        """Re-running bootstrap on an already-bootstrapped repo no-ops
        each step. Action codes flip from ``created`` / ``written`` /
        ``init`` to ``existed``."""
        target = tmp_path / "twice"
        a = LocalStoreAdapter(docs_repo_path=target)
        first = await a.bootstrap_project(
            owner="o", project_name="twice", description="",
        )
        assert first.artifacts["dir"] == "created"
        second = await a.bootstrap_project(
            owner="o", project_name="twice", description="",
        )
        assert second.artifacts["dir"] == "existed"
        assert second.artifacts["readme"] == "existed"
        assert second.artifacts["git"] == "existed"

    @pytest.mark.asyncio
    async def test_bootstrap_existing_state_accepted(self, tmp_path: Path):
        """``existing_state`` is for Protocol parity; LocalStore ignores
        it. Passing a populated dict still completes successfully."""
        target = tmp_path / "with-state"
        a = LocalStoreAdapter(docs_repo_path=target)
        result = await a.bootstrap_project(
            owner="o", project_name="with-state", description="",
            existing_state={"github": {"repo_node_id": "R_xxx"}},
        )
        assert result.phase == "complete"


class TestMilestones:
    """find_milestone parity (PAR-1): integer lookups raise rather than
    silently return None — LocalStore has no native integer-ID concept."""

    @pytest.mark.asyncio
    async def test_find_by_title_returns_milestone(self, adapter, docs_repo):
        ms_dir = docs_repo / "milestones"
        ms_dir.mkdir(parents=True, exist_ok=True)
        (ms_dir / "3.0.1.md").write_text("# 3.0.1\nMilestone notes.\n")

        result = await adapter.find_milestone("o", "r", "3.0.1")
        assert result is not None
        assert result.title == "3.0.1"

    @pytest.mark.asyncio
    async def test_find_by_title_returns_none_when_absent(self, adapter):
        result = await adapter.find_milestone("o", "r", "no-such-milestone")
        assert result is None

    @pytest.mark.asyncio
    async def test_find_by_int_raises(self, adapter):
        """PAR-1: integer-ID lookups must raise rather than silently
        return None. The error message names the limitation and
        suggests the workaround."""
        from forge_manager_mcp.adapters import errors as _errors

        with pytest.raises(_errors.ForgeError) as exc_info:
            await adapter.find_milestone("o", "r", 42)
        # Message names the limitation explicitly.
        assert "find_milestone(int)" in str(exc_info.value)
        assert "title" in str(exc_info.value)


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
