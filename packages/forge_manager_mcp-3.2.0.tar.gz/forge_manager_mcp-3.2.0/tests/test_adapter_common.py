"""Unit tests for the shared adapter helpers in adapters/_common.py."""
from __future__ import annotations

from datetime import datetime, timezone

import pytest

from forge_manager_mcp.adapters._common import (
    find_milestone_by_title_in_list,
    label_names_from_api,
    milestone_title_from_api,
    parse_iso,
)
from forge_manager_mcp.adapters.types import Milestone


class TestParseIso:
    def test_parses_z_suffix(self):
        result = parse_iso("2026-05-01T12:34:56Z")
        assert result == datetime(2026, 5, 1, 12, 34, 56, tzinfo=timezone.utc)

    def test_parses_offset(self):
        result = parse_iso("2026-05-01T12:34:56+00:00")
        assert result == datetime(2026, 5, 1, 12, 34, 56, tzinfo=timezone.utc)

    def test_returns_none_on_falsy(self):
        assert parse_iso(None) is None
        assert parse_iso("") is None

    def test_returns_none_on_garbage(self):
        assert parse_iso("not-a-date") is None
        assert parse_iso(12345) is None  # type: ignore[arg-type]


class TestLabelNamesFromApi:
    def test_strings(self):
        d = {"labels": ["bug", "area:mcp"]}
        assert label_names_from_api(d) == ["bug", "area:mcp"]

    def test_objects(self):
        d = {"labels": [{"name": "bug", "color": "f00"}, {"name": "feature"}]}
        assert label_names_from_api(d) == ["bug", "feature"]

    def test_mixed(self):
        d = {"labels": ["bug", {"name": "feature"}]}
        assert label_names_from_api(d) == ["bug", "feature"]

    def test_object_missing_name_yields_empty_string(self):
        d = {"labels": [{"color": "f00"}]}
        assert label_names_from_api(d) == [""]

    def test_missing_labels_key(self):
        assert label_names_from_api({}) == []

    def test_null_labels(self):
        assert label_names_from_api({"labels": None}) == []

    def test_empty_list(self):
        assert label_names_from_api({"labels": []}) == []

    def test_drops_falsy_entries(self):
        d = {"labels": ["bug", None, "", "feature"]}
        assert label_names_from_api(d) == ["bug", "feature"]


class TestMilestoneTitleFromApi:
    def test_dict_form(self):
        d = {"milestone": {"title": "v3.0.0", "id": 42}}
        assert milestone_title_from_api(d) == "v3.0.0"

    def test_string_form(self):
        d = {"milestone": "v3.0.0"}
        assert milestone_title_from_api(d) == "v3.0.0"

    def test_null_milestone(self):
        assert milestone_title_from_api({"milestone": None}) is None

    def test_missing_milestone_key(self):
        assert milestone_title_from_api({}) is None

    def test_dict_without_title(self):
        # Edge case: milestone dict missing title field.
        assert milestone_title_from_api({"milestone": {"id": 42}}) is None

    def test_dict_with_non_string_title(self):
        # Defense against malformed payloads.
        assert milestone_title_from_api({"milestone": {"title": 42}}) is None


class TestFindMilestoneByTitleInList:
    """Shared title-based milestone lookup helper (DRY-E)."""

    @pytest.mark.asyncio
    async def test_returns_match(self):
        ms = [
            Milestone(title="v3.0.0", number=1, state="open"),
            Milestone(title="v3.1.0", number=2, state="open"),
        ]

        async def list_fn(owner, repo, state):
            return ms

        result = await find_milestone_by_title_in_list(
            list_fn, "o", "r", "v3.1.0",
        )
        assert result is not None
        assert result.title == "v3.1.0"
        assert result.number == 2

    @pytest.mark.asyncio
    async def test_returns_none_when_no_match(self):
        async def list_fn(owner, repo, state):
            return [Milestone(title="v1.0.0", number=1, state="open")]

        result = await find_milestone_by_title_in_list(
            list_fn, "o", "r", "v9.9.9",
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_passes_state_all_to_list_fn(self):
        seen_states = []

        async def list_fn(owner, repo, state):
            seen_states.append(state)
            return []

        await find_milestone_by_title_in_list(list_fn, "o", "r", "x")
        # Helper passes state="all" so closed milestones are findable.
        assert seen_states == ["all"]


if __name__ == "__main__":
    import sys
    sys.exit(pytest.main([__file__, "-v"]))
