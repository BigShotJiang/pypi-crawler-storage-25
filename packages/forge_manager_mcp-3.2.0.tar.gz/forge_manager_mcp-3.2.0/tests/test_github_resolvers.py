"""Unit tests for github.py — ID resolvers and validators.

Covers get_label_id, resolve_thread_id, validate_node_id, and the
InvalidNodeIdError exception.
"""
from __future__ import annotations

import json
import httpx
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from forge_manager_mcp.github.core import GitHubError, InvalidNodeIdError
from forge_manager_mcp.github.issues import get_label_id
from forge_manager_mcp.github.resolvers import (
    find_milestone_node_id,
    get_file_content,
    get_repo_visibility,
    resolve_thread_id,
    validate_node_id,
)
from forge_manager_mcp.github.scaffold import (
    create_label,
    create_repository,
    get_organization_id,
)


TOKEN = "ghp_test_token"


def _mock_response(data: dict, status_code: int = 200):
    mock = MagicMock()
    mock.status_code = status_code
    mock.json.return_value = data
    mock.text = json.dumps(data)
    return mock


class TestGetLabelId:
    @pytest.mark.asyncio
    async def test_success(self):
        response_data = {
            "data": {"repository": {"label": {"id": "LA_bug123"}}}
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            label_id = await get_label_id(TOKEN, "owner", "repo", "bug")
        assert label_id == "LA_bug123"

    @pytest.mark.asyncio

    async def test_label_not_found_raises(self):
        response_data = {"data": {"repository": {"label": None}}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(GitHubError, match="not found"):
                await get_label_id(TOKEN, "owner", "repo", "nonexistent")

    @pytest.mark.asyncio

    async def test_empty_label_name_raises(self):
        with pytest.raises(ValueError, match="label_name"):
            await get_label_id(TOKEN, "owner", "repo", "")


class TestValidateNodeId:
    @pytest.mark.asyncio
    async def test_success_returns_none(self):
        response_data = {"data": {"node": {"id": "I_kwDO_abc"}}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            assert await validate_node_id(TOKEN, "issue_id", "I_kwDO_abc") is None

    @pytest.mark.asyncio

    async def test_null_node_raises_invalid(self):
        response_data = {"data": {"node": None}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(InvalidNodeIdError) as exc_info:
                await validate_node_id(TOKEN, "thread_id", "I_kwDO_missing")
        assert exc_info.value.param_name == "thread_id"
        assert exc_info.value.value == "I_kwDO_missing"
        assert "thread_id" in str(exc_info.value)

    @pytest.mark.asyncio

    async def test_could_not_resolve_error_raises_invalid(self):
        response_data = {
            "errors": [{"message": "Could not resolve to a node with the id of 'garbage'"}]
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(InvalidNodeIdError):
                await validate_node_id(TOKEN, "thread_id", "garbage")

    @pytest.mark.asyncio

    async def test_transient_github_error_propagates(self):
        # A generic GitHub error (e.g. 500) should NOT be rewritten as
        # InvalidNodeIdError — it may succeed on retry.
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response({}, status_code=500))):
            with pytest.raises(GitHubError):
                await validate_node_id(TOKEN, "thread_id", "I_kwDO_any")

    @pytest.mark.asyncio

    async def test_empty_id_raises_value_error(self):
        with pytest.raises(ValueError, match="thread_id"):
            await validate_node_id(TOKEN, "thread_id", "")

    @pytest.mark.asyncio

    async def test_whitespace_id_raises_value_error(self):
        with pytest.raises(ValueError, match="issue_id"):
            await validate_node_id(TOKEN, "issue_id", "   ")


class TestResolveThreadId:
    @pytest.mark.asyncio
    async def test_resolves_issue(self):
        response_data = {
            "data": {"repository": {"issue": {"id": "I_kwDO_abc"}}}
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            node_id = await resolve_thread_id(TOKEN, "owner", "repo", 42, "issue")
        assert node_id == "I_kwDO_abc"

    @pytest.mark.asyncio

    async def test_resolves_discussion(self):
        response_data = {
            "data": {"repository": {"discussion": {"id": "D_kwDO_abc"}}}
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            node_id = await resolve_thread_id(TOKEN, "owner", "repo", 7, "discussion")
        assert node_id == "D_kwDO_abc"

    @pytest.mark.asyncio

    async def test_missing_issue_raises(self):
        response_data = {"data": {"repository": {"issue": None}}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(GitHubError, match="not found"):
                await resolve_thread_id(TOKEN, "owner", "repo", 999, "issue")

    @pytest.mark.asyncio

    async def test_missing_discussion_raises(self):
        response_data = {"data": {"repository": {"discussion": None}}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(GitHubError, match="not found"):
                await resolve_thread_id(TOKEN, "owner", "repo", 999, "discussion")

    @pytest.mark.asyncio

    async def test_empty_owner_raises(self):
        with pytest.raises(ValueError, match="owner"):
            await resolve_thread_id(TOKEN, "", "repo", 1, "issue")

    @pytest.mark.asyncio

    async def test_empty_repo_raises(self):
        with pytest.raises(ValueError, match="repo"):
            await resolve_thread_id(TOKEN, "owner", "", 1, "issue")

    @pytest.mark.asyncio

    async def test_invalid_number_raises(self):
        with pytest.raises(ValueError, match="number"):
            await resolve_thread_id(TOKEN, "owner", "repo", 0, "issue")
        with pytest.raises(ValueError, match="number"):
            await resolve_thread_id(TOKEN, "owner", "repo", -5, "issue")

    @pytest.mark.asyncio

    async def test_invalid_kind_raises(self):
        with pytest.raises(ValueError, match="kind"):
            await resolve_thread_id(TOKEN, "owner", "repo", 1, "pull_request")


class TestGetFileContent:
    @pytest.mark.asyncio
    async def test_returns_text(self):
        response_data = {
            "data": {
                "repository": {
                    "object": {"text": "file body contents"}
                }
            }
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            out = await get_file_content(TOKEN, "o", "r", "main", "README.md")
        assert out == "file body contents"

    @pytest.mark.asyncio

    async def test_returns_none_when_object_missing(self):
        """Missing file (non-existent path/ref) → None, not an error."""
        response_data = {"data": {"repository": {"object": None}}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            assert await get_file_content(TOKEN, "o", "r", "main", "nope.md") is None

    @pytest.mark.asyncio

    async def test_empty_owner_raises(self):
        with pytest.raises(ValueError, match="owner"):
            await get_file_content(TOKEN, "", "r", "main", "x.md")

    @pytest.mark.asyncio

    async def test_empty_ref_raises(self):
        with pytest.raises(ValueError, match="ref"):
            await get_file_content(TOKEN, "o", "r", "", "x.md")

    @pytest.mark.asyncio

    async def test_empty_path_raises(self):
        with pytest.raises(ValueError, match="path"):
            await get_file_content(TOKEN, "o", "r", "main", "")


class TestGetRepoVisibility:
    """#116 — get_repo_visibility for the open_session repo-shape audit."""

    @pytest.mark.asyncio

    async def test_returns_visibility_string(self):
        response_data = {
            "data": {"repository": {"visibility": "PRIVATE"}}
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            assert await get_repo_visibility(TOKEN, "o", "r") == "PRIVATE"

    @pytest.mark.asyncio

    async def test_returns_public_for_public_repo(self):
        response_data = {
            "data": {"repository": {"visibility": "PUBLIC"}}
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            assert await get_repo_visibility(TOKEN, "o", "r") == "PUBLIC"

    @pytest.mark.asyncio

    async def test_returns_none_when_repo_missing(self):
        """Repo not found → None (not an error). Distinguishes ABSENT from
        transient API failures."""
        response_data = {"data": {"repository": None}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            assert await get_repo_visibility(TOKEN, "o", "ghost-repo") is None

    @pytest.mark.asyncio

    async def test_empty_owner_raises(self):
        with pytest.raises(ValueError, match="owner"):
            await get_repo_visibility(TOKEN, "", "r")

    @pytest.mark.asyncio

    async def test_empty_repo_raises(self):
        with pytest.raises(ValueError, match="repo"):
            await get_repo_visibility(TOKEN, "o", "")


class TestGetOrganizationId:
    @pytest.mark.asyncio
    async def test_returns_id_when_org_exists(self):
        response_data = {"data": {"organization": {"id": "O_kwDO_org"}}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            assert await get_organization_id(TOKEN, "myorg") == "O_kwDO_org"

    @pytest.mark.asyncio

    async def test_returns_none_when_org_missing(self):
        response_data = {"data": {"organization": None}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            assert await get_organization_id(TOKEN, "ghost-org") is None

    @pytest.mark.asyncio

    async def test_empty_login_raises(self):
        with pytest.raises(ValueError, match="login"):
            await get_organization_id(TOKEN, "")


class TestCreateRepository:
    @pytest.mark.asyncio
    async def test_returns_fields(self):
        response_data = {
            "data": {
                "createRepository": {
                    "repository": {
                        "id": "R_kwDO_new",
                        "url": "https://github.com/org/name",
                        "nameWithOwner": "org/name",
                    }
                }
            }
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            out = await create_repository(TOKEN, "O_kwDO_org", "name", "PUBLIC", "desc")
        assert out["id"] == "R_kwDO_new"
        assert out["name_with_owner"] == "org/name"

    @pytest.mark.asyncio

    async def test_invalid_visibility_raises(self):
        with pytest.raises(ValueError, match="visibility"):
            await create_repository(TOKEN, "O_abc", "name", "SECRET")

    @pytest.mark.asyncio

    async def test_empty_name_raises(self):
        with pytest.raises(ValueError, match="name"):
            await create_repository(TOKEN, "O_abc", "", "PUBLIC")

    @pytest.mark.asyncio

    async def test_empty_owner_id_raises(self):
        with pytest.raises(ValueError, match="owner_id"):
            await create_repository(TOKEN, "", "name", "PUBLIC")


class TestCreateLabel:
    @pytest.mark.asyncio
    async def test_returns_label_id(self):
        response_data = {
            "data": {"createLabel": {"label": {"id": "LA_new"}}}
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            assert await create_label(TOKEN, "R_repo", "bug", "d73a4a", "Issue") == "LA_new"

    @pytest.mark.asyncio

    async def test_empty_name_raises(self):
        with pytest.raises(ValueError, match="name"):
            await create_label(TOKEN, "R_repo", "")

    @pytest.mark.asyncio

    async def test_github_error_propagates(self):
        """Already-exists errors surface as GitHubError — caller is
        responsible for idempotent catching."""
        response_data = {
            "errors": [{"message": "Name has already been taken"}]
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(GitHubError):
                await create_label(TOKEN, "R_repo", "bug")


class TestFindMilestoneNodeId:
    """#232 — milestone resolver for create_issue / create_thread."""

    @pytest.mark.asyncio
    async def test_int_form_resolves_to_id(self):
        response_data = {
            "data": {"repository": {"milestone": {"id": "MI_milestone10"}}}
        }
        captured = {}

        def _capture(url, *, headers=None, json=None, **_):
            captured["query"] = json["query"]
            captured["variables"] = json.get("variables", {})
            return _mock_response(response_data)

        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(side_effect=_capture)):
            node_id = await find_milestone_node_id(TOKEN, "owner", "repo", 10)

        assert node_id == "MI_milestone10"
        assert captured["variables"]["number"] == 10
        assert "milestone(number:" in captured["query"]

    @pytest.mark.asyncio
    async def test_str_form_resolves_to_id(self):
        response_data = {
            "data": {
                "repository": {
                    "milestones": {
                        "nodes": [
                            {"id": "MI_a", "title": "1.2.0"},
                            {"id": "MI_b", "title": "2.3.0"},
                            {"id": "MI_c", "title": "1.5.0"},
                        ]
                    }
                }
            }
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            node_id = await find_milestone_node_id(TOKEN, "owner", "repo", "2.3.0")

        assert node_id == "MI_b"

    @pytest.mark.asyncio
    async def test_str_form_searches_open_and_closed(self):
        """Closed milestones must still resolve — see #193 mid-cycle move
        from open 2.3.0 to closed 2.2.0 for the precedent."""
        captured = {}

        def _capture(url, *, headers=None, json=None, **_):
            captured["query"] = json["query"]
            return _mock_response({
                "data": {
                    "repository": {
                        "milestones": {
                            "nodes": [{"id": "MI_closed", "title": "1.5.0"}]
                        }
                    }
                }
            })

        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(side_effect=_capture)):
            node_id = await find_milestone_node_id(TOKEN, "owner", "repo", "1.5.0")

        assert node_id == "MI_closed"
        # Both states must be in the query so closed milestones resolve.
        assert "states: [OPEN, CLOSED]" in captured["query"]

    @pytest.mark.asyncio
    async def test_int_form_not_found_raises_with_number(self):
        response_data = {"data": {"repository": {"milestone": None}}}
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(GitHubError, match=r"#999.*not found"):
                await find_milestone_node_id(TOKEN, "owner", "repo", 999)

    @pytest.mark.asyncio
    async def test_str_form_not_found_lists_available_titles(self):
        response_data = {
            "data": {
                "repository": {
                    "milestones": {
                        "nodes": [
                            {"id": "MI_a", "title": "1.2.0"},
                            {"id": "MI_b", "title": "2.3.0"},
                        ]
                    }
                }
            }
        }
        with patch.object(httpx.AsyncClient, "post", new=AsyncMock(return_value=_mock_response(response_data))):
            with pytest.raises(GitHubError) as exc_info:
                await find_milestone_node_id(TOKEN, "owner", "repo", "9.9.9")

        msg = str(exc_info.value)
        assert "'9.9.9'" in msg
        assert "1.2.0" in msg
        assert "2.3.0" in msg

    @pytest.mark.asyncio
    async def test_zero_int_raises_value_error(self):
        with pytest.raises(ValueError, match="positive integer"):
            await find_milestone_node_id(TOKEN, "owner", "repo", 0)

    @pytest.mark.asyncio
    async def test_negative_int_raises_value_error(self):
        with pytest.raises(ValueError, match="positive integer"):
            await find_milestone_node_id(TOKEN, "owner", "repo", -1)

    @pytest.mark.asyncio
    async def test_empty_string_raises_value_error(self):
        with pytest.raises(ValueError, match="non-empty"):
            await find_milestone_node_id(TOKEN, "owner", "repo", "")

    @pytest.mark.asyncio
    async def test_whitespace_string_raises_value_error(self):
        with pytest.raises(ValueError, match="non-empty"):
            await find_milestone_node_id(TOKEN, "owner", "repo", "   ")

    @pytest.mark.asyncio
    async def test_empty_owner_raises_value_error(self):
        with pytest.raises(ValueError, match="owner and repo"):
            await find_milestone_node_id(TOKEN, "", "repo", "1.0.0")

    @pytest.mark.asyncio
    async def test_bool_rejected(self):
        """bool is a subclass of int in Python; reject explicitly so a
        caller passing `True` accidentally doesn't get treated as
        milestone number 1."""
        with pytest.raises(ValueError, match="non-empty string or positive int"):
            await find_milestone_node_id(TOKEN, "owner", "repo", True)


if __name__ == "__main__":
    import sys
    import pytest
    sys.exit(pytest.main([__file__, "-v"]))
