######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.23                                                                                #
# Generated on 2026-04-28T04:06:45.688257                                                            #
######################################################################################################

from __future__ import annotations



class GcpDefaultClientProvider(object, metaclass=type):
    @staticmethod
    def get_gs_storage_client(*args, **kwargs):
        ...
    @staticmethod
    def get_credentials(scopes, *args, **kwargs):
        ...
    ...

cached_provider_class: None

def get_gs_storage_client():
    ...

def get_credentials(scopes, *args, **kwargs):
    ...

