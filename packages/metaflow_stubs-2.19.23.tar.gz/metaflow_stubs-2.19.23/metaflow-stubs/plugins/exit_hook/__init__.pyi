######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.23                                                                                #
# Generated on 2026-04-28T04:06:45.657880                                                            #
######################################################################################################

from __future__ import annotations


from . import exit_hook_decorator as exit_hook_decorator

