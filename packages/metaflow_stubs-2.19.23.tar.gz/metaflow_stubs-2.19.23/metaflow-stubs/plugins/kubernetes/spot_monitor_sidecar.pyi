######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.23                                                                                #
# Generated on 2026-04-28T04:06:45.678452                                                            #
######################################################################################################

from __future__ import annotations



class SpotTerminationMonitorSidecar(object, metaclass=type):
    def __init__(self):
        ...
    def process_message(self, msg):
        ...
    @classmethod
    def get_worker(cls):
        ...
    ...

