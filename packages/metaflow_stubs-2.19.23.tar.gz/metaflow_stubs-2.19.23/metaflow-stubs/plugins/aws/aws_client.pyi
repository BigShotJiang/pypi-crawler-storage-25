######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.23                                                                                #
# Generated on 2026-04-28T04:06:45.679537                                                            #
######################################################################################################

from __future__ import annotations



cached_aws_sandbox_creds: None

cached_provider_class: None

class Boto3ClientProvider(object, metaclass=type):
    @staticmethod
    def get_client(module, with_error = False, role_arn = None, session_vars = None, client_params = None):
        ...
    ...

def get_aws_client(module, with_error = False, role_arn = None, session_vars = None, client_params = None):
    ...

