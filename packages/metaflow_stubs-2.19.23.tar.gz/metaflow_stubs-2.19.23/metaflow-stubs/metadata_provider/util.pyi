######################################################################################################
#                                 Auto-generated Metaflow stub file                                  #
# MF version: 2.19.23                                                                                #
# Generated on 2026-04-28T04:06:45.649737                                                            #
######################################################################################################

from __future__ import annotations



def copy_tree(src, dst, update = False):
    ...

def sync_local_metadata_to_datastore(metadata_local_dir, task_ds):
    ...

def sync_local_metadata_from_datastore(metadata_local_dir, task_ds):
    ...

