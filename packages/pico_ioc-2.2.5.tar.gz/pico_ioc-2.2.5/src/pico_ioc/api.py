"""High-level API for bootstrapping the pico-ioc container.

The :func:`init` function is the primary entry point. It scans modules,
validates bindings, and returns a fully wired :class:`PicoContainer`.
"""

import importlib
import inspect
import logging
import pkgutil
from typing import Any, Callable, Dict, Iterable, List, Optional, Set, Tuple, Union

from .aop import ContainerObserver
from .component_scanner import CustomScanner
from .config_builder import ContextConfig, configuration
from .constants import SCOPE_SINGLETON
from .container import PicoContainer
from .decorators import Qualifier, cleanup, component, configure, configured, factory, provides
from .exceptions import ConfigurationError, InvalidBindingError
from .factory import ComponentFactory, ProviderMetadata
from .locator import ComponentLocator
from .registrar import Registrar
from .scope import ScopedCaches, ScopeManager

KeyT = Union[str, type]
Provider = Callable[[], Any]


def _scan_package(package) -> Iterable[Any]:
    for _, name, _ in pkgutil.walk_packages(package.__path__, package.__name__ + "."):
        yield importlib.import_module(name)


def _is_sequence(inputs: Any) -> bool:
    return isinstance(inputs, Iterable) and not inspect.ismodule(inputs) and not isinstance(inputs, str)


def _resolve_module(it: Any):
    return importlib.import_module(it) if isinstance(it, str) else it


def _iter_input_modules(inputs: Union[Any, Iterable[Any]]) -> Iterable[Any]:
    seq = inputs if _is_sequence(inputs) else [inputs]
    seen: Set[str] = set()
    for it in seq:
        mod = _resolve_module(it)
        for resolved in _scan_package(mod) if hasattr(mod, "__path__") else [mod]:
            name = getattr(resolved, "__name__", None)
            if name and name not in seen:
                seen.add(name)
                yield resolved


def _normalize_override_provider(v: Any):
    if isinstance(v, tuple) and len(v) == 2:
        src, lz = v
        if callable(src):
            return (lambda s=src: s()), bool(lz)
        return (lambda s=src: s), bool(lz)
    if callable(v):
        return (lambda f=v: f()), False
    return (lambda inst=v: inst), False


def init(
    modules: Union[Any, Iterable[Any]],
    *,
    profiles: Tuple[str, ...] = (),
    allowed_profiles: Optional[Iterable[str]] = None,
    environ: Optional[Dict[str, str]] = None,
    overrides: Optional[Dict[KeyT, Any]] = None,
    logger: Optional[logging.Logger] = None,
    config: Optional[ContextConfig] = None,
    custom_scopes: Optional[Iterable[str]] = None,
    validate_only: bool = False,
    container_id: Optional[str] = None,
    observers: Optional[List[ContainerObserver]] = None,
    custom_scanners: Optional[List[CustomScanner]] = None,
) -> PicoContainer:
    """Bootstrap the pico-ioc container.

    Scans the given modules for decorated components, validates all
    dependency bindings, eagerly creates non-lazy singletons, and returns a
    ready-to-use :class:`PicoContainer`.

    Args:
        modules: One or more Python modules (or packages, or dotted-name
            strings) to scan for ``@component``, ``@factory``,
            ``@provides``, and ``@configured`` declarations.
        profiles: Active profile names for conditional binding.
        allowed_profiles: If set, unknown profile names raise
            :class:`ConfigurationError`.
        environ: Custom environment dict (defaults to ``os.environ``).
        overrides: Dict of ``{key: value_or_callable}`` that replace
            scanned providers. Useful for testing.
        logger: Custom logger for framework messages.
        config: An optional :class:`ContextConfig` created by
            :func:`configuration`.
        custom_scopes: Additional scope names to register (each backed by
            a new ``ContextVar``).
        validate_only: If ``True``, perform binding validation and cycle
            detection but skip eager singleton creation.
        container_id: Explicit container identifier.
        observers: :class:`ContainerObserver` instances for monitoring.
        custom_scanners: :class:`CustomScanner` implementations for
            extending component discovery.

    Returns:
        A fully wired :class:`PicoContainer`.

    Raises:
        ConfigurationError: If unknown profiles are used or async
            singletons lack ``lazy=True``.
        InvalidBindingError: If dependency validation or cycle detection
            fails.
        ProviderNotFoundError: If a required dependency cannot be found.

    Example:
        >>> from pico_ioc import init, configuration, DictSource
        >>> container = init(
        ...     modules=["myapp"],  # scans recursively
        ...     config=configuration(DictSource({"db": {"url": "sqlite://"}})),
        ... )
        >>> svc = container.get(MyService)
    """
    active = tuple(p.strip() for p in profiles if p)
    _validate_profiles(active, allowed_profiles)

    factory, registrar, pico = _create_container(
        active, environ, logger, config, custom_scopes, custom_scanners, container_id, observers,
    )

    for m in _iter_input_modules(modules):
        registrar.register_module(m)

    _apply_overrides(factory, overrides)
    registrar.finalize(overrides, pico_instance=pico)

    return _wire_and_resolve(pico, registrar, validate_only)


def _create_container(active, environ, logger, config, custom_scopes, custom_scanners, container_id, observers):
    factory = ComponentFactory()
    caches = ScopedCaches()
    scopes = ScopeManager()
    if custom_scopes:
        for name in custom_scopes:
            scopes.register_scope(name)

    pico = PicoContainer(factory, caches, scopes, container_id=container_id, profiles=active, observers=observers or [])
    registrar = Registrar(factory, profiles=active, environ=environ, logger=logger, config=config)

    if custom_scanners:
        for scanner in custom_scanners:
            registrar.register_custom_scanner(scanner)

    return factory, registrar, pico


def _apply_overrides(factory, overrides):
    if overrides:
        for k, v in overrides.items():
            prov, _ = _normalize_override_provider(v)
            factory.bind(k, prov)


def _wire_and_resolve(pico, registrar, validate_only):
    locator = registrar.locator()
    if validate_only:
        pico.attach_locator(locator)
        _fail_fast_cycle_check(pico)
        return pico

    registrar.attach_runtime(pico, locator)
    pico.attach_locator(locator)
    _fail_fast_cycle_check(pico)
    _eagerly_resolve_singletons(pico, locator)
    return pico


def _validate_profiles(active: Tuple[str, ...], allowed_profiles: Optional[Iterable[str]]) -> None:
    if allowed_profiles is None:
        return
    allowed_set = set(a.strip() for a in allowed_profiles)
    unknown = set(active) - allowed_set
    if unknown:
        raise ConfigurationError(f"Unknown profiles: {sorted(unknown)}; allowed: {sorted(allowed_set)}")


def _eagerly_resolve_singletons(pico: PicoContainer, locator: ComponentLocator) -> None:
    eager_singletons = []
    for key, md in locator._metadata.items():
        if md.scope == SCOPE_SINGLETON and not md.lazy:
            cache = pico._cache_for(key)
            instance = cache.get(key)
            if instance is None:
                instance = pico.get(key)
            eager_singletons.append(instance)

    configure_awaitables = []
    for instance in eager_singletons:
        res = pico._run_configure_methods(instance)
        if inspect.isawaitable(res):
            configure_awaitables.append(res)

    if configure_awaitables:
        raise ConfigurationError(
            "Sync init() found eagerly loaded singletons with async @configure methods. "
            "This can be caused by an async __ainit__ or async @configure. "
            "Use an async main function and await pico.aget() for those components, "
            "or mark them as lazy=True."
        )


def _find_cycle(graph: Dict[KeyT, Tuple[KeyT, ...]]) -> Optional[Tuple[KeyT, ...]]:
    temp: Set[KeyT] = set()
    perm: Set[KeyT] = set()
    stack: List[KeyT] = []

    def visit(n: KeyT) -> Optional[Tuple[KeyT, ...]]:
        if n in perm:
            return None
        if n in temp:
            try:
                idx = stack.index(n)
                return tuple(stack[idx:] + [n])
            except ValueError:
                return tuple([n, n])
        temp.add(n)
        stack.append(n)
        for m in graph.get(n, ()):
            c = visit(m)
            if c:
                return c
        stack.pop()
        temp.remove(n)
        perm.add(n)
        return None

    for node in graph.keys():
        c = visit(node)
        if c:
            return c
    return None


def _format_key(k: KeyT) -> str:
    return getattr(k, "__name__", str(k))


def _fail_fast_cycle_check(pico: "PicoContainer") -> None:
    graph = pico.build_resolution_graph()
    cyc = _find_cycle(graph)
    if not cyc:
        return
    path = " -> ".join(_format_key(k) for k in cyc)
    raise InvalidBindingError([f"Circular dependency detected: {path}"])
