Read and follow ./AGENTS.md for project conventions.

## Pico Ecosystem Context

pico-ioc is the **foundation** of the pico ecosystem. All other packages depend on it:

- pico-boot: orchestration & plugin discovery
- pico-fastapi: FastAPI integration
- pico-sqlalchemy: SQLAlchemy + transactions
- pico-celery: Celery task integration
- pico-pydantic: Pydantic validation AOP
- pico-agent: LLM agent framework

## Key Reminders

- **Commit messages: ONE LINE ONLY.** No body, no footer, no `Co-Authored-By` block. If you wrote multiple lines, amend before the user has to ask.
- Internal attributes are `_pico_meta`, `_pico_infra`, `_pico_name`, `_pico_key` (not dunder)
- **NEVER change `version_scheme`** in pyproject.toml. It MUST remain `"post-release"`. Changing it to `"guess-next-dev"` causes `.dev0` versions to leak to PyPI. This was already fixed once — do not revert it.
- requires-python >= 3.11 (no 3.10)
