from __future__ import annotations

from memoria.interfaces.cli.app import app


def main() -> None:
    app()


if __name__ == "__main__":
    main()
