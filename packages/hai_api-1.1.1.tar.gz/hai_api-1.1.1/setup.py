from setuptools import setup, find_packages

setup(
    name="hai-api",
    version="1.1.1",
    author="Hussain Alkhatib",
    description="The official Python SDK for hAI Private AI.",
    long_description=open("README.md", "r", encoding="utf-8").read() if open("README.md", "r") else "hAI Python SDK",
    long_description_content_type="text/markdown",
    url="https://ai.hussain.ink",
    packages=find_packages(),
    install_requires=[
        "httpx>=0.24.0",
        "python-dotenv>=1.0.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
