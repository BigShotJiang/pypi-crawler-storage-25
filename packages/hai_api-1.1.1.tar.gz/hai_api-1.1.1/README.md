# hai-api (Python SDK)

The official Python SDK for Hussain's Private AI Bridge (hAI). This library allows you to interact with multiple AI models through a single, easy-to-use client.

## Installation

```bash
pip install hai-api
```

## Features
- Unified interface for DeepSeek and Gemini.
- Full support for streaming and tool-use.
- Robust session management.
