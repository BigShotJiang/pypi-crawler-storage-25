"""Tests for clustering module."""
