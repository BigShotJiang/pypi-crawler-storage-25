"""Tests for statistics module."""
