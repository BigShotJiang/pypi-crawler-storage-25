"""Tests for visualization module."""
