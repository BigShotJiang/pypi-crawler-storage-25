"""Tests for yasqat package."""
