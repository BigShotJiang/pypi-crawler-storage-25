"""
yasqat - Yet Another Sequence Analytics Toolkit

A modern Python library for sequence analysis with polars and plotnine.
"""

from importlib.metadata import PackageNotFoundError, version

from yasqat import io as io  # re-export so `yasqat.io` works
from yasqat.core.alphabet import Alphabet
from yasqat.core.pool import SequencePool
from yasqat.core.sequence import (
    IntervalSequence,
    SequenceConfig,
    StateSequence,
)

try:
    __version__ = version("yasqat")
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = [
    "Alphabet",
    "IntervalSequence",
    "SequenceConfig",
    "SequencePool",
    "StateSequence",
    "__version__",
    "io",
]
