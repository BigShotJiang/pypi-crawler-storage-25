"""SequencePool class for managing collections of sequences."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from yasqat.core.alphabet import Alphabet
from yasqat.core.sequence import SequenceConfig, StateSequence

if TYPE_CHECKING:
    from yasqat.metrics.base import DistanceMatrix


@dataclass
class SequencePool:
    """
    A pool (collection) of sequences for batch operations.

    SequencePool provides efficient operations on multiple sequences,
    including pairwise distance computation and batch statistics.
    """

    _data: pl.DataFrame = field(default_factory=pl.DataFrame)
    _config: SequenceConfig = field(default_factory=SequenceConfig)
    _alphabet: Alphabet = field(default_factory=lambda: Alphabet(states=()))
    _sequences: dict[int | str, list[str]] = field(default_factory=dict)

    def __init__(
        self,
        data: pl.DataFrame,
        config: SequenceConfig | None = None,
        alphabet: Alphabet | None = None,
    ) -> None:
        """
        Initialize a sequence pool.

        Args:
            data: Polars DataFrame with sequence data in long format.
            config: Column configuration.
            alphabet: State alphabet (inferred if not provided).
        """
        self._config = config or SequenceConfig()
        self._data = self._validate_and_prepare(data)
        self._alphabet = alphabet or self._infer_alphabet()
        self._sequences = self._extract_sequences()

    def _validate_and_prepare(self, data: pl.DataFrame) -> pl.DataFrame:
        """Validate and prepare the data."""
        required_cols = [
            self._config.id_column,
            self._config.time_column,
            self._config.state_column,
        ]

        for col in required_cols:
            if col not in data.columns:
                raise ValueError(f"Missing required column: {col}")

        return data.sort([self._config.id_column, self._config.time_column])

    def _infer_alphabet(self) -> Alphabet:
        """Infer alphabet from data."""
        return Alphabet.from_series(self._data[self._config.state_column])

    def _extract_sequences(self) -> dict[int | str, list[str]]:
        """Extract sequences as lists of states using a single group_by pass."""
        id_col = self._config.id_column
        state_col = self._config.state_column

        # Data is already sorted by [id, time] from _validate_and_prepare.
        # maintain_order=True preserves that row order within each group.
        grouped = self._data.group_by(id_col, maintain_order=True).agg(
            pl.col(state_col)
        )

        return {row[id_col]: row[state_col] for row in grouped.iter_rows(named=True)}

    @property
    def data(self) -> pl.DataFrame:
        """Return the underlying DataFrame."""
        return self._data

    @property
    def alphabet(self) -> Alphabet:
        """Return the state alphabet."""
        return self._alphabet

    @property
    def config(self) -> SequenceConfig:
        """Return the column configuration."""
        return self._config

    @property
    def sequence_ids(self) -> list[int | str]:
        """Return sorted list of unique sequence IDs."""
        return sorted(self._sequences.keys())

    def __len__(self) -> int:
        """Return the number of sequences in the pool."""
        return len(self._sequences)

    def __getitem__(self, seq_id: int | str) -> list[str]:
        """Get a sequence by ID."""
        return self._sequences[seq_id]

    def __iter__(self):  # type: ignore[no-untyped-def]
        """Iterate over sequence IDs."""
        return iter(self._sequences)

    def get_sequence(self, seq_id: int | str) -> list[str]:
        """Get states for a specific sequence."""
        return self._sequences[seq_id]

    def get_encoded_sequence(self, seq_id: int | str) -> np.ndarray:
        """Get an encoded sequence as numpy array."""
        return self._alphabet.encode(self._sequences[seq_id])

    def to_state_sequence(self) -> StateSequence:
        """Convert to a StateSequence object."""
        return StateSequence(
            data=self._data,
            config=self._config,
            alphabet=self._alphabet,
        )

    def sequence_lengths(self) -> pl.DataFrame:
        """Get the length of each sequence."""
        return (
            self._data.group_by(self._config.id_column)
            .agg(pl.len().alias("length"))
            .sort(self._config.id_column)
        )

    def compute_distances(
        self,
        method: str = "om",
        n_jobs: int = 1,
        **kwargs: float,
    ) -> DistanceMatrix:
        """
        Compute pairwise distance matrix.

        Args:
            method: Distance method ("om", "hamming", "lcs", "lcp", "rlcp",
                "euclidean", "chi2", "dtw", "twed", "omloc", "omspell",
                "omstran", "nms", "nmsmst", "svrspell").
            n_jobs: Number of parallel workers. 1 = sequential (default).
                -1 = use all available CPUs. Values > 1 use that many threads.
                Parallelism uses threads (not processes) since numba releases
                the GIL.
            **kwargs: Method-specific parameters.

        Returns:
            DistanceMatrix with pairwise distances and sequence ID labels.

        Note:
            This uses an O(n²) loop over sequence pairs. For large pools
            (n > ~500) consider using :meth:`sample` to draw a representative
            subset first, or use CLARA clustering which applies sampling
            internally (see :func:`yasqat.clustering.clara_clustering`).
        """
        from yasqat.metrics import (
            chi2_distance,
            euclidean_distance,
            hamming_distance,
            lcp_distance,
            lcs_distance,
            nms_distance,
            nmsmst_distance,
            omloc_distance,
            omspell_distance,
            omstran_distance,
            optimal_matching_distance,
            rlcp_distance,
            svrspell_distance,
            twed_distance,
        )
        from yasqat.metrics.base import DistanceMatrix
        from yasqat.metrics.dtw import dtw_distance

        methods: dict[str, Callable[..., float]] = {
            "om": optimal_matching_distance,
            "hamming": hamming_distance,
            "lcs": lcs_distance,
            "lcp": lcp_distance,
            "rlcp": rlcp_distance,
            "euclidean": euclidean_distance,
            "chi2": chi2_distance,
            "dtw": dtw_distance,
            "twed": twed_distance,
            "omloc": omloc_distance,
            "omspell": omspell_distance,
            "omstran": omstran_distance,
            "nms": nms_distance,
            "nmsmst": nmsmst_distance,
            "svrspell": svrspell_distance,
        }

        if method not in methods:
            raise ValueError(f"Unknown method: {method}. Available: {list(methods)}")

        metric_fn = methods[method]
        n = len(self)
        ids = self.sequence_ids
        distances = np.zeros((n, n), dtype=np.float64)

        # Pre-encode all sequences
        encoded = [self.get_encoded_sequence(ids[i]) for i in range(n)]

        if n_jobs == 1:
            for i in range(n):
                for j in range(i + 1, n):
                    dist = metric_fn(encoded[i], encoded[j], **kwargs)
                    distances[i, j] = dist
                    distances[j, i] = dist
        else:
            import os
            from concurrent.futures import ThreadPoolExecutor, as_completed

            workers = os.cpu_count() or 1 if n_jobs == -1 else n_jobs
            pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

            def _compute_pair(pair: tuple[int, int]) -> tuple[int, int, float]:
                i, j = pair
                return i, j, metric_fn(encoded[i], encoded[j], **kwargs)

            with ThreadPoolExecutor(max_workers=workers) as executor:
                futures = [executor.submit(_compute_pair, p) for p in pairs]
                for future in as_completed(futures):
                    i, j, dist = future.result()
                    distances[i, j] = dist
                    distances[j, i] = dist

        return DistanceMatrix(values=distances, labels=ids)

    def filter_by_length(
        self,
        min_length: int | None = None,
        max_length: int | None = None,
    ) -> SequencePool:
        """Filter sequences by length."""
        lengths = self.sequence_lengths()
        id_col = self._config.id_column

        if min_length is not None:
            lengths = lengths.filter(pl.col("length") >= min_length)
        if max_length is not None:
            lengths = lengths.filter(pl.col("length") <= max_length)

        valid_ids = lengths[id_col].to_list()
        filtered_data = self._data.filter(pl.col(id_col).is_in(valid_ids))

        return SequencePool(
            data=filtered_data,
            config=self._config,
            alphabet=self._alphabet,
        )

    def sample(self, n: int, seed: int | None = None) -> SequencePool:
        """Sample n sequences from the pool."""
        rng = np.random.default_rng(seed)
        ids = self.sequence_ids
        sampled_ids = rng.choice(ids, size=min(n, len(ids)), replace=False).tolist()

        sampled_data = self._data.filter(
            pl.col(self._config.id_column).is_in(sampled_ids)
        )

        return SequencePool(
            data=sampled_data,
            config=self._config,
            alphabet=self._alphabet,
        )

    def recode_states(self, mapping: dict[str, str]) -> SequencePool:
        """
        Recode (merge or rename) states using a mapping.

        Creates a new SequencePool with states transformed according to
        the mapping. States not in the mapping are kept as-is.
        The alphabet is rebuilt from the recoded data.

        Args:
            mapping: Dictionary mapping old state names to new state names.
                Multiple old states can map to the same new state (merging).

        Returns:
            New SequencePool with recoded states and updated alphabet.

        Example:
            >>> pool.recode_states({"A": "X", "B": "X"})  # Merge A and B into X
        """
        state_col = self._config.state_column

        recoded_data = self._data.with_columns(
            pl.col(state_col).replace(mapping).alias(state_col)
        )

        return SequencePool(
            data=recoded_data,
            config=self._config,
        )

    def describe(self) -> dict[str, int | float | list[str]]:
        """Get summary statistics about the pool."""
        lengths = self.sequence_lengths()["length"]
        min_len = lengths.min()
        max_len = lengths.max()
        mean_len = lengths.mean()
        median_len = lengths.median()

        return {
            "n_sequences": len(self),
            "n_states": len(self._alphabet),
            "states": list(self._alphabet.states),
            "total_observations": self._data.height,
            "min_length": int(min_len) if isinstance(min_len, (int, float)) else 0,
            "max_length": int(max_len) if isinstance(max_len, (int, float)) else 0,
            "mean_length": float(mean_len)
            if isinstance(mean_len, (int, float))
            else 0.0,
            "median_length": float(median_len)
            if isinstance(median_len, (int, float))
            else 0.0,
        }
