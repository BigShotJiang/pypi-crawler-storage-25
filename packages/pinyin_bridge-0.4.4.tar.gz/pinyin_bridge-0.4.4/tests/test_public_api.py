import re
from pathlib import Path

import pytest

import pinyin_bridge
import pinyin_bridge.core.pinyin as core_pinyin
import pinyin_bridge.core.text as core_text
import pinyin_bridge.core.tokenizer as core_tokenizer


EXPECTED_PUBLIC_API = [
    "__version__",
    "add_word",
    "add_words",
    "analyze",
    "classify",
    "clear_words",
    "delete_word",
    "list_words",
    "pinyin",
    "reverse",
    "segment",
]


def test_pyproject_version_matches_public_module_version():
    pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
    content = pyproject.read_text(encoding="utf-8")
    match = re.search(r'^version = "([^"]+)"$', content, re.MULTILINE)
    assert match is not None
    assert match.group(1) == pinyin_bridge.__version__


def test_public_pinyin_supports_style_and_word_unit():
    assert pinyin_bridge.pinyin("中国", style="num") == ["zhong1", "guo2"]
    assert pinyin_bridge.pinyin("北京欢迎你", style="mark", unit="word") == ["běi jīng", "huān yíng", "nǐ"]
    assert pinyin_bridge.pinyin("银行", heteronym=True) == ["yin", "hang"]
    assert pinyin_bridge.pinyin("重阳", style="mark", unit="word", heteronym=True) == ["chóng yáng"]
    assert pinyin_bridge.pinyin("长春", style="mark", unit="word") == ["cháng chūn"]


def test_public_api_exposes_analyze_and_classify():
    analysis = pinyin_bridge.analyze("中国")
    finals = [char.chosen.final for token in analysis.tokens for char in token.chars if char.chosen]
    assert finals == ["ong", "uo"]
    assert set(pinyin_bridge.classify("中国").keys()) == {"声母", "韵母", "声调"}


def test_public_api_surface_stays_narrow():
    assert pinyin_bridge.__all__ == EXPECTED_PUBLIC_API
    assert "tone" not in pinyin_bridge.__all__
    assert "word_pinyin" not in pinyin_bridge.__all__
    assert "segment_text" not in pinyin_bridge.__all__
    assert "segment_with_pinyin" not in pinyin_bridge.__all__


def test_internal_legacy_helpers_are_removed():
    assert not hasattr(core_pinyin, "tone")
    assert not hasattr(core_pinyin, "word_pinyin")
    assert not hasattr(core_text, "segment_text")
    assert not hasattr(core_tokenizer, "segment_with_pinyin")


def test_removed_legacy_helpers_cannot_be_imported():
    with pytest.raises(ImportError):
        from pinyin_bridge.core.pinyin import tone

    with pytest.raises(ImportError):
        from pinyin_bridge.core.pinyin import word_pinyin

    with pytest.raises(ImportError):
        from pinyin_bridge.core.text import segment_text

    with pytest.raises(ImportError):
        from pinyin_bridge.core.tokenizer import segment_with_pinyin


def test_user_dictionary_round_trip():
    pinyin_bridge.add_word("乔布斯", "qiáo bù sī")
    try:
        assert pinyin_bridge.pinyin("乔布斯", style="mark", unit="word") == ["qiáo bù sī"]
        assert any(item["text"] == "乔布斯" for item in pinyin_bridge.list_words())
    finally:
        pinyin_bridge.delete_word("乔布斯")


def test_user_dictionary_invalidates_segment_and_reverse_views():
    seg_before = pinyin_bridge.segment("这是测试词")
    pinyin_bridge.add_word("测试词", "cè shì cí")
    try:
        seg_after = pinyin_bridge.segment("这是测试词")
        assert seg_after != seg_before, "segment should change after adding word"
        assert any(item["text"] == "测试词" for item in pinyin_bridge.reverse("ce4", scope="word"))
    finally:
        pinyin_bridge.delete_word("测试词")
