import pinyin_bridge


def test_segment_groups_adjacent_non_chinese_text():
    assert pinyin_bridge.segment("hello 中国 2026!") == ["hello", " ", "中国", " ", "2026", "!"]


def test_segment_groups_unknown_chinese_runs_until_known_phrase_boundary():
    assert pinyin_bridge.segment("重阳中国") == ["重阳", "中国"]


def test_word_unit_preserves_grouped_non_chinese_tokens():
    assert pinyin_bridge.pinyin("hello中国2026", unit="word") == ["hello", "zhong guo", "2026"]
