from pinyin_bridge.core.rules import marked_syllable


def test_marked_syllable_handles_iu_and_ui_tone_placement():
    assert marked_syllable("xiu", 4) == "xiù"
    assert marked_syllable("liu", 2) == "liú"
    assert marked_syllable("gui", 3) == "guǐ"
    assert marked_syllable("dui", 4) == "duì"
