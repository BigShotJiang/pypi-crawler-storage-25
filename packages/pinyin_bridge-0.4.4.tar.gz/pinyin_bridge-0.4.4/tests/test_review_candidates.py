from pinyin_bridge.data.review_candidates import audit_review_candidates, load_review_candidates


def test_review_candidates_are_unique_and_non_runtime():
    candidates = load_review_candidates()
    texts = {candidate.text for candidate in candidates}
    assert len(candidates) == len(texts)
    assert "龟兹" in texts
    assert "下载" not in texts
    assert "秘鲁" not in texts
    assert "阿房宫" not in texts
    assert "角色" not in texts
    assert "说服" not in texts
    assert "口吃" not in texts
    assert "倔强" not in texts
    assert "燕山" not in texts
    assert "乳臭未干" not in texts


def test_review_candidate_audit_reports_seed_coverage_and_gaps():
    rows = {row.text: row for row in audit_review_candidates()}
    assert rows["龟兹"].status == "missing"
    assert rows["龟兹"].pypinyin == "qiū cí"
    assert rows["柏树"].status == "missing"
    assert rows["臭味相投"].status == "missing"
