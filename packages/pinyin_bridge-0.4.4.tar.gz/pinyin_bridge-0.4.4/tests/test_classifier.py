from pinyin_bridge.core.analyzer import analyze
from pinyin_bridge.core.classifier import classify
from pinyin_bridge.core.formatter import pinyin_list


def test_formatter_outputs_requested_styles():
    analysis = analyze("中国")
    assert pinyin_list(analysis, style="plain", unit="char") == ["zhong", "guo"]
    assert pinyin_list(analysis, style="num", unit="char") == ["zhong1", "guo2"]
    assert pinyin_list(analysis, style="mark", unit="char") == ["zhōng", "guó"]


def test_classify_final_reads_from_analyzer_finals():
    buckets = {item["name"]: item["detail"] for item in classify("中国", kind="final")}
    assert buckets["后鼻音韵母"] == [["中", "zhōng"]]
    assert buckets["后响复韵母"] == [["国", "guó"]]


def test_classify_all_returns_named_sections():
    grouped = classify("中国", kind="all")
    assert set(grouped.keys()) == {"声母", "韵母", "声调"}
