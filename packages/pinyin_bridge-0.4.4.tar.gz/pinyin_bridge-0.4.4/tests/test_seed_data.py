from pinyin_bridge.data.seed_loader import SEED_FILES, load_seed_entries, load_seed_phrase_entries


def test_seed_loader_exposes_expected_entries():
    entries = {entry.text: entry for entry in load_seed_entries()}
    assert SEED_FILES == ("core_words.tsv", "manual_reviewed.tsv", "polyphonic_words.tsv", "places.tsv")
    assert entries["重庆"].category == "polyphonic"
    assert entries["重庆"].priority == 200
    assert entries["中华人民共和国"].pinyin == "zhōng huá rén mín gòng hé guó"
    assert entries["重庆"].review_status == "approved"
    assert entries["重庆"].source_ref == "pypinyin:phrase_dict"
    assert len(entries) >= 69
    assert entries["燕国"].default_pinyin == "yàn guó"
    assert entries["燕国"].notes
    assert entries["会稽"].default_pinyin == "huì jī"
    assert entries["角色"].source_ref == "manual:reviewed_2026-04-19"
    assert entries["下载"].source_ref == "manual:reviewed_2026-04-19"
    assert entries["秘鲁"].category == "place"
    assert entries["说服"].source_ref == "zdic:hans/说服"
    assert entries["口吃"].pinyin == "kǒu chī"
    assert entries["倔强"].pinyin == "jué jiàng"
    assert entries["燕山"].source_ref == "zdic:hans/燕山"
    assert entries["乳臭未干"].pinyin == "rǔ xiù wèi gān"


def test_seed_phrase_entries_are_normalized_for_runtime_use():
    phrases = load_seed_phrase_entries()
    assert phrases["中国"] == ("zhōng guó", "seed:core")
    assert phrases["北京"] == ("běi jīng", "seed:place")
    assert phrases["银行"] == ("yín háng", "seed:polyphonic")
    assert phrases["广州"] == ("guǎng zhōu", "seed:place")
    assert phrases["燕国"] == ("yān guó", "seed:historical")
    assert phrases["番禺"] == ("pān yú", "seed:place")
    assert phrases["下载"] == ("xià zài", "seed:common")
