import subprocess
import sys

from pinyin_bridge.data.seed_status import build_seed_status_report, render_seed_status_report


def test_seed_status_report_contains_runtime_and_candidate_counts():
    report = build_seed_status_report()
    files = {status.filename: status for status in report.file_statuses}

    assert report.seed_file_count == 4
    assert report.raw_seed_rows == 69
    assert report.active_seed_rows == 69
    assert report.override_rows == 2
    assert report.active_review_counts == {"approved": 69}
    assert report.active_category_counts["polyphonic"] == 24
    assert report.active_category_counts["place"] == 22
    assert report.active_source_counts["manual_reviewed"] == 2
    assert report.candidate_total == 6
    assert report.candidate_status_counts == {"missing": 6}
    assert report.candidate_category_counts["historical"] == 4
    assert files["manual_reviewed.tsv"].active_rows == 2
    assert files["polyphonic_words.tsv"].category_counts["polyphonic"] == 24


def test_seed_status_report_renderer_has_expected_sections():
    output = render_seed_status_report(build_seed_status_report())

    assert "Seed Lexicon Status" in output
    assert "Seed Files" in output
    assert "Active Entries By Category" in output
    assert "Review Candidates By Status" in output
    assert "manual_overrides: 2" in output
    assert "review_candidates: 6" in output


def test_show_seed_status_script_outputs_report():
    completed = subprocess.run(
        [sys.executable, "scripts/show_seed_status.py"],
        capture_output=True,
        text=True,
        check=False,
    )

    assert completed.returncode == 0
    assert "Seed Lexicon Status" in completed.stdout
    assert "active_seed_entries: 69" in completed.stdout
    assert "Review Candidates By Status" in completed.stdout
