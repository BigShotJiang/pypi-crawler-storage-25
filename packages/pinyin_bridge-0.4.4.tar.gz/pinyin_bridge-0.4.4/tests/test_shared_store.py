"""Tests for shared_store.py - SharedDict with Redis backend."""

import os
import pytest

from pinyin_bridge.data.shared_store import SharedDict


class TestSharedDictMemory:
    """Test SharedDict with in-memory backend."""

    def test_basic_operations(self):
        shared = SharedDict("test:basic", mode="memory")
        
        # set and get
        shared.set("中国", "zhong guo")
        assert shared.get("中国") == "zhong guo"
        
        # delete
        shared.delete("中国")
        assert shared.get("中国") is None
        
        # get_all
        shared.bulk_set([("你好", "ni hao"), ("世界", "shi jie")])
        all_data = shared.get_all()
        assert all_data == {"你好": "ni hao", "世界": "shi jie"}
        
        # clear
        shared.clear()
        assert shared.get_all() == {}
        
        # check backend
        assert shared.is_using_redis is False

    def test_override_value(self):
        shared = SharedDict("test:override", mode="memory")
        
        shared.set("中国", "zhong guo")
        shared.set("中国", "zhong guo 2")
        assert shared.get("中国") == "zhong guo 2"

    def test_concurrent_access(self, monkeypatch):
        import threading
        
        shared = SharedDict("test:concurrent", mode="memory")
        results = []
        
        def writer(index):
            shared.set(f"key{index}", f"value{index}")
            results.append(shared.get(f"key{index}"))
        
        threads = [threading.Thread(target=writer, args=(i,)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        
        assert len(results) == 10
        assert shared.is_using_redis is False


def redis_available():
    """Check if Redis is available."""
    try:
        import redis
        r = redis.from_url("redis://localhost:6379")
        r.ping()
        return True
    except Exception:
        return False


class TestSharedDictRedis:
    """Test SharedDict with Redis backend. Requires Redis running."""

    def test_redis_backend(self):
        if not redis_available():
            pytest.skip("Redis not available")
        
        shared = SharedDict("test:redis", mode="redis")
        
        # Check backend
        assert shared.is_using_redis is True
        
        # Basic operations
        shared.set("redis测试", "redis ceshi")
        assert shared.get("redis测试") == "redis ceshi"
        
        shared.delete("redis测试")
        assert shared.get("redis测试") is None
        
        # Cleanup
        shared.clear()

    def test_cross_process_sync(self):
        """Test that multiple processes see the same data."""
        if not redis_available():
            pytest.skip("Redis not available")
        
        shared1 = SharedDict("test:cross", mode="redis")
        shared1.clear()
        shared1.set("共享词", "gong xiang ci")
        
        # Simulate another process
        shared2 = SharedDict("test:cross", mode="redis")
        assert shared2.get("共享词") == "gong xiang ci"
        
        # Cleanup
        shared1.clear()


class TestSharedDictAutoMode:
    """Test auto-detect mode."""

    def test_auto_mode_without_env(self, monkeypatch):
        monkeypatch.delenv("PINYIN_BRIDGE_REDIS_URL", raising=False)
        
        shared = SharedDict("test:auto", mode=None)
        
        # Should use memory when no Redis URL set
        assert shared.is_using_redis is False

    def test_auto_mode_with_env(self, monkeypatch):
        if not redis_available():
            pytest.skip("Redis not available")
        
        monkeypatch.setenv("PINYIN_BRIDGE_REDIS_URL", "redis://localhost:6379")
        
        shared = SharedDict("test:auto_env", mode=None)
        
        assert shared.is_using_redis is True
        
        # Cleanup
        shared.clear()


# Run examples from docstring
def test_examples():
    """Run examples from docstring."""
    # Auto-detect (default): use Redis if PINYIN_BRIDGE_REDIS_URL set, else memory
    shared = SharedDict("test:examples", mode="memory")
    assert shared.is_using_redis is False
    
    # Basic operations
    shared.set("中国", "zhong guo")
    assert shared.get("中国") == "zhong guo"
    shared.delete("中国")
    assert shared.get("中国") is None
    
    # Bulk operations
    shared.bulk_set([("你好", "ni hao"), ("世界", "shi jie")])
    assert shared.get_all() == {"你好": "ni hao", "世界": "shi jie"}
    
    # Clear
    shared.clear()
    assert shared.get_all() == {}