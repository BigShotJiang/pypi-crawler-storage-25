import pinyin_bridge


def test_reverse_auto_detects_numbered_queries():
    results = pinyin_bridge.reverse("zhong1", tone="auto", scope="char")
    assert any(item["text"] == "中" for item in results)


def test_reverse_char_scope_uses_full_single_character_index():
    results = pinyin_bridge.reverse("hao3", tone="auto", scope="char")
    assert any(item["text"] == "好" for item in results)


def test_reverse_word_scope_matches_phrase_entries():
    pinyin_bridge.add_word("苹果", "píng guǒ")
    try:
        results = pinyin_bridge.reverse("ping", tone="ignore", scope="word")
        assert any(item["text"] == "苹果" for item in results)
    finally:
        pinyin_bridge.delete_word("苹果")


def test_reverse_rejects_invalid_options():
    try:
        pinyin_bridge.reverse("zhong1", tone="bad")
    except ValueError as exc:
        assert str(exc) == "Unsupported tone mode: bad"
    else:
        raise AssertionError("reverse() should reject unsupported tone modes")

    try:
        pinyin_bridge.reverse("zhong1", scope="bad")
    except ValueError as exc:
        assert str(exc) == "Unsupported scope: bad"
    else:
        raise AssertionError("reverse() should reject unsupported scopes")
