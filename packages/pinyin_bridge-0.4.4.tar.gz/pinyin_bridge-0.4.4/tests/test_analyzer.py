from pinyin_bridge.core.analyzer import analyze


def flatten(analysis):
    return [char for token in analysis.tokens for char in token.chars]


def test_analyze_uses_real_initials_finals_and_tones():
    flat = [c for c in flatten(analyze("中国")) if c.chosen]
    assert [
        (c.char, c.chosen.initial, c.chosen.final, c.chosen.tone)
        for c in flat
    ] == [
        ("中", "zh", "ong", 1),
        ("国", "g", "uo", 2),
    ]


def test_analyze_preserves_non_chinese_characters():
    chars = flatten(analyze("A中，B"))
    assert [char.chosen.plain if char.chosen else char.char for char in chars] == [
        "A",
        "zhong",
        "，",
        "B",
    ]


def test_analyze_phrase_hit_beats_character_fallback():
    chars = [char for char in flatten(analyze("重庆")) if char.chosen]
    assert [char.chosen.plain for char in chars] == ["chong", "qing"]
    assert all(char.chosen.source == "seed:polyphonic" for char in chars)
