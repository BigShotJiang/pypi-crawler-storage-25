from pathlib import Path

from pinyin_bridge.data import db


def test_default_database_path_falls_back_when_home_database_is_read_only(tmp_path, monkeypatch):
    read_only_db = tmp_path / "readonly.db"
    writable_fallback = tmp_path / "fallback.db"

    initial = db.Database(str(read_only_db))
    initial.close()
    read_only_db.chmod(0o444)

    monkeypatch.delenv(db.DB_PATH_ENV_VAR, raising=False)
    monkeypatch.setattr(db, "DEFAULT_DB_PATH", read_only_db)
    monkeypatch.setattr(db, "FALLBACK_DB_PATH", writable_fallback)
    db.reset_db()

    try:
        instance = db.get_db()
        instance.add_word("测试词", "cè shì cí")
        assert instance.db_path == writable_fallback
        assert any(item["text"] == "测试词" for item in instance.get_all_words("user"))
    finally:
        db.reset_db()
        read_only_db.chmod(0o644)
