import json
import subprocess
import sys


CLI = [sys.executable, "-m", "pinyin_bridge.cli"]


def run_cli(*args: str):
    return subprocess.run(CLI + list(args), capture_output=True, text=True)


def test_cli_json_outputs_array_payload():
    completed = run_cli("中国", "--json")
    assert completed.returncode == 0
    assert json.loads(completed.stdout) == [{"text": "中国", "result": ["zhong", "guo"]}]


def test_cli_classify_outputs_structured_json():
    completed = run_cli("中国", "--classify", "final")
    assert completed.returncode == 0
    payload = json.loads(completed.stdout)
    buckets = {item["name"]: item["detail"] for item in payload}
    assert buckets["后鼻音韵母"] == [["中", "zhōng"]]


def test_cli_reverse_outputs_reverse_matches():
    completed = run_cli("zhong1", "--reverse", "--json")
    assert completed.returncode == 0
    payload = json.loads(completed.stdout)
    assert any(item["result"][0]["text"] == "中" or any(match["text"] == "中" for match in item["result"]) for item in payload)
