from __future__ import annotations

from typing import Dict, List, Tuple

from pinyin_bridge.core.analyzer import analyze
from pinyin_bridge.core.formatter import analysis_to_array



def convert(text: str, tone_style: str = "mark", with_punctuation: bool = True) -> List[Tuple[str, str, str]]:
    rows = analysis_to_array(analyze(text), style=tone_style)
    result = []
    for row in rows:
        if not with_punctuation and row["is_punctuation"]:
            continue
        result.append((row["char"], row["pinyin"], row["full_pinyin"]))
    return result


def convert_simple(text: str, tone_style: str = "mark") -> List[str]:
    return [row["pinyin"] or row["char"] for row in analysis_to_array(analyze(text), style=tone_style)]


def convert_to_array(text: str, tone_style: str = "mark") -> List[Dict[str, object]]:
    return analysis_to_array(analyze(text), style=tone_style)


def set_phrase_dict(phrase_dict: dict):
    from pinyin_bridge.core.tokenizer import set_phrase_dict

    set_phrase_dict(phrase_dict)
