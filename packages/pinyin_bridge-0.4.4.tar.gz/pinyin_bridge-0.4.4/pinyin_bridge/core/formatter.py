from __future__ import annotations

from itertools import product
from typing import List

from pinyin_bridge.core.analyzer import Pronunciation, TextAnalysis
from pinyin_bridge.core.rules import marked_syllable, numbered_syllable

PinyinValue = str | list[str]


def render_pronunciation(pronunciation: Pronunciation, style: str = "plain") -> str:
    if style == "plain":
        return pronunciation.plain
    if style == "num":
        return numbered_syllable(pronunciation.plain, pronunciation.tone)
    if style == "mark":
        return marked_syllable(pronunciation.plain, pronunciation.tone)
    raise ValueError(f"Unsupported style: {style}")


def render_candidates(candidates: list[Pronunciation], style: str) -> list[str]:
    rendered: list[str] = []
    seen: set[str] = set()
    for candidate in candidates:
        value = render_pronunciation(candidate, style)
        if value not in seen:
            seen.add(value)
            rendered.append(value)
    return rendered


def render_word_candidates(token, style: str) -> str | list[str]:
    per_char = [render_candidates(char.candidates, style) for char in token.chars if char.candidates]
    if not per_char:
        return token.text

    variants: list[str] = []
    seen: set[str] = set()
    for pieces in product(*per_char):
        value = " ".join(pieces)
        if value not in seen:
            seen.add(value)
            variants.append(value)

    return variants[0] if len(variants) == 1 else variants


def pinyin_list(
    analysis: TextAnalysis,
    *,
    style: str = "plain",
    unit: str = "char",
    heteronym: bool = False,
) -> List[PinyinValue]:
    if unit == "char":
        result: List[PinyinValue] = []
        for token in analysis.tokens:
            for char in token.chars:
                if not char.chosen:
                    result.append(char.char)
                    continue

                if not heteronym:
                    result.append(render_pronunciation(char.chosen, style))
                    continue

                values = render_candidates(char.candidates, style)
                result.append(values[0] if len(values) == 1 else values)
        return result

    if unit == "word":
        result: List[PinyinValue] = []
        for token in analysis.tokens:
            if token.kind != "chinese":
                result.append(token.text)
                continue

            if not heteronym:
                result.append(" ".join(render_pronunciation(char.chosen, style) for char in token.chars if char.chosen))
                continue

            result.append(render_word_candidates(token, style))
        return result

    raise ValueError(f"Unsupported unit: {unit}")


def analysis_to_array(analysis: TextAnalysis, *, style: str = "mark") -> list[dict[str, object]]:
    rows = []
    for token in analysis.tokens:
        for char in token.chars:
            rendered = render_pronunciation(char.chosen, style) if char.chosen else ""
            rows.append(
                {
                    "char": char.char,
                    "pinyin": rendered,
                    "full_pinyin": rendered,
                    "is_punctuation": token.kind == "punctuation",
                    "is_chinese": char.is_chinese,
                }
            )
    return rows
