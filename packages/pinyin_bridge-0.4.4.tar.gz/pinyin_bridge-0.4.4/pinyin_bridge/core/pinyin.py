from __future__ import annotations

from pinyin_bridge.core.analyzer import analyze
from pinyin_bridge.core.formatter import pinyin_list


def pinyin(text: str, tone: str = "plain", mode: str = "normal"):
    analysis = analyze(text)
    if mode == "normal":
        return pinyin_list(analysis, style=tone, unit="char")
    if mode == "initial":
        return [char.chosen.initial if char.chosen else "" for token in analysis.tokens for char in token.chars]
    if mode == "final":
        return [char.chosen.final if char.chosen else "" for token in analysis.tokens for char in token.chars]
    raise ValueError(f"Unsupported mode: {mode}")

