from __future__ import annotations

from dataclasses import dataclass
from typing import List

import pypinyin

from pinyin_bridge.core import tokenizer
from pinyin_bridge.core.rules import parse_syllable, split_initial_final


@dataclass(frozen=True)
class Pronunciation:
    plain: str
    tone: int
    initial: str
    final: str
    source: str


@dataclass(frozen=True)
class CharAnalysis:
    char: str
    index: int
    chosen: Pronunciation | None
    candidates: list[Pronunciation]
    token_index: int
    is_chinese: bool


@dataclass(frozen=True)
class TokenAnalysis:
    text: str
    start: int
    end: int
    kind: str
    chars: list[CharAnalysis]


@dataclass(frozen=True)
class TextAnalysis:
    text: str
    tokens: list[TokenAnalysis]


def make_pronunciation(syllable: str, source: str) -> Pronunciation:
    plain, tone = parse_syllable(syllable)
    initial, final = split_initial_final(plain)
    return Pronunciation(plain=plain, tone=tone, initial=initial, final=final, source=source)


def pypinyin_groups(text: str, heteronym: bool) -> list[list[str]]:
    groups = pypinyin.pinyin(text, style=pypinyin.Style.TONE3, heteronym=heteronym)
    return [[item for item in group if item] or [""] for group in groups]


def token_groups(token_text: str, heteronym: bool) -> tuple[list[list[str]], str]:
    phrase_hit = tokenizer.lookup_phrase_pinyin(token_text)
    if phrase_hit:
        pinyin_text, source = phrase_hit
        pieces = pinyin_text.split()
        if len(pieces) == len(token_text):
            return [[piece] for piece in pieces], source
    return pypinyin_groups(token_text, heteronym), "pypinyin"


def analyze(text: str, *, segment: bool = True, heteronym: bool = False) -> TextAnalysis:
    if not text:
        return TextAnalysis(text=text, tokens=[])

    token_texts = tokenizer.segment(text) if segment else list(text)
    tokens: List[TokenAnalysis] = []
    cursor = 0
    char_index = 0

    for token_index, token_text in enumerate(token_texts):
        kind = tokenizer.token_kind(token_text)
        groups: list[list[str]] = []
        source = "passthrough"
        if kind == "chinese":
            groups, source = token_groups(token_text, heteronym)

        chars: list[CharAnalysis] = []
        for offset, char in enumerate(token_text):
            if kind == "chinese":
                candidates = [make_pronunciation(item, source) for item in groups[offset] if item]
                chosen = candidates[0] if candidates else None
            else:
                candidates = []
                chosen = None

            chars.append(
                CharAnalysis(
                    char=char,
                    index=char_index,
                    chosen=chosen,
                    candidates=candidates,
                    token_index=token_index,
                    is_chinese=kind == "chinese",
                )
            )
            char_index += 1

        tokens.append(
            TokenAnalysis(
                text=token_text,
                start=cursor,
                end=cursor + len(token_text),
                kind=kind,
                chars=chars,
            )
        )
        cursor += len(token_text)

    return TextAnalysis(text=text, tokens=tokens)
