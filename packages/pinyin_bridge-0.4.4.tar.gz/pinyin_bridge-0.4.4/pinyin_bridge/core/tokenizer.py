from __future__ import annotations

from functools import lru_cache
from typing import Dict, List, Optional, Tuple

from pinyin_bridge.data import db
from pinyin_bridge.data.seed_loader import load_seed_phrase_entries

_RUNTIME_PHRASES: Dict[str, str] = {}
_MAX_PHRASE_LEN = 10  # 预定义最大词长，避免循环计算
_phrase_entries_cache: Dict[str, Tuple[str, str]] | None = None


def warmup():
    """预加载所有词表到内存，加速首次调用"""
    global _phrase_entries_cache
    _phrase_entries_cache = _load_phrase_entries()
    return True


def set_phrase_dict(phrase_dict: Dict[str, str]):
    global _phrase_entries_cache
    _RUNTIME_PHRASES.clear()
    _RUNTIME_PHRASES.update(phrase_dict)
    _phrase_entries_cache = None


def _load_phrase_entries() -> Dict[str, Tuple[str, str]]:
    entries = dict(load_seed_phrase_entries())
    entries.update({text: (pinyin, "phrase_dict") for text, pinyin in _RUNTIME_PHRASES.items()})
    for item in db.get_db().get_all_words("user"):
        entries[item["text"]] = (item["pinyin"], "user_dict")
    return entries


def clear_phrase_cache():
    global _phrase_entries_cache
    _phrase_entries_cache = None


def phrase_entries() -> Dict[str, Tuple[str, str]]:
    global _phrase_entries_cache
    if _phrase_entries_cache is None:
        _phrase_entries_cache = _load_phrase_entries()
    return _phrase_entries_cache


def lookup_phrase_pinyin(text: str) -> Optional[Tuple[str, str]]:
    return phrase_entries().get(text)


def longest_phrase_match(text: str, start: int, entries: Dict[str, Tuple[str, str]], max_window: int) -> Optional[str]:
    upper = min(len(text), start + max_window)
    for end in range(upper, start, -1):
        piece = text[start:end]
        if piece in entries:
            return piece
    return None


def token_kind(token: str) -> str:
    if not token:
        return "mixed"
    if all("\u4e00" <= char <= "\u9fff" for char in token):
        return "chinese"
    if all(char.isdigit() for char in token):
        return "digit"
    if all(char.isascii() and char.isalpha() for char in token):
        return "latin"
    if all(not char.isalnum() and not ("\u4e00" <= char <= "\u9fff") for char in token):
        return "punctuation"
    return "mixed"


def segment(text: str) -> List[str]:
    if not text:
        return []

    entries = phrase_entries()
    result: List[str] = []
    index = 0
    
    # 预计算 max_window，避免每次循环调用 max()
    max_window = _MAX_PHRASE_LEN
    text_len = len(text)

    while index < len(text):
        current = text[index]
        if not ("\u4e00" <= current <= "\u9fff"):
            current_kind = token_kind(current)
            end = index + 1
            while end < len(text):
                next_char = text[end]
                if "\u4e00" <= next_char <= "\u9fff" or token_kind(next_char) != current_kind:
                    break
                end += 1

            result.append(text[index:end])
            index = end
            continue

        matched = longest_phrase_match(text, index, entries, max_window)

        if matched:
            result.append(matched)
            index += len(matched)
        else:
            end = index + 1
            while end < len(text):
                next_char = text[end]
                if not ("\u4e00" <= next_char <= "\u9fff"):
                    break
                if longest_phrase_match(text, end, entries, max_window):
                    break
                end += 1

            result.append(text[index:end])
            index = end

    return result
