from __future__ import annotations

from functools import lru_cache
from typing import Dict, List

from pypinyin.constants import PINYIN_DICT

from pinyin_bridge.core import tokenizer
from pinyin_bridge.core.analyzer import analyze
from pinyin_bridge.core.formatter import render_pronunciation
from pinyin_bridge.core.rules import MARK_TO_BASE_TONE, marked_syllable, parse_syllable

VALID_TONE_MODES = {"auto", "strict", "ignore"}
VALID_SCOPES = {"all", "char", "word"}


def query_parts(query: str, tone: str) -> tuple[str, int | None]:
    if tone not in VALID_TONE_MODES:
        raise ValueError(f"Unsupported tone mode: {tone}")

    plain, detected_tone = parse_syllable(query)
    has_explicit_tone = any(char.isdigit() or char in MARK_TO_BASE_TONE for char in query)
    if tone == "strict":
        return plain, detected_tone or 0
    if tone == "ignore":
        return plain, None
    return plain, detected_tone if has_explicit_tone else None


def matches(plain: str, tone: int, expected_plain: str, expected_tone: int | None) -> bool:
    if plain != expected_plain:
        return False
    if expected_tone is None:
        return True
    return tone == expected_tone


@lru_cache(maxsize=1)
def char_index() -> dict[str, list[dict[str, str]]]:
    index: dict[str, list[dict[str, str]]] = {}
    for codepoint, readings in PINYIN_DICT.items():
        seen: set[tuple[str, int]] = set()
        char = chr(codepoint)
        for syllable in readings.split(","):
            plain, detected_tone = parse_syllable(syllable)
            key = (plain, detected_tone)
            if not plain or key in seen:
                continue

            seen.add(key)
            index.setdefault(plain, []).append(
                {
                    "text": char,
                    "tone": str(detected_tone),
                    "pinyin": marked_syllable(plain, detected_tone),
                    "scope": "char",
                }
            )
    return index


@lru_cache(maxsize=1)
def word_entries() -> List[Dict[str, object]]:
    result = []
    for text in tokenizer.phrase_entries().keys():
        analysis = analyze(text)
        chars = [char for token in analysis.tokens for char in token.chars if char.chosen]
        if chars:
            result.append(
                {
                    "text": text,
                    "pronunciations": chars,
                    "pinyin": " ".join(render_pronunciation(char.chosen, "mark") for char in chars),
                    "scope": "word",
                }
            )
    return result


def clear_reverse_cache():
    word_entries.cache_clear()


def reverse(query: str, *, tone: str = "auto", scope: str = "all") -> List[Dict[str, str]]:
    if scope not in VALID_SCOPES:
        raise ValueError(f"Unsupported scope: {scope}")

    expected_plain, expected_tone = query_parts(query, tone)
    results: List[Dict[str, str]] = []

    if scope in {"char", "all"}:
        for item in char_index().get(expected_plain, []):
            if matches(expected_plain, int(item["tone"]), expected_plain, expected_tone):
                results.append({"text": item["text"], "pinyin": item["pinyin"], "scope": item["scope"]})

    if scope in {"word", "all"}:
        for item in word_entries():
            if any(matches(char.chosen.plain, char.chosen.tone, expected_plain, expected_tone) for char in item["pronunciations"]):
                results.append({"text": item["text"], "pinyin": item["pinyin"], "scope": item["scope"]})

    return results
