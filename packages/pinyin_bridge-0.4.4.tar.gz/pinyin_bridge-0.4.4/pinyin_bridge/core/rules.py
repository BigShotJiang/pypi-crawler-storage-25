from __future__ import annotations

INITIALS = (
    "zh", "ch", "sh",
    "b", "p", "m", "f", "d", "t", "n", "l",
    "g", "k", "h", "j", "q", "x", "r", "z", "c", "s", "y", "w",
)

INITIAL_CATEGORIES = {
    "双唇音": ["b", "p", "m"],
    "唇齿音": ["f"],
    "舌尖前音": ["z", "c", "s"],
    "舌尖中音": ["d", "t", "n", "l"],
    "舌尖后音": ["zh", "ch", "sh", "r"],
    "舌面前音": ["j", "q", "x"],
    "舌面后音": ["g", "k", "h"],
}

FINAL_CATEGORIES = {
    "舌面元音单韵母": ["a", "o", "e", "i", "u", "ü"],
    "卷舌单韵母": ["er"],
    "前响复韵母": ["ai", "ei", "ao", "ou"],
    "中响复韵母": ["iao", "ui", "uei", "uai"],
    "后响复韵母": ["ia", "ie", "uo", "ua", "üe"],
    "前鼻音韵母": ["an", "en", "in", "ün", "ian", "uan", "uen", "üan"],
    "后鼻音韵母": ["ang", "eng", "iang", "uang", "ing", "ueng", "ong", "iong"],
}

TONE_NAMES = {
    1: "阴平第一声",
    2: "阳平第二声",
    3: "上声第三声",
    4: "去声第四声",
}

TONE_MARKS = {
    "a": "āáǎà",
    "e": "ēéěè",
    "i": "īíǐì",
    "o": "ōóǒò",
    "u": "ūúǔù",
    "ü": "ǖǘǚǜ",
}

MARK_TO_BASE_TONE = {
    marked: (base, tone)
    for base, marks in TONE_MARKS.items()
    for tone, marked in enumerate(marks, start=1)
}


def normalize_plain(value: str) -> str:
    return value.lower().replace("u:", "ü").replace("v", "ü")


def parse_syllable(syllable: str) -> tuple[str, int]:
    value = normalize_plain(syllable.strip())
    tone = 0
    if value and value[-1].isdigit():
        tone = int(value[-1])
        value = value[:-1]
        if tone == 5:
            tone = 0

    rebuilt = []
    for char in value:
        mapped = MARK_TO_BASE_TONE.get(char)
        if mapped:
            base, detected = mapped
            rebuilt.append(base)
            tone = detected
        else:
            rebuilt.append(char)

    return "".join(rebuilt), tone


def split_initial_final(plain: str) -> tuple[str, str]:
    normalized = normalize_plain(plain)
    for initial in INITIALS:
        if normalized.startswith(initial):
            return initial, normalized[len(initial):]
    return "", normalized


def numbered_syllable(plain: str, tone: int) -> str:
    plain = normalize_plain(plain)
    return plain if tone in (0, 5) else f"{plain}{tone}"


def marked_syllable(plain: str, tone: int) -> str:
    plain = normalize_plain(plain)
    if tone in (0, 5):
        return plain

    target = tone_vowel_index(plain)
    if target is None:
        return plain

    vowel = plain[target]
    marked = TONE_MARKS[vowel][tone - 1]
    return plain[:target] + marked + plain[target + 1:]


def tone_vowel_index(plain: str) -> int | None:
    if "a" in plain:
        return plain.index("a")
    if "e" in plain:
        return plain.index("e")
    if "ou" in plain:
        return plain.index("o")
    if "iu" in plain:
        return plain.index("u")
    if "ui" in plain:
        return plain.index("i")
    for vowel in ("o", "i", "u", "ü"):
        if vowel in plain:
            return plain.rindex(vowel)
    return None
