"""Shared storage layer for multiprocess dictionary access.
Supports Redis for cross-process sharing, with fallback to embedded dict."""

from __future__ import annotations

import os
import threading
from typing import Any, Dict, List, Optional, Tuple

import redis

REDIS_URL_ENV = "PINYIN_BRIDGE_REDIS_URL"


class SharedDict:
    """Thread-safe shared dictionary with Redis backend and in-memory fallback.
    
    Examples:
        >>> # Auto-detect (default): use Redis if PINYIN_BRIDGE_REDIS_URL set, else memory
        >>> shared = SharedDict("pinyin_bridge:user")
        
        >>> # Force Redis explicitly
        >>> shared = SharedDict("pinyin_bridge:user", mode="redis")
        
        >>> # Force in-memory only (no Redis)
        >>> shared = SharedDict("pinyin_bridge:user", mode="memory")
        
        >>> # Basic operations
        >>> shared.set("中国", "zhong guo")
        >>> shared.get("中国")
        'zhong guo'
        >>> shared.delete("中国")
        
        >>> # Bulk operations
        >>> shared.bulk_set([("你好", "ni hao"), ("世界", "shi jie")])
        >>> shared.get_all()
        {'你好': 'ni hao', '世界': 'shi jie'}
        
        >>> # Check backend
        >>> shared.is_using_redis
        True  # or False
        
        >>> # Environment variable
        >>> # PINYIN_BRIDGE_REDIS_URL=redis://localhost:6379 python app.py
    """

    def __init__(self, key_prefix: str = "pinyin_bridge", mode: Optional[str] = None):
        self._key_prefix = key_prefix
        self._local: Dict[str, str] = {}
        self._redis: Optional[redis.Redis] = None
        self._use_redis = False
        self._lock = threading.RLock()
        self._init_backend(mode)

    def _init_backend(self, mode: Optional[str] = None):
        if mode == "memory":
            self._use_redis = False
            return
        
        redis_url = os.environ.get(REDIS_URL_ENV)
        if mode == "redis" or (mode is None and redis_url):
            try:
                url = redis_url or "redis://localhost:6379"
                self._redis = redis.from_url(url, decode_responses=True)
                self._redis.ping()
                self._use_redis = True
            except Exception:
                self._redis = None
                self._use_redis = False

    def _get_key(self, key: str) -> str:
        return f"{self._key_prefix}:{key}"

    def get(self, key: str) -> Optional[str]:
        with self._lock:
            if self._use_redis and self._redis:
                return self._redis.hget(self._get_key("dict"), key)
            return self._local.get(key)

    def set(self, key: str, value: str) -> None:
        with self._lock:
            if self._use_redis and self._redis:
                self._redis.hset(self._get_key("dict"), key, value)
            self._local[key] = value

    def delete(self, key: str) -> None:
        with self._lock:
            if self._use_redis and self._redis:
                self._redis.hdel(self._get_key("dict"), key)
            self._local.pop(key, None)

    def get_all(self) -> Dict[str, str]:
        with self._lock:
            if self._use_redis and self._redis:
                return self._redis.hgetall(self._get_key("dict"))
            return dict(self._local)

    def bulk_set(self, items: List[Tuple[str, str]]) -> None:
        with self._lock:
            if self._use_redis and self._redis:
                if items:
                    self._redis.hset(
                        self._get_key("dict"),
                        mapping={k: v for k, v in items}
                    )
            self._local.update(items)

    def clear(self) -> None:
        with self._lock:
            if self._use_redis and self._redis:
                self._redis.delete(self._get_key("dict"))
            self._local.clear()

    @property
    def is_using_redis(self) -> bool:
        return self._use_redis


_shared_user_dict: Optional[SharedDict] = None
_shared_seed_dict: Optional[SharedDict] = None


def get_shared_user_dict() -> SharedDict:
    global _shared_user_dict
    if _shared_user_dict is None:
        _shared_user_dict = SharedDict("pinyin_bridge:user")
    return _shared_user_dict


def get_shared_seed_dict() -> SharedDict:
    global _shared_seed_dict
    if _shared_seed_dict is None:
        _shared_seed_dict = SharedDict("pinyin_bridge:seed")
    return _shared_seed_dict
