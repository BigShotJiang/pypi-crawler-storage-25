from __future__ import annotations

import csv
from dataclasses import dataclass
from importlib import resources

from pinyin_bridge.data._pinyin_util import default_phrase_pinyin, normalize_pinyin_text
from pinyin_bridge.data.seed_loader import load_seed_entries

CANDIDATE_FILE = "review_candidates.tsv"
EXPECTED_HEADERS = ("text", "category", "source_ref", "notes")


@dataclass(frozen=True)
class ReviewCandidate:
    text: str
    category: str
    source_ref: str
    notes: str


@dataclass(frozen=True)
class CandidateAuditRow:
    text: str
    category: str
    source_ref: str
    notes: str
    pypinyin: str
    current_seed: str
    status: str


# Shared implementations provided above. Local aliases for internal use.
_dph = default_phrase_pinyin


def load_review_candidates() -> tuple[ReviewCandidate, ...]:
    package_root = resources.files("pinyin_bridge.data")
    path = package_root.joinpath("seed", CANDIDATE_FILE)
    rows: list[ReviewCandidate] = []
    seen: set[str] = set()
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        headers = tuple(reader.fieldnames or ())
        if headers != EXPECTED_HEADERS:
            raise ValueError(f"{CANDIDATE_FILE}: expected headers {EXPECTED_HEADERS}, got {headers}")

        for line_number, row in enumerate(reader, start=2):
            text = (row["text"] or "").strip()
            category = (row["category"] or "").strip()
            source_ref = (row["source_ref"] or "").strip()
            notes = (row["notes"] or "").strip()
            if not text:
                raise ValueError(f"{CANDIDATE_FILE}:{line_number}: text must not be empty")
            if not category:
                raise ValueError(f"{CANDIDATE_FILE}:{line_number}: category must not be empty")
            if not source_ref:
                raise ValueError(f"{CANDIDATE_FILE}:{line_number}: source_ref must not be empty")
            if text in seen:
                raise ValueError(f"{CANDIDATE_FILE}:{line_number}: duplicate candidate {text!r}")
            seen.add(text)
            rows.append(ReviewCandidate(text=text, category=category, source_ref=source_ref, notes=notes))

    return tuple(rows)


def audit_review_candidates() -> tuple[CandidateAuditRow, ...]:
    seed_entries = {entry.text: entry for entry in load_seed_entries()}
    rows: list[CandidateAuditRow] = []
    for candidate in load_review_candidates():
        seed_entry = seed_entries.get(candidate.text)
        current_seed = seed_entry.pinyin if seed_entry else ""
        default_pinyin = _dph(candidate.text)
        if not seed_entry:
            status = "missing"
        elif seed_entry.pinyin == default_pinyin:
            status = "covered"
        else:
            status = "override"
        rows.append(
            CandidateAuditRow(
                text=candidate.text,
                category=candidate.category,
                source_ref=candidate.source_ref,
                notes=candidate.notes,
                pypinyin=default_pinyin,
                current_seed=current_seed,
                status=status,
            )
        )
    return tuple(rows)

