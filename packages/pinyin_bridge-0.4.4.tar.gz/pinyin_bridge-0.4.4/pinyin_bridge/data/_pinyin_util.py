"""Internal utilities for pinyin normalization and default lookup."""

from pypinyin import Style, pinyin as pypinyin

from pinyin_bridge.core.rules import marked_syllable, parse_syllable


def normalize_pinyin_text(text: str) -> str:
    """Normalize a space-separated pinyin string to marked tone format."""
    syllables = text.split()
    if not syllables:
        raise ValueError("Pinyin value must contain at least one syllable")
    return " ".join(marked_syllable(*parse_syllable(syl)) for syl in syllables)


def default_phrase_pinyin(text: str) -> str:
    """Get the default pinyin for text, computed via pypinyin."""
    groups = pypinyin(text, style=Style.TONE3, heteronym=False)
    return normalize_pinyin_text(" ".join(group[0] for group in groups if group and group[0]))
