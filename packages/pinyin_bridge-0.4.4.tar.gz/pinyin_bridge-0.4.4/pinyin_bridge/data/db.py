import os
import sqlite3
import tempfile
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from pinyin_bridge.data.shared_store import get_shared_user_dict, get_shared_seed_dict

DB_PATH_ENV_VAR = "PINYIN_BRIDGE_DB_PATH"
DEFAULT_DB_PATH = Path(__file__).parent / "dict.db"
FALLBACK_DB_PATH = Path(tempfile.gettempdir()) / "pinyin_bridge" / "dict.db"
SOURCE_TABLES = {
    "user": "user_dict",
    "dict": "dict",
}


def resolve_db_path(db_path: Optional[str] = None) -> Path:
    if db_path is not None:
        return Path(db_path).expanduser()

    env_path = os.environ.get(DB_PATH_ENV_VAR)
    if env_path:
        return Path(env_path).expanduser()

    return DEFAULT_DB_PATH


def uses_default_db_path(db_path: Optional[str] = None) -> bool:
    return db_path is None and DB_PATH_ENV_VAR not in os.environ


def resolve_source_table(source: str) -> str:
    table = SOURCE_TABLES.get(source)
    if table is None:
        raise ValueError(f"Unsupported source: {source}")
    return table


class Database:
    DEFAULT_DB_PATH = DEFAULT_DB_PATH
    
    def __init__(self, db_path: Optional[str] = None):
        self.requested_db_path = resolve_db_path(db_path)
        self.db_path = self.requested_db_path
        self._allow_fallback = uses_default_db_path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection = None  # type: ignore
        self._query_cache: Dict[str, str] = {}  # 查询缓存
        self._init_db()
        if self._allow_fallback and not self._is_writable():
            self._switch_to_fallback_path()

    def _init_db(self):
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        
        cursor = self._conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS dict (
                text TEXT PRIMARY KEY,
                pinyin TEXT NOT NULL,
                category TEXT DEFAULT 'word'
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_dict (
                text TEXT PRIMARY KEY,
                pinyin TEXT NOT NULL
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS phonetic_cache (
                char TEXT PRIMARY KEY,
                initial TEXT,
                final TEXT,
                tone INTEGER
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pinyin_cache (
                text TEXT PRIMARY KEY,
                result TEXT NOT NULL,
                tone_mode TEXT,
                updated_at TIMESTAMP
            )
        ''')
        
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_dict_text ON dict(text)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_user_dict_text ON user_dict(text)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_phonetic_char ON phonetic_cache(char)')
        
        self._conn.commit()

    def _is_writable(self) -> bool:
        cursor = self._conn.cursor()
        try:
            cursor.execute("BEGIN IMMEDIATE")
            self._conn.rollback()
            return True
        except sqlite3.OperationalError:
            self._conn.rollback()
            return False

    def _switch_to_fallback_path(self):
        self.close()
        self.db_path = FALLBACK_DB_PATH
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _run_with_write_fallback(self, operation):
        try:
            return operation()
        except sqlite3.OperationalError as exc:
            if not self._allow_fallback or "readonly" not in str(exc).lower() or self.db_path == FALLBACK_DB_PATH:
                raise

            self._switch_to_fallback_path()
            return operation()

    def get_pinyin(self, text: str) -> Optional[str]:
        # 检查查询缓存
        cached = self._query_cache.get(text)
        if cached is not None:
            return cached
        
        shared_user = get_shared_user_dict()
        result = shared_user.get(text)
        if result is not None:
            self._query_cache[text] = result
            return result
        
        cursor = self._conn.cursor()
        
        cursor.execute('SELECT pinyin FROM user_dict WHERE text = ?', (text,))
        row = cursor.fetchone()
        if row:
            return row['pinyin']
        
        cursor.execute('SELECT pinyin FROM dict WHERE text = ?', (text,))
        row = cursor.fetchone()
        if row:
            return row['pinyin']
        
        return None

    def add_words(self, words: List[Tuple[str, str]], source: str = 'user'):
        table = resolve_source_table(source)

        def operation():
            cursor = self._conn.cursor()
            cursor.executemany(
                f'''
                    INSERT OR REPLACE INTO {table} (text, pinyin)
                    VALUES (?, ?)
                ''',
                words,
            )
            self._conn.commit()
            if source == 'user':
                shared = get_shared_user_dict()
                for text, pinyin in words:
                    shared.set(text, pinyin)

        self._run_with_write_fallback(operation)

    def add_word(self, text: str, pinyin: str, source: str = 'user'):
        self.add_words([(text, pinyin)], source)

    def delete_word(self, text: str, source: str = 'user'):
        table = resolve_source_table(source)

        def operation():
            cursor = self._conn.cursor()
            cursor.execute(f'DELETE FROM {table} WHERE text = ?', (text,))
            self._conn.commit()
            if source == 'user':
                shared = get_shared_user_dict()
                shared.delete(text)

        self._run_with_write_fallback(operation)

    def clear_user_dict(self):
        def operation():
            cursor = self._conn.cursor()
            cursor.execute('DELETE FROM user_dict')
            self._conn.commit()
            shared = get_shared_user_dict()
            shared.clear()

        self._run_with_write_fallback(operation)

    def get_phonetic_cache(self, char: str) -> Optional[Dict]:
        cursor = self._conn.cursor()
        cursor.execute(
            'SELECT initial, final, tone FROM phonetic_cache WHERE char = ?',
            (char,)
        )
        row = cursor.fetchone()
        if row:
            return dict(row)
        return None

    def set_phonetic_cache(self, char: str, initial: str, final: str, tone: int):
        def operation():
            cursor = self._conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO phonetic_cache (char, initial, final, tone)
                VALUES (?, ?, ?, ?)
            ''', (char, initial, final, tone))
            self._conn.commit()

        self._run_with_write_fallback(operation)

    def get_pinyin_cache(self, text: str, tone_mode: str) -> Optional[str]:
        cursor = self._conn.cursor()
        cursor.execute(
            'SELECT result FROM pinyin_cache WHERE text = ? AND tone_mode = ?',
            (text, tone_mode)
        )
        row = cursor.fetchone()
        return row['result'] if row else None

    def set_pinyin_cache(self, text: str, result: str, tone_mode: str):
        def operation():
            cursor = self._conn.cursor()
            cursor.execute('''
                INSERT OR REPLACE INTO pinyin_cache (text, result, tone_mode, updated_at)
                VALUES (?, ?, ?, ?)
            ''', (text, result, tone_mode, datetime.now().isoformat()))
            self._conn.commit()

        self._run_with_write_fallback(operation)

    def get_all_words(self, source: str = 'user') -> List[Dict[str, str]]:
        cursor = self._conn.cursor()
        
        table = resolve_source_table(source)
        cursor.execute(f'SELECT text, pinyin FROM {table}')
        
        return [{'text': row['text'], 'pinyin': row['pinyin']} for row in cursor.fetchall()]

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None  # type: ignore


_db: Optional[Database] = None


def get_db(db_path: Optional[str] = None) -> Database:
    global _db
    resolved_path = resolve_db_path(db_path)

    if _db is None or _db.requested_db_path != resolved_path:
        reset_db()
        _db = Database(db_path)

    return _db


def reset_db(db_path: Optional[str] = None) -> Optional[Database]:
    global _db
    if _db is not None:
        _db.close()
        _db = None

    if db_path is None:
        return None

    return get_db(db_path)


def get_pinyin(text: str) -> Optional[str]:
    return get_db().get_pinyin(text)


def add_words(words: List[Tuple[str, str]], source: str = 'user'):
    get_db().add_words(words, source)


def add_word(text: str, pinyin: str, source: str = 'user'):
    get_db().add_word(text, pinyin, source)


def delete_word(text: str, source: str = 'user'):
    get_db().delete_word(text, source)


def clear_user_dict():
    get_db().clear_user_dict()
