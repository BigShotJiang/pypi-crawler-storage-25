"""Seed data loader - loads from SQLite database for performance."""

from __future__ import annotations

import os
import sqlite3
from functools import lru_cache
from pathlib import Path


def _get_db_path() -> Path:
    env_path = os.environ.get("PINYIN_BRIDGE_DB_PATH")
    if env_path:
        return Path(env_path).expanduser()
    return Path(__file__).parent / "dict.db"


@lru_cache(maxsize=1)
def load_seed_phrase_entries() -> dict[str, tuple[str, str]]:
    """Load entries directly from SQLite database."""
    try:
        db_path = _get_db_path()
        if db_path.exists():
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            cursor.execute("SELECT text, pinyin FROM dict")
            result = {row["text"]: (row["pinyin"], "db") for row in cursor.fetchall()}
            conn.close()
            return result
    except Exception:
        pass
    return {}


def clear_seed_cache():
    load_seed_phrase_entries.cache_clear()