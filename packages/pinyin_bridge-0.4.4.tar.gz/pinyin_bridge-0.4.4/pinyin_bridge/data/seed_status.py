from __future__ import annotations

import csv
from collections import Counter
from dataclasses import dataclass
from importlib import resources

from pinyin_bridge.data.review_candidates import audit_review_candidates
from pinyin_bridge.data.seed_loader import EXPECTED_HEADERS, SEED_FILES, load_seed_entries


@dataclass(frozen=True)
class SeedFileStatus:
    filename: str
    raw_rows: int
    active_rows: int
    review_counts: dict[str, int]
    category_counts: dict[str, int]


@dataclass(frozen=True)
class SeedStatusReport:
    seed_file_count: int
    raw_seed_rows: int
    active_seed_rows: int
    override_rows: int
    active_review_counts: dict[str, int]
    active_category_counts: dict[str, int]
    active_source_counts: dict[str, int]
    file_statuses: tuple[SeedFileStatus, ...]
    candidate_total: int
    candidate_status_counts: dict[str, int]
    candidate_category_counts: dict[str, int]


def _sorted_counts(counter: Counter[str]) -> dict[str, int]:
    return dict(sorted(counter.items()))


def _read_seed_rows(filename: str) -> list[dict[str, str]]:
    package_root = resources.files("pinyin_bridge.data")
    path = package_root.joinpath("seed", filename)
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        headers = tuple(reader.fieldnames or ())
        if headers != EXPECTED_HEADERS:
            raise ValueError(f"{filename}: expected headers {EXPECTED_HEADERS}, got {headers}")
        return list(reader)


def build_seed_status_report() -> SeedStatusReport:
    entries = load_seed_entries()
    active_by_file = Counter(entry.filename for entry in entries)
    file_statuses: list[SeedFileStatus] = []
    raw_seed_rows = 0
    for filename in SEED_FILES:
        rows = _read_seed_rows(filename)
        raw_seed_rows += len(rows)
        file_statuses.append(
            SeedFileStatus(
                filename=filename,
                raw_rows=len(rows),
                active_rows=active_by_file.get(filename, 0),
                review_counts=_sorted_counts(Counter((row["review_status"] or "").strip() for row in rows)),
                category_counts=_sorted_counts(Counter((row["category"] or "").strip() for row in rows)),
            )
        )

    candidates = audit_review_candidates()
    return SeedStatusReport(
        seed_file_count=len(SEED_FILES),
        raw_seed_rows=raw_seed_rows,
        active_seed_rows=len(entries),
        override_rows=sum(1 for entry in entries if entry.pinyin != entry.default_pinyin),
        active_review_counts=_sorted_counts(Counter(entry.review_status for entry in entries)),
        active_category_counts=_sorted_counts(Counter(entry.category for entry in entries)),
        active_source_counts=_sorted_counts(Counter(entry.source for entry in entries)),
        file_statuses=tuple(file_statuses),
        candidate_total=len(candidates),
        candidate_status_counts=_sorted_counts(Counter(row.status for row in candidates)),
        candidate_category_counts=_sorted_counts(Counter(row.category for row in candidates)),
    )


def _format_counts(counts: dict[str, int]) -> str:
    if not counts:
        return "-"
    return ", ".join(f"{name}={count}" for name, count in counts.items())


def render_seed_status_report(report: SeedStatusReport) -> str:
    lines = [
        "Seed Lexicon Status",
        f"seed_files: {report.seed_file_count}",
        f"raw_seed_rows: {report.raw_seed_rows}",
        f"active_seed_entries: {report.active_seed_rows}",
        f"manual_overrides: {report.override_rows}",
        f"review_candidates: {report.candidate_total}",
        "",
        "Seed Files",
    ]
    for status in report.file_statuses:
        lines.append(
            f"- {status.filename}: raw={status.raw_rows}, active={status.active_rows}, "
            f"review[{_format_counts(status.review_counts)}], category[{_format_counts(status.category_counts)}]"
        )

    lines.extend(
        [
            "",
            "Active Entries By Review Status",
            f"- {_format_counts(report.active_review_counts)}",
            "",
            "Active Entries By Category",
            f"- {_format_counts(report.active_category_counts)}",
            "",
            "Active Entries By Source",
            f"- {_format_counts(report.active_source_counts)}",
            "",
            "Review Candidates By Status",
            f"- {_format_counts(report.candidate_status_counts)}",
            "",
            "Review Candidates By Category",
            f"- {_format_counts(report.candidate_category_counts)}",
        ]
    )
    return "\n".join(lines)
