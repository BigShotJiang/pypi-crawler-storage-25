from __future__ import annotations

from functools import lru_cache
from typing import Any, Dict, List, Union

from pinyin_bridge.core.analyzer import TextAnalysis, analyze as analyze_text
from pinyin_bridge.core.classifier import classify as classify_text
from pinyin_bridge.core.formatter import PinyinValue, pinyin_list
from pinyin_bridge.core.reverse import clear_reverse_cache, reverse as reverse_text
from pinyin_bridge.core import tokenizer
from pinyin_bridge.data import db

__version__ = "0.4.2"

_result_cache: Dict[str, List[PinyinValue]] = {}


def _invalidate_runtime_caches():
    tokenizer.clear_phrase_cache()
    clear_reverse_cache()
    _result_cache.clear()


@lru_cache(maxsize=4096)
def _pinyin_cached(text: str, style: str, unit: str, segment: bool, heteronym: bool) -> List[PinyinValue]:
    return pinyin_list(
        analyze_text(text, segment=segment, heteronym=heteronym),
        style=style,
        unit=unit,
        heteronym=heteronym,
    )


def analyze(text: str, *, segment: bool = True, heteronym: bool = False) -> TextAnalysis:
    return analyze_text(text, segment=segment, heteronym=heteronym)


def pinyin(
    text: str,
    *,
    style: str = "plain",
    unit: str = "char",
    segment: bool = True,
    heteronym: bool = False,
) -> List[PinyinValue]:
    return _pinyin_cached(text, style, unit, segment, heteronym)


def classify(
    text: Union[str, List[str]],
    *,
    kind: str = "all",
    segment: bool = True,
    output_format: str = "dict",
) -> Union[Dict[str, Any], List[Dict[str, Any]]]:
    if isinstance(text, list):
        text = "".join(text)
    result = classify_text(text, kind=kind, segment=segment)
    if output_format == "list" and kind == "all" and isinstance(result, dict):
        return [
            {"name": "声母", "detail": result["声母"]},
            {"name": "韵母", "detail": result["韵母"]},
            {"name": "声调", "detail": result["声调"]},
        ]
    return result


def segment(text: str) -> List[str]:
    return tokenizer.segment(text)


def reverse(query: str, *, tone: str = "auto", scope: str = "all") -> List[Dict[str, str]]:
    return reverse_text(query, tone=tone, scope=scope)


def warmup():
    """预热库，加载所有数据到内存，加速首次调用"""
    return tokenizer.warmup()


def add_words(words, source: str = "user"):
    if isinstance(words, dict):
        words = list(words.items())
    db.add_words(words, source)
    _invalidate_runtime_caches()


def add_word(text: str, pinyin: str, source: str = "user"):
    db.add_word(text, pinyin, source)
    _invalidate_runtime_caches()


def delete_word(text: str, source: str = "user"):
    db.delete_word(text, source)
    _invalidate_runtime_caches()


def list_words(source: str = "user") -> List[Dict[str, str]]:
    return db.get_db().get_all_words(source)


def clear_words():
    db.clear_user_dict()
    _invalidate_runtime_caches()


__all__ = [
    "__version__",
    "add_word",
    "add_words",
    "analyze",
    "classify",
    "clear_words",
    "delete_word",
    "list_words",
    "pinyin",
    "reverse",
    "segment",
]
