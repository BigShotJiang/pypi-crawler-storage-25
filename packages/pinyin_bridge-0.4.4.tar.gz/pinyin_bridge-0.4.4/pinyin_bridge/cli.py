from __future__ import annotations

import argparse
import json

import pinyin_bridge


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Pinyin-Bridge: 汉字拼音转换工具", prog="pinyin-bridge")
    parser.add_argument("text", nargs="?", help="要处理的文本或反查拼音")
    parser.add_argument("--style", "--tone", dest="style", choices=["plain", "num", "mark"], default="plain")
    parser.add_argument("--unit", choices=["char", "word"], default="char")
    parser.add_argument("--classify", nargs="?", const="all", choices=["initial", "final", "tone", "all"])
    parser.add_argument("--reverse", action="store_true")
    parser.add_argument("-f", "--file", type=str, help="输入文件 (每行一个文本)")
    parser.add_argument("-o", "--output", type=str, help="输出文件")
    parser.add_argument("--json", action="store_true", help="JSON 格式输出")
    parser.add_argument("--add", type=str, help="添加词语 (格式: 词语:拼音)")
    return parser


def load_inputs(args) -> list[str]:
    if args.file:
        with open(args.file, "r", encoding="utf-8") as handle:
            return [line.strip() for line in handle if line.strip()]
    if args.text:
        return [args.text]
    return []


def render_payload(args, payload):
    if args.json:
        return json.dumps(payload, ensure_ascii=False, indent=2)
    if args.classify or args.reverse:
        if len(payload) == 1:
            return json.dumps(payload[0]["result"], ensure_ascii=False, indent=2)
        return json.dumps(payload, ensure_ascii=False, indent=2)
    return "\n".join(" ".join(item["result"]) for item in payload)


def main():
    parser = build_parser()
    args = parser.parse_args()

    if args.add:
        text, pinyin = args.add.split(":", 1)
        pinyin_bridge.add_word(text.strip(), pinyin.strip())
        print(f"已添加: {text.strip()} -> {pinyin.strip()}")
        return

    texts = load_inputs(args)
    if not texts:
        parser.print_help()
        return

    payload = []
    for text in texts:
        if args.reverse:
            result = pinyin_bridge.reverse(text)
        elif args.classify:
            result = pinyin_bridge.classify(text, kind=args.classify)
        else:
            result = pinyin_bridge.pinyin(text, style=args.style, unit=args.unit)
        payload.append({"text": text, "result": result})

    output = render_payload(args, payload)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            handle.write(output)
    else:
        print(output)


if __name__ == "__main__":
    main()
