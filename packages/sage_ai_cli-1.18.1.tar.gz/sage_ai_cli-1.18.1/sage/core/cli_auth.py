"""CLI authentication — Firebase email/password, token storage, auto-refresh."""

from __future__ import annotations

import json
import os
import stat
import time
from pathlib import Path
from typing import Optional

import httpx

FIREBASE_API_KEY = os.environ.get(
    "VITE_FIREBASE_API_KEY",
    "AIzaSyAX_tX1pr822FLr_jTBxwmUF-w-cUZ-UAE",  # public web key
)
IDENTITY_TOOLKIT = "https://identitytoolkit.googleapis.com/v1"
SECURE_TOKEN_URL = "https://securetoken.googleapis.com/v1/token"

AUTH_DIR = Path.home() / ".sage"
AUTH_FILE = AUTH_DIR / "auth.json"

SAGE_API_BASE = os.environ.get("SAGE_API_BASE", "https://sage-ai-uoxy6o2jha-uc.a.run.app")


# ── Token storage ─────────────────────────────────────────────────────────────

def save_auth(data: dict) -> None:
    AUTH_DIR.mkdir(parents=True, exist_ok=True)
    AUTH_FILE.write_text(json.dumps(data, indent=2))
    AUTH_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)  # 600


def load_auth() -> dict | None:
    if not AUTH_FILE.exists():
        return None
    try:
        return json.loads(AUTH_FILE.read_text())
    except Exception:
        return None


def clear_auth() -> None:
    if AUTH_FILE.exists():
        AUTH_FILE.unlink()


# ── Token operations ──────────────────────────────────────────────────────────

def _is_expired(auth: dict, buffer_seconds: int = 300) -> bool:
    expires_at = auth.get("expires_at", 0)
    return time.time() >= (expires_at - buffer_seconds)


def _refresh_token(auth: dict) -> dict:
    refresh = auth.get("refresh_token", "")
    if not refresh:
        raise RuntimeError("No refresh token available. Please run: sage login")
    r = httpx.post(
        f"{SECURE_TOKEN_URL}?key={FIREBASE_API_KEY}",
        json={"grant_type": "refresh_token", "refresh_token": refresh},
        timeout=15,
    )
    r.raise_for_status()
    data = r.json()
    auth["id_token"] = data["id_token"]
    auth["refresh_token"] = data["refresh_token"]
    auth["expires_at"] = time.time() + int(data.get("expires_in", 3600))
    save_auth(auth)
    return auth


def get_valid_token() -> str:
    """Return a valid Firebase ID token, refreshing if needed. Raises if not logged in."""
    auth = load_auth()
    if auth is None:
        raise RuntimeError(
            "Not logged in. Run: sage login\n"
            "Server models and CLI require a paid plan. Browser AI is always free."
        )
    if _is_expired(auth):
        auth = _refresh_token(auth)
    return auth["id_token"]


def get_auth_headers() -> dict:
    """Return Authorization + X-CLI headers for backend requests."""
    token = get_valid_token()
    return {"Authorization": f"Bearer {token}", "X-CLI": "true"}


# ── Login / logout ────────────────────────────────────────────────────────────

def login(email: str, password: str) -> dict:
    """Sign in with email/password and store the token."""
    r = httpx.post(
        f"{IDENTITY_TOOLKIT}/accounts:signInWithPassword?key={FIREBASE_API_KEY}",
        json={"email": email, "password": password, "returnSecureToken": True},
        timeout=15,
    )
    if not r.is_success:
        err = r.json().get("error", {}).get("message", "Unknown error")
        msg_map = {
            "EMAIL_NOT_FOUND": "No account found with this email.",
            "INVALID_PASSWORD": "Incorrect password.",
            "INVALID_LOGIN_CREDENTIALS": "Incorrect email or password.",
            "USER_DISABLED": "Account disabled.",
            "TOO_MANY_ATTEMPTS_TRY_LATER": "Too many attempts. Try again later.",
        }
        raise RuntimeError(msg_map.get(err, err))

    data = r.json()
    auth = {
        "uid": data["localId"],
        "email": data["email"],
        "id_token": data["idToken"],
        "refresh_token": data["refreshToken"],
        "expires_at": time.time() + int(data.get("expiresIn", 3600)),
    }

    # Verify with backend and get tier
    try:
        res = httpx.post(
            f"{SAGE_API_BASE}/auth/verify",
            json={"token": auth["id_token"]},
            timeout=10,
        )
        if res.is_success:
            info = res.json()
            auth["tier"] = info.get("tier", "free")
    except Exception:
        auth["tier"] = "unknown"

    save_auth(auth)
    return auth


def logout() -> None:
    clear_auth()


def whoami() -> dict | None:
    auth = load_auth()
    if auth is None:
        return None
    if _is_expired(auth):
        try:
            auth = _refresh_token(auth)
        except Exception:
            return None
    return {"email": auth.get("email"), "tier": auth.get("tier", "unknown")}


def check_cli_access() -> None:
    """Raise RuntimeError if user is not logged in or on free tier."""
    auth = load_auth()
    if auth is None:
        raise RuntimeError(
            "CLI requires a paid SAGE account.\n"
            "  1. Sign up at https://sage-ai-uoxy6o2jha-uc.a.run.app\n"
            "  2. Subscribe to Starter or higher ($8/mo)\n"
            "  3. Run: sage login\n"
            "Browser AI at the website is always free."
        )
    tier = auth.get("tier", "free")
    if tier == "free":
        raise RuntimeError(
            "Your account is on the Free plan — CLI requires Starter or higher.\n"
            "Upgrade at: https://sage-ai-uoxy6o2jha-uc.a.run.app (Billing tab)\n"
            "Browser AI at the website is always free."
        )
