"""
DBSpendGuard — Persistent, ACID-compliant SpendGuard backed by Postgres.

Every critical money operation happens inside a single SQL transaction
with SELECT ... FOR UPDATE to prevent race conditions.

Drop-in replacement for InMemorySpendGuard via the SpendGuardPort protocol.
"""
from __future__ import annotations

import uuid
from typing import Optional, Tuple

from core.payments.db import get_db_connection


class DBSpendGuard:
    """
    Atomic spend-guard that uses Postgres rows as the source of truth.

    Contract:
      pre_authorize  →  deducts from balance, creates hold
      capture_usage  →  marks portion of hold as captured
      finalize_hold  →  refunds uncaptured portion, closes hold
    """

    # ── pre_authorize ────────────────────────────────────────────
    def pre_authorize(
        self, tenant_id: str, estimated_cost_micro: int
    ) -> Tuple[bool, Optional[str]]:
        hold_id = str(uuid.uuid4())

        with get_db_connection() as conn:
            with conn:                              # TX boundary
                cur = conn.cursor()

                # Lock the account row
                cur.execute(
                    "SELECT balance_micro FROM accounts "
                    "WHERE tenant_id = %s FOR UPDATE",
                    (tenant_id,),
                )
                row = cur.fetchone()
                if not row:
                    return False, None

                balance = row[0]
                if balance < estimated_cost_micro:
                    return False, None

                # Deduct
                cur.execute(
                    "UPDATE accounts SET balance_micro = balance_micro - %s "
                    "WHERE tenant_id = %s",
                    (estimated_cost_micro, tenant_id),
                )

                # Create hold
                cur.execute(
                    "INSERT INTO holds (hold_id, tenant_id, amount_micro, status) "
                    "VALUES (%s, %s, %s, 'active')",
                    (hold_id, tenant_id, estimated_cost_micro),
                )

        return True, hold_id

    # ── capture_usage ────────────────────────────────────────────
    def capture_usage(self, hold_id: str, amount_micro: int) -> None:
        with get_db_connection() as conn:
            with conn:
                cur = conn.cursor()

                cur.execute(
                    "SELECT amount_micro, captured_micro FROM holds "
                    "WHERE hold_id = %s FOR UPDATE",
                    (hold_id,),
                )
                row = cur.fetchone()
                if not row:
                    raise Exception("HOLD_NOT_FOUND")

                total, captured = row
                new_captured = captured + amount_micro
                if new_captured > total:
                    raise Exception("OVER_CAPTURE")

                cur.execute(
                    "UPDATE holds SET captured_micro = %s WHERE hold_id = %s",
                    (new_captured, hold_id),
                )

    # ── finalize_hold ────────────────────────────────────────────
    def finalize_hold(self, hold_id: str) -> None:
        with get_db_connection() as conn:
            with conn:
                cur = conn.cursor()

                cur.execute(
                    "SELECT tenant_id, amount_micro, captured_micro "
                    "FROM holds WHERE hold_id = %s FOR UPDATE",
                    (hold_id,),
                )
                row = cur.fetchone()
                if not row:
                    return

                tenant_id, total, captured = row
                refund = total - captured

                if refund > 0:
                    cur.execute(
                        "UPDATE accounts SET balance_micro = balance_micro + %s "
                        "WHERE tenant_id = %s",
                        (refund, tenant_id),
                    )

                cur.execute(
                    "UPDATE holds SET status = 'finalized' WHERE hold_id = %s",
                    (hold_id,),
                )
