"""
Postgres connection pool for Kernell economic layer.

Uses psycopg2 with a SimpleConnectionPool to avoid
creating a new connection per request while keeping
thread-safety via the pool's getconn/putconn contract.
"""
from __future__ import annotations

import os
from contextlib import contextmanager

import psycopg2
from psycopg2 import pool as pg_pool

_DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://postgres:kernell@127.0.0.1:5432/kernell"
)

_pool: pg_pool.SimpleConnectionPool | None = None


def _get_pool() -> pg_pool.SimpleConnectionPool:
    global _pool
    if _pool is None or _pool.closed:
        _pool = pg_pool.SimpleConnectionPool(
            minconn=2,
            maxconn=20,
            dsn=_DATABASE_URL,
        )
    return _pool


@contextmanager
def get_db_connection():
    """
    Context manager that checks out a connection from the pool,
    yields it, and returns it when done.

    Usage:
        with get_db_connection() as conn:
            with conn:  # <-- this is the TX boundary
                cur = conn.cursor()
                ...
    """
    p = _get_pool()
    conn = p.getconn()
    try:
        yield conn
    finally:
        p.putconn(conn)


def close_pool():
    global _pool
    if _pool and not _pool.closed:
        _pool.closeall()
        _pool = None
