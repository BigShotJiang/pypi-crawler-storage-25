"""
DBIdempotencyManager — Persistent idempotency backed by Postgres.

Prevents duplicate executions across restarts, retries, and replays.
Uses INSERT ... ON CONFLICT DO NOTHING for atomic claim semantics.

Lifecycle:
  start()    → INSERT with status='processing' (atomic claim)
  complete() → UPDATE status='completed', store response
  fail()     → UPDATE status='failed'
  get()      → SELECT current state
"""
from __future__ import annotations

import json
from typing import Any, Dict, Optional

from core.payments.db import get_db_connection


class DBIdempotencyManager:
    """
    Persistent idempotency guard for a single (tenant_id, key) pair.

    Usage:
        idem = DBIdempotencyManager(tenant_id, key)
        existing = idem.get()
        if existing and existing["status"] == "completed":
            return existing["response"]
        if not idem.start():
            raise Exception("IDEMPOTENCY_RACE")
        # ... do work ...
        idem.complete(result_dict)
    """

    def __init__(self, tenant_id: str, idempotency_key: str) -> None:
        self._tenant_id = tenant_id
        self._key = idempotency_key

    def get(self) -> Optional[Dict[str, Any]]:
        """Return the current idempotency record, or None."""
        with get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT status, response FROM idempotency_keys "
                "WHERE idempotency_key = %s",
                (self._key,),
            )
            row = cur.fetchone()
            if not row:
                return None
            status, response = row
            return {"status": status, "response": response}

    def start(self) -> bool:
        """
        Atomically claim this key. Returns True if we own it,
        False if another request already claimed it.
        """
        with get_db_connection() as conn:
            with conn:
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO idempotency_keys "
                    "(idempotency_key, tenant_id, status) "
                    "VALUES (%s, %s, 'processing') "
                    "ON CONFLICT (idempotency_key) DO NOTHING",
                    (self._key, self._tenant_id),
                )
                return cur.rowcount == 1

    def complete(self, response: Dict[str, Any]) -> None:
        """Mark this key as completed and store the response."""
        with get_db_connection() as conn:
            with conn:
                cur = conn.cursor()
                cur.execute(
                    "UPDATE idempotency_keys "
                    "SET status = 'completed', response = %s "
                    "WHERE idempotency_key = %s",
                    (json.dumps(response), self._key),
                )

    def fail(self, error: Exception) -> None:
        """Mark this key as failed so it can be retried."""
        with get_db_connection() as conn:
            with conn:
                cur = conn.cursor()
                cur.execute(
                    "UPDATE idempotency_keys SET status = 'failed' "
                    "WHERE idempotency_key = %s",
                    (self._key,),
                )
