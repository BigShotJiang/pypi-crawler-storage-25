# core/payments — Persistent economic layer for Kernell OS
