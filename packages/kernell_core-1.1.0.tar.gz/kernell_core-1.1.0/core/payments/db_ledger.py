"""
DBLedger — Persistent transaction ledger backed by Postgres.

Every ExecutionLedgerEntry is written to the `transactions` table
so that economic history survives restarts.
"""
from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List, Optional

from core.payments.db import get_db_connection


class DBLedger:
    """
    Persistent ledger that writes to Postgres `transactions` table.

    Conforms to the same interface as InMemoryLedger so it can be
    swapped in transparently.
    """

    def record(self, entry: Any) -> None:
        """Insert a single ledger entry into Postgres."""
        with get_db_connection() as conn:
            with conn:
                cur = conn.cursor()
                # Use getattr to safely access tx_hash if it exists on the entry
                tx_hash = getattr(entry, "tx_hash", None)
                cur.execute(
                    """
                    INSERT INTO transactions (
                        execution_id, tenant_id,
                        estimated_micro, reserved_micro,
                        captured_micro, refunded_micro,
                        status, error, tx_hash
                    ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    ON CONFLICT (execution_id) DO NOTHING
                    """,
                    (
                        entry.execution_id,
                        entry.tenant_id,
                        entry.estimated_micro,
                        entry.reserved_micro,
                        entry.captured_micro,
                        entry.refunded_micro,
                        entry.status,
                        entry.error,
                        tx_hash,
                    ),
                )

    def list_entries(self) -> List[Dict[str, Any]]:
        """Return all ledger entries from Postgres, newest first."""
        with get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT execution_id, tenant_id, estimated_micro, "
                "reserved_micro, captured_micro, refunded_micro, "
                "status, error, created_at, tx_hash, block_number, retry_count "
                "FROM transactions ORDER BY created_at DESC LIMIT 500"
            )
            rows = cur.fetchall()
            cols = [
                "execution_id", "tenant_id", "estimated_micro",
                "reserved_micro", "captured_micro", "refunded_micro",
                "status", "error", "created_at", "tx_hash", "block_number", "retry_count"
            ]
            return [dict(zip(cols, r)) for r in rows]

    def get_uncertain_transactions(self, limit=50) -> List[Dict[str, Any]]:
        with get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute(
                "SELECT execution_id, tenant_id, tx_hash, retry_count "
                "FROM transactions WHERE status = 'uncertain' "
                "ORDER BY created_at ASC LIMIT %s", (limit,)
            )
            rows = cur.fetchall()
            cols = ["execution_id", "tenant_id", "tx_hash", "retry_count"]
            return [dict(zip(cols, r)) for r in rows]

    def update_transaction_status(self, execution_id: str, status: str, block_number: Optional[int] = None):
        with get_db_connection() as conn:
            with conn:
                cur = conn.cursor()
                if block_number is not None:
                    cur.execute(
                        "UPDATE transactions SET status = %s, block_number = %s, last_checked_at = NOW() WHERE execution_id = %s",
                        (status, block_number, execution_id)
                    )
                else:
                    cur.execute(
                        "UPDATE transactions SET status = %s, last_checked_at = NOW() WHERE execution_id = %s",
                        (status, execution_id)
                    )

    def increment_retry(self, execution_id: str):
        with get_db_connection() as conn:
            with conn:
                cur = conn.cursor()
                cur.execute(
                    "UPDATE transactions SET retry_count = retry_count + 1, last_checked_at = NOW() WHERE execution_id = %s",
                    (execution_id,)
                )
