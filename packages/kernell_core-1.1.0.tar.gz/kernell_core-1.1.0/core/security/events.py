import json
import time
import os

SECURITY_LOG = "data/security_events.jsonl"

def record_security_event(event_type, detail, severity, tenant_id=None, execution_id=None):
    os.makedirs("data", exist_ok=True)
    event = {
        "type": event_type,
        "severity": severity,
        "detail": detail,
        "tenant_id": tenant_id,
        "execution_id": execution_id,
        "timestamp": time.time(),
    }
    with open(SECURITY_LOG, "a") as f:
        f.write(json.dumps(event) + "\n")
    try:
        from core.security.locks import redis_client
        redis_client.publish("kernell:security_events", json.dumps(event))
    except Exception:
        pass

def emit_execution_event(event_type: str, tenant_id: str, **kwargs):
    execution_id = kwargs.pop("execution_id", None)
    record_security_event(
        "EXECUTION_EVENT",
        {
            "exec_type": event_type,
            "execution_id": execution_id,
            **kwargs
        },
        "INFO",
        tenant_id,
        execution_id
    )
