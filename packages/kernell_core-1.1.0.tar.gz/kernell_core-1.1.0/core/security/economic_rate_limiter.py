"""
Kernell Economic Rate Limiter — FASE 4.1

Controls the physical throughput of money (μ / minuto).
Uses a highly optimized bucketed sliding window in Redis.
Instead of large ZRANGEs, it uses `INCRBY` on 1-second buckets and `MGET`.
"""
from __future__ import annotations

import os
import time
from typing import Optional, Tuple

# Load .env
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import redis

REDIS_URL = os.environ.get("REDIS_URL", "redis://127.0.0.1:6380")
_redis = redis.Redis.from_url(REDIS_URL)

# Defaults: 1,000,000 micro (1 unit) per 60 seconds
DEFAULT_LIMIT_MICRO = 1_000_000
WINDOW_SECONDS = 60


class EconomicRateLimiter:
    """
    Limits the total money a tenant can burn within a rolling window.
    Evaluated BEFORE execution begins.
    """

    def __init__(
        self,
        r: Optional[redis.Redis] = None,
        limit_micro: int = DEFAULT_LIMIT_MICRO,
        window_seconds: int = WINDOW_SECONDS
    ):
        self._r = r or _redis
        self._limit = limit_micro
        self._window = window_seconds

    def check(self, tenant_id: str, estimated_micro: int) -> Tuple[bool, int]:
        """
        Check if adding `estimated_micro` would exceed the rate limit.
        Returns: (allowed, current_spend_in_window)
        """
        now = int(time.time())
        # Fetch the last N second buckets
        keys = [f"kernell:ratelimit:spend:{tenant_id}:{now - i}" for i in range(self._window)]
        
        # MGET is O(N) where N is small (60), extremely fast and avoids ZRANGE/sum overhead in Python
        values = self._r.mget(keys)
        
        total_spend = sum(int(v) for v in values if v is not None)
        
        allowed = (total_spend + estimated_micro) <= self._limit
        return allowed, total_spend

    def record(self, tenant_id: str, actual_micro: int) -> None:
        """
        Record the actual spend into the current 1-second bucket.
        """
        if actual_micro <= 0:
            return
            
        now = int(time.time())
        key = f"kernell:ratelimit:spend:{tenant_id}:{now}"
        
        pipe = self._r.pipeline()
        pipe.incrby(key, actual_micro)
        pipe.expire(key, self._window + 5)  # expire slightly after it leaves the window
        pipe.execute()


# ── Singleton ────────────────────────────────────────────────────────
_limiter: Optional[EconomicRateLimiter] = None


def get_rate_limiter() -> EconomicRateLimiter:
    global _limiter
    if _limiter is None:
        _limiter = EconomicRateLimiter()
    return _limiter
