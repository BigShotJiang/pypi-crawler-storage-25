import json
import time
from core.security.locks import redis_client

class IdempotencyManager:
    def __init__(self, tenant_id: str, key: str):
        self.redis = redis_client
        self.key = f"kernell:idem:{tenant_id}:{key}"

    def start(self) -> bool:
        """
        Attempts to start idempotency processing.
        Returns True if new, False if already exists (processing or completed).
        """
        data = {
            "status": "processing",
            "timestamp": time.time()
        }
        success = self.redis.set(self.key, json.dumps(data), nx=True, ex=900)
        return success is True

    def get(self) -> dict | None:
        val = self.redis.get(self.key)
        return json.loads(val) if val else None

    def complete(self, response: dict) -> None:
        data = {
            "status": "completed",
            "response": response,
            "timestamp": time.time()
        }
        self.redis.set(self.key, json.dumps(data), ex=86400) # Keep for 24h

    def fail(self, error: Exception) -> None:
        data = {
            "status": "failed",
            "error": str(error),
            "timestamp": time.time()
        }
        self.redis.set(self.key, json.dumps(data), ex=300) # Keep for 5m to retry later
