import os
import uuid
import time
import redis
from contextlib import contextmanager

# Load .env if dotenv is available
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

REDIS_URL = os.environ.get("REDIS_URL", "redis://127.0.0.1:6380")
redis_client = redis.Redis.from_url(REDIS_URL)

class RedisLock:
    def __init__(self, tenant_id: str, ttl_ms: int = 10000):
        self.key = f"kernell:lock:tenant:{tenant_id}"
        self.ttl_ms = ttl_ms
        self.value = str(uuid.uuid4())
        self.redis = redis_client

    def acquire(self) -> bool:
        acquired = self.redis.set(
            self.key,
            self.value,
            nx=True,
            px=self.ttl_ms
        )
        return acquired is True

    def release(self) -> None:
        release_script = """
        if redis.call("GET", KEYS[1]) == ARGV[1]
        then
            return redis.call("DEL", KEYS[1])
        else
            return 0
        end
        """
        self.redis.eval(release_script, 1, self.key, self.value)

def acquire_with_retry(lock: RedisLock, retries: int = 20, delay: float = 0.05) -> bool:
    for _ in range(retries):
        if lock.acquire():
            return True
        time.sleep(delay)
    return False

@contextmanager
def get_tenant_lock(tenant_id: str, timeout_ms: int = 10000):
    lock = RedisLock(tenant_id, ttl_ms=timeout_ms)
    if not acquire_with_retry(lock, retries=20, delay=0.05):
        raise TimeoutError(f"Could not acquire lock for tenant {tenant_id}")
    try:
        yield lock
    finally:
        lock.release()

