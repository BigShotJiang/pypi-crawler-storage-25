"""
Kernell Economic Risk Engine — FASE 4

Real-time threat detection using Redis sliding windows.
Evaluates tenant risk BEFORE money is touched.

Detectors:
  1. BURST_SPEND    — too much money burned in a short window
  2. PROBING_ATTACK — high failure-to-success ratio
  3. REPLAY_ABUSE   — excessive idempotency key reuse
  4. COST_ANOMALY   — actual cost >> estimated cost

Each detector produces a 0.0–1.0 score.
Combined into a weighted risk_score that gates execution.
"""
from __future__ import annotations

import os
import time
import json
from dataclasses import dataclass, asdict
from typing import Optional

# Load .env
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import redis

REDIS_URL = os.environ.get("REDIS_URL", "redis://127.0.0.1:6380")
_redis = redis.Redis.from_url(REDIS_URL)

# ─── Configuration ───────────────────────────────────────────────────
WINDOW_SECONDS = 10           # Sliding window size
BURST_THRESHOLD_MICRO = 500_000  # 500k micro in 10s = suspicious
FAILURE_RATIO_THRESHOLD = 0.6    # 60%+ failures = probing
REPLAY_THRESHOLD = 5             # 5+ same-key hits = abuse
BLOCK_THRESHOLD = 0.6            # risk_score >= 0.6 → block

# Weights for composite score
W_BURST = 0.45
W_FAILURE = 0.25
W_REPLAY = 0.2
W_ANOMALY = 0.1


@dataclass
class RiskAssessment:
    tenant_id: str
    timestamp: float
    burst_score: float
    failure_score: float
    replay_score: float
    anomaly_score: float
    risk_score: float
    blocked: bool
    flags: list

    def to_dict(self):
        return asdict(self)


class RiskEngine:
    """
    Stateless evaluator that reads counters from Redis sliding windows.

    Call record_*() after each execution event to feed the engine.
    Call evaluate() BEFORE pre_authorize to gate the request.
    """

    def __init__(self, r: Optional[redis.Redis] = None):
        self._r = r or _redis

    # ── Recording (call these from ExecutionManager) ─────────────

    def record_spend(self, tenant_id: str, amount_micro: int) -> None:
        """Record a spend event in the sliding window."""
        key = f"kernell:risk:spend:{tenant_id}"
        now = time.time()
        pipe = self._r.pipeline()
        pipe.zadd(key, {f"{now}:{amount_micro}": now})
        pipe.zremrangebyscore(key, 0, now - WINDOW_SECONDS)
        pipe.expire(key, WINDOW_SECONDS * 2)
        pipe.execute()

    def record_execution(self, tenant_id: str, success: bool) -> None:
        """Record an execution result (success/failure)."""
        key_ok = f"kernell:risk:exec_ok:{tenant_id}"
        key_fail = f"kernell:risk:exec_fail:{tenant_id}"
        now = time.time()
        target_key = key_ok if success else key_fail
        pipe = self._r.pipeline()
        pipe.zadd(target_key, {str(now): now})
        pipe.zremrangebyscore(key_ok, 0, now - WINDOW_SECONDS)
        pipe.zremrangebyscore(key_fail, 0, now - WINDOW_SECONDS)
        pipe.expire(key_ok, WINDOW_SECONDS * 2)
        pipe.expire(key_fail, WINDOW_SECONDS * 2)
        pipe.execute()

    def record_replay(self, tenant_id: str) -> None:
        """Record a replay/idempotency hit."""
        key = f"kernell:risk:replay:{tenant_id}"
        now = time.time()
        pipe = self._r.pipeline()
        pipe.zadd(key, {str(now): now})
        pipe.zremrangebyscore(key, 0, now - WINDOW_SECONDS)
        pipe.expire(key, WINDOW_SECONDS * 2)
        pipe.execute()

    # ── Evaluation ───────────────────────────────────────────────

    def evaluate(self, tenant_id: str) -> RiskAssessment:
        """
        Compute the composite risk score for a tenant.
        Call this BEFORE pre_authorize.
        """
        now = time.time()
        cutoff = now - WINDOW_SECONDS
        flags = []

        # 1. Burst spend
        burst_score = self._score_burst(tenant_id, cutoff)
        if burst_score > 0.5:
            flags.append("BURST_SPEND")

        # 2. Failure ratio
        failure_score = self._score_failure(tenant_id, cutoff)
        if failure_score > 0.5:
            flags.append("PROBING_ATTACK")

        # 3. Replay abuse
        replay_score = self._score_replay(tenant_id, cutoff)
        if replay_score > 0.5:
            flags.append("REPLAY_ABUSE")

        # 4. Anomaly (placeholder — needs per-request data)
        anomaly_score = 0.0

        # Composite
        risk_score = (
            W_BURST * burst_score
            + W_FAILURE * failure_score
            + W_REPLAY * replay_score
            + W_ANOMALY * anomaly_score
        )
        risk_score = min(risk_score, 1.0)

        blocked = risk_score >= BLOCK_THRESHOLD
        if blocked:
            flags.append("RISK_BLOCKED")

        return RiskAssessment(
            tenant_id=tenant_id,
            timestamp=now,
            burst_score=round(burst_score, 3),
            failure_score=round(failure_score, 3),
            replay_score=round(replay_score, 3),
            anomaly_score=round(anomaly_score, 3),
            risk_score=round(risk_score, 3),
            blocked=blocked,
            flags=flags,
        )

    # ── Internal scorers ─────────────────────────────────────────

    def _score_burst(self, tenant_id: str, cutoff: float) -> float:
        """How much was spent in the window vs threshold."""
        key = f"kernell:risk:spend:{tenant_id}"
        members = self._r.zrangebyscore(key, cutoff, "+inf")
        total = 0
        for m in members:
            # format: "timestamp:amount"
            parts = m.decode().split(":")
            if len(parts) >= 2:
                try:
                    total += int(parts[-1])
                except ValueError:
                    pass
        if BURST_THRESHOLD_MICRO == 0:
            return 0.0
        return min(total / BURST_THRESHOLD_MICRO, 1.0)

    def _score_failure(self, tenant_id: str, cutoff: float) -> float:
        """Ratio of failures to total executions in window."""
        ok_count = self._r.zcount(
            f"kernell:risk:exec_ok:{tenant_id}", cutoff, "+inf"
        )
        fail_count = self._r.zcount(
            f"kernell:risk:exec_fail:{tenant_id}", cutoff, "+inf"
        )
        total = ok_count + fail_count
        if total < 3:  # not enough data
            return 0.0
        ratio = fail_count / total
        # Scale: 0.6 ratio → 0.5 score, 1.0 ratio → 1.0 score
        if ratio < FAILURE_RATIO_THRESHOLD:
            return 0.0
        return min((ratio - FAILURE_RATIO_THRESHOLD) / (1.0 - FAILURE_RATIO_THRESHOLD), 1.0)

    def _score_replay(self, tenant_id: str, cutoff: float) -> float:
        """How many replay hits in the window vs threshold."""
        count = self._r.zcount(
            f"kernell:risk:replay:{tenant_id}", cutoff, "+inf"
        )
        if REPLAY_THRESHOLD == 0:
            return 0.0
        return min(count / REPLAY_THRESHOLD, 1.0)


# ── Singleton ────────────────────────────────────────────────────────
_engine: Optional[RiskEngine] = None


def get_risk_engine() -> RiskEngine:
    global _engine
    if _engine is None:
        _engine = RiskEngine()
    return _engine
