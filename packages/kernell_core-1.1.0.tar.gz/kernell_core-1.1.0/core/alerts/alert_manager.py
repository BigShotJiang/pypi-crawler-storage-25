"""
Kernell Operational Alerting System — FASE 4.2

Sends actionable alerts to webhooks (Slack/Telegram) with built-in anti-spam cooldowns.
Never blocks the main execution thread.
"""
import os
import requests
import json
import redis
import logging
from typing import Optional, Dict, Any
from datetime import datetime

logger = logging.getLogger(__name__)

# Load .env
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

REDIS_URL = os.environ.get("REDIS_URL", "redis://127.0.0.1:6380")
_redis = redis.Redis.from_url(REDIS_URL)

ALERT_WEBHOOK_URL = os.getenv("ALERT_WEBHOOK_URL", "")
DEFAULT_COOLDOWN = 60  # 1 minute

ICONS = {
    "CRITICAL": "🚨",
    "WARNING": "⚠️",
    "INFO": "ℹ️"
}

class AlertManager:
    def __init__(self, r: Optional[redis.Redis] = None, webhook: str = ALERT_WEBHOOK_URL):
        self._r = r or _redis
        self._webhook = webhook

    def send(self, level: str, alert_type: str, payload: Dict[str, Any], tenant_id: str = "system") -> bool:
        """
        Send an alert if not on cooldown.
        Returns True if sent (or logged for testing), False if skipped due to cooldown or error.
        """
        # Anti-spam cooldown
        cooldown_key = f"kernell:alert:cooldown:{alert_type}:{tenant_id}"
        if self._r.exists(cooldown_key):
            return False

        # Set cooldown
        self._r.set(cooldown_key, 1, ex=DEFAULT_COOLDOWN)

        icon = ICONS.get(level.upper(), "🔴")
        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC")

        # Format payload cleanly
        details = "\n".join([f"{k.capitalize()}: {v}" for k, v in payload.items()])
        text = f"{icon} *{alert_type.replace('_', ' ')}*\nTenant: {tenant_id}\n{details}\nTime: {now}"

        message = {
            "text": text,
            "_raw": {
                "level": level,
                "type": alert_type,
                "tenant_id": tenant_id,
                "payload": payload
            }
        }

        # If no webhook is configured, just push to test queue
        if not self._webhook:
            self._r.rpush("kernell:alert:test_queue", json.dumps(message["_raw"]))
            self._r.expire("kernell:alert:test_queue", 300)
            logger.info(f"ALERT: {text.replace(chr(10), ' | ')}")
            return True

        # Send to real webhook
        try:
            requests.post(self._webhook, json=message, timeout=2.0)
            return True
        except Exception as e:
            logger.error(f"Failed to send alert: {e}")
            return False

_manager: Optional[AlertManager] = None

def get_alert_manager() -> AlertManager:
    global _manager
    if _manager is None:
        _manager = AlertManager()
    return _manager
