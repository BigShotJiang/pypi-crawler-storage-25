from fastapi import FastAPI, BackgroundTasks, HTTPException, Header, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
import hashlib
import json
import os
import re
import sqlite3
import time
from datetime import datetime, timedelta
from typing import Any, Optional

from kernell_os_sdk.billing.spend_guard import SpendGuard
from kernell_os_sdk.runtime.execution_manager import (
    DefaultCostEstimator,
    ExecutionManager,
    input_adjustment_micro,
    BudgetExceededError,
    PreAuthorizationError,
)

from core.security.gate import SecurityGate
from core.security.economic_invariants import EconomicInvariants

# ─── Allowed Origins (restrict in production) ──────────────────────────
ALLOWED_ORIGINS = os.environ.get(
    "CORS_ORIGINS",
    "https://tu-dominio.com,http://localhost:3000,http://localhost:8000"
).split(",")

app = FastAPI(
    title="Kernell OS Core API",
    description="Control plane API for autonomous economic agents",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── KERN Economic Engine Config ────────────────────────────────────────
KERN_PRICING = {
    "execution": 0.015,
    "validation_ovv": 0.007,
    "routing_nexus": 0.003,
    "memory_write": 0.003,
    "memory_read": 0.001,
    "audit_log": 0.001,
}

# Server-side complexity map (never trust the client)
TASK_COMPLEXITY = {
    "simple": 1.0,
    "multi_agent": 1.5,
    "financial": 2.5,
    "autonomous_loop": 3.0,
    "default": 1.0,
}

KERN_INITIAL_BALANCE = 50.0
KERN_TRIAL_DAYS = 14
KERN_LOW_THRESHOLD = 10.0
KERN_UPGRADE_THRESHOLD = 5.0
RATE_LIMIT_SECONDS = 1

# ─── Persistent Storage (SQLite) ──────────────────────────────────
DB_PATH = "data/kernell_core.db"

IP_RATE_LIMIT = {}
SPEND_GUARD_DB = "data/spend_guard.sqlite3"

# ─── Dual-mode SpendGuard + Ledger bootstrap ─────────────────────────
USE_DB = os.getenv("USE_DB", "0") == "1"

if USE_DB:
    from core.payments.db_spend_guard import DBSpendGuard
    from core.payments.db_ledger import DBLedger
    spend_guard = DBSpendGuard()
    ledger = DBLedger()
else:
    spend_guard = SpendGuard(db_path=SPEND_GUARD_DB)
    ledger = None  # ExecutionManager defaults to InMemoryLedger


def _normalize_task_input(raw: Any) -> str:
    if raw is None:
        return ""
    return str(raw).strip()


def _tokens_upper(s: str) -> list[str]:
    """2–5 letter tokens (e.g. tickers / topics); deterministic, sandbox-only."""
    found = re.findall(r"\b[A-Za-z]{2,5}\b", s or "")
    out: list[str] = []
    seen: set[str] = set()
    for t in found:
        u = t.upper()
        if u in seen:
            continue
        seen.add(u)
        out.append(u)
        if len(out) >= 8:
            break
    return out


def _financial_output(user_input: str) -> dict:
    tokens = _tokens_upper(user_input)
    symbols = tokens[:5] if tokens else ["MARKET"]
    primary = symbols[0]
    seed = int(hashlib.sha256(user_input.encode("utf-8")).hexdigest()[:8], 16) % 1000
    confidence = round(0.58 + (seed % 350) / 1000.0, 2)
    analysis = (
        f"Sandbox read on «{user_input or 'general market'}»: {primary} — "
        "narrative momentum mixed; simulated volatility regime moderate. "
        "Liquidity assumed adequate for retail-sized clips. "
        "Deterministic mock only — not investment advice; wire real data for production."
    )
    return {
        "analysis": analysis,
        "confidence": confidence,
        "confidence_note": "mock / educational — not investment advice",
        "symbols": symbols,
        "sources": [
            {"label": "Mock quote path", "ref": f"sandbox://sym/{primary}"},
            {"label": "Risk policy", "ref": "internal://spend_guard/ok"},
        ],
    }


def _execute_task_v2(task_payload: dict):
    """
    Runtime executor adapter for ExecutionManager.
    Returns (result, usage) so cost settlement is deterministic.
    """
    task_type = str(task_payload.get("task_type", "simple"))
    user_input = _normalize_task_input(task_payload.get("input"))
    agent = "nemesis" if task_type == "financial" else "nexus"
    base_cost = (
        KERN_PRICING["execution"]
        + KERN_PRICING["validation_ovv"]
        + KERN_PRICING["routing_nexus"]
        + KERN_PRICING["audit_log"]
    )
    multiplier = TASK_COMPLEXITY.get(task_type, TASK_COMPLEXITY["default"])
    # Apply a small deterministic optimization factor (5%) to simulate actual < estimate.
    actual_cost_micro = int((base_cost * multiplier * 1_000_000) * 0.95) + input_adjustment_micro(
        task_payload
    )

    output: dict
    if task_type == "financial":
        output = _financial_output(user_input)
    elif task_type == "multi_agent":
        output = {
            "summary": "Simulated multi-agent pass (planner → worker → reviewer).",
            "brief_excerpt": (user_input[:400] + ("…" if len(user_input) > 400 else ""))
            if user_input
            else "(no input — used default brief)",
        }
    elif task_type == "autonomous_loop":
        output = {
            "summary": "Simulated autonomous loop: plan, act, check stop condition.",
            "planned_iterations": 3,
            "seed_excerpt": (user_input[:300] + ("…" if len(user_input) > 300 else ""))
            if user_input
            else "(no input — default seed)",
        }
    else:
        output = {
            "summary": (
                f"Echo ({len(user_input)} chars): "
                f"{user_input[:500]}{'…' if len(user_input) > 500 else ''}"
                if user_input
                else "Ran simple task with empty input — add text to drive the mock output."
            ),
        }

    result = {
        "execution_trace": {
            "agent": agent,
            "validated_by": "sentinel",
            "policy_check": "passed",
            "economic_guard": "enforced",
        },
        "input_used": user_input,
        "output": output,
    }
    usage = {"cost_micro": actual_cost_micro}
    return result, usage


execution_manager = ExecutionManager(
    executor=_execute_task_v2,
    spend_guard=spend_guard,
    cost_estimator=DefaultCostEstimator(),
    ledger=ledger,  # None → uses InMemoryLedger; DBLedger → persists to Postgres
)

def init_db():
    os.makedirs("data", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('PRAGMA journal_mode=WAL;')
    c.execute('PRAGMA synchronous=NORMAL;')
    c.execute('''CREATE TABLE IF NOT EXISTS users (
        api_key TEXT PRIMARY KEY,
        credits_kern REAL,
        total_spent_kern REAL DEFAULT 0,
        executions_count INTEGER DEFAULT 0,
        expires_at TIMESTAMP,
        last_call TIMESTAMP
    )''')
    c.execute('''CREATE TABLE IF NOT EXISTS processed_events (
        event_id TEXT PRIMARY KEY,
        processed_at TIMESTAMP
    )''')
    conn.commit()
    conn.close()

init_db()

def get_db():
    conn = sqlite3.connect(DB_PATH, timeout=5.0)
    conn.row_factory = sqlite3.Row
    return conn


def _ensure_spend_guard_balance(api_key: str, user_row: sqlite3.Row) -> int:
    """
    SpendGuard is the single source of truth for available execution balance.
    During migration, bootstrap tenant balance once from legacy SQLite credits.
    """
    balance_micro = spend_guard.get_balance(api_key)
    if balance_micro is not None:
        return balance_micro

    seed_micro = int(float(user_row["credits_kern"]) * 1_000_000)
    spend_guard.provision_tenant(
        api_key,
        initial_balance_micro=seed_micro,
        hard_limit_micro=0,
        soft_limit_micro=int(KERN_LOW_THRESHOLD * 1_000_000),
    )
    return spend_guard.get_balance(api_key) or 0

# ─── Models ─────────────────────────────────────────────────────────────
class LeadCapture(BaseModel):
    name: str
    company: str
    email: str
    use_case: str
    budget: str
    goal: str

class TaskExecution(BaseModel):
    task_type: str = "simple"
    input: str = ""
    max_budget_micro: Optional[int] = None

# ─── Endpoints ──────────────────────────────────────────────────────────

@app.post("/api/v1/leads/request-access")
def request_core_access(lead: LeadCapture, background_tasks: BackgroundTasks, request: Request):
    client_ip = request.client.host
    now = time.time()
    if client_ip in IP_RATE_LIMIT and now - IP_RATE_LIMIT[client_ip] < 60:
        raise HTTPException(status_code=429, detail="Rate limit exceeded. Please wait 60 seconds.")
    IP_RATE_LIMIT[client_ip] = now
    def save_lead(data: dict):
        os.makedirs("data", exist_ok=True)
        with open("data/leads_capture.jsonl", "a") as f:
            f.write(json.dumps(data) + "\n")

    background_tasks.add_task(save_lead, lead.model_dump())

    # Provision Sandbox Environment
    sandbox_key = "sk_test_kernell_" + os.urandom(8).hex()
    expires_at = datetime.utcnow() + timedelta(days=KERN_TRIAL_DAYS)

    # Airdrop KERN Credits
    conn = get_db()
    c = conn.cursor()
    c.execute(
        "INSERT INTO users (api_key, credits_kern, expires_at) VALUES (?, ?, ?)",
        (sandbox_key, KERN_INITIAL_BALANCE, expires_at.isoformat())
    )
    conn.commit()
    conn.close()

    # Mirror sandbox credits into SpendGuard (micro-units) for v2 execution flow.
    spend_guard.provision_tenant(
        sandbox_key,
        initial_balance_micro=int(KERN_INITIAL_BALANCE * 1_000_000),
        hard_limit_micro=0,
        soft_limit_micro=int(KERN_LOW_THRESHOLD * 1_000_000),
    )

    return {
        "status": "success",
        "message": "You now have access to the Kernell Core private demo.",
        "sandbox_key": sandbox_key,
        "initial_balance": KERN_INITIAL_BALANCE,
        "currency": "KERN",
        "next_steps": "Check your email for the private repository invite.",
    }


@app.post("/api/v1/sandbox/execute")
def simulate_execution(
    task: TaskExecution,
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
):
    if not x_api_key:
        raise HTTPException(status_code=401, detail="Missing Sandbox Key")

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE api_key = ?", (x_api_key,))
    user = c.fetchone()

    if not user:
        conn.close()
        raise HTTPException(status_code=401, detail="Invalid Sandbox Key")

    expires_at = datetime.fromisoformat(user["expires_at"])
    last_call = datetime.fromisoformat(user["last_call"]) if user["last_call"] else None

    # ── Expiration guard ─────────────────────────────────────────────
    if datetime.utcnow() > expires_at:
        conn.close()
        raise HTTPException(
            status_code=403,
            detail="Sandbox trial expired. Upgrade to Production Tier.",
        )

    # ── Rate limit guard ─────────────────────────────────────────────
    now = datetime.utcnow()
    if last_call and (now - last_call).total_seconds() < RATE_LIMIT_SECONDS:
        conn.close()
        raise HTTPException(status_code=429, detail="Too many requests. Slow down.")

    # ── Calculate deterministic cost (server-side complexity) ────────
    multiplier = TASK_COMPLEXITY.get(task.task_type, TASK_COMPLEXITY["default"])
    base_cost = (
        KERN_PRICING["execution"]
        + KERN_PRICING["validation_ovv"]
        + KERN_PRICING["routing_nexus"]
        + KERN_PRICING["audit_log"]
    )
    total_cost = round(base_cost * multiplier, 4)

    # ── Atomp Consumption (Race Condition Fix) ───────────────────────
    c.execute("""
        UPDATE users 
        SET credits_kern = credits_kern - ?, 
            total_spent_kern = total_spent_kern + ?, 
            executions_count = executions_count + 1, 
            last_call = ? 
        WHERE api_key = ? AND credits_kern >= ?
    """, (total_cost, total_cost, now.isoformat(), x_api_key, total_cost))
    
    if c.rowcount == 0:
        # Atomic lock failed: User doesn't have enough credits
        c.execute("UPDATE users SET last_call = ? WHERE api_key = ?", (now.isoformat(), x_api_key))
        conn.commit()
        
        # Enriched 402 payload
        base_url = os.environ.get("APP_BASE_URL", "http://localhost:3000")
        recommended_plan = "growth" if executions_count > 1000 else "starter"
        
        # In a real setup, we might proxy this through our billing router directly
        # For the SDK, we'll give them a direct link (or a link to our UI)
        # Using a dummy frontend checkout link for the example:
        upgrade_url = f"{base_url}/checkout?plan={recommended_plan}"
        
        reason = "limit_reached"
        message = "Execution limit reached. Your agents are paused to prevent uncontrolled spend."
        if task.task_type == "financial":
            reason = "high_cost_agent"
            message = "Financial agents consume more credits due to risk controls."
        elif task.task_type == "autonomous_loop":
            reason = "high_cost_agent"
            message = "Autonomous loops consume more credits."
        
        conn.close()
        
        raise HTTPException(
            status_code=402,
            detail={
                "error": "payment_required",
                "reason": reason,
                "message": message,
                "remaining_kern": round(credits_kern, 4),
                "upgrade_url": upgrade_url,
                "recommended_plan": recommended_plan,
                "estimated_cost_next_task": total_cost
            }
        )
    
    conn.commit()
    
    # Fetch updated balance to return to client
    c.execute("SELECT credits_kern FROM users WHERE api_key = ?", (x_api_key,))
    new_credits = c.fetchone()["credits_kern"]
    conn.close()

    return {
        "status": "success",
        "execution_trace": {
            "agent": "nemesis" if task.task_type == "financial" else "nexus",
            "validated_by": "sentinel",
            "policy_check": "passed",
            "economic_guard": "enforced",
        },
        "cost_kern": total_cost,
        "remaining_kern": new_credits,
        "warning": "Approaching execution limit" if new_credits < KERN_LOW_THRESHOLD else None,
        "upgrade_required": new_credits < KERN_UPGRADE_THRESHOLD,
        "recommended_plan": "Production Tier ($299/mo)" if new_credits < KERN_UPGRADE_THRESHOLD else None,
    }


@app.get("/api/v1/sandbox/balance")
def get_balance(x_api_key: Optional[str] = Header(None, alias="X-API-Key")):
    """Check remaining KERN balance for a sandbox key."""
    if not x_api_key:
        raise HTTPException(status_code=401, detail="Missing Sandbox Key")

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE api_key = ?", (x_api_key,))
    user = c.fetchone()
    conn.close()

    if not user:
        raise HTTPException(status_code=401, detail="Invalid Sandbox Key")

    remaining_micro = _ensure_spend_guard_balance(x_api_key, user)
    remaining = remaining_micro / 1_000_000
    total_spent = user["total_spent_kern"]
    executions = user["executions_count"]
    
    cost_per_exec = KERN_PRICING["execution"] + KERN_PRICING["validation_ovv"] + KERN_PRICING["routing_nexus"] + KERN_PRICING["audit_log"]
    est_executions = int(remaining / cost_per_exec) if remaining > 0 else 0

    return {
        "balance_kern": remaining,
        "balance_source": "spend_guard",
        "total_spent_kern": round(total_spent, 4),
        "executions_count": executions,
        "estimated_executions": est_executions,
        "expires_at": user["expires_at"],
        "upgrade_required": remaining < KERN_UPGRADE_THRESHOLD,
    }


@app.post("/api/v1/sandbox/execute-v2")
def simulate_execution_v2(
    task: TaskExecution,
    x_api_key: Optional[str] = Header(None, alias="X-API-Key"),
    idempotency_key: Optional[str] = Header(None, alias="Idempotency-Key"),
):
    """
    Economic execution path v2.
    All spend logic is centralized in ExecutionManager (HOLD/CAPTURE/RELEASE).
    """
    if not x_api_key:
        raise HTTPException(status_code=401, detail="Missing Sandbox Key")

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE api_key = ?", (x_api_key,))
    user = c.fetchone()
    conn.close()
    if not user:
        raise HTTPException(status_code=401, detail="Invalid Sandbox Key")

    expires_at = datetime.fromisoformat(user["expires_at"])
    if datetime.utcnow() > expires_at:
        raise HTTPException(
            status_code=403,
            detail="Sandbox trial expired. Upgrade to Production Tier.",
        )

    tenant_balance = _ensure_spend_guard_balance(x_api_key, user)
    user_budget = task.max_budget_micro
    if user_budget is not None:
        effective_budget = min(user_budget, tenant_balance)
    else:
        effective_budget = tenant_balance

    try:
        # 1. Pre-execution Security Gate
        SecurityGate.check_payload({
            "task_type": task.task_type,
            "input": task.input,
            "max_budget_micro": task.max_budget_micro,
            "tenant_id": x_api_key
        })

        # 2. Core Execution (Invariants and locks now live inside execution_manager.execute)
        payload = execution_manager.execute(
            tenant_id=x_api_key,
            task={"task_type": task.task_type, "input": task.input},
            max_budget_micro=effective_budget,
            idempotency_key=idempotency_key,
        )

    except ValueError as val_err:
        from core.security.events import record_security_event
        record_security_event("VALIDATION_ERROR", str(val_err), "MEDIUM", x_api_key)
        raise HTTPException(status_code=400, detail=str(val_err)) from val_err
    except PreAuthorizationError as pre_auth_err:
        from core.security.events import record_security_event
        record_security_event("INSUFFICIENT_FUNDS", str(pre_auth_err), "MEDIUM", x_api_key)
        raise HTTPException(status_code=402, detail=str(pre_auth_err)) from pre_auth_err
    except BudgetExceededError as budget_err:
        raise HTTPException(status_code=409, detail=str(budget_err)) from budget_err
    except Exception as exc:
        from core.security.events import record_security_event
        record_security_event("CORE_FAILURE", str(exc), "HIGH", x_api_key)
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    remaining_micro = spend_guard.get_balance(x_api_key) or 0
    remaining_kern = remaining_micro / 1_000_000

    res = payload["result"]
    return {
        "status": payload["status"],
        "execution_id": payload["execution_id"],
        "execution_trace": res["execution_trace"],
        "input_used": res.get("input_used", ""),
        "output": res.get("output"),
        "cost_estimated_kern": round(payload["cost_estimated_micro"] / 1_000_000, 6),
        "cost_actual_kern": round(payload["cost_actual_micro"] / 1_000_000, 6),
        "refund_kern": round(payload["refunded_micro"] / 1_000_000, 6),
        "remaining_kern": round(remaining_kern, 6),
    }


# ─── Billing Router (Stripe) ───────────────────────────────────────────
from api.billing import router as billing_router
app.include_router(billing_router)


@app.get("/api/v1/security/events")
def get_security_events(limit: int = 50):
    try:
        with open("data/security_events.jsonl") as f:
            lines = f.readlines()
    except FileNotFoundError:
        return []
    events = [json.loads(l) for l in lines[-limit:]]
    return list(reversed(events))


@app.get("/health")
def health_check():
    return {"status": "operational", "system": "kernell-os-core"}


@app.get("/api/v1/status")
def system_status():
    return {
        "status": "online",
        "active_agents": 5,
        "defcon_level": 5,
        "ledger_status": "synced",
    }


@app.get("/api/v1/trace/{transaction_id}")
def get_economic_trace(transaction_id: str):
    entries = execution_manager.ledger_entries()
    for entry in entries:
        if entry["execution_id"] == transaction_id:
            return {
                "transaction_id": entry["execution_id"],
                "budget_requested": entry["estimated_micro"],
                "budget_allowed": entry["estimated_micro"],
                "reserved": entry["reserved_micro"],
                "spent": entry["captured_micro"],
                "refunded": entry["refunded_micro"]
            }
    raise HTTPException(status_code=404, detail="Transaction not found")


# ─── Wallet Endpoints (require USE_DB) ──────────────────────────────
class FundRequest(BaseModel):
    amount_micro: int

@app.post("/api/v1/wallet/{tenant_id}/fund")
def fund_wallet(tenant_id: str, body: FundRequest):
    if not USE_DB:
        raise HTTPException(status_code=503, detail="Persistent ledger not enabled")
    from core.payments.db import get_db_connection
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute(
                """
                INSERT INTO accounts (tenant_id, balance_micro)
                VALUES (%s, %s)
                ON CONFLICT (tenant_id)
                DO UPDATE SET balance_micro = accounts.balance_micro + %s
                """,
                (tenant_id, body.amount_micro, body.amount_micro),
            )
    return {"status": "funded", "tenant_id": tenant_id, "amount_micro": body.amount_micro}

@app.get("/api/v1/wallet/{tenant_id}")
def get_wallet(tenant_id: str):
    if not USE_DB:
        raise HTTPException(status_code=503, detail="Persistent ledger not enabled")
    from core.payments.db import get_db_connection
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute(
            "SELECT balance_micro FROM accounts WHERE tenant_id = %s",
            (tenant_id,),
        )
        row = cur.fetchone()
    balance = row[0] if row else 0
    # Also gather active holds
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute(
            "SELECT COALESCE(SUM(amount_micro - captured_micro), 0) "
            "FROM holds WHERE tenant_id = %s AND status = 'active'",
            (tenant_id,),
        )
        locked = cur.fetchone()[0]
    return {
        "tenant_id": tenant_id,
        "balance_micro": balance,
        "locked_micro": locked,
        "available_micro": balance,  # balance already has holds deducted
    }

@app.get("/api/v1/ledger/{tenant_id}")
def get_tenant_ledger(tenant_id: str):
    """Return paginated transaction history for a tenant."""
    if not USE_DB:
        entries = [e for e in execution_manager.ledger_entries() if e.get("tenant_id") == tenant_id]
        return {"entries": entries[:50]}
    from core.payments.db import get_db_connection
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute(
            "SELECT execution_id, estimated_micro, reserved_micro, "
            "captured_micro, refunded_micro, status, error, created_at "
            "FROM transactions WHERE tenant_id = %s "
            "ORDER BY created_at DESC LIMIT 50",
            (tenant_id,),
        )
        rows = cur.fetchall()
        cols = [
            "execution_id", "estimated_micro", "reserved_micro",
            "captured_micro", "refunded_micro", "status", "error", "created_at",
        ]
    return {"entries": [dict(zip(cols, r)) for r in rows]}



@app.get("/api/v1/reconcile")
def run_reconciliation():
    """Run economic reconciliation and return the result."""
    if not USE_DB:
        raise HTTPException(status_code=503, detail="Persistent ledger not enabled")
    from core.payments.reconciler import run_and_log
    result = run_and_log()
    return result.to_dict()


@app.get("/api/v1/metrics/spend_rate/{tenant_id}")
def get_spend_rate(tenant_id: str):
    from core.security.economic_rate_limiter import get_rate_limiter
    limiter = get_rate_limiter()
    # Check spend by passing 0 as estimated cost so it doesn't fail
    _, current_spend = limiter.check(tenant_id, 0)
    return {
        "tenant_id": tenant_id,
        "spend_per_minute": current_spend,
        "limit_micro": limiter._limit,
        "window_seconds": limiter._window
    }

@app.get("/api/v1/metrics/risk/{tenant_id}")
def get_tenant_risk_metric(tenant_id: str):
    """Alias for /api/v1/risk for UI consistency."""
    from core.security.risk_engine import get_risk_engine
    assessment = get_risk_engine().evaluate(tenant_id)
    return assessment.to_dict()

@app.get("/api/v1/metrics/health")
def get_system_health():
    if not USE_DB:
        return {"status": "WARNING", "reason": "Persistent ledger not enabled"}
    from core.payments.reconciler import reconcile
    try:
        # Run reconcile directly. If it fails or takes too long, we might want to cache this,
        # but for demo it's fine.
        result = reconcile()
        return {
            "status": "CONSISTENT" if result.is_consistent else "BROKEN",
            "details": {
                "negative_balances": len(result.negative_balances),
                "overcapture_violations": result.overcapture_violations,
                "orphaned_holds": result.orphaned_holds
            }
        }
    except Exception as e:
        return {"status": "BROKEN", "reason": str(e)}

@app.get("/api/v1/risk/{tenant_id}")
def get_tenant_risk(tenant_id: str):
    """Evaluate current risk score for a tenant."""
    from core.security.risk_engine import get_risk_engine
    assessment = get_risk_engine().evaluate(tenant_id)
    return assessment.to_dict()


PHASE_MAP = {
    "EXECUTION_STARTED": "INIT",
    "LOCK_ACQUIRED": "LOCK",
    "LOCK_TIMEOUT": "LOCK",
    "HOLD_CREATED": "HOLD",
    "EXECUTION_COMPLETED": "EXECUTION",
    "INVARIANT_FAILED": "EXECUTION",
    "ROLLBACK": "ROLLBACK",
    "REFUND": "ROLLBACK",
    "LOCK_RELEASED": "FINAL",
    "IDEMPOTENCY_HIT": "GUARD",
    "IDEMPOTENCY_PROCESSING": "GUARD",
    "REPLAY_BLOCKED": "GUARD",
    "RISK_BLOCKED": "GUARD",
    "RISK_ELEVATED": "GUARD",
    "RATE_LIMIT_BLOCKED": "GUARD",
}

def load_events(execution_id: str):
    import json
    events = []
    try:
        with open("data/security_events.jsonl") as f:
            for line in f:
                e = json.loads(line)
                if e.get("execution_id") == execution_id:
                    events.append(e)
    except Exception:
        pass
    return sorted(events, key=lambda x: x["timestamp"])

def normalize_event(e):
    base = {
        "t": e["timestamp"],
        "tenant_id": e.get("tenant_id"),
    }
    if e["type"] == "EXECUTION_EVENT":
        return {
            **base,
            "type": e["detail"]["exec_type"],
            "meta": {k: v for k, v in e["detail"].items() if k != "exec_type"},
            "kind": "execution"
        }
    return {
        **base,
        "type": e["type"],
        "meta": {"detail": e.get("detail")},
        "kind": "security"
    }

def extract_economic(events, execution_id):
    data = {
        "estimated_micro": None,
        "reserved_micro": None,
        "captured_micro": None,
        "refunded_micro": None
    }
    # from ledger if available
    entries = execution_manager.ledger_entries()
    for entry in entries:
        if entry["execution_id"] == execution_id:
            data["estimated_micro"] = entry["estimated_micro"]
            data["reserved_micro"] = entry["reserved_micro"]
            data["captured_micro"] = entry["captured_micro"]
            data["refunded_micro"] = entry["refunded_micro"]
            return data
    
    # fallback
    for e in events:
        if e["type"] == "HOLD_CREATED":
            data["reserved_micro"] = e["meta"].get("amount")
            data["estimated_micro"] = e["meta"].get("estimated")
    return data

def derive_status(events):
    types = [e["type"] for e in events]
    if "REPLAY_BLOCKED" in types or "IDEMPOTENCY_HIT" in types:
        return "replay_blocked"
    if "EXECUTION_COMPLETED" in types:
        return "completed"
    if "ROLLBACK" in types or "LOCK_TIMEOUT" in types or "INVARIANT_FAILED" in types:
        return "failed"
    return "unknown"

def extract_flags(events):
    flags = []
    for e in events:
        if e["kind"] == "security":
            flags.append(e["type"])
    return list(set(flags))

@app.get("/api/v1/replay/{execution_id}")
def get_replay(execution_id: str):
    raw = load_events(execution_id)
    norm = [normalize_event(e) for e in raw]

    timeline = []
    for e in norm:
        timeline.append({
            "t": e["t"],
            "type": e["type"],
            "phase": PHASE_MAP.get(e["type"], "UNKNOWN"),
            "meta": e["meta"]
        })

    return {
        "execution_id": execution_id,
        "tenant_id": norm[0]["tenant_id"] if norm else None,
        "timeline": timeline,
        "economic": extract_economic(norm, execution_id),
        "result": {
            "status": derive_status(norm),
            "error": None
        },
        "security": {
            "flags": extract_flags(norm)
        }
    }

if __name__ == "__main__":
    uvicorn.run("api.app:app", host="0.0.0.0", port=8000, reload=True)
