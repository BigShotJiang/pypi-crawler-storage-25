"""
FASE 3 — Critical Integration Test
Tests persistent economic layer end-to-end:
  1. Fund wallet
  2. Pre-authorize (deducts balance, creates hold)
  3. Capture usage
  4. Finalize hold (refund remainder)
  5. Verify final balance is mathematically correct
  6. Verify DB state survives (no in-memory dependency)
"""
import sys
import uuid
sys.path.insert(0, "/home/anny/kernell-os")

from core.payments.db import get_db_connection
from core.payments.db_spend_guard import DBSpendGuard

TENANT = "test_tenant_fase3"
FUND_AMOUNT = 1_000_000  # 1M micro

def cleanup():
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM transactions WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM holds WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM accounts WHERE tenant_id = %s", (TENANT,))

def get_balance():
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT balance_micro FROM accounts WHERE tenant_id = %s", (TENANT,))
        row = cur.fetchone()
        return row[0] if row else 0

def count_holds(status=None):
    with get_db_connection() as conn:
        cur = conn.cursor()
        if status:
            cur.execute("SELECT COUNT(*) FROM holds WHERE tenant_id = %s AND status = %s", (TENANT, status))
        else:
            cur.execute("SELECT COUNT(*) FROM holds WHERE tenant_id = %s", (TENANT,))
        return cur.fetchone()[0]

def test():
    print("=" * 60)
    print("FASE 3 — Persistent Economic Layer Integration Test")
    print("=" * 60)

    # 0. Cleanup
    cleanup()
    print("\n✔ Cleanup complete")

    # 1. Fund wallet
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO accounts (tenant_id, balance_micro) VALUES (%s, %s)",
                (TENANT, FUND_AMOUNT),
            )
    balance = get_balance()
    assert balance == FUND_AMOUNT, f"Fund failed: expected {FUND_AMOUNT}, got {balance}"
    print(f"✔ Funded wallet: {balance}μ")

    # 2. Pre-authorize
    guard = DBSpendGuard()
    reserve = 200_000
    ok, hold_id = guard.pre_authorize(TENANT, reserve)
    assert ok, "Pre-auth failed"
    assert hold_id is not None
    balance_after_hold = get_balance()
    expected = FUND_AMOUNT - reserve
    assert balance_after_hold == expected, f"Balance after hold: expected {expected}, got {balance_after_hold}"
    print(f"✔ Pre-authorized {reserve}μ → balance={balance_after_hold}μ, hold={hold_id[:8]}...")

    # 3. Capture partial usage
    captured = 150_000
    guard.capture_usage(hold_id, captured)
    print(f"✔ Captured {captured}μ from hold")

    # 4. Over-capture should fail
    try:
        guard.capture_usage(hold_id, 100_000)  # 150k + 100k > 200k
        assert False, "OVER_CAPTURE should have been raised"
    except Exception as e:
        assert "OVER_CAPTURE" in str(e)
        print(f"✔ Over-capture correctly blocked: {e}")

    # 5. Finalize (refund remainder)
    guard.finalize_hold(hold_id)
    refund = reserve - captured  # 50_000
    balance_final = get_balance()
    expected_final = FUND_AMOUNT - captured  # 1M - 150k = 850k
    assert balance_final == expected_final, f"Final balance: expected {expected_final}, got {balance_final}"
    print(f"✔ Finalized hold → refunded {refund}μ → balance={balance_final}μ")

    # 6. Hold should be finalized
    active = count_holds("active")
    finalized = count_holds("finalized")
    assert active == 0, f"Active holds should be 0, got {active}"
    assert finalized == 1, f"Finalized holds should be 1, got {finalized}"
    print(f"✔ Hold states: active={active}, finalized={finalized}")

    # 7. Insufficient funds should be denied
    ok2, _ = guard.pre_authorize(TENANT, 999_999_999)
    assert not ok2, "Should deny insufficient funds"
    print(f"✔ Insufficient funds correctly denied")

    # 8. Math invariant
    print(f"\n{'=' * 60}")
    print(f"  INVARIANT: Fund({FUND_AMOUNT}) - Captured({captured}) = Balance({balance_final})")
    print(f"  {FUND_AMOUNT} - {captured} = {balance_final}")
    assert FUND_AMOUNT - captured == balance_final
    print(f"  ✅ PASS — No money created or destroyed")
    print(f"{'=' * 60}")

    # Cleanup
    cleanup()
    print("\n✔ Test cleanup done")
    print("\n🟢 ALL TESTS PASSED — Persistent economic layer is correct")

if __name__ == "__main__":
    test()
