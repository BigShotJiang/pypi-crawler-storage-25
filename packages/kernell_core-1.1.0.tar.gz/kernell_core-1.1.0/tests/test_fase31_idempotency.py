"""
FASE 3.1 + 3.2 — Persistent Idempotency & Reconciliation Test

Tests:
  1. Same idempotency key → only 1 execution (10 sequential attempts)
  2. Same response returned every time
  3. Reconciliation reports consistent state
  4. Full flow: fund → execute with idem → replay blocked → reconcile
"""
import os
import sys
import uuid
import json
import threading
import time

sys.path.insert(0, "/home/anny/kernell-os")
os.environ["USE_DB"] = "1"

from core.payments.db import get_db_connection
from core.payments.db_spend_guard import DBSpendGuard
from core.payments.db_idempotency import DBIdempotencyManager
from core.payments.db_ledger import DBLedger
from core.payments.reconciler import reconcile
from kernell_os_sdk.runtime.execution_manager import (
    ExecutionManager,
    DefaultCostEstimator,
    ExecutionLedgerEntry,
)

TENANT = "idem_test_tenant"
FUND_AMOUNT = 5_000_000
IDEM_KEY = f"test-idem-{uuid.uuid4().hex[:8]}"

def cleanup():
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM idempotency_keys WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM transactions WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM holds WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM accounts WHERE tenant_id = %s", (TENANT,))

def fund():
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO accounts (tenant_id, balance_micro) VALUES (%s, %s) "
                "ON CONFLICT (tenant_id) DO UPDATE SET balance_micro = %s",
                (TENANT, FUND_AMOUNT, FUND_AMOUNT),
            )

def get_balance():
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT balance_micro FROM accounts WHERE tenant_id = %s", (TENANT,))
        row = cur.fetchone()
        return row[0] if row else 0

def dummy_executor(task):
    """Simulates a real executor."""
    time.sleep(0.05)
    return {"result": "ok", "task": task.get("task_type")}, {"cost_micro": 20000}

def test():
    print("=" * 60)
    print("FASE 3.1 + 3.2 — Idempotency & Reconciliation Test")
    print("=" * 60)

    cleanup()
    fund()
    balance_before = get_balance()
    print(f"\n✔ Funded: {balance_before}μ")

    guard = DBSpendGuard()
    ledger = DBLedger()
    em = ExecutionManager(
        executor=dummy_executor,
        spend_guard=guard,
        cost_estimator=DefaultCostEstimator(),
        ledger=ledger,
    )

    # ── TEST 1: First execution with idempotency key ──
    print(f"\n--- Test 1: First execution (key={IDEM_KEY[:12]}...) ---")
    result1 = em.execute(
        tenant_id=TENANT,
        task={"task_type": "simple", "input": "hello"},
        idempotency_key=IDEM_KEY,
    )
    assert result1["status"] == "completed"
    exec_id = result1["execution_id"]
    cost1 = result1["cost_actual_micro"]
    print(f"  ✔ Execution {exec_id[:8]}... completed, cost={cost1}μ")

    balance_after_first = get_balance()
    print(f"  ✔ Balance: {balance_before}μ → {balance_after_first}μ (spent ~{balance_before - balance_after_first}μ)")

    # ── TEST 2: 10 sequential replays (same key) ──
    print(f"\n--- Test 2: 10 sequential replays (same key) ---")
    for i in range(10):
        result_replay = em.execute(
            tenant_id=TENANT,
            task={"task_type": "simple", "input": "hello"},
            idempotency_key=IDEM_KEY,
        )
        assert result_replay["execution_id"] == exec_id, \
            f"Replay {i}: got different execution_id!"
        assert result_replay["cost_actual_micro"] == cost1, \
            f"Replay {i}: got different cost!"

    balance_after_replays = get_balance()
    assert balance_after_replays == balance_after_first, \
        f"Balance changed after replays! {balance_after_first} → {balance_after_replays}"
    print(f"  ✔ All 10 replays returned SAME response")
    print(f"  ✔ Balance unchanged: {balance_after_replays}μ")
    print(f"  ✔ NO duplicate execution, NO duplicate spend")

    # ── TEST 3: Concurrent replays (10 threads, same key) ──
    print(f"\n--- Test 3: 10 concurrent replays (same key) ---")
    concurrent_results = []
    lock = threading.Lock()

    def replay_worker():
        try:
            r = em.execute(
                tenant_id=TENANT,
                task={"task_type": "simple", "input": "hello"},
                idempotency_key=IDEM_KEY,
            )
            with lock:
                concurrent_results.append(r)
        except Exception as e:
            with lock:
                concurrent_results.append({"error": str(e)})

    threads = [threading.Thread(target=replay_worker) for _ in range(10)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # All should return the same cached result
    for r in concurrent_results:
        if "error" not in r:
            assert r["execution_id"] == exec_id

    balance_after_concurrent = get_balance()
    assert balance_after_concurrent == balance_after_first
    print(f"  ✔ All concurrent replays safe, balance={balance_after_concurrent}μ")

    # ── TEST 4: Different key → new execution ──
    print(f"\n--- Test 4: New key → new execution ---")
    new_key = f"test-idem-{uuid.uuid4().hex[:8]}"
    result_new = em.execute(
        tenant_id=TENANT,
        task={"task_type": "simple", "input": "world"},
        idempotency_key=new_key,
    )
    assert result_new["execution_id"] != exec_id
    assert result_new["status"] == "completed"
    balance_after_new = get_balance()
    print(f"  ✔ New execution {result_new['execution_id'][:8]}...")
    print(f"  ✔ Balance: {balance_after_concurrent}μ → {balance_after_new}μ")

    # ── TEST 5: Reconciliation ──
    print(f"\n--- Test 5: Reconciliation ---")
    recon = reconcile()
    print(f"  Total balance:      {recon.total_balance}μ")
    print(f"  Active holds:       {recon.total_active_holds}μ")
    print(f"  Total captured:     {recon.total_captured}μ")
    print(f"  System money:       {recon.total_funded}μ")
    print(f"  Negative balances:  {recon.negative_balances}")
    print(f"  Dangling holds:     {recon.dangling_holds}")
    print(f"  Orphaned holds:     {recon.orphaned_holds}")
    print(f"  Overcapture:        {recon.overcapture_violations}")
    assert recon.is_consistent, "RECONCILIATION FAILED — INCONSISTENT STATE"
    print(f"  ✅ System is CONSISTENT")

    # ── Final invariant ──
    print(f"\n{'=' * 60}")
    total_spent = balance_before - balance_after_new
    print(f"  Funded:        {balance_before}μ")
    print(f"  Final balance: {balance_after_new}μ")
    print(f"  Total spent:   {total_spent}μ (2 executions)")
    print(f"  Replays:       21 (10 seq + 10 conc + 1 original = 0 extra spend)")
    print(f"  ✅ PASS — Idempotency is REAL and PERSISTENT")
    print(f"{'=' * 60}")

    cleanup()
    print(f"\n🟢 ALL FASE 3.1 + 3.2 TESTS PASSED")

if __name__ == "__main__":
    test()
