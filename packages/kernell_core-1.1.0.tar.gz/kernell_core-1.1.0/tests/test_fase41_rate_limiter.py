"""
FASE 4.1 — Economic Rate Limiter Test

Proves the system strictly enforces money-burning rate limits.
100 valid executions of 50,000μ each. Limit is 1,000,000μ.
Only ~20 executions should succeed. The rest should hit RATE_LIMIT_BLOCKED.
"""
import os
import sys
import uuid
import time
import threading

sys.path.insert(0, "/home/anny/kernell-os")
os.environ["USE_DB"] = "1"

from core.payments.db import get_db_connection
from core.payments.db_spend_guard import DBSpendGuard
from core.payments.db_ledger import DBLedger
from core.security.economic_rate_limiter import get_rate_limiter
from kernell_os_sdk.runtime.execution_manager import (
    ExecutionManager,
    DefaultCostEstimator,
    PreAuthorizationError,
)

TENANT = "rate_limit_tenant"
FUND_AMOUNT = 10_000_000  # 10M — enough to not run out

def cleanup():
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM idempotency_keys WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM transactions WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM holds WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM accounts WHERE tenant_id = %s", (TENANT,))

def fund():
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO accounts (tenant_id, balance_micro) VALUES (%s, %s) "
                "ON CONFLICT (tenant_id) DO UPDATE SET balance_micro = %s",
                (TENANT, FUND_AMOUNT, FUND_AMOUNT),
            )

def get_balance():
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT balance_micro FROM accounts WHERE tenant_id = %s", (TENANT,))
        row = cur.fetchone()
        return row[0] if row else 0

class CustomEstimator(DefaultCostEstimator):
    def estimate_micro(self, task) -> int:
        return 50_000
    def actual_micro(self, task, usage, est) -> int:
        return 50_000

def dummy_executor(task):
    time.sleep(0.01)
    return {"result": "ok"}, {"cost_micro": 50_000}

def flush_keys():
    import redis
    r = get_rate_limiter()._r
    for key in r.scan_iter(f"kernell:ratelimit:spend:{TENANT}:*"):
        r.delete(key)
    # Also flush risk keys to avoid RISK_BLOCKED triggering before RATE_LIMIT_BLOCKED
    for pattern in ["spend", "exec_ok", "exec_fail", "replay"]:
        key = f"kernell:risk:{pattern}:{TENANT}"
        r.delete(key)

def test():
    print("=" * 60)
    print("FASE 4.1 — Economic Rate Limiter Test")
    print("=" * 60)

    cleanup()
    fund()
    flush_keys()
    
    limiter = get_rate_limiter()
    print(f"\n✔ Limit: {limiter._limit}μ / {limiter._window}s")
    print(f"✔ Funded: {get_balance()}μ")

    guard = DBSpendGuard()
    ledger = DBLedger()
    em = ExecutionManager(
        executor=dummy_executor,
        spend_guard=guard,
        cost_estimator=CustomEstimator(),
        ledger=ledger,
    )

    success_count = 0
    blocked_count = 0
    total_spent = 0

    print(f"\n--- Running 100 rapid executions (50,000μ each) ---")
    for i in range(100):
        k = f"idem-rate-{uuid.uuid4().hex[:8]}"
        try:
            em.execute(TENANT, {"task_type": "heavy"}, idempotency_key=k)
            success_count += 1
            total_spent += 50_000
            # Need to sleep slightly so timestamps move and risk engine doesn't block FIRST
            time.sleep(0.05)
        except PreAuthorizationError as e:
            if "RATE_LIMIT_BLOCKED" in str(e):
                if blocked_count == 0:
                    print(f"  ⛔ First block at execution {i+1}: {e}")
                blocked_count += 1
            elif "RISK_BLOCKED" in str(e):
                print(f"  ⚠ RISK_BLOCKED took precedence over RATE_LIMIT. We should test RATE_LIMIT purely.")
                # We can reset risk keys to let rate limiter trigger
                from core.security.risk_engine import get_risk_engine
                r = get_risk_engine()._r
                for pattern in ["spend", "exec_ok", "exec_fail", "replay"]:
                    key = f"kernell:risk:{pattern}:{TENANT}"
                    r.delete(key)
                # Try again
                try:
                    em.execute(TENANT, {"task_type": "heavy"}, idempotency_key=k)
                    success_count += 1
                    total_spent += 50_000
                except PreAuthorizationError as e2:
                    if "RATE_LIMIT_BLOCKED" in str(e2):
                        if blocked_count == 0:
                            print(f"  ⛔ First block at execution {i+1}: {e2}")
                        blocked_count += 1

    print(f"\n--- Results ---")
    print(f"  Success: {success_count} (Expected: ~20)")
    print(f"  Blocked: {blocked_count} (Expected: ~80)")
    print(f"  Spend captured: {total_spent}μ")

    balance_final = get_balance()
    actual_spent = FUND_AMOUNT - balance_final
    print(f"  Actual spend in DB: {actual_spent}μ")

    assert success_count <= (limiter._limit // 50_000) + 1, f"Too many successes: {success_count}"
    assert actual_spent <= limiter._limit + 50_000, f"Allowed spend {actual_spent} exceeded limit {limiter._limit} by too much"
    assert blocked_count > 0, "No requests were rate limited!"

    print(f"\n  ✅ Rate Limiter strictly enforced the physical money burn rate")

    cleanup()
    flush_keys()
    print(f"\n🟢 FASE 4.1 — ECONOMIC RATE LIMITER TEST PASSED")

if __name__ == "__main__":
    test()
