"""
FASE 3 — Concurrency Stress Test
Simulates 50 concurrent pre-authorize + capture + finalize cycles
against the same tenant to verify no double-spend or balance corruption.
"""
import sys
import uuid
import threading
import time
sys.path.insert(0, "/home/anny/kernell-os")

from core.payments.db import get_db_connection
from core.payments.db_spend_guard import DBSpendGuard

TENANT = "stress_tenant"
FUND_AMOUNT = 10_000_000  # 10M micro
RESERVE_PER = 100_000     # 100k per request
CAPTURE_PER = 80_000      # 80k captured per request
CONCURRENT = 50

results = {"success": 0, "denied": 0, "errors": []}
lock = threading.Lock()

def cleanup():
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM transactions WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM holds WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM accounts WHERE tenant_id = %s", (TENANT,))

def fund():
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO accounts (tenant_id, balance_micro) VALUES (%s, %s) "
                "ON CONFLICT (tenant_id) DO UPDATE SET balance_micro = %s",
                (TENANT, FUND_AMOUNT, FUND_AMOUNT),
            )

def get_balance():
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT balance_micro FROM accounts WHERE tenant_id = %s", (TENANT,))
        row = cur.fetchone()
        return row[0] if row else 0

def worker(guard, idx):
    try:
        ok, hold_id = guard.pre_authorize(TENANT, RESERVE_PER)
        if not ok:
            with lock:
                results["denied"] += 1
            return

        guard.capture_usage(hold_id, CAPTURE_PER)
        guard.finalize_hold(hold_id)

        with lock:
            results["success"] += 1
    except Exception as e:
        with lock:
            results["errors"].append(f"Worker {idx}: {e}")

def test():
    print("=" * 60)
    print("FASE 3 — Concurrency Stress Test (50 threads)")
    print("=" * 60)

    cleanup()
    fund()
    balance_before = get_balance()
    print(f"✔ Funded: {balance_before}μ")
    print(f"  Reserve per request: {RESERVE_PER}μ")
    print(f"  Capture per request: {CAPTURE_PER}μ")
    print(f"  Max possible executions: {FUND_AMOUNT // RESERVE_PER}")
    print(f"  Concurrent threads: {CONCURRENT}")

    guard = DBSpendGuard()

    # Launch concurrent workers
    threads = []
    start = time.time()
    for i in range(CONCURRENT):
        t = threading.Thread(target=worker, args=(guard, i))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    elapsed = time.time() - start
    balance_after = get_balance()

    print(f"\n--- Results ({elapsed:.2f}s) ---")
    print(f"  Success: {results['success']}")
    print(f"  Denied:  {results['denied']}")
    print(f"  Errors:  {len(results['errors'])}")

    if results["errors"]:
        for e in results["errors"][:5]:
            print(f"    ⚠ {e}")

    # Math invariant
    expected_spent = results["success"] * CAPTURE_PER
    expected_balance = FUND_AMOUNT - expected_spent
    print(f"\n  Fund:     {FUND_AMOUNT}μ")
    print(f"  Spent:    {expected_spent}μ ({results['success']} × {CAPTURE_PER})")
    print(f"  Expected: {expected_balance}μ")
    print(f"  Actual:   {balance_after}μ")

    assert balance_after == expected_balance, (
        f"BALANCE MISMATCH: expected {expected_balance}, got {balance_after}"
    )
    assert balance_after >= 0, f"NEGATIVE BALANCE: {balance_after}"
    assert results["success"] + results["denied"] == CONCURRENT, "Thread accounting error"

    print(f"\n  ✅ INVARIANT HOLDS: No money created or destroyed under concurrency")
    print(f"  ✅ No double-spend detected")
    print(f"  ✅ No negative balance")

    # Verify all holds are finalized
    with get_db_connection() as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM holds WHERE tenant_id = %s AND status = 'active'", (TENANT,))
        active = cur.fetchone()[0]
    assert active == 0, f"Dangling active holds: {active}"
    print(f"  ✅ All holds finalized (no dangling holds)")

    cleanup()
    print(f"\n🟢 CONCURRENCY STRESS TEST PASSED")

if __name__ == "__main__":
    test()
