"""
FASE 4.4 — Chaos & Failure Testing

Simulates catastrophic failures in the system to ensure Economic Invariants are NEVER broken.
1. Redis Failure (Fail-open): Risk Engine and Rate Limiter should degrade gracefully.
2. DB Latency: Should slow down but not corrupt data.
3. DB Disconnect mid-flight: The execution should fail safely, rolling back the transaction, and Reconciler must stay consistent.
"""
import os
import sys
import uuid
import time
import threading
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, "/home/anny/kernell-os")
os.environ["USE_DB"] = "1"
os.environ["ALERT_WEBHOOK_URL"] = ""

from core.payments.db import get_db_connection
from core.payments.db_spend_guard import DBSpendGuard
from core.payments.db_ledger import DBLedger
from core.payments.reconciler import run_and_log
from kernell_os_sdk.runtime.execution_manager import (
    ExecutionManager,
    DefaultCostEstimator,
)

TENANT = "chaos_tenant"
FUND_AMOUNT = 50_000_000

def cleanup():
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute("DELETE FROM idempotency_keys WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM transactions WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM holds WHERE tenant_id = %s", (TENANT,))
            cur.execute("DELETE FROM accounts WHERE tenant_id = %s", (TENANT,))

def fund():
    with get_db_connection() as conn:
        with conn:
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO accounts (tenant_id, balance_micro) VALUES (%s, %s) "
                "ON CONFLICT (tenant_id) DO UPDATE SET balance_micro = %s",
                (TENANT, FUND_AMOUNT, FUND_AMOUNT),
            )

class ChaosEstimator(DefaultCostEstimator):
    def estimate_micro(self, task) -> int:
        return 10_000
    def actual_micro(self, task, usage, est) -> int:
        return 10_000

# ── MOCK CHAOS INJECTION ─────────────────────────────────────────

# 1. Chaos Executor
def chaos_executor(task):
    if task.get("chaos") == "slow":
        time.sleep(0.5)
    elif task.get("chaos") == "db_drop":
        # Simulate connection drop by throwing an exception
        raise Exception("OperationalError: FATAL: connection to client lost")
    return {"result": "ok"}, {"cost_micro": 10_000}

# 2. Redis Chaos Monkey
# We monkeypatch the risk engine and rate limiter to simulate Redis being down
from core.security.risk_engine import RiskEngine
from core.security.economic_rate_limiter import EconomicRateLimiter

original_evaluate = RiskEngine.evaluate
original_check = EconomicRateLimiter.check

def monkey_evaluate(self, tenant_id: str):
    if getattr(self, "chaos_down", False):
        raise Exception("Redis ConnectionError: Connection refused")
    return original_evaluate(self, tenant_id)

def monkey_check(self, tenant_id: str, estimated_micro: int):
    if getattr(self, "chaos_down", False):
        raise Exception("Redis ConnectionError: Connection refused")
    return original_check(self, tenant_id, estimated_micro)

RiskEngine.evaluate = monkey_evaluate
EconomicRateLimiter.check = monkey_check

def test():
    print("=" * 60)
    print("FASE 4.4 — Chaos & Failure Testing")
    print("=" * 60)

    cleanup()
    fund()

    guard = DBSpendGuard()
    ledger = DBLedger()
    em = ExecutionManager(
        executor=chaos_executor,
        spend_guard=guard,
        cost_estimator=ChaosEstimator(),
        ledger=ledger,
    )

    from core.security.risk_engine import get_risk_engine
    from core.security.economic_rate_limiter import get_rate_limiter
    
    re_instance = get_risk_engine()
    rl_instance = get_rate_limiter()

    successes = 0
    failures = 0

    def run_worker(chaos_type):
        nonlocal successes, failures
        try:
            em.execute(TENANT, {"task_type": "heavy", "chaos": chaos_type}, idempotency_key=f"chaos-{uuid.uuid4().hex[:8]}")
            successes += 1
        except Exception as e:
            failures += 1

    print("\n--- Phase 1: Redis Outage (Fail-Open) ---")
    re_instance.chaos_down = True
    rl_instance.chaos_down = True
    
    try:
        em.execute(TENANT, {"task_type": "heavy"}, idempotency_key=f"chaos-{uuid.uuid4().hex[:8]}")
        print("  ✅ System succeeded gracefully (Fail-Open) despite Redis connection refused.")
    except Exception as e:
        print(f"  ❌ System failed to fail-open: {e}")
        sys.exit(1)

    re_instance.chaos_down = False
    rl_instance.chaos_down = False

    print("\n--- Phase 2: Total Chaos (Latency, Redis Flaps, DB Drops, Concurrency) ---")
    
    tasks = []
    # 20 normal, 10 slow, 20 db_drop
    for _ in range(20): tasks.append("normal")
    for _ in range(10): tasks.append("slow")
    for _ in range(20): tasks.append("db_drop")

    import random
    random.shuffle(tasks)

    def chaos_loop():
        # Randomly toggle Redis outage every 0.1s
        for _ in range(20):
            re_instance.chaos_down = random.choice([True, False])
            rl_instance.chaos_down = re_instance.chaos_down
            time.sleep(0.1)
        re_instance.chaos_down = False
        rl_instance.chaos_down = False

    chaos_thread = threading.Thread(target=chaos_loop)
    chaos_thread.start()

    with ThreadPoolExecutor(max_workers=10) as executor:
        for t in tasks:
            executor.submit(run_worker, t)

    chaos_thread.join()

    print(f"  Chaos runs completed. Successes: {successes}, Failures: {failures}")
    
    # 20 normal + 10 slow + 1 phase1 = 31 expected successes
    # 20 db_drop = 20 expected failures
    
    print("\n--- Phase 3: Post-Chaos Reconciler Check ---")
    result = run_and_log()
    
    print(f"  Total Balance: {result.total_balance}μ")
    print(f"  Total Active Holds: {result.total_active_holds}μ")
    print(f"  Total Captured: {result.total_captured}μ")
    print(f"  Total Funded: {result.total_funded}μ")
    print(f"  Expected Funded: {FUND_AMOUNT}μ")

    if result.is_consistent:
        print("\n  ✅ Reconciler reports CONSISTENT state.")
    else:
        print("\n  ❌ Reconciler reports INCONSISTENT state!")
        print(f"     Negative Balances: {result.negative_balances}")
        print(f"     Orphaned Holds: {result.orphaned_holds}")
        print(f"     Overcaptures: {result.overcapture_violations}")
        sys.exit(1)

    assert result.total_funded == FUND_AMOUNT, "Money was created or destroyed!"
    assert result.is_consistent, "System state is inconsistent after chaos"

    print(f"\n🟢 FASE 4.4 — CHAOS & FAILURE TESTING PASSED")

if __name__ == "__main__":
    test()
