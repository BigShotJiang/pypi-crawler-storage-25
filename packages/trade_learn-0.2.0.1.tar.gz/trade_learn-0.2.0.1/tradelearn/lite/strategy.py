from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from tradelearn.backtest.history import build_history_panel
from tradelearn.backtest.indicator_cache import BatchIndicatorCache
from tradelearn.backtest.models import Order
from tradelearn.backtest.strategy import Strategy as CoreStrategy
from tradelearn.backtest.targets import TargetWeightSnapshot, build_target_weight_intents
from tradelearn.lite.data import LiteDataProxy, _ta_frame
from tradelearn.lite.indicator import IndicatorBundle, IndicatorProxy
from tradelearn.lite.position import PositionProxy


@dataclass(frozen=True)
class _TargetWeightSnapshots:
    prices: dict[str, float]
    sizes: dict[str, float]
    mults: dict[str, float]


class Strategy(CoreStrategy):
    """Tradelearn Lite strategy facade."""

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        user_next = cls.__dict__.get("next")
        if user_next is None or user_next is Strategy.next:
            return
        if "_next_lite_custom" not in cls.__dict__:
            cls._next_lite_custom = user_next
        cls.next = Strategy.next

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._params = self._check_params(kwargs)
        self._bt_data = None
        self._bt_position = PositionProxy(self)
        self._bt_positions: dict[str | None, PositionProxy] = {}
        self._bt_data_by_ticker: dict[str, Any] = {}
        self._indicator_cache = {}
        self._batch_indicator_cache = None
        self._bt_close_array = None
        self._bt_primary_data = None
        self._records: dict[str, pd.Series | pd.DataFrame] = {}
        self._storage: dict[str, Any] | None = None
        self._start_on_day = 0
        self._lite_target_size_by_data: dict[Any, float] = {}

    def _bind_research_result(self, result: Any) -> Any:
        from tradelearn.research.run import bind_research_result

        return bind_research_result(result, self)

    def _check_params(self, params: dict[str, Any]) -> dict[str, Any]:
        for key, value in params.items():
            if not hasattr(self, key):
                raise AttributeError(
                    f"Strategy '{self.__class__.__name__}' is missing parameter '{key}'."
                    " Strategy class should define parameters as class variables before they "
                    "can be optimized or run with."
                )
            setattr(self, key, value)
        return params

    def _setup(self):
        """Bind Tradelearn Lite facade views before init()."""
        if self._bt_data is None:
            data = self.datas[0]
            self._bt_primary_data = data
            self._bt_data = LiteDataProxy(data)
            self.data = self._bt_data
            self._bt_close_array = data.get_array("close")
            self._bt_data_by_ticker = {
                str(getattr(feed, "_name", None) or f"data{i}"): feed
                for i, feed in enumerate(self.datas)
            }
            for i, feed in enumerate(self.datas):
                setattr(self, f"data{i}", LiteDataProxy(feed))
        self._storage = getattr(self.broker, "storage", None)

    def position(self, ticker: str | None = None) -> Any:
        """Return the Tradelearn Lite position view for a ticker."""
        if ticker is None:
            return self._bt_position
        data = self._resolve_ticker_data(ticker)
        proxy = self._bt_positions.get(ticker)
        if proxy is None or proxy._data is not data:
            proxy = PositionProxy(self, ticker=ticker, data=data)
            self._bt_positions[ticker] = proxy
        return proxy

    def next(self) -> None:
        self._next_lite_custom()

    def _next_lite_custom(self) -> None:
        pass

    def I(  # noqa: E743
        self,
        funcval: Callable | pd.DataFrame | pd.Series | Any,
        *args,
        name: str | None = None,
        plot: bool = True,
        overlay: bool | None = None,
        color: str | None = None,
        scatter: bool = False,
        **kwargs,
    ) -> Any:
        """Declare a Tradelearn Lite gradually revealed indicator."""
        cache_key = self._indicator_cache_key(funcval, args, kwargs)
        cached = self._indicator_cache.get(cache_key)
        if cached is not None:
            return cached

        if callable(funcval):
            batch_cache = self._get_batch_indicator_cache()
            indicator_name = self._indicator_name(funcval, name, args, kwargs)
            line = batch_cache.precompute(
                indicator_name,
                getattr(funcval, "compute", funcval),
                *args,
                **kwargs,
            )
            values = line._values
        else:
            indicator_name = name or getattr(funcval, "name", None) or funcval.__class__.__name__
            if isinstance(funcval, pd.DataFrame):
                if not funcval.index.equals(self.data.index):
                    raise ValueError(
                        "Indicators of pd.DataFrame or pd.Series must have the same index as `data`"
                    )
                proxy = IndicatorBundle(funcval, self.datas[0], indicator_name)
                proxy.attrs.update(
                    {
                        "name": indicator_name,
                        "plot": plot,
                        "overlay": overlay,
                        "color": color,
                        "scatter": scatter,
                        **kwargs,
                    }
                )
                self._indicator_cache[cache_key] = proxy
                return proxy
            values = self._coerce_indicator_values(funcval, indicator_name)

        proxy = IndicatorProxy(values, self.datas[0], index=self.data.index, name=indicator_name)
        proxy.attrs.update(
            {
                "name": indicator_name,
                "plot": plot,
                "overlay": overlay,
                "color": color,
                "scatter": scatter,
                **kwargs,
            }
        )
        self._indicator_cache[cache_key] = proxy
        return proxy

    def _indicator_name(
        self,
        func: Callable,
        name: str | None,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> str:
        if name is not None:
            return name
        func_name = getattr(func, "name", None) or getattr(func, "__name__", None)
        if func_name is None:
            func_name = func.__class__.__name__
        if func_name == "<lambda>":
            func_name = f"{func_name}:{id(func)}"
        return str(func_name)

    def _coerce_indicator_values(self, value: Any, name: str) -> np.ndarray:
        if isinstance(value, (pd.DataFrame, pd.Series)):
            if not value.index.equals(self.data.index):
                raise ValueError(
                    "Indicators of pd.DataFrame or pd.Series must have the same index as `data`"
                )
            values = value.to_numpy()
        else:
            values = np.asarray(value, order="C")
        if values.ndim == 2 and min(values.shape) == 1:
            values = values.reshape(-1)
        if values.ndim not in (1, 2) or values.shape[0] != len(self.data.index):
            raise ValueError(
                "Indicators must have the same length as `data` "
                f'(data shape: {len(self.data.index)}; '
                f'indicator "{name}" shape: {getattr(values, "shape", "")})'
            )
        if values.ndim == 2:
            raise ValueError(
                "DataFrame-style multi-column indicators are not supported by this facade yet"
            )
        return values

    def _get_batch_indicator_cache(self) -> BatchIndicatorCache:
        if self._batch_indicator_cache is None:
            self._batch_indicator_cache = BatchIndicatorCache(self.datas[0])
        return self._batch_indicator_cache

    def _indicator_cache_key(
        self,
        func: Callable,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> tuple[Any, ...]:
        return (
            self._cache_value_key(func),
            tuple(self._cache_value_key(arg) for arg in args),
            tuple((key, self._cache_value_key(value)) for key, value in sorted(kwargs.items())),
        )

    @staticmethod
    def _cache_value_key(value: Any) -> tuple[str, Any]:
        try:
            hash(value)
        except TypeError:
            return ("id", id(value))
        return ("value", value)

    def buy(
        self,
        *,
        ticker: str = None,
        size: float = 1.0,
        limit: float = None,
        stop: float = None,
        sl: float = None,
        tp: float = None,
        tag: object = None,
    ):
        assert size > 0, "size must be a positive order quantity"
        if sl is not None or tp is not None:
            return self.buy_bracket(ticker=ticker, size=size, sl=sl, tp=tp, tag=tag)
        data = self._resolve_ticker_data(ticker)
        return self._submit_lite_order(Order.Buy, data, size, limit, stop, tag)

    def _submit_lite_order(
        self,
        side: int,
        data: Any,
        size: float,
        limit: float | None,
        stop: float | None,
        tag: object | None,
        **order_kwargs: Any,
    ) -> Any:
        broker = self.broker
        actual_size = float(abs(size))
        pending = self._pending_size
        pending_delta = actual_size if side == Order.Buy else -actual_size
        next_target_size = self._lite_position_size(data) + pending_delta
        pending[data] = pending.get(data, 0.0) + pending_delta
        self._lite_target_size_by_data[data] = next_target_size
        exectype = Order.Limit if limit else Order.Stop if stop else Order.Market
        if tag is None and not order_kwargs:
            submit = getattr(broker, "submit_basic", broker._submit)
            return submit(self, data, side, actual_size, limit or stop, exectype)
        info = dict(order_kwargs.pop("info", {}))
        if tag is not None:
            info["tag"] = tag
        return broker._submit(
            self,
            data,
            side,
            actual_size,
            limit or stop,
            exectype,
            info=info,
            **order_kwargs,
        )

    def _buy_data(
        self,
        data: Any,
        size: float | None = None,
        price: float | None = None,
        exectype: int | None = None,
        **kwargs: Any,
    ):
        limit = price if exectype == Order.Limit else None
        stop = price if exectype == Order.Stop else None
        tag = kwargs.pop("tag", None)
        info = kwargs.get("info")
        if tag is None and isinstance(info, dict):
            tag = info.get("tag")
        return self._submit_lite_order(Order.Buy, data, size or 1, limit, stop, tag, **kwargs)

    def _sell_data(
        self,
        data: Any,
        size: float | None = None,
        price: float | None = None,
        exectype: int | None = None,
        **kwargs: Any,
    ):
        limit = price if exectype == Order.Limit else None
        stop = price if exectype == Order.Stop else None
        tag = kwargs.pop("tag", None)
        info = kwargs.get("info")
        if tag is None and isinstance(info, dict):
            tag = info.get("tag")
        return self._submit_lite_order(Order.Sell, data, size or 1, limit, stop, tag, **kwargs)

    def sell(
        self,
        *,
        ticker: str = None,
        size: float = 1.0,
        limit: float = None,
        stop: float = None,
        sl: float = None,
        tp: float = None,
        tag: object = None,
    ):
        assert size > 0, "size must be a positive order quantity"
        if sl is not None or tp is not None:
            return self.sell_bracket(ticker=ticker, size=size, sl=sl, tp=tp, tag=tag)
        data = self._resolve_ticker_data(ticker)
        return self._submit_lite_order(Order.Sell, data, size, limit, stop, tag)

    def cancel(self, order: Any) -> None:
        return self.broker.cancel(order)

    def _current_price(self, data: Any) -> float:
        return float(data.get_array("close")[data._cursor])

    def _lite_position_size(self, data: Any) -> float:
        if data in self._lite_target_size_by_data:
            return float(self._lite_target_size_by_data[data])
        if bool(getattr(self.broker, "_buffer_order_submissions", False)):
            positions = getattr(self.broker, "_positions", {})
            position = positions.get(data)
            if position is not None:
                return float(position.size + self._pending_size.get(data, 0.0))
            return float(self._pending_size.get(data, 0.0))
        return float(self.getposition(data).size + self._pending_size.get(data, 0.0))

    def order_target_size(self, *, ticker: str = None, target: float = 0, **kwargs: Any):
        data = self._resolve_ticker_data(ticker)
        delta = float(target) - self._lite_position_size(data)
        if delta > 0:
            return self._buy_data(data=data, size=delta, **kwargs)
        if delta < 0:
            return self._sell_data(data=data, size=abs(delta), **kwargs)
        return None

    def order_target_value(
        self,
        *,
        ticker: str = None,
        target: float = 0.0,
        price: float | None = None,
        **kwargs: Any,
    ):
        data = self._resolve_ticker_data(ticker)
        price = float(price if price is not None else self._current_price(data))
        mult = self._position_mult(data)
        current_value = float(self.broker.getvalue(datas=[data]))
        delta = float(target) - current_value
        if abs(delta) < 1e-12:
            return None
        size = int(abs(delta) / (price * mult))
        if not size:
            return None
        if delta > 0:
            return self._buy_data(data=data, size=size, **kwargs)
        return self._sell_data(data=data, size=size, **kwargs)

    def order_target_percent(
        self,
        *,
        ticker: str = None,
        target: float = 0.0,
        **kwargs: Any,
    ):
        portfolio_value = float(self.broker.getvalue())
        return self.order_target_value(
            ticker=ticker,
            target=float(target) * portfolio_value,
            **kwargs,
        )

    def buy_bracket(
        self,
        *,
        ticker: str = None,
        size: float = 1.0,
        limit: float = None,
        stop: float = None,
        sl: float = None,
        tp: float = None,
        tag: object = None,
    ) -> list[Any]:
        kwargs = {"info": {"tag": tag}} if tag is not None else {}
        return super().buy_bracket(
            data=self._resolve_ticker_data(ticker),
            size=size,
            price=limit or stop,
            stopprice=sl,
            limitprice=tp,
            exectype=Order.Limit if limit else Order.Stop if stop else Order.Market,
            **kwargs,
        )

    def sell_bracket(
        self,
        *,
        ticker: str = None,
        size: float = 1.0,
        limit: float = None,
        stop: float = None,
        sl: float = None,
        tp: float = None,
        tag: object = None,
    ) -> list[Any]:
        kwargs = {"info": {"tag": tag}} if tag is not None else {}
        return super().sell_bracket(
            data=self._resolve_ticker_data(ticker),
            size=size,
            price=limit or stop,
            stopprice=sl,
            limitprice=tp,
            exectype=Order.Limit if limit else Order.Stop if stop else Order.Market,
            **kwargs,
        )

    def _resolve_ticker_data(self, ticker: str | None = None) -> Any:
        if ticker is None:
            return self._bt_primary_data
        if ticker in self._bt_data_by_ticker:
            return self._bt_data_by_ticker[ticker]
        if self.data is not None and ticker == self.data.the_ticker:
            return self._bt_primary_data
        raise ValueError(f"Unknown ticker {ticker!r}")

    def record(
        self,
        name: str = None,
        plot: bool = True,
        overlay: bool = None,
        color: str = None,
        scatter: bool = False,
        **kwargs,
    ) -> None:
        index = self.data.index
        row = max(0, len(self.data) - 1)
        for key, value in kwargs.items():
            if isinstance(value, (dict, pd.Series)):
                values = dict(value)
                frame = self._records.get(key)
                if not isinstance(frame, pd.DataFrame):
                    frame = pd.DataFrame(
                        index=_ta_frame(self._bt_primary_data).index,
                        columns=values.keys(),
                    )
                    self._records[key] = frame
                frame.loc[index[-1], list(values.keys())] = list(values.values())
                frame.name = name or key
                frame.attrs.update(
                    {
                        "name": name or key,
                        "plot": plot,
                        "overlay": overlay,
                        "color": color,
                        "scatter": scatter,
                    }
                )
            else:
                series = self._records.get(key)
                if not isinstance(series, pd.Series):
                    series = pd.Series(
                        index=_ta_frame(self._bt_primary_data).index,
                        dtype="float64",
                    )
                    self._records[key] = series
                series.iloc[row] = value
                series.name = name or key
                series.attrs.update(
                    {
                        "name": name or key,
                        "plot": plot,
                        "overlay": overlay,
                        "color": color,
                        "scatter": scatter,
                    }
                )

    @property
    def equity(self) -> float:
        return float(self.broker.getvalue())

    @property
    def storage(self) -> dict[str, Any] | None:
        return self._storage

    @property
    def orders(self) -> tuple[Any, ...]:
        return tuple(getattr(self.broker, "_orders", ()))

    def trades(self, ticker: str = None) -> tuple[Any, ...]:
        return tuple(getattr(self, "_trades", ()))

    @property
    def closed_trades(self) -> tuple[Any, ...]:
        return tuple(getattr(self, "_closed_trades", ()))

    def target_percent(self, ticker: str, target: float):
        """Move one ticker toward a target portfolio weight."""
        return self.order_target_percent(ticker=ticker, target=float(target))

    def history_panel(self, lookback: int | None = None) -> Any:
        """Return recent multi-asset OHLCV bars."""
        feeds = tuple((self._bt_data_by_ticker or {}).values())
        if not feeds and self._bt_primary_data is not None:
            feeds = (self._bt_primary_data,)
        return build_history_panel(feeds, lookback=lookback)

    def target_weights(
        self,
        weights: Mapping[str, float] | pd.Series,
        *,
        close_missing: bool = True,
    ) -> list[Any]:
        """Move the portfolio toward the requested ticker weights.

        ``cash`` is accepted as a reserved key and is not translated into an order.
        """
        self._lite_target_size_by_data.clear()
        data_by_ticker = self._target_weight_data_map()
        equity = float(self.broker.getvalue())
        snapshots = self._target_weight_snapshots(data_by_ticker)
        intent_snapshots = {
            ticker: TargetWeightSnapshot(
                price=snapshots.prices[ticker],
                size=snapshots.sizes[ticker],
                mult=snapshots.mults[ticker],
            )
            for ticker in data_by_ticker
        }
        intents = build_target_weight_intents(
            weights,
            data_by_symbol=data_by_ticker,
            snapshots=intent_snapshots,
            equity=equity,
            close_missing=close_missing,
            unknown_label="ticker(s)",
        )
        orders: list[Any] = []
        for intent in intents:
            data = data_by_ticker[intent.symbol]
            if intent.side == "buy":
                order = self._buy_data(data=data, size=intent.qty)
            else:
                order = self._sell_data(data=data, size=intent.qty)
            if order is not None:
                orders.append(order)
        return orders

    def _target_weight_data_map(self) -> dict[str, Any]:
        if self._bt_data_by_ticker:
            return self._bt_data_by_ticker
        return {self.data.the_ticker: self._bt_primary_data}

    def _target_weight_snapshots(self, data_by_ticker: dict[str, Any]) -> _TargetWeightSnapshots:
        prices: dict[str, float] = {}
        sizes: dict[str, float] = {}
        mults: dict[str, float] = {}
        target_sizes = self._lite_target_size_by_data
        pending = self._pending_size
        buffering = bool(getattr(self.broker, "_buffer_order_submissions", False))
        broker_positions = getattr(self.broker, "_positions", {}) if buffering else {}
        comminfo = getattr(self.broker, "_comminfo", None)
        default_mult = float(getattr(self.broker, "_mult", 1.0))
        for ticker, data in data_by_ticker.items():
            close = data.get_array("close")
            prices[ticker] = float(close[data._cursor])
            mults[ticker] = self._position_mult(data) if comminfo is not None else default_mult
            if data in target_sizes:
                sizes[ticker] = float(target_sizes[data])
            elif buffering:
                position = broker_positions.get(data)
                base_size = float(getattr(position, "size", 0.0)) if position is not None else 0.0
                sizes[ticker] = base_size + float(pending.get(data, 0.0))
            else:
                sizes[ticker] = float(self.getposition(data).size + pending.get(data, 0.0))
        return _TargetWeightSnapshots(prices=prices, sizes=sizes, mults=mults)

    def target_equal(
        self,
        tickers: Sequence[str],
        *,
        weight: float = 1.0,
        close_missing: bool = True,
    ) -> list[Any]:
        """Assign an equal combined target weight to the selected tickers."""
        tickers = [str(ticker) for ticker in tickers]
        if not tickers:
            return self.close_all() if close_missing else []
        per_ticker = float(weight) / len(tickers)
        return self.target_weights(
            {ticker: per_ticker for ticker in tickers},
            close_missing=close_missing,
        )

    def close_all(self) -> list[Any]:
        """Close all known Lite data-feed positions."""
        orders = []
        for ticker in self._bt_data_by_ticker or {self.data.the_ticker: self._bt_primary_data}:
            order = self.target_percent(str(ticker), 0.0)
            if order is not None:
                orders.append(order)
        return orders

    def start_on_day(self, n: int) -> None:
        assert 0 <= n < len(self.data.index), f"day must be within [0, {len(self.data.index)-1}]"
        self._start_on_day = int(n)
        self.addminperiod(int(n) + 1)

    def start_on_bar(self, n: int) -> None:
        """Start ``next`` no earlier than bar index ``n``."""
        self.start_on_day(n)

    @classmethod
    def prepare_data(cls, tickers: list[str], start: str) -> pd.DataFrame | None:
        return None
