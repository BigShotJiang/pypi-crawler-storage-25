"""Overlap indicators backed by pandas-ta-classic."""

import pandas as pd
import pandas_ta_classic as pta

from tradelearn.indicators.base import FunctionIndicator


def _sma(close: pd.Series, period: int = 20) -> pd.Series:
    """Simple moving average.

    NOTE: Values may differ from future ta.tdx.ma / ta.tv.sma variants.
    Choose the namespace that matches your market convention.
    """
    return pta.sma(close, length=period)


def _ema(close: pd.Series, length: int = 20) -> pd.Series:
    """Exponential moving average.

    NOTE: Values may differ from ta.tdx.ema / ta.tv.ema variants.
    Choose the namespace that matches your market convention.
    """
    return pta.ema(close, length=length)


def _bbands(close: pd.Series, length: int = 20, std: float = 2.0) -> pd.DataFrame:
    """Bollinger Bands.

    NOTE: Values may differ from future ta.tdx.boll / ta.tv.bbands variants.
    Choose the namespace that matches your market convention.
    """
    result = pta.bbands(close, length=length, std=std).iloc[:, :3].copy()
    result.columns = ["lower", "mid", "upper"]
    return result


def _stream_sma(
    buffers: dict[str, list[float]],
    state: dict[str, float],
    params: dict[str, object],
) -> float:
    period = int(params.get("period", 20))
    close = buffers["close"]
    running_sum = float(state.get("sum", 0.0)) + close[-1]
    if len(close) > period:
        running_sum -= close[-period - 1]
    state["sum"] = running_sum
    if len(close) < period:
        return float("nan")
    return running_sum / period


sma = FunctionIndicator(
    "sma",
    _sma,
    {"period": 20},
    bar_columns=("close",),
    stream_func=_stream_sma,
)
ema = FunctionIndicator("ema", _ema, {"length": 20}, bar_columns=("close",))
bbands = FunctionIndicator("bbands", _bbands, {"length": 20, "std": 2.0}, bar_columns=("close",))
