from .ERPNext import ERPNextLibrary
from robotlibcore import DynamicCore

class ERPNext(DynamicCore):
    """
    RPA.ERPNext Library
    A library for interacting with Frappe/ERPNext via REST API.
    """
    def __init__(self):
        libraries = [ERPNextLibrary()]
        super().__init__(libraries)
