# RPA.ERPNext

Library for automating [ERPNext](https://erpnext.com/) using REST API, built for [Robot Framework](https://robotframework.org/).

## Installation

```bash
pip install rpa-erpnext
```
