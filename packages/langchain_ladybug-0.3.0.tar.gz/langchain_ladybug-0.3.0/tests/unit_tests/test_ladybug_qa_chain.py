"""Unit tests for LadybugQAChain."""

import pytest

from langchain_ladybug.chains.ladybug_qa import extract_cypher, remove_prefix


def test_remove_prefix_removes_when_present() -> None:
    assert remove_prefix("cypher MATCH (n) RETURN n", "cypher") == " MATCH (n) RETURN n"


def test_remove_prefix_unchanged_when_absent() -> None:
    assert remove_prefix("MATCH (n) RETURN n", "cypher") == "MATCH (n) RETURN n"


def test_remove_prefix_empty_string() -> None:
    assert remove_prefix("", "cypher") == ""


def test_extract_cypher_with_backticks() -> None:
    text = "Here is the query:\n```MATCH (n) RETURN n```"
    assert extract_cypher(text) == "MATCH (n) RETURN n"


def test_extract_cypher_without_backticks() -> None:
    text = "MATCH (n) RETURN n"
    assert extract_cypher(text) == "MATCH (n) RETURN n"


def test_extract_cypher_returns_first_match() -> None:
    text = "```first```\n```second```"
    assert extract_cypher(text) == "first"


def test_ladybug_qa_chain_requires_dangerous_requests() -> None:
    """Constructing LadybugQAChain without opt-in should raise ValueError."""
    from unittest.mock import MagicMock

    from langchain_ladybug.chains.ladybug_qa import LadybugQAChain

    mock_graph = MagicMock()
    mock_chain = MagicMock()

    with pytest.raises(ValueError, match="allow_dangerous_requests"):
        LadybugQAChain(
            graph=mock_graph,
            cypher_generation_chain=mock_chain,
            qa_chain=mock_chain,
            allow_dangerous_requests=False,
        )
