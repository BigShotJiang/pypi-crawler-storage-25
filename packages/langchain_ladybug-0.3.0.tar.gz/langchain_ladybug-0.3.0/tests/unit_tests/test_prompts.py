"""Unit tests for Ladybug prompt templates."""

from langchain_ladybug.chains.prompts import (
    CYPHER_QA_PROMPT,
    LADYBUG_GENERATION_PROMPT,
)


def test_ladybug_generation_prompt_variables() -> None:
    assert set(LADYBUG_GENERATION_PROMPT.input_variables) == {"schema", "question"}


def test_ladybug_generation_prompt_contains_rules() -> None:
    template = LADYBUG_GENERATION_PROMPT.template
    assert "()-[]->()" in template
    assert "triple backticks" in template


def test_cypher_qa_prompt_variables() -> None:
    assert set(CYPHER_QA_PROMPT.input_variables) == {"context", "question"}


def test_cypher_qa_prompt_format() -> None:
    result = CYPHER_QA_PROMPT.format(
        context="[manager:CTL LLC]",
        question="Which managers own Neo4j stocks?",
    )
    assert "CTL LLC" in result
    assert "Neo4j stocks" in result
