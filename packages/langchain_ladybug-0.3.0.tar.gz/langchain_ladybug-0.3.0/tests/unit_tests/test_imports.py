"""Verify that all public symbols can be imported from the package."""


def test_ladybug_graph_importable() -> None:
    from langchain_ladybug.graphs import LadybugGraph  # noqa: F401


def test_ladybug_qa_chain_importable() -> None:
    from langchain_ladybug.chains import LadybugQAChain  # noqa: F401


def test_graph_document_importable() -> None:
    from langchain_community.graphs.graph_document import (  # noqa: F401
        GraphDocument,
        Node,
        Relationship,
    )


def test_prompts_importable() -> None:
    from langchain_ladybug.chains import (  # noqa: F401
        CYPHER_QA_PROMPT,
        LADYBUG_GENERATION_PROMPT,
    )


def test_top_level_importable() -> None:
    import langchain_ladybug  # noqa: F401

    assert hasattr(langchain_ladybug, "LadybugGraph")
    assert hasattr(langchain_ladybug, "LadybugQAChain")
