"""Question answering over a graph."""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional

from langchain_classic.chains.base import Chain
from langchain_classic.chains.llm import LLMChain
from langchain_core.callbacks import CallbackManagerForChainRun
from langchain_core.language_models import BaseLanguageModel
from langchain_core.prompts import BasePromptTemplate
from pydantic import Field

from langchain_ladybug.chains.prompts import CYPHER_QA_PROMPT, LADYBUG_GENERATION_PROMPT
from langchain_ladybug.graphs.ladybug_graph import LadybugGraph


def remove_prefix(text: str, prefix: str) -> str:
    """Remove a prefix from a text string.

    Args:
        text: Text to remove the prefix from.
        prefix: Prefix to remove from the text.

    Returns:
        Text with the prefix removed, or the original text if it does not start
        with the prefix.
    """
    if text.startswith(prefix):
        return text[len(prefix):]
    return text


def extract_cypher(text: str) -> str:
    """Extract Cypher code from a text string.

    Looks for Cypher code enclosed in triple backticks.

    Args:
        text: Text to extract Cypher code from.

    Returns:
        Cypher code extracted from the first triple-backtick block, or the
        original text if no such block is found.
    """
    pattern = r"```(.*?)```"
    matches = re.findall(pattern, text, re.DOTALL)
    return matches[0] if matches else text


class LadybugQAChain(Chain):
    """Question-answering against a graph by generating Cypher statements for Ladybug.

    *Security note*: Make sure that the database connection uses credentials
        that are narrowly-scoped to only include necessary permissions.
        Failure to do so may result in data corruption or loss, since the calling
        code may attempt commands that would result in deletion, mutation
        of data if appropriately prompted or reading sensitive data if such
        data is present in the database.
        The best way to guard against such negative outcomes is to (as appropriate)
        limit the permissions granted to the credentials used with this tool.

        See https://python.langchain.com/docs/security for more information.
    """

    graph: LadybugGraph = Field(exclude=True)
    cypher_generation_chain: LLMChain
    qa_chain: LLMChain
    input_key: str = "query"
    output_key: str = "result"

    allow_dangerous_requests: bool = False
    """Forced user opt-in to acknowledge that the chain can make dangerous requests.

    *Security note*: Make sure that the database connection uses credentials
        that are narrowly-scoped to only include necessary permissions.
        Failure to do so may result in data corruption or loss, since the calling
        code may attempt commands that would result in deletion, mutation
        of data if appropriately prompted or reading sensitive data if such
        data is present in the database.
        The best way to guard against such negative outcomes is to (as appropriate)
        limit the permissions granted to the credentials used with this tool.

        See https://python.langchain.com/docs/security for more information.
    """

    def __init__(self, **kwargs: Any) -> None:
        """Initialize the chain.

        Raises:
            ValueError: If `allow_dangerous_requests` is not `True`.
        """
        if not kwargs.get("allow_dangerous_requests"):
            raise ValueError(
                "In order to use this chain, you must acknowledge that it can make "
                "dangerous requests by setting `allow_dangerous_requests` to `True`. "
                "You must narrowly scope the permissions of the database connection "
                "to only include necessary permissions. Failure to do so may result "
                "in data corruption or loss or reading sensitive data if such data is "
                "present in the database. "
                "Only use this chain if you understand the risks and have taken the "
                "necessary precautions. "
                "See https://python.langchain.com/docs/security for more information."
            )
        super().__init__(**kwargs)

    @property
    def input_keys(self) -> List[str]:
        """Return the input keys."""
        return [self.input_key]

    @property
    def output_keys(self) -> List[str]:
        """Return the output keys."""
        return [self.output_key]

    @classmethod
    def from_llm(
        cls,
        llm: Optional[BaseLanguageModel] = None,
        *,
        qa_prompt: BasePromptTemplate = CYPHER_QA_PROMPT,
        cypher_prompt: BasePromptTemplate = LADYBUG_GENERATION_PROMPT,
        cypher_llm: Optional[BaseLanguageModel] = None,
        qa_llm: Optional[BaseLanguageModel] = None,
        **kwargs: Any,
    ) -> LadybugQAChain:
        """Initialize from an LLM.

        Args:
            llm: A language model to use for both Cypher generation and QA when
                separate models are not provided.
            qa_prompt: Prompt template for the QA step.
            cypher_prompt: Prompt template for the Cypher generation step.
            cypher_llm: A language model dedicated to Cypher generation. If
                provided, `llm` is used only for QA unless `qa_llm` is also given.
            qa_llm: A language model dedicated to the QA step. If provided,
                `llm` is used only for Cypher generation unless `cypher_llm` is
                also given.
            **kwargs: Additional keyword arguments passed to the chain constructor.

        Returns:
            A configured `LadybugQAChain` instance.

        Raises:
            ValueError: If neither `llm` nor `cypher_llm` is provided, neither
                `llm` nor `qa_llm` is provided, or all three of `llm`,
                `cypher_llm`, and `qa_llm` are provided simultaneously.
        """
        if not cypher_llm and not llm:
            raise ValueError("Either `llm` or `cypher_llm` parameters must be provided")
        if not qa_llm and not llm:
            raise ValueError(
                "Either `llm` or `qa_llm` parameters must be provided along with"
                " `cypher_llm`"
            )
        if cypher_llm and qa_llm and llm:
            raise ValueError(
                "You can specify up to two of 'cypher_llm', 'qa_llm'"
                ", and 'llm', but not all three simultaneously."
            )

        qa_chain = LLMChain(
            llm=qa_llm or llm,  # type: ignore[arg-type]
            prompt=qa_prompt,
        )
        cypher_generation_chain = LLMChain(
            llm=cypher_llm or llm,  # type: ignore[arg-type]
            prompt=cypher_prompt,
        )

        return cls(
            qa_chain=qa_chain,
            cypher_generation_chain=cypher_generation_chain,
            **kwargs,
        )

    def _call(
        self,
        inputs: Dict[str, Any],
        run_manager: Optional[CallbackManagerForChainRun] = None,
    ) -> Dict[str, str]:
        """Generate a Cypher statement, query the graph, and answer the question.

        Args:
            inputs: Dictionary containing the input question under `input_key`.
            run_manager: Optional callback manager for tracing and logging.

        Returns:
            Dictionary with the answer under `output_key`.
        """
        _run_manager = run_manager or CallbackManagerForChainRun.get_noop_manager()
        callbacks = _run_manager.get_child()
        question = inputs[self.input_key]

        generated_cypher = self.cypher_generation_chain.run(
            {"question": question, "schema": self.graph.get_schema}, callbacks=callbacks
        )
        generated_cypher = remove_prefix(extract_cypher(generated_cypher), "cypher")

        _run_manager.on_text("Generated Cypher:", end="\n", verbose=self.verbose)
        _run_manager.on_text(
            generated_cypher, color="green", end="\n", verbose=self.verbose
        )
        context = self.graph.query(generated_cypher)

        _run_manager.on_text("Full Context:", end="\n", verbose=self.verbose)
        _run_manager.on_text(
            str(context), color="green", end="\n", verbose=self.verbose
        )

        result = self.qa_chain(
            {"question": question, "context": context},
            callbacks=callbacks,
        )
        return {self.output_key: result[self.qa_chain.output_key]}
