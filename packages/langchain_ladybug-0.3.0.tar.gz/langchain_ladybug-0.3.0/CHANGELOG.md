# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2026-05-07

### Added

- Initial release of `langchain-ladybug`, based on [@adsharma](https://github.com/adsharma)'s port of the Kuzu LangChain integration to Ladybug ([langchain-community PR #438](https://github.com/langchain-ai/langchain-community/pull/438)).
- `LadybugGraph` — LangChain graph wrapper for the [Ladybug](https://github.com/ladybug-ai/ladybug) graph database with support for:
  - Schema introspection via `refresh_schema` and `get_schema`.
  - Cypher query execution via `query`.
  - Document ingestion via `add_graph_documents`, including optional source chunk tracking with `MENTIONS` relationships.
- `LadybugQAChain` — question-answering chain that translates natural language to Ladybug-dialect Cypher and returns grounded answers from the graph.
- `LADYBUG_GENERATION_PROMPT` — prompt template for Ladybug-dialect Cypher generation, enforcing correct relationship pattern syntax (`()-[]->()`) and clean output.
- `CYPHER_QA_PROMPT` — prompt template for producing human-readable answers from Cypher query results.
- Support for separate `cypher_llm` and `qa_llm` models in `LadybugQAChain.from_llm`.
