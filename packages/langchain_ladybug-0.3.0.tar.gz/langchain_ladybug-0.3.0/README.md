# langchain-ladybug

LangChain integration for the [Ladybug](https://github.com/ladybug-ai/ladybug) graph database.

This package provides:

- **`LadybugGraph`** — a LangChain graph wrapper for Ladybug that supports schema introspection, Cypher queries, and document ingestion via `add_graph_documents`.
- **`LadybugQAChain`** — a question-answering chain that generates Ladybug-dialect Cypher queries from natural language and returns answers grounded in the graph.
- Prompt templates (`LADYBUG_GENERATION_PROMPT`, `CYPHER_QA_PROMPT`) tuned for the Ladybug Cypher dialect.

## Installation

```bash
uv pip install langchain-ladybug
```

The `ladybug` Python package must also be installed:

```bash
uv pip install ladybug
```

## Quick Start

```python
import ladybug as lb
from langchain_ladybug import LadybugGraph, LadybugQAChain
from langchain_openai import ChatOpenAI

db = lb.Database("/path/to/my.db")

graph = LadybugGraph(db)

llm = ChatOpenAI(model="gpt-4o", temperature=0)

chain = LadybugQAChain.from_llm(
    llm=llm,
    graph=graph,
)

answer = chain.invoke({"query": "Who acted in The Godfather?"})
print(answer["result"])
```

## Development

```bash
# Install dependencies
uv sync

# Run unit tests
make test

# Lint
make lint

# Format
make format
```

## Acknowledgements

Started from the Kuzu → Ladybug LangChain support port by [@adsharma](https://github.com/adsharma) ([PR #438](https://github.com/langchain-ai/langchain-community/pull/438)) — a proposed LadybugDB (formerly Kuzu) integration into the upstream langchain-community repo


## Project Structure

```
langchain_ladybug/
├── graphs/
│   ├── graph_document.py   # Node, Relationship, GraphDocument data classes
│   └── ladybug_graph.py    # LadybugGraph wrapper
└── chains/
    ├── prompts.py           # Ladybug-dialect Cypher prompt templates
    └── ladybug_qa.py        # LadybugQAChain
tests/
├── unit_tests/             # No network calls
└── integration_tests/      # Requires ladybug
```
