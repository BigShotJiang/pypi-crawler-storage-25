"""Function registry primitives."""
