# Answers Lib

Library to interact with Expert AI Answers engine.

## Installation

```bash
pip install eai-answers-lib
```

## Usage

```python
from eai_answers_lib import Answers

a = Answers()
result = a.get_answers(query="Your question")
```

## Authentication

```python
a = Answers(
    enable_auth=True,
    client_id="your-client-id",
    client_secret="your-client-secret"
)
```

## Environment Variables

- `ANSWERS_ENDPOINT` - API endpoint URL
- `ANSWERS_CLIENT_ID` - Client ID for authentication
- `ANSWERS_CLIENT_SECRET` - Client secret for authentication