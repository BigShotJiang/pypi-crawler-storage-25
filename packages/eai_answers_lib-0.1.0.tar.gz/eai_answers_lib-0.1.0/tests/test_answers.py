import pytest
import responses
from src import Answers


responses.mock.start()
responses.mock.register_uri(
    responses.POST,
    "https://api.example.com/auth/realms/test-realm/protocol/openid-connect/token",
    json={"access_token": "test-token", "expires_in": 3600},
    status=200,
)


@pytest.fixture
def mock_endpoint():
    return "https://api.example.com"


@pytest.fixture
def answers(mock_endpoint):
    return Answers(endpoint=mock_endpoint, enable_auth=False)


@pytest.fixture
def answers_with_auth(mock_endpoint):
    return Answers(
        endpoint=mock_endpoint,
        enable_auth=True,
        auth_path="auth",
        realm="test-realm",
        client_id="test-client",
        client_secret="test-secret",
    )


class TestInit:
    def test_init_success(self, mock_endpoint):
        answers = Answers(endpoint=mock_endpoint)
        assert answers.endpoint == mock_endpoint

    def test_init_missing_endpoint_raises(self):
        with pytest.raises(ValueError, match="endpoint must be provided"):
            Answers(endpoint=None)

    def test_init_with_auth(self, mock_endpoint):
        answers = Answers(
            endpoint=mock_endpoint,
            enable_auth=True,
            auth_path="auth",
            realm="test-realm",
            client_id="client",
            client_secret="secret",
        )
        assert answers.enable_auth is True
        assert answers.auth_path == "auth"
        assert answers.realm == "test-realm"

    def test_init_default_paths(self, mock_endpoint):
        answers = Answers(endpoint=mock_endpoint)
        assert answers.query_path == "v1/query"
        assert answers.status_path == "v1/status"


def test_refresh_bearer_success(answers_with_auth):
    responses.mock.register_uri(
        responses.POST,
        "https://api.example.com/auth/realms/test-realm/protocol/openid-connect/token",
        json={"access_token": "new-token", "expires_in": 3600},
        status=200,
    )
    answers_with_auth.refresh_bearer()
    assert answers_with_auth.bearer == "new-token"
    assert answers_with_auth.token_expiration > 0


def test_refresh_bearer_failure(answers_with_auth):
    responses.mock.register_uri(
        responses.POST,
        "https://api.example.com/auth/realms/test-realm/protocol/openid-connect/token",
        status=401,
    )
    with pytest.raises(Exception, match="Error Refreshing authentication Bearer"):
        answers_with_auth.refresh_bearer()


def test_get_auth_header_no_auth(answers):
    headers = answers.get_auth_header()
    assert headers == {}


def test_get_auth_header_with_auth(answers_with_auth):
    headers = answers_with_auth.get_auth_header()
    assert headers == {"Authorization": "Bearer test-token"}


@responses.activate
def test_start_query_task_success(answers):
    responses.post(
        "https://api.example.com/v1/query/pkg/collection",
        json={"success": True, "data": {"task_id": "task-123"}},
        status=200,
    )
    task_id = answers.start_query_task(payload={}, headers={}, pkg="pkg", collection="collection")
    assert task_id == "task-123"


@responses.activate
def test_start_query_task_failure(answers):
    responses.post(
        "https://api.example.com/v1/query/pkg/collection",
        json={"success": False, "data": {"error": "failed"}},
        status=200,
    )
    with pytest.raises(Exception):
        answers.start_query_task(payload={}, headers={}, pkg="pkg", collection="collection")


@responses.activate
def test_poll_query_status_success(answers):
    responses.get(
        "https://api.example.com/v1/status/task-123",
        json={"success": True, "data": {"completed": True, "query_tasks": ["t1"], "completed_tasks": ["t1"]}},
        status=200,
    )
    status = answers.poll_query_status(task_id="task-123", headers={})
    assert status["success"] is True
    assert status["data"]["completed"] is True


@responses.activate
def test_poll_query_status_failure(answers):
    responses.get(
        "https://api.example.com/v1/status/task-123",
        json={"success": False, "messages": ["error"]},
        status=200,
    )
    status = answers.poll_query_status(task_id="task-123", headers={})
    assert status["success"] is False


@responses.activate
def test_call_full_flow(answers):
    responses.post(
        "https://api.example.com/v1/query/pkg/collection",
        json={"success": True, "data": {"task_id": "task-456"}},
        status=200,
    )
    responses.get(
        "https://api.example.com/v1/status/task-456",
        json={"success": True, "data": {"completed": True}},
        status=200,
    )
    result = answers(payload={}, pkg="pkg", collection="collection")
    assert result["success"] is True
    assert result["data"]["completed"] is True