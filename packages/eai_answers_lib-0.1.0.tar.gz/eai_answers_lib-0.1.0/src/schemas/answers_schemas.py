
from typing import Any, Dict, Optional, Union, List, Literal
from pydantic import BaseModel


    
    
class PackageAndCollection(BaseModel):
    kb: str
    description: str # collection description
    id: str # collection id
    
class CollectionDocument(BaseModel):
    data: str
    dataAnnotation: Optional[str] = None
    dataXml: Optional[str] = None
    dataJson: Optional[Dict[Any, Any]] = None
    size: Optional[int] = None
    name: str

class AddCollectionRequest(BaseModel):
    cogitoAnalysisMode: Optional[str] = None
    removeAnnotations: Optional[bool] = True
    ocr: Optional[bool] = False
    doubleColumn: Optional[bool] = False
    pageImages: Optional[bool] = False
    indexStrategies: List[str]
    engine: str
    analyzer: Optional[str] = None
    status: Optional[str] = None
    messages: Optional[List[Dict[str, str]]] = None
    documents: List[CollectionDocument]
    pkg: str
    collection: str

