# neuronx-sdk

Python SDK for the [NeuronX AI Platform](https://neuronx.jagatab.uk) — 19 free LLMs, 185K+ code patterns, autonomous agents.

## Install

```bash
pip install neuronx-sdk
```

## Quick Start

```python
from neuronx import NeuronX

nx = NeuronX(api_key="nx-YOUR_KEY")

# Chat with 19 free LLM providers
response = nx.chat("explain quicksort in Python")
print(response.text)

# Generate code using 185K+ patterns
code = nx.codegen("REST API with JWT auth", language="python")
print(code.code)

# AI-powered search
results = nx.search("transformer attention mechanism")
print(results.summary)

# Problem solving
solution = nx.solve("optimize database queries for 1M rows")
print(solution.response)
```

## License

MIT
