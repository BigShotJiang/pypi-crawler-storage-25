"""AI Code Reviewer using NeuronX SDK.

Run:
    python examples/code_reviewer.py [file_path]

Reviews code for security issues, bugs, and best practices using Guard.
Also searches NeuronX's 28K+ pattern database for related patterns.
"""

import sys
from neuronx import NeuronX


def review_file(filepath: str):
    nx = NeuronX(base_url="http://localhost:8000", timeout=60)

    with open(filepath) as f:
        code = f.read()

    ext = filepath.rsplit(".", 1)[-1] if "." in filepath else "python"
    lang_map = {"py": "python", "js": "javascript", "ts": "typescript", "go": "go", "rs": "rust"}
    language = lang_map.get(ext, ext)

    print(f"Reviewing {filepath} ({language})...")
    print("=" * 50)

    # Guard review
    review = nx.review(code, language=language, filename=filepath)
    print(f"\nIssues found: {review.issues_found}")
    for issue in review.issues:
        loc = f"line {issue.line}" if issue.line else ""
        print(f"  [{issue.severity}] {issue.message} {loc}")
        if issue.suggestion:
            print(f"    Fix: {issue.suggestion}")

    # Pattern search for related best practices
    print(f"\nRelated patterns from 28K+ database:")
    patterns = nx.patterns.search(language, limit=3)
    for p in patterns.patterns:
        print(f"  - {p.name}: {p.code[:80]}...")

    nx.close()


def review_snippet():
    """Review code pasted via stdin."""
    nx = NeuronX(base_url="http://localhost:8000", timeout=60)

    samples = [
        ("eval(user_input)", "Eval injection"),
        ("os.system(f'rm -rf {path}')", "Command injection"),
        ("password = 'admin123'", "Hardcoded password"),
    ]

    print("NeuronX Code Review Demo")
    print("=" * 50)

    for code, label in samples:
        print(f"\n--- {label} ---")
        print(f"Code: {code}")
        review = nx.review(code)
        print(f"Issues: {review.issues_found}")
        for issue in review.issues:
            print(f"  [{issue.severity}] {issue.message}")

    nx.close()


if __name__ == "__main__":
    if len(sys.argv) > 1:
        review_file(sys.argv[1])
    else:
        review_snippet()
