"""Interactive AI Chatbot using NeuronX SDK.

Run:
    python examples/chatbot.py

Uses NeuronX's 19 free LLM providers with smart routing.
"""

from neuronx import NeuronX

def main():
    nx = NeuronX(base_url="http://localhost:8000")

    print("NeuronX Chatbot (type 'quit' to exit)")
    print("=" * 40)

    while True:
        user_input = input("\nYou: ").strip()
        if not user_input or user_input.lower() in ("quit", "exit"):
            break

        try:
            response = nx.chat(user_input)
            print(f"\nAI ({response.engine}): {response.text}")
        except Exception as e:
            print(f"\nError: {e}")

    nx.close()
    print("Goodbye!")


if __name__ == "__main__":
    main()
