"""AI Search Engine using NeuronX SDK.

Run:
    python examples/search_engine.py

Demonstrates AI-powered search with 3 engines and Knowledge Graph exploration.
"""

from neuronx import NeuronX


def main():
    nx = NeuronX(base_url="http://localhost:8000", timeout=30)

    print("NeuronX AI Search Engine")
    print("=" * 40)

    query = input("\nSearch: ").strip() or "python async patterns"

    # AI Search
    print(f"\nSearching for: {query}")
    results = nx.search(query)

    if results.summary:
        print(f"\nAI Summary: {results.summary}")

    print(f"\nResults ({results.total}):")
    for i, item in enumerate(results.items, 1):
        print(f"  {i}. {item.title}")
        if item.url:
            print(f"     {item.url}")
        if item.snippet:
            print(f"     {item.snippet[:100]}...")

    # Knowledge Graph context
    print(f"\nKnowledge Graph for '{query.split()[0]}':")
    kg = nx.kg.query(query.split()[0], depth=2)
    for node in kg.results[:5]:
        print(f"  {node.label} ({node.relationship}, weight={node.weight})")

    nx.close()


if __name__ == "__main__":
    main()
