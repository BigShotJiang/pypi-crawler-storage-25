"""Autonomous Agent Builder using NeuronX SDK.

Run:
    python examples/agent_builder.py

Demonstrates launching autonomous agents, waiting for results,
and using marketplace agents.
"""

from neuronx import NeuronX


def main():
    nx = NeuronX(base_url="http://localhost:8000", timeout=60)

    # List available tools
    print("Available Agent Tools:")
    print("=" * 40)
    tools = nx.agents.list_tools()
    for t in tools:
        print(f"  {t.name}: {t.description}")

    # Launch an agent task
    print("\nLaunching agent task...")
    task = nx.agents.run("Analyze the top code patterns and suggest improvements")
    print(f"Task ID: {task.task_id}")
    print(f"Status: {task.status}")

    # Wait for completion
    print("Waiting for agent to complete...")
    result = nx.agents.wait(task.task_id, poll_interval=3, timeout=120)
    print(f"\nStatus: {result.status}")
    print(f"Success: {result.success}")
    print(f"Result:\n{result.result}")

    # Marketplace agents
    print("\n" + "=" * 40)
    print("Marketplace Agents:")
    agents = nx.marketplace.list()
    for a in agents:
        print(f"  {a.id}: {a.name} - {a.description[:60]}...")
        print(f"    Rating: {a.rating}, Installs: {a.installs}")

    nx.close()


if __name__ == "__main__":
    main()
