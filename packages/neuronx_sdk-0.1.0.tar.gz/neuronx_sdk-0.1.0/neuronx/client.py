"""HTTP client for NeuronX API with auth, retries, and error handling."""

from __future__ import annotations

import time
from typing import Any, AsyncIterator, Iterator

import httpx

from .exceptions import (
    AuthenticationError,
    NeuronXError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)

DEFAULT_BASE_URL = "https://neuronx.jagatab.uk"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 2
RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}


def _raise_for_status(response: httpx.Response) -> None:
    """Raise a typed NeuronX exception for HTTP errors."""
    if response.is_success:
        return

    try:
        body = response.json()
    except Exception:
        body = {"detail": response.text}

    msg = body.get("detail", body.get("error", body.get("message", response.text)))
    kwargs = {"status_code": response.status_code, "response": body}

    if response.status_code == 401:
        raise AuthenticationError(f"Authentication failed: {msg}", **kwargs)
    if response.status_code == 403:
        raise AuthenticationError(f"Forbidden: {msg}", **kwargs)
    if response.status_code == 404:
        raise NotFoundError(f"Not found: {msg}", **kwargs)
    if response.status_code == 422:
        raise ValidationError(f"Validation error: {msg}", **kwargs)
    if response.status_code == 429:
        retry_after = response.headers.get("retry-after")
        raise RateLimitError(
            f"Rate limit exceeded: {msg}",
            retry_after=float(retry_after) if retry_after else None,
            **kwargs,
        )
    if response.status_code >= 500:
        raise ServerError(f"Server error: {msg}", **kwargs)
    raise NeuronXError(f"HTTP {response.status_code}: {msg}", **kwargs)


class NeuronXClient:
    """Synchronous HTTP client for the NeuronX API."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        self.base_url = base_url.rstrip("/")
        self.max_retries = max_retries
        headers = {"Accept": "application/json"}
        if api_key:
            headers["X-API-Key"] = api_key
        self._client = httpx.Client(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
        )

    def request(self, method: str, path: str, **kwargs) -> dict[str, Any]:
        """Make an HTTP request with retries."""
        last_exc: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                response = self._client.request(method, path, **kwargs)
                if response.status_code in RETRYABLE_STATUS_CODES and attempt < self.max_retries:
                    wait = 2 ** attempt
                    if response.status_code == 429:
                        retry_after = response.headers.get("retry-after")
                        if retry_after:
                            wait = float(retry_after)
                    time.sleep(wait)
                    continue
                _raise_for_status(response)
                return response.json()
            except httpx.TimeoutException as e:
                last_exc = TimeoutError(f"Request timed out: {e}")
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)
                    continue
            except (httpx.ConnectError, httpx.RemoteProtocolError) as e:
                last_exc = NeuronXError(f"Connection error: {e}")
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)
                    continue
        raise last_exc  # type: ignore[misc]

    def get(self, path: str, **kwargs) -> dict[str, Any]:
        return self.request("GET", path, **kwargs)

    def post(self, path: str, **kwargs) -> dict[str, Any]:
        return self.request("POST", path, **kwargs)

    def stream_sse(self, method: str, path: str, **kwargs) -> Iterator[dict[str, Any]]:
        """Stream Server-Sent Events."""
        import json
        with self._client.stream(method, path, **kwargs) as response:
            _raise_for_status(response)
            buffer = ""
            for chunk in response.iter_text():
                buffer += chunk
                while "\n\n" in buffer:
                    event, buffer = buffer.split("\n\n", 1)
                    for line in event.split("\n"):
                        if line.startswith("data: "):
                            data = line[6:]
                            if data.strip() == "[DONE]":
                                return
                            try:
                                yield json.loads(data)
                            except json.JSONDecodeError:
                                yield {"text": data}

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class AsyncNeuronXClient:
    """Async HTTP client for the NeuronX API."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ):
        self.base_url = base_url.rstrip("/")
        self.max_retries = max_retries
        headers = {"Accept": "application/json"}
        if api_key:
            headers["X-API-Key"] = api_key
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers=headers,
            timeout=timeout,
        )

    async def request(self, method: str, path: str, **kwargs) -> dict[str, Any]:
        """Make an async HTTP request with retries."""
        import asyncio
        last_exc: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                response = await self._client.request(method, path, **kwargs)
                if response.status_code in RETRYABLE_STATUS_CODES and attempt < self.max_retries:
                    wait = 2 ** attempt
                    if response.status_code == 429:
                        retry_after = response.headers.get("retry-after")
                        if retry_after:
                            wait = float(retry_after)
                    await asyncio.sleep(wait)
                    continue
                _raise_for_status(response)
                return response.json()
            except httpx.TimeoutException as e:
                last_exc = TimeoutError(f"Request timed out: {e}")
                if attempt < self.max_retries:
                    await asyncio.sleep(2 ** attempt)
                    continue
            except (httpx.ConnectError, httpx.RemoteProtocolError) as e:
                last_exc = NeuronXError(f"Connection error: {e}")
                if attempt < self.max_retries:
                    await asyncio.sleep(2 ** attempt)
                    continue
        raise last_exc  # type: ignore[misc]

    async def get(self, path: str, **kwargs) -> dict[str, Any]:
        return await self.request("GET", path, **kwargs)

    async def post(self, path: str, **kwargs) -> dict[str, Any]:
        return await self.request("POST", path, **kwargs)

    async def stream_sse(self, method: str, path: str, **kwargs) -> AsyncIterator[dict[str, Any]]:
        """Stream Server-Sent Events (async)."""
        import json
        async with self._client.stream(method, path, **kwargs) as response:
            _raise_for_status(response)
            buffer = ""
            async for chunk in response.aiter_text():
                buffer += chunk
                while "\n\n" in buffer:
                    event, buffer = buffer.split("\n\n", 1)
                    for line in event.split("\n"):
                        if line.startswith("data: "):
                            data = line[6:]
                            if data.strip() == "[DONE]":
                                return
                            try:
                                yield json.loads(data)
                            except json.JSONDecodeError:
                                yield {"text": data}

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()
