"""Marketplace agents module — nx.marketplace wraps /api/marketplace/* endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .models import MarketplaceAgent, MarketplaceResponse

if TYPE_CHECKING:
    from .client import AsyncNeuronXClient, NeuronXClient


class Marketplace:
    """Synchronous marketplace interface."""

    def __init__(self, client: NeuronXClient):
        self._client = client

    def list(self) -> list[MarketplaceAgent]:
        """List all available marketplace agents.

        Returns:
            List of MarketplaceAgent with .id, .name, .description, etc.
        """
        data = self._client.get("/api/marketplace/agents")
        return [
            MarketplaceAgent(
                id=a.get("id", ""),
                name=a.get("name", ""),
                description=a.get("description", ""),
                category=a.get("category", ""),
                author=a.get("author", ""),
                version=a.get("version", ""),
                rating=a.get("rating", 0.0),
                installs=a.get("installs", 0),
            )
            for a in data.get("agents", [])
        ]

    def run(
        self,
        agent_id: str,
        *,
        code: str | None = None,
        query: str | None = None,
        language: str = "python",
        **kwargs,
    ) -> MarketplaceResponse:
        """Run a marketplace agent.

        Args:
            agent_id: Agent ID (e.g. "code-reviewer", "bug-hunter").
            code: Code to analyze (for code-related agents).
            query: Query string (for search/research agents).
            language: Programming language context.

        Returns:
            MarketplaceResponse with .result, .success
        """
        payload: dict[str, Any] = {"language": language, **kwargs}
        if code:
            payload["code"] = code
        if query:
            payload["query"] = query

        data = self._client.post(f"/api/marketplace/agents/{agent_id}/run", json=payload)
        return MarketplaceResponse.from_api(data)


class AsyncMarketplace:
    """Async marketplace interface."""

    def __init__(self, client: AsyncNeuronXClient):
        self._client = client

    async def list(self) -> list[MarketplaceAgent]:
        """List marketplace agents (async)."""
        data = await self._client.get("/api/marketplace/agents")
        return [
            MarketplaceAgent(
                id=a.get("id", ""),
                name=a.get("name", ""),
                description=a.get("description", ""),
                category=a.get("category", ""),
                author=a.get("author", ""),
                version=a.get("version", ""),
                rating=a.get("rating", 0.0),
                installs=a.get("installs", 0),
            )
            for a in data.get("agents", [])
        ]

    async def run(
        self,
        agent_id: str,
        *,
        code: str | None = None,
        query: str | None = None,
        language: str = "python",
        **kwargs,
    ) -> MarketplaceResponse:
        """Run a marketplace agent (async)."""
        payload: dict[str, Any] = {"language": language, **kwargs}
        if code:
            payload["code"] = code
        if query:
            payload["query"] = query

        data = await self._client.post(f"/api/marketplace/agents/{agent_id}/run", json=payload)
        return MarketplaceResponse.from_api(data)
