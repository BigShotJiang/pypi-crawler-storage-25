"""Search module — nx.search() wraps POST /api/search/v2/search."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .models import SearchResponse

if TYPE_CHECKING:
    from .client import AsyncNeuronXClient, NeuronXClient


class Search:
    """Synchronous search interface."""

    def __init__(self, client: NeuronXClient):
        self._client = client

    def create(
        self,
        query: str,
        *,
        engines: list[str] | None = None,
        per_page: int = 10,
        include_summary: bool = True,
    ) -> SearchResponse:
        """Search using NeuronX's 3-engine AI search.

        Args:
            query: Search query string.
            engines: Specific engines to use (e.g. ["faiss", "keyword", "web"]).
            per_page: Number of results per page.
            include_summary: Whether to include AI-generated summary.

        Returns:
            SearchResponse with .summary, .items[], .total
        """
        payload: dict[str, Any] = {
            "query": query,
            "per_page": per_page,
            "include_summary": include_summary,
        }
        if engines:
            payload["engines"] = engines

        data = self._client.post("/api/search/v2/search", json=payload)
        return SearchResponse.from_api(data)


class AsyncSearch:
    """Async search interface."""

    def __init__(self, client: AsyncNeuronXClient):
        self._client = client

    async def create(
        self,
        query: str,
        *,
        engines: list[str] | None = None,
        per_page: int = 10,
        include_summary: bool = True,
    ) -> SearchResponse:
        """Search (async)."""
        payload: dict[str, Any] = {
            "query": query,
            "per_page": per_page,
            "include_summary": include_summary,
        }
        if engines:
            payload["engines"] = engines

        data = await self._client.post("/api/search/v2/search", json=payload)
        return SearchResponse.from_api(data)
