"""Knowledge Graph module — nx.kg wraps /api/knowledge-graph/* endpoints."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .models import KGResponse, KGStatus

if TYPE_CHECKING:
    from .client import AsyncNeuronXClient, NeuronXClient


class KnowledgeGraph:
    """Synchronous Knowledge Graph interface."""

    def __init__(self, client: NeuronXClient):
        self._client = client

    def query(
        self,
        concept: str,
        *,
        depth: int = 2,
    ) -> KGResponse:
        """Query the Knowledge Graph for related concepts.

        Args:
            concept: The concept to look up (e.g. "fastapi", "authentication").
            depth: How many relationship hops to traverse (default 2).

        Returns:
            KGResponse with .concept, .results[] (KGNode objects)
        """
        data = self._client.get(
            "/api/knowledge-graph/query",
            params={"concept": concept, "depth": depth},
        )
        return KGResponse.from_api(data)

    def status(self) -> KGStatus:
        """Get Knowledge Graph statistics.

        Returns:
            KGStatus with .nodes, .edges, .last_build
        """
        data = self._client.get("/api/knowledge-graph/status")
        return KGStatus.from_api(data)


class AsyncKnowledgeGraph:
    """Async Knowledge Graph interface."""

    def __init__(self, client: AsyncNeuronXClient):
        self._client = client

    async def query(
        self,
        concept: str,
        *,
        depth: int = 2,
    ) -> KGResponse:
        """Query the Knowledge Graph (async)."""
        data = await self._client.get(
            "/api/knowledge-graph/query",
            params={"concept": concept, "depth": depth},
        )
        return KGResponse.from_api(data)

    async def status(self) -> KGStatus:
        """Get KG statistics (async)."""
        data = await self._client.get("/api/knowledge-graph/status")
        return KGStatus.from_api(data)
