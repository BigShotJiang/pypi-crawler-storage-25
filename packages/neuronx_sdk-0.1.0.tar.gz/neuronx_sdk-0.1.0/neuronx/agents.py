"""Autonomous agents module — nx.agents wraps /api/agents/* endpoints."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any

from .models import AgentResult, AgentTask, AgentTool

if TYPE_CHECKING:
    from .client import AsyncNeuronXClient, NeuronXClient


class Agents:
    """Synchronous agents interface."""

    def __init__(self, client: NeuronXClient):
        self._client = client

    def run(
        self,
        goal: str,
        *,
        role: str | None = None,
        tools: list[str] | None = None,
        max_steps: int | None = None,
    ) -> AgentTask:
        """Launch an autonomous agent task.

        Args:
            goal: What the agent should accomplish.
            role: Agent role (diagnostician, knowledge_curator, quality_auditor,
                  post_mortem_analyst, provider_optimizer, data_quality,
                  performance_sentinel).
            tools: Specific tools to allow.
            max_steps: Maximum number of ReAct steps.

        Returns:
            AgentTask with .task_id and .status
        """
        payload: dict[str, Any] = {"goal": goal}
        if role:
            payload["role"] = role
        if tools:
            payload["tools"] = tools
        if max_steps is not None:
            payload["max_steps"] = max_steps

        data = self._client.post("/api/agents/run", json=payload)
        return AgentTask.from_api(data)

    def get(self, task_id: str) -> AgentResult:
        """Get the result of an agent task.

        Args:
            task_id: The task ID returned by agents.run().

        Returns:
            AgentResult with .status, .result, .steps, .success
        """
        data = self._client.get(f"/api/agents/task/{task_id}")
        return AgentResult.from_api(data)

    def wait(
        self,
        task_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 120.0,
    ) -> AgentResult:
        """Wait for an agent task to complete.

        Args:
            task_id: The task ID to wait for.
            poll_interval: Seconds between status checks.
            timeout: Maximum seconds to wait.

        Returns:
            AgentResult once the task completes.

        Raises:
            TimeoutError: If the task doesn't complete within the timeout.
        """
        from .exceptions import TimeoutError

        start = time.time()
        while time.time() - start < timeout:
            result = self.get(task_id)
            if result.status in ("completed", "failed", "error"):
                return result
            time.sleep(poll_interval)
        raise TimeoutError(f"Agent task {task_id} did not complete within {timeout}s")

    def list_tools(self) -> list[AgentTool]:
        """List all available agent tools.

        Returns:
            List of AgentTool with .name, .description, .parameters
        """
        data = self._client.get("/api/agents/tools")
        return [
            AgentTool(
                name=t.get("name", ""),
                description=t.get("description", ""),
                parameters=t.get("parameters", {}),
            )
            for t in data.get("tools", [])
        ]


class AsyncAgents:
    """Async agents interface."""

    def __init__(self, client: AsyncNeuronXClient):
        self._client = client

    async def run(
        self,
        goal: str,
        *,
        role: str | None = None,
        tools: list[str] | None = None,
        max_steps: int | None = None,
    ) -> AgentTask:
        """Launch an autonomous agent task (async)."""
        payload: dict[str, Any] = {"goal": goal}
        if role:
            payload["role"] = role
        if tools:
            payload["tools"] = tools
        if max_steps is not None:
            payload["max_steps"] = max_steps

        data = await self._client.post("/api/agents/run", json=payload)
        return AgentTask.from_api(data)

    async def get(self, task_id: str) -> AgentResult:
        """Get agent task result (async)."""
        data = await self._client.get(f"/api/agents/task/{task_id}")
        return AgentResult.from_api(data)

    async def wait(
        self,
        task_id: str,
        *,
        poll_interval: float = 2.0,
        timeout: float = 120.0,
    ) -> AgentResult:
        """Wait for agent task completion (async)."""
        import asyncio
        from .exceptions import TimeoutError

        start = time.time()
        while time.time() - start < timeout:
            result = await self.get(task_id)
            if result.status in ("completed", "failed", "error"):
                return result
            await asyncio.sleep(poll_interval)
        raise TimeoutError(f"Agent task {task_id} did not complete within {timeout}s")

    async def list_tools(self) -> list[AgentTool]:
        """List available agent tools (async)."""
        data = await self._client.get("/api/agents/tools")
        return [
            AgentTool(
                name=t.get("name", ""),
                description=t.get("description", ""),
                parameters=t.get("parameters", {}),
            )
            for t in data.get("tools", [])
        ]
