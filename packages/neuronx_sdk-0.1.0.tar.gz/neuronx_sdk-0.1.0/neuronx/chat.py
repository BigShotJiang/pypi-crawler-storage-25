"""Chat module — nx.chat() wraps POST /api/llm/chat."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Iterator

from .models import ChatResponse, StreamChunk

if TYPE_CHECKING:
    from .client import AsyncNeuronXClient, NeuronXClient


class Chat:
    """Synchronous chat interface."""

    def __init__(self, client: NeuronXClient):
        self._client = client

    def create(
        self,
        message: str,
        *,
        model: str | None = None,
        provider: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        system_prompt: str | None = None,
    ) -> ChatResponse:
        """Send a chat message and get an AI response.

        Args:
            message: The user message to send.
            model: Specific model to use (e.g. "llama-3.3-70b").
            provider: Specific provider (e.g. "groq", "gemini").
            temperature: Sampling temperature (0.0-2.0).
            max_tokens: Maximum tokens in response.
            system_prompt: System prompt to set context.

        Returns:
            ChatResponse with .text, .engine, .model, .tokens_used
        """
        payload: dict[str, Any] = {"message": message}
        if model:
            payload["model"] = model
        if provider:
            payload["provider"] = provider
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if system_prompt:
            payload["system_prompt"] = system_prompt

        data = self._client.post("/api/llm/chat", json=payload)
        return ChatResponse.from_api(data)

    def stream(
        self,
        message: str,
        *,
        model: str | None = None,
        provider: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        system_prompt: str | None = None,
    ) -> Iterator[StreamChunk]:
        """Stream a chat response via SSE.

        Yields:
            StreamChunk with .text and .done
        """
        payload: dict[str, Any] = {"message": message, "stream": True}
        if model:
            payload["model"] = model
        if provider:
            payload["provider"] = provider
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if system_prompt:
            payload["system_prompt"] = system_prompt

        for event in self._client.stream_sse("POST", "/api/llm/chat", json=payload):
            yield StreamChunk(
                text=event.get("text", event.get("chunk", "")),
                done=event.get("done", False),
                raw=event,
            )


class AsyncChat:
    """Async chat interface."""

    def __init__(self, client: AsyncNeuronXClient):
        self._client = client

    async def create(
        self,
        message: str,
        *,
        model: str | None = None,
        provider: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        system_prompt: str | None = None,
    ) -> ChatResponse:
        """Send a chat message (async)."""
        payload: dict[str, Any] = {"message": message}
        if model:
            payload["model"] = model
        if provider:
            payload["provider"] = provider
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens
        if system_prompt:
            payload["system_prompt"] = system_prompt

        data = await self._client.post("/api/llm/chat", json=payload)
        return ChatResponse.from_api(data)

    async def stream(self, message: str, **kwargs) -> Any:
        """Stream a chat response (async)."""
        payload: dict[str, Any] = {"message": message, "stream": True, **kwargs}
        async for event in self._client.stream_sse("POST", "/api/llm/chat", json=payload):
            yield StreamChunk(
                text=event.get("text", event.get("chunk", "")),
                done=event.get("done", False),
                raw=event,
            )
