"""NeuronX SDK — Python client for the NeuronX AI Platform.

Usage:
    from neuronx import NeuronX

    nx = NeuronX(api_key="nx-YOUR_KEY")

    # Chat with 19 free LLM providers
    response = nx.chat("explain quicksort")
    print(response.text)

    # Generate code using 185K+ patterns
    code = nx.codegen("REST API with JWT auth", language="python")
    print(code.code)

    # AI-powered search
    results = nx.search("transformer attention mechanism")
    print(results.summary)

    # Problem solving
    solution = nx.solve("optimize database queries for 1M rows")
    print(solution.response)
"""

from __future__ import annotations

from typing import Any, Iterator

from .agents import AsyncAgents, Agents
from .chat import AsyncChat, Chat
from .client import AsyncNeuronXClient, NeuronXClient
from .codegen import AsyncCodegen, Codegen
from .exceptions import (
    AuthenticationError,
    NeuronXError,
    NotFoundError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
)
from .kg import AsyncKnowledgeGraph, KnowledgeGraph
from .marketplace import AsyncMarketplace, Marketplace
from .models import (
    AgentResult,
    ChatResponse,
    CodegenResponse,
    KGResponse,
    KGStatus,
    MarketplaceAgent,
    PatternsResponse,
    ReviewResponse,
    SearchResponse,
    SolveResponse,
    StreamChunk,
)
from .patterns import AsyncPatterns, Patterns
from .review import AsyncReview, Review
from .search import AsyncSearch, Search
from .solve import AsyncSolve, Solve

__version__ = "0.1.0"
__all__ = [
    "NeuronX",
    "AsyncNeuronX",
    "NeuronXError",
    "AuthenticationError",
    "RateLimitError",
    "TimeoutError",
    "ServerError",
    "NotFoundError",
    "ValidationError",
    "ChatResponse",
    "CodegenResponse",
    "SearchResponse",
    "SolveResponse",
    "ReviewResponse",
    "PatternsResponse",
    "AgentResult",
    "KGResponse",
    "KGStatus",
    "MarketplaceAgent",
    "StreamChunk",
]


class NeuronX:
    """NeuronX SDK client — synchronous.

    Args:
        api_key: Your NeuronX API key (nx-...).
        base_url: API base URL. Defaults to https://neuronx.jagatab.uk.
        timeout: Request timeout in seconds. Defaults to 30.
        max_retries: Number of retries for failed requests. Defaults to 2.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "https://neuronx.jagatab.uk",
        timeout: float = 30.0,
        max_retries: int = 2,
    ):
        self._client = NeuronXClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._chat = Chat(self._client)
        self._codegen = Codegen(self._client)
        self._search = Search(self._client)
        self._solve = Solve(self._client)
        self._review = Review(self._client)
        self.patterns = Patterns(self._client)
        self.agents = Agents(self._client)
        self.marketplace = Marketplace(self._client)
        self.kg = KnowledgeGraph(self._client)

    # --- Convenience methods (top-level shortcuts) ---

    def chat(
        self,
        message: str,
        *,
        model: str | None = None,
        provider: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        system_prompt: str | None = None,
    ) -> ChatResponse:
        """Send a chat message. Shortcut for nx.chat.create()."""
        return self._chat.create(
            message, model=model, provider=provider,
            temperature=temperature, max_tokens=max_tokens,
            system_prompt=system_prompt,
        )

    def chat_stream(
        self,
        message: str,
        **kwargs,
    ) -> Iterator[StreamChunk]:
        """Stream a chat response. Shortcut for nx.chat.stream()."""
        return self._chat.stream(message, **kwargs)

    def codegen(
        self,
        prompt: str,
        *,
        language: str = "python",
        framework: str | None = None,
        use_patterns: bool = True,
        max_tokens: int | None = None,
    ) -> CodegenResponse:
        """Generate code. Shortcut for nx.codegen.create()."""
        return self._codegen.create(
            prompt, language=language, framework=framework,
            use_patterns=use_patterns, max_tokens=max_tokens,
        )

    def search(
        self,
        query: str,
        *,
        engines: list[str] | None = None,
        per_page: int = 10,
        include_summary: bool = True,
    ) -> SearchResponse:
        """AI-powered search. Shortcut for nx.search.create()."""
        return self._search.create(
            query, engines=engines, per_page=per_page,
            include_summary=include_summary,
        )

    def solve(
        self,
        problem: str,
        *,
        context: str | None = None,
        language: str | None = None,
        max_tokens: int | None = None,
    ) -> SolveResponse:
        """Solve a problem. Shortcut for nx.solve.create()."""
        return self._solve.create(
            problem, context=context, language=language,
            max_tokens=max_tokens,
        )

    def review(
        self,
        code: str,
        *,
        language: str = "python",
        filename: str | None = None,
    ) -> ReviewResponse:
        """Review code for security issues and bugs. Shortcut for nx.review.create()."""
        return self._review.create(code, language=language, filename=filename)

    def status(self) -> dict[str, Any]:
        """Get NeuronX system health status."""
        return self._client.get("/status")

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __repr__(self) -> str:
        return f"NeuronX(base_url={self._client.base_url!r})"


class AsyncNeuronX:
    """NeuronX SDK client — async.

    Args:
        api_key: Your NeuronX API key (nx-...).
        base_url: API base URL. Defaults to https://neuronx.jagatab.uk.
        timeout: Request timeout in seconds. Defaults to 30.
        max_retries: Number of retries for failed requests. Defaults to 2.
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str = "https://neuronx.jagatab.uk",
        timeout: float = 30.0,
        max_retries: int = 2,
    ):
        self._client = AsyncNeuronXClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self._chat = AsyncChat(self._client)
        self._codegen = AsyncCodegen(self._client)
        self._search = AsyncSearch(self._client)
        self._solve = AsyncSolve(self._client)
        self._review = AsyncReview(self._client)
        self.patterns = AsyncPatterns(self._client)
        self.agents = AsyncAgents(self._client)
        self.marketplace = AsyncMarketplace(self._client)
        self.kg = AsyncKnowledgeGraph(self._client)

    async def chat(
        self,
        message: str,
        *,
        model: str | None = None,
        provider: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
        system_prompt: str | None = None,
    ) -> ChatResponse:
        """Send a chat message (async)."""
        return await self._chat.create(
            message, model=model, provider=provider,
            temperature=temperature, max_tokens=max_tokens,
            system_prompt=system_prompt,
        )

    async def codegen(
        self,
        prompt: str,
        *,
        language: str = "python",
        framework: str | None = None,
        use_patterns: bool = True,
        max_tokens: int | None = None,
    ) -> CodegenResponse:
        """Generate code (async)."""
        return await self._codegen.create(
            prompt, language=language, framework=framework,
            use_patterns=use_patterns, max_tokens=max_tokens,
        )

    async def search(
        self,
        query: str,
        *,
        engines: list[str] | None = None,
        per_page: int = 10,
        include_summary: bool = True,
    ) -> SearchResponse:
        """AI-powered search (async)."""
        return await self._search.create(
            query, engines=engines, per_page=per_page,
            include_summary=include_summary,
        )

    async def solve(
        self,
        problem: str,
        *,
        context: str | None = None,
        language: str | None = None,
        max_tokens: int | None = None,
    ) -> SolveResponse:
        """Solve a problem (async)."""
        return await self._solve.create(
            problem, context=context, language=language,
            max_tokens=max_tokens,
        )

    async def review(
        self,
        code: str,
        *,
        language: str = "python",
        filename: str | None = None,
    ) -> ReviewResponse:
        """Review code (async)."""
        return await self._review.create(code, language=language, filename=filename)

    async def status(self) -> dict[str, Any]:
        """Get system health (async)."""
        return await self._client.get("/status")

    async def close(self) -> None:
        await self._client.close()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    def __repr__(self) -> str:
        return f"AsyncNeuronX(base_url={self._client.base_url!r})"
