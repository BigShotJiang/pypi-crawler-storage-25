"""Pattern search module — nx.patterns wraps GET /api/patterns/search."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .models import PatternsResponse

if TYPE_CHECKING:
    from .client import AsyncNeuronXClient, NeuronXClient


class Patterns:
    """Synchronous pattern search interface."""

    def __init__(self, client: NeuronXClient):
        self._client = client

    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        language: str | None = None,
    ) -> PatternsResponse:
        """Search NeuronX's 28K+ code pattern database.

        Args:
            query: Search query (e.g. "singleton pattern").
            limit: Maximum number of patterns to return.
            language: Filter by programming language.

        Returns:
            PatternsResponse with .patterns[], .count
        """
        params: dict[str, Any] = {"q": query, "limit": limit}
        if language:
            params["language"] = language

        data = self._client.get("/api/patterns/search", params=params)
        return PatternsResponse.from_api(data)

    def stats(self) -> dict[str, Any]:
        """Get pattern database statistics."""
        return self._client.get("/api/patterns/stats")


class AsyncPatterns:
    """Async pattern search interface."""

    def __init__(self, client: AsyncNeuronXClient):
        self._client = client

    async def search(
        self,
        query: str,
        *,
        limit: int = 10,
        language: str | None = None,
    ) -> PatternsResponse:
        """Search patterns (async)."""
        params: dict[str, Any] = {"q": query, "limit": limit}
        if language:
            params["language"] = language

        data = await self._client.get("/api/patterns/search", params=params)
        return PatternsResponse.from_api(data)

    async def stats(self) -> dict[str, Any]:
        """Get pattern stats (async)."""
        return await self._client.get("/api/patterns/stats")
