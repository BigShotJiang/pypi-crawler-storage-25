"""Pydantic v2 response models for NeuronX SDK."""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


# --- Chat ---

class ChatResponse(BaseModel):
    """Response from nx.chat()."""
    text: str = ""
    engine: str = ""
    model: str = ""
    tokens_used: int = 0
    latency_ms: float = 0
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> ChatResponse:
        return cls(
            text=data.get("response", data.get("text", "")),
            engine=data.get("engine", data.get("provider", "")),
            model=data.get("model", ""),
            tokens_used=data.get("tokens_used", 0),
            latency_ms=data.get("latency_ms", 0),
            raw=data,
        )


# --- Code Generation ---

class CodegenResponse(BaseModel):
    """Response from nx.codegen()."""
    code: str = ""
    language: str = ""
    patterns_used: list[str] = Field(default_factory=list)
    explanation: str = ""
    engine: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> CodegenResponse:
        return cls(
            code=data.get("code", data.get("generated_code", "")),
            language=data.get("language", ""),
            patterns_used=data.get("patterns_used", []),
            explanation=data.get("explanation", ""),
            engine=data.get("engine", ""),
            raw=data,
        )


# --- Search ---

class SearchItem(BaseModel):
    """A single search result."""
    title: str = ""
    url: str = ""
    snippet: str = ""
    score: float = 0.0
    source: str = ""


class SearchResponse(BaseModel):
    """Response from nx.search()."""
    summary: str = ""
    items: list[SearchItem] = Field(default_factory=list)
    total: int = 0
    engine: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> SearchResponse:
        items = []
        for r in data.get("results", []):
            items.append(SearchItem(
                title=r.get("title", ""),
                url=r.get("url", r.get("link", "")),
                snippet=r.get("snippet", r.get("description", "")),
                score=r.get("score", 0.0),
                source=r.get("source", ""),
            ))
        return cls(
            summary=data.get("summary", data.get("ai_summary", "")),
            items=items,
            total=data.get("total", len(items)),
            engine=data.get("engine", ""),
            raw=data,
        )


# --- Solve ---

class SolveResponse(BaseModel):
    """Response from nx.solve()."""
    response: str = ""
    steps: list[str] = Field(default_factory=list)
    confidence: float = 0.0
    engine: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> SolveResponse:
        resp = data.get("response", data.get("solution", ""))
        # API may return response as a nested dict with its own "response" key
        if isinstance(resp, dict):
            resp = resp.get("response", resp.get("text", str(resp)))
        return cls(
            response=resp,
            steps=data.get("steps", []),
            confidence=data.get("confidence", 0.0),
            engine=data.get("engine", ""),
            raw=data,
        )


# --- Review (Guard) ---

class ReviewIssue(BaseModel):
    """A single issue found by Guard code review."""
    severity: str = ""
    message: str = ""
    line: int | None = None
    rule: str = ""
    suggestion: str = ""


class ReviewResponse(BaseModel):
    """Response from nx.review()."""
    issues: list[ReviewIssue] = Field(default_factory=list)
    issues_found: int = 0
    errors: int = 0
    summary: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> ReviewResponse:
        issues = []
        for i in data.get("issues", []):
            issues.append(ReviewIssue(
                severity=i.get("severity", i.get("level", "")),
                message=i.get("message", i.get("description", "")),
                line=i.get("line"),
                rule=i.get("rule", i.get("pattern", "")),
                suggestion=i.get("suggestion", i.get("fix", "")),
            ))
        return cls(
            issues=issues,
            issues_found=data.get("issues_found", len(issues)),
            errors=data.get("errors", 0),
            summary=data.get("summary", data.get("error", "")),
            raw=data,
        )


# --- Patterns ---

class Pattern(BaseModel):
    """A code pattern from NeuronX's 28K+ pattern database."""
    id: str = ""
    name: str = ""
    code: str = ""
    language: str = ""
    quality_score: float = 0.0
    source: str = ""


class PatternsResponse(BaseModel):
    """Response from nx.patterns.search()."""
    query: str = ""
    patterns: list[Pattern] = Field(default_factory=list)
    count: int = 0
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> PatternsResponse:
        patterns = []
        for p in data.get("patterns", []):
            patterns.append(Pattern(
                id=p.get("id", ""),
                name=p.get("name", ""),
                code=p.get("code", ""),
                language=p.get("language", ""),
                quality_score=p.get("quality_score", p.get("score", 0.0)),
                source=p.get("source", ""),
            ))
        return cls(
            query=data.get("query", ""),
            patterns=patterns,
            count=data.get("count", len(patterns)),
            raw=data,
        )


# --- Agents ---

class AgentTask(BaseModel):
    """A running or completed agent task."""
    task_id: str = ""
    status: str = ""
    goal: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> AgentTask:
        return cls(
            task_id=data.get("task_id", ""),
            status=data.get("status", ""),
            goal=data.get("goal", ""),
            raw=data,
        )


class AgentResult(BaseModel):
    """Result of a completed agent task."""
    task_id: str = ""
    status: str = ""
    goal: str = ""
    result: str = ""
    steps: list[dict[str, Any]] = Field(default_factory=list)
    success: bool = False
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> AgentResult:
        result_data = data.get("result", {})
        if isinstance(result_data, dict):
            result_text = result_data.get("result", "")
            raw_steps = result_data.get("steps", [])
            success = result_data.get("success", False)
        else:
            result_text = str(result_data)
            raw_steps = []
            success = data.get("status") == "completed"
        # API may return steps as an int (count) instead of a list
        if isinstance(raw_steps, int):
            steps = [{"step": i} for i in range(raw_steps)]
        elif isinstance(raw_steps, list):
            steps = raw_steps
        else:
            steps = []
        return cls(
            task_id=data.get("task_id", ""),
            status=data.get("status", ""),
            goal=data.get("goal", ""),
            result=result_text,
            steps=steps,
            success=success,
            raw=data,
        )


class AgentTool(BaseModel):
    """An agent tool."""
    name: str = ""
    description: str = ""
    parameters: dict[str, Any] = Field(default_factory=dict)


# --- Marketplace ---

class MarketplaceAgent(BaseModel):
    """A marketplace agent."""
    id: str = ""
    name: str = ""
    description: str = ""
    category: str = ""
    author: str = ""
    version: str = ""
    rating: float = 0.0
    installs: int = 0


class MarketplaceResponse(BaseModel):
    """Response from marketplace agent run."""
    result: str = ""
    agent_id: str = ""
    success: bool = False
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> MarketplaceResponse:
        result = data.get("result", "")
        if isinstance(result, dict):
            result = result.get("result", result.get("text", str(result)))
        return cls(
            result=result,
            agent_id=data.get("agent_id", data.get("id", "")),
            success=data.get("success", data.get("status") == "completed"),
            raw=data,
        )


# --- Knowledge Graph ---

class KGNode(BaseModel):
    """A node from the Knowledge Graph."""
    id: str = ""
    label: str = ""
    type: str = ""
    depth: int = 0
    relationship: str = ""
    weight: float = 0.0
    evidence_count: int = 0


class KGResponse(BaseModel):
    """Response from nx.kg.query()."""
    concept: str = ""
    results: list[KGNode] = Field(default_factory=list)
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> KGResponse:
        nodes = []
        for n in data.get("results", []):
            nodes.append(KGNode(
                id=n.get("id", ""),
                label=n.get("label", ""),
                type=n.get("type", ""),
                depth=n.get("depth", 0),
                relationship=n.get("relationship", ""),
                weight=n.get("weight", 0.0),
                evidence_count=n.get("evidence_count", 0),
            ))
        return cls(
            concept=data.get("concept", ""),
            results=nodes,
            raw=data,
        )


class KGStatus(BaseModel):
    """Knowledge Graph status."""
    nodes: int = 0
    edges: int = 0
    last_build: str = ""
    raw: dict[str, Any] = Field(default_factory=dict)

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> KGStatus:
        return cls(
            nodes=data.get("nodes", 0),
            edges=data.get("edges", 0),
            last_build=data.get("last_build", ""),
            raw=data,
        )


# --- Streaming ---

class StreamChunk(BaseModel):
    """A single chunk from a streaming response."""
    text: str = ""
    done: bool = False
    raw: dict[str, Any] = Field(default_factory=dict)
