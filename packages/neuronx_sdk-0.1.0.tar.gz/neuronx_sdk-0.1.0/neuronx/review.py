"""Guard code review module — nx.review() wraps POST /api/guard/ci-review."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .models import ReviewResponse

if TYPE_CHECKING:
    from .client import AsyncNeuronXClient, NeuronXClient


class Review:
    """Synchronous code review interface."""

    def __init__(self, client: NeuronXClient):
        self._client = client

    def create(
        self,
        code: str,
        *,
        language: str = "python",
        filename: str | None = None,
        as_diff: bool = False,
    ) -> ReviewResponse:
        """Review code for security issues, bugs, and best practices.

        Args:
            code: Code string or diff to review.
            language: Programming language.
            filename: Optional filename for context.
            as_diff: If True, send code as a diff (unified format).

        Returns:
            ReviewResponse with .issues[], .issues_found, .summary
        """
        payload: dict[str, Any] = {"language": language}
        if as_diff:
            payload["diff"] = code
        else:
            payload["diff"] = code  # API expects diff field
        if filename:
            payload["filename"] = filename

        data = self._client.post("/api/guard/ci-review", json=payload)
        return ReviewResponse.from_api(data)


class AsyncReview:
    """Async code review interface."""

    def __init__(self, client: AsyncNeuronXClient):
        self._client = client

    async def create(
        self,
        code: str,
        *,
        language: str = "python",
        filename: str | None = None,
        as_diff: bool = False,
    ) -> ReviewResponse:
        """Review code (async)."""
        payload: dict[str, Any] = {"language": language}
        if as_diff:
            payload["diff"] = code
        else:
            payload["diff"] = code
        if filename:
            payload["filename"] = filename

        data = await self._client.post("/api/guard/ci-review", json=payload)
        return ReviewResponse.from_api(data)
