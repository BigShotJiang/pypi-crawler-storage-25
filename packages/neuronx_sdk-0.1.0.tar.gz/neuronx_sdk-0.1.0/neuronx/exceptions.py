"""NeuronX SDK exceptions."""


class NeuronXError(Exception):
    """Base exception for all NeuronX SDK errors."""

    def __init__(self, message: str, status_code: int | None = None, response: dict | None = None):
        self.message = message
        self.status_code = status_code
        self.response = response
        super().__init__(message)


class AuthenticationError(NeuronXError):
    """Invalid or missing API key."""


class RateLimitError(NeuronXError):
    """Rate limit exceeded (30/min or 1000/day on free tier)."""

    def __init__(self, message: str = "Rate limit exceeded", retry_after: float | None = None, **kwargs):
        self.retry_after = retry_after
        super().__init__(message, **kwargs)


class TimeoutError(NeuronXError):
    """Request timed out."""


class ServerError(NeuronXError):
    """NeuronX server returned a 5xx error."""


class NotFoundError(NeuronXError):
    """Requested resource not found."""


class ValidationError(NeuronXError):
    """Request validation failed."""
