"""Code generation module — nx.codegen() wraps POST /api/codegen/generate."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .models import CodegenResponse

if TYPE_CHECKING:
    from .client import AsyncNeuronXClient, NeuronXClient


class Codegen:
    """Synchronous code generation interface."""

    def __init__(self, client: NeuronXClient):
        self._client = client

    def create(
        self,
        prompt: str,
        *,
        language: str = "python",
        framework: str | None = None,
        use_patterns: bool = True,
        max_tokens: int | None = None,
    ) -> CodegenResponse:
        """Generate code from a natural language prompt.

        Args:
            prompt: What to generate (e.g. "REST API with JWT auth").
            language: Target language (python, javascript, etc.).
            framework: Target framework (fastapi, express, etc.).
            use_patterns: Whether to use NeuronX's 185K pattern database.
            max_tokens: Maximum tokens in generated code.

        Returns:
            CodegenResponse with .code, .language, .patterns_used, .explanation
        """
        payload: dict[str, Any] = {
            "description": prompt,
            "language": language,
            "use_patterns": use_patterns,
        }
        if framework:
            payload["framework"] = framework
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        data = self._client.post("/api/codegen/generate", json=payload)
        return CodegenResponse.from_api(data)


class AsyncCodegen:
    """Async code generation interface."""

    def __init__(self, client: AsyncNeuronXClient):
        self._client = client

    async def create(
        self,
        prompt: str,
        *,
        language: str = "python",
        framework: str | None = None,
        use_patterns: bool = True,
        max_tokens: int | None = None,
    ) -> CodegenResponse:
        """Generate code (async)."""
        payload: dict[str, Any] = {
            "description": prompt,
            "language": language,
            "use_patterns": use_patterns,
        }
        if framework:
            payload["framework"] = framework
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        data = await self._client.post("/api/codegen/generate", json=payload)
        return CodegenResponse.from_api(data)
