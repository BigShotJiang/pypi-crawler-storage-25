"""Problem solving module — nx.solve() wraps POST /solve."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .models import SolveResponse

if TYPE_CHECKING:
    from .client import AsyncNeuronXClient, NeuronXClient


class Solve:
    """Synchronous problem solver interface."""

    def __init__(self, client: NeuronXClient):
        self._client = client

    def create(
        self,
        problem: str,
        *,
        context: str | None = None,
        language: str | None = None,
        max_tokens: int | None = None,
    ) -> SolveResponse:
        """Solve a problem using NeuronX's AI.

        Args:
            problem: Problem description to solve.
            context: Additional context or constraints.
            language: Programming language context.
            max_tokens: Maximum tokens in response.

        Returns:
            SolveResponse with .response, .steps[], .confidence
        """
        payload: dict[str, Any] = {"problem": problem}
        if context:
            payload["context"] = context
        if language:
            payload["language"] = language
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        data = self._client.post("/solve", json=payload)
        return SolveResponse.from_api(data)


class AsyncSolve:
    """Async problem solver interface."""

    def __init__(self, client: AsyncNeuronXClient):
        self._client = client

    async def create(
        self,
        problem: str,
        *,
        context: str | None = None,
        language: str | None = None,
        max_tokens: int | None = None,
    ) -> SolveResponse:
        """Solve a problem (async)."""
        payload: dict[str, Any] = {"problem": problem}
        if context:
            payload["context"] = context
        if language:
            payload["language"] = language
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        data = await self._client.post("/solve", json=payload)
        return SolveResponse.from_api(data)
