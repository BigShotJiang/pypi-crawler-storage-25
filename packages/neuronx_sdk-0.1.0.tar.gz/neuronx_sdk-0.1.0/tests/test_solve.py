"""Tests for the solve module."""

import json
import pytest

from neuronx.models import SolveResponse


def test_solve_basic(nx, mock_api):
    mock_api.post("/solve").respond(200, json={
        "response": "Use indexing and query optimization.",
        "steps": ["Add indexes", "Use EXPLAIN ANALYZE", "Batch operations"],
        "confidence": 0.85,
        "engine": "groq",
    })
    result = nx.solve("optimize database queries for 1M rows")
    assert isinstance(result, SolveResponse)
    assert "indexing" in result.response
    assert len(result.steps) == 3
    assert result.confidence == 0.85


def test_solve_with_context(nx, mock_api):
    route = mock_api.post("/solve").respond(200, json={"response": "ok"})
    nx.solve("fix bug", context="FastAPI app", language="python")
    body = json.loads(route.calls[0].request.content)
    assert body["context"] == "FastAPI app"
    assert body["language"] == "python"


def test_solve_response_model():
    resp = SolveResponse.from_api({
        "solution": "The answer is 42",
        "steps": ["step1"],
        "confidence": 0.9,
    })
    assert resp.response == "The answer is 42"
    assert resp.steps == ["step1"]


def test_status(nx, mock_api):
    mock_api.get("/status").respond(200, json={
        "status": "healthy",
        "uptime": 12345,
    })
    result = nx.status()
    assert result["status"] == "healthy"
