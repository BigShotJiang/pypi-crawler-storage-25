"""Tests for the agents module."""

import json
import pytest

from neuronx.models import AgentResult, AgentTask, AgentTool


def test_agents_run(nx, mock_api):
    mock_api.post("/api/agents/run").respond(200, json={
        "task_id": "task-123",
        "status": "running",
        "goal": "find security issues",
    })
    task = nx.agents.run("find security issues", role="diagnostician")
    assert isinstance(task, AgentTask)
    assert task.task_id == "task-123"
    assert task.status == "running"


def test_agents_run_params(nx, mock_api):
    route = mock_api.post("/api/agents/run").respond(200, json={
        "task_id": "t1", "status": "running", "goal": "test",
    })
    nx.agents.run("test", role="quality_auditor", max_steps=5)
    body = json.loads(route.calls[0].request.content)
    assert body["goal"] == "test"
    assert body["role"] == "quality_auditor"
    assert body["max_steps"] == 5


def test_agents_get(nx, mock_api):
    mock_api.get("/api/agents/task/task-123").respond(200, json={
        "task_id": "task-123",
        "status": "completed",
        "goal": "find bugs",
        "result": {
            "success": True,
            "result": "Found 3 issues",
            "steps": [{"tool": "search_patterns", "result": "ok"}],
        },
    })
    result = nx.agents.get("task-123")
    assert isinstance(result, AgentResult)
    assert result.success is True
    assert result.result == "Found 3 issues"
    assert len(result.steps) == 1


def test_agents_wait_completed(nx, mock_api):
    mock_api.get("/api/agents/task/t1").respond(200, json={
        "task_id": "t1", "status": "completed", "goal": "test",
        "result": {"success": True, "result": "done"},
    })
    result = nx.agents.wait("t1", poll_interval=0.1, timeout=5)
    assert result.status == "completed"


def test_agents_list_tools(nx, mock_api):
    mock_api.get("/api/agents/tools").respond(200, json={
        "tools": [
            {"name": "search_patterns", "description": "Search patterns", "parameters": {"query": "str"}},
            {"name": "execute_code", "description": "Run code", "parameters": {"code": "str"}},
        ],
    })
    tools = nx.agents.list_tools()
    assert len(tools) == 2
    assert isinstance(tools[0], AgentTool)
    assert tools[0].name == "search_patterns"


def test_agent_result_model():
    result = AgentResult.from_api({
        "task_id": "t1", "status": "completed", "goal": "test",
        "result": {"success": True, "result": "answer", "steps": []},
    })
    assert result.success is True
    assert result.result == "answer"


def test_agent_result_string_result():
    result = AgentResult.from_api({
        "task_id": "t1", "status": "completed", "goal": "test",
        "result": "plain string",
    })
    assert result.result == "plain string"
