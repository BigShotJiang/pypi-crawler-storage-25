"""Tests for the review (Guard) module."""

import json
import pytest

from neuronx.models import ReviewResponse


def test_review_basic(nx, mock_api):
    mock_api.post("/api/guard/ci-review").respond(200, json={
        "issues": [
            {"severity": "critical", "message": "eval() is dangerous", "line": 1, "rule": "no-eval", "suggestion": "Use ast.literal_eval()"},
            {"severity": "warning", "message": "Unused variable", "line": 3, "rule": "no-unused", "suggestion": "Remove or use it"},
        ],
        "issues_found": 2,
        "errors": 0,
        "summary": "2 issues found",
    })
    result = nx.review("eval(user_input)\nx = 1\n")
    assert isinstance(result, ReviewResponse)
    assert result.issues_found == 2
    assert len(result.issues) == 2
    assert result.issues[0].severity == "critical"
    assert result.issues[0].rule == "no-eval"


def test_review_sends_diff(nx, mock_api):
    route = mock_api.post("/api/guard/ci-review").respond(200, json={
        "issues": [], "issues_found": 0, "errors": 0,
    })
    nx.review("def foo(): pass", language="python", filename="app.py")
    body = json.loads(route.calls[0].request.content)
    assert body["diff"] == "def foo(): pass"
    assert body["language"] == "python"
    assert body["filename"] == "app.py"


def test_review_no_issues(nx, mock_api):
    mock_api.post("/api/guard/ci-review").respond(200, json={
        "issues": [], "issues_found": 0, "errors": 0,
    })
    result = nx.review("x = 1 + 2")
    assert result.issues_found == 0
    assert result.issues == []


def test_review_response_model():
    resp = ReviewResponse.from_api({
        "issues": [{"level": "high", "description": "bad code", "pattern": "sec-01"}],
        "issues_found": 1,
        "error": "Review complete",
    })
    assert resp.issues[0].severity == "high"
    assert resp.issues[0].message == "bad code"
    assert resp.issues[0].rule == "sec-01"
