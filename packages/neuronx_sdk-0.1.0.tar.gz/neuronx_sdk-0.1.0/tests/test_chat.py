"""Tests for the chat module."""

import pytest

from neuronx.models import ChatResponse


def test_chat_basic(nx, mock_api):
    mock_api.post("/api/llm/chat").respond(200, json={
        "response": "Quicksort is a divide-and-conquer algorithm.",
        "engine": "groq/llama-3.3-70b",
        "model": "llama-3.3-70b",
        "tokens_used": 42,
        "latency_ms": 150.5,
    })
    result = nx.chat("explain quicksort")
    assert isinstance(result, ChatResponse)
    assert "Quicksort" in result.text
    assert result.engine == "groq/llama-3.3-70b"
    assert result.tokens_used == 42


def test_chat_with_params(nx, mock_api):
    route = mock_api.post("/api/llm/chat").respond(200, json={
        "response": "ok",
        "engine": "gemini",
    })
    nx.chat("test", provider="gemini", temperature=0.5, max_tokens=100)
    import json
    body = json.loads(route.calls[0].request.content)
    assert body["provider"] == "gemini"
    assert body["temperature"] == 0.5
    assert body["max_tokens"] == 100


def test_chat_with_system_prompt(nx, mock_api):
    route = mock_api.post("/api/llm/chat").respond(200, json={"response": "ok"})
    nx.chat("hello", system_prompt="You are a pirate")
    import json
    body = json.loads(route.calls[0].request.content)
    assert body["system_prompt"] == "You are a pirate"


def test_chat_response_model():
    resp = ChatResponse.from_api({
        "response": "hello",
        "engine": "test",
        "model": "test-model",
    })
    assert resp.text == "hello"
    assert resp.engine == "test"
    assert resp.tokens_used == 0  # default
