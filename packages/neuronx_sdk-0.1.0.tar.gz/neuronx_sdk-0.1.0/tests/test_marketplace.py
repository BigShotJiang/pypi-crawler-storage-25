"""Tests for the marketplace module."""

import json
import pytest

from neuronx.models import MarketplaceAgent, MarketplaceResponse


def test_marketplace_list(nx, mock_api):
    mock_api.get("/api/marketplace/agents").respond(200, json={
        "agents": [
            {"id": "code-reviewer", "name": "Code Reviewer", "description": "Reviews code", "category": "development", "author": "NeuronX", "version": "1.0.0", "rating": 4.5, "installs": 100},
            {"id": "bug-hunter", "name": "Bug Hunter", "description": "Finds bugs", "category": "development", "author": "NeuronX", "version": "1.0.0", "rating": 4.2, "installs": 80},
        ],
    })
    agents = nx.marketplace.list()
    assert len(agents) == 2
    assert isinstance(agents[0], MarketplaceAgent)
    assert agents[0].id == "code-reviewer"
    assert agents[0].rating == 4.5


def test_marketplace_run(nx, mock_api):
    mock_api.post("/api/marketplace/agents/code-reviewer/run").respond(200, json={
        "result": "Found 2 issues in your code",
        "agent_id": "code-reviewer",
        "status": "completed",
    })
    result = nx.marketplace.run("code-reviewer", code="eval(x)")
    assert isinstance(result, MarketplaceResponse)
    assert result.success is True
    assert "2 issues" in result.result


def test_marketplace_run_params(nx, mock_api):
    route = mock_api.post("/api/marketplace/agents/bug-hunter/run").respond(200, json={
        "result": "ok", "status": "completed",
    })
    nx.marketplace.run("bug-hunter", code="x = 1", language="javascript")
    body = json.loads(route.calls[0].request.content)
    assert body["code"] == "x = 1"
    assert body["language"] == "javascript"


def test_marketplace_response_nested_result():
    resp = MarketplaceResponse.from_api({
        "result": {"result": "nested answer", "details": {}},
        "status": "completed",
    })
    assert resp.result == "nested answer"
