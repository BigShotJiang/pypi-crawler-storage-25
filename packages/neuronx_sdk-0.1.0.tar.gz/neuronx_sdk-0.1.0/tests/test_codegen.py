"""Tests for the codegen module."""

import json
import pytest

from neuronx.models import CodegenResponse


def test_codegen_basic(nx, mock_api):
    mock_api.post("/api/codegen/generate").respond(200, json={
        "code": "from fastapi import FastAPI\napp = FastAPI()",
        "language": "python",
        "patterns_used": ["fastapi-setup", "jwt-auth"],
        "explanation": "Generated a FastAPI app with JWT.",
    })
    result = nx.codegen("REST API with JWT auth")
    assert isinstance(result, CodegenResponse)
    assert "FastAPI" in result.code
    assert result.language == "python"
    assert len(result.patterns_used) == 2


def test_codegen_with_framework(nx, mock_api):
    route = mock_api.post("/api/codegen/generate").respond(200, json={
        "code": "code here",
        "language": "javascript",
    })
    nx.codegen("REST API", language="javascript", framework="express")
    body = json.loads(route.calls[0].request.content)
    assert body["language"] == "javascript"
    assert body["framework"] == "express"
    assert body["description"] == "REST API"


def test_codegen_patterns_toggle(nx, mock_api):
    route = mock_api.post("/api/codegen/generate").respond(200, json={"code": "x"})
    nx.codegen("test", use_patterns=False)
    body = json.loads(route.calls[0].request.content)
    assert body["use_patterns"] is False
    assert body["description"] == "test"


def test_codegen_response_model():
    resp = CodegenResponse.from_api({
        "generated_code": "print('hello')",
        "language": "python",
    })
    assert resp.code == "print('hello')"
