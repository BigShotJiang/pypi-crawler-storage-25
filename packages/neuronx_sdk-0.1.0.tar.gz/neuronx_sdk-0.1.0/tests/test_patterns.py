"""Tests for the patterns module."""

import json
import pytest

from neuronx.models import PatternsResponse


def test_patterns_search(nx, mock_api):
    mock_api.get("/api/patterns/search").respond(200, json={
        "query": "singleton",
        "count": 2,
        "patterns": [
            {"id": "abc123", "name": "Singleton", "code": "class Singleton: ...", "language": "python", "quality_score": 0.95},
            {"id": "def456", "name": "Config Singleton", "code": "config = {}", "language": "python", "quality_score": 0.88},
        ],
    })
    result = nx.patterns.search("singleton", limit=5)
    assert isinstance(result, PatternsResponse)
    assert result.count == 2
    assert len(result.patterns) == 2
    assert result.patterns[0].name == "Singleton"
    assert result.patterns[0].quality_score == 0.95


def test_patterns_search_params(nx, mock_api):
    route = mock_api.get("/api/patterns/search").respond(200, json={
        "query": "test", "count": 0, "patterns": [],
    })
    nx.patterns.search("test", limit=3, language="javascript")
    req = route.calls[0].request
    assert "q=test" in str(req.url)
    assert "limit=3" in str(req.url)
    assert "language=javascript" in str(req.url)


def test_patterns_response_model():
    resp = PatternsResponse.from_api({
        "query": "factory",
        "patterns": [{"id": "x", "name": "Factory", "score": 0.9}],
    })
    assert resp.query == "factory"
    assert resp.patterns[0].quality_score == 0.9
