"""Tests for the HTTP client."""

import httpx
import pytest
import respx

from neuronx.client import NeuronXClient
from neuronx.exceptions import (
    AuthenticationError,
    NeuronXError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)


def test_successful_get(client, mock_api):
    mock_api.get("/status").respond(200, json={"status": "ok"})
    result = client.get("/status")
    assert result == {"status": "ok"}


def test_successful_post(client, mock_api):
    mock_api.post("/api/llm/chat").respond(200, json={"response": "hello"})
    result = client.post("/api/llm/chat", json={"message": "hi"})
    assert result["response"] == "hello"


def test_auth_header_sent(mock_api):
    route = mock_api.post("/api/llm/chat").respond(200, json={"response": "ok"})
    c = NeuronXClient(api_key="nx-my-key", base_url="https://neuronx.jagatab.uk", max_retries=0)
    c.post("/api/llm/chat", json={"message": "test"})
    assert route.calls[0].request.headers["x-api-key"] == "nx-my-key"
    c.close()


def test_401_raises_auth_error(client, mock_api):
    mock_api.get("/test").respond(401, json={"detail": "Invalid key"})
    with pytest.raises(AuthenticationError, match="Invalid key"):
        client.get("/test")


def test_404_raises_not_found(client, mock_api):
    mock_api.get("/missing").respond(404, json={"detail": "Not found"})
    with pytest.raises(NotFoundError):
        client.get("/missing")


def test_422_raises_validation_error(client, mock_api):
    mock_api.post("/bad").respond(422, json={"detail": "Bad input"})
    with pytest.raises(ValidationError):
        client.post("/bad")


def test_429_raises_rate_limit(client, mock_api):
    mock_api.get("/limited").respond(429, json={"detail": "Too many requests"})
    with pytest.raises(RateLimitError):
        client.get("/limited")


def test_500_raises_server_error(client, mock_api):
    mock_api.get("/broken").respond(500, json={"detail": "Internal error"})
    with pytest.raises(ServerError):
        client.get("/broken")


def test_context_manager():
    with respx.mock(base_url="https://neuronx.jagatab.uk"):
        with NeuronXClient(base_url="https://neuronx.jagatab.uk") as c:
            assert c.base_url == "https://neuronx.jagatab.uk"
