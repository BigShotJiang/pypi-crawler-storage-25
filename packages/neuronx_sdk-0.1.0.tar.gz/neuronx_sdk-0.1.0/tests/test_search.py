"""Tests for the search module."""

import json
import pytest

from neuronx.models import SearchResponse


def test_search_basic(nx, mock_api):
    mock_api.post("/api/search/v2/search").respond(200, json={
        "summary": "Attention is all you need.",
        "results": [
            {"title": "Transformer Paper", "url": "https://arxiv.org/...", "snippet": "self-attention", "score": 0.95},
            {"title": "BERT", "url": "https://arxiv.org/...", "snippet": "bidirectional", "score": 0.88},
        ],
        "total": 2,
        "engine": "faiss+web",
    })
    result = nx.search("transformer attention")
    assert isinstance(result, SearchResponse)
    assert "Attention" in result.summary
    assert len(result.items) == 2
    assert result.items[0].title == "Transformer Paper"
    assert result.items[0].score == 0.95


def test_search_with_engines(nx, mock_api):
    route = mock_api.post("/api/search/v2/search").respond(200, json={
        "results": [], "summary": "",
    })
    nx.search("test", engines=["faiss", "keyword"])
    body = json.loads(route.calls[0].request.content)
    assert body["engines"] == ["faiss", "keyword"]


def test_search_per_page(nx, mock_api):
    route = mock_api.post("/api/search/v2/search").respond(200, json={
        "results": [], "summary": "",
    })
    nx.search("test", per_page=5)
    body = json.loads(route.calls[0].request.content)
    assert body["per_page"] == 5


def test_search_response_model():
    resp = SearchResponse.from_api({
        "ai_summary": "A summary",
        "results": [{"title": "Test", "link": "http://test.com", "description": "desc"}],
    })
    assert resp.summary == "A summary"
    assert resp.items[0].url == "http://test.com"
    assert resp.items[0].snippet == "desc"
