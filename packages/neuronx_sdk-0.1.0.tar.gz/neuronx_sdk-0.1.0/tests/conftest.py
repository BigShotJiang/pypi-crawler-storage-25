"""Shared test fixtures for NeuronX SDK tests."""

import pytest
import httpx
import respx

from neuronx import NeuronX
from neuronx.client import NeuronXClient


@pytest.fixture
def mock_api():
    """Mock the NeuronX API using respx."""
    with respx.mock(base_url="https://neuronx.jagatab.uk") as mock:
        yield mock


@pytest.fixture
def client(mock_api):
    """Create a NeuronXClient pointing at the mocked API."""
    c = NeuronXClient(api_key="nx-test-key", base_url="https://neuronx.jagatab.uk", max_retries=0)
    yield c
    c.close()


@pytest.fixture
def nx(mock_api):
    """Create a NeuronX SDK instance pointing at the mocked API."""
    n = NeuronX(api_key="nx-test-key", base_url="https://neuronx.jagatab.uk", max_retries=0)
    yield n
    n.close()
