"""Tests for the Knowledge Graph module."""

import pytest

from neuronx.models import KGResponse, KGStatus


def test_kg_query(nx, mock_api):
    mock_api.get("/api/knowledge-graph/query").respond(200, json={
        "concept": "fastapi",
        "depth": 2,
        "results": [
            {"id": "abc", "label": "authentication", "type": "concept", "depth": 1, "relationship": "related_to", "weight": 8.5, "evidence_count": 150},
            {"id": "def", "label": "pydantic", "type": "concept", "depth": 2, "relationship": "uses", "weight": 7.0, "evidence_count": 90},
        ],
    })
    result = nx.kg.query("fastapi")
    assert isinstance(result, KGResponse)
    assert result.concept == "fastapi"
    assert len(result.results) == 2
    assert result.results[0].label == "authentication"
    assert result.results[0].weight == 8.5


def test_kg_query_depth(nx, mock_api):
    route = mock_api.get("/api/knowledge-graph/query").respond(200, json={
        "concept": "test", "results": [],
    })
    nx.kg.query("test", depth=3)
    assert "depth=3" in str(route.calls[0].request.url)


def test_kg_status(nx, mock_api):
    mock_api.get("/api/knowledge-graph/status").respond(200, json={
        "nodes": 5784,
        "edges": 45548,
        "last_build": "2026-04-05T12:00:00",
    })
    status = nx.kg.status()
    assert isinstance(status, KGStatus)
    assert status.nodes == 5784
    assert status.edges == 45548


def test_kg_response_model():
    resp = KGResponse.from_api({
        "concept": "python",
        "results": [{"id": "x", "label": "async", "type": "concept"}],
    })
    assert resp.concept == "python"
    assert resp.results[0].label == "async"
