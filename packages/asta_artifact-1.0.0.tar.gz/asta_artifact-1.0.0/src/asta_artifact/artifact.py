"""Artifact builder producing canonical format::

    {
        "id": "...", "name": "...", "description": "...",
        "entities": {"paper-1": {id, type, displayLabel, s2Metadata}},
        "annotations": {"ann-1": {id, type, entityId, text, ...}},
        "content": [{id, type, title, childIds}, {id, type, text}, ...]
    }
"""

from __future__ import annotations

import json
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from .models import (
    Annotation,
    AnnotationType,
    DisplayText,
    EntityType,
    Facet,
    Paper,
    S2Paper,
    Snippet,
)
from .content import (
    ContentBlock,
    Markdown,
    Section,
    SectionContext,
    Sections,
    SectionsContext,
    content_block_from_dict,
)


class Artifact:
    """Asta artifact with structured content, annotations, and entities."""

    def __init__(self, artifact_id: str, name: str,
                 description: str | None = None):
        if not artifact_id:
            raise ValueError("artifact_id is required")
        if not name:
            raise ValueError("name is required")

        self._id = artifact_id
        self._name = name
        self._description = description

        self._content: list[ContentBlock] = []
        self._entities: dict[str, Paper] = {}
        self._annotations: dict[str, Annotation] = {}

        self._content_counter = 0
        self._entity_counter = 0
        self._annotation_counter = 0

    @property
    def id(self) -> str:
        return self._id

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str | None:
        return self._description

    @property
    def content(self) -> list[ContentBlock]:
        return self._content

    @property
    def entities(self) -> dict[str, Paper]:
        return self._entities

    @property
    def annotations(self) -> dict[str, Annotation]:
        return self._annotations

    def _next_content_id(self) -> str:
        self._content_counter += 1
        return f"c_{self._content_counter:03d}"

    def _next_entity_id(self) -> str:
        self._entity_counter += 1
        return f"ent_{self._entity_counter:03d}"

    def _next_annotation_id(self) -> str:
        self._annotation_counter += 1
        return f"ann_{self._annotation_counter:03d}"

    def _update_counter(self, counter_attr: str, id_str: str) -> None:
        """Update a counter to avoid ID collisions after loading."""
        try:
            num = int(id_str.split("_")[1])
            setattr(self, counter_attr, max(getattr(self, counter_attr), num))
        except (IndexError, ValueError):
            pass

    # --- Entity Methods ---

    def add_paper_entity(self, display_label: str,
                         s2_metadata: S2Paper | dict | None = None,
                         entity_id: str | None = None) -> str:
        """Add a Paper entity and return its ID."""
        entity_id = entity_id or self._next_entity_id()
        if isinstance(s2_metadata, dict):
            s2_metadata = S2Paper.model_validate(s2_metadata)
        entity = Paper(
            id=entity_id,
            display_label=display_label,
            s2_metadata=s2_metadata,
        )
        self._entities[entity_id] = entity
        return entity_id

    # --- Annotation Methods ---

    def add_snippet(self, entity_id: str, text: str = "",
                    heading: str | None = None,
                    sentence_id: str | None = None) -> str:
        """Add a Snippet annotation and return its ID.

        To link the snippet to a content block, append the returned ID
        to the block's ``annotation_ids`` list.
        """
        ann_id = self._next_annotation_id()
        ann = Snippet(
            id=ann_id, entity_id=entity_id,
            text=text, heading=heading, sentence_id=sentence_id,
        )
        self._annotations[ann_id] = ann
        return ann_id

    def add_facet(self, entity_id: str, name: str = "",
                  value: str | int | float | bool = "") -> str:
        """Add a Facet annotation and return its ID."""
        ann_id = self._next_annotation_id()
        ann = Facet(
            id=ann_id, entity_id=entity_id,
            name=name, value=value,
        )
        self._annotations[ann_id] = ann
        return ann_id

    def add_display_text(self, entity_id: str, text: str = "") -> str:
        """Add a DisplayText annotation and return its ID."""
        ann_id = self._next_annotation_id()
        ann = DisplayText(
            id=ann_id, entity_id=entity_id,
            text=text,
        )
        self._annotations[ann_id] = ann
        return ann_id

    # --- Content Methods ---

    def markdown(self, text: str) -> Markdown:
        """Add a top-level markdown block (not inside a section)."""
        content_id = self._next_content_id()
        block = Markdown(id=content_id, text=text)
        self._content.append(block)
        return block

    def table(self, headers: list[str], rows: list[list[str]]) -> Markdown:
        """Add a top-level markdown table."""
        from .content import SectionContext
        # Reuse SectionContext's table logic without a section
        def _esc(v: str) -> str:
            return str(v).replace("|", "\\|").replace("\n", " ")
        lines = [
            "| " + " | ".join(headers) + " |",
            "| " + " | ".join("---" for _ in headers) + " |",
        ]
        for row in rows:
            lines.append("| " + " | ".join(_esc(v) for v in row) + " |")
        return self.markdown("\n".join(lines))

    @contextmanager
    def section(self, title: str, description: str | None = None,
                section_id: str | None = None):
        """Create a section and yield a SectionContext for adding content."""
        content_id = section_id or self._next_content_id()
        sec = Section(id=content_id, title=title, description=description)
        self._content.append(sec)
        ctx = SectionContext(self, sec)
        yield ctx

    @contextmanager
    def sections(self, title: str):
        """Create a SECTIONS container and yield a SectionsContext."""
        content_id = self._next_content_id()
        block = Sections(id=content_id, title=title)
        self._content.append(block)
        ctx = SectionsContext(self, block)
        yield ctx

    # --- Export ---

    def to_dict(self) -> dict:
        """Export as a dictionary matching the canonical schema."""
        result: dict[str, Any] = {
            "id": self._id,
            "name": self._name,
        }

        if self._description:
            result["description"] = self._description

        result["entities"] = {
            eid: e.to_dict() for eid, e in self._entities.items()
        }
        result["annotations"] = {
            aid: a.to_dict() for aid, a in self._annotations.items()
        }
        result["content"] = [block.to_dict() for block in self._content]

        return result

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    # --- Load from existing ---

    @classmethod
    def load(cls, path: str | Path) -> Artifact:
        """Load an artifact from a JSON file."""
        path = Path(path)
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: dict) -> Artifact:
        """Create an Artifact from a canonical dictionary or A2A envelope."""
        # Unwrap A2A envelope if present
        if "artifactId" in data and "parts" in data:
            part = data["parts"][0]
            data = part["data"] if isinstance(part, dict) else part.root.data
        builder = cls(
            artifact_id=data["id"],
            name=data["name"],
            description=data.get("description"),
        )

        # Load content
        for block_data in data.get("content", []):
            block = content_block_from_dict(block_data)
            builder._content.append(block)
            builder._update_counter("_content_counter", block.id)

        # Load entities
        for entity_id, entity_data in data.get("entities", {}).items():
            entity_type = entity_data.get("type")
            if entity_type == EntityType.PAPER.value:
                entity = Paper.from_dict(entity_data)
            else:
                raise ValueError(f"Unknown entity type: {entity_type}")
            builder._entities[entity_id] = entity
            builder._update_counter("_entity_counter", entity_id)

        # Load annotations
        for ann_id, ann_data in data.get("annotations", {}).items():
            ann_type = ann_data.get("type")
            if ann_type == AnnotationType.SNIPPET.value:
                ann = Snippet.from_dict(ann_data)
            elif ann_type == AnnotationType.FACET.value:
                ann = Facet.from_dict(ann_data)
            elif ann_type == AnnotationType.DISPLAY_TEXT.value:
                ann = DisplayText.from_dict(ann_data)
            else:
                raise ValueError(f"Unknown annotation type: {ann_type}")
            builder._annotations[ann_id] = ann
            builder._update_counter("_annotation_counter", ann_id)

        return builder
