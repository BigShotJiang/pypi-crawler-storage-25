"""Artifacts CLI — export A2A task artifacts to various formats.

Usage:
    artifacts --input test-output/ --output export/
    artifacts --input test-output/ --output export/ --format html
"""

from __future__ import annotations

import json
import os
import sys

import click

from asta_artifact import Artifact
from asta_artifact.exporter import export_artifacts_to_html_directory


def _load_artifacts_from_dir(input_dir: str) -> list[Artifact]:
    """Load artifacts from all JSON files in a directory."""
    artifacts = []
    for fname in sorted(os.listdir(input_dir)):
        if not fname.endswith(".json"):
            continue
        path = os.path.join(input_dir, fname)
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Support both raw artifact dicts and A2A envelopes with parts
        if "artifacts" in data:
            for art_data in data["artifacts"]:
                if "parts" in art_data:
                    for part in art_data["parts"]:
                        part_data = part.get("data") or part
                        if "entities" in part_data and "content" in part_data:
                            artifacts.append(Artifact.from_dict(part_data))
                elif "entities" in art_data and "content" in art_data:
                    artifacts.append(Artifact.from_dict(art_data))
        elif "parts" in data:
            for part in data["parts"]:
                part_data = part.get("data") or part
                if "entities" in part_data and "content" in part_data:
                    artifacts.append(Artifact.from_dict(part_data))
        elif "entities" in data and "content" in data:
            artifacts.append(Artifact.from_dict(data))
    return artifacts


@click.command()
@click.option("--input", "input_dir", required=True,
              help="Directory containing result JSON files")
@click.option("--output", "output_dir", required=True,
              help="Directory to write exported files")
@click.option("--format", "fmt", default="html",
              type=click.Choice(["html"]),
              help="Output format (default: html)")
def main(input_dir: str, output_dir: str, fmt: str) -> None:
    """Export A2A task artifacts to HTML."""
    if not os.path.isdir(input_dir):
        click.echo(f"Error: {input_dir} is not a directory")
        sys.exit(1)

    artifacts = _load_artifacts_from_dir(input_dir)
    if not artifacts:
        click.echo(f"Error: no artifacts found in {input_dir}")
        sys.exit(1)

    click.echo(f"Loaded {len(artifacts)} artifacts from {input_dir}")

    if fmt == "html":
        export_artifacts_to_html_directory(artifacts, output_dir)

    click.echo(f"Exported to {output_dir}")


if __name__ == "__main__":
    main()
