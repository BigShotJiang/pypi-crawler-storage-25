"""Artifact HTML exporter — renders Asta artifacts as standalone HTML pages."""

from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path
from typing import TYPE_CHECKING

from .models import AnnotationType, Paper, Snippet, Facet, DisplayText
from .content import Section, Sections, Markdown, Figure, Code

if TYPE_CHECKING:
    from .artifact import Artifact

_ARTIFACT_REF_RE = re.compile(
    r'<artifact\s+id="([^"]+)"(?:\s+contentId="([^"]*)")?(?:\s*/>|>(?P<label>[^<]*)</artifact>)'
)

_PAPER_TAG_RE = re.compile(
    r"""<paper\s+entityId=["']([^"']+)["']\s+annotationId=["']([^"']+)["']"""
    r"""(?:\s+corpusId=["']([^"']+)["'])?"""
    r"""(?:\s+artifactId=["']([^"']+)["'])?\s*>"""
    r"""([^<]*)</paper>"""
)


# ---- CSS ----

COMMON_STYLES = """
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap');
body { font-family: Manrope, Arial, sans-serif; line-height: 1.6; max-width: 900px; margin: 0 auto; padding: 20px; color: #0A3235; background: #FAF2E9; }
h1, h2, h3 { font-weight: 700; }
h1 { font-size: 1.5em; border-bottom: 2px solid #105257; padding-bottom: 8px; }
h2 { font-size: 1.2em; margin-top: 24px; color: #105257; }
.desc { background: #fff; padding: 12px; margin: 12px 0; border-left: 3px solid #0FCB8C; border-radius: 4px; }
.entity-card { background: #fff; padding: 12px; margin: 8px 0; border-left: 3px solid #0FCB8C; border-radius: 4px; }
.entity-card .label { font-weight: 700; font-size: 1.05em; }
.entity-card .meta { font-size: 0.9em; color: #5D5D5D; margin-top: 4px; }
.annotation-group { margin: 12px 0; padding: 10px; background: #fff; border: 1px solid #D6D6D6; border-radius: 4px; }
.annotation-group h4 { margin: 0 0 8px 0; font-size: 0.95em; color: #5D5D5D; }
.snippet { margin: 6px 0; padding: 8px; background: #FAF2E9; border-left: 2px solid #F0529C; font-size: 0.93em; }
.snippet .heading { font-weight: 700; color: #0A3235; margin-bottom: 2px; }
.facet { display: inline-block; padding: 2px 8px; margin: 2px 4px; background: #E6FAF3; color: #105257; border-radius: 10px; font-size: 0.85em; }
.facet strong { color: #0A3235; }
.facet-group { display: flex; flex-wrap: wrap; gap: 4px; margin: 6px 0; }
.facet-detail { margin: 6px 0; padding: 6px 10px; background: #fff; border-radius: 4px; font-size: 0.9em; line-height: 1.5; }
.display-text { margin: 4px 0; font-size: 0.93em; color: #5D5D5D; }
details { margin: 8px 0; }
details summary { cursor: pointer; font-weight: 600; padding: 8px; background: #fff; border: 1px solid #D6D6D6; border-radius: 4px; color: #105257; }
details summary:hover { background: #E6FAF3; }
details > .section-body { padding: 12px; border: 1px solid #D6D6D6; border-top: none; background: #fff; }
pre { background: #0A3235; color: #FAF2E9; padding: 12px; overflow-x: auto; font-size: 0.9em; border-radius: 4px; }
code { font-family: 'Space Mono', monospace; }
a { color: #105257; text-decoration: underline; text-decoration-color: #0FCB8C; text-underline-offset: 2px; }
a:hover { color: #F0529C; }
table { border-collapse: collapse; width: 100%; margin: 12px 0; }
th, td { border: 1px solid #D6D6D6; padding: 8px 12px; text-align: left; }
th { background: #105257; color: #FAF2E9; font-weight: 600; }
tr:nth-child(even) { background: #fff; }
tr:nth-child(odd) { background: #FAF2E9; }
.toc { margin-bottom: 20px; }
.toc ul { list-style: none; padding: 0; }
.toc li { margin: 4px 0; }
.evidence { margin: 12px 0; padding: 10px; background: #fff; border-left: 3px solid #B11BE8; border-radius: 4px; }
.evidence ul { margin: 6px 0; padding-left: 20px; }
.evidence li { margin: 4px 0; font-size: 0.93em; line-height: 1.5; }
.evidence a { color: #105257; text-decoration: none; }
.evidence a:hover { color: #F0529C; text-decoration: underline; }
.evidence-line { margin: 6px 0; }
.evidence-line p { display: inline; }
.entity-badge { display: inline-block; padding: 1px 8px; margin: 1px 3px; background: #E6FAF3; border-radius: 10px; font-size: 0.8em; color: #105257; text-decoration: none; white-space: nowrap; vertical-align: middle; }
.entity-badge:hover { background: #0FCB8C; color: #fff; text-decoration: none; }
.paper-tag { display: inline-block; padding: 1px 8px; margin: 1px 3px; background: #E6FAF3; border-radius: 10px; font-size: 0.8em; color: #105257; text-decoration: none; white-space: nowrap; vertical-align: middle; cursor: pointer; }
nav a { text-decoration: underline; text-decoration-color: #0FCB8C; text-underline-offset: 2px; }
.ev-inline { display: inline-flex; align-items: center; border: 1px solid #888; border-radius: 4px; overflow: hidden; font-size: 0.82em; background: #E6FAF3; vertical-align: middle; margin: 0 2px; line-height: 1.2; }
.ev-ext { padding: 2px 7px; color: #5D5D5D; text-decoration: none; white-space: nowrap; border-right: 1px solid #888; }
.ev-ext:hover { background: #d0f0e4; color: #105257; }
.ev-cite { padding: 2px 7px; color: #105257; text-decoration: none; white-space: nowrap; font-weight: 500; }
.ev-cite:hover { background: #d0f0e4; color: #F0529C; }
.ev-div { width: 0; border-left: 1px solid #888; align-self: stretch; }
.ev-row { margin: 6px 0; display: flex; flex-wrap: wrap; gap: 6px; }
"""


# ---- Helpers ----

def _escape_html(text: str) -> str:
    return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _short_paper_label(entity: Paper) -> str:
    """Generate a short badge label from a Paper entity."""
    meta = entity.s2_metadata
    if meta:
        parts = []
        if meta.authors:
            first = meta.authors[0].name.split()[-1] if meta.authors[0].name else ""
            if len(meta.authors) > 2:
                parts.append(first + " et al.")
            elif len(meta.authors) == 2:
                parts.append(first)
            else:
                parts.append(first)
        if meta.year:
            parts.append(str(meta.year))
        label = " ".join(parts)
        if label:
            return label
    label = entity.display_label or ""
    if len(label) > 60:
        return label[:60] + "..."
    return label or "ref"


def _markdown_to_html(text: str) -> str:
    import markdown
    # Ensure blank line before list items so markdown renders them properly
    text = re.sub(r'(\S)\n([-*+] )', r'\1\n\n\2', text)
    text = re.sub(r'(\S)\n(\d+\. )', r'\1\n\n\2', text)
    return markdown.markdown(text, extensions=["extra", "tables"])


def _create_html_page(title: str, content: str, css: str) -> str:
    return (
        '<!DOCTYPE html>\n<html lang="en">\n<head>\n'
        '    <meta charset="UTF-8">\n'
        '    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n'
        f'    <title>{_escape_html(title)}</title>\n'
        f'    <style>{css}</style>\n'
        '</head>\n<body>\n'
        f'{content}\n'
        '</body>\n</html>'
    )


# ---- Exporter ----

class ArtifactExporter:
    """Export artifacts to HTML."""

    _PAPER_REF_RE = re.compile(r'paper-([0-9a-f]{20,})')

    def __init__(self, artifact: Artifact):
        self.artifact = artifact
        self._annotations_by_entity: dict[str, list] = defaultdict(list)
        for ann in artifact.annotations.values():
            self._annotations_by_entity[ann.entity_id].append(ann)
        self._inline_annotation_ids: set[str] = set()
        for block in artifact.content:
            if hasattr(block, 'annotation_ids'):
                self._inline_annotation_ids.update(block.annotation_ids)
        self._entity_links: dict[str, str] = {}
        self._source_links: dict[str, str] = {}
        self._source_names: dict[str, str] = {}

    def _render_entity(self, entity_id: str, entity: Paper,
                       link_href: str | None = None) -> str:
        parts = []
        label = _escape_html(entity.display_label or entity.id)

        # Build S2 URL
        s2_url = None
        if entity_id.startswith("paper-"):
            corpus_id = entity_id[6:]
            if corpus_id.isdigit():
                s2_url = f"https://api.semanticscholar.org/CorpusId:{corpus_id}"
        if s2_url is None and entity.s2_metadata and entity.s2_metadata.corpus_id:
            s2_url = f"https://api.semanticscholar.org/CorpusId:{entity.s2_metadata.corpus_id}"

        parts.append(f'<div class="entity-card" id="entity-{entity_id}">')
        if link_href:
            parts.append(f'<div class="label"><a href="{link_href}">{label}</a></div>')
        elif s2_url:
            parts.append(f'<div class="label"><a href="{s2_url}">{label}</a></div>')
        else:
            parts.append(f'<div class="label">{label}</div>')

        meta = entity.s2_metadata
        if meta:
            meta_items = []
            if meta.authors:
                author_names = ", ".join(a.name for a in meta.authors[:3])
                if len(meta.authors) > 3:
                    author_names += " et al."
                meta_items.append(author_names)
            if meta.year:
                meta_items.append(str(meta.year))
            if meta.venue:
                meta_items.append(meta.venue)
            if s2_url:
                meta_items.append(f'<a href="{s2_url}">Semantic Scholar</a>')
            if meta_items:
                parts.append(f'<div class="meta">{" | ".join(meta_items)}</div>')

        parts.append('</div>')
        return '\n'.join(parts)

    def _render_annotations_for_entity(self, entity_id: str) -> str:
        annotations = self._annotations_by_entity.get(entity_id, [])
        if not annotations:
            return ''

        facets = []
        display_texts = []
        for a in annotations:
            if isinstance(a, Facet) and a.id not in self._inline_annotation_ids:
                facets.append(a)
            elif isinstance(a, DisplayText):
                display_texts.append(a)

        if not facets and not display_texts:
            return ''

        parts = ['<div class="annotation-group">']

        if facets:
            # Short facets as pills, long ones as detail blocks
            short = [f for f in facets if len(str(f.value)) <= 60]
            long = [f for f in facets if len(str(f.value)) > 60]
            if short:
                parts.append('<div class="facet-group">')
                for f in short:
                    parts.append(
                        f'<span class="facet"><strong>{_escape_html(f.name)}:</strong> '
                        f'{_escape_html(str(f.value))}</span>'
                    )
                parts.append('</div>')
            for f in long:
                parts.append(
                    f'<div class="facet-detail"><strong>{_escape_html(f.name)}:</strong> '
                    f'{_escape_html(str(f.value))}</div>'
                )

        for dt in display_texts:
            parts.append(f'<div class="display-text">{_escape_html(dt.text)}</div>')

        parts.append('</div>')
        return '\n'.join(parts)

    @staticmethod
    def _parse_source_ref(text: str) -> tuple[str, str | None] | None:
        """Parse ``<artifact id="..." contentId="..." />`` from snippet text."""
        m = _ARTIFACT_REF_RE.search(text)
        if m:
            return m.group(1), m.group(2)
        return None

    def _resolve_snippet_link(self, snip: Snippet) -> str | None:
        """Resolve the best link for a snippet badge.

        Parses ``<artifact id="..." contentId="..." />`` from the snippet text
        to resolve source deep-links.  Falls back to entity_id -> file mapping.
        """
        ref = self._parse_source_ref(snip.text)
        if ref:
            artifact_id, content_id = ref
            base = self._source_links.get(artifact_id)
            if base:
                if content_id:
                    return base + "#" + content_id
                return base
        return self._entity_links.get(snip.entity_id)

    def _render_description(self, text: str) -> str:
        """Render description text, resolving inline artifact and paper references.

        Replaces ``<artifact id="..." />`` with named links and ``paper-{hash}``
        with Semantic Scholar links, while escaping all other text.
        """
        replacements = []
        for m in _ARTIFACT_REF_RE.finditer(text):
            artifact_id = m.group(1)
            inline_label = m.group("label")
            href = self._source_links.get(artifact_id)
            label = inline_label or self._source_names.get(artifact_id) or _escape_html(artifact_id)
            if href:
                replacements.append((m.start(), m.end(), f'<a href="{href}">{label}</a>'))
            else:
                replacements.append((m.start(), m.end(), label))

        for m in _PAPER_TAG_RE.finditer(text):
            if not any(s <= m.start() and e >= m.end() for s, e, _ in replacements):
                entity_id = m.group(1)
                corpus_id = m.group(3)
                citation = m.group(5)
                # Build S2 link
                s2_url = None
                if corpus_id:
                    s2_url = f"https://api.semanticscholar.org/CorpusId:{corpus_id}"
                elif entity_id in self.artifact.entities:
                    entity = self.artifact.entities[entity_id]
                    if entity.s2_metadata and entity.s2_metadata.corpus_id:
                        s2_url = f"https://api.semanticscholar.org/CorpusId:{entity.s2_metadata.corpus_id}"
                if s2_url:
                    replacements.append((m.start(), m.end(),
                                         f'<a href="{s2_url}" class="paper-tag">{_escape_html(citation)}</a>'))
                else:
                    replacements.append((m.start(), m.end(),
                                         f'<span class="paper-tag">{_escape_html(citation)}</span>'))

        for m in self._PAPER_REF_RE.finditer(text):
            if not any(s <= m.start() and e >= m.end() for s, e, _ in replacements):
                paper_key = m.group(0)
                corpus_id = m.group(1)
                entity = self.artifact.entities.get(paper_key)
                s2_url = f"https://www.semanticscholar.org/paper/{corpus_id}"
                if entity:
                    label = _escape_html(entity.display_label or paper_key)
                    replacements.append((m.start(), m.end(), f'<a href="{s2_url}">{label}</a>'))

        if not replacements:
            return _escape_html(text)

        replacements.sort(key=lambda r: r[0])
        parts = []
        last_end = 0
        for start, end, html in replacements:
            if start > last_end:
                parts.append(_escape_html(text[last_end:start]))
            parts.append(html)
            last_end = end
        if last_end < len(text):
            parts.append(_escape_html(text[last_end:]))
        return ''.join(parts)

    def _replace_artifact_tags(self, html: str) -> str:
        """Replace <artifact id="...">label</artifact> tags in rendered HTML with anchor links."""
        def _replace(m):
            artifact_id = m.group(1)
            inline_label = m.group("label")
            href = self._source_links.get(artifact_id)
            label = inline_label or self._source_names.get(artifact_id) or _escape_html(artifact_id)
            if href:
                return f'<a href="{href}">{label}</a>'
            return label
        return _ARTIFACT_REF_RE.sub(_replace, html)

    def _replace_paper_tags(self, html: str) -> str:
        """Replace <paper> tags with inline evidence button groups."""
        def _replace(m):
            entity_id = m.group(1)
            annotation_id = m.group(2)
            corpus_id = m.group(3)
            artifact_ref = m.group(4)
            citation = m.group(5)

            # Resolve S2 link
            s2_url = None
            if corpus_id:
                s2_url = f"https://api.semanticscholar.org/CorpusId:{corpus_id}"
            elif entity_id in self.artifact.entities:
                entity = self.artifact.entities[entity_id]
                if entity.s2_metadata and entity.s2_metadata.corpus_id:
                    s2_url = f"https://api.semanticscholar.org/CorpusId:{entity.s2_metadata.corpus_id}"

            # Resolve extraction artifact link from artifactId attribute
            extraction_link = None
            extraction_label = None
            if artifact_ref:
                art_id = artifact_ref.split("#")[0]
                extraction_link = self._source_links.get(art_id)
                name = self._source_names.get(art_id, "")
                if name:
                    extraction_label = name[:30] + "…" if len(name) > 30 else name
            else:
                # Fallback: resolve from annotation snippet text
                ann = self.artifact.annotations.get(annotation_id)
                if ann and isinstance(ann, Snippet):
                    ref = self._parse_source_ref(ann.text)
                    if ref:
                        extraction_link = self._source_links.get(ref[0])
                        name = self._source_names.get(ref[0], "")
                        if name:
                            extraction_label = name[:30] + "…" if len(name) > 30 else name

            # Build inline evidence group
            parts = []
            if extraction_link and extraction_label:
                parts.append(f'<a href="{extraction_link}" class="ev-ext">{_escape_html(extraction_label)}</a>')
            if s2_url:
                parts.append(f'<a href="{s2_url}" class="ev-cite">{_escape_html(citation)}</a>')
            else:
                parts.append(f'<span class="ev-cite">{_escape_html(citation)}</span>')

            return '<span class="ev-inline">' + '<span class="ev-div"></span>'.join(parts) + '</span>'
        return _PAPER_TAG_RE.sub(_replace, html)

    def _render_content_block(self, block, content_by_id: dict) -> str:
        if isinstance(block, Sections):
            inner_parts = []
            for child_id in block.child_ids:
                child = content_by_id.get(child_id)
                if child:
                    inner_parts.append(self._render_content_block(child, content_by_id))

            section_id = block.id.replace("_", "-")
            parts = [f'<details open id="{_escape_html(section_id)}">']
            parts.append(f'<summary>{_escape_html(block.title)}</summary>')
            parts.append('<div class="section-body">')
            parts.extend(inner_parts)
            parts.append('</div></details>')
            return '\n'.join(parts)

        if isinstance(block, Section):
            inner_parts = []
            for child_id in block.child_ids:
                child = content_by_id.get(child_id)
                if child:
                    inner_parts.append(self._render_content_block(child, content_by_id))

            section_id = block.id.replace("_", "-")
            parts = [f'<details open id="{_escape_html(section_id)}">']
            parts.append(f'<summary>{_escape_html(block.title)}</summary>')
            parts.append('<div class="section-body">')

            if block.description:
                parts.append(f'<div class="desc">{self._render_description(block.description)}</div>')

            parts.extend(inner_parts)
            parts.append('</div></details>')
            return '\n'.join(parts)

        if isinstance(block, Markdown):
            html = _markdown_to_html(block.text)
            html = self._replace_artifact_tags(html)
            html = self._replace_paper_tags(html)

            # Render inline annotations (facets + snippet evidence pills)
            if block.annotation_ids:
                has_paper_tags = _PAPER_TAG_RE.search(block.text) is not None
                snippets = []
                facets = []
                for aid in block.annotation_ids:
                    ann = self.artifact.annotations.get(aid)
                    if isinstance(ann, Snippet) and not has_paper_tags:
                        snippets.append(ann)
                    elif isinstance(ann, Facet):
                        facets.append(ann)

                # Evidence pills from snippet annotations
                evidence_pills = []
                seen_entities: set[str] = set()
                for snip in snippets:
                    eid = snip.entity_id
                    if eid in seen_entities:
                        continue
                    seen_entities.add(eid)
                    entity = self.artifact.entities.get(eid)
                    citation = _short_paper_label(entity) if entity else eid

                    s2_url = None
                    if entity and entity.s2_metadata and entity.s2_metadata.corpus_id:
                        s2_url = f"https://api.semanticscholar.org/CorpusId:{entity.s2_metadata.corpus_id}"
                    elif eid.startswith("paper-"):
                        cid = eid[6:]
                        if cid.isdigit():
                            s2_url = f"https://api.semanticscholar.org/CorpusId:{cid}"

                    if s2_url:
                        evidence_pills.append(f'<a href="{s2_url}" class="ev-cite">{_escape_html(citation)}</a>')
                    else:
                        evidence_pills.append(f'<span class="ev-cite">{_escape_html(citation)}</span>')

                seen_facets: set[str] = set()
                pills = []
                for f in facets:
                    key = f"{f.name}:{f.value}"
                    if key in seen_facets:
                        continue
                    seen_facets.add(key)
                    pills.append(
                        f'<span class="facet"><strong>{_escape_html(f.name)}:</strong> '
                        f'{_escape_html(str(f.value))}</span>'
                    )

                extra = ''
                if evidence_pills:
                    extra += '\n<div class="ev-row">' + ' '.join(
                        f'<span class="ev-inline">{p}</span>' for p in evidence_pills
                    ) + '</div>'
                if pills:
                    extra += '\n<div class="facet-group">' + ''.join(pills) + '</div>'

                return f'<div class="evidence-line">{html}{extra}</div>'

            return f'<div class="evidence-line">{html}</div>'

        if isinstance(block, Figure):
            parts = ['<figure>']
            if block.imageb64:
                parts.append(f'<img src="data:image/png;base64,{block.imageb64}" alt="Figure" style="max-width:100%">')
            if block.caption:
                parts.append(f'<figcaption>{_escape_html(block.caption)}</figcaption>')
            parts.append('</figure>')
            return '\n'.join(parts)

        if isinstance(block, Code):
            lang = block.language or ''
            return f'<pre><code class="language-{_escape_html(lang)}">{_escape_html(block.code)}</code></pre>'

        return ''

    def to_html(self, include_entities: bool = True,
                include_raw_json: bool = False,
                entity_links: dict | None = None,
                source_links: dict | None = None,
                source_names: dict | None = None,
                nav_html: str | None = None) -> str:
        if entity_links:
            self._entity_links = entity_links
        if source_links:
            self._source_links = source_links
        if source_names:
            self._source_names = source_names

        html: list[str] = []
        if nav_html:
            html.append(nav_html)

        html.append(f'<h1>{_escape_html(self.artifact.name)}</h1>')

        # Build content_by_id lookup and identify child blocks
        content_by_id: dict = {}
        child_block_ids: set[str] = set()
        for block in self.artifact.content:
            content_by_id[block.id] = block
            if isinstance(block, (Section, Sections)):
                child_block_ids.update(block.child_ids)

        # Table of contents for top-level sections only
        sections = [b for b in self.artifact.content
                    if isinstance(b, (Section, Sections)) and b.id not in child_block_ids]
        if sections:
            html.append('<div class="toc"><strong>Contents:</strong><ul>')
            for sec in sections:
                sec_id = sec.id.replace("_", "-")
                html.append(f'<li><a href="#{_escape_html(sec_id)}">{_escape_html(sec.title)}</a></li>')
            html.append('</ul></div>')

        # Render only top-level content (skip blocks owned by sections)
        for block in self.artifact.content:
            if block.id in child_block_ids:
                continue
            html.append(self._render_content_block(block, content_by_id))

        # Related artifacts
        if self._source_links:
            items = []
            for artifact_id, href in sorted(self._source_links.items()):
                label = self._source_names.get(artifact_id, artifact_id)
                items.append(f'<li><a href="{href}">{_escape_html(label)}</a></li>')
            if items:
                html.append('<hr><nav class="toc"><strong>Related Artifacts:</strong><ul>')
                html.extend(items)
                html.append('</ul></nav>')

        # Entities (only if there are any)
        if include_entities and self.artifact.entities:
            html.append('<hr><h2>Entities</h2>')
            for eid, entity in self.artifact.entities.items():
                link = self._entity_links.get(eid)
                html.append(self._render_entity(eid, entity, link))
                html.append(self._render_annotations_for_entity(eid))

        # Raw JSON
        if include_raw_json:
            html.append('<hr><h2>Raw JSON (Debug)</h2>')
            html.append(f'<pre>{_escape_html(json.dumps(self.artifact.to_dict(), indent=2))}</pre>')

        return _create_html_page(self.artifact.name, '\n'.join(html), COMMON_STYLES)

    def save_html(self, path: str | Path, **kwargs) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(self.to_html(**kwargs))


# ---- Convenience functions ----

def export_artifact_to_html(artifact: Artifact, path: str | Path) -> None:
    """Convenience function to export an artifact to HTML."""
    ArtifactExporter(artifact).save_html(path)


def export_artifact_directory_to_html(artifact_dir: str | Path,
                                      output_path: str | Path) -> None:
    """Export an artifact directory (with artifact.json) to HTML."""
    from .artifact import Artifact
    artifact_dir = Path(artifact_dir)
    json_path = artifact_dir / "artifact.json"
    if not json_path.exists():
        raise FileNotFoundError(f"artifact.json not found in {artifact_dir}")
    artifact = Artifact.load(json_path)
    export_artifact_to_html(artifact, output_path)


# ---- Multi-artifact directory export ----

def _slugify(text: str) -> str:
    """Convert text to a filesystem-safe slug."""
    import re
    slug = text.lower().strip()
    slug = re.sub(r'[^\w\s-]', '', slug)
    slug = re.sub(r'[\s_]+', '-', slug)
    slug = re.sub(r'-+', '-', slug).rstrip('-')
    return slug


def _build_links(artifact: Artifact, other_artifacts: list[Artifact],
                 other_filenames: dict[str, str]):
    """Build (entity_links, source_links, source_names) for an artifact.

    entity_links: entity_id -> href (Paper entities shared across artifacts)
    source_links: artifact_id -> href (for snippet source deep-links)
    source_names: artifact_id -> display name (for link labels)
    """
    entity_links: dict[str, str] = {}
    source_links: dict[str, str] = {}
    source_names: dict[str, str] = {}

    artifact_id_to_file: dict[str, str] = {}
    artifact_id_to_name: dict[str, str] = {}
    for other in other_artifacts:
        fname = other_filenames.get(other.id, '')
        artifact_id_to_file[other.id] = fname
        artifact_id_to_name[other.id] = other.name

    # Sort others: those with more annotations first
    sorted_others = sorted(other_artifacts, key=lambda a: len(a.annotations))

    # Map paper entities to files containing them
    paper_to_file: dict[str, str] = {}
    for other in sorted_others:
        for eid in other.entities:
            if eid not in paper_to_file:
                target = other_filenames.get(other.id)
                if target:
                    paper_to_file[eid] = target

    for eid in artifact.entities:
        if eid in paper_to_file:
            entity_links[eid] = paper_to_file[eid]

    # Build source links from snippet text and artifact content
    for ann in artifact.annotations.values():
        if isinstance(ann, Snippet):
            ref = ArtifactExporter._parse_source_ref(ann.text)
            if ref:
                aid = ref[0]
                if aid in artifact_id_to_file:
                    source_links[aid] = artifact_id_to_file[aid]
                    source_names[aid] = artifact_id_to_name.get(aid, aid)

    texts_to_scan = []
    if artifact.description:
        texts_to_scan.append(artifact.description)
    for block in artifact.content:
        if hasattr(block, 'text'):
            texts_to_scan.append(block.text)

    for text in texts_to_scan:
        for m in _ARTIFACT_REF_RE.finditer(text):
            aid = m.group(1)
            if aid in artifact_id_to_file:
                source_links[aid] = artifact_id_to_file[aid]
                source_names[aid] = artifact_id_to_name.get(aid, aid)

    return entity_links, source_links, source_names


def _find_child_artifact_ids(artifact: Artifact) -> set[str]:
    """Extract referenced artifact IDs from <artifact id="..." /> tags in description, annotations, and content."""
    ids: set[str] = set()
    if artifact.description:
        for m in _ARTIFACT_REF_RE.finditer(artifact.description):
            ids.add(m.group(1))
    for ann in artifact.annotations.values():
        if hasattr(ann, 'text'):
            for m in _ARTIFACT_REF_RE.finditer(ann.text):
                ids.add(m.group(1))
    for block in artifact.content:
        if hasattr(block, 'text'):
            for m in _ARTIFACT_REF_RE.finditer(block.text):
                ids.add(m.group(1))
    return ids


def _build_hierarchy(artifacts: list[Artifact]):
    """Build parent-child hierarchy from <artifact> references.

    Returns (roots, children_of) where roots are artifacts not referenced
    as children of any parent, and children_of maps artifact IDs to their
    child artifacts.
    """
    by_id: dict[str, Artifact] = {}
    for art in artifacts:
        by_id.setdefault(art.id, art)

    children_of: dict[str, list[Artifact]] = {}
    all_child_ids: set[str] = set()

    # Count how many parents reference each child
    child_ref_count: dict[str, int] = {}
    for art in artifacts:
        child_ids = _find_child_artifact_ids(art)
        for cid in child_ids:
            if cid in by_id:
                child_ref_count[cid] = child_ref_count.get(cid, 0) + 1

    # Only attach children that are referenced by a single parent.
    # Widely-shared artifacts (like schemas referenced by many extractions)
    # stay as standalone root-level entries instead of being nested N times.
    for art in artifacts:
        child_ids = _find_child_artifact_ids(art)
        children = []
        seen_children: set[str] = set()
        for cid in child_ids:
            if cid in by_id and cid not in seen_children and child_ref_count.get(cid, 0) <= 1:
                children.append(by_id[cid])
                all_child_ids.add(cid)
                seen_children.add(cid)
        if children:
            children_of.setdefault(art.id, []).extend(children)

    # Find root IDs (not referenced as children)
    seen_root_ids: set[str] = set()
    roots = []
    for art in artifacts:
        if art.id not in all_child_ids and art.id not in seen_root_ids:
            roots.append(art)
            seen_root_ids.add(art.id)

    return roots, children_of


_INDEX_CSS = """
@import url('https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&display=swap');
body { font-family: Manrope, Arial, sans-serif; margin: 0; padding: 20px 20px 40px; color: #0A3235; background: #FAF2E9; }
h1 { font-weight: 700; font-size: 1.5em; border-bottom: 2px solid #105257; padding-bottom: 8px; max-width: 960px; margin: 0 auto 24px; }
.dag { max-width: 960px; margin: 0 auto; }
.lane { margin-bottom: 0; position: relative; }
.lane-label { font-size: 0.88em; text-transform: uppercase; letter-spacing: 0.06em; color: #105257; font-weight: 700; margin-bottom: 8px; padding-left: 4px; }
.lane-list { margin: 0; padding: 12px 12px 12px 32px; background: #fff; border: 1px solid #D6D6D6; border-radius: 6px; list-style: disc; }
.lane-list li { padding: 3px 0; font-size: 0.92em; }
.lane-list a { color: #105257; text-decoration: underline; text-decoration-color: #0FCB8C; text-underline-offset: 2px; }
.lane-list a:hover { color: #F0529C; }
.connectors { display: flex; justify-content: center; padding: 4px 0; }
.connector-dot { width: 2px; height: 18px; background: #b0c4b8; margin: 0 8px; border-radius: 1px; }
.connector-arrow { width: 0; height: 0; border-left: 5px solid transparent; border-right: 5px solid transparent; border-top: 6px solid #b0c4b8; margin: 0 auto; }
.connector-row { display: flex; flex-direction: column; align-items: center; padding: 2px 0; }
"""


def export_artifacts_to_html_directory(artifacts: list[Artifact],
                                       output_dir: str | Path) -> Path:
    """Export a hierarchical HTML page of artifacts with expand/collapse.

    Builds parent-child relationships from embedded <artifact> references.
    Renders a single index.html with nested <details> elements.
    Individual artifact HTML files are also written for detail views.

    Returns the path to the output directory.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    roots, children_of = _build_hierarchy(artifacts)

    # Generate filenames
    filenames: dict[str, str] = {}
    for art in artifacts:
        slug = _slugify(art.name)
        filenames.setdefault(art.id, slug + ".html")

    # Render individual artifact pages
    for art in artifacts:
        others = [a for a in artifacts if a.id != art.id]
        sibling_filenames = {a.id: filenames.get(a.id, '') for a in others}
        entity_links, source_links, source_names = _build_links(art, others, sibling_filenames)

        exporter = ArtifactExporter(art)
        back_nav = '<nav><a href="index.html">&larr; All artifacts</a></nav>'
        html = exporter.to_html(
            entity_links=entity_links,
            source_links=source_links,
            source_names=source_names,
            nav_html=back_nav,
        )
        with open(output_dir / filenames[art.id], 'w', encoding='utf-8') as f:
            f.write(html)

    # ── Layered DAG layout (pure Python) ──
    # Assign each artifact a rank (depth from roots) via BFS.
    by_id_all: dict[str, Artifact] = {a.id: a for a in artifacts}
    children_of_full: dict[str, set[str]] = {}
    parents_of: dict[str, set[str]] = {}
    for art in artifacts:
        child_ids = _find_child_artifact_ids(art)
        for cid in child_ids:
            if cid in by_id_all:
                children_of_full.setdefault(art.id, set()).add(cid)
                parents_of.setdefault(cid, set()).add(art.id)

    # Find roots (no parents)
    all_ids = {a.id for a in artifacts}
    all_child_ids_dag = set()
    for kids in children_of_full.values():
        all_child_ids_dag.update(kids)
    root_ids = all_ids - all_child_ids_dag

    # Assign ranks: longest path from any root (ensures children are always deeper)
    ranks: dict[str, int] = {}
    from collections import deque
    queue = deque((rid, 0) for rid in root_ids)
    while queue:
        nid, depth = queue.popleft()
        if nid in ranks and ranks[nid] >= depth:
            continue
        ranks[nid] = depth
        for cid in children_of_full.get(nid, set()):
            queue.append((cid, depth + 1))

    # Assign rank 0 to any unvisited nodes
    for aid in all_ids:
        if aid not in ranks:
            ranks[aid] = 0

    # Group by rank
    max_rank = max(ranks.values()) if ranks else 0
    lanes: list[list[Artifact]] = [[] for _ in range(max_rank + 1)]
    for art in artifacts:
        lanes[ranks[art.id]].append(art)

    # Build connector dots between lanes
    def _connector_html():
        return (
            '<div class="connectors">'
            '<div class="connector-row">'
            '<div class="connector-dot"></div>'
            '<div class="connector-arrow"></div>'
            '</div>'
            '</div>'
        )

    # Lane labels: derive from common prefix or use "Layer N"
    def _lane_label(lane_arts: list[Artifact]) -> str:
        names = [a.name for a in lane_arts]
        # Check for common prefix pattern (e.g. "Extraction:", "Schema:")
        for prefix in ["Schema:", "Extraction:"]:
            if all(n.startswith(prefix) for n in names):
                return prefix.rstrip(":") + "s"
        # Check if none have a prefix (likely theories)
        if not any(n.startswith(("Schema:", "Extraction:")) for n in names):
            if len(names) > 1:
                return "Theories"
            return "Theory"
        return f"Layer {ranks[lane_arts[0].id]}"

    body_parts = ['<h1>Artifacts</h1>', '<div class="dag">']

    for rank, lane_arts in enumerate(lanes):
        if not lane_arts:
            continue

        label = _lane_label(lane_arts)
        body_parts.append(f'<div class="lane">')
        body_parts.append(f'<div class="lane-label">{_escape_html(label)}</div>')
        body_parts.append('<ul class="lane-list">')
        for art in lane_arts:
            href = filenames.get(art.id, '')
            name = _escape_html(art.name)
            if href:
                body_parts.append(f'<li><a href="{href}">{name}</a></li>')
            else:
                body_parts.append(f'<li>{name}</li>')
        body_parts.append('</ul></div>')

        # Add connector between lanes (except after last)
        if rank < max_rank:
            body_parts.append(_connector_html())

    body_parts.append('</div>')

    index_html = _create_html_page('Artifacts', '\n'.join(body_parts), _INDEX_CSS)
    with open(output_dir / 'index.html', 'w', encoding='utf-8') as f:
        f.write(index_html)

    return output_dir
