echo "Before run"
