"""beeflow common gdb module."""
