"""beeflow common module."""
