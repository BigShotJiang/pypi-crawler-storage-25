"""beeflow common integration module."""
