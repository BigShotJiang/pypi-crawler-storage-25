"""beeflow common crt module."""
