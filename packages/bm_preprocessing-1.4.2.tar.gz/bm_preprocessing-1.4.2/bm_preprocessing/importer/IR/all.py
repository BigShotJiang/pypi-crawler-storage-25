from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "IR" / "all.py"
dm_doc = SourceCodeModule("bm_preprocessing.IR.all", _source_file)
