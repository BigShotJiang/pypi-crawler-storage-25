from pathlib import Path

from .._module_printer import SourceCodeModule

_source_file = Path(__file__).parents[2] / "src" / "DM" / "dm_doc.py"
dm_doc = SourceCodeModule("bm_preprocessing.DM.dm_doc", _source_file)
