# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2022-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import pytest

import tests


@pytest.mark.parametrize('cmd, expected', (
    ('covreport', 'report'),
    ('tmp', 'tmp'),
    ('venv', 'venv'),
    ('shortcut', 'baw'),
    ('name', 'Beta Alpha Omega'),
    ('requirement', ''),
    ('sources', 'baw'),
    ('image', 'try_baw'),
    ('stable', ''),
    ('branch', ''),
))
# ('describe', ''), # does not work on github TODO: ENABLE LATER
def test_cmd_info(cmd, expected, monkeypatch, capsys):
    tests.baaw(
        f'info {cmd}',
        monkeypatch,
    )
    stdout = tests.stdout(capsys)
    if expected:
        assert expected in stdout, str(stdout)


def test_cmd_requirement_info(monkeypatch, capsys):
    tests.baaw(
        'info requirement',
        monkeypatch,
        verbose=False,
    )
    stdout = tests.stdout(capsys)
    # ensure that stdout only procudes a single int
    hashed = int(stdout)  # pylint:disable=W0612


def test_cmd_requirement_verbose_info(monkeypatch, capsys):
    tests.baaw(
        '--verbose info requirement',
        monkeypatch,
    )
    stdout = tests.stdout(capsys)
    assert stdout.startswith('baw:')
    assert len(stdout.split('_')) == 1


def test_cmd_info_clean(simple, capsys):  # pylint:disable=W0621,W0613
    """Ensure that workspace is clean."""
    simple[0]('info clean')
    stdout = tests.stdout(capsys)
    # ensure that workspace is clean
    assert 'clean' in stdout


def test_cmd_info_cov(simple, capsys):
    simple[0]('info cov')
    stdout = tests.stdout(capsys)
    assert '100.0' in stdout
