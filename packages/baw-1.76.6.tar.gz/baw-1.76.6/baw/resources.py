# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2021-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================
"""Base for generating project. Templates have to be here."""

import os
import time

import utilo

import baw
import baw.config
import baw.project.version
import baw.utils

FOLDERS = [
    'tests',
    'docs',
    'docs/releases',
]

TEMPLATES = os.path.join(baw.ROOT, 'baw/templates')
assert os.path.exists(TEMPLATES), f'No template-dir {TEMPLATES}'

fread = utilo.file_read


def joined(path: str, asserts: bool = True) -> str:
    result = os.path.join(TEMPLATES, path)
    if asserts:
        assert os.path.exists(result), f'Does not exists {result}'
    return result


LICENSE_TEMPLATE = fread(joined('LICENSE'))
WORKSPACE_TEMPLATE = joined('.code-workspace')
GIT_IGNORE_TEMPLATE = joined('.gitignore')
RCFILE_PATH = joined('.rcfile')
ISORT_PATH = joined('.isort.cfg')
CONFTEST_PATH = joined('conftest.tpy')

README = """\
# {{SHORT}}
"""

CHANGELOG = """\
# Changelog

Every noteable change is logged here.

## v0.0.0 initial release
"""

LICENSE = """\
# Licence
"""

BACKLOG_RST = """\
.. _backlog:

backlog
=======
"""

RELEASE_RST = """\
releases
========

Upcomming releases must be planned here. See unplanned features in
:ref:`backlog` to create next release plan.

current
-------

.. toctree::
  :maxdepth: 1

completed
---------

.. toctree::
  :maxdepth: 1

"""

INDEX_RST = """\
Welcome to {{NAME}}
======================================

Progress
--------

.. toctree::
  :maxdepth: 1

  releases/releases
  releases/backlog
  CHANGELOG

Modules
-------

.. toctree::
   :maxdepth: 4

   modules

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

"""

COPYRIGHT = """\
#==============================================================================
# C O P Y R I G H T
#------------------------------------------------------------------------------
# Copyright (c) 2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
#==============================================================================
"""

REQUIREMENTS = COPYRIGHT

INIT = COPYRIGHT + """
import os

__version__ = '0.0.0'

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
"""

ENTRY_POINT = """\
[project.scripts]
{{SHORT}} = "{{SHORT}}.cli:main"
"""

INIT_CMD = COPYRIGHT + """\
import utilo
import utilo.cli

from {{SHORT}} import __version__

COMMANDS = [] # add additional cmds here

@utilo.saveme
def main():
    parser = utilo.cli.create_parser(
        COMMANDS,
        version=__version__,
        config=utilo.ParserConfiguration(
            outputparameter=True,
            inputparameter=True,
        ),
    )
    args = utilo.parse(parser)
    inputpath, output, _ = utilo.sources(args)  # pylint:disable=W0612,W0632
    return utilo.SUCCESS
"""

MAIN_CMD = COPYRIGHT + """\
from {{SHORT}}.cli import main

if __name__ == "__main__":
    main()
"""

CODE_WORKSPACE = fread(WORKSPACE_TEMPLATE)
JENKINSFILE = fread(joined('Jenkinsfile'))
GITIGNORE = fread(joined('.gitignore'))
SETUP_PY = fread(joined('pyproject'))
RELEASE_PLAN = fread(joined('docs/plan.rst'))

REFACTOR = fread(joined('refactor'))

DOC_CONF = fread(joined('conf.py'))

ISORT_TEMPLATE = fread(ISORT_PATH)
CONFTEST_TEMPLATE = fread(CONFTEST_PATH)

WORKFLOWS = '.github/workflows'

# None copies files
FILES = [
    # ('..code-workspace', CODE_WORKSPACE),
    ('.git/info/exclude', GITIGNORE),
    ('CHANGELOG', CHANGELOG),
    ('LICENSE', LICENSE_TEMPLATE),
    ('README', README),
    ('docs/index.rst', INDEX_RST),
    ('docs/releases/backlog.rst', BACKLOG_RST),
    ('docs/releases/releases.rst', RELEASE_RST),
    ('tests/__init__.py', COPYRIGHT),
    ('tests/conftest.py', CONFTEST_TEMPLATE),
    (baw.utils.REQUIREMENTS_TXT, REQUIREMENTS),
]

DOTGITHUB = [
    ('.github/dependabot.yml', fread(joined('.github/dependabot.yml'))),
    (f'{WORKFLOWS}/docker.yml', fread(joined(f'{WORKFLOWS}/docker.yml'))),
    (f'{WORKFLOWS}/pypi.yml', fread(joined(f'{WORKFLOWS}/pypi.yml'))),
    (f'{WORKFLOWS}/release.yml', fread(joined(f'{WORKFLOWS}/release.yml'))),
    (f'{WORKFLOWS}/test.yml', fread(joined(f'{WORKFLOWS}/test.yml'))),
    ('Makefile', fread(joined('Makefile'))),
]


def template_replace(root: str, template: str, **kwargs) -> str:
    """Replace $vars in template

    Args:
        root(str): project root
        template(str): which contains the {{VARS}}
        kwargs(str): list of variables to replace in template
    Returns:
        content of template with replaced vars
    Hint:
        Vars are defined as {{VARNAME}}.
    """
    root = baw.forward_slash(root, save_newline=False)
    short = baw.config.shortcut(root)
    source = baw.config.sources(root)
    name_ = baw.config.name(root)
    version_tag = baw.project.version.determine(root)
    year = str(time.localtime(time.time()).tm_year)

    template = template.replace('{{SHORT}}', short)
    template = template.replace('{{PACKAGE}}', short)
    template = template.replace('{{SOURCES}}', ', '.join(source))
    template = template.replace('{{NAME}}', name_)
    template = template.replace('{{VERSION}}', version_tag)
    template = template.replace('{{ROOT}}', root)
    template = template.replace('{{YEAR}}', year)

    for key, value in kwargs.items():
        value = str(value)  # ensure to repace str
        template = template.replace('{{' + key.upper() + '}}', value)
    template = template.strip()
    return template
