# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2022-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import baw.cmd.test
import baw.cmd.utils


def run(args: dict):
    root = baw.cmd.utils.get_root(args)
    pattern = args.get('pattern', 'all')
    if pattern == 'all':
        pattern = True
    completed = baw.cmd.test.run_test(
        root,
        generate=pattern,
        verbose=args['verbose'],
    )
    return completed


def extend_cli(parser):
    cli = parser.add_parser(
        'generate',
        help='Generate test data',
    )
    cli.add_argument(
        'pattern',
        help='Generate test data',
        nargs='?',
        const='all',
    )
    cli.add_argument(
        '--overwrite',
        help='overwrite already generated data',
        action='store_true',
    )
    cli.set_defaults(func=run)
