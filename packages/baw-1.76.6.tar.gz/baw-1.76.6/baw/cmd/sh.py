# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2022-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import sys

import baw.cmd.utils
import baw.runtime


def run_shell(args: dict):
    cmd = args['cmd']
    root = baw.cmd.utils.get_root(args)
    completed = baw.runtime.run_target(
        root=root,
        cmd=cmd,
        cwd=root,
        verbose=False,
        debugging=True,
    )
    if completed.returncode:
        sys.exit(completed.returncode)
    sys.exit(baw.SUCCESS)
