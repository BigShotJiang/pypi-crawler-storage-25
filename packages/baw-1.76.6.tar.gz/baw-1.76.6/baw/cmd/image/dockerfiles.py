# =============================================================================
# C O P Y R I G H T
# -----------------------------------------------------------------------------
# Copyright (c) 2022-2023 by Helmut Konrad Schewe. All rights reserved.
# This file is property of Helmut Konrad Schewe. Any unauthorized copy,
# use or distribution is an offensive act against international law and may
# be prosecuted under federal law. Its content is company confidential.
# =============================================================================

import contextlib
import os
import sys

import utilo

import baw.cmd.info
import baw.cmd.utils
import baw.config
import baw.pipefile
import baw.project.version
import baw.utils


@contextlib.contextmanager
def generate(root: str, inject: bool = False, install: bool = False):
    name = baw.cmd.info.requirement_hash(root, verbose=True)
    name = name.replace(':', '_')
    # use own tmpfile cause TemporaryFile(delete=True) seems no supported
    # at linux, parameter delete is missing.
    config = os.path.join(root, name)
    content = header(root)
    content += baw.NEWLINE * 2
    content += environments(root)
    content += requirements(root)
    content += SYNC
    if install:
        use = baw.project.version.determine(root, verbose=True)
        content += INSTALL % use
    if setup := baw.config.docker_setup(root):
        content += f'RUN ls; {setup}'
    if inject:
        content += resources(root)
    baw.utils.file_replace(
        config,
        content,
    )
    yield config
    # remove file
    os.unlink(config)


DEFAULT_IMAGE = 'alpine:3.23.3'


def header(root: str) -> str:
    """\
    >>> header(__file__)
    'FROM .../...'
    """
    root = baw.cmd.utils.determine_root(root)
    if not root:
        sys.exit(baw.FAILURE)
    image = baw.pipefile.docker_image(root)
    if not image:
        image = DEFAULT_IMAGE
        baw.error(f'Could not parse docker image: {image} in {root}')
    result = f'FROM {image}'
    return result


FILES = 'requirements.txt requirements.dev requirements.all'.split()


def requirements(root: str) -> str:
    r"""\
    >>> requirements(__file__)
    ''
    """
    # TODO: REMOVE LATER
    root = baw.cmd.utils.determine_root(root)
    if not root:
        sys.exit(baw.FAILURE)
    result = ''
    for item in FILES:
        path = os.path.join(root, item)
        if not os.path.exists(path):
            continue
        result += f'COPY {item} /var/workdir/{item}{baw.NEWLINE}'
    return result


RESOURCES = ('.baw setup.py '
             'README.md README CHANGELOG.md CHANGELOG'
             ' tests').split()
# RESOURCES += ['.git']


def resources(root: str) -> str:
    r"""Copy resources to generate test data.

    >>> resources(__file__)
    ''
    """
    root = baw.cmd.utils.determine_root(root)
    if not root:
        sys.exit(baw.FAILURE)
    conftest = os.path.join(root, 'tests/conftest.py')
    if not os.path.exists(conftest):
        return ''
    if 'RESOURCES' not in utilo.file_read(conftest):
        # resource generator step is not required
        return ''
    result = ''
    for item in baw.config.sources(root) + RESOURCES:
        path = os.path.join(root, item)
        if not os.path.exists(path):
            continue
        if os.path.isfile(path):
            result += f'COPY {item} /var/workdir/{item}{baw.NEWLINE}'
        else:
            result += f'COPY {item}/ /var/workdir/{item}/{baw.NEWLINE}'
    result += GENERATE
    return result


def environments(root: str) -> str:
    r"""\
    ENV RUNJOB="exit 1"
    >>> environments(__file__) # '...ENV GITEA_SERVER_URL=...\n'
    ''
    """
    root = baw.cmd.utils.determine_root(root)
    if not root:
        sys.exit(baw.FAILURE)
    env = baw.pipefile.docker_env(root)
    if not env:
        return ''
    result = ''
    for key, value in env.items():
        result += f'ENV {key}="{value}"{baw.NEWLINE}'
    return result


SYNC = """
RUN baw sync all
"""

INSTALL = """
RUN pip install %s
"""

GENERATE = """
# ensure to run with maximum computing power
ENV JENKINS_HOME="TRUE"
RUN baw generate all
"""
