export { activate } from "./activate";
