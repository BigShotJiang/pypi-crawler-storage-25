"""
cli.py - Command-line interface utilities for pyBBQ.

Handles terminal output such as the startup logo.
"""

import sys


# ANSI escape code for yellow text and reset.
# These are widely supported on modern terminals (Linux, macOS, Windows 10+).
_YELLOW = "\033[93m"
_RESET = "\033[0m"

# Unicode block-art logo. Uses box-drawing and block characters that may not
# render on terminals with limited code-page support (e.g. Windows cp437/cp850).
_LOGO_UNICODE = r"""
  ██████╗ ██╗   ██╗██████╗ ██████╗  ██████╗
  ██╔══██╗╚██╗ ██╔╝██╔══██╗██╔══██╗██╔═══██╗
  ██████╔╝ ╚████╔╝ ██████╔╝██████╔╝██║   ██║
  ██╔═══╝   ╚██╔╝  ██╔══██╗██╔══██╗██║▄▄ ██║
  ██║        ██║   ██████╔╝██████╔╝╚██████╔╝
  ╚═╝        ╚═╝   ╚═════╝ ╚═════╝  ╚══▀▀═╝
"""

# Pure-ASCII fallback logo for terminals that cannot display Unicode block art.
_LOGO_ASCII = r"""
  ____       ____  ____   ___
 |  _ \ _   | __ )|  _ \ / _ \
 | |_) | | | |  _ \| |_) | | | |
 |  __/| |_| | |_) |  _ <| |_| |
 |_|    \__, |____/|_| \_\\__\_\
         |___/
"""


def _supports_unicode() -> bool:
    """Return True if the current stdout encoding can represent Unicode art.

    We test by attempting to encode a representative block character. If the
    encoding raises UnicodeEncodeError (common on Windows with cp850/cp437
    code pages), we fall back to pure ASCII.
    """
    encoding = getattr(sys.stdout, "encoding", None) or "ascii"
    try:
        "█".encode(encoding)
        return True
    except (UnicodeEncodeError, LookupError):
        return False


def main() -> None:
    """Console script entry point for pybbq.

    Parses command-line arguments and launches the pyBBQ solver.
    Usage: pybbq <input.yaml> [output_dir] [Sweep|SweepFull]
    """
    import sys
    # Local import to avoid circular dependency (pyBBQ imports from cli)
    from pybbq.pybbq import pyBBQ

    print_logo()
    if len(sys.argv) > 3:
        print('Loading the provided yaml file: ' + sys.argv[1])
        if sys.argv[3] == 'Sweep':
            pyBBQ(sys.argv[1], sys.argv[2], 'Sweep')
        elif sys.argv[3] == 'SweepFull':
            pyBBQ(sys.argv[1], sys.argv[2], 'SweepFull')
        else:
            pyBBQ(sys.argv[1], sys.argv[2])
    elif len(sys.argv) > 2:
        print('Loading the provided yaml file: ' + sys.argv[1])
        pyBBQ(sys.argv[1], sys.argv[2])
    elif len(sys.argv) > 1:
        print('Loading the provided yaml file: ' + sys.argv[1])
        pyBBQ(sys.argv[1])
    else:
        print('No input yaml file provided.')


def print_logo() -> None:
    """Print the pyBBQ startup logo to stdout in yellow.

    Automatically selects the Unicode block-art version when the terminal
    supports it, and falls back to a plain ASCII version otherwise.
    """
    logo = _LOGO_UNICODE if _supports_unicode() else _LOGO_ASCII
    # colour is applied only when stdout is a real terminal (not redirected
    # to a file or pipe) to avoid polluting captured output with escape codes.
    if sys.stdout.isatty():
        print(f"{_YELLOW}{logo}{_RESET}")
    else:
        print(logo)
