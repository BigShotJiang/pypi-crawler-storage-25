# Changelog

All notable changes to `enkindler-cli` are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and
this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.1] — Fix CLI ↔ backend body-key drift

A full audit of every body-bearing CLI request against the OpenAPI spec
**and** the live backend turned up four bugs of the same shape: spec
and backend disagree, the CLI followed the spec, and the backend
rejected (or silently ignored) the request. All four are fixed here.

### Fixed
- `enkindler deployment yaml-edit` no longer fails with `400 yaml is required`.
  The PATCH body now uses key `yaml` (was `deployment_yaml`).
- `enkindler deployment pipeline cd --enable|--disable` no longer fails
  with `400 continuous_deployment must be a boolean`. The PATCH body now
  uses key `continuous_deployment` (was `enabled`).
- `enkindler deployment pipeline attach` now requires `--branch`. The
  backend rejects requests without `watched_branch`, so the CLI fails
  fast with a helpful Typer error instead of letting the user hit a 400.

### Changed (minor break)
- `enkindler deployment build` no longer accepts `--branch` or `--commit`.
  The backend silently ignored both flags — the build always ran from
  the pipeline's attached `watched_branch`. Removing rather than warning,
  per user preference; restore once the backend honors them per the
  spec. To build from a different branch today, attach the pipeline with
  the new branch (`enkindler deployment pipeline attach <id> --pipeline P --branch B`),
  build, then reattach to the original branch.

### Internal
- 4 new regression tests in `tests/commands/test_deployments.py` pin
  the PATCH/POST body shape for the three fixed routes plus the
  flag-removal on `build`. Suite is now 93 tests (up from 89).
- The smoke checklist at `docs/smoke-checklists/deployments.md` would
  have caught all four — process-wise, run it before tagging future
  releases.

## [0.3.0] — Phase 7: cluster sub-app (full surface)

### Added
- `enkindler cluster ...` — wraps all 43 routes under `/api/cluster/*`.
  - **Top-level**: `health`, `metrics`, `deployments` (cluster-wide),
    `pods` (cluster-wide), `pv`, `storageclass`.
  - **`node`**: `list`, `get <name>`.
  - **`namespace`**: `list`, `get <ns>`, `delete <ns>` (destructive).
  - **`pod`**: `get <ns> <name>`, `logs <ns> <name> [--container --tail
    --previous --follow]`, `events <ns> <name> [--follow]`,
    `exec <ns> <name> -- <cmd...>` (kubectl exec equivalent),
    `probe <ns> <name> --port N [--path --method --header]`.
  - **`deployment`**: `get`, `delete` (destructive), `scale --replicas N`,
    `logs [--follow]`, `events [--follow]`, `rollout-status`, `replicasets`.
  - **`statefulset`**: `get`, `events`, `logs`.
  - **`service`**: `list <ns>`, `get <ns> <name>`, `endpoints <ns> <name>`.
  - **`configmap`**: `list <ns>`, `get <ns> <name>`.
  - **`secret`**: `list <ns>`, `get <ns> <name>` (values never returned).
  - **`ingress`**: `list <ns>`, `get <ns> <name>`.
  - **`networkpolicy`**: `list <ns>`.
  - **`pvc`**: `list <ns>`.
  - **`config ingress`**: `get`, `update '<json>'` (ingress-nginx ConfigMap).
- `--follow` flag on `pod logs`, `pod events`, `deployment logs`,
  `deployment events` — uses the `_sse.stream_sse` helper from Phase 1 to
  consume the four SSE streams (`*/logs/stream`, `*/events/stream`).

### Internal
- 53 new pytest-httpx tests in `tests/commands/test_cluster.py` covering
  all 43 ops + 401/403/404 error envelopes + SSE parsing.
- SDK regenerated (`make regen-sdk`) against the new 62-path / 48-schema spec.

## [0.2.0] — Phase 1: deployment write verbs

### Added
- `enkindler deployment delete <id>` — destructive; confirm prompt or `--yes`.
- `enkindler deployment scale <id> --replicas N` — set replica count.
- `enkindler deployment env <id> --set KEY=VAL [--unset KEY] [--secret]` —
  update env vars or secrets; triggers a rolling restart.
- `enkindler deployment force-restart <id>` — destructive; rolls every pod.
- `enkindler deployment yaml-edit <id>` — opens `$EDITOR` with the live K8s
  YAML; PATCHes on save.
- `enkindler deployment build <id> [--branch B] [--commit SHA]` — trigger
  a CI/CD build via the attached Build Pipeline.
- `enkindler deployment rollback <id> --to <history-id>` — roll back to a
  prior revision returned by `deployment history`.
- `enkindler deployment history <id>` — list rollback targets.
- `enkindler deployment logs <id> [--container C] [--tail N]` — non-streaming
  log snapshot per pod.
- `enkindler deployment status <id>` — live K8s status.
- `enkindler deployment refresh-status` — re-poll every deployment.
- `enkindler deployment promote-pending <id>` — promote a non-CD build.
- `enkindler deployment pipeline attach|detach|cd <id>` — manage the attached
  Build Pipeline.

### Improved
- 403 errors now show the missing permission name (read from the backend's
  `required` / `missing_permission` envelope field) so callers know which
  role they need.
- 401 errors only suggest `enkindler login`; 403 errors no longer prompt
  re-login (the existing token is fine, the user just lacks the perm).

### Internal
- New `_render`, `_sse`, `_sdk` modules under `enkindler_cli/` to share table
  rendering, SSE parsing, and the generated-SDK shim across phases 2–10.
- `Client._raise()` now attaches the parsed JSON body to `AuthError`.
- `Client.stream()` for SSE — used in upcoming Pipelines / Cluster phases.
- Makefile: `regen-sdk` produces a clean SDK at `src/enkindler_cli/_generated/`
  (fixed the flatten step that previously dropped `client.py` / `errors.py`).
- New `make regen-sdk-local` target for iterating against a local backend.
- New test fixtures (`fake_cluster`) and per-command pytest-httpx coverage.

## [0.1.3] — 2026-04-25

- Multi-cluster `config` sub-app, OAuth Auth Code + PKCE login, and the
  initial `deployment list` / `deployment get` verbs.
