"""Enkindler command-line interface."""

__version__ = "0.3.1"
