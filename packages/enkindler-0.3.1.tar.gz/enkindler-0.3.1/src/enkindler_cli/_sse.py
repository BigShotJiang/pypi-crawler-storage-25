"""Server-Sent Events helper used by future streaming commands.

Phases 6 (Pipelines) and 7 (Cluster) will use this for `--follow` flags. It
lives in phase 1 so the CLI's HTTP shape is locked in before SSE routes show up.

The backend's SSE convention is event-typed JSON lines:

    event: log
    data: {"line": "...", "ts": "..."}

This module yields `(event, data_dict)` tuples. Lines that aren't JSON come
through as `(event, {"_raw": "..."})` so callers can still see them.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from typing import Any

from .client import Client


def stream_sse(
    client: Client,
    path: str,
    *,
    params: dict[str, Any] | None = None,
) -> Iterator[tuple[str, dict[str, Any]]]:
    """Stream SSE events from `path`. Yields `(event, data)` tuples until EOF.

    `event` defaults to `"message"` per the SSE spec when no `event:` line is
    present. `data` is the parsed JSON payload, or `{"_raw": "..."}` if the
    backend sent a non-JSON `data:` line.
    """
    yield from parse_sse(client.stream(path, params=params))


def parse_sse(byte_chunks: Iterator[bytes]) -> Iterator[tuple[str, dict[str, Any]]]:
    """Parse a stream of byte chunks as SSE. Public so tests can feed it directly."""
    buf = ""
    event = "message"
    data_lines: list[str] = []
    for chunk in byte_chunks:
        buf += chunk.decode("utf-8", errors="replace")
        while "\n" in buf:
            line, buf = buf.split("\n", 1)
            line = line.rstrip("\r")
            if line == "":
                if data_lines:
                    yield event, _parse_data("\n".join(data_lines))
                event = "message"
                data_lines = []
                continue
            if line.startswith(":"):
                # SSE comment / heartbeat — ignore.
                continue
            if line.startswith("event:"):
                event = line[len("event:"):].strip()
            elif line.startswith("data:"):
                data_lines.append(line[len("data:"):].lstrip())
            # Other fields (id:, retry:) ignored — we don't reconnect.
    # Flush trailing event without a blank-line terminator.
    if data_lines:
        yield event, _parse_data("\n".join(data_lines))


def _parse_data(payload: str) -> dict[str, Any]:
    try:
        parsed = json.loads(payload)
    except json.JSONDecodeError:
        return {"_raw": payload}
    if isinstance(parsed, dict):
        return parsed
    return {"_raw": parsed}
