"""Shared rendering helpers used by all command modules.

Tables, key-value object views, and destructive-action confirmation.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

console = Console()
err_console = Console(stderr=True)


def render_table(
    rows: Iterable[Mapping[str, Any]],
    columns: list[tuple[str, str]],
    *,
    empty_message: str = "No results.",
) -> None:
    """Print a Rich table.

    `columns` is a list of `(header, key)` tuples. Each row is dot-walked using
    `key` (e.g. `"creator.email"`). Missing values render as `—`.
    """
    rows = list(rows)
    if not rows:
        console.print(f"[dim]{empty_message}[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    for header, _ in columns:
        table.add_column(header)
    for row in rows:
        cells = [_format_cell(_dotwalk(row, key)) for _, key in columns]
        table.add_row(*cells)
    console.print(table)


def render_object(d: Mapping[str, Any], fields: list[tuple[str, str]]) -> None:
    """Print a flat key/value view of a single object.

    `fields` is a list of `(label, key)` tuples; key supports dot-walking.
    """
    for label, key in fields:
        value = _format_cell(_dotwalk(d, key))
        console.print(f"  {label}: {value}")


def confirm_destructive(action: str, name: str, *, yes_flag: bool) -> None:
    """Prompt before a destructive action unless --yes was passed.

    Aborts via `typer.Exit(1)` on rejection. Prints to stderr so stdout stays
    machine-parseable.
    """
    if yes_flag:
        return
    err_console.print(f"[yellow]About to {action}: [bold]{name}[/bold][/yellow]")
    if not typer.confirm("Continue?", default=False):
        err_console.print("[dim]Aborted.[/dim]")
        raise typer.Exit(code=1)


def _dotwalk(obj: Any, key: str) -> Any:
    cur: Any = obj
    for part in key.split("."):
        if isinstance(cur, Mapping):
            cur = cur.get(part)
        else:
            return None
        if cur is None:
            return None
    return cur


def _format_cell(value: Any) -> str:
    if value is None or value == "":
        return "—"
    if isinstance(value, bool):
        return "yes" if value else "no"
    return str(value)
