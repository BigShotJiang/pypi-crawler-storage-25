"""Multi-cluster CLI configuration.

Storage layout (TOML at platformdirs.user_config_dir/config.toml):

    default = "prod"

    [clusters.dev]
    url = "https://enkindler-dev.acme.corp"
    token = "eyJ..."           # optional; written by `enkindler login`
    user_email = "x@acme.com"  # optional
    instance_name = "acme-dev" # set on `enkindler config add` from /api/instance

    [clusters.prod]
    url = "https://enkindler.acme.corp"
    ...

Cluster names are local labels. They don't have to be unique across users.
A user typically has names like `dev`, `tst`, `prod`. If they manage multiple
customers, they prefix: `acme-prod`, `globex-prod`, etc.
"""

from __future__ import annotations

import contextlib
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

import platformdirs

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

import tomli_w

APP_NAME = "enkindler"


def config_dir() -> Path:
    """Cross-platform per-user config directory.

    macOS:   ~/Library/Application Support/enkindler
    Linux:   ~/.config/enkindler
    Windows: %APPDATA%\\enkindler
    """
    return Path(platformdirs.user_config_dir(APP_NAME, appauthor=False, roaming=True))


def config_path() -> Path:
    return config_dir() / "config.toml"


class ConfigError(Exception):
    """Raised when configuration is missing or inconsistent."""


@dataclass
class Cluster:
    name: str
    url: str
    token: str | None = None
    user_email: str | None = None
    instance_name: str | None = None

    def to_dict(self) -> dict[str, str]:
        d: dict[str, str] = {"url": self.url}
        if self.token:
            d["token"] = self.token
        if self.user_email:
            d["user_email"] = self.user_email
        if self.instance_name:
            d["instance_name"] = self.instance_name
        return d


@dataclass
class Config:
    clusters: dict[str, Cluster] = field(default_factory=dict)
    default: str | None = None

    @classmethod
    def load(cls) -> Config:
        path = config_path()
        if not path.exists():
            return cls()
        with path.open("rb") as f:
            data = tomllib.load(f)
        clusters = {
            name: Cluster(
                name=name,
                url=str(cdata.get("url", "")).rstrip("/"),
                token=cdata.get("token"),
                user_email=cdata.get("user_email"),
                instance_name=cdata.get("instance_name"),
            )
            for name, cdata in (data.get("clusters") or {}).items()
        }
        return cls(clusters=clusters, default=data.get("default"))

    def save(self) -> None:
        path = config_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        payload: dict[str, object] = {}
        if self.default:
            payload["default"] = self.default
        if self.clusters:
            payload["clusters"] = {name: c.to_dict() for name, c in self.clusters.items()}
        with path.open("wb") as f:
            tomli_w.dump(payload, f)
        if os.name != "nt":
            with contextlib.suppress(OSError):
                path.chmod(0o600)

    # ─── Mutations ──────────────────────────────────────────────────────────

    def add(self, cluster: Cluster, *, make_default: bool = False) -> None:
        if cluster.name in self.clusters:
            raise ConfigError(
                f"Cluster '{cluster.name}' already exists. Remove it first or pick a different name."
            )
        self.clusters[cluster.name] = cluster
        if make_default or self.default is None:
            self.default = cluster.name

    def remove(self, name: str) -> None:
        if name not in self.clusters:
            raise ConfigError(f"No cluster named '{name}'.")
        del self.clusters[name]
        if self.default == name:
            # Pick any remaining cluster as default, or clear it.
            self.default = next(iter(self.clusters), None)

    def set_default(self, name: str) -> None:
        if name not in self.clusters:
            raise ConfigError(f"No cluster named '{name}'.")
        self.default = name

    def update_token(self, name: str, *, token: str, user_email: str | None) -> None:
        if name not in self.clusters:
            raise ConfigError(f"No cluster named '{name}'.")
        self.clusters[name].token = token
        if user_email:
            self.clusters[name].user_email = user_email

    def clear_token(self, name: str) -> None:
        if name in self.clusters:
            self.clusters[name].token = None
            self.clusters[name].user_email = None

    # ─── Resolution ─────────────────────────────────────────────────────────

    def resolve(self, cluster_name: str | None = None) -> Cluster:
        """Pick the cluster to operate on.

        Order: explicit --cluster arg > default cluster > error.
        """
        if cluster_name:
            if cluster_name not in self.clusters:
                raise ConfigError(
                    f"No cluster named '{cluster_name}'. Run `enkindler config list` to see configured clusters."
                )
            return self.clusters[cluster_name]
        if self.default and self.default in self.clusters:
            return self.clusters[self.default]
        if not self.clusters:
            raise ConfigError(
                "No clusters configured. Run `enkindler config add --name <name> --url <url>` to add one."
            )
        raise ConfigError(
            "No default cluster set. Run `enkindler config use <name>` to pick one, "
            "or pass --cluster <name> to this command."
        )


def effective_url_override() -> str | None:
    """Returns ENKINDLER_API_URL if set, else None.

    The env var still works as a one-shot override for local dev:
        ENKINDLER_API_URL=http://localhost:5179 enkindler whoami
    Per-command --api-url is a Typer flag handled at the command level.
    """
    env = os.environ.get("ENKINDLER_API_URL")
    return env.rstrip("/") if env else None
