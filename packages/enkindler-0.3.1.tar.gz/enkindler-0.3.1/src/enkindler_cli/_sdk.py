"""Bridge between our `Cluster` resolution and the openapi-python-client SDK.

The generated SDK lives under `enkindler_cli._generated` (gitignored, produced
by `make regen-sdk`). Importing the generated package on a fresh clone would
fail — so this shim imports lazily and gives a friendly error if the user
forgot to regenerate.

Most commands in phases 1+ are short enough that hand-rolled `Client` calls
remain simpler than the generated SDK. Use `sdk_client` only when a route
benefits from typed models (e.g. complex `oneOf` request bodies in phase 5).
"""

from __future__ import annotations

from typing import Any

from .client import APIError, AuthError
from .config import Cluster, Config, ConfigError, effective_url_override


class SDKMissingError(RuntimeError):
    """The generated SDK isn't present. Tell the user to run `make regen-sdk`."""


def sdk_client(cluster: Cluster | None = None, *, api_url_override: str | None = None) -> Any:
    """Return a generated `AuthenticatedClient` pointed at the resolved cluster.

    Raises `SDKMissingError` if the generated SDK hasn't been built yet.
    """
    try:
        # Generated package layout: enkindler_cli._generated.client.AuthenticatedClient.
        from ._generated.client import AuthenticatedClient  # type: ignore[import-not-found]
    except ImportError as e:
        raise SDKMissingError(
            "Generated SDK not found. Run `make regen-sdk` to build it from the backend OpenAPI spec."
        ) from e

    if cluster is None:
        cluster = Config.load().resolve(None)
    if not cluster.token:
        raise ConfigError(
            f"Cluster '{cluster.name}' has no token. Run `enkindler login --cluster {cluster.name}`."
        )
    base_url = api_url_override or effective_url_override() or cluster.url
    return AuthenticatedClient(base_url=base_url, token=cluster.token)


# Re-export the shared error types so generated-SDK call sites can catch one symbol.
__all__ = ["APIError", "AuthError", "SDKMissingError", "sdk_client"]
