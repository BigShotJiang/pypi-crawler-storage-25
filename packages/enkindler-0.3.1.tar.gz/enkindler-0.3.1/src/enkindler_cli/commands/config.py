"""`enkindler config ...` — manage local cluster configuration.

Subcommands:
    enkindler config            interactive add-first-cluster (or print list)
    enkindler config add        non-interactive add
    enkindler config list       show configured clusters
    enkindler config use NAME   set default cluster
    enkindler config remove NAME
    enkindler config show [NAME]
    enkindler config path       print the config file path
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from ..client import APIError, Client
from ..config import Cluster, Config, ConfigError, config_path

app = typer.Typer(no_args_is_help=False, help="Manage local cluster configuration.")
console = Console()
err_console = Console(stderr=True)


def _verify_url(url: str) -> dict:
    """Hit GET /api/instance to confirm the URL is an Enkindler backend.
    Raises typer.Exit on any failure with a friendly message."""
    try:
        with Client.for_url(url) as c:
            info = c.get("/api/instance")
    except APIError as e:
        err_console.print(f"[red]Could not reach {url}:[/red] {e.message}")
        raise typer.Exit(code=1) from None
    except Exception as e:
        err_console.print(f"[red]Could not reach {url}:[/red] {e}")
        raise typer.Exit(code=1) from None
    if not isinstance(info, dict) or info.get("product") != "enkindler":
        err_console.print(f"[red]{url} responded but is not an Enkindler backend.[/red]")
        raise typer.Exit(code=1)
    return info


@app.callback(invoke_without_command=True)
def root(ctx: typer.Context) -> None:
    """Default behaviour when called as bare `enkindler config`."""
    if ctx.invoked_subcommand is not None:
        return
    cfg = Config.load()
    if cfg.clusters:
        # Show the list — same as `enkindler config list`.
        _print_list(cfg)
        return
    # No clusters → drop into interactive add.
    console.print("[bold]No clusters configured.[/bold] Let's add one.\n")
    name = typer.prompt('Cluster name (e.g. "dev", "prod")').strip()
    url = typer.prompt("Backend URL (e.g. https://enkindler.acme.corp)").strip().rstrip("/")
    info = _verify_url(url)
    instance_name = info.get("name", url)
    console.print(f"[green]✓[/green] Verified [bold]{instance_name}[/bold] (Enkindler v{info.get('version', '?')})")
    cluster = Cluster(name=name, url=url, instance_name=instance_name)
    cfg.add(cluster, make_default=True)
    cfg.save()
    console.print(f"[green]✓[/green] Saved cluster [bold]{name}[/bold] (default).")
    console.print("\nNext: [bold]enkindler login[/bold] to sign in.")


@app.command("add")
def add(
    name: str = typer.Option(..., "--name", help="Local label for this cluster (e.g. dev, prod, acme-prod)."),
    url: str = typer.Option(..., "--url", help="Backend base URL (e.g. https://enkindler.acme.corp)."),
    default: bool = typer.Option(False, "--default", help="Set as the default cluster."),
    skip_verify: bool = typer.Option(False, "--skip-verify", help="Don't call /api/instance to verify the URL."),
) -> None:
    """Add a cluster non-interactively."""
    url = url.rstrip("/")
    cfg = Config.load()
    if name in cfg.clusters:
        err_console.print(f"[red]Cluster '{name}' already exists.[/red] Remove it first or pick a different name.")
        raise typer.Exit(code=1)
    instance_name: str | None = None
    if not skip_verify:
        info = _verify_url(url)
        instance_name = info.get("name", url)
        console.print(f"[green]✓[/green] Verified [bold]{instance_name}[/bold] (Enkindler v{info.get('version', '?')})")
    try:
        cfg.add(Cluster(name=name, url=url, instance_name=instance_name), make_default=default)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None
    cfg.save()
    is_default = " (default)" if cfg.default == name else ""
    console.print(f"[green]✓[/green] Added cluster [bold]{name}[/bold]{is_default}.")


@app.command("list")
def list_clusters() -> None:
    """Show configured clusters."""
    cfg = Config.load()
    _print_list(cfg)


def _print_list(cfg: Config) -> None:
    if not cfg.clusters:
        console.print("[dim]No clusters configured. Run `enkindler config` to add one.[/dim]")
        return
    table = Table(show_header=True, header_style="bold")
    table.add_column("Name")
    table.add_column("URL")
    table.add_column("Instance")
    table.add_column("Default", justify="center")
    table.add_column("Signed in")
    for name, c in cfg.clusters.items():
        table.add_row(
            name,
            c.url,
            c.instance_name or "—",
            "*" if cfg.default == name else "",
            c.user_email or "—",
        )
    console.print(table)


@app.command("use")
def use(name: str = typer.Argument(..., help="Cluster name to make default.")) -> None:
    """Set the default cluster."""
    cfg = Config.load()
    try:
        cfg.set_default(name)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None
    cfg.save()
    console.print(f"[green]✓[/green] Default cluster is now [bold]{name}[/bold].")


@app.command("remove")
def remove(name: str = typer.Argument(..., help="Cluster name to remove.")) -> None:
    """Remove a cluster from the local config (does not affect the backend)."""
    cfg = Config.load()
    try:
        cfg.remove(name)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None
    cfg.save()
    console.print(f"[green]✓[/green] Removed [bold]{name}[/bold].")
    if cfg.default:
        console.print(f"  Default is now [bold]{cfg.default}[/bold].")


@app.command("show")
def show(name: str | None = typer.Argument(None, help="Cluster name (defaults to the current default).")) -> None:
    """Print the resolved cluster's URL and signed-in user."""
    cfg = Config.load()
    try:
        c = cfg.resolve(name)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None
    console.print(f"[bold]Name:[/bold]      {c.name}")
    console.print(f"[bold]URL:[/bold]       {c.url}")
    console.print(f"[bold]Instance:[/bold]  {c.instance_name or '—'}")
    console.print(f"[bold]Signed in:[/bold] {c.user_email or '—'}")
    console.print(f"[bold]Default:[/bold]   {'yes' if cfg.default == c.name else 'no'}")


@app.command("path")
def path() -> None:
    """Print the absolute path to the config file."""
    console.print(str(config_path()))
