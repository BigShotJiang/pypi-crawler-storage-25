"""`enkindler login` and `enkindler logout`.

Login uses OAuth 2.0 Authorization Code with PKCE against Microsoft Entra ID:

  1. Fetch /api/instance to discover {azure_ad.tenant_id, client_id}.
  2. Generate PKCE verifier + S256 challenge, random `state`, pick a free
     localhost port, start a tiny HTTP server.
  3. Open the user's browser to Microsoft's authorize endpoint with
     redirect_uri=http://localhost:<port> and the challenge.
  4. Local server catches the redirect with ?code=...&state=...
     (or, with --no-browser, prompt the user to paste the code).
  5. POST {code, code_verifier, redirect_uri} to /api/auth/cli/callback,
     which exchanges with Azure as a public client and returns an Enkindler
     JWT. JWT is written to the cluster's slot in the config file.
"""

from __future__ import annotations

import base64
import contextlib
import hashlib
import http.server
import secrets
import socket
import threading
import urllib.parse
import webbrowser

import typer
from rich.console import Console

from ..client import APIError, Client
from ..config import Config, ConfigError, effective_url_override

console = Console()
err_console = Console(stderr=True)


# ─── PKCE primitives ──────────────────────────────────────────────────────────

def _pkce_pair() -> tuple[str, str]:
    """Return (verifier, S256 challenge). RFC 7636."""
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).decode().rstrip("=")
    digest = hashlib.sha256(verifier.encode()).digest()
    challenge = base64.urlsafe_b64encode(digest).decode().rstrip("=")
    return verifier, challenge


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


# ─── Local callback server ────────────────────────────────────────────────────

_PAGE_STYLE = (
    "body{font-family:system-ui,sans-serif;max-width:480px;margin:80px auto;"
    "text-align:center;color:#222}h1{margin:0 0 8px}p{color:#555}"
)


def _success_html() -> bytes:
    return (
        '<!doctype html><html><head><meta charset="utf-8"><title>Enkindler login</title>'
        f'<style>{_PAGE_STYLE} h1{{color:#16a34a}}</style></head><body>'
        '<h1>✓ Signed in</h1>'
        '<p>You can close this tab and return to your terminal.</p>'
        '</body></html>'
    ).encode()


def _error_html(msg: str) -> bytes:
    safe = (msg or "Login failed").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return (
        '<!doctype html><html><head><meta charset="utf-8"><title>Enkindler login</title>'
        f'<style>{_PAGE_STYLE} h1{{color:#dc2626}}</style></head><body>'
        '<h1>✗ Login failed</h1>'
        f'<p>{safe}</p>'
        '<p>Return to your terminal for details.</p>'
        '</body></html>'
    ).encode()


class _Result:
    """Mutable holder for the captured ?code= / ?error= from the redirect."""
    code: str | None = None
    state: str | None = None
    error: str | None = None
    error_description: str | None = None


def _make_handler(result: _Result, expected_state: str):
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, *args, **kwargs):  # silence per-request stderr
            pass

        def do_GET(self):
            url = urllib.parse.urlparse(self.path)
            qs = urllib.parse.parse_qs(url.query)
            has_code = "code" in qs
            has_error = "error" in qs

            # The browser fires extra requests (favicon.ico, prefetch, etc.)
            # alongside the real OAuth redirect. Only the request carrying the
            # OAuth `code` or `error` is the actual callback — everything else
            # is noise we should silently ignore. Without this gate, a
            # favicon request would race the real callback and OVERWRITE
            # `result.error`, masking a successful login as a state mismatch.
            if not (has_code or has_error):
                self.send_response(204)
                self.end_headers()
                return

            if has_error:
                err = qs.get("error", [""])[0]
                desc = qs.get("error_description", [""])[0] or err
                result.error = err
                result.error_description = desc
                self.send_response(400)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(_error_html(desc))
                return

            state = qs.get("state", [None])[0]
            if state != expected_state:
                result.error = "state_mismatch"
                result.error_description = "OAuth state did not match — possible CSRF."
                self.send_response(400)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(_error_html(result.error_description))
                return

            result.code = qs["code"][0]
            result.state = state
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write(_success_html())

    return Handler


# ─── Login flow ───────────────────────────────────────────────────────────────

def login(
    cluster: str | None = typer.Option(
        None, "--cluster", "-c", help="Cluster name (defaults to the configured default).",
    ),
    api_url: str | None = typer.Option(
        None, "--api-url", help="Override the cluster's URL (advanced).",
    ),
    no_browser: bool = typer.Option(
        False, "--no-browser",
        help="Do not open a browser; print the URL and accept a pasted authorization code.",
    ),
) -> None:
    """Sign in via Microsoft (OAuth Authorization Code + PKCE)."""
    cfg = Config.load()
    try:
        c = cfg.resolve(cluster)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None

    base = api_url or effective_url_override() or c.url
    console.print(f"Signing in to [bold]{c.name}[/bold] ({base})")

    # 1. Discover Azure AD tenant + client_id from the backend.
    with Client(base_url=base) as client:
        try:
            instance = client.get("/api/instance")
        except APIError as e:
            err_console.print(f"[red]Could not reach {base}:[/red] {e.message}")
            raise typer.Exit(code=1) from None
    aad = instance.get("azure_ad")
    if not aad or not aad.get("tenant_id") or not aad.get("client_id"):
        err_console.print("[red]This Enkindler backend is not configured for Azure AD login.[/red]")
        raise typer.Exit(code=1)
    tenant_id = aad["tenant_id"]
    client_id = aad["client_id"]

    # 2. PKCE + state.
    verifier, challenge = _pkce_pair()
    state = secrets.token_urlsafe(24)

    # 3. Build authorize URL.
    auth_params = {
        "client_id": client_id,
        "response_type": "code",
        "scope": "openid profile email offline_access",
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "state": state,
        "prompt": "select_account",
    }

    if no_browser:
        # Out-of-band (paste-the-code) flow. We use the special "nativeclient"
        # redirect URI which Azure renders as a page that displays the code
        # for the user to copy.
        redirect_uri = "https://login.microsoftonline.com/common/oauth2/nativeclient"
        auth_params["redirect_uri"] = redirect_uri
        authorize_url = (
            f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/authorize"
            f"?{urllib.parse.urlencode(auth_params)}"
        )
        console.print()
        console.print("Open this URL on a machine with a browser:")
        console.print(f"[bold cyan]{authorize_url}[/bold cyan]")
        console.print()
        console.print("After signing in, Microsoft will display an authorization code.")
        code = typer.prompt("Paste the code here").strip()
        if not code:
            err_console.print("[red]No code provided.[/red]")
            raise typer.Exit(code=1)
    else:
        # Interactive (browser → localhost) flow.
        port = _free_port()
        # Azure's loopback wildcard accepts any port but matches the path
        # exactly. We registered `http://localhost` (no path), so the redirect
        # must also have no path — just `http://localhost:<port>`.
        redirect_uri = f"http://localhost:{port}"
        auth_params["redirect_uri"] = redirect_uri
        authorize_url = (
            f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/authorize"
            f"?{urllib.parse.urlencode(auth_params)}"
        )

        result = _Result()
        server = http.server.HTTPServer(("127.0.0.1", port), _make_handler(result, state))
        server.timeout = 1
        server_thread = threading.Thread(
            target=server.serve_forever, kwargs={"poll_interval": 0.5}, daemon=True,
        )
        server_thread.start()

        console.print()
        console.print("Opening browser to sign in…")
        console.print(f"If it doesn't open, visit: [cyan]{authorize_url}[/cyan]")
        console.print()
        opened = False
        with contextlib.suppress(webbrowser.Error):
            opened = webbrowser.open(authorize_url)
        if not opened:
            err_console.print(
                "[yellow]Could not open a browser. Re-run with [bold]--no-browser[/bold] for the paste-the-code fallback.[/yellow]",
            )
            server.shutdown()
            raise typer.Exit(code=1)

        try:
            with console.status("Waiting for browser approval…", spinner="dots"):
                # Wait up to 5 minutes for the redirect to land.
                for _ in range(300):
                    if result.code or result.error:
                        break
                    threading.Event().wait(1.0)
        finally:
            server.shutdown()
            server_thread.join(timeout=2)

        if result.error:
            err_console.print(f"[red]Login failed:[/red] {result.error_description or result.error}")
            raise typer.Exit(code=1)
        if not result.code:
            err_console.print("[red]Login timed out.[/red] Run `enkindler login` again.")
            raise typer.Exit(code=1)
        code = result.code

    # 4. Exchange code with the backend for an Enkindler JWT.
    with Client(base_url=base) as client:
        try:
            resp = client.post(
                "/api/auth/cli/callback",
                json={
                    "code": code,
                    "code_verifier": verifier,
                    "redirect_uri": redirect_uri,
                },
            )
        except APIError as e:
            err_console.print(f"[red]Login failed:[/red] {e.message}")
            raise typer.Exit(code=1) from None

    if resp.get("status") != "authorized" or not resp.get("token"):
        err_console.print(f"[red]Unexpected response:[/red] {resp}")
        raise typer.Exit(code=1)

    cfg.update_token(c.name, token=resp["token"], user_email=resp.get("user", {}).get("email"))
    cfg.save()
    console.print(
        f"[green]✓ Signed in to[/green] [bold]{c.name}[/bold] as [bold]{resp.get('user', {}).get('email', 'user')}[/bold]",
    )


def logout(
    cluster: str | None = typer.Option(None, "--cluster", "-c", help="Cluster to sign out of (defaults to the configured default)."),
) -> None:
    """Clear the locally cached token. Does not invalidate the JWT server-side."""
    cfg = Config.load()
    try:
        c = cfg.resolve(cluster)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None
    if not c.token:
        console.print(f"Already signed out of [bold]{c.name}[/bold].")
        return
    cfg.clear_token(c.name)
    cfg.save()
    console.print(f"[green]✓ Signed out of[/green] [bold]{c.name}[/bold].")
