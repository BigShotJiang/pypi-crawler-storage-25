"""`enkindler cluster ...` — wraps the 43 routes under /api/cluster/*.

Layout:
- top-level verbs that don't fit a sub-noun: `health`, `metrics`,
  `deployments` (cluster-wide list), `pods` (cluster-wide list).
- sub-apps for each Kubernetes object kind: `node`, `namespace`, `pod`,
  `deployment`, `statefulset`, `service`, `endpoint`, `configmap`, `secret`,
  `ingress`, `networkpolicy`, `pvc`, `pv`, `storageclass`, `replicaset`,
  plus a `config ingress` pair for the ingress-nginx ConfigMap.

All ops use the hand-rolled `Client` (not the generated SDK). Streaming
verbs (`*-stream`) live behind `--follow` flags and use `_sse.stream_sse`.
"""

from __future__ import annotations

import json
import shlex
from typing import Any

import typer
from rich.console import Console

from .._render import confirm_destructive, render_object, render_table
from .._sse import stream_sse
from ..client import Client, ConfigError
from ..config import Config

app = typer.Typer(no_args_is_help=True, help="Inspect the Kubernetes cluster behind this Enkindler instance.")
console = Console()
err_console = Console(stderr=True)

# ─── Shared options ──────────────────────────────────────────────────────────
_CLUSTER_OPT = typer.Option(None, "--cluster", "-c", help="Cluster name from `enkindler config list`.")
_API_URL_OPT = typer.Option(None, "--api-url", help="Override the cluster's API URL for this command.")
_YES_OPT = typer.Option(False, "--yes", "-y", help="Skip the destructive-action confirmation prompt.")
_EXEC_CMD_ARG = typer.Argument(..., help="Command + args to run inside the pod (e.g. ls /tmp).")
_PROBE_HEADER_OPT = typer.Option([], "--header", "-H", help="Extra header in 'Key: Value' form. Repeatable.")


def _resolve(cluster: str | None, api_url: str | None) -> Client:
    cfg = Config.load()
    try:
        c = cfg.resolve(cluster)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None
    return Client.from_cluster(c, api_url_override=api_url)


def _print_json(obj: Any) -> None:
    console.print(json.dumps(obj, indent=2, default=str))


def _follow_sse(client: Client, path: str) -> None:
    """Print SSE frames as `[event] {json}` lines until interrupted."""
    try:
        for event, data in stream_sse(client, path):
            payload = json.dumps(data, default=str) if data else ""
            console.print(f"[bold cyan]\\[{event}][/bold cyan] {payload}")
    except KeyboardInterrupt:
        err_console.print("[dim]Stream interrupted.[/dim]")


# ─── Top-level overview verbs ────────────────────────────────────────────────


@app.command("health")
def cluster_health(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Cluster-wide health snapshot."""
    with _resolve(cluster, api_url) as c:
        h = c.get("/api/cluster/health")
    pods = h.get("pods") or {}
    nodes = h.get("nodes") or {}
    console.print(f"Nodes:      {h.get('totalNodes')} total — {nodes}")
    console.print(f"Namespaces: {h.get('totalNamespaces')}")
    console.print(f"Pods:       {pods}")
    if h.get("conditions"):
        console.print("Conditions:")
        for cond in h["conditions"]:
            console.print(f"  - {cond}")


@app.command("metrics")
def cluster_metrics(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Cluster-wide CPU/memory + workload counts."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get("/api/cluster/metrics"))


@app.command("deployments")
def cluster_deployments_all(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List every Deployment across the cluster."""
    with _resolve(cluster, api_url) as c:
        rows = c.get("/api/cluster/deployments")
    render_table(
        rows or [],
        [
            ("Namespace", "namespace"),
            ("Name", "name"),
            ("Replicas", "replicas"),
            ("Ready", "readyReplicas"),
            ("Available", "availableReplicas"),
            ("Updated", "updatedReplicas"),
            ("Image", "image"),
        ],
        empty_message="No deployments visible.",
    )


@app.command("pods")
def cluster_pods_all(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List every Pod across the cluster."""
    with _resolve(cluster, api_url) as c:
        rows = c.get("/api/cluster/pods")
    render_table(
        rows or [],
        [
            ("Namespace", "namespace"),
            ("Name", "name"),
            ("Phase", "phase"),
            ("Node", "node"),
            ("PodIP", "podIP"),
            ("Restarts", "restarts"),
        ],
        empty_message="No pods visible.",
    )


# ─── Node sub-app ────────────────────────────────────────────────────────────

node_app = typer.Typer(no_args_is_help=True, help="Cluster nodes.")
app.add_typer(node_app, name="node")


@node_app.command("list")
def node_list(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List every node with conditions, taints, and capacity."""
    with _resolve(cluster, api_url) as c:
        result = c.get("/api/cluster/nodes")
    nodes = result.get("nodes") if isinstance(result, dict) else result
    flat = []
    for n in nodes or []:
        cap = n.get("capacity") or {}
        cond = ",".join(
            cd.get("type", "?") for cd in (n.get("conditions") or []) if cd.get("status") == "True"
        )
        flat.append({
            **n,
            "_cpu": cap.get("cpu"),
            "_mem": cap.get("memory"),
            "_taints": len(n.get("taints") or []),
            "_cond": cond,
        })
    render_table(
        flat,
        [
            ("Name", "name"),
            ("Conditions", "_cond"),
            ("Taints", "_taints"),
            ("CPU", "_cpu"),
            ("Memory", "_mem"),
            ("Created", "creationTimestamp"),
        ],
        empty_message="No nodes.",
    )


@node_app.command("get")
def node_get(
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Full node object (kubectl describe node equivalent)."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/nodes/{name}"))


# ─── Namespace sub-app ───────────────────────────────────────────────────────

ns_app = typer.Typer(no_args_is_help=True, help="Namespaces.")
app.add_typer(ns_app, name="namespace")


@ns_app.command("list")
def ns_list(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List user-visible namespaces."""
    with _resolve(cluster, api_url) as c:
        rows = c.get("/api/cluster/namespaces")
    render_table(
        rows or [],
        [("Name", "name"), ("Status", "status"), ("Created", "createdAt")],
        empty_message="No namespaces visible.",
    )


@ns_app.command("get")
def ns_get(
    namespace: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Namespace detail with its deployments + pods."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}"))


@ns_app.command("delete")
def ns_delete(
    namespace: str = typer.Argument(...),
    yes: bool = _YES_OPT,
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Delete a namespace (and clean up related Enkindler DB rows)."""
    confirm_destructive("delete namespace", namespace, yes_flag=yes)
    with _resolve(cluster, api_url) as c:
        result = c.delete(f"/api/cluster/namespaces/{namespace}")
    console.print(f"[green]Deleted namespace[/green] {namespace}.")
    if isinstance(result, dict):
        for k, v in result.items():
            console.print(f"  {k}: {v}")


# ─── Pod sub-app ─────────────────────────────────────────────────────────────

pod_app = typer.Typer(no_args_is_help=True, help="Pods within a namespace.")
app.add_typer(pod_app, name="pod")


@pod_app.command("get")
def pod_get(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Pod detail (phase, IP, containers, conditions)."""
    with _resolve(cluster, api_url) as c:
        d = c.get(f"/api/cluster/namespaces/{namespace}/pods/{name}")
    console.print(f"[bold]{d.get('name')}[/bold]  ({d.get('namespace')})")
    render_object(d, [
        ("Phase", "phase"),
        ("Node", "node"),
        ("Pod IP", "podIP"),
        ("Host IP", "hostIP"),
        ("Started", "startTime"),
        ("Restarts", "restarts"),
    ])
    if d.get("containers"):
        console.print("Containers:")
        for ct in d["containers"]:
            console.print(f"  - {ct.get('name')}: image={ct.get('image')} ready={ct.get('ready')} restarts={ct.get('restartCount')}")


@pod_app.command("logs")
def pod_logs(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    container: str | None = typer.Option(None, "--container", help="Required for multi-container pods."),
    tail: int | None = typer.Option(None, "--tail", help="Lines from the end of the log."),
    previous: bool = typer.Option(False, "--previous", help="Read logs from the previous (terminated) container instance."),
    follow: bool = typer.Option(False, "--follow", "-f", help="Stream live logs via SSE (Ctrl-C to stop)."),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Pod log snapshot, or stream live with --follow."""
    params: dict[str, Any] = {}
    if container is not None:
        params["container"] = container
    if tail is not None:
        params["tail"] = str(tail)
    if previous:
        params["previous"] = "true"
    base = f"/api/cluster/namespaces/{namespace}/pods/{name}/logs"
    with _resolve(cluster, api_url) as c:
        if follow:
            _follow_sse(c, base + "/stream")
            return
        out = c.get(base, params=params or None)
        text = (out or {}).get("logs") if isinstance(out, dict) else out
        if not text:
            console.print("[dim]No log output.[/dim]")
            return
        console.print(text)
        if isinstance(out, dict) and out.get("truncated"):
            err_console.print("[yellow](output truncated)[/yellow]")


@pod_app.command("events")
def pod_events(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    follow: bool = typer.Option(False, "--follow", "-f", help="Stream live pod events via SSE."),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Pod events snapshot, or stream live with --follow."""
    base = f"/api/cluster/namespaces/{namespace}/pods/{name}/events"
    with _resolve(cluster, api_url) as c:
        if follow:
            _follow_sse(c, base + "/stream")
            return
        rows = c.get(base)
    render_table(
        rows or [],
        [
            ("Type", "type"),
            ("Reason", "reason"),
            ("Count", "count"),
            ("Last", "lastTimestamp"),
            ("Message", "message"),
        ],
        empty_message="No pod events.",
    )


@pod_app.command("exec")
def pod_exec(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    command: list[str] = _EXEC_CMD_ARG,
    container: str | None = typer.Option(None, "--container"),
    timeout_ms: int | None = typer.Option(None, "--timeout-ms"),
    max_bytes: int | None = typer.Option(None, "--max-bytes"),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Run a one-shot command inside a pod container (kubectl exec equivalent)."""
    body: dict[str, Any] = {"command": command}
    if container is not None:
        body["container"] = container
    if timeout_ms is not None:
        body["timeoutMs"] = timeout_ms
    if max_bytes is not None:
        body["maxBytes"] = max_bytes
    with _resolve(cluster, api_url) as c:
        result = c.post(
            f"/api/cluster/namespaces/{namespace}/pods/{name}/exec",
            json=body,
        )
    if not isinstance(result, dict):
        _print_json(result)
        return
    if result.get("stdout"):
        console.print(result["stdout"], end="")
    if result.get("stderr"):
        err_console.print(result["stderr"], end="")
    exit_code = result.get("exitCode")
    if exit_code is not None and exit_code != 0:
        err_console.print(f"[yellow]exit code {exit_code}[/yellow]")
        raise typer.Exit(code=int(exit_code) if isinstance(exit_code, int) else 1)


@pod_app.command("probe")
def pod_probe(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    port: int = typer.Option(..., "--port", help="Container port to probe."),
    path: str | None = typer.Option(None, "--path", help="HTTP path (defaults to /)."),
    method: str | None = typer.Option(None, "--method", help="HTTP method (default GET)."),
    header: list[str] = _PROBE_HEADER_OPT,
    body_str: str | None = typer.Option(None, "--body", help="Request body."),
    timeout_ms: int | None = typer.Option(None, "--timeout-ms"),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """One-shot in-cluster HTTP probe via port-forward."""
    headers: dict[str, str] = {}
    for h in header:
        if ":" not in h:
            err_console.print(f"[red]Bad --header value '{h}'. Expected 'Key: Value'.[/red]")
            raise typer.Exit(code=1)
        k, v = h.split(":", 1)
        headers[k.strip()] = v.strip()
    body: dict[str, Any] = {"port": port}
    if path is not None:
        body["path"] = path
    if method is not None:
        body["method"] = method
    if headers:
        body["headers"] = headers
    if body_str is not None:
        body["body"] = body_str
    if timeout_ms is not None:
        body["timeoutMs"] = timeout_ms
    with _resolve(cluster, api_url) as c:
        _print_json(c.post(
            f"/api/cluster/namespaces/{namespace}/pods/{name}/probe",
            json=body,
        ))


# ─── Deployment sub-app (cluster-level) ─────────────────────────────────────

dep_app = typer.Typer(no_args_is_help=True, help="K8s Deployments addressed by namespace+name.")
app.add_typer(dep_app, name="deployment")


@dep_app.command("get")
def dep_get(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Live K8s Deployment detail with embedded pods."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}/deployments/{name}"))


@dep_app.command("delete")
def dep_delete(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    yes: bool = _YES_OPT,
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Delete a Deployment from the cluster."""
    confirm_destructive("delete deployment", f"{namespace}/{name}", yes_flag=yes)
    with _resolve(cluster, api_url) as c:
        result = c.delete(f"/api/cluster/namespaces/{namespace}/deployments/{name}")
    console.print(f"[green]Deleted deployment[/green] {namespace}/{name}.")
    if isinstance(result, dict):
        _print_json(result)


@dep_app.command("scale")
def dep_scale(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    replicas: int = typer.Option(..., "--replicas", "-r", min=0),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Scale a Deployment by namespace + name."""
    with _resolve(cluster, api_url) as c:
        result = c.post(
            f"/api/cluster/namespaces/{namespace}/deployments/{name}/scale",
            json={"replicas": replicas},
        )
    console.print(f"[green]Scaled[/green] {namespace}/{name} → {replicas} replicas.")
    if isinstance(result, dict) and result.get("status"):
        console.print(f"  Status: {result['status']}")


@dep_app.command("logs")
def dep_logs(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    tail: int | None = typer.Option(None, "--tail", help="Lines per pod (default 100)."),
    previous: bool = typer.Option(False, "--previous", help="Read previous-instance logs."),
    follow: bool = typer.Option(False, "--follow", "-f", help="Stream live aggregated logs via SSE."),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Aggregated logs from all pods of a Deployment, or stream with --follow."""
    params: dict[str, Any] = {}
    if tail is not None:
        params["tail"] = str(tail)
    if previous:
        params["previous"] = "true"
    base = f"/api/cluster/namespaces/{namespace}/deployments/{name}/logs"
    with _resolve(cluster, api_url) as c:
        if follow:
            _follow_sse(c, base + "/stream")
            return
        out = c.get(base, params=params or None)
        text = (out or {}).get("logs") if isinstance(out, dict) else out
        if not text:
            console.print("[dim]No log output.[/dim]")
            return
        console.print(text)
        if isinstance(out, dict) and out.get("truncated"):
            err_console.print("[yellow](output truncated)[/yellow]")


@dep_app.command("events")
def dep_events(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    follow: bool = typer.Option(False, "--follow", "-f", help="Stream live deployment + pod events."),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Combined Deployment + Pod events, or stream with --follow."""
    base = f"/api/cluster/namespaces/{namespace}/deployments/{name}/events"
    with _resolve(cluster, api_url) as c:
        if follow:
            _follow_sse(c, base + "/stream")
            return
        rows = c.get(base)
    render_table(
        rows or [],
        [
            ("Type", "type"),
            ("Reason", "reason"),
            ("Count", "count"),
            ("Last", "lastTimestamp"),
            ("Message", "message"),
        ],
        empty_message="No events.",
    )


@dep_app.command("rollout-status")
def dep_rollout_status(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Computed rollout status (kubectl rollout status equivalent)."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}/deployments/{name}/rollout-status"))


@dep_app.command("replicasets")
def dep_replicasets(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List the deployment's ReplicaSet history."""
    with _resolve(cluster, api_url) as c:
        result = c.get(f"/api/cluster/namespaces/{namespace}/deployments/{name}/replicasets")
    rows = result.get("replicaSets") if isinstance(result, dict) else result
    render_table(
        rows or [],
        [
            ("Name", "name"),
            ("Replicas", "replicas"),
            ("Ready", "readyReplicas"),
            ("Available", "availableReplicas"),
            ("Generation", "generation"),
            ("Created", "creationTimestamp"),
        ],
        empty_message="No replicasets.",
    )


# ─── StatefulSet sub-app ────────────────────────────────────────────────────

ss_app = typer.Typer(no_args_is_help=True, help="StatefulSets.")
app.add_typer(ss_app, name="statefulset")


@ss_app.command("get")
def ss_get(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """StatefulSet detail with pods."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}/statefulsets/{name}"))


@ss_app.command("events")
def ss_events(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Combined StatefulSet + Pod events."""
    with _resolve(cluster, api_url) as c:
        rows = c.get(f"/api/cluster/namespaces/{namespace}/statefulsets/{name}/events")
    render_table(
        rows or [],
        [("Type", "type"), ("Reason", "reason"), ("Count", "count"), ("Last", "lastTimestamp"), ("Message", "message")],
        empty_message="No events.",
    )


@ss_app.command("logs")
def ss_logs(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Aggregated logs from up to 3 StatefulSet pods."""
    with _resolve(cluster, api_url) as c:
        out = c.get(f"/api/cluster/namespaces/{namespace}/statefulsets/{name}/logs")
    text = (out or {}).get("logs") if isinstance(out, dict) else out
    if not text:
        console.print("[dim]No log output.[/dim]")
        return
    console.print(text)
    if isinstance(out, dict) and out.get("truncated"):
        err_console.print("[yellow](output truncated)[/yellow]")


# ─── Service sub-app ─────────────────────────────────────────────────────────

svc_app = typer.Typer(no_args_is_help=True, help="Services + Endpoints.")
app.add_typer(svc_app, name="service")


@svc_app.command("list")
def svc_list(
    namespace: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List Services in a namespace."""
    with _resolve(cluster, api_url) as c:
        result = c.get(f"/api/cluster/namespaces/{namespace}/services")
    rows = result.get("services") if isinstance(result, dict) else result
    render_table(
        rows or [],
        [("Name", "name"), ("Type", "type"), ("ClusterIP", "clusterIP"), ("LB IP", "loadBalancerIP")],
        empty_message="No services.",
    )


@svc_app.command("get")
def svc_get(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Get a Service plus its Endpoints."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}/services/{name}"))


@svc_app.command("endpoints")
def svc_endpoints(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Get raw Endpoints object for a Service name."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}/endpoints/{name}"))


# ─── ConfigMap sub-app ───────────────────────────────────────────────────────

cm_app = typer.Typer(no_args_is_help=True, help="ConfigMaps.")
app.add_typer(cm_app, name="configmap")


@cm_app.command("list")
def cm_list(
    namespace: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List ConfigMaps (keys only) in a namespace."""
    with _resolve(cluster, api_url) as c:
        result = c.get(f"/api/cluster/namespaces/{namespace}/configmaps")
    rows = result.get("configMaps") if isinstance(result, dict) else result
    flat = [
        {**r, "_keys": ", ".join((r.get("keys") or [])[:5]) + ("..." if len(r.get("keys") or []) > 5 else "")}
        for r in (rows or [])
    ]
    render_table(
        flat,
        [("Name", "name"), ("Keys", "_keys"), ("Created", "creationTimestamp")],
        empty_message="No configmaps.",
    )


@cm_app.command("get")
def cm_get(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Read a ConfigMap including data values."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}/configmaps/{name}"))


# ─── Secret sub-app ──────────────────────────────────────────────────────────

sec_app = typer.Typer(no_args_is_help=True, help="Secrets (values are NEVER returned).")
app.add_typer(sec_app, name="secret")


@sec_app.command("list")
def sec_list(
    namespace: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List Secrets (keys only — values are never returned by the API)."""
    with _resolve(cluster, api_url) as c:
        result = c.get(f"/api/cluster/namespaces/{namespace}/secrets")
    rows = result.get("secrets") if isinstance(result, dict) else result
    flat = [
        {**r, "_keys": ", ".join((r.get("keys") or [])[:5]) + ("..." if len(r.get("keys") or []) > 5 else "")}
        for r in (rows or [])
    ]
    render_table(
        flat,
        [("Name", "name"), ("Type", "type"), ("Keys", "_keys"), ("Created", "creationTimestamp")],
        empty_message="No secrets.",
    )


@sec_app.command("get")
def sec_get(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Get a Secret's keys and per-key sizes (no values)."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}/secrets/{name}"))


# ─── Ingress sub-app ─────────────────────────────────────────────────────────

ing_app = typer.Typer(no_args_is_help=True, help="Ingresses.")
app.add_typer(ing_app, name="ingress")


@ing_app.command("list")
def ing_list(
    namespace: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List Ingresses in a namespace."""
    with _resolve(cluster, api_url) as c:
        result = c.get(f"/api/cluster/namespaces/{namespace}/ingresses")
    rows = result.get("ingresses") if isinstance(result, dict) else result
    _print_json(rows)


@ing_app.command("get")
def ing_get(
    namespace: str = typer.Argument(...),
    name: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Full Ingress object."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}/ingresses/{name}"))


# ─── NetworkPolicy sub-app ───────────────────────────────────────────────────

netpol_app = typer.Typer(no_args_is_help=True, help="NetworkPolicies.")
app.add_typer(netpol_app, name="networkpolicy")


@netpol_app.command("list")
def netpol_list(
    namespace: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List NetworkPolicies in a namespace."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}/networkpolicies"))


# ─── Storage sub-apps ────────────────────────────────────────────────────────

pvc_app = typer.Typer(no_args_is_help=True, help="PersistentVolumeClaims.")
app.add_typer(pvc_app, name="pvc")


@pvc_app.command("list")
def pvc_list(
    namespace: str = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List PVCs in a namespace."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get(f"/api/cluster/namespaces/{namespace}/persistentvolumeclaims"))


@app.command("pv")
def pv_list(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List PersistentVolumes (cluster-wide)."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get("/api/cluster/persistentvolumes"))


@app.command("storageclass")
def sc_list(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List StorageClasses (cluster-wide)."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get("/api/cluster/storageclasses"))


# ─── Ingress controller config sub-app ───────────────────────────────────────

cfg_app = typer.Typer(no_args_is_help=True, help="Cluster-level config (ingress-nginx ConfigMap, etc.).")
app.add_typer(cfg_app, name="config")

ingress_cfg_app = typer.Typer(no_args_is_help=True, help="ingress-nginx controller ConfigMap.")
cfg_app.add_typer(ingress_cfg_app, name="ingress")


@ingress_cfg_app.command("get")
def ingress_cfg_get(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Read the ingress-nginx controller ConfigMap."""
    with _resolve(cluster, api_url) as c:
        _print_json(c.get("/api/cluster/config/ingress"))


@ingress_cfg_app.command("update")
def ingress_cfg_update(
    settings_json: str = typer.Argument(..., help="JSON object of settings to merge into the ConfigMap."),
    yes: bool = _YES_OPT,
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Update the ingress-nginx controller ConfigMap (merges the JSON settings)."""
    try:
        settings = json.loads(settings_json)
    except json.JSONDecodeError as e:
        err_console.print(f"[red]Bad JSON: {e}[/red]")
        raise typer.Exit(code=1) from None
    if not isinstance(settings, dict):
        err_console.print("[red]Settings must be a JSON object.[/red]")
        raise typer.Exit(code=1)
    confirm_destructive(
        "update ingress-nginx ConfigMap",
        f"{len(settings)} setting(s): {shlex.quote(json.dumps(settings))[:60]}",
        yes_flag=yes,
    )
    with _resolve(cluster, api_url) as c:
        result = c.patch("/api/cluster/config/ingress", json={"settings": settings})
    console.print("[green]Updated ingress-nginx ConfigMap.[/green]")
    if isinstance(result, dict):
        _print_json(result)
