"""`enkindler whoami` — confirm the current session."""

from __future__ import annotations

import typer
from rich.console import Console

from ..client import Client, ConfigError
from ..config import Config

console = Console()
err_console = Console(stderr=True)


def whoami(
    cluster: str | None = typer.Option(None, "--cluster", "-c"),
    api_url: str | None = typer.Option(None, "--api-url"),
) -> None:
    """Show the current authenticated user."""
    cfg = Config.load()
    try:
        c = cfg.resolve(cluster)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None

    with Client.from_cluster(c, api_url_override=api_url) as client:
        me = client.get("/api/user/me")
        perms = client.get("/api/user/me/permissions")

    console.print(f"[bold]Cluster:[/bold] {c.name}  ({c.instance_name or c.url})")
    console.print(f"[bold]Email:[/bold]   {me['email']}")
    console.print(f"[bold]Name:[/bold]    {me.get('name') or '—'}")
    console.print(f"[bold]User id:[/bold] {me['id']}")
    console.print(f"[bold]Roles:[/bold]   {', '.join(perms.get('roles', [])) or '—'}")
    console.print(f"[bold]Perms:[/bold]   {len(perms.get('permissions', []))} granted")
