"""`enkindler deployment ...` — verbs that map onto the backend's
/api/deployments/* surface.

Hand-rolls HTTP through `Client` rather than going through the generated SDK.
Body shapes here intentionally mirror the OpenAPI spec; if the backend renames
a field, we'll catch it via the test fixtures generated from the spec examples.
"""

from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from .._render import confirm_destructive, render_object, render_table
from ..client import Client, ConfigError
from ..config import Config

app = typer.Typer(no_args_is_help=True)
console = Console()
err_console = Console(stderr=True)

pipeline_app = typer.Typer(no_args_is_help=True, help="Manage a deployment's attached Build Pipeline.")
app.add_typer(pipeline_app, name="pipeline")

# Shared option declarations to keep signatures readable.
_CLUSTER_OPT = typer.Option(None, "--cluster", "-c", help="Cluster name from `enkindler config list`.")
_API_URL_OPT = typer.Option(None, "--api-url", help="Override the cluster's API URL for this command.")
_YES_OPT = typer.Option(False, "--yes", "-y", help="Skip the destructive-action confirmation prompt.")
_ENV_SET_OPT = typer.Option([], "--set", help="Set an env var: KEY=VAL. Repeatable.", metavar="KEY=VAL")
_ENV_UNSET_OPT = typer.Option([], "--unset", help="Remove an env var by key. Repeatable.")
_ENV_SECRET_OPT = typer.Option(False, "--secret", help="Apply --set/--unset to the secrets map instead of env_vars.")


def _resolve(cluster: str | None, api_url: str | None) -> Client:
    cfg = Config.load()
    try:
        c = cfg.resolve(cluster)
    except ConfigError as e:
        err_console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1) from None
    return Client.from_cluster(c, api_url_override=api_url)


# ─── Read verbs ──────────────────────────────────────────────────────────────


@app.command("list")
def list_deployments(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
    mcp: bool = typer.Option(False, "--mcp", help="Only MCP-server deployments."),
) -> None:
    """List Enkindler-managed AKS deployments."""
    params = {"mcp": "true"} if mcp else None
    with _resolve(cluster, api_url) as c:
        rows = c.get("/api/deployments", params=params)

    flat = []
    for d in rows or []:
        flat.append({
            **d,
            "image": f"{d.get('repository', '')}:{d.get('image_tag', '')}",
            "owner": (d.get("creator") or {}).get("name") or (d.get("creator") or {}).get("email"),
        })
    render_table(
        flat,
        [
            ("ID", "id"),
            ("Name", "name"),
            ("Namespace", "namespace"),
            ("Image", "image"),
            ("Replicas", "replicas"),
            ("Status", "status"),
            ("Owner", "owner"),
        ],
        empty_message="No deployments.",
    )


@app.command("get")
def get_deployment(
    deployment_id: int = typer.Argument(..., help="Numeric deployment id."),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Show one deployment by id."""
    with _resolve(cluster, api_url) as c:
        d = c.get(f"/api/deployments/{deployment_id}")
    console.print(f"[bold]{d['name']}[/bold]  ({d['namespace']})")
    render_object(
        d,
        [
            ("Status", "status"),
            ("Image", "repository"),
            ("Tag", "image_tag"),
            ("Replicas", "replicas"),
            ("App URL", "app_url"),
            ("Owner", "creator.email"),
        ],
    )
    if d.get("error_message"):
        console.print(f"  [red]Error:[/red] {d['error_message']}")


@app.command("status")
def deployment_status(
    deployment_id: int = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Live status snapshot of a deployment from the K8s control plane."""
    with _resolve(cluster, api_url) as c:
        s = c.get(f"/api/deployments/{deployment_id}/status")
    console.print(json.dumps(s, indent=2))


@app.command("history")
def deployment_history(
    deployment_id: int = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """List historical revisions you can roll back to."""
    with _resolve(cluster, api_url) as c:
        rows = c.get(f"/api/deployments/{deployment_id}/history")
    render_table(
        rows or [],
        [
            ("ID", "id"),
            ("Tag", "image_tag"),
            ("Replicas", "replicas"),
            ("Status", "status"),
            ("Created", "created_at"),
            ("By", "created_by_email"),
        ],
        empty_message="No history yet.",
    )


@app.command("logs")
def deployment_logs(
    deployment_id: int = typer.Argument(...),
    container: str | None = typer.Option(None, "--container", help="Pick a container if the pod has more than one."),
    tail: int | None = typer.Option(None, "--tail", help="Lines from the end of each pod's log."),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Snapshot of recent logs from each pod backing a deployment (non-streaming)."""
    params: dict[str, Any] = {}
    if container is not None:
        params["container"] = container
    if tail is not None:
        params["tail"] = str(tail)
    with _resolve(cluster, api_url) as c:
        rows = c.get(f"/api/deployments/{deployment_id}/logs", params=params or None)
    if not rows:
        console.print("[dim]No log entries returned.[/dim]")
        return
    for entry in rows:
        pod = entry.get("pod") or "?"
        console.print(f"[bold cyan]── {pod} ──[/bold cyan]")
        console.print(entry.get("logs") or "[dim](empty)[/dim]")


# ─── Write verbs ─────────────────────────────────────────────────────────────


@app.command("scale")
def scale_deployment(
    deployment_id: int = typer.Argument(...),
    replicas: int = typer.Option(..., "--replicas", "-r", min=0, help="Desired replica count."),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Set the deployment's replica count."""
    with _resolve(cluster, api_url) as c:
        result = c.post(f"/api/deployments/{deployment_id}/scale", json={"replicas": replicas})
    console.print(f"[green]Scaled[/green] deployment {deployment_id} → {replicas} replicas.")
    if isinstance(result, dict) and result.get("status"):
        console.print(f"  Status: {result['status']}")


@app.command("env")
def env_update(
    deployment_id: int = typer.Argument(...),
    set_pairs: list[str] = _ENV_SET_OPT,
    unset_keys: list[str] = _ENV_UNSET_OPT,
    secret: bool = _ENV_SECRET_OPT,
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Update env vars (or secrets) on a deployment. Triggers a rolling restart."""
    if not set_pairs and not unset_keys:
        err_console.print("[red]Pass at least one --set KEY=VAL or --unset KEY.[/red]")
        raise typer.Exit(code=1)
    # Validate --set syntax before any HTTP so bad input fails fast.
    parsed_sets: list[tuple[str, str]] = []
    for pair in set_pairs:
        if "=" not in pair:
            err_console.print(f"[red]Bad --set value '{pair}'. Expected KEY=VAL.[/red]")
            raise typer.Exit(code=1)
        k, v = pair.split("=", 1)
        parsed_sets.append((k, v))

    with _resolve(cluster, api_url) as c:
        existing = c.get(f"/api/deployments/{deployment_id}")
        target_field = "secrets" if secret else "env_vars"
        current: dict[str, str] = dict(existing.get(target_field) or {})
        for k, v in parsed_sets:
            current[k] = v
        for k in unset_keys:
            current.pop(k, None)
        c.patch(
            f"/api/deployments/{deployment_id}/env",
            json={target_field: current},
        )
    field_label = "secrets" if secret else "env vars"
    console.print(f"[green]Updated {field_label}[/green] on deployment {deployment_id}. A rolling restart was triggered.")


@app.command("yaml-edit")
def yaml_edit(
    deployment_id: int = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Open the deployment's K8s YAML in $EDITOR; PATCH it back on save."""
    editor = os.environ.get("EDITOR") or os.environ.get("VISUAL") or "vi"
    with _resolve(cluster, api_url) as c:
        d = c.get(f"/api/deployments/{deployment_id}")
        original = d.get("deployment_yaml") or ""

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as tmp:
            tmp.write(original)
            tmp_path = Path(tmp.name)

        try:
            subprocess.run([editor, str(tmp_path)], check=True)
            edited = tmp_path.read_text()
        finally:
            tmp_path.unlink(missing_ok=True)

        if edited == original:
            console.print("[dim]No changes; nothing sent.[/dim]")
            return

        c.patch(
            f"/api/deployments/{deployment_id}/yaml",
            json={"yaml": edited},
        )
    console.print(f"[green]Updated[/green] YAML on deployment {deployment_id}.")


@app.command("force-restart")
def force_restart(
    deployment_id: int = typer.Argument(...),
    yes: bool = _YES_OPT,
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Force a rolling restart of every pod (kubectl rollout restart equivalent)."""
    confirm_destructive("force-restart", f"deployment {deployment_id}", yes_flag=yes)
    with _resolve(cluster, api_url) as c:
        result = c.post(f"/api/deployments/{deployment_id}/force-restart")
    restarted = (result or {}).get("restarted") or []
    failed = (result or {}).get("failed") or []
    console.print(f"[green]Force-restart triggered[/green] on deployment {deployment_id}.")
    if restarted:
        console.print(f"  Restarted: {', '.join(restarted) if isinstance(restarted, list) else restarted}")
    if failed:
        console.print(f"  [yellow]Failed:[/yellow] {failed}")


@app.command("build")
def trigger_build(
    deployment_id: int = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Trigger a CI/CD build via the deployment's attached Build Pipeline.

    The build always runs from the pipeline's attached `watched_branch` —
    use `enkindler deployment pipeline attach <id> --pipeline P --branch B`
    to change it before building.
    """
    with _resolve(cluster, api_url) as c:
        result = c.post(f"/api/deployments/{deployment_id}/build")
    console.print(f"[green]Build queued[/green] for deployment {deployment_id}.")
    if isinstance(result, dict):
        for k in ("run_id", "pipeline_id", "build_status", "watched_branch"):
            if k in result:
                console.print(f"  {k}: {result[k]}")


@app.command("rollback")
def rollback_deployment(
    deployment_id: int = typer.Argument(...),
    history_id: int = typer.Option(..., "--to", help="History entry id from `enkindler deployment history`."),
    yes: bool = _YES_OPT,
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Roll a deployment back to a prior history entry."""
    confirm_destructive(
        f"rollback to history #{history_id}",
        f"deployment {deployment_id}",
        yes_flag=yes,
    )
    with _resolve(cluster, api_url) as c:
        d = c.post(
            f"/api/deployments/{deployment_id}/rollback",
            json={"history_id": history_id},
        )
    console.print(f"[green]Rollback triggered[/green] for deployment {deployment_id} → history #{history_id}.")
    if isinstance(d, dict) and d.get("status"):
        console.print(f"  Status: {d['status']}")


@app.command("delete")
def delete_deployment(
    deployment_id: int = typer.Argument(...),
    yes: bool = _YES_OPT,
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Delete a deployment and its K8s resources."""
    with _resolve(cluster, api_url) as c:
        # Show what's being deleted before prompting.
        try:
            d = c.get(f"/api/deployments/{deployment_id}")
            label = f"deployment {deployment_id} ({d.get('name')} in {d.get('namespace')})"
        except Exception:
            label = f"deployment {deployment_id}"
        confirm_destructive("delete", label, yes_flag=yes)
        c.delete(f"/api/deployments/{deployment_id}")
    console.print(f"[green]Deleted[/green] {label}.")


@app.command("refresh-status")
def refresh_status(
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Re-poll the K8s status of every deployment in this instance."""
    with _resolve(cluster, api_url) as c:
        result = c.post("/api/deployments/refresh-status")
    if isinstance(result, dict):
        console.print(
            f"[green]Refreshed[/green] {result.get('refreshed', 0)} deployments "
            f"({result.get('errored', 0)} errored).",
        )
    else:
        console.print("[green]Refresh requested.[/green]")


@app.command("promote-pending")
def promote_pending(
    deployment_id: int = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Promote the pending image tag (set by a non-CD build) to live."""
    with _resolve(cluster, api_url) as c:
        d = c.post(f"/api/deployments/{deployment_id}/promote-pending")
    console.print(f"[green]Promoted pending image[/green] for deployment {deployment_id}.")
    if isinstance(d, dict) and d.get("image_tag"):
        console.print(f"  New tag: {d['image_tag']}")


# ─── Pipeline sub-app ────────────────────────────────────────────────────────


@pipeline_app.command("attach")
def pipeline_attach(
    deployment_id: int = typer.Argument(..., help="Deployment id."),
    pipeline_id: int = typer.Option(..., "--pipeline", help="Build Pipeline id to attach."),
    branch: str = typer.Option(..., "--branch", help="Branch to watch (required)."),
    cd: bool = typer.Option(False, "--cd", help="Enable continuous deployment from this pipeline."),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Wire a Build Pipeline to a deployment."""
    body: dict[str, Any] = {
        "pipeline_id": pipeline_id,
        "watched_branch": branch,
        "continuous_deployment": cd,
    }
    with _resolve(cluster, api_url) as c:
        c.post(f"/api/deployments/{deployment_id}/attach-pipeline", json=body)
    console.print(
        f"[green]Attached[/green] pipeline {pipeline_id} to deployment {deployment_id} "
        f"(branch={branch}, cd={'on' if cd else 'off'}).",
    )


@pipeline_app.command("detach")
def pipeline_detach(
    deployment_id: int = typer.Argument(...),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Remove the attached Build Pipeline from a deployment."""
    with _resolve(cluster, api_url) as c:
        c.delete(f"/api/deployments/{deployment_id}/attach-pipeline")
    console.print(f"[green]Detached[/green] pipeline from deployment {deployment_id}.")


@pipeline_app.command("cd")
def pipeline_cd(
    deployment_id: int = typer.Argument(...),
    enable: bool = typer.Option(False, "--enable", help="Turn continuous deployment on."),
    disable: bool = typer.Option(False, "--disable", help="Turn continuous deployment off."),
    cluster: str | None = _CLUSTER_OPT,
    api_url: str | None = _API_URL_OPT,
) -> None:
    """Toggle continuous deployment on the attached pipeline."""
    if enable == disable:
        err_console.print("[red]Pass exactly one of --enable or --disable.[/red]")
        raise typer.Exit(code=1)
    with _resolve(cluster, api_url) as c:
        c.patch(
            f"/api/deployments/{deployment_id}/continuous-deployment",
            json={"continuous_deployment": bool(enable)},
        )
    state = "enabled" if enable else "disabled"
    console.print(f"[green]Continuous deployment {state}[/green] on deployment {deployment_id}.")
