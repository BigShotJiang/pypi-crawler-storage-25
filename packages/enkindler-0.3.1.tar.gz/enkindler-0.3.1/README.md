# enkindler CLI

Command-line interface for the [Enkindler](https://enkindler.enkindl.com) AI operations dashboard. Manages AKS deployments, Helm platforms, integrations, and cluster resources from your terminal.

Patterned after `az` and `databricks` — designed to be ergonomic for both humans and AI agents.

## Install

```bash
pip install enkindler
```

Works on macOS, Linux, and Windows (Python 3.10+).

## Quick start

```bash
# Sign in via Microsoft device-code flow (opens browser)
enkindler login

# Verify the session
enkindler whoami

# List your deployments
enkindler deployment list
```

## Configuration

Config and the cached JWT live at:

| OS | Path |
|---|---|
| macOS | `~/Library/Application Support/enkindler/config.toml` |
| Linux | `~/.config/enkindler/config.toml` |
| Windows | `%APPDATA%\enkindler\config.toml` |

Override the backend URL with `--api-url https://...` on any command, or set `ENKINDLER_API_URL` in the environment.

## Architecture

- Backend exposes an OpenAPI spec at `/api/openapi.json` (the contract).
- This CLI consumes that spec to drive command behaviour.
- Auth uses the Azure AD device-code flow — no browser required on the same machine, no token-pasting.

## Development

```bash
python -m venv .venv && source .venv/bin/activate  # or `.venv\Scripts\activate` on Windows
pip install -e '.[dev]'
pytest
ruff check .
```

## License

MIT
