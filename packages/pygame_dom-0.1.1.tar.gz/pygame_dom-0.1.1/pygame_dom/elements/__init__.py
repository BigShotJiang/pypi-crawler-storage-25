from pygame_dom.elements.text_elements import H1, H2, H3, H4, H5, H6, P, DIV, BUTTON

__all__ = ["H1", "H2", "H3", "H4", "H5", "H6", "P", "DIV", "BUTTON"]