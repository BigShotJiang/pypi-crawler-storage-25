"""Track database management — stores feature vectors and metadata."""

import json
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Final

import numpy as np

SCHEMA_VERSION: Final[int] = 2

_CREATE_SQL = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS tracks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    path TEXT NOT NULL,
    title TEXT NOT NULL,
    artist TEXT NOT NULL DEFAULT 'Unknown',
    genre TEXT NOT NULL DEFAULT 'Unknown',
    bpm REAL NOT NULL,
    estimated_key TEXT NOT NULL,
    lufs REAL NOT NULL,
    dynamic_range REAL NOT NULL,
    duration_sec REAL NOT NULL,
    brightness REAL NOT NULL,
    vector BLOB NOT NULL,
    clap_vector BLOB,
    source TEXT NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_tracks_path_source ON tracks(path, source);
CREATE INDEX IF NOT EXISTS idx_tracks_source ON tracks(source);
"""

_MIGRATE_V2_SQL = """
ALTER TABLE tracks ADD COLUMN clap_vector BLOB;
"""


@dataclass(frozen=True)
class TrackRecord:
    """A track stored in the database."""

    id: int
    path: str
    title: str
    artist: str
    genre: str
    bpm: float
    estimated_key: str
    lufs: float
    dynamic_range: float
    duration_sec: float
    brightness: float
    vector: np.ndarray
    source: str
    clap_vector: np.ndarray | None = None


class TrackDatabase:
    """SQLite-backed track database with numpy vectors."""

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path))
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._init_schema()

    def _init_schema(self) -> None:
        cursor = self._conn.cursor()
        cursor.executescript(_CREATE_SQL)

        # Check/set schema version
        cursor.execute("SELECT COUNT(*) FROM schema_version")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO schema_version (version) VALUES (?)", (SCHEMA_VERSION,))
        else:
            cursor.execute("SELECT version FROM schema_version LIMIT 1")
            current = cursor.fetchone()[0]
            if current < 2:
                # Migrate v1 -> v2: add clap_vector column
                try:
                    cursor.executescript(_MIGRATE_V2_SQL)
                except Exception:
                    pass  # column may already exist
                cursor.execute("UPDATE schema_version SET version = ?", (SCHEMA_VERSION,))

        self._conn.commit()

    def add_track(
        self,
        path: str,
        title: str,
        artist: str,
        genre: str,
        bpm: float,
        estimated_key: str,
        lufs: float,
        dynamic_range: float,
        duration_sec: float,
        brightness: float,
        vector: np.ndarray,
        source: str = "user",
        clap_vector: np.ndarray | None = None,
    ) -> int:
        """Add a track to the database. Returns the track ID."""
        from refmatch.features import VECTOR_DIM

        if vector.shape != (VECTOR_DIM,):
            raise ValueError(
                f"Vector dimension mismatch: got {vector.shape}, "
                f"expected ({VECTOR_DIM},)"
            )
        vector_bytes = vector.astype(np.float32).tobytes()
        clap_bytes = clap_vector.astype(np.float32).tobytes() if clap_vector is not None else None

        cursor = self._conn.cursor()
        cursor.execute(
            """INSERT INTO tracks
            (path, title, artist, genre, bpm, estimated_key, lufs,
             dynamic_range, duration_sec, brightness, vector, clap_vector, source)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                path,
                title,
                artist,
                genre,
                bpm,
                estimated_key,
                lufs,
                dynamic_range,
                duration_sec,
                brightness,
                vector_bytes,
                clap_bytes,
                source,
            ),
        )
        self._conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    def get_all_tracks(self, source: str | None = None) -> list[TrackRecord]:
        """Get all tracks, optionally filtered by source."""
        cursor = self._conn.cursor()
        if source is not None:
            cursor.execute("SELECT * FROM tracks WHERE source = ? ORDER BY id", (source,))
        else:
            cursor.execute("SELECT * FROM tracks ORDER BY id")
        return [self._row_to_record(row) for row in cursor.fetchall()]

    def get_track_count(self, source: str | None = None) -> int:
        """Get the number of tracks in the database."""
        cursor = self._conn.cursor()
        if source is not None:
            cursor.execute("SELECT COUNT(*) FROM tracks WHERE source = ?", (source,))
        else:
            cursor.execute("SELECT COUNT(*) FROM tracks")
        return cursor.fetchone()[0]

    def remove_track(self, track_id: int) -> bool:
        """Remove a track by ID. Returns True if a track was removed."""
        cursor = self._conn.cursor()
        cursor.execute("DELETE FROM tracks WHERE id = ?", (track_id,))
        self._conn.commit()
        return cursor.rowcount > 0

    def has_path(self, path: str) -> bool:
        """Check if a track with the given path already exists."""
        cursor = self._conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM tracks WHERE path = ?", (path,))
        return cursor.fetchone()[0] > 0

    def get_vectors_and_ids(self, source: str | None = None) -> tuple[np.ndarray, list[int]]:
        """Get all DSP vectors as a matrix and their corresponding IDs."""
        tracks = self.get_all_tracks(source)
        if not tracks:
            return np.empty((0, 0), dtype=np.float32), []
        vectors = np.stack([t.vector for t in tracks])
        ids = [t.id for t in tracks]
        return vectors, ids

    def get_clap_vectors_and_ids(
        self, source: str | None = None,
    ) -> tuple[np.ndarray, list[int]]:
        """Get all CLAP vectors as a matrix and their corresponding IDs.

        Only returns tracks that have CLAP embeddings.
        """
        tracks = self.get_all_tracks(source)
        with_clap = [t for t in tracks if t.clap_vector is not None]
        if not with_clap:
            return np.empty((0, 0), dtype=np.float32), []
        vectors = np.stack([t.clap_vector for t in with_clap])
        ids = [t.id for t in with_clap]
        return vectors, ids

    def get_track_by_id(self, track_id: int) -> TrackRecord | None:
        """Get a single track by ID."""
        cursor = self._conn.cursor()
        cursor.execute("SELECT * FROM tracks WHERE id = ?", (track_id,))
        row = cursor.fetchone()
        if row is None:
            return None
        return self._row_to_record(row)

    def export_seed(self, output_path: str | Path) -> None:
        """Export all seed tracks as a JSON + numpy bundle."""
        tracks = self.get_all_tracks(source="seed")
        output = Path(output_path)
        output.mkdir(parents=True, exist_ok=True)

        metadata = []
        vectors = []
        for t in tracks:
            metadata.append({
                "id": t.id,
                "title": t.title,
                "artist": t.artist,
                "genre": t.genre,
                "bpm": t.bpm,
                "key": t.estimated_key,
                "lufs": t.lufs,
                "dynamic_range": t.dynamic_range,
                "duration_sec": t.duration_sec,
                "brightness": t.brightness,
            })
            vectors.append(t.vector)

        with open(output / "metadata.json", "w") as f:
            json.dump(metadata, f, indent=2)

        if vectors:
            np.save(output / "vectors.npy", np.stack(vectors))

    def import_seed(self, seed_path: str | Path) -> int:
        """Import seed tracks from a JSON + numpy bundle. Returns count imported.

        Import is transactional: either all tracks are imported or none.
        Uses allow_pickle=False for safe numpy loading.
        """
        seed = Path(seed_path)
        meta_file = seed / "metadata.json"
        vec_file = seed / "vectors.npy"

        if not meta_file.exists() or not vec_file.exists():
            raise FileNotFoundError(f"Seed database not found at {seed}")

        with open(meta_file) as f:
            metadata = json.load(f)

        # Safe load: no pickle allowed (numpy arrays only)
        vectors = np.load(vec_file, allow_pickle=False)

        if len(metadata) != len(vectors):
            raise ValueError(
                f"Metadata/vector count mismatch: {len(metadata)} vs {len(vectors)}"
            )

        cursor = self._conn.cursor()
        try:
            for i, meta in enumerate(metadata):
                vec = vectors[i].astype(np.float32)
                cursor.execute(
                    """INSERT OR IGNORE INTO tracks
                    (path, title, artist, genre, bpm, estimated_key, lufs,
                     dynamic_range, duration_sec, brightness, vector, source)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        f"seed://{meta['artist']}/{meta['title']}",
                        meta["title"],
                        meta["artist"],
                        meta.get("genre", "Unknown"),
                        meta["bpm"],
                        meta["key"],
                        meta["lufs"],
                        meta["dynamic_range"],
                        meta["duration_sec"],
                        meta["brightness"],
                        vec.tobytes(),
                        "seed",
                    ),
                )
            self._conn.commit()
        except Exception:
            self._conn.rollback()
            raise

        return len(metadata)

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()

    def _get_column_names(self) -> list[str]:
        """Get column names from tracks table."""
        cursor = self._conn.cursor()
        cursor.execute("PRAGMA table_info(tracks)")
        return [row[1] for row in cursor.fetchall()]

    def _row_to_record(self, row: tuple) -> TrackRecord:
        """Convert a database row to TrackRecord, handling both v1 and v2 schemas."""
        cols = self._get_column_names()
        data = dict(zip(cols, row))

        vector = np.frombuffer(data["vector"], dtype=np.float32).copy()

        clap_raw = data.get("clap_vector")
        clap_vector = (
            np.frombuffer(clap_raw, dtype=np.float32).copy()
            if clap_raw is not None and isinstance(clap_raw, (bytes, memoryview))
            else None
        )

        return TrackRecord(
            id=data["id"],
            path=data["path"],
            title=data["title"],
            artist=data["artist"],
            genre=data["genre"],
            bpm=data["bpm"],
            estimated_key=data["estimated_key"],
            lufs=data["lufs"],
            dynamic_range=data["dynamic_range"],
            duration_sec=data["duration_sec"],
            brightness=data["brightness"],
            vector=vector,
            source=data["source"],
            clap_vector=clap_vector,
        )
