"""Rich terminal output formatting."""

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from refmatch.features import AudioFeatures
from refmatch.matcher import MatchResult

console = Console()


def _bar(value: float, max_val: float, width: int = 10) -> str:
    """Create a simple bar chart character."""
    filled = int((value / max_val) * width) if max_val > 0 else 0
    filled = max(0, min(width, filled))
    return "\u2588" * filled + "\u2591" * (width - filled)


def _brightness_label(brightness: float) -> str:
    """Convert brightness score to human label."""
    if brightness < 0.3:
        return "dark/warm"
    if brightness < 0.5:
        return "warm"
    if brightness < 0.7:
        return "neutral"
    if brightness < 0.85:
        return "bright"
    return "very bright"


def display_analysis(features: AudioFeatures, filename: str) -> None:
    """Display track analysis dashboard."""
    # Spectral balance estimation from the feature vector
    # Using spectral contrast bands as proxy for frequency balance
    vec = features.vector
    # Rough estimation: low (bands 0-2), mid (bands 3-4), high (bands 5-6)
    low = float(abs(vec[17] + vec[18] + vec[19]) / 3) * 100
    mid = float(abs(vec[20] + vec[21]) / 2) * 100
    high = float(abs(vec[22] + vec[23]) / 2) * 100

    # Normalize to percentages
    total = low + mid + high
    if total > 0:
        low = (low / total) * 100
        mid = (mid / total) * 100
        high = (high / total) * 100

    lines = [
        f"  [bold]BPM:[/bold]             {features.bpm:.0f}",
        f"  [bold]Key:[/bold]             {features.estimated_key} (estimated)",
        f"  [bold]Loudness:[/bold]        {features.lufs:.1f} LUFS",
        f"  [bold]Dynamic Range:[/bold]   {features.dynamic_range:.1f} dB",
        f"  [bold]Brightness:[/bold]      {features.brightness:.2f}"
        f" ({_brightness_label(features.brightness)})",
        f"  [bold]Duration:[/bold]        {features.duration_sec:.1f}s",
        "",
        "  [bold]Spectral Balance:[/bold]",
        f"    Low  (20-200Hz):   {_bar(low, 100)}  {low:.0f}%",
        f"    Mid  (200-2kHz):   {_bar(mid, 100)}  {mid:.0f}%",
        f"    High (2k-20kHz):   {_bar(high, 100)}  {high:.0f}%",
    ]

    panel = Panel(
        "\n".join(lines),
        title=f"[bold cyan]Track Analysis: {filename}[/bold cyan]",
        border_style="cyan",
    )
    console.print(panel)


def display_matches(
    matches: list[MatchResult], filename: str, dimension: str | None = None,
) -> None:
    """Display match results as a table."""
    if not matches:
        console.print(
            "[yellow]No matches found. "
            "Add tracks to your library or check the seed database.[/yellow]"
        )
        return

    title = f"Top {len(matches)} Reference Matches for: {filename}"
    if dimension:
        title += f" [dim](dimension: {dimension})[/dim]"

    table = Table(title=title, show_lines=True, border_style="cyan")
    table.add_column("#", style="bold", width=3, justify="right")
    table.add_column("Track", style="white", min_width=25)
    table.add_column("Artist", style="dim", min_width=15)
    table.add_column("Match", style="bold green", width=7, justify="right")
    table.add_column("Why", style="yellow", min_width=40)

    has_clap = any(m.clap_score is not None for m in matches)
    if has_clap:
        table.add_column("DSP", style="dim", width=5, justify="right")
        table.add_column("CLAP", style="magenta", width=5, justify="right")

    for i, match in enumerate(matches, 1):
        pct = f"{match.similarity * 100:.0f}%"
        why = "; ".join(match.explanation[:2])  # Show top 2 reasons
        row = [str(i), match.track.title, match.track.artist, pct, why]
        if has_clap:
            dsp_pct = f"{match.dsp_score * 100:.0f}%" if match.dsp_score is not None else "-"
            clap_pct = f"{match.clap_score * 100:.0f}%" if match.clap_score is not None else "-"
            row.extend([dsp_pct, clap_pct])
        table.add_row(*row)

    console.print(table)

    if dimension is None:
        console.print(
            "\n[dim]Tip: use --dimension low-end|loudness|brightness|rhythm|harmony "
            "for targeted matching[/dim]"
        )


def display_library_stats(user_count: int, seed_count: int) -> None:
    """Display library statistics."""
    table = Table(title="Library", border_style="cyan")
    table.add_column("Source", style="bold")
    table.add_column("Tracks", justify="right")

    table.add_row("Your tracks", str(user_count))
    table.add_row("Seed database", str(seed_count))
    table.add_row("[bold]Total[/bold]", f"[bold]{user_count + seed_count}[/bold]")

    console.print(table)
