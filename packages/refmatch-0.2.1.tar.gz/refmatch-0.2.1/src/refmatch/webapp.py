"""RefMatch Web UI — local browser-based interface for reference track matching."""

from __future__ import annotations

import os
import tempfile
import urllib.parse
import webbrowser
from pathlib import Path
from threading import Timer

from flask import Flask, jsonify, request

from refmatch.database import TrackDatabase
from refmatch.features import DIMENSIONS, AudioFeatures, extract_features
from refmatch.matcher import find_matches

# Try CLAP
try:
    from refmatch import embeddings as clap

    CLAP_AVAILABLE = clap.is_available()
except Exception:
    CLAP_AVAILABLE = False

_DATA_DIR = Path.home() / ".refmatch"
_DB_PATH = _DATA_DIR / "library.db"
_SEED_DIR = Path(__file__).parent / "data" / "seed"

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024  # 200MB max upload

_seed_loaded = False


def _get_db() -> TrackDatabase:
    return TrackDatabase(_DB_PATH)


def _ensure_seed(db: TrackDatabase) -> None:
    global _seed_loaded
    if _seed_loaded:
        return
    if db.get_track_count(source="seed") > 0:
        _seed_loaded = True
        return
    if _SEED_DIR.exists() and (_SEED_DIR / "metadata.json").exists():
        try:
            db.import_seed(_SEED_DIR)
            _seed_loaded = True
        except Exception:
            pass


def _preload_seed() -> None:
    """Pre-load seed database at startup so first request is fast."""
    try:
        db = _get_db()
        _ensure_seed(db)
        db.close()
    except Exception:
        pass


def _search_urls(title: str, artist: str) -> dict[str, str]:
    q = urllib.parse.quote_plus(f"{artist} {title}")
    # Use an HTTPS Spotify search URL; pywebview reliably opens this externally
    # on macOS, and Spotify can intercept it into the desktop app.
    spotify_q = urllib.parse.quote(f"artist:{artist} track:{title}", safe="")
    return {
        "spotify": f"https://open.spotify.com/search/{spotify_q}",
        "youtube": f"https://www.youtube.com/results?search_query={q}",
    }


def _features_to_dict(f: AudioFeatures) -> dict:
    return {
        "bpm": round(f.bpm, 1),
        "key": f.estimated_key,
        "lufs": round(f.lufs, 1),
        "dynamic_range": round(f.dynamic_range, 1),
        "brightness": round(f.brightness, 3),
        "duration_sec": round(f.duration_sec, 1),
    }


def _escape_html(text: str) -> str:
    """Escape HTML special characters to prevent XSS."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#x27;")
    )


@app.route("/")
def index():
    return _HTML


@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]
    if not file.filename:
        return jsonify({"error": "Empty filename"}), 400

    suffix = Path(file.filename).suffix.lower()
    if suffix not in {".wav", ".mp3", ".flac", ".ogg", ".aiff", ".aif", ".m4a"}:
        return jsonify({"error": f"Unsupported format: {suffix}"}), 400

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        file.save(tmp.name)
        tmp_path = tmp.name

    try:
        features = extract_features(tmp_path)
        analysis = _features_to_dict(features)

        # Get matches
        db = _get_db()
        _ensure_seed(db)

        clap_vector = None
        if CLAP_AVAILABLE:
            try:
                clap_emb = clap.extract_clap_embedding(tmp_path)
                clap_vector = clap_emb.vector
            except Exception:
                pass

        dimension = request.form.get("dimension") or None
        results = find_matches(
            features, db, top_k=10, dimension=dimension, clap_vector=clap_vector,
        )
        db.close()

        matches = []
        for r in results:
            matches.append({
                "title": _escape_html(r.track.title),
                "artist": _escape_html(r.track.artist),
                "genre": _escape_html(r.track.genre),
                "similarity": round(r.similarity * 100, 1),
                "dsp_score": round(r.dsp_score * 100, 1) if r.dsp_score else None,
                "clap_score": round(r.clap_score * 100, 1) if r.clap_score else None,
                "bpm": round(r.track.bpm, 1),
                "key": _escape_html(r.track.estimated_key),
                "lufs": round(r.track.lufs, 1),
                "explanation": [_escape_html(e) for e in r.explanation],
                **_search_urls(r.track.title, r.track.artist),
            })

        return jsonify({
            "analysis": analysis,
            "matches": matches,
            "clap_enabled": clap_vector is not None,
            "filename": _escape_html(file.filename),
        })

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Analysis failed: {e}"}), 500
    finally:
        os.unlink(tmp_path)


@app.route("/api/library/add", methods=["POST"])
def api_library_add():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]
    suffix = Path(file.filename).suffix.lower()

    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        file.save(tmp.name)
        tmp_path = tmp.name

    try:
        features = extract_features(tmp_path)
        title = Path(file.filename).stem.replace("_", " ").replace("-", " ").title()
        artist = request.form.get("artist", "Unknown")
        genre = request.form.get("genre", "Unknown")

        clap_vector = None
        if CLAP_AVAILABLE:
            try:
                clap_emb = clap.extract_clap_embedding(tmp_path)
                clap_vector = clap_emb.vector
            except Exception:
                pass

        db = _get_db()
        db.add_track(
            path=tmp_path,
            title=title,
            artist=artist,
            genre=genre,
            bpm=features.bpm,
            estimated_key=features.estimated_key,
            lufs=features.lufs,
            dynamic_range=features.dynamic_range,
            duration_sec=features.duration_sec,
            brightness=features.brightness,
            vector=features.vector,
            source="user",
            clap_vector=clap_vector,
        )
        db.close()

        return jsonify({"success": True, "title": title})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        os.unlink(tmp_path)


@app.route("/api/stats")
def api_stats():
    db = _get_db()
    _ensure_seed(db)
    user = db.get_track_count(source="user")
    seed = db.get_track_count(source="seed")
    db.close()
    return jsonify({
        "user_tracks": user,
        "seed_tracks": seed,
        "total": user + seed,
        "clap_available": CLAP_AVAILABLE,
        "dimensions": list(DIMENSIONS.keys()),
    })


# NOTE: The HTML template uses DOM-safe rendering via textContent for all
# user-controlled data. Server-side _escape_html provides defense-in-depth.
_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>RefMatch</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0a0a0f;--surface:#12121a;--surface2:#1a1a28;--border:#1e1e2e;--text:#e0e0e8;--dim:#6b6b80;--accent:#00d4ff;--accent2:#8b5cf6;--green:#22c55e;--red:#ef4444;--gradient:linear-gradient(135deg,#00d4ff,#8b5cf6)}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:var(--bg);color:var(--text);min-height:100vh}
a{color:var(--accent);text-decoration:none}
a:hover{text-decoration:underline}

.app{max-width:900px;margin:0 auto;padding:24px}
header{text-align:center;padding:40px 0 32px}
header h1{font-size:1.75rem;font-weight:800;background:var(--gradient);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
header p{color:var(--dim);margin-top:8px;font-size:.9rem}

.dropzone{border:2px dashed var(--border);border-radius:16px;padding:48px 24px;text-align:center;cursor:pointer;transition:all .3s;background:var(--surface);margin-bottom:24px;position:relative}
.dropzone:hover,.dropzone.drag{border-color:var(--accent);background:var(--surface2)}
.dropzone h2{font-size:1.1rem;margin-bottom:8px}
.dropzone p{color:var(--dim);font-size:.85rem}
.dropzone input{position:absolute;inset:0;opacity:0;cursor:pointer}

.controls{display:flex;gap:12px;margin-bottom:24px;flex-wrap:wrap;align-items:center}
.controls select{background:var(--surface);border:1px solid var(--border);color:var(--text);padding:8px 16px;border-radius:8px;font-size:.85rem}
.controls .status{margin-left:auto;color:var(--dim);font-size:.8rem}
.badge{display:inline-block;padding:2px 8px;border-radius:4px;font-size:.7rem;font-weight:600}
.badge-green{background:#22c55e22;color:var(--green)}
.badge-dim{background:#6b6b8022;color:var(--dim)}

.loading{display:none;text-align:center;padding:32px}
.loading.active{display:block}
.spinner{display:inline-block;width:32px;height:32px;border:3px solid var(--border);border-top:3px solid var(--accent);border-radius:50%;animation:spin 1s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

.analysis{display:none;background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:24px;margin-bottom:24px}
.analysis.show{display:block}
.analysis h3{margin-bottom:16px;font-size:1rem}
.analysis-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px}
.stat{background:var(--surface2);border-radius:8px;padding:12px;text-align:center}
.stat .label{font-size:.7rem;color:var(--dim);text-transform:uppercase;letter-spacing:.05em}
.stat .value{font-size:1.25rem;font-weight:700;margin-top:4px}

.results{display:none}
.results.show{display:block}
.results h3{margin-bottom:16px;font-size:1rem}
.match{background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:16px 20px;margin-bottom:12px;display:grid;grid-template-columns:auto 1fr auto;gap:16px;align-items:center;transition:border-color .2s}
.match:hover{border-color:var(--accent)}
.match-rank{font-size:1.5rem;font-weight:800;color:var(--accent);min-width:32px;text-align:center}
.match-info h4{font-size:.95rem;margin-bottom:4px}
.match-info .meta{font-size:.8rem;color:var(--dim)}
.match-info .why{font-size:.8rem;color:var(--accent2);margin-top:6px}
.match-score{text-align:right}
.match-score .pct{font-size:1.5rem;font-weight:800}
.match-score .sub{font-size:.7rem;color:var(--dim);margin-top:2px}
.match-links{margin-top:8px;display:flex;gap:8px}
.match-links a{font-size:.75rem;padding:4px 10px;border-radius:4px;background:var(--surface2);border:1px solid var(--border);color:var(--text);transition:all .2s}
.match-links a:hover{border-color:var(--accent);text-decoration:none}
</style>
</head>
<body>
<div class="app">
<header>
  <h1>RefMatch</h1>
  <p>Drop your track. Get reference matches.</p>
</header>

<div class="dropzone" id="dropzone">
  <h2>Drop audio file here</h2>
  <p>WAV, MP3, FLAC, OGG, AIFF, M4A</p>
  <input type="file" id="fileInput" accept=".wav,.mp3,.flac,.ogg,.aiff,.aif,.m4a">
</div>

<div class="controls">
  <select id="dimension">
    <option value="">All dimensions</option>
    <option value="low-end">Low-end</option>
    <option value="loudness">Loudness</option>
    <option value="brightness">Brightness</option>
    <option value="rhythm">Rhythm</option>
    <option value="harmony">Harmony</option>
  </select>
  <span class="status" id="stats"></span>
</div>

<div class="loading" id="loading">
  <div class="spinner"></div>
  <p style="margin-top:12px;color:var(--dim)">Analyzing audio...</p>
</div>

<div class="analysis" id="analysis">
  <h3>Analysis: <span id="filename"></span></h3>
  <div class="analysis-grid" id="analysisGrid"></div>
</div>

<div class="results" id="results">
  <h3>Top Matches</h3>
  <div id="matchList"></div>
</div>
</div>

<script>
const dropzone=document.getElementById('dropzone'),
  fileInput=document.getElementById('fileInput'),
  loading=document.getElementById('loading'),
  analysis=document.getElementById('analysis'),
  results=document.getElementById('results');

// Open URL in system browser — works in both pywebview and regular browser
function openExternal(url){
  // Try pywebview API first
  if(window.pywebview&&window.pywebview.api&&window.pywebview.api.open_url){
    window.pywebview.api.open_url(url);
  } else {
    // Regular browser: open in new tab
    window.open(url,'_blank','noopener,noreferrer');
  }
}

fetch('/api/stats').then(r=>r.json()).then(d=>{
  const s=document.getElementById('stats');
  s.textContent=d.total+' tracks ';
  const b=document.createElement('span');
  b.className='badge '+(d.clap_available?'badge-green':'badge-dim');
  b.textContent=d.clap_available?'CLAP':'DSP only';
  s.appendChild(b);
});

dropzone.addEventListener('dragover',e=>{e.preventDefault();dropzone.classList.add('drag')});
dropzone.addEventListener('dragleave',()=>dropzone.classList.remove('drag'));
dropzone.addEventListener('drop',e=>{e.preventDefault();dropzone.classList.remove('drag');if(e.dataTransfer.files.length)analyze(e.dataTransfer.files[0])});
fileInput.addEventListener('change',e=>{if(e.target.files.length)analyze(e.target.files[0])});

function createStat(label,value){
  const d=document.createElement('div');d.className='stat';
  const l=document.createElement('div');l.className='label';l.textContent=label;
  const v=document.createElement('div');v.className='value';v.textContent=value;
  d.appendChild(l);d.appendChild(v);return d;
}

function createMatch(m,i){
  const card=document.createElement('div');card.className='match';

  const rank=document.createElement('div');rank.className='match-rank';rank.textContent=i+1;

  const info=document.createElement('div');info.className='match-info';
  const h4=document.createElement('h4');h4.textContent=m.title;
  const meta=document.createElement('div');meta.className='meta';
  meta.textContent=[m.artist,m.genre,m.bpm+' BPM',m.key,m.lufs+' LUFS'].join(' \u00b7 ');
  const why=document.createElement('div');why.className='why';
  why.textContent=m.explanation.slice(0,2).join('; ');
  const links=document.createElement('div');links.className='match-links';
  const sp=document.createElement('a');sp.href='#';
  sp.textContent='Spotify';
  sp.addEventListener('click',function(e){e.preventDefault();openExternal(m.spotify)});
  const yt=document.createElement('a');yt.href='#';
  yt.textContent='YouTube';
  yt.addEventListener('click',function(e){e.preventDefault();openExternal(m.youtube)});
  links.appendChild(sp);links.appendChild(yt);
  info.appendChild(h4);info.appendChild(meta);info.appendChild(why);info.appendChild(links);

  const score=document.createElement('div');score.className='match-score';
  const pct=document.createElement('div');pct.className='pct';pct.textContent=m.similarity+'%';
  const sub=document.createElement('div');sub.className='sub';
  sub.textContent=m.clap_score?'DSP '+m.dsp_score+'% / CLAP '+m.clap_score+'%':'DSP match';
  score.appendChild(pct);score.appendChild(sub);

  card.appendChild(rank);card.appendChild(info);card.appendChild(score);
  return card;
}

function showError(msg){
  loading.classList.remove('active');
  const el=document.getElementById('dropzone');
  const old=el.querySelector('.error-msg');
  if(old)old.remove();
  const e=document.createElement('p');
  e.className='error-msg';
  e.style.cssText='color:#ef4444;margin-top:12px;font-size:.9rem';
  e.textContent=msg;
  el.appendChild(e);
  setTimeout(()=>e.remove(),8000);
}

function analyze(file){
  loading.classList.add('active');
  analysis.classList.remove('show');
  results.classList.remove('show');
  const old=document.querySelector('.error-msg');
  if(old)old.remove();

  // Update loading text with filename
  const loadText=loading.querySelector('p');
  if(loadText)loadText.textContent='Analyzing '+file.name+' ...';

  const fd=new FormData();
  fd.append('file',file);
  const dim=document.getElementById('dimension').value;
  if(dim)fd.append('dimension',dim);

  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(),120000);

  fetch('/api/analyze',{method:'POST',body:fd,signal:controller.signal})
  .then(r=>{clearTimeout(timeout);return r.json()})
  .then(d=>{
    loading.classList.remove('active');
    if(d.error){showError(d.error);return}

    document.getElementById('filename').textContent=d.filename;
    const grid=document.getElementById('analysisGrid');
    grid.replaceChildren();
    const a=d.analysis;
    grid.appendChild(createStat('BPM',a.bpm));
    grid.appendChild(createStat('Key',a.key));
    grid.appendChild(createStat('Loudness',a.lufs+' LUFS'));
    grid.appendChild(createStat('Dynamic Range',a.dynamic_range+' dB'));
    grid.appendChild(createStat('Brightness',a.brightness));
    grid.appendChild(createStat('Duration',Math.round(a.duration_sec)+'s'));
    analysis.classList.add('show');

    const list=document.getElementById('matchList');
    list.replaceChildren();
    d.matches.forEach((m,i)=>list.appendChild(createMatch(m,i)));
    results.classList.add('show');
  })
  .catch(e=>{
    clearTimeout(timeout);
    if(e.name==='AbortError')showError('Analysis timed out. Try a shorter track or smaller file.');
    else showError('Error: '+e.message);
  });
}
</script>
</body>
</html>"""


def _serve(port: int) -> None:
    """Start the production WSGI server."""
    from waitress import serve

    _preload_seed()
    serve(app, host="127.0.0.1", port=port, threads=4, channel_timeout=120)


def run_app(port: int = 5432, no_browser: bool = False) -> None:
    """Run the web UI in browser mode."""
    if not no_browser:
        Timer(1.0, lambda: webbrowser.open(f"http://localhost:{port}")).start()
    _serve(port)


def run_desktop(port: int = 5432) -> None:
    """Run as a native desktop window using pywebview."""
    from threading import Thread

    import webview

    _preload_seed()

    # Start production server in background thread
    server = Thread(target=lambda: _serve(port), daemon=True)
    server.start()

    # Icon path
    icon_path = str(Path(__file__).parent / "data" / "icon.png")
    icon = icon_path if Path(icon_path).exists() else None

    # API bridge for pywebview — exposes open_url to JS
    class Api:
        def open_url(self, url: str) -> None:
            webbrowser.open(url)

    # Create native window
    webview.create_window(
        "RefMatch",
        f"http://127.0.0.1:{port}",
        width=960,
        height=740,
        min_size=(700, 500),
        background_color="#0a0a0f",
        on_top=True,
        js_api=Api(),
    )
    webview.start(icon=icon)
