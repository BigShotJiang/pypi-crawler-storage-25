"""CLAP embedding extraction — pretrained audio model for perceptual similarity.

Uses laion/clap-htsat-fused for variable-length audio support.
Falls back gracefully when transformers/torch not installed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

import numpy as np

CLAP_DIM: Final[int] = 512
CLAP_SR: Final[int] = 48000
CLAP_MODEL_ID: Final[str] = "laion/clap-htsat-fused"
SEGMENT_DURATION_SEC: Final[float] = 30.0


@dataclass(frozen=True)
class ClapEmbedding:
    """CLAP audio embedding with metadata."""

    vector: np.ndarray  # L2-normalized, shape (512,)
    model_id: str
    segments_used: int


def is_available() -> bool:
    """Check if CLAP dependencies (transformers, torch) are installed."""
    try:
        import torch  # noqa: F401
        from transformers import ClapModel  # noqa: F401

        return True
    except ImportError:
        return False


def _get_device() -> str:
    """Pick the best available device: MPS > CPU."""
    import torch

    if torch.backends.mps.is_available():
        return "mps"
    return "cpu"


# Module-level cache for model + processor (lazy loaded)
_model = None
_processor = None


def _ensure_model():
    """Lazy-load model and processor on first use."""
    global _model, _processor

    if _model is not None:
        return _model, _processor

    from transformers import ClapModel, ClapProcessor

    device = _get_device()
    _processor = ClapProcessor.from_pretrained(CLAP_MODEL_ID)
    _model = ClapModel.from_pretrained(CLAP_MODEL_ID)
    _model.eval()
    _model = _model.to(device)

    return _model, _processor


def extract_clap_embedding(audio_path: str) -> ClapEmbedding:
    """Extract a CLAP embedding from an audio file.

    Loads audio at 48kHz, chunks into 30-second segments,
    embeds each segment, and returns the L2-normalized mean embedding.

    Raises:
        ImportError: if transformers/torch not installed.
        ValueError: if audio is too short or unreadable.
    """
    import librosa
    import torch

    model, processor = _ensure_model()
    device = next(model.parameters()).device

    # Load at 48kHz for CLAP
    audio, sr = librosa.load(audio_path, sr=CLAP_SR, mono=True)

    if len(audio) < CLAP_SR * 3:  # minimum 3 seconds
        raise ValueError(f"Audio too short for CLAP: {len(audio) / CLAP_SR:.1f}s")

    # Chunk into segments for variable-length support
    segment_samples = int(SEGMENT_DURATION_SEC * CLAP_SR)
    segments = []

    if len(audio) <= segment_samples:
        segments.append(audio)
    else:
        # Overlapping segments: step by half the segment length
        step = segment_samples // 2
        for start in range(0, len(audio) - segment_samples + 1, step):
            segments.append(audio[start : start + segment_samples])
        # Include the tail if there's a meaningful remainder
        remainder = audio[-(segment_samples):]
        if len(segments) == 0 or not np.array_equal(segments[-1], remainder):
            segments.append(remainder)

    # Embed each segment
    embeddings = []
    for seg in segments:
        inputs = processor(
            audios=seg,
            sampling_rate=CLAP_SR,
            return_tensors="pt",
        )
        inputs = {k: v.to(device) for k, v in inputs.items()}

        with torch.no_grad():
            emb = model.get_audio_features(**inputs)  # [1, 512]

        embeddings.append(emb.cpu().numpy().squeeze())

    # Average all segment embeddings
    mean_emb = np.mean(embeddings, axis=0).astype(np.float32)

    # L2 normalize
    norm = np.linalg.norm(mean_emb)
    if norm > 0:
        mean_emb /= norm

    return ClapEmbedding(
        vector=mean_emb,
        model_id=CLAP_MODEL_ID,
        segments_used=len(segments),
    )
