"""Similarity matching engine — finds reference tracks closest to a query."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

import numpy as np

from refmatch.database import TrackDatabase, TrackRecord
from refmatch.features import DIMENSIONS, FEATURE_NAMES, AudioFeatures

# Weight for blending DSP and CLAP similarity scores
# 0.0 = pure DSP, 1.0 = pure CLAP
CLAP_WEIGHT: Final[float] = 0.6


@dataclass(frozen=True)
class MatchResult:
    """A single match result with explainability."""

    track: TrackRecord
    similarity: float  # 0-1, higher = more similar
    explanation: list[str]  # human-readable reasons
    dsp_score: float | None = None
    clap_score: float | None = None


def _explain_match(query: AudioFeatures, track: TrackRecord) -> list[str]:
    """Generate human-readable explanations for why a track matches."""
    reasons = []

    # Loudness comparison
    lufs_diff = abs(query.lufs - track.lufs)
    if lufs_diff < 1.5:
        reasons.append(f"Very similar loudness ({track.lufs:.1f} LUFS, diff: {lufs_diff:.1f} dB)")
    elif lufs_diff < 3.0:
        reasons.append(f"Close loudness ({track.lufs:.1f} LUFS, diff: {lufs_diff:.1f} dB)")

    # BPM comparison
    bpm_diff = abs(query.bpm - track.bpm)
    if bpm_diff < 3:
        reasons.append(f"Same tempo range ({track.bpm:.0f} BPM)")
    elif bpm_diff < 8:
        reasons.append(f"Similar tempo ({track.bpm:.0f} BPM, diff: {bpm_diff:.0f})")

    # Key comparison
    if query.estimated_key == track.estimated_key:
        reasons.append(f"Same key ({track.estimated_key})")

    # Dynamic range
    dr_diff = abs(query.dynamic_range - track.dynamic_range)
    if dr_diff < 2.0:
        reasons.append(f"Similar dynamics (range: {track.dynamic_range:.1f} dB)")

    # Brightness
    br_diff = abs(query.brightness - track.brightness)
    if br_diff < 0.1:
        reasons.append("Matching tonal brightness")
    elif query.brightness > track.brightness + 0.15:
        reasons.append(
            f"Reference is warmer (brightness: {track.brightness:.2f}"
            f" vs yours: {query.brightness:.2f})"
        )
    elif track.brightness > query.brightness + 0.15:
        reasons.append(
            f"Reference is brighter (brightness: {track.brightness:.2f}"
            f" vs yours: {query.brightness:.2f})"
        )

    # Spectral balance via contrast bands
    q_low = float(np.mean(query.vector[17:20]))  # contrast bands 0-2
    t_low = float(np.mean(track.vector[17:20]))
    if abs(q_low - t_low) < 0.03:
        reasons.append("Similar low-end energy")

    if not reasons:
        reasons.append("Overall spectral similarity")

    return reasons


def find_matches(
    query: AudioFeatures,
    db: TrackDatabase,
    top_k: int = 5,
    dimension: str | None = None,
    source: str | None = None,
    clap_vector: np.ndarray | None = None,
) -> list[MatchResult]:
    """Find the top-K most similar tracks to the query.

    Args:
        query: Features of the query track.
        db: Track database to search.
        top_k: Number of results to return.
        dimension: Optional dimension to match on (low-end, loudness, brightness, rhythm, harmony).
        source: Optional filter by source (e.g., 'seed', 'user').
        clap_vector: Optional CLAP embedding for hybrid matching.

    Returns:
        List of MatchResult sorted by similarity (highest first).
    """
    if top_k < 1:
        raise ValueError(f"top_k must be >= 1, got {top_k}")

    vectors, ids = db.get_vectors_and_ids(source)

    if vectors.size == 0:
        return []

    if dimension is not None:
        # Dimension-specific matching: use subset of DSP features only
        if dimension not in DIMENSIONS:
            raise ValueError(f"Unknown dimension: {dimension}. Choose from: {list(DIMENSIONS)}")

        indices = [FEATURE_NAMES.index(name) for name in DIMENSIONS[dimension]]
        query_sub = query.vector[indices].copy()
        q_norm = np.linalg.norm(query_sub)
        if q_norm > 0:
            query_sub /= q_norm

        db_sub = vectors[:, indices].copy()
        norms = np.linalg.norm(db_sub, axis=1, keepdims=True)
        norms = np.where(norms == 0, 1, norms)
        db_sub /= norms

        dsp_scores = db_sub @ query_sub
    else:
        # Full DSP vector matching
        dsp_scores = vectors @ query.vector

    # Build CLAP score map if available
    clap_score_map: dict[int, float] = {}
    use_hybrid = clap_vector is not None and dimension is None
    if use_hybrid:
        clap_vectors, clap_ids = db.get_clap_vectors_and_ids(source)
        if clap_vectors.size > 0:
            clap_sims = clap_vectors @ clap_vector
            for i, cid in enumerate(clap_ids):
                clap_score_map[cid] = float(clap_sims[i])

    # Compute final blended scores
    final_scores = np.empty(len(ids), dtype=np.float64)
    for i, track_id in enumerate(ids):
        dsp = float(dsp_scores[i])
        if use_hybrid and track_id in clap_score_map:
            clap = clap_score_map[track_id]
            final_scores[i] = (1 - CLAP_WEIGHT) * dsp + CLAP_WEIGHT * clap
        else:
            final_scores[i] = dsp

    # Get top-K indices
    k = min(top_k, len(final_scores))
    top_indices = np.argsort(final_scores)[::-1][:k]

    results = []
    for idx in top_indices:
        track_id = ids[idx]
        track = db.get_track_by_id(track_id)
        if track is None:
            continue

        raw_sim = float(final_scores[idx])
        # Map cosine similarity [-1, 1] to [0, 1] uniformly
        sim = (raw_sim + 1.0) / 2.0

        dsp_s = (float(dsp_scores[idx]) + 1.0) / 2.0
        clap_s = (
            (clap_score_map[track_id] + 1.0) / 2.0
            if track_id in clap_score_map
            else None
        )

        explanation = _explain_match(query, track)
        results.append(MatchResult(
            track=track,
            similarity=sim,
            explanation=explanation,
            dsp_score=dsp_s,
            clap_score=clap_s,
        ))

    return results
