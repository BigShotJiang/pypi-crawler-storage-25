"""Audio feature extraction and vector construction."""

from dataclasses import dataclass
from typing import Final

import librosa
import numpy as np
import pyloudnorm
import soundfile as sf

# Preprocessing constants
SAMPLE_RATE: Final[int] = 22050
MIN_DURATION_SEC: Final[float] = 10.0
SILENCE_THRESHOLD_DB: Final[float] = -60.0

# Feature vector dimension names for explainability
FEATURE_NAMES: Final[list[str]] = [
    # MFCCs (13)
    *[f"mfcc_{i}" for i in range(13)],
    # Spectral (4)
    "spectral_centroid_mean",
    "spectral_centroid_std",
    "spectral_bandwidth_mean",
    "spectral_bandwidth_std",
    # Spectral contrast (7 bands)
    *[f"spectral_contrast_{i}" for i in range(7)],
    # Other spectral (2)
    "spectral_rolloff_mean",
    "zero_crossing_rate_mean",
    # Energy (2)
    "rms_mean",
    "rms_std",
    # Rhythm (1)
    "tempo",
    # Loudness (2)
    "lufs",
    "dynamic_range",
    # Chroma (12)
    *[f"chroma_{i}" for i in range(12)],
]

VECTOR_DIM: Final[int] = len(FEATURE_NAMES)  # 43 dimensions

# Dimension subsets for targeted matching
DIMENSIONS: Final[dict[str, list[str]]] = {
    "low-end": [
        "spectral_contrast_0",
        "spectral_contrast_1",
        "spectral_contrast_2",
        "rms_mean",
        "spectral_centroid_mean",
    ],
    "loudness": [
        "lufs",
        "dynamic_range",
        "rms_mean",
        "rms_std",
    ],
    "brightness": [
        "spectral_centroid_mean",
        "spectral_centroid_std",
        "spectral_rolloff_mean",
        "spectral_contrast_5",
        "spectral_contrast_6",
    ],
    "rhythm": [
        "tempo",
        "zero_crossing_rate_mean",
        "rms_std",
    ],
    "harmony": [
        *[f"chroma_{i}" for i in range(12)],
    ],
}


@dataclass(frozen=True)
class AudioFeatures:
    """Extracted audio features with metadata."""

    vector: np.ndarray  # L2-normalized feature vector
    bpm: float
    estimated_key: str
    lufs: float
    dynamic_range: float
    duration_sec: float
    sample_rate_original: int
    brightness: float  # 0-1 scale, derived from spectral centroid

    def dimension_vector(self, dimension: str) -> np.ndarray:
        """Extract a subset of the feature vector for dimension-specific matching."""
        if dimension not in DIMENSIONS:
            raise ValueError(f"Unknown dimension: {dimension}. Choose from: {list(DIMENSIONS)}")
        indices = [FEATURE_NAMES.index(name) for name in DIMENSIONS[dimension]]
        sub = self.vector[indices].copy()
        norm = np.linalg.norm(sub)
        if norm > 0:
            sub /= norm
        return sub


# Key estimation via chroma
_KEY_NAMES: Final[list[str]] = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]

_MAJOR_PROFILE: Final[np.ndarray] = np.array(
    [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
)
_MINOR_PROFILE: Final[np.ndarray] = np.array(
    [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]
)


def _estimate_key(chroma_mean: np.ndarray) -> str:
    """Estimate musical key using Krumhansl-Kessler profiles."""
    best_corr = -1.0
    best_key = "C major"
    for shift in range(12):
        rotated = np.roll(chroma_mean, -shift)
        major_corr = float(np.corrcoef(rotated, _MAJOR_PROFILE)[0, 1])
        minor_corr = float(np.corrcoef(rotated, _MINOR_PROFILE)[0, 1])
        if major_corr > best_corr:
            best_corr = major_corr
            best_key = f"{_KEY_NAMES[shift]} major"
        if minor_corr > best_corr:
            best_corr = minor_corr
            best_key = f"{_KEY_NAMES[shift]} minor"
    return best_key


def _compute_brightness(spectral_centroid_mean: float, sr: int) -> float:
    """Convert spectral centroid to 0-1 brightness scale."""
    nyquist = sr / 2.0
    return float(np.clip(spectral_centroid_mean / nyquist, 0.0, 1.0))


def extract_features(audio_path: str) -> AudioFeatures:
    """Extract audio features from a file and return a normalized feature vector.

    Preprocessing:
    - Resample to 22050 Hz
    - Fold to mono
    - Trim leading/trailing silence
    - Reject tracks shorter than 10 seconds
    """
    # Load with original sample rate for LUFS measurement
    audio_orig, sr_orig = sf.read(audio_path)
    if audio_orig.ndim > 1:
        audio_orig = np.mean(audio_orig, axis=1)

    # LUFS measurement needs original sample rate
    meter = pyloudnorm.Meter(sr_orig)
    try:
        lufs = meter.integrated_loudness(audio_orig)
    except Exception:
        lufs = -24.0  # fallback for very short/silent audio

    if np.isinf(lufs) or np.isnan(lufs):
        lufs = -70.0

    # Load with librosa for feature extraction (resampled, mono)
    y, sr = librosa.load(audio_path, sr=SAMPLE_RATE, mono=True)

    # Trim silence
    y_trimmed, _ = librosa.effects.trim(y, top_db=abs(SILENCE_THRESHOLD_DB))
    duration = len(y_trimmed) / sr

    if duration < MIN_DURATION_SEC:
        raise ValueError(
            f"Track too short: {duration:.1f}s (minimum {MIN_DURATION_SEC}s after silence trim)"
        )

    y = y_trimmed

    # MFCCs
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    mfcc_mean = np.mean(mfccs, axis=1)

    # Spectral centroid
    cent = librosa.feature.spectral_centroid(y=y, sr=sr)[0]
    cent_mean, cent_std = float(np.mean(cent)), float(np.std(cent))

    # Spectral bandwidth
    bw = librosa.feature.spectral_bandwidth(y=y, sr=sr)[0]
    bw_mean, bw_std = float(np.mean(bw)), float(np.std(bw))

    # Spectral contrast (7 bands)
    contrast = librosa.feature.spectral_contrast(y=y, sr=sr, n_bands=6)
    contrast_mean = np.mean(contrast, axis=1)  # 7 values (6 bands + 1 valley)

    # Spectral rolloff
    rolloff = librosa.feature.spectral_rolloff(y=y, sr=sr)[0]
    rolloff_mean = float(np.mean(rolloff))

    # Zero crossing rate
    zcr = librosa.feature.zero_crossing_rate(y)[0]
    zcr_mean = float(np.mean(zcr))

    # RMS energy
    rms = librosa.feature.rms(y=y)[0]
    rms_mean, rms_std = float(np.mean(rms)), float(np.std(rms))

    # Tempo
    tempo_arr = librosa.beat.tempo(y=y, sr=sr)  # noqa: deprecated in 0.10, removed in 1.0
    tempo = float(tempo_arr[0]) if len(tempo_arr) > 0 else 120.0

    # Dynamic range (difference between 95th and 5th percentile of RMS in dB)
    rms_db = librosa.amplitude_to_db(rms, ref=np.max)
    dynamic_range = float(np.percentile(rms_db, 95) - np.percentile(rms_db, 5))

    # Chroma
    chroma = librosa.feature.chroma_stft(y=y, sr=sr)
    chroma_mean = np.mean(chroma, axis=1)

    # Key estimation
    estimated_key = _estimate_key(chroma_mean)

    # Brightness
    brightness = _compute_brightness(cent_mean, sr)

    # Build feature vector
    vector = np.concatenate([
        mfcc_mean,  # 13
        [cent_mean, cent_std],  # 2
        [bw_mean, bw_std],  # 2
        contrast_mean,  # 7
        [rolloff_mean],  # 1
        [zcr_mean],  # 1
        [rms_mean, rms_std],  # 2
        [tempo],  # 1
        [lufs],  # 1
        [dynamic_range],  # 1
        chroma_mean,  # 12
    ]).astype(np.float32)

    # L2 normalize
    norm = np.linalg.norm(vector)
    if norm > 0:
        vector /= norm

    return AudioFeatures(
        vector=vector,
        bpm=tempo,
        estimated_key=estimated_key,
        lufs=lufs,
        dynamic_range=dynamic_range,
        duration_sec=duration,
        sample_rate_original=sr_orig,
        brightness=brightness,
    )
