"""RefMatch CLI — reference track suggestions for music producers."""

import sys
from pathlib import Path

import click
from rich.console import Console

from refmatch import __version__
from refmatch import embeddings as clap
from refmatch.database import TrackDatabase
from refmatch.display import display_analysis, display_library_stats, display_matches
from refmatch.features import DIMENSIONS, extract_features
from refmatch.matcher import find_matches

console = Console()

# Default paths
_DATA_DIR = Path.home() / ".refmatch"
_DB_PATH = _DATA_DIR / "library.db"
_SEED_DIR = Path(__file__).parent / "data" / "seed"


def _get_db() -> TrackDatabase:
    """Get or create the track database."""
    return TrackDatabase(_DB_PATH)


def _ensure_seed_loaded(db: TrackDatabase) -> None:
    """Load seed database if not already loaded."""
    if db.get_track_count(source="seed") > 0:
        return

    seed_path = _SEED_DIR
    if seed_path.exists() and (seed_path / "metadata.json").exists():
        try:
            count = db.import_seed(seed_path)
            console.print(f"[dim]Loaded {count} seed tracks[/dim]")
        except Exception as e:
            console.print(f"[yellow]Could not load seed database: {e}[/yellow]")


@click.group()
@click.version_option(version=__version__, prog_name="refmatch")
def main() -> None:
    """RefMatch — AI-powered reference track suggestions for music producers.

    Analyze your track and find reference tracks that match its sonic characteristics.
    """


@main.command()
@click.argument("file", type=click.Path(exists=True))
def analyze(file: str) -> None:
    """Analyze an audio file and display its features.

    Extracts BPM, key, loudness, spectral balance, and more.
    """
    path = Path(file)
    console.print(f"[dim]Analyzing {path.name}...[/dim]")

    try:
        features = extract_features(str(path))
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Could not process audio file: {e}[/red]")
        console.print("[dim]Supported formats: WAV, MP3, FLAC, OGG, AIFF[/dim]")
        sys.exit(1)

    display_analysis(features, path.name)


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.option(
    "-n", "--top", default=5, type=click.IntRange(min=1, max=50),
    help="Number of matches to return", show_default=True,
)
@click.option(
    "-d",
    "--dimension",
    type=click.Choice(list(DIMENSIONS.keys())),
    default=None,
    help="Match on a specific sonic dimension",
)
@click.option("--library", is_flag=True, help="Match against your own library only")
@click.option("--no-clap", is_flag=True, help="Disable CLAP embeddings (DSP only)")
def match(file: str, top: int, dimension: str | None, library: bool, no_clap: bool) -> None:
    """Find reference tracks that match your audio file.

    Analyzes the input file and searches the database for the most similar tracks.
    Uses CLAP neural embeddings when available for better perceptual matching.
    """
    path = Path(file)
    console.print(f"[dim]Analyzing {path.name}...[/dim]")

    try:
        features = extract_features(str(path))
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        sys.exit(1)
    except Exception as e:
        console.print(f"[red]Could not process audio file: {e}[/red]")
        sys.exit(1)

    # Extract CLAP embedding if available and not disabled
    clap_vector = None
    if not no_clap and clap.is_available():
        try:
            console.print("[dim]Extracting CLAP embedding...[/dim]")
            clap_emb = clap.extract_clap_embedding(str(path))
            clap_vector = clap_emb.vector
            console.print(
                f"[dim]CLAP: {clap_emb.segments_used} segments, "
                f"hybrid matching enabled[/dim]"
            )
        except Exception as e:
            console.print(f"[dim]CLAP unavailable: {e} (using DSP only)[/dim]")

    db = _get_db()
    _ensure_seed_loaded(db)

    source = "user" if library else None
    total = db.get_track_count(source)

    if total == 0:
        if library:
            console.print(
                "[yellow]Your library is empty. "
                "Add tracks with: refmatch library add <file>[/yellow]"
            )
        else:
            console.print(
                "[yellow]No tracks in database. "
                "Add tracks or install the seed database.[/yellow]"
            )
        db.close()
        sys.exit(1)

    console.print(f"[dim]Searching {total} tracks...[/dim]")
    results = find_matches(
        features, db, top_k=top, dimension=dimension, source=source,
        clap_vector=clap_vector,
    )
    display_matches(results, path.name, dimension)
    db.close()


@main.group()
def library() -> None:
    """Manage your reference track library."""


@library.command("add")
@click.argument("path", type=click.Path(exists=True))
@click.option("--artist", default="Unknown", help="Artist name")
@click.option("--genre", default="Unknown", help="Genre tag")
@click.option("--no-clap", is_flag=True, help="Skip CLAP embedding extraction")
def library_add(path: str, artist: str, genre: str, no_clap: bool) -> None:
    """Add a track or directory of tracks to your library."""
    p = Path(path)
    db = _get_db()

    use_clap = not no_clap and clap.is_available()
    if use_clap:
        console.print("[dim]CLAP model available — extracting neural embeddings[/dim]")

    audio_extensions = {".wav", ".mp3", ".flac", ".ogg", ".aiff", ".aif", ".m4a"}

    if p.is_file():
        files = [p]
    elif p.is_dir():
        files = [f for f in p.rglob("*") if f.suffix.lower() in audio_extensions]
        if not files:
            console.print(f"[yellow]No audio files found in {p}[/yellow]")
            db.close()
            return
        console.print(f"[dim]Found {len(files)} audio files[/dim]")
    else:
        console.print(f"[red]Not a file or directory: {p}[/red]")
        db.close()
        sys.exit(1)

    added = 0
    skipped = 0

    for audio_file in files:
        abs_path = str(audio_file.resolve())
        if db.has_path(abs_path):
            skipped += 1
            continue

        try:
            features = extract_features(abs_path)
            title = audio_file.stem.replace("_", " ").replace("-", " ").title()

            clap_vector = None
            if use_clap:
                try:
                    clap_emb = clap.extract_clap_embedding(abs_path)
                    clap_vector = clap_emb.vector
                except Exception:
                    pass  # CLAP failure is non-fatal

            db.add_track(
                path=abs_path,
                title=title,
                artist=artist,
                genre=genre,
                bpm=features.bpm,
                estimated_key=features.estimated_key,
                lufs=features.lufs,
                dynamic_range=features.dynamic_range,
                duration_sec=features.duration_sec,
                brightness=features.brightness,
                vector=features.vector,
                source="user",
                clap_vector=clap_vector,
            )
            added += 1
            clap_tag = " [cyan]+CLAP[/cyan]" if clap_vector is not None else ""
            console.print(f"  [green]+[/green] {audio_file.name}{clap_tag}")
        except ValueError as e:
            console.print(f"  [yellow]![/yellow] {audio_file.name}: {e}")
        except Exception as e:
            console.print(f"  [red]x[/red] {audio_file.name}: {e}")

    console.print(f"\n[bold]Added {added} tracks[/bold]", end="")
    if skipped:
        console.print(f" [dim]({skipped} already in library)[/dim]", end="")
    console.print()
    db.close()


@library.command("list")
def library_list() -> None:
    """Show library contents and stats."""
    db = _get_db()
    user_count = db.get_track_count(source="user")
    seed_count = db.get_track_count(source="seed")
    display_library_stats(user_count, seed_count)

    if user_count > 0:
        console.print("\n[bold]Your tracks:[/bold]")
        tracks = db.get_all_tracks(source="user")
        for t in tracks[:20]:  # Show max 20
            console.print(
                f"  {t.id:>4}  {t.title:<30}  {t.artist:<20}  "
                f"{t.bpm:.0f} BPM  {t.estimated_key:<10}  {t.lufs:.1f} LUFS"
            )
        if user_count > 20:
            console.print(f"  [dim]... and {user_count - 20} more[/dim]")

    db.close()


@library.command("remove")
@click.argument("track_id", type=int)
def library_remove(track_id: int) -> None:
    """Remove a track from your library by ID (seed tracks are protected)."""
    db = _get_db()
    track = db.get_track_by_id(track_id)
    if track is None:
        console.print(f"[yellow]Track {track_id} not found[/yellow]")
    elif track.source == "seed":
        console.print(f"[red]Cannot remove seed track {track_id}[/red]")
    elif db.remove_track(track_id):
        console.print(f"[green]Removed track {track_id}[/green]")
    db.close()


@main.command()
@click.option("-p", "--port", default=5432, type=int, help="Port to run on", show_default=True)
@click.option("--no-browser", is_flag=True, help="Don't auto-open browser")
@click.option("--desktop", is_flag=True, help="Launch as native desktop window (always-on-top)")
def app(port: int, no_browser: bool, desktop: bool) -> None:
    """Launch RefMatch UI.

    Default: opens in your browser.
    With --desktop: opens as a native always-on-top window next to your DAW.
    """
    if desktop:
        try:
            from refmatch.webapp import run_desktop

            console.print("[bold cyan]RefMatch[/bold cyan] desktop app starting...")
            run_desktop(port=port)
        except ImportError:
            console.print(
                "[red]Desktop mode requires pywebview.[/red]\n"
                "Install it with: pip install pywebview"
            )
            sys.exit(1)
    else:
        from refmatch.webapp import run_app

        console.print(
            f"[bold cyan]RefMatch[/bold cyan] web UI starting on http://localhost:{port}"
        )
        run_app(port=port, no_browser=no_browser)


if __name__ == "__main__":
    main()
