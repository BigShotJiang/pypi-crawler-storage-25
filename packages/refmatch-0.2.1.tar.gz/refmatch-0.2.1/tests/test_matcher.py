"""Tests for the matching engine."""

from pathlib import Path

import numpy as np
import pytest

from refmatch.database import TrackDatabase
from refmatch.features import VECTOR_DIM, AudioFeatures, extract_features
from refmatch.matcher import find_matches


def _make_vector(seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    v = rng.random(VECTOR_DIM).astype(np.float32)
    v /= np.linalg.norm(v)
    return v


def _populate_db(db: TrackDatabase, count: int = 10) -> None:
    """Add some test tracks to the database."""
    for i in range(count):
        db.add_track(
            path=f"/test/track_{i}.wav",
            title=f"Track {i}",
            artist=f"Artist {i % 3}",
            genre=["Electronic", "Hip-Hop", "Rock", "Pop", "Jazz"][i % 5],
            bpm=100.0 + i * 5,
            estimated_key=["C major", "A minor", "G major", "E minor", "F major"][i % 5],
            lufs=-8.0 - i * 0.5,
            dynamic_range=4.0 + i * 0.3,
            duration_sec=180.0 + i * 10,
            brightness=0.3 + i * 0.05,
            vector=_make_vector(i),
            source="seed",
        )


class TestFindMatches:
    def test_returns_requested_count(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        _populate_db(db)
        # Create a synthetic query
        query = AudioFeatures(
            vector=_make_vector(0),
            bpm=120.0, estimated_key="C major", lufs=-8.0,
            dynamic_range=6.0, duration_sec=180.0,
            sample_rate_original=44100, brightness=0.5,
        )

        results = find_matches(query, db, top_k=5)
        assert len(results) == 5
        db.close()

    def test_returns_less_if_db_small(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        _populate_db(db, count=3)

        query = AudioFeatures(
            vector=_make_vector(99),
            bpm=120.0, estimated_key="C major", lufs=-8.0,
            dynamic_range=6.0, duration_sec=180.0,
            sample_rate_original=44100, brightness=0.5,
        )

        results = find_matches(query, db, top_k=5)
        assert len(results) == 3
        db.close()

    def test_empty_db_returns_empty(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)

        query = AudioFeatures(
            vector=_make_vector(0),
            bpm=120.0, estimated_key="C major", lufs=-8.0,
            dynamic_range=6.0, duration_sec=180.0,
            sample_rate_original=44100, brightness=0.5,
        )

        results = find_matches(query, db, top_k=5)
        assert len(results) == 0
        db.close()

    def test_most_similar_first(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        _populate_db(db)

        from refmatch.features import AudioFeatures
        # Query with same vector as track 0 — should match highest
        query = AudioFeatures(
            vector=_make_vector(0),
            bpm=100.0, estimated_key="C major", lufs=-8.0,
            dynamic_range=4.0, duration_sec=180.0,
            sample_rate_original=44100, brightness=0.3,
        )

        results = find_matches(query, db, top_k=5)
        assert results[0].similarity >= results[1].similarity
        assert results[0].track.title == "Track 0"
        db.close()

    def test_results_sorted_descending(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        _populate_db(db)

        query = AudioFeatures(
            vector=_make_vector(42),
            bpm=120.0, estimated_key="A minor", lufs=-10.0,
            dynamic_range=6.0, duration_sec=200.0,
            sample_rate_original=44100, brightness=0.5,
        )

        results = find_matches(query, db, top_k=5)
        for i in range(len(results) - 1):
            assert results[i].similarity >= results[i + 1].similarity
        db.close()

    def test_dimension_matching(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        _populate_db(db)

        query = AudioFeatures(
            vector=_make_vector(0),
            bpm=100.0, estimated_key="C major", lufs=-8.0,
            dynamic_range=4.0, duration_sec=180.0,
            sample_rate_original=44100, brightness=0.3,
        )

        results = find_matches(query, db, top_k=3, dimension="loudness")
        assert len(results) <= 3
        # Results should still be sorted
        for i in range(len(results) - 1):
            assert results[i].similarity >= results[i + 1].similarity
        db.close()

    def test_invalid_dimension_raises(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        _populate_db(db)

        from refmatch.features import AudioFeatures
        query = AudioFeatures(
            vector=_make_vector(0),
            bpm=100.0, estimated_key="C major", lufs=-8.0,
            dynamic_range=4.0, duration_sec=180.0,
            sample_rate_original=44100, brightness=0.3,
        )

        with pytest.raises(ValueError, match="Unknown dimension"):
            find_matches(query, db, dimension="nonexistent")
        db.close()

    def test_explanation_not_empty(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        _populate_db(db)

        query = AudioFeatures(
            vector=_make_vector(0),
            bpm=100.0, estimated_key="C major", lufs=-8.0,
            dynamic_range=4.0, duration_sec=180.0,
            sample_rate_original=44100, brightness=0.3,
        )

        results = find_matches(query, db, top_k=1)
        assert len(results[0].explanation) > 0
        db.close()

    def test_source_filter(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        _populate_db(db)  # adds as "seed"

        # Add one user track
        db.add_track(
            path="/user/my_track.wav", title="My Track", artist="Me", genre="Electronic",
            bpm=128.0, estimated_key="C minor", lufs=-8.0, dynamic_range=6.0,
            duration_sec=200.0, brightness=0.5, vector=_make_vector(50), source="user",
        )

        query = AudioFeatures(
            vector=_make_vector(50),
            bpm=128.0, estimated_key="C minor", lufs=-8.0,
            dynamic_range=6.0, duration_sec=200.0,
            sample_rate_original=44100, brightness=0.5,
        )

        results = find_matches(query, db, top_k=5, source="user")
        assert len(results) == 1
        assert results[0].track.source == "user"
        db.close()


class TestEndToEnd:
    def test_analyze_and_match(self, sine_wav: Path, noise_wav: Path, db_path: Path) -> None:
        """Full pipeline: extract features, add to DB, match."""
        db = TrackDatabase(db_path)

        # Add noise track to DB
        noise_features = extract_features(str(noise_wav))
        db.add_track(
            path=str(noise_wav), title="White Noise", artist="Test", genre="Noise",
            bpm=noise_features.bpm, estimated_key=noise_features.estimated_key,
            lufs=noise_features.lufs, dynamic_range=noise_features.dynamic_range,
            duration_sec=noise_features.duration_sec, brightness=noise_features.brightness,
            vector=noise_features.vector, source="seed",
        )

        # Add sine track to DB
        sine_features = extract_features(str(sine_wav))
        db.add_track(
            path=str(sine_wav), title="Sine 440", artist="Test", genre="Tone",
            bpm=sine_features.bpm, estimated_key=sine_features.estimated_key,
            lufs=sine_features.lufs, dynamic_range=sine_features.dynamic_range,
            duration_sec=sine_features.duration_sec, brightness=sine_features.brightness,
            vector=sine_features.vector, source="seed",
        )

        # Query with sine — should match sine first
        results = find_matches(sine_features, db, top_k=2)
        assert len(results) == 2
        assert results[0].track.title == "Sine 440"
        db.close()
