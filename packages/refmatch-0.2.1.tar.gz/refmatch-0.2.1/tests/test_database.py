"""Tests for track database."""

from pathlib import Path

import numpy as np

from refmatch.database import TrackDatabase
from refmatch.features import VECTOR_DIM


def _make_vector(seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    v = rng.random(VECTOR_DIM).astype(np.float32)
    v /= np.linalg.norm(v)
    return v


class TestTrackDatabase:
    def test_create_database(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        assert db_path.exists()
        db.close()

    def test_add_and_count(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        db.add_track(
            path="/test/track.wav",
            title="Test Track",
            artist="Test Artist",
            genre="Electronic",
            bpm=128.0,
            estimated_key="C minor",
            lufs=-8.0,
            dynamic_range=6.0,
            duration_sec=180.0,
            brightness=0.5,
            vector=_make_vector(0),
        )
        assert db.get_track_count() == 1
        db.close()

    def test_add_multiple(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        for i in range(5):
            db.add_track(
                path=f"/test/track_{i}.wav",
                title=f"Track {i}",
                artist="Artist",
                genre="Pop",
                bpm=120.0 + i,
                estimated_key="A minor",
                lufs=-10.0,
                dynamic_range=8.0,
                duration_sec=200.0,
                brightness=0.6,
                vector=_make_vector(i),
            )
        assert db.get_track_count() == 5
        db.close()

    def test_filter_by_source(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        db.add_track(
            path="/user/track.wav", title="User Track", artist="A", genre="Rock",
            bpm=120.0, estimated_key="E minor", lufs=-9.0, dynamic_range=7.0,
            duration_sec=200.0, brightness=0.5, vector=_make_vector(0), source="user",
        )
        db.add_track(
            path="seed://Artist/Track", title="Seed Track", artist="B", genre="Pop",
            bpm=130.0, estimated_key="G major", lufs=-7.0, dynamic_range=5.0,
            duration_sec=180.0, brightness=0.6, vector=_make_vector(1), source="seed",
        )
        assert db.get_track_count(source="user") == 1
        assert db.get_track_count(source="seed") == 1
        assert db.get_track_count() == 2
        db.close()

    def test_has_path(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        db.add_track(
            path="/test/track.wav", title="T", artist="A", genre="G",
            bpm=120.0, estimated_key="C major", lufs=-8.0, dynamic_range=6.0,
            duration_sec=180.0, brightness=0.5, vector=_make_vector(0),
        )
        assert db.has_path("/test/track.wav")
        assert not db.has_path("/other/track.wav")
        db.close()

    def test_remove_track(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        track_id = db.add_track(
            path="/test/track.wav", title="T", artist="A", genre="G",
            bpm=120.0, estimated_key="C major", lufs=-8.0, dynamic_range=6.0,
            duration_sec=180.0, brightness=0.5, vector=_make_vector(0),
        )
        assert db.remove_track(track_id)
        assert db.get_track_count() == 0
        db.close()

    def test_remove_nonexistent(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        assert not db.remove_track(999)
        db.close()

    def test_get_vectors_and_ids(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        for i in range(3):
            db.add_track(
                path=f"/test/{i}.wav", title=f"T{i}", artist="A", genre="G",
                bpm=120.0, estimated_key="C major", lufs=-8.0, dynamic_range=6.0,
                duration_sec=180.0, brightness=0.5, vector=_make_vector(i),
            )
        vectors, ids = db.get_vectors_and_ids()
        assert vectors.shape == (3, VECTOR_DIM)
        assert len(ids) == 3
        db.close()

    def test_get_vectors_empty(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        vectors, ids = db.get_vectors_and_ids()
        assert vectors.size == 0
        assert len(ids) == 0
        db.close()

    def test_export_import_seed(self, db_path: Path, tmp_dir: Path) -> None:
        db = TrackDatabase(db_path)
        for i in range(3):
            db.add_track(
                path=f"seed://A/T{i}", title=f"Track {i}", artist="Artist", genre="Pop",
                bpm=120.0 + i, estimated_key="C major", lufs=-8.0, dynamic_range=6.0,
                duration_sec=180.0, brightness=0.5, vector=_make_vector(i), source="seed",
            )

        export_dir = tmp_dir / "export"
        db.export_seed(export_dir)
        db.close()

        # Import into fresh DB
        db2_path = tmp_dir / "test2.db"
        db2 = TrackDatabase(db2_path)
        count = db2.import_seed(export_dir)
        assert count == 3
        assert db2.get_track_count(source="seed") == 3
        db2.close()

    def test_vector_roundtrip(self, db_path: Path) -> None:
        db = TrackDatabase(db_path)
        original = _make_vector(42)
        track_id = db.add_track(
            path="/test/rt.wav", title="RT", artist="A", genre="G",
            bpm=120.0, estimated_key="C major", lufs=-8.0, dynamic_range=6.0,
            duration_sec=180.0, brightness=0.5, vector=original,
        )
        track = db.get_track_by_id(track_id)
        assert track is not None
        np.testing.assert_array_almost_equal(track.vector, original)
        db.close()
