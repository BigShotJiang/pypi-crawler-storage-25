"""Tests for CLI commands."""

from pathlib import Path

from click.testing import CliRunner

from refmatch.cli import main


class TestCLI:
    def test_version(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["--version"])
        assert result.exit_code == 0
        assert "0.2.1" in result.output

    def test_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "reference track" in result.output.lower()

    def test_analyze_valid_file(self, sine_wav: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["analyze", str(sine_wav)])
        assert result.exit_code == 0
        assert "BPM" in result.output
        assert "LUFS" in result.output
        assert "Brightness" in result.output

    def test_analyze_short_file(self, short_wav: Path) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["analyze", str(short_wav)])
        assert result.exit_code == 1
        assert "too short" in result.output.lower()

    def test_analyze_nonexistent_file(self) -> None:
        runner = CliRunner()
        result = runner.invoke(main, ["analyze", "/nonexistent/file.wav"])
        assert result.exit_code != 0

    def test_library_list_empty(self, tmp_dir: Path, monkeypatch) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        runner = CliRunner()
        result = runner.invoke(main, ["library", "list"])
        assert result.exit_code == 0
        assert "0" in result.output

    def test_library_add_file(self, sine_wav: Path, tmp_dir: Path, monkeypatch) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        runner = CliRunner()
        result = runner.invoke(main, ["library", "add", str(sine_wav)])
        assert result.exit_code == 0
        assert "Added 1" in result.output

    def test_library_add_duplicate(self, sine_wav: Path, tmp_dir: Path, monkeypatch) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        runner = CliRunner()
        runner.invoke(main, ["library", "add", str(sine_wav)])
        result = runner.invoke(main, ["library", "add", str(sine_wav)])
        assert "already in library" in result.output

    def test_library_add_directory(
        self, sine_wav: Path, sine_880_wav: Path, tmp_dir: Path, monkeypatch,
    ) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        runner = CliRunner()
        result = runner.invoke(main, ["library", "add", str(sine_wav.parent)])
        assert result.exit_code == 0
        assert "Added" in result.output

    def test_library_add_empty_dir(self, tmp_dir: Path, monkeypatch) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        empty = tmp_dir / "empty"
        empty.mkdir()
        runner = CliRunner()
        result = runner.invoke(main, ["library", "add", str(empty)])
        assert "No audio files" in result.output

    def test_library_add_no_clap_flag(
        self, sine_wav: Path, tmp_dir: Path, monkeypatch,
    ) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        runner = CliRunner()
        result = runner.invoke(main, ["library", "add", "--no-clap", str(sine_wav)])
        assert result.exit_code == 0
        assert "Added 1" in result.output

    def test_library_remove_nonexistent(self, tmp_dir: Path, monkeypatch) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        runner = CliRunner()
        result = runner.invoke(main, ["library", "remove", "999"])
        assert "not found" in result.output.lower()

    def test_library_remove_existing(
        self, sine_wav: Path, tmp_dir: Path, monkeypatch,
    ) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        runner = CliRunner()
        runner.invoke(main, ["library", "add", str(sine_wav)])
        # Library list to find the ID
        result = runner.invoke(main, ["library", "list"])
        assert "1" in result.output
        # Remove track 1
        result = runner.invoke(main, ["library", "remove", "1"])
        assert "Removed" in result.output or result.exit_code == 0

    def test_match_no_db(self, sine_wav: Path, tmp_dir: Path, monkeypatch) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        monkeypatch.setattr("refmatch.cli._SEED_DIR", tmp_dir / "no_seed")
        runner = CliRunner()
        result = runner.invoke(main, ["match", str(sine_wav)])
        assert result.exit_code == 1

    def test_match_with_library(
        self, sine_wav: Path, sine_880_wav: Path, tmp_dir: Path, monkeypatch,
    ) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        monkeypatch.setattr("refmatch.cli._SEED_DIR", tmp_dir / "no_seed")
        runner = CliRunner()
        # Add some tracks first
        runner.invoke(main, ["library", "add", str(sine_wav)])
        runner.invoke(main, ["library", "add", str(sine_880_wav)])
        # Match against library
        result = runner.invoke(main, ["match", str(sine_wav), "--library"])
        assert result.exit_code == 0

    def test_match_empty_library(
        self, sine_wav: Path, tmp_dir: Path, monkeypatch,
    ) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        monkeypatch.setattr("refmatch.cli._SEED_DIR", tmp_dir / "no_seed")
        runner = CliRunner()
        result = runner.invoke(main, ["match", str(sine_wav), "--library"])
        assert result.exit_code == 1
        assert "empty" in result.output.lower()

    def test_match_with_dimension(
        self, sine_wav: Path, noise_wav: Path, tmp_dir: Path, monkeypatch,
    ) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        monkeypatch.setattr("refmatch.cli._SEED_DIR", tmp_dir / "no_seed")
        runner = CliRunner()
        runner.invoke(main, ["library", "add", str(noise_wav)])
        result = runner.invoke(main, [
            "match", str(sine_wav), "--library", "--dimension", "loudness",
        ])
        assert result.exit_code == 0

    def test_match_no_clap_flag(
        self, sine_wav: Path, noise_wav: Path, tmp_dir: Path, monkeypatch,
    ) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        monkeypatch.setattr("refmatch.cli._SEED_DIR", tmp_dir / "no_seed")
        runner = CliRunner()
        runner.invoke(main, ["library", "add", str(noise_wav)])
        result = runner.invoke(main, [
            "match", str(sine_wav), "--library", "--no-clap",
        ])
        assert result.exit_code == 0

    def test_match_top_n(
        self, sine_wav: Path, noise_wav: Path, bass_wav: Path,
        tmp_dir: Path, monkeypatch,
    ) -> None:
        monkeypatch.setattr("refmatch.cli._DB_PATH", tmp_dir / "test.db")
        monkeypatch.setattr("refmatch.cli._SEED_DIR", tmp_dir / "no_seed")
        runner = CliRunner()
        runner.invoke(main, ["library", "add", str(noise_wav)])
        runner.invoke(main, ["library", "add", str(bass_wav)])
        result = runner.invoke(main, [
            "match", str(sine_wav), "--library", "-n", "1",
        ])
        assert result.exit_code == 0
