"""Tests for CLAP embedding extraction."""

from unittest.mock import MagicMock, patch

import numpy as np
import pytest

from refmatch.embeddings import (
    CLAP_DIM,
    CLAP_SR,
    SEGMENT_DURATION_SEC,
    ClapEmbedding,
    is_available,
)


class TestIsAvailable:
    def test_returns_bool(self) -> None:
        result = is_available()
        assert isinstance(result, bool)

    @patch.dict("sys.modules", {"torch": None})
    def test_false_without_torch(self) -> None:
        # Force reimport check
        with patch("builtins.__import__", side_effect=ImportError):
            assert is_available() is False


class TestClapEmbedding:
    def test_frozen_dataclass(self) -> None:
        vec = np.random.randn(CLAP_DIM).astype(np.float32)
        emb = ClapEmbedding(vector=vec, model_id="test", segments_used=1)
        assert emb.vector.shape == (CLAP_DIM,)
        assert emb.model_id == "test"
        assert emb.segments_used == 1

        with pytest.raises(AttributeError):
            emb.model_id = "changed"  # type: ignore[misc]


torch_available = pytest.importorskip("torch", reason="torch not installed")


@pytest.mark.skipif(not torch_available, reason="torch not installed")
class TestExtractClapEmbedding:
    @patch("refmatch.embeddings._ensure_model")
    def test_short_audio_raises(self, mock_model, tmp_dir) -> None:
        """Audio shorter than 3 seconds should raise."""
        import soundfile as sf

        mock_m = MagicMock()
        mock_p = MagicMock()
        mock_model.return_value = (mock_m, mock_p)

        short_path = tmp_dir / "short.wav"
        audio = np.zeros(int(CLAP_SR * 1), dtype=np.float32)  # 1 second
        sf.write(str(short_path), audio, CLAP_SR)

        from refmatch.embeddings import extract_clap_embedding

        with pytest.raises(ValueError, match="too short"):
            extract_clap_embedding(str(short_path))

    @patch("refmatch.embeddings._ensure_model")
    def test_embedding_shape_and_normalization(self, mock_model, sine_wav) -> None:
        """Extracted embedding should be 512-dim and L2-normalized."""
        import torch

        mock_m = MagicMock()
        mock_p = MagicMock()

        # Mock processor to return tensor dict
        mock_p.return_value = {"input_features": torch.randn(1, 64, 1001)}

        # Mock model to return 512-dim embedding
        fake_emb = torch.randn(1, CLAP_DIM)
        mock_m.get_audio_features.return_value = fake_emb
        mock_m.parameters.return_value = iter([torch.tensor([1.0])])  # CPU device

        mock_model.return_value = (mock_m, mock_p)

        from refmatch.embeddings import extract_clap_embedding

        result = extract_clap_embedding(str(sine_wav))

        assert isinstance(result, ClapEmbedding)
        assert result.vector.shape == (CLAP_DIM,)
        assert result.segments_used >= 1
        # Check L2 normalization
        norm = np.linalg.norm(result.vector)
        assert abs(norm - 1.0) < 1e-5

    @patch("refmatch.embeddings._ensure_model")
    def test_multiple_segments_for_long_audio(self, mock_model, tmp_dir) -> None:
        """Long audio should produce multiple segments."""
        import soundfile as sf
        import torch

        mock_m = MagicMock()
        mock_p = MagicMock()

        mock_p.return_value = {"input_features": torch.randn(1, 64, 1001)}
        fake_emb = torch.randn(1, CLAP_DIM)
        mock_m.get_audio_features.return_value = fake_emb
        mock_m.parameters.return_value = iter([torch.tensor([1.0])])

        mock_model.return_value = (mock_m, mock_p)

        # Create 90-second audio (should produce multiple segments)
        long_path = tmp_dir / "long.wav"
        audio = np.random.randn(int(CLAP_SR * 90)).astype(np.float32) * 0.1
        sf.write(str(long_path), audio, CLAP_SR)

        from refmatch.embeddings import extract_clap_embedding

        result = extract_clap_embedding(str(long_path))

        assert result.segments_used > 1
        assert result.vector.shape == (CLAP_DIM,)


class TestConstants:
    def test_dimensions(self) -> None:
        assert CLAP_DIM == 512

    def test_sample_rate(self) -> None:
        assert CLAP_SR == 48000

    def test_segment_duration(self) -> None:
        assert SEGMENT_DURATION_SEC == 30.0
