"""Tests for display formatting."""

import numpy as np

from refmatch.database import TrackRecord
from refmatch.display import (
    _bar,
    _brightness_label,
    display_analysis,
    display_library_stats,
    display_matches,
)
from refmatch.features import VECTOR_DIM, AudioFeatures
from refmatch.matcher import MatchResult


def _make_features() -> AudioFeatures:
    vec = np.random.randn(VECTOR_DIM).astype(np.float32)
    vec /= np.linalg.norm(vec)
    return AudioFeatures(
        vector=vec,
        bpm=120.0,
        estimated_key="C major",
        lufs=-14.0,
        dynamic_range=10.0,
        duration_sec=180.0,
        sample_rate_original=44100,
        brightness=0.5,
    )


def _make_track(track_id: int = 1) -> TrackRecord:
    vec = np.random.randn(VECTOR_DIM).astype(np.float32)
    vec /= np.linalg.norm(vec)
    return TrackRecord(
        id=track_id,
        path=f"seed://artist/track_{track_id}",
        title=f"Test Track {track_id}",
        artist="Test Artist",
        genre="Electronic",
        bpm=125.0,
        estimated_key="A minor",
        lufs=-12.0,
        dynamic_range=8.0,
        duration_sec=200.0,
        brightness=0.6,
        vector=vec,
        source="seed",
    )


class TestBar:
    def test_empty(self) -> None:
        assert _bar(0, 100) == "\u2591" * 10

    def test_full(self) -> None:
        assert _bar(100, 100) == "\u2588" * 10

    def test_half(self) -> None:
        result = _bar(50, 100)
        assert "\u2588" in result
        assert "\u2591" in result

    def test_zero_max(self) -> None:
        assert _bar(10, 0) == "\u2591" * 10


class TestBrightnessLabel:
    def test_dark(self) -> None:
        assert "dark" in _brightness_label(0.2) or "warm" in _brightness_label(0.2)

    def test_neutral(self) -> None:
        assert _brightness_label(0.6) == "neutral"

    def test_bright(self) -> None:
        assert "bright" in _brightness_label(0.8)

    def test_very_bright(self) -> None:
        assert "very bright" in _brightness_label(0.9)


class TestDisplayAnalysis:
    def test_renders_without_error(self, capsys) -> None:
        features = _make_features()
        display_analysis(features, "test.wav")
        # Just verify it didn't crash — Rich captures to its own console


class TestDisplayMatches:
    def test_empty_matches(self, capsys) -> None:
        display_matches([], "test.wav")
        # Should print "No matches found"

    def test_with_matches(self) -> None:
        track = _make_track()
        matches = [
            MatchResult(
                track=track,
                similarity=0.85,
                explanation=["Similar loudness", "Same tempo range"],
            ),
        ]
        # Should not raise
        display_matches(matches, "test.wav", None)

    def test_with_dimension(self) -> None:
        track = _make_track()
        matches = [
            MatchResult(
                track=track,
                similarity=0.9,
                explanation=["Similar low-end energy"],
            ),
        ]
        display_matches(matches, "test.wav", "low-end")

    def test_with_clap_scores(self) -> None:
        track = _make_track()
        matches = [
            MatchResult(
                track=track,
                similarity=0.88,
                explanation=["Matching tonal brightness"],
                dsp_score=0.82,
                clap_score=0.92,
            ),
        ]
        display_matches(matches, "test.wav", None)


class TestDisplayLibraryStats:
    def test_renders(self) -> None:
        display_library_stats(5, 100)

    def test_empty(self) -> None:
        display_library_stats(0, 0)
