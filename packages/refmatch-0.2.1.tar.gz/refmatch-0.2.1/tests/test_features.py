"""Tests for audio feature extraction."""

from pathlib import Path

import numpy as np
import pytest

from refmatch.features import DIMENSIONS, FEATURE_NAMES, VECTOR_DIM, extract_features


class TestExtractFeatures:
    def test_returns_correct_vector_dim(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        assert features.vector.shape == (VECTOR_DIM,)

    def test_vector_is_l2_normalized(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        norm = np.linalg.norm(features.vector)
        assert abs(norm - 1.0) < 1e-5

    def test_detects_bpm(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        assert features.bpm > 0

    def test_detects_lufs(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        assert features.lufs < 0  # Should be negative for normal audio

    def test_detects_key(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        assert features.estimated_key  # Should return a key string
        assert "major" in features.estimated_key or "minor" in features.estimated_key

    def test_brightness_in_range(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        assert 0.0 <= features.brightness <= 1.0

    def test_dynamic_range_positive(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        assert features.dynamic_range >= 0

    def test_duration_correct(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        assert abs(features.duration_sec - 15.0) < 1.0  # ~15 seconds

    def test_rejects_short_audio(self, short_wav: Path) -> None:
        with pytest.raises(ValueError, match="too short"):
            extract_features(str(short_wav))

    def test_noise_vs_sine_different_features(self, sine_wav: Path, noise_wav: Path) -> None:
        sine_features = extract_features(str(sine_wav))
        noise_features = extract_features(str(noise_wav))
        # Cosine similarity should be less than 1 (they are different)
        sim = float(np.dot(sine_features.vector, noise_features.vector))
        assert sim < 0.95

    def test_same_file_same_features(self, sine_wav: Path) -> None:
        f1 = extract_features(str(sine_wav))
        f2 = extract_features(str(sine_wav))
        np.testing.assert_array_almost_equal(f1.vector, f2.vector)

    def test_bass_is_less_bright_than_high(self, bass_wav: Path, sine_wav: Path) -> None:
        bass = extract_features(str(bass_wav))
        high = extract_features(str(sine_wav))  # 440Hz
        assert bass.brightness < high.brightness


class TestDimensionVector:
    def test_dimension_vector_subset(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        for dim_name, dim_features in DIMENSIONS.items():
            sub = features.dimension_vector(dim_name)
            assert sub.shape == (len(dim_features),)

    def test_dimension_vector_normalized(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        for dim_name in DIMENSIONS:
            sub = features.dimension_vector(dim_name)
            norm = np.linalg.norm(sub)
            if norm > 0:
                assert abs(norm - 1.0) < 1e-5

    def test_unknown_dimension_raises(self, sine_wav: Path) -> None:
        features = extract_features(str(sine_wav))
        with pytest.raises(ValueError, match="Unknown dimension"):
            features.dimension_vector("nonexistent")


class TestFeatureNames:
    def test_feature_names_count(self) -> None:
        assert len(FEATURE_NAMES) == VECTOR_DIM

    def test_feature_names_unique(self) -> None:
        assert len(set(FEATURE_NAMES)) == len(FEATURE_NAMES)

    def test_dimension_features_exist(self) -> None:
        for dim_name, dim_features in DIMENSIONS.items():
            for feat in dim_features:
                assert feat in FEATURE_NAMES, f"{feat} in dimension {dim_name} not found"
