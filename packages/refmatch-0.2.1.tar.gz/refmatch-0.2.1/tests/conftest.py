"""Test fixtures — synthetic audio generation for deterministic tests."""

import tempfile
from pathlib import Path

import numpy as np
import pytest
import soundfile as sf


@pytest.fixture
def tmp_dir():
    """Temporary directory for test files."""
    with tempfile.TemporaryDirectory() as d:
        yield Path(d)


@pytest.fixture
def sine_wav(tmp_dir: Path) -> Path:
    """Generate a 15-second 440Hz sine wave WAV file."""
    sr = 22050
    duration = 15.0
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    audio = 0.5 * np.sin(2 * np.pi * 440 * t).astype(np.float32)
    path = tmp_dir / "sine_440.wav"
    sf.write(str(path), audio, sr)
    return path


@pytest.fixture
def sine_880_wav(tmp_dir: Path) -> Path:
    """Generate a 15-second 880Hz sine wave WAV file."""
    sr = 22050
    duration = 15.0
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    audio = 0.5 * np.sin(2 * np.pi * 880 * t).astype(np.float32)
    path = tmp_dir / "sine_880.wav"
    sf.write(str(path), audio, sr)
    return path


@pytest.fixture
def short_wav(tmp_dir: Path) -> Path:
    """Generate a 3-second WAV file (too short for analysis)."""
    sr = 22050
    duration = 3.0
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    audio = 0.5 * np.sin(2 * np.pi * 440 * t).astype(np.float32)
    path = tmp_dir / "short.wav"
    sf.write(str(path), audio, sr)
    return path


@pytest.fixture
def noise_wav(tmp_dir: Path) -> Path:
    """Generate a 15-second white noise WAV file."""
    sr = 22050
    duration = 15.0
    rng = np.random.default_rng(42)
    audio = (rng.random(int(sr * duration)) * 2 - 1).astype(np.float32) * 0.3
    path = tmp_dir / "noise.wav"
    sf.write(str(path), audio, sr)
    return path


@pytest.fixture
def bass_wav(tmp_dir: Path) -> Path:
    """Generate a 15-second 80Hz bass tone WAV file."""
    sr = 22050
    duration = 15.0
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    audio = 0.5 * np.sin(2 * np.pi * 80 * t).astype(np.float32)
    path = tmp_dir / "bass_80.wav"
    sf.write(str(path), audio, sr)
    return path


@pytest.fixture
def db_path(tmp_dir: Path) -> Path:
    """Path for a temporary database."""
    return tmp_dir / "test.db"
