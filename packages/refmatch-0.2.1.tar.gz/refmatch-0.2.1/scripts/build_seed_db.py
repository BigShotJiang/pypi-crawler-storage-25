#!/usr/bin/env python3
"""Build the seed database from CC-licensed audio tracks.

Downloads tracks from Jamendo (CC-licensed) across genres,
extracts features, and creates the seed database bundle.

Usage:
    python scripts/build_seed_db.py --count 100 --output data/seed
"""

import argparse
import json
import tempfile
import urllib.request
from pathlib import Path

import numpy as np

from refmatch.features import extract_features

# Jamendo API (free, CC-licensed music, no auth needed for browsing)
JAMENDO_API = "https://api.jamendo.com/v3.0"
JAMENDO_CLIENT_ID = "2c9a11b9"  # Public client ID

GENRES = [
    "electronic",
    "hiphop",
    "rock",
    "pop",
    "jazz",
    "classical",
    "ambient",
    "metal",
    "rnb",
    "reggae",
    "folk",
    "blues",
    "techno",
    "house",
    "triphop",
    "drum+and+bass",
    "dubstep",
    "soul",
    "funk",
    "country",
    "latin",
    "world",
    "punk",
    "indie",
    "lofi",
]


def fetch_tracks(genre: str, limit: int = 10) -> list[dict]:
    """Fetch track metadata from Jamendo API."""
    url = (
        f"{JAMENDO_API}/tracks/?client_id={JAMENDO_CLIENT_ID}"
        f"&format=json&limit={limit}&fuzzytags={genre}"
        f"&include=musicinfo&audioformat=mp32"
        f"&order=popularity_total"
    )
    try:
        with urllib.request.urlopen(url, timeout=30) as resp:
            data = json.loads(resp.read())
            return data.get("results", [])
    except Exception as e:
        print(f"  Warning: Could not fetch {genre}: {e}")
        return []


def download_preview(url: str, dest: Path) -> bool:
    """Download audio preview to file."""
    try:
        urllib.request.urlretrieve(url, str(dest))
        return True
    except Exception as e:
        print(f"  Warning: Download failed: {e}")
        return False


def build_seed_database(count: int, output_dir: Path) -> None:
    """Build seed database from Jamendo CC tracks."""
    per_genre = max(1, count // len(GENRES))
    remainder = count - per_genre * len(GENRES)

    metadata = []
    vectors = []
    total = 0

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)

        for i, genre in enumerate(GENRES):
            n = per_genre + (1 if i < remainder else 0)
            print(f"\n[{genre}] Fetching {n} tracks...")
            tracks = fetch_tracks(genre, limit=n + 5)  # extra buffer

            added = 0
            for track in tracks:
                if added >= n:
                    break

                audio_url = track.get("audiodownload") or track.get("audio")
                if not audio_url:
                    continue

                name = track.get("name", "Unknown")
                artist = track.get("artist_name", "Unknown")
                track_id = track.get("id", "0")

                print(f"  [{total + 1}] {artist} — {name}...", end=" ", flush=True)

                audio_path = tmp / f"{track_id}.mp3"
                if not download_preview(audio_url, audio_path):
                    print("SKIP (download failed)")
                    continue

                try:
                    features = extract_features(str(audio_path))
                    metadata.append({
                        "id": total,
                        "title": name[:100],
                        "artist": artist[:100],
                        "genre": genre,
                        "bpm": round(features.bpm, 1),
                        "key": features.estimated_key,
                        "lufs": round(features.lufs, 1),
                        "dynamic_range": round(features.dynamic_range, 1),
                        "duration_sec": round(features.duration_sec, 1),
                        "brightness": round(features.brightness, 3),
                        "jamendo_id": track_id,
                        "license": track.get("license_ccurl", "CC"),
                    })
                    vectors.append(features.vector)
                    total += 1
                    added += 1
                    print("OK")
                except ValueError as e:
                    print(f"SKIP ({e})")
                except Exception as e:
                    print(f"SKIP (error: {e})")

                # Clean up temp file
                audio_path.unlink(missing_ok=True)

    print(f"\n{'=' * 50}")
    print(f"Total tracks processed: {total}")

    if total == 0:
        print("No tracks processed. Check your internet connection.")
        return

    # Save
    output_dir.mkdir(parents=True, exist_ok=True)

    with open(output_dir / "metadata.json", "w") as f:
        json.dump(metadata, f, indent=2)

    np.save(output_dir / "vectors.npy", np.stack(vectors))

    # Size info
    vec_size = (output_dir / "vectors.npy").stat().st_size
    meta_size = (output_dir / "metadata.json").stat().st_size
    print(f"Saved to {output_dir}/")
    print(f"  metadata.json: {meta_size / 1024:.1f} KB")
    print(f"  vectors.npy:   {vec_size / 1024:.1f} KB")
    print(f"  Total:         {(vec_size + meta_size) / 1024:.1f} KB")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Build RefMatch seed database")
    parser.add_argument(
        "--count", type=int, default=100,
        help="Total number of tracks to include (default: 100)",
    )
    parser.add_argument(
        "--output", type=str, default="data/seed",
        help="Output directory (default: data/seed)",
    )
    args = parser.parse_args()
    build_seed_database(args.count, Path(args.output))
