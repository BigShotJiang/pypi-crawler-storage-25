__version__ = "0.7.0"
MAGIC_NUMBER = 88


def get_magic_number() -> int:
    return MAGIC_NUMBER
