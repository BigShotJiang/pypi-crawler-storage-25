"""Optional Playwright-backed browser runtime for built-in browser tools."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any

from packages.contracts.runtime import ExecutionResult

from .runtime import ToolInvocation
from .surfaces import BrowserToolBackend


def create_playwright_browser_backend(*, headless: bool = True) -> tuple[BrowserToolBackend | None, str | None]:
    try:
        from playwright.sync_api import sync_playwright  # type: ignore import-not-found
    except Exception as exc:  # pragma: no cover - import availability depends on operator env
        return (None, f"Playwright backend is unavailable: {exc}")
    try:
        backend = PlaywrightBrowserBackend(sync_playwright=sync_playwright, headless=headless)
    except Exception as exc:  # pragma: no cover - launch availability depends on operator env
        return (None, f"Playwright backend could not start: {exc}")
    return (backend, None)


@dataclass(slots=True)
class PlaywrightBrowserBackend(BrowserToolBackend):
    sync_playwright: Any
    headless: bool = True
    _playwright: Any | None = None
    _browser: Any | None = None
    _page: Any | None = None
    _console_messages: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self._playwright = self.sync_playwright().start()
        self._browser = self._playwright.chromium.launch(headless=self.headless)
        page = self._browser.new_page()
        page.on("console", self._on_console)
        self._page = page

    def backend_label(self) -> str:
        return "playwright-sync"

    def invoke(self, action: str, invocation: ToolInvocation) -> Mapping[str, Any] | ExecutionResult:
        page = self._require_page()
        if action == "navigate":
            url = str(invocation.arguments.get("url") or "").strip()
            if not url:
                raise ValueError("tool.browser.navigate requires a 'url' argument")
            page.goto(url, wait_until="domcontentloaded", timeout=20_000)
            return self._summary(invocation, self._page_summary(page))
        if action == "snapshot":
            return self._summary(invocation, self._snapshot_summary(page))
        if action == "click":
            selector = str(invocation.arguments.get("selector") or "").strip()
            if not selector:
                raise ValueError("tool.browser.click requires a 'selector' argument")
            page.locator(selector).first.click(timeout=10_000)
            return self._summary(invocation, self._page_summary(page))
        if action == "type":
            selector = str(invocation.arguments.get("selector") or "").strip()
            text = str(invocation.arguments.get("text") or "")
            if not selector or not text:
                raise ValueError("tool.browser.type requires 'selector' and 'text'")
            locator = page.locator(selector).first
            locator.click(timeout=10_000)
            locator.fill(text, timeout=10_000)
            return self._summary(invocation, f"typed into {selector}\n{text}")
        if action == "scroll":
            amount = int(invocation.arguments.get("amount") or 800)
            page.mouse.wheel(0, amount)
            return self._summary(invocation, f"scrolled by {amount}px\n{self._page_summary(page)}")
        if action == "back":
            page.go_back(wait_until="domcontentloaded", timeout=20_000)
            return self._summary(invocation, self._page_summary(page))
        if action == "press":
            key = str(invocation.arguments.get("key") or "").strip()
            if not key:
                raise ValueError("tool.browser.press requires a 'key' argument")
            page.keyboard.press(key)
            return self._summary(invocation, f"pressed {key}\n{self._page_summary(page)}")
        if action == "images":
            return self._summary(invocation, self._images_summary(page))
        if action == "vision":
            prompt = str(invocation.arguments.get("prompt") or "").strip()
            lines = ["browser inspection", self._page_summary(page), self._snapshot_summary(page)]
            if prompt:
                lines.append(f"prompt: {prompt}")
            return self._summary(invocation, "\n".join(lines))
        if action == "console":
            lines = self._console_messages[-20:] or ["<empty>"]
            return self._summary(invocation, "\n".join(lines))
        raise ValueError(f"unsupported browser action: {action}")

    def _require_page(self):
        if self._page is None:
            raise RuntimeError("browser page is not available")
        return self._page

    def _on_console(self, message: Any) -> None:
        text = ""
        try:
            text = str(message.text)
        except Exception:  # pragma: no cover - defensive for adapter payloads
            text = str(message)
        self._console_messages.append(text)
        del self._console_messages[:-50]

    def _page_summary(self, page: Any) -> str:
        title = ""
        url = ""
        try:
            title = page.title()
        except Exception:
            title = ""
        try:
            url = page.url
        except Exception:
            url = ""
        lines = []
        if title:
            lines.append(title)
        if url:
            lines.append(f"source: {url}")
        return "\n".join(lines) or "browser page is ready"

    def _snapshot_summary(self, page: Any) -> str:
        try:
            body_text = page.locator("body").inner_text(timeout=10_000)
        except Exception:
            body_text = ""
        body_text = " ".join(body_text.split())
        body_text = body_text[:1600] + ("…" if len(body_text) > 1600 else "")
        lines = [self._page_summary(page)]
        if body_text:
            lines.append(body_text)
        return "\n".join(line for line in lines if line)

    def _images_summary(self, page: Any) -> str:
        records = page.evaluate(
            """
            () => Array.from(document.images).slice(0, 20).map((image, index) => ({
              index: index + 1,
              src: image.currentSrc || image.src || '',
              alt: image.alt || ''
            }))
            """
        )
        if not records:
            return "<empty>"
        lines = []
        for record in records:
            index = record.get("index", "?")
            src = str(record.get("src") or "")
            alt = str(record.get("alt") or "")
            suffix = f" | alt={alt}" if alt else ""
            lines.append(f"{index}. {src}{suffix}")
        return "\n".join(lines)

    def _summary(self, invocation: ToolInvocation, body: str) -> Mapping[str, Any]:
        return {
            "execution_id": invocation.invocation_id,
            "summary": body.strip() or "browser action completed",
            "outcome": "success",
            "side_effects": ("browser",),
        }

