"""Provider-neutral model adapter interfaces and baseline adapters."""

from .inventory import MODEL_SURFACES
from .provider_runtime import (
    InMemoryProviderManifestRegistry,
    InMemoryProviderTransportRegistry,
    ProviderCatalogRecord,
    ProviderManifest,
    ProviderManifestRegistry,
    ProviderRuntimeResolution,
    ProviderRuntimeResolver,
    ProviderSetupGuide,
    ProviderTransportDefinition,
    ProviderTransportRegistry,
)
from .runtime import (
    CredentialSource,
    InMemoryModelAdapterRegistry,
    ModelAdapter,
    ModelAdapterDescriptor,
    ModelEmbeddingResult,
    ModelRequest,
    ModelTextResult,
    ModelUsage,
    PreviewModelProviderCapability,
    PromptEchoModelAdapter,
    StaticTextModelAdapter,
)

__all__ = [
    "CredentialSource",
    "InMemoryProviderManifestRegistry",
    "InMemoryProviderTransportRegistry",
    "InMemoryModelAdapterRegistry",
    "MODEL_SURFACES",
    "ModelAdapter",
    "ModelAdapterDescriptor",
    "ModelEmbeddingResult",
    "ModelRequest",
    "ModelTextResult",
    "ModelUsage",
    "ProviderCatalogRecord",
    "ProviderManifest",
    "ProviderManifestRegistry",
    "ProviderRuntimeResolution",
    "ProviderRuntimeResolver",
    "ProviderSetupGuide",
    "ProviderTransportDefinition",
    "ProviderTransportRegistry",
    "PreviewModelProviderCapability",
    "PromptEchoModelAdapter",
    "StaticTextModelAdapter",
]
