"""Bounded downstream selection helpers for intent-ranked guardians and skills."""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import replace

from packages.contracts.runtime import ContextBundle, IntentDecision
from packages.skills import render_skill_overlay


def skill_definition_overlay_enabled(definition: object) -> bool:
    explicit = getattr(definition, "include_in_overlay", None)
    if explicit is not None:
        return _coerce_bool(explicit)
    metadata = getattr(definition, "metadata", {})
    if isinstance(metadata, Mapping):
        return _coerce_bool(metadata.get("include_in_overlay"))
    return False


def augment_context_with_intent_selection(
    *,
    context: ContextBundle,
    intent: IntentDecision,
    skill_definitions: Sequence[object],
    skill_activate: Callable[[str], object] | None = None,
) -> ContextBundle:
    guardian_lines, guardian_id = _guardian_overlay(intent)
    skill_lines, skill_id = _skill_overlay(
        intent=intent,
        skill_definitions=skill_definitions,
        skill_activate=skill_activate,
    )
    sections: list[str] = []
    artifact_ids = list(context.artifact_ids)
    if guardian_lines:
        if guardian_id:
            artifact_ids.append(f"guardian:{guardian_id}")
        sections.append("\n".join(guardian_lines))
    if skill_lines:
        if skill_id:
            artifact_ids.append(f"skill:{skill_id}")
        sections.append("\n".join(skill_lines))
    if not sections:
        return context
    rendered_prompt = (context.rendered_prompt or "").strip()
    overlay = "\n\n".join(sections)
    combined_prompt = overlay if not rendered_prompt else f"{rendered_prompt}\n\n{overlay}"
    return replace(
        context,
        bundle_id=f"{context.bundle_id}:intent-selection",
        artifact_ids=tuple(dict.fromkeys(artifact_ids)),
        prompt_envelope=context.prompt_envelope.append_turn_injection(overlay),
        rendered_prompt=combined_prompt,
    )


def _guardian_overlay(intent: IntentDecision) -> tuple[tuple[str, ...], str | None]:
    top_guardian = _top_candidate(intent, kind="guardian")
    if not _candidate_is_actionable(top_guardian):
        return (), None
    approval_classes = str(top_guardian.metadata.get("approval_classes", "")).strip()
    lines = [
        f"Selected guardian lane: {top_guardian.label} ({top_guardian.candidate_id})",
        "Keep tool choices and outbound actions aligned with this guarded surface unless the request clearly requires another lane.",
    ]
    if approval_classes:
        lines.append(f"Approval classes: {approval_classes}")
    return tuple(lines), top_guardian.candidate_id


def _skill_overlay(
    *,
    intent: IntentDecision,
    skill_definitions: Sequence[object],
    skill_activate: Callable[[str], object] | None = None,
) -> tuple[tuple[str, ...], str | None]:
    definition = _selected_skill_definition(intent=intent, skill_definitions=skill_definitions)
    if definition is None:
        return (), None
    skill_id = str(getattr(definition, "skill_id", "")).strip() or None
    if skill_id and skill_activate is not None:
        try:
            skill_activate(skill_id)
        except Exception:
            pass
    return render_skill_overlay(definition), skill_id


def _selected_skill_definition(
    *,
    intent: IntentDecision,
    skill_definitions: Sequence[object],
) -> object | None:
    top_skill = _top_candidate(intent, kind="skill")
    if not _candidate_is_actionable(top_skill):
        return None
    for definition in skill_definitions:
        if str(getattr(definition, "skill_id", "")).strip() != top_skill.candidate_id:
            continue
        if not skill_definition_overlay_enabled(definition):
            return None
        if not str(getattr(definition, "instruction_text", "")).strip():
            return None
        return definition
    return None


def _top_candidate(intent: IntentDecision, *, kind: str):
    for score in intent.candidate_scores:
        if score.kind == kind:
            return score
    return None


def _candidate_is_actionable(score, *, minimum_total_score: float = 0.25) -> bool:
    if score is None:
        return False
    return float(getattr(score, "total_score", 0.0)) >= minimum_total_score


def _coerce_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    normalized = str(value or "").strip().lower()
    if normalized in {"1", "true", "yes", "on"}:
        return True
    if normalized in {"0", "false", "no", "off"}:
        return False
    return False
