"""Static public SkillHub projection derived from the canonical skill catalog."""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any

from .builtins import builtin_skill_catalog
from .hub import SkillCatalogEntry

_CATALOG_HEADLINE = "Static public SkillHub for the bundled Aegis skill catalog."
_CATALOG_SUMMARY = (
    "SkillHub is the release-facing projection of the built-in procedural skills "
    "that ship with Aegis today. It reflects the packaged CLI truth without "
    "turning the public site into a hosted marketplace or runtime-backed search UI."
)
_BUILTIN_POSTURE = (
    "Every SkillHub entry here is bundled with the packaged Aegis CLI as a built-in "
    "procedural guide. There is no separate install step for these entries."
)
_CURATED_ORIGIN_POSTURE = (
    "Some bundled skills are Aegis-native curation of common operator patterns, "
    "but the shipped public truth is the Aegis-bundled catalog rather than an "
    "upstream marketplace listing."
)
_OPERATOR_INSTALL_POSTURE = (
    "Extra public skills remain explicit operator-owned installs after setup. "
    "Aegis can expose install references in the CLI, but SkillHub itself stays "
    "static and does not imply one-click hosted installs or model-owned search."
)


@dataclass(frozen=True, slots=True)
class SkillHubSiteEntry:
    skill_id: str
    slug: str
    display_name: str
    summary: str
    reference: str
    section_id: str
    section_display_name: str
    detail_doc_id: str
    detail_path: str
    source_id: str
    source_label: str
    source_kind: str
    storage_tier: str
    activation_mode: str
    activation_label: str
    default_enabled: bool
    default_enabled_label: str
    slash_command: str
    packaging_posture: str
    install_posture: str
    operator_install_posture: str
    aliases: tuple[str, ...] = ()
    trigger_phrases: tuple[str, ...] = ()
    keywords: tuple[str, ...] = ()
    platforms: tuple[str, ...] = ()
    requires_tools: tuple[str, ...] = ()
    requires_toolsets: tuple[str, ...] = ()
    required_environment_variables: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SkillHubSiteSection:
    section_id: str
    display_name: str
    summary: str
    entry_count: int
    entries: tuple[SkillHubSiteEntry, ...]


@dataclass(frozen=True, slots=True)
class SkillHubSiteCatalog:
    generated_at: str
    headline: str
    summary: str
    builtin_posture: str
    curated_origin_posture: str
    operator_install_posture: str
    stats: dict[str, int]
    sections: tuple[SkillHubSiteSection, ...]
    entries: tuple[SkillHubSiteEntry, ...]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=False)


def build_skillhub_site_catalog(*, root: Path | None = None) -> SkillHubSiteCatalog:
    builtin_catalog = builtin_skill_catalog(root=root)
    section_membership: dict[str, tuple[str, str]] = {}
    for section in builtin_catalog.sections:
        for entry in section.entries:
            if entry.visibility.include_in_site:
                section_membership[entry.skill_id] = (section.section_id, section.display_name)
    entries = [
        _site_entry_for_catalog_entry(
            entry,
            section_id=section_membership[entry.skill_id][0],
            section_display_name=section_membership[entry.skill_id][1],
        )
        for entry in builtin_catalog.site_entries()
    ]
    entries_by_id = {entry.skill_id: entry for entry in entries}
    sections: list[SkillHubSiteSection] = []
    for section in builtin_catalog.sections:
        section_entries = tuple(
            entries_by_id[entry.skill_id]
            for entry in section.entries
            if entry.visibility.include_in_site
        )
        if not section_entries:
            continue
        sections.append(
            SkillHubSiteSection(
                section_id=section.section_id,
                display_name=section.display_name,
                summary=section.summary,
                entry_count=len(section_entries),
                entries=section_entries,
            )
        )
    entry_count = len(entries)
    return SkillHubSiteCatalog(
        generated_at=_utc_timestamp(),
        headline=_CATALOG_HEADLINE,
        summary=_CATALOG_SUMMARY,
        builtin_posture=_BUILTIN_POSTURE,
        curated_origin_posture=_CURATED_ORIGIN_POSTURE,
        operator_install_posture=_OPERATOR_INSTALL_POSTURE,
        stats={
            "entry_count": entry_count,
            "section_count": len(sections),
            "always_on_count": sum(1 for entry in entries if entry.activation_mode == "always-on"),
            "on_demand_count": sum(1 for entry in entries if entry.activation_mode == "on-demand"),
            "default_enabled_count": sum(1 for entry in entries if entry.default_enabled),
        },
        sections=tuple(sections),
        entries=tuple(entries),
    )


def _site_entry_for_catalog_entry(
    entry: SkillCatalogEntry,
    *,
    section_id: str,
    section_display_name: str,
) -> SkillHubSiteEntry:
    slug = entry.skill_id
    detail_doc_id = f"skillhub/library/{slug}"
    detail_path = f"/docs/skillhub/library/{slug}/"
    slash_command = str(entry.metadata.get("slash_command") or entry.skill_id).strip()
    return SkillHubSiteEntry(
        skill_id=entry.skill_id,
        slug=slug,
        display_name=entry.display_name,
        summary=entry.summary,
        reference=entry.reference,
        section_id=section_id,
        section_display_name=section_display_name,
        detail_doc_id=detail_doc_id,
        detail_path=detail_path,
        source_id=entry.source_id,
        source_label=entry.source_label,
        source_kind=entry.source_kind,
        storage_tier=entry.storage_tier,
        activation_mode=entry.activation_mode,
        activation_label=_activation_label(entry.activation_mode),
        default_enabled=entry.default_enabled,
        default_enabled_label=_default_enabled_label(entry.default_enabled),
        slash_command=f"/{slash_command}",
        packaging_posture=_packaging_posture(entry),
        install_posture=_install_posture(entry),
        operator_install_posture=_OPERATOR_INSTALL_POSTURE,
        aliases=_metadata_strings(entry.metadata, "aliases"),
        trigger_phrases=_metadata_strings(entry.metadata, "trigger_phrases"),
        keywords=_metadata_strings(entry.metadata, "keywords"),
        platforms=_metadata_strings(entry.metadata, "platforms"),
        requires_tools=_metadata_strings(entry.metadata, "requires_tools"),
        requires_toolsets=_metadata_strings(entry.metadata, "requires_toolsets"),
        required_environment_variables=_metadata_strings(
            entry.metadata,
            "required_environment_variables",
        ),
    )


def _metadata_strings(metadata: dict[str, Any] | Any, key: str) -> tuple[str, ...]:
    raw = metadata.get(key) if isinstance(metadata, dict) else None
    if isinstance(raw, (tuple, list, set)):
        return tuple(str(item).strip() for item in raw if str(item).strip())
    if raw is None:
        return ()
    value = str(raw).strip()
    return (value,) if value else ()


def _activation_label(activation_mode: str) -> str:
    return "Always on" if activation_mode == "always-on" else "On demand"


def _default_enabled_label(default_enabled: bool) -> str:
    return "Enabled by default" if default_enabled else "Available when invoked"


def _packaging_posture(entry: SkillCatalogEntry) -> str:
    if entry.source_id == "builtin":
        return "Bundled with the packaged Aegis CLI as a built-in procedural skill."
    return "Published from the canonical skill catalog for static site consumption."


def _install_posture(entry: SkillCatalogEntry) -> str:
    if entry.source_id == "builtin":
        return (
            "No separate install step. This skill already ships inside the public "
            "Aegis bundle."
        )
    return "Installed separately by the operator through explicit CLI flows."


def _utc_timestamp() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--format", choices=("json",), default="json")
    args = parser.parse_args(argv)
    catalog = build_skillhub_site_catalog()
    if args.format == "json":
        print(catalog.to_json())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
