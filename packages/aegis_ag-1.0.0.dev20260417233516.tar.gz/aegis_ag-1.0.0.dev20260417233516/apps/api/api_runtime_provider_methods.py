"""Provider methods for the API runtime app."""


from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
import json
from typing import Any, Mapping
from uuid import uuid4

from apps.provider_runtime import (
    SurfaceModelProviderCapability,
    provider_selection_from_payload,
)
from packages.auth import AuthProfile, PersistentAuthProfileStore
from packages.context import ContextRuntime
from packages.contracts import ContextBundle, EventEnvelope, ExecutionResult, GoalNode, MemoryRecord, ProfileState, SessionState, ActivityGraph
from packages.kernel import KernelDependencies, KernelOutcome, KernelService, KernelTurnRequest, ObservationPipeline, StateReconciler
from packages.learning import LearningRuntime
from packages.evidence import MemoryRuntime
from packages.operator import (
    MemoryOperatorDetail,
    MemorySearchHit,
    ProcedureOperatorDetail,
    build_audit_surface,
    build_memory_operator_surface,
    build_procedure_operator_surface,
    build_profile_operator_surface,
    build_activity_operator_surface,
    library_procedure_overlays,
)
from packages.planning import PlanningService
from packages.session import SessionLineageService, SessionResumeResult
from packages.storage import RuntimeStorageRepository
from packages.tools import BuiltinToolDependencies, build_tool_runtime
from packages.tools.adapters import DeliveryMessageSurfaceAdapter, StructuredClarifySurface
from packages.tools.browser_backend import create_playwright_browser_backend

from .capabilities import (
    APIContextCapability,
    APIDeliveryCapability,
    APIMemoryCapability,
    APIModelProvider,
    APIPlanningCapability,
    APITelemetrySink,
    APIToolExecution,
)
from .state_runtime import APIContinuityInspection, APIStateService
from .tool_surfaces import APIMemoryManagementSurface

from .api_runtime_support import (
    APIAppConfig,
    APIResponse,
    APISessionCreationResult,
    APISessionInspection,
    APIResumeResult,
    APITurnRecord,
    APITurnResult,
    _coerce_str_tuple,
    _json_bytes,
    _jsonable,
    _now,
    _optional_bool,
    _optional_datetime,
    _optional_str,
    _read_json_bytes,
    _split_path,
)

def list_providers(self) -> dict[str, Any]:
    return {
        "active_provider": self.model_provider.describe(),
        "providers": [record.as_mapping() for record in self.model_provider.runtime_resolver.list_catalog()],
    }

def setup_provider(self, provider_id: str) -> dict[str, Any]:
    guide = self.model_provider.runtime_resolver.build_setup_guide(provider_id)
    return {
        "active_provider": self.model_provider.describe(),
        "guide": guide.as_mapping(),
    }

def _selection_profiles_from_payload(provider_profile: Mapping[str, Any]) -> tuple[AuthProfile, AuthProfile, str]:
    selection = provider_selection_from_payload(provider_profile)
    strong_profile = selection.strong_profile
    weak_profile = selection.weak_profile
    if strong_profile is None or weak_profile is None:
        raise ValueError("provider_profile must include strong_profile and weak_profile objects")
    return (
        strong_profile,
        weak_profile,
        selection.intent_mode,
    )


def set_default_provider(self, provider_profile: Mapping[str, Any]) -> dict[str, Any]:
    strong_profile, weak_profile, intent_mode = _selection_profiles_from_payload(provider_profile)
    self.auth_store.register(strong_profile)
    self.auth_store.register(weak_profile)
    self.model_provider.set_active_profiles(
        strong_provider_profile_id=strong_profile.profile_id,
        weak_provider_profile_id=weak_profile.profile_id,
        provider_id=strong_profile.provider_id,
        intent_mode=intent_mode,
    )
    return {
        "provider_profiles": {
            "strong": strong_profile,
            "weak": weak_profile,
            "intent_mode": intent_mode,
        },
        "active_provider": self.model_provider.describe(),
    }

def _provider_probe(
    self,
    *,
    prompt: str,
) -> ExecutionResult:
    active_profile = self.model_provider.active_profile()
    profile = ProfileState(
        profile_id=f"provider-test:{active_profile.provider_id if active_profile is not None else 'preview'}",
        display_name=active_profile.provider_id if active_profile is not None else "Provider Test",
        mode="default",
    )
    session = SessionState(
        session_id=f"session:provider-test:{uuid4().hex[:8]}",
        profile_id=profile.profile_id,
        workspace_id="provider-test",
        status="active",
        started_at=_now(),
        updated_at=_now(),
    )
    context = ContextBundle(
        bundle_id=f"bundle:provider-test:{uuid4().hex[:8]}",
        session_id=session.session_id,
        instruction_refs=("apps/api",),
        goal_ids=(),
        memory_ids=(),
        artifact_ids=(),
        token_budget=512,
        rendered_prompt="provider test",
    )
    return self.model_provider.generate(
        profile=profile,
        session=session,
        context=context,
        prompt=prompt,
    )

def test_provider(self, *, prompt: str = "Summarize the current provider configuration.") -> dict[str, Any]:
    active_provider = self.model_provider.describe()
    try:
        result = self._provider_probe(prompt=prompt)
    except Exception as error:  # pragma: no cover - defensive surface guard
        return {
            "active_provider": active_provider,
            "status": "not-ready",
            "error": str(error),
        }
    return {
        "active_provider": active_provider,
        "status": "ok",
        "result": result,
    }

def doctor_provider(self) -> dict[str, Any]:
    active_provider = self.model_provider.describe()
    bootstrap_check = {
        "check": "embedding_bootstrap",
        "status": str(active_provider.get("embedding_bootstrap_status") or "unknown"),
        "summary": str(active_provider.get("embedding_bootstrap_summary") or ""),
    }
    if active_provider["source"] != "configured":
        return {
            "status": "preview",
            "active_provider": active_provider,
            "checks": (
                {"check": "provider_profile", "status": "missing"},
                {"check": "credentials", "status": "preview"},
                bootstrap_check,
            ),
            "probe_summary": "",
        }
    try:
        probe = self._provider_probe(prompt="Doctor check")
    except Exception as error:  # pragma: no cover - defensive surface guard
        return {
            "status": "not-ready",
            "active_provider": active_provider,
            "checks": (
                {"check": "provider_profile", "status": "configured"},
                {"check": "credentials", "status": "missing", "summary": str(error)},
                bootstrap_check,
            ),
            "probe_summary": "",
        }
    return {
        "status": "ready",
        "active_provider": active_provider,
        "checks": (
            {"check": "provider_profile", "status": "configured"},
            {"check": "credentials", "status": "available"},
            bootstrap_check,
            {"check": "runtime", "status": "ok", "summary": probe.summary},
        ),
        "probe_summary": probe.summary,
    }
