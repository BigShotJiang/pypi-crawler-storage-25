from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as package_version
from pathlib import Path
import re

from .shell_stack import RICH_AVAILABLE, Text, rich_cell_len

BRAND_ACCENT = "#d5ac89"
BRAND_ACCENT_STRONG = "#f0b56e"
BRAND_LIGHT = "#ece7de"
BRAND_MUTED = "#93a1b6"
BRAND_DARK = "#202736"
LIVE_DIFF_FILE_FG = "#f7c48e"
LIVE_DIFF_HUNK_FG = "#ffd07a"
LIVE_DIFF_ADD_FG = "#8ff0aa"
LIVE_DIFF_REMOVE_FG = "#ff9f8f"
LIVE_DIFF_CONTEXT_FG = "#c9d2de"
SETTLED_DIFF_FILE_FG = "#bd926d"
SETTLED_DIFF_HUNK_FG = "#c29a67"
SETTLED_DIFF_ADD_FG = "#5c9a70"
SETTLED_DIFF_REMOVE_FG = "#aa6c63"
SETTLED_DIFF_CONTEXT_FG = "#7d8798"
COMMAND_PALETTE_VISIBLE_ROWS = 6
USER_HISTORY_BG = "#454649"
USER_HISTORY_FG = "#f2efe8"
SHELL_WELCOME_HEADLINE = "Here with you, built to stay."
STARTUP_SEQUENCE_STEP_DELAY = 0.60
STARTUP_SEQUENCE_FINAL_DELAY = 0.60
GROWTH_PROGRESS_WIDTH = 14
GROWTH_PROGRESS_FILLED = "▰"
GROWTH_PROGRESS_EMPTY = "▱"
GROWTH_HIGHLIGHT_FG = BRAND_ACCENT_STRONG
QUEUE_PREVIEW_INSET = 3
MARKDOWN_BOLD_PATTERN = re.compile(r"\*\*(.+?)\*\*")
WEB_URL_PATTERN = re.compile(r"(https?://[^\s]+)", re.IGNORECASE)
EXPERIENCE_NOISE_PATTERN = re.compile(
    r"^(?:it looks like|i couldn't|i could not|sorry|tool failed\b|unable to\b)",
    re.IGNORECASE,
)
GROWTH_LEVEL_PATTERN = re.compile(r"\bLv\.\d+\b")
GROWTH_META_PATTERN = re.compile(r"\b(level-up|stage-shift)\b")
# SVG-derived pixel rows. Growth-stage marks stay on the canonical 24-cell
# horizontal canvas from the source brand assets so left/right geometry does not
# drift from row-parity mismatches.
GUARDIAN_HEAD_ROWS = (
    "          kggk          ",
    "        kcccccck        ",
    "       kcccccccck       ",
    "      kcccmmmmccck      ",
    "      kccmmmmmmcck      ",
    "      kccmttttmcck      ",
    "      kcctxttxtcck      ",
    "      kccttxxttcck      ",
)
EGG_STAGE_ROWS = (
    "          kkkk          ",
    "         kcccck         ",
    "        kcccccck        ",
    "       kcccccccck       ",
    "      kcccccccccck      ",
    "      kcccccccccck      ",
    "     kcccccccccccck     ",
    "     kcccccccccccck     ",
    "     kcccccccccccck     ",
    "     kcccccccccccck     ",
    "      kcccccccccck      ",
    "      kcccccccccck      ",
    "       kkcccccckk       ",
    "         kkkkkk         ",
)
SEED_STAGE_ROWS = (
    "           gg           ",
    "          kkkk          ",
    "         kcccck         ",
    "        kcccccck        ",
    "        kcttttck        ",
    "        kcxttxck        ",
    "        k cccc k        ",
    "         kkcckk         ",
    "          kggk          ",
    "           kk           ",
)
HATCHLING_STAGE_ROWS = (
    "          kggk          ",
    "        kcccccck        ",
    "       kccmmmmcck       ",
    "      kcccccccccck      ",
    "      kcctxttxtcck      ",
    "      kccttxxttcck      ",
    "      kcc tttt cck      ",
    "      k cccccccc k      ",
    "       kk      kk       ",
    "        kkkkkkkk        ",
    "         kkkkkk         ",
    "         mtggtm         ",
    "          tggt          ",
    "          k  k          ",
    "          k  k          ",
    "         kkkkkk         ",
)
SCOUT_STAGE_ROWS = (
    "          kggk          ",
    "        kcccccck        ",
    "       kcccccccck       ",
    "      kcccmmmmccck      ",
    "      kccmmmmmmcck      ",
    "      kcctxttxtcck      ",
    "      kccttxxttcck      ",
    "      k ccttttcc k      ",
    "        kkkkkkkk        ",
    "       kkkkkkkkkk       ",
    "        kcmmmmck        ",
    "        kctggtck        ",
    "        kctggtck        ",
    "        kccttcck        ",
    "        kkmmmmkk        ",
    "         kk  kk         ",
    "         kk  kk         ",
    "        kkk  kkk        ",
)
GUARDIAN_STAGE_ROWS = (
    "          kggk          ",
    "        kcccccck        ",
    "       kcccccccck       ",
    "      kcccmmmmccck      ",
    "      kccmmmmmmcck      ",
    "      kccmttttmcck      ",
    "      kcctxttxtcck      ",
    "      kccttxxttcck      ",
    "      k ccttttcc k      ",
    "       kkccxxcckk       ",
    "        kkkkkkkk        ",
    "       kkkkkkkkkk       ",
    "      kccmmmmmmcck      ",
    "     kkccmttttmcckk     ",
    "     kkcmttggttmckk     ",
    "      kcmttggttmck      ",
    "      k  mttttm  k      ",
    "       kccmggmcck       ",
    "        ccm  mcc        ",
    "        ccm  mcc        ",
    "        ccm  mcc        ",
    "       kcck  kcck       ",
)
GROWTH_STAGE_ROWS = {
    "seed": SEED_STAGE_ROWS,
    "hatchling": HATCHLING_STAGE_ROWS,
    "scout": SCOUT_STAGE_ROWS,
    "guardian": GUARDIAN_STAGE_ROWS,
}


def display_path(path: Path) -> str:
    home = Path.home()
    try:
        return f"~/{path.relative_to(home)}"
    except ValueError:
        return str(path)


def display_width(content: str) -> int:
    if RICH_AVAILABLE:
        return rich_cell_len(content)
    return len(content)


def compact_line(value: str, *, limit: int) -> str:
    compact = " ".join(value.split()).strip()
    if len(compact) <= limit:
        return compact
    return compact[: max(0, limit - 3)].rstrip() + "..."


def render_guardian_mark():
    return _render_pixel_mark(centered_rows(GUARDIAN_HEAD_ROWS), fallback="[Aegis guardian]")


def render_growth_mark(stage_id: str, *, level: int | None = None):
    rows = _growth_rows(stage_id, level=level)
    fallback = "[Aegis egg]" if stage_id == "seed" and (level or 0) <= 0 else f"[Aegis {stage_id}]"
    return _render_pixel_mark(rows, fallback=fallback)


def centered_guardian_rows() -> tuple[str, ...]:
    return centered_rows(GUARDIAN_HEAD_ROWS)


def centered_rows(rows: tuple[str, ...], *, width: int | None = None) -> tuple[str, ...]:
    resolved_width = width or max(len(row) for row in rows)
    centered: list[str] = []
    for row in rows:
        padding = resolved_width - len(row)
        left = padding // 2
        right = padding - left
        centered.append((" " * left) + row + (" " * right))
    return tuple(centered)


def resolve_aegis_version() -> str:
    try:
        return package_version("aegis-ag")
    except PackageNotFoundError:
        pyproject = Path(__file__).resolve().parents[2] / "pyproject.toml"
        if pyproject.exists():
            for raw in pyproject.read_text(encoding="utf-8").splitlines():
                stripped = raw.strip()
                if stripped.startswith("version = "):
                    return stripped.split("=", 1)[1].strip().strip('"')
        return "dev"


def strip_markdown_bold(text: str) -> str:
    return MARKDOWN_BOLD_PATTERN.sub(lambda match: match.group(1), text)


def render_markdown_bold(text: str, *, base_style: str) -> Text:
    rendered = Text()
    cursor = 0
    for match in MARKDOWN_BOLD_PATTERN.finditer(text):
        if match.start() > cursor:
            rendered.append(text[cursor : match.start()], style=base_style)
        rendered.append(match.group(1), style=f"bold {base_style}")
        cursor = match.end()
    if cursor < len(text):
        rendered.append(text[cursor:], style=base_style)
    if not text:
        rendered.append("", style=base_style)
    return rendered


def render_highlighted_history_line(
    text: str,
    *,
    base_style: str,
    highlight_pattern: re.Pattern[str],
    highlight_style: str,
) -> Text:
    rendered = Text(text, style=base_style)
    for match in highlight_pattern.finditer(text):
        rendered.stylize(highlight_style, match.start(), match.end())
    return rendered


def _growth_rows(stage_id: str, *, level: int | None = None) -> tuple[str, ...]:
    if stage_id == "seed" and (level or 0) <= 0:
        return EGG_STAGE_ROWS
    return GROWTH_STAGE_ROWS.get(stage_id, GUARDIAN_STAGE_ROWS)


def _render_pixel_mark(rows: tuple[str, ...], *, fallback: str):
    if not RICH_AVAILABLE:
        return Text(fallback)
    palette = {
        "g": BRAND_ACCENT_STRONG,
        "c": "#e8e1d6",
        "t": BRAND_ACCENT,
        "m": BRAND_MUTED,
        "k": "#13161c",
        "x": "#08090c",
        " ": None,
    }
    glyph = Text(no_wrap=True)
    for row_index, row in enumerate(rows):
        for cell in row:
            color = palette.get(cell)
            if color is None:
                glyph.append("  ")
            else:
                glyph.append("██", style=color)
        if row_index < len(rows) - 1:
            glyph.append("\n")
    return glyph
