from __future__ import annotations

import datetime
import sqlite3
import time
from pathlib import Path
from typing import Any

# Metric kind mapping matching SomaShared/HealthMetric.swift
METRIC_KINDS: dict[str, str] = {
    # Hourly cumulative stats
    "steps": "hourlyStat",
    "active_calories": "hourlyStat",
    "basal_calories": "hourlyStat",
    "distance_walking": "hourlyStat",
    "distance_cycling": "hourlyStat",
    "distance_swimming": "hourlyStat",
    "workout_minutes": "hourlyStat",
    "flights_climbed": "hourlyStat",
    "dietary_energy": "hourlyStat",
    "dietary_water": "hourlyStat",
    "dietary_caffeine": "hourlyStat",
    "dietary_protein": "hourlyStat",
    "dietary_carbs": "hourlyStat",
    "dietary_fat": "hourlyStat",
    "dietary_fiber": "hourlyStat",
    "dietary_sugar": "hourlyStat",
    "dietary_sodium": "hourlyStat",
    # Daily snapshots (category-based)
    "stand_hours": "dailySnapshot",
    "sleep_duration": "dailySnapshot",
    # Sample events
    "heart_rate": "sampleEvent",
    "resting_heart_rate": "sampleEvent",
    "walking_heart_rate_avg": "sampleEvent",
    "blood_oxygen": "sampleEvent",
    "respiratory_rate": "sampleEvent",
    "body_mass": "sampleEvent",
    "body_fat_percentage": "sampleEvent",
    "bmi": "sampleEvent",
    "lean_body_mass": "sampleEvent",
    "height": "sampleEvent",
    "waist_circumference": "sampleEvent",
    "hrv": "sampleEvent",
    "vo2_max": "sampleEvent",
    "body_temperature": "sampleEvent",
    "wrist_temperature": "sampleEvent",
    "blood_pressure_systolic": "sampleEvent",
    "blood_pressure_diastolic": "sampleEvent",
    "blood_glucose": "sampleEvent",
    "environmental_audio": "sampleEvent",
    "walking_steadiness": "sampleEvent",
    # Category events
    "mindful_session": "categoryEvent",
    "low_heart_rate_event": "categoryEvent",
    "high_heart_rate_event": "categoryEvent",
    "irregular_rhythm_event": "categoryEvent",
    "headache": "categoryEvent",
    "fatigue": "categoryEvent",
    "nausea": "categoryEvent",
    "menstrual_flow": "categoryEvent",
    "cervical_mucus": "categoryEvent",
    "ovulation_test": "categoryEvent",
    "sexual_activity": "categoryEvent",
    # Activity
    "user_activity": "activityEvent",
}

# Staleness thresholds in seconds
STALE_THRESHOLDS: dict[str, int] = {
    "location": 600,
    "heart_rate": 600,
    "resting_heart_rate": 3600,
    "blood_oxygen": 3600,
    "respiratory_rate": 3600,
    "body_mass": 86400,
    "hrv": 3600,
    "vo2_max": 86400,
    "activity": 300,
    "dailySnapshot": 86400,
    "hourlyStat": 7200,
    "categoryEvent": 86400,
    "workout": 86400,
}

ACTIVITY_LABELS: dict[int, str] = {
    0: "Stationary",
    1: "Walking",
    2: "Running",
    3: "Automotive",
    4: "Cycling",
    5: "Unknown",
}

HOURLY_METRICS: tuple[str, ...] = tuple(
    metric for metric, kind in METRIC_KINDS.items() if kind == "hourlyStat"
)
DAILY_SNAPSHOT_METRICS: tuple[str, ...] = tuple(
    metric for metric, kind in METRIC_KINDS.items() if kind == "dailySnapshot"
)


class SomaStore:
    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path).expanduser()

    def database_status(self) -> dict[str, Any]:
        return {
            "path": str(self.db_path),
            "exists": self.db_path.exists(),
        }

    def get_user_location(self) -> dict[str, Any]:
        sql = """
        SELECT
            latitude, longitude, altitude, accuracy, address,
            recorded_at, updated_at
        FROM location_current
        WHERE id = 1
        """
        rows = self._query(sql)
        if not rows:
            return self._unavailable("No replicated location is available yet.")
        row = rows[0]
        return self._add_freshness(row, "recorded_at", "location")

    def get_location_history(self, since: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        sql = """
        SELECT
            source_event_id, latitude, longitude, altitude, accuracy,
            address, recorded_at
        FROM location_history
        """
        params: list[Any] = []
        if since:
            sql += " WHERE recorded_at >= ?"
            params.append(since)
        sql += " ORDER BY recorded_at DESC"
        rows = self._query(sql, params=params, limit=limit)
        return [self._add_freshness(r, "recorded_at", "location") for r in rows]

    def get_health_metrics_list(self) -> list[dict[str, Any]]:
        # Sample metrics from health_latest
        sample_sql = """
        SELECT metric, value, unit, recorded_at, updated_at
        FROM health_latest
        ORDER BY metric ASC
        """
        sample_rows = self._query(sample_sql)

        # Most recent daily snapshot per metric
        snapshot_sql = """
        SELECT h.metric, h.date, h.snapshot_value as value, h.unit, h.recorded_at, h.updated_at
        FROM health_daily h
        INNER JOIN (
            SELECT metric, MAX(date) as max_date
            FROM health_daily
            WHERE aggregation_kind = 'snapshot' AND metric IN ({placeholders})
            GROUP BY metric
        ) latest ON h.metric = latest.metric AND h.date = latest.max_date
        WHERE h.aggregation_kind = 'snapshot' AND h.metric IN ({placeholders})
        ORDER BY h.metric ASC
        """
        snapshot_placeholders = ", ".join("?" for _ in DAILY_SNAPSHOT_METRICS)
        snapshot_rows = self._query(
            snapshot_sql.format(placeholders=snapshot_placeholders),
            params=list(DAILY_SNAPSHOT_METRICS) + list(DAILY_SNAPSHOT_METRICS),
        )

        hourly_rows = self._latest_hourly_metric_rows()

        results = []
        for row in sample_rows:
            row["kind"] = METRIC_KINDS.get(row.get("metric", ""), "sampleEvent")
            results.append(self._add_freshness(row, "recorded_at", row.get("metric", "")))
        for row in snapshot_rows:
            row["kind"] = "dailySnapshot"
            results.append(self._add_freshness(row, "recorded_at", "dailySnapshot"))
        for row in hourly_rows:
            row["kind"] = "hourlyStat"
            results.append(self._add_freshness(row, "recorded_at", "hourlyStat"))
        return results

    def get_health_metric(
        self,
        metric: str,
        since: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        kind = METRIC_KINDS.get(metric, "sampleEvent")

        if kind == "hourlyStat":
            rows = self._query_hourly_metric(metric=metric, since=since, limit=limit)
            return [self._add_freshness(r, "recorded_at", "hourlyStat") for r in rows]
        elif kind == "dailySnapshot":
            sql = """
            SELECT metric, date, snapshot_value as value, unit, recorded_at, updated_at
            FROM health_daily
            WHERE metric = ? AND aggregation_kind = 'snapshot'
            """
            params: list[Any] = [metric]
            if since:
                sql += " AND date >= ?"
                params.append(since)
            sql += " ORDER BY date DESC"
            rows = self._query(sql, params=params, limit=limit)
            return [self._add_freshness(r, "recorded_at", "dailySnapshot") for r in rows]
        elif kind == "activityEvent":
            sql = """
            SELECT activity_code, start_at, end_at
            FROM activity_samples
            """
            params = []
            if since:
                sql += " WHERE start_at >= ?"
                params.append(since)
            sql += " ORDER BY start_at DESC"
            rows = self._query(sql, params=params, limit=limit)
            results = []
            for row in rows:
                code = row.get("activity_code", 5)
                row["activity_label"] = ACTIVITY_LABELS.get(code, "Unknown")
                results.append(self._add_freshness(row, "start_at", "activity"))
            return results
        else:
            sql = """
            SELECT metric, value, unit, start_at, end_at
            FROM health_samples
            WHERE metric = ?
            """
            params = [metric]
            if since:
                sql += " AND start_at >= ?"
                params.append(since)
            sql += " ORDER BY start_at DESC"
            rows = self._query(sql, params=params, limit=limit)
            return [self._add_freshness(r, "start_at", metric) for r in rows]

    def get_health_summary(self) -> dict[str, Any]:
        metrics = self.get_health_metrics_list()
        return {
            "latest_metrics": metrics,
            "activity": self.get_user_activity(),
            "database": self.database_status(),
        }

    def get_user_activity(self) -> dict[str, Any]:
        sql = """
        SELECT activity_code, start_at, end_at, updated_at
        FROM activity_current
        WHERE id = 1
        """
        rows = self._query(sql)
        if not rows:
            return self._unavailable("No activity projection is available yet.")
        row = rows[0]
        code = row.get("activity_code", 5)
        label = ACTIVITY_LABELS.get(code, "Unknown")
        row["activity_label"] = label
        return self._add_freshness(row, "start_at", "activity")

    def get_daily_summary(self, date: str | None = None) -> dict[str, Any]:
        if date is None:
            date = datetime.date.today().isoformat()

        base_sql = """
        SELECT
            metric, date, aggregation_kind, unit,
            snapshot_value, sum_value, avg_value, min_value, max_value,
            count, recorded_at, updated_at
        FROM health_daily
        WHERE date = ? AND metric NOT IN ({placeholders})
        ORDER BY metric ASC
        """
        hourly_placeholders = ", ".join("?" for _ in HOURLY_METRICS)
        metrics = self._query(
            base_sql.format(placeholders=hourly_placeholders),
            params=[date, *HOURLY_METRICS],
        )
        metrics.extend(self._daily_hourly_summary_rows(date))
        metrics.sort(key=lambda row: str(row.get("metric", "")))
        return {
            "date": date,
            "metrics": [self._add_freshness(r, "recorded_at", "dailySnapshot") for r in metrics],
        }

    def get_workouts(self, since: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        if not self._table_exists("workout_sessions"):
            return []

        sql = """
        SELECT
            workout_id, activity_type, activity_label,
            start_at, end_at, duration,
            total_distance, total_energy_burned
        FROM workout_sessions
        """
        params: list[Any] = []
        if since:
            sql += " WHERE start_at >= ?"
            params.append(since)
        sql += " ORDER BY start_at DESC"
        rows = self._query(sql, params=params, limit=limit)
        return [self._add_freshness(r, "start_at", "workout") for r in rows]

    def query_sensor_data(self, sql: str, limit: int = 100) -> list[dict[str, Any]]:
        normalized = sql.strip().lower()
        if not normalized.startswith("select") and not normalized.startswith("with"):
            raise ValueError("Only read-only SELECT queries are allowed.")
        if ";" in normalized.rstrip(";"):
            raise ValueError("Only a single SQL statement is allowed.")
        return self._query(sql, limit=limit)

    def _query(
        self,
        sql: str,
        params: list[Any] | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        if not self.db_path.exists():
            return []

        statement = sql.strip()
        if limit is not None:
            clamped = max(1, min(int(limit), 500))
            statement = f"{statement}\nLIMIT {clamped}"

        # Open read-only to enforce MCP read-only contract.
        # WAL mode is set by the Mac writer app, not the reader.
        uri = f"file:{self.db_path}?mode=ro"
        with sqlite3.connect(uri, uri=True) as connection:
            connection.row_factory = sqlite3.Row
            cursor = connection.execute(statement, params or [])
            return [dict(row) for row in cursor.fetchall()]

    def _table_exists(self, table: str) -> bool:
        rows = self._query(
            "SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?",
            params=[table],
        )
        return bool(rows)

    def _latest_hourly_metric_rows(self) -> list[dict[str, Any]]:
        if self._table_exists("health_hourly"):
            sql = """
            SELECT metric, date, SUM(value) as value, unit, MAX(recorded_at) as recorded_at
            FROM health_hourly
            WHERE date = (SELECT MAX(date) FROM health_hourly h2 WHERE h2.metric = health_hourly.metric)
            GROUP BY metric
            ORDER BY metric ASC
            """
            return self._query(sql)

        placeholders = ", ".join("?" for _ in HOURLY_METRICS)
        sql = f"""
        SELECT h.metric, h.date, h.snapshot_value as value, h.unit, h.recorded_at
        FROM health_daily h
        INNER JOIN (
            SELECT metric, MAX(date) as max_date
            FROM health_daily
            WHERE aggregation_kind = 'snapshot' AND metric IN ({placeholders})
            GROUP BY metric
        ) latest ON h.metric = latest.metric AND h.date = latest.max_date
        WHERE h.aggregation_kind = 'snapshot' AND h.metric IN ({placeholders})
        ORDER BY h.metric ASC
        """
        return self._query(sql, params=list(HOURLY_METRICS) + list(HOURLY_METRICS))

    def _query_hourly_metric(
        self,
        metric: str,
        since: str | None,
        limit: int,
    ) -> list[dict[str, Any]]:
        if self._table_exists("health_hourly"):
            sql = """
            SELECT metric, date, hour, value, unit, recorded_at
            FROM health_hourly
            WHERE metric = ?
            """
            params: list[Any] = [metric]
            if since:
                sql += " AND (date > ? OR (date = ? AND hour >= ?))"
                since_date = since[:10] if len(since) >= 10 else since
                since_hour = 0
                if len(since) >= 13 and since[10] == "T":
                    try:
                        since_hour = int(since[11:13])
                    except ValueError:
                        pass
                params.extend([since_date, since_date, since_hour])
            sql += " ORDER BY date DESC, hour DESC"
            return self._query(sql, params=params, limit=limit)

        sql = """
        SELECT metric, date, NULL as hour, snapshot_value as value, unit, recorded_at
        FROM health_daily
        WHERE metric = ? AND aggregation_kind = 'snapshot'
        """
        params = [metric]
        if since:
            sql += " AND date >= ?"
            params.append(since[:10] if len(since) >= 10 else since)
        sql += " ORDER BY date DESC"
        return self._query(sql, params=params, limit=limit)

    def _daily_hourly_summary_rows(self, date: str) -> list[dict[str, Any]]:
        if self._table_exists("health_hourly"):
            sql = """
            SELECT
                metric,
                date,
                'snapshot' as aggregation_kind,
                unit,
                SUM(value) as snapshot_value,
                NULL as sum_value,
                NULL as avg_value,
                NULL as min_value,
                NULL as max_value,
                COUNT(*) as count,
                MAX(recorded_at) as recorded_at,
                MAX(recorded_at) as updated_at
            FROM health_hourly
            WHERE date = ?
            GROUP BY metric, date, unit
            ORDER BY metric ASC
            """
            return self._query(sql, params=[date])

        placeholders = ", ".join("?" for _ in HOURLY_METRICS)
        sql = f"""
        SELECT
            metric, date, aggregation_kind, unit,
            snapshot_value, sum_value, avg_value, min_value, max_value,
            count, recorded_at, updated_at
        FROM health_daily
        WHERE date = ? AND aggregation_kind = 'snapshot' AND metric IN ({placeholders})
        ORDER BY metric ASC
        """
        return self._query(sql, params=[date, *HOURLY_METRICS])

    def _add_freshness(
        self, row: dict[str, Any], timestamp_key: str, metric_type: str
    ) -> dict[str, Any]:
        ts = row.get(timestamp_key)
        if ts and isinstance(ts, str):
            try:
                # Parse ISO8601 timestamp. SQLite 'now' is UTC, so treat
                # offset-less timestamps as UTC to avoid local-time skew.
                dt = datetime.datetime.fromisoformat(ts.replace("Z", "+00:00"))
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=datetime.timezone.utc)
                age = int(time.time() - dt.timestamp())
                threshold = STALE_THRESHOLDS.get(metric_type, 3600)
                row["age_seconds"] = age
                row["stale"] = age > threshold
            except (ValueError, TypeError):
                row["age_seconds"] = None
                row["stale"] = None
        else:
            row["age_seconds"] = None
            row["stale"] = None
        return row

    def _unavailable(self, message: str) -> dict[str, Any]:
        return {
            "status": "unavailable",
            "message": message,
            "database": self.database_status(),
        }
