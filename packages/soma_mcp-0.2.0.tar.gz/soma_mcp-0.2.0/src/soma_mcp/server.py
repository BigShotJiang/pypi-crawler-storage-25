from __future__ import annotations

import argparse
from pathlib import Path

from . import __version__
from .store import SomaStore

try:
    from fastmcp import FastMCP
except ImportError as exc:  # pragma: no cover - import guard for local bootstrap
    FastMCP = None
    FASTMCP_IMPORT_ERROR = exc
else:
    FASTMCP_IMPORT_ERROR = None

# MCP tool annotations for read-only, idempotent sensor queries.
# Tells MCP clients these tools are safe to call without confirmation prompts.
_READ_ONLY = {"readOnlyHint": True, "idempotentHint": True, "openWorldHint": False}


def build_server(db_path: str | Path):
    if FastMCP is None:
        raise RuntimeError(
            "fastmcp is required to run soma-mcp. Install dependencies with `pip install -e .`."
        ) from FASTMCP_IMPORT_ERROR

    store = SomaStore(db_path)
    mcp = FastMCP(
        "soma",
        version=__version__,
        instructions=(
            "Soma provides real-time Apple Health, Location, and Activity data "
            "from the user's iPhone via a local SQLite replica. Use get_health_summary() "
            "for a quick overview, get_user_location() for current position, and "
            "get_health_metric() for historical data. All timestamps are ISO8601. "
            "Every response includes age_seconds and stale fields for freshness."
        ),
    )

    @mcp.tool(annotations=_READ_ONLY)
    def get_user_location() -> dict:
        """Return the latest replicated location projection with freshness metadata.

        The result includes coordinates, optional address fields, and freshness keys such as
        `age_seconds` and `stale`. Timestamp fields are ISO8601 strings.
        """
        return store.get_user_location()

    @mcp.tool(annotations=_READ_ONLY)
    def get_location_history(since: str | None = None, limit: int = 100) -> list[dict]:
        """Return replicated location history ordered by newest first.

        `since` must be an ISO8601 timestamp and filters on `recorded_at >= since`.
        `limit` is clamped to 1...500. Each row includes freshness metadata.
        """
        return store.get_location_history(since=since, limit=limit)

    @mcp.tool(annotations=_READ_ONLY)
    def get_health_summary() -> dict:
        """Return the current high-value health context for agent tasks.

        The payload includes latest sample metrics, today's replicated daily snapshots,
        current activity, and local database status. Timestamps are ISO8601 strings.
        """
        return store.get_health_summary()

    @mcp.tool(annotations=_READ_ONLY)
    def get_health_metric(metric: str, since: str | None = None, limit: int = 100) -> list[dict]:
        """Return history for one metric using metric-aware semantics.

        Daily snapshot metrics return one row per day from `health_daily`. Sample metrics return
        event history from `health_samples`. `user_activity` returns rows from `activity_samples`.
        `since` accepts an ISO8601 timestamp for event metrics or an ISO8601 date for daily
        snapshots. `limit` is clamped to 1...500.
        """
        return store.get_health_metric(metric=metric, since=since, limit=limit)

    @mcp.tool(annotations=_READ_ONLY)
    def get_health_metrics_list() -> list[dict]:
        """Return the available replicated metrics, kinds, and their latest values.

        The response mixes latest sample metrics and today's daily snapshots, each annotated with
        freshness metadata so agents can decide whether the data is recent enough.
        """
        return store.get_health_metrics_list()

    @mcp.tool(annotations=_READ_ONLY)
    def get_user_activity() -> dict:
        """Return the latest replicated motion/activity projection with freshness metadata.

        The response includes `activity_code`, a human-readable `activity_label`, and ISO8601
        start/end timestamps for the current activity interval.
        """
        return store.get_user_activity()

    @mcp.tool(annotations=_READ_ONLY)
    def get_daily_summary(date: str | None = None) -> dict:
        """Return one day's replicated health rollup.

        `date` must be an ISO8601 date (`YYYY-MM-DD`) and defaults to today in the host locale.
        The response includes cumulative daily snapshots and derived sample-stat aggregates for that
        day, each with freshness metadata.
        """
        return store.get_daily_summary(date=date)

    @mcp.tool(annotations=_READ_ONLY)
    def get_workouts(since: str | None = None, limit: int = 50) -> list[dict]:
        """Return workout session history ordered by newest first.

        Each workout includes activity type/label, start/end timestamps, duration in seconds,
        total distance in meters, and total energy burned in kcal. `since` accepts an ISO8601
        timestamp. `limit` is clamped to 1...500.
        """
        return store.get_workouts(since=since, limit=limit)

    @mcp.tool(annotations=_READ_ONLY)
    def query_sensor_data(sql: str, limit: int = 100) -> list[dict]:
        """Run a single read-only SQL query against the local Soma SQLite replica.

        Only one SELECT or WITH statement is allowed. Mutating SQL is rejected. `limit` is
        clamped to 1...500 and appended to the query result set for safety.
        """
        return store.query_sensor_data(sql=sql, limit=limit)

    return mcp


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Soma MCP server.")
    parser.add_argument(
        "--db",
        default="~/.soma/sensors.db",
        help="Path to the local Soma SQLite replica.",
    )
    args = parser.parse_args()

    server = build_server(args.db)
    server.run()


if __name__ == "__main__":
    main()
