from __future__ import annotations

"""
GraphAgent — a BaseAgent backed by a free-form NeuronGraph.

Weight learning is PPO-style: the graph acts as both actor and critic.
The actor head reads output neurons [0:-1], the critic head reads the last
output neuron. For discrete actions the actor outputs logits; for continuous
actions it outputs means (std is a learned parameter).

The agent is intentionally minimal — it wires the NeuronGraph into the
tensor-optix contract. Topology mutations are performed externally by
TopologyController, which holds a reference to the graph.
"""

import os
from typing import Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical, Normal

from tensor_optix.core.base_agent import BaseAgent
from tensor_optix.core.types import EpisodeData, HyperparamSet
from tensor_optix.core.trajectory_buffer import compute_gae
from tensor_optix.core.device import get_device

from ..graph.neuron_graph import NeuronGraph
from ..graph.topology_ops import add_input_neuron


class GraphAgent(BaseAgent):
    """
    RL agent whose policy network is a mutable NeuronGraph.

    Parameters
    ----------
    graph:
        A NeuronGraph that has already been configured with input/output neurons.
        The last output neuron is the value head; all others are action logits
        (discrete) or action means (continuous).
    obs_dim:
        Expected observation dimensionality. If a new obs arrives with more
        dimensions, the agent automatically grows new input neurons.
    n_actions:
        Number of discrete actions, or dimension of continuous action space.
    continuous:
        If True, actions are sampled from a Gaussian. If False, from Categorical.
    hyperparams:
        Initial HyperparamSet. Keys used: learning_rate, clip_ratio,
        entropy_coef, vf_coef, gamma, gae_lambda, n_epochs, minibatch_size,
        max_grad_norm.
    """

    is_on_policy = True

    default_hyperparams = {
        "learning_rate":  3e-4,
        "clip_ratio":     0.2,
        "entropy_coef":   0.01,
        "vf_coef":        0.5,
        "gamma":          0.99,
        "gae_lambda":     0.95,
        "n_epochs":       4,
        "minibatch_size": 64,
        "max_grad_norm":  0.5,
    }

    def __init__(
        self,
        graph: NeuronGraph,
        obs_dim: int,
        n_actions: int,
        continuous: bool = False,
        hyperparams: Optional[HyperparamSet] = None,
        device=None,
    ) -> None:
        self.graph = graph
        self.obs_dim = obs_dim
        self.n_actions = n_actions
        self.continuous = continuous
        self.device = torch.device(device) if device is not None else get_device()

        self.graph.to(self.device)

        if continuous:
            # Learnable log-std, one per action dimension
            self.log_std = nn.Parameter(torch.zeros(n_actions, device=self.device))

        params = list(self.graph.parameters())
        if continuous:
            params.append(self.log_std)

        _hp = dict(self.default_hyperparams)
        if hyperparams is not None:
            _hp.update(hyperparams.params)
        self._hyperparams = HyperparamSet(params=_hp, episode_id=0)

        self.optimizer = torch.optim.Adam(params, lr=_hp["learning_rate"])
        self._episode_count = 0

    # ------------------------------------------------------------------
    # BaseAgent contract
    # ------------------------------------------------------------------

    def act(self, observation) -> any:
        """
        Given a numpy observation, return an action (and store log_prob).
        Dynamically grows input neurons if obs_dim has expanded.
        """
        obs = self._to_tensor(observation)
        self._maybe_grow_inputs(obs)

        self.graph.reset_state()
        with torch.no_grad():
            out = self.graph(obs)

        action, log_prob = self._sample_action(out)
        self._last_log_prob = log_prob
        return action

    def learn(self, episode_data: EpisodeData) -> dict:
        hp = self._hyperparams.params
        obs_t = torch.tensor(
            np.array(episode_data.observations), dtype=torch.float32, device=self.device
        )
        act_t = torch.tensor(
            np.array(episode_data.actions), dtype=torch.long if not self.continuous else torch.float32,
            device=self.device,
        )
        rew_t = torch.tensor(episode_data.rewards, dtype=torch.float32, device=self.device)
        old_lp = torch.tensor(
            episode_data.log_probs if episode_data.log_probs else [0.0] * len(episode_data.rewards),
            dtype=torch.float32, device=self.device,
        )

        # Compute values and advantages
        with torch.no_grad():
            values = self._batch_values(obs_t)
        advantages, returns = compute_gae(
            rewards=rew_t.cpu().numpy().tolist(),
            values=values.cpu().numpy().tolist(),
            dones=episode_data.dones,
            gamma=hp["gamma"],
            gae_lambda=hp["gae_lambda"],
        )
        adv_t = torch.tensor(advantages, dtype=torch.float32, device=self.device)
        ret_t = torch.tensor(returns, dtype=torch.float32, device=self.device)
        adv_t = (adv_t - adv_t.mean()) / (adv_t.std() + 1e-8)

        T = obs_t.shape[0]
        total_loss = total_pg = total_vf = total_ent = 0.0
        n_updates = 0

        for _ in range(hp["n_epochs"]):
            perm = torch.randperm(T, device=self.device)
            for start in range(0, T, hp["minibatch_size"]):
                idx = perm[start : start + hp["minibatch_size"]]
                if idx.numel() == 0:
                    continue
                ob = obs_t[idx]
                ac = act_t[idx]
                old_lp_b = old_lp[idx]
                adv_b = adv_t[idx]
                ret_b = ret_t[idx]

                out_b = self._batch_forward(ob)
                new_lp, entropy, values_b = self._evaluate_actions(out_b, ac)

                ratio = torch.exp(new_lp - old_lp_b)
                pg1 = ratio * adv_b
                pg2 = torch.clamp(ratio, 1 - hp["clip_ratio"], 1 + hp["clip_ratio"]) * adv_b
                pg_loss = -torch.min(pg1, pg2).mean()

                vf_loss = F.mse_loss(values_b, ret_b)
                ent_loss = -entropy.mean()

                loss = pg_loss + hp["vf_coef"] * vf_loss + hp["entropy_coef"] * ent_loss

                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.graph.parameters(), hp["max_grad_norm"])
                self.optimizer.step()
                self.graph.enforce_dale()

                total_loss += loss.item()
                total_pg += pg_loss.item()
                total_vf += vf_loss.item()
                total_ent += ent_loss.item()
                n_updates += 1

        self._episode_count += 1
        denom = max(n_updates, 1)
        return {
            "loss": total_loss / denom,
            "pg_loss": total_pg / denom,
            "vf_loss": total_vf / denom,
            "entropy": -total_ent / denom,
            "n_neurons": self.graph.n_neurons(),
            "n_edges": self.graph.n_edges(),
        }

    def get_hyperparams(self) -> HyperparamSet:
        return self._hyperparams

    def set_hyperparams(self, hyperparams: HyperparamSet) -> None:
        self._hyperparams = hyperparams
        for pg in self.optimizer.param_groups:
            pg["lr"] = hyperparams.params.get("learning_rate", pg["lr"])

    def save_weights(self, path: str) -> None:
        os.makedirs(os.path.dirname(path) if os.path.dirname(path) else ".", exist_ok=True)
        state = {
            "topology": self.graph.to_dict(),
            "graph":    self.graph.state_dict(),
            "episode":  self._episode_count,
        }
        if self.continuous:
            state["log_std"] = self.log_std.data
        torch.save(state, path)

    def load_weights(self, path: str) -> None:
        state = torch.load(path, map_location=self.device, weights_only=False)
        if "topology" in state:
            # Reconstruct topology so state_dict keys match exactly — handles
            # evolved graphs where neurons were added or pruned since construction.
            from ..graph.neuron_graph import NeuronGraph
            self.graph = NeuronGraph.from_dict(state["topology"]).to(self.device)
        self.graph.load_state_dict(state["graph"])
        self._episode_count = state.get("episode", 0)
        if self.continuous and "log_std" in state:
            self.log_std.data.copy_(state["log_std"])

    @classmethod
    def from_checkpoint(cls, path: str, device: str = "auto") -> "GraphAgent":
        """
        Load a fully-evolved GraphAgent from a checkpoint saved by save_weights().

        Unlike load_weights(), this does not require a pre-constructed agent —
        it reconstructs the topology from the checkpoint and returns a ready
        agent.

            agent = GraphAgent.from_checkpoint("checkpoints/best.pt")
            agent.act(obs)
        """
        from ..graph.neuron_graph import NeuronGraph

        state = torch.load(path, map_location="cpu", weights_only=False)
        if "topology" not in state:
            raise ValueError(
                f"Checkpoint at '{path}' has no topology key. "
                "It was saved before topology-aware checkpointing was introduced. "
                "Construct the agent manually and call load_weights() instead."
            )
        graph = NeuronGraph.from_dict(state["topology"])
        n_inputs   = len(graph.input_ids)
        n_outputs  = len(graph.output_ids)
        continuous = "log_std" in state
        # Last output neuron is always the value head; remaining are action outputs.
        n_actions  = n_outputs - 1

        _device = (
            ("cuda" if torch.cuda.is_available() else "cpu")
            if device == "auto" else device
        )
        agent = cls(
            graph=graph,
            obs_dim=n_inputs,
            n_actions=n_actions,
            continuous=continuous,
            device=_device,
        )
        agent.graph.load_state_dict(state["graph"])
        agent._episode_count = state.get("episode", 0)
        if continuous and "log_std" in state:
            agent.log_std.data.copy_(state["log_std"].to(agent.device))
        return agent

    def perturb_weights(self, noise_scale: float) -> None:
        with torch.no_grad():
            for p in self.graph.parameters():
                p.mul_(1 + noise_scale * torch.randn_like(p))

    def average_weights(self, paths: list) -> None:
        if not paths:
            return
        states = [torch.load(p, map_location=self.device)["graph"] for p in paths]
        avg = {k: torch.stack([s[k].float() for s in states]).mean(0) for k in states[0]}
        self.graph.load_state_dict(avg)

    def teardown(self) -> None:
        self.graph.cpu()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _to_tensor(self, obs) -> torch.Tensor:
        if isinstance(obs, torch.Tensor):
            return obs.float().to(self.device)
        return torch.tensor(obs, dtype=torch.float32, device=self.device).flatten()

    def _maybe_grow_inputs(self, obs: torch.Tensor) -> None:
        current_inputs = len(self.graph.input_ids)
        needed = obs.shape[0]
        if needed > current_inputs:
            for _ in range(needed - current_inputs):
                add_input_neuron(self.graph, activation="linear")
            self.obs_dim = needed
            # Rebuild optimizer to include new parameters
            params = list(self.graph.parameters())
            if self.continuous:
                params.append(self.log_std)
            lr = self._hyperparams.params.get("learning_rate", 3e-4)
            self.optimizer = torch.optim.Adam(params, lr=lr)

    def _batch_forward(self, obs_batch: torch.Tensor) -> torch.Tensor:
        """
        Vectorized batch forward over the graph.

        Instead of looping over B observations, we keep an activation buffer
        [B, n_neurons] and propagate in topological order. Each neuron's
        pre-activation is a sum of weighted columns — pure tensor ops, no
        Python loop over B.
        """
        B = obs_batch.shape[0]
        graph = self.graph
        dev = self.device

        order = graph._topological_order()
        input_ids = graph.input_ids

        # Map every neuron id to a column index in the activation buffer
        all_ids = list(input_ids) + list(order)
        nid_to_col: dict[str, int] = {nid: i for i, nid in enumerate(all_ids)}
        n_total = len(all_ids)
        n_input = len(input_ids)

        # act[nid] = [B] activation tensor for that neuron (no in-place writes)
        act: dict[str, torch.Tensor] = {}

        # Inject inputs
        for i, nid in enumerate(input_ids):
            act[nid] = obs_batch[:, i]

        for nid in order:
            neuron = graph._neurons[nid]  # type: ignore
            pre = torch.zeros(B, device=dev)
            for eid in graph._in_edges.get(nid, []):
                edge = graph._edges[eid]
                src = edge.src
                if src in act:
                    pre = pre + edge.weight * act[src]
            act[nid] = neuron._activation_fn(pre + neuron.bias.squeeze(0))

        return torch.stack([act[nid] for nid in graph.output_ids], dim=1)  # [B, n_outputs]

    def _batch_values(self, obs_batch: torch.Tensor) -> torch.Tensor:
        out = self._batch_forward(obs_batch)
        return out[:, -1]  # last output neuron = value

    def _sample_action(self, out: torch.Tensor):
        logits_or_means = out[:-1]  # all but last = actor
        if self.continuous:
            std = self.log_std.exp().clamp(1e-4, 2.0)
            dist = Normal(logits_or_means, std)
            action = dist.sample()
            log_prob = dist.log_prob(action).sum()
            return action.cpu().numpy(), log_prob
        else:
            dist = Categorical(logits=logits_or_means)
            action = dist.sample()
            return action.item(), dist.log_prob(action)

    def _evaluate_actions(self, out_batch: torch.Tensor, actions: torch.Tensor):
        logits_or_means = out_batch[:, :-1]
        values = out_batch[:, -1]
        if self.continuous:
            std = self.log_std.exp().clamp(1e-4, 2.0)
            dist = Normal(logits_or_means, std.unsqueeze(0).expand_as(logits_or_means))
            log_prob = dist.log_prob(actions).sum(-1)
            entropy = dist.entropy().sum(-1)
        else:
            dist = Categorical(logits=logits_or_means)
            log_prob = dist.log_prob(actions)
            entropy = dist.entropy()
        return log_prob, entropy, values


# ──────────────────────────────────────────────────────────────────────────────
# RecurrentGraphAgent
# ──────────────────────────────────────────────────────────────────────────────

class RecurrentGraphAgent(GraphAgent):
    """
    GraphAgent subclass that supports TrainableGRUNeuron / TrainableLSTMNeuron.

    When the graph contains any neuron with is_recurrent=True, learn() switches
    from the default shuffled-minibatch PPO to sequential chunk-based training
    (truncated BPTT). Inference via act() is unchanged — it still calls the
    parent step() path with detached hidden states.

    Extra hyperparams:
      chunk_len (int, default 64): BPTT truncation length in timesteps.
    """

    default_hyperparams = {
        **GraphAgent.default_hyperparams,
        "chunk_len": 64,
    }

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def learn(self, episode_data: EpisodeData) -> dict:
        if not self._has_recurrent_neurons():
            return super().learn(episode_data)
        return self._recurrent_learn(episode_data)

    # ------------------------------------------------------------------
    # Sequential / recurrent forward
    # ------------------------------------------------------------------

    def recurrent_forward(self, obs_sequence: torch.Tensor, chunk_len: int = 64) -> torch.Tensor:
        """
        Process T timesteps in order with truncated BPTT every chunk_len steps.

        Returns [T, n_outputs].
        """
        T = obs_sequence.shape[0]
        outputs = []

        self._reset_recurrent_train_states()

        for t in range(T):
            if t > 0 and t % chunk_len == 0:
                self._detach_recurrent_train_states()

            out = self._sequential_step(obs_sequence[t])
            outputs.append(out)

        return torch.stack(outputs)  # [T, n_outputs]

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _has_recurrent_neurons(self) -> bool:
        return any(
            getattr(n, "is_recurrent", False)
            for n in self.graph._neurons.values()
        )

    def _reset_recurrent_train_states(self) -> None:
        for neuron in self.graph._neurons.values():
            if getattr(neuron, "is_recurrent", False):
                neuron.reset_train_state()

    def _detach_recurrent_train_states(self) -> None:
        for neuron in self.graph._neurons.values():
            if getattr(neuron, "is_recurrent", False):
                if hasattr(neuron, "_h_train"):
                    neuron._h_train = neuron._h_train.detach()
                if hasattr(neuron, "_c_train"):
                    neuron._c_train = neuron._c_train.detach()

    def _sequential_step(self, obs: torch.Tensor) -> torch.Tensor:
        """
        Single-timestep forward through the graph using recurrent_step() for
        recurrent neurons and _activation_fn for point neurons.
        obs: [n_inputs]
        Returns: [n_outputs]
        """
        graph = self.graph
        act: dict[str, torch.Tensor] = {}

        for i, nid in enumerate(graph.input_ids):
            act[nid] = obs[i].unsqueeze(0)  # keep scalar as [1]

        for nid in graph._topological_order():
            neuron = graph._neurons[nid]
            pre = torch.zeros(1, device=self.device)
            for eid in graph._in_edges.get(nid, []):
                edge = graph._edges[eid]
                src = edge.src
                if src in act:
                    pre = pre + edge.weight * act[src]

            if getattr(neuron, "is_recurrent", False):
                act[nid] = neuron.recurrent_step(pre)
            else:
                act[nid] = neuron._activation_fn(pre + neuron.bias.squeeze(0))

        return torch.stack([act[nid] for nid in graph.output_ids]).squeeze(-1)  # [n_outputs]

    def _recurrent_learn(self, episode_data: EpisodeData) -> dict:
        hp = self._hyperparams.params
        chunk_len = int(hp.get("chunk_len", 64))

        obs_t = torch.tensor(
            np.array(episode_data.observations), dtype=torch.float32, device=self.device
        )
        act_t = torch.tensor(
            np.array(episode_data.actions),
            dtype=torch.long if not self.continuous else torch.float32,
            device=self.device,
        )
        rew_t = torch.tensor(episode_data.rewards, dtype=torch.float32, device=self.device)
        old_lp = torch.tensor(
            episode_data.log_probs if episode_data.log_probs else [0.0] * len(episode_data.rewards),
            dtype=torch.float32, device=self.device,
        )

        # Compute values with detached inference pass
        with torch.no_grad():
            values = self._batch_values(obs_t)
        advantages, returns = compute_gae(
            rewards=rew_t.cpu().numpy().tolist(),
            values=values.cpu().numpy().tolist(),
            dones=episode_data.dones,
            gamma=hp["gamma"],
            gae_lambda=hp["gae_lambda"],
        )
        adv_t = torch.tensor(advantages, dtype=torch.float32, device=self.device)
        ret_t = torch.tensor(returns, dtype=torch.float32, device=self.device)
        adv_t = (adv_t - adv_t.mean()) / (adv_t.std() + 1e-8)

        T = obs_t.shape[0]
        total_loss = total_pg = total_vf = total_ent = 0.0
        n_updates = 0

        for _ in range(hp["n_epochs"]):
            # Sequential chunk windows — no shuffling
            for start in range(0, T, chunk_len):
                end = min(start + chunk_len, T)
                if end - start < 2:
                    continue

                ob_chunk = obs_t[start:end]        # [chunk, obs_dim]
                ac_chunk = act_t[start:end]        # [chunk]
                old_lp_chunk = old_lp[start:end]   # [chunk]
                adv_chunk = adv_t[start:end]        # [chunk]
                ret_chunk = ret_t[start:end]        # [chunk]

                out_chunk = self.recurrent_forward(ob_chunk, chunk_len=chunk_len)  # [chunk, n_outputs]
                new_lp, entropy, values_chunk = self._evaluate_actions(out_chunk, ac_chunk)

                ratio = torch.exp(new_lp - old_lp_chunk)
                pg1 = ratio * adv_chunk
                pg2 = torch.clamp(ratio, 1 - hp["clip_ratio"], 1 + hp["clip_ratio"]) * adv_chunk
                pg_loss = -torch.min(pg1, pg2).mean()

                vf_loss = F.mse_loss(values_chunk, ret_chunk)
                ent_loss = -entropy.mean()

                loss = pg_loss + hp["vf_coef"] * vf_loss + hp["entropy_coef"] * ent_loss

                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.graph.parameters(), hp["max_grad_norm"])
                self.optimizer.step()
                self.graph.enforce_dale()

                total_loss += loss.item()
                total_pg += pg_loss.item()
                total_vf += vf_loss.item()
                total_ent += ent_loss.item()
                n_updates += 1

        self._episode_count += 1
        denom = max(n_updates, 1)
        return {
            "loss": total_loss / denom,
            "pg_loss": total_pg / denom,
            "vf_loss": total_vf / denom,
            "entropy": -total_ent / denom,
            "n_neurons": self.graph.n_neurons(),
            "n_edges": self.graph.n_edges(),
        }
