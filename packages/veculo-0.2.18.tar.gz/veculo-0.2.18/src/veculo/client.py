#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

"""Veculo API client."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Optional

import httpx

if TYPE_CHECKING:
    from veculo.embeddings import EmbeddingProvider

from veculo.errors import AuthenticationError, NotFoundError, ValidationError, VeculoError

_DEFAULT_ENDPOINT = "https://api.veculo.com"
_DEFAULT_TIMEOUT = 30.0
_API_VERSION = "v1"


class VeculoClient:
    """Client for the Veculo managed graph+vector database API.

    The client reads configuration from explicit arguments, then falls back to
    environment variables:

    * ``VECULO_ENDPOINT``  -- API base URL (default ``https://api.veculo.com``)
    * ``VECULO_API_KEY``   -- API key for authentication
    * ``VECULO_CLUSTER_ID`` -- Target cluster identifier

    Example::

        from veculo import VeculoClient

        client = VeculoClient(api_key="vk-...", cluster_id="cl-a7f3b2")
        client.put_vertex(id="alice", label="person", properties={"name": "Alice"})
        result = client.get_vertex(id="alice")
    """

    def __init__(
        self,
        endpoint: str | None = None,
        api_key: str | None = None,
        cluster_id: str | None = None,
        cluster_name: str | None = None,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        """Initialize the Veculo client.

        Provide either ``cluster_id`` or ``cluster_name``. If
        ``cluster_name`` is given, the client resolves it to an ID via
        the API on first use.

        Args:
            endpoint: API endpoint URL. Defaults to ``VECULO_ENDPOINT`` env var
                or ``https://api.veculo.com``.
            api_key: Veculo API key. Defaults to ``VECULO_API_KEY`` env var.
            cluster_id: Cluster ID (e.g., ``cl-a7f3b2``). Defaults to
                ``VECULO_CLUSTER_ID`` env var.
            cluster_name: Cluster display name (e.g., ``"production"``).
                Defaults to ``VECULO_CLUSTER_NAME`` env var. Resolved to
                cluster_id automatically.
            timeout: HTTP request timeout in seconds.

        Raises:
            VeculoError: If ``api_key`` or cluster cannot be resolved.
        """
        self.endpoint = (
            endpoint or os.environ.get("VECULO_ENDPOINT") or _DEFAULT_ENDPOINT
        ).rstrip("/")
        self.api_key = api_key or os.environ.get("VECULO_API_KEY")
        self._timeout = timeout

        if not self.api_key:
            raise VeculoError(
                "API key is required. Pass api_key= or set VECULO_API_KEY."
            )

        # Resolve cluster: ID takes priority, then name lookup
        self.cluster_id = cluster_id or os.environ.get("VECULO_CLUSTER_ID")
        cluster_name = cluster_name or os.environ.get("VECULO_CLUSTER_NAME")

        # Auto-detect: if cluster_id doesn't look like an ID, treat it as a name
        if self.cluster_id and not self.cluster_id.startswith("cl-"):
            cluster_name = self.cluster_id
            self.cluster_id = None

        if not self.cluster_id and cluster_name:
            self.cluster_id = self._resolve_cluster_name(cluster_name)
        elif not self.cluster_id:
            raise VeculoError(
                "Cluster is required. Pass cluster_id=, cluster_name=, "
                "or set VECULO_CLUSTER_ID / VECULO_CLUSTER_NAME."
            )

        self._embedder: EmbeddingProvider | None = None

        self._client = httpx.Client(
            base_url=f"{self.endpoint}/{_API_VERSION}/{self.cluster_id}",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "veculo-python/0.1.0",
            },
            timeout=timeout,
        )

    def _resolve_cluster_name(self, name: str) -> str:
        """Look up a cluster ID by display name via the API."""
        response = httpx.get(
            f"{self.endpoint}/tenants",
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=self._timeout,
        )
        if not response.is_success:
            raise VeculoError(
                f"Failed to list clusters: HTTP {response.status_code}"
            )
        clusters = response.json()
        for cluster in clusters:
            if cluster.get("name") == name:
                return cluster["tenant_id"]
        raise NotFoundError(f"No cluster found with name '{name}'")

    # ------------------------------------------------------------------
    # Vertex operations
    # ------------------------------------------------------------------

    def put_vertex(
        self,
        id: str,
        label: str = "default",
        properties: dict[str, Any] | None = None,
        embedding: list[float] | None = None,
        visibility: str | None = None,
    ) -> dict:
        """Insert or update a vertex, optionally with a vector embedding.

        Args:
            id: Unique vertex identifier.
            label: Vertex label / type.
            properties: Key-value properties to store.
            embedding: Optional vector embedding for similarity search.
            visibility: Accumulo-style visibility expression.

        Returns:
            API response body as a dictionary.
        """
        body: dict[str, Any] = {"id": id, "label": label}
        if properties is not None:
            body["properties"] = properties
        if visibility is not None:
            body["visibility"] = visibility
        if embedding is not None:
            body["embedding"] = embedding
            return self._request("POST", "/vertices/embedding", json=body)
        return self._request("POST", "/vertices", json=body)

    def put_vertex_with_text(
        self,
        id: str,
        text: str,
        label: str = "default",
        properties: dict[str, Any] | None = None,
        visibility: str | None = None,
        embed_server_side: bool = False,
    ) -> dict:
        """Insert a vertex, generating an embedding from text.

        Args:
            id: Unique vertex identifier.
            text: Text to generate embedding from.
            label: Vertex label.
            properties: Additional properties.
            visibility: Visibility expression.
            embed_server_side: If True, sends text to Veculo API for
                server-side embedding (billed). If False, requires
                an embedding provider to be configured via set_embedder().

        Returns:
            API response.

        Raises:
            VeculoError: If no embedder configured and embed_server_side=False.
        """
        if embed_server_side:
            body: dict[str, Any] = {"id": id, "label": label, "text": text}
            if properties:
                body["properties"] = properties
            if visibility:
                body["visibility"] = visibility
            return self._request("POST", "/vertices/embed", json=body)

        if self._embedder is None:
            raise VeculoError(
                "No embedding provider configured. Call client.set_embedder() "
                "or use embed_server_side=True."
            )
        embedding = self._embedder.embed(text)
        props = dict(properties or {})
        props["_text"] = text
        return self.put_vertex(
            id=id, label=label, properties=props,
            embedding=embedding, visibility=visibility,
        )

    def put_vertex_with_file(
        self,
        file_path: str,
        id: str | None = None,
        label: str | None = None,
        properties: dict[str, Any] | None = None,
        visibility: str | None = None,
    ) -> dict:
        """Upload a file and create a vertex with automatic knowledge extraction.

        The file is uploaded to GCS. Veculo asynchronously extracts text,
        generates embeddings, discovers entities, and builds relationship
        edges from the file content.

        Supported types: PDF, images (JPEG/PNG/WebP), audio (MP3/WAV),
        video (MP4), code (Python/Java/JavaScript/TypeScript), plain text.

        Veculo automatically:
        - Extracts text (OCR, transcription, or parsing)
        - Generates embeddings
        - Discovers entities and relationships
        - Builds a knowledge subgraph

        If ``id`` is not provided, it is auto-generated from the filename:
        ``paper.pdf`` → ``document:paper``,
        ``transformer.py`` → ``code:transformer``,
        ``diagram.png`` → ``image:diagram``.

        Args:
            file_path: Path to file on disk.
            id: Vertex identifier (auto-generated from filename if omitted).
            label: Vertex label (auto-detected from content type if omitted).
            properties: Additional key-value properties.
            visibility: Accumulo-style visibility expression.

        Returns:
            API response with vertex_id and file_uri.

        Example::

            # Just upload — ID, label, everything auto-detected
            client.put_vertex_with_file("attention-is-all-you-need.pdf")
            client.put_vertex_with_file("transformer.py")
            client.put_vertex_with_file("architecture.png")
        """
        import mimetypes
        from pathlib import Path

        path = Path(file_path)
        filename = path.name
        content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        file_bytes = path.read_bytes()

        data: dict[str, Any] = {}
        if id:
            data["id"] = id
        if label:
            data["label"] = label
        if properties:
            data["properties_json"] = __import__("json").dumps(properties)
        if visibility:
            data["visibility"] = visibility

        return self._multipart_request(
            "/vertices/file",
            files={"file": (filename, file_bytes, content_type)},
            data=data,
        )

    def _multipart_request(
        self,
        path: str,
        files: dict,
        data: dict,
    ) -> dict:
        """Send a multipart/form-data request (for file uploads)."""
        # httpx needs Content-Type unset for multipart boundary auto-detection
        response = self._client.post(path, files=files, data=data)
        if response.is_success:
            return response.json()
        # Same error handling as _request
        try:
            error_body = response.json()
            message = error_body.get("error", {}).get("message", response.text)
        except Exception:
            error_body = None
            message = response.text or f"HTTP {response.status_code}"
        status = response.status_code
        if status in (401, 403):
            raise AuthenticationError(message, status_code=status, body=error_body)
        if status == 404:
            raise NotFoundError(message, status_code=status, body=error_body)
        if status in (400, 422):
            raise ValidationError(message, status_code=status, body=error_body)
        raise VeculoError(message, status_code=status, body=error_body)

    def set_embedder(self, provider: "EmbeddingProvider") -> None:
        """Configure a client-side embedding provider.

        Example::
            from veculo.embeddings import OpenAIEmbeddings
            client.set_embedder(OpenAIEmbeddings(api_key="sk-..."))
        """
        self._embedder = provider

    def get_vertex(
        self,
        id: str,
        authorizations: str | None = None,
    ) -> dict:
        """Retrieve a vertex by ID.

        Args:
            id: Vertex identifier.
            authorizations: Comma-separated visibility authorizations.

        Returns:
            Vertex data as a dictionary.
        """
        params: dict[str, str] | None = None
        if authorizations is not None:
            params = {"authorizations": authorizations}
        return self._request("GET", f"/vertices/{id}", params=params)

    # ------------------------------------------------------------------
    # Edge operations
    # ------------------------------------------------------------------

    def put_edge(
        self,
        source: str,
        target: str,
        edge_type: str,
        properties: dict[str, Any] | None = None,
        visibility: str | None = None,
    ) -> dict:
        """Create or update a directed edge between two vertices.

        Args:
            source: Source vertex ID.
            target: Target vertex ID.
            edge_type: Relationship type (e.g., ``"knows"``).
            properties: Key-value properties to store on the edge.
            visibility: Accumulo-style visibility expression.

        Returns:
            API response body as a dictionary.
        """
        body: dict[str, Any] = {
            "source": source,
            "target": target,
            "edge_type": edge_type,
        }
        if properties is not None:
            body["properties"] = properties
        if visibility is not None:
            body["visibility"] = visibility
        return self._request("POST", "/edges", json=body)

    # ------------------------------------------------------------------
    # Query operations
    # ------------------------------------------------------------------

    def get_neighbors(
        self,
        vertex_id: str,
        edge_type: str,
        depth: int = 1,
        authorizations: str | None = None,
    ) -> dict:
        """Traverse the graph to find neighbors of a vertex.

        Args:
            vertex_id: Starting vertex ID.
            edge_type: Filter traversal to this edge type.
            depth: Maximum traversal depth (default 1).
            authorizations: Comma-separated visibility authorizations.

        Returns:
            Neighboring vertices and edges as a dictionary.
        """
        body: dict[str, Any] = {
            "vertex_id": vertex_id,
            "edge_type": edge_type,
        }
        if authorizations is not None:
            body["authorizations"] = authorizations
        return self._request("POST", "/neighbors", json=body)

    def query(
        self,
        embedding: list[float] | None = None,
        top_k: int = 10,
        edge_type: str | None = None,
        depth: int = 1,
        authorizations: str | None = None,
    ) -> dict:
        """Execute a hybrid vector similarity + graph traversal query.

        Finds the ``top_k`` most similar vertices by embedding, then
        optionally expands the result set via graph traversal.

        Args:
            embedding: Query vector for similarity search.
            top_k: Number of nearest neighbors to return (default 10).
            edge_type: Optional edge type filter for graph expansion.
            depth: Graph traversal depth (default 1).
            authorizations: Comma-separated visibility authorizations.

        Returns:
            Combined vector and graph results as a dictionary.
        """
        body: dict[str, Any] = {"top_k": top_k, "depth": depth}
        if embedding is not None:
            body["query_vector"] = embedding
        if edge_type is not None:
            body["edge_type"] = edge_type
        if authorizations is not None:
            body["authorizations"] = authorizations
        return self._request("POST", "/query/vector", json=body)

    def query_temporal(
        self,
        vertex_id: str,
        start_time: int | None = None,
        end_time: int | None = None,
        edge_type: str | None = None,
        time_field: str = "write_time",
    ) -> dict:
        """Query edges within a time range.

        Args:
            vertex_id: Vertex to query edges for.
            start_time: Start of time range (epoch milliseconds).
            end_time: End of time range (epoch milliseconds).
            edge_type: Optional edge type filter.
            time_field: "write_time" (Accumulo timestamp) or "event_time" (property).

        Returns:
            Dict with 'edges' list and 'count'.
        """
        body: dict[str, Any] = {"vertex_id": vertex_id, "time_field": time_field}
        if start_time is not None:
            body["start_time"] = start_time
        if end_time is not None:
            body["end_time"] = end_time
        if edge_type is not None:
            body["edge_type"] = edge_type
        return self._request("POST", "/query/temporal", json=body)

    def aggregate(
        self,
        aggregation: str,
        vertex_id: str | None = None,
        edge_type: str | None = None,
        time_bucket: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        limit: int = 100,
    ) -> dict:
        """Run a server-side aggregation query.

        Args:
            aggregation: One of COUNT, COUNT_DISTINCT, GROUP_BY_EDGE_TYPE,
                GROUP_BY_TIME, DEGREE, TOP_CONNECTED.
            vertex_id: Scope to a single vertex (optional).
            edge_type: Filter to a specific edge type (optional).
            time_bucket: For GROUP_BY_TIME: HOUR, DAY, WEEK, MONTH.
            start_time: Lower time bound (epoch millis).
            end_time: Upper time bound (epoch millis).
            limit: Maximum results to return.

        Returns:
            Dict with 'aggregation', 'results' list, and 'count'.
        """
        body: dict[str, Any] = {"aggregation": aggregation, "limit": limit}
        if vertex_id is not None:
            body["vertex_id"] = vertex_id
        if edge_type is not None:
            body["edge_type"] = edge_type
        if time_bucket is not None:
            body["time_bucket"] = time_bucket
        if start_time is not None:
            body["start_time"] = start_time
        if end_time is not None:
            body["end_time"] = end_time
        return self._request("POST", "/query/aggregate", json=body)

    def list_jobs(self) -> dict:
        """List file upload jobs and their extraction status.

        Returns:
            Dict with 'jobs' list containing vertex_id, filename, content_type,
            status (processing/complete), and extraction details.
        """
        return self._request("GET", "/jobs")

    def get_metrics(self) -> dict:
        """Retrieve cluster health and performance metrics.

        Returns:
            Cluster metrics as a dictionary.
        """
        return self._request("GET", "/metrics")

    # ------------------------------------------------------------------
    # Hibernate / Resume
    # ------------------------------------------------------------------

    def hibernate(self) -> dict:
        """Hibernate the cluster to save costs.

        Flushes all in-memory data to GCS, snapshots ZooKeeper metadata,
        and tears down all compute resources. Data and tablet metadata
        are fully preserved. Resume later with ``resume()``.

        Returns:
            API response with hibernation status.
        """
        return self._request("POST", "/hibernate")

    def resume(self) -> dict:
        """Resume a hibernated cluster.

        Deploys fresh compute pointing at the existing GCS data and
        restores ZooKeeper metadata. All tables, vertices, edges,
        and embeddings come back intact.

        Returns:
            API response with resume status.
        """
        return self._request("POST", "/resume")

    # ------------------------------------------------------------------
    # Bulk operations
    # ------------------------------------------------------------------

    def put_vertices_bulk(
        self,
        vertices: list[dict[str, Any]],
    ) -> dict:
        """Insert multiple vertices in a single batch.

        Args:
            vertices: List of vertex dicts, each with 'id', 'label',
                and optional 'properties'.

        Returns:
            API response with insert count.
        """
        return self._request("POST", "/vertices/bulk", json={"vertices": vertices})

    def put_edges_bulk(
        self,
        edges: list[dict[str, Any]],
    ) -> dict:
        """Insert multiple edges in a single batch.

        Args:
            edges: List of edge dicts, each with 'source', 'target',
                'edge_type', and optional 'properties'.

        Returns:
            API response with insert count.
        """
        return self._request("POST", "/edges/bulk", json={"edges": edges})

    # ------------------------------------------------------------------
    # AI-native queries
    # ------------------------------------------------------------------

    def nl_query(
        self,
        question: str,
        authorizations: str | None = None,
        schema_hints: dict | None = None,
    ) -> dict:
        """Execute a natural language query against the graph.

        Translates the question into a structured query plan via LLM,
        executes it, and returns results with the generated plan.

        Args:
            question: Natural language question.
            authorizations: Comma-separated visibility authorizations.
            schema_hints: Optional schema metadata for better translation.

        Returns:
            Dict with 'question', 'query_plan', and 'results'.
        """
        body: dict[str, Any] = {"question": question}
        if authorizations is not None:
            body["authorizations"] = authorizations
        if schema_hints is not None:
            body["schema_hints"] = schema_hints
        return self._request("POST", "/query/natural", json=body)

    def rag_query(
        self,
        question: str,
        context_hops: int = 1,
        model: str | None = None,
        authorizations: str | None = None,
        top_k: int = 10,
    ) -> dict:
        """Execute a Graph-Augmented RAG query.

        Performs vector search, expands graph neighborhoods, and
        synthesizes an answer via LLM with source citations.

        Args:
            question: Natural language question.
            context_hops: Graph traversal depth for context (default 1).
            model: LLM model for synthesis.
            authorizations: Visibility authorizations for ABAC.
            top_k: Number of vector search results.

        Returns:
            Dict with 'answer', 'sources', 'context', and 'model'.
        """
        body: dict[str, Any] = {
            "question": question,
            "context_hops": context_hops,
            "top_k": top_k,
        }
        if model is not None:
            body["model"] = model
        if authorizations is not None:
            body["authorizations"] = authorizations
        return self._request("POST", "/rag", json=body)

    # ------------------------------------------------------------------
    # Graph pattern queries
    # ------------------------------------------------------------------

    def query_expand(
        self,
        embedding: list[float],
        top_k: int = 10,
        threshold: float = 0.5,
        alpha: float = 0.7,
        depth: int = 1,
    ) -> dict:
        """Topological vector expansion -- finds similar vertices AND scores their graph neighbors.

        Performs vector search to find seed vertices, then expands to their
        graph neighbors and scores them using a combination of vector similarity
        and connectivity strength.

        Args:
            embedding: Query vector for similarity search.
            top_k: Number of results to return (default 10).
            threshold: Minimum similarity for seed search (default 0.5).
            alpha: Weight between similarity and connectivity.
                0 = pure connectivity, 1 = pure similarity (default 0.7).
            depth: Graph traversal depth for expansion (default 1).

        Returns:
            Dict with 'results' (list of scored vertices) and 'count'.
        """
        body: dict[str, Any] = {
            "query_vector": embedding,
            "top_k": top_k,
            "threshold": threshold,
            "alpha": alpha,
            "depth": depth,
        }
        return self._request("POST", "/query/expand", json=body)

    def reason(
        self,
        query: str | None = None,
        embedding: list[float] | None = None,
        start_vertex: str | None = None,
        strategy: str | None = None,
        max_depth: int | None = None,
        alpha: float | None = None,
        threshold: float | None = None,
        edge_types: list[str] | None = None,
        use_scan_server: bool = False,
    ) -> dict:
        """SSM reasoning: stateful multi-hop graph traversal.

        Each hop updates a hidden state using the current vertex's embedding.
        The next hop follows the neighbor most aligned with the accumulated state.

        Use ``strategy`` for pre-built reasoning modes, or set parameters manually.

        Strategies:
            - ``"root_cause"``: Deep traces through dependency/trigger edges (alpha=0.95)
            - ``"access_trace"``: Follow authorization chains (alpha=0.9)
            - ``"compliance"``: Trace control/evidence paths (alpha=0.85)
            - ``"influence"``: Follow any edge type, moderate momentum (alpha=0.8)
            - ``"fraud"``: Very low threshold, follows weak signals (alpha=0.9)
            - ``"knowledge"``: Follow citation/reference edges (alpha=0.8)
            - ``"supply_chain"``: Trace supplier/component chains (alpha=0.85)
            - ``"explore"``: Low momentum, adaptive discovery (alpha=0.5)

        Args:
            query: Natural language query (embedded server-side via Vertex AI).
            embedding: Raw query vector (alternative to query).
            start_vertex: Start vertex ID. If None, finds nearest to query.
            strategy: Pre-built reasoning strategy name.
            max_depth: Maximum hops (overrides strategy default).
            alpha: State momentum (overrides strategy default).
            threshold: Minimum cosine to continue (overrides strategy default).
            edge_types: Edge types to follow (overrides strategy default).
            use_scan_server: Route through inference scan servers (default True).

        Returns:
            Dict with 'path', 'hop_count', 'terminated_early',
            'termination_reason', 'final_state', and optionally 'strategy'.

        Example::

            # Strategy-based (easiest)
            result = client.reason(query="trace why auth-service failed",
                                   strategy="root_cause")

            # Knowledge exploration
            result = client.reason(query="how did neural networks evolve",
                                   strategy="knowledge",
                                   start_vertex="ai-foundations")

            # Manual parameters
            result = client.reason(query="...", alpha=0.9, threshold=0.1,
                                   edge_types=["references", "cites"])
        """
        if not query and not embedding:
            raise ValueError("Provide either query (text) or embedding (vector)")
        body: dict[str, Any] = {"use_scan_server": use_scan_server}
        if query is not None:
            body["query_text"] = query
        if embedding is not None:
            body["query_vector"] = embedding
        if start_vertex is not None:
            body["start_vertex"] = start_vertex
        if strategy is not None:
            body["strategy"] = strategy
        if max_depth is not None:
            body["max_depth"] = max_depth
        if alpha is not None:
            body["alpha"] = alpha
        if threshold is not None:
            body["threshold"] = threshold
        if edge_types is not None:
            body["edge_types"] = edge_types
        return self._request("POST", "/query/reason", json=body, timeout=120)

    def reason_multi_agent(
        self,
        query: str | None = None,
        embedding: list[float] | None = None,
        start_vertex: str | None = None,
        max_depth: int = 5,
        strategies: list[str] | None = None,
        use_scan_server: bool = False,
    ) -> dict:
        """Multi-agent SSM reasoning: runs multiple strategies in parallel.

        Each strategy performs an independent SSM traversal with its own
        parameters. The result includes agreement/divergence analysis
        showing which vertices all agents visited vs. only some.

        Args:
            query: Natural language query (embedded server-side via Vertex AI).
            embedding: Raw query vector (alternative to query).
            start_vertex: Start vertex ID. If None, finds nearest to query.
            max_depth: Maximum hops per agent (default 5).
            strategies: List of strategy names to run in parallel.
                Options: root_cause, access_trace, compliance, influence,
                fraud, knowledge, supply_chain, explore.
                Defaults to ["knowledge", "influence"].
            use_scan_server: Route through inference scan servers.

        Returns:
            Dict with 'paths' (one per strategy), 'agreed_vertices',
            'divergent_vertices', 'confidence' (0-1), and 'agent_count'.

        Example::

            result = client.reason_multi_agent(
                query="how did neural networks evolve",
                strategies=["knowledge", "influence", "explore"],
            )
            print(f"Confidence: {result['confidence']}")
            print(f"Agreed vertices: {result['agreed_vertices']}")
        """
        if not query and not embedding:
            raise ValueError("Provide either query (text) or embedding (vector)")
        body: dict[str, Any] = {"max_depth": max_depth, "use_scan_server": use_scan_server}
        if query is not None:
            body["query_text"] = query
        if embedding is not None:
            body["query_vector"] = embedding
        if start_vertex is not None:
            body["start_vertex"] = start_vertex
        body["strategies"] = strategies or ["knowledge", "influence"]
        return self._request("POST", "/query/reason/multi-agent", json=body, timeout=120)

    def reason_temporal(
        self,
        query: str | None = None,
        embedding: list[float] | None = None,
        start_vertex: str | None = None,
        max_depth: int = 5,
        alpha: float = 0.8,
        threshold: float = 0.3,
        recent_window_hours: float = 24.0,
        use_scan_server: bool = False,
    ) -> dict:
        """Temporal SSM reasoning with time-based decay.

        Recent vertices have more influence on the hidden state than
        older ones. The decay window controls what counts as "recent".

        Args:
            query: Natural language query (embedded server-side via Vertex AI).
            embedding: Raw query vector (alternative to query).
            start_vertex: Start vertex ID. If None, finds nearest to query.
            max_depth: Maximum hops (default 5).
            alpha: Base state momentum (default 0.8).
            threshold: Minimum cosine similarity to continue (default 0.3).
            recent_window_hours: Time window in hours. Vertices older than
                this get full decay (default 24).
            use_scan_server: Route through inference scan servers.

        Returns:
            Dict with 'path', 'hop_count', 'terminated_early',
            'termination_reason', and 'final_state'.

        Example::

            result = client.reason_temporal(
                query="recent activity on auth-service",
                recent_window_hours=48,
                alpha=0.9,
            )
        """
        if not query and not embedding:
            raise ValueError("Provide either query (text) or embedding (vector)")
        body: dict[str, Any] = {
            "max_depth": max_depth,
            "alpha": alpha,
            "threshold": threshold,
            "recent_window_hours": recent_window_hours,
            "use_scan_server": use_scan_server,
        }
        if query is not None:
            body["query_text"] = query
        if embedding is not None:
            body["query_vector"] = embedding
        if start_vertex is not None:
            body["start_vertex"] = start_vertex
        return self._request("POST", "/query/reason/temporal", json=body, timeout=120)

    def verify_adversarial(
        self,
        query: str | None = None,
        embedding: list[float] | None = None,
        start_vertex: str | None = None,
        max_depth: int = 5,
        use_scan_server: bool = False,
    ) -> dict:
        """Adversarial verification: runs prove AND disprove SSM paths.

        The "prove" SSM follows the most aligned path. The "disprove"
        SSM deliberately follows divergent paths looking for contradictions.
        Returns both paths and a verdict.

        Verdicts:
            - ``"SUPPORTED"``: Support path is strong, no contradictions found.
            - ``"CONTESTED"``: Both paths found valid evidence.
            - ``"UNSUPPORTED"``: Support path failed.

        Args:
            query: Natural language query (embedded server-side via Vertex AI).
            embedding: Raw query vector (alternative to query).
            start_vertex: Start vertex ID. If None, finds nearest to query.
            max_depth: Maximum hops per path (default 5).
            use_scan_server: Route through inference scan servers.

        Returns:
            Dict with 'verdict', 'trust_score', 'support_score',
            'contradict_score', 'kappa' (predictive hyperbolic spread),
            'geometric_regime' ("conflicted"/"confident"/"uninformative"),
            'mean_radius', 'support_path', and 'contradict_path'.

            The trust_score is calibrated using the spread metric kappa
            from Di Gioia (2026): T = sigma(5*delta) * S * geometric_confidence,
            where delta = support_score - contradict_score.

        Example::

            result = client.verify_adversarial(
                query="service X caused the outage",
                start_vertex="incident-42",
            )
            print(f"Verdict: {result['verdict']}")
            print(f"Trust: {result['trust_score']:.0%}")
            print(f"Spread kappa={result['kappa']:.3f} ({result['geometric_regime']})")
        """
        if not query and not embedding:
            raise ValueError("Provide either query (text) or embedding (vector)")
        body: dict[str, Any] = {"max_depth": max_depth, "use_scan_server": use_scan_server}
        if query is not None:
            body["query_text"] = query
        if embedding is not None:
            body["query_vector"] = embedding
        if start_vertex is not None:
            body["start_vertex"] = start_vertex
        return self._request("POST", "/query/reason/adversarial", json=body, timeout=120)

    def attend(
        self,
        vertex_id: str,
        query: str | None = None,
        embedding: list[float] | None = None,
        top_k: int = 10,
        layers: int = 1,
    ) -> dict:
        """Graph attention: score ALL neighbors of a vertex simultaneously.

        Unlike SSM reasoning which follows a single best path, attention
        computes softmax-weighted scores over the entire neighborhood.
        Set ``layers > 1`` for a multi-layer graph transformer that
        attends on the top-K results from the previous layer.

        Args:
            vertex_id: Seed vertex whose neighbors to attend over.
            query: Natural language query (embedded server-side via Vertex AI).
            embedding: Raw query vector (alternative to query).
            top_k: Number of top-attended neighbors to return (default 10).
            layers: Number of attention layers to stack (default 1).
                2 = attend on seed, then attend on each result's neighbors.

        Returns:
            Dict with 'vertex_id', 'attended' (list of scored neighbors),
            'layers', and 'count'.

        Example::

            # Single-layer attention
            result = client.attend(
                vertex_id="neural-networks",
                query="transformer architecture",
                top_k=5,
            )

            # 2-layer graph transformer
            result = client.attend(
                vertex_id="neural-networks",
                query="transformer architecture",
                top_k=5,
                layers=2,
            )
        """
        if not query and not embedding:
            raise ValueError("Provide either query (text) or embedding (vector)")
        body: dict[str, Any] = {"vertex_id": vertex_id, "top_k": top_k, "layers": layers}
        if query is not None:
            body["query_text"] = query
        if embedding is not None:
            body["query_vector"] = embedding
        return self._request("POST", "/query/attend", json=body, timeout=120)

    def trace_causes(
        self,
        start_vertex: str,
        query: str | None = None,
        embedding: list[float] | None = None,
        max_depth: int = 5,
        threshold: float = 0.2,
    ) -> dict:
        """Causal inference (forward): trace what a vertex causes.

        Follows only outgoing edges (E_*), scoring by alignment with
        the query. The causal strength is the product of all hop scores --
        a chain is only as strong as its weakest link.

        Args:
            start_vertex: Starting vertex ID.
            query: Natural language query (embedded server-side).
            embedding: Raw query vector.
            max_depth: Maximum hops to follow (default 5).
            threshold: Minimum cosine similarity to continue (default 0.2).

        Returns:
            Dict with 'chain' (list of hops), 'direction' ("forward"),
            'causal_strength', and 'hop_count'.

        Example::

            result = client.trace_causes(
                start_vertex="config-change-42",
                query="downstream service failures",
            )
        """
        if not query and not embedding:
            raise ValueError("Provide either query (text) or embedding (vector)")
        body: dict[str, Any] = {
            "start_vertex": start_vertex,
            "direction": "forward",
            "max_depth": max_depth,
            "threshold": threshold,
        }
        if query is not None:
            body["query_text"] = query
        if embedding is not None:
            body["query_vector"] = embedding
        return self._request("POST", "/query/causal", json=body, timeout=120)

    def trace_caused_by(
        self,
        start_vertex: str,
        query: str | None = None,
        embedding: list[float] | None = None,
        max_depth: int = 5,
        threshold: float = 0.2,
    ) -> dict:
        """Causal inference (backward): trace what caused a vertex.

        Follows only incoming edges (EI_*), scoring by alignment with
        the query. The causal strength is the product of all hop scores.

        Args:
            start_vertex: Starting vertex ID (the effect to trace back from).
            query: Natural language query (embedded server-side).
            embedding: Raw query vector.
            max_depth: Maximum hops to follow (default 5).
            threshold: Minimum cosine similarity to continue (default 0.2).

        Returns:
            Dict with 'chain' (list of hops), 'direction' ("backward"),
            'causal_strength', and 'hop_count'.

        Example::

            result = client.trace_caused_by(
                start_vertex="outage-2024-03-15",
                query="root cause of service failure",
            )
        """
        if not query and not embedding:
            raise ValueError("Provide either query (text) or embedding (vector)")
        body: dict[str, Any] = {
            "start_vertex": start_vertex,
            "direction": "backward",
            "max_depth": max_depth,
            "threshold": threshold,
        }
        if query is not None:
            body["query_text"] = query
        if embedding is not None:
            body["query_vector"] = embedding
        return self._request("POST", "/query/causal", json=body, timeout=120)

    def compile_path(
        self,
        path: list[dict[str, Any]],
    ) -> dict:
        """Compile a reasoning path into a direct edge for faster future queries.

        After running ``reason()`` and getting a useful path, compile it
        so future queries can skip multi-hop traversal and use the
        pre-computed direct edge.

        Args:
            path: List of hop dicts from a reasoning result, each with
                'vertex_id' and 'score'.

        Returns:
            Dict with 'status', 'source', 'target', and 'hops'.

        Example::

            # Run reasoning, then compile the result
            result = client.reason(query="...", strategy="root_cause")
            client.compile_path(result["path"])
        """
        return self._request("POST", "/query/compile-path", json={
            "mode": "compile",
            "path": path,
        })

    def compile_frequent_paths(
        self,
        min_frequency: int = 3,
        min_confidence: float = 0.5,
    ) -> dict:
        """Compile all frequently-traversed paths into direct edges.

        Scans for reasoning paths that have been traversed at least
        ``min_frequency`` times with average confidence above
        ``min_confidence``, and creates direct compiled edges.

        Args:
            min_frequency: Minimum traversal count (default 3).
            min_confidence: Minimum average confidence (default 0.5).

        Returns:
            Dict with 'status' and 'paths_compiled'.
        """
        return self._request("POST", "/query/compile-path", json={
            "mode": "frequent",
            "min_frequency": min_frequency,
            "min_confidence": min_confidence,
        })

    # ------------------------------------------------------------------
    # GNN, Neuro-Symbolic, and Hyperbolic queries
    # ------------------------------------------------------------------

    def gnn_propagate(
        self,
        query: str | None = None,
        embedding: list[float] | None = None,
        start_vertex: str = "",
        rounds: int = 2,
        top_k: int = 10,
        self_weight: float = 0.7,
    ) -> dict:
        """GNN message passing: aggregate neighbor embeddings over multiple rounds.

        Unlike SSM (sequential) or attention (single-pass), GNN propagates
        information from ALL neighbors simultaneously across K rounds.
        Each round updates vertex representations by pooling neighbor
        embeddings, enabling multi-hop information diffusion.

        Args:
            query: Natural language query (embedded server-side via Vertex AI).
            embedding: Raw query vector (alternative to query).
            start_vertex: Seed vertex ID for subgraph expansion.
            rounds: Number of message-passing rounds / GNN layers (default 2).
            top_k: Number of top-scored vertices to return (default 10).
            self_weight: Weight for self-embedding vs neighbor aggregate,
                0-1 (default 0.7). Higher = less neighbor influence.

        Returns:
            Dict with 'seed_vertex', 'ranked_vertices' (list of
            {vertex_id, score, round_discovered}), 'rounds', and
            'vertices_processed'.

        Example::

            result = client.gnn_propagate(
                query="machine learning optimization",
                start_vertex="ml-foundations",
                rounds=3,
            )
            for v in result["ranked_vertices"]:
                print(f"{v['vertex_id']}: {v['score']:.3f}")
        """
        if not query and not embedding:
            raise ValueError("Provide either query (text) or embedding (vector)")
        body: dict[str, Any] = {
            "start_vertex": start_vertex,
            "rounds": rounds,
            "top_k": top_k,
            "self_weight": self_weight,
        }
        if query is not None:
            body["query_text"] = query
        if embedding is not None:
            body["query_vector"] = embedding
        return self._request("POST", "/query/gnn", json=body, timeout=120)

    def infer_edges(
        self,
        start_vertex: str,
        rules: list[dict] | None = None,
        max_inferences: int = 50,
    ) -> dict:
        """Rule-based inference: apply logical rules to discover implicit edges.

        Rules are edge-type chains that imply a new relationship.
        For example, ``["IMPLEMENTS", "CITES"] -> "INFLUENCED_BY"``
        means "if A IMPLEMENTS B and B CITES C, then A is INFLUENCED_BY C."

        The engine walks the graph following rule patterns and returns
        inferred edges with confidence scores and evidence paths.

        Args:
            start_vertex: Vertex ID to apply rules from.
            rules: List of rule dicts, each with 'antecedent' (list of
                edge types), 'consequent' (inferred edge type), and
                optional 'min_confidence'. If None, uses built-in defaults.
            max_inferences: Maximum inferred edges to return (default 50).

        Returns:
            Dict with 'inferences' (list of {source, target, edge_type,
            evidence_path, confidence, rule}), 'rules_applied',
            'inference_count', and 'vertices_examined'.

        Example::

            # Use default rules
            result = client.infer_edges(start_vertex="neural-networks")

            # Custom rules
            result = client.infer_edges(
                start_vertex="auth-service",
                rules=[
                    {"antecedent": ["calls", "calls"], "consequent": "TRANSITIVELY_CALLS"},
                    {"antecedent": ["depends_on", "depends_on"], "consequent": "TRANSITIVELY_DEPENDS"},
                ],
            )
        """
        body: dict[str, Any] = {
            "start_vertex": start_vertex,
            "max_inferences": max_inferences,
        }
        if rules is not None:
            body["rules"] = rules
        return self._request("POST", "/query/symbolic", json=body, timeout=120)

    def discover_rules(
        self,
        max_rules: int = 10,
        sample_size: int = 1000,
    ) -> dict:
        """Discover inference rules from graph structure by sampling edge-type patterns.

        Samples vertices and finds common 2-hop edge-type combinations,
        returning them as candidate rules ordered by frequency. Use
        the discovered rules with ``infer_edges()``.

        Args:
            max_rules: Maximum rules to return (default 10).
            sample_size: Number of vertices to sample (default 1000).

        Returns:
            Dict with 'rules' (list of {antecedent, consequent,
            min_confidence}) and 'count'.

        Example::

            rules = client.discover_rules(max_rules=5)
            for r in rules["rules"]:
                print(f"{r['antecedent']} -> {r['consequent']}")

            # Apply discovered rules
            result = client.infer_edges(
                start_vertex="my-vertex",
                rules=rules["rules"],
            )
        """
        return self._request("POST", "/query/symbolic/discover", json={
            "max_rules": max_rules,
            "sample_size": sample_size,
        }, timeout=120)

    def hyperbolic_search(
        self,
        query: str | None = None,
        embedding: list[float] | None = None,
        top_k: int = 10,
    ) -> dict:
        """Search using hyperbolic distance in the Poincare ball model.

        Maps embeddings to hyperbolic space where hierarchical
        relationships are naturally preserved. Parent concepts are
        "closer to the center" and child concepts are "near the boundary."

        Results include hierarchy information: each match reports its
        depth (distance from origin) and whether it is an ancestor
        (more general) or descendant (more specific) relative to the query.

        Args:
            query: Natural language query (embedded server-side via Vertex AI).
            embedding: Raw query vector (alternative to query).
            top_k: Number of nearest results to return (default 10).

        Returns:
            Dict with 'matches' (list of {vertex_id, hyperbolic_distance,
            hyperbolic_similarity, hierarchy_depth, is_ancestor}),
            'query_depth', and 'match_count'.

        Example::

            result = client.hyperbolic_search(
                query="neural network architectures",
                top_k=20,
            )
            ancestors = [m for m in result["matches"] if m["is_ancestor"]]
            descendants = [m for m in result["matches"] if not m["is_ancestor"]]
            print(f"Ancestors (more general): {len(ancestors)}")
            print(f"Descendants (more specific): {len(descendants)}")
        """
        if not query and not embedding:
            raise ValueError("Provide either query (text) or embedding (vector)")
        body: dict[str, Any] = {"top_k": top_k}
        if query is not None:
            body["query_text"] = query
        if embedding is not None:
            body["query_vector"] = embedding
        return self._request("POST", "/query/hyperbolic", json=body, timeout=60)

    # ------------------------------------------------------------------
    # Graph pattern queries
    # ------------------------------------------------------------------

    def find_path(
        self,
        source: str,
        target: str,
        edge_type: str | None = None,
        max_depth: int = 5,
        find_all: bool = False,
        max_paths: int = 10,
    ) -> dict:
        """Find paths between two vertices.

        Args:
            source: Source vertex ID.
            target: Target vertex ID.
            edge_type: Edge type to follow (optional).
            max_depth: Maximum path length (default 5).
            find_all: If True, find all paths (default: shortest only).
            max_paths: Maximum paths to return when find_all=True.

        Returns:
            Dict with 'paths' (list of vertex ID lists) and 'count'.
        """
        body: dict[str, Any] = {
            "source": source, "target": target,
            "max_depth": max_depth, "find_all": find_all, "max_paths": max_paths,
        }
        if edge_type is not None:
            body["edge_type"] = edge_type
        return self._request("POST", "/query/path", json=body)

    def find_intersection(
        self,
        anchor_vertices: list[str],
        edge_types: list[str] | None = None,
        direction: str = "both",
    ) -> dict:
        """Find vertices connected to ALL anchor vertices.

        Args:
            anchor_vertices: List of vertex IDs that results must connect to.
            edge_types: Edge types to follow (optional).
            direction: "outgoing", "incoming", or "both" (default).

        Returns:
            Dict with 'vertices' (list of matching IDs) and 'count'.
        """
        body: dict[str, Any] = {
            "anchor_vertices": anchor_vertices,
            "edge_types": edge_types or [],
            "direction": direction,
        }
        return self._request("POST", "/query/intersection", json=body)

    def find_triangles(
        self,
        vertex_id: str,
        edge_type: str | None = None,
        max_triangles: int = 100,
    ) -> dict:
        """Find triangles involving a vertex.

        Args:
            vertex_id: Center vertex ID.
            edge_type: Edge type filter (optional).
            max_triangles: Maximum triangles to return (default 100).

        Returns:
            Dict with 'triangles' (list of [A,B,C] vertex ID triples) and 'count'.
        """
        body: dict[str, Any] = {"vertex_id": vertex_id, "max_triangles": max_triangles}
        if edge_type is not None:
            body["edge_type"] = edge_type
        return self._request("POST", "/query/triangles", json=body)

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def configure_auto_embed(
        self,
        model: str = "text-embedding-005",
        provider: str = "vertex-ai",
        text_properties: list[str] | None = None,
        min_text_length: int = 10,
    ) -> dict:
        """Configure automatic embedding generation for text vertices.

        When enabled, new vertices with text properties will automatically
        get embeddings generated during minor compaction.

        Args:
            model: Embedding model name.
            provider: Embedding provider (vertex-ai, openai).
            text_properties: Property names to treat as text sources.
            min_text_length: Minimum text length to trigger embedding.

        Returns:
            API response confirming configuration.
        """
        body: dict[str, Any] = {
            "model": model,
            "provider": provider,
            "text_properties": text_properties or [],
            "min_text_length": min_text_length,
        }
        return self._request("POST", "/configure/auto-embed", json=body)

    def configure_semantic_edges(
        self,
        similarity_threshold: float = 0.85,
        max_edges_per_vertex: int = 10,
    ) -> dict:
        """Configure automatic semantic edge creation.

        During major compaction, vertices with similar embeddings will
        automatically get SIMILAR_TO edges.

        Args:
            similarity_threshold: Minimum cosine similarity (default 0.85).
            max_edges_per_vertex: Maximum edges per vertex (default 10).

        Returns:
            API response confirming configuration.
        """
        return self._request("POST", "/configure/semantic-edges", json={
            "similarity_threshold": similarity_threshold,
            "max_edges_per_vertex": max_edges_per_vertex,
        })

    def configure_tiered_storage(
        self,
        enabled: bool,
        local_volume: str | None = None,
        cloud_volume: str | None = None,
    ) -> dict:
        """Enable or disable tiered storage.

        When enabled, minor compactions write to fast local storage and
        major compactions migrate data to durable cloud storage.

        Args:
            enabled: True to enable, False to disable.
            local_volume: Local volume URI (e.g., "file:///mnt/nvme/accumulo").
            cloud_volume: Cloud volume URI (e.g., "gs://bucket/accumulo").

        Returns:
            Dict with status and configuration.
        """
        body: dict[str, Any] = {"enabled": enabled}
        if local_volume is not None:
            body["local_volume"] = local_volume
        if cloud_volume is not None:
            body["cloud_volume"] = cloud_volume
        return self._request("POST", "/configure/tiered-storage", json=body)

    # ------------------------------------------------------------------
    # Embedding evolution & continuous learning
    # ------------------------------------------------------------------

    def track_evolution(
        self,
        vertex_id: str,
        max_versions: int = 10,
        significance_threshold: float = 0.1,
    ) -> dict:
        """Track how a vertex's embedding has changed over time.

        Returns drift metrics computed from historical embedding snapshots.
        Significant drift may indicate semantic evolution in the underlying
        data, concept shifts, or data quality issues.

        Args:
            vertex_id: Vertex to track.
            max_versions: Maximum historical snapshots to analyze (default 10).
            significance_threshold: Total drift above this value is flagged
                as significant (default 0.1).

        Returns:
            Dict with 'vertex_id', 'total_drift', 'drift_rate', 'significant',
            'snapshot_count', and 'history' (list of snapshots with timestamps
            and per-step drift values).

        Example::

            result = client.track_evolution("product:widget-x")
            if result["significant"]:
                print(f"Embedding drifted {result['total_drift']:.4f}")
        """
        body: dict[str, Any] = {
            "vertex_id": vertex_id,
            "max_versions": max_versions,
            "significance_threshold": significance_threshold,
        }
        return self._request("POST", "/query/evolution", json=body, timeout=60)

    def enrich_embeddings(
        self,
        learning_rate: float = 0.2,
        max_neighbors: int = 50,
        batch_size: int = 100,
    ) -> dict:
        """Enrich vertex embeddings based on graph neighborhood structure.

        For each vertex with an embedding, blends it with the mean of its
        neighbors' embeddings:

            new = (1 - learning_rate) * original + learning_rate * mean(neighbors)

        This makes vector search more graph-aware -- vertices connected to
        semantically similar neighbors get reinforced embeddings, while
        vertices with diverse connections develop richer contextual vectors.

        Run periodically as a background maintenance task.

        Args:
            learning_rate: How much neighbor influence to absorb (0.0-1.0).
                Default 0.2 means 80% original + 20% neighbor average.
            max_neighbors: Maximum neighbors to average per vertex (default 50).
            batch_size: Vertices processed per internal batch (default 100).

        Returns:
            Dict with 'vertices_scanned', 'vertices_enriched',
            'vertices_skipped', and 'avg_neighbor_count'.

        Example::

            result = client.enrich_embeddings(learning_rate=0.15)
            print(f"Enriched {result['vertices_enriched']} vertices")
        """
        body: dict[str, Any] = {
            "learning_rate": learning_rate,
            "max_neighbors": max_neighbors,
            "batch_size": batch_size,
        }
        return self._request("POST", "/admin/enrich", json=body, timeout=300)

    # ------------------------------------------------------------------
    # Insights
    # ------------------------------------------------------------------

    def get_anomalies(
        self,
        authorizations: str | None = None,
    ) -> dict:
        """Get vertices flagged as anomalous by embedding analysis.

        Returns:
            Dict with 'anomalies' list of flagged vertices and scores.
        """
        params: dict[str, str] | None = None
        if authorizations is not None:
            params = {"authorizations": authorizations}
        return self._request("GET", "/insights/anomalies", params=params)

    def get_top_ranked(
        self,
        authorizations: str | None = None,
    ) -> dict:
        """Get top-ranked vertices by PageRank score.

        Returns:
            Dict with 'ranks' list of vertices and their scores.
        """
        params: dict[str, str] | None = None
        if authorizations is not None:
            params = {"authorizations": authorizations}
        return self._request("GET", "/insights/ranks", params=params)

    def get_processing_status(self) -> dict:
        """Get the status of pending marker processing queue.

        Returns:
            Dict with queue sizes for each marker type.
        """
        return self._request("GET", "/insights/processing-queue")

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict:
        """Send an HTTP request and return the parsed JSON response.

        Raises:
            AuthenticationError: On 401 or 403 responses.
            NotFoundError: On 404 responses.
            ValidationError: On 400 or 422 responses.
            VeculoError: On any other non-2xx response.
        """
        response = self._client.request(method, path, params=params, json=json,
                                        timeout=timeout)

        if response.is_success:
            if response.status_code == 204:
                return {}
            return response.json()

        # Parse error body
        try:
            error_body = response.json()
            message = error_body.get("error", {}).get("message", response.text)
        except Exception:
            error_body = None
            message = response.text or f"HTTP {response.status_code}"

        status = response.status_code
        if status in (401, 403):
            raise AuthenticationError(message, status_code=status, body=error_body)
        if status == 404:
            raise NotFoundError(message, status_code=status, body=error_body)
        if status in (400, 422):
            raise ValidationError(message, status_code=status, body=error_body)
        raise VeculoError(message, status_code=status, body=error_body)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "VeculoClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return (
            f"VeculoClient(endpoint={self.endpoint!r}, "
            f"cluster_id={self.cluster_id!r})"
        )
