"""
Tests for diffwatch.
Run with: pytest tests/ -v
"""

import json
import time
import threading
from pathlib import Path

import pytest

from diffwatch import DiffWatch, FileEvent, DiffResult
from diffwatch.diff import line_diff, word_diff, word_diff_inline, json_patch


# ── line_diff ─────────────────────────────────────────────────────────────────

class TestLineDiff:
    def test_equal_content(self):
        chunks = line_diff("hello\nworld\n", "hello\nworld\n")
        types = {c["type"] for c in chunks}
        assert types == {"equal"}

    def test_inserted_line(self):
        chunks = line_diff("a\nb\n", "a\nnew\nb\n")
        types = [c["type"] for c in chunks if c["type"] != "equal"]
        assert "insert" in types

    def test_deleted_line(self):
        chunks = line_diff("a\nb\nc\n", "a\nc\n")
        types = [c["type"] for c in chunks if c["type"] != "equal"]
        assert "delete" in types

    def test_replaced_line(self):
        chunks = line_diff("a\nold\nb\n", "a\nnew\nb\n")
        types = [c["type"] for c in chunks if c["type"] != "equal"]
        assert len(types) > 0

    def test_empty_old(self):
        chunks = line_diff("", "new line\n")
        assert any(c["type"] == "insert" for c in chunks)

    def test_empty_new(self):
        chunks = line_diff("old line\n", "")
        assert any(c["type"] == "delete" for c in chunks)

    def test_line_numbers(self):
        chunks = line_diff("a\nb\nc\n", "a\nx\nc\n")
        for c in chunks:
            assert "old_start" in c
            assert "new_start" in c


# ── word_diff ─────────────────────────────────────────────────────────────────

class TestWordDiff:
    def test_equal(self):
        chunks = word_diff("hello world", "hello world")
        assert all(c["type"] == "equal" for c in chunks)

    def test_word_inserted(self):
        chunks = word_diff("hello", "hello world")
        types = {c["type"] for c in chunks}
        assert "insert" in types

    def test_word_deleted(self):
        chunks = word_diff("hello world", "hello")
        types = {c["type"] for c in chunks}
        assert "delete" in types

    def test_word_replaced(self):
        chunks = word_diff("hello world", "hello Python")
        types = {c["type"] for c in chunks}
        assert "delete" in types
        assert "insert" in types

    def test_inline_format(self):
        result = word_diff_inline("hello world", "hello Python")
        assert "[-world-]" in result
        assert "[+Python+]" in result

    def test_custom_markers(self):
        result = word_diff_inline("a b", "a c",
                                  delete_fmt="<del>{value}</del>",
                                  insert_fmt="<ins>{value}</ins>")
        assert "<del>" in result
        assert "<ins>" in result


# ── json_patch ────────────────────────────────────────────────────────────────

class TestJsonPatch:
    def test_no_changes(self):
        ops = json_patch({"a": 1}, {"a": 1})
        assert ops == []

    def test_replace_value(self):
        ops = json_patch({"a": 1}, {"a": 2})
        assert any(o["op"] == "replace" and o["path"] == "/a" for o in ops)

    def test_add_key(self):
        ops = json_patch({"a": 1}, {"a": 1, "b": 2})
        assert any(o["op"] == "add" and o["path"] == "/b" for o in ops)

    def test_remove_key(self):
        ops = json_patch({"a": 1, "b": 2}, {"a": 1})
        assert any(o["op"] == "remove" and o["path"] == "/b" for o in ops)

    def test_nested_change(self):
        ops = json_patch({"a": {"b": 1}}, {"a": {"b": 2}})
        assert any(o["op"] == "replace" and "/a/b" in o["path"] for o in ops)

    def test_list_add(self):
        ops = json_patch({"items": [1, 2]}, {"items": [1, 2, 3]})
        assert any(o["op"] == "add" for o in ops)

    def test_list_remove(self):
        ops = json_patch({"items": [1, 2, 3]}, {"items": [1, 2]})
        assert any(o["op"] == "remove" for o in ops)

    def test_scalar_replace(self):
        ops = json_patch("old", "new")
        assert ops == [{"op": "replace", "path": "/", "value": "new"}]

    def test_special_chars_escaped(self):
        ops = json_patch({"a/b": 1}, {"a/b": 2})
        assert any("~1" in o["path"] for o in ops)


# ── DiffResult ────────────────────────────────────────────────────────────────

class TestDiffResult:
    def test_line_diff(self):
        d = DiffResult("/tmp/f", "a\nb\n", "a\nc\n")
        chunks = d.line_diff()
        assert any(c["type"] != "equal" for c in chunks)

    def test_unified_diff(self):
        d = DiffResult("/tmp/f", "a\nb\n", "a\nc\n")
        u = d.unified_diff()
        assert "---" in u or "+++" in u or "-b" in u

    def test_word_diff(self):
        d = DiffResult("/tmp/f", "hello world", "hello Python")
        chunks = d.word_diff()
        assert any(c["type"] in ("insert", "delete") for c in chunks)

    def test_json_patch(self):
        d = DiffResult("/tmp/f", '{"a": 1}', '{"a": 2}')
        ops = d.json_patch()
        assert any(o["op"] == "replace" for o in ops)

    def test_json_patch_invalid_raises(self):
        d = DiffResult("/tmp/f", "not json", "also not json")
        with pytest.raises(ValueError):
            d.json_patch()

    def test_summary(self):
        d = DiffResult("/tmp/f", "a\nb\n", "a\nc\nd\n")
        s = d.summary()
        assert "lines_added" in s
        assert "lines_removed" in s
        assert s["path"] == "/tmp/f"


# ── DiffWatch ─────────────────────────────────────────────────────────────────

class TestDiffWatch:
    def test_watch_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello\n")
        watcher = DiffWatch(interval=0.1)
        watcher.watch(str(f))
        assert str(f) in watcher._watched_files

    def test_watch_nonexistent_raises(self):
        watcher = DiffWatch()
        with pytest.raises(FileNotFoundError):
            watcher.watch("/nonexistent/file.txt")

    def test_watch_directory(self, tmp_path):
        (tmp_path / "a.txt").write_text("content")
        watcher = DiffWatch(interval=0.1)
        watcher.watch(str(tmp_path))
        assert any(str(tmp_path) in p for p in watcher._watched_files)

    def test_detects_modification(self, tmp_path):
        f = tmp_path / "config.txt"
        f.write_text("original\n")
        events = []
        watcher = DiffWatch(interval=0.05)
        watcher.watch(str(f))
        watcher.on_change(lambda e: events.append(e))
        watcher.start()
        time.sleep(0.1)
        f.write_text("modified\n")
        time.sleep(0.3)
        watcher.stop()
        assert len(events) >= 1
        assert events[0].type == "modified"

    def test_detects_deletion(self, tmp_path):
        f = tmp_path / "todelete.txt"
        f.write_text("bye\n")
        events = []
        watcher = DiffWatch(interval=0.05)
        watcher.watch(str(f))
        watcher.on_change(lambda e: events.append(e))
        watcher.start()
        time.sleep(0.1)
        f.unlink()
        time.sleep(0.3)
        watcher.stop()
        deleted = [e for e in events if e.type == "deleted"]
        assert len(deleted) >= 1

    def test_check_once(self, tmp_path):
        f = tmp_path / "once.txt"
        f.write_text("v1\n")
        watcher = DiffWatch()
        watcher.watch(str(f))
        f.write_text("v2\n")
        events = watcher.check_once()
        assert len(events) == 1
        assert events[0].type == "modified"

    def test_diff_content_correct(self, tmp_path):
        f = tmp_path / "diff.txt"
        f.write_text("line1\nline2\n")
        events = []
        watcher = DiffWatch(interval=0.05)
        watcher.watch(str(f))
        watcher.on_change(lambda e: events.append(e))
        watcher.start()
        time.sleep(0.1)
        f.write_text("line1\nline3\n")
        time.sleep(0.3)
        watcher.stop()
        assert len(events) >= 1
        diff = events[0].diff
        assert diff.old_content == "line1\nline2\n"
        assert diff.new_content == "line1\nline3\n"

    def test_multiple_callbacks(self, tmp_path):
        f = tmp_path / "multi.txt"
        f.write_text("a\n")
        results = []
        watcher = DiffWatch(interval=0.05)
        watcher.watch(str(f))
        watcher.on_change(lambda e: results.append("cb1"))
        watcher.on_change(lambda e: results.append("cb2"))
        watcher.start()
        time.sleep(0.1)
        f.write_text("b\n")
        time.sleep(0.3)
        watcher.stop()
        assert "cb1" in results
        assert "cb2" in results
