"""
diffwatch.core
--------------
File and directory watcher with structured diff output and callbacks.
"""

import json
import os
import threading
import time
import hashlib
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from .diff import line_diff, word_diff, json_patch, line_diff_unified


@dataclass
class DiffResult:
    """Result of a file change event."""
    path: str
    old_content: str
    new_content: str
    changed_at: datetime = field(default_factory=datetime.now)

    def line_diff(self, context: int = 3) -> List[dict]:
        """Return structured line-level diff."""
        return line_diff(self.old_content, self.new_content, context=context)

    def word_diff(self) -> List[dict]:
        """Return structured word-level diff."""
        return word_diff(self.old_content, self.new_content)

    def unified_diff(self, context: int = 3) -> str:
        """Return unified diff string (like diff -u)."""
        return line_diff_unified(
            self.old_content, self.new_content,
            fromfile=f"{self.path} (old)",
            tofile=f"{self.path} (new)",
            context=context,
        )

    def json_patch(self) -> List[dict]:
        """
        Return RFC 6902 JSON Patch ops.
        Only works if the file content is valid JSON.
        Raises ValueError if content is not JSON.
        """
        try:
            old = json.loads(self.old_content) if self.old_content else {}
            new = json.loads(self.new_content)
        except json.JSONDecodeError as e:
            raise ValueError(f"File is not valid JSON: {e}")
        return json_patch(old, new)

    def summary(self) -> dict:
        """Return a brief summary of changes."""
        changes = self.line_diff()
        added = sum(len(c["new_lines"]) for c in changes if c["type"] in ("insert", "replace"))
        removed = sum(len(c["old_lines"]) for c in changes if c["type"] in ("delete", "replace"))
        return {
            "path": self.path,
            "changed_at": self.changed_at.isoformat(),
            "lines_added": added,
            "lines_removed": removed,
        }


@dataclass
class FileEvent:
    """Represents a file system event."""
    type: str            # "modified" | "created" | "deleted"
    path: str
    diff: Optional[DiffResult] = None
    occurred_at: datetime = field(default_factory=datetime.now)

    def __repr__(self):
        return f"<FileEvent type={self.type!r} path={self.path!r}>"


# ── DiffWatch ─────────────────────────────────────────────────────────────────

class DiffWatch:
    """
    Watch files and directories for changes.
    Emits structured diffs and fires callbacks on every change.

    Parameters
    ----------
    interval : float
        Polling interval in seconds. Default: 1.0.
    ignore_patterns : list[str]
        Glob-style patterns to ignore (e.g. ["*.pyc", ".git/*"]).

    Example
    -------
    >>> watcher = DiffWatch()
    >>>
    >>> @watcher.on_change
    ... def handle(event):
    ...     print(event.diff.unified_diff())
    >>>
    >>> watcher.watch("config.yaml")
    >>> watcher.watch("./src", recursive=True)
    >>> watcher.start()
    """

    def __init__(
        self,
        interval: float = 1.0,
        ignore_patterns: Optional[List[str]] = None,
    ):
        self._interval = interval
        self._ignore_patterns = ignore_patterns or [
            "*.pyc", "__pycache__/*", ".git/*", "*.swp", ".DS_Store",
        ]
        self._watched_files: Dict[str, str] = {}   # path → last content
        self._watched_hashes: Dict[str, str] = {}  # path → md5 hash
        self._watched_dirs: List[tuple] = []       # (path, recursive, extensions)
        self._callbacks: List[Callable[[FileEvent], None]] = []
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._running = False

    # ── Registration ──────────────────────────────────────────────────────────

    def watch(
        self,
        path: str,
        recursive: bool = False,
        extensions: Optional[List[str]] = None,
    ) -> "DiffWatch":
        """
        Watch a file or directory.

        Parameters
        ----------
        path : str
            File or directory path to watch.
        recursive : bool
            If path is a directory, watch subdirectories too.
        extensions : list[str], optional
            Only watch files with these extensions (e.g. [".yaml", ".json"]).

        Returns self for chaining.
        """
        p = Path(path).resolve()

        if p.is_file():
            self._register_file(str(p))
        elif p.is_dir():
            self._watched_dirs.append((str(p), recursive, extensions or []))
            self._scan_dir(str(p), recursive, extensions or [])
        else:
            raise FileNotFoundError(f"Path not found: {path}")

        return self

    def on_change(self, func: Callable[[FileEvent], None]) -> Callable:
        """
        Register a callback for file change events.
        Can be used as a decorator or called directly.

        The callback receives a FileEvent with a DiffResult attached.
        """
        self._callbacks.append(func)
        return func

    def on_create(self, func: Callable[[FileEvent], None]) -> Callable:
        """Register a callback for file creation events."""
        def wrapper(event: FileEvent):
            if event.type == "created":
                func(event)
        self._callbacks.append(wrapper)
        return func

    def on_delete(self, func: Callable[[FileEvent], None]) -> Callable:
        """Register a callback for file deletion events."""
        def wrapper(event: FileEvent):
            if event.type == "deleted":
                func(event)
        self._callbacks.append(wrapper)
        return func

    # ── Control ───────────────────────────────────────────────────────────────

    def start(self, block: bool = False) -> "DiffWatch":
        """
        Start watching in a background thread.

        Parameters
        ----------
        block : bool
            If True, block until Ctrl+C. Default: False.
        """
        if self._running:
            return self
        self._stop_event.clear()
        self._running = True
        self._thread = threading.Thread(
            target=self._loop, name="diffwatch", daemon=True
        )
        self._thread.start()

        if block:
            try:
                while self._running:
                    time.sleep(0.5)
            except KeyboardInterrupt:
                self.stop()
        return self

    def stop(self) -> "DiffWatch":
        """Stop the watcher."""
        self._stop_event.set()
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        return self

    def check_once(self) -> List[FileEvent]:
        """
        Manually poll for changes once (without starting the background thread).
        Returns list of FileEvent objects for any changes found.
        """
        events = []
        # Refresh directory scans
        for dir_path, recursive, extensions in self._watched_dirs:
            self._scan_dir(dir_path, recursive, extensions)

        for path in list(self._watched_files.keys()):
            event = self._check_file(path)
            if event:
                events.append(event)
                self._fire(event)
        return events

    # ── Internal ──────────────────────────────────────────────────────────────

    def _register_file(self, path: str):
        if path not in self._watched_files:
            try:
                content = Path(path).read_text(errors="replace")
            except Exception:
                content = ""
            self._watched_files[path] = content
            self._watched_hashes[path] = _md5(content)

    def _scan_dir(self, dir_path: str, recursive: bool, extensions: List[str]):
        pattern = "**/*" if recursive else "*"
        for p in Path(dir_path).glob(pattern):
            if not p.is_file():
                continue
            if extensions and p.suffix not in extensions:
                continue
            if self._should_ignore(str(p)):
                continue
            self._register_file(str(p))

    def _should_ignore(self, path: str) -> bool:
        from fnmatch import fnmatch
        name = Path(path).name
        for pattern in self._ignore_patterns:
            if fnmatch(name, pattern) or fnmatch(path, pattern):
                return True
        return False

    def _check_file(self, path: str) -> Optional[FileEvent]:
        p = Path(path)

        # Deleted
        if not p.exists():
            old_content = self._watched_files.pop(path, "")
            self._watched_hashes.pop(path, None)
            return FileEvent(
                type="deleted", path=path,
                diff=DiffResult(path, old_content, "")
            )

        try:
            new_content = p.read_text(errors="replace")
        except Exception:
            return None

        new_hash = _md5(new_content)
        old_hash = self._watched_hashes.get(path, "")

        if new_hash != old_hash:
            old_content = self._watched_files[path]
            self._watched_files[path] = new_content
            self._watched_hashes[path] = new_hash
            return FileEvent(
                type="modified", path=path,
                diff=DiffResult(path, old_content, new_content)
            )

        return None

    def _loop(self):
        while not self._stop_event.is_set():
            # Refresh directory scans for new files
            for dir_path, recursive, extensions in self._watched_dirs:
                self._scan_dir(dir_path, recursive, extensions)

            for path in list(self._watched_files.keys()):
                event = self._check_file(path)
                if event:
                    self._fire(event)

            self._stop_event.wait(self._interval)

    def _fire(self, event: FileEvent):
        for cb in self._callbacks:
            try:
                cb(event)
            except Exception as e:
                import traceback
                traceback.print_exc()


def _md5(content: str) -> str:
    return hashlib.md5(content.encode(errors="replace")).hexdigest()
