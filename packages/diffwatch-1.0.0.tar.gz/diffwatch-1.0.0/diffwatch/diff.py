"""
diffwatch.diff
--------------
Diff algorithms: line-level, word-level, and JSON patch (RFC 6902).
"""

import difflib
import json
import re
from typing import Any, Dict, List, Optional


# ── Line diff ─────────────────────────────────────────────────────────────────

def line_diff(old: str, new: str, context: int = 3) -> List[dict]:
    """
    Compute a line-level diff between two strings.

    Returns a list of change dicts:
      {"type": "equal"|"insert"|"delete"|"replace",
       "old_lines": [...], "new_lines": [...],
       "old_start": int, "new_start": int}

    Parameters
    ----------
    old : str
        Original content.
    new : str
        New content.
    context : int
        Number of unchanged context lines to include around changes.
    """
    old_lines = old.splitlines(keepends=True)
    new_lines = new.splitlines(keepends=True)
    matcher = difflib.SequenceMatcher(None, old_lines, new_lines)

    changes = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        changes.append({
            "type": tag,
            "old_lines": [l.rstrip("\n") for l in old_lines[i1:i2]],
            "new_lines": [l.rstrip("\n") for l in new_lines[j1:j2]],
            "old_start": i1 + 1,
            "new_start": j1 + 1,
        })
    return changes


def line_diff_unified(old: str, new: str,
                      fromfile: str = "old", tofile: str = "new",
                      context: int = 3) -> str:
    """Return a unified diff string (like `diff -u`)."""
    old_lines = old.splitlines(keepends=True)
    new_lines = new.splitlines(keepends=True)
    return "".join(difflib.unified_diff(
        old_lines, new_lines,
        fromfile=fromfile, tofile=tofile,
        n=context,
    ))


# ── Word diff ─────────────────────────────────────────────────────────────────

def word_diff(old: str, new: str) -> List[dict]:
    """
    Compute a word-level diff between two strings.

    Returns list of:
      {"type": "equal"|"insert"|"delete", "value": str}
    """
    old_words = _tokenize(old)
    new_words = _tokenize(new)
    matcher = difflib.SequenceMatcher(None, old_words, new_words)

    result = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            result.append({"type": "equal", "value": "".join(old_words[i1:i2])})
        elif tag == "insert":
            result.append({"type": "insert", "value": "".join(new_words[j1:j2])})
        elif tag == "delete":
            result.append({"type": "delete", "value": "".join(old_words[i1:i2])})
        elif tag == "replace":
            result.append({"type": "delete", "value": "".join(old_words[i1:i2])})
            result.append({"type": "insert", "value": "".join(new_words[j1:j2])})
    return result


def word_diff_inline(old: str, new: str,
                     delete_fmt: str = "[-{value}-]",
                     insert_fmt: str = "[+{value}+]") -> str:
    """
    Return an inline word diff string with configurable markers.

    Example output:
      "Hello [-world-] [+Python+]!"
    """
    parts = []
    for chunk in word_diff(old, new):
        if chunk["type"] == "equal":
            parts.append(chunk["value"])
        elif chunk["type"] == "delete":
            parts.append(delete_fmt.format(value=chunk["value"]))
        elif chunk["type"] == "insert":
            parts.append(insert_fmt.format(value=chunk["value"]))
    return "".join(parts)


def _tokenize(text: str) -> List[str]:
    """Split text into word + whitespace tokens for word-level diffing."""
    return re.split(r"(\s+)", text)


# ── JSON patch (RFC 6902) ─────────────────────────────────────────────────────

def json_patch(old: Any, new: Any, path: str = "") -> List[dict]:
    """
    Compute a JSON Patch (RFC 6902) between two JSON-serializable objects.

    Returns a list of patch operations:
      {"op": "add"|"remove"|"replace", "path": "/key/subkey", "value": ...}

    Parameters
    ----------
    old : Any
        Original JSON-serializable object.
    new : Any
        New JSON-serializable object.
    path : str
        Base JSON Pointer path (used for recursion).
    """
    ops = []

    if isinstance(old, dict) and isinstance(new, dict):
        # Removed keys
        for key in old:
            if key not in new:
                ops.append({"op": "remove", "path": f"{path}/{_escape(key)}"})

        # Added or changed keys
        for key in new:
            child_path = f"{path}/{_escape(key)}"
            if key not in old:
                ops.append({"op": "add", "path": child_path, "value": new[key]})
            else:
                ops.extend(json_patch(old[key], new[key], child_path))

    elif isinstance(old, list) and isinstance(new, list):
        max_len = max(len(old), len(new))
        for i in range(max_len):
            child_path = f"{path}/{i}"
            if i >= len(old):
                ops.append({"op": "add", "path": child_path, "value": new[i]})
            elif i >= len(new):
                # Remove in reverse order to preserve indices
                ops.append({"op": "remove", "path": child_path})
            else:
                ops.extend(json_patch(old[i], new[i], child_path))

    else:
        if old != new:
            ops.append({"op": "replace", "path": path or "/", "value": new})

    return ops


def _escape(key: str) -> str:
    """Escape JSON Pointer special characters."""
    return str(key).replace("~", "~0").replace("/", "~1")
