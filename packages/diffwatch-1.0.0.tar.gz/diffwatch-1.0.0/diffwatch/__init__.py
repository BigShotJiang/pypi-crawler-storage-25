"""
diffwatch — File & directory watcher with structured diffs,
callbacks, JSON patch output, and a CLI tool.
"""

from .core import DiffWatch, FileEvent, DiffResult
from .diff import line_diff, word_diff, json_patch

__all__ = ["DiffWatch", "FileEvent", "DiffResult", "line_diff", "word_diff", "json_patch"]
__version__ = "1.0.0"
__author__ = "prabhay759"
