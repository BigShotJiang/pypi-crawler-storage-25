"""
diffwatch CLI
-------------
Usage:
    diffwatch myfile.yaml
    diffwatch ./src --recursive --ext .py .js
    diffwatch config.json --format json-patch
    diffwatch . --format word
"""

import argparse
import sys
import json
from pathlib import Path

from .core import DiffWatch, FileEvent


def main():
    parser = argparse.ArgumentParser(
        prog="diffwatch",
        description="Watch files/directories and show structured diffs on change.",
    )
    parser.add_argument("paths", nargs="+", help="Files or directories to watch")
    parser.add_argument(
        "--format", "-f",
        choices=["unified", "line", "word", "json-patch", "summary"],
        default="unified",
        help="Diff output format (default: unified)",
    )
    parser.add_argument(
        "--recursive", "-r", action="store_true",
        help="Watch directories recursively",
    )
    parser.add_argument(
        "--ext", nargs="+", metavar="EXT",
        help="Only watch files with these extensions (e.g. --ext .py .yaml)",
    )
    parser.add_argument(
        "--interval", "-i", type=float, default=1.0,
        help="Polling interval in seconds (default: 1.0)",
    )
    parser.add_argument(
        "--context", "-c", type=int, default=3,
        help="Context lines for unified/line diff (default: 3)",
    )
    args = parser.parse_args()

    watcher = DiffWatch(interval=args.interval)

    for path in args.paths:
        try:
            watcher.watch(path, recursive=args.recursive, extensions=args.ext)
        except FileNotFoundError as e:
            print(f"  ⚠️  {e}", file=sys.stderr)

    @watcher.on_change
    def handle(event: FileEvent):
        print(f"\n{'─'*60}")
        print(f"  {_icon(event.type)} {event.type.upper()}: {event.path}")
        print(f"  {event.occurred_at.strftime('%H:%M:%S')}")
        print(f"{'─'*60}")

        if event.type == "deleted":
            print("  File was deleted.")
            return

        diff = event.diff
        fmt = args.format

        if fmt == "unified":
            output = diff.unified_diff(context=args.context)
            if output:
                print(output, end="")
            else:
                print("  (no text changes)")

        elif fmt == "line":
            for chunk in diff.line_diff(context=args.context):
                if chunk["type"] == "equal":
                    continue
                print(f"  [{chunk['type'].upper()}] "
                      f"old:{chunk['old_start']} new:{chunk['new_start']}")
                for line in chunk["old_lines"]:
                    print(f"  - {line}")
                for line in chunk["new_lines"]:
                    print(f"  + {line}")

        elif fmt == "word":
            from .diff import word_diff_inline
            result = word_diff_inline(diff.old_content, diff.new_content)
            print(result[:2000])  # cap output

        elif fmt == "json-patch":
            try:
                ops = diff.json_patch()
                print(json.dumps(ops, indent=2))
            except ValueError as e:
                print(f"  ⚠️  {e}")

        elif fmt == "summary":
            s = diff.summary()
            print(f"  +{s['lines_added']} lines added, -{s['lines_removed']} lines removed")

    print(f"👀 diffwatch watching {len(watcher._watched_files)} file(s)...")
    print("   Press Ctrl+C to stop.\n")

    try:
        watcher.start(block=True)
    except KeyboardInterrupt:
        print("\n  Stopped.")


def _icon(event_type: str) -> str:
    return {"modified": "✏️", "created": "✅", "deleted": "🗑️"}.get(event_type, "•")


if __name__ == "__main__":
    main()
