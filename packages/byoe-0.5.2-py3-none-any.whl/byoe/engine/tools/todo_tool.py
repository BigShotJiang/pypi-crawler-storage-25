"""Todo tool — agent self-managed task list for long, multi-step work.

Safe (no filesystem/network access).  State is per-session in-memory.
Helps the agent track sub-tasks without cluttering the conversation.
"""

from .base import Tool


class TodoTool(Tool):
    name = "todo"
    description = (
        "Manage a private TODO list to track your own progress during complex, multi-step tasks. "
        "Use this to avoid forgetting steps — not to show the user a task manager. "
        "Actions: add, done, remove, list, clear."
    )
    parameters = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["add", "done", "remove", "list", "clear"],
                "description": "Operation to perform.",
            },
            "item": {
                "type": "string",
                "description": "Task description (for 'add') or task number (for 'done'/'remove').",
            },
        },
        "required": ["action"],
    }

    def __init__(self):
        # Session-scoped state; reset on Agent.reset()
        self._items: list[dict] = []   # {"text": str, "done": bool}
        self._counter = 0

    def _reset(self):
        self._items.clear()
        self._counter = 0

    def execute(self, action: str, item: str = "") -> str:
        action = action.strip().lower()

        if action == "list":
            if not self._items:
                return "TODO list is empty."
            lines = []
            for t in self._items:
                mark = "✓" if t["done"] else "○"
                lines.append(f"{t['id']}. [{mark}] {t['text']}")
            pending = sum(1 for t in self._items if not t["done"])
            lines.append(f"\n{pending}/{len(self._items)} pending")
            return "\n".join(lines)

        if action == "add":
            if not item.strip():
                return "Error: provide a task description."
            self._counter += 1
            self._items.append({"id": self._counter, "text": item.strip(), "done": False})
            return f"Added #{self._counter}: {item.strip()}"

        if action in ("done", "remove"):
            try:
                num = int(item.strip())
            except (ValueError, AttributeError):
                return f"Error: provide a task number for '{action}'."
            match = next((t for t in self._items if t["id"] == num), None)
            if not match:
                return f"Error: task #{num} not found."
            if action == "done":
                match["done"] = True
                return f"✓ Marked #{num} done: {match['text']}"
            else:
                self._items.remove(match)
                return f"Removed #{num}: {match['text']}"

        if action == "clear":
            n = len(self._items)
            self._reset()
            return f"Cleared {n} items."

        return f"Error: unknown action '{action}'. Use: add, done, remove, list, clear."
