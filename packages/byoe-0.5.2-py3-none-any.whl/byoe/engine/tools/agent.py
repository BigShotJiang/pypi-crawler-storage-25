"""Sub-agent spawning — delegate complex sub-tasks to an independent agent."""

from .base import Tool


class AgentTool(Tool):
    name = "agent"
    description = (
        "Spawn a sub-agent to handle a complex sub-task independently. "
        "The sub-agent has its own context and tool access. Use this for: "
        "researching a codebase, implementing a multi-step change in isolation, "
        "delegating to a specialist role, or any task that benefits from a fresh context window. "
        "Use the 'role' parameter to give the sub-agent a specific persona (e.g. backend architect, tester). "
        "Set inherit_crew_context=true to automatically inject the project's INSTRUCTIONS.md and crew state."
    )
    parameters = {
        "type": "object",
        "properties": {
            "task": {"type": "string", "description": "What the sub-agent should accomplish"},
            "role": {"type": "string", "description": "Optional role/persona for the sub-agent (e.g. 'You are a senior backend architect specializing in Python APIs.')"},
            "inherit_crew_context": {"type": "boolean", "description": "If true, inject the project's Crew context (INSTRUCTIONS.md, crew.yaml, resume.md) into the sub-agent. Default: true"},
        },
        "required": ["task"],
    }

    _parent_agent = None  # set by Agent.__init__

    def execute(self, task: str, role: str = "", inherit_crew_context: bool = True) -> str:
        if self._parent_agent is None:
            return "Error: agent tool not initialized (no parent agent)"

        from ..agent import Agent
        from ..prompt import system_prompt as build_system_prompt
        from ..llm import LLM

        parent = self._parent_agent

        # Build sub-agent system prompt
        if inherit_crew_context:
            # Reuse the same prompt builder so Crew context is injected
            base_tools = [t for t in parent.tools if t.name != "agent"]
            sub_system = build_system_prompt(base_tools)
        else:
            sub_system = (
                "You are a helpful AI assistant. Complete the task given to you using the available tools."
            )

        if role:
            sub_system = f"{role}\n\n{sub_system}"

        sub_llm = LLM(
            model=parent.llm.model,
            api_key=parent.llm._api_key,
            base_url=parent.llm._base_url,
            **parent.llm.extra,
        )
        sub = Agent(
            llm=sub_llm,
            tools=[t for t in parent.tools if t.name != "agent"],
            max_context_tokens=parent.context.max_tokens,
            max_rounds=20,
            system=sub_system,
        )

        try:
            result = sub.chat(task)
            if len(result) > 5000:
                # Summarise rather than hard-truncate so the main agent gets
                # a coherent, complete picture of what the sub-agent did.
                result = _summarize_sub_output(result, parent.llm)
            return f"[Sub-agent completed]\n{result}"
        except Exception as e:
            return f"Sub-agent error: {e}"


def _summarize_sub_output(text: str, llm) -> str:
    """Ask the LLM to compress a long sub-agent result into a concise summary.

    Preserves: key decisions, file paths edited, errors encountered, final
    answer / output.  Falls back to head+tail truncation if the LLM call fails.
    """
    try:
        resp = llm.chat(
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a summarisation assistant. "
                        "Compress the following sub-agent output into at most 1500 words. "
                        "Preserve: key decisions, file paths created/edited, commands run, "
                        "errors encountered, and the final result/answer. "
                        "Drop: verbose command output, repeated content, boilerplate."
                    ),
                },
                {"role": "user", "content": text[:20000]},
            ],
        )
        return f"[Sub-agent output summarised — original was {len(text)} chars]\n{resp.content}"
    except Exception:
        # Fallback: head + tail to preserve both context and conclusion
        half = 2000
        return (
            text[:half]
            + f"\n\n... [{len(text) - half * 2} chars omitted — LLM summary unavailable] ...\n\n"
            + text[-half:]
        )
