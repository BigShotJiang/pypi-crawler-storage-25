"""Directory listing tool — structured tree output.

Safer and more token-efficient than `bash ls -la` for exploring project structure.
"""

import os
from pathlib import Path
from .base import Tool

MAX_ENTRIES = 200   # hard cap to avoid flooding context


class ListDirTool(Tool):
    name = "list_dir"
    description = (
        "List the contents of a directory as a structured tree. "
        "Shows file sizes and types. More reliable than bash `ls` for exploring project structure. "
        f"Capped at {MAX_ENTRIES} entries."
    )
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "Directory path to list. Defaults to current working directory.",
            },
            "depth": {
                "type": "integer",
                "description": "How many levels deep to recurse. 1 = immediate children only. Default: 2.",
            },
            "show_hidden": {
                "type": "boolean",
                "description": "Include hidden files/directories (starting with dot). Default: false.",
            },
        },
        "required": [],
    }

    def execute(
        self,
        path: str = ".",
        depth: int = 2,
        show_hidden: bool = False,
    ) -> str:
        root = Path(path).expanduser().resolve()
        if not root.exists():
            return f"Error: path not found: {path}"
        if not root.is_dir():
            return f"Error: {path} is not a directory"

        depth = max(1, min(int(depth), 6))   # clamp 1–6

        lines: list[str] = [str(root)]
        count = [0]

        def _walk(directory: Path, prefix: str, level: int) -> None:
            if level > depth or count[0] >= MAX_ENTRIES:
                return
            try:
                entries = sorted(
                    directory.iterdir(),
                    key=lambda e: (e.is_file(), e.name.lower()),
                )
            except PermissionError:
                lines.append(f"{prefix}└── [permission denied]")
                return

            visible = [e for e in entries if show_hidden or not e.name.startswith(".")]

            for idx, entry in enumerate(visible):
                if count[0] >= MAX_ENTRIES:
                    lines.append(f"{prefix}└── ... [truncated]")
                    return
                is_last   = idx == len(visible) - 1
                connector = "└── " if is_last else "├── "
                extender  = "    " if is_last else "│   "

                if entry.is_symlink():
                    target = os.readlink(entry)
                    lines.append(f"{prefix}{connector}{entry.name} -> {target}")
                elif entry.is_dir():
                    lines.append(f"{prefix}{connector}{entry.name}/")
                    count[0] += 1
                    _walk(entry, prefix + extender, level + 1)
                else:
                    try:
                        size = entry.stat().st_size
                        size_str = _fmt_size(size)
                    except OSError:
                        size_str = "?"
                    lines.append(f"{prefix}{connector}{entry.name}  ({size_str})")
                    count[0] += 1

        _walk(root, "", 1)

        summary = f"\n{count[0]} items listed"
        if count[0] >= MAX_ENTRIES:
            summary += f" (capped at {MAX_ENTRIES})"
        return "\n".join(lines) + summary


def _fmt_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"
