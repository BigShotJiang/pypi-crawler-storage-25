"""Diff tool — show changes between file versions or between two files.

Use cases:
  - diff_file(path="src/foo.py")          → git diff of a tracked file
  - diff_file(path="src/foo.py", staged=True) → git diff --cached
  - diff_file(file_a="old.py", file_b="new.py") → compare any two files
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path
from .base import Tool


class DiffFileTool(Tool):
    name = "diff_file"
    description = (
        "Show a unified diff for a file. "
        "When given a single path, shows git diff (unstaged changes by default, "
        "or --cached / --staged changes with staged=true). "
        "When given file_a and file_b, compares any two files regardless of git. "
        "Use this for code review, verifying edits, or understanding what changed."
    )
    parameters = {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "File path to diff against git HEAD (mutually exclusive with file_a/file_b).",
            },
            "staged": {
                "type": "boolean",
                "description": "Show staged (cached) diff instead of unstaged. Only used with 'path'.",
            },
            "file_a": {
                "type": "string",
                "description": "First file for two-file comparison.",
            },
            "file_b": {
                "type": "string",
                "description": "Second file for two-file comparison.",
            },
            "context_lines": {
                "type": "integer",
                "description": "Number of context lines around changes (default: 3).",
            },
        },
        "required": [],
    }

    def execute(
        self,
        path: str | None = None,
        staged: bool = False,
        file_a: str | None = None,
        file_b: str | None = None,
        context_lines: int = 3,
    ) -> str:
        if file_a and file_b:
            return self._file_diff(file_a, file_b, context_lines)
        if path:
            return self._git_diff(path, staged, context_lines)
        return "Error: provide either 'path' (git diff) or 'file_a' + 'file_b' (file comparison)."

    @staticmethod
    def _git_diff(path: str, staged: bool, context_lines: int) -> str:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            return f"Error: file not found: {path}"

        # Find the git repo root
        try:
            root_result = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                cwd=str(p.parent if p.is_file() else p),
                capture_output=True, text=True, timeout=10,
            )
            if root_result.returncode != 0:
                return f"Not a git repository: {p.parent}"
            git_root = root_result.stdout.strip()
        except FileNotFoundError:
            return "git is not installed or not in PATH."
        except Exception as e:
            return f"git error: {e}"

        cmd = ["git", "diff", f"-U{context_lines}"]
        if staged:
            cmd.append("--cached")
        cmd.append(str(p))

        try:
            result = subprocess.run(
                cmd, cwd=git_root, capture_output=True, text=True, timeout=15,
            )
            diff = result.stdout or result.stderr
            if not diff.strip():
                if staged:
                    return f"No staged changes in {path}"
                return f"No unstaged changes in {path} (file matches HEAD)"
            # Limit output to avoid flooding context
            lines = diff.splitlines()
            if len(lines) > 300:
                diff = "\n".join(lines[:300]) + f"\n... ({len(lines) - 300} more lines)"
            return diff
        except subprocess.TimeoutExpired:
            return "git diff timed out."
        except Exception as e:
            return f"git diff error: {e}"

    @staticmethod
    def _file_diff(file_a: str, file_b: str, context_lines: int) -> str:
        import difflib
        pa = Path(file_a).expanduser().resolve()
        pb = Path(file_b).expanduser().resolve()
        if not pa.exists():
            return f"Error: file not found: {file_a}"
        if not pb.exists():
            return f"Error: file not found: {file_b}"
        try:
            lines_a = pa.read_text(errors="replace").splitlines(keepends=True)
            lines_b = pb.read_text(errors="replace").splitlines(keepends=True)
        except OSError as e:
            return f"Error reading files: {e}"

        diff_lines = list(difflib.unified_diff(
            lines_a, lines_b,
            fromfile=str(pa), tofile=str(pb),
            n=context_lines,
        ))
        if not diff_lines:
            return "Files are identical."
        diff = "".join(diff_lines)
        lines = diff.splitlines()
        if len(lines) > 300:
            diff = "\n".join(lines[:300]) + f"\n... ({len(lines) - 300} more lines)"
        return diff
