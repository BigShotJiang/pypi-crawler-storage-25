"""HTTP fetch tool — GET/POST a URL and return the response body.

Truncates to MAX_BYTES to avoid flooding context.  Strips HTML tags when
content-type is text/html so the LLM sees readable text.
Retries up to 3 times on transient network errors (timeout, connection reset).
"""

import ipaddress
import json
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request
from .base import Tool

MAX_BYTES = 12_000   # ~3 K tokens — enough for docs/APIs without flooding context
TIMEOUT   = 20

# Private / link-local IP ranges that should never be reached from agent code
_BLOCKED_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),   # link-local / AWS metadata
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]


def _is_ssrf_blocked(host: str) -> bool:
    """Return True if the resolved IP falls in a private/loopback range."""
    try:
        ip = ipaddress.ip_address(socket.gethostbyname(host))
        return any(ip in net for net in _BLOCKED_NETWORKS)
    except Exception:
        return False  # can't resolve — let urllib fail naturally


def _strip_html(html: str) -> str:
    """Very lightweight HTML → plain-text: remove tags, collapse whitespace."""
    # Remove <script> and <style> blocks entirely
    html = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", html, flags=re.I | re.S)
    # Remove all remaining tags
    html = re.sub(r"<[^>]+>", " ", html)
    # Decode common HTML entities
    html = html.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">") \
               .replace("&quot;", '"').replace("&#39;", "'").replace("&nbsp;", " ")
    # Collapse whitespace
    html = re.sub(r"[ \t]+", " ", html)
    html = re.sub(r"\n{3,}", "\n\n", html)
    return html.strip()


class FetchUrlTool(Tool):
    name = "fetch_url"
    description = (
        "Fetch a URL and return its content (GET by default). "
        "Useful for reading documentation, calling REST APIs, or downloading text files. "
        "HTML pages are converted to plain text automatically. "
        "Response is truncated to ~12 KB."
    )
    parameters = {
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "The URL to fetch (http or https).",
            },
            "method": {
                "type": "string",
                "enum": ["GET", "POST", "PUT", "DELETE", "PATCH"],
                "description": "HTTP method. Default: GET.",
            },
            "headers": {
                "type": "object",
                "description": "Optional HTTP headers as key-value pairs.",
            },
            "body": {
                "type": "string",
                "description": "Request body for POST/PUT (JSON string or plain text).",
            },
            "raw": {
                "type": "boolean",
                "description": "Return raw bytes as-is instead of stripping HTML. Default: false.",
            },
        },
        "required": ["url"],
    }

    # risky — accesses external network
    is_risky = True

    def execute(
        self,
        url: str,
        method: str = "GET",
        headers: dict | None = None,
        body: str | None = None,
        raw: bool = False,
    ) -> str:
        if not url.startswith(("http://", "https://")):
            return "Error: only http/https URLs are supported."

        parsed_host = urllib.parse.urlparse(url).hostname or ""
        if _is_ssrf_blocked(parsed_host):
            return f"Error: access to private/internal addresses is blocked ({parsed_host})."

        data = body.encode() if body else None
        req = urllib.request.Request(url, data=data, method=method.upper())

        req.add_header("User-Agent", "byoe-agent/1.0")
        if headers:
            for k, v in headers.items():
                req.add_header(str(k), str(v))
        if data and "Content-Type" not in (headers or {}):
            # auto-detect JSON body
            try:
                json.loads(body)  # type: ignore
                req.add_header("Content-Type", "application/json")
            except (ValueError, TypeError):
                req.add_header("Content-Type", "text/plain")

        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                status  = resp.status
                ct      = resp.headers.get("Content-Type", "")
                content = resp.read(MAX_BYTES)
        except urllib.error.HTTPError as e:
            return f"HTTP {e.code} {e.reason}\n{e.read(2000).decode(errors='replace')}"
        except (urllib.error.URLError, TimeoutError, ConnectionResetError, OSError) as e:
            # Retry up to 2 more times on transient network errors
            last_err = str(e)
            for attempt in range(2):
                time.sleep(1.5 * (attempt + 1))
                try:
                    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                        status  = resp.status
                        ct      = resp.headers.get("Content-Type", "")
                        content = resp.read(MAX_BYTES)
                    break  # success
                except urllib.error.HTTPError as he:
                    return f"HTTP {he.code} {he.reason}\n{he.read(2000).decode(errors='replace')}"
                except Exception as retry_e:
                    last_err = str(retry_e)
            else:
                return f"Error fetching URL after 3 attempts: {last_err}"
        except Exception as e:
            return f"Error: {e}"

        text = content.decode("utf-8", errors="replace")

        if not raw and "html" in ct.lower():
            text = _strip_html(text)

        truncated = len(content) >= MAX_BYTES
        result    = f"HTTP {status} | {ct}\n\n{text}"
        if truncated:
            result += f"\n\n... [truncated at {MAX_BYTES} bytes]"
        return result
