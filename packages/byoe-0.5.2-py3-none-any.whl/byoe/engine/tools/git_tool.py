"""Git tool — safe, whitelist-based git operations.

Only read-only and non-destructive commands are allowed by default.
Push / force operations require explicit dangerous-level confirmation.
"""

import os
import subprocess
import sys
from pathlib import Path
from .base import Tool

TIMEOUT = 30

# Commands allowed without any special permission
_SAFE_CMDS = {
    "status", "diff", "log", "show", "branch", "tag", "remote",
    "stash list", "stash show", "ls-files", "shortlog", "describe",
}

# Commands allowed at 'risky' level (modify local state, no network)
_RISKY_CMDS = {
    "add", "commit", "checkout", "switch", "restore",
    "stash", "merge", "rebase", "cherry-pick", "reset", "revert",
}

# Everything else (push, pull, fetch, clone, force) is dangerous


def _classify(subcmd: str) -> str:
    """Return 'safe', 'risky', or 'dangerous' for the given git subcommand."""
    first = subcmd.strip().split()[0].lower() if subcmd.strip() else ""
    if first in _SAFE_CMDS:
        return "safe"
    if first in _RISKY_CMDS:
        return "risky"
    return "dangerous"


class GitTool(Tool):
    name = "git"
    description = (
        "Run git commands in the current working directory. "
        "Read-only commands (status, diff, log, show) are always allowed. "
        "Local-modifying commands (add, commit, checkout) require approval. "
        "Network commands (push, pull, fetch) require explicit confirmation."
    )
    parameters = {
        "type": "object",
        "properties": {
            "args": {
                "type": "string",
                "description": (
                    "Git subcommand and arguments, e.g. 'status', 'log --oneline -10', "
                    "'diff HEAD~1', 'commit -m \"fix: typo\"'."
                ),
            },
        },
        "required": ["args"],
    }

    def execute(self, args: str) -> str:
        args = args.strip()
        if not args:
            return "Error: no git arguments provided."

        level = _classify(args)
        # is_risky / is_dangerous are checked by the permission manager in the agent loop.
        # We set them here so the tool carries the right metadata.
        # (The agent already called permission.check() before calling execute().)

        cmd = ["git"] + args.split()
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=TIMEOUT,
                encoding="utf-8",
                errors="replace",
                cwd=os.getcwd(),
            )
        except FileNotFoundError:
            return "Error: git is not installed or not in PATH."
        except subprocess.TimeoutExpired:
            return f"Error: git command timed out after {TIMEOUT}s"
        except Exception as e:
            return f"Error: {e}"

        stdout = result.stdout.strip()
        stderr = result.stderr.strip()
        out = ""
        if stdout:
            out += stdout
        if stderr:
            out += ("\n" if out else "") + f"[stderr]\n{stderr}"
        if not out:
            out = "(no output)"

        if result.returncode != 0:
            out = f"[exit {result.returncode}]\n{out}"

        # Truncate very long output
        if len(out) > 8000:
            out = out[:8000] + "\n... [truncated]"

        return out

    @property
    def is_risky(self) -> bool:  # type: ignore[override]
        return False  # individual calls classified at runtime; permission handled by agent

    @property
    def is_dangerous(self) -> bool:  # type: ignore[override]
        return False
