"""Test runner tool — execute a project's test suite and parse results.

Supports: pytest, jest, go test, cargo test, maven, gradle, npm test.
Auto-detects the test framework if no command is specified.
Returns structured pass/fail/coverage summary instead of raw output.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path
from .base import Tool

_FRAMEWORK_HINTS: list[tuple[str, str, str]] = [
    # (marker file/dir,  default command,          label)
    ("pytest.ini",      "python -m pytest -v --tb=short", "pytest"),
    ("pyproject.toml",  "python -m pytest -v --tb=short", "pytest"),
    ("setup.cfg",       "python -m pytest -v --tb=short", "pytest"),
    ("jest.config.js",  "npx jest --no-coverage",         "jest"),
    ("jest.config.ts",  "npx jest --no-coverage",         "jest"),
    ("package.json",    "npm test -- --watchAll=false",    "npm test"),
    ("go.mod",          "go test ./... -v",                "go test"),
    ("Cargo.toml",      "cargo test",                      "cargo test"),
    ("pom.xml",         "mvn test -q",                     "maven"),
    ("build.gradle",    "./gradlew test",                  "gradle"),
]


class RunTestsTool(Tool):
    name = "run_tests"
    description = (
        "Run the project's test suite and return a structured pass/fail summary. "
        "Auto-detects pytest, jest, go test, cargo test, maven, gradle, or npm test. "
        "Use this after implementing a feature to verify correctness, or during Verify phase."
    )
    parameters = {
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "Custom test command to run. If omitted, auto-detects from project files.",
            },
            "path": {
                "type": "string",
                "description": "Directory to run tests in (default: current working directory).",
            },
            "timeout": {
                "type": "integer",
                "description": "Timeout in seconds (default: 120).",
            },
        },
        "required": [],
    }

    def execute(
        self,
        command: str | None = None,
        path: str = ".",
        timeout: int = 120,
    ) -> str:
        cwd = Path(path).expanduser().resolve()
        if not cwd.is_dir():
            return f"Error: directory not found: {path}"

        if command:
            cmd = command
            label = "custom"
        else:
            cmd, label = self._detect_framework(cwd)
            if not cmd:
                return (
                    "Could not auto-detect test framework. "
                    "Provide a 'command' argument (e.g. 'python -m pytest')."
                )

        shell = sys.platform == "win32"
        try:
            result = subprocess.run(
                cmd if shell else cmd.split(),
                cwd=str(cwd),
                capture_output=True,
                text=True,
                timeout=timeout,
                shell=shell,
                env={**os.environ},
            )
        except subprocess.TimeoutExpired:
            return f"Test run timed out after {timeout}s. Consider increasing the timeout or running a subset of tests."
        except FileNotFoundError:
            return f"Command not found: {cmd!r}. Is the test runner installed?"
        except Exception as e:
            return f"Test run error: {e}"

        output = (result.stdout or "") + (result.stderr or "")
        summary = self._parse_summary(output, label, result.returncode)
        return summary

    @staticmethod
    def _detect_framework(cwd: Path) -> tuple[str, str]:
        for marker, cmd, label in _FRAMEWORK_HINTS:
            if (cwd / marker).exists():
                return cmd, label
        return "", ""

    @staticmethod
    def _parse_summary(output: str, label: str, returncode: int) -> str:
        lines = output.splitlines()
        status = "✅ PASSED" if returncode == 0 else "❌ FAILED"

        # pytest
        m = re.search(r"(\d+) passed(?:,\s*(\d+) failed)?(?:,\s*(\d+) error)?(?:,\s*(\d+) warning)?", output)
        if m:
            passed = int(m.group(1) or 0)
            failed = int(m.group(2) or 0)
            errors = int(m.group(3) or 0)
            summary_line = f"{passed} passed, {failed} failed, {errors} errors"
            # Coverage line
            cov_m = re.search(r"TOTAL\s+\d+\s+\d+\s+(\d+)%", output)
            cov = f", coverage {cov_m.group(1)}%" if cov_m else ""
            # Collect failure details (short)
            fails = []
            for line in lines:
                if "FAILED" in line and "::" in line:
                    fails.append(f"  • {line.strip()}")
                if len(fails) >= 10:
                    fails.append("  … (more failures)")
                    break
            fail_block = "\n" + "\n".join(fails) if fails else ""
            return f"[{label}] {status}\n{summary_line}{cov}{fail_block}"

        # jest
        m = re.search(r"Tests:\s+(.+)", output)
        suites = re.search(r"Test Suites:\s+(.+)", output)
        if m:
            return f"[{label}] {status}\n{m.group(0)}\n{suites.group(0) if suites else ''}"

        # go test
        if label == "go test":
            passes = len(re.findall(r"^--- PASS:", output, re.MULTILINE))
            fails_list = re.findall(r"^--- FAIL: (\S+)", output, re.MULTILINE)
            summary_line = f"{passes} passed, {len(fails_list)} failed"
            fail_block = ("\n" + "\n".join(f"  • {f}" for f in fails_list[:10])) if fails_list else ""
            return f"[{label}] {status}\n{summary_line}{fail_block}"

        # generic fallback — return last 30 lines
        tail = "\n".join(lines[-30:]) if len(lines) > 30 else output
        return f"[{label}] {status}\n{tail}"
