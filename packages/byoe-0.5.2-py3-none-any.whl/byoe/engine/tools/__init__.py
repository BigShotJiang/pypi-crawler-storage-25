"""Tool registry.

ALL_TOOLS is the canonical *instance* list used by Agent (one instance per
session, wired by Agent._wire_tools).  The registry dict maps name → instance
for O(1) look-up and supports runtime registration of custom tools.
"""

from .bash import BashTool
from .read import ReadFileTool
from .write import WriteFileTool
from .edit import EditFileTool
from .glob_tool import GlobTool
from .grep import GrepTool
from .agent import AgentTool
from .fetch_url import FetchUrlTool
from .list_dir import ListDirTool
from .python_repl import PythonReplTool
from .web_search import WebSearchTool
from .git_tool import GitTool
from .todo_tool import TodoTool
from .run_tests import RunTestsTool
from .diff_file import DiffFileTool

ALL_TOOLS = [
    BashTool(),
    ReadFileTool(),
    WriteFileTool(),
    EditFileTool(),
    GlobTool(),
    GrepTool(),
    AgentTool(),
    FetchUrlTool(),
    ListDirTool(),
    PythonReplTool(),
    WebSearchTool(),
    GitTool(),
    TodoTool(),
    RunTestsTool(),
    DiffFileTool(),
]

# O(1) name → instance map (kept in sync with ALL_TOOLS)
_REGISTRY: dict[str, object] = {t.name: t for t in ALL_TOOLS}


def get_tool(name: str):
    """Return the tool instance for *name*, or None if not found."""
    return _REGISTRY.get(name)


def register_tool(tool) -> None:
    """Register a custom tool at runtime.  Replaces any existing tool with the same name."""
    _REGISTRY[tool.name] = tool
    # Keep ALL_TOOLS in sync so Agent picks it up on next instantiation
    ALL_TOOLS[:] = [t for t in ALL_TOOLS if t.name != tool.name]
    ALL_TOOLS.append(tool)
