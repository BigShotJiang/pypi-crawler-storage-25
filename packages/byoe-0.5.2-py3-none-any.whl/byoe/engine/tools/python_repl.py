"""Python REPL tool — run Python code in an isolated subprocess.

Dangerous: executes arbitrary Python.  Always prompts for permission.
stdout + stderr are captured and returned (truncated to MAX_OUTPUT).
"""

import subprocess
import sys
import textwrap
from .base import Tool

MAX_OUTPUT = 8_000
TIMEOUT    = 30


class PythonReplTool(Tool):
    name = "python_repl"
    description = (
        "Execute Python code and return stdout + stderr. "
        "Useful for data processing, calculations, format conversions, and testing snippets. "
        "Runs in an isolated subprocess. Output is truncated to ~8 KB."
    )
    parameters = {
        "type": "object",
        "properties": {
            "code": {
                "type": "string",
                "description": "Python code to execute.",
            },
            "timeout": {
                "type": "integer",
                "description": f"Timeout in seconds. Default: {TIMEOUT}. Max: 120.",
            },
        },
        "required": ["code"],
    }

    # dangerous — arbitrary code execution
    is_dangerous = True

    def execute(self, code: str, timeout: int = TIMEOUT) -> str:
        timeout = max(1, min(int(timeout), 120))

        # Dedent in case the LLM indents the whole block
        code = textwrap.dedent(code)

        # Build a minimal safe env — strip API keys / tokens from the child process
        import os as _os
        _safe_keys = {"PATH", "PYTHONPATH", "PYTHONHOME", "SYSTEMROOT", "TEMP", "TMP",
                      "HOME", "USERPROFILE", "LANG", "LC_ALL", "LC_CTYPE"}
        safe_env = {k: v for k, v in _os.environ.items() if k in _safe_keys}

        try:
            result = subprocess.run(
                [sys.executable, "-c", code],
                capture_output=True,
                text=True,
                timeout=timeout,
                encoding="utf-8",
                errors="replace",
                env=safe_env,
            )
        except subprocess.TimeoutExpired:
            return f"Error: execution timed out after {timeout}s"
        except Exception as e:
            return f"Error: {e}"

        stdout = result.stdout or ""
        stderr = result.stderr or ""
        combined = ""

        if stdout:
            combined += stdout
        if stderr:
            combined += ("\n" if combined else "") + f"[stderr]\n{stderr}"
        if not combined:
            combined = "(no output)"

        if len(combined) > MAX_OUTPUT:
            combined = combined[:MAX_OUTPUT] + f"\n... [truncated at {MAX_OUTPUT} chars]"

        exit_code = result.returncode
        header = f"[exit {exit_code}]\n" if exit_code != 0 else ""
        return header + combined
