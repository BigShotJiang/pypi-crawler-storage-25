"""Configuration - env vars and defaults."""

import os
from dataclasses import dataclass
from pathlib import Path


def _load_dotenv():
    """Load .env from cwd, walking up to home dir. No-op if python-dotenv missing."""
    try:
        from dotenv import load_dotenv
        env_path = Path(".env")
        if not env_path.exists():
            cur = Path.cwd()
            home = Path.home()
            while cur != home and cur != cur.parent:
                candidate = cur / ".env"
                if candidate.exists():
                    env_path = candidate
                    break
                cur = cur.parent
        load_dotenv(env_path, override=False)
    except ImportError:
        pass


@dataclass
class Config:
    model: str = "gpt-4o"
    api_key: str = ""
    base_url: str | None = None
    max_tokens: int = 16384
    temperature: float = 0.0
    max_context_tokens: int = 128_000

    @classmethod
    def from_env(cls) -> "Config":
        _load_dotenv()
        api_key = (
            os.getenv("BYOE_API_KEY")
            or os.getenv("OPENAI_API_KEY")
            or os.getenv("DEEPSEEK_API_KEY")
            or os.getenv("ANTHROPIC_API_KEY")
            or ""
        )
        return cls(
            model=os.getenv("BYOE_MODEL", "gpt-4o"),
            api_key=api_key,
            base_url=(
                os.getenv("BYOE_BASE_URL")
                or os.getenv("OPENAI_BASE_URL")
            ),
            max_tokens=int(os.getenv("BYOE_MAX_TOKENS", "16384")),
            temperature=float(os.getenv("BYOE_TEMPERATURE", "0")),
            max_context_tokens=int(os.getenv("BYOE_MAX_CONTEXT", "128000")),
        )
