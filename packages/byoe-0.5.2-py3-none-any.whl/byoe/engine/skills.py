"""Server-side skill persistence.

Skills are stored as JSON files in ~/.byoe/skills/<name>.json.
This allows skills created in the JetBot UI to survive browser/device changes
and to be available in `byoe chat` (CLI mode) as well.

Schema of each skill file:
    {
        "name": "my-skill",
        "description": "...",
        "instructions": "...",
        "trigger": "optional trigger phrase",
        "created_at": "2026-04-17T12:00:00",
        "builtin": false
    }
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

SKILLS_DIR = Path.home() / ".byoe" / "skills"


def _ensure_dir() -> None:
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)


def list_skills() -> list[dict]:
    """Return all custom skills sorted by name."""
    if not SKILLS_DIR.exists():
        return []
    skills = []
    for f in sorted(SKILLS_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            data["name"] = f.stem  # canonical name = filename
            skills.append(data)
        except Exception:
            pass
    return skills


def save_skill(name: str, description: str, instructions: str,
               trigger: str = "") -> dict:
    """Create or overwrite a custom skill. Returns the saved skill dict."""
    _ensure_dir()
    # Sanitise name: lowercase, hyphens, no path separators
    safe_name = (
        name.strip().lower()
        .replace(" ", "-")
        .replace("/", "-")
        .replace("\\", "-")
        .replace("..", "-")
    )
    if not safe_name:
        raise ValueError("Skill name cannot be empty")

    skill = {
        "name": safe_name,
        "description": description.strip() or safe_name,
        "instructions": instructions.strip(),
        "trigger": trigger.strip(),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "builtin": False,
    }
    path = SKILLS_DIR / f"{safe_name}.json"
    path.write_text(json.dumps(skill, ensure_ascii=False, indent=2), encoding="utf-8")
    return skill


def delete_skill(name: str) -> bool:
    """Delete a custom skill. Returns True if deleted, False if not found."""
    path = SKILLS_DIR / f"{name}.json"
    if path.exists():
        path.unlink()
        return True
    return False


def get_skill(name: str) -> dict | None:
    """Load a single skill by name, or None if not found."""
    path = SKILLS_DIR / f"{name}.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        data["name"] = path.stem
        return data
    except Exception:
        return None
