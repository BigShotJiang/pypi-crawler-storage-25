"""BYOE CLI — 统一入口

卜一智航（BYOE）· 卜一智元出品 · byoe.net
携智而来，决策随行 — Bring Your Own Executive AI

子命令:
  byoe init          初始化 Crew 工作区
  byoe plan <name>   创建新变更计划
  byoe status        查看工作区状态
  byoe release       归档已完成变更
  byoe agents        列出领域专家
  byoe run [tool]    启动 AI 工具（默认内置 Agent）
  byoe chat          交互式内置 Agent（同 byoe run）
  byoe web           启动 Web 管控界面（浏览器 UI）
"""
from __future__ import annotations

import argparse
import sys

from byoe import __version__


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="byoe",
        description="卜一智航 (BYOE) — 携智而来，决策随行\nAI 开发团队编排 + 内置多模型编程 Agent | byoe.net",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  byoe init                         初始化 Crew 工作区
  byoe plan login-feature           创建新变更计划
  byoe status                       查看所有活跃变更状态
  byoe chat                         启动内置 AI Agent（自动注入项目上下文）
  byoe chat -m deepseek-chat        使用 DeepSeek 模型
  byoe chat -r session_xxx          恢复上次对话
  byoe run                          同 byoe chat
  byoe run claude                   启动 Claude Code 并注入上下文
  byoe run opencode                 启动 OpenCode 并注入上下文
  byoe run aider                    启动 Aider 并注入上下文
  byoe run cursor                   打开 Cursor 并写入 .cursorrules
  byoe agents                       列出所有可用的领域专家
  byoe release                      归档已完成变更
  byoe sessions                     列出已保存的对话会话
  byoe sessions show <id>           查看会话详情
  byoe sessions delete <id>         删除会话
  byoe web                          启动 Web 管控界面（浏览器自动打开）
  byoe web --port 8080 --no-browser 在 8080 端口启动，不打开浏览器
        """,
    )
    parser.add_argument("--version", "-v", action="version", version=f"byoe {__version__}")

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")

    # ── init ──────────────────────────────────────────────────────────────────
    init_parser = subparsers.add_parser("init", help="初始化 Crew 工作区")
    init_parser.add_argument("--name", "-n", metavar="NAME", help="项目名称")
    init_parser.add_argument(
        "--no-gitignore", dest="gitignore", action="store_false", default=True,
        help="不自动添加 .gitignore 规则",
    )
    init_parser.add_argument("--prd", metavar="FILE", help="导入已有需求文档（PRD）")
    init_parser.add_argument("--scan", action="store_true", default=False, help="扫描代码库建立基线")

    # ── plan ──────────────────────────────────────────────────────────────────
    plan_parser = subparsers.add_parser("plan", help="创建新变更计划")
    plan_parser.add_argument("name", nargs="?", metavar="NAME", help="变更名称（kebab-case）")
    plan_parser.add_argument("--express", action="store_true", help="快速模式（Bug 修复）")
    plan_parser.add_argument("--prototype", action="store_true", help="原型模式（快速验证）")

    # ── status ────────────────────────────────────────────────────────────────
    subparsers.add_parser("status", help="查看所有活跃变更状态")

    # ── release ───────────────────────────────────────────────────────────────
    subparsers.add_parser("release", help="归档已完成变更")

    # ── agents ────────────────────────────────────────────────────────────────
    agents_parser = subparsers.add_parser("agents", help="列出所有可用的领域专家")
    agents_parser.add_argument(
        "--category", "-c", metavar="CAT",
        help="按分类过滤（如 engineering、game、design）",
    )
    agents_parser.add_argument(
        "--show", "-s", metavar="ID",
        help="查看指定专家的完整详情（支持部分匹配）",
    )

    # ── sessions ──────────────────────────────────────────────────────────────
    sessions_parser = subparsers.add_parser("sessions", help="管理已保存的对话会话")
    sessions_sub = sessions_parser.add_subparsers(dest="sessions_action", metavar="<action>")

    sessions_sub.add_parser("list", help="列出最近保存的会话（默认）")

    show_s = sessions_sub.add_parser("show", help="查看会话详情（消息历史 + 修改文件）")
    show_s.add_argument("id", metavar="SESSION_ID")

    del_s = sessions_sub.add_parser("delete", help="删除一个已保存的会话")
    del_s.add_argument("id", metavar="SESSION_ID")

    # ── run ───────────────────────────────────────────────────────────────────
    run_parser = subparsers.add_parser(
        "run",
        help="启动 AI 编程工具（默认: 内置 Agent）",
    )
    run_parser.add_argument(
        "tool",
        nargs="?",
        default=None,
        choices=["claude", "opencode", "aider", "cursor"],
        metavar="TOOL",
        help="外部工具: claude | opencode | aider | cursor（省略则启动内置 Agent）",
    )
    run_parser.add_argument(
        "--no-inject", dest="inject", action="store_false", default=True,
        help="不注入 INSTRUCTIONS.md 上下文（仅外部工具有效）",
    )
    run_parser.add_argument("-m", "--model", help="模型名称（仅内置 Agent，覆盖 BYOE_MODEL）")
    run_parser.add_argument("-p", "--prompt", help="单次提示模式，执行后退出（仅内置 Agent）")
    run_parser.add_argument("-r", "--resume", metavar="ID", help="恢复已保存的会话（仅内置 Agent）")

    # ── chat ──────────────────────────────────────────────────────────────────
    chat_parser = subparsers.add_parser("chat", help="启动内置 AI Agent（同 byoe run）")
    chat_parser.add_argument("-m", "--model", help="模型名称（覆盖 BYOE_MODEL 环境变量）")
    chat_parser.add_argument(
        "-p", "--prompt", help="单次提示模式（非交互式，执行后退出）"
    )
    chat_parser.add_argument("-r", "--resume", metavar="ID", help="恢复已保存的会话")

    # ── web ───────────────────────────────────────────────────────────────────
    web_parser = subparsers.add_parser("web", help="启动 Web 管控界面（浏览器 UI）")
    web_parser.add_argument(
        "--port", "-p", type=int, default=7860,
        help="监听端口（默认 7860）",
    )
    web_parser.add_argument(
        "--host", default="127.0.0.1",
        help="绑定地址（默认 127.0.0.1，局域网访问可设为 0.0.0.0）",
    )
    web_parser.add_argument(
        "--no-browser", dest="open_browser", action="store_false", default=True,
        help="不自动打开浏览器",
    )
    web_parser.add_argument("-m", "--model", help="模型名称（覆盖 BYOE_MODEL）")
    web_parser.add_argument("-r", "--resume", metavar="ID", help="恢复已保存的会话")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    # ── dispatch ──────────────────────────────────────────────────────────────

    if args.command == "init":
        from byoe.orchestrator.commands.init import init_command
        init_command(
            name=args.name,
            gitignore=args.gitignore,
            prd=getattr(args, "prd", None),
            scan=getattr(args, "scan", False),
        )

    elif args.command == "plan":
        from byoe.orchestrator.commands.plan import plan_command
        plan_command(
            name=getattr(args, "name", None),
            express=getattr(args, "express", False),
            prototype=getattr(args, "prototype", False),
        )

    elif args.command == "status":
        from byoe.orchestrator.commands.status import status_command
        status_command()

    elif args.command == "release":
        from byoe.orchestrator.commands.release import release_command
        release_command()

    elif args.command == "agents":
        from byoe.orchestrator.commands.agents import agents_command
        agents_command(
            category=getattr(args, "category", None),
            show=getattr(args, "show", None),
        )

    elif args.command == "sessions":
        _run_sessions(args)

    elif args.command == "run":
        tool = getattr(args, "tool", None)
        if tool is None:
            # 内置 Agent（可带 -m / -r 参数）
            _run_chat(args)
        else:
            from byoe.orchestrator.commands.run import run_command
            run_command(tool=tool, inject=getattr(args, "inject", True))

    elif args.command == "chat":
        _run_chat(args)

    elif args.command == "web":
        from byoe.web import start_web
        start_web(
            host=args.host,
            port=args.port,
            open_browser=args.open_browser,
            model=getattr(args, "model", None),
            resume=getattr(args, "resume", None),
        )

    else:
        parser.print_help()
        sys.exit(1)


def _run_sessions(args) -> None:
    """Handle `byoe sessions [list|show|delete]`."""
    from byoe.engine.session import list_sessions, load_session, delete_session
    from rich.console import Console
    from rich.table import Table

    console = Console()
    action = getattr(args, "sessions_action", None) or "list"

    if action == "list" or action is None:
        sessions = list_sessions()
        if not sessions:
            console.print("[dim]No saved sessions found.[/dim]")
            console.print("Start a chat and type [bold]/save[/bold] to create one.")
            return
        table = Table(title="Saved Sessions", show_lines=True)
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Model", style="green")
        table.add_column("Saved At")
        table.add_column("Files Changed", style="yellow")
        table.add_column("Preview", max_width=50)
        for s in sessions:
            table.add_row(
                s["id"],
                s["model"],
                s["saved_at"],
                str(len(s.get("changed_files", []))),
                s["preview"],
            )
        console.print(table)
        console.print(f"\nResume: [bold]byoe chat -r <SESSION_ID>[/bold]")

    elif action == "show":
        sid = args.id
        loaded = load_session(sid)
        if not loaded:
            console.print(f"[red]Session '{sid}' not found.[/red]")
            return
        messages, model, changed_files = loaded
        console.print(f"\n[bold]Session:[/bold] {sid}  ([cyan]{model}[/cyan])")
        console.print(f"[bold]Messages:[/bold] {len(messages)}")
        if changed_files:
            console.print(f"\n[bold]Files modified ({len(changed_files)}):[/bold]")
            for f in sorted(changed_files):
                console.print(f"  [cyan]{f}[/cyan]")
        console.print(f"\n[bold]History:[/bold]")
        for m in messages:
            role = m.get("role", "?")
            content = (m.get("content") or "")[:200]
            if content:
                color = {"user": "blue", "assistant": "green"}.get(role, "dim")
                console.print(f"  [{color}]{role}[/{color}]: {content}")

    elif action == "delete":
        sid = args.id
        if delete_session(sid):
            console.print(f"[green]Deleted session: {sid}[/green]")
        else:
            console.print(f"[red]Session '{sid}' not found.[/red]")


def _run_chat(args) -> None:
    """启动内置 Agent，处理 -m / -p / -r 参数。"""
    from byoe.engine.config import Config
    from byoe.engine.llm import LLM
    from byoe.engine.agent import Agent
    from byoe.engine.session import load_session
    from byoe.chat import run_repl

    config = Config.from_env()

    model = getattr(args, "model", None)
    resume_id = getattr(args, "resume", None)
    one_shot = getattr(args, "prompt", None)

    if model:
        config.model = model

    if not config.api_key:
        from byoe.orchestrator.utils import red
        print(red("❌ 未找到 API Key"))
        print(
            "请设置: BYOE_API_KEY / OPENAI_API_KEY / DEEPSEEK_API_KEY\n\n"
            "示例 (Windows PowerShell):\n"
            "  $env:OPENAI_API_KEY='sk-...'\n"
            "  $env:BYOE_MODEL='deepseek-chat'\n"
            "  $env:OPENAI_BASE_URL='https://api.deepseek.com'\n"
        )
        import sys; sys.exit(1)

    llm = LLM(
        model=config.model,
        api_key=config.api_key,
        base_url=config.base_url,
        temperature=config.temperature,
        max_tokens=config.max_tokens,
    )
    agent = Agent(llm=llm, max_context_tokens=config.max_context_tokens)

    if resume_id:
        loaded = load_session(resume_id)
        if loaded:
            agent.messages, loaded_model, loaded_files = loaded
            agent.changed_files.update(loaded_files)
            if not model:
                agent.llm.model = loaded_model
                config.model = loaded_model
            from rich.console import Console
            Console().print(f"[green]Resumed session: {resume_id} (model: {agent.llm.model})[/green]")
        else:
            from rich.console import Console
            Console().print(f"[red]Session '{resume_id}' not found.[/red]")
            import sys; sys.exit(1)

    if one_shot:
        _run_once(agent, one_shot)
    else:
        run_repl(agent, config)


def _run_once(agent, prompt: str) -> None:
    def on_token(tok):
        print(tok, end="", flush=True)

    from rich.console import Console
    console = Console()

    def on_tool(name, kwargs):
        s = ", ".join(f"{k}={repr(v)[:40]}" for k, v in kwargs.items())
        console.print(f"\n[dim]> {name}({s[:80]})[/dim]")

    agent.chat(prompt, on_token=on_token, on_tool=on_tool)
    print()


if __name__ == "__main__":
    main()
