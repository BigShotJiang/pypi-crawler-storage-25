"""Allow `python -m byoe` to work as an alias for the `byoe` CLI."""
from byoe.cli import main

main()
