# -*- coding: utf-8 -*-
"""卜一智航 — 携智而来，决策随行。
BYOE (Bring Your Own Executive AI) — 卜一智元出品

AI 开发团队编排（Crew 工作流）+ 内置多模型编程 Agent 一体化工具。

官网: https://byoe.net
"""

__version__ = "0.5.2"
__author__ = "卜一智元"
__email__ = "hi@byoe.net"
__url__ = "https://byoe.net"
__tagline__ = "携智而来，决策随行。"
