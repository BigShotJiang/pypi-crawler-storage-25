"""Orchestrator layer — Crew project workflow management."""
