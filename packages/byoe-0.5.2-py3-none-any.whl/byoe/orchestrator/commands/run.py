"""byoe run 命令 — 启动 AI 编程工具并注入 Crew 上下文

支持两种模式：
  byoe run            → 启动内置 Agent（引擎层，自动注入项目上下文）
  byoe run claude     → 启动 Claude Code（外部工具，注入 INSTRUCTIONS.md）
  byoe run opencode   → 启动 OpenCode（外部工具）
  byoe run aider      → 启动 Aider（通过 --system-prompt 注入）
  byoe run cursor     → 打开 Cursor（通过 .cursorrules 注入）
"""
from __future__ import annotations

import os
import sys
import shutil
import subprocess
from pathlib import Path
from byoe.orchestrator.utils import pkg_root, green, yellow, bold, cyan, red


# 外部工具配置（Claude Code / OpenCode / Aider / Cursor 保持原有行为）
EXTERNAL_TOOL_CONFIGS: dict[str, dict] = {
    "claude": {
        "label": "Claude Code",
        "commands": ["claude"],
        "inject_flag": None,
        "install_hint": "npm install -g @anthropic-ai/claude-code  或访问 https://claude.ai/code",
        "context_mode": "print",
    },
    "opencode": {
        "label": "OpenCode",
        "commands": ["opencode"],
        "inject_flag": None,
        "install_hint": "npm install -g opencode-ai  或访问 https://opencode.ai",
        "context_mode": "print",
    },
    "aider": {
        "label": "Aider",
        "commands": ["aider"],
        "inject_flag": "--system-prompt",
        "install_hint": "pip install aider-chat",
        "context_mode": "flag",
    },
    "cursor": {
        "label": "Cursor",
        "commands": ["cursor", "cursor.exe"],
        "inject_flag": None,
        "install_hint": "下载 Cursor: https://cursor.sh",
        "context_mode": "open",
    },
}


def run_command(tool: str | None = None, inject: bool = True) -> None:
    """
    tool=None  → 启动内置 Agent REPL（等同于 byoe chat）
    tool=str   → 启动外部工具
    """
    if tool is None or tool == "builtin":
        _run_builtin()
        return

    cwd = Path.cwd()
    config = EXTERNAL_TOOL_CONFIGS.get(tool)
    if not config:
        print(red(f"❌ 不支持的工具: {tool}"))
        print(f"   支持: builtin（内置）, {', '.join(EXTERNAL_TOOL_CONFIGS.keys())}")
        return

    label = config["label"]
    executable = _find_executable(config["commands"])
    if not executable:
        print(yellow(f"⚠️  未找到 {label}，请先安装:"))
        print(f"   {config['install_hint']}\n")
        return

    print(f"\n🚀 {bold(f'启动 {label}')}\n")

    instructions_path = cwd / "INSTRUCTIONS.md"
    crew_yaml         = cwd / "crew.yaml"
    resume_path       = cwd / "crew" / "resume.md"

    if inject:
        _print_context_hint(tool, config, label, instructions_path, crew_yaml, resume_path, cwd)

    mode = config["context_mode"]

    if mode == "flag" and inject and instructions_path.exists():
        cmd = [executable, config["inject_flag"], str(instructions_path)]
        _launch(cmd, cwd)
    elif mode == "open":
        if inject:
            _write_cursorrules(cwd, instructions_path)
        _launch([executable, str(cwd)], cwd, wait=False)
    else:
        _launch([executable], cwd)


def _run_builtin() -> None:
    """启动内置 Agent REPL（engine 层）。system prompt 会自动注入 Crew 上下文。"""
    # 延迟导入，避免在不使用 chat 时加载 openai 等依赖
    try:
        from byoe.engine.config import Config
        from byoe.engine.llm import LLM
        from byoe.engine.agent import Agent
        from byoe.chat import run_repl
    except ImportError as e:
        print(red(f"❌ 内置 Agent 依赖缺失: {e}"))
        print("   请运行: pip install byoe[engine]  或  pip install openai rich prompt_toolkit")
        sys.exit(1)

    config = Config.from_env()
    if not config.api_key:
        print(red("[bold]No API key found.[/bold]"))
        print(
            "请设置以下任一环境变量:\n"
            "  BYOE_API_KEY / OPENAI_API_KEY / DEEPSEEK_API_KEY\n\n"
            "示例:\n"
            "  # OpenAI\n"
            "  set OPENAI_API_KEY=sk-...\n\n"
            "  # DeepSeek\n"
            "  set OPENAI_API_KEY=sk-... & set OPENAI_BASE_URL=https://api.deepseek.com\n\n"
            "  # Ollama (本地)\n"
            "  set OPENAI_API_KEY=ollama & set OPENAI_BASE_URL=http://localhost:11434/v1 & set BYOE_MODEL=qwen2.5-coder\n"
        )
        sys.exit(1)

    llm = LLM(
        model=config.model,
        api_key=config.api_key,
        base_url=config.base_url,
        temperature=config.temperature,
        max_tokens=config.max_tokens,
    )
    agent = Agent(llm=llm, max_context_tokens=config.max_context_tokens)
    run_repl(agent, config)


# ── 外部工具辅助函数 ─────────────────────────────────────────────────────────

def _print_context_hint(tool, config, label, instructions_path, crew_yaml, resume_path, cwd):
    files_to_load = []
    if instructions_path.exists(): files_to_load.append(str(instructions_path))
    if crew_yaml.exists():         files_to_load.append(str(crew_yaml))
    if resume_path.exists():       files_to_load.append(str(resume_path))

    print(f"{cyan('📋 BYOE 上下文文件:')}")
    for f in files_to_load:
        print(f"   {f}")
    print()

    if tool == "claude":
        print(f"{cyan('💡 Claude Code 使用提示:')}")
        print(f"   {bold('/add INSTRUCTIONS.md crew.yaml crew/resume.md')}")
        _write_claude_instructions(cwd, instructions_path)
    elif tool == "opencode":
        print(f"{cyan('💡 OpenCode 使用提示:')}")
        print(f"   {bold('@INSTRUCTIONS.md @crew.yaml @crew/resume.md')}")
        _write_opencode_instructions(cwd, instructions_path)
    print()


def _write_claude_instructions(cwd: Path, instructions_path: Path) -> None:
    if not instructions_path.exists():
        return
    claude_dir = cwd / ".claude"
    claude_dir.mkdir(exist_ok=True)
    dest = claude_dir / "CLAUDE.md"
    if dest.exists():
        print(yellow("   ℹ️  .claude/CLAUDE.md 已存在，跳过写入"))
    else:
        content = instructions_path.read_text(encoding="utf-8")
        yaml_path = cwd / "crew.yaml"
        if yaml_path.exists():
            content += f"\n\n---\n\n## 当前项目配置 (crew.yaml)\n\n```yaml\n{yaml_path.read_text(encoding='utf-8')}```\n"
        dest.write_text(content, encoding="utf-8")
        print(green("   ✅ 已写入 .claude/CLAUDE.md"))


def _write_opencode_instructions(cwd: Path, instructions_path: Path) -> None:
    if not instructions_path.exists():
        return
    oc_dir = cwd / ".opencode"
    oc_dir.mkdir(exist_ok=True)
    dest = oc_dir / "instructions.md"
    if dest.exists():
        print(yellow("   ℹ️  .opencode/instructions.md 已存在，跳过写入"))
    else:
        dest.write_text(instructions_path.read_text(encoding="utf-8"), encoding="utf-8")
        print(green("   ✅ 已写入 .opencode/instructions.md"))


def _write_cursorrules(cwd: Path, instructions_path: Path) -> None:
    if not instructions_path.exists():
        return
    cursorrules_path = cwd / ".cursorrules"
    if cursorrules_path.exists():
        print(yellow("   ℹ️  .cursorrules 已存在，跳过写入"))
    else:
        cursorrules_path.write_text(instructions_path.read_text(encoding="utf-8"), encoding="utf-8")
        print(green("   ✅ 已写入 .cursorrules"))


def _find_executable(commands: list[str]) -> str | None:
    for cmd in commands:
        found = shutil.which(cmd)
        if found:
            return found
    return None


def _launch(cmd: list[str], cwd: Path, wait: bool = True) -> None:
    print(f"{cyan('▶ 运行:')} {' '.join(cmd)}\n")
    try:
        if wait:
            subprocess.run(cmd, cwd=str(cwd))
        else:
            subprocess.Popen(cmd, cwd=str(cwd))
            print(green("✅ 已在后台启动"))
    except KeyboardInterrupt:
        print("\n👋 已退出")
    except FileNotFoundError:
        print(red(f"❌ 命令不存在: {cmd[0]}"))
    except Exception as e:
        print(red(f"❌ 启动失败: {e}"))
