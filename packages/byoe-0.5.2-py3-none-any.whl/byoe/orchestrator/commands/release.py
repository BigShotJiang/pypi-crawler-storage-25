"""byoe release 命令 — 归档已完成变更"""
from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path
from byoe.orchestrator.utils import green, yellow, bold, cyan, red


def release_command() -> None:
    cwd = Path.cwd()
    crew_dir = cwd / "crew"

    if not crew_dir.exists():
        print(yellow("⚠️  未找到 crew/ 目录，请先运行 byoe init"))
        return

    changes_dir = crew_dir / "changes"
    if not changes_dir.exists() or not any(changes_dir.iterdir()):
        print(yellow("⚠️  没有活跃变更可以归档"))
        return

    open_blockers = _count_open_blockers(crew_dir)
    if open_blockers > 0:
        print(yellow(f"⚠️  有 {open_blockers} 个未解决的 blocker（警告但不阻断）"))

    done_changes = []
    pending_changes = []

    for d in sorted(changes_dir.iterdir()):
        if not d.is_dir():
            continue
        proposal = d / "proposal.md"
        if proposal.exists():
            content = proposal.read_text(encoding="utf-8")
            if "verify_confirmed: true" in content or "plan_confirmed: true" in content:
                done_changes.append(d)
            else:
                pending_changes.append(d)
        else:
            pending_changes.append(d)

    if not done_changes:
        print(yellow("⚠️  没有已完成的变更可归档"))
        print(f"   活跃变更: {', '.join(d.name for d in pending_changes)}")
        print(f"\n   提示: 在 proposal.md frontmatter 中设置 verify_confirmed: true 标记完成\n")
        return

    archive_dir = crew_dir / "archive"
    archive_dir.mkdir(exist_ok=True)

    archived = []
    for d in done_changes:
        dest = archive_dir / f"{d.name}-{datetime.now().strftime('%Y%m%d')}"
        if dest.exists():
            dest = archive_dir / f"{d.name}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        shutil.move(str(d), str(dest))
        archived.append(d.name)
        print(green(f"📦 归档: {d.name} → crew/archive/{dest.name}"))

    _update_resume(crew_dir, archived)

    if pending_changes:
        print(yellow(f"\n⚠️  以下变更仍在进行中，未归档:"))
        for d in pending_changes:
            print(f"   - {d.name}")

    print(f"\n{green('✅ 归档完成！')} 共归档 {len(archived)} 个变更\n")


def _count_open_blockers(crew_dir: Path) -> int:
    import re
    blockers_path = crew_dir / "blockers.md"
    if not blockers_path.exists():
        return 0
    content = blockers_path.read_text(encoding="utf-8")
    return len(re.findall(r"## \[OPEN\]", content))


def _update_resume(crew_dir: Path, archived: list[str]) -> None:
    resume_path = crew_dir / "resume.md"
    if not resume_path.exists():
        return
    try:
        content = resume_path.read_text(encoding="utf-8")
        note = f"\n> 已归档（{datetime.now().strftime('%Y-%m-%d')}）: {', '.join(archived)}\n"
        content += note
        resume_path.write_text(content, encoding="utf-8")
    except Exception:
        pass
