"""byoe init 命令 — 初始化 Crew 工作区"""
from __future__ import annotations

import os
from pathlib import Path
from byoe.orchestrator.utils import pkg_root, infer_project_name, green, yellow, cyan, bold


def init_command(
    name: str | None = None,
    gitignore: bool = True,
    prd: str | None = None,
    scan: bool = False,
) -> None:
    cwd = Path.cwd()
    project_name = name or infer_project_name(cwd)

    print(f"\n🚀 BYOE 初始化: {bold(project_name)}\n")

    crew_dir = cwd / "crew"
    if crew_dir.exists():
        print(yellow("⚠️  crew/ 已存在，跳过目录创建"))
    else:
        crew_dir.mkdir(parents=True, exist_ok=True)
        print(green("📁 创建 crew/"))

    instr_dest = cwd / "INSTRUCTIONS.md"
    if instr_dest.exists():
        print(yellow("⚠️  INSTRUCTIONS.md 已存在，跳过"))
    else:
        instr_src = pkg_root() / "templates" / "INSTRUCTIONS.md"
        if instr_src.exists():
            instr_dest.write_text(instr_src.read_text(encoding="utf-8"), encoding="utf-8")
            print(green("📄 创建 INSTRUCTIONS.md（AI 行为指令）"))
        else:
            print(yellow("⚠️  找不到模板 templates/INSTRUCTIONS.md，跳过"))

    yaml_dest = cwd / "crew.yaml"
    if yaml_dest.exists():
        print(yellow("⚠️  crew.yaml 已存在，跳过"))
    else:
        yaml_dest.write_text(_generate_yaml(project_name), encoding="utf-8")
        print(green("⚙️  创建 crew.yaml（项目配置）"))

    specs_dir = crew_dir / "specs"
    if not specs_dir.exists():
        specs_dir.mkdir(parents=True, exist_ok=True)
        print(green("📁 创建 crew/specs/"))

    resume_path = crew_dir / "resume.md"
    if not resume_path.exists():
        resume_path.write_text(_generate_resume(), encoding="utf-8")
        print(green("📝 创建 crew/resume.md（状态快照）"))

    blockers_path = crew_dir / "blockers.md"
    if not blockers_path.exists():
        blockers_path.write_text("# Blockers & 决策记录\n\n（无待解决问题）\n", encoding="utf-8")
        print(green("📝 创建 crew/blockers.md（问题与决策）"))

    if gitignore:
        _append_gitignore(cwd)

    if prd:
        _import_prd(cwd, crew_dir, prd)

    if scan:
        _scan_codebase(cwd)

    print(f"""
{green('✅ 初始化完成！')}

{cyan('📂 项目结构:')}
   INSTRUCTIONS.md          ← AI 行为指令（核心文件）
   crew.yaml                ← 项目配置（入库）
   crew/
   ├── resume.md            ← 状态快照
   ├── blockers.md          ← 问题与决策
   └── specs/               ← 共享规约（入库）

{cyan('🎬 下一步:')}
   byoe chat                启动内置 AI Agent（自动注入上下文）
   byoe run claude          启动 Claude Code 并注入上下文
   byoe run opencode        启动 OpenCode 并注入上下文
   byoe plan <变更名称>     创建新变更计划
""")


def _generate_yaml(project_name: str) -> str:
    return f"""# BYOE 项目配置

project:
  name: "{project_name}"
  description: ""

workflow:
  default_mode: standard     # standard | express | prototype
  concurrent_changes: true

verify:
  test_command: ""            # 为空时 AI 基于验收标准审查

git:
  ignore_crew: true          # crew/ 不入库（推荐）

specialists: []               # 按需激活领域专家，运行 byoe agents 查看可用列表
"""


def _generate_resume() -> str:
    return """---
active_changes: []
---

# Crew 状态快照

## 活跃变更

（暂无活跃变更）

## 待解决

（无待解决问题）

## 下一步

运行 `byoe plan <变更名称>` 开始工作。
"""


def _append_gitignore(cwd: Path) -> None:
    gitignore_path = cwd / ".gitignore"
    marker = "# Crew / BYOE"
    rules = f"\n{marker}\ncrew/\n!crew/specs/\n"

    if gitignore_path.exists():
        existing = gitignore_path.read_text(encoding="utf-8")
        if "Crew" in existing or "BYOE" in existing:
            print(yellow("⚠️  .gitignore 已包含相关规则，跳过"))
            return
        with open(gitignore_path, "a", encoding="utf-8") as f:
            f.write(rules)
        print(green("📝 追加 .gitignore 规则"))
    else:
        gitignore_path.write_text(rules.lstrip(), encoding="utf-8")
        print(green("📝 创建 .gitignore"))


def _import_prd(cwd: Path, crew_dir: Path, prd_file: str) -> None:
    prd_path = Path(prd_file)
    if not prd_path.is_absolute():
        prd_path = cwd / prd_file
    if not prd_path.exists():
        print(yellow(f"⚠️  PRD 文件不存在: {prd_file}，跳过导入"))
        return
    dest = crew_dir / "specs" / prd_path.name
    dest.write_text(prd_path.read_text(encoding="utf-8"), encoding="utf-8")
    print(green(f"📋 已导入 PRD: crew/specs/{prd_path.name}"))


def _scan_codebase(cwd: Path) -> None:
    crew_dir = cwd / "crew"
    extensions_map: dict[str, str] = {
        ".py": "Python", ".ts": "TypeScript", ".js": "JavaScript",
        ".go": "Go", ".rs": "Rust", ".java": "Java", ".cs": "C#",
        ".cpp": "C++", ".c": "C", ".rb": "Ruby", ".php": "PHP",
        ".swift": "Swift", ".kt": "Kotlin",
    }
    lang_counts: dict[str, int] = {}
    dir_set: set[str] = set()
    ignore_dirs = {".git", "node_modules", "__pycache__", ".venv", "dist", "build", "target"}

    for root, dirs, files in os.walk(cwd):
        dirs[:] = [d for d in dirs if d not in ignore_dirs]
        rel_root = Path(root).relative_to(cwd)
        if rel_root != Path("."):
            dir_set.add(str(rel_root).replace("\\", "/"))
        for f in files:
            ext = Path(f).suffix.lower()
            lang = extensions_map.get(ext)
            if lang:
                lang_counts[lang] = lang_counts.get(lang, 0) + 1

    top_dirs = sorted(dir_set)[:20]
    langs_sorted = sorted(lang_counts.items(), key=lambda x: -x[1])

    lines = ["# Codebase Baseline\n",
             f"_Scanned: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M')}_\n"]

    if langs_sorted:
        lines.append("\n## Languages\n")
        for lang, count in langs_sorted:
            lines.append(f"- **{lang}**: {count} files\n")

    if top_dirs:
        lines.append("\n## Directory Structure (top-level)\n")
        for d in top_dirs:
            lines.append(f"- `{d}/`\n")

    md_path = crew_dir / "codebase.md"
    md_path.write_text("".join(lines), encoding="utf-8")
    print(green("🔍 代码库扫描完成 → crew/codebase.md"))
    if langs_sorted:
        langs_str = ", ".join(f"{l}({c})" for l, c in langs_sorted)
        print(f"   语言分布: {langs_str}")
