"""byoe plan 命令 — 创建新变更计划"""
from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path
from byoe.orchestrator.utils import infer_project_name, to_kebab_case, green, yellow, cyan, bold, red


def plan_command(
    name: str | None = None,
    express: bool = False,
    prototype: bool = False,
) -> None:
    cwd = Path.cwd()
    crew_dir = cwd / "crew"

    if not crew_dir.exists():
        print(yellow("⚠️  未找到 crew/ 目录，自动执行 byoe init...\n"))
        from byoe.orchestrator.commands.init import init_command
        init_command()

    if not name:
        print(yellow("⚠️  请提供变更名称，例如: byoe plan login-feature"))
        return

    change_name = to_kebab_case(name)
    if not change_name:
        print(red("❌ 无效的变更名称"))
        return

    mode = _infer_mode(change_name, express, prototype)

    changes_dir = crew_dir / "changes" / change_name
    if changes_dir.exists():
        print(yellow(f"⚠️  变更 '{change_name}' 已存在"))
        proposal = changes_dir / "proposal.md"
        if proposal.exists():
            print(f"   现有 proposal: {proposal}")
        print(f"   可继续工作，或使用不同名称创建新变更\n")
        return

    changes_dir.mkdir(parents=True, exist_ok=True)

    proposal_path = changes_dir / "proposal.md"
    proposal_path.write_text(_generate_proposal(change_name, mode), encoding="utf-8")
    print(green(f"✅ 创建变更计划: {bold(change_name)}"))
    print(f"   模式: {bold(mode)}")
    print(f"   文件: crew/changes/{change_name}/proposal.md\n")

    _update_resume(crew_dir, change_name, mode)
    _print_next_steps(change_name, mode)


def _infer_mode(name: str, express: bool, prototype: bool) -> str:
    if express:
        return "express"
    if prototype:
        return "prototype"
    express_keywords = ["fix", "bug", "hotfix", "patch", "typo"]
    prototype_keywords = ["spike", "prototype", "poc", "experiment", "试验", "原型"]
    name_lower = name.lower()
    if any(kw in name_lower for kw in express_keywords):
        print(yellow("💡 检测到关键词，自动推断为 express 模式（可用 --prototype 覆盖）"))
        return "express"
    if any(kw in name_lower for kw in prototype_keywords):
        print(yellow("💡 检测到关键词，自动推断为 prototype 模式（可用 --express 覆盖）"))
        return "prototype"
    return "standard"


def _generate_proposal(change_name: str, mode: str) -> str:
    now = datetime.now().strftime("%Y-%m-%d")
    mode_note = {
        "standard": "新功能 / 重构（完整 PDEVI 流程）",
        "express": "Bug 修复（P → E → V 快速流程）",
        "prototype": "快速原型（P → D → E，无 Verify）",
    }.get(mode, mode)

    return f"""---
mode: {mode}
plan_confirmed: false
created: {now}
---

# 变更计划：{change_name}

> 模式: **{mode}** — {mode_note}

## 目标

<!-- 描述本次变更要达成的业务/技术目标 -->

## 需求

- [ ] 需求 1
- [ ] 需求 2

## 验收标准

- [ ] 验收标准 1
- [ ] 验收标准 2

---

> **下一步**: 完善上述内容后，运行 `byoe chat` 启动 AI 对话继续推进。
"""


def _update_resume(crew_dir: Path, change_name: str, mode: str) -> None:
    resume_path = crew_dir / "resume.md"
    if not resume_path.exists():
        return
    try:
        content = resume_path.read_text(encoding="utf-8")
        entry = f"\n### {change_name}\n- 模式: {mode}\n- 阶段: plan\n- 创建: {datetime.now().strftime('%Y-%m-%d')}\n"
        if "（暂无活跃变更）" in content:
            content = content.replace("（暂无活跃变更）", entry.strip())
        elif "## 活跃变更" in content:
            content = content.replace("## 活跃变更\n", f"## 活跃变更\n{entry}")
        resume_path.write_text(content, encoding="utf-8")
    except Exception:
        pass


def _print_next_steps(change_name: str, mode: str) -> None:
    mode_flow = {
        "standard": "Plan → Design → Execute → Verify → Iterate",
        "express": "Plan → Execute → Verify",
        "prototype": "Plan → Design → Execute",
    }.get(mode, "")

    print(f"{cyan('🎬 下一步:')}")
    print(f"   流程: {mode_flow}")
    print(f"   1. 编辑 crew/changes/{change_name}/proposal.md 填写目标和需求")
    print(f"   2. 运行 {bold('byoe chat')} 启动内置 AI Agent（自动加载上下文）")
    print(f"   3. 或运行 {bold('byoe run claude')} / {bold('byoe run opencode')} 使用外部工具\n")
