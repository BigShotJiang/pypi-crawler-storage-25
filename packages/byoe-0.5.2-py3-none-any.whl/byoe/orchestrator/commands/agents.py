"""byoe agents 命令 — 列出所有可用的领域专家"""
from __future__ import annotations

import re
from pathlib import Path
from byoe.orchestrator.utils import pkg_root, green, cyan, bold, yellow, red


def agents_command(category: str | None = None, show: str | None = None) -> None:
    agents_dir = pkg_root() / "agents"
    if not agents_dir.exists():
        print(yellow("⚠️  找不到 agents/ 目录"))
        return

    # ── --show <id>: 显示单个专家详情 ────────────────────────────────────────
    if show:
        _show_agent(agents_dir, show)
        return

    files = sorted(
        f for f in agents_dir.iterdir()
        if f.suffix == ".md" and f.name != "README.md"
    )

    agents: list[dict] = []
    for file in files:
        try:
            content = file.read_text(encoding="utf-8")
        except Exception:
            continue
        meta = _parse_frontmatter(content)
        agents.append({
            "id": file.stem,
            "name": meta.get("name", file.stem),
            "category": meta.get("category", "其他"),
            "stages": _parse_stages(meta.get("stages", "")),
            "file": file.name,
        })

    if category:
        agents = [a for a in agents if category.lower() in a["category"].lower()]

    grouped: dict[str, list] = {}
    for agent in agents:
        grouped.setdefault(agent["category"], []).append(agent)

    total = len(agents)
    print(f"\n🤖 {bold('BYOE 领域专家')}（共 {total} 位）\n")

    for cat, members in sorted(grouped.items()):
        print(f"  {cyan(cat)}")
        for m in members:
            stages_str = f"  [{','.join(m['stages'])}]" if m["stages"] else ""
            print(f"    {bold(m['id']):<30} {m['name']}{yellow(stages_str)}")
        print()

    print(f"激活方式：在 {bold('crew.yaml')} 中添加 specialists 列表")
    print("  specialists:")
    if agents:
        print(f"    - {agents[0]['id']}")
    print()
    print(f"查看单个专家详情：{bold('byoe agents --show <id>')}")
    print()


def _show_agent(agents_dir: Path, agent_id: str) -> None:
    """显示单个专家的完整 Markdown 内容。"""
    # 精确匹配
    target = agents_dir / f"{agent_id}.md"
    if not target.exists():
        # 模糊匹配（前缀/包含）
        candidates = [
            f for f in agents_dir.glob("*.md")
            if agent_id.lower() in f.stem.lower() and f.name != "README.md"
        ]
        if not candidates:
            print(red(f"❌ 未找到专家: {agent_id}"))
            print(f"   运行 {bold('byoe agents')} 查看所有可用专家 ID")
            return
        if len(candidates) == 1:
            target = candidates[0]
        else:
            print(yellow(f"⚠️  找到多个匹配的专家，请指定完整 ID:"))
            for c in candidates:
                print(f"   {c.stem}")
            return

    content = target.read_text(encoding="utf-8")
    meta = _parse_frontmatter(content)

    # 去掉 frontmatter，只显示 Markdown 正文
    body = re.sub(r"^---.*?---\s*", "", content, flags=re.DOTALL).strip()

    print(f"\n🤖 {bold(target.stem)}")
    if meta.get("name"):
        print(f"   {cyan(meta['name'])}")
    if meta.get("category"):
        print(f"   分类: {meta['category']}")
    if meta.get("stages"):
        print(f"   适用阶段: {meta['stages']}")
    print()
    print(body)
    print()


def _parse_frontmatter(content: str) -> dict:
    """简单解析 YAML frontmatter（不依赖 pyyaml）"""
    if not content.startswith("---"):
        return {}
    end = content.find("---", 3)
    if end == -1:
        return {}
    fm = content[3:end].strip()
    result: dict = {}
    for line in fm.splitlines():
        if ":" in line:
            key, _, value = line.partition(":")
            result[key.strip()] = value.strip().strip('"').strip("'")
    return result


def _parse_stages(stages_str: str) -> list[str]:
    """将 '[P,D,E]' 或 'P,D,E' 解析为列表"""
    stages_str = stages_str.strip("[]")
    if not stages_str:
        return []
    return [s.strip() for s in stages_str.split(",") if s.strip()]
