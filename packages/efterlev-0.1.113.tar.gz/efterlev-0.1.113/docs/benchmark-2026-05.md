# Time-to-FRMR benchmark — methodology + results

**Status:** v0.1.112 ships the harness + methodology. Result tables
populated by maintainer-dispatched runs of the
`benchmark-dispatch.yml` workflow. Update this file with each
result-publishing release.

**Last updated:** 2026-05-15 (v0.1.112 harness ships; numbers pending).

---

## What this measures

**Time-to-FRMR** is the wall-clock from invoking `efterlev report run`
to the last artifact landing on disk. The pipeline at v0.1.111 is:

```
init → scan → agent gap → agent document → poam → oscal poam → oscal component-definition
```

Three deterministic stages (init, scan, poam, oscal poam, oscal cd)
plus two LLM-bearing stages (agent gap, agent document). The benchmark
captures:

- **Wall-clock seconds** — the number a customer cares about.
- **LLM cost (USD)** — sum of receipts.log entries past pipeline-start.
- **Token usage per model** — input + output tokens for cost-vs-quality
  reasoning.
- **KSI classifications produced** — sanity check on output volume.
- **Artifact presence** — did we actually land OSCAL POA&M + CD on
  disk (regression guard against silent failure modes).

## What this is NOT measuring

- **Authorization timeline.** *"Tool work done in 12 minutes"* is not
  *"FedRAMP authorization in 12 minutes."* The customer-review, 3PAO
  assessment, and FedRAMP PMO acceptance steps remain. Don't read the
  numbers as authorization-completion metrics.
- **Customer review of drafted artifacts.** Every Efterlev-drafted
  narrative carries `requires_review: Literal[True]`; reviewer time is
  the next-largest term in the equation, and Efterlev doesn't measure
  it.
- **Anything beyond a fixture.** The numbers reflect repo-shape
  fixtures vendored under `evals/fixtures/`. Customer codebases will
  vary: bigger codebases → more evidence to classify → more LLM tokens
  → higher wall-clock. The published numbers are floor estimates for a
  Phase-2-lite-shaped workload.

## How to reproduce

**Local (uses your `ANTHROPIC_API_KEY`):**

```bash
uv run python scripts/benchmark.py \
    --fixture evals/fixtures/csp-starter-cfn \
    --model claude-haiku-4-5 \
    --runs 3
```

Output lands under `.benchmark-results/<timestamp>/summary.json` with
per-run + aggregate (mean, median, p95, max) for wall-clock + cost.

**CI (workflow_dispatch):**

```bash
gh workflow run benchmark-dispatch.yml \
    -f fixture=evals/fixtures/csp-starter-cfn \
    -f llm_model=claude-haiku-4-5 \
    -f runs=3
```

The workflow uploads `.benchmark-results/**` as an artifact retained
for 90 days; download via `gh run download`.

## Methodology

**Why latency is reported as median + p95 + max, not just mean.**
Anthropic API latency is bimodal: most runs cluster near 60-90s for a
typical Phase-2-lite fixture, but the tail extends to 200s+ when the
API hits regional load. Mean alone hides the tail. Customer-experience
math uses p95 (the worst run in 20).

**Why N=3 by default.** Three runs is the smallest sample where median
is meaningful and p95 is suggestive. N=10 would be more statistically
sound but costs ~3.3× more API spend; for a maintainer-dispatched
benchmark, N=3 + occasional N=10 deep-dive is the right ratio.

**Why Haiku 4.5 is the default measurement model.** The CFN
maintainer-validation pass at v0.1.81 + v0.1.98 hit 44/44 = 100%
precision + 100% recall on Haiku 4.5 across two fixtures. If
classification quality is invariant on Haiku for fixture-shaped
workloads, then the cost-sensitive default is Haiku — and the
benchmark numbers should reflect that. Run on Sonnet or Opus when you
want quality-vs-cost comparison data.

**Why the full pipeline (not just gap agent).** Customers invoke
`efterlev report run`, which includes init, scan, gap, document, poam,
and OSCAL emit. Benchmarking gap-only undercounts wall-clock by ~30-50%
versus what a customer actually experiences.

**Bedrock backend** — supported via `--backend bedrock`. Per AWS pricing
agreements, Bedrock-Haiku is typically ~30% cheaper than Anthropic API
Haiku in commercial regions; published numbers should specify backend.

## Fixtures

Five fixtures vendored under `evals/fixtures/` are appropriate for the
benchmark:

| Fixture | IaC | Resource count (approx) | Notes |
|--|--|--|--|
| `csp-starter-cfn` | CloudFormation | ~30 resources | v0.1.78 first labeled CFN fixture; Phase 2 lite ground-truth |
| `aws-vpc-cfn` | CloudFormation | ~40 resources | v0.1.97; AWS Quick Start VPC |
| `aws-vpc-tfm` | Terraform module | ~50 resources | terraform-aws-modules/vpc |
| `aws-s3-bucket-tfm` | Terraform module | ~10 resources | terraform-aws-modules/s3-bucket |
| `aws-lambda-tfm` | Terraform module | ~20 resources | terraform-aws-modules/lambda |

Smaller fixtures (`govnotes-v1`, `iam-dynamic-policy`,
`encryption-mixed`, `serverless-mixed`, `runtime-monitoring`) are
useful for unit-test-shape benchmarks but aren't representative of
customer codebases.

## Results

### v0.1.112 — initial run (pending)

> **Status:** Harness ships; first benchmark dispatch scheduled
> alongside v0.1.112.1 release. Update this section with the
> `summary.json` aggregate per-fixture once the dispatch lands.

Template:

| Fixture | Model | Backend | N | Wall-clock (median / p95 / max) | Cost (median / max) | KSIs |
|--|--|--|--|--|--|--|
| csp-starter-cfn | claude-haiku-4-5 | anthropic | 3 | _ / _ / _ s | _ / _ USD | _ |
| csp-starter-cfn | claude-sonnet-4-6 | anthropic | 3 | _ / _ / _ s | _ / _ USD | _ |
| aws-vpc-cfn | claude-haiku-4-5 | anthropic | 3 | _ / _ / _ s | _ / _ USD | _ |
| aws-vpc-tfm | claude-haiku-4-5 | anthropic | 3 | _ / _ / _ s | _ / _ USD | _ |
| aws-s3-bucket-tfm | claude-haiku-4-5 | anthropic | 3 | _ / _ / _ s | _ / _ USD | _ |
| aws-lambda-tfm | claude-haiku-4-5 | anthropic | 3 | _ / _ / _ s | _ / _ USD | _ |

## Comparison framing

Paramify markets *"FedRAMP 20x authorization in 30 days"* as a
service-engagement duration: their solutions-engineering team + the
customer's compliance lead + a 3PAO. Efterlev's *"time-to-FRMR"* is a
single CLI invocation on the customer's laptop or CI runner. **The two
numbers measure different things.** Efterlev does not — and cannot —
shorten the 3PAO assessment timeline. What it does is take the
draft-FRMR step (the artifact a customer hands to a 3PAO) from
~weeks-to-author down to minutes-of-LLM-runtime + reviewer hours.

For honest competitive use:

- **Pair every benchmark number with the LIMITATIONS caveat** in the
  same surface (README headline, marketing site, blog post). Don't
  ship the time without the "this is tool runtime, not authorization"
  framing — the same discipline LIMITATIONS.md applies to every other
  Efterlev claim.
- **Don't divide.** "Efterlev N× faster than Paramify" is meaningless
  when the units differ. Report Efterlev's number; let the reader
  bring Paramify's number.

## Refresh cadence

Re-run after material changes to:

- The agent prompts (Gap, Documentation, Remediation) — affects token
  count + classification quality.
- The detector set — affects evidence count → token count.
- The OSCAL output stages (deterministic, but adds wall-clock).
- New labeled fixtures vendored under `evals/fixtures/`.

Otherwise: re-run quarterly to track LLM-provider-side latency drift.
