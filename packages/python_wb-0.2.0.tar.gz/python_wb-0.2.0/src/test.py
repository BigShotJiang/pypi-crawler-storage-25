import asyncio
from pywb import WBClient
from pywb.exceptions import BadRequestError


async def main():
    token = "eyJhbGciOiJFUzI1NiIsImtpZCI6IjIwMjYwMzAydjEiLCJ0eXAiOiJKV1QifQ.eyJhY2MiOjEsImVudCI6MSwiZXhwIjoxNzkwMzk3MTQxLCJpZCI6IjAxOWQzMDIzLWJkMGMtNzYyNy1hZmQ4LTVmOGIwMWVmOGEwYyIsImlpZCI6MTI4NDg1NDE5LCJvaWQiOjI1MDEyNDEwOCwicyI6MTYxMjYsInNpZCI6ImJjMDRiNDUyLTlkMWMtNDM3MC1hZDUwLTc1NDQzYmJiZWQzMCIsInQiOmZhbHNlLCJ1aWQiOjEyODQ4NTQxOX0.r2N1FXLRM8PZM43PzkKa4HgrdFSYf5Nz3s2JXUPrcUOZ0RicfvWqa4JowK6FVDps8pHoqsnHDukuRLvNKqvCbQ"

    async with WBClient(token, is_sandbox=False) as client:
        try:
            result = await client.get_seller_info()
            print(result.tin, result.name, result.sid, result.trade_mark)
        except BadRequestError as e:
            print(f"Error: {e}", e.payload)


if __name__ == "__main__":
    asyncio.run(main())