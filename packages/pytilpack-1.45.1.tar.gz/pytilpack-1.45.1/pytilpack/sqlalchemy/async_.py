"""SQLAlchemy用のユーティリティ集（async版）。"""

import asyncio
import contextlib
import contextvars
import dataclasses
import logging
import secrets
import threading
import typing

import sqlalchemy
import sqlalchemy.ext.asyncio
import sqlalchemy.sql.base

import pytilpack.asyncio
import pytilpack.paginator
from pytilpack.sqlalchemy._base import _ReprMixin, _ToDictMixin, _WaitForConnectionState

logger = logging.getLogger(__name__)


@dataclasses.dataclass
class _InitArgs:
    """init()の引数。"""

    url: str | sqlalchemy.engine.URL
    autoflush: bool
    expire_on_commit: bool
    engine_kwargs: dict


class AsyncMixin(sqlalchemy.ext.asyncio.AsyncAttrs, _ReprMixin, _ToDictMixin):
    """モデルのベースクラス。SQLAlchemy 2.0スタイル・async前提。

    Examples:
        モデル定義例::

            class Base(sqlalchemy.orm.DeclarativeBase, pytilpack.sqlalchemy_.AsyncMixin):
                pass

            class User(Base):
                __tablename__ = "users"
                ...

        Quart例::

            @app.before_request
            async def _before_request() -> None:
                quart.g.db_session_token = await models.Base.start_session()

            @app.teardown_request
            async def _teardown_request(_: BaseException | None) -> None:
                if hasattr(quart.g, "db_session_token"):
                    await models.Base.close_session(quart.g.db_session_token)
                    del quart.g.db_session_token

    """

    _init_args: _InitArgs | None = None
    """初期化引数。init()呼び出し後に設定される。"""

    _thread_local: threading.local | None = None
    """スレッドローカルストレージ。init()呼び出し後に設定される。"""

    session_var: contextvars.ContextVar[sqlalchemy.ext.asyncio.AsyncSession] = contextvars.ContextVar("session_var")
    """セッション。"""

    @classmethod
    def init(
        cls,
        url: str | sqlalchemy.engine.URL,
        pool_size: int | None = None,
        max_overflow: int | None = None,
        pool_recycle: int | None = 280,
        pool_pre_ping: bool = True,
        autoflush: bool = True,
        expire_on_commit: bool = False,
        eagerly_init: bool = True,
        **kwargs: typing.Any,
    ) -> None:
        """DB接続を初期化する。(推奨される既定設定を適用する。)

        engineとsessionmakerはスレッドローカルで遅延初期化される。
        各スレッドが初めてDB操作を行う際にそのスレッド専用のengineとsessionmakerが生成される。

        Args:
            url: DB接続URL。
            pool_size: コネクションプールのサイズ。スレッド数に応じて調整要。負数の場合はプーリングを無効化する。
            max_overflow: コネクションプールの最大オーバーフロー数。Noneの場合はデフォルト値を使用。
            pool_recycle: コネクションプールのリサイクル時間。Noneの場合はデフォルト値を使用。
            pool_pre_ping: コネクションプールのプレピン。Noneの場合はデフォルト値を使用。
            autoflush: セッションのautoflushフラグ。デフォルトはTrue。
            expire_on_commit: セッションのexpire_on_commitフラグ。デフォルトはFalse。
            eagerly_init: Trueの場合（デフォルト）、呼び出し元スレッドのengineとsessionmakerをすぐに生成する。
            **kwargs: その他のsqlalchemy.create_async_engine()へのキーワード引数。

        """
        if cls._init_args is not None:
            raise RuntimeError("DB接続はすでに初期化されています。")

        if pool_size is not None and pool_size < 0:
            engine_kwargs = kwargs.copy()
            engine_kwargs["poolclass"] = sqlalchemy.pool.NullPool
        else:
            if pool_size is not None and max_overflow is None:
                max_overflow = pool_size * 1  # デフォルトで倍まで許可
            engine_kwargs = kwargs.copy()
            if pool_size is not None:
                engine_kwargs["pool_size"] = pool_size
            if max_overflow is not None:
                engine_kwargs["max_overflow"] = max_overflow
        if pool_recycle is not None:
            engine_kwargs["pool_recycle"] = pool_recycle
        if pool_pre_ping is not None:
            engine_kwargs["pool_pre_ping"] = pool_pre_ping

        cls._init_args = _InitArgs(
            url=url,
            autoflush=autoflush,
            expire_on_commit=expire_on_commit,
            engine_kwargs=engine_kwargs,
        )
        cls._thread_local = threading.local()

        if eagerly_init:
            cls._get_engine_and_sessionmaker()

    @classmethod
    async def term(cls) -> None:
        """現在のスレッドのDB接続を終了する。

        スレッドローカルなengineをdisposeして解放する。
        スレッド終了時やテスト後の後始末に使用する。

        """
        if cls._init_args is None:
            logger.warning("未初期化時のterm()呼び出し")
            return
        if cls._thread_local is None:
            return
        if hasattr(cls._thread_local, "engine") and cls._thread_local.engine is not None:
            await cls._thread_local.engine.dispose()
            cls._thread_local.engine = None
            cls._thread_local.sessionmaker = None

    @classmethod
    def _get_engine_and_sessionmaker(
        cls,
    ) -> tuple[
        sqlalchemy.ext.asyncio.AsyncEngine,
        sqlalchemy.ext.asyncio.async_sessionmaker[sqlalchemy.ext.asyncio.AsyncSession],
    ]:
        """現在のスレッドのengineとsessionmakerを取得する（なければ遅延生成）。"""
        if cls._init_args is None:
            raise RuntimeError("init()が呼ばれていません。")
        if cls._thread_local is None:
            raise RuntimeError("init()が呼ばれていません。")
        if not hasattr(cls._thread_local, "engine") or cls._thread_local.engine is None:
            cls._thread_local.engine = sqlalchemy.ext.asyncio.create_async_engine(
                cls._init_args.url, **cls._init_args.engine_kwargs
            )
            cls._thread_local.sessionmaker = sqlalchemy.ext.asyncio.async_sessionmaker(
                cls._thread_local.engine,
                autoflush=cls._init_args.autoflush,
                expire_on_commit=cls._init_args.expire_on_commit,
            )
        return cls._thread_local.engine, cls._thread_local.sessionmaker

    @classmethod
    def engine(cls) -> sqlalchemy.ext.asyncio.AsyncEngine:
        """現在のスレッドのDB接続を返す。init()後に初めて呼ばれた時点で遅延生成される。"""
        return cls._get_engine_and_sessionmaker()[0]

    @classmethod
    def sessionmaker(
        cls,
    ) -> sqlalchemy.ext.asyncio.async_sessionmaker[sqlalchemy.ext.asyncio.AsyncSession]:
        """現在のスレッドのセッションファクトリを返す。init()後に初めて呼ばれた時点で遅延生成される。"""
        return cls._get_engine_and_sessionmaker()[1]

    @classmethod
    def connect(cls) -> sqlalchemy.ext.asyncio.AsyncConnection:
        """DBに接続する。

        使用例::
            async with Base.connect() as conn:
                await conn.run_sync(Base.metadata.create_all)

        """
        return cls.engine().connect()

    @classmethod
    @contextlib.asynccontextmanager
    async def session_scope(
        cls,
        name: str | None = None,
        log_level: int = logging.DEBUG,
    ):
        """セッションを開始するコンテキストマネージャ。

        使用例::
            async with Base.session_scope() as session:
                ...

        Args:
            name: セッション名。指定時のみログ出力する。
            log_level: ログレベル。

        """
        token = await cls.start_session(name=name, log_level=log_level)
        try:
            yield cls.session()
        finally:
            await cls.close_session(token, name=name, log_level=log_level)

    @classmethod
    async def start_session(
        cls, name: str | None = None, log_level: int = logging.DEBUG
    ) -> contextvars.Token[sqlalchemy.ext.asyncio.AsyncSession]:
        """セッションを開始する。"""
        session = cls.sessionmaker()()  # pylint: disable=not-callable
        token = cls.session_var.set(session)
        if name is not None:
            logger.log(
                log_level,
                f"セッション開始: {name} session={id(session):x},"
                f" thread={threading.get_ident():x},"
                f" task={pytilpack.asyncio.get_task_id_hex()}",
            )
        return token

    @classmethod
    async def close_session(
        cls,
        token: contextvars.Token[sqlalchemy.ext.asyncio.AsyncSession],
        name: str | None = None,
        log_level: int = logging.DEBUG,
    ) -> None:
        """セッションを終了する。"""
        session = cls.session()
        if name is not None:
            logger.log(
                log_level,
                f"セッション終了: {name} session={id(session):x},"
                f" thread={threading.get_ident():x},"
                f" task={pytilpack.asyncio.get_task_id_hex()}",
            )
        await asafe_close(session)
        cls.session_var.reset(token)

    @classmethod
    def session(cls) -> sqlalchemy.ext.asyncio.AsyncSession:
        """セッションを取得する。"""
        sess = cls.session_var.get(None)
        if sess is None:
            raise RuntimeError(f"セッションが開始されていません。{cls.__qualname__}.start_session()を呼び出してください。")
        return sess

    @classmethod
    def select(cls) -> sqlalchemy.Select[tuple[typing.Self]]:
        """sqlalchemy.Selectを返す。"""
        # cls.count()などでfrom句が消えないように明示的にfrom句を指定して返す。
        return sqlalchemy.select(cls).select_from(cls)

    @classmethod
    def insert(cls) -> sqlalchemy.Insert:
        """sqlalchemy.Insertを返す。"""
        return sqlalchemy.insert(cls)

    @classmethod
    def update(cls) -> sqlalchemy.Update:
        """sqlalchemy.Updateを返す。"""
        return sqlalchemy.update(cls)

    @classmethod
    def delete(cls) -> sqlalchemy.Delete:
        """sqlalchemy.Deleteを返す。"""
        return sqlalchemy.delete(cls)

    @classmethod
    async def count(cls, query: sqlalchemy.Select | sqlalchemy.CompoundSelect) -> int:
        """queryのレコード数を取得する。"""
        # pylint: disable=not-callable
        return (
            await cls.scalar_one_or_none(
                sqlalchemy.select(sqlalchemy.func.count()).select_from(query.order_by(None).subquery())
            )
            or 0
        )

    @classmethod
    async def scalar_one[T](cls, query: sqlalchemy.Select[tuple[T]] | sqlalchemy.CompoundSelect[tuple[T]]) -> T:
        """queryの結果を1件取得する。

        Args:
            query: クエリ。

        Returns:
            1件のインスタンス。

        Raises:
            sqlalchemy.exc.NoResultFound: 結果が0件の場合。
            sqlalchemy.exc.MultipleResultsFound: 結果が複数件の場合。

        """
        return (await cls.session().execute(query)).scalar_one()

    @classmethod
    async def scalar_one_or_none[T](cls, query: sqlalchemy.Select[tuple[T]] | sqlalchemy.CompoundSelect[tuple[T]]) -> T | None:
        """queryの結果を0件または1件取得する。

        Args:
            query: クエリ。

        Returns:
            0件の場合はNone、1件の場合はインスタンス。

        Raises:
            sqlalchemy.exc.MultipleResultsFound: 結果が複数件の場合。

        """
        return (await cls.session().execute(query)).scalar_one_or_none()

    @classmethod
    async def scalars[T](cls, query: sqlalchemy.Select[tuple[T]] | sqlalchemy.CompoundSelect[tuple[T]]) -> list[T]:
        """queryの結果を全件取得する。

        Args:
            query: クエリ。

        Returns:
            全件のインスタンスのリスト。

        """
        return list((await cls.session().execute(query)).scalars().all())

    @classmethod
    async def one[TT: tuple](cls, query: sqlalchemy.Select[TT] | sqlalchemy.CompoundSelect[TT]) -> sqlalchemy.Row[TT]:
        """queryの結果を1件取得する。

        Args:
            query: クエリ。

        Returns:
            1件のインスタンス。

        Raises:
            sqlalchemy.exc.NoResultFound: 結果が0件の場合。
            sqlalchemy.exc.MultipleResultsFound: 結果が複数件の場合。

        """
        return (await cls.session().execute(query)).one()

    @classmethod
    async def one_or_none[TT: tuple](
        cls, query: sqlalchemy.Select[TT] | sqlalchemy.CompoundSelect[TT]
    ) -> sqlalchemy.Row[TT] | None:
        """queryの結果を0件または1件取得する。

        Args:
            query: クエリ。

        Returns:
            0件の場合はNone、1件の場合はインスタンス。

        Raises:
            sqlalchemy.exc.MultipleResultsFound: 結果が複数件の場合。

        """
        return (await cls.session().execute(query)).one_or_none()

    @classmethod
    async def all[TT: tuple](cls, query: sqlalchemy.Select[TT] | sqlalchemy.CompoundSelect[TT]) -> list[sqlalchemy.Row[TT]]:
        """queryの結果を全件取得する。

        Args:
            query: クエリ。

        Returns:
            全件のインスタンスのリスト。

        """
        return list((await cls.session().execute(query)).all())

    @classmethod
    async def get_by_id_not_null(
        cls, id_: int, for_update: bool = False, options: sqlalchemy.sql.base.ExecutableOption | None = None
    ) -> typing.Self:
        """IDを元にインスタンスを取得。見つからない場合は例外を出す。

        Args:
            id_: ID。
            for_update: 更新ロックを取得するか否か。
            options: クエリオプション。eager loadingなどに使用する。

        Returns:
            インスタンス。
        Raises:
            ValueError: 見つからない場合。
        """
        instance = await cls.get_by_id(id_, for_update=for_update, options=options)
        if instance is None:
            raise ValueError(f"{cls.__qualname__}が見つかりませんでした。id={id_}")
        return instance

    @classmethod
    async def get_by_id(
        cls, id_: int, for_update: bool = False, options: sqlalchemy.sql.base.ExecutableOption | None = None
    ) -> typing.Self | None:
        """IDを元にインスタンスを取得。

        Args:
            id_: ID。
            for_update: 更新ロックを取得するか否か。
            options: クエリオプション。eager loadingなどに使用する。

        Returns:
            インスタンス。

        """
        q = cls.select().where(cls.id == id_)  # type: ignore  # pylint: disable=no-member
        if options is not None:
            q = q.options(options)
        if for_update:
            q = q.with_for_update()
        return await cls.scalar_one_or_none(q)  # type: ignore[arg-type]

    @classmethod
    async def paginate(
        cls,
        query: sqlalchemy.Select | sqlalchemy.CompoundSelect,
        page: int,
        per_page: int,
        scalar: bool = True,
    ) -> pytilpack.paginator.Paginator:
        """Flask-SQLAlchemy風ページネーション。

        Args:
            query: ページネーションするクエリ。
            page: ページ番号。
            per_page: 1ページあたりのアイテム数。
            scalar: Trueの場合、スカラー値を返す。Falseの場合、全件のインスタンスを返す。

        Returns:
            ページネーションされた結果を返すpytilpack.paginator.Paginatorインスタンス。
        """
        if page <= 0:
            raise ValueError(f"ページ番号は1以上でなければなりません: page={page}")
        if per_page <= 0:
            raise ValueError(f"1ページあたりのアイテム数は1以上でなければなりません: per_page={per_page}")
        total = await cls.count(query)
        page_query = query.offset((page - 1) * per_page).limit(per_page)
        items = await (cls.scalars(page_query) if scalar else cls.all(page_query))
        # pylint: disable=protected-access
        return pytilpack.paginator.Paginator(page=page, per_page=per_page, items=items, total=total)

    @classmethod
    def run_with_session[**P, R](cls, func: typing.Callable[P, typing.Awaitable[R]], *args: P.args, **kwargs: P.kwargs) -> R:
        """非同期関数をセッション付きで同期実行する関数。

        Args:
            func: デコレート対象の非同期関数
            *args: 非同期関数への引数
            **kwargs: 非同期関数へのキーワード引数

        Returns:
            非同期関数の戻り値
        """

        async def wrapper() -> R:
            async with cls.session_scope():
                return await func(*args, **kwargs)

        return pytilpack.asyncio.run(wrapper())


class AsyncUniqueIDMixin:
    """self.unique_idを持つテーブルクラスに便利メソッドを生やすmixin。"""

    @classmethod
    def generate_unique_id(cls) -> str:
        """ユニークIDを生成する。"""
        return secrets.token_urlsafe(32)

    @classmethod
    async def get_by_unique_id(
        cls: type[typing.Self],
        unique_id: str | int,
        allow_id: bool = False,
        for_update: bool = False,
    ) -> typing.Self | None:
        """ユニークIDを元にインスタンスを取得。

        Args:
            unique_id: ユニークID。
            allow_id: ユニークIDだけでなくID(int)も許可するかどうか。
            for_update: 更新ロックを取得するか否か。

        Returns:
            インスタンス。

        """
        assert issubclass(cls, AsyncMixin)
        if allow_id and isinstance(unique_id, int):
            q = cls.select().where(cls.id == unique_id)  # type: ignore
        else:
            q = cls.select().where(cls.unique_id == unique_id)  # type: ignore
        if for_update:
            q = q.with_for_update()
        return await cls.scalar_one_or_none(q)


async def await_for_connection(url: str, timeout: float = 180.0) -> None:
    """DBに接続可能になるまで待機する。"""
    state = _WaitForConnectionState(url, timeout)
    while True:
        try:
            engine = sqlalchemy.ext.asyncio.create_async_engine(url)
            try:
                async with engine.connect() as connection:
                    await connection.execute(sqlalchemy.text("SELECT 1"))
            finally:
                await engine.dispose()
            state.on_success()
            break
        except Exception as e:
            await asyncio.sleep(state.on_failure(e))


async def asafe_close(session: sqlalchemy.ext.asyncio.AsyncSession, log_level: int | None = logging.DEBUG):
    """例外を出さずにセッションをクローズ。"""
    try:
        await asyncio.shield(session.close())
    except Exception:
        if log_level is not None:
            logger.log(log_level, "セッションクローズ失敗", exc_info=True)
