"""Shared MCP/REST tool definitions."""

TOOLS = [
    {
        "name": "smrti_remember",
        "description": """Store a memory, belief, or observation.

When calling this tool, you MUST:
- Resolve ALL pronouns to explicit names ("he" → "Dave", "that project" → "Project Alpha")
- Correct obvious typos ("pythn" → "Python", "k8s" → "Kubernetes")
- Break complex statements into the most atomic form possible
- Include emotional valence when sentiment is expressed (-1.0 to 1.0)
- Use negative valence (-0.5 to -1.0) for errors, failures, and things to avoid

Use type=belief with an evidence string to assert a probabilistic fact (starts with lower initial confidence, builds through evidence). The system extracts entities, assigns truth values, and links to existing knowledge.""",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "The memory or observation to store"},
                "type": {"type": "string", "enum": ["belief", "episode", "goal"], "default": "episode"},
                "probability": {"type": "number", "description": "How true is this (0-1)", "default": 0.8},
                "valence": {"type": "number", "description": "Emotional tone (-1 to 1)", "default": 0.0},
                "evidence": {"type": "string", "description": "Why you believe this (only used when type=belief)"},
            },
            "required": ["content"],
        },
    },
    {
        "name": "smrti_recall",
        "description": "Retrieve relevant memories using salience-scored search. Returns memories with their truth values, confidence, and emotional context. Each memory includes a `severity` field: `critical_warning` means a past mistake — DO NOT repeat; `known_antipattern` means a disproven belief — avoid this approach; `context` is neutral background.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "What to recall"},
                "top_k": {"type": "integer", "default": 10},
                "min_confidence": {"type": "number", "default": 0.1},
            },
            "required": ["query"],
        },
    },
    {
        "name": "smrti_reflect",
        "description": "Trigger a consolidation pass. Updates beliefs based on evidence, decays attention, discovers new connections. Returns a summary of changes.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "smrti_forget",
        "description": "Lower confidence on a memory or belief. Does not hard-delete — the consolidation epoch handles pruning.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "What to forget"},
                "reason": {"type": "string"},
            },
            "required": ["query"],
        },
    },
    {
        "name": "smrti_personality",
        "description": "Get or set the agent's personality profile. Affects how memories are scored, how fast beliefs change, and emotional reactivity.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "enum": ["get", "set", "preset"]},
                "preset": {"type": "string", "enum": ["balanced", "analytical", "curious", "empathetic", "maverick", "deterministic"]},
                "params": {"type": "object", "description": "Custom personality parameters"},
            },
            "required": ["action"],
        },
    },
    {
        "name": "smrti_status",
        "description": "Get memory statistics: total atoms, active beliefs, emotional state, attention distribution, and list of all spaces for this tenant.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "smrti_space_query",
        "description": "Query the relationship between two memory spaces. op=overlap returns Jaccard similarity and matched atom pairs; op=intersection returns atoms present in both spaces; op=diff returns atoms unique to the current space.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "op": {"type": "string", "enum": ["overlap", "intersection", "diff"]},
                "other_space": {"type": "string", "description": "The space to compare with"},
                "threshold": {"type": "number", "description": "Contextual similarity threshold (0-1)", "default": 0.85},
            },
            "required": ["op", "other_space"],
        },
    },
    {
        "name": "smrti_space_merge",
        "description": "Materialize a bridge space from the overlap between the current space and another. Creates new atoms that represent shared concepts with merged truth values, attention, and valence. The bridge space can evolve independently and accumulate its own memories.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "other_space": {"type": "string", "description": "The space to merge with"},
                "threshold": {"type": "number", "default": 0.85},
                "min_jaccard": {"type": "number", "description": "Minimum overlap score to trigger materialization", "default": 0.1},
            },
            "required": ["other_space"],
        },
    },
]
