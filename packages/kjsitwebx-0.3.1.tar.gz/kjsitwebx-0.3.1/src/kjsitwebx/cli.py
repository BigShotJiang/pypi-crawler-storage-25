import os
import sys
from importlib import resources 

def extract_resource_tree(resource_dir, target_dir):
    """
    Recursively copies files and directories from the package to the target directory.
    """
    # Loop through everything inside the current resource directory
    for item in resource_dir.iterdir():
        
        # Ignore Python's internal files and cache directories at all levels
        if item.name.startswith('__'):
            continue
            
        # Figure out the exact path where this item should go on the user's computer
        dest_path = os.path.join(target_dir, item.name)
        
        if item.is_file():
            # If it's a file, read the bytes and write them to the destination
            with open(dest_path, 'wb') as dest_file:
                dest_file.write(item.read_bytes())
            print(f"✅ Dropped file: {dest_path}")
            
        elif item.is_dir():
            # If it's a folder, create the folder on the user's computer
            os.makedirs(dest_path, exist_ok=True)
            print(f"📁 Created folder: {dest_path}")
            
            # 🔄 RECURSION: Call this exact same function again, but pass it 
            # the new sub-folder and the new destination path!
            extract_resource_tree(item, dest_path)


def main():
    # Get the directory where the user executed the command
    target_dir = os.getcwd()
    
    print(f"Extracting files into: {target_dir} ...\n")

    try:
        # Access the root 'codes' module inside our package
        base_template_dir = resources.files('kjsitwebx.codes')
        
        # Start the recursive extraction process
        extract_resource_tree(base_template_dir, target_dir)
                
        print("\n🎉 All files and folders successfully extracted!")

    except Exception as e:
        print(f"❌ Error extracting files: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()