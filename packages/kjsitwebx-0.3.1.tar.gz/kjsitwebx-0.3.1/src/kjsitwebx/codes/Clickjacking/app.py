from flask import Flask, request, render_template

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    name = "def"
    if request.method == "POST":
        name = request.form.get("name")
    print(f"Received name: {name}")
    return render_template("form.html")

app.run(debug=True)