import sqlite3

# This connects to 'test.db' (and creates the file if it doesn't exist)
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Create the 'users' table
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL
    )
''')

# Clear out any old data just in case you run this multiple times
cursor.execute("DELETE FROM users")

# Insert some dummy data so we have something to "hack"
cursor.execute("INSERT INTO users (username, password) VALUES ('admin', 'supersecret_admin_pass')")
cursor.execute("INSERT INTO users (username, password) VALUES ('johndoe', 'password123')")

# Save the changes and close the connection
conn.commit()
conn.close()

print("Database and 'users' table created successfully!")