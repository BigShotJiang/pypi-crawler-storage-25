import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms'; // You MUST import this for forms

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule], // Add it here
  template: `
    <h2>Validation Form</h2>

    <!-- Create the form and link it to an event -->
    <form #myForm="ngForm" (ngSubmit)="submitForm()">
      
      <!-- Input with HTML 'required' validator -->
      <input name="user" ngModel required placeholder="Type something...">
      <br><br>

      <!-- Button is DISABLED if form.valid is false -->
      <button type="submit" [disabled]="!myForm.valid">
        Submit
      </button>

    </form>

    <h3 style="color: green;">{{ message }}</h3>
  `
})
export class AppComponent {
  message = '';

  // The Event Function
  submitForm() {
    this.message = "Form submitted successfully!";
  }
}