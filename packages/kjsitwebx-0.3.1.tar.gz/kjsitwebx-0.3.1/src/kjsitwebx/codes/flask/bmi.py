from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    result = ""
    if request.method == "POST":
        w = float(request.form["weight"])
        h = float(request.form["height"])
        bmi = w / (h * h)
        result = "BMI = " + str(round(bmi, 2))
    return render_template("bmi.html", result=result)

app.run(debug=True)