from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    message = ""
    if request.method == "POST":
        name = request.form["name"]
        feedback = request.form["feedback"]
        message = "Thank you " + name
    return render_template("feedback.html", message=message)

app.run(debug=True)