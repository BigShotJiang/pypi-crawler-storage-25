from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home():
    posts = ["Post 1", "Post 2", "Post 3"]
    return render_template("blog.html", posts=posts)

app.run(debug=True)