from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():
    result = ""
    if request.method == "POST":
        city = request.form["city"]
        result = "Weather in " + city + " is Sunny"
    return render_template("weather.html", result=result)

app.run(debug=True)