import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <h2>Feedback System</h2>

    <!-- Input Box -->
    <textarea #feedbackBox placeholder="Write your feedback here"></textarea>
    <br>
    
    <!-- Submit Button (Saves the text, then clears the box) -->
    <button (click)="submitFeedback(feedbackBox.value); feedbackBox.value = ''">
      Submit
    </button>

    <h3>Submitted Feedback:</h3>
    <ul>
      <!-- Loops through the array and prints each feedback -->
      @for (fb of feedbacks; track fb) {
        <li>{{ fb }}</li>
      }
    </ul>
  `
})
export class AppComponent {
  // Array to actually store the feedback
  feedbacks: string[] = [];

  submitFeedback(text: string) {
    if (text) {
      this.feedbacks.push(text); // Adds the new feedback to the list
    }
  }
}