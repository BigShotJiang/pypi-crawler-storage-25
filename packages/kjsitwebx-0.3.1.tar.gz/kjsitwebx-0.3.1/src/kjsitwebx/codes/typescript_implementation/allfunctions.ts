// 1. Named Function
function add(a: number, b: number) { 
    console.log("Add: " + (a + b)); 
}

// 2. Anonymous Function
let sub = function(a: number, b: number) { 
    console.log("Sub: " + (a - b)); 
};

// 3. Arrow Function
let mult = (a: number, b: number) => { 
    console.log("Mult: " + (a * b)); 
};

// OUTPUT CALLS
add(10, 5);  // Output: Add: 15
sub(10, 5);  // Output: Sub: 5
mult(10, 5); // Output: Mult: 50