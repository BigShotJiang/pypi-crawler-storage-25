class Animal { 
    eat() { 
    console.log("Eating"); 
} 
}

// 1. Single
class Dog extends Animal { 
    bark() { 
    console.log("Barking"); 
} 
}

// 2. Multilevel
class Puppy extends Dog { 
    weep() { 
    console.log("Weeping"); 
} 
}

// 3. Hierarchical
class Cat extends Animal { 
    meow() { 
    console.log("Meowing"); 
} 
}

// OUTPUT CALLS
let myPuppy = new Puppy();
myPuppy.eat();  // Output: Eating  (Inherited from Animal)
myPuppy.weep();
myPuppy.bark(); // Output: Barking (Inherited from Dog)

let myCat = new Cat();
myCat.eat();    // Output: Eating  (Inherited from Animal)