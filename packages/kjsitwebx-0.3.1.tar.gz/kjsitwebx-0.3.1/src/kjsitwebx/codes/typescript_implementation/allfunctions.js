// 1. Named Function
function add(a, b) {
    console.log("Add: " + (a + b));
}
// 2. Anonymous Function
var sub = function (a, b) {
    console.log("Sub: " + (a - b));
};
// 3. Arrow Function
var mult = function (a, b) {
    console.log("Mult: " + (a * b));
};
// OUTPUT CALLS
add(10, 5); // Output: Add: 15
sub(10, 5); // Output: Sub: 5
mult(10, 5); // Output: Mult: 50
