var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Animal = /** @class */ (function () {
    function Animal() {
    }
    Animal.prototype.eat = function () {
        console.log("Eating");
    };
    return Animal;
}());
// 1. Single
var Dog = /** @class */ (function (_super) {
    __extends(Dog, _super);
    function Dog() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Dog.prototype.bark = function () {
        console.log("Barking");
    };
    return Dog;
}(Animal));
// 2. Multilevel
var Puppy = /** @class */ (function (_super) {
    __extends(Puppy, _super);
    function Puppy() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Puppy.prototype.weep = function () {
        console.log("Weeping");
    };
    return Puppy;
}(Dog));
// 3. Hierarchical
var Cat = /** @class */ (function (_super) {
    __extends(Cat, _super);
    function Cat() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Cat.prototype.meow = function () {
        console.log("Meowing");
    };
    return Cat;
}(Animal));
// OUTPUT CALLS
var myPuppy = new Puppy();
myPuppy.eat(); // Output: Eating  (Inherited from Animal)
myPuppy.weep();
myPuppy.bark(); // Output: Barking (Inherited from Dog)
var myCat = new Cat();
myCat.eat(); // Output: Eating  (Inherited from Animal)
