interface Car {
    speed: number;
    drive(): void;
}

class MyCar implements Car {
    speed = 100;
    drive() { 
        console.log("Driving at " + this.speed); 
    }
}

// OUTPUT CALL
let c = new MyCar();
c.drive(); 
// Output: Driving at 100