function calculate(a: number, b: number, operator: string): number {
    switch (operator) {
        case '+': return a + b;
        case '-': return a - b;
        case '*': return a * b;
        case '/': return a / b;
        default: return 0; 
    }
}

console.log(calculate(10, 5, '+')); // Output: 15