var MyCar = /** @class */ (function () {
    function MyCar() {
        this.speed = 100;
    }
    MyCar.prototype.drive = function () { console.log("Driving at " + this.speed); };
    return MyCar;
}());
// OUTPUT CALL
var c = new MyCar();
c.drive();
// Output: Driving at 100
