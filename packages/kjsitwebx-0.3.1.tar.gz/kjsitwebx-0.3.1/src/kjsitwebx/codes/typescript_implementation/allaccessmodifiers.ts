class Person {
    public name = "John";      
    private age = 20;          
    protected salary = 5000;   
}

class Employee extends Person {
    showInfo() {
        console.log("Name: " + this.name);     // Public works
        console.log("Salary: " + this.salary); // Protected works
        // console.log(this.age); // ERROR: age is private
    }
}

// OUTPUT CALL
let emp = new Employee();
emp.showInfo(); 
// Output: Name: John
// Output: Salary: 5000
console.log(emp.name); // Output: John (Public is accessible)
// console.log(emp.salary); // ERROR: salary is protected
// console.log(emp.age); // ERROR: age is private