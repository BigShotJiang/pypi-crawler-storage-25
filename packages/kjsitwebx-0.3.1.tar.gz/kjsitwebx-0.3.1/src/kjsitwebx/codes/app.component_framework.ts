import { Component } from '@angular/core';

// 1. Create a tiny child component
@Component({
  selector: 'app-header',
  standalone: true,
  template: `<h1 style="color: blue;">My Simple Angular Page</h1>`
})
export class HeaderComponent {}

// 2. Your Main Component
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [HeaderComponent], // Import the child here
  template: `
    <!-- Using the Component -->
    <app-header></app-header> 

    <button (click)="showText = !showText">Toggle Text</button>

    <!-- Using a Directive (@if) -->
    @if(showText) {
      <p>The directive is working! This text can be hidden.</p>
    }
  `
})
export class AppComponent {
  showText = true; // This controls the @if directive
}