var btn = document.getElementById("myButton");
var out = document.getElementById("output");
btn.addEventListener("click", function () {
    out.innerHTML = "Hey! TypeScript is working!";
});
