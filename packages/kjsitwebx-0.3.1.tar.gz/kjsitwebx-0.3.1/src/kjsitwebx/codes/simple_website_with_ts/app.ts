let btn = document.getElementById("myButton")!;
let out = document.getElementById("output")!;

btn.addEventListener("click", () => {
    out.innerHTML = "Hey! TypeScript is working!";
});