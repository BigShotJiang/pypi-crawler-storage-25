import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  standalone: true,
  template: `
    <h2>Students Record</h2>
    
    <input #sName placeholder="Enter student name">
    <button (click)="addStudent(sName.value)">Add Student</button>

    <ul>
      <!-- New Angular @for syntax: No imports needed! -->
      @for (student of students; track student) {
        <li>{{ student }}</li>
      }
    </ul>
  `
})
export class AppComponent {
  students: string[] = ['Ramesh', 'Yohan'];

  addStudent(name: string) {
    if (name) {
      this.students.push(name);
    }
  }
}