from flask import Flask, request
import sqlite3
app = Flask(__name__)

# Fake database
users = {"admin": "1234", "dev": "pass"}

@app.route("/", methods=["GET", "POST"])
def login():
    output = ""

    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()

        

        # THIS is an actual SQL Injection vulnerability:
        query = f"SELECT * FROM users WHERE username = '{username}' AND password = '{password}'"
        cursor.execute(query)


        # ❌ XSS vulnerability (directly printing user input)
        output += "<br>Hello " + username

    return '''
        <h2>Login</h2>
        <form method="POST">
            Username: <input name="username"><br><br>
            Password: <input name="password"><br><br>
            <button type="submit">Login</button>
        </form>
        <h3>{}</h3>
    '''.format(output)

app.run(debug=True) 