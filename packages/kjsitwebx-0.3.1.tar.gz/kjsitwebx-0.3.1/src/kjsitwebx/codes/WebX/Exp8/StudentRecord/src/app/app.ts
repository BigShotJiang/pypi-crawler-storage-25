import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  selector: 'app-root',
  imports: [FormsModule, CommonModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {
  name: string = "";
  age: number | null = null;

  students: any[] = [];

  addStudent() {
    if (this.name === "" || this.age === null) {
      alert("Enter details");
      return;
    }

    this.students.push({
      name: this.name,
      age: this.age
    });

    // clear input
    this.name = "";
    this.age = null;
  }
}
