from flask import Flask, render_template, request

app = Flask(__name__)

users = ["abhinav", "rahul", "admin"]

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/validate', methods=['POST'])
def validate():
    username = request.form['username']

    if username.lower() in users:
        return "User already exists ❌"
    else:
        return "Username available ✅"

if __name__ == '__main__':
    app.run(debug=True)