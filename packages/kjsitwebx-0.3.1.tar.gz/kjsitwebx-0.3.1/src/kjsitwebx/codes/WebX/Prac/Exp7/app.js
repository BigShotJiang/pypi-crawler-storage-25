"use strict";
function Hii() {
    var name = document.getElementById("name").value;
    if (name === "") {
        alert("Please enter your name");
        return;
    }
    document.getElementById("output").innerHTML = "Hello, " + name + "! Welcome to Our Site";
}
