from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home():
    data = {
        "name": "Ishika",
        "role": "Frontend Developer",
        "skills": ["HTML", "CSS", "JavaScript", "React"],
        "projects": ["Student App", "Weather App", "Feedback System"]
    }
    return render_template("index.html", data=data)

if __name__ == "__main__":
    app.run(debug=True)