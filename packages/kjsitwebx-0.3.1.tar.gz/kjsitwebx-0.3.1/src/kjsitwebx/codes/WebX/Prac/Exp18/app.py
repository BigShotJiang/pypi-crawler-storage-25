from flask import Flask, render_template, request
app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def home():
    result=""
    bmi=""
    if request.method == "POST":
         height = request.form['height']
         weight = request.form['weight']
         bmi = float(weight) / (float(height) ** 2)
         if bmi < 18.5:
            result = "Underweight"
         elif bmi < 25:
            result = "Normal weight"
         elif bmi < 30:
            result = "Overweight"       
         else:
            result = "Obese"
         bmi = round(bmi, 2)
        
            
    return render_template('index.html', bmi=bmi, result=result)
        
if __name__ == '__main__':
    app.run(debug=True)