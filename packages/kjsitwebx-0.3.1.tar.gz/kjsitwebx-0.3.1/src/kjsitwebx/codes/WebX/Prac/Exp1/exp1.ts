let num1: number = 10;
let num2: number = 5;
let operator: string = "+"; // change this to test

let result: number;

switch (operator) {
    case "+":
        result = num1 + num2;
        break;

    case "-":
        result = num1 - num2;
        break;

    case "*":
        result = num1 * num2;
        break;

    case "/":
        result = num1 / num2;
        break;

    default:
        console.log("Invalid operator");
        result = 0;
}

console.log("Result =", result);
