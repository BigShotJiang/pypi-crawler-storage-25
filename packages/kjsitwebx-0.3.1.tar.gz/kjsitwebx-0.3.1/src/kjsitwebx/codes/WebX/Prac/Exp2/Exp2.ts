class user{
    login(){
        console.log("User logged in");
    }
}

class student extends user{
    study(){
        console.log("Student is studying");
    }
}

class Sportstudent extends student {
    play(){
        console.log("Sport student is playing");
    }
}

class teacher extends user{
    teach(){
        console.log("Teacher is teaching");
    }
}
 
interface Extra {
    logout(): void;
}

// Student taking from:
// ✔ User (class)
// ✔ Extra (interface)
class SmartStudent extends user implements Extra {
    study() {
        console.log("Smart student studying");
    }

    logout() {
        console.log("User logged out");
    }
}



let s = new student();
s.login();
s.study();
let t= new teacher();
t.login();
t.teach();
let sp = new Sportstudent();
sp.login();
sp.study();
sp.play();

let ss = new SmartStudent();
ss.login();
ss.study();
ss.logout();