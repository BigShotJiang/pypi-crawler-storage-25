# Design Weather app in Flask
from flask import Flask,render_template,request

app= Flask(__name__)

@app.route("/", methods=["POST","GET"])
def home():
        message=""
        
        if request.method=="POST":
            city=request.form["city"]
            if city.lower()=="delhi":
                message="Weather in Delhi: Sunny, 30°C ☀️"
            elif city.lower()=="mumbai":
                message= "Weather in Mumbai: Rainy, 25°C 🌧️"
            elif city.lower()=="kolkata":
                message="Weather in Kolkata: Cloudy, 28°C ☁️"
            else:
                message="City not found! Please try Delhi, Mumbai, or Kolkata." 
        return render_template("index.html", msg=message)
    
if __name__=="__main__":
    app.run(debug=True)