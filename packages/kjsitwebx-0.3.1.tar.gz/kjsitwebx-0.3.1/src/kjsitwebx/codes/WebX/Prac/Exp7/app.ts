function Hii() {
    let name = (document.getElementById("name") as HTMLInputElement).value;

    if (name === "") {
        alert("Please enter your name");
        return; // 🔥 important to stop further execution
    }

    document.getElementById("output")!.innerHTML =
        `Hello, ${name}! Welcome to Our Site`;
}