
from flask import Flask ,render_template,request

app= Flask(__name__)

@app.route("/", methods=["POST","GET"])
def home():
     message=""
     
     if request.method=="POST":
         name=request.form["name"]
         feedback=request.form["feedback"]
         message=f"Thank you {name} for your feedback! 😊<br> Your feedback: {feedback}"
     return render_template("index.html", msg=message)
 
if __name__=="__main__":
     app.run(debug=True)
    
