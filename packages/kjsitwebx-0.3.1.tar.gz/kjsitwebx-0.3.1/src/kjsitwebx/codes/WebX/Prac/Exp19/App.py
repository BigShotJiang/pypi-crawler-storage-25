from flask import Flask, request

app = Flask(__name__)

# 🔴 XSS DEMO
@app.route('/xss', methods=['GET', 'POST'])
def xss():
    name = ""
    if request.method == 'POST':
        name = request.form['name']   # unsafe input (no sanitization)

    return f"""
    <h2>XSS Demo</h2>
    <form method="POST">
        <input name="name" placeholder="Enter name">
        <button>Submit</button>
    </form>
    <p>Hello {name}</p>
    """


# 🔵 SQL INJECTION DEMO (simulated, no DB)
@app.route('/sql', methods=['GET', 'POST'])
def sql():
    msg = ""

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # ❌ unsafe logic (simulating SQL injection)
        if username == "admin" and password == "123":
            msg = "Login Successful"
        elif "' OR '1'='1" in password:
            msg = "Login Successful (SQL Injection)"
        else:
            msg = "Login Failed"

    return f"""
    <h2>SQL Injection Demo</h2>
    <form method="POST">
        <input name="username" placeholder="Username">
        <input name="password" placeholder="Password">
        <button>Login</button>
    </form>
    <p>{msg}</p>
    """

if __name__ == "__main__":
    app.run(debug=True)