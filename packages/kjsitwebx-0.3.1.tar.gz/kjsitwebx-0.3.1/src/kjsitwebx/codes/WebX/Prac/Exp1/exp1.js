"use strict";
let num1 = 10;
let num2 = 5;
let operator = "+"; // change this to test
let result;
switch (operator) {
    case "+":
        result = num1 + num2;
        break;
    case "-":
        result = num1 - num2;
        break;
    case "*":
        result = num1 * num2;
        break;
    case "/":
        result = num1 / num2;
        break;
    default:
        console.log("Invalid operator");
        result = 0;
}
console.log("Result =", result);
