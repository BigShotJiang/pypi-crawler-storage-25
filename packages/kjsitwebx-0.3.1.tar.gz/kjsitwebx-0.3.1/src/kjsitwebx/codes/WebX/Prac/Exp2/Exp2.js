"use strict";
class user {
    login() {
        console.log("User logged in");
    }
}
class student extends user {
    study() {
        console.log("Student is studying");
    }
}
class teacher extends user {
    teach() {
        console.log("Teacher is teaching");
    }
}
let s = new student();
s.login();
s.study();
