class BankAccount {
    public name: string;
    private balance: number;
    protected bank: string;

    constructor(name: string, balance: number, bank: string) {
        this.name = name;
        this.balance = balance;
        this.bank = bank;
    }

    showBalance() {
        console.log("Balance:", this.balance); // ✅ private used inside class
    }
}

// 🔹 Child class
class SavingsAccount extends BankAccount {
    showDetails() {
        console.log(this.name);   // ✅ public
        console.log(this.bank);   // ✅ protected
        // console.log(this.balance); ❌ private (not allowed)
    }
}

// 🔹 Object
let acc = new SavingsAccount("Ishika", 5000, "SBI");

acc.showBalance();
acc.showDetails();

console.log(acc.name);   // ✅ public
// console.log(acc.balance); ❌ private
// console.log(acc.bank); ❌ protected