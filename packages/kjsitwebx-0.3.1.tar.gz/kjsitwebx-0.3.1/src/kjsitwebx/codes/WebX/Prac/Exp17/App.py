from flask import Flask, render_template
app = Flask(__name__)

posts=[
    {"title": "My First Blog Post",
    "content": "This is the content of my first blog post.",
    "author": "John Doe"},
    { "title": "My Second Blog Post",
    "content": "This is the content of my second blog post.",
    "author": "Jane Doe"},
    {"title": "My Third Blog Post",
    "content": "This is the content of my third blog post.",
    "author": "John Doe"}
]
@app.route('/')
def home():
    return render_template('index.html', posts=posts)
if __name__ == '__main__':
    app.run(debug=True)