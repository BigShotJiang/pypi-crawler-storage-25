interface Student{
    name: string;
    age: number;
    study(): void;
}

class Student1 implements Student {
    name:string;
    age:number;

    constructor(name:string,age:number){
        this.name=name;
        this.age=age;   
    }
    study() {
        console.log(`${this.name} is studying`);
    }
}

let s1=new Student1("Ishika",21);
s1.study();
