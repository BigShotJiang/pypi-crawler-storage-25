"use strict";
class Student1 {
    name;
    age;
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }
    study() {
        console.log(`${this.name} is studying`);
    }
}
let s1 = new Student1("Ishika", 21);
s1.study();
