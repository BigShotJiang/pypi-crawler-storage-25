from pathlib import Path
from arcade.sound import Sound
from arcade.application import Window
from arcade.sprite.colored import SpriteSolidColor
from arcade.texture.texture import Texture
from typing_extensions import override

import pyglet.image

from arcade.types import Color, RGBOrA255
from .abstract import AbstractEngine
from PIL import Image
import arcade
import logging
import re

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

_BUTTON_MAP: dict[int, str] = {
    arcade.MOUSE_BUTTON_LEFT:   "left",
    arcade.MOUSE_BUTTON_RIGHT:  "right",
    arcade.MOUSE_BUTTON_MIDDLE: "middle",
}

_KEY_MAP: dict[int, str] = {
    arcade.key.LEFT:      "left",
    arcade.key.RIGHT:     "right",
    arcade.key.UP:        "up",
    arcade.key.DOWN:      "down",
    arcade.key.ESCAPE:    "escape",
    arcade.key.ENTER:     "enter",
    arcade.key.RETURN:    "enter",
    arcade.key.BACKSPACE: "backspace",
    arcade.key.DELETE:    "delete",
    arcade.key.TAB:       "tab",
    arcade.key.HOME:      "home",
    arcade.key.END:       "end",
    arcade.key.PAGEUP:    "pageup",
    arcade.key.PAGEDOWN:  "pagedown",
    arcade.key.F1:  "f1",  arcade.key.F2:  "f2",  arcade.key.F3:  "f3",
    arcade.key.F4:  "f4",  arcade.key.F5:  "f5",  arcade.key.F6:  "f6",
    arcade.key.F7:  "f7",  arcade.key.F8:  "f8",  arcade.key.F9:  "f9",
    arcade.key.F10: "f10", arcade.key.F11: "f11", arcade.key.F12: "f12",
}


def _hex_to_rgb(hex_color: str) -> RGBOrA255:
    assert bool(re.fullmatch(r"#([0-9a-fA-F]{6}|[0-9a-fA-F]{8})", hex_color)), f"Bad color format for #RRGGBB/#RRGGBBAA: {hex_color}"

    hex_color = hex_color.lstrip("#")
    if len(hex_color) == 6:
        return tuple[int, int, int](int(hex_color[i:i+2], 16) for i in (0, 2, 4)) #type: ignore
    elif len(hex_color) == 8:
        return tuple[int, int, int, int](int(hex_color[i:i+2], 16) for i in (0, 2, 4, 6)) #type: ignore
    else:
        raise ValueError("Invalid hex color format")



class ArcadeEngine(AbstractEngine):
    def __init__(self, nrows: int, ncols: int, cell_size: int, margin: int) -> None:
        super().__init__(nrows, ncols, cell_size, margin)
        WINDOW_WIDTH = (self.cell_size + self.margin) * self.ncols + self.margin
        WINDOW_HEIGHT = (self.cell_size + self.margin) * self.nrows + self.margin
        WINDOW_TITLE = ""

        self.window: Window = arcade.Window(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE)

        self._load_icon()

        # Texture blanche réutilisée par set_cell_color (#11)
        _white = Image.new("RGBA", (self.cell_size, self.cell_size), (255, 255, 255, 255))
        self._white_texture: arcade.Texture = arcade.Texture(name="__white__", image=_white)

        # Cache des sons (#12)
        self._sound_cache: dict[str, Sound] = {}

        self.view: GameView = GameView(self)
    
    def _load_icon(self) -> None:
        """Load window icon from package assets directory."""
        try:
            icon_path = Path(__file__).parent.parent / "assets" / "grille_icon_256.png"
            
            if icon_path.exists():
                # Charger l'image
                icon = pyglet.image.load(str(icon_path))
                # Convertir en ImageData
                self.window.set_icon(icon.get_image_data())
        except Exception:
            pass
        
    @override
    def start(self) -> None:
        super().start()
        self.window.show_view(self.view)
        arcade.run()


    @override
    def exit(self) -> None:
        self.window.close()

    def _check_bounds(self, i: int, j: int) -> None:
        if not (0 <= i < self.nrows and 0 <= j < self.ncols):
            raise IndexError(f"Cell ({i}, {j}) is out of bounds for grid {self.nrows}×{self.ncols}")

    @override
    def set_cell_color(self, i: int, j: int, color: str) -> None:
        self._check_bounds(i, j)
        i = self.nrows - 1 - i
        self.view.grid_sprites[i][j].texture = self._white_texture
        self.view.grid_sprites[i][j].color = _hex_to_rgb(color)

    @override
    def set_cell_image(self, i: int, j: int, image: str) -> None:
        self._check_bounds(i, j)
        if image not in self.view.textures:
            raise KeyError(f"Image '{image}' not loaded. Call load_image('{image}', path) first.")
        i = self.nrows - 1 - i
        self.view.grid_sprites[i][j].color = _hex_to_rgb("#FFFFFFFF")
        self.view.grid_sprites[i][j].texture = self.view.textures[image]

    @override
    def set_cell_char(self, i: int, j: int, char: str, color: str) -> None:
        super().set_cell_char(i, j, char, color)
        if 0 <= i < self.nrows and 0 <= j < self.ncols:
            i_flipped = self.nrows - 1 - i
            sprite = self.view.grid_sprites[i_flipped][j]

            if char:
                existing = self.view.grid_chars[i][j]
                if existing is None:
                    self.view.grid_chars[i][j] = arcade.Text(
                        text=char,
                        x=sprite.center_x,
                        y=sprite.center_y,
                        color=_hex_to_rgb(color),
                        font_size=self.cell_size*0.75,  # Rough approximation for now
                        anchor_x="center",
                        anchor_y="center"
                    )
                else:
                    existing.text = char
                    existing.color = _hex_to_rgb(color)
            else:
                # Clear the character
                self.view.grid_chars[i][j] = None

    @override
    def load_image(self, name: str, path: str) -> None:
        img = Image.open(path).convert("RGBA").resize((self.cell_size, self.cell_size), Image.Resampling.LANCZOS)  # type: ignore[arg-type]
        self.view.textures[name] = arcade.Texture(name=name, image=img)

    @override
    def play_sound(self, path: str) -> None:
        if path not in self._sound_cache:
            self._sound_cache[path] = arcade.load_sound(path)
        _ = self._sound_cache[path].play()



class GameView(arcade.View):
    """
    Main application class.
    """

    def __init__(self, crafter: ArcadeEngine) -> None:
        """
        Set up the application.
        """
        super().__init__()
        self.crafter: ArcadeEngine = crafter
        # Set the background color of the window
        self.background_color: Color = arcade.color.BLACK

        self.textures: dict[str, arcade.Texture] = dict[str, Texture]()
        # 1d list of all sprites in the two-dimensional sprite list
        self.grid_sprite_list: arcade.SpriteList[arcade.Sprite] = arcade.SpriteList()

        # 2d grid hat holds references to the spritelist
        self.grid_sprites: list[list[arcade.Sprite]] = []

        # 2d grid that holds Texts to be drawn on top of sprites
        self.grid_chars: list[list[arcade.Text|None]] = [[None for _ in range(crafter.ncols)] for _ in range(crafter.nrows)]

        # Create a list of solidcolor sprites to represent each cell
        for row in range(self.crafter.nrows):
            self.grid_sprites.append([])
            for column in range(self.crafter.ncols):
                x = column * (self.crafter.cell_size + self.crafter.margin) + (self.crafter.cell_size / 2 + self.crafter.margin)
                y = row * (self.crafter.cell_size + self.crafter.margin) + (self.crafter.cell_size / 2 + self.crafter.margin)
                sprite: SpriteSolidColor = arcade.SpriteSolidColor(self.crafter.cell_size, self.crafter.cell_size, color=arcade.color.WHITE)
                sprite.center_x = x
                sprite.center_y = y
                self.grid_sprite_list.append(sprite)
                self.grid_sprites[row].append(sprite)

    @override
    def on_update(self, delta_time: float) -> bool | None:
        logger.debug(f"on_update({delta_time})")
        self.crafter.frame_no += 1 #! Incrémentation du frame_no
        #print("test")
        _ = super().on_update(delta_time)
        if self.crafter.on_update_fn:
            self.crafter.on_update_fn()

    @override
    def on_key_press(self, symbol: int, modifiers: int) -> bool | None:
        logger.debug(f"on_key_press({symbol}, {modifiers})")
        _ = super().on_key_press(symbol, modifiers)
        #print(symbol, chr(symbol), modifiers)
        if self.crafter.on_key_fn:
            key_name = _KEY_MAP.get(symbol, chr(symbol) if symbol < 128 else f"key_{symbol}")
            self.crafter.on_key_fn(key_name)
#            self.immediate_update()

    @override
    def on_draw(self) -> None:
        """
        Render the screen.
        """
        if self.crafter.on_draw_fn:
            self.crafter.on_draw_fn()
        self.clear()
        self.grid_sprite_list.draw()
        #print(self.grid_chars)
        for i in range(self.crafter.nrows):
            for j in range(self.crafter.ncols):
                text_obj = self.grid_chars[i][j]
                if text_obj:
                    text_obj.draw()

    @override
    def on_mouse_press(self, x: int, y: int, button: int, modifiers: int) -> None:
        """
        Called when the user presses a mouse button.
        """
        logger.debug(f"on_mouse_press({x},{y},{button},{modifiers})")
        column = int(x // (self.crafter.cell_size + self.crafter.margin))
        row = self.crafter.nrows - 1 - int(y // (self.crafter.cell_size + self.crafter.margin))
        logger.debug(f"Grid coordinates: ({row}, {column})")
        if self.crafter.on_click_fn and 0 <= row < self.crafter.nrows and 0 <= column < self.crafter.ncols:
            button_name = _BUTTON_MAP.get(button, "left")
            self.crafter.on_click_fn(row, column, button_name)
            #self.immediate_update()

