from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Any, TextIO

from mycel_cli.daemon import paths as daemon_paths

_ERROR_CONTEXT_SUPPRESSION_SECONDS = 300.0
_BOOTSTRAP_CONTEXT_SUPPRESSION_SECONDS = 3600.0


def read_hook_payload(
    stdin: TextIO, *, default_event: str = "Notification"
) -> dict[str, Any]:
    text = stdin.read().strip()
    if not text:
        return {"hook_event_name": default_event}
    payload = json.loads(text)
    if not isinstance(payload, dict):
        raise RuntimeError("hook input must be a JSON object")
    return payload


def hook_event_name(
    payload: dict[str, Any], *, default_event: str = "Notification"
) -> str:
    return str(payload.get("hook_event_name") or default_event)


def format_agent_context(
    payload: Any, *, local_id: str, cli_command: str | None = None
) -> str:
    notifications = (
        payload.get("notifications", []) if isinstance(payload, dict) else []
    )
    if not notifications:
        return ""
    command = cli_command or os.getenv("MYCEL_CLI_COMMAND") or "cel"
    lines = [
        "<mycel-notifications>",
        f"You are using Mycel identity {local_id}.",
        f"You have {len(notifications)} pending Mycel notification(s).",
    ]
    for item in notifications:
        if not isinstance(item, dict):
            continue
        chat_id = str(item.get("chat_id") or "").strip()
        event_type = str(
            item.get("event_type") or item.get("notification_type") or "notification"
        )
        notification_type = str(item.get("notification_type") or "").strip()
        sender_name = str(item.get("sender_name") or "someone")
        if chat_id and notification_type == "chat":
            unread_count = item.get("unread_count")
            unread_text = (
                f" ({unread_count} unread)"
                if isinstance(unread_count, int) and unread_count >= 0
                else ""
            )
            lines.append(
                f"- {sender_name} sent a new {event_text(event_type)} in chat {chat_id}{unread_text}."
            )
            lines.append("  Read this chat before deciding whether to reply:")
            lines.append(f"  {command} read-message {chat_id}")
            lines.append("  Reply if useful:")
            lines.append(f'  {command} send-message {chat_id} "..."')
        else:
            summary = str(item.get("summary") or "").strip()
            lines.append(
                f"- {summary}"
                if summary
                else f"- {sender_name} sent a new {event_text(event_type)}."
            )
    lines.append("Use cel for the real chat content; this hook only carries metadata.")
    lines.append("</mycel-notifications>")
    return "\n".join(lines) + "\n"


def format_hook_error_context(error: BaseException, *, local_id: str) -> str:
    return (
        "<mycel-notifications>\n"
        f"You are using Mycel identity {local_id}.\n"
        f"Mycel notification check failed: {error}\n"
        "The provider hook delivered this diagnostic instead of failing the host event.\n"
        "You can retry with `cel self inbox read` after the Mycel backend is available.\n"
        "</mycel-notifications>\n"
    )


def format_hook_diagnostic_context(message: str, *, local_id: str) -> str:
    return (
        "<mycel-notifications>\n"
        f"You are using Mycel identity {local_id}.\n"
        f"{message}\n"
        "The provider hook delivered this diagnostic instead of failing the host event.\n"
        "</mycel-notifications>\n"
    )


def format_bootstrap_context(
    provider: str,
    *,
    cli_command: str | None = None,
    owner_user_id: str | None = None,
    resolved_local_id: str | None = None,
    multiple_local_ids: list[str] | None = None,
) -> str:
    return _wrap_mycel_context(
        format_agent_guide(
            provider=provider,
            cli_command=cli_command,
            owner_user_id=owner_user_id,
            resolved_local_id=resolved_local_id,
            multiple_local_ids=multiple_local_ids,
        )
    )


def format_agent_guide(
    provider: str,
    *,
    cli_command: str | None = None,
    owner_user_id: str | None = None,
    resolved_local_id: str | None = None,
    multiple_local_ids: list[str] | None = None,
) -> str:
    command = cli_command or os.getenv("MYCEL_CLI_COMMAND") or "cel"
    token = str(os.getenv("MYCEL_SESSION_ID") or "")[:8]
    local_id = f"{provider}-{token}" if token else f"{provider}-<short-name>"
    display_name = (
        f"{provider.title()} {token}" if token else f"{provider.title()} <short name>"
    )
    lines = ["Mycel agent guide", ""]
    if resolved_local_id:
        lines.extend(
            [
                "What is happening:",
                "  You were launched through cel, the Mycel wrapper for local code agents.",
                "  Mycel gives this local session a durable user identity and a real chat inbox.",
                "  That identity is how other agents can reach you after this terminal moment.",
                "",
                f"This session resolves to Mycel identity: {resolved_local_id}",
                "Use this identity; do not create another identity.",
                f"Refresh this guide any time:\n  {command} agent guide",
                "",
                "Next action:",
                f"  Run {command} self start if local delivery is not running.",
                "  Then use read-message and send-message for real communication.",
                "",
                "Communicate with durable Mycel messages:",
                f"  {command} read-message <target>",
                f'  {command} send-message <target> "..."',
            ]
        )
        return "\n".join(lines) + "\n"
    if multiple_local_ids:
        lines.extend(
            [
                "What is happening:",
                "  This folder is already linked to more than one Mycel identity.",
                "  Choosing the wrong one would make messages come from the wrong agent.",
                "",
                f"Multiple {provider} identities are available here:",
                *(f"  - {item}" for item in multiple_local_ids),
                "",
                "Next action:",
                "  Ask the user which identity this session should be.",
                f"  Then restart with: {command} {provider} --identity <local-id>",
                f"  If the user wants a fresh setup here, restart plain: {command} {provider}",
            ]
        )
        return "\n".join(lines) + "\n"
    lines.extend(
        [
            "What is happening:",
            f"  You are a {provider} session launched through cel.",
            "  cel is here so local code agents can become durable Mycel users.",
            "  A durable identity means you can send and receive Mycel messages,",
            "  join group workflows, and be reached again through local delivery.",
            "",
            "Current state:",
            "  This session is in bootstrap mode.",
            f"  The {provider} process is already running in this terminal.",
            "  No Mycel identity is bound yet.",
            "  The local Mycel delivery daemon may still be stopped; setup starts it later.",
            "  This is expected for a fresh folder. Stay in this session.",
            "",
            "Your job:",
            "  Do not merely summarize this guide back to the user.",
            "  Drive setup like a careful assistant.",
            "  If there is a real choice, ask the user.",
            "  If there is no choice, run the next command yourself.",
            "",
            f"Refresh this guide any time:\n  {command} agent guide",
            "",
            f"Check local state:\n  {command} self status",
            "",
        ]
    )
    if owner_user_id:
        lines.extend(
            [
                f"Owner login is already present: {owner_user_id}",
                "Use it; do not run login again.",
                "",
                "Next action:",
                "  Create this session's Mycel identity now with the command below.",
                "  This identity is you in Mycel, not just a config entry.",
                "  Then start local delivery and refresh this guide.",
                "",
            ]
        )
    else:
        lines.extend(
            [
                "If no owner is logged in:",
                "  Ask: hosted guest trial, or normal account?",
                f"  Hosted guest trial, new guest: run {command} login --guest",
                f"  Hosted guest trial, existing guest token: run {command} login --guest --token <token>",
                f"  To get a token from an existing guest machine: run {command} self token --guest there.",
                f"  Normal account: ask the user to run {command} login <email-or-username>",
                f"  After login: run {command} agent guide again.",
                "",
            ]
        )
    lines.extend(
        [
            "Identity creation command:",
            f"Create your agent identity: {command} agent external create {local_id} "
            f'--name "{display_name}" --provider {provider}',
            "",
            "Local delivery command:",
            f"  {command} self start",
            "",
            "Communicate with durable Mycel messages:",
            f"  {command} read-message <target>",
            f'  {command} send-message <target> "..."',
            "",
            "Expectation:",
            "  After setup, other agents can message this identity.",
            "  Hook notifications are only nudges; real content lives in Mycel messages.",
        ]
    )
    return "\n".join(lines) + "\n"


def _wrap_mycel_context(body: str) -> str:
    return f"<mycel-notifications>\n{body}</mycel-notifications>\n"


def should_emit_bootstrap_context(
    *, provider: str, event_name: str, token: str | None = None
) -> bool:
    token = token or str(os.getenv("MYCEL_SESSION_ID") or "")
    if not token:
        return event_name == "SessionStart"
    cache_path = _bootstrap_context_cache_path()
    now = time.time()
    key = f"{provider}:{token}"
    try:
        payload = json.loads(cache_path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        payload = {}
    except json.JSONDecodeError:
        payload = {}
    seen_at = float(payload.get(key) or 0)
    if now - seen_at < _BOOTSTRAP_CONTEXT_SUPPRESSION_SECONDS:
        return False
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    payload[key] = now
    cache_path.write_text(
        json.dumps(payload, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    cache_path.chmod(0o600)
    return True


def should_emit_hook_error_context(error: BaseException, *, local_id: str) -> bool:
    cache_path = _hook_error_cache_path()
    key = f"{local_id}:{type(error).__name__}:{error}"
    now = time.time()
    if cache_path.exists():
        payload = json.loads(cache_path.read_text(encoding="utf-8") or "{}")
        if (
            payload.get("key") == key
            and now - float(payload.get("reported_at") or 0)
            < _ERROR_CONTEXT_SUPPRESSION_SECONDS
        ):
            return False
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    cache_path.write_text(
        json.dumps({"key": key, "reported_at": now}, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    cache_path.chmod(0o600)
    return True


def clear_hook_error_context() -> None:
    cache_path = _hook_error_cache_path()
    if cache_path.exists():
        cache_path.unlink()


def _hook_error_cache_path() -> Path:
    return daemon_paths.mycel_home() / "hook-error-cache.json"


def _bootstrap_context_cache_path() -> Path:
    return daemon_paths.mycel_home() / "bootstrap-guide-cache.json"


def event_text(event_type: str) -> str:
    return event_type.replace(".", " ")


def hook_output(event_name: str, context: str, *, include_continue: bool) -> str:
    if not context:
        return ""
    payload: dict[str, Any] = {
        "hookSpecificOutput": {
            "hookEventName": event_name,
            "additionalContext": context,
        }
    }
    if include_continue:
        payload["continue"] = True
    return json.dumps(payload, ensure_ascii=False) + "\n"


def stop_block_output(context: str) -> str:
    if not context:
        return ""
    return (
        json.dumps({"decision": "block", "reason": context}, ensure_ascii=False) + "\n"
    )
