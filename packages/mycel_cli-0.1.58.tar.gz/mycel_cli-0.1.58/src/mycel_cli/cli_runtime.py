from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path


def current_cli_command() -> str:
    env_command = os.environ.get("MYCEL_CLI_COMMAND")
    if env_command:
        env_path = Path(env_command).expanduser()
        if env_path.is_absolute() or len(env_path.parts) > 1:
            return str(env_path.resolve())
        return env_command

    current = _current_argv_cel()
    if current is not None:
        return str(current)

    command = shutil.which("cel")
    if command:
        return str(Path(command).resolve())
    return "cel"


def current_cli_bin() -> Path | None:
    command = current_cli_command()
    if command == "cel":
        return None
    return Path(command).parent


def _current_argv_cel() -> Path | None:
    if not sys.argv:
        return None
    first = Path(sys.argv[0]).expanduser()
    if first.name not in {"cel", "cel.exe"}:
        return None
    if not first.is_absolute():
        return None
    if not first.exists():
        return None
    return first.resolve()
