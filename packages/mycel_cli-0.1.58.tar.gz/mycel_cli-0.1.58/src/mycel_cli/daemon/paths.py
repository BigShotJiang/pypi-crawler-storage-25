from __future__ import annotations

import os
import re
from pathlib import Path

_SAFE_ID_RE = re.compile(r"[^A-Za-z0-9_.-]+")


def mycel_home() -> Path:
    return Path(os.getenv("MYCEL_HOME") or Path.home() / ".mycel").expanduser()


def safe_local_id(local_id: str) -> str:
    safe = _SAFE_ID_RE.sub("_", local_id).strip("._")
    if not safe:
        raise RuntimeError("local id cannot be empty")
    return safe


def run_dir() -> Path:
    return mycel_home() / "run"


def inbox_path(local_id: str) -> Path:
    return mycel_home() / "inbox" / f"{safe_local_id(local_id)}.jsonl"


def cursor_path(local_id: str) -> Path:
    return mycel_home() / "inbox" / f"{safe_local_id(local_id)}.cursor"


def subscriber_status_path(local_id: str) -> Path:
    return run_dir() / f"subscriber-{safe_local_id(local_id)}.json"


def subscriber_watermark_path(local_id: str) -> Path:
    return run_dir() / f"subscriber-{safe_local_id(local_id)}.watermark.json"


def surface_path(local_id: str) -> Path:
    return run_dir() / "surfaces" / f"{safe_local_id(local_id)}.json"


def pending_surface_path(token: str) -> Path:
    return run_dir() / "pending-surfaces" / f"{safe_local_id(token)}.json"


def session_path(session_id: str) -> Path:
    return run_dir() / "sessions" / f"{safe_local_id(session_id)}.json"


def wake_path(local_id: str) -> Path:
    return run_dir() / f"wake-{safe_local_id(local_id)}.json"


def rewake_path(local_id: str) -> Path:
    return run_dir() / f"rewake-{safe_local_id(local_id)}.json"


def debug_config_path() -> Path:
    return mycel_home() / "debug.json"


def debug_log_path() -> Path:
    return mycel_home() / "debug.jsonl"


def task_status_path(task_name: str) -> Path:
    return run_dir() / f"{task_name}.json"
