from __future__ import annotations

from mycel_cli.daemon.ipc import DaemonIpcUnavailable, request as daemon_request
from mycel_cli.internal_hooks import (
    format_agent_context,
    format_hook_diagnostic_context,
)


def read_inbox_context(
    local_id: str, *, daemon_unavailable_context: str | None = None
) -> str:
    try:
        payload = daemon_request("drain_for_hook", local_id=local_id)
    except DaemonIpcUnavailable:
        if daemon_unavailable_context is not None:
            return daemon_unavailable_context
        return format_hook_diagnostic_context(
            f"local Mycel daemon is not running for {local_id}",
            local_id=local_id,
        )
    if payload.get("status") == "stale":
        return format_hook_diagnostic_context(
            str(payload["message"]), local_id=local_id
        )
    return format_agent_context(payload, local_id=local_id)
