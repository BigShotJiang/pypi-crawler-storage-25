from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, dataclass

from mycel_cli.daemon.paths import session_path
from mycel_cli.debug_log import log_debug_event


@dataclass(frozen=True)
class SessionBinding:
    session_id: str
    local_id: str
    bound_at: float


def bind_session(session_id: str, local_id: str) -> SessionBinding:
    session_id = session_id.strip()
    local_id = local_id.strip()
    if not session_id:
        raise RuntimeError("MYCEL_SESSION_ID is required")
    if not local_id:
        raise RuntimeError("local_id is required")
    binding = SessionBinding(
        session_id=session_id,
        local_id=local_id,
        bound_at=time.time(),
    )
    path = session_path(session_id)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(asdict(binding), ensure_ascii=False) + "\n", encoding="utf-8")
    os.replace(tmp, path)
    path.chmod(0o600)
    log_debug_event(
        "session",
        "session.bound",
        local_id=local_id,
        details={"session_id": session_id},
    )
    return binding


def lookup_session(session_id: str) -> str | None:
    session_id = session_id.strip()
    if not session_id:
        return None
    path = session_path(session_id)
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        local_id = str(payload.get("local_id") or "").strip()
    except Exception as exc:
        path.unlink(missing_ok=True)
        log_debug_event(
            "session",
            "session.lookup.dropped",
            reason=str(exc) or exc.__class__.__name__,
            details={"session_id": session_id},
        )
        return None
    if not local_id:
        path.unlink(missing_ok=True)
        log_debug_event(
            "session",
            "session.lookup.dropped",
            reason="missing-local-id",
            details={"session_id": session_id},
        )
        return None
    return local_id
