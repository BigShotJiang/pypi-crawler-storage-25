from __future__ import annotations

import hashlib
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any


def runtime_identity() -> dict[str, str]:
    return {
        "daemon_version": _package_version(),
        "daemon_fingerprint": runtime_fingerprint(),
    }


def daemon_runtime_restart_needed(state: dict[str, Any]) -> bool:
    stored = str(state.get("daemon_fingerprint") or "")
    return bool(stored and stored != runtime_fingerprint())


def runtime_fingerprint() -> str:
    root = Path(__file__).resolve().parents[1]
    digest = hashlib.sha256()
    for path in sorted(root.rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        digest.update(path.relative_to(root).as_posix().encode())
        try:
            digest.update(path.read_bytes())
        except OSError:
            continue
    return digest.hexdigest()[:16]


def _package_version() -> str:
    try:
        return version("mycel-cli")
    except PackageNotFoundError:
        return "unknown"
