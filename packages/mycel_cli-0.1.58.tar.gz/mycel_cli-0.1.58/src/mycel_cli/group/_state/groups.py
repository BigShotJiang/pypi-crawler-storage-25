"""Group CRUD and per-group locking."""

from __future__ import annotations

import json
import shutil
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

from filelock import FileLock

from mycel_cli.group._state import paths as _paths
from mycel_cli.group._state.paths import (
    atomic_write_text,
    _ensure_dirs,
    _validate_group_name,
)
from mycel_cli.group.terminal import DEFAULT_TERMINAL, VALID_TERMINALS

# Current persisted shape. Old shapes are not rewritten in-place; this package
# owns the clean `cel` contract only.
SCHEMA_VERSION = 8

VALID_GROUP_STATUSES = frozenset({"active", "stopped"})


def group_terminal_type(group: dict[str, Any]) -> str:
    """Group's terminal_type. Falls back to DEFAULT_TERMINAL only for pre-feature groups."""
    return group.get("terminal_type") or DEFAULT_TERMINAL


def validate_group(group: dict[str, Any]) -> None:
    """Raise ValueError if group violates schema invariants.

    Required fields enforced here let display/logic paths use direct dict
    access (group["status"], group["name"]) instead of .get with masking
    defaults. Bugs in serializers surface here, not at use sites.
    """
    name = group.get("name")
    if not name:
        raise ValueError(f"Group missing required field 'name': {group!r}")

    status = group.get("status")
    if status not in VALID_GROUP_STATUSES:
        raise ValueError(
            f"Group {name!r}: invalid status {status!r}; "
            f"valid: {sorted(VALID_GROUP_STATUSES)}"
        )

    tt = group.get("terminal_type")
    if tt is not None and tt not in VALID_TERMINALS:
        raise ValueError(
            f"Group {name!r}: invalid terminal_type {tt!r}; "
            f"valid: {sorted(VALID_TERMINALS)}"
        )

    tc = group.get("terminal_container")
    if tc is not None and not isinstance(tc, str):
        raise ValueError(
            f"Group {name!r}: terminal_container must be str or None, got {type(tc).__name__}"
        )

    if "users" in group:
        raise ValueError(
            f"Group {name!r}: old role key 'users' is not supported; use 'roles'"
        )
    roles = group.get("roles")
    if not isinstance(roles, list):
        raise ValueError(f"Group {name!r}: roles must be a list")

    for u in roles:
        role = u.get("role")
        if not isinstance(role, str) or not role.strip():
            raise ValueError(f"Group {name!r}: role record has invalid role {role!r}")
        if not u.get("session"):
            raise ValueError(f"Group {name!r}: role record missing 'session' field")


def _group_file(name: str) -> Path:
    return _paths.GROUPS_DIR / f"{name}.json"


def _group_lock_file(name: str) -> Path:
    return _paths.GROUPS_DIR / f"{name}.json.lock"


def _group_lock(name: str) -> FileLock:
    return FileLock(str(_group_lock_file(name)))


def _group_resource_dir(group_name: str) -> Path:
    return _paths.GROUPS_DIR / group_name


def _ensure_group_resource_dirs(group_name: str) -> None:
    (_group_resource_dir(group_name) / "messages").mkdir(parents=True, exist_ok=True)


def new_group(
    name: str,
    terminal_type: str = DEFAULT_TERMINAL,
    *,
    workers_enabled: bool | None = None,
) -> dict[str, Any]:
    group: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "name": name,
        "status": "stopped",
        "roles": [],
        "group_prompt": None,
        "created_at": time.time(),
        "terminal_type": terminal_type,
        "terminal_container": None,
    }
    if workers_enabled is not None:
        group["workers_enabled"] = workers_enabled
    return group


def load_group(name: str) -> dict[str, Any] | None:
    _ensure_dirs()
    with _group_lock(name):
        return _load_group_unlocked(name)


def _load_group_unlocked(name: str) -> dict[str, Any] | None:
    f = _group_file(name)
    if not f.exists():
        return None
    group = json.loads(f.read_text(encoding="utf-8"))
    validate_group(group)
    return group


def save_group(name: str, group: dict[str, Any]) -> None:
    _ensure_dirs()
    with _group_lock(name):
        _save_group_unlocked(name, group)


def _save_group_unlocked(name: str, group: dict[str, Any]) -> None:
    atomic_write_text(
        _group_file(name), json.dumps(group, ensure_ascii=False, indent=2)
    )


def delete_group(name: str) -> bool:
    f = _group_file(name)
    if not f.exists():
        return False
    f.unlink()
    # 清理 per-group 资源目录，但保留 messages/ 以便事后分析。
    # 若清理后外层目录为空（没有 messages/ 需要保留），一并 rmdir 掉，
    # 避免留下空壳目录。
    resource_dir = _group_resource_dir(name)
    if resource_dir.exists():
        for child in resource_dir.iterdir():
            if child.name == "messages":
                continue
            if child.is_dir():
                shutil.rmtree(child, ignore_errors=True)
            else:
                child.unlink(missing_ok=True)
        # next() 拿第一项；空迭代器说明目录已清空，可安全 rmdir
        if next(resource_dir.iterdir(), None) is None:
            resource_dir.rmdir()
    return True


def list_groups() -> list[str]:
    """返回所有 group 名（按文件名排序）。"""
    if not _paths.GROUPS_DIR.exists():
        return []
    return sorted(f.stem for f in _paths.GROUPS_DIR.glob("*.json"))


def create_group(
    name: str,
    terminal_type: str = DEFAULT_TERMINAL,
    *,
    workers_enabled: bool | None = None,
) -> dict[str, Any]:
    """创建新 group，如已存在则报错。"""
    _validate_group_name(name)
    if _group_file(name).exists():
        raise ValueError(f"Group '{name}' 已存在")
    group = new_group(
        name,
        terminal_type=terminal_type,
        workers_enabled=workers_enabled,
    )
    validate_group(group)
    save_group(name, group)
    _ensure_group_resource_dirs(name)
    return group


def delete_all() -> None:
    """清除所有状态（global + groups + signal files）。"""
    from mycel_cli.group._state.globals_ import delete_global

    delete_global()
    if _paths.GROUPS_DIR.exists():
        for child in _paths.GROUPS_DIR.iterdir():
            if child.is_dir():
                shutil.rmtree(child)
            else:
                child.unlink()
    for f in _paths.STATE_DIR.glob("stop-*"):
        f.unlink()


@contextmanager
def mutate_group(name: str) -> Iterator[dict[str, Any]]:
    """Acquire per-group lock, load, yield group for mutation, save on exit.

    Use this for any read-modify-write on group state to prevent
    daemon and CLI from clobbering each other's writes.
    """
    _ensure_dirs()
    with _group_lock(name):
        group = _load_group_unlocked(name)
        if group is None:
            raise ValueError(f"Group {name!r} 不存在")
        yield group
        _save_group_unlocked(name, group)


def set_group_container(name: str, ref: str) -> None:
    with mutate_group(name) as group:
        group["terminal_container"] = ref
