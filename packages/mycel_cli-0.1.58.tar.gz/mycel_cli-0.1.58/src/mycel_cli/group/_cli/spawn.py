"""Agent-session spawn, readiness wait, terminal teardown, daemon launch.

All I/O that touches real terminals / subprocesses / signals lives here so the
rest of `_cli/` remains pure orchestration. Tests stub these symbols via
`monkeypatch.setattr("mycel_cli.group._cli.spawn.<name>", ...)`.
"""

from __future__ import annotations

import json
import os
import re
import shlex
import signal
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

import typer

from mycel_cli.group.agent_types import normalize_agent_type
from mycel_cli.group._cli.identity_env import shell_env_prefix
from mycel_cli.providers.stop_hooks import check_stop_hook_or_fail
from mycel_cli.group._state import paths as _paths
from mycel_cli.group._state.globals_ import save_global
from mycel_cli.group._state.groups import (
    group_terminal_type,
    load_group,
    set_group_container,
)
from mycel_cli.group._state.roles import (
    iter_workers,
    role_agent_type,
)
from mycel_cli.group._state.transcript import read_transcript
from mycel_cli.group.terminal import TerminalPlacement, get_terminal
from mycel_cli.group.worker import WorkerInfo, resolve_worker, worker_cache_from_info
from mycel_cli.providers.contract_delivery import codex_initial_prompt_bundle
from mycel_cli.providers.hook_settings import provider_config_home


def spawn_claude_session(
    session: str,
    path: str | None,
    *,
    local_id: str,
    bootstrap_prompt: str,
    append_system_prompt: str,
    terminal_type: str,
    role: str,
    group_id: str,
    env: dict[str, str] | None = None,
) -> str:
    """Spawn a Claude session inside the group's shared terminal container.

    Ensures the container exists (creating it on first call for the group),
    persists the ref onto ``group["terminal_container"]``, and spawns the
    user at the role-appropriate location. Returns the target_id of
    the newly spawned surface.
    """
    check_stop_hook_or_fail({"claude-code"})
    target_path = path or os.getcwd()
    _ensure_claude_project_trusted(target_path)

    prompt_fd, prompt_path = tempfile.mkstemp(prefix="cel-sysprompt-", suffix=".txt")
    try:
        os.write(prompt_fd, append_system_prompt.encode())
    finally:
        os.close(prompt_fd)

    claude_cmd = shell_env_prefix(env) + _provider_shell_command(
        provider="claude",
        local_id=local_id,
        native_args=[
            "--dangerously-skip-permissions",
            bootstrap_prompt,
            "--append-system-prompt-file",
            prompt_path,
        ],
    )

    group = load_group(group_id)
    if group is None:
        raise RuntimeError(f"Group {group_id!r} not found")

    terminal = get_terminal(terminal_type)
    ref = group.get("terminal_container")
    if ref is None:
        ref = terminal.ensure_group_container(group_id)
        set_group_container(group_id, ref)

    placement = _keep_terminal_placement(role, group_id=group_id, group=group)
    target_id = terminal.spawn_in_container(ref, placement, target_path, claude_cmd)
    return target_id


def spawn_codex_session(
    session: str,
    path: str | None,
    *,
    local_id: str,
    bootstrap_prompt: str,
    append_system_prompt: str,
    terminal_type: str,
    role: str,
    group_id: str,
    env: dict[str, str] | None = None,
) -> str:
    """Spawn a Codex interactive session inside the group terminal container."""
    check_stop_hook_or_fail({"codex"})
    _ = session
    target_path = path or os.getcwd()
    _ensure_codex_project_trusted(target_path)

    initial_prompt = codex_initial_prompt_bundle(
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
    )
    prompt_path = _write_codex_prompt_file(
        group_id=group_id, session=session, prompt=initial_prompt
    )
    codex_cmd = shell_env_prefix(env) + _provider_shell_command(
        provider="codex",
        local_id=local_id,
        native_args=[
            "--dangerously-bypass-approvals-and-sandbox",
            "--no-alt-screen",
        ],
        native_shell_args=[f'"$(cat {shlex.quote(str(prompt_path))})"'],
    )

    group = load_group(group_id)
    if group is None:
        raise RuntimeError(f"Group {group_id!r} not found")

    terminal = get_terminal(terminal_type)
    ref = group.get("terminal_container")
    if ref is None:
        ref = terminal.ensure_group_container(group_id)
        set_group_container(group_id, ref)

    placement = _keep_terminal_placement(role, group_id=group_id, group=group)
    return terminal.spawn_in_container(ref, placement, target_path, codex_cmd)


def _keep_terminal_placement(
    role: str, *, group_id: str, group: dict
) -> TerminalPlacement:
    if role == "supervisor":
        return TerminalPlacement(slot="primary", title="supervisor")
    if role == "reviewer":
        return TerminalPlacement(
            slot="right",
            title="reviewer",
            anchor_title="supervisor",
        )
    if role == "worker":
        fresh = load_group(group_id) or group
        worker_index = sum(1 for _ in iter_workers(fresh))
        if worker_index == 0:
            return TerminalPlacement(
                slot="down",
                title="worker-1",
                anchor_title="supervisor",
            )
        return TerminalPlacement(
            slot="next",
            title=f"worker-{worker_index + 1}",
            anchor_title="worker-1",
        )
    raise ValueError(f"unknown keep role: {role!r}")


def spawn_agent_session(
    session: str,
    path: str | None,
    *,
    agent_type: str,
    local_id: str,
    bootstrap_prompt: str,
    append_system_prompt: str,
    terminal_type: str,
    role: str,
    group_id: str,
    env: dict[str, str] | None = None,
) -> str:
    if normalize_agent_type(agent_type) == "codex":
        return spawn_codex_session(
            session,
            path,
            local_id=local_id,
            bootstrap_prompt=bootstrap_prompt,
            append_system_prompt=append_system_prompt,
            terminal_type=terminal_type,
            role=role,
            group_id=group_id,
            env=env,
        )
    return spawn_claude_session(
        session,
        path,
        local_id=local_id,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
        terminal_type=terminal_type,
        role=role,
        group_id=group_id,
        env=env,
    )


def _find_stop_payload_after(
    started_at: float,
    *,
    user_session: str | None = None,
    group_id: str | None = None,
) -> tuple[str, dict] | None:
    candidates: list[tuple[float, str, dict]] = []
    for stop_path in _paths.STATE_DIR.glob("stop-*"):
        try:
            stat = stop_path.stat()
            payload = json.loads(stop_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if (
            user_session is not None
            and payload.get("mycel_user_session") != user_session
        ):
            continue
        if group_id is not None and payload.get("mycel_group_id") != group_id:
            continue
        payload_time = payload.get("mycel_written_at")
        try:
            event_time = (
                float(payload_time)
                if payload_time is not None
                else float(stat.st_mtime)
            )
        except (TypeError, ValueError):
            event_time = float(stat.st_mtime)
        if event_time < started_at:
            continue
        session_id = payload.get("session_id") or stop_path.name.removeprefix("stop-")
        candidates.append((event_time, str(session_id), payload))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    _, session_id, payload = candidates[0]
    return session_id, payload


def _has_session_identity(info: WorkerInfo) -> bool:
    return any(
        getattr(info, field, None) is not None
        for field in ("jsonl_path", "target_id", "thread_id")
    )


def _iso_utc(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp, timezone.utc).isoformat()


def wait_for_worker_ready(
    session: str,
    *,
    agent_type: str = "claude-code",
    terminal_type: str,
    cache_hint: dict | None = None,
    started_at: float | None = None,
    user_session: str | None = None,
    group_id: str | None = None,
    attempts: int = 10,
    interval: float = 0.2,
) -> WorkerInfo:
    resolved_agent_type = normalize_agent_type(agent_type)
    info = resolve_worker(
        session,
        terminal_type,
        agent_type=resolved_agent_type,
        cache_hint=cache_hint,
        group_id=group_id,
    )
    wait_started_at = started_at if started_at is not None else time.time()
    ready_attempts = max(attempts, 300)
    for _ in range(ready_attempts):
        stop_payload = _find_stop_payload_after(
            wait_started_at, user_session=user_session, group_id=group_id
        )
        if stop_payload is not None:
            provider_session_id, payload = stop_payload
            transcript_path = payload.get("transcript_path")
            if resolved_agent_type == "codex":
                info.thread_id = provider_session_id
            if transcript_path:
                info.jsonl_path = Path(transcript_path)
            if info.target_id is None and cache_hint:
                info.target_id = cache_hint.get("target_id")
            if payload.get("last_assistant_message"):
                return info
        if group_id is not None and user_session is not None:
            replies = read_transcript(
                group_id,
                worker=user_session,
                since=_iso_utc(wait_started_at),
            )
            if any(entry.kind == "stop_reply" for entry in replies):
                if info.target_id is None and cache_hint:
                    info.target_id = cache_hint.get("target_id")
                return info
        time.sleep(interval)
        info = resolve_worker(
            session,
            terminal_type,
            agent_type=resolved_agent_type,
            cache_hint=cache_hint,
            group_id=group_id,
        )
    raise TimeoutError(f"Session '{session}' did not reach ready state")


def spawn_and_wait_for_ready(
    session: str,
    path: str | None,
    *,
    agent_type: str = "claude-code",
    local_id: str,
    terminal_type: str,
    bootstrap_prompt: str,
    append_system_prompt: str,
    role: str,
    group_id: str,
    user_env: dict[str, str] | None = None,
    on_spawned: Callable[[str | None], None] | None = None,
    on_failure: Callable[[], None] | None = None,
) -> tuple[dict, WorkerInfo]:
    """Spawn an agent session and block until transcript/hook signals readiness.

    Returns (cache, info). On timeout or missing jsonl, invokes `on_failure`
    (for rollback cleanup) then raises `typer.Exit(1)` after printing the error.
    """
    started_at = time.time()
    target_id = spawn_agent_session(
        session,
        path,
        agent_type=agent_type,
        local_id=local_id,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
        terminal_type=terminal_type,
        role=role,
        group_id=group_id,
        env=user_env,
    )
    if on_spawned is not None:
        on_spawned(target_id)
    try:
        info = wait_for_worker_ready(
            session,
            agent_type=agent_type,
            terminal_type=terminal_type,
            cache_hint={"target_id": target_id},
            started_at=started_at,
            user_session=session,
            group_id=group_id,
        )
    except TimeoutError as exc:
        typer.echo(str(exc), err=True)
        if on_failure is not None:
            try:
                on_failure()
            except Exception:
                pass
        raise typer.Exit(1)
    if not _has_session_identity(info):
        typer.echo(f"未找到可用的 session '{session}'", err=True)
        if on_failure is not None:
            try:
                on_failure()
            except Exception:
                pass
        raise typer.Exit(1)
    cache = worker_cache_from_info(info)
    if target_id and not cache.get("target_id"):
        cache["target_id"] = target_id
    return cache, info


def _provider_shell_command(
    *,
    provider: str,
    local_id: str,
    native_args: list[str],
    native_shell_args: list[str] | None = None,
) -> str:
    # @@@provider-contract-delivery - native_shell_args are short, pre-quoted
    # shell snippets for provider channels that need local file expansion.
    return " ".join(
        [
            "cel",
            provider,
            "--identity",
            shlex.quote(local_id),
            "--",
            *(shlex.quote(str(arg)) for arg in native_args),
            *(native_shell_args or []),
        ]
    )


def _write_codex_prompt_file(*, group_id: str, session: str, prompt: str) -> Path:
    prompt_dir = _paths.STATE_DIR / "provider-prompts"
    prompt_dir.mkdir(parents=True, exist_ok=True)
    prompt_path = prompt_dir / f"codex-{group_id}-{session}.txt"
    _paths.atomic_write_text(prompt_path, prompt)
    return prompt_path


def kill_and_close_worker(worker: dict, group: dict) -> None:
    """Kill worker process (if running) and close its terminal surface. Best-effort, never raises."""
    try:
        if role_agent_type(worker) == "codex":
            info = resolve_worker(
                worker["session"],
                None,
                agent_type="codex",
                cache_hint=worker.get("cache") or {},
                group_id=str(group["name"]),
            )
        else:
            info = resolve_worker(
                worker["session"], None, group_id=str(group["name"])
            )
        if info.running and info.pid:
            try:
                os.kill(info.pid, signal.SIGTERM)
            except (ProcessLookupError, OSError):
                pass
        target_id = (worker.get("cache") or {}).get("target_id")
        if target_id:
            try:
                get_terminal(group_terminal_type(group)).close(target_id)
            except Exception:
                pass
        _delete_provider_prompt_files(
            group_id=str(group["name"]), session=worker["session"]
        )
    except Exception:
        pass


def _delete_provider_prompt_files(*, group_id: str, session: str) -> None:
    prompt_dir = _paths.STATE_DIR / "provider-prompts"
    for prompt_path in prompt_dir.glob(f"*-{group_id}-{session}.txt"):
        prompt_path.unlink(missing_ok=True)


def _tail_daemon_log_lines(limit: int = 20) -> str:
    log_path = _paths.STATE_DIR / "daemon.log"
    try:
        lines = log_path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return ""
    return "\n".join(lines[-limit:])


def launch_daemon(global_state: dict, foreground: bool, *, quiet: bool = False) -> None:
    from mycel_cli.daemon.runtime_identity import runtime_identity

    global_state["stopped"] = False
    global_state.update(runtime_identity())
    save_global(global_state)
    if foreground:
        global_state["daemon_pid"] = os.getpid()
        save_global(global_state)
        if not quiet:
            typer.echo(f"Mycel daemon 已启动，PID {os.getpid()}，前台模式。")
        from mycel_cli.daemon.main import run_daemon

        run_daemon()
        return

    _paths.STATE_DIR.mkdir(parents=True, exist_ok=True)
    with open(_paths.STATE_DIR / "daemon.log", "a", encoding="utf-8") as log_file:
        proc = subprocess.Popen(
            [sys.executable, "-m", "mycel_cli.daemon"],
            stdin=subprocess.DEVNULL,
            stdout=log_file,
            stderr=log_file,
            cwd=str(_paths.STATE_DIR),
            start_new_session=True,
        )
    time.sleep(0.2)
    if proc.poll() is not None:
        global_state["daemon_pid"] = None
        save_global(global_state)
        tail = _tail_daemon_log_lines()
        message = f"Mycel daemon 启动失败，退出码 {proc.returncode}。"
        if tail:
            message += "\n最近日志：\n" + tail
        typer.echo(message, err=True)
        raise typer.Exit(1)
    global_state["daemon_pid"] = proc.pid
    save_global(global_state)
    if not quiet:
        typer.echo(f"Mycel daemon 已启动，PID {proc.pid}，后台模式。")


def _codex_hook_paths() -> list[Path]:
    paths = [provider_config_home() / ".codex" / "hooks.json"]
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if result.returncode == 0:
            paths.append(Path(result.stdout.strip()) / ".codex" / "hooks.json")
    except Exception:
        pass
    deduped: list[Path] = []
    seen: set[Path] = set()
    for path in paths:
        if path in seen:
            continue
        seen.add(path)
        deduped.append(path)
    return deduped


def _codex_config_path() -> Path:
    return provider_config_home() / ".codex" / "config.toml"


def _toml_basic_string_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace('"', '\\"')


def _ensure_codex_root_setting(config_path: Path, key: str, value_literal: str) -> None:
    """Ensure a root-level TOML scalar exists with the desired value.

    We only patch the root section (before the first table) so we avoid
    accidentally writing `approval_policy` or `sandbox_mode` inside some later
    table.
    """
    assignment = f"{key} = {value_literal}\n"
    text = config_path.read_text(encoding="utf-8") if config_path.exists() else ""
    if not text:
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(assignment, encoding="utf-8")
        return

    lines = text.splitlines(keepends=True)
    updated: list[str] = []
    before_first_table = True
    found = False
    key_re = re.compile(rf"^\s*{re.escape(key)}\s*=")
    section_re = re.compile(r"^\s*\[[^\]]+\]\s*$")

    for line in lines:
        stripped = line.strip()
        if before_first_table and key_re.match(stripped):
            updated.append(assignment)
            found = True
            continue
        if section_re.match(stripped):
            if before_first_table and not found:
                updated.append(assignment)
                found = True
            before_first_table = False
        updated.append(line)

    if before_first_table and not found:
        updated.append(assignment)

    new_text = "".join(updated)
    if new_text != text:
        config_path.write_text(new_text, encoding="utf-8")


def _ensure_codex_automation_defaults(config_path: Path) -> None:
    """Ensure Codex launches in non-interactive approval mode for cel sessions."""
    _ensure_codex_root_setting(config_path, "approval_policy", '"never"')
    _ensure_codex_root_setting(config_path, "sandbox_mode", '"danger-full-access"')


def _ensure_single_codex_project_trusted(config_path: Path, project_path: str) -> None:
    header = f'[projects."{_toml_basic_string_escape(project_path)}"]'
    trust_line = 'trust_level = "trusted"'
    text = config_path.read_text(encoding="utf-8") if config_path.exists() else ""
    if not text:
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(f"{header}\n{trust_line}\n", encoding="utf-8")
        return

    lines = text.splitlines(keepends=True)
    updated: list[str] = []
    found_section = False
    in_target_section = False
    trust_written = False
    section_re = re.compile(r"^\s*\[[^\]]+\]\s*$")

    for line in lines:
        stripped = line.strip()
        if section_re.match(stripped):
            if in_target_section and not trust_written:
                updated.append(f"{trust_line}\n")
            in_target_section = stripped == header
            if in_target_section:
                found_section = True
                trust_written = False
            updated.append(line)
            continue

        if in_target_section and stripped.startswith("trust_level"):
            updated.append(f"{trust_line}\n")
            trust_written = True
            continue

        updated.append(line)

    if in_target_section and not trust_written:
        updated.append(f"{trust_line}\n")

    new_text = "".join(updated)
    if not found_section:
        if new_text and not new_text.endswith("\n"):
            new_text += "\n"
        if new_text:
            new_text += "\n"
        new_text += f"{header}\n{trust_line}\n"

    if new_text != text:
        config_path.write_text(new_text, encoding="utf-8")


def _ensure_codex_project_trusted(target_path: str) -> None:
    """Ensure the target directory is trusted in the current HOME's Codex config.

    Codex trust prompts are not suppressed by command-line flags in current CLI
    versions, so we must persist the project path into `config.toml`.
    """
    config_path = _codex_config_path()
    _ensure_codex_automation_defaults(config_path)
    expanded = Path(target_path).expanduser()
    if not expanded.is_absolute():
        expanded = Path(os.path.abspath(str(Path.cwd() / expanded)))
    raw_target = str(expanded)
    resolved_target = str(expanded.resolve(strict=False))
    aliases = [raw_target]
    if resolved_target != raw_target:
        aliases.append(resolved_target)

    for alias in aliases:
        _ensure_single_codex_project_trusted(config_path, alias)


def _claude_config_path() -> Path:
    return provider_config_home() / ".claude.json"


def _ensure_claude_project_trusted(target_path: str) -> None:
    """Persist `hasTrustDialogAccepted=true` for the target path in ~/.claude.json.

    Claude Code prompts an interactive trust dialog the first time it accesses
    an unknown folder; `--dangerously-skip-permissions` does not bypass it.
    Pre-marking the path mirrors `_ensure_codex_project_trusted` for codex.
    """
    config_path = _claude_config_path()
    expanded = Path(target_path).expanduser()
    if not expanded.is_absolute():
        expanded = Path(os.path.abspath(str(Path.cwd() / expanded)))
    raw_target = str(expanded)
    resolved_target = str(expanded.resolve(strict=False))
    aliases = [raw_target]
    if resolved_target != raw_target:
        aliases.append(resolved_target)

    config = (
        json.loads(config_path.read_text(encoding="utf-8"))
        if config_path.exists()
        else {}
    )
    if not isinstance(config, dict):
        raise ValueError(f"{config_path} must contain a JSON object")

    projects = config.get("projects")
    if not isinstance(projects, dict):
        projects = {}
        config["projects"] = projects

    changed = False
    for alias in aliases:
        entry = projects.get(alias)
        if not isinstance(entry, dict):
            entry = {}
            projects[alias] = entry
            changed = True
        if entry.get("hasTrustDialogAccepted") is not True:
            entry["hasTrustDialogAccepted"] = True
            changed = True

    if changed:
        config_path.parent.mkdir(parents=True, exist_ok=True)
        config_path.write_text(
            json.dumps(config, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
