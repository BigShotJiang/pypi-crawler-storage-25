"""Per-worker stop / silent detection.

`check_worker` is called once per worker per tick. It:
  - consumes stop-file → persists reply → notifies supervisor (with first-stop
    suppression + throttle), returns None
  - detects JSONL-mtime silent and returns a silent info dict for batching
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from mycel_cli.group._workflow import memory_state
from mycel_cli.group._workflow.constants import (
    MIN_NOTIFY_INTERVAL,
    REPLY_INLINE_LIMIT,
    SILENT_MAX_COUNT,
    SILENT_TIMEOUT,
    log,
    stop_file,
)
from mycel_cli.group._workflow.notify import notify_supervisor_from_role
from mycel_cli.group._workflow.xml_format import format_stop_msg
from mycel_cli.group._state.groups import mutate_group
from mycel_cli.group._state.messages import write_and_index_message
from mycel_cli.group._state.transcript import append_transcript
from mycel_cli.group._state.roles import (
    role_jsonl_path,
    worker_session_id,
)


def jsonl_age(user: dict, now: float) -> float | None:
    """Return seconds since user's JSONL was last written, or None if unavailable."""
    path = role_jsonl_path(user)
    if path is None:
        return None
    try:
        return now - path.stat().st_mtime
    except OSError:
        return None


def _save_worker_output(
    group_name: str,
    session: str,
    content: str,
) -> Path | None:
    """把 Worker 的 stop 回复写入 messages/ 并追加索引，返回路径。内容为空则返回 None。"""
    if not content:
        return None
    try:
        _, out_file = write_and_index_message(
            group_name,
            role="worker",
            session=session,
            event_type="stop",
            content=content,
        )
        return out_file
    except Exception as e:
        log.warning("Failed to save worker output [%s/%s]: %s", group_name, session, e)
        return None


def _mark_user_bootstrapped(group_name: str, session: str) -> None:
    """Persist bootstrapped=True so daemon restart doesn't re-suppress the next stop."""
    try:
        with mutate_group(group_name) as m:
            for u in m.get("roles", []):
                if u.get("session") == session:
                    u["bootstrapped"] = True
                    return
    except Exception as e:
        log.warning("Failed to mark user %s bootstrapped: %s", session, e)


def _read_stop_payload(sf: Path, group_name: str, session: str) -> str:
    """Parse the stop-signal JSON; return last_assistant_message or empty string.

    Never raises — all failure modes produce an empty message and log a warning,
    since observability must not break the main event-relay flow.
    """
    try:
        stop_data = json.loads(sf.read_text())
    except (json.JSONDecodeError, OSError) as e:
        log.warning(
            "stop signal [%s/%s] unreadable (%s): %s — sup will see empty reply",
            group_name,
            session,
            sf,
            e,
        )
        return ""
    last_msg = stop_data.get("last_assistant_message", "")
    if not last_msg:
        log.warning(
            "stop signal [%s/%s] has no last_assistant_message field; sup will see empty reply (path=%s)",
            group_name,
            session,
            sf,
        )
    return last_msg


def _handle_stop(
    group_name: str,
    group: dict[str, Any],
    worker: dict[str, Any],
    session: str,
    sf: Path,
    key: str,
) -> None:
    """Consume stop signal: persist reply, notify supervisor with throttle + first-stop suppression."""
    last_msg = _read_stop_payload(sf, group_name, session)

    sf.unlink(missing_ok=True)
    memory_state.last_silent.pop(key, None)
    memory_state.silent_count.pop(key, None)
    memory_state.silent_closed.discard(key)

    now = time.time()
    last = memory_state.last_notify.get(key, 0)
    if now - last < MIN_NOTIFY_INTERVAL:
        log.info(
            "Stop signal consumed, throttled (%.0fs since last notify)", now - last
        )
        memory_state.mark_dirty()
        return

    # Persist Worker→Supervisor reply to transcript before notifying.
    # append_transcript never raises — observability must not break the main
    # event-relay flow.
    append_transcript(
        group_name,
        direction="worker_to_sup",
        worker=session,
        content=last_msg,
        kind="stop_reply",
    )

    if session not in memory_state.first_stop_suppressed:
        memory_state.first_stop_suppressed.add(session)
        memory_state.last_notify[key] = now
        log.info("Initial stop suppressed [%s/%s]", group_name, session)
        _mark_user_bootstrapped(group_name, session)
        memory_state.mark_dirty()
        return

    # Always persist full output to messages/ (100% write)
    saved_file = _save_worker_output(group_name, session, last_msg)
    # output_file in notification only when reply exceeds inline limit
    inline_reply = last_msg
    notify_output_file: Path | None = None
    if len(last_msg) > REPLY_INLINE_LIMIT:
        notify_output_file = saved_file
        inline_reply = last_msg[:REPLY_INLINE_LIMIT] + "…"
    msg = format_stop_msg(group_name, session, inline_reply, notify_output_file)
    notify_supervisor_from_role(
        group_id=group_name,
        group=group,
        sender=worker,
        message=msg,
    )
    memory_state.last_notify[key] = now
    log.info("Stop signal consumed [%s/%s]", group_name, session)
    memory_state.mark_dirty()


def _check_silent(
    group_name: str,
    session: str,
    worker: dict[str, Any],
    key: str,
) -> dict[str, Any] | None:
    """Return silent info dict if JSONL mtime exceeds the (escalating) timeout; else None."""
    now = time.time()
    age = jsonl_age(worker, now)
    if age is None:
        return None
    last_silent = memory_state.last_silent.get(key, 0)
    # 渐进式退避：1st=180s, 2nd=240s, 3rd+=300s
    count_so_far = memory_state.silent_count.get(key, 0)
    effective_timeout = min(SILENT_TIMEOUT + count_so_far * 60, 300)
    if age <= effective_timeout or now - last_silent <= effective_timeout:
        return None

    if key in memory_state.silent_closed:
        memory_state.last_silent[key] = now
        log.info(
            "JSONL silent suppressed (closed) [%s/%s] (%ds)",
            group_name,
            session,
            int(age),
        )
        memory_state.mark_dirty()
        return None

    count = memory_state.silent_count.get(key, 0) + 1
    memory_state.silent_count[key] = count
    memory_state.last_silent[key] = now
    if count >= SILENT_MAX_COUNT:
        memory_state.silent_closed.add(key)
    log.info(
        "JSONL silent detected [%s/%s] (%ds) count=%d/%d",
        group_name,
        session,
        int(age),
        count,
        SILENT_MAX_COUNT,
    )
    memory_state.mark_dirty()
    return {
        "session": session,
        "age": int(age),
        "silent_count": count,
    }


def check_worker(
    group_name: str,
    group: dict[str, Any],
    worker: dict[str, Any],
) -> dict[str, Any] | None:
    """对一个 worker 做 stop/silent 检测。

    Stop 事件：立即通知 supervisor，返回 None。
    Silent 事件：更新状态后返回 silent info dict，由调用方聚合记录为本地健康观察。
    无事件：返回 None。
    """
    session = worker.get("session")
    if not session:
        return None

    session_id = worker_session_id(worker)
    if not session_id:
        return None

    key = f"{group_name}:{session}"
    sf = stop_file(session_id)

    if sf.exists():
        _handle_stop(group_name, group, worker, session, sf, key)
        return None

    return _check_silent(group_name, session, worker, key)
