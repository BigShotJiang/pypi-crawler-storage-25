"""Group workflow loop: iterate groups, route events, sleep, repeat.

Intentionally thin — all detection and notification logic lives in sibling
modules (`worker_check`, `review`, `notify`). The unified local daemon
starts this loop as one sibling task.
"""

from __future__ import annotations

import os
import signal
import sys
import threading
import time
from typing import Any

from mycel_cli.group._workflow import memory_state
from mycel_cli.group._workflow.constants import POLL_INTERVAL, log
from mycel_cli.group._workflow.review import (
    check_group_start_signal,
    check_group_stop_signal,
    check_group_sync_signal,
    check_pending_review_verdicts,
    check_reviewer_stop_signals,
)
from mycel_cli.group._workflow.worker_check import check_worker
from mycel_cli.group._workflow.xml_format import (
    format_aggregated_silent_msg,
    format_silent_msg,
)
from mycel_cli.group._state import paths as _paths
from mycel_cli.group._state.globals_ import load_global
from mycel_cli.group._state.groups import list_groups, load_group
from mycel_cli.group._state.messages import write_and_index_message
from mycel_cli.group._state.roles import (
    find_supervisor,
    iter_workers,
)
from mycel_cli.daemon.task_status import write_task_status


def _startup() -> None:
    """One-time group workflow-loop startup: clean stale signals, restore group workflow memory state."""
    log.info("Group workflow loop started (pid=%d)", os.getpid())

    for f in _paths.STATE_DIR.glob("stop-*"):
        f.unlink(missing_ok=True)
        log.info(f"Cleaned stale signal: {f.name}")

    memory_state.load()


def _install_signal_handlers() -> None:
    if threading.current_thread() is not threading.main_thread():
        return

    def handle_signal(signum: int, frame: Any) -> None:
        log.info("Group workflow loop stopping")
        sys.exit(0)

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)


def _write_group_loop_status(payload: dict[str, Any]) -> None:
    write_task_status("group-loop", payload)


def _mark_group_loop_active() -> None:
    _write_group_loop_status(
        {
            "state": "active",
            "last_tick_at": time.time(),
            "last_error": None,
        }
    )


def _mark_group_loop_error(
    *, state: str, group_name: str | None, exc: Exception
) -> None:
    _write_group_loop_status(
        {
            "state": state,
            "group": group_name,
            "last_tick_at": time.time(),
            "error_type": exc.__class__.__name__,
            "last_error": str(exc),
        }
    )


def _write_silent_to_messages(
    group_name: str, silent_batch: list[dict[str, Any]], msg: str
) -> None:
    """Persist silent event to messages/ index. Never raises."""
    try:
        if len(silent_batch) == 1:
            write_and_index_message(
                group_name,
                role="daemon",
                session=silent_batch[0]["session"],
                event_type="silent",
                content=msg,
            )
        else:
            write_and_index_message(
                group_name,
                role="daemon",
                event_type="silent",
                content=msg,
            )
    except Exception as e:
        log.warning("Failed to write silent event to messages/ [%s]: %s", group_name, e)


def _process_silent_batch(group_name: str, silent_batch: list[dict[str, Any]]) -> None:
    """Persist local silent health observations without sending role chat."""
    if not silent_batch:
        return
    if len(silent_batch) == 1:
        s = silent_batch[0]
        msg = format_silent_msg(
            group_name,
            s["session"],
            s["age"],
            s["silent_count"],
        )
    else:
        msg = format_aggregated_silent_msg(group_name, silent_batch)

    _write_silent_to_messages(group_name, silent_batch, msg)


def _tick_group(group_name: str) -> None:
    """Run one tick of detection / routing for a single group.

    Returns early when group is stopped / unclaimed.
    """
    try:
        group = load_group(group_name)
        if group is None:
            return

        # group sync is pure reviewer-side context refresh. It should not be
        # gated on group active state or supervisor presence.
        check_group_sync_signal(group_name, group)

        if group.get("status") == "stopped":
            return

        # ── group stop signal (from CLI) ──────────────────────
        # Must be checked before supervisor guard, because stop signal is written
        # by the CLI before setting status=stopped.
        if check_group_stop_signal(group_name, group):
            return  # Group was stopped immediately
        group = load_group(group_name) or group
        if group.get("status") == "stopped":
            return

        # Unclaimed group = dormant. 没 supervisor 说明还没 wire 起来，
        # 主动跳过比"跑完再丢弃"更干净，也不留 warning 噪声。
        if not find_supervisor(group):
            return

        check_group_start_signal(group_name, group)

        # ── reviewer stop results / review settlement ───────────
        check_reviewer_stop_signals(group_name, group)
        group = load_group(group_name) or group
        if group.get("status") == "stopped":
            return

        # Check pending review events; settle any where all reviewers have
        # returned results (this mutates group state, reload afterwards).
        check_pending_review_verdicts(group_name, group)
        group = load_group(group_name) or group
        if group.get("status") == "stopped":
            return

        # ── group sync signal (from group update / reviewer add) ──
        check_group_sync_signal(group_name, group)

        # ── worker stop/silent detection ────────────────────────
        silent_batch: list[dict[str, Any]] = []
        for worker in iter_workers(group):
            silent = check_worker(group_name, group, worker)
            if silent:
                silent_batch.append(silent)
        _process_silent_batch(group_name, silent_batch)
    finally:
        memory_state.flush_if_dirty()


def _is_fatal_group_workflow_error(exc: Exception) -> bool:
    return isinstance(exc, ValueError)


def run_group_workflow_loop() -> None:
    _startup()
    _install_signal_handlers()
    _mark_group_loop_active()

    while True:
        loop_had_error = False
        try:
            g = load_global()
            if g is None:
                log.info("No active cel, exiting")
                break
            if g.get("stopped"):
                log.info("Cel marked stopped, exiting")
                break

            for group_name in list_groups():
                try:
                    _tick_group(group_name)
                except Exception as exc:
                    loop_had_error = True
                    if _is_fatal_group_workflow_error(exc):
                        _mark_group_loop_error(
                            state="fatal",
                            group_name=group_name,
                            exc=exc,
                        )
                        log.exception(
                            "Daemon fatal group error [%s]; exiting",
                            group_name,
                        )
                        raise
                    _mark_group_loop_error(
                        state="degraded",
                        group_name=group_name,
                        exc=exc,
                    )
                    log.exception("Daemon group loop error [%s]", group_name)

        except Exception as exc:
            if _is_fatal_group_workflow_error(exc):
                raise
            loop_had_error = True
            _mark_group_loop_error(state="degraded", group_name=None, exc=exc)
            log.exception("Group workflow loop error")

        if not loop_had_error:
            _mark_group_loop_active()

        time.sleep(POLL_INTERVAL)
