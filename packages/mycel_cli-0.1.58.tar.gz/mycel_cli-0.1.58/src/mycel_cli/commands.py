"""Execution shell for cel."""

from __future__ import annotations

import contextlib
import json
import subprocess
import sys
from collections.abc import Sequence
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, TextIO

from mycel_sdk import Client
from mycel_sdk.errors import ApiError

from .config import (
    CliConfig,
    effective_base_url,
    load_cli_config,
    load_owner_config,
)
from .daemon import surfaces
from .handlers import ProcessRequest, RawOutput, handle_command


def _package_version() -> str:
    try:
        return version("mycel-cli")
    except PackageNotFoundError:
        return "unknown"


def _client_from_openapi_root(
    *,
    package_root: str,
    base_url: str,
    auth_token: str | None,
) -> Any:
    return Client.from_openapi_client_root(
        package_root,
        base_url=base_url,
        auth_token=auth_token,
    )


def _client_from_config(
    *,
    auth_token: str | None,
    base_url: str,
) -> Client:
    return Client(
        auth_token=auth_token,
        base_url=base_url,
    )


def _openapi_client_root() -> str | None:
    import os

    root = os.getenv("MYCEL_OPENAPI_CLIENT_ROOT")
    if root is None:
        return None
    root = root.strip()
    return root or None


class _LazyValue:
    def __init__(self, factory: Any) -> None:
        self._factory = factory
        self._resolved = False
        self._value: Any = None

    def resolve(self) -> Any:
        if not self._resolved:
            self._value = self._factory()
            self._resolved = True
        return self._value

    def __getattr__(self, name: str) -> Any:
        return getattr(self.resolve(), name)


def _config_for_command(args: Any) -> CliConfig:
    scope = getattr(args, "config_scope", "identity")
    if scope == "login":
        base_url = args.base_url or effective_base_url()["base_url"]
        return CliConfig(base_url=base_url, auth_token=getattr(args, "token", None))
    if scope == "owner":
        return load_owner_config()
    if scope != "identity":
        raise RuntimeError(f"unsupported config scope: {scope}")
    return load_cli_config(cwd=Path.cwd())


def _client_for_config(config: Any) -> Any:
    openapi_client_root = _openapi_client_root()
    if openapi_client_root is not None:
        return _client_from_openapi_root(
            package_root=openapi_client_root,
            base_url=config.base_url,
            auth_token=config.auth_token,
        )
    return _client_from_config(
        auth_token=config.auth_token,
        base_url=config.base_url,
    )


def _execute_command(
    args: Any,
    *,
    client: Any | None,
    stdin: TextIO,
    stdout: TextIO,
) -> int:
    cfg = _LazyValue(lambda: _config_for_command(args))
    resolved_client = (
        client if client is not None else _LazyValue(lambda: _client_for_config(cfg))
    )

    payload = handle_command(
        args=args,
        handler=args.handler,
        client=resolved_client,
        config=cfg,
        stdin=stdin,
        stdout=stdout,
    )
    return _write_payload(payload, stdout=stdout)


def _write_payload(payload: Any, *, stdout: TextIO) -> int:
    if isinstance(payload, RawOutput):
        stdout.write(payload.text)
        return payload.return_code
    if isinstance(payload, ProcessRequest):
        surface_ref = surfaces.register_from_env(payload.env)
        pending_surface_ref = None
        if surface_ref is None:
            pending_surface_ref = surfaces.register_pending_from_env(payload.env)
        try:
            return subprocess.run(
                payload.command, env=payload.env, check=False
            ).returncode
        finally:
            if surface_ref is not None:
                surfaces.unregister_from_env(payload.env)
            if pending_surface_ref is not None:
                surfaces.unregister_pending_from_env(payload.env)
    stdout.write(json.dumps(payload, ensure_ascii=False))
    stdout.write("\n")
    return 0


def _print_start_here(stdout: TextIO) -> None:
    stdout.write(
        "\nStart here:\n"
        "  cel self connect <backend-url>  # optional: use a self-hosted Mycel backend\n"
        "  cel codex        # or: cel claude\n"
        "  cel agent guide\n"
        "  The agent will inspect local state, ask when there is a choice, then run the needed setup.\n"
        '  cel send-message @<user-or-local-id> "hello"\n'
        "  cel read-message @<user-or-local-id>\n"
        '  cel send-message <chat-id> "hello group"\n'
        "  cel read-message <chat-id>\n"
        '  cel send-message <chat-id>@<user-or-local-id> "please check this"\n'
        "  cel group create\n"
    )


def run_cli(
    argv: Sequence[str],
    *,
    client: Any | None = None,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
) -> int:
    import click

    from mycel_cli.typer_app import app

    in_stream = stdin or sys.stdin
    out = stdout or sys.stdout
    err = stderr or sys.stderr
    normalized_argv = list(argv)

    def run_command(args: Any) -> int:
        return _execute_command(args, client=client, stdin=in_stream, stdout=out)

    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            result = app(
                args=normalized_argv or ["--help"],
                prog_name="cel",
                standalone_mode=False,
                obj={"run_command": run_command},
            )
        if not normalized_argv:
            _print_start_here(out)
        return int(result or 0)
    except ApiError as exc:
        err.write(f"error: {exc}\n")
        return 1
    except RuntimeError as exc:
        err.write(f"error: {exc}\n")
        return 1
    except click.ClickException as exc:
        with contextlib.redirect_stderr(err):
            exc.show()
        return int(exc.exit_code)
    except click.exceptions.Exit as exc:
        return int(exc.exit_code or 0)
    except SystemExit as exc:
        return int(exc.code or 0)
