"""BloodHound CE API client."""
import importlib.resources
import json
import logging
from pathlib import Path

import requests

log = logging.getLogger(__name__)


def get_token(base_url: str, username: str, password: str) -> str:
    """Authenticate to BloodHound CE and return a session token.

    Endpoint: POST /api/v2/login
    Body:     {"login_method": "secret", "username": ..., "secret": ...}
    Returns the session_token string from data.session_token.
    """
    url = f"{base_url.rstrip('/')}/api/v2/login"
    resp = requests.post(
        url,
        json={"login_method": "secret", "username": username, "secret": password},
        timeout=30,
    )
    resp.raise_for_status()
    body = resp.json()
    token = body.get("data", {}).get("session_token")
    if not token:
        raise ValueError(f"No session_token in response: {body}")
    return token


def upload_opengraph(json_file: str, base_url: str, token: str):
    data = json.loads(Path(json_file).read_text())
    url = f"{base_url.rstrip('/')}/api/v2/graphs/custom-upload"
    resp = requests.post(
        url,
        json=data,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        timeout=60,
    )
    resp.raise_for_status()
    print(f"Upload complete: {resp.status_code}")


def provision_custom_types(base_url: str, token: str, types_file: str | None = None):
    """POST RACF custom node type definitions to BloodHound CE.

    Uses the bundled racfhound/data/custom-types.json by default.
    Pass types_file to override with a local file.

    BloodHound CE endpoint: POST /api/v2/custom-node-kinds
    """
    if types_file:
        data = json.loads(Path(types_file).read_text())
    else:
        ref = importlib.resources.files("racfhound.data").joinpath("custom-types.json")
        data = json.loads(ref.read_text(encoding="utf-8"))

    url = f"{base_url.rstrip('/')}/api/v2/custom-node-kinds"
    resp = requests.post(
        url,
        json=data,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        timeout=30,
    )
    resp.raise_for_status()
    print(f"Custom types provisioned: {resp.status_code}")
    n = len(data.get("custom_types", {}))
    print(f"  Registered {n} node type(s): {', '.join(data.get('custom_types', {}).keys())}")


def populate_saved_queries(base_url: str, token: str, queries_dir: str | None = None):
    """POST bundled Cypher queries to BloodHound CE, skipping any that already exist.

    BloodHound CE endpoints:
      GET  /api/v2/saved-queries          — returns list of existing queries
      POST /api/v2/saved-queries          — creates a single query
    """
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    base = base_url.rstrip("/")

    # Load query files
    if queries_dir:
        query_files = list(Path(queries_dir).glob("*.json"))
    else:
        pkg = importlib.resources.files("racfhound.data.queries")
        query_files = [f for f in pkg.iterdir() if f.name.endswith(".json")]

    if not query_files:
        print("No query files found.")
        return

    # Fetch existing query names to avoid duplicates
    resp = requests.get(f"{base}/api/v2/saved-queries", headers=headers, timeout=30)
    resp.raise_for_status()
    existing = {q["name"] for q in resp.json().get("data", [])}
    log.debug("Existing saved queries: %d", len(existing))

    created = skipped = errors = 0
    for qf in sorted(query_files, key=lambda f: f.name):
        try:
            query = json.loads(qf.read_text(encoding="utf-8"))
        except Exception as e:
            log.warning("Skipping %s — invalid JSON: %s", qf.name, e)
            errors += 1
            continue

        name = query.get("name", "")
        if name in existing:
            log.debug("Skip (exists): %s", name)
            skipped += 1
            continue

        try:
            r = requests.post(
                f"{base}/api/v2/saved-queries",
                json=query,
                headers=headers,
                timeout=30,
            )
            r.raise_for_status()
            log.debug("Created: %s", name)
            created += 1
        except requests.HTTPError as e:
            log.warning("Failed to create %r: %s", name, e)
            errors += 1

    print(f"Saved queries: {created} created, {skipped} skipped (already exist), {errors} errors")
