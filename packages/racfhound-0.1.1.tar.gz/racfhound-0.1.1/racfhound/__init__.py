"""RACFHound — RACF collection and BloodHound export pipeline."""

__version__ = "0.1.0"
