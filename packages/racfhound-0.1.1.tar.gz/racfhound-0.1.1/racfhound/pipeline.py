"""Orchestrates the collect → transform → export pipeline."""
import json
from pathlib import Path


def _load_list(path: str | None) -> set[str]:
    if path is None:
        return set()
    return {line.strip().upper() for line in Path(path).read_text().splitlines() if line.strip()}


def run_collect(
    host: str,
    port: int,
    ftp_port: int,
    username: str,
    key_file: str | None,
    password: str | None,
    racf_dsns: list[str],
    job_class: str,
    msg_class: str,
    job_name: str,
    output_dir: str,
    poll_interval: int,
    poll_timeout: int,
) -> dict:
    from racfhound.collect import CollectConfig, collect

    config = CollectConfig(
        host=host,
        port=port,
        ftp_port=ftp_port,
        username=username,
        key_file=key_file,
        password=password,
        racf_dsns=racf_dsns,
        job_class=job_class,
        msg_class=msg_class,
        job_name=job_name,
        output_dir=Path(output_dir),
        poll_interval=poll_interval,
        poll_timeout=poll_timeout,
    )
    return collect(config)


def run_export(dump: str, apf: str | None, parmlib: str | None, proclib: str | None, output: str):
    import mfpandas
    from mfpandas_racfhound import to_bloodhound

    racf = mfpandas.IRRDBU00(dump)
    racf.parse_t()  # parse_t() is the blocking version; parse() starts a background thread

    graph = to_bloodhound(
        racf,
        apf_libs=_load_list(apf),
        parmlib_datasets=_load_list(parmlib),
        proclib_datasets=_load_list(proclib),
    )
    Path(output).write_text(json.dumps(graph, indent=2))
    print(f"Written: {output}")
