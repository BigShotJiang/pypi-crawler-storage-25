"""JCL template for RACF collection.

The generated job runs a single IRRDBU00 step.

APF, PARMLIB, and PROCLIB lists are gathered post-job by reading PARMLIB
members directly via FTP — no operator command authority required.

The RACFDUMP dataset uses BLKSIZE=4100 (explicit, not SMS-managed) so that
the ICF catalog records DSORG=PS.  Without an explicit BLKSIZE, DSORG is
stored as ** which blocks FTP and USS cp access.
"""
from __future__ import annotations


def _line(name: str, op: str, params: str) -> str:
    """Format one JCL statement with the name field padded to 8 characters."""
    return f"//{name:<8} {op} {params}"


def render_jcl(
    racf_dsns: list[str],
    job_class: str = "A",
    msg_class: str = "X",
    job_name: str = "",
) -> str:
    """Return the collection JCL as a UTF-8 string ready for EBCDIC encoding.

    Args:
        racf_dsns:  One or more RACF database dataset names (DISP=SHR).
        job_class:  JES job class (single character).
        msg_class:  SYSOUT message class (single character).
        job_name:   JCL job name, 1–8 characters.
    """
    if not racf_dsns:
        raise ValueError("At least one RACF DSN is required")

    jn = job_name.upper()[:8]
    jc = job_class.upper()
    mc = msg_class.upper()

    indd_lines = "\n".join(
        _line(f"INDD{i + 1}", "DD", f"DISP=SHR,DSN={dsn.upper()}")
        for i, dsn in enumerate(racf_dsns)
    )

    return f"""\
{_line(jn, 'JOB', f",'RACFHOUND COLLECT',CLASS={jc},MSGCLASS={mc},NOTIFY=&SYSUID")}
//*
//* IRRDBU00 — unload RACF database(s)
//*
//* BLKSIZE=4100 is specified explicitly (LRECL=4096 + 4-byte RDW).
//* BLKSIZE=0 (SMS-managed) leaves DSORG=** in the catalog which prevents
//* FTP retrieval.  Explicit BLKSIZE forces DSORG=PS into the catalog entry.
//*
{_line('IRRDBU00', 'EXEC', 'PGM=IRRDBU00,REGION=0M,PARM=NOLOCKINPUT')}
{_line('SYSPRINT', 'DD', 'SYSOUT=*')}
{indd_lines}
{_line('OUTDD', 'DD', 'DSN=&SYSUID..RACFDUMP,')}
//            DISP=(MOD,CATLG,DELETE),
//            SPACE=(CYL,(50,10),RLSE),
//            DCB=(RECFM=VB,LRECL=4096,BLKSIZE=4100),
//            UNIT=SYSDA
"""
