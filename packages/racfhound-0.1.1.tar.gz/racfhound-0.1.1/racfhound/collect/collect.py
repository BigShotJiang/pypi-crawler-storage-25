"""End-to-end RACF collection from a remote z/OS system.

Flow
----
1.  SSH connect
2.  Detect EBCDIC codepage (locale charmap)
3.  Discover RACF database DSNs via RVARY LIST (unless supplied explicitly)
4.  Render JCL, encode to EBCDIC, upload via SFTP
5.  Pre-delete stale RACFDUMP output dataset (idempotent re-runs)
6.  Submit job, capture job ID
7.  Poll until job leaves EXECUTING state; verify RACFDUMP is catalogued
8.  Retrieve RACFDUMP via FTP ASCII (handles VB RDWs + EBCDIC conversion)
9.  Read APF/PARMLIB/PROCLIB from PARMLIB members via FTP (no operator auth needed)
10. Parse and save all artifacts to output_dir
"""
from __future__ import annotations

import ftplib
import logging
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

from .connection import ZOSConnection
from .jcl import render_jcl
from .parsers import parse_apf, parse_parmlib, parse_proclib, parse_rvary

log = logging.getLogger(__name__)

_JOB_ID_RE = re.compile(r"\bJOB(\d{5,})\b", re.IGNORECASE)


@dataclass
class CollectConfig:
    host: str
    username: str
    racf_dsns: list[str]
    port: int = 22
    key_file: str | None = None
    password: str | None = None
    ftp_port: int = 21
    job_class: str = "A"
    msg_class: str = "X"
    job_name: str = ""  # defaults to username[:8]
    poll_interval: int = 15
    poll_timeout: int = 1800
    output_dir: Path = field(default_factory=lambda: Path("collect_output"))


# ------------------------------------------------------------------
# Public API
# ------------------------------------------------------------------


def collect(config: CollectConfig) -> dict[str, Path]:
    """Run the full collection pipeline against the configured z/OS system.

    Returns a dict mapping artifact names to local Path objects:
      racfdump   — IRRDBU00 unload (ASCII text, one record per line)
      apflist    — APF library DSNs, one per line  (may be empty)
      parmlist   — PARMLIB DSNs, one per line       (may be empty)
      proclist   — PROCLIB DSNs, one per line       (may be empty)
    """
    out_dir = Path(config.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    with ZOSConnection(
        host=config.host,
        port=config.port,
        username=config.username,
        key_file=config.key_file,
        password=config.password,
    ) as conn:
        conn.detect_ebcdic()
        log.info("EBCDIC: %s", conn.ebcdic)

        racf_dsns = config.racf_dsns or _discover_racf_dsns(conn)
        job_name = (config.job_name or config.username[:8]).upper()
        userid = config.username.upper()

        jcl = render_jcl(
            racf_dsns=racf_dsns,
            job_class=config.job_class,
            msg_class=config.msg_class,
            job_name=job_name,
        )
        job_id = _submit_job(conn, jcl, config, job_name, userid)
        _wait_for_job(conn, job_id, job_name, userid, config)

    # FTP session (separate from SSH)
    results = _ftp_collect(config, userid)
    return _write_artifacts(results, out_dir)


# ------------------------------------------------------------------
# Internal helpers
# ------------------------------------------------------------------


def _discover_racf_dsns(conn: ZOSConnection) -> list[str]:
    out, _, _ = conn.run("tsocmd 'RVARY LIST' 2>&1")
    log.debug("RVARY LIST: %s", out.strip())
    dsns = parse_rvary(out)
    log.info("Discovered RACF databases: %s", ", ".join(dsns))
    return dsns


def _submit_job(
    conn: ZOSConnection, jcl: str, config: CollectConfig,
    job_name: str, userid: str,
) -> str | None:
    tmp_utf8 = f"/tmp/racfhound_{userid}_collect.utf8"
    tmp_jcl  = f"/tmp/racfhound_{userid}_collect.jcl"

    # Pre-delete stale RACFDUMP so IEBGENER DISP=(NEW,CATLG) doesn't fail
    conn.run(f"tsocmd \"DELETE '{userid}.RACFDUMP'\" 2>/dev/null")

    conn.put_text(tmp_utf8, jcl)
    out, err, rc = conn.run(
        f"iconv -f UTF-8 -t {conn.ebcdic} {tmp_utf8} > {tmp_jcl}"
    )
    conn.run(f"rm -f {tmp_utf8}")
    if rc != 0:
        conn.run(f"rm -f {tmp_jcl}")
        raise RuntimeError(f"JCL encoding failed (rc={rc}): {err.strip()}")

    out, err, rc = conn.run(f"submit {tmp_jcl}")
    conn.run(f"rm -f {tmp_jcl}")
    if rc != 0:
        raise RuntimeError(f"submit failed (rc={rc}): {err.strip() or out.strip()}")

    m = _JOB_ID_RE.search(out + err)
    job_id = f"JOB{m.group(1)}" if m else None
    log.info("Submitted job %s (job_id=%s)", job_name, job_id or "unknown")
    return job_id


def _wait_for_job(
    conn: ZOSConnection, job_id: str | None, job_name: str,
    userid: str, config: CollectConfig,
) -> None:
    ref = job_id or job_name
    primary_dsn = f"{userid}.RACFDUMP"
    deadline = time.monotonic() + config.poll_timeout
    last_status = ""

    time.sleep(5)

    while time.monotonic() < deadline:
        status_out, _, _ = conn.run(f"tsocmd 'STATUS {ref}' 2>&1")
        last_status = status_out.strip()
        log.debug("STATUS %s: %s", ref, last_status)

        if "EXECUTING" not in status_out.upper():
            time.sleep(3)
            _, _, rc = conn.run(f"tsocmd \"LISTDS '{primary_dsn}'\" 2>&1")
            if rc != 0:
                raise RuntimeError(
                    f"Job {ref} completed but '{primary_dsn}' not catalogued.\n"
                    f"Last STATUS: {last_status}\n"
                    "Check JES output for abend or authorisation failure."
                )
            log.info("Job %s complete — RACFDUMP ready", ref)
            return

        log.info("Job %s executing … next check in %ds", ref, config.poll_interval)
        time.sleep(config.poll_interval)

    raise TimeoutError(f"Job {ref} did not complete within {config.poll_timeout}s")


def _ftp_collect(config: CollectConfig, userid: str) -> dict[str, str]:
    """Retrieve dump + read PARMLIB members for APF/PARMLIB/PROCLIB lists."""
    results: dict[str, str] = {}
    try:
        with ftplib.FTP() as ftp:
            ftp.connect(config.host, config.ftp_port, timeout=30)
            ftp.login(config.username, config.password or "")
            # z/OS FTP ASCII mode sends ISO 8859-1, not UTF-8
            ftp.encoding = "latin-1"
            log.debug("FTP: %s", ftp.getwelcome().splitlines()[0])

            # RACF dump — FTP ASCII (TYPE A) strips VB RDWs + converts EBCDIC
            dump_dsn = f"{userid}.RACFDUMP"
            dump_text = _ftp_text(ftp, dump_dsn)
            if dump_text is None:
                raise ftplib.error_perm(f"550 Could not retrieve {dump_dsn}")
            results["racfdump"] = dump_text
            log.info("FTP retrieved %s (%d bytes)", dump_dsn, len(dump_text))

            # APF / PARMLIB / PROCLIB from PARMLIB members
            _ftp_read_parmlib(ftp, results)

    except ftplib.error_perm as e:
        if "RACFDUMP" in str(e):
            raise RuntimeError(f"FTP could not retrieve RACFDUMP: {e}") from e
        log.warning("FTP partial failure: %s", e)
    except Exception as e:
        raise RuntimeError(f"FTP retrieval failed: {e}") from e

    return results


def _ftp_text(ftp: ftplib.FTP, dsn: str) -> str | None:
    """Retrieve a z/OS dataset via FTP ASCII mode (TYPE A).

    FTP ASCII mode on z/OS:
    - Converts EBCDIC to ASCII (ISO 8859-1 / Latin-1)
    - Strips VB record descriptor words (RDWs)
    - Presents records as newline-delimited lines

    ftp.encoding must be set to 'latin-1' before calling this function
    (ftplib defaults to 'utf-8' which fails on non-ASCII Latin-1 bytes).
    """
    lines: list[str] = []
    try:
        ftp.retrlines(f"RETR '{dsn}'", lines.append)
        log.debug("FTP read %s (%d lines)", dsn, len(lines))
        return "\n".join(lines) + "\n"
    except ftplib.error_perm as e:
        log.debug("FTP skip %s: %s", dsn, e)
        return None


def _ftp_read_parmlib(ftp: ftplib.FTP, results: dict[str, str]) -> None:
    """Read APF, PARMLIB, and PROCLIB lists from PARMLIB members via FTP.

    Reads IEASYS00 to discover the active PROG suffix, then reads PROGxx for
    the APF library list.  Also reads IEFSSNxx and MSTJCLxx for PARMLIB and
    PROCLIB concatenation when available.
    """
    # Determine active PROG suffix from IEASYS00
    prog_suffix = _find_parmlib_suffix(ftp, "PROG")
    parm_suffix = _find_parmlib_suffix(ftp, "PARMLIB") or "00"

    # APF list from PROGxx PARMLIB member
    if prog_suffix is not None:
        member = f"PROG{prog_suffix}"
        text = _ftp_text(ftp, f"SYS1.PARMLIB({member})")
        if text:
            results["apflist_raw"] = text
            log.info("Read APF list from SYS1.PARMLIB(%s)", member)

    # PARMLIB concatenation from PARAMLIBxx member (z/OS 2.1+)
    if parm_suffix:
        member = f"PARMLIB{parm_suffix}"
        text = _ftp_text(ftp, f"SYS1.PARMLIB({member})")
        if text:
            results["parmlist_raw"] = text

    # PROCLIB from IEFSSNxx (subsystem names, contains JES proc info)
    for suffix in ["00", "01", prog_suffix or "00"]:
        text = _ftp_text(ftp, f"SYS1.PARMLIB(IEFJOBS{suffix})")
        if text:
            results["proclist_raw"] = text
            break


def _find_parmlib_suffix(ftp: ftplib.FTP, keyword: str) -> str | None:
    """Scan IEASYS00 for 'keyword=xx' and return the suffix."""
    ieasys = _ftp_text(ftp, "SYS1.PARMLIB(IEASYS00)")
    if not ieasys:
        return None
    pattern = re.compile(rf"\b{keyword}\s*=\s*(\w+)", re.IGNORECASE)
    for line in ieasys.splitlines():
        m = pattern.search(line)
        if m:
            return m.group(1)
    return None


def _write_artifacts(results: dict[str, str], out_dir: Path) -> dict[str, Path]:
    artifacts: dict[str, Path] = {}

    _save(out_dir, "racfdump.txt", results.get("racfdump", ""), artifacts)

    for key, parser, name in [
        ("apflist_raw", parse_apf, "apflist"),
        ("parmlist_raw", parse_parmlib, "parmlist"),
        ("proclist_raw", parse_proclib, "proclist"),
    ]:
        raw = results.get(key, "")
        parsed = parser(raw)
        _save(out_dir, f"{name}.txt", parsed, artifacts, key=name)
        if raw and not parsed.strip():
            log.warning("%s: raw output found but no DSNs parsed", name)
            (out_dir / f"{name}_raw.txt").write_text(raw, encoding="utf-8")
        elif not raw:
            log.info("%s: not available (PARMLIB member not found)", name)

    return artifacts


def _save(
    out_dir: Path, filename: str, content: str,
    artifacts: dict, key: str | None = None,
) -> None:
    if not content.strip():
        return
    path = out_dir / filename
    path.write_text(content, encoding="utf-8")
    log.info("Saved %s (%d bytes)", path, len(content))
    artifacts[key or filename.split(".")[0]] = path
