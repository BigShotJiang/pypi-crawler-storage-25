"""SSH/SFTP connection to z/OS."""
from __future__ import annotations

import logging
from pathlib import Path

import paramiko

log = logging.getLogger(__name__)




class ZOSConnection:
    """Authenticated SSH/SFTP connection to a z/OS system.

    Handles EBCDIC codec detection.  All text passed to *put_text* is
    encoded to EBCDIC before upload; all bytes retrieved via *get_bytes*
    are raw (caller decodes).
    """

    def __init__(
        self,
        host: str,
        port: int = 22,
        username: str | None = None,
        key_file: str | None = None,
        password: str | None = None,
    ) -> None:
        self.host = host
        self.port = port
        self.username = username
        self.key_file = key_file
        self.password = password
        # Filled in after connect() + detect_ebcdic()
        self.ebcdic: str = "IBM-1047"
        self._client: paramiko.SSHClient | None = None
        self._sftp: paramiko.SFTPClient | None = None

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def connect(self) -> "ZOSConnection":
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kwargs: dict = dict(hostname=self.host, port=self.port, username=self.username)
        if self.key_file:
            kwargs["key_filename"] = str(self.key_file)
        if self.password:
            kwargs["password"] = self.password
        client.connect(**kwargs)
        self._client = client
        log.info("Connected to %s:%d as %s", self.host, self.port, self.username)
        return self

    def __enter__(self) -> "ZOSConnection":
        return self.connect()

    def __exit__(self, *_) -> None:
        self.close()

    def close(self) -> None:
        if self._sftp:
            self._sftp.close()
            self._sftp = None
        if self._client:
            self._client.close()
            self._client = None

    # ------------------------------------------------------------------
    # Shell commands
    # ------------------------------------------------------------------

    def run(self, command: str) -> tuple[str, str, int]:
        """Execute *command* in a non-interactive shell.

        Returns (stdout, stderr, exit_code).  stdout/stderr are decoded
        as UTF-8 with replacement (the SSH daemon translates EBCDIC→ASCII
        for the channel).
        """
        _, stdout, stderr = self._client.exec_command(command)
        exit_code = stdout.channel.recv_exit_status()
        out = stdout.read().decode("utf-8", errors="replace")
        err = stderr.read().decode("utf-8", errors="replace")
        return out, err, exit_code

    # ------------------------------------------------------------------
    # EBCDIC detection
    # ------------------------------------------------------------------

    def detect_ebcdic(self) -> str:
        """Query the system charmap and update *self.ebcdic*.

        The charmap is used as the iconv source/target encoding when
        converting artifacts on the z/OS side.  Falls back to IBM-1047.
        Returns the z/OS-native charmap name.
        """
        out, _, rc = self.run("locale charmap")
        charmap = out.strip()
        if rc == 0 and charmap:
            self.ebcdic = charmap
            log.debug("Detected charmap: %s", charmap)
            return charmap
        self.ebcdic = "IBM-1047"
        return self.ebcdic

    # ------------------------------------------------------------------
    # SFTP helpers
    # ------------------------------------------------------------------

    def _sftp_client(self) -> paramiko.SFTPClient:
        if not self._sftp:
            self._sftp = self._client.open_sftp()
        return self._sftp

    def put_bytes(self, remote_path: str, data: bytes) -> None:
        sftp = self._sftp_client()
        with sftp.open(remote_path, "wb") as fh:
            fh.write(data)

    def put_text(self, remote_path: str, text: str) -> None:
        """Upload *text* as UTF-8 via SFTP binary.

        Callers that need EBCDIC on z/OS must run iconv after uploading:
          iconv -f UTF-8 -t IBM-1047 <remote_path> > <ebcdic_path>
        """
        self.put_bytes(remote_path, text.encode("utf-8"))

    def get_bytes(self, remote_path: str) -> bytes:
        sftp = self._sftp_client()
        with sftp.open(remote_path, "rb") as fh:
            return fh.read()

    def get_text(self, remote_path: str, encoding: str = "utf-8") -> str:
        return self.get_bytes(remote_path).decode(encoding)
