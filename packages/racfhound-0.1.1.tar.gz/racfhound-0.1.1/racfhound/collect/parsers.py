"""Parse z/OS operator command output into plain DSN lists.

Each parser extracts dataset names from the raw text captured by the
CONSOLE/IKJEFT01 steps and returns a sorted list of uppercase DSNs,
one per line — matching the format expected by pipeline._load_list().

RVARY LIST  → ICH10011I PRIMARY/BACKUP DATABASE = <dsn>
D PROG,APF  → CSV450I LIBRARY=<dsn> VOLUME=<vol>
D PARMLIB   → PARMLIB DATASET = <dsn>[(member)]  VOLUME = <vol>
D PROCLIB   → DSNAME = <dsn>  VOLUME = <vol>
"""
from __future__ import annotations

import logging
import re

log = logging.getLogger(__name__)

# RVARY LIST (ICH15013I tabular format):
#   ACTIVE USE  NUM VOLUME   DATASET
#    YES   PRIM   1 D5CFG1   SYS1.RACFDS
#    YES   BACK   1 D5CFG1   SYS1.RACFDS.BACKUP
_RVARY_ROW_RE = re.compile(
    r"^\s*(?:YES|NO)\s+(PRIM|BACK)\s+\d+\s+\S+\s+(\S+)",
    re.IGNORECASE | re.MULTILINE,
)

# Patterns for each operator command output
_APF_RE = re.compile(r"LIBRARY\s*=\s*(\S+)\s+VOLUME", re.IGNORECASE)
_PARMLIB_RE = re.compile(r"PARMLIB\s+DATASET\s*=\s*(\S+)", re.IGNORECASE)
_PROCLIB_RE = re.compile(r"DSNAME\s*=\s*(\S+)", re.IGNORECASE)

# Member qualifier stripped from PARMLIB entries like SYS1.PARMLIB(ACTIVE)
_MEMBER_RE = re.compile(r"\([^)]+\)$")


def _strip_member(dsn: str) -> str:
    return _MEMBER_RE.sub("", dsn).strip()


def parse_rvary(raw: str) -> list[str]:
    """Return ordered list of RACF database DSNs from RVARY LIST output.

    Parses the ICH15013I tabular format:
      ACTIVE USE  NUM VOLUME   DATASET
       YES   PRIM   1 VOL001   SYS1.RACFDS
       YES   BACK   1 VOL001   SYS1.RACFDS.BACKUP

    Primary (PRIM) databases come before backup (BACK) databases.
    Raises ValueError if no databases are found.
    """
    prim, back = [], []
    for m in _RVARY_ROW_RE.finditer(raw):
        use, dsn = m.group(1).upper(), m.group(2).upper()
        (prim if use == "PRIM" else back).append(dsn)
    if not prim and not back:
        raise ValueError(
            "RVARY LIST returned no database names — "
            "check RACF authorisation (RVARY.SWITCH.RACF or RVARY.LIST.RACF)"
        )
    if prim:
        # Only use primary databases as IRRDBU00 INDD.  Including backup (BACK)
        # databases alongside the primary causes IRRDBU00 to leave DSORG=** in
        # the output dataset catalog entry, which blocks FTP retrieval.
        # Users who need backup databases can pass them explicitly via --racf-dsn.
        if back:
            log.debug("RVARY LIST: ignoring BACK databases %s", back)
        return prim
    return back


# PROGxx PARMLIB format: DSNAME(SYS1.LINKLIB) or DSNAME=SYS1.LINKLIB
_PROGXX_APF_RE = re.compile(r"DSNAME\s*[=(]\s*([A-Z#@$][A-Z0-9#@$.-]{0,43})", re.IGNORECASE)


def parse_apf(raw: str) -> str:
    """Return newline-separated DSNs from D PROG,APF or PROGxx PARMLIB output."""
    # D PROG,APF operator command output (CSV450I LIBRARY=dsn VOLUME=...)
    found = {m.group(1).upper() for m in _APF_RE.finditer(raw)}
    # PROGxx PARMLIB member (DSNAME(dsn) or DSNAME=dsn)
    found |= {m.group(1).upper() for m in _PROGXX_APF_RE.finditer(raw)}
    return "\n".join(sorted(found)) + ("\n" if found else "")


def parse_parmlib(raw: str) -> str:
    """Return newline-separated DSNs extracted from D PARMLIB output."""
    found = sorted(
        {_strip_member(m.group(1)).upper() for m in _PARMLIB_RE.finditer(raw)}
    )
    return "\n".join(found) + ("\n" if found else "")


def parse_proclib(raw: str) -> str:
    """Return newline-separated DSNs extracted from D PROCLIB output."""
    found = sorted({m.group(1).upper() for m in _PROCLIB_RE.finditer(raw)})
    return "\n".join(found) + ("\n" if found else "")
