"""Remote collection from z/OS via SSH."""
from .collect import CollectConfig, collect
from .connection import ZOSConnection

__all__ = ["CollectConfig", "collect", "ZOSConnection"]
