"""CLI entry point for racfhound."""
import logging

import click


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable debug logging.")
def cli(verbose: bool):
    """RACFHound — RACF → BloodHound pipeline."""
    logging.basicConfig(
        level=logging.DEBUG if verbose else logging.INFO,
        format="%(levelname)s %(message)s",
    )


# ---------------------------------------------------------------------------
# collect
# ---------------------------------------------------------------------------


@cli.command()
@click.option("--host", required=True, envvar="MF_HOST", help="z/OS SSH hostname.")
@click.option("--port", default=22, show_default=True, envvar="MF_PORT")
@click.option("--ftp-port", default=21, show_default=True, envvar="MF_FTP_PORT")
@click.option("--user", "username", required=True, envvar="MF_USER", help="TSO user ID.")
@click.option(
    "--key",
    "key_file",
    default=None,
    envvar="MF_KEY",
    help="Path to SSH private key (omit to use password auth).",
)
@click.option(
    "--password",
    default=None,
    envvar="MF_PASSWORD",
    help="SSH password (prefer --key; or set MF_PASSWORD env var).",
)
@click.option(
    "--racf-dsn",
    "racf_dsns",
    multiple=True,
    envvar="MF_RACF_DSN",
    help="RACF database DSN(s).  Repeat for secondary databases.  "
         "Omit to auto-discover via RVARY LIST.",
)
@click.option("--job-class", default="A", show_default=True, envvar="MF_JOB_CLASS")
@click.option("--msg-class", default="X", show_default=True, envvar="MF_MSG_CLASS")
@click.option("--job-name", default="RACFHUND", show_default=True)
@click.option(
    "--output-dir",
    "-o",
    default="collect_output",
    show_default=True,
    help="Local directory for collected artifacts.",
)
@click.option(
    "--poll-interval",
    default=15,
    show_default=True,
    help="Seconds between job-status polls.",
)
@click.option(
    "--poll-timeout",
    default=1800,
    show_default=True,
    help="Maximum seconds to wait for the collection job.",
)
def collect(
    host, port, ftp_port, username, key_file, password, racf_dsns,
    job_class, msg_class, job_name, output_dir,
    poll_interval, poll_timeout,
):
    """Collect RACF data from z/OS and save artifacts locally.

    \b
    After collection, run:
      racfhound export --dump <output_dir>/racfdump.txt \\
                       --apf <output_dir>/apflist.txt \\
                       --parmlib <output_dir>/parmlist.txt \\
                       --proclib <output_dir>/proclist.txt

    Environment variables: MF_HOST, MF_PORT, MF_USER, MF_KEY,
    MF_PASSWORD, MF_RACF_DSN (colon-separated), MF_JOB_CLASS, MF_MSG_CLASS.
    """
    from racfhound.pipeline import run_collect

    artifacts = run_collect(
        host=host,
        port=port,
        ftp_port=ftp_port,
        username=username,
        key_file=key_file,
        password=password,
        racf_dsns=list(racf_dsns),
        job_class=job_class,
        msg_class=msg_class,
        job_name=job_name,
        output_dir=output_dir,
        poll_interval=poll_interval,
        poll_timeout=poll_timeout,
    )

    click.echo("\nCollection complete.  Artifacts:")
    for name, path in artifacts.items():
        click.echo(f"  {name:12s}  {path}")

    racfdump = artifacts.get("racfdump")
    if racfdump:
        apf = artifacts.get("apflist", "")
        parmlib = artifacts.get("parmlist", "")
        proclib = artifacts.get("proclist", "")
        click.echo("\nNext step:")
        click.echo(
            f"  racfhound export --dump {racfdump}"
            + (f" --apf {apf}" if apf else "")
            + (f" --parmlib {parmlib}" if parmlib else "")
            + (f" --proclib {proclib}" if proclib else "")
        )


# ---------------------------------------------------------------------------
# export
# ---------------------------------------------------------------------------


@cli.command()
@click.option(
    "--dump", required=True, type=click.Path(exists=True),
    help="IRRDBU00 unload file (racfdump.txt from collect, or an existing unload).",
)
@click.option("--apf",     type=click.Path(exists=True), help="APF library list, one DSN per line.")
@click.option("--parmlib", type=click.Path(exists=True), help="PARMLIB dataset list, one DSN per line.")
@click.option("--proclib", type=click.Path(exists=True), help="PROCLIB dataset list, one DSN per line.")
@click.option("--output", "-o", default="racf_opengraph.json", show_default=True,
              help="Output OpenGraph JSON file.")
def export(dump, apf, parmlib, proclib, output):
    """Transform a RACF unload file into BloodHound OpenGraph JSON.

    \b
    Works with files from racfhound collect or any existing IRRDBU00 unload:
      racfhound export --dump racfdump.txt
      racfhound export --dump racfdump.txt --apf apflist.txt \\
                       --parmlib parmlist.txt --proclib proclist.txt
    """
    from racfhound.pipeline import run_export

    run_export(dump, apf, parmlib, proclib, output)


# ---------------------------------------------------------------------------
# login
# ---------------------------------------------------------------------------


@cli.command()
@click.option("--url", default="http://localhost:8080", show_default=True, envvar="BH_URL")
@click.option("--user", "username", required=True, envvar="BH_USER", prompt=True,
              help="BloodHound username / email.")
@click.option("--password", required=True, envvar="BH_PASSWORD",
              prompt=True, hide_input=True,
              help="BloodHound password (or set BH_PASSWORD).")
@click.option("--export", "do_export", is_flag=True,
              help="Print 'export BH_TOKEN=...' instead of just the token.")
def login(url, username, password, do_export):
    """Authenticate to BloodHound CE and print the session token.

    \b
    Capture the token in a variable:
      export BH_TOKEN=$(racfhound login --user admin@example.com --password s3cr3t)

    Or use --export to print the full shell assignment:
      eval $(racfhound login --user admin@example.com --password s3cr3t --export)
    """
    from racfhound.export import get_token

    token = get_token(url, username, password)
    if do_export:
        click.echo(f"export BH_TOKEN={token}")
    else:
        click.echo(token)


# ---------------------------------------------------------------------------
# upload
# ---------------------------------------------------------------------------


@cli.command()
@click.argument("json_file", type=click.Path(exists=True))
@click.option("--url", default="http://localhost:8080", show_default=True)
@click.option("--token", envvar="BH_TOKEN", required=True, help="BloodHound JWT (or set BH_TOKEN)")
def upload(json_file, url, token):
    """Upload an OpenGraph JSON file to a BloodHound instance."""
    from racfhound.export import upload_opengraph

    upload_opengraph(json_file, url, token)


# ---------------------------------------------------------------------------
# provision
# ---------------------------------------------------------------------------


@cli.command()
@click.option("--url", default="http://localhost:8080", show_default=True, envvar="BH_URL")
@click.option("--token", envvar="BH_TOKEN", required=True, help="BloodHound JWT (or set BH_TOKEN)")
@click.option(
    "--file", "types_file",
    default=None,
    type=click.Path(exists=True),
    help="Custom types JSON to provision (default: bundled racfhound/data/custom-types.json).",
)
def provision(url, token, types_file):
    """Register RACF node type icons/colours in BloodHound CE.

    Posts the custom node kind definitions to /api/v2/custom-node-kinds so
    BloodHound displays RACF nodes with the correct icons.  Run this once
    after connecting a new BloodHound instance.
    """
    from racfhound.export import provision_custom_types

    provision_custom_types(url, token, types_file)


# ---------------------------------------------------------------------------
# queries
# ---------------------------------------------------------------------------


@cli.command()
@click.option("--url", default="http://localhost:8080", show_default=True, envvar="BH_URL")
@click.option("--token", envvar="BH_TOKEN", required=True, help="BloodHound JWT (or set BH_TOKEN)")
@click.option(
    "--dir", "queries_dir",
    default=None,
    type=click.Path(exists=True, file_okay=False),
    help="Directory of query JSON files (default: bundled racfhound/data/queries/).",
)
def queries(url, token, queries_dir):
    """Populate BloodHound CE with the 40 bundled RACF Cypher queries.

    Fetches existing saved queries first and skips any whose name already
    exists, so the command is safe to re-run.
    """
    from racfhound.export import populate_saved_queries

    populate_saved_queries(url, token, queries_dir)
