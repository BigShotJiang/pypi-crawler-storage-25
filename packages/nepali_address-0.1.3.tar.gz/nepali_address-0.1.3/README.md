# nepali-address

A Python package for retrieving geographical data of Nepal, including Provinces, Districts, and Local Bodies (Municipalities/Rural Municipalities). This package is a Python port of the [nepali-address](https://github.com/yourusername/nepali-address) TypeScript library.

## Installation

```bash
pip install nepali-address
```

## Usage

### Provinces

```python
from nepali_address import get_provinces, get_province_by_id

# Get all provinces
provinces = get_provinces()

# Get province by ID
province = get_province_by_id(3)
# {'id': 3, 'name': 'Bagmati Province', 'name_ne': 'बागमती प्रदेश', ...}
```

### Districts

```python
from nepali_address import get_districts, get_district_by_name, get_districts_by_province

# Get all districts
districts = get_districts()

# Get district by name (auto-normalizes input)
kathmandu = get_district_by_name('Kathmandu')

# Get districts in a province
bagmati_districts = get_districts_by_province(3)
```

### Local Levels (Municipalities)

```python
from nepali_address import get_local_levels, get_local_levels_by_district

# Get all local levels (753 total)
all_local_levels = get_local_levels()

# Get local levels in Kathmandu
ktm_local_levels = get_local_levels_by_district(306)
```

## Features

- **Standardized Data**: Contains all 7 provinces, 77 districts, and 753 local bodies.
- **Fast Lookup**: Uses internal mapping for O(1) lookups by ID, Name, and Postal Code.
- **Normalization**: Handles input variations (e.g., "Kathmandu", "kathmandu", "Bagmati Province" vs "Bagmati").
- **Zero Dependencies**: Pure Python implementation with no external requirements.

## License

MIT
