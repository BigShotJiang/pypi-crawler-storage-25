import re
import unicodedata

def normalize(string: str) -> str:
    """
    Normalize the input given by user
    Useful for getting data that are little bit error like.
    """
    if not isinstance(string, str):
        return ""
        
    # Unicode normalization (NFC)
    string = unicodedata.normalize('NFC', string)
    
    # Lowercase and trim
    string = string.lower().strip()
    
    # Remove 'province' and 'प्रदेश'
    string = re.sub(r'\bprovince\b', '', string)
    string = string.replace('प्रदेश', '')
    
    # Replace multiple spaces with single space
    string = re.sub(r'\s+', ' ', string)
    
    return string.strip()
