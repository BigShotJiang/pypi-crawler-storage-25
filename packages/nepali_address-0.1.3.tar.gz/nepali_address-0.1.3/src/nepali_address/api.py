from typing import List, Optional, Union
from .data.provinces import PROVINCES
from .data.districts import DISTRICTS
from .data.local_levels import LOCAL_LEVELS
from .maps import (
    PROVINCE_BY_ID, PROVINCE_BY_ISO,
    DISTRICT_BY_ID, DISTRICT_BY_POSTCODE, DISTRICT_BY_NAME, DISTRICTS_BY_PROVINCE,
    LOCAL_LEVEL_BY_ID, LOCAL_LEVEL_BY_NAME, LOCAL_LEVELS_BY_DISTRICT, LOCAL_LEVELS_BY_TYPE
)
from .utils import normalize

# Province APIs
def get_provinces() -> List[dict]:
    """Retrieves the complete list of provinces in Nepal."""
    return list(PROVINCES)

def get_province_by_id(p_id: int) -> Optional[dict]:
    """Finds a specific province by its unique identifier (1-7)."""
    return PROVINCE_BY_ID.get(p_id)

def get_province_by_iso_code(iso_code: str) -> Optional[dict]:
    """Finds a province by its ISO 3166-2:NP code (e.g., 'NP-P3')."""
    return PROVINCE_BY_ISO.get(iso_code.upper())

# District APIs
def get_districts() -> List[dict]:
    """Retrieves the complete list of districts in Nepal."""
    return list(DISTRICTS)

def get_district_by_id(d_id: int) -> Optional[dict]:
    """Finds a specific district by its unique ID."""
    return DISTRICT_BY_ID.get(d_id)

def get_district_by_name(name: str) -> Optional[dict]:
    """Finds a specific district by its name."""
    return DISTRICT_BY_NAME.get(normalize(name))

def get_districts_by_province(province_id: int) -> List[dict]:
    """Retrieves all districts belonging to a specific province."""
    return DISTRICTS_BY_PROVINCE.get(province_id, [])

def get_district_by_postcode(postcode: str) -> Optional[dict]:
    """Retrieves a district by its 5-digit post code."""
    return DISTRICT_BY_POSTCODE.get(postcode)

# Local Level APIs
def get_local_levels() -> List[dict]:
    """Retrieves the complete list of all local bodies/municipalities in Nepal."""
    return list(LOCAL_LEVELS)

def get_local_level_by_id(l_id: int) -> Optional[dict]:
    """Finds a specific local level by its unique ID."""
    return LOCAL_LEVEL_BY_ID.get(l_id)

def get_local_level_by_name(name: str) -> Optional[dict]:
    """Finds a specific local level by its name."""
    return LOCAL_LEVEL_BY_NAME.get(normalize(name))

def get_local_levels_by_type(ll_type: str) -> List[dict]:
    """Retrieves the complete list of all local levels by its type."""
    return LOCAL_LEVELS_BY_TYPE.get(ll_type, [])

def get_local_levels_by_district(district_id: int) -> List[dict]:
    """Retrieves all local levels belonging to a specific district."""
    return LOCAL_LEVELS_BY_DISTRICT.get(district_id, [])
