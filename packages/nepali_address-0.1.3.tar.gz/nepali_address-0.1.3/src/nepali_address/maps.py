from .data.provinces import PROVINCES
from .data.districts import DISTRICTS
from .data.local_levels import LOCAL_LEVELS
from .utils import normalize

# Province maps
PROVINCE_BY_ID = {p['id']: p for p in PROVINCES}
PROVINCE_BY_ISO = {p['iso_code'].upper(): p for p in PROVINCES}

# District maps
DISTRICT_BY_ID = {d['id']: d for d in DISTRICTS}
DISTRICT_BY_POSTCODE = {d.get('postcode'): d for d in DISTRICTS if 'postcode' in d}
DISTRICT_BY_NAME = {normalize(d['name']): d for d in DISTRICTS}
DISTRICTS_BY_PROVINCE = {}
for d in DISTRICTS:
    p_id = d['province_id']
    if p_id not in DISTRICTS_BY_PROVINCE:
        DISTRICTS_BY_PROVINCE[p_id] = []
    DISTRICTS_BY_PROVINCE[p_id].append(d)

# Local level maps
LOCAL_LEVEL_BY_ID = {l['id']: l for l in LOCAL_LEVELS}
LOCAL_LEVEL_BY_NAME = {normalize(l['name']): l for l in LOCAL_LEVELS}
LOCAL_LEVELS_BY_DISTRICT = {}
LOCAL_LEVELS_BY_TYPE = {}

for l in LOCAL_LEVELS:
    d_id = l['district_id']
    if d_id not in LOCAL_LEVELS_BY_DISTRICT:
        LOCAL_LEVELS_BY_DISTRICT[d_id] = []
    LOCAL_LEVELS_BY_DISTRICT[d_id].append(l)
    
    l_type = l.get('type')
    if l_type:
        if l_type not in LOCAL_LEVELS_BY_TYPE:
            LOCAL_LEVELS_BY_TYPE[l_type] = []
        LOCAL_LEVELS_BY_TYPE[l_type].append(l)
