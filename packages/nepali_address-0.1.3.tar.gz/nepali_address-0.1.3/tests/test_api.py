import unittest
from nepali_address import (
    get_provinces,
    get_province_by_id,
    get_districts,
    get_district_by_name,
    get_local_levels,
    get_local_levels_by_district
)

class TestNepaliAddress(unittest.TestCase):
    def test_get_provinces(self):
        provinces = get_provinces()
        self.assertEqual(len(provinces), 7)
        self.assertEqual(provinces[0]['name'], 'Koshi Province')

    def test_get_province_by_id(self):
        province = get_province_by_id(3)
        self.assertEqual(province['name'], 'Bagmati Province')
        
    def test_get_districts(self):
        districts = get_districts()
        self.assertEqual(len(districts), 77)

    def test_get_district_by_name(self):
        district = get_district_by_name('Kathmandu')
        self.assertEqual(district['id'], 306)
        
    def test_get_local_levels(self):
        local_levels = get_local_levels()
        self.assertEqual(len(local_levels), 753)
        
    def test_get_local_levels_by_district(self):
        local_levels = get_local_levels_by_district(306)
        self.assertEqual(len(local_levels), 11) # Kathmandu has 11 local levels

if __name__ == '__main__':
    unittest.main()
