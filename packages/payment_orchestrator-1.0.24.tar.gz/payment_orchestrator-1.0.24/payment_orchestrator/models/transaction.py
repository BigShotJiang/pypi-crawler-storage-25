from dataclasses import dataclass
from typing import Optional
from datetime import datetime


@dataclass
class Transaction:
    transaction_id: str
    status: str
    amount: int
    currency: str
    cardholder_name: str
    masked_card: str
    email: str
    timestamp: str
    error_message: Optional[str] = None
    retry_count: int = 0
    
    def to_dict(self) -> dict:
        return {
            "transaction_id": self.transaction_id,
            "status": self.status,
            "amount": self.amount,
            "currency": self.currency,
            "cardholder_name": self.cardholder_name,
            "masked_card": self.masked_card,
            "email": self.email,
            "timestamp": self.timestamp,
            "error_message": self.error_message,
            "retry_count": self.retry_count
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "Transaction":
        return cls(
            transaction_id=data["transaction_id"],
            status=data["status"],
            amount=data["amount"],
            currency=data["currency"],
            cardholder_name=data["cardholder_name"],
            masked_card=data["masked_card"],
            email=data["email"],
            timestamp=data["timestamp"],
            error_message=data.get("error_message"),
            retry_count=data.get("retry_count", 0)
        )
