"""Encryption service for sensitive data (No-op for testing)."""

import logging
from typing import Optional

logger = logging.getLogger(__name__)


class PaymentEncryptor:
    """
    Payment data encryptor - No-op implementation for testing.
    
    WARNING: This does NOT encrypt data. For production use, implement proper encryption.
    """
    
    def __init__(self, kms_key_id: str, region: str = "us-east-1"):
        self.kms_key_id = kms_key_id
        self.region = region
        logger.warning("PaymentEncryptor initialized in NO-OP mode - Data is NOT encrypted!")
        logger.warning("This is for testing only. DO NOT use in production!")
    
    def encrypt(self, plaintext: str) -> Optional[str]:
        """
        Pass-through encryption (no actual encryption).
        
        WARNING: Data is NOT encrypted!
        """
        logger.debug("Encrypt called (no-op mode)")
        return plaintext  # Return plaintext without encryption
    
    def decrypt(self, encrypted_data: str) -> Optional[str]:
        """
        Pass-through decryption (no actual decryption).
        
        WARNING: Data was NOT encrypted!
        """
        logger.debug("Decrypt called (no-op mode)")
        return encrypted_data  # Return data as-is

