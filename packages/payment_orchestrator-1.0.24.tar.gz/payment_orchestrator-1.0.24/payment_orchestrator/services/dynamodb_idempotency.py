"""DynamoDB-based idempotency manager for payment processing."""

import boto3
import json
import hashlib
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, Optional
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class DynamoDBIdempotencyManager:
    """
    DynamoDB-based idempotency manager.
    
    Purpose: Prevent duplicate payments by mapping idempotency keys to transaction IDs.
    
    Table Schema (SIMPLIFIED):
    - idempotency_key (String, HASH): Primary key - SHA256 hash of payment data
    - transaction_id (String): Transaction ID that was created for this payment
    - timestamp (String): When this idempotency record was created
    - ttl (Number): TTL for automatic deletion (24 hours)
    
    Note: Status is NOT stored here - check transactions table for status!
    """
    
    def __init__(self, table_name: str, region: str = "us-east-1"):
        """
        Initialize DynamoDB idempotency manager.
        
        Args:
            table_name: DynamoDB table name for idempotency
            region: AWS region
        """
        self.table_name = table_name
        self.region = region
        self.dynamodb = boto3.resource('dynamodb', region_name=region)
        self.table = self.dynamodb.Table(table_name)
        logger.info(f"DynamoDBIdempotencyManager initialized with table: {table_name}")
    
    def generate_idempotency_key(self, payment_data: Dict[str, Any]) -> str:
        """
        Generate idempotency key from payment data.
        
        Args:
            payment_data: Payment request data
            
        Returns:
            SHA256 hash of payment data
        """
        # Create deterministic string from payment data
        key_data = {
            "card_number": payment_data.get("card_number", ""),
            "amount": payment_data.get("amount", 0),
            "currency": payment_data.get("currency", "USD"),
            "email": payment_data.get("email", ""),
            "cardholder_name": payment_data.get("cardholder_name", "")
        }
        
        key_string = json.dumps(key_data, sort_keys=True)
        return hashlib.sha256(key_string.encode()).hexdigest()
    
    def check_and_set(self, idempotency_key: str, transaction_id: str) -> Optional[str]:
        """
        Check if payment already exists and set if not.
        
        Uses DynamoDB conditional write for atomicity.
        
        Args:
            idempotency_key: Idempotency key
            transaction_id: Transaction ID to associate with this key
            
        Returns:
            Existing transaction_id if already processed, None if new
        """
        try:
            # Try to get existing item
            response = self.table.get_item(Key={'idempotency_key': idempotency_key})
            
            if 'Item' in response:
                existing_txn_id = response['Item']['transaction_id']
                logger.info(f"Idempotent request detected: {existing_txn_id}")
                return existing_txn_id
            
            # No existing item - create new record
            ttl = int((datetime.utcnow() + timedelta(hours=24)).timestamp())
            
            item = {
                'idempotency_key': idempotency_key,
                'transaction_id': transaction_id,
                'timestamp': datetime.utcnow().isoformat(),
                'ttl': ttl
            }
            
            # Conditional put - only if key doesn't exist
            self.table.put_item(
                Item=item,
                ConditionExpression='attribute_not_exists(idempotency_key)'
            )
            
            logger.info(f"New idempotency record created: {transaction_id}")
            return None
            
        except ClientError as e:
            if e.response['Error']['Code'] == 'ConditionalCheckFailedException':
                # Race condition - another request created it
                response = self.table.get_item(Key={'idempotency_key': idempotency_key})
                if 'Item' in response:
                    existing_txn_id = response['Item']['transaction_id']
                    logger.info(f"Race condition detected, returning existing: {existing_txn_id}")
                    return existing_txn_id
            logger.error(f"DynamoDB error in check_and_set: {e}")
            raise
    
    def get_transaction_id(self, idempotency_key: str) -> Optional[str]:
        """
        Get transaction ID for an idempotency key.
        
        Args:
            idempotency_key: Idempotency key
            
        Returns:
            Transaction ID if found, None otherwise
        """
        try:
            response = self.table.get_item(Key={'idempotency_key': idempotency_key})
            
            if 'Item' in response:
                return response['Item']['transaction_id']
            
            return None
            
        except ClientError as e:
            logger.error(f"DynamoDB error getting transaction ID: {e}")
            return None
