"""SNS notification service for payment events."""

import boto3
import json
import logging
from typing import Dict, Any, Optional
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)


class SNSNotifier:
    """
    SNS-based notification service for payment events.
    
    Publishes payment events to SNS topic which triggers Lambda for email sending.
    """
    
    def __init__(self, topic_arn: str, region: str = "us-east-1"):
        """
        Initialize SNS notifier.
        
        Args:
            topic_arn: SNS topic ARN
            region: AWS region
        """
        self.topic_arn = topic_arn
        self.region = region
        self.sns_client = boto3.client("sns", region_name=region)
        logger.info(f"SNSNotifier initialized with topic: {topic_arn}")
    
    def publish_payment_event(
        self,
        event_type: str,
        transaction_id: str,
        amount: int,
        currency: str,
        cardholder_name: str,
        email: str,
        message: Optional[str] = None,
        additional_data: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Publish payment event to SNS topic.
        
        Sends minimal data structure compatible with existing Lambda:
        {
            "to_email": "customer@example.com",
            "subject": "Payment Success - txn_123",
            "body": "Email body text"
        }
        
        Args:
            event_type: Type of event (SUCCESS, FAILURE, FRAUD_ALERT)
            transaction_id: Transaction ID
            amount: Payment amount in cents
            currency: Currency code
            cardholder_name: Customer name
            email: Customer email
            message: Optional message
            additional_data: Additional event data
            
        Returns:
            True if published successfully, False otherwise
        """
        try:
            # Build email subject and body based on event type
            if event_type == "SUCCESS":
                subject = f"✅ Payment Successful - {transaction_id}"
                body = self._build_success_email_body(
                    cardholder_name, transaction_id, amount, currency
                )
            elif event_type == "FAILURE":
                subject = f"❌ Payment Failed - {transaction_id}"
                error_msg = additional_data.get("error", message) if additional_data else message
                body = self._build_failure_email_body(
                    cardholder_name, transaction_id, amount, currency, error_msg or "Payment processing failed"
                )
            elif event_type == "FRAUD_ALERT":
                subject = f"⚠️ FRAUD ALERT - {transaction_id}"
                fraud_reason = additional_data.get("fraud_reason", message) if additional_data else message
                body = self._build_fraud_email_body(
                    cardholder_name, transaction_id, amount, currency, fraud_reason or "Suspicious activity detected"
                )
            else:
                subject = f"Payment Notification - {transaction_id}"
                body = f"Payment event: {event_type}\nTransaction ID: {transaction_id}"
            
            # Simple payload matching existing Lambda structure
            payload = {
                "to_email": email,
                "subject": subject,
                "body": body
            }
            
            # Publish to SNS
            response = self.sns_client.publish(
                TopicArn=self.topic_arn,
                Message=json.dumps(payload),
                Subject=subject,
                MessageAttributes={
                    "event_type": {
                        "DataType": "String",
                        "StringValue": event_type
                    },
                    "transaction_id": {
                        "DataType": "String",
                        "StringValue": transaction_id
                    }
                }
            )
            
            logger.info(f"✅ Published {event_type} event to SNS: {transaction_id}, MessageId: {response['MessageId']}")
            return True
            
        except ClientError as e:
            logger.error(f"❌ SNS publish failed: {e}")
            return False
        except Exception as e:
            logger.error(f"❌ Unexpected error publishing to SNS: {e}")
            return False
    
    def _build_success_email_body(self, cardholder_name: str, transaction_id: str, amount: int, currency: str) -> str:
        """Build success email body."""
        amount_formatted = amount / 100
        return f"""Dear {cardholder_name},

Your payment has been processed successfully!

Transaction Details:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Transaction ID: {transaction_id}
Amount: {amount_formatted:.2f} {currency}
Status: SUCCESS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Thank you for your payment!

Best regards,
Payment Team"""
    
    def _build_failure_email_body(self, cardholder_name: str, transaction_id: str, amount: int, currency: str, error_message: str) -> str:
        """Build failure email body."""
        amount_formatted = amount / 100
        return f"""Dear {cardholder_name},

Unfortunately, your payment could not be processed.

Transaction Details:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Transaction ID: {transaction_id}
Amount: {amount_formatted:.2f} {currency}
Status: FAILED
Reason: {error_message}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Please try again or contact our support team.

Best regards,
Payment Team"""
    
    def _build_fraud_email_body(self, cardholder_name: str, transaction_id: str, amount: int, currency: str, fraud_reason: str) -> str:
        """Build fraud alert email body."""
        amount_formatted = amount / 100
        return f"""⚠️ SECURITY ALERT ⚠️

Dear {cardholder_name},

We detected suspicious activity on your payment attempt and blocked it for your protection.

Transaction Details:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Transaction ID: {transaction_id}
Amount: {amount_formatted:.2f} {currency}
Status: BLOCKED
Reason: {fraud_reason}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

If this was you, please contact our support team immediately.
If this was not you, no action is needed - we've protected your account.

Best regards,
Security Team"""
    
    def notify_payment_success(
        self,
        transaction_id: str,
        amount: int,
        currency: str,
        cardholder_name: str,
        email: str
    ) -> bool:
        """
        Notify payment success via SNS.
        
        Args:
            transaction_id: Transaction ID
            amount: Payment amount in cents
            currency: Currency code
            cardholder_name: Customer name
            email: Customer email
            
        Returns:
            True if notification sent successfully
        """
        logger.info(f"📧 Sending SUCCESS notification for: {transaction_id}")
        
        return self.publish_payment_event(
            event_type="SUCCESS",
            transaction_id=transaction_id,
            amount=amount,
            currency=currency,
            cardholder_name=cardholder_name,
            email=email,
            message=f"Payment of {amount/100:.2f} {currency} processed successfully"
        )
    
    def notify_payment_failure(
        self,
        transaction_id: str,
        amount: int,
        currency: str,
        cardholder_name: str,
        email: str,
        error_message: str
    ) -> bool:
        """
        Notify payment failure via SNS.
        
        Args:
            transaction_id: Transaction ID
            amount: Payment amount in cents
            currency: Currency code
            cardholder_name: Customer name
            email: Customer email
            error_message: Failure reason
            
        Returns:
            True if notification sent successfully
        """
        logger.info(f"📧 Sending FAILURE notification for: {transaction_id}")
        
        return self.publish_payment_event(
            event_type="FAILURE",
            transaction_id=transaction_id,
            amount=amount,
            currency=currency,
            cardholder_name=cardholder_name,
            email=email,
            message=f"Payment failed: {error_message}",
            additional_data={"error": error_message}
        )
    
    def notify_fraud_alert(
        self,
        transaction_id: str,
        amount: int,
        currency: str,
        cardholder_name: str,
        email: str,
        fraud_reason: str
    ) -> bool:
        """
        Notify fraud detection via SNS.
        
        Args:
            transaction_id: Transaction ID
            amount: Payment amount in cents
            currency: Currency code
            cardholder_name: Customer name
            email: Customer email
            fraud_reason: Fraud detection reason
            
        Returns:
            True if notification sent successfully
        """
        logger.info(f"🚨 Sending FRAUD_ALERT notification for: {transaction_id}")
        
        return self.publish_payment_event(
            event_type="FRAUD_ALERT",
            transaction_id=transaction_id,
            amount=amount,
            currency=currency,
            cardholder_name=cardholder_name,
            email=email,
            message=f"Fraud detected: {fraud_reason}",
            additional_data={"fraud_reason": fraud_reason}
        )
    
    def _get_timestamp(self) -> str:
        """Get current UTC timestamp in ISO format."""
        from datetime import datetime
        return datetime.utcnow().isoformat()
