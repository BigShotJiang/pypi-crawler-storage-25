import re
import logging
from typing import Tuple, Optional

logger = logging.getLogger(__name__)


class FraudDetector:
    def __init__(self, high_amount_threshold: int = 1000000):
        self.high_amount_threshold = high_amount_threshold
        logger.info(f"FraudDetector initialized with threshold: {high_amount_threshold}")
    
    def check_fraud(self, payment_data: dict, transaction_history: list = None) -> Tuple[bool, Optional[str]]:
        amount = payment_data.get("amount", 0)
        
        if amount > self.high_amount_threshold:
            reason = f"Amount exceeds threshold: {amount} > {self.high_amount_threshold}"
            logger.warning(f"Fraud detected: {reason}")
            return True, reason
        
        logger.info("Fraud check passed")
        return False, None
