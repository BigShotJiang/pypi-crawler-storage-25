from __future__ import annotations

from semzero.repo_understanding.hypothesis_ranking import build_shadow_hypothesis_receipt
from semzero.repo_understanding.messy_sql_stress import (
    MESSY_STRESS_SCENARIOS,
    RESULT_FAIL,
    RESULT_PASS,
    build_messy_stress_summary_markdown,
    classify_messy_stress_result,
    compute_messiness_score,
)
from semzero.repo_understanding.production_ranking_adapter import (
    apply_production_ranking_adapter,
)


def _event(event_type: str, family: str, *, cte: str | None = None) -> dict:
    return {
        "event_type": event_type,
        "family_hint": family,
        "model": "int_payment_summary",
        "confidence": 0.95,
        "fidelity": 0.95,
        "source": "sql_semantic_diff",
        "location": {"clause": "SELECT", "cte": cte},
    }


def _shadow(
    *,
    outcome: str = "ranked",
    primary_family: str | None = "enum_domain_closure",
    events: tuple[dict, ...] = (),
    ranked: list[dict] | None = None,
    messiness: dict | None = None,
    circuit_breaker: bool = False,
) -> dict:
    event_types = [event["event_type"] for event in events]
    if ranked is None:
        ranked = []
        if primary_family:
            ranked.append(
                {
                    "family": primary_family,
                    "role": "primary",
                    "rank_score": 0.79,
                    "supporting_event_types": event_types,
                }
            )
    return {
        "analysis_outcome": (
            "massive_rewrite_circuit_breaker" if circuit_breaker else outcome
        ),
        "primary_family": primary_family,
        "semantic_events": list(events),
        "semantic_event_types": event_types,
        "messiness": messiness or compute_messiness_score(list(events)),
        "circuit_breaker": {"triggered": circuit_breaker},
        "summary": {
            "primary_count": sum(1 for item in ranked if item.get("role") == "primary"),
            "secondary_count": sum(1 for item in ranked if item.get("role") == "secondary"),
            "advisory_count": sum(1 for item in ranked if item.get("role") == "advisory"),
            "suppressed_count": sum(1 for item in ranked if item.get("role") == "suppressed"),
        },
        "ranked_hypotheses": ranked,
    }


def test_messy_scenario_metadata_covers_expected_stress_cases():
    assert set(MESSY_STRESS_SCENARIOS) == {
        "refactor_plus_enum_change",
        "refactor_plus_grain_change",
        "enum_plus_metric_change",
        "column_add_plus_used_remove",
        "join_key_plus_formatting",
        "multiple_true_risks_one_file",
        "messy_harmless_refactor",
        "ambiguous_heavy_rewrite",
    }
    assert MESSY_STRESS_SCENARIOS["messy_harmless_refactor"].should_be_quiet is True
    assert MESSY_STRESS_SCENARIOS["ambiguous_heavy_rewrite"].allow_circuit_breaker is True


def test_refactor_plus_enum_change_classifies_pass():
    shadow = _shadow(
        primary_family="enum_domain_closure",
        events=(_event("case_else_changed", "enum_domain_closure"),),
    )

    classification = classify_messy_stress_result(
        "refactor_plus_enum_change",
        shadow_receipt=shadow,
        production_adapter={"adapter_applied": True, "behavior": "validated_enum_primary"},
    )

    assert classification.result == RESULT_PASS
    assert classification.actual_primary == "enum_domain_closure"
    assert classification.messiness_level == "low"


def test_messy_harmless_refactor_stays_quiet():
    shadow = _shadow(
        outcome="silent_pass",
        primary_family=None,
        events=(),
        ranked=[],
        messiness={
            "score": 0.31,
            "level": "low",
            "decision": "normal_ranking",
            "signals": {"semantic_event_count": 0},
        },
    )

    classification = classify_messy_stress_result(
        "messy_harmless_refactor",
        shadow_receipt=shadow,
        production_adapter={
            "adapter_applied": True,
            "behavior": "validated_silence",
            "comment_summary": {"must_review_count": 0},
        },
    )

    assert classification.result == RESULT_PASS
    assert classification.actual_primary is None


def test_messy_harmless_refactor_fails_if_it_becomes_must_review():
    shadow = _shadow(
        primary_family="join_cardinality",
        events=(),
        ranked=[
            {
                "family": "join_cardinality",
                "role": "primary",
                "rank_score": 0.52,
                "supporting_event_types": [],
            }
        ],
    )

    classification = classify_messy_stress_result(
        "messy_harmless_refactor",
        shadow_receipt=shadow,
        production_adapter={"comment_summary": {"must_review_count": 1}},
    )

    assert classification.result == RESULT_FAIL
    assert classification.reason == "harmless messy refactor became must_review"


def test_multiple_true_risks_one_file_detects_multiple_families():
    events = (
        _event("selected_column_removed", "schema_contract_break"),
        _event("case_else_changed", "enum_domain_closure"),
        _event("group_by_key_added", "grain_contract_drift"),
    )
    shadow = _shadow(
        primary_family="schema_contract_break",
        events=events,
        ranked=[
            {
                "family": "schema_contract_break",
                "role": "primary",
                "rank_score": 0.82,
                "supporting_event_types": ["selected_column_removed"],
            },
            {
                "family": "enum_domain_closure",
                "role": "secondary",
                "rank_score": 0.79,
                "supporting_event_types": ["case_else_changed"],
            },
            {
                "family": "join_cardinality",
                "role": "advisory",
                "rank_score": 0.53,
                "supporting_event_types": ["group_by_key_added"],
            },
        ],
    )

    classification = classify_messy_stress_result(
        "multiple_true_risks_one_file",
        shadow_receipt=shadow,
        production_adapter={
            "adapter_applied": True,
            "behavior": "validated_schema_contract_break",
        },
    )

    assert classification.result == RESULT_PASS
    assert classification.messiness_level == "medium"
    assert "enum_domain_closure" in classification.visible_families
    assert "schema_contract_break" in classification.visible_families


def test_ambiguous_heavy_rewrite_triggers_broad_warning():
    events = [
        _event("selected_column_removed", "schema_contract_break"),
        _event("selected_column_added", "schema_contract_break"),
        _event("selected_expression_changed", "schema_contract_break"),
        _event("case_else_changed", "enum_domain_closure"),
        _event("case_branch_removed", "enum_domain_closure"),
        _event("join_added", "join_relationship_drift"),
        _event("join_key_changed", "join_relationship_drift"),
        _event("group_by_key_added", "grain_contract_drift"),
        _event("where_predicate_changed", "filter_population_drift"),
    ]
    shadow = build_shadow_hypothesis_receipt(
        {"receipt_kind": "dbt_assumption_gate_v1_25", "findings": []},
        events,
        rewrite_stats={"line_change_ratio": 0.43, "joins_changed": 2},
    )
    adapted = apply_production_ranking_adapter(
        production_receipt={
            "receipt_kind": "dbt_assumption_gate_v1_25",
            "verdict": "REQUIRE_REVIEW",
            "summary": {},
        },
        production_comment="old precise comment",
        shadow_receipt=shadow,
    )

    classification = classify_messy_stress_result(
        "ambiguous_heavy_rewrite",
        shadow_receipt=shadow,
        production_adapter=adapted["artifact"],
    )

    assert shadow["analysis_outcome"] == "massive_rewrite_circuit_breaker"
    assert shadow["messiness"]["level"] == "high"
    assert adapted["artifact"]["behavior"] == "massive_rewrite_broad_warning"
    assert classification.result == RESULT_PASS


def test_messiness_score_is_deterministic():
    events = [
        _event("selected_column_removed", "schema_contract_break"),
        _event("case_else_changed", "enum_domain_closure"),
        _event("group_by_key_added", "grain_contract_drift"),
    ]

    first = compute_messiness_score(events, rewrite_stats={"line_change_ratio": 0.18})
    second = compute_messiness_score(events, rewrite_stats={"line_change_ratio": 0.18})

    assert first == second
    assert first["level"] == "medium"
    assert first["signals"]["family_count"] == 3


def test_metric_and_filter_gaps_do_not_get_promoted_to_production():
    shadow = _shadow(
        primary_family="metric_semantics_drift",
        events=(_event("aggregate_argument_changed", "metric_semantics_drift"),),
    )

    classification = classify_messy_stress_result(
        "enum_plus_metric_change",
        shadow_receipt=shadow,
        production_adapter={
            "adapter_applied": True,
            "behavior": "validated_metric_primary",
            "primary": {"family": "metric_semantics_drift"},
            "comment_summary": {"must_review_count": 1},
        },
    )

    assert classification.result == RESULT_FAIL
    assert classification.reason == "unvalidated metric/filter family leaked into production"


def test_messy_stress_markdown_summary_renders_rows():
    shadow = _shadow(
        primary_family="enum_domain_closure",
        events=(_event("case_else_changed", "enum_domain_closure"),),
    )
    classification = classify_messy_stress_result(
        "refactor_plus_enum_change",
        shadow_receipt=shadow,
    )

    markdown = build_messy_stress_summary_markdown([classification])

    assert "refactor_plus_enum_change" in markdown
    assert "enum_domain_closure" in markdown
    assert RESULT_PASS in markdown
