from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

from click.testing import CliRunner

from semzero.cli import cli
from semzero.repo_understanding import local_check


BASE_SQL = """WITH payment_summary AS (
    SELECT
        customer_id,
        COUNT(payment_id) AS total_payments,
        SUM(payment_value) AS total_paid,
        CASE
            WHEN SUM(CASE WHEN payment_status = 'completed' THEN 1 ELSE 0 END) > 0
            THEN 'paid'
            ELSE 'pending'
        END AS final_payment_status
    FROM {{ ref('stg_payments') }}
    GROUP BY customer_id
)
SELECT * FROM payment_summary
"""


def _git(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=repo, text=True).strip()


def _init_dbt_repo(tmp_path: Path) -> Path:
    repo = tmp_path / "repo"
    model = repo / "models" / "intermediate" / "int_payment_summary.sql"
    model.parent.mkdir(parents=True)
    model.write_text(BASE_SQL, encoding="utf-8")
    (repo / "dbt_project.yml").write_text(
        "name: semzero_blind_test\nversion: '1.0'\nprofile: semzero_blind_test\n",
        encoding="utf-8",
    )
    _git(tmp_path, "init", "repo")
    _git(repo, "checkout", "-b", "main")
    _git(repo, "config", "user.email", "semzero@example.com")
    _git(repo, "config", "user.name", "SemZero Test")
    _git(repo, "add", ".")
    _git(repo, "commit", "-m", "base")
    return repo


def _disable_dbt(monkeypatch):
    original = local_check.shutil.which

    def fake_which(name):
        if name == "dbt":
            return None
        return original(name)

    monkeypatch.setattr(local_check.shutil, "which", fake_which)


def _artifact_dir_from_output(repo: Path, output: str) -> Path:
    match = re.search(r"Artifacts: (.+?)/?$", output, flags=re.M)
    assert match, output
    raw = match.group(1).strip().rstrip("/")
    path = Path(raw)
    return path if path.is_absolute() else repo / path


def test_check_detects_dbt_project_changed_files_and_writes_artifacts(tmp_path, monkeypatch):
    repo = _init_dbt_repo(tmp_path)
    _disable_dbt(monkeypatch)
    assert not (repo / ".semzero").exists()
    model = repo / "models" / "intermediate" / "int_payment_summary.sql"
    model.write_text(BASE_SQL.replace("ELSE 'pending'", "ELSE 'unresolved'"), encoding="utf-8")
    monkeypatch.chdir(repo)

    result = CliRunner().invoke(cli, ["check"])

    assert result.exit_code == 1
    assert "dbt project: detected" in result.output
    assert "Changed files: 1" in result.output
    assert "Result: REVIEW RECOMMENDED" in result.output
    artifact_dir = _artifact_dir_from_output(repo, result.output)
    assert artifact_dir.exists()
    assert (artifact_dir / "receipt.json").exists()
    assert (artifact_dir / "comment.md").exists()
    assert (artifact_dir / "production_ranking_adapter.json").exists()
    assert (artifact_dir / "semzero_check_summary.json").exists()
    assert "models/intermediate/int_payment_summary.sql" in (
        artifact_dir / "changed_files.txt"
    ).read_text(encoding="utf-8")


def test_check_review_output_for_enum_fixture_includes_recommended_command(tmp_path, monkeypatch):
    repo = _init_dbt_repo(tmp_path)
    _disable_dbt(monkeypatch)
    model = repo / "models" / "intermediate" / "int_payment_summary.sql"
    model.write_text(BASE_SQL.replace("ELSE 'pending'", "ELSE 'unresolved'"), encoding="utf-8")
    monkeypatch.chdir(repo)

    result = CliRunner().invoke(cli, ["check"])

    assert result.exit_code == 1
    assert "Primary risk: Enum Domain Closure" in result.output
    assert "CASE fallback changed from 'pending' to 'unresolved'." in result.output
    assert "Recommended next check:" in result.output
    assert "dbt build --select int_payment_summary+" in result.output
    assert "dbt compile: unavailable" in result.output
    assert "Analysis fidelity: medium" in result.output
    assert "Note: dbt compile unavailable; used static SQL fallback." in result.output


def test_check_quiet_output_for_format_only_fixture(tmp_path, monkeypatch):
    repo = _init_dbt_repo(tmp_path)
    _disable_dbt(monkeypatch)
    model = repo / "models" / "intermediate" / "int_payment_summary.sql"
    model.write_text("-- harmless local note\n" + BASE_SQL, encoding="utf-8")
    monkeypatch.chdir(repo)

    result = CliRunner().invoke(cli, ["check"])

    assert result.exit_code == 0
    assert "Result: QUIET" in result.output
    assert "No review-worthy semantic assumption change detected." in result.output
    artifact_dir = _artifact_dir_from_output(repo, result.output)
    summary = json.loads((artifact_dir / "semzero_check_summary.json").read_text())
    assert summary["result"] == "QUIET"
    assert summary["exit_code"] == 0


def test_check_base_override_is_reported(tmp_path, monkeypatch):
    repo = _init_dbt_repo(tmp_path)
    _disable_dbt(monkeypatch)
    model = repo / "models" / "intermediate" / "int_payment_summary.sql"
    model.write_text(BASE_SQL.replace("ELSE 'pending'", "ELSE 'unresolved'"), encoding="utf-8")
    monkeypatch.chdir(repo)

    result = CliRunner().invoke(cli, ["check", "--base", "main"])

    assert result.exit_code == 1
    assert "Base: main provided" in result.output


def test_check_exit_code_2_when_not_in_git_repo(tmp_path, monkeypatch):
    (tmp_path / "dbt_project.yml").write_text("name: nope\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    result = CliRunner().invoke(cli, ["check"])

    assert result.exit_code == 2
    assert "SemZero could not find a git repository." in result.output


def test_check_exit_code_2_when_dbt_project_missing(tmp_path, monkeypatch):
    repo = tmp_path / "repo"
    repo.mkdir()
    _git(tmp_path, "init", "repo")
    monkeypatch.chdir(repo)

    result = CliRunner().invoke(cli, ["check"])

    assert result.exit_code == 2
    assert "No dbt_project.yml found." in result.output


def test_doctor_reports_useful_environment_checks(tmp_path, monkeypatch):
    repo = _init_dbt_repo(tmp_path)
    _disable_dbt(monkeypatch)
    monkeypatch.chdir(repo)

    result = CliRunner().invoke(cli, ["doctor"])

    assert result.exit_code == 0
    assert "SemZero Doctor" in result.output
    assert "Git repo: OK" in result.output
    assert "dbt project: OK" in result.output
    assert "dbt command: not found" in result.output
    assert "SemZero can still run using static SQL fallback." in result.output


def test_legacy_check_receipt_mode_still_works(tmp_path):
    receipt = tmp_path / "receipt.json"
    receipt.write_text(
        json.dumps(
            {
                "verdict": "BLOCK",
                "assessments": [],
                "blocked_by": ["domain enum drift"],
                "review_reasons": [],
                "evaluated_at": "2026-04-05T00:00:00+00:00",
            }
        ),
        encoding="utf-8",
    )

    result = CliRunner().invoke(cli, ["check", "--receipt", str(receipt)])

    assert result.exit_code == 0
    assert "Verdict:" in result.output
    assert "Evidence source:" in result.output
