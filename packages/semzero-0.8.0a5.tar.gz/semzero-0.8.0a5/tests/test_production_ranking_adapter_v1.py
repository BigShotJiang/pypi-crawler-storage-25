from __future__ import annotations

import json

from semzero.repo_understanding.production_ranking_adapter import (
    PRODUCTION_RANKING_ADAPTER_KIND,
    apply_production_ranking_adapter,
)


def _receipt():
    return {
        "receipt_kind": "dbt_assumption_gate_v1_25",
        "verdict": "REQUIRE_REVIEW",
        "mode": "shadow_advisory",
        "summary": {
            "changed_resource_count": 1,
            "blast_radius_resource_count": 1,
        },
        "findings": [],
    }


def _shadow(
    *,
    outcome="ranked",
    primary_family="enum_domain_closure",
    primary_events=("case_else_changed",),
    rank_score=0.79,
    semantic_events=None,
    circuit_breaker=None,
    primary_extra=None,
):
    primary_extra = primary_extra or {}
    ranked = []
    if primary_family:
        ranked.append(
            {
                "family": primary_family,
                "role": "primary",
                "rank_score": rank_score,
                "stable_id": f"AG-{primary_family.upper()}-001",
                "supporting_event_types": list(primary_events),
                "why_it_matters": "A validated hidden assumption changed.",
                "recommended_check": "Review the changed assumption before merge.",
                **primary_extra,
            }
        )
    return {
        "kind": "semzero_shadow_hypothesis_receipt_v1",
        "analysis_outcome": outcome,
        "primary_family": primary_family,
        "max_rank_score": rank_score if primary_family else 0.0,
        "semantic_event_types": list(semantic_events if semantic_events is not None else primary_events),
        "circuit_breaker": circuit_breaker or {"triggered": False},
        "ranked_hypotheses": ranked,
    }


def test_adapter_promotes_validated_enum_primary(tmp_path):
    result = apply_production_ranking_adapter(
        production_receipt=_receipt(),
        production_comment="old enum comment",
        shadow_receipt=_shadow(),
        output_dir=tmp_path,
    )

    artifact = result["artifact"]
    assert artifact["kind"] == PRODUCTION_RANKING_ADAPTER_KIND
    assert artifact["adapter_applied"] is True
    assert artifact["behavior"] == "validated_enum_primary"
    assert "Primary: `enum_domain_closure`" in result["comment"]
    assert "Review-required: `1`" in result["comment"]
    assert json.loads((tmp_path / "production_ranking_adapter.json").read_text()) == artifact


def test_adapter_promotes_structural_join_or_grain_primary():
    result = apply_production_ranking_adapter(
        production_receipt=_receipt(),
        production_comment="old structural comment",
        shadow_receipt=_shadow(
            primary_family="join_cardinality",
            primary_events=("group_by_key_added", "group_by_key_removed"),
            semantic_events=("group_by_key_added", "group_by_key_removed"),
        ),
    )

    assert result["artifact"]["adapter_applied"] is True
    assert result["artifact"]["behavior"] == "validated_structural_primary"
    assert "group_by_key_added" in result["comment"]


def test_adapter_promotes_schema_break_only_with_downstream_reference_evidence():
    result = apply_production_ranking_adapter(
        production_receipt=_receipt(),
        production_comment="old schema comment",
        shadow_receipt=_shadow(
            primary_family="schema_contract_break",
            primary_events=("selected_column_removed",),
            semantic_events=("selected_column_removed",),
            primary_extra={
                "trigger_evidence": [
                    "selected_column_removed: total_paid",
                    "mart_order_payments references total_paid",
                ],
                "blast_radius": [{"name": "mart_order_payments"}],
            },
        ),
    )

    assert result["artifact"]["adapter_applied"] is True
    assert result["artifact"]["behavior"] == "validated_schema_contract_break"
    assert "Schema Contract Break" in result["comment"]


def test_adapter_does_not_promote_schema_break_without_downstream_evidence():
    result = apply_production_ranking_adapter(
        production_receipt=_receipt(),
        production_comment="old schema comment",
        shadow_receipt=_shadow(
            primary_family="schema_contract_break",
            primary_events=("selected_column_removed",),
            semantic_events=("selected_column_removed",),
        ),
    )

    assert result["artifact"]["adapter_applied"] is False
    assert result["artifact"]["old_path_fallback"] is True
    assert result["comment"] == "old schema comment"


def test_adapter_promotes_validated_format_or_unused_column_silence():
    result = apply_production_ranking_adapter(
        production_receipt=_receipt(),
        production_comment="old noisy comment",
        shadow_receipt=_shadow(
            outcome="silent_pass",
            primary_family=None,
            primary_events=(),
            semantic_events=("selected_column_removed",),
        ),
    )

    assert result["artifact"]["adapter_applied"] is True
    assert result["artifact"]["behavior"] == "validated_silence"
    assert "Verdict: `ALLOW`" in result["comment"]
    assert "Review-required: `0`" in result["comment"]


def test_adapter_keeps_metric_and_filter_shadow_only():
    metric = apply_production_ranking_adapter(
        production_receipt=_receipt(),
        production_comment="old metric comment",
        shadow_receipt=_shadow(
            primary_family="metric_semantics_drift",
            primary_events=("aggregate_argument_changed",),
            semantic_events=("aggregate_argument_changed",),
        ),
    )
    filter_result = apply_production_ranking_adapter(
        production_receipt=_receipt(),
        production_comment="old filter comment",
        shadow_receipt=_shadow(
            outcome="silent_pass",
            primary_family=None,
            primary_events=(),
            semantic_events=("where_predicate_changed",),
        ),
    )

    assert metric["artifact"]["adapter_applied"] is False
    assert metric["comment"] == "old metric comment"
    assert filter_result["artifact"]["adapter_applied"] is False
    assert filter_result["comment"] == "old filter comment"


def test_adapter_promotes_massive_rewrite_broad_warning():
    result = apply_production_ranking_adapter(
        production_receipt=_receipt(),
        production_comment="old granular comment",
        shadow_receipt=_shadow(
            outcome="massive_rewrite_circuit_breaker",
            primary_family=None,
            semantic_events=("join_added", "selected_column_removed"),
            circuit_breaker={
                "triggered": True,
                "reason": "ast_node_change_ratio_above_40_percent",
                "recommended_action": "run full downstream dbt build/test",
                "unranked_assumption_families": [
                    {"family": "join_cardinality"},
                    {"family": "schema_contract_break"},
                ],
            },
        ),
    )

    assert result["artifact"]["adapter_applied"] is True
    assert result["artifact"]["behavior"] == "massive_rewrite_broad_warning"
    assert "Massive structural rewrite detected" in result["comment"]
    assert "join_cardinality" in result["comment"]
