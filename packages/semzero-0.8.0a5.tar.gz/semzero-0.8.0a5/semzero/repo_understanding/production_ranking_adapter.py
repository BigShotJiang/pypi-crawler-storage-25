from __future__ import annotations

import json
from pathlib import Path
from typing import Any


PRODUCTION_RANKING_ADAPTER_KIND = "semzero_production_ranking_adapter_v1"

VALIDATED_PRIMARY_FAMILIES = {
    "enum_domain_closure",
    "grain_contract_drift",
    "join_cardinality",
    "join_relationship_drift",
    "schema_contract_break",
}

UNVALIDATED_FAMILIES = {
    "metric_semantics_drift",
    "metric_formula_changed",
    "filter_population_drift",
    "enum_population_drift",
    "incremental_filter",
}

ENUM_EVENTS = {
    "case_else_changed",
    "case_branch_added",
    "case_branch_removed",
    "in_list_added_value",
    "in_list_removed_value",
}

STRUCTURAL_EVENTS = {
    "group_by_key_added",
    "group_by_key_removed",
    "group_by_key_replaced",
    "distinct_added",
    "distinct_removed",
    "join_key_changed",
    "join_target_changed",
    "join_type_changed",
    "join_predicate_weakened",
}

SCHEMA_EVENTS = {"selected_column_removed"}
VALIDATED_SILENCE_EVENTS = set() | SCHEMA_EVENTS


def apply_production_ranking_adapter(
    *,
    production_receipt: dict[str, Any],
    production_comment: str,
    shadow_receipt: dict[str, Any],
    output_dir: str | Path | None = None,
) -> dict[str, Any]:
    """Selectively replace the production PR comment with validated shadow ranking.

    The adapter is intentionally allowlist-only. Unvalidated families keep the
    existing stable production comment path while the shadow artifacts continue
    to collect evidence.
    """
    decision = _adapter_decision(production_receipt, shadow_receipt)
    comment = (
        _render_adapted_comment(production_receipt, shadow_receipt, decision)
        if decision["adapter_applied"]
        else production_comment
    )
    artifact = {
        "kind": PRODUCTION_RANKING_ADAPTER_KIND,
        **decision,
        "source_receipt_kind": production_receipt.get("receipt_kind"),
        "source_verdict": production_receipt.get("verdict"),
        "shadow_outcome": shadow_receipt.get("analysis_outcome"),
        "shadow_primary_family": shadow_receipt.get("primary_family"),
        "semantic_events": list(shadow_receipt.get("semantic_event_types") or []),
        "messiness": shadow_receipt.get("messiness") or {},
        "validated_primary_families": sorted(VALIDATED_PRIMARY_FAMILIES),
        "unvalidated_families_kept_shadow_only": sorted(UNVALIDATED_FAMILIES),
        "comment_changed": comment != production_comment,
        "comment_summary": _comment_summary(decision, shadow_receipt),
    }
    if output_dir:
        root = Path(output_dir)
        root.mkdir(parents=True, exist_ok=True)
        (root / "production_ranking_adapter.json").write_text(
            json.dumps(artifact, indent=2, sort_keys=True),
            encoding="utf-8",
        )
    return {"comment": comment, "artifact": artifact}


def _adapter_decision(
    production_receipt: dict[str, Any], shadow_receipt: dict[str, Any]
) -> dict[str, Any]:
    ranked = list(shadow_receipt.get("ranked_hypotheses") or [])
    primary = _primary_hypothesis(shadow_receipt)
    events = set(str(x) for x in (shadow_receipt.get("semantic_event_types") or []))
    circuit = shadow_receipt.get("circuit_breaker") or {}
    outcome = str(shadow_receipt.get("analysis_outcome") or "")

    if circuit.get("triggered"):
        return _decision(
            applied=True,
            behavior="massive_rewrite_broad_warning",
            reason="massive rewrite circuit breaker is validated for production broad warning",
            primary=primary,
            ranked=ranked,
            events=events,
        )

    if outcome == "silent_pass":
        if events.issubset(VALIDATED_SILENCE_EVENTS):
            return _decision(
                applied=True,
                behavior="validated_silence",
                reason="shadow ranking found no validated reviewer-actionable assumption",
                primary=primary,
                ranked=ranked,
                events=events,
            )
        return _decision(
            applied=False,
            behavior="old_path_fallback",
            reason="silent shadow result involved unvalidated event types",
            primary=primary,
            ranked=ranked,
            events=events,
        )

    if not primary:
        return _decision(
            applied=False,
            behavior="old_path_fallback",
            reason="shadow ranking produced no primary hypothesis",
            primary=primary,
            ranked=ranked,
            events=events,
        )

    family = str(primary.get("family") or "")
    primary_events = set(str(x) for x in (primary.get("supporting_event_types") or []))
    if family in UNVALIDATED_FAMILIES:
        return _decision(
            applied=False,
            behavior="old_path_fallback",
            reason=f"{family} is still shadow-only",
            primary=primary,
            ranked=ranked,
            events=events,
        )
    if family == "enum_domain_closure" and primary_events.intersection(ENUM_EVENTS):
        return _decision(
            applied=True,
            behavior="validated_enum_primary",
            reason="enum primary is backed by validated semantic enum event",
            primary=primary,
            ranked=ranked,
            events=events,
        )
    if family in {"grain_contract_drift", "join_cardinality", "join_relationship_drift"} and primary_events.intersection(STRUCTURAL_EVENTS):
        return _decision(
            applied=True,
            behavior="validated_structural_primary",
            reason="grain/join structural primary is backed by validated structural event",
            primary=primary,
            ranked=ranked,
            events=events,
        )
    if family == "schema_contract_break" and _validated_schema_break(primary):
        return _decision(
            applied=True,
            behavior="validated_schema_contract_break",
            reason="schema break is backed by selected_column_removed and downstream reference evidence",
            primary=primary,
            ranked=ranked,
            events=events,
        )
    if family in VALIDATED_PRIMARY_FAMILIES:
        return _decision(
            applied=False,
            behavior="old_path_fallback",
            reason=f"{family} lacked required validated semantic evidence",
            primary=primary,
            ranked=ranked,
            events=events,
        )
    return _decision(
        applied=False,
        behavior="old_path_fallback",
        reason=f"{family or 'unknown'} is not allowlisted for production promotion",
        primary=primary,
        ranked=ranked,
        events=events,
    )


def _decision(
    *,
    applied: bool,
    behavior: str,
    reason: str,
    primary: dict[str, Any] | None,
    ranked: list[dict[str, Any]],
    events: set[str],
) -> dict[str, Any]:
    return {
        "adapter_applied": applied,
        "behavior": behavior,
        "reason": reason,
        "old_path_fallback": not applied,
        "primary": _primary_summary(primary),
        "role_counts": {
            "primary": _count_role(ranked, "primary"),
            "secondary": _count_role(ranked, "secondary"),
            "advisory": _count_role(ranked, "advisory"),
            "suppressed": _count_role(ranked, "suppressed"),
        },
        "blocked_unvalidated_events": sorted(events.intersection(_unvalidated_event_types())),
    }


def _render_adapted_comment(
    production_receipt: dict[str, Any],
    shadow_receipt: dict[str, Any],
    decision: dict[str, Any],
) -> str:
    mode = production_receipt.get("mode") or "shadow"
    summary = production_receipt.get("summary") or {}
    behavior = decision["behavior"]
    if behavior == "massive_rewrite_broad_warning":
        return _render_massive_rewrite_comment(shadow_receipt, mode, summary)
    if behavior == "validated_silence":
        return _render_silent_comment(shadow_receipt, mode, summary)
    return _render_ranked_comment(shadow_receipt, mode, summary, behavior)


def _render_ranked_comment(
    shadow_receipt: dict[str, Any],
    mode: str,
    summary: dict[str, Any],
    behavior: str,
) -> str:
    ranked = list(shadow_receipt.get("ranked_hypotheses") or [])
    primary = _primary_hypothesis(shadow_receipt) or {}
    advisory = [item for item in ranked if item.get("role") in {"secondary", "advisory"}]
    family = str(primary.get("family") or "unknown")
    score = float(primary.get("rank_score") or 0.0)
    events = list(primary.get("supporting_event_types") or [])
    lines = [
        "<!-- semzero-assumption-gate -->",
        "## SemZero Assumption Gate",
        "",
        "**1 review-worthy assumption may break downstream dbt data. Review before merging.**",
        "",
        f"Verdict: `REQUIRE_REVIEW` · Mode: `{mode}` · Review-required: `1` · Advisory: `{len(advisory)}`",
        f"Changed dbt resource(s): `{summary.get('changed_resource_count', 0)}` · Affected downstream resource(s): `{summary.get('blast_radius_resource_count', 0)}`",
        f"Production ranking: `{behavior}` · Primary: `{family}` · Score: `{score:.4f}`",
        "",
        "### Review before merge",
        "",
        f"1. **{_title_family(family)}**",
        f"   - **What changed:** {_event_list(events)}",
        f"   - **Why it matters:** {_why_it_matters(primary)}",
        f"   - **Recommended check:** {_recommended_check(primary)}",
    ]
    if primary.get("id") or primary.get("stable_id"):
        lines.append(f"   - **Finding ID:** `{primary.get('stable_id') or primary.get('id')}`")
    messiness = shadow_receipt.get("messiness") or {}
    if messiness.get("level") == "medium":
        other_changes = [
            str(event)
            for event in (shadow_receipt.get("semantic_event_types") or [])
            if str(event) not in set(events)
        ]
        unvalidated_changes = [
            event for event in other_changes if event in _unvalidated_event_types()
        ]
        validated_changes = [
            event for event in other_changes if event not in _unvalidated_event_types()
        ]
        lines += [
            "",
            "### Other semantic changes detected",
            "",
            "SemZero ranked the dominant assumption above, but this PR contains multiple semantic change signals.",
        ]
        for event in validated_changes[:6]:
            lines.append(f"- `{event}`")
        if unvalidated_changes:
            lines.append(
                f"- `{len(unvalidated_changes)}` shadow-only metric/filter signal(s) kept out of production ranking"
            )
    if advisory:
        lines += ["", "### Useful advisory", ""]
        for item in advisory[:3]:
            lines.append(
                f"- **{_title_family(str(item.get('family') or 'unknown'))}** — `{item.get('role')}` · score `{float(item.get('rank_score') or 0.0):.4f}`"
            )
    lines += [
        "",
        "_This production comment is controlled by the validated ranking adapter. Full evidence remains in `receipt.json`, `shadow_hypothesis_receipt.json`, and `production_ranking_adapter.json`._",
    ]
    return "\n".join(lines)


def _render_silent_comment(
    shadow_receipt: dict[str, Any], mode: str, summary: dict[str, Any]
) -> str:
    return "\n".join(
        [
            "<!-- semzero-assumption-gate -->",
            "## SemZero Assumption Gate",
            "",
            "**No reviewer-actionable assumption drift found in the changed dbt scope.**",
            "",
            f"Verdict: `ALLOW` · Mode: `{mode}` · Review-required: `0` · Advisory: `0`",
            f"Changed dbt resource(s): `{summary.get('changed_resource_count', 0)}` · Affected downstream resource(s): `{summary.get('blast_radius_resource_count', 0)}`",
            f"Production ranking: `validated_silence` · Max score: `{float(shadow_receipt.get('max_rank_score') or 0.0):.4f}`",
            "",
            "SemZero stayed quiet because no validated semantic ranking hypothesis crossed the activation threshold.",
            "",
            "_Full evidence remains in `receipt.json`, `shadow_hypothesis_receipt.json`, and `production_ranking_adapter.json`._",
        ]
    )


def _render_massive_rewrite_comment(
    shadow_receipt: dict[str, Any], mode: str, summary: dict[str, Any]
) -> str:
    cb = shadow_receipt.get("circuit_breaker") or {}
    families = [
        str(item.get("family") or "")
        for item in (cb.get("unranked_assumption_families") or [])
        if item.get("family")
    ]
    lines = [
        "<!-- semzero-assumption-gate -->",
        "## SemZero Assumption Gate",
        "",
        "**Massive structural rewrite detected. SemZero suppressed granular assumption guesses.**",
        "",
        f"Verdict: `REQUIRE_REVIEW` · Mode: `{mode}` · Review-required: `1` · Advisory: `0`",
        f"Changed dbt resource(s): `{summary.get('changed_resource_count', 0)}` · Affected downstream resource(s): `{summary.get('blast_radius_resource_count', 0)}`",
        "Production ranking: `massive_rewrite_broad_warning`",
        "",
        "### Review before merge",
        "",
        f"- **Reason:** `{cb.get('reason') or 'massive_rewrite_circuit_breaker'}`",
        f"- **Recommended action:** {cb.get('recommended_action') or 'run full downstream dbt build/test'}",
        "- **Why it matters:** The SQL shape changed too broadly for precise assumption attribution to be trustworthy.",
    ]
    messiness = shadow_receipt.get("messiness") or {}
    if messiness:
        lines.append(
            f"- **Messiness:** `{messiness.get('level')}` · score `{float(messiness.get('score') or 0.0):.4f}`"
        )
    if families:
        lines += ["", "Assumption families present in this rewrite, unranked:", ""]
        for family in families[:8]:
            lines.append(f"- `{family}`")
    lines += [
        "",
        "_SemZero is intentionally refusing fake precision here. Full evidence remains in `receipt.json`, `shadow_hypothesis_receipt.json`, and `production_ranking_adapter.json`._",
    ]
    return "\n".join(lines)


def _primary_hypothesis(shadow_receipt: dict[str, Any]) -> dict[str, Any] | None:
    for item in shadow_receipt.get("ranked_hypotheses") or []:
        if item.get("role") == "primary":
            return item
    return None


def _validated_schema_break(primary: dict[str, Any]) -> bool:
    events = set(str(x) for x in (primary.get("supporting_event_types") or []))
    if not events.intersection(SCHEMA_EVENTS):
        return False
    if primary.get("blast_radius"):
        return True
    trigger_text = " ".join(str(x) for x in (primary.get("trigger_evidence") or [])).lower()
    return "references" in trigger_text or "downstream" in trigger_text


def _why_it_matters(primary: dict[str, Any]) -> str:
    return (
        str(primary.get("why_it_matters") or "").strip()
        or _default_why(str(primary.get("family") or ""))
    )


def _recommended_check(primary: dict[str, Any]) -> str:
    return (
        str(primary.get("recommended_check") or "").strip()
        or _default_check(str(primary.get("family") or ""))
    )


def _default_why(family: str) -> str:
    if family == "enum_domain_closure":
        return "A status or enum mapping changed, so downstream filters or mappings may no longer mean the same thing."
    if family in {"grain_contract_drift", "join_cardinality", "join_relationship_drift"}:
        return "The row relationship or grain changed, so downstream joins or aggregations may produce different results while SQL still compiles."
    if family == "schema_contract_break":
        return "A model output contract changed while downstream SQL may still depend on it."
    return "A validated semantic change may affect downstream assumptions."


def _default_check(family: str) -> str:
    if family == "enum_domain_closure":
        return "Verify downstream accepted values, filters, and mappings for the changed enum value."
    if family in {"grain_contract_drift", "join_cardinality", "join_relationship_drift"}:
        return "Verify join keys, row grain, and downstream unique/relationship tests before merge."
    if family == "schema_contract_break":
        return "Update downstream references or restore the removed output column before merge."
    return "Review the changed assumption and run the affected downstream dbt build/test scope."


def _event_list(events: list[str]) -> str:
    if not events:
        return "`semantic event evidence unavailable`"
    return ", ".join(f"`{event}`" for event in events[:6])


def _title_family(family: str) -> str:
    return family.replace("_", " ").title()


def _primary_summary(primary: dict[str, Any] | None) -> dict[str, Any] | None:
    if not primary:
        return None
    return {
        "family": primary.get("family"),
        "role": primary.get("role"),
        "rank_score": primary.get("rank_score"),
        "supporting_event_types": list(primary.get("supporting_event_types") or []),
        "stable_id": primary.get("stable_id") or primary.get("id"),
    }


def _comment_summary(
    decision: dict[str, Any], shadow_receipt: dict[str, Any]
) -> dict[str, Any]:
    if decision["behavior"] == "validated_silence":
        return {"verdict": "ALLOW", "must_review_count": 0, "advisory_count": 0}
    if decision["behavior"] == "massive_rewrite_broad_warning":
        return {"verdict": "REQUIRE_REVIEW", "must_review_count": 1, "advisory_count": 0}
    roles = decision["role_counts"]
    return {
        "verdict": "REQUIRE_REVIEW" if decision["adapter_applied"] else shadow_receipt.get("source_verdict"),
        "must_review_count": 1 if decision["adapter_applied"] else roles.get("primary", 0),
        "advisory_count": roles.get("secondary", 0) + roles.get("advisory", 0),
    }


def _count_role(ranked: list[dict[str, Any]], role: str) -> int:
    return sum(1 for item in ranked if item.get("role") == role)


def _unvalidated_event_types() -> set[str]:
    return {
        "aggregate_argument_changed",
        "arithmetic_expression_changed",
        "where_predicate_changed",
        "status_population_changed",
        "filter_predicate_changed",
    }
