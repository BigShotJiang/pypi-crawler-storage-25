from __future__ import annotations

import json
import hashlib
import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from semzero.repo_understanding.hypothesis_ranking import (
    build_ranking_comparison,
    build_shadow_hypothesis_receipt,
    estimate_rewrite_stats,
    render_shadow_comment,
)
from semzero.repo_understanding.production_ranking_adapter import (
    apply_production_ranking_adapter,
)
from semzero.repo_understanding.sql_semantic_diff import (
    SemanticDiffEvent,
    extract_sql_semantic_events,
)


CHECK_SUMMARY_KIND = "semzero_check_summary_v1"


@dataclass(frozen=True, slots=True)
class GitBase:
    ref: str
    source: str
    fallback_worktree_only: bool = False


@dataclass(frozen=True, slots=True)
class CompileResult:
    status: str
    reason: str
    log: str = ""


class SemZeroCheckError(RuntimeError):
    def __init__(self, message: str, *, exit_code: int = 2) -> None:
        super().__init__(message)
        self.exit_code = exit_code


def run_semzero_check(
    *,
    start_dir: str | Path = ".",
    base: str = "",
    output_dir: str | Path | None = None,
    run_id: str | None = None,
) -> dict[str, Any]:
    repo_root = detect_git_root(start_dir)
    if not repo_root:
        raise SemZeroCheckError(
            "SemZero could not find a git repository.\nRun this inside a dbt project tracked by git."
        )
    dbt_project = repo_root / "dbt_project.yml"
    if not dbt_project.exists():
        raise SemZeroCheckError(
            "No dbt_project.yml found.\nSemZero currently supports dbt SQL projects."
        )

    run_id = run_id or datetime.now().strftime("%Y-%m-%d-%H%M%S")
    artifact_dir = Path(output_dir) if output_dir else repo_root / ".semzero" / "runs" / run_id
    artifact_dir.mkdir(parents=True, exist_ok=True)

    git_base = infer_git_base(repo_root, base=base)
    changed_files = detect_changed_files(repo_root, git_base)
    dbt_like = [path for path in changed_files if _is_dbt_like(path)]
    diff_text = build_changed_diff(repo_root, git_base, dbt_like)
    (artifact_dir / "changed_files.txt").write_text("\n".join(dbt_like), encoding="utf-8")
    (artifact_dir / "changed.diff").write_text(diff_text, encoding="utf-8")

    compile_result = try_dbt_compile(repo_root)
    (artifact_dir / "dbt_compile.log").write_text(compile_result.log, encoding="utf-8")
    _write_json(
        artifact_dir / "dbt_compile.status.json",
        {"status": compile_result.status, "reason": compile_result.reason},
    )

    manifest_path = repo_root / "target" / "manifest.json"
    repo_snapshot = build_optional_repo_snapshot(
        repo_root=repo_root,
        manifest_path=manifest_path,
        output_path=artifact_dir / "repo_snapshot.json",
    )
    analysis_fidelity = "high" if compile_result.status == "COMPLETE" and manifest_path.exists() else "medium"

    semantic_events: list[SemanticDiffEvent] = []
    rewrite_stats_payloads: list[dict[str, Any]] = []
    for path in dbt_like:
        if not path.endswith(".sql"):
            continue
        before_sql = read_before_sql(repo_root, git_base, path)
        after_sql = read_after_sql(repo_root, path)
        events = extract_sql_semantic_events(before_sql, after_sql, model=Path(path).stem)
        semantic_events.extend(events)
        rewrite_stats_payloads.append(
            estimate_rewrite_stats(
                before_sql,
                after_sql,
                joins_changed=sum(1 for event in events if event.event_type.startswith("join_")),
            ).to_dict()
        )

    rewrite_stats = aggregate_rewrite_stats(rewrite_stats_payloads)
    production_receipt = build_static_receipt(
        changed_files=dbt_like,
        semantic_events=semantic_events,
        repo_snapshot=repo_snapshot,
        mode="local",
    )
    old_comment = render_static_comment(production_receipt)
    shadow_receipt = build_shadow_hypothesis_receipt(
        production_receipt,
        semantic_events,
        repo_snapshot,
        rewrite_stats=rewrite_stats or None,
    )
    shadow_comment = render_shadow_comment(shadow_receipt)
    ranking_comparison = build_ranking_comparison(
        production_receipt,
        shadow_receipt,
        production_comment=old_comment,
    )
    adapted = apply_production_ranking_adapter(
        production_receipt=production_receipt,
        production_comment=old_comment,
        shadow_receipt=shadow_receipt,
        output_dir=artifact_dir,
    )
    final_comment = str(adapted["comment"])

    _write_json(artifact_dir / "receipt.json", production_receipt)
    (artifact_dir / "comment.md").write_text(final_comment, encoding="utf-8")
    _write_json(artifact_dir / "shadow_hypothesis_receipt.json", shadow_receipt)
    (artifact_dir / "shadow_comment.md").write_text(shadow_comment, encoding="utf-8")
    _write_json(artifact_dir / "ranking_comparison.json", ranking_comparison)

    result = result_from_adapter(adapted["artifact"], production_receipt)
    primary = primary_hypothesis(shadow_receipt)
    recommended_command = recommended_dbt_command(primary, dbt_like)
    summary = {
        "kind": CHECK_SUMMARY_KIND,
        "result": result,
        "exit_code": 1 if result == "REVIEW RECOMMENDED" else 0,
        "repo_root": str(repo_root),
        "dbt_project": "detected",
        "base": git_base.ref,
        "base_source": git_base.source,
        "changed_file_count": len(dbt_like),
        "changed_files": dbt_like,
        "dbt_compile": compile_result.status.lower(),
        "dbt_compile_reason": compile_result.reason,
        "analysis_fidelity": analysis_fidelity,
        "primary_risk": primary_summary(primary),
        "recommended_next_check": recommended_command,
        "artifact_dir": display_artifact_path(repo_root, artifact_dir),
        "artifact_dir_absolute": str(artifact_dir),
        "adapter": adapted["artifact"],
    }
    _write_json(artifact_dir / "semzero_check_summary.json", summary)
    return {
        "summary": summary,
        "terminal": render_check_terminal_summary(summary),
        "artifact_dir": artifact_dir,
    }


def run_semzero_doctor(start_dir: str | Path = ".") -> dict[str, Any]:
    git_path = shutil.which("git")
    dbt_path = shutil.which("dbt")
    root = detect_git_root(start_dir) if git_path else None
    dbt_project = bool(root and (root / "dbt_project.yml").exists())
    manifest = bool(root and (root / "target" / "manifest.json").exists())
    profiles = _profiles_likely_available(root) if root else False
    write_ok = False
    if root:
        try:
            target = root / ".semzero" / "runs"
            target.mkdir(parents=True, exist_ok=True)
            probe = target / ".write-test"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink(missing_ok=True)
            write_ok = True
        except Exception:
            write_ok = False
    can_static = bool(git_path and root and dbt_project and write_ok)
    return {
        "git_available": bool(git_path),
        "git_repo": bool(root),
        "repo_root": str(root) if root else "",
        "dbt_project": dbt_project,
        "dbt_command": bool(dbt_path),
        "dbt_path": dbt_path or "",
        "profiles_likely_available": profiles,
        "manifest_found": manifest,
        "python_version": f"{os.sys.version_info.major}.{os.sys.version_info.minor}.{os.sys.version_info.micro}",
        "write_access": write_ok,
        "static_fallback_available": can_static,
        "semzero_version": _semzero_version(),
    }


def render_doctor(payload: dict[str, Any]) -> str:
    lines = [
        "SemZero Doctor",
        f"Git available: {_ok(payload['git_available'])}",
        f"Git repo: {_ok(payload['git_repo'])}",
        f"dbt project: {_ok(payload['dbt_project'])}",
        f"dbt command: {'found' if payload['dbt_command'] else 'not found'}",
        f"dbt compile: {'likely available' if payload['dbt_command'] and payload['profiles_likely_available'] else 'unavailable'}",
        f"Manifest: {'found' if payload['manifest_found'] else 'not found'}",
        f"Write access: {_ok(payload['write_access'])}",
        f"Python: {payload['python_version']}",
        f"SemZero: {payload['semzero_version']}",
    ]
    if payload["static_fallback_available"]:
        lines += [
            "",
            "SemZero can still run using static SQL fallback.",
            "Recommended:",
            "Run `dbt compile` once for higher-fidelity lineage when credentials are available.",
        ]
    else:
        lines += ["", "Recommended:"]
        if not payload["git_available"]:
            lines.append("Install git and run SemZero inside a git-tracked dbt repo.")
        elif not payload["git_repo"]:
            lines.append("Run this inside a dbt project tracked by git.")
        elif not payload["dbt_project"]:
            lines.append("Run this inside a dbt project containing dbt_project.yml.")
        elif not payload["write_access"]:
            lines.append("Allow SemZero to write .semzero/runs artifacts in this repo.")
    return "\n".join(lines) + "\n"


def detect_git_root(start_dir: str | Path = ".") -> Path | None:
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=Path(start_dir),
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        return Path(out).resolve() if out else None
    except Exception:
        return None


def infer_git_base(repo_root: Path, *, base: str = "") -> GitBase:
    if base:
        return GitBase(ref=base, source="provided")
    for candidate in ("origin/main", "origin/master", "main", "master"):
        if _git_ref_exists(repo_root, candidate):
            return GitBase(ref=candidate, source="inferred")
    upstream = _git(["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"], repo_root)
    if upstream:
        merge_base = _git(["merge-base", "HEAD", upstream], repo_root)
        if merge_base:
            return GitBase(ref=merge_base, source=f"upstream:{upstream}")
    return GitBase(ref="HEAD", source="worktree", fallback_worktree_only=True)


def detect_changed_files(repo_root: Path, git_base: GitBase) -> list[str]:
    files: list[str] = []
    if not git_base.fallback_worktree_only:
        files.extend(_split_lines(_git(["diff", "--name-only", f"{git_base.ref}...HEAD"], repo_root)))
    files.extend(_split_lines(_git(["diff", "--name-only"], repo_root)))
    files.extend(_split_lines(_git(["diff", "--cached", "--name-only"], repo_root)))
    return sorted(dict.fromkeys(path for path in files if path))


def build_changed_diff(repo_root: Path, git_base: GitBase, paths: list[str]) -> str:
    if not paths:
        return ""
    chunks: list[str] = []
    if not git_base.fallback_worktree_only:
        chunks.append(_git(["diff", f"{git_base.ref}...HEAD", "--", *paths], repo_root))
    chunks.append(_git(["diff", "--", *paths], repo_root))
    chunks.append(_git(["diff", "--cached", "--", *paths], repo_root))
    return "\n".join(chunk for chunk in chunks if chunk.strip())


def try_dbt_compile(repo_root: Path) -> CompileResult:
    dbt = shutil.which("dbt")
    if not dbt:
        return CompileResult(status="UNAVAILABLE", reason="dbt_not_found")
    try:
        completed = subprocess.run(
            [dbt, "compile"],
            cwd=repo_root,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=180,
            check=False,
        )
    except Exception as exc:
        return CompileResult(status="UNAVAILABLE", reason=type(exc).__name__, log=str(exc))
    status = "COMPLETE" if completed.returncode == 0 else "UNAVAILABLE"
    reason = "dbt_compile_completed" if completed.returncode == 0 else f"dbt_compile_failed:{completed.returncode}"
    return CompileResult(status=status, reason=reason, log=completed.stdout or "")


def build_optional_repo_snapshot(
    *, repo_root: Path, manifest_path: Path, output_path: Path
) -> dict[str, Any] | None:
    if not manifest_path.exists():
        _write_json(output_path, {"status": "MISSING", "reason": "manifest_not_found"})
        return None
    try:
        from semzero.repo_understanding.dbt_repo_snapshot import write_dbt_repo_snapshot

        return write_dbt_repo_snapshot(
            manifest_path,
            output_path,
            repo="local",
            repo_root=repo_root,
        )
    except Exception as exc:
        _write_json(output_path, {"status": "SNAPSHOT_ERROR", "message": str(exc)})
        return None


def read_before_sql(repo_root: Path, git_base: GitBase, path: str) -> str:
    ref = git_base.ref
    return _git(["show", f"{ref}:{path}"], repo_root)


def read_after_sql(repo_root: Path, path: str) -> str:
    full = repo_root / path
    if not full.exists():
        return ""
    return full.read_text(encoding="utf-8", errors="ignore")


def build_static_receipt(
    *,
    changed_files: list[str],
    semantic_events: list[SemanticDiffEvent],
    repo_snapshot: dict[str, Any] | None,
    mode: str,
) -> dict[str, Any]:
    findings = seed_validated_findings(semantic_events, changed_files, repo_snapshot)
    verdict = "REQUIRE_REVIEW" if findings else "ALLOW"
    return {
        "receipt_kind": "semzero_local_check_static_v1",
        "schema_version": "semzero.evidence.v1",
        "adapter": "semzero_check",
        "domain": "data",
        "mode": mode,
        "verdict": verdict,
        "summary": {
            "finding_count": len(findings),
            "changed_resource_count": len(changed_files),
            "blast_radius_resource_count": _blast_radius_count(findings),
            "analysis_status": {
                "status": "COMPLETE",
                "reason": "local_static_semantic_analysis",
            },
        },
        "changed_files": changed_files,
        "findings": findings,
    }


def seed_validated_findings(
    events: list[SemanticDiffEvent],
    changed_files: list[str],
    repo_snapshot: dict[str, Any] | None,
) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    seen: set[str] = set()
    for event in events:
        family = _finding_family_for_event(event)
        if not family:
            continue
        if family == "schema_contract_break" and not _downstream_refs_for_removed_column(event, repo_snapshot):
            continue
        key = f"{family}:{event.event_type}:{event.model}:{event.raw_excerpt}"
        if key in seen:
            continue
        seen.add(key)
        findings.append(_finding_from_event(event, family, changed_files, repo_snapshot))
    return findings


def aggregate_rewrite_stats(items: list[dict[str, Any]]) -> dict[str, Any]:
    if not items:
        return {}
    keys = set().union(*(item.keys() for item in items))
    out = {key: max(float(item.get(key) or 0.0) for item in items) for key in keys}
    if "joins_changed" in out:
        out["joins_changed"] = int(out["joins_changed"])
    return out


def render_static_comment(receipt: dict[str, Any]) -> str:
    review = 1 if receipt.get("verdict") == "REQUIRE_REVIEW" else 0
    return "\n".join(
        [
            "<!-- semzero-assumption-gate -->",
            "## SemZero Assumption Gate",
            "",
            f"Verdict: `{receipt.get('verdict')}` · Mode: `{receipt.get('mode')}` · Review-required: `{review}` · Advisory: `0`",
            "",
            "Static local check completed.",
        ]
    )


def result_from_adapter(adapter: dict[str, Any], receipt: dict[str, Any]) -> str:
    comment_summary = adapter.get("comment_summary") or {}
    if str(comment_summary.get("verdict") or receipt.get("verdict")) == "REQUIRE_REVIEW":
        return "REVIEW RECOMMENDED"
    return "QUIET"


def render_check_terminal_summary(summary: dict[str, Any]) -> str:
    lines = [
        "SemZero Assumption Gate",
        f"Result: {summary['result']}",
        "dbt project: detected",
        f"Base: {summary['base']} {summary['base_source']}",
        f"Changed files: {summary['changed_file_count']}",
        f"dbt compile: {summary['dbt_compile']}",
        f"Analysis fidelity: {summary['analysis_fidelity']}",
    ]
    if summary["analysis_fidelity"] == "medium":
        lines += [
            "Note: dbt compile unavailable; used static SQL fallback.",
        ]
    primary = summary.get("primary_risk") or {}
    if summary["result"] == "REVIEW RECOMMENDED":
        lines += [
            f"Primary risk: {primary.get('title') or 'Structural Rewrite'}",
        ]
        if primary.get("file"):
            lines.append(f"File: {primary['file']}")
        why = primary.get("why") or "A validated semantic assumption may need review."
        lines += [
            "Why:",
            why,
            "Recommended next check:",
            f"  {summary['recommended_next_check']}",
        ]
    else:
        lines.append("No review-worthy semantic assumption change detected.")
    lines.append(f"Artifacts: {summary['artifact_dir']}/")
    return "\n".join(lines) + "\n"


def primary_hypothesis(shadow_receipt: dict[str, Any]) -> dict[str, Any] | None:
    for item in shadow_receipt.get("ranked_hypotheses") or []:
        if item.get("role") == "primary":
            return item
    return None


def primary_summary(primary: dict[str, Any] | None) -> dict[str, Any]:
    if not primary:
        return {}
    return {
        "family": primary.get("family"),
        "title": _title_family(str(primary.get("family") or "")),
        "file": primary.get("source_path") or "",
        "score": primary.get("rank_score"),
        "why": primary.get("why_it_matters") or _default_why(str(primary.get("family") or "")),
        "recommended_check": primary.get("recommended_check") or "",
    }


def recommended_dbt_command(primary: dict[str, Any] | None, changed_files: list[str]) -> str:
    source_path = str((primary or {}).get("source_path") or "")
    model = Path(source_path).stem if source_path else ""
    if not model and changed_files:
        model = Path(changed_files[0]).stem
    return f"dbt build --select {model}+" if model else "dbt build --select state:modified+"


def _finding_family_for_event(event: SemanticDiffEvent) -> str:
    if event.family_hint == "enum_domain_closure" and event.event_type == "case_else_changed":
        return "enum_domain_closure"
    if event.family_hint in {"grain_contract_drift", "join_relationship_drift"}:
        return "join_cardinality"
    if event.event_type == "selected_column_removed":
        return "schema_contract_break"
    return ""


def _finding_from_event(
    event: SemanticDiffEvent,
    family: str,
    changed_files: list[str],
    repo_snapshot: dict[str, Any] | None,
) -> dict[str, Any]:
    path = _path_for_event(event, changed_files, repo_snapshot)
    refs = _downstream_refs_for_removed_column(event, repo_snapshot)
    blast = [
        {
            "name": ref.get("downstream_name") or ref.get("downstream_model"),
            "unique_id": ref.get("downstream_model"),
            "path": ref.get("downstream_path"),
            "business_severity": ref.get("sensitivity") or "UNKNOWN",
        }
        for ref in refs
    ]
    return {
        "id": f"LOCAL-{family.upper()}-{_stable_suffix(event)}",
        "stable_id": f"LOCAL-{family.upper()}-{_stable_suffix(event)}",
        "family": family,
        "severity": "high" if family != "enum_domain_closure" else "medium",
        "confidence": "medium",
        "source_resource": event.model,
        "source_path": path,
        "assumption": _assumption_for_event(event, family),
        "why_it_matters": _why_for_event(event, family),
        "recommended_check": _check_for_family(family),
        "trigger_evidence": [f"{event.event_type}: {event.raw_excerpt}"],
        "blast_radius": blast,
        "business_impact": {
            "highest_business_severity": _highest_business_severity(blast),
        },
        "replay_fidelity": {"score": event.fidelity or 0.70},
    }


def _path_for_event(
    event: SemanticDiffEvent, changed_files: list[str], repo_snapshot: dict[str, Any] | None
) -> str:
    models = (repo_snapshot or {}).get("models") or {}
    for model in models.values():
        if str(model.get("name") or "").lower() == event.model.lower():
            return str(model.get("path") or "")
    for path in changed_files:
        if Path(path).stem.lower() == event.model.lower():
            return path
    return changed_files[0] if changed_files else ""


def _downstream_refs_for_removed_column(
    event: SemanticDiffEvent, repo_snapshot: dict[str, Any] | None
) -> list[dict[str, Any]]:
    if event.event_type != "selected_column_removed":
        return []
    column = _removed_column_alias(event)
    if not column:
        return []
    models = (repo_snapshot or {}).get("models") or {}
    for model in models.values():
        if str(model.get("name") or "").lower() != event.model.lower():
            continue
        return [
            ref
            for ref in (model.get("downstream_column_references") or [])
            if str(ref.get("column") or "").lower() == column.lower()
        ]
    return []


def _removed_column_alias(event: SemanticDiffEvent) -> str:
    before = str(event.before or event.raw_excerpt or "")
    alias = re.search(r"\bas\s+([A-Za-z_][A-Za-z0-9_]*)\s*$", before, flags=re.I)
    if alias:
        return alias.group(1)
    simple = re.search(r"(?:^|\.)([A-Za-z_][A-Za-z0-9_]*)\s*$", before.strip())
    return simple.group(1) if simple else ""


def _assumption_for_event(event: SemanticDiffEvent, family: str) -> str:
    if family == "enum_domain_closure":
        return "Downstream consumers still understand the changed enum/status mapping."
    if family == "join_cardinality":
        return "Downstream consumers still receive the same row relationship and grain."
    if family == "schema_contract_break":
        return "Downstream consumers can still select the removed model output column."
    return f"{event.event_type} does not change a hidden downstream assumption."


def _why_for_event(event: SemanticDiffEvent, family: str) -> str:
    if event.event_type == "case_else_changed":
        return f"CASE fallback changed from {event.before!r} to {event.after!r}."
    if event.event_type.startswith("group_by"):
        return "GROUP BY keys changed, so the model grain or row multiplicity may have changed."
    if event.event_type.startswith("join_"):
        return "A join relationship changed, so downstream row matching may no longer mean the same thing."
    if event.event_type == "selected_column_removed":
        return "A selected output column was removed while downstream SQL may depend on it."
    return _default_why(family)


def _default_why(family: str) -> str:
    if family == "enum_domain_closure":
        return "A status or enum mapping changed."
    if family == "join_cardinality":
        return "A structural grain or join relationship changed."
    if family == "schema_contract_break":
        return "A downstream-used model output changed."
    return "A semantic assumption changed."


def _check_for_family(family: str) -> str:
    if family == "enum_domain_closure":
        return "Verify downstream accepted values, filters, and mappings for the changed enum value."
    if family == "join_cardinality":
        return "Verify row grain, join keys, and downstream unique/relationship tests."
    if family == "schema_contract_break":
        return "Update downstream references or restore the removed output column."
    return "Review the changed assumption and run the affected downstream dbt build/test scope."


def _highest_business_severity(blast: list[dict[str, Any]]) -> str:
    order = {"UNKNOWN": 0, "ANALYTICAL": 1, "OPERATIONAL": 2, "CUSTOMER_FACING": 3, "REVENUE_CRITICAL": 4}
    best = "UNKNOWN"
    for item in blast:
        value = str(item.get("business_severity") or "UNKNOWN").upper()
        if order.get(value, 0) > order.get(best, 0):
            best = value
    return best


def _stable_suffix(event: SemanticDiffEvent) -> str:
    seed = f"{event.model}:{event.event_type}:{event.raw_excerpt}"
    return hashlib.sha1(seed.encode("utf-8")).hexdigest()[:8].upper()


def _blast_radius_count(findings: list[dict[str, Any]]) -> int:
    seen = set()
    for finding in findings:
        for item in finding.get("blast_radius") or []:
            if item.get("unique_id") or item.get("name"):
                seen.add(item.get("unique_id") or item.get("name"))
    return len(seen)


def _is_dbt_like(path: str) -> bool:
    return path.endswith((".sql", ".yml", ".yaml")) and (
        path.startswith(("models/", "macros/", "snapshots/", "seeds/")) or path == "dbt_project.yml"
    )


def _git_ref_exists(repo_root: Path, ref: str) -> bool:
    return bool(_git(["rev-parse", "--verify", "--quiet", ref], repo_root))


def _git(args: list[str], repo_root: Path) -> str:
    try:
        return subprocess.check_output(
            ["git", *args],
            cwd=repo_root,
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except Exception:
        return ""


def _split_lines(blob: str) -> list[str]:
    return [line.strip() for line in str(blob or "").splitlines() if line.strip()]


def _profiles_likely_available(repo_root: Path | None) -> bool:
    if not repo_root:
        return False
    if (repo_root / "profiles.yml").exists():
        return True
    return (Path.home() / ".dbt" / "profiles.yml").exists()


def _semzero_version() -> str:
    try:
        from semzero.version import __version__

        return __version__
    except Exception:
        return "unknown"


def _title_family(family: str) -> str:
    return family.replace("_", " ").title()


def _ok(value: bool) -> str:
    return "OK" if value else "missing"


def _write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def display_artifact_path(repo_root: Path, artifact_dir: Path) -> str:
    try:
        return str(artifact_dir.relative_to(repo_root))
    except Exception:
        return str(artifact_dir)
