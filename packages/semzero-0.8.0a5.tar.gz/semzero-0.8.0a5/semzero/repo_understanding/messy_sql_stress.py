from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from semzero.repo_understanding.sql_semantic_diff import SemanticDiffEvent


RESULT_PASS = "PASS"
RESULT_PARTIAL = "PARTIAL"
RESULT_FAIL = "FAIL"

MESSINESS_KIND = "semzero_sql_messiness_v1"
MESSY_STRESS_SUMMARY_KIND = "semzero_messy_sql_stress_summary_v1"

LOW_MESSINESS_MAX = 0.35
HIGH_MESSINESS_MIN = 0.67

JOIN_EVENTS = {
    "join_added",
    "join_removed",
    "join_key_changed",
    "join_target_changed",
    "join_type_changed",
    "join_predicate_weakened",
}
SELECTED_COLUMN_EVENTS = {
    "selected_column_added",
    "selected_column_removed",
    "selected_column_renamed",
    "selected_expression_changed",
    "selected_alias_changed",
    "type_cast_changed",
}
CASE_EVENTS = {
    "case_else_changed",
    "case_branch_added",
    "case_branch_removed",
    "case_condition_changed",
}
GROUP_BY_EVENTS = {
    "group_by_key_added",
    "group_by_key_removed",
    "group_by_key_replaced",
    "distinct_added",
    "distinct_removed",
}
METRIC_EVENTS = {
    "aggregate_function_changed",
    "aggregate_argument_changed",
    "arithmetic_expression_changed",
    "metric_numerator_changed",
    "metric_denominator_changed",
    "distinctness_changed",
}
FILTER_EVENTS = {
    "where_predicate_added",
    "where_predicate_removed",
    "where_predicate_changed",
    "status_population_changed",
    "filter_predicate_changed",
}
UNVALIDATED_PRODUCTION_FAMILIES = {
    "metric_semantics_drift",
    "metric_formula_changed",
    "filter_population_drift",
    "enum_population_drift",
    "incremental_filter",
}

EVENT_FAMILY_BY_TYPE = {
    **{event: "join_relationship_drift" for event in JOIN_EVENTS},
    **{event: "schema_contract_break" for event in SELECTED_COLUMN_EVENTS},
    **{event: "enum_domain_closure" for event in CASE_EVENTS},
    **{event: "grain_contract_drift" for event in GROUP_BY_EVENTS},
    **{event: "metric_semantics_drift" for event in METRIC_EVENTS},
    **{event: "filter_population_drift" for event in FILTER_EVENTS},
}


@dataclass(frozen=True, slots=True)
class MessyStressScenario:
    scenario: str
    mutation_mix: tuple[str, ...]
    expected_primary_families: tuple[str, ...] = ()
    allowed_secondary_families: tuple[str, ...] = ()
    forbidden_primary_families: tuple[str, ...] = ()
    expected_semantic_events: tuple[str, ...] = ()
    expected_visible_families: tuple[str, ...] = ()
    should_be_quiet: bool = False
    allow_circuit_breaker: bool = False
    expected_messiness_levels: tuple[str, ...] = ("low", "medium")
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "scenario": self.scenario,
            "mutation_mix": list(self.mutation_mix),
            "expected_primary_families": list(self.expected_primary_families),
            "allowed_secondary_families": list(self.allowed_secondary_families),
            "forbidden_primary_families": list(self.forbidden_primary_families),
            "expected_semantic_events": list(self.expected_semantic_events),
            "expected_visible_families": list(self.expected_visible_families),
            "should_be_quiet": self.should_be_quiet,
            "allow_circuit_breaker": self.allow_circuit_breaker,
            "expected_messiness_levels": list(self.expected_messiness_levels),
            "notes": self.notes,
        }


@dataclass(frozen=True, slots=True)
class MessyStressClassification:
    scenario: str
    expected_primary: list[str]
    actual_primary: str | None
    visible_families: list[str]
    semantic_events: list[str]
    messiness_level: str
    messiness_score: float
    circuit_breaker: bool
    production_behavior: str
    result: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "scenario": self.scenario,
            "expected_primary": self.expected_primary,
            "actual_primary": self.actual_primary,
            "visible_families": self.visible_families,
            "semantic_events": self.semantic_events,
            "messiness_level": self.messiness_level,
            "messiness_score": self.messiness_score,
            "circuit_breaker": self.circuit_breaker,
            "production_behavior": self.production_behavior,
            "result": self.result,
            "reason": self.reason,
        }


MESSY_STRESS_SCENARIOS: dict[str, MessyStressScenario] = {
    "refactor_plus_enum_change": MessyStressScenario(
        scenario="refactor_plus_enum_change",
        mutation_mix=(
            "rename CTE",
            "reformat SQL",
            "add comments",
            "change CASE ELSE 'pending' to 'unresolved'",
        ),
        expected_primary_families=("enum_domain_closure",),
        forbidden_primary_families=(
            "grain_contract_drift",
            "join_cardinality",
            "join_relationship_drift",
        ),
        expected_semantic_events=("case_else_changed",),
        notes="Refactor noise must not hide direct enum drift.",
    ),
    "refactor_plus_grain_change": MessyStressScenario(
        scenario="refactor_plus_grain_change",
        mutation_mix=(
            "rename CTE",
            "reorder SELECT columns",
            "change GROUP BY key",
        ),
        expected_primary_families=(
            "grain_contract_drift",
            "join_cardinality",
            "join_relationship_drift",
        ),
        forbidden_primary_families=("enum_domain_closure",),
        expected_semantic_events=("group_by_key_added", "group_by_key_removed"),
        notes="Structural risk should dominate harmless SQL movement.",
    ),
    "enum_plus_metric_change": MessyStressScenario(
        scenario="enum_plus_metric_change",
        mutation_mix=(
            "change CASE ELSE fallback",
            "change SUM(payment_value) to SUM(payment_value * 0.9)",
        ),
        expected_primary_families=("enum_domain_closure",),
        allowed_secondary_families=("metric_semantics_drift", "metric_formula_changed"),
        expected_semantic_events=("case_else_changed",),
        expected_visible_families=("enum_domain_closure",),
        notes="Metric remains a known shadow-only gap until the narrow metric fix ships.",
    ),
    "column_add_plus_used_remove": MessyStressScenario(
        scenario="column_add_plus_used_remove",
        mutation_mix=("add harmless selected column", "remove downstream-used selected column"),
        expected_primary_families=("schema_contract_break", "required_column_removed"),
        expected_semantic_events=("selected_column_removed",),
        expected_visible_families=("schema_contract_break",),
        notes="Breaking removal must dominate harmless additive schema churn.",
    ),
    "join_key_plus_formatting": MessyStressScenario(
        scenario="join_key_plus_formatting",
        mutation_mix=("reformat joins", "reorder CTEs", "change join predicate key"),
        expected_primary_families=("join_cardinality", "join_relationship_drift"),
        expected_semantic_events=("join_key_changed",),
        expected_visible_families=("join_cardinality",),
        notes="Direct join mutation should survive formatting noise.",
    ),
    "multiple_true_risks_one_file": MessyStressScenario(
        scenario="multiple_true_risks_one_file",
        mutation_mix=(
            "change CASE ELSE",
            "change GROUP BY",
            "remove downstream-used column",
        ),
        expected_primary_families=(
            "schema_contract_break",
            "grain_contract_drift",
            "join_cardinality",
            "join_relationship_drift",
        ),
        allowed_secondary_families=("enum_domain_closure",),
        expected_semantic_events=(
            "case_else_changed",
            "selected_column_removed",
        ),
        expected_visible_families=("enum_domain_closure",),
        expected_messiness_levels=("medium", "high"),
        notes="Multiple true positives are acceptable if the comment stays useful.",
    ),
    "messy_harmless_refactor": MessyStressScenario(
        scenario="messy_harmless_refactor",
        mutation_mix=(
            "rename CTE",
            "reorder SELECT expressions",
            "add comments",
            "format SQL",
        ),
        should_be_quiet=True,
        expected_messiness_levels=("low", "medium"),
        notes="Large harmless movement must not become a scary review finding.",
    ),
    "ambiguous_heavy_rewrite": MessyStressScenario(
        scenario="ambiguous_heavy_rewrite",
        mutation_mix=(
            "large CTE restructure",
            "selected columns added/removed",
            "CASE logic changed",
            "join added/removed",
            "GROUP BY changed",
        ),
        allow_circuit_breaker=True,
        expected_messiness_levels=("high",),
        notes="SemZero should refuse fake precision and recommend wider dbt validation.",
    ),
}


def compute_messiness_score(
    semantic_events: list[SemanticDiffEvent | dict[str, Any]],
    rewrite_stats: Any | None = None,
) -> dict[str, Any]:
    events = [_event_dict(event) for event in semantic_events]
    event_types = [str(event.get("event_type") or "") for event in events if event.get("event_type")]
    families = {
        str(event.get("family_hint") or EVENT_FAMILY_BY_TYPE.get(str(event.get("event_type") or ""), ""))
        for event in events
    }
    families.discard("")
    stats = _rewrite_stats_dict(rewrite_stats)
    changed_line_ratio = float(stats.get("line_change_ratio") or 0.0)
    cte_rewrite_ratio = float(stats.get("cte_rewrite_ratio") or 0.0)
    joins_changed = int(stats.get("joins_changed") or 0)
    model_length_ratio = float(stats.get("model_length_ratio") or 1.0)
    selected_count = _count(event_types, SELECTED_COLUMN_EVENTS)
    join_count = max(_count(event_types, JOIN_EVENTS), joins_changed)
    case_count = _count(event_types, CASE_EVENTS)
    group_count = _count(event_types, GROUP_BY_EVENTS)
    metric_count = _count(event_types, METRIC_EVENTS)
    filter_count = _count(event_types, FILTER_EVENTS)
    changed_cte_count = len({str(event.get("cte") or "") for event in events if event.get("cte")})
    has_schema_and_relationship = bool(
        set(event_types).intersection(SELECTED_COLUMN_EVENTS)
        and set(event_types).intersection(JOIN_EVENTS | GROUP_BY_EVENTS)
    )
    event_count = len(event_types)
    family_count = len(families)

    score = 0.0
    score += min(0.25, event_count * 0.035)
    score += min(0.20, max(family_count - 1, 0) * 0.06)
    score += min(0.25, changed_line_ratio * 0.55)
    score += min(0.10, cte_rewrite_ratio * 0.10)
    score += min(0.12, join_count * 0.05)
    score += min(0.12, selected_count * 0.04)
    score += min(0.10, case_count * 0.04)
    score += min(0.10, group_count * 0.05)
    score += min(0.08, (metric_count + filter_count) * 0.04)
    if has_schema_and_relationship:
        score += 0.08
    if model_length_ratio > 1.6:
        score += min(0.10, (model_length_ratio - 1.6) * 0.12)
    score = round(min(score, 1.0), 4)

    high_shape = (
        event_count >= 7
        or family_count >= 4
        or changed_line_ratio >= 0.40
        or joins_changed > 3
        or model_length_ratio > 2.0
    )
    if score >= HIGH_MESSINESS_MIN and high_shape:
        level = "high"
    elif score >= LOW_MESSINESS_MAX:
        level = "medium"
    else:
        level = "low"

    decision = (
        "circuit_breaker"
        if level == "high"
        else "rank_with_multiple_semantic_changes"
        if level == "medium"
        else "normal_ranking"
    )
    return {
        "kind": MESSINESS_KIND,
        "score": score,
        "level": level,
        "signals": {
            "semantic_event_count": event_count,
            "family_count": family_count,
            "changed_line_ratio": round(changed_line_ratio, 4),
            "join_event_count": join_count,
            "selected_column_event_count": selected_count,
            "case_event_count": case_count,
            "group_by_event_count": group_count,
            "metric_event_count": metric_count,
            "filter_event_count": filter_count,
            "changed_cte_count": changed_cte_count,
            "cte_rewrite_ratio": round(cte_rewrite_ratio, 4),
            "model_length_ratio": round(model_length_ratio, 4),
            "schema_and_relationship_changed": has_schema_and_relationship,
        },
        "decision": decision,
    }


def classify_messy_stress_result(
    scenario: MessyStressScenario | str,
    *,
    shadow_receipt: dict[str, Any],
    production_adapter: dict[str, Any] | None = None,
    compile_status: str = "COMPLETE",
    changed_file_count: int = 1,
) -> MessyStressClassification:
    scenario_obj = (
        MESSY_STRESS_SCENARIOS[scenario] if isinstance(scenario, str) else scenario
    )
    ranked = list(shadow_receipt.get("ranked_hypotheses") or [])
    primary = next((item for item in ranked if item.get("role") == "primary"), None)
    actual_primary = str(primary.get("family") or "") if primary else None
    visible_families = _visible_families(shadow_receipt)
    semantic_events = list(shadow_receipt.get("semantic_event_types") or [])
    messiness = shadow_receipt.get("messiness") or compute_messiness_score(
        list(shadow_receipt.get("semantic_events") or [])
    )
    messiness_level = str(messiness.get("level") or "low")
    messiness_score = round(float(messiness.get("score") or 0.0), 4)
    circuit_breaker = bool(
        shadow_receipt.get("analysis_outcome") == "massive_rewrite_circuit_breaker"
        or (shadow_receipt.get("circuit_breaker") or {}).get("triggered")
    )
    adapter = production_adapter or {}
    production_behavior = str(adapter.get("behavior") or "")
    production_applied = bool(adapter.get("adapter_applied"))
    production_primary_family = str((adapter.get("primary") or {}).get("family") or actual_primary or "")
    production_must_review = int((adapter.get("comment_summary") or {}).get("must_review_count") or 0)

    if changed_file_count != 1:
        result, reason = RESULT_PARTIAL, "changed_file_count != 1; stress branch scope is polluted"
    elif compile_status != "COMPLETE":
        result, reason = RESULT_PARTIAL, "compile did not complete; stress result needs manual review"
    elif production_applied and production_primary_family in UNVALIDATED_PRODUCTION_FAMILIES:
        result, reason = RESULT_FAIL, "unvalidated metric/filter family leaked into production"
    elif scenario_obj.should_be_quiet:
        if actual_primary or production_must_review > 0:
            result, reason = RESULT_FAIL, "harmless messy refactor became must_review"
        else:
            result, reason = RESULT_PASS, "harmless messy refactor stayed quiet"
    elif scenario_obj.allow_circuit_breaker:
        if circuit_breaker and production_behavior in {"", "massive_rewrite_broad_warning"}:
            result, reason = RESULT_PASS, "high messiness triggered broad warning"
        elif messiness_level == "high" and actual_primary:
            result, reason = RESULT_FAIL, "high messiness emitted fake precise primary"
        else:
            result, reason = RESULT_PARTIAL, "heavy rewrite was not confidently classified"
    elif circuit_breaker:
        result, reason = RESULT_PARTIAL, "circuit breaker fired early but safely"
    elif actual_primary in scenario_obj.forbidden_primary_families:
        result, reason = RESULT_FAIL, "wrong unrelated family became primary"
    elif not actual_primary:
        result, reason = RESULT_FAIL, "true high-risk messy change stayed quiet"
    elif actual_primary in scenario_obj.expected_primary_families:
        if _expected_events_present(scenario_obj, semantic_events) and _visible_expected_families(
            scenario_obj, visible_families
        ):
            result, reason = RESULT_PASS, "dominant expected risk is primary"
        else:
            result, reason = RESULT_PARTIAL, "primary is right but supporting events/families are incomplete"
    elif _visible_expected_families(scenario_obj, visible_families):
        result, reason = RESULT_PARTIAL, "validated risk appears secondary, not primary"
    else:
        result, reason = RESULT_FAIL, "wrong family, missing event, or unrelated primary"

    return MessyStressClassification(
        scenario=scenario_obj.scenario,
        expected_primary=list(scenario_obj.expected_primary_families),
        actual_primary=actual_primary,
        visible_families=visible_families,
        semantic_events=semantic_events,
        messiness_level=messiness_level,
        messiness_score=messiness_score,
        circuit_breaker=circuit_breaker,
        production_behavior=production_behavior,
        result=result,
        reason=reason,
    )


def build_messy_stress_summary_markdown(
    classifications: list[MessyStressClassification],
) -> str:
    lines = [
        "| Scenario | Expected Primary | Actual Primary | Visible Families | Messiness | Circuit Breaker | Result | Reason |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |",
    ]
    for item in classifications:
        lines.append(
            "| {scenario} | {expected} | {actual} | {families} | {messiness} | {circuit} | {result} | {reason} |".format(
                scenario=item.scenario,
                expected=", ".join(item.expected_primary) or "none",
                actual=item.actual_primary or "none",
                families=", ".join(item.visible_families) or "none",
                messiness=f"{item.messiness_level} ({item.messiness_score:.4f})",
                circuit="yes" if item.circuit_breaker else "no",
                result=item.result,
                reason=item.reason,
            )
        )
    return "\n".join(lines) + "\n"


def _event_dict(event: SemanticDiffEvent | dict[str, Any]) -> dict[str, Any]:
    if isinstance(event, SemanticDiffEvent):
        data = event.to_dict()
        location = data.get("location") or {}
        return {
            "event_type": data.get("event_type"),
            "family_hint": data.get("family_hint"),
            "cte": location.get("cte"),
        }
    location = event.get("location") if isinstance(event.get("location"), dict) else {}
    return {
        "event_type": event.get("event_type"),
        "family_hint": event.get("family_hint"),
        "cte": event.get("cte") or location.get("cte"),
    }


def _rewrite_stats_dict(rewrite_stats: Any | None) -> dict[str, Any]:
    if rewrite_stats is None:
        return {}
    if isinstance(rewrite_stats, dict):
        return rewrite_stats
    if hasattr(rewrite_stats, "to_dict"):
        return dict(rewrite_stats.to_dict())
    return {
        "line_change_ratio": getattr(rewrite_stats, "line_change_ratio", 0.0),
        "cte_rewrite_ratio": getattr(rewrite_stats, "cte_rewrite_ratio", 0.0),
        "joins_changed": getattr(rewrite_stats, "joins_changed", 0),
        "model_length_ratio": getattr(rewrite_stats, "model_length_ratio", 1.0),
    }


def _count(event_types: list[str], candidates: set[str]) -> int:
    return sum(1 for event_type in event_types if event_type in candidates)


def _visible_families(shadow_receipt: dict[str, Any]) -> list[str]:
    families: set[str] = set()
    for item in shadow_receipt.get("ranked_hypotheses") or []:
        family = str(item.get("family") or "")
        if family and item.get("role") in {"primary", "secondary", "advisory"}:
            families.add(family)
    for event in shadow_receipt.get("semantic_events") or []:
        event_type = str(event.get("event_type") or "")
        family = str(event.get("family_hint") or EVENT_FAMILY_BY_TYPE.get(event_type, ""))
        if family:
            families.add(family)
    return sorted(families)


def _expected_events_present(
    scenario: MessyStressScenario, semantic_events: list[str]
) -> bool:
    if not scenario.expected_semantic_events:
        return True
    return all(event in semantic_events for event in scenario.expected_semantic_events)


def _visible_expected_families(
    scenario: MessyStressScenario, visible_families: list[str]
) -> bool:
    if not scenario.expected_visible_families:
        return True
    visible = set(visible_families)
    return all(family in visible for family in scenario.expected_visible_families)
