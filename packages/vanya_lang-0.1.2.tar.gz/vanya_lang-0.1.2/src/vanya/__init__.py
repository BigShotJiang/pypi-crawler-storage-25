import platform
import subprocess
import sys
import urllib.request
import tarfile
import zipfile
import lzma
from pathlib import Path

__version__ = "0.1.2"
BINARY_VERSION = "0.1.0"

R2_BASE = "https://pub-5dae181f67424ed482a6fd7383474727.r2.dev"

PLATFORMS = {
    ("Darwin", "x86_64"): "x86_64-apple-darwin",
    ("Darwin", "arm64"): "aarch64-apple-darwin",
    ("Linux", "x86_64"): "x86_64-unknown-linux-gnu",
    ("Linux", "aarch64"): "aarch64-unknown-linux-gnu",
    ("Windows", "AMD64"): "x86_64-pc-windows-msvc",
}


def get_binary_path() -> Path:
    bin_dir = Path(__file__).parent / "bin"
    bin_dir.mkdir(exist_ok=True)
    ext = ".exe" if platform.system() == "Windows" else ""
    binary = bin_dir / f"vanya{ext}"
    if not binary.exists():
        download_binary(binary)
    return binary


def download_binary(dest: Path) -> None:
    system = platform.system()
    machine = platform.machine()
    target = PLATFORMS.get((system, machine))
    if not target:
        raise RuntimeError(f"Unsupported platform: {system}-{machine}")

    ext = ".zip" if system == "Windows" else ".tar.xz"
    url = f"{R2_BASE}/v{BINARY_VERSION}/vanya-{target}{ext}"

    print(f"Downloading vanya from {url}")
    archive_path = dest.parent / f"vanya{ext}"
    req = urllib.request.Request(url, headers={"User-Agent": "vanya-installer"})
    with urllib.request.urlopen(req) as resp, open(archive_path, "wb") as f:
        f.write(resp.read())

    if ext == ".tar.xz":
        with lzma.open(archive_path) as xz:
            with tarfile.open(fileobj=xz) as tar:
                for member in tar.getmembers():
                    if member.name.endswith("vanya"):
                        member.name = "vanya"
                        tar.extract(member, dest.parent)
                        break
    else:
        with zipfile.ZipFile(archive_path, "r") as z:
            for name in z.namelist():
                if name.endswith("vanya.exe"):
                    with z.open(name) as src, open(dest, "wb") as dst:
                        dst.write(src.read())
                    break

    archive_path.unlink()
    dest.chmod(0o755)


def main() -> None:
    binary = get_binary_path()
    result = subprocess.run([str(binary)] + sys.argv[1:])
    sys.exit(result.returncode)
