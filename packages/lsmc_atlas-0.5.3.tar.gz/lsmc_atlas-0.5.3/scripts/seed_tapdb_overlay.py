"""Seed minimal Atlas TapDB overlay data.

This script is intentionally TapDB-only and does not rely on legacy ORM tables.
"""

from __future__ import annotations

from app.db.engine import SessionLocal
from app.domain.enums import AccessScope, SystemGroup
from app.domain.services.groups import GroupCreate, UserGroupService
from app.domain.services.orgs import (
    OrganizationCreate,
    OrganizationService,
    SiteCreate,
    SiteService,
)


def _ensure_orgs(db) -> list:
    org_svc = OrganizationService(db)
    orgs = org_svc.list_all(active_only=False)
    if orgs:
        site_svc = SiteService(db)
        for org in orgs:
            sites = site_svc.list_by_organization(org.euid, active_only=False)
            if sites:
                continue
            site_svc.create(
                SiteCreate(
                    organization_id=org.euid,
                    name="Default Site",
                    site_code="DEFAULT",
                ),
                created_by=None,
            )
        return orgs
    created = org_svc.create(
        OrganizationCreate(
            name="lsmc-default-org",
            display_name="LSMC Default Org",
            org_type="clinic",
            initial_site_name="Default Site",
            initial_site_code="DEFAULT",
        ),
        created_by=None,
    )
    return [created]


def _scope_for_group(group: SystemGroup) -> AccessScope:
    if group == SystemGroup.ADMIN:
        return AccessScope.SYSTEM
    if group == SystemGroup.LSMC_STAFF:
        return AccessScope.CROSS_TENANT
    return AccessScope.TENANT


def _ensure_system_groups(db, tenant_id):
    svc = UserGroupService(db, tenant_id)
    for group_code in SystemGroup:
        existing = svc.get_group_by_code(group_code.value)
        if existing is not None:
            continue
        svc.create_group(
            GroupCreate(
                group_code=group_code.value,
                name=group_code.value.replace("_", " ").title(),
                description=f"System group {group_code.value}",
                access_scope=_scope_for_group(group_code),
                default_roles=None,
            ),
            created_by=None,
        )


def main() -> int:
    session = SessionLocal()
    try:
        orgs = _ensure_orgs(session)
        for org in orgs:
            _ensure_system_groups(session, org.uid)
        session.commit()
        print("TapDB seed overlay complete.")
        return 0
    except Exception as exc:  # pragma: no cover
        session.rollback()
        print(f"TapDB seed overlay failed: {exc}")
        return 1
    finally:
        session.close()


if __name__ == "__main__":
    raise SystemExit(main())
