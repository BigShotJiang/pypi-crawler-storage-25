"""Smoke tests for web (HTML) routes.

Ensures every web endpoint returns a non-500 response with correct auth.
Tests are organized by authentication level: admin, internal, regular user.
"""

import uuid

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import (
    CurrentUser,
    get_current_user,
    get_current_user_or_token,
    get_current_user_web,
    require_internal,
    require_org_admin,
)
from app.auth.middleware import csrf_protect
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import app
from app.web.routes.pages import require_admin
from tests.tapdb_test_helpers import ensure_tapdb_org

_uid = str(uuid.uuid4())
_oid = "TRF-FAKE-001"
_sid = "SHP-FAKE-001"
_exc = "EXC-FAKE-001"
_man = "MAN-FAKE-001"
_rel = "REL-FAKE-001"
_tid = "TKT-FAKE-001"


@pytest.fixture
def tenant_uuid() -> uuid.UUID:
    return uuid.uuid4()


@pytest.fixture
def setup_org(db_session: Session, tenant_uuid: uuid.UUID) -> uuid.UUID:
    ensure_tapdb_org(db_session, tenant_uuid, name="web-smoke-org", display_name="Web Smoke Org")
    db_session.flush()
    return tenant_uuid


@pytest.fixture
def ext_user(tenant_uuid: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="websmoke@test.com",
        name="Web Smoke",
        tenant_id=tenant_uuid,
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def int_user(tenant_uuid: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="websmoke@lsmc.bio",
        name="Web Smoke Internal",
        tenant_id=tenant_uuid,
        roles=[Role.INTERNAL_USER.value],
    )


@pytest.fixture
def adm_user(tenant_uuid: uuid.UUID) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="websmoke-admin@lsmc.bio",
        name="Web Smoke Admin",
        tenant_id=tenant_uuid,
        roles=[Role.ADMIN.value],
    )


def _client(db_session: Session, user: CurrentUser) -> TestClient:
    """Build a TestClient with given user and overridden dependencies."""

    def override_db():
        try:
            yield db_session
        finally:
            pass

    def override_user():
        return user

    async def override_csrf():
        pass

    app.dependency_overrides[get_db] = override_db
    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_current_user_web] = override_user
    app.dependency_overrides[get_current_user_or_token] = override_user
    app.dependency_overrides[csrf_protect] = override_csrf
    app.dependency_overrides[require_admin] = override_user
    app.dependency_overrides[require_internal] = override_user
    app.dependency_overrides[require_org_admin] = override_user
    return TestClient(app)


@pytest.fixture(autouse=True)
def _clear_overrides():
    yield
    app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


def test_web_health():
    """Standard health endpoints return 200."""
    client = TestClient(app)
    for path in ("/health", "/healthz", "/readyz"):
        resp = client.get(path)
        assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Admin GET routes
# ---------------------------------------------------------------------------

ADMIN_GET = [
    "/admin/api-tokens",
    "/admin/test-definitions/create",
    f"/admin/test-definitions/{_uid}",
    f"/admin/test-definitions/{_uid}/edit",
    "/admin/groups",
    "/admin/groups/ADMIN",
    "/admin/groups/CUSTOMER",
    "/admin/organizations/create",
    f"/admin/organizations/{_uid}/edit",
    f"/admin/organizations/{_uid}/sites/new",
    f"/admin/organizations/{_uid}/users/new",
    f"/admin/sites/{_uid}/edit",
    f"/admin/users/{_uid}",
    f"/admin/users/{_uid}/edit",
]


@pytest.mark.db
@pytest.mark.parametrize("path", ADMIN_GET)
def test_web_admin_get(db_session, adm_user, setup_org, path):
    """Admin GET pages return non-500."""
    c = _client(db_session, adm_user)
    resp = c.get(path)
    assert resp.status_code != 500, f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 302, 404, 410)


# ---------------------------------------------------------------------------
# Admin POST routes
# ---------------------------------------------------------------------------

ADMIN_POST = [
    (f"/admin/api-tokens/{_uid}/revoke", {}),
    ("/admin/test-definitions/create", {"name": "Smoke", "code": "SMK1"}),
    (f"/admin/test-definitions/{_uid}/deactivate", {}),
    (f"/admin/test-definitions/{_uid}/edit", {"name": "Smoke"}),
    (f"/admin/test-definitions/{_uid}/link-document", {"document_id": _uid}),
    (f"/admin/test-definitions/{_uid}/unlink-document", {"document_id": _uid}),
    ("/admin/groups/ADMIN/add-member", {"user_email": "nobody@test.com"}),
    ("/admin/groups/ADMIN/remove-member", {"user_id": _uid}),
    (
        "/admin/organizations/create",
        {"name": "Smoke Org", "initial_site_name": "Smoke Org Primary Site"},
    ),
    (f"/admin/organizations/{_uid}/delete", {}),
    (f"/admin/organizations/{_uid}/edit", {"name": "Upd"}),
    (f"/admin/organizations/{_uid}/sites/new", {"name": "Site1"}),
    (f"/admin/organizations/{_uid}/users/new", {"email": "u@t.com"}),
    ("/admin/settings/api-tokens", {"name": "tok"}),
    (f"/admin/settings/api-tokens/{_uid}/revoke", {}),
    ("/admin/settings/refresh-session", {}),
    (f"/admin/sites/{_uid}/edit", {"name": "Site1"}),
    (f"/admin/users/{_uid}/activate", {}),
    (f"/admin/users/{_uid}/deactivate", {}),
    (f"/admin/users/{_uid}/edit", {"name": "X"}),
]


@pytest.mark.db
@pytest.mark.parametrize("path,data", ADMIN_POST)
def test_web_admin_post(db_session, adm_user, setup_org, path, data):
    """Admin POST routes return non-500."""
    c = _client(db_session, adm_user)
    resp = c.post(path, data=data)
    assert resp.status_code != 500, f"POST {path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 302, 303, 400, 404, 410, 422)


# ---------------------------------------------------------------------------
# Internal / intake GET routes
# ---------------------------------------------------------------------------

INTERNAL_GET = [
    f"/documents/{_uid}",
    f"/exceptions/{_exc}",
    f"/manifests/{_man}",
    f"/testkits/{_uid}",
]


@pytest.mark.db
@pytest.mark.parametrize("path", INTERNAL_GET)
def test_web_internal_get(db_session, int_user, setup_org, path):
    """Internal GET pages return non-500."""
    c = _client(db_session, int_user)
    resp = c.get(path)
    assert resp.status_code != 500, f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 302, 404, 410)


# ---------------------------------------------------------------------------
# Internal / intake POST routes
# ---------------------------------------------------------------------------

INTERNAL_POST = [
    (f"/exceptions/{_exc}/assign", {"assigned_to": _uid}),
    (f"/exceptions/{_exc}/close", {}),
    (f"/exceptions/{_exc}/escalate", {}),
    (f"/exceptions/{_exc}/resolve", {"resolution": "ok"}),
]


@pytest.mark.db
@pytest.mark.parametrize("path,data", INTERNAL_POST)
def test_web_internal_post(db_session, int_user, setup_org, path, data):
    """Internal POST routes return non-500."""
    c = _client(db_session, int_user)
    resp = c.post(path, data=data)
    assert resp.status_code != 500, f"POST {path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 302, 303, 400, 404, 410, 422)


# ---------------------------------------------------------------------------
# Regular-user GET routes
# ---------------------------------------------------------------------------

USER_GET = [
    f"/clinicians/{_uid}/edit",
    f"/clinicians/{_uid}/users/new",
    f"/trfs/{_oid}/edit",
    f"/patients/{_uid}",
    f"/patients/{_uid}/edit",
    f"/results-sets/{_uid}",
    f"/results/{_rel}",
    f"/results/{_rel}/artifacts/{_uid}/download",
    f"/results/{_rel}/download-all",
    f"/shipments/{_sid}",
    f"/shipments/{_sid}/edit",
    f"/shipments/{_sid}/add-specimen",
    f"/shipments/{_sid}/search/testkits",
    "/search",
    "/search?q=test&scope=instance",
    "/graph",
    "/dag",
    f"/support/{_uid}",
]


@pytest.mark.db
@pytest.mark.parametrize("path", USER_GET)
def test_web_user_get(db_session, ext_user, setup_org, path):
    """Regular-user GET pages return non-500."""
    c = _client(db_session, ext_user)
    resp = c.get(path)
    assert resp.status_code != 500, f"{path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 302, 307, 404, 410)


# ---------------------------------------------------------------------------
# Regular-user POST routes
# ---------------------------------------------------------------------------

USER_POST = [
    (f"/clinicians/{_uid}/edit", {"first_name": "A"}),
    (f"/clinicians/{_uid}/users/new", {"email": "c@t.com"}),
    (f"/trfs/{_oid}/fulfillment-runs/{_uid}/transition", {"action": "start"}),
    (f"/trfs/{_oid}/edit", {"notes": "x"}),
    (f"/trfs/{_oid}/status", {"status": "ACTIVE"}),
    (f"/patients/{_uid}/edit", {"first_name": "B"}),
    (f"/results-sets/{_uid}/publish", {}),
    (f"/shipments/{_sid}/add-existing-kit", {"testkit_id": _uid}),
    (f"/shipments/{_sid}/add-kit", {"label": "K1"}),
    (f"/testkits/{_tid}/link-trf", {"trf_euid": _oid}),
    (f"/testkits/{_tid}/unlink-trf", {"trf_euid": _oid}),
    (f"/testkits/{_tid}/create-bloom-tube", {"test_euid": _uid}),
    (f"/shipments/{_sid}/edit", {"notes": "x"}),
    (f"/shipments/{_sid}/receive", {}),
    (f"/shipments/{_sid}/remove-item", {"item_id": _uid}),
    (f"/shipments/{_sid}/ship", {}),
    (f"/support/{_uid}/resolve", {"resolution_notes": "ok"}),
]


@pytest.mark.db
@pytest.mark.parametrize("path,data", USER_POST)
def test_web_user_post(db_session, ext_user, setup_org, path, data):
    """Regular-user POST routes return non-500."""
    c = _client(db_session, ext_user)
    resp = c.post(path, data=data)
    assert resp.status_code != 500, f"POST {path} returned 500: {resp.text[:200]}"
    assert resp.status_code in (200, 302, 303, 400, 404, 410, 422)


# =============================================================================
# Global Exception Handler Tests
# =============================================================================


@pytest.mark.db
def test_global_exception_handler_html(db_session, ext_user, setup_org):
    """Unhandled exception returns generic 500 HTML with trace ID."""
    # Add a temporary route that raises an unhandled exception
    from fastapi import APIRouter

    from app.main import app as _app

    err_router = APIRouter()

    @err_router.get("/test-500-html")
    async def raise_error():
        raise RuntimeError("SECRET_DB_CONNECTION_STRING_LEAKED")

    _app.include_router(err_router)

    try:
        c = _client(db_session, ext_user)
        resp = c.get("/test-500-html")
        assert resp.status_code == 500
        body = resp.text
        # Must NOT contain the secret
        assert "SECRET_DB_CONNECTION_STRING_LEAKED" not in body
        # Must contain a trace ID (UUID4 format)
        import re

        assert re.search(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", body)
        # Must contain generic error message
        assert "unexpected error" in body.lower() or "An Unexpected Error" in body
    finally:
        # Remove the test route
        _app.router.routes = [
            r for r in _app.router.routes if not (hasattr(r, "path") and r.path == "/test-500-html")
        ]


@pytest.mark.db
def test_global_exception_handler_json(db_session, ext_user, setup_org):
    """Unhandled exception on API path returns generic JSON with trace ID."""
    from fastapi import APIRouter

    from app.main import app as _app

    err_router = APIRouter(prefix="/api")

    @err_router.get("/test-500-json")
    async def raise_error():
        raise RuntimeError("INTERNAL_SECRET_LEAK")

    _app.include_router(err_router)

    try:
        c = _client(db_session, ext_user)
        resp = c.get("/api/test-500-json", headers={"Accept": "application/json"})
        assert resp.status_code == 500
        data = resp.json()
        # Must NOT contain the secret
        assert "INTERNAL_SECRET_LEAK" not in str(data)
        # Must have trace_id
        assert "trace_id" in data
        # Must have generic detail
        assert "unexpected error" in data["detail"].lower()
    finally:
        _app.router.routes = [
            r
            for r in _app.router.routes
            if not (hasattr(r, "path") and r.path == "/api/test-500-json")
        ]
