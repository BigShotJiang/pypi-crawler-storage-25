"""Tests for User API Token authentication.

Tests cover:
1. Token creation (requires API_ACCESS group)
2. Token authentication on API endpoints
3. Token validation (expired, revoked, invalid)
4. Endpoints fail without authentication
5. Usage tracking
"""

import uuid
from types import SimpleNamespace
from typing import Any

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.db.engine import get_db
from app.domain.enums import AccessScope, SystemGroup
from app.domain.services.groups import GroupCreate, UserGroupService
from app.domain.services.user_api_tokens import (
    TokenCreate,
    UserAPITokenService,
    generate_token,
    hash_token,
)
from app.domain.services.users import UserCreate, UserService
from app.main import app
from app.persistence.tapdb.orm_models.core import Organization
from app.persistence.tapdb.orm_models.user_api_tokens import (
    TokenStatus,
    UserAPIToken,
    UserAPITokenRevision,
)
from tests.tapdb_test_helpers import ensure_tapdb_org

# --- Fixtures ---


@pytest.fixture
def test_tenant(db_session: Session) -> Organization:
    """Create a test tenant organization."""
    org_id = uuid.uuid4()
    ensure_tapdb_org(db_session, org_id, name="test-tenant", display_name="Test Tenant")
    db_session.flush()
    return SimpleNamespace(id=org_id, uid=org_id)


@pytest.fixture
def api_access_group(db_session: Session):
    """Get or create the API_ACCESS system group."""
    group_svc = UserGroupService(db_session, tenant_id=None)
    group = group_svc.get_group_by_code(SystemGroup.API_ACCESS.value)
    if group is not None:
        return group
    group, _ = group_svc.create_group(
        GroupCreate(
            group_code=SystemGroup.API_ACCESS.value,
            name="API Access",
            description="Users who can create personal API tokens",
            access_scope=AccessScope.SYSTEM,
        ),
        created_by=None,
    )
    return group


@pytest.fixture
def test_user_profile(db_session: Session, test_tenant: Organization):
    """Create a test user profile."""
    user = UserService(db_session).create(
        UserCreate(
            cognito_sub=str(uuid.uuid4()),
            email="testuser@example.com",
            name="Test User",
            tenant_id=test_tenant.uid,
            roles=["EXTERNAL_USER"],
        )
    )
    return user


@pytest.fixture
def user_with_api_access(db_session: Session, test_user_profile, api_access_group):
    """Create a user with API_ACCESS group membership."""
    UserGroupService(db_session, tenant_id=test_user_profile.tenant_id).add_user_to_group(
        user_id=uuid.UUID(test_user_profile.cognito_sub),
        group_euid=api_access_group.euid,
        added_by=None,
    )
    return test_user_profile


@pytest.fixture
def internal_user_with_api_access(db_session: Session, test_tenant: Organization, api_access_group):
    """Create an internal user with API_ACCESS group membership."""
    user = UserService(db_session).create(
        UserCreate(
            cognito_sub=str(uuid.uuid4()),
            email="internal@example.com",
            name="Internal User",
            tenant_id=test_tenant.uid,
            roles=["INTERNAL_USER"],
        )
    )
    UserGroupService(db_session, tenant_id=user.tenant_id).add_user_to_group(
        user_id=uuid.UUID(user.cognito_sub),
        group_euid=api_access_group.euid,
        added_by=None,
    )
    return user


@pytest.fixture
def valid_api_token(
    db_session: Session, user_with_api_access: Any, test_tenant: Organization
) -> tuple[str, UserAPIToken, UserAPITokenRevision]:
    """Create a valid API token and return (plaintext_token, token, revision)."""
    svc = UserAPITokenService(db_session, test_tenant.uid)
    token, revision, plaintext = svc.create(
        user_id=uuid.UUID(user_with_api_access.cognito_sub),
        data=TokenCreate(token_name="Test Token", expires_in_days=30),
        created_by=uuid.UUID(user_with_api_access.cognito_sub),
    )
    return plaintext, token, revision


@pytest.fixture
def valid_internal_api_token(
    db_session: Session, internal_user_with_api_access: Any, test_tenant: Organization
) -> tuple[str, UserAPIToken, UserAPITokenRevision]:
    """Create a valid API token for an internal user."""
    svc = UserAPITokenService(db_session, test_tenant.uid)
    token, revision, plaintext = svc.create(
        user_id=uuid.UUID(internal_user_with_api_access.cognito_sub),
        data=TokenCreate(token_name="Internal Web Token", expires_in_days=30),
        created_by=uuid.UUID(internal_user_with_api_access.cognito_sub),
    )
    return plaintext, token, revision


@pytest.fixture
def unauthenticated_client(db_session: Session) -> TestClient:
    """Create a test client with no authentication."""

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    app.dependency_overrides[get_db] = override_get_db

    with TestClient(app) as c:
        yield c

    app.dependency_overrides.clear()


# --- Token Generation Tests ---


@pytest.mark.db
class TestTokenGeneration:
    """Test token generation and hashing."""

    def test_generate_token_has_prefix(self):
        """Generated tokens should have lsmc_ prefix."""
        token = generate_token()
        assert token.startswith("lsmc_")

    def test_generate_token_length(self):
        """Generated tokens should be 69 chars (5 prefix + 64 hex)."""
        token = generate_token()
        assert len(token) == 69  # "lsmc_" (5) + 64 hex chars

    def test_generate_token_unique(self):
        """Each generated token should be unique."""
        tokens = [generate_token() for _ in range(100)]
        assert len(set(tokens)) == 100

    def test_hash_token_deterministic(self):
        """Hashing the same token should produce the same hash."""
        token = "lsmc_abc123"
        hash1 = hash_token(token)
        hash2 = hash_token(token)
        assert hash1 == hash2

    def test_hash_token_different_for_different_tokens(self):
        """Different tokens should produce different hashes."""
        hash1 = hash_token("lsmc_token1")
        hash2 = hash_token("lsmc_token2")
        assert hash1 != hash2


# --- Token Service Tests ---


@pytest.mark.db
class TestTokenService:
    """Test UserAPITokenService operations."""

    def test_user_without_api_access_cannot_create_token(
        self, db_session: Session, test_user_profile: Any, test_tenant: Organization
    ):
        """Users without API_ACCESS group cannot create tokens."""
        svc = UserAPITokenService(db_session, test_tenant.uid)
        assert not svc.user_has_api_access(uuid.UUID(test_user_profile.cognito_sub))

    def test_user_with_api_access_can_create_token(
        self, db_session: Session, user_with_api_access: Any, test_tenant: Organization
    ):
        """Users with API_ACCESS group can create tokens."""
        svc = UserAPITokenService(db_session, test_tenant.uid)
        assert svc.user_has_api_access(uuid.UUID(user_with_api_access.cognito_sub))

    def test_create_token_returns_plaintext_only_once(
        self, db_session: Session, user_with_api_access: Any, test_tenant: Organization
    ):
        """Token creation returns plaintext token (shown only once)."""
        svc = UserAPITokenService(db_session, test_tenant.uid)
        token, revision, plaintext = svc.create(
            user_id=uuid.UUID(user_with_api_access.cognito_sub),
            data=TokenCreate(token_name="My Token", expires_in_days=30),
            created_by=uuid.UUID(user_with_api_access.cognito_sub),
        )

        assert plaintext.startswith("lsmc_")
        assert token.token_name == "My Token"
        assert revision.status == TokenStatus.ACTIVE.value
        # Hash is stored, not plaintext
        assert revision.token_hash != plaintext
        assert revision.token_hash == hash_token(plaintext)

    def test_validate_valid_token(
        self, db_session: Session, valid_api_token, test_tenant: Organization
    ):
        """Valid token should validate successfully."""
        plaintext, token, revision = valid_api_token
        svc = UserAPITokenService(db_session, test_tenant.uid)

        result = svc.validate(plaintext)
        assert result.is_valid
        assert result.token_id == token.euid
        assert result.user_id == token.user_id

    def test_validate_invalid_token(self, db_session: Session, test_tenant: Organization):
        """Invalid token should fail validation."""
        svc = UserAPITokenService(db_session, test_tenant.uid)
        result = svc.validate("lsmc_invalidtoken123456789012345678901234567890123456789012345678")
        assert not result.is_valid

    def test_validate_revoked_token(
        self,
        db_session: Session,
        valid_api_token,
        user_with_api_access: Any,
        test_tenant: Organization,
    ):
        """Revoked token should fail validation."""
        plaintext, token, _ = valid_api_token
        svc = UserAPITokenService(db_session, test_tenant.uid)

        # Revoke the token
        svc.revoke(
            token.euid, revoked_by=uuid.UUID(user_with_api_access.cognito_sub), reason="Test revoke"
        )

        result = svc.validate(plaintext)
        assert not result.is_valid

    def test_validate_expired_token(
        self,
        db_session: Session,
        user_with_api_access: Any,
        api_access_group: Any,
        test_tenant: Organization,
    ):
        """Expired token should fail validation."""
        svc = UserAPITokenService(db_session, test_tenant.uid)
        _token, _revision, plaintext = svc.create(
            user_id=uuid.UUID(user_with_api_access.cognito_sub),
            data=TokenCreate(token_name="Expired Token", expires_in_days=-1),
            created_by=uuid.UUID(user_with_api_access.cognito_sub),
        )
        result = svc.validate(plaintext)
        assert not result.is_valid


# --- API Endpoint Authentication Tests ---


@pytest.mark.db
class TestAPIEndpointsWithToken:
    """Test API endpoints accept Bearer token authentication."""

    def test_orders_endpoint_with_valid_token(
        self, unauthenticated_client: TestClient, valid_api_token
    ):
        """GET /api/patients should succeed with valid Bearer token."""
        plaintext, _, _ = valid_api_token

        response = unauthenticated_client.get(
            "/api/patients",
            headers={"Authorization": f"Bearer {plaintext}"},
        )
        assert response.status_code == status.HTTP_200_OK

    def test_orders_endpoint_without_token_fails(self, unauthenticated_client: TestClient):
        """GET /api/patients should fail without authentication."""
        response = unauthenticated_client.get("/api/patients")
        assert response.status_code == status.HTTP_401_UNAUTHORIZED
        assert response.json()["detail"] == "Not authenticated"

    def test_orders_endpoint_with_invalid_token_fails(self, unauthenticated_client: TestClient):
        """GET /api/patients should fail with invalid token."""
        response = unauthenticated_client.get(
            "/api/patients",
            headers={
                "Authorization": "Bearer lsmc_invalidtoken12345678901234567890123456789012345678901234"
            },
        )
        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    def test_orders_endpoint_with_malformed_token_fails(self, unauthenticated_client: TestClient):
        """GET /api/patients should fail with malformed token (no lsmc_ prefix)."""
        response = unauthenticated_client.get(
            "/api/patients",
            headers={"Authorization": "Bearer notavalidtoken"},
        )
        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    def test_orders_endpoint_with_revoked_token_fails(
        self,
        db_session: Session,
        unauthenticated_client: TestClient,
        valid_api_token,
        user_with_api_access,
        test_tenant,
    ):
        """GET /api/patients should fail with revoked token."""
        plaintext, token, _ = valid_api_token
        svc = UserAPITokenService(db_session, test_tenant.uid)
        svc.revoke(
            token.euid, revoked_by=uuid.UUID(user_with_api_access.cognito_sub), reason="Revoked"
        )

        response = unauthenticated_client.get(
            "/api/patients",
            headers={"Authorization": f"Bearer {plaintext}"},
        )
        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    def test_internal_web_route_accepts_valid_token(
        self,
        unauthenticated_client: TestClient,
        valid_internal_api_token,
    ):
        """Internal web pages should accept bearer tokens without redirecting to Cognito."""
        plaintext, _, _ = valid_internal_api_token

        response = unauthenticated_client.get(
            "/accessioning/minimal",
            headers={"Authorization": f"Bearer {plaintext}"},
            follow_redirects=False,
        )

        assert response.status_code == status.HTTP_200_OK
        assert "Minimal Accessioning" in response.text


@pytest.mark.db
class TestUsageTracking:
    """Test that token usage is tracked."""

    def test_last_used_at_updated_on_use(self, db_session: Session, valid_api_token, test_tenant):
        """Token's last_used_at should be updated when usage is recorded."""
        plaintext, token, _ = valid_api_token

        # Check last_used_at was updated
        svc = UserAPITokenService(db_session, test_tenant.uid)
        svc.update_last_used(token.euid)
        token_info = svc.get_token(token.euid)
        assert token_info is not None
        _, revision = token_info
        assert revision.last_used_at is not None

    def test_usage_log_created_on_use(self, db_session: Session, valid_api_token, test_tenant):
        """Usage log entry should be created when usage is recorded."""
        plaintext, token, _ = valid_api_token

        # Check usage log
        svc = UserAPITokenService(db_session, test_tenant.uid)
        svc.log_usage(
            token_id=token.euid,
            tenant_id=test_tenant.uid,
            endpoint="/api/patients",
            http_method="GET",
            ip_address="127.0.0.1",
            user_agent="pytest",
            response_status=200,
        )
        stats = svc.get_usage_stats(token.euid)
        assert stats["total_requests"] >= 1


@pytest.mark.db
class TestMultipleEndpoints:
    """Test token auth works across multiple API endpoints."""

    def test_health_endpoint_no_auth_required(self, unauthenticated_client: TestClient):
        """Health endpoints should work without authentication."""
        for path in ("/health", "/healthz", "/readyz"):
            response = unauthenticated_client.get(path)
            assert response.status_code == status.HTTP_200_OK

    def test_api_patients_requires_auth(self, unauthenticated_client: TestClient):
        """GET /api/patients requires authentication."""
        response = unauthenticated_client.get("/api/patients")
        assert response.status_code == status.HTTP_401_UNAUTHORIZED

    def test_api_shipments_requires_auth(self, unauthenticated_client: TestClient):
        """GET /api/shipments requires authentication."""
        response = unauthenticated_client.get("/api/shipments")
        assert response.status_code in [status.HTTP_401_UNAUTHORIZED, status.HTTP_404_NOT_FOUND]
