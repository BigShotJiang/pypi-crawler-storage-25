"""Unit tests for atlas db TapDB orchestration."""

from __future__ import annotations

from types import SimpleNamespace

from app.cli import db as db_cli


def test_build_local_uses_tapdb_bootstrap(monkeypatch):
    tapdb_calls: list[list[str]] = []
    overlay_calls: list[tuple[int, int]] = []

    monkeypatch.setattr(
        db_cli,
        "run_tapdb_cli",
        lambda **kwargs: (
            tapdb_calls.append(kwargs["args"])
            or SimpleNamespace(stdout="", stderr="", returncode=0)
        ),
    )
    monkeypatch.setattr(
        db_cli,
        "export_database_url_for_target",
        lambda **_kwargs: "postgresql+psycopg2://atlas@localhost:5432/atlas_dev",
    )
    monkeypatch.setattr(
        db_cli,
        "_apply_atlas_overlay",
        lambda *, start_step, total_steps: overlay_calls.append((start_step, total_steps)),
    )

    db_cli.build(
        target="local",
        cluster="",
        region="us-west-2",
        profile="lsmc",
        namespace="lsmc-atlas",
    )

    assert tapdb_calls[0] == ["bootstrap", "local", "--no-gui"]
    assert overlay_calls == [(3, 3)]


def test_reset_uses_tapdb_delete_then_bootstrap(monkeypatch):
    tapdb_calls: list[list[str]] = []
    overlay_calls: list[tuple[int, int]] = []

    monkeypatch.setattr(
        db_cli,
        "run_tapdb_cli",
        lambda **kwargs: (
            tapdb_calls.append(kwargs["args"])
            or SimpleNamespace(stdout="", stderr="", returncode=0)
        ),
    )
    monkeypatch.setattr(
        db_cli,
        "export_database_url_for_target",
        lambda **_kwargs: "postgresql+psycopg2://atlas@localhost:5432/atlas_dev",
    )
    monkeypatch.setattr(
        db_cli,
        "_apply_atlas_overlay",
        lambda *, start_step, total_steps: overlay_calls.append((start_step, total_steps)),
    )

    db_cli.reset(
        force=True,
        target="local",
        cluster="",
        region="us-west-2",
        profile="lsmc",
        namespace="lsmc-atlas",
    )

    assert tapdb_calls[0] == ["db", "delete", "dev", "--force"]
    assert tapdb_calls[1] == ["bootstrap", "local", "--no-gui"]
    assert overlay_calls == [(4, 4)]


def test_nuke_routes_destructive_action_through_tapdb(monkeypatch):
    tapdb_calls: list[list[str]] = []

    monkeypatch.setattr(
        db_cli,
        "run_tapdb_cli",
        lambda **kwargs: (
            tapdb_calls.append(kwargs["args"])
            or SimpleNamespace(stdout="", stderr="", returncode=0)
        ),
    )

    db_cli.nuke(
        force=True,
        target="local",
        region="us-west-2",
        profile="lsmc",
        namespace="lsmc-atlas",
    )

    assert tapdb_calls == [["db", "delete", "dev", "--force"]]
