"""Security regression tests for LSMC Atlas.

Covers fixes: SEC-40 (CSRF bypass), SEC-41 (timing-safe API key),
SEC-47 (security headers), SEC-52 (entity_type enum validation).
"""

from __future__ import annotations

import inspect
import uuid

import pytest
from starlette.requests import Request
from starlette.testclient import TestClient

from app.main import app
from app.settings import settings


@pytest.fixture
def raw_client():
    """TestClient with NO dependency overrides — tests real middleware/auth."""
    app.dependency_overrides.clear()
    with TestClient(app, raise_server_exceptions=False) as c:
        yield c
    app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# SEC-40 — CSRF Bearer prefix bypass
# ---------------------------------------------------------------------------


class TestCSRFBearerBypass:
    """Only Bearer tokens prefixed with 'lsmc_' should skip CSRF checks.

    csrf_protect is a FastAPI dependency (not global middleware), so we test
    the function directly with crafted Request objects.
    """

    @staticmethod
    def _make_request(auth_header: str | None = None) -> Request:
        """Build a minimal Starlette Request for csrf_protect."""
        from starlette.requests import Request as StarletteRequest

        headers = {"content-type": "application/json"}
        if auth_header is not None:
            headers["authorization"] = auth_header
        scope = {
            "type": "http",
            "method": "POST",
            "headers": [(k.encode(), v.encode()) for k, v in headers.items()],
            "path": "/test",
            "query_string": b"",
            "root_path": "",
        }
        req = StarletteRequest(scope)
        # Provide a session dict so the middleware doesn't crash
        req.scope["session"] = {}
        return req

    @pytest.mark.asyncio
    async def test_csrf_skip_for_valid_lsmc_bearer_token(self):
        """POST with 'Bearer lsmc_xxx' should NOT raise CSRF 403."""
        from app.auth.middleware import csrf_protect

        req = self._make_request("Bearer lsmc_test_token_abc")
        # Should return without raising
        await csrf_protect(req)

    @pytest.mark.asyncio
    async def test_csrf_enforced_for_arbitrary_bearer_token(self):
        """POST with 'Bearer arbitrary_value' MUST raise CSRF 403."""
        from fastapi import HTTPException

        from app.auth.middleware import csrf_protect

        req = self._make_request("Bearer arbitrary_value")
        with pytest.raises(HTTPException) as exc_info:
            await csrf_protect(req)
        assert exc_info.value.status_code == 403
        assert "CSRF" in str(exc_info.value.detail)

    @pytest.mark.asyncio
    async def test_csrf_enforced_for_empty_bearer(self):
        """POST with 'Bearer ' (empty value) MUST raise CSRF 403."""
        from fastapi import HTTPException

        from app.auth.middleware import csrf_protect

        req = self._make_request("Bearer ")
        with pytest.raises(HTTPException) as exc_info:
            await csrf_protect(req)
        assert exc_info.value.status_code == 403
        assert "CSRF" in str(exc_info.value.detail)


# ---------------------------------------------------------------------------
# SEC-41 — Timing-safe API key comparison
# ---------------------------------------------------------------------------


@pytest.mark.db
class TestInternalAPIKey:
    """Internal API key verification must use hmac.compare_digest."""

    def test_internal_api_key_rejects_missing_key(self, raw_client: TestClient):
        resp = raw_client.get(
            f"/internal/trfs/{uuid.uuid4()}",
            params={"tenant_id": str(uuid.uuid4())},
        )
        assert resp.status_code == 401

    def test_internal_api_key_rejects_wrong_key(self, raw_client: TestClient):
        resp = raw_client.get(
            f"/internal/trfs/{uuid.uuid4()}",
            params={"tenant_id": str(uuid.uuid4())},
            headers={"X-Api-Key": "wrong-key-value"},
        )
        assert resp.status_code == 401

    def test_internal_api_key_accepts_correct_key(self, raw_client: TestClient):
        """With the correct key the request passes auth (may fail later for other reasons)."""
        resp = raw_client.get(
            f"/internal/trfs/{uuid.uuid4()}",
            params={"tenant_id": str(uuid.uuid4())},
            headers={"X-Api-Key": settings.internal_api_key},
        )
        # Should NOT be 401 — downstream 404 is fine
        assert resp.status_code != 401

    def test_internal_api_key_uses_hmac_compare(self):
        """verify_internal_api_key source uses hmac.compare_digest."""
        from app.api.routes.internal import verify_internal_api_key

        src = inspect.getsource(verify_internal_api_key)
        assert "hmac.compare_digest" in src, (
            "verify_internal_api_key must use hmac.compare_digest for timing-safe comparison"
        )


# ---------------------------------------------------------------------------
# SEC-47 — Security headers middleware
# ---------------------------------------------------------------------------


@pytest.mark.db
class TestSecurityHeaders:
    """SecurityHeadersMiddleware must add required headers to every response."""

    def test_response_has_x_frame_options_deny(self, raw_client: TestClient):
        resp = raw_client.get("/health")
        assert resp.headers.get("X-Frame-Options") == "DENY"

    def test_response_has_x_content_type_options(self, raw_client: TestClient):
        resp = raw_client.get("/health")
        assert resp.headers.get("X-Content-Type-Options") == "nosniff"

    def test_response_has_referrer_policy(self, raw_client: TestClient):
        resp = raw_client.get("/health")
        assert resp.headers.get("Referrer-Policy") == "strict-origin-when-cross-origin"

    def test_response_has_permissions_policy(self, raw_client: TestClient):
        resp = raw_client.get("/health")
        assert "Permissions-Policy" in resp.headers

    def test_response_has_content_security_policy(self, raw_client: TestClient):
        resp = raw_client.get("/health")
        assert "Content-Security-Policy" in resp.headers
        assert "default-src" in resp.headers["Content-Security-Policy"]


# ---------------------------------------------------------------------------
# SEC-52 — entity_type enum validation
# ---------------------------------------------------------------------------


@pytest.mark.db
class TestEntityTypeValidation:
    """entity_type parameter must be validated against allowed enum values."""

    def _make_auth_client(self) -> TestClient:
        """Client with auth overridden (including require_internal)."""
        from app.auth.dependencies import CurrentUser, get_current_user, require_internal
        from app.auth.rbac import Role

        user = CurrentUser(
            sub=str(uuid.uuid4()),
            email="internal@lsmc.bio",
            name="Internal User",
            tenant_id=uuid.uuid4(),
            roles=[Role.INTERNAL_USER.value],
        )
        app.dependency_overrides[get_current_user] = lambda: user
        app.dependency_overrides[require_internal] = lambda: user
        return TestClient(app, raise_server_exceptions=False)

    def test_entity_type_rejects_invalid_value(self):
        """POST with entity_type='INVALID' must fail with 422."""
        client = self._make_auth_client()
        try:
            resp = client.post(
                f"/api/documents/{uuid.uuid4()}/link",
                json={"entity_type": "INVALID", "entity_id": str(uuid.uuid4())},
            )
            assert resp.status_code == 422, (
                f"Expected 422 for invalid entity_type, got {resp.status_code}"
            )
        finally:
            app.dependency_overrides.clear()

    def test_entity_type_accepts_valid_value(self):
        """POST with entity_type='ORDER' should pass validation (not 422)."""
        client = self._make_auth_client()
        try:
            resp = client.post(
                f"/api/documents/{uuid.uuid4()}/link",
                json={"entity_type": "ORDER", "entity_id": str(uuid.uuid4())},
            )
            # May fail for other reasons (404 missing doc, 500 no DB) but NOT 422
            assert resp.status_code != 422, (
                "Got 422 for valid entity_type 'ORDER' — validation is too strict"
            )
        finally:
            app.dependency_overrides.clear()
