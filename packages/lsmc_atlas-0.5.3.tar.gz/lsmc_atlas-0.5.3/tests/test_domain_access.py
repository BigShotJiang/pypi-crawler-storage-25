from __future__ import annotations

from contextlib import asynccontextmanager

import pytest
from fastapi.testclient import TestClient

from app.main import create_app


@pytest.fixture
def client(monkeypatch: pytest.MonkeyPatch) -> TestClient:
    @asynccontextmanager
    async def _no_op_lifespan(_app):
        yield

    monkeypatch.setattr("app.main.lifespan", _no_op_lifespan)
    app = create_app()
    with TestClient(app, raise_server_exceptions=False) as test_client:
        yield test_client


def test_atlas_allows_approved_origin_preflight(client: TestClient) -> None:
    response = client.options(
        "/health",
        headers={
            "Origin": "https://portal.lsmc.bio",
            "Access-Control-Request-Method": "GET",
        },
    )

    assert response.status_code == 200
    assert response.headers["access-control-allow-origin"] == "https://portal.lsmc.bio"


def test_atlas_rejects_disallowed_origin(client: TestClient) -> None:
    response = client.options(
        "/health",
        headers={
            "Origin": "https://evil.example.com",
            "Access-Control-Request-Method": "GET",
        },
    )

    assert response.status_code == 403
    assert response.text == "Origin not allowed"


def test_atlas_rejects_disallowed_host(client: TestClient) -> None:
    """Host filtering is now handled upstream (load balancer / security groups).

    TrustedHostMiddleware uses allowed_hosts=['*'], so arbitrary Host headers
    are permitted at the application layer.
    """
    response = client.get("/health", headers={"host": "evil.example.com"})

    # Middleware allows all hosts now — filtering is done at infra layer
    assert response.status_code == 200
