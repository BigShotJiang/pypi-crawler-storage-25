"""Tests for user group management."""

import uuid

from app.domain.services.groups import GroupCreate, GroupInfo, UserGroupService
from app.persistence.tapdb.orm_models.groups import (
    AccessScope,
    SystemGroup,
    UserGroup,
    UserGroupMembership,
    UserGroupRevision,
)


class TestGroupModels:
    """Test group model definitions."""

    def test_access_scope_enum(self):
        """Test AccessScope enum values."""
        assert AccessScope.TENANT.value == "TENANT"
        assert AccessScope.CROSS_TENANT.value == "CROSS_TENANT"
        assert AccessScope.SYSTEM.value == "SYSTEM"

    def test_system_group_enum(self):
        """Test SystemGroup enum values."""
        assert SystemGroup.CUSTOMER.value == "CUSTOMER"
        assert SystemGroup.LSMC_STAFF.value == "LSMC_STAFF"
        assert SystemGroup.ADMIN.value == "ADMIN"

    def test_user_group_model_structure(self):
        """Test UserGroup model has required fields."""
        # Check the model class has expected attributes via __table__
        columns = {c.name for c in UserGroup.__table__.columns}
        assert "id" in columns
        assert "tenant_id" in columns
        assert "group_code" in columns
        assert "created_at" in columns
        assert "created_by" in columns

    def test_user_group_revision_model_structure(self):
        """Test UserGroupRevision model has required fields."""
        columns = {c.name for c in UserGroupRevision.__table__.columns}
        assert "revision_id" in columns
        assert "group_id" in columns
        assert "revision_no" in columns
        assert "name" in columns
        assert "description" in columns
        assert "access_scope" in columns
        assert "default_roles" in columns
        assert "is_system_group" in columns
        assert "is_active" in columns

    def test_user_group_membership_model_structure(self):
        """Test UserGroupMembership model has required fields."""
        columns = {c.name for c in UserGroupMembership.__table__.columns}
        assert "id" in columns
        assert "user_id" in columns
        assert "group_id" in columns
        assert "is_active" in columns
        assert "added_by" in columns


class TestGroupCreate:
    """Test GroupCreate dataclass."""

    def test_default_values(self):
        """Test GroupCreate default values."""
        data = GroupCreate(
            group_code="TEST_GROUP",
            name="Test Group",
        )

        assert data.group_code == "TEST_GROUP"
        assert data.name == "Test Group"
        assert data.description is None
        assert data.access_scope == AccessScope.TENANT
        assert data.default_roles is None

    def test_custom_values(self):
        """Test GroupCreate with custom values."""
        data = GroupCreate(
            group_code="CUSTOM",
            name="Custom Group",
            description="A custom group",
            access_scope=AccessScope.SYSTEM,
            default_roles=["ADMIN", "READ_WRITE"],
        )

        assert data.group_code == "CUSTOM"
        assert data.description == "A custom group"
        assert data.access_scope == AccessScope.SYSTEM
        assert data.default_roles == ["ADMIN", "READ_WRITE"]


class TestGroupInfo:
    """Test GroupInfo dataclass."""

    def test_group_info_creation(self):
        """Test GroupInfo creation."""
        info = GroupInfo(
            euid="GRP-1",
            group_code="TEST",
            name="Test Group",
            description="Test description",
            access_scope="tenant",
            default_roles=["USER"],
            is_system_group=False,
            is_active=True,
            member_count=5,
        )

        assert info.euid == "GRP-1"
        assert info.group_code == "TEST"
        assert info.member_count == 5
        assert info.is_active is True


class TestUserGroupService:
    """Test UserGroupService class structure."""

    def test_service_initialization(self):
        """Test service can be initialized."""

        # Mock db session
        class MockDB:
            pass

        tenant_id = uuid.uuid4()
        service = UserGroupService(MockDB(), tenant_id)

        assert service.tenant_id == tenant_id
        assert service.db is not None

    def test_service_has_required_methods(self):
        """Test service has required methods."""
        assert hasattr(UserGroupService, "create_group")
        assert hasattr(UserGroupService, "get_group_by_code")
        assert hasattr(UserGroupService, "add_user_to_group")
