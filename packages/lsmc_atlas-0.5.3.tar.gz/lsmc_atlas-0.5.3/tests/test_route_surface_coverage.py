"""Route-surface smoke coverage.

Ensures every registered API endpoint and GUI route is exercised by at least one
request in tests.
"""

from __future__ import annotations

import re
import uuid
from collections.abc import Generator

import pytest
from fastapi.routing import APIRoute
from fastapi.testclient import TestClient
from starlette.routing import Route

from app.api.routes.internal import verify_internal_api_key
from app.auth.dependencies import (
    CurrentUser,
    IntegrationClientPrincipal,
    get_bloom_integration_client,
    get_current_user,
    get_current_user_or_token,
    get_current_user_web,
    require_internal,
    require_org_admin,
)
from app.auth.middleware import csrf_protect
from app.auth.rbac import Role
from app.db.engine import get_db
from app.domain.services.orgs import OrganizationCreate, OrganizationService
from app.main import app
from app.web.routes.pages import require_admin

_PARAM_RE = re.compile(r"\{([^}]+)\}")


@pytest.fixture
def ensure_org_for_surface(db_session):
    org_svc = OrganizationService(db_session)
    existing = org_svc.list_all(active_only=False)
    if existing:
        return existing[0]
    return org_svc.create(
        OrganizationCreate(
            name="surface-org",
            display_name="Surface Org",
            org_type="clinic",
        ),
        created_by=None,
    )


@pytest.fixture
def admin_user_for_surface(ensure_org_for_surface) -> CurrentUser:
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="surface-admin@lsmc.bio",
        name="Surface Admin",
        tenant_id=ensure_org_for_surface.uid,
        roles=[Role.ADMIN.value, Role.INTERNAL_USER.value, Role.EXTERNAL_USER_ADMIN.value],
    )


@pytest.fixture
def surface_client(
    db_session,
    admin_user_for_surface: CurrentUser,
    ensure_org_for_surface,
) -> Generator[TestClient, None, None]:
    """Client with broad auth/internal overrides for route-surface smoke."""

    def override_get_db():
        yield db_session

    def override_user():
        return admin_user_for_surface

    async def override_csrf():
        return None

    async def override_internal_api_key():
        return "test-internal-key"

    def override_bloom_client():
        return IntegrationClientPrincipal(
            client_id=uuid.uuid4(),
            tenant_id=admin_user_for_surface.tenant_id,
            client_name="surface-bloom-client",
            permissions=["bloom:atlas:write", "*"],
            allowed_endpoints=["/api/integrations/bloom/v1"],
        )

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_user
    app.dependency_overrides[get_current_user_web] = override_user
    app.dependency_overrides[get_current_user_or_token] = override_user
    app.dependency_overrides[require_internal] = override_user
    app.dependency_overrides[require_org_admin] = override_user
    app.dependency_overrides[require_admin] = override_user
    app.dependency_overrides[csrf_protect] = override_csrf
    app.dependency_overrides[verify_internal_api_key] = override_internal_api_key
    app.dependency_overrides[get_bloom_integration_client] = override_bloom_client

    with TestClient(app) as client:
        yield client

    app.dependency_overrides.clear()


def _route_methods(route: APIRoute | Route) -> list[str]:
    methods = sorted(m for m in getattr(route, "methods", set()) if m not in {"HEAD", "OPTIONS"})
    return methods


def _placeholder_value(name: str, converter: str | None) -> str:
    lname = name.lower()
    conv = (converter or "").lower()

    if conv == "uuid" or lname == "id" or lname.endswith("_id") or lname.endswith("id"):
        return str(uuid.uuid4())
    if conv == "int":
        return "1"
    if conv == "float":
        return "1.0"
    if conv == "path" or "path" in lname:
        return "sample"
    if "number" in lname:
        return "FAKE-001"
    if "code" in lname:
        return "CODE"
    if "email" in lname:
        return "user@example.com"
    if "name" in lname:
        return "sample"
    return "sample"


def _instantiate_path(path_template: str) -> str:
    def repl(match: re.Match[str]) -> str:
        raw = match.group(1)
        if ":" in raw:
            pname, converter = raw.split(":", 1)
        else:
            pname, converter = raw, None
        return _placeholder_value(pname, converter)

    return _PARAM_RE.sub(repl, path_template)


def _is_api_route(path: str) -> bool:
    return path.startswith("/api/") or path.startswith("/internal/") or path.startswith("/auth/")


def _should_skip(path: str) -> bool:
    if path.startswith("/static"):
        return True
    return path in {"/docs", "/redoc", "/api/docs", "/api/redoc", "/openapi.json"}


def _exercise_route(client: TestClient, *, method: str, path: str, is_api: bool):
    headers = {"Idempotency-Key": "surface-smoke-idem"}

    kwargs = {
        "headers": headers,
        "follow_redirects": False,
    }

    if method in {"POST", "PUT", "PATCH"} or method == "DELETE":
        if is_api:
            kwargs["json"] = {}
        else:
            kwargs["data"] = {}

    return client.request(method, path, **kwargs)


def _collect_routes(*, api: bool) -> list[tuple[str, str]]:
    route_methods: list[tuple[str, str]] = []
    for route in app.routes:
        if not isinstance(route, (APIRoute, Route)):
            continue
        path = getattr(route, "path", "")
        if not path or _should_skip(path):
            continue

        is_api_route = _is_api_route(path)
        if api != is_api_route:
            continue

        concrete_path = _instantiate_path(path)
        for method in _route_methods(route):
            route_methods.append((method, concrete_path))

    # deterministic order for stable failures
    route_methods.sort(key=lambda x: (x[1], x[0]))
    return route_methods


@pytest.mark.db
def test_all_api_endpoints_have_smoke_hit(
    surface_client: TestClient, db_session, admin_user_for_surface
):
    failures: list[str] = []
    exercised = _collect_routes(api=True)

    for method, path in exercised:
        try:
            _exercise_route(surface_client, method=method, path=path, is_api=True)
        except Exception as exc:  # pragma: no cover - defensive for transport errors
            failures.append(f"{method} {path} -> exception: {exc}")

    assert exercised, "No API routes were discovered for smoke coverage"
    assert not failures, "\n".join(failures)


@pytest.mark.db
def test_all_gui_routes_have_smoke_hit(
    surface_client: TestClient, db_session, admin_user_for_surface
):
    failures: list[str] = []
    exercised = _collect_routes(api=False)

    for method, path in exercised:
        try:
            _exercise_route(surface_client, method=method, path=path, is_api=False)
        except Exception as exc:  # pragma: no cover - defensive for transport errors
            failures.append(f"{method} {path} -> exception: {exc}")

    assert exercised, "No GUI routes were discovered for smoke coverage"
    assert not failures, "\n".join(failures)
