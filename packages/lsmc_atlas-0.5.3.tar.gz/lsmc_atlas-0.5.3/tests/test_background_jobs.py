"""Tests for background job scheduler."""

import asyncio
from unittest.mock import Mock

import pytest


class TestBackgroundJobScheduler:
    """Tests for BackgroundJobScheduler."""

    @pytest.mark.asyncio
    async def test_scheduler_start_stop(self):
        """Test scheduler can start and stop cleanly."""
        from app.domain.services.background_jobs import BackgroundJobScheduler

        scheduler = BackgroundJobScheduler()
        await scheduler.start()
        assert scheduler._running is True

        await scheduler.stop()
        assert scheduler._running is False
        assert len(scheduler._jobs) == 0

    @pytest.mark.asyncio
    async def test_scheduler_schedule_recurring_job(self):
        """Test scheduling a recurring job."""
        from app.domain.services.background_jobs import BackgroundJobScheduler

        scheduler = BackgroundJobScheduler()
        await scheduler.start()

        call_count = 0

        def test_job():
            nonlocal call_count
            call_count += 1

        # Schedule job with long interval (won't actually run in test)
        scheduler.schedule_recurring("test_job", test_job, interval_seconds=3600)

        # Job should be registered
        assert "test_job" in scheduler._jobs
        assert not scheduler._jobs["test_job"].done()

        # Clean up
        await scheduler.stop()

    @pytest.mark.asyncio
    async def test_scheduler_replaces_existing_job(self):
        """Test that scheduling a job with same ID replaces the old one."""
        from app.domain.services.background_jobs import BackgroundJobScheduler

        scheduler = BackgroundJobScheduler()
        await scheduler.start()

        mock_job1 = Mock()
        mock_job2 = Mock()

        scheduler.schedule_recurring("same_id", mock_job1, interval_seconds=3600)
        first_task = scheduler._jobs["same_id"]

        scheduler.schedule_recurring("same_id", mock_job2, interval_seconds=3600)
        second_task = scheduler._jobs["same_id"]

        # Should be different task objects
        assert first_task is not second_task

        # Wait a bit for the cancel to propagate
        await asyncio.sleep(0.01)

        await scheduler.stop()

    @pytest.mark.asyncio
    async def test_scheduler_handles_async_jobs(self):
        """Test scheduler handles async job functions."""
        from app.domain.services.background_jobs import BackgroundJobScheduler

        scheduler = BackgroundJobScheduler()
        await scheduler.start()

        async def async_job():
            await asyncio.sleep(0.01)

        scheduler.schedule_recurring("async_job", async_job, interval_seconds=3600)
        assert "async_job" in scheduler._jobs

        await scheduler.stop()

    def test_get_scheduler_singleton(self):
        """Test get_scheduler returns same instance."""
        from app.domain.services.background_jobs import get_scheduler

        scheduler1 = get_scheduler()
        scheduler2 = get_scheduler()
        assert scheduler1 is scheduler2


class TestTrackingUpdateJob:
    """Tests for run_tracking_update_job function."""

    @pytest.mark.asyncio
    async def test_job_skips_when_fedex_unavailable(self):
        """Test that job gracefully skips when FedEx is not available."""
        from app.domain.services.background_jobs import run_tracking_update_job
        from app.domain.services.fedex_tracking import FEDEX_AVAILABLE

        if FEDEX_AVAILABLE:
            pytest.skip("FedEx is available, skipping unavailable test")

        # Should not raise any errors - just returns early
        mock_db_factory = Mock(return_value=Mock())
        await run_tracking_update_job(mock_db_factory)
