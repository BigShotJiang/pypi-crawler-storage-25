"""TapDB runtime integration tests for Atlas database URL resolution."""

from __future__ import annotations

import sys
import types

import pytest

from app.integrations import tapdb_runtime


def test_database_url_is_derived_from_tapdb_config(monkeypatch):
    monkeypatch.setattr(tapdb_runtime, "ensure_tapdb_version", lambda: "3.0.3")
    monkeypatch.setattr(
        tapdb_runtime,
        "_get_tapdb_db_config_for_env",
        lambda env: {
            "host": "localhost",
            "port": "6432",
            "user": "atlas_user",
            "password": "atlas_pw",
            "database": f"atlas_{env}",
        },
    )

    db_url = tapdb_runtime.export_database_url_for_target(
        target="local",
        profile="lsmc",
        region="us-west-2",
        namespace="lsmc-atlas",
    )

    assert db_url == "postgresql+psycopg2://atlas_user:atlas_pw@localhost:6432/atlas_dev"


def test_local_target_maps_to_dev(monkeypatch):
    called: list[str] = []

    monkeypatch.setattr(tapdb_runtime, "ensure_tapdb_version", lambda: "3.0.3")

    def _fake_get_cfg(env: str) -> dict[str, str]:
        called.append(env)
        return {
            "host": "localhost",
            "port": "5432",
            "user": "u",
            "password": "",
            "database": "d",
        }

    monkeypatch.setattr(tapdb_runtime, "_get_tapdb_db_config_for_env", _fake_get_cfg)
    tapdb_runtime.export_database_url_for_target(target="local")
    assert called == ["dev"]


def test_aurora_target_maps_to_prod(monkeypatch):
    called: list[str] = []

    monkeypatch.setattr(tapdb_runtime, "ensure_tapdb_version", lambda: "3.0.3")

    def _fake_get_cfg(env: str) -> dict[str, str]:
        called.append(env)
        return {
            "host": "aurora.cluster.local",
            "port": "5432",
            "user": "u",
            "password": "",
            "database": "d",
        }

    monkeypatch.setattr(tapdb_runtime, "_get_tapdb_db_config_for_env", _fake_get_cfg)
    tapdb_runtime.export_database_url_for_target(target="aurora")
    assert called == ["prod"]


def test_ensure_tapdb_version_allows_local_override(monkeypatch):
    monkeypatch.setattr(tapdb_runtime.importlib.metadata, "version", lambda _: "3.0.3.dev0")
    monkeypatch.setattr(tapdb_runtime, "_is_local_tapdb_override_install", lambda: True)
    monkeypatch.setitem(
        sys.modules,
        "daylily_tapdb",
        types.SimpleNamespace(__version__="3.0.3.dev0"),
    )

    assert tapdb_runtime.ensure_tapdb_version("3.0.3") == "3.0.3.dev0"


def test_ensure_tapdb_version_rejects_non_local_mismatch(monkeypatch):
    monkeypatch.setattr(tapdb_runtime.importlib.metadata, "version", lambda _: "3.0.1.dev0")
    monkeypatch.setattr(tapdb_runtime, "_is_local_tapdb_override_install", lambda: False)
    monkeypatch.setitem(
        sys.modules,
        "daylily_tapdb",
        types.SimpleNamespace(__version__="3.0.0.dev0"),
    )

    with pytest.raises(tapdb_runtime.TapDBRuntimeError):
        tapdb_runtime.ensure_tapdb_version("3.0.3")


def test_resolve_tapdb_config_path_prefers_user_scoped_over_repo_template(
    monkeypatch, tmp_path
):
    user_scoped = (
        tmp_path
        / ".config"
        / "tapdb"
        / "atlas"
        / "lsmc-atlas"
        / "tapdb-config.yaml"
    )
    user_scoped.parent.mkdir(parents=True, exist_ok=True)
    user_scoped.write_text("meta: {}\n", encoding="utf-8")

    monkeypatch.delenv("TAPDB_CONFIG_PATH", raising=False)
    monkeypatch.setenv("HOME", str(tmp_path))

    resolved = tapdb_runtime._resolve_tapdb_config_path(
        namespace="lsmc-atlas",
        client_id="atlas",
    )

    assert resolved == str(user_scoped)
