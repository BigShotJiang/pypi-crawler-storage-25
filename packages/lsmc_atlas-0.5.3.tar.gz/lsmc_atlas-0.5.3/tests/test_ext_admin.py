"""Tests for EXTERNAL_USER_ADMIN role feature.

Tests cover:
1. RBAC unit tests (is_org_admin, permissions, role constants)
2. Token scope constraint tests (_constrain_roles_by_scope)
3. Token scope creation validation (validate_scope_for_creator)
4. Cognito group mapping tests (customer-admins → EXTERNAL_USER_ADMIN)
5. Web route tests (org user management, settings, deactivate/activate)
6. API route tests (org user creation with role validation, token scope)
7. Tenant isolation and privilege escalation prevention
"""

import uuid

import pytest
from fastapi import status
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, _constrain_roles_by_scope
from app.auth.rbac import (
    EXTERNAL_ASSIGNABLE_ROLES,
    ORG_ADMIN_ASSIGNABLE_ROLES,
    ROLE_PERMISSIONS,
    Permission,
    Role,
    can_write,
    is_org_admin,
    is_read_only,
)
from app.db.engine import get_db
from app.domain.enums import AccessScope, SystemGroup, TokenScope
from app.domain.services.groups import GroupCreate, UserGroupService
from app.domain.services.user_api_tokens import UserAPITokenService
from app.domain.services.users import UserCreate, UserService
from app.main import app
from app.persistence.tapdb.orm_models.core import Organization
from app.settings import settings
from tests.tapdb_test_helpers import ensure_tapdb_org

# =============================================================================
# Fixtures
# =============================================================================


def get_permissions(roles: list[str]) -> set[Permission]:
    """Aggregate permissions for a list of role strings."""
    perms: set[Permission] = set()
    for r in roles:
        try:
            perms |= ROLE_PERMISSIONS.get(Role(r), set())
        except ValueError:
            pass
    return perms


@pytest.fixture
def test_tenant_id() -> uuid.UUID:
    """Generate a consistent tenant ID for tests."""
    return uuid.uuid4()


@pytest.fixture
def other_tenant_id_ext() -> uuid.UUID:
    """Second tenant ID for isolation tests."""
    return uuid.uuid4()


@pytest.fixture
def ext_admin_user(test_tenant_id: uuid.UUID) -> CurrentUser:
    """Create an EXTERNAL_USER_ADMIN test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="orgadmin@acme-genetics.com",
        name="Org Admin",
        tenant_id=test_tenant_id,
        roles=[Role.EXTERNAL_USER.value, Role.EXTERNAL_USER_ADMIN.value],
    )


@pytest.fixture
def ext_regular_user(test_tenant_id: uuid.UUID) -> CurrentUser:
    """Create a regular EXTERNAL_USER test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="regular@acme-genetics.com",
        name="Regular User",
        tenant_id=test_tenant_id,
        roles=[Role.EXTERNAL_USER.value],
    )


@pytest.fixture
def internal_user_ext(test_tenant_id: uuid.UUID) -> CurrentUser:
    """Create an INTERNAL_USER test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="staff@lsmc.bio",
        name="LSMC Staff",
        tenant_id=test_tenant_id,
        roles=[Role.INTERNAL_USER.value],
    )


@pytest.fixture
def admin_user_ext(test_tenant_id: uuid.UUID) -> CurrentUser:
    """Create an ADMIN test user."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="admin@lsmc.bio",
        name="Admin User",
        tenant_id=test_tenant_id,
        roles=[Role.ADMIN.value],
    )


@pytest.fixture
def other_tenant_admin(other_tenant_id_ext: uuid.UUID) -> CurrentUser:
    """Create an org admin in a DIFFERENT tenant."""
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="otheradmin@other-org.com",
        name="Other Org Admin",
        tenant_id=other_tenant_id_ext,
        roles=[Role.EXTERNAL_USER.value, Role.EXTERNAL_USER_ADMIN.value],
    )


def create_test_client(db_session: Session, user: CurrentUser) -> TestClient:
    """Create a test client with given user and DB session."""
    from app.auth.dependencies import get_current_user, get_current_user_web
    from app.auth.middleware import csrf_protect

    def override_get_db():
        try:
            yield db_session
        finally:
            pass

    def override_get_current_user():
        return user

    async def override_csrf_protect():
        """Skip CSRF protection in tests."""
        pass

    app.dependency_overrides[get_db] = override_get_db
    app.dependency_overrides[get_current_user] = override_get_current_user
    app.dependency_overrides[get_current_user_web] = override_get_current_user
    app.dependency_overrides[csrf_protect] = override_csrf_protect

    return TestClient(app)


def _create_user_profile(
    db_session: Session,
    *,
    tenant_id: uuid.UUID,
    email: str,
    name: str,
    roles: list[str],
    is_active: bool = True,
    cognito_sub: str | None = None,
):
    """Create a TapDB-backed user profile for web/API tests."""
    svc = UserService(db_session)
    profile = svc.create(
        UserCreate(
            email=email,
            name=name,
            tenant_id=tenant_id,
            roles=roles,
            cognito_sub=cognito_sub or str(uuid.uuid4()),
        )
    )
    if not is_active:
        svc.deactivate(profile.euid)
        refreshed = svc.get_by_id(profile.euid)
        return refreshed
    return profile


def _ensure_api_access_group(db_session: Session, tenant_id: uuid.UUID):
    svc = UserGroupService(db_session, tenant_id)
    group = svc.get_group_by_code(SystemGroup.API_ACCESS.value)
    if group is not None:
        return group
    svc.create_group(
        GroupCreate(
            group_code=SystemGroup.API_ACCESS.value,
            name="API Access",
            description="API access group",
            access_scope=AccessScope.SYSTEM,
        ),
        created_by=None,
    )
    return svc.get_group_by_code(SystemGroup.API_ACCESS.value)


@pytest.fixture
def setup_tenant(db_session: Session, test_tenant_id: uuid.UUID) -> Organization:
    """Create organization/tenant in DB for FK constraints."""
    org = ensure_tapdb_org(
        db_session,
        test_tenant_id,
        name="acme-genetics",
        display_name="Acme Genetics",
        org_type="clinic",
    )
    db_session.flush()
    return org


@pytest.fixture
def setup_other_tenant(db_session: Session, other_tenant_id_ext: uuid.UUID) -> Organization:
    """Create second organization/tenant for isolation tests."""
    org = ensure_tapdb_org(
        db_session,
        other_tenant_id_ext,
        name="other-org",
        display_name="Other Org",
        org_type="clinic",
    )
    db_session.flush()
    return org


# =============================================================================
# 1. RBAC Unit Tests
# =============================================================================


class TestRBACOrgAdmin:
    """Test RBAC helper functions for EXTERNAL_USER_ADMIN role."""

    def test_is_org_admin_with_ext_admin_role(self):
        """is_org_admin returns True for EXTERNAL_USER_ADMIN."""
        assert is_org_admin([Role.EXTERNAL_USER_ADMIN.value]) is True

    def test_is_org_admin_with_global_admin_role(self):
        """is_org_admin returns True for ADMIN."""
        assert is_org_admin([Role.ADMIN.value]) is True

    def test_is_org_admin_with_external_user_role(self):
        """is_org_admin returns False for plain EXTERNAL_USER."""
        assert is_org_admin([Role.EXTERNAL_USER.value]) is False

    def test_is_org_admin_with_internal_user_role(self):
        """is_org_admin returns False for INTERNAL_USER."""
        assert is_org_admin([Role.INTERNAL_USER.value]) is False

    def test_is_org_admin_with_read_only_role(self):
        """is_org_admin returns False for READ_ONLY."""
        assert is_org_admin([Role.READ_ONLY.value]) is False

    def test_ext_admin_has_org_user_manage_permission(self):
        """EXTERNAL_USER_ADMIN has ORG_USER_MANAGE permission."""
        perms = get_permissions([Role.EXTERNAL_USER_ADMIN.value])
        assert Permission.ORG_USER_MANAGE in perms

    def test_ext_admin_has_org_api_token_manage_permission(self):
        """EXTERNAL_USER_ADMIN has ORG_API_TOKEN_MANAGE permission."""
        perms = get_permissions([Role.EXTERNAL_USER_ADMIN.value])
        assert Permission.ORG_API_TOKEN_MANAGE in perms

    def test_ext_admin_has_org_settings_update_permission(self):
        """EXTERNAL_USER_ADMIN has ORG_SETTINGS_UPDATE permission."""
        perms = get_permissions([Role.EXTERNAL_USER_ADMIN.value])
        assert Permission.ORG_SETTINGS_UPDATE in perms

    def test_ext_admin_has_org_audit_read_permission(self):
        """EXTERNAL_USER_ADMIN has ORG_AUDIT_READ permission."""
        perms = get_permissions([Role.EXTERNAL_USER_ADMIN.value])
        assert Permission.ORG_AUDIT_READ in perms

    def test_ext_admin_can_write(self):
        """can_write includes EXTERNAL_USER_ADMIN."""
        assert can_write([Role.EXTERNAL_USER_ADMIN.value]) is True

    def test_ext_admin_is_not_read_only(self):
        """is_read_only excludes EXTERNAL_USER_ADMIN."""
        assert is_read_only([Role.EXTERNAL_USER_ADMIN.value]) is False

    def test_ext_admin_does_not_have_admin_permissions(self):
        """EXTERNAL_USER_ADMIN does NOT have ADMIN-only permissions."""
        perms = get_permissions([Role.EXTERNAL_USER_ADMIN.value])
        assert Permission.ADMIN_USERS not in perms
        assert Permission.ADMIN_TENANTS not in perms

    def test_ext_admin_does_not_have_internal_permissions(self):
        """EXTERNAL_USER_ADMIN does NOT have INTERNAL_USER permissions."""
        perms = get_permissions([Role.EXTERNAL_USER_ADMIN.value])
        assert Permission.INTAKE_SCAN not in perms
        assert Permission.INTAKE_MATCH not in perms

    def test_org_admin_assignable_roles_include_ext_admin(self):
        """ORG_ADMIN_ASSIGNABLE_ROLES includes EXTERNAL_USER_ADMIN."""
        assert Role.EXTERNAL_USER_ADMIN.value in ORG_ADMIN_ASSIGNABLE_ROLES

    def test_org_admin_assignable_roles_exclude_internal(self):
        """ORG_ADMIN_ASSIGNABLE_ROLES excludes INTERNAL_USER and ADMIN."""
        assert Role.INTERNAL_USER.value not in ORG_ADMIN_ASSIGNABLE_ROLES
        assert Role.ADMIN.value not in ORG_ADMIN_ASSIGNABLE_ROLES

    def test_external_assignable_roles_exclude_ext_admin(self):
        """EXTERNAL_ASSIGNABLE_ROLES does NOT include EXTERNAL_USER_ADMIN."""
        assert Role.EXTERNAL_USER_ADMIN.value not in EXTERNAL_ASSIGNABLE_ROLES

    def test_current_user_is_org_admin_property(self, ext_admin_user: CurrentUser):
        """CurrentUser.is_org_admin property returns True for EXTERNAL_USER_ADMIN."""
        assert ext_admin_user.is_org_admin is True

    def test_current_user_is_org_admin_false_for_regular(self, ext_regular_user: CurrentUser):
        """CurrentUser.is_org_admin property returns False for EXTERNAL_USER."""
        assert ext_regular_user.is_org_admin is False


# =============================================================================
# 2. Token Scope Constraint Tests
# =============================================================================


class TestConstrainRolesByScope:
    """Test _constrain_roles_by_scope function."""

    def test_ext_org_scope_strips_ext_admin(self):
        """ext_org scope strips EXTERNAL_USER_ADMIN."""
        roles = [Role.EXTERNAL_USER.value, Role.EXTERNAL_USER_ADMIN.value]
        constrained = _constrain_roles_by_scope(roles, TokenScope.EXT_ORG.value)
        assert Role.EXTERNAL_USER_ADMIN.value not in constrained
        assert Role.EXTERNAL_USER.value in constrained

    def test_ext_org_scope_strips_internal(self):
        """ext_org scope strips INTERNAL_USER."""
        roles = [Role.INTERNAL_USER.value]
        constrained = _constrain_roles_by_scope(roles, TokenScope.EXT_ORG.value)
        assert Role.INTERNAL_USER.value not in constrained
        # Should fallback to EXTERNAL_USER
        assert Role.EXTERNAL_USER.value in constrained

    def test_ext_org_scope_strips_admin(self):
        """ext_org scope strips ADMIN."""
        roles = [Role.ADMIN.value]
        constrained = _constrain_roles_by_scope(roles, TokenScope.EXT_ORG.value)
        assert Role.ADMIN.value not in constrained
        assert Role.EXTERNAL_USER.value in constrained

    def test_ext_org_scope_keeps_read_write(self):
        """ext_org scope keeps READ_WRITE."""
        roles = [Role.READ_WRITE.value, Role.EXTERNAL_USER.value]
        constrained = _constrain_roles_by_scope(roles, TokenScope.EXT_ORG.value)
        assert Role.READ_WRITE.value in constrained
        assert Role.EXTERNAL_USER.value in constrained

    def test_lsmc_internal_scope_strips_admin(self):
        """lsmc_internal scope strips ADMIN but keeps INTERNAL_USER."""
        roles = [Role.ADMIN.value, Role.INTERNAL_USER.value]
        constrained = _constrain_roles_by_scope(roles, TokenScope.LSMC_INTERNAL.value)
        assert Role.ADMIN.value not in constrained
        assert Role.INTERNAL_USER.value in constrained

    def test_lsmc_internal_scope_keeps_ext_admin(self):
        """lsmc_internal scope keeps EXTERNAL_USER_ADMIN."""
        roles = [Role.EXTERNAL_USER_ADMIN.value, Role.INTERNAL_USER.value]
        constrained = _constrain_roles_by_scope(roles, TokenScope.LSMC_INTERNAL.value)
        assert Role.EXTERNAL_USER_ADMIN.value in constrained
        assert Role.INTERNAL_USER.value in constrained

    def test_lsmc_internal_scope_fallback_for_admin_only(self):
        """lsmc_internal scope gives INTERNAL_USER if user only had ADMIN."""
        roles = [Role.ADMIN.value]
        constrained = _constrain_roles_by_scope(roles, TokenScope.LSMC_INTERNAL.value)
        assert Role.INTERNAL_USER.value in constrained
        assert Role.ADMIN.value not in constrained

    def test_atlas_admin_scope_passes_all_through(self):
        """atlas_admin scope passes all roles through unchanged."""
        roles = [Role.ADMIN.value, Role.INTERNAL_USER.value, Role.EXTERNAL_USER.value]
        constrained = _constrain_roles_by_scope(roles, TokenScope.ATLAS_ADMIN.value)
        assert constrained == roles

    def test_none_scope_defaults_to_ext_org(self):
        """None scope defaults to ext_org (most restrictive)."""
        roles = [Role.ADMIN.value]
        constrained = _constrain_roles_by_scope(roles, None)
        assert Role.ADMIN.value not in constrained
        assert Role.EXTERNAL_USER.value in constrained

    def test_unknown_scope_defaults_to_ext_org(self):
        """Unknown scope string defaults to ext_org."""
        roles = [Role.INTERNAL_USER.value]
        constrained = _constrain_roles_by_scope(roles, "bogus_scope")
        assert Role.INTERNAL_USER.value not in constrained


# =============================================================================
# 3. Token Scope Creation Validation
# =============================================================================


class TestScopeAllowedCreators:
    """Test validate_scope_for_creator and SCOPE_ALLOWED_CREATORS mapping."""

    def test_ext_admin_can_create_ext_org_token(self):
        """EXTERNAL_USER_ADMIN can create ext_org scoped tokens."""
        assert UserAPITokenService.validate_scope_for_creator(
            TokenScope.EXT_ORG.value, [Role.EXTERNAL_USER_ADMIN.value]
        )

    def test_admin_can_create_ext_org_token(self):
        """ADMIN can create ext_org scoped tokens."""
        assert UserAPITokenService.validate_scope_for_creator(
            TokenScope.EXT_ORG.value, [Role.ADMIN.value]
        )

    def test_regular_external_cannot_create_ext_org_token(self):
        """Regular EXTERNAL_USER cannot create ext_org scoped tokens."""
        assert not UserAPITokenService.validate_scope_for_creator(
            TokenScope.EXT_ORG.value, [Role.EXTERNAL_USER.value]
        )

    def test_internal_can_create_lsmc_internal_token(self):
        """INTERNAL_USER can create lsmc_internal scoped tokens."""
        assert UserAPITokenService.validate_scope_for_creator(
            TokenScope.LSMC_INTERNAL.value, [Role.INTERNAL_USER.value]
        )

    def test_ext_admin_cannot_create_lsmc_internal_token(self):
        """EXTERNAL_USER_ADMIN cannot create lsmc_internal scoped tokens."""
        assert not UserAPITokenService.validate_scope_for_creator(
            TokenScope.LSMC_INTERNAL.value, [Role.EXTERNAL_USER_ADMIN.value]
        )

    def test_only_admin_can_create_atlas_admin_token(self):
        """Only ADMIN can create atlas_admin scoped tokens."""
        assert UserAPITokenService.validate_scope_for_creator(
            TokenScope.ATLAS_ADMIN.value, [Role.ADMIN.value]
        )
        assert not UserAPITokenService.validate_scope_for_creator(
            TokenScope.ATLAS_ADMIN.value, [Role.EXTERNAL_USER_ADMIN.value]
        )
        assert not UserAPITokenService.validate_scope_for_creator(
            TokenScope.ATLAS_ADMIN.value, [Role.INTERNAL_USER.value]
        )

    def test_unknown_scope_rejected(self):
        """Unknown scope is rejected for all roles."""
        assert not UserAPITokenService.validate_scope_for_creator("nonexistent", [Role.ADMIN.value])


# =============================================================================
# 4. Cognito Group Mapping Tests
# =============================================================================


class TestCognitoGroupMapping:
    """Test Cognito group → role mapping includes customer-admins."""

    def test_customer_admins_maps_to_ext_admin(self):
        """customer-admins group maps to EXTERNAL_USER + EXTERNAL_USER_ADMIN."""
        roles = settings.map_cognito_groups_to_roles(["customer-admins"])
        assert Role.EXTERNAL_USER.value in roles
        assert Role.EXTERNAL_USER_ADMIN.value in roles

    def test_lsmc_customer_admins_maps_to_ext_admin(self):
        """lsmc-customer-admins group maps to EXTERNAL_USER + EXTERNAL_USER_ADMIN."""
        roles = settings.map_cognito_groups_to_roles(["lsmc-customer-admins"])
        assert Role.EXTERNAL_USER.value in roles
        assert Role.EXTERNAL_USER_ADMIN.value in roles

    def test_customers_group_does_not_get_ext_admin(self):
        """customers group does NOT get EXTERNAL_USER_ADMIN."""
        roles = settings.map_cognito_groups_to_roles(["customers"])
        assert Role.EXTERNAL_USER.value in roles
        assert Role.EXTERNAL_USER_ADMIN.value not in roles

    def test_lsmc_customers_group_does_not_get_ext_admin(self):
        """lsmc-customers group does NOT get EXTERNAL_USER_ADMIN."""
        roles = settings.map_cognito_groups_to_roles(["lsmc-customers"])
        assert Role.EXTERNAL_USER.value in roles
        assert Role.EXTERNAL_USER_ADMIN.value not in roles


# =============================================================================
# 5. Web Route Tests — Org Admin Required Routes
# =============================================================================


@pytest.mark.db
class TestWebOrgUserCreateForm:
    """Test GET /my-organization/users/new (org admin only)."""

    def test_org_admin_can_access_user_create_form(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin can access the user creation form."""
        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.get("/my-organization/users/new")
            assert resp.status_code == status.HTTP_200_OK
        finally:
            app.dependency_overrides.clear()

    def test_regular_user_cannot_access_user_create_form(
        self,
        db_session: Session,
        ext_regular_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Regular EXTERNAL_USER gets 403 on user creation form."""
        client = create_test_client(db_session, ext_regular_user)
        try:
            resp = client.get("/my-organization/users/new")
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()


@pytest.mark.db
class TestWebOrgUserCreate:
    """Test POST /my-organization/users/new (org admin only)."""

    def test_regular_user_cannot_create_org_user(
        self,
        db_session: Session,
        ext_regular_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Regular EXTERNAL_USER gets 403 on user creation POST."""
        client = create_test_client(db_session, ext_regular_user)
        try:
            resp = client.post(
                "/my-organization/users/new",
                data={
                    "email": "new@acme.com",
                    "name": "New User",
                    "roles": ["EXTERNAL_USER"],
                },
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()


@pytest.mark.db
class TestWebOrgUserDeactivate:
    """Test POST /my-organization/users/{user_id}/deactivate."""

    def test_regular_user_cannot_deactivate(
        self,
        db_session: Session,
        ext_regular_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Regular EXTERNAL_USER gets 403 on deactivate."""
        target_id = uuid.uuid4()
        client = create_test_client(db_session, ext_regular_user)
        try:
            resp = client.post(f"/my-organization/users/{target_id}/deactivate")
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_self_deactivation_prevented(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin cannot deactivate themselves — redirects with flash."""
        # Create a UserProfile matching the admin's sub
        user_profile = _create_user_profile(
            db_session,
            tenant_id=ext_admin_user.tenant_id,
            email=ext_admin_user.email,
            name=ext_admin_user.name or "Org Admin",
            roles=ext_admin_user.roles,
            is_active=True,
            cognito_sub=ext_admin_user.sub,
        )

        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                f"/my-organization/users/{user_profile.euid}/deactivate",
                follow_redirects=False,
            )
            # Should redirect (303) with flash error, not deactivate
            assert resp.status_code == status.HTTP_303_SEE_OTHER
            assert "/my-organization/users" in resp.headers.get("location", "")
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_can_deactivate_other_user(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin can deactivate another user in same tenant."""
        target_profile = _create_user_profile(
            db_session,
            tenant_id=ext_admin_user.tenant_id,
            email="target@acme.com",
            name="Target User",
            roles=[Role.EXTERNAL_USER.value],
            is_active=True,
        )

        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                f"/my-organization/users/{target_profile.euid}/deactivate",
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_303_SEE_OTHER
            # Verify user is deactivated
            refreshed = UserService(db_session).get_by_id(target_profile.euid)
            assert refreshed is not None
            assert refreshed.is_active is False
        finally:
            app.dependency_overrides.clear()


@pytest.mark.db
class TestWebOrgUserActivate:
    """Test POST /my-organization/users/{user_id}/activate."""

    def test_regular_user_cannot_activate(
        self,
        db_session: Session,
        ext_regular_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Regular EXTERNAL_USER gets 403 on activate."""
        target_id = uuid.uuid4()
        client = create_test_client(db_session, ext_regular_user)
        try:
            resp = client.post(f"/my-organization/users/{target_id}/activate")
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_can_activate_user(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin can activate a deactivated user in same tenant."""
        target_profile = _create_user_profile(
            db_session,
            tenant_id=ext_admin_user.tenant_id,
            email="inactive@acme.com",
            name="Inactive User",
            roles=[Role.EXTERNAL_USER.value],
            is_active=False,
        )

        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                f"/my-organization/users/{target_profile.euid}/activate",
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_303_SEE_OTHER
            refreshed = UserService(db_session).get_by_id(target_profile.euid)
            assert refreshed is not None
            assert refreshed.is_active is True
        finally:
            app.dependency_overrides.clear()


@pytest.mark.db
class TestWebOrgSettingsEdit:
    """Test GET/POST /my-organization/settings/edit (org admin only)."""

    def test_regular_user_cannot_access_settings_edit(
        self,
        db_session: Session,
        ext_regular_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Regular EXTERNAL_USER gets 403 on settings edit."""
        client = create_test_client(db_session, ext_regular_user)
        try:
            resp = client.get("/my-organization/settings/edit")
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_can_access_settings_edit_form(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin can access the settings edit form."""
        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.get("/my-organization/settings/edit")
            assert resp.status_code == status.HTTP_200_OK
        finally:
            app.dependency_overrides.clear()

    def test_regular_user_cannot_post_settings_edit(
        self,
        db_session: Session,
        ext_regular_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Regular EXTERNAL_USER gets 403 on settings edit POST."""
        client = create_test_client(db_session, ext_regular_user)
        try:
            resp = client.post(
                "/my-organization/settings/edit",
                data={"display_name": "Hacked Name"},
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_can_update_settings(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin can update org settings."""
        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                "/my-organization/settings/edit",
                data={
                    "display_name": "Acme Genetics Updated",
                    "contact_email": "admin@acme.com",
                },
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_303_SEE_OTHER
        finally:
            app.dependency_overrides.clear()


# =============================================================================
# 6. Tenant Isolation Tests
# =============================================================================


@pytest.mark.db
class TestTenantIsolationOrgAdmin:
    """Test that org admins cannot cross tenant boundaries."""

    def test_org_admin_cannot_deactivate_other_tenant_user(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
        setup_other_tenant: Organization,
        other_tenant_id_ext: uuid.UUID,
    ):
        """Org admin cannot deactivate a user in a different tenant."""
        other_user = _create_user_profile(
            db_session,
            tenant_id=other_tenant_id_ext,
            email="other@other-org.com",
            name="Other Org User",
            roles=[Role.EXTERNAL_USER.value],
            is_active=True,
        )

        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                f"/my-organization/users/{other_user.euid}/deactivate",
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_cannot_activate_other_tenant_user(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
        setup_other_tenant: Organization,
        other_tenant_id_ext: uuid.UUID,
    ):
        """Org admin cannot activate a user in a different tenant."""
        other_user = _create_user_profile(
            db_session,
            tenant_id=other_tenant_id_ext,
            email="other-inactive@other-org.com",
            name="Other Inactive",
            roles=[Role.EXTERNAL_USER.value],
            is_active=False,
        )

        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                f"/my-organization/users/{other_user.euid}/activate",
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()


# =============================================================================
# 7. API Route Tests — Org User Creation Role Validation
# =============================================================================


@pytest.mark.db
class TestAPICreateOrgUserRoleValidation:
    """Test POST /api/organizations/{org_id}/users role validation."""

    def test_org_admin_can_assign_ext_admin_role(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
        test_tenant_id: uuid.UUID,
    ):
        """Org admin can assign EXTERNAL_USER_ADMIN role to new user."""
        from app.auth.dependencies import get_current_user

        def override_get_db():
            try:
                yield db_session
            finally:
                pass

        app.dependency_overrides[get_db] = override_get_db
        app.dependency_overrides[get_current_user] = lambda: ext_admin_user

        try:
            with TestClient(app) as client:
                resp = client.post(
                    f"/api/organizations/{setup_tenant.euid}/users",
                    json={
                        "email": "newadmin@acme.com",
                        "name": "New Admin",
                        "roles": [
                            Role.EXTERNAL_USER.value,
                            Role.EXTERNAL_USER_ADMIN.value,
                        ],
                    },
                )
                assert resp.status_code == status.HTTP_201_CREATED
                data = resp.json()
                assert Role.EXTERNAL_USER_ADMIN.value in data["roles"]
        finally:
            app.dependency_overrides.clear()

    def test_regular_external_cannot_assign_ext_admin_role(
        self,
        db_session: Session,
        ext_regular_user: CurrentUser,
        setup_tenant: Organization,
        test_tenant_id: uuid.UUID,
    ):
        """Regular EXTERNAL_USER cannot assign EXTERNAL_USER_ADMIN role."""
        from app.auth.dependencies import get_current_user

        def override_get_db():
            try:
                yield db_session
            finally:
                pass

        app.dependency_overrides[get_db] = override_get_db
        app.dependency_overrides[get_current_user] = lambda: ext_regular_user

        try:
            with TestClient(app) as client:
                resp = client.post(
                    f"/api/organizations/{setup_tenant.euid}/users",
                    json={
                        "email": "sneaky@acme.com",
                        "name": "Sneaky User",
                        "roles": [Role.EXTERNAL_USER_ADMIN.value],
                    },
                )
                assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_cannot_assign_internal_role(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
        test_tenant_id: uuid.UUID,
    ):
        """Org admin cannot assign INTERNAL_USER role."""
        from app.auth.dependencies import get_current_user

        def override_get_db():
            try:
                yield db_session
            finally:
                pass

        app.dependency_overrides[get_db] = override_get_db
        app.dependency_overrides[get_current_user] = lambda: ext_admin_user

        try:
            with TestClient(app) as client:
                resp = client.post(
                    f"/api/organizations/{setup_tenant.euid}/users",
                    json={
                        "email": "escalation@acme.com",
                        "name": "Escalation Attempt",
                        "roles": [Role.INTERNAL_USER.value],
                    },
                )
                assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_cannot_assign_admin_role(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
        test_tenant_id: uuid.UUID,
    ):
        """Org admin cannot assign ADMIN role (privilege escalation)."""
        from app.auth.dependencies import get_current_user

        def override_get_db():
            try:
                yield db_session
            finally:
                pass

        app.dependency_overrides[get_db] = override_get_db
        app.dependency_overrides[get_current_user] = lambda: ext_admin_user

        try:
            with TestClient(app) as client:
                resp = client.post(
                    f"/api/organizations/{setup_tenant.euid}/users",
                    json={
                        "email": "admin-escalation@acme.com",
                        "name": "Admin Escalation",
                        "roles": [Role.ADMIN.value],
                    },
                )
                assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()


# =============================================================================
# 8. API Token Scope Tests
# =============================================================================


@pytest.mark.db
class TestAPITokenScope:
    """Test POST /user-tokens with scope parameter."""

    def _setup_api_client(self, db_session, user):
        """Helper to set up API client with user override."""
        from app.auth.dependencies import get_current_user

        def override_get_db():
            try:
                yield db_session
            finally:
                pass

        app.dependency_overrides[get_db] = override_get_db
        app.dependency_overrides[get_current_user] = lambda: user
        return TestClient(app)

    def _create_api_access_membership(self, db_session, user, tenant):
        """Helper: create user profile + API_ACCESS group membership."""
        profile = _create_user_profile(
            db_session,
            tenant_id=tenant.uid,
            email=user.email,
            name=user.name or "User",
            roles=user.roles,
            is_active=True,
            cognito_sub=user.sub,
        )
        group = _ensure_api_access_group(db_session, tenant.uid)
        assert group is not None
        UserGroupService(db_session, tenant.uid).add_user_to_group(
            user_id=uuid.UUID(user.sub),
            group_euid=group.euid,
            added_by=uuid.UUID(user.sub),
        )
        return profile

    def test_ext_admin_can_create_ext_org_scoped_token(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin can create ext_org scoped token via API."""
        self._create_api_access_membership(db_session, ext_admin_user, setup_tenant)
        client = self._setup_api_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                "/user-tokens",
                json={
                    "token_name": "My Org Token",
                    "expires_in_days": 30,
                    "scope": "ext_org",
                },
            )
            assert resp.status_code == status.HTTP_201_CREATED
            data = resp.json()
            assert "token" in data
            assert data["token_name"] == "My Org Token"
        finally:
            app.dependency_overrides.clear()

    def test_ext_admin_cannot_create_lsmc_internal_token(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin CANNOT create lsmc_internal scoped token."""
        self._create_api_access_membership(db_session, ext_admin_user, setup_tenant)
        client = self._setup_api_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                "/user-tokens",
                json={
                    "token_name": "Internal Token",
                    "expires_in_days": 30,
                    "scope": "lsmc_internal",
                },
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_ext_admin_cannot_create_atlas_admin_token(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin CANNOT create atlas_admin scoped token."""
        self._create_api_access_membership(db_session, ext_admin_user, setup_tenant)
        client = self._setup_api_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                "/user-tokens",
                json={
                    "token_name": "Admin Token",
                    "expires_in_days": 30,
                    "scope": "atlas_admin",
                },
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()


# =============================================================================
# 9. Org-Admin Token Management Web Routes
# =============================================================================


@pytest.mark.db
class TestWebOrgAdminTokenManagement:
    """Test org-admin web routes for managing tokens of other org users."""

    def _create_target_user(self, db_session, tenant_id, email="target@acme.com"):
        """Create a UserProfile for a target user in the given tenant."""
        return _create_user_profile(
            db_session,
            tenant_id=tenant_id,
            email=email,
            name="Target User",
            roles=[Role.EXTERNAL_USER.value],
            is_active=True,
        )

    def _grant_api_access(self, db_session, user_id):
        """Grant API_ACCESS group membership to user_id (UUID)."""
        user_svc = UserService(db_session)
        user = user_svc.get_by_cognito_sub(str(user_id))
        assert user is not None
        group = _ensure_api_access_group(db_session, user.tenant_id)
        assert group is not None
        UserGroupService(db_session, user.tenant_id).add_user_to_group(
            user_id=user_id,
            group_euid=group.euid,
            added_by=None,
        )

    # --- GET list tokens ---

    def test_org_admin_can_list_org_user_tokens(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin can list tokens for a user in their org."""
        target = self._create_target_user(db_session, setup_tenant.uid)
        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.get(f"/my-organization/users/{target.euid}/api-tokens")
            assert resp.status_code == 200
            assert "API Tokens" in resp.text
            assert target.email in resp.text
        finally:
            app.dependency_overrides.clear()

    def test_regular_user_cannot_list_org_user_tokens(
        self,
        db_session: Session,
        ext_regular_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Regular external user gets 403 on org user token listing."""
        target = self._create_target_user(db_session, setup_tenant.uid)
        client = create_test_client(db_session, ext_regular_user)
        try:
            resp = client.get(
                f"/my-organization/users/{target.euid}/api-tokens",
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_cannot_list_other_tenant_user_tokens(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
        setup_other_tenant: Organization,
    ):
        """Org admin cannot list tokens for user in another tenant."""
        target = self._create_target_user(
            db_session, setup_other_tenant.uid, email="other@other.com"
        )
        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.get(
                f"/my-organization/users/{target.euid}/api-tokens",
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    # --- POST create token ---

    def test_org_admin_can_create_token_for_org_user(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin can create a token for a user in their org."""
        target = self._create_target_user(db_session, setup_tenant.uid)
        self._grant_api_access(db_session, uuid.UUID(target.cognito_sub))
        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                f"/my-organization/users/{target.euid}/api-tokens",
                data={"token_name": "OrgCreated", "expires_in_days": "30"},
                follow_redirects=False,
            )
            # Should show the token page (200) with plaintext token
            assert resp.status_code == 200
            assert "Save this token now" in resp.text
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_created_token_scope_is_ext_org(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Tokens created by org admin for org user always have ext_org scope."""
        target = self._create_target_user(db_session, setup_tenant.uid)
        self._grant_api_access(db_session, uuid.UUID(target.cognito_sub))
        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                f"/my-organization/users/{target.euid}/api-tokens",
                data={"token_name": "ScopeCheck", "expires_in_days": "60"},
                follow_redirects=False,
            )
            assert resp.status_code == 200

            # Verify the token via service (keyed on cognito sub)
            target_sub = uuid.UUID(target.cognito_sub)
            token_svc = UserAPITokenService(db_session, setup_tenant.uid)
            tokens = token_svc.list_user_tokens(target_sub)
            assert len(tokens) >= 1
        finally:
            app.dependency_overrides.clear()

    def test_regular_user_cannot_create_token_for_org_user(
        self,
        db_session: Session,
        ext_regular_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Regular external user gets 403 when trying to create token for org user."""
        target = self._create_target_user(db_session, setup_tenant.uid)
        self._grant_api_access(db_session, uuid.UUID(target.cognito_sub))
        client = create_test_client(db_session, ext_regular_user)
        try:
            resp = client.post(
                f"/my-organization/users/{target.euid}/api-tokens",
                data={"token_name": "Blocked", "expires_in_days": "30"},
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_cannot_create_token_for_other_tenant_user(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
        setup_other_tenant: Organization,
    ):
        """Org admin cannot create token for user in another tenant."""
        target = self._create_target_user(
            db_session, setup_other_tenant.uid, email="cross@other.com"
        )
        self._grant_api_access(db_session, uuid.UUID(target.cognito_sub))
        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                f"/my-organization/users/{target.euid}/api-tokens",
                data={"token_name": "CrossTenant", "expires_in_days": "30"},
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    # --- POST revoke token ---

    def _create_token_for_user(self, db_session, tenant_id, user_profile, created_by_uuid):
        """Helper: create a token for a user and return (token, revision).

        Uses cognito_sub as user_id (matching service convention).
        """
        from app.domain.services.user_api_tokens import TokenCreate

        svc = UserAPITokenService(db_session, tenant_id)
        token, revision, _ = svc.create(
            user_id=uuid.UUID(user_profile.cognito_sub),
            data=TokenCreate(token_name="TestToken", expires_in_days=30, scope="ext_org"),
            created_by=created_by_uuid,
        )
        return token, revision

    def test_org_admin_can_revoke_org_user_token(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Org admin can revoke a token belonging to an org user."""
        target = self._create_target_user(db_session, setup_tenant.uid)
        self._grant_api_access(db_session, uuid.UUID(target.cognito_sub))
        token, _ = self._create_token_for_user(
            db_session, setup_tenant.uid, target, ext_admin_user.sub_uuid
        )
        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                f"/my-organization/users/{target.euid}/api-tokens/{token.euid}/revoke",
                data={},
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_303_SEE_OTHER
            # Verify token is revoked (expire stale cache from internal commit)
            db_session.expire_all()
            svc = UserAPITokenService(db_session, setup_tenant.uid)
            result = svc.get_token(token.euid)
            assert result is not None
            _, rev = result
            assert rev.status == "REVOKED"
        finally:
            app.dependency_overrides.clear()

    def test_regular_user_cannot_revoke_org_user_token(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        ext_regular_user: CurrentUser,
        setup_tenant: Organization,
    ):
        """Regular external user gets 403 when trying to revoke org user token."""
        target = self._create_target_user(db_session, setup_tenant.uid)
        self._grant_api_access(db_session, uuid.UUID(target.cognito_sub))
        token, _ = self._create_token_for_user(
            db_session, setup_tenant.uid, target, ext_admin_user.sub_uuid
        )
        client = create_test_client(db_session, ext_regular_user)
        try:
            resp = client.post(
                f"/my-organization/users/{target.euid}/api-tokens/{token.euid}/revoke",
                data={},
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()

    def test_org_admin_cannot_revoke_other_tenant_user_token(
        self,
        db_session: Session,
        ext_admin_user: CurrentUser,
        setup_tenant: Organization,
        setup_other_tenant: Organization,
    ):
        """Org admin cannot revoke token for user in another tenant."""
        target = self._create_target_user(
            db_session, setup_other_tenant.uid, email="revoke-cross@other.com"
        )
        self._grant_api_access(db_session, uuid.UUID(target.cognito_sub))
        token, _ = self._create_token_for_user(
            db_session, setup_other_tenant.uid, target, uuid.uuid4()
        )
        client = create_test_client(db_session, ext_admin_user)
        try:
            resp = client.post(
                f"/my-organization/users/{target.euid}/api-tokens/{token.euid}/revoke",
                data={},
                follow_redirects=False,
            )
            assert resp.status_code == status.HTTP_403_FORBIDDEN
        finally:
            app.dependency_overrides.clear()
