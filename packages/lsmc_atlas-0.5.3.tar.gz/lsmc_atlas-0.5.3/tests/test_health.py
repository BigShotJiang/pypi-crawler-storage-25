"""Tests for health check endpoint."""

import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture
def client() -> TestClient:
    """Create a test client."""
    return TestClient(app)


@pytest.mark.parametrize("path", ["/health", "/healthz", "/readyz"])
def test_health_check(client: TestClient, path: str) -> None:
    """Test that all health endpoints return 200 OK."""
    response = client.get(path)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "version" in data


@pytest.mark.parametrize("path", ["/health", "/healthz", "/readyz"])
def test_health_check_version(client: TestClient, path: str) -> None:
    """Test that all health endpoints return correct version."""
    from app import __version__

    response = client.get(path)
    data = response.json()
    assert data["version"] == __version__


def test_global_healthcheck_returns_json(client: TestClient) -> None:
    """Test that /global_healthcheck?type=json returns structured JSON with all 4 services."""
    response = client.get("/global_healthcheck?type=json")
    # May be 200 or 503 depending on whether peer services are reachable
    assert response.status_code in (200, 503)
    data = response.json()
    assert "status" in data
    assert data["status"] in ("ok", "degraded")
    assert "timestamp" in data
    assert "atlas_version" in data
    assert "services" in data
    # All 4 services must be present
    for svc in ("atlas", "bloom", "ursa", "dewey"):
        assert svc in data["services"], f"Missing service: {svc}"
        svc_data = data["services"][svc]
        assert "status" in svc_data
        assert "url" in svc_data
        assert "response_ms" in svc_data


def test_global_healthcheck_no_auth_required(client: TestClient) -> None:
    """Test that /global_healthcheck does not require authentication."""
    # No auth headers — should still return a valid response (not 401/403)
    response = client.get("/global_healthcheck")
    assert response.status_code not in (401, 403)
