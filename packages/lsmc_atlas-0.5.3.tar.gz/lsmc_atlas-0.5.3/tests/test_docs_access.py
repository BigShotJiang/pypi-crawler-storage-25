"""Tests for API docs access control.

Verifies:
- ADMIN, INTERNAL_USER, EXTERNAL_USER_ADMIN can access /docs, /redoc, /openapi.json
- EXTERNAL_USER is blocked (403)
- Unauthenticated requests are blocked (401)
- EXTERNAL_USER_ADMIN sees filtered OpenAPI schema (no /internal/*, /webhooks/*, etc.)
"""

import uuid

import pytest
from fastapi.testclient import TestClient

from app.auth.dependencies import CurrentUser, get_current_user
from app.auth.rbac import Role
from app.db.engine import get_db
from app.main import _filter_openapi_for_external_admin, app

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_user(role_values: list[str], tenant_id: str | None = None) -> CurrentUser:
    tid = uuid.UUID(tenant_id) if tenant_id else uuid.uuid4()
    return CurrentUser(
        sub=str(uuid.uuid4()),
        email="test@example.com",
        name="Test",
        tenant_id=tid,
        roles=role_values,
    )


def _make_client(user: CurrentUser | None = None) -> TestClient:
    """Build a TestClient, optionally injecting an authenticated user."""
    overrides: dict = {}

    # Stub out DB (docs endpoints don't need it, but the dependency chain does)
    def override_get_db():
        yield None  # pragma: no cover

    overrides[get_db] = override_get_db

    if user is not None:
        overrides[get_current_user] = lambda: user

    app.dependency_overrides = overrides
    client = TestClient(app, raise_server_exceptions=False)
    return client


# ---------------------------------------------------------------------------
# Access control — allowed roles
# ---------------------------------------------------------------------------

DOC_PATHS = ["/docs", "/api/docs", "/redoc", "/api/redoc", "/openapi.json"]


@pytest.mark.parametrize("path", DOC_PATHS)
def test_admin_can_access_docs(path: str):
    user = _make_user([Role.ADMIN.value])
    c = _make_client(user)
    resp = c.get(path)
    assert resp.status_code == 200, f"{path} returned {resp.status_code}"
    app.dependency_overrides.clear()


@pytest.mark.parametrize("path", DOC_PATHS)
def test_internal_user_can_access_docs(path: str):
    user = _make_user([Role.INTERNAL_USER.value])
    c = _make_client(user)
    resp = c.get(path)
    assert resp.status_code == 200, f"{path} returned {resp.status_code}"
    app.dependency_overrides.clear()


@pytest.mark.parametrize("path", DOC_PATHS)
def test_external_user_admin_can_access_docs(path: str):
    user = _make_user([Role.EXTERNAL_USER_ADMIN.value])
    c = _make_client(user)
    resp = c.get(path)
    assert resp.status_code == 200, f"{path} returned {resp.status_code}"
    app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# Access control — blocked roles / unauthenticated
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("path", DOC_PATHS)
def test_external_user_blocked(path: str):
    user = _make_user([Role.EXTERNAL_USER.value])
    c = _make_client(user)
    resp = c.get(path)
    assert resp.status_code == 403, f"{path} should be 403 for EXTERNAL_USER"
    app.dependency_overrides.clear()


@pytest.mark.parametrize("path", DOC_PATHS)
def test_unauthenticated_blocked(path: str):
    """No user injected → require_docs_access should raise 401."""
    # Don't override get_current_user so the real dep fires (session empty → 401)
    c = _make_client(user=None)
    resp = c.get(path)
    # Could be 401 (not authenticated) — session middleware may give 401 or 403
    assert resp.status_code in (401, 403), f"{path} should block unauthenticated"
    app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# OpenAPI schema filtering for EXTERNAL_USER_ADMIN
# ---------------------------------------------------------------------------


def test_external_admin_openapi_filtered():
    """EXTERNAL_USER_ADMIN should not see /internal/*, /webhooks/*, etc."""
    user = _make_user([Role.EXTERNAL_USER_ADMIN.value])
    c = _make_client(user)
    resp = c.get("/openapi.json")
    assert resp.status_code == 200
    schema = resp.json()
    paths = list(schema.get("paths", {}).keys())

    for p in paths:
        assert not p.startswith("/internal"), f"Internal path {p} should be hidden"
        assert not p.startswith("/webhooks"), f"Webhook path {p} should be hidden"
        assert not p.startswith("/api-clients"), f"API-clients path {p} should be hidden"
        assert not p.startswith("/admin/"), f"Admin path {p} should be hidden"
        assert not p.startswith("/api/intake"), f"Intake path {p} should be hidden"
        assert not p.startswith("/api/exceptions"), f"Exceptions path {p} should be hidden"
        assert not p.startswith("/api/barcode"), f"Barcode path {p} should be hidden"
    app.dependency_overrides.clear()


def test_admin_openapi_unfiltered():
    """ADMIN should see the full schema including internal paths."""
    user = _make_user([Role.ADMIN.value])
    c = _make_client(user)
    resp = c.get("/openapi.json")
    assert resp.status_code == 200
    schema = resp.json()
    paths = list(schema.get("paths", {}).keys())
    # Full schema should have /internal paths
    internal_paths = [p for p in paths if p.startswith("/internal")]
    assert len(internal_paths) > 0, "ADMIN should see /internal/* paths"
    app.dependency_overrides.clear()


# ---------------------------------------------------------------------------
# Unit test for the filter function directly
# ---------------------------------------------------------------------------


def test_filter_openapi_function():
    sample = {
        "paths": {
            "/api/trfs": {"get": {}},
            "/api/patients": {"get": {}},
            "/internal/push-results": {"post": {}},
            "/webhooks/subscribe": {"post": {}},
            "/api-clients/list": {"get": {}},
            "/admin/user-tokens": {"get": {}},
            "/api/intake/scan": {"post": {}},
            "/api/barcode/print": {"post": {}},
        }
    }
    filtered = _filter_openapi_for_external_admin(sample)
    assert "/api/trfs" in filtered["paths"]
    assert "/api/patients" in filtered["paths"]
    assert "/internal/push-results" not in filtered["paths"]
    assert "/webhooks/subscribe" not in filtered["paths"]
    assert "/api-clients/list" not in filtered["paths"]
    assert "/admin/user-tokens" not in filtered["paths"]
    assert "/api/intake/scan" not in filtered["paths"]
    assert "/api/barcode/print" not in filtered["paths"]
    # Original should be unchanged
    assert "/internal/push-results" in sample["paths"]
