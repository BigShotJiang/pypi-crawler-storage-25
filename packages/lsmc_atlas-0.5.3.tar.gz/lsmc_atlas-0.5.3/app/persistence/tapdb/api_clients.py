"""TapDB-backed repository adapter for Atlas API clients."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

CLIENT_TEMPLATE_CODE = "atlas/auth/api-client/1.0/"
REVISION_TEMPLATE_CODE = "atlas/auth/api-client-revision/1.0/"
USAGE_TEMPLATE_CODE = "atlas/auth/api-client-usage/1.0/"

CLIENT_PREFIX = "APC"
REVISION_PREFIX = "APR"
USAGE_PREFIX = "APG"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbAPIClientRecord:
    euid: str
    tenant_id: uuid.UUID
    site_id: str | None
    client_name: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbAPIClientRevisionRecord:
    client_id: str
    revision_id: str
    revision_no: int
    api_key: str
    is_active: bool
    permissions: list[str]
    allowed_endpoints: list[str] | None
    rate_limit_per_minute: int | None
    ip_allowed_list: list[str] | None
    expires_at: datetime | None
    note: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbAPIClientUsageLogRecord:
    euid: str
    tenant_id: uuid.UUID
    client_id: str
    endpoint: str
    method: str
    status_code: int
    ip_address: str | None
    request_size_bytes: int | None
    response_size_bytes: int | None
    duration_ms: int | None
    accessed_at: datetime | None


class TapdbAPIClientRepository:
    """API client persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create(
        self,
        tenant_id: uuid.UUID,
        data: Any,
        hashed_api_key: str,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbAPIClientRecord, TapdbAPIClientRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)
        client_props = {
            "tenant_id": str(tenant_id),
            "site_id": str(getattr(data, "site_id", "") or ""),
            "client_name": data.client_name,
            "created_by": str(created_by) if created_by else None,
            "created_at": now.isoformat(),
        }

        client_instance = self.factory.create_instance(
            session=self.db,
            template_code=CLIENT_TEMPLATE_CODE,
            name=data.client_name,
            properties=client_props,
        )
        client_euid = client_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=REVISION_TEMPLATE_CODE,
            name=f"{data.client_name}-rev-1",
            properties={
                "client_id": client_euid,
                "revision_no": 1,
                "api_key": hashed_api_key,
                "is_active": True,
                "permissions": data.permissions,
                "allowed_endpoints": data.allowed_endpoints,
                "rate_limit_per_minute": data.rate_limit_per_minute,
                "ip_allowed_list": data.ip_allowed_list,
                "expires_at": data.expires_at.isoformat() if data.expires_at else None,
                "note": None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=client_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()
        return self._to_client(client_instance), self._to_revision(revision_instance)

    def get(
        self, client_id: str, tenant_id: uuid.UUID
    ) -> tuple[TapdbAPIClientRecord, TapdbAPIClientRevisionRecord] | None:
        client = self._get_client_by_id(client_id, tenant_id)
        if client is None:
            return None
        revision = self._latest_revision(client_id)
        if revision is None:
            return None
        return client, revision

    def list(
        self, tenant_id: uuid.UUID, skip: int = 0, limit: int = 100
    ) -> list[tuple[TapdbAPIClientRecord, TapdbAPIClientRevisionRecord]]:
        records: list[tuple[TapdbAPIClientRecord, TapdbAPIClientRevisionRecord]] = []
        tenant_key = str(tenant_id)
        for instance in self._instances_for_template(CLIENT_TEMPLATE_CODE):
            client = self._to_client(instance)
            if str(client.tenant_id) != tenant_key:
                continue
            revision = self._latest_revision(client.euid)
            if revision is None:
                continue
            records.append((client, revision))
        records.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return records[skip : skip + limit]

    def update(
        self,
        tenant_id: uuid.UUID,
        client_id: str,
        data: Any,
        updated_by: uuid.UUID | None,
    ) -> tuple[TapdbAPIClientRecord, TapdbAPIClientRevisionRecord] | None:
        result = self.get(client_id, tenant_id)
        if result is None:
            return None
        client, current_revision = result
        now = datetime.now(UTC)

        new_revision = self.factory.create_instance(
            session=self.db,
            template_code=REVISION_TEMPLATE_CODE,
            name=f"{client.client_name}-rev-{current_revision.revision_no + 1}",
            properties={
                "client_id": client_id,
                "revision_no": current_revision.revision_no + 1,
                "api_key": current_revision.api_key,
                "is_active": (
                    data.is_active if data.is_active is not None else current_revision.is_active
                ),
                "permissions": (
                    data.permissions
                    if data.permissions is not None
                    else current_revision.permissions
                ),
                "allowed_endpoints": (
                    data.allowed_endpoints
                    if data.allowed_endpoints is not None
                    else current_revision.allowed_endpoints
                ),
                "rate_limit_per_minute": (
                    data.rate_limit_per_minute
                    if data.rate_limit_per_minute is not None
                    else current_revision.rate_limit_per_minute
                ),
                "ip_allowed_list": (
                    data.ip_allowed_list
                    if data.ip_allowed_list is not None
                    else current_revision.ip_allowed_list
                ),
                "expires_at": (
                    data.expires_at.isoformat()
                    if data.expires_at is not None
                    else (
                        current_revision.expires_at.isoformat()
                        if current_revision.expires_at
                        else None
                    )
                ),
                "note": data.note,
                "created_by": str(updated_by) if updated_by else None,
                "created_at": now.isoformat(),
            },
        )
        client_instance = get_instance_by_euid(self.db, CLIENT_TEMPLATE_CODE, client_id)
        if client_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=client_instance,
                child=new_revision,
                relationship_type="revision",
            )
        self.db.commit()
        return client, self._to_revision(new_revision)

    def rotate_key(
        self,
        tenant_id: uuid.UUID,
        client_id: str,
        hashed_api_key: str,
        rotated_by: uuid.UUID | None,
    ) -> tuple[TapdbAPIClientRecord, TapdbAPIClientRevisionRecord] | None:
        result = self.get(client_id, tenant_id)
        if result is None:
            return None
        client, current_revision = result
        now = datetime.now(UTC)

        new_revision = self.factory.create_instance(
            session=self.db,
            template_code=REVISION_TEMPLATE_CODE,
            name=f"{client.client_name}-rev-{current_revision.revision_no + 1}",
            properties={
                "client_id": client_id,
                "revision_no": current_revision.revision_no + 1,
                "api_key": hashed_api_key,
                "is_active": current_revision.is_active,
                "permissions": current_revision.permissions,
                "allowed_endpoints": current_revision.allowed_endpoints,
                "rate_limit_per_minute": current_revision.rate_limit_per_minute,
                "ip_allowed_list": current_revision.ip_allowed_list,
                "expires_at": (
                    current_revision.expires_at.isoformat() if current_revision.expires_at else None
                ),
                "note": "API key rotated",
                "created_by": str(rotated_by) if rotated_by else None,
                "created_at": now.isoformat(),
            },
        )
        client_instance = get_instance_by_euid(self.db, CLIENT_TEMPLATE_CODE, client_id)
        if client_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=client_instance,
                child=new_revision,
                relationship_type="revision",
            )
        self.db.commit()
        return client, self._to_revision(new_revision)

    def validate_api_key(
        self, tenant_id: uuid.UUID, hashed_api_key: str
    ) -> tuple[TapdbAPIClientRecord, TapdbAPIClientRevisionRecord] | None:
        tenant_key = str(tenant_id)
        candidates: list[TapdbAPIClientRevisionRecord] = []
        for instance in self._instances_for_template(REVISION_TEMPLATE_CODE):
            revision = self._to_revision(instance)
            if revision.api_key != hashed_api_key:
                continue
            if not revision.is_active:
                continue
            if revision.expires_at and revision.expires_at < datetime.now(UTC):
                continue
            client = self._get_client_by_id(revision.client_id, tenant_id)
            if client is None or str(client.tenant_id) != tenant_key:
                continue
            candidates.append(revision)
        if not candidates:
            return None
        candidates.sort(key=lambda rev: rev.revision_no, reverse=True)
        winner = candidates[0]
        client = self._get_client_by_id(winner.client_id, tenant_id)
        if client is None:
            return None
        return client, winner

    def validate_api_key_any_tenant(
        self, hashed_api_key: str
    ) -> tuple[TapdbAPIClientRecord, TapdbAPIClientRevisionRecord] | None:
        """Validate API key without pre-resolving tenant.

        Used by integration entrypoints where tenant scope is encoded in
        the API client itself.
        """
        candidates: list[tuple[TapdbAPIClientRecord, TapdbAPIClientRevisionRecord]] = []
        for instance in self._instances_for_template(REVISION_TEMPLATE_CODE):
            revision = self._to_revision(instance)
            if revision.api_key != hashed_api_key:
                continue
            if not revision.is_active:
                continue
            if revision.expires_at and revision.expires_at < datetime.now(UTC):
                continue
            client = self._get_client_by_id_any_tenant(revision.client_id)
            if client is None:
                continue
            candidates.append((client, revision))
        if not candidates:
            return None
        candidates.sort(key=lambda row: row[1].revision_no, reverse=True)
        return candidates[0]

    def log_usage(
        self,
        tenant_id: uuid.UUID,
        client_id: str,
        endpoint: str,
        method: str,
        status_code: int,
        ip_address: str | None = None,
        request_size_bytes: int | None = None,
        response_size_bytes: int | None = None,
        duration_ms: int | None = None,
    ) -> None:
        self._ensure_templates()
        now = datetime.now(UTC)
        usage_props = {
            "tenant_id": str(tenant_id),
            "client_id": client_id,
            "endpoint": endpoint,
            "method": method,
            "status_code": status_code,
            "ip_address": ip_address,
            "request_size_bytes": request_size_bytes,
            "response_size_bytes": response_size_bytes,
            "duration_ms": duration_ms,
            "accessed_at": now.isoformat(),
        }
        usage_instance = self.factory.create_instance(
            session=self.db,
            template_code=USAGE_TEMPLATE_CODE,
            name=f"{method.upper()} {endpoint}",
            properties=usage_props,
        )
        client_instance = get_instance_by_euid(self.db, CLIENT_TEMPLATE_CODE, client_id)
        if client_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=client_instance,
                child=usage_instance,
                relationship_type="usage",
            )
        self.db.commit()

    def get_usage_logs(
        self,
        tenant_id: uuid.UUID,
        client_id: str | None = None,
        limit: int = 100,
    ) -> list[TapdbAPIClientUsageLogRecord]:
        tenant_key = str(tenant_id)
        client_key = client_id
        logs: list[TapdbAPIClientUsageLogRecord] = []
        for instance in self._instances_for_template(USAGE_TEMPLATE_CODE):
            log = self._to_usage_log(instance)
            if str(log.tenant_id) != tenant_key:
                continue
            if client_key and log.client_id != client_key:
                continue
            logs.append(log)
        logs.sort(
            key=lambda row: row.accessed_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return logs[:limit]

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            CLIENT_TEMPLATE_CODE,
            CLIENT_PREFIX,
            "Atlas API Client",
            {"managed_by": "lsmc-atlas", "domain": "api_clients"},
        )
        self._ensure_template(
            REVISION_TEMPLATE_CODE,
            REVISION_PREFIX,
            "Atlas API Client Revision",
            {"managed_by": "lsmc-atlas", "domain": "api_clients"},
        )
        self._ensure_template(
            USAGE_TEMPLATE_CODE,
            USAGE_PREFIX,
            "Atlas API Client Usage",
            {"managed_by": "lsmc-atlas", "domain": "api_clients"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl=json_addl,
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != instance_prefix:
                existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _write_instance_properties(self, instance: generic_instance, props: dict[str, Any]) -> None:
        raw = dict(instance.json_addl or {})
        raw["properties"] = props
        instance.json_addl = raw
        flag_modified(instance, "json_addl")

    def _get_client_by_id(
        self, client_id: str, tenant_id: uuid.UUID
    ) -> TapdbAPIClientRecord | None:
        instance = get_instance_by_euid(self.db, CLIENT_TEMPLATE_CODE, client_id)
        if instance is None or instance.is_deleted:
            return None
        if not self._matches_template(instance, CLIENT_TEMPLATE_CODE):
            return None
        record = self._to_client(instance)
        if str(record.tenant_id) != str(tenant_id):
            return None
        return record

    def _get_client_by_id_any_tenant(self, client_id: str) -> TapdbAPIClientRecord | None:
        instance = get_instance_by_euid(self.db, CLIENT_TEMPLATE_CODE, client_id)
        if instance is None or instance.is_deleted:
            return None
        if not self._matches_template(instance, CLIENT_TEMPLATE_CODE):
            return None
        return self._to_client(instance)

    def _latest_revision(self, client_id: str) -> TapdbAPIClientRevisionRecord | None:
        client_instance = get_instance_by_euid(self.db, CLIENT_TEMPLATE_CODE, client_id)
        if client_instance is None:
            return None
        children = get_child_instances(self.db, client_instance, REVISION_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_revision(c) for c in children]
        revisions.sort(key=lambda rev: rev.revision_no, reverse=True)
        return revisions[0]

    def _matches_template(self, instance: generic_instance, template_code: str) -> bool:
        category, type_, subtype, version = _parse_template_code(template_code)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _to_client(self, instance: generic_instance) -> TapdbAPIClientRecord:
        props = self._instance_properties(instance)
        return TapdbAPIClientRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            site_id=(str(props.get("site_id")).strip() or None)
            if props.get("site_id") is not None
            else None,
            client_name=str(props.get("client_name") or instance.name),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_revision(self, instance: generic_instance) -> TapdbAPIClientRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbAPIClientRevisionRecord(
            client_id=str(props.get("client_id") or ""),
            revision_id=instance.euid,
            revision_no=int(props.get("revision_no") or 1),
            api_key=str(props.get("api_key") or ""),
            is_active=bool(props.get("is_active", True)),
            permissions=list(props.get("permissions") or []),
            allowed_endpoints=props.get("allowed_endpoints"),
            rate_limit_per_minute=(
                int(props.get("rate_limit_per_minute"))
                if props.get("rate_limit_per_minute") is not None
                else None
            ),
            ip_allowed_list=props.get("ip_allowed_list"),
            expires_at=_to_dt(props.get("expires_at")),
            note=props.get("note"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_usage_log(self, instance: generic_instance) -> TapdbAPIClientUsageLogRecord:
        props = self._instance_properties(instance)
        return TapdbAPIClientUsageLogRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            client_id=str(props.get("client_id") or ""),
            endpoint=str(props.get("endpoint") or ""),
            method=str(props.get("method") or ""),
            status_code=int(props.get("status_code") or 0),
            ip_address=props.get("ip_address"),
            request_size_bytes=(
                int(props.get("request_size_bytes"))
                if props.get("request_size_bytes") is not None
                else None
            ),
            response_size_bytes=(
                int(props.get("response_size_bytes"))
                if props.get("response_size_bytes") is not None
                else None
            ),
            duration_ms=int(props.get("duration_ms"))
            if props.get("duration_ms") is not None
            else None,
            accessed_at=_to_dt(props.get("accessed_at")) or instance.created_dt,
        )
