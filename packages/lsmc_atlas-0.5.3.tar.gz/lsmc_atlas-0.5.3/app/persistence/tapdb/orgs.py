"""TapDB-backed repository adapter for Atlas organizations and sites."""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

ORG_TEMPLATE_CODE = "atlas/core/organization/1.0/"
ORG_REV_TEMPLATE_CODE = "atlas/core/organization-revision/1.0/"
SITE_TEMPLATE_CODE = "atlas/core/site/1.0/"
SITE_REV_TEMPLATE_CODE = "atlas/core/site-revision/1.0/"

ORG_PREFIX = "RGX"
ORG_REV_PREFIX = "RGR"
SITE_PREFIX = "STX"
SITE_REV_PREFIX = "STR"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


@dataclass
class TapdbOrganizationRevisionRecord:
    euid: str
    organization_id: str
    revision_no: int
    name: str
    display_name: str | None
    org_type: str
    contact_email: str | None
    contact_phone: str | None
    owner_user_id: str | None
    address: dict | None
    is_active: bool
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


@dataclass
class TapdbOrganizationRecord:
    euid: str
    uid: uuid.UUID | None  # internal UUID (used as tenant_id for access control)
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbSiteRevisionRecord:
    euid: str
    site_id: str
    revision_no: int
    name: str
    site_code: str | None
    address: dict | None
    contact_email: str | None
    contact_phone: str | None
    is_active: bool
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


@dataclass
class TapdbSiteRecord:
    euid: str
    organization_id: str
    created_at: datetime | None
    created_by: uuid.UUID | None
    revisions: list[TapdbSiteRevisionRecord] = field(default_factory=list)


class TapdbOrgRepository:
    """Organization + Site persistence backed by TapDB instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_org(self, data: Any, created_by: uuid.UUID | None) -> TapdbOrganizationRecord:
        self._ensure_templates()

        org_tenant_id = uuid.uuid4()
        org_instance = self.factory.create_instance(
            session=self.db,
            template_code=ORG_TEMPLATE_CODE,
            name=data.name,
            properties={
                "created_by": str(created_by) if created_by else None,
            },
            tenant_id=org_tenant_id,
        )
        org_euid = org_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=ORG_REV_TEMPLATE_CODE,
            name=data.name,
            properties={
                "organization_id": org_euid,
                "revision_no": 1,
                "name": data.name,
                "display_name": data.display_name,
                "org_type": data.org_type,
                "contact_email": data.contact_email,
                "contact_phone": data.contact_phone,
                "owner_user_id": data.owner_user_id,
                "address": data.address,
                "is_active": True,
                "created_by": str(created_by) if created_by else None,
                "note": None,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=org_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()
        return self._to_org_record(org_instance)

    def get_org_by_uid(self, uid: uuid.UUID) -> TapdbOrganizationRecord | None:
        """Look up an organization by its tenant_id UUID column on generic_instance."""
        category, type_, subtype, version = _parse_template_code(ORG_TEMPLATE_CODE)
        stmt = (
            select(generic_instance)
            .join(generic_template, generic_instance.template_uid == generic_template.uid)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
                generic_instance.tenant_id == uid,
                generic_instance.is_deleted.is_(False),
            )
        )
        instance = self.db.execute(stmt).scalar_one_or_none()
        if instance is None:
            return None
        return self._to_org_record(instance)

    def get_org_by_id(self, org_id: str) -> TapdbOrganizationRecord | None:
        instance = self._resolve_org_instance(org_id)
        if instance is None or instance.is_deleted:
            return None
        return self._to_org_record(instance)

    def get_org_with_revision(
        self, org_id: str
    ) -> tuple[TapdbOrganizationRecord, TapdbOrganizationRevisionRecord] | None:
        org = self.get_org_by_id(org_id)
        if org is None:
            return None
        rev = self._latest_org_revision(org_id)
        if rev is None:
            return None
        return (org, rev)

    def get_org_with_revision_by_uid(
        self, uid: uuid.UUID
    ) -> tuple[TapdbOrganizationRecord, TapdbOrganizationRevisionRecord] | None:
        """Look up org by tenant_id UUID and return with latest revision."""
        org = self.get_org_by_uid(uid)
        if org is None:
            return None
        rev = self._latest_org_revision(org.euid)
        if rev is None:
            return None
        return (org, rev)

    def list_orgs(self, active_only: bool = True) -> list[TapdbOrganizationRecord]:
        category, type_, subtype, version = _parse_template_code(ORG_TEMPLATE_CODE)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        items: list[TapdbOrganizationRecord] = []
        for instance in self.db.execute(stmt).scalars().all():
            if active_only:
                rev = self._latest_org_revision(instance.euid)
                if rev is None or not rev.is_active:
                    continue
            items.append(self._to_org_record(instance))
        return items

    def update_org(
        self,
        org_id: str,
        data: Any,
        updated_by: uuid.UUID | None,
    ) -> TapdbOrganizationRecord | None:
        org_instance = self._resolve_org_instance(org_id)
        if org_instance is None or org_instance.is_deleted:
            return None
        latest = self._latest_org_revision(org_id)
        if latest is None:
            return None

        new_revision = self.factory.create_instance(
            session=self.db,
            template_code=ORG_REV_TEMPLATE_CODE,
            name=data.name if data.name is not None else latest.name,
            properties={
                "organization_id": org_id,
                "revision_no": latest.revision_no + 1,
                "name": data.name if data.name is not None else latest.name,
                "display_name": (
                    data.display_name if data.display_name is not None else latest.display_name
                ),
                "org_type": data.org_type if data.org_type is not None else latest.org_type,
                "contact_email": (
                    data.contact_email if data.contact_email is not None else latest.contact_email
                ),
                "contact_phone": (
                    data.contact_phone if data.contact_phone is not None else latest.contact_phone
                ),
                "owner_user_id": (
                    data.owner_user_id if data.owner_user_id is not None else latest.owner_user_id
                ),
                "address": data.address if data.address is not None else latest.address,
                "is_active": data.is_active if data.is_active is not None else latest.is_active,
                "created_by": str(updated_by) if updated_by else None,
                "note": data.note,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=org_instance,
            child=new_revision,
            relationship_type="revision",
        )
        self.db.commit()
        return self._to_org_record(org_instance)

    def soft_delete_org(self, org_id: str, deleted_by: uuid.UUID | None = None) -> bool:
        """Soft-delete organization (and sites) by marking instances is_deleted."""
        org_instance = self._resolve_org_instance(org_id)
        if org_instance is None or org_instance.is_deleted:
            return False

        deleted_at = datetime.now(UTC).isoformat()

        def _mark_deleted(instance: generic_instance) -> None:
            if instance.is_deleted:
                return
            instance.is_deleted = True
            json_addl = dict(instance.json_addl or {})
            props = self._properties(instance)
            props["deleted_at"] = deleted_at
            if deleted_by:
                props["deleted_by"] = str(deleted_by)
            json_addl["properties"] = props
            instance.json_addl = json_addl

        _mark_deleted(org_instance)
        for org_revision in get_child_instances(self.db, org_instance, ORG_REV_TEMPLATE_CODE):
            _mark_deleted(org_revision)

        for site in self.list_sites_by_org(org_id, active_only=False):
            site_instance = self._resolve_site_instance(site.euid)
            if site_instance is None:
                continue
            _mark_deleted(site_instance)
            for site_revision in get_child_instances(
                self.db, site_instance, SITE_REV_TEMPLATE_CODE
            ):
                _mark_deleted(site_revision)

        self.db.commit()
        return True

    def create_site(self, data: Any, created_by: uuid.UUID | None) -> TapdbSiteRecord:
        self._ensure_templates()
        canonical_org_id = self._canonicalize_org_identifier(str(data.organization_id))

        site_instance = self.factory.create_instance(
            session=self.db,
            template_code=SITE_TEMPLATE_CODE,
            name=data.name,
            properties={
                "organization_id": canonical_org_id,
                "created_by": str(created_by) if created_by else None,
            },
        )
        site_euid = site_instance.euid

        # Optional containment lineage from org -> site when org exists.
        org_instance = self._resolve_org_instance(canonical_org_id)
        if org_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=org_instance,
                child=site_instance,
                relationship_type="contains",
            )

        site_rev_instance = self.factory.create_instance(
            session=self.db,
            template_code=SITE_REV_TEMPLATE_CODE,
            name=data.name,
            properties={
                "site_id": site_euid,
                "revision_no": 1,
                "name": data.name,
                "site_code": data.site_code,
                "address": data.address,
                "contact_email": data.contact_email,
                "contact_phone": data.contact_phone,
                "is_active": True,
                "created_by": str(created_by) if created_by else None,
                "note": None,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=site_instance,
            child=site_rev_instance,
            relationship_type="revision",
        )
        self.db.commit()
        return self._to_site_record(site_instance)

    def get_site_by_id(self, site_id: str) -> TapdbSiteRecord | None:
        instance = self._resolve_site_instance(site_id)
        if instance is None or instance.is_deleted:
            return None
        return self._to_site_record(instance)

    def list_sites_by_org(
        self,
        org_id: str,
        active_only: bool = True,
    ) -> list[TapdbSiteRecord]:
        category, type_, subtype, version = _parse_template_code(SITE_TEMPLATE_CODE)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        org_key = str(org_id)
        org_keys = {org_key}
        org_instance = self._resolve_org_instance(org_key)
        if org_instance is not None and org_instance.tenant_id is not None:
            org_keys.add(str(org_instance.tenant_id))
        else:
            parsed_org_uuid = _parse_uuid(org_key)
            if parsed_org_uuid is not None:
                org_by_uid = self.get_org_by_uid(parsed_org_uuid)
                if org_by_uid is not None:
                    org_keys.add(org_by_uid.euid)
        sites: list[TapdbSiteRecord] = []
        for instance in self.db.execute(stmt).scalars().all():
            props = self._properties(instance)
            if str(props.get("organization_id")) not in org_keys:
                continue
            site = self._to_site_record(instance)
            if active_only:
                latest = site.revisions[-1] if site.revisions else None
                if latest and not latest.is_active:
                    continue
            sites.append(site)
        return sites

    def update_site(
        self,
        site_id: str,
        data: Any,
        updated_by: uuid.UUID | None,
    ) -> TapdbSiteRecord | None:
        site_instance = self._resolve_site_instance(site_id)
        if site_instance is None or site_instance.is_deleted:
            return None
        latest = self._latest_site_revision(site_id)
        if latest is None:
            return None

        new_revision = self.factory.create_instance(
            session=self.db,
            template_code=SITE_REV_TEMPLATE_CODE,
            name=data.name if data.name is not None else latest.name,
            properties={
                "site_id": site_id,
                "revision_no": latest.revision_no + 1,
                "name": data.name if data.name is not None else latest.name,
                "site_code": data.site_code if data.site_code is not None else latest.site_code,
                "address": data.address if data.address is not None else latest.address,
                "contact_email": (
                    data.contact_email if data.contact_email is not None else latest.contact_email
                ),
                "contact_phone": (
                    data.contact_phone if data.contact_phone is not None else latest.contact_phone
                ),
                "is_active": data.is_active if data.is_active is not None else latest.is_active,
                "created_by": str(updated_by) if updated_by else None,
                "note": data.note,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=site_instance,
            child=new_revision,
            relationship_type="revision",
        )
        self.db.commit()
        return self._to_site_record(site_instance)

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(ORG_TEMPLATE_CODE, "Atlas Organization", ORG_PREFIX)
        self._ensure_template(ORG_REV_TEMPLATE_CODE, "Atlas Organization Revision", ORG_REV_PREFIX)
        self._ensure_template(SITE_TEMPLATE_CODE, "Atlas Site", SITE_PREFIX)
        self._ensure_template(SITE_REV_TEMPLATE_CODE, "Atlas Site Revision", SITE_REV_PREFIX)
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(self, template_code: str, template_name: str, prefix: str) -> None:
        self._ensure_prefix_sequence(prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is not None:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != prefix:
                existing.instance_prefix = prefix
            return
        self.db.add(
            generic_template(
                name=template_name,
                polymorphic_discriminator="generic_template",
                category=category,
                type=type_,
                subtype=subtype,
                version=version,
                instance_prefix=prefix,
                instance_polymorphic_identity="generic_instance",
                json_addl={"managed_by": "lsmc-atlas", "domain": "core"},
                bstatus="active",
                is_singleton=False,
                is_deleted=False,
            )
        )

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _matches_template(self, instance: generic_instance, template_code: str) -> bool:
        category, type_, subtype, version = _parse_template_code(template_code)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _properties(self, instance: generic_instance) -> dict[str, Any]:
        json_addl = instance.json_addl or {}
        props = json_addl.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _latest_org_revision(self, org_id: str) -> TapdbOrganizationRevisionRecord | None:
        org_instance = self._resolve_org_instance(org_id)
        if org_instance is None:
            return None
        children = get_child_instances(self.db, org_instance, ORG_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_org_revision(c, org_id) for c in children]
        revisions.sort(key=lambda rev: rev.revision_no, reverse=True)
        return revisions[0]

    def _latest_site_revision(self, site_id: str) -> TapdbSiteRevisionRecord | None:
        site_instance = self._resolve_site_instance(site_id)
        if site_instance is None:
            return None
        children = get_child_instances(self.db, site_instance, SITE_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_site_revision(c, site_id) for c in children]
        revisions.sort(key=lambda rev: rev.revision_no, reverse=True)
        return revisions[0]

    def _to_org_record(self, instance: generic_instance) -> TapdbOrganizationRecord:
        props = self._properties(instance)
        return TapdbOrganizationRecord(
            euid=instance.euid,
            uid=instance.tenant_id if instance.tenant_id else _parse_uuid(props.get("id")),
            created_at=instance.created_dt or datetime.now(UTC),
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_org_revision(
        self,
        instance: generic_instance,
        fallback_org_id: str = "",
    ) -> TapdbOrganizationRevisionRecord:
        props = self._properties(instance)
        return TapdbOrganizationRevisionRecord(
            euid=instance.euid,
            organization_id=str(props.get("organization_id", fallback_org_id)),
            revision_no=int(props.get("revision_no") or 1),
            name=str(props.get("name") or instance.name),
            display_name=props.get("display_name"),
            org_type=str(props.get("org_type") or "clinic"),
            contact_email=props.get("contact_email"),
            contact_phone=props.get("contact_phone"),
            owner_user_id=str(props.get("owner_user_id")) if props.get("owner_user_id") else None,
            address=props.get("address"),
            is_active=bool(props.get("is_active", True)),
            created_at=instance.created_dt or datetime.now(UTC),
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    def _to_site_record(self, instance: generic_instance) -> TapdbSiteRecord:
        props = self._properties(instance)
        site_euid = instance.euid
        site_instance = instance
        children = get_child_instances(self.db, site_instance, SITE_REV_TEMPLATE_CODE)
        revisions = [self._to_site_revision(c, site_euid) for c in children]
        revisions.sort(key=lambda rev: rev.revision_no)
        raw_org_id = str(props.get("organization_id", ""))
        canonical_org_id = self._canonicalize_org_identifier(raw_org_id) if raw_org_id else ""
        return TapdbSiteRecord(
            euid=site_euid,
            organization_id=canonical_org_id,
            created_at=instance.created_dt or datetime.now(UTC),
            created_by=_parse_uuid(props.get("created_by")),
            revisions=revisions,
        )

    def _to_site_revision(
        self,
        instance: generic_instance,
        fallback_site_id: str = "",
    ) -> TapdbSiteRevisionRecord:
        props = self._properties(instance)
        return TapdbSiteRevisionRecord(
            euid=instance.euid,
            site_id=str(props.get("site_id", fallback_site_id)),
            revision_no=int(props.get("revision_no") or 1),
            name=str(props.get("name") or instance.name),
            site_code=props.get("site_code"),
            address=props.get("address"),
            contact_email=props.get("contact_email"),
            contact_phone=props.get("contact_phone"),
            is_active=bool(props.get("is_active", True)),
            created_at=instance.created_dt or datetime.now(UTC),
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    # ------------------------------------------------------------------
    # EUID-first resolvers
    # ------------------------------------------------------------------

    def _resolve_org_instance(
        self,
        org_id: str | uuid.UUID,
    ) -> generic_instance | None:
        """Resolve an organization instance by EUID."""
        euid = str(org_id)
        return get_instance_by_euid(self.db, ORG_TEMPLATE_CODE, euid)

    def _resolve_site_instance(
        self,
        site_id: str | uuid.UUID,
    ) -> generic_instance | None:
        """Resolve a site instance by EUID."""
        euid = str(site_id)
        return get_instance_by_euid(self.db, SITE_TEMPLATE_CODE, euid)

    def _canonicalize_org_identifier(self, org_id: str) -> str:
        """Normalize org identifier to canonical organization EUID when possible."""
        instance = self._resolve_org_instance(org_id)
        if instance is not None:
            return instance.euid
        parsed_uuid = _parse_uuid(org_id)
        if parsed_uuid is not None:
            org_by_uid = self.get_org_by_uid(parsed_uuid)
            if org_by_uid is not None:
                return org_by_uid.euid
        return org_id
