"""TapDB-backed repository adapter for Atlas family domain."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

FAMILY_TEMPLATE_CODE = "atlas/people/family/1.0/"
FAMILY_REV_TEMPLATE_CODE = "atlas/people/family-revision/1.0/"

FAMILY_PREFIX = "FAM"
FAMILY_REV_PREFIX = "FMR"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbFamilyRecord:
    euid: str
    tenant_id: uuid.UUID
    site_id: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbFamilyRevisionRecord:
    euid: str
    family_id: str
    revision_no: int
    name: str
    notes: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


class TapdbFamilyRepository:
    """Family persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_family(
        self,
        *,
        tenant_id: uuid.UUID,
        name: str,
        notes: str | None,
        site_id: str,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbFamilyRecord, TapdbFamilyRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)

        resolved_name = (name or "").strip() or f"Family {now:%Y-%m-%d}"

        family_props = {
            "tenant_id": str(tenant_id),
            "site_id": str(site_id),
            "created_by": str(created_by) if created_by else None,
            "created_at": now.isoformat(),
        }
        family_instance = self.factory.create_instance(
            session=self.db,
            template_code=FAMILY_TEMPLATE_CODE,
            name=resolved_name,
            properties=family_props,
        )

        rev_instance = self.factory.create_instance(
            session=self.db,
            template_code=FAMILY_REV_TEMPLATE_CODE,
            name=f"{resolved_name}-rev-1",
            properties={
                "family_id": family_instance.euid,
                "revision_no": 1,
                "name": resolved_name,
                "notes": notes,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": "family created",
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=family_instance,
            child=rev_instance,
            relationship_type="revision",
        )
        self.db.commit()
        return self._to_family(family_instance), self._to_family_revision(rev_instance)

    def get_family_with_revision(
        self,
        *,
        family_euid: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbFamilyRecord, TapdbFamilyRevisionRecord] | None:
        family_instance = self._resolve_family_instance(family_euid)
        if family_instance is None:
            return None
        family = self._to_family(family_instance)
        if tenant_id is not None and family.tenant_id != tenant_id:
            return None
        revision = self._get_latest_family_revision(family_instance)
        if revision is None:
            return None
        return family, revision

    def list_families(
        self,
        *,
        tenant_id: uuid.UUID | None,
        limit: int,
        offset: int,
    ) -> list[tuple[TapdbFamilyRecord, TapdbFamilyRevisionRecord]]:
        rows: list[tuple[TapdbFamilyRecord, TapdbFamilyRevisionRecord]] = []
        tenant_key = str(tenant_id) if tenant_id else None

        for instance in self._instances_for_template(FAMILY_TEMPLATE_CODE):
            family = self._to_family(instance)
            if tenant_key and str(family.tenant_id) != tenant_key:
                continue
            revision = self._get_latest_family_revision(instance)
            if revision is None:
                continue
            rows.append((family, revision))

        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[offset : offset + limit]

    def _get_latest_family_revision(
        self, family_instance: generic_instance
    ) -> TapdbFamilyRevisionRecord | None:
        children = get_child_instances(self.db, family_instance, FAMILY_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_family_revision(c) for c in children]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0]

    # ------------------------------------------------------------------
    # Instance helpers
    # ------------------------------------------------------------------

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            FAMILY_TEMPLATE_CODE,
            name="Atlas Family",
            instance_prefix=FAMILY_PREFIX,
            json_addl={"managed_by": "lsmc-atlas", "domain": "people"},
        )
        self._ensure_template(
            FAMILY_REV_TEMPLATE_CODE,
            name="Atlas Family Revision",
            instance_prefix=FAMILY_REV_PREFIX,
            json_addl={"managed_by": "lsmc-atlas", "domain": "people"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        *,
        name: str,
        instance_prefix: str,
        json_addl: dict[str, Any],
    ) -> None:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = select(generic_template).where(
            generic_template.category == category,
            generic_template.type == type_,
            generic_template.subtype == subtype,
            generic_template.version == version,
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            ensure_instance_prefix_sequence(self.db, instance_prefix)
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl=json_addl,
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
            return

        if existing.instance_prefix != instance_prefix:
            ensure_instance_prefix_sequence(self.db, instance_prefix)
            existing.instance_prefix = instance_prefix

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _resolve_family_instance(self, family_euid: str) -> generic_instance | None:
        return get_instance_by_euid(self.db, FAMILY_TEMPLATE_CODE, family_euid)

    def _to_family(self, instance: generic_instance) -> TapdbFamilyRecord:
        props = self._instance_properties(instance)
        return TapdbFamilyRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            site_id=(str(props.get("site_id")).strip() or None)
            if props.get("site_id") is not None
            else None,
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_family_revision(self, instance: generic_instance) -> TapdbFamilyRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbFamilyRevisionRecord(
            euid=instance.euid,
            family_id=str(props.get("family_id") or ""),
            revision_no=int(props.get("revision_no") or 1),
            name=str(props.get("name") or instance.name or ""),
            notes=props.get("notes"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )
