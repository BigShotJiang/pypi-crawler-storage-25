"""TapDB-backed repository adapter for Atlas collection events."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

COLLECTION_EVENT_TEMPLATE_CODE = "atlas/people/collection-event/1.0/"
COLLECTION_EVENT_REV_TEMPLATE_CODE = "atlas/people/collection-event-revision/1.0/"

COLLECTION_EVENT_PREFIX = "CEV"
COLLECTION_EVENT_REV_PREFIX = "CER"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbCollectionEventRecord:
    euid: str
    tenant_id: uuid.UUID
    patient_id: str
    site_id: str
    container_euid: str
    specimen_euid: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbCollectionEventRevisionRecord:
    euid: str
    collection_event_id: str
    revision_no: int
    collected_at: datetime | None
    collection_type: str | None
    collected_by: str | None
    expected_mrn: str | None
    expected_dob: str | None
    expected_name: str | None
    expected_label_text: str | None
    note: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


class TapdbCollectionEventRepository:
    """Collection event persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create(
        self,
        *,
        tenant_id: uuid.UUID,
        patient_id: str,
        site_id: str,
        container_euid: str,
        specimen_euid: str | None,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbCollectionEventRecord, TapdbCollectionEventRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)
        name = f"collection-{container_euid}"
        event_instance = self.factory.create_instance(
            session=self.db,
            template_code=COLLECTION_EVENT_TEMPLATE_CODE,
            name=name,
            properties={
                "tenant_id": str(tenant_id),
                "patient_id": patient_id,
                "site_id": site_id,
                "container_euid": container_euid,
                "specimen_euid": specimen_euid,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=COLLECTION_EVENT_REV_TEMPLATE_CODE,
            name=f"{name}-rev-1",
            properties={
                "collection_event_id": event_instance.euid,
                "revision_no": 1,
                "collected_at": (
                    data.collected_at.isoformat() if getattr(data, "collected_at", None) else None
                ),
                "collection_type": data.collection_type,
                "collected_by": data.collected_by,
                "expected_mrn": data.expected_mrn,
                "expected_dob": data.expected_dob,
                "expected_name": data.expected_name,
                "expected_label_text": data.expected_label_text,
                "note": "collection event created",
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=event_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_event(event_instance), self._to_revision(revision_instance)

    def get(
        self,
        *,
        collection_event_id: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbCollectionEventRecord, TapdbCollectionEventRevisionRecord] | None:
        instance = self._resolve_event_instance(collection_event_id)
        if instance is None:
            return None
        event = self._to_event(instance)
        if tenant_id is not None and event.tenant_id != tenant_id:
            return None
        revision = self._latest_revision(instance)
        if revision is None:
            return None
        return event, revision

    def list(
        self,
        *,
        tenant_id: uuid.UUID | None,
        patient_id: str | None = None,
        container_euid: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[tuple[TapdbCollectionEventRecord, TapdbCollectionEventRevisionRecord]]:
        rows: list[tuple[TapdbCollectionEventRecord, TapdbCollectionEventRevisionRecord]] = []
        tenant_key = str(tenant_id) if tenant_id else None
        patient_key = str(patient_id or "").strip() or None
        container_key = str(container_euid or "").strip() or None
        for instance in self._instances_for_template(COLLECTION_EVENT_TEMPLATE_CODE):
            event = self._to_event(instance)
            if tenant_key and str(event.tenant_id) != tenant_key:
                continue
            if patient_key and event.patient_id != patient_key:
                continue
            if container_key and event.container_euid != container_key:
                continue
            revision = self._latest_revision(instance)
            if revision is None:
                continue
            rows.append((event, revision))
        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[offset : offset + limit]

    def update(
        self,
        *,
        tenant_id: uuid.UUID,
        collection_event_id: str,
        data: Any,
        updated_by: uuid.UUID | None,
    ) -> tuple[TapdbCollectionEventRecord, TapdbCollectionEventRevisionRecord] | None:
        result = self.get(collection_event_id=collection_event_id, tenant_id=tenant_id)
        if result is None:
            return None
        event, current = result
        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=COLLECTION_EVENT_REV_TEMPLATE_CODE,
            name=f"{collection_event_id}-rev-{current.revision_no + 1}",
            properties={
                "collection_event_id": collection_event_id,
                "revision_no": current.revision_no + 1,
                "collected_at": (
                    data.collected_at.isoformat()
                    if getattr(data, "collected_at", None) is not None
                    else (current.collected_at.isoformat() if current.collected_at else None)
                ),
                "collection_type": (
                    data.collection_type
                    if getattr(data, "collection_type", None) is not None
                    else current.collection_type
                ),
                "collected_by": (
                    data.collected_by
                    if getattr(data, "collected_by", None) is not None
                    else current.collected_by
                ),
                "expected_mrn": (
                    data.expected_mrn
                    if getattr(data, "expected_mrn", None) is not None
                    else current.expected_mrn
                ),
                "expected_dob": (
                    data.expected_dob
                    if getattr(data, "expected_dob", None) is not None
                    else current.expected_dob
                ),
                "expected_name": (
                    data.expected_name
                    if getattr(data, "expected_name", None) is not None
                    else current.expected_name
                ),
                "expected_label_text": (
                    data.expected_label_text
                    if getattr(data, "expected_label_text", None) is not None
                    else current.expected_label_text
                ),
                "note": getattr(data, "note", None),
                "created_by": str(updated_by) if updated_by else None,
                "created_at": now.isoformat(),
            },
        )
        event_instance = get_instance_by_euid(
            self.db, COLLECTION_EVENT_TEMPLATE_CODE, collection_event_id
        )
        if event_instance is not None:
            self.factory.link_instances(
                session=self.db,
                parent=event_instance,
                child=revision_instance,
                relationship_type="revision",
            )
        self.db.flush()
        return event, self._to_revision(revision_instance)

    def set_specimen_euid(
        self,
        *,
        tenant_id: uuid.UUID,
        collection_event_id: str,
        specimen_euid: str,
    ) -> TapdbCollectionEventRecord | None:
        result = self.get(collection_event_id=collection_event_id, tenant_id=tenant_id)
        if result is None:
            return None
        _event, _current = result
        event_instance = get_instance_by_euid(
            self.db, COLLECTION_EVENT_TEMPLATE_CODE, collection_event_id
        )
        if event_instance is None:
            return None
        payload = getattr(event_instance, "json_addl", None) or {}
        if not isinstance(payload, dict):
            payload = {}
        props = payload.get("properties")
        if not isinstance(props, dict):
            props = {}
        props["specimen_euid"] = specimen_euid
        payload["properties"] = props
        event_instance.json_addl = payload
        flag_modified(event_instance, "json_addl")
        self.db.flush()
        return self._to_event(event_instance)

    def _latest_revision(
        self, event_instance: generic_instance
    ) -> TapdbCollectionEventRevisionRecord | None:
        children = get_child_instances(self.db, event_instance, COLLECTION_EVENT_REV_TEMPLATE_CODE)
        if not children:
            return None
        revisions = [self._to_revision(child) for child in children]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0]

    def _resolve_event_instance(self, collection_event_id: str) -> generic_instance | None:
        return get_instance_by_euid(self.db, COLLECTION_EVENT_TEMPLATE_CODE, collection_event_id)

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            COLLECTION_EVENT_TEMPLATE_CODE,
            name="Atlas Collection Event",
            instance_prefix=COLLECTION_EVENT_PREFIX,
            json_addl={"managed_by": "lsmc-atlas", "domain": "people"},
        )
        self._ensure_template(
            COLLECTION_EVENT_REV_TEMPLATE_CODE,
            name="Atlas Collection Event Revision",
            instance_prefix=COLLECTION_EVENT_REV_PREFIX,
            json_addl={"managed_by": "lsmc-atlas", "domain": "people"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        *,
        name: str,
        instance_prefix: str,
        json_addl: dict[str, Any] | None = None,
    ) -> None:
        category, type_name, subtype, version = _parse_template_code(template_code)
        existing = self.db.execute(
            select(generic_template).where(
                generic_template.category == category,
                generic_template.type == type_name,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
        ).scalar_one_or_none()
        if existing is None:
            ensure_instance_prefix_sequence(self.db, instance_prefix)
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_name,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl=json_addl or {},
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_name, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_name,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _to_event(self, instance: generic_instance) -> TapdbCollectionEventRecord:
        props = self._instance_props(instance)
        return TapdbCollectionEventRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            patient_id=str(props.get("patient_id") or ""),
            site_id=str(props.get("site_id") or ""),
            container_euid=str(props.get("container_euid") or ""),
            specimen_euid=str(props.get("specimen_euid") or "") or None,
            created_at=_to_dt(props.get("created_at")) or getattr(instance, "created_dt", None),
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_revision(self, instance: generic_instance) -> TapdbCollectionEventRevisionRecord:
        props = self._instance_props(instance)
        return TapdbCollectionEventRevisionRecord(
            euid=instance.euid,
            collection_event_id=str(props.get("collection_event_id") or ""),
            revision_no=int(props.get("revision_no") or 1),
            collected_at=_to_dt(props.get("collected_at")),
            collection_type=str(props.get("collection_type") or "") or None,
            collected_by=str(props.get("collected_by") or "") or None,
            expected_mrn=str(props.get("expected_mrn") or "") or None,
            expected_dob=str(props.get("expected_dob") or "") or None,
            expected_name=str(props.get("expected_name") or "") or None,
            expected_label_text=str(props.get("expected_label_text") or "") or None,
            note=str(props.get("note") or "") or None,
            created_at=_to_dt(props.get("created_at")) or getattr(instance, "created_dt", None),
            created_by=_parse_uuid(props.get("created_by")),
        )

    @staticmethod
    def _instance_props(instance: generic_instance) -> dict[str, Any]:
        payload = getattr(instance, "json_addl", None) or {}
        if isinstance(payload, dict):
            props = payload.get("properties")
            if isinstance(props, dict):
                return dict(props)
        return {}
