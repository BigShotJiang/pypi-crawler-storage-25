"""TapDB-backed persistence for Atlas organization/site storage policies."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import func, select
from sqlalchemy.orm import Session

ORG_STORAGE_POLICY_TEMPLATE_CODE = "atlas/integration/storage-policy-org/1.0/"
SITE_STORAGE_POLICY_TEMPLATE_CODE = "atlas/integration/storage-policy-site/1.0/"

# TapDB instance prefixes must avoid ambiguous letters (I/L/O/U).
ORG_STORAGE_POLICY_PREFIX = "SPG"
SITE_STORAGE_POLICY_PREFIX = "SPT"


StorageAccessMode = str


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


def _as_bool(value: Any, default: bool = False) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value or "").strip().lower()
    if not text:
        return default
    return text in {"1", "true", "yes", "y"}


def _as_str_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    return []


@dataclass(frozen=True)
class TapdbStoragePolicyRecord:
    policy_euid: str
    organization_euid: str
    site_euid: str | None
    bucket: str
    region: str
    base_prefix: str
    access_mode: StorageAccessMode
    assume_role_arn: str | None
    kms_key_arn: str | None
    allowed_artifact_classes: list[str]
    enabled: bool
    created_at: datetime | None
    created_by: uuid.UUID | None
    modified_at: datetime | None
    modified_by: uuid.UUID | None


class TapdbStoragePolicyRepository:
    """Organization/site storage-policy persistence backed by TapDB templates."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def upsert_org_policy(
        self,
        *,
        organization_euid: str,
        bucket: str,
        region: str,
        base_prefix: str,
        access_mode: StorageAccessMode,
        assume_role_arn: str | None,
        kms_key_arn: str | None,
        allowed_artifact_classes: list[str],
        enabled: bool,
        actor_id: uuid.UUID | None,
    ) -> TapdbStoragePolicyRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        clean_org = str(organization_euid).strip()
        existing = self._find_org_policy_instance(clean_org)
        if existing is None:
            props = {
                "organization_euid": clean_org,
                "site_euid": "",
                "bucket": str(bucket).strip(),
                "region": str(region).strip(),
                "base_prefix": str(base_prefix or "").strip().strip("/"),
                "access_mode": str(access_mode).strip(),
                "assume_role_arn": str(assume_role_arn or "").strip() or None,
                "kms_key_arn": str(kms_key_arn or "").strip() or None,
                "allowed_artifact_classes": [
                    str(item).strip() for item in allowed_artifact_classes if str(item).strip()
                ],
                "enabled": bool(enabled),
                "created_by": str(actor_id) if actor_id else None,
                "created_at": now.isoformat(),
                "modified_by": str(actor_id) if actor_id else None,
                "modified_at": now.isoformat(),
            }
            instance = self.factory.create_instance(
                session=self.db,
                template_code=ORG_STORAGE_POLICY_TEMPLATE_CODE,
                name=f"org-policy:{clean_org}",
                properties=props,
            )
            self.db.commit()
            return self._to_storage_policy(instance)

        props = self._instance_properties(existing)
        props.update(
            {
                "organization_euid": clean_org,
                "site_euid": "",
                "bucket": str(bucket).strip(),
                "region": str(region).strip(),
                "base_prefix": str(base_prefix or "").strip().strip("/"),
                "access_mode": str(access_mode).strip(),
                "assume_role_arn": str(assume_role_arn or "").strip() or None,
                "kms_key_arn": str(kms_key_arn or "").strip() or None,
                "allowed_artifact_classes": [
                    str(item).strip() for item in allowed_artifact_classes if str(item).strip()
                ],
                "enabled": bool(enabled),
                "modified_by": str(actor_id) if actor_id else None,
                "modified_at": now.isoformat(),
            }
        )
        self._write_instance_properties(existing, props)
        self.db.commit()
        self.db.refresh(existing)
        return self._to_storage_policy(existing)

    def upsert_site_policy(
        self,
        *,
        organization_euid: str,
        site_euid: str,
        bucket: str,
        region: str,
        base_prefix: str,
        access_mode: StorageAccessMode,
        assume_role_arn: str | None,
        kms_key_arn: str | None,
        allowed_artifact_classes: list[str],
        enabled: bool,
        actor_id: uuid.UUID | None,
    ) -> TapdbStoragePolicyRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        clean_org = str(organization_euid).strip()
        clean_site = str(site_euid).strip()
        existing = self._find_site_policy_instance(clean_org, clean_site)
        if existing is None:
            props = {
                "organization_euid": clean_org,
                "site_euid": clean_site,
                "bucket": str(bucket).strip(),
                "region": str(region).strip(),
                "base_prefix": str(base_prefix or "").strip().strip("/"),
                "access_mode": str(access_mode).strip(),
                "assume_role_arn": str(assume_role_arn or "").strip() or None,
                "kms_key_arn": str(kms_key_arn or "").strip() or None,
                "allowed_artifact_classes": [
                    str(item).strip() for item in allowed_artifact_classes if str(item).strip()
                ],
                "enabled": bool(enabled),
                "created_by": str(actor_id) if actor_id else None,
                "created_at": now.isoformat(),
                "modified_by": str(actor_id) if actor_id else None,
                "modified_at": now.isoformat(),
            }
            instance = self.factory.create_instance(
                session=self.db,
                template_code=SITE_STORAGE_POLICY_TEMPLATE_CODE,
                name=f"site-policy:{clean_org}:{clean_site}",
                properties=props,
            )
            self.db.commit()
            return self._to_storage_policy(instance)

        props = self._instance_properties(existing)
        props.update(
            {
                "organization_euid": clean_org,
                "site_euid": clean_site,
                "bucket": str(bucket).strip(),
                "region": str(region).strip(),
                "base_prefix": str(base_prefix or "").strip().strip("/"),
                "access_mode": str(access_mode).strip(),
                "assume_role_arn": str(assume_role_arn or "").strip() or None,
                "kms_key_arn": str(kms_key_arn or "").strip() or None,
                "allowed_artifact_classes": [
                    str(item).strip() for item in allowed_artifact_classes if str(item).strip()
                ],
                "enabled": bool(enabled),
                "modified_by": str(actor_id) if actor_id else None,
                "modified_at": now.isoformat(),
            }
        )
        self._write_instance_properties(existing, props)
        self.db.commit()
        self.db.refresh(existing)
        return self._to_storage_policy(existing)

    def get_org_policy(self, organization_euid: str) -> TapdbStoragePolicyRecord | None:
        instance = self._find_org_policy_instance(str(organization_euid).strip())
        if instance is None:
            return None
        return self._to_storage_policy(instance)

    def get_site_policy(
        self,
        organization_euid: str,
        site_euid: str,
    ) -> TapdbStoragePolicyRecord | None:
        instance = self._find_site_policy_instance(
            str(organization_euid).strip(),
            str(site_euid).strip(),
        )
        if instance is None:
            return None
        return self._to_storage_policy(instance)

    def clear_site_policy(self, organization_euid: str, site_euid: str) -> bool:
        instance = self._find_site_policy_instance(
            str(organization_euid).strip(),
            str(site_euid).strip(),
        )
        if instance is None:
            return False
        instance.is_deleted = True
        self.db.commit()
        return True

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            ORG_STORAGE_POLICY_TEMPLATE_CODE,
            ORG_STORAGE_POLICY_PREFIX,
            "Atlas Organization Storage Policy",
            {"managed_by": "lsmc-atlas", "domain": "storage_policies", "scope": "organization"},
        )
        self._ensure_template(
            SITE_STORAGE_POLICY_TEMPLATE_CODE,
            SITE_STORAGE_POLICY_PREFIX,
            "Atlas Site Storage Policy",
            {"managed_by": "lsmc-atlas", "domain": "storage_policies", "scope": "site"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl=json_addl,
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != instance_prefix:
                existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _query_instances_for_template(
        self,
        template_code: str,
        *,
        property_filters: dict[str, str | None] | None = None,
    ):
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        for key, value in (property_filters or {}).items():
            if value is None:
                continue
            stmt = stmt.where(
                func.jsonb_extract_path_text(
                    generic_instance.json_addl["properties"],
                    key,
                )
                == str(value)
            )
        return stmt

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties") if isinstance(raw, dict) else None
        return dict(props) if isinstance(props, dict) else {}

    def _write_instance_properties(self, instance: generic_instance, props: dict[str, Any]) -> None:
        raw = dict(instance.json_addl or {})
        raw["properties"] = props
        instance.json_addl = raw

    def _find_org_policy_instance(self, organization_euid: str) -> generic_instance | None:
        stmt = self._query_instances_for_template(
            ORG_STORAGE_POLICY_TEMPLATE_CODE,
            property_filters={"organization_euid": str(organization_euid)},
        ).limit(1)
        return self.db.execute(stmt).scalar_one_or_none()

    def _find_site_policy_instance(
        self,
        organization_euid: str,
        site_euid: str,
    ) -> generic_instance | None:
        stmt = self._query_instances_for_template(
            SITE_STORAGE_POLICY_TEMPLATE_CODE,
            property_filters={
                "organization_euid": str(organization_euid),
                "site_euid": str(site_euid),
            },
        ).limit(1)
        return self.db.execute(stmt).scalar_one_or_none()

    def _to_storage_policy(self, instance: generic_instance) -> TapdbStoragePolicyRecord:
        props = self._instance_properties(instance)
        return TapdbStoragePolicyRecord(
            policy_euid=instance.euid,
            organization_euid=str(props.get("organization_euid") or ""),
            site_euid=(str(props.get("site_euid") or "").strip() or None),
            bucket=str(props.get("bucket") or ""),
            region=str(props.get("region") or "us-west-2"),
            base_prefix=str(props.get("base_prefix") or "").strip().strip("/"),
            access_mode=str(props.get("access_mode") or "lsmc_managed"),
            assume_role_arn=str(props.get("assume_role_arn") or "").strip() or None,
            kms_key_arn=str(props.get("kms_key_arn") or "").strip() or None,
            allowed_artifact_classes=_as_str_list(props.get("allowed_artifact_classes")),
            enabled=_as_bool(props.get("enabled"), default=False),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            modified_at=_to_dt(props.get("modified_at"))
            or instance.modified_dt
            or instance.created_dt,
            modified_by=_parse_uuid(props.get("modified_by")),
        )
