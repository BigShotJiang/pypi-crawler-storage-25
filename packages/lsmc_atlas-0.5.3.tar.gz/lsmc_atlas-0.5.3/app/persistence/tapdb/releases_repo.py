"""TapDB-backed repository adapter for Atlas release packages."""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import (
    get_child_instances,
    get_instance_by_euid,
    get_parent_instances,
)

RELEASE_PACKAGE_TEMPLATE_CODE = "atlas/delivery/release-package/1.0/"
RELEASE_PACKAGE_REV_TEMPLATE_CODE = "atlas/delivery/release-package-revision/1.0/"
RELEASE_ARTIFACT_TEMPLATE_CODE = "atlas/reference/artifact/1.0/"
RELEASE_ARTIFACT_REF_TEMPLATE_CODE = "atlas/reference/artifact-link/1.0/"

RELEASE_PACKAGE_PREFIX = "RPK"
RELEASE_PACKAGE_REV_PREFIX = "RPR"
RELEASE_ARTIFACT_PREFIX = "ART"
RELEASE_ARTIFACT_REF_PREFIX = "AAF"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbReleasePackageRecord:
    euid: str
    tenant_id: uuid.UUID
    package_number: str
    order_id: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None

    @property
    def id(self) -> str:
        """Legacy compatibility alias used by older route code."""
        return self.euid


@dataclass
class TapdbReleasePackageRevisionRecord:
    euid: str
    release_package_id: str
    revision_no: int
    status: str
    artifact_ids: list[str]
    release_notes: str | None
    released_at: datetime | None
    released_by: uuid.UUID | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None
    release_type: str = "INITIAL"

    @property
    def id(self) -> str:
        """Legacy compatibility alias used by older route code."""
        return self.euid


@dataclass
class TapdbArtifactRecord:
    euid: str
    tenant_id: uuid.UUID
    source_system: str
    source_uid: str
    filename: str
    checksum: str
    checksum_algorithm: str
    content_type: str | None
    size_bytes: int | None
    artifact_type: str | None
    s3_bucket: str | None
    s3_key: str | None
    artifact_metadata: dict[str, Any]
    created_at: datetime | None
    created_by: uuid.UUID | None

    @property
    def id(self) -> str:
        return self.euid

    @property
    def mime_type(self) -> str | None:
        """Legacy compatibility alias used by API/web response mappers."""
        return self.content_type

    @property
    def checksum_sha256(self) -> str | None:
        """Legacy compatibility alias used by API/web response mappers."""
        return self.checksum

    @property
    def storage_uri(self) -> str | None:
        """Build an S3 URI when bucket/key metadata is present."""
        if self.s3_bucket and self.s3_key:
            return f"s3://{self.s3_bucket}/{self.s3_key}"
        return None


class TapdbReleaseRepository:
    """Release package persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def generate_next_package_number(self) -> str:
        max_num = 0
        for instance in self._instances_for_template(RELEASE_PACKAGE_TEMPLATE_CODE):
            package = self._to_package(instance)
            match = re.fullmatch(r"REL-(\d+)", package.package_number or "")
            if match:
                max_num = max(max_num, int(match.group(1)))
        return f"REL-{max_num + 1}"

    def create_package(
        self,
        *,
        tenant_id: uuid.UUID,
        package_number: str,
        data: Any,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbReleasePackageRecord, TapdbReleasePackageRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)
        package_instance = self.factory.create_instance(
            session=self.db,
            template_code=RELEASE_PACKAGE_TEMPLATE_CODE,
            name=package_number,
            properties={
                "tenant_id": str(tenant_id),
                "package_number": package_number,
                "order_id": str(getattr(data, "order_id", None))
                if getattr(data, "order_id", None)
                else None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=RELEASE_PACKAGE_REV_TEMPLATE_CODE,
            name=f"{package_number}-rev-1",
            properties={
                "revision_no": 1,
                "status": "DRAFT",
                "release_notes": getattr(data, "release_notes", None),
                "released_at": None,
                "released_by": None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": None,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=package_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        for artifact_id in [
            str(item) for item in (getattr(data, "artifact_ids", None) or []) if item
        ]:
            self._create_artifact_ref(
                parent=revision_instance, artifact_euid=artifact_id, created_by=created_by
            )
        self.db.flush()
        return self._to_package(package_instance), self._to_revision(revision_instance)

    def create_package_revision(
        self,
        *,
        package_id: str,
        status: str,
        artifact_ids: list[str],
        release_notes: str | None,
        released_at: datetime | None,
        released_by: uuid.UUID | None,
        note: str | None,
        created_by: uuid.UUID | None,
    ) -> TapdbReleasePackageRevisionRecord | None:
        package = self.get_package_by_id(package_id=package_id, tenant_id=None)
        if package is None:
            return None
        latest = self.get_latest_revision(package_id)
        if latest is None:
            return None
        package_instance = get_instance_by_euid(self.db, RELEASE_PACKAGE_TEMPLATE_CODE, package_id)
        if package_instance is None:
            return None

        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=RELEASE_PACKAGE_REV_TEMPLATE_CODE,
            name=f"{package.package_number}-rev-{latest.revision_no + 1}",
            properties={
                "revision_no": latest.revision_no + 1,
                "status": status,
                "release_notes": release_notes,
                "released_at": released_at.isoformat() if released_at else None,
                "released_by": str(released_by) if released_by else None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": note,
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=package_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        for artifact_id in artifact_ids:
            self._create_artifact_ref(
                parent=revision_instance, artifact_euid=artifact_id, created_by=created_by
            )
        self.db.flush()
        return self._to_revision(revision_instance)

    def get_package_by_id(
        self, *, package_id: str, tenant_id: uuid.UUID | None
    ) -> TapdbReleasePackageRecord | None:
        instance = get_instance_by_euid(self.db, RELEASE_PACKAGE_TEMPLATE_CODE, package_id)
        if instance is None or instance.is_deleted:
            return None
        package = self._to_package(instance)
        if tenant_id is not None and package.tenant_id != tenant_id:
            return None
        return package

    def get_package_by_number(
        self,
        *,
        package_number: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbReleasePackageRecord, TapdbReleasePackageRevisionRecord] | None:
        normalized = (package_number or "").strip()
        for instance in self._instances_for_template(RELEASE_PACKAGE_TEMPLATE_CODE):
            package = self._to_package(instance)
            if package.package_number != normalized:
                continue
            if tenant_id is not None and package.tenant_id != tenant_id:
                continue
            revision = self.get_latest_revision(package.euid)
            if revision is None:
                return None
            return package, revision
        return None

    def list_packages(
        self,
        *,
        tenant_id: uuid.UUID | None,
        skip: int,
        limit: int,
        order_id: str | None = None,
    ) -> list[tuple[TapdbReleasePackageRecord, TapdbReleasePackageRevisionRecord | None]]:
        rows: list[tuple[TapdbReleasePackageRecord, TapdbReleasePackageRevisionRecord | None]] = []
        for instance in self._instances_for_template(RELEASE_PACKAGE_TEMPLATE_CODE):
            package = self._to_package(instance)
            if tenant_id is not None and package.tenant_id != tenant_id:
                continue
            if order_id is not None and package.order_id != order_id:
                continue
            rows.append((package, self.get_latest_revision(package.euid)))
        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC), reverse=True
        )
        return rows[skip : skip + limit]

    def list_by_order(
        self, *, order_id: str, tenant_id: uuid.UUID | None
    ) -> list[TapdbReleasePackageRecord]:
        rows = self.list_packages(tenant_id=tenant_id, skip=0, limit=10_000, order_id=order_id)
        return [package for package, _revision in rows]

    def get_latest_revision(self, package_id: str) -> TapdbReleasePackageRevisionRecord | None:
        package_instance = get_instance_by_euid(self.db, RELEASE_PACKAGE_TEMPLATE_CODE, package_id)
        if package_instance is None:
            return None
        revisions = [
            self._to_revision(child)
            for child in get_child_instances(
                self.db, package_instance, RELEASE_PACKAGE_REV_TEMPLATE_CODE
            )
        ]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0] if revisions else None

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            RELEASE_PACKAGE_TEMPLATE_CODE, "Atlas Release Package", RELEASE_PACKAGE_PREFIX
        )
        self._ensure_template(
            RELEASE_PACKAGE_REV_TEMPLATE_CODE,
            "Atlas Release Package Revision",
            RELEASE_PACKAGE_REV_PREFIX,
        )
        self._ensure_template(
            RELEASE_ARTIFACT_TEMPLATE_CODE, "Atlas Artifact", RELEASE_ARTIFACT_PREFIX
        )
        self._ensure_template(
            RELEASE_ARTIFACT_REF_TEMPLATE_CODE, "Atlas Artifact Link", RELEASE_ARTIFACT_REF_PREFIX
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(self, template_code: str, name: str, instance_prefix: str) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl={"managed_by": "lsmc-atlas", "domain": "delivery"},
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != instance_prefix:
                existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def create_artifact(
        self,
        *,
        tenant_id: uuid.UUID,
        source_system: str,
        source_uid: str,
        filename: str,
        checksum: str,
        checksum_algorithm: str,
        content_type: str | None,
        size_bytes: int | None,
        artifact_type: str | None,
        s3_bucket: str | None,
        s3_key: str | None,
        metadata: dict[str, Any] | None,
        created_by: uuid.UUID | None,
    ) -> TapdbArtifactRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        instance = self.factory.create_instance(
            session=self.db,
            template_code=RELEASE_ARTIFACT_TEMPLATE_CODE,
            name=filename or source_uid,
            properties={
                "tenant_id": str(tenant_id),
                "source_system": source_system,
                "source_uid": source_uid,
                "filename": filename,
                "checksum": checksum,
                "checksum_algorithm": checksum_algorithm,
                "content_type": content_type,
                "size_bytes": size_bytes,
                "artifact_type": artifact_type,
                "s3_bucket": s3_bucket,
                "s3_key": s3_key,
                "artifact_metadata": dict(metadata or {}),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.db.flush()
        return self._to_artifact(instance)

    def get_artifact_by_id(
        self, *, artifact_id: str, tenant_id: uuid.UUID | None
    ) -> TapdbArtifactRecord | None:
        instance = get_instance_by_euid(self.db, RELEASE_ARTIFACT_TEMPLATE_CODE, artifact_id)
        if instance is None or instance.is_deleted:
            return None
        artifact = self._to_artifact(instance)
        if tenant_id is not None and artifact.tenant_id != tenant_id:
            return None
        return artifact

    def get_artifact_by_source(
        self,
        *,
        source_system: str,
        source_uid: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbArtifactRecord | None:
        normalized_system = (source_system or "").strip()
        normalized_uid = (source_uid or "").strip()
        for instance in self._instances_for_template(RELEASE_ARTIFACT_TEMPLATE_CODE):
            artifact = self._to_artifact(instance)
            if artifact.source_system != normalized_system or artifact.source_uid != normalized_uid:
                continue
            if tenant_id is not None and artifact.tenant_id != tenant_id:
                continue
            return artifact
        return None

    def list_artifacts(
        self,
        *,
        tenant_id: uuid.UUID | None,
        skip: int,
        limit: int,
    ) -> list[TapdbArtifactRecord]:
        rows: list[TapdbArtifactRecord] = []
        for instance in self._instances_for_template(RELEASE_ARTIFACT_TEMPLATE_CODE):
            artifact = self._to_artifact(instance)
            if tenant_id is not None and artifact.tenant_id != tenant_id:
                continue
            rows.append(artifact)
        rows.sort(key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC), reverse=True)
        return rows[skip : skip + limit]

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _create_artifact_ref(
        self, *, parent: generic_instance, artifact_euid: str, created_by: uuid.UUID | None
    ) -> None:
        now = datetime.now(UTC)
        ref = self.factory.create_instance(
            session=self.db,
            template_code=RELEASE_ARTIFACT_REF_TEMPLATE_CODE,
            name=f"artifact:{artifact_euid}",
            properties={
                "artifact_euid": artifact_euid,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=parent,
            child=ref,
            relationship_type="artifact_reference",
        )

    def _artifact_euids_for_revision(self, revision_instance: generic_instance) -> list[str]:
        refs = get_child_instances(self.db, revision_instance, RELEASE_ARTIFACT_REF_TEMPLATE_CODE)
        artifact_ids: list[str] = []
        for ref in refs:
            props = self._instance_properties(ref)
            artifact_euid = str(props.get("artifact_euid") or "").strip()
            if artifact_euid:
                artifact_ids.append(artifact_euid)
        return artifact_ids

    def _to_package(self, instance: generic_instance) -> TapdbReleasePackageRecord:
        props = self._instance_properties(instance)
        return TapdbReleasePackageRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            package_number=str(props.get("package_number") or instance.name or ""),
            order_id=props.get("order_id"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_revision(self, instance: generic_instance) -> TapdbReleasePackageRevisionRecord:
        props = self._instance_properties(instance)
        parents = get_parent_instances(self.db, instance, RELEASE_PACKAGE_TEMPLATE_CODE)
        package = parents[0] if parents else None
        return TapdbReleasePackageRevisionRecord(
            euid=instance.euid,
            release_package_id=package.euid if package is not None else "",
            revision_no=int(props.get("revision_no") or 1),
            status=str(props.get("status") or "DRAFT"),
            artifact_ids=self._artifact_euids_for_revision(instance),
            release_notes=props.get("release_notes"),
            released_at=_to_dt(props.get("released_at")),
            released_by=_parse_uuid(props.get("released_by")),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    def _to_artifact(self, instance: generic_instance) -> TapdbArtifactRecord:
        props = self._instance_properties(instance)
        metadata = props.get("artifact_metadata")
        if not isinstance(metadata, dict):
            metadata = {}
        return TapdbArtifactRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            source_system=str(props.get("source_system") or ""),
            source_uid=str(props.get("source_uid") or ""),
            filename=str(props.get("filename") or instance.name or ""),
            checksum=str(props.get("checksum") or ""),
            checksum_algorithm=str(props.get("checksum_algorithm") or "sha256"),
            content_type=props.get("content_type"),
            size_bytes=int(props["size_bytes"]) if props.get("size_bytes") is not None else None,
            artifact_type=props.get("artifact_type"),
            s3_bucket=props.get("s3_bucket"),
            s3_key=props.get("s3_key"),
            artifact_metadata=dict(metadata),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )
