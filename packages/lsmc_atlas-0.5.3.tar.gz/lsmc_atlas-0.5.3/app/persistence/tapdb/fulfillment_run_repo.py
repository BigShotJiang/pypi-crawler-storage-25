"""TapDB-backed repository adapter for assay workflow entities."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import (
    get_child_instances,
    get_instance_by_euid,
    get_parent_instances,
)
from app.persistence.tapdb.trfs import TEST_TEMPLATE_CODE, TRF_TEMPLATE_CODE

FULFILLMENT_RUN_TEMPLATE_CODE = "atlas/fulfillment/run/1.0/"
FULFILLMENT_RUN_REV_TEMPLATE_CODE = "atlas/fulfillment/run-revision/1.0/"
FULFILLMENT_OUTPUT_TEMPLATE_CODE = "atlas/fulfillment/output/1.0/"
RESULTS_SET_TEMPLATE_CODE = "atlas/assay/results-set/1.0/"
FULFILLMENT_ARTIFACT_REF_TEMPLATE_CODE = "atlas/reference/artifact-link/1.0/"
FULFILLMENT_OUTPUT_CONTEXT_REF_TEMPLATE_CODE = "atlas/reference/analysis-return-context/1.0/"

ASSAY_RUN_PREFIX = "ARX"
ASSAY_RUN_REV_PREFIX = "ARV"
ASSAY_RESULT_PREFIX = "ASX"
RESULTS_SET_PREFIX = "RSX"
ASSAY_ARTIFACT_REF_PREFIX = "AAF"
ASSAY_RESULT_CONTEXT_REF_PREFIX = "ARC"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbFulfillmentRunRecord:
    euid: str
    tenant_id: uuid.UUID
    order_id: str
    test_order_id: str
    fulfillment_route_code: str
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbFulfillmentRunRevisionRecord:
    euid: str
    fulfillment_run_euid: str
    revision_no: int
    status: str
    accession_id: str | None
    qc_hold_reason: str | None
    qc_override: bool
    note: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbFulfillmentOutputRecord:
    euid: str
    tenant_id: uuid.UUID
    fulfillment_run_euid: str
    version_no: int
    result_payload: dict | None
    artifact_ids: list[str] | None
    amends_result_euid: str | None
    amend_reason: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbResultsSetRecord:
    euid: str
    tenant_id: uuid.UUID
    test_euid: str
    published_at: datetime | None
    published_by: uuid.UUID | None
    note: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None


@dataclass
class TapdbResultsSetAssayRecord:
    euid: str
    results_set_euid: str
    fulfillment_run_euid: str
    created_at: datetime | None


class TapdbFulfillmentRunRepository:
    """Assay workflow persistence backed by TapDB templates and lineage."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_fulfillment_run(
        self,
        *,
        tenant_id: uuid.UUID,
        order_id: str,
        test_order_id: str,
        fulfillment_route_code: str,
        created_by: uuid.UUID | None,
    ) -> tuple[TapdbFulfillmentRunRecord, TapdbFulfillmentRunRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)
        trf_instance = get_instance_by_euid(self.db, TRF_TEMPLATE_CODE, order_id)
        test_instance = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, test_order_id)
        if trf_instance is None:
            raise ValueError(f"TRF not found: {order_id}")
        if test_instance is None:
            raise ValueError(f"Test not found: {test_order_id}")
        props = {
            "tenant_id": str(tenant_id),
            "fulfillment_route_code": fulfillment_route_code,
            "created_by": str(created_by) if created_by else None,
            "created_at": now.isoformat(),
        }
        run_instance = self.factory.create_instance(
            session=self.db,
            template_code=FULFILLMENT_RUN_TEMPLATE_CODE,
            name=f"{fulfillment_route_code}-run",
            properties=props,
        )
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=FULFILLMENT_RUN_REV_TEMPLATE_CODE,
            name=f"{fulfillment_route_code}-rev-1",
            properties={
                "revision_no": 1,
                "status": "DRAFT",
                "accession_id": None,
                "qc_hold_reason": None,
                "qc_override": False,
                "note": None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=run_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.factory.link_instances(
            session=self.db,
            parent=trf_instance,
            child=run_instance,
            relationship_type="fulfillment_run_trf",
        )
        self.factory.link_instances(
            session=self.db,
            parent=test_instance,
            child=run_instance,
            relationship_type="fulfillment_run_test",
        )
        self.db.flush()
        return self._to_assay_run(run_instance), self._to_assay_run_revision(revision_instance)

    def create_fulfillment_run_revision(
        self,
        *,
        fulfillment_run_euid: str,
        status: str,
        accession_id: str | None,
        qc_hold_reason: str | None,
        qc_override: bool,
        note: str | None,
        created_by: uuid.UUID | None,
    ) -> TapdbFulfillmentRunRevisionRecord | None:
        current = self.get_fulfillment_run_with_revision(
            fulfillment_run_euid=fulfillment_run_euid, tenant_id=None
        )
        if current is None:
            return None
        run, latest = current
        run_instance = self._resolve_fulfillment_run_instance(fulfillment_run_euid)
        if run_instance is None:
            return None

        now = datetime.now(UTC)
        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=FULFILLMENT_RUN_REV_TEMPLATE_CODE,
            name=f"{run.fulfillment_route_code}-rev-{latest.revision_no + 1}",
            properties={
                "revision_no": latest.revision_no + 1,
                "status": status,
                "accession_id": accession_id,
                "qc_hold_reason": qc_hold_reason,
                "qc_override": qc_override,
                "note": note,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=run_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.flush()
        return self._to_assay_run_revision(revision_instance)

    def get_fulfillment_run_with_revision(
        self,
        *,
        fulfillment_run_euid: str,
        tenant_id: uuid.UUID | None,
    ) -> tuple[TapdbFulfillmentRunRecord, TapdbFulfillmentRunRevisionRecord] | None:
        run = self.get_fulfillment_run_by_euid(
            fulfillment_run_euid=fulfillment_run_euid, tenant_id=tenant_id
        )
        if run is None:
            return None
        revision = self.get_latest_fulfillment_run_revision(fulfillment_run_euid)
        if revision is None:
            return None
        return run, revision

    def get_fulfillment_run_by_euid(
        self,
        *,
        fulfillment_run_euid: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbFulfillmentRunRecord | None:
        instance = get_instance_by_euid(
            self.db, FULFILLMENT_RUN_TEMPLATE_CODE, fulfillment_run_euid
        )
        if instance is None:
            return None
        run = self._to_assay_run(instance)
        if tenant_id is not None and run.tenant_id != tenant_id:
            return None
        return run

    def get_fulfillment_run_by_test_order_and_code(
        self,
        *,
        test_order_id: str,
        fulfillment_route_code: str,
        tenant_id: uuid.UUID,
    ) -> tuple[TapdbFulfillmentRunRecord, TapdbFulfillmentRunRevisionRecord] | None:
        code = str(fulfillment_route_code).strip()
        test_instance = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, test_order_id)
        if test_instance is None:
            return None
        for instance in get_child_instances(self.db, test_instance, FULFILLMENT_RUN_TEMPLATE_CODE):
            run = self._to_assay_run(instance)
            if (
                run.tenant_id != tenant_id
                or run.test_order_id != test_order_id
                or run.fulfillment_route_code != code
            ):
                continue
            revision = self.get_latest_fulfillment_run_revision(run.euid)
            if revision is None:
                continue
            return run, revision
        return None

    def list_fulfillment_runs_for_order(
        self,
        *,
        order_id: str,
        tenant_id: uuid.UUID,
    ) -> list[tuple[TapdbFulfillmentRunRecord, TapdbFulfillmentRunRevisionRecord]]:
        rows: list[tuple[TapdbFulfillmentRunRecord, TapdbFulfillmentRunRevisionRecord]] = []
        trf_instance = get_instance_by_euid(self.db, TRF_TEMPLATE_CODE, order_id)
        if trf_instance is None:
            return rows
        for instance in get_child_instances(self.db, trf_instance, FULFILLMENT_RUN_TEMPLATE_CODE):
            run = self._to_assay_run(instance)
            if run.tenant_id != tenant_id or run.order_id != order_id:
                continue
            revision = self.get_latest_fulfillment_run_revision(run.euid)
            if revision is not None:
                rows.append((run, revision))
        rows.sort(key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC))
        return rows

    def list_fulfillment_runs_for_test_order(
        self,
        *,
        test_order_id: str,
        tenant_id: uuid.UUID,
    ) -> list[tuple[TapdbFulfillmentRunRecord, TapdbFulfillmentRunRevisionRecord]]:
        rows: list[tuple[TapdbFulfillmentRunRecord, TapdbFulfillmentRunRevisionRecord]] = []
        test_instance = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, test_order_id)
        if test_instance is None:
            return rows
        for instance in get_child_instances(self.db, test_instance, FULFILLMENT_RUN_TEMPLATE_CODE):
            run = self._to_assay_run(instance)
            if run.tenant_id != tenant_id or run.test_order_id != test_order_id:
                continue
            revision = self.get_latest_fulfillment_run_revision(run.euid)
            if revision is not None:
                rows.append((run, revision))
        rows.sort(key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC))
        return rows

    def get_latest_fulfillment_run_revision(
        self, fulfillment_run_euid: str
    ) -> TapdbFulfillmentRunRevisionRecord | None:
        run_instance = self._resolve_fulfillment_run_instance(fulfillment_run_euid)
        if run_instance is None:
            return None
        children = get_child_instances(self.db, run_instance, FULFILLMENT_RUN_REV_TEMPLATE_CODE)
        revisions = [self._to_assay_run_revision(child) for child in children]
        revisions.sort(key=lambda row: row.revision_no, reverse=True)
        return revisions[0] if revisions else None

    def create_fulfillment_output(
        self,
        *,
        tenant_id: uuid.UUID,
        fulfillment_run_euid: str,
        version_no: int,
        result_payload: dict | None,
        artifact_ids: list[str] | None,
        analysis_context: dict[str, Any] | None,
        created_by: uuid.UUID | None,
        amends_result_euid: str | None = None,
        amend_reason: str | None = None,
    ) -> TapdbFulfillmentOutputRecord:
        self._ensure_templates()
        run_instance = self._resolve_fulfillment_run_instance(fulfillment_run_euid)
        if run_instance is None:
            raise ValueError(f"Assay run not found: {fulfillment_run_euid}")

        now = datetime.now(UTC)
        instance = self.factory.create_instance(
            session=self.db,
            template_code=FULFILLMENT_OUTPUT_TEMPLATE_CODE,
            name=f"result-v{version_no}",
            properties={
                "tenant_id": str(tenant_id),
                "version_no": version_no,
                "result_payload": result_payload,
                "amend_reason": amend_reason,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=run_instance,
            child=instance,
            relationship_type="fulfillment_output",
        )
        if amends_result_euid:
            original = get_instance_by_euid(
                self.db, FULFILLMENT_OUTPUT_TEMPLATE_CODE, amends_result_euid
            )
            if original is None:
                raise ValueError(f"Original assay result not found: {amends_result_euid}")
            self.factory.link_instances(
                session=self.db,
                parent=original,
                child=instance,
                relationship_type="amends_result",
            )
        if analysis_context:
            self._create_analysis_context_ref(
                parent=instance,
                analysis_context=analysis_context,
                created_by=created_by,
            )
        for artifact_id in artifact_ids or []:
            self._create_artifact_ref(
                parent=instance,
                artifact_euid=artifact_id,
                created_by=created_by,
            )
        self.db.flush()
        return self._to_assay_result(instance)

    def get_fulfillment_output_by_analysis_euid(
        self,
        *,
        fulfillment_run_euid: str,
        analysis_euid: str,
        tenant_id: uuid.UUID,
    ) -> TapdbFulfillmentOutputRecord | None:
        for result in self.list_fulfillment_outputs_for_run(fulfillment_run_euid, tenant_id):
            context = self._analysis_context_for_result(
                self._resolve_assay_result_instance(result.euid)
            )
            if (
                str((context or {}).get("analysis_euid") or "").strip()
                == str(analysis_euid).strip()
            ):
                return result
        return None

    def get_fulfillment_output(
        self, result_euid: str, tenant_id: uuid.UUID
    ) -> TapdbFulfillmentOutputRecord | None:
        instance = get_instance_by_euid(self.db, FULFILLMENT_OUTPUT_TEMPLATE_CODE, result_euid)
        if instance is None:
            return None
        result = self._to_assay_result(instance)
        if result.tenant_id != tenant_id:
            return None
        return result

    def list_fulfillment_outputs_for_run(
        self,
        fulfillment_run_euid: str,
        tenant_id: uuid.UUID,
    ) -> list[TapdbFulfillmentOutputRecord]:
        run_instance = self._resolve_fulfillment_run_instance(fulfillment_run_euid)
        if run_instance is None:
            return []
        rows = [
            self._to_assay_result(child)
            for child in get_child_instances(
                self.db, run_instance, FULFILLMENT_OUTPUT_TEMPLATE_CODE
            )
        ]
        rows = [row for row in rows if row.tenant_id == tenant_id]
        rows.sort(key=lambda row: row.version_no)
        return rows

    def get_latest_fulfillment_output_for_run(
        self,
        fulfillment_run_euid: str,
        tenant_id: uuid.UUID,
    ) -> TapdbFulfillmentOutputRecord | None:
        rows = self.list_fulfillment_outputs_for_run(fulfillment_run_euid, tenant_id)
        return rows[-1] if rows else None

    def get_or_create_results_set(
        self,
        *,
        tenant_id: uuid.UUID,
        test_euid: str,
        created_by: uuid.UUID | None,
    ) -> TapdbResultsSetRecord:
        existing = self.get_latest_draft_results_set_for_test(
            test_euid=test_euid,
            tenant_id=tenant_id,
        )
        if existing is not None:
            return existing

        self._ensure_templates()
        now = datetime.now(UTC)
        test_instance = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, test_euid)
        if test_instance is None:
            raise ValueError(f"Test not found: {test_euid}")
        instance = self.factory.create_instance(
            session=self.db,
            template_code=RESULTS_SET_TEMPLATE_CODE,
            name=f"results-set-{test_euid[:12]}-{int(now.timestamp())}",
            properties={
                "tenant_id": str(tenant_id),
                "published_at": None,
                "published_by": None,
                "note": None,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=test_instance,
            child=instance,
            relationship_type="results_set_test",
        )
        self.db.flush()
        return self._to_results_set(instance)

    def get_latest_draft_results_set_for_test(
        self,
        *,
        test_euid: str,
        tenant_id: uuid.UUID,
    ) -> TapdbResultsSetRecord | None:
        test_instance = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, test_euid)
        if test_instance is None:
            return None
        rows: list[TapdbResultsSetRecord] = []
        for instance in get_child_instances(self.db, test_instance, RESULTS_SET_TEMPLATE_CODE):
            record = self._to_results_set(instance)
            if record.tenant_id != tenant_id or record.test_euid != test_euid:
                continue
            if record.published_at is None:
                rows.append(record)
        rows.sort(key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC), reverse=True)
        return rows[0] if rows else None

    def get_results_set_by_euid(
        self,
        *,
        results_set_euid: str,
        tenant_id: uuid.UUID | None,
    ) -> TapdbResultsSetRecord | None:
        instance = get_instance_by_euid(self.db, RESULTS_SET_TEMPLATE_CODE, results_set_euid)
        if instance is None:
            return None
        record = self._to_results_set(instance)
        if tenant_id is not None and record.tenant_id != tenant_id:
            return None
        return record

    def publish_results_set(
        self,
        *,
        results_set_euid: str,
        tenant_id: uuid.UUID,
        published_by: uuid.UUID | None,
        note: str | None,
    ) -> TapdbResultsSetRecord | None:
        existing = self.get_results_set_by_euid(
            results_set_euid=results_set_euid, tenant_id=tenant_id
        )
        if existing is None:
            return None
        if existing.published_at is not None:
            return existing

        instance = self._resolve_results_set_instance(results_set_euid)
        if instance is None:
            return None
        props = self._instance_properties(instance)
        props["published_at"] = datetime.now(UTC).isoformat()
        props["published_by"] = str(published_by) if published_by else None
        if note is not None:
            props["note"] = note
        instance.json_addl = {"properties": props}
        self.db.flush()
        return self._to_results_set(instance)

    def list_results_sets_for_test(
        self,
        *,
        test_euid: str,
        tenant_id: uuid.UUID,
        include_unpublished: bool,
    ) -> list[TapdbResultsSetRecord]:
        rows: list[TapdbResultsSetRecord] = []
        test_instance = get_instance_by_euid(self.db, TEST_TEMPLATE_CODE, test_euid)
        if test_instance is None:
            return rows
        for instance in get_child_instances(self.db, test_instance, RESULTS_SET_TEMPLATE_CODE):
            record = self._to_results_set(instance)
            if record.tenant_id != tenant_id or record.test_euid != test_euid:
                continue
            if not include_unpublished and record.published_at is None:
                continue
            rows.append(record)
        rows.sort(key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC), reverse=True)
        return rows

    def list_results_sets_for_trf(
        self,
        *,
        trf_euid: str,
        tenant_id: uuid.UUID,
        include_unpublished: bool,
    ) -> list[TapdbResultsSetRecord]:
        trf_instance = get_instance_by_euid(self.db, TRF_TEMPLATE_CODE, trf_euid)
        if trf_instance is None:
            return []

        rows: list[TapdbResultsSetRecord] = []
        seen: set[str] = set()
        for test_instance in get_child_instances(self.db, trf_instance, TEST_TEMPLATE_CODE):
            for instance in get_child_instances(self.db, test_instance, RESULTS_SET_TEMPLATE_CODE):
                record = self._to_results_set(instance)
                if record.tenant_id != tenant_id:
                    continue
                if not include_unpublished and record.published_at is None:
                    continue
                if record.euid in seen:
                    continue
                seen.add(record.euid)
                rows.append(record)

        rows.sort(key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC), reverse=True)
        return rows

    def add_fulfillment_run_to_results_set(
        self,
        *,
        results_set_euid: str,
        fulfillment_run_euid: str,
    ) -> TapdbResultsSetAssayRecord:
        existing = self.get_results_set_assay(
            results_set_euid=results_set_euid, fulfillment_run_euid=fulfillment_run_euid
        )
        if existing is not None:
            return existing
        results_set_instance = self._resolve_results_set_instance(results_set_euid)
        run_instance = self._resolve_fulfillment_run_instance(fulfillment_run_euid)
        if results_set_instance is None or run_instance is None:
            raise ValueError("Results set or assay run not found")
        lineage = self.factory.link_instances(
            session=self.db,
            parent=results_set_instance,
            child=run_instance,
            relationship_type="results_set_assay",
        )
        self.db.flush()
        return self._to_results_set_assay(lineage)

    def get_results_set_assay(
        self,
        *,
        results_set_euid: str,
        fulfillment_run_euid: str,
    ) -> TapdbResultsSetAssayRecord | None:
        results_set_instance = self._resolve_results_set_instance(results_set_euid)
        if results_set_instance is None:
            return None
        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == results_set_instance.uid,
                generic_instance_lineage.relationship_type == "results_set_assay",
                generic_instance_lineage.is_deleted.is_(False),
            )
            .order_by(generic_instance_lineage.created_dt.asc())
        )
        for lineage in self.db.execute(stmt).scalars().all():
            child = getattr(lineage, "child_instance", None)
            if child is not None and child.euid == fulfillment_run_euid:
                return self._to_results_set_assay(lineage)
        return None

    def list_fulfillment_runs_for_results_set(
        self,
        *,
        results_set_euid: str,
        tenant_id: uuid.UUID,
    ) -> list[TapdbFulfillmentRunRecord]:
        results_set_instance = self._resolve_results_set_instance(results_set_euid)
        if results_set_instance is None:
            return []
        rows = [
            self._to_assay_run(child)
            for child in get_child_instances(
                self.db, results_set_instance, FULFILLMENT_RUN_TEMPLATE_CODE
            )
        ]
        return [row for row in rows if row.tenant_id == tenant_id]

    def list_results_set_fulfillment_runs(
        self,
        *,
        results_set_euid: str,
    ) -> list[TapdbResultsSetAssayRecord]:
        results_set_instance = self._resolve_results_set_instance(results_set_euid)
        if results_set_instance is None:
            return []
        stmt = (
            select(generic_instance_lineage)
            .where(
                generic_instance_lineage.parent_instance_uid == results_set_instance.uid,
                generic_instance_lineage.relationship_type == "results_set_assay",
                generic_instance_lineage.is_deleted.is_(False),
            )
            .order_by(generic_instance_lineage.created_dt.asc())
        )
        return [
            self._to_results_set_assay(lineage) for lineage in self.db.execute(stmt).scalars().all()
        ]

    def list_results_sets_for_fulfillment_run(
        self,
        *,
        fulfillment_run_euid: str,
        tenant_id: uuid.UUID,
    ) -> list[TapdbResultsSetRecord]:
        run_instance = self._resolve_fulfillment_run_instance(fulfillment_run_euid)
        if run_instance is None:
            return []
        rows: list[TapdbResultsSetRecord] = []
        for parent in get_parent_instances(self.db, run_instance, RESULTS_SET_TEMPLATE_CODE):
            record = self._to_results_set(parent)
            if record.tenant_id != tenant_id:
                continue
            rows.append(record)
        rows.sort(key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC), reverse=True)
        return rows

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            FULFILLMENT_RUN_TEMPLATE_CODE, "Atlas Fulfillment Run", ASSAY_RUN_PREFIX
        )
        self._ensure_template(
            FULFILLMENT_RUN_REV_TEMPLATE_CODE,
            "Atlas Fulfillment Run Revision",
            ASSAY_RUN_REV_PREFIX,
        )
        self._ensure_template(
            FULFILLMENT_OUTPUT_TEMPLATE_CODE, "Atlas Fulfillment Output", ASSAY_RESULT_PREFIX
        )
        self._ensure_template(RESULTS_SET_TEMPLATE_CODE, "Atlas Results Set", RESULTS_SET_PREFIX)
        self._ensure_template(
            FULFILLMENT_ARTIFACT_REF_TEMPLATE_CODE, "Atlas Artifact Link", ASSAY_ARTIFACT_REF_PREFIX
        )
        self._ensure_template(
            FULFILLMENT_OUTPUT_CONTEXT_REF_TEMPLATE_CODE,
            "Atlas Analysis Return Context",
            ASSAY_RESULT_CONTEXT_REF_PREFIX,
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(self, template_code: str, name: str, instance_prefix: str) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl={"managed_by": "lsmc-atlas", "domain": "assay"},
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != instance_prefix:
                existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _resolve_fulfillment_run_instance(
        self, fulfillment_run_euid: str
    ) -> generic_instance | None:
        return get_instance_by_euid(self.db, FULFILLMENT_RUN_TEMPLATE_CODE, fulfillment_run_euid)

    def _resolve_assay_result_instance(self, result_euid: str) -> generic_instance | None:
        return get_instance_by_euid(self.db, FULFILLMENT_OUTPUT_TEMPLATE_CODE, result_euid)

    def _resolve_results_set_instance(self, results_set_euid: str) -> generic_instance | None:
        return get_instance_by_euid(self.db, RESULTS_SET_TEMPLATE_CODE, results_set_euid)

    def _create_artifact_ref(
        self,
        *,
        parent: generic_instance,
        artifact_euid: str,
        created_by: uuid.UUID | None,
    ) -> None:
        now = datetime.now(UTC)
        ref = self.factory.create_instance(
            session=self.db,
            template_code=FULFILLMENT_ARTIFACT_REF_TEMPLATE_CODE,
            name=f"artifact:{artifact_euid}",
            properties={
                "artifact_euid": artifact_euid,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=parent,
            child=ref,
            relationship_type="artifact_reference",
        )

    def _create_analysis_context_ref(
        self,
        *,
        parent: generic_instance,
        analysis_context: dict[str, Any],
        created_by: uuid.UUID | None,
    ) -> None:
        now = datetime.now(UTC)
        ref = self.factory.create_instance(
            session=self.db,
            template_code=FULFILLMENT_OUTPUT_CONTEXT_REF_TEMPLATE_CODE,
            name=f"analysis:{analysis_context.get('analysis_euid') or parent.euid}",
            properties={
                "analysis_euid": str(analysis_context.get("analysis_euid") or "").strip(),
                "source_system": str(analysis_context.get("source_system") or "").strip(),
                "run_euid": str(analysis_context.get("run_euid") or "").strip(),
                "sequenced_library_assignment_euid": str(
                    analysis_context.get("sequenced_library_assignment_euid") or ""
                ).strip(),
                "flowcell_id": str(analysis_context.get("flowcell_id") or "").strip(),
                "lane": str(analysis_context.get("lane") or "").strip(),
                "library_barcode": str(analysis_context.get("library_barcode") or "").strip(),
                "atlas_trf_euid": str(analysis_context.get("atlas_trf_euid") or "").strip(),
                "atlas_test_euid": str(analysis_context.get("atlas_test_euid") or "").strip(),
                "atlas_test_fulfillment_item_euid": str(
                    analysis_context.get("atlas_test_fulfillment_item_euid") or ""
                ).strip(),
                "analysis_type": str(analysis_context.get("analysis_type") or "").strip(),
                "review_state": str(analysis_context.get("review_state") or "").strip(),
                "result_status": str(analysis_context.get("result_status") or "").strip(),
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
            },
        )
        self.factory.link_instances(
            session=self.db,
            parent=parent,
            child=ref,
            relationship_type="analysis_return_context",
        )

    def _artifact_euids_for_parent(self, parent: generic_instance) -> list[str]:
        rows = get_child_instances(self.db, parent, FULFILLMENT_ARTIFACT_REF_TEMPLATE_CODE)
        artifact_ids: list[str] = []
        for row in rows:
            props = self._instance_properties(row)
            artifact_euid = str(props.get("artifact_euid") or "").strip()
            if artifact_euid:
                artifact_ids.append(artifact_euid)
        return artifact_ids

    def _analysis_context_for_result(
        self, parent: generic_instance | None
    ) -> dict[str, Any] | None:
        if parent is None:
            return None
        rows = get_child_instances(self.db, parent, FULFILLMENT_OUTPUT_CONTEXT_REF_TEMPLATE_CODE)
        if not rows:
            return None
        return self._instance_properties(rows[0])

    def _parent_assay_run_for_revision(self, instance: generic_instance) -> generic_instance | None:
        parents = get_parent_instances(self.db, instance, FULFILLMENT_RUN_TEMPLATE_CODE)
        return parents[0] if parents else None

    def _parent_assay_run_for_result(self, instance: generic_instance) -> generic_instance | None:
        parents = get_parent_instances(self.db, instance, FULFILLMENT_RUN_TEMPLATE_CODE)
        return parents[0] if parents else None

    def _parent_trf_for_assay_run(self, instance: generic_instance) -> generic_instance | None:
        parents = get_parent_instances(self.db, instance, TRF_TEMPLATE_CODE)
        return parents[0] if parents else None

    def _parent_test_for_assay_run(self, instance: generic_instance) -> generic_instance | None:
        parents = get_parent_instances(self.db, instance, TEST_TEMPLATE_CODE)
        return parents[0] if parents else None

    def _parent_test_for_results_set(self, instance: generic_instance) -> generic_instance | None:
        parents = get_parent_instances(self.db, instance, TEST_TEMPLATE_CODE)
        return parents[0] if parents else None

    def _parent_result_for_amendment(self, instance: generic_instance) -> generic_instance | None:
        stmt = (
            select(generic_instance)
            .join(
                generic_instance_lineage,
                generic_instance.uid == generic_instance_lineage.parent_instance_uid,
            )
            .where(
                generic_instance_lineage.child_instance_uid == instance.uid,
                generic_instance_lineage.relationship_type == "amends_result",
                generic_instance_lineage.is_deleted.is_(False),
                generic_instance.is_deleted.is_(False),
            )
            .limit(1)
        )
        return self.db.execute(stmt).scalar_one_or_none()

    def _to_assay_run(self, instance: generic_instance) -> TapdbFulfillmentRunRecord:
        props = self._instance_properties(instance)
        trf = self._parent_trf_for_assay_run(instance)
        test = self._parent_test_for_assay_run(instance)
        return TapdbFulfillmentRunRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            order_id=trf.euid if trf is not None else "",
            test_order_id=test.euid if test is not None else "",
            fulfillment_route_code=str(props.get("fulfillment_route_code") or ""),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_assay_run_revision(
        self, instance: generic_instance
    ) -> TapdbFulfillmentRunRevisionRecord:
        props = self._instance_properties(instance)
        parent_run = self._parent_assay_run_for_revision(instance)
        return TapdbFulfillmentRunRevisionRecord(
            euid=instance.euid,
            fulfillment_run_euid=parent_run.euid if parent_run is not None else "",
            revision_no=int(props.get("revision_no") or 1),
            status=str(props.get("status") or "DRAFT"),
            accession_id=props.get("accession_id"),
            qc_hold_reason=props.get("qc_hold_reason"),
            qc_override=bool(props.get("qc_override", False)),
            note=props.get("note"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_assay_result(self, instance: generic_instance) -> TapdbFulfillmentOutputRecord:
        props = self._instance_properties(instance)
        run = self._parent_assay_run_for_result(instance)
        original = self._parent_result_for_amendment(instance)
        return TapdbFulfillmentOutputRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            fulfillment_run_euid=run.euid if run is not None else "",
            version_no=int(props.get("version_no") or 1),
            result_payload=props.get("result_payload")
            if isinstance(props.get("result_payload"), dict)
            else None,
            artifact_ids=self._artifact_euids_for_parent(instance) or None,
            amends_result_euid=original.euid if original is not None else None,
            amend_reason=props.get("amend_reason"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_results_set(self, instance: generic_instance) -> TapdbResultsSetRecord:
        props = self._instance_properties(instance)
        test = self._parent_test_for_results_set(instance)
        return TapdbResultsSetRecord(
            euid=instance.euid,
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            test_euid=test.euid if test is not None else "",
            published_at=_to_dt(props.get("published_at")),
            published_by=_parse_uuid(props.get("published_by")),
            note=props.get("note"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_parse_uuid(props.get("created_by")),
        )

    def _to_results_set_assay(
        self, lineage: generic_instance_lineage
    ) -> TapdbResultsSetAssayRecord:
        return TapdbResultsSetAssayRecord(
            euid=lineage.euid,
            results_set_euid=str(getattr(lineage.parent_instance, "euid", "") or ""),
            fulfillment_run_euid=str(getattr(lineage.child_instance, "euid", "") or ""),
            created_at=lineage.created_dt,
        )
