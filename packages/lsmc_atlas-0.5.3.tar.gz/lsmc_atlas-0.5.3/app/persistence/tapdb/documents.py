"""TapDB-backed repository adapter for Atlas documents domain."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.persistence.tapdb.euid_helpers import get_child_instances, get_instance_by_euid

DOCUMENT_TEMPLATE_CODE = "atlas/logistics/document/1.0/"
DOCUMENT_REV_TEMPLATE_CODE = "atlas/logistics/document-revision/1.0/"
LINK_EVENT_TEMPLATE_CODE = "atlas/events/link-event/1.0/"

DOCUMENT_PREFIX = "DCM"
DOCUMENT_REV_PREFIX = "DCR"
LINK_EVENT_PREFIX = "NKE"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _to_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbDocumentRecord:
    euid: str
    tenant_id: uuid.UUID
    created_at: datetime | None
    created_by: uuid.UUID | None
    restricted_to_user_id: uuid.UUID | None = None


@dataclass
class TapdbDocumentRevisionRecord:
    euid: str
    document_euid: str
    revision_no: int
    filename: str
    content_type: str | None
    size_bytes: int
    s3_bucket: str | None
    s3_key: str | None
    document_type: str | None
    created_at: datetime | None
    created_by: uuid.UUID | None
    note: str | None


@dataclass
class TapdbLinkEventRecord:
    euid: str
    tenant_id: uuid.UUID
    action: str
    source_type: str
    source_id: str
    target_type: str
    target_id: str
    created_at: datetime | None
    created_by: uuid.UUID | None


class TapdbDocumentRepository:
    """Document persistence backed by TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def create_document(
        self,
        tenant_id: uuid.UUID,
        data: Any,
        created_by: uuid.UUID | None,
        restricted_to_user_id: uuid.UUID | None = None,
    ) -> tuple[TapdbDocumentRecord, TapdbDocumentRevisionRecord]:
        self._ensure_templates()
        now = datetime.now(UTC)
        document_props: dict[str, Any] = {
            "tenant_id": str(tenant_id),
            "created_by": str(created_by) if created_by else None,
            "created_at": now.isoformat(),
        }
        if restricted_to_user_id is not None:
            document_props["restricted_to_user_id"] = str(restricted_to_user_id)

        document_instance = self.factory.create_instance(
            session=self.db,
            template_code=DOCUMENT_TEMPLATE_CODE,
            name=data.filename,
            properties=document_props,
        )
        self.db.flush()
        document_euid = document_instance.euid

        revision_instance = self.factory.create_instance(
            session=self.db,
            template_code=DOCUMENT_REV_TEMPLATE_CODE,
            name=f"{data.filename}-rev-1",
            properties={
                "document_euid": document_euid,
                "revision_no": 1,
                "filename": data.filename,
                "content_type": data.content_type,
                "size_bytes": int(data.size_bytes),
                "s3_bucket": data.s3_bucket,
                "s3_key": data.s3_key,
                "document_type": data.document_type,
                "created_by": str(created_by) if created_by else None,
                "created_at": now.isoformat(),
                "note": data.note,
            },
        )

        self.factory.link_instances(
            session=self.db,
            parent=document_instance,
            child=revision_instance,
            relationship_type="revision",
        )
        self.db.commit()

        return self._to_document(document_instance), self._to_revision(revision_instance)

    def get_document(
        self,
        document_euid: str,
        tenant_id: uuid.UUID,
        user_id: uuid.UUID | None = None,
        is_internal: bool = False,
    ) -> tuple[TapdbDocumentRecord, TapdbDocumentRevisionRecord] | None:
        document = self._get_document_by_euid(document_euid, tenant_id, is_internal=is_internal)
        if document is None:
            return None
        # Visibility check for external users
        if not is_internal and document.restricted_to_user_id is not None:
            if user_id is None or document.restricted_to_user_id != user_id:
                return None
        revision = self._get_latest_revision_for_instance(document_euid)
        if revision is None:
            return None
        return document, revision

    def list_documents(
        self,
        tenant_id: uuid.UUID,
        skip: int = 0,
        limit: int = 50,
        document_type: str | None = None,
        user_id: uuid.UUID | None = None,
        is_internal: bool = False,
    ) -> list[tuple[TapdbDocumentRecord, TapdbDocumentRevisionRecord]]:
        tenant_key = str(tenant_id)
        rows: list[tuple[TapdbDocumentRecord, TapdbDocumentRevisionRecord]] = []

        for instance in self._instances_for_template(DOCUMENT_TEMPLATE_CODE):
            document = self._to_document(instance)
            # Internal users see everything; external users see only their tenant
            if not is_internal and str(document.tenant_id) != tenant_key:
                continue
            # Visibility filter for external users
            if not is_internal and document.restricted_to_user_id is not None:
                if user_id is None or document.restricted_to_user_id != user_id:
                    continue
            revision = self._get_latest_revision_for_instance(document.euid)
            if revision is None:
                continue
            if document_type and revision.document_type != document_type:
                continue
            rows.append((document, revision))

        rows.sort(
            key=lambda row: row[0].created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return rows[skip : skip + limit]

    def add_link_event(
        self,
        tenant_id: uuid.UUID,
        action: str,
        source_type: str,
        source_id: str,
        target_type: str,
        target_id: str,
        created_by: uuid.UUID | None,
    ) -> TapdbLinkEventRecord:
        self._ensure_templates()
        now = datetime.now(UTC)
        link_props = {
            "tenant_id": str(tenant_id),
            "action": action,
            "source_type": source_type,
            "source_id": str(source_id),
            "target_type": target_type,
            "target_id": str(target_id),
            "created_by": str(created_by) if created_by else None,
            "created_at": now.isoformat(),
        }
        event_instance = self.factory.create_instance(
            session=self.db,
            template_code=LINK_EVENT_TEMPLATE_CODE,
            name=f"{source_type}:{source_id}->{target_type}:{target_id}",
            properties=link_props,
        )
        self.db.commit()
        return self._to_link_event(event_instance)

    def get_link_events_for_target(
        self,
        tenant_id: uuid.UUID,
        target_type: str,
        target_id: str,
        source_type: str | None = None,
    ) -> list[TapdbLinkEventRecord]:
        tenant_key = str(tenant_id)
        target_key = str(target_id)
        rows: list[TapdbLinkEventRecord] = []

        for instance in self._instances_for_template(LINK_EVENT_TEMPLATE_CODE):
            event = self._to_link_event(instance)
            if str(event.tenant_id) != tenant_key:
                continue
            if event.target_type != target_type:
                continue
            if event.target_id != target_key:
                continue
            if source_type and event.source_type != source_type:
                continue
            rows.append(event)

        rows.sort(key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC))
        return rows

    def get_link_events_for_source(
        self,
        tenant_id: uuid.UUID,
        source_type: str,
        source_id: str,
        target_type: str | None = None,
    ) -> list[TapdbLinkEventRecord]:
        tenant_key = str(tenant_id)
        source_key = str(source_id)
        rows: list[TapdbLinkEventRecord] = []

        for instance in self._instances_for_template(LINK_EVENT_TEMPLATE_CODE):
            event = self._to_link_event(instance)
            if str(event.tenant_id) != tenant_key:
                continue
            if event.source_type != source_type:
                continue
            if event.source_id != source_key:
                continue
            if target_type and event.target_type != target_type:
                continue
            rows.append(event)

        rows.sort(key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC))
        return rows

    def get_linked_documents(
        self,
        tenant_id: uuid.UUID,
        entity_type: str,
        entity_id: str,
    ) -> list[tuple[TapdbDocumentRecord, TapdbDocumentRevisionRecord]]:
        events = self.get_link_events_for_target(
            tenant_id=tenant_id,
            target_type=entity_type,
            target_id=entity_id,
            source_type="DOCUMENT",
        )
        active_doc_euids: set[str] = set()
        for event in events:
            if event.action == "LINK":
                active_doc_euids.add(event.source_id)
            elif event.action == "UNLINK":
                active_doc_euids.discard(event.source_id)

        rows: list[tuple[TapdbDocumentRecord, TapdbDocumentRevisionRecord]] = []
        for doc_euid in active_doc_euids:
            result = self.get_document(document_euid=doc_euid, tenant_id=tenant_id)
            if result is not None:
                rows.append(result)
        return rows

    def _get_latest_revision_for_instance(
        self, document_euid: str
    ) -> TapdbDocumentRevisionRecord | None:
        """Get the latest revision for a document using lineage or property match."""
        instance = get_instance_by_euid(self.db, DOCUMENT_TEMPLATE_CODE, document_euid)
        if instance is None:
            return None
        children = get_child_instances(self.db, instance, DOCUMENT_REV_TEMPLATE_CODE)
        if not children:
            return None
        # Children are ordered by created_dt desc; pick highest revision_no
        revisions = [self._to_revision(c) for c in children]
        revisions.sort(key=lambda rev: rev.revision_no, reverse=True)
        return revisions[0]

    def _get_document_by_euid(
        self,
        document_euid: str,
        tenant_id: uuid.UUID,
        is_internal: bool = False,
    ) -> TapdbDocumentRecord | None:
        instance = get_instance_by_euid(self.db, DOCUMENT_TEMPLATE_CODE, document_euid)
        if instance is None or instance.is_deleted:
            return None
        document = self._to_document(instance)
        # Internal users can access any tenant's documents
        if not is_internal and str(document.tenant_id) != str(tenant_id):
            return None
        return document

    def _ensure_templates(self) -> None:
        if self._templates_ready:
            return
        self._ensure_template(
            DOCUMENT_TEMPLATE_CODE,
            DOCUMENT_PREFIX,
            "Atlas Document",
            {"managed_by": "lsmc-atlas", "domain": "documents"},
        )
        self._ensure_template(
            DOCUMENT_REV_TEMPLATE_CODE,
            DOCUMENT_REV_PREFIX,
            "Atlas Document Revision",
            {"managed_by": "lsmc-atlas", "domain": "documents"},
        )
        self._ensure_template(
            LINK_EVENT_TEMPLATE_CODE,
            LINK_EVENT_PREFIX,
            "Atlas Link Event",
            {"managed_by": "lsmc-atlas", "domain": "events"},
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        instance_prefix: str,
        name: str,
        json_addl: dict[str, Any],
    ) -> None:
        self._ensure_prefix_sequence(instance_prefix)
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name=name,
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=instance_prefix,
                    instance_polymorphic_identity="actor_instance",
                    json_addl=json_addl,
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != instance_prefix:
                existing.instance_prefix = instance_prefix

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _instances_for_template(self, template_code: str) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(template_code)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _instance_properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _matches_template(self, instance: generic_instance, template_code: str) -> bool:
        category, type_, subtype, version = _parse_template_code(template_code)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _to_document(self, instance: generic_instance) -> TapdbDocumentRecord:
        props = self._instance_properties(instance)
        return TapdbDocumentRecord(
            euid=instance.euid,
            tenant_id=_to_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_to_uuid(props.get("created_by")),
            restricted_to_user_id=_to_uuid(props.get("restricted_to_user_id")),
        )

    def _to_revision(self, instance: generic_instance) -> TapdbDocumentRevisionRecord:
        props = self._instance_properties(instance)
        return TapdbDocumentRevisionRecord(
            euid=instance.euid,
            document_euid=str(props.get("document_euid") or ""),
            revision_no=int(props.get("revision_no") or 1),
            filename=str(props.get("filename") or ""),
            content_type=props.get("content_type"),
            size_bytes=int(props.get("size_bytes") or 0),
            s3_bucket=props.get("s3_bucket"),
            s3_key=props.get("s3_key"),
            document_type=props.get("document_type"),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_to_uuid(props.get("created_by")),
            note=props.get("note"),
        )

    def _to_link_event(self, instance: generic_instance) -> TapdbLinkEventRecord:
        props = self._instance_properties(instance)
        return TapdbLinkEventRecord(
            euid=instance.euid,
            tenant_id=_to_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            action=str(props.get("action") or "LINK"),
            source_type=str(props.get("source_type") or ""),
            source_id=str(props.get("source_id") or ""),
            target_type=str(props.get("target_type") or ""),
            target_id=str(props.get("target_id") or ""),
            created_at=_to_dt(props.get("created_at")) or instance.created_dt,
            created_by=_to_uuid(props.get("created_by")),
        )
