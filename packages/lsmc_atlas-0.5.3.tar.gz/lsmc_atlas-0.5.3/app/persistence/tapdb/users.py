"""TapDB-backed repository adapter for Atlas user profiles."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

from app.persistence.tapdb.euid_helpers import get_instance_by_euid

USER_TEMPLATE_CODE = "atlas/core/user-profile/1.0/"
USER_PREFIX = "PRF"


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


def _parse_uuid(value: Any) -> uuid.UUID | None:
    if value is None:
        return None
    if isinstance(value, uuid.UUID):
        return value
    try:
        return uuid.UUID(str(value))
    except (ValueError, AttributeError):
        return None


def _to_dt(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    if isinstance(value, str):
        candidate = value.strip()
        if not candidate:
            return None
        if candidate.endswith("Z"):
            candidate = candidate[:-1] + "+00:00"
        try:
            return datetime.fromisoformat(candidate)
        except ValueError:
            return None
    return None


@dataclass
class TapdbUserProfileRecord:
    euid: str
    cognito_sub: str
    tenant_id: uuid.UUID
    email: str
    name: str | None
    roles: list[str]
    is_active: bool
    preferences: dict | None
    created_at: datetime | None
    last_login_at: datetime | None


class TapdbUserRepository:
    """User profile persistence with TapDB templates/instances."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._template_ready = False

    def create_user(self, data: Any) -> TapdbUserProfileRecord:
        self._ensure_template()
        props = {
            "cognito_sub": data.cognito_sub,
            "tenant_id": str(data.tenant_id),
            "email": data.email,
            "name": data.name,
            "roles": data.roles or [],
            "is_active": True,
            "preferences": None,
            "last_login_at": None,
        }
        instance = self.factory.create_instance(
            session=self.db,
            template_code=USER_TEMPLATE_CODE,
            name=data.email,
            properties=props,
        )
        self.db.commit()
        return self._to_record(instance)

    def get_user_by_id(self, user_id: str) -> TapdbUserProfileRecord | None:
        instance = get_instance_by_euid(self.db, USER_TEMPLATE_CODE, user_id)
        if instance is None or instance.is_deleted or not self._matches_template(instance):
            return None
        return self._to_record(instance)

    def get_user_by_sub(self, cognito_sub: str) -> TapdbUserProfileRecord | None:
        for instance in self._list_instances():
            props = self._properties(instance)
            if str(props.get("cognito_sub", "")).strip() == str(cognito_sub).strip():
                return self._to_record(instance)
        return None

    def get_user_by_email_in_tenant(
        self,
        email: str,
        tenant_id: uuid.UUID,
    ) -> TapdbUserProfileRecord | None:
        email_key = str(email).strip().lower()
        tenant_key = str(tenant_id)
        for instance in self._list_instances():
            props = self._properties(instance)
            if str(props.get("tenant_id")) != tenant_key:
                continue
            if str(props.get("email", "")).strip().lower() == email_key:
                return self._to_record(instance)
        return None

    def get_user_by_email(self, email: str) -> TapdbUserProfileRecord | None:
        email_key = str(email).strip().lower()
        for instance in self._list_instances():
            props = self._properties(instance)
            if str(props.get("email", "")).strip().lower() == email_key:
                return self._to_record(instance)
        return None

    def list_users_by_subs(self, cognito_subs: list[str]) -> list[TapdbUserProfileRecord]:
        if not cognito_subs:
            return []
        target_subs = {str(sub).strip() for sub in cognito_subs if str(sub).strip()}
        records: list[TapdbUserProfileRecord] = []
        for instance in self._list_instances():
            props = self._properties(instance)
            if str(props.get("cognito_sub", "")).strip() in target_subs:
                records.append(self._to_record(instance))
        return records

    def list_users(
        self,
        tenant_id: uuid.UUID | None = None,
        skip: int = 0,
        limit: int = 50,
        is_active: bool | None = None,
    ) -> list[TapdbUserProfileRecord]:
        records = []
        tenant_key = str(tenant_id) if tenant_id else None
        for instance in self._list_instances():
            record = self._to_record(instance)
            if tenant_key and str(record.tenant_id) != tenant_key:
                continue
            if is_active is not None and record.is_active != is_active:
                continue
            records.append(record)
        records.sort(
            key=lambda row: row.created_at or datetime.min.replace(tzinfo=UTC),
            reverse=True,
        )
        return records[skip : skip + limit]

    def update_user(self, user_id: str, data: Any) -> TapdbUserProfileRecord | None:
        instance = get_instance_by_euid(self.db, USER_TEMPLATE_CODE, user_id)
        if instance is None or instance.is_deleted or not self._matches_template(instance):
            return None
        props = self._properties(instance)
        if data.email is not None:
            props["email"] = data.email
        if data.name is not None:
            props["name"] = data.name
        if data.roles is not None:
            props["roles"] = data.roles
        if data.is_active is not None:
            props["is_active"] = bool(data.is_active)
        self._write_properties(instance, props)
        self.db.commit()
        return self._to_record(instance)

    def set_last_login(self, user_id: str, last_login_at: datetime) -> None:
        instance = get_instance_by_euid(self.db, USER_TEMPLATE_CODE, user_id)
        if instance is None or instance.is_deleted or not self._matches_template(instance):
            return
        props = self._properties(instance)
        props["last_login_at"] = last_login_at.isoformat()
        self._write_properties(instance, props)
        self.db.commit()

    def update_preferences(
        self, user_id: str, preferences: dict[str, Any]
    ) -> TapdbUserProfileRecord | None:
        instance = get_instance_by_euid(self.db, USER_TEMPLATE_CODE, user_id)
        if instance is None or instance.is_deleted or not self._matches_template(instance):
            return None
        props = self._properties(instance)
        props["preferences"] = dict(preferences)
        self._write_properties(instance, props)
        self.db.commit()
        return self._to_record(instance)

    def _ensure_template(self) -> None:
        if self._template_ready:
            return
        self._ensure_prefix_sequence(USER_PREFIX)
        category, type_, subtype, version = _parse_template_code(USER_TEMPLATE_CODE)
        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is None:
            self.db.add(
                generic_template(
                    name="Atlas User Profile",
                    polymorphic_discriminator="actor_template",
                    category=category,
                    type=type_,
                    subtype=subtype,
                    version=version,
                    instance_prefix=USER_PREFIX,
                    instance_polymorphic_identity="actor_instance",
                    json_addl={"managed_by": "lsmc-atlas", "domain": "users"},
                    bstatus="active",
                    is_singleton=False,
                    is_deleted=False,
                )
            )
        else:
            if existing.is_deleted:
                existing.is_deleted = False
            if existing.instance_prefix != USER_PREFIX:
                existing.instance_prefix = USER_PREFIX
        self._template_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _matches_template(self, instance: generic_instance) -> bool:
        category, type_, subtype, version = _parse_template_code(USER_TEMPLATE_CODE)
        return (
            instance.category == category
            and instance.type == type_
            and instance.subtype == subtype
            and instance.version == version
        )

    def _list_instances(self) -> list[generic_instance]:
        category, type_, subtype, version = _parse_template_code(USER_TEMPLATE_CODE)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        return list(self.db.execute(stmt).scalars().all())

    def _properties(self, instance: generic_instance) -> dict[str, Any]:
        raw = instance.json_addl or {}
        props = raw.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _write_properties(self, instance: generic_instance, props: dict[str, Any]) -> None:
        raw = dict(instance.json_addl or {})
        raw["properties"] = props
        instance.json_addl = raw
        flag_modified(instance, "json_addl")

    def _to_record(self, instance: generic_instance) -> TapdbUserProfileRecord:
        props = self._properties(instance)
        return TapdbUserProfileRecord(
            euid=instance.euid,
            cognito_sub=str(props.get("cognito_sub") or ""),
            tenant_id=_parse_uuid(props.get("tenant_id")) or uuid.UUID(int=0),
            email=str(props.get("email") or instance.name),
            name=props.get("name"),
            roles=list(props.get("roles") or []),
            is_active=bool(props.get("is_active", True)),
            preferences=props.get("preferences"),
            created_at=instance.created_dt or datetime.now(UTC),
            last_login_at=_to_dt(props.get("last_login_at")),
        )
