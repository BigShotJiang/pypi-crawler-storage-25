"""TapDB-backed repository adapter for Atlas tenant theme settings."""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from typing import Any

from daylily_tapdb.factory import InstanceFactory
from daylily_tapdb.models.instance import generic_instance
from daylily_tapdb.models.lineage import generic_instance_lineage
from daylily_tapdb.models.template import generic_template
from daylily_tapdb.sequences import ensure_instance_prefix_sequence
from daylily_tapdb.templates import TemplateManager
from sqlalchemy import select
from sqlalchemy.orm import Session
from sqlalchemy.orm.attributes import flag_modified

SKIN_CONFIG_TEMPLATE_CODE = "atlas/theme/skin-configuration/1.0/"
SKIN_REVISION_TEMPLATE_CODE = "atlas/theme/skin-configuration-revision/1.0/"

SKIN_CONFIG_PREFIX = "THM"
SKIN_REVISION_PREFIX = "THR"

DEFAULT_FONT_CHOICE = "kanit"

FONT_CHOICES: tuple[dict[str, str], ...] = (
    {
        "code": "kanit",
        "name": "Kanit",
        "description": "Default UI font with Cormorant Garamond reserved for prominent titles.",
        "body_family": '"Kanit", "Segoe UI", system-ui, sans-serif',
        "heading_family": '"Cormorant Garamond", Georgia, serif',
        "body_preview": "Direct, compact UI text for everyday navigation.",
        "heading_preview": "Important Titles",
    },
    {
        "code": "nunito-sans",
        "name": "Nunito Sans",
        "description": "Rounded UI text paired with Frank Ruhl Libre for prominent titles.",
        "body_family": '"Nunito Sans", "Segoe UI", system-ui, sans-serif',
        "heading_family": '"Frank Ruhl Libre", Georgia, serif',
        "body_preview": "Softer, more relaxed copy for the main interface.",
        "heading_preview": "Important Titles",
    },
)

FONT_CHOICE_MAP = {item["code"]: item for item in FONT_CHOICES}


def _parse_template_code(template_code: str) -> tuple[str, str, str, str]:
    parts = template_code.strip("/").split("/")
    if len(parts) != 4:
        raise ValueError(f"Invalid template code: {template_code}")
    return parts[0], parts[1], parts[2], parts[3]


@dataclass(frozen=True)
class TapdbThemeState:
    """Resolved tenant theme values used by API/web routes."""

    theme: str
    custom_css: str | None
    font_choice: str
    font_config: dict[str, str]


def resolve_font_choice(font_choice: str | None) -> dict[str, str]:
    """Resolve a persisted font code to a supported font configuration."""
    candidate = str(font_choice or "").strip().lower()
    config = FONT_CHOICE_MAP.get(candidate)
    if config is None:
        config = FONT_CHOICE_MAP[DEFAULT_FONT_CHOICE]
    return dict(config)


class TapdbThemeRepository:
    """Theme persistence using TapDB instances + revision lineages."""

    def __init__(self, db: Session):
        self.db = db
        self.templates = TemplateManager()
        self.factory = InstanceFactory(self.templates)
        self._templates_ready = False

    def get_current_theme(self, tenant_id: uuid.UUID | None) -> TapdbThemeState:
        if tenant_id is None:
            config = resolve_font_choice(DEFAULT_FONT_CHOICE)
            return TapdbThemeState(
                theme="default",
                custom_css=None,
                font_choice=config["code"],
                font_config=config,
            )

        config = self._find_latest_skin_config(tenant_id)
        if config is None:
            font_config = resolve_font_choice(DEFAULT_FONT_CHOICE)
            return TapdbThemeState(
                theme="default",
                custom_css=None,
                font_choice=font_config["code"],
                font_config=font_config,
            )

        revision = self._find_latest_skin_revision(config.uid)
        if revision is None:
            font_config = resolve_font_choice(DEFAULT_FONT_CHOICE)
            return TapdbThemeState(
                theme="default",
                custom_css=None,
                font_choice=font_config["code"],
                font_config=font_config,
            )

        props = self._properties(revision)
        raw_font_config = props.get("font_config")
        font_choice = None
        if isinstance(raw_font_config, dict):
            font_choice = raw_font_config.get("code")
        resolved_font_config = resolve_font_choice(font_choice)
        return TapdbThemeState(
            theme=str(props.get("base_theme") or "default"),
            custom_css=props.get("custom_css"),
            font_choice=resolved_font_config["code"],
            font_config=resolved_font_config,
        )

    def select_theme(
        self,
        tenant_id: uuid.UUID,
        theme: str | None,
        created_by: uuid.UUID | None,
        font_choice: str | None = None,
    ) -> TapdbThemeState:
        self._ensure_templates_bootstrapped()

        config = self._find_latest_skin_config(tenant_id)
        if config is None:
            config = self.factory.create_instance(
                session=self.db,
                template_code=SKIN_CONFIG_TEMPLATE_CODE,
                name=f"tenant-{tenant_id}-theme",
                properties={
                    "tenant_id": str(tenant_id),
                    "skin_code": f"tenant-{tenant_id}-theme",
                    "created_by": str(created_by) if created_by else None,
                },
            )

        latest_revision = self._find_latest_skin_revision(config.uid)
        next_revision_no = 1
        latest_props: dict[str, Any] = {}
        if latest_revision is not None:
            latest_props = self._properties(latest_revision)
            next_revision_no = int(latest_props.get("revision_no") or 0) + 1

        current_state = self.get_current_theme(tenant_id)
        resolved_theme = str(theme or current_state.theme or "default")
        resolved_font_config = resolve_font_choice(font_choice or current_state.font_choice)
        revision_properties = dict(latest_props)
        revision_properties.update(
            {
                "revision_no": next_revision_no,
                "name": f"{resolved_theme} theme",
                "base_theme": resolved_theme,
                "custom_css": revision_properties.get("custom_css"),
                "css_variables": revision_properties.get("css_variables"),
                "font_config": resolved_font_config,
                "component_styles": revision_properties.get("component_styles"),
                "is_active": True,
                "created_by": str(created_by) if created_by else None,
                "note": revision_properties.get("note"),
            }
        )

        revision = self.factory.create_instance(
            session=self.db,
            template_code=SKIN_REVISION_TEMPLATE_CODE,
            name=f"{resolved_theme} theme",
            properties=revision_properties,
        )
        self.factory.link_instances(
            session=self.db,
            parent=config,
            child=revision,
            relationship_type="revision",
        )
        self.db.commit()
        return TapdbThemeState(
            theme=resolved_theme,
            custom_css=revision_properties.get("custom_css"),
            font_choice=resolved_font_config["code"],
            font_config=resolved_font_config,
        )

    def _ensure_templates_bootstrapped(self) -> None:
        if self._templates_ready:
            return

        self._ensure_template(
            template_code=SKIN_CONFIG_TEMPLATE_CODE,
            template_name="Atlas Skin Configuration",
            instance_prefix=SKIN_CONFIG_PREFIX,
            template_polymorphic_discriminator="generic_template",
            instance_polymorphic_identity="generic_instance",
        )
        self._ensure_template(
            template_code=SKIN_REVISION_TEMPLATE_CODE,
            template_name="Atlas Skin Configuration Revision",
            instance_prefix=SKIN_REVISION_PREFIX,
            template_polymorphic_discriminator="generic_template",
            instance_polymorphic_identity="generic_instance",
        )
        self._templates_ready = True
        self.db.flush()
        self.templates.clear_cache()

    def _ensure_template(
        self,
        template_code: str,
        template_name: str,
        instance_prefix: str,
        template_polymorphic_discriminator: str,
        instance_polymorphic_identity: str,
    ) -> generic_template:
        category, type_, subtype, version = _parse_template_code(template_code)
        self._ensure_prefix_sequence(instance_prefix)

        stmt = (
            select(generic_template)
            .where(
                generic_template.category == category,
                generic_template.type == type_,
                generic_template.subtype == subtype,
                generic_template.version == version,
            )
            .limit(1)
        )
        existing = self.db.execute(stmt).scalar_one_or_none()
        if existing is not None:
            if existing.is_deleted:
                existing.is_deleted = False
            return existing

        created = generic_template(
            name=template_name,
            polymorphic_discriminator=template_polymorphic_discriminator,
            category=category,
            type=type_,
            subtype=subtype,
            version=version,
            instance_prefix=instance_prefix,
            instance_polymorphic_identity=instance_polymorphic_identity,
            json_addl={"managed_by": "lsmc-atlas", "domain": "themes"},
            bstatus="active",
            is_singleton=False,
            is_deleted=False,
        )
        self.db.add(created)
        self.db.flush()
        return created

    def _ensure_prefix_sequence(self, prefix: str) -> None:
        ensure_instance_prefix_sequence(self.db, prefix)

    def _find_latest_skin_config(self, tenant_id: uuid.UUID) -> generic_instance | None:
        category, type_, subtype, version = _parse_template_code(SKIN_CONFIG_TEMPLATE_CODE)
        stmt = (
            select(generic_instance)
            .where(
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        tenant_key = str(tenant_id)
        for instance in self.db.execute(stmt).scalars().all():
            if str(self._properties(instance).get("tenant_id")) == tenant_key:
                return instance
        return None

    def _find_latest_skin_revision(self, config_uid: int) -> generic_instance | None:
        category, type_, subtype, version = _parse_template_code(SKIN_REVISION_TEMPLATE_CODE)
        stmt = (
            select(generic_instance)
            .join(
                generic_instance_lineage,
                generic_instance_lineage.child_instance_uid == generic_instance.uid,
            )
            .where(
                generic_instance_lineage.parent_instance_uid == config_uid,
                generic_instance_lineage.relationship_type == "revision",
                generic_instance.category == category,
                generic_instance.type == type_,
                generic_instance.subtype == subtype,
                generic_instance.version == version,
                generic_instance.is_deleted.is_(False),
            )
            .order_by(generic_instance.created_dt.desc())
        )
        revisions = list(self.db.execute(stmt).scalars().all())
        if not revisions:
            return None
        revisions.sort(
            key=lambda rev: int(self._properties(rev).get("revision_no") or 0),
            reverse=True,
        )
        return revisions[0]

    def _properties(self, instance: generic_instance) -> dict[str, Any]:
        json_addl = instance.json_addl or {}
        props = json_addl.get("properties")
        if isinstance(props, dict):
            return dict(props)
        return {}

    def _write_properties(self, instance: generic_instance, properties: dict[str, Any]) -> None:
        json_addl = dict(instance.json_addl or {})
        json_addl["properties"] = properties
        instance.json_addl = json_addl
        flag_modified(instance, "json_addl")
