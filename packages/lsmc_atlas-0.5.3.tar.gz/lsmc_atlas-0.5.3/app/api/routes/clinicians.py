"""LSMC Hub - Clinician API Routes.

External API for managing clinicians with tenant scoping.
"""

import logging
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from app.auth.dependencies import CurrentUser, get_current_user
from app.db.engine import get_db
from app.domain.services.people import ClinicianCreate, ClinicianService
from app.domain.services.users import UserCreate, UserService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/clinicians", tags=["clinicians"])


# --- Request/Response Schemas ---


class ClinicianCreateRequest(BaseModel):
    """Request to create a clinician."""

    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    credentials: str | None = Field(None, max_length=50)
    npi: str | None = Field(None, max_length=20)
    email: str | None = Field(None, max_length=255)
    phone: str | None = Field(None, max_length=50)
    specialty: str | None = Field(None, max_length=100)
    site_id: str | None = None


class ClinicianUpdateRequest(BaseModel):
    """Request to update a clinician."""

    first_name: str | None = Field(None, min_length=1, max_length=100)
    last_name: str | None = Field(None, min_length=1, max_length=100)
    credentials: str | None = Field(None, max_length=50)
    npi: str | None = Field(None, max_length=20)
    email: str | None = Field(None, max_length=255)
    phone: str | None = Field(None, max_length=50)
    specialty: str | None = Field(None, max_length=100)
    site_id: str | None = None


class ClinicianResponse(BaseModel):
    """Clinician response."""

    id: str
    euid: str | None = None
    tenant_id: str
    first_name: str
    last_name: str
    credentials: str | None
    npi: str | None
    email: str | None
    phone: str | None
    specialty: str | None
    site_id: str | None
    revision_no: int
    created_at: str


class ClinicianListResponse(BaseModel):
    """List of clinicians."""

    items: list[ClinicianResponse]
    total: int


class ClinicianUserCreateRequest(BaseModel):
    """Request to invite a user associated with a clinician.

    Atlas creates the Cognito account automatically via AdminCreateUser.
    """

    email: str = Field(..., min_length=1, max_length=255)
    name: str | None = Field(None, max_length=255)
    roles: list[str] = Field(default=["EXTERNAL_USER"])


class ClinicianUserResponse(BaseModel):
    """User response."""

    id: str
    email: str
    name: str | None
    tenant_id: str
    roles: list[str]
    is_active: bool
    created_at: str


def _clinician_to_response(clinician, revision) -> ClinicianResponse:
    """Convert clinician + revision to response."""
    return ClinicianResponse(
        id=clinician.euid,
        euid=clinician.euid,
        tenant_id=str(clinician.tenant_id),
        first_name=revision.first_name,
        last_name=revision.last_name,
        credentials=revision.credentials,
        npi=revision.npi,
        email=revision.email,
        phone=revision.phone,
        specialty=revision.specialty,
        site_id=str(revision.site_id) if revision.site_id else None,
        revision_no=revision.revision_no,
        created_at=clinician.created_at.isoformat(),
    )


# --- Endpoints ---


@router.get("", response_model=ClinicianListResponse)
async def list_clinicians(
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
    skip: int = 0,
    limit: int = Query(default=50, le=200),
    search: str | None = None,
) -> ClinicianListResponse:
    """List clinicians for tenant."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub)

    if search:
        clinicians = svc.search_by_name(search, limit=limit, cross_tenant=cross_tenant)
    else:
        clinicians = svc.list_clinicians(skip=skip, limit=limit, cross_tenant=cross_tenant)

    items = [_clinician_to_response(c, r) for c, r in clinicians]
    return ClinicianListResponse(items=items, total=len(items))


@router.get("/{clinician_id}", response_model=ClinicianResponse)
async def get_clinician(
    clinician_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ClinicianResponse:
    """Get clinician by ID (EUID)."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub)
    result = svc.get(clinician_id, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Clinician not found")

    clinician, revision = result
    return _clinician_to_response(clinician, revision)


@router.post("", response_model=ClinicianResponse, status_code=status.HTTP_201_CREATED)
async def create_clinician(
    request: ClinicianCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ClinicianResponse:
    """Create a new clinician."""
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub)
    clinician, revision = svc.create(
        ClinicianCreate(
            first_name=request.first_name,
            last_name=request.last_name,
            credentials=request.credentials,
            npi=request.npi,
            email=request.email,
            phone=request.phone,
            specialty=request.specialty,
            site_id=request.site_id,
        )
    )
    return _clinician_to_response(clinician, revision)


@router.patch("/{clinician_id}", response_model=ClinicianResponse)
async def update_clinician(
    clinician_id: str,
    request: ClinicianUpdateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ClinicianResponse:
    """Update clinician (creates new revision)."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub)

    updates = {k: v for k, v in request.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="No fields to update")

    result = svc.update(clinician_id, updates, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Clinician not found")

    clinician, revision = result
    return _clinician_to_response(clinician, revision)


@router.get("/by-npi/{npi}", response_model=ClinicianResponse)
async def get_clinician_by_npi(
    npi: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ClinicianResponse:
    """Get clinician by NPI."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub)
    result = svc.get_by_npi(npi, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Clinician not found")

    clinician, revision = result
    return _clinician_to_response(clinician, revision)


@router.post(
    "/{clinician_id}/users",
    response_model=ClinicianUserResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_clinician_user(
    clinician_id: str,
    request: ClinicianUserCreateRequest,
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Session = Depends(get_db),
) -> ClinicianUserResponse:
    """Create a user associated with a clinician.

    The user will be created in the same tenant as the clinician.
    External users can only create users within their own organization.
    """
    # First, verify the clinician exists and user has access
    clinician_svc = ClinicianService(db, current_user.tenant_id, current_user.sub)
    result = clinician_svc.get(clinician_id)

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Clinician not found")

    clinician, _ = result

    # Verify user is creating in their own tenant (unless internal/admin)
    if not current_user.is_internal and current_user.tenant_id != clinician.tenant_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied")

    # Validate roles - external users can only create EXTERNAL_USER or READ_ONLY roles
    allowed_roles = {"EXTERNAL_USER", "READ_ONLY", "READ_WRITE"}
    if not current_user.is_internal:
        for role in request.roles:
            if role not in allowed_roles:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Cannot assign role: {role}. Only {allowed_roles} allowed.",
                )

    try:
        user_svc = UserService(db, current_user.sub_uuid)
        user = user_svc.invite(
            UserCreate(
                email=request.email,
                name=request.name,
                tenant_id=clinician.tenant_id,
                roles=request.roles,
            )
        )

        return ClinicianUserResponse(
            id=str(user.euid),
            email=user.email,
            name=user.name,
            tenant_id=str(user.tenant_id),
            roles=user.roles,
            is_active=user.is_active,
            created_at=user.created_at.isoformat(),
        )
    except ValueError as e:
        logger.warning("Clinician provisioning error: %s", e)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid request. Please check the provided data.",
        )
