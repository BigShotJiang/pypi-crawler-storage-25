"""LSMC Hub - Web Routes.

Server-rendered pages using Jinja2 templates.
"""

from app.web.routes.accessioning import router as accessioning_router
from app.web.routes.admin_groups import router as admin_groups_router
from app.web.routes.api_clients import router as api_clients_router
from app.web.routes.families import router as families_router
from app.web.routes.graph import router as graph_router
from app.web.routes.pages import router
from app.web.routes.search import router as search_router
from app.web.routes.webhooks import router as webhooks_router

# Include sub-routers
router.include_router(webhooks_router)
router.include_router(api_clients_router)
router.include_router(admin_groups_router)
router.include_router(accessioning_router)
router.include_router(families_router)
router.include_router(search_router)
router.include_router(graph_router)

__all__ = ["router"]
