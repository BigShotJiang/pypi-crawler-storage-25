"""LSMC Hub - Web Page Routes.

Server-rendered pages using Jinja2 templates.
"""

import logging
import uuid
from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.auth.dependencies import (
    CurrentUser,
    _get_current_user_from_session,
    get_current_user_web,
    require_internal,
    require_org_admin,
    require_read_write_web,
)
from app.auth.middleware import csrf_protect, get_csrf_token
from app.auth.rbac import EXTERNAL_ASSIGNABLE_ROLES, ORG_ADMIN_ASSIGNABLE_ROLES
from app.db.engine import get_db
from app.domain.services.people import PatientCreate, PatientService, PatientUpdate
from app.settings import settings
from app.util.security import safe_redirect_url, sanitize_path_segment
from app.web.flash import flash, get_flashed_messages
from app.web.templates import templates

try:
    from daylily_tapdb.timezone_utils import DEFAULT_DISPLAY_TIMEZONE
except Exception:
    DEFAULT_DISPLAY_TIMEZONE = "UTC"

try:
    from daylily_tapdb.user_store import get_display_timezone_by_login_or_email
except Exception:

    def get_display_timezone_by_login_or_email(*_args, **_kwargs) -> str:
        return DEFAULT_DISPLAY_TIMEZONE


logger = logging.getLogger(__name__)


def _safe_redirect_url(url: str, default: str = "/trfs/new") -> str:
    """Validate redirect URL to prevent open redirects.

    Delegates to the shared ``safe_redirect_url`` utility, overriding
    the default fallback to ``/trfs/new`` for TRF pages.
    """
    return safe_redirect_url(url, default=default)


def _seg(value: str | object) -> str:
    """Shorthand: URL-encode a user-controlled path segment."""
    return sanitize_path_segment(str(value))


def _is_missing_relation_error(exc: SQLAlchemyError) -> bool:
    """Detect missing-table errors from partially migrated runtimes."""
    message = str(getattr(exc, "orig", exc)).lower()
    return "undefinedtable" in message or ('relation "' in message and "does not exist" in message)


def _rollback_quietly(db: Session) -> None:
    """Rollback safely after recoverable DB errors."""
    try:
        db.rollback()
    except Exception:  # pragma: no cover - defensive
        pass


def _raise_deprecated_gui_route(*, route_path: str, replacement_path: str | None = None) -> None:
    """Raise a consistent deprecation response for removed GUI routes."""
    detail = f"{route_path} GUI route is deprecated and no longer available."
    if replacement_path:
        detail = f"{detail} Use {replacement_path} instead."
    raise HTTPException(
        status_code=status.HTTP_410_GONE,
        detail=detail,
        headers={
            "X-Atlas-Deprecated": "true",
            "X-Atlas-Deprecated-Route": route_path,
            "X-Atlas-Replacement": replacement_path or "",
        },
    )


router = APIRouter(tags=["pages"])


def get_template_context(
    request: Request, user: CurrentUser | None = None, db: Session | None = None
) -> dict:
    """Build common template context."""
    from app.persistence.tapdb.themes import DEFAULT_FONT_CHOICE, resolve_font_choice

    default_font_config = resolve_font_choice(DEFAULT_FONT_CHOICE)
    ctx = {
        "request": request,
        "user": user,
        "current_year": datetime.now(UTC).year,
        "analysis_ui_url": settings.analysis_ui_url,
        "lims_ui_url": settings.lims_ui_url,
        "bloom_ui_url": settings.bloom_ui_url,
        "csrf_token": get_csrf_token(request),
        "flash_messages": get_flashed_messages(request, with_categories=True),
        "user_theme": "default",  # Default theme
        "user_font": default_font_config["code"],
        "user_font_config": default_font_config,
        "user_preferences": {"display_timezone": DEFAULT_DISPLAY_TIMEZONE},
        "deployment": settings.deployment,
    }

    # Fetch user's theme and preferences from database if we have db and user
    if db and user and user.tenant_id:
        try:
            from app.domain.services.users import UserService
            from app.persistence.tapdb.themes import TapdbThemeRepository

            # Fetch theme from TapDB tenant skin configuration.
            state = TapdbThemeRepository(db).get_current_theme(user.tenant_id)
            ctx["user_theme"] = state.theme
            ctx["user_font"] = state.font_choice
            ctx["user_font_config"] = state.font_config

            # Fetch user preferences from UserProfile
            if user.sub:
                user_profile = UserService(db).get_by_cognito_sub(user.sub)

                if user_profile and user_profile.preferences:
                    ctx["user_preferences"] = {
                        **ctx["user_preferences"],
                        **user_profile.preferences,
                    }

            lookup_email = str(getattr(user, "email", "") or "").strip()
            if lookup_email:
                shared_tz = get_display_timezone_by_login_or_email(db, lookup_email)
                ctx["user_preferences"]["display_timezone"] = shared_tz

        except Exception:
            pass  # Fall back to defaults on any error

    return ctx


def _get_all_organizations_with_revisions(db: Session) -> list:
    """Helper to get all organizations with their latest revision data.

    Returns a list of organization objects with name and display_name attributes set.
    """
    from app.domain.services.orgs import OrganizationService

    org_svc = OrganizationService(db)
    all_orgs = org_svc.list_all(active_only=False)
    organizations = []
    for org in all_orgs:
        result = org_svc.get_with_revision(org.euid)
        if result:
            _, rev = result
            org.name = rev.name
            org.display_name = rev.display_name
            organizations.append(org)
    return organizations


def _list_site_summaries(db: Session, organization_euid: str) -> list[dict[str, object]]:
    """Return site rows with latest revision data for an organization."""
    from app.domain.services.orgs import SiteService

    site_svc = SiteService(db)
    summaries: list[dict[str, object]] = []
    for site in site_svc.list_by_organization(organization_euid):
        latest_rev = site.revisions[-1] if site.revisions else None
        if latest_rev is None:
            continue
        addr = latest_rev.address or {}
        summaries.append(
            {
                "id": site.euid,
                "name": latest_rev.name,
                "site_code": latest_rev.site_code,
                "city": addr.get("city", ""),
                "state": addr.get("state", ""),
                "contact_email": latest_rev.contact_email,
                "contact_phone": latest_rev.contact_phone,
                "is_active": latest_rev.is_active,
            }
        )
    return summaries


def _list_tenant_test_summaries(
    db: Session,
    tenant_id: uuid.UUID,
    *,
    limit_trfs: int = 200,
) -> list[dict[str, str]]:
    """Return flattened Test rows for selector UIs."""
    from app.domain.services.trfs import TestService, TrfService

    trf_svc = TrfService(db, tenant_id)
    test_svc = TestService(db, tenant_id)
    summaries: list[dict[str, str]] = []
    trfs = trf_svc.list_trfs(limit=limit_trfs, cross_tenant=False)
    for trf, _trf_rev in trfs:
        for test, test_rev, _assays in test_svc.list_for_trf(trf.euid, cross_tenant=False):
            label_bits = [test.euid, test_rev.product_code or "TEST", f"TRF {trf.order_number}"]
            summaries.append(
                {
                    "id": test.euid,
                    "label": " | ".join(label_bits),
                    "trf_euid": trf.euid,
                    "trf_number": trf.order_number,
                }
            )
    return summaries


def _list_patient_summaries(db: Session, tenant_id: uuid.UUID) -> list[dict[str, str]]:
    """Return patient selector rows for a tenant."""
    patient_svc = PatientService(db, tenant_id)
    rows: list[dict[str, str]] = []
    for patient, revision in patient_svc.list_patients(limit=200, cross_tenant=False):
        rows.append(
            {
                "id": patient.euid,
                "name": f"{revision.first_name} {revision.last_name}".strip(),
            }
        )
    return rows


def _sync_parent_child_relationships_from_test_roles(
    *,
    db: Session,
    tenant_id: uuid.UUID,
    test_euid: str,
    linked_patient_euid: str,
    linked_role,
    order_rel_svc,
) -> None:
    """Infer parent/child relationship edges from current Test patient roles."""
    from app.domain.enums import OrderPatientRole
    from app.domain.services.patient_relationships import PatientRelationshipService

    links = order_rel_svc.list_order_patient_links(order_euid=test_euid)
    role_map: dict[OrderPatientRole, str] = {}
    for link in links:
        role_map.setdefault(link.role, link.patient_euid)

    proband_euid = role_map.get(OrderPatientRole.PROBAND)
    if not proband_euid:
        return

    rel_svc = PatientRelationshipService(db, tenant_id)
    if linked_role == OrderPatientRole.FATHER:
        if linked_patient_euid != proband_euid:
            rel_svc.set_father(
                child_patient_euid=proband_euid, father_patient_euid=linked_patient_euid
            )
        return

    if linked_role == OrderPatientRole.MOTHER:
        if linked_patient_euid != proband_euid:
            rel_svc.set_mother(
                child_patient_euid=proband_euid, mother_patient_euid=linked_patient_euid
            )
        return

    if linked_role == OrderPatientRole.PROBAND:
        father_euid = role_map.get(OrderPatientRole.FATHER)
        mother_euid = role_map.get(OrderPatientRole.MOTHER)
        if father_euid and father_euid != linked_patient_euid:
            rel_svc.set_father(
                child_patient_euid=linked_patient_euid, father_patient_euid=father_euid
            )
        if mother_euid and mother_euid != linked_patient_euid:
            rel_svc.set_mother(
                child_patient_euid=linked_patient_euid, mother_patient_euid=mother_euid
            )


def _list_testkit_summaries(db: Session, tenant_id: uuid.UUID) -> list[dict[str, str | None]]:
    """Return test kit selector rows for a tenant."""
    from app.domain.services.shipments import TestKitService

    testkit_svc = TestKitService(db, tenant_id)
    rows: list[dict[str, str | None]] = []
    for kit in testkit_svc.list_kits(limit=100, cross_tenant=False):
        kit_result = testkit_svc.get_with_revision(kit.euid, cross_tenant=False)
        kit_revision = kit_result[1] if kit_result else None
        rows.append(
            {
                "id": kit.euid,
                "label": getattr(kit, "display_label", None) or kit.kit_barcode or kit.euid,
                "origin_site_id": getattr(kit_revision, "origin_site_id", None),
            }
        )
    return rows


def _testkit_display_label(testkit) -> str:
    return str(
        getattr(testkit, "display_label", None)
        or getattr(testkit, "kit_barcode", None)
        or getattr(testkit, "euid", "")
    )


def _list_shipment_summaries(db: Session, tenant_id: uuid.UUID) -> list[dict[str, str | None]]:
    """Return shipment selector rows for a tenant."""
    from app.domain.services.shipments import ShipmentService

    shipment_svc = ShipmentService(db, tenant_id)
    rows: list[dict[str, str | None]] = []
    for shipment, revision in shipment_svc.list_shipments(limit=100, cross_tenant=False):
        rows.append(
            {
                "id": shipment.euid,
                "label": shipment.shipment_number,
                "status": revision.status if revision else None,
            }
        )
    return rows


def _list_collection_event_summaries(
    db: Session,
    tenant_id: uuid.UUID,
    *,
    patient_euid: str | None = None,
    container_euid: str | None = None,
) -> list[dict[str, object]]:
    from app.domain.services.collection_events import CollectionEventService
    from app.domain.services.orgs import SiteService

    svc = CollectionEventService(db, tenant_id)
    rows: list[dict[str, object]] = []
    for event, revision in svc.list(patient_euid=patient_euid, container_euid=container_euid):
        site = SiteService(db).get_by_id(event.site_id)
        site_revision = site.revisions[-1] if site and getattr(site, "revisions", None) else None
        rows.append(
            {
                "id": event.euid,
                "patient_euid": event.patient_id,
                "site_euid": event.site_id,
                "site_name": site_revision.name if site_revision else event.site_id,
                "container_euid": event.container_euid,
                "specimen_euid": event.specimen_euid,
                "collected_at": revision.collected_at,
                "collection_type": revision.collection_type,
                "collected_by": revision.collected_by,
                "expected_mrn": revision.expected_mrn,
                "expected_dob": revision.expected_dob,
                "expected_name": revision.expected_name,
                "expected_label_text": revision.expected_label_text,
            }
        )
    return rows


def _list_tube_summaries_for_anchor(
    db: Session,
    tenant_id: uuid.UUID,
    *,
    local_entity_type: str,
    local_entity_id: str,
) -> list[dict[str, object]]:
    from app.domain.services.collection_events import CollectionEventService
    from app.domain.services.external_objects import ExternalObjectService
    from app.domain.services.people import PatientService

    external_svc = ExternalObjectService(db, tenant_id)
    collection_svc = CollectionEventService(db, tenant_id)
    patient_svc = PatientService(db, tenant_id)
    rows: list[dict[str, object]] = []
    seen_container_ids: set[str] = set()
    for relation in external_svc.list_relations_for_local_entity(
        local_entity_type, local_entity_id
    ):
        ext = external_svc.get_external_object_by_id(relation.external_object_id)
        if ext is None or ext.object_type != "container" or ext.is_deleted:
            continue
        if ext.euid in seen_container_ids:
            continue
        seen_container_ids.add(ext.euid)
        rels = external_svc.list_relations_for_external_object(ext.euid)
        collection_event_rel = next(
            (rel for rel in rels if rel.relation_type == "has_collection_event"),
            None,
        )
        collection_event = None
        patient_name = None
        if collection_event_rel is not None:
            collection_event = collection_svc.get(collection_event_rel.local_entity_id)
            if collection_event is not None:
                event, _event_rev = collection_event
                patient = patient_svc.get_by_id(event.patient_id, cross_tenant=False)
                if patient is not None:
                    _patient_obj, patient_rev = patient
                    patient_name = f"{patient_rev.first_name} {patient_rev.last_name}".strip()
        rows.append(
            {
                "container_external_object_euid": ext.euid,
                "container_euid": ext.external_euid,
                "status": ext.status,
                "collection_event_euid": (
                    collection_event[0].euid if collection_event is not None else None
                ),
                "patient_name": patient_name,
                "filled": collection_event is not None,
            }
        )
    return rows


def _build_tube_panel_context(
    db: Session,
    tenant_id: uuid.UUID,
    *,
    anchor_type: str,
    anchor_id: str,
    return_to: str,
) -> dict[str, object]:
    from app.domain.services.site_scope import list_tenant_site_options

    ctx: dict[str, object] = {
        "tube_panel_anchor_type": anchor_type,
        "tube_panel_anchor_id": anchor_id,
        "tube_return_to": return_to,
        "tube_linked_rows": _list_tube_summaries_for_anchor(
            db,
            tenant_id,
            local_entity_type=anchor_type,
            local_entity_id=anchor_id,
        ),
        "tube_test_options": _list_tenant_test_summaries(db, tenant_id),
        "tube_shipment_options": _list_shipment_summaries(db, tenant_id),
        "tube_testkit_options": _list_testkit_summaries(db, tenant_id),
        "tube_patient_options": _list_patient_summaries(db, tenant_id),
        "tube_site_options": list_tenant_site_options(db, tenant_id),
        "tube_selected_test_euid": anchor_id if anchor_type == "Test" else None,
        "tube_selected_shipment_euid": anchor_id if anchor_type == "Shipment" else None,
        "tube_selected_testkit_euid": anchor_id if anchor_type == "TestKit" else None,
        "tube_selected_site_euid": anchor_id if anchor_type == "Site" else None,
    }
    return ctx


def _tube_detail_context(
    db: Session, tenant_id: uuid.UUID, container_euid: str
) -> dict[str, object]:
    from app.domain.services.collection_events import CollectionEventService
    from app.domain.services.external_objects import ExternalObjectService
    from app.domain.services.orgs import SiteService
    from app.domain.services.people import PatientService
    from app.domain.services.shipments import ShipmentService, TestKitService
    from app.domain.services.trfs import TestService

    external_svc = ExternalObjectService(db, tenant_id)
    collection_svc = CollectionEventService(db, tenant_id)
    patient_svc = PatientService(db, tenant_id)
    container = external_svc.get_external_object("bloom", "container", container_euid)
    if container is None:
        raise HTTPException(status_code=404, detail="Tube not found")

    relations = external_svc.list_relations_for_external_object(container.euid)
    detail: dict[str, object] = {
        "container_external_object_euid": container.euid,
        "container_euid": container.external_euid,
        "status": container.status,
        "test": None,
        "shipment": None,
        "testkit": None,
        "site": None,
        "collection_event": None,
        "specimen": None,
    }
    for relation in relations:
        if relation.relation_type == "belongs_to_test":
            test = TestService(db, tenant_id).get_by_id(
                relation.local_entity_id, cross_tenant=False
            )
            if test is not None:
                test_obj = test
                detail["test"] = {"id": test_obj.euid}
        elif relation.relation_type == "belongs_to_shipment":
            shipment = ShipmentService(db, tenant_id).get(
                relation.local_entity_id, cross_tenant=False
            )
            if shipment is not None:
                detail["shipment"] = {"id": shipment[0].euid, "label": shipment[0].shipment_number}
        elif relation.relation_type == "belongs_to_testkit":
            testkit = TestKitService(db, tenant_id).get_with_revision(
                relation.local_entity_id, cross_tenant=False
            )
            if testkit is not None:
                detail["testkit"] = {
                    "id": testkit[0].euid,
                    "label": _testkit_display_label(testkit[0]),
                }
        elif relation.relation_type == "belongs_to_site":
            site = SiteService(db).get_by_id(relation.local_entity_id)
            site_rev = site.revisions[-1] if site and getattr(site, "revisions", None) else None
            if site is not None:
                detail["site"] = {
                    "id": site.euid,
                    "label": site_rev.name if site_rev else site.euid,
                }
        elif relation.relation_type == "has_collection_event":
            event = collection_svc.get(relation.local_entity_id)
            if event is not None:
                event_obj, event_rev = event
                patient = patient_svc.get_by_id(event_obj.patient_id, cross_tenant=False)
                patient_name = None
                if patient is not None:
                    _patient_obj, patient_rev = patient
                    patient_name = f"{patient_rev.first_name} {patient_rev.last_name}".strip()
                detail["collection_event"] = {
                    "id": event_obj.euid,
                    "patient_euid": event_obj.patient_id,
                    "patient_name": patient_name,
                    "site_euid": event_obj.site_id,
                    "collected_at": event_rev.collected_at,
                    "collection_type": event_rev.collection_type,
                    "collected_by": event_rev.collected_by,
                }

    specimen_links = external_svc.list_relations_for_local_entity("ExternalObject", container.euid)
    for relation in specimen_links:
        if relation.relation_type != "contained_in":
            continue
        specimen = external_svc.get_external_object_by_id(relation.external_object_id)
        if specimen is None or specimen.object_type != "specimen":
            continue
        detail["specimen"] = {
            "external_object_euid": specimen.euid,
            "specimen_euid": specimen.external_euid,
            "status": specimen.status,
        }
        break

    return detail


def _list_owner_candidates(db: Session, org_id: str) -> list[dict[str, str]]:
    """List active users in an organization for owner assignment."""
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserService

    org = OrganizationService(db).get_by_id(org_id)
    if org is None or org.uid is None:
        return []

    user_svc = UserService(db)
    users = user_svc.list_users(tenant_id=org.uid, limit=500, is_active=True)
    candidates = [
        {
            "id": str(user.euid),
            "email": user.email,
            "name": user.name or "",
            "display": _format_owner_user_display(user.euid, user.email, user.name),
        }
        for user in users
    ]
    candidates.sort(key=lambda item: (item["name"].lower(), item["email"].lower()))
    return candidates


def _format_owner_user_display(
    euid: str | None,
    email: str | None,
    name: str | None,
) -> str:
    """Render owner as EUID | email | name."""
    parts = [
        part
        for part in [str(euid or "").strip(), (email or "").strip(), (name or "").strip()]
        if part
    ]
    return " | ".join(parts)


def _lookup_owner_user_profile(db: Session, value: str | None):
    """Resolve owner profile from EUID/email/display input with tolerant matching."""
    from app.domain.services.users import UserService

    token = _normalize_owner_lookup_input(value)
    if not token:
        return None

    user_svc = UserService(db)
    user = user_svc.get_by_id(token)
    if user is None:
        user = user_svc.get_by_id(token.upper())
    if user is None and "@" in token:
        user = user_svc.get_by_email(token)
    if user is not None:
        return user

    lowered = token.casefold()
    for candidate in user_svc.list_users(limit=1000, is_active=None):
        if lowered in {
            str(getattr(candidate, "euid", "")).casefold(),
            str(getattr(candidate, "email", "")).casefold(),
            str(getattr(candidate, "name", "")).casefold(),
        }:
            return candidate
    return None


def _normalize_owner_lookup_input(value: str | None) -> str:
    """Accept rich owner display input and return best lookup token."""
    raw = (value or "").strip()
    if not raw:
        return ""

    if "|" in raw:
        tokens = [token.strip() for token in raw.split("|") if token.strip()]
        email_token = next((token for token in tokens if "@" in token), None)
        if email_token:
            return email_token
        if tokens:
            return tokens[0]

    if "—" in raw:
        left = raw.split("—", 1)[0].strip()
        if left:
            return left

    return raw


def _resolve_optional_owner_user_id(
    db: Session,
    value: str | None,
    *,
    field_name: str,
    organization_euid: str | None = None,
) -> str | None:
    """Resolve optional owner input by EUID, email, or fuzzy name match."""
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserService

    raw = _normalize_owner_lookup_input(value)
    if not raw:
        return None

    user_svc = UserService(db)
    user = user_svc.get_by_id(raw)
    if user is None and "@" in raw:
        user = user_svc.get_by_email(raw)

    if user is None:
        lowered = raw.casefold()
        candidates = user_svc.list_users(limit=1000, is_active=True)
        matches = [
            candidate
            for candidate in candidates
            if lowered in (candidate.email or "").casefold()
            or lowered in (candidate.name or "").casefold()
            or lowered in str(candidate.euid).casefold()
        ]
        if len(matches) > 1:
            raise ValueError(f"{field_name} matches multiple users; provide exact EUID or email")
        if not matches:
            raise ValueError(f"{field_name} did not match any active user")
        user = matches[0]

    if organization_euid:
        org = OrganizationService(db).get_by_id(organization_euid)
        if org is None or org.uid is None:
            raise ValueError("Organization not found for owner assignment")
        if user.tenant_id != org.uid:
            raise ValueError(
                "Owner user must belong to the same organization (users are single-org only)"
            )

    return str(user.euid)


def _normalize_specimen_types_input(value: str | None) -> list[str] | None:
    """Normalize comma-separated specimen types from admin assay forms."""
    if value is None:
        return None

    normalized: list[str] = []
    seen: set[str] = set()
    for raw_token in value.split(","):
        token = raw_token.strip().upper()
        if not token or token in seen:
            continue
        seen.add(token)
        normalized.append(token)
    return normalized


def _normalize_optional_text(value: str | None) -> str | None:
    """Normalize optional text form fields and drop sentinel strings."""
    raw = (value or "").strip()
    if not raw or raw.casefold() in {"none", "null"}:
        return None
    return raw


def _extract_bloom_config_form_payload(form_data) -> dict[str, str | bool | None]:
    """Normalize shared Bloom config form fields."""
    return {
        "enabled": form_data.get("enabled") == "true",
        "bloom_base_url": (form_data.get("bloom_base_url") or "").strip(),
        "bloom_api_key_secret_ref": (form_data.get("bloom_api_key_secret_ref") or "").strip(),
        "bloom_webhook_secret_ref": (form_data.get("bloom_webhook_secret_ref") or "").strip()
        or None,
        "bloom_service_user": (form_data.get("bloom_service_user") or "").strip() or None,
    }


def _validate_bloom_credentials(
    *,
    bloom_base_url: str,
    bloom_api_key_secret_ref: str,
) -> None:
    """Validate Bloom API credentials using a lightweight authenticated call."""
    from app.integrations.bloom_client import BloomClient, resolve_secret_value

    base_url = (bloom_base_url or "").strip()
    secret_ref = (bloom_api_key_secret_ref or "").strip()
    if not base_url:
        raise ValueError("Bloom Base URL is required for validation")
    if not secret_ref:
        raise ValueError("Bloom API Key Secret Ref is required for validation")

    api_key = resolve_secret_value(secret_ref)
    client = BloomClient(
        base_url=base_url,
        api_key=api_key,
        timeout_seconds=settings.bloom_request_timeout_seconds,
        max_retries=settings.bloom_max_retries,
        verify_ssl=settings.bloom_verify_ssl,
    )
    client.list_object_categories()


def _check_bloom_connection_health(
    *,
    bloom_base_url: str,
    bloom_api_key_secret_ref: str,
) -> None:
    """Run a bounded, lightweight Bloom connectivity check for page rendering."""
    from app.integrations.bloom_client import BloomClient, resolve_secret_value

    base_url = (bloom_base_url or "").strip()
    secret_ref = (bloom_api_key_secret_ref or "").strip()
    if not base_url:
        raise ValueError("Bloom Base URL is required for status checks")
    if not secret_ref:
        raise ValueError("Bloom API Key Secret Ref is required for status checks")

    api_key = resolve_secret_value(secret_ref)
    timeout_seconds = max(1, min(int(settings.bloom_request_timeout_seconds), 3))
    client = BloomClient(
        base_url=base_url,
        api_key=api_key,
        timeout_seconds=timeout_seconds,
        max_retries=0,
        verify_ssl=settings.bloom_verify_ssl,
    )
    client.list_object_categories()


def _build_org_bloom_connection_status(org_bloom_config) -> dict[str, str]:
    """Build UI status for org-level Bloom connectivity, checking live when possible."""
    try:
        if org_bloom_config is None:
            return {
                "state": "not_configured",
                "badge": "secondary",
                "label": "Not Configured",
                "detail": "No organization Bloom configuration is saved yet.",
            }

        if not bool(getattr(org_bloom_config, "enabled", False)):
            return {
                "state": "disabled",
                "badge": "secondary",
                "label": "Disabled",
                "detail": "Bloom integration is disabled for this organization.",
            }

        bloom_base_url = (getattr(org_bloom_config, "bloom_base_url", "") or "").strip()
        bloom_api_key_secret_ref = (
            getattr(org_bloom_config, "bloom_api_key_secret_ref", "") or ""
        ).strip()
        missing: list[str] = []
        if not bloom_base_url:
            missing.append("bloom_base_url")
        if not bloom_api_key_secret_ref:
            missing.append("bloom_api_key_secret_ref")
        if missing:
            return {
                "state": "incomplete",
                "badge": "warning",
                "label": "Config Incomplete",
                "detail": f"Missing required field(s): {', '.join(missing)}.",
            }

        try:
            _check_bloom_connection_health(
                bloom_base_url=bloom_base_url,
                bloom_api_key_secret_ref=bloom_api_key_secret_ref,
            )
        except Exception as exc:  # pragma: no cover - exercised via monkeypatch in tests
            logger.warning(
                "Bloom connectivity check failed for org %s: %s",
                getattr(org_bloom_config, "organization_id", "unknown"),
                exc,
            )
            detail = str(exc).strip() or "Unable to complete authenticated Bloom API checks."
            if len(detail) > 200:
                detail = f"{detail[:197]}..."
            return {
                "state": "error",
                "badge": "danger",
                "label": "Connection Failed",
                "detail": f"Checked on page load: {detail}",
            }

        return {
            "state": "healthy",
            "badge": "success",
            "label": "Connection OK",
            "detail": "Checked on page load: authenticated Bloom API checks succeeded.",
        }
    except Exception as exc:  # pragma: no cover - defensive
        logger.exception("Unable to compute Bloom connection status: %s", exc)
        return {
            "state": "error",
            "badge": "danger",
            "label": "Status Unavailable",
            "detail": "Bloom status could not be evaluated on page load.",
        }


ORDER_STATUS_UI_TO_DB = {
    "CREATED": "DRAFT",
    "ACTIVE": "ACTIVE",
    "ACKNOWLEDGED": "SUBMITTED",
    "CANCELED": "CANCELED",
    "ABANDONED": "ABANDONED",
    "COMPLETE": "COMPLETED_REPORT_READY",
    "EXCEPTION": "REJECTED",
}

ORDER_STATUS_OPTIONS = [
    ("CREATED", "created"),
    ("ACTIVE", "active"),
    ("ACKNOWLEDGED", "acknowledged"),
    ("CANCELED", "canceled"),
    ("ABANDONED", "abandoned"),
    ("COMPLETE", "complete"),
    ("EXCEPTION", "exception"),
]

ORDER_STATUS_CHIP_LABELS = {
    "DRAFT": "draft",
    "ACTIVE": "in progress",
    "SUBMITTED": "submitted",
    "CANCELED": "voided",
    "ABANDONED": "archived",
    "COMPLETED_REPORT_READY": "results ready",
    "REJECTED": "rejected",
}

TEST_ORDER_STATUS_UI_TO_DB = {
    "IN_PROGRESS": "IN_PROGRESS",
    "FAILED": "FAILED",
    "REJECTED": "REJECTED",
    "COMPLETED": "COMPLETED",
    "CANCELED": "CANCELED",
}

TEST_ORDER_STATUS_OPTIONS = [
    ("IN_PROGRESS", "in progress"),
    ("FAILED", "failed"),
    ("REJECTED", "rejected"),
    ("COMPLETED", "completed"),
    ("CANCELED", "canceled"),
]

TEST_ORDER_STATUS_ALLOWED = {value for value, _label in TEST_ORDER_STATUS_OPTIONS}

ORDER_STATUS_DB_TO_UI = {db: ui for ui, db in ORDER_STATUS_UI_TO_DB.items()}
TEST_ORDER_STATUS_DB_TO_UI = {db: ui for ui, db in TEST_ORDER_STATUS_UI_TO_DB.items()}


def _order_status_ui_from_db(status: str | None) -> str:
    status_normalized = (status or "DRAFT").strip().upper()
    return ORDER_STATUS_DB_TO_UI.get(status_normalized, status_normalized)


def _test_order_status_ui_from_db(status: str | None) -> str:
    status_normalized = (status or "").strip().upper()
    return TEST_ORDER_STATUS_DB_TO_UI.get(status_normalized, "")


def _status_label(value: str | None) -> str:
    return (value or "").replace("_", " ").strip().lower()


def _option_label(options: list[tuple[str, str]], value: str | None) -> str:
    normalized = (value or "").strip().upper()
    for option_value, option_label in options:
        if option_value == normalized:
            return option_label
    return _status_label(normalized)


def _trf_status_label(status: str | None) -> str:
    ui_value = _order_status_ui_from_db(status)
    return _option_label(ORDER_STATUS_OPTIONS, ui_value)


def _test_status_label(status: str | None) -> str:
    ui_value = _test_order_status_ui_from_db(status)
    if ui_value:
        return _option_label(TEST_ORDER_STATUS_OPTIONS, ui_value)
    return _status_label(status)


# --- Dashboard ---


@router.get("/login", response_class=HTMLResponse)
async def login_splash(request: Request):
    """Public login splash page."""
    current_user = _get_current_user_from_session(request)
    if current_user is not None:
        return RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)

    ctx = get_template_context(request)
    ctx.update(
        {
            "auth_badge": "Secure SSO",
            "auth_eyebrow": "LSMC Atlas",
            "auth_title": "Operational access for TRFs, shipments, results, and support.",
            "auth_description": (
                "Atlas gives LSMC teams and partner organizations one secure workspace "
                "for case movement, specimen coordination, and follow-up."
            ),
            "auth_card_state": "default",
            "auth_card_kicker": "Clinical Sequencing Customer Portal",
            "auth_card_title": "Sign in to continue",
            "auth_card_copy": (
                "Use your approved organization credentials to continue into LSMC Atlas."
            ),
            "auth_primary_href": "/auth/login",
            "auth_primary_label": "Sign In With Secure SSO",
            "auth_secondary_prefix": "Need help with access?",
            "auth_secondary_label": "support@lsmc.bio",
            "auth_secondary_href": "mailto:support@lsmc.bio",
            "auth_footer_note": "Customer portal for clinical sequencing operations.",
        }
    )
    return templates.TemplateResponse(request, "login.html", context=ctx)


@router.get("/", response_class=HTMLResponse)
async def dashboard(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Dashboard page."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.dashboard import DashboardService

    ctx = get_template_context(request, current_user, db)

    # Internal/admin users with CROSS_TENANT_READ see data across all tenants
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)

    # Get dashboard data
    svc = DashboardService(db, current_user.tenant_id, current_user.sub)
    stats = svc.get_stats(cross_tenant=cross_tenant)
    recent_orders = svc.get_recent_orders(limit=10, cross_tenant=cross_tenant)
    pending_exceptions = svc.get_pending_exceptions(limit=5) if current_user.is_internal else []

    ctx["stats"] = {
        "orders_total": stats.orders_total,
        "orders_active": stats.orders_active,
        "shipments_in_transit": stats.shipments_in_transit,
        "results_ready": stats.results_ready,
    }
    ctx["recent_orders"] = [
        {
            "id": order.id,
            "order_number": order.order_number,
            "patient_name": order.patient_name,
            "status": order.status,
            "created_at": order.created_at,
        }
        for order in recent_orders
    ]
    ctx["pending_exceptions"] = [
        {
            "id": exc.id,
            "barcode": exc.barcode or exc.exception_number,
            "type": exc.exception_type,
            "issue": exc.issue,
            "created_at": exc.created_at,
        }
        for exc in pending_exceptions
    ]
    ctx["show_api_docs"] = settings.debug

    return templates.TemplateResponse(request, "dashboard.html", context=ctx)


# --- My Organization (for external users) ---


@router.get("/my-organization", response_class=HTMLResponse)
async def my_organization(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """View current user's organization details."""
    from app.domain.services.external_objects import OrgBloomConfigService, SiteBloomConfigService
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.storage_policies import StoragePolicyService
    from app.domain.services.users import UserService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision_by_uid(current_user.tenant_id)

    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    ctx["organization"] = organization
    ctx["revision"] = revision

    ctx["sites"] = _list_site_summaries(db, organization.euid)
    site_config_service = SiteBloomConfigService(db)
    site_config_map = {
        cfg.site_id: cfg
        for cfg in site_config_service.list_enabled(organization_id=current_user.tenant_id)
    }
    for site in ctx["sites"]:
        site["bloom_config_enabled"] = site["id"] in site_config_map
    org_bloom_config = OrgBloomConfigService(db).get(current_user.tenant_id)
    ctx["org_bloom_config"] = org_bloom_config
    ctx["bloom_connection_status"] = _build_org_bloom_connection_status(org_bloom_config)

    storage_policy_service = StoragePolicyService(db)
    org_storage_policy = storage_policy_service.get_org_policy(organization.euid)
    ctx["org_storage_policy"] = org_storage_policy
    try:
        ctx["effective_org_storage_policy"] = storage_policy_service.resolve_effective_policy(
            organization_euid=organization.euid,
            site_euid=None,
        )
    except ValueError:
        ctx["effective_org_storage_policy"] = None

    # Get users in this organization
    user_svc = UserService(db, current_user.sub_uuid)
    users = user_svc.list_users(tenant_id=current_user.tenant_id, limit=50)
    ctx["users"] = [
        {
            "id": str(u.euid),
            "name": u.name,
            "email": u.email,
            "roles": u.roles,
            "is_active": u.is_active,
        }
        for u in users
    ]

    return templates.TemplateResponse(request, "my_organization/index.html", context=ctx)


@router.get("/my-organization/users", response_class=HTMLResponse)
async def my_organization_users(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """List users in current user's organization."""
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision_by_uid(current_user.tenant_id)

    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    ctx["organization"] = organization
    ctx["revision"] = revision

    # Get users in this organization
    user_svc = UserService(db, current_user.sub_uuid)
    users = user_svc.list_users(tenant_id=current_user.tenant_id, limit=100)
    ctx["users"] = [
        {
            "id": str(u.euid),
            "name": u.name,
            "email": u.email,
            "roles": u.roles,
            "is_active": u.is_active,
        }
        for u in users
    ]
    # All org members can view users (read-only); org admins get management controls
    ctx["can_manage_users"] = current_user.is_org_admin

    return templates.TemplateResponse(request, "my_organization/users.html", context=ctx)


@router.get(
    "/my-organization/users/new",
    response_class=HTMLResponse,
    dependencies=[Depends(require_org_admin)],
)
async def my_organization_user_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Show user creation form for current user's organization (org admin only)."""
    from app.domain.services.orgs import OrganizationService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision_by_uid(current_user.tenant_id)

    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    ctx["organization"] = organization
    ctx["revision"] = revision

    # Org admins can assign more roles than regular external users
    ctx["available_roles"] = sorted(ORG_ADMIN_ASSIGNABLE_ROLES)

    return templates.TemplateResponse(request, "my_organization/user_form.html", context=ctx)


@router.post(
    "/my-organization/users/new",
    response_class=HTMLResponse,
    dependencies=[Depends(require_org_admin), Depends(csrf_protect)],
)
async def my_organization_user_create(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Create a new user for current user's organization (org admin only)."""
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserCreate, UserService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision_by_uid(current_user.tenant_id)

    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    form_data = await request.form()

    # Filter to only org-admin assignable roles
    roles = [r for r in form_data.getlist("roles") if r in ORG_ADMIN_ASSIGNABLE_ROLES]

    try:
        user_svc = UserService(db, current_user.sub_uuid)
        user_svc.invite(
            UserCreate(
                email=form_data["email"],
                name=form_data.get("name") or None,
                tenant_id=current_user.tenant_id,
                roles=roles,
            )
        )
        flash(request, "User invited successfully", "success")
        return RedirectResponse(url="/my-organization/users", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        ctx["organization"] = organization
        ctx["revision"] = revision
        ctx["available_roles"] = sorted(ORG_ADMIN_ASSIGNABLE_ROLES)
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "my_organization/user_form.html", context=ctx)


@router.post(
    "/my-organization/users/{user_id}/deactivate",
    dependencies=[Depends(require_org_admin), Depends(csrf_protect)],
)
async def my_organization_user_deactivate(
    request: Request,
    user_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Deactivate a user in the current org (org admin only)."""
    from app.domain.services.users import UserService

    user_svc = UserService(db, current_user.sub_uuid)
    target_user = user_svc.get_by_id(user_id)

    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")

    # Tenant isolation: only deactivate users in own org
    if target_user.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=403, detail="Access denied")

    # Prevent self-deactivation
    if str(target_user.cognito_sub) == current_user.sub:
        flash(request, "Cannot deactivate your own account", "error")
        return RedirectResponse(url="/my-organization/users", status_code=status.HTTP_303_SEE_OTHER)

    user_svc.deactivate(user_id)
    flash(request, f"User {target_user.email} deactivated", "success")
    return RedirectResponse(url="/my-organization/users", status_code=status.HTTP_303_SEE_OTHER)


@router.post(
    "/my-organization/users/{user_id}/activate",
    dependencies=[Depends(require_org_admin), Depends(csrf_protect)],
)
async def my_organization_user_activate(
    request: Request,
    user_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Activate a user in the current org (org admin only)."""
    from app.domain.services.users import UserService

    user_svc = UserService(db, current_user.sub_uuid)
    target_user = user_svc.get_by_id(user_id)

    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")

    # Tenant isolation: only activate users in own org
    if target_user.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=403, detail="Access denied")

    user_svc.activate(user_id)
    flash(request, f"User {target_user.email} activated", "success")
    return RedirectResponse(url="/my-organization/users", status_code=status.HTTP_303_SEE_OTHER)


# --- Org-Admin Token Management for Org Users ---


@router.get(
    "/my-organization/users/{user_id}/api-tokens",
    response_class=HTMLResponse,
    dependencies=[Depends(require_org_admin)],
)
async def my_organization_user_tokens(
    request: Request,
    user_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """List API tokens for an org user (org admin only)."""
    from app.domain.services.user_api_tokens import UserAPITokenService
    from app.domain.services.users import UserService

    user_svc = UserService(db, current_user.sub_uuid)
    target_user = user_svc.get_by_id(user_id)

    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")

    # Tenant isolation
    if target_user.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=403, detail="Access denied")

    token_svc = UserAPITokenService(db, current_user.tenant_id)
    target_user_sub = uuid.UUID(target_user.cognito_sub)
    tokens = token_svc.list_user_tokens(target_user_sub)
    has_api_access = token_svc.user_has_api_access(target_user_sub)

    ctx = get_template_context(request, current_user, db)
    ctx["target_user_id"] = str(user_id)
    ctx["target_user_name"] = target_user.name or target_user.email
    ctx["target_user_email"] = target_user.email
    ctx["tokens"] = tokens
    ctx["has_api_access"] = has_api_access

    return templates.TemplateResponse(request, "my_organization/user_tokens.html", context=ctx)


@router.post(
    "/my-organization/users/{user_id}/api-tokens",
    dependencies=[Depends(require_org_admin), Depends(csrf_protect)],
)
async def my_organization_user_token_create(
    request: Request,
    user_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Create an API token for an org user (org admin only, ext_org scope only)."""
    from app.domain.services.user_api_tokens import TokenCreate, UserAPITokenService
    from app.domain.services.users import UserService

    user_svc = UserService(db, current_user.sub_uuid)
    target_user = user_svc.get_by_id(user_id)

    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")

    # --- CODEQL SAST FIX ---
    # Construct the redirect URL using the trusted database property (target_user.euid).
    # This proves to CodeQL that no malicious payload can be injected into the URL.
    safe_user_id = str(target_user.euid)
    redirect_url = f"/my-organization/users/{safe_user_id}/api-tokens"

    # Tenant isolation
    if target_user.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=403, detail="Access denied")

    token_svc = UserAPITokenService(db, current_user.tenant_id)

    # Target user must have API_ACCESS group
    target_user_sub = uuid.UUID(target_user.cognito_sub)
    if not token_svc.user_has_api_access(target_user_sub):
        flash(request, "User does not have API_ACCESS group membership", "error")
        return RedirectResponse(
            url=_safe_redirect_url(redirect_url), status_code=status.HTTP_303_SEE_OTHER
        )

    form_data = await request.form()
    token_name = form_data.get("token_name", "").strip()
    expires_in_days = int(form_data.get("expires_in_days", 90))

    if not token_name:
        flash(request, "Token name is required", "error")
        return RedirectResponse(
            url=_safe_redirect_url(redirect_url), status_code=status.HTTP_303_SEE_OTHER
        )

    if expires_in_days < 1 or expires_in_days > 365:
        flash(request, "Expiration must be between 1 and 365 days", "error")
        return RedirectResponse(
            url=_safe_redirect_url(redirect_url), status_code=status.HTTP_303_SEE_OTHER
        )

    # Org admins can only create ext_org scope tokens for org users
    scope = "ext_org"

    token, revision, plaintext_token = token_svc.create(
        user_id=target_user_sub,
        data=TokenCreate(token_name=token_name, expires_in_days=expires_in_days, scope=scope),
        created_by=current_user.sub_uuid,
    )

    # Show the token (only shown once) — reuse existing template
    ctx = get_template_context(request, current_user, db)
    ctx["token"] = token
    ctx["revision"] = revision
    ctx["plaintext_token"] = plaintext_token
    scheme = request.headers.get("X-Forwarded-Proto", request.url.scheme)
    if "localhost" in request.url.netloc or "127.0.0.1" in request.url.netloc:
        scheme = "https"
    ctx["base_url"] = f"{scheme}://{request.url.netloc}"
    return templates.TemplateResponse(request, "settings/show_api_token.html", context=ctx)


@router.post(
    "/my-organization/users/{user_id}/api-tokens/{token_id}/revoke",
    dependencies=[Depends(require_org_admin), Depends(csrf_protect)],
)
async def my_organization_user_token_revoke(
    request: Request,
    user_id: str,
    token_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Revoke an API token for an org user (org admin only)."""
    from app.domain.services.user_api_tokens import UserAPITokenService
    from app.domain.services.users import UserService

    user_svc = UserService(db, current_user.sub_uuid)
    target_user = user_svc.get_by_id(user_id)

    if not target_user:
        raise HTTPException(status_code=404, detail="User not found")

    safe_user_id = str(target_user.euid)
    redirect_url = f"/my-organization/users/{safe_user_id}/api-tokens"

    # Tenant isolation
    if target_user.tenant_id != current_user.tenant_id:
        raise HTTPException(status_code=403, detail="Access denied")

    token_svc = UserAPITokenService(db, current_user.tenant_id)

    # Verify token exists and belongs to the target user
    token_result = token_svc.get_token(token_id)
    if not token_result:
        flash(request, "Token not found", "error")
        return RedirectResponse(
            url=_safe_redirect_url(redirect_url), status_code=status.HTTP_303_SEE_OTHER
        )

    token, _ = token_result
    target_user_sub = str(uuid.UUID(target_user.cognito_sub))
    if token.user_id != target_user_sub:
        flash(request, "Token does not belong to this user", "error")
        return RedirectResponse(
            url=_safe_redirect_url(redirect_url), status_code=status.HTTP_303_SEE_OTHER
        )

    form_data = await request.form()
    reason = form_data.get("reason", "Revoked by org admin")

    token_svc.revoke(token_id, revoked_by=current_user.sub_uuid, reason=reason)
    flash(request, f"Token '{token.token_name}' has been revoked", "success")

    return RedirectResponse(
        url=_safe_redirect_url(redirect_url), status_code=status.HTTP_303_SEE_OTHER
    )


@router.get("/my-organization/sites", response_class=HTMLResponse)
async def my_organization_sites(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """List sites in current user's organization."""
    from app.domain.services.external_objects import SiteBloomConfigService
    from app.domain.services.orgs import OrganizationService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision_by_uid(current_user.tenant_id)

    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    ctx["organization"] = organization
    ctx["revision"] = revision

    ctx["sites"] = _list_site_summaries(db, organization.euid)
    site_config_service = SiteBloomConfigService(db)
    site_config_map = {
        cfg.site_id: cfg
        for cfg in site_config_service.list_enabled(organization_id=current_user.tenant_id)
    }
    for site in ctx["sites"]:
        site["bloom_config_enabled"] = site["id"] in site_config_map

    return templates.TemplateResponse(request, "my_organization/sites.html", context=ctx)


@router.get("/my-organization/sites/new", response_class=HTMLResponse)
async def my_organization_site_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Show site creation form for current user's organization."""
    from app.domain.services.orgs import OrganizationService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision_by_uid(current_user.tenant_id)

    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    ctx["organization"] = organization
    ctx["revision"] = revision
    ctx["site"] = None
    ctx["site_revision"] = None

    return templates.TemplateResponse(request, "my_organization/site_form.html", context=ctx)


@router.post(
    "/my-organization/sites/new",
    response_class=HTMLResponse,
    dependencies=[Depends(csrf_protect)],
)
async def my_organization_site_create(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Create a new site for current user's organization."""
    from app.domain.services.orgs import OrganizationService, SiteCreate, SiteService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision_by_uid(current_user.tenant_id)

    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    form_data = await request.form()

    # Build address dict
    address = {}
    if form_data.get("address_line1"):
        address["line1"] = form_data["address_line1"]
    if form_data.get("address_line2"):
        address["line2"] = form_data["address_line2"]
    if form_data.get("city"):
        address["city"] = form_data["city"]
    if form_data.get("state"):
        address["state"] = form_data["state"]
    if form_data.get("postal_code"):
        address["postal_code"] = form_data["postal_code"]

    try:
        svc = SiteService(db)
        svc.create(
            SiteCreate(
                organization_id=organization.euid,
                name=form_data["name"],
                site_code=form_data.get("site_code"),
                address=address if address else None,
                contact_email=form_data.get("contact_email"),
                contact_phone=form_data.get("contact_phone"),
            ),
            created_by=current_user.sub_uuid,
        )
        flash(request, "Site created successfully", "success")
        return RedirectResponse(url="/my-organization/sites", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        ctx["organization"] = organization
        ctx["revision"] = revision
        ctx["site"] = None
        ctx["site_revision"] = None
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "my_organization/site_form.html", context=ctx)


@router.get("/my-organization/sites/{site_id}", response_class=HTMLResponse)
async def my_organization_site_detail(
    request: Request,
    site_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Show a site detail page within the current organization."""
    from app.domain.services.external_objects import (
        BloomConfigResolverService,
        OrgBloomConfigService,
        SiteBloomConfigService,
    )
    from app.domain.services.orgs import OrganizationService, SiteService
    from app.domain.services.storage_policies import StoragePolicyService

    ctx = get_template_context(request, current_user, db)
    org_result = OrganizationService(db).get_with_revision_by_uid(current_user.tenant_id)
    if not org_result:
        raise HTTPException(status_code=404, detail="Organization not found")
    organization, revision = org_result

    site = SiteService(db).get_by_id(site_id)
    if not site or str(site.organization_id) != str(organization.euid):
        raise HTTPException(status_code=404, detail="Site not found")

    site_revision = site.revisions[-1] if site.revisions else None
    ctx["organization"] = organization
    ctx["revision"] = revision
    ctx["site"] = site
    ctx["site_revision"] = site_revision
    ctx["org_bloom_config"] = OrgBloomConfigService(db).get(current_user.tenant_id)
    ctx["site_bloom_config"] = SiteBloomConfigService(db).get(site_id)
    ctx["effective_bloom_config"] = BloomConfigResolverService(db).get_effective(
        organization_id=current_user.tenant_id,
        site_id=site_id,
    )
    storage_policy_service = StoragePolicyService(db)
    ctx["site_storage_policy"] = storage_policy_service.get_site_policy(
        organization_euid=organization.euid,
        site_euid=site_id,
    )
    try:
        ctx["effective_site_storage_policy"] = storage_policy_service.resolve_effective_policy(
            organization_euid=organization.euid,
            site_euid=site_id,
        )
    except ValueError:
        ctx["effective_site_storage_policy"] = None
    ctx.update(
        _build_tube_panel_context(
            db,
            current_user.tenant_id,
            anchor_type="Site",
            anchor_id=site.euid,
            return_to=f"/my-organization/sites/{site.euid}",
        )
    )
    return templates.TemplateResponse(request, "my_organization/site_detail.html", context=ctx)


@router.post(
    "/my-organization/integrations/bloom",
    dependencies=[Depends(require_org_admin), Depends(csrf_protect)],
)
async def my_organization_bloom_config_save(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Create or update the current org's Bloom integration config."""
    from app.domain.services.external_objects import OrgBloomConfigService, OrgBloomConfigUpsert

    form_data = await request.form()
    action = (form_data.get("action") or "save").strip().lower()
    payload = _extract_bloom_config_form_payload(form_data)
    if action == "validate":
        try:
            _validate_bloom_credentials(
                bloom_base_url=str(payload["bloom_base_url"]),
                bloom_api_key_secret_ref=str(payload["bloom_api_key_secret_ref"]),
            )
            flash(
                request,
                "Bloom credentials validated successfully. Values were not saved.",
                "success",
            )
        except Exception as exc:
            flash(request, f"Bloom credential validation failed: {exc}", "error")
        return RedirectResponse(url="/my-organization", status_code=status.HTTP_303_SEE_OTHER)

    try:
        OrgBloomConfigService(db).upsert(
            current_user.tenant_id,
            OrgBloomConfigUpsert(
                enabled=bool(payload["enabled"]),
                bloom_base_url=str(payload["bloom_base_url"]),
                bloom_api_key_secret_ref=str(payload["bloom_api_key_secret_ref"]),
                bloom_webhook_secret_ref=(
                    str(payload["bloom_webhook_secret_ref"])
                    if payload["bloom_webhook_secret_ref"] is not None
                    else None
                ),
                bloom_service_user=(
                    str(payload["bloom_service_user"])
                    if payload["bloom_service_user"] is not None
                    else None
                ),
            ),
            actor_id=current_user.sub_uuid,
        )
        flash(request, "Organization Bloom integration saved.", "success")
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
    return RedirectResponse(url="/my-organization", status_code=status.HTTP_303_SEE_OTHER)


@router.post(
    "/my-organization/sites/{site_id}/integrations/bloom",
    dependencies=[Depends(require_org_admin), Depends(csrf_protect)],
)
async def my_organization_site_bloom_config_save(
    request: Request,
    site_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Create or update a site-level Bloom integration config."""
    from app.domain.services.external_objects import SiteBloomConfigService, SiteBloomConfigUpsert
    from app.domain.services.orgs import OrganizationService, SiteService

    org_result = OrganizationService(db).get_with_revision_by_uid(current_user.tenant_id)
    if not org_result:
        raise HTTPException(status_code=404, detail="Organization not found")
    organization, _revision = org_result
    site = SiteService(db).get_by_id(site_id)
    if not site or str(site.organization_id) != str(organization.euid):
        raise HTTPException(status_code=404, detail="Site not found")

    form_data = await request.form()
    action = (form_data.get("action") or "save").strip().lower()
    payload = _extract_bloom_config_form_payload(form_data)
    if action == "validate":
        try:
            _validate_bloom_credentials(
                bloom_base_url=str(payload["bloom_base_url"]),
                bloom_api_key_secret_ref=str(payload["bloom_api_key_secret_ref"]),
            )
            flash(
                request,
                "Bloom credentials validated successfully. Values were not saved.",
                "success",
            )
        except Exception as exc:
            flash(request, f"Bloom credential validation failed: {exc}", "error")
            safe_site_id = str(site.euid)
        return RedirectResponse(
            url=_safe_redirect_url(f"/my-organization/sites/{safe_site_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    try:
        SiteBloomConfigService(db).upsert(
            site_id,
            current_user.tenant_id,
            SiteBloomConfigUpsert(
                enabled=bool(payload["enabled"]),
                bloom_base_url=str(payload["bloom_base_url"]),
                bloom_api_key_secret_ref=str(payload["bloom_api_key_secret_ref"]),
                bloom_webhook_secret_ref=(
                    str(payload["bloom_webhook_secret_ref"])
                    if payload["bloom_webhook_secret_ref"] is not None
                    else None
                ),
                bloom_service_user=(
                    str(payload["bloom_service_user"])
                    if payload["bloom_service_user"] is not None
                    else None
                ),
            ),
            actor_id=current_user.sub_uuid,
        )
        flash(request, "Site Bloom integration saved.", "success")
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
    safe_site_id = str(site.euid)
    return RedirectResponse(
        url=_safe_redirect_url(f"/my-organization/sites/{safe_site_id}"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post(
    "/my-organization/storage-policy",
    dependencies=[Depends(require_org_admin), Depends(csrf_protect)],
)
async def my_organization_storage_policy_save(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Create or update organization-level persisted storage policy."""
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.storage_policies import StoragePolicyService, StoragePolicyUpsert

    org_result = OrganizationService(db).get_with_revision_by_uid(current_user.tenant_id)
    if not org_result:
        raise HTTPException(status_code=404, detail="Organization not found")
    organization, _revision = org_result

    form_data = await request.form()
    allowed_classes = [
        token.strip()
        for token in str(form_data.get("allowed_artifact_classes", "")).split(",")
        if token.strip()
    ]

    try:
        StoragePolicyService(db).upsert_org_policy(
            organization_euid=organization.euid,
            data=StoragePolicyUpsert(
                bucket=str(form_data.get("bucket", "")).strip(),
                region=str(form_data.get("region", "")).strip(),
                base_prefix=str(form_data.get("base_prefix", "")).strip(),
                access_mode=str(form_data.get("access_mode", "lsmc_managed")).strip(),
                assume_role_arn=str(form_data.get("assume_role_arn", "")).strip() or None,
                kms_key_arn=str(form_data.get("kms_key_arn", "")).strip() or None,
                allowed_artifact_classes=allowed_classes,
                enabled=str(form_data.get("enabled", "true")).strip().lower()
                in {"1", "true", "yes"},
            ),
            actor_id=current_user.sub_uuid,
        )
        flash(request, "Organization storage policy saved.", "success")
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")

    return RedirectResponse(url="/my-organization", status_code=status.HTTP_303_SEE_OTHER)


@router.post(
    "/my-organization/sites/{site_id}/storage-policy",
    dependencies=[Depends(require_org_admin), Depends(csrf_protect)],
)
async def my_organization_site_storage_policy_save(
    request: Request,
    site_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Create/update/clear a site-level storage-policy override."""
    from app.domain.services.orgs import OrganizationService, SiteService
    from app.domain.services.storage_policies import StoragePolicyService, StoragePolicyUpsert

    org_result = OrganizationService(db).get_with_revision_by_uid(current_user.tenant_id)
    if not org_result:
        raise HTTPException(status_code=404, detail="Organization not found")
    organization, _revision = org_result
    site = SiteService(db).get_by_id(site_id)
    if not site or str(site.organization_id) != str(organization.euid):
        raise HTTPException(status_code=404, detail="Site not found")

    form_data = await request.form()
    action = str(form_data.get("action", "save")).strip().lower()
    service = StoragePolicyService(db)

    try:
        if action == "clear":
            service.clear_site_policy(
                organization_euid=organization.euid,
                site_euid=site_id,
            )
            flash(request, "Site storage override cleared.", "success")
        else:
            allowed_classes = [
                token.strip()
                for token in str(form_data.get("allowed_artifact_classes", "")).split(",")
                if token.strip()
            ]
            service.upsert_site_policy(
                organization_euid=organization.euid,
                site_euid=site_id,
                data=StoragePolicyUpsert(
                    bucket=str(form_data.get("bucket", "")).strip(),
                    region=str(form_data.get("region", "")).strip(),
                    base_prefix=str(form_data.get("base_prefix", "")).strip(),
                    access_mode=str(form_data.get("access_mode", "lsmc_managed")).strip(),
                    assume_role_arn=str(form_data.get("assume_role_arn", "")).strip() or None,
                    kms_key_arn=str(form_data.get("kms_key_arn", "")).strip() or None,
                    allowed_artifact_classes=allowed_classes,
                    enabled=str(form_data.get("enabled", "true")).strip().lower()
                    in {"1", "true", "yes"},
                ),
                actor_id=current_user.sub_uuid,
            )
            flash(request, "Site storage policy override saved.", "success")
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")

    safe_site_id = str(site.euid)
    return RedirectResponse(
        url=_safe_redirect_url(f"/my-organization/sites/{safe_site_id}"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


# --- Org Settings (org admin) ---


@router.get(
    "/my-organization/settings/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(require_org_admin)],
)
async def my_organization_settings_edit_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Show organization settings edit form (org admin only)."""
    from app.domain.services.orgs import OrganizationService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision_by_uid(current_user.tenant_id)

    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    ctx["organization"] = organization
    ctx["revision"] = revision
    return templates.TemplateResponse(request, "my_organization/settings_edit.html", context=ctx)


@router.post(
    "/my-organization/settings/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(require_org_admin), Depends(csrf_protect)],
)
async def my_organization_settings_edit_submit(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Update organization settings (org admin only)."""
    from app.domain.services.orgs import OrganizationService, OrganizationUpdate

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision_by_uid(current_user.tenant_id)

    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    form_data = await request.form()

    try:
        # Org admins cannot toggle is_active — only global admins can
        org_svc.update(
            current_user.tenant_id,
            OrganizationUpdate(
                display_name=form_data.get("display_name") or None,
                contact_email=form_data.get("contact_email") or None,
                contact_phone=form_data.get("contact_phone") or None,
                note=form_data.get("note") or "Updated by org admin",
            ),
            updated_by=current_user.sub_uuid,
        )
        flash(request, "Organization settings updated", "success")
        return RedirectResponse(url="/my-organization", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        ctx["organization"] = organization
        ctx["revision"] = revision
        ctx["error"] = str(e)
        return templates.TemplateResponse(
            request, "my_organization/settings_edit.html", context=ctx
        )


# --- TRFs ---


@router.get("/trfs", response_class=HTMLResponse)
async def orders_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    status_filter: str | None = Query(None, alias="status"),
):
    """TRF list page."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.enums import OrderStatus
    from app.domain.services.people import ClinicianService, PatientService
    from app.domain.services.trfs import TestService, TrfService

    ctx = get_template_context(request, current_user, db)
    ctx["status_filter"] = status_filter

    # Fetch TRFs from service
    order_svc = TrfService(db, current_user.tenant_id)
    patient_svc = PatientService(db, current_user.tenant_id)
    clinician_svc = ClinicianService(db, current_user.tenant_id)
    test_order_svc = TestService(db, current_user.tenant_id)

    # Parse status filter if provided
    status_enum = None
    if status_filter:
        try:
            status_enum = OrderStatus(status_filter)
        except ValueError:
            pass

    # Internal/admin users with CROSS_TENANT_READ see all TRFs
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    orders_data = order_svc.list_trfs(status=status_enum, limit=100, cross_tenant=cross_tenant)

    # Build TRF list with patient names, clinician names, and test counts
    orders = []
    for order, revision in orders_data:
        # Patient is derived from child Order↔Patient links; fall back to legacy TRF patient_id if present.
        patient_name = None
        try:
            from app.domain.enums import OrderPatientRole
            from app.domain.services.order_relationships import OrderRelationshipService

            rel_svc = OrderRelationshipService(db, order.tenant_id)
            test_orders_data = test_order_svc.list_for_trf(order.euid, cross_tenant=cross_tenant)

            # Pick PROBAND if present; else first linked patient.
            proband_id: str | None = None
            first_id: str | None = None
            for to, _to_rev, _assays in test_orders_data:
                links = rel_svc.list_order_patient_links(order_euid=to.euid)
                if not links:
                    continue
                for link in links:
                    if first_id is None:
                        first_id = link.patient_euid
                    if link.role == OrderPatientRole.PROBAND:
                        proband_id = link.patient_euid
                        break
                if proband_id is not None:
                    break

            chosen_patient_id = (
                proband_id or first_id or (revision.patient_id if revision else None)
            )
            if chosen_patient_id:
                patient_result = patient_svc.get_by_id(chosen_patient_id, cross_tenant=cross_tenant)
                if patient_result:
                    _patient, patient_rev = patient_result
                    patient_name = f"{patient_rev.first_name} {patient_rev.last_name}"
        except Exception:
            # Keep list page robust; missing-link data should not break rendering.
            patient_name = None

        clinician_name = None
        if revision and revision.clinician_id:
            clinician_result = clinician_svc.get_by_id(
                revision.clinician_id, cross_tenant=cross_tenant
            )
            if clinician_result:
                _clinician, clinician_rev = clinician_result
                clinician_name = f"{clinician_rev.first_name} {clinician_rev.last_name}"

        # Get child order count
        test_order_count = len(test_order_svc.list_for_trf(order.euid, cross_tenant=cross_tenant))

        orders.append(
            {
                "id": order.euid,
                "order_number": order.order_number,
                "patient_name": patient_name,
                "clinician_name": clinician_name,
                "test_order_count": test_order_count,
                "status": revision.status if revision else "DRAFT",
                "order_type": revision.order_type if revision else "CLINICAL",
                "created_at": order.created_at,
            }
        )

    ctx["orders"] = orders
    return templates.TemplateResponse(request, "trfs/list.html", context=ctx)


@router.get("/trfs/new", response_class=HTMLResponse)
async def orders_create(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """New TRF form."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.people import ClinicianService, PatientService
    from app.domain.services.site_scope import list_tenant_site_options

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)
    site_options = list_tenant_site_options(db, current_user.tenant_id)
    ctx["site_options"] = site_options
    ctx["selected_site_id"] = site_options[0].id if len(site_options) == 1 else None

    # Load patients using service layer (tenant-scoped, optimized)
    try:
        patient_svc = PatientService(db, current_user.tenant_id, current_user.sub_uuid)
        patients_data = patient_svc.list_patients(limit=200, cross_tenant=cross_tenant)
        ctx["patients"] = [
            {
                "id": patient.euid,
                "name": f"{revision.first_name} {revision.last_name}",
                "mrn": revision.mrn,
                "date_of_birth": revision.date_of_birth.isoformat()
                if revision.date_of_birth
                else None,
            }
            for patient, revision in patients_data
        ]
    except Exception as e:
        print(f"Error loading patients: {e}")
        ctx["patients"] = []

    # Load clinicians using service layer (tenant-scoped, optimized)
    try:
        clinician_svc = ClinicianService(db, current_user.tenant_id, current_user.sub_uuid)
        clinicians_data = clinician_svc.list_clinicians(
            limit=200, active_only=True, cross_tenant=cross_tenant
        )
        ctx["clinicians"] = [
            {
                "id": clinician.euid,
                "name": f"{revision.first_name} {revision.last_name}",
                "credentials": revision.credentials,
                "npi": revision.npi,
            }
            for clinician, revision in clinicians_data
        ]
    except Exception as e:
        print(f"Error loading clinicians: {e}")
        ctx["clinicians"] = []

    # Load fulfillment routes from test definitions catalog.
    try:
        from app.domain.services.test_definitions import TestDefinitionService

        test_definition_svc = TestDefinitionService(db)
        test_definitions = test_definition_svc.list_all(active_only=True)
        ctx["fulfillment_routes"] = [
            {
                "code": definition.code,
                "name": definition.name,
                "euid": definition.euid,
            }
            for definition in test_definitions
        ]
    except Exception as e:
        print(f"Error loading fulfillment routes: {e}")
        ctx["fulfillment_routes"] = []

    return templates.TemplateResponse(request, "trfs/create.html", context=ctx)


@router.post("/trfs/new", dependencies=[Depends(csrf_protect)])
async def orders_create_submit(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """Create a new TRF with Tests."""
    from app.domain.enums import OrderPatientRole
    from app.domain.services.order_relationships import OrderPatientLink
    from app.domain.services.people import ClinicianService, PatientService
    from app.domain.services.trfs import (
        TestCreate,
        TrfCreate,
        TrfService,
    )

    try:
        # Parse form data manually to handle test_orders array
        form_data = await request.form()

        # Patient links (new: patients[N][patient_id]/patients[N][role]; legacy: patient_id)
        patient_links: list[OrderPatientLink] = []
        i = 0
        while f"patients[{i}][patient_id]" in form_data:
            pid_raw = form_data.get(f"patients[{i}][patient_id]")
            role_raw = form_data.get(f"patients[{i}][role]") or OrderPatientRole.PROBAND.value
            if pid_raw and str(pid_raw).strip():
                try:
                    patient_links.append(
                        OrderPatientLink(
                            patient_euid=str(pid_raw).strip(),
                            role=OrderPatientRole(str(role_raw)),
                        )
                    )
                except ValueError:
                    flash(request, "Invalid patient or role selected", "error")
                    return RedirectResponse(url="/trfs/new", status_code=status.HTTP_303_SEE_OTHER)
            i += 1

        if not patient_links:
            legacy_patient_id = form_data.get("patient_id")
            if legacy_patient_id and str(legacy_patient_id).strip():
                patient_links = [
                    OrderPatientLink(
                        patient_euid=str(legacy_patient_id).strip(),
                        role=OrderPatientRole.PROBAND,
                    )
                ]

        clinician_id = form_data.get("clinician_id")
        order_type = form_data.get("order_type", "CLINICAL")
        clinical_notes = form_data.get("clinical_notes")
        site_id = (form_data.get("site_id") or "").strip() or None

        if not patient_links:
            flash(request, "At least one patient is required", "error")
            return RedirectResponse(url="/trfs/new", status_code=status.HTTP_303_SEE_OTHER)

        clinician_euid: str | None = str(clinician_id).strip() if clinician_id else None

        patient_svc = PatientService(db, current_user.tenant_id, current_user.sub_uuid)
        for pl in patient_links:
            patient_result = patient_svc.get_by_id(pl.patient_euid)
            if not patient_result:
                flash(request, "Selected patient no longer exists", "error")
                return RedirectResponse(url="/trfs/new", status_code=status.HTTP_303_SEE_OTHER)

        if clinician_euid:
            clinician_svc = ClinicianService(db, current_user.tenant_id, current_user.sub_uuid)
            clinician_result = clinician_svc.get_by_id(clinician_euid)
            if not clinician_result:
                flash(request, "Selected clinician no longer exists", "error")
                return RedirectResponse(url="/trfs/new", status_code=status.HTTP_303_SEE_OTHER)

        # Parse test orders from form (test_orders[0][fulfillment_route_code], ...).
        test_orders_data = []
        i = 0
        while f"test_orders[{i}][fulfillment_route_code]" in form_data:
            route_code = form_data.get(f"test_orders[{i}][fulfillment_route_code]")
            if route_code:
                test_orders_data.append(
                    {
                        "fulfillment_route_code": route_code,
                        "priority": form_data.get(f"test_orders[{i}][priority]", "NORMAL"),
                        "specimen_type": form_data.get(f"test_orders[{i}][specimen_type]", "BLOOD"),
                        "clinical_notes": form_data.get(f"test_orders[{i}][clinical_notes]", ""),
                    }
                )
            i += 1

        # Build child orders ("test orders") from form
        child_orders: list[TestCreate] = []
        for to_data in test_orders_data:
            child_orders.append(
                TestCreate(
                    product_code=to_data["fulfillment_route_code"],
                    fulfillment_route_codes=[to_data["fulfillment_route_code"]],
                    specimen_type_required=to_data["specimen_type"],
                    special_instructions=to_data["clinical_notes"] or None,
                )
            )

        # Create TRF + child orders + patient links (no patient stored on TRF revision)
        svc = TrfService(db, current_user.tenant_id)
        order, revision = svc.create(
            TrfCreate(
                clinician_id=clinician_euid,
                order_type=order_type,
                clinical_notes=clinical_notes,
                site_id=site_id,
            ),
            tests=child_orders,
            patient_links=patient_links,
            created_by=current_user.sub_uuid,
        )

        flash(request, f"TRF {order.euid} created successfully", "success")
        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{_seg(order.euid)}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except Exception as e:
        db.rollback()
        logger.error("Error creating TRF: %s", e, exc_info=True)
        flash(
            request,
            str(e)
            if isinstance(e, ValueError)
            else "An error occurred while creating the TRF. Please try again.",
            "error",
        )
        return RedirectResponse(url="/trfs/new", status_code=status.HTTP_303_SEE_OTHER)


@router.get("/trfs/{trf_euid}", response_class=HTMLResponse)
async def orders_detail(
    request: Request,
    trf_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """TRF detail page keyed by TRF EUID."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.people import ClinicianService, PatientService
    from app.domain.services.trfs import TestService, TrfService

    ctx = get_template_context(request, current_user, db)

    # Internal/admin users with CROSS_TENANT_READ can view TRFs from any tenant
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)

    # Fetch TRF by EUID
    order_svc = TrfService(db, current_user.tenant_id)
    result = order_svc.get_by_id(trf_euid, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"TRF {trf_euid} not found",
        )

    order, revision = result

    # Use the order's tenant_id for fetching related entities
    # (important when viewing a cross-tenant order)
    effective_tenant_id = order.tenant_id

    # Build TRF context
    ctx["order"] = {
        "id": order.euid,
        "euid": order.euid,
        "order_number": order.euid,
        "status": revision.status if revision else "DRAFT",
        "status_class": (revision.status if revision else "DRAFT"),
        "status_chip": _trf_status_label(revision.status if revision else "DRAFT"),
        "status_ui": _order_status_ui_from_db(revision.status if revision else "DRAFT"),
        "order_type": revision.order_type if revision else "CLINICAL",
        "clinical_notes": revision.clinical_notes if revision else None,
        "created_at": order.created_at,
    }
    ctx["order_status_options"] = ORDER_STATUS_OPTIONS

    # Fetch child Tests once; used for patient derivation and UI rendering.
    test_order_svc = TestService(db, effective_tenant_id)
    test_orders_data = test_order_svc.list_for_trf(order.euid, cross_tenant=cross_tenant)

    # Fetch patients (derived from child order ↔ patient links; legacy fallback to TRF revision.patient_id)
    ctx["patient"] = None  # legacy-friendly "primary" patient
    ctx["patients"] = []
    patient_name_by_id: dict[str, str] = {}
    patient_roles: dict[str, set[str]] = {}

    from app.domain.enums import OrderPatientRole
    from app.domain.services.order_relationships import OrderRelationshipService

    rel_svc = OrderRelationshipService(db, effective_tenant_id)
    patient_svc = PatientService(db, effective_tenant_id, current_user.sub_uuid)

    if revision and revision.patient_id:
        # Ensure legacy TRFs still show a patient even if no child orders exist yet.
        patient_roles.setdefault(revision.patient_id, set()).add(OrderPatientRole.PROBAND.value)

    for to, _to_rev, _assays in test_orders_data:
        links = rel_svc.list_order_patient_links(order_euid=to.euid)
        if not links and revision and revision.patient_id:
            # Legacy fallback: TRF stored patient_id directly.
            links = [
                type(
                    "_Link",
                    (),
                    {"patient_euid": revision.patient_id, "role": OrderPatientRole.PROBAND},
                )()
            ]
        for link in links:
            patient_roles.setdefault(link.patient_euid, set()).add(link.role.value)

    for pid, roles in patient_roles.items():
        pres = patient_svc.get_by_id(pid, cross_tenant=cross_tenant)
        if not pres:
            continue
        patient, prev = pres
        name = f"{prev.first_name} {prev.last_name}".strip()
        patient_name_by_id[pid] = name
        ctx["patients"].append(
            {
                "id": patient.euid,
                "name": name,
                "first_name": prev.first_name,
                "last_name": prev.last_name,
                "date_of_birth": prev.date_of_birth,
                "mrn": prev.mrn,
                "sex": prev.sex,
                "roles": sorted(roles),
            }
        )

    # Pick primary patient: PROBAND if present, else first (stable order).
    ctx["patients"].sort(
        key=lambda row: ("PROBAND" not in (row.get("roles") or []), row.get("name") or "")
    )
    if ctx["patients"]:
        primary = ctx["patients"][0]
        ctx["patient"] = {
            "id": primary["id"],
            "first_name": primary["first_name"],
            "last_name": primary["last_name"],
            "date_of_birth": primary["date_of_birth"],
            "mrn": primary["mrn"],
            "sex": primary["sex"],
        }

    # Fetch clinician
    ctx["clinician"] = None
    if revision and revision.clinician_id:
        clinician_svc = ClinicianService(db, effective_tenant_id)
        clinician_result = clinician_svc.get_by_id(revision.clinician_id)
        if clinician_result:
            _clinician, clinician_rev = clinician_result
            ctx["clinician"] = {
                "first_name": clinician_rev.first_name,
                "last_name": clinician_rev.last_name,
                "credentials": clinician_rev.credentials,
            }

    # Fetch organization with latest revision
    ctx["organization"] = None
    org_svc = OrganizationService(db)
    org_result = org_svc.get_with_revision_by_uid(effective_tenant_id)
    if org_result:
        _org, org_rev = org_result
        ctx["organization"] = {"name": org_rev.name if org_rev else "Unknown"}

    # Build child Test context (includes patient role links)
    ctx["test_orders"] = []
    for to, to_rev, _assays in test_orders_data:
        links = rel_svc.list_order_patient_links(order_euid=to.euid)
        if not links and revision and revision.patient_id:
            links = [
                type(
                    "_Link",
                    (),
                    {"patient_euid": revision.patient_id, "role": OrderPatientRole.PROBAND},
                )()
            ]
        ctx["test_orders"].append(
            {
                "id": to.euid,
                "euid": to.euid,
                "product_code": to_rev.product_code if to_rev else None,
                "status": to_rev.status if to_rev else "PENDING",
                "status_ui": _test_order_status_ui_from_db(to_rev.status if to_rev else "PENDING"),
                "status_display": _test_status_label(to_rev.status if to_rev else "PENDING"),
                "fulfillment_route_codes": to_rev.fulfillment_route_codes if to_rev else [],
                "specimen_type": to_rev.specimen_type_required if to_rev else None,
                "clinical_notes": to_rev.special_instructions if to_rev else None,
                "priority": "STAT" if (revision and revision.is_stat) else "NORMAL",
                "patients": [
                    {
                        "id": link.patient_euid,
                        "name": patient_name_by_id.get(link.patient_euid) or link.patient_euid,
                        "role": link.role.value,
                    }
                    for link in links
                ],
                "fulfillment_routes": [
                    {
                        "fulfillment_route_code": code,
                        "fulfillment_route_name": code,
                    }
                    for code in (
                        to_rev.fulfillment_route_codes
                        if to_rev and to_rev.fulfillment_route_codes
                        else []
                    )
                ],
            }
        )
    ctx["test_order_status_options"] = TEST_ORDER_STATUS_OPTIONS

    # Fetch assay runs for this order (Step 8)
    from app.domain.policies.fulfillment_state_machine import (
        ALLOWED_TRANSITIONS,
        FulfillmentRunState,
        is_terminal,
    )
    from app.domain.services.fulfillment_runs import FulfillmentRunService

    assay_runs_data = []
    assay_rows: list[tuple[object, object]] = []
    candidate_tenants: list[uuid.UUID] = []
    for candidate in [order.tenant_id, current_user.tenant_id, uuid.UUID(int=0)]:
        if candidate and candidate not in candidate_tenants:
            candidate_tenants.append(candidate)

    for tenant_candidate in candidate_tenants:
        rows = FulfillmentRunService(db, tenant_candidate).list_for_trf(order.euid)
        if rows:
            assay_rows = rows
            break

    for ar, ar_rev in assay_rows:
        try:
            current_state = FulfillmentRunState(ar_rev.status)
        except ValueError:
            # Keep the page resilient if an unknown status is stored.
            continue
        next_transitions = list(ALLOWED_TRANSITIONS.get(current_state, set()))
        assay_runs_data.append(
            {
                "id": ar.euid,
                "test_order_id": ar.test_order_id,
                "fulfillment_route_code": ar.fulfillment_route_code,
                "status": ar_rev.status,
                "accession_id": ar_rev.accession_id,
                "qc_hold_reason": ar_rev.qc_hold_reason,
                "note": ar_rev.note,
                "revision_no": ar_rev.revision_no,
                "updated_at": ar_rev.created_at.strftime("%Y-%m-%d %H:%M")
                if ar_rev.created_at
                else None,
                "next_transitions": [s.value for s in next_transitions],
                "is_terminal": is_terminal(current_state),
            }
        )

    ctx["assay_runs"] = assay_runs_data

    return templates.TemplateResponse(request, "trfs/detail.html", context=ctx)


@router.get("/trfs/tests/{test_euid}", response_class=HTMLResponse)
async def trf_test_detail(
    request: Request,
    test_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Test detail page keyed by Test EUID."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.external_objects import (
        BloomConfigResolverService,
        ExternalObjectService,
        OrgBloomConfigService,
        SiteBloomConfigService,
    )
    from app.domain.services.order_relationships import OrderRelationshipService
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.people import PatientService
    from app.domain.services.shipments import ShipmentService
    from app.domain.services.trfs import TestService, TrfService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)

    test_svc = TestService(db, current_user.tenant_id)
    test = test_svc.get_by_id(test_euid, cross_tenant=cross_tenant)
    if test is None:
        raise HTTPException(status_code=404, detail=f"Test {test_euid} not found")

    test_rev = test_svc._get_latest_revision(test_euid)  # noqa: SLF001
    if test_rev is None:
        raise HTTPException(status_code=404, detail=f"Test revision not found: {test_euid}")

    trf_result = TrfService(db, test.tenant_id).get_by_id(test.order_id, cross_tenant=cross_tenant)
    if trf_result is None:
        raise HTTPException(status_code=404, detail=f"Parent TRF not found for {test_euid}")
    trf, trf_rev = trf_result

    patient_svc = PatientService(db, test.tenant_id, current_user.sub_uuid)
    relationship_svc = OrderRelationshipService(db, test.tenant_id)
    linked_patients = relationship_svc.list_order_patient_links(order_euid=test.euid)
    patient_name_by_id: dict[str, str] = {}
    patient_rows: list[dict[str, str]] = []
    for link in linked_patients:
        patient_result = patient_svc.get_by_id(link.patient_euid, cross_tenant=cross_tenant)
        if patient_result is None:
            patient_rows.append(
                {"id": link.patient_euid, "name": link.patient_euid, "role": link.role.value}
            )
            continue
        patient_obj, patient_rev = patient_result
        patient_name = f"{patient_rev.first_name} {patient_rev.last_name}".strip()
        patient_name_by_id[patient_obj.euid] = patient_name
        patient_rows.append({"id": patient_obj.euid, "name": patient_name, "role": link.role.value})

    external_svc = ExternalObjectService(db, test.tenant_id)
    linked_materials: list[dict[str, str]] = []
    seen_external_ids: set[str] = set()
    for entity_type in ("Test",):
        for relation in external_svc.list_relations_for_local_entity(entity_type, test.euid):
            if relation.external_object_id in seen_external_ids:
                continue
            seen_external_ids.add(relation.external_object_id)
            ext = external_svc.get_external_object_by_id(relation.external_object_id)
            if ext is None:
                continue
            linked_materials.append(
                {
                    "object_type": ext.object_type,
                    "external_euid": ext.external_euid,
                    "status": ext.status,
                    "relation_type": relation.relation_type,
                }
            )

    available_patients = _list_patient_summaries(db, test.tenant_id)

    shipment_rows: list[dict[str, str]] = []
    for shipment_obj, shipment_rev in ShipmentService(db, test.tenant_id).list_shipments(
        limit=100, cross_tenant=cross_tenant
    ):
        shipment_rows.append(
            {
                "id": shipment_obj.euid,
                "label": shipment_obj.shipment_number,
                "status": shipment_rev.status if shipment_rev else "",
            }
        )

    testkit_rows = _list_testkit_summaries(db, test.tenant_id)

    org_result = OrganizationService(db).get_with_revision_by_uid(test.tenant_id)
    organization = org_result[0] if org_result else None
    site_options = _list_site_summaries(db, organization.euid) if organization else []
    resolver = BloomConfigResolverService(db)
    default_site_id = site_options[0]["id"] if len(site_options) == 1 else None
    effective_bloom_cfg = resolver.get_effective(
        organization_id=test.tenant_id,
        site_id=str(default_site_id) if default_site_id else None,
    )
    ctx["trf"] = {
        "id": trf.euid,
        "euid": trf.euid,
        "number": trf.euid,
        "status": trf_rev.status if trf_rev else "DRAFT",
    }
    ctx["test"] = {
        "id": test.euid,
        "euid": test.euid,
        "status": test_rev.status,
        "status_ui": _test_order_status_ui_from_db(test_rev.status),
        "status_label": _test_status_label(test_rev.status),
        "product_code": test_rev.product_code,
        "product_name": test_rev.product_name,
        "fulfillment_route_codes": test_rev.fulfillment_route_codes,
        "specimen_type": test_rev.specimen_type_required,
        "clinical_notes": test_rev.clinical_notes,
    }
    ctx["linked_patients"] = patient_rows
    ctx["linked_materials"] = linked_materials
    ctx["available_patients"] = available_patients
    ctx["available_shipments"] = shipment_rows
    ctx["available_testkits"] = testkit_rows
    ctx["site_options"] = site_options
    ctx["org_bloom_config"] = OrgBloomConfigService(db).get(test.tenant_id)
    ctx["site_bloom_configs"] = SiteBloomConfigService(db).list_enabled(
        organization_id=test.tenant_id
    )
    ctx["effective_bloom_config"] = effective_bloom_cfg
    ctx["effective_bloom_config_source"] = (
        effective_bloom_cfg.scope if effective_bloom_cfg else None
    )
    ctx["test_order_status_options"] = TEST_ORDER_STATUS_OPTIONS
    ctx.update(
        _build_tube_panel_context(
            db,
            test.tenant_id,
            anchor_type="Test",
            anchor_id=test.euid,
            return_to=f"/trfs/tests/{test.euid}",
        )
    )
    return templates.TemplateResponse(request, "trfs/test_detail.html", context=ctx)


@router.post("/trfs/tests/{test_euid}/patient", dependencies=[Depends(csrf_protect)])
async def trf_test_link_patient(
    request: Request,
    test_euid: str,
    patient_euid: Annotated[str, Form()],
    role: Annotated[str, Form()] = "PROBAND",
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)] = None,
    db: Session = Depends(get_db),
):
    """Link or update a patient on a Test."""
    from app.domain.enums import OrderPatientRole
    from app.domain.services.order_relationships import OrderPatientLink, OrderRelationshipService
    from app.domain.services.trfs import TestService

    cross_tenant = False
    test = TestService(db, current_user.tenant_id).get_by_id(test_euid, cross_tenant=cross_tenant)
    if test is None:
        raise HTTPException(status_code=404, detail=f"Test {test_euid} not found")

    rel_svc = OrderRelationshipService(db, test.tenant_id)
    try:
        linked_patient_euid = patient_euid.strip()
        linked_role = OrderPatientRole(role.strip().upper())
        rel_svc.ensure_order_patient_links(
            order_euid=test_euid,
            links=[
                OrderPatientLink(
                    patient_euid=linked_patient_euid,
                    role=linked_role,
                )
            ],
            replace=False,
        )
        _sync_parent_child_relationships_from_test_roles(
            db=db,
            tenant_id=test.tenant_id,
            test_euid=test_euid,
            linked_patient_euid=linked_patient_euid,
            linked_role=linked_role,
            order_rel_svc=rel_svc,
        )
        db.commit()
        flash(request, "Patient linked to Test.", "success")
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")

    safe_test_id = str(test.euid)
    return RedirectResponse(url=_safe_redirect_url(f"/trfs/tests/{safe_test_id}"), status_code=303)


@router.post("/trfs/tests/{test_euid}/request-material", dependencies=[Depends(csrf_protect)])
async def trf_test_request_material(
    request: Request,
    test_euid: str,
    patient_euid: Annotated[str | None, Form()] = None,
    shipment_euid: Annotated[str | None, Form()] = None,
    testkit_euid: Annotated[str | None, Form()] = None,
    site_euid: Annotated[str | None, Form()] = None,
    collection_site_euid: Annotated[str | None, Form()] = None,
    collected_at: Annotated[str | None, Form()] = None,
    collection_type: Annotated[str | None, Form()] = None,
    collected_by: Annotated[str | None, Form()] = None,
    expected_mrn: Annotated[str | None, Form()] = None,
    expected_dob: Annotated[str | None, Form()] = None,
    expected_name: Annotated[str | None, Form()] = None,
    expected_label_text: Annotated[str | None, Form()] = None,
    origin_site_id: Annotated[str | None, Form()] = None,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)] = None,
    db: Session = Depends(get_db),
):
    """Create a Bloom tube for a Test with optional specimen creation."""
    from app.domain.services.bloom_bridge import (
        ContainerSpecimenBridgeService,
        TubeCreationRequest,
    )
    from app.domain.services.trfs import TestService

    test = TestService(db, current_user.tenant_id).get_by_id(test_euid, cross_tenant=False)
    if test is None:
        raise HTTPException(status_code=404, detail=f"Test {test_euid} not found")

    if test.tenant_id != current_user.tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Cross-tenant write forbidden"
        )

    patient_euid = (patient_euid or "").strip() or None
    shipment_euid = (shipment_euid or "").strip() or None
    testkit_euid = (testkit_euid or "").strip() or None
    site_euid = (site_euid or "").strip() or None
    collection_site_euid = (collection_site_euid or "").strip() or None
    collected_at_dt = (
        datetime.fromisoformat(collected_at.strip())
        if collected_at and collected_at.strip()
        else None
    )

    request_key = (
        f"atlas:bloom-tube:{test_euid}:{patient_euid or 'none'}:"
        f"{shipment_euid or 'none'}:{testkit_euid or 'none'}:{site_euid or 'none'}"
    )

    svc = ContainerSpecimenBridgeService(db, test.tenant_id)
    try:
        result = svc.create_tube_with_optional_specimen(
            TubeCreationRequest(
                test_euid=test.euid,
                patient_euid=patient_euid,
                shipment_euid=shipment_euid,
                testkit_euid=testkit_euid,
                site_euid=site_euid,
                collection_site_euid=collection_site_euid,
                collected_at=collected_at_dt,
                collection_type=(collection_type or "").strip() or None,
                collected_by=(collected_by or "").strip() or None,
                expected_mrn=(expected_mrn or "").strip() or None,
                expected_dob=(expected_dob or "").strip() or None,
                expected_name=(expected_name or "").strip() or None,
                expected_label_text=(expected_label_text or "").strip() or None,
                origin_site_id=(origin_site_id or "").strip() or None,
                idempotency_key=request_key,
            ),
            actor_id=current_user.sub_uuid,
        )
        db.commit()
        if result.specimen_euid:
            flash(request, "Bloom tube and specimen created.", "success")
        else:
            flash(request, "Bloom tube created.", "success")
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")

    safe_test_id = str(test.euid)
    return RedirectResponse(url=_safe_redirect_url(f"/trfs/tests/{safe_test_id}"), status_code=303)


@router.get("/tubes/{container_euid}", response_class=HTMLResponse)
async def tubes_detail(
    request: Request,
    container_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Dedicated Bloom tube detail page."""
    ctx = get_template_context(request, current_user, db)
    tube = _tube_detail_context(db, current_user.tenant_id, container_euid)
    ctx["tube"] = tube
    ctx["tube_test_options"] = _list_tenant_test_summaries(db, current_user.tenant_id)
    ctx["tube_shipment_options"] = _list_shipment_summaries(db, current_user.tenant_id)
    ctx["tube_testkit_options"] = _list_testkit_summaries(db, current_user.tenant_id)
    ctx["tube_patient_options"] = _list_patient_summaries(db, current_user.tenant_id)
    from app.domain.services.site_scope import list_tenant_site_options

    ctx["tube_site_options"] = list_tenant_site_options(db, current_user.tenant_id)
    ctx["collection_events"] = _list_collection_event_summaries(
        db, current_user.tenant_id, container_euid=container_euid
    )
    return templates.TemplateResponse(request, "tubes/detail.html", context=ctx)


@router.post("/tubes/create", dependencies=[Depends(csrf_protect)])
async def tubes_create(
    request: Request,
    test_euid: Annotated[str | None, Form()] = None,
    shipment_euid: Annotated[str | None, Form()] = None,
    testkit_euid: Annotated[str | None, Form()] = None,
    site_euid: Annotated[str | None, Form()] = None,
    patient_euid: Annotated[str | None, Form()] = None,
    collection_site_euid: Annotated[str | None, Form()] = None,
    collected_at: Annotated[str | None, Form()] = None,
    collection_type: Annotated[str | None, Form()] = None,
    collected_by: Annotated[str | None, Form()] = None,
    expected_mrn: Annotated[str | None, Form()] = None,
    expected_dob: Annotated[str | None, Form()] = None,
    expected_name: Annotated[str | None, Form()] = None,
    expected_label_text: Annotated[str | None, Form()] = None,
    return_to: Annotated[str | None, Form()] = None,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)] = None,
    db: Session = Depends(get_db),
):
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest

    _safe_redirect_url(return_to or "/")  # validate but unused; redirect is per-branch below
    bridge = ContainerSpecimenBridgeService(db, current_user.tenant_id)
    try:
        collected_at_dt = (
            datetime.fromisoformat(collected_at.strip())
            if collected_at and collected_at.strip()
            else None
        )
        result = bridge.create_tube_with_optional_specimen(
            TubeCreationRequest(
                test_euid=(test_euid or "").strip() or None,
                shipment_euid=(shipment_euid or "").strip() or None,
                testkit_euid=(testkit_euid or "").strip() or None,
                site_euid=(site_euid or "").strip() or None,
                patient_euid=(patient_euid or "").strip() or None,
                collection_site_euid=(collection_site_euid or "").strip() or None,
                collected_at=collected_at_dt,
                collection_type=(collection_type or "").strip() or None,
                collected_by=(collected_by or "").strip() or None,
                expected_mrn=(expected_mrn or "").strip() or None,
                expected_dob=(expected_dob or "").strip() or None,
                expected_name=(expected_name or "").strip() or None,
                expected_label_text=(expected_label_text or "").strip() or None,
                idempotency_key=f"atlas:tube:create:{uuid.uuid4().hex}",
            ),
            actor_id=current_user.sub_uuid,
        )
        db.commit()
        flash(request, "Tube saved.", "success")
        safe_container_id = str(result.container_euid)
        return RedirectResponse(
            url=_safe_redirect_url(f"/tubes/{safe_container_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
        return RedirectResponse(url="/tubes", status_code=status.HTTP_303_SEE_OTHER)


@router.post("/tubes/{container_euid}/fill", dependencies=[Depends(csrf_protect)])
async def tubes_fill(
    request: Request,
    container_euid: str,
    patient_euid: Annotated[str, Form()],
    collection_site_euid: Annotated[str, Form()],
    test_euid: Annotated[str | None, Form()] = None,
    shipment_euid: Annotated[str | None, Form()] = None,
    testkit_euid: Annotated[str | None, Form()] = None,
    site_euid: Annotated[str | None, Form()] = None,
    collected_at: Annotated[str | None, Form()] = None,
    collection_type: Annotated[str | None, Form()] = None,
    collected_by: Annotated[str | None, Form()] = None,
    expected_mrn: Annotated[str | None, Form()] = None,
    expected_dob: Annotated[str | None, Form()] = None,
    expected_name: Annotated[str | None, Form()] = None,
    expected_label_text: Annotated[str | None, Form()] = None,
    return_to: Annotated[str | None, Form()] = None,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)] = None,
    db: Session = Depends(get_db),
):
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest
    from app.domain.services.external_objects import ExternalObjectService

    ext_svc = ExternalObjectService(db, current_user.tenant_id)
    container = ext_svc.get_external_object("bloom", "container", container_euid)
    if not container:
        raise HTTPException(status_code=404, detail="Tube not found")
    safe_container_id = str(container.external_euid)
    redirect_url = _safe_redirect_url(f"/tubes/{safe_container_id}")
    bridge = ContainerSpecimenBridgeService(db, current_user.tenant_id)
    try:
        collected_at_dt = (
            datetime.fromisoformat(collected_at.strip())
            if collected_at and collected_at.strip()
            else None
        )
        bridge.fill_tube(
            TubeCreationRequest(
                container_euid=container_euid,
                patient_euid=patient_euid.strip(),
                collection_site_euid=collection_site_euid.strip(),
                test_euid=(test_euid or "").strip() or None,
                shipment_euid=(shipment_euid or "").strip() or None,
                testkit_euid=(testkit_euid or "").strip() or None,
                site_euid=(site_euid or "").strip() or None,
                collected_at=collected_at_dt,
                collection_type=(collection_type or "").strip() or None,
                collected_by=(collected_by or "").strip() or None,
                expected_mrn=(expected_mrn or "").strip() or None,
                expected_dob=(expected_dob or "").strip() or None,
                expected_name=(expected_name or "").strip() or None,
                expected_label_text=(expected_label_text or "").strip() or None,
                idempotency_key=f"atlas:tube:fill:{container_euid}:{uuid.uuid4().hex}",
            ),
            actor_id=current_user.sub_uuid,
        )
        db.commit()
        flash(request, "Tube filled and collection event created.", "success")
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
    return RedirectResponse(
        url=_safe_redirect_url(redirect_url), status_code=status.HTTP_303_SEE_OTHER
    )


@router.post("/tubes/{container_euid}/update", dependencies=[Depends(csrf_protect)])
async def tubes_update(
    request: Request,
    container_euid: str,
    test_euid: Annotated[str | None, Form()] = None,
    shipment_euid: Annotated[str | None, Form()] = None,
    testkit_euid: Annotated[str | None, Form()] = None,
    site_euid: Annotated[str | None, Form()] = None,
    status_value: Annotated[str | None, Form(alias="status")] = None,
    return_to: Annotated[str | None, Form()] = None,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)] = None,
    db: Session = Depends(get_db),
):
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService
    from app.domain.services.external_objects import ExternalObjectService

    ext_svc = ExternalObjectService(db, current_user.tenant_id)
    container = ext_svc.get_external_object("bloom", "container", container_euid)
    if not container:
        raise HTTPException(status_code=404, detail="Tube not found")
    safe_container_id = str(container.external_euid)
    redirect_url = _safe_redirect_url(f"/tubes/{safe_container_id}")
    bridge = ContainerSpecimenBridgeService(db, current_user.tenant_id)
    try:
        bridge.update_tube(
            container_euid=container_euid,
            test_euid=(test_euid or "").strip() or None,
            shipment_euid=(shipment_euid or "").strip() or None,
            testkit_euid=(testkit_euid or "").strip() or None,
            site_euid=(site_euid or "").strip() or None,
            status=(status_value or "").strip() or None,
            actor_id=current_user.sub_uuid,
        )
        db.commit()
        flash(request, "Tube updated.", "success")
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
    return RedirectResponse(
        url=_safe_redirect_url(redirect_url), status_code=status.HTTP_303_SEE_OTHER
    )


@router.get("/collection-events", response_class=HTMLResponse)
async def collection_events_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Collection event list page."""
    ctx = get_template_context(request, current_user, db)
    ctx["collection_events"] = _list_collection_event_summaries(db, current_user.tenant_id)
    return templates.TemplateResponse(request, "collection_events/list.html", context=ctx)


@router.get("/collection-events/{collection_event_id}", response_class=HTMLResponse)
async def collection_events_detail(
    request: Request,
    collection_event_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Collection event detail page."""
    from app.domain.services.collection_events import CollectionEventService

    ctx = get_template_context(request, current_user, db)
    event = CollectionEventService(db, current_user.tenant_id).get(collection_event_id)
    if event is None:
        raise HTTPException(status_code=404, detail="Collection event not found")
    event_obj, revision = event
    ctx["collection_event"] = {
        "id": event_obj.euid,
        "patient_euid": event_obj.patient_id,
        "site_euid": event_obj.site_id,
        "container_euid": event_obj.container_euid,
        "specimen_euid": event_obj.specimen_euid,
        "collected_at": revision.collected_at,
        "collection_type": revision.collection_type,
        "collected_by": revision.collected_by,
        "expected_mrn": revision.expected_mrn,
        "expected_dob": revision.expected_dob,
        "expected_name": revision.expected_name,
        "expected_label_text": revision.expected_label_text,
    }
    return templates.TemplateResponse(request, "collection_events/detail.html", context=ctx)


@router.get("/collection-events/{collection_event_id}/edit", response_class=HTMLResponse)
async def collection_events_edit_form(
    request: Request,
    collection_event_id: str,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """Collection event edit page."""
    from app.domain.services.collection_events import CollectionEventService
    from app.domain.services.site_scope import list_tenant_site_options

    ctx = get_template_context(request, current_user, db)
    event = CollectionEventService(db, current_user.tenant_id).get(collection_event_id)
    if event is None:
        raise HTTPException(status_code=404, detail="Collection event not found")
    event_obj, revision = event
    ctx["collection_event"] = {
        "id": event_obj.euid,
        "site_euid": event_obj.site_id,
        "container_euid": event_obj.container_euid,
        "collected_at": revision.collected_at.isoformat() if revision.collected_at else "",
        "collection_type": revision.collection_type or "",
        "collected_by": revision.collected_by or "",
        "expected_mrn": revision.expected_mrn or "",
        "expected_dob": revision.expected_dob or "",
        "expected_name": revision.expected_name or "",
        "expected_label_text": revision.expected_label_text or "",
    }
    ctx["site_options"] = list_tenant_site_options(db, current_user.tenant_id)
    return templates.TemplateResponse(request, "collection_events/edit.html", context=ctx)


@router.post("/collection-events/{collection_event_id}/edit", dependencies=[Depends(csrf_protect)])
async def collection_events_edit_submit(
    request: Request,
    collection_event_id: str,
    site_euid: Annotated[str | None, Form()] = None,
    collected_at: Annotated[str | None, Form()] = None,
    collection_type: Annotated[str | None, Form()] = None,
    collected_by: Annotated[str | None, Form()] = None,
    expected_mrn: Annotated[str | None, Form()] = None,
    expected_dob: Annotated[str | None, Form()] = None,
    expected_name: Annotated[str | None, Form()] = None,
    expected_label_text: Annotated[str | None, Form()] = None,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)] = None,
    db: Session = Depends(get_db),
):
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService
    from app.domain.services.collection_events import CollectionEventService, CollectionEventUpdate

    svc = CollectionEventService(db, current_user.tenant_id)
    current = svc.get(collection_event_id)
    if current is None:
        raise HTTPException(status_code=404, detail="Collection event not found")

    safe_event_id = str(current[0].euid)
    if site_euid and site_euid.strip() and site_euid.strip() != current[0].site_id:
        flash(
            request,
            "Collection event site is immutable after creation. Update the tube direct site separately.",
            "error",
        )
        return RedirectResponse(
            url=_safe_redirect_url(f"/collection-events/{safe_event_id}/edit"),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    try:
        collected_at_dt = (
            datetime.fromisoformat(collected_at.strip())
            if collected_at and collected_at.strip()
            else None
        )
        svc.update(
            collection_event_id,
            CollectionEventUpdate(
                collected_at=collected_at_dt,
                collection_type=(collection_type or "").strip() or None,
                collected_by=(collected_by or "").strip() or None,
                expected_mrn=(expected_mrn or "").strip() or None,
                expected_dob=(expected_dob or "").strip() or None,
                expected_name=(expected_name or "").strip() or None,
                expected_label_text=(expected_label_text or "").strip() or None,
                note="collection event updated",
            ),
            updated_by=current_user.sub_uuid,
        )
        ContainerSpecimenBridgeService(db, current_user.tenant_id).sync_collection_event_snapshot(
            collection_event_id=collection_event_id,
            actor_id=current_user.sub_uuid,
        )
        db.commit()
        flash(request, "Collection event updated.", "success")
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
        return RedirectResponse(
            url=_safe_redirect_url(f"/collection-events/{safe_event_id}/edit"),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    return RedirectResponse(
        url=_safe_redirect_url(f"/collection-events/{safe_event_id}"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/trfs/{trf_euid}/status", dependencies=[Depends(csrf_protect)])
async def orders_change_status(
    request: Request,
    trf_euid: str,
    status_value: Annotated[str, Form(alias="status")],
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """Change TRF status from the detail page."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.enums import OrderStatus
    from app.domain.services.trfs import TrfService

    try:
        cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
        initial_svc = TrfService(db, current_user.tenant_id)
        result = initial_svc.get_by_id(trf_euid, cross_tenant=cross_tenant)
        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"TRF {trf_euid} not found",
            )
        order, _revision = result
        safe_order_id = str(order.euid)

        requested_status = (status_value or "").strip().upper()
        mapped_status = ORDER_STATUS_UI_TO_DB.get(requested_status)
        if not mapped_status:
            flash(request, "Invalid TRF status selected.", "error")
            return RedirectResponse(
                url=_safe_redirect_url(f"/trfs/{safe_order_id}"),
                status_code=status.HTTP_303_SEE_OTHER,
            )

        target_status = OrderStatus(mapped_status)
        effective_svc = TrfService(db, order.tenant_id)
        updated = effective_svc.change_status(
            order.euid,
            target_status,
            reason=f"TRF status changed to {requested_status.lower()} via UI",
            updated_by=current_user.sub_uuid,
            cross_tenant=cross_tenant,
        )
        if not updated:
            flash(request, "Unable to update TRF status.", "error")
            return RedirectResponse(
                url=_safe_redirect_url(f"/trfs/{safe_order_id}"),
                status_code=status.HTTP_303_SEE_OTHER,
            )

        flash(request, "TRF status updated.", "success")
        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{safe_order_id}"), status_code=status.HTTP_303_SEE_OTHER
        )

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(
            "Error changing TRF status for %s: %s", trf_euid.replace("\n", ""), e, exc_info=True
        )
        flash(request, "Unable to update TRF status. Please try again.", "error")
        return RedirectResponse(url="/trfs", status_code=status.HTTP_303_SEE_OTHER)


@router.post(
    "/trfs/tests/{test_order_id}/status",
    dependencies=[Depends(csrf_protect)],
)
async def orders_test_order_change_status(
    request: Request,
    test_order_id: str,
    status_value: Annotated[str, Form(alias="status")],
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """Change Test status from the TRF/Test detail pages."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.enums import TestOrderStatus
    from app.domain.services.trfs import TestService, TrfService

    try:
        cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
        test_svc = TestService(db, current_user.tenant_id)
        test_order = test_svc.get_by_id(test_order_id, cross_tenant=cross_tenant)
        if not test_order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Test {test_order_id} not found",
            )
        trf_svc = TrfService(db, test_order.tenant_id)
        trf_result = trf_svc.get_by_id(test_order.order_id, cross_tenant=cross_tenant)
        if not trf_result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Parent TRF not found for test {test_order_id}",
            )
        order, _revision = trf_result
        safe_order_id = str(order.euid)

        requested_status = (status_value or "").strip().upper()
        mapped_status = TEST_ORDER_STATUS_UI_TO_DB.get(requested_status)
        if not mapped_status:
            flash(request, "Invalid test status selected.", "error")
            return RedirectResponse(
                url=_safe_redirect_url(f"/trfs/{safe_order_id}"), status_code=303
            )

        target_status = TestOrderStatus(mapped_status)
        updated = test_svc.change_status(
            test_order_id,
            target_status,
            reason=f"Test status changed to {requested_status.lower()} via UI",
            updated_by=current_user.sub_uuid,
            cross_tenant=cross_tenant,
        )
        if not updated:
            flash(request, "Unable to update test status.", "error")
            return RedirectResponse(
                url=_safe_redirect_url(f"/trfs/{safe_order_id}"),
                status_code=status.HTTP_303_SEE_OTHER,
            )

        flash(request, "Test status updated.", "success")
        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{safe_order_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(
            "Error changing test status for %s: %s",
            test_order_id.replace("\n", ""),
            e,
            exc_info=True,
        )
        flash(request, "Unable to update test status. Please try again.", "error")
        return RedirectResponse(
            url=_safe_redirect_url(request.headers.get("referer") or "/trfs"),
            status_code=status.HTTP_303_SEE_OTHER,
        )


@router.post(
    "/trfs/{trf_euid}/transition-all",
    dependencies=[Depends(csrf_protect), Depends(require_internal)],
)
async def orders_transition_all(
    request: Request,
    trf_euid: str,
    next_state: Annotated[str, Form()],
    note: Annotated[str | None, Form()] = None,
    qc_hold_reason: Annotated[str | None, Form()] = None,
    qc_override: Annotated[str | None, Form()] = None,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)] = None,
    db: Session = Depends(get_db),
):
    """Transition all eligible assay runs to a new state.

    For each assay run that can validly transition to the target state,
    performs the transition. Skips assay runs that cannot make the transition.
    Recomputes TRF rollup after all transitions.
    """
    from app.auth.rbac import Permission, has_permission
    from app.domain.enums import FulfillmentRunState
    from app.domain.policies.fulfillment_state_machine import ALLOWED_TRANSITIONS
    from app.domain.services.fulfillment_runs import FulfillmentRunService, TransitionData
    from app.domain.services.trfs import TrfService

    try:
        # Verify TRF exists (internal users can access cross-tenant TRFs)
        order_svc = TrfService(db, current_user.tenant_id)
        cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
        result = order_svc.get_by_id(trf_euid, cross_tenant=cross_tenant)
        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"TRF {trf_euid} not found",
            )
        order, _ = result
        safe_order_id = str(order.euid)

        # Parse the target state
        try:
            target_state = FulfillmentRunState(next_state)
        except ValueError:
            logger.warning("Invalid assay state requested: %s", next_state.replace("\n", ""))
            flash(request, "Invalid state transition requested.", "error")
            return RedirectResponse(
                url=_safe_redirect_url(f"/trfs/{safe_order_id}"),
                status_code=status.HTTP_303_SEE_OTHER,
            )

        # Resolve the assay service tenant with fallback to current user tenant.
        effective_tenant_id = order.tenant_id
        assay_svc = FulfillmentRunService(db, effective_tenant_id)
        assay_runs = assay_svc.list_for_trf(order.euid)
        if not assay_runs and current_user.tenant_id != effective_tenant_id:
            effective_tenant_id = current_user.tenant_id
            assay_svc = FulfillmentRunService(db, effective_tenant_id)
            assay_runs = assay_svc.list_for_trf(order.euid)
        if not assay_runs and effective_tenant_id != uuid.UUID(int=0):
            effective_tenant_id = uuid.UUID(int=0)
            assay_svc = FulfillmentRunService(db, effective_tenant_id)
            assay_runs = assay_svc.list_for_trf(order.euid)

        # Transition all eligible assay runs.
        transitioned = 0
        skipped = 0

        for ar, ar_rev in assay_runs:
            current_state = FulfillmentRunState(ar_rev.status)
            allowed = ALLOWED_TRANSITIONS.get(current_state, set())
            if target_state in allowed:
                assay_svc.transition(
                    ar.euid,
                    TransitionData(
                        target_state=target_state,
                        qc_hold_reason=qc_hold_reason
                        if target_state == FulfillmentRunState.QC_HOLD
                        else None,
                        qc_override=(qc_override == "true"),
                        note=note,
                    ),
                    transition_by=current_user.sub_uuid,
                )
                transitioned += 1
            else:
                skipped += 1

        db.commit()

        if transitioned > 0:
            msg = f"{transitioned} assay run(s) transitioned to {next_state}"
            if skipped > 0:
                msg += f" ({skipped} skipped — not eligible)"
            flash(request, msg, "success")
        else:
            flash(request, f"No assay runs could be transitioned to {next_state}", "warning")

        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{safe_order_id}"), status_code=status.HTTP_303_SEE_OTHER
        )

    except ValueError as e:
        db.rollback()
        logger.error("Transition error: %s", e, exc_info=True)
        flash(request, "Unable to complete the state transition. Please try again.", "error")
        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{safe_order_id}"), status_code=status.HTTP_303_SEE_OTHER
        )
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error("Error transitioning assay runs: %s", e, exc_info=True)
        flash(request, "Unable to complete the state transition. Please try again.", "error")
        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{safe_order_id}"), status_code=status.HTTP_303_SEE_OTHER
        )


@router.post(
    "/trfs/{trf_euid}/fulfillment-runs/{fulfillment_run_euid}/transition",
    dependencies=[Depends(csrf_protect), Depends(require_internal)],
)
async def orders_assay_run_transition(
    request: Request,
    trf_euid: str,
    fulfillment_run_euid: str,
    next_state: Annotated[str, Form()],
    qc_hold_reason: Annotated[str | None, Form()] = None,
    qc_override: Annotated[str | None, Form()] = None,
    note: Annotated[str | None, Form()] = None,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)] = None,
    db: Session = Depends(get_db),
):
    """Transition an assay run to a new state (internal only, Step 8.2)."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.enums import FulfillmentRunState
    from app.domain.services.fulfillment_runs import FulfillmentRunService, TransitionData
    from app.domain.services.trfs import TrfService

    try:
        # Verify TRF exists (internal users can access cross-tenant TRFs)
        order_svc = TrfService(db, current_user.tenant_id)
        cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
        result = order_svc.get_by_id(trf_euid, cross_tenant=cross_tenant)
        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"TRF {trf_euid} not found",
            )
        order, _ = result
        safe_order_id = str(order.euid)

        # Parse the target state
        try:
            target_state = FulfillmentRunState(next_state)
        except ValueError:
            logger.warning("Invalid assay state requested: %s", next_state.replace("\n", ""))
            flash(request, "Invalid state transition requested.", "error")
            return RedirectResponse(
                url=_safe_redirect_url(f"/trfs/{safe_order_id}"),
                status_code=status.HTTP_303_SEE_OTHER,
            )

        # Resolve the assay service tenant with fallback to current user tenant.
        effective_tenant_id = order.tenant_id
        assay_svc = FulfillmentRunService(db, effective_tenant_id)
        if not assay_svc.list_for_trf(order.euid) and current_user.tenant_id != effective_tenant_id:
            effective_tenant_id = current_user.tenant_id
            assay_svc = FulfillmentRunService(db, effective_tenant_id)
        if not assay_svc.list_for_trf(order.euid) and effective_tenant_id != uuid.UUID(int=0):
            effective_tenant_id = uuid.UUID(int=0)
            assay_svc = FulfillmentRunService(db, effective_tenant_id)

        # Transition the assay run.
        assay_svc.transition(
            fulfillment_run_euid,
            TransitionData(
                target_state=target_state,
                qc_hold_reason=qc_hold_reason,
                qc_override=qc_override == "true",
                note=note,
            ),
            transition_by=current_user.sub_uuid,
        )

        db.commit()

        flash(request, f"Test run transitioned to {next_state}", "success")
        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{safe_order_id}"), status_code=status.HTTP_303_SEE_OTHER
        )

    except ValueError as e:
        db.rollback()
        logger.error("Transition error: %s", e, exc_info=True)
        flash(request, "Unable to complete the state transition. Please try again.", "error")
        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{safe_order_id}"), status_code=status.HTTP_303_SEE_OTHER
        )
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error("Error transitioning assay run: %s", e, exc_info=True)
        flash(request, "Unable to complete the state transition. Please try again.", "error")
        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{safe_order_id}"), status_code=status.HTTP_303_SEE_OTHER
        )


@router.get("/trfs/{trf_euid}/edit", response_class=HTMLResponse)
async def orders_edit_form(
    request: Request,
    trf_euid: str,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """Edit order form."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.people import ClinicianService, PatientService
    from app.domain.services.site_scope import list_tenant_site_options
    from app.domain.services.trfs import TestService, TrfService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)

    # Fetch TRF
    order_svc = TrfService(db, current_user.tenant_id)
    result = order_svc.get_by_id(trf_euid, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"TRF {trf_euid} not found",
        )

    order, revision = result
    safe_order_id = str(order.euid)

    if revision.status != "DRAFT":
        flash(request, f"TRF {trf_euid} cannot be edited (status: {revision.status})", "error")
        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{safe_order_id}"), status_code=status.HTTP_303_SEE_OTHER
        )

    # Build order context.
    # Derive patient links from child order graph edges; keep legacy TRF patient fallback read-only.
    derived_patient_id: str | None = (
        str(revision.patient_id) if revision and revision.patient_id else None
    )
    patient_links_ctx: list[dict[str, str]] = []
    try:
        from app.domain.enums import OrderPatientRole
        from app.domain.services.order_relationships import OrderRelationshipService

        rel_svc = OrderRelationshipService(db, order.tenant_id)
        test_order_svc_tmp = TestService(db, current_user.tenant_id)
        for to, _to_rev, _assays in test_order_svc_tmp.list_for_trf(
            order.euid, cross_tenant=cross_tenant
        ):
            links = rel_svc.list_order_patient_links(order_euid=to.euid)
            if not links:
                continue
            patient_links_ctx = [
                {"patient_id": str(link.patient_euid), "role": str(link.role.value)}
                for link in links
            ]
            proband = next(
                (link.patient_euid for link in links if link.role == OrderPatientRole.PROBAND),
                None,
            )
            derived_patient_id = proband or links[0].patient_euid
            break
        if not patient_links_ctx and derived_patient_id:
            patient_links_ctx = [
                {
                    "patient_id": str(derived_patient_id),
                    "role": str(OrderPatientRole.PROBAND.value),
                }
            ]
    except Exception:
        derived_patient_id = revision.patient_id if revision else None
        patient_links_ctx = (
            [{"patient_id": str(derived_patient_id), "role": "PROBAND"}]
            if derived_patient_id
            else []
        )

    ctx["order"] = {
        "id": order.euid,
        "order_number": order.euid,
        "status": revision.status if revision else "DRAFT",
        "order_type": revision.order_type if revision else "CLINICAL",
        "clinical_notes": revision.clinical_notes if revision else None,
        "patient_id": str(derived_patient_id) if derived_patient_id else None,
        "clinician_id": str(revision.clinician_id) if revision and revision.clinician_id else None,
        "site_id": getattr(order, "site_id", None),
    }
    ctx["patient_links"] = patient_links_ctx

    # Fetch test orders for this order
    test_order_svc = TestService(db, current_user.tenant_id)
    test_orders_data = test_order_svc.list_for_trf(order.euid, cross_tenant=cross_tenant)
    ctx["existing_test_orders"] = [
        {
            "id": to.euid,
            "fulfillment_route_code": to_rev.product_code if to_rev else None,
            "specimen_type": to_rev.specimen_type_required if to_rev else "BLOOD",
            "clinical_notes": to_rev.special_instructions if to_rev else "",
        }
        for to, to_rev, _assays in test_orders_data
    ]

    # Load patients
    patient_svc = PatientService(db, current_user.tenant_id)
    patients_data = patient_svc.list_patients(limit=200, cross_tenant=False)
    ctx["patients"] = [
        {
            "id": patient.euid,
            "name": f"{rev.first_name} {rev.last_name}",
            "dob": rev.date_of_birth.isoformat() if rev.date_of_birth else None,
        }
        for patient, rev in patients_data
    ]

    # Load clinicians
    clinician_svc = ClinicianService(db, current_user.tenant_id, current_user.sub_uuid)
    clinicians_data = clinician_svc.list_clinicians(
        limit=200, active_only=True, cross_tenant=cross_tenant
    )
    ctx["clinicians"] = [
        {
            "id": clinician.euid,
            "name": f"{rev.first_name} {rev.last_name}",
            "credentials": rev.credentials,
        }
        for clinician, rev in clinicians_data
    ]

    ctx["fulfillment_routes"] = [
        {"code": "WGS", "name": "Whole Genome Sequencing"},
        {"code": "WES", "name": "Whole Exome Sequencing"},
        {"code": "RNA", "name": "RNA Sequencing"},
        {"code": "PANEL", "name": "Targeted Gene Panel"},
    ]
    site_options = list_tenant_site_options(db, order.tenant_id)
    ctx["site_options"] = site_options
    ctx["selected_site_id"] = (ctx["order"]["site_id"] if ctx["order"]["site_id"] else None) or (
        site_options[0].id if len(site_options) == 1 else None
    )

    return templates.TemplateResponse(request, "trfs/edit.html", context=ctx)


@router.post("/trfs/{trf_euid}/edit", dependencies=[Depends(csrf_protect)])
async def orders_edit_submit(
    request: Request,
    trf_euid: str,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """Update an existing order."""
    from app.domain.services.trfs import (
        TestCreate,
        TestService,
        TrfService,
        TrfUpdate,
    )

    try:
        from app.auth.rbac import Permission, has_permission

        cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
        form_data = await request.form()
        patient_id = form_data.get("patient_id")  # legacy
        clinician_id = form_data.get("clinician_id")
        order_type = form_data.get("order_type", "CLINICAL")
        clinical_notes = form_data.get("clinical_notes")
        site_id = (form_data.get("site_id") or "").strip() or None

        # Fetch TRF
        svc = TrfService(db, current_user.tenant_id)
        result = svc.get_by_id(trf_euid, cross_tenant=cross_tenant)

        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"TRF {trf_euid} not found",
            )

        order, revision = result
        safe_order_id = str(order.euid)

        if revision.status != "DRAFT":
            flash(request, f"TRF {trf_euid} cannot be edited", "error")
            return RedirectResponse(
                url=_safe_redirect_url(f"/trfs/{safe_order_id}"),
                status_code=status.HTTP_303_SEE_OTHER,
            )

        # Update TRF (no patient stored on TRF revision)
        svc.update(
            order.euid,
            TrfUpdate(
                clinician_id=clinician_id if clinician_id else None,
                order_type=order_type,
                clinical_notes=clinical_notes,
                site_id=site_id,
            ),
            updated_by=current_user.sub_uuid,
            cross_tenant=cross_tenant,
        )

        # Patient links (preferred: patients[N][patient_id]/patients[N][role]; legacy: patient_id)
        patient_links: list[object] = []
        try:
            from app.domain.enums import OrderPatientRole
            from app.domain.services.order_relationships import OrderPatientLink

            i = 0
            while f"patients[{i}][patient_id]" in form_data:
                pid_raw = form_data.get(f"patients[{i}][patient_id]")
                role_raw = form_data.get(f"patients[{i}][role]") or OrderPatientRole.PROBAND.value
                if pid_raw and str(pid_raw).strip():
                    patient_links.append(
                        OrderPatientLink(
                            patient_euid=str(pid_raw),
                            role=OrderPatientRole(str(role_raw)),
                        )
                    )
                i += 1

            if not patient_links and patient_id:
                patient_links = [
                    OrderPatientLink(
                        patient_euid=str(patient_id),
                        role=OrderPatientRole.PROBAND,
                    )
                ]
        except Exception:
            patient_links = []

        # Apply patient links to all existing child orders (best-effort).
        if patient_links:
            try:
                from app.domain.enums import OrderPatientRole
                from app.domain.services.order_relationships import OrderRelationshipService

                rel_svc = OrderRelationshipService(db, order.tenant_id)
                test_order_svc_existing = TestService(db, current_user.tenant_id)
                for to, _to_rev, _assays in test_order_svc_existing.list_for_trf(
                    order.euid, cross_tenant=cross_tenant
                ):
                    existing_links = rel_svc.list_order_patient_links(order_euid=to.euid)
                    preserved = [
                        lnk for lnk in existing_links if lnk.role != OrderPatientRole.PROBAND
                    ]
                    desired = preserved + list(patient_links)
                    rel_svc.ensure_order_patient_links(
                        order_euid=to.euid, links=desired, replace=True
                    )
            except Exception:
                logger.debug("Unable to update order patient links during edit", exc_info=True)

        # Parse and create new Tests (simple approach: add new ones)
        test_order_svc = TestService(db, current_user.tenant_id)
        i = 0
        while f"test_orders[{i}][fulfillment_route_code]" in form_data:
            route_code = form_data.get(f"test_orders[{i}][fulfillment_route_code]")
            is_new = form_data.get(f"test_orders[{i}][is_new]") == "1"
            if route_code and is_new:
                created = test_order_svc.create(
                    trf_id=order.euid,
                    data=TestCreate(
                        product_code=route_code,
                        fulfillment_route_codes=[route_code],
                        specimen_type_required=form_data.get(
                            f"test_orders[{i}][specimen_type]", "BLOOD"
                        ),
                        special_instructions=form_data.get(f"test_orders[{i}][clinical_notes]")
                        or None,
                    ),
                    created_by=current_user.sub_uuid,
                    cross_tenant=cross_tenant,
                )
                if created and patient_id:
                    try:
                        from app.domain.enums import OrderPatientRole
                        from app.domain.services.order_relationships import (
                            OrderPatientLink,
                            OrderRelationshipService,
                        )

                        rel_svc = OrderRelationshipService(db, order.tenant_id)
                        test_order, _rev = created
                        rel_svc.ensure_order_patient_links(
                            order_euid=test_order.euid,
                            links=list(patient_links)
                            if patient_links
                            else [
                                OrderPatientLink(
                                    patient_euid=str(patient_id),
                                    role=OrderPatientRole.PROBAND,
                                )
                            ],
                            replace=False,
                        )
                    except Exception:
                        logger.debug(
                            "Unable to link PROBAND patient to new child order", exc_info=True
                        )
            i += 1

        db.commit()

        # If "Save & Submit" was clicked, submit the order after saving
        submit_after_save = form_data.get("submit_after_save") == "1"
        if submit_after_save:
            # Transition assay runs DRAFT → ORDERED and recompute rollup
            from app.domain.enums import FulfillmentRunState
            from app.domain.policies.rollups import OrderRollupService
            from app.domain.services.fulfillment_runs import (
                FulfillmentRunCreate,
                FulfillmentRunService,
                TransitionData,
            )

            assay_svc = FulfillmentRunService(db, current_user.tenant_id)
            assay_runs = assay_svc.list_for_trf(order.euid)

            # Backfill missing FulfillmentRun records from test orders
            if not assay_runs:
                for to, to_rev, _assays in test_order_svc.list_for_trf(
                    order.euid, cross_tenant=cross_tenant
                ):
                    for fulfillment_route_code in to_rev.fulfillment_route_codes or []:
                        assay_svc.create(
                            FulfillmentRunCreate(
                                order_id=order.euid,
                                test_order_id=to.euid,
                                fulfillment_route_code=fulfillment_route_code,
                            ),
                            created_by=current_user.sub_uuid,
                        )
                assay_runs = assay_svc.list_for_trf(order.euid)

            for ar, ar_rev in assay_runs:
                if ar_rev.status == FulfillmentRunState.DRAFT.value:
                    assay_svc.transition(
                        ar.euid,
                        TransitionData(
                            target_state=FulfillmentRunState.ORDERED,
                            note="TRF submitted",
                        ),
                        transition_by=current_user.sub_uuid,
                    )

            rollup_svc = OrderRollupService(db, current_user.tenant_id)
            rollup_svc.compute_and_update(order.euid, updated_by=current_user.sub_uuid)
            db.commit()

            flash(request, f"TRF {trf_euid} saved and submitted successfully", "success")
        else:
            flash(request, f"TRF {trf_euid} updated successfully", "success")

        return RedirectResponse(
            url=_safe_redirect_url(f"/trfs/{safe_order_id}"), status_code=status.HTTP_303_SEE_OTHER
        )

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error("Error updating TRF: %s", e, exc_info=True)
        flash(request, "An error occurred while updating the TRF. Please try again.", "error")
        return RedirectResponse(url="/trfs", status_code=status.HTTP_303_SEE_OTHER)


# NOTE: Legacy specimen order-linking routes removed; use Bloom-backed tube flows.


# --- Patients ---


@router.get("/patients", response_class=HTMLResponse)
async def patients_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    search: str | None = Query(None),
):
    """List patients for the tenant."""

    cross_tenant = False
    ctx = get_template_context(request, current_user, db)
    svc = PatientService(db, current_user.tenant_id, current_user.sub_uuid)

    results = (
        svc.search_by_name(search, limit=100, cross_tenant=cross_tenant)
        if search
        else svc.list_patients(limit=100, cross_tenant=cross_tenant)
    )

    patients = []
    for patient, revision in results:
        patients.append(
            {
                "id": patient.euid,
                "first_name": revision.first_name,
                "last_name": revision.last_name,
                "full_name": f"{revision.first_name} {revision.last_name}",
                "date_of_birth": revision.date_of_birth.isoformat()
                if revision.date_of_birth
                else None,
                "sex": revision.sex,
                "mrn": revision.mrn,
                "email": revision.email,
                "phone": revision.phone,
                "created_at": patient.created_at.strftime("%Y-%m-%d %H:%M")
                if patient.created_at
                else None,
            }
        )

    ctx["patients"] = patients
    ctx["search"] = search or ""
    return templates.TemplateResponse(request, "patients/list.html", context=ctx)


@router.get("/patients/new", response_class=HTMLResponse)
async def patients_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
    redirect: str | None = Query(None),
):
    """New patient form."""
    ctx = get_template_context(request, current_user, db)
    ctx["redirect_url"] = _safe_redirect_url(redirect) if redirect else None
    return templates.TemplateResponse(request, "patients/create.html", context=ctx)


@router.post("/patients/new", dependencies=[Depends(csrf_protect)])
async def patients_create_submit(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
    first_name: str = Form(...),
    last_name: str = Form(...),
    date_of_birth: str = Form(...),
    sex: str | None = Form(None),
    mrn: str | None = Form(None),
    email: str | None = Form(None),
    phone: str | None = Form(None),
    address_line1: str | None = Form(None),
    address_line2: str | None = Form(None),
    city: str | None = Form(None),
    state: str | None = Form(None),
    postal_code: str | None = Form(None),
    country: str | None = Form("US"),
    site_id: str | None = Form(None),
    redirect_url: str = Form("/patients"),
):
    """Create a new patient."""
    from datetime import date as date_type

    safe_redirect = _safe_redirect_url(redirect_url, default="/patients")

    try:
        dob = date_type.fromisoformat(date_of_birth)
    except ValueError as e:
        logger.error("Invalid date format: %s", e, exc_info=True)
        flash(request, "Invalid date format. Please check your input.", "error")
        return RedirectResponse(url="/patients/new", status_code=status.HTTP_303_SEE_OTHER)

    try:
        svc = PatientService(db, current_user.tenant_id)
        svc.create(
            PatientCreate(
                first_name=first_name,
                last_name=last_name,
                date_of_birth=dob,
                sex=sex if sex else None,
                mrn=mrn if mrn else None,
                email=email if email else None,
                phone=phone if phone else None,
                address_line1=address_line1,
                address_line2=address_line2,
                city=city,
                state=state,
                postal_code=postal_code,
                country=country,
                site_id=(site_id or "").strip() or None,
            ),
            created_by=current_user.sub_uuid,
        )

        flash(request, f"Patient {first_name} {last_name} created successfully", "success")
        return RedirectResponse(
            url=safe_redirect,
            status_code=status.HTTP_303_SEE_OTHER,
        )
    except ValueError as e:
        flash(request, str(e), "error")
        return RedirectResponse(url="/patients/new", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        logger.error("Error creating patient: %s", e, exc_info=True)
        flash(request, "An error occurred while creating patient. Please try again.", "error")
        return RedirectResponse(url="/patients/new", status_code=status.HTTP_303_SEE_OTHER)


@router.get("/patients/{patient_id}", response_class=HTMLResponse)
async def patients_detail(
    request: Request,
    patient_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Patient detail page."""
    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)
    svc = PatientService(db, current_user.tenant_id, current_user.sub_uuid)

    result = svc.get_by_id(patient_id, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(status_code=404, detail="Patient not found")

    patient, revision = result

    # Get all revisions for history. TapDB-backed records may not expose
    # an ORM-style `.revisions` relationship, so fall back to latest only.
    revisions = []
    revision_history = getattr(patient, "revisions", None) or [revision]
    for rev in revision_history:
        revisions.append(
            {
                "revision_no": rev.revision_no,
                "first_name": rev.first_name,
                "last_name": rev.last_name,
                "mrn": rev.mrn,
                "created_at": rev.created_at.strftime("%Y-%m-%d %H:%M") if rev.created_at else None,
                "note": rev.note,
            }
        )

    # Get linked orders for this patient
    from app.domain.services.trfs import TrfService

    order_svc = TrfService(db, current_user.tenant_id)
    linked_orders = order_svc.list_by_patient(patient_id, cross_tenant=cross_tenant)

    # Graph-native family relationships (TapDB lineage)
    family_ctx = {"families": [], "father": None, "mother": None, "siblings": []}
    try:
        from app.domain.services.families import FamilyService
        from app.domain.services.patient_relationships import PatientRelationshipService

        rel_svc = PatientRelationshipService(db, current_user.tenant_id)
        fam_svc = FamilyService(db, current_user.tenant_id, current_user.sub_uuid)
        graph = rel_svc.get_patient_family_graph(patient.euid)

        for fid in graph.family_ids:
            fres = fam_svc.get_by_id(fid, cross_tenant=cross_tenant)
            if not fres:
                continue
            _fam, frev = fres
            family_ctx["families"].append({"id": fid, "name": frev.name})

        if graph.father_id:
            father = svc.get_by_id(graph.father_id, cross_tenant=cross_tenant)
            if father:
                _p, prev = father
                family_ctx["father"] = {
                    "id": str(graph.father_id),
                    "name": f"{prev.first_name} {prev.last_name}",
                }

        if graph.mother_id:
            mother = svc.get_by_id(graph.mother_id, cross_tenant=cross_tenant)
            if mother:
                _p, prev = mother
                family_ctx["mother"] = {
                    "id": str(graph.mother_id),
                    "name": f"{prev.first_name} {prev.last_name}",
                }

        for sid in graph.sibling_ids:
            sib = svc.get_by_id(sid, cross_tenant=cross_tenant)
            if not sib:
                continue
            _p, prev = sib
            family_ctx["siblings"].append(
                {"id": str(sid), "name": f"{prev.first_name} {prev.last_name}"}
            )
    except Exception:
        logger.debug("Patient family graph lookup failed", exc_info=True)

    ctx["patient"] = {
        "id": patient.euid,
        "first_name": revision.first_name,
        "last_name": revision.last_name,
        "middle_name": revision.middle_name,
        "full_name": f"{revision.first_name} {revision.last_name}",
        "date_of_birth": revision.date_of_birth.isoformat() if revision.date_of_birth else None,
        "sex": revision.sex,
        "mrn": revision.mrn,
        "email": revision.email,
        "phone": revision.phone,
        "address": revision.address,
        "clinical_notes": revision.clinical_notes,
        "created_at": patient.created_at.strftime("%Y-%m-%d %H:%M") if patient.created_at else None,
        "revision_no": revision.revision_no,
    }
    ctx["revisions"] = revisions
    ctx["linked_orders"] = linked_orders
    ctx["family"] = family_ctx
    ctx["collection_events"] = _list_collection_event_summaries(
        db, current_user.tenant_id, patient_euid=patient.euid
    )
    return templates.TemplateResponse(request, "patients/detail.html", context=ctx)


@router.get("/patients/{patient_id}/edit", response_class=HTMLResponse)
async def patients_edit_form(
    request: Request,
    patient_id: str,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """Patient edit form."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.site_scope import list_tenant_site_options

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)
    svc = PatientService(db, current_user.tenant_id, current_user.sub_uuid)

    result = svc.get_by_id(patient_id, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(status_code=404, detail="Patient not found")

    patient, revision = result

    ctx["patient"] = {
        "id": patient.euid,
        "first_name": revision.first_name,
        "last_name": revision.last_name,
        "middle_name": revision.middle_name,
        "date_of_birth": revision.date_of_birth.isoformat() if revision.date_of_birth else None,
        "sex": revision.sex,
        "mrn": revision.mrn,
        "email": revision.email,
        "phone": revision.phone,
        "address": revision.address or {},
        "clinical_notes": revision.clinical_notes,
        "site_id": getattr(patient, "site_id", None),
    }
    site_options = list_tenant_site_options(db, patient.tenant_id)
    ctx["site_options"] = site_options
    ctx["selected_site_id"] = getattr(patient, "site_id", None) or (
        site_options[0].id if len(site_options) == 1 else None
    )
    return templates.TemplateResponse(request, "patients/edit.html", context=ctx)


@router.post("/patients/{patient_id}/edit", dependencies=[Depends(csrf_protect)])
async def patients_edit_submit(
    request: Request,
    patient_id: str,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
    first_name: str = Form(...),
    last_name: str = Form(...),
    middle_name: str | None = Form(None),
    date_of_birth: str = Form(...),
    sex: str | None = Form(None),
    mrn: str | None = Form(None),
    email: str | None = Form(None),
    phone: str | None = Form(None),
    address_line1: str | None = Form(None),
    address_line2: str | None = Form(None),
    city: str | None = Form(None),
    state: str | None = Form(None),
    postal_code: str | None = Form(None),
    country: str | None = Form("US"),
    clinical_notes: str | None = Form(None),
    site_id: str | None = Form(None),
    note: str | None = Form(None),
):
    """Update patient (creates new revision)."""
    from datetime import date as date_type

    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = PatientService(db, current_user.tenant_id, current_user.sub_uuid)

    try:
        dob = date_type.fromisoformat(date_of_birth)
    except ValueError as e:
        logger.error("Invalid date format: %s", e, exc_info=True)
        flash(request, "Invalid date format. Please check your input.", "error")
        return RedirectResponse(url="/patients", status_code=status.HTTP_303_SEE_OTHER)

    try:
        address = None
        if any([address_line1, address_line2, city, state, postal_code, country]):
            address = {
                "address_line1": address_line1,
                "address_line2": address_line2,
                "city": city,
                "state": state,
                "postal_code": postal_code,
                "country": country,
            }

        result = svc.update(
            patient_id,
            PatientUpdate(
                first_name=first_name,
                last_name=last_name,
                middle_name=middle_name if middle_name else None,
                date_of_birth=dob,
                sex=sex if sex else None,
                mrn=mrn if mrn else None,
                email=email if email else None,
                phone=phone if phone else None,
                address=address,
                clinical_notes=clinical_notes if clinical_notes else None,
                site_id=(site_id or "").strip() or None,
                note=note if note else None,
            ),
            updated_by=current_user.sub_uuid,
            cross_tenant=cross_tenant,
        )

        if not result:
            raise HTTPException(status_code=404, detail="Patient not found")

        safe_patient_id = str(result.euid)

        flash(request, f"Patient {first_name} {last_name} updated successfully", "success")
        return RedirectResponse(
            url=_safe_redirect_url(f"/patients/{safe_patient_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except ValueError as e:
        flash(request, str(e), "error")
        return RedirectResponse(url="/patients", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        logger.error("Error updating patient: %s", e, exc_info=True)
        flash(request, "An error occurred while updating patient. Please try again.", "error")
        return RedirectResponse(url="/patients", status_code=status.HTTP_303_SEE_OTHER)


# --- Clinicians ---


@router.get("/clinicians", response_class=HTMLResponse)
async def clinicians_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    search: str | None = Query(None),
):
    """List clinicians for the tenant."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.people import ClinicianService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub_uuid)

    if search:
        results = svc.search_by_name(search, limit=100, cross_tenant=cross_tenant)
    else:
        results = svc.list_clinicians(limit=100, active_only=False, cross_tenant=cross_tenant)

    clinicians = []
    for clinician, revision in results:
        clinicians.append(
            {
                "id": clinician.euid,
                "first_name": revision.first_name,
                "last_name": revision.last_name,
                "full_name": f"{revision.first_name} {revision.last_name}",
                "credentials": revision.credentials,
                "npi": revision.npi,
                "specialty": revision.specialty,
                "email": revision.email,
                "phone": revision.phone,
                "is_active": revision.is_active,
                "created_at": clinician.created_at.strftime("%Y-%m-%d %H:%M")
                if clinician.created_at
                else None,
            }
        )

    ctx["clinicians"] = clinicians
    ctx["search"] = search or ""
    return templates.TemplateResponse(request, "clinicians/list.html", context=ctx)


@router.get("/clinicians/new", response_class=HTMLResponse)
async def clinicians_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
    redirect: str | None = Query(None),
):
    """New clinician form."""
    from app.domain.services.site_scope import list_tenant_site_options

    ctx = get_template_context(request, current_user, db)
    ctx["redirect_url"] = _safe_redirect_url(redirect or "/trfs/new")
    site_options = list_tenant_site_options(db, current_user.tenant_id)
    ctx["site_options"] = site_options
    ctx["selected_site_id"] = site_options[0].id if len(site_options) == 1 else None
    return templates.TemplateResponse(request, "clinicians/create.html", context=ctx)


@router.post("/clinicians/new", dependencies=[Depends(csrf_protect)])
async def clinicians_create_submit(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
    first_name: str = Form(...),
    last_name: str = Form(...),
    credentials: str | None = Form(None),
    specialty: str | None = Form(None),
    npi: str | None = Form(None),
    email: str | None = Form(None),
    phone: str | None = Form(None),
    site_id: str | None = Form(None),
    redirect_url: str = Form("/trfs/new"),
):
    """Create a new clinician."""
    safe_redirect = _safe_redirect_url(redirect_url)
    try:
        from app.domain.services.people import ClinicianCreate, ClinicianService

        # Create clinician
        svc = ClinicianService(db, current_user.tenant_id, current_user.sub_uuid)
        clinician, revision = svc.create(
            ClinicianCreate(
                first_name=first_name,
                last_name=last_name,
                credentials=credentials if credentials else None,
                specialty=specialty if specialty else None,
                npi=npi if npi else None,
                email=email if email else None,
                phone=phone if phone else None,
                site_id=(site_id or "").strip() or None,
            )
        )

        flash(request, f"Clinician {first_name} {last_name} created successfully", "success")
        return RedirectResponse(
            url=safe_redirect,
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except Exception as e:
        logger.error("Error creating clinician: %s", e, exc_info=True)
        flash(
            request,
            str(e)
            if isinstance(e, ValueError)
            else "An error occurred while creating clinician. Please try again.",
            "error",
        )
        return RedirectResponse(url="/clinicians/new", status_code=status.HTTP_303_SEE_OTHER)


@router.get("/clinicians/{clinician_id}", response_class=HTMLResponse)
async def clinicians_detail(
    request: Request,
    clinician_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Clinician detail page."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.people import ClinicianService
    from app.domain.services.users import UserService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub_uuid)

    result = svc.get_by_id(clinician_id, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(status_code=404, detail="Clinician not found")

    clinician, revision = result

    # Get all revisions for history. TapDB-backed records may not expose
    # an ORM-style `.revisions` relationship, so fall back to latest only.
    revisions = []
    revision_history = getattr(clinician, "revisions", None) or [revision]
    for rev in revision_history:
        revisions.append(
            {
                "revision_no": rev.revision_no,
                "first_name": rev.first_name,
                "last_name": rev.last_name,
                "npi": rev.npi,
                "is_active": rev.is_active,
                "created_at": rev.created_at.strftime("%Y-%m-%d %H:%M") if rev.created_at else None,
                "note": rev.note,
            }
        )

    # Get users in the same organization
    user_svc = UserService(db, current_user.sub_uuid)
    org_users = user_svc.list_users(tenant_id=clinician.tenant_id, limit=50)
    ctx["users"] = [
        {
            "id": str(u.euid),
            "name": u.name,
            "email": u.email,
            "roles": u.roles,
            "is_active": u.is_active,
        }
        for u in org_users
    ]

    ctx["clinician"] = {
        "id": clinician.euid,
        "first_name": revision.first_name,
        "last_name": revision.last_name,
        "full_name": f"{revision.first_name} {revision.last_name}",
        "credentials": revision.credentials,
        "npi": revision.npi,
        "specialty": revision.specialty,
        "email": revision.email,
        "phone": revision.phone,
        "fax": revision.fax,
        "addresses": revision.addresses,
        "is_active": revision.is_active,
        "created_at": clinician.created_at.strftime("%Y-%m-%d %H:%M")
        if clinician.created_at
        else None,
        "revision_no": revision.revision_no,
    }
    ctx["revisions"] = revisions
    return templates.TemplateResponse(request, "clinicians/detail.html", context=ctx)


@router.get("/clinicians/{clinician_id}/edit", response_class=HTMLResponse)
async def clinicians_edit_form(
    request: Request,
    clinician_id: str,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """Clinician edit form."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.people import ClinicianService
    from app.domain.services.site_scope import list_tenant_site_options

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub_uuid)

    result = svc.get_by_id(clinician_id, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(status_code=404, detail="Clinician not found")

    clinician, revision = result

    ctx["clinician"] = {
        "id": clinician.euid,
        "first_name": revision.first_name,
        "last_name": revision.last_name,
        "credentials": revision.credentials,
        "npi": revision.npi,
        "specialty": revision.specialty,
        "email": revision.email,
        "phone": revision.phone,
        "fax": revision.fax,
        "site_id": revision.site_id or getattr(clinician, "site_id", None),
        "is_active": revision.is_active,
    }
    site_options = list_tenant_site_options(db, clinician.tenant_id)
    ctx["site_options"] = site_options
    ctx["selected_site_id"] = ctx["clinician"]["site_id"] or (
        site_options[0].id if len(site_options) == 1 else None
    )
    return templates.TemplateResponse(request, "clinicians/edit.html", context=ctx)


@router.post("/clinicians/{clinician_id}/edit", dependencies=[Depends(csrf_protect)])
async def clinicians_edit_submit(
    request: Request,
    clinician_id: str,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
    first_name: str = Form(...),
    last_name: str = Form(...),
    credentials: str | None = Form(None),
    npi: str | None = Form(None),
    specialty: str | None = Form(None),
    email: str | None = Form(None),
    phone: str | None = Form(None),
    fax: str | None = Form(None),
    site_id: str | None = Form(None),
    is_active: bool = Form(True),
    note: str | None = Form(None),
):
    """Update clinician (creates new revision)."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.people import ClinicianService, ClinicianUpdate

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub_uuid)

    result = svc.update(
        clinician_id,
        ClinicianUpdate(
            first_name=first_name,
            last_name=last_name,
            credentials=credentials if credentials else None,
            npi=npi if npi else None,
            specialty=specialty if specialty else None,
            email=email if email else None,
            phone=phone if phone else None,
            fax=fax if fax else None,
            site_id=(site_id or "").strip() or None,
            is_active=is_active,
            note=note if note else None,
        ),
        updated_by=current_user.sub_uuid,
        cross_tenant=cross_tenant,
    )

    if not result:
        raise HTTPException(status_code=404, detail="Clinician not found")

    safe_clinician_id = str(result.euid)

    flash(request, f"Clinician {first_name} {last_name} updated successfully", "success")
    return RedirectResponse(
        url=_safe_redirect_url(f"/clinicians/{safe_clinician_id}"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.get("/clinicians/{clinician_id}/users/new", response_class=HTMLResponse)
async def clinicians_user_create_form(
    request: Request,
    clinician_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
):
    """Form to create a new user for the clinician's organization."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.people import ClinicianService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub_uuid)

    result = svc.get_by_id(clinician_id, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(status_code=404, detail="Clinician not found")

    clinician, revision = result

    # Verify user is creating in their own tenant (unless internal/admin)
    if not current_user.is_internal and current_user.tenant_id != clinician.tenant_id:
        raise HTTPException(status_code=403, detail="Access denied")

    ctx["clinician"] = {
        "id": clinician.euid,
        "full_name": f"{revision.first_name} {revision.last_name}",
        "tenant_id": str(clinician.tenant_id),
    }

    # Define available roles based on user permissions
    if current_user.is_internal:
        ctx["available_roles"] = [
            "ADMIN",
            "EXTERNAL_USER",
            "EXTERNAL_USER_ADMIN",
            "INTERNAL_USER",
            "READ_ONLY",
            "READ_WRITE",
        ]
    elif current_user.is_org_admin:
        ctx["available_roles"] = sorted(ORG_ADMIN_ASSIGNABLE_ROLES)
    else:
        ctx["available_roles"] = sorted(EXTERNAL_ASSIGNABLE_ROLES)

    return templates.TemplateResponse(request, "clinicians/user_create.html", context=ctx)


@router.post("/clinicians/{clinician_id}/users/new", dependencies=[Depends(csrf_protect)])
async def clinicians_user_create_submit(
    request: Request,
    clinician_id: str,
    current_user: Annotated[CurrentUser, Depends(require_org_admin)],
    db: Session = Depends(get_db),
    email: str = Form(...),
    name: str = Form(None),
    roles: list[str] = Form(default=["EXTERNAL_USER"]),
):
    """Create a new user for the clinician's organization."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.people import ClinicianService
    from app.domain.services.users import UserCreate, UserService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ClinicianService(db, current_user.tenant_id, current_user.sub_uuid)

    result = svc.get_by_id(clinician_id, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(status_code=404, detail="Clinician not found")

    clinician, _ = result

    # Verify user is creating in their own tenant (unless internal/admin)
    if not current_user.is_internal and current_user.tenant_id != clinician.tenant_id:
        raise HTTPException(status_code=403, detail="Access denied")

    # Validate roles - external users can only create certain roles
    if current_user.is_org_admin:
        allowed_roles = ORG_ADMIN_ASSIGNABLE_ROLES
    else:
        allowed_roles = EXTERNAL_ASSIGNABLE_ROLES
    if not current_user.is_internal:
        for role in roles:
            if role not in allowed_roles:
                flash(
                    request, f"Cannot assign role: {role}. Only {allowed_roles} allowed.", "error"
                )
                safe_clinician_id = str(clinician.euid)
                return RedirectResponse(
                    url=_safe_redirect_url(f"/clinicians/{safe_clinician_id}/users/new"),
                    status_code=status.HTTP_303_SEE_OTHER,
                )

    try:
        user_svc = UserService(db, current_user.sub_uuid)
        user_svc.invite(
            UserCreate(
                email=email,
                name=name if name else None,
                tenant_id=clinician.tenant_id,
                roles=roles,
            )
        )

        safe_clinician_id = str(clinician.euid)

        flash(request, f"User {email} invited successfully", "success")
        return RedirectResponse(
            url=_safe_redirect_url(f"/clinicians/{safe_clinician_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    except (ValueError, Exception) as e:
        logger.error("Error adding user to clinician: %s", e, exc_info=True)
        flash(request, "An error occurred while adding the user. Please try again.", "error")
        return RedirectResponse(url="/clinicians", status_code=status.HTTP_303_SEE_OTHER)


# --- Shipments ---


@router.get("/shipments", response_class=HTMLResponse)
async def shipments_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    status_filter: str | None = Query(None, alias="status"),
):
    """Shipments list page."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import ShipmentService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)
    ctx["status_filter"] = status_filter

    # Fetch shipments from service
    svc = ShipmentService(db, current_user.tenant_id)
    shipments_data = svc.list_shipments(limit=100, cross_tenant=cross_tenant)

    shipments = []
    for shipment, revision in shipments_data:
        # Skip if doesn't match status filter
        if status_filter and revision and revision.status != status_filter:
            continue

        # Get containment counts for this shipment
        tree = svc.get_containment_tree(shipment.euid)
        kit_count = len(tree.get("test_kits", []))
        specimen_count = len(tree.get("direct_specimens", []))
        # Also count specimens inside kits
        for kit in tree.get("test_kits", []):
            specimen_count += len(kit.get("specimens", []))

        shipments.append(
            {
                "id": str(shipment.euid),
                "shipment_number": shipment.shipment_number,
                "status": revision.status if revision else "DRAFT",
                "tracking_number": revision.tracking_number if revision else None,
                "carrier": revision.carrier if revision else None,
                "created_at": shipment.created_at,
                "kit_count": kit_count,
                "specimen_count": specimen_count,
            }
        )

    ctx["shipments"] = shipments
    return templates.TemplateResponse(request, "shipments/list.html", context=ctx)


@router.get("/shipments/new", response_class=HTMLResponse)
async def shipments_create(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """New shipment form."""
    from app.domain.services.orgs import SiteService

    ctx = get_template_context(request, current_user, db)

    # Query sites for current tenant (tenant_id == organization_id)
    site_svc = SiteService(db)
    sites = site_svc.list_by_organization(current_user.tenant_id, active_only=True)

    # Build site list with names from revisions
    sites_with_names = []
    for site in sites:
        latest_rev = site.revisions[-1] if site.revisions else None
        if latest_rev:
            sites_with_names.append({"id": site.euid, "name": latest_rev.name})

    ctx["sites"] = sites_with_names
    return templates.TemplateResponse(request, "shipments/create.html", context=ctx)


@router.post("/shipments/new", dependencies=[Depends(csrf_protect)])
async def shipments_create_submit(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
    carrier: str | None = Form(None),
    tracking_number: str | None = Form(None),
    origin_site_id: str | None = Form(None),
    special_instructions: str | None = Form(None),
):
    """Create a new shipment."""
    from app.domain.services.orgs import OrganizationService, SiteService
    from app.domain.services.shipments import ShipmentCreate, ShipmentService

    try:
        # Validate origin_site_id as canonical site EUID if provided.
        origin_site_euid = None
        origin_address = None

        if origin_site_id:
            site_svc = SiteService(db)
            site = site_svc.get_by_id(origin_site_id)
            org_svc = OrganizationService(db)
            current_org = org_svc.get_by_uid(current_user.tenant_id)
            current_org_euid = current_org.euid if current_org else None
            if (
                not site
                or not current_org_euid
                or str(site.organization_id) != str(current_org_euid)
            ):
                flash(request, "Invalid origin site ID format", "error")
                return RedirectResponse(url="/shipments/new", status_code=status.HTTP_303_SEE_OTHER)
            origin_site_euid = site.euid

            # Get site address from latest revision to store in origin_address
            latest_rev = site.revisions[-1] if site.revisions else None
            if latest_rev:
                origin_address = {
                    "site_id": site.euid,
                    "site_name": latest_rev.name,
                    "address": latest_rev.address,
                }

        svc = ShipmentService(db, current_user.tenant_id)
        shipment, revision = svc.create(
            ShipmentCreate(
                carrier=carrier,
                tracking_number=tracking_number,
                origin_site_id=origin_site_euid,
                origin_address=origin_address,
                special_instructions=special_instructions,
            ),
            created_by=current_user.sub_uuid,
        )

        flash(request, f"Shipment {shipment.shipment_number} created successfully", "success")
        safe_shipment_num = str(shipment.shipment_number)
        # Redirect using human-readable shipment_number
        return RedirectResponse(
            url=_safe_redirect_url(f"/shipments/{safe_shipment_num}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except Exception as e:
        logger.error("Error creating shipment: %s", e, exc_info=True)
        flash(request, "An error occurred while creating shipment. Please try again.", "error")
        return RedirectResponse(url="/shipments/new", status_code=status.HTTP_303_SEE_OTHER)


@router.get("/shipments/{shipment_number}", response_class=HTMLResponse)
async def shipments_detail(
    request: Request,
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Shipment detail page. Uses human-readable shipment_number in URL."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import ShipmentService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)

    svc = ShipmentService(db, current_user.tenant_id)
    result = svc.get_by_shipment_number(shipment_number, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Shipment {shipment_number} not found",
        )

    shipment, revision = result

    # Get containment tree
    tree = svc.get_containment_tree(shipment.euid)

    # Get FedEx tracking data if available
    tracking_data = None
    if revision and revision.tracking_number:
        from app.domain.services.fedex_tracking import FedExTrackingService

        tracking_svc = FedExTrackingService(db, current_user.tenant_id, current_user.sub)
        tracking_data = tracking_svc.get_latest_tracking(shipment.euid)

    # Get linked documents
    from app.domain.services.documents import DocumentService

    doc_svc = DocumentService(db, current_user.tenant_id, current_user.sub)
    linked_docs = doc_svc.get_linked_documents("Shipment", str(shipment.euid))
    documents = [
        {
            "id": doc.euid,
            "filename": rev.filename if rev else "Unknown",
            "document_type": rev.document_type if rev else None,
            "size_bytes": rev.size_bytes if rev else None,
        }
        for doc, rev in linked_docs
    ]

    ctx["shipment"] = shipment
    ctx["revision"] = revision
    ctx["origin_site"] = None
    ctx["containment_tree"] = tree
    ctx["tracking"] = tracking_data
    ctx["documents"] = documents
    # Keep backward compatibility
    ctx["test_kits"] = tree["test_kits"]
    ctx.update(
        _build_tube_panel_context(
            db,
            shipment.tenant_id,
            anchor_type="Shipment",
            anchor_id=shipment.euid,
            return_to=f"/shipments/{shipment.shipment_number}",
        )
    )
    return templates.TemplateResponse(request, "shipments/detail.html", context=ctx)


@router.get("/shipments/{shipment_number}/edit", response_class=HTMLResponse)
async def shipments_edit_form(
    request: Request,
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """Shipment edit form."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import ShipmentService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)

    svc = ShipmentService(db, current_user.tenant_id)
    result = svc.get_by_shipment_number(shipment_number, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Shipment {shipment_number} not found",
        )

    shipment, revision = result
    ctx["shipment"] = shipment
    ctx["revision"] = revision

    return templates.TemplateResponse(request, "shipments/edit.html", context=ctx)


@router.post("/shipments/{shipment_number}/edit", dependencies=[Depends(csrf_protect)])
async def shipments_edit_submit(
    request: Request,
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)],
    db: Session = Depends(get_db),
):
    """Update a shipment."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import ShipmentService, ShipmentUpdate

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    try:
        form_data = await request.form()

        svc = ShipmentService(db, current_user.tenant_id)
        result = svc.get_by_shipment_number(shipment_number, cross_tenant=cross_tenant)

        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Shipment {shipment_number} not found",
            )

        shipment, _ = result

        svc.update(
            shipment.euid,
            ShipmentUpdate(
                carrier=form_data.get("carrier") or None,
                tracking_number=form_data.get("tracking_number") or None,
                temperature_requirement=form_data.get("temperature_requirement") or None,
                special_instructions=form_data.get("special_instructions") or None,
                note=form_data.get("note") or None,
            ),
            updated_by=current_user.sub_uuid,
            cross_tenant=cross_tenant,
        )

        safe_shipment_num = str(shipment.shipment_number)
        flash(request, f"Shipment {shipment_number} updated successfully", "success")
        return RedirectResponse(
            url=_safe_redirect_url(f"/shipments/{safe_shipment_num}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error("Error updating shipment: %s", e, exc_info=True)
        flash(request, "An error occurred while updating shipment. Please try again.", "error")
        return RedirectResponse(
            url="/shipments",
            status_code=status.HTTP_303_SEE_OTHER,
        )


@router.post("/shipments/{shipment_number}/ship", dependencies=[Depends(csrf_protect)])
async def shipments_ship(
    request: Request,
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Mark a shipment as shipped (transition to IN_TRANSIT status)."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.enums import ShipmentStatus
    from app.domain.services.shipments import ShipmentService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    try:
        svc = ShipmentService(db, current_user.tenant_id)
        result = svc.get_by_shipment_number(shipment_number, cross_tenant=cross_tenant)

        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Shipment {shipment_number} not found",
            )

        shipment, _revision = result

        # Change status to IN_TRANSIT
        svc.change_status(
            shipment_id=shipment.euid,
            new_status=ShipmentStatus.IN_TRANSIT,
            reason="Marked as shipped via web UI",
            updated_by=current_user.sub_uuid,
            cross_tenant=cross_tenant,
        )

        safe_shipment_num = str(shipment.shipment_number)
        flash(request, f"Shipment {shipment_number} marked as shipped", "success")
        return RedirectResponse(
            url=_safe_redirect_url(f"/shipments/{safe_shipment_num}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error("Error shipping shipment: %s", e, exc_info=True)
        flash(request, "An error occurred while shipping shipment. Please try again.", "error")
        return RedirectResponse(
            url="/shipments",
            status_code=status.HTTP_303_SEE_OTHER,
        )


@router.post("/shipments/{shipment_number}/receive", dependencies=[Depends(csrf_protect)])
async def shipments_receive(
    request: Request,
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    """Receive a shipment (internal users only).

    Step 6.4: Sets shipment status to RECEIVED and processes contents:
    - For each contained TestKit: mark RECEIVED
    - Material processing is Bloom-owned.
    """
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.intake import IntakeService
    from app.domain.services.shipments import (
        ShipmentService,
        TestKitService,
    )

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    try:
        shipment_svc = ShipmentService(db, current_user.tenant_id)
        result = shipment_svc.get_by_shipment_number(shipment_number, cross_tenant=cross_tenant)

        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Shipment {shipment_number} not found",
            )

        shipment, _ = result

        # Use IntakeService to mark shipment as received
        intake_svc = IntakeService(db, current_user.tenant_id)
        receive_result = intake_svc.receive_shipment(
            shipment.euid,
            created_by=current_user.sub_uuid,
            cross_tenant=cross_tenant,
        )
        safe_shipment_num = str(shipment.shipment_number)
        if not receive_result:
            flash(request, f"Failed to receive shipment {shipment_number}", "error")
            return RedirectResponse(
                url=_safe_redirect_url(f"/shipments/{safe_shipment_num}"),
                status_code=status.HTTP_303_SEE_OTHER,
            )

        # Get shipment contents and process TestKits
        contents = shipment_svc.get_contents(shipment.euid)

        testkit_svc = TestKitService(db, current_user.tenant_id)
        testkits_received = 0

        for item in contents:
            if item["type"] == "TestKit":
                tk_result = testkit_svc.mark_received(
                    item["id"],
                    reason="Shipment received",
                    updated_by=current_user.sub_uuid,
                    cross_tenant=cross_tenant,
                )
                if tk_result:
                    testkits_received += 1

        db.commit()

        flash(
            request,
            f"Shipment {shipment_number} received: {testkits_received} kits processed",
            "success",
        )
        return RedirectResponse(
            url=_safe_redirect_url(f"/shipments/{safe_shipment_num}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error("Error receiving shipment: %s", e, exc_info=True)
        flash(request, "An error occurred while receiving shipment. Please try again.", "error")
        return RedirectResponse(
            url="/shipments",
            status_code=status.HTTP_303_SEE_OTHER,
        )


@router.post("/shipments/{shipment_number}/add-kit", dependencies=[Depends(csrf_protect)])
async def shipments_add_kit(
    request: Request,
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    kit_barcode: str | None = Form(None),
    kit_type: str | None = Form(None),
):
    """Add a test kit to a shipment."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import ShipmentService, TestKitCreate, TestKitService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    try:
        shipment_svc = ShipmentService(db, current_user.tenant_id)
        result = shipment_svc.get_by_shipment_number(shipment_number, cross_tenant=cross_tenant)

        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Shipment {shipment_number} not found",
            )

        shipment, _revision = result

        safe_shipment_num = str(shipment.shipment_number)

        if shipment.tenant_id != current_user.tenant_id:
            # Cross-tenant *reads* are allowed for some internal users, but
            # cross-tenant *writes* are not supported in this workflow.
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN, detail="Cross-tenant write forbidden"
            )

        kit_svc = TestKitService(db, current_user.tenant_id)
        normalized_barcode = str(kit_barcode or "").strip()
        if normalized_barcode:
            # Get-or-create the test kit by barcode to avoid unique constraint errors.
            test_kit, created = kit_svc.get_or_create_by_barcode(
                kit_barcode=normalized_barcode,
                kit_type=kit_type,
                origin_site_id=getattr(_revision, "origin_site_id", None),
                created_by=current_user.sub_uuid,
            )
        else:
            test_kit = kit_svc.create(
                TestKitCreate(
                    kit_barcode=None,
                    kit_type=kit_type,
                    origin_site_id=getattr(_revision, "origin_site_id", None),
                ),
                created_by=current_user.sub_uuid,
            )
            created = True

        # Idempotency: if the kit is already in this shipment, do not add a duplicate event.
        already_contained = any(
            item.get("type") == "TestKit" and item.get("id") == str(test_kit.euid)
            for item in shipment_svc.get_contents(shipment.euid)
        )
        if already_contained:
            flash(
                request,
                f"Test kit {_testkit_display_label(test_kit)} is already in shipment",
                "success",
            )
            return RedirectResponse(
                url=_safe_redirect_url(f"/shipments/{safe_shipment_num}"),
                status_code=status.HTTP_303_SEE_OTHER,
            )

        # Add test kit to shipment
        shipment_svc.add_item(
            shipment.euid,
            "TestKit",
            test_kit.euid,
            reason="Added via web UI",
            created_by=current_user.sub_uuid,
        )

        suffix = " (created kit)" if created else " (existing kit)"
        flash(
            request,
            f"Test kit {_testkit_display_label(test_kit)} added to shipment{suffix}",
            "success",
        )
        return RedirectResponse(
            url=_safe_redirect_url(f"/shipments/{safe_shipment_num}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error("Error adding kit: %s", e, exc_info=True)
        flash(request, "An error occurred while adding kit. Please try again.", "error")
        return RedirectResponse(
            url="/shipments",
            status_code=status.HTTP_303_SEE_OTHER,
        )


@router.get(
    "/shipments/{shipment_number}/add-specimen",
    response_class=HTMLResponse,
    dependencies=[Depends(require_read_write_web)],
)
async def shipments_add_specimen_form(
    request: Request,
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Render shipment-scoped Bloom tube creation form."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.shipments import ShipmentService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    shipment_result = ShipmentService(db, current_user.tenant_id).get_by_shipment_number(
        shipment_number,
        cross_tenant=cross_tenant,
    )
    if not shipment_result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shipment not found")
    shipment, revision = shipment_result
    if shipment.tenant_id != current_user.tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Cross-tenant write forbidden"
        )

    org_result = OrganizationService(db).get_with_revision_by_uid(shipment.tenant_id)
    organization = org_result[0] if org_result else None
    site_options = _list_site_summaries(db, organization.euid) if organization else []

    ctx = get_template_context(request, current_user, db)
    ctx["shipment"] = shipment
    ctx["revision"] = revision
    ctx["test_options"] = _list_tenant_test_summaries(db, shipment.tenant_id)
    ctx["available_patients"] = _list_patient_summaries(db, shipment.tenant_id)
    ctx["available_testkits"] = _list_testkit_summaries(db, shipment.tenant_id)
    ctx["site_options"] = site_options
    ctx["selected_origin_site_id"] = site_options[0]["id"] if len(site_options) == 1 else None
    return templates.TemplateResponse(request, "shipments/add_specimen.html", context=ctx)


@router.post("/shipments/{shipment_number}/add-specimen", dependencies=[Depends(csrf_protect)])
async def shipments_add_specimen_submit(
    request: Request,
    shipment_number: str,
    test_euid: Annotated[str, Form()],
    patient_euid: Annotated[str | None, Form()] = None,
    testkit_euid: Annotated[str | None, Form()] = None,
    site_euid: Annotated[str | None, Form()] = None,
    collection_site_euid: Annotated[str | None, Form()] = None,
    collected_at: Annotated[str | None, Form()] = None,
    collection_type: Annotated[str | None, Form()] = None,
    collected_by: Annotated[str | None, Form()] = None,
    expected_mrn: Annotated[str | None, Form()] = None,
    expected_dob: Annotated[str | None, Form()] = None,
    expected_name: Annotated[str | None, Form()] = None,
    expected_label_text: Annotated[str | None, Form()] = None,
    origin_site_id: Annotated[str | None, Form()] = None,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)] = None,
    db: Session = Depends(get_db),
):
    """Create a Bloom tube (and optional specimen) from a shipment entrypoint."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest
    from app.domain.services.shipments import ShipmentService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    shipment_result = ShipmentService(db, current_user.tenant_id).get_by_shipment_number(
        shipment_number,
        cross_tenant=cross_tenant,
    )
    if not shipment_result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shipment not found")
    shipment, _revision = shipment_result
    if shipment.tenant_id != current_user.tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Cross-tenant write forbidden"
        )

    patient_euid = (patient_euid or "").strip() or None
    testkit_euid = (testkit_euid or "").strip() or None
    site_euid = (site_euid or "").strip() or None
    collection_site_euid = (collection_site_euid or "").strip() or None
    origin_site_id = (origin_site_id or "").strip() or None
    collected_at_dt = (
        datetime.fromisoformat(collected_at.strip())
        if collected_at and collected_at.strip()
        else None
    )

    request_key = (
        f"atlas:shipment-add-specimen:{shipment.euid}:{test_euid.strip()}:"
        f"{patient_euid or 'none'}:{testkit_euid or 'none'}:{site_euid or 'none'}:{origin_site_id or 'none'}"
    )

    bridge = ContainerSpecimenBridgeService(db, shipment.tenant_id)
    try:
        result = bridge.create_tube_with_optional_specimen(
            TubeCreationRequest(
                test_euid=test_euid.strip(),
                patient_euid=patient_euid,
                shipment_euid=shipment.euid,
                testkit_euid=testkit_euid,
                site_euid=site_euid,
                collection_site_euid=collection_site_euid,
                collected_at=collected_at_dt,
                collection_type=(collection_type or "").strip() or None,
                collected_by=(collected_by or "").strip() or None,
                expected_mrn=(expected_mrn or "").strip() or None,
                expected_dob=(expected_dob or "").strip() or None,
                expected_name=(expected_name or "").strip() or None,
                expected_label_text=(expected_label_text or "").strip() or None,
                origin_site_id=origin_site_id,
                idempotency_key=request_key,
            ),
            actor_id=current_user.sub_uuid,
        )
        db.commit()
        if result.specimen_euid:
            flash(request, "Bloom tube and specimen added to shipment.", "success")
        else:
            flash(request, "Bloom tube added to shipment.", "success")
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
        return RedirectResponse(
            url="/shipments",
            status_code=status.HTTP_303_SEE_OTHER,
        )

    safe_shipment_num = str(shipment.shipment_number)
    return RedirectResponse(
        url=_safe_redirect_url(f"/shipments/{safe_shipment_num}"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.get("/shipments/{shipment_number}/search/testkits", response_class=HTMLResponse)
async def shipments_search_testkits(
    request: Request,
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    q: str = Query(""),
):
    """Search testkits for adding to shipment (HTMX partial)."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import ShipmentService, TestKitService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ShipmentService(db, current_user.tenant_id)
    result = svc.get_by_shipment_number(shipment_number, cross_tenant=cross_tenant)
    if not result:
        return HTMLResponse("<div class='text-error'>Shipment not found</div>")

    shipment, _ = result

    # Get current contents to exclude
    current_contents = svc.get_contents(shipment.euid)
    current_kit_ids = {item["id"] for item in current_contents if item["type"] == "TestKit"}

    # Search for testkits
    kit_svc = TestKitService(db, current_user.tenant_id)
    kits = kit_svc.list_kits(limit=20, cross_tenant=cross_tenant)

    # Filter by search query and exclude already-added
    available = []
    for kit in kits:
        if kit.euid not in current_kit_ids:
            label = _testkit_display_label(kit)
            if not q or q.lower() in label.lower() or q.lower() in kit.euid.lower():
                available.append(kit)
                if len(available) >= 10:
                    break

    from markupsafe import escape as html_escape

    html = '<div class="search-results">'
    if not available:
        html += '<div class="text-muted p-sm">No matching testkits found</div>'
    else:
        csrf_token = get_csrf_token(request)
        safe_shipment = html_escape(shipment_number)
        for kit in available:
            safe_label = html_escape(_testkit_display_label(kit))
            safe_euid = html_escape(kit.euid)
            safe_csrf = html_escape(csrf_token)
            html += f'''
            <div class="search-result-item" style="display: flex; justify-content: space-between; align-items: center; padding: 0.5rem; border-bottom: 1px solid var(--border-color);">
                <div><code>{safe_label}</code></div>
                <form method="POST" action="/shipments/{safe_shipment}/add-existing-kit" style="margin: 0;">
                    <input type="hidden" name="csrf_token" value="{safe_csrf}">
                    <input type="hidden" name="testkit_id" value="{safe_euid}">
                    <button type="submit" class="btn btn-sm btn-primary">Add</button>
                </form>
            </div>
            '''
    html += "</div>"
    return HTMLResponse(html)


@router.post("/shipments/{shipment_number}/add-existing-kit", dependencies=[Depends(csrf_protect)])
async def shipments_add_existing_kit(
    request: Request,
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Add an existing testkit to a shipment."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import ShipmentService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    form_data = await request.form()
    testkit_id = form_data.get("testkit_id")

    if not testkit_id:
        flash(request, "No test kit selected", "error")
        return RedirectResponse(url="/shipments", status_code=status.HTTP_303_SEE_OTHER)

    try:
        svc = ShipmentService(db, current_user.tenant_id)
        result = svc.get_by_shipment_number(shipment_number, cross_tenant=cross_tenant)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shipment not found")

        shipment, _ = result
        svc.add_item(
            shipment.euid,
            "TestKit",
            str(testkit_id),
            reason="Added via web interface",
            created_by=current_user.sub_uuid,
        )
        flash(request, "Test kit added to shipment", "success")
        safe_shipment_num = str(shipment.shipment_number)
    except Exception as e:
        logger.error("Error adding test kit: %s", e, exc_info=True)
        flash(request, "An error occurred while adding test kit. Please try again.", "error")
        safe_shipment_num = _seg(shipment_number)

    return RedirectResponse(
        url=_safe_redirect_url(f"/shipments/{safe_shipment_num}"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/shipments/{shipment_number}/remove-item", dependencies=[Depends(csrf_protect)])
async def shipments_remove_item(
    request: Request,
    shipment_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Remove an item (TestKit) from a shipment."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import ShipmentService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    form_data = await request.form()
    item_type = form_data.get("item_type")
    item_id = form_data.get("item_id")
    reason = form_data.get("reason", "Removed via web interface")

    if not item_type or not item_id:
        flash(request, "Missing item information", "error")
        return RedirectResponse(url="/shipments", status_code=status.HTTP_303_SEE_OTHER)

    try:
        svc = ShipmentService(db, current_user.tenant_id)
        result = svc.get_by_shipment_number(shipment_number, cross_tenant=cross_tenant)
        if not result:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Shipment not found")

        shipment, _ = result
        svc.remove_item(
            shipment.euid,
            item_type,
            uuid.UUID(item_id),
            reason=reason,
            created_by=current_user.sub_uuid,
        )
        flash(request, f"{item_type} removed from shipment", "success")
    except Exception as e:
        logger.error("Error removing item: %s", e, exc_info=True)
        flash(request, "An error occurred while removing item. Please try again.", "error")

    safe_shipment_num = str(shipment.shipment_number)
    return RedirectResponse(
        url=_safe_redirect_url(f"/shipments/{safe_shipment_num}"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


# --- Intake (Internal Only) ---


@router.get("/intake", response_class=HTMLResponse)
async def intake_scan(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    barcode: str | None = None,
):
    """Scan & Match page."""
    ctx = get_template_context(request, current_user, db)
    ctx["exception_count"] = 0
    ctx["scan_result"] = None
    ctx["candidates"] = []

    if barcode:
        # Would perform actual scan
        ctx["scan_result"] = {
            "found": True,
            "entity_type": "TestKit",
            "entity_id": "123",
            "barcode": barcode,
            "details": {"status": "RECEIVED"},
        }

    return templates.TemplateResponse(request, "intake/scan_match.html", context=ctx)


@router.post("/intake/scan", response_class=HTMLResponse, dependencies=[Depends(csrf_protect)])
async def intake_scan_post(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    """Scan a barcode and identify the item (HTMX endpoint).

    Step 6.3: Intake scan + match endpoints.
    """

    from app.domain.services.intake import IntakeService

    ctx = get_template_context(request, current_user, db)

    form_data = await request.form()
    barcode = form_data.get("barcode", "").strip()

    if not barcode:
        ctx["scan_result"] = {"found": False, "barcode": ""}
        ctx["candidates"] = []
        return templates.TemplateResponse(request, "intake/_scan_result.html", context=ctx)

    from app.auth.rbac import Permission, has_permission

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    intake_svc = IntakeService(db, current_user.tenant_id)
    scan_result = intake_svc.scan_barcode(barcode, cross_tenant=cross_tenant)

    if not scan_result.found:
        ctx["scan_result"] = {"found": False, "barcode": barcode}
        ctx["candidates"] = []
        return templates.TemplateResponse(request, "intake/_scan_result.html", context=ctx)

    # Build template-compatible scan_result
    ctx["scan_result"] = {
        "found": True,
        "entity_type": scan_result.entity_type,
        "entity_id": str(scan_result.entity_id),
        "barcode": barcode,
        "details": scan_result.entity_details or {},
    }
    ctx["candidates"] = []

    db.commit()
    return templates.TemplateResponse(request, "intake/_scan_result.html", context=ctx)


# NOTE: Legacy intake matching POST route removed; matching is Bloom-owned.


@router.get("/intake/exceptions", response_class=HTMLResponse)
async def intake_exceptions(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    type_filter: str | None = Query(None, alias="type"),
):
    """Exception queue page.

    Step 6.3: Implement using ExceptionService.list_exceptions.
    """
    from app.auth.rbac import Permission, has_permission
    from app.domain.enums import ExceptionStatus
    from app.domain.services.exceptions import ExceptionService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)
    ctx["type_filter"] = type_filter

    exception_svc = ExceptionService(db, current_user.tenant_id, current_user.sub)
    all_exceptions = exception_svc.list_exceptions(
        limit=500,
        exception_type_filter=type_filter,
        cross_tenant=cross_tenant,
    )

    # Compute stats
    stats = {"unmatched": 0, "received_pending": 0, "mia": 0}
    for _exc, rev in all_exceptions:
        if (
            rev.status != ExceptionStatus.RESOLVED.value
            and rev.status != ExceptionStatus.CLOSED.value
        ):
            if rev.exception_type == "NO_MATCH":
                stats["unmatched"] += 1
            elif rev.exception_type == "RECEIVED_NO_ORDER":
                stats["received_pending"] += 1
            elif rev.exception_type == "MIA":
                stats["mia"] += 1

    ctx["stats"] = stats
    ctx["exceptions"] = [
        {
            "exception_number": exc.exception_number,
            "exception_type": rev.exception_type,
            "status": rev.status,
            "created_at": exc.created_at,
            "external_object_id": rev.external_object_id,
            "order_id": rev.order_id,
            "note": rev.note,
        }
        for exc, rev in all_exceptions
    ]
    return templates.TemplateResponse(request, "intake/exception_queue.html", context=ctx)


@router.get("/intake/print", response_class=HTMLResponse)
async def intake_print_labels(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    """Barcode label printing page."""
    from app.domain.services.barcode_printing import BarcodePrintService

    ctx = get_template_context(request, current_user, db)

    svc = BarcodePrintService(db, current_user.tenant_id, current_user.sub)
    printers = svc.get_configured_printers()

    ctx["service_available"] = svc.is_available()
    ctx["printer_count"] = len(printers)
    ctx["printers"] = [
        {
            "name": p.name,
            "ip_address": p.ip_address,
            "model": p.model,
            "lab": p.lab,
            "available_label_styles": p.available_label_styles,
        }
        for p in printers
    ]
    return templates.TemplateResponse(request, "intake/print_labels.html", context=ctx)


# --- Results ---


@router.get("/results", response_class=HTMLResponse)
async def results_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Results list page."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.releases import ReleaseService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)

    # Fetch releases from service
    svc = ReleaseService(db, current_user.tenant_id)
    releases_data = svc.list_packages(limit=100, cross_tenant=cross_tenant)

    releases = []
    for package, revision in releases_data:
        releases.append(
            {
                "id": str(package.euid),
                "package_number": package.package_number,
                "order_id": str(package.order_id) if package.order_id else None,
                "status": revision.status if revision else "DRAFT",
                "released_at": revision.released_at if revision else None,
                "created_at": package.created_at,
            }
        )

    ctx["releases"] = releases
    return templates.TemplateResponse(request, "results/list.html", context=ctx)


@router.get("/results/create", response_class=HTMLResponse)
async def results_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    """Release package creation form (internal staff only)."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.trfs import TrfService

    ctx = get_template_context(request, current_user, db)

    # Get orders — internal staff see all tenants
    order_svc = TrfService(db, current_user.tenant_id)
    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    orders_data = order_svc.list_trfs(limit=100, cross_tenant=cross_tenant)

    # Extract just the Order objects for the template
    ctx["orders"] = [order for order, revision in orders_data]
    ctx["artifacts"] = []
    return templates.TemplateResponse(request, "results/create.html", context=ctx)


@router.post("/results/create", dependencies=[Depends(csrf_protect)])
async def results_create_submit(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
    order_id: str = Form(...),
    artifact_ids: list[str] = Form([]),
    release_notes: str | None = Form(None),
    action: str = Form("draft"),
):
    """Create a release package (internal staff only)."""
    from app.domain.enums import ReleasePackageStatus
    from app.domain.services.releases import ReleasePackageCreate, ReleaseService

    svc = ReleaseService(db, current_user.tenant_id)

    # Create the package
    package = svc.create_package(
        ReleasePackageCreate(
            order_id=order_id,
            artifact_ids=artifact_ids or [],
            release_notes=release_notes,
        ),
        created_by=current_user.user_id,
    )

    # If action is "approve", change status to APPROVED
    if action == "approve":
        svc.change_status(
            package.euid,
            ReleasePackageStatus.APPROVED,
            reason="Approved upon creation",
            updated_by=current_user.user_id,
        )

    safe_package_num = str(package.package_number)
    # Redirect using human-readable package_number
    return RedirectResponse(
        url=_safe_redirect_url(f"/results/{safe_package_num}"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.get("/results/{package_number}", response_class=HTMLResponse)
async def results_detail(
    request: Request,
    package_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Release package detail page. Uses human-readable package_number in URL."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.releases import ReleaseService
    from app.domain.services.trfs import TrfService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)

    svc = ReleaseService(db, current_user.tenant_id)
    result = svc.get_by_package_number(package_number, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Release package {package_number} not found",
        )

    package, revision = result

    # Get artifacts
    artifacts = svc.get_artifacts(package.euid) if package else []

    ctx["release"] = {
        "id": str(package.euid),
        "package_number": package.package_number,
        "status": revision.status if revision else "DRAFT",
        "release_notes": revision.release_notes if revision else None,
        "released_at": revision.released_at if revision else None,
        "created_at": package.created_at,
    }

    # Get associated order
    ctx["order"] = None
    if package.order_id:
        order_svc = TrfService(db, current_user.tenant_id)
        order_result = order_svc.get_by_id(package.order_id, cross_tenant=cross_tenant)
        if order_result:
            order, _order_rev = order_result
            ctx["order"] = {
                "id": str(order.euid),
                "order_number": order.order_number,
            }

    ctx["artifacts"] = [
        {
            "id": str(a.euid),
            "filename": a.filename,
            "source_system": a.source_system,
            "artifact_type": a.artifact_type,
            "size_bytes": a.size_bytes,
        }
        for a in artifacts
    ]

    return templates.TemplateResponse(request, "results/detail.html", context=ctx)


@router.get("/results/{package_number}/artifacts/{artifact_id}/download")
async def results_artifact_download(
    request: Request,
    package_number: str,
    artifact_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Download a single artifact from a release package."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.enums import AuditAction
    from app.domain.services.audit import AuditService
    from app.domain.services.releases import ReleaseService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ReleaseService(db, current_user.tenant_id)

    # Verify the package exists and is released
    result = svc.get_by_package_number(package_number, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Release package {package_number} not found",
        )

    package, revision = result
    if revision.status != "RELEASED":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Package has not been released yet",
        )

    safe_package_num = str(package.package_number)

    # Get the artifact
    artifact = svc.get_artifact(artifact_id, cross_tenant=cross_tenant)
    if not artifact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Artifact not found",
        )

    # Log the download (PHI-sensitive operation).
    AuditService(db, tenant_id=package.tenant_id, user_id=current_user.sub).log(
        action=AuditAction.DOWNLOAD,
        entity_type="Artifact",
        entity_id=artifact.euid,
        details={
            "filename": artifact.filename,
            "artifact_type": artifact.artifact_type,
            "package_number": package_number,
        },
        user_id=current_user.sub_uuid,
    )
    db.commit()

    # In production, this would redirect to a presigned S3 URL
    # For now, return a placeholder response
    if artifact.storage_uri and artifact.storage_uri.startswith("s3://"):
        # Would generate presigned URL here
        flash(request, f"Download initiated for {artifact.filename}", "info")
        return RedirectResponse(
            url=_safe_redirect_url(f"/results/{safe_package_num}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    else:
        flash(request, "Artifact storage not configured", "warning")
        return RedirectResponse(
            url=_safe_redirect_url(f"/results/{safe_package_num}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )


@router.get("/results/{package_number}/download-all")
async def results_download_all(
    request: Request,
    package_number: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Download all artifacts from a release package as a ZIP."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.enums import AuditAction
    from app.domain.services.audit import AuditService
    from app.domain.services.releases import ReleaseService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    svc = ReleaseService(db, current_user.tenant_id)

    # Verify the package exists and is released
    result = svc.get_by_package_number(package_number, cross_tenant=cross_tenant)
    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Release package {package_number} not found",
        )

    package, revision = result
    if revision.status != "RELEASED":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Package has not been released yet",
        )

    safe_package_num = str(package.package_number)

    # Get all artifacts
    artifacts = svc.get_artifacts(package.euid)

    # Log the bulk download (PHI-sensitive operation).
    AuditService(db, tenant_id=package.tenant_id, user_id=current_user.sub).log(
        action=AuditAction.DOWNLOAD,
        entity_type="ReleasePackage",
        entity_id=package.euid,
        details={
            "package_number": package_number,
            "artifact_count": len(artifacts),
            "action": "download_all",
        },
        user_id=current_user.sub_uuid,
    )
    db.commit()

    # In production, this would generate a ZIP and redirect to presigned URL
    # For now, return a placeholder response
    flash(request, f"Bulk download initiated for {len(artifacts)} files", "info")
    return RedirectResponse(
        url=_safe_redirect_url(f"/results/{safe_package_num}"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


# --- Results Sets (Step 8) ---


@router.get("/results-sets", response_class=HTMLResponse)
async def results_sets_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Results sets list page (Step 8.2).

    Internal users see all results sets.
    External users see only published results sets.
    """

    from app.domain.services.fulfillment_runs import ResultsSetService
    from app.domain.services.trfs import TrfService

    ctx = get_template_context(request, current_user, db)
    ctx["current_user"] = current_user
    trf_svc = TrfService(db, current_user.tenant_id)
    rs_svc = ResultsSetService(db, current_user.tenant_id)

    results_sets: list[dict[str, object]] = []
    trfs = trf_svc.list_trfs(limit=5000, cross_tenant=False)
    for trf, _trf_rev in trfs:
        for rs in rs_svc.list_for_trf(trf.euid, include_unpublished=True):
            if not current_user.is_internal and rs.published_at is None:
                continue
            fulfillment_run_count = len(rs_svc.get_fulfillment_runs_for_results_set(rs.euid))
            results_sets.append(
                {
                    "id": rs.euid,
                    "test_euid": rs.test_euid,
                    "order_number": trf.order_number,
                    "fulfillment_run_count": fulfillment_run_count,
                    "published_at": rs.published_at.strftime("%Y-%m-%d %H:%M")
                    if rs.published_at
                    else None,
                    "published_by": str(rs.published_by) if rs.published_by else None,
                    "created_at": rs.created_at.strftime("%Y-%m-%d %H:%M")
                    if rs.created_at
                    else None,
                }
            )

    results_sets.sort(
        key=lambda item: str(item.get("created_at") or ""),
        reverse=True,
    )

    ctx["results_sets"] = results_sets
    return templates.TemplateResponse(request, "results/sets.html", context=ctx)


@router.get("/results-sets/{results_set_id}", response_class=HTMLResponse)
async def results_set_detail(
    request: Request,
    results_set_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Results set detail page (Step 8.2)."""
    import json

    from app.auth.rbac import Permission, has_permission
    from app.domain.services.fulfillment_runs import (
        FulfillmentOutputService,
        FulfillmentRunService,
        ResultsSetService,
    )
    from app.domain.services.releases import ReleaseService
    from app.domain.services.trfs import TestService, TrfService
    from app.persistence.tapdb.fulfillment_run_repo import TapdbFulfillmentRunRepository

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)
    ctx["current_user"] = current_user

    if cross_tenant:
        rs = TapdbFulfillmentRunRepository(db).get_results_set_by_euid(
            results_set_euid=results_set_id,
            tenant_id=None,
        )
    else:
        rs = ResultsSetService(db, current_user.tenant_id).get(results_set_id)
    if not rs:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Results set not found",
        )

    if not current_user.is_internal and rs.published_at is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Results set has not been published yet",
        )

    tenant_scope = rs.tenant_id if cross_tenant else current_user.tenant_id
    test_svc = TestService(db, tenant_scope)
    test_obj = test_svc.get_by_id(rs.test_euid, cross_tenant=cross_tenant)
    if not test_obj:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Test not found",
        )

    order_svc = TrfService(db, tenant_scope)
    order_result = order_svc.get_by_id(test_obj.order_id, cross_tenant=cross_tenant)
    if not order_result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found",
        )
    order, _order_rev = order_result

    rs_svc = ResultsSetService(db, tenant_scope)
    assay_svc = FulfillmentRunService(db, tenant_scope)
    result_svc = FulfillmentOutputService(db, tenant_scope)
    release_svc = ReleaseService(db, tenant_scope)

    assays: list[dict[str, object]] = []
    for run in rs_svc.get_fulfillment_runs_for_results_set(rs.euid):
        run_result = assay_svc.get(run.euid)
        run_revision = run_result[1] if run_result else None
        latest_result = result_svc.get_latest_for_assay_run(run.euid)

        result_artifacts: list[dict[str, str | None]] = []
        if latest_result and latest_result.artifact_ids:
            for artifact_id in latest_result.artifact_ids:
                artifact = release_svc.get_artifact_by_id(artifact_id, cross_tenant=cross_tenant)
                if artifact:
                    result_artifacts.append(
                        {
                            "id": artifact.euid,
                            "filename": artifact.filename,
                            "artifact_type": artifact.artifact_type,
                        }
                    )

        assays.append(
            {
                "id": run.euid,
                "fulfillment_route_code": run.fulfillment_route_code,
                "status": run_revision.status if run_revision else None,
                "accession_id": run_revision.accession_id if run_revision else None,
                "result": {
                    "id": latest_result.euid,
                    "version_no": latest_result.version_no,
                    "payload_pretty": json.dumps(latest_result.result_payload, indent=2)
                    if latest_result.result_payload
                    else "{}",
                    "artifacts": result_artifacts,
                }
                if latest_result
                else None,
            }
        )

    ctx["results_set"] = {
        "id": rs.euid,
        "test_euid": rs.test_euid,
        "published_at": rs.published_at.strftime("%Y-%m-%d %H:%M") if rs.published_at else None,
        "published_by": str(rs.published_by) if rs.published_by else None,
        "note": rs.note,
        "created_at": rs.created_at.strftime("%Y-%m-%d %H:%M") if rs.created_at else None,
    }
    ctx["order"] = {"id": order.euid, "order_number": order.order_number}
    ctx["assays"] = assays
    ctx["fulfillment_routes"] = assays

    return templates.TemplateResponse(request, "results/set_detail.html", context=ctx)


@router.post(
    "/results-sets/{results_set_euid}/publish",
    dependencies=[Depends(csrf_protect), Depends(require_internal)],
)
async def results_set_publish(
    request: Request,
    results_set_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Publish a release bundle (internal only, Step 8.2)."""
    from app.domain.services.fulfillment_runs import ResultsSetService

    try:
        svc = ResultsSetService(db, current_user.tenant_id)
        rs = svc.publish(results_set_euid, published_by=current_user.sub_uuid)  # noqa: F841
        db.commit()

        safe_rs_id = str(rs.euid)

        # TODO: Step 9 - Emit webhook results_set_published

        flash(request, "Release bundle published successfully", "success")
        return RedirectResponse(
            url=_safe_redirect_url(f"/results-sets/{safe_rs_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except ValueError as e:
        db.rollback()
        logger.error("Error: %s", e, exc_info=True)
        flash(request, "An error occurred. Please try again.", "error")
        return RedirectResponse(
            url="/results-sets",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    except Exception as e:
        db.rollback()
        logger.error("Error publishing release bundle: %s", e, exc_info=True)
        flash(
            request,
            "An error occurred while publishing release bundle. Please try again.",
            "error",
        )
        return RedirectResponse(
            url="/results-sets",
            status_code=status.HTTP_303_SEE_OTHER,
        )


# --- Exception Queue (Internal Only) ---


@router.get(
    "/exceptions",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
    deprecated=True,
)
async def exceptions_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    status: str | None = Query(None),
    exception_type: str | None = Query(None),
):
    """Deprecated GUI route. Use intake exception queue pages instead."""
    _raise_deprecated_gui_route(route_path="/exceptions", replacement_path="/intake/exceptions")


@router.get(
    "/exceptions/{exception_number}",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
    deprecated=True,
)
async def exception_detail(
    exception_number: str,
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Deprecated GUI route. Use intake exception queue pages instead."""
    _raise_deprecated_gui_route(
        route_path=f"/exceptions/{exception_number}", replacement_path="/intake/exceptions"
    )


@router.post(
    "/exceptions/{exception_number}/assign",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal), Depends(csrf_protect)],
    deprecated=True,
)
async def exception_assign(
    exception_number: str,
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Deprecated GUI route. Use intake exception queue pages instead."""
    _raise_deprecated_gui_route(
        route_path=f"/exceptions/{exception_number}/assign",
        replacement_path="/intake/exceptions",
    )


@router.post(
    "/exceptions/{exception_number}/resolve",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal), Depends(csrf_protect)],
    deprecated=True,
)
async def exception_resolve(
    exception_number: str,
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    resolution_notes: str = Form(...),
):
    """Deprecated GUI route. Use intake exception queue pages instead."""
    _raise_deprecated_gui_route(
        route_path=f"/exceptions/{exception_number}/resolve",
        replacement_path="/intake/exceptions",
    )


@router.post(
    "/exceptions/{exception_number}/escalate",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal), Depends(csrf_protect)],
    deprecated=True,
)
async def exception_escalate(
    exception_number: str,
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Deprecated GUI route. Use intake exception queue pages instead."""
    _raise_deprecated_gui_route(
        route_path=f"/exceptions/{exception_number}/escalate",
        replacement_path="/intake/exceptions",
    )


@router.post(
    "/exceptions/{exception_number}/close",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal), Depends(csrf_protect)],
    deprecated=True,
)
async def exception_close(
    exception_number: str,
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Deprecated GUI route. Use intake exception queue pages instead."""
    _raise_deprecated_gui_route(
        route_path=f"/exceptions/{exception_number}/close",
        replacement_path="/intake/exceptions",
    )


# --- Test Kits (Writable Users) ---


@router.get(
    "/testkits", response_class=HTMLResponse, dependencies=[Depends(require_read_write_web)]
)
async def testkits_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    barcode: str | None = Query(None),
    kit_type: str | None = Query(None),
    status_filter: str | None = Query(None, alias="status"),
):
    """List test kits."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import TestKitService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)

    kit_svc = TestKitService(db, current_user.tenant_id)
    kits = kit_svc.list_kits(limit=100, cross_tenant=cross_tenant)

    # Enrich with revision data and apply filters
    enriched_kits = []
    kit_types_set = set()
    for kit in kits:
        result = kit_svc.get_with_revision(kit.euid, cross_tenant=cross_tenant)
        if result:
            _, rev = result
            kit.kit_type = rev.kit_type
            kit.status = rev.status
            kit.expiration_date = rev.expiration_date

            if rev.kit_type:
                kit_types_set.add(rev.kit_type)

            # Apply filters
            if barcode:
                label = _testkit_display_label(kit).lower()
                if barcode.lower() not in label and barcode.lower() not in kit.euid.lower():
                    continue
            if kit_type and rev.kit_type != kit_type:
                continue
            if status_filter and rev.status != status_filter:
                continue

            enriched_kits.append(kit)

    ctx["testkits"] = enriched_kits
    ctx["kit_types"] = sorted(kit_types_set)
    ctx["total"] = len(enriched_kits)
    ctx["limit"] = 100
    ctx["filter"] = {
        "barcode": barcode,
        "kit_type": kit_type,
        "status": status_filter,
    }

    return templates.TemplateResponse(request, "testkits/list.html", context=ctx)


@router.get(
    "/testkits/create", response_class=HTMLResponse, dependencies=[Depends(require_read_write_web)]
)
async def testkits_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Show test kit creation form."""
    from app.domain.services.orgs import OrganizationService

    ctx = get_template_context(request, current_user, db)
    ctx["testkit"] = None
    ctx["kit_types"] = ["COLLECTION", "EXTRACTION", "SEQUENCING", "STORAGE"]
    org_result = OrganizationService(db).get_with_revision_by_uid(current_user.tenant_id)
    organization = org_result[0] if org_result else None
    site_options = _list_site_summaries(db, organization.euid) if organization else []
    ctx["site_options"] = site_options
    ctx["organization_euid"] = organization.euid if organization else None
    ctx["selected_origin_site_id"] = site_options[0]["id"] if len(site_options) == 1 else None
    return templates.TemplateResponse(request, "testkits/form.html", context=ctx)


@router.post(
    "/testkits/create",
    response_class=HTMLResponse,
    dependencies=[Depends(require_read_write_web), Depends(csrf_protect)],
)
async def testkits_create(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Create a new test kit."""
    from app.domain.services.orgs import OrganizationService, SiteService
    from app.domain.services.shipments import TestKitCreate, TestKitService

    form_data = await request.form()
    kit_barcode = form_data.get("kit_barcode", "").strip()
    kit_type = form_data.get("kit_type") or None
    origin_site_id = (form_data.get("origin_site_id") or "").strip() or None
    expiration_date_str = form_data.get("expiration_date", "").strip()

    if not kit_barcode:
        flash(request, "Kit barcode is required", "error")
        return RedirectResponse(url="/testkits/create", status_code=status.HTTP_303_SEE_OTHER)

    expiration_date = None
    if expiration_date_str:
        try:
            expiration_date = datetime.fromisoformat(expiration_date_str)
        except ValueError:
            flash(request, "Invalid expiration date format", "error")
            return RedirectResponse(url="/testkits/create", status_code=status.HTTP_303_SEE_OTHER)

    try:
        if origin_site_id:
            site = SiteService(db).get_by_id(origin_site_id)
            if site is None:
                raise ValueError("Origin site not found")
        svc = TestKitService(db, current_user.tenant_id)
        kit_data = TestKitCreate(
            kit_barcode=kit_barcode or None,
            kit_type=kit_type,
            origin_site_id=origin_site_id,
            expiration_date=expiration_date,
        )
        kit = svc.create(kit_data, created_by=current_user.sub_uuid)
        flash(request, f"Test kit {_testkit_display_label(kit)} created successfully", "success")
        safe_kit_id = str(kit.euid)
        return RedirectResponse(
            url=_safe_redirect_url(f"/testkits/{safe_kit_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    except Exception as e:
        logger.error("Error creating test kit: %s", e, exc_info=True)
        flash(request, "An error occurred while creating test kit. Please try again.", "error")
        org_result = OrganizationService(db).get_with_revision_by_uid(current_user.tenant_id)
        organization = org_result[0] if org_result else None
        site_options = _list_site_summaries(db, organization.euid) if organization else []
        ctx = get_template_context(request, current_user, db)
        ctx["testkit"] = None
        ctx["kit_types"] = ["COLLECTION", "EXTRACTION", "SEQUENCING", "STORAGE"]
        ctx["site_options"] = site_options
        ctx["organization_euid"] = organization.euid if organization else None
        ctx["selected_origin_site_id"] = origin_site_id
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "testkits/form.html", context=ctx)


@router.get(
    "/testkits/{testkit_id}",
    response_class=HTMLResponse,
    dependencies=[Depends(require_read_write_web)],
)
async def testkits_detail(
    request: Request,
    testkit_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Test kit detail page."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.shipments import TestKitService
    from app.domain.services.testkit_trf_links import TestKitTrfLinkService
    from app.domain.services.trfs import TrfService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    ctx = get_template_context(request, current_user, db)

    kit_svc = TestKitService(db, current_user.tenant_id)
    result = kit_svc.get_with_revision(testkit_id, cross_tenant=cross_tenant)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Test kit not found",
        )

    testkit, revision = result
    ctx["testkit"] = testkit
    ctx["revision"] = revision
    ctx["can_write_in_tenant"] = bool(testkit.tenant_id == current_user.tenant_id)
    ctx["origin_site"] = None
    ctx["origin_site_detail_path"] = None
    if getattr(revision, "origin_site_id", None):
        from app.domain.services.orgs import SiteService

        site = SiteService(db).get_by_id(revision.origin_site_id)
        if site and site.revisions:
            site_revision = site.revisions[-1]
            ctx["origin_site"] = {"id": site.euid, "name": site_revision.name}
            if current_user.is_internal or current_user.is_admin:
                ctx["origin_site_detail_path"] = f"/admin/sites/{site.euid}"
            else:
                ctx["origin_site_detail_path"] = f"/my-organization/sites/{site.euid}"

    # Material content lookup is Bloom-owned.
    ctx["specimens"] = []

    # Container/specimen containment history is Bloom-owned and not persisted in Atlas.
    ctx["containment_history"] = []
    ctx["containment_history_note"] = "Bloom-owned material history is not shown in Atlas."
    trf_links = TestKitTrfLinkService(db, testkit.tenant_id).list_linked_trfs(
        testkit_euid=testkit.euid
    )
    ctx["linked_trfs"] = [
        {
            "euid": row.trf_euid,
            "number": row.trf_number,
            "status": row.status,
            "linked_at": row.linked_at,
        }
        for row in trf_links
    ]

    ctx["trf_options"] = []
    ctx["test_options"] = []
    ctx["available_patients"] = []
    ctx["site_options"] = []
    if ctx["can_write_in_tenant"]:
        ctx["trf_options"] = [
            {
                "id": trf.euid,
                "number": trf.order_number,
                "status": trf_rev.status,
            }
            for trf, trf_rev in TrfService(db, testkit.tenant_id).list_trfs(
                limit=200,
                cross_tenant=False,
            )
        ]
        ctx["test_options"] = _list_tenant_test_summaries(db, testkit.tenant_id)
        ctx["available_patients"] = _list_patient_summaries(db, testkit.tenant_id)
        org_result = OrganizationService(db).get_with_revision_by_uid(testkit.tenant_id)
        organization = org_result[0] if org_result else None
        ctx["site_options"] = _list_site_summaries(db, organization.euid) if organization else []
        ctx["selected_origin_site_id"] = (
            ctx["site_options"][0]["id"] if len(ctx["site_options"]) == 1 else None
        )
        ctx.update(
            _build_tube_panel_context(
                db,
                testkit.tenant_id,
                anchor_type="TestKit",
                anchor_id=testkit.euid,
                return_to=f"/testkits/{testkit.euid}",
            )
        )
    else:
        ctx["tube_linked_rows"] = []

    return templates.TemplateResponse(request, "testkits/detail.html", context=ctx)


@router.post("/testkits/{testkit_id}/link-trf", dependencies=[Depends(csrf_protect)])
async def testkits_link_trf(
    request: Request,
    testkit_id: str,
    trf_euid: Annotated[str, Form()],
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)] = None,
    db: Session = Depends(get_db),
):
    """Link a TRF to a test kit (idempotent)."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import TestKitService
    from app.domain.services.testkit_trf_links import TestKitTrfLinkService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    testkit_result = TestKitService(db, current_user.tenant_id).get_with_revision(
        testkit_id, cross_tenant=cross_tenant
    )
    if testkit_result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Test kit not found")
    testkit, _revision = testkit_result
    if testkit.tenant_id != current_user.tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Cross-tenant write forbidden"
        )

    try:
        created = TestKitTrfLinkService(db, testkit.tenant_id).link_trf(
            testkit_euid=testkit.euid,
            trf_euid=trf_euid.strip(),
            created_by=current_user.sub_uuid,
        )
        db.commit()
        if created:
            flash(request, "TRF linked to test kit.", "success")
        else:
            flash(request, "TRF was already linked to this test kit.", "success")
        safe_kit_id = str(testkit.euid)
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
    return RedirectResponse(
        url=_safe_redirect_url(
            f"/testkits/{safe_kit_id}" if "safe_kit_id" in locals() else "/testkits"
        ),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/testkits/{testkit_id}/unlink-trf", dependencies=[Depends(csrf_protect)])
async def testkits_unlink_trf(
    request: Request,
    testkit_id: str,
    trf_euid: Annotated[str, Form()],
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)] = None,
    db: Session = Depends(get_db),
):
    """Unlink a TRF from a test kit (idempotent)."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.shipments import TestKitService
    from app.domain.services.testkit_trf_links import TestKitTrfLinkService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    testkit_result = TestKitService(db, current_user.tenant_id).get_with_revision(
        testkit_id, cross_tenant=cross_tenant
    )
    if testkit_result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Test kit not found")
    testkit, _revision = testkit_result
    if testkit.tenant_id != current_user.tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Cross-tenant write forbidden"
        )

    try:
        removed = TestKitTrfLinkService(db, testkit.tenant_id).unlink_trf(
            testkit_euid=testkit.euid,
            trf_euid=trf_euid.strip(),
            removed_by=current_user.sub_uuid,
        )
        db.commit()
        if removed:
            flash(request, "TRF unlinked from test kit.", "success")
        else:
            flash(request, "TRF link was already absent.", "success")
        safe_kit_id = str(testkit.euid)
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
    return RedirectResponse(
        url=_safe_redirect_url(
            f"/testkits/{safe_kit_id}" if "safe_kit_id" in locals() else "/testkits"
        ),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/testkits/{testkit_id}/create-bloom-tube", dependencies=[Depends(csrf_protect)])
async def testkits_create_bloom_tube(
    request: Request,
    testkit_id: str,
    test_euid: Annotated[str, Form()],
    patient_euid: Annotated[str | None, Form()] = None,
    origin_site_id: Annotated[str | None, Form()] = None,
    current_user: Annotated[CurrentUser, Depends(require_read_write_web)] = None,
    db: Session = Depends(get_db),
):
    """Create a Bloom tube from test kit detail and auto-link parent TRF."""
    from app.auth.rbac import Permission, has_permission
    from app.domain.services.bloom_bridge import ContainerSpecimenBridgeService, TubeCreationRequest
    from app.domain.services.shipments import TestKitService
    from app.domain.services.testkit_trf_links import TestKitTrfLinkService
    from app.domain.services.trfs import TestService

    cross_tenant = has_permission(current_user.roles, Permission.CROSS_TENANT_READ)
    testkit_result = TestKitService(db, current_user.tenant_id).get_with_revision(
        testkit_id, cross_tenant=cross_tenant
    )
    if testkit_result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Test kit not found")
    testkit, _revision = testkit_result
    if testkit.tenant_id != current_user.tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Cross-tenant write forbidden"
        )

    patient_euid = (patient_euid or "").strip() or None
    origin_site_id = (origin_site_id or "").strip() or None
    test_euid = test_euid.strip()
    request_key = (
        f"atlas:testkit-create-tube:{testkit.euid}:{test_euid}:{patient_euid or 'none'}:"
        f"{origin_site_id or 'none'}"
    )

    bridge = ContainerSpecimenBridgeService(db, testkit.tenant_id)
    trf_link_svc = TestKitTrfLinkService(db, testkit.tenant_id)
    try:
        result = bridge.create_tube_with_optional_specimen(
            TubeCreationRequest(
                test_euid=test_euid,
                patient_euid=patient_euid,
                shipment_euid=None,
                testkit_euid=testkit.euid,
                origin_site_id=origin_site_id,
                idempotency_key=request_key,
            ),
            actor_id=current_user.sub_uuid,
        )
        test = TestService(db, testkit.tenant_id).get_by_id(result.test_euid, cross_tenant=False)
        if test is None:
            raise ValueError(f"Test not found: {result.test_euid}")
        trf_link_svc.link_trf(
            testkit_euid=testkit.euid,
            trf_euid=str(test.order_id),
            created_by=current_user.sub_uuid,
        )
        db.commit()
        if result.specimen_euid:
            flash(request, "Bloom tube + specimen created and TRF linked to kit.", "success")
        else:
            flash(request, "Bloom tube created and TRF linked to kit.", "success")
        safe_kit_id = str(testkit.euid)
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
    return RedirectResponse(
        url=_safe_redirect_url(
            f"/testkits/{safe_kit_id}" if "safe_kit_id" in locals() else "/testkits"
        ),
        status_code=status.HTTP_303_SEE_OTHER,
    )


# NOTE: Legacy test-kit specimen routes removed; material ownership is Bloom-owned.


# --- Manifests (Internal Only) ---


@router.get(
    "/manifests",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
    deprecated=True,
)
async def manifests_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Deprecated GUI route."""
    _raise_deprecated_gui_route(route_path="/manifests", replacement_path="/documents")


@router.get("/manifests/template.csv", deprecated=True)
async def manifest_template_download():
    """Deprecated GUI route."""
    _raise_deprecated_gui_route(route_path="/manifests/template.csv", replacement_path="/documents")


@router.get(
    "/manifests/upload",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
    deprecated=True,
)
async def manifest_upload_page(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Deprecated GUI route."""
    _raise_deprecated_gui_route(
        route_path="/manifests/upload", replacement_path="/documents/upload"
    )


@router.post(
    "/manifests/upload",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal), Depends(csrf_protect)],
    deprecated=True,
)
async def manifest_upload(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    file: bytes = File(...),
    shipment_id: str | None = Form(None),
):
    """Deprecated GUI route."""
    _raise_deprecated_gui_route(
        route_path="/manifests/upload", replacement_path="/documents/upload"
    )


@router.get(
    "/manifests/{manifest_number}",
    response_class=HTMLResponse,
    dependencies=[Depends(require_internal)],
    deprecated=True,
)
async def manifest_detail(
    manifest_number: str,
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Deprecated GUI route."""
    _raise_deprecated_gui_route(
        route_path=f"/manifests/{manifest_number}", replacement_path="/documents"
    )


# --- Documents (Internal Only) ---


# Document upload handler removed - consolidated into documents_upload_submit below


# --- Admin (Admin Only) ---


def require_admin(current_user: CurrentUser = Depends(get_current_user_web)) -> CurrentUser:
    """Require admin role."""
    if not current_user.is_admin:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Admin access required")
    return current_user


@router.get("/admin", response_class=HTMLResponse)
async def admin_index(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Admin dashboard."""
    import importlib.metadata as importlib_metadata
    import os

    def _dependency_meta(package: str, description: str) -> dict[str, str]:
        try:
            version = importlib_metadata.version(package)
            return {
                "package": package,
                "description": description,
                "version": version,
                "status": "available",
            }
        except importlib_metadata.PackageNotFoundError:
            return {
                "package": package,
                "description": description,
                "version": "Not installed",
                "status": "missing",
            }

    ctx = get_template_context(request, current_user, db)
    ctx["stats"] = {"organizations": 0, "users": 0, "orders_today": 0, "pending_releases": 0}
    ctx["recent_activity"] = []
    ctx["interface_links"] = [
        {"label": "TapDB GUI", "url": "/tapdb", "external": False},
        {"label": "Atlas API Docs", "url": "/api/docs", "external": False},
        {"label": "LIMS", "url": settings.lims_ui_url, "external": True},
        {"label": "Bloom", "url": settings.bloom_ui_url, "external": True},
        {"label": "Analysis", "url": settings.analysis_ui_url, "external": True},
    ]
    ctx["dependency_info"] = [
        _dependency_meta("daylily-tapdb", "Templated Abstract Polymorphic Database library"),
        _dependency_meta("zebra-day", "Zebra printer fleet management and ZPL label printing"),
        _dependency_meta("daylily-carrier-tracking", "Carrier tracking integration library"),
    ]
    ctx["tapdb_runtime"] = {
        "env": os.environ.get("TAPDB_ENV", ""),
        "database_name": os.environ.get("TAPDB_DATABASE_NAME", ""),
        "client_id": os.environ.get("TAPDB_CLIENT_ID", ""),
        "config_path": os.environ.get("TAPDB_CONFIG_PATH", ""),
    }
    return templates.TemplateResponse(request, "admin/index.html", context=ctx)


@router.get("/admin/settings", response_class=HTMLResponse)
async def admin_settings(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Settings page for theme selection and preferences."""
    from app.api.routes.themes import AVAILABLE_FONT_CHOICES, AVAILABLE_THEMES
    from app.persistence.tapdb.themes import TapdbThemeRepository

    ctx = get_template_context(request, current_user, db)

    # Get current theme from TapDB
    state = TapdbThemeRepository(db).get_current_theme(current_user.tenant_id)
    current_theme = state.theme
    theme_css_path = "/static/css/theme.css"
    if current_theme != "default":
        theme_css_path = f"/static/css/themes/{current_theme}.css"

    ctx["current_theme"] = current_theme
    ctx["current_font"] = state.font_choice
    ctx["theme_css_path"] = theme_css_path
    ctx["themes"] = AVAILABLE_THEMES
    ctx["font_choices"] = AVAILABLE_FONT_CHOICES
    ctx["user_roles"] = current_user.roles if hasattr(current_user, "roles") else []

    # API Token management section
    import uuid as uuid_module

    from app.domain.services.user_api_tokens import UserAPITokenService

    user_id = uuid_module.UUID(current_user.sub) if current_user.sub else None
    token_svc = UserAPITokenService(db, current_user.tenant_id)

    ctx["has_api_access"] = token_svc.user_has_api_access(user_id) if user_id else False
    ctx["api_tokens"] = (
        token_svc.list_user_tokens(user_id) if user_id and ctx["has_api_access"] else []
    )

    return templates.TemplateResponse(request, "admin/settings.html", context=ctx)


@router.post("/admin/settings/refresh-session", dependencies=[Depends(csrf_protect)])
async def admin_refresh_session(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Refresh current session with roles from database."""
    from app.domain.services.users import UserService

    user_svc = UserService(db, current_user.sub)

    # Try to find user by cognito_sub first
    user = user_svc.get_by_cognito_sub(current_user.sub)

    # If not found, try by email (fallback for dev mode)
    if not user:
        user = user_svc.get_by_email(current_user.email)

    if user:
        # Update session with roles from database
        request.session["roles"] = user.roles
        request.session["name"] = user.name
        request.session["email"] = user.email
        # Also update the user_sub to match the database cognito_sub
        request.session["user_sub"] = user.cognito_sub
        flash(request, "Session refreshed successfully.", "success")
    else:
        logger.warning(
            "Session refresh failed: user not found in database. sub=%s email=%s",
            current_user.sub[:20],
            current_user.email,
        )
        flash(
            request,
            "Unable to refresh session. Please try logging out and back in.",
            "error",
        )

    return RedirectResponse(url="/admin/settings", status_code=status.HTTP_303_SEE_OTHER)


# --- User API Tokens ---


@router.post("/admin/settings/api-tokens", dependencies=[Depends(csrf_protect)])
async def create_user_api_token(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Create a new user API token."""
    import uuid as uuid_module

    from app.domain.services.user_api_tokens import TokenCreate, UserAPITokenService

    user_id = uuid_module.UUID(current_user.sub)
    token_svc = UserAPITokenService(db, current_user.tenant_id)

    # Check API_ACCESS group membership
    if not token_svc.user_has_api_access(user_id):
        flash(request, "API_ACCESS group membership required to create tokens", "error")
        return RedirectResponse(url="/admin/settings", status_code=status.HTTP_303_SEE_OTHER)

    form_data = await request.form()
    token_name = form_data.get("token_name", "").strip()
    expires_in_days = int(form_data.get("expires_in_days", 90))
    scope = form_data.get("scope", "ext_org").strip()

    if not token_name:
        flash(request, "Token name is required", "error")
        return RedirectResponse(url="/admin/settings", status_code=status.HTTP_303_SEE_OTHER)

    if expires_in_days < 1 or expires_in_days > 365:
        flash(request, "Expiration must be between 1 and 365 days", "error")
        return RedirectResponse(url="/admin/settings", status_code=status.HTTP_303_SEE_OTHER)

    # Validate scope for the user's roles
    if not token_svc.validate_scope_for_creator(scope, current_user.roles):
        flash(request, f"Your roles do not permit creating tokens with scope '{scope}'", "error")
        return RedirectResponse(url="/admin/settings", status_code=status.HTTP_303_SEE_OTHER)

    token, revision, plaintext_token = token_svc.create(
        user_id=user_id,
        data=TokenCreate(token_name=token_name, expires_in_days=expires_in_days, scope=scope),
        created_by=user_id,
    )

    # Show the token (only shown once)
    ctx = get_template_context(request, current_user, db)
    ctx["token"] = token
    ctx["revision"] = revision
    ctx["plaintext_token"] = plaintext_token
    # Build base URL - use http for localhost, respect X-Forwarded-Proto otherwise
    scheme = request.headers.get("X-Forwarded-Proto", request.url.scheme)
    if "localhost" in request.url.netloc or "127.0.0.1" in request.url.netloc:
        scheme = "https"
    ctx["base_url"] = f"{scheme}://{request.url.netloc}"
    return templates.TemplateResponse(request, "settings/show_api_token.html", context=ctx)


@router.post("/admin/settings/api-tokens/{token_id}/revoke", dependencies=[Depends(csrf_protect)])
async def revoke_user_api_token(
    request: Request,
    token_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Revoke a user API token."""
    import uuid as uuid_module

    from app.domain.services.user_api_tokens import UserAPITokenService

    user_id = uuid_module.UUID(current_user.sub)
    token_svc = UserAPITokenService(db, current_user.tenant_id)

    # Verify ownership
    token_result = token_svc.get_token(token_id)
    if not token_result:
        flash(request, "Token not found", "error")
        return RedirectResponse(url="/admin/settings", status_code=status.HTTP_303_SEE_OTHER)

    token, _ = token_result
    if token.user_id != str(user_id):
        flash(request, "You can only revoke your own tokens", "error")
        return RedirectResponse(url="/admin/settings", status_code=status.HTTP_303_SEE_OTHER)

    form_data = await request.form()
    reason = form_data.get("reason", "Revoked by user")

    token_svc.revoke(token_id, revoked_by=user_id, reason=reason)
    flash(request, f"Token '{token.token_name}' has been revoked", "success")

    return RedirectResponse(url="/admin/settings", status_code=status.HTTP_303_SEE_OTHER)


# --- Documents ---


@router.get("/documents", response_class=HTMLResponse)
async def documents_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    document_type: str | None = Query(None),
    filename: str | None = Query(None),
):
    """List documents (internal only)."""
    from app.domain.services.documents import DocumentService

    ctx = get_template_context(request, current_user, db)

    doc_svc = DocumentService(
        db, current_user.tenant_id, current_user.sub, is_internal=current_user.is_internal
    )
    docs_with_revisions = doc_svc.list_documents(limit=100)

    # Pre-fetch all link events so we can show linked status in the list
    linked_docs_repo = doc_svc._repo()

    documents = []
    for doc, rev in docs_with_revisions:
        # Apply filters
        if document_type and rev and rev.document_type != document_type:
            continue
        if filename and rev and filename.lower() not in (rev.filename or "").lower():
            continue

        # Look up linked entity for this document
        linked_entity = None
        try:
            link_events = linked_docs_repo.get_link_events_for_source(
                tenant_id=current_user.tenant_id,
                source_type="DOCUMENT",
                source_id=doc.euid,
                target_type=None,
            )
            link_events = [e for e in link_events if e.action == "LINK"]
            if link_events:
                first_link = link_events[0]
                entity_type = first_link.target_type
                entity_id = first_link.target_id
                linked_entity = {
                    "type": entity_type,
                    "label": entity_id,
                    "url": f"/{entity_type.lower()}s/{entity_id}",
                }
        except Exception:
            pass

        documents.append(
            {
                "id": doc.euid,
                "filename": rev.filename if rev else "Unknown",
                "document_type": rev.document_type if rev else None,
                "size_bytes": rev.size_bytes if rev else None,
                "content_type": rev.content_type if rev else None,
                "created_at": doc.created_at,
                "linked_entity": linked_entity,
            }
        )

    ctx["documents"] = documents
    return templates.TemplateResponse(request, "documents/list.html", context=ctx)


@router.get(
    "/documents/search-entities",
    response_class=HTMLResponse,
)
async def documents_search_entities(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    entity_type: str = Query("patient"),
    q: str = Query(""),
    page: int = Query(1),
):
    """HTMX endpoint: search patients, clinicians, or TRFs and return a paginated HTML table."""
    from app.domain.services.people import ClinicianService, PatientService
    from app.domain.services.trfs import TrfService

    PAGE_SIZE = 10
    results: list[dict[str, str]] = []
    search_term = q.strip()
    cross_tenant = current_user.is_internal
    offset = (max(1, page) - 1) * PAGE_SIZE

    # ------- Patient -------
    if entity_type == "patient":
        headers = ["Name", "MRN", "DOB"]
        if search_term:
            all_rows = PatientService(db, current_user.tenant_id).search_by_name(
                search_term, limit=200, cross_tenant=cross_tenant
            )
        else:
            all_rows = PatientService(db, current_user.tenant_id).list_patients(
                limit=200, cross_tenant=cross_tenant
            )
        total = len(all_rows)
        page_rows = all_rows[offset : offset + PAGE_SIZE]
        for patient, revision in page_rows:
            name = f"{revision.first_name} {revision.last_name}".strip()
            mrn = getattr(revision, "mrn", None) or "—"
            dob = str(getattr(revision, "date_of_birth", None) or "—")
            results.append(
                {"id": patient.euid, "label": name, "col1": name, "col2": mrn, "col3": dob}
            )

    # ------- Clinician -------
    elif entity_type == "clinician":
        headers = ["Name", "Credentials", "NPI"]
        if search_term:
            all_rows = ClinicianService(db, current_user.tenant_id).search_by_name(
                search_term, limit=200, cross_tenant=cross_tenant
            )
        else:
            all_rows = ClinicianService(db, current_user.tenant_id).list_clinicians(
                limit=200, cross_tenant=cross_tenant
            )
        total = len(all_rows)
        page_rows = all_rows[offset : offset + PAGE_SIZE]
        for clinician, revision in page_rows:
            name = f"{revision.first_name} {revision.last_name}".strip()
            creds = getattr(revision, "credentials", None) or "—"
            npi = getattr(revision, "npi", None) or "—"
            results.append(
                {"id": clinician.euid, "label": name, "col1": name, "col2": creds, "col3": npi}
            )

    # ------- TRF -------
    elif entity_type == "trf":
        headers = ["TRF #", "Status", "EUID"]
        all_rows = TrfService(db, current_user.tenant_id).list_trfs(
            limit=200, cross_tenant=cross_tenant
        )
        # Client-side filter by search term
        if search_term:
            all_rows = [
                (trf, rev)
                for trf, rev in all_rows
                if search_term.lower() in (trf.order_number or trf.euid).lower()
            ]
        total = len(all_rows)
        page_rows = all_rows[offset : offset + PAGE_SIZE]
        for trf, revision in page_rows:
            number = trf.order_number or trf.euid
            trf_status = getattr(revision, "status", "—")
            results.append(
                {
                    "id": trf.euid,
                    "label": number,
                    "col1": number,
                    "col2": trf_status,
                    "col3": trf.euid,
                }
            )
    else:
        headers = ["Name", "Detail", "ID"]
        total = 0

    # ------- Build HTML table -------
    total_pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
    current_page = min(max(1, page), total_pages)

    html = []

    if not results and total == 0:
        html.append(
            f'<div class="empty-state" style="padding:var(--space-xl);">'
            f'<p class="text-muted">No {entity_type}s found</p></div>'
        )
    else:
        html.append('<div class="table-container">')
        html.append('<table class="table" id="entityResultsTable">')

        # Header
        html.append("<thead><tr>")
        for h in headers:
            html.append(f"<th>{h}</th>")
        html.append("<th></th>")
        html.append("</tr></thead>")

        # Body
        html.append("<tbody>")
        for r in results:
            html.append(
                f"<tr>"
                f"<td>{r['col1']}</td>"
                f'<td class="text-muted">{r["col2"]}</td>'
                f'<td class="text-muted text-mono text-sm">{r["col3"]}</td>'
                f'<td style="text-align:right;">'
                f'<button type="button" class="btn btn-sm btn-primary"'
                f' data-entity-id="{r["id"]}" data-entity-label="{r["label"]}"'
                f' onclick="selectEntity(this)">Select</button>'
                f"</td>"
                f"</tr>"
            )
        html.append("</tbody></table></div>")

    # ------- Pagination controls -------
    if total > PAGE_SIZE:
        import html as html_mod

        q_escaped = html_mod.escape(search_term)
        html.append(
            '<div style="display:flex;justify-content:space-between;align-items:center;'
            'padding:var(--space-sm) var(--space-md);border-top:1px solid var(--border-color);">'
        )
        html.append(
            f'<span class="text-muted text-sm">'
            f"Page {current_page} of {total_pages} ({total} results)"
            f"</span>"
        )
        html.append('<div style="display:flex;gap:var(--space-sm);">')
        if current_page > 1:
            html.append(
                f'<button type="button" class="btn btn-sm btn-secondary"'
                f' hx-get="/documents/search-entities'
                f'?entity_type={entity_type}&q={q_escaped}&page={current_page - 1}"'
                f' hx-target="#entitySearchResults" hx-swap="innerHTML"'
                f">← Prev</button>"
            )
        if current_page < total_pages:
            html.append(
                f'<button type="button" class="btn btn-sm btn-secondary"'
                f' hx-get="/documents/search-entities'
                f'?entity_type={entity_type}&q={q_escaped}&page={current_page + 1}"'
                f' hx-target="#entitySearchResults" hx-swap="innerHTML"'
                f">Next →</button>"
            )
        html.append("</div></div>")

    from starlette.responses import HTMLResponse as StarletteHTMLResponse

    return StarletteHTMLResponse("".join(html))


@router.get(
    "/documents/upload",
    response_class=HTMLResponse,
)
async def documents_upload_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Show document upload form."""
    ctx = get_template_context(request, current_user, db)
    ctx["document_types"] = [
        "MANIFEST",
        "PACKING_SLIP",
        "CHAIN_OF_CUSTODY",
        "REQUISITION",
        "LAB_REPORT",
        "OTHER",
    ]
    ctx["is_internal"] = current_user.is_internal
    return templates.TemplateResponse(request, "documents/upload.html", context=ctx)


@router.post(
    "/documents/upload",
    response_class=HTMLResponse,
    dependencies=[Depends(csrf_protect)],
)
async def documents_upload_submit(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Upload a new document, optionally linking to an entity.

    Supports both standalone uploads (from /documents/upload page) and
    entity-linked uploads (from entity detail pages).

    Form fields:
    - file: The uploaded file (required)
    - document_type: Type of document (optional)
    - description/note: Description text (optional, accepts either field name)
    - entity_type: Entity type to link to (optional: ORDER, SHIPMENT, TESTKIT)
    - entity_id: Entity UUID to link to (required if entity_type provided)
    """
    from app.domain.services.documents import DocumentService, DocumentUpload
    from app.domain.services.shipments import ShipmentService
    from app.domain.services.trfs import TrfService

    form_data = await request.form()
    uploaded_file = form_data.get("file")
    document_type = form_data.get("document_type") or None
    # Support both 'description' and 'note' field names
    note = form_data.get("description", "").strip() or form_data.get("note", "").strip() or None
    # Optional entity linking
    entity_type = form_data.get("entity_type") or None
    entity_id_str = form_data.get("entity_id") or None

    if not uploaded_file or not hasattr(uploaded_file, "read"):
        flash(request, "Please select a file to upload", "error")
        return RedirectResponse(url="/documents/upload", status_code=status.HTTP_303_SEE_OTHER)

    try:
        file_content = await uploaded_file.read(settings.max_upload_size_bytes + 1)
        if len(file_content) > settings.max_upload_size_bytes:
            flash(
                request,
                f"File too large. Maximum size is {settings.max_upload_size_bytes // (1024 * 1024)} MB.",
                "error",
            )
            return RedirectResponse(url="/documents/upload", status_code=status.HTTP_303_SEE_OTHER)
        filename = uploaded_file.filename or "uploaded_file"

        doc_svc = DocumentService(
            db, current_user.tenant_id, current_user.sub, is_internal=current_user.is_internal
        )

        # Determine visibility / restricted_to_user_id
        visibility = form_data.get("visibility", "organization")
        restricted_to_user_id = None
        if visibility == "individual":
            restricted_to_user_id = current_user.sub_uuid

        # Upload the document
        result = doc_svc.upload(
            DocumentUpload(
                filename=filename,
                content=file_content,
                content_type=uploaded_file.content_type or "application/octet-stream",
                document_type=document_type,
                note=note,
                restricted_to_user_id=restricted_to_user_id,
            ),
            created_by=current_user.sub_uuid,
        )

        # Link to entity if provided
        if entity_type and entity_id_str:
            print(
                f"[UPLOAD DEBUG] calling link_to_entity({result.document_euid}, {entity_type}, {entity_id_str})"
            )
            doc_svc.link_to_entity(
                result.document_euid,
                entity_type,
                entity_id_str,
                created_by=current_user.sub_uuid,
            )

            flash(request, f"Document '{filename}' uploaded and linked successfully", "success")

            # Redirect back to entity page with human-readable identifiers
            if entity_type == "Shipment":
                shipment_result = ShipmentService(db, current_user.tenant_id).get(
                    entity_id_str, cross_tenant=False
                )
                if shipment_result:
                    shipment, _shipment_rev = shipment_result
                    safe_ship_num = str(shipment.shipment_number)
                    return RedirectResponse(
                        url=_safe_redirect_url(f"/shipments/{safe_ship_num}"),
                        status_code=status.HTTP_303_SEE_OTHER,
                    )
            elif entity_type in ("Order", "Trf"):
                trf_result = TrfService(db, current_user.tenant_id).get_by_id(
                    entity_id_str, cross_tenant=False
                )
                if trf_result:
                    trf, _trf_rev = trf_result
                    safe_order_id = str(trf.order_number)
                    return RedirectResponse(
                        url=_safe_redirect_url(f"/trfs/{safe_order_id}"),
                        status_code=status.HTTP_303_SEE_OTHER,
                    )
            elif entity_type == "TestKit":
                from app.domain.services.shipments import TestKitService

                tk_result = TestKitService(db, current_user.tenant_id).get_with_revision(
                    entity_id_str, cross_tenant=False
                )
                if tk_result:
                    safe_tk_id = str(tk_result[0].euid)
                return RedirectResponse(
                    url=_safe_redirect_url(f"/testkits/{safe_tk_id}"),
                    status_code=status.HTTP_303_SEE_OTHER,
                )
            elif entity_type == "Patient":
                return RedirectResponse(
                    url=_safe_redirect_url(f"/patients/{_seg(entity_id_str)}"),
                    status_code=status.HTTP_303_SEE_OTHER,
                )
            elif entity_type == "Clinician":
                return RedirectResponse(
                    url=_safe_redirect_url(f"/clinicians/{_seg(entity_id_str)}"),
                    status_code=status.HTTP_303_SEE_OTHER,
                )

        # Fallback to document detail
        safe_doc_id = str(result.document_euid)
        return RedirectResponse(
            url=_safe_redirect_url(f"/documents/{safe_doc_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

        # Standalone upload - redirect to document detail
        flash(request, f"Document '{filename}' uploaded successfully", "success")
        return RedirectResponse(
            url=_safe_redirect_url(f"/documents/{_seg(result.document_euid)}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    except Exception as e:
        logger.error("Error uploading document: %s", e, exc_info=True)
        flash(request, "An error occurred while uploading document. Please try again.", "error")
        return RedirectResponse(url="/documents/upload", status_code=status.HTTP_303_SEE_OTHER)


@router.get(
    "/documents/{document_euid}",
    response_class=HTMLResponse,
)
async def documents_detail(
    request: Request,
    document_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Document detail page."""
    from app.domain.services.documents import DocumentService

    ctx = get_template_context(request, current_user, db)

    doc_svc = DocumentService(
        db, current_user.tenant_id, current_user.sub, is_internal=current_user.is_internal
    )
    result = doc_svc.get(document_euid)

    if not result:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Document not found",
        )

    document, revision = result

    # Get linked entities via TapDB link events
    linked_docs_repo = doc_svc._repo()
    link_events_records = linked_docs_repo.get_link_events_for_source(
        tenant_id=current_user.tenant_id,
        source_type="DOCUMENT",
        source_id=document_euid,
        target_type=None,
    )
    # Filter to only LINK actions (not UNLINK)
    link_events_records = [e for e in link_events_records if e.action == "LINK"]

    linked_entities = []
    for link in link_events_records:
        entity_type = link.target_type
        entity_id = link.target_id
        url = f"/{entity_type.lower()}s/{entity_id}"
        linked_entities.append(
            {
                "type": entity_type,
                "id": entity_id,
                "url": url,
                "label": f"{entity_type} {entity_id[:12]}..."
                if len(entity_id) > 12
                else f"{entity_type} {entity_id}",
            }
        )

    # Attach the filename from the revision onto the document object for the template
    document.filename = revision.filename if revision else "Unknown"
    ctx["document"] = document
    ctx["revision"] = revision
    ctx["linked_entities"] = linked_entities
    return templates.TemplateResponse(request, "documents/detail.html", context=ctx)


@router.get("/admin/audit", response_class=HTMLResponse)
async def admin_audit(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
    action: str | None = Query(None),
    entity_type: str | None = Query(None),
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    page: int = Query(1, ge=1),
):
    """Audit log page."""
    from datetime import datetime

    from app.domain.services.audit import AuditFilter, AuditService

    ctx = get_template_context(request, current_user, db)

    # Build filter
    filter = AuditFilter(
        action=action,
        entity_type=entity_type,
        date_from=datetime.fromisoformat(date_from) if date_from else None,
        date_to=datetime.fromisoformat(date_to) if date_to else None,
    )

    # Get audit events (pass None for tenant_id to get all events for admins)
    svc = AuditService(db, tenant_id=None, user_id=current_user.sub)
    limit = 50
    skip = (page - 1) * limit
    events = svc.list_events(filter=filter, skip=skip, limit=limit)
    total = svc.count(filter=filter)

    ctx["audit_events"] = [
        {
            "event_id": event.event_id,
            "created_at": event.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            "event_type": event.action,
            "actor_id": event.user_id or "SYSTEM",
            "user_email": None,  # Would need to fetch from user service
            "entity_type": event.entity_type or "—",
            "entity_id": event.entity_id or "—",
            "ip_address": event.ip_address,
            "details": event.details,
        }
        for event in events
    ]
    ctx["total"] = total
    ctx["page"] = page
    ctx["pages"] = (total + limit - 1) // limit
    ctx["filter"] = {
        "action": action,
        "entity_type": entity_type,
        "date_from": date_from,
        "date_to": date_to,
    }

    return templates.TemplateResponse(request, "admin/audit.html", context=ctx)


# --- Admin API Tokens ---


@router.get("/admin/api-tokens", response_class=HTMLResponse)
async def admin_api_tokens(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
    status_filter: str | None = Query(None, alias="status"),
    user_id: str | None = Query(None),
    export: str | None = Query(None),
):
    """Admin page for managing all user API tokens."""
    import io

    from starlette.responses import StreamingResponse

    from app.domain.services.user_api_tokens import UserAPITokenService
    from app.domain.services.users import UserService

    token_svc = UserAPITokenService(db, current_user.tenant_id)
    user_svc = UserService(db, current_user.sub_uuid)

    # Get all tokens with optional filters
    user_id_filter = user_id.strip() if user_id else None
    if user_id_filter:
        profile = user_svc.get_by_id(user_id_filter)
        if profile and getattr(profile, "cognito_sub", None):
            user_id_filter = profile.cognito_sub
    tokens_raw = token_svc.list_all_tokens(
        user_id_filter=user_id_filter,
        status_filter=status_filter,
        limit=500,
    )

    # Get user emails for display
    user_cache: dict[str, str] = {}
    tokens = []
    for t in tokens_raw:
        token_user_id = str(t.user_id or "")
        if token_user_id and token_user_id not in user_cache:
            user = user_svc.get_by_id(token_user_id) or user_svc.get_by_cognito_sub(token_user_id)
            user_cache[token_user_id] = user.email if user else "Unknown"

        tokens.append(
            {
                **t.__dict__,
                "user_id": token_user_id,
                "user_email": user_cache.get(token_user_id, "Unknown"),
            }
        )

    # Calculate stats
    stats = {
        "total": len(tokens_raw),
        "active": sum(1 for t in tokens_raw if t.status == "ACTIVE" and not t.is_expired),
        "expired": sum(1 for t in tokens_raw if t.is_expired or t.status == "EXPIRED"),
        "revoked": sum(1 for t in tokens_raw if t.status == "REVOKED"),
    }

    # Export handling
    if export == "csv":
        output = io.StringIO()
        output.write("User Email,Token Name,Prefix,Status,Created,Expires,Last Used,Usage Count\n")
        for t in tokens:
            output.write(
                f"{t['user_email']},{t['token_name']},{t['token_prefix']},{t['status']},"
                f"{t['created_at']},{t['expires_at']},{t['last_used_at'] or 'Never'},{t['usage_count']}\n"
            )

        return StreamingResponse(
            iter([output.getvalue()]),
            media_type="text/csv",
            headers={"Content-Disposition": "attachment; filename=api_tokens.csv"},
        )

    # Get users for filter dropdown
    users = user_svc.list_users(tenant_id=current_user.tenant_id, limit=500)

    ctx = get_template_context(request, current_user, db)
    ctx["tokens"] = tokens
    ctx["stats"] = stats
    ctx["users"] = users
    ctx["filters"] = {"status": status_filter, "user_id": user_id}

    return templates.TemplateResponse(request, "admin/api_tokens.html", context=ctx)


@router.post("/admin/api-tokens/{token_id}/revoke", dependencies=[Depends(csrf_protect)])
async def admin_revoke_api_token(
    request: Request,
    token_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Admin: Revoke any user API token."""
    import uuid as uuid_module

    from app.domain.services.user_api_tokens import UserAPITokenService

    admin_id = uuid_module.UUID(current_user.sub)
    token_svc = UserAPITokenService(db, current_user.tenant_id)

    result = token_svc.revoke(token_id, revoked_by=admin_id, reason="Revoked by administrator")

    if result:
        token, _ = result
        flash(request, f"Token '{token.token_name}' has been revoked", "success")
    else:
        flash(request, "Token not found", "error")

    return RedirectResponse(url="/admin/api-tokens", status_code=status.HTTP_303_SEE_OTHER)


@router.get("/admin/organizations", response_class=HTMLResponse)
async def admin_organizations_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
    search: str | None = Query(None),
    org_type: str | None = Query(None),
    is_active: str | None = Query(None),
):
    """List all organizations (admin only)."""
    from app.domain.services.orgs import OrganizationService

    ctx = get_template_context(request, current_user, db)

    # Get all organizations
    org_svc = OrganizationService(db)
    all_orgs = org_svc.list_all(active_only=False)

    # Enrich with revision data and apply filters
    organizations = []
    search_lower = search.lower() if search else None
    for org in all_orgs:
        result = org_svc.get_with_revision(org.euid)
        if result:
            _, rev = result
            # Apply search filter
            if search_lower:
                name_match = rev.name and search_lower in rev.name.lower()
                display_match = rev.display_name and search_lower in rev.display_name.lower()
                if not (name_match or display_match):
                    continue

            # Apply filters
            if org_type and rev.org_type != org_type:
                continue
            if is_active == "true" and not rev.is_active:
                continue
            if is_active == "false" and rev.is_active:
                continue

            # Enrich org with revision data
            org.name = rev.name
            org.display_name = rev.display_name
            org.org_type = rev.org_type
            org.contact_email = rev.contact_email
            org.is_active = rev.is_active
            organizations.append(org)

    ctx["organizations"] = organizations
    ctx["filter"] = {
        "search": search,
        "org_type": org_type,
        "is_active": is_active,
    }

    return templates.TemplateResponse(request, "admin/organizations.html", context=ctx)


@router.get("/admin/organizations/create", response_class=HTMLResponse)
async def admin_organizations_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Organization creation form."""
    ctx = get_template_context(request, current_user, db)
    ctx["organization"] = None
    ctx["revision"] = None
    ctx["owner_candidates"] = []
    ctx["owner_user_id_input"] = ""
    ctx["owner_user_display_input"] = ""
    ctx["contact_email_input"] = ""
    ctx["contact_phone_input"] = ""
    ctx["initial_site_name"] = ""
    ctx["initial_site_code"] = ""
    ctx["initial_site_contact_email"] = ""
    ctx["initial_site_contact_phone"] = ""
    ctx["initial_site_address_line1"] = ""
    ctx["initial_site_address_line2"] = ""
    ctx["initial_site_city"] = ""
    ctx["initial_site_state"] = ""
    ctx["initial_site_postal_code"] = ""
    return templates.TemplateResponse(request, "admin/organization_form.html", context=ctx)


@router.post("/admin/organizations/create", dependencies=[Depends(csrf_protect)])
async def admin_organizations_create(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Create a new organization."""
    from app.domain.services.orgs import (
        OrganizationCreate,
        OrganizationService,
    )

    form_data = await request.form()
    owner_user_id_raw = form_data.get("owner_user_id")
    initial_site_name = (form_data.get("initial_site_name") or "").strip()
    initial_site_code = (form_data.get("initial_site_code") or "").strip() or None
    initial_site_contact_email = _normalize_optional_text(
        form_data.get("initial_site_contact_email")
    )
    initial_site_contact_phone = _normalize_optional_text(
        form_data.get("initial_site_contact_phone")
    )
    contact_email = _normalize_optional_text(form_data.get("contact_email"))
    contact_phone = _normalize_optional_text(form_data.get("contact_phone"))

    try:
        if not initial_site_name:
            raise ValueError("Initial site name is required when creating an organization")

        initial_site_address: dict[str, str] = {}
        if (form_data.get("initial_site_address_line1") or "").strip():
            initial_site_address["line1"] = (
                form_data.get("initial_site_address_line1") or ""
            ).strip()
        if (form_data.get("initial_site_address_line2") or "").strip():
            initial_site_address["line2"] = (
                form_data.get("initial_site_address_line2") or ""
            ).strip()
        if (form_data.get("initial_site_city") or "").strip():
            initial_site_address["city"] = (form_data.get("initial_site_city") or "").strip()
        if (form_data.get("initial_site_state") or "").strip():
            initial_site_address["state"] = (form_data.get("initial_site_state") or "").strip()
        if (form_data.get("initial_site_postal_code") or "").strip():
            initial_site_address["postal_code"] = (
                form_data.get("initial_site_postal_code") or ""
            ).strip()

        owner_user_id = _resolve_optional_owner_user_id(
            db,
            owner_user_id_raw,
            field_name="Owner user ID",
        )
        org_svc = OrganizationService(db)
        org_svc.create(
            OrganizationCreate(
                name=form_data.get("name"),
                display_name=form_data.get("display_name") or None,
                org_type=form_data.get("org_type", "clinic"),
                contact_email=contact_email,
                contact_phone=contact_phone,
                owner_user_id=owner_user_id,
                initial_site_name=initial_site_name,
                initial_site_code=initial_site_code,
                initial_site_contact_email=initial_site_contact_email,
                initial_site_contact_phone=initial_site_contact_phone,
                initial_site_address=initial_site_address or None,
            ),
            created_by=current_user.sub_uuid,
        )
        flash(request, "Organization created successfully", "success")
        return RedirectResponse(url="/admin/organizations", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        ctx = get_template_context(request, current_user, db)
        ctx["organization"] = None
        ctx["revision"] = None
        ctx["owner_candidates"] = []
        ctx["owner_user_id_input"] = (owner_user_id_raw or "").strip()
        ctx["owner_user_display_input"] = (owner_user_id_raw or "").strip()
        ctx["contact_email_input"] = (form_data.get("contact_email") or "").strip()
        ctx["contact_phone_input"] = (form_data.get("contact_phone") or "").strip()
        ctx["initial_site_name"] = initial_site_name
        ctx["initial_site_code"] = initial_site_code or ""
        ctx["initial_site_contact_email"] = initial_site_contact_email or ""
        ctx["initial_site_contact_phone"] = initial_site_contact_phone or ""
        ctx["initial_site_address_line1"] = (
            form_data.get("initial_site_address_line1") or ""
        ).strip()
        ctx["initial_site_address_line2"] = (
            form_data.get("initial_site_address_line2") or ""
        ).strip()
        ctx["initial_site_city"] = (form_data.get("initial_site_city") or "").strip()
        ctx["initial_site_state"] = (form_data.get("initial_site_state") or "").strip()
        ctx["initial_site_postal_code"] = (form_data.get("initial_site_postal_code") or "").strip()
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "admin/organization_form.html", context=ctx)


@router.get("/admin/organizations/{org_id}", response_class=HTMLResponse)
async def admin_organization_detail(
    request: Request,
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Organization detail page (admin only)."""
    from app.domain.services.external_objects import OrgBloomConfigService, SiteBloomConfigService
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision(org_id)

    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    ctx["organization"] = organization
    ctx["revision"] = revision

    ctx["sites"] = _list_site_summaries(db, organization.euid)
    site_config_service = SiteBloomConfigService(db)
    site_config_map = {
        cfg.site_id: cfg
        for cfg in site_config_service.list_enabled(organization_id=organization.uid)
    }
    for site in ctx["sites"]:
        site["bloom_config_enabled"] = site["id"] in site_config_map

    # Get users in this organization
    user_svc = UserService(db, current_user.sub_uuid)
    users = user_svc.list_users(tenant_id=organization.uid, limit=50)
    ctx["users"] = [
        {
            "id": u.euid,
            "name": u.name,
            "email": u.email,
            "roles": u.roles,
            "is_active": u.is_active,
        }
        for u in users
    ]
    owner_user = None
    if revision.owner_user_id:
        owner_user = _lookup_owner_user_profile(db, str(revision.owner_user_id))
    ctx["owner_user"] = owner_user
    org_bloom_config = OrgBloomConfigService(db).get(organization.uid)
    ctx["org_bloom_config"] = org_bloom_config
    ctx["bloom_connection_status"] = _build_org_bloom_connection_status(org_bloom_config)

    return templates.TemplateResponse(request, "admin/organization_detail.html", context=ctx)


@router.post(
    "/admin/organizations/{org_id}/integrations/bloom",
    dependencies=[Depends(require_admin), Depends(csrf_protect)],
)
async def admin_organization_bloom_config_save(
    request: Request,
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Create or update org-level Bloom config from the admin UI."""
    from app.domain.services.external_objects import OrgBloomConfigService, OrgBloomConfigUpsert
    from app.domain.services.orgs import OrganizationService

    organization = OrganizationService(db).get_by_id(org_id)
    if organization is None or organization.uid is None:
        raise HTTPException(status_code=404, detail="Organization not found")

    form_data = await request.form()
    action = (form_data.get("action") or "save").strip().lower()
    payload = _extract_bloom_config_form_payload(form_data)
    if action == "validate":
        try:
            _validate_bloom_credentials(
                bloom_base_url=str(payload["bloom_base_url"]),
                bloom_api_key_secret_ref=str(payload["bloom_api_key_secret_ref"]),
            )
            flash(
                request,
                "Bloom credentials validated successfully. Values were not saved.",
                "success",
            )
        except Exception as exc:
            flash(request, f"Bloom credential validation failed: {exc}", "error")
        safe_org_id = str(organization.euid)
        return RedirectResponse(
            url=_safe_redirect_url(f"/admin/organizations/{safe_org_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    try:
        OrgBloomConfigService(db).upsert(
            organization.uid,
            OrgBloomConfigUpsert(
                enabled=bool(payload["enabled"]),
                bloom_base_url=str(payload["bloom_base_url"]),
                bloom_api_key_secret_ref=str(payload["bloom_api_key_secret_ref"]),
                bloom_webhook_secret_ref=(
                    str(payload["bloom_webhook_secret_ref"])
                    if payload["bloom_webhook_secret_ref"] is not None
                    else None
                ),
                bloom_service_user=(
                    str(payload["bloom_service_user"])
                    if payload["bloom_service_user"] is not None
                    else None
                ),
            ),
            actor_id=current_user.sub_uuid,
        )
        flash(request, "Organization Bloom integration saved.", "success")
        safe_org_id = str(organization.uid)
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
    return RedirectResponse(
        url=_safe_redirect_url(
            f"/admin/organizations/{safe_org_id}"
            if "safe_org_id" in locals()
            else "/admin/organizations"
        ),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.get("/admin/organizations/{org_id}/edit", response_class=HTMLResponse)
async def admin_organizations_edit_form(
    request: Request,
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Organization edit form."""
    from app.domain.services.orgs import OrganizationService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision(org_id)

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Organization not found")

    org, revision = result
    owner_user = None
    if revision.owner_user_id:
        owner_user = _lookup_owner_user_profile(db, str(revision.owner_user_id))
    ctx["organization"] = org
    ctx["revision"] = revision
    ctx["owner_candidates"] = _list_owner_candidates(db, org_id)
    ctx["owner_user_id_input"] = str(revision.owner_user_id) if revision.owner_user_id else ""
    ctx["owner_user_display_input"] = (
        _format_owner_user_display(owner_user.euid, owner_user.email, owner_user.name)
        if owner_user
        else (str(revision.owner_user_id) if revision.owner_user_id else "")
    )
    revision_contact_email = _normalize_optional_text(revision.contact_email)
    revision_contact_phone = _normalize_optional_text(revision.contact_phone)
    ctx["contact_email_input"] = (revision_contact_email or "") or (
        (owner_user.email or "").strip() if owner_user else ""
    )
    ctx["contact_phone_input"] = revision_contact_phone or ""

    return templates.TemplateResponse(request, "admin/organization_form.html", context=ctx)


@router.post("/admin/organizations/{org_id}/edit", dependencies=[Depends(csrf_protect)])
async def admin_organizations_edit(
    request: Request,
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Update an organization."""
    from app.domain.services.orgs import OrganizationService, OrganizationUpdate

    form_data = await request.form()
    owner_user_id_raw = form_data.get("owner_user_id")

    try:
        org_svc = OrganizationService(db)
        is_active = form_data.get("is_active") == "true"
        contact_email = _normalize_optional_text(form_data.get("contact_email"))
        contact_phone = _normalize_optional_text(form_data.get("contact_phone"))
        owner_user_id = _resolve_optional_owner_user_id(
            db,
            owner_user_id_raw,
            field_name="Owner user ID",
            organization_euid=org_id,
        )

        org_svc.update(
            org_id,
            OrganizationUpdate(
                name=form_data.get("name"),
                display_name=form_data.get("display_name") or None,
                org_type=form_data.get("org_type"),
                contact_email=contact_email,
                contact_phone=contact_phone,
                owner_user_id=owner_user_id,
                is_active=is_active,
                note=form_data.get("note") or None,
            ),
            updated_by=current_user.sub_uuid,
        )
        flash(request, "Organization updated successfully", "success")
        return RedirectResponse(url="/admin/organizations", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        ctx = get_template_context(request, current_user, db)
        org_svc = OrganizationService(db)
        result = org_svc.get_with_revision(org_id)
        if result:
            ctx["organization"], ctx["revision"] = result
        else:
            ctx["organization"] = None
            ctx["revision"] = None
        ctx["owner_candidates"] = _list_owner_candidates(db, org_id)
        ctx["owner_user_id_input"] = (owner_user_id_raw or "").strip()
        ctx["owner_user_display_input"] = (owner_user_id_raw or "").strip()
        ctx["contact_email_input"] = (form_data.get("contact_email") or "").strip()
        ctx["contact_phone_input"] = (form_data.get("contact_phone") or "").strip()
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "admin/organization_form.html", context=ctx)


@router.post(
    "/admin/organizations/{org_id}/delete",
    dependencies=[Depends(require_admin), Depends(csrf_protect)],
)
async def admin_organizations_delete(
    request: Request,
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Soft-delete an organization."""
    from app.domain.services.orgs import OrganizationService

    try:
        deleted = OrganizationService(db).soft_delete(org_id, deleted_by=current_user.sub_uuid)
        if deleted:
            flash(request, "Organization deleted (soft delete)", "success")
        else:
            flash(request, "Organization not found", "error")
    except Exception as exc:
        logger.error(
            "Error deleting organization %s: %s", str(org_id).replace("\n", ""), exc, exc_info=True
        )
        flash(request, "An error occurred while deleting organization. Please try again.", "error")

    return RedirectResponse(url="/admin/organizations", status_code=status.HTTP_303_SEE_OTHER)


@router.get("/admin/organizations/{org_id}/sites/new", response_class=HTMLResponse)
async def admin_organization_site_create_form(
    request: Request,
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Show site creation form for a specific organization."""
    from app.domain.services.orgs import OrganizationService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision(org_id)
    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    ctx["organization"] = organization
    ctx["revision"] = revision
    ctx["site"] = None
    ctx["site_revision"] = None
    return templates.TemplateResponse(request, "admin/organization_site_form.html", context=ctx)


@router.post(
    "/admin/organizations/{org_id}/sites/new",
    response_class=HTMLResponse,
    dependencies=[Depends(csrf_protect)],
)
async def admin_organization_site_create(
    request: Request,
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Create a new site for a specific organization."""
    from app.domain.services.orgs import OrganizationService, SiteCreate, SiteService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision(org_id)
    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    form_data = await request.form()

    # Build address dict
    address = {}
    if form_data.get("address_line1"):
        address["line1"] = form_data["address_line1"]
    if form_data.get("address_line2"):
        address["line2"] = form_data["address_line2"]
    if form_data.get("city"):
        address["city"] = form_data["city"]
    if form_data.get("state"):
        address["state"] = form_data["state"]
    if form_data.get("postal_code"):
        address["postal_code"] = form_data["postal_code"]

    try:
        svc = SiteService(db)
        svc.create(
            SiteCreate(
                organization_id=org_id,
                name=form_data["name"],
                site_code=form_data.get("site_code"),
                address=address if address else None,
                contact_email=form_data.get("contact_email"),
                contact_phone=form_data.get("contact_phone"),
            ),
            created_by=current_user.sub_uuid,
        )
        flash(request, "Site created successfully", "success")
        safe_org_id = str(organization.euid)
        return RedirectResponse(
            url=_safe_redirect_url(f"/admin/organizations/{safe_org_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    except Exception as e:
        ctx["organization"] = organization
        ctx["revision"] = revision
        ctx["site"] = None
        ctx["site_revision"] = None
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "admin/organization_site_form.html", context=ctx)


@router.get("/admin/organizations/{org_id}/users/new", response_class=HTMLResponse)
async def admin_organization_user_create_form(
    request: Request,
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Show user creation form for a specific organization."""
    from app.domain.services.orgs import OrganizationService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision(org_id)
    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    ctx["organization"] = organization
    ctx["revision"] = revision
    ctx["available_roles"] = [
        "ADMIN",
        "EXTERNAL_USER",
        "EXTERNAL_USER_ADMIN",
        "INTERNAL_USER",
        "READ_ONLY",
        "READ_WRITE",
    ]
    return templates.TemplateResponse(request, "admin/organization_user_form.html", context=ctx)


@router.post(
    "/admin/organizations/{org_id}/users/new",
    response_class=HTMLResponse,
    dependencies=[Depends(csrf_protect)],
)
async def admin_organization_user_create(
    request: Request,
    org_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Create a new user for a specific organization."""
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserCreate, UserService

    ctx = get_template_context(request, current_user, db)

    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision(org_id)
    if not result:
        raise HTTPException(status_code=404, detail="Organization not found")

    organization, revision = result
    form_data = await request.form()

    # Get selected roles
    roles = form_data.getlist("roles")

    try:
        user_svc = UserService(db, current_user.sub_uuid)
        if organization.uid is None:
            raise ValueError("Organization tenant ID is not configured")
        user_svc.invite(
            UserCreate(
                email=form_data["email"],
                name=form_data.get("name") or None,
                tenant_id=organization.uid,
                roles=list(roles),
            )
        )
        flash(request, "User invited successfully", "success")
        safe_org_id = str(organization.euid)
        return RedirectResponse(
            url=_safe_redirect_url(f"/admin/organizations/{safe_org_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    except Exception as e:
        ctx["organization"] = organization
        ctx["revision"] = revision
        ctx["available_roles"] = [
            "ADMIN",
            "EXTERNAL_USER",
            "EXTERNAL_USER_ADMIN",
            "INTERNAL_USER",
            "READ_ONLY",
            "READ_WRITE",
        ]
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "admin/organization_user_form.html", context=ctx)


@router.get("/admin/test-definitions", response_class=HTMLResponse)
async def admin_assays_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
    category: str | None = Query(None),
    is_active: str | None = Query(None),
):
    """List all assays (admin only)."""
    from app.domain.services.test_definitions import TestDefinitionService

    ctx = get_template_context(request, current_user, db)

    assay_svc = TestDefinitionService(db)

    # Parse is_active filter
    active_only = True
    if is_active == "false" or is_active == "all":
        active_only = False

    assays = assay_svc.list_all(
        active_only=active_only,
        category=category,
    )

    ctx["fulfillment_routes"] = assays
    ctx["assays"] = assays
    ctx["categories"] = assay_svc.get_categories()
    ctx["filter"] = {
        "category": category,
        "is_active": is_active,
    }

    return templates.TemplateResponse(request, "admin/test_definitions.html", context=ctx)


@router.get("/admin/test-definitions/create", response_class=HTMLResponse)
async def admin_assays_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Show assay creation form."""
    ctx = get_template_context(request, current_user, db)
    ctx["assay"] = None
    ctx["bloom_lab_method_euid"] = ""
    ctx["specimen_types_input"] = ""
    return templates.TemplateResponse(request, "admin/test_definition_form.html", context=ctx)


@router.post(
    "/admin/test-definitions/create",
    response_class=HTMLResponse,
    dependencies=[Depends(csrf_protect)],
)
async def admin_assays_create(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Create a new assay."""
    from app.domain.services.test_definitions import TestDefinitionCreate, TestDefinitionService

    form_data = await request.form()

    try:
        svc = TestDefinitionService(db)
        specimen_types = _normalize_specimen_types_input(form_data.get("specimen_types"))
        assay = svc.create(
            TestDefinitionCreate(
                code=form_data["code"],
                name=form_data["name"],
                description=form_data.get("description"),
                category=form_data.get("category"),
                technology=form_data.get("technology"),
                specimen_types=specimen_types,
            )
        )

        # Optional Bloom lab_method external ID mapping (stored via ExternalObject+Relation).
        bloom_lab_method_euid = (form_data.get("bloom_lab_method_euid") or "").strip()
        if bloom_lab_method_euid:
            from app.persistence.tapdb.external_objects import TapdbExternalObjectRepository

            global_tenant_id = uuid.UUID(int=0)
            ext_repo = TapdbExternalObjectRepository(db)
            ext_obj = ext_repo.create_or_update_external_object(
                tenant_id=global_tenant_id,
                provider="bloom",
                object_type="lab_method",
                external_euid=bloom_lab_method_euid,
                metadata={"fulfillment_route_code": assay.code},
                actor_id=current_user.sub_uuid,
            )
            ext_repo.set_single_relation_for_local_entity(
                tenant_id=global_tenant_id,
                relation_type="lab_method_for_test",
                local_entity_type="Test",
                local_entity_id=assay.euid,
                external_object_id=ext_obj.euid,
                metadata={"fulfillment_route_code": assay.code},
                actor_id=current_user.sub_uuid,
            )

        flash(request, "Test created successfully", "success")
        return RedirectResponse(
            url="/admin/test-definitions", status_code=status.HTTP_303_SEE_OTHER
        )
    except Exception as e:
        ctx = get_template_context(request, current_user, db)
        ctx["assay"] = None
        ctx["bloom_lab_method_euid"] = (form_data.get("bloom_lab_method_euid") or "").strip()
        ctx["specimen_types_input"] = form_data.get("specimen_types") or ""
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "admin/test_definition_form.html", context=ctx)


@router.get("/admin/test-definitions/{assay_euid}", response_class=HTMLResponse)
async def admin_assays_detail(
    request: Request,
    assay_euid: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Test detail page with linked documents."""
    from app.domain.services.documents import DocumentService
    from app.domain.services.test_definitions import TestDefinitionService

    ctx = get_template_context(request, current_user, db)

    svc = TestDefinitionService(db)
    assay = svc.get_by_euid(assay_euid)

    if not assay:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Test not found")

    ctx["assay"] = assay
    ctx["bloom_lab_method_euid"] = None
    ctx["specimen_types_input"] = ", ".join(assay.specimen_types or [])

    # Optional Bloom lab_method external ID mapping (global).
    try:
        from app.persistence.tapdb.external_objects import TapdbExternalObjectRepository

        global_tenant_id = uuid.UUID(int=0)
        ext_repo = TapdbExternalObjectRepository(db)
        relations = ext_repo.list_relations_for_local_entity(
            tenant_id=global_tenant_id,
            local_entity_type="Test",
            local_entity_id=assay.euid,
        )
        for rel in relations:
            if rel.relation_type != "lab_method_for_test":
                continue
            ext = ext_repo.get_external_object_by_id(rel.external_object_id)
            if ext and not ext.is_deleted and ext.external_euid:
                ctx["bloom_lab_method_euid"] = ext.external_euid
                break
    except Exception:
        ctx["bloom_lab_method_euid"] = None

    # Get linked documents
    doc_svc = DocumentService(db, current_user.tenant_id, current_user.sub)
    linked_docs = doc_svc.get_linked_documents("AssayRef", assay_euid)
    ctx["documents"] = [
        {
            "id": doc.euid,
            "filename": rev.filename if rev else "Unknown",
            "document_type": rev.document_type if rev else None,
            "size_bytes": rev.size_bytes if rev else None,
        }
        for doc, rev in linked_docs
    ]

    return templates.TemplateResponse(request, "admin/test_definition_detail.html", context=ctx)


@router.post(
    "/admin/test-definitions/{assay_euid}/link-document",
    dependencies=[Depends(require_admin), Depends(csrf_protect)],
)
async def admin_assays_link_document(
    request: Request,
    assay_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Link an existing document to an assay."""
    from app.domain.services.documents import DocumentService
    from app.domain.services.test_definitions import TestDefinitionService

    form_data = await request.form()
    document_id = form_data.get("document_id")

    if not document_id:
        flash(request, "No document selected", "error")
        return RedirectResponse(
            url="/admin/test-definitions", status_code=status.HTTP_303_SEE_OTHER
        )

    try:
        assay = TestDefinitionService(db).get_by_euid(assay_euid)
        doc_svc = DocumentService(db, current_user.tenant_id, current_user.sub)
        doc_svc.link_to_entity(
            document_id, "AssayRef", assay_euid, created_by=current_user.sub_uuid
        )
        flash(request, "Document linked to test", "success")
        safe_assay_id = str(assay.euid)
    except Exception as e:
        logger.error("Error linking document: %s", e, exc_info=True)
        flash(request, "An error occurred while linking document. Please try again.", "error")

    return RedirectResponse(
        url=_safe_redirect_url(
            f"/admin/test-definitions/{safe_assay_id}"
            if "safe_assay_id" in locals()
            else "/admin/test-definitions"
        ),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post(
    "/admin/test-definitions/{assay_euid}/unlink-document",
    dependencies=[Depends(require_admin), Depends(csrf_protect)],
)
async def admin_assays_unlink_document(
    request: Request,
    assay_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Unlink a document from an assay."""
    from app.domain.services.documents import DocumentService
    from app.domain.services.test_definitions import TestDefinitionService

    form_data = await request.form()
    document_id = form_data.get("document_id")

    if not document_id:
        flash(request, "No document selected", "error")
        return RedirectResponse(
            url="/admin/test-definitions", status_code=status.HTTP_303_SEE_OTHER
        )

    try:
        assay = TestDefinitionService(db).get_by_euid(assay_euid)
        doc_svc = DocumentService(db, current_user.tenant_id, current_user.sub)
        doc_svc.unlink_from_entity(
            document_id, "AssayRef", assay_euid, created_by=current_user.sub_uuid
        )
        flash(request, "Document unlinked from test", "success")
        safe_assay_id = str(assay.euid)
    except Exception as e:
        logger.error("Error unlinking document: %s", e, exc_info=True)
        flash(request, "An error occurred while unlinking document. Please try again.", "error")

    return RedirectResponse(
        url=_safe_redirect_url(
            f"/admin/test-definitions/{safe_assay_id}"
            if "safe_assay_id" in locals()
            else "/admin/test-definitions"
        ),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post(
    "/admin/test-definitions/{assay_euid}/deactivate",
    dependencies=[Depends(require_admin), Depends(csrf_protect)],
)
async def admin_assays_deactivate(
    request: Request,
    assay_euid: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Deactivate a test."""
    from app.domain.services.test_definitions import TestDefinitionService

    try:
        svc = TestDefinitionService(db)
        assay = svc.get_by_euid(assay_euid)
        if not assay:
            raise HTTPException(status_code=404, detail="Test definition not found")
        safe_assay_id = str(assay.euid)
        svc.deactivate(assay_euid)
        flash(request, "Test deactivated", "success")
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error deactivating assay: %s", e, exc_info=True)
        flash(request, "An error occurred while deactivating assay. Please try again.", "error")
        return RedirectResponse(
            url="/admin/test-definitions", status_code=status.HTTP_303_SEE_OTHER
        )

    return RedirectResponse(
        url=_safe_redirect_url(f"/admin/test-definitions/{safe_assay_id}"),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.get("/admin/test-definitions/{assay_euid}/edit", response_class=HTMLResponse)
async def admin_assays_edit_form(
    request: Request,
    assay_euid: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Show test edit form."""
    from app.domain.services.test_definitions import TestDefinitionService

    ctx = get_template_context(request, current_user, db)

    svc = TestDefinitionService(db)
    assay = svc.get_by_euid(assay_euid)

    if not assay:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Test not found")

    ctx["assay"] = assay
    ctx["bloom_lab_method_euid"] = None
    ctx["specimen_types_input"] = ", ".join(assay.specimen_types or [])

    # Optional Bloom lab_method external ID mapping (global).
    try:
        from app.persistence.tapdb.external_objects import TapdbExternalObjectRepository

        global_tenant_id = uuid.UUID(int=0)
        ext_repo = TapdbExternalObjectRepository(db)
        relations = ext_repo.list_relations_for_local_entity(
            tenant_id=global_tenant_id,
            local_entity_type="Test",
            local_entity_id=assay.euid,
        )
        for rel in relations:
            if rel.relation_type != "lab_method_for_test":
                continue
            ext = ext_repo.get_external_object_by_id(rel.external_object_id)
            if ext and not ext.is_deleted and ext.external_euid:
                ctx["bloom_lab_method_euid"] = ext.external_euid
                break
    except Exception:
        ctx["bloom_lab_method_euid"] = None
    return templates.TemplateResponse(request, "admin/test_definition_form.html", context=ctx)


@router.post(
    "/admin/test-definitions/{assay_euid}/edit",
    response_class=HTMLResponse,
    dependencies=[Depends(csrf_protect)],
)
async def admin_assays_edit(
    request: Request,
    assay_euid: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Update a test."""
    from app.domain.services.test_definitions import TestDefinitionService, TestDefinitionUpdate

    form_data = await request.form()

    try:
        svc = TestDefinitionService(db)
        assay = svc.get_by_euid(assay_euid)

        if not assay:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Test not found")

        specimen_types = _normalize_specimen_types_input(form_data.get("specimen_types"))
        svc.update(
            assay_euid,
            TestDefinitionUpdate(
                name=form_data.get("name"),
                description=form_data.get("description"),
                category=form_data.get("category"),
                technology=form_data.get("technology"),
                specimen_types=specimen_types,
                is_active=form_data.get("is_active") == "true",
            ),
        )

        # Optional Bloom lab_method external ID mapping (stored via ExternalObject+Relation).
        bloom_lab_method_euid = (form_data.get("bloom_lab_method_euid") or "").strip()
        from app.persistence.tapdb.external_objects import TapdbExternalObjectRepository

        global_tenant_id = uuid.UUID(int=0)
        ext_repo = TapdbExternalObjectRepository(db)
        if bloom_lab_method_euid:
            ext_obj = ext_repo.create_or_update_external_object(
                tenant_id=global_tenant_id,
                provider="bloom",
                object_type="lab_method",
                external_euid=bloom_lab_method_euid,
                metadata={"fulfillment_route_code": assay.code},
                actor_id=current_user.sub_uuid,
            )
            ext_repo.set_single_relation_for_local_entity(
                tenant_id=global_tenant_id,
                relation_type="lab_method_for_test",
                local_entity_type="Test",
                local_entity_id=assay.euid,
                external_object_id=ext_obj.euid,
                metadata={"fulfillment_route_code": assay.code},
                actor_id=current_user.sub_uuid,
            )
        else:
            ext_repo.set_single_relation_for_local_entity(
                tenant_id=global_tenant_id,
                relation_type="lab_method_for_test",
                local_entity_type="Test",
                local_entity_id=assay.euid,
                external_object_id=None,
                actor_id=current_user.sub_uuid,
            )

        flash(request, "Test updated successfully", "success")
        return RedirectResponse(
            url="/admin/test-definitions", status_code=status.HTTP_303_SEE_OTHER
        )
    except HTTPException:
        raise
    except Exception as e:
        ctx = get_template_context(request, current_user, db)
        svc = TestDefinitionService(db)
        ctx["assay"] = svc.get_by_euid(assay_euid)
        ctx["bloom_lab_method_euid"] = (form_data.get("bloom_lab_method_euid") or "").strip()
        ctx["specimen_types_input"] = form_data.get("specimen_types") or ""
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "admin/test_definition_form.html", context=ctx)


# --- Sites (Origin Locations) ---


@router.get("/admin/sites", response_class=HTMLResponse)
async def admin_sites_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """List all sites (admin only)."""
    from app.domain.services.orgs import OrganizationService, SiteService

    ctx = get_template_context(request, current_user, db)
    org_service = OrganizationService(db)
    site_service = SiteService(db)

    sites: list[dict[str, object]] = []
    try:
        organizations = org_service.list_all(active_only=False)
        for org in organizations:
            org_result = org_service.get_with_revision(org.euid)
            org_name = org.euid
            if org_result:
                _org_obj, org_revision = org_result
                org_name = org_revision.display_name or org_revision.name or org.euid
            for site in site_service.list_by_organization(org.euid, active_only=False):
                revision = site.revisions[-1] if getattr(site, "revisions", None) else None
                if revision is None:
                    continue
                sites.append(
                    {
                        "id": site.euid,
                        "name": revision.name,
                        "site_code": revision.site_code,
                        "address": revision.address or {},
                        "contact_email": revision.contact_email,
                        "contact_phone": revision.contact_phone,
                        "is_active": revision.is_active,
                        "organization_euid": org.euid,
                        "organization_name": org_name,
                    }
                )
    except SQLAlchemyError as exc:
        if _is_missing_relation_error(exc):
            _rollback_quietly(db)
            sites = []
        else:
            raise

    sites.sort(key=lambda item: str(item.get("name", "")).lower())

    ctx["sites"] = sites
    return templates.TemplateResponse(request, "admin/sites.html", context=ctx)


@router.get("/admin/sites/create", response_class=HTMLResponse)
async def admin_sites_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Show site creation form."""
    ctx = get_template_context(request, current_user, db)
    ctx["site"] = None
    ctx["revision"] = None
    return templates.TemplateResponse(request, "admin/site_form.html", context=ctx)


@router.post(
    "/admin/sites/create", response_class=HTMLResponse, dependencies=[Depends(csrf_protect)]
)
async def admin_sites_create(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Create a new site."""
    from app.domain.services.orgs import OrganizationService, SiteCreate, SiteService

    form_data = await request.form()

    # Build address dict
    address = {}
    if form_data.get("address_line1"):
        address["line1"] = form_data["address_line1"]
    if form_data.get("address_line2"):
        address["line2"] = form_data["address_line2"]
    if form_data.get("city"):
        address["city"] = form_data["city"]
    if form_data.get("state"):
        address["state"] = form_data["state"]
    if form_data.get("postal_code"):
        address["postal_code"] = form_data["postal_code"]

    try:
        organization_result = OrganizationService(db).get_with_revision_by_uid(
            current_user.tenant_id
        )
        organization = organization_result[0] if organization_result else None
        if organization is None:
            raise ValueError("Organization not found for current admin tenant")
        svc = SiteService(db)
        svc.create(
            SiteCreate(
                organization_id=organization.euid,
                name=form_data["name"],
                site_code=form_data.get("site_code"),
                address=address if address else None,
                contact_email=form_data.get("contact_email"),
                contact_phone=form_data.get("contact_phone"),
            ),
            created_by=current_user.sub_uuid,
        )
        flash(request, "Site created successfully", "success")
        return RedirectResponse(url="/admin/sites", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        ctx = get_template_context(request, current_user, db)
        ctx["site"] = None
        ctx["revision"] = None
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "admin/site_form.html", context=ctx)


@router.get("/admin/sites/{site_id}/edit", response_class=HTMLResponse)
async def admin_sites_edit_form(
    request: Request,
    site_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Show site edit form."""
    from app.domain.services.orgs import SiteService

    ctx = get_template_context(request, current_user, db)
    svc = SiteService(db)
    site = svc.get_by_id(site_id)
    if not site:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Site not found")

    revision = site.revisions[-1] if getattr(site, "revisions", None) else None

    ctx["site"] = site
    ctx["revision"] = revision
    return templates.TemplateResponse(request, "admin/site_form.html", context=ctx)


@router.post(
    "/admin/sites/{site_id}/edit", response_class=HTMLResponse, dependencies=[Depends(csrf_protect)]
)
async def admin_sites_edit(
    request: Request,
    site_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Update a site."""
    from app.domain.services.orgs import SiteService, SiteUpdate

    form_data = await request.form()

    # Build address dict
    address = {}
    if form_data.get("address_line1"):
        address["line1"] = form_data["address_line1"]
    if form_data.get("address_line2"):
        address["line2"] = form_data["address_line2"]
    if form_data.get("city"):
        address["city"] = form_data["city"]
    if form_data.get("state"):
        address["state"] = form_data["state"]
    if form_data.get("postal_code"):
        address["postal_code"] = form_data["postal_code"]

    try:
        svc = SiteService(db)
        site = svc.get_by_id(site_id)
        if site is None:
            raise ValueError("Site not found")
        latest_revision = site.revisions[-1] if site.revisions else None
        requested_is_active = form_data.get("is_active") == "true"
        if latest_revision and latest_revision.is_active and not requested_is_active:
            active_sites = svc.list_by_organization(str(site.organization_id), active_only=True)
            if len(active_sites) <= 1:
                raise ValueError("Organization must have at least one active site")
        svc.update(
            site_id,
            SiteUpdate(
                name=form_data.get("name"),
                site_code=form_data.get("site_code"),
                address=address if address else None,
                contact_email=form_data.get("contact_email"),
                contact_phone=form_data.get("contact_phone"),
                is_active=form_data.get("is_active") == "true",
            ),
            updated_by=current_user.sub_uuid,
        )
        flash(request, "Site updated successfully", "success")
        return RedirectResponse(url="/admin/sites", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        ctx = get_template_context(request, current_user, db)
        site = SiteService(db).get_by_id(site_id)
        revision = site.revisions[-1] if site and getattr(site, "revisions", None) else None
        ctx["site"] = site
        ctx["revision"] = revision
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "admin/site_form.html", context=ctx)


@router.get("/admin/sites/{site_id}", response_class=HTMLResponse)
async def admin_site_detail(
    request: Request,
    site_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Site detail page (admin only)."""
    from app.domain.services.external_objects import (
        BloomConfigResolverService,
        OrgBloomConfigService,
        SiteBloomConfigService,
    )
    from app.domain.services.orgs import OrganizationService, SiteService

    ctx = get_template_context(request, current_user, db)
    site = SiteService(db).get_by_id(site_id)
    if not site:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Site not found")

    revision = site.revisions[-1] if getattr(site, "revisions", None) else None
    organization = OrganizationService(db).get_by_id(str(site.organization_id))

    ctx["site"] = site
    ctx["revision"] = revision
    ctx["organization"] = organization
    ctx["org_bloom_config"] = (
        OrgBloomConfigService(db).get(organization.uid) if organization else None
    )
    ctx["site_bloom_config"] = SiteBloomConfigService(db).get(site_id)
    ctx["effective_bloom_config"] = (
        BloomConfigResolverService(db).get_effective(
            organization_id=organization.uid,
            site_id=site_id,
        )
        if organization and organization.uid
        else None
    )
    if organization and organization.uid:
        ctx.update(
            _build_tube_panel_context(
                db,
                organization.uid,
                anchor_type="Site",
                anchor_id=site.euid,
                return_to=f"/admin/sites/{site.euid}",
            )
        )
    return templates.TemplateResponse(request, "admin/site_detail.html", context=ctx)


@router.post(
    "/admin/sites/{site_id}/integrations/bloom",
    dependencies=[Depends(require_admin), Depends(csrf_protect)],
)
async def admin_site_bloom_config_save(
    request: Request,
    site_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Create or update site-level Bloom config from the admin UI."""
    from app.domain.services.external_objects import SiteBloomConfigService, SiteBloomConfigUpsert
    from app.domain.services.orgs import OrganizationService, SiteService

    site = SiteService(db).get_by_id(site_id)
    if site is None:
        raise HTTPException(status_code=404, detail="Site not found")
    organization = OrganizationService(db).get_by_id(str(site.organization_id))
    if organization is None or organization.uid is None:
        raise HTTPException(status_code=404, detail="Organization not found for site")

    form_data = await request.form()
    action = (form_data.get("action") or "save").strip().lower()
    payload = _extract_bloom_config_form_payload(form_data)
    if action == "validate":
        try:
            _validate_bloom_credentials(
                bloom_base_url=str(payload["bloom_base_url"]),
                bloom_api_key_secret_ref=str(payload["bloom_api_key_secret_ref"]),
            )
            flash(
                request,
                "Bloom credentials validated successfully. Values were not saved.",
                "success",
            )
        except Exception as exc:
            flash(request, f"Bloom credential validation failed: {exc}", "error")
        safe_site_id = str(site.euid)
        return RedirectResponse(
            url=_safe_redirect_url(f"/admin/sites/{safe_site_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )

    try:
        SiteBloomConfigService(db).upsert(
            site_id,
            organization.uid,
            SiteBloomConfigUpsert(
                enabled=bool(payload["enabled"]),
                bloom_base_url=str(payload["bloom_base_url"]),
                bloom_api_key_secret_ref=str(payload["bloom_api_key_secret_ref"]),
                bloom_webhook_secret_ref=(
                    str(payload["bloom_webhook_secret_ref"])
                    if payload["bloom_webhook_secret_ref"] is not None
                    else None
                ),
                bloom_service_user=(
                    str(payload["bloom_service_user"])
                    if payload["bloom_service_user"] is not None
                    else None
                ),
            ),
            actor_id=current_user.sub_uuid,
        )
        flash(request, "Site Bloom integration saved.", "success")
        safe_site_id = str(site.euid)
    except Exception as exc:
        db.rollback()
        flash(request, str(exc), "error")
    return RedirectResponse(
        url=_safe_redirect_url(
            f"/admin/sites/{safe_site_id}" if "safe_site_id" in locals() else "/admin/sites"
        ),
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.get("/admin/users", response_class=HTMLResponse)
async def admin_users_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
    tenant_id: str | None = Query(None),
    is_active: str | None = Query(None),
):
    """List all users (admin only)."""
    from app.domain.services.users import UserService

    ctx = get_template_context(request, current_user, db)

    # Get all organizations for filter
    organizations = _get_all_organizations_with_revisions(db)
    ctx["organizations"] = organizations

    # Parse filters
    tenant_filter = None
    if tenant_id:
        from app.domain.services.orgs import OrganizationService

        org_svc = OrganizationService(db)
        org = org_svc.get_by_id(tenant_id)
        if org is not None and org.uid is not None:
            tenant_filter = org.uid
        else:
            try:
                tenant_filter = uuid.UUID(tenant_id)
            except ValueError:
                tenant_filter = None

    is_active_filter = None
    if is_active == "true":
        is_active_filter = True
    elif is_active == "false":
        is_active_filter = False

    # Get users
    user_svc = UserService(db, current_user.sub)
    users = user_svc.list_users(
        tenant_id=tenant_filter,
        is_active=is_active_filter,
        limit=100,
    )

    # Enrich with tenant names
    org_map = {str(org.uid): org for org in organizations if getattr(org, "uid", None)}
    for user in users:
        org = org_map.get(str(user.tenant_id))
        user.tenant_name = org.display_name or org.name if org else "Unknown"

    ctx["users"] = users
    ctx["tenant_filter"] = tenant_id
    ctx["is_active_filter"] = is_active

    return templates.TemplateResponse(request, "admin/users.html", context=ctx)


@router.get("/admin/users/create", response_class=HTMLResponse)
async def admin_users_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Show user creation form."""
    ctx = get_template_context(request, current_user, db)

    # Get all organizations
    ctx["organizations"] = _get_all_organizations_with_revisions(db)
    ctx["user"] = None

    return templates.TemplateResponse(request, "admin/user_form.html", context=ctx)


@router.post(
    "/admin/users/create", response_class=HTMLResponse, dependencies=[Depends(csrf_protect)]
)
async def admin_users_create(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Create a new user."""
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserCreate, UserService

    form_data = await request.form()

    # Parse roles (checkboxes)
    roles = form_data.getlist("roles")
    if not roles:
        # Show error
        ctx = get_template_context(request, current_user, db)
        ctx["organizations"] = _get_all_organizations_with_revisions(db)
        ctx["user"] = None
        ctx["error"] = "At least one role must be selected"
        return templates.TemplateResponse(request, "admin/user_form.html", context=ctx)

    try:
        tenant_value = str(form_data["tenant_id"]).strip()
        org = OrganizationService(db).get_by_id(tenant_value)
        if org is not None and org.uid is not None:
            tenant_uuid = org.uid
        else:
            tenant_uuid = uuid.UUID(tenant_value)

        user_svc = UserService(db, current_user.sub)
        user_svc.invite(
            UserCreate(
                email=form_data["email"],
                name=form_data.get("name") or None,
                tenant_id=tenant_uuid,
                roles=roles,
            )
        )
        return RedirectResponse(url="/admin/users", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        # Show error
        ctx = get_template_context(request, current_user, db)
        ctx["organizations"] = _get_all_organizations_with_revisions(db)
        ctx["user"] = None
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "admin/user_form.html", context=ctx)


@router.get("/admin/users/{user_id}", response_class=HTMLResponse)
async def admin_users_detail(
    request: Request,
    user_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Show user detail page."""
    from app.domain.services.orgs import OrganizationService
    from app.domain.services.users import UserService

    ctx = get_template_context(request, current_user, db)

    user_svc = UserService(db, current_user.sub)
    user = user_svc.get_by_id(user_id)

    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    # Get tenant name
    org_svc = OrganizationService(db)
    result = org_svc.get_with_revision_by_uid(user.tenant_id)
    tenant_name = result[1].display_name or result[1].name if result else None

    ctx["user"] = user
    ctx["tenant_name"] = tenant_name

    return templates.TemplateResponse(request, "admin/user_detail.html", context=ctx)


@router.get("/admin/users/{user_id}/edit", response_class=HTMLResponse)
async def admin_users_edit_form(
    request: Request,
    user_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Show user edit form."""
    from app.domain.services.users import UserService

    ctx = get_template_context(request, current_user, db)

    user_svc = UserService(db, current_user.sub)
    user = user_svc.get_by_id(user_id)

    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")

    # Get all organizations
    ctx["organizations"] = _get_all_organizations_with_revisions(db)
    ctx["user"] = user

    return templates.TemplateResponse(request, "admin/user_form.html", context=ctx)


@router.post(
    "/admin/users/{user_id}/edit", response_class=HTMLResponse, dependencies=[Depends(csrf_protect)]
)
async def admin_users_edit(
    request: Request,
    user_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Update a user."""
    from app.domain.services.users import UserService, UserUpdate

    form_data = await request.form()

    # Parse roles (checkboxes)
    roles = form_data.getlist("roles")
    if not roles:
        # Show error
        ctx = get_template_context(request, current_user, db)
        user_svc = UserService(db, current_user.sub)
        user = user_svc.get_by_id(user_id)
        ctx["organizations"] = _get_all_organizations_with_revisions(db)
        ctx["user"] = user
        ctx["error"] = "At least one role must be selected"
        return templates.TemplateResponse(request, "admin/user_form.html", context=ctx)

    try:
        user_svc = UserService(db, current_user.sub)
        is_active = form_data.get("is_active") == "true"

        user_svc.update(
            user_id,
            UserUpdate(
                email=form_data["email"],
                name=form_data.get("name") or None,
                roles=roles,
                is_active=is_active,
            ),
        )
        return RedirectResponse(url="/admin/users", status_code=status.HTTP_303_SEE_OTHER)
    except Exception as e:
        # Show error
        ctx = get_template_context(request, current_user, db)
        user_svc = UserService(db, current_user.sub)
        user = user_svc.get_by_id(user_id)
        ctx["organizations"] = _get_all_organizations_with_revisions(db)
        ctx["user"] = user
        ctx["error"] = str(e)
        return templates.TemplateResponse(request, "admin/user_form.html", context=ctx)


@router.post("/admin/users/{user_id}/deactivate", dependencies=[Depends(csrf_protect)])
async def admin_users_deactivate(
    user_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Deactivate a user."""
    from app.domain.services.users import UserService

    user_svc = UserService(db, current_user.sub)
    user_svc.deactivate(user_id)
    return RedirectResponse(url="/admin/users", status_code=status.HTTP_303_SEE_OTHER)


@router.post("/admin/users/{user_id}/activate", dependencies=[Depends(csrf_protect)])
async def admin_users_activate(
    user_id: str,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    db: Session = Depends(get_db),
):
    """Activate a user."""
    from app.domain.services.users import UserService

    user_svc = UserService(db, current_user.sub)
    user_svc.activate(user_id)
    return RedirectResponse(url="/admin/users", status_code=status.HTTP_303_SEE_OTHER)


# --- Support Ticket Routes ---


@router.get("/support", response_class=HTMLResponse)
async def support_list(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    status: str | None = Query(None),
    ticket_type: str | None = Query(None),
):
    """List support tickets."""
    from app.domain.services.support import SupportTicketService

    ctx = get_template_context(request, current_user, db)

    svc = SupportTicketService(db, current_user.tenant_id, current_user.sub)
    tickets = svc.list_tickets(
        status=status,
        ticket_type=ticket_type,
        limit=100,
    )

    ctx["tickets"] = tickets
    ctx["status_filter"] = status
    ctx["type_filter"] = ticket_type

    return templates.TemplateResponse(request, "support/list.html", context=ctx)


@router.get("/support/create", response_class=HTMLResponse)
async def support_create_form(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
    trace_id: str | None = Query(None),
    timestamp: str | None = Query(None),
    error_user: str | None = Query(None),
):
    """Show support ticket creation form.

    When linked from the 500 error modal, trace_id / timestamp / error_user
    query params pre-fill the form so the user can review before submitting.
    """
    from app.domain.services.site_scope import list_tenant_site_options

    ctx = get_template_context(request, current_user, db)
    site_options = list_tenant_site_options(db, current_user.tenant_id)
    ctx["site_options"] = site_options
    ctx["selected_site_id"] = site_options[0].id if len(site_options) == 1 else None

    # Pre-fill from error modal context
    if trace_id:
        ctx["prefill_subject"] = f"Error Report — Trace {trace_id[:8]}"
        ctx["prefill_description"] = (
            f"An unexpected error occurred.\n\n"
            f"Trace ID: {trace_id}\n"
            f"Time: {timestamp or 'N/A'}\n"
            f"User: {error_user or 'N/A'}\n\n"
            f"Please describe what you were doing when this error occurred:\n"
        )
        ctx["prefill_ticket_type"] = "TECHNICAL"
        ctx["prefill_priority"] = "HIGH"
        ctx["prefill_trace_id"] = trace_id

    return templates.TemplateResponse(request, "support/create.html", context=ctx)


@router.post("/support/create", response_class=HTMLResponse, dependencies=[Depends(csrf_protect)])
async def support_create(
    request: Request,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Create a new support ticket."""
    from app.domain.services.support import SupportTicketService, TicketCreate

    form_data = await request.form()

    # Parse optional UUIDs
    related_order_id = (form_data.get("related_order_id") or "").strip() or None
    related_shipment_id = (form_data.get("related_shipment_id") or "").strip() or None
    site_id = (form_data.get("site_id") or "").strip() or None

    try:
        svc = SupportTicketService(db, current_user.tenant_id, current_user.sub)
        ticket, revision = svc.create(
            TicketCreate(
                subject=form_data["subject"],
                description=form_data["description"],
                ticket_type=form_data["ticket_type"],
                priority=form_data["priority"],
                related_order_id=related_order_id,
                related_shipment_id=related_shipment_id,
                site_id=site_id,
            ),
            created_by=current_user.sub_uuid,
        )
        safe_ticket_id = str(ticket.euid)
        return RedirectResponse(
            url=_safe_redirect_url(f"/support/{safe_ticket_id}"),
            status_code=status.HTTP_303_SEE_OTHER,
        )
    except Exception as e:
        from app.domain.services.site_scope import list_tenant_site_options

        ctx = get_template_context(request, current_user, db)
        ctx["error"] = str(e)
        site_options = list_tenant_site_options(db, current_user.tenant_id)
        ctx["site_options"] = site_options
        ctx["selected_site_id"] = site_id or (
            site_options[0].id if len(site_options) == 1 else None
        )
        return templates.TemplateResponse(request, "support/create.html", context=ctx)


@router.get("/support/{ticket_id}", response_class=HTMLResponse)
async def support_detail(
    request: Request,
    ticket_id: str,
    current_user: Annotated[CurrentUser, Depends(get_current_user_web)],
    db: Session = Depends(get_db),
):
    """Show support ticket detail."""
    from app.domain.services.support import SupportTicketService

    ctx = get_template_context(request, current_user, db)

    svc = SupportTicketService(db, current_user.tenant_id, current_user.sub)
    result = svc.get_by_id(ticket_id)

    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ticket not found")

    ticket, revision = result
    ctx["ticket"] = ticket
    ctx["revision"] = revision

    return templates.TemplateResponse(request, "support/detail.html", context=ctx)


@router.post("/support/{ticket_id}/resolve", dependencies=[Depends(csrf_protect)])
async def support_resolve(
    ticket_id: str,
    request: Request,
    current_user: Annotated[CurrentUser, Depends(require_internal)],
    db: Session = Depends(get_db),
):
    """Resolve a support ticket (internal users only)."""
    from app.domain.services.support import SupportTicketService

    form_data = await request.form()

    svc = SupportTicketService(db, current_user.tenant_id, current_user.sub)
    result = svc.get_by_id(ticket_id)
    if not result:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Ticket not found")
    ticket, _revision = result
    safe_ticket_id = str(ticket.euid)

    svc.resolve(
        ticket_id,
        resolution_notes=form_data["resolution_notes"],
        updated_by=current_user.sub_uuid,
    )

    return RedirectResponse(
        url=_safe_redirect_url(f"/support/{safe_ticket_id}"), status_code=status.HTTP_303_SEE_OTHER
    )
