"""LSMC Hub - Database Engine and Session Management.

Engine and session factory are created lazily on first access so that
importing this module does not require a valid DATABASE_URL (e.g. during
test collection when no database is running).
"""

from __future__ import annotations

from collections.abc import Generator
from typing import Annotated

from fastapi import Depends
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

_engine = None
_SessionLocal = None


def _get_engine():
    global _engine
    if _engine is None:
        from app.settings import settings

        _engine = create_engine(
            str(settings.database_url),
            pool_pre_ping=True,
            pool_size=5,
            max_overflow=10,
            echo=settings.debug,
        )
    return _engine


def _get_session_local():
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(
            autocommit=False,
            autoflush=False,
            bind=_get_engine(),
        )
    return _SessionLocal


# ---------------------------------------------------------------------------
# Public API — these are properties that behave like the old module globals.
# Callers that do ``from app.db.engine import engine`` or
# ``from app.db.engine import SessionLocal`` get a lazy wrapper via
# module-level ``__getattr__``.
# ---------------------------------------------------------------------------


class _EngineProxy:
    """Thin proxy so ``engine.xxx`` works without import-time creation."""

    def __getattr__(self, name):
        return getattr(_get_engine(), name)

    def __repr__(self):
        return repr(_get_engine())


class _SessionLocalProxy:
    """Thin proxy so ``SessionLocal(...)`` works without import-time creation."""

    def __call__(self, **kw):
        return _get_session_local()(**kw)

    def __getattr__(self, name):
        return getattr(_get_session_local(), name)

    def __repr__(self):
        return repr(_get_session_local())


engine = _EngineProxy()
SessionLocal = _SessionLocalProxy()


def get_db() -> Generator[Session, None, None]:
    """
    FastAPI dependency that provides a database session.

    Yields a session and ensures it is closed after the request.
    """
    db = _get_session_local()()
    try:
        yield db
    finally:
        db.close()


# Type alias for dependency injection
DbSession = Annotated[Session, Depends(get_db)]
