# Atlas Authentication Setup

Atlas uses AWS Cognito for authentication, sharing a User Pool with bloom
and daylily-ursa for consistent authentication across all three applications.

## Configuration

Create `~/.config/lsmc-atlas/config.yaml`:

```yaml
authentication:
  mode: cognito
  cognito:
    region: us-west-2
    user_pool_id: us-west-2_examplePoolId
    app_client_id: exampleclientid123
    client_name: atlas
    domain: daylily-ursa-5r8giqv5p.auth.us-west-2.amazoncognito.com
    redirect_uri: https://localhost:8915/auth/callback
    logout_url: https://localhost:8915/

  # Allowed email domains for authentication
  # Empty list blocks all domains. Use ["*"] to allow all domains.
  allowed_email_domains:
    - lsmc.bio
    - lsmc.com
    - lsmc.life
    - daylilyinformatics.com
    - dyly.bio

  # Map Cognito groups to roles
  group_role_map:
    admin: ADMIN
    analysts: ANALYST
    viewers: VIEWER
```

Create or update the Cognito pool/app with `daycog`, then import or bind the resolved contract into Atlas YAML.

```bash
source ../../daylily/daylily-cognito/activate
export AWS_PROFILE=lsmc
export AWS_REGION=us-west-2

daycog config create-all \
  --pool-name daylily-ursa-users \
  --region "$AWS_REGION" \
  --default-client atlas

atlas cognito import \
  --pool-name daylily-ursa-users \
  --region "$AWS_REGION" \
  --client-name atlas \
  --profile "$AWS_PROFILE"

# Or bind an already-known contract directly into Atlas YAML
atlas cognito bind \
  --pool-id us-west-2_examplePoolId \
  --region "$AWS_REGION" \
  --app-client-id exampleclientid123 \
  --client-name atlas \
  --domain daylily-ursa-5r8giqv5p.auth.us-west-2.amazoncognito.com \
  --callback-url https://localhost:8915/auth/callback \
  --logout-url https://localhost:8915/

# Validate Atlas YAML against daycog context data and the live Cognito app client
atlas cognito status --port 8915
atlas cognito validate --port 8915
```

Atlas no longer owns Cognito pool/app/user lifecycle commands. Use `daycog` directly for pool creation, app creation, callback/logout updates, and user management.

## Roles

| Role | Description |
|------|-------------|
| `ADMIN` | System administrator — full access across all tenants |
| `INTERNAL_USER` | LSMC staff — intake, matching, results, cross-tenant views |
| `EXTERNAL_USER_ADMIN` | Org admin — manage users/tokens/settings within own tenant |
| `EXTERNAL_USER` | Clinic/collaborator — tenant-scoped ordering, patient, shipment access |
| `READ_WRITE` | Modifier role — combined with EXTERNAL_USER for data entry |
| `READ_ONLY` | Viewer role — combined with EXTERNAL_USER for read-only access |

### Cognito Group → Role Mapping (defaults)

| Cognito Group | Atlas Roles |
|---------------|-------------|
| `lsmc-admins` | `ADMIN` |
| `lsmc-staff` | `INTERNAL_USER` |
| `lsmc-customers` | `EXTERNAL_USER` |
| `lsmc-customer-admins` | `EXTERNAL_USER`, `EXTERNAL_USER_ADMIN` |
| `customer-admins` | `EXTERNAL_USER`, `EXTERNAL_USER_ADMIN` |

These defaults are in `app/settings.py` under `DEFAULT_COGNITO_GROUP_ROLE_MAP`.

## API Token Scopes

API tokens have a `scope` field that constrains the token's effective permissions regardless of the user's actual roles. See [TOKEN_SCOPES.md](TOKEN_SCOPES.md) for full reference.

## Running the Server

```bash
# Start in foreground
atlas server start

# Start in background
atlas server start --background

# Stop server
atlas server stop

# View logs
atlas server logs
```

## Shared Cognito Pool

All three applications (lsmc-atlas, bloom, daylily-ursa) share a single Cognito User Pool:

- **Pool ID:** `us-west-2_pUqKyIM1N`
- **Region:** `us-west-2`
- **Domain:** `lsmc-shared-dev-puqkyim1n.auth.us-west-2.amazoncognito.com`

This ensures users can authenticate with the same credentials across all applications.

## Email Domain Restrictions

Authentication is restricted to the following allowed email domains:
- lsmc.bio
- lsmc.com
- lsmc.life
- daylilyinformatics.com
- dyly.bio

To allow all domains, set `allowed_email_domains: ["*"]`
To block all domains (disable auth), set `allowed_email_domains: []`
To block specific domains, add them to `blocked_email_domains` (takes precedence over allowed list).

## See Also

- [daylily-cognito](https://github.com/Daylily-Informatics/daylily-cognito) - Shared auth library
- [bloom](https://github.com/Daylily-Informatics/bloom) - Bloom configuration
- [daylily-ursa](https://github.com/Daylily-Informatics/daylily-ursa) - URSA configuration
