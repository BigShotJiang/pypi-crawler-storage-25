# LSMC Atlas — Manual RBAC Testing Guide

> **Purpose**: Step-by-step instructions for creating Cognito test users and
> manually verifying role-based access control across the Atlas UI.
>
> **Prerequisites**:
> - AWS CLI installed and configured with profile `lsmc`
> - Cognito User Pool `lsmc-atlas-dev` exists in `us-west-2`
> - Atlas server running at `http://localhost:8915`
> - Atlas CLI (`atlas`) available in your shell

---

## Table of Contents

1. [Part 1 — Create Missing Cognito Groups](#part-1--create-missing-cognito-groups)
2. [Part 2 — Create Five Test Users in Cognito](#part-2--create-five-test-users-in-cognito)
3. [Part 3 — Set Permanent Passwords](#part-3--set-permanent-passwords)
4. [Part 4 — Assign Users to Cognito Groups](#part-4--assign-users-to-cognito-groups)
5. [Part 5 — Provision Users in Atlas Database](#part-5--provision-users-in-atlas-database)
6. [Part 6 — Login Instructions](#part-6--login-instructions)
7. [Part 7 — Per-Persona Testing Checklists](#part-7--per-persona-testing-checklists)
8. [Part 8 — Cross-Cutting Verification Tests](#part-8--cross-cutting-verification-tests)
9. [Part 9 — Quick Reference: Groups → Roles → Permissions](#part-9--quick-reference-groups--roles--permissions)

---

## Environment Setup

All AWS CLI commands use these values. Export them once at the start of your
session:

```bash
export AWS_PROFILE="lsmc"
export AWS_REGION="us-west-2"

# Fetch the Pool ID dynamically
POOL_ID=$(aws cognito-idp list-user-pools --max-results 60 \
  --query "UserPools[?Name=='lsmc-atlas-dev'].Id | [0]" --output text)

echo "Pool ID: $POOL_ID"
```

Verify the output is a valid pool ID (e.g., `us-west-2_pUqKyIM1N`) before
proceeding.

---

## Part 1 — Create Missing Cognito Groups

Your pool currently has three groups: `lsmc-admins`, `lsmc-staff`,
`lsmc-customers`. Two additional groups are needed for full RBAC coverage.

### 1.1 Create `lsmc-customer-admins`

```bash
aws cognito-idp create-group \
  --user-pool-id "$POOL_ID" \
  --group-name "lsmc-customer-admins" \
  --description "External org admins — maps to EXTERNAL_USER + EXTERNAL_USER_ADMIN"
```

### 1.2 Create `lsmc-readonly`

```bash
aws cognito-idp create-group \
  --user-pool-id "$POOL_ID" \
  --group-name "lsmc-readonly" \
  --description "Read-only access — maps to READ_ONLY role"
```

### 1.3 Verify all groups exist

```bash
aws cognito-idp list-groups \
  --user-pool-id "$POOL_ID" \
  --query "Groups[].GroupName" --output table
```

Expected output should list all five groups:

| Group Name             |
|------------------------|
| `lsmc-admins`          |
| `lsmc-staff`           |
| `lsmc-customers`       |
| `lsmc-customer-admins` |
| `lsmc-readonly`        |

---

## Part 2 — Create Five Test Users in Cognito

Each user is created with a temporary password and email auto-verified.
`--message-action SUPPRESS` prevents Cognito from sending welcome emails.

### 2.1 test-customer@lsmc.bio

```bash
aws cognito-idp admin-create-user \
  --user-pool-id "$POOL_ID" \
  --username "test-customer@lsmc.bio" \
  --user-attributes \
    Name=email,Value="test-customer@lsmc.bio" \
    Name=email_verified,Value=true \
  --temporary-password 'TestUser1!' \
  --message-action SUPPRESS
```

### 2.2 test-customer-admin@lsmc.bio

```bash
aws cognito-idp admin-create-user \
  --user-pool-id "$POOL_ID" \
  --username "test-customer-admin@lsmc.bio" \
  --user-attributes \
    Name=email,Value="test-customer-admin@lsmc.bio" \
    Name=email_verified,Value=true \
  --temporary-password 'TestUser1!' \
  --message-action SUPPRESS
```

### 2.3 test-staff@lsmc.bio

```bash
aws cognito-idp admin-create-user \
  --user-pool-id "$POOL_ID" \
  --username "test-staff@lsmc.bio" \
  --user-attributes \
    Name=email,Value="test-staff@lsmc.bio" \
    Name=email_verified,Value=true \
  --temporary-password 'TestUser1!' \
  --message-action SUPPRESS
```

### 2.4 test-admin@lsmc.bio

```bash
aws cognito-idp admin-create-user \
  --user-pool-id "$POOL_ID" \
  --username "test-admin@lsmc.bio" \
  --user-attributes \
    Name=email,Value="test-admin@lsmc.bio" \
    Name=email_verified,Value=true \
  --temporary-password 'TestUser1!' \
  --message-action SUPPRESS
```

### 2.5 test-readonly@lsmc.bio

```bash
aws cognito-idp admin-create-user \
  --user-pool-id "$POOL_ID" \
  --username "test-readonly@lsmc.bio" \
  --user-attributes \
    Name=email,Value="test-readonly@lsmc.bio" \
    Name=email_verified,Value=true \
  --temporary-password 'TestUser1!' \
  --message-action SUPPRESS
```

### 2.6 Verify all users exist

```bash
aws cognito-idp list-users \
  --user-pool-id "$POOL_ID" \
  --filter 'email ^= "test-"' \
  --query "Users[].[Username, UserStatus, Attributes[?Name=='email'].Value | [0]]" \
  --output table
```

---

## Part 3 — Set Permanent Passwords

Newly created Cognito users are in `FORCE_CHANGE_PASSWORD` status. Setting a
permanent password moves them to `CONFIRMED` so they can log in directly via
the Hosted UI without a password-change challenge.

### 3.1 test-customer@lsmc.bio

```bash
aws cognito-idp admin-set-user-password \
  --user-pool-id "$POOL_ID" \
  --username "test-customer@lsmc.bio" \
  --password 'TestUser1!' \
  --permanent
```

### 3.2 test-customer-admin@lsmc.bio

```bash
aws cognito-idp admin-set-user-password \
  --user-pool-id "$POOL_ID" \
  --username "test-customer-admin@lsmc.bio" \
  --password 'TestUser1!' \
  --permanent
```

### 3.3 test-staff@lsmc.bio

```bash
aws cognito-idp admin-set-user-password \
  --user-pool-id "$POOL_ID" \
  --username "test-staff@lsmc.bio" \
  --password 'TestUser1!' \
  --permanent
```

### 3.4 test-admin@lsmc.bio

```bash
aws cognito-idp admin-set-user-password \
  --user-pool-id "$POOL_ID" \
  --username "test-admin@lsmc.bio" \
  --password 'TestUser1!' \
  --permanent
```

### 3.5 test-readonly@lsmc.bio

```bash
aws cognito-idp admin-set-user-password \
  --user-pool-id "$POOL_ID" \
  --username "test-readonly@lsmc.bio" \
  --password 'TestUser1!' \
  --permanent
```

### 3.6 Verify status is CONFIRMED

```bash
aws cognito-idp list-users \
  --user-pool-id "$POOL_ID" \
  --filter 'email ^= "test-"' \
  --query "Users[].[Attributes[?Name=='email'].Value | [0], UserStatus]" \
  --output table
```

All five users should show `CONFIRMED`.

---

## Part 4 — Assign Users to Cognito Groups

Each user is added to exactly one Cognito group. The group determines which
Atlas roles are mapped at login time (see `DEFAULT_COGNITO_GROUP_ROLE_MAP` in
`app/settings.py`).

| User                          | Cognito Group          | Mapped Atlas Roles                        |
|-------------------------------|------------------------|-------------------------------------------|
| `test-customer@lsmc.bio`      | `lsmc-customers`       | `EXTERNAL_USER`                           |
| `test-customer-admin@lsmc.bio`| `lsmc-customer-admins` | `EXTERNAL_USER`, `EXTERNAL_USER_ADMIN`    |
| `test-staff@lsmc.bio`         | `lsmc-staff`           | `INTERNAL_USER`                           |
| `test-admin@lsmc.bio`         | `lsmc-admins`          | `ADMIN`                                   |
| `test-readonly@lsmc.bio`      | `lsmc-readonly`        | `READ_ONLY`                               |

### 4.1 test-customer → lsmc-customers

```bash
aws cognito-idp admin-add-user-to-group \
  --user-pool-id "$POOL_ID" \
  --username "test-customer@lsmc.bio" \
  --group-name "lsmc-customers"
```

### 4.2 test-customer-admin → lsmc-customer-admins

```bash
aws cognito-idp admin-add-user-to-group \
  --user-pool-id "$POOL_ID" \
  --username "test-customer-admin@lsmc.bio" \
  --group-name "lsmc-customer-admins"
```

### 4.3 test-staff → lsmc-staff

```bash
aws cognito-idp admin-add-user-to-group \
  --user-pool-id "$POOL_ID" \
  --username "test-staff@lsmc.bio" \
  --group-name "lsmc-staff"
```

### 4.4 test-admin → lsmc-admins

```bash
aws cognito-idp admin-add-user-to-group \
  --user-pool-id "$POOL_ID" \
  --username "test-admin@lsmc.bio" \
  --group-name "lsmc-admins"
```

### 4.5 test-readonly → lsmc-readonly

```bash
aws cognito-idp admin-add-user-to-group \
  --user-pool-id "$POOL_ID" \
  --username "test-readonly@lsmc.bio" \
  --group-name "lsmc-readonly"
```

### 4.6 Verify group memberships

```bash
for USER in test-customer test-customer-admin test-staff test-admin test-readonly; do
  echo "--- ${USER}@lsmc.bio ---"
  aws cognito-idp admin-list-groups-for-user \
    --user-pool-id "$POOL_ID" \
    --username "${USER}@lsmc.bio" \
    --query "Groups[].GroupName" --output text
done
```

---

## Part 5 — Provision Users in Atlas Database

If `auto_provision_users` is enabled in your config, users are created in the
Atlas DB on first login. Otherwise, pre-create them with the CLI.

> **⚠️ Replace placeholder tenant IDs** below with actual UUIDs from your
> database. Run `atlas users list` or query the `organization` table to find
> them.

```bash
# Find your tenant IDs first:
atlas users list
```

### 5.1 External users (need a customer org tenant ID)

```bash
CUSTOMER_TENANT="<REPLACE_WITH_CUSTOMER_ORG_UUID>"

atlas users create "test-customer@lsmc.bio" \
  --name "Test Customer" \
  --tenant-id "$CUSTOMER_TENANT"

atlas users create "test-customer-admin@lsmc.bio" \
  --name "Test Org Admin" \
  --tenant-id "$CUSTOMER_TENANT"

atlas users create "test-readonly@lsmc.bio" \
  --name "Test Readonly" \
  --tenant-id "$CUSTOMER_TENANT"
```

### 5.2 Internal / admin users (need the LSMC org tenant ID)

```bash
LSMC_TENANT="<REPLACE_WITH_LSMC_ORG_UUID>"

atlas users create "test-staff@lsmc.bio" \
  --name "Test Staff" \
  --tenant-id "$LSMC_TENANT"

atlas users create "test-admin@lsmc.bio" \
  --name "Test Admin" \
  --admin \
  --tenant-id "$LSMC_TENANT"
```

### 5.3 Promote the org admin user

After creating `test-customer-admin@lsmc.bio`, add the
`EXTERNAL_USER_ADMIN` role:

```bash
atlas users make-ext-admin "test-customer-admin@lsmc.bio"
```

### 5.4 Verify provisioned users

```bash
atlas users list
```

---

## Part 6 — Login Instructions

### How to log in as a test user

1. Ensure the Atlas server is running: `atlas server start`
2. Open **http://localhost:8915** in your browser
3. Click **Login** — you will be redirected to the Cognito Hosted UI
4. Enter the test user's email and password: `TestUser1!`
5. After successful authentication, you are redirected back to Atlas

### How to switch between personas

1. Click **Logout** in the top-right corner of the Atlas UI
2. You will be redirected to the login page
3. Click **Login** again and enter the next test user's credentials
4. **Tip**: Use a private/incognito window for a second persona simultaneously

### Verify the active role

After login, check the **role indicator badge** in the top-right header bar:

| Badge | Meaning            |
|-------|--------------------|
| 🛡️    | `ADMIN`            |
| 🔬    | `INTERNAL_USER`    |
| 👤    | `EXTERNAL_USER`    |
| 👁️    | `READ_ONLY`        |

The user's email is displayed next to the badge.

---

## Part 7 — Per-Persona Testing Checklists

For each persona, log in and work through every item. Mark ✅ or ❌ as you go.

---

### Persona 1: EXTERNAL_USER — `test-customer@lsmc.com`

**Cognito group**: `lsmc-customers`
**Mapped roles**: `EXTERNAL_USER`
**Scope**: Tenant-scoped (own organization only)

#### Navigation Bar Visibility

| Element                | Expected | Result |
|------------------------|----------|--------|
| Dashboard              | ✅ Visible |        |
| Orders                 | ✅ Visible |        |
| Shipments              | ✅ Visible |        |
| Results                | ✅ Visible |        |
| Manage → Patients      | ✅ Visible |        |
| Manage → Clinicians    | ✅ Visible |        |
| Manage → My Organization | ✅ Visible |        |
| Support                | ✅ Visible |        |
| **Intake**             | ❌ Hidden  |        |
| **Entities dropdown**  | ❌ Hidden  |        |
| **Admin**              | ❌ Hidden  |        |

#### Allowed Actions

| Action                              | Expected | Result |
|-------------------------------------|----------|--------|
| View dashboard with own-org stats   | ✅ Works  |        |
| Dashboard: no "Pending Exceptions"  | ✅ Hidden |        |
| Orders → view list                  | ✅ Works  |        |
| Orders → + New Order                | ✅ Works  |        |
| Orders → edit a DRAFT order         | ✅ Works  |        |
| Orders → submit an order            | ✅ Works  |        |
| Patients → view list                | ✅ Works  |        |
| Patients → create new patient       | ✅ Works  |        |
| Patients → edit patient             | ✅ Works  |        |
| Shipments → view list               | ✅ Works  |        |
| Shipments → + New Shipment          | ✅ Works  |        |
| Results → view released results     | ✅ Works  |        |
| Results → unpublished results sets  | ❌ Hidden |        |
| My Organization → view org info     | ✅ Works  |        |
| My Organization → view user list    | ✅ Works (read-only) | |
| Profile → update own settings       | ✅ Works  |        |

#### Denied Actions (should return 403 or be hidden)

| Action / URL                                | Expected | Result |
|---------------------------------------------|----------|--------|
| My Org → Users → "New User" button          | ❌ Hidden |        |
| My Org → Users → Deactivate/Activate        | ❌ Hidden |        |
| My Org → Settings → Edit                    | ❌ 403    |        |
| Navigate to `/intake`                       | ❌ 403    |        |
| Navigate to `/tubes`                        | ❌ 403    |        |
| Navigate to `/testkits`                     | ❌ 403    |        |
| Navigate to `/manifests`                    | ❌ 403    |        |
| Navigate to `/documents`                    | ❌ 403    |        |
| Navigate to `/exceptions`                   | ❌ 403    |        |
| Navigate to `/admin`                        | ❌ 403    |        |
| Navigate to `/admin/users`                  | ❌ 403    |        |
| Navigate to `/admin/organizations`          | ❌ 403    |        |

#### Tenant Isolation

| Check                                       | Expected | Result |
|---------------------------------------------|----------|--------|
| Orders list shows only own-org orders       | ✅ Yes    |        |
| Patients list shows only own-org patients   | ✅ Yes    |        |
| Shipments list shows only own-org shipments | ✅ Yes    |        |
| Cannot see other orgs' data via URL guessing| ✅ Yes    |        |

---

### Persona 2: EXTERNAL_USER_ADMIN — `test-customer-admin@lsmc.com`

**Cognito group**: `lsmc-customer-admins`
**Mapped roles**: `EXTERNAL_USER`, `EXTERNAL_USER_ADMIN`
**Scope**: Tenant-scoped (own organization only) + org management

#### Navigation Bar Visibility

Same as Persona 1 — no Intake, no Entities, no Admin.

#### All Persona 1 Actions

All "Allowed Actions" from Persona 1 should also work for this user.

#### Additional Org-Admin Capabilities

| Action                                          | Expected | Result |
|-------------------------------------------------|----------|--------|
| My Org → Users → "New User" button visible      | ✅ Visible |        |
| My Org → Users → Create new user                | ✅ Works   |        |
| My Org → Users → role dropdown shows org-admin assignable roles | ✅ Yes | |
| My Org → Users → Deactivate a user              | ✅ Works   |        |
| My Org → Users → Activate a user                | ✅ Works   |        |
| My Org → Users → Cannot deactivate self         | ✅ Blocked |        |
| My Org → Users → {user}/api-tokens              | ✅ Works   |        |
| My Org → Users → Create API token (ext_org scope only) | ✅ Works | |
| My Org → Users → Revoke API token               | ✅ Works   |        |
| My Org → Settings → Edit                        | ✅ Works   |        |
| My Org → Settings → Can edit display_name, contact_email, phone, note | ✅ Yes | |
| My Org → Settings → Cannot toggle is_active     | ✅ Blocked |        |

#### Still Denied

| Action / URL                    | Expected | Result |
|---------------------------------|----------|--------|
| Navigate to `/intake`           | ❌ 403    |        |
| Navigate to `/tubes`            | ❌ 403    |        |
| Navigate to `/admin`            | ❌ 403    |        |
| Navigate to `/admin/users`      | ❌ 403    |        |
| See data from other tenants     | ❌ No     |        |


---

### Persona 3: INTERNAL_USER — `test-staff@lsmc.com`

**Cognito group**: `lsmc-staff`
**Mapped roles**: `INTERNAL_USER`
**Scope**: Cross-tenant (can see all organizations' data)

#### Navigation Bar Visibility

| Element                    | Expected   | Result |
|----------------------------|------------|--------|
| Dashboard                  | ✅ Visible  |        |
| Orders                     | ✅ Visible  |        |
| Shipments                  | ✅ Visible  |        |
| Results                    | ✅ Visible  |        |
| Manage → Patients          | ✅ Visible  |        |
| Manage → Clinicians        | ✅ Visible  |        |
| Manage → My Organization   | ✅ Visible  |        |
| Support                    | ✅ Visible  |        |
| **Intake**                 | ✅ Visible  |        |
| **Entities → Tubes**       | ✅ Visible  |        |
| **Entities → TestKits**    | ✅ Visible  |        |
| **Entities → Documents**   | ✅ Visible  |        |
| **Entities → Manifests**   | ✅ Visible  |        |
| **Entities → Exceptions**  | ✅ Visible  |        |
| **Admin**                  | ❌ Hidden   |        |

#### Internal-Only Workflows

| Action                                          | Expected | Result |
|-------------------------------------------------|----------|--------|
| Dashboard → "Pending Exceptions" section visible| ✅ Yes    |        |
| Dashboard → "Scan & Match" quick action visible | ✅ Yes    |        |
| Intake → Scan & Match page loads                | ✅ Works  |        |
| Intake → Scan a barcode                         | ✅ Works  |        |
| Intake → Match material to test order            | ✅ Works  |        |
| Intake → Exceptions queue                       | ✅ Works  |        |
| Intake → Assign/resolve/escalate/close exception| ✅ Works  |        |
| Intake → Print Labels page                      | ✅ Works  |        |
| Tubes → list all                                | ✅ Works  |        |
| Tubes → create new                              | ✅ Works  |        |
| Tubes → edit existing                           | ✅ Works  |        |
| TestKits → list all                             | ✅ Works  |        |
| TestKits → create new                           | ✅ Works  |        |
| TestKits → view detail                          | ✅ Works  |        |
| TestKits → add/remove linked tubes              | ✅ Works  |        |
| Manifests → list all                            | ✅ Works  |        |
| Manifests → upload manifest                     | ✅ Works  |        |
| Manifests → view detail                         | ✅ Works  |        |
| Documents → list all                            | ✅ Works  |        |
| Documents → upload document                     | ✅ Works  |        |
| Documents → view detail                         | ✅ Works  |        |
| Results → Create Release Package                | ✅ Works  |        |
| Results Sets → Publish                          | ✅ Works  |        |
| Shipments → Receive shipment                    | ✅ Works  |        |
| Orders → Transition assay run states            | ✅ Works  |        |
| Support → Resolve tickets                       | ✅ Works  |        |

#### Cross-Tenant Access

| Check                                           | Expected | Result |
|-------------------------------------------------|----------|--------|
| Orders list shows orders from ALL tenants       | ✅ Yes    |        |
| Can view order detail for any tenant's order    | ✅ Yes    |        |
| Patients from all tenants visible               | ✅ Yes    |        |

#### Still Denied

| Action / URL                    | Expected | Result |
|---------------------------------|----------|--------|
| Navigate to `/admin`            | ❌ 403    |        |
| Navigate to `/admin/users`      | ❌ 403    |        |
| Navigate to `/admin/organizations` | ❌ 403 |        |
| Navigate to `/admin/test-definitions`     | ❌ 403    |        |

---

### Persona 4: ADMIN — `test-admin@lsmc.com`

**Cognito group**: `lsmc-admins`
**Mapped roles**: `ADMIN`
**Scope**: Full system access (all tenants, all features)

#### Navigation Bar Visibility

| Element                    | Expected   | Result |
|----------------------------|------------|--------|
| All items from Persona 3   | ✅ Visible  |        |
| **Admin**                  | ✅ Visible  |        |

#### All Persona 3 Actions

Everything from Persona 3 should work. Admin has every permission.

#### Admin-Only Capabilities

| Action                                          | Expected | Result |
|-------------------------------------------------|----------|--------|
| Admin Dashboard (`/admin`) loads                | ✅ Works  |        |
| Admin → Users → list all users (all tenants)    | ✅ Works  |        |
| Admin → Users → create new user                 | ✅ Works  |        |
| Admin → Users → edit user                       | ✅ Works  |        |
| Admin → Users → deactivate user                 | ✅ Works  |        |
| Admin → Users → activate user                   | ✅ Works  |        |
| Admin → Organizations → list all                | ✅ Works  |        |
| Admin → Organizations → create new              | ✅ Works  |        |
| Admin → Organizations → edit (incl. is_active)  | ✅ Works  |        |
| Admin → Organizations → add site                | ✅ Works  |        |
| Admin → Organizations → add user                | ✅ Works  |        |
| Admin → Sites → list all                        | ✅ Works  |        |
| Admin → Sites → create / edit                   | ✅ Works  |        |
| Admin → Assays → list all                       | ✅ Works  |        |
| Admin → Assays → create / edit / deactivate     | ✅ Works  |        |
| Admin → Assays → link/unlink documents          | ✅ Works  |        |
| Admin → Audit Log → view with filters           | ✅ Works  |        |
| Admin → API Tokens → view all tokens            | ✅ Works  |        |
| Admin → API Tokens → revoke any token           | ✅ Works  |        |

---

### Persona 5: READ_ONLY — `test-readonly@lsmc.com`

**Cognito group**: `lsmc-readonly`
**Mapped roles**: `READ_ONLY`
**Scope**: Tenant-scoped (own organization only), view-only

#### Navigation Bar Visibility

| Element                    | Expected   | Result |
|----------------------------|------------|--------|
| Dashboard                  | ✅ Visible  |        |
| Orders                     | ✅ Visible  |        |
| Shipments                  | ✅ Visible  |        |
| Results                    | ✅ Visible  |        |
| Manage → Patients          | ✅ Visible  |        |
| Manage → Clinicians        | ✅ Visible  |        |
| Manage → My Organization   | ✅ Visible  |        |
| Support                    | ✅ Visible  |        |
| **Intake**                 | ❌ Hidden   |        |
| **Entities dropdown**      | ❌ Hidden   |        |
| **Admin**                  | ❌ Hidden   |        |

#### Allowed Actions (read-only)

| Action                                      | Expected | Result |
|---------------------------------------------|----------|--------|
| Dashboard → view stats (read-only)          | ✅ Works  |        |
| Dashboard → no Quick Action creation links  | ✅ Hidden |        |
| Dashboard → no "Pending Exceptions"         | ✅ Hidden |        |
| Orders → view list                          | ✅ Works  |        |
| Orders → view order detail                  | ✅ Works  |        |
| Patients → view list                        | ✅ Works  |        |
| Patients → view patient detail              | ✅ Works  |        |
| Shipments → view list                       | ✅ Works  |        |
| Shipments → view shipment detail            | ✅ Works  |        |
| Results → view released results             | ✅ Works  |        |
| My Organization → view org info             | ✅ Works  |        |
| Profile → update own settings               | ✅ Works  |        |

#### Denied Actions (should return 403 or be hidden)

| Action / URL                                | Expected | Result |
|---------------------------------------------|----------|--------|
| Orders → + New Order (button/submission)    | ❌ 403    |        |
| Orders → edit any order                     | ❌ 403    |        |
| Orders → submit an order                    | ❌ 403    |        |
| Orders → cancel an order                    | ❌ 403    |        |
| Patients → create new patient               | ❌ 403    |        |
| Patients → edit patient                     | ❌ 403    |        |
| Shipments → + New Shipment                  | ❌ 403    |        |
| Shipments → edit shipment                   | ❌ 403    |        |
| My Org → Users → "New User" button          | ❌ Hidden |        |
| My Org → Users → Deactivate/Activate        | ❌ Hidden |        |
| My Org → Settings → Edit                    | ❌ 403    |        |
| Navigate to `/intake`                       | ❌ 403    |        |
| Navigate to `/tubes`                        | ❌ 403    |        |
| Navigate to `/testkits`                     | ❌ 403    |        |
| Navigate to `/manifests`                    | ❌ 403    |        |
| Navigate to `/documents`                    | ❌ 403    |        |
| Navigate to `/exceptions`                   | ❌ 403    |        |
| Navigate to `/admin`                        | ❌ 403    |        |
| Navigate to `/admin/users`                  | ❌ 403    |        |
| Navigate to `/admin/organizations`          | ❌ 403    |        |

#### Tenant Isolation

| Check                                       | Expected | Result |
|---------------------------------------------|----------|--------|
| Orders list shows only own-org orders       | ✅ Yes    |        |
| Patients list shows only own-org patients   | ✅ Yes    |        |
| Shipments list shows only own-org shipments | ✅ Yes    |        |
| Cannot see other orgs' data via URL guessing| ✅ Yes    |        |

---

## Part 8 — Cross-Cutting Verification Tests

These tests span multiple personas and validate system-wide RBAC behavior.

### 8.1 Tenant Isolation — Data Boundary Test

1. Log in as `test-staff@lsmc.bio` (INTERNAL_USER)
2. Create a TRF for a **different organization** than the one `test-customer@lsmc.bio` belongs to
3. Note the TRF EUID
4. Log out
5. Log in as `test-customer@lsmc.bio` (EXTERNAL_USER)
6. Navigate to the TRFs list
7. **Verify**: The staff-created TRF for a different org is **NOT visible**
8. Try navigating directly to `/trfs/<that-trf-euid>`
9. **Verify**: Returns **403** or redirects with an error, not the TRF detail

| Check                                               | Expected         | Result |
|-----------------------------------------------------|------------------|--------|
| External user cannot see other-org TRFs in list     | ✅ Not visible    |        |
| External user cannot access other-org TRF via URL   | ✅ 403 / redirect |        |

### 8.2 Role Indicator Badges

Log in as each user and verify the badge in the top-right header:

| User                            | Expected Badge | Actual Badge |
|---------------------------------|----------------|--------------|
| `test-admin@lsmc.bio`          | 🛡️ ADMIN       |              |
| `test-staff@lsmc.bio`          | 🔬 INTERNAL_USER |            |
| `test-customer@lsmc.bio`       | 👤 EXTERNAL_USER |            |
| `test-customer-admin@lsmc.bio` | 👤 EXTERNAL_USER |            |
| `test-readonly@lsmc.bio`       | 👁️ READ_ONLY    |            |

### 8.3 Direct URL Probing — External Users

For **each external persona** (`test-customer`, `test-customer-admin`,
`test-readonly`), manually type the following URLs into the browser and verify
the result:

| URL                            | EXTERNAL_USER | EXT_USER_ADMIN | READ_ONLY |
|--------------------------------|---------------|----------------|-----------|
| `/intake`                      | 403           | 403            | 403       |
| `/intake/scan`                 | 403           | 403            | 403       |
| `/tubes`                       | 403           | 403            | 403       |
| `/testkits`                    | 403           | 403            | 403       |
| `/manifests`                   | 403           | 403            | 403       |
| `/documents`                   | 403           | 403            | 403       |
| `/exceptions`                  | 403           | 403            | 403       |
| `/admin`                       | 403           | 403            | 403       |
| `/admin/users`                 | 403           | 403            | 403       |
| `/admin/organizations`         | 403           | 403            | 403       |
| `/admin/test-definitions`                | 403           | 403            | 403       |
| `/admin/audit`                 | 403           | 403            | 403       |

### 8.4 Direct URL Probing — Internal User

For `test-staff@lsmc.bio` (INTERNAL_USER), verify admin routes are blocked:

| URL                            | Expected | Result |
|--------------------------------|----------|--------|
| `/intake`                      | ✅ Works  |        |
| `/tubes`                       | ✅ Works  |        |
| `/admin`                       | ❌ 403    |        |
| `/admin/users`                 | ❌ 403    |        |
| `/admin/organizations`         | ❌ 403    |        |
| `/admin/test-definitions`                | ❌ 403    |        |

### 8.5 API Route Probing (Optional — via curl)

Extract the session cookie from your browser's DevTools (Application → Cookies
→ `lsmc_session`), then test API endpoints directly:

```bash
# As an external user — should get 403 on intake endpoints
COOKIE="lsmc_session=<paste-cookie-value>"

curl -b "$COOKIE" http://localhost:8915/api/intake/scan \
  -X POST -H "Content-Type: application/json" \
  -d '{"barcode":"TEST-001"}'
# Expected: 403 Forbidden

curl -b "$COOKIE" http://localhost:8915/api/admin/users \
  -X GET
# Expected: 403 Forbidden
```

### 8.6 Session Behavior

| Check                                               | Expected | Result |
|-----------------------------------------------------|----------|--------|
| Logging out clears the session cookie               | ✅ Yes    |        |
| Accessing protected pages after logout redirects to login | ✅ Yes |        |
| Session cookie has `HttpOnly` flag (check DevTools)  | ✅ Yes    |        |
| Session cookie has `SameSite=Lax` (or Strict)       | ✅ Yes    |        |

---

## Part 9 — Quick Reference: Groups → Roles → Permissions

### Cognito Group → Atlas Role Mapping

Source: `DEFAULT_COGNITO_GROUP_ROLE_MAP` in `app/settings.py`

| Cognito Group          | Mapped Atlas Roles                     | Access Scope   |
|------------------------|----------------------------------------|----------------|
| `lsmc-customers`       | `EXTERNAL_USER`                        | Tenant-scoped  |
| `lsmc-customer-admins` | `EXTERNAL_USER`, `EXTERNAL_USER_ADMIN` | Tenant-scoped  |
| `lsmc-readonly`        | `READ_ONLY`                            | Tenant-scoped  |
| `lsmc-staff`           | `INTERNAL_USER`                        | Cross-tenant   |
| `lsmc-admins`          | `ADMIN`                                | Full system    |

### Role → Permission Matrix

Source: `ROLE_PERMISSIONS` in `app/auth/rbac.py`

| Permission               | READ_ONLY | EXTERNAL_USER | EXT_USER_ADMIN | INTERNAL_USER | ADMIN |
|--------------------------|:---------:|:-------------:|:--------------:|:-------------:|:-----:|
| `profile:read`           | ✅        | ✅             | ✅              | ✅             | ✅    |
| `profile:update`         | ✅        | ✅             | ✅              | ✅             | ✅    |
| `order:create`           | ❌        | ✅             | ✅              | ✅             | ✅    |
| `order:read`             | ✅        | ✅             | ✅              | ✅             | ✅    |
| `order:update`           | ❌        | ✅             | ✅              | ✅             | ✅    |
| `order:submit`           | ❌        | ✅             | ✅              | ✅             | ✅    |
| `order:cancel`           | ❌        | ✅             | ✅              | ✅             | ✅    |
| `patient:create`         | ❌        | ✅             | ✅              | ✅             | ✅    |
| `patient:read`           | ✅        | ✅             | ✅              | ✅             | ✅    |
| `patient:update`         | ❌        | ✅             | ✅              | ✅             | ✅    |
| `shipment:create`        | ❌        | ✅             | ✅              | ✅             | ✅    |
| `shipment:read`          | ✅        | ✅             | ✅              | ✅             | ✅    |
| `shipment:update`        | ❌        | ✅             | ✅              | ✅             | ✅    |
| `release:read`           | ✅        | ✅             | ✅              | ✅             | ✅    |
| `release:create`         | ❌        | ❌             | ❌              | ✅             | ✅    |
| `audit:read`             | ✅        | ✅             | ✅              | ✅             | ✅    |
| `audit:export`           | ❌        | ✅             | ✅              | ✅             | ✅    |
| `theme:read`             | ✅        | ✅             | ✅              | ✅             | ✅    |
| `theme:update`           | ❌        | ✅             | ✅              | ✅             | ✅    |
| `theme:scrape`           | ❌        | ❌             | ❌              | ✅             | ✅    |
| `org:user_manage`        | ❌        | ❌             | ✅              | ❌             | ✅    |
| `org:api_token_manage`   | ❌        | ❌             | ✅              | ❌             | ✅    |
| `org:settings_update`    | ❌        | ❌             | ✅              | ❌             | ✅    |
| `org:audit_read`         | ❌        | ❌             | ✅              | ❌             | ✅    |
| `intake:scan`            | ❌        | ❌             | ❌              | ✅             | ✅    |
| `intake:match`           | ❌        | ❌             | ❌              | ✅             | ✅    |
| `intake:exception`       | ❌        | ❌             | ❌              | ✅             | ✅    |
| `cross_tenant:read`      | ❌        | ❌             | ❌              | ✅             | ✅    |
| All other permissions    | ❌        | ❌             | ❌              | ❌             | ✅    |

### Test User Quick Reference

| Email                           | Password    | Cognito Group          | Roles                              | Badge |
|---------------------------------|-------------|------------------------|------------------------------------|-------|
| `test-customer@lsmc.bio`       | `TestUser1!`| `lsmc-customers`       | `EXTERNAL_USER`                    | 👤    |
| `test-customer-admin@lsmc.bio` | `TestUser1!`| `lsmc-customer-admins` | `EXTERNAL_USER`, `EXT_USER_ADMIN`  | 👤    |
| `test-staff@lsmc.bio`          | `TestUser1!`| `lsmc-staff`           | `INTERNAL_USER`                    | 🔬    |
| `test-admin@lsmc.bio`          | `TestUser1!`| `lsmc-admins`          | `ADMIN`                            | 🛡️    |
| `test-readonly@lsmc.bio`       | `TestUser1!`| `lsmc-readonly`        | `READ_ONLY`                        | 👁️    |

---

*Generated for LSMC Atlas RBAC manual testing. Keep this file updated as new
roles, permissions, or routes are added to the application.*
