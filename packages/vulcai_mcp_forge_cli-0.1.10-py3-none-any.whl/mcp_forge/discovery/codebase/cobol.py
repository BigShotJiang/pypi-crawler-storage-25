"""
Parser COBOL pour la découverte codebase.
Supporte le format fixe (COBOL 74/85) et le format libre (COBOL 2002+).

Unités extraites :
  - Paragraphes dans la PROCEDURE DIVISION
  - Sections dans la PROCEDURE DIVISION
  - FUNCTION-ID (COBOL moderne, user-defined functions)
  - Programmes appelables (CALL 'NOM')

Détection automatique du format :
  - Fixed : colonne 7 contient *, D, -, / sur une fraction des lignes
  - Free  : pas de contrainte de colonnes
"""
from __future__ import annotations

import keyword as _kw
import re
from pathlib import Path

from mcp_forge.models import DiscoveredTool, ParameterType, ToolParameter

_SLUG_RE = re.compile(r"[^a-z0-9]+")

_RESERVED = set(_kw.kwlist + _kw.softkwlist) | {
    "constructor", "prototype", "__proto__",
}

# Seuil : si plus de 20% des lignes ont un caractère valide en col 7 >> fixed
_FIXED_THRESHOLD = 0.20


class CobolParser:
    """Extrait les paragraphes/sections/fonctions de fichiers COBOL."""

    def extract(self, path: Path, root: Path) -> list[DiscoveredTool]:
        try:
            source = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            return []

        relative_path = str(path.relative_to(root)).replace("\\", "/")
        program_name = _detect_program_name(source) or path.stem

        fmt = _detect_format(source)
        normalized = _normalize(source, fmt)

        # Extrait uniquement la PROCEDURE DIVISION
        proc_div = _extract_procedure_division(normalized)

        tools: list[DiscoveredTool] = []
        seen: set[str] = set()

        prefix = _SLUG_RE.sub("_", program_name.lower()).strip("_")

        # FUNCTION-ID (COBOL moderne)
        for m in re.finditer(r'^\s*FUNCTION-ID\.\s+([\w-]+)', normalized, re.IGNORECASE | re.MULTILINE):
            _add_paragraph(m.group(1), "user-defined function", prefix, relative_path, seen, tools)

        # Paragraphes et sections dans PROCEDURE DIVISION
        if proc_div:
            for m in re.finditer(
                r'^\s*([\w-]+)\s+SECTION\s*\.',
                proc_div, re.IGNORECASE | re.MULTILINE,
            ):
                _add_paragraph(m.group(1), "section", prefix, relative_path, seen, tools)

            for m in re.finditer(
                r'^\s*([\w-]+)\s*\.\s*$',
                proc_div, re.IGNORECASE | re.MULTILINE,
            ):
                name = m.group(1).strip()
                if _is_valid_paragraph(name):
                    _add_paragraph(name, "paragraph", prefix, relative_path, seen, tools)

        # CALL externes (programmes appelés)
        for m in re.finditer(
            r'\bCALL\s+[\'"]?([\w-]+)[\'"]?',
            normalized, re.IGNORECASE,
        ):
            called = m.group(1)
            if called.upper() not in {"SYSTEM", "CBL_COPY_FILE", "CBL_DELETE_FILE"}:
                slug = f"call_{_SLUG_RE.sub('_', called.lower()).strip('_')}"
                if slug not in seen:
                    seen.add(slug)
                    tools.append(DiscoveredTool(
                        name=slug,
                        description=f"CALL '{called}' — programme externe appelé",
                        parameters=_parse_using_clause(normalized, m.end()),
                        tags=["codebase", relative_path, "external-call"],
                        metadata={
                            "file": relative_path,
                            "function": called,
                            "type": "call",
                            "language": "cobol",
                        },
                    ))

        return tools


# ------------------------------------------------------------------
# Format detection & normalization
# ------------------------------------------------------------------

def _detect_format(source: str) -> str:
    """Retourne 'fixed' ou 'free' selon le contenu du fichier."""
    lines = source.splitlines()
    if not lines:
        return "free"
    fixed_indicators = sum(
        1 for line in lines
        if len(line) >= 7 and line[6] in ("*", "D", "d", "-", "/", " ")
        and len(line) > 10
    )
    ratio = fixed_indicators / max(len(lines), 1)
    return "fixed" if ratio >= _FIXED_THRESHOLD else "free"


def _normalize(source: str, fmt: str) -> str:
    """Normalise le source en retirant les artefacts du format fixe."""
    if fmt == "free":
        # Retire les commentaires *> style libre
        source = re.sub(r'\*>.*', '', source)
        return source

    # Format fixe : traite ligne par ligne
    result = []
    for line in source.splitlines():
        # Ligne trop courte >> gardée telle quelle
        if len(line) < 7:
            result.append(line)
            continue
        indicator = line[6]
        # Commentaire (* ou /) >> ligne vide
        if indicator in ("*", "/"):
            result.append("")
            continue
        # Continuation (-) >> colle à la ligne précédente
        if indicator == "-":
            code = line[11:72].rstrip() if len(line) > 11 else ""
            if result:
                result[-1] = result[-1].rstrip() + " " + code.lstrip("\"'")
            continue
        # Code normal : colonnes 7-72 (Area A+B)
        code = line[6:72].rstrip() if len(line) > 6 else ""
        result.append(code)

    return "\n".join(result)


# ------------------------------------------------------------------
# Extraction helpers
# ------------------------------------------------------------------

def _extract_procedure_division(source: str) -> str:
    """Extrait le texte de la PROCEDURE DIVISION jusqu'à la fin ou END PROGRAM."""
    m = re.search(r'\bPROCEDURE\s+DIVISION\b', source, re.IGNORECASE)
    if not m:
        return ""
    end = re.search(r'\bEND\s+PROGRAM\b|\bEND\s+FUNCTION\b', source[m.end():], re.IGNORECASE)
    if end:
        return source[m.end(): m.end() + end.start()]
    return source[m.end():]


def _detect_program_name(source: str) -> str:
    """Extrait le PROGRAM-ID ou FUNCTION-ID."""
    m = re.search(r'\b(?:PROGRAM-ID|FUNCTION-ID)\.\s+([\w-]+)', source, re.IGNORECASE)
    return m.group(1) if m else ""


_RESERVED_COBOL_WORDS = {
    "END", "STOP", "EXIT", "GOBACK", "CONTINUE", "NEXT",
    "SENTENCE", "IF", "ELSE", "WHEN", "PERFORM", "MOVE",
    "COMPUTE", "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE",
    "EVALUATE", "SEARCH", "READ", "WRITE", "REWRITE",
    "DELETE", "START", "OPEN", "CLOSE", "DISPLAY", "ACCEPT",
    "CALL", "SET", "INITIALIZE", "INSPECT", "STRING",
    "UNSTRING", "SORT", "MERGE", "RELEASE", "RETURN",
    "DECLARATIVES", "DIVISION", "SECTION",
}


def _is_valid_paragraph(name: str) -> bool:
    """Vérifie qu'un nom est un paragraphe valide (pas un mot réservé COBOL)."""
    upper = name.upper()
    if upper in _RESERVED_COBOL_WORDS:
        return False
    if re.match(r'^\d', name):
        return False
    if len(name) < 2:
        return False
    return bool(re.match(r'^[\w-]+$', name))


def _add_paragraph(
    name: str,
    kind: str,
    prefix: str,
    relative_path: str,
    seen: set[str],
    tools: list[DiscoveredTool],
) -> None:
    func_slug = _SLUG_RE.sub("_", name.lower()).strip("_") or "para"
    slug = f"{prefix}_{func_slug}" if prefix else func_slug
    if slug in seen:
        return
    seen.add(slug)
    tools.append(DiscoveredTool(
        name=slug,
        description=f"COBOL {kind} : {name.upper()}",
        parameters=[],
        tags=["codebase", relative_path, kind],
        metadata={
            "file": relative_path,
            "function": name.upper(),
            "type": kind,
            "language": "cobol",
        },
    ))


def _parse_using_clause(source: str, pos: int) -> list[ToolParameter]:
    """Extrait les paramètres d'un CALL ... USING ..."""
    window = source[pos:pos + 200]
    m = re.search(r'\bUSING\b(.*?)(?:\.|BY\s+(?:REFERENCE|VALUE|CONTENT)|\n\n)', window, re.IGNORECASE | re.DOTALL)
    if not m:
        return []
    params = []
    for var in re.findall(r'[\w-]+', m.group(1)):
        if var.upper() in _RESERVED_COBOL_WORDS or len(var) < 2:
            continue
        slug = _SLUG_RE.sub("_", var.lower()).strip("_") or "param"
        if slug in _RESERVED:
            slug = slug + "_"
        params.append(ToolParameter(
            name=slug,
            type=ParameterType.STRING,
            description=var.upper(),
            required=True,
        ))
    return params[:8]  # limite raisonnable
