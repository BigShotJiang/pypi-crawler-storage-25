"""
Discovery à partir d'une application CLI locale.

Stratégie :
  1. Lancer <commande> --help pour obtenir la description globale
  2. Détecter les sous-commandes dans la sortie
  3. Pour chaque sous-commande, lancer <commande> <sous-cmd> --help
  4. Parser options/flags -> ToolParameter
  5. Chaque sous-commande -> un DiscoveredTool
"""
from __future__ import annotations

import keyword
import re
import shlex
import subprocess
from dataclasses import dataclass, field

from rich.console import Console

from mcp_forge.models import (
    DiscoveredTool,
    DiscoveryResult,
    ForgeConfig,
    ParameterType,
    SourceType,
    ToolParameter,
)

console = Console()

_MAX_DEPTH = 2
_TIMEOUT = 10

_SUBCOMMAND_PATTERNS = [
    re.compile(r"^\s{2,4}([a-z][a-z0-9_-]+)\s{2,}(.+)$", re.MULTILINE),
    re.compile(r"^\s{2,4}([a-z][a-z0-9_-]+)\s*$", re.MULTILINE),
]

_OPTION_PATTERN = re.compile(
    r"(?:^|\s)"
    r"(-[a-zA-Z](?:,\s*--[a-z][a-z0-9_-]*)?"
    r"|--[a-z][a-z0-9_-]*)"
    r"(?:\s+([A-Z_]+|\[.*?\]))?"
    r"\s{2,}(.+?)(?=\s{2,}-|\n|$)",
    re.MULTILINE,
)

_SUBCOMMAND_SECTION_HEADERS = re.compile(
    r"^(?:available\s+)?(?:commands?|subcommands?|actions?)\s*:?\s*$",
    re.IGNORECASE | re.MULTILINE,
)

_VALUE_TYPE_MAP: dict[str, ParameterType] = {
    "FILE": ParameterType.STRING,
    "PATH": ParameterType.STRING,
    "DIR": ParameterType.STRING,
    "URL": ParameterType.STRING,
    "TEXT": ParameterType.STRING,
    "STRING": ParameterType.STRING,
    "STR": ParameterType.STRING,
    "NAME": ParameterType.STRING,
    "INT": ParameterType.INTEGER,
    "INTEGER": ParameterType.INTEGER,
    "N": ParameterType.INTEGER,
    "NUM": ParameterType.INTEGER,
    "NUMBER": ParameterType.INTEGER,
    "FLOAT": ParameterType.NUMBER,
}

_RESERVED_WORDS = {
    "help", "version", "options", "flags", "arguments", "usage",
    "global", "commands", "subcommands", "available",
}


@dataclass
class _CLICommand:
    name: str
    args: list[str]
    description: str = ""
    options: list[ToolParameter] = field(default_factory=list)


class CLIAppDiscovery:
    def __init__(self, config: ForgeConfig):
        self.config = config
        self.cmd_parts = shlex.split(config.source)

    def discover(self) -> DiscoveryResult:
        console.print("[bold]>> Analyse de l'application CLI...[/bold]")

        root_help = self._run_help(self.cmd_parts)
        if root_help is None:
            raise ValueError(f"Impossible de lancer '{' '.join(self.cmd_parts)} --help'")

        title, root_description = self._parse_header(root_help)
        title = title or self.cmd_parts[-1]

        subcommands = self._detect_subcommands(root_help)
        console.print(f"[dim]  {len(subcommands)} sous-commande(s) détectée(s)[/dim]")

        tools: list[DiscoveredTool] = []

        if subcommands:
            for sub_name, sub_desc in subcommands:
                cmd_args = self.cmd_parts + [sub_name]
                sub_help = self._run_help(cmd_args)
                _, detailed_desc = self._parse_header(sub_help or "")
                options, flags = self._parse_options(sub_help or "")

                # Niveau 2 : sous-sous-commandes (ex: git remote add)
                if sub_help and _MAX_DEPTH >= 2:
                    nested = self._detect_subcommands(sub_help)
                    for nested_name, nested_desc in nested:
                        nested_args = cmd_args + [nested_name]
                        nested_help = self._run_help(nested_args)
                        _, nested_detailed = self._parse_header(nested_help or "")
                        nested_opts, nested_flags = self._parse_options(nested_help or "")
                        tools.append(self._build_tool(
                            name=f"{sub_name}_{nested_name}",
                            cmd_args=nested_args,
                            description=nested_detailed or nested_desc or f"{sub_name} {nested_name}",
                            options=nested_opts,
                            param_flags=nested_flags,
                        ))

                tools.append(self._build_tool(
                    name=sub_name,
                    cmd_args=cmd_args,
                    description=detailed_desc or sub_desc or sub_name,
                    options=options,
                    param_flags=flags,
                ))
        else:
            # Pas de sous-commandes : la commande entière est un tool
            options, flags = self._parse_options(root_help)
            tools.append(self._build_tool(
                name=self._normalize_name(title),
                cmd_args=self.cmd_parts,
                description=root_description or title,
                options=options,
                param_flags=flags,
            ))

        console.print(f"[green][OK] {len(tools)} outil(s) MCP extrait(s)[/green]")

        return DiscoveryResult(
            source_type=SourceType.CLI_APP,
            source_path=self.config.source,
            title=title,
            description=root_description,
            tools=tools,
        )

    # ------------------------------------------------------------------
    # Exécution subprocess
    # ------------------------------------------------------------------

    def _run_help(self, cmd_args: list[str]) -> str | None:
        for help_flag in ["--help", "-h"]:
            try:
                result = subprocess.run(
                    cmd_args + [help_flag],
                    capture_output=True,
                    text=True,
                    timeout=_TIMEOUT,
                )
                output = result.stdout or result.stderr
                if output.strip():
                    return output
            except (subprocess.TimeoutExpired, FileNotFoundError):
                continue
            except Exception:
                continue
        # Essai avec "help" comme sous-commande (ex: git help commit)
        try:
            result = subprocess.run(
                [cmd_args[0], "help"] + cmd_args[1:],
                capture_output=True,
                text=True,
                timeout=_TIMEOUT,
            )
            output = result.stdout or result.stderr
            if output.strip():
                return output
        except Exception:
            pass
        return None

    # ------------------------------------------------------------------
    # Parsing
    # ------------------------------------------------------------------

    def _parse_header(self, help_text: str) -> tuple[str, str]:
        lines = [ln.rstrip() for ln in help_text.splitlines() if ln.strip()]
        title = lines[0].strip() if lines else ""
        title = re.sub(r"^(?:usage|name)\s*:?\s*", "", title, flags=re.IGNORECASE).strip()
        desc_lines = []
        for line in lines[1:]:
            if re.match(r"^[A-Z][A-Z\s]+:$", line.strip()):
                break
            if line.strip().startswith("-"):
                break
            desc_lines.append(line.strip())
        return title, " ".join(ln for ln in desc_lines if ln)

    def _detect_subcommands(self, help_text: str) -> list[tuple[str, str]]:
        section_match = _SUBCOMMAND_SECTION_HEADERS.search(help_text)
        search_text = help_text[section_match.end():] if section_match else help_text

        found: dict[str, str] = {}
        for pattern in _SUBCOMMAND_PATTERNS:
            for m in pattern.finditer(search_text):
                name = m.group(1)
                desc = m.group(2).strip() if len(m.groups()) > 1 else ""
                if name not in _RESERVED_WORDS and name not in found:
                    found[name] = desc
        return list(found.items())

    def _parse_options(self, help_text: str) -> tuple[list[ToolParameter], dict[str, str]]:
        """Retourne (params, param_flags) où param_flags mappe nom_python >> flag_cli."""
        params: list[ToolParameter] = []
        param_flags: dict[str, str] = {}
        seen: set[str] = set()

        for m in _OPTION_PATTERN.finditer(help_text):
            flag = m.group(1).strip()
            value_hint = (m.group(2) or "").strip()
            description = (m.group(3) or "").strip()

            if flag.startswith("--"):
                raw_name = flag[2:].replace("-", "_")
            elif flag.startswith("-") and len(flag) == 2:
                raw_name = flag[1:]
            else:
                continue

            if raw_name in seen or len(raw_name) < 2:
                continue

            # Sanitise les mots-clés Python (and, or, continue, etc.)
            name = f"{raw_name}_" if keyword.iskeyword(raw_name) else raw_name
            original_flag = f"--{raw_name.replace('_', '-')}"
            if name != raw_name:
                param_flags[name] = original_flag

            seen.add(raw_name)

            if value_hint:
                ptype = _VALUE_TYPE_MAP.get(value_hint.upper(), ParameterType.STRING)
                required = not value_hint.startswith("[")
            else:
                ptype = ParameterType.BOOLEAN
                required = False

            default = None
            dm = re.search(r"\(default[=:\s]+([^)]+)\)", description, re.IGNORECASE)
            if dm:
                default = dm.group(1).strip()

            params.append(ToolParameter(
                name=name,
                type=ptype,
                description=description,
                required=required,
                default=default,
            ))

        return params, param_flags

    # ------------------------------------------------------------------
    # Construction du tool
    # ------------------------------------------------------------------

    def _build_tool(
        self,
        name: str,
        cmd_args: list[str],
        description: str,
        options: list[ToolParameter],
        param_flags: dict[str, str] | None = None,
    ) -> DiscoveredTool:
        return DiscoveredTool(
            name=self._normalize_name(name),
            description=description,
            parameters=options,
            tags=["cli"],
            metadata={"cmd": cmd_args, "param_flags": param_flags or {}},
        )

    @staticmethod
    def _normalize_name(name: str) -> str:
        return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")
