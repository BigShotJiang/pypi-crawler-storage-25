"""
Pipeline distant : envoie le DiscoveryPayload à l'API Azure et récupère
les fichiers générés (server.py, requirements.txt, README.md).

Variables d'environnement :
  FORGE_API_URL       URL de l'API (défaut : https://api.mcp-forge.io)
  FORGE_LICENSE_KEY   Clé de licence (format : mfg_live_<uuid>)
"""
from __future__ import annotations

import os
from pathlib import Path

import httpx

from mcp_forge.models import DiscoveryResult, ForgeConfig, GeneratedServer
from mcp_forge.schemas.payload import DiscoveryPayload

_DEFAULT_API_URL = "https://api.mcp-forge.io"
_TIMEOUT = 60.0


class RemoteError(Exception):
    """Erreur levée par le pipeline distant (affichée après la fin du spinner)."""


def run_remote(result: DiscoveryResult, config: ForgeConfig) -> GeneratedServer:
    """Envoie le payload à l'API Azure et écrit les fichiers générés localement."""
    api_url = os.environ.get("FORGE_API_URL", _DEFAULT_API_URL).rstrip("/")
    license_key = os.environ.get("FORGE_LICENSE_KEY", "")

    if not license_key:
        raise RemoteError(
            "FORGE_LICENSE_KEY manquante.\n"
            "  Obtenez votre clé sur https://app.mcp-forge.io puis :\n"
            "  Windows : set FORGE_LICENSE_KEY=mfg_live_...\n"
            "  Mac/Linux : export FORGE_LICENSE_KEY=mfg_live_..."
        )

    payload = DiscoveryPayload.from_discovery_result(result)

    try:
        response = httpx.post(
            f"{api_url}/v1/generate",
            json=payload.model_dump(mode="json"),
            headers={
                "Authorization": f"Bearer {license_key}",
                "Content-Type": "application/json",
            },
            timeout=_TIMEOUT,
            verify=True,
        )
    except httpx.ConnectError:
        raise RemoteError(f"Impossible de joindre l'API ({api_url}). Vérifiez votre connexion.")
    except httpx.TimeoutException:
        raise RemoteError("L'API n'a pas répondu dans les délais. Réessayez plus tard.")

    if response.status_code == 401:
        raise RemoteError("Clé de licence invalide ou expirée.")
    if response.status_code == 429:
        raise RemoteError("Quota atteint pour votre plan. Contactez support@mcp-forge.io.")
    if response.status_code != 200:
        raise RemoteError(f"Erreur API ({response.status_code}) : {response.text[:200]}")

    data = response.json()
    return _write_generated_files(data, config)


def _write_generated_files(data: dict, config: ForgeConfig) -> GeneratedServer:
    """Écrit les fichiers retournés par l'API dans le dossier de sortie.

    Format attendu de l'API :
      { "success": bool, "server_name": str, "tools_count": int,
        "files": { "server.py": "...", "requirements.txt": "...", ... } }
    """
    server_name = data.get("server_name", "mcp_server")
    output_dir = Path(config.output_dir) / server_name
    output_dir.mkdir(parents=True, exist_ok=True)

    files: dict[str, str] = data.get("files", {})

    for filename, content in files.items():
        if content:
            (output_dir / filename).write_text(content, encoding="utf-8")

    tools_count = data.get("tools_count", 0)
    console.print(f"[green][OK] Serveur généré dans : {output_dir}[/green]")

    return GeneratedServer(
        server_name=server_name,
        output_dir=str(output_dir),
        files=files,
        tools_count=tools_count,
        success=True,
    )
