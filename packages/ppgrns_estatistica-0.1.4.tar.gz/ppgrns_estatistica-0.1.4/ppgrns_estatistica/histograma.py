import matplotlib.pyplot as plt
import numpy as np
from .posicao import _garantir_numerico, _selecionar_colunas

def histograma(dados, *colunas, numerocolunas=None, cor='lightblue', titulo="",
               vertical="Frequência", qualidade=100,
               tamanhohorizontal=1, tamanhovertical=1, salvar=''):
    """
    Gera um histograma de uma única variável.
    Se múltiplas colunas forem passadas, o gráfico será gerado para a primeira delas.
    """
    # 1. Padronização da seleção (aceita lista, args soltos ou nada)
    cols = _selecionar_colunas(dados, colunas)

    if not cols:
        print("❌ Erro: Nenhuma coluna selecionada.")
        return

    # O histograma foca em uma distribuição por vez
    coluna = cols[0]

    # 2. Preparação e Limpeza automática
    dados_num = _garantir_numerico(dados[[coluna]], [coluna])
    serie = dados_num[coluna].dropna()

    if serie.empty:
        print(f"❌ Erro: A coluna '{coluna}' não possui dados numéricos válidos.")
        return

    # 3. Cálculo dos Bins (Intervalos)
    # Usa 'auto' (regra de Sturges/Freedman-Diaconis) se o usuário não definir
    counts, bin_edges = np.histogram(serie, bins=numerocolunas if numerocolunas else 'auto')
    n_bins = len(counts)

    # 4. Criar os rótulos dos intervalos para o eixo X
    labels = []
    for i in range(len(bin_edges) - 1):
        labels.append(f"{bin_edges[i]:.2f} - {bin_edges[i + 1]:.2f}")

    # 5. Configuração da Figura
    plt.figure(figsize=(10 * tamanhohorizontal, 6 * tamanhovertical), dpi=qualidade)

    # Usamos barras manuais para fixar os rótulos centralizados
    x_pos = np.arange(len(labels))
    plt.bar(x_pos, counts, width=0.95, color=cor, edgecolor='black', alpha=0.8)

    # 6. Lógica de Rotação Dinâmica do Eixo X
    # Evita sobreposição de texto conforme a quantidade de classes
    rotacao = 0
    if 6 <= n_bins <= 12:
        rotacao = 45
    elif n_bins > 12:
        rotacao = 90

    plt.xticks(x_pos, labels, rotation=rotacao, ha='right' if rotacao > 0 else 'center')

    # 7. Estética e Títulos
    if titulo:
        plt.title(titulo, fontsize=14, pad=15)
    else:
        plt.title(f"Distribuição de Frequência: {coluna.capitalize()}", fontsize=12)

    plt.ylabel(vertical, fontsize=11)
    plt.xlabel("Intervalos de Classe", fontsize=11)
    plt.grid(axis='y', linestyle='--', alpha=0.6)

    plt.tight_layout()

    # 8. Opção de Salvamento
    if salvar:
        nome_arquivo = f"{salvar}.png"
        plt.savefig(nome_arquivo, bbox_inches='tight')
        print(f"💾 Gráfico salvo com sucesso: {nome_arquivo}")

    plt.show()