import pandas as pd
import numpy as np


def _garantir_numerico(dados, colunas):
    """
    Força a conversão das colunas para números, removendo lixo invisível.
    Utiliza o DataFrame original para filtrar e limpar as colunas selecionadas.
    """
    df_limpo = dados[list(colunas)].copy()
    for col in df_limpo.columns:
        if not pd.api.types.is_numeric_dtype(df_limpo[col]):
            # Limpeza de caracteres invisíveis e ajuste de vírgula para ponto
            df_limpo[col] = (df_limpo[col].astype(str)
                             .str.replace('\u200b', '', regex=False)
                             .str.replace(',', '.', regex=False)
                             .str.strip())
            df_limpo[col] = pd.to_numeric(df_limpo[col], errors='coerce')
    return df_limpo


def _selecionar_colunas(dados, colunas):
    """
    Padroniza a seleção de colunas para suportar:
    1. Lista: ef.media(df, ['col1', 'col2'])
    2. Argumentos soltos: ef.media(df, 'col1', 'col2')
    3. Nada (todas): ef.media(df)
    """
    if not colunas:
        return dados.columns.tolist()

    # Se o primeiro argumento for uma lista ou tupla, desempacota
    if len(colunas) == 1 and isinstance(colunas[0], (list, tuple)):
        return list(colunas[0])

    # Caso contrário, retorna a tupla de argumentos como uma lista
    return list(colunas)


def media(dados, *colunas, mostrar=True):
    """Calcula a média aritmética das colunas selecionadas."""
    cols = _selecionar_colunas(dados, colunas)
    try:
        dados_num = _garantir_numerico(dados, cols)
        res = dados_num.mean(numeric_only=True)
    except KeyError as e:
        print(f"❌ Erro: Uma ou mais colunas não foram encontradas: {e}")
        return None

    if mostrar:
        print("\n--- Média ---")
        print(res.to_string() if not res.empty else "⚠️ Nenhuma coluna numérica.")
    return res


def mediana(dados, *colunas, mostrar=True):
    """Calcula a mediana das colunas selecionadas."""
    cols = _selecionar_colunas(dados, colunas)
    try:
        dados_num = _garantir_numerico(dados, cols)
        res = dados_num.median(numeric_only=True)
    except KeyError as e:
        print(f"❌ Erro: Uma ou mais colunas não foram encontradas: {e}")
        return None

    if mostrar:
        print("\n--- Mediana ---")
        print(res.to_string() if not res.empty else "⚠️ Nenhuma coluna numérica.")
    return res


def quartil(dados, *colunas, quartil=1, metodo='exc', mostrar=True):
    """Calcula o 1º, 2º ou 3º quartil usando o método EXC (Weibull) ou INC."""
    cols = _selecionar_colunas(dados, colunas)
    try:
        dados_num = _garantir_numerico(dados, cols)
    except KeyError as e:
        print(f"❌ Erro: Uma ou mais colunas não foram encontradas: {e}")
        return None

    q_map = {1: 25, 2: 50, 3: 75}
    p = q_map.get(quartil, 25)
    metodo_np = 'weibull' if metodo.lower() == 'exc' else 'linear'

    res_dict = {}
    for col in cols:
        serie = dados_num[col].dropna()
        if not serie.empty:
            try:
                # Tenta usar o parâmetro 'method' (NumPy 1.22+)
                res_dict[col] = np.percentile(serie, p, method=metodo_np)
            except TypeError:
                # Fallback para versões anteriores do NumPy usando 'interpolation'
                interp = 'linear' if metodo_np == 'linear' else 'higher'
                res_dict[col] = np.percentile(serie, p, interpolation=interp)

    res = pd.Series(res_dict)
    if mostrar:
        print(f"\n--- {quartil}º Quartil ({metodo.upper()}) ---")
        print(res.to_string() if not res.empty else "⚠️ Sem dados numéricos.")
    return res


def percentil(dados, *colunas, percentil=50, metodo='exc', mostrar=True):
    """Calcula um percentil específico (0-100) para as colunas selecionadas."""
    cols = _selecionar_colunas(dados, colunas)
    try:
        dados_num = _garantir_numerico(dados, cols)
    except KeyError as e:
        print(f"❌ Erro: Uma ou mais colunas não foram encontradas: {e}")
        return None

    metodo_np = 'weibull' if metodo.lower() == 'exc' else 'linear'
    res_dict = {}
    for col in cols:
        serie = dados_num[col].dropna()
        if not serie.empty:
            try:
                res_dict[col] = np.percentile(serie, percentil, method=metodo_np)
            except TypeError:
                interp = 'linear' if metodo_np == 'linear' else 'higher'
                res_dict[col] = np.percentile(serie, percentil, interpolation=interp)

    res = pd.Series(res_dict)
    if mostrar:
        print(f"\n--- Percentil {percentil} ({metodo.upper()}) ---")
        print(res.to_string() if not res.empty else "⚠️ Sem dados numéricos.")
    return res


def limiteinferior(dados, *colunas, metodo='exc', mostrar=True):
    """Calcula o limite inferior para detecção de outliers (Q1 - 1.5*IQR)."""
    cols = _selecionar_colunas(dados, colunas)
    # Passamos mostrar=False para as chamadas internas de quartil
    q1 = quartil(dados, *cols, quartil=1, metodo=metodo, mostrar=False)
    q3 = quartil(dados, *cols, quartil=3, metodo=metodo, mostrar=False)
    res = q1 - (1.5 * (q3 - q1))

    if mostrar:
        print(f"\n--- Limite Inferior ({metodo.upper()}) ---")
        print(res.to_string() if not res.empty else "⚠️ Sem dados numéricos.")
    return res


def limitesuperior(dados, *colunas, metodo='exc', mostrar=True):
    """Calcula o limite superior para detecção de outliers (Q3 + 1.5*IQR)."""
    cols = _selecionar_colunas(dados, colunas)
    q1 = quartil(dados, *cols, quartil=1, metodo=metodo, mostrar=False)
    q3 = quartil(dados, *cols, quartil=3, metodo=metodo, mostrar=False)
    res = q3 + (1.5 * (q3 - q1))

    if mostrar:
        print(f"\n--- Limite Superior ({metodo.upper()}) ---")
        print(res.to_string() if not res.empty else "⚠️ Sem dados numéricos.")
    return res