import matplotlib.pyplot as plt
from .posicao import mediana, quartil, limiteinferior, limitesuperior, _garantir_numerico, _selecionar_colunas

def boxplot(dados, *colunas, larguras=None, cores=None, metodos=None,
            titulo="", horizontal=None, vertical="", qualidade=100,
            tamanhohorizontal=1, tamanhovertical=1, salvar=''):
    """
    Cria boxplots altamente personalizáveis para relatórios estatísticos.
    Aceita nomes de colunas avulsos, listas de colunas ou seleciona todas automaticamente.
    """
    # 1. Padronização da seleção de colunas (resolve o erro de KeyError com listas)
    cols = _selecionar_colunas(dados, colunas)
    n = len(cols)

    # 2. Tratamento de listas (Larguras, Cores, Métodos e Nomes Horizontais)
    def ajustar_lista(lista, padrao, nome_param):
        lista = list(lista) if lista else []
        if len(lista) > n:
            print(f"⚠️ Aviso: Excesso de {nome_param}. Ignorando os itens extras.")
            return lista[:n]
        elif len(lista) < n:
            if len(lista) > 0:
                print(f"⚠️ Aviso: Faltam {nome_param}. Usando padrão para o restante.")
            # Preenche o restante com o valor padrão ou o último valor da lista
            complemento = padrao if not lista else lista[-1]
            lista.extend([complemento] * (n - len(lista)))
        return lista

    lista_larguras = ajustar_lista(larguras, 1, "larguras")
    lista_cores = ajustar_lista(cores, 'lightblue', "cores")
    lista_metodos = ajustar_lista(metodos, 'exc', "métodos")

    # Se 'horizontal' não for fornecido, usamos os nomes das colunas
    lista_nomes = ajustar_lista(horizontal, None, "nomes horizontais")
    for i in range(n):
        if lista_nomes[i] is None:
            lista_nomes[i] = cols[i]

    # 3. Configuração da Figura
    largura_final = 10 * tamanhohorizontal
    altura_final = 6 * tamanhovertical
    plt.figure(figsize=(largura_final, altura_final), dpi=qualidade)

    # 4. Cálculo das Estatísticas
    # Limpeza automática de caracteres invisíveis e conversão numérica
    dados_num = _garantir_numerico(dados[cols], cols)
    stats_list = []

    for i, col in enumerate(cols):
        d = dados_num[col].dropna()
        if d.empty: continue

        # Chamadas internas com mostrar=False para não poluir o terminal durante o plot
        q1 = quartil(dados, col, quartil=1, metodo=lista_metodos[i], mostrar=False).iloc[0]
        q2 = mediana(dados, col, mostrar=False).iloc[0]
        q3 = quartil(dados, col, quartil=3, metodo=lista_metodos[i], mostrar=False).iloc[0]
        inf = limiteinferior(dados, col, metodo=lista_metodos[i], mostrar=False).iloc[0]
        sup = limitesuperior(dados, col, metodo=lista_metodos[i], mostrar=False).iloc[0]

        outliers = d[(d < inf) | (d > sup)].tolist()

        stats = {
            'label': lista_nomes[i],
            'whislo': inf,
            'q1': q1,
            'med': q2,
            'q3': q3,
            'whishi': sup,
            'fliers': outliers
        }
        stats_list.append(stats)

    # 5. Plotagem Customizada
    if stats_list:
        ax = plt.subplot(111)
        for i, s in enumerate(stats_list):
            # Renderiza cada box individualmente para permitir cores e larguras distintas
            bp = ax.bxp([s], positions=[i], widths=lista_larguras[i], patch_artist=True)
            for patch in bp['boxes']:
                patch.set_facecolor(lista_cores[i])

        # Aplica Títulos e Rótulos
        if titulo:
            plt.title(titulo, fontsize=14, pad=15)

        if vertical:
            plt.ylabel(vertical, fontsize=12)

        ax.set_xticklabels(lista_nomes)
        plt.grid(axis='y', linestyle='--', alpha=0.6)
        plt.tight_layout()

        # 6. Opção de Salvamento
        if salvar:
            nome_arquivo = f"{salvar}.png"
            plt.savefig(nome_arquivo, bbox_inches='tight')
            print(f"💾 Gráfico salvo com sucesso: {nome_arquivo}")

        plt.show()
    else:
        print("❌ Erro: Não foi possível gerar o boxplot com os dados fornecidos.")