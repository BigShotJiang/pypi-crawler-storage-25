from __future__ import annotations

import hashlib
import json
import os
import shutil
from contextlib import ExitStack
from pathlib import Path
from tempfile import NamedTemporaryFile
from time import time
from typing import Any
from urllib.parse import quote
from uuid import uuid4

import httpx
from fastmcp import FastMCP


DEFAULT_BASE_URL = "http://42.51.34.112:8191"
BASE_URL = os.environ.get("MINERU_BASE_URL", DEFAULT_BASE_URL).strip().rstrip("/")
API_TOKEN = os.environ.get("MINERU_API_TOKEN", "").strip()
TIMEOUT = float(os.environ.get("MINERU_TIMEOUT", "1800"))
TRUST_ENV = os.environ.get("MINERU_TRUST_ENV", "").strip().lower() in {"1", "true", "yes"}
LOG_DIR = Path(os.environ.get("MINERU_LOG_DIR", "~/.mineru-selfhosted-mcp/logs")).expanduser()
OUTPUT_ROOT = Path(os.environ.get("MINERU_OUTPUT_ROOT", "/data/mineru_output")).expanduser()
DOWNLOAD_PUBLISH_DIR = Path(
    os.environ.get("MINERU_DOWNLOAD_PUBLISH_DIR", "/data/mineru_output/_published")
).expanduser()
DOWNLOAD_BASE_URL = os.environ.get("MINERU_DOWNLOAD_BASE_URL", f"{BASE_URL}/downloads").strip().rstrip("/")

OCR_LANGUAGES = [
    "ch",
    "en",
    "japan",
    "korean",
    "chinese_cht",
    "latin",
    "arabic",
    "east_slavic",
    "cyrillic",
    "devanagari",
    "ta",
    "te",
    "ka",
    "th",
    "el",
]

mcp = FastMCP("mineru-selfhosted")


def _headers() -> dict[str, str]:
    headers: dict[str, str] = {}
    if API_TOKEN:
        headers["Authorization"] = f"Bearer {API_TOKEN}"
    return headers


def _extract_primary_result(result: dict[str, Any]) -> dict[str, Any]:
    parsed = result.get("results", {})
    first_key = next(iter(parsed), None)
    return parsed[first_key] if first_key else {}


def _ensure_log_dir() -> Path:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    return LOG_DIR


def _ensure_output_root() -> Path:
    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    return OUTPUT_ROOT


def _ensure_download_publish_dir() -> Path:
    DOWNLOAD_PUBLISH_DIR.mkdir(parents=True, exist_ok=True)
    return DOWNLOAD_PUBLISH_DIR


def _coerce_paths(file_paths: str | list[str]) -> list[Path]:
    raw_paths = [file_paths] if isinstance(file_paths, str) else file_paths
    resolved: list[Path] = []
    for raw_path in raw_paths:
        path = Path(raw_path).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")
        resolved.append(path)
    if not resolved:
        raise ValueError("at least one file path is required")
    return resolved


def _resolve_return_md(return_md: bool, middle_json_only: bool) -> bool:
    return False if middle_json_only else return_md


def _normalize_lang_list(
    language: str,
    languages: list[str] | None,
) -> list[str]:
    normalized = [item.strip() for item in (languages or []) if item.strip()]
    if normalized:
        return normalized
    return [language.strip()] if language.strip() else ["ch"]


def _stringify_bool(value: bool) -> str:
    return str(value).lower()


def _safe_stem(name: str) -> str:
    stem = Path(name).stem or "mineru_result"
    sanitized = "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in stem)
    return sanitized.strip("_") or "mineru_result"


def _short_hash(value: str) -> str:
    return hashlib.md5(value.encode("utf-8")).hexdigest()[:6]


def _resolve_output_dir(
    *,
    output_dir: str | None,
    paths: list[Path] | None,
    task_id: str | None,
    result: dict[str, Any] | None = None,
) -> Path:
    if output_dir:
        target = Path(output_dir).expanduser().resolve()
        target.mkdir(parents=True, exist_ok=True)
        return target

    root = _ensure_output_root()
    if paths:
        first_path = paths[0]
        folder_name = f"{_safe_stem(first_path.name)}_{_short_hash(str(first_path))}"
    else:
        first_result_name = next(iter((result or {}).get("results", {})), None)
        if first_result_name:
            folder_name = f"{_safe_stem(first_result_name)}_{_short_hash(first_result_name)}"
        elif task_id:
            folder_name = f"task_{_safe_stem(task_id)}_{_short_hash(task_id)}"
        else:
            folder_name = f"mineru_result_{_short_hash(str(time()))}"

    target = root / folder_name
    target.mkdir(parents=True, exist_ok=True)
    return target


def _write_text(path: Path, content: str) -> str:
    path.write_text(content, encoding="utf-8")
    return str(path)


def _write_json(path: Path, payload: Any) -> str:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return str(path)


def _parse_json_string(value: Any) -> Any:
    if not isinstance(value, str):
        return value

    text = value.strip()
    if not text or text[0] not in "[{":
        return value

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return value


def _normalize_primary_payload(payload: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(payload)
    for key in ("middle_json", "model_output", "content_list", "images"):
        normalized[key] = _parse_json_string(normalized.get(key))
    return normalized


def _normalize_result_payload(result: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(result)
    results = normalized.get("results")
    if not isinstance(results, dict):
        return normalized

    normalized["results"] = {
        source_name: _normalize_primary_payload(payload) if isinstance(payload, dict) else payload
        for source_name, payload in results.items()
    }
    return normalized


def _publish_downloadable(path: str | Path) -> str | None:
    if not DOWNLOAD_BASE_URL:
        return None

    source = Path(path).expanduser().resolve()
    share_id = uuid4().hex
    share_dir = _ensure_download_publish_dir() / share_id
    share_dir.mkdir(parents=True, exist_ok=True)
    target = share_dir / source.name
    try:
        os.link(source, target)
    except OSError:
        shutil.copy2(source, target)
    return f"{DOWNLOAD_BASE_URL}/{share_id}/{quote(source.name)}"


def _persist_primary_result(
    *,
    output_dir: Path,
    source_name: str,
    payload: dict[str, Any],
) -> dict[str, str | None]:
    prefix = _safe_stem(source_name)
    artifacts: dict[str, str | None] = {}

    markdown = payload.get("md_content")
    if markdown:
        artifacts["markdown_path"] = _write_text(output_dir / f"{prefix}.md", markdown)
        artifacts["markdown_download_url"] = _publish_downloadable(artifacts["markdown_path"])

    middle_json = payload.get("middle_json")
    if middle_json is not None:
        artifacts["middle_json_path"] = _write_json(output_dir / f"{prefix}.middle.json", middle_json)
        artifacts["middle_json_download_url"] = _publish_downloadable(artifacts["middle_json_path"])

    model_output = payload.get("model_output")
    if model_output is not None:
        artifacts["model_output_path"] = _write_json(output_dir / f"{prefix}.model_output.json", model_output)
        artifacts["model_output_download_url"] = _publish_downloadable(artifacts["model_output_path"])

    content_list = payload.get("content_list")
    if content_list is not None:
        artifacts["content_list_path"] = _write_json(output_dir / f"{prefix}.content_list.json", content_list)
        artifacts["content_list_download_url"] = _publish_downloadable(artifacts["content_list_path"])

    images = payload.get("images")
    if images is not None:
        artifacts["images_path"] = _write_json(output_dir / f"{prefix}.images.json", images)
        artifacts["images_download_url"] = _publish_downloadable(artifacts["images_path"])

    return artifacts


def _persist_result_bundle(
    *,
    result: dict[str, Any],
    output_dir: Path,
) -> dict[str, Any]:
    per_file: dict[str, dict[str, str | None]] = {}
    artifact_paths: list[str] = []
    artifact_download_urls: list[str] = []

    for source_name, payload in result.get("results", {}).items():
        if not isinstance(payload, dict):
            continue
        artifacts = _persist_primary_result(
            output_dir=output_dir,
            source_name=source_name,
            payload=payload,
        )
        if artifacts:
            per_file[source_name] = artifacts
            artifact_paths.extend(
                value for key, value in artifacts.items() if key.endswith("_path") and isinstance(value, str)
            )
            artifact_download_urls.extend(
                value for key, value in artifacts.items() if key.endswith("_download_url") and isinstance(value, str)
            )

    raw_result_path = _write_json(output_dir / "raw_result.json", result)
    raw_result_download_url = _publish_downloadable(raw_result_path)

    primary_artifact = next(iter(artifact_paths), None) or raw_result_path
    primary_download_url = next(iter(artifact_download_urls), None) or raw_result_download_url
    return {
        "output_dir": str(output_dir),
        "artifact_count": len(artifact_paths),
        "artifact_paths": artifact_paths,
        "artifact_download_urls": artifact_download_urls,
        "artifacts_by_file": per_file,
        "primary_artifact": primary_artifact,
        "primary_download_url": primary_download_url,
        "raw_result_path": raw_result_path,
        "raw_result_download_url": raw_result_download_url,
    }


def _build_parse_data(
    *,
    backend: str,
    language: str,
    languages: list[str] | None,
    parse_method: str,
    formula_enable: bool,
    table_enable: bool,
    server_url: str | None,
    start_page_id: int,
    end_page_id: int,
    return_md: bool,
    return_middle_json: bool,
    return_model_output: bool,
    return_content_list: bool,
    return_images: bool,
    response_format_zip: bool,
    return_original_file: bool,
) -> dict[str, str | list[str]]:
    data: dict[str, str | list[str]] = {
        "backend": backend,
        "parse_method": parse_method,
        "formula_enable": _stringify_bool(formula_enable),
        "table_enable": _stringify_bool(table_enable),
        "return_md": _stringify_bool(return_md),
        "return_middle_json": _stringify_bool(return_middle_json),
        "return_model_output": _stringify_bool(return_model_output),
        "return_content_list": _stringify_bool(return_content_list),
        "return_images": _stringify_bool(return_images),
        "response_format_zip": _stringify_bool(response_format_zip),
        "return_original_file": _stringify_bool(return_original_file and response_format_zip),
        "start_page_id": str(start_page_id),
        "end_page_id": str(end_page_id),
        "lang_list": _normalize_lang_list(language, languages),
    }

    if server_url:
        data["server_url"] = server_url

    return data


def _save_binary_response(
    content: bytes,
    filename_hint: str,
    suffix: str = ".zip",
    output_dir: str | None = None,
) -> str:
    target_dir = Path(output_dir).expanduser().resolve() if output_dir else _ensure_log_dir()
    target_dir.mkdir(parents=True, exist_ok=True)
    safe_name = Path(filename_hint or "mineru_result").stem or "mineru_result"
    with NamedTemporaryFile(
        prefix=f"{safe_name}_",
        suffix=suffix,
        dir=target_dir,
        delete=False,
    ) as temp_file:
        temp_file.write(content)
        return temp_file.name


def _build_progress(status: str | None, file_count: int) -> dict[str, Any]:
    is_completed = status == "completed"
    is_failed = status in {"failed", "error"}
    return {
        "current": file_count if is_completed else 0,
        "total": file_count,
        "percent": 100 if is_completed else 0,
        "stage": status or "unknown",
        "is_terminal": is_completed or is_failed,
    }


def _summarize_json_result(
    result: dict[str, Any],
    *,
    paths: list[Path] | None = None,
    elapsed_seconds: float | None = None,
    inline_content: bool = False,
    output_dir: str | None = None,
    task_id: str | None = None,
) -> dict[str, Any]:
    result = _normalize_result_payload(result)
    primary = _extract_primary_result(result)
    status = result.get("status")
    file_list = [str(path) for path in paths] if paths else []
    file_count = len(file_list) if file_list else len(result.get("results", {}))
    is_completed = status == "completed"
    is_failed = status in {"failed", "error"}
    summary = {
        "server": BASE_URL,
        "files": file_list,
        "task_id": result.get("task_id") or task_id,
        "status": status,
        "message": result.get("message"),
        "backend": result.get("backend"),
        "version": result.get("version"),
        "status_url": result.get("status_url"),
        "result_url": result.get("result_url"),
        "queued_ahead": result.get("queued_ahead"),
        "elapsed_seconds": elapsed_seconds,
        "file_count": file_count,
        "completed_count": file_count if is_completed else 0,
        "failed_count": file_count if is_failed else 0,
        "progress": _build_progress(status, file_count),
        "content_inlined": inline_content,
    }

    if inline_content:
        summary.update(
            {
                "markdown": primary.get("md_content"),
                "middle_json": primary.get("middle_json"),
                "model_output": primary.get("model_output"),
                "content_list": primary.get("content_list"),
                "images": primary.get("images"),
                "raw_result": result,
            }
        )
        return summary

    persisted = _persist_result_bundle(
        result=result,
        output_dir=_resolve_output_dir(
            output_dir=output_dir,
            paths=paths,
            task_id=result.get("task_id") or task_id,
            result=result,
        ),
    )
    summary.update(persisted)
    return summary


def _summarize_zip_result(
    response: httpx.Response,
    *,
    paths: list[Path] | None = None,
    elapsed_seconds: float | None = None,
    output_dir: str | None = None,
) -> dict[str, Any]:
    content_disposition = response.headers.get("content-disposition", "")
    filename_hint = "mineru_result"
    if "filename=" in content_disposition:
        filename_hint = content_disposition.split("filename=", 1)[1].strip().strip('"')
    zip_path = _save_binary_response(
        response.content,
        filename_hint=filename_hint,
        output_dir=output_dir,
    )
    file_list = [str(path) for path in paths] if paths else []
    file_count = len(file_list)
    status = response.headers.get("X-MinerU-Task-Status", "completed")
    return {
        "server": BASE_URL,
        "files": file_list,
        "task_id": response.headers.get("X-MinerU-Task-Id"),
        "status": status,
        "status_url": response.headers.get("X-MinerU-Task-Status-Url"),
        "result_url": response.headers.get("X-MinerU-Task-Result-Url"),
        "elapsed_seconds": elapsed_seconds,
        "file_count": file_count,
        "completed_count": file_count if status == "completed" else 0,
        "failed_count": 0 if status == "completed" else file_count,
        "progress": _build_progress(status, file_count),
        "content_inlined": False,
        "response_format": "zip",
        "zip_path": zip_path,
        "zip_filename": Path(zip_path).name,
        "zip_download_url": _publish_downloadable(zip_path),
    }


def _collect_directory_files(
    directory: str,
    pattern: str,
    recursive: bool,
) -> list[Path]:
    root = Path(directory).expanduser().resolve()
    if not root.exists():
        raise FileNotFoundError(f"Directory not found: {root}")
    if not root.is_dir():
        raise NotADirectoryError(f"Not a directory: {root}")

    iterator = root.rglob(pattern) if recursive else root.glob(pattern)
    files = sorted(path.resolve() for path in iterator if path.is_file())
    if not files:
        raise ValueError(f"no files matched pattern {pattern!r} under {root}")
    return files


def _request_parse_endpoint(
    *,
    endpoint: str,
    file_paths: str | list[str],
    backend: str,
    language: str,
    languages: list[str] | None,
    parse_method: str,
    formula_enable: bool,
    table_enable: bool,
    server_url: str | None,
    start_page_id: int,
    end_page_id: int,
    return_md: bool,
    return_middle_json: bool,
    return_model_output: bool,
    return_content_list: bool,
    return_images: bool,
    response_format_zip: bool,
    return_original_file: bool,
    inline_content: bool,
    output_dir: str | None,
) -> dict[str, Any]:
    paths = _coerce_paths(file_paths)
    started_at = time()
    data = _build_parse_data(
        backend=backend,
        language=language,
        languages=languages,
        parse_method=parse_method,
        formula_enable=formula_enable,
        table_enable=table_enable,
        server_url=server_url,
        start_page_id=start_page_id,
        end_page_id=end_page_id,
        return_md=return_md,
        return_middle_json=return_middle_json,
        return_model_output=return_model_output,
        return_content_list=return_content_list,
        return_images=return_images,
        response_format_zip=response_format_zip,
        return_original_file=return_original_file,
    )

    with ExitStack() as stack:
        opened_files = [stack.enter_context(path.open("rb")) for path in paths]
        files = [
            ("files", (path.name, file_handle, "application/octet-stream"))
            for path, file_handle in zip(paths, opened_files)
        ]
        with httpx.Client(
            timeout=TIMEOUT,
            headers=_headers(),
            trust_env=TRUST_ENV,
        ) as client:
            response = client.post(f"{BASE_URL}{endpoint}", data=data, files=files)
            response.raise_for_status()

    elapsed_seconds = round(time() - started_at, 3)
    content_type = response.headers.get("content-type", "")
    if "application/zip" in content_type:
        return _summarize_zip_result(
            response,
            paths=paths,
            elapsed_seconds=elapsed_seconds,
            output_dir=output_dir,
        )

    result = response.json()
    summary = _summarize_json_result(
        result,
        paths=paths,
        elapsed_seconds=elapsed_seconds,
        inline_content=inline_content,
        output_dir=output_dir,
    )
    summary["response_format"] = "json"
    return summary


def _parse_files(
    *,
    file_paths: str | list[str],
    backend: str,
    language: str,
    languages: list[str] | None,
    parse_method: str,
    formula_enable: bool,
    table_enable: bool,
    server_url: str | None,
    start_page_id: int,
    end_page_id: int,
    return_md: bool,
    return_middle_json: bool,
    return_model_output: bool,
    return_content_list: bool,
    return_images: bool,
    response_format_zip: bool,
    return_original_file: bool,
    inline_content: bool,
    output_dir: str | None,
) -> dict[str, Any]:
    return _request_parse_endpoint(
        endpoint="/file_parse",
        file_paths=file_paths,
        backend=backend,
        language=language,
        languages=languages,
        parse_method=parse_method,
        formula_enable=formula_enable,
        table_enable=table_enable,
        server_url=server_url,
        start_page_id=start_page_id,
        end_page_id=end_page_id,
        return_md=return_md,
        return_middle_json=return_middle_json,
        return_model_output=return_model_output,
        return_content_list=return_content_list,
        return_images=return_images,
        response_format_zip=response_format_zip,
        return_original_file=return_original_file,
        inline_content=inline_content,
        output_dir=output_dir,
    )


def _submit_parse_task(
    *,
    file_paths: str | list[str],
    backend: str,
    language: str,
    languages: list[str] | None,
    parse_method: str,
    formula_enable: bool,
    table_enable: bool,
    server_url: str | None,
    start_page_id: int,
    end_page_id: int,
    return_md: bool,
    return_middle_json: bool,
    return_model_output: bool,
    return_content_list: bool,
    return_images: bool,
    response_format_zip: bool,
    return_original_file: bool,
    inline_content: bool,
    output_dir: str | None,
) -> dict[str, Any]:
    return _request_parse_endpoint(
        endpoint="/tasks",
        file_paths=file_paths,
        backend=backend,
        language=language,
        languages=languages,
        parse_method=parse_method,
        formula_enable=formula_enable,
        table_enable=table_enable,
        server_url=server_url,
        start_page_id=start_page_id,
        end_page_id=end_page_id,
        return_md=return_md,
        return_middle_json=return_middle_json,
        return_model_output=return_model_output,
        return_content_list=return_content_list,
        return_images=return_images,
        response_format_zip=response_format_zip,
        return_original_file=return_original_file,
        inline_content=inline_content,
        output_dir=output_dir,
    )


def _request_json(method: str, endpoint: str) -> dict[str, Any]:
    with httpx.Client(timeout=TIMEOUT, headers=_headers(), trust_env=TRUST_ENV) as client:
        response = client.request(method, f"{BASE_URL}{endpoint}")
        response.raise_for_status()
        return response.json()


def _get_task_result(
    task_id: str,
    *,
    inline_content: bool,
    output_dir: str | None,
) -> dict[str, Any]:
    with httpx.Client(timeout=TIMEOUT, headers=_headers(), trust_env=TRUST_ENV) as client:
        response = client.get(f"{BASE_URL}/tasks/{task_id}/result")
        if response.status_code == 202:
            pending = response.json()
            pending["server"] = BASE_URL
            pending["task_id"] = task_id
            pending["response_format"] = "json"
            pending.setdefault("status", "pending")
            pending["content_inlined"] = inline_content
            pending["raw_result"] = dict(pending) if inline_content else None
            return pending
        if response.status_code == 409:
            failed = response.json()
            failed["server"] = BASE_URL
            failed["task_id"] = task_id
            failed["response_format"] = "json"
            failed.setdefault("status", "failed")
            failed["content_inlined"] = inline_content
            failed["raw_result"] = dict(failed) if inline_content else None
            return failed
        response.raise_for_status()

    content_type = response.headers.get("content-type", "")
    if "application/zip" in content_type:
        summary = _summarize_zip_result(response, output_dir=output_dir)
        summary["task_id"] = task_id
        return summary

    result = response.json()
    summary = _summarize_json_result(
        result,
        inline_content=inline_content,
        output_dir=output_dir,
        task_id=task_id,
    )
    summary["response_format"] = "json"
    return summary


@mcp.tool
def mineru_health() -> dict[str, Any]:
    """Check whether the remote self-hosted MinerU API is healthy."""
    with httpx.Client(timeout=30.0, headers=_headers(), trust_env=TRUST_ENV) as client:
        resp = client.get(f"{BASE_URL}/health")
        resp.raise_for_status()
        return resp.json()


@mcp.tool
def parse_document(
    file_path: str,
    backend: str = "hybrid-auto-engine",
    language: str = "ch",
    languages: list[str] | None = None,
    parse_method: str = "auto",
    formula_enable: bool = True,
    table_enable: bool = True,
    server_url: str | None = None,
    start_page_id: int = 0,
    end_page_id: int = 99999,
    return_md: bool = True,
    return_middle_json: bool = False,
    return_model_output: bool = False,
    return_content_list: bool = False,
    return_images: bool = False,
    response_format_zip: bool = False,
    return_original_file: bool = False,
    middle_json_only: bool = False,
    inline_content: bool = False,
    output_dir: str | None = None,
) -> dict[str, Any]:
    """Parse a local document through the remote MinerU API."""
    result = _parse_files(
        file_paths=file_path,
        backend=backend,
        language=language,
        languages=languages,
        parse_method=parse_method,
        formula_enable=formula_enable,
        table_enable=table_enable,
        server_url=server_url,
        start_page_id=start_page_id,
        end_page_id=end_page_id,
        return_md=_resolve_return_md(return_md, middle_json_only),
        return_middle_json=(return_middle_json or middle_json_only),
        return_model_output=return_model_output,
        return_content_list=return_content_list,
        return_images=return_images,
        response_format_zip=response_format_zip,
        return_original_file=return_original_file,
        inline_content=inline_content,
        output_dir=output_dir,
    )
    result["file"] = result["files"][0]
    return result


@mcp.tool
def parse_documents(
    file_paths: list[str],
    backend: str = "hybrid-auto-engine",
    language: str = "ch",
    languages: list[str] | None = None,
    parse_method: str = "auto",
    formula_enable: bool = True,
    table_enable: bool = True,
    server_url: str | None = None,
    start_page_id: int = 0,
    end_page_id: int = 99999,
    return_md: bool = True,
    return_middle_json: bool = False,
    return_model_output: bool = False,
    return_content_list: bool = False,
    return_images: bool = False,
    response_format_zip: bool = False,
    return_original_file: bool = False,
    middle_json_only: bool = False,
    inline_content: bool = False,
    output_dir: str | None = None,
) -> dict[str, Any]:
    """Parse one or more local documents through the remote MinerU API."""
    return _parse_files(
        file_paths=file_paths,
        backend=backend,
        language=language,
        languages=languages,
        parse_method=parse_method,
        formula_enable=formula_enable,
        table_enable=table_enable,
        server_url=server_url,
        start_page_id=start_page_id,
        end_page_id=end_page_id,
        return_md=_resolve_return_md(return_md, middle_json_only),
        return_middle_json=(return_middle_json or middle_json_only),
        return_model_output=return_model_output,
        return_content_list=return_content_list,
        return_images=return_images,
        response_format_zip=response_format_zip,
        return_original_file=return_original_file,
        inline_content=inline_content,
        output_dir=output_dir,
    )


@mcp.tool
def parse_directory(
    directory: str,
    pattern: str = "*",
    recursive: bool = False,
    backend: str = "hybrid-auto-engine",
    language: str = "ch",
    languages: list[str] | None = None,
    parse_method: str = "auto",
    formula_enable: bool = True,
    table_enable: bool = True,
    server_url: str | None = None,
    start_page_id: int = 0,
    end_page_id: int = 99999,
    return_md: bool = True,
    return_middle_json: bool = False,
    return_model_output: bool = False,
    return_content_list: bool = False,
    return_images: bool = False,
    response_format_zip: bool = False,
    return_original_file: bool = False,
    middle_json_only: bool = False,
    inline_content: bool = False,
    output_dir: str | None = None,
) -> dict[str, Any]:
    """Parse all matching files in a directory through the remote MinerU API."""
    files = _collect_directory_files(directory, pattern, recursive)
    result = _parse_files(
        file_paths=[str(path) for path in files],
        backend=backend,
        language=language,
        languages=languages,
        parse_method=parse_method,
        formula_enable=formula_enable,
        table_enable=table_enable,
        server_url=server_url,
        start_page_id=start_page_id,
        end_page_id=end_page_id,
        return_md=_resolve_return_md(return_md, middle_json_only),
        return_middle_json=(return_middle_json or middle_json_only),
        return_model_output=return_model_output,
        return_content_list=return_content_list,
        return_images=return_images,
        response_format_zip=response_format_zip,
        return_original_file=return_original_file,
        inline_content=inline_content,
        output_dir=output_dir,
    )
    result["directory"] = str(Path(directory).expanduser().resolve())
    result["pattern"] = pattern
    result["recursive"] = recursive
    result["matched_count"] = len(files)
    return result


@mcp.tool
def submit_parse_task(
    file_paths: list[str],
    backend: str = "hybrid-auto-engine",
    language: str = "ch",
    languages: list[str] | None = None,
    parse_method: str = "auto",
    formula_enable: bool = True,
    table_enable: bool = True,
    server_url: str | None = None,
    start_page_id: int = 0,
    end_page_id: int = 99999,
    return_md: bool = True,
    return_middle_json: bool = False,
    return_model_output: bool = False,
    return_content_list: bool = False,
    return_images: bool = False,
    response_format_zip: bool = False,
    return_original_file: bool = False,
    middle_json_only: bool = False,
    inline_content: bool = False,
    output_dir: str | None = None,
) -> dict[str, Any]:
    """Submit one or more local documents as an asynchronous MinerU parse task."""
    return _submit_parse_task(
        file_paths=file_paths,
        backend=backend,
        language=language,
        languages=languages,
        parse_method=parse_method,
        formula_enable=formula_enable,
        table_enable=table_enable,
        server_url=server_url,
        start_page_id=start_page_id,
        end_page_id=end_page_id,
        return_md=_resolve_return_md(return_md, middle_json_only),
        return_middle_json=(return_middle_json or middle_json_only),
        return_model_output=return_model_output,
        return_content_list=return_content_list,
        return_images=return_images,
        response_format_zip=response_format_zip,
        return_original_file=return_original_file,
        inline_content=inline_content,
        output_dir=output_dir,
    )


@mcp.tool
def get_task_status(task_id: str) -> dict[str, Any]:
    """Fetch the status payload for an asynchronous MinerU parse task."""
    result = _request_json("GET", f"/tasks/{task_id}")
    result["server"] = BASE_URL
    return result


@mcp.tool
def get_task_result(
    task_id: str,
    inline_content: bool = False,
    output_dir: str | None = None,
) -> dict[str, Any]:
    """Fetch the final result for an asynchronous MinerU parse task."""
    return _get_task_result(
        task_id,
        inline_content=inline_content,
        output_dir=output_dir,
    )


@mcp.tool
def get_ocr_languages() -> dict[str, Any]:
    """List common OCR language codes supported by MinerU."""
    return {
        "count": len(OCR_LANGUAGES),
        "languages": OCR_LANGUAGES,
    }


@mcp.tool
def clean_logs(days: int = 7) -> dict[str, Any]:
    """Delete local MCP log files older than the requested number of days."""
    if days < 0:
        raise ValueError("days must be >= 0")

    log_dir = _ensure_log_dir()
    cutoff = time() - (days * 86400)
    deleted: list[str] = []

    for path in log_dir.rglob("*"):
        if not path.is_file():
            continue
        if path.stat().st_mtime < cutoff:
            path.unlink()
            deleted.append(str(path))

    return {
        "log_dir": str(log_dir),
        "days": days,
        "deleted_count": len(deleted),
        "deleted_files": deleted,
    }


def main() -> None:
    mcp.run()
