"""NatShell TUI application — the main user interface."""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from textual import on, work
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.events import MouseUp
from textual.widgets import Button, Footer, Input, Static

from natshell.agent.loop import AgentEvent, AgentLoop, EventType
from natshell.agent.plan import Plan, parse_plan_file
from natshell.agent.plan_executor import (
    _build_plan_prompt,
    _build_step_prompt,
    _effective_plan_max_steps,
    _shallow_tree,
)
from natshell.commands import (
    compact_chat,
    handle_undo,
    show_help,
    show_history_info,
    show_memory,
    show_skills,
)
from natshell.config import (
    NatShellConfig,
    apply_profile,
    list_profiles,
    save_engine_preference,
    save_model_config,
    save_ollama_default,
)
from natshell.inference.engine import ToolCall
from natshell.model_manager import (
    BUNDLED_TIERS,
    download_bundled_model,
    fetch_model_list,
    find_local_model,
    format_download_menu,
    format_local_models,
    format_model_info,
    format_model_list,
    get_remote_base_url,
    prepare_remote_engine_params,
    resolve_local_model_path,
    set_default_model,
)
from natshell.safety.classifier import Risk
from natshell.session import AmbiguousSessionID, SessionManager
from natshell.tools.execute_shell import (
    _has_sudo_invocation,
    execute_shell,
    needs_sudo_password,
    set_sudo_password,
)
from natshell.tools.registry import PLAN_SAFE_TOOLS
from natshell.ui import clipboard
from natshell.ui.commands import MODELS_DIR, ModelSwitchProvider
from natshell.ui.widgets import (
    AssistantMessage,
    BlockedMessage,
    CommandBlock,
    ConfirmScreen,
    ErrorMessage,
    HistoryInput,
    LogoBanner,
    PlanningMessage,
    PlanOverviewMessage,
    PlanStepDivider,
    PlanSummaryMessage,
    QuitConfirmScreen,
    RunStatsMessage,
    SudoPasswordScreen,
    SystemMessage,
    ThinkingIndicator,
    UserMessage,
    _escape,
)


def _tool_display_text(tool_call: ToolCall) -> str:
    """Human-readable command text for the EXECUTING display block."""
    match tool_call.name:
        case "execute_shell":
            return tool_call.arguments.get("command", str(tool_call.arguments))
        case "edit_file":
            return f"edit_file \u2192 {tool_call.arguments.get('path', '?')}"
        case "run_code":
            lang = tool_call.arguments.get("language", "?")
            return f"run_code \u2192 {lang}"
        case "write_file":
            return f"write_file \u2192 {tool_call.arguments.get('path', '?')}"
        case _:
            return f"{tool_call.name}({tool_call.arguments})"


logger = logging.getLogger(__name__)


SLASH_COMMANDS = [
    ("/help", "Show available commands"),
    ("/skills", "List available skills"),
    ("/skills show", "Show full instructions for a skill"),
    ("/skills enable", "Enable a skill"),
    ("/skills disable", "Disable a skill"),
    ("/clear", "Clear chat and model context"),
    ("/compact", "Compact context, keeping key facts"),
    ("/cmd", "Execute a shell command directly"),
    ("/exeplan", "Preview or execute a multi-step plan"),
    ("/plan", "Generate a multi-step plan from a description"),
    ("/model", "Show current engine/model info"),
    ("/model list", "List models on the remote server"),
    ("/model use", "Switch to a remote model"),
    ("/model switch", "Switch to a different local model"),
    ("/model local", "Switch back to local model"),
    ("/model default", "Set default remote model"),
    ("/profile", "List configuration profiles"),
    ("/profile", "Apply a configuration profile"),
    ("/history", "Show conversation context size"),
    ("/keys", "Show keyboard shortcuts"),
    ("/memory", "Show working memory content"),
    ("/memory reload", "Re-read agents.md from disk"),
    ("/memory clear", "Clear working memory file"),
    ("/memory path", "Show memory file path"),
    ("/undo", "Undo the last file edit or write"),
    ("/save", "Save current session"),
    ("/load", "Load a saved session (list if no id)"),
    ("/sessions", "List saved sessions"),
    ("/exit", "Exit NatShell"),
    ("/quit", "Exit NatShell"),
]


class NatShellApp(App):
    """The NatShell TUI application."""

    TITLE = "NatShell"
    SUB_TITLE = "Natural Language Shell"
    CSS_PATH = Path("ui/styles.tcss")
    COMMANDS = App.COMMANDS | {ModelSwitchProvider}

    ALLOW_SELECT = True

    BINDINGS = [
        Binding("ctrl+c", "copy_selection", "Copy", priority=True),
        Binding("ctrl+e", "copy_chat", "Copy Chat"),
        Binding("ctrl+l", "clear_chat", "Clear Chat"),
    ]

    def __init__(
        self,
        agent: AgentLoop,
        config: NatShellConfig | None = None,
        skip_permissions: bool = False,
        skill_registry: object = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.agent = agent
        self._config = config or NatShellConfig()
        self._busy = False
        self._skip_permissions = skip_permissions
        self._session_mgr = SessionManager()
        self._skill_registry = skill_registry
        # Tab completion state
        self._completion_matches: list[str] = []
        self._completion_index: int = -1
        self._completion_prefix: str = ""

    def copy_to_clipboard(self, text: str) -> None:
        """Copy text using NatShell's clipboard backends, with OSC52 fallback."""
        if not clipboard.copy(text, self):
            super().copy_to_clipboard(text)

    def compose(self) -> ComposeResult:
        """Yield the child widgets to construct the main application UI layout."""
        yield LogoBanner()
        yield ScrollableContainer(
            Static(
                "[dim]Welcome to NatShell. Type a request to get started."
                " Use /help for commands.[/]\n"
            ),
            id="conversation",
        )
        with Vertical(id="input-area"):
            yield Static(id="slash-suggestions")
            with Horizontal(id="input-row"):
                yield Button("\u2715", id="quit-btn", variant="default")
                yield HistoryInput(
                    placeholder="Ask me anything about your system...",
                    id="user-input",
                )
                yield Button("\U0001f4cb", id="paste-btn", variant="default")
        yield Footer()

    def on_mount(self) -> None:
        """Handle application startup: focus the input widget.

        Shows warnings if in danger mode.
        """
        self.query_one("#user-input", Input).focus()
        if self._skip_permissions:
            conversation = self.query_one("#conversation", ScrollableContainer)
            conversation.mount(
                Static(
                    "[bold yellow]WARNING: --danger-fast is active. "
                    "All confirmations will be skipped.[/]\n"
                )
            )

    @on(Input.Changed, "#user-input")
    def on_input_changed(self, event: Input.Changed) -> None:
        """Show/hide slash command suggestions as the user types."""
        text = event.value
        suggestions = self.query_one("#slash-suggestions", Static)

        # Reset completion state when the user types manually
        self._completion_matches = []
        self._completion_index = -1
        self._completion_prefix = ""

        if text.startswith("/") and " " not in text:
            matches = [(cmd, desc) for cmd, desc in SLASH_COMMANDS if cmd.startswith(text.lower())]
            if matches:
                lines = [f"  [bold cyan]{cmd}[/]  [dim]{desc}[/]" for cmd, desc in matches]
                suggestions.update("\n".join(lines))
                suggestions.display = True
                return

        suggestions.display = False

    def _build_completions(self, text: str) -> list[str]:
        """Build tab-completion candidates for the current input text."""
        if not text.startswith("/"):
            return []

        parts = text.split(maxsplit=1)
        base_cmd = parts[0].lower()

        if len(parts) == 1 and not text.endswith(" "):
            # Level 1: complete the base command
            seen: set[str] = set()
            matches: list[str] = []
            for cmd, _ in SLASH_COMMANDS:
                # Extract just the base command (first word)
                base = cmd.split()[0]
                if base.startswith(base_cmd) and base not in seen:
                    seen.add(base)
                    matches.append(base)
            return matches

        # Level 2: complete subcommands/arguments
        arg_prefix = parts[1].lower() if len(parts) > 1 else ""

        if base_cmd == "/model":
            subs = ["list", "use", "switch", "local", "default"]
            return [
                f"/model {s}" for s in subs if s.startswith(arg_prefix)
            ]
        elif base_cmd == "/profile":
            profiles = list_profiles(self._config)
            return [
                f"/profile {p}" for p in profiles if p.startswith(arg_prefix)
            ]
        elif base_cmd == "/load":
            try:
                sessions = self._session_mgr.list_sessions()
                return [
                    f"/load {s['id']}"
                    for s in sessions
                    if s["id"].startswith(arg_prefix)
                ]
            except Exception:
                return []

        return []

    def on_history_input_tab_complete(
        self, message: HistoryInput.TabComplete
    ) -> None:
        """Handle tab completion from the input widget."""
        input_widget = self.query_one("#user-input", HistoryInput)
        text = input_widget.value

        # If no active completion, build matches
        if not self._completion_matches:
            self._completion_prefix = text
            self._completion_matches = self._build_completions(text)
            if not self._completion_matches:
                return
            self._completion_index = -1

        # Cycle through matches
        if message.reverse:
            self._completion_index -= 1
            if self._completion_index < 0:
                self._completion_index = len(self._completion_matches) - 1
        else:
            self._completion_index += 1
            if self._completion_index >= len(self._completion_matches):
                self._completion_index = 0

        match = self._completion_matches[self._completion_index]
        input_widget.value = match
        input_widget.cursor_position = len(match)

    @on(Input.Submitted, "#user-input")
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Process the user's input when they press Enter."""
        input_widget = self.query_one("#user-input", HistoryInput)
        user_text = input_widget.get_submit_text().strip()
        self.query_one("#slash-suggestions", Static).display = False
        if not user_text:
            return

        if self._busy:
            # Slash commands are not safe mid-run
            if user_text.startswith("/"):
                return
            # Queue the message for injection between agent steps
            input_widget.add_to_history(user_text)
            input_widget.value = ""
            input_widget.clear_paste()
            conversation = self.query_one("#conversation", ScrollableContainer)
            conversation.mount(UserMessage(user_text))
            conversation.scroll_end()
            self.agent.enqueue_message(user_text)
            return

        input_widget.add_to_history(user_text)
        input_widget.value = ""
        input_widget.clear_paste()

        # Intercept slash commands before the agent
        if user_text.startswith("/"):
            await self._handle_slash_command(user_text)
            return

        # Bare "exit" or "quit" exits the app
        if user_text.lower() in ("exit", "quit"):
            self.exit()
            return

        self._busy = True

        # Add user message to conversation
        conversation = self.query_one("#conversation", ScrollableContainer)
        conversation.mount(UserMessage(user_text))

        # Run the agent loop
        self.run_agent(user_text)

    def _render_agent_event(
        self,
        event: AgentEvent,
        conversation: ScrollableContainer,
        thinking_ref: list[ThinkingIndicator | None],
        elapsed_ref: list[int] | None = None,
    ) -> None:
        """Render a single agent event into the conversation. Shared by run_agent and run_plan.

        thinking_ref is a single-element list holding the current ThinkingIndicator
        (or None), used as a mutable reference so callers can track it.
        elapsed_ref carries the accumulated thinking time across indicator replacements.
        """
        if elapsed_ref is None:
            elapsed_ref = [0]
        thinking = thinking_ref[0]

        # Remove thinking indicator when we get a real event
        if thinking and event.type in (
            EventType.PLANNING,
            EventType.TOOL_RESULT,
            EventType.RESPONSE,
            EventType.BLOCKED,
            EventType.CONFIRM_NEEDED,
            EventType.ERROR,
        ):
            elapsed_ref[0] = thinking._elapsed
            thinking.remove()
            thinking_ref[0] = None
            self.query_one(LogoBanner).stop_animation()

        match event.type:
            case EventType.THINKING:
                if not thinking_ref[0]:
                    indicator = ThinkingIndicator(elapsed=elapsed_ref[0])
                    conversation.mount(indicator)
                    thinking_ref[0] = indicator
                    self.query_one(LogoBanner).start_animation()

            case EventType.PLANNING:
                conversation.mount(PlanningMessage(event.data))

            case EventType.EXECUTING:
                cmd = _tool_display_text(event.tool_call)
                block = CommandBlock(cmd)
                block.id = f"cmd-{event.tool_call.id}"
                conversation.mount(block)

            case EventType.TOOL_RESULT:
                block_id = f"cmd-{event.tool_call.id}"
                try:
                    block = self.query_one(f"#{block_id}", CommandBlock)
                    block.set_result(
                        event.tool_result.output or event.tool_result.error,
                        event.tool_result.exit_code,
                    )
                except Exception:
                    conversation.mount(
                        CommandBlock(
                            str(event.tool_call.arguments),
                            event.tool_result.output or event.tool_result.error,
                            event.tool_result.exit_code,
                        )
                    )

            case EventType.BLOCKED:
                cmd = event.tool_call.arguments.get("command", str(event.tool_call.arguments))
                conversation.mount(BlockedMessage(cmd))

            case EventType.RESPONSE:
                conversation.mount(AssistantMessage(event.data, metrics=event.metrics))

            case EventType.RUN_STATS:
                if event.metrics:
                    conversation.mount(RunStatsMessage(event.metrics))

            case EventType.QUEUED_MESSAGE:
                pass  # Already rendered by on_input_submitted

            case EventType.ERROR:
                conversation.mount(ErrorMessage(event.data))

        conversation.scroll_end()

    @work(exclusive=True, thread=False)
    async def run_agent(self, user_text: str) -> None:
        """Run the agent loop in a background worker."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        thinking_ref: list[ThinkingIndicator | None] = [None]
        elapsed_ref: list[int] = [0]

        async def confirm_callback(tool_call: ToolCall) -> bool:
            return await self.push_screen_wait(ConfirmScreen(tool_call))

        async def password_callback(tool_call: ToolCall) -> str | None:
            command = tool_call.arguments.get("command", "")
            return await self.push_screen_wait(SudoPasswordScreen(command))

        confirm_cb = None if self._skip_permissions else confirm_callback

        try:
            async for event in self.agent.handle_user_message(
                user_text,
                confirm_callback=confirm_cb,
                password_callback=password_callback,
            ):
                self._render_agent_event(event, conversation, thinking_ref, elapsed_ref)

        except Exception as e:
            conversation.mount(ErrorMessage(str(e)))

        finally:
            if thinking_ref[0]:
                thinking_ref[0].remove()
            self._busy = False
            self.query_one(LogoBanner).stop_animation()
            self.query_one("#user-input", Input).focus()

    async def _handle_slash_command(self, text: str) -> None:
        """Parse and dispatch slash commands."""
        parts = text.split(maxsplit=1)
        command = parts[0].lower()
        args = parts[1] if len(parts) > 1 else ""
        conversation = self.query_one("#conversation", ScrollableContainer)

        match command:
            case "/help":
                self._show_help(conversation)
            case "/skills":
                self._handle_skills(args, conversation)
            case "/clear":
                self.action_clear_chat()
            case "/compact":
                self._compact_chat(conversation)
            case "/cmd":
                if not args:
                    conversation.mount(SystemMessage("Usage: /cmd <command>"))
                else:
                    self.run_cmd(args)
            case "/exeplan":
                self._handle_exeplan_command(args, conversation)
            case "/plan":
                if not args:
                    conversation.mount(
                        SystemMessage(
                            "Usage: /plan <description>\n"
                            "Example: /plan build a REST API with Express and SQLite"
                        )
                    )
                else:
                    self._handle_plan_command(args, conversation)
            case "/profile":
                await self._handle_profile_command(args, conversation)
            case "/model":
                await self._handle_model_command(args, conversation)
            case "/history":
                self._show_history_info(conversation)
            case "/keys":
                self._show_keys(conversation)
            case "/memory":
                self._handle_memory(args, conversation)
            case "/undo":
                self._handle_undo(conversation)
            case "/save":
                self._handle_save(args, conversation)
            case "/load":
                self._handle_load(args, conversation)
            case "/sessions":
                self._handle_sessions(conversation)
            case "/exit" | "/quit":
                self.exit()
            case _:
                conversation.mount(
                    SystemMessage(f"Unknown command: {command}. Type /help for available commands.")
                )

        conversation.scroll_end()

    @work(exclusive=True, thread=False)
    async def run_cmd(self, command: str) -> None:
        """Execute a shell command directly, bypassing the AI. Runs in a worker
        so that push_screen_wait (for confirmation/sudo password) works."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        conversation.mount(UserMessage(f"/cmd {command}"))

        # Safety classification
        risk = self.agent.safety.classify_command(command)

        if risk == Risk.BLOCKED:
            conversation.mount(BlockedMessage(command))
            return

        if risk == Risk.CONFIRM and not self._skip_permissions:
            synthetic_call = ToolCall(
                id="slash-cmd", name="execute_shell", arguments={"command": command}
            )
            confirmed = await self.push_screen_wait(ConfirmScreen(synthetic_call))
            if not confirmed:
                conversation.mount(SystemMessage("Command cancelled."))
                return

        self._busy = True
        try:
            result = await execute_shell(command)

            # If sudo needs a password, prompt and retry
            if needs_sudo_password(result):
                password = await self.push_screen_wait(SudoPasswordScreen(command))
                if password:
                    set_sudo_password(password)
                    # If the command doesn't contain sudo at a command
                    # position (e.g. "apt install" which internally invokes
                    # sudo), prepend it so the password injection kicks in.
                    retry_cmd = (
                        command if _has_sudo_invocation(command) else f"sudo {command}"
                    )
                    # Re-classify the modified command — prepending sudo
                    # may change the risk level.
                    retry_risk = self.agent.safety.classify_tool_call(
                        "execute_shell", {"command": retry_cmd}
                    )
                    if retry_risk == Risk.BLOCKED:
                        conversation.mount(
                            SystemMessage("Retried command with sudo was blocked.")
                        )
                        return
                    if retry_risk == Risk.CONFIRM and not self._skip_permissions:
                        synthetic = ToolCall(
                            id="slash-cmd-retry",
                            name="execute_shell",
                            arguments={"command": retry_cmd},
                        )
                        confirmed = await self.push_screen_wait(
                            ConfirmScreen(synthetic)
                        )
                        if not confirmed:
                            conversation.mount(SystemMessage("Command cancelled."))
                            return
                    result = await execute_shell(retry_cmd)

            output = result.output or result.error
            conversation.mount(CommandBlock(command, output, result.exit_code))
            # Show stderr in red when both stdout and stderr are present
            if result.error and result.output:
                conversation.mount(
                    Static(f"[red]{_escape(result.error)}[/]", classes="cmd-output")
                )

            # Inject into agent context so the model knows what the user ran
            context_output = output
            if result.error and result.output:
                context_output = f"{result.output}\nStderr:\n{result.error}"
            self.agent.messages.append(
                {
                    "role": "user",
                    "content": (
                        f"[The user directly ran a shell command: `{command}`]\n"
                        f"Exit code: {result.exit_code}\n"
                        f"Output:\n{context_output}"
                    ),
                }
            )
        finally:
            self._busy = False
            self.query_one("#user-input", Input).focus()
            conversation.scroll_end()

    # ─── /plan ────────────────────────────────────────────────────────────

    def _handle_plan_command(self, description: str, conversation: ScrollableContainer) -> None:
        """Generate a PLAN.md file from a natural language description."""
        conversation.mount(UserMessage(f"/plan {description}"))
        conversation.mount(
            SystemMessage(
                "Generating plan\u2026 the model will examine your project and create PLAN.md."
            )
        )
        self.run_plan_generation(description)

    @work(exclusive=True, thread=False)
    async def run_plan_generation(self, description: str) -> None:
        """Run the agent loop with a plan generation prompt."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        thinking_ref: list[ThinkingIndicator | None] = [None]
        elapsed_ref: list[int] = [0]
        self._busy = True

        async def confirm_callback(tool_call: ToolCall) -> bool:
            return await self.push_screen_wait(ConfirmScreen(tool_call))

        async def password_callback(tool_call: ToolCall) -> str | None:
            command = tool_call.arguments.get("command", "")
            return await self.push_screen_wait(SudoPasswordScreen(command))

        confirm_cb = None if self._skip_permissions else confirm_callback

        # Fresh context — plan generation is self-contained
        self.agent.clear_history()
        tree = _shallow_tree(Path.cwd())
        try:
            n_ctx = self.agent.engine.engine_info().n_ctx or 4096
        except (AttributeError, TypeError):
            n_ctx = 4096
        prompt = _build_plan_prompt(description, tree, n_ctx=n_ctx)

        try:
            async for event in self.agent.handle_user_message(
                prompt,
                confirm_callback=confirm_cb,
                password_callback=password_callback,
                tool_filter=PLAN_SAFE_TOOLS,
                skip_intent_detection=True,
            ):
                self._render_agent_event(event, conversation, thinking_ref, elapsed_ref)

        except Exception as e:
            conversation.mount(ErrorMessage(str(e)))

        finally:
            if thinking_ref[0]:
                thinking_ref[0].remove()
            self._busy = False
            self.query_one(LogoBanner).stop_animation()
            self.query_one("#user-input", Input).focus()

        # Preview the generated plan if it was written
        plan_path = Path.cwd() / "PLAN.md"
        if plan_path.exists():
            try:
                plan = parse_plan_file(str(plan_path))
                conversation.mount(PlanOverviewMessage(plan.title, [s.title for s in plan.steps]))
            except (ValueError, FileNotFoundError):
                conversation.mount(
                    SystemMessage(
                        f"Plan written to {plan_path}\n"
                        "[dim]Note: could not parse step structure. "
                        "Check that ## headings are used for steps.[/]"
                    )
                )

        conversation.scroll_end()

    # ─── /exeplan ──────────────────────────────────────────────────────────

    def _handle_exeplan_command(self, args: str, conversation: ScrollableContainer) -> None:
        """Dispatch /exeplan subcommands."""
        parts = args.strip().split(maxsplit=1)

        if not parts:
            conversation.mount(
                SystemMessage(
                    "Usage: /exeplan <file>       \u2014 preview plan steps\n"
                    "       /exeplan run <file>   \u2014 execute all steps\n"
                    "       /exeplan show <file>  \u2014 same as bare /exeplan"
                )
            )
            return

        subcmd = parts[0].lower()

        if subcmd == "run":
            file_path = parts[1].strip() if len(parts) > 1 else ""
            if not file_path:
                conversation.mount(SystemMessage("Usage: /exeplan run <file>"))
                return
            try:
                plan = parse_plan_file(file_path)
            except FileNotFoundError as e:
                conversation.mount(SystemMessage(f"[red]{e}[/]"))
                return
            except ValueError as e:
                conversation.mount(SystemMessage(f"[red]Parse error: {e}[/]"))
                return
            self.run_plan(plan)

        elif subcmd == "show":
            file_path = parts[1].strip() if len(parts) > 1 else ""
            if not file_path:
                conversation.mount(SystemMessage("Usage: /exeplan show <file>"))
                return
            self._show_plan_preview(file_path, conversation)

        else:
            # Bare /exeplan <file> — treat as show
            file_path = args.strip()
            self._show_plan_preview(file_path, conversation)

    def _show_plan_preview(self, file_path: str, conversation: ScrollableContainer) -> None:
        """Parse and display a plan preview (dry-run)."""
        try:
            plan = parse_plan_file(file_path)
        except FileNotFoundError as e:
            conversation.mount(SystemMessage(f"[red]{e}[/]"))
            return
        except ValueError as e:
            conversation.mount(SystemMessage(f"[red]Parse error: {e}[/]"))
            return

        conversation.mount(PlanOverviewMessage(plan.title, [s.title for s in plan.steps]))

    @work(exclusive=True, thread=False)
    async def run_plan(self, plan: Plan) -> None:
        """Execute a multi-step plan, one step at a time."""
        import time

        conversation = self.query_one("#conversation", ScrollableContainer)
        self._busy = True
        plan_t0 = time.monotonic()

        # Show plan overview header
        conversation.mount(
            SystemMessage(
                f"[bold]Executing plan:[/] {_escape(plan.title)} ({len(plan.steps)} steps)"
            )
        )
        conversation.scroll_end()

        async def confirm_callback(tool_call: ToolCall) -> bool:
            return await self.push_screen_wait(ConfirmScreen(tool_call))

        async def password_callback(tool_call: ToolCall) -> str | None:
            command = tool_call.arguments.get("command", "")
            return await self.push_screen_wait(SudoPasswordScreen(command))

        confirm_cb = None if self._skip_permissions else confirm_callback

        completed_summaries: list[str] = []
        completed_files: list[str] = []
        completed_count = 0
        failed_count = 0
        skipped_count = 0

        # Get engine context window for scaling
        try:
            n_ctx = self.agent.engine.engine_info().n_ctx or 4096
        except (AttributeError, TypeError):
            n_ctx = 4096

        # State persistence for resume support
        from datetime import datetime, timezone

        from natshell.agent.plan_state import (
            PlanState,
            StepResult,
            save_plan_state,
            state_path_for_plan,
        )

        plan_source = plan.source_dir or Path.cwd()
        state_file = state_path_for_plan(plan_source / "PLAN.md")
        state = PlanState(
            plan_file=str(state_file.with_suffix(".md")),
            plan_title=plan.title,
            total_steps=len(plan.steps),
            step_results=[],
            completed_summaries=[],
            completed_files=[],
            started_at=datetime.now(timezone.utc).isoformat(),
        )

        try:
            for step in plan.steps:
                # Mount step divider
                divider = PlanStepDivider(step.number, len(plan.steps), step.title)
                divider.id = f"plan-step-{step.number}"
                conversation.mount(divider)
                conversation.scroll_end()

                # Clear agent history (keep system prompt) for a fresh context
                self.agent.clear_history()

                # Use context-aware step limit for plan execution
                # plan_max is a FLOOR — large-context models get their
                # full context-scaled budget when it exceeds the plan floor.
                plan_max = _effective_plan_max_steps(n_ctx, self.agent.config.plan_max_steps)
                original_max = self.agent.config.max_steps
                effective_max = max(plan_max, self.agent._effective_max_steps(n_ctx))
                self.agent.config.max_steps = effective_max
                self.agent.set_step_limit(effective_max)

                # Re-read working memory for cross-step context
                wm_content: str | None = None
                if self._config.memory.enabled:
                    from natshell.agent.working_memory import (
                        load_working_memory,
                        should_inject_memory,
                    )

                    if should_inject_memory(n_ctx, self._config.memory.min_ctx):
                        wm = load_working_memory(
                            Path.cwd(), self._config.memory.max_chars
                        )
                        if wm is not None:
                            wm_content = wm.content

                # Build focused prompt for this step
                prompt = _build_step_prompt(
                    step,
                    plan,
                    completed_summaries,
                    max_steps=effective_max,
                    completed_files=completed_files or None,
                    n_ctx=n_ctx,
                    working_memory=wm_content,
                )

                # Run the agent loop for this step
                thinking_ref: list[ThinkingIndicator | None] = [None]
                elapsed_ref: list[int] = [0]
                hit_max_steps = False
                step_files: list[str] = []

                try:
                    async for event in self.agent.handle_user_message(
                        prompt,
                        confirm_callback=confirm_cb,
                        password_callback=password_callback,
                    ):
                        self._render_agent_event(event, conversation, thinking_ref, elapsed_ref)

                        # Track file changes for cross-step memory
                        if (
                            event.type == EventType.TOOL_RESULT
                            and event.tool_call
                            and event.tool_call.name in ("write_file", "edit_file")
                            and event.tool_result
                            and event.tool_result.exit_code == 0
                        ):
                            path = event.tool_call.arguments.get("path", "")
                            if path:
                                action = (
                                    "created"
                                    if event.tool_call.name == "write_file"
                                    else "modified"
                                )
                                step_files.append(
                                    f"{path} ({action} in step {step.number})"
                                )

                        # Detect max-steps warning
                        if (
                            event.type == EventType.RESPONSE
                            and event.data
                            and "maximum number of steps" in event.data
                        ):
                            hit_max_steps = True

                except Exception as e:
                    conversation.mount(ErrorMessage(str(e)))
                    divider.mark_failed(str(e))
                    failed_count += 1
                    completed_summaries.append(f"{step.number}. {step.title} \u2717")
                    state.step_results.append(StepResult(
                        number=step.number, title=step.title, status="failed",
                        summary=completed_summaries[-1], files_changed=step_files,
                        error=str(e),
                    ))
                    state.completed_summaries = list(completed_summaries)
                    state.completed_files = list(completed_files)
                    save_plan_state(state, state_file)
                    continue

                finally:
                    self.agent.config.max_steps = original_max
                    self.agent.set_step_limit(
                        self.agent._effective_max_steps(n_ctx)
                    )
                    if thinking_ref[0]:
                        thinking_ref[0].remove()
                    self.query_one(LogoBanner).stop_animation()

                # Record file changes from this step
                completed_files.extend(step_files)

                # Update divider status
                if hit_max_steps:
                    divider.mark_partial()
                    failed_count += 1
                    completed_summaries.append(f"{step.number}. {step.title} \u26a0 (partial)")
                else:
                    divider.mark_done()
                    completed_count += 1
                    completed_summaries.append(f"{step.number}. {step.title} \u2713")

                # Persist state after each step
                step_status = "passed" if not hit_max_steps else "partial"
                state.step_results.append(StepResult(
                    number=step.number, title=step.title, status=step_status,
                    summary=completed_summaries[-1], files_changed=step_files,
                ))
                state.completed_summaries = list(completed_summaries)
                state.completed_files = list(completed_files)
                save_plan_state(state, state_file)

                conversation.scroll_end()

        except Exception as e:
            conversation.mount(ErrorMessage(str(e)))
        finally:
            # Calculate remaining skipped steps
            executed = completed_count + failed_count
            skipped_count = len(plan.steps) - executed

            wall_ms = int((time.monotonic() - plan_t0) * 1000)
            conversation.mount(
                PlanSummaryMessage(completed_count, failed_count, skipped_count, wall_ms)
            )

            # Final state save
            state.finished_at = datetime.now(timezone.utc).isoformat()
            save_plan_state(state, state_file)

            self._busy = False
            self.query_one(LogoBanner).stop_animation()
            self.query_one("#user-input", Input).focus()
            conversation.scroll_end()

    def _show_help(self, conversation: ScrollableContainer) -> None:
        """Show available slash commands."""
        show_help(conversation)

    def _show_keys(self, conversation: ScrollableContainer) -> None:
        """Show keyboard shortcuts."""
        keys_text = (
            "[bold]Keyboard Shortcuts[/]\n\n"
            "  [bold cyan]Enter[/]       Send message\n"
            "  [bold cyan]Up/Down[/]     Navigate input history\n"
            "  [bold cyan]Ctrl+C[/]      Copy selected text\n"
            "  [bold cyan]Ctrl+E[/]      Copy entire chat\n"
            "  [bold cyan]Ctrl+L[/]      Clear chat\n"
            "  [bold cyan]Ctrl+P[/]      Command palette (model switcher)\n\n"
            "  Type [bold cyan]exit[/] or [bold cyan]/exit[/] to quit."
        )
        conversation.mount(SystemMessage(keys_text))

    async def _handle_model_command(self, args: str, conversation: ScrollableContainer) -> None:
        """Dispatch /model subcommands."""
        if not args:
            self._show_model_info(conversation)
            return

        parts = args.split(maxsplit=1)
        subcmd = parts[0].lower()
        subargs = parts[1] if len(parts) > 1 else ""

        match subcmd:
            case "list":
                await self._model_list(conversation)
            case "use":
                if not subargs:
                    conversation.mount(SystemMessage("Usage: /model use <model-name>"))
                else:
                    await self._model_use(subargs.strip(), conversation)
            case "switch":
                await self._model_switch_command(subargs.strip(), conversation)
            case "local":
                await self._model_switch_local(conversation)
            case "default":
                if not subargs:
                    conversation.mount(SystemMessage("Usage: /model default <model-name>"))
                else:
                    self._model_set_default(subargs.strip(), conversation)
            case "download":
                await self._model_download_command(subargs.strip(), conversation)
            case _:
                conversation.mount(
                    SystemMessage(
                        "Unknown subcommand. Usage:\n"
                        "  /model            — show current info\n"
                        "  /model list       — list remote models\n"
                        "  /model use <n>    — switch to remote model\n"
                        "  /model switch     — switch local model\n"
                        "  /model local      — switch to local model\n"
                        "  /model default <n> — set default model\n"
                        "  /model download   — download a bundled model tier"
                    )
                )

    def _get_remote_base_url(self) -> str | None:
        """Find the remote base URL from config or current engine."""
        return get_remote_base_url(self._config, self.agent.engine.engine_info())

    def _show_model_info(self, conversation: ScrollableContainer) -> None:
        """Show current model/engine information."""
        info = self.agent.engine.engine_info()
        text = format_model_info(info, self._config)
        conversation.mount(SystemMessage(text))

    async def _model_list(self, conversation: ScrollableContainer) -> None:
        """Ping server and list available models."""
        base_url = self._get_remote_base_url()
        if not base_url:
            conversation.mount(
                SystemMessage(
                    "No remote server configured.\n"
                    "Set [ollama] url in ~/.config/natshell/config.toml\n"
                    "or use --remote <url> at startup."
                )
            )
            return

        conversation.mount(SystemMessage(f"Checking {base_url}..."))

        reachable, models, error = await fetch_model_list(base_url)
        if not reachable or models is None:
            conversation.mount(SystemMessage(error or "Unknown error"))
            return

        current_info = self.agent.engine.engine_info()
        conversation.mount(
            SystemMessage(format_model_list(models, current_info.model_name))
        )

    async def _model_use(self, model_name: str, conversation: ScrollableContainer) -> None:
        """Switch to a remote model."""
        from natshell.inference.ollama import ping_server
        from natshell.inference.remote import RemoteEngine

        base_url = self._get_remote_base_url()
        if not base_url:
            conversation.mount(
                SystemMessage("No remote server configured. Set [ollama] url in config.")
            )
            return

        reachable = await ping_server(base_url)
        if not reachable:
            conversation.mount(SystemMessage(f"[red]Cannot reach server at {base_url}[/]"))
            return

        api_url, n_ctx = await prepare_remote_engine_params(
            model_name, base_url, self._config
        )
        new_engine = RemoteEngine(base_url=api_url, model=model_name, n_ctx=n_ctx)
        await self.agent.swap_engine(new_engine)
        save_engine_preference("remote")
        save_ollama_default(model_name, url=base_url)
        conversation.mount(
            SystemMessage(
                f"Switched to [bold]{model_name}[/] on {base_url}\n"
                "[dim]Conversation history cleared.[/]"
            )
        )

    async def _switch_to_remote_api(
        self,
        base_url: str,
        model: str,
        api_key: str,
        n_ctx: int,
        conversation: ScrollableContainer,
    ) -> None:
        """Switch to a remote OpenAI-compatible API (non-Ollama)."""
        from natshell.inference.remote import RemoteEngine

        # Use profile api_key, fall back to config, then env var
        key = api_key or self._config.remote.api_key
        if not key:
            import os
            key = os.environ.get("NATSHELL_API_KEY", "")

        new_engine = RemoteEngine(
            base_url=base_url, model=model, api_key=key, n_ctx=n_ctx,
        )
        await self.agent.swap_engine(new_engine)
        save_engine_preference("remote")
        conversation.mount(
            SystemMessage(
                f"Switched to [bold]{model}[/] on {base_url}\n"
                "[dim]Conversation history cleared.[/]"
            )
        )

    async def _model_switch_local(self, conversation: ScrollableContainer) -> None:
        """Switch back to the local model."""
        info = self.agent.engine.engine_info()
        if info.engine_type == "local":
            conversation.mount(SystemMessage("Already using the local model."))
            return

        model_path = resolve_local_model_path(self._config)

        if not Path(model_path).exists():
            conversation.mount(
                SystemMessage(
                    f"[red]Local model not found at {model_path}[/]\n"
                    "Run natshell --download to fetch it."
                )
            )
            return

        conversation.mount(SystemMessage("Loading local model..."))

        from natshell.inference.local import LocalEngine

        mc = self._config.model
        try:
            engine = await asyncio.to_thread(
                LocalEngine,
                model_path=model_path,
                n_ctx=mc.n_ctx,
                n_threads=mc.n_threads,
                n_gpu_layers=mc.n_gpu_layers,
                main_gpu=mc.main_gpu,
                prompt_cache=mc.prompt_cache,
                prompt_cache_mb=mc.prompt_cache_mb,
            )
            await self.agent.swap_engine(engine)
            save_engine_preference("local")
            conversation.mount(
                SystemMessage(
                    f"Switched to local model: [bold]{Path(model_path).name}[/]\n"
                    "[dim]Conversation history cleared.[/]"
                )
            )
        except Exception as e:
            conversation.mount(SystemMessage(f"[red]Failed to load local model: {e}[/]"))

    async def _model_switch_command(self, args: str, conversation: ScrollableContainer) -> None:
        """Handle /model switch [filename]."""
        if not MODELS_DIR.is_dir():
            conversation.mount(
                SystemMessage(
                    f"No models directory found at {MODELS_DIR}\n"
                    "Run natshell --download to fetch a model."
                )
            )
            return

        available = sorted(MODELS_DIR.glob("*.gguf"))
        if not available:
            conversation.mount(
                SystemMessage("No .gguf models found. Run natshell --download to fetch one.")
            )
            return

        if not args:
            current = self.agent.engine.engine_info().model_name
            conversation.mount(
                SystemMessage(format_local_models(available, current))
            )
            return

        target = find_local_model(args, available)
        if not target:
            conversation.mount(
                SystemMessage(
                    f"Model not found: {args}\nUse /model switch to list available models."
                )
            )
            return

        await self.switch_local_model(str(target))

    async def _model_download_command(
        self, args: str, conversation: ScrollableContainer
    ) -> None:
        """Handle /model download [tier]."""
        if not args:
            conversation.mount(SystemMessage(format_download_menu()))
            return

        tier_key = args.lower()
        if tier_key not in BUNDLED_TIERS:
            conversation.mount(
                SystemMessage(
                    f"Unknown tier '{args}'. "
                    f"Valid tiers: {', '.join(BUNDLED_TIERS)}"
                )
            )
            return

        tier = BUNDLED_TIERS[tier_key]
        conversation.mount(
            SystemMessage(f"Downloading {tier['name']} ({tier['description']})...")
        )
        conversation.scroll_end()

        try:
            model_path = await download_bundled_model(tier_key)
        except RuntimeError as e:
            conversation.mount(SystemMessage(f"[red]{e}[/]"))
            return

        # Persist and switch to the downloaded model
        save_model_config(tier["hf_repo"], tier["hf_file"])
        save_engine_preference("local")
        self._config.model.hf_repo = tier["hf_repo"]
        self._config.model.hf_file = tier["hf_file"]

        conversation.mount(
            SystemMessage(
                f"[green]Downloaded {tier['name']}[/] — {tier['hf_file']}\n"
                f"Switching to {tier['name']}..."
            )
        )

        await self.switch_local_model(str(model_path))

    async def switch_local_model(self, model_path: str) -> None:
        """Switch to a different local .gguf model (used by command palette and /model switch)."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        name = Path(model_path).name
        conversation.mount(SystemMessage(f"Loading {name}..."))
        conversation.scroll_end()

        from natshell.inference.local import LocalEngine

        mc = self._config.model
        try:
            engine = await asyncio.to_thread(
                LocalEngine,
                model_path=model_path,
                n_ctx=mc.n_ctx,
                n_threads=mc.n_threads,
                n_gpu_layers=mc.n_gpu_layers,
                main_gpu=mc.main_gpu,
                prompt_cache=mc.prompt_cache,
                prompt_cache_mb=mc.prompt_cache_mb,
            )
            await self.agent.swap_engine(engine)

            # Derive hf_repo/hf_file and persist to config
            # hf_file is the filename; hf_repo we keep as current config value
            hf_file = name
            hf_repo = mc.hf_repo
            save_model_config(hf_repo, hf_file)
            save_engine_preference("local")
            mc.hf_file = hf_file

            conversation.mount(
                SystemMessage(f"Switched to [bold]{name}[/]\n[dim]Conversation history cleared.[/]")
            )
        except Exception as e:
            conversation.mount(SystemMessage(f"[red]Failed to load {name}: {e}[/]"))

        conversation.scroll_end()

    def _model_set_default(self, model_name: str, conversation: ScrollableContainer) -> None:
        """Persist the default model and remote URL to user config."""
        info = self.agent.engine.engine_info()
        text = set_default_model(model_name, self._config, info)
        conversation.mount(SystemMessage(text))

    # ─── /profile ──────────────────────────────────────────────────────

    async def _handle_profile_command(
        self, args: str, conversation: ScrollableContainer
    ) -> None:
        """Dispatch /profile subcommands."""
        name = args.strip()

        if not name:
            # List available profiles
            names = list_profiles(self._config)
            if not names:
                conversation.mount(
                    SystemMessage(
                        "No profiles configured.\n"
                        "Add [profiles.<name>] sections to "
                        "~/.config/natshell/config.toml"
                    )
                )
                return
            lines = ["[bold]Available Profiles[/]\n"]
            for n in names:
                p = self._config.profiles[n]
                # Build a short summary of what the profile sets
                parts: list[str] = []
                if p.ollama_model:
                    parts.append(p.ollama_model)
                elif p.remote_model:
                    parts.append(p.remote_model)
                if p.engine:
                    parts.append(f"engine={p.engine}")
                if p.n_ctx:
                    parts.append(f"n_ctx={p.n_ctx}")
                summary = ", ".join(parts) if parts else "(empty)"
                lines.append(f"  [bold cyan]{n}[/]  [dim]{summary}[/]")
            lines.append("\n[dim]Use /profile <name> to apply.[/]")
            conversation.mount(SystemMessage("\n".join(lines)))
            return

        # Apply a named profile
        try:
            apply_profile(self._config, name)
        except KeyError:
            available = ", ".join(list_profiles(self._config)) or "(none)"
            conversation.mount(
                SystemMessage(
                    f"Unknown profile: [bold]{_escape(name)}[/]\n"
                    f"Available: {available}"
                )
            )
            return

        profile = self._config.profiles[name]

        # Swap engine if the profile specifies a remote model
        if profile.ollama_model:
            await self._model_use(profile.ollama_model, conversation)
        elif profile.remote_model and profile.remote_url:
            await self._switch_to_remote_api(
                profile.remote_url, profile.remote_model,
                profile.api_key, profile.n_ctx, conversation,
            )
        elif profile.engine == "local":
            await self._model_switch_local(conversation)
        else:
            # No engine swap needed — just report the change
            parts: list[str] = []
            if profile.n_ctx:
                parts.append(f"n_ctx={profile.n_ctx}")
            if profile.temperature:
                parts.append(f"temperature={profile.temperature}")
            if profile.n_gpu_layers != -2:
                parts.append(f"n_gpu_layers={profile.n_gpu_layers}")
            detail = ", ".join(parts) if parts else "applied"
            conversation.mount(
                SystemMessage(
                    f"Profile [bold]{_escape(name)}[/] applied ({detail})"
                )
            )

    def _show_history_info(self, conversation: ScrollableContainer) -> None:
        """Show conversation context size and context window usage."""
        show_history_info(self.agent, conversation)

    def _handle_memory(self, args: str, conversation: ScrollableContainer) -> None:
        """Handle /memory subcommands."""
        show_memory(self.agent, conversation, args)

    def _handle_skills(self, args: str, conversation: ScrollableContainer) -> None:
        """Handle /skills subcommands."""
        show_skills(self._skill_registry, conversation, args, self._config)

    def _handle_undo(self, conversation: ScrollableContainer) -> None:
        """Undo the last file edit or write by restoring from backup."""
        handle_undo(conversation)

    # ─── /save, /load, /sessions ─────────────────────────────────────────

    def _handle_save(self, args: str, conversation: ScrollableContainer) -> None:
        """Save current conversation to a session file."""
        name = args.strip()
        info = self.agent.engine.engine_info()
        engine_dict = {
            "engine_type": info.engine_type,
            "model_name": info.model_name,
            "base_url": info.base_url,
            "n_ctx": info.n_ctx,
        }
        sid = self._session_mgr.save(
            messages=self.agent.messages,
            engine_info=engine_dict,
            name=name,
        )
        display_name = name or sid[:12]
        conversation.mount(
            SystemMessage(f"Session saved: [bold]{_escape(display_name)}[/]\nID: {sid}")
        )

    def _handle_load(self, args: str, conversation: ScrollableContainer) -> None:
        """Load a saved session, or list sessions if no ID given."""
        session_id = args.strip()
        if not session_id:
            self._handle_sessions(conversation)
            return

        try:
            data = self._session_mgr.load(session_id)
        except AmbiguousSessionID as exc:
            shown = ", ".join(c[:12] for c in exc.candidates[:5])
            if len(exc.candidates) > 5:
                shown += ", …"
            conversation.mount(
                SystemMessage(
                    f"Ambiguous session ID: [bold]{_escape(session_id)}[/]\n"
                    f"Matches {len(exc.candidates)}: {_escape(shown)}\n"
                    "Use more characters to disambiguate."
                )
            )
            return
        except ValueError:
            conversation.mount(
                SystemMessage(
                    f"Invalid session ID: [bold]{_escape(session_id)}[/]\n"
                    "Expected lowercase hex (at least 4 chars). "
                    "Run /sessions to see valid IDs."
                )
            )
            return

        if data is None:
            conversation.mount(
                SystemMessage(f"Session not found: {_escape(session_id)}")
            )
            return

        self.agent.messages = data["messages"]
        name = data.get("name", session_id)
        msg_count = len(data["messages"])
        conversation.mount(
            SystemMessage(
                f"Loaded session: [bold]{_escape(name)}[/]\n"
                f"Messages restored: {msg_count}"
            )
        )

    def _handle_sessions(self, conversation: ScrollableContainer) -> None:
        """List all saved sessions."""
        sessions = self._session_mgr.list_sessions()
        if not sessions:
            conversation.mount(SystemMessage("No saved sessions."))
            return

        lines = ["[bold]Saved Sessions[/]\n"]
        for s in sessions:
            name = s["name"] or "(unnamed)"
            msg_count = s["message_count"]
            updated = s["updated"][:19].replace("T", " ")  # trim to readable
            lines.append(
                f"  [bold cyan]{s['id'][:12]}[/]  "
                f"{_escape(name)}  "
                f"[dim]({msg_count} msgs, {updated})[/]"
            )
        lines.append(
            "\n[dim]Use /load <id> to restore — the 12-char prefix shown "
            "above is enough.[/]"
        )
        conversation.mount(SystemMessage("\n".join(lines)))

    def on_mouse_up(self, event: MouseUp) -> None:
        """Copy selected text to clipboard on right-click."""
        if event.button == 3:
            selected = self.screen.get_selected_text()
            if selected:
                if clipboard.copy(selected, self):
                    self.notify("Copied to clipboard", timeout=2)
                else:
                    self.notify(
                        "Copy failed — no clipboard tool found", severity="error", timeout=3
                    )

    def action_copy_selection(self) -> None:
        """Copy selected text to clipboard (Ctrl+C)."""
        selected = self.screen.get_selected_text()
        if selected:
            if clipboard.copy(selected, self):
                self.notify("Copied to clipboard", timeout=2)
                self.clear_selection()
            else:
                self.notify("Copy failed — no clipboard tool found", severity="error", timeout=3)

    def action_copy_chat(self) -> None:
        """Copy the entire chat conversation to clipboard."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        parts = []
        for child in conversation.children:
            if hasattr(child, "copyable_text"):
                parts.append(child.copyable_text)
        if parts:
            text = "\n\n".join(parts)
            if clipboard.copy(text, self):
                self.notify("Chat copied!", timeout=2)
            else:
                self.notify("Copy failed — no clipboard tool found", severity="error", timeout=3)
        else:
            self.notify("Nothing to copy", timeout=2)

    @on(Button.Pressed, "#quit-btn")
    def on_quit_btn(self) -> None:
        self._confirm_quit()

    @work(exclusive=True, thread=False)
    async def _confirm_quit(self) -> None:
        was_busy = self._busy
        confirmed = await self.push_screen_wait(QuitConfirmScreen(was_busy=was_busy))
        if confirmed:
            if was_busy:
                self.workers.cancel_all()
            self.exit()

    @on(Button.Pressed, "#copy-chat-btn")
    def on_copy_chat_btn(self) -> None:
        self.action_copy_chat()

    @on(Button.Pressed, "#paste-btn")
    def on_paste_btn(self) -> None:
        content = clipboard.read()
        if content is None:
            self.notify(
                "Cannot read clipboard — no paste tool available", severity="error", timeout=3
            )
            return
        if not content.strip():
            self.notify("Clipboard is empty", timeout=2)
            return
        input_widget = self.query_one("#user-input", HistoryInput)
        input_widget.insert_from_clipboard(content)
        input_widget.focus()

    def action_clear_chat(self) -> None:
        """Clear the conversation and agent history."""
        conversation = self.query_one("#conversation", ScrollableContainer)
        conversation.remove_children()
        conversation.mount(Static("[dim]Chat cleared. Type a new request.[/]\n"))
        self.agent.clear_history()
        self.query_one("#user-input", HistoryInput).clear_history()

    def _compact_chat(self, conversation: ScrollableContainer) -> None:
        """Compact conversation context, keeping key facts."""
        compact_chat(self.agent, conversation)
