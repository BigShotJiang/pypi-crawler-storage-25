"""
CB Dominus SDK - Ultra-flat async SDK for CareBridge Services

Namespace-first API:
    from dominus import dominus

    # Secrets namespace
    value = await dominus.secrets.get("DB_URL")
    await dominus.secrets.upsert("KEY", "value")

    # Database (namespace-based)
    tables = await dominus.db.tables()
    rows = await dominus.db.query("users", filters={"status": "active"})
    await dominus.db.insert("users", {"name": "John"})

    # Auth (namespace-based)
    users = await dominus.auth.list_users()
    await dominus.auth.create_user(username="john", email="j@ex.com", password="secret")

    # DDL (namespace-based)
    await dominus.ddl.create_table("public", "users", [{"name": "id", "type": "UUID"}])

    # Files (namespace-based)
    result = await dominus.files.upload(data=file_bytes, filename="report.pdf", category="reports")

    # Redis caching
    await dominus.redis.set("key", "value", ttl=3600)
    value = await dominus.redis.get("key")

    # Logging
    await dominus.logs.info("Operation complete", {"user_id": user_id})

    # Email
    await dominus.courier.send("welcome", to="user@example.com", from_email="hello@app.com", model={})

    # Secure table access with audit logging
    rows = await dominus.secure.query("patients", context=SecureAccessContext(
        reason="Reviewing chart",
        actor=user_id
    ))

    # Admin operations
    await dominus.admin.reseed_admin_category()

    # Portal authentication
    session = await dominus.portal.login("user@example.com", "password", "tenant-id")

    # Health
    status = await dominus.health.check()

Flat shortcuts remain for common gateway-backed secrets and DB operations:
    value = await dominus.get("DB_URL")
    await dominus.upsert("KEY", "value")

Supported string commands:
    result = await dominus("secrets.get", key="DB_URL")
    await dominus("sql.app.list_tables", schema="public")

Crypto Helpers:
    from dominus import hash_password, hash_psk, generate_token
    hashed = hash_password("secret")
"""
from .start import dominus, Dominus
from .helpers.core import DominusResponse

# Export crypto helpers
from .helpers.crypto import (
    hash_password,
    verify_password,
    hash_psk,
    verify_psk,
    generate_psk_local,
    hash_token,
    generate_token,
)

# Export namespace classes for type hints
from .namespaces.db import DbNamespace
from .namespaces.auth import AuthNamespace
from .namespaces.ddl import DdlNamespace
from .namespaces.files import FilesNamespace
from .namespaces.portal import PortalNamespace
from .namespaces.admin import AdminNamespace
from .namespaces.secure import SecureNamespace, SecureAccessContext
from .namespaces.secrets import SecretsNamespace
from .namespaces.redis import RedisNamespace
from .namespaces.logs import LogsNamespace
from .namespaces.courier import CourierNamespace
from .namespaces.health import HealthNamespace
# Export new namespaces (Node.js SDK parity)
from .namespaces.artifacts import (
    ARTIFACT_REF_PREFIX,
    DISPLAY_REF_PREFIX,
    ARTIFACT_ENVIRONMENTS,
    ArtifactsNamespace,
    build_artifact_ref,
    build_v2_artifact_ref,
    build_pinned_artifact_ref,
    build_legacy_artifact_ref,
    build_display_artifact_ref,
    parse_artifact_ref,
    try_parse_artifact_ref,
    validate_artifact_address,
    is_artifact_ref,
    is_pinned_artifact_ref,
    is_head_artifact_ref,
    is_legacy_artifact_ref,
    is_display_artifact_ref,
)
from .namespaces.jobs import JobsNamespace
from .namespaces.processor import ProcessorNamespace
from .namespaces.sync import SyncNamespace
from .namespaces.authority import AuthorityNamespace
from .namespaces.deployer import DeployerNamespace
from .namespaces.warden import WardenNamespace

# Export AI namespace for agent-runtime operations
from .namespaces.ai import (
    AiNamespace,
    RagSubNamespace,
    ArtifactsSubNamespace,
    ResultsSubNamespace,
    WorkflowSubNamespace,
)

# Export cache and resilience utilities
from .helpers.cache import (
    dominus_cache,
    CircuitBreaker,
    DominusCache,
    gateway_circuit_breaker,
    exponential_backoff_with_jitter,
)

# Export JWT verification utilities
from .helpers.core import (
    verify_jwt_locally,
    is_jwt_valid,
    mint_selected_scope_jwt,
)

# Export trace utilities for distributed tracing
from .helpers.trace import (
    generate_trace_id,
    get_current_trace_id,
    get_current_span_id,
    start_trace,
    end_trace,
    with_trace,
)

# Export error classes
from .errors import (
    DominusError,
    AuthenticationError,
    AuthorizationError,
    NotFoundError,
    ValidationError,
    ConflictError,
    ServiceError,
    SecureTableError,
    ConnectionError as DominusConnectionError,
    TimeoutError as DominusTimeoutError,
)

__version__ = "4.0.5"
__all__ = [
    # Main SDK instance
    "dominus",
    "Dominus",
    "DominusResponse",
    # Crypto helpers
    "hash_password",
    "verify_password",
    "hash_psk",
    "verify_psk",
    "generate_psk_local",
    "hash_token",
    "generate_token",
    # Namespace classes (for type hints)
    "DbNamespace",
    "AuthNamespace",
    "DdlNamespace",
    "FilesNamespace",
    "PortalNamespace",
    "AdminNamespace",
    "SecureNamespace",
    "SecureAccessContext",
    "SecretsNamespace",
    "RedisNamespace",
    "LogsNamespace",
    "CourierNamespace",
    "HealthNamespace",
    # New namespaces (Node.js SDK parity)
    "ARTIFACT_REF_PREFIX",
    "DISPLAY_REF_PREFIX",
    "ARTIFACT_ENVIRONMENTS",
    "ArtifactsNamespace",
    "build_artifact_ref",
    "build_v2_artifact_ref",
    "build_pinned_artifact_ref",
    "build_legacy_artifact_ref",
    "build_display_artifact_ref",
    "parse_artifact_ref",
    "try_parse_artifact_ref",
    "validate_artifact_address",
    "is_artifact_ref",
    "is_pinned_artifact_ref",
    "is_head_artifact_ref",
    "is_legacy_artifact_ref",
    "is_display_artifact_ref",
    "JobsNamespace",
    "ProcessorNamespace",
    "SyncNamespace",
    "AuthorityNamespace",
    "DeployerNamespace",
    "WardenNamespace",
    # AI namespace for agent-runtime operations
    "AiNamespace",
    "RagSubNamespace",
    "ArtifactsSubNamespace",
    "ResultsSubNamespace",
    "WorkflowSubNamespace",
    # Cache and resilience utilities
    "dominus_cache",
    "CircuitBreaker",
    "DominusCache",
    "gateway_circuit_breaker",
    "exponential_backoff_with_jitter",
    # JWT verification utilities
    "verify_jwt_locally",
    "is_jwt_valid",
    "mint_selected_scope_jwt",
    # Trace utilities
    "generate_trace_id",
    "get_current_trace_id",
    "get_current_span_id",
    "start_trace",
    "end_trace",
    "with_trace",
    # Error classes
    "DominusError",
    "AuthenticationError",
    "AuthorizationError",
    "NotFoundError",
    "ValidationError",
    "ConflictError",
    "ServiceError",
    "SecureTableError",
    "DominusConnectionError",
    "DominusTimeoutError",
]
