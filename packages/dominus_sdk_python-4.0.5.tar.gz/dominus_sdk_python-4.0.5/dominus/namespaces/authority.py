"""
Authority Namespace - Dominus Authority service surface.

Canonical SDK entry point for the dominus-authority service. Mirrors the MCP
``authority_*`` tool surface so application code can drive runs, companies,
deploys, managed clients, timelines, dossiers, and Authority context resolution
without touching workflow-manager / client-worker / deploy-worker routes
directly.

All methods route through the gateway (``use_gateway=True``) which maps
``/api/authority/*`` -> ``/svc/authority/*`` upstream to dominus-authority.

Run launch is also exposed as ``dominus.workflow.ensure(...)``. Both call
``/api/authority/runs/ensure``. Use ``dominus.workflow.ensure`` for the
canonical "launch a saved workflow" path; use ``dominus.authority.ensure_run``
when you want to think in Authority terms (run lifecycle, run dossiers,
retries, cancels).
"""
from __future__ import annotations

from typing import Any, Dict, Mapping, Optional, TYPE_CHECKING
from urllib.parse import quote, urlencode

if TYPE_CHECKING:
    from ..start import Dominus


def _compact(payload: Mapping[str, Any]) -> Dict[str, Any]:
    """Drop None and empty-string values."""
    out: Dict[str, Any] = {}
    for k, v in payload.items():
        if v is None:
            continue
        if isinstance(v, str) and v == "":
            continue
        out[k] = v
    return out


def _normalize_run_kind_token(raw: Optional[str]) -> str:
    if not raw:
        return ""
    s = str(raw).strip().lower().replace(".", "_").replace("-", "_")
    return s


def _is_company_bootstrap_run_kind(run_kind: Optional[str]) -> bool:
    return _normalize_run_kind_token(run_kind) == "company_bootstrap"


def _query_string(params: Mapping[str, Any]) -> str:
    cleaned = {k: v for k, v in params.items() if v is not None and v != ""}
    if not cleaned:
        return ""
    return "?" + urlencode({k: str(v) for k, v in cleaned.items()})


class AuthorityNamespace:
    """
    Authority service namespace.

    Usage::

        await dominus.authority.ensure_run(workflow_id="...", subject="PCM47474562")
        await dominus.authority.list_companies()
        await dominus.authority.get_run_dossier(run_id)
    """

    def __init__(self, client: "Dominus"):
        self._client = client

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _post(
        self,
        endpoint: str,
        body: Optional[Dict[str, Any]] = None,
        *,
        timeout: float = 30.0,
    ) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=endpoint,
            method="POST",
            body=body or {},
            use_gateway=True,
            timeout=timeout,
        )

    async def _get(self, endpoint: str, *, timeout: float = 30.0) -> Dict[str, Any]:
        return await self._client._request(
            endpoint=endpoint,
            method="GET",
            use_gateway=True,
            timeout=timeout,
        )

    @staticmethod
    def _initiator(
        initiator_type: Optional[str],
        initiator_id: Optional[str],
        idempotency_key: Optional[str],
    ) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        if initiator_type:
            out["initiator_type"] = initiator_type
        if initiator_id:
            out["initiator_id"] = initiator_id
        if idempotency_key:
            out["idempotency_key"] = idempotency_key
        return out

    @staticmethod
    def _scope(
        app_slug: Optional[str],
        env: Optional[str],
        target_org_id: Optional[str],
        target_env: Optional[str],
        target_app_slug: Optional[str] = None,
        shared_app_slug: Optional[str] = None,
    ) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        if app_slug:
            out["app_slug"] = app_slug
        if env:
            out["env"] = env
        if target_org_id:
            out["target_org_id"] = target_org_id
        if target_app_slug:
            out["target_app_slug"] = target_app_slug
        if target_env:
            out["target_env"] = target_env
        if shared_app_slug:
            out["shared_app_slug"] = shared_app_slug
        return out

    def _target_query_params(
        self,
        target_org_id: Optional[str],
        target_env: Optional[str],
    ) -> tuple[Optional[str], Optional[str]]:
        """
        Omit target_org_id / target_env from GET query strings when they
        duplicate the JWT gateway org/env (selected-scope MCP and operators).
        """
        client = self._client
        gw_org = getattr(client, "_gateway_org_id", None)
        gw_env = getattr(client, "_gateway_env", None)
        tid = target_org_id
        tev = target_env
        if tid is not None and gw_org is not None and str(tid) == str(gw_org):
            tid = None
        if tev is not None and gw_env is not None and str(tev) == str(gw_env):
            tev = None
        return tid, tev

    @staticmethod
    def _http_timeout(explicit: Optional[float], default: float) -> float:
        """Use explicit client timeout when provided; otherwise the historical SDK default."""
        return default if explicit is None else explicit

    # ==================================================================
    # Runs
    # ==================================================================

    async def ensure_run(
        self,
        *,
        workflow_id: Optional[str] = None,
        workflow_ref: Optional[str] = None,
        run_kind: Optional[str] = None,
        bootstrap_profile: Optional[str] = None,
        company_slug: Optional[str] = None,
        slug: Optional[str] = None,
        instance_id: Optional[str] = None,
        instance_key: Optional[str] = None,
        group: Optional[str] = None,
        owner: Optional[str] = None,
        subject: Optional[str] = None,
        company: Optional[str] = None,
        mode: str = "async",
        bindings: Optional[Dict[str, Any]] = None,
        inputs: Optional[Dict[str, Any]] = None,
        context: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        target_app_slug: Optional[str] = None,
        shared_app_slug: Optional[str] = None,
        execution_mode: Optional[str] = None,
        region: Optional[str] = None,
        system: Optional[str] = None,
        github_mode: Optional[str] = None,
        overwrite_existing: Optional[bool] = None,
        owner_email: Optional[str] = None,
        include: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Ensure (and optionally launch) an Authority-backed workflow run.

        Calls ``POST /api/authority/runs/ensure``.

        For company bootstrap, pass ``run_kind="company.bootstrap"`` (or ``company_bootstrap``) plus
        ``company``, ``company_slug``, or ``slug``. Optional bootstrap fields mirror
        ``bootstrap_company`` (``execution_mode``, ``region``, ``bootstrap_profile``, …).
        """
        bootstrap = _is_company_bootstrap_run_kind(run_kind)
        if not bootstrap and not workflow_id and not workflow_ref:
            raise ValueError(
                "ensure_run requires workflow_id or workflow_ref unless run_kind is "
                "company.bootstrap / company_bootstrap"
            )
        if bootstrap:
            co = (company_slug or slug or company or "").strip()
            if not co:
                raise ValueError(
                    "ensure_run with run_kind company.bootstrap requires company, company_slug, or slug"
                )
        if mode == "streaming":
            raise ValueError(
                "Authority runs do not support streaming mode; "
                "use blocking, async, or ensure_only"
            )

        initiator = self._initiator(initiator_type, initiator_id, idempotency_key)
        scope = self._scope(app_slug, env, target_org_id, target_env, target_app_slug=target_app_slug)

        if bootstrap:
            body = _compact({
                "run_kind": run_kind,
                "bootstrap_profile": bootstrap_profile,
                "workflow_id": workflow_id,
                "workflow_ref": workflow_ref,
                "instance_id": instance_id,
                "instance_key": instance_key,
                "group": group,
                "owner": owner,
                "subject": subject,
                "company": company,
                "company_slug": company_slug,
                "slug": slug,
                "bindings": bindings,
                "inputs": inputs,
                "context": context,
                "execution_mode": execution_mode,
                "region": region,
                "system": system,
                "github_mode": github_mode,
                "overwrite_existing": overwrite_existing,
                "owner_email": owner_email,
                "include": include,
                "metadata": metadata,
                "display_name": display_name,
                "description": description,
                "shared_app_slug": shared_app_slug,
                **initiator,
                **scope,
            })
        else:
            body = _compact({
                "workflow_id": workflow_id,
                "workflow_ref": workflow_ref,
                "bootstrap_profile": bootstrap_profile,
                "instance_id": instance_id,
                "instance_key": instance_key,
                "group": group,
                "owner": owner,
                "subject": subject,
                "company": company,
                "mode": mode,
                "bindings": bindings,
                "inputs": inputs,
                "context": context,
                **initiator,
                **scope,
            })
        return await self._post(
            "/api/authority/runs/ensure",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def get_run(self, run_id: str, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        """Get an Authority-backed run by id. ``GET /api/authority/runs/{run_id}``."""
        if not run_id:
            raise ValueError("run_id is required")
        return await self._get(
            f"/api/authority/runs/{quote(run_id, safe='')}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def list_runs(
        self,
        *,
        workflow_id: Optional[str] = None,
        status: Optional[str] = None,
        group: Optional[str] = None,
        owner: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """List Authority-backed runs. ``GET /api/authority/runs``."""
        tid, tev = self._target_query_params(target_org_id, target_env)
        qs = _query_string({
            "workflow_id": workflow_id,
            "status": status,
            "group": group,
            "owner": owner,
            "app_slug": app_slug,
            "env": env,
            "target_org_id": tid,
            "target_env": tev,
            "limit": limit,
            "offset": offset,
        })
        return await self._get(
            f"/api/authority/runs{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def cancel_run(
        self,
        run_id: str,
        *,
        reason: Optional[str] = None,
        mode: Optional[str] = None,
        execution_mode: Optional[str] = None,
        company: Optional[str] = None,
        subject: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Cancel an Authority-backed run. ``POST /api/authority/runs/{run_id}/cancel``."""
        if not run_id:
            raise ValueError("run_id is required")
        body = _compact({
            "reason": reason,
            "mode": mode,
            "execution_mode": execution_mode,
            "company": company,
            "subject": subject,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, target_org_id, target_env),
        })
        return await self._post(
            f"/api/authority/runs/{quote(run_id, safe='')}/cancel",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def retry_run(
        self,
        run_id: str,
        *,
        reason: Optional[str] = None,
        mode: Optional[str] = None,
        trigger_artifact: Optional[str] = None,
        company: Optional[str] = None,
        subject: Optional[str] = None,
        branch: Optional[str] = None,
        sha: Optional[str] = None,
        service_type: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Retry an Authority-backed run. ``POST /api/authority/runs/{run_id}/retry``."""
        if not run_id:
            raise ValueError("run_id is required")
        body = _compact({
            "reason": reason,
            "mode": mode,
            "trigger_artifact": trigger_artifact,
            "company": company,
            "subject": subject,
            "branch": branch,
            "sha": sha,
            "service_type": service_type,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, target_org_id, target_env),
        })
        return await self._post(
            f"/api/authority/runs/{quote(run_id, safe='')}/retry",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def nudge_run(
        self,
        run_id: str,
        *,
        reason: Optional[str] = None,
        mode: Optional[str] = None,
        trigger_artifact: Optional[str] = None,
        company: Optional[str] = None,
        subject: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Nudge an Authority-backed run. ``POST /api/authority/runs/{run_id}/nudge``."""
        if not run_id:
            raise ValueError("run_id is required")
        body = _compact({
            "reason": reason,
            "mode": mode,
            "trigger_artifact": trigger_artifact,
            "company": company,
            "subject": subject,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, target_org_id, target_env),
        })
        return await self._post(
            f"/api/authority/runs/{quote(run_id, safe='')}/nudge",
            body,
        )

    async def get_run_timeline(
        self,
        run_id: str,
        *,
        since: Optional[str] = None,
        until: Optional[str] = None,
        window_hours: Optional[int] = None,
        limit: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get run state-transition timeline. ``GET /api/authority/runs/{run_id}/timeline``."""
        if not run_id:
            raise ValueError("run_id is required")
        qs = _query_string({
            "since": since,
            "until": until,
            "window_hours": window_hours,
            "limit": limit,
        })
        return await self._get(
            f"/api/authority/runs/{quote(run_id, safe='')}/timeline{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def get_run_dossier(
        self,
        run_id: str,
        *,
        since: Optional[str] = None,
        until: Optional[str] = None,
        window_hours: Optional[int] = None,
        limit: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get the full Authority dossier for a run. ``GET /api/authority/dossiers/run/{run_id}``."""
        if not run_id:
            raise ValueError("run_id is required")
        qs = _query_string({
            "since": since,
            "until": until,
            "window_hours": window_hours,
            "limit": limit,
        })
        return await self._get(
            f"/api/authority/dossiers/run/{quote(run_id, safe='')}{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    # ==================================================================
    # Workflows (publication / bindings)
    # ==================================================================

    async def publish_workflow(
        self,
        *,
        name: Optional[str] = None,
        yaml_content: Optional[str] = None,
        workflow_ref: Optional[str] = None,
        workflow_id: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[Any] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_app_slug: Optional[str] = None,
        target_env: Optional[str] = None,
        shared_app_slug: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Publish a workflow to the Authority registry. ``POST /api/authority/workflows/publish``."""
        body = _compact({
            "name": name,
            "yaml_content": yaml_content,
            "workflow_ref": workflow_ref,
            "workflow_id": workflow_id,
            "description": description,
            "tags": tags,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(
                app_slug,
                env,
                target_org_id,
                target_env,
                target_app_slug=target_app_slug,
                shared_app_slug=shared_app_slug,
            ),
        })
        return await self._post(
            "/api/authority/workflows/publish",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def list_bindings(
        self,
        *,
        source_workflow_ref: Optional[str] = None,
        workflow_type: Optional[str] = None,
        company_slug: Optional[str] = None,
        status: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_app_slug: Optional[str] = None,
        target_env: Optional[str] = None,
        shared_app_slug: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """List Authority workflow bindings. ``GET /api/authority/workflow-bindings``."""
        tid, tev = self._target_query_params(target_org_id, target_env)
        qs = _query_string({
            "source_workflow_ref": source_workflow_ref,
            "workflow_type": workflow_type,
            "company_slug": company_slug,
            "status": status,
            "app_slug": app_slug,
            "env": env,
            "target_org_id": tid,
            "target_app_slug": target_app_slug,
            "target_env": tev,
            "shared_app_slug": shared_app_slug,
            "limit": limit,
            "offset": offset,
        })
        return await self._get(
            f"/api/authority/workflow-bindings{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def list_publications(
        self,
        *,
        publication_id: Optional[str] = None,
        binding_id: Optional[str] = None,
        source_workflow_ref: Optional[str] = None,
        workflow_type: Optional[str] = None,
        company_slug: Optional[str] = None,
        status: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_app_slug: Optional[str] = None,
        target_env: Optional[str] = None,
        shared_app_slug: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """List Authority workflow publications. ``GET /api/authority/workflow-publications``."""
        tid, tev = self._target_query_params(target_org_id, target_env)
        qs = _query_string({
            "publication_id": publication_id,
            "binding_id": binding_id,
            "source_workflow_ref": source_workflow_ref,
            "workflow_type": workflow_type,
            "company_slug": company_slug,
            "status": status,
            "app_slug": app_slug,
            "env": env,
            "target_org_id": tid,
            "target_app_slug": target_app_slug,
            "target_env": tev,
            "shared_app_slug": shared_app_slug,
            "limit": limit,
            "offset": offset,
        })
        return await self._get(
            f"/api/authority/workflow-publications{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def create_workflow_binding(
        self,
        *,
        company_slug: str,
        workflow_type: str,
        source_workflow_id: str,
        target_workflow_id: str,
        source_workflow_ref: Optional[str] = None,
        source_org_id: Optional[str] = None,
        source_version: Optional[int] = None,
        target_tenant_slug: Optional[str] = None,
        target_workflow_slug: Optional[str] = None,
        active_publication_id: Optional[str] = None,
        publication_state: Optional[str] = None,
        publication_operation: Optional[str] = None,
        source_hash: Optional[str] = None,
        target_hash: Optional[str] = None,
        drift_status: Optional[str] = None,
        drift_checked_at: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        status: Optional[str] = None,
        published_at: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_app_slug: Optional[str] = None,
        target_env: Optional[str] = None,
        shared_app_slug: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Create or update a workflow binding. ``POST /api/authority/workflow-bindings``."""
        body = _compact({
            "company_slug": company_slug,
            "workflow_type": workflow_type,
            "source_workflow_ref": source_workflow_ref,
            "source_org_id": source_org_id,
            "source_workflow_id": source_workflow_id,
            "source_version": source_version,
            "target_tenant_slug": target_tenant_slug,
            "target_workflow_slug": target_workflow_slug,
            "target_workflow_id": target_workflow_id,
            "active_publication_id": active_publication_id,
            "publication_state": publication_state,
            "publication_operation": publication_operation,
            "source_hash": source_hash,
            "target_hash": target_hash,
            "drift_status": drift_status,
            "drift_checked_at": drift_checked_at,
            "metadata": metadata,
            "status": status,
            "published_at": published_at,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(
                app_slug,
                env,
                target_org_id,
                target_env,
                target_app_slug=target_app_slug,
                shared_app_slug=shared_app_slug,
            ),
        })
        return await self._post(
            "/api/authority/workflow-bindings",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def create_workflow_publication(
        self,
        *,
        company_slug: str,
        workflow_type: str,
        source_workflow_id: str,
        target_workflow_id: str,
        source_workflow_ref: Optional[str] = None,
        source_org_id: Optional[str] = None,
        operation: Optional[str] = None,
        source_version: Optional[int] = None,
        source_hash: Optional[str] = None,
        source_name: Optional[str] = None,
        source_description: Optional[str] = None,
        source_tags: Optional[list[Any]] = None,
        source_yaml: Optional[str] = None,
        target_tenant_slug: Optional[str] = None,
        target_workflow_slug: Optional[str] = None,
        target_hash: Optional[str] = None,
        previous_publication_id: Optional[str] = None,
        rollback_of_publication_id: Optional[str] = None,
        publication_status: Optional[str] = None,
        binding_status: Optional[str] = None,
        publication_metadata: Optional[Dict[str, Any]] = None,
        binding_metadata: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        published_at: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_app_slug: Optional[str] = None,
        target_env: Optional[str] = None,
        shared_app_slug: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Create or upsert a workflow publication. ``POST /api/authority/workflow-publications``."""
        body = _compact({
            "company_slug": company_slug,
            "workflow_type": workflow_type,
            "source_workflow_ref": source_workflow_ref,
            "source_org_id": source_org_id,
            "operation": operation,
            "source_workflow_id": source_workflow_id,
            "source_version": source_version,
            "source_hash": source_hash,
            "source_name": source_name,
            "source_description": source_description,
            "source_tags": source_tags,
            "source_yaml": source_yaml,
            "target_tenant_slug": target_tenant_slug,
            "target_workflow_slug": target_workflow_slug,
            "target_workflow_id": target_workflow_id,
            "target_hash": target_hash,
            "previous_publication_id": previous_publication_id,
            "rollback_of_publication_id": rollback_of_publication_id,
            "publication_status": publication_status,
            "binding_status": binding_status,
            "publication_metadata": publication_metadata,
            "binding_metadata": binding_metadata,
            "metadata": metadata,
            "published_at": published_at,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(
                app_slug,
                env,
                target_org_id,
                target_env,
                target_app_slug=target_app_slug,
                shared_app_slug=shared_app_slug,
            ),
        })
        return await self._post(
            "/api/authority/workflow-publications",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    # ==================================================================
    # Companies
    # ==================================================================

    async def create_company(
        self,
        *,
        company_slug: str,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        bootstrap_status: Optional[str] = None,
        bootstrap_run_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Create a new company. ``POST /api/authority/companies``."""
        if not company_slug:
            raise ValueError("create_company requires company_slug")
        body = _compact({
            "company_slug": company_slug,
            "display_name": display_name,
            "description": description,
            "bootstrap_status": bootstrap_status,
            "bootstrap_run_id": bootstrap_run_id,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, target_org_id, target_env),
        })
        return await self._post(
            "/api/authority/companies",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def get_company(
        self,
        company_slug: str,
        *,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get an Authority company. ``GET /api/authority/companies/{company}``."""
        if not company_slug:
            raise ValueError("company_slug is required")
        tid, tev = self._target_query_params(target_org_id, target_env)
        qs = _query_string({
            "app_slug": app_slug,
            "env": env,
            "target_org_id": tid,
            "target_env": tev,
        })
        return await self._get(
            f"/api/authority/companies/{quote(company_slug, safe='')}{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def list_companies(
        self,
        *,
        status: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """List Authority companies. ``GET /api/authority/companies``."""
        tid, tev = self._target_query_params(target_org_id, target_env)
        qs = _query_string({
            "app_slug": app_slug,
            "env": env,
            "target_org_id": tid,
            "target_env": tev,
            "status": status,
            "limit": limit,
            "offset": offset,
        })
        return await self._get(
            f"/api/authority/companies{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def bootstrap_company(
        self,
        company_slug: str,
        *,
        action: Optional[str] = None,
        run_id: Optional[str] = None,
        reason: Optional[str] = None,
        bootstrap_profile: Optional[str] = None,
        shared_app_slug: Optional[str] = None,
        region: Optional[str] = None,
        system: Optional[str] = None,
        github_mode: Optional[str] = None,
        overwrite_existing: Optional[bool] = None,
        owner_email: Optional[str] = None,
        execution_mode: Optional[str] = None,
        include: Optional[Dict[str, Any]] = None,
        rollback_include: Optional[Dict[str, Any]] = None,
        delete_repo: Optional[bool] = None,
        metadata: Optional[Dict[str, Any]] = None,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_app_slug: Optional[str] = None,
        target_env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Trigger or replay company bootstrap. ``POST /api/authority/companies/{company}/bootstrap``."""
        if not company_slug:
            raise ValueError("company_slug is required")
        body = _compact({
            "action": action,
            "run_id": run_id,
            "reason": reason,
            "bootstrap_profile": bootstrap_profile,
            "shared_app_slug": shared_app_slug,
            "region": region,
            "system": system,
            "github_mode": github_mode,
            "overwrite_existing": overwrite_existing,
            "owner_email": owner_email,
            "execution_mode": execution_mode,
            "include": include,
            "rollback_include": rollback_include,
            "delete_repo": delete_repo,
            "metadata": metadata,
            "display_name": display_name,
            "description": description,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(
                app_slug,
                env,
                None,
                target_env,
                target_app_slug=target_app_slug,
            ),
        })
        return await self._post(
            f"/api/authority/companies/{quote(company_slug, safe='')}/bootstrap",
            body,
            timeout=self._http_timeout(timeout, 60.0),
        )

    async def get_company_bootstrap(
        self,
        company_slug: str,
        *,
        run_id: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get company bootstrap state. ``GET /api/authority/companies/{company}/bootstrap``."""
        if not company_slug:
            raise ValueError("company_slug is required")
        qs = _query_string({
            "app_slug": app_slug,
            "env": env,
            "run_id": run_id,
        })
        return await self._get(
            f"/api/authority/companies/{quote(company_slug, safe='')}/bootstrap{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def get_company_dossier(
        self,
        company_slug: str,
        *,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        window_hours: Optional[int] = None,
        limit: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get full Authority dossier for a company. ``GET /api/authority/dossiers/company/{company}``."""
        if not company_slug:
            raise ValueError("company_slug is required")
        tid, tev = self._target_query_params(target_org_id, target_env)
        qs = _query_string({
            "app_slug": app_slug,
            "env": env,
            "target_org_id": tid,
            "target_env": tev,
            "since": since,
            "until": until,
            "window_hours": window_hours,
            "limit": limit,
        })
        return await self._get(
            f"/api/authority/dossiers/company/{quote(company_slug, safe='')}{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    # ==================================================================
    # Deploys
    # ==================================================================

    async def register_deploy(
        self,
        *,
        repo_full_name: str,
        deploy_id: Optional[str] = None,
        branch: Optional[str] = None,
        sha: Optional[str] = None,
        service_type: Optional[str] = None,
        company: Optional[str] = None,
        subject: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Register a deploy. ``POST /api/authority/deploys/registrations``."""
        if not repo_full_name:
            raise ValueError("register_deploy requires repo_full_name")
        body = _compact({
            "deploy_id": deploy_id,
            "repo_full_name": repo_full_name,
            "branch": branch,
            "sha": sha,
            "service_type": service_type,
            "company": company,
            "subject": subject,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, target_org_id, target_env),
        })
        return await self._post(
            "/api/authority/deploys/registrations",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def get_deploy(self, deploy_id: str, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        """Get deploy by id. ``GET /api/authority/deploys/{deploy_id}``."""
        if not deploy_id:
            raise ValueError("deploy_id is required")
        return await self._get(
            f"/api/authority/deploys/{quote(deploy_id, safe='')}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def list_deploys(
        self,
        *,
        repo_full_name: Optional[str] = None,
        status: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        limit: int = 50,
        offset: int = 0,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """List deploys. ``GET /api/authority/deploys``."""
        tid, tev = self._target_query_params(target_org_id, target_env)
        qs = _query_string({
            "app_slug": app_slug,
            "env": env,
            "target_org_id": tid,
            "target_env": tev,
            "repo_full_name": repo_full_name,
            "status": status,
            "limit": limit,
            "offset": offset,
        })
        return await self._get(
            f"/api/authority/deploys{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def rollout_deploy(
        self,
        deploy_id: str,
        *,
        repo_full_name: Optional[str] = None,
        branch: Optional[str] = None,
        sha: Optional[str] = None,
        service_type: Optional[str] = None,
        reason: Optional[str] = None,
        company: Optional[str] = None,
        subject: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        force: Optional[bool] = None,
        allow_duplicate_sha: Optional[bool] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Trigger a rollout. ``POST /api/authority/deploys/{deploy_id}/rollouts``."""
        if not deploy_id:
            raise ValueError("deploy_id is required")
        body = _compact({
            "repo_full_name": repo_full_name,
            "branch": branch,
            "sha": sha,
            "service_type": service_type,
            "reason": reason,
            "company": company,
            "subject": subject,
            "metadata": metadata,
            "force": force,
            "allow_duplicate_sha": allow_duplicate_sha,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, target_org_id, target_env),
        })
        return await self._post(
            f"/api/authority/deploys/{quote(deploy_id, safe='')}/rollouts",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def get_deploy_dossier(
        self,
        deploy_id: str,
        *,
        since: Optional[str] = None,
        until: Optional[str] = None,
        window_hours: Optional[int] = None,
        limit: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Get the full Authority dossier for a deploy.
        ``GET /api/authority/dossiers/deploy/{deploy_id}``.

        Mirrors the MCP ``authority_get_deploy_dossier`` tool. If the dossier
        route is not yet enabled in dominus-authority the gateway will return
        404 — the SDK surface is intentionally aligned with MCP.
        """
        if not deploy_id:
            raise ValueError("deploy_id is required")
        qs = _query_string({
            "since": since,
            "until": until,
            "window_hours": window_hours,
            "limit": limit,
        })
        return await self._get(
            f"/api/authority/dossiers/deploy/{quote(deploy_id, safe='')}{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    # ==================================================================
    # Managed clients
    # ==================================================================

    async def create_client_class(
        self,
        *,
        slug: str,
        name: Optional[str] = None,
        description: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Create a managed client class. ``POST /api/authority/clients/classes``."""
        if not slug:
            raise ValueError("create_client_class requires slug")
        body = _compact({
            "slug": slug,
            "name": name,
            "description": description,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, None, None),
        })
        return await self._post(
            "/api/authority/clients/classes",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def create_client_variant(
        self,
        *,
        class_slug: str,
        slug: str,
        name: Optional[str] = None,
        channel: Optional[str] = None,
        architecture: Optional[str] = None,
        runtime_family: Optional[str] = None,
        installer_format: Optional[str] = None,
        status: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Create a managed client variant. ``POST /api/authority/clients/variants``."""
        if not class_slug:
            raise ValueError("create_client_variant requires class_slug")
        if not slug:
            raise ValueError("create_client_variant requires slug")
        body = _compact({
            "class_slug": class_slug,
            "slug": slug,
            "name": name,
            "channel": channel,
            "architecture": architecture,
            "runtime_family": runtime_family,
            "installer_format": installer_format,
            "status": status,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, None, None),
        })
        return await self._post(
            "/api/authority/clients/variants",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def publish_client_release(
        self,
        *,
        variant_slug: str,
        version: str,
        manifest_path: Optional[str] = None,
        status: str = "published",
        storage_app_slug: Optional[str] = None,
        storage_env: Optional[str] = None,
        storage_category: Optional[str] = None,
        bootstrapper_path: Optional[str] = None,
        artifact_manifest_path: Optional[str] = None,
        checksums: Optional[Dict[str, Any]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """
        Create or upsert a managed-client release.

        ``POST /api/authority/clients/releases``.

        Use ``status="proposed"`` to start the release FSM without publishing;
        ``manifest_path`` may be omitted for proposed releases. Use
        ``approve_client_release`` → ``publish_approved_client_release`` →
        ``distribute_client_release`` for staged rollout.
        """
        if not variant_slug:
            raise ValueError("publish_client_release requires variant_slug")
        if not version:
            raise ValueError("publish_client_release requires version")
        status_eff = str(status or "published").strip().lower()
        if not manifest_path and status_eff != "proposed":
            raise ValueError("publish_client_release requires manifest_path unless status is proposed")
        body = _compact({
            "variant_slug": variant_slug,
            "version": version,
            "status": status,
            "storage_app_slug": storage_app_slug,
            "storage_env": storage_env,
            "storage_category": storage_category,
            "manifest_path": manifest_path,
            "bootstrapper_path": bootstrapper_path,
            "artifact_manifest_path": artifact_manifest_path,
            "checksums": checksums,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, None, None),
        })
        return await self._post(
            "/api/authority/clients/releases",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def get_client_release(
        self,
        release_id: str,
        *,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Fetch one release by id. ``GET /api/authority/clients/releases/{release_id}``."""
        if not release_id:
            raise ValueError("get_client_release requires release_id")
        qs = _query_string({"app_slug": app_slug, "env": env})
        return await self._get(
            f"/api/authority/clients/releases/{quote(release_id, safe='')}{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def approve_client_release(
        self,
        release_id: str,
        *,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Approve a proposed release. ``POST /api/authority/clients/releases/{id}/approve``."""
        if not release_id:
            raise ValueError("approve_client_release requires release_id")
        body = _compact({
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, None, None),
        })
        return await self._post(
            f"/api/authority/clients/releases/{quote(release_id, safe='')}/approve",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def publish_approved_client_release(
        self,
        release_id: str,
        *,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Publish an approved release (gateway health handshake). ``POST .../publish``."""
        if not release_id:
            raise ValueError("publish_approved_client_release requires release_id")
        body = _compact({
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, None, None),
        })
        return await self._post(
            f"/api/authority/clients/releases/{quote(release_id, safe='')}/publish",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def distribute_client_release(
        self,
        release_id: str,
        *,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Mark a published release as distributed. ``POST .../distribute``."""
        if not release_id:
            raise ValueError("distribute_client_release requires release_id")
        body = _compact({
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, None, None),
        })
        return await self._post(
            f"/api/authority/clients/releases/{quote(release_id, safe='')}/distribute",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def create_client_bootstrap_session(
        self,
        *,
        release_id: str,
        company: Optional[str] = None,
        subject: Optional[str] = None,
        ttl_hours: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Create a one-shot client bootstrap session. ``POST /api/authority/clients/bootstrap-sessions``."""
        if not release_id:
            raise ValueError("create_client_bootstrap_session requires release_id")
        body = _compact({
            "release_id": release_id,
            "company": company,
            "subject": subject,
            "ttl_hours": ttl_hours,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, None, None),
        })
        return await self._post(
            "/api/authority/clients/bootstrap-sessions",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def get_client_installation(
        self,
        installation_id: str,
        *,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get a managed client installation. ``GET /api/authority/clients/installations/{installation_id}``."""
        if not installation_id:
            raise ValueError("installation_id is required")
        return await self._get(
            f"/api/authority/clients/installations/{quote(installation_id, safe='')}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def list_client_installations(
        self,
        *,
        status: Optional[str] = None,
        variant_slug: Optional[str] = None,
        company: Optional[str] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """List managed client installations. ``GET /api/authority/clients/installations``."""
        qs = _query_string({
            "app_slug": app_slug,
            "env": env,
            "status": status,
            "variant_slug": variant_slug,
            "company": company,
            "limit": limit,
            "offset": offset,
        })
        return await self._get(
            f"/api/authority/clients/installations{qs}",
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def revoke_client_installation(
        self,
        installation_id: str,
        *,
        reason: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Revoke a managed client installation. ``POST /api/authority/clients/installations/{installation_id}/revoke``."""
        if not installation_id:
            raise ValueError("installation_id is required")
        body = _compact({
            "reason": reason,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, None, None),
        })
        return await self._post(
            f"/api/authority/clients/installations/{quote(installation_id, safe='')}/revoke",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def rotate_client_credentials(
        self,
        installation_id: str,
        *,
        reason: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Rotate credentials for a managed client installation. ``POST /api/authority/clients/installations/{installation_id}/rotate-credentials``."""
        if not installation_id:
            raise ValueError("installation_id is required")
        body = _compact({
            "reason": reason,
            "metadata": metadata,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, None, None),
        })
        return await self._post(
            f"/api/authority/clients/installations/{quote(installation_id, safe='')}/rotate-credentials",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    # ==================================================================
    # Timelines
    # ==================================================================

    async def query_timelines(
        self,
        *,
        subject: Optional[str] = None,
        company: Optional[str] = None,
        run_id: Optional[str] = None,
        filters: Optional[Dict[str, Any]] = None,
        since: Optional[str] = None,
        until: Optional[str] = None,
        window_hours: Optional[int] = None,
        limit: Optional[int] = None,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        target_org_id: Optional[str] = None,
        target_env: Optional[str] = None,
        initiator_type: Optional[str] = None,
        initiator_id: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Query the Authority timelines store. ``POST /api/authority/timelines/query``."""
        body = _compact({
            "subject": subject,
            "company": company,
            "run_id": run_id,
            "filters": filters,
            "since": since,
            "until": until,
            "window_hours": window_hours,
            "limit": limit,
            **self._initiator(initiator_type, initiator_id, idempotency_key),
            **self._scope(app_slug, env, target_org_id, target_env),
        })
        return await self._post(
            "/api/authority/timelines/query",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def get_timeline_archive_status(
        self,
        *,
        all_scopes: bool = False,
        app_slug: Optional[str] = None,
        env: Optional[str] = None,
        limit: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Get Authority timeline archive backlog state. ``GET /api/authority/timelines/archive-status``."""
        qs = _query_string({
            "all_scopes": "true" if all_scopes else None,
            "app_slug": app_slug,
            "env": env,
            "limit": limit,
        })
        return await self._get(
            f"/api/authority/timelines/archive-status{qs}",
            timeout=self._http_timeout(timeout, 15.0),
        )

    async def repair_timeline_archive_manifests(
        self,
        *,
        since: Optional[str] = None,
        until: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Rebuild Authority timeline daily archive manifests from cold buckets. ``POST /api/authority/timelines/archive-repair``."""
        body = _compact({
            "since": since,
            "until": until,
        })
        return await self._post(
            "/api/authority/timelines/archive-repair",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def verify_timeline_archive_manifests(
        self,
        *,
        since: Optional[str] = None,
        until: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Verify Authority timeline daily archive manifests against cold buckets. ``POST /api/authority/timelines/archive-verify``."""
        body = _compact({
            "since": since,
            "until": until,
        })
        return await self._post(
            "/api/authority/timelines/archive-verify",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    async def prune_timeline_archive_retention(
        self,
        *,
        since: Optional[str] = None,
        until: Optional[str] = None,
        retention_days: Optional[int] = None,
        dry_run: bool = True,
        confirm: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Dry-run or enforce Authority timeline cold archive retention. ``POST /api/authority/timelines/archive-prune``."""
        body = _compact({
            "since": since,
            "until": until,
            "retention_days": retention_days,
            "dry_run": dry_run,
            "confirm": confirm,
        })
        return await self._post(
            "/api/authority/timelines/archive-prune",
            body,
            timeout=self._http_timeout(timeout, 30.0),
        )

    # ==================================================================
    # Context
    # ==================================================================

    async def context_current(self, *, timeout: Optional[float] = None) -> Dict[str, Any]:
        """Get current Authority context. ``GET /api/authority/context/current``."""
        return await self._get(
            "/api/authority/context/current",
            timeout=self._http_timeout(timeout, 15.0),
        )

    async def context_resolve(
        self,
        *,
        org_id: Optional[str] = None,
        app_slug: Optional[str] = None,
        company: Optional[str] = None,
        tenant: Optional[str] = None,
        scope_mode: Optional[str] = None,
        use_shared: Optional[bool] = None,
        target_org_id: Optional[str] = None,
        target_app_slug: Optional[str] = None,
        target_env: Optional[str] = None,
        env: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Resolve the rrc.v1 routing contract. ``POST /api/authority/context/resolve``."""
        body: Dict[str, Any] = {}
        if org_id is not None:
            body["org_id"] = org_id
        if app_slug is not None:
            body["app_slug"] = app_slug
        if company is not None:
            body["company"] = company
        if tenant is not None:
            body["tenant"] = tenant
        if scope_mode is not None:
            body["scope_mode"] = scope_mode
        if use_shared is not None:
            body["use_shared"] = use_shared
        if target_org_id is not None:
            body["target_org_id"] = target_org_id
        if target_app_slug is not None:
            body["target_app_slug"] = target_app_slug
        if target_env is not None:
            body["target_env"] = target_env
        if env is not None:
            body["env"] = env
        return await self._post(
            "/api/authority/context/resolve",
            body,
            timeout=self._http_timeout(timeout, 20.0),
        )
