"""
Tests to ensure we reliably wrap the Anthropic API.
"""

import time
import unittest.mock
from pathlib import Path
from types import SimpleNamespace

import anthropic
import pytest
from braintrust import logger
from braintrust.integrations.anthropic import AnthropicIntegration, wrap_anthropic
from braintrust.integrations.anthropic._utils import extract_anthropic_usage
from braintrust.integrations.anthropic.tracing import _log_message_to_span
from braintrust.test_helpers import init_test_logger


PROJECT_NAME = "test-anthropic-app"
MODEL = "claude-3-haiku-20240307"  # use the cheapest model since answers dont matter


@pytest.fixture(scope="module")
def vcr_cassette_dir():
    return str(Path(__file__).resolve().parent / "cassettes")


def _get_client():
    return anthropic.Anthropic()


def _get_async_client():
    return anthropic.AsyncAnthropic()


@pytest.fixture
def memory_logger():
    init_test_logger(PROJECT_NAME)
    with logger._internal_with_memory_background_logger() as bgl:
        yield bgl


def test_log_message_to_span_includes_stop_reason_and_stop_sequence():
    span = unittest.mock.MagicMock()
    message = SimpleNamespace(
        role="assistant",
        content=[{"type": "text", "text": "done"}],
        model=MODEL,
        stop_reason="stop_sequence",
        stop_sequence="DONE",
        usage={
            "input_tokens": 11,
            "output_tokens": 7,
            "cache_read_input_tokens": 0,
            "cache_creation_input_tokens": 0,
        },
    )

    _log_message_to_span(message, span, time_to_first_token=0.123)

    span.log.assert_called_once_with(
        output={
            "role": "assistant",
            "content": [{"type": "text", "text": "done"}],
            "model": MODEL,
            "stop_reason": "stop_sequence",
            "stop_sequence": "DONE",
        },
        metrics={
            "prompt_tokens": 11.0,
            "completion_tokens": 7.0,
            "prompt_cached_tokens": 0.0,
            "prompt_cache_creation_tokens": 0.0,
            "tokens": 18.0,
            "time_to_first_token": 0.123,
        },
        metadata={},
    )


@pytest.mark.vcr
def test_anthropic_messages_create_stream_true(memory_logger):
    assert not memory_logger.pop()

    client = wrap_anthropic(_get_client())
    kws = {
        "model": MODEL,
        "max_tokens": 300,
        "messages": [{"role": "user", "content": "What is 3*4?"}],
        "stream": True,
    }

    start = time.time()
    with client.messages.create(**kws) as out:
        msgs = [m for m in out]
    end = time.time()

    assert msgs  # a very coarse grained check that this works

    spans = memory_logger.pop()
    assert len(spans) == 1
    span = spans[0]
    assert span["metadata"]["model"] == MODEL
    assert span["metadata"]["provider"] == "anthropic"
    assert span["metadata"]["max_tokens"] == 300
    assert span["metadata"]["stream"] == True
    metrics = span["metrics"]
    _assert_metrics_are_valid(metrics, start, end)
    assert span["input"] == kws["messages"]
    assert span["output"]
    assert span["output"]["role"] == "assistant"
    assert "12" in span["output"]["content"][0]["text"]


@pytest.mark.vcr
def test_anthropic_messages_model_params_inputs(memory_logger):
    assert not memory_logger.pop()
    client = wrap_anthropic(_get_client())

    kw = {
        "model": MODEL,
        "max_tokens": 300,
        "system": "just return the number",
        "messages": [{"role": "user", "content": "what is 1+1?"}],
        "temperature": 0.5,
        "top_p": 0.5,
    }

    def _with_messages_create():
        return client.messages.create(**kw)

    def _with_messages_stream():
        with client.messages.stream(**kw) as stream:
            for msg in stream:
                pass
        return stream.get_final_message()

    for f in [_with_messages_create, _with_messages_stream]:
        msg = f()
        assert msg.content[0].text == "2"

        logs = memory_logger.pop()
        assert len(logs) == 1
        log = logs[0]
        assert log["output"]["role"] == "assistant"
        assert "2" in log["output"]["content"][0]["text"]
        assert log["metadata"]["model"] == MODEL
        assert log["metadata"]["max_tokens"] == 300
        assert log["metadata"]["temperature"] == 0.5
        assert log["metadata"]["top_p"] == 0.5


@pytest.mark.vcr
def test_anthropic_messages_system_prompt_inputs(memory_logger):
    assert not memory_logger.pop()

    client = wrap_anthropic(_get_client())
    system = "Today's date is 2024-03-26. Only return the date"
    q = [{"role": "user", "content": "what is tomorrow's date? only return the date"}]

    args = {
        "messages": q,
        "temperature": 0,
        "max_tokens": 300,
        "system": system,
        "model": MODEL,
    }

    def _with_messages_create():
        return client.messages.create(**args)

    def _with_messages_stream():
        with client.messages.stream(**args) as stream:
            for msg in stream:
                pass
        return stream.get_final_message()

    for f in [_with_messages_create, _with_messages_stream]:
        msg = f()
        assert "2024-03-27" in msg.content[0].text

        logs = memory_logger.pop()
        assert len(logs) == 1
        log = logs[0]
        inputs = log["input"]
        assert len(inputs) == 2
        inputs_by_role = {m["role"]: m["content"] for m in inputs}
        assert inputs_by_role["system"] == system
        assert inputs_by_role["user"] == q[0]["content"]


@pytest.mark.vcr
@pytest.mark.asyncio
async def test_anthropic_messages_create_async(memory_logger):
    assert not memory_logger.pop()

    params = {
        "model": MODEL,
        "max_tokens": 100,
        "messages": [{"role": "user", "content": "what is 6+1?, just return the number"}],
    }

    client = wrap_anthropic(anthropic.AsyncAnthropic())
    msg = await client.messages.create(**params)
    assert "7" in msg.content[0].text

    spans = memory_logger.pop()
    assert len(spans) == 1
    span = spans[0]
    assert span["metadata"]["model"] == MODEL
    assert span["metadata"]["max_tokens"] == 100
    assert span["input"] == params["messages"]
    assert span["output"]["role"] == "assistant"
    assert "7" in span["output"]["content"][0]["text"]


@pytest.mark.vcr
@pytest.mark.asyncio
async def test_anthropic_messages_create_async_stream_true(memory_logger):
    assert not memory_logger.pop()

    params = {
        "model": MODEL,
        "max_tokens": 100,
        "messages": [{"role": "user", "content": "what is 6+1?, just return the number"}],
        "stream": True,
    }

    client = wrap_anthropic(anthropic.AsyncAnthropic())
    stream = await client.messages.create(**params)
    async for event in stream:
        pass

    spans = memory_logger.pop()
    assert len(spans) == 1
    span = spans[0]
    assert span["metadata"]["model"] == MODEL
    assert span["metadata"]["max_tokens"] == 100
    assert span["input"] == params["messages"]
    assert span["output"]["role"] == "assistant"
    assert "7" in span["output"]["content"][0]["text"]


@pytest.mark.vcr
@pytest.mark.asyncio
async def test_anthropic_messages_streaming_async(memory_logger):
    assert not memory_logger.pop()

    client = wrap_anthropic(_get_async_client())
    msgs_in = [{"role": "user", "content": "what is 1+1?, just return the number"}]

    start = time.time()
    msg_out = None

    async with client.messages.stream(max_tokens=1024, messages=msgs_in, model=MODEL) as stream:
        async for event in stream:
            pass
        msg_out = await stream.get_final_message()
        assert msg_out.content[0].text == "2"
        usage = msg_out.usage
    end = time.time()

    logs = memory_logger.pop()
    assert len(logs) == 1
    log = logs[0]
    assert "user" in str(log["input"])
    assert "1+1" in str(log["input"])
    assert "2" in str(log["output"])
    assert log["project_id"] == PROJECT_NAME
    assert log["span_attributes"]["type"] == "llm"
    assert log["metadata"]["model"] == MODEL
    assert log["metadata"]["max_tokens"] == 1024
    _assert_metrics_are_valid(log["metrics"], start, end)
    metrics = log["metrics"]
    assert metrics["prompt_tokens"] == usage.input_tokens
    assert metrics["completion_tokens"] == usage.output_tokens
    assert metrics["tokens"] == usage.input_tokens + usage.output_tokens
    assert metrics["prompt_cached_tokens"] == usage.cache_read_input_tokens
    assert metrics["prompt_cache_creation_tokens"] == usage.cache_creation_input_tokens
    assert log["metadata"]["model"] == MODEL
    assert log["metadata"]["max_tokens"] == 1024


@pytest.mark.vcr
def test_anthropic_client_error(memory_logger):
    assert not memory_logger.pop()

    client = wrap_anthropic(_get_client())

    fake_model = "there-is-no-such-model"
    msg_in = {"role": "user", "content": "who are you?"}

    try:
        client.messages.create(model=fake_model, max_tokens=999, messages=[msg_in])
    except Exception:
        pass
    else:
        raise Exception("should have raised an exception")

    logs = memory_logger.pop()
    assert len(logs) == 1
    log = logs[0]
    assert log["project_id"] == PROJECT_NAME
    assert "404" in log["error"]


@pytest.mark.vcr
def test_anthropic_messages_stream_errors(memory_logger):
    assert not memory_logger.pop()

    client = wrap_anthropic(_get_client())
    msg_in = {"role": "user", "content": "what is 2+2? (just the number)"}

    try:
        with client.messages.stream(model=MODEL, max_tokens=300, messages=[msg_in]) as stream:
            raise Exception("fake-error")
    except Exception:
        pass
    else:
        raise Exception("should have raised an exception")

    spans = memory_logger.pop()
    assert len(spans) == 1
    span = spans[0]
    assert "Exception: fake-error" in span["error"]
    assert span["metrics"]["end"] > 0


@pytest.mark.vcr
def test_anthropic_messages_streaming_sync(memory_logger):
    assert not memory_logger.pop()

    client = wrap_anthropic(_get_client())
    msg_in = {"role": "user", "content": "what is 2+2? (just the number)"}

    start = time.time()
    with client.messages.stream(model=MODEL, max_tokens=300, messages=[msg_in]) as stream:
        msgs_out = [m for m in stream]
    end = time.time()
    msg_out = stream.get_final_message()
    usage = msg_out.usage
    # crudely check that the stream is valid
    assert len(msgs_out) > 3
    assert 1 <= len([m for m in msgs_out if m.type == "text"])
    assert msgs_out[0].type == "message_start"
    assert msgs_out[-1].type == "message_stop"

    logs = memory_logger.pop()
    assert len(logs) == 1
    log = logs[0]
    assert "user" in str(log["input"])
    assert "2+2" in str(log["input"])
    assert "4" in str(log["output"])
    assert log["project_id"] == PROJECT_NAME
    assert log["span_attributes"]["type"] == "llm"
    _assert_metrics_are_valid(log["metrics"], start, end)
    assert log["metrics"]["prompt_tokens"] == usage.input_tokens
    assert log["metrics"]["completion_tokens"] == usage.output_tokens
    assert log["metrics"]["tokens"] == usage.input_tokens + usage.output_tokens
    assert log["metrics"]["prompt_cached_tokens"] == usage.cache_read_input_tokens
    assert log["metrics"]["prompt_cache_creation_tokens"] == usage.cache_creation_input_tokens


@pytest.mark.vcr
def test_anthropic_messages_sync(memory_logger):
    assert not memory_logger.pop()

    client = wrap_anthropic(_get_client())

    msg_in = {"role": "user", "content": "what's 2+2?"}

    start = time.time()
    msg = client.messages.create(model=MODEL, max_tokens=300, messages=[msg_in])
    end = time.time()

    text = msg.content[0].text
    assert text

    # verify we generated the right spans.
    logs = memory_logger.pop()

    assert len(logs) == 1
    log = logs[0]
    assert "2+2" in str(log["input"])
    assert "4" in str(log["output"])
    assert log["project_id"] == PROJECT_NAME
    assert log["span_id"]
    assert log["root_span_id"]
    attrs = log["span_attributes"]
    assert attrs["type"] == "llm"
    assert "anthropic" in attrs["name"]
    metrics = log["metrics"]
    _assert_metrics_are_valid(metrics, start, end)
    assert log["metadata"]["model"] == MODEL
    assert log["output"]["model"] == msg.model
    assert log["output"]["stop_reason"] == msg.stop_reason


def _assert_metrics_are_valid(metrics, start, end):
    assert metrics["tokens"] > 0
    assert metrics["prompt_tokens"] > 0
    assert metrics["completion_tokens"] > 0
    assert "time_to_first_token" in metrics
    assert metrics["time_to_first_token"] >= 0
    if start and end:
        assert start <= metrics["start"] <= metrics["end"] <= end
    else:
        assert metrics["start"] <= metrics["end"]


@pytest.mark.vcr
def test_anthropic_beta_messages_sync(memory_logger):
    assert not memory_logger.pop()

    client = wrap_anthropic(_get_client())
    msg_in = {"role": "user", "content": "what's 3+3?"}

    start = time.time()
    msg = client.beta.messages.create(model=MODEL, max_tokens=300, messages=[msg_in])
    end = time.time()

    text = msg.content[0].text
    assert text
    assert "6" in text

    logs = memory_logger.pop()
    assert len(logs) == 1
    log = logs[0]
    assert "3+3" in str(log["input"])
    assert "6" in str(log["output"])
    assert log["project_id"] == PROJECT_NAME
    assert log["span_id"]
    assert log["root_span_id"]
    attrs = log["span_attributes"]
    assert attrs["type"] == "llm"
    assert "anthropic" in attrs["name"]
    metrics = log["metrics"]
    _assert_metrics_are_valid(metrics, start, end)
    assert log["metadata"]["model"] == MODEL


@pytest.mark.vcr
def test_anthropic_beta_messages_stream_sync(memory_logger):
    assert not memory_logger.pop()

    client = wrap_anthropic(_get_client())
    msg_in = {"role": "user", "content": "what is 5+5? (just the number)"}

    start = time.time()
    with client.beta.messages.stream(model=MODEL, max_tokens=300, messages=[msg_in]) as stream:
        msgs_out = [m for m in stream]
    end = time.time()
    msg_out = stream.get_final_message()
    usage = msg_out.usage

    assert len(msgs_out) > 3
    assert msgs_out[0].type == "message_start"
    assert msgs_out[-1].type == "message_stop"
    assert "10" in msg_out.content[0].text

    logs = memory_logger.pop()
    assert len(logs) == 1
    log = logs[0]
    assert "user" in str(log["input"])
    assert "5+5" in str(log["input"])
    assert "10" in str(log["output"])
    assert log["project_id"] == PROJECT_NAME
    assert log["span_attributes"]["type"] == "llm"
    _assert_metrics_are_valid(log["metrics"], start, end)
    assert log["metrics"]["prompt_tokens"] == usage.input_tokens
    assert log["metrics"]["completion_tokens"] == usage.output_tokens
    assert log["metrics"]["tokens"] == usage.input_tokens + usage.output_tokens


@pytest.mark.vcr
@pytest.mark.asyncio
async def test_anthropic_beta_messages_create_async(memory_logger):
    assert not memory_logger.pop()

    params = {
        "model": MODEL,
        "max_tokens": 100,
        "messages": [{"role": "user", "content": "what is 8+2?, just return the number"}],
    }

    client = wrap_anthropic(anthropic.AsyncAnthropic())
    msg = await client.beta.messages.create(**params)
    assert "10" in msg.content[0].text

    spans = memory_logger.pop()
    assert len(spans) == 1
    span = spans[0]
    assert span["metadata"]["model"] == MODEL
    assert span["metadata"]["max_tokens"] == 100
    assert span["input"] == params["messages"]
    assert span["output"]["role"] == "assistant"
    assert "10" in span["output"]["content"][0]["text"]


@pytest.mark.vcr(
    match_on=["method", "scheme", "host", "port", "path", "body"]
)  # exclude query - varies by SDK version
@pytest.mark.asyncio
async def test_anthropic_beta_messages_streaming_async(memory_logger):
    assert not memory_logger.pop()

    client = wrap_anthropic(_get_async_client())
    msgs_in = [{"role": "user", "content": "what is 9+1?, just return the number"}]

    start = time.time()
    msg_out = None

    async with client.beta.messages.stream(max_tokens=1024, messages=msgs_in, model=MODEL) as stream:
        async for event in stream:
            pass
        msg_out = await stream.get_final_message()
        assert "10" in msg_out.content[0].text
        usage = msg_out.usage
    end = time.time()

    logs = memory_logger.pop()
    assert len(logs) == 1
    log = logs[0]
    assert "user" in str(log["input"])
    assert "9+1" in str(log["input"])
    assert "10" in str(log["output"])
    assert log["project_id"] == PROJECT_NAME
    assert log["span_attributes"]["type"] == "llm"
    assert log["metadata"]["model"] == MODEL
    assert log["metadata"]["max_tokens"] == 1024
    _assert_metrics_are_valid(log["metrics"], start, end)
    metrics = log["metrics"]
    assert metrics["prompt_tokens"] == usage.input_tokens
    assert metrics["completion_tokens"] == usage.output_tokens
    assert metrics["tokens"] == usage.input_tokens + usage.output_tokens


@pytest.mark.vcr
def test_setup_creates_spans(memory_logger):
    """`AnthropicIntegration.setup()` should create spans when making API calls."""
    AnthropicIntegration.setup()

    client = anthropic.Anthropic()
    message = client.messages.create(
        model=MODEL,
        max_tokens=100,
        messages=[{"role": "user", "content": "hi"}],
    )

    usage = message.usage

    spans = memory_logger.pop()
    assert len(spans) == 1
    span = spans[0]
    assert span["metadata"]["model"] == MODEL
    assert span["metadata"]["provider"] == "anthropic"

    cache_creation = getattr(usage, "cache_creation", None)
    if cache_creation is None:
        pytest.skip("Anthropic SDK version does not expose nested cache_creation usage fields")

    if isinstance(cache_creation, dict):
        ephemeral_5m = cache_creation["ephemeral_5m_input_tokens"]
        ephemeral_1h = cache_creation["ephemeral_1h_input_tokens"]
    else:
        ephemeral_5m = cache_creation.ephemeral_5m_input_tokens
        ephemeral_1h = cache_creation.ephemeral_1h_input_tokens

    assert span["metadata"]["usage_service_tier"] == usage.service_tier
    assert span["metadata"]["usage_inference_geo"] == usage.inference_geo
    metrics = span["metrics"]
    assert metrics["prompt_tokens"] == (
        usage.input_tokens + usage.cache_read_input_tokens + usage.cache_creation_input_tokens
    )
    assert metrics["completion_tokens"] == usage.output_tokens
    assert metrics["prompt_cache_creation_tokens"] == usage.cache_creation_input_tokens
    assert metrics["prompt_cache_creation_ephemeral_5m_tokens"] == ephemeral_5m
    assert metrics["prompt_cache_creation_ephemeral_1h_tokens"] == ephemeral_1h
    assert "service_tier" not in metrics


def test_extract_anthropic_usage_preserves_nested_numeric_fields():
    usage = {
        "input_tokens": 8,
        "output_tokens": 12,
        "cache_creation": {
            "ephemeral_5m_input_tokens": 3,
            "ephemeral_1h_input_tokens": 4,
        },
        "server_tool_use": {
            "web_search_requests": 2,
            "web_fetch_requests": 1,
        },
        "service_tier": "standard",
        "inference_geo": "not_available",
    }
    metrics, metadata = extract_anthropic_usage(usage)

    assert metrics["prompt_tokens"] == 15
    assert metrics["completion_tokens"] == 12
    assert metrics["tokens"] == 27
    assert metrics["prompt_cache_creation_tokens"] == 7
    assert metrics["prompt_cache_creation_ephemeral_5m_tokens"] == 3
    assert metrics["prompt_cache_creation_ephemeral_1h_tokens"] == 4
    assert metrics["server_tool_use_web_search_requests"] == 2
    assert metrics["server_tool_use_web_fetch_requests"] == 1
    assert "service_tier" not in metrics
    assert metadata == {
        "usage_service_tier": "standard",
        "usage_inference_geo": "not_available",
    }


def test_extract_anthropic_usage_skips_empty_usage():
    metrics, metadata = extract_anthropic_usage(SimpleNamespace())

    assert metrics == {}
    assert metadata == {}


def _make_batch_requests():
    return [
        {
            "custom_id": "req-1",
            "params": {
                "model": MODEL,
                "max_tokens": 100,
                "messages": [{"role": "user", "content": "What is 2+2?"}],
            },
        },
        {
            "custom_id": "req-2",
            "params": {
                "model": MODEL,
                "max_tokens": 100,
                "messages": [{"role": "user", "content": "What is 3+3?"}],
            },
        },
    ]


class TestBatchesCreateSpans:
    """Tests verifying that batches.create() produces correct spans."""

    @pytest.mark.vcr
    def test_sync_batches_create_produces_span(self, memory_logger):
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_client())
        result = client.messages.batches.create(requests=_make_batch_requests())

        assert result.id
        assert result.processing_status == "in_progress"

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert span["span_attributes"]["name"] == "anthropic.messages.batches.create"
        assert span["span_attributes"]["type"] == "task"
        assert span["metadata"]["provider"] == "anthropic"
        assert span["metadata"]["num_requests"] == 2
        assert span["metadata"]["model"] == MODEL
        assert span["input"] == [{"custom_id": "req-1"}, {"custom_id": "req-2"}]
        assert span["output"]["id"] == result.id
        assert span["output"]["processing_status"] == "in_progress"
        assert span["output"]["request_counts"]["processing"] == 2

    @pytest.mark.vcr
    @pytest.mark.asyncio
    async def test_async_batches_create_produces_span(self, memory_logger):
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_async_client())
        result = await client.messages.batches.create(requests=_make_batch_requests())

        assert result.id
        assert result.processing_status == "in_progress"

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert span["span_attributes"]["name"] == "anthropic.messages.batches.create"
        assert span["span_attributes"]["type"] == "task"
        assert span["metadata"]["provider"] == "anthropic"
        assert span["metadata"]["num_requests"] == 2
        assert span["metadata"]["model"] == MODEL
        assert span["input"] == [{"custom_id": "req-1"}, {"custom_id": "req-2"}]
        assert span["output"]["id"] == result.id

    @pytest.mark.vcr
    def test_sync_batches_create_logs_error_on_failure(self, memory_logger):
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_client())
        # Empty requests list triggers a 400 error
        with pytest.raises(Exception):
            client.messages.batches.create(requests=[])

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert span["span_attributes"]["name"] == "anthropic.messages.batches.create"
        assert span["error"]

    @pytest.mark.vcr
    def test_sync_batches_create_multi_model_metadata(self, memory_logger):
        """When batch requests use different models, metadata should include 'models' list."""
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_client())

        requests = [
            {
                "custom_id": "req-1",
                "params": {
                    "model": "claude-3-haiku-20240307",
                    "max_tokens": 100,
                    "messages": [{"role": "user", "content": "Hi"}],
                },
            },
            {
                "custom_id": "req-2",
                "params": {
                    "model": "claude-3-5-haiku-latest",
                    "max_tokens": 100,
                    "messages": [{"role": "user", "content": "Hello"}],
                },
            },
        ]
        result = client.messages.batches.create(requests=requests)
        assert result.id

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert "model" not in span["metadata"]
        assert span["metadata"]["models"] == sorted(["claude-3-haiku-20240307", "claude-3-5-haiku-latest"])


class TestBatchesResultsSpans:
    """Tests verifying that batches.results() produces correct spans.

    Mocked because the batch results API requires a completed batch, and batches
    can take up to 24 hours to finish processing.
    """

    def test_sync_batches_results_produces_span(self, memory_logger):
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_client())
        mock_decoder = unittest.mock.MagicMock()
        with unittest.mock.patch(
            "anthropic.resources.messages.batches.Batches.results",
            return_value=mock_decoder,
        ):
            result = client.messages.batches.results("msgbatch_abc123")

        assert result is mock_decoder

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert span["span_attributes"]["name"] == "anthropic.messages.batches.results"
        assert span["span_attributes"]["type"] == "task"
        assert span["metadata"]["provider"] == "anthropic"
        assert span["input"]["message_batch_id"] == "msgbatch_abc123"
        assert span["output"]["type"] == "jsonl_stream"

    @pytest.mark.asyncio
    async def test_async_batches_results_produces_span(self, memory_logger):
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_async_client())
        mock_decoder = unittest.mock.MagicMock()
        with unittest.mock.patch(
            "anthropic.resources.messages.batches.AsyncBatches.results",
            return_value=mock_decoder,
        ):
            result = await client.messages.batches.results(message_batch_id="msgbatch_abc456")

        assert result is mock_decoder

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert span["span_attributes"]["name"] == "anthropic.messages.batches.results"
        assert span["metadata"]["provider"] == "anthropic"
        assert span["input"]["message_batch_id"] == "msgbatch_abc456"

    def test_sync_batches_results_logs_error_on_failure(self, memory_logger):
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_client())
        with unittest.mock.patch(
            "anthropic.resources.messages.batches.Batches.results",
            side_effect=Exception("results fetch failed"),
        ):
            with pytest.raises(Exception, match="results fetch failed"):
                client.messages.batches.results("msgbatch_abc123")

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert span["span_attributes"]["name"] == "anthropic.messages.batches.results"
        assert "results fetch failed" in span["error"]


class TestBetaBatchesCreateSpans:
    """Tests verifying that beta.messages.batches.create() produces correct spans."""

    @pytest.mark.vcr
    def test_sync_beta_batches_create_produces_span(self, memory_logger):
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_client())
        result = client.beta.messages.batches.create(requests=_make_batch_requests())

        assert result.id
        assert result.processing_status == "in_progress"

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert span["span_attributes"]["name"] == "anthropic.messages.batches.create"
        assert span["span_attributes"]["type"] == "task"
        assert span["metadata"]["provider"] == "anthropic"
        assert span["metadata"]["num_requests"] == 2
        assert span["metadata"]["model"] == MODEL
        assert span["input"] == [{"custom_id": "req-1"}, {"custom_id": "req-2"}]
        assert span["output"]["id"] == result.id
        assert span["output"]["processing_status"] == "in_progress"
        assert span["output"]["request_counts"]["processing"] == 2

    @pytest.mark.vcr
    @pytest.mark.asyncio
    async def test_async_beta_batches_create_produces_span(self, memory_logger):
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_async_client())
        result = await client.beta.messages.batches.create(requests=_make_batch_requests())

        assert result.id
        assert result.processing_status == "in_progress"

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert span["span_attributes"]["name"] == "anthropic.messages.batches.create"
        assert span["span_attributes"]["type"] == "task"
        assert span["metadata"]["provider"] == "anthropic"
        assert span["metadata"]["num_requests"] == 2
        assert span["metadata"]["model"] == MODEL
        assert span["input"] == [{"custom_id": "req-1"}, {"custom_id": "req-2"}]
        assert span["output"]["id"] == result.id


class TestBetaBatchesResultsSpans:
    """Tests verifying that beta.messages.batches.results() produces correct spans.

    Mocked because the batch results API requires a completed batch, and batches
    can take up to 24 hours to finish processing.
    """

    def test_sync_beta_batches_results_produces_span(self, memory_logger):
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_client())
        mock_decoder = unittest.mock.MagicMock()
        with unittest.mock.patch(
            "anthropic.resources.beta.messages.batches.Batches.results",
            return_value=mock_decoder,
        ):
            result = client.beta.messages.batches.results("msgbatch_beta123")

        assert result is mock_decoder

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert span["span_attributes"]["name"] == "anthropic.messages.batches.results"
        assert span["span_attributes"]["type"] == "task"
        assert span["metadata"]["provider"] == "anthropic"
        assert span["input"]["message_batch_id"] == "msgbatch_beta123"
        assert span["output"]["type"] == "jsonl_stream"

    @pytest.mark.asyncio
    async def test_async_beta_batches_results_produces_span(self, memory_logger):
        assert not memory_logger.pop()

        client = wrap_anthropic(_get_async_client())
        mock_decoder = unittest.mock.MagicMock()
        with unittest.mock.patch(
            "anthropic.resources.beta.messages.batches.AsyncBatches.results",
            return_value=mock_decoder,
        ):
            result = await client.beta.messages.batches.results(message_batch_id="msgbatch_beta456")

        assert result is mock_decoder

        spans = memory_logger.pop()
        assert len(spans) == 1
        span = spans[0]
        assert span["span_attributes"]["name"] == "anthropic.messages.batches.results"
        assert span["metadata"]["provider"] == "anthropic"
        assert span["input"]["message_batch_id"] == "msgbatch_beta456"
