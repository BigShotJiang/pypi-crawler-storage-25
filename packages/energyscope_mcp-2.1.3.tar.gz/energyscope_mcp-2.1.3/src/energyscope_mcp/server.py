"""
EnergyScope MCP Server
======================
MCP server for AI agents to discover, query, and analyse energy market data.
17 tools: 6 data + 11 analytics.

An analyst can ask their AI assistant questions like:
  "What's the latest WTI crude oil price?"
  "Forecast WTI using crude stocks and production as predictors"
  "Are there any regime changes in WTI since 2020?"
  "Is WTI stationary? Run unit root tests."
  "What's the correlation between WTI, Brent, and jet fuel?"
  "Run a Prophet forecast on US crude stocks with US holidays"

The agent uses these tools to search, browse, fetch, and analyse the data.

Register:
    claude mcp add --scope user --transport stdio energyscope -- python "<path>/energyscope_mcp.py"

Requires:
    pip install mcp pyarrow

Env vars:
    ENERGYSCOPE_SERVER  - Flight server address (default: grpc://localhost:8815)
    ENERGYSCOPE_API_KEY - API key for authentication (optional)
"""

import os
import sys
import json
import time
from typing import Optional

import pyarrow as pa
import pyarrow.flight as flight
from mcp.server.fastmcp import FastMCP

from . import __version__ as MCP_VERSION

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

SERVER_ADDRESS = os.environ.get("ENERGYSCOPE_SERVER", "grpc://localhost:8815")
API_KEY = os.environ.get("ENERGYSCOPE_API_KEY", "")

mcp = FastMCP(
    "energyscope",
    instructions=(
        f"EnergyScope MCP Server v{MCP_VERSION}. "
        "Energy Analytics Flight Server. "
        "1.4M time series from 10 sources. 39 tools: 7 data + 32 analytics. "
        "All analytics run server-side — your analytics where the data sits.\n\n"
        f"VERSION: When the user asks which version of energyscope-mcp is running, "
        f"answer 'energyscope-mcp v{MCP_VERSION}'. This is the version installed on the "
        f"user's machine (not a runtime-queried value). The same version is returned as "
        f"the first line of the `health` tool output if fresh confirmation is needed.\n\n"
        "DATASETS:\n"
        "- PET (EIA Petroleum): 174K series. Prices, stocks, production, imports/exports, refinery ops. 1859–2026.\n"
        "  Key: PET.RWTC.D (WTI), PET.RBRTE.D (Brent), PET.WCESTUS1.W (crude stocks), "
        "PET.WCRFPUS2.W (production), PET.WGTSTUS1.W (gasoline stocks), PET.MCRFPUS2.M (monthly prod)\n"
        "- ELEC (EIA Electricity): 755K series. Generation, consumption, prices by state/fuel. 2001–2025.\n"
        "- NG (EIA Natural Gas): 16K series. Prices, storage, production. Henry Hub: NG.RNGWHHD.D. 1900–2026.\n"
        "- INTL (EIA International): 103K series. Global production, consumption, trade. 1949–2025.\n"
        "- STEO (EIA Short-Term Outlook): 4.4K series. EIA forecasts to 2027.\n"
        "- PET_IMPORTS (EIA): 46K series. US petroleum imports by country/product.\n"
        "- FRED (Federal Reserve): 14 key series. Interest rates, USD index, inflation.\n"
        "- ECB (European Central Bank): 38 series. EUR exchange rates, policy rates.\n"
        "- EUROSTAT: 327K series. European energy production, consumption, prices.\n"
        "- JODI (Joint Organisations): 4.2K series. Global oil/gas supply/demand balances.\n"
        "- WORLDBANK: 120 series. GDP, population, energy intensity by country.\n"
        "- BAKER_HUGHES: 14 series. US rig counts.\n"
        "- CFTC: 45 series. Commitments of Traders — managed money positioning for WTI, Brent, NG, ULSD, RBOB.\n"
        "  Key: CFTC.WTI.MM_Net (net managed money), CFTC.WTI.OI (open interest), CFTC.BRENT.MM_Net\n"
        "- ICE: 24 series. ICE Brent futures curve (daily). M1-M12 constant-maturity + dated contracts.\n"
        "  Key: ICE.BRENT.M1.D (front month), ICE.BRENT.M12.D (12-month), ICE.BRENT.2026-06.D (June contract)\n"
        "  Use for contango/backwardation analysis, term-structure trades.\n\n"
        "SERIES ID CONVENTION: {DATASET}.{ID}.{FREQ} e.g. PET.RWTC.D = Petroleum, Reuters WTI Cushing, Daily.\n"
        "Freq suffixes: .D=daily, .W=weekly, .M=monthly, .A=annual.\n"
        "Use the search tool to find series — don't guess IDs.\n\n"
        "ANALYTICS (20 tools): forecast (XGBoost multi-factor, default), arima, prophet, theta, smooth, "
        "breakpoints, stats, volatility, returns, correlation, unit_root, cointegration, var, acf, "
        "transform, hp_filter, bandpass, seasonality, interpolate, outliers, elastic_net, "
        "quantile_reg, bubble_test, lpirf, midas."
    ),
)

# ---------------------------------------------------------------------------
# Flight client (singleton)
# ---------------------------------------------------------------------------

_client = None


def _call_options():
    """Build FlightCallOptions with API key auth header if configured."""
    if API_KEY:
        import base64
        token = base64.b64encode(f"{API_KEY}:".encode()).decode()
        return flight.FlightCallOptions(headers=[(b"authorization", f"Basic {token}".encode())])
    return None


def get_client() -> flight.FlightClient:
    global _client
    if _client is None:
        _client = flight.connect(SERVER_ADDRESS)
    return _client


def sparkline(values, width=20):
    """Generate ASCII sparkline from a list of numbers."""
    if not values or len(values) < 2:
        return ""
    chars = "▁▂▃▄▅▆▇█"
    mn = min(values)
    mx = max(values)
    rng = mx - mn
    if rng == 0:
        return chars[4] * width
    # Sample to width
    step = max(1, len(values) // width)
    sampled = [values[i] for i in range(0, len(values), step)][:width]
    return "".join(chars[min(7, int((v - mn) / rng * 7.99))] for v in sampled)


def do_action(action_type: str, body: str = "") -> dict:
    """Call a Flight action and return parsed JSON response."""
    client = get_client()
    action = flight.Action(action_type, body.encode() if body else b"")
    results = []
    for result in client.do_action(action, options=_call_options()):
        results.append(json.loads(result.body.to_pybytes()))
    return results[0] if len(results) == 1 else results


def do_get(series: list, start: str = None, end: str = None) -> pa.Table:
    """Fetch data via Flight do_get."""
    client = get_client()
    ticket_dict = {"series": series}
    if start:
        ticket_dict["start"] = start
    if end:
        ticket_dict["end"] = end
    ticket = flight.Ticket(json.dumps(ticket_dict).encode())
    reader = client.do_get(ticket, options=_call_options())
    return reader.read_all()


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def search(query: str, limit: int = 20) -> str:
    """Search for energy data series by keyword.

    Use this to find series IDs for topics like "crude oil", "gasoline prices",
    "natural gas storage", "diesel imports", "jet fuel", etc.

    Returns series_id, name, frequency (D/W/M/A), and units.

    Examples:
      search("WTI crude oil")
      search("gasoline retail price")
      search("natural gas storage")
      search("distillate imports PADD 1")
    """
    result = do_action("search", query)
    if isinstance(result, list) and len(result) == 0:
        return "No series found. Try broader keywords."

    # Truncate to limit
    if isinstance(result, list):
        result = result[:limit]

    lines = []
    for r in result:
        freq = r.get("f", "?")
        units = r.get("units", "")
        lines.append(f"  {r['series_id']:40s}  {freq}  {units:20s}  {r.get('name', '')}")

    header = f"Found {len(result)} series:\n"
    header += f"  {'Series ID':40s}  F  {'Units':20s}  Name\n"
    header += f"  {'-'*40}  -  {'-'*20}  {'-'*40}\n"
    return header + "\n".join(lines)


@mcp.tool()
def get_data(
    series_ids: list[str],
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Fetch time series data for one or more series.

    Args:
        series_ids: List of series IDs (e.g. ["PET.RWTC.D", "PET.RBRTE.D"])
        start: Start date YYYY-MM-DD (optional, defaults to all history)
        end: End date YYYY-MM-DD (optional, defaults to latest)

    Returns data as a table with columns: series_id, period, value.

    Examples:
      get_data(["PET.RWTC.D"], "2024-01-01", "2024-12-31")
      get_data(["PET.RWTC.D", "PET.RBRTE.D"], "2020-01-01")
    """
    table = do_get(series_ids, start, end)

    if table.num_rows == 0:
        return "No data found for the given series and date range."

    # Format as readable table
    lines = [f"{'Series ID':40s}  {'Period':12s}  {'Value':>12s}"]
    lines.append(f"{'-'*40}  {'-'*12}  {'-'*12}")

    sid_col = table.column("series_id")
    period_col = table.column("period")
    value_col = table.column("value")

    for i in range(min(table.num_rows, 500)):  # cap at 500 rows
        sid = sid_col[i].as_py()
        period = period_col[i].as_py()
        value = value_col[i].as_py()
        val_str = f"{value:>12.4f}" if value is not None else f"{'N/A':>12s}"
        lines.append(f"{sid:40s}  {period:12s}  {val_str}")

    result = f"{table.num_rows} rows returned.\n\n" + "\n".join(lines)
    if table.num_rows > 500:
        result += f"\n\n... (showing first 500 of {table.num_rows} rows)"
    return result


@mcp.tool()
def latest(series_ids: list[str]) -> str:
    """Get the latest (most recent) value for one or more series.

    Faster than get_data — returns just the last known data point per series,
    plus the series name and units.

    Args:
        series_ids: List of series IDs

    Examples:
      latest(["PET.RWTC.D"])  # Latest WTI crude oil price
      latest(["PET.RWTC.D", "PET.RBRTE.D"])  # Latest WTI and Brent
    """
    result = do_action("latest", json.dumps({"series": series_ids}))

    lines = []
    for r in result:
        if "error" in r:
            lines.append(f"  {r['series_id']}: {r['error']}")
        else:
            val = r.get("value")
            val_str = f"{val:.4f}" if val is not None else "N/A"
            freq = r.get("frequency", "")
            date_range = ""
            if r.get("first_period"):
                date_range = f"{r['first_period']}–{r.get('period', '?')}"
            elif r.get("first_year"):
                date_range = f"{r['first_year']}–{r.get('last_year', '?')}"
            pts = r.get("data_points", "")
            meta = f" [{freq}]" if freq else ""
            meta += f" {date_range}" if date_range else ""
            meta += f" ({pts:,} pts)" if pts else ""
            lines.append(
                f"  {r['series_id']:40s}  {r.get('period', '?'):12s}  "
                f"{val_str:>12s}  {r.get('units', ''):20s}  {r.get('name', '')}{meta}"
            )

    header = f"  {'Series ID':40s}  {'Period':12s}  {'Value':>12s}  {'Units':20s}  Name\n"
    header += f"  {'-'*40}  {'-'*12}  {'-'*12}  {'-'*20}  {'-'*30}\n"
    return header + "\n".join(lines)


@mcp.tool()
def browse(category_id: Optional[int] = None) -> str:
    """Browse the EIA data category tree.

    Call with no arguments to see top-level categories.
    Call with a category_id to see its children and series.

    Use this to explore what data is available when you don't know
    the exact series ID.

    Examples:
      browse()             # Top-level categories (Petroleum, Natural Gas, etc.)
      browse(714755)       # Children of a specific category
    """
    body = json.dumps({"id": category_id}) if category_id else "{}"
    result = do_action("browse", body)

    if isinstance(result, list):
        # Top-level categories
        lines = ["Top-level categories:\n"]
        for cat in result:
            children = cat.get("children", 0)
            series = cat.get("series", 0)
            lines.append(f"  [{cat['id']}] {cat['name']}  ({children} subcategories, {series} series)")
        return "\n".join(lines)
    else:
        # Category detail
        lines = [f"Category: {result['name']} (id={result['id']})\n"]

        children = result.get("children", [])
        if children:
            lines.append(f"Subcategories ({len(children)}):")
            for cat in children:
                c = cat.get("children", 0)
                s = cat.get("series", 0)
                lines.append(f"  [{cat['id']}] {cat['name']}  ({c} subcategories, {s} series)")

        series = result.get("series", [])
        if series:
            lines.append(f"\nSeries ({len(series)}):")
            for s in series[:50]:  # cap display
                lines.append(f"  {s['series_id']:40s}  {s.get('f', '?')}  {s.get('units', ''):20s}  {s.get('name', '')}")
            if len(series) > 50:
                lines.append(f"  ... and {len(series) - 50} more")

        return "\n".join(lines)


@mcp.tool()
def datasets() -> str:
    """List available datasets and their status (loaded, rows, series count).

    Shows what data is currently available on the server.
    """
    result = do_action("list_datasets")

    lines = [f"{'Name':10s}  {'Status':10s}  {'Rows':>12s}  {'Series':>10s}"]
    lines.append(f"{'-'*10}  {'-'*10}  {'-'*12}  {'-'*10}")

    for ds in result:
        status = "loaded" if ds.get("loaded") else "available"
        rows = f"{ds.get('rows', 0):>12,}" if ds.get("loaded") else f"{'—':>12s}"
        series = f"{ds.get('series', 0):>10,}" if ds.get("loaded") else f"{'—':>10s}"
        lines.append(f"{ds['name']:10s}  {status:10s}  {rows}  {series}")

    return "\n".join(lines)


@mcp.tool()
def feedback(
    message: str,
    category: str = "general",
    context: str = "",
    user: str = "anonymous",
) -> str:
    """Submit feedback, bug report, or feature request to the EnergyScope team.

    Use this whenever you encounter an issue, have a suggestion, or want to flag
    something for improvement. Messages are written to a central feedback log on
    the server and the team is notified immediately.

    Args:
        message: The feedback text (what's wrong / what would help / what you tried).
        category: One of "bug", "feature", "data-gap", "ux", "question", "general".
        context: Optional context — tool name, series IDs, error message, etc.
        user: Identifier for who you are (e.g. "gunvor-analyst-1", "david"). Optional.
    """
    try:
        result = do_action("feedback", json.dumps({
            "message": message,
            "category": category,
            "context": context,
            "user": user,
            "client_version": f"mcp-{MCP_VERSION}",
        }))
        return f"Feedback submitted at {result.get('ts', '?')} (category: {result.get('category', '?')}). Thank you!"
    except Exception as e:
        return f"Could not submit feedback: {e}"


@mcp.tool()
def health() -> str:
    """Check server health and connection status. Also reports MCP client version."""
    try:
        result = do_action("healthcheck")
        return (
            f"MCP client: energyscope-mcp v{MCP_VERSION}\n"
            f"Status: {result.get('status', '?')}\n"
            f"Series: {result.get('series_count', 0):,}\n"
            f"Rows: {result.get('data_rows', 0):,}\n"
            f"Server: {SERVER_ADDRESS}"
        )
    except Exception as e:
        return f"MCP client: energyscope-mcp v{MCP_VERSION}\nConnection failed: {e}\nServer: {SERVER_ADDRESS}"


# ---------------------------------------------------------------------------
# Analytics Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def forecast(
    series_ids: list[str],
    target: str,
    horizon: int = 12,
    method: str = "xgboost",
    engine: str = "both",
    pinned: Optional[dict] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Multi-factor forecast using XGBoost/ElasticNet/Ridge/OLS regression.
    Auto-forecasts predictor series with ARIMA and/or Prophet.
    Use pinned to fix predictor values for scenario analysis.

    Args:
        series_ids: All series (target + predictors), e.g. ["PET.RWTC.D", "PET.WCESTUS1.W"]
        target: The series to forecast, e.g. "PET.RWTC.D"
        horizon: Periods ahead (default 12)
        method: xgboost (default), elasticnet, ridge, ols
        engine: Predictor engine — both (default), arima, prophet
        pinned: Fix predictors at specific values for scenarios, e.g. {"PET.WCRFPUS2.W": 13660}
        start: Start date for training (YYYY-MM-DD)
        end: End date for training
    """
    req = {"series": series_ids, "target": target, "horizon": horizon,
           "method": method, "predictor_engine": engine}
    if pinned: req["pinned"] = pinned
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("forecast", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"ES.Forecast: {target} (R²={result.get('r_squared', 0):.3f}, method={method}, engine={engine})"]
    lines.append(f"Observations: {result.get('observations', 0)}")
    lines.append("")
    for c in result.get("coefficients", []):
        sel = " *" if c.get("selected") else ""
        lines.append(f"  {c['series']}: {c['coefficient']:.4f}{sel}")
    lines.append("")
    lines.append("Forecast:")
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")

    if "forecast_comparison" in result:
        lines.append("")
        lines.append("Comparison (ARIMA vs Prophet predictor engines):")
        for eng, fcs in result["forecast_comparison"].items():
            vals = ", ".join([f"${f['forecast']:.2f}" for f in fcs[:3]])
            lines.append(f"  {eng}: {vals}...")

    return "\n".join(lines)


@mcp.tool()
def arima(
    series_id: str,
    horizon: int = 12,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Univariate auto-ARIMA forecast with confidence intervals.

    Args:
        series_id: Series to forecast, e.g. "PET.RWTC.D"
        horizon: Periods ahead (default 12)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "horizon": horizon}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("arima", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"ARIMA{tuple(result.get('order', []))} (AIC={result.get('aic', 0):.1f})"]
    lines.append("")
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")
    return "\n".join(lines)


@mcp.tool()
def prophet(
    series_id: str,
    horizon: int = 12,
    holidays: Optional[str] = None,
    seasonality: str = "additive",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Facebook Prophet forecast with holidays and seasonality.

    Args:
        series_id: Series to forecast, e.g. "PET.WCESTUS1.W"
        horizon: Periods ahead (default 12)
        holidays: Country code for holidays (US, UK, DE, FR)
        seasonality: additive (default) or multiplicative
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "horizon": horizon, "seasonality_mode": seasonality}
    if holidays: req["country_holidays"] = holidays
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("prophet", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Prophet forecast ({result.get('frequency', '?')})"]
    if result.get("changepoints"):
        lines.append(f"Changepoints: {', '.join(result['changepoints'][-5:])}")
    lines.append("")
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")
    return "\n".join(lines)


@mcp.tool()
def theta(
    series_id: str,
    horizon: int = 12,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Theta method forecast — M3 competition winner. Fast, robust benchmark.

    Args:
        series_id: Series to forecast, e.g. "PET.RWTC.D"
        horizon: Periods ahead (default 12)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "horizon": horizon}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("theta", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Theta forecast ({result.get('observations', 0)} obs)"]
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower', 0):.2f} – {f.get('ci_upper', 0):.2f}]")
    return "\n".join(lines)


@mcp.tool()
def breakpoints(
    series_id: str,
    min_shift: float = 0,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Detect structural breaks / regime changes in a series.

    Args:
        series_id: Series to analyse, e.g. "PET.RWTC.D"
        min_shift: Minimum shift magnitude to include (e.g. 5 for $5+)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id}
    if min_shift > 0: req["min_shift"] = min_shift
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("breakpoints", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"{result.get('n_breakpoints', 0)} breakpoints detected:"]
    for bp in result.get("breakpoints", []):
        shift = bp.get("shift", 0)
        lines.append(f"  {bp['period']}: {'+' if shift > 0 else ''}{shift:.1f}  (before: {bp.get('mean_before', 0):.1f} → after: {bp.get('mean_after', 0):.1f})")
    return "\n".join(lines)


@mcp.tool()
def stats(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Descriptive statistics for a series.

    Args:
        series_id: Series to analyse, e.g. "PET.RWTC.D"
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("stats", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Stats for {series_id}:"]
    for key in ["count", "mean", "median", "std", "min", "max", "skewness", "kurtosis",
                "p5", "p25", "p75", "p95", "first_date", "last_date", "pct_change"]:
        val = result.get(key)
        if val is not None:
            lines.append(f"  {key}: {val}")
    return "\n".join(lines)


@mcp.tool()
def volatility(
    series_id: str,
    window: int = 20,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Rolling + GARCH(1,1) conditional volatility, annualised.

    Args:
        series_id: Series to analyse, e.g. "PET.RWTC.D"
        window: Rolling window (default 20)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "window": window}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("volatility", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    current = result.get("current", {})
    lines = [f"Volatility for {series_id}:"]
    lines.append(f"  Rolling vol ({window}): {current.get('rolling_vol', 0):.4f}")
    if "garch_vol" in current:
        lines.append(f"  GARCH vol: {current.get('garch_vol', 0):.4f}")
    lines.append(f"  Frequency: {current.get('frequency', '?')}")
    lines.append(f"  Annualised factor: {current.get('annualised_factor', 0)}")
    return "\n".join(lines)


@mcp.tool()
def correlation(
    series_ids: list[str],
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Pairwise correlation matrix for multiple series.

    Args:
        series_ids: List of series IDs (at least 2)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_ids}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("correlation", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    labels = result.get("labels", [])
    matrix = result.get("matrix", [])
    lines = [f"Correlation ({result.get('observations', 0)} observations):"]
    header = "".ljust(25) + "  ".join([l[:10].rjust(10) for l in labels])
    lines.append(header)
    for i, label in enumerate(labels):
        row = label[:25].ljust(25) + "  ".join([f"{matrix[i][j]:.4f}".rjust(10) for j in range(len(labels))])
        lines.append(row)
    return "\n".join(lines)


@mcp.tool()
def unit_root(
    series_id: str,
    test: str = "all",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Unit root tests — is this series stationary? (ADF, KPSS, Phillips-Perron)

    Args:
        series_id: Series to test, e.g. "PET.RWTC.D"
        test: adf, kpss, pp, or all (default)
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_id, "test": test}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("unit_root", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Unit root tests for {series_id}:"]
    lines.append(f"Consensus: {result.get('consensus', '?')}")
    for name, t in result.get("tests", {}).items():
        lines.append(f"  {name.upper()}: stat={t.get('statistic', 0):.4f}, p={t.get('p_value', 0):.4f}, stationary={t.get('stationary', '?')}")
    return "\n".join(lines)


@mcp.tool()
def cointegration(
    series_ids: list[str],
    method: str = "johansen",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Cointegration test — do these series move together long-term?

    Args:
        series_ids: List of series IDs (at least 2)
        method: johansen (default) or engle-granger
        start: Start date (YYYY-MM-DD)
        end: End date
    """
    req = {"series": series_ids, "method": method}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("cointegration", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"

    lines = [f"Cointegration ({method}): {'COINTEGRATED' if result.get('cointegrated') else 'Not cointegrated'}"]
    lines.append(f"Observations: {result.get('observations', 0)}")
    if "trace_tests" in result:
        for t in result["trace_tests"]:
            lines.append(f"  {t['hypothesis']}: stat={t['trace_stat']:.2f}, cv95={t['cv_95']:.2f}, reject={t.get('reject_95', '?')}")
    return "\n".join(lines)


@mcp.tool()
def transform(
    series_id: str,
    operation: str = "diff",
    window: int = 5,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Time series transform: diff, pct, log, logdiff, lag, ma, ema, cumsum, zscore.

    Args:
        series_id: Series to transform
        operation: diff, pct, log, logdiff, lag, ma, ema, cumsum, zscore
        window: Window size for ma/ema/lag (default 5)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "operation": operation, "window": window}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("transform", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    rows = result.get("rows", [])
    lines = [f"Transform: {operation} (window={result.get('window', '')})", f"{len(rows)} data points"]
    for r in rows[-5:]:
        lines.append(f"  {r['period']}: {r['original']} → {r['result']}")
    return "\n".join(lines)


@mcp.tool()
def smooth(
    series_id: str,
    horizon: int = 12,
    method: str = "ets",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Exponential smoothing forecast (single, double, Holt-Winters, ETS auto).

    Args:
        series_id: Series to forecast
        horizon: Periods ahead (default 12)
        method: single, double, holt-winters, ets (default)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "horizon": horizon, "method": method}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("smooth", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"Smooth: {result.get('method', '?')} (AIC={result.get('aic', '?')})"]
    for f in result.get("forecast", []):
        lines.append(f"  {f['period']}: {f['forecast']:.2f}")
    return "\n".join(lines)


@mcp.tool()
def hp_filter(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Boosted Hodrick-Prescott filter — trend vs cycle decomposition.

    Args:
        series_id: Series to decompose
        start: Start date
        end: End date
    """
    req = {"series": series_id, "boosted": True}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("hp_filter", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    rows = result.get("rows", [])
    lines = [f"HP Filter: lambda={result.get('lambda')}, boosted={result.get('boosted')}, iterations={result.get('iterations')}", f"{len(rows)} data points"]
    for r in rows[-5:]:
        lines.append(f"  {r['period']}: observed={r['observed']}, trend={r['trend']}, cycle={r['cycle']}")
    return "\n".join(lines)


@mcp.tool()
def bandpass(
    series_id: str,
    low: int = 6,
    high: int = 32,
    method: str = "cf",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Band-pass filter — extract cycles at specific frequencies (Baxter-King or Christiano-Fitzgerald).

    Args:
        series_id: Series to filter
        low: Min cycle length in periods (default 6)
        high: Max cycle length (default 32)
        method: bk or cf (default)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "low": low, "high": high, "method": method}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("bandpass", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    rows = result.get("rows", [])
    lines = [f"Band-pass: {result.get('method')} (cycle {low}–{high} periods)", f"{len(rows)} data points"]
    for r in rows[-5:]:
        lines.append(f"  {r['period']}: cycle={r['cycle']}, trend={r['trend']}")
    return "\n".join(lines)


@mcp.tool()
def seasonality(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Seasonal decomposition — trend, seasonal, and residual components.

    Args:
        series_id: Series to decompose
        start: Start date
        end: End date
    """
    req = {"series": series_id}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("seasonality", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    rows = result.get("rows", [])
    lines = [f"Seasonality: {result.get('model')} (period={result.get('period')})", f"{len(rows)} data points"]
    for r in rows[-5:]:
        lines.append(f"  {r['period']}: trend={r['trend']}, seasonal={r['seasonal']}, residual={r['residual']}")
    return "\n".join(lines)


@mcp.tool()
def interpolate(
    series_id: str,
    method: str = "linear",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Fill missing values using interpolation (linear, log-linear, spline, cardinal).

    Args:
        series_id: Series to interpolate
        method: linear (default), log-linear, spline, cardinal
        start: Start date
        end: End date
    """
    req = {"series": series_id, "method": method}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("interpolate", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    return f"Interpolate ({result.get('method')}): {result.get('gaps_filled')} gaps filled out of {result.get('total_points')} points"


@mcp.tool()
def outliers(
    series_id: str,
    method: str = "zscore",
    threshold: float = 3.0,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Detect outliers using Z-score, IQR, or Isolation Forest.

    Args:
        series_id: Series to analyse
        method: zscore (default), iqr, isolation_forest
        threshold: Detection threshold (default 3.0)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "method": method, "threshold": threshold}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("outliers", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"Outliers ({method}, threshold={threshold}): {result.get('outlier_count')} of {result.get('total_points')} ({result.get('outlier_pct', 0):.1f}%)"]
    for o in result.get("outliers", []):
        lines.append(f"  {o['period']}: {o['value']}")
    return "\n".join(lines)


@mcp.tool()
def returns(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Log returns, cumulative returns, and drawdown analysis.

    Args:
        series_id: Series to analyse
        start: Start date
        end: End date
    """
    req = {"series": series_id}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("returns", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    s = result.get("summary", {})
    lines = [
        f"Returns for {series_id}:",
        f"  Total return: {s.get('total_return_pct', 0):.2f}%",
        f"  Max drawdown: {s.get('max_drawdown_pct', 0):.2f}% ({s.get('max_drawdown_peak')} → {s.get('max_drawdown_trough')})",
        f"  Avg daily return: {s.get('avg_daily_return', 0):.6f}",
        f"  Volatility: {s.get('volatility', 0):.4f}",
        f"  Positive periods: {s.get('positive_periods', 0)}, Negative: {s.get('negative_periods', 0)}",
    ]
    return "\n".join(lines)


@mcp.tool()
def elastic_net(
    series_ids: list[str],
    target: str,
    alpha: float = 1.0,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Elastic net regression — variable selection for predicting a target series.

    Args:
        series_ids: All series (target + predictors)
        target: Series to predict
        alpha: Regularisation strength (default 1.0)
        start: Start date
        end: End date
    """
    req = {"series": series_ids, "target": target, "alpha": alpha, "l1_ratio": 0.5}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("elastic_net", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"Elastic Net: R²={result.get('r_squared', 0):.4f}, {result.get('n_selected')}/{result.get('n_predictors')} selected"]
    for c in result.get("coefficients", []):
        sel = " *" if c.get("selected") else ""
        lines.append(f"  {c['series']}: {c['coefficient']:.4f}{sel}")
    return "\n".join(lines)


@mcp.tool()
def quantile_reg(
    series_id: str,
    lags: int = 1,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Quantile autoregression — conditional quantile estimates for tail risk analysis.

    Args:
        series_id: Series to analyse
        lags: Number of lags (default 1)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "lags": lags}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("quantile_reg", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"Quantile Regression (lags={lags}, obs={result.get('observations')}):"]
    lines.append(f"  Last value: {result.get('last_value')}")
    for q, est in result.get("current_estimates", {}).items():
        lines.append(f"  Q{q}: {est}")
    return "\n".join(lines)


@mcp.tool()
def bubble_test(
    series_id: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """GSADF test for explosive bubbles (Phillips, Shi & Yu 2015).

    Args:
        series_id: Series to test
        start: Start date
        end: End date
    """
    req = {"series": series_id}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("bubble_test", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"GSADF: {result.get('gsadf', 0):.4f} (cv95={result.get('cv_95', 0):.4f})",
        f"Bubble detected: {result.get('bubble_detected', False)}",
        f"Episodes: {result.get('n_episodes', 0)}",
    ]
    for ep in result.get("episodes", []):
        lines.append(f"  {ep['start']} – {ep['end']} ({ep['duration']} periods)")
    return "\n".join(lines)


@mcp.tool()
def lpirf(
    series_ids: list[str],
    shock: str,
    response: str,
    horizons: int = 20,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Local Projection Impulse Response (Jordà 2005) — non-parametric IRF.

    Args:
        series_ids: All series involved (shock + response + controls)
        shock: Shock series ID
        response: Response series ID
        horizons: Number of horizons (default 20)
        start: Start date
        end: End date
    """
    req = {"series": series_ids, "shock": shock, "response": response, "horizons": horizons}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("lpirf", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"LPIRF: {shock} → {response} (obs={result.get('observations')})"]
    for pt in result.get("irf", []):
        resp = pt.get('response')
        if resp is not None:
            lines.append(f"  h={pt['horizon']}: {resp:.6f}  [{pt.get('ci_lower', 0):.6f} – {pt.get('ci_upper', 0):.6f}]")
    return "\n".join(lines)


@mcp.tool()
def midas(
    low_freq_series: str,
    high_freq_series: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """MIDAS mixed-frequency volatility — use high-freq data to forecast low-freq vol.

    Args:
        low_freq_series: Low-frequency series (e.g. monthly)
        high_freq_series: High-frequency series (e.g. daily)
        start: Start date
        end: End date
    """
    req = {"low_freq_series": low_freq_series, "high_freq_series": high_freq_series}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("midas", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"MIDAS: {result.get('freq_high')} → {result.get('freq_low')}",
        f"  Current vol: {result.get('current_vol', 0):.4f}",
        f"  Forecast vol: {result.get('forecast_vol', 0):.4f}",
        f"  Observations: {result.get('observations')}",
    ]
    return "\n".join(lines)


@mcp.tool()
def var(
    series_ids: list[str],
    lags: Optional[int] = None,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Vector Autoregression with impulse response and Granger causality.

    Args:
        series_ids: List of series IDs (at least 2)
        lags: Lag order (None = auto-select by AIC)
        start: Start date
        end: End date
    """
    req = {"series": series_ids}
    if lags: req["lags"] = lags
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("var", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"VAR: lags={result.get('lags')}, AIC={result.get('aic', 0):.1f}, obs={result.get('observations')}"]
    if result.get("granger_causality"):
        lines.append("Granger causality:")
        for pair, gc in result["granger_causality"].items():
            sig = " *" if gc.get("significant") else ""
            lines.append(f"  {pair}: p={gc.get('p_value', 0):.4f}{sig}")
    return "\n".join(lines)


@mcp.tool()
def acf(
    series_id: str,
    nlags: int = 20,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Autocorrelation (ACF), partial autocorrelation (PACF), and Ljung-Box Q-stats.

    Args:
        series_id: Series to analyse
        nlags: Number of lags (default 20)
        start: Start date
        end: End date
    """
    req = {"series": series_id, "nlags": nlags}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("acf", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"ACF/PACF ({result.get('observations')} obs, band=±{result.get('confidence_band', 0):.4f}):"]
    for r in result.get("rows", [])[:nlags + 1]:
        sig = " *" if r.get("significant") else ""
        lines.append(f"  lag {r['lag']}: ACF={r['acf']:.4f}, PACF={r.get('pacf', '')}{sig}")
    if result.get("q_stats"):
        lines.append("Ljung-Box Q:")
        for lag, qs in result["q_stats"].items():
            lines.append(f"  lag {lag}: Q={qs['q_stat']:.2f}, p={qs['p_value']:.4f}")
    return "\n".join(lines)


@mcp.tool()
def spread(
    series_a: str,
    series_b: str,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Spread analysis between two series — spread, z-score, percentile, half-life.

    Args:
        series_a: First series (e.g. PET.RBRTE.D for Brent)
        series_b: Second series (e.g. PET.RWTC.D for WTI)
        start: Start date
        end: End date
    """
    req = {"series_a": series_a, "series_b": series_b}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("spread", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"Spread: {series_a} - {series_b}",
        f"  Current: {result.get('current_spread', 0):.2f}",
        f"  Mean: {result.get('mean', 0):.2f}, Std: {result.get('std', 0):.2f}",
        f"  Range: {result.get('min', 0):.2f} to {result.get('max', 0):.2f}",
        f"  Z-score: {result.get('zscore', 0):.2f}",
        f"  Percentile: {result.get('percentile', 0):.1f}%",
        f"  Half-life: {result.get('half_life', 'N/A')} periods",
        f"  Observations: {result.get('observations', 0)}",
    ]
    return "\n".join(lines)


@mcp.tool()
def rolling_correlation(
    series_a: str,
    series_b: str,
    window: int = 52,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Rolling window correlation between two series — shows how relationships shift over time.

    Args:
        series_a: First series
        series_b: Second series
        window: Rolling window size (default 52)
        start: Start date
        end: End date
    """
    req = {"series_a": series_a, "series_b": series_b, "window": window}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("rolling_correlation", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"Rolling Correlation: {series_a} vs {series_b} (window={window})",
        f"  Overall: {result.get('overall_correlation', 0):.4f}",
        f"  Current: {result.get('current_correlation', 0):.4f}",
        f"  Range: {result.get('min_correlation', 0):.4f} to {result.get('max_correlation', 0):.4f}",
        f"  Mean: {result.get('mean_correlation', 0):.4f}",
        f"  Observations: {result.get('observations', 0)}",
    ]
    return "\n".join(lines)


@mcp.tool()
def chart(
    series_ids: list[str],
    start: Optional[str] = None,
    end: Optional[str] = None,
    width: int = 30,
) -> str:
    """ASCII sparkline charts for one or more series — quick visual in text.

    Args:
        series_ids: Series to chart
        start: Start date
        end: End date
        width: Chart width in characters (default 30)
    """
    lines = []
    for sid in series_ids:
        try:
            req = {"series": [sid]}
            if start: req["start"] = start
            if end: req["end"] = end
            table = do_get([sid], start, end)
            values = [float(table.column("value")[i].as_py()) for i in range(table.num_rows)
                      if table.column("value")[i].as_py() is not None]
            if not values:
                lines.append(f"{sid}: no data")
                continue
            spark = sparkline(values, width)
            mn = min(values)
            mx = max(values)
            cur = values[-1]
            lines.append(f"{sid}")
            lines.append(f"  {spark}  {cur:.2f}")
            lines.append(f"  {'L:'+str(round(mn,2)):>10s}{'':>{width-20}}{'H:'+str(round(mx,2)):>10s}")
        except Exception as e:
            lines.append(f"{sid}: error ({e})")
    return "\n".join(lines)


@mcp.tool()
def snd_balance(
    production: Optional[str] = "PET.WCRFPUS2.W",
    imports: Optional[str] = "PET.WCEIMUS2.W",
    exports: Optional[str] = "PET.WCREXUS2.W",
    refinery_input: Optional[str] = "PET.WCRRIUS2.W",
    stocks: Optional[str] = "PET.WCESTUS1.W",
    adjustments: Optional[str] = None,
    pinned: Optional[dict] = None,
    forecast_horizon: int = 4,
    start: Optional[str] = None,
) -> str:
    """US crude oil supply & demand balance with scenario analysis.

    Computes: Supply (production + imports) - Demand (refinery input + exports) = Stock Change.
    Forecasts each component with Theta, or use pinned values for scenarios.

    Args:
        production: Production series (default US weekly)
        imports: Imports series
        exports: Exports series
        refinery_input: Refinery input series (proxy for demand)
        stocks: Stocks series (for comparison)
        adjustments: Optional adjustment series
        pinned: Pin any component at a fixed value, e.g. {"production": 13660}
        forecast_horizon: Weeks ahead (default 4)
        start: Start date for historical view
    """
    components = {
        "production": production,
        "imports": imports,
        "exports": exports,
        "refinery_input": refinery_input,
        "stocks": stocks,
    }
    if adjustments:
        components["adjustments"] = adjustments

    # Get latest values for all components
    series_ids = [v for v in components.values() if v]
    latest_result = do_action("latest", json.dumps({"series": series_ids}))
    latest_map = {r["series_id"]: r for r in latest_result if "error" not in r}

    lines = []
    lines.append("US CRUDE OIL S&D BALANCE")
    lines.append("=" * 50)

    # Current balance
    lines.append("\nCURRENT (latest available):")
    vals = {}
    for name, sid in components.items():
        if sid and sid in latest_map:
            v = latest_map[sid].get("value", 0) or 0
            period = latest_map[sid].get("period", "?")
            vals[name] = float(v)
            lines.append(f"  {name:20s}  {v:>12,.0f}  ({period})  {latest_map[sid].get('units','')}")

    prod = vals.get("production", 0)
    imp = vals.get("imports", 0)
    exp = vals.get("exports", 0)
    ref = vals.get("refinery_input", 0)
    adj = vals.get("adjustments", 0)

    supply = prod + imp
    demand = ref + exp
    balance = supply - demand + adj
    lines.append(f"  {'---':20s}  {'---':>12s}")
    lines.append(f"  {'Supply (P+I)':20s}  {supply:>12,.0f}")
    lines.append(f"  {'Demand (R+E)':20s}  {demand:>12,.0f}")
    lines.append(f"  {'Balance':20s}  {balance:>+12,.0f}  {'(build)' if balance > 0 else '(draw)'}")

    # Forecast / scenario
    if pinned or forecast_horizon > 0:
        lines.append(f"\nSCENARIO ({forecast_horizon} periods ahead):")
        if pinned:
            lines.append(f"  Pinned: {pinned}")

        # Forecast each component
        fc_vals = {}
        for name, sid in components.items():
            if not sid or name == "stocks":
                continue
            if pinned and name in pinned:
                fc_vals[name] = float(pinned[name])
                lines.append(f"  {name:20s}  {fc_vals[name]:>12,.0f}  (PINNED)")
            else:
                try:
                    result = do_action("theta", json.dumps({"series": sid, "horizon": forecast_horizon}))
                    if "error" not in result and result.get("forecast"):
                        # Average of forecast values
                        avg = sum(f["forecast"] for f in result["forecast"]) / len(result["forecast"])
                        fc_vals[name] = avg
                        lines.append(f"  {name:20s}  {avg:>12,.0f}  (Theta forecast)")
                except:
                    fc_vals[name] = vals.get(name, 0)
                    lines.append(f"  {name:20s}  {fc_vals[name]:>12,.0f}  (unchanged)")

        fc_supply = fc_vals.get("production", 0) + fc_vals.get("imports", 0)
        fc_demand = fc_vals.get("refinery_input", 0) + fc_vals.get("exports", 0)
        fc_adj = fc_vals.get("adjustments", 0)
        fc_balance = fc_supply - fc_demand + fc_adj

        lines.append(f"  {'---':20s}  {'---':>12s}")
        lines.append(f"  {'Fcast Supply':20s}  {fc_supply:>12,.0f}")
        lines.append(f"  {'Fcast Demand':20s}  {fc_demand:>12,.0f}")
        lines.append(f"  {'Fcast Balance':20s}  {fc_balance:>+12,.0f}  {'(build)' if fc_balance > 0 else '(draw)'}")

        # Implied stock change
        current_stocks = vals.get("stocks", 0)
        implied_stocks = current_stocks + fc_balance * forecast_horizon
        lines.append(f"\n  Implied stocks in {forecast_horizon} periods: {implied_stocks:,.0f}")
        lines.append(f"  Stock change: {fc_balance * forecast_horizon:+,.0f}")

    lines.append(f"\n{'=' * 50}")
    return "\n".join(lines)


@mcp.tool()
def report(
    series_ids: list[str],
    sections: Optional[list[str]] = None,
    lookback_days: int = 7,
    forecast_horizon: int = 12,
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Generate a market report — runs a battery of analytics on the given series.

    Sections: prices, changes, spreads, fundamentals, forecast, volatility, correlations, breakpoints.
    Defaults to all sections. This is a meta-tool that calls multiple analytics in one shot.

    Args:
        series_ids: Series to analyse (e.g. ["PET.RWTC.D", "PET.RBRTE.D", "PET.WCESTUS1.W"])
        sections: Which sections to include (default: all)
        lookback_days: Lookback for change detection (default 7)
        forecast_horizon: Periods for forecasts (default 12)
        start: Training window start date (YYYY-MM-DD). Applied to spread, correlation,
               volatility, breakpoints. Omitting uses full history.
        end: Training window end date (YYYY-MM-DD).
    """
    if sections is None:
        sections = ["prices", "changes", "spreads", "forecast", "volatility", "correlations", "breakpoints"]

    # Common window params for analytics sub-calls
    def _win(extra=None):
        d = dict(extra or {})
        if start: d["start"] = start
        if end: d["end"] = end
        return d

    report_parts = []
    report_parts.append(f"ENERGYSCOPE MARKET REPORT")
    report_parts.append(f"Series: {', '.join(series_ids)}")
    if start or end:
        report_parts.append(f"Window: {start or 'earliest'} → {end or 'latest'}")
    report_parts.append(f"{'='*60}")

    # Prices — latest values
    if "prices" in sections:
        try:
            result = do_action("latest", json.dumps({"series": series_ids}))
            report_parts.append("\n📊 LATEST PRICES")
            for r in result:
                if "error" not in r:
                    val = r.get("value")
                    report_parts.append(f"  {r['series_id']:40s}  {r.get('period','?'):10s}  {val if val is not None else 'N/A':>10}  {r.get('units',''):15s}  {r.get('name','')[:40]}")
        except: pass

    # Changes — what moved
    if "changes" in sections:
        try:
            result = do_action("changes", json.dumps({"series": series_ids, "lookback_days": lookback_days}))
            report_parts.append(f"\n📈 CHANGES (last {lookback_days} days)")
            for c in result.get("changes", []):
                flag = " ⚠️" if c.get("move_zscore", 0) > 2 else ""
                report_parts.append(f"  {c['series_id']:40s}  {c.get('pct_change',0):+.1f}%  (z={c.get('move_zscore',0):.1f}){flag}")
        except: pass

    # Spreads — if we have pairs
    if "spreads" in sections and len(series_ids) >= 2:
        try:
            result = do_action("spread", json.dumps(_win({"series_a": series_ids[0], "series_b": series_ids[1]})))
            if "error" not in result:
                report_parts.append(f"\n📐 SPREAD: {series_ids[0]} - {series_ids[1]}")
                report_parts.append(f"  Current: {result.get('current_spread', 0):.2f}  Mean: {result.get('mean', 0):.2f}  Z-score: {result.get('zscore', 0):.2f}  Pctl: {result.get('percentile', 0):.0f}%  ({result.get('observations', '?')} obs)")
        except: pass

    # Forecast
    if "forecast" in sections:
        for sid in series_ids[:3]:  # limit to 3 series
            try:
                result = do_action("theta", json.dumps({"series": sid, "horizon": forecast_horizon}))
                if "error" not in result:
                    fc = result.get("forecast", [])
                    if fc:
                        report_parts.append(f"\n🔮 FORECAST: {sid} (Theta, {forecast_horizon} periods)")
                        for f in fc[:3]:
                            report_parts.append(f"  {f['period']}: {f['forecast']:.2f}  [{f.get('ci_lower',0):.2f} – {f.get('ci_upper',0):.2f}]")
                        if len(fc) > 3:
                            report_parts.append(f"  ... {len(fc)} total periods")
            except: pass

    # Volatility
    if "volatility" in sections:
        for sid in series_ids[:3]:
            try:
                result = do_action("volatility", json.dumps(_win({"series": sid, "window": 20})))
                if "error" not in result:
                    cur = result.get("current", {})
                    report_parts.append(f"\n📊 VOLATILITY: {sid}")
                    report_parts.append(f"  Rolling(20): {cur.get('rolling_vol', 0):.4f}  GARCH: {cur.get('garch_vol', 0):.4f}  ({cur.get('frequency','?')}, annualised)")
            except: pass

    # Correlations
    if "correlations" in sections and len(series_ids) >= 2:
        try:
            result = do_action("correlation", json.dumps(_win({"series": series_ids})))
            if "error" not in result:
                report_parts.append(f"\n🔗 CORRELATIONS ({result.get('observations', 0)} obs)")
                labels = result.get("labels", [])
                matrix = result.get("matrix", [])
                for i in range(len(labels)):
                    for j in range(i+1, len(labels)):
                        report_parts.append(f"  {labels[i]} vs {labels[j]}: {matrix[i][j]:.4f}")
        except: pass

    # Breakpoints
    if "breakpoints" in sections:
        for sid in series_ids[:3]:
            try:
                result = do_action("breakpoints", json.dumps(_win({"series": sid, "min_shift": 5})))
                if "error" not in result and result.get("n_breakpoints", 0) > 0:
                    report_parts.append(f"\n⚡ BREAKPOINTS: {sid} (min_shift=$5)")
                    for bp in result.get("breakpoints", [])[-3:]:
                        report_parts.append(f"  {bp['period']}: shift {bp.get('shift',0):+.1f}")
            except: pass

    report_parts.append(f"\n{'='*60}")
    report_parts.append(f"Generated by EnergyScope Analytics Flight Server")
    return "\n".join(report_parts)


@mcp.tool()
def crack_spread(
    ratio: str = "3-2-1",
    crude: str = "PET.RWTC.D",
    gasoline: str = "PET.EER_EPMRU_PF4_RGC_DPG.D",
    distillate: str = "PET.EER_EPD2F_PF4_Y35NY_DPG.D",
    start: Optional[str] = None,
    end: Optional[str] = None,
) -> str:
    """Refining crack spread — 3-2-1, gasoline, or diesel.

    Args:
        ratio: 3-2-1 (default), gasoline, or diesel
        crude: Crude oil series (default WTI)
        gasoline: Gasoline series (default US Gulf Coast)
        distillate: Distillate series (default NY Harbor heating oil)
        start: Start date
        end: End date
    """
    req = {"crude": crude, "gasoline": gasoline, "distillate": distillate, "ratio": ratio}
    if start: req["start"] = start
    if end: req["end"] = end
    result = do_action("crack_spread", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [
        f"{result.get('label', ratio)} ($/bbl):",
        f"  Current: ${result.get('current', 0):.2f}",
        f"  Mean: ${result.get('mean', 0):.2f}, Std: ${result.get('std', 0):.2f}",
        f"  Range: ${result.get('min', 0):.2f} to ${result.get('max', 0):.2f}",
        f"  Z-score: {result.get('zscore', 0):.2f}",
        f"  Observations: {result.get('observations', 0)}",
    ]
    return "\n".join(lines)


@mcp.tool()
def changes(
    series_ids: list[str],
    lookback_days: int = 7,
) -> str:
    """What changed since last week? Detects significant moves across multiple series, ranked by size.

    Args:
        series_ids: List of series to check
        lookback_days: Days to look back (default 7)
    """
    req = {"series": series_ids, "lookback_days": lookback_days}
    result = do_action("changes", json.dumps(req))
    if "error" in result:
        return f"Error: {result['error']}"
    lines = [f"Changes over last {lookback_days} days ({result.get('series_count', 0)} series):"]
    for c in result.get("changes", []):
        direction = "+" if c.get("abs_change", 0) >= 0 else ""
        zscore = c.get("move_zscore", 0)
        flag = " ⚠️" if zscore > 2 else ""
        lines.append(
            f"  {c['series_id']:40s}  {direction}{c.get('pct_change', 0):+.1f}%  "
            f"({c.get('prev_value', '?')} → {c.get('current_value', '?')})  "
            f"z={zscore:.1f}{flag}"
        )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    mcp.run(transport="stdio")
