"""
iceberg_migration/cli.py
========================
CLI entry point for the Iceberg Migration tool.

Usage
-----
    iceberg-migration <tables_file> [--provider aws|minio|gcp]

    # or directly:
    python -m iceberg_migration.cli <tables_file>

``tables_file`` is a plain text file, one entry per line:

    # This is a comment – ignored
    source_db,target_db,orders
    source_db,target_db,customers

Each line has three comma-separated columns: source_db, target_db, table_name.

All configuration is read from a ``.env`` file.
Copy ``.env.example`` → ``.env`` and fill in your values.
"""

import argparse
import logging
import os
import sys
import time
from multiprocessing import Pool

from iceberg_migration.config import MigrationConfig
from iceberg_migration.providers import SUPPORTED_PROVIDERS

# =============================================================================
# Logging
# =============================================================================

os.makedirs("logs", exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  [%(name)s:%(lineno)d]  %(message)s",
    handlers=[
        logging.FileHandler("logs/migration.log", mode="a"),
        logging.StreamHandler(sys.stdout),
    ],
)

logger = logging.getLogger(__name__)


# =============================================================================
# Input parsing
# =============================================================================


def parse_tables_file(file_path: str) -> list[tuple[str, str, str]]:
    """Parse a tables file into a list of ``(source_db, target_db, table)`` tuples.

    Format: one entry per line, three comma-separated columns::

        source_db,target_db,table_name

    - Blank lines and lines starting with ``#`` are ignored.
    - Lines not matching the expected format are logged and skipped.
    """
    tables: list[tuple[str, str, str]] = []

    with open(file_path) as fh:
        for line_number, raw_line in enumerate(fh, start=1):
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue

            parts = [p.strip() for p in line.split(",")]
            if len(parts) != 3:
                logger.warning(
                    "Line %d: expected 'source_db,target_db,table_name', got %r – skipped",
                    line_number,
                    line,
                )
                continue

            tables.append((parts[0], parts[1], parts[2]))

    return tables


# =============================================================================
# Per-table worker  (runs inside a child process)
# =============================================================================


def migrate_one_table(args: tuple[str, str, str, str]) -> None:
    """Migrate a single Iceberg table from source to target.

    This function is the unit of work executed by each worker process.
    It loads its own config so every child process is fully self-contained.

    Parameters
    ----------
    args:
        ``(source_database, target_database, table_name, provider)`` tuple.
    """
    source_database, target_database, table_name, provider = args
    fqn = f"{source_database}.{table_name} → {target_database}.{table_name}"
    start = time.time()

    logger.info("──── START   %s  [%s] ────", fqn, provider)

    try:
        from iceberg_migration.migrator import TableMigrator
        from iceberg_migration.providers import build_provider

        migration_config = MigrationConfig.from_env()
        source, target = build_provider(
            provider, source_database, target_database, table_name, migration_config
        )
        TableMigrator(source, target).run()

        logger.info("──── DONE    %s  (%.1fs) ────", fqn, time.time() - start)

    except Exception as exc:
        logger.error("──── FAILED  %s: %s ────", fqn, exc, exc_info=True)


# =============================================================================
# Entry point
# =============================================================================


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Migrate Apache Iceberg V2 tables across cloud accounts."
    )
    parser.add_argument(
        "tables_file",
        help="Path to a text file listing tables as 'source_db,target_db,table_name', one per line.",
    )
    parser.add_argument(
        "--provider",
        choices=SUPPORTED_PROVIDERS,
        default="aws",
        help="Cloud provider to use (default: aws).",
    )
    args = parser.parse_args()

    if not os.path.isfile(args.tables_file):
        print(f"Error: file not found: {args.tables_file}", file=sys.stderr)
        sys.exit(1)

    tables = parse_tables_file(args.tables_file)
    if not tables:
        logger.warning("No valid tables found in '%s'. Nothing to do.", args.tables_file)
        return

    migration_config = MigrationConfig.from_env()
    logger.info(
        "Provider: %s | Migrating %d table(s) with %d parallel worker(s)",
        args.provider,
        len(tables),
        migration_config.parallel_tables,
    )

    work_items = [(src_db, tgt_db, tbl, args.provider) for src_db, tgt_db, tbl in tables]
    with Pool(processes=migration_config.parallel_tables) as pool:
        pool.map(migrate_one_table, work_items)

    logger.info("All done.")


if __name__ == "__main__":
    main()
