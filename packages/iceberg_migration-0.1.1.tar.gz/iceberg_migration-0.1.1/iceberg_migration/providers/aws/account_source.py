"""
iceberg_migration/providers/aws/account_source.py

AWS implementation of IcebergSourceAccount.

Downloads every Iceberg file for one table from the source S3 bucket,
rewrites all bucket references to point at the target bucket, and saves
the patched files locally under a ``new/`` working directory.

Migration pipeline  (AWSSourceAccount.execute)
-----------------------------------------------
Step 1  Download and patch the metadata JSON.
        Side-effect: records manifest-list URIs for the current snapshot.
Step 2  Scan each manifest-list Avro.
        Side-effect: records manifest URIs.
Step 3  Scan each manifest Avro.
        Side-effect: records delete-file URIs.
Step 4  Download all delete files in parallel.
Step 5  Patch each delete-file Parquet (stream row-batches to save RAM).
Step 6  Patch each manifest Avro (update paths + delete-file sizes).
Step 7  Patch each manifest-list Avro (update paths + manifest lengths).

Local directory layout produced
--------------------------------
<cwd>/<database>/<table>/old/metadata/  original downloads
<cwd>/<database>/<table>/new/metadata/  patched copies
<cwd>/<database>/<table>/old/data/...   original delete files
<cwd>/<database>/<table>/new/data/...   patched delete files
"""

import json
import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, cast
from urllib.parse import urlparse

import boto3
import pyarrow as pa
import pyarrow.parquet as pq
from fastavro import reader as avro_reader
from fastavro import writer as avro_writer
from pyiceberg.catalog import load_catalog

from iceberg_migration.base import IcebergSourceAccount
from iceberg_migration.config import MigrationConfig
from iceberg_migration.constants import (
    IcebergContentType,
    IcebergManifest,
    IcebergManifestList,
    IcebergMetadata,
    LocalDir,
)
from iceberg_migration.providers.aws.config import AWSSourceConfig, AWSTargetConfig
from iceberg_migration.utils import (
    replace_bucket,
    replace_bucket_in_avro_bounds,
    replace_buckets_in_json,
)

_JSON_INDENT = 2  # match the indentation pyiceberg uses when writing metadata files

logger = logging.getLogger(__name__)


# =============================================================================
# AWSSourceAccount
# =============================================================================


class AWSSourceAccount(IcebergSourceAccount):
    """Downloads and patches Iceberg table files from the source AWS account.

    Parameters
    ----------
    database_name:
        Glue database that contains the table.
    table_name:
        Name of the Iceberg table.
    source_config:
        Credentials for the source AWS account.
    target_config:
        Target account config — ``target_config.s3_bucket`` is the bucket
        name written into every patched file.
    migration_config:
        Thread counts and batch sizes for parallel processing.
    """

    def __init__(
        self,
        database_name: str,
        table_name: str,
        source_config: AWSSourceConfig,
        target_config: AWSTargetConfig,
        migration_config: MigrationConfig,
    ):
        self.database_name = database_name
        self.table_name = table_name
        self._src: AWSSourceConfig = source_config
        self._migration = migration_config

        self._catalog = self._build_catalog()
        self._iceberg_table = self._catalog.load_table(f"{database_name}.{table_name}")

        # Source bucket is discovered automatically from the table location.
        # Target bucket is always explicit — never derived from a prefix.
        _location = urlparse(self._iceberg_table.location())
        self.source_bucket: str = _location.netloc
        self._scheme: str = _location.scheme  # "s3" for AWS, "s3a" when written by Spark
        self.target_bucket: str = target_config.s3_bucket

        self._current_snapshot_id = self._iceberg_table.metadata.current_snapshot_id

        # Populated step-by-step during execute()
        self._manifest_list_uris: list[str] = []
        self._manifest_uris: list[str] = []
        self._delete_file_uris: set[str] = set()

        # Size tracking so manifest-length fields stay accurate after patching
        self._delete_file_sizes: dict[str, int] = {}  # target S3 URI → bytes
        self._manifest_file_sizes: dict[str, int] = {}  # filename       → bytes

    # -------------------------------------------------------------------------
    # IcebergSourceAccount interface
    # -------------------------------------------------------------------------

    def execute(self) -> None:
        """Run the full download-and-patch pipeline for this table."""
        fqn = f"{self.database_name}.{self.table_name}"
        logger.info("=== Source: start  %s ===", fqn)

        self._step1_patch_metadata_json()
        self._step2_scan_manifest_lists()
        self._step3_scan_manifests()

        logger.info(
            "%s discovered → %d manifest-list(s), %d manifest(s), %d delete-file(s)",
            fqn,
            len(self._manifest_list_uris),
            len(self._manifest_uris),
            len(self._delete_file_uris),
        )

        failures = {
            "delete-file": self._run_parallel(
                self._process_delete_file,
                list(self._delete_file_uris),
                "delete-file",
            ),
            "manifest": self._run_parallel(
                lambda uri: self._patch_manifest(
                    self._download(uri, f"{LocalDir.OLD}/{LocalDir.METADATA}")
                ),
                self._manifest_uris,
                "manifest",
            ),
            "manifest-list": self._run_parallel(
                lambda uri: self._patch_manifest_list(
                    self._download(uri, f"{LocalDir.OLD}/{LocalDir.METADATA}")
                ),
                self._manifest_list_uris,
                "manifest-list",
            ),
        }

        for step, failed_items in failures.items():
            if failed_items:
                logger.warning("[%s] %d item(s) failed: %s", step, len(failed_items), failed_items)

        logger.info("=== Source: done   %s ===", fqn)

    def get_catalog_table(self) -> dict:
        """Return the raw Glue ``get_table`` response for the source table.

        The target account uses this as a template when registering the table
        in the destination Glue catalog.
        """
        response: dict = self._boto3_client("glue").get_table(
            DatabaseName=self.database_name,
            Name=self.table_name,
        )
        return response

    # -------------------------------------------------------------------------
    # AWS clients and Iceberg catalog
    # -------------------------------------------------------------------------

    def _boto3_client(self, service: str):
        return boto3.client(
            service,
            aws_access_key_id=self._src.access_key_id,
            aws_secret_access_key=self._src.secret_access_key,
            region_name=self._src.region,
        )

    def _build_catalog(self):
        return load_catalog(
            catalog_name=self._src.glue_catalog,
            **{
                "type": "glue",
                "glue.region": self._src.region,
                "glue.access-key-id": self._src.access_key_id,
                "glue.secret-access-key": self._src.secret_access_key,
                # S3 credentials — required so pyiceberg can read the metadata
                # JSON when load_table() resolves the metadata_location from Glue.
                "s3.region": self._src.region,
                "s3.access-key-id": self._src.access_key_id,
                "s3.secret-access-key": self._src.secret_access_key,
            },
        )

    # -------------------------------------------------------------------------
    # Path helpers
    # -------------------------------------------------------------------------

    def _replace(self, path: str) -> str:
        return replace_bucket(path, self.source_bucket, self.target_bucket, scheme=self._scheme)

    def _local_path(self, s3_uri: str, sub_dir: str) -> str:
        filename = os.path.basename(s3_uri)
        return os.path.join(os.getcwd(), self.database_name, self.table_name, sub_dir, filename)

    # -------------------------------------------------------------------------
    # S3 download
    # -------------------------------------------------------------------------

    def _download(self, s3_uri: str, sub_dir: str) -> str:
        """Download *s3_uri* from the source bucket to a local path.

        Always reads from ``self.source_bucket`` regardless of what bucket
        name appears in the URI, so both old and new URIs resolve to the same
        S3 key.  Skips the download when the file already exists locally.
        """
        local = self._local_path(s3_uri, sub_dir)
        if os.path.exists(local):
            return local

        os.makedirs(os.path.dirname(local), exist_ok=True)
        s3_key = urlparse(s3_uri).path.lstrip("/")
        logger.info("Downloading  s3://%s/%s", self.source_bucket, s3_key)
        self._boto3_client("s3").download_file(self.source_bucket, s3_key, local)
        return local

    # -------------------------------------------------------------------------
    # Step 1 – Metadata JSON
    # -------------------------------------------------------------------------

    def _step1_patch_metadata_json(self) -> None:
        """Patch the current metadata JSON and all historical metadata files
        referenced in its ``metadata-log``.

        The ``metadata-log`` lists every previous metadata version.  When data
        files are synced to the target bucket (e.g. via ``mc mirror`` or
        ``aws s3 sync``) those older files land there unmodified — still
        pointing at the source bucket.  Patching all of them ensures:
          - time-travel queries work correctly from the target account
          - every file in the target metadata/ prefix is self-consistent

        The original (pre-replacement) URIs are saved so we can download the
        Avro files from the source bucket in subsequent steps.
        """
        local = self._download(
            self._iceberg_table.metadata_location,
            f"{LocalDir.OLD}/{LocalDir.METADATA}",
        )
        with open(local) as fh:
            metadata = json.load(fh)

        # Collect manifest-list URIs BEFORE replacing paths
        for snapshot in metadata.get(IcebergMetadata.SNAPSHOTS, []):
            manifest_list_uri = snapshot.get(IcebergMetadata.MANIFEST_LIST, "")
            is_current_snapshot = str(self._current_snapshot_id) in manifest_list_uri
            if manifest_list_uri and is_current_snapshot:
                self._manifest_list_uris.append(manifest_list_uri)

        # Collect historical metadata file URIs BEFORE replacing paths
        historical_uris = [
            entry[IcebergMetadata.METADATA_FILE]
            for entry in metadata.get(IcebergMetadata.METADATA_LOG, [])
            if IcebergMetadata.METADATA_FILE in entry
        ]

        replace_buckets_in_json(
            metadata, self.source_bucket, self.target_bucket, scheme=self._scheme
        )

        patched = local.replace(f"/{LocalDir.OLD}/", f"/{LocalDir.NEW}/")
        os.makedirs(os.path.dirname(patched), exist_ok=True)
        with open(patched, "w") as fh:
            json.dump(metadata, fh, indent=_JSON_INDENT)

        logger.info("Patched metadata JSON  →  %s", patched)

        # Patch every historical metadata file so the target is fully consistent
        for uri in historical_uris:
            self._patch_historical_metadata_json(uri)

    def _patch_historical_metadata_json(self, s3_uri: str) -> None:
        """Download and patch a historical metadata JSON file from ``metadata-log``.

        These files are only needed for time-travel queries but must reference
        the target bucket — not the source — once the table has been migrated.
        """
        local = self._download(s3_uri, f"{LocalDir.OLD}/{LocalDir.METADATA}")
        with open(local) as fh:
            metadata = json.load(fh)

        replace_buckets_in_json(
            metadata, self.source_bucket, self.target_bucket, scheme=self._scheme
        )

        patched = local.replace(f"/{LocalDir.OLD}/", f"/{LocalDir.NEW}/")
        os.makedirs(os.path.dirname(patched), exist_ok=True)
        with open(patched, "w") as fh:
            json.dump(metadata, fh, indent=_JSON_INDENT)

        logger.info("Patched historical metadata  →  %s", patched)

    # -------------------------------------------------------------------------
    # Step 2 – Manifest-list scanning
    # -------------------------------------------------------------------------

    def _step2_scan_manifest_lists(self) -> None:
        """Read each manifest-list Avro and collect the URI of every manifest
        file it references."""
        for uri in self._manifest_list_uris:
            local = self._download(uri, f"{LocalDir.OLD}/{LocalDir.METADATA}")
            with open(local, "rb") as fh:
                for _record in avro_reader(fh):
                    record = cast(dict[str, Any], _record)
                    if IcebergManifestList.MANIFEST_PATH in record:
                        self._manifest_uris.append(record[IcebergManifestList.MANIFEST_PATH])

    # -------------------------------------------------------------------------
    # Step 3 – Manifest scanning (collect delete files)
    # -------------------------------------------------------------------------

    def _step3_scan_manifests(self) -> None:
        """Read each manifest Avro and collect the URI of every positional
        delete file it references."""
        for uri in self._manifest_uris:
            local = self._download(uri, f"{LocalDir.OLD}/{LocalDir.METADATA}")
            with open(local, "rb") as fh:
                for _record in avro_reader(fh):
                    record = cast(dict[str, Any], _record)
                    data_file = record.get(IcebergManifest.DATA_FILE, {})
                    is_delete_file = (
                        data_file.get(IcebergManifest.CONTENT) == IcebergContentType.POSITION_DELETE
                    )
                    if is_delete_file and IcebergManifest.FILE_PATH in data_file:
                        self._delete_file_uris.add(data_file[IcebergManifest.FILE_PATH])

    # -------------------------------------------------------------------------
    # Steps 4 + 5 – Delete file download and Parquet patching
    # -------------------------------------------------------------------------

    def _patch_delete_parquet(self, old_local: str) -> int:
        """Stream-patch the ``file_path`` column in a positional-delete Parquet.

        Reads in batches of ``migration_config.batch_size`` rows to avoid
        loading the whole file into memory.  Returns the patched file size.
        """
        patched = old_local.replace(f"/{LocalDir.OLD}/", f"/{LocalDir.NEW}/")
        if os.path.exists(patched):
            return os.path.getsize(patched)

        os.makedirs(os.path.dirname(patched), exist_ok=True)
        parquet_file = pq.ParquetFile(old_local)
        schema = parquet_file.schema.to_arrow_schema()
        writer = pq.ParquetWriter(patched, schema=schema, compression="zstd", version="1.0")

        for batch in parquet_file.iter_batches(batch_size=self._migration.batch_size):
            df = batch.to_pandas()
            if IcebergManifest.FILE_PATH in df.columns:
                df[IcebergManifest.FILE_PATH] = df[IcebergManifest.FILE_PATH].apply(self._replace)
            writer.write_table(pa.Table.from_pandas(df, schema=schema))

        writer.close()
        size = os.path.getsize(patched)
        logger.info("Patched delete file  →  %s  (%s bytes)", patched, f"{size:,}")
        return size

    def _process_delete_file(self, s3_uri: str) -> None:
        """Download one delete file and patch it.  Records the new size so
        manifest files can reference an accurate ``file_size_in_bytes``."""
        parts = s3_uri.split("/")
        data_index = parts.index(LocalDir.DATA)
        relative_dir = "/".join(parts[data_index + 1 : -1])

        old_local = self._download(s3_uri, f"{LocalDir.OLD}/{LocalDir.DATA}/{relative_dir}")
        patched_size = self._patch_delete_parquet(old_local)
        self._delete_file_sizes[self._replace(s3_uri)] = patched_size

    # -------------------------------------------------------------------------
    # Step 6 – Manifest Avro patching
    # -------------------------------------------------------------------------

    def _patch_manifest(self, old_local: str) -> None:
        """Rewrite all S3 paths inside a manifest Avro.

        Also updates ``file_size_in_bytes`` for delete-file entries using
        the sizes measured in step 5.
        """
        patched = old_local.replace(f"/{LocalDir.OLD}/", f"/{LocalDir.NEW}/")
        os.makedirs(os.path.dirname(patched), exist_ok=True)

        records = []
        with open(old_local, "rb") as fh:
            avro = avro_reader(fh)
            schema = avro.writer_schema

            for _record in avro:
                record = cast(dict[str, Any], _record)
                data_file = record.get(IcebergManifest.DATA_FILE, {})

                if IcebergManifest.FILE_PATH in data_file:
                    is_delete = (
                        data_file.get(IcebergManifest.CONTENT) == IcebergContentType.POSITION_DELETE
                    )
                    if is_delete:
                        target_uri = self._replace(data_file[IcebergManifest.FILE_PATH])
                        if target_uri in self._delete_file_sizes:
                            data_file[IcebergManifest.FILE_SIZE_IN_BYTES] = self._delete_file_sizes[
                                target_uri
                            ]
                    data_file[IcebergManifest.FILE_PATH] = self._replace(
                        data_file[IcebergManifest.FILE_PATH]
                    )

                replace_bucket_in_avro_bounds(
                    record, self.source_bucket, self.target_bucket, scheme=self._scheme
                )
                records.append(record)

        with open(patched, "wb") as fh:
            avro_writer(fh, schema, records)

        size = os.path.getsize(patched)
        self._manifest_file_sizes[os.path.basename(patched)] = size
        logger.info("Patched manifest  →  %s  (%s bytes)", patched, f"{size:,}")

    # -------------------------------------------------------------------------
    # Step 7 – Manifest-list Avro patching
    # -------------------------------------------------------------------------

    def _patch_manifest_list(self, old_local: str) -> None:
        """Rewrite all S3 paths in a manifest-list Avro and update the
        ``manifest_length`` field for each entry."""
        patched = old_local.replace(f"/{LocalDir.OLD}/", f"/{LocalDir.NEW}/")
        os.makedirs(os.path.dirname(patched), exist_ok=True)

        records = []
        with open(old_local, "rb") as fh:
            avro = avro_reader(fh)
            schema = avro.writer_schema

            for _record in avro:
                record = cast(dict[str, Any], _record)
                if IcebergManifestList.MANIFEST_PATH in record:
                    filename = os.path.basename(record[IcebergManifestList.MANIFEST_PATH])
                    if filename in self._manifest_file_sizes:
                        record[IcebergManifestList.MANIFEST_LENGTH] = self._manifest_file_sizes[
                            filename
                        ]
                    record[IcebergManifestList.MANIFEST_PATH] = self._replace(
                        record[IcebergManifestList.MANIFEST_PATH]
                    )
                records.append(record)

        with open(patched, "wb") as fh:
            avro_writer(fh, schema, records)

        logger.info("Patched manifest-list  →  %s", patched)

    # -------------------------------------------------------------------------
    # Parallel execution
    # -------------------------------------------------------------------------

    def _run_parallel(self, task_fn, items: list, step_name: str) -> list[str]:
        """Execute *task_fn(item)* concurrently for every item.
        Returns a list of items that raised an exception."""
        failed: list[str] = []
        with ThreadPoolExecutor(max_workers=self._migration.number_threads) as pool:
            futures = {pool.submit(task_fn, item): item for item in items}
            for future in as_completed(futures):
                item = futures[future]
                try:
                    future.result()
                except Exception as exc:
                    logger.error("[%s] failed for %s: %s", step_name, item, exc)
                    failed.append(item)
        return failed
