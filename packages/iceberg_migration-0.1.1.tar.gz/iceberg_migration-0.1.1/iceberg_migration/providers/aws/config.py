"""
iceberg_migration/providers/aws/config.py

AWS-specific configuration — credentials and catalog settings for both the
source and target AWS accounts.

All values are read from environment variables (loaded from .env).
Copy .env.example → .env and fill in the required values before running.
"""

import os
from dataclasses import dataclass
from typing import Optional

from dotenv import load_dotenv

load_dotenv()

_REQUIRED_SOURCE = (
    "SOURCE_AWS_REGION",
    "SOURCE_AWS_ACCESS_KEY_ID",
    "SOURCE_AWS_SECRET_ACCESS_KEY",
)
_REQUIRED_TARGET = (
    "TARGET_AWS_REGION",
    "TARGET_AWS_ACCESS_KEY_ID",
    "TARGET_AWS_SECRET_ACCESS_KEY",
    "TARGET_S3_BUCKET",
)


def _require(var: str) -> str:
    value = os.getenv(var)
    if not value:
        raise OSError(
            f"Required environment variable '{var}' is not set. "
            "Copy .env.example → .env and fill in the missing values."
        )
    return value


@dataclass(frozen=True)
class AWSSourceConfig:
    """Credentials and catalog settings for the SOURCE AWS account.

    Environment variables
    ---------------------
    SOURCE_AWS_REGION               AWS region of the source account.
    SOURCE_AWS_ACCESS_KEY_ID        Access key for the source account.
    SOURCE_AWS_SECRET_ACCESS_KEY    Secret key for the source account.
    SOURCE_GLUE_CATALOG             Glue catalog name (default: awsdatacatalog).
    """

    region: str
    access_key_id: str
    secret_access_key: str
    glue_catalog: str

    @classmethod
    def from_env(cls) -> "AWSSourceConfig":
        return cls(
            region=_require("SOURCE_AWS_REGION"),
            access_key_id=_require("SOURCE_AWS_ACCESS_KEY_ID"),
            secret_access_key=_require("SOURCE_AWS_SECRET_ACCESS_KEY"),
            glue_catalog=os.getenv("SOURCE_GLUE_CATALOG", "awsdatacatalog"),
        )


@dataclass(frozen=True)
class AWSTargetConfig:
    """Credentials, catalog settings, and storage for the TARGET AWS account.

    Environment variables
    ---------------------
    TARGET_AWS_REGION               AWS region of the target account.
    TARGET_AWS_ACCESS_KEY_ID        Access key for the target account.
    TARGET_AWS_SECRET_ACCESS_KEY    Secret key for the target account.
    TARGET_AWS_SESSION_TOKEN        Session token (optional, for temporary creds).
    TARGET_S3_BUCKET                Destination S3 bucket name (explicit, required).
    TARGET_GLUE_CATALOG             Glue catalog name (default: awsdatacatalog).
    """

    region: str
    access_key_id: str
    secret_access_key: str
    s3_bucket: str
    glue_catalog: str
    session_token: Optional[str]

    @classmethod
    def from_env(cls) -> "AWSTargetConfig":
        return cls(
            region=_require("TARGET_AWS_REGION"),
            access_key_id=_require("TARGET_AWS_ACCESS_KEY_ID"),
            secret_access_key=_require("TARGET_AWS_SECRET_ACCESS_KEY"),
            s3_bucket=_require("TARGET_S3_BUCKET"),
            glue_catalog=os.getenv("TARGET_GLUE_CATALOG", "awsdatacatalog"),
            session_token=os.getenv("TARGET_AWS_SESSION_TOKEN") or None,
        )
