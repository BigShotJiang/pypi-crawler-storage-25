"""
iceberg_migration/providers/aws/account_target.py

AWS implementation of IcebergTargetAccount.

Uploads the patched Iceberg files to the target S3 bucket and registers
the table in the target Glue catalog.

Steps  (AWSTargetAccount.execute)
----------------------------------
Step 1  upload_files()    – upload new/metadata/ and new/data/ to S3.
Step 2  register_table()  – create the table entry in the target Glue catalog.
"""

import logging
import os
from urllib.parse import urlparse

import boto3

from iceberg_migration.base import IcebergTargetAccount
from iceberg_migration.config import MigrationConfig
from iceberg_migration.constants import GlueTableKey, LocalDir
from iceberg_migration.providers.aws.config import AWSTargetConfig
from iceberg_migration.utils import replace_bucket

logger = logging.getLogger(__name__)


# =============================================================================
# Stateless helper functions
# =============================================================================


def list_files_recursive(directory: str) -> list[str]:
    """Return the absolute path of every file under *directory*."""
    all_files: list[str] = []
    for root, _, files in os.walk(directory):
        for filename in files:
            all_files.append(os.path.join(root, filename))
    return all_files


# =============================================================================
# AWSTargetAccount
# =============================================================================


class AWSTargetAccount(IcebergTargetAccount):
    """Uploads patched Iceberg files and registers the table in the target
    AWS Glue catalog.

    Parameters
    ----------
    source_database_name:
        Source database name — used to locate the patched files on the local
        filesystem (``<cwd>/<source_database_name>/<table_name>/new/...``).
    target_database_name:
        Target Glue database name — used when registering the table in the
        destination catalog.
    table_name:
        Name of the Iceberg table.
    source_glue_table:
        Raw ``glue.get_table()["Table"]`` dict from the source account.
        Used as a template; all S3 paths are rewritten to the target bucket
        before the table is created in the destination catalog.
    source_bucket:
        Source S3 bucket name.  Pass ``AWSSourceAccount.source_bucket``.
    target_config:
        Credentials and explicit bucket name for the target AWS account.
    migration_config:
        Shared performance settings.
    """

    def __init__(
        self,
        source_database_name: str,
        target_database_name: str,
        table_name: str,
        source_glue_table: dict,
        source_bucket: str,
        target_config: AWSTargetConfig,
        migration_config: MigrationConfig,
    ):
        self.source_database_name = source_database_name
        self.database_name = target_database_name  # kept for backward-compat logging
        self.table_name = table_name
        self._glue_table = source_glue_table
        self._tgt: AWSTargetConfig = target_config
        self._migration = migration_config

        self.source_bucket = source_bucket
        self.target_bucket = target_config.s3_bucket  # always explicit

        metadata_loc = source_glue_table.get(GlueTableKey.PARAMETERS, {}).get(
            GlueTableKey.METADATA_LOCATION, ""
        )
        self._scheme: str = urlparse(metadata_loc).scheme if metadata_loc else "s3"

    # -------------------------------------------------------------------------
    # IcebergTargetAccount interface
    # -------------------------------------------------------------------------

    def execute(self) -> None:
        """Upload files to S3 then register the table in the target Glue catalog."""
        fqn = f"{self.database_name}.{self.table_name}"
        logger.info("=== Target: start  %s ===", fqn)
        self.upload_files()
        self.register_table()
        logger.info("=== Target: done   %s ===", fqn)

    # -------------------------------------------------------------------------
    # AWS client
    # -------------------------------------------------------------------------

    def _boto3_client(self, service: str):
        return boto3.client(
            service,
            aws_access_key_id=self._tgt.access_key_id,
            aws_secret_access_key=self._tgt.secret_access_key,
            aws_session_token=self._tgt.session_token,
            region_name=self._tgt.region,
        )

    # -------------------------------------------------------------------------
    # Path helpers
    # -------------------------------------------------------------------------

    def _replace(self, path: str) -> str:
        return replace_bucket(path, self.source_bucket, self.target_bucket, scheme=self._scheme)

    def _table_s3_prefix(self) -> str:
        """Derive the S3 key prefix for the table root inside the target bucket.

        Example
        -------
        metadata_location = s3://target/mydb/orders/metadata/v3.metadata.json
        table prefix      = mydb/orders
        """
        parameters = self._glue_table[GlueTableKey.PARAMETERS]
        target_metadata_location = self._replace(parameters[GlueTableKey.METADATA_LOCATION])
        return urlparse(target_metadata_location).path.lstrip("/").rsplit("/", 2)[0]

    # -------------------------------------------------------------------------
    # Glue table input
    # -------------------------------------------------------------------------

    def _build_glue_table_input(self) -> dict:
        """Build the Glue ``TableInput`` dict with all S3 paths rewritten to
        the target bucket.  The original source dict is never mutated."""
        parameters = dict(self._glue_table.get(GlueTableKey.PARAMETERS, {}))
        storage = dict(self._glue_table[GlueTableKey.STORAGE_DESCRIPTOR])

        parameters[GlueTableKey.METADATA_LOCATION] = self._replace(
            parameters[GlueTableKey.METADATA_LOCATION]
        )

        if GlueTableKey.PREVIOUS_METADATA_LOCATION in parameters:
            parameters[GlueTableKey.PREVIOUS_METADATA_LOCATION] = self._replace(
                parameters[GlueTableKey.PREVIOUS_METADATA_LOCATION]
            )

        if GlueTableKey.LOCATION in storage:
            storage[GlueTableKey.LOCATION] = self._replace(storage[GlueTableKey.LOCATION])

        if GlueTableKey.ADDITIONAL_LOCATIONS in storage:
            storage[GlueTableKey.ADDITIONAL_LOCATIONS] = [
                self._replace(loc) if f"{self._scheme}://" in loc else loc
                for loc in storage[GlueTableKey.ADDITIONAL_LOCATIONS]
            ]

        return {
            GlueTableKey.NAME: self.table_name,
            GlueTableKey.STORAGE_DESCRIPTOR: storage,
            GlueTableKey.TABLE_TYPE: self._glue_table[GlueTableKey.TABLE_TYPE],
            GlueTableKey.PARAMETERS: parameters,
        }

    # -------------------------------------------------------------------------
    # S3 upload
    # -------------------------------------------------------------------------

    def _upload_directory(self, local_dir: str, s3_prefix: str) -> None:
        """Upload every file under *local_dir* to *s3_prefix* in the target
        bucket, preserving the subdirectory structure."""
        if not os.path.isdir(local_dir):
            logger.warning("Upload skipped – directory not found: %s", local_dir)
            return

        s3 = self._boto3_client("s3")
        for local_file in list_files_recursive(local_dir):
            relative_path = os.path.relpath(local_file, local_dir)
            s3_key = os.path.join(s3_prefix, relative_path)
            s3.upload_file(Filename=local_file, Bucket=self.target_bucket, Key=s3_key)
            logger.info("Uploaded  %s  →  s3://%s/%s", local_file, self.target_bucket, s3_key)

    def upload_files(self) -> None:
        """Upload the patched ``metadata/`` and ``data/`` sub-trees to S3."""
        prefix = self._table_s3_prefix()
        new_root = os.path.join(
            os.getcwd(), self.source_database_name, self.table_name, LocalDir.NEW
        )
        self._upload_directory(
            local_dir=os.path.join(new_root, LocalDir.METADATA),
            s3_prefix=os.path.join(prefix, LocalDir.METADATA),
        )
        self._upload_directory(
            local_dir=os.path.join(new_root, LocalDir.DATA),
            s3_prefix=os.path.join(prefix, LocalDir.DATA),
        )

    # -------------------------------------------------------------------------
    # Glue registration
    # -------------------------------------------------------------------------

    def register_table(self) -> None:
        """Create the table entry in the target Glue catalog."""
        self._boto3_client("glue").create_table(
            DatabaseName=self.database_name,
            TableInput=self._build_glue_table_input(),
        )
        logger.info(
            "Glue table registered: %s.%s  →  s3://%s",
            self.database_name,
            self.table_name,
            self.target_bucket,
        )
