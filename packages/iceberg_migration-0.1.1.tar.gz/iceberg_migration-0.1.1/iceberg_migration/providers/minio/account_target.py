"""
iceberg_migration/providers/minio/account_target.py

MinIO + Hive Metastore implementation of IcebergTargetAccount.

Inherits the S3 upload logic from AWSTargetAccount.
Three things differ from the AWS implementation:

  _boto3_client()    → adds endpoint_url for local MinIO
  _table_s3_prefix() → reads from the plain catalog dict (no Glue envelope)
  register_table()   → uses pyiceberg catalog.register_table() (instead of Glue)

Requires: pyiceberg[hive]  (adds the Thrift client for HMS)
"""

import logging
from urllib.parse import urlparse

import boto3
from pyiceberg.catalog import load_catalog

from iceberg_migration.config import MigrationConfig
from iceberg_migration.providers.aws.account_target import AWSTargetAccount
from iceberg_migration.providers.minio.config import MinIOTargetConfig

logger = logging.getLogger(__name__)


class MinIOTargetAccount(AWSTargetAccount):
    """Uploads patched Iceberg files to MinIO and registers the table in Hive.

    The S3 upload logic (``upload_files``, ``_upload_directory``) is fully
    inherited from AWSTargetAccount; only the endpoint and catalog differ.

    Parameters
    ----------
    source_database_name:
        Source database name — used to locate the patched files on the local
        filesystem (``<cwd>/<source_database_name>/<table_name>/new/...``).
    target_database_name:
        Target Hive database name — used when registering the table in HMS.
    table_name:
        Name of the Iceberg table.
    source_catalog_table:
        Dict returned by ``MinIOSourceAccount.get_catalog_table()``.
        Shape: ``{"metadata_location": "s3://...", "table_location": "s3://..."}``.
    source_bucket:
        Source MinIO bucket name.  Pass ``MinIOSourceAccount.source_bucket``.
    target_config:
        MinIO endpoint + credentials + destination bucket for the target.
    migration_config:
        Shared performance settings.
    """

    def __init__(
        self,
        source_database_name: str,
        target_database_name: str,
        table_name: str,
        source_catalog_table: dict,
        source_bucket: str,
        target_config: MinIOTargetConfig,
        migration_config: MigrationConfig,
    ):
        # Do NOT call super().__init__() — it expects Glue-format source_glue_table.
        self.source_database_name = source_database_name
        self.database_name = target_database_name  # kept for logging
        self.table_name = table_name
        self._catalog_table = source_catalog_table  # plain dict, no Glue envelope
        self._tgt: MinIOTargetConfig = target_config  # type: ignore[assignment]
        self._migration = migration_config
        self.source_bucket = source_bucket
        self.target_bucket = target_config.bucket

        metadata_loc = source_catalog_table.get("metadata_location", "")
        self._scheme: str = urlparse(metadata_loc).scheme if metadata_loc else "s3"

    # -------------------------------------------------------------------------
    # Overrides – transport, prefix derivation, and catalog registration
    # -------------------------------------------------------------------------

    def _boto3_client(self, service: str):
        """boto3 client pointed at the target MinIO endpoint."""
        return boto3.client(
            service,
            endpoint_url=self._tgt.endpoint_url,
            aws_access_key_id=self._tgt.access_key,
            aws_secret_access_key=self._tgt.secret_key,
            region_name="us-east-1",
        )

    def _table_s3_prefix(self) -> str:
        """Derive the S3 key prefix for the table root in the target bucket.

        Reads ``metadata_location`` from the plain catalog dict rather than
        from a Glue ``Parameters`` envelope.

        Example
        -------
        metadata_location = s3://target/mydb/orders/metadata/v3.metadata.json
        table prefix      = mydb/orders
        """
        target_metadata = self._replace(self._catalog_table["metadata_location"])
        return urlparse(target_metadata).path.lstrip("/").rsplit("/", 2)[0]

    def register_table(self) -> None:
        """Register the migrated table in the target Hive Metastore.

        Uses pyiceberg's ``register_table`` which creates a Hive table entry
        pointing at the patched metadata file in the target bucket.
        """
        catalog = load_catalog(
            "hive-target",
            **{
                "type": "hive",
                "uri": self._tgt.hive_uri,
                "s3.endpoint": self._tgt.endpoint_url,
                "s3.access-key-id": self._tgt.access_key,
                "s3.secret-access-key": self._tgt.secret_key,
                "s3.path-style-access": "true",
            },
        )
        target_metadata = self._replace(self._catalog_table["metadata_location"])
        catalog.register_table(
            identifier=(self.database_name, self.table_name),
            metadata_location=target_metadata,
        )
        logger.info(
            "Hive table registered: %s.%s → s3://%s",
            self.database_name,
            self.table_name,
            self.target_bucket,
        )

    # execute(), upload_files(), _upload_directory() are inherited from AWSTargetAccount.
    # They rely only on _boto3_client(), _table_s3_prefix(), and self.target_bucket —
    # all of which are overridden or set correctly above.
