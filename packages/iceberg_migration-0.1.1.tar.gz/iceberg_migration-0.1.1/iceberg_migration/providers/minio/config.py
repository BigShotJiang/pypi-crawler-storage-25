"""
iceberg_migration/providers/minio/config.py

Configuration for MinIO (S3-compatible) + Hive Metastore.

Both source and target can point to the same MinIO instance (different buckets)
or to different instances — each gets its own endpoint URL, credentials,
and Hive Metastore URI.
"""

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


def _require(var: str) -> str:
    value = os.getenv(var)
    if not value:
        raise OSError(
            f"Required environment variable '{var}' is not set. "
            "Copy .env.example → .env and fill in the missing values."
        )
    return value


@dataclass(frozen=True)
class MinIOSourceConfig:
    """Connection settings for the SOURCE MinIO instance.

    Environment variables
    ---------------------
    SOURCE_MINIO_ENDPOINT      MinIO S3 API endpoint (e.g. http://localhost:9000).
    SOURCE_MINIO_ACCESS_KEY    MinIO root user / access key.
    SOURCE_MINIO_SECRET_KEY    MinIO root password / secret key.
    SOURCE_HIVE_URI            Hive Metastore Thrift URI (e.g. thrift://localhost:9083).
    """

    endpoint_url: str
    access_key: str
    secret_key: str
    hive_uri: str

    @classmethod
    def from_env(cls) -> "MinIOSourceConfig":
        return cls(
            endpoint_url=_require("SOURCE_MINIO_ENDPOINT"),
            access_key=_require("SOURCE_MINIO_ACCESS_KEY"),
            secret_key=_require("SOURCE_MINIO_SECRET_KEY"),
            hive_uri=_require("SOURCE_HIVE_URI"),
        )


@dataclass(frozen=True)
class MinIOTargetConfig:
    """Connection settings for the TARGET MinIO instance.

    Environment variables
    ---------------------
    TARGET_MINIO_ENDPOINT      MinIO S3 API endpoint.
    TARGET_MINIO_ACCESS_KEY    MinIO access key.
    TARGET_MINIO_SECRET_KEY    MinIO secret key.
    TARGET_MINIO_BUCKET        Destination bucket name (required, explicit).
    TARGET_HIVE_URI            Hive Metastore Thrift URI for the target catalog.
    """

    endpoint_url: str
    access_key: str
    secret_key: str
    bucket: str
    hive_uri: str

    @classmethod
    def from_env(cls) -> "MinIOTargetConfig":
        return cls(
            endpoint_url=_require("TARGET_MINIO_ENDPOINT"),
            access_key=_require("TARGET_MINIO_ACCESS_KEY"),
            secret_key=_require("TARGET_MINIO_SECRET_KEY"),
            bucket=_require("TARGET_MINIO_BUCKET"),
            hive_uri=_require("TARGET_HIVE_URI"),
        )
