"""
iceberg_migration/providers/minio/account_source.py

MinIO + Hive Metastore implementation of IcebergSourceAccount.

Inherits the full 7-step download-and-patch pipeline from AWSSourceAccount.
Only three things differ from the AWS implementation:

  _boto3_client()   → adds endpoint_url and disables SSL for local MinIO
  _build_catalog()  → Hive Metastore via pyiceberg (instead of Glue)
  get_catalog_table() → returns a plain dict (no Glue envelope)

Requires: pyiceberg[hive]  (adds the Thrift client for HMS)
"""

import logging
from urllib.parse import urlparse

import boto3
from pyiceberg.catalog import load_catalog

from iceberg_migration.config import MigrationConfig
from iceberg_migration.providers.aws.account_source import AWSSourceAccount
from iceberg_migration.providers.minio.config import MinIOSourceConfig, MinIOTargetConfig

logger = logging.getLogger(__name__)


class MinIOSourceAccount(AWSSourceAccount):
    """Downloads and patches Iceberg table files from a MinIO source bucket.

    The 7-step patching pipeline (metadata JSON → manifest-lists → manifests
    → delete files) is fully inherited from AWSSourceAccount.

    Parameters
    ----------
    database_name:
        Hive database containing the table.
    table_name:
        Name of the Iceberg table.
    source_config:
        MinIO endpoint + credentials + Hive URI for the source.
    target_config:
        Target config — ``target_config.bucket`` is written into patched files.
    migration_config:
        Thread counts and batch sizes (shared with other providers).
    """

    def __init__(
        self,
        database_name: str,
        table_name: str,
        source_config: MinIOSourceConfig,
        target_config: MinIOTargetConfig,
        migration_config: MigrationConfig,
    ):
        # Do NOT call super().__init__() — it would try to use Glue/S3 directly.
        # We replicate the same attribute setup with MinIO-specific config instead.
        self.database_name = database_name
        self.table_name = table_name
        self._src: MinIOSourceConfig = source_config  # type: ignore[assignment]
        self._migration = migration_config

        self._catalog = self._build_catalog()
        self._iceberg_table = self._catalog.load_table(f"{database_name}.{table_name}")

        _location = urlparse(self._iceberg_table.location())
        self.source_bucket: str = _location.netloc
        self._scheme: str = _location.scheme
        self.target_bucket: str = target_config.bucket

        self._current_snapshot_id = self._iceberg_table.metadata.current_snapshot_id

        self._manifest_list_uris: list[str] = []
        self._manifest_uris: list[str] = []
        self._delete_file_uris: set[str] = set()
        self._delete_file_sizes: dict[str, int] = {}
        self._manifest_file_sizes: dict[str, int] = {}

    # -------------------------------------------------------------------------
    # Overrides – transport and catalog
    # -------------------------------------------------------------------------

    def _boto3_client(self, service: str):
        """boto3 client pointed at the local MinIO endpoint."""
        return boto3.client(
            service,
            endpoint_url=self._src.endpoint_url,
            aws_access_key_id=self._src.access_key,
            aws_secret_access_key=self._src.secret_key,
            region_name="us-east-1",  # MinIO ignores the region value
        )

    def _build_catalog(self):
        """pyiceberg catalog connected to the Hive Metastore via Thrift."""
        return load_catalog(
            "hive-source",
            **{
                "type": "hive",
                "uri": self._src.hive_uri,
                "s3.endpoint": self._src.endpoint_url,
                "s3.access-key-id": self._src.access_key,
                "s3.secret-access-key": self._src.secret_key,
                "s3.path-style-access": "true",
            },
        )

    def get_catalog_table(self) -> dict:
        """Return Iceberg table metadata for the target account.

        Unlike the AWS implementation (which wraps Glue's get_table response),
        MinIO has no native catalog API — we return a plain dict with just the
        two values the target account needs.
        """
        return {
            "metadata_location": self._iceberg_table.metadata_location,
            "table_location": self._iceberg_table.location(),
        }

    # execute() and all 7 step methods are inherited from AWSSourceAccount.
