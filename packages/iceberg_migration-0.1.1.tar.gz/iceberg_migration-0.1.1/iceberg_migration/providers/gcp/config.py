"""
iceberg_migration/providers/gcp/config.py

GCP-specific configuration — project, credentials, and bucket settings for
both the source and target GCP accounts.

Authentication
--------------
Set ``*_GCP_CREDENTIALS_FILE`` to the path of a service-account JSON key file.
Leave it empty to fall back to Application Default Credentials (ADC), which
works when running inside GCP (Cloud Run, GCE, etc.) or after running
``gcloud auth application-default login`` locally.
"""

import os
from dataclasses import dataclass
from typing import Optional

from dotenv import load_dotenv

load_dotenv()


def _require(var: str) -> str:
    value = os.getenv(var)
    if not value:
        raise OSError(
            f"Required environment variable '{var}' is not set. "
            "Copy .env.example → .env and fill in the missing values."
        )
    return value


@dataclass(frozen=True)
class GCPSourceConfig:
    """Credentials and catalog settings for the SOURCE GCP account.

    Environment variables
    ---------------------
    SOURCE_GCP_PROJECT              GCP project ID of the source account.
    SOURCE_GCP_CREDENTIALS_FILE     Path to a service-account JSON key (optional; uses ADC if empty).
    SOURCE_BQ_LOCATION              BigLake dataset location, e.g. "US" (default: US).
    SOURCE_GCS_CATALOG_URI          pyiceberg REST catalog URI pointing to BigLake.
    """

    project: str
    credentials_file: Optional[str]  # None → use Application Default Credentials
    bq_location: str
    catalog_uri: str

    @classmethod
    def from_env(cls) -> "GCPSourceConfig":
        return cls(
            project=_require("SOURCE_GCP_PROJECT"),
            credentials_file=os.getenv("SOURCE_GCP_CREDENTIALS_FILE") or None,
            bq_location=os.getenv("SOURCE_BQ_LOCATION", "US"),
            catalog_uri=_require("SOURCE_GCS_CATALOG_URI"),
        )


@dataclass(frozen=True)
class GCPTargetConfig:
    """Credentials and storage settings for the TARGET GCP account.

    Environment variables
    ---------------------
    TARGET_GCP_PROJECT              GCP project ID of the target account.
    TARGET_GCS_BUCKET               Destination GCS bucket name (required).
    TARGET_GCP_CREDENTIALS_FILE     Path to a service-account JSON key (optional; uses ADC if empty).
    TARGET_BQ_LOCATION              BigLake dataset location (default: US).
    TARGET_GCS_CATALOG_URI          pyiceberg REST catalog URI for the target.
    """

    project: str
    gcs_bucket: str
    credentials_file: Optional[str]
    bq_location: str
    catalog_uri: str

    @classmethod
    def from_env(cls) -> "GCPTargetConfig":
        return cls(
            project=_require("TARGET_GCP_PROJECT"),
            gcs_bucket=_require("TARGET_GCS_BUCKET"),
            credentials_file=os.getenv("TARGET_GCP_CREDENTIALS_FILE") or None,
            bq_location=os.getenv("TARGET_BQ_LOCATION", "US"),
            catalog_uri=_require("TARGET_GCS_CATALOG_URI"),
        )
