"""
iceberg_migration/providers/gcp/account_source.py

GCP implementation of IcebergSourceAccount (Google Cloud Storage + BigLake).

Status: NOT YET IMPLEMENTED
----------------------------
This file is a structured stub.  The class signature, constructor, and
helper skeletons are defined so the provider factory and tests can reference
GCPSourceAccount without import errors.  Calling ``execute()`` or
``get_catalog_table()`` raises NotImplementedError.

Implementation notes for when this is completed
------------------------------------------------
- URI scheme  : gs://
- Download    : google.cloud.storage.Client().bucket(...).blob(...).download_to_filename(...)
- Catalog     : pyiceberg REST catalog pointed at BigLake Metastore
- Path patch  : replace_bucket(..., scheme="gs") from iceberg_migration.utils
- Steps 1–7   : identical pipeline to AWSSourceAccount; only _download() differs

Required packages (add to pyproject.toml dependencies when implementing)
------------------------------------------------------------------------
    google-cloud-storage>=2.16
    google-auth>=2.29
"""

import logging

from iceberg_migration.base import IcebergSourceAccount
from iceberg_migration.config import MigrationConfig
from iceberg_migration.providers.gcp.config import GCPSourceConfig, GCPTargetConfig

logger = logging.getLogger(__name__)

URI_SCHEME = "gs"


class GCPSourceAccount(IcebergSourceAccount):
    """Downloads and patches Iceberg table files from a GCS source bucket.

    Parameters
    ----------
    database_name:
        BigLake / Hive database (dataset) containing the table.
    table_name:
        Name of the Iceberg table.
    source_config:
        Credentials and project for the source GCP account.
    target_config:
        Target config — ``target_config.gcs_bucket`` is written into patched files.
    migration_config:
        Thread counts and batch sizes (shared with other providers).
    """

    def __init__(
        self,
        database_name: str,
        table_name: str,
        source_config: GCPSourceConfig,
        target_config: GCPTargetConfig,
        migration_config: MigrationConfig,
    ):
        self.database_name = database_name
        self.table_name = table_name
        self._src = source_config
        self._tgt = target_config
        self._migration = migration_config

        # Will be set after catalog load:
        self.source_bucket: str = ""
        self.target_bucket: str = target_config.gcs_bucket

    # -------------------------------------------------------------------------
    # IcebergSourceAccount interface
    # -------------------------------------------------------------------------

    def execute(self) -> None:
        raise NotImplementedError(
            "GCPSourceAccount.execute() is not yet implemented.\n"
            "See the implementation notes in providers/gcp/account_source.py."
        )

    def get_catalog_table(self) -> dict:
        raise NotImplementedError(
            "GCPSourceAccount.get_catalog_table() is not yet implemented.\n"
            "This should return BigLake table metadata in a format that "
            "GCPTargetAccount.execute() can consume."
        )

    # -------------------------------------------------------------------------
    # Helpers (to be implemented)
    # -------------------------------------------------------------------------

    def _gcs_client(self):
        """Return an authenticated google.cloud.storage.Client.

        Example implementation::

            from google.cloud import storage
            from google.oauth2 import service_account

            if self._src.credentials_file:
                creds = service_account.Credentials.from_service_account_file(
                    self._src.credentials_file
                )
                return storage.Client(project=self._src.project, credentials=creds)
            return storage.Client(project=self._src.project)  # ADC
        """
        raise NotImplementedError

    def _build_catalog(self):
        """Return a pyiceberg catalog pointed at the source BigLake Metastore.

        Example implementation::

            from pyiceberg.catalog import load_catalog

            return load_catalog(
                "biglake-source",
                **{
                    "type": "rest",
                    "uri": self._src.catalog_uri,
                    "credential": self._src.credentials_file or "",
                },
            )
        """
        raise NotImplementedError

    def _download(self, gcs_uri: str, sub_dir: str) -> str:
        """Download *gcs_uri* from the source bucket to a local path.

        Example implementation::

            local = self._local_path(gcs_uri, sub_dir)
            if os.path.exists(local):
                return local
            os.makedirs(os.path.dirname(local), exist_ok=True)
            parsed = urlparse(gcs_uri)
            key = parsed.path.lstrip("/")
            self._gcs_client().bucket(self.source_bucket).blob(key).download_to_filename(local)
            return local
        """
        raise NotImplementedError
