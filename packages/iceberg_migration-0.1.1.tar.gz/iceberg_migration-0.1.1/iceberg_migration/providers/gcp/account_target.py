"""
iceberg_migration/providers/gcp/account_target.py

GCP implementation of IcebergTargetAccount (Google Cloud Storage + BigLake).

Status: NOT YET IMPLEMENTED
----------------------------
Calling ``execute()`` raises NotImplementedError.

Implementation notes for when this is completed
------------------------------------------------
- Upload      : google.cloud.storage.Client().bucket(...).blob(...).upload_from_filename(...)
- Register    : BigLake REST API or pyiceberg catalog.create_table()
- Path prefix : gs://<target_bucket>/<database>/<table>/

Required packages (add to pyproject.toml dependencies when implementing)
------------------------------------------------------------------------
    google-cloud-storage>=2.16
    google-auth>=2.29
"""

import logging

from iceberg_migration.base import IcebergTargetAccount
from iceberg_migration.config import MigrationConfig
from iceberg_migration.providers.gcp.config import GCPTargetConfig

logger = logging.getLogger(__name__)


class GCPTargetAccount(IcebergTargetAccount):
    """Uploads patched Iceberg files and registers the table in the target
    GCP catalog (BigLake Metastore).

    Parameters
    ----------
    source_database_name:
        Source database name — used to locate patched files on the local
        filesystem (``<cwd>/<source_database_name>/<table_name>/new/...``).
    target_database_name:
        Target BigLake / Hive database name — used when registering the table.
    table_name:
        Name of the Iceberg table.
    source_catalog_table:
        Raw catalog metadata from GCPSourceAccount.get_catalog_table().
        Used as a template when registering in the target catalog.
    source_bucket:
        Source GCS bucket name.  Pass ``GCPSourceAccount.source_bucket``.
    target_config:
        Credentials and bucket for the target GCP account.
    migration_config:
        Shared performance settings.
    """

    def __init__(
        self,
        source_database_name: str,
        target_database_name: str,
        table_name: str,
        source_catalog_table: dict,
        source_bucket: str,
        target_config: GCPTargetConfig,
        migration_config: MigrationConfig,
    ):
        self.source_database_name = source_database_name
        self.database_name = target_database_name  # kept for logging
        self.table_name = table_name
        self._catalog_table = source_catalog_table
        self.source_bucket = source_bucket
        self._tgt = target_config
        self._migration = migration_config
        self.target_bucket = target_config.gcs_bucket

    # -------------------------------------------------------------------------
    # IcebergTargetAccount interface
    # -------------------------------------------------------------------------

    def execute(self) -> None:
        raise NotImplementedError(
            "GCPTargetAccount.execute() is not yet implemented.\n"
            "See the implementation notes in providers/gcp/account_target.py."
        )

    # -------------------------------------------------------------------------
    # Helpers (to be implemented)
    # -------------------------------------------------------------------------

    def _gcs_client(self):
        """Return an authenticated google.cloud.storage.Client.

        Example implementation::

            from google.cloud import storage
            from google.oauth2 import service_account

            if self._tgt.credentials_file:
                creds = service_account.Credentials.from_service_account_file(
                    self._tgt.credentials_file
                )
                return storage.Client(project=self._tgt.project, credentials=creds)
            return storage.Client(project=self._tgt.project)  # ADC
        """
        raise NotImplementedError

    def _upload_directory(self, local_dir: str, gcs_prefix: str) -> None:
        """Upload every file under *local_dir* to *gcs_prefix* in the target bucket.

        Example implementation::

            import os
            client = self._gcs_client()
            bucket = client.bucket(self.target_bucket)
            for root, _, files in os.walk(local_dir):
                for filename in files:
                    local_file = os.path.join(root, filename)
                    relative = os.path.relpath(local_file, local_dir)
                    blob_name = os.path.join(gcs_prefix, relative)
                    bucket.blob(blob_name).upload_from_filename(local_file)
                    logger.info("Uploaded %s → gs://%s/%s", local_file, self.target_bucket, blob_name)
        """
        raise NotImplementedError

    def register_table(self) -> None:
        """Register the table in the target BigLake catalog.

        Example implementation::

            from pyiceberg.catalog import load_catalog

            catalog = load_catalog(
                "biglake-target",
                **{"type": "rest", "uri": self._tgt.catalog_uri, ...},
            )
            # Build schema and partition spec from source_catalog_table metadata,
            # then call catalog.create_table(...)
        """
        raise NotImplementedError
