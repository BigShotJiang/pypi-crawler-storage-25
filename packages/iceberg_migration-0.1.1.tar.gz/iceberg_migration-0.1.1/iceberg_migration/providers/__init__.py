# Providers expose cloud-specific implementations of IcebergSourceAccount
# and IcebergTargetAccount.
#
# Available providers
# -------------------
# aws   – Amazon Web Services (S3 + Glue catalog)
# minio – MinIO (self-hosted S3-compatible object storage)
#
# Stub providers (not yet implemented)
# -------------------------------------
# gcp   – Google Cloud Storage + BigLake Metastore
# azure – Azure Data Lake Storage + Unity Catalog

from iceberg_migration.base import IcebergSourceAccount, IcebergTargetAccount
from iceberg_migration.config import MigrationConfig

SUPPORTED_PROVIDERS = ("aws", "gcp", "minio")


def build_provider(
    provider: str,
    source_database_name: str,
    target_database_name: str,
    table_name: str,
    migration_config: MigrationConfig,
) -> tuple[IcebergSourceAccount, IcebergTargetAccount]:
    """Factory: build a (source, target) pair for the requested cloud provider.

    Parameters
    ----------
    provider:
        One of ``"aws"``, ``"gcp"``, ``"minio"``.
    source_database_name:
        Database name in the source catalog.
    target_database_name:
        Database name in the target catalog (may differ from source).
    table_name:
        The Iceberg table to migrate.
    migration_config:
        Shared performance settings (parallel workers, batch size, etc.).

    Returns
    -------
    (source, target)
        Ready to pass to ``TableMigrator(source, target).run()``.

    Raises
    ------
    ValueError
        If *provider* is not in SUPPORTED_PROVIDERS.
    """
    if provider == "aws":
        from iceberg_migration.providers.aws.account_source import AWSSourceAccount
        from iceberg_migration.providers.aws.account_target import AWSTargetAccount
        from iceberg_migration.providers.aws.config import AWSSourceConfig, AWSTargetConfig

        source_config = AWSSourceConfig.from_env()
        target_config = AWSTargetConfig.from_env()

        source = AWSSourceAccount(
            database_name=source_database_name,
            table_name=table_name,
            source_config=source_config,
            target_config=target_config,
            migration_config=migration_config,
        )
        target = AWSTargetAccount(
            source_database_name=source_database_name,
            target_database_name=target_database_name,
            table_name=table_name,
            source_glue_table=source.get_catalog_table()["Table"],
            source_bucket=source.source_bucket,
            target_config=target_config,
            migration_config=migration_config,
        )
        return source, target

    if provider == "gcp":
        from iceberg_migration.providers.gcp.account_source import GCPSourceAccount
        from iceberg_migration.providers.gcp.account_target import GCPTargetAccount
        from iceberg_migration.providers.gcp.config import GCPSourceConfig, GCPTargetConfig

        gcp_src_cfg = GCPSourceConfig.from_env()
        gcp_tgt_cfg = GCPTargetConfig.from_env()

        gcp_source = GCPSourceAccount(
            database_name=source_database_name,
            table_name=table_name,
            source_config=gcp_src_cfg,
            target_config=gcp_tgt_cfg,
            migration_config=migration_config,
        )
        gcp_target = GCPTargetAccount(
            source_database_name=source_database_name,
            target_database_name=target_database_name,
            table_name=table_name,
            source_catalog_table=gcp_source.get_catalog_table(),
            source_bucket=gcp_source.source_bucket,
            target_config=gcp_tgt_cfg,
            migration_config=migration_config,
        )
        return gcp_source, gcp_target

    if provider == "minio":
        from iceberg_migration.providers.minio.account_source import MinIOSourceAccount
        from iceberg_migration.providers.minio.account_target import MinIOTargetAccount
        from iceberg_migration.providers.minio.config import MinIOSourceConfig, MinIOTargetConfig

        minio_src_cfg = MinIOSourceConfig.from_env()
        minio_tgt_cfg = MinIOTargetConfig.from_env()

        minio_source = MinIOSourceAccount(
            database_name=source_database_name,
            table_name=table_name,
            source_config=minio_src_cfg,
            target_config=minio_tgt_cfg,
            migration_config=migration_config,
        )
        minio_target = MinIOTargetAccount(
            source_database_name=source_database_name,
            target_database_name=target_database_name,
            table_name=table_name,
            source_catalog_table=minio_source.get_catalog_table(),
            source_bucket=minio_source.source_bucket,
            target_config=minio_tgt_cfg,
            migration_config=migration_config,
        )
        return minio_source, minio_target

    raise ValueError(
        f"Unknown provider: {provider!r}. Supported providers: {', '.join(SUPPORTED_PROVIDERS)}"
    )
