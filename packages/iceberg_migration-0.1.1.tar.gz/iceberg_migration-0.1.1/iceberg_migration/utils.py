"""
iceberg_migration/utils.py

Pure utility functions with no cloud-provider dependencies.
Importable without boto3, pyiceberg, or any heavy package installed.

All path-replacement functions accept a ``scheme`` parameter so they work
with any cloud URI format (s3://, gs://, abfs://, etc.).
"""

from iceberg_migration.constants import IcebergManifest


def replace_bucket(path: str, old: str, new: str, scheme: str = "s3") -> str:
    """Swap the bucket name inside a cloud storage URI.

    >>> replace_bucket("s3://old/db/table/snap.avro", "old", "new")
    's3://new/db/table/snap.avro'
    >>> replace_bucket("gs://old/db/table/snap.avro", "old", "new", scheme="gs")
    'gs://new/db/table/snap.avro'
    """
    return path.replace(f"{scheme}://{old}", f"{scheme}://{new}")


def replace_buckets_in_json(node, old: str, new: str, scheme: str = "s3") -> None:
    """Recursively replace *old* bucket with *new* in every string value
    of a nested dict/list structure (used to patch Iceberg metadata JSON).

    Mutates *node* in-place.
    """
    prefix = f"{scheme}://"
    if isinstance(node, dict):
        for key, value in node.items():
            if isinstance(value, str) and prefix in value:
                node[key] = replace_bucket(value, old, new, scheme)
            else:
                replace_buckets_in_json(value, old, new, scheme)
    elif isinstance(node, list):
        for i, item in enumerate(node):
            if isinstance(item, str) and prefix in item:
                node[i] = replace_bucket(item, old, new, scheme)
            else:
                replace_buckets_in_json(item, old, new, scheme)


def replace_bucket_in_avro_bounds(record: dict, old: str, new: str, scheme: str = "s3") -> None:
    """Patch the raw-bytes bucket reference stored inside Iceberg manifest
    ``lower_bounds`` / ``upper_bounds`` column-stats fields."""
    data_file = record.get(IcebergManifest.DATA_FILE, {})
    for bound_key in (IcebergManifest.LOWER_BOUNDS, IcebergManifest.UPPER_BOUNDS):
        for item in data_file.get(bound_key, []):
            raw = item.get(IcebergManifest.BOUNDS_VALUE)
            if isinstance(raw, bytes) and old.encode() in raw:
                item[IcebergManifest.BOUNDS_VALUE] = replace_bucket(
                    raw.decode("utf-8", errors="replace"), old, new, scheme
                ).encode("utf-8")
