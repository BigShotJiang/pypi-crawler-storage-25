"""
iceberg_migration/base.py

Abstract base classes that define the contract every cloud provider must fulfill.

Adding a new provider (e.g. GCP, Azure, MinIO) means creating two classes:
  - A subclass of IcebergSourceAccount  (download + patch files from source)
  - A subclass of IcebergTargetAccount  (upload files + register table at target)

The rest of the codebase — TableMigrator, CLI, etc. — works with these
interfaces and does not need to change when a new provider is added.
"""

from abc import ABC, abstractmethod


class IcebergSourceAccount(ABC):
    """Interface for reading an Iceberg table from a source cloud account.

    Responsibilities
    ----------------
    - Connect to the source catalog and load the Iceberg table.
    - Download all relevant files: metadata JSON, manifest-list, manifest,
      and positional-delete Parquet files.
    - Patch every storage path inside those files so it points to the
      target bucket/container instead of the source one.
    - Save the patched files under a local ``new/`` directory.

    Implementations
    ---------------
    - ``iceberg_migration.providers.aws.AWSSourceAccount``
    - ``iceberg_migration.providers.minio.MinIOSourceAccount``
    - ``iceberg_migration.providers.gcp.GCPSourceAccount``  (stub — not yet implemented)
    """

    #: Set by the constructor after the Iceberg table is loaded.
    #: The target account needs this value to rewrite paths correctly.
    source_bucket: str

    @abstractmethod
    def execute(self) -> None:
        """Download all Iceberg files and patch every storage path."""
        ...

    @abstractmethod
    def get_catalog_table(self) -> dict:
        """Return the raw catalog metadata for the source table.

        The target account uses this as a template when registering the
        table in the destination catalog.  The exact format depends on the
        provider (e.g. a Glue ``get_table`` response for AWS).
        """
        ...


class IcebergTargetAccount(ABC):
    """Interface for writing a migrated Iceberg table to a target cloud account.

    Responsibilities
    ----------------
    - Upload the patched files from the local ``new/`` directory to the
      target storage bucket/container.
    - Register the table in the target catalog so it is immediately queryable.

    Implementations
    ---------------
    - ``iceberg_migration.providers.aws.AWSTargetAccount``
    - ``iceberg_migration.providers.minio.MinIOTargetAccount``
    - ``iceberg_migration.providers.gcp.GCPTargetAccount``  (stub — not yet implemented)
    """

    @abstractmethod
    def execute(self) -> None:
        """Upload patched files and register the table in the target catalog."""
        ...
