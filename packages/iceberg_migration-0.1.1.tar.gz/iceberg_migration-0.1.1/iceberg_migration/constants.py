"""
iceberg_migration/constants.py

Single source of truth for every field name, key, and magic value used
when reading or writing Iceberg files.

Why this matters
----------------
Iceberg stores its state across three file formats (JSON, Avro, Parquet),
each with its own set of fixed field names.  Hard-coding those strings
throughout the codebase makes the code fragile and hard to maintain.
Centralising them here means:
  - a field rename only needs one change
  - IDE auto-complete works on the constants
  - typos are caught at import time, not at runtime
"""


class IcebergMetadata:
    """Field names inside an Iceberg metadata JSON file."""

    SNAPSHOTS = "snapshots"
    MANIFEST_LIST = "manifest-list"  # URI to the manifest-list Avro for a snapshot
    SNAPSHOT_ID = "snapshot-id"
    METADATA_LOG = "metadata-log"  # list of previous metadata file entries
    METADATA_FILE = "metadata-file"  # URI of a previous metadata JSON inside metadata-log


class IcebergManifestList:
    """Field names inside a manifest-list Avro file.

    A manifest-list is the Avro file whose name starts with ``snap-``.
    Each record in it points to one manifest file.
    """

    MANIFEST_PATH = "manifest_path"  # S3 URI of the manifest Avro
    MANIFEST_LENGTH = "manifest_length"  # byte size of the manifest Avro


class IcebergManifest:
    """Field names inside a manifest Avro file.

    Each record in a manifest describes one data file or delete file.
    """

    DATA_FILE = "data_file"  # nested record describing the file
    FILE_PATH = "file_path"  # S3 URI of the data / delete file
    CONTENT = "content"  # see IcebergContentType below
    FILE_SIZE_IN_BYTES = "file_size_in_bytes"
    LOWER_BOUNDS = "lower_bounds"  # list of {column-id, value} pairs
    UPPER_BOUNDS = "upper_bounds"  # list of {column-id, value} pairs
    BOUNDS_VALUE = "value"  # the bytes value inside a bounds item


class IcebergContentType:
    """Possible values for IcebergManifest.CONTENT.

    Defined by the Iceberg V2 spec:
    https://iceberg.apache.org/spec/#manifest-lists
    """

    DATA = 0  # regular data file
    POSITION_DELETE = 1  # positional delete file  ← the one we need to patch
    EQUALITY_DELETE = 2  # equality delete file


class GlueTableKey:
    """Keys inside the dict returned by ``glue.get_table()["Table"]``."""

    NAME = "Name"
    TABLE_TYPE = "TableType"
    STORAGE_DESCRIPTOR = "StorageDescriptor"
    PARAMETERS = "Parameters"

    # Inside StorageDescriptor
    LOCATION = "Location"
    ADDITIONAL_LOCATIONS = "AdditionalLocations"

    # Inside Parameters
    METADATA_LOCATION = "metadata_location"
    PREVIOUS_METADATA_LOCATION = "previous_metadata_location"


class LocalDir:
    """Names of the local working directories created during migration."""

    OLD = "old"  # original files downloaded from the source bucket
    NEW = "new"  # patched files ready to be uploaded to the target bucket
    METADATA = "metadata"
    DATA = "data"
