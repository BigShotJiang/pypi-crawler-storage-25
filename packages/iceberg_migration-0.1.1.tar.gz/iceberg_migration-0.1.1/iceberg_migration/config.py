"""
iceberg_migration/config.py

Provider-agnostic configuration shared by all cloud providers.

Provider-specific configs live alongside their implementations:
    iceberg_migration/providers/aws/config.py  → AWSSourceConfig, AWSTargetConfig
    iceberg_migration/providers/gcp/config.py  → GCPSourceConfig, GCPTargetConfig
"""

import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class MigrationConfig:
    """Performance tuning settings shared by all providers.

    Environment variables
    ---------------------
    PARALLEL_TABLES   Number of tables migrated simultaneously (default: 5).
    NUMBER_THREADS    Threads per table for patching files in parallel (default: 10).
    BATCH_SIZE        Rows per batch when streaming Parquet delete files (default: 500000).
    """

    parallel_tables: int
    number_threads: int
    batch_size: int

    @classmethod
    def from_env(cls) -> "MigrationConfig":
        try:
            parallel_tables = int(os.getenv("PARALLEL_TABLES", "5"))
            number_threads = int(os.getenv("NUMBER_THREADS", "10"))
            batch_size = int(os.getenv("BATCH_SIZE", "500000"))
        except ValueError as exc:
            raise ValueError(
                f"Invalid migration config value: {exc}. "
                "PARALLEL_TABLES, NUMBER_THREADS, and BATCH_SIZE must be integers."
            ) from exc

        if parallel_tables < 1:
            raise ValueError(f"PARALLEL_TABLES must be >= 1, got {parallel_tables}")
        if number_threads < 1:
            raise ValueError(f"NUMBER_THREADS must be >= 1, got {number_threads}")
        if batch_size < 1:
            raise ValueError(f"BATCH_SIZE must be >= 1, got {batch_size}")

        return cls(
            parallel_tables=parallel_tables,
            number_threads=number_threads,
            batch_size=batch_size,
        )
