"""
iceberg_migration/migrator.py

TableMigrator is the thin glue between a source account and a target account.
It is provider-agnostic: any combination of IcebergSourceAccount +
IcebergTargetAccount implementations can be passed in.

Example
-------
    from iceberg_migration.migrator import TableMigrator
    from iceberg_migration.providers.aws import AWSSourceAccount, AWSTargetAccount

    source = AWSSourceAccount(...)
    target = AWSTargetAccount(...)
    TableMigrator(source, target).run()
"""

import logging
import time

from iceberg_migration.base import IcebergSourceAccount, IcebergTargetAccount

logger = logging.getLogger(__name__)


class TableMigrator:
    """Orchestrates a single Iceberg table migration from source to target.

    Parameters
    ----------
    source:
        Any implementation of IcebergSourceAccount (AWS, GCP, Azure, MinIO…).
    target:
        Any implementation of IcebergTargetAccount (AWS, GCP, Azure, MinIO…).
    """

    def __init__(self, source: IcebergSourceAccount, target: IcebergTargetAccount):
        self.source = source
        self.target = target

    def run(self) -> None:
        """Run the full migration: patch files at source, then upload and
        register at target."""
        start = time.time()
        logger.info("Migration started")

        self.source.execute()
        self.target.execute()

        logger.info("Migration finished in %.1fs", time.time() - start)
