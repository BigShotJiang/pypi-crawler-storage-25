"""
iceberg-migration
=================
A tool for migrating Apache Iceberg V2 tables across cloud providers.

Supported providers
-------------------
- AWS   (S3 + Glue catalog)                   → providers/aws/
- MinIO (self-hosted S3-compatible + Hive)     → providers/minio/
- GCP   (GCS + BigLake, stub — not yet impl.) → providers/gcp/

Quick start (using the provider factory)
-----------------------------------------
    from iceberg_migration.config import MigrationConfig
    from iceberg_migration.providers import build_provider
    from iceberg_migration.migrator import TableMigrator

    migration_config = MigrationConfig.from_env()
    source, target = build_provider("aws", "my_db", "my_db", "my_table", migration_config)
    TableMigrator(source, target).run()
"""

__version__ = "0.1.1"
__author__ = "Softel"
