"""tests/test_config.py — MigrationConfig env-var parsing and validation."""

import pytest

from iceberg_migration.config import MigrationConfig


class TestMigrationConfig:
    def test_defaults(self, monkeypatch):
        monkeypatch.delenv("PARALLEL_TABLES", raising=False)
        monkeypatch.delenv("NUMBER_THREADS", raising=False)
        monkeypatch.delenv("BATCH_SIZE", raising=False)
        cfg = MigrationConfig.from_env()
        assert cfg.parallel_tables == 5
        assert cfg.number_threads == 10
        assert cfg.batch_size == 500_000

    def test_custom_values(self, monkeypatch):
        monkeypatch.setenv("PARALLEL_TABLES", "3")
        monkeypatch.setenv("NUMBER_THREADS", "8")
        monkeypatch.setenv("BATCH_SIZE", "1000")
        cfg = MigrationConfig.from_env()
        assert cfg.parallel_tables == 3
        assert cfg.number_threads == 8
        assert cfg.batch_size == 1000

    def test_invalid_type_raises(self, monkeypatch):
        monkeypatch.setenv("PARALLEL_TABLES", "not-a-number")
        with pytest.raises(ValueError, match="must be integers"):
            MigrationConfig.from_env()

    def test_zero_parallel_tables_raises(self, monkeypatch):
        monkeypatch.setenv("PARALLEL_TABLES", "0")
        with pytest.raises(ValueError, match="PARALLEL_TABLES must be >= 1"):
            MigrationConfig.from_env()

    def test_negative_batch_size_raises(self, monkeypatch):
        monkeypatch.setenv("BATCH_SIZE", "-100")
        with pytest.raises(ValueError, match="BATCH_SIZE must be >= 1"):
            MigrationConfig.from_env()

    def test_is_frozen(self):
        cfg = MigrationConfig(parallel_tables=1, number_threads=1, batch_size=1)
        with pytest.raises(Exception):
            cfg.parallel_tables = 99  # type: ignore[misc]
