"""tests/test_utils.py — Unit tests for iceberg_migration.utils."""

from iceberg_migration.utils import (
    replace_bucket,
    replace_bucket_in_avro_bounds,
    replace_buckets_in_json,
)


class TestReplaceBucket:
    def test_simple_s3_path(self):
        assert (
            replace_bucket("s3://old-bucket/db/table/file.avro", "old-bucket", "new-bucket")
            == "s3://new-bucket/db/table/file.avro"
        )

    def test_gs_scheme(self):
        assert (
            replace_bucket("gs://old/db/file.avro", "old", "new", scheme="gs")
            == "gs://new/db/file.avro"
        )

    def test_no_match_returns_unchanged(self):
        path = "s3://other-bucket/db/file.avro"
        assert replace_bucket(path, "old-bucket", "new-bucket") == path

    def test_only_replaces_bucket_not_key(self):
        # 'old' appears in the key path — must not be replaced there
        result = replace_bucket("s3://old/path/with/old/in/key.avro", "old", "new")
        assert result == "s3://new/path/with/old/in/key.avro"


class TestReplaceBucketsInJson:
    def test_flat_dict(self):
        node = {"location": "s3://src/db/table"}
        replace_buckets_in_json(node, "src", "tgt")
        assert node["location"] == "s3://tgt/db/table"

    def test_nested_dict(self):
        node = {"level1": {"level2": "s3://src/file.avro"}}
        replace_buckets_in_json(node, "src", "tgt")
        assert node["level1"]["level2"] == "s3://tgt/file.avro"

    def test_list_of_strings(self):
        node = {"snapshots": ["s3://src/a.avro", "s3://src/b.avro"]}
        replace_buckets_in_json(node, "src", "tgt")
        assert node["snapshots"] == ["s3://tgt/a.avro", "s3://tgt/b.avro"]

    def test_metadata_log_entries(self):
        """metadata-log is a list of dicts — the key case for the historical fix."""
        node = {
            "metadata-log": [
                {"metadata-file": "s3://src/db/table/metadata/v0.metadata.json", "timestamp-ms": 1},
                {"metadata-file": "s3://src/db/table/metadata/v1.metadata.json", "timestamp-ms": 2},
            ]
        }
        replace_buckets_in_json(node, "src", "tgt")
        assert (
            node["metadata-log"][0]["metadata-file"]
            == "s3://tgt/db/table/metadata/v0.metadata.json"
        )
        assert (
            node["metadata-log"][1]["metadata-file"]
            == "s3://tgt/db/table/metadata/v1.metadata.json"
        )

    def test_non_matching_strings_unchanged(self):
        node = {"name": "my_table", "type": "ICEBERG"}
        replace_buckets_in_json(node, "src", "tgt")
        assert node == {"name": "my_table", "type": "ICEBERG"}

    def test_mutates_in_place(self):
        node = {"loc": "s3://src/file"}
        original_id = id(node)
        replace_buckets_in_json(node, "src", "tgt")
        assert id(node) == original_id

    def test_gs_scheme(self):
        node = {"loc": "gs://src-bucket/file.avro"}
        replace_buckets_in_json(node, "src-bucket", "tgt-bucket", scheme="gs")
        assert node["loc"] == "gs://tgt-bucket/file.avro"


class TestReplaceBucketInAvroBounds:
    def _make_record(self, path_bytes: bytes) -> dict:
        return {
            "data_file": {
                "lower_bounds": [{"key": 1, "value": path_bytes}],
                "upper_bounds": [{"key": 1, "value": path_bytes}],
            }
        }

    def test_replaces_bucket_in_bytes(self):
        path = b"s3://old-bucket/db/table/data.parquet"
        record = self._make_record(path)
        replace_bucket_in_avro_bounds(record, "old-bucket", "new-bucket")
        expected = b"s3://new-bucket/db/table/data.parquet"
        assert record["data_file"]["lower_bounds"][0]["value"] == expected
        assert record["data_file"]["upper_bounds"][0]["value"] == expected

    def test_no_match_leaves_bytes_unchanged(self):
        path = b"s3://other-bucket/db/table/data.parquet"
        record = self._make_record(path)
        replace_bucket_in_avro_bounds(record, "old-bucket", "new-bucket")
        assert record["data_file"]["lower_bounds"][0]["value"] == path

    def test_non_bytes_value_skipped(self):
        record = {"data_file": {"lower_bounds": [{"key": 1, "value": 42}], "upper_bounds": []}}
        replace_bucket_in_avro_bounds(record, "old", "new")  # must not raise

    def test_empty_bounds(self):
        record = {"data_file": {"lower_bounds": [], "upper_bounds": []}}
        replace_bucket_in_avro_bounds(record, "old", "new")
        assert record["data_file"]["lower_bounds"] == []

    def test_missing_data_file(self):
        replace_bucket_in_avro_bounds({}, "old", "new")  # must not raise
