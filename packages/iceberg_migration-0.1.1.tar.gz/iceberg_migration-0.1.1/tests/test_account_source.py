"""tests/test_account_source.py — AWSSourceAccount unit tests.

All AWS calls (boto3, pyiceberg) are mocked — no real network traffic.
The ``source_account`` fixture (in conftest.py) wires up a fully-patched
instance with:
  source_bucket = "iceberg-source"
  target_bucket = "iceberg-target"
  database_name = "test_db"
  table_name    = "orders"
"""

import json
import os
from pathlib import Path
from unittest.mock import MagicMock

from tests.conftest import (
    make_delete_parquet,
    make_manifest_avro,
    make_manifest_list_avro,
    make_metadata_json,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _write_local(account, s3_uri: str, sub_dir: str, content: bytes) -> str:
    """Pre-populate a local file as if _download() had already fetched it."""
    local = account._local_path(s3_uri, sub_dir)
    os.makedirs(os.path.dirname(local), exist_ok=True)
    with open(local, "wb") as fh:
        fh.write(content)
    return local


def _mock_download(account, local_file: str):
    """Make account._download() return *local_file* for any URI."""
    account._download = MagicMock(return_value=local_file)


# ---------------------------------------------------------------------------
# Initialisation
# ---------------------------------------------------------------------------


class TestInit:
    def test_source_bucket_derived_from_location(self, source_account):
        assert source_account.source_bucket == "iceberg-source"

    def test_target_bucket_from_config(self, source_account):
        assert source_account.target_bucket == "iceberg-target"

    def test_snapshot_id_set(self, source_account):
        assert source_account._current_snapshot_id == 1111

    def test_accumulators_empty(self, source_account):
        assert source_account._manifest_list_uris == []
        assert source_account._manifest_uris == []
        assert source_account._delete_file_uris == set()


# ---------------------------------------------------------------------------
# Step 1 — metadata JSON patching
# ---------------------------------------------------------------------------


class TestStep1PatchMetadataJson:
    def _metadata_uri(self):
        return "s3://iceberg-source/test_db/orders/metadata/v2.metadata.json"

    def test_patches_location_field(self, source_account, tmp_path):
        meta_path = make_metadata_json(
            tmp_path,
            "v2.metadata.json",
            source_bucket="iceberg-source",
        )
        _mock_download(source_account, meta_path)

        source_account._step1_patch_metadata_json()

        patched_path = meta_path.replace("/old/", "/new/")
        with open(patched_path) as fh:
            patched = json.load(fh)

        assert patched["location"] == "s3://iceberg-target/test_db/orders"

    def test_collects_manifest_list_uri_for_current_snapshot(self, source_account, tmp_path):
        manifest_list_uri = "s3://iceberg-source/test_db/orders/metadata/snap-1111.avro"
        meta_path = make_metadata_json(
            tmp_path,
            "v2.metadata.json",
            source_bucket="iceberg-source",
            snapshot_id=1111,
            manifest_list_uri=manifest_list_uri,
        )
        _mock_download(source_account, meta_path)

        source_account._step1_patch_metadata_json()

        assert manifest_list_uri in source_account._manifest_list_uris

    def test_does_not_collect_manifest_list_for_other_snapshots(self, source_account, tmp_path):
        """Snapshots other than the current one should be ignored."""
        other_uri = "s3://iceberg-source/test_db/orders/metadata/snap-9999.avro"
        meta_path = make_metadata_json(
            tmp_path,
            "v2.metadata.json",
            source_bucket="iceberg-source",
            snapshot_id=9999,  # ← not the current snapshot (1111)
            manifest_list_uri=other_uri,
        )
        _mock_download(source_account, meta_path)

        source_account._step1_patch_metadata_json()

        assert other_uri not in source_account._manifest_list_uris

    def test_writes_patched_json_with_indent(self, source_account, tmp_path):
        """Output file must be pretty-printed (indent=2), not compact."""
        meta_path = make_metadata_json(tmp_path, "v2.metadata.json", "iceberg-source")
        _mock_download(source_account, meta_path)

        source_account._step1_patch_metadata_json()

        patched_path = meta_path.replace("/old/", "/new/")
        raw = Path(patched_path).read_text()
        # A compact dump would not start "{\n"; an indented one does.
        assert raw.startswith("{\n")


# ---------------------------------------------------------------------------
# Step 1 — historical metadata-log patching (the MinIO bug fix)
# ---------------------------------------------------------------------------


class TestPatchHistoricalMetadataJson:
    def test_patches_location_in_historical_file(self, source_account, tmp_path):
        """_patch_historical_metadata_json must rewrite source → target bucket."""
        hist_path = make_metadata_json(
            tmp_path,
            "v0.metadata.json",
            source_bucket="iceberg-source",
        )
        _mock_download(source_account, hist_path)

        source_account._patch_historical_metadata_json(
            "s3://iceberg-source/test_db/orders/metadata/v0.metadata.json"
        )

        patched_path = hist_path.replace("/old/", "/new/")
        with open(patched_path) as fh:
            patched = json.load(fh)

        assert "iceberg-target" in patched["location"]
        assert "iceberg-source" not in patched["location"]

    def test_step1_patches_all_historical_files(self, source_account, tmp_path):
        """When metadata-log has two entries, both must be patched."""
        # Write the two historical metadata files (pre-downloaded)
        v0_path = make_metadata_json(tmp_path, "v0.metadata.json", "iceberg-source")
        v1_path = make_metadata_json(tmp_path, "v1.metadata.json", "iceberg-source")

        hist_uris = [
            "s3://iceberg-source/test_db/orders/metadata/v0.metadata.json",
            "s3://iceberg-source/test_db/orders/metadata/v1.metadata.json",
        ]

        # Current metadata references them in metadata-log
        meta_path = make_metadata_json(
            tmp_path,
            "v2.metadata.json",
            source_bucket="iceberg-source",
            metadata_log=[
                {"metadata-file": hist_uris[0], "timestamp-ms": 1},
                {"metadata-file": hist_uris[1], "timestamp-ms": 2},
            ],
        )

        # _download is called 3 times: v2 (current), v0, v1
        call_sequence = [meta_path, v0_path, v1_path]
        source_account._download = MagicMock(side_effect=call_sequence)

        source_account._step1_patch_metadata_json()

        for hist_path in [v0_path, v1_path]:
            patched_path = hist_path.replace("/old/", "/new/")
            with open(patched_path) as fh:
                patched = json.load(fh)
            assert "iceberg-source" not in patched["location"], (
                f"{os.path.basename(hist_path)} still contains source bucket reference"
            )

    def test_metadata_log_entries_get_bucket_rewritten(self, source_account, tmp_path):
        """The metadata-log list inside the current metadata JSON is also patched."""
        hist_uri = "s3://iceberg-source/test_db/orders/metadata/v0.metadata.json"
        meta_path = make_metadata_json(
            tmp_path,
            "v2.metadata.json",
            source_bucket="iceberg-source",
            metadata_log=[{"metadata-file": hist_uri, "timestamp-ms": 1}],
        )

        hist_path = make_metadata_json(tmp_path, "v0.metadata.json", "iceberg-source")
        source_account._download = MagicMock(side_effect=[meta_path, hist_path])

        source_account._step1_patch_metadata_json()

        patched_meta_path = meta_path.replace("/old/", "/new/")
        with open(patched_meta_path) as fh:
            patched = json.load(fh)

        assert patched["metadata-log"][0]["metadata-file"].startswith("s3://iceberg-target/")


# ---------------------------------------------------------------------------
# Step 2 — manifest-list scanning
# ---------------------------------------------------------------------------


class TestStep2ScanManifestLists:
    def test_collects_manifest_uris(self, source_account, tmp_path):
        manifest_uri = "s3://iceberg-source/test_db/orders/metadata/00000-abc.avro"
        avro_path = make_manifest_list_avro(tmp_path, "snap-1111.avro", [manifest_uri])
        source_account._manifest_list_uris = [
            "s3://iceberg-source/test_db/orders/metadata/snap-1111.avro"
        ]
        source_account._download = MagicMock(return_value=avro_path)

        source_account._step2_scan_manifest_lists()

        assert manifest_uri in source_account._manifest_uris

    def test_empty_manifest_list_yields_no_uris(self, source_account, tmp_path):
        avro_path = make_manifest_list_avro(tmp_path, "snap-empty.avro", [])
        source_account._manifest_list_uris = [
            "s3://iceberg-source/test_db/orders/metadata/snap-empty.avro"
        ]
        source_account._download = MagicMock(return_value=avro_path)

        source_account._step2_scan_manifest_lists()

        assert source_account._manifest_uris == []


# ---------------------------------------------------------------------------
# Step 3 — manifest scanning (collect delete files)
# ---------------------------------------------------------------------------


class TestStep3ScanManifests:
    def test_collects_delete_file_uris(self, source_account, tmp_path):
        delete_uri = "s3://iceberg-source/test_db/orders/data/delete.parquet"
        avro_path = make_manifest_avro(
            tmp_path,
            "00000-abc.avro",
            [delete_uri],
            content=1,  # POSITION_DELETE
        )
        source_account._manifest_uris = [
            "s3://iceberg-source/test_db/orders/metadata/00000-abc.avro"
        ]
        source_account._download = MagicMock(return_value=avro_path)

        source_account._step3_scan_manifests()

        assert delete_uri in source_account._delete_file_uris

    def test_data_files_not_collected(self, source_account, tmp_path):
        data_uri = "s3://iceberg-source/test_db/orders/data/data.parquet"
        avro_path = make_manifest_avro(
            tmp_path,
            "00000-data.avro",
            [data_uri],
            content=0,  # DATA
        )
        source_account._manifest_uris = [
            "s3://iceberg-source/test_db/orders/metadata/00000-data.avro"
        ]
        source_account._download = MagicMock(return_value=avro_path)

        source_account._step3_scan_manifests()

        assert source_account._delete_file_uris == set()


# ---------------------------------------------------------------------------
# Delete-file Parquet patching
# ---------------------------------------------------------------------------


class TestPatchDeleteParquet:
    def test_rewrites_file_path_column(self, source_account, tmp_path):
        old_path = make_delete_parquet(
            tmp_path,
            "old/data/delete.parquet",
            ["s3://iceberg-source/test_db/orders/data/file.parquet"],
        )

        source_account._patch_delete_parquet(old_path)

        patched_path = old_path.replace("/old/", "/new/")
        import pyarrow.parquet as pq

        table = pq.read_table(patched_path)
        paths = table.column("file_path").to_pylist()
        assert paths == ["s3://iceberg-target/test_db/orders/data/file.parquet"]

    def test_returns_patched_file_size(self, source_account, tmp_path):
        old_path = make_delete_parquet(
            tmp_path,
            "old/data/delete.parquet",
            ["s3://iceberg-source/test_db/orders/data/file.parquet"],
        )

        size = source_account._patch_delete_parquet(old_path)

        assert size > 0
        patched_path = old_path.replace("/old/", "/new/")
        assert size == os.path.getsize(patched_path)
