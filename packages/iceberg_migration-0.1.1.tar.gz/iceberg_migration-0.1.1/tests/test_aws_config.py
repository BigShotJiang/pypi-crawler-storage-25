"""tests/test_aws_config.py — AWSSourceConfig and AWSTargetConfig loading."""

import pytest

from iceberg_migration.providers.aws.config import AWSSourceConfig, AWSTargetConfig


class TestAWSSourceConfig:
    def test_loads_from_env(self, monkeypatch):
        monkeypatch.setenv("SOURCE_AWS_REGION", "eu-west-1")
        monkeypatch.setenv("SOURCE_AWS_ACCESS_KEY_ID", "AKIAIOSFODNN7EXAMPLE")
        monkeypatch.setenv("SOURCE_AWS_SECRET_ACCESS_KEY", "secret")
        monkeypatch.delenv("SOURCE_GLUE_CATALOG", raising=False)
        cfg = AWSSourceConfig.from_env()
        assert cfg.region == "eu-west-1"
        assert cfg.glue_catalog == "awsdatacatalog"

    def test_custom_glue_catalog(self, monkeypatch):
        monkeypatch.setenv("SOURCE_AWS_REGION", "us-east-1")
        monkeypatch.setenv("SOURCE_AWS_ACCESS_KEY_ID", "key")
        monkeypatch.setenv("SOURCE_AWS_SECRET_ACCESS_KEY", "secret")
        monkeypatch.setenv("SOURCE_GLUE_CATALOG", "my-catalog")
        assert AWSSourceConfig.from_env().glue_catalog == "my-catalog"

    def test_missing_required_var_raises(self, monkeypatch):
        monkeypatch.delenv("SOURCE_AWS_REGION", raising=False)
        monkeypatch.setenv("SOURCE_AWS_ACCESS_KEY_ID", "key")
        monkeypatch.setenv("SOURCE_AWS_SECRET_ACCESS_KEY", "secret")
        with pytest.raises(EnvironmentError, match="SOURCE_AWS_REGION"):
            AWSSourceConfig.from_env()


class TestAWSTargetConfig:
    def test_loads_from_env(self, monkeypatch):
        monkeypatch.setenv("TARGET_AWS_REGION", "us-west-2")
        monkeypatch.setenv("TARGET_AWS_ACCESS_KEY_ID", "tgt-key")
        monkeypatch.setenv("TARGET_AWS_SECRET_ACCESS_KEY", "tgt-secret")
        monkeypatch.setenv("TARGET_S3_BUCKET", "my-target-bucket")
        monkeypatch.delenv("TARGET_AWS_SESSION_TOKEN", raising=False)
        monkeypatch.delenv("TARGET_GLUE_CATALOG", raising=False)
        cfg = AWSTargetConfig.from_env()
        assert cfg.s3_bucket == "my-target-bucket"
        assert cfg.session_token is None

    def test_session_token_optional(self, monkeypatch):
        monkeypatch.setenv("TARGET_AWS_REGION", "us-east-1")
        monkeypatch.setenv("TARGET_AWS_ACCESS_KEY_ID", "key")
        monkeypatch.setenv("TARGET_AWS_SECRET_ACCESS_KEY", "secret")
        monkeypatch.setenv("TARGET_S3_BUCKET", "bucket")
        monkeypatch.setenv("TARGET_AWS_SESSION_TOKEN", "my-token")
        assert AWSTargetConfig.from_env().session_token == "my-token"

    def test_missing_bucket_raises(self, monkeypatch):
        monkeypatch.setenv("TARGET_AWS_REGION", "us-east-1")
        monkeypatch.setenv("TARGET_AWS_ACCESS_KEY_ID", "key")
        monkeypatch.setenv("TARGET_AWS_SECRET_ACCESS_KEY", "secret")
        monkeypatch.delenv("TARGET_S3_BUCKET", raising=False)
        with pytest.raises(EnvironmentError, match="TARGET_S3_BUCKET"):
            AWSTargetConfig.from_env()
