"""
escli social — social media search via Tavily API.

Searches across Reddit, X/Twitter, TikTok, LinkedIn, Instagram,
Facebook, or all combined for real-world opinions and discussions.

Usage:
  escli social "query"                              Search all platforms
  escli social "query" --platform reddit             Reddit only
  escli social "query" --platform x,linkedin         Multiple platforms
  escli social "query" --time week --raw             Last week, full content
  escli social "query" --answer                      Include AI summary
"""

import argparse
import json
import sys
import time

from ..services.credentials import call_with_retry, ServiceCallError

TAVILY_API = "https://api.tavily.com"

PLATFORM_DOMAINS = {
    "reddit": ["reddit.com"],
    "x": ["x.com", "twitter.com"],
    "twitter": ["x.com", "twitter.com"],
    "tiktok": ["tiktok.com"],
    "linkedin": ["linkedin.com"],
    "instagram": ["instagram.com"],
    "facebook": ["facebook.com"],
    "youtube": ["youtube.com"],
    "combined": ["reddit.com", "x.com", "twitter.com", "tiktok.com",
                 "linkedin.com", "instagram.com", "facebook.com"],
}

VALID_PLATFORMS = list(PLATFORM_DOMAINS.keys())
VALID_TIME_RANGES = ["day", "week", "month", "year"]
VALID_DEPTHS = ["basic", "advanced", "fast", "ultra-fast"]


def _get_api_key() -> str:
    key = get_key_for_service("tavily", "TAVILY_API_KEY")
    if not key:
        print("  ✗ no Tavily API key. Set TAVILY_API_KEY or add one via the dashboard.", file=sys.stderr)
        sys.exit(1)
    return key


def _resolve_domains(platform_str: str | None) -> list[str]:
    """Resolve platform string to domain list."""
    if not platform_str:
        return PLATFORM_DOMAINS["combined"]

    domains = []
    for p in platform_str.lower().split(","):
        p = p.strip()
        if p in PLATFORM_DOMAINS:
            domains.extend(PLATFORM_DOMAINS[p])
        else:
            print(f"  ✗ unknown platform: {p}", file=sys.stderr)
            print(f"  valid: {', '.join(VALID_PLATFORMS)}", file=sys.stderr)
            sys.exit(2)

    return list(dict.fromkeys(domains))  # dedupe preserving order


def cmd_social(args):
    """Search social media platforms."""
    import httpx

    query = " ".join(args.query)
    if not query:
        print("  ✗ search query required", file=sys.stderr)
        return 1

    platform = getattr(args, "platform", None)
    domains = _resolve_domains(platform)
    t0 = time.time()

    if not args.quiet:
        platform_label = platform or "all platforms"
        print(f"  ▸ searching {platform_label}: {query}", file=sys.stderr)

    # Build request
    body: dict = {
        "query": query,
        "include_domains": domains,
        "max_results": getattr(args, "max_results", 10) or 10,
        "search_depth": getattr(args, "depth", "advanced") or "advanced",
        "include_answer": getattr(args, "answer", False),
        "include_raw_content": getattr(args, "raw", False),
        "include_images": getattr(args, "images", False),
        "include_usage": True,
    }

    time_range = getattr(args, "time", None)
    if time_range:
        body["time_range"] = time_range

    country = getattr(args, "country", None)
    if country:
        body["country"] = country

    def do_search(key):
        resp = httpx.post(
            f"{TAVILY_API}/search",
            json=body,
            headers={
                "Authorization": f"Bearer {key.api_key}",
                "Content-Type": "application/json",
            },
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()

    try:
        data = call_with_retry("tavily", do_search, env_var="TAVILY_API_KEY")
        if data is None:
            if args.json:
                print(json.dumps({"ok": False, "data": None, "error": {"code": "tavily.no_key", "message": "no Tavily API key"}, "meta": {}}))
            else:
                print("  ✗ no Tavily API key. Set TAVILY_API_KEY or add one via the dashboard.", file=sys.stderr)
            return 1
    except ServiceCallError as e:
        if args.json:
            print(json.dumps({"ok": False, "data": None, "error": {"code": f"tavily.{e.status_code}", "message": str(e)}, "meta": {}}))
        else:
            print(f"  ✗ all keys exhausted: {e}", file=sys.stderr)
        return 1
    except httpx.HTTPStatusError as e:
        error_msg = str(e)
        try:
            error_msg = e.response.json().get("detail", {}).get("error", str(e))
        except Exception:
            pass
        if args.json:
            print(json.dumps({"ok": False, "data": None, "error": {"code": f"tavily.{e.response.status_code}", "message": error_msg}, "meta": {}}))
        else:
            print(f"  ✗ {error_msg}", file=sys.stderr)
        return 1
    except Exception as e:
        if args.json:
            print(json.dumps({"ok": False, "data": None, "error": {"code": "tavily.network", "message": str(e), "retryable": True}, "meta": {}}))
        else:
            print(f"  ✗ {e}", file=sys.stderr)
        return 1

    elapsed = round(time.time() - t0, 1)
    results = data.get("results", [])
    answer = data.get("answer")

    if args.json:
        print(json.dumps({
            "ok": True,
            "data": {
                "answer": answer,
                "results": [{
                    "title": r.get("title", ""),
                    "url": r.get("url", ""),
                    "content": r.get("content", ""),
                    "score": r.get("score"),
                    "raw_content": r.get("raw_content") if getattr(args, "raw", False) else None,
                } for r in results],
                "platform": platform or "combined",
                "query": query,
            },
            "error": None,
            "meta": {
                "elapsed_seconds": elapsed,
                "result_count": len(results),
                "credits": data.get("usage", {}).get("credits"),
            },
        }))
        return 0

    # Human output
    if answer:
        print(f"\n  {answer}\n")

    for r in results:
        title = r.get("title", "")
        url = r.get("url", "")
        content = r.get("content", "")
        score = r.get("score", 0)

        # Detect platform from URL
        platform_tag = ""
        for p, doms in PLATFORM_DOMAINS.items():
            if p in ("combined", "twitter"):
                continue
            if any(d in url for d in doms):
                platform_tag = p
                break

        print(f"  {f'[{platform_tag}] ' if platform_tag else ''}{title}")
        print(f"  {url}")
        if content:
            text = content.strip().replace("\n", " ")[:200]
            print(f"    {text}")
        print()

    if not args.quiet:
        credits = data.get("usage", {}).get("credits", "?")
        print(f"  {len(results)} results · {elapsed}s · {credits} credit(s)", file=sys.stderr)

    return 0


# ── Parser ───────────────────────────────────────────────────────

def register(subparsers):
    """Register the social subcommand."""
    F = argparse.RawDescriptionHelpFormatter

    p = subparsers.add_parser(
        "social", help="Social media search (Tavily)",
        formatter_class=F,
        epilog="""platforms:
  reddit, x, tiktok, linkedin, instagram, facebook, youtube, combined (default)

examples:
  escli social "what are people saying about Claude Code"
  escli social "AI trends 2026" --platform reddit
  escli social "product reviews" --platform tiktok,instagram --time week
  escli social "company sentiment" --platform linkedin,x --answer
  escli social "breaking news" --platform x --time day --raw --max-results 15
  escli --json --quiet social "brand perception" --platform reddit,x

time ranges:
  day     Last 24 hours (breaking news, reactions)
  week    Last 7 days
  month   Last 30 days (broader trends)
  year    Last 12 months
""")

    p.add_argument("query", nargs="+", help="What to search for on social media")
    p.add_argument("--platform", "-p", default=None, metavar="P",
                   help=f"Platform(s) to search, comma-separated ({', '.join(VALID_PLATFORMS)})")
    p.add_argument("--time", "-t", default=None, choices=VALID_TIME_RANGES, metavar="T",
                   help="Time range: day, week, month, year")
    p.add_argument("--max-results", "-n", type=int, default=10, metavar="N",
                   help="Max results (1-20, default: 10)")
    p.add_argument("--depth", default="advanced", choices=VALID_DEPTHS,
                   help="Search depth (default: advanced)")
    p.add_argument("--answer", "-a", action="store_true",
                   help="Include AI-synthesized answer")
    p.add_argument("--raw", action="store_true",
                   help="Include full post content (raw markdown)")
    p.add_argument("--images", action="store_true",
                   help="Include images from results")
    p.add_argument("--country", default=None, metavar="CC",
                   help="Country for geo-targeted results (e.g. 'united states')")
    p.set_defaults(func=cmd_social)

    return p
