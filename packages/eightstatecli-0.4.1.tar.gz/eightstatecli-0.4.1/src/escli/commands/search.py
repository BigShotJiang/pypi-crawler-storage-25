"""
escli search / fetch — web search and URL extraction via Parallel.ai.

Uses the free Parallel Search MCP endpoint (no API key required).
Falls back to the REST API with a key from gate if available.

Usage:
  escli search "query about something"           Web search
  escli search "query" --queries "q1" "q2"       Multiple search queries
  escli fetch <url> [url2 ...]                   Extract content from URLs
  escli fetch <url> --objective "what to find"   Focused extraction
  escli fetch <url> --full                       Full page content
"""

import argparse
import json
import sys
import time
import uuid

from ..services.credentials import call_with_retry, ServiceCallError

MCP_ENDPOINT = "https://search.parallel.ai/mcp"
REST_ENDPOINT = "https://api.parallel.ai/v1"


def _session_id() -> str:
    """Stable session ID for rate limiting."""
    return uuid.uuid4().hex


def _call_mcp(tool_name: str, arguments: dict) -> dict:
    """Call a tool on the Parallel MCP endpoint via JSON-RPC over HTTP."""
    import httpx

    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {
            "name": tool_name,
            "arguments": arguments,
        },
    }

    resp = httpx.post(
        MCP_ENDPOINT,
        json=payload,
        headers={
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
        },
        timeout=60,
    )
    resp.raise_for_status()

    data = resp.json()
    if "error" in data:
        raise RuntimeError(data["error"].get("message", "MCP error"))

    result = data.get("result", {})
    # MCP tool results come as content array
    content = result.get("content", [])
    for item in content:
        if item.get("type") == "text":
            try:
                return json.loads(item["text"])
            except json.JSONDecodeError:
                return {"text": item["text"]}

    return result


def _call_rest_search(objective: str, queries: list[str], api_key: str) -> dict:
    """Call Parallel Search REST API directly."""
    import httpx

    resp = httpx.post(
        f"{REST_ENDPOINT}/search",
        json={"objective": objective, "search_queries": queries},
        headers={"Content-Type": "application/json", "x-api-key": api_key},
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()


def _call_rest_extract(urls: list[str], objective: str | None, full: bool, api_key: str) -> dict:
    """Call Parallel Extract REST API directly."""
    import httpx

    body: dict = {"urls": urls}
    if objective:
        body["objective"] = objective
    if full:
        body["full_content"] = True

    resp = httpx.post(
        f"{REST_ENDPOINT}/extract",
        json=body,
        headers={"Content-Type": "application/json", "x-api-key": api_key},
        timeout=60,
    )
    resp.raise_for_status()
    return resp.json()


# ── Commands ─────────────────────────────────────────────────────

def cmd_search(args):
    """Web search via Parallel."""
    objective = " ".join(args.objective)
    if not objective:
        print("  ✗ search objective required", file=sys.stderr)
        return 1

    queries = args.queries if args.queries else [objective]
    t0 = time.time()

    if not args.quiet:
        print(f"  ▸ searching: {objective}", file=sys.stderr)

    # Try REST API with key rotation, fall back to free MCP
    data = None
    try:
        result = call_with_retry(
            "parallel",
            lambda key: _call_rest_search(objective, queries, key.api_key),
            env_var="PARALLEL_API_KEY",
        )
        if result is not None:
            data = result
    except ServiceCallError:
        pass  # All keys exhausted, fall through to MCP

    if data is None:
        try:
            session = _session_id()
            data = _call_mcp("web_search", {
                "objective": objective,
                "search_queries": queries,
                "session_id": session,
            })
        except Exception as e:
            if args.json:
                print(json.dumps({"success": False, "error": str(e)}))
            else:
                print(f"  ✗ search failed: {e}", file=sys.stderr)
            return 1

    elapsed = round(time.time() - t0, 1)
    results = data.get("results", [])

    if args.json:
        print(json.dumps({
            "success": True,
            "elapsed_seconds": elapsed,
            "results": results,
            "count": len(results),
        }))
        return 0

    if not results:
        print("  No results found.", file=sys.stderr)
        return 0

    for r in results:
        title = r.get("title", "")
        url = r.get("url", "")
        excerpts = r.get("excerpts", [])

        print(f"\n  {title}")
        print(f"  {url}")
        for ex in excerpts[:2]:
            # Truncate long excerpts
            text = ex.strip().replace("\n", " ")[:200]
            print(f"    {text}")

    if not args.quiet:
        print(f"\n  {len(results)} results · {elapsed}s", file=sys.stderr)

    return 0


def cmd_fetch(args):
    """Extract content from URLs via Parallel."""
    urls = args.urls
    if not urls:
        print("  ✗ at least one URL required", file=sys.stderr)
        return 1

    objective = args.objective
    full = getattr(args, "full", False)
    t0 = time.time()

    if not args.quiet:
        print(f"  ▸ fetching {len(urls)} URL(s)...", file=sys.stderr)

    # Try REST API with key rotation, fall back to free MCP
    data = None
    try:
        result = call_with_retry(
            "parallel",
            lambda key: _call_rest_extract(urls, objective, full, key.api_key),
            env_var="PARALLEL_API_KEY",
        )
        if result is not None:
            data = result
    except ServiceCallError:
        pass  # All keys exhausted, fall through to MCP

    if data is None:
        try:
            session = _session_id()
            mcp_args: dict = {"urls": urls, "session_id": session}
            if objective:
                mcp_args["objective"] = objective
            if full:
                mcp_args["full_content"] = True
            data = _call_mcp("web_fetch", mcp_args)
        except Exception as e:
            if args.json:
                print(json.dumps({"success": False, "error": str(e)}))
            else:
                print(f"  ✗ fetch failed: {e}", file=sys.stderr)
            return 1

    elapsed = round(time.time() - t0, 1)
    results = data.get("results", [])

    if args.json:
        print(json.dumps({
            "success": True,
            "elapsed_seconds": elapsed,
            "results": results,
            "count": len(results),
        }))
        return 0

    for r in results:
        title = r.get("title", "")
        url = r.get("url", "")
        full_content = r.get("full_content")
        excerpts = r.get("excerpts", [])

        if title:
            print(f"\n  # {title}")
        print(f"  {url}\n")

        if full_content:
            print(full_content)
        else:
            for ex in excerpts:
                print(ex)
                print()

    if not args.quiet:
        print(f"  {len(results)} page(s) · {elapsed}s", file=sys.stderr)

    return 0


# ── Parser ───────────────────────────────────────────────────────

def register(subparsers):
    """Register search and fetch subcommands."""
    F = argparse.RawDescriptionHelpFormatter

    # search
    search_p = subparsers.add_parser(
        "search", aliases=["s"], help="Web search (Parallel.ai)",
        formatter_class=F,
        epilog="""examples:
  escli search "latest cloudflare workers features"
  escli search "react server components" --queries "RSC tutorial" "RSC vs SSR"
  escli --json search "python web frameworks 2026"

Uses the free Parallel Search MCP. No API key needed.
Add a Parallel API key for higher rate limits.
""")
    search_p.add_argument("objective", nargs="+", help="What you're searching for")
    search_p.add_argument("--queries", nargs="+", default=None, metavar="Q",
                          help="Specific search queries (default: uses objective)")
    search_p.set_defaults(func=cmd_search)

    # fetch
    fetch_p = subparsers.add_parser(
        "fetch", aliases=["f"], help="Extract URL content (Parallel.ai)",
        formatter_class=F,
        epilog="""examples:
  escli fetch https://docs.parallel.ai/search/search-quickstart
  escli fetch https://example.com --objective "pricing information"
  escli fetch https://example.com --full
  escli --json fetch https://example.com https://other.com

Uses the free Parallel Extract MCP. No API key needed.
""")
    fetch_p.add_argument("urls", nargs="+", help="URLs to extract content from")
    fetch_p.add_argument("--objective", default=None, help="Focus extraction on this topic")
    fetch_p.add_argument("--full", action="store_true", help="Return full page content instead of excerpts")
    fetch_p.set_defaults(func=cmd_fetch)

    return search_p
