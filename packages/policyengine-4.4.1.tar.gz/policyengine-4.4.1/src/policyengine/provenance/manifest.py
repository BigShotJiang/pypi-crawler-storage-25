import os
from functools import lru_cache
from importlib import import_module
from importlib.resources import files
from pathlib import Path
from typing import Optional

import requests
from pydantic import BaseModel, Field

HF_REQUEST_TIMEOUT_SECONDS = 30
PYPI_REQUEST_TIMEOUT_SECONDS = 30
LOCAL_DATA_REPO_HINTS = {
    "us": ("policyengine_us", "policyengine-us-data", "policyengine_us_data"),
    "uk": ("policyengine_uk", "policyengine-uk-data", "policyengine_uk_data"),
}


class DataReleaseManifestUnavailableError(ValueError):
    """Raised when a data release manifest cannot be fetched or is absent."""


class PackageVersion(BaseModel):
    name: str
    version: str
    sha256: Optional[str] = None
    wheel_url: Optional[str] = None


class DataPackageVersion(PackageVersion):
    repo_id: str
    repo_type: str = "model"
    release_manifest_path: str = "release_manifest.json"
    release_manifest_revision: Optional[str] = None


class CompatiblePackage(BaseModel):
    name: str
    specifier: str


CompatibleModelPackage = CompatiblePackage


class BuiltWithModelPackage(PackageVersion):
    git_sha: Optional[str] = None
    data_build_fingerprint: Optional[str] = None


class DataBuildInfo(BaseModel):
    build_id: Optional[str] = None
    built_at: Optional[str] = None
    built_with_core_package: Optional[PackageVersion] = None
    built_with_model_package: Optional[BuiltWithModelPackage] = None


class ArtifactPathReference(BaseModel):
    path: str


class ArtifactPathTemplate(BaseModel):
    path_template: str

    def resolve(self, **kwargs: str) -> str:
        return self.path_template.format(**kwargs)


class PreservationMirror(BaseModel):
    """Durable mirror of a data artifact on a preservation-grade host.

    The primary host for PolicyEngine calibrated h5 files is Hugging
    Face, which is fast and integrated with the Python client but does
    not publish a preservation commitment. A ``PreservationMirror``
    records an additional copy on a host that *does* publish one
    (Zenodo, the Internet Archive, or an institutional archive), so a
    TRO citation URL can fall back if the primary location is ever
    unavailable.
    """

    kind: str
    """Short identifier for the preservation host: ``zenodo``, ``internet_archive``, ``archival_gcs``, etc."""

    url: str
    """Dereferenceable HTTPS URL for the mirrored artifact."""

    doi: Optional[str] = None
    """DOI for the preservation deposit, when the host assigns one (Zenodo always does)."""

    sha256: Optional[str] = None
    """Content hash of the mirrored bytes. When equal to the primary artifact's ``sha256``, the mirror is byte-identical and the hash can be reused for verification."""

    deposited_at: Optional[str] = None
    """ISO 8601 timestamp of when the mirror was deposited, if known."""


class DataReleaseArtifact(BaseModel):
    kind: str
    path: str
    repo_id: str
    revision: str
    sha256: Optional[str] = None
    size_bytes: Optional[int] = None
    preservation_mirrors: list[PreservationMirror] = Field(default_factory=list)
    """Durable secondary locations for this artifact. Populated when the
    release pipeline mirrors the artifact to a preservation-grade host.
    Empty when no preservation deposit exists yet."""

    @property
    def uri(self) -> str:
        return build_hf_uri(
            repo_id=self.repo_id,
            path_in_repo=self.path,
            revision=self.revision,
        )


class DataReleaseManifest(BaseModel):
    schema_version: int
    data_package: PackageVersion
    compatible_model_packages: list[CompatiblePackage] = Field(default_factory=list)
    compatible_core_packages: list[CompatiblePackage] = Field(default_factory=list)
    default_datasets: dict[str, str] = Field(default_factory=dict)
    build: Optional[DataBuildInfo] = None
    artifacts: dict[str, DataReleaseArtifact] = Field(default_factory=dict)
    preservation_dois: list[str] = Field(default_factory=list)
    """DOIs covering the release as a whole (Zenodo concept: one DOI
    can enclose the full set of artifacts published together). Distinct
    from per-artifact DOIs on ``DataReleaseArtifact.preservation_mirrors``.
    Populated when the release pipeline mirrors to a DOI-minting host."""


class DataCertification(BaseModel):
    compatibility_basis: str
    certified_for_model_version: str
    data_build_id: Optional[str] = None
    built_with_model_version: Optional[str] = None
    built_with_model_git_sha: Optional[str] = None
    data_build_fingerprint: Optional[str] = None
    certified_by: Optional[str] = None


class CertifiedDataArtifact(BaseModel):
    data_package: Optional[PackageVersion] = None
    dataset: str
    uri: str
    sha256: Optional[str] = None
    build_id: Optional[str] = None


class CountryReleaseManifest(BaseModel):
    schema_version: int = 1
    bundle_id: Optional[str] = None
    published_at: Optional[str] = None
    country_id: str
    policyengine_version: str
    model_package: PackageVersion
    data_package: DataPackageVersion
    default_dataset: str
    datasets: dict[str, ArtifactPathReference] = Field(default_factory=dict)
    region_datasets: dict[str, ArtifactPathTemplate] = Field(default_factory=dict)
    certified_data_artifact: Optional[CertifiedDataArtifact] = None
    certification: Optional[DataCertification] = None

    @property
    def default_dataset_uri(self) -> str:
        if (
            self.certified_data_artifact is not None
            and self.certified_data_artifact.dataset == self.default_dataset
        ):
            return self.certified_data_artifact.uri
        return resolve_dataset_reference(self.country_id, self.default_dataset)


def build_hf_uri(repo_id: str, path_in_repo: str, revision: str) -> str:
    return f"hf://{repo_id}/{path_in_repo}@{revision}"


def https_dataset_uri(repo_id: str, path_in_repo: str, revision: str) -> str:
    """Return a dereferenceable HTTPS URI for a Hugging Face dataset artifact."""
    return f"https://huggingface.co/{repo_id}/resolve/{revision}/{path_in_repo}"


def https_release_manifest_uri(data_package: "DataPackageVersion") -> str:
    """Return a dereferenceable HTTPS URI for a data release manifest."""
    revision = data_package.release_manifest_revision or data_package.version
    return (
        f"https://huggingface.co/{data_package.repo_id}/resolve/"
        f"{revision}/{data_package.release_manifest_path}"
    )


@lru_cache
def fetch_pypi_wheel_metadata(name: str, version: str) -> dict[str, Optional[str]]:
    """Fetch wheel sha256 and URL from PyPI for a package version.

    Returns a dict with ``sha256`` and ``url`` keys. Missing keys are
    returned as ``None`` rather than raising, so TRO construction can
    degrade gracefully when PyPI is unreachable or the package lacks
    a wheel distribution.
    """
    response = requests.get(
        f"https://pypi.org/pypi/{name}/{version}/json",
        timeout=PYPI_REQUEST_TIMEOUT_SECONDS,
    )
    if response.status_code != 200:
        return {"sha256": None, "url": None}
    payload = response.json()
    urls = payload.get("urls") or []
    for entry in urls:
        if entry.get("packagetype") == "bdist_wheel":
            return {
                "sha256": entry.get("digests", {}).get("sha256"),
                "url": entry.get("url"),
            }
    if urls:
        entry = urls[0]
        return {
            "sha256": entry.get("digests", {}).get("sha256"),
            "url": entry.get("url"),
        }
    return {"sha256": None, "url": None}


@lru_cache
def get_release_manifest(country_id: str) -> CountryReleaseManifest:
    manifest_path = files("policyengine").joinpath(
        "data", "release_manifests", f"{country_id}.json"
    )
    if not manifest_path.is_file():
        raise ValueError(f"No bundled release manifest for country '{country_id}'")

    return CountryReleaseManifest.model_validate_json(manifest_path.read_text())


@lru_cache
def get_data_release_manifest(country_id: str) -> DataReleaseManifest:
    country_manifest = get_release_manifest(country_id)

    headers = {}
    token = os.environ.get("HUGGING_FACE_TOKEN")
    if token:
        headers["Authorization"] = f"Bearer {token}"

    try:
        response = requests.get(
            https_release_manifest_uri(country_manifest.data_package),
            headers=headers,
            timeout=HF_REQUEST_TIMEOUT_SECONDS,
        )
    except requests.RequestException as exc:
        raise DataReleaseManifestUnavailableError(
            "Could not fetch the data release manifest from Hugging Face."
        ) from exc

    if response.status_code in (401, 403):
        raise DataReleaseManifestUnavailableError(
            "Could not fetch the data release manifest from Hugging Face. "
            "If this country uses a private data repo, set HUGGING_FACE_TOKEN."
        )
    if response.status_code == 404:
        raise DataReleaseManifestUnavailableError(
            "No data release manifest was published for this data package."
        )
    try:
        response.raise_for_status()
    except requests.RequestException as exc:
        raise DataReleaseManifestUnavailableError(
            "Could not fetch the data release manifest from Hugging Face."
        ) from exc
    return DataReleaseManifest.model_validate_json(response.text)


def _specifier_matches(version: str, specifier: str) -> bool:
    """Match a PEP 440 version specifier (``==``, ``>=``, ``<``, ``,``-joined)."""
    from packaging.specifiers import InvalidSpecifier, SpecifierSet
    from packaging.version import InvalidVersion, Version

    try:
        return Version(version) in SpecifierSet(specifier)
    except (InvalidSpecifier, InvalidVersion):
        return False


def certify_data_release_compatibility(
    country_id: str,
    runtime_model_version: str,
    runtime_data_build_fingerprint: Optional[str] = None,
) -> DataCertification:
    country_manifest = get_release_manifest(country_id)
    try:
        data_release_manifest = get_data_release_manifest(country_id)
    except DataReleaseManifestUnavailableError as exc:
        bundled_certification = country_manifest.certification
        if (
            bundled_certification is not None
            and bundled_certification.certified_for_model_version
            == runtime_model_version
        ):
            if (
                runtime_data_build_fingerprint is not None
                and bundled_certification.data_build_fingerprint is not None
                and runtime_data_build_fingerprint
                != bundled_certification.data_build_fingerprint
            ):
                raise ValueError(
                    "Runtime data build fingerprint does not match the bundled "
                    "data certification."
                )
            return bundled_certification
        raise exc
    built_with_model = (
        data_release_manifest.build.built_with_model_package
        if data_release_manifest.build is not None
        else None
    )

    if (
        built_with_model is not None
        and built_with_model.name != country_manifest.model_package.name
    ):
        raise ValueError(
            "Data release manifest was built with a different model package: "
            f"expected {country_manifest.model_package.name}, "
            f"got {built_with_model.name}."
        )

    if (
        built_with_model is not None
        and built_with_model.version == runtime_model_version
    ):
        return DataCertification(
            compatibility_basis="exact_build_model_version",
            certified_for_model_version=runtime_model_version,
            data_build_id=(
                data_release_manifest.build.build_id
                if data_release_manifest.build is not None
                else None
            ),
            built_with_model_version=built_with_model.version,
            built_with_model_git_sha=built_with_model.git_sha,
            data_build_fingerprint=built_with_model.data_build_fingerprint,
        )

    if (
        built_with_model is not None
        and built_with_model.data_build_fingerprint is not None
        and runtime_data_build_fingerprint is not None
        and built_with_model.data_build_fingerprint == runtime_data_build_fingerprint
    ):
        return DataCertification(
            compatibility_basis="matching_data_build_fingerprint",
            certified_for_model_version=runtime_model_version,
            data_build_id=(
                data_release_manifest.build.build_id
                if data_release_manifest.build is not None
                else None
            ),
            built_with_model_version=built_with_model.version,
            built_with_model_git_sha=built_with_model.git_sha,
            data_build_fingerprint=built_with_model.data_build_fingerprint,
        )

    for compatible_model_package in data_release_manifest.compatible_model_packages:
        if compatible_model_package.name != country_manifest.model_package.name:
            continue
        if _specifier_matches(
            version=runtime_model_version,
            specifier=compatible_model_package.specifier,
        ):
            return DataCertification(
                compatibility_basis="legacy_compatible_model_package",
                certified_for_model_version=runtime_model_version,
                data_build_id=(
                    data_release_manifest.build.build_id
                    if data_release_manifest.build is not None
                    else None
                ),
                built_with_model_version=(
                    built_with_model.version if built_with_model is not None else None
                ),
                built_with_model_git_sha=(
                    built_with_model.git_sha if built_with_model is not None else None
                ),
                data_build_fingerprint=(
                    built_with_model.data_build_fingerprint
                    if built_with_model is not None
                    else None
                ),
            )

    raise ValueError(
        "Data release manifest is not certified for the runtime model version "
        f"{runtime_model_version} in country '{country_id}'."
    )


def resolve_dataset_reference(country_id: str, dataset: str) -> str:
    if "://" in dataset:
        return dataset

    manifest = get_release_manifest(country_id)
    path_reference = manifest.datasets.get(dataset)
    if path_reference is not None:
        return build_hf_uri(
            repo_id=manifest.data_package.repo_id,
            path_in_repo=path_reference.path,
            revision=manifest.data_package.version,
        )

    data_release_manifest = get_data_release_manifest(country_id)
    artifact = data_release_manifest.artifacts.get(dataset)
    if artifact is None:
        raise ValueError(
            f"Unknown dataset '{dataset}' for country '{country_id}'. "
            f"Known datasets: {sorted(manifest.datasets)}"
        )

    return artifact.uri


def resolve_managed_dataset_reference(
    country_id: str,
    dataset: Optional[str] = None,
    *,
    allow_unmanaged: bool = False,
) -> str:
    """Resolve a dataset reference under policyengine.py bundle enforcement.

    Managed mode pins dataset selection to the bundled `policyengine.py`
    release manifest. Callers can:

    - omit `dataset` to use the certified default dataset for the bundle
    - pass a logical dataset name present in the bundled/data-release manifests

    Direct URLs or raw Hugging Face references are treated as unmanaged unless
    `allow_unmanaged=True` is set explicitly.
    """

    manifest = get_release_manifest(country_id)
    if dataset is None:
        return manifest.default_dataset_uri

    if "://" in dataset:
        if dataset == manifest.default_dataset_uri:
            return dataset
        if allow_unmanaged:
            return dataset
        raise ValueError(
            "Explicit dataset URIs bypass the policyengine.py release bundle. "
            "Pass a manifest dataset name or omit `dataset` to use the certified "
            "default dataset. Set `allow_unmanaged=True` only if you intend to "
            "bypass bundle enforcement."
        )

    return resolve_dataset_reference(country_id, dataset)


def resolve_local_managed_dataset_source(
    country_id: str,
    dataset_uri: str,
    *,
    allow_local_mirror: bool = True,
) -> str:
    """Resolve a local mirror of a managed dataset when available.

    This preserves the bundled dataset URI for provenance while allowing local
    development environments with sibling data-repo checkouts to load the
    exact certified artifact from disk rather than re-downloading it.
    """

    if not allow_local_mirror or not dataset_uri.startswith("hf://"):
        return dataset_uri

    local_hint = LOCAL_DATA_REPO_HINTS.get(country_id)
    if local_hint is None:
        return dataset_uri

    path_without_revision = dataset_uri[5:].rsplit("@", 1)[0]
    parts = path_without_revision.split("/", 2)
    if len(parts) != 3:
        return dataset_uri
    _, _, path_in_repo = parts

    model_module_name, data_repo_name, data_package_name = local_hint
    try:
        model_module = import_module(model_module_name)
    except ImportError:
        return dataset_uri

    repo_root = Path(model_module.__file__).resolve().parents[1]
    local_path = (
        repo_root.with_name(data_repo_name)
        / data_package_name
        / "storage"
        / path_in_repo
    )
    if local_path.exists():
        return str(local_path)
    return dataset_uri


def dataset_logical_name(dataset: str) -> str:
    return Path(dataset.rsplit("@", 1)[0]).stem


def resolve_default_datasets(country_id: str) -> list[str]:
    manifest = get_release_manifest(country_id)
    return list(manifest.datasets.keys())


def resolve_region_dataset_path(
    country_id: str,
    region_type: str,
    **kwargs: str,
) -> Optional[str]:
    manifest = get_release_manifest(country_id)
    template = manifest.region_datasets.get(region_type)
    if template is None:
        return None

    resolved_path = template.resolve(**kwargs)
    if "://" in resolved_path:
        return resolved_path

    return build_hf_uri(
        repo_id=manifest.data_package.repo_id,
        path_in_repo=resolved_path,
        revision=manifest.data_package.version,
    )
