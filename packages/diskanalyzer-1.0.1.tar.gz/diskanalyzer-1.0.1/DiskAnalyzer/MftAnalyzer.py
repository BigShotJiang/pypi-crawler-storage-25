#!/usr/bin/env python3
# -*- coding: utf-8 -*-

###################
#    This package implements multiples libraries and tools to parse, analyze
#    and extract informations from disk on the live system.
#    Copyright (C) 2025, 2026  DiskAnalyzer

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
###################

"""
This package implements multiples libraries and tools to parse, analyze
and extract informations from disk on the live system.
"""

__version__ = "1.0.1"
__author__ = "Maurice Lambert"
__author_email__ = "mauricelambert434@gmail.com"
__maintainer__ = "Maurice Lambert"
__maintainer_email__ = "mauricelambert434@gmail.com"
__description__ = """
This package implements multiples libraries and tools to parse, analyze
and extract informations from disk on the live system.
"""
__url__ = "https://github.com/mauricelambert/DiskAnalyzer"

__all__ = [
    "ACEHeader",
    "ACL",
    "AttributeHeader",
    "AttributeHeaderNonResident",
    "AttributeHeaderResident",
    "AttributeList",
    "FileName",
    "MFTEntryHeader",
    "NonResidentAttribute",
    "ResidentAttribute",
    "SecurityDescriptor",
    "StandardInformation",
    "StandardInformationLess2K",
    "get_file_content",
    "parse_mft",
    "file_extract",
    "file_extract_from_csv",
    "write_file_from_csv",
    "get_data_positions",
    "resolve_parents",
    "analyze_mft",
    "extracted_mft_analysis",
]

__license__ = "GPL-3.0 License"
__copyright__ = """
DiskAnalyzer  Copyright (C) 2025, 2026  Maurice Lambert
This program comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under certain conditions.
"""
copyright = __copyright__
license = __license__

from ctypes import (
    LittleEndianStructure,
    c_ubyte,
    c_uint8,
    c_uint32,
    c_char,
    c_uint64,
    c_uint16,
    sizeof,
)
from _io import BufferedRandom, TextIOWrapper, BufferedWriter, BufferedReader
from typing import List, Tuple, Dict, Iterable, Union
from csv import writer, reader, QUOTE_ALL
from datetime import timedelta, datetime
from sys import exit, stderr, argv
from enum import IntEnum, IntFlag
from collections import deque

if __package__:
    from .NtfsAnalyzer import ntfs_parse, parse_correct_ntfs, DRIVE_PATH
else:
    from NtfsAnalyzer import ntfs_parse, parse_correct_ntfs, DRIVE_PATH


class AttributeType(IntEnum):
    STANDARD_INFORMATION  = 0x10
    ATTRIBUTE_LIST        = 0x20
    FILE_NAME             = 0x30
    OBJECT_ID             = 0x40
    SECURITY_DESCRIPTOR   = 0x50
    VOLUME_NAME           = 0x60
    VOLUME_INFORMATION    = 0x70
    DATA                  = 0x80
    INDEX_ROOT            = 0x90
    INDEX_ALLOCATION      = 0xA0
    BITMAP                = 0xB0
    REPARSE_POINT         = 0xC0
    EA_INFORMATION        = 0xD0
    EA                    = 0xE0
    LOGGED_UTILITY_STREAM = 0x100
    END                   = 0xFFFFFFFF


class FileInformationFlags(IntFlag):
    READ_ONLY           = 0x0001
    HIDDEN              = 0x0002
    SYSTEM              = 0x0004
    ARCHIVE             = 0x0020
    DEVICE              = 0x0040
    NORMAL              = 0x0080
    TEMPORARY           = 0x0100
    SPARSE_FILE         = 0x0200
    REPARSE_POINT       = 0x0400
    COMPRESSED          = 0x0800
    OFFLINE             = 0x1000
    NOT_CONTENT_INDEXED = 0x2000
    ENCRYPTED           = 0x4000


class FileNameFlags(IntFlag):
    READ_ONLY           = 0x0001
    HIDDEN              = 0x0002
    SYSTEM              = 0x0004
    ARCHIVE             = 0x0020
    DEVICE              = 0x0040
    NORMAL              = 0x0080
    TEMPORARY           = 0x0100
    SPARSE_FILE         = 0x0200
    REPARSE_POINT       = 0x0400
    COMPRESSED          = 0x0800
    OFFLINE             = 0x1000
    NOT_CONTENT_INDEXED = 0x2000
    ENCRYPTED           = 0x4000
    DIRECTORY           = 0x10000000
    INDEX_VIEW          = 0x20000000


class AceType(IntEnum):
    ACCESS_ALLOWED = 0x00
    ACCESS_DENIED  = 0x01
    SYSTEM_AUDIT   = 0x02


class AceFlags(IntFlag):
    OBJECT_INHERIT       = 0x01
    CONTAINER_INHERIT    = 0x02
    NO_PROPAGATE_INHERIT = 0x04
    INHERIT_ONLY         = 0x08
    AUDIT_SUCCESS        = 0x40
    AUDIT_FAILURE        = 0x80


class AccessMask(IntFlag):
    READ_DATA                 = 0x00000001
    WRITE_DATA                = 0x00000002
    APPEND_DATA               = 0x00000004
    READ_EXTENDED_ATTRIBUTES  = 0x00000008
    WRITE_EXTENDED_ATTRIBUTES = 0x00000010
    EXECUTE                   = 0x00000020
    DELETE_CHILD              = 0x00000040
    READ_ATTRIBUTES           = 0x00000080
    WRITE_ATTRIBUTES          = 0x00000100
    DELETE                    = 0x00010000
    READ_PERMISSIONS          = 0x00020000
    WRITE_DACL                = 0x00040000
    WRITE_OWNER               = 0x00080000
    SYNCHRONIZE               = 0x00100000
    ACCESS_SYSTEM_SECURITY    = 0x01000000
    GENERIC_ALL               = 0x10000000
    GENERIC_EXECUTE           = 0x20000000
    GENERIC_WRITE             = 0x40000000
    GENERIC_READ              = 0x80000000


class SecurityDescriptorControl(IntFlag):
    OWNER_DEFAULTED       = 0x0001
    GROUP_DEFAULTED       = 0x0002
    DACL_PRESENT          = 0x0004
    DACL_DEFAULTED        = 0x0008
    SACL_PRESENT          = 0x0010
    SACL_DEFAULTED        = 0x0020
    DACL_AUTO_INHERIT_REQ = 0x0100
    SACL_AUTO_INHERIT_REQ = 0x0200
    DACL_AUTO_INHERITED   = 0x0400
    SACL_AUTO_INHERITED   = 0x0800
    DACL_PROTECTED        = 0x1000
    SACL_PROTECTED        = 0x2000
    RM_CONTROL_VALID      = 0x4000
    SELF_RELATIVE         = 0x8000


ATTRIBUTE_TYPES = {
    AttributeType.STANDARD_INFORMATION:        '$STANDARD_INFORMATION',        # [resident] Contains file system metadata: creation time, modification time, access time, file flags (readonly, hidden, system), etc
    AttributeType.ATTRIBUTE_LIST:              '$ATTRIBUTE_LIST',              # Used when a file has too many attributes to fit in one MFT record
    AttributeType.FILE_NAME:                   '$FILE_NAME',                   # Contains the file name, its parent directory reference, name namespace and userland modifiable timestamps
    AttributeType.OBJECT_ID:                   '$OBJECT_ID',                   # Contains a 128-bit Object ID (GUID)
    AttributeType.SECURITY_DESCRIPTOR:         '$SECURITY_DESCRIPTOR',         # Stores security metadata: owner SID, ACLs, DACLs
    AttributeType.VOLUME_NAME:                 '$VOLUME_NAME',                 # Contains the volume name of the NTFS partition
    AttributeType.VOLUME_INFORMATION:          '$VOLUME_INFORMATION',          # Flags and version info for the volume: dirty bit, NTFS version
    AttributeType.DATA:                        '$DATA',                        # Holds actual file content. Can be resident (for small files) or non-resident (with data runs)
    AttributeType.INDEX_ROOT:                  '$INDEX_ROOT',                  # Holds the root of the B-tree index for filenames in a folder
    AttributeType.INDEX_ALLOCATION:            '$INDEX_ALLOCATION',            # Contains non-resident blocks of the B-tree
    AttributeType.BITMAP:                      '$BITMAP',                      # Bitmap that tracks allocation of MFT entries or index blocks (contains information about: block free/used)
    AttributeType.REPARSE_POINT:               '$REPARSE_POINT',               # Contains reparse tag and associated data (symbolic links, mount points and OneDrive placeholders)
    AttributeType.EA_INFORMATION:              '$EA_INFORMATION',              # [legacy] Extended Attributes header
    AttributeType.EA:                          '$EA',                          # [obsolete] Extended Attributes
    AttributeType.LOGGED_UTILITY_STREAM:       '$LOGGED_UTILITY_STREAM',       # Internal NTFS metadata used for integrity streams
    AttributeType.END:                         'END',                          # Sentinel value marking the end of attributes in an MFT record
}

FILE_INFORMATION_ATTRIBUTE_FLAGS = {
    FileInformationFlags.READ_ONLY:             "ReadOnly",
    FileInformationFlags.HIDDEN:                "Hidden",
    FileInformationFlags.SYSTEM:                "System",
    FileInformationFlags.ARCHIVE:               "Archive",
    FileInformationFlags.DEVICE:                "Device",
    FileInformationFlags.NORMAL:                "Normal",
    FileInformationFlags.TEMPORARY:             "Temporary",
    FileInformationFlags.SPARSE_FILE:           "Sparse File",
    FileInformationFlags.REPARSE_POINT:         "Reparse Point",
    FileInformationFlags.COMPRESSED:            "Compressed",
    FileInformationFlags.OFFLINE:               "Offline",
    FileInformationFlags.NOT_CONTENT_INDEXED:   "Not Content Indexed",
    FileInformationFlags.ENCRYPTED:             "Encrypted",
}

FILE_NAME_ATTRIBUTE_FLAGS = {
    FileNameFlags.READ_ONLY:                    "Read-Only",
    FileNameFlags.HIDDEN:                       "Hidden",
    FileNameFlags.SYSTEM:                       "System",
    FileNameFlags.ARCHIVE:                      "Archive",
    FileNameFlags.DEVICE:                       "Device",
    FileNameFlags.NORMAL:                       "Normal",
    FileNameFlags.TEMPORARY:                    "Temporary",
    FileNameFlags.SPARSE_FILE:                  "Sparse File",
    FileNameFlags.REPARSE_POINT:                "Reparse Point",
    FileNameFlags.COMPRESSED:                   "Compressed",
    FileNameFlags.OFFLINE:                      "Offline",
    FileNameFlags.NOT_CONTENT_INDEXED:          "Not Content Indexed",
    FileNameFlags.ENCRYPTED:                    "Encrypted",
    FileNameFlags.DIRECTORY:                    "Directory",
    FileNameFlags.INDEX_VIEW:                   "Index View",
}

ACE_TYPE_MAP = {
    AceType.ACCESS_ALLOWED:                     "Access Allowed",
    AceType.ACCESS_DENIED:                      "Access Denied",
    AceType.SYSTEM_AUDIT:                       "System Audit",
}

ACE_FLAG_MAP = {
    AceFlags.OBJECT_INHERIT:                    "Object Inherit",
    AceFlags.CONTAINER_INHERIT:                 "Container Inherit",
    AceFlags.NO_PROPAGATE_INHERIT:              "No Propagate Inherit",
    AceFlags.INHERIT_ONLY:                      "Inherit Only",
    AceFlags.AUDIT_SUCCESS:                     "Audit Success",
    AceFlags.AUDIT_FAILURE:                     "Audit Failure",
}

ACCESS_MASK_FLAGS = {
    AccessMask.READ_DATA:                       "ReadData / ListDirectory",
    AccessMask.WRITE_DATA:                      "WriteData / AddFile",
    AccessMask.APPEND_DATA:                     "AppendData / AddSubdirectory",
    AccessMask.READ_EXTENDED_ATTRIBUTES:        "ReadExtendedAttributes",
    AccessMask.WRITE_EXTENDED_ATTRIBUTES:       "WriteExtendedAttributes",
    AccessMask.EXECUTE:                         "Execute / Traverse",
    AccessMask.DELETE_CHILD:                    "DeleteChild",
    AccessMask.READ_ATTRIBUTES:                 "ReadAttributes",
    AccessMask.WRITE_ATTRIBUTES:                "WriteAttributes",
    AccessMask.DELETE:                          "Delete",
    AccessMask.READ_PERMISSIONS:                "ReadPermissions",
    AccessMask.WRITE_DACL:                      "WriteDACL",
    AccessMask.WRITE_OWNER:                     "WriteOwner",
    AccessMask.SYNCHRONIZE:                     "Synchronize",
    AccessMask.ACCESS_SYSTEM_SECURITY:          "AccessSystemSecurity",
    AccessMask.GENERIC_ALL:                     "GenericAll",
    AccessMask.GENERIC_EXECUTE:                 "GenericExecute",
    AccessMask.GENERIC_WRITE:                   "GenericWrite",
    AccessMask.GENERIC_READ:                    "GenericRead",
}

SECURITY_DESCRIPTOR_CONTROL_FLAGS = {
    SecurityDescriptorControl.OWNER_DEFAULTED:          "Owner Defaulted",
    SecurityDescriptorControl.GROUP_DEFAULTED:          "Group Defaulted",
    SecurityDescriptorControl.DACL_PRESENT:             "DACL Present",
    SecurityDescriptorControl.DACL_DEFAULTED:           "DACL Defaulted",
    SecurityDescriptorControl.SACL_PRESENT:             "SACL Present",
    SecurityDescriptorControl.SACL_DEFAULTED:           "SACL Defaulted",
    SecurityDescriptorControl.DACL_AUTO_INHERIT_REQ:    "DACL Auto Inherit Req",
    SecurityDescriptorControl.SACL_AUTO_INHERIT_REQ:    "SACL Auto Inherit Req",
    SecurityDescriptorControl.DACL_AUTO_INHERITED:      "DACL Auto Inherited",
    SecurityDescriptorControl.SACL_AUTO_INHERITED:      "SACL Auto Inherited",
    SecurityDescriptorControl.DACL_PROTECTED:           "DACL Protected",
    SecurityDescriptorControl.SACL_PROTECTED:           "SACL Protected",
    SecurityDescriptorControl.RM_CONTROL_VALID:         "RM Control Valid",
    SecurityDescriptorControl.SELF_RELATIVE:            "Self Relative",
}


class MFTEntryHeader(LittleEndianStructure):
    """
    This class defines the MFT entry structure.
    """

    _pack_ = 1
    _fields_ = [
        ("signature", c_char * 4),           # Signature "FILE"
        ("fixup_offset", c_uint16),          # FixupOffset
        ("fixup_entries", c_uint16),         # FixupEntries
        ("log_seq_number", c_uint64),        # Lsn
        ("sequence_number", c_uint16),       # SequenceNumber
        ("hard_link_count", c_uint16),       # HardLinkCount
        ("first_attr_offset", c_uint16),     # FirstAttributeOffset
        ("flags", c_uint16),                 # Flags, 0x01 = in-use, 0x02 = directory
        ("used_entry_size", c_uint32),       # UsedSize
        ("allocated_entry_size", c_uint32),  # AllocatedSize
        ("base_file_record", c_uint64),      # BaseFileRecord
        ("next_attr_id", c_uint16),          # NextAttributeId
        ("align", c_uint16),                 # Align
        ("mft_record_number", c_uint32),     # MftRecordNumber
    ]


class AttributeHeader(LittleEndianStructure):
    """
    This class defines the MFT attribute headers.
    """

    _pack_ = 1
    _fields_ = [
        ("type_id", c_uint32),
        ("length", c_uint32),
        ("non_resident", c_uint8),
        ("name_length", c_uint8),
        ("name_offset", c_uint16),
        ("flags", c_uint16),
        ("attribute_id", c_uint16),
    ]


class AttributeHeaderResident(LittleEndianStructure):
    """
    This class defines the full MFT resident
    attribute headers (value inside the MFT,
    small value - ~700 bytes).
    """

    _pack_ = 1
    _fields_ = [
        ("type_id", c_uint32),
        ("length", c_uint32),
        ("non_resident", c_uint8),  # 0 = resident, 1 = non-resident
        ("name_length", c_uint8),
        ("name_offset", c_uint16),
        ("flags", c_uint16),
        ("attribute_id", c_uint16),
        ("attr_length", c_uint32),
        ("attr_offset", c_uint16),
        ("indexed_flag", c_uint8),
        ("padding", c_uint8),
    ]


class ResidentAttribute(LittleEndianStructure):
    """
    This class defines the MFT resident attribute
    specific fields (value inside the MFT,
    small value - ~700 bytes).
    """

    _pack_ = 1
    _fields_ = [
        ("value_length", c_uint32),
        ("value_offset", c_uint16),
        ("flags", c_uint8),
        ("reserved", c_uint8),
    ]

    def read_resident_data(self, data: bytes) -> bytes:
        """
        This method reads data from MFT entry (resident data).
        """

        return data[self.value_offset : self.value_offset + self.value_length]


class AttributeHeaderNonResident(LittleEndianStructure):
    """
    This class defines the full MFT non resident
    attribute headers (value outside the MFT,
    value > ~700 bytes).
    """

    _pack_ = 1
    _fields_ = [
        ("type_id", c_uint32),
        ("length", c_uint32),
        ("non_resident", c_uint8),  # 0 = resident, 1 = non-resident
        ("name_length", c_uint8),
        ("name_offset", c_uint16),
        ("flags", c_uint16),
        ("attribute_id", c_uint16),
        ("starting_vcn", c_uint64),
        ("last_vcn", c_uint64),
        ("data_run_offset", c_uint16),
        ("compression_unit_size", c_uint16),
        ("reserved", c_uint32),
        ("allocated_size", c_uint64),
        ("real_size", c_uint64),
        ("initialized_size", c_uint64),
    ]

    def parse_data_runs(self, cluster_size: int) -> List[Tuple[int, int]]:
        """
        This method parses data runs (data: length, offset).
        """

        i = 0
        lcn = 0
        self.data_runs = []
        self.size = 0

        while i < len(self.data_runs_data):
            header = self.data_runs_data[i]
            i += 1
            if header == 0x00:
                break

            len_size = header & 0x0F
            off_size = (header >> 4) & 0x0F

            length_bytes = self.data_runs_data[i : i + len_size]
            i += len_size
            offset_bytes = self.data_runs_data[i : i + off_size]
            i += off_size

            length = int.from_bytes(length_bytes, "little")

            if off_size > 0:
                offset = int.from_bytes(
                    offset_bytes
                    + (b"\x00" if offset_bytes[-1] < 0x80 else b"\xff")
                    * (8 - off_size),
                    "little",
                    signed=True,
                )
                lcn += offset

            size = length * cluster_size
            self.size += size
            self.data_runs.append((lcn * cluster_size, size))

        return self.data_runs

    def read_data_runs(
        self, file: BufferedReader, ntfs_offset: int
    ) -> Iterable[bytes]:
        """
        This generator yields content block by content block.
        """

        for offset, size in self.data_runs:
            file.seek(ntfs_offset + offset)
            yield file.read(size)

    def read_content(
        self, file: BufferedReader, ntfs_offset: int
    ) -> bytearray:
        """
        This method returns content as bytearray.
        """

        content = bytearray()
        for block in self.read_data_runs(file, ntfs_offset):
            content.extend(block)
        return content


class NonResidentAttribute(LittleEndianStructure):
    """
    This class defines the MFT non resident attribute
    specific fields (value outside the MFT,
    value > ~700 bytes).
    """

    _pack_ = 1
    _fields_ = [
        ("starting_vcn", c_uint64),
        ("last_vcn", c_uint64),
        ("data_run_offset", c_uint16),
        ("compression_unit_size", c_uint16),
        ("reserved", c_uint32),
        ("allocated_size", c_uint64),
        ("real_size", c_uint64),
        ("initialized_size", c_uint64),
    ]


class StandardInformationLess2K(LittleEndianStructure):
    """
    This class defines the $STANDARD_INFORMATION MFT attribute.
    """

    _pack_ = 1
    _fields_ = [
        ("CreationTime", c_uint64),        # 0x00
        ("ModificationTime", c_uint64),    # 0x08
        ("MFTChangeTime", c_uint64),       # 0x10
        ("AccessTime", c_uint64),          # 0x18
        ("FileAttributes", c_uint32),      # 0x20
        ("MaxVersions", c_uint32),         # 0x24
        ("VersionNumber", c_uint32),       # 0x28
        ("ClassId", c_uint32),             # 0x2C
    ]

    def __str__(self):
        return (
            "[+] $STANDARD_INFORMATION detected\n"
            f"  Creation time:          {self.creation_time}\n"
            f"  Modification time:      {self.modification_time}\n"
            f"  MFT change time:        {self.mft_modification_time}\n"
            f"  Access time:            {self.access_time}\n"
            f"  File attributes:        {self.FileAttributes}\n"
            + (
                (
                    "    "
                    + ", ".join(
                        parse_standard_information_flags(self.FileAttributes)
                    )
                    + "\n"
                )
                if self.FileAttributes
                else ""
            )
            + f"  Max versions:           {self.MaxVersions}\n"
            f"  Version number:         {self.VersionNumber}\n"
            f"  Class ID:               {self.ClassId}\n"
        )


class StandardInformation(LittleEndianStructure):
    """
    This class defines the $STANDARD_INFORMATION MFT attribute.
    """

    _pack_ = 1
    _fields_ = [
        ("CreationTime", c_uint64),     # 0x00 (kerneland)
        ("ModificationTime", c_uint64), # 0x08 (kerneland)
        ("MFTChangeTime", c_uint64),    # 0x10 (kerneland)
        ("AccessTime", c_uint64),       # 0x18 (kerneland)
        ("FileAttributes", c_uint32),   # 0x20
        ("MaxVersions", c_uint32),      # 0x24
        ("VersionNumber", c_uint32),    # 0x28
        ("ClassId", c_uint32),          # 0x2C
        ("OwnerId", c_uint32),          # 0x30 (2K+)
        ("SecurityId", c_uint32),       # 0x34 (2K+)
        ("QuotaCharged", c_uint64),     # 0x38 (2K+)
        ("USN", c_uint64),              # 0x40 (2K+)
    ]

    def __str__(self):
        return (
            "[+] $STANDARD_INFORMATION detected\n"
            f"  Creation time:          {self.creation_time} (kerneland)\n"
            f"  Modification time:      {self.modification_time} (kerneland)\n"
            f"  MFT change time:        {self.mft_modification_time} (kerneland)\n"
            f"  Access time:            {self.access_time} (kerneland)\n"
            f"  File attributes:        {self.FileAttributes}\n"
            + (
                (
                    "    "
                    + ", ".join(
                        parse_standard_information_flags(self.FileAttributes)
                    )
                    + "\n"
                )
                if self.FileAttributes
                else ""
            )
            + f"  Max versions:           {self.MaxVersions}\n"
            f"  Version number:         {self.VersionNumber}\n"
            f"  Class ID:               {self.ClassId}\n"
            f"  Owner ID:               {self.OwnerId}\n"
            f"  Security ID:            {self.SecurityId}\n"
            f"  Quota charged:          {self.QuotaCharged}\n"
            f"  Update Sequence Number: {self.USN}\n"
        )


class AttributeList(LittleEndianStructure):
    """
    This class defines the $ATTRIBUTE_LIST MFT attribute.
    """

    _pack_ = 1
    _fields_ = [
        ("Type", c_uint32),              # 4 bytes: Type of the attribute list (typically 0x00)
        ("RecordLength", c_uint16),      # 2 bytes: Record length
        ("NameLength", c_ubyte),         # 1 byte:  Name length
        ("OffsetToName", c_ubyte),       # 1 byte:  Offset to the name
        ("StartingVCN", c_uint64),       # 8 bytes: Starting VCN (Virtual Cluster Number)
        ("BaseFileReference", c_uint64), # 8 bytes: Base file reference
        ("AttributeId", c_uint16),       # 2 bytes: Attribute ID
    ]

    def __str__(self):
        return (
            "[+] $ATTRIBUTE_LIST detected\n"
            f"  Type:                         {self.Type}\n"
            f"  Record length:                {self.RecordLength}\n"
            f"  Name length:                  {self.NameLength}\n"
            f"  Name offset:                  {self.OffsetToName}\n"
            f"  Virtual Cluster Number start: {self.StartingVCN}\n"
            f"  Base file reference:          {self.BaseFileReference}\n"
            f"  Attribute ID:                 {self.AttributeId}\n"
            f"  Name:                         {self.name}\n"
        )


class FileName(LittleEndianStructure):
    """
    This class defines the $FILE_NAME MFT attribute.
    """

    _pack_ = 1
    _fields_ = [
        ("ParentDirectory", c_uint64),    # 0x00: 8 bytes: File reference to the parent directory
        ("CreationTime", c_uint64),       # 0x08: 8 bytes: File creation time (userland)
        ("ModificationTime", c_uint64),   # 0x10: 8 bytes: Last write (modified) time (userland)
        ("MFTChangeTime", c_uint64),      # 0x18: 8 bytes: Last change to MFT entry (not file content) (userland)
        ("AccessTime", c_uint64),         # 0x20: 8 bytes: Last access time (userland)
        ("AllocatedSize", c_uint64),      # 0x28: 8 bytes: Allocated size of the file
        ("RealSize", c_uint64),           # 0x30: 8 bytes: Actual file size
        ("Flags", c_uint32),              # 0x38: 4 bytes: Flags (e.g., Directory, compressed, hidden)
        ("Reserved", c_uint32),           # 0x3C: 4 bytes: Reserved for future use (Extended Attributes, Reparse)
        ("FileNameLength", c_ubyte),      # 0x40: 1 byte:  Filename length in characters
        ("FileNameNamespace", c_ubyte),   # 0x41: 1 byte:  Filename namespace (e.g., Win32, DOS)
                                          # 0x42: X wchar: Filename content
    ]

    def __str__(self):
        return (
            "[+] $FILE_NAME detected\n"
            f"  Creation time:          {self.creation_time} (userland)\n"
            f"  Modification time:      {self.modification_time} (userland)\n"
            f"  MFT change time:        {self.mft_modification_time} (userland)\n"
            f"  Access time:            {self.access_time} (userland)\n"
            f"  Allocated size:         {self.AllocatedSize}\n"
            f"  Real size:              {self.RealSize}\n"
            f"  Flags:                  {self.Flags}\n"
            + (
                ("    " + ", ".join(parse_file_name_flags(self.Flags)) + "\n")
                if self.Flags
                else ""
            )
            + f"  Reserved:               {self.Reserved}\n"
            f"  Filename length:        {self.FileNameLength}\n"
            f"  Filename Namespace:     {self.FileNameNamespace}\n"
            f"  Name:                   {self.name}\n"
        )


class SecurityDescriptor(LittleEndianStructure):
    """
    This class defines the $SECURITY_DESCRIPTOR MFT attribute.
    """

    _pack_ = 1
    _fields_ = [
        ("Revision", c_uint8),
        ("Padding1", c_uint8),
        ("ControlFlags", c_uint16),
        ("OffsetOwner", c_uint32),
        ("OffsetGroup", c_uint32),
        ("OffsetSACL", c_uint32),
        ("OffsetDACL", c_uint32),
    ]

    def __str__(self):
        if self.sacl:
            sacl_indent = "\n  " + str(self.sacl).replace("\n", "\n  ")
        if self.dacl:
            dacl_indent = "\n  " + str(self.dacl).replace("\n", "\n  ")
        return (
            "[+] $SECURITY_DESCRIPTOR detected\n"
            f"  Revision:  {self.Revision}\n"
            f"  Padding:   {self.Padding1}\n"
            f"  Control flags:      {self.ControlFlags}\n"
            + (
                (
                    "    "
                    + ", ".join(parse_control_flags(self.ControlFlags))
                    + "\n"
                )
                if self.ControlFlags
                else ""
            )
            + f"  Offset owner: {self.OffsetOwner}"
            + (f" ({self.owner_sid})" if self.owner_sid else "")
            + "\n"
            f"  Offset group: {self.OffsetGroup}"
            + (f" ({self.group_sid})" if self.group_sid else "")
            + "\n"
            + (f"  SACL: {sacl_indent}\n" if self.sacl else "")
            + (f"  DACL: {dacl_indent}" if self.dacl else "")
        )


class ACL(LittleEndianStructure):
    """
    This class defines the MFT Access Control List structure.
    """

    _pack_ = 1
    _fields_ = [
        ("AclRevision", c_uint8),
        ("Padding1", c_uint8),
        ("AclSize", c_uint16),
        ("AceCount", c_uint16),
        ("Padding2", c_uint16),
    ]

    def __str__(self):
        ace_indent = "\n    " + "\n".join(str(x) for x in self.ace).replace(
            "\n", "\n    "
        )
        return (
            "[+] ACL detected\n"
            f"  Revision:  {self.AclRevision}\n"
            f"  Padding:   {self.Padding1}\n"
            f"  Size:      {self.AclSize}\n"
            f"  Ace count: {self.AceCount}\n"
            f"  ACE: {ace_indent}"
        )


class ACEHeader(LittleEndianStructure):
    """
    This class defines the MFT ACE header structure.
    """

    _pack_ = 1
    _fields_ = [
        ("AceType", c_uint8),
        ("AceFlags", c_uint8),
        ("AceSize", c_uint16),
        ("AccessMask", c_uint32),
        # SID follows dynamically
    ]

    def __str__(self):
        return (
            "[+] ACE Header detected\n"
            f"  Type:        {ACE_TYPE_MAP.get(self.AceType, f'Unknown ({self.AceType})')} ({self.AceType})\n"
            f"  Flags:       {self.AceFlags}\n"
            + (
                ("    " + ", ".join(parse_ace_flags(self.AceFlags)) + "\n")
                if self.AceFlags
                else ""
            )
            + f"  Size:        {self.AceSize}\n"
            f"  Access mask: {self.AccessMask}\n"
            + (
                ("    " + ", ".join(parse_access_mask(self.AccessMask)) + "\n")
                if self.AccessMask
                else ""
            )
            + f"  SID:         {self.sid}"
        )


# $OBJECT_ID
# $REPARSE_POINT
# $INDEX_ROOT
# $INDEX_ALLOCATION
# $BITMAP

parent_directories: Dict[Tuple[int, int], Tuple[int, int]] = {}
records_sequences: Dict[int, int] = {}
file_names: Dict[Tuple[int, int], str] = {}


def get_parent_directory_record(directory_record: int) -> Tuple[int, int]:
    """
    This function returns the parent directory record ID and the sequence.
    """

    return (
        directory_record & 0x0000FFFFFFFFFFFF,
        (directory_record >> 48) & 0xFFFF,
    )


def resolve_parents(
    name: str, record_sequence: Tuple[int, int], base: str = None
) -> str:
    """
    This function returns the parents directory string representation.
    """

    full_path = deque([name])
    while (
        new_record_sequence := parent_directories.get(record_sequence)
    ) and record_sequence != new_record_sequence:
        if name := file_names.get(new_record_sequence):
            pass
        elif sequence := records_sequences.get(new_record_sequence[0]):
            new_record_sequence = (new_record_sequence[0], sequence)
            name = file_names[new_record_sequence]
            base = "$BROKEN_SEQUENCE"
        else:
            print(
                "Error: no name for",
                new_record_sequence,
                "parent for",
                "\\".join(full_path),
                file=stderr,
            )
            base = "$BROKEN_RECORD"
            break

        full_path.appendleft(name)
        record_sequence = new_record_sequence

    if base:
        full_path.appendleft(base)
    return "\\".join(full_path)


def parse_sid(data: bytes) -> Tuple[str, int]:
    """
    This function converts SID data to human readable format.
    """

    revision = data[0]
    subauth_count = data[1]
    id_auth = int.from_bytes(data[2:8], "big")
    sid_parts = [
        int.from_bytes(data[8 + i * 4 : 12 + i * 4], "little")
        for i in range(subauth_count)
    ]
    sid = f"S-{revision}-{id_auth}" + "".join(f"-{x}" for x in sid_parts)
    sid_length = 8 + subauth_count * 4
    return sid, sid_length


def parse_acl(data: bytes) -> ACL:
    """
    This function parses ACL and ACEs.
    """

    acl = ACL.from_buffer_copy(data)
    entries = []
    acl_size = sizeof(ACL)

    for _ in range(acl.AceCount):
        ace_hdr = ACEHeader.from_buffer_copy(data[acl_size:])
        sid, sid_len = parse_sid(data[acl_size + 8 :])
        ace_hdr.sid = sid
        entries.append(ace_hdr)
        acl_size += ace_hdr.AceSize

    acl.ace = entries
    return acl


def parse_security_descriptor(
    attribute_header: Union[
        AttributeHeaderResident, AttributeHeaderNonResident
    ],
    file: BufferedReader,
    ntfs_offset: int,
) -> Union[SecurityDescriptor, None]:
    """
    This function parses the $SECURITY_DESCRIPTOR MFT attribute.
    """

    data = get_attribute_data(attribute_header, file, ntfs_offset)
    if not data:
        attribute_header.parsing = None
        return None

    security_descriptor = SecurityDescriptor.from_buffer_copy(data[:20])
    security_descriptor.owner_sid = security_descriptor.group_sid = (
        security_descriptor.sacl
    ) = security_descriptor.dacl = None

    if security_descriptor.OffsetOwner:
        sid, _ = parse_sid(data[security_descriptor.OffsetOwner :])
        security_descriptor.owner_sid = sid

    if security_descriptor.OffsetGroup:
        sid, _ = parse_sid(data[security_descriptor.OffsetGroup :])
        security_descriptor.group_sid = sid

    if security_descriptor.OffsetSACL:
        security_descriptor.sacl = parse_acl(
            data[security_descriptor.OffsetSACL :],
        )

    if security_descriptor.OffsetDACL:
        security_descriptor.dacl = parse_acl(
            data[security_descriptor.OffsetDACL :]
        )

    attribute_header.parsing = security_descriptor
    return security_descriptor


def get_attribute_data(
    attribute_header: Union[
        AttributeHeaderResident, AttributeHeaderNonResident
    ],
    file: BufferedReader,
    ntfs_offset: int,
) -> Union[bytes, None]:
    """
    This function returns attribute data from resident and non resident attribute.
    """

    if attribute_header.non_resident:
        if ntfs_offset is None:
            return None
        return attribute_header.read_content(file, ntfs_offset)
    else:
        return attribute_header.data


def parse_attribute_list(
    attribute_header: Union[
        AttributeHeaderResident, AttributeHeaderNonResident
    ],
    file: BufferedReader,
    ntfs_offset: int,
) -> List[AttributeList]:
    """
    This function parses a $ATTRIBUTE_LIST MFT attribute.
    """

    offset = 0
    entries = []
    data = get_attribute_data(attribute_header, file, ntfs_offset)
    if not data:
        return entries

    while offset < len(data):
        attribute_list = AttributeList.from_buffer_copy(data)

        if attribute_list.RecordLength == 0:
            break

        entry_data = data[offset : offset + attribute_list.RecordLength]

        name = ""
        if attribute_list.NameLength > 0:
            name_offset = attribute_list.OffsetToName
            name_end = name_offset + attribute_list.NameLength * 2
            try:
                name = entry_data[name_offset:name_end].decode("utf-16-le")
            except UnicodeDecodeError:
                name = repr(entry_data[name_offset:name_end].decode("latin1"))

        attribute_list.name = name
        entries.append(attribute_list)
        offset += attribute_list.RecordLength

    attribute_header.parsing = entries
    return entries


def filetime_to_datetime(filetime: int) -> Union[datetime]:
    """
    This function converts windows filetime to python datetime.
    """

    if filetime == 0:
        return None

    try:
        return datetime(1601, 1, 1) + timedelta(microseconds=filetime / 10)
    except OverflowError:
        return None


def parse_standard_information(
    attribute_header: Union[
        AttributeHeaderResident, AttributeHeaderNonResident
    ],
    file: BufferedReader,
    ntfs_offset: int,
) -> None:
    """
    This function parses the $STANDARD_INFORMATION MFT attribute.
    """

    data = get_attribute_data(attribute_header, file, ntfs_offset)
    if not data:
        attribute_header.parsing = None
        return None

    if len(data) == 48:
        standard_information = StandardInformationLess2K.from_buffer_copy(data)
    else:
        standard_information = StandardInformation.from_buffer_copy(data)
    standard_information.creation_time = filetime_to_datetime(
        standard_information.CreationTime
    )
    standard_information.modification_time = filetime_to_datetime(
        standard_information.ModificationTime
    )
    standard_information.mft_modification_time = filetime_to_datetime(
        standard_information.MFTChangeTime
    )
    standard_information.access_time = filetime_to_datetime(
        standard_information.AccessTime
    )
    attribute_header.parsing = standard_information


def parse_file_name(
    attribute_header: Union[
        AttributeHeaderResident, AttributeHeaderNonResident
    ],
    file: BufferedReader,
    ntfs_offset: int,
) -> None:
    """
    This function parses the $FILE_NAME MFT attribute.
    """

    data = get_attribute_data(attribute_header, file, ntfs_offset)
    if not data:
        attribute_header.parsing = None
        return None

    filename = FileName.from_buffer_copy(data)
    filename.creation_time = filetime_to_datetime(filename.CreationTime)
    filename.modification_time = filetime_to_datetime(
        filename.ModificationTime
    )
    filename.mft_modification_time = filetime_to_datetime(
        filename.MFTChangeTime
    )
    filename.access_time = filetime_to_datetime(filename.AccessTime)
    attribute_header.parsing = filename

    name = ""
    if filename.FileNameLength > 0:
        offset = sizeof(FileName)
        try:
            name = data[offset : offset + filename.FileNameLength * 2].decode(
                "utf-16-le"
            )
        except UnicodeDecodeError:
            name = repr(
                data[offset : offset + filename.FileNameLength * 2].decode(
                    "latin1"
                )
            )

    filename.name = name


def parse_standard_information_flags(flags: int) -> List[str]:
    """
    This function returns the string values for MFT entry flags.
    """

    return [
        name
        for bit, name in FILE_INFORMATION_ATTRIBUTE_FLAGS.items()
        if flags & bit
    ]


def parse_file_name_flags(flags: int) -> List[str]:
    """
    This function returns the string values for MFT entry flags.
    """

    return [
        name for bit, name in FILE_NAME_ATTRIBUTE_FLAGS.items() if flags & bit
    ]


def parse_control_flags(flags: int) -> List[str]:
    """
    This function returns human readable control flags from flags value.
    """

    return [
        desc
        for bit, desc in SECURITY_DESCRIPTOR_CONTROL_FLAGS.items()
        if flags & bit
    ]


def parse_ace_flags(flags: int) -> List[str]:
    """
    This function returns human readable ACE flags from flags value.
    """

    return [name for bit, name in ACE_FLAG_MAP.items() if flags & bit]


def parse_access_mask(mask: int) -> List[str]:
    """
    This function returns human readable access flags from flags value.
    """

    return [name for bit, name in ACCESS_MASK_FLAGS.items() if mask & bit]


def parse_mft_flags(flags: int) -> List[str]:
    """
    This function returns the string values for MFT entry flags.
    """

    FLAG_MAP = {
        0x0001: "IN_USE",
        0x0002: "DIRECTORY",
        0x0004: "SYSTEM",
        0x0008: "NOT_INDEXED",
    }
    return [name for bit, name in FLAG_MAP.items() if flags & bit]


def parse_attribute_flags(flags: int) -> List[str]:
    """
    This function returns the string values for MFT attribute flags.
    """

    ATTR_FLAGS = {
        0x0001: "COMPRESSED",
        0x4000: "ENCRYPTED",
        0x8000: "SPARSE",
    }
    return [name for bit, name in ATTR_FLAGS.items() if flags & bit]


def get_mft_entry_size(value: int, cluster_size: int) -> int:
    """
    This function returns the MFT entry size.
    """

    if value < 0:
        return 2 ** abs(value)
    else:
        return value * cluster_size


ATTRIBUTEHEADERSIZE = sizeof(AttributeHeader)
ATTRIBUTEHEADERRESIDENTSIZE = sizeof(AttributeHeaderResident)
ATTRIBUTEHEADERNONRESIDENTSIZE = sizeof(AttributeHeaderNonResident)


def walk_attributes(
    data: bytes,
    mft_entry: MFTEntryHeader,
    entry_offset: int,
    cluster_size: int,
    file: BufferedReader,
    ntfs_offset: int,
) -> None:
    """
    This function loops over one entry attributes.
    """

    offset = entry_offset
    data_size = len(data)

    attribute_header = AttributeHeader.from_buffer_copy(
        data[offset : offset + ATTRIBUTEHEADERSIZE]
    )

    while attribute_header.type_id and attribute_header.type_id != 0xFFFFFFFF:
        if attribute_header.non_resident == 0:
            # resident = ResidentAttribute.from_buffer_copy(data[offset + sizeof(AttributeHeader):])
            attribute_header = AttributeHeaderResident.from_buffer_copy(
                data[offset : offset + ATTRIBUTEHEADERNONRESIDENTSIZE]
            )
            # value_offset = offset + resident.value_offset
            attribute_header.value_offset = (
                offset + attribute_header.attr_offset
            )
            attribute_header.data = data[
                attribute_header.value_offset : attribute_header.value_offset
                + attribute_header.attr_length
            ]
        else:
            # nonresident = NonResidentAttribute.from_buffer_copy(data[offset + sizeof(AttributeHeader):])
            attribute_header = AttributeHeaderNonResident.from_buffer_copy(
                data[offset : offset + ATTRIBUTEHEADERNONRESIDENTSIZE]
            )
            attribute_header.value_offset = (
                offset + attribute_header.data_run_offset
            )
            attribute_header.data_runs_data = data[
                attribute_header.value_offset :
            ]
            attribute_header.parse_data_runs(cluster_size)

        if attribute_header.type_id == AttributeType.STANDARD_INFORMATION:
            parse_standard_information(attribute_header, file, ntfs_offset)
        elif attribute_header.type_id == AttributeType.ATTRIBUTE_LIST:
            parse_attribute_list(attribute_header, file, ntfs_offset)
        elif attribute_header.type_id == AttributeType.FILE_NAME:
            parse_file_name(attribute_header, file, ntfs_offset)
            parent_directories[
                (mft_entry.mft_record_number, mft_entry.sequence_number)
            ] = get_parent_directory_record(
                attribute_header.parsing.ParentDirectory
            )
            if (
                sequence := records_sequences.get(mft_entry.mft_record_number)
            ) is None or sequence < mft_entry.sequence_number:
                records_sequences[mft_entry.mft_record_number] = (
                    mft_entry.sequence_number
                )
            file_names[
                (mft_entry.mft_record_number, mft_entry.sequence_number)
            ] = attribute_header.parsing.name
        elif attribute_header.type_id == AttributeType.SECURITY_DESCRIPTOR:
            parse_security_descriptor(attribute_header, file, ntfs_offset)

        attribute_header.offset = offset
        attribute_header.name = ATTRIBUTE_TYPES.get(
            attribute_header.type_id, hex(attribute_header.type_id)
        )
        mft_entry.attributes.append(attribute_header)
        offset += attribute_header.length

        if data[offset : offset + 4] == b"\xff\xff\xff\xff":
            break

        if offset + ATTRIBUTEHEADERSIZE > data_size:
            print(
                "Attribute length too big:",
                hex(attribute_header.length),
                "next attribute end:",
                offset + ATTRIBUTEHEADERSIZE,
                "greater than entry size",
                data_size,
                file=stderr,
            )
            break

        attribute_header = AttributeHeader.from_buffer_copy(
            data[offset : offset + ATTRIBUTEHEADERSIZE]
        )


def parse_mft_entry(
    file: BufferedReader,
    entry_size: int = 1024,
    ntfs_offset: int = None,
    cluster_size: int = 4096,
) -> Tuple[MFTEntryHeader, bytes]:
    """
    This function parses a single MFT entry.
    """

    data = file.read(entry_size)
    return (
        build_mft_entry(data, file, entry_size, ntfs_offset, cluster_size),
        data,
    )


def build_mft_entry(
    data: bytes,
    file: BufferedReader,
    entry_size: int = 1024,
    ntfs_offset: int = None,
    cluster_size: int = 4096,
) -> MFTEntryHeader:
    """
    This function built a MFT entry.
    """

    mft_entry = MFTEntryHeader.from_buffer_copy(data)
    data = apply_fixup(data, mft_entry)
    mft_entry = MFTEntryHeader.from_buffer_copy(data)
    mft_entry.attributes = []
    walk_attributes(
        data,
        mft_entry,
        mft_entry.first_attr_offset,
        cluster_size,
        file,
        ntfs_offset,
    )

    return mft_entry


def parse_file(
    file: BufferedReader,
    offset: int,
    entry_size: int = 1024,
    ntfs_offset: int = None,
    cluster_size: int = 4096,
) -> Tuple[MFTEntryHeader, bytes]:
    """
    This function parses a MFT file from the disk.
    """

    file.seek(offset)
    return parse_mft_entry(file, entry_size, ntfs_offset, cluster_size)


def parse_extracted_mft(
    file: BufferedReader, entry_size: int = 1024
) -> Iterable[MFTEntryHeader]:
    """
    This function parses an extracted MFT.
    """

    data = file.read(entry_size)
    while len(data) == entry_size:
        yield build_mft_entry(data, file, entry_size)
        data = file.read(entry_size)


def parse_mft(*args, **kwargs) -> (
    Tuple[BufferedReader, MFTEntryHeader, bytes, int, int, int, int]
):
    """
    This function parses the MFT from the disk, using NTFS
    partition and VBR (first sector).
    """

    file, vbr, ntfs_offset = parse_correct_ntfs(*ntfs_parse(*args, **kwargs))
    cluster_size = vbr.bytes_per_sector * vbr.sectors_per_cluster
    mft_offset_bytes = ntfs_offset + (vbr.mft_lcn * cluster_size)
    mft_entry_size = get_mft_entry_size(
        vbr.clusters_per_mft_record, cluster_size
    )

    mft_entry, data = parse_file(
        file, mft_offset_bytes, mft_entry_size, ntfs_offset, cluster_size
    )
    return (
        file,
        mft_entry,
        data,
        mft_offset_bytes,
        mft_entry_size,
        ntfs_offset,
        cluster_size,
    )


def get_file_content(
    file: BufferedReader,
    mft_entry: MFTEntryHeader,
    ntfs_offset: int,
    mft_entry_raw_data: bytes,
) -> Iterable[bytes]:
    """
    This generator yields FILE content blocks or resident data.
    """

    for attribute in mft_entry.attributes:
        if attribute.type_id == AttributeType.DATA:
            if attribute.non_resident:
                yield from attribute.read_data_runs(file, ntfs_offset)
            else:
                # yield attribute.read_resident_data(mft_entry_raw_data)
                yield attribute.data


def print_file(mft_entry: MFTEntryHeader) -> None:
    """
    This function prints the FILE values.
    """

    print("[+] MFT Entry Detected")
    print(f"  Signature:              {bytes(mft_entry.signature).decode()}")
    print(f"  Fixup offset:           {mft_entry.fixup_offset}")
    print(f"  Fixup entries:          {mft_entry.fixup_entries}")
    print(f"  Log sequence number:    {mft_entry.log_seq_number}")
    print(f"  Sequence #:             {mft_entry.sequence_number}")
    print(f"  Hard Links:             {mft_entry.hard_link_count}")
    print(f"  First attribute offset: {mft_entry.first_attr_offset}")
    print(f"  Flags:                  {hex(mft_entry.flags)}")
    if mft_entry.flags:
        print("     ", ", ".join(parse_mft_flags(mft_entry.flags)))
    print(f"  Used entry size:        {mft_entry.used_entry_size}")
    print(f"  Allocated entry size:   {mft_entry.allocated_entry_size}")
    print(f"  Next attribute ID:      {mft_entry.next_attr_id}")
    print(f"  MFT Record #:           {mft_entry.mft_record_number}")

    for attribute in mft_entry.attributes:
        non_resident = bool(attribute.non_resident)
        print(f"\n[+] Attribute detected: {attribute.name} at offset {attribute.offset}")
        print(f"  Type ID:                      {attribute.type_id}")
        print(f"  Length:                       {attribute.length}")
        print(f"  Non-resident:                 {non_resident}")
        print(f"  Name length:                  {attribute.name_length}")
        print(f"  Name offset:                  {attribute.name_offset}")
        print(f"  Flags:                        {hex(attribute.flags)}")
        if attribute.flags:
            print("     ", ", ".join(parse_attribute_flags(attribute.flags)))
        print(f"  Attribute ID:                 {hex(attribute.attribute_id)}")

        if non_resident:
            print(f"  Starting VCN:                 {attribute.starting_vcn}")
            print(f"  Last VCN:                     {attribute.last_vcn}")
            print(f"  Non-resident DATA run offset: {attribute.data_run_offset}")
            print(f"  Compression unit size:        {attribute.compression_unit_size}")
            print(f"  Reserved:                     {attribute.reserved}")
            print(f"  Allocated size:               {attribute.allocated_size}")
            print(f"  Real size:                    {attribute.real_size}")
            print(f"  Initialized size:             {attribute.initialized_size}")
            print(f"  Size:                         {attribute.size}")
        else:
            print(f"  Resident value length:        {attribute.attr_length}")
            print(f"  Value offset:                 {attribute.attr_offset}")
            print(f"  Indexed flag:                 {bool(attribute.indexed_flag)} (fast lookup: map $FILE_NAME in the $I30 index to the MFT entry for big directory)")
            print(f"  Padding:                      {attribute.padding}")
            print(f"  Value (hex):                  {attribute.data.hex()}")

        if getattr(attribute, "parsing", None):
            if isinstance(attribute.parsing, list):
                parsing_indent = "\n    " + "\n".join(
                    (str(x) for x in attribute.parsing)
                ).replace("\n", "\n    ")
            else:
                parsing_indent = "\n  " + str(attribute.parsing).replace(
                    "\n", "\n  "
                )
            print(f"  Value parsed: {parsing_indent}")


def apply_fixup(data: bytes, mft_entry: MFTEntryHeader) -> bytes:
    """
    This function apply the NTFS fixup array to restore correct sector-end bytes.
    """

    data = bytearray(data)
    fixup_offset = mft_entry.fixup_offset
    signature = int.from_bytes(data[fixup_offset:fixup_offset + 2], "little")

    for i in range(1, mft_entry.fixup_entries):
        sector_end = i * 512 - 2
        actual = int.from_bytes(data[fixup_offset + i * 2:fixup_offset + i * 2 + 2], "little")
        if int.from_bytes(data[sector_end:sector_end + 2], "little") != signature:
            print(f"Fixup signature mismatch at sector {i}", file=stderr)
        data[sector_end:sector_end + 2] = actual.to_bytes(2, "little")
    return bytes(data)


def file_extract(
    file: BufferedReader,
    mft_entry: MFTEntryHeader,
    destination_path: str,
    mft_entry_raw_data: bytes,
    ntfs_offset: int,
) -> None:
    """
    This function extracts the full MFT file content.
    """

    with open(destination_path, "wb") as mft_extract:
        for block in get_file_content(
            file, mft_entry, ntfs_offset, mft_entry_raw_data
        ):
            mft_extract.write(block)


def get_data_positions(
    mft_entry: MFTEntryHeader, mft_entry_offset: int, ntfs_offset: int
) -> Iterable[Tuple[int, int, bool]]:
    """
    This generator yields each pair offset and size with boolean for resident data.
    """

    for attribute in mft_entry.attributes:
        if attribute.type_id == AttributeType.DATA:
            if attribute.non_resident:
                for offset, size in attribute.data_runs:
                    yield ntfs_offset + offset, size, False
            else:
                yield mft_entry_offset + attribute.value_offset, attribute.attr_length, True


def get_mft_entries_offsets(
    mft_entry: MFTEntryHeader,
    mft_entry_offset: int,
    mft_entry_size: int,
    ntfs_offset: int,
) -> Iterable[Tuple[int, int, bool]]:
    """
    This generator yields each pair offset and size for MFT entries.
    """

    for offset, size, _ in get_data_positions(
        mft_entry, mft_entry_offset, ntfs_offset
    ):
        first = True
        while size >= mft_entry_size:
            yield offset, size, first
            offset += mft_entry_size
            size -= mft_entry_size
            first = False


def analyze_mft(
    file: BufferedReader,
    mft_entry: MFTEntryHeader,
    mft_entry_raw_data: bytes,
    mft_entry_offset: int,
    mft_entry_size: int,
    ntfs_offset: int,
    cluster_size: int,
) -> Iterable[
    Tuple[
        Tuple[MFTEntryHeader, bytes],
        int,
    ]
]:
    """
    This generator analyzes the full MFT using the disk/partition disk.
    This generator yields each MFT entries, data, offset, size, first entry for the data block
    (if True: offset and full size written in MFT $DATA else: modified size and offset).
    """

    for offset, size, first in get_mft_entries_offsets(
        mft_entry, mft_entry_offset, mft_entry_size, ntfs_offset
    ):
        yield parse_file(
            file, offset, mft_entry_size, ntfs_offset, cluster_size
        ), offset, size, first


def acl_to_csv_str(acl: ACL) -> str:
    """
    Converts an ACL object ($DACL or $SACL) into a single CSV-friendly string.
    Each ACE in the ACL is represented as: Type|Flags|AccessMask|SID
    Multiple ACEs are separated by semicolons (;).

    If the ACL is empty or has no ACEs, an empty string is returned.

    Example output:
        "Allow|Read,Write|0x1F01FF|S-1-5-21-...,Deny|Delete|0x10000|S-1-5-32-544"

    Parameters:
        acl (ACL): The ACL object to convert. Can be a DACL or SACL from a SecurityDescriptor.

    Returns:
        str: A string representation of the ACL suitable for a CSV cell.
    """

    if not acl or not hasattr(acl, "ace") or not acl.ace:
        return ""

    ace_strings = []
    for ace in acl.ace:
        ace_type = ACE_TYPE_MAP.get(ace.AceType, f"Unknown({ace.AceType})")
        ace_flags = (
            ", ".join(parse_ace_flags(ace.AceFlags)) if ace.AceFlags else ""
        )
        access_mask = (
            ", ".join(parse_access_mask(ace.AccessMask))
            if ace.AccessMask
            else ""
        )
        sid = getattr(ace, "sid", "")
        ace_strings.append(f"{ace_type}|{ace_flags}|{access_mask}|{sid}")

    return ";".join(ace_strings)


def save_attribute(
    csv_writer: writer,
    mft_entry: MFTEntryHeader,
    entry_mft_offset: int,
    data_positions: List[Tuple[int, int, str]],
) -> None:
    """
    This function saves a MFT entry in a CSV format,
    for each $FILE_NAME the MFT entry and information is duplicated,
    there is only one $STANDARD_INFORMATION and $SECURITY_DESCRIPTOR by MFT entry.

    The CSV contains the MFT entry offset (an integer) and the data positions
    and sizes in the following format: offset|size;offset|size;...

    MFT entry
        SequenceNumber:   sequence_number
        Flags:            flags # 0x01 = in-use, 0x02 = directory
        MftRecordNumber:  mft_record_number
    $STANDARD_INFORMATION
        CreationTime:     creation_time
        ModificationTime: modification_time
        MFTChangeTime:    mft_modification_time
        AccessTime:       access_time
        FileAttributes: ", ".join(parse_standard_information_flags(self.FileAttributes))
        USN
    $FILE_NAME
        ParentDirectory
        CreationTime:     creation_time
        ModificationTime: modification_time
        MFTChangeTime:    mft_modification_time
        AccessTime:       access_time
        AllocatedSize:    AllocatedSize
        RealSize:         RealSize
        Flags:            ", ".join(parse_file_name_flags(self.Flags))
        FileNameNamespace:name
    $SECURITY_DESCRIPTOR
        ControlFlags:     ", ".join(parse_control_flags(self.ControlFlags))
        Owner:            owner_sid
        Group:            group_sid
        DACL:             dacl
        SACL:             sacl
    """

    if data_positions:
        data_positions_str = ";".join(
            f"{offset}|{size}|{resident}"
            for offset, size, resident in data_positions
        )
    else:
        data_positions_str = ""

    standard_information = StandardInformation()
    standard_information.creation_time = (
        standard_information.modification_time
    ) = standard_information.mft_modification_time = (
        standard_information.access_time
    ) = str(None)
    security_descriptor = SecurityDescriptor()
    security_descriptor.owner_sid = security_descriptor.group_sid = (
        security_descriptor.dacl
    ) = security_descriptor.sacl = str(None)
    file_names = []

    for attribute in mft_entry.attributes:
        if attribute.type_id == AttributeType.STANDARD_INFORMATION:
            standard_information = attribute.parsing
        elif attribute.type_id == AttributeType.FILE_NAME:
            file_names.append(attribute.parsing)
        elif attribute.type_id == AttributeType.SECURITY_DESCRIPTOR:
            security_descriptor = attribute.parsing

    if not file_names:
        file_name = FileName()
        file_name.creation_time = file_name.modification_time = (
            file_name.mft_modification_time
        ) = file_name.access_time = file_name.name = str(None)
        file_names = [file_name]

    for file_name in file_names:
        csv_writer.writerow(
            [
                str(entry_mft_offset),
                data_positions_str,
                str(mft_entry.sequence_number),
                ", ".join(
                    flag
                    for bit, flag in ((0x01, "InUse"), (0x02, "Directory"))
                    if mft_entry.flags & bit
                ),
                str(mft_entry.mft_record_number),
                standard_information.creation_time,
                standard_information.modification_time,
                standard_information.mft_modification_time,
                standard_information.access_time,
                ", ".join(
                    parse_standard_information_flags(
                        standard_information.FileAttributes
                    )
                ),
                str(getattr(standard_information, "USN", None)),
                str(file_name.ParentDirectory),
                file_name.creation_time,
                file_name.modification_time,
                file_name.mft_modification_time,
                file_name.access_time,
                str(file_name.AllocatedSize),
                str(file_name.RealSize),
                ", ".join(parse_file_name_flags(file_name.Flags)),
                file_name.name,  # In my VM, MFT was corrupted, some filename contains illegal characters, so use repr if needed
                ", ".join(
                    parse_control_flags(security_descriptor.ControlFlags)
                ),
                security_descriptor.owner_sid,
                security_descriptor.group_sid,
                acl_to_csv_str(security_descriptor.dacl),
                acl_to_csv_str(security_descriptor.sacl),
            ]
        )


def get_identifiers_from_csv(
    filepath: str, full_path_csv: TextIOWrapper
) -> Tuple[int, int]:
    """
    This function returns (record, sequence) from CSV full path file.
    """

    full_path_csv.seek(0)
    for data in reader(full_path_csv):
        record, sequence, name, full_path = data
        if filepath == full_path:
            return int(record), int(sequence)

    raise FileNotFoundError(filepath + " not found in MFT")


def get_file_content_from_csv(
    filepath: str,
    entries_csv: TextIOWrapper,
    full_path_csv: TextIOWrapper,
    file: BufferedReader,
) -> Iterable[bytes]:
    """
    This function extracts file chunk contents from CSV files.
    """

    for offset, size, resident in get_file_chunks_from_csv(
        filepath, entries_csv, full_path_csv, file
    ):
        file.seek(int(offset))
        yield file.read(int(size))


def get_file_chunks_from_csv(
    filepath: str,
    entries_csv: TextIOWrapper,
    full_path_csv: TextIOWrapper,
    file: BufferedReader,
) -> Iterable[Tuple[int, int, str]]:
    """
    This function extracts chunks offset and size from CSV files.
    """

    record_sequence = get_identifiers_from_csv(filepath, full_path_csv)

    entries_csv.seek(0)
    for data in reader(entries_csv):
        record = int(data[4])
        sequence = int(data[2])
        if (record, sequence) == record_sequence:
            for data_positions in (x for x in data[1].split(";")):
                offset, size, resident = data_positions.split("|")
                yield int(offset), int(size), resident


def write_file_from_csv(
    filepath: str,
    data: bytes,
    entries_csv: TextIOWrapper,
    full_path_csv: TextIOWrapper,
    file: BufferedRandom,
    offset: int = 0,
) -> None:
    """
    This function writes files from CSV.
    """

    chunks = list(
        get_file_chunks_from_csv(filepath, entries_csv, full_path_csv, file)
    )
    size = sum(x[1] for x in chunks)

    if len(data) > (size - offset):
        raise ValueError("data length greater than file size with offset")

    for chunk_offset, size, _ in chunks:
        if offset:
            if size > offset:
                size -= offset
                chunk_offset += offset
                offset = 0
            else:
                offset -= size
                continue

        write_chunck(file, chunk_offset, size, data[:size])


def file_extract_from_csv(
    filepath: str,
    target: BufferedWriter,
    entries_csv: TextIOWrapper,
    full_path_csv: TextIOWrapper,
    file: BufferedReader,
) -> None:
    """
    This function extracts file content from CSV files.
    """

    for content in get_file_content_from_csv(
        filepath, entries_csv, full_path_csv, file
    ):
        target.write(content)


def write_chunck(
    file: BufferedRandom, offset: int, size: int, data: bytes
) -> int:
    """
    This function writes a chunk.
    """

    if len(data) > size:
        raise ValueError("chunk size lower than data length")

    file.seek(offset)
    file.write(data)


def extracted_mft_analysis(mft: BufferedReader, entries: writer, fullpath: writer) -> Iterable[Tuple[MFTEntryHeader, List[Tuple[int, int, str]]]]:
    """
    This generator parses an extracted MFT file, export entries data
    and full paths in CSV and yields MFT entry and data positions tuples.
    """

    for mft_entry in parse_extracted_mft(mft):
        data_positions = []
        for offset, size, resident in get_data_positions(mft_entry, 0, 0):
            data_positions.append((offset, size, "resident" if resident else "non-resident"))
        save_attribute(entries, mft_entry, mft.tell(), data_positions)
        yield mft_entry, data_positions

    for record_sequence, name in file_names.items():
        full_path = resolve_parents(name, record_sequence, mft.name)
        fullpath.writerow(
            [
                str(record_sequence[0]),
                str(record_sequence[1]),
                name,
                full_path,
            ]
        )


def main(copyright: bool = True) -> int:
    """
    The main function to starts the script from the command line.
    """

    if copyright:
        print(copyright)

    if len(argv) == 2:
        filename = argv[1]
    elif len(argv) == 1:
        filename = DRIVE_PATH
    else:
        print("USAGES:", executable, argv[0], "[filepath]", file=stderr)
        return 1

    (
        file,
        mft_entry,
        mft_entry_raw_data,
        mft_entry_offset,
        mft_entry_size,
        ntfs_offset,
        cluster_size,
    ) = parse_mft(file_path=filename)

    if mft_entry.signature != b"FILE":
        print("Invalid MFT entry signature.")
        return 1

    print_file(mft_entry)
    file_extract(file, mft_entry, "$MFT", mft_entry_raw_data, ntfs_offset)

    csv_file = open("MftEntries.csv", "w", newline="", encoding="utf-8")
    csv_writer = writer(csv_file, quoting=QUOTE_ALL)
    for (mft_entry, mft_entry_raw), offset, size, first in analyze_mft(
        file,
        mft_entry,
        mft_entry_raw_data,
        mft_entry_offset,
        mft_entry_size,
        ntfs_offset,
        cluster_size,
    ):
        # print_file(mft_entry)
        # input()

        data_positions = []
        for offset, size, resident in get_data_positions(
            mft_entry, mft_entry_offset, ntfs_offset
        ):
            data_positions.append(
                (offset, size, "resident" if resident else "non-resident")
            )

        save_attribute(csv_writer, mft_entry, offset, data_positions)
    csv_file.close()

    with open("FullPath.csv", "w", newline="", encoding="utf-8") as csv_file:
        csv_writer = writer(csv_file, quoting=QUOTE_ALL)
        for record_sequence, name in file_names.items():
            full_path = resolve_parents(name, record_sequence, file.name)
            csv_writer.writerow(
                [
                    str(record_sequence[0]),
                    str(record_sequence[1]),
                    name,
                    full_path,
                ]
            )
            # if full_path == '.\\Windows\\System32\\config\\SAM' or full_path == '.\\Windows\\System32\\config\\SYSTEM':
            #     with open("MftEntries.csv", newline='', encoding="utf-8") as database, open(name, 'wb') as content:
            #         for data in reader(database):
            #             if (int(data[4]), int(data[2])) == record_sequence:
            #                 for data_positions in (x for x in data[1].split(';')):
            #                     offset, size, resident = data_positions.split("|")
            #                     file.seek(int(offset))
            #                     content.write(file.read(int(size)))

    # with open("MftEntries.csv", newline='', encoding="utf-8") as entries, open("FullPath.csv", newline='', encoding="utf-8") as full_path, open("SAM", 'wb') as sam, open("SYSTEM", 'wb') as system, open(file.name, 'rb+') as raw_writer:
    #     file_extract_from_csv('.\\Windows\\System32\\config\\SAM', sam, entries, full_path, file)
    #     file_extract_from_csv('.\\Windows\\System32\\config\\SYSTEM', system, entries, full_path, file)
    #     write_file_from_csv("", b'', entries, full_path, raw_writer)

    # for mft_entry in parse_extracted_mft(open("$MFT", "rb")):
    #     print_file(mft_entry)
    #     input()

    return 0


if __name__ == "__main__":
    exit(main())

r"""
>>> import DiskAnalyzer.MftAnalyzer
>>> with open("MftEntries.csv", newline='', encoding="utf-8") as entries, open("FullPath.csv", newline='', encoding="utf-8") as full_path, open("SAM", 'wb') as sam, open("SYSTEM", 'wb') as system, open('\\\\.\\\C:', 'rb') as file:
...     DiskAnalyzer.MftAnalyzer.file_extract_from_csv('.\\Windows\\System32\\config\\SAM', sam, entries, full_path, file)
...     DiskAnalyzer.MftAnalyzer.file_extract_from_csv('.\\Windows\\System32\\config\\SYSTEM', system, entries, full_path, file)
...
"""
