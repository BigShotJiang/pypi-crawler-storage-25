#!/usr/bin/env python3
# -*- coding: utf-8 -*-

###################
#    This package implements multiples libraries and tools to parse, analyze
#    and extract informations from disk on the live system.
#    Copyright (C) 2026  DiskAnalyzer

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.
###################

r"""
This package implements multiples libraries and tools to parse, analyze
and extract informations from disk on the live system.

~# dd if=/dev/zero of=disk.img bs=1M count=200
200+0 records in
200+0 records out
209715200 bytes (210 MB, 200 MiB) copied, 0.11415 s, 1.8 GB/s

~# fdisk disk.img

Welcome to fdisk (util-linux 2.41.3).
Changes will remain in memory only, until you decide to write them.
Be careful before using the write command.

Device does not contain a recognized partition table.
Created a new DOS (MBR) disklabel with disk identifier 0x88d08f9b.

Command (m for help): n
Partition type
   p   primary (0 primary, 0 extended, 4 free)
   e   extended (container for logical partitions)
Select (default p): p
Partition number (1-4, default 1): 1
First sector (2048-409599, default 2048):
Last sector, +/-sectors or +/-size{K,M,G,T,P} (2048-409599, default 409599):

Created a new partition 1 of type 'Linux' and of size 199 MiB.

Command (m for help): t
Selected partition 1
Hex code or alias (type L to list all): b
Changed type of partition 'Linux' to 'W95 FAT32'.

Command (m for help): p
Disk fat32.img: 200 MiB, 209715200 bytes, 409600 sectors
Units: sectors of 1 * 512 = 512 bytes
Sector size (logical/physical): 512 bytes / 512 bytes
I/O size (minimum/optimal): 512 bytes / 512 bytes
Disklabel type: dos
Disk identifier: 0x88d08f9b

Device     Boot Start    End Sectors  Size Id Type
fat32.img1       2048 409599  407552  199M  b W95 FAT32

Command (m for help): w
The partition table has been altered.

~# sudo losetup -Pf disk.img
~# losetup -a
/dev/loop0: []: (/home/kali/fat32.img)
~# sudo mkfs.fat -F 32 /dev/loop0p1
mkfs.fat 4.2 (2021-01-31)
~# sudo mkdir -p /mnt/fat32
~# sudo mount /dev/loop0p1 /mnt/fat32
~# echo "Hello FAT32" > /mnt/fat32/test.txt
~# mkdir /mnt/fat32/dir1
~# echo "Nested file" > /mnt/fat32/dir1/nested.txt
~# touch "/mnt/fat32/ThisIsALongFileNameToTestLFN.txt"
~# python3 -c 'open("/mnt/fat32/big.txt", "w").write("a"*8000)'
~# dd if=/dev/urandom of=/mnt/fat32/big.bin bs=1M count=20
~# sudo umount /mnt/fat32
~# sudo losetup -d /dev/loop0

https://github.com/procount/fat32images/raw/refs/heads/master/noobs1gb.img.zip

C:\> certutil -urlcache https://github.com/RCH2514/Medium-attachments/raw/refs/heads/main/stick.img
C:\> python -m DiskAnalyzer.MbrRepair stick.img

DiskAnalyzer  Copyright (C) 2025, 2026  Maurice Lambert
This program comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under certain conditions.

Warning: No main partition found, partitions found: EMPTY EMPTY EMPTY EMPTY
[?] <enter> to search partitions, Ctrl+C to stop...
[!] Found a new FAT32 partition at 6 with 49152 sectors (end: 25168896 B)
End Of File
Last sector 49158
[?] <enter> to write a new unbootable MBR, Ctrl+C to stop...

C:\> python -m DiskAnalyzer.MbrRepair stick.img

DiskAnalyzer  Copyright (C) 2025, 2026  Maurice Lambert
This program comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under certain conditions.

Warning: No main partition found, partitions found: FAT32 EMPTY EMPTY EMPTY
[?] <enter> to search partitions, Ctrl+C to stop...
C:\> python -m DiskAnalyzer.Fat32Analyzer -v stick.img
[+] MBR Detected
  Bootloader
    ebfeffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    ffffffffffff
  Partition 1:
    Status       : 0x00 (INACTIVE)
    Type         : 0x0B (FAT32)
    Start LBA    : 6
    Total Sectors: 49152 (24.00 MB)
  Boot Signature
    55aa

[+] FAT32 Boot Sector Detected
  Jump Boot: eb5890
  OEM Name: mkfs.fat
  Bytes Per Sector: 512
  Sectors Per Cluster: 1
  Reserved Sector Count: 32
  Number of FATs: 2
  Root Entry Count: 0
  Total Sectors 16: 49152
  Media: 248
  FAT Size 16: 0
  Sector per track: 32
  Number of heads: 4
  Hidden Sectors: 0
  Total Sectors 32: 0
  FAT Size 32: 378
  Extended Flags: 0
  File System version: 0
  Root Cluster: 2
  FSInfo Sector: 1
  Backup Boot Sector: 6
  Reserved: 000000000000000000000000
  Drive Number: 0x80
  Reserved: 0
  Boot Signature: 0x29
  Volume ID: 0x8caae860
  Volume Label: NO NAME
  File System Type: FAT32
  Boot code:
    0e1fbe777cac22c0740b56b40ebb0700cd105eebf032e4cd16cd19ebfe54686973206973206e6f74
    206120626f6f7461626c65206469736b2e2020506c6561736520696e73657274206120626f6f7461
    626c6520666c6f70707920616e640d0a707265737320616e79206b657920746f2074727920616761
    696e202e2e2e200d0a00000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    0000000000000000000000000000000000000000
BootSectorSignature: aa55

[+] FSInfo Sector
  Lead Signature: 0x41615252
  Reserved:
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
    00000000000000000000000000000000000000000000000000000000000000000000000000000000
  Struct Signature: 0x61417272
  Free Count: 48363
  Next Free Cluster: 2
  Reserved: 000000000000000000000000
  Trail Signature: 0xaa550000
[>] Partition size in sector: 49152

[+] Directory Entry Found
  Long name: notes.txt
  Name: NOTES.TXT
  Attributes: ARCHIVE
  NT Reserved: 0
  Creation Time: 22:27:22.082
  Creation Date: 2025-07-17
  Last Access Date: 2025-07-17
  Write Time: 22:27:22
  Write Date: 2025-07-17
  First Cluster: 3
  File Size: 76 bytes
  File content:
    4e6f7465733a0a2d207072616374696365206d79207a6172726f772073687566666c650a2d206c65
    61726e20736f6d652066616c736520637574730a2d20706c617920736f6d65207374730a

[+] Directory Entry Found
  Long name: random_thoughts.txt
  Name: RANDOM~1.TXT
  Attributes: ARCHIVE
  NT Reserved: 0
  Creation Time: 22:27:22.082
  Creation Date: 2025-07-17
  Last Access Date: 2025-07-17
  Write Time: 22:27:22
  Write Date: 2025-07-17
  First Cluster: 4
  File Size: 56 bytes
  File content:
    6920776f6e6465722077686572652069207075742074686520666c61672e2064696420692070616c
    6d20697420736f6d6577686572653f0a

[+] Directory Entry Found
  Long name: secret_magic_collection.gz
  Deleted file
  Partial name: ECRET~1.GZ
  Attributes: ARCHIVE
  NT Reserved: 0
  Creation Time: 22:27:22.083
  Creation Date: 2025-07-17
  Last Access Date: 2025-07-17
  Write Time: 22:27:22
  Write Date: 2025-07-17
  First Cluster: 5
  File Size: 60 bytes
  File content:
    1f8b0808ca7879680003666c61672e747874002b4e2eca2c28710e71ab368ccf3128338ecf353133
    4c8e372f324cce36ade502000ba1b6db1f000000
C:\>

>>> print(bytes.fromhex("4e6f7465733a0a2d207072616374696365206d79207a6172726f772073687566666c650a2d206c6561726e20736f6d652066616c736520637574730a2d20706c617920736f6d65207374730a").decode())
Notes:
- practice my zarrow shuffle
- learn some false cuts
- play some sts

>>> print(bytes.fromhex("6920776f6e6465722077686572652069207075742074686520666c61672e2064696420692070616c6d20697420736f6d6577686572653f0a").decode())
i wonder where i put the flag. did i palm it somewhere?

>>> from gzip import decompress
>>> print(decompress(bytes.fromhex("1f8b0808ca7879680003666c61672e747874002b4e2eca2c28710e71ab368ccf3128338ecf3531334c8e372f324cce36ade502000ba1b6db1f000000")).decode())
scriptCTF{1_l0v3_m461c_7r1ck5}

>>>
"""

__version__ = "0.0.1"
__author__ = "Maurice Lambert"
__author_email__ = "mauricelambert434@gmail.com"
__maintainer__ = "Maurice Lambert"
__maintainer_email__ = "mauricelambert434@gmail.com"
__description__ = """
This package implements multiples libraries and tools to parse, analyze
and extract informations from disk on the live system.
"""
__url__ = "https://github.com/mauricelambert/DiskAnalyzer"

__all__ = [
    "get_partition",
    "fat32_parse",
    "print_fat32_bootsector",
    "fat32_enumeration",
    "print_directory_entry",
    "save_directory_entry_to_csv",
]

__license__ = "GPL-3.0 License"
__copyright__ = """
DiskAnalyzer  Copyright (C) 2026  Maurice Lambert
This program comes with ABSOLUTELY NO WARRANTY.
This is free software, and you are welcome to redistribute it
under certain conditions.
"""
copyright = __copyright__
license = __license__

from ctypes import (
    LittleEndianStructure,
    c_char,
    c_uint8,
    c_uint16,
    c_uint32,
)

if __package__:
    from .DiskAnalyzer import (
        GPTHeader,
        MBRHeader,
        Partition,
        print_gpt_analysis,
        print_mbr_analysis,
        disk_parsing,
        SECTOR_SIZE,
    )
else:
    from DiskAnalyzer import (
        GPTHeader,
        MBRHeader,
        Partition,
        print_gpt_analysis,
        print_mbr_analysis,
        disk_parsing,
        SECTOR_SIZE,
    )

from typing import Tuple, Iterable, List, Union
from sys import exit, stderr, argv, executable
from csv import DictWriter, QUOTE_ALL
from _io import BufferedReader
from datetime import datetime
from collections import deque
from enum import IntEnum


class FAT32EntryAttr(IntEnum):
    READ_ONLY = 0x01
    HIDDEN = 0x02
    SYSTEM = 0x04
    VOLUME_ID = 0x08
    DIRECTORY = 0x10
    ARCHIVE = 0x20
    LFN = 0x0F  # Long File Name


class FAT32EntryState(IntEnum):
    EMPTY = 0x00
    DELETED = 0xE5
    VALID = 0x01


class FAT32BootSector(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [
        # Jump instruction + OEM
        ("JumpBoot", c_uint8 * 3),              # 0x00
        ("OEMName", c_char * 8),                # 0x03

        # BIOS Parameter Block (BPB)
        ("BytesPerSector", c_uint16),           # 0x0B
        ("SectorsPerCluster", c_uint8),         # 0x0D
        ("ReservedSectorCount", c_uint16),      # 0x0E
        ("NumFATs", c_uint8),                   # 0x10
        ("RootEntryCount", c_uint16),           # 0x11 (0 pour FAT32)
        ("TotalSectors16", c_uint16),           # 0x13
        ("Media", c_uint8),                     # 0x15
        ("FATSize16", c_uint16),                # 0x16 (0 pour FAT32)
        ("SectorsPerTrack", c_uint16),          # 0x18
        ("NumHeads", c_uint16),                 # 0x1A
        ("HiddenSectors", c_uint32),            # 0x1C
        ("TotalSectors32", c_uint32),           # 0x20

        # FAT32 Extended BPB
        ("FATSize32", c_uint32),                # 0x24
        ("ExtFlags", c_uint16),                 # 0x28
        ("FSVersion", c_uint16),                # 0x2A
        ("RootCluster", c_uint32),              # 0x2C
        ("FSInfoSector", c_uint16),             # 0x30
        ("BackupBootSector", c_uint16),         # 0x32
        ("Reserved", c_uint8 * 12),             # 0x34

        # Drive info
        ("DriveNumber", c_uint8),               # 0x40
        ("Reserved1", c_uint8),                 # 0x41
        ("BootSignature", c_uint8),             # 0x42 (0x29)
        ("VolumeID", c_uint32),                 # 0x43
        ("VolumeLabel", c_char * 11),           # 0x47
        ("FileSystemType", c_char * 8),         # 0x52 ("FAT32   ")

        # Boot code
        ("BootCode", c_uint8 * 420),            # 0x5A
        ("BootSectorSignature", c_uint16),      # 0x1FE
    ]


class FAT32FSInfo(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [
        ("LeadSignature", c_uint32),           # 0x00  - 0x03  (0x41615252)
        ("Reserved1", c_uint8 * 480),          # 0x04  - 0x1DF
        ("StructSignature", c_uint32),         # 0x1E0 - 0x1E3 (0x61417272)
        ("FreeCount", c_uint32),               # 0x1E4 - 0x1E7
        ("NextFree", c_uint32),                # 0x1E8 - 0x1EB
        ("Reserved2", c_uint8 * 12),           # 0x1EC - 0x1F7
        ("TrailSignature", c_uint32),          # 0x1F8 - 0x1FB (0xAA550000)
    ]


# Directory Entry (32 bytes)
class FAT32DirEntry(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [
        ("Name", c_char * 8),
        ("Ext", c_char * 3),
        ("Attr", c_uint8),
        ("NTReserved", c_uint8),
        ("CreationTimeTenth", c_uint8),
        ("CreationTime", c_uint16),
        ("CreationDate", c_uint16),
        ("LastAccessDate", c_uint16),
        ("ClusterHigh", c_uint16),
        ("WriteTime", c_uint16),
        ("WriteDate", c_uint16),
        ("ClusterLow", c_uint16),
        ("FileSize", c_uint32),
    ]

    @property
    def state(self) -> FAT32EntryState:
        if len(self.Name) == 0:
            return FAT32EntryState.EMPTY

        first_byte = self.Name[0]
        if first_byte == FAT32EntryState.EMPTY:
            return FAT32EntryState.EMPTY
        elif first_byte == FAT32EntryState.DELETED:
            return FAT32EntryState.DELETED
        else:
            return FAT32EntryState.VALID

    @property
    def is_empty(self) -> bool:
        return self.state == FAT32EntryState.EMPTY

    @property
    def is_deleted(self) -> bool:
        return self.state == FAT32EntryState.DELETED

    @property
    def is_lfn(self) -> bool:
        return self.Attr == FAT32EntryAttr.LFN

    @property
    def is_directory(self) -> bool:
        return bool(self.Attr & FAT32EntryAttr.DIRECTORY)

    @property
    def is_file(self) -> bool:
        return bool(self.Attr & FAT32EntryAttr.ARCHIVE)

    @property
    def short_name(self) -> str:
        """
        Return 8.3 formatted name.
        """
        name = self.Name.decode("cp437", errors="replace").rstrip()
        ext = self.Ext.decode("cp437", errors="replace").rstrip()
        return f"{name}.{ext}" if ext else name

    @property
    def first_cluster(self) -> int:
        """
        Return full 32-bit first cluster number.
        """
        return (self.ClusterHigh << 16) | self.ClusterLow


# Long File Name Entry (LFN)
class FAT32LFNEntry(LittleEndianStructure):
    _pack_ = 1
    _fields_ = [
        ("Order", c_uint8),
        ("Name1", c_uint16 * 5),
        ("Attr", c_uint8),
        ("Type", c_uint8),
        ("Checksum", c_uint8),
        ("Name2", c_uint16 * 6),
        ("Zero", c_uint16),
        ("Name3", c_uint16 * 2),
    ]


def cluster_to_offset(cluster: int, bs: FAT32BootSector) -> int:
    """
    Convert a cluster number to the absolute file offset
    """

    first_data_sector = bs.ReservedSectorCount + (bs.NumFATs * bs.FATSize32)
    sector = first_data_sector + (cluster - 2) * bs.SectorsPerCluster
    return sector * bs.BytesPerSector


def read_cluster(
    file: BufferedReader,
    cluster: int,
    bs: FAT32BootSector,
    partition_offset: int,
) -> bytes:
    """
    This function returns the cluster bytes content.
    """

    file.seek(partition_offset + cluster_to_offset(cluster, bs))
    return file.read(bs.BytesPerSector * bs.SectorsPerCluster)


def read_fat(
    file: BufferedReader, bs: FAT32BootSector, partition_offset: int
) -> bytes:
    """
    This function read the FAT.
    """

    fat_offset = partition_offset + bs.ReservedSectorCount * bs.BytesPerSector
    file.seek(fat_offset)
    return file.read(bs.FATSize32 * bs.BytesPerSector)


def read_fat_entry(
    file,
    bs: FAT32BootSector,
    fat_offset_bytes: int,
    cluster: int,
    partition_offset: int,
) -> int:
    """
    Read a FAT32 entry for a given cluster.
    """

    fat_entry_offset = partition_offset + fat_offset_bytes + (cluster * 4)
    file.seek(fat_entry_offset)
    value = int.from_bytes(file.read(4), "little")
    return value & 0x0FFFFFFF


def get_cluster_chain(
    file: BufferedReader,
    bs: FAT32BootSector,
    start_cluster: int,
    partition_offset: int,
) -> List[int]:
    """
    Follow FAT chain and return list of clusters.
    """

    fat_offset_bytes = bs.ReservedSectorCount * bs.BytesPerSector
    clusters = []
    current = start_cluster

    while 0x2 <= current < 0x0FFFFFF8:
        clusters.append(current)
        current = read_fat_entry(
            file, bs, fat_offset_bytes, current, partition_offset
        )

    return clusters


def read_file_content(
    file: BufferedReader,
    bs: FAT32BootSector,
    entry: FAT32DirEntry,
    partition_offset: int,
    extract_data: bool = True,
) -> Union[bytearray, List[Tuple[int, int]]]:
    """
    Two actions:
        1. Extract raw file content from disk.
        2. Extract data offsets and sizes.
    """

    cluster_chain = get_cluster_chain(
        file, bs, entry.first_cluster, partition_offset
    )
    cluster_size = bs.BytesPerSector * bs.SectorsPerCluster

    data = bytearray() if extract_data else list()
    size = entry.FileSize
    data_size = 0

    for cluster in cluster_chain:
        absolute_offset = cluster_to_offset(cluster, bs) + partition_offset

        if size > cluster_size:
            data_size = cluster_size
            size -= cluster_size
        else:
            data_size = size
            size = 0

        if extract_data:
            file.seek(absolute_offset)
            data.extend(file.read(data_size))
        else:
            data.append((absolute_offset, data_size))

    return data


def parse_directory(
    file: BufferedReader,
    start_cluster: int,
    bs: FAT32BootSector,
    fat: bytes,
    partition_offset: int,
) -> List[FAT32DirEntry]:
    """
    Parse directory starting at start_cluster, following FAT chains.
    """

    cluster = start_cluster
    entries = []

    while 0x00000002 <= cluster < 0x0FFFFFF8:
        data = read_cluster(file, cluster, bs, partition_offset)
        lfn_stack = deque()

        for i in range(0, len(data), 32):
            entry = FAT32DirEntry.from_buffer_copy(data[i : i + 32])

            if entry.is_empty:
                return entries
            # elif entry.is_deleted:
            #     continue
            elif entry.is_lfn:
                lfn = FAT32LFNEntry.from_buffer_copy(data[i : i + 32])
                lfn_stack.appendleft(decode_lfn_part(lfn))
                continue

            entry.longname = "".join(lfn_stack)
            lfn_stack.clear()
            entries.append(entry)

        fat_entry_offset = cluster * 4
        cluster = (
            int.from_bytes(
                fat[fat_entry_offset : fat_entry_offset + 4], "little"
            )
            & 0x0FFFFFFF
        )

    return entries


def decode_lfn_part(lfn: FAT32LFNEntry) -> str:
    """
    Decode one LFN entry part (UTF-16LE).
    """

    name_bytes = []

    for field in (lfn.Name1, lfn.Name2, lfn.Name3):
        for char in field:
            if char == 0x0000:
                break
            elif char != 0xFFFF:
                name_bytes.append(char)

    return bytes(b"".join(c.to_bytes(2, "little") for c in name_bytes)).decode(
        "utf-16le", errors="ignore"
    )


def fat32_enumeration(
    bootsector: FAT32BootSector, file: BufferedReader, partition_offset: int
) -> Iterable[FAT32DirEntry]:
    """
    This generator yields all FAT32 Directory entries.
    """

    fat = read_fat(file, bootsector, partition_offset)
    yield from list_directory(
        file, bootsector.RootCluster, bootsector, fat, partition_offset
    )
    # root_entries = parse_directory(file, bootsector.RootCluster, bootsector, fat)
    # for entry in root_entries: print_directory_entry(entry, bootsector, file)


def list_directory(
    file: BufferedReader,
    cluster: int,
    bootsector: FAT32BootSector,
    fat: bytes,
    partition_offset: int,
    path="",
) -> Iterable[FAT32DirEntry]:
    """
    This recursive generator yields parsed entries
    from recursives directories.
    """

    entries = parse_directory(file, cluster, bootsector, fat, partition_offset)
    for entry in entries:
        entry.path = path
        if entry.is_file:
            yield entry
        elif (
            entry.is_directory
            and bytes(entry.Name).strip() != b".."
            and bytes(entry.Name).strip() != b"."
        ):
            yield entry
            yield from list_directory(
                file,
                entry.first_cluster,
                bootsector,
                fat,
                partition_offset,
                path=f"{path}/{entry.longname}",
            )


def parse_fat32_bootsector(data: bytes) -> FAT32BootSector:
    """
    This function returns FAT32FSInfo structure from bytes.
    """

    return FAT32BootSector.from_buffer_copy(data)


def parse_fat32_fsinfo(data: bytes) -> FAT32FSInfo:
    """
    This function returns FAT32FSInfo structure from bytes.
    """

    return FAT32FSInfo.from_buffer_copy(data)


def get_partition(filename: str) -> Union[Partition, BufferedReader]:
    """
    This function gets FAT partition using DiskAnalyzer module functions.
    """

    disk, file = disk_parsing(keep_open=True, file_path=filename)
    partition = disk.to_partition()

    if partition is None:
        try:
            partition = next(disk.fat_partitions())
        except StopIteration:
            return None, None, file

    return disk, partition, file


def fat32_parse(
    partition: Partition, file: BufferedReader
) -> Tuple[BufferedReader, FAT32BootSector, int, FAT32FSInfo]:
    """
    Parse the disk, find the FAT32 partition,
    read the Boot Sector and FSInfo.
    """

    fat32_offset = partition.start_sector * SECTOR_SIZE if partition else 0
    file.seek(fat32_offset)

    bootsector = parse_fat32_bootsector(file.read(SECTOR_SIZE))

    fsinfo_sector = bootsector.FSInfoSector
    file.seek(fat32_offset + fsinfo_sector * SECTOR_SIZE)
    fsinfo = parse_fat32_fsinfo(file.read(SECTOR_SIZE))

    return file, bootsector, fat32_offset, fsinfo


def get_total_sectors(bs: FAT32BootSector) -> int:
    """
    Return the total number of sectors in a FAT32 partition.
    """

    return bs.TotalSectors16 if bs.TotalSectors16 != 0 else bs.TotalSectors32


def print_fat32_bootsector(bs: FAT32BootSector, fsinfo: FAT32FSInfo) -> None:
    """
    This function prints informations about FAT32 partition.
    """

    print("\n[+] FAT32 Boot Sector Detected")
    print(f"  Jump Boot: {bytes(bs.JumpBoot).hex()}")
    print(f"  OEM Name: {bs.OEMName.decode(errors='ignore').strip()}")
    print(f"  Bytes Per Sector: {bs.BytesPerSector}")
    print(f"  Sectors Per Cluster: {bs.SectorsPerCluster}")
    print(f"  Reserved Sector Count: {bs.ReservedSectorCount}")
    print(f"  Number of FATs: {bs.NumFATs}")
    print(f"  Root Entry Count: {bs.RootEntryCount}")
    print(f"  Total Sectors 16: {bs.TotalSectors16}")
    print(f"  Media: {bs.Media}")
    print(f"  FAT Size 16: {bs.FATSize16}")
    print(f"  Sector per track: {bs.SectorsPerTrack}")
    print(f"  Number of heads: {bs.NumHeads}")
    print(f"  Hidden Sectors: {bs.HiddenSectors}")
    print(f"  Total Sectors 32: {bs.TotalSectors32}")
    print(f"  FAT Size 32: {bs.FATSize32}")
    print(f"  Extended Flags: {bs.ExtFlags}")
    print(f"  File System version: {bs.FSVersion}")
    print(f"  Root Cluster: {bs.RootCluster}")
    print(f"  FSInfo Sector: {bs.FSInfoSector}")
    print(f"  Backup Boot Sector: {bs.BackupBootSector}")
    print(f"  Reserved: {bytes(bs.Reserved).hex()}")
    print(f"  Drive Number: {hex(bs.DriveNumber)}")
    print(f"  Reserved: {bs.Reserved1}")
    print(f"  Boot Signature: {hex(bs.BootSignature)}")
    print(f"  Volume ID: {hex(bs.VolumeID)}")
    print(f"  Volume Label: {bs.VolumeLabel.decode(errors='ignore').strip()}")
    print(
        f"  File System Type: {bs.FileSystemType.decode(errors='ignore').strip()}"
    )

    line_length = 40
    bootloader = memoryview(bytes(bs.BootCode))
    print("  Boot code:")
    for index in range(0, len(bootloader), line_length):
        print("   ", bootloader[index : index + line_length].hex())

    print("BootSectorSignature:", bs.BootSectorSignature.to_bytes(2).hex())

    print("\n[+] FSInfo Sector")
    print(f"  Lead Signature: {hex(fsinfo.LeadSignature)}")

    reserved = memoryview(bytes(fsinfo.Reserved1))
    print("  Reserved:")
    for index in range(0, len(reserved), line_length):
        print("   ", reserved[index : index + line_length].hex())

    print(f"  Struct Signature: {hex(fsinfo.StructSignature)}")
    print(f"  Free Count: {fsinfo.FreeCount}")
    print(f"  Next Free Cluster: {fsinfo.NextFree}")
    print(f"  Reserved: {bytes(fsinfo.Reserved2).hex()}")
    print(f"  Trail Signature: {hex(fsinfo.TrailSignature)}")
    print("[>] Partition size in sector:", get_total_sectors(bs))


def parse_fat_time(time: int) -> str:
    """
    Convert FAT time (c_uint16) to HH:MM:SS string.
    """

    hour = (time >> 11) & 0x1F
    minute = (time >> 5) & 0x3F
    second = (time & 0x1F) * 2
    return f"{hour:02}:{minute:02}:{second:02}"


def parse_fat_date(date: int) -> str:
    """
    Convert FAT date (c_uint16) to YYYY-MM-DD string.
    """

    year = ((date >> 9) & 0x7F) + 1980
    month = (date >> 5) & 0x0F
    day = date & 0x1F
    try:
        return datetime(year, month, day).strftime("%Y-%m-%d")
    except ValueError:
        return "Invalid date"


def print_directory_entry(
    entry: FAT32DirEntry,
    bootsector: FAT32BootSector,
    file: BufferedReader,
    partition_offset: int,
) -> None:
    """
    Prints information about a FAT32 directory entry with readable fields.
    """

    attrs = get_attributes(entry.Attr)
    deleted, name = get_short_name(entry.Name, entry.Ext)

    print("\n[+] Directory Entry Found")
    print("  Path:", entry.path)
    print(f"  Long name: {entry.longname}")

    if deleted:
        print("  Deleted file")
        start = "  Partial name:"
    else:
        start = "  Name:"

    print(start, name)
    print(f"  Attributes: {', '.join(attrs) if attrs else 'None'}")
    print(f"  NT Reserved: {entry.NTReserved}")
    print(f"  Creation Time: {parse_fat_time(entry.CreationTime)}.{entry.CreationTimeTenth:03}")
    print(f"  Creation Date: {parse_fat_date(entry.CreationDate)}")
    print(f"  Last Access Date: {parse_fat_date(entry.LastAccessDate)}")
    print(f"  Write Time: {parse_fat_time(entry.WriteTime)}")
    print(f"  Write Date: {parse_fat_date(entry.WriteDate)}")
    print(f"  First Cluster: {entry.first_cluster}")
    print(f"  File Size: {entry.FileSize} bytes")

    content = read_file_content(file, bootsector, entry, partition_offset)
    line_length = 40
    content2 = memoryview(content)
    print("  File content:")
    for index in range(0, len(content2), line_length):
        print("   ", content2[index : index + line_length].hex())


def get_attributes(attributes: int) -> List[str]:
    """
    This function returns the list of FAT32 attributes names
    from attributes value.
    """

    return [attr.name for attr in FAT32EntryAttr if attributes & attr]


def get_short_name(name: bytes, extension: bytes) -> Tuple[bool, str]:
    """
    This function returns is_deleted and string name
    from FAT32 short name and extension.
    """

    if name[0] == FAT32EntryState.DELETED.value:
        deleted = True
        name = name[1:].decode("cp437").rstrip()
    else:
        deleted = False
        name = name.decode("cp437").rstrip()

    ext = extension.decode("cp437").rstrip()
    return deleted, f"{name}.{ext}" if ext else name


def save_directory_entry_to_csv(
    entry: FAT32DirEntry,
    bootsector: FAT32BootSector,
    fat32_file: BufferedReader,
    csv_file: DictWriter,
    partition_offset: int,
) -> None:
    """
    Save FAT32 directory entry information into a CSV file.
    """

    attrs = get_attributes(entry.Attr)
    deleted, name = get_short_name(entry.Name, entry.Ext)

    data_positions = []
    for offset, size in read_file_content(
        fat32_file, bootsector, entry, partition_offset, False
    ):
        data_positions.append(str(offset) + ":" + str(size))

    row = {
        "Path": entry.path,
        "LongName": entry.longname,
        "Deleted": str(deleted),
        "Name": name,
        "Attributes": "|".join(attrs) if attrs else "",
        "NTReserved": entry.NTReserved,
        "CreationTime": f"{parse_fat_time(entry.CreationTime)}.{entry.CreationTimeTenth:03}",
        "CreationDate": parse_fat_date(entry.CreationDate),
        "LastAccessDate": parse_fat_date(entry.LastAccessDate),
        "WriteTime": parse_fat_time(entry.WriteTime),
        "WriteDate": parse_fat_date(entry.WriteDate),
        "FirstCluster": entry.first_cluster,
        "FileSize": entry.FileSize,
        "DataPositions": "|".join(data_positions),
    }

    csv_file.writerow(row)


def main() -> int:
    """
    The main function to starts the script from the command line.
    """

    print(copyright)

    verbose = False
    if "-v" in argv:
        argv.remove("-v")
        verbose = True

    if len(argv) == 2:
        filename = argv[1]
    else:
        print("USAGES:", executable, argv[0], "[-v] [filepath]", file=stderr)
        return 1

    disk, partition, file = get_partition(filename)

    if isinstance(disk, GPTHeader):
        print_gpt_analysis(disk)
    elif isinstance(disk, MBRHeader):
        print_mbr_analysis(disk)

    file, bs, offset, fsinfo = fat32_parse(partition, file)

    if bs.BootSectorSignature != 0xAA55:
        print(
            "Invalid Boot Sector Signature:",
            hex(bs.BootSectorSignature),
            "(0xAA55)",
            file=stderr,
        )
        return 2

    print_fat32_bootsector(bs, fsinfo)

    with open("FAT32.csv", mode="w", newline="", encoding="utf-8") as csvfile:
        writer = DictWriter(
            csvfile,
            fieldnames=(
                "Path",
                "FileSize",
                "WriteTime",
                "Deleted",
                "WriteDate",
                "Attributes",
                "FirstCluster",
                "Name",
                "LongName",
                "LastAccessDate",
                "DataPositions",
                "CreationTime",
                "NTReserved",
                "CreationDate",
            ),
            quoting=QUOTE_ALL,
        )
        for entry in fat32_enumeration(bs, file, offset):
            if verbose:
                print_directory_entry(entry, bs, file, offset)
            save_directory_entry_to_csv(entry, bs, file, writer, offset)

    return 0


if __name__ == "__main__":
    exit(main())
