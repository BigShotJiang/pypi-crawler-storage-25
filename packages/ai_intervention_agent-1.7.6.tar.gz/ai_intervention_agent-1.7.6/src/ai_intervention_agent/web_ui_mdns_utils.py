"""mDNS / DNS-SD 辅助工具 — 从 web_ui.py 提取。

包含主机名规范化、虚拟网卡过滤、IPv4 地址探测等纯函数，
由 WebFeedbackUI 的 mDNS 功能调用。

R23.2: ``psutil`` 改成 lazy 导入。
why：``import psutil`` 在 ``web_ui`` cold-start trace 上是 ~3 ms 的纯静态成本
（``psutil._psosx`` ~1.5 ms + ``psutil._common`` ~1 ms + 子模块 ~0.5 ms），
但 psutil 在本模块**唯一的使用点**是 ``_list_non_loopback_ipv4`` —— 只有
在 mDNS 启用（``bind_interface != 127.0.0.1``）且需要枚举本机网卡时才会触发，
而 mDNS 注册又在 ``WebFeedbackUI.run()`` 启动的 daemon thread 异步执行（R20.11
确立的契约）。所以 main thread 的 cold-start 路径上 100% 不需要 psutil。
本地回环开发场景（``host=127.0.0.1``）甚至**永远**用不到。
延迟到 ``_list_non_loopback_ipv4`` 内部首次调用时才 import：
- ``sys.modules`` 已缓存，第二次调用零成本（mDNS 一般只查一次网卡）
- 第一次 import 在 daemon thread 中发生（mDNS 路径），不阻塞 main thread
  的 ``app.run()`` socket listen
- 失败仍走原有 ``except Exception`` 兜底（返回空列表 → mDNS 降级为不发布）
"""

from __future__ import annotations

import socket
from ipaddress import AddressValueError, ip_address
from typing import Any

from ai_intervention_agent.enhanced_logging import EnhancedLogger

logger = EnhancedLogger(__name__)

# ============================================================================
# 常量
# ============================================================================

MDNS_DEFAULT_HOSTNAME = "ai.local"
MDNS_SERVICE_TYPE_HTTP = "_http._tcp.local."


# ============================================================================
# 主机名
# ============================================================================


def normalize_mdns_hostname(value: Any) -> str:
    """规范化 mDNS 主机名。

    - 非字符串 / 空 → 默认 ai.local
    - 末尾 '.' 移除（zeroconf 内部会追加 FQDN 点号）
    - 不含 '.' 的短名 → 追加 '.local'
    """
    if not isinstance(value, str):
        return MDNS_DEFAULT_HOSTNAME

    hostname = value.strip()
    if not hostname:
        return MDNS_DEFAULT_HOSTNAME

    if hostname.endswith("."):
        hostname = hostname[:-1]

    if "." not in hostname:
        hostname = f"{hostname}.local"

    return hostname


# ============================================================================
# 网卡 / IPv4 探测
# ============================================================================


def _is_probably_virtual_interface(ifname: str) -> bool:
    """启发式过滤虚拟网卡（避免优先选到 docker0 / veth 等）"""
    name = (ifname or "").lower()
    if name == "lo":
        return True

    if name.startswith(
        (
            "docker",
            "br-",
            "veth",
            "virbr",
            "vmnet",
            "cni",
            "flannel",
            "lxcbr",
            "podman",
        )
    ):
        return True

    return bool(
        any(
            token in name
            for token in ("tun", "tap", "wg", "tailscale", "zerotier", "vpn", "ppp")
        )
    )


def _get_default_route_ipv4() -> str | None:
    """通过路由选择的方式获取"默认出口"IPv4（不实际发包）"""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            ip = str(s.getsockname()[0])
        ip_obj = ip_address(ip)
        if ip_obj.is_loopback or ip_obj.is_link_local or ip_obj.is_unspecified:
            return None
        if ip_obj.version != 4:
            return None
        return ip
    except OSError:
        return None


def _list_non_loopback_ipv4(prefer_physical: bool = True) -> list[str]:
    """枚举本机非回环 IPv4 地址（优先物理网卡）。

    R23.2: ``psutil`` 改成函数内 lazy import（详见模块顶部注释）。``sys.modules``
    会自动缓存，第二次及以后调用零额外 import 成本；第一次 import 失败（极罕见，
    psutil 是 hard dep）走 ``except Exception`` 路径，返回空列表让 mDNS 降级。
    """
    try:
        import psutil

        addrs = psutil.net_if_addrs()
        stats = psutil.net_if_stats()
    except Exception:
        return []

    result: list[str] = []

    for ifname, snics in addrs.items():
        if prefer_physical and _is_probably_virtual_interface(ifname):
            continue

        stat = stats.get(ifname)
        if stat is not None and not stat.isup:
            continue

        for snic in snics:
            if snic.family != socket.AF_INET:
                continue

            ip = snic.address
            try:
                ip_obj = ip_address(ip)
            except (AddressValueError, ValueError):
                continue

            if ip_obj.version != 4:
                continue
            if ip_obj.is_loopback or ip_obj.is_link_local or ip_obj.is_unspecified:
                continue

            result.append(ip)

    seen: set[str] = set()
    uniq: list[str] = []
    for ip in result:
        if ip in seen:
            continue
        seen.add(ip)
        uniq.append(ip)

    uniq.sort(key=lambda x: 0 if ip_address(x).is_private else 1)
    return uniq


def detect_best_publish_ipv4(bind_interface: str) -> str | None:
    """自动探测适合对外发布的 IPv4 地址。

    优先级：
    1) bind_interface 为具体 IPv4（非 0.0.0.0/回环）→ 直接使用
    2) 默认路由推断
    3) 物理网卡枚举
    4) 所有非回环地址兜底
    """
    try:
        bind_ip = ip_address(bind_interface)
        if (
            bind_ip.version == 4
            and not bind_ip.is_loopback
            and not bind_ip.is_unspecified
            and not bind_ip.is_link_local
        ):
            return bind_interface
    except (AddressValueError, ValueError):
        pass

    candidates = _list_non_loopback_ipv4(prefer_physical=True)
    route_ip = _get_default_route_ipv4()
    if route_ip and route_ip in candidates:
        return route_ip
    if candidates:
        return candidates[0]

    if route_ip:
        return route_ip

    candidates = _list_non_loopback_ipv4(prefer_physical=False)
    if candidates:
        return candidates[0]

    return None
