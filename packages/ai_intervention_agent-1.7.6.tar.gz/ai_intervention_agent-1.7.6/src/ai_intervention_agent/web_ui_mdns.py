"""mDNS 生命周期 Mixin — 从 WebFeedbackUI 提取。

封装 mDNS/DNS-SD 服务的发现、注册、注销逻辑，
由 WebFeedbackUI 通过 MRO 继承。

异步注册（R20.11）
~~~~~~~~~~~~~~~~~~
``_start_mdns_if_needed`` 内部的 ``zeroconf.register_service`` 因 RFC 6762 §8
要求的 conflict-probe announcement 而**同步阻塞 ~1.7 s**（多次 250 ms multicast
probe + 最终 announcement）。在 ``WebFeedbackUI.run()`` 中直接同步调用会让
Flask ``app.run()`` 进入 listen 状态延迟 ~1.7 s——浏览器/插件第一次访问 Web UI
会被推迟相同时间。

R20.11 把对 ``_start_mdns_if_needed`` 的调用搬到后台 daemon 线程：``run()`` 启动
线程后立刻进入 ``app.run()``，``app.run`` 在 ~30 ms 内开始 listen，浏览器可立即
访问；mDNS announcement 在后台并行完成，对 ``http://127.0.0.1:port`` /
``http://<lan-ip>:port`` 路径完全透明（这两条访问路径不依赖 mDNS 名字解析），仅
LAN 上其他设备用 ``ai.local`` 路径访问时才会等 announcement 完成（典型在 1-2 秒
内自然达成）。

``_stop_mdns`` 在 ``run()`` finally 块中 ``join`` 线程，防止 daemon 线程在主进程
结束时 race 写入 ``_mdns_zeroconf``。``_start_mdns_if_needed`` 自身保持同步语义
不变——既兼容现有 26+ 个直接调用该方法的单元测试，也允许 daemon thread 中按
原契约执行。
"""

from __future__ import annotations

import inspect
import socket
import threading
from typing import TYPE_CHECKING, Any

from ai_intervention_agent.config_manager import get_config
from ai_intervention_agent.enhanced_logging import EnhancedLogger
from ai_intervention_agent.web_ui_mdns_utils import (
    MDNS_DEFAULT_HOSTNAME,
    MDNS_SERVICE_TYPE_HTTP,
    detect_best_publish_ipv4,
    normalize_mdns_hostname,
)

if TYPE_CHECKING:
    from flask import Flask

logger = EnhancedLogger(__name__)


class MdnsMixin:
    """mDNS/Zeroconf 服务发布与注销。"""

    if TYPE_CHECKING:
        app: Flask
        host: str
        port: int
        _mdns_zeroconf: Any
        _mdns_service_info: Any
        _mdns_hostname: str | None
        _mdns_publish_ip: str | None
        _mdns_thread: threading.Thread | None

    def _get_mdns_config(self) -> dict[str, Any]:
        """读取 mdns 配置段（失败则返回空字典）"""
        try:
            cfg = get_config().get_section("mdns")
            return cfg if isinstance(cfg, dict) else {}
        except Exception as e:
            logger.warning(
                f"无法加载 mdns 配置，已降级为不发布 mDNS: {e}", exc_info=True
            )
            return {}

    def _should_enable_mdns(self, mdns_config: dict[str, Any]) -> bool:
        """判断当前是否应启用 mDNS（默认策略：bind_interface 不是 127.0.0.1）"""
        enabled_raw = mdns_config.get("enabled")
        if isinstance(enabled_raw, bool):
            return enabled_raw
        return self.host not in {"127.0.0.1", "localhost", "::1"}

    def _start_mdns_if_needed(self) -> None:
        """启动 mDNS 发布（失败则降级，不影响 Web UI 启动）"""
        if self._mdns_zeroconf is not None:
            return

        mdns_config = self._get_mdns_config()
        if not self._should_enable_mdns(mdns_config):
            return

        if self.host in {"127.0.0.1", "localhost", "::1"}:
            logger.warning(
                "mDNS 已配置启用，但 bind_interface 为本地回环地址，外部设备无法访问，已跳过发布"
            )
            return

        try:
            from zeroconf import NonUniqueNameException, ServiceInfo, Zeroconf
        except Exception as e:
            logger.error(f"mDNS 功能不可用：无法导入 zeroconf 依赖: {e}", exc_info=True)
            print("mDNS 功能不可用：缺少依赖 zeroconf（请更新依赖/重新安装）。")
            return

        hostname = normalize_mdns_hostname(
            mdns_config.get("hostname", MDNS_DEFAULT_HOSTNAME)
        )
        service_name_raw = mdns_config.get("service_name", "AI Intervention Agent")
        service_name = (
            service_name_raw.strip()
            if isinstance(service_name_raw, str) and service_name_raw.strip()
            else "AI Intervention Agent"
        )

        publish_ip = detect_best_publish_ipv4(self.host)
        if not publish_ip:
            logger.error("mDNS 发布失败：无法探测可发布的内网 IPv4 地址")
            print(
                "mDNS 发布失败：无法探测可发布的内网 IP（已降级为仅通过 IP/localhost 访问）。"
            )
            return

        server_fqdn = f"{hostname}."
        service_fqdn = f"{service_name}.{MDNS_SERVICE_TYPE_HTTP}"
        properties = {
            "path": "/",
            "hostname": hostname,
            "publish_ip": publish_ip,
        }

        try:
            info = ServiceInfo(
                MDNS_SERVICE_TYPE_HTTP,
                service_fqdn,
                addresses=[socket.inet_aton(publish_ip)],
                port=self.port,
                properties=properties,
                server=server_fqdn,
            )
        except (OSError, ValueError) as e:
            # 历史教训：``socket.inet_aton`` 在 publish_ip 不是合法 IPv4 字面量时
            # 抛 ``OSError``（``illegal IP address string passed``）；这条分支会
            # 让 ``run()`` 内的 ``_start_mdns_if_needed()`` 抛出，进而让整个 Web
            # UI 起不来 —— 违反 docstring 承诺「失败则降级，不影响 Web UI 启动」。
            # 包成软失败 + 日志告警 + 返回。
            logger.warning(
                f"mDNS ServiceInfo 构造失败（publish_ip={publish_ip!r}），"
                f"已降级，不影响 Web UI 启动: {e}",
                exc_info=True,
            )
            return

        # 历史教训：``Zeroconf()`` 在以下真实环境会抛 ``OSError``：
        #   - Linux + Avahi 共存且未开 ``disallow-other-stacks=no``: errno 98
        #     (EADDRINUSE)
        #   - Windows 上有 169.254.x.x link-local 接口: WinError 10049
        #   - IPv6 loopback 无 multicast 能力: errno 101 (Network unreachable)
        # 不包 try 会让 ``WebFeedbackUI.run()`` 直接挂掉，整个 Web UI
        # 起不来 —— 这违反 docstring 承诺的「mDNS 失败 → 降级」原则。
        try:
            zc = Zeroconf()
        except OSError as e:
            logger.warning(
                f"Zeroconf 构造失败（端口冲突 / 接口不可用 / IPv6 loopback 无 "
                f"multicast 等），已降级为仅 IP/localhost 访问: {e}",
                exc_info=True,
            )
            print(
                f"mDNS 不可用：Zeroconf 端点初始化失败（{e}）。"
                "已降级为仅通过 IP/localhost 访问。"
            )
            return

        try:
            kwargs: dict[str, Any] = {}
            try:
                params = inspect.signature(zc.register_service).parameters
                if "allow_name_change" in params:
                    kwargs["allow_name_change"] = True
                elif "allow_rename" in params:
                    kwargs["allow_rename"] = True
            except Exception:
                kwargs = {}

            zc.register_service(info, **kwargs)
        except NonUniqueNameException:
            config_path = None
            try:
                config_path = str(get_config().config_file)
            except Exception:
                config_path = None

            logger.error(
                f"mDNS 发布失败：主机名冲突（{hostname}）。请修改配置中的 mdns.hostname 后重试"
            )
            print(f"mDNS 发布失败：主机名 {hostname} 可能已被局域网中其他设备占用。")
            print(
                "请修改配置中的 mdns.hostname（例如 ai-你的机器名.local），然后重启服务。"
            )
            if config_path:
                print(f"   配置文件: {config_path}")
            try:
                zc.close()
            except Exception as zc_err:
                # **R119**：``zeroconf.Zeroconf.close()`` 失败会泄漏 UDP socket
                # + mDNS responder 后台线程。这条 cleanup 紧跟在 hostname 冲突
                # 错误路径上——pre-R119 完全静默，进程 exit 后还有 zeroconf
                # 守护线程在跑、UDP 套接字未释放但用户完全看不到。R119 加
                # debug 痕迹，开 debug 后就能区分 "mDNS 失败 + cleanup OK"
                # vs "mDNS 失败 + cleanup 也失败导致资源泄漏"。
                logger.debug(
                    "[R119] hostname 冲突路径下 zc.close() 失败 "
                    f"(zeroconf UDP socket 可能泄漏): "
                    f"{type(zc_err).__name__}: {zc_err}"
                )
            return
        except Exception as e:
            logger.warning(
                f"mDNS 发布失败（已降级，不影响 Web UI）：{e}", exc_info=True
            )
            print(f"mDNS 发布失败：{e}（已降级为仅通过 IP/localhost 访问）。")
            try:
                zc.close()
            except Exception as zc_err:
                # **R119**：与上面 hostname 冲突路径同 spirit。这条 cleanup
                # 紧跟在通用 mDNS 发布失败路径上，主异常已通过 logger.warning
                # 记录；这里 debug 级补一条 cleanup 失败信号即可。
                logger.debug(
                    "[R119] mDNS 发布失败路径下 zc.close() 失败 "
                    f"(zeroconf UDP socket 可能泄漏): "
                    f"{type(zc_err).__name__}: {zc_err}"
                )
            return

        self._mdns_zeroconf = zc
        self._mdns_service_info = info
        self._mdns_hostname = hostname
        self._mdns_publish_ip = publish_ip

        logger.info(f"mDNS 已发布: http://{hostname}:{self.port} (IP: {publish_ip})")
        print(f"mDNS 已发布: http://{hostname}:{self.port} (IP: {publish_ip})")

    def _stop_mdns(self) -> None:
        """停止 mDNS 发布（尽力而为）

        R20.11：mDNS register 在后台 daemon thread 异步执行，本方法在 ``run()``
        finally 块中调用；如果 register thread 仍在跑（典型场景：Web UI 子进程
        在 mDNS conflict-probe 完成前被 SIGTERM 终止），先 ``join`` 等待线程
        完成，避免：

        * **泄漏**：thread 后续 set ``_mdns_zeroconf = zc`` 但本方法已经返回，
          导致 zc 实例在 daemon thread 死亡时连带 close 失败而留下 multicast
          socket 半关闭。
        * **TOCTOU**：``if self._mdns_zeroconf is None: return`` 早退后，thread
          竞争写 ``_mdns_zeroconf``——下一次 ``run()`` 看到旧实例仍在但已不可用。

        ``join(timeout=2.0)`` 平衡 *进程退出延迟* 与 *register 完成正确性*：
        2.0s 通常足够 zeroconf 完成 announcement（实测 ~1.7s），同时不会让
        Web UI shutdown 看起来 hang。超时后线程仍是 daemon，会随主进程结束。
        """
        thread = getattr(self, "_mdns_thread", None)
        if thread is not None and thread.is_alive():
            try:
                thread.join(timeout=2.0)
            except Exception as e:
                logger.debug(f"等待 mDNS 注册线程完成失败（忽略）：{e}")
        # 显式置 None，让 run() 多次调用之间隔离
        self._mdns_thread = None

        if self._mdns_zeroconf is None:
            return

        try:
            if self._mdns_service_info is not None:
                self._mdns_zeroconf.unregister_service(self._mdns_service_info)
        except Exception as e:
            logger.debug(f"注销 mDNS 服务失败（忽略）：{e}")

        try:
            self._mdns_zeroconf.close()
        except Exception as e:
            logger.debug(f"关闭 mDNS Zeroconf 失败（忽略）：{e}")

        self._mdns_zeroconf = None
        self._mdns_service_info = None
        self._mdns_hostname = None
        self._mdns_publish_ip = None
