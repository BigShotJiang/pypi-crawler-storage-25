"""MCP 服务器配置与工具函数 — 配置数据类、常量、输入验证、响应解析。

从 server.py 提取的无状态模块：
- WebUIConfig / FeedbackConfig 数据类及其 getter
- 超时计算、输入验证、图片处理、MCP 响应构建
- 所有函数不依赖 server.py 的全局状态（缓存、进程管理等）

R20.9 性能优化（lazy mcp.types）：
================================
``mcp.types`` 单独 import 约 ~184 ms（被 task_queue → server_config 间接拖入
即可观察到）。MCP 响应构建（``parse_structured_response`` / ``_process_image``
/ ``_make_resubmit_response``）只在 MCP server 主进程调用，Web UI 子进程
压根用不到 ``ImageContent`` / ``TextContent`` / ``ContentBlock``。

通过 ``from __future__ import annotations``（PEP 563）+ ``TYPE_CHECKING``
gate + 一次性缓存的 ``_lazy_mcp_types()`` 访问器，把 ``mcp.types`` 推迟到
**首次实际调用**响应构建函数时才加载。Web UI 子进程从此完全不会触发
``mcp.types`` 加载，task_queue 间接 import 时间从 ~218 ms 降至 ~30 ms。
"""

from __future__ import annotations

import base64
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any, ClassVar, Literal, overload

from pydantic import BaseModel, field_validator

from ai_intervention_agent.config_manager import get_config
from ai_intervention_agent.config_utils import (
    clamp_value,
    get_compat_config,
    truncate_string,
)
from ai_intervention_agent.enhanced_logging import EnhancedLogger

if TYPE_CHECKING:
    # 仅供类型检查器解析签名/注解；运行时绝不触发 mcp.types 加载。
    # 与下方 ``_lazy_mcp_types()`` 配合实现「类型注解零成本 + 运行时
    # lazy load」双赢。``TextContent`` 在 ``__future__ annotations`` 下
    # 仅出现在字符串化的类型注解中，ruff 看不到使用——用 noqa 显式声明。
    from mcp.types import ContentBlock, ImageContent, TextContent  # noqa: F401

# R20.9：mcp.types 单例缓存。首次调用 `_lazy_mcp_types()` 时才真正 import
# `mcp.types` 模块（~184 ms），后续调用直接返回缓存。Web UI 子进程不会调用
# 任何使用本访问器的函数，因此该模块永远不会被加载。
_mcp_types_module: Any = None


def _lazy_mcp_types() -> Any:
    """懒加载并缓存 ``mcp.types`` 模块对象（线程安全：GIL + 幂等赋值）。

    返回的对象有 ``TextContent`` / ``ImageContent`` / ``ContentBlock`` 等
    类属性。调用方应直接通过本函数返回值访问，不要重新 ``import mcp.types``
    （那会让 lazy 化的努力前功尽弃）。
    """
    global _mcp_types_module
    if _mcp_types_module is None:
        from mcp import types as _mcp_types

        _mcp_types_module = _mcp_types
    return _mcp_types_module


logger = EnhancedLogger(__name__)

# ============================================================================
# 超时与边界常量
# ============================================================================

# NOTE: 这些 MIN/MAX 常量必须与 ``shared_types.SECTION_MODELS::feedback`` 中的
# Pydantic ``_clamp_int(min, max, default)`` 边界保持一致 —— 否则会出现「config.toml
# 写 frontend_countdown=1000，shared_types Pydantic 接受 1000，但 web_ui_validators /
# task_queue 用本文件的常量把它 clamp 回 250」这种 docs 撒谎、行为不一致的漂移。
# ``tests/test_server_config_shared_types_parity.py`` 锁住此契约。
FEEDBACK_TIMEOUT_DEFAULT = 600  # 默认后端最大等待时间（秒）
FEEDBACK_TIMEOUT_MIN = 10  # 后端最小等待时间（秒，与 shared_types 对齐）
FEEDBACK_TIMEOUT_MAX = 7200  # 后端最大等待时间上限（秒，2 小时；与 shared_types 对齐）

AUTO_RESUBMIT_TIMEOUT_DEFAULT = 240  # 默认前端倒计时（秒）
AUTO_RESUBMIT_TIMEOUT_MIN = 10  # 前端最小倒计时（秒，与 shared_types 对齐）
AUTO_RESUBMIT_TIMEOUT_MAX = 3600  # 前端最大倒计时（秒，1 小时；与 shared_types 对齐）

BACKEND_BUFFER = 40  # 后端缓冲时间（秒，前端+缓冲=后端最小）
BACKEND_MIN = 260  # 后端最低等待时间（秒，预留安全余量避免 MCPHub 300秒硬超时）

# R166: 大幅放宽文本长度限制（"手动输入 / 自动返回 / 额外附加"三块均收敛到
# 远超正常使用的软上限）。背景：之前 10000 字符的硬截断会让"LLM 输出长上
# 下文 / 用户粘贴长技术文档"的合法场景被默默截断 + "..."，反馈数据丢失却
# 零日志告警。R166 把软上限抬高 ~10-100×，让正常使用永远不被截断，同时
# 保留 task_queue.add_task 的 10MB 字节硬上限作为唯一的 DoS 防御：
#
#   软上限（本文件）─┐
#                   ├──→ "warn but never block" 语义，方便日志诊断异常 caller
#   硬上限（task_queue ─┘    10MB 字节）：拒绝级，唯一的"反 DoS"护栏
#
# 软上限阈值参考：
#   * 100MB-1MB ASCII / 3MB UTF-8 中文 → 远超合理 prompt + LLM 输出场景
#   * 仍远低于 10MB 字节硬上限（保留 ~3-10× 余量）
#   * 截断时仍保留原 "+ ..." 行为以保持向后兼容（测试断言依赖此前缀）
PROMPT_MAX_LENGTH = 100_000  # 提示语最大长度（resubmit_prompt / prompt_suffix）
RESUBMIT_PROMPT_DEFAULT = "请立即调用 interactive_feedback 工具"
PROMPT_SUFFIX_DEFAULT = "\n请积极调用 interactive_feedback 工具"

MAX_MESSAGE_LENGTH = (
    1_000_000  # 用户输入/提示文本最大长度（约 1MB UTF-8，远低于 10MB 硬上限）
)
MAX_OPTION_LENGTH = (
    10_000  # 单个预定义选项最大长度（防 UI 渲染异常用，正常 option 不会超过 200）
)


# ============================================================================
# 配置数据类
# ============================================================================


class WebUIConfig(BaseModel):
    """Web UI 服务配置：host, port, timeout, max_retries, retry_delay"""

    PORT_MIN: ClassVar[int] = 1
    PORT_MAX: ClassVar[int] = 65535
    PORT_PRIVILEGED: ClassVar[int] = 1024
    # 不变量：以下 6 个常量必须等于 ``shared_types.SECTION_MODELS::web_ui`` 中
    # 对应 Pydantic 字段的 ``BeforeValidator(_clamp_int/_clamp_float(...))`` 边界。
    # 否则 ``service_manager._load_web_ui_config_from_disk`` 会做"二次 clamp"，
    # 把已通过 Pydantic 校验的用户值悄悄截断（例如 ``http_request_timeout=500``
    # → Pydantic 接受 500 → 这里被强行降到 300）。详见
    # ``tests/test_server_config_shared_types_parity.py::TestWebUIConfigSharedTypesParity``。
    TIMEOUT_MIN: ClassVar[int] = 1
    TIMEOUT_MAX: ClassVar[int] = 600
    MAX_RETRIES_MIN: ClassVar[int] = 0
    MAX_RETRIES_MAX: ClassVar[int] = 20
    RETRY_DELAY_MIN: ClassVar[float] = 0.0
    RETRY_DELAY_MAX: ClassVar[float] = 60.0

    SUPPORTED_LANGS: ClassVar[tuple] = ("auto", "en", "zh-CN")

    host: str
    port: int
    language: str = "auto"
    timeout: int = 30
    max_retries: int = 3
    retry_delay: float = 1.0
    external_base_url: str = ""

    @field_validator("language")
    @classmethod
    def validate_language(cls, v: str) -> str:
        if v not in cls.SUPPORTED_LANGS:
            logger.warning(
                "不支持的语言 '%s'，回退到 'auto'。支持的值: %s",
                v,
                ", ".join(cls.SUPPORTED_LANGS),
            )
            return "auto"
        return v

    @field_validator("port")
    @classmethod
    def validate_port(cls, v: int) -> int:
        if not (cls.PORT_MIN <= v <= cls.PORT_MAX):
            raise ValueError(
                f"端口号必须在 {cls.PORT_MIN}-{cls.PORT_MAX} 范围内，当前值: {v}"
            )
        if v < cls.PORT_PRIVILEGED:
            logger.warning(
                f"端口 {v} 是特权端口（<{cls.PORT_PRIVILEGED}），"
                f"可能需要 root/管理员权限才能绑定"
            )
        return v

    @field_validator("timeout")
    @classmethod
    def clamp_timeout(cls, v: int) -> int:
        return clamp_value(v, cls.TIMEOUT_MIN, cls.TIMEOUT_MAX, "timeout")

    @field_validator("max_retries")
    @classmethod
    def clamp_max_retries(cls, v: int) -> int:
        return clamp_value(v, cls.MAX_RETRIES_MIN, cls.MAX_RETRIES_MAX, "max_retries")

    @field_validator("retry_delay")
    @classmethod
    def clamp_retry_delay(cls, v: float) -> float:
        return clamp_value(v, cls.RETRY_DELAY_MIN, cls.RETRY_DELAY_MAX, "retry_delay")


class FeedbackConfig(BaseModel):
    """反馈配置：timeout、auto_resubmit_timeout、提示语等"""

    timeout: int
    auto_resubmit_timeout: int
    resubmit_prompt: str
    prompt_suffix: str

    @field_validator("timeout")
    @classmethod
    def clamp_timeout(cls, v: int) -> int:
        return clamp_value(
            v, FEEDBACK_TIMEOUT_MIN, FEEDBACK_TIMEOUT_MAX, "feedback.timeout"
        )

    @field_validator("auto_resubmit_timeout")
    @classmethod
    def clamp_auto_resubmit(cls, v: int) -> int:
        if v == 0:
            return v
        return clamp_value(
            v,
            AUTO_RESUBMIT_TIMEOUT_MIN,
            AUTO_RESUBMIT_TIMEOUT_MAX,
            "feedback.auto_resubmit_timeout",
        )

    @field_validator("resubmit_prompt")
    @classmethod
    def truncate_resubmit(cls, v: str) -> str:
        return truncate_string(
            v,
            PROMPT_MAX_LENGTH,
            "feedback.resubmit_prompt",
            default=RESUBMIT_PROMPT_DEFAULT,
        )

    @field_validator("prompt_suffix")
    @classmethod
    def truncate_suffix(cls, v: str) -> str:
        return truncate_string(
            v,
            PROMPT_MAX_LENGTH,
            "feedback.prompt_suffix",
        )


# ============================================================================
# 配置读取函数
# ============================================================================


def get_feedback_config() -> FeedbackConfig:
    """从配置文件加载反馈配置"""
    try:
        config_mgr = get_config()
        feedback_config = config_mgr.get_section("feedback")

        timeout = int(
            get_compat_config(
                feedback_config, "backend_max_wait", "timeout", FEEDBACK_TIMEOUT_DEFAULT
            )
        )
        auto_resubmit_timeout = int(
            get_compat_config(
                feedback_config,
                "frontend_countdown",
                "auto_resubmit_timeout",
                AUTO_RESUBMIT_TIMEOUT_DEFAULT,
            )
        )
        resubmit_prompt = str(
            feedback_config.get("resubmit_prompt", RESUBMIT_PROMPT_DEFAULT)
        )
        prompt_suffix = str(feedback_config.get("prompt_suffix", PROMPT_SUFFIX_DEFAULT))

        return FeedbackConfig(
            timeout=timeout,
            auto_resubmit_timeout=auto_resubmit_timeout,
            resubmit_prompt=resubmit_prompt,
            prompt_suffix=prompt_suffix,
        )
    except (ValueError, TypeError) as e:
        logger.warning(f"获取反馈配置失败（类型错误），使用默认值: {e}", exc_info=True)
        return FeedbackConfig(
            timeout=FEEDBACK_TIMEOUT_DEFAULT,
            auto_resubmit_timeout=AUTO_RESUBMIT_TIMEOUT_DEFAULT,
            resubmit_prompt=RESUBMIT_PROMPT_DEFAULT,
            prompt_suffix=PROMPT_SUFFIX_DEFAULT,
        )
    except Exception as e:
        logger.warning(f"获取反馈配置失败，使用默认值: {e}", exc_info=True)
        return FeedbackConfig(
            timeout=FEEDBACK_TIMEOUT_DEFAULT,
            auto_resubmit_timeout=AUTO_RESUBMIT_TIMEOUT_DEFAULT,
            resubmit_prompt=RESUBMIT_PROMPT_DEFAULT,
            prompt_suffix=PROMPT_SUFFIX_DEFAULT,
        )


def calculate_backend_timeout(
    auto_resubmit_timeout: int, max_timeout: int = 0, infinite_wait: bool = False
) -> int:
    """计算后端等待超时：前端倒计时 + 缓冲，0 表示无限等待"""
    if infinite_wait:
        return 0

    if max_timeout <= 0:
        feedback_config = get_feedback_config()
        max_timeout = feedback_config.timeout

    if auto_resubmit_timeout <= 0:
        return max(max_timeout, BACKEND_MIN)

    calculated = max(auto_resubmit_timeout + BACKEND_BUFFER, BACKEND_MIN)
    return min(calculated, max_timeout)


def get_feedback_prompts() -> tuple[str, str]:
    """获取 (resubmit_prompt, prompt_suffix)"""
    config = get_feedback_config()
    return config.resubmit_prompt, config.prompt_suffix


def _append_prompt_suffix(text: str) -> str:
    """为用户反馈类文本追加 prompt_suffix（若已存在则不重复追加）"""
    _, prompt_suffix = get_feedback_prompts()
    if not prompt_suffix:
        return text
    return text if text.endswith(prompt_suffix) else (text + prompt_suffix)


@overload
def _make_resubmit_response(as_mcp: Literal[True] = ...) -> list: ...


@overload
def _make_resubmit_response(as_mcp: Literal[False]) -> dict: ...


def _make_resubmit_response(as_mcp: bool = True) -> list | dict:
    """创建错误/超时的重新提交响应"""
    resubmit_prompt, _ = get_feedback_prompts()
    if as_mcp:
        # R20.9: lazy load mcp.types，避免子进程 import 链路被污染
        return [_lazy_mcp_types().TextContent(type="text", text=resubmit_prompt)]
    return {"text": resubmit_prompt}


# ============================================================================
# 输入验证
# ============================================================================


def _normalize_option_default(value: Any) -> bool:
    """把任意输入归一化为 bool（接受 true/false/1/0/"true"/"false"/"yes"/"no"）。

    保持宽松：未知值视为未默认选中（False），避免因 LLM 偶发地传入字符串
    类型的 "true"/"false" 而把"默认勾选"功能直接打掉。
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes", "y", "on", "selected"}
    return False


def validate_input_with_defaults(
    prompt: str, predefined_options: list | None = None
) -> tuple[str, list[str], list[bool]]:
    """验证清理输入：截断过长内容，过滤非法选项，并解析每项的"默认选中"状态。

    `predefined_options` 兼容三种格式（向后兼容 + TODO #3 增强）：

    1. 纯字符串：``"选项 A"`` —— default 为 False
    2. 带默认选中的对象：``{"label": "选项 B", "default": True}`` ——
       支持的别名：``label`` / ``text`` / ``value``，``default`` /
       ``selected`` / ``checked``。
    3. 紧凑数组：``["选项 C", true]`` —— 第一项为 label，第二项为 default。

    Returns
    -------
    tuple[str, list[str], list[bool]]
        归一化后的 ``(prompt, options_labels, options_defaults)``，两个列表长度
        始终一致，长度为 0 表示用户未提供选项。

    See Also
    --------
    validate_input : 旧版本，仅返回 ``(prompt, options_labels)``，向后兼容；
        若仅关心 label 不需要 default 信息时使用即可。
    """
    try:
        cleaned_prompt = prompt.strip()
    except AttributeError:
        raise ValueError("prompt 必须是字符串类型") from None
    if len(cleaned_prompt) > MAX_MESSAGE_LENGTH:
        logger.warning(
            f"prompt 长度过长 ({len(cleaned_prompt)} 字符)，将被截断到 {MAX_MESSAGE_LENGTH}"
        )
        cleaned_prompt = cleaned_prompt[:MAX_MESSAGE_LENGTH] + "..."

    cleaned_options: list[str] = []
    cleaned_defaults: list[bool] = []
    if predefined_options:
        for option in predefined_options:
            label_raw: Any = None
            default_raw: Any = False

            if isinstance(option, str):
                label_raw = option
            elif isinstance(option, dict):
                # 兼容多种命名约定：label / text / value，selected / default / checked
                label_raw = (
                    option.get("label")
                    if option.get("label") is not None
                    else option.get("text")
                    if option.get("text") is not None
                    else option.get("value")
                )
                default_raw = (
                    option.get("default")
                    if option.get("default") is not None
                    else option.get("selected")
                    if option.get("selected") is not None
                    else option.get("checked")
                )
            elif isinstance(option, (list, tuple)) and len(option) >= 1:
                label_raw = option[0]
                if len(option) >= 2:
                    default_raw = option[1]
            else:
                logger.warning(f"跳过非法选项（既不是字符串也不是对象）: {option!r}")
                continue

            if not isinstance(label_raw, str):
                logger.warning(f"跳过非字符串选项 label: {label_raw!r}")
                continue

            cleaned_option = label_raw.strip()
            if not cleaned_option:
                continue

            if len(cleaned_option) > MAX_OPTION_LENGTH:
                logger.warning(f"选项过长被截断: {cleaned_option[:50]}...")
                cleaned_option = cleaned_option[:MAX_OPTION_LENGTH] + "..."

            cleaned_options.append(cleaned_option)
            cleaned_defaults.append(_normalize_option_default(default_raw))

    return cleaned_prompt, cleaned_options, cleaned_defaults


def validate_input(
    prompt: str, predefined_options: list | None = None
) -> tuple[str, list[str]]:
    """验证清理输入：截断过长内容，过滤非法选项（向后兼容签名）。

    返回 ``(prompt, options_labels)``。如需同时获取每项的"默认选中"状态，
    请使用 :func:`validate_input_with_defaults`。
    """
    cleaned_prompt, cleaned_options, _ = validate_input_with_defaults(
        prompt, predefined_options
    )
    return cleaned_prompt, cleaned_options


# ============================================================================
# 工具函数
# ============================================================================


def _generate_task_id() -> str:
    """生成全局唯一任务 ID（避免极端并发下碰撞）"""
    project_name = Path.cwd().name or "task"
    return f"{project_name}-{uuid.uuid4()}"


def get_target_host(host: str) -> str:
    """将不可直连的监听地址转换为客户端可访问地址（如 localhost）"""
    return "localhost" if host in {"0.0.0.0", "::"} else host


def is_loopback_url(url: str) -> bool:
    """判断 URL 的 host 是否解析到本机回环地址。

    覆盖三类常见写法：
        * 字面量 ``localhost`` / ``127.0.0.1`` / ``::1`` / ``[::1]``
        * 整个 ``127.0.0.0/8`` IPv4 段（``127.123.45.67`` 也算回环）
        * ``ipaddress.ip_address(host).is_loopback`` 真值的 IPv6 地址

    用于在 Bark / 跨设备通知场景过滤 ``http://localhost:8080`` 这类
    "对外推送但点了打不开" 的 base_url：手机 Bark 解析 loopback 会指向
    手机自己，必然打不开 Web UI。

    任何解析失败 / 空串 / 非 string 输入都返回 ``False``，让调用方按
    "未识别即放行" 处理，避免误伤合法的 LAN/公网 URL。
    """
    if not isinstance(url, str):
        return False

    candidate = url.strip()
    if not candidate:
        return False

    try:
        from urllib.parse import urlparse

        parsed = urlparse(candidate)
    except (TypeError, ValueError):
        return False

    host = parsed.hostname
    if not host:
        return False

    host_lower = host.strip().lower()
    if host_lower in {"localhost", "127.0.0.1", "::1"}:
        return True

    try:
        from ipaddress import ip_address

        return bool(ip_address(host_lower).is_loopback)
    except (TypeError, ValueError):
        return False


def resolve_external_base_url(
    web_ui_config: WebUIConfig | None = None,
    *,
    for_external_use: bool = False,
) -> str:
    """解析"对外可访问"的 Web UI 基地址，用于通知点击跳转等场景。

    优先级：
        1. ``[web_ui] external_base_url`` 配置（用户显式指定，如 ``http://ai.local:8080``）
        2. mDNS 地址（``[mdns] hostname``，默认 ``ai.local``），仅在 mDNS 显式启用
           或 ``auto`` 且监听地址不是 loopback 时使用
        3. ``http://{target_host}:{port}``（基于 ``[web_ui] host/port`` 推导）

    返回值会去掉末尾斜杠，便于直接和 ``/path`` 拼接；解析失败时返回空串。

    参数 ``for_external_use``（默认 ``False`` 保持向后兼容）：
        * ``False``：保留原契约——任何解析成功的 URL 都返回，包括 loopback。
        * ``True``：调用方明确声明 "我要给跨设备/外部场景用"，函数会在
          解析结果命中 :func:`is_loopback_url` 时返回 ``""``，迫使调用方
          走 "无外部可达地址" 的降级路径（例如 Bark 通知不附 ``url`` 字段、
          UI 显示提示让用户配 ``external_base_url`` 或 ``web_ui.host``）。
    """
    try:
        config_mgr = get_config()
        web_section = config_mgr.get_section("web_ui") or {}
        mdns_section = config_mgr.get_section("mdns") or {}
        network_section = config_mgr.get_section("network_security") or {}
    except Exception as exc:
        logger.debug(f"读取 [web_ui] 配置失败，无法解析外部基地址: {exc}")
        web_section = {}
        mdns_section = {}
        network_section = {}

    explicit = (
        str(getattr(web_ui_config, "external_base_url", "") or "").strip()
        if web_ui_config is not None
        else ""
    )
    explicit = explicit or str(web_section.get("external_base_url", "") or "").strip()
    resolved = ""
    if explicit:
        if explicit.startswith(("http://", "https://")):
            resolved = explicit.rstrip("/")
        else:
            logger.warning(
                f"web_ui.external_base_url 必须以 http:// 或 https:// 开头，已忽略: {explicit!r}"
            )

    if not resolved:
        if web_ui_config is None:
            try:
                host = str(
                    network_section.get(
                        "bind_interface",
                        web_section.get("host", "127.0.0.1"),
                    )
                )
                port = int(web_section.get("port", 8080))
            except (TypeError, ValueError):
                return ""
        else:
            host = web_ui_config.host
            port = int(web_ui_config.port)

        if not host:
            return ""

        host_normalized = host.strip().lower()
        loopback_hosts = {"127.0.0.1", "localhost", "::1", "[::1]"}
        mdns_enabled_raw = mdns_section.get("enabled", "auto")
        mdns_enabled = False
        if isinstance(mdns_enabled_raw, bool):
            mdns_enabled = mdns_enabled_raw
        else:
            mdns_enabled_text = str(mdns_enabled_raw).strip().lower()
            if mdns_enabled_text in {"true", "1", "yes", "on", "enabled"}:
                mdns_enabled = True
            elif mdns_enabled_text in {"false", "0", "no", "off", "disabled"}:
                mdns_enabled = False
            else:
                mdns_enabled = host_normalized not in loopback_hosts

        mdns_hostname = str(mdns_section.get("hostname", "ai.local") or "").strip()
        mdns_hostname = mdns_hostname.rstrip(".").strip("/")
        if mdns_enabled and mdns_hostname and "://" not in mdns_hostname:
            resolved = f"http://{mdns_hostname}:{port}"
        else:
            resolved = f"http://{get_target_host(host)}:{port}"

    if for_external_use and resolved and is_loopback_url(resolved):
        logger.debug(
            "resolve_external_base_url(for_external_use=True): "
            f"过滤 loopback 结果 {resolved!r}，调用方将走无外部 base_url 降级路径"
        )
        return ""

    return resolved


def suggest_lan_base_url(port: int) -> str | None:
    """探测一个适合对外推送的 LAN base_url（``http://<lan-ipv4>:<port>``）。

    用于 Bark / 跨设备通知场景：当 :func:`resolve_external_base_url` 在
    ``for_external_use=True`` 模式返回空串时，UI / 日志可以用本函数给出
    "你应该配成什么样" 的具体推荐。

    内部复用 :func:`web_ui_mdns_utils.detect_best_publish_ipv4`（lazy import，
    避免冷启动加载 ``psutil``）。它会跳过 ``docker0`` / VPN tunnel / 回环 /
    link-local 地址，优先返回路由探测到的默认出口 IPv4，再退化到物理网卡
    枚举。任何探测失败都返回 ``None``，调用方应优雅降级（例如 UI 隐藏
    "推荐 LAN IP" 行）。
    """
    try:
        port_int = int(port)
    except (TypeError, ValueError):
        return None
    if port_int < 1 or port_int > 65535:
        return None

    try:
        from ai_intervention_agent.web_ui_mdns_utils import detect_best_publish_ipv4
    except Exception as exc:
        logger.debug(f"加载 web_ui_mdns_utils 失败，无法推荐 LAN base_url: {exc}")
        return None

    try:
        try:
            config_mgr = get_config()
            network_section = config_mgr.get_section("network_security") or {}
            web_section = config_mgr.get_section("web_ui") or {}
            bind_interface = str(
                network_section.get(
                    "bind_interface",
                    web_section.get("host", "127.0.0.1"),
                )
            )
        except Exception as exc:
            logger.debug(f"读取 bind_interface 失败，使用默认 127.0.0.1: {exc}")
            bind_interface = "127.0.0.1"

        ip = detect_best_publish_ipv4(bind_interface)
    except Exception as exc:
        logger.debug(f"detect_best_publish_ipv4 调用失败: {exc}")
        return None

    if not ip:
        return None
    return f"http://{ip}:{port_int}"


# ============================================================================
# 图片处理与 MCP 响应构建
# ============================================================================


def _format_file_size(size: int) -> str:
    """格式化文件大小为人类可读格式"""
    if size < 1024:
        return f"{size} B"
    if size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    return f"{size / (1024 * 1024):.1f} MB"


def _guess_mime_type_from_data(base64_data: str) -> str | None:
    """通过文件魔数猜测 MIME 类型"""
    try:
        snippet = base64_data[:256]
        snippet += "=" * ((4 - len(snippet) % 4) % 4)
        raw = base64.b64decode(snippet, validate=False)

        mime_signatures = [
            (b"\x89PNG\r\n\x1a\n", "image/png"),
            (b"\xff\xd8\xff", "image/jpeg"),
            (b"GIF87a", "image/gif"),
            (b"GIF89a", "image/gif"),
            (b"BM", "image/bmp"),
            (b"II*\x00", "image/tiff"),
            (b"MM\x00*", "image/tiff"),
            (b"\x00\x00\x01\x00", "image/x-icon"),
        ]

        for signature, mime_type in mime_signatures:
            if raw.startswith(signature):
                return mime_type

        if raw.startswith(b"RIFF") and len(raw) >= 12 and raw[8:12] == b"WEBP":
            return "image/webp"

        # SVG 检测已移除：与 file_validator.py 安全策略对齐，SVG 可嵌入脚本

    except Exception:
        pass
    return None


def _process_image(image: dict, index: int) -> tuple[ImageContent | None, str | None]:
    """处理单张图片，返回 (ImageContent, 文本描述)"""
    base64_data = image.get("data")
    if not isinstance(base64_data, str) or not base64_data.strip():
        logger.warning(f"图片 {index + 1} 的 data 字段无效: {type(base64_data)}")
        return None, f"=== 图片 {index + 1} ===\n处理失败: 图片数据无效"

    base64_data = base64_data.strip()

    inferred_mime_type: str | None = None
    if base64_data.startswith("data:") and ";base64," in base64_data:
        header, b64 = base64_data.split(",", 1)
        base64_data = b64.strip()
        if header.startswith("data:"):
            inferred_mime_type = header[5:].split(";", 1)[0].strip() or None

    content_type = (
        image.get("content_type")
        or image.get("mimeType")
        or image.get("mime_type")
        or inferred_mime_type
        or "image/jpeg"
    )

    content_type = str(content_type).strip()
    if ";" in content_type:
        content_type = content_type.split(";", 1)[0].strip()
    content_type = content_type.lower()
    if content_type == "image/jpg":
        content_type = "image/jpeg"

    if not content_type.startswith("image/"):
        guessed = _guess_mime_type_from_data(base64_data)
        content_type = guessed or "image/jpeg"

    filename = image.get("filename", f"image_{index + 1}")
    size = image.get("size", len(base64_data) * 3 // 4)
    text_desc = f"=== 图片 {index + 1} ===\n文件名: {filename}\n类型: {content_type}\n大小: {_format_file_size(size)}"

    # R20.9: lazy load mcp.types
    return (
        _lazy_mcp_types().ImageContent(
            type="image", data=base64_data, mimeType=str(content_type)
        ),
        text_desc,
    )


def parse_structured_response(
    response_data: dict[str, Any] | None,
) -> list[ContentBlock]:
    """解析反馈数据为 MCP Content 列表"""
    result: list[ContentBlock] = []
    text_parts: list[str] = []

    if not isinstance(response_data, dict):
        response_data = {}

    logger.debug(f"parse_structured_response 接收数据: {type(response_data)}")

    legacy_text = response_data.get("interactive_feedback")
    user_input = response_data.get("user_input", "") or ""
    if not user_input and isinstance(legacy_text, str) and legacy_text.strip():
        user_input = legacy_text

    selected_options_raw = response_data.get("selected_options", [])
    selected_options = (
        [str(x) for x in selected_options_raw if x is not None]
        if isinstance(selected_options_raw, list)
        else []
    )

    logger.debug(
        f"解析结果: user_input={len(user_input)}字符, options={len(selected_options)}个"
    )

    if selected_options:
        text_parts.append(f"选择的选项: {', '.join(selected_options)}")
    if user_input:
        text_parts.append(f"用户输入: {user_input}")

    images = response_data.get("images", []) or []
    for index, image in enumerate(images):
        if not isinstance(image, dict):
            continue
        try:
            img_content, text_desc = _process_image(image, index)
            if img_content:
                result.append(img_content)
            if text_desc:
                text_parts.append(text_desc)
        except Exception as e:
            logger.error(f"处理图片 {index + 1} 时出错: {e}", exc_info=True)
            text_parts.append(f"=== 图片 {index + 1} ===\n处理失败: {e!s}")

    combined_text = "\n\n".join(text_parts) if text_parts else "用户未提供任何内容"

    combined_text = _append_prompt_suffix(combined_text)

    # R20.9: 单次调用内 hoist 一次 _lazy_mcp_types() 引用，避免 isinstance
    # 与 append 各自重复函数调用（同一个调用栈内 mcp.types 已经被 lazy 加载，
    # 但 attribute lookup 有微小开销）。
    _mt = _lazy_mcp_types()
    text_cls = _mt.TextContent
    image_cls = _mt.ImageContent

    result.append(text_cls(type="text", text=combined_text))

    logger.debug("最终返回结果:")
    for i, item in enumerate(result):
        if isinstance(item, text_cls):
            preview = item.text[:100] + ("..." if len(item.text) > 100 else "")
            logger.debug(f"  - [{i}] TextContent: '{preview}'")
        elif isinstance(item, image_cls):
            logger.debug(
                f"  - [{i}] ImageContent: mimeType={item.mimeType}, data_length={len(item.data)}"
            )
        else:
            logger.debug(f"  - [{i}] 未知类型: {type(item)}")

    return result
