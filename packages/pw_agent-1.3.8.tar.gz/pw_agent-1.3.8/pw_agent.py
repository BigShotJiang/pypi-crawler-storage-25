#!/usr/bin/env python3
"""PW Agent — CLI coding assistant powered by your Ollama GPUs via PastaWater."""

import argparse
import os
import sys
import requests

from rich.console import Console
from rich.panel import Panel
from prompt_toolkit import prompt as pt_prompt
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
from prompt_toolkit.completion import Completer, Completion, PathCompleter
from prompt_toolkit.key_binding import KeyBindings

from llm_client import LLMClient
from agent import Agent, get_model_warning
from config import (
    load_config, save_config, has_config, DEFAULT_CONFIG_DIR,
    get_active_instance, add_instance, remove_instance,
    instance_key_for_brain, instance_key_for_cloud,
)


VERSION = "1.3.8"
console = Console()

BANNER = """[bold cyan]
 ╔═══════════════════════════════════════════════╗
 ║  PW Agent v{version}                              ║
 ║  Coding assistant on your own GPUs           ║
 ╚═══════════════════════════════════════════════╝
[/bold cyan]"""

HELP_TEXT = """[dim]
Commands:
  /add FILE     Add a file to context (@file also works)
  /plan         Switch to Plan mode (read-only analysis)
  /build        Switch to Build mode (full read/write access)
  /clear        Clear conversation history
  /commit       Generate commit message and commit
  /diff         Show unstaged changes
  /models       Show all fleet GPUs and active models
  /instances    List saved connections
  /connect      Add a new cloud or local connection
  /use N        Switch active instance or GPU slot
  /disconnect N Remove a saved instance
  /refresh      Re-detect model (if changed on GPU Setup)
  /update       Update pw-agent to latest version
  /config       Show saved config
  /logout       Clear all saved config
  /quit         Exit (or Ctrl+D)

Flags: -y/--yes (auto-approve), -p "prompt" (one-shot), --instance N
[/dim]"""

# ─── First-run interactive setup ──────────────────────────────────────────────

def _pick_model(models: list[str]) -> str:
    """Let user pick from a list of models. Returns chosen model name."""
    if len(models) == 1:
        console.print(f"  [green]✓ Using: {models[0]}[/green]")
        return models[0]
    console.print("  [bold]Available models:[/bold]")
    for i, m in enumerate(models, 1):
        console.print(f"    [cyan]{i}[/cyan] — {m}")
    console.print()
    pick = pt_prompt(f"  Choose model [1-{len(models)}]: ").strip()
    try:
        return models[int(pick) - 1]
    except (ValueError, IndexError):
        return models[0]


def _add_local_brain(cfg: dict, existing_keys: set, brain: dict | None = None) -> tuple[dict, str, dict] | None:
    """Add a local brain connection. Auto-scans if no brain provided."""
    if not brain:
        console.print("\n  [dim]Scanning for local brain...[/dim]")
        brains = scan_local_brains()
        if not brains:
            console.print("  [red]No local brain found.[/red]")
            console.print("  [dim]Start PastaWater brain or Ollama first.[/dim]")
            return None
        brain = brains[0]

    key = instance_key_for_brain(brain["url"])
    if key in existing_keys:
        console.print(f"  [dim]Local brain on port {brain['port']} already added.[/dim]")
        return None

    console.print(f"  [green]✓ Found brain on port {brain['port']}[/green]")

    # Always require PW token — even for local Ollama
    console.print()
    console.print("  [dim]PastaWater account required.[/dim]")
    console.print("  [dim]Get your token from:[/dim] [underline cyan]https://pastawater.io/settings?tab=cli[/underline cyan]")
    console.print()
    pw_token = pt_prompt("  Paste your PW token: ").strip()
    if not pw_token:
        console.print("  [red]No token provided.[/red]")
        return None

    # Validate the token against PastaWater API
    try:
        resp = requests.get(
            "https://pastawater.io/api/user/byog/slots",
            headers={"Authorization": f"Bearer {pw_token}"},
            timeout=10,
        )
        if resp.status_code == 401:
            console.print("  [red]✗ Invalid token. Sign up at pastawater.io[/red]")
            return None
        if resp.status_code != 200:
            console.print(f"  [red]✗ Token validation failed ({resp.status_code})[/red]")
            return None
        console.print("  [green]✓ Token verified[/green]")
    except Exception as e:
        console.print(f"  [red]✗ Could not verify token: {e}[/red]")
        return None

    # Fetch models from brain (with auth if needed)
    if brain.get("needs_key"):
        try:
            resp = requests.get(
                f"{brain['url']}/api/tags",
                headers={"Authorization": f"Bearer {pw_token}"},
                timeout=10,
            )
            if resp.status_code == 200:
                brain["models"] = [m["name"] for m in resp.json().get("models", [])]
        except Exception:
            pass

    all_models = brain["models"]
    if not all_models:
        console.print("  [yellow]No models loaded. Start an LLM on GPU Setup first.[/yellow]")
        return None

    instance: dict = {"mode": "brain", "brain_url": brain["url"]}
    if pw_token:
        instance["token"] = pw_token
    instance["model"] = _pick_model(all_models)
    instance["name"] = f"Local ({instance['model']})"
    cfg = add_instance(cfg, key, instance)
    console.print(f"  [green]✓ Added: {instance['name']}[/green]")
    return cfg, key, instance


def _add_cloud(cfg: dict, existing_keys: set) -> tuple[dict, str, dict] | None:
    """Add a cloud connection via PastaWater token."""
    console.print()
    console.print("  [dim]Get your token from:[/dim] [underline cyan]https://pastawater.io/settings?tab=cli[/underline cyan]")
    console.print()
    token = pt_prompt("  Paste your PW token: ").strip()
    if not token:
        console.print("  [red]No token provided.[/red]")
        return None

    console.print(f"\n  [dim]Connecting to PastaWater...[/dim]")
    temp_client = LLMClient(token=token)
    devices = temp_client.list_devices()

    if not devices:
        console.print("  [yellow]⚠ No GPUs with LLM running found.[/yellow]")
        console.print("  [dim]Start an LLM model on https://pastawater.io/gpu-setup first.[/dim]")
        return None

    available = [d for d in devices if instance_key_for_cloud(d["slot"]) not in existing_keys]
    if not available:
        console.print("  [dim]All available GPUs are already added.[/dim]")
        return None

    console.print(f"  [green]✓ Found {len(available)} new GPU(s) with LLM:[/green]\n")
    for i, d in enumerate(available, 1):
        console.print(f"    [cyan]{i}[/cyan] — [bold]{d['device_name']}[/bold]  {d['gpu']} ({d['vram_gb']}GB)  [dim]{d['llm_model']}[/dim]")
    console.print()

    if len(available) == 1:
        chosen = available[0]
        console.print(f"  [green]✓ Auto-selected: {chosen['device_name']}[/green]")
    else:
        pick = pt_prompt(f"  Choose GPU [1-{len(available)}]: ").strip()
        try:
            chosen = available[int(pick) - 1]
        except (ValueError, IndexError):
            chosen = available[0]

    key = instance_key_for_cloud(chosen["slot"])
    instance = {
        "mode": "cloud",
        "name": f"{chosen['device_name']} ({chosen['gpu']})",
        "token": token,
        "slot": chosen["slot"],
        "device_id": chosen["device_id"],
        "device_name": chosen["device_name"],
        "model": chosen["llm_model"],
    }
    cfg = add_instance(cfg, key, instance)
    console.print(f"  [green]✓ Added: {instance['name']}[/green]")
    return cfg, key, instance


def add_connection(cfg: dict) -> tuple[dict, str, dict] | None:
    """Interactive flow to add a new connection. Always shows choice menu."""
    existing_keys = set(cfg.get("instances", {}).keys())

    # Scan for local brain in background to show status
    local_brains = scan_local_brains()
    local_available = local_brains and instance_key_for_brain(local_brains[0]["url"]) not in existing_keys

    console.print()
    console.print("  [bold]How do you want to connect?[/bold]")
    console.print(f"  [cyan]1[/cyan] — Local GPU [dim](direct to Ollama on this machine{', detected!' if local_available else ''})[/dim]")
    console.print("  [cyan]2[/cyan] — PastaWater Cloud [dim](remote GPUs via API token)[/dim]")
    console.print()
    mode = pt_prompt("  Choose [1/2]: ").strip()

    if mode == "1":
        return _add_local_brain(cfg, existing_keys, local_brains[0] if local_brains else None)
    else:
        return _add_cloud(cfg, existing_keys)


def run_setup() -> dict:
    """First-run setup. Returns config dict with at least one instance."""
    console.print()
    console.print(Panel(
        "[bold]Welcome to PW Agent![/bold]\n\n"
        "Let's connect you to your GPU fleet.\n"
        "This only takes a few seconds.",
        border_style="cyan",
        padding=(1, 2),
    ))

    cfg: dict = {"config_dir": DEFAULT_CONFIG_DIR, "instances": {}}
    result = add_connection(cfg)
    if result:
        cfg = result[0]
    path = save_config(cfg, DEFAULT_CONFIG_DIR)
    console.print(f"\n  [dim]Config saved to {path}[/dim]\n")
    return cfg


# ─── GPU listing ──────────────────────────────────────────────────────────────

def refresh_status(status_obj, client, cfg, args, agent):
    """Update the status object with current agent/client/config state."""
    inst = get_active_instance(cfg)
    model = client.model or inst.get("model", "unknown")
    name = inst.get("name", "unknown")
    mode_label = "local" if inst.get("mode") == "brain" else "cloud"
    
    # Store as a list of formatted text tuples for prompt_toolkit
    parts = [
        ("class:bottom-toolbar.status", f" {model} "),
        ("class:bottom-toolbar", " │ "),
        ("class:bottom-toolbar.active", f" {name} "),
        ("class:bottom-toolbar", " │ "),
        ("class:bottom-toolbar", f" {mode_label} "),
        ("class:bottom-toolbar", " │ "),
    ]
    
    if agent.plan_mode:
        parts.append(("class:bottom-toolbar.active", " PLAN "))
    else:
        parts.append(("class:bottom-toolbar.status", " BUILD "))
        
    if args.yes:
        parts.append(("class:bottom-toolbar", " │ "))
        parts.append(("class:bottom-toolbar.active", " AUTO-APPROVE "))
        
    status_obj["formatted"] = parts
    # For backward compat/logging
    status_obj["text"] = " │ ".join([p[1].strip() for p in parts if "│" not in p[1]])
    agent.status_text = status_obj["text"]


def print_models(client: LLMClient):
    """Print a table of all fleet GPUs and their LLM status."""
    from rich.table import Table

    devices = client.list_devices()
    if not devices:
        console.print("  [yellow]No GPUs with LLM running found.[/yellow]")
        return

    table = Table(
        title="Active Engines on Your Fleet",
        title_style="bold white",
        border_style="dim",
        show_lines=False,
        pad_edge=False,
        padding=(0, 2),
    )
    table.add_column("Slot", style="cyan", width=5)
    table.add_column("GPU", style="white")
    table.add_column("Model", style="bold")
    table.add_column("VRAM", style="dim", justify="right")
    table.add_column("Status", justify="right")

    for d in devices:
        is_active = d["device_id"] == client.device_id
        status = "[bold green]● Active[/bold green]" if is_active else "[dim]Idle[/dim]"
        model_display = d["llm_model"] or "—"
        table.add_row(
            str(d["slot"]),
            f"{d['device_name']}\n[dim]{d['gpu']}[/dim]",
            model_display,
            f"{d['vram_gb']}GB",
            status,
        )

    console.print()
    console.print(table)
    console.print("\n  [dim]Type /switch <slot> to change active engine.[/dim]\n")


def check_for_update() -> str | None:
    """Check PyPI for a newer version. Returns new version string or None."""
    try:
        resp = requests.get("https://pypi.org/pypi/pw-agent/json", timeout=5)
        if resp.status_code == 200:
            latest = resp.json()["info"]["version"]
            if latest != VERSION:
                return latest
    except Exception:
        pass
    return None


def do_update() -> bool:
    """Update pw-agent to latest. Detects install method and uses the right tool."""
    import subprocess
    import shutil
    console.print("  [dim]Updating pw-agent...[/dim]")

    # Detect if running from pipx venv
    is_pipx = "pipx" in (sys.prefix or "") or "pipx" in (sys.executable or "")

    if is_pipx or shutil.which("pipx"):
        result = subprocess.run(
            ["pipx", "upgrade", "pw-agent", "--force", "--pip-args=--no-cache-dir"],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode == 0:
            console.print(f"  [green]✓ Updated![/green] [dim]Restart pw-agent to use the new version.[/dim]")
            return True

    # Fallback to pip
    for cmd in [
        ["pip", "install", "--upgrade", "--no-cache-dir", "--break-system-packages", "pw-agent"],
        ["pip3", "install", "--upgrade", "--no-cache-dir", "--break-system-packages", "pw-agent"],
        ["pip", "install", "--upgrade", "--no-cache-dir", "pw-agent"],
    ]:
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            if result.returncode == 0:
                console.print(f"  [green]✓ Updated![/green] [dim]Restart pw-agent to use the new version.[/dim]")
                return True
        except FileNotFoundError:
            continue

    console.print(f"  [red]✗ Update failed. Try manually: pipx upgrade pw-agent[/red]")
    return False


def scan_local_brains() -> list[dict]:
    """Scan common ports for local Ollama/brain instances.
    Returns list of {"url": ..., "port": ..., "models": [...], "needs_key": bool}."""
    import requests
    found = []
    for port in [41789, 11434, 8080, 11435]:
        url = f"http://localhost:{port}"
        try:
            resp = requests.get(f"{url}/api/tags", timeout=2)
            if resp.status_code == 200:
                models = [m["name"] for m in resp.json().get("models", [])]
                found.append({"url": url, "port": port, "models": models, "needs_key": False})
            elif resp.status_code == 401:
                # Brain with auth — detected but needs API key to list models
                found.append({"url": url, "port": port, "models": [], "needs_key": True})
        except Exception:
            # Also check if it's a brain by hitting /health (no auth needed)
            try:
                resp = requests.get(f"{url}/health", timeout=2)
                if resp.status_code == 200 and "version" in resp.text:
                    found.append({"url": url, "port": port, "models": [], "needs_key": True})
            except Exception:
                pass
    return found


def detect_brain_url() -> str | None:
    """Check if there's a local brain running. Returns first found URL."""
    brains = scan_local_brains()
    return brains[0]["url"] if brains else None
    return None


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="PW Agent — CLI coding assistant powered by your Ollama GPUs",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--token", default=os.environ.get("PW_TOKEN"), help="PastaWater API token (or PW_TOKEN env)")
    parser.add_argument("--device", default=None, help="Device ID to use")
    parser.add_argument("--model", default=None, help="Ollama model name")
    parser.add_argument("--api-url", default=os.environ.get("PW_API_URL", "https://pastawater.io"), help="PastaWater API URL")
    parser.add_argument("--brain", default=os.environ.get("PW_BRAIN_URL", ""), help="Direct brain URL")
    parser.add_argument("--no-stream", action="store_true", help="Disable streaming output")
    parser.add_argument("--instance", type=int, default=None, metavar="N", help="Use instance N (from /instances list)")
    parser.add_argument("--setup", action="store_true", help="Re-run first-time setup")
    parser.add_argument("-p", "--print", dest="one_shot", metavar="PROMPT", help="Non-interactive: send prompt, print response, exit")
    parser.add_argument("-y", "--yes", action="store_true", help="Auto-approve all tool actions (no confirmation prompts)")
    parser.add_argument("--no-resume", action="store_true", help="Start fresh, don't resume previous session")
    parser.add_argument("--version", action="version", version=f"pw-agent {VERSION}")

    args = parser.parse_args()

    console.print(BANNER.format(version=VERSION))

    # ─── Check for updates (non-blocking) ─────────────────────────────
    if not args.one_shot:
        latest = check_for_update()
        if latest:
            console.print(f"  [yellow]Update available: v{VERSION} → v{latest}[/yellow]  [dim]Run /update to install[/dim]")

    # ─── Load or run setup ────────────────────────────────────────────
    cfg = load_config()

    if args.setup or (not cfg.get("instances") and not args.token and not args.brain):
        cfg = run_setup()

    # ─── Build client from active instance or CLI args ────────────────
    def build_client_from_instance(inst: dict) -> LLMClient | None:
        """Create an LLMClient from an instance config."""
        if inst.get("mode") == "brain":
            return LLMClient(brain_url=inst.get("brain_url", ""), token=inst.get("token", ""), model=inst.get("model", ""))
        elif inst.get("mode") == "cloud":
            return LLMClient(
                token=inst.get("token", ""),
                device_id=inst.get("device_id", ""),
                slot=inst.get("slot", 0),
                model=inst.get("model", ""),
                api_url=args.api_url,
            )
        return None

    # CLI args override config
    if args.brain:
        model = args.model or ""
        if not model:
            try:
                resp = requests.get(f"{args.brain}/api/tags", timeout=5)
                models = [m["name"] for m in resp.json().get("models", [])]
                if models:
                    model = models[0]
            except Exception:
                pass
        client = LLMClient(brain_url=args.brain, model=model)
        console.print(f"  [dim]Mode: Direct brain ({args.brain})[/dim]")
    elif args.token:
        client = LLMClient(token=args.token, model=args.model or "", api_url=args.api_url)
        console.print(f"  [dim]Mode: PastaWater cloud (CLI token)[/dim]")
    else:
        # --instance N flag to pick a specific instance
        if args.instance is not None:
            instances = cfg.get("instances", {})
            keys = list(instances.keys())
            try:
                key = keys[args.instance - 1]
                inst = instances[key]
            except (IndexError, KeyError):
                console.print(f"[red]Instance {args.instance} not found. Run /instances to see list.[/red]")
                sys.exit(1)
        else:
            inst = get_active_instance(cfg)

        if not inst:
            console.print("[red]No connection configured. Run: pw-agent --setup[/red]")
            sys.exit(1)
        client = build_client_from_instance(inst)
        if not client:
            console.print("[red]Invalid instance config. Run: pw-agent --setup[/red]")
            sys.exit(1)
        mode_label = inst.get("name", inst.get("mode", "unknown"))
        console.print(f"  [dim]Instance: {mode_label}[/dim]")

    # ─── Verify PW token is valid ────────────────────────────────────
    token_to_check = client.token or inst.get("token", "") if not args.brain else (args.token or "")
    if not token_to_check:
        console.print("[red]PastaWater account required. Run: pw-agent --setup[/red]")
        sys.exit(1)
    try:
        vresp = requests.get(
            "https://pastawater.io/api/user/byog/slots",
            headers={"Authorization": f"Bearer {token_to_check}"},
            timeout=10,
        )
        if vresp.status_code == 401:
            console.print("[red]Token expired or revoked. Run: pw-agent --setup[/red]")
            sys.exit(1)
    except Exception:
        pass  # Offline — allow if token exists, will fail on actual API call

    # ─── Test connection + re-detect model ──────────────────────────
    console.print("  [dim]Connecting...[/dim]")

    # For brain mode, re-detect what model is actually available
    if client.direct_mode:
        try:
            resp = requests.get(
                f"{client.brain_url}/api/tags",
                headers={"Authorization": f"Bearer {client.token}"} if client.token else {},
                timeout=5,
            )
            if resp.status_code == 200:
                available = [m["name"] for m in resp.json().get("models", [])]
                if available and client.model not in available:
                    old = client.model
                    client.model = available[0]
                    console.print(f"  [yellow]Model changed: {old} → {client.model}[/yellow]")
                    # Update saved config
                    inst = get_active_instance(cfg)
                    if inst:
                        inst["model"] = client.model
                        inst["name"] = f"Local ({client.model})"
                        save_config(cfg, cfg.get("config_dir", DEFAULT_CONFIG_DIR))
        except Exception:
            pass

    ok, msg = client.test_connection()
    if ok:
        console.print(f"  [green]✓ {msg}[/green]")
    else:
        console.print(f"  [red]✗ {msg}[/red]")
        console.print("  [dim]Run [bold]pw-agent --setup[/bold] to reconfigure.[/dim]")
        sys.exit(1)

    cwd = os.getcwd()
    console.print(f"  [dim]Working directory: {cwd}[/dim]")

    # ─── Model quality warning ────────────────────────────────────────
    warning = get_model_warning(client.model)
    if warning:
        console.print(f"  [yellow]{warning}[/yellow]")

    # ─── Auto-approve mode ────────────────────────────────────────────
    if args.yes:
        import tools as _tools
        _tools.AUTO_APPROVE = True
        console.print("  [bold red]⚠ Auto-approve mode — agent can modify files without asking[/bold red]")

    # ─── Status bar info ──────────────────────────────────────────────
    status = {"text": "", "formatted": []}
    # Create temp agent to refresh status
    temp_agent = Agent(client, plan_mode=False)
    refresh_status(status, client, cfg, args, temp_agent)

    # ─── One-shot mode (-p "prompt") ──────────────────────────────────
    if args.one_shot:
        agent = Agent(client, stream=not args.no_stream, status_text=status["text"])
        agent.run(args.one_shot)
        return

    # ─── Resume previous session ──────────────────────────────────────
    agent = Agent(client, stream=not args.no_stream, status_text=status["text"])
    if not args.no_resume:
        from config import load_session
        prev = load_session(cwd)
        if prev:
            agent.load_session(prev)

    console.print(HELP_TEXT)

    history_file = os.path.join(cfg.get("config_dir", DEFAULT_CONFIG_DIR), "history")
    os.makedirs(os.path.dirname(history_file), exist_ok=True)

    def _bottom_toolbar():
        toolbar = [("class:bottom-toolbar", " ")]
        toolbar.extend(status["formatted"])
        toolbar.append(("class:bottom-toolbar", "\n "))
        toolbar.append(("class:bottom-toolbar.key", " [Ctrl+C] Interrupt  │  /help  │  /quit "))
        return toolbar

    session = PromptSession(
        history=FileHistory(history_file),
        auto_suggest=AutoSuggestFromHistory(),
        completer=PwCompleter(),
        complete_while_typing=False,
        key_bindings=_key_bindings(),
        bottom_toolbar=_bottom_toolbar,
    )

    while True:
        try:
            user_input = session.prompt(
                [("class:prompt", "❯ ")],
                style=_prompt_style(),
            ).strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Bye![/dim]")
            break

        if not user_input:
            continue

        while user_input.endswith("\\"):
            try:
                cont = session.prompt([("class:continuation", "… ")], style=_prompt_style())
                user_input = user_input[:-1] + "\n" + cont
            except (KeyboardInterrupt, EOFError):
                break

        # @file shorthand → /add file
        if user_input.startswith("@") and not user_input.startswith("@@"):
            filepath = user_input[1:].strip()
            if filepath:
                agent.add_file(filepath)
            continue

        if user_input.startswith("/"):
            parts = user_input.split(maxsplit=1)
            cmd = parts[0].lower()
            cmd_arg = parts[1].strip() if len(parts) > 1 else ""

            if cmd in ("/plan", "/p"):
                agent.plan_mode = True
                refresh_status(status, client, cfg, args, agent)
                console.print("  [bold cyan]Mode switched to PLAN (read-only analysis)[/bold cyan]")
                continue

            if cmd in ("/build", "/b"):
                agent.plan_mode = False
                refresh_status(status, client, cfg, args, agent)
                console.print("  [bold green]Mode switched to BUILD (full read/write access)[/bold green]")
                continue

            if cmd in ("/quit", "/exit", "/q"):
                console.print("[dim]Bye![/dim]")
                break
            elif cmd == "/help":
                console.print(HELP_TEXT)
            elif cmd == "/clear":
                agent.reset()
            elif cmd == "/add":
                if cmd_arg:
                    agent.add_file(cmd_arg)
                else:
                    console.print("  [yellow]Usage: /add <filepath>[/yellow]")
            elif cmd == "/diff":
                import subprocess
                result = subprocess.run(["git", "diff"], capture_output=True, text=True, timeout=10)
                if result.stdout.strip():
                    console.print(f"\n{result.stdout[:3000]}")
                else:
                    console.print("  [dim]No unstaged changes.[/dim]")
            elif cmd == "/commit":
                # Ask the LLM to generate a commit message from the diff
                import subprocess
                diff = subprocess.run(["git", "diff", "--staged"], capture_output=True, text=True, timeout=10)
                if not diff.stdout.strip():
                    diff = subprocess.run(["git", "diff"], capture_output=True, text=True, timeout=10)
                if not diff.stdout.strip():
                    console.print("  [dim]No changes to commit.[/dim]")
                else:
                    agent.run(f"Generate a concise git commit message for this diff, then run `git add -A && git commit -m \"<message>\"`. Here's the diff:\n\n```\n{diff.stdout[:3000]}\n```")
            elif cmd in ("/models", "/gpus", "/slots", "/model"):
                print_models(client)
            elif cmd == "/use":
                if not cmd_arg:
                    console.print("  [yellow]Usage: /use <number>[/yellow]")
                    continue

                instances = cfg.get("instances", {})
                keys = list(instances.keys())
                
                # Check if it's an instance index or a slot switch (if in cloud mode)
                try:
                    target_idx = int(cmd_arg)
                except ValueError:
                    console.print("  [yellow]Please provide a number.[/yellow]")
                    continue

                # 1. Try switching to a saved instance first
                if 1 <= target_idx <= len(keys):
                    key = keys[target_idx - 1]
                    cfg["active"] = key
                    save_config(cfg, cfg.get("config_dir", DEFAULT_CONFIG_DIR))
                    inst = instances[key]
                    new_client = build_client_from_instance(inst)
                    if new_client:
                        client = new_client
                        agent.client = client
                        refresh_status(status, client, cfg, args, agent)
                        console.print(f"  [green]✓ Switched to connection: {inst.get('name', key)}[/green]")
                
                # 2. If it's a cloud instance, try switching slots within that connection
                elif not client.direct_mode:
                    new_slot = target_idx
                    devices = client.list_devices()
                    target = next((d for d in devices if d["slot"] == new_slot), None)
                    if not target:
                        console.print(f"  [red]Slot {new_slot} not found or has no LLM running.[/red]")
                    else:
                        client.slot = new_slot
                        client.device_id = target["device_id"]
                        client.model = target["llm_model"]
                        refresh_status(status, client, cfg, args, agent)
                        console.print(f"  [green]✓ Switched active slot to {new_slot}: {target['llm_model']} on {target['gpu']}[/green]")
                else:
                    console.print(f"  [red]Invalid selection: {target_idx}[/red]")
            elif cmd == "/disconnect":
                instances = cfg.get("instances", {})
                keys = list(instances.keys())
                if not cmd_arg:
                    console.print("  [yellow]Usage: /disconnect <number>[/yellow]")
                else:
                    try:
                        idx = int(cmd_arg) - 1
                        key = keys[idx]
                        name = instances[key].get("name", key)
                        cfg = remove_instance(cfg, key)
                        save_config(cfg, cfg.get("config_dir", DEFAULT_CONFIG_DIR))
                        console.print(f"  [dim]Removed: {name}[/dim]")
                        
                        # Re-sync if active changed
                        inst = get_active_instance(cfg)
                        if inst:
                            new_client = build_client_from_instance(inst)
                            if new_client:
                                client = new_client
                                agent.client = client
                                refresh_status(status, client, cfg, args, agent)
                                console.print(f"  [dim]Switched to: {inst.get('name', '')}[/dim]")
                    except (ValueError, IndexError):
                        console.print(f"  [red]Invalid instance number. Run /instances to see list.[/red]")
            elif cmd == "/refresh":
                if client.direct_mode:
                    try:
                        resp = requests.get(
                            f"{client.brain_url}/api/tags",
                            headers={"Authorization": f"Bearer {client.token}"} if client.token else {},
                            timeout=5,
                        )
                        if resp.status_code == 200:
                            available = [m["name"] for m in resp.json().get("models", [])]
                            if available:
                                old = client.model
                                client.model = available[0]
                                agent.client = client
                                inst = get_active_instance(cfg)
                                if inst:
                                    inst["model"] = client.model
                                    inst["name"] = f"Local ({client.model})"
                                    save_config(cfg, cfg.get("config_dir", DEFAULT_CONFIG_DIR))
                                if old != client.model:
                                    console.print(f"  [green]✓ Model changed: {old} → {client.model}[/green]")
                                else:
                                    console.print(f"  [dim]Model unchanged: {client.model}[/dim]")
                                
                                refresh_status(status, client, cfg, args, agent)
                            else:
                                console.print("  [yellow]No models found on brain.[/yellow]")
                    except Exception as e:
                        console.print(f"  [red]✗ {e}[/red]")
                else:
                    temp = LLMClient(token=client.token, api_url=client.api_url)
                    devices = temp.list_devices()
                    if devices:
                        for d in devices:
                            if d["slot"] == client.slot:
                                old = client.model
                                client.model = d["llm_model"]
                                agent.client = client
                                inst = get_active_instance(cfg)
                                if inst:
                                    inst["model"] = client.model
                                    save_config(cfg, cfg.get("config_dir", DEFAULT_CONFIG_DIR))
                                if old != client.model:
                                    console.print(f"  [green]✓ Model changed: {old} → {client.model}[/green]")
                                else:
                                    console.print(f"  [dim]Model unchanged: {client.model}[/dim]")
                                
                                refresh_status(status, client, cfg, args, agent)
                                break
                    else:
                        console.print("  [yellow]No GPUs with LLM found.[/yellow]")
            elif cmd == "/update":
                if do_update():
                    console.print("[dim]Bye![/dim]")
                    break
            elif cmd == "/config":
                active = get_active_instance(cfg)
                console.print(f"\n  [cyan]Active:[/cyan] {cfg.get('active', 'none')}")
                console.print(f"  [cyan]Mode:[/cyan] {active.get('mode', 'none')}")
                console.print(f"  [cyan]Model:[/cyan] {active.get('model', 'none')}")
                console.print(f"  [cyan]Instances:[/cyan] {len(cfg.get('instances', {}))}")
                console.print()
            elif cmd == "/logout":
                from config import _config_path
                path = _config_path(cfg.get("config_dir", ""))
                if os.path.exists(path):
                    os.remove(path)
                    console.print("  [dim]Config cleared. Run pw-agent --setup to reconfigure.[/dim]")
                else:
                    console.print("  [dim]No config found.[/dim]")
            else:
                console.print(f"  [yellow]Unknown command: {cmd}[/yellow]")
            continue

        agent.run(user_input)
        console.print()


class PwCompleter(Completer):
    """Tab-completes slash commands and file paths after /add or @."""

    COMMANDS = [
        ("/help", "Show help"),
        ("/add", "Add file to context"),
        ("/plan", "Switch to Plan mode (read-only)"),
        ("/build", "Switch to Build mode (read/write)"),
        ("/clear", "Clear conversation"),
        ("/commit", "Git commit with AI message"),
        ("/diff", "Show git diff"),
        ("/models", "Show fleet GPUs"),
        ("/instances", "List saved connections"),
        ("/connect", "Add new connection"),
        ("/use", "Switch connection or GPU slot"),
        ("/disconnect", "Remove a connection"),
        ("/refresh", "Re-detect model"),
        ("/update", "Update to latest version"),
        ("/config", "Show config"),
        ("/logout", "Clear saved config"),
        ("/quit", "Exit"),
    ]

    def __init__(self):
        self._path_completer = PathCompleter(expanduser=True)

    def get_completions(self, document, complete_event):
        text = document.text_before_cursor

        # Slash command completion
        if text.startswith("/"):
            for cmd, desc in self.COMMANDS:
                if cmd.startswith(text):
                    yield Completion(cmd, start_position=-len(text), display_meta=desc)

            # File path after /add
            if text.startswith("/add "):
                sub_doc = document.__class__(text[5:], cursor_position=len(text) - 5)
                for c in self._path_completer.get_completions(sub_doc, complete_event):
                    yield c

            # Slot number or instance index after /use
            if text.startswith("/use "):
                for n in range(1, 10):
                    s = str(n)
                    partial = text[5:]
                    if s.startswith(partial):
                        yield Completion(s, start_position=-len(partial), display_meta=f"Select {n}")
            return

        # @file path completion
        if text.startswith("@"):
            sub_doc = document.__class__(text[1:], cursor_position=len(text) - 1)
            for c in self._path_completer.get_completions(sub_doc, complete_event):
                yield c


def _key_bindings():
    """Custom key bindings — Tab accepts auto-suggestion."""
    kb = KeyBindings()

    @kb.add("tab")
    def _(event):
        buf = event.app.current_buffer
        suggestion = buf.suggestion
        if suggestion:
            buf.insert_text(suggestion.text)
        elif buf.complete_state:
            buf.complete_next()
        else:
            buf.start_completion()

    return kb


def _prompt_style():
    from prompt_toolkit.styles import Style
    return Style.from_dict({
        "prompt": "ansibrightcyan bold",
        "continuation": "ansigray",
        "bottom-toolbar": "bg:#18181b #a1a1aa",
        "bottom-toolbar.status": "bg:#18181b #ffffff bold",
        "bottom-toolbar.key": "bg:#18181b #71717a",
        "bottom-toolbar.active": "bg:#18181b #38bdf8 bold",
    })


if __name__ == "__main__":
    main()
