# Changelog

## [0.1.9](https://github.com/cjoelrun/mushu/compare/mushu-cli-v0.1.8...mushu-cli-v0.1.9) (2026-04-14)


### Features

* **cli:** add conversation commands to mushu agents ([422fb91](https://github.com/cjoelrun/mushu/commit/422fb917226123ad3235bac2e1ba49d6ed51fee2))
* mushu-agents conversation layer, SDK + CLI updates, service composition ([c6414d8](https://github.com/cjoelrun/mushu/commit/c6414d8f57d53998d62d50ade3450295c846da59))


### Bug Fixes

* **ci:** remove broken MCP tool generation step from SDK regen workflow ([4b59e2f](https://github.com/cjoelrun/mushu/commit/4b59e2f508771b74ad50974e0777e046dab199fe))

## [0.1.8](https://github.com/cjoelrun/mushu/compare/mushu-cli-v0.1.7...mushu-cli-v0.1.8) (2026-04-13)


### Features

* **agents:** ChatGPT Plus OAuth connect flow (iOS BYOS) ([9e0c36b](https://github.com/cjoelrun/mushu/commit/9e0c36b21f85cb3bca7f4429914e349d61861b71))

## [0.1.7](https://github.com/cjoelrun/mushu/compare/mushu-cli-v0.1.6...mushu-cli-v0.1.7) (2026-04-12)


### Features

* **agents:** scaffold mushu-agents service end-to-end ([3dccf13](https://github.com/cjoelrun/mushu/commit/3dccf13e68405875f69f534420c375891023fb1e))

## [0.1.6](https://github.com/cjoelrun/mushu/compare/mushu-cli-v0.1.5...mushu-cli-v0.1.6) (2026-04-11)


### Bug Fixes

* **cli:** auto-init health config on redirect-uri add ([dcafbd4](https://github.com/cjoelrun/mushu/commit/dcafbd4f40b853309f862b7efe4ffa182b771e68))

## [0.1.5](https://github.com/cjoelrun/mushu/compare/mushu-cli-v0.1.4...mushu-cli-v0.1.5) (2026-04-10)


### Features

* **cli:** add --access-token/--refresh-token flags to login-manual ([cec8bde](https://github.com/cjoelrun/mushu/commit/cec8bde2cb2e53c9c21f7619d18b97419c1f7c13))
* **health:** add redirect URI management to CLI and MCP ([e744f3c](https://github.com/cjoelrun/mushu/commit/e744f3c3847c138fd381eecffb9c59fdc8adc582))
* **health:** add SDK clients and CLI commands for health service ([c911f09](https://github.com/cjoelrun/mushu/commit/c911f0970f22a95a50ae35123ef540359ee62fe2))

## [0.1.4](https://github.com/cjoelrun/mushu/compare/mushu-cli-v0.1.3...mushu-cli-v0.1.4) (2026-01-26)


### Bug Fixes

* **cli:** bump to 0.1.4 with URL fix ([2f63e03](https://github.com/cjoelrun/mushu/commit/2f63e035dcea364a58e26fd5f02de1ad08c9bea2))

## [0.1.3](https://github.com/cjoelrun/mushu/compare/mushu-cli-v0.1.2...mushu-cli-v0.1.3) (2026-01-26)


### Bug Fixes

* **cli:** remove /v1 suffix from API URLs ([19bd03b](https://github.com/cjoelrun/mushu/commit/19bd03b4c06201a9a9567a21e0f5233c292dae33))

## [0.1.2](https://github.com/cjoelrun/mushu/compare/mushu-cli-v0.1.1...mushu-cli-v0.1.2) (2026-01-26)


### Bug Fixes

* **cli:** use core_url for org commands instead of auth_url ([b7ce7d5](https://github.com/cjoelrun/mushu/commit/b7ce7d52ae5c5b4ba343ae5fc9f307eb286f041c))

## [0.1.1](https://github.com/cjoelrun/mushu/compare/mushu-cli-v0.1.0...mushu-cli-v0.1.1) (2026-01-25)


### Features

* **cli:** add app and api-key commands ([fa651ff](https://github.com/cjoelrun/mushu/commit/fa651ffa924a5d5d25f9e79453ba327a341368eb))


### Bug Fixes

* **cli:** align version with release-please manifest ([ddd628c](https://github.com/cjoelrun/mushu/commit/ddd628cf00cd803270fd4524a67e54b8dbed35b5))
