"""Agents commands — manage AI agent runs and BYOK configuration."""

import typer
import httpx
from rich.console import Console
from rich.table import Table

from mushu.config import get_config

app = typer.Typer(help="AI agent runs and BYOK configuration")
console = Console()


def _get_headers(api_key: str | None = None) -> dict:
    if api_key:
        return {"X-API-Key": api_key}
    from mushu.config import get_auth_token
    token = get_auth_token()
    if not token:
        console.print("[red]Not authenticated. Run 'mushu auth login' or use --api-key.[/red]")
        raise typer.Exit(1)
    return {"Authorization": f"Bearer {token}"}


@app.command("run")
def create_run(
    user_id: str = typer.Option(..., "--user", "-u", help="User ID"),
    media_url: str = typer.Option(..., "--media", "-m", help="mushu-media R2 URL"),
    workflow: str = typer.Option("food-log", "--workflow", "-w", help="Workflow name"),
    api_key: str = typer.Option(None, "--api-key", "-k", help="Tenant API key"),
    poll: bool = typer.Option(True, "--poll/--no-poll", help="Poll for result (max 45s)"),
):
    """Submit an agent run and optionally wait for the result."""
    import time
    config = get_config()
    agents_url = getattr(config, "agents_url", "https://agents.mushucorp.com")
    headers = _get_headers(api_key)

    with httpx.Client() as client:
        response = client.post(
            f"{agents_url}/runs",
            headers=headers,
            json={"user_id": user_id, "workflow": workflow, "media_url": media_url},
        )

    if response.status_code != 200:
        console.print(f"[red]✗ Failed: {response.status_code} — {response.text}[/red]")
        raise typer.Exit(1)

    job_id = response.json()["job_id"]
    console.print(f"[green]✓ Run submitted:[/green] {job_id}")

    if not poll:
        return

    console.print("Polling for result (max 45s)...")
    for attempt in range(15):
        time.sleep(3)
        with httpx.Client() as client:
            r = client.get(f"{agents_url}/runs/{job_id}", headers=headers)
        if r.status_code != 200:
            console.print(f"[red]Poll error: {r.status_code}[/red]")
            raise typer.Exit(1)

        data = r.json()
        status = data["status"]
        if status == "complete":
            console.print(f"[green]✓ Complete[/green]")
            if data.get("result"):
                import json
                console.print(json.dumps(data["result"], indent=2))
            return
        elif status == "failed":
            console.print(f"[red]✗ Failed: {data.get('error', 'unknown error')}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"  [{attempt + 1}/15] status={status}...")

    console.print("[yellow]Timed out after 45s. Run may still be in progress.[/yellow]")
    console.print(f"Check: mushu agents status --job-id {job_id}")


@app.command("status")
def get_run_status(
    job_id: str = typer.Option(..., "--job-id", "-j", help="Job ID"),
    api_key: str = typer.Option(None, "--api-key", "-k", help="Tenant API key"),
):
    """Check the status of an agent run."""
    config = get_config()
    agents_url = getattr(config, "agents_url", "https://agents.mushucorp.com")
    headers = _get_headers(api_key)

    with httpx.Client() as client:
        response = client.get(f"{agents_url}/runs/{job_id}", headers=headers)

    if response.status_code == 404:
        console.print(f"[red]Run not found: {job_id}[/red]")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error: {response.status_code} — {response.text}[/red]")
        raise typer.Exit(1)

    data = response.json()
    status = data["status"]
    color = {"complete": "green", "failed": "red", "running": "yellow", "pending": "blue"}.get(
        status, "white"
    )
    console.print(f"[{color}]Status: {status}[/{color}]")
    if data.get("result"):
        import json
        console.print(json.dumps(data["result"], indent=2))
    if data.get("error"):
        console.print(f"[red]Error: {data['error']}[/red]")


@app.command("conversation-create")
def conversation_create(
    user_id: str = typer.Option(..., "--user", "-u", help="User ID"),
    workflow: str = typer.Option("meal-plan", "--workflow", "-w", help="Workflow name (e.g. meal-plan)"),
    api_key: str = typer.Option(None, "--api-key", "-k", help="Tenant API key"),
):
    """Create a new multi-turn conversation. Prints the conv_id."""
    config = get_config()
    agents_url = getattr(config, "agents_url", "https://agents.mushucorp.com")
    headers = _get_headers(api_key)

    with httpx.Client() as client:
        response = client.post(
            f"{agents_url}/conversations",
            headers=headers,
            json={"user_id": user_id, "workflow": workflow},
        )

    if response.status_code != 200:
        console.print(f"[red]✗ Failed: {response.status_code} — {response.text}[/red]")
        raise typer.Exit(1)

    conv_id = response.json()["conv_id"]
    console.print(f"[green]✓ Conversation created:[/green] {conv_id}")


@app.command("conversation-send")
def conversation_send(
    conv_id: str = typer.Option(..., "--conv-id", "-c", help="Conversation ID"),
    message: str = typer.Option(..., "--message", "-m", help="Message content"),
    api_key: str = typer.Option(None, "--api-key", "-k", help="Tenant API key"),
    poll: bool = typer.Option(True, "--poll/--no-poll", help="Poll for reply (max 60s)"),
):
    """Send a message to a conversation and optionally wait for the assistant reply."""
    import time
    config = get_config()
    agents_url = getattr(config, "agents_url", "https://agents.mushucorp.com")
    headers = _get_headers(api_key)

    with httpx.Client() as client:
        response = client.post(
            f"{agents_url}/conversations/{conv_id}/messages",
            headers=headers,
            json={"content": message},
        )

    if response.status_code == 409:
        detail = response.json().get("detail", {})
        active_id = detail.get("active_pending_id", "unknown")
        console.print(f"[yellow]⚠ Conversation busy — another turn is in flight.[/yellow]")
        console.print(f"  Poll for active turn: mushu agents conversation-poll --conv-id {conv_id} --pending-id {active_id}")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]✗ Failed: {response.status_code} — {response.text}[/red]")
        raise typer.Exit(1)

    pending_id = response.json()["pending_id"]
    console.print(f"[green]✓ Message sent:[/green] pending_id={pending_id}")

    if not poll:
        console.print(f"  Poll: mushu agents conversation-poll --conv-id {conv_id} --pending-id {pending_id}")
        return

    console.print("Waiting for reply (max 60s)...")
    for attempt in range(20):
        time.sleep(3)
        with httpx.Client() as client:
            r = client.get(f"{agents_url}/conversations/{conv_id}/poll/{pending_id}", headers=headers)
        if r.status_code != 200:
            console.print(f"[red]Poll error: {r.status_code}[/red]")
            raise typer.Exit(1)

        data = r.json()
        status = data["status"]
        if status == "complete":
            console.print(f"[green]✓ Reply ready[/green]")
            if data.get("result_text"):
                console.print(data["result_text"])
            return
        elif status == "failed":
            console.print(f"[red]✗ Failed: {data.get('error', 'unknown error')}[/red]")
            raise typer.Exit(1)
        else:
            console.print(f"  [{attempt + 1}/20] status={status}...")

    console.print("[yellow]Timed out after 60s.[/yellow]")
    console.print(f"  Poll: mushu agents conversation-poll --conv-id {conv_id} --pending-id {pending_id}")


@app.command("conversation-poll")
def conversation_poll(
    conv_id: str = typer.Option(..., "--conv-id", "-c", help="Conversation ID"),
    pending_id: str = typer.Option(..., "--pending-id", "-p", help="Pending ID from send"),
    api_key: str = typer.Option(None, "--api-key", "-k", help="Tenant API key"),
):
    """Poll for the result of a sent message."""
    config = get_config()
    agents_url = getattr(config, "agents_url", "https://agents.mushucorp.com")
    headers = _get_headers(api_key)

    with httpx.Client() as client:
        response = client.get(
            f"{agents_url}/conversations/{conv_id}/poll/{pending_id}",
            headers=headers,
        )

    if response.status_code == 404:
        console.print(f"[red]Pending record not found.[/red]")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error: {response.status_code} — {response.text}[/red]")
        raise typer.Exit(1)

    data = response.json()
    status = data["status"]
    color = {"complete": "green", "failed": "red", "pending": "blue"}.get(status, "white")
    console.print(f"[{color}]Status: {status}[/{color}]")
    if data.get("result_text"):
        console.print(data["result_text"])
    if data.get("error"):
        console.print(f"[red]Error: {data['error']}[/red]")


@app.command("conversation-list")
def conversation_list(
    user_id: str = typer.Option(..., "--user", "-u", help="User ID"),
    api_key: str = typer.Option(None, "--api-key", "-k", help="Tenant API key"),
):
    """List conversations for a user."""
    config = get_config()
    agents_url = getattr(config, "agents_url", "https://agents.mushucorp.com")
    headers = _get_headers(api_key)

    with httpx.Client() as client:
        response = client.get(
            f"{agents_url}/conversations",
            headers=headers,
            params={"user_id": user_id},
        )

    if response.status_code != 200:
        console.print(f"[red]Error: {response.status_code} — {response.text}[/red]")
        raise typer.Exit(1)

    convs = response.json()
    if not convs:
        console.print("[dim]No conversations found.[/dim]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("conv_id")
    table.add_column("workflow")
    table.add_column("status")
    table.add_column("created_at")
    for c in convs:
        status = c["status"]
        color = {"idle": "green", "processing": "yellow", "failed": "red"}.get(status, "white")
        table.add_row(
            c["conv_id"],
            c["workflow"],
            f"[{color}]{status}[/{color}]",
            c.get("created_at", "")[:19],
        )
    console.print(table)


@app.command("chatgpt-status")
def chatgpt_status(
    api_key: str = typer.Option(None, "--api-key", "-k", help="Tenant API key"),
):
    """Check ChatGPT Plus connection status for this tenant.

    Shows whether the tenant's ChatGPT Plus subscription is connected,
    expired, or not yet set up. Connecting requires the iOS app.
    """
    config = get_config()
    agents_url = getattr(config, "agents_url", "https://agents.mushucorp.com")
    headers = _get_headers(api_key)

    with httpx.Client() as client:
        response = client.get(f"{agents_url}/chatgpt/status", headers=headers)

    if response.status_code != 200:
        console.print(f"[red]Error: {response.status_code} — {response.text}[/red]")
        raise typer.Exit(1)

    data = response.json()
    connected = data.get("connected", False)
    expired = data.get("expired", False)
    email = data.get("email")
    expires = data.get("expires")

    if expired:
        console.print("[yellow]⚠ ChatGPT Plus subscription expired or token revoked.[/yellow]")
        if email:
            console.print(f"  Last connected as: {email}")
        console.print("  Reconnect via your iOS app to resume AI runs.")
    elif connected:
        import datetime

        console.print(f"[green]✓ Connected[/green]", end="")
        if email:
            console.print(f" as [bold]{email}[/bold]", end="")
        if expires:
            days_left = (expires - int(datetime.datetime.now().timestamp())) // 86400
            console.print(f" (expires in {days_left} day{'s' if days_left != 1 else ''})", end="")
        console.print()
    else:
        console.print("[dim]✗ Not connected[/dim]")
        console.print("  Use your iOS app to connect a ChatGPT Plus subscription.")
