from typing import TypeVar, Generic

class Reference[T]:
    def __init__(self, value: T | None = None) -> None:
        self.value = value

    def require(self) -> T:
        if self.value is None:
            raise Exception("Reference hasn't been resolved!")

        return self.value

    def resolve(self, value: T) -> None:
        if self.value is None:
            self.value = value

    def __repr__(self) -> str:
        return object.__repr__(self.require())
