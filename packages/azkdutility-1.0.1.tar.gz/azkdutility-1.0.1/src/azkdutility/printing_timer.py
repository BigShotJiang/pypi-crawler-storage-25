import time

from typing import Union, Callable, TypeVar, ParamSpec, Type

from .reference import Reference

P = ParamSpec("P")
T = TypeVar("T")


# use not recommended, but it's here
class PrintingTimer:
    def __init__(self, message: str | Reference[str] = "Done in {}s"):
        self.message = message
        self.start_time = time.time()

    def print(self, message: str) -> None:
        if not "{}" in message:
            message += " ({}s)"

        elapsed = time.time() - self.start_time

        print(message.format(elapsed))

    @classmethod
    def wrap(
        cls, message: str | None = None
    ) -> Callable[[Callable[P, T]], Callable[P, T]]:

        def wrapper(method: Callable[P, T]) -> Callable[P, T]:
            def handler(*args, **kwargs) -> T:
                if message is None:
                    if "ptref" in method.__annotations__.keys():
                        message_obj = Reference()

                        kwargs["ptref"] = message_obj
                    else:
                        message_obj = Reference("Done in {}s")

                else:
                    message_obj = message

                with cls(message_obj):
                    return method(*args, **kwargs)

            return handler

        return wrapper

    def __enter__(self) -> None:
        self.start_time = time.time()

    def __exit__(self, *_) -> None:
        message = (
            self.message.require()
            if isinstance(self.message, Reference)
            else self.message
        )

        self.print(message)
