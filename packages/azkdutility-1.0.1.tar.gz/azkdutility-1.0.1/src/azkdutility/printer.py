import sys

from typing import TextIO


class Printer:
    stdout: TextIO
    trail: str

    def __init__(self, stdout: TextIO = sys.stdout) -> None:
        self.stdout = stdout
        self.trail = ""

    def print(
        self, *values: object, sep: str | None = " ", end: str | None = "\n"
    ) -> None:

        print(*values, sep=sep, end=end, file=self.stdout)

        if sep is None:
            sep = ""

        if end is None:
            end = ""

        self.trail += sep.join([str(value) for value in values]) + end
