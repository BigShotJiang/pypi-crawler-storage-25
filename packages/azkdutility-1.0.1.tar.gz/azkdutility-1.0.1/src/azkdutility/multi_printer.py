from .printer import Printer


class MultiPrinter(Printer):
    printers: list[Printer]
    trail: str

    def __init__(self, *printers: Printer) -> None:
        self.printers = list(printers)
        self.trail = ""

    def add(self, printer: Printer) -> None:
        self.printers.append(printer)

    def remove(self, printer: Printer) -> None:
        self.printers.remove(printer)

    def print(
        self, *values: object, sep: str | None = " ", end: str | None = "\n"
    ) -> None:

        for printer in self.printers:
            printer.print(*values, sep=sep, end=end)

        if sep is None:
            sep = ""

        if end is None:
            end = ""

        self.trail += sep.join([str(value) for value in values]) + end
