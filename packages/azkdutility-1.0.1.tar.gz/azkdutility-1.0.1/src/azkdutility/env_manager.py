from __future__ import annotations

import os
import json

from typing import TextIO, Callable, Self


class EnvManager(dict[str, str]):
    # use a+ as mode
    file: TextIO | None

    @staticmethod
    def load_values(file: str | TextIO) -> dict[str, str]:
        if isinstance(file, str):
            file = open(file, "a+")

        values = {}

        file.seek(0)
        for line in file.readlines():
            line = line.strip()
            if "=" not in line:
                continue

            key, value = line.split("=")
            if not (key and value):
                continue

            values[key] = value

        return values

    @staticmethod
    def dump_values(values: dict[str, str], file: str | TextIO) -> None:
        if isinstance(file, str):
            file = open(file, "a+")

        file.seek(0)
        file.truncate(0)

        lines = []
        for key, value in values.items():
            lines.append(f"{key}={value}")

        file.write("\n".join(lines))

    def __init__(
        self,
        env_path: str = ".env",
        /,
        *,
        default_callback: Callable[[str, str], str] | None = None,
    ) -> None:

        super().__init__()

        self.env_path = env_path
        self.default_callback = default_callback

        self.file = None

    def __enter__(self) -> Self:
        # lazy reset; could be set to none in exit? overcomplicates typing
        self.file = open(self.env_path, "a+")

        self._load_values()

        return self

    def _load_values(self) -> None:
        assert self.file is not None

        values = self.load_values(self.file)

        for key, value in values.items():
            self[key] = value
            os.environ[key] = value

    def _dump_values(self) -> None:
        assert self.file is not None

        self.dump_values(self, self.file)

    def __setitem__(self, key: str, value: str) -> None:
        super().__setitem__(key, value)

        os.environ[key] = value

    def __getitem__(self, key: str) -> str:
        # only needs internal values for writing data
        return os.environ[key]

    def get[T](self, key: str, default: T = None) -> str | T:
        return super().get(key, default)

    def require(
        self,
        key: str,
        /,
        title: str | None = None,
        *,
        callback: Callable[[str, str], str] | None = None,
    ) -> str:

        if title is None:
            title = key

        callback = callback or self.default_callback

        value = self.get(key)
        if value is None:
            if callback is None:
                value = input(f"Please enter a value for {title}: ")
            else:
                value = callback(key, title)

        self[key] = value

        return value

    def __exit__(self, *_) -> bool:
        assert self.file is not None

        self._dump_values()

        self.file.close()

        self.file = None

        return False
