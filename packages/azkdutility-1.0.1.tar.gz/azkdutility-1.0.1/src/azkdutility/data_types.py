from typing import TypedDict


class LinkedWorkItem(TypedDict):
    role: str
    uri: str


class WorkItemExport(TypedDict):
    uri: str | None
    id: str | None
    title: str | None
    description: str | None
    linked: list[LinkedWorkItem]
