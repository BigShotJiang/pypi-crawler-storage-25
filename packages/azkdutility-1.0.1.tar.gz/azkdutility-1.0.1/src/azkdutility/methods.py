import os
import asyncio
import functools
import inspect
import traceback

from typing import Callable, Iterable, Any, AsyncIterator, Awaitable

from asyncio import Future, Task

from functools import partial


def print_header(*args, decoration: str = "-", **kwargs) -> None:
    print(decoration * 30)
    print(*args, **kwargs)
    print(decoration * 30)


def method_header[**P, R](string: str) -> Callable[[Callable[P, R]], Callable[P, R]]:
    def wrapper(method: Callable[P, R]) -> Callable[P, R]:
        @functools.wraps(method)
        def handler(*args: P.args, **kwargs: P.kwargs) -> R:
            print_header(string)

            return method(*args, **kwargs)

        return handler

    return wrapper


# GoLang Style Call
async def gls_call[T](
    method: Callable[..., T], /, print_exc: bool = False
) -> tuple[T | None, Exception | None]:

    try:
        if inspect.iscoroutinefunction(method):
            return await method(), None
        else:
            return method(), None

    except Exception as e:
        if print_exc:
            traceback.print_exception(e)

        return None, e
