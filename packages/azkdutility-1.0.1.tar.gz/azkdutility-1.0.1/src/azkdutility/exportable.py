from typing import Any, ClassVar, Self, TypedDict


type Export[T: Exportable] = dict[str, Any]


class Exportable:
    DISABLE_TRACKING: ClassVar[bool] = False

    _registry: list[str]

    def __init__(self) -> None:
        object.__setattr__(self, "_registry", [])

    def _import(self, obj: Export[Self]) -> None:
        for name, value in obj.items():
            setattr(self, name, value)

    @classmethod
    def export_obj(cls, obj: object) -> object:
        if isinstance(obj, Exportable):
            return obj.export()

        elif isinstance(obj, list):
            obj = obj.copy()

            for i, sub_obj in enumerate(obj):
                obj[i] = cls.export_obj(sub_obj)

            return obj

        elif isinstance(obj, dict):
            obj = obj.copy()

            for name, sub_obj in obj.items():
                obj[name] = cls.export_obj(sub_obj)

            return obj

        elif isinstance(obj, tuple):
            return cls.export_obj(list(obj))

        elif obj is None or isinstance(obj, (str, bool, int, float)):
            return obj

        else:
            return repr(obj)

    def export(self, *, strict: bool = True) -> Export[Self]:
        result: Export[Self] = {}

        for name in self._registry:
            if strict:
                value = getattr(self, name)
            else:
                value = getattr(self, name, None)

            result[name] = self.export_obj(value)

        return result

    def _add_to_registry(self, name: str) -> None:
        if name.startswith("_") or self.DISABLE_TRACKING or name in self._registry:
            return

        self._registry.append(name)

    def __setattr__(self, name: str, value: Any) -> None:
        self._add_to_registry(name)

        object.__setattr__(self, name, value)
