import tkinter as tk
import string
import random
import queue

from queue import Queue

from .printer import Printer


def gen_id(length: int = 8) -> str:
    return "".join(random.choices(string.ascii_letters + string.digits, k=length))


class TkTextPrinter(Printer):
    textbox: tk.Text
    disabled: bool
    queue: Queue[tuple[tuple[object, ...], str | None, str | None]]

    def __init__(self, textbox: tk.Text, disabled: bool = True) -> None:
        self.textbox = textbox
        self.disabled = disabled
        self.queue = Queue()

        self.textbox.after(10, self._flush_queue)

    def print(
        self, *values: object, sep: str | None = " ", end: str | None = "\n"
    ) -> None:

        self.queue.put_nowait((values, sep, end))

    def _print(
        self, *values: object, sep: str | None = " ", end: str | None = "\n"
    ) -> None:

        if sep is None:
            sep = ""

        if end is None:
            end = "\n"

        string_values = [str(value) for value in values]

        chars = sep.join(string_values) + end

        self.textbox.config(state="normal")

        self.textbox.insert("end", chars)

        self.textbox.see("end")

        if self.disabled:
            self.textbox.config(state="disabled")

    def _flush_queue(self) -> None:
        try:
            while True:
                print_args = self.queue.get_nowait()

                self._print(print_args)

        except queue.Empty:
            pass

        self.textbox.after(10, self._flush_queue)
