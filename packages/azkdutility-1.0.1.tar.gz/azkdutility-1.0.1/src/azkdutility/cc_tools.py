import os
import asyncio

from typing import Any

from asyncio import Task

from typing import (
    Callable,
    Iterable,
    AsyncIterable,
    AsyncIterator,
    Awaitable,
    Coroutine,
    overload,
)


async def _iterable_to_async(
    iterable: Iterable[Any] | AsyncIterable[Any],
) -> AsyncIterator[Any]:

    if isinstance(iterable, Iterable):
        for item in iterable:
            yield item
    else:
        async for item in iterable:
            yield item


@overload
def cc_zip(
    *,
    strict: bool = False,
) -> AsyncIterator[tuple[Any]]: ...


@overload
def cc_zip[A](
    iterable_a: Iterable[A] | AsyncIterable[A],
    /,
    *,
    strict: bool = False,
) -> AsyncIterator[tuple[A]]: ...


@overload
def cc_zip[A, B](
    iterable_a: Iterable[A] | AsyncIterable[A],
    iterable_b: Iterable[B] | AsyncIterable[B],
    /,
    *,
    strict: bool = False,
) -> AsyncIterator[tuple[A, B]]: ...


@overload
def cc_zip[A, B, C](
    iterable_a: Iterable[A] | AsyncIterable[A],
    iterable_b: Iterable[B] | AsyncIterable[B],
    iterable_c: Iterable[C] | AsyncIterable[C],
    /,
    *,
    strict: bool = False,
) -> AsyncIterator[tuple[A, B, C]]: ...


@overload
def cc_zip[A, B, C, D](
    iterable_a: Iterable[A] | AsyncIterable[A],
    iterable_b: Iterable[B] | AsyncIterable[B],
    iterable_c: Iterable[C] | AsyncIterable[C],
    iterable_d: Iterable[D] | AsyncIterable[D],
    /,
    *,
    strict: bool = False,
) -> AsyncIterator[tuple[A, B, C, D]]: ...


@overload
def cc_zip[A, B, C, D, E](
    iterable_a: Iterable[A] | AsyncIterable[A],
    iterable_b: Iterable[B] | AsyncIterable[B],
    iterable_c: Iterable[C] | AsyncIterable[C],
    iterable_d: Iterable[D] | AsyncIterable[D],
    iterable_e: Iterable[E] | AsyncIterable[E],
    /,
    *,
    strict: bool = False,
) -> AsyncIterator[tuple[A, B, C, D, E]]: ...


@overload
def cc_zip[A, B, C, D, E, F](
    iterable_a: Iterable[A] | AsyncIterable[A],
    iterable_b: Iterable[B] | AsyncIterable[B],
    iterable_c: Iterable[C] | AsyncIterable[C],
    iterable_d: Iterable[D] | AsyncIterable[D],
    iterable_e: Iterable[E] | AsyncIterable[E],
    iterable_f: Iterable[F] | AsyncIterable[F],
    /,
    *,
    strict: bool = False,
) -> AsyncIterator[tuple[A, B, C, D, E, F]]: ...


async def cc_zip(
    iterable_a: Iterable[Any] | AsyncIterable[Any] | None = None,
    iterable_b: Iterable[Any] | AsyncIterable[Any] | None = None,
    iterable_c: Iterable[Any] | AsyncIterable[Any] | None = None,
    iterable_d: Iterable[Any] | AsyncIterable[Any] | None = None,
    iterable_e: Iterable[Any] | AsyncIterable[Any] | None = None,
    iterable_f: Iterable[Any] | AsyncIterable[Any] | None = None,
    /,
    *iterables: Iterable[Any] | AsyncIterable[Any],
    strict: bool = False,
) -> AsyncIterator[tuple[Any, ...]]:

    async_iterables: list[AsyncIterator[Any]] = []
    for iterable in (
        iterable_a,
        iterable_b,
        iterable_c,
        iterable_d,
        iterable_e,
        iterable_f,
        *iterables,
    ):

        if iterable is None:
            continue

        async_iterables.append(_iterable_to_async(iterable))

    iterators = [iterable.__aiter__() for iterable in async_iterables]
    while iterators:
        iter_results = await asyncio.gather(
            *[iterator.__anext__() for iterator in iterators], return_exceptions=True
        )

        values: list[Any] = []
        has_remaining_values = False
        for result in iter_results:
            if isinstance(result, StopAsyncIteration):
                continue

            values.append(result)

            has_remaining_values = True

        if not has_remaining_values:
            if strict:
                raise ValueError("Iterables have different lengths!")

            break

        yield tuple(values)


async def cc_enumerate[T](
    iterable: Iterable[T] | AsyncIterable[T], /, start: int = 0
) -> AsyncIterator[tuple[int, T]]:

    index = start
    async for item in _iterable_to_async(iterable):
        yield index, item
        index += 1


async def cc_iterate[T](
    method: Callable[..., Awaitable[T]],
    /,
    *iterables: Iterable[Any] | AsyncIterable[Any],
    max_workers: int | None = None,
) -> AsyncIterator[T]:

    # concurrent.futures.ThreadPoolExecutor
    if max_workers is None:
        max_workers = min(32, (os.process_cpu_count() or 1) + 4)
    if max_workers <= 0:
        raise ValueError("max_workers must be greater than 0")

    semaphore = asyncio.Semaphore(max_workers)

    async def call_in_semaphore(*items: Any) -> T:
        async with semaphore:
            return await method(*items)

    tasks: list[Task[T]] = []
    async for items in cc_zip(*iterables):
        tasks.append(asyncio.create_task(call_in_semaphore(*items)))

    for task in tasks:
        yield await task
