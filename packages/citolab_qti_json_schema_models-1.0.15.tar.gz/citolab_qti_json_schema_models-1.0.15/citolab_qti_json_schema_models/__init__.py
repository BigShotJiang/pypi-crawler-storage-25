"""
Citolab QTI JSON Schema Models.

Generated Python models for the QTI JSON schema project.
This package contains type definitions for exams, items, users, and groups.
"""

__version__ = "1.0.0"
__author__ = "Marcel Hoekstra"

from .models import *  # noqa: F401,F403
