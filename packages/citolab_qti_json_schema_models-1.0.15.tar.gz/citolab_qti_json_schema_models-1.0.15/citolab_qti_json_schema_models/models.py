from enum import Enum
from typing import Optional, Any, List, TypeVar, Type, Callable, cast


T = TypeVar("T")
EnumT = TypeVar("EnumT", bound=Enum)


def from_str(x: Any) -> str:
    assert isinstance(x, str)
    return x


def from_none(x: Any) -> Any:
    assert x is None
    return x


def from_union(fs, x):
    for f in fs:
        try:
            return f(x)
        except:
            pass
    assert False


def from_bool(x: Any) -> bool:
    assert isinstance(x, bool)
    return x


def to_enum(c: Type[EnumT], x: Any) -> EnumT:
    assert isinstance(x, c)
    return x.value


def from_list(f: Callable[[Any], T], x: Any) -> List[T]:
    assert isinstance(x, list)
    return [f(y) for y in x]


def from_int(x: Any) -> int:
    assert isinstance(x, int) and not isinstance(x, bool)
    return x


def to_class(c: Type[T], x: Any) -> dict:
    assert isinstance(x, c)
    return cast(Any, x).to_dict()


def from_float(x: Any) -> float:
    assert isinstance(x, (float, int)) and not isinstance(x, bool)
    return float(x)


def to_float(x: Any) -> float:
    assert isinstance(x, (int, float))
    return x


class FileType(Enum):
    ANSWER = "answer"
    ANSWER_EXTRACTED = "answer_extracted"
    CONFIGURATION = "configuration"
    METADATA = "metadata"
    QTI_EXPORT = "qti_export"
    QTI_IMPORT = "qti_import"
    QUESTION = "question"
    QUESTION_AND_ANSWER = "question_and_answer"
    QUESTION_AND_ANSWER_EXTRACTED = "question_and_answer_extracted"
    QUESTION_EXTRACTED = "question_extracted"
    SOURCES = "sources"
    STRUCTURE = "structure"


class ExamFile:
    """A file associated with an exam"""

    id: Optional[str]
    """Unique identifier for the exam file"""

    exam_id: str
    """Reference to the parent exam"""

    file_type: FileType
    file_url: str
    """URL where the file is stored"""

    processed: bool
    """Whether the file has been processed"""

    def __init__(self, id: Optional[str], exam_id: str, file_type: FileType, file_url: str, processed: bool) -> None:
        self.id = id
        self.exam_id = exam_id
        self.file_type = file_type
        self.file_url = file_url
        self.processed = processed

    @staticmethod
    def from_dict(obj: Any) -> 'ExamFile':
        assert isinstance(obj, dict)
        id = from_union([from_str, from_none], obj.get("_id"))
        exam_id = from_str(obj.get("examId"))
        file_type = FileType(obj.get("fileType"))
        file_url = from_str(obj.get("fileUrl"))
        processed = from_bool(obj.get("processed"))
        return ExamFile(id, exam_id, file_type, file_url, processed)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.id is not None:
            result["_id"] = from_union([from_str, from_none], self.id)
        result["examId"] = from_str(self.exam_id)
        result["fileType"] = to_enum(FileType, self.file_type)
        result["fileUrl"] = from_str(self.file_url)
        result["processed"] = from_bool(self.processed)
        return result


class HotTextSelection:
    correct: bool
    """Whether this selection is correct"""

    identifier: str
    """Unique identifier for this selection"""

    text: str
    """The text content of this selection"""

    def __init__(self, correct: bool, identifier: str, text: str) -> None:
        self.correct = correct
        self.identifier = identifier
        self.text = text

    @staticmethod
    def from_dict(obj: Any) -> 'HotTextSelection':
        assert isinstance(obj, dict)
        correct = from_bool(obj.get("correct"))
        identifier = from_str(obj.get("identifier"))
        text = from_str(obj.get("text"))
        return HotTextSelection(correct, identifier, text)

    def to_dict(self) -> dict:
        result: dict = {}
        result["correct"] = from_bool(self.correct)
        result["identifier"] = from_str(self.identifier)
        result["text"] = from_str(self.text)
        return result


class InlineChoice:
    correct_option: str
    """The correct option for this position"""

    options: List[str]
    """Available options for this position"""

    position: int
    """Position of this choice in the text (0-based)"""

    def __init__(self, correct_option: str, options: List[str], position: int) -> None:
        self.correct_option = correct_option
        self.options = options
        self.position = position

    @staticmethod
    def from_dict(obj: Any) -> 'InlineChoice':
        assert isinstance(obj, dict)
        correct_option = from_str(obj.get("correct_option"))
        options = from_list(from_str, obj.get("options"))
        position = from_int(obj.get("position"))
        return InlineChoice(correct_option, options, position)

    def to_dict(self) -> dict:
        result: dict = {}
        result["correct_option"] = from_str(self.correct_option)
        result["options"] = from_list(from_str, self.options)
        result["position"] = from_int(self.position)
        return result


class InteractionType(Enum):
    CHOICE = "choice"
    HOTTEXT = "hottext"
    INLINE_CHOICE = "inline_choice"
    MATCH = "match"
    ORDER = "order"


class CorrectPair:
    source: str
    """Identifier of the source item"""

    target: str
    """Identifier of the target item"""

    def __init__(self, source: str, target: str) -> None:
        self.source = source
        self.target = target

    @staticmethod
    def from_dict(obj: Any) -> 'CorrectPair':
        assert isinstance(obj, dict)
        source = from_str(obj.get("source"))
        target = from_str(obj.get("target"))
        return CorrectPair(source, target)

    def to_dict(self) -> dict:
        result: dict = {}
        result["source"] = from_str(self.source)
        result["target"] = from_str(self.target)
        return result


class MatchSetItem:
    content: str
    """Content of this match item"""

    identifier: str
    """Unique identifier for this match item"""

    def __init__(self, content: str, identifier: str) -> None:
        self.content = content
        self.identifier = identifier

    @staticmethod
    def from_dict(obj: Any) -> 'MatchSetItem':
        assert isinstance(obj, dict)
        content = from_str(obj.get("content"))
        identifier = from_str(obj.get("identifier"))
        return MatchSetItem(content, identifier)

    def to_dict(self) -> dict:
        result: dict = {}
        result["content"] = from_str(self.content)
        result["identifier"] = from_str(self.identifier)
        return result


class MatchSets:
    correct_pairs: List[CorrectPair]
    """Correct pairings between sets"""

    set_a: List[MatchSetItem]
    """Items in set A (source items)"""

    set_b: List[MatchSetItem]
    """Items in set B (target items)"""

    def __init__(self, correct_pairs: List[CorrectPair], set_a: List[MatchSetItem], set_b: List[MatchSetItem]) -> None:
        self.correct_pairs = correct_pairs
        self.set_a = set_a
        self.set_b = set_b

    @staticmethod
    def from_dict(obj: Any) -> 'MatchSets':
        assert isinstance(obj, dict)
        correct_pairs = from_list(CorrectPair.from_dict, obj.get("correct_pairs"))
        set_a = from_list(MatchSetItem.from_dict, obj.get("set_a"))
        set_b = from_list(MatchSetItem.from_dict, obj.get("set_b"))
        return MatchSets(correct_pairs, set_a, set_b)

    def to_dict(self) -> dict:
        result: dict = {}
        result["correct_pairs"] = from_list(lambda x: to_class(CorrectPair, x), self.correct_pairs)
        result["set_a"] = from_list(lambda x: to_class(MatchSetItem, x), self.set_a)
        result["set_b"] = from_list(lambda x: to_class(MatchSetItem, x), self.set_b)
        return result


class OrderItem:
    content: str
    """Content of this order item"""

    correct_position: int
    """Correct position of this item in the sequence (1-based)"""

    identifier: str
    """Unique identifier for this order item"""

    def __init__(self, content: str, correct_position: int, identifier: str) -> None:
        self.content = content
        self.correct_position = correct_position
        self.identifier = identifier

    @staticmethod
    def from_dict(obj: Any) -> 'OrderItem':
        assert isinstance(obj, dict)
        content = from_str(obj.get("content"))
        correct_position = from_int(obj.get("correct_position"))
        identifier = from_str(obj.get("identifier"))
        return OrderItem(content, correct_position, identifier)

    def to_dict(self) -> dict:
        result: dict = {}
        result["content"] = from_str(self.content)
        result["correct_position"] = from_int(self.correct_position)
        result["identifier"] = from_str(self.identifier)
        return result


class ResponseStyle(Enum):
    CALCULATION = "calculation"
    KNOWLEDGE = "knowledge"


class ReviewStatus(Enum):
    CHECKED = "checked"
    NEEDS_REVIEW = "needs_review"
    UNCHECKED = "unchecked"


class ExamItem:
    """An individual exam item (question) within an item block"""

    id: Optional[str]
    """Unique identifier for the exam item"""

    answer: str
    """Correct answer or answer key"""

    correction: Optional[str]
    """Correction guidelines or rubric"""

    hottext_content: Optional[str]
    """Full text content with markers for hot text interactions"""

    hottext_selections: Optional[List[HotTextSelection]]
    """Selectable text options for hot text interactions"""

    image_context: Optional[str]
    """Description of images specific to this item"""

    image_urls: Optional[List[str]]
    """URLs of images associated with this item"""

    inline_choice_text: Optional[str]
    """Text with placeholders (e.g., {0}, {1}) for inline choice interactions"""

    inline_choices: Optional[List[InlineChoice]]
    """Inline choice options for each placeholder position"""

    interaction_type: Optional[InteractionType]
    item_block_id: str
    """Reference to the parent item block"""

    item_identifier: Optional[str]
    """QTI identifier for this item (e.g., 'ITM-01')"""

    item_images: Optional[List[str]]
    """JSON stringified array of images (deprecated, use image_urls)"""

    item_number: int
    """Sequential number of this item within the exam"""

    item_type: Optional[str]
    """Type of item (deprecated, use interaction_type)"""

    match_sets: Optional[MatchSets]
    max_score: float
    """Maximum score achievable for this item"""

    order_items: Optional[List[OrderItem]]
    """Items to be ordered for order interactions"""

    question: str
    """The question text"""

    question_options: Optional[List[str]]
    """Multiple choice options (for choice interactions)"""

    response_style: Optional[ResponseStyle]
    response_type: Optional[str]
    """Response type (deprecated, use interaction_type)"""

    review_note: Optional[str]
    """Review notes for this item"""

    review_status: Optional[ReviewStatus]
    reviewed_at: Optional[str]
    """Timestamp when this item was reviewed (ISO 8601 format)"""

    reviewed_by: Optional[str]
    """ID of the user who reviewed this item"""

    stimulus: Optional[str]
    """Additional stimulus text specific to this item"""

    def __init__(self, id: Optional[str], answer: str, correction: Optional[str], hottext_content: Optional[str], hottext_selections: Optional[List[HotTextSelection]], image_context: Optional[str], image_urls: Optional[List[str]], inline_choice_text: Optional[str], inline_choices: Optional[List[InlineChoice]], interaction_type: Optional[InteractionType], item_block_id: str, item_identifier: Optional[str], item_images: Optional[List[str]], item_number: int, item_type: Optional[str], match_sets: Optional[MatchSets], max_score: float, order_items: Optional[List[OrderItem]], question: str, question_options: Optional[List[str]], response_style: Optional[ResponseStyle], response_type: Optional[str], review_note: Optional[str], review_status: Optional[ReviewStatus], reviewed_at: Optional[str], reviewed_by: Optional[str], stimulus: Optional[str]) -> None:
        self.id = id
        self.answer = answer
        self.correction = correction
        self.hottext_content = hottext_content
        self.hottext_selections = hottext_selections
        self.image_context = image_context
        self.image_urls = image_urls
        self.inline_choice_text = inline_choice_text
        self.inline_choices = inline_choices
        self.interaction_type = interaction_type
        self.item_block_id = item_block_id
        self.item_identifier = item_identifier
        self.item_images = item_images
        self.item_number = item_number
        self.item_type = item_type
        self.match_sets = match_sets
        self.max_score = max_score
        self.order_items = order_items
        self.question = question
        self.question_options = question_options
        self.response_style = response_style
        self.response_type = response_type
        self.review_note = review_note
        self.review_status = review_status
        self.reviewed_at = reviewed_at
        self.reviewed_by = reviewed_by
        self.stimulus = stimulus

    @staticmethod
    def from_dict(obj: Any) -> 'ExamItem':
        assert isinstance(obj, dict)
        id = from_union([from_str, from_none], obj.get("_id"))
        answer = from_str(obj.get("answer"))
        correction = from_union([from_none, from_str], obj.get("correction"))
        hottext_content = from_union([from_none, from_str], obj.get("hottext_content"))
        hottext_selections = from_union([lambda x: from_list(HotTextSelection.from_dict, x), from_none], obj.get("hottext_selections"))
        image_context = from_union([from_none, from_str], obj.get("image_context"))
        image_urls = from_union([lambda x: from_list(from_str, x), from_none], obj.get("image_urls"))
        inline_choice_text = from_union([from_none, from_str], obj.get("inline_choice_text"))
        inline_choices = from_union([lambda x: from_list(InlineChoice.from_dict, x), from_none], obj.get("inline_choices"))
        interaction_type = from_union([InteractionType, from_none], obj.get("interaction_type"))
        item_block_id = from_str(obj.get("item_block_id"))
        item_identifier = from_union([from_none, from_str], obj.get("item_identifier"))
        item_images = from_union([lambda x: from_list(from_str, x), from_none], obj.get("item_images"))
        item_number = from_int(obj.get("item_number"))
        item_type = from_union([from_none, from_str], obj.get("item_type"))
        match_sets = from_union([MatchSets.from_dict, from_none], obj.get("match_sets"))
        max_score = from_float(obj.get("max_score"))
        order_items = from_union([lambda x: from_list(OrderItem.from_dict, x), from_none], obj.get("order_items"))
        question = from_str(obj.get("question"))
        question_options = from_union([lambda x: from_list(from_str, x), from_none], obj.get("question_options"))
        response_style = from_union([ResponseStyle, from_none], obj.get("response_style"))
        response_type = from_union([from_none, from_str], obj.get("response_type"))
        review_note = from_union([from_none, from_str], obj.get("review_note"))
        review_status = from_union([ReviewStatus, from_none], obj.get("review_status"))
        reviewed_at = from_union([from_none, from_str], obj.get("reviewed_at"))
        reviewed_by = from_union([from_none, from_str], obj.get("reviewed_by"))
        stimulus = from_union([from_none, from_str], obj.get("stimulus"))
        return ExamItem(id, answer, correction, hottext_content, hottext_selections, image_context, image_urls, inline_choice_text, inline_choices, interaction_type, item_block_id, item_identifier, item_images, item_number, item_type, match_sets, max_score, order_items, question, question_options, response_style, response_type, review_note, review_status, reviewed_at, reviewed_by, stimulus)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.id is not None:
            result["_id"] = from_union([from_str, from_none], self.id)
        result["answer"] = from_str(self.answer)
        if self.correction is not None:
            result["correction"] = from_union([from_none, from_str], self.correction)
        if self.hottext_content is not None:
            result["hottext_content"] = from_union([from_none, from_str], self.hottext_content)
        if self.hottext_selections is not None:
            result["hottext_selections"] = from_union([lambda x: from_list(lambda x: to_class(HotTextSelection, x), x), from_none], self.hottext_selections)
        if self.image_context is not None:
            result["image_context"] = from_union([from_none, from_str], self.image_context)
        if self.image_urls is not None:
            result["image_urls"] = from_union([lambda x: from_list(from_str, x), from_none], self.image_urls)
        if self.inline_choice_text is not None:
            result["inline_choice_text"] = from_union([from_none, from_str], self.inline_choice_text)
        if self.inline_choices is not None:
            result["inline_choices"] = from_union([lambda x: from_list(lambda x: to_class(InlineChoice, x), x), from_none], self.inline_choices)
        if self.interaction_type is not None:
            result["interaction_type"] = from_union([lambda x: to_enum(InteractionType, x), from_none], self.interaction_type)
        result["item_block_id"] = from_str(self.item_block_id)
        if self.item_identifier is not None:
            result["item_identifier"] = from_union([from_none, from_str], self.item_identifier)
        if self.item_images is not None:
            result["item_images"] = from_union([lambda x: from_list(from_str, x), from_none], self.item_images)
        result["item_number"] = from_int(self.item_number)
        if self.item_type is not None:
            result["item_type"] = from_union([from_none, from_str], self.item_type)
        if self.match_sets is not None:
            result["match_sets"] = from_union([lambda x: to_class(MatchSets, x), from_none], self.match_sets)
        result["max_score"] = to_float(self.max_score)
        if self.order_items is not None:
            result["order_items"] = from_union([lambda x: from_list(lambda x: to_class(OrderItem, x), x), from_none], self.order_items)
        result["question"] = from_str(self.question)
        if self.question_options is not None:
            result["question_options"] = from_union([lambda x: from_list(from_str, x), from_none], self.question_options)
        if self.response_style is not None:
            result["response_style"] = from_union([lambda x: to_enum(ResponseStyle, x), from_none], self.response_style)
        if self.response_type is not None:
            result["response_type"] = from_union([from_none, from_str], self.response_type)
        if self.review_note is not None:
            result["review_note"] = from_union([from_none, from_str], self.review_note)
        if self.review_status is not None:
            result["review_status"] = from_union([lambda x: to_enum(ReviewStatus, x), from_none], self.review_status)
        if self.reviewed_at is not None:
            result["reviewed_at"] = from_union([from_none, from_str], self.reviewed_at)
        if self.reviewed_by is not None:
            result["reviewed_by"] = from_union([from_none, from_str], self.reviewed_by)
        if self.stimulus is not None:
            result["stimulus"] = from_union([from_none, from_str], self.stimulus)
        return result


class ExamObject:
    """Exam metadata stored separately from main exam record"""

    id: Optional[str]
    """Unique identifier"""

    course: Optional[str]
    """Course name (e.g., 'biologie', 'wiskunde')"""

    description: Optional[str]
    """Description of the exam"""

    exam_code: Optional[str]
    """Exam code (e.g., 'HA-1018-a-25-1-c')"""

    exam_id: str
    """Reference to the parent exam"""

    school_type: Optional[str]
    """School type (e.g., 'HAVO', 'VWO')"""

    tijd_vak: Optional[str]
    """Time/subject type"""

    title: Optional[str]
    """Title of the exam"""

    updated_at: Optional[str]
    """Last updated timestamp (ISO 8601 format)"""

    year: Optional[int]
    """Year of the exam"""

    def __init__(self, id: Optional[str], course: Optional[str], description: Optional[str], exam_code: Optional[str], exam_id: str, school_type: Optional[str], tijd_vak: Optional[str], title: Optional[str], updated_at: Optional[str], year: Optional[int]) -> None:
        self.id = id
        self.course = course
        self.description = description
        self.exam_code = exam_code
        self.exam_id = exam_id
        self.school_type = school_type
        self.tijd_vak = tijd_vak
        self.title = title
        self.updated_at = updated_at
        self.year = year

    @staticmethod
    def from_dict(obj: Any) -> 'ExamObject':
        assert isinstance(obj, dict)
        id = from_union([from_str, from_none], obj.get("_id"))
        course = from_union([from_none, from_str], obj.get("course"))
        description = from_union([from_none, from_str], obj.get("description"))
        exam_code = from_union([from_none, from_str], obj.get("exam_code"))
        exam_id = from_str(obj.get("examId"))
        school_type = from_union([from_none, from_str], obj.get("school_type"))
        tijd_vak = from_union([from_none, from_str], obj.get("tijd_vak"))
        title = from_union([from_none, from_str], obj.get("title"))
        updated_at = from_union([from_none, from_str], obj.get("updated_at"))
        year = from_union([from_none, from_int], obj.get("year"))
        return ExamObject(id, course, description, exam_code, exam_id, school_type, tijd_vak, title, updated_at, year)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.id is not None:
            result["_id"] = from_union([from_str, from_none], self.id)
        if self.course is not None:
            result["course"] = from_union([from_none, from_str], self.course)
        if self.description is not None:
            result["description"] = from_union([from_none, from_str], self.description)
        if self.exam_code is not None:
            result["exam_code"] = from_union([from_none, from_str], self.exam_code)
        result["examId"] = from_str(self.exam_id)
        if self.school_type is not None:
            result["school_type"] = from_union([from_none, from_str], self.school_type)
        if self.tijd_vak is not None:
            result["tijd_vak"] = from_union([from_none, from_str], self.tijd_vak)
        if self.title is not None:
            result["title"] = from_union([from_none, from_str], self.title)
        if self.updated_at is not None:
            result["updated_at"] = from_union([from_none, from_str], self.updated_at)
        if self.year is not None:
            result["year"] = from_union([from_none, from_int], self.year)
        return result


class TypeEnum(Enum):
    """Type of access (user or group)"""

    GROUP = "group"
    USER = "user"


class AccessEntry:
    id: str
    """ID of the user or group being granted access"""

    type: TypeEnum
    """Type of access (user or group)"""

    def __init__(self, id: str, type: TypeEnum) -> None:
        self.id = id
        self.type = type

    @staticmethod
    def from_dict(obj: Any) -> 'AccessEntry':
        assert isinstance(obj, dict)
        id = from_str(obj.get("id"))
        type = TypeEnum(obj.get("type"))
        return AccessEntry(id, type)

    def to_dict(self) -> dict:
        result: dict = {}
        result["id"] = from_str(self.id)
        result["type"] = to_enum(TypeEnum, self.type)
        return result


class ExamStructureItem:
    item_block_index: int
    """Index of the item block"""

    item_block_title: Optional[str]
    """Title of the item block"""

    item_number: int
    """Number of the item"""

    def __init__(self, item_block_index: int, item_block_title: Optional[str], item_number: int) -> None:
        self.item_block_index = item_block_index
        self.item_block_title = item_block_title
        self.item_number = item_number

    @staticmethod
    def from_dict(obj: Any) -> 'ExamStructureItem':
        assert isinstance(obj, dict)
        item_block_index = from_int(obj.get("item_block_index"))
        item_block_title = from_union([from_none, from_str], obj.get("item_block_title"))
        item_number = from_int(obj.get("item_number"))
        return ExamStructureItem(item_block_index, item_block_title, item_number)

    def to_dict(self) -> dict:
        result: dict = {}
        result["item_block_index"] = from_int(self.item_block_index)
        if self.item_block_title is not None:
            result["item_block_title"] = from_union([from_none, from_str], self.item_block_title)
        result["item_number"] = from_int(self.item_number)
        return result


class ExamConfig:
    enhanced_extraction: Optional[bool]
    """Whether to use enhanced extraction (e.g., Mistral for PDF extraction)"""

    has_structure: Optional[bool]
    """Whether the exam has structure defined"""

    model: Optional[str]
    """AI model to use for processing (e.g., 'gpt-4o')"""

    option_markings: Optional[bool]
    """Whether option markings are enabled"""

    structure: Optional[List[ExamStructureItem]]
    """Structure definition for the exam"""

    def __init__(self, enhanced_extraction: Optional[bool], has_structure: Optional[bool], model: Optional[str], option_markings: Optional[bool], structure: Optional[List[ExamStructureItem]]) -> None:
        self.enhanced_extraction = enhanced_extraction
        self.has_structure = has_structure
        self.model = model
        self.option_markings = option_markings
        self.structure = structure

    @staticmethod
    def from_dict(obj: Any) -> 'ExamConfig':
        assert isinstance(obj, dict)
        enhanced_extraction = from_union([from_bool, from_none], obj.get("enhanced_extraction"))
        has_structure = from_union([from_bool, from_none], obj.get("hasStructure"))
        model = from_union([from_str, from_none], obj.get("model"))
        option_markings = from_union([from_bool, from_none], obj.get("option_markings"))
        structure = from_union([lambda x: from_list(ExamStructureItem.from_dict, x), from_none], obj.get("structure"))
        return ExamConfig(enhanced_extraction, has_structure, model, option_markings, structure)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.enhanced_extraction is not None:
            result["enhanced_extraction"] = from_union([from_bool, from_none], self.enhanced_extraction)
        if self.has_structure is not None:
            result["hasStructure"] = from_union([from_bool, from_none], self.has_structure)
        if self.model is not None:
            result["model"] = from_union([from_str, from_none], self.model)
        if self.option_markings is not None:
            result["option_markings"] = from_union([from_bool, from_none], self.option_markings)
        if self.structure is not None:
            result["structure"] = from_union([lambda x: from_list(lambda x: to_class(ExamStructureItem, x), x), from_none], self.structure)
        return result


class ExamStatus(Enum):
    COMPLETED = "completed"
    CREATED = "created"
    ERROR = "error"
    PROCESSING = "processing"
    READY_FOR_REVIEW = "ready_for_review"
    UPLOADED = "uploaded"


class Exam:
    """An exam captured in the QTI JSON schema model"""

    id: Optional[str]
    """Unique identifier for the exam"""

    access: Optional[List[AccessEntry]]
    """Access control list for the exam"""

    config: Optional[ExamConfig]
    course: Optional[str]
    """Course name (denormalized for list views)"""

    name: Optional[str]
    """Name of the exam"""

    school_type: Optional[str]
    """School type (e.g., 'HAVO', 'VWO')"""

    status: ExamStatus
    tijd_vak: Optional[str]
    """Time/subject type (e.g., 'voorbereidend', 'hoofdfase')"""

    user_id: str
    """ID of the user who created the exam"""

    year: Optional[int]
    """Year of the exam (denormalized for list views)"""

    def __init__(self, id: Optional[str], access: Optional[List[AccessEntry]], config: Optional[ExamConfig], course: Optional[str], name: Optional[str], school_type: Optional[str], status: ExamStatus, tijd_vak: Optional[str], user_id: str, year: Optional[int]) -> None:
        self.id = id
        self.access = access
        self.config = config
        self.course = course
        self.name = name
        self.school_type = school_type
        self.status = status
        self.tijd_vak = tijd_vak
        self.user_id = user_id
        self.year = year

    @staticmethod
    def from_dict(obj: Any) -> 'Exam':
        assert isinstance(obj, dict)
        id = from_union([from_str, from_none], obj.get("_id"))
        access = from_union([lambda x: from_list(AccessEntry.from_dict, x), from_none], obj.get("access"))
        config = from_union([ExamConfig.from_dict, from_none], obj.get("config"))
        course = from_union([from_none, from_str], obj.get("course"))
        name = from_union([from_none, from_str], obj.get("name"))
        school_type = from_union([from_none, from_str], obj.get("school_type"))
        status = ExamStatus(obj.get("status"))
        tijd_vak = from_union([from_none, from_str], obj.get("tijd_vak"))
        user_id = from_str(obj.get("userId"))
        year = from_union([from_none, from_int], obj.get("year"))
        return Exam(id, access, config, course, name, school_type, status, tijd_vak, user_id, year)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.id is not None:
            result["_id"] = from_union([from_str, from_none], self.id)
        if self.access is not None:
            result["access"] = from_union([lambda x: from_list(lambda x: to_class(AccessEntry, x), x), from_none], self.access)
        if self.config is not None:
            result["config"] = from_union([lambda x: to_class(ExamConfig, x), from_none], self.config)
        if self.course is not None:
            result["course"] = from_union([from_none, from_str], self.course)
        if self.name is not None:
            result["name"] = from_union([from_none, from_str], self.name)
        if self.school_type is not None:
            result["school_type"] = from_union([from_none, from_str], self.school_type)
        result["status"] = to_enum(ExamStatus, self.status)
        if self.tijd_vak is not None:
            result["tijd_vak"] = from_union([from_none, from_str], self.tijd_vak)
        result["userId"] = from_str(self.user_id)
        if self.year is not None:
            result["year"] = from_union([from_none, from_int], self.year)
        return result


class Group:
    """A group in the QTI JSON schema model"""

    id: Optional[str]
    """Unique identifier for the group"""

    created_by: str
    """User ID of the admin who created the group"""

    description: Optional[str]
    """Optional description of the group"""

    members: List[str]
    """Array of user IDs that are members of the group"""

    name: str
    """Name of the group (unique, searchable)"""

    def __init__(self, id: Optional[str], created_by: str, description: Optional[str], members: List[str], name: str) -> None:
        self.id = id
        self.created_by = created_by
        self.description = description
        self.members = members
        self.name = name

    @staticmethod
    def from_dict(obj: Any) -> 'Group':
        assert isinstance(obj, dict)
        id = from_union([from_str, from_none], obj.get("_id"))
        created_by = from_str(obj.get("createdBy"))
        description = from_union([from_none, from_str], obj.get("description"))
        members = from_list(from_str, obj.get("members"))
        name = from_str(obj.get("name"))
        return Group(id, created_by, description, members, name)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.id is not None:
            result["_id"] = from_union([from_str, from_none], self.id)
        result["createdBy"] = from_str(self.created_by)
        if self.description is not None:
            result["description"] = from_union([from_none, from_str], self.description)
        result["members"] = from_list(from_str, self.members)
        result["name"] = from_str(self.name)
        return result


class ItemElement:
    """An individual exam item (question) within an item block"""

    id: Optional[str]
    """Unique identifier for the exam item"""

    answer: str
    """Correct answer or answer key"""

    correction: Optional[str]
    """Correction guidelines or rubric"""

    hottext_content: Optional[str]
    """Full text content with markers for hot text interactions"""

    hottext_selections: Optional[List[HotTextSelection]]
    """Selectable text options for hot text interactions"""

    image_context: Optional[str]
    """Description of images specific to this item"""

    image_urls: Optional[List[str]]
    """URLs of images associated with this item"""

    inline_choice_text: Optional[str]
    """Text with placeholders (e.g., {0}, {1}) for inline choice interactions"""

    inline_choices: Optional[List[InlineChoice]]
    """Inline choice options for each placeholder position"""

    interaction_type: Optional[InteractionType]
    item_block_id: str
    """Reference to the parent item block"""

    item_identifier: Optional[str]
    """QTI identifier for this item (e.g., 'ITM-01')"""

    item_images: Optional[List[str]]
    """JSON stringified array of images (deprecated, use image_urls)"""

    item_number: int
    """Sequential number of this item within the exam"""

    item_type: Optional[str]
    """Type of item (deprecated, use interaction_type)"""

    match_sets: Optional[MatchSets]
    max_score: float
    """Maximum score achievable for this item"""

    order_items: Optional[List[OrderItem]]
    """Items to be ordered for order interactions"""

    question: str
    """The question text"""

    question_options: Optional[List[str]]
    """Multiple choice options (for choice interactions)"""

    response_style: Optional[ResponseStyle]
    response_type: Optional[str]
    """Response type (deprecated, use interaction_type)"""

    review_note: Optional[str]
    """Review notes for this item"""

    review_status: Optional[ReviewStatus]
    reviewed_at: Optional[str]
    """Timestamp when this item was reviewed (ISO 8601 format)"""

    reviewed_by: Optional[str]
    """ID of the user who reviewed this item"""

    stimulus: Optional[str]
    """Additional stimulus text specific to this item"""

    def __init__(self, id: Optional[str], answer: str, correction: Optional[str], hottext_content: Optional[str], hottext_selections: Optional[List[HotTextSelection]], image_context: Optional[str], image_urls: Optional[List[str]], inline_choice_text: Optional[str], inline_choices: Optional[List[InlineChoice]], interaction_type: Optional[InteractionType], item_block_id: str, item_identifier: Optional[str], item_images: Optional[List[str]], item_number: int, item_type: Optional[str], match_sets: Optional[MatchSets], max_score: float, order_items: Optional[List[OrderItem]], question: str, question_options: Optional[List[str]], response_style: Optional[ResponseStyle], response_type: Optional[str], review_note: Optional[str], review_status: Optional[ReviewStatus], reviewed_at: Optional[str], reviewed_by: Optional[str], stimulus: Optional[str]) -> None:
        self.id = id
        self.answer = answer
        self.correction = correction
        self.hottext_content = hottext_content
        self.hottext_selections = hottext_selections
        self.image_context = image_context
        self.image_urls = image_urls
        self.inline_choice_text = inline_choice_text
        self.inline_choices = inline_choices
        self.interaction_type = interaction_type
        self.item_block_id = item_block_id
        self.item_identifier = item_identifier
        self.item_images = item_images
        self.item_number = item_number
        self.item_type = item_type
        self.match_sets = match_sets
        self.max_score = max_score
        self.order_items = order_items
        self.question = question
        self.question_options = question_options
        self.response_style = response_style
        self.response_type = response_type
        self.review_note = review_note
        self.review_status = review_status
        self.reviewed_at = reviewed_at
        self.reviewed_by = reviewed_by
        self.stimulus = stimulus

    @staticmethod
    def from_dict(obj: Any) -> 'ItemElement':
        assert isinstance(obj, dict)
        id = from_union([from_str, from_none], obj.get("_id"))
        answer = from_str(obj.get("answer"))
        correction = from_union([from_none, from_str], obj.get("correction"))
        hottext_content = from_union([from_none, from_str], obj.get("hottext_content"))
        hottext_selections = from_union([lambda x: from_list(HotTextSelection.from_dict, x), from_none], obj.get("hottext_selections"))
        image_context = from_union([from_none, from_str], obj.get("image_context"))
        image_urls = from_union([lambda x: from_list(from_str, x), from_none], obj.get("image_urls"))
        inline_choice_text = from_union([from_none, from_str], obj.get("inline_choice_text"))
        inline_choices = from_union([lambda x: from_list(InlineChoice.from_dict, x), from_none], obj.get("inline_choices"))
        interaction_type = from_union([InteractionType, from_none], obj.get("interaction_type"))
        item_block_id = from_str(obj.get("item_block_id"))
        item_identifier = from_union([from_none, from_str], obj.get("item_identifier"))
        item_images = from_union([lambda x: from_list(from_str, x), from_none], obj.get("item_images"))
        item_number = from_int(obj.get("item_number"))
        item_type = from_union([from_none, from_str], obj.get("item_type"))
        match_sets = from_union([MatchSets.from_dict, from_none], obj.get("match_sets"))
        max_score = from_float(obj.get("max_score"))
        order_items = from_union([lambda x: from_list(OrderItem.from_dict, x), from_none], obj.get("order_items"))
        question = from_str(obj.get("question"))
        question_options = from_union([lambda x: from_list(from_str, x), from_none], obj.get("question_options"))
        response_style = from_union([ResponseStyle, from_none], obj.get("response_style"))
        response_type = from_union([from_none, from_str], obj.get("response_type"))
        review_note = from_union([from_none, from_str], obj.get("review_note"))
        review_status = from_union([ReviewStatus, from_none], obj.get("review_status"))
        reviewed_at = from_union([from_none, from_str], obj.get("reviewed_at"))
        reviewed_by = from_union([from_none, from_str], obj.get("reviewed_by"))
        stimulus = from_union([from_none, from_str], obj.get("stimulus"))
        return ItemElement(id, answer, correction, hottext_content, hottext_selections, image_context, image_urls, inline_choice_text, inline_choices, interaction_type, item_block_id, item_identifier, item_images, item_number, item_type, match_sets, max_score, order_items, question, question_options, response_style, response_type, review_note, review_status, reviewed_at, reviewed_by, stimulus)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.id is not None:
            result["_id"] = from_union([from_str, from_none], self.id)
        result["answer"] = from_str(self.answer)
        if self.correction is not None:
            result["correction"] = from_union([from_none, from_str], self.correction)
        if self.hottext_content is not None:
            result["hottext_content"] = from_union([from_none, from_str], self.hottext_content)
        if self.hottext_selections is not None:
            result["hottext_selections"] = from_union([lambda x: from_list(lambda x: to_class(HotTextSelection, x), x), from_none], self.hottext_selections)
        if self.image_context is not None:
            result["image_context"] = from_union([from_none, from_str], self.image_context)
        if self.image_urls is not None:
            result["image_urls"] = from_union([lambda x: from_list(from_str, x), from_none], self.image_urls)
        if self.inline_choice_text is not None:
            result["inline_choice_text"] = from_union([from_none, from_str], self.inline_choice_text)
        if self.inline_choices is not None:
            result["inline_choices"] = from_union([lambda x: from_list(lambda x: to_class(InlineChoice, x), x), from_none], self.inline_choices)
        if self.interaction_type is not None:
            result["interaction_type"] = from_union([lambda x: to_enum(InteractionType, x), from_none], self.interaction_type)
        result["item_block_id"] = from_str(self.item_block_id)
        if self.item_identifier is not None:
            result["item_identifier"] = from_union([from_none, from_str], self.item_identifier)
        if self.item_images is not None:
            result["item_images"] = from_union([lambda x: from_list(from_str, x), from_none], self.item_images)
        result["item_number"] = from_int(self.item_number)
        if self.item_type is not None:
            result["item_type"] = from_union([from_none, from_str], self.item_type)
        if self.match_sets is not None:
            result["match_sets"] = from_union([lambda x: to_class(MatchSets, x), from_none], self.match_sets)
        result["max_score"] = to_float(self.max_score)
        if self.order_items is not None:
            result["order_items"] = from_union([lambda x: from_list(lambda x: to_class(OrderItem, x), x), from_none], self.order_items)
        result["question"] = from_str(self.question)
        if self.question_options is not None:
            result["question_options"] = from_union([lambda x: from_list(from_str, x), from_none], self.question_options)
        if self.response_style is not None:
            result["response_style"] = from_union([lambda x: to_enum(ResponseStyle, x), from_none], self.response_style)
        if self.response_type is not None:
            result["response_type"] = from_union([from_none, from_str], self.response_type)
        if self.review_note is not None:
            result["review_note"] = from_union([from_none, from_str], self.review_note)
        if self.review_status is not None:
            result["review_status"] = from_union([lambda x: to_enum(ReviewStatus, x), from_none], self.review_status)
        if self.reviewed_at is not None:
            result["reviewed_at"] = from_union([from_none, from_str], self.reviewed_at)
        if self.reviewed_by is not None:
            result["reviewed_by"] = from_union([from_none, from_str], self.reviewed_by)
        if self.stimulus is not None:
            result["stimulus"] = from_union([from_none, from_str], self.stimulus)
        return result


class ItemBlock:
    """A block of items within an exam"""

    id: Optional[str]
    """Unique identifier for the item block"""

    exam_id: str
    """Reference to the parent exam"""

    image_context: Optional[str]
    """Description of images associated with this block"""

    image_urls: Optional[List[str]]
    """URLs of images associated with this item block"""

    items: Optional[List[ItemElement]]
    """Items contained within this block (populated in queries)"""

    order_index: int
    """Order index to maintain sequence of blocks within an exam"""

    stimulus: Optional[str]
    """Stimulus text providing context for items in this block"""

    title: Optional[str]
    """Title of the item block"""

    def __init__(self, id: Optional[str], exam_id: str, image_context: Optional[str], image_urls: Optional[List[str]], items: Optional[List[ItemElement]], order_index: int, stimulus: Optional[str], title: Optional[str]) -> None:
        self.id = id
        self.exam_id = exam_id
        self.image_context = image_context
        self.image_urls = image_urls
        self.items = items
        self.order_index = order_index
        self.stimulus = stimulus
        self.title = title

    @staticmethod
    def from_dict(obj: Any) -> 'ItemBlock':
        assert isinstance(obj, dict)
        id = from_union([from_str, from_none], obj.get("_id"))
        exam_id = from_str(obj.get("exam_id"))
        image_context = from_union([from_none, from_str], obj.get("image_context"))
        image_urls = from_union([lambda x: from_list(from_str, x), from_none], obj.get("image_urls"))
        items = from_union([lambda x: from_list(ItemElement.from_dict, x), from_none], obj.get("items"))
        order_index = from_int(obj.get("order_index"))
        stimulus = from_union([from_none, from_str], obj.get("stimulus"))
        title = from_union([from_none, from_str], obj.get("title"))
        return ItemBlock(id, exam_id, image_context, image_urls, items, order_index, stimulus, title)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.id is not None:
            result["_id"] = from_union([from_str, from_none], self.id)
        result["exam_id"] = from_str(self.exam_id)
        if self.image_context is not None:
            result["image_context"] = from_union([from_none, from_str], self.image_context)
        if self.image_urls is not None:
            result["image_urls"] = from_union([lambda x: from_list(from_str, x), from_none], self.image_urls)
        if self.items is not None:
            result["items"] = from_union([lambda x: from_list(lambda x: to_class(ItemElement, x), x), from_none], self.items)
        result["order_index"] = from_int(self.order_index)
        if self.stimulus is not None:
            result["stimulus"] = from_union([from_none, from_str], self.stimulus)
        if self.title is not None:
            result["title"] = from_union([from_none, from_str], self.title)
        return result


class UserRole(Enum):
    ADMIN = "admin"
    USER = "user"
    VIEWER = "viewer"


class User:
    """A user in the QTI JSON schema model"""

    id: Optional[str]
    """Unique identifier for the user record"""

    email: Optional[str]
    """Email address of the user"""

    role: UserRole
    shared_exam_ids: List[str]
    """Array of exam IDs shared with this user (deprecated - use access field on exams)"""

    user_id: str
    """User ID from authentication system"""

    username: Optional[str]
    """Username for the user"""

    def __init__(self, id: Optional[str], email: Optional[str], role: UserRole, shared_exam_ids: List[str], user_id: str, username: Optional[str]) -> None:
        self.id = id
        self.email = email
        self.role = role
        self.shared_exam_ids = shared_exam_ids
        self.user_id = user_id
        self.username = username

    @staticmethod
    def from_dict(obj: Any) -> 'User':
        assert isinstance(obj, dict)
        id = from_union([from_str, from_none], obj.get("_id"))
        email = from_union([from_none, from_str], obj.get("email"))
        role = UserRole(obj.get("role"))
        shared_exam_ids = from_list(from_str, obj.get("sharedExamIds"))
        user_id = from_str(obj.get("userId"))
        username = from_union([from_none, from_str], obj.get("username"))
        return User(id, email, role, shared_exam_ids, user_id, username)

    def to_dict(self) -> dict:
        result: dict = {}
        if self.id is not None:
            result["_id"] = from_union([from_str, from_none], self.id)
        if self.email is not None:
            result["email"] = from_union([from_none, from_str], self.email)
        result["role"] = to_enum(UserRole, self.role)
        result["sharedExamIds"] = from_list(from_str, self.shared_exam_ids)
        result["userId"] = from_str(self.user_id)
        if self.username is not None:
            result["username"] = from_union([from_none, from_str], self.username)
        return result


def exam_file_from_dict(s: Any) -> ExamFile:
    return ExamFile.from_dict(s)


def exam_file_to_dict(x: ExamFile) -> Any:
    return to_class(ExamFile, x)


def exam_item_from_dict(s: Any) -> ExamItem:
    return ExamItem.from_dict(s)


def exam_item_to_dict(x: ExamItem) -> Any:
    return to_class(ExamItem, x)


def exam_object_from_dict(s: Any) -> ExamObject:
    return ExamObject.from_dict(s)


def exam_object_to_dict(x: ExamObject) -> Any:
    return to_class(ExamObject, x)


def exam_from_dict(s: Any) -> Exam:
    return Exam.from_dict(s)


def exam_to_dict(x: Exam) -> Any:
    return to_class(Exam, x)


def group_from_dict(s: Any) -> Group:
    return Group.from_dict(s)


def group_to_dict(x: Group) -> Any:
    return to_class(Group, x)


def item_block_from_dict(s: Any) -> ItemBlock:
    return ItemBlock.from_dict(s)


def item_block_to_dict(x: ItemBlock) -> Any:
    return to_class(ItemBlock, x)


def user_from_dict(s: Any) -> User:
    return User.from_dict(s)


def user_to_dict(x: User) -> Any:
    return to_class(User, x)
