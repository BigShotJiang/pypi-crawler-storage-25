from .IndexTokenBurn import IndexTokenBurn
