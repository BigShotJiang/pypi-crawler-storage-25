#!/usr/bin/env python3
"""Secrets encrypted storage module."""

import sqlite3
import os
import sys
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
import base64
import hashlib

try:
    from cryptography.fernet import Fernet
except ImportError as e:
    print(f"Error: cryptography library required. Install with: pip install cryptography. Error: {e}")
    sys.exit(1)

try:
    from .config_provider import get_provider
except ImportError:
    from config_provider import get_provider

ALLOWED_TABLES = {'secrets'}


class SecretsDB:
    """Encrypted secrets storage using cryptography library."""
    
    def __init__(self, db_path: str = None):
        if db_path:
            self.db_path = Path(db_path)
        else:
            provider = get_provider()
            self.db_path = Path(provider.get_data_dir()) / "secrets.db"
        self._ensure_dir()
        self._init_db()
        self._init_encryption()
    
    def _ensure_dir(self):
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
    
    def _get_master_key(self) -> bytes:
        """Get or create master encryption key."""
        key_file = self.db_path.parent / ".secrets.key"
        
        if key_file.exists():
            with open(key_file, 'rb') as f:
                return f.read()
        
        # Generate new key
        key = Fernet.generate_key()
        key_file.write_bytes(key)
        os.chmod(key_file, 0o600)
        return key
    
    def _init_encryption(self):
        """Initialize Fernet cipher with master key."""
        master_key = self._get_master_key()
        self.cipher = Fernet(master_key)
    
    def _init_db(self):
        """Initialize secrets table."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS secrets (
                id TEXT PRIMARY KEY,
                key TEXT UNIQUE NOT NULL,
                encrypted_value TEXT NOT NULL,
                created_at TEXT,
                updated_at TEXT
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_secrets_key ON secrets(key)")
        
        conn.commit()
        conn.close()
    
    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn
    
    def _encrypt(self, value: str) -> str:
        """Encrypt a value."""
        return self.cipher.encrypt(value.encode()).decode()
    
    def _decrypt(self, encrypted_value: str) -> str:
        """Decrypt a value."""
        return self.cipher.decrypt(encrypted_value.encode()).decode()
    
    def set(self, key: str, value: str) -> bool:
        """Set a secret value."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        encrypted = self._encrypt(value)
        now = datetime.now().isoformat()
        
        # Check if exists
        cursor.execute("SELECT id FROM secrets WHERE key = ?", (key,))
        exists = cursor.fetchone()
        
        if exists:
            cursor.execute(
                "UPDATE secrets SET encrypted_value = ?, updated_at = ? WHERE key = ?",
                (encrypted, now, key)
            )
        else:
            secret_id = f"sec-{key}-{datetime.now().strftime('%Y%m%d%H%M%S')}"
            cursor.execute(
                "INSERT INTO secrets (id, key, encrypted_value, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (secret_id, key, encrypted, now, now)
            )
        
        conn.commit()
        conn.close()
        return True
    
    def get(self, key: str) -> Optional[str]:
        """Get a secret value."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT encrypted_value FROM secrets WHERE key = ?", (key,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            return self._decrypt(row['encrypted_value'])
        return None
    
    def delete(self, key: str) -> bool:
        """Delete a secret."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM secrets WHERE key = ?", (key,))
        conn.commit()
        conn.close()
        
        return cursor.rowcount > 0
    
    def list(self) -> List[Dict[str, str]]:
        """List all secrets (without values)."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT key, created_at, updated_at FROM secrets ORDER BY key")
        rows = cursor.fetchall()
        conn.close()
        
        return [
            {
                "key": row['key'],
                "created_at": row['created_at'],
                "updated_at": row['updated_at']
            }
            for row in rows
        ]
    
    def exists(self, key: str) -> bool:
        """Check if a secret exists."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT 1 FROM secrets WHERE key = ?", (key,))
        exists = cursor.fetchone() is not None
        conn.close()
        
        return exists


def get_secrets_db() -> SecretsDB:
    """Get SecretsDB instance."""
    provider = get_provider()
    return SecretsDB(db_path=str(Path(provider.get_data_dir()) / "secrets.db"))
