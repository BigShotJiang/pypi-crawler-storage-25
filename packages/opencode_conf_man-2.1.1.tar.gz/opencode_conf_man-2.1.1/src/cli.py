#!/usr/bin/env python3
"""conf-man CLI entry point."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src import main

if __name__ == "__main__":
    main()
