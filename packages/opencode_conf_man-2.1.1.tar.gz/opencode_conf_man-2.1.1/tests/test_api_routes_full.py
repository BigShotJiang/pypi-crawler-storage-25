"""
src/api/routes/__init__.py 模块完整测试
"""

import pytest
import sys
from pathlib import Path
from fastapi.testclient import TestClient
from datetime import datetime, timedelta

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.api.routes import (
    router, validate_version_format, guess_project_from_version, 
    generate_id, VERSION_PROJECT_MAP
)


class TestRouter:
    """路由测试"""

    def test_router_exists(self):
        """测试路由存在"""
        assert router is not None


class TestVersionValidation:
    """版本验证函数测试"""

    def test_validate_valid_version(self):
        """测试验证有效版本"""
        is_valid, msg = validate_version_format("1.0.0")
        assert is_valid is True
        assert msg == ""

    def test_validate_invalid_version(self):
        """测试验证无效版本"""
        is_valid, msg = validate_version_format("invalid")
        assert is_valid is False
        assert "格式错误" in msg

    def test_validate_version_without_patch(self):
        """测试验证缺少补丁版本"""
        is_valid, msg = validate_version_format("1.0")
        assert is_valid is False


class TestGuessProject:
    """项目猜测测试"""

    def test_guess_conf_man(self):
        """测试猜测conf-man项目"""
        assert guess_project_from_version("1.0.0") == "conf-man"

    def test_guess_oc_collab(self):
        """测试猜测oc-collab项目"""
        assert guess_project_from_version("2.0.0") == "oc-collab"

    def test_guess_pm_agent(self):
        """测试猜测pm-agent项目"""
        assert guess_project_from_version("3.0.0") == "pm-agent"

    def test_guess_test_agent(self):
        """测试猜测test-agent项目"""
        assert guess_project_from_version("4.0.0") == "test-agent"

    def test_guess_unknown(self):
        """测试猜测未知项目"""
        assert guess_project_from_version("9.0.0") is None


class TestGenerateId:
    """ID生成测试"""

    def test_generate_id_with_prefix(self):
        """测试带前缀生成ID"""
        id1 = generate_id("test")
        assert id1.startswith("test-")
        assert len(id1) > 10

    def test_generate_id_unique(self):
        """测试生成的ID唯一"""
        id1 = generate_id("test")
        id2 = generate_id("test")
        assert id1 != id2


class TestVersionProjectMap:
    """版本项目映射测试"""

    def test_map_contains_conf_man(self):
        """测试映射包含conf-man"""
        assert "1." in VERSION_PROJECT_MAP

    def test_map_contains_oc_collab(self):
        """测试映射包含oc-collab"""
        assert "2." in VERSION_PROJECT_MAP


class TestModels:
    """数据模型测试"""

    def test_project_create_model(self):
        """测试ProjectCreate模型"""
        from src.api.routes import ProjectCreate
        p = ProjectCreate(name="test-project")
        assert p.name == "test-project"

    def test_version_create_model(self):
        """测试VersionCreate模型"""
        from src.api.routes import VersionCreate
        v = VersionCreate(version="1.0.0", project_id="test")
        assert v.version == "1.0.0"
        assert v.project_id == "test"

    def test_dependency_create_model(self):
        """测试DependencyCreate模型"""
        from src.api.routes import DependencyCreate
        d = DependencyCreate(name="pytest")
        assert d.name == "pytest"


class TestWebhookModels:
    """Webhook模型测试"""

    def test_webhook_component(self):
        """测试WebhookComponent模型"""
        from src.api.routes import WebhookComponent
        c = WebhookComponent(name="test", version="1.0.0")
        assert c.name == "test"
        assert c.version == "1.0.0"

    def test_webhook_release_request(self):
        """测试WebhookReleaseRequest模型"""
        from src.api.routes import WebhookReleaseRequest
        req = WebhookReleaseRequest(
            version="1.0.0",
            components=[]
        )
        assert req.version == "1.0.0"

    def test_webhook_subscribe_request(self):
        """测试WebhookSubscribeRequest模型"""
        from src.api.routes import WebhookSubscribeRequest
        req = WebhookSubscribeRequest(
            url="http://test.com",
            events=["version.registered"]
        )
        assert req.url == "http://test.com"

    def test_diff_request(self):
        """测试DiffRequest模型"""
        from src.api.routes import DiffRequest
        req = DiffRequest(version_a="1.0.0", version_b="2.0.0")
        assert req.version_a == "1.0.0"
        assert req.version_b == "2.0.0"

    def test_tag_request(self):
        """测试TagRequest模型"""
        from src.api.routes import TagRequest
        req = TagRequest(name="stable")
        assert req.name == "stable"


class TestExportImport:
    """导入导出模型测试"""

    def test_export_request(self):
        """测试ExportRequest模型"""
        from src.api.routes import ExportRequest
        req = ExportRequest(version_id="test-1", format="json")
        assert req.version_id == "test-1"
        assert req.format == "json"


class TestAPIKeyModels:
    """API Key模型测试"""

    def test_api_key_create_request(self):
        """测试APIKeyCreateRequest模型"""
        from src.api.routes import APIKeyCreateRequest
        req = APIKeyCreateRequest(name="test-key")
        assert req.name == "test-key"

    def test_api_key_create_with_expiry(self):
        """测试APIKeyCreateRequest模型带过期时间"""
        from src.api.routes import APIKeyCreateRequest
        req = APIKeyCreateRequest(name="test-key", expires_days=30)
        assert req.name == "test-key"
        assert req.expires_days == 30


class TestPyPITokenModels:
    """PyPI Token模型测试"""

    def test_pypi_token_create_request(self):
        """测试PyPITokenCreateRequest模型"""
        from src.api.routes import PyPITokenCreateRequest
        req = PyPITokenCreateRequest(name="pypi-token", token="test-token")
        assert req.name == "pypi-token"
        assert req.token == "test-token"

    def test_pypi_token_rotate_request(self):
        """测试PyPITokenRotateRequest模型"""
        from src.api.routes import PyPITokenRotateRequest
        req = PyPITokenRotateRequest(new_token="new-token")
        assert req.new_token == "new-token"


class TestSecretsModels:
    """Secrets模型测试"""

    def test_secret_set_request(self):
        """测试SecretSetRequest模型"""
        from src.api.routes import SecretSetRequest
        req = SecretSetRequest(key="test-key", value="test-value")
        assert req.key == "test-key"
        assert req.value == "test-value"


class TestBroadcastEvent:
    """事件广播测试"""

    def test_broadcast_event_exists(self):
        """测试broadcast_event函数存在"""
        from src.api.routes import broadcast_event
        assert callable(broadcast_event)

    def test_get_db_function(self):
        """测试get_db函数"""
        from src.api.routes import get_db
        assert callable(get_db)

    def test_load_api_keys_function(self):
        """测试load_api_keys函数"""
        from src.api.routes import load_api_keys
        assert callable(load_api_keys)

    def test_verify_api_key_function(self):
        """测试verify_api_key函数"""
        from src.api.routes import verify_api_key
        assert callable(verify_api_key)


class TestVersionRoutesModule:
    """version_routes模块测试"""

    def test_version_routes_db_path(self):
        """测试版本数据库路径"""
        from src.api import version_routes
        assert hasattr(version_routes, 'VERSIONS_DB_PATH')

    def test_version_routes_get_db(self):
        """测试get_db函数"""
        from src.api.version_routes import get_db
        conn = get_db()
        assert conn is not None
        conn.close()

    def test_version_routes_init_db(self):
        """测试init_db函数"""
        from src.api.version_routes import init_db
        init_db()


class TestRouteFunctions:
    """路由辅助函数测试"""

    def test_validate_version_with_v_prefix(self):
        """测试验证带v前缀的版本"""
        is_valid, msg = validate_version_format("v1.0.0")
        assert is_valid is False

    def test_validate_version_with_suffix(self):
        """测试验证带后缀的版本"""
        is_valid, msg = validate_version_format("1.0.0-beta")
        assert is_valid is False

    def test_guess_project_edge_cases(self):
        """测试项目猜测边界情况"""
        assert guess_project_from_version("9.9.9") is None
        assert guess_project_from_version("") is None

    def test_generate_id_different_prefixes(self):
        """测试不同前缀的ID生成"""
        id1 = generate_id("proj")
        id2 = generate_id("ver")
        id3 = generate_id("dep")
        assert id1.startswith("proj-")
        assert id2.startswith("ver-")
        assert id3.startswith("dep-")


class TestWebhookSubscribeRequest:
    """Webhook订阅请求测试"""

    def test_subscribe_with_valid_events(self):
        """测试有效事件的订阅"""
        from src.api.routes import WebhookSubscribeRequest
        req = WebhookSubscribeRequest(
            url="http://example.com/webhook",
            events=["version.registered", "version.released"]
        )
        assert len(req.events) == 2

    def test_subscribe_with_invalid_event(self):
        """测试无效事件的订阅请求"""
        from src.api.routes import WebhookSubscribeRequest
        req = WebhookSubscribeRequest(
            url="http://example.com/webhook",
            events=["invalid.event"]
        )
        assert req.events[0] == "invalid.event"
