"""
src/cli.py 模块测试
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


class TestCliModule:
    """cli模块测试"""

    def test_cli_module_import(self):
        """测试cli模块可以导入"""
        from src import cli
        assert cli is not None

    def test_main_import(self):
        """测试main可以导入"""
        from src import main
        assert main is not None

    def test_cli_is_click_group(self):
        """测试cli是click组"""
        from click import Group
        from src import cli
        assert isinstance(cli, Group)

    def test_cli_routes(self):
        """测试CLI有路由"""
        from src import cli
        # cli应该有多个命令
        commands = list(cli.commands.keys())
        assert len(commands) > 0

    def test_main_runs(self):
        """测试main可以运行"""
        from src import main
        assert callable(main)
