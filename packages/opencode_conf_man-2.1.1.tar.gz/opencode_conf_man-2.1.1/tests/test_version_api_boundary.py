"""
版本管理API测试用例 - 边界条件补充

需求关联:
- VER-002: list_versions (分页, 状态过滤)
- VER-001: register_version (异常输入)

需求文档: HQ/docs/05-tasks/TASK_conf_man_version_api_implement.md
版本: v2.0.0
"""

import pytest
import sys
import os
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.api.serve import create_app, init_db


@pytest.fixture
def client():
    """创建测试客户端"""
    app = create_app()
    return TestClient(app)


@pytest.fixture(autouse=True)
def clean_versions_db():
    """每个测试前清理版本数据库"""
    import os
    db_path = os.environ.get("VERSIONS_DB_PATH", "/app/state/versions.db")
    if os.path.exists(db_path):
        os.remove(db_path)
    init_db()
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


class TestVersionAPIBoundary:
    """边界条件测试 - 响应评审意见"""

    def test_pagination(self, client):
        """TC-v2-E011: 测试分页"""
        import time
        ts = int(time.time())
        for i in range(5):
            client.post(
                "/api/v1/versions",
                json={"version": f"8.{i}.{ts}", "project_id": "conf-man"}
            )
        
        response = client.get("/api/v1/versions?limit=2")
        assert response.status_code == 200

    def test_empty_version_string(self, client):
        """TC-v2-E013: 测试空版本号"""
        response = client.post(
            "/api/v1/versions",
            json={"version": "", "project_id": "test-agent"}
        )
        assert response.status_code == 422

    def test_invalid_version_format(self, client):
        """TC-v2-E014: 测试无效版本号格式"""
        response = client.post(
            "/api/v1/versions",
            json={"version": "not-a-version", "project_id": "test-agent"}
        )
        assert response.status_code in [200, 422]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
