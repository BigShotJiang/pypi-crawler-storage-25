import pytest
import sys
from pathlib import Path
import os
import json
from unittest.mock import patch, AsyncMock, MagicMock
from datetime import datetime

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from src.storage import Database


@pytest.fixture
def db():
    db_path = os.path.join(os.getcwd(), "state", "test_webhook_v131.db")
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    if os.path.exists(db_path):
        os.remove(db_path)
    
    test_db = Database(db_path)
    yield test_db
    
    if os.path.exists(db_path):
        os.remove(db_path)


@pytest.fixture
def api_client():
    from fastapi.testclient import TestClient
    from src.api import app
    return TestClient(app)


class TestWebhookSubscription:
    """Test webhook subscription API"""

    def test_subscribe_success(self, db):
        """Test successful webhook subscription"""
        from src.api.routes import WebhookSubscribeRequest
        
        request = WebhookSubscribeRequest(
            url="http://example.com/callback",
            events=["version.registered", "version.released"]
        )
        
        sub_id = f"sub-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": sub_id,
            "url": request.url,
            "events": json.dumps(request.events),
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        subs = db.list("webhook_subscribers")
        assert len(subs) == 1
        assert subs[0]["url"] == "http://example.com/callback"

    def test_subscribe_multiple_events(self, db):
        """Test subscription with multiple events"""
        from src.api.routes import WebhookSubscribeRequest
        
        request = WebhookSubscribeRequest(
            url="http://pm-agent:8000/api/callback",
            events=["version.registered", "version.released", "version.deprecated"]
        )
        
        sub_id = f"sub-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": sub_id,
            "url": request.url,
            "events": json.dumps(request.events),
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        subs = db.list("webhook_subscribers")
        events = json.loads(subs[0]["events"])
        assert len(events) == 3
        assert "version.registered" in events

    def test_unsubscribe(self, db):
        """Test unsubscribe"""
        sub_id = "sub-test-001"
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": sub_id,
            "url": "http://example.com/callback",
            "events": '["version.registered"]',
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        db.update("webhook_subscribers", sub_id, {"active": 0})
        
        subs = db.list("webhook_subscribers")
        assert subs[0]["active"] == 0

    def test_list_active_subscribers(self, db):
        """Test listing active subscribers"""
        now = datetime.now().isoformat()
        
        for i in range(3):
            db.insert("webhook_subscribers", {
                "id": f"sub-test-{i}",
                "url": f"http://example{i}.com/callback",
                "events": '["version.registered"]',
                "active": 1,
                "created_at": now,
                "updated_at": now
            })
        
        db.insert("webhook_subscribers", {
            "id": "sub-inactive",
            "url": "http://inactive.com/callback",
            "events": '["version.registered"]',
            "active": 0,
            "created_at": now,
            "updated_at": now
        })
        
        subs = db.list("webhook_subscribers", filters={"active": 1})
        assert len(subs) == 3


class TestWebhookLogs:
    """Test webhook logs"""

    def test_log_callback(self, db):
        """Test logging webhook callback"""
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": "sub-001",
            "url": "http://example.com/callback",
            "events": '["version.registered"]',
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("webhook_logs", {
            "id": "log-001",
            "subscriber_id": "sub-001",
            "event": "version.registered",
            "url": "http://example.com/callback",
            "payload": '{"version": "1.3.1"}',
            "status_code": 200,
            "response": '{"status": "ok"}',
            "created_at": now
        })
        
        logs = db.list("webhook_logs")
        assert len(logs) == 1
        assert logs[0]["status_code"] == 200

    def test_log_failed_callback(self, db):
        """Test logging failed callback"""
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": "sub-001",
            "url": "http://example.com/callback",
            "events": '["version.released"]',
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("webhook_logs", {
            "id": "log-002",
            "subscriber_id": "sub-001",
            "event": "version.released",
            "url": "http://example.com/callback",
            "payload": '{"version": "1.3.1"}',
            "status_code": 500,
            "response": "Internal Server Error",
            "created_at": now
        })
        
        logs = db.list("webhook_logs", filters={"status_code": 500})
        assert len(logs) == 1

    def test_log_by_subscriber(self, db):
        """Test filtering logs by subscriber"""
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": "sub-001",
            "url": "http://example.com/callback",
            "events": '["version.registered"]',
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("webhook_logs", {
            "id": "log-003",
            "subscriber_id": "sub-001",
            "event": "version.registered",
            "url": "http://example.com/callback",
            "payload": "{}",
            "status_code": 200,
            "response": "{}",
            "created_at": now
        })
        
        logs = db.list("webhook_logs", filters={"subscriber_id": "sub-001"})
        assert len(logs) == 1


class TestVersionRelease:
    """Test version release API"""

    def test_create_version(self, db):
        """Test creating version"""
        version_id = "ver-1.3.1"
        now = datetime.now().isoformat()
        
        db.insert("versions", {
            "id": version_id,
            "version": "1.3.1",
            "status": "draft",
            "registered_at": now,
            "git_commit_hash": "abc123",
            "project_id": "test-project",
            "manifest": '{"components": []}',
            "created_at": now,
            "updated_at": now
        })
        
        versions = db.list("versions", filters={"version": "1.3.1"})
        assert len(versions) == 1
        assert versions[0]["status"] == "draft"

    def test_release_version(self, db):
        """Test releasing version"""
        version_id = "ver-1.3.1"
        now = datetime.now().isoformat()
        
        db.insert("versions", {
            "id": version_id,
            "version": "1.3.1",
            "status": "draft",
            "registered_at": now,
            "git_commit_hash": "abc123",
            "project_id": "test-project",
            "manifest": '{"components": []}',
            "created_at": now,
            "updated_at": now
        })
        
        db.update("versions", version_id, {
            "status": "released",
            "released_at": now,
            "updated_at": now
        })
        
        version = db.get_by_id("versions", version_id)
        assert version["status"] == "released"
        assert version["released_at"] == now

    def test_deprecate_version(self, db):
        """Test deprecating version"""
        version_id = "ver-1.3.0"
        now = datetime.now().isoformat()
        
        db.insert("versions", {
            "id": version_id,
            "version": "1.3.0",
            "status": "released",
            "registered_at": now,
            "released_at": now,
            "git_commit_hash": "abc123",
            "project_id": "test-project",
            "manifest": '{"components": []}',
            "created_at": now,
            "updated_at": now
        })
        
        db.update("versions", version_id, {
            "status": "deprecated",
            "updated_at": now
        })
        
        version = db.get_by_id("versions", version_id)
        assert version["status"] == "deprecated"


class TestBroadcastEvents:
    """Test broadcast events"""

    def test_event_filtering(self, db):
        """Test that events are filtered correctly"""
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": "sub-003",
            "url": "http://example.com/callback",
            "events": '["version.registered"]',
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        subs = db.list("webhook_subscribers", filters={"active": 1})
        
        for sub in subs:
            events = json.loads(sub["events"])
            assert "version.registered" in events
    
    def test_subscriber_insert_and_list(self, db):
        """Test inserting and listing webhook subscribers"""
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": "sub-test-001",
            "url": "http://test.com/webhook",
            "events": '["version.registered", "version.released"]',
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        subs = db.list("webhook_subscribers")
        assert len(subs) == 1
        assert subs[0]["url"] == "http://test.com/webhook"
    
    def test_webhook_log_insert(self, db):
        """Test inserting webhook logs"""
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": "sub-001",
            "url": "http://example.com/callback",
            "events": '["version.registered"]',
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("webhook_logs", {
            "id": "log-test-001",
            "subscriber_id": "sub-001",
            "event": "version.registered",
            "url": "http://example.com/callback",
            "payload": '{"version": "1.3.1"}',
            "status_code": 200,
            "response": '{"status": "ok"}',
            "created_at": now
        })
        
        logs = db.list("webhook_logs")
        assert len(logs) == 1
        assert logs[0]["status_code"] == 200
        """Test that events are filtered correctly"""
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": "sub-003",
            "url": "http://example.com/callback",
            "events": '["version.registered"]',
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        subs = db.list("webhook_subscribers", filters={"active": 1})
        
        for sub in subs:
            events = json.loads(sub["events"])
            assert "version.registered" in events


class TestWebhookModels:
    """Test webhook Pydantic models"""

    def test_subscribe_request_model(self):
        """Test WebhookSubscribeRequest model"""
        from src.api.routes import WebhookSubscribeRequest
        
        request = WebhookSubscribeRequest(
            url="http://test.com/webhook",
            events=["version.registered"]
        )
        
        assert request.url == "http://test.com/webhook"
        assert "version.registered" in request.events

    def test_subscribe_request_default_events(self):
        """Test WebhookSubscribeRequest with events"""
        from src.api.routes import WebhookSubscribeRequest
        
        request = WebhookSubscribeRequest(
            url="http://test.com/webhook",
            events=["version.registered", "version.released"]
        )
        
        assert request.url == "http://test.com/webhook"
        assert len(request.events) == 2

    def test_webhook_release_request_model(self):
        """Test WebhookReleaseRequest model"""
        from src.api.routes import WebhookReleaseRequest, WebhookComponent
        
        request = WebhookReleaseRequest(
            version="1.3.1",
            components=[
                WebhookComponent(name="conf-man", version="1.3.1")
            ]
        )
        
        assert request.version == "1.3.1"
        assert len(request.components) == 1

    def test_webhook_component_model(self):
        """Test WebhookComponent model"""
        from src.api.routes import WebhookComponent
        
        component = WebhookComponent(
            name="oc-collab",
            version="2.5.0"
        )
        
        assert component.name == "oc-collab"
        assert component.version == "2.5.0"


class TestWebhookSubscribeRequest:
    """Test WebhookSubscribeRequest model exists and works"""
    
    def test_model_import(self):
        """Test WebhookSubscribeRequest can be imported"""
        try:
            from src.api.routes import WebhookSubscribeRequest
            assert WebhookSubscribeRequest is not None
        except ImportError:
            pass
