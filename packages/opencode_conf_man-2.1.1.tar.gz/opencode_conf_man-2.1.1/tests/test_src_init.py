"""
src/__init__.py 模块测试 - CLI命令
"""

import pytest
import sys
import os
import json
import tempfile
from pathlib import Path
from click.testing import CliRunner

sys.path.insert(0, str(Path(__file__).parent.parent))

from src import cli, get_db, ensure_init, VERSION


class TestCLI:
    """CLI命令测试"""

    def test_cli_version(self):
        """测试CLI版本"""
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert VERSION in result.output

    def test_cli_help(self):
        """测试CLI帮助"""
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0


class TestEnsureInit:
    """ensure_init函数测试"""

    def test_ensure_init(self, tmp_path):
        """测试初始化"""
        # 使用临时目录
        old_env = os.environ.get("CONF_MAN_DATA_DIR")
        os.environ["CONF_MAN_DATA_DIR"] = str(tmp_path)
        try:
            ensure_init()
        finally:
            if old_env:
                os.environ["CONF_MAN_DATA_DIR"] = old_env
            else:
                os.environ.pop("CONF_MAN_DATA_DIR", None)


class TestInitCommand:
    """init命令测试"""

    def test_init_command(self, tmp_path):
        """测试init命令"""
        runner = CliRunner()
        os.environ["CONF_MAN_DATA_DIR"] = str(tmp_path)
        try:
            result = runner.invoke(cli, ["init"])
            assert result.exit_code == 0
            assert "conf-man v" in result.output
            assert "已初始化" in result.output
        finally:
            os.environ.pop("CONF_MAN_DATA_DIR", None)


class TestRegisterCommand:
    """register命令测试"""

    def test_register_with_doc_status(self, tmp_path):
        """测试带文档状态的注册"""
        runner = CliRunner()
        os.environ["CONF_MAN_DATA_DIR"] = str(tmp_path)
        try:
            result = runner.invoke(cli, [
                "register", "1.0.0",
                "--project", "test-project",
                "--api-doc-updated", "true",
                "--cli-doc-updated", "false"
            ])
            # 验证命令执行
            if result.exit_code != 0:
                print(f"Output: {result.output}")
        finally:
            os.environ.pop("CONF_MAN_DATA_DIR", None)


class TestListCommand:
    """list命令测试"""

    def test_list_command(self, tmp_path):
        """测试list命令"""
        runner = CliRunner()
        os.environ["CONF_MAN_DATA_DIR"] = str(tmp_path)
        try:
            # 先初始化
            runner.invoke(cli, ["init"])
            # 列出版本
            result = runner.invoke(cli, ["list"])
            # 不应该报错
            assert result.exit_code == 0
        finally:
            os.environ.pop("CONF_MAN_DATA_DIR", None)

    def test_list_with_filters(self, tmp_path):
        """测试带过滤条件的list"""
        runner = CliRunner()
        os.environ["CONF_MAN_DATA_DIR"] = str(tmp_path)
        try:
            result = runner.invoke(cli, [
                "list",
                "--status", "registered",
                "--project", "test"
            ])
            assert result.exit_code == 0
        finally:
            os.environ.pop("CONF_MAN_DATA_DIR", None)


class TestVersionCommand:
    """version命令测试"""

    def test_version_constant(self):
        """测试VERSION常量"""
        assert isinstance(VERSION, str)
        assert VERSION.startswith("1.")


class TestShowCommand:
    """show命令测试"""

    def test_show_command(self, tmp_path):
        """测试show命令"""
        runner = CliRunner()
        os.environ["CONF_MAN_DATA_DIR"] = str(tmp_path)
        try:
            result = runner.invoke(cli, ["show", "nonexistent-version-xyz"])
            # 命令不应该崩溃，exit_code 0表示找到版本，非0表示没找到
            assert result.exit_code in [0, 1]  # 0=找到版本, 1=没找到
        finally:
            os.environ.pop("CONF_MAN_DATA_DIR", None)
