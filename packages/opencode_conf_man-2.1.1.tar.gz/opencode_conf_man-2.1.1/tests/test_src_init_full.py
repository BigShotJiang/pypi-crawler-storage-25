"""
src/__init__.py CLI命令完整测试
"""

import pytest
import sys
import os
import json
import tempfile
from pathlib import Path
from click.testing import CliRunner

sys.path.insert(0, str(Path(__file__).parent.parent))

from src import cli


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def clean_env(runner):
    """清理环境变量"""
    old_env = dict(os.environ)
    yield
    os.environ.clear()
    os.environ.update(old_env)


@pytest.fixture
def initialized_env(tmp_path, runner, clean_env):
    """初始化环境"""
    os.environ["CONF_MAN_DATA_DIR"] = str(tmp_path)
    runner.invoke(cli, ["init"])
    yield tmp_path
    if "CONF_MAN_DATA_DIR" in os.environ:
        del os.environ["CONF_MAN_DATA_DIR"]


class TestRegisterCommand:
    """register命令测试"""

    def test_register_basic(self, runner, initialized_env):
        """测试基本注册"""
        result = runner.invoke(cli, ["register", "1.0.0", "--project", "test"])
        assert "登记完成" in result.output or result.exit_code == 0

    def test_register_with_manifest(self, runner, initialized_env, tmp_path):
        """测试带清单文件注册"""
        manifest = tmp_path / "manifest.yaml"
        manifest.write_text("project: test\nversion: 1.0.0")
        result = runner.invoke(cli, ["register", "2.0.0", "--manifest", str(manifest)])
        assert "登记完成" in result.output or result.exit_code == 0

    def test_register_with_test_report(self, runner, initialized_env, tmp_path):
        """测试带测试报告注册"""
        report = tmp_path / "report.json"
        report.write_text('{"passed": true}')
        result = runner.invoke(cli, ["register", "3.0.0", "--test-report", str(report)])
        assert "登记完成" in result.output or result.exit_code == 0

    def test_register_with_doc_status(self, runner, initialized_env):
        """测试带文档状态注册"""
        result = runner.invoke(cli, [
            "register", "4.0.0",
            "--api-doc-updated", "true",
            "--cli-doc-updated", "false"
        ])
        assert "登记完成" in result.output or result.exit_code == 0

    def test_register_with_all_options(self, runner, initialized_env, tmp_path):
        """测试带所有选项注册"""
        manifest = tmp_path / "manifest.yaml"
        manifest.write_text("project: test\ncommit: abc123")
        result = runner.invoke(cli, [
            "register", "5.0.0",
            "--manifest", str(manifest),
            "--project", "full-test",
            "--api-doc-updated", "true",
            "--cli-doc-updated", "true"
        ])
        assert result.exit_code == 0


class TestListCommand:
    """list命令测试"""

    def test_list_empty(self, runner, initialized_env):
        """测试列出空版本"""
        result = runner.invoke(cli, ["list"])
        assert result.exit_code == 0

    def test_list_with_status_filter(self, runner, initialized_env):
        """测试带状态过滤"""
        result = runner.invoke(cli, ["list", "--status", "registered"])
        assert result.exit_code == 0

    def test_list_with_project_filter(self, runner, initialized_env):
        """测试带项目过滤"""
        result = runner.invoke(cli, ["list", "--project", "test"])
        assert result.exit_code == 0

    def test_list_with_limit(self, runner, initialized_env):
        """测试带数量限制"""
        result = runner.invoke(cli, ["list", "--limit", "10"])
        assert result.exit_code == 0


class TestShowCommand:
    """show命令测试"""

    def test_show_not_exists(self, runner, initialized_env):
        """测试显示不存在的版本"""
        result = runner.invoke(cli, ["show", "99.0.0"])
        assert "不存在" in result.output or result.exit_code != 0


class TestReleaseCommand:
    """release命令测试"""

    def test_release_not_exists(self, runner, initialized_env):
        """测试发布不存在的版本"""
        result = runner.invoke(cli, ["release", "99.0.0"])
        assert "不存在" in result.output or result.exit_code != 0


class TestRollbackCommand:
    """rollback命令测试"""

    def test_rollback_not_exists(self, runner, initialized_env):
        """测试回滚不存在的版本"""
        result = runner.invoke(cli, ["rollback", "99.0.0"])
        assert "不存在" in result.output or result.exit_code != 0


class TestDiffCommand:
    """diff命令测试"""

    def test_diff_one_not_exists(self, runner, initialized_env):
        """测试比较一个不存在的版本"""
        result = runner.invoke(cli, ["diff", "99.99.99", "98.98.98"])
        assert "不存在" in result.output or result.exit_code != 0 or "未找到" in result.output


class TestTagCommand:
    """tag命令测试"""

    def test_tag_not_exists(self, runner, initialized_env):
        """测试给不存在的版本添加标签"""
        result = runner.invoke(cli, ["tag", "99.0.0", "stable"])
        assert "不存在" in result.output or result.exit_code != 0


class TestExportCommand:
    """export命令测试"""

    def test_export_not_exists(self, runner, initialized_env):
        """测试导出不存在的版本"""
        result = runner.invoke(cli, ["export", "99.0.0"])
        assert "不存在" in result.output or result.exit_code != 0

    def test_export_json_format(self, runner, initialized_env, tmp_path):
        """测试JSON格式导出"""
        os.environ["CONF_MAN_DATA_DIR"] = str(tmp_path)
        runner.invoke(cli, ["init"])
        runner.invoke(cli, ["register", "1.0.0"])
        result = runner.invoke(cli, ["export", "1.0.0", "--format", "json"])
        if "不存在" not in result.output:
            assert result.exit_code == 0


class TestImportCommand:
    """import命令测试"""

    def test_import_file_not_exists(self, runner, initialized_env):
        """测试导入不存在的文件"""
        result = runner.invoke(cli, ["import", "/tmp/not_exist.json"])
        assert "不存在" in result.output or result.exit_code != 0


class TestSecretCommands:
    """secret命令测试"""

    def test_secret_get_not_exists(self, runner, initialized_env):
        """测试获取不存在的密钥"""
        result = runner.invoke(cli, ["secret", "get", "not-exist"])
        assert result.exit_code != 0 or "不存在" in result.output

    def test_secret_list(self, runner, initialized_env):
        """测试列出密钥"""
        result = runner.invoke(cli, ["secret", "list"])
        assert result.exit_code == 0

    def test_secret_delete_not_exists(self, runner, initialized_env):
        """测试删除不存在的密钥"""
        result = runner.invoke(cli, ["secret", "delete", "not-exist"])
        assert result.exit_code != 0 or "不存在" in result.output


class TestServeCommand:
    """serve命令测试"""

    def test_serve_help(self, runner):
        """测试serve帮助"""
        result = runner.invoke(cli, ["serve", "--help"])
        assert result.exit_code == 0


class TestErrorHandling:
    """错误处理测试"""

    def test_show_with_invalid_version(self, runner, initialized_env):
        """测试显示无效版本号"""
        result = runner.invoke(cli, ["show", ""])
        assert result.exit_code != 0 or "不存在" in result.output

    def test_release_already_released(self, runner, initialized_env):
        """测试重复发布"""
        import time
        ts = int(time.time())
        runner.invoke(cli, ["register", f"1.{ts}"])
        runner.invoke(cli, ["release", f"1.{ts}"])
        result = runner.invoke(cli, ["release", f"1.{ts}"])
        assert result.exit_code == 0

    def test_diff_both_not_exist(self, runner, initialized_env):
        """测试比较两个都不存在的版本"""
        result = runner.invoke(cli, ["diff", "99.0.0", "98.0.0"])
        assert result.exit_code != 0 or "不存在" in result.output or "未找到" in result.output


class TestDocStatusFilters:
    """文档状态过滤测试"""

    def test_list_with_api_doc_filter(self, runner, initialized_env):
        """测试按API文档状态过滤"""
        result = runner.invoke(cli, ["list", "--api-doc-updated", "true"])
        assert result.exit_code == 0

    def test_list_with_cli_doc_filter(self, runner, initialized_env):
        """测试按CLI文档状态过滤"""
        result = runner.invoke(cli, ["list", "--cli-doc-updated", "false"])
        assert result.exit_code == 0
