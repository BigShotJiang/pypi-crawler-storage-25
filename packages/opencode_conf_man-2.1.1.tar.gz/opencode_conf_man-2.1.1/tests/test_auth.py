"""
auth模块测试用例
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.auth import TokenManager, generate_api_key
from cryptography.fernet import Fernet


class TestTokenManager:
    """TokenManager测试"""

    def test_init_with_valid_key(self):
        """测试带有效key初始化"""
        valid_key = Fernet.generate_key().decode()
        manager = TokenManager(valid_key)
        assert manager.key is not None

    def test_init_without_key(self):
        """测试不带key自动生成"""
        manager = TokenManager()
        assert manager.key is not None
        assert len(manager.key) > 0

    def test_encrypt_decrypt(self):
        """测试加密解密"""
        valid_key = Fernet.generate_key().decode()
        manager = TokenManager(valid_key)
        original = "my-secret-token"
        encrypted = manager.encrypt(original)
        decrypted = manager.decrypt(encrypted)
        assert decrypted == original

    def test_encrypt_returns_string(self):
        """测试加密返回字符串"""
        valid_key = Fernet.generate_key().decode()
        manager = TokenManager(valid_key)
        encrypted = manager.encrypt("secret")
        assert isinstance(encrypted, str)

    def test_decrypt_returns_string(self):
        """测试解密返回字符串"""
        valid_key = Fernet.generate_key().decode()
        manager = TokenManager(valid_key)
        encrypted = manager.encrypt("secret")
        decrypted = manager.decrypt(encrypted)
        assert isinstance(decrypted, str)

    def test_get_key(self):
        """测试获取key"""
        valid_key = Fernet.generate_key().decode()
        manager = TokenManager(valid_key)
        key = manager.get_key()
        assert isinstance(key, str)


class TestGenerateApiKey:
    """generate_api_key测试"""

    def test_generate_api_key(self):
        """测试生成API key"""
        key = generate_api_key()
        assert isinstance(key, str)
        assert len(key) == 32

    def test_generate_api_key_unique(self):
        """测试生成的key是唯一的"""
        key1 = generate_api_key()
        key2 = generate_api_key()
        assert key1 != key2
