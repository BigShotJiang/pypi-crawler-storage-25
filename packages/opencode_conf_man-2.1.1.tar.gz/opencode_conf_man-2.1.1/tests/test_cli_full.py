"""
src/cli.py 模块完整测试
"""

import pytest
import sys
from pathlib import Path
from click.testing import CliRunner

sys.path.insert(0, str(Path(__file__).parent.parent))

from src import cli


class TestCliModuleFull:
    """cli模块完整测试"""

    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_cli_module_import(self):
        """测试cli模块可以导入"""
        from src import cli
        assert cli is not None

    def test_main_import(self):
        """测试main可以导入"""
        from src import main
        assert main is not None

    def test_cli_is_click_group(self):
        """测试cli是click组"""
        from click import Group
        from src import cli
        assert isinstance(cli, Group)

    def test_cli_routes(self):
        """测试CLI有路由"""
        from src import cli
        commands = list(cli.commands.keys())
        assert len(commands) > 0
        # 验证主要命令存在
        assert "register" in commands
        assert "list" in commands
        assert "show" in commands
        assert "release" in commands

    def test_main_runs(self):
        """测试main可以运行"""
        from src import main
        assert callable(main)

    def test_cli_version_option(self):
        """测试CLI版本选项"""
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0

    def test_cli_help_option(self):
        """测试CLI帮助选项"""
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "conf-man" in result.output.lower()

    def test_cli_init_command(self):
        """测试init命令"""
        runner = CliRunner()
        result = runner.invoke(cli, ["init"])
        assert result.exit_code == 0
