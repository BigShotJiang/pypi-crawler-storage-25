"""
E2E Tests - Full API Application Tests

这些测试需要完整的API应用 (src.api)，包含所有路由
运行方式: pytest tests/test_e2e_extended_api.py
"""

import pytest
import sys
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent.parent))


@pytest.fixture
def client():
    """创建测试客户端 - 使用完整API应用"""
    from src.api import app
    return TestClient(app)


class TestExtendedAPIEndpoints:
    """测试serve.py中不存在的扩展API端点"""

    def test_rollback_version(self, client):
        """测试版本回滚"""
        import time
        ts = int(time.time())
        
        # 创建版本 - 直接测试，不需要API key
        reg_resp = client.post(
            "/api/v1/versions",
            json={"version": f"1.0.{ts}", "project_id": "conf-man"}
        )
        if reg_resp.status_code not in [200, 201]:
            pytest.skip(f"Cannot create version: {reg_resp.status_code}")
        
        version_id = reg_resp.json().get("id")
        if not version_id:
            pytest.skip("Version ID not returned")
        
        # 回滚
        response = client.post(f"/api/v1/versions/{version_id}/rollback")
        if response.status_code == 404:
            pytest.skip("Endpoint not available")
        assert response.status_code == 200
        assert response.json()["status"] == "rolledback"

    def test_diff_versions(self, client):
        """测试版本比较"""
        import time
        ts = int(time.time())
        
        # 创建两个版本
        client.post(
            "/api/v1/versions",
            json={"version": f"1.0.{ts}", "project_id": "conf-man"}
        )
        client.post(
            "/api/v1/versions",
            json={"version": f"2.0.{ts}", "project_id": "conf-man"}
        )
        
        # 比较 - 尝试POST
        response = client.post(
            "/api/v1/versions/diff",
            json={"version_a": f"1.0.{ts}", "version_b": f"2.0.{ts}"}
        )
        if response.status_code in [404, 405]:
            pytest.skip("Endpoint not available or wrong method")
        assert response.status_code == 200
        data = response.json()
        assert "version_a" in data
        assert "version_b" in data

    def test_tag_version(self, client):
        """测试版本标签"""
        import time
        ts = int(time.time())
        
        reg_resp = client.post(
            "/api/v1/versions",
            json={"version": f"1.0.{ts}", "project_id": "conf-man"}
        )
        if reg_resp.status_code not in [200, 201]:
            pytest.skip(f"Cannot create version: {reg_resp.status_code}")
        
        version_id = reg_resp.json().get("id")
        if not version_id:
            pytest.skip("Version ID not returned")
        
        response = client.post(
            f"/api/v1/versions/{version_id}/tag",
            json={"name": "stable"}
        )
        if response.status_code == 404:
            pytest.skip("Endpoint not available")
        assert response.status_code == 200

    def test_list_version_tags(self, client):
        """测试列出版本标签"""
        import time
        ts = int(time.time())
        
        reg_resp = client.post(
            "/api/v1/versions",
            json={"version": f"1.0.{ts}", "project_id": "conf-man"}
        )
        if reg_resp.status_code not in [200, 201]:
            pytest.skip(f"Cannot create version: {reg_resp.status_code}")
        
        version_id = reg_resp.json().get("id")
        if not version_id:
            pytest.skip("Version ID not returned")
        
        # 添加标签
        client.post(
            f"/api/v1/versions/{version_id}/tag",
            json={"name": "stable"}
        )
        
        # 列出
        response = client.get(f"/api/v1/versions/{version_id}/tags")
        if response.status_code == 404:
            pytest.skip("Endpoint not available")
        assert response.status_code == 200


class TestExtendedAPIFilters:
    """测试扩展API过滤功能"""

    def test_status_filter(self, client):
        """测试状态过滤"""
        import time
        ts = int(time.time())
        
        # 创建registered版本
        client.post(
            "/api/v1/versions",
            json={"version": f"1.0.{ts}", "project_id": "test-agent"}
        )
        
        # 创建并发布版本
        resp = client.post(
            "/api/v1/versions",
            json={"version": f"2.0.{ts}", "project_id": "test-agent"}
        )
        if resp.status_code not in [200, 201]:
            pytest.skip("Cannot create version")
        
        version_data = resp.json()
        version_id = version_data.get("id")
        if version_id:
            client.post(f"/api/v1/versions/{version_id}/release")
        
        # 按status过滤
        response = client.get("/api/v1/versions?status=released")
        if response.status_code == 404:
            pytest.skip("Endpoint not available")
        assert response.status_code == 200

    def test_project_filter(self, client):
        """测试项目过滤"""
        import time
        ts = int(time.time())
        
        client.post(
            "/api/v1/versions",
            json={"version": f"1.0.{ts}", "project_id": "test-agent"}
        )
        client.post(
            "/api/v1/versions",
            json={"version": f"2.0.{ts}", "project_id": "pm-agent"}
        )
        
        response = client.get("/api/v1/versions?project_id=test-agent")
        if response.status_code == 404:
            pytest.skip("Endpoint not available")
        assert response.status_code == 200
