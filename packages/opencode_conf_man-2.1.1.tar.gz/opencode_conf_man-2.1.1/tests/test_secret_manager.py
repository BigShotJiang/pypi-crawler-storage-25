"""
secret_manager模块测试用例
"""

import pytest
import sys
import os
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


class TestSecretsDB:
    """SecretsDB测试"""

    @pytest.fixture
    def secrets_db(self, tmp_path):
        """创建临时SecretsDB实例"""
        from src.secret_manager import SecretsDB
        db_path = tmp_path / "secrets.db"
        return SecretsDB(db_path=str(db_path))

    def test_init_with_path(self, secrets_db):
        """测试带路径初始化"""
        assert secrets_db.db_path.exists()

    def test_set_secret(self, secrets_db):
        """测试设置密钥"""
        result = secrets_db.set("test-key", "test-value")
        assert result is True

    def test_get_secret(self, secrets_db):
        """测试获取密钥"""
        secrets_db.set("test-key", "test-value")
        value = secrets_db.get("test-key")
        assert value == "test-value"

    def test_get_secret_not_exists(self, secrets_db):
        """测试获取不存在的密钥"""
        value = secrets_db.get("not-exist")
        assert value is None

    def test_update_secret(self, secrets_db):
        """测试更新密钥"""
        secrets_db.set("test-key", "value1")
        secrets_db.set("test-key", "value2")
        value = secrets_db.get("test-key")
        assert value == "value2"

    def test_delete_secret(self, secrets_db):
        """测试删除密钥"""
        secrets_db.set("test-key", "test-value")
        result = secrets_db.delete("test-key")
        assert result is True
        assert secrets_db.get("test-key") is None

    def test_delete_not_exists(self, secrets_db):
        """测试删除不存在的密钥"""
        result = secrets_db.delete("not-exist")
        assert result is False

    def test_list_secrets(self, secrets_db):
        """测试列出密钥"""
        secrets_db.set("key1", "value1")
        secrets_db.set("key2", "value2")
        secrets = secrets_db.list()
        assert len(secrets) == 2
        keys = [s["key"] for s in secrets]
        assert "key1" in keys
        assert "key2" in keys

    def test_list_secrets_without_values(self, secrets_db):
        """测试列出密钥不包含值"""
        secrets_db.set("test-key", "secret-value")
        secrets = secrets_db.list()
        assert "test-key" in [s["key"] for s in secrets]
        for s in secrets:
            assert "encrypted_value" not in s

    def test_exists(self, secrets_db):
        """测试检查密钥存在"""
        secrets_db.set("test-key", "test-value")
        assert secrets_db.exists("test-key") is True
        assert secrets_db.exists("not-exist") is False

    def test_encryption(self, secrets_db):
        """测试加密功能"""
        secrets_db.set("secret", "my-secret")
        # 验证加密存储
        import sqlite3
        conn = sqlite3.connect(str(secrets_db.db_path))
        cursor = conn.cursor()
        cursor.execute("SELECT encrypted_value FROM secrets WHERE key = ?", ("secret",))
        row = cursor.fetchone()
        conn.close()
        # 加密值不应该是明文
        assert row[0] != "my-secret"

    def test_multiple_secrets(self, secrets_db):
        """测试多个密钥"""
        for i in range(10):
            secrets_db.set(f"key-{i}", f"value-{i}")
        
        secrets = secrets_db.list()
        assert len(secrets) == 10
        
        for i in range(10):
            assert secrets_db.get(f"key-{i}") == f"value-{i}"
