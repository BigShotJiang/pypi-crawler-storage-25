"""
src/api/routes 完整测试 - 使用完整API应用

这些测试使用 src.api 应用（包含所有路由）来测试 routes/__init__.py 中的端点
"""

import pytest
import sys
from pathlib import Path
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock, AsyncMock

sys.path.insert(0, str(Path(__file__).parent.parent.parent))


class TestRoutesWithFullApp:
    """使用完整API应用测试路由"""

    @pytest.fixture
    def client(self):
        """创建测试客户端 - 使用完整API"""
        from src.api import app
        return TestClient(app)

    def test_health_check(self, client):
        """测试健康检查"""
        response = client.get("/health")
        assert response.status_code == 200
        assert "status" in response.json()

    def test_routes_loaded(self, client):
        """测试路由已加载"""
        routes = []
        for r in client.app.routes:
            if hasattr(r, 'path'):
                routes.append(r.path)
        assert len(routes) > 10

    def test_versions_endpoint_accessible(self, client):
        """测试版本端点可访问"""
        response = client.get("/api/v1/versions")
        assert response.status_code in [200, 401, 422, 500]


class TestRouteExistence:
    """测试路由存在性"""

    def test_all_routes_exist(self):
        """测试所有路由都存在"""
        from src.api.routes import router
        routes = []
        for r in router.routes:
            if hasattr(r, 'path'):
                routes.append(r.path)
        
        assert "/projects" in routes
        assert "/versions" in routes
        assert "/dependencies" in routes

    def test_route_paths(self):
        """测试路由路径"""
        from src.api.routes import router
        
        paths = []
        for route in router.routes:
            if hasattr(route, 'path'):
                paths.append(route.path)
        
        assert len(paths) > 0


class TestDependencyInjection:
    """测试依赖注入"""

    def test_fallback_db_exists(self):
        """测试fallback_db存在"""
        from src.api.routes import _fallback_db
        assert _fallback_db is None or _fallback_db is not None


class TestModelValidation:
    """测试模型验证"""

    def test_project_create_validation(self):
        """测试项目创建验证"""
        from src.api.routes import ProjectCreate
        p = ProjectCreate(name="test")
        assert p.name == "test"

    def test_version_create_validation(self):
        """测试版本创建验证"""
        from src.api.routes import VersionCreate
        v = VersionCreate(version="1.0.0", project_id="test")
        assert v.version == "1.0.0"
        assert v.project_id == "test"

    def test_dependency_create_validation(self):
        """测试依赖创建验证"""
        from src.api.routes import DependencyCreate
        d = DependencyCreate(name="pytest", version_spec=">=7.0")
        assert d.name == "pytest"
        assert d.version_spec == ">=7.0"

    def test_webhook_release_validation(self):
        """测试webhook发布验证"""
        from src.api.routes import WebhookReleaseRequest, WebhookComponent
        req = WebhookReleaseRequest(
            version="1.0.0",
            components=[WebhookComponent(name="app", version="1.0.0")]
        )
        assert req.version == "1.0.0"
        assert len(req.components) == 1

    def test_webhook_subscribe_validation(self):
        """测试webhook订阅验证"""
        from src.api.routes import WebhookSubscribeRequest
        req = WebhookSubscribeRequest(
            url="http://example.com",
            events=["version.registered"]
        )
        assert req.url == "http://example.com"
        assert "version.registered" in req.events

    def test_secret_set_validation(self):
        """测试密钥设置验证"""
        from src.api.routes import SecretSetRequest
        req = SecretSetRequest(key="api-key", value="secret123")
        assert req.key == "api-key"
        assert req.value == "secret123"

    def test_api_key_create_validation(self):
        """测试API Key创建验证"""
        from src.api.routes import APIKeyCreateRequest
        req = APIKeyCreateRequest(name="my-key", expires_days=30)
        assert req.name == "my-key"
        assert req.expires_days == 30

    def test_pypi_token_create_validation(self):
        """测试PyPI Token创建验证"""
        from src.api.routes import PyPITokenCreateRequest
        req = PyPITokenCreateRequest(name="pypi", token="token123")
        assert req.name == "pypi"
        assert req.token == "token123"

    def test_pypi_token_rotate_validation(self):
        """测试PyPI Token轮换验证"""
        from src.api.routes import PyPITokenRotateRequest
        req = PyPITokenRotateRequest(new_token="newtoken")
        assert req.new_token == "newtoken"

    def test_diff_request_validation(self):
        """测试Diff请求验证"""
        from src.api.routes import DiffRequest
        req = DiffRequest(version_a="1.0.0", version_b="2.0.0")
        assert req.version_a == "1.0.0"
        assert req.version_b == "2.0.0"

    def test_tag_request_validation(self):
        """测试Tag请求验证"""
        from src.api.routes import TagRequest
        req = TagRequest(name="stable")
        assert req.name == "stable"

    def test_export_request_validation(self):
        """测试Export请求验证"""
        from src.api.routes import ExportRequest
        req = ExportRequest(version_id="v1", format="json")
        assert req.version_id == "v1"
        assert req.format == "json"


class TestHelperFunctions:
    """测试辅助函数"""

    def test_validate_version_edge_cases(self):
        """测试版本验证边界情况"""
        from src.api.routes import validate_version_format
        
        assert validate_version_format("0.0.0")[0] is True
        assert validate_version_format("10.20.30")[0] is True
        assert validate_version_format("1.0")[0] is False
        assert validate_version_format("1")[0] is False

    def test_guess_project_complete(self):
        """测试项目猜测完整"""
        from src.api.routes import guess_project_from_version
        
        assert guess_project_from_version("1.0.0") == "conf-man"
        assert guess_project_from_version("1.5.0") == "conf-man"
        assert guess_project_from_version("2.0.0") == "oc-collab"
        assert guess_project_from_version("3.0.0") == "pm-agent"
        assert guess_project_from_version("4.0.0") == "test-agent"
        assert guess_project_from_version("9.0.0") is None

    def test_generate_id_variations(self):
        """测试ID生成变体"""
        from src.api.routes import generate_id
        
        id1 = generate_id("a")
        id2 = generate_id("b")
        id3 = generate_id("abc")
        
        assert id1.startswith("a-")
        assert id2.startswith("b-")
        assert id3.startswith("abc-")
        assert len(id1) > 5
        assert len(id2) > 5
        assert len(id3) > 7
