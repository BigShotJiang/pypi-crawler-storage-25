"""
src/api/routes/__init__.py 模块测试
"""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.api.routes import router


class TestRouter:
    """路由测试"""

    def test_router_exists(self):
        """测试路由存在"""
        assert router is not None

    def test_router_routes_count(self):
        """测试路由数量"""
        # routes模块应该有很多路由
        routes = router.routes if hasattr(router, 'routes') else []
        # 至少应该有基本的路由
        assert len(routes) > 0
