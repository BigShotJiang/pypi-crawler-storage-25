import pytest
import sys
from pathlib import Path
import os
import json
from datetime import datetime
from unittest.mock import patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from src.storage import Database


@pytest.fixture
def db():
    db_path = os.path.join(os.getcwd(), "state", "test_e2e_v131.db")
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    if os.path.exists(db_path):
        os.remove(db_path)
    
    test_db = Database(db_path)
    
    test_db.execute("""
        CREATE TABLE IF NOT EXISTS webhook_subscribers (
            id TEXT PRIMARY KEY,
            url TEXT NOT NULL,
            events TEXT,
            active INTEGER DEFAULT 1,
            created_at TEXT,
            updated_at TEXT
        )
    """)
    test_db.execute("""
        CREATE TABLE IF NOT EXISTS webhook_logs (
            id TEXT PRIMARY KEY,
            subscriber_id TEXT,
            event TEXT,
            url TEXT,
            payload TEXT,
            status_code INTEGER,
            response TEXT,
            success INTEGER DEFAULT 0,
            created_at TEXT
        )
    """)
    test_db.execute("""
        CREATE TABLE IF NOT EXISTS version_tags (
            id TEXT PRIMARY KEY,
            version_id TEXT NOT NULL,
            name TEXT NOT NULL,
            created_at TEXT
        )
    """)
    test_db.execute("""
        CREATE TABLE IF NOT EXISTS versions (
            id TEXT PRIMARY KEY,
            version TEXT NOT NULL,
            status TEXT,
            registered_at TEXT,
            released_at TEXT,
            git_commit_hash TEXT,
            project_id TEXT,
            manifest TEXT,
            created_at TEXT,
            updated_at TEXT
        )
    """)
    test_db.execute("""
        CREATE TABLE IF NOT EXISTS dependencies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version_id TEXT,
            name TEXT,
            version_spec TEXT,
            locked_version TEXT
        )
    """)
    
    yield test_db
    
    if os.path.exists(db_path):
        os.remove(db_path)


class TestE2EVersionLifecycle:
    """E2E测试：完整版本生命周期"""

    def test_full_version_lifecycle(self, db):
        """测试完整版本生命周期：创建->发布->回滚->标签"""
        now = datetime.now().isoformat()
        
        version_id = "ver-e2e-test-001"
        
        version = {
            "id": version_id,
            "version": "1.0.0",
            "status": "draft",
            "registered_at": now,
            "git_commit_hash": "abc123",
            "project_id": "test-project",
            "manifest": '{"components": []}',
            "created_at": now,
            "updated_at": now
        }
        db.insert("versions", version)
        
        v = db.get_by_id("versions", version_id)
        assert v["status"] == "draft"
        
        db.update("versions", version_id, {"status": "released", "released_at": now, "updated_at": now})
        v = db.get_by_id("versions", version_id)
        assert v["status"] == "released"
        
        db.update("versions", version_id, {"status": "rolledback", "updated_at": now})
        v = db.get_by_id("versions", version_id)
        assert v["status"] == "rolledback"
        
        tag_id = "tag-e2e-001"
        db.insert("version_tags", {
            "id": tag_id,
            "version_id": version_id,
            "name": "v1.0.0-stable",
            "created_at": now
        })
        
        tags = db.list("version_tags", filters={"version_id": version_id})
        assert len(tags) == 1
        assert tags[0]["name"] == "v1.0.0-stable"


class TestE2EVersionRollback:
    """E2E测试：版本回滚"""

    def test_rollback_draft_version(self, db):
        """测试回滚草稿版本"""
        now = datetime.now().isoformat()
        
        db.insert("versions", {
            "id": "ver-rollback-001",
            "version": "2.0.0",
            "status": "draft",
            "registered_at": now,
            "git_commit_hash": "def456",
            "project_id": "test",
            "manifest": "{}",
            "created_at": now,
            "updated_at": now
        })
        
        db.update("versions", "ver-rollback-001", {"status": "rolledback", "updated_at": now})
        
        v = db.get_by_id("versions", "ver-rollback-001")
        assert v["status"] == "rolledback"

    def test_rollback_released_version(self, db):
        """测试回滚已发布版本"""
        now = datetime.now().isoformat()
        
        db.insert("versions", {
            "id": "ver-rollback-002",
            "version": "2.1.0",
            "status": "released",
            "registered_at": now,
            "released_at": now,
            "git_commit_hash": "ghi789",
            "project_id": "test",
            "manifest": "{}",
            "created_at": now,
            "updated_at": now
        })
        
        db.update("versions", "ver-rollback-002", {"status": "rolledback", "updated_at": now})
        
        v = db.get_by_id("versions", "ver-rollback-002")
        assert v["status"] == "rolledback"


class TestE2EVersionDiff:
    """E2E测试：版本比较"""

    def test_diff_two_versions(self, db):
        """测试比较两个版本"""
        now = datetime.now().isoformat()
        
        db.insert("versions", {
            "id": "ver-diff-a",
            "version": "1.0.0",
            "status": "released",
            "registered_at": now,
            "git_commit_hash": "abc123",
            "project_id": "test",
            "manifest": '{"components": ["a", "b"]}',
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("versions", {
            "id": "ver-diff-b",
            "version": "1.1.0",
            "status": "released",
            "registered_at": now,
            "git_commit_hash": "xyz789",
            "project_id": "test",
            "manifest": '{"components": ["a", "b", "c"]}',
            "created_at": now,
            "updated_at": now
        })
        
        v1 = db.get_by_id("versions", "ver-diff-a")
        v2 = db.get_by_id("versions", "ver-diff-b")
        
        differences = []
        if v1.get("manifest") != v2.get("manifest"):
            differences.append("manifest changed")
        if v1.get("git_commit_hash") != v2.get("git_commit_hash"):
            differences.append("git_commit_hash changed")
        
        assert "manifest changed" in differences
        assert "git_commit_hash changed" in differences

    def test_diff_identical_versions(self, db):
        """测试比较相同版本"""
        now = datetime.now().isoformat()
        
        db.insert("versions", {
            "id": "ver-same-a",
            "version": "1.0.0",
            "status": "released",
            "registered_at": now,
            "git_commit_hash": "same123",
            "project_id": "test",
            "manifest": '{"components": ["a"]}',
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("versions", {
            "id": "ver-same-b",
            "version": "1.0.0",
            "status": "released",
            "registered_at": now,
            "git_commit_hash": "same123",
            "project_id": "test",
            "manifest": '{"components": ["a"]}',
            "created_at": now,
            "updated_at": now
        })
        
        v1 = db.get_by_id("versions", "ver-same-a")
        v2 = db.get_by_id("versions", "ver-same-b")
        
        differences = []
        if v1.get("manifest") != v2.get("manifest"):
            differences.append("manifest changed")
        if v1.get("git_commit_hash") != v2.get("git_commit_hash"):
            differences.append("git_commit_hash changed")
        
        assert len(differences) == 0


class TestE2EVersionTags:
    """E2E测试：版本标签"""

    def test_add_multiple_tags(self, db):
        """测试添加多个标签"""
        now = datetime.now().isoformat()
        
        version_id = "ver-tags-001"
        
        db.insert("versions", {
            "id": version_id,
            "version": "1.0.0",
            "status": "released",
            "registered_at": now,
            "git_commit_hash": "test123",
            "project_id": "test",
            "manifest": "{}",
            "created_at": now,
            "updated_at": now
        })
        
        for i, tag_name in enumerate(["stable", "latest", "v1.0.0"]):
            db.insert("version_tags", {
                "id": f"tag-{i}",
                "version_id": version_id,
                "name": tag_name,
                "created_at": now
            })
        
        tags = db.list("version_tags", filters={"version_id": version_id})
        assert len(tags) == 3
        
        tag_names = [t["name"] for t in tags]
        assert "stable" in tag_names
        assert "latest" in tag_names

    def test_list_tags_empty(self, db):
        """测试列出不存在的标签"""
        tags = db.list("version_tags", filters={"version_id": "non-existent"})
        assert len(tags) == 0


class TestE2EExportImport:
    """E2E测试：版本导出导入"""

    def test_export_version_with_deps(self, db):
        """测试导出版本及依赖"""
        now = datetime.now().isoformat()
        
        version_id = "ver-export-001"
        db.insert("versions", {
            "id": version_id,
            "version": "1.0.0",
            "status": "released",
            "registered_at": now,
            "git_commit_hash": "export123",
            "project_id": "test",
            "manifest": '{"name": "test-project"}',
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("dependencies", {
            "version_id": version_id,
            "name": "dep-a",
            "version_spec": "^1.0.0",
            "locked_version": "1.2.3"
        })
        db.insert("dependencies", {
            "version_id": version_id,
            "name": "dep-b",
            "version_spec": "^2.0.0",
            "locked_version": "2.1.0"
        })
        
        version = db.get_by_id("versions", version_id)
        deps = db.list("dependencies", filters={"version_id": version_id})
        
        export_data = {
            "version": version,
            "dependencies": deps
        }
        
        assert export_data["version"]["version"] == "1.0.0"
        assert len(export_data["dependencies"]) == 2

    def test_import_version(self, db):
        """测试导入版本"""
        now = datetime.now().isoformat()
        
        import_data = {
            "version": {
                "id": "ver-import-001",
                "version": "2.0.0",
                "status": "imported",
                "registered_at": now,
                "git_commit_hash": "import123",
                "project_id": "imported-project",
                "manifest": '{"name": "imported"}'
            },
            "dependencies": [
                {"name": "dep-x", "version_spec": "^1.0", "locked_version": "1.5.0"}
            ]
        }
        
        version_data = import_data["version"]
        db.insert("versions", {
            "id": version_data["id"],
            "version": version_data["version"],
            "status": version_data["status"],
            "registered_at": version_data["registered_at"],
            "git_commit_hash": version_data["git_commit_hash"],
            "project_id": version_data["project_id"],
            "manifest": version_data["manifest"],
            "created_at": now,
            "updated_at": now
        })
        
        for dep in import_data["dependencies"]:
            db.insert("dependencies", {
                "version_id": version_data["id"],
                "name": dep["name"],
                "version_spec": dep["version_spec"],
                "locked_version": dep["locked_version"]
            })
        
        imported = db.get_by_id("versions", "ver-import-001")
        assert imported["version"] == "2.0.0"
        
        deps = db.list("dependencies", filters={"version_id": "ver-import-001"})
        assert len(deps) == 1


class TestE2EWebhookIntegration:
    """E2E测试：Webhook集成"""

    def test_subscribe_and_notify(self, db):
        """测试订阅和通知流程"""
        now = datetime.now().isoformat()
        
        sub_id = "sub-e2e-001"
        db.insert("webhook_subscribers", {
            "id": sub_id,
            "url": "http://example.com/webhook",
            "events": json.dumps(["version.registered", "version.released"]),
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        version_id = "ver-webhook-001"
        db.insert("versions", {
            "id": version_id,
            "version": "1.0.0",
            "status": "registered",
            "registered_at": now,
            "git_commit_hash": "webhook123",
            "project_id": "test",
            "manifest": "{}",
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("webhook_logs", {
            "id": "log-e2e-001",
            "subscriber_id": sub_id,
            "event": "version.registered",
            "url": "http://example.com/webhook",
            "payload": '{"version": "1.0.0"}',
            "status_code": 200,
            "response": '{"status": "ok"}',
            "success": 1,
            "created_at": now
        })
        
        subs = db.list("webhook_subscribers", filters={"active": 1})
        assert len(subs) == 1
        
        logs = db.list("webhook_logs", filters={"subscriber_id": sub_id})
        assert len(logs) == 1
        assert logs[0]["success"] == 1

    def test_webhook_filtering_by_event(self, db):
        """测试按事件过滤webhook"""
        now = datetime.now().isoformat()
        
        db.insert("webhook_subscribers", {
            "id": "sub-filter-001",
            "url": "http://example.com/all",
            "events": json.dumps(["version.registered", "version.released", "version.deprecated"]),
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("webhook_logs", {
            "id": "log-filter-001",
            "subscriber_id": "sub-filter-001",
            "event": "version.registered",
            "url": "http://example.com/all",
            "payload": "{}",
            "status_code": 200,
            "response": "{}",
            "success": 1,
            "created_at": now
        })
        
        logs = db.list("webhook_logs", filters={"event": "version.registered"})
        assert len(logs) == 1
        assert logs[0]["event"] == "version.registered"


class TestE2EFullWorkflow:
    """E2E测试：完整工作流"""

    def test_complete_release_workflow(self, db):
        """测试完整发布工作流"""
        now = datetime.now().isoformat()
        
        version_id = "ver-workflow-001"
        db.insert("versions", {
            "id": version_id,
            "version": "3.0.0",
            "status": "draft",
            "registered_at": now,
            "git_commit_hash": "workflow123",
            "project_id": "workflow-test",
            "manifest": '{"components": [{"name": "core", "version": "1.0"}]}',
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("dependencies", {
            "version_id": version_id,
            "name": "dependency-a",
            "version_spec": "^1.0.0",
            "locked_version": "1.2.3"
        })
        
        db.update("versions", version_id, {"status": "released", "released_at": now, "updated_at": now})
        
        db.insert("version_tags", {
            "id": "tag-workflow-001",
            "version_id": version_id,
            "name": "v3.0.0-release",
            "created_at": now
        })
        
        sub_id = "sub-workflow-001"
        db.insert("webhook_subscribers", {
            "id": sub_id,
            "url": "http://notifications.example.com/hook",
            "events": json.dumps(["version.released"]),
            "active": 1,
            "created_at": now,
            "updated_at": now
        })
        
        db.insert("webhook_logs", {
            "id": "log-workflow-001",
            "subscriber_id": sub_id,
            "event": "version.released",
            "url": "http://notifications.example.com/hook",
            "payload": '{"version": "3.0.0"}',
            "status_code": 200,
            "response": '{"status": "received"}',
            "success": 1,
            "created_at": now
        })
        
        final_version = db.get_by_id("versions", version_id)
        assert final_version["status"] == "released"
        
        tags = db.list("version_tags", filters={"version_id": version_id})
        assert len(tags) == 1
        
        deps = db.list("dependencies", filters={"version_id": version_id})
        assert len(deps) == 1
        
        logs = db.list("webhook_logs")
        assert len(logs) == 1
        assert logs[0]["success"] == 1
