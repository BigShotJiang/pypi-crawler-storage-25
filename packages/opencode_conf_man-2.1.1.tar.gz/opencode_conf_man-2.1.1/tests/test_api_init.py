"""
src/api/__init__.py 模块测试
"""

import pytest
import sys
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.api import app


class TestAPIApp:
    """API应用测试"""

    @pytest.fixture
    def client(self):
        """创建测试客户端"""
        return TestClient(app)

    def test_app_exists(self):
        """测试应用存在"""
        assert app is not None

    def test_app_title(self):
        """测试应用标题"""
        assert app.title == "conf-man API"

    def test_app_version(self):
        """测试应用版本"""
        assert app.version is not None


class TestHealthEndpoint:
    """健康检查端点测试"""

    @pytest.fixture
    def client(self):
        return TestClient(app)

    def test_health_check(self, client):
        """测试健康检查"""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert "status" in data
        assert data["status"] == "ok"


class TestAPIKeysEndpoints:
    """API Keys端点测试"""

    @pytest.fixture
    def client(self):
        from src.storage import Database
        from src.api import app
        client = TestClient(app)
        app.state.db = Database()
        yield client
        if hasattr(app.state, 'db'):
            del app.state.db

    def test_list_api_keys_requires_auth(self, client):
        """测试列出API Keys"""
        response = client.get("/api/v1/api-keys")
        assert response.status_code == 200

    def test_create_api_key_requires_auth(self, client):
        """测试创建API Key需要认证"""
        response = client.post("/api/v1/api-keys", params={"name": "test"})
        assert response.status_code in [401, 422]

    def test_delete_api_key_requires_auth(self, client):
        """测试删除API Key需要认证"""
        response = client.delete("/api/v1/api-keys/test-id")
        assert response.status_code in [401, 422]
