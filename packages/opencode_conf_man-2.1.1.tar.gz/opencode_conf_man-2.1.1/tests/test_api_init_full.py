"""
src/api/__init__.py 模块完整测试
"""

import pytest
import sys
import os
import tempfile
from pathlib import Path
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent.parent.parent))


class TestAPIInitFull:
    """api/__init__.py完整测试"""

    def test_app_import(self):
        """测试应用可以导入"""
        from src.api import app
        assert app is not None

    def test_app_title(self):
        """测试应用标题"""
        from src.api import app
        assert app.title == "conf-man API"

    def test_app_version(self):
        """测试应用版本"""
        from src.api import app
        assert app.version is not None

    def test_app_has_routes(self):
        """测试应用有路由"""
        from src.api import app
        # 应用应该有一些路由
        assert len(app.routes) > 0

    def test_health_endpoint(self):
        """测试健康检查端点"""
        from src.api import app
        client = TestClient(app)
        response = client.get("/health")
        assert response.status_code == 200

    def test_health_response(self):
        """测试健康检查响应"""
        from src.api import app
        client = TestClient(app)
        response = client.get("/health")
        data = response.json()
        assert "status" in data
        assert "version" in data

    def test_api_keys_endpoint(self):
        """测试API Keys端点"""
        from src.api import app
        from src.storage import Database
        client = TestClient(app)
        app.state.db = Database()
        try:
            response = client.get("/api/v1/api-keys")
            assert response.status_code == 200
            data = response.json()
            assert "api_keys" in data
        finally:
            if hasattr(app.state, 'db'):
                del app.state.db

    def test_create_api_key_requires_auth(self):
        """测试创建API Key需要认证"""
        from src.api import app
        from src.storage import Database
        client = TestClient(app)
        app.state.db = Database()
        try:
            response = client.post("/api/v1/api-keys", params={"name": "test"})
            assert response.status_code in [401, 422]
        finally:
            del app.state.db

    def test_delete_api_key_requires_auth(self):
        """测试删除API Key需要认证"""
        from src.api import app
        from src.storage import Database
        client = TestClient(app)
        app.state.db = Database()
        try:
            response = client.delete("/api/v1/api-keys/test-id")
            assert response.status_code in [401, 422]
        finally:
            if hasattr(app.state, 'db'):
                del app.state.db

    def test_load_api_keys(self):
        """测试load_api_keys函数"""
        from src.api import load_api_keys, API_KEYS
        from src.storage import Database
        db = Database()
        result = load_api_keys(db)
        assert result is None

    def test_lifespan_context(self):
        """测试lifespan上下文管理器"""
        from src.api import lifespan
        from src.api import app
        import asyncio
        
        async def test_lifespan():
            async with lifespan(app) as handler:
                assert hasattr(app.state, 'db')
        
        asyncio.run(test_lifespan())

    def test_api_keys_global_variable(self):
        """测试API_KEYS全局变量"""
        from src.api import API_KEYS
        assert isinstance(API_KEYS, dict)

    def test_create_api_key_with_expires(self):
        """测试创建带过期时间的API Key"""
        from src.api import app
        from src.storage import Database
        client = TestClient(app)
        app.state.db = Database()
        try:
            response = client.post("/api/v1/api-keys", params={"name": "test-key", "expires_at": "2025-12-31"})
            assert response.status_code in [200, 401, 422]
        finally:
            if hasattr(app.state, 'db'):
                del app.state.db

    def test_app_state_db(self):
        """测试应用状态中的数据库"""
        from src.api import app
        from src.storage import Database
        app.state.db = Database()
        try:
            assert hasattr(app.state, 'db')
        finally:
            if hasattr(app.state, 'db'):
                del app.state.db
