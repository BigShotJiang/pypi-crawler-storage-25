"""
Chatsee AI SDK
Tracks conversation data with optional support for tool calls, errors, and metadata.
"""

from typing import Optional, Dict, Any, List
from dataclasses import dataclass, asdict
from datetime import datetime
import asyncio
import json
import requests
import logging
import warnings

# Optional local redaction support (fail open if unavailable)
from chatsee.redaction.engine import redact_payload_sync
from chatsee.redaction.loader import load_redaction_rules_sync
from chatsee.env import resolve_api_base_url

# Set up a logger for the library
logger = logging.getLogger(__name__)


async def _with_deadline(coro, timeout: Optional[float]):
    """Apply a deadline using asyncio.timeout if available (3.11+)."""
    if timeout is None:
        return await coro
    if hasattr(asyncio, "timeout"):
        async with asyncio.timeout(timeout):
            return await coro
    return await asyncio.wait_for(coro, timeout=timeout)


def _run_coroutine_blocking(coro, timeout: Optional[float] = None):
    """
    Run an async coroutine from synchronous SDK code.

    Always runs the coroutine on a brand-new asyncio event loop in a
    dedicated worker thread. This gives us two properties that matter to
    the MCP client:

    1. We never deadlock a caller that is itself inside a running event
       loop (we cannot call ``asyncio.run()`` from such a context).
    2. The event loop / httpx transport state used for this call is
       fully torn down when the worker thread exits, so consecutive SDK
       calls don't inherit leaked sockets or anyio TaskGroup state from
       a previous ``asyncio.run()`` on the main thread. On
       Windows + Python 3.12 this leak manifests as
       ``httpx.ConnectError: All connection attempts failed`` on the
       second and later calls.

    ``asyncio.timeout`` (Python 3.11+) is applied *inside* the coroutine
    when a deadline is requested, so cancellation is delivered cleanly
    through anyio TaskGroups instead of raising BaseExceptionGroup.
    """
    import threading

    wrapped = _with_deadline(coro, timeout)
    result_box: Dict[str, Any] = {}

    def _runner() -> None:
        try:
            result_box["value"] = asyncio.run(wrapped)
        except BaseException as exc:  # re-raised on the calling thread below
            result_box["error"] = exc

    thread = threading.Thread(target=_runner, name="chatsee-mcp-call", daemon=False)
    thread.start()
    thread.join()
    if "error" in result_box:
        raise result_box["error"]
    return result_box.get("value")


@dataclass
class ToolCall:
    tool_name: str
    arguments: Dict[str, Any]
    result: Optional[Any] = None
    error: Optional[str] = None
    timestamp: str = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.utcnow().isoformat()

class ChatseeTracker:
    """
    SDK class for tracking LLM conversations.

    Parameters
    ----------
    agent_id : str
        The agent identifier.
    tenant_id : str
        The tenant identifier.
    session_id : str, optional
        Client-supplied session ID.  If omitted the API generates one.
    api_base_url : str, optional
        Environment alias (``"qa"``, ``"demo"``, ``"gcp"``, ``"gcp-demo"``,
        ``"dev"``) or a full URL.  Defaults to ``"qa"``.
    is_final_turn : bool
        Pass ``True`` to ``end_turn`` to signal the conversation
        termination service that this is the last turn.  The
        conversation will be flushed immediately without waiting
        for the inactivity timer or signature detection.
    """
    
    _DEFAULT_API_BASE_URL = "qa"
    _PROCESS_INTERACTION_PATH = "/v1/api/process_interaction"
    _BATCH_PROCESS_PATH = "/v1/api/batch_process_interactions"
    _CLASSIFIERS_PATH = "/v1/redaction/fetch-classifiers"
    _MCP_TOOL_FETCH_PENDING = "pull_pending_remediations"
    _MCP_TOOL_FETCH_ALL = "get_all_skills"
    _MCP_TOOL_ACK = "acknowledge_applied"
    _MCP_TOOL_REJECT = "reject_remediation"
    _MCP_TOOL_STATUS = "get_remediation_status"

    def __init__(self,
                 agent_id: str,
                 tenant_id: str,
                 # Removed chatsee_api_key
                 session_id: Optional[str] = None,
                 timeout: int = 10,
                 verify_ssl: bool = False,
                 api_base_url: Optional[str] = None,
                 mcp_server_url: Optional[str] = None,
                 mcp_api_key: Optional[str] = None,
                 redaction_enabled: bool = False,
                 redaction_fields_to_redact: Optional[Any] = None,
                 redaction_cache_ttl_seconds: int = 300,
                 redaction_timeout_seconds: float = 5.0,
                 redaction_classifiers_url: Optional[str] = None):

        if not agent_id or not tenant_id:
            raise ValueError("agent_id and tenant_id are required.")

        self.agent_id = agent_id
        self.tenant_id = tenant_id
        self.session_id = session_id
        self.timeout = timeout
        self.verify_ssl = verify_ssl

        base_url = resolve_api_base_url(api_base_url or self._DEFAULT_API_BASE_URL).rstrip("/")
        self._api_base_url = base_url
        self._api_endpoint = f"{base_url}{self._PROCESS_INTERACTION_PATH}"
        self._batch_api_endpoint = f"{base_url}{self._BATCH_PROCESS_PATH}"
        self._classifiers_url = redaction_classifiers_url or f"{base_url}{self._CLASSIFIERS_PATH}"

        # Intentionally do NOT rstrip('/') here: the chatsee-mcp server's
        # Streamable HTTP endpoint is served at a trailing-slash path
        # (e.g. "/mcp/"). Stripping the slash would rely on an HTTP
        # redirect to the canonical URL, which the anyio-based MCP client
        # does not follow cleanly and ends up reporting as a generic
        # TCP "All connection attempts failed".
        self._mcp_server_url = (mcp_server_url or "").strip() or None
        self._mcp_api_key = mcp_api_key or None

        self._redaction_enabled = bool(redaction_enabled)
        self._redaction_fields_to_redact = (
            redaction_fields_to_redact
            if redaction_fields_to_redact is not None
            else {"user_message", "bot_message", "interactions"}
        )
        self._redaction_cache_ttl_seconds = int(redaction_cache_ttl_seconds)
        self._redaction_timeout_seconds = float(redaction_timeout_seconds)
        
        # Internal state for the current turn
        self.current_user_message: Optional[str] = None
        self.current_metadata: Dict[str, Any] = {}
        self.current_tool_calls: List[ToolCall] = []
        self.current_exception: Optional[str] = None
        self.error_encountered: int = 0
        self.current_system_prompt: Optional[str] = None
        
        self.session = requests.Session()
        self.session.headers.update({
            "Content-Type": "application/json"
        })
        
        if not self.verify_ssl:
            warnings.filterwarnings('ignore', 'Unverified HTTPS request')

    def _apply_redaction_if_enabled(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if not self._redaction_enabled:
            return payload
        rules = load_redaction_rules_sync(
            classifiers_url=self._classifiers_url,
            cache_ttl_seconds=self._redaction_cache_ttl_seconds,
            timeout_seconds=self._redaction_timeout_seconds,
            verify_ssl=self.verify_ssl,
        )
        if not rules:
            return payload

        try:
            redacted = redact_payload_sync(
                payload, rules, fields_to_redact=self._redaction_fields_to_redact
            )
            return redacted if isinstance(redacted, dict) else payload
        except Exception:
            # Fail open: do not block tracking
            return payload

    def redact(self, payload: Any, fields_to_redact: Optional[Any] = None) -> Any:
        """
        Redact an arbitrary payload using this tracker’s configured environment.
        This does not send anything to Chatsee.
        """
        rules = load_redaction_rules_sync(
            classifiers_url=self._classifiers_url,
            cache_ttl_seconds=self._redaction_cache_ttl_seconds,
            timeout_seconds=self._redaction_timeout_seconds,
            verify_ssl=self.verify_ssl,
        )
        if not rules:
            return payload
        return redact_payload_sync(
            payload,
            rules,
            fields_to_redact=fields_to_redact
            if fields_to_redact is not None
            else self._redaction_fields_to_redact,
        )

    def start_turn(self, user_message: str, metadata: Optional[Dict[str, Any]] = None, system_prompt: Optional[str] = None):
        """
        Start tracking a turn.
        """
        self.current_user_message = user_message
        self.current_metadata = metadata or {}
        self.current_tool_calls = []
        self.current_exception = None
        self.error_encountered = 0
        self.current_system_prompt = system_prompt
    
    def log_tool_call(self, tool_name: str, arguments: Dict[str, Any], 
                      result: Optional[Any] = None, error: Optional[str] = None):
        """
        Log an optional tool/function call.
        """
        if self.current_user_message is None:
             logger.warning("log_tool_call called before start_turn.")
             return

        tool_call = ToolCall(
            tool_name=tool_name,
            arguments=arguments,
            result=result,
            error=error
        )
        self.current_tool_calls.append(tool_call)
        
        if error:
            self.error_encountered = 1
            if not self.current_exception:
                self.current_exception = error
    
    def log_exception(self, exception: Exception):
        """
        Log an optional exception.
        """
        if self.current_user_message is None:
             logger.warning("log_exception called before start_turn.")
             return

        self.error_encountered = 1
        self.current_exception = str(exception)
    
    def end_turn(self, bot_message: str, is_final_turn: bool = False):
        """
        Complete the turn and send data to the API.

        Parameters
        ----------
        bot_message : str
            The assistant's response for this turn.
        is_final_turn : bool, optional
            When ``True``, signals the conversation termination service
            that this is the last turn.  The conversation will be flushed
            downstream immediately without waiting for the inactivity
            timer or signature detection.  Default ``False``.
        """
        if not self.current_user_message:
            logger.warning("end_turn called without start_turn. Skipping log.")
            return

        try:
            # Prepare optional tool call data
            tool_calls_dicts = [asdict(tc) for tc in self.current_tool_calls]

            metadata = dict(self.current_metadata)
            if is_final_turn:
                metadata["is_final_turn"] = True

            payload = {
                # Required Fields (No API Key)
                'agent_id': self.agent_id,
                'tenant_id': self.tenant_id,
                'user_message': self.current_user_message,
                'bot_message': bot_message,
                'session_id': self.session_id,
                
                # Optional Fields
                'tool_call': 1 if tool_calls_dicts else 0,
                'tool_calls_details': tool_calls_dicts,
                'error_encountered': self.error_encountered,
                'exception': self.current_exception,
                'metadata': metadata,
                'system_prompt': self.current_system_prompt
            }

            payload_to_send = self._apply_redaction_if_enabled(payload)
            
            # Send to API
            response = self.session.post(
                self._api_endpoint,
                json=payload_to_send,
                timeout=self.timeout,
                verify=self.verify_ssl
            )
            response.raise_for_status()

            # Log success (useful for QA/debugging; controlled by consumer's logging config)
            interaction_id = None
            try:
                data = response.json()
                interaction_id = data.get("interaction_id") or data.get("data", {}).get("interaction_id")
            except Exception:
                data = None

            if interaction_id:
                logger.info(
                    "Chatsee interaction sent successfully. status=%s interaction_id=%s",
                    response.status_code,
                    interaction_id,
                )
            else:
                logger.info(
                    "Chatsee interaction sent successfully. status=%s",
                    response.status_code,
                )
            
            # Update session ID if generated by API
            if not self.session_id:
                if data is None:
                    data = response.json()
                if 'session_id' in data:
                    self.session_id = data['session_id']
            
        except Exception as e:
            logger.error(f"Failed to send turn to Chatsee: {e}")
        finally:
            # Reset state
            self.current_user_message = None
            self.current_metadata = {}
            self.current_tool_calls = []
            self.current_exception = None
            self.error_encountered = 0
            self.current_system_prompt = None

    def send_batch(self, interactions: List[Dict[str, Any]], timeout: Optional[int] = None) -> Dict[str, Any]:
        """
        Send multiple interactions in a single API call so the backend
        processes them as one batch (one Processor run, one Query Processor run).

        Each dict in *interactions* should contain:
            - user_message (str, required)
            - bot_message  (str, required)
            - session_id   (str, optional)
            - tool_call    (int, optional — 0 or 1)
            - tool_calls_details (list[dict], optional)
            - error_encountered  (int, optional — 0 or 1)
            - exception    (str, optional)
            - metadata     (dict, optional)
            - system_prompt (str, optional)

        Returns the parsed JSON response from the API on success,
        or a dict with ``status: "error"`` on failure.
        """
        if not interactions:
            logger.warning("send_batch called with empty list. Nothing to send.")
            return {"status": "error", "message": "No interactions provided."}

        if self._redaction_enabled:
            interactions = [self._apply_redaction_if_enabled(i) for i in interactions]

        payload = {
            "agent_id": self.agent_id,
            "tenant_id": self.tenant_id,
            "interactions": interactions,
        }

        batch_timeout = timeout or max(self.timeout, len(interactions) // 5 + 30)

        try:
            response = self.session.post(
                self._batch_api_endpoint,
                json=payload,
                timeout=batch_timeout,
                verify=self.verify_ssl,
            )
            response.raise_for_status()
            data = response.json()
            logger.info(
                "Chatsee batch sent successfully. status=%s count=%d",
                response.status_code,
                len(interactions),
            )
            return data
        except Exception as e:
            logger.error("Failed to send batch to Chatsee: %s", e)
            return {"status": "error", "message": str(e)}

    def fetch_remediations(
        self,
        mode: str = "pending",
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Pull remediation skills for this agent from the chatsee-mcp server.

        Uses the MCP ``pull_pending_remediations`` (mode=``"pending"``,
        default) or ``get_all_skills`` (mode=``"all"``) tool over
        Streamable HTTP. Tenant + agent are resolved server-side from the
        MCP API key; the caller only chooses the delivery mode.

        Parameters
        ----------
        mode : str
            ``"pending"`` (default) — only skills that have not been
            delivered yet (new since the last sync).
            ``"all"`` — every skill for this agent, regardless of state.
        timeout : int, optional
            Per-call timeout in seconds. Falls back to ``self.timeout``.

        Returns
        -------
        dict
            On success: the MCP payload containing, at minimum,
            ``skills_markdown`` (string to inject into the prompt) and
            ``failure_memory_ids`` (list[str] to pass to
            :meth:`acknowledge_remediations`). Other keys depend on the
            MCP server version (e.g. ``delivered_count``, ``total_rules``).
            On failure: ``{"status": "error", "message": "..."}``.

        The MCP server transitions any ``Created`` docs it returns to
        ``Delivered`` as a side effect. Real acknowledgement of injection
        must follow via :meth:`acknowledge_remediations`.
        """
        if mode not in ("pending", "all"):
            return self._error(f"Invalid mode '{mode}'. Must be 'pending' or 'all'.")

        tool = (
            self._MCP_TOOL_FETCH_PENDING
            if mode == "pending"
            else self._MCP_TOOL_FETCH_ALL
        )
        payload = self._call_mcp_tool(tool, {}, timeout=timeout)
        if isinstance(payload, dict) and payload.get("status") == "error":
            return payload

        if isinstance(payload, dict):
            logger.info(
                "Chatsee remediations fetched. total=%s delivered=%s mode=%s",
                payload.get("total_rules"),
                payload.get("delivered_count"),
                mode,
            )
        return payload

    def acknowledge_remediations(
        self,
        failure_memory_ids: List[str],
        details: str = "",
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Acknowledge that one or more remediations have been injected into
        the chatbot's system prompt.

        Calls the MCP ``acknowledge_applied`` tool once per
        ``failure_memory_id`` over a single Streamable HTTP session. The
        server transitions each doc from ``mcp_delivery.state == Delivered``
        to ``Applied`` (or reports "already applied" for idempotent re-acks)
        and records the provided ``details``.

        Parameters
        ----------
        failure_memory_ids : list[str]
            IDs returned by a prior :meth:`fetch_remediations` call.
        details : str, optional
            Free-text note describing what was injected.
        timeout : int, optional
            Per-batch timeout in seconds.

        Returns
        -------
        dict
            ``{
                "status": "ok",
                "applied_count": <int>,
                "results": [
                    {"failure_memory_id": "...", "response": <MCP-payload>},
                    ...
                ]
            }``
            On session-level failure: ``{"status": "error", "message": "..."}``.
        """
        ids = [i for i in (failure_memory_ids or []) if i]
        if not ids:
            return self._error("failure_memory_ids must not be empty.")

        calls = [
            (self._MCP_TOOL_ACK, {"failure_memory_id": fid, "details": details or ""})
            for fid in ids
        ]
        session_result = self._call_mcp_tools_in_session(calls, timeout=timeout)
        if session_result.get("status") == "error":
            return session_result

        applied = 0
        results = []
        for fid, resp in zip(ids, session_result["results"]):
            results.append({"failure_memory_id": fid, "response": resp})
            if isinstance(resp, dict):
                # MCP typically returns success=True / state="Applied" on
                # a fresh transition, and success=True / already=True (or
                # similar) on idempotent re-ack. We only count brand-new
                # transitions toward applied_count.
                if resp.get("success") and resp.get("state") == "Applied" and not resp.get(
                    "already_applied"
                ):
                    applied += 1
        logger.info(
            "Chatsee remediations acknowledged. total=%d applied=%d",
            len(ids),
            applied,
        )
        return {"status": "ok", "applied_count": applied, "results": results}

    def reject_remediations(
        self,
        failure_memory_ids: List[str],
        reason: str = "",
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Reject one or more delivered remediations.

        Calls the MCP ``reject_remediation`` tool once per
        ``failure_memory_id``. Transitions each doc from ``Delivered`` to
        ``Rejected`` and records the reason. Useful when a delivered skill
        is not applicable to this deployment.
        """
        ids = [i for i in (failure_memory_ids or []) if i]
        if not ids:
            return self._error("failure_memory_ids must not be empty.")

        calls = [
            (self._MCP_TOOL_REJECT, {"failure_memory_id": fid, "reason": reason or ""})
            for fid in ids
        ]
        session_result = self._call_mcp_tools_in_session(calls, timeout=timeout)
        if session_result.get("status") == "error":
            return session_result

        rejected = 0
        results = []
        for fid, resp in zip(ids, session_result["results"]):
            results.append({"failure_memory_id": fid, "response": resp})
            if isinstance(resp, dict) and resp.get("success") and resp.get(
                "state"
            ) == "Rejected":
                rejected += 1
        return {"status": "ok", "rejected_count": rejected, "results": results}

    def get_remediation_status(
        self,
        failure_memory_id: Optional[str] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Query the current delivery state of one or all remediations for
        this agent via the MCP ``get_remediation_status`` tool.

        Parameters
        ----------
        failure_memory_id : str, optional
            Specific entry to query. Omit to get status of all entries.
        """
        args: Dict[str, Any] = {}
        if failure_memory_id:
            args["failure_memory_id"] = failure_memory_id
        return self._call_mcp_tool(self._MCP_TOOL_STATUS, args, timeout=timeout)

    # ── MCP transport helpers ────────────────────────────────────────────

    def _error(self, message: str) -> Dict[str, Any]:
        logger.error(message)
        return {"status": "error", "message": message}

    def _validate_mcp_config(self) -> Optional[Dict[str, Any]]:
        if not self._mcp_server_url or not self._mcp_api_key:
            return self._error(
                "mcp_server_url and mcp_api_key must be provided to "
                "ChatseeTracker before making MCP calls."
            )
        return None

    @staticmethod
    def _import_mcp():
        try:
            from mcp import ClientSession  # noqa: WPS433
            from mcp.client.streamable_http import streamablehttp_client  # noqa: WPS433
        except ImportError as exc:
            raise RuntimeError(
                "The 'mcp' package is required for closed-loop remediation "
                "calls. Install with: pip install 'chatsee-ai[closed_loop]' "
                "or pip install 'mcp>=1.2.0'"
            ) from exc
        return ClientSession, streamablehttp_client

    @staticmethod
    def _unwrap_exc(exc: BaseException) -> BaseException:
        """
        Return the innermost 'interesting' sub-exception from a nested
        BaseExceptionGroup (anyio TaskGroups raise these), so the SDK's
        error messages carry the underlying httpx/connection error instead
        of the opaque 'unhandled errors in a TaskGroup' wrapper.
        """
        while True:
            sub = getattr(exc, "exceptions", None)
            if sub and len(sub) >= 1:
                exc = sub[0]
                continue
            return exc

    @staticmethod
    def _decode_tool_result(result) -> Any:
        """Normalise an MCP CallToolResult into a plain Python value."""
        if getattr(result, "isError", False):
            err_text = ""
            if getattr(result, "content", None):
                first = result.content[0]
                err_text = getattr(first, "text", "") or ""
            return {"status": "error", "message": err_text or "MCP tool error."}

        if not getattr(result, "content", None):
            return {}

        first = result.content[0]
        text = getattr(first, "text", None)
        if text is None:
            return {}
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return {"raw": text}

    # Default MCP retry policy for transient TCP / HTTP failures. Kept
    # deliberately small so a really unreachable server fails fast.
    _MCP_MAX_ATTEMPTS = 3
    _MCP_RETRY_BACKOFF_SECONDS = 0.5

    def _call_mcp_tool(
        self,
        tool_name: str,
        arguments: Dict[str, Any],
        timeout: Optional[int] = None,
    ) -> Any:
        """Invoke a single MCP tool over a fresh Streamable HTTP session,
        with a small bounded retry for transient TCP / HTTP errors."""
        err = self._validate_mcp_config()
        if err is not None:
            return err

        ClientSession, streamablehttp_client = self._import_mcp()
        headers = {"Authorization": f"Bearer {self._mcp_api_key}"}
        decode = self._decode_tool_result

        async def _invoke() -> Any:
            async with streamablehttp_client(
                self._mcp_server_url, headers=headers
            ) as (read, write, _):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    result = await session.call_tool(tool_name, arguments)
                    return decode(result)

        last_exc: Optional[BaseException] = None
        for attempt in range(1, self._MCP_MAX_ATTEMPTS + 1):
            try:
                return _run_coroutine_blocking(
                    _invoke(), timeout=timeout or self.timeout
                )
            except BaseException as exc:  # noqa: BLE001 — anyio raises BEG
                last_exc = exc
                inner = self._unwrap_exc(exc)
                if attempt < self._MCP_MAX_ATTEMPTS:
                    logger.warning(
                        "MCP call to '%s' failed (attempt %d/%d): %s. Retrying in %ss.",
                        tool_name, attempt, self._MCP_MAX_ATTEMPTS, inner,
                        self._MCP_RETRY_BACKOFF_SECONDS * attempt,
                    )
                    import time as _time
                    _time.sleep(self._MCP_RETRY_BACKOFF_SECONDS * attempt)

        inner = self._unwrap_exc(last_exc) if last_exc else Exception("unknown")
        return self._error(f"MCP call to '{tool_name}' failed: {inner}")

    def _call_mcp_tools_in_session(
        self,
        calls: List[tuple],
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Invoke multiple MCP tools over a single Streamable HTTP session.

        Each entry in ``calls`` is a ``(tool_name, arguments_dict)`` tuple.
        Returns ``{"status": "ok", "results": [...]}`` with one decoded
        result per call, or ``{"status": "error", "message": "..."}`` on
        session-level failure.
        """
        err = self._validate_mcp_config()
        if err is not None:
            return err

        ClientSession, streamablehttp_client = self._import_mcp()
        headers = {"Authorization": f"Bearer {self._mcp_api_key}"}
        decode = self._decode_tool_result

        async def _invoke() -> List[Any]:
            results: List[Any] = []
            async with streamablehttp_client(
                self._mcp_server_url, headers=headers
            ) as (read, write, _):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    for tool_name, args in calls:
                        r = await session.call_tool(tool_name, args)
                        results.append(decode(r))
            return results

        last_exc: Optional[BaseException] = None
        for attempt in range(1, self._MCP_MAX_ATTEMPTS + 1):
            try:
                results = _run_coroutine_blocking(
                    _invoke(), timeout=timeout or self.timeout
                )
                return {"status": "ok", "results": results}
            except BaseException as exc:  # noqa: BLE001
                last_exc = exc
                inner = self._unwrap_exc(exc)
                if attempt < self._MCP_MAX_ATTEMPTS:
                    logger.warning(
                        "MCP batch session failed (attempt %d/%d): %s. Retrying.",
                        attempt, self._MCP_MAX_ATTEMPTS, inner,
                    )
                    import time as _time
                    _time.sleep(self._MCP_RETRY_BACKOFF_SECONDS * attempt)

        inner = self._unwrap_exc(last_exc) if last_exc else Exception("unknown")
        return self._error(f"MCP batch session failed: {inner}")