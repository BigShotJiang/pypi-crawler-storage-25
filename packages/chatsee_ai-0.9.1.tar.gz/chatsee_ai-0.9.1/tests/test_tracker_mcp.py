"""
Unit tests for the MCP fetch / acknowledge / reject paths on
``ChatseeTracker``.

The MCP transport helpers are stubbed so these tests do not need a
running chatsee-mcp server.

Run with:

    pip install pytest
    pytest Chatsee-SDK-Py\ \(Updated\)/tests/test_tracker_mcp.py
"""

from unittest.mock import patch

import pytest

from chatsee.tracker import ChatseeTracker


AGENT_ID = "67b6d2b9aaaaaaaaaaaaaaaa"
TENANT_ID = "6880a5edbbbbbbbbbbbbbbbb"


def _make_tracker(**overrides) -> ChatseeTracker:
    kwargs = dict(
        agent_id=AGENT_ID,
        tenant_id=TENANT_ID,
        api_base_url="https://chatsee.test/api",
        mcp_server_url="https://mcp.chatsee.test/mcp",
        mcp_api_key="cs-test-aaaaaaaaaaaaaaaaaaaaaaaa-" + "a" * 48,
        timeout=5,
    )
    kwargs.update(overrides)
    return ChatseeTracker(**kwargs)


# ────────────────────────────── fetch_remediations ──────────────────────────────


def test_fetch_pending_calls_pull_pending_remediations():
    tracker = _make_tracker()
    expected = {
        "skills_markdown": "# Skills\n- rule",
        "failure_memory_ids": ["abc123"],
        "delivered_count": 1,
        "total_rules": 1,
    }
    with patch.object(tracker, "_call_mcp_tool", return_value=expected) as stub:
        result = tracker.fetch_remediations(mode="pending")

    stub.assert_called_once()
    tool_name = stub.call_args.args[0]
    arguments = stub.call_args.args[1]
    assert tool_name == "pull_pending_remediations"
    assert arguments == {}
    assert result == expected


def test_fetch_all_calls_get_all_skills():
    tracker = _make_tracker()
    with patch.object(tracker, "_call_mcp_tool", return_value={"total_rules": 3}) as stub:
        tracker.fetch_remediations(mode="all")
    assert stub.call_args.args[0] == "get_all_skills"


def test_fetch_rejects_bad_mode():
    tracker = _make_tracker()
    result = tracker.fetch_remediations(mode="bogus")
    assert result["status"] == "error"
    assert "Must be 'pending' or 'all'" in result["message"]


def test_fetch_requires_mcp_config_via_underlying_tool():
    # _call_mcp_tool is the one that validates config; stubbing it here
    # proves fetch_remediations delegates to it unchanged.
    tracker = _make_tracker()
    with patch.object(
        tracker,
        "_call_mcp_tool",
        return_value={"status": "error", "message": "mcp_server_url and mcp_api_key required"},
    ):
        result = tracker.fetch_remediations()
    assert result["status"] == "error"


def test_fetch_propagates_mcp_error_payload():
    tracker = _make_tracker()
    with patch.object(
        tracker,
        "_call_mcp_tool",
        return_value={"status": "error", "message": "Agent unknown"},
    ):
        result = tracker.fetch_remediations()
    assert result == {"status": "error", "message": "Agent unknown"}


# ────────────────────────────── acknowledge_remediations ────────────────────────


def test_acknowledge_uses_single_mcp_session_and_counts_applied():
    tracker = _make_tracker()
    session_response = {
        "status": "ok",
        "results": [
            {"success": True, "state": "Applied", "failure_memory_id": "id1"},
            {"success": True, "state": "Applied", "already_applied": True, "failure_memory_id": "id2"},
        ],
    }
    with patch.object(
        tracker, "_call_mcp_tools_in_session", return_value=session_response
    ) as stub:
        result = tracker.acknowledge_remediations(
            failure_memory_ids=["id1", "id2"],
            details="injected on boot",
        )

    stub.assert_called_once()
    calls = stub.call_args.args[0]
    # One acknowledge_applied call per id, carrying details.
    assert len(calls) == 2
    assert all(tool == "acknowledge_applied" for tool, _ in calls)
    assert calls[0][1] == {"failure_memory_id": "id1", "details": "injected on boot"}
    assert calls[1][1] == {"failure_memory_id": "id2", "details": "injected on boot"}
    # Idempotent re-ack shouldn't be counted as applied.
    assert result["applied_count"] == 1
    assert result["results"][0]["failure_memory_id"] == "id1"


def test_acknowledge_rejects_empty_list():
    tracker = _make_tracker()
    with patch.object(tracker, "_call_mcp_tools_in_session") as stub:
        result = tracker.acknowledge_remediations(failure_memory_ids=[])
    assert result["status"] == "error"
    stub.assert_not_called()


def test_acknowledge_surfaces_session_error():
    tracker = _make_tracker()
    with patch.object(
        tracker,
        "_call_mcp_tools_in_session",
        return_value={"status": "error", "message": "disconnected"},
    ):
        result = tracker.acknowledge_remediations(failure_memory_ids=["id1"])
    assert result == {"status": "error", "message": "disconnected"}


# ────────────────────────────── reject_remediations ─────────────────────────────


def test_reject_calls_reject_remediation_per_id_with_reason():
    tracker = _make_tracker()
    with patch.object(
        tracker,
        "_call_mcp_tools_in_session",
        return_value={
            "status": "ok",
            "results": [
                {"success": True, "state": "Rejected", "failure_memory_id": "id1"},
            ],
        },
    ) as stub:
        result = tracker.reject_remediations(
            failure_memory_ids=["id1"], reason="not applicable"
        )
    calls = stub.call_args.args[0]
    assert calls == [
        ("reject_remediation", {"failure_memory_id": "id1", "reason": "not applicable"}),
    ]
    assert result["rejected_count"] == 1


# ────────────────────────────── get_remediation_status ──────────────────────────


def test_status_all_uses_empty_args():
    tracker = _make_tracker()
    with patch.object(tracker, "_call_mcp_tool", return_value={"total": 0}) as stub:
        tracker.get_remediation_status()
    assert stub.call_args.args[0] == "get_remediation_status"
    assert stub.call_args.args[1] == {}


def test_status_single_passes_id():
    tracker = _make_tracker()
    with patch.object(tracker, "_call_mcp_tool", return_value={}) as stub:
        tracker.get_remediation_status(failure_memory_id="abc")
    assert stub.call_args.args[1] == {"failure_memory_id": "abc"}


# ────────────────────────────── helper ──────────────────────────────────────────


def test_run_coroutine_blocking_no_loop():
    from chatsee.tracker import _run_coroutine_blocking

    async def answer():
        return 42

    assert _run_coroutine_blocking(answer()) == 42


if __name__ == "__main__":  # pragma: no cover
    import sys

    sys.exit(pytest.main([__file__, "-v"]))
