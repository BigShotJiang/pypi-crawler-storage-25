from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="chatsee-ai",
    version="0.9.1",
    author="Chatsee Team",
    author_email="kunal.golani@isynergytech.com",
    description="A Python SDK for Chatsee AI.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(exclude=["build", "build.*", "tests", "tests.*"]),
    install_requires=[
        "requests>=2.31.0",
    ],
    extras_require={
        # Required for fetch_remediations() which talks to chatsee-mcp over
        # the Model Context Protocol (Streamable HTTP). Kept as an optional
        # extra so users who only emit interactions are not forced to pull
        # in the MCP client stack.
        "closed_loop": [
            "mcp>=1.2.0",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)