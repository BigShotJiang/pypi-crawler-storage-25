"""Tests for R7 — Connection Resilience.

Covers:
- TCP keepalive defaults applied during initialization
- SSL mode configuration via VELOCITY_SSL_MODE
- Connect timeout via VELOCITY_CONNECT_TIMEOUT
- RDS-specific transient error message detection
- Connection lifecycle logging
- Connection pool validation (ping) on reuse
"""

import os
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# TCP Keepalive defaults
# ---------------------------------------------------------------------------

class TestTCPKeepalive:
    """Verify keepalive params are injected into the config."""

    @patch.dict(os.environ, {
        "DBDatabase": "testdb",
        "DBHost": "localhost",
        "DBPort": "5432",
        "DBUser": "user",
        "DBPassword": "pass",
    })
    @patch("psycopg.connect", return_value=MagicMock(closed=False))
    def test_keepalive_defaults_applied(self, mock_connect):
        from velocity.db.servers.postgres import initialize

        engine = initialize(pool_enabled=False)
        config = engine.config
        assert config["keepalives"] == 1
        assert config["keepalives_idle"] == 30
        assert config["keepalives_interval"] == 10
        assert config["keepalives_count"] == 3

    @patch.dict(os.environ, {
        "DBDatabase": "testdb",
        "DBHost": "localhost",
        "DBPort": "5432",
        "DBUser": "user",
        "DBPassword": "pass",
    })
    @patch("psycopg.connect", return_value=MagicMock(closed=False))
    def test_keepalive_user_override(self, mock_connect):
        from velocity.db.servers.postgres import initialize

        engine = initialize(keepalives_idle=60, pool_enabled=False)
        assert engine.config["keepalives_idle"] == 60
        assert engine.config["keepalives"] == 1  # default still applied

    @patch.dict(os.environ, {
        "DBDatabase": "testdb",
        "DBHost": "localhost",
        "DBPort": "5432",
        "DBUser": "user",
        "DBPassword": "pass",
    })
    @patch("psycopg.connect", return_value=MagicMock(closed=False))
    def test_class_initializer_keepalive(self, mock_connect):
        from velocity.db.servers.postgres import PostgreSQLInitializer

        engine = PostgreSQLInitializer.initialize(pool_enabled=False)
        config = engine.config
        assert config["keepalives"] == 1
        assert config["keepalives_idle"] == 30


# ---------------------------------------------------------------------------
# SSL Mode
# ---------------------------------------------------------------------------

class TestSSLMode:
    """Verify VELOCITY_SSL_MODE env var flows into the config."""

    @patch.dict(os.environ, {
        "DBDatabase": "testdb",
        "DBHost": "localhost",
        "DBPort": "5432",
        "DBUser": "user",
        "DBPassword": "pass",
        "VELOCITY_SSL_MODE": "require",
    })
    @patch("psycopg.connect", return_value=MagicMock(closed=False))
    def test_ssl_mode_from_env(self, mock_connect):
        from velocity.db.servers.postgres import initialize

        engine = initialize(pool_enabled=False)
        assert engine.config["sslmode"] == "require"

    @patch.dict(os.environ, {
        "DBDatabase": "testdb",
        "DBHost": "localhost",
        "DBPort": "5432",
        "DBUser": "user",
        "DBPassword": "pass",
        "VELOCITY_SSL_MODE": "verify-full",
    })
    @patch("psycopg.connect", return_value=MagicMock(closed=False))
    def test_ssl_mode_user_override(self, mock_connect):
        from velocity.db.servers.postgres import initialize

        engine = initialize(sslmode="prefer", pool_enabled=False)
        # Explicit config takes precedence (setdefault).
        assert engine.config["sslmode"] == "prefer"

    @patch.dict(os.environ, {
        "DBDatabase": "testdb",
        "DBHost": "localhost",
        "DBPort": "5432",
        "DBUser": "user",
        "DBPassword": "pass",
    })
    @patch("psycopg.connect", return_value=MagicMock(closed=False))
    def test_no_ssl_mode_when_env_unset(self, mock_connect):
        from velocity.db.servers.postgres import initialize

        engine = initialize(pool_enabled=False)
        assert "sslmode" not in engine.config

    @patch.dict(os.environ, {
        "DBDatabase": "testdb",
        "DBHost": "localhost",
        "DBPort": "5432",
        "DBUser": "user",
        "DBPassword": "pass",
        "VELOCITY_SSL_MODE": "require",
    })
    @patch("psycopg.connect", return_value=MagicMock(closed=False))
    def test_class_initializer_ssl(self, mock_connect):
        from velocity.db.servers.postgres import PostgreSQLInitializer

        engine = PostgreSQLInitializer.initialize(pool_enabled=False)
        assert engine.config["sslmode"] == "require"


# ---------------------------------------------------------------------------
# Connect Timeout
# ---------------------------------------------------------------------------

class TestConnectTimeout:
    """Verify VELOCITY_CONNECT_TIMEOUT env var is read by Engine."""

    def test_default_timeout_is_5(self):
        from velocity.db.core.engine import Engine

        driver = MagicMock()
        driver.connect.return_value = MagicMock(closed=False)
        engine = Engine(driver, {"dbname": "test"}, MagicMock(), pool_enabled=False)
        # connect_timeout defaults to 5 when env not set.
        conn = engine.connect()
        call_kwargs = driver.connect.call_args
        assert call_kwargs[1].get("connect_timeout", call_kwargs[0][0] if call_kwargs[0] else None) is not None

    @patch.dict(os.environ, {"VELOCITY_CONNECT_TIMEOUT": "10"})
    def test_env_var_override(self):
        from velocity.db.core.engine import Engine

        driver = MagicMock()
        driver.connect.return_value = MagicMock(closed=False)
        engine = Engine(driver, {"dbname": "test"}, MagicMock(), pool_enabled=False)
        engine.connect()
        call_kwargs = driver.connect.call_args[1]
        assert call_kwargs.get("connect_timeout") == 10

    def test_explicit_param_overrides_env(self):
        from velocity.db.core.engine import Engine

        driver = MagicMock()
        driver.connect.return_value = MagicMock(closed=False)
        engine = Engine(driver, {"dbname": "test"}, MagicMock(),
                        connect_timeout=3, pool_enabled=False)
        engine.connect()
        call_kwargs = driver.connect.call_args[1]
        assert call_kwargs.get("connect_timeout") == 3


# ---------------------------------------------------------------------------
# RDS Transient Error Detection
# ---------------------------------------------------------------------------

class TestRDSTransientErrors:
    """Verify RDS-specific error messages are detected as transient."""

    @pytest.fixture
    def sql_cls(self):
        from velocity.db.servers.postgres.sql import SQL
        return SQL

    def test_server_closed_connection(self, sql_cls):
        assert sql_cls.is_connection_error_message(
            "server closed the connection unexpectedly"
        )

    def test_connection_reset_by_peer(self, sql_cls):
        assert sql_cls.is_connection_error_message("connection reset by peer")

    def test_rds_recovery_mode(self, sql_cls):
        assert sql_cls.is_connection_error_message(
            "the database system is in recovery mode"
        )

    def test_rds_too_many_connections(self, sql_cls):
        assert sql_cls.is_connection_error_message("too many connections")

    def test_rds_remaining_slots_reserved(self, sql_cls):
        assert sql_cls.is_connection_error_message(
            "remaining connection slots are reserved"
        )

    def test_rds_canceling_recovery_conflict(self, sql_cls):
        assert sql_cls.is_connection_error_message(
            "canceling statement due to conflict with recovery"
        )

    def test_communication_link_failure(self, sql_cls):
        assert sql_cls.is_connection_error_message("communication link failure")

    def test_connection_not_available(self, sql_cls):
        assert sql_cls.is_connection_error_message("connection is not available")

    def test_terminating_connection(self, sql_cls):
        assert sql_cls.is_connection_error_message(
            "terminating connection due to administrator command"
        )

    def test_database_starting_up(self, sql_cls):
        assert sql_cls.is_connection_error_message(
            "the database system is starting up"
        )

    def test_normal_error_not_transient(self, sql_cls):
        assert not sql_cls.is_connection_error_message(
            "column \"foo\" does not exist"
        )

    def test_empty_message_not_transient(self, sql_cls):
        assert not sql_cls.is_connection_error_message("")

    def test_none_not_transient(self, sql_cls):
        assert not sql_cls.is_connection_error_message(None)

    def test_transient_delegates_to_connection(self, sql_cls):
        # is_transient_connection_error_message delegates to is_connection_error_message
        assert sql_cls.is_transient_connection_error_message(
            "server closed the connection unexpectedly"
        )
        assert not sql_cls.is_transient_connection_error_message(
            "syntax error at position 42"
        )


# ---------------------------------------------------------------------------
# Connection Pool Validation
# ---------------------------------------------------------------------------

class TestPoolValidation:
    """Verify pool validates connections before handing them out."""

    def test_dead_connection_discarded(self):
        from velocity.db.core.engine import ConnectionPool

        connect_fn = MagicMock()
        fresh_conn = MagicMock(closed=False)
        connect_fn.return_value = fresh_conn

        pool = ConnectionPool(connect_fn, minconn=0, maxconn=2, validate=False)

        # Manually inject a dead connection.
        dead_conn = MagicMock(closed=True)
        pool._pool.append(dead_conn)

        conn = pool.getconn()
        # The dead one should be skipped, a fresh one created.
        assert conn is fresh_conn
        dead_conn.close.assert_called_once()

    def test_validated_connection_reused(self):
        from velocity.db.core.engine import ConnectionPool

        good_conn = MagicMock(closed=False)
        cursor_mock = MagicMock()
        good_conn.cursor.return_value = cursor_mock

        connect_fn = MagicMock(return_value=good_conn)
        pool = ConnectionPool(connect_fn, minconn=0, maxconn=2, validate=True)

        # Put a connection back, then get it.
        pool._pool.append(good_conn)
        pool._total_created = 1
        pool._available.release()  # simulate returning a slot
        conn = pool.getconn()
        assert conn is good_conn

    def test_validation_failure_creates_new(self):
        from velocity.db.core.engine import ConnectionPool

        stale_conn = MagicMock(closed=False)
        stale_cursor = MagicMock()
        stale_cursor.execute.side_effect = Exception("connection lost")
        stale_conn.cursor.return_value = stale_cursor

        fresh_conn = MagicMock(closed=False)
        connect_fn = MagicMock(return_value=fresh_conn)

        pool = ConnectionPool(connect_fn, minconn=0, maxconn=2, validate=True)
        pool._pool.append(stale_conn)
        pool._total_created = 1
        pool._available.release()

        conn = pool.getconn()
        assert conn is fresh_conn
        stale_conn.close.assert_called_once()


# ---------------------------------------------------------------------------
# Connection Retry with Transient Errors
# ---------------------------------------------------------------------------

class TestConnectionRetry:
    """Verify exec_function retries on transient connection errors."""

    def test_retries_on_transient_error(self):
        from velocity.db.core.engine import Engine
        from velocity.db import exceptions

        driver = MagicMock()
        conn = MagicMock(closed=False)
        driver.connect.return_value = conn

        sql = MagicMock()
        sql.server = "PostGreSQL"
        sql.is_transient_connection_error_message.return_value = True

        engine = Engine(driver, {"dbname": "test"}, sql, pool_enabled=False)

        call_count = 0

        def flaky_fn(tx):
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise exceptions.DbConnectionError(
                    "server closed the connection unexpectedly"
                )
            return "success"

        tx = engine.transaction()
        tx.connection = conn
        result = engine.exec_function(flaky_fn, tx, tx)
        assert result == "success"
        assert call_count == 3

    def test_gives_up_after_6_retries(self):
        from velocity.db.core.engine import Engine
        from velocity.db import exceptions

        driver = MagicMock()
        conn = MagicMock(closed=False)
        driver.connect.return_value = conn

        sql = MagicMock()
        sql.server = "PostGreSQL"
        sql.is_transient_connection_error_message.return_value = True

        engine = Engine(driver, {"dbname": "test"}, sql, pool_enabled=False)

        def always_fails(tx):
            raise exceptions.DbConnectionError("server closed the connection unexpectedly")

        tx = engine.transaction()
        tx.connection = conn
        with pytest.raises(exceptions.DbConnectionError):
            engine.exec_function(always_fails, tx, tx)
