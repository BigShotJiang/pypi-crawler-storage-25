"""
Tests for R6 — Prepared statement support via psycopg v3.
"""

import os
import pytest
from unittest.mock import MagicMock, patch, PropertyMock

from velocity.db.core.engine import Engine
from velocity.db.core.transaction import Transaction


# ── Engine.prepare_enabled ──────────────────────────────────────────


class TestPrepareEnabledConfig:
    """Verify the Engine.prepare_enabled property and env-var control."""

    def test_default_is_false(self):
        driver = MagicMock()
        engine = Engine(driver, {}, MagicMock(), pool_enabled=False)
        assert engine.prepare_enabled is False

    def test_explicit_true(self):
        driver = MagicMock()
        engine = Engine(driver, {}, MagicMock(), pool_enabled=False, prepare_enabled=True)
        assert engine.prepare_enabled is True

    def test_explicit_false(self):
        driver = MagicMock()
        engine = Engine(driver, {}, MagicMock(), pool_enabled=False, prepare_enabled=False)
        assert engine.prepare_enabled is False

    @patch.dict(os.environ, {"VELOCITY_PREPARE_ENABLED": "true"})
    def test_env_var_true(self):
        driver = MagicMock()
        engine = Engine(driver, {}, MagicMock(), pool_enabled=False)
        assert engine.prepare_enabled is True

    @patch.dict(os.environ, {"VELOCITY_PREPARE_ENABLED": "false"})
    def test_env_var_false(self):
        driver = MagicMock()
        engine = Engine(driver, {}, MagicMock(), pool_enabled=False)
        assert engine.prepare_enabled is False

    @patch.dict(os.environ, {"VELOCITY_PREPARE_ENABLED": "1"})
    def test_env_var_1(self):
        driver = MagicMock()
        engine = Engine(driver, {}, MagicMock(), pool_enabled=False)
        assert engine.prepare_enabled is True

    def test_explicit_overrides_env(self):
        """Explicit kwarg takes precedence over environment variable."""
        with patch.dict(os.environ, {"VELOCITY_PREPARE_ENABLED": "true"}):
            driver = MagicMock()
            engine = Engine(driver, {}, MagicMock(), pool_enabled=False, prepare_enabled=False)
            assert engine.prepare_enabled is False


# ── Transaction._execute with prepare ───────────────────────────────


class TestExecutePrepare:
    """Verify that _execute passes prepare flag to cursor.execute."""

    def _make_tx(self, prepare_enabled=False):
        engine = MagicMock()
        engine.pool_enabled = False
        engine.prepare_enabled = prepare_enabled

        conn = MagicMock()
        conn.closed = False  # psycopg v3 returns bool
        mock_cursor = MagicMock()
        mock_cursor.description = [("col1",)]
        mock_cursor.fetchone.return_value = None
        conn.cursor.return_value = mock_cursor
        tx = Transaction(engine, connection=conn)
        return tx, mock_cursor

    def test_prepare_false_by_default(self):
        tx, cursor = self._make_tx(prepare_enabled=False)
        tx._execute("SELECT 1", (42,))
        cursor.execute.assert_called_once_with("SELECT 1", (42,), prepare=False)

    def test_prepare_true_when_engine_enabled(self):
        tx, cursor = self._make_tx(prepare_enabled=True)
        tx._execute("SELECT 1", (42,))
        cursor.execute.assert_called_once_with("SELECT 1", (42,), prepare=True)

    def test_prepare_explicit_override(self):
        """Explicit prepare=True overrides engine default of False."""
        tx, cursor = self._make_tx(prepare_enabled=False)
        tx._execute("SELECT 1", (42,), prepare=True)
        cursor.execute.assert_called_once_with("SELECT 1", (42,), prepare=True)

    def test_prepare_explicit_false_overrides_engine(self):
        """Explicit prepare=False overrides engine default of True."""
        tx, cursor = self._make_tx(prepare_enabled=True)
        tx._execute("SELECT 1", (42,), prepare=False)
        cursor.execute.assert_called_once_with("SELECT 1", (42,), prepare=False)

    def test_no_params_with_prepare(self):
        tx, cursor = self._make_tx(prepare_enabled=True)
        tx._execute("SELECT 1")
        cursor.execute.assert_called_once_with("SELECT 1", prepare=True)

    def test_fallback_when_prepare_not_supported(self):
        """Non-psycopg3 drivers that don't support prepare= keyword."""
        engine = MagicMock()
        engine.pool_enabled = False
        engine.prepare_enabled = True

        conn = MagicMock()
        conn.closed = False
        mock_cursor = MagicMock()
        mock_cursor.description = [("col1",)]
        mock_cursor.fetchone.return_value = None
        # First call with prepare= raises TypeError, second without succeeds.
        mock_cursor.execute.side_effect = [TypeError("unexpected keyword"), None]
        conn.cursor.return_value = mock_cursor
        tx = Transaction(engine, connection=conn)

        tx._execute("SELECT 1", (42,))
        # Should have been called twice — once with prepare, once without.
        assert mock_cursor.execute.call_count == 2
        mock_cursor.execute.assert_any_call("SELECT 1", (42,), prepare=True)
        mock_cursor.execute.assert_any_call("SELECT 1", (42,))


# ── Transaction.execute public API ──────────────────────────────────


class TestExecutePublicAPI:
    """Verify that the public execute() passes prepare through."""

    def _make_tx(self):
        engine = MagicMock()
        engine.pool_enabled = False
        engine.prepare_enabled = False

        conn = MagicMock()
        conn.closed = False
        mock_cursor = MagicMock()
        mock_cursor.description = [("col1",)]
        mock_cursor.fetchone.return_value = None
        conn.cursor.return_value = mock_cursor
        tx = Transaction(engine, connection=conn)
        return tx, mock_cursor

    def test_execute_forwards_prepare(self):
        tx, cursor = self._make_tx()
        tx.execute("SELECT 1", prepare=True)
        cursor.execute.assert_called_once_with("SELECT 1", prepare=True)

    def test_execute_default_prepare_none(self):
        tx, cursor = self._make_tx()
        tx.execute("SELECT 1")
        # With engine.prepare_enabled=False, effective prepare is False.
        cursor.execute.assert_called_once_with("SELECT 1", prepare=False)
