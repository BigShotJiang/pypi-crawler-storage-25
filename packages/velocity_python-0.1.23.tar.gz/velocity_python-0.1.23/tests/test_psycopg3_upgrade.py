"""
Tests for psycopg v3 migration — verifying driver compatibility.
"""

import os
import pytest
from unittest.mock import MagicMock, patch

from velocity.db.core.engine import Engine
from velocity.db.core.transaction import Transaction


# ── Driver import ───────────────────────────────────────────────────


class TestPsycopgImport:
    """Verify that psycopg (v3) is importable and has expected API."""

    def test_import_psycopg(self):
        import psycopg
        assert hasattr(psycopg, "connect")
        assert hasattr(psycopg, "Connection")
        assert hasattr(psycopg, "Error")

    def test_psycopg_version_is_v3(self):
        import psycopg
        major = int(psycopg.__version__.split(".")[0])
        assert major >= 3

    def test_error_has_sqlstate(self):
        import psycopg
        e = psycopg.Error("test")
        assert hasattr(e, "sqlstate")

    def test_error_has_no_pgcode(self):
        """psycopg v3 errors don't have pgcode; they use sqlstate."""
        import psycopg
        e = psycopg.Error("test")
        assert not hasattr(e, "pgcode")


# ── Postgres initializer uses psycopg ──────────────────────────────


class TestPostgresInitializer:
    """Verify the PostgreSQL initializer uses psycopg (v3)."""

    def test_class_initializer_uses_psycopg(self):
        from velocity.db.servers.postgres import PostgreSQLInitializer

        mock_psycopg = MagicMock()
        config = {
            "database": "testdb",
            "host": "localhost",
            "user": "user",
            "password": "pass",
        }
        with patch.dict("sys.modules", {"psycopg": mock_psycopg}):
            engine = PostgreSQLInitializer.initialize(config)
            assert engine.driver is mock_psycopg

    def test_database_key_remapped_to_dbname(self):
        from velocity.db.servers.postgres import PostgreSQLInitializer

        mock_psycopg = MagicMock()
        config = {
            "database": "testdb",
            "host": "localhost",
            "user": "user",
            "password": "pass",
        }
        with patch.dict("sys.modules", {"psycopg": mock_psycopg}):
            engine = PostgreSQLInitializer.initialize(config)
            # The config should now use 'dbname', not 'database'.
            assert "dbname" in engine.config
            assert "database" not in engine.config
            assert engine.config["dbname"] == "testdb"

    def test_backward_compat_function_uses_psycopg(self):
        from velocity.db.servers.postgres import initialize

        mock_psycopg = MagicMock()
        with patch.dict(os.environ, {
            "DBDatabase": "testdb",
            "DBHost": "localhost",
            "DBPort": "5432",
            "DBUser": "user",
            "DBPassword": "pass",
        }), patch.dict("sys.modules", {"psycopg": mock_psycopg}):
            engine = initialize()
            assert engine.driver is mock_psycopg
            assert "dbname" in engine.config
            assert engine.config["dbname"] == "testdb"


# ── get_error uses sqlstate ─────────────────────────────────────────


class TestGetErrorPsycopg3:
    """Verify SQL.get_error() handles psycopg v3 error attributes."""

    def test_sqlstate_attribute(self):
        from velocity.db.servers.postgres.sql import SQL

        class FakeError(Exception):
            sqlstate = "42P01"

        code, msg = SQL.get_error(FakeError("relation does not exist"))
        assert code == "42P01"

    def test_pgcode_fallback(self):
        """For any remaining psycopg2-style errors, pgcode still works."""
        from velocity.db.servers.postgres.sql import SQL

        class FakeError(Exception):
            pgcode = "23505"

        code, msg = SQL.get_error(FakeError("unique violation"))
        assert code == "23505"

    def test_neither_attribute(self):
        from velocity.db.servers.postgres.sql import SQL

        code, msg = SQL.get_error(RuntimeError("some error"))
        assert code is None
        assert "some error" in msg


# ── _execute_values without psycopg2 ───────────────────────────────


class TestExecuteValuesNoPsycopg2:
    """Verify _execute_values works without psycopg2.extras."""

    def test_basic_insert(self):
        engine = MagicMock()
        engine.pool_enabled = False
        conn = MagicMock()
        tx = Transaction(engine, connection=conn)

        mock_cursor = MagicMock()
        mock_cursor.rowcount = 3
        tx.cursor = MagicMock(return_value=mock_cursor)

        result = tx._execute_values(
            "INSERT INTO t (a, b) VALUES %s",
            [(1, "x"), (2, "y"), (3, "z")],
            template="(%s, %s)",
        )

        assert result == 3
        mock_cursor.execute.assert_called_once()
        sql_arg = mock_cursor.execute.call_args[0][0]
        assert "(%s, %s), (%s, %s), (%s, %s)" in sql_arg

    def test_auto_template(self):
        """When no template provided, it's inferred from arg tuple width."""
        engine = MagicMock()
        engine.pool_enabled = False
        conn = MagicMock()
        tx = Transaction(engine, connection=conn)

        mock_cursor = MagicMock()
        mock_cursor.rowcount = 2
        tx.cursor = MagicMock(return_value=mock_cursor)

        result = tx._execute_values(
            "INSERT INTO t (a, b) VALUES %s",
            [(1, 2), (3, 4)],
        )

        assert result == 2
        sql_arg = mock_cursor.execute.call_args[0][0]
        assert "(%s, %s), (%s, %s)" in sql_arg
        params = mock_cursor.execute.call_args[0][1]
        assert params == [1, 2, 3, 4]

    def test_page_size_batching(self):
        """Large batches are split into pages."""
        engine = MagicMock()
        engine.pool_enabled = False
        conn = MagicMock()
        tx = Transaction(engine, connection=conn)

        mock_cursor = MagicMock()
        mock_cursor.rowcount = 2
        tx.cursor = MagicMock(return_value=mock_cursor)

        rows = [(i,) for i in range(5)]
        result = tx._execute_values(
            "INSERT INTO t (a) VALUES %s",
            rows,
            template="(%s)",
            page_size=2,
        )

        # 5 rows with page_size=2 → 3 execute calls (2+2+1)
        assert mock_cursor.execute.call_count == 3
        # Total rowcount: 2+2+2 = 6 (mock returns 2 per call)
        assert result == 6


# ── Connection.closed compatibility ─────────────────────────────────


class TestConnectionClosedCompat:
    """Verify that boolean .closed (psycopg v3) works in pool validation."""

    def test_bool_closed_false(self):
        """psycopg v3 returns False for open connections."""
        from velocity.db.core.engine import ConnectionPool

        mock_connect = MagicMock()
        conn = MagicMock()
        conn.closed = False  # psycopg v3 style
        mock_connect.return_value = conn

        pool = ConnectionPool(mock_connect, minconn=0, maxconn=1)
        pool._pool.append(conn)
        pool._total_created = 1

        got = pool.getconn()
        assert got is conn

    def test_bool_closed_true_discards(self):
        """psycopg v3 returns True for closed connections → pool discards."""
        from velocity.db.core.engine import ConnectionPool

        closed_conn = MagicMock()
        closed_conn.closed = True  # psycopg v3 style

        fresh_conn = MagicMock()
        fresh_conn.closed = False

        call_count = [0]
        def connect_fn():
            call_count[0] += 1
            return fresh_conn

        pool = ConnectionPool(connect_fn, minconn=0, maxconn=2)
        pool._pool.append(closed_conn)
        pool._total_created = 1

        got = pool.getconn()
        # Should have discarded closed_conn and created a new one.
        assert got is fresh_conn
