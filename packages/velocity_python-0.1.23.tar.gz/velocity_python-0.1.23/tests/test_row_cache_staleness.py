"""
Tests for R9 — Row Cache Staleness: cache_ttl, with_lock(), no_cache().
"""

import time
import pytest
from unittest.mock import MagicMock, call, patch

from velocity.db.core.row import Row


def _make_row(cache=None, pk=None, cache_ttl=None, no_cache=False):
    """Create a Row with a mocked table, bypassing DB access."""
    table = MagicMock()
    table.name = "test_table"
    base_data = cache or {
        "sys_id": 1,
        "name": "Alice",
        "balance": 100,
    }
    table.select.return_value.as_dict.return_value.one.return_value = dict(base_data)
    table.update_or_insert = MagicMock()

    row = Row.__new__(Row)
    object.__setattr__(row, "table", table)
    object.__setattr__(row, "pk", pk or {"sys_id": 1})
    object.__setattr__(row, "_cache", dict(cache) if cache else None)
    object.__setattr__(row, "_column_set", None)
    object.__setattr__(row, "_batching", False)
    object.__setattr__(row, "_pending", {})
    object.__setattr__(row, "_cache_ttl", cache_ttl)
    object.__setattr__(row, "_cache_time", None)
    object.__setattr__(row, "_no_cache", no_cache)
    return row


# ──────────────────────────────────────────────────────────────────────
# cache_ttl tests
# ──────────────────────────────────────────────────────────────────────


class TestCacheTTL:
    """Tests for time-based cache invalidation."""

    def test_cache_used_within_ttl(self):
        """Within TTL, reads should come from cache (no extra DB call)."""
        row = _make_row(
            cache={"sys_id": 1, "name": "Alice", "balance": 100},
            cache_ttl=10,
        )
        # Simulate cache_time as recent
        object.__setattr__(row, "_cache_time", time.monotonic())

        assert row["name"] == "Alice"
        assert row["balance"] == 100
        # No DB call — cache was fresh
        row.table.select.assert_not_called()

    def test_cache_expires_after_ttl(self):
        """After TTL, the next read should re-fetch from DB."""
        row = _make_row(
            cache={"sys_id": 1, "name": "Alice", "balance": 100},
            cache_ttl=0.01,  # 10ms TTL
        )
        # Set cache_time to far in the past
        object.__setattr__(row, "_cache_time", time.monotonic() - 1)

        # Configure what DB returns on re-fetch
        row.table.select.return_value.as_dict.return_value.one.return_value = {
            "sys_id": 1,
            "name": "Bob",
            "balance": 200,
        }

        assert row["name"] == "Bob"
        row.table.select.assert_called_once()

    def test_no_ttl_caches_indefinitely(self):
        """Without cache_ttl, cache never expires on its own."""
        row = _make_row(
            cache={"sys_id": 1, "name": "Alice", "balance": 100},
        )
        # Set cache_time to distant past
        object.__setattr__(row, "_cache_time", time.monotonic() - 9999)

        assert row["name"] == "Alice"
        row.table.select.assert_not_called()

    def test_cache_ttl_via_table_row(self):
        """table.row(key, cache_ttl=N) should propagate to the Row."""
        table = MagicMock()
        table.name = "test"
        table.select.return_value.as_dict.return_value.one.return_value = {
            "sys_id": 42,
            "name": "Carol",
        }

        from velocity.db.core.table import Table
        # Use Row directly since Table.row calls Row()
        row = Row(table, {"sys_id": 42}, cache_ttl=5)
        assert row._cache_ttl == 5

    def test_ttl_cache_time_set_on_first_fetch(self):
        """_cache_time should be set when cache is first populated."""
        row = _make_row(cache_ttl=10)
        assert row._cache_time is None

        before = time.monotonic()
        _ = row["name"]
        after = time.monotonic()

        assert row._cache_time is not None
        assert before <= row._cache_time <= after


# ──────────────────────────────────────────────────────────────────────
# no_cache tests
# ──────────────────────────────────────────────────────────────────────


class TestNoCache:
    """Tests for no_cache mode — every read goes to DB."""

    def test_no_cache_always_fetches(self):
        """In no_cache mode, every __getitem__ call should hit the DB."""
        row = _make_row(no_cache=True)

        _ = row["name"]
        _ = row["name"]

        # Should have fetched twice — no caching
        assert row.table.select.call_count == 2

    def test_no_cache_returns_fresh_data(self):
        """no_cache should always return the latest DB data."""
        row = _make_row(no_cache=True)

        # First read
        row.table.select.return_value.as_dict.return_value.one.return_value = {
            "sys_id": 1, "name": "Alice", "balance": 100,
        }
        assert row["balance"] == 100

        # Simulate external update
        row.table.select.return_value.as_dict.return_value.one.return_value = {
            "sys_id": 1, "name": "Alice", "balance": 200,
        }
        assert row["balance"] == 200

    def test_no_cache_from_row_method(self):
        """Row.no_cache() should return a new Row with _no_cache=True."""
        row = _make_row(
            cache={"sys_id": 1, "name": "Alice", "balance": 100},
        )
        fresh = row.no_cache()

        assert fresh._no_cache is True
        assert fresh.pk == row.pk
        assert fresh.table is row.table

    def test_no_cache_does_not_store_cache(self):
        """In no_cache mode, _cache should remain None after reads."""
        row = _make_row(no_cache=True)
        _ = row["name"]

        assert row._cache is None

    def test_to_dict_in_no_cache_mode(self):
        """to_dict() should work in no_cache mode (fresh from DB)."""
        row = _make_row(no_cache=True)
        row.table.select.return_value.as_dict.return_value.one.return_value = {
            "sys_id": 1, "name": "Alice",
        }
        d = row.to_dict()
        assert d == {"sys_id": 1, "name": "Alice"}

    def test_no_cache_iter(self):
        """Iteration in no_cache mode should fetch from DB."""
        row = _make_row(no_cache=True)
        row.table.select.return_value.as_dict.return_value.one.return_value = {
            "sys_id": 1, "name": "Alice",
        }
        keys = list(row)
        assert "sys_id" in keys
        assert "name" in keys


# ──────────────────────────────────────────────────────────────────────
# with_lock tests
# ──────────────────────────────────────────────────────────────────────


class TestWithLock:
    """Tests for Row.with_lock() — SELECT FOR UPDATE + cache clear."""

    def test_with_lock_issues_select_for_update(self):
        """with_lock() should call table.select with lock=True."""
        row = _make_row(
            cache={"sys_id": 1, "name": "Alice", "balance": 100},
        )
        result = row.with_lock()

        row.table.select.assert_called_once_with(where={"sys_id": 1}, lock=True)
        assert result is row  # returns self for chaining

    def test_with_lock_clears_cache(self):
        """with_lock() should invalidate the cache."""
        row = _make_row(
            cache={"sys_id": 1, "name": "Alice", "balance": 100},
        )
        assert row._cache is not None

        row.with_lock()

        assert row._cache is None
        assert row._column_set is None

    def test_with_lock_next_read_refetches(self):
        """After with_lock(), the next read should fetch from DB."""
        row = _make_row(
            cache={"sys_id": 1, "name": "Alice", "balance": 100},
        )
        # After with_lock, configure DB to return updated data
        row.with_lock()
        row.table.select.return_value.as_dict.return_value.one.return_value = {
            "sys_id": 1, "name": "Alice", "balance": 999,
        }

        assert row["balance"] == 999

    def test_with_lock_chaining(self):
        """with_lock() should support chaining: row.with_lock()['col']."""
        row = _make_row(
            cache={"sys_id": 1, "name": "Alice", "balance": 100},
        )
        row.table.select.return_value.as_dict.return_value.one.return_value = {
            "sys_id": 1, "name": "Alice", "balance": 500,
        }

        balance = row.with_lock()["balance"]
        assert balance == 500


# ──────────────────────────────────────────────────────────────────────
# invalidate / refresh interaction with new fields
# ──────────────────────────────────────────────────────────────────────


class TestInvalidateRefresh:
    """Verify invalidate() and refresh() work correctly with new cache fields."""

    def test_invalidate_clears_cache_time(self):
        """invalidate() should clear _cache and _cache_time."""
        row = _make_row(
            cache={"sys_id": 1, "name": "Alice"},
            cache_ttl=10,
        )
        object.__setattr__(row, "_cache_time", time.monotonic())

        row.invalidate()

        assert row._cache is None
        assert row._column_set is None

    def test_refresh_resets_cache_time(self):
        """refresh() should re-fetch and update _cache_time."""
        row = _make_row(cache_ttl=10)

        before = time.monotonic()
        row.refresh()
        after = time.monotonic()

        assert row._cache is not None
        assert row._cache_time is not None
        assert before <= row._cache_time <= after

    def test_setitem_invalidates_cache_time(self):
        """__setitem__ should clear both _cache and allow re-fetch with fresh _cache_time."""
        row = _make_row(
            cache={"sys_id": 1, "name": "Alice", "balance": 100},
            cache_ttl=10,
        )
        object.__setattr__(row, "_cache_time", time.monotonic() - 100)

        row["name"] = "Bob"

        # Cache should be invalidated
        assert row._cache is None

        # Next read re-fetches
        row.table.select.return_value.as_dict.return_value.one.return_value = {
            "sys_id": 1, "name": "Bob", "balance": 100,
        }
        before = time.monotonic()
        _ = row["name"]
        assert row._cache_time >= before
