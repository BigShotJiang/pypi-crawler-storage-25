"""
Tests for R2 — Batch Operations (insert_many, upsert_many, update_many).
"""

import pytest
from unittest.mock import MagicMock, patch, call

from velocity.db.servers.postgres.sql import SQL
from velocity.db.servers.tablehelper import TableHelper


# ── SQL generation tests ────────────────────────────────────────────


class TestInsertManySQL:
    """Tests for SQL.insert_many()."""

    def test_basic_insert_many(self):
        rows = [
            {"name": "Alice", "age": 30},
            {"name": "Bob", "age": 25},
        ]
        sql, args, template = SQL.insert_many("users", rows)

        assert "INSERT INTO" in sql
        assert "users" in sql
        assert "VALUES %s" in sql
        assert len(args) == 2
        assert args[0] == ("Alice", 30)
        assert args[1] == ("Bob", 25)

    def test_empty_rows_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            SQL.insert_many("users", [])

    def test_single_row(self):
        rows = [{"name": "Alice"}]
        sql, args, template = SQL.insert_many("users", rows)

        assert len(args) == 1
        assert args[0] == ("Alice",)

    def test_union_of_columns(self):
        """Rows with different keys should produce the union of all columns."""
        rows = [
            {"name": "Alice", "age": 30},
            {"name": "Bob", "email": "bob@example.com"},
        ]
        sql, args, template = SQL.insert_many("users", rows)

        # All three columns should appear
        assert "name" in sql
        assert "age" in sql
        assert "email" in sql

        # Row 1 has no email → None
        assert args[0] == ("Alice", 30, None)
        # Row 2 has no age → None
        assert args[1] == ("Bob", None, "bob@example.com")

    def test_special_values_uniform(self):
        """When all rows have the same @@value for a column, it's inlined."""
        rows = [
            {"name": "Alice", "created": "@@CURRENT_TIMESTAMP"},
            {"name": "Bob", "created": "@@CURRENT_TIMESTAMP"},
        ]
        sql, args, template = SQL.insert_many("users", rows)

        # The template should contain the literal CURRENT_TIMESTAMP
        assert "CURRENT_TIMESTAMP" in template
        # Only 'name' should be in the args
        assert args[0] == ("Alice",)
        assert args[1] == ("Bob",)

    def test_special_values_mixed(self):
        """When @@values differ across rows, they go through as params."""
        rows = [
            {"name": "Alice", "status": "@@CURRENT_TIMESTAMP"},
            {"name": "Bob", "status": "active"},
        ]
        sql, args, template = SQL.insert_many("users", rows)

        # Both should be in args since they differ
        assert len(args[0]) == 2
        assert len(args[1]) == 2

    def test_reserved_word_columns_quoted(self):
        """Column names that are reserved words should be quoted."""
        rows = [{"order": 1, "name": "test"}]
        sql, args, template = SQL.insert_many("users", rows)

        # 'order' is a reserved word and should be quoted
        assert '"order"' in sql or "order" in sql.lower()

    def test_template_format(self):
        """Template should have the right number of placeholders."""
        rows = [{"a": 1, "b": 2, "c": 3}]
        sql, args, template = SQL.insert_many("t", rows)

        # Template should have 3 %s placeholders
        assert template.count("%s") == 3


class TestMergeManySQL:
    """Tests for SQL.merge_many()."""

    def _mock_tx(self, pkeys):
        """Create a mock transaction that returns given primary keys."""
        tx = MagicMock()
        table_mock = MagicMock()
        table_mock.primary_keys.return_value = pkeys
        tx.table.return_value = table_mock
        return tx

    def test_basic_merge_many(self):
        tx = self._mock_tx(["sys_id"])
        rows = [
            {"sys_id": 1, "name": "Alice"},
            {"sys_id": 2, "name": "Bob"},
        ]
        sql, args, template = SQL.merge_many(tx, "users", rows)

        assert "INSERT INTO" in sql
        assert "ON CONFLICT" in sql
        assert "DO UPDATE" in sql
        assert "EXCLUDED" in sql
        assert len(args) == 2

    def test_empty_rows_raises(self):
        tx = self._mock_tx(["sys_id"])
        with pytest.raises(ValueError, match="non-empty"):
            SQL.merge_many(tx, "users", [])

    def test_pk_auto_detect(self):
        tx = self._mock_tx(["id"])
        rows = [{"id": 1, "name": "Alice"}]
        sql, args, template = SQL.merge_many(tx, "users", rows)

        assert "ON CONFLICT" in sql

    def test_pk_string(self):
        tx = self._mock_tx([])
        rows = [{"code": "A", "name": "Alice"}]
        sql, args, template = SQL.merge_many(tx, "items", rows, pk="code")

        assert "ON CONFLICT" in sql

    def test_pk_list(self):
        tx = self._mock_tx([])
        rows = [{"a": 1, "b": 2, "val": "x"}]
        sql, args, template = SQL.merge_many(tx, "t", rows, pk=["a", "b"])

        assert "ON CONFLICT" in sql

    def test_pk_only_does_nothing(self):
        """When all columns are PK columns, should DO NOTHING."""
        tx = self._mock_tx([])
        rows = [{"a": 1, "b": 2}]
        sql, args, template = SQL.merge_many(tx, "t", rows, pk=["a", "b"])

        assert "DO NOTHING" in sql

    def test_no_pk_raises(self):
        tx = self._mock_tx([])  # no primary keys
        rows = [{"name": "Alice"}]
        with pytest.raises(ValueError, match="Primary key"):
            SQL.merge_many(tx, "users", rows)

    def test_merge_many_union_columns(self):
        """Rows with different keys should produce union of columns."""
        tx = self._mock_tx(["id"])
        rows = [
            {"id": 1, "name": "Alice"},
            {"id": 2, "email": "bob@example.com"},
        ]
        sql, args, template = SQL.merge_many(tx, "users", rows)

        assert "name" in sql
        assert "email" in sql


# ── Transaction._execute_values tests ───────────────────────────────


class TestTransactionExecuteValues:
    """Tests for Transaction._execute_values()."""

    def test_calls_execute_values(self):
        from velocity.db.core.transaction import Transaction

        engine = MagicMock()
        engine.pool_enabled = False
        conn = MagicMock()
        tx = Transaction(engine, connection=conn)

        mock_cursor = MagicMock()
        mock_cursor.rowcount = 3
        tx.cursor = MagicMock(return_value=mock_cursor)

        result = tx._execute_values(
            "INSERT INTO t (a) VALUES %s",
            [(1,), (2,), (3,)],
            template="(%s)",
        )

        # With the new implementation, cursor.execute is called directly
        # with the expanded VALUES clause.
        mock_cursor.execute.assert_called_once()
        call_args = mock_cursor.execute.call_args
        assert "INSERT INTO t (a) VALUES (%s), (%s), (%s)" == call_args[0][0]
        assert [1, 2, 3] == call_args[0][1]
        assert result == 3

    def test_connects_if_needed(self):
        from velocity.db.core.transaction import Transaction

        engine = MagicMock()
        engine.pool_enabled = False
        tx = Transaction(engine, connection=None)

        mock_cursor = MagicMock()
        mock_cursor.rowcount = 1
        # After connect, cursor() will work
        engine.connect.return_value = MagicMock()

        with patch.object(tx, "cursor", return_value=mock_cursor):
            tx._execute_values("INSERT INTO t VALUES %s", [(1,)])

        engine.connect.assert_called_once()

    def test_raises_processed_error(self):
        from velocity.db.core.transaction import Transaction

        engine = MagicMock()
        engine.pool_enabled = False
        engine.process_error.return_value = RuntimeError("processed")
        conn = MagicMock()
        tx = Transaction(engine, connection=conn)

        mock_cursor = MagicMock()
        mock_cursor.execute.side_effect = Exception("raw")
        tx.cursor = MagicMock(return_value=mock_cursor)

        with pytest.raises(RuntimeError, match="processed"):
            tx._execute_values("INSERT INTO t VALUES %s", [(1,)])


# ── Table batch method tests ────────────────────────────────────────


class TestTableBatchMethods:
    """Tests for Table.insert_many, upsert_many, update_many."""

    def _make_table(self):
        """Create a Table with mocked tx and sql."""
        from velocity.db.core.table import Table

        tx = MagicMock()
        tx._execute_values = MagicMock(return_value=5)

        table = Table.__new__(Table)
        table.tx = tx
        table.name = "test_table"
        table.sql = SQL
        table._cursor = None
        return table

    def test_insert_many_empty(self):
        table = self._make_table()
        assert table.insert_many([]) == 0
        table.tx._execute_values.assert_not_called()

    def test_insert_many_delegates(self):
        table = self._make_table()
        rows = [{"name": "a"}, {"name": "b"}]
        result = table.insert_many(rows)

        assert result == 5
        table.tx._execute_values.assert_called_once()
        call_args = table.tx._execute_values.call_args
        assert "INSERT INTO" in call_args[0][0]
        assert len(call_args[0][1]) == 2

    def test_upsert_many_empty(self):
        table = self._make_table()
        assert table.upsert_many([]) == 0

    def test_upsert_many_delegates(self):
        table = self._make_table()
        # Need to mock tx.table().primary_keys() for merge_many SQL generation
        pk_table = MagicMock()
        pk_table.primary_keys.return_value = ["sys_id"]
        table.tx.table.return_value = pk_table

        rows = [
            {"sys_id": 1, "name": "a"},
            {"sys_id": 2, "name": "b"},
        ]
        result = table.upsert_many(rows)

        assert result == 5
        table.tx._execute_values.assert_called_once()
        call_args = table.tx._execute_values.call_args
        assert "ON CONFLICT" in call_args[0][0]

    def test_update_many_empty(self):
        table = self._make_table()
        assert table.update_many([]) == 0

    def test_update_many_delegates_to_upsert(self):
        table = self._make_table()
        rows = [
            {"sys_id": 1, "name": "updated_a"},
            {"sys_id": 2, "name": "updated_b"},
        ]
        result = table.update_many(rows)

        assert result == 5
        table.tx._execute_values.assert_called_once()
        call_args = table.tx._execute_values.call_args
        assert "ON CONFLICT" in call_args[0][0]

    def test_insert_many_page_size(self):
        table = self._make_table()
        rows = [{"name": "a"}]
        table.insert_many(rows, page_size=500)

        call_kwargs = table.tx._execute_values.call_args[1]
        assert call_kwargs["page_size"] == 500

    def test_update_many_custom_pk(self):
        table = self._make_table()
        rows = [{"code": "A", "name": "updated"}]
        table.update_many(rows, pk="code")

        table.tx._execute_values.assert_called_once()
        call_args = table.tx._execute_values.call_args
        assert "ON CONFLICT" in call_args[0][0]


# ── Integration-style tests with real SQL generation ────────────────


class TestBatchSQLIntegration:
    """Verify the complete SQL strings are well-formed."""

    def test_insert_many_sql_is_valid(self):
        rows = [
            {"sys_id": 1, "name": "Alice", "active": True},
            {"sys_id": 2, "name": "Bob", "active": False},
        ]
        sql, args, template = SQL.insert_many("users", rows)

        # Should be parseable SQL
        assert sql.startswith("INSERT INTO")
        assert "%s" in sql  # execute_values placeholder
        assert len(args) == 2
        assert all(len(a) == 3 for a in args)

    def test_merge_many_sql_is_valid(self):
        tx = MagicMock()
        table_mock = MagicMock()
        table_mock.primary_keys.return_value = ["sys_id"]
        tx.table.return_value = table_mock

        rows = [
            {"sys_id": 1, "name": "Alice", "active": True},
            {"sys_id": 2, "name": "Bob", "active": False},
        ]
        sql, args, template = SQL.merge_many(tx, "users", rows)

        assert "INSERT INTO" in sql
        assert "ON CONFLICT" in sql
        assert "DO UPDATE SET" in sql
        assert "EXCLUDED" in sql
        assert len(args) == 2

    def test_merge_many_pk_dict(self):
        tx = MagicMock()
        rows = [{"tenant": "t1", "code": "A", "val": 1}]
        sql, args, template = SQL.merge_many(
            tx, "items", rows, pk={"tenant": "t1", "code": "A"}
        )

        assert "ON CONFLICT" in sql
        assert len(args) == 1

    def test_large_batch(self):
        """Ensure a large number of rows doesn't break SQL generation."""
        rows = [{"id": i, "val": f"v{i}"} for i in range(1000)]
        sql, args, template = SQL.insert_many("big_table", rows)

        assert len(args) == 1000
        assert args[999] == (999, "v999")
