"""
Tests for R5 — Transaction-scoped query result caching.
"""

import os
import pytest
from collections import OrderedDict
from unittest.mock import MagicMock, patch, PropertyMock

from velocity.db.core.transaction import Transaction, _DEFAULT_QUERY_CACHE_SIZE


# ── Transaction cache internals ─────────────────────────────────────


class TestCacheKeyGeneration:
    """Verify _cache_key produces stable, hashable keys."""

    def _make_tx(self):
        engine = MagicMock()
        engine.pool_enabled = False
        return Transaction(engine)

    def test_key_without_params(self):
        tx = self._make_tx()
        key = tx._cache_key("SELECT 1", None)
        assert key == ("SELECT 1",)

    def test_key_with_tuple_params(self):
        tx = self._make_tx()
        k1 = tx._cache_key("SELECT %s", (42,))
        k2 = tx._cache_key("SELECT %s", (42,))
        assert k1 == k2

    def test_key_with_list_params(self):
        tx = self._make_tx()
        k1 = tx._cache_key("SELECT %s", [42])
        k2 = tx._cache_key("SELECT %s", [42])
        assert k1 == k2

    def test_key_with_dict_params(self):
        tx = self._make_tx()
        k1 = tx._cache_key("SELECT %(a)s", {"a": 1, "b": 2})
        k2 = tx._cache_key("SELECT %(a)s", {"b": 2, "a": 1})
        # Dict keys are sorted, so order doesn't matter.
        assert k1 == k2

    def test_different_sql_different_key(self):
        tx = self._make_tx()
        k1 = tx._cache_key("SELECT 1", None)
        k2 = tx._cache_key("SELECT 2", None)
        assert k1 != k2

    def test_different_params_different_key(self):
        tx = self._make_tx()
        k1 = tx._cache_key("SELECT %s", (1,))
        k2 = tx._cache_key("SELECT %s", (2,))
        assert k1 != k2

    def test_key_is_hashable(self):
        tx = self._make_tx()
        key = tx._cache_key("SELECT %s", (1, "hello"))
        # Must be usable as a dict key.
        d = {key: "value"}
        assert d[key] == "value"


class TestCachePutGet:
    """Verify _cache_put / _cache_get and LRU eviction."""

    def _make_tx(self):
        engine = MagicMock()
        engine.pool_enabled = False
        return Transaction(engine)

    def test_put_and_get(self):
        tx = self._make_tx()
        key = ("sql",)
        tx._cache_put(key, [{"a": 1}])
        assert tx._cache_get(key) == [{"a": 1}]

    def test_get_miss_returns_none(self):
        tx = self._make_tx()
        assert tx._cache_get(("missing",)) is None

    def test_lru_eviction(self):
        tx = self._make_tx()
        # Override max to a small number.
        tx._Transaction__query_cache_max = 3

        tx._cache_put(("a",), [1])
        tx._cache_put(("b",), [2])
        tx._cache_put(("c",), [3])
        # All present.
        assert tx._cache_get(("a",)) == [1]
        assert tx._cache_get(("b",)) == [2]
        assert tx._cache_get(("c",)) == [3]

        # Adding a 4th should evict the least-recently-used.
        # After the gets above, access order is a, b, c.
        # But LRU is based on insert/access order — 'a' was accessed last in the
        # series, so 'b' is now LRU (since 'a' was accessed after 'b').
        # Actually after the three gets, last access order is a→b→c.
        # So 'a' is the LRU. Let's just add a 4th and check that one is gone.
        tx._cache_put(("d",), [4])
        assert tx.cache_size == 3
        # 'a' should have been evicted (LRU after the sequence of gets).
        assert tx._cache_get(("a",)) is None

    def test_cache_size_property(self):
        tx = self._make_tx()
        assert tx.cache_size == 0
        tx._cache_put(("a",), [])
        assert tx.cache_size == 1


class TestCacheInvalidation:
    """Verify invalidate_cache / clear_cache."""

    def _make_tx(self):
        engine = MagicMock()
        engine.pool_enabled = False
        return Transaction(engine)

    def test_clear_all(self):
        tx = self._make_tx()
        tx._cache_put(("SELECT * FROM users",), [1])
        tx._cache_put(("SELECT * FROM orders",), [2])
        tx.clear_cache()
        assert tx.cache_size == 0

    def test_clear_by_table_name(self):
        tx = self._make_tx()
        tx._cache_put(("SELECT * FROM users WHERE id = 1",), [1])
        tx._cache_put(("SELECT * FROM orders WHERE id = 1",), [2])
        tx.invalidate_cache("users")
        assert tx.cache_size == 1
        assert tx._cache_get(("SELECT * FROM orders WHERE id = 1",)) == [2]

    def test_clear_by_table_name_case_insensitive(self):
        tx = self._make_tx()
        tx._cache_put(('SELECT * FROM "Users" WHERE id = 1',), [1])
        tx.invalidate_cache("users")
        assert tx.cache_size == 0

    def test_invalidate_nonexistent_table_is_noop(self):
        tx = self._make_tx()
        tx._cache_put(("SELECT * FROM users",), [1])
        tx.invalidate_cache("nonexistent")
        assert tx.cache_size == 1


# ── Table.select(cache=True) integration ────────────────────────────


class TestTableSelectCache:
    """Test cache=True on Table.select()."""

    def _make_table(self):
        from velocity.db.core.table import Table
        from velocity.db.servers.postgres.sql import SQL

        engine = MagicMock()
        engine.pool_enabled = False
        # The @return_default decorator creates savepoints.
        engine.sql.create_savepoint.return_value = ("SAVEPOINT sp", ())
        engine.sql.release_savepoint.return_value = ("RELEASE SAVEPOINT sp", ())
        engine.sql.rollback_savepoint.return_value = ("ROLLBACK TO sp", ())
        tx = Transaction(engine)

        # Mock execute to return a Result-like with .all()
        mock_result = MagicMock()
        mock_result.all.return_value = [{"id": 1, "name": "test"}]
        tx.execute = MagicMock(return_value=mock_result)
        tx._execute = MagicMock(return_value=mock_result)

        table = Table.__new__(Table)
        table.tx = tx
        table.name = "config"
        table.sql = SQL
        table._cursor = None
        return table, tx

    def test_cache_miss_queries_database(self):
        table, tx = self._make_table()
        result = table.select(where="1=1", cache=True)
        assert result == [{"id": 1, "name": "test"}]
        tx.execute.assert_called_once()

    def test_cache_hit_skips_database(self):
        table, tx = self._make_table()
        # First call — cache miss.
        result1 = table.select(where="1=1", cache=True)
        assert tx.execute.call_count == 1

        # Second call — same args → cache hit.
        result2 = table.select(where="1=1", cache=True)
        assert tx.execute.call_count == 1  # Not called again.
        assert result2 == result1

    def test_different_where_misses_cache(self):
        table, tx = self._make_table()
        table.select(where="id = 1", cache=True)
        table.select(where="id = 2", cache=True)
        assert tx.execute.call_count == 2

    def test_cache_false_always_queries(self):
        table, tx = self._make_table()
        table.select(where="1=1", cache=False)
        table.select(where="1=1", cache=False)
        assert tx.execute.call_count == 2

    def test_cache_default_is_false(self):
        table, tx = self._make_table()
        table.select(where="1=1")
        table.select(where="1=1")
        assert tx.execute.call_count == 2


class TestWriteInvalidatesCache:
    """Verify that write operations invalidate the query cache."""

    def _make_table(self):
        from velocity.db.core.table import Table
        from velocity.db.servers.postgres.sql import SQL

        engine = MagicMock()
        engine.pool_enabled = False
        engine.schema_locked = False
        engine.sql = SQL
        # create_savepoint and rollback_savepoint used by @create_missing
        engine.sql.create_savepoint = MagicMock(return_value=("SAVEPOINT sp", ()))
        engine.sql.rollback_savepoint = MagicMock(return_value=("ROLLBACK TO sp", ()))
        engine.sql.release_savepoint = MagicMock(return_value=("RELEASE SAVEPOINT sp", ()))
        tx = Transaction(engine)

        mock_result = MagicMock()
        mock_result.all.return_value = [{"id": 1}]
        mock_result.cursor.rowcount = 1
        tx.execute = MagicMock(return_value=mock_result)
        tx._execute = MagicMock(return_value=mock_result)

        table = Table.__new__(Table)
        table.tx = tx
        table.name = "config"
        table.sql = SQL
        table._cursor = None
        return table, tx

    def test_insert_invalidates(self):
        table, tx = self._make_table()
        # Prime cache.
        tx._cache_put(("SELECT * FROM config",), [{"id": 1}])
        assert tx.cache_size == 1
        table.insert({"key": "test"})
        assert tx.cache_size == 0

    def test_update_invalidates(self):
        table, tx = self._make_table()
        tx._cache_put(("SELECT * FROM config",), [{"id": 1}])
        table.update({"key": "test"}, where={"id": 1})
        assert tx.cache_size == 0

    def test_delete_invalidates(self):
        table, tx = self._make_table()
        tx._cache_put(("SELECT * FROM config",), [{"id": 1}])
        table.delete(where={"id": 1})
        assert tx.cache_size == 0

    def test_truncate_invalidates(self):
        table, tx = self._make_table()
        tx._cache_put(("SELECT * FROM config",), [{"id": 1}])
        table.truncate()
        assert tx.cache_size == 0


class TestCacheEnvVar:
    """Verify VELOCITY_QUERY_CACHE_SIZE env var is respected."""

    def test_default_cache_size(self):
        assert _DEFAULT_QUERY_CACHE_SIZE == 100

    @patch.dict(os.environ, {"VELOCITY_QUERY_CACHE_SIZE": "50"})
    def test_env_var_override(self):
        # The module-level default is set at import time, so we test the
        # Transaction constructor with a patched value.
        import importlib
        import velocity.db.core.transaction as mod

        original = mod._DEFAULT_QUERY_CACHE_SIZE
        mod._DEFAULT_QUERY_CACHE_SIZE = 50
        try:
            engine = MagicMock()
            engine.pool_enabled = False
            tx = Transaction(engine)
            assert tx._Transaction__query_cache_max == 50
        finally:
            mod._DEFAULT_QUERY_CACHE_SIZE = original
