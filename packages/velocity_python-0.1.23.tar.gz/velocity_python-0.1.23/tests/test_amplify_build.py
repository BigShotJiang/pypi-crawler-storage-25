from velocity.aws.amplify_build import (
    BackendDeploymentConfig,
    build_environment_variables,
    get_amplify_app_id_and_branch,
    run_backend_deployment,
)


class FakeAmplifyProject:
    def get_merged_env_vars(self, branch):
        return {"EXISTING": branch}

    def get_region(self):
        return "us-east-1"


class FakeDeployProject(FakeAmplifyProject):
    def __init__(self):
        self.updated_functions = []

    def list_lambda_functions_filtered(self, branch):
        return [
            {
                "FunctionName": f"ClientEvents-{branch}",
                "Layers": [
                    {
                        "Arn": "arn:aws:lambda:us-east-1:741671896925:layer:py-lib-support:225"
                    },
                    {
                        "Arn": "arn:aws:lambda:us-east-1:741671896925:layer:py-lib-accounting:34"
                    },
                ],
            }
        ]

    def update_lambda_function(self, **kwargs):
        self.updated_functions.append(kwargs)


class FakeLambdaClient:
    def list_layer_versions(self, LayerName, MaxItems):
        versions = {
            "py-lib-support": [
                {
                    "Version": 240,
                    "LayerVersionArn": "arn:aws:lambda:us-east-1:741671896925:layer:py-lib-support:240",
                }
            ],
            "py-lib-accounting": [
                {
                    "Version": 34,
                    "LayerVersionArn": "arn:aws:lambda:us-east-1:741671896925:layer:py-lib-accounting:34",
                }
            ],
        }
        return {"LayerVersions": versions[LayerName][:MaxItems]}


def test_backend_deployment_config_resolves_queue_timeout_and_memory_size():
    config = BackendDeploymentConfig(
        queue_name_template="clients-queue-{branch}",
        short_timeout_tokens=("Events", "Data"),
        memory_size_by_token={"QueueHandler": 1024, "Events": 512},
    )

    assert config.resolve_queue_name("Demo") == "clients-queue-demo"
    assert config.resolve_timeout("ClientEvents-demo") == 60
    assert config.resolve_timeout("ClientUtility-demo") == 900
    assert config.resolve_memory_size("ClientQueueHandler-demo") == 1024
    assert config.resolve_memory_size("ClientEvents-demo") == 512
    assert config.resolve_memory_size("ClientUtility-demo") is None


def test_build_environment_variables_reads_project_metadata(tmp_path, monkeypatch):
    amplify_dir = tmp_path / "amplify" / "backend"
    amplify_dir.mkdir(parents=True)
    (amplify_dir / "amplify-meta.json").write_text('{"UserPoolId": "us-east-1_demoPool",}')

    monkeypatch.setenv("AWS_JOB_ID", "job-123")
    app = FakeAmplifyProject()

    env_vars = build_environment_variables(
        app,
        "demo",
        "clients-queue-demo",
        project_root=tmp_path,
    )

    assert env_vars["EXISTING"] == "demo"
    assert env_vars["SqsWorkQueue"] == "clients-queue-demo"
    assert env_vars["AWS_JOB_ID"] == "job-123"
    assert env_vars["AWS_USER_POOL_ID"] == "us-east-1_demoPool"
    assert env_vars["USER_BRANCH"] == "demo"
    assert env_vars["REACT_APP_USER_BRANCH"] == "demo"
    assert env_vars["USER_REGION"] == "us-east-1"
    assert env_vars["LOGLEVEL"] == "INFO"
    assert "BUILD_DATETIME" in env_vars


def test_get_amplify_app_id_and_branch_uses_team_provider_info(tmp_path, monkeypatch):
    team_provider_path = tmp_path / "amplify"
    team_provider_path.mkdir(parents=True)
    (team_provider_path / "team-provider-info.json").write_text(
        '{"demo": {"awscloudformation": {"AmplifyAppId": "app-123"}}}'
    )

    monkeypatch.setenv("AWS_BRANCH", "demo")
    monkeypatch.delenv("AWS_APP_ID", raising=False)

    app_id, branch = get_amplify_app_id_and_branch(tmp_path)

    assert app_id == "app-123"
    assert branch == "demo"


def test_run_backend_deployment_refreshes_lambda_layers(monkeypatch, tmp_path):
    monkeypatch.setattr(
        "velocity.aws.amplify_build.ensure_lambda_policies_and_attach",
        lambda *args, **kwargs: None,
    )
    monkeypatch.setattr(
        "velocity.aws.amplify_build.set_cloudwatch_logging",
        lambda *args, **kwargs: True,
    )

    app = FakeDeployProject()
    config = BackendDeploymentConfig(
        queue_name_template="clients-queue-{branch}",
        short_timeout_tokens=("Events",),
        memory_size_by_token={"Events": 512},
    )

    run_backend_deployment(
        "app-123",
        "demo",
        config,
        project_root=tmp_path,
        app=app,
        lambda_client=FakeLambdaClient(),
        logs_client=object(),
    )

    assert len(app.updated_functions) == 1
    assert app.updated_functions[0]["function_name"] == "ClientEvents-demo"
    assert app.updated_functions[0]["timeout"] == 60
    assert app.updated_functions[0]["memory_size"] == 512
    assert app.updated_functions[0]["layers"] == [
        "arn:aws:lambda:us-east-1:741671896925:layer:py-lib-support:240",
        "arn:aws:lambda:us-east-1:741671896925:layer:py-lib-accounting:34",
    ]