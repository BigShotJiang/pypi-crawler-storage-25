"""Tests for the ConnectionPool and Engine pooling integration."""

import threading
import time
import pytest

from unittest.mock import MagicMock, patch, PropertyMock
from velocity.db.core.engine import ConnectionPool, Engine
from velocity.db.core.transaction import Transaction
from velocity.db import exceptions


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mock_conn(closed=False):
    """Return a mock that quacks like a psycopg3 connection."""
    conn = MagicMock()
    conn.closed = closed
    conn.cursor.return_value = MagicMock()
    return conn


def _make_connect_fn(closed=False):
    """Return a connect function that produces mock connections."""
    def connect():
        return _make_mock_conn(closed=closed)
    return connect


def _make_engine(pool_enabled=True, pool_min=1, pool_max=5, pool_validate=False):
    """Build an Engine with a mock driver and pooling configured."""
    driver = MagicMock()
    driver.connect.side_effect = lambda **kw: _make_mock_conn()
    sql = MagicMock()
    sql.server = "PostgreSQL"
    config = {
        "database": "testdb",
        "host": "localhost",
        "user": "testuser",
        "password": "testpass",
    }
    return Engine(
        driver, config, sql,
        pool_enabled=pool_enabled,
        pool_min=pool_min,
        pool_max=pool_max,
        pool_validate=pool_validate,
    )


# ---------------------------------------------------------------------------
# ConnectionPool unit tests
# ---------------------------------------------------------------------------

class TestConnectionPool:

    def test_creation_prefills_minconn(self):
        conns_created = []
        def connect():
            c = _make_mock_conn()
            conns_created.append(c)
            return c

        pool = ConnectionPool(connect, minconn=3, maxconn=5, validate=False)
        assert pool.size == 3
        assert len(conns_created) == 3

    def test_getconn_returns_connection(self):
        pool = ConnectionPool(_make_connect_fn(), minconn=1, maxconn=2, validate=False)
        conn = pool.getconn()
        assert conn is not None
        assert pool.size == 0  # it was popped

    def test_putconn_returns_to_pool(self):
        pool = ConnectionPool(_make_connect_fn(), minconn=0, maxconn=2, validate=False)
        conn = pool.getconn()
        assert pool.size == 0
        pool.putconn(conn)
        assert pool.size == 1

    def test_putconn_discard(self):
        pool = ConnectionPool(_make_connect_fn(), minconn=0, maxconn=2, validate=False)
        conn = pool.getconn()
        pool.putconn(conn, discard=True)
        assert pool.size == 0
        conn.close.assert_called_once()

    def test_putconn_none_releases_slot(self):
        pool = ConnectionPool(_make_connect_fn(), minconn=0, maxconn=1, validate=False)
        conn = pool.getconn()
        # Release the slot by putting None.
        pool.putconn(None)
        # Should be able to get another connection now (maxconn=1).
        conn2 = pool.getconn()
        assert conn2 is not None

    def test_dead_connections_are_discarded(self):
        pool = ConnectionPool(_make_connect_fn(), minconn=1, maxconn=2, validate=False)
        # Poison the idle connection.
        pool._pool[0].closed = True
        conn = pool.getconn()
        # Should have created a new connection because the idle one was dead.
        assert conn is not None
        assert conn.closed == False

    def test_closeall(self):
        pool = ConnectionPool(_make_connect_fn(), minconn=3, maxconn=5, validate=False)
        assert pool.size == 3
        pool.closeall()
        assert pool.size == 0

    def test_getconn_after_closeall_raises(self):
        pool = ConnectionPool(_make_connect_fn(), minconn=1, maxconn=2, validate=False)
        pool.closeall()
        with pytest.raises(exceptions.DbConnectionError):
            pool.getconn()

    def test_maxconn_less_than_1_raises(self):
        with pytest.raises(ValueError):
            ConnectionPool(_make_connect_fn(), minconn=0, maxconn=0)

    def test_minconn_clamped_to_maxconn(self):
        pool = ConnectionPool(_make_connect_fn(), minconn=10, maxconn=2, validate=False)
        # minconn is clamped to maxconn, so only 2 pre-created.
        assert pool.size == 2

    def test_validation_rejects_bad_conn(self):
        def bad_connect():
            conn = _make_mock_conn()
            conn.cursor.return_value.execute.side_effect = Exception("broken")
            return conn

        # With validation on, pool should discard bad connections.
        pool = ConnectionPool(bad_connect, minconn=0, maxconn=2, validate=True)
        # Put a bad conn.
        bad = bad_connect()
        pool._pool.append(bad)
        # getconn should discard it and create a new one.
        conn = pool.getconn()
        assert conn is not None

    def test_concurrent_getconn_respects_maxconn(self):
        """Multiple threads should not exceed maxconn concurrent connections."""
        pool = ConnectionPool(_make_connect_fn(), minconn=0, maxconn=3, validate=False)
        borrowed = []
        barrier = threading.Barrier(3)

        def borrow():
            conn = pool.getconn()
            borrowed.append(conn)
            barrier.wait(timeout=5)  # all threads hold connections
            time.sleep(0.05)
            pool.putconn(conn)

        threads = [threading.Thread(target=borrow) for _ in range(3)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=10)

        assert len(borrowed) == 3

    def test_prefill_failure_is_nonfatal(self):
        """If DB is unreachable at pool creation, it should not raise."""
        call_count = 0
        def failing_connect():
            nonlocal call_count
            call_count += 1
            raise Exception("DB unreachable")

        pool = ConnectionPool(failing_connect, minconn=3, maxconn=5, validate=False)
        assert pool.size == 0  # No connections pre-filled, but pool is alive.


# ---------------------------------------------------------------------------
# Engine pool integration tests
# ---------------------------------------------------------------------------

class TestEnginePoolIntegration:

    def test_pool_enabled_by_default(self):
        eng = _make_engine(pool_enabled=True)
        assert eng.pool_enabled is True
        assert eng.pool is not None

    def test_pool_disabled(self):
        eng = _make_engine(pool_enabled=False)
        assert eng.pool_enabled is False
        assert eng.pool is None

    def test_connect_uses_pool(self):
        eng = _make_engine(pool_enabled=True, pool_min=1, pool_max=2)
        conn = eng.connect()
        assert conn is not None

    def test_close_pool(self):
        eng = _make_engine(pool_enabled=True, pool_min=2, pool_max=5)
        assert eng.pool.size >= 1
        eng.close_pool()
        assert eng.pool is None
        assert eng.pool_enabled is False

    def test_return_pooled_connection(self):
        eng = _make_engine(pool_enabled=True, pool_min=0, pool_max=2)
        conn = eng.connect()
        initial_size = eng.pool.size
        eng.return_pooled_connection(conn)
        assert eng.pool.size == initial_size + 1

    def test_return_pooled_connection_discard(self):
        eng = _make_engine(pool_enabled=True, pool_min=0, pool_max=2)
        conn = eng.connect()
        eng.return_pooled_connection(conn, discard=True)
        conn.close.assert_called()

    def test_str_includes_pool_info(self):
        eng = _make_engine(pool_enabled=True, pool_min=2, pool_max=5)
        s = str(eng)
        assert "pool(" in s

    @patch.dict("os.environ", {
        "VELOCITY_POOL_ENABLED": "false",
    })
    def test_env_disables_pool(self):
        eng = _make_engine(pool_enabled=None)
        assert eng.pool_enabled is False

    @patch.dict("os.environ", {
        "VELOCITY_POOL_MIN": "2",
        "VELOCITY_POOL_MAX": "10",
    })
    def test_env_configures_pool_size(self):
        eng = _make_engine(pool_enabled=True, pool_min=None, pool_max=None)
        assert eng.pool is not None
        assert eng.pool.maxconn == 10


# ---------------------------------------------------------------------------
# Transaction pool integration tests
# ---------------------------------------------------------------------------

class TestTransactionPoolIntegration:

    def test_transaction_returns_conn_to_pool_on_close(self):
        eng = _make_engine(pool_enabled=True, pool_min=1, pool_max=2)
        tx = Transaction(eng)
        _ = tx.cursor()  # triggers connection acquisition
        assert tx.connection is not None
        pool_size_before = eng.pool.size
        tx.close()
        assert tx.connection is None
        assert eng.pool.size >= pool_size_before  # returned, not closed

    def test_transaction_discards_conn_on_error(self):
        eng = _make_engine(pool_enabled=True, pool_min=1, pool_max=2)
        tx = Transaction(eng)
        _ = tx.cursor()
        conn = tx.connection

        # Simulate an error exit.
        try:
            with tx:
                raise ValueError("simulated error")
        except ValueError:
            pass

        # The connection should have been discarded, not returned.
        assert tx.connection is None
        conn.close.assert_called()

    def test_context_manager_returns_conn_on_success(self):
        eng = _make_engine(pool_enabled=True, pool_min=0, pool_max=2)
        with Transaction(eng) as tx:
            _ = tx.cursor()
            conn = tx.connection
        # After clean exit, connection returned (not closed).
        assert tx.connection is None

    def test_non_pooled_transaction_closes_directly(self):
        eng = _make_engine(pool_enabled=False)
        tx = Transaction(eng)
        _ = tx.cursor()
        conn = tx.connection
        tx.close()
        conn.close.assert_called_once()
        assert tx.connection is None
