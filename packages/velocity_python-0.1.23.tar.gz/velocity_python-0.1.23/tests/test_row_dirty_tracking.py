"""
Tests for R3 — Row dirty-tracking mode with .save().

When ``dirty_tracking=True``, writes accumulate in memory and are flushed
to the database only on explicit ``.save()``.
"""

import pytest
from unittest.mock import MagicMock

from velocity.db.core.row import Row


def _make_dirty_row(cache=None, pk=None):
    """Create a Row with dirty_tracking=True and a mocked table."""
    table = MagicMock()
    table.name = "test_table"
    table.select.return_value.as_dict.return_value.one.return_value = cache or {
        "name": "Alice",
        "email": "alice@example.com",
        "sys_id": 1,
    }
    table.update_or_insert = MagicMock()

    row = Row.__new__(Row)
    object.__setattr__(row, "table", table)
    object.__setattr__(row, "pk", pk or {"sys_id": 1})
    object.__setattr__(row, "_cache", dict(cache) if cache else None)
    object.__setattr__(row, "_column_set", None)
    object.__setattr__(row, "_batching", False)
    object.__setattr__(row, "_pending", {})
    object.__setattr__(row, "_cache_ttl", None)
    object.__setattr__(row, "_cache_time", None)
    object.__setattr__(row, "_no_cache", False)
    object.__setattr__(row, "_dirty_tracking", True)
    object.__setattr__(row, "_dirty", {})
    return row


def _make_normal_row(cache=None, pk=None):
    """Create a Row with dirty_tracking=False (default)."""
    table = MagicMock()
    table.name = "test_table"
    table.select.return_value.as_dict.return_value.one.return_value = cache or {
        "name": "Alice",
        "email": "alice@example.com",
        "sys_id": 1,
    }
    table.update_or_insert = MagicMock()

    row = Row.__new__(Row)
    object.__setattr__(row, "table", table)
    object.__setattr__(row, "pk", pk or {"sys_id": 1})
    object.__setattr__(row, "_cache", dict(cache) if cache else None)
    object.__setattr__(row, "_column_set", None)
    object.__setattr__(row, "_batching", False)
    object.__setattr__(row, "_pending", {})
    object.__setattr__(row, "_cache_ttl", None)
    object.__setattr__(row, "_cache_time", None)
    object.__setattr__(row, "_no_cache", False)
    object.__setattr__(row, "_dirty_tracking", False)
    object.__setattr__(row, "_dirty", {})
    return row


class TestDirtyTracking:

    def test_no_db_write_on_assignment(self):
        """Assignments should NOT trigger DB writes when dirty tracking is on."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        row["name"] = "Bob"
        row.table.update_or_insert.assert_not_called()

    def test_save_flushes_all_changes(self):
        """save() should issue a single UPDATE with all accumulated changes."""
        row = _make_dirty_row({"name": "Alice", "email": "old@test.com", "sys_id": 1})
        row["name"] = "Bob"
        row["email"] = "bob@test.com"
        row.save()

        row.table.update_or_insert.assert_called_once_with(
            {"name": "Bob", "email": "bob@test.com"}, pk={"sys_id": 1}
        )

    def test_save_clears_dirty_dict(self):
        """After save(), the dirty dict should be empty."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        row["name"] = "Bob"
        assert row.is_dirty
        row.save()
        assert not row.is_dirty

    def test_save_no_changes_is_noop(self):
        """save() with no changes should not issue a DB call."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        row.save()
        row.table.update_or_insert.assert_not_called()

    def test_reads_see_dirty_values(self):
        """Reads should return the dirty (not-yet-saved) value."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        row["name"] = "Bob"
        assert row["name"] == "Bob"

    def test_is_dirty_property(self):
        """is_dirty should reflect whether unsaved changes exist."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        assert not row.is_dirty
        row["name"] = "Bob"
        assert row.is_dirty

    def test_discard_clears_changes(self):
        """discard() should drop pending changes and invalidate cache."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        row["name"] = "Bob"
        assert row.is_dirty
        row.discard()
        assert not row.is_dirty

    def test_discard_invalidates_cache(self):
        """After discard(), cache should be None so next read re-fetches."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        row["name"] = "Bob"
        row.discard()
        assert row._cache is None

    def test_save_invalidates_cache(self):
        """After save(), cache should be invalidated for trigger-computed columns."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        row["name"] = "Bob"
        row.save()
        assert row._cache is None

    def test_last_write_wins(self):
        """Multiple assignments to the same column keep the last value."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        row["name"] = "Bob"
        row["name"] = "Charlie"
        row.save()

        row.table.update_or_insert.assert_called_once_with(
            {"name": "Charlie"}, pk={"sys_id": 1}
        )

    def test_pk_write_raises(self):
        """Writing to a PK column should raise even with dirty tracking."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        with pytest.raises(Exception, match="Cannot update a primary key"):
            row["sys_id"] = 999

    def test_attr_style_is_deferred(self):
        """Attribute-style writes should also be deferred."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        row.name = "Bob"
        row.table.update_or_insert.assert_not_called()
        row.save()
        row.table.update_or_insert.assert_called_once()

    def test_save_without_dirty_tracking_raises(self):
        """save() on a normal row should raise RuntimeError."""
        row = _make_normal_row({"name": "Alice", "sys_id": 1})
        with pytest.raises(RuntimeError, match="dirty_tracking=True"):
            row.save()

    def test_save_returns_self(self):
        """save() should return self for chaining."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        row["name"] = "Bob"
        result = row.save()
        assert result is row

    def test_discard_returns_self(self):
        """discard() should return self for chaining."""
        row = _make_dirty_row({"name": "Alice", "sys_id": 1})
        result = row.discard()
        assert result is row

    def test_constructor_parameter(self):
        """Row can be created with dirty_tracking=True via constructor."""
        table = MagicMock()
        table.name = "test_table"
        table.select.return_value.as_dict.return_value.one.return_value = {
            "name": "Alice", "sys_id": 1,
        }
        row = Row(table, 1, dirty_tracking=True)
        assert row._dirty_tracking is True
        assert row._dirty == {}

    def test_normal_row_writes_through(self):
        """Without dirty tracking, writes still go through immediately."""
        row = _make_normal_row({"name": "Alice", "sys_id": 1})
        row["name"] = "Bob"
        row.table.update_or_insert.assert_called_once()
