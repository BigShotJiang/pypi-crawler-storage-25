"""
Tests for R12 — Observability & Performance: slow-query logging, query counters,
connection timing, @engine.perf_log, @return_default counter, structured logging.
"""

import logging
import time
import os
import pytest
from unittest.mock import MagicMock, patch, PropertyMock, call
from functools import wraps

from velocity.db.core.transaction import (
    Transaction,
    _classify_sql,
    _extract_table_name,
    _SLOW_QUERY_MS,
    _logger as tx_logger,
)


# ──────────────────────────────────────────────────────────────────────
# SQL classification helpers
# ──────────────────────────────────────────────────────────────────────


class TestClassifySql:
    def test_select(self):
        assert _classify_sql("SELECT * FROM users") == "SELECT"

    def test_insert(self):
        assert _classify_sql("INSERT INTO users (name) VALUES ('a')") == "INSERT"

    def test_update(self):
        assert _classify_sql("UPDATE users SET name='b'") == "UPDATE"

    def test_delete(self):
        assert _classify_sql("DELETE FROM users WHERE id=1") == "DELETE"

    def test_create(self):
        assert _classify_sql("CREATE TABLE foo (id int)") == "DDL"

    def test_alter(self):
        assert _classify_sql("ALTER TABLE foo ADD col int") == "DDL"

    def test_drop(self):
        assert _classify_sql("DROP TABLE foo") == "DDL"

    def test_set(self):
        assert _classify_sql("SET lock_timeout = '5s'") == "SET"

    def test_leading_whitespace(self):
        assert _classify_sql("   SELECT 1") == "SELECT"

    def test_empty(self):
        assert _classify_sql("") == "OTHER"

    def test_none(self):
        assert _classify_sql(None) == "OTHER"

    def test_unknown(self):
        assert _classify_sql("GRANT ALL ON foo TO bar") == "OTHER"


class TestExtractTableName:
    def test_select_from(self):
        assert _extract_table_name("SELECT * FROM users WHERE id=1") == "users"

    def test_insert_into(self):
        assert _extract_table_name("INSERT INTO orders (id) VALUES (1)") == "orders"

    def test_update(self):
        assert _extract_table_name("UPDATE accounts SET x=1") == "accounts"

    def test_quoted_table(self):
        assert _extract_table_name('SELECT * FROM "my_table" WHERE x=1') == "my_table"

    def test_none_input(self):
        assert _extract_table_name(None) is None

    def test_empty(self):
        assert _extract_table_name("") is None


# ──────────────────────────────────────────────────────────────────────
# Transaction query counter and timing
# ──────────────────────────────────────────────────────────────────────


def _make_tx():
    """Create a Transaction with mocked engine, bypassing real DB."""
    engine = MagicMock()
    engine.pool_enabled = False
    engine.prepare_enabled = False
    tx = Transaction.__new__(Transaction)
    tx.engine = engine
    tx.connection = MagicMock()
    tx.connection.closed = False  # Prevent cursor() from thinking the connection is dead.
    tx._Transaction__pg_types = {}
    tx._Transaction__pooled = False
    tx._Transaction__query_cache = {}
    tx._Transaction__query_cache_max = 100
    tx._query_count = 0
    tx._query_time_ms = 0.0
    tx._return_default_count = 0
    tx._last_return_default_error = None
    return tx


class TestTransactionQueryCounters:
    """Verify _query_count and _query_time_ms increment per execute."""

    def test_initial_counters_zero(self):
        tx = _make_tx()
        assert tx._query_count == 0
        assert tx._query_time_ms == 0.0
        assert tx._return_default_count == 0

    def test_execute_increments_counter(self):
        tx = _make_tx()
        cursor = MagicMock()
        tx.connection.cursor.return_value = cursor
        tx._execute("SELECT 1")
        assert tx._query_count == 1
        assert tx._query_time_ms >= 0

    def test_multiple_executes_accumulate(self):
        tx = _make_tx()
        cursor = MagicMock()
        tx.connection.cursor.return_value = cursor
        tx._execute("SELECT 1")
        tx._execute("SELECT 2")
        tx._execute("SELECT 3")
        assert tx._query_count == 3

    def test_query_time_accumulates(self):
        tx = _make_tx()

        class SlowCursor:
            def execute(self, *a, **kw):
                time.sleep(0.01)
            @property
            def description(self):
                return None

        tx.connection.cursor.return_value = SlowCursor()

        tx._execute("SELECT 1")
        tx._execute("SELECT 2")
        assert tx._query_time_ms >= 10  # at least 10ms for 2 * 10ms sleeps


# ──────────────────────────────────────────────────────────────────────
# Slow query logging
# ──────────────────────────────────────────────────────────────────────


class TestSlowQueryLogging:
    """Slow queries above threshold emit WARNING log."""

    def test_slow_query_logs_warning(self, caplog):
        tx = _make_tx()

        class SlowCursor:
            def execute(self, *a, **kw):
                time.sleep(0.01)
            @property
            def description(self):
                return None

        tx.connection.cursor.return_value = SlowCursor()

        # Patch threshold to 5ms so our 10ms query triggers it.
        with patch("velocity.db.core.transaction._SLOW_QUERY_MS", 5):
            with caplog.at_level(logging.WARNING, logger="velocity.db.transaction"):
                tx._execute("SELECT * FROM big_table")

        assert any("Slow query" in r.message for r in caplog.records)
        assert any("big_table" in r.message for r in caplog.records)
        assert any("sql=SELECT * FROM big_table" in r.message for r in caplog.records)

    def test_fast_query_no_warning(self, caplog):
        tx = _make_tx()
        cursor = MagicMock()
        tx.connection.cursor.return_value = cursor

        with patch("velocity.db.core.transaction._SLOW_QUERY_MS", 500):
            with caplog.at_level(logging.WARNING, logger="velocity.db.transaction"):
                tx._execute("SELECT 1")

        assert not any("Slow query" in r.message for r in caplog.records)

    def test_slow_query_disabled_when_zero(self, caplog):
        tx = _make_tx()

        class SlowCursor:
            def execute(self, *a, **kw):
                time.sleep(0.01)
            @property
            def description(self):
                return None

        tx.connection.cursor.return_value = SlowCursor()

        with patch("velocity.db.core.transaction._SLOW_QUERY_MS", 0):
            with caplog.at_level(logging.WARNING, logger="velocity.db.transaction"):
                tx._execute("SELECT * FROM big_table")

        assert not any("Slow query" in r.message for r in caplog.records)

    def test_slow_query_structured_extra(self, caplog):
        """Verify structured logging extra fields on slow-query record."""
        tx = _make_tx()

        class SlowCursor:
            def execute(self, *a, **kw):
                time.sleep(0.01)
            @property
            def description(self):
                return None

        tx.connection.cursor.return_value = SlowCursor()

        with patch("velocity.db.core.transaction._SLOW_QUERY_MS", 5):
            with caplog.at_level(logging.WARNING, logger="velocity.db.transaction"):
                tx._execute("SELECT * FROM orders WHERE id = 1")

        slow_records = [r for r in caplog.records if "Slow query" in r.message]
        assert len(slow_records) >= 1
        rec = slow_records[0]
        assert rec.query_duration_ms > 0
        assert rec.table_name == "orders"
        assert rec.operation == "SELECT"
        assert rec.sql_preview == "SELECT * FROM orders WHERE id = 1"
        assert rec.stack_info


# ──────────────────────────────────────────────────────────────────────
# Commit logging
# ──────────────────────────────────────────────────────────────────────


class TestCommitLogging:
    """Transaction commit logs query stats at DEBUG."""

    def test_commit_logs_query_stats(self, caplog):
        tx = _make_tx()
        cursor = MagicMock()
        tx.connection.cursor.return_value = cursor

        tx._execute("SELECT 1")
        tx._execute("UPDATE t SET x=1")

        with caplog.at_level(logging.DEBUG, logger="velocity.db.transaction"):
            tx.commit()

        commit_records = [r for r in caplog.records if "Transaction commit" in r.message]
        assert len(commit_records) == 1
        rec = commit_records[0]
        assert "2 queries" in rec.message
        assert rec.query_count == 2
        assert rec.query_time_ms >= 0

    def test_commit_no_log_when_no_queries(self, caplog):
        tx = _make_tx()
        with caplog.at_level(logging.DEBUG, logger="velocity.db.transaction"):
            tx.commit()
        assert not any("Transaction commit" in r.message for r in caplog.records)


# ──────────────────────────────────────────────────────────────────────
# @engine.perf_log decorator
# ──────────────────────────────────────────────────────────────────────


class TestPerfLogDecorator:
    """Verify @engine.perf_log emits INFO log with wall/query/time."""

    def _make_engine(self):
        from velocity.db.core.engine import Engine

        engine = MagicMock(spec=Engine)
        # Borrow the real perf_log method.
        engine.perf_log = Engine.perf_log.__get__(engine, Engine)
        return engine

    def test_perf_log_logs_info(self, caplog):
        engine = self._make_engine()

        @engine.perf_log
        def my_func(tx=None):
            time.sleep(0.01)
            return 42

        tx = _make_tx()
        tx._query_count = 5
        tx._query_time_ms = 123.4

        with caplog.at_level(logging.INFO, logger="velocity.db.engine"):
            result = my_func(tx=tx)

        assert result == 42
        perf_records = [r for r in caplog.records if "perf_log" in r.message]
        assert len(perf_records) >= 1
        rec = perf_records[0]
        assert rec.query_count == 5
        assert rec.query_time_ms == 123.4
        assert rec.wall_ms >= 10

    def test_perf_log_no_tx(self, caplog):
        """perf_log works even without a tx argument."""
        engine = self._make_engine()

        @engine.perf_log
        def my_func():
            return "ok"

        with caplog.at_level(logging.INFO, logger="velocity.db.engine"):
            result = my_func()

        assert result == "ok"
        perf_records = [r for r in caplog.records if "perf_log" in r.message]
        assert len(perf_records) >= 1
        rec = perf_records[0]
        assert rec.query_count == 0

    def test_perf_log_finds_tx_positional(self, caplog):
        """perf_log picks up Transaction from positional args."""
        engine = self._make_engine()
        tx = _make_tx()
        tx._query_count = 3
        tx._query_time_ms = 75.0

        @engine.perf_log
        def my_func(tx_arg, label):
            return label

        with caplog.at_level(logging.INFO, logger="velocity.db.engine"):
            result = my_func(tx, "done")

        assert result == "done"
        perf_records = [r for r in caplog.records if "perf_log" in r.message]
        assert len(perf_records) >= 1
        assert perf_records[0].query_count == 3


# ──────────────────────────────────────────────────────────────────────
# @return_default counter
# ──────────────────────────────────────────────────────────────────────


class TestReturnDefaultCounter:
    """@return_default increments tx._return_default_count on each swallowed exception."""

    def test_counter_increments(self):
        from velocity.db.core.decorators import return_default
        from velocity.db import exceptions

        tx = _make_tx()
        # create_savepoint / release_savepoint / rollback_savepoint need to work
        tx.create_savepoint = MagicMock(return_value="sp1")
        tx.release_savepoint = MagicMock()
        tx.rollback_savepoint = MagicMock()

        table = MagicMock()
        table.tx = tx
        table.cursor = MagicMock(return_value=MagicMock())

        @return_default(default=0)
        def failing_method(self):
            raise exceptions.DbApplicationError("boom")

        result = failing_method(table)
        assert result == 0
        assert tx._return_default_count == 1

        # Call again — counter should accumulate.
        result = failing_method(table)
        assert result == 0
        assert tx._return_default_count == 2

    def test_counter_stays_zero_on_success(self):
        from velocity.db.core.decorators import return_default

        tx = _make_tx()
        tx.create_savepoint = MagicMock(return_value="sp1")
        tx.release_savepoint = MagicMock()
        tx.rollback_savepoint = MagicMock()

        table = MagicMock()
        table.tx = tx
        table.cursor = MagicMock(return_value=MagicMock())

        @return_default(default=0)
        def ok_method(self):
            return 42

        result = ok_method(table)
        assert result == 42
        assert tx._return_default_count == 0


# ──────────────────────────────────────────────────────────────────────
# Connection timing (Engine.connect / ConnectionPool.getconn)
# ──────────────────────────────────────────────────────────────────────


class TestConnectionTiming:
    """Verify Engine.connect and Pool.getconn include timing in debug logs."""

    def test_pool_getconn_logs_timing(self, caplog):
        from velocity.db.core.engine import ConnectionPool

        mock_conn = MagicMock()
        pool = ConnectionPool(connect_fn=lambda: mock_conn, maxconn=2)

        with caplog.at_level(logging.DEBUG, logger="velocity.db.engine"):
            conn = pool.getconn()

        assert conn is mock_conn
        pool_records = [r for r in caplog.records if "Pool:" in r.message]
        assert len(pool_records) >= 1
        # Should mention timing in ms
        assert any("ms" in r.message for r in pool_records)

        pool.putconn(conn)

    def test_pool_reuse_logs_timing(self, caplog):
        from velocity.db.core.engine import ConnectionPool

        mock_conn = MagicMock()
        # Make _is_alive return True for reuse.
        mock_conn.closed = False
        pool = ConnectionPool(connect_fn=lambda: mock_conn, maxconn=2)

        conn = pool.getconn()
        pool.putconn(conn)

        with caplog.at_level(logging.DEBUG, logger="velocity.db.engine"):
            conn2 = pool.getconn()

        reuse_records = [r for r in caplog.records if "reusing" in r.message]
        assert len(reuse_records) >= 1
        assert any("ms" in r.message for r in reuse_records)

        pool.putconn(conn2)
