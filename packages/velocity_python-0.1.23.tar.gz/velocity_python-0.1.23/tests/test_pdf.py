"""Tests for velocity.misc.pdf — HTML-to-PDF generation."""

from unittest.mock import MagicMock, patch

import pytest

from velocity.misc.pdf import _DEFAULT_BODY_CSS, html_to_pdf, wrap_html


class TestWrapHtml:

    def test_produces_full_document(self):
        result = wrap_html("My Title", "<p>Hello</p>")
        assert "<!DOCTYPE html>" in result
        assert "<title>My Title</title>" in result
        assert "<h1>My Title</h1>" in result
        assert "<p>Hello</p>" in result

    def test_includes_default_css(self):
        result = wrap_html("T", "<p>body</p>")
        assert "font-family:" in result
        assert _DEFAULT_BODY_CSS.strip()[:30] in result

    def test_includes_custom_css(self):
        result = wrap_html("T", "<p>body</p>", css=".custom { color: red; }")
        assert ".custom { color: red; }" in result

    def test_empty_body(self):
        result = wrap_html("T", "")
        assert "<h1>T</h1>" in result


class TestHtmlToPdf:

    def test_raises_without_pdfkit(self):
        with patch("velocity.misc.pdf.pdfkit", None), patch(
            "velocity.misc.pdf._pdfkit_import_error", ImportError("missing pdfkit")
        ):
            with pytest.raises(ImportError, match="pdfkit is required"):
                html_to_pdf("<h1>test</h1>")

    def test_raises_without_wkhtmltopdf_binary(self):
        mock_pdfkit = MagicMock()

        with patch("velocity.misc.pdf.pdfkit", mock_pdfkit), patch(
            "velocity.misc.pdf._find_wkhtmltopdf", return_value=None
        ):
            with pytest.raises(ImportError, match="wkhtmltopdf binary not available"):
                html_to_pdf("<h1>test</h1>")

    def test_calls_pdfkit_with_defaults(self):
        mock_pdfkit = MagicMock()
        mock_config = object()
        mock_pdfkit.configuration.return_value = mock_config
        mock_pdfkit.from_string.return_value = b"%PDF-fake"

        with patch("velocity.misc.pdf.pdfkit", mock_pdfkit), patch(
            "velocity.misc.pdf._find_wkhtmltopdf", return_value="/opt/bin/wkhtmltopdf"
        ):
            result = html_to_pdf("<h1>Hello</h1>")

        assert result == b"%PDF-fake"
        mock_pdfkit.configuration.assert_called_once_with(
            wkhtmltopdf="/opt/bin/wkhtmltopdf"
        )
        mock_pdfkit.from_string.assert_called_once()
        call_args = mock_pdfkit.from_string.call_args
        assert call_args.args[0] == "<h1>Hello</h1>"
        assert call_args.args[1] is False
        assert call_args.kwargs["configuration"] is mock_config
        options = call_args.kwargs["options"]
        assert options["page-size"] == "Letter"
        assert options["orientation"] == "Portrait"
        assert options["margin-top"] == "0.5in"
        assert options["margin-right"] == "0.5in"
        assert options["margin-bottom"] == "0.75in"
        assert options["margin-left"] == "0.5in"
        assert options["enable-local-file-access"] == ""

    def test_passes_footer_and_margin_options(self):
        mock_pdfkit = MagicMock()
        mock_pdfkit.configuration.return_value = object()
        mock_pdfkit.from_string.return_value = b"%PDF"

        with patch("velocity.misc.pdf.pdfkit", mock_pdfkit), patch(
            "velocity.misc.pdf._find_wkhtmltopdf", return_value="/opt/bin/wkhtmltopdf"
        ):
            html_to_pdf(
                "<h1>report</h1>",
                page_size="A4",
                orientation="landscape",
                margin_top="0.5in",
                margin_right="0.45in",
                margin_bottom="0.55in",
                margin_left="0.45in",
                footer_right="Page {page} of {pages}",
                footer_center="CaringCent, LLC",
                footer_font_size="8pt",
            )

        options = mock_pdfkit.from_string.call_args.kwargs["options"]
        assert options["page-size"] == "A4"
        assert options["orientation"] == "Landscape"
        assert options["margin-top"] == "0.5in"
        assert options["margin-right"] == "0.45in"
        assert options["margin-bottom"] == "0.55in"
        assert options["margin-left"] == "0.45in"
        assert options["footer-right"] == "Page [page] of [topage]"
        assert options["footer-center"] == "CaringCent, LLC"
        assert options["footer-font-size"] == "8"

    def test_shorthand_margin_applies_to_all_sides(self):
        mock_pdfkit = MagicMock()
        mock_pdfkit.configuration.return_value = object()
        mock_pdfkit.from_string.return_value = b"%PDF"

        with patch("velocity.misc.pdf.pdfkit", mock_pdfkit), patch(
            "velocity.misc.pdf._find_wkhtmltopdf", return_value="/opt/bin/wkhtmltopdf"
        ):
            html_to_pdf("<h1>report</h1>", margin="1in", footer_font_size="10pt")

        options = mock_pdfkit.from_string.call_args.kwargs["options"]
        assert options["margin-top"] == "1in"
        assert options["margin-right"] == "1in"
        assert options["margin-bottom"] == "1in"
        assert options["margin-left"] == "1in"

    def test_wrap_then_convert(self):
        mock_pdfkit = MagicMock()
        mock_pdfkit.configuration.return_value = object()
        mock_pdfkit.from_string.return_value = b"%PDF-wrapped"

        html = wrap_html("Report", "<p>Content</p>")

        with patch("velocity.misc.pdf.pdfkit", mock_pdfkit), patch(
            "velocity.misc.pdf._find_wkhtmltopdf", return_value="/opt/bin/wkhtmltopdf"
        ):
            result = html_to_pdf(html)

        assert result == b"%PDF-wrapped"
        passed_html = mock_pdfkit.from_string.call_args.args[0]
        assert "<title>Report</title>" in passed_html
        assert "<p>Content</p>" in passed_html

    def test_wraps_backend_errors(self):
        mock_pdfkit = MagicMock()
        mock_pdfkit.configuration.return_value = object()
        mock_pdfkit.from_string.side_effect = OSError("boom")

        with patch("velocity.misc.pdf.pdfkit", mock_pdfkit), patch(
            "velocity.misc.pdf._find_wkhtmltopdf", return_value="/opt/bin/wkhtmltopdf"
        ):
            with pytest.raises(RuntimeError, match="PDF generation failed: boom"):
                html_to_pdf("<h1>test</h1>")
