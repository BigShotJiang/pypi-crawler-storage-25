"""
Tests for R10 — Security Hardening: column quoting, DDL logging, credential masking.
"""

import logging
import re
import pytest
from unittest.mock import MagicMock, patch, call

from velocity.db.servers.base.sql import BaseSQLDialect


# ──────────────────────────────────────────────────────────────────────
# quote_identifier tests
# ──────────────────────────────────────────────────────────────────────


class TestQuoteIdentifier:
    """Verify quote_identifier on each dialect."""

    def test_base_dialect_double_quotes(self):
        assert BaseSQLDialect.quote_identifier("amount") == '"amount"'

    def test_base_dialect_escapes_internal_quotes(self):
        assert BaseSQLDialect.quote_identifier('col"name') == '"col""name"'

    def test_base_dialect_prevents_injection(self):
        malicious = 'sys_id); DROP TABLE users; --'
        quoted = BaseSQLDialect.quote_identifier(malicious)
        # Must be a single quoted identifier — entire payload wrapped in quotes
        assert quoted.startswith('"')
        assert quoted.endswith('"')
        assert quoted == '"sys_id); DROP TABLE users; --"'
        # When embedded in SQL like max("sys_id); DROP TABLE users; --"),
        # the DB treats the whole thing as one (non-existent) column name

    def test_postgres_inherits_default(self):
        from velocity.db.servers.postgres.sql import SQL as PgSQL
        assert PgSQL.quote_identifier("balance") == '"balance"'

    def test_mysql_uses_backticks(self):
        from velocity.db.servers.mysql.sql import SQL as MySqlSQL
        assert MySqlSQL.quote_identifier("balance") == "`balance`"

    def test_mysql_escapes_backtick(self):
        from velocity.db.servers.mysql.sql import SQL as MySqlSQL
        assert MySqlSQL.quote_identifier("col`name") == "`col``name`"

    def test_sqlserver_uses_brackets(self):
        from velocity.db.servers.sqlserver.sql import SQL as SsSQL
        assert SsSQL.quote_identifier("balance") == "[balance]"

    def test_sqlserver_escapes_bracket(self):
        from velocity.db.servers.sqlserver.sql import SQL as SsSQL
        assert SsSQL.quote_identifier("col]name") == "[col]]name]"


# ──────────────────────────────────────────────────────────────────────
# Aggregate column quoting integration tests
# ──────────────────────────────────────────────────────────────────────


def _make_table():
    """Create a Table with a mocked transaction and Postgres SQL dialect."""
    from velocity.db.core.table import Table
    from velocity.db.servers.postgres.sql import SQL as PgSQL

    tx = MagicMock()
    tx.engine.sql = PgSQL
    table = Table(tx, "accounts")
    table._cursor_obj = MagicMock()
    return table


class TestAggregateQuoting:
    """Verify aggregate SQL uses quoted column names."""

    def test_sum_quotes_column(self):
        table = _make_table()
        sql, _ = table.sum("balance", sql_only=True)
        # Column should be double-quoted inside the aggregate
        assert '"balance"' in sql
        assert 'sum(coalesce("balance"' in sql

    def test_max_quotes_column(self):
        table = _make_table()
        sql, _ = table.max("amount", sql_only=True)
        assert 'max("amount")' in sql

    def test_min_quotes_column(self):
        table = _make_table()
        sql, _ = table.min("amount", sql_only=True)
        assert 'min("amount")' in sql

    def test_sum_injection_prevented(self):
        table = _make_table()
        malicious = "balance); DROP TABLE users; --"
        sql, _ = table.sum(malicious, sql_only=True)
        # The malicious payload should be inside quotes, not executable
        assert "DROP TABLE" not in sql.split('"')[-1]  # not outside quotes

    def test_max_injection_prevented(self):
        table = _make_table()
        malicious = "x); DELETE FROM accounts; --"
        sql, _ = table.max(malicious, sql_only=True)
        assert "DELETE" not in sql.replace('"', "").split(")")[0]


# ──────────────────────────────────────────────────────────────────────
# DDL audit logging tests
# ──────────────────────────────────────────────────────────────────────


class TestDDLAuditLogging:
    """Verify DDL operations emit WARNING log messages."""

    def _make_table_with_sql(self):
        from velocity.db.core.table import Table
        tx = MagicMock()
        sql_dialect = MagicMock()
        sql_dialect.create_table.return_value = ("CREATE TABLE ...", [])
        sql_dialect.drop_table.return_value = ("DROP TABLE ...", [])
        sql_dialect.create_index.return_value = ("CREATE INDEX ...", [])
        sql_dialect.drop_index.return_value = ("DROP INDEX ...", [])
        sql_dialect.drop_column.return_value = ("ALTER TABLE DROP COLUMN ...", [])
        sql_dialect.create_foreign_key.return_value = ("ALTER TABLE ADD FK ...", [])
        sql_dialect.rename_table.return_value = ("ALTER TABLE RENAME ...", [])
        sql_dialect.rename_column.return_value = ("ALTER TABLE RENAME COLUMN ...", [])
        sql_dialect.alter_trigger.return_value = ("ALTER TABLE TRIGGER ...", [])
        sql_dialect.create_view.return_value = ("CREATE VIEW ...", [])
        sql_dialect.drop_view.return_value = ("DROP VIEW ...", [])
        sql_dialect.set_sequence.return_value = ("ALTER SEQUENCE ...", [])
        sql_dialect.alter_column_by_type.return_value = ("ALTER COLUMN ...", [])
        tx.engine.sql = sql_dialect
        tx.execute.return_value = MagicMock(cursor=MagicMock(), scalar=MagicMock(return_value=0))
        table = Table(tx, "test_table")
        table._cursor_obj = MagicMock()
        return table

    def test_create_table_logs_warning(self, caplog):
        table = self._make_table_with_sql()
        with caplog.at_level(logging.WARNING, logger="velocity.db.core.table"):
            table.create(columns={"name": "text", "age": "int"})
        assert any("DDL CREATE TABLE test_table" in r.message for r in caplog.records)
        assert any("name" in r.message and "age" in r.message for r in caplog.records)

    def test_drop_table_logs_warning(self, caplog):
        table = self._make_table_with_sql()
        with caplog.at_level(logging.WARNING, logger="velocity.db.core.table"):
            table.drop()
        assert any("DDL DROP TABLE test_table" in r.message for r in caplog.records)

    def test_create_index_logs_warning(self, caplog):
        table = self._make_table_with_sql()
        with caplog.at_level(logging.WARNING, logger="velocity.db.core.table"):
            table.create_index(columns=["email"], unique=True)
        assert any("DDL CREATE INDEX" in r.message and "unique=True" in r.message for r in caplog.records)

    def test_drop_column_logs_warning(self, caplog):
        table = self._make_table_with_sql()
        with caplog.at_level(logging.WARNING, logger="velocity.db.core.table"):
            table.drop_column("old_col")
        assert any("DDL DROP COLUMN old_col" in r.message for r in caplog.records)

    def test_rename_column_logs_warning(self, caplog):
        table = self._make_table_with_sql()
        with caplog.at_level(logging.WARNING, logger="velocity.db.core.table"):
            table.rename_column("old", "new")
        assert any("DDL RENAME COLUMN" in r.message and "old -> new" in r.message for r in caplog.records)

    def test_sql_only_does_not_log(self, caplog):
        """sql_only=True should return SQL without logging."""
        table = self._make_table_with_sql()
        with caplog.at_level(logging.WARNING, logger="velocity.db.core.table"):
            result = table.create_index(columns=["email"], sql_only=True)
        assert not any("DDL" in r.message for r in caplog.records)
        assert result is not None  # Should return the SQL tuple


# ──────────────────────────────────────────────────────────────────────
# Credential masking in error messages
# ──────────────────────────────────────────────────────────────────────


class TestCredentialMasking:
    """Verify credentials are masked in error messages raised by process_error."""

    def test_password_masked_in_connection_error(self):
        from velocity.db.core.engine import Engine
        from velocity.db import exceptions

        engine = MagicMock(spec=Engine)
        engine.sql = MagicMock()
        engine.sql.get_error.return_value = (None, "connection refused")
        engine.sql.ConnectionErrorCodes = []
        engine.sql.ApplicationErrorCodes = []
        engine.sql.ColumnMissingErrorCodes = []
        engine.sql.TableMissingErrorCodes = []
        engine.sql.DatabaseMissingErrorCodes = []
        engine.sql.ForeignKeyMissingErrorCodes = []
        engine.sql.TruncationErrorCodes = []
        engine.sql.DataIntegrityErrorCodes = []
        engine.sql.DuplicateKeyErrorCodes = []
        engine.sql.DatabaseObjectExistsErrorCodes = []
        engine.sql.LockTimeoutErrorCodes = []
        engine.sql.RetryTransactionCodes = []
        engine.sql.is_connection_error_message.return_value = False
        engine.sql.classify_by_message.return_value = None
        engine.sql.enhance_message.return_value = None

        # Simulate a driver error that includes a password in its message
        exc = Exception("connection to host=db.example.com password=s3cret123 failed")

        with pytest.raises(Exception) as exc_info:
            Engine.process_error(engine, exc)

        msg = str(exc_info.value)
        assert "s3cret123" not in msg
        assert "*****" in msg

    def test_url_credentials_masked(self):
        from velocity.db.core.engine import Engine

        engine = MagicMock(spec=Engine)
        engine.sql = MagicMock()
        engine.sql.get_error.return_value = (None, "fail")
        engine.sql.ConnectionErrorCodes = []
        engine.sql.ApplicationErrorCodes = []
        engine.sql.ColumnMissingErrorCodes = []
        engine.sql.TableMissingErrorCodes = []
        engine.sql.DatabaseMissingErrorCodes = []
        engine.sql.ForeignKeyMissingErrorCodes = []
        engine.sql.TruncationErrorCodes = []
        engine.sql.DataIntegrityErrorCodes = []
        engine.sql.DuplicateKeyErrorCodes = []
        engine.sql.DatabaseObjectExistsErrorCodes = []
        engine.sql.LockTimeoutErrorCodes = []
        engine.sql.RetryTransactionCodes = []
        engine.sql.is_connection_error_message.return_value = False
        engine.sql.classify_by_message.return_value = None
        engine.sql.enhance_message.return_value = None

        exc = Exception("could not connect to postgresql://admin:supersecret@db:5432/mydb")

        with pytest.raises(Exception) as exc_info:
            Engine.process_error(engine, exc)

        msg = str(exc_info.value)
        assert "supersecret" not in msg
        assert "*****" in msg

    def test_mask_sensitive_in_string_function(self):
        from velocity.db.utils import mask_sensitive_in_string

        # password= pattern
        assert "s3cret" not in mask_sensitive_in_string("password=s3cret host=db")
        # URL pattern
        assert "mypass" not in mask_sensitive_in_string("postgresql://user:mypass@host/db")
        # No credentials — unchanged
        assert mask_sensitive_in_string("normal error text") == "normal error text"
