from types import SimpleNamespace

from velocity.payment.braintree_adapter import BraintreeAdapter


def build_adapter():
    return BraintreeAdapter(
        {
            "merchant_id": "merchant",
            "public_key": "public",
            "private_key": "private",
            "environment": "sandbox",
        }
    )


def test_charge_stored_payment_method_success(monkeypatch):
    adapter = build_adapter()
    captured = {}

    def fake_sale(params):
        captured.update(params)
        return SimpleNamespace(
            is_success=True,
            transaction=SimpleNamespace(
                id="txn_123",
                amount="10.50",
                status="submitted_for_settlement",
                currency_iso_code="USD",
                processor_authorization_code="auth_123",
            ),
        )

    monkeypatch.setattr(adapter.gateway.transaction, "sale", fake_sale)

    result = adapter.charge_stored_payment_method(
        None,
        {
            "amount": 1050,
            "payment_method": "token_123",
            "descriptor": {"name": "CARINGCENT"},
            "metadata": {"client_id": "client_1", "campaign_id": "CAMP"},
        },
    )

    assert result["success"] is True
    assert result["processor_transaction_id"] == "txn_123"
    assert result["processor_charge_id"] == "txn_123"
    assert captured["payment_method_token"] == "token_123"
    assert captured["amount"] == "10.50"
    assert captured["descriptor"] == {"name": "CARINGCENT"}
    assert captured["custom_fields"]["client_id"] == "client_1"


def test_charge_stored_payment_method_failure_uses_processor_response(monkeypatch):
    adapter = build_adapter()

    def fake_sale(params):
        return SimpleNamespace(
            is_success=False,
            message="generic error",
            transaction=SimpleNamespace(processor_response_text="declined"),
            errors=SimpleNamespace(deep_errors=[]),
        )

    monkeypatch.setattr(adapter.gateway.transaction, "sale", fake_sale)

    result = adapter.charge_stored_payment_method(
        None,
        {
            "amount": 1050,
            "payment_method": "token_123",
        },
    )

    assert result["success"] is False
    assert result["error_message"] == "declined"