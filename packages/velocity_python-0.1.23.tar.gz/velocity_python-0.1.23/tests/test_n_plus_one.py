"""
Tests for R14 — N+1 Query Prevention.

Covers:
- Row._from_data() pre-populated cache
- Table.rows(prefetch=True) single-query eager loading
- Table.select_rows() convenience method
- Result.as_rows() transform
- N+1 detection warning in debug mode
"""

import logging
import time
import pytest
from unittest.mock import MagicMock, patch, call

from velocity.db.core.row import Row
from velocity.db.core.result import Result
from velocity.db.core import transaction as txmod


# ──────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────


def _make_table(rows_data=None):
    """Return a mock Table whose select() yields *rows_data* as dicts."""
    table = MagicMock()
    table.name = "orders"

    if rows_data is None:
        rows_data = [
            {"sys_id": 1, "name": "Alice", "total": 100},
            {"sys_id": 2, "name": "Bob", "total": 200},
            {"sys_id": 3, "name": "Carol", "total": 300},
        ]

    # Make the mock Result iterable so Table.rows(prefetch=True) works
    mock_result = MagicMock()
    mock_result.__iter__ = MagicMock(return_value=iter(rows_data))
    mock_result.all.return_value = list(rows_data)
    table.select.return_value = mock_result

    # For non-prefetch rows() path
    table.ids = MagicMock(return_value=iter([d["sys_id"] for d in rows_data]))

    return table, rows_data


# ──────────────────────────────────────────────────────────────────────
# Row._from_data
# ──────────────────────────────────────────────────────────────────────


class TestRowFromData:
    def test_cache_is_pre_populated(self):
        table = MagicMock()
        table.name = "orders"
        data = {"sys_id": 42, "name": "Alice", "total": 100}

        row = Row._from_data(table, data)

        assert row["sys_id"] == 42
        assert row["name"] == "Alice"
        assert row["total"] == 100
        # No DB call was made
        table.select.assert_not_called()

    def test_pk_extracted(self):
        table = MagicMock()
        table.name = "orders"
        data = {"sys_id": 7, "name": "Bob"}

        row = Row._from_data(table, data)

        assert row.pk == {"sys_id": 7}

    def test_to_dict_returns_full_data(self):
        table = MagicMock()
        table.name = "orders"
        data = {"sys_id": 1, "a": "x", "b": "y"}

        row = Row._from_data(table, data)
        assert row.to_dict() == data
        table.select.assert_not_called()

    def test_iteration(self):
        table = MagicMock()
        table.name = "orders"
        data = {"sys_id": 1, "name": "Alice"}

        row = Row._from_data(table, data)
        assert set(row.keys()) == {"sys_id", "name"}

    def test_write_through_still_works(self):
        table = MagicMock()
        table.name = "orders"
        data = {"sys_id": 1, "name": "Alice"}

        row = Row._from_data(table, data)
        row["name"] = "Bob"
        table.update_or_insert.assert_called_once()

    def test_cache_time_is_set(self):
        table = MagicMock()
        table.name = "orders"
        data = {"sys_id": 1, "name": "Alice"}

        before = time.monotonic()
        row = Row._from_data(table, data)
        after = time.monotonic()

        assert before <= row._cache_time <= after


# ──────────────────────────────────────────────────────────────────────
# Table.rows(prefetch=True)
# ──────────────────────────────────────────────────────────────────────


class TestRowsPrefetch:
    def test_prefetch_yields_rows_with_cache(self):
        """prefetch=True should do one SELECT and yield pre-populated Rows."""
        from velocity.db.core.table import Table

        table, data = _make_table()

        # Call the real rows() method but with our mock table
        rows = list(Table.rows(table, where={"status": "active"}, prefetch=True))

        assert len(rows) == 3
        # Each row should have data without triggering extra queries
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"
        assert rows[2]["name"] == "Carol"

        # select() called once (not ids())
        table.select.assert_called_once()
        table.ids.assert_not_called()

    def test_non_prefetch_uses_ids(self):
        """Without prefetch, rows() should use ids() as before."""
        from velocity.db.core.table import Table

        table, data = _make_table()

        # We can't fully test non-prefetch with mocks since Row() needs a real table,
        # but we can verify ids() is called
        table.ids.return_value = iter([1, 2, 3])

        # This will fail at Row() construction since table is a mock,
        # but ids() should be called
        try:
            list(Table.rows(table, where={"status": "active"}, prefetch=False))
        except Exception:
            pass

        table.ids.assert_called_once()


# ──────────────────────────────────────────────────────────────────────
# Table.select_rows()
# ──────────────────────────────────────────────────────────────────────


class TestSelectRows:
    def test_returns_list_of_rows(self):
        from velocity.db.core.table import Table

        table, data = _make_table()

        # Make select().all() return data so iteration works
        mock_result = MagicMock()
        mock_result.__iter__ = MagicMock(return_value=iter(data))
        table.select.return_value = mock_result

        rows = Table.select_rows(table, where={"status": "active"})

        assert isinstance(rows, list)
        assert len(rows) == 3
        assert all(isinstance(r, Row) for r in rows)
        assert rows[0]["sys_id"] == 1
        assert rows[2]["total"] == 300

    def test_single_select_call(self):
        from velocity.db.core.table import Table

        table, data = _make_table()
        mock_result = MagicMock()
        mock_result.__iter__ = MagicMock(return_value=iter(data))
        table.select.return_value = mock_result

        Table.select_rows(table, where={"status": "active"})

        table.select.assert_called_once()


# ──────────────────────────────────────────────────────────────────────
# Result.as_rows()
# ──────────────────────────────────────────────────────────────────────


class TestResultAsRows:
    def _make_result(self, rows_data):
        """Create a Result with a mock cursor returning *rows_data* (list of tuples)."""
        cursor = MagicMock()
        headers = list(rows_data[0].keys()) if rows_data else []
        cursor.description = [(h,) for h in headers]
        tuples = [tuple(d[h] for h in headers) for d in rows_data]

        call_count = [0]

        def fetchone():
            if call_count[0] < len(tuples):
                row = tuples[call_count[0]]
                call_count[0] += 1
                return row
            return None

        cursor.fetchone = fetchone
        return Result(cursor=cursor)

    def test_as_rows_returns_row_objects(self):
        table = MagicMock()
        table.name = "orders"
        data = [
            {"sys_id": 1, "name": "Alice"},
            {"sys_id": 2, "name": "Bob"},
        ]

        result = self._make_result(data)
        rows = result.as_rows(table).all()

        assert len(rows) == 2
        assert all(isinstance(r, Row) for r in rows)
        assert rows[0]["name"] == "Alice"
        assert rows[1]["name"] == "Bob"

    def test_as_rows_no_extra_queries(self):
        table = MagicMock()
        table.name = "orders"
        data = [{"sys_id": 1, "name": "Alice"}]

        result = self._make_result(data)
        rows = result.as_rows(table).all()

        _ = rows[0]["name"]
        table.select.assert_not_called()

    def test_as_rows_chainable(self):
        table = MagicMock()
        table.name = "orders"
        result = self._make_result([{"sys_id": 1, "name": "test"}])

        ret = result.as_rows(table)
        assert ret is result  # chainable


# ──────────────────────────────────────────────────────────────────────
# N+1 Detection
# ──────────────────────────────────────────────────────────────────────


class TestNPlusOneDetection:
    def test_warning_after_threshold(self):
        """In debug mode, warn when same table is queried > threshold times."""
        tx = MagicMock(spec=txmod.Transaction)
        tx._table_select_counts = {}
        tx._n1_warned = set()
        tx._query_count = 0
        tx._query_time_ms = 0.0

        old_debug = txmod.debug
        try:
            txmod.debug = True

            with patch.object(txmod, "_N_PLUS_1_THRESHOLD", 3):
                with patch.object(txmod._logger, "warning") as mock_warn:
                    # Simulate 4 SELECTs on the same table
                    for i in range(4):
                        sql = 'SELECT * FROM orders WHERE sys_id = %s'
                        tbl = txmod._extract_table_name(sql)
                        tx._table_select_counts[tbl] = tx._table_select_counts.get(tbl, 0) + 1
                        count = tx._table_select_counts[tbl]
                        if count > 3 and tbl not in tx._n1_warned:
                            tx._n1_warned.add(tbl)
                            txmod._logger.warning(
                                "Possible N+1: table %s queried %d times in this transaction "
                                "(threshold=%d). Consider using prefetch=True or select_rows().",
                                tbl, count, 3,
                                extra={"table_name": tbl, "select_count": count},
                            )

                    assert mock_warn.called
                    args = mock_warn.call_args[0]
                    assert "N+1" in args[0]
                    assert "orders" in args[1]
        finally:
            txmod.debug = old_debug

    def test_no_warning_below_threshold(self):
        """Below threshold, no warning should be emitted."""
        tx = MagicMock(spec=txmod.Transaction)
        tx._table_select_counts = {}
        tx._n1_warned = set()

        old_debug = txmod.debug
        try:
            txmod.debug = True

            with patch.object(txmod, "_N_PLUS_1_THRESHOLD", 10):
                with patch.object(txmod._logger, "warning") as mock_warn:
                    for i in range(5):
                        sql = 'SELECT * FROM orders WHERE sys_id = %s'
                        tbl = txmod._extract_table_name(sql)
                        tx._table_select_counts[tbl] = tx._table_select_counts.get(tbl, 0) + 1
                        count = tx._table_select_counts[tbl]
                        if count > 10 and tbl not in tx._n1_warned:
                            tx._n1_warned.add(tbl)
                            txmod._logger.warning("N+1 detected")

                    mock_warn.assert_not_called()
        finally:
            txmod.debug = old_debug

    def test_no_warning_when_debug_false(self):
        """When debug=False, N+1 detection should be skipped."""
        old_debug = txmod.debug
        try:
            txmod.debug = False
            # Just confirm the flag check — the real detection is in _execute()
            assert not txmod.debug
        finally:
            txmod.debug = old_debug

    def test_warning_only_once_per_table(self):
        """Once warned for a table, don't warn again in the same transaction."""
        tx_counts = {}
        tx_warned = set()

        warnings_emitted = []

        for i in range(20):
            tbl = "orders"
            tx_counts[tbl] = tx_counts.get(tbl, 0) + 1
            if tx_counts[tbl] > 5 and tbl not in tx_warned:
                tx_warned.add(tbl)
                warnings_emitted.append(tbl)

        assert len(warnings_emitted) == 1

    def test_transaction_init_has_tracking_attrs(self):
        """Transaction should initialise the N+1 tracking attributes."""
        engine = MagicMock()
        engine.pool_enabled = False
        tx = txmod.Transaction(engine)
        assert tx._table_select_counts == {}
        assert tx._n1_warned == set()
