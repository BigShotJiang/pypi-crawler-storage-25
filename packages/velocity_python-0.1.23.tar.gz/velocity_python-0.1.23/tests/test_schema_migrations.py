"""
Tests for R16 — Schema Migration Framework.

Covers:
- @migration decorator: registration, duplicate detection, up/down
- clear_registry / get_registry helpers
- MigrationRunner: pending, status, migrate, rollback, diff
- Schema locking: migrations temporarily unlock and re-lock
- Checksum detection for modified migrations
- Orphaned migration detection
- CLI entry point
- File-based migration discovery
"""

import logging
import os
import textwrap
import tempfile
import time

import pytest
from unittest.mock import MagicMock, patch, call, PropertyMock

from velocity.db.migrations import (
    migration,
    clear_registry,
    get_registry,
    MigrationRunner,
    _cli_main,
    _registry,
    TRACKING_TABLE,
)


# ── Fixtures ────────────────────────────────────────────────────────


@pytest.fixture(autouse=True)
def _clean_registry():
    """Ensure every test starts and ends with an empty migration registry."""
    clear_registry()
    yield
    clear_registry()


def _mock_result(rows, columns=None):
    """
    Create a mock Result that supports .all() returning list-of-dicts
    and .as_tuple() returning list-of-tuples.
    """
    result = MagicMock()
    result.all.return_value = rows
    if columns:
        result.as_tuple.return_value = [tuple(r[c] for c in columns) for r in rows]
    else:
        result.as_tuple.return_value = [(list(r.values())) for r in rows]
    return result


def _make_mock_table(exists=False, select_rows=None):
    """Return a mock Table with exists(), create(), select(), insert(), delete()."""
    table = MagicMock()
    table.exists.return_value = exists
    if select_rows is not None:
        table.select.return_value = _mock_result(select_rows)
    else:
        table.select.return_value = _mock_result([])
    return table


def _make_mock_engine(schema_locked=False):
    """Build a mock engine with transaction(), schema_locked, lock/unlock."""
    engine = MagicMock()
    engine.schema_locked = schema_locked

    # Track lock state so tests can verify unlock/re-lock sequence
    lock_state = {"locked": schema_locked}

    def unlock():
        lock_state["locked"] = False
        engine.schema_locked = False

    def lock():
        lock_state["locked"] = True
        engine.schema_locked = True

    engine.unlock_schema.side_effect = unlock
    engine.lock_schema.side_effect = lock
    engine._lock_state = lock_state

    return engine


def _make_mock_tx(applied_rows=None, table_exists=True):
    """
    Build a mock Transaction that supports:
    - tx.table(name) -> mock table with select/insert/delete
    - tx.cursor() -> mock cursor
    - tx.commit(), tx.rollback(), tx.close()
    """
    tx = MagicMock()
    tx.cursor.return_value = MagicMock()

    if applied_rows is None:
        applied_rows = []

    mock_table = _make_mock_table(exists=table_exists, select_rows=applied_rows)
    tx.table.return_value = mock_table

    return tx


# ── @migration decorator tests ─────────────────────────────────────


class TestMigrationDecorator:

    def test_register_up_migration(self):
        @migration(version=1, description="Create users")
        def up(tx):
            pass

        reg = get_registry()
        assert 1 in reg
        assert reg[1]["up"] is up
        assert reg[1]["down"] is None
        assert reg[1]["description"] == "Create users"

    def test_register_down_migration(self):
        @migration(version=1, description="Create users")
        def up(tx):
            pass

        @migration(version=1, down=True)
        def down(tx):
            pass

        reg = get_registry()
        assert reg[1]["up"] is up
        assert reg[1]["down"] is down

    def test_duplicate_up_raises(self):
        @migration(version=1, description="First")
        def up1(tx):
            pass

        with pytest.raises(ValueError, match="already has a 'up' function"):
            @migration(version=1, description="Second")
            def up2(tx):
                pass

    def test_duplicate_down_raises(self):
        @migration(version=1, down=True)
        def down1(tx):
            pass

        with pytest.raises(ValueError, match="already has a 'down' function"):
            @migration(version=1, down=True)
            def down2(tx):
                pass

    def test_multiple_versions(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        @migration(version=2, description="v2")
        def up2(tx):
            pass

        @migration(version=3, description="v3")
        def up3(tx):
            pass

        reg = get_registry()
        assert sorted(reg.keys()) == [1, 2, 3]

    def test_decorator_returns_original_function(self):
        @migration(version=1, description="test")
        def my_func(tx):
            return 42

        assert my_func(None) == 42

    def test_clear_registry(self):
        @migration(version=1, description="test")
        def up(tx):
            pass

        assert len(get_registry()) == 1
        clear_registry()
        assert len(get_registry()) == 0


# ── MigrationRunner.pending() ──────────────────────────────────────


class TestMigrationRunnerPending:

    def test_all_pending_when_none_applied(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        @migration(version=2, description="v2")
        def up2(tx):
            pass

        engine = _make_mock_engine()
        tx = _make_mock_tx(applied_rows=[], table_exists=True)
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        assert runner.pending() == [1, 2]

    def test_none_pending_when_all_applied(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        engine = _make_mock_engine()
        tx = _make_mock_tx(
            applied_rows=[{
                "version": 1, "description": "v1",
                "sys_created": "2024-01-01", "checksum": "abc", "execution_ms": 10,
            }],
            table_exists=True,
        )
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        assert runner.pending() == []

    def test_partial_pending(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        @migration(version=2, description="v2")
        def up2(tx):
            pass

        @migration(version=3, description="v3")
        def up3(tx):
            pass

        engine = _make_mock_engine()
        tx = _make_mock_tx(
            applied_rows=[{
                "version": 1, "description": "v1",
                "sys_created": "2024-01-01", "checksum": "abc", "execution_ms": 10,
            }],
            table_exists=True,
        )
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        assert runner.pending() == [2, 3]


# ── MigrationRunner.status() ───────────────────────────────────────


class TestMigrationRunnerStatus:

    def test_status_shows_applied_and_pending(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        @migration(version=2, description="v2")
        def up2(tx):
            pass

        @migration(version=2, down=True)
        def down2(tx):
            pass

        engine = _make_mock_engine()
        tx = _make_mock_tx(
            applied_rows=[{
                "version": 1, "description": "v1",
                "sys_created": "2024-01-01", "checksum": MigrationRunner._checksum(up1),
                "execution_ms": 15,
            }],
            table_exists=True,
        )
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        entries = runner.status()

        assert len(entries) == 2
        assert entries[0]["version"] == 1
        assert entries[0]["status"] == "applied"
        assert entries[0]["checksum_match"] is True
        assert entries[1]["version"] == 2
        assert entries[1]["status"] == "pending"
        assert entries[1]["reversible"] is True


# ── MigrationRunner.migrate() ──────────────────────────────────────


class TestMigrationRunnerMigrate:

    def test_migrate_calls_up_functions(self):
        call_log = []

        @migration(version=1, description="v1")
        def up1(tx):
            call_log.append(1)

        @migration(version=2, description="v2")
        def up2(tx):
            call_log.append(2)

        engine = _make_mock_engine()
        # For pending(): returns empty (nothing applied)
        tx_pending = _make_mock_tx(applied_rows=[], table_exists=True)
        # For each migrate(): returns a new tx
        tx_mig1 = _make_mock_tx(applied_rows=[], table_exists=True)
        tx_mig2 = _make_mock_tx(applied_rows=[], table_exists=True)

        engine.transaction.side_effect = [tx_pending, tx_mig1, tx_mig2]

        runner = MigrationRunner(engine)
        applied = runner.migrate()

        assert applied == [1, 2]
        assert call_log == [1, 2]
        tx_mig1.commit.assert_called_once()
        tx_mig2.commit.assert_called_once()

    def test_migrate_with_target(self):
        call_log = []

        @migration(version=1, description="v1")
        def up1(tx):
            call_log.append(1)

        @migration(version=2, description="v2")
        def up2(tx):
            call_log.append(2)

        @migration(version=3, description="v3")
        def up3(tx):
            call_log.append(3)

        engine = _make_mock_engine()
        tx_pending = _make_mock_tx(applied_rows=[], table_exists=True)
        tx_mig1 = _make_mock_tx(applied_rows=[], table_exists=True)
        tx_mig2 = _make_mock_tx(applied_rows=[], table_exists=True)

        engine.transaction.side_effect = [tx_pending, tx_mig1, tx_mig2]

        runner = MigrationRunner(engine)
        applied = runner.migrate(target=2)

        assert applied == [1, 2]
        assert call_log == [1, 2]

    def test_migrate_no_pending(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        engine = _make_mock_engine()
        tx = _make_mock_tx(
            applied_rows=[{
                "version": 1, "description": "v1",
                "sys_created": "2024-01-01", "checksum": "abc", "execution_ms": 10,
            }],
            table_exists=True,
        )
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        applied = runner.migrate()
        assert applied == []

    def test_migrate_dry_run(self, caplog):
        @migration(version=1, description="v1")
        def up1(tx):
            pytest.fail("Should not be called in dry_run")

        engine = _make_mock_engine()
        tx = _make_mock_tx(applied_rows=[], table_exists=True)
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        with caplog.at_level(logging.INFO, logger="velocity.db.migrations"):
            result = runner.migrate(dry_run=True)

        assert result == [1]
        assert "DRY RUN" in caplog.text

    def test_migrate_rollback_on_failure(self):
        @migration(version=1, description="v1")
        def up1(tx):
            raise RuntimeError("boom")

        engine = _make_mock_engine()
        tx_pending = _make_mock_tx(applied_rows=[], table_exists=True)
        tx_mig = _make_mock_tx(applied_rows=[], table_exists=True)
        engine.transaction.side_effect = [tx_pending, tx_mig]

        runner = MigrationRunner(engine)
        with pytest.raises(RuntimeError, match="boom"):
            runner.migrate()

        tx_mig.rollback.assert_called_once()

    def test_migrate_unlocks_and_relocks_schema(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        engine = _make_mock_engine(schema_locked=True)
        tx_pending = _make_mock_tx(applied_rows=[], table_exists=True)
        tx_mig = _make_mock_tx(applied_rows=[], table_exists=True)
        engine.transaction.side_effect = [tx_pending, tx_mig]

        runner = MigrationRunner(engine)
        runner.migrate()

        engine.unlock_schema.assert_called_once()
        engine.lock_schema.assert_called_once()
        # After migration, schema should be locked again
        assert engine.schema_locked is True

    def test_migrate_relocks_schema_on_failure(self):
        @migration(version=1, description="v1")
        def up1(tx):
            raise RuntimeError("fail")

        engine = _make_mock_engine(schema_locked=True)
        tx_pending = _make_mock_tx(applied_rows=[], table_exists=True)
        tx_mig = _make_mock_tx(applied_rows=[], table_exists=True)
        engine.transaction.side_effect = [tx_pending, tx_mig]

        runner = MigrationRunner(engine)
        with pytest.raises(RuntimeError):
            runner.migrate()

        # Schema must be re-locked even on failure
        engine.lock_schema.assert_called_once()
        assert engine.schema_locked is True


# ── MigrationRunner.rollback() ─────────────────────────────────────


class TestMigrationRunnerRollback:

    def test_rollback_latest(self):
        call_log = []

        @migration(version=1, description="v1")
        def up1(tx):
            pass

        @migration(version=1, down=True)
        def down1(tx):
            call_log.append("down_1")

        @migration(version=2, description="v2")
        def up2(tx):
            pass

        @migration(version=2, down=True)
        def down2(tx):
            call_log.append("down_2")

        engine = _make_mock_engine()
        tx_check = _make_mock_tx(
            applied_rows=[
                {"version": 1, "description": "v1", "sys_created": "2024-01-01", "checksum": "a", "execution_ms": 10},
                {"version": 2, "description": "v2", "sys_created": "2024-01-02", "checksum": "b", "execution_ms": 20},
            ],
            table_exists=True,
        )
        tx_rb = _make_mock_tx(table_exists=True)
        engine.transaction.side_effect = [tx_check, tx_rb]

        runner = MigrationRunner(engine)
        rolled = runner.rollback()

        assert rolled == [2]
        assert call_log == ["down_2"]
        tx_rb.commit.assert_called_once()

    def test_rollback_to_target(self):
        call_log = []

        @migration(version=1, description="v1")
        def up1(tx):
            pass

        @migration(version=1, down=True)
        def down1(tx):
            call_log.append("down_1")

        @migration(version=2, description="v2")
        def up2(tx):
            pass

        @migration(version=2, down=True)
        def down2(tx):
            call_log.append("down_2")

        @migration(version=3, description="v3")
        def up3(tx):
            pass

        @migration(version=3, down=True)
        def down3(tx):
            call_log.append("down_3")

        engine = _make_mock_engine()
        tx_check = _make_mock_tx(
            applied_rows=[
                {"version": 1, "description": "v1", "sys_created": "2024-01-01", "checksum": "a", "execution_ms": 10},
                {"version": 2, "description": "v2", "sys_created": "2024-01-02", "checksum": "b", "execution_ms": 20},
                {"version": 3, "description": "v3", "sys_created": "2024-01-03", "checksum": "c", "execution_ms": 30},
            ],
            table_exists=True,
        )
        tx_rb1 = _make_mock_tx(table_exists=True)
        tx_rb2 = _make_mock_tx(table_exists=True)
        engine.transaction.side_effect = [tx_check, tx_rb1, tx_rb2]

        runner = MigrationRunner(engine)
        rolled = runner.rollback(target=1)

        # Should roll back 3, then 2 — version 1 stays
        assert rolled == [3, 2]
        assert call_log == ["down_3", "down_2"]

    def test_rollback_no_down_raises(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        engine = _make_mock_engine()
        tx_check = _make_mock_tx(
            applied_rows=[
                {"version": 1, "description": "v1", "sys_created": "2024-01-01", "checksum": "a", "execution_ms": 10},
            ],
            table_exists=True,
        )
        engine.transaction.side_effect = [tx_check]

        runner = MigrationRunner(engine)
        with pytest.raises(ValueError, match="no 'down' function"):
            runner.rollback()

    def test_rollback_dry_run(self, caplog):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        @migration(version=1, down=True)
        def down1(tx):
            pytest.fail("Should not be called in dry_run")

        engine = _make_mock_engine()
        tx_check = _make_mock_tx(
            applied_rows=[
                {"version": 1, "description": "v1", "sys_created": "2024-01-01", "checksum": "a", "execution_ms": 10},
            ],
            table_exists=True,
        )
        engine.transaction.side_effect = [tx_check]

        runner = MigrationRunner(engine)
        with caplog.at_level(logging.INFO, logger="velocity.db.migrations"):
            result = runner.rollback(dry_run=True)

        assert result == [1]
        assert "DRY RUN" in caplog.text

    def test_rollback_unlocks_and_relocks_schema(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        @migration(version=1, down=True)
        def down1(tx):
            pass

        engine = _make_mock_engine(schema_locked=True)
        tx_check = _make_mock_tx(
            applied_rows=[
                {"version": 1, "description": "v1", "sys_created": "2024-01-01", "checksum": "a", "execution_ms": 10},
            ],
            table_exists=True,
        )
        tx_rb = _make_mock_tx(table_exists=True)
        engine.transaction.side_effect = [tx_check, tx_rb]

        runner = MigrationRunner(engine)
        runner.rollback()

        engine.unlock_schema.assert_called_once()
        engine.lock_schema.assert_called_once()


# ── MigrationRunner.diff() ─────────────────────────────────────────


class TestMigrationRunnerDiff:

    def test_diff_all_pending(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        @migration(version=2, description="v2")
        def up2(tx):
            pass

        engine = _make_mock_engine()
        tx = _make_mock_tx(applied_rows=[], table_exists=True)
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        d = runner.diff()

        assert d["pending_count"] == 2
        assert d["pending_versions"] == [1, 2]
        assert d["applied_count"] == 0
        assert d["modified"] == []
        assert d["orphaned"] == []

    def test_diff_up_to_date(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        engine = _make_mock_engine()
        tx = _make_mock_tx(
            applied_rows=[{
                "version": 1, "description": "v1",
                "sys_created": "2024-01-01",
                "checksum": MigrationRunner._checksum(up1),
                "execution_ms": 10,
            }],
            table_exists=True,
        )
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        d = runner.diff()

        assert d["pending_count"] == 0
        assert d["applied_count"] == 1
        assert d["modified"] == []

    def test_diff_detects_modified(self):
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        engine = _make_mock_engine()
        tx = _make_mock_tx(
            applied_rows=[{
                "version": 1, "description": "v1",
                "sys_created": "2024-01-01",
                "checksum": "old_checksum_not_matching",
                "execution_ms": 10,
            }],
            table_exists=True,
        )
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        d = runner.diff()

        assert d["modified"] == [1]

    def test_diff_detects_orphaned(self):
        engine = _make_mock_engine()
        tx = _make_mock_tx(
            applied_rows=[{
                "version": 99, "description": "ghost",
                "sys_created": "2024-01-01",
                "checksum": "abc",
                "execution_ms": 10,
            }],
            table_exists=True,
        )
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        d = runner.diff()

        assert d["orphaned"] == [99]


# ── MigrationRunner checksum ───────────────────────────────────────


class TestChecksum:

    def test_checksum_deterministic(self):
        def my_func(tx):
            pass

        c1 = MigrationRunner._checksum(my_func)
        c2 = MigrationRunner._checksum(my_func)
        assert c1 == c2
        assert len(c1) == 16  # truncated SHA-256

    def test_different_functions_different_checksums(self):
        def func_a(tx):
            pass

        def func_b(tx):
            return 1

        assert MigrationRunner._checksum(func_a) != MigrationRunner._checksum(func_b)


# ── File-based migration discovery ─────────────────────────────────


class TestMigrationDiscovery:

    def test_load_from_directory(self, tmp_path):
        """Migrations in .py files in a directory are auto-discovered."""
        mig_file = tmp_path / "001_create_users.py"
        mig_file.write_text(textwrap.dedent("""\
            from velocity.db.migrations import migration

            @migration(version=1, description="Create users table")
            def up(tx):
                pass

            @migration(version=1, down=True)
            def down(tx):
                pass
        """))

        engine = _make_mock_engine()
        tx = _make_mock_tx(applied_rows=[], table_exists=True)
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine, migrations_dir=str(tmp_path))
        assert runner.pending() == [1]
        reg = get_registry()
        assert reg[1]["description"] == "Create users table"
        assert reg[1]["down"] is not None

    def test_load_skips_underscore_files(self, tmp_path):
        """Files starting with _ are ignored."""
        (tmp_path / "__init__.py").write_text("")
        (tmp_path / "_helper.py").write_text(
            "from velocity.db.migrations import migration\n"
            "@migration(version=99, description='should not load')\n"
            "def up(tx): pass\n"
        )
        (tmp_path / "001_real.py").write_text(
            "from velocity.db.migrations import migration\n"
            "@migration(version=1, description='real')\n"
            "def up(tx): pass\n"
        )

        engine = _make_mock_engine()
        tx = _make_mock_tx(applied_rows=[], table_exists=True)
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine, migrations_dir=str(tmp_path))
        assert runner.pending() == [1]
        assert 99 not in get_registry()

    def test_missing_directory_raises(self):
        engine = _make_mock_engine()
        with pytest.raises(FileNotFoundError, match="not found"):
            MigrationRunner(engine, migrations_dir="/nonexistent/path")


# ── Tracking table creation ────────────────────────────────────────


class TestTrackingTable:

    def test_tracking_table_created_when_missing(self):
        """If tracking table doesn't exist, it's created on first use."""
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        engine = _make_mock_engine()
        # Table doesn't exist initially
        tx = _make_mock_tx(applied_rows=[], table_exists=False)
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        runner.pending()

        # Should have called table.create() with column definitions
        mock_table = tx.table.return_value
        mock_table.create.assert_called_once()
        create_kwargs = mock_table.create.call_args
        columns = create_kwargs[1].get("columns") or create_kwargs[0][0]
        assert "version" in columns
        assert "description" in columns
        assert "checksum" in columns
        assert "execution_ms" in columns

    def test_tracking_table_not_recreated_when_exists(self):
        """If tracking table exists, no create() is issued."""
        @migration(version=1, description="v1")
        def up1(tx):
            pass

        engine = _make_mock_engine()
        tx = _make_mock_tx(applied_rows=[], table_exists=True)
        engine.transaction.return_value = tx

        runner = MigrationRunner(engine)
        runner.pending()

        # Should NOT have called table.create()
        mock_table = tx.table.return_value
        mock_table.create.assert_not_called()


# ── CLI tests ──────────────────────────────────────────────────────


class TestCLI:

    def test_cli_no_command_shows_help(self, capsys):
        result = _cli_main([])
        assert result == 1

    @patch("velocity.db.migrations.MigrationRunner")
    @patch("velocity.db.servers.postgres.initialize")
    def test_cli_migrate(self, mock_init, mock_runner_cls):
        mock_engine = _make_mock_engine()
        mock_init.return_value = mock_engine
        mock_runner = MagicMock()
        mock_runner.migrate.return_value = [1, 2]
        mock_runner_cls.return_value = mock_runner

        result = _cli_main(["migrate"])

        assert result == 0
        mock_runner.migrate.assert_called_once_with(target=None, dry_run=False)

    @patch("velocity.db.migrations.MigrationRunner")
    @patch("velocity.db.servers.postgres.initialize")
    def test_cli_migrate_with_target(self, mock_init, mock_runner_cls):
        mock_engine = _make_mock_engine()
        mock_init.return_value = mock_engine
        mock_runner = MagicMock()
        mock_runner.migrate.return_value = [1]
        mock_runner_cls.return_value = mock_runner

        result = _cli_main(["migrate", "--to", "1"])

        assert result == 0
        mock_runner.migrate.assert_called_once_with(target=1, dry_run=False)

    @patch("velocity.db.migrations.MigrationRunner")
    @patch("velocity.db.servers.postgres.initialize")
    def test_cli_rollback(self, mock_init, mock_runner_cls):
        mock_engine = _make_mock_engine()
        mock_init.return_value = mock_engine
        mock_runner = MagicMock()
        mock_runner.rollback.return_value = [2]
        mock_runner_cls.return_value = mock_runner

        result = _cli_main(["rollback"])

        assert result == 0
        mock_runner.rollback.assert_called_once_with(target=None, dry_run=False)

    @patch("velocity.db.migrations.MigrationRunner")
    @patch("velocity.db.servers.postgres.initialize")
    def test_cli_status(self, mock_init, mock_runner_cls):
        mock_engine = _make_mock_engine()
        mock_init.return_value = mock_engine
        mock_runner = MagicMock()
        mock_runner.status.return_value = [
            {"version": 1, "status": "applied", "description": "v1",
             "applied_at": "2024-01-01", "execution_ms": 10,
             "checksum_match": True, "reversible": True},
        ]
        mock_runner_cls.return_value = mock_runner

        result = _cli_main(["status"])

        assert result == 0

    @patch("velocity.db.migrations.MigrationRunner")
    @patch("velocity.db.servers.postgres.initialize")
    def test_cli_diff(self, mock_init, mock_runner_cls):
        mock_engine = _make_mock_engine()
        mock_init.return_value = mock_engine
        mock_runner = MagicMock()
        mock_runner.diff.return_value = {
            "pending_count": 0,
            "pending_versions": [],
            "applied_count": 1,
            "modified": [],
            "orphaned": [],
        }
        mock_runner_cls.return_value = mock_runner

        result = _cli_main(["diff"])

        assert result == 0

    def test_cli_engine_init_failure(self):
        """CLI returns error when database can't be initialized."""
        with patch("velocity.db.servers.postgres.initialize", side_effect=Exception("no db")):
            result = _cli_main(["migrate"])
        assert result == 1
