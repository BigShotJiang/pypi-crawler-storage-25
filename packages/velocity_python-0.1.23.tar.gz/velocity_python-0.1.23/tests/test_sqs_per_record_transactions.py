"""
Tests for R8 — SQS Per-Record Transactions.

Verifies that each SQS record is processed in its own transaction with
independent commit/rollback, and that partial batch failures are reported
via the ``batchItemFailures`` SQS response format.
"""

import json
import pytest
from unittest.mock import MagicMock, patch, call

from velocity.aws.handlers.sqs_handler import SqsHandler
from velocity.aws.handlers.context_factory import ContextFactory


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_record(message_id, body, receive_count=1):
    """Build a minimal SQS record dict."""
    return {
        "messageId": message_id,
        "body": json.dumps(body) if isinstance(body, dict) else body,
        "attributes": {
            "ApproximateReceiveCount": str(receive_count),
        },
    }


def _make_event(*records):
    return {"Records": list(records)}


class _StubContext:
    """Lightweight context that satisfies execute_actions requirements."""

    def __init__(self, **kwargs):
        self._args = kwargs.get("args", {})
        self._postdata = kwargs.get("postdata", {})
        self._response = kwargs.get("response", None)
        self.perf = MagicMock()

    def action(self):
        if isinstance(self._postdata, dict):
            return self._postdata.get("action", "")
        return ""

    def args(self):
        return self._args

    def postdata(self, keys=-1, default=None):
        if keys == -1:
            return self._postdata
        if not isinstance(keys, list):
            keys = [keys]
        data = self._postdata
        for key in keys:
            if isinstance(data, dict) and key in data:
                data = data[key]
            else:
                return default
        return data

    def response(self):
        return self._response

    def configure_perf(self, **kw):
        pass


class _StubContextFactory(ContextFactory):
    """Factory that produces _StubContext objects without DB access."""

    def create(self, *, aws_event, aws_context, args, postdata, response, session):
        return _StubContext(args=args, postdata=postdata, response=response)


class _StubTransaction:
    """Minimal transaction context manager for testing."""

    def __init__(self):
        self.committed = False
        self.rolled_back = False
        self.closed = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            self.rolled_back = True
        else:
            self.committed = True
        self.closed = True
        return False  # don't suppress

    def rollback(self):
        self.rolled_back = True

    def commit(self):
        self.committed = True

    def close(self):
        self.closed = True


def _make_handler(event, handler_cls=None, action_side_effect=None):
    """
    Create a handler instance wired with stub context factory and a mock
    engine on the outer tx.

    *action_side_effect* — if a dict mapping messageId→Exception, the
    OnActionDefault will raise for matching records.  If callable, it is
    called for every record.
    """
    cls = handler_cls or SqsHandler
    handler = cls(event, MagicMock(), context_factory=_StubContextFactory())

    # Track which records we've processed
    handler._processed_records = []
    _side_effect = action_side_effect

    # Record-tracking that maps record context to the _StubTransaction
    handler._record_txns = []
    _txn_list = handler._record_txns

    class _Engine:
        """Mock engine whose transaction() returns _StubTransactions."""

        def transaction(self):
            txn = _StubTransaction()
            _txn_list.append(txn)
            return txn

    # The outer tx passed by the @engine.transaction decorator.
    outer_tx = MagicMock()
    outer_tx.engine = _Engine()
    handler._outer_tx = outer_tx

    # Install an action handler that optionally fails.
    original_default = handler.OnActionDefault

    def _action(tx, context):
        handler._processed_records.append(context.postdata())
        if _side_effect is not None:
            if callable(_side_effect) and not isinstance(_side_effect, dict):
                _side_effect(tx, context)
            elif isinstance(_side_effect, dict):
                # Lookup by action name
                action = context.action()
                exc = _side_effect.get(action)
                if exc is not None:
                    raise exc

    handler.OnActionDefault = _action
    return handler


# ---------------------------------------------------------------------------
# Tests — Per-Record Transactions
# ---------------------------------------------------------------------------

class TestPerRecordTransactions:

    def test_each_record_gets_own_transaction(self):
        event = _make_event(
            _make_record("m1", {"action": "a"}),
            _make_record("m2", {"action": "b"}),
            _make_record("m3", {"action": "c"}),
        )
        handler = _make_handler(event)
        result = handler.serve(handler._outer_tx)

        assert result is None  # no failures
        assert len(handler._record_txns) == 3
        for txn in handler._record_txns:
            assert txn.committed
            assert not txn.rolled_back

    def test_successful_records_committed(self):
        event = _make_event(
            _make_record("m1", {"action": "ok1"}),
            _make_record("m2", {"action": "ok2"}),
        )
        handler = _make_handler(event)
        handler.serve(handler._outer_tx)

        assert all(t.committed for t in handler._record_txns)

    def test_failed_record_rolled_back(self):
        """When an action raises and handle_error re-raises, the transaction
        is rolled back by the context manager."""
        event = _make_event(
            _make_record("m1", {"action": "ok"}),
            _make_record("m2", {"action": "fail"}),
            _make_record("m3", {"action": "ok2"}),
        )
        handler = _make_handler(
            event,
            action_side_effect={"fail": RuntimeError("boom")},
        )
        result = handler.serve(handler._outer_tx)

        # m2 should be in failures
        assert result == {"batchItemFailures": [{"itemIdentifier": "m2"}]}
        # m1 and m3 committed, m2 rolled back
        assert handler._record_txns[0].committed
        assert handler._record_txns[1].rolled_back
        assert handler._record_txns[2].committed

    def test_all_records_processed_even_with_failures(self):
        """Failure of one record should not prevent processing of later records."""
        event = _make_event(
            _make_record("m1", {"action": "fail1"}),
            _make_record("m2", {"action": "ok"}),
            _make_record("m3", {"action": "fail2"}),
        )
        handler = _make_handler(
            event,
            action_side_effect={
                "fail1": RuntimeError("err1"),
                "fail2": RuntimeError("err2"),
            },
        )
        result = handler.serve(handler._outer_tx)

        assert len(handler._processed_records) == 3
        assert result == {
            "batchItemFailures": [
                {"itemIdentifier": "m1"},
                {"itemIdentifier": "m3"},
            ]
        }


# ---------------------------------------------------------------------------
# Tests — batchItemFailures Response
# ---------------------------------------------------------------------------

class TestBatchItemFailures:

    def test_no_failures_returns_none(self):
        event = _make_event(_make_record("m1", {"action": "ok"}))
        handler = _make_handler(event)
        result = handler.serve(handler._outer_tx)
        assert result is None

    def test_partial_failure_format(self):
        event = _make_event(
            _make_record("m1", {"action": "ok"}),
            _make_record("m2", {"action": "fail"}),
        )
        handler = _make_handler(
            event, action_side_effect={"fail": ValueError("bad")}
        )
        result = handler.serve(handler._outer_tx)
        assert result == {"batchItemFailures": [{"itemIdentifier": "m2"}]}

    def test_all_failures(self):
        event = _make_event(
            _make_record("m1", {"action": "fail1"}),
            _make_record("m2", {"action": "fail2"}),
        )
        handler = _make_handler(
            event,
            action_side_effect={
                "fail1": RuntimeError("e1"),
                "fail2": RuntimeError("e2"),
            },
        )
        result = handler.serve(handler._outer_tx)
        assert result == {
            "batchItemFailures": [
                {"itemIdentifier": "m1"},
                {"itemIdentifier": "m2"},
            ]
        }

    def test_empty_records_returns_none(self):
        event = {"Records": []}
        handler = SqsHandler(event, MagicMock(), context_factory=_StubContextFactory())
        result = handler.serve(MagicMock())
        assert result is None

    def test_no_records_key_returns_none(self):
        event = {}
        handler = SqsHandler(event, MagicMock(), context_factory=_StubContextFactory())
        result = handler.serve(MagicMock())
        assert result is None

    def test_record_without_message_id_not_in_failures(self):
        """If a record lacks messageId, the failure is still processed but
        not added to batchItemFailures (can't identify it)."""
        record = {
            "body": json.dumps({"action": "fail"}),
            "attributes": {},
        }
        event = {"Records": [record]}
        handler = _make_handler(
            event, action_side_effect={"fail": RuntimeError("boom")}
        )
        result = handler.serve(handler._outer_tx)
        # No messageId → nothing to report
        assert result is None


# ---------------------------------------------------------------------------
# Tests — on_record_error Hook
# ---------------------------------------------------------------------------

class TestOnRecordError:

    def test_default_hook_logs_error(self):
        record = _make_record("m1", {"action": "fail"}, receive_count=3)
        handler = SqsHandler(
            _make_event(record), MagicMock(), context_factory=_StubContextFactory()
        )
        # Just verify it doesn't raise
        handler.on_record_error(record, RuntimeError("test"))

    def test_hook_called_for_each_failure(self):
        event = _make_event(
            _make_record("m1", {"action": "fail1"}),
            _make_record("m2", {"action": "ok"}),
            _make_record("m3", {"action": "fail2"}),
        )
        handler = _make_handler(
            event,
            action_side_effect={
                "fail1": RuntimeError("e1"),
                "fail2": RuntimeError("e2"),
            },
        )
        calls = []
        handler.on_record_error = lambda rec, exc: calls.append(
            (rec["messageId"], str(exc))
        )
        handler.serve(handler._outer_tx)
        assert calls == [("m1", "e1"), ("m3", "e2")]

    def test_custom_hook_override(self):
        class CustomHandler(SqsHandler):
            error_records = []

            def on_record_error(self, record, exception):
                self.error_records.append(record["messageId"])

        event = _make_event(
            _make_record("m1", {"action": "fail"}),
        )
        handler = CustomHandler(
            event, MagicMock(), context_factory=_StubContextFactory()
        )
        handler.OnActionDefault = lambda tx, ctx: (_ for _ in ()).throw(
            RuntimeError("boom")
        )

        # Wire up engine
        outer_tx = MagicMock()
        outer_tx.engine = MagicMock()
        outer_tx.engine.transaction.return_value = _StubTransaction()
        handler.serve(outer_tx)

        assert handler.error_records == ["m1"]


# ---------------------------------------------------------------------------
# Tests — onError Integration (handle_error swallows error)
# ---------------------------------------------------------------------------

class TestOnErrorIntegration:

    def test_handled_error_not_in_failures(self):
        """When onError handles the error (no re-raise), the record is NOT
        reported as a failure — the error was successfully handled."""
        event = _make_event(
            _make_record("m1", {"action": "fail"}),
        )
        handler = _make_handler(
            event, action_side_effect={"fail": RuntimeError("handled")}
        )
        # Add onError so handle_error doesn't re-raise
        handler.onError = MagicMock()

        result = handler.serve(handler._outer_tx)
        # onError swallowed the error → record is "handled" → no failure
        assert result is None
        handler.onError.assert_called_once()

    def test_onerror_that_reraises_causes_failure(self):
        """If onError itself raises, the record is reported as failed."""
        event = _make_event(
            _make_record("m1", {"action": "fail"}),
        )
        handler = _make_handler(
            event, action_side_effect={"fail": RuntimeError("orig")}
        )
        handler.onError = MagicMock(side_effect=RuntimeError("onError failed"))

        result = handler.serve(handler._outer_tx)
        assert result == {"batchItemFailures": [{"itemIdentifier": "m1"}]}


# ---------------------------------------------------------------------------
# Tests — Rollback Before handle_error
# ---------------------------------------------------------------------------

class TestRollbackBeforeHandleError:

    def test_rollback_called_before_handle_error(self):
        """When execute_actions raises, tx.rollback() is called before
        handle_error so onError gets a usable transaction."""
        event = _make_event(_make_record("m1", {"action": "fail"}))
        handler = _make_handler(
            event, action_side_effect={"fail": RuntimeError("boom")}
        )
        # Track rollback and onError calls
        rollback_order = []
        handler.onError = lambda tx, ctx, exc, tb: rollback_order.append("onError")

        # We need to intercept the record tx's rollback
        original_serve = handler.serve

        def patched_serve(tx):
            # Replace the engine.transaction to track rollback order
            original_engine_tx = tx.engine.transaction

            def tracking_transaction():
                txn = original_engine_tx()
                original_rollback = txn.rollback

                def tracked_rollback():
                    rollback_order.append("rollback")
                    return original_rollback()

                txn.rollback = tracked_rollback
                return txn

            tx.engine.transaction = tracking_transaction
            return original_serve(tx)

        result = patched_serve(handler._outer_tx)
        assert rollback_order == ["rollback", "onError"]


# ---------------------------------------------------------------------------
# Tests — Transaction Isolation
# ---------------------------------------------------------------------------

class TestTransactionIsolation:

    def test_failed_record_does_not_affect_later_records(self):
        """Each record gets its own transaction, so a failure in record 1
        does not affect record 2's transaction."""
        processed = []

        def action_fn(tx, context):
            action = context.action()
            if action == "fail":
                raise RuntimeError("boom")
            processed.append(action)

        event = _make_event(
            _make_record("m1", {"action": "fail"}),
            _make_record("m2", {"action": "ok1"}),
            _make_record("m3", {"action": "ok2"}),
        )
        handler = _make_handler(event, action_side_effect=action_fn)
        result = handler.serve(handler._outer_tx)

        assert processed == ["ok1", "ok2"]
        assert result == {"batchItemFailures": [{"itemIdentifier": "m1"}]}

    def test_outer_tx_not_used_for_db_work(self):
        """The outer tx (from @engine.transaction decorator) should only be
        used to access tx.engine. No DB operations on it."""
        event = _make_event(_make_record("m1", {"action": "ok"}))
        handler = _make_handler(event)
        outer_tx = handler._outer_tx
        handler.serve(outer_tx)

        # The outer tx's cursor/execute/commit should not have been called
        outer_tx.cursor.assert_not_called()
        outer_tx.execute.assert_not_called()


# ---------------------------------------------------------------------------
# Tests — DLQ Candidate Detection
# ---------------------------------------------------------------------------

class TestDLQCandidate:

    def test_below_threshold(self):
        record = _make_record("m1", {}, receive_count=1)
        assert SqsHandler.is_dlq_candidate(record) is False

    def test_at_threshold(self):
        record = _make_record("m1", {}, receive_count=5)
        assert SqsHandler.is_dlq_candidate(record) is True

    def test_above_threshold(self):
        record = _make_record("m1", {}, receive_count=10)
        assert SqsHandler.is_dlq_candidate(record) is True

    def test_custom_threshold(self):
        record = _make_record("m1", {}, receive_count=3)
        assert SqsHandler.is_dlq_candidate(record, max_receives=3) is True
        assert SqsHandler.is_dlq_candidate(record, max_receives=4) is False

    def test_missing_receive_count(self):
        record = {"messageId": "m1", "body": "{}", "attributes": {}}
        assert SqsHandler.is_dlq_candidate(record) is False


# ---------------------------------------------------------------------------
# Tests — Edge Cases
# ---------------------------------------------------------------------------

class TestEdgeCases:

    def test_non_json_body(self):
        """Non-JSON body should be wrapped in raw_body."""
        event = _make_event(
            {"messageId": "m1", "body": "plain text", "attributes": {}},
        )
        handler = _make_handler(event)
        result = handler.serve(handler._outer_tx)
        # Should still process (OnActionDefault called, no action → default)
        assert result is None
        assert len(handler._processed_records) == 1
        assert handler._processed_records[0] == {"raw_body": "plain text"}

    def test_empty_body(self):
        event = _make_event(
            {"messageId": "m1", "attributes": {}},
        )
        handler = _make_handler(event)
        handler.serve(handler._outer_tx)
        assert len(handler._processed_records) == 1
        assert handler._processed_records[0] == {}

    def test_action_routing_from_body(self):
        """The action field in the body should be used for routing."""
        event = _make_event(
            _make_record("m1", {"action": "process-order"}),
        )
        handler = SqsHandler(
            event, MagicMock(), context_factory=_StubContextFactory()
        )
        calls = []

        def on_action_process_order(tx, ctx):
            calls.append("OnActionProcessOrder")

        handler.OnActionProcessOrder = on_action_process_order

        outer_tx = MagicMock()
        outer_tx.engine = MagicMock()
        outer_tx.engine.transaction.return_value = _StubTransaction()
        handler.serve(outer_tx)

        assert calls == ["OnActionProcessOrder"]

    def test_large_batch(self):
        """Handles a large batch without issues."""
        records = [_make_record(f"m{i}", {"action": "ok"}) for i in range(100)]
        event = _make_event(*records)
        handler = _make_handler(event)
        result = handler.serve(handler._outer_tx)
        assert result is None
        assert len(handler._record_txns) == 100

    def test_mixed_results_preserves_order(self):
        """Failure order in batchItemFailures matches record order."""
        event = _make_event(
            _make_record("m1", {"action": "ok"}),
            _make_record("m2", {"action": "fail1"}),
            _make_record("m3", {"action": "ok"}),
            _make_record("m4", {"action": "fail2"}),
            _make_record("m5", {"action": "ok"}),
        )
        handler = _make_handler(
            event,
            action_side_effect={
                "fail1": ValueError("e1"),
                "fail2": ValueError("e2"),
            },
        )
        result = handler.serve(handler._outer_tx)
        ids = [f["itemIdentifier"] for f in result["batchItemFailures"]]
        assert ids == ["m2", "m4"]
