import json
import unittest
from types import SimpleNamespace

from velocity.aws.handlers.base_handler import BaseHandler
from velocity.aws.handlers.response import Response


class DummyContext:
    def __init__(self, response):
        self._response = response

    def response(self):
        return self._response

    def action(self):
        return "button-click"


class DummyHandler(BaseHandler):
    def __init__(self, aws_context=None):
        super().__init__({}, aws_context or SimpleNamespace(aws_request_id="req-123"))
        self.on_error_calls = []

    def onError(self, tx, context, exc, tb):
        self.on_error_calls.append({"exc": exc, "tb": tb})


class TestBaseHandlerErrorResponse(unittest.TestCase):
    def test_unhandled_http_error_sets_generic_response(self):
        handler = DummyHandler()
        response = Response()
        context = DummyContext(response)

        handler.handle_error(tx=None, local_context=context, exception=RuntimeError("secret details"))

        self.assertEqual(response.status(), 500)
        self.assertEqual(response.body["message"], "Something went wrong while processing your request.")
        self.assertEqual(response.body["detail"], "More information has been logged on the backend.")
        self.assertTrue(response.body["logged"])
        self.assertEqual(response.body["reference_id"], "req-123")

        rendered = response.render()
        body = json.loads(rendered["body"])
        self.assertEqual(rendered["statusCode"], 500)
        self.assertEqual(len(body["actions"]), 2)
        self.assertEqual(body["actions"][0]["action"], "console")
        self.assertEqual(body["actions"][1]["action"], "alert")
        self.assertIn("Reference: req-123.", body["actions"][1]["payload"]["message"])
        self.assertNotIn("secret details", body["actions"][1]["payload"]["message"])
        self.assertEqual(len(handler.on_error_calls), 1)

    def test_unhandled_non_http_error_without_onerror_reraises(self):
        handler = BaseHandler({}, SimpleNamespace(aws_request_id="req-456"))
        context = DummyContext(None)

        with self.assertRaises(RuntimeError):
            handler.handle_error(tx=None, local_context=context, exception=RuntimeError("boom"))


if __name__ == "__main__":
    unittest.main()