import datetime
import json
import os
import re
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple, Union

import boto3
import botocore.exceptions

try:
    from zoneinfo import ZoneInfo
except ImportError:
    ZoneInfo = None

try:
    import pytz
except ImportError:
    pytz = None

from velocity.aws.amplify import AmplifyProject


ANSI_ESCAPE_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
USER_POOL_ID_RE = re.compile(r'"UserPoolId": "(.*)",', re.I | re.M)
DEFAULT_ENV_PASSTHROUGH_KEYS = (
    "AWS_JOB_ID",
    "AWS_BRANCH",
    "AWS_COMMIT_ID",
    "AWS_COMMIT_MESSAGE",
    "AWS_EXECUTION_ENV",
    "AWS_APP_ID",
    "AWS_PROJECT_NAME",
    "AWS_BRANCH_ENV",
    "AWS_BACKEND_ENV",
)
THROTTLE_ERROR_CODES = {
    "Throttling",
    "ThrottlingException",
    "RequestLimitExceeded",
    "TooManyRequestsException",
}


@dataclass(frozen=True)
class BackendDeploymentConfig:
    queue_name_template: str
    subnet_ids: Tuple[str, ...] = field(default_factory=tuple)
    security_group_ids: Tuple[str, ...] = field(default_factory=tuple)
    short_timeout_seconds: int = 60
    default_timeout_seconds: int = 900
    short_timeout_tokens: Tuple[str, ...] = (
        "Events",
        "Data",
        "Public",
        "WebHooks",
    )
    memory_size_by_token: Mapping[str, int] = field(default_factory=dict)
    use_reserved_concurrency: bool = True

    def resolve_queue_name(self, branch: str) -> str:
        return self.queue_name_template.format(branch=branch.lower(), raw_branch=branch)

    def resolve_timeout(self, function_name: str) -> int:
        if any(token in function_name for token in self.short_timeout_tokens):
            return self.short_timeout_seconds
        return self.default_timeout_seconds

    def resolve_memory_size(self, function_name: str) -> Optional[int]:
        for token, memory_size in self.memory_size_by_token.items():
            if token in function_name:
                return memory_size
        return None


def _normalize_project_root(project_root: Union[str, Path]) -> Path:
    return Path(project_root).resolve()


def _format_build_datetime(timezone_name: str) -> str:
    now = datetime.datetime.now(datetime.timezone.utc)

    if ZoneInfo is not None:
        return now.astimezone(ZoneInfo(timezone_name)).strftime("%m/%d/%Y %I:%M%p")

    if pytz is not None:
        return now.astimezone(pytz.timezone(timezone_name)).strftime("%m/%d/%Y %I:%M%p")

    return now.strftime("%m/%d/%Y %I:%M%p")


def get_amplify_app_id_and_branch(project_root: Union[str, Path] = ".") -> Tuple[str, str]:
    root = _normalize_project_root(project_root)

    branch = os.environ.get("AWS_BRANCH")
    if branch:
        print(f"[INFO] Using AWS_BRANCH from env: {branch}")
    else:
        try:
            result = subprocess.run(
                ["amplify", "env", "list"],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=str(root),
            )
            lines = result.stdout.splitlines()
            current_line = next((line for line in lines if "*" in line), None)
            if not current_line:
                raise RuntimeError(
                    "Could not determine current Amplify environment from env list output."
                )

            clean_line = ANSI_ESCAPE_RE.sub("", current_line)
            match = re.search(r"\*\s*([a-zA-Z0-9._-]+)", clean_line)
            if not match:
                raise RuntimeError(f"Could not parse branch name from: {clean_line}")
            branch = match.group(1)
            print(f"[INFO] Current Amplify env/branch from CLI: {branch}")
        except Exception as exc:
            raise RuntimeError(f"Error getting Amplify env list: {exc}")

    app_id = os.environ.get("AWS_APP_ID")
    if app_id:
        print(f"[INFO] Using AWS_APP_ID from env: {app_id}")
    else:
        team_provider_path = root / "amplify" / "team-provider-info.json"
        try:
            with team_provider_path.open("r") as handle:
                team_info = json.load(handle)

            if branch not in team_info:
                raise RuntimeError(
                    f"Branch '{branch}' not found in team-provider-info.json"
                )

            app_id = team_info[branch]["awscloudformation"].get("AmplifyAppId")
            if not app_id:
                raise RuntimeError(
                    f"AmplifyAppId not found for branch '{branch}' in team-provider-info.json"
                )

            print(f"[INFO] Amplify App ID from file: {app_id}")
        except Exception as exc:
            raise RuntimeError(f"Error reading team-provider-info.json for App ID: {exc}")

    return app_id, branch


def initialize_build_environment(
    project_root: Union[str, Path] = ".",
    include_run_on_build_env: bool = False,
) -> Optional[Tuple[str, str]]:
    try:
        import env
    except ImportError:
        return None

    app_id, branch = get_amplify_app_id_and_branch(project_root)
    print(f"[INFO] Setting environment to: {branch}")
    env.set(branch)
    os.environ["AWS_BRANCH"] = branch
    os.environ["AWS_APP_ID"] = app_id
    if include_run_on_build_env:
        os.environ["RUN_ON_BUILD_ENV"] = branch
    return app_id, branch


def build_environment_variables(
    app: AmplifyProject,
    branch: str,
    queue_name: Optional[str],
    project_root: Union[str, Path] = ".",
    passthrough_env_keys: Sequence[str] = DEFAULT_ENV_PASSTHROUGH_KEYS,
    timezone_name: str = "US/Mountain",
) -> Dict[str, Any]:
    root = _normalize_project_root(project_root)
    env_vars = dict(app.get_merged_env_vars(branch))

    if queue_name:
        env_vars["SqsWorkQueue"] = queue_name

    for key in passthrough_env_keys:
        if key in os.environ:
            env_vars[key] = os.environ[key]

    build_datetime = _format_build_datetime(timezone_name)
    env_vars["BUILD_DATETIME"] = build_datetime
    env_vars["USER_BRANCH"] = branch
    env_vars["REACT_APP_USER_BRANCH"] = branch
    env_vars["USER_REGION"] = app.get_region()
    env_vars["LOGLEVEL"] = "WARNING" if branch == "production" else "INFO"

    amplify_meta_path = root / "amplify" / "backend" / "amplify-meta.json"
    if amplify_meta_path.exists():
        with amplify_meta_path.open("r") as handle:
            match = USER_POOL_ID_RE.search(handle.read())
            if match:
                env_vars["AWS_USER_POOL_ID"] = match.group(1)

    return env_vars


def retryable_call(
    fn,
    *args,
    max_attempts: int = 5,
    initial_delay: int = 2,
    **kwargs,
):
    delay = initial_delay
    for attempt in range(1, max_attempts + 1):
        try:
            return fn(*args, **kwargs)
        except botocore.exceptions.ClientError as exc:
            error = exc.response.get("Error", {})
            error_code = error.get("Code", "")
            message = error.get("Message", "")
            if (
                error_code in THROTTLE_ERROR_CODES
                or "rate exceeded" in message.lower()
            ):
                if attempt < max_attempts:
                    print(
                        f"Throttling detected. Retry {attempt}/{max_attempts} after {delay}s..."
                    )
                    time.sleep(delay)
                    delay *= 2
                    continue
                print("Exceeded max retries due to throttling.")
            raise


def resolve_latest_layer_arns(
    lambda_client,
    current_layers: Sequence[Mapping[str, Any]],
) -> Sequence[str]:
    updated_layer_arns = []

    for layer in current_layers or ():
        layer_arn = layer["Arn"]
        layer_name = layer_arn.split(":")[-2]
        current_version = layer_arn.split(":")[-1]

        latest_response = retryable_call(
            lambda_client.list_layer_versions,
            LayerName=layer_name,
            MaxItems=1,
        )

        if latest_response and latest_response.get("LayerVersions"):
            latest_version_info = latest_response["LayerVersions"][0]
            latest_version = latest_version_info["Version"]
            latest_arn = latest_version_info["LayerVersionArn"]
            updated_layer_arns.append(
                latest_arn if str(latest_version) != str(current_version) else layer_arn
            )
        else:
            updated_layer_arns.append(layer_arn)

    return updated_layer_arns


def _serialize_policy_document(policy_document: Any) -> str:
    if isinstance(policy_document, str):
        return policy_document
    return json.dumps(policy_document)


def ensure_lambda_policies_and_attach(
    app: AmplifyProject,
    function: Mapping[str, str],
    iam_client=None,
) -> None:
    if iam_client is None:
        iam_client = boto3.client("iam")

    account_id = app.get_account_id()
    lambda_layer_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Effect": "Allow",
                "Action": ["lambda:GetFunctionConfiguration"],
                "Resource": f"arn:aws:lambda:*:{account_id}:function:*",
            }
        ],
    }

    required_policies = [
        (
            "lambda-vpc-execution",
            f"arn:aws:iam::{account_id}:policy/lambda-vpc-execution",
            app.get_lambda_vpc_policy_template(),
        ),
        (
            "lambda-layer-access",
            f"arn:aws:iam::{account_id}:policy/lambda-layer-access",
            lambda_layer_policy,
        ),
        ("AmazonSQSFullAccess", "arn:aws:iam::aws:policy/AmazonSQSFullAccess", None),
    ]

    for policy_name, policy_arn, policy_doc in required_policies:
        if policy_doc is None:
            continue
        try:
            retryable_call(iam_client.get_policy, PolicyArn=policy_arn)
        except iam_client.exceptions.NoSuchEntityException:
            print(f"Creating policy {policy_name}")
            retryable_call(
                iam_client.create_policy,
                PolicyName=policy_name,
                PolicyDocument=_serialize_policy_document(policy_doc),
            )
            time.sleep(10)

    role_name = function["Role"].split("/")[-1]
    attached_policies = retryable_call(
        iam_client.list_attached_role_policies, RoleName=role_name
    )["AttachedPolicies"]

    for policy_name, policy_arn, _ in required_policies:
        if not any(policy["PolicyName"] == policy_name for policy in attached_policies):
            print(f"Attaching {policy_name} to {role_name}")
            retryable_call(
                iam_client.attach_role_policy,
                PolicyArn=policy_arn,
                RoleName=role_name,
            )
            if policy_name == "lambda-vpc-execution":
                time.sleep(10)


def ensure_cloudwatch_log_group(logs_client, log_group_name: str) -> None:
    try:
        logs_client.create_log_group(logGroupName=log_group_name)
    except logs_client.exceptions.ResourceAlreadyExistsException:
        return
    except botocore.exceptions.ClientError as exc:
        if exc.response["Error"].get("Code") != "ResourceAlreadyExistsException":
            raise


def _configure_lambda_logging(lambda_client, function_name: str) -> bool:
    logging_config = {
        "LogFormat": "JSON",
        "SystemLogLevel": "WARN",
        "ApplicationLogLevel": "INFO",
    }
    try:
        lambda_client.update_function_configuration(
            FunctionName=function_name, LoggingConfig=logging_config
        )
        return True
    except botocore.exceptions.ClientError as exc:
        code = exc.response.get("Error", {}).get("Code")
        if code == "ResourceConflictException":
            return False
        raise


def _function_name(function: Union[str, Mapping[str, str]]) -> str:
    if isinstance(function, str):
        return function
    return function["FunctionName"]


def set_cloudwatch_logging(
    app: AmplifyProject,
    function: Union[str, Mapping[str, str]],
    branch: str,
    lambda_client=None,
    logs_client=None,
) -> bool:
    if lambda_client is None:
        lambda_client = boto3.client("lambda")
    if logs_client is None:
        logs_client = boto3.client("logs")

    function_name = _function_name(function)
    log_group_name = f"/aws/lambda/{function_name}"
    account_id = app.get_account_id()
    region = app.get_region()

    try:
        lambda_client.add_permission(
            FunctionName="LambdaCloudWatchNotification",
            StatementId="InvokePermissionsForCWL",
            Action="lambda:invokeFunction",
            Principal="logs.amazonaws.com",
            SourceArn=f"arn:aws:logs:{region}:{account_id}:log-group:*",
            SourceAccount=account_id,
        )
    except lambda_client.exceptions.ResourceConflictException:
        pass

    ensure_cloudwatch_log_group(logs_client, log_group_name)

    args = {
        "logGroupName": log_group_name,
        "destinationArn": (
            f"arn:aws:lambda:{region}:{account_id}:function:LambdaCloudWatchNotification"
        ),
        "filterName": function_name,
        "filterPattern": "?error ?exception ?warning ?critical ?ERROR ?EXCEPTION ?WARN ?CRITICAL",
    }
    for _attempt in range(2):
        try:
            logs_client.put_subscription_filter(**args)
            logs_client.put_retention_policy(
                logGroupName=log_group_name,
                retentionInDays=(7 if branch == "production" else 1),
            )
            break
        except logs_client.exceptions.ResourceNotFoundException:
            ensure_cloudwatch_log_group(logs_client, log_group_name)
    else:
        raise RuntimeError(
            f"Unable to configure subscription filter for {log_group_name}; verify the log group exists and retry."
        )

    succeeded = _configure_lambda_logging(lambda_client, function_name)
    if succeeded:
        print(f"[INFO] Logging configuration applied for {function_name}")
    return succeeded


def run_backend_deployment(
    app_id: str,
    branch: str,
    config: BackendDeploymentConfig,
    project_root: Union[str, Path] = ".",
    app: Optional[AmplifyProject] = None,
    lambda_client=None,
    logs_client=None,
) -> None:
    if app is None:
        app = AmplifyProject(app_id)
    if lambda_client is None:
        lambda_client = boto3.client("lambda")
    if logs_client is None:
        logs_client = boto3.client("logs")

    queue_name = config.resolve_queue_name(branch)
    queue_handler = None
    queue_producers = []
    pending_logging = []

    env_vars = build_environment_variables(
        app,
        branch,
        queue_name,
        project_root=project_root,
    )
    subnet_ids = list(config.subnet_ids) if config.subnet_ids else None
    security_group_ids = (
        list(config.security_group_ids) if config.security_group_ids else None
    )

    for function in app.list_lambda_functions_filtered(branch):
        function_name = function["FunctionName"]
        if "QueueHandler" in function_name:
            queue_handler = function
        else:
            queue_producers.append(function)

        ensure_lambda_policies_and_attach(app, function)

        timeout_value = config.resolve_timeout(function_name)
        memory_value = config.resolve_memory_size(function_name)
        layers_value = None
        current_layers = function.get("Layers") or []
        if current_layers:
            try:
                layers_value = list(resolve_latest_layer_arns(lambda_client, current_layers))
            except Exception as exc:
                print(
                    f"[WARN] Unable to resolve latest layers for {function_name}: {exc}. "
                    "Keeping current layer attachments."
                )
        print(
            f"[INFO] Updating Lambda function {function_name} with timeout={timeout_value}"
            + (
                f" memory_size={memory_value}" if memory_value is not None else ""
            )
        )
        app.update_lambda_function(
            function_name=function_name,
            merge_env_vars=env_vars,
            timeout=timeout_value,
            memory_size=memory_value,
            subnet_ids=subnet_ids,
            security_group_ids=security_group_ids,
            layers=layers_value,
        )

        if not set_cloudwatch_logging(
            app,
            function_name,
            branch,
            lambda_client=lambda_client,
            logs_client=logs_client,
        ):
            pending_logging.append(function_name)

    if queue_handler:
        print(
            f"[INFO] Configuring SQS queue {queue_name} with handler {queue_handler['FunctionName']}"
        )
        app.setup_sqs_queue_and_permissions(
            branch=branch,
            queue_name=queue_name,
            queue_producers=queue_producers,
            queue_handler=queue_handler,
            use_reserved_concurrency=config.use_reserved_concurrency,
        )

    if pending_logging:
        retry_delay = 5
        max_rounds = 3
        for round_number in range(1, max_rounds + 1):
            print(
                f"[INFO] Retry round {round_number}: waiting {retry_delay}s before reprocessing {len(pending_logging)} function(s)."
            )
            time.sleep(retry_delay)
            next_round = []
            for function_name in pending_logging:
                failed = not set_cloudwatch_logging(
                    app,
                    function_name,
                    branch,
                    lambda_client=lambda_client,
                    logs_client=logs_client,
                )
                if failed:
                    next_round.append(function_name)
            pending_logging = next_round
            if not pending_logging:
                break

        if pending_logging:
            print(
                "[WARN] Logging configuration still could not be applied for: "
                + ", ".join(pending_logging)
                + "; please rerun build.py or update those functions manually."
            )


def update_lambda_layers_to_latest(
    app_id: str,
    branch: str,
    function_names: Optional[Sequence[str]] = None,
    app: Optional[AmplifyProject] = None,
    lambda_client=None,
) -> None:
    if app is None:
        app = AmplifyProject(app_id)
    if lambda_client is None:
        lambda_client = boto3.client("lambda")

    if function_names:
        if len(function_names) == 1:
            print(f"[INFO] Updating layers for specific function: {function_names[0]}")
    else:
        print("[INFO] No specific function provided, scanning all functions in the application...")
        functions = list(app.list_lambda_functions_filtered(branch))
        function_names = [function["FunctionName"] for function in functions]
        if not function_names:
            print("[INFO] No Lambda functions found in this application.")
            return
        print(
            f"[INFO] Found {len(function_names)} functions to process: {', '.join(function_names)}"
        )

    for function_name in function_names:
        print(f"\n[INFO] === Processing function: {function_name} ===")

        try:
            response = retryable_call(
                lambda_client.get_function_configuration,
                FunctionName=function_name,
            )

            if not response:
                print(f"[ERROR] Failed to get configuration for function {function_name}")
                continue

            current_layers = response.get("Layers", [])
            if not current_layers:
                print(f"[INFO] Function {function_name} has no layers attached.")
                continue

            print(
                f"[INFO] Found {len(current_layers)} layers attached to {function_name}"
            )
            updated_layer_arns = []

            for layer in current_layers:
                layer_arn = layer["Arn"]
                layer_name = layer_arn.split(":")[-2]
                current_version = layer_arn.split(":")[-1]
                print(
                    f"[INFO] Processing layer: {layer_name} (current version: {current_version})"
                )

            try:
                updated_layer_arns = list(
                    resolve_latest_layer_arns(lambda_client, current_layers)
                )
            except Exception as exc:
                print(f"[ERROR] Failed to resolve latest layers: {exc}")
                print("[INFO] Keeping current layer versions")
                updated_layer_arns = [layer["Arn"] for layer in current_layers]

            for original_arn, updated_arn in zip(
                [layer["Arn"] for layer in current_layers],
                updated_layer_arns,
            ):
                layer_name = original_arn.split(":")[-2]
                current_version = original_arn.split(":")[-1]
                latest_version = updated_arn.split(":")[-1]
                if updated_arn != original_arn:
                    print(
                        f"[INFO] Updating {layer_name}: v{current_version} -> v{latest_version}"
                    )
                else:
                    print(
                        f"[INFO] {layer_name} is already at latest version (v{latest_version})"
                    )

            current_layer_arns = [layer["Arn"] for layer in current_layers]
            if updated_layer_arns != current_layer_arns:
                print(
                    f"[INFO] Updating function {function_name} with new layer versions..."
                )
                retryable_call(
                    lambda_client.update_function_configuration,
                    FunctionName=function_name,
                    Layers=updated_layer_arns,
                )
                print(f"[SUCCESS] Successfully updated layers for {function_name}")
            else:
                print(
                    f"[INFO] All layers are already at their latest versions for {function_name}"
                )
        except lambda_client.exceptions.ResourceNotFoundException:
            print(f"[ERROR] Function {function_name} not found")
        except Exception as exc:
            print(f"[ERROR] Failed to update layers for {function_name}: {exc}")

    print(f"\n[INFO] === Completed processing {len(function_names)} function(s) ===")