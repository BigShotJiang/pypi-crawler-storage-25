"""
SQS Handler Module

This module provides a base class for handling AWS SQS events in Lambda functions.
It includes per-record transaction isolation, partial batch failure reporting
via ``batchItemFailures``, and error handling hooks.
"""

import json
from typing import Any, Dict, Optional

from velocity.aws.handlers import context as VelocityContext
from velocity.aws.handlers.base_handler import BaseHandler
from velocity.aws.handlers.context_factory import ContextFactory
from velocity.logging import configure_logging, get_logger


configure_logging()
logger = get_logger("velocity.aws.handlers.sqs")


class SqsHandler(BaseHandler):
    """
    Base class for handling SQS events in AWS Lambda functions.

    Each SQS record is processed in its own database transaction.  If a record
    fails, the transaction is rolled back and the record's ``messageId`` is
    included in the ``batchItemFailures`` response so that SQS retries only
    the failed records.  Successful records are deleted from the queue
    automatically.
    """

    def __init__(
        self,
        aws_event: Dict[str, Any],
        aws_context: Any,
        context_factory: Optional[ContextFactory] = None,
        context_class=VelocityContext.Context,
    ):
        super().__init__(
            aws_event,
            aws_context,
            context_factory=context_factory,
            context_class=context_class,
        )

    def serve(self, tx):
        """
        Process all SQS records, each in its own transaction.

        Returns a ``batchItemFailures`` response so that only failed records
        are retried by SQS.  When all records succeed the return value is
        ``None`` (no failures to report).
        """
        records = self.aws_event.get("Records", [])
        if not records:
            return None

        engine = tx.engine
        failures = []

        for record in records:
            message_id = record.get("messageId")
            try:
                with engine.transaction() as record_tx:
                    self._process_record(record_tx, record)
            except Exception as exc:
                self.on_record_error(record, exc)
                if message_id:
                    failures.append({"itemIdentifier": message_id})

        if failures:
            return {"batchItemFailures": failures}
        return None

    def _process_record(self, tx, record: Dict[str, Any]):
        """
        Process a single SQS record.
        """
        attrs = record.get("attributes", {})
        postdata = {}

        body = record.get("body")
        if body:
            try:
                postdata = json.loads(body)
            except json.JSONDecodeError as e:
                logger.warning("Failed to parse SQS message body as JSON: %s", e)
                postdata = {"raw_body": body}

        local_context = self.create_context(
            args=attrs,
            postdata=postdata,
            response=None,
            session=None,
        )
        if hasattr(local_context, "configure_perf"):
            local_context.configure_perf(postdata=postdata)

        action = postdata.get("action") if isinstance(postdata, dict) else None
        actions = self.get_actions_to_execute(action)

        try:
            self.execute_actions(tx, local_context, actions)
        except Exception as e:
            # Roll back failed DB state so handle_error/onError get a usable tx.
            try:
                tx.rollback()
            except Exception:
                pass
            self.handle_error(tx, local_context, e)

    def on_record_error(self, record, exception):
        """
        Called when a record fails and will be reported in
        ``batchItemFailures``.  Override in subclasses for custom behaviour
        (e.g. alerting, metrics).
        """
        message_id = record.get("messageId", "unknown")
        receive_count = record.get("attributes", {}).get(
            "ApproximateReceiveCount", "0"
        )
        logger.error(
            "SQS record %s failed (receive count: %s): %s",
            message_id,
            receive_count,
            exception,
        )

    @staticmethod
    def is_dlq_candidate(record, max_receives=5):
        """
        Return ``True`` if the record has been received *max_receives* or more
        times, indicating it is likely headed for the dead-letter queue.

        The actual DLQ routing is controlled by the SQS redrive policy;
        this helper is for logging and metrics.
        """
        receive_count = int(
            record.get("attributes", {}).get("ApproximateReceiveCount", "0")
        )
        return receive_count >= max_receives

    def OnActionDefault(self, tx, context):
        action = context.action() if hasattr(context, "action") else "unknown"
        warning_message = (
            f"[Warn] Action handler not found. Calling default action "
            f"`SqsHandler.OnActionDefault` with the following parameters:\n"
            f"  - action: {action}\n"
            f"  - attrs: {context.args()}\n"
            f"  - postdata: {context.postdata()}"
        )
        logger.warning(warning_message)
