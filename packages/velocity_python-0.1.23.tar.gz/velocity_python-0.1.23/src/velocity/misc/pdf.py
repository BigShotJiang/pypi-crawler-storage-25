"""
HTML-to-PDF generation using pdfkit + wkhtmltopdf.

The Python dependency surface is intentionally small: pdfkit wraps an external
``wkhtmltopdf`` binary. On Lambda, the binary is typically supplied by the
support layer at ``/opt/bin/wkhtmltopdf`` with companion shared libraries in
``/opt/lib``.

Usage::

    from velocity.misc.pdf import html_to_pdf

    pdf_bytes = html_to_pdf("<h1>Hello</h1><p>World</p>")

    pdf_bytes = html_to_pdf(
        html,
        page_size="Letter",
        orientation="landscape",
        margin="0.5in",
        footer_right="Page {page} of {pages}",
    )

    from velocity.misc.pdf import wrap_html, html_to_pdf

    html = wrap_html("My Report", "<p>Content here</p>")
    pdf_bytes = html_to_pdf(html)

Requires the ``pdf`` extra plus a runnable ``wkhtmltopdf`` binary::

    pip install velocity-python[pdf]
"""

from __future__ import annotations

import logging
import os
import shutil
from typing import Optional

logger = logging.getLogger("velocity.misc.pdf")

_pdfkit_import_error: Exception | None = None

try:
    import pdfkit
except ImportError as exc:
    _pdfkit_import_error = exc
    pdfkit = None  # type: ignore[assignment]


_DEFAULT_BODY_CSS = """\
body {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 11pt;
    line-height: 1.6;
    color: #222;
    margin: 0;
    padding: 24px;
}
h1 { font-size: 20px; margin-bottom: 16px; }
p  { margin: 0 0 12px; line-height: 1.6; }
ol, ul { padding-left: 24px; }
li { margin-bottom: 8px; }
"""


def _prepend_env_path(name: str, *paths: str) -> None:
    current = os.environ.get(name, "")
    existing = [path for path in current.split(":") if path]
    merged: list[str] = []

    for path in paths:
        if path and os.path.isdir(path) and path not in merged:
            merged.append(path)

    for path in existing:
        if path not in merged:
            merged.append(path)

    if merged:
        os.environ[name] = ":".join(merged)


def _configure_wkhtml_runtime() -> None:
    if "AWS_LAMBDA_FUNCTION_NAME" not in os.environ:
        return

    os.environ.setdefault("FONTCONFIG_PATH", "/opt/fonts")
    os.environ.setdefault("HOME", "/tmp")
    os.environ.setdefault("XDG_RUNTIME_DIR", "/tmp")
    os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
    _prepend_env_path("LD_LIBRARY_PATH", "/opt/lib")


def _find_wkhtmltopdf() -> str | None:
    configured = os.environ.get("WKHTMLTOPDF_PATH")
    candidates = [
        configured,
        shutil.which("wkhtmltopdf"),
        "/opt/bin/wkhtmltopdf",
        "/opt/wkhtmltopdf",
        "/opt/python/bin/wkhtmltopdf",
        "/var/task/bin/wkhtmltopdf",
    ]

    for candidate in candidates:
        if candidate and os.path.exists(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return None


def _normalize_footer_text(text: str) -> str:
    return text.replace("{page}", "[page]").replace("{pages}", "[topage]")


def _normalize_footer_font_size(value: str) -> str:
    normalized = str(value or "8").strip().lower()
    if normalized.endswith("pt"):
        normalized = normalized[:-2].strip()
    return normalized or "8"


def _require_pdf_backend() -> tuple[object, object]:
    if pdfkit is None:
        base_message = (
            "pdfkit is required for PDF generation. "
            "Install it with: pip install velocity-python[pdf] or pip install pdfkit"
        )
        if _pdfkit_import_error is not None:
            raise ImportError(
                f"{base_message} Root cause: {_pdfkit_import_error!r}"
            ) from _pdfkit_import_error
        raise ImportError(base_message)

    _configure_wkhtml_runtime()
    wkhtmltopdf_path = _find_wkhtmltopdf()
    if not wkhtmltopdf_path:
        raise ImportError(
            "wkhtmltopdf binary not available for PDF generation. "
            "Expected it in PATH, WKHTMLTOPDF_PATH, or the Lambda layer under /opt/bin."
        )

    return pdfkit, pdfkit.configuration(wkhtmltopdf=wkhtmltopdf_path)


def html_to_pdf(
    html: str,
    *,
    page_size: str = "Letter",
    orientation: str = "portrait",
    margin: Optional[str] = None,
    margin_top: Optional[str] = None,
    margin_right: Optional[str] = None,
    margin_bottom: Optional[str] = None,
    margin_left: Optional[str] = None,
    footer_right: Optional[str] = None,
    footer_center: Optional[str] = None,
    footer_font_size: str = "8pt",
) -> bytes:
    """Convert an HTML string to PDF bytes."""
    pdf_backend, configuration = _require_pdf_backend()

    options: dict[str, str] = {
        "encoding": "UTF-8",
        "page-size": page_size,
        "orientation": orientation.capitalize(),
        "enable-local-file-access": "",
        "quiet": "",
    }

    if margin:
        options["margin-top"] = margin
        options["margin-right"] = margin
        options["margin-bottom"] = margin
        options["margin-left"] = margin
    else:
        options["margin-top"] = margin_top or "0.5in"
        options["margin-right"] = margin_right or "0.5in"
        options["margin-bottom"] = margin_bottom or "0.75in"
        options["margin-left"] = margin_left or "0.5in"

    if footer_right:
        options["footer-right"] = _normalize_footer_text(footer_right)
    if footer_center:
        options["footer-center"] = _normalize_footer_text(footer_center)
    if footer_right or footer_center:
        options["footer-font-size"] = _normalize_footer_font_size(footer_font_size)

    try:
        return pdf_backend.from_string(
            html,
            False,
            configuration=configuration,
            options=options,
        )
    except Exception as exc:
        logger.exception("wkhtmltopdf PDF generation failed")
        raise RuntimeError(f"PDF generation failed: {exc}") from exc


def wrap_html(title: str, body: str, css: str = "") -> str:
    """Wrap a body fragment in a complete HTML document with default styles."""
    all_css = _DEFAULT_BODY_CSS + "\n" + css
    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset=\"utf-8\">
<title>{title}</title>
<style>
{all_css}
</style>
</head>
<body>
<h1>{title}</h1>
{body}
</body>
</html>"""