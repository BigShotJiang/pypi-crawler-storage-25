import os
from ..base.initializer import BaseInitializer
from velocity.db.core import engine


# Default TCP keepalive settings for PostgreSQL connections.
# These detect broken connections within ~90 seconds of inactivity,
# which is critical for Lambda containers that may sit idle between
# warm-start invocations.
_DEFAULT_KEEPALIVE = {
    "keepalives": 1,
    "keepalives_idle": 30,
    "keepalives_interval": 10,
    "keepalives_count": 3,
}


class PostgreSQLInitializer(BaseInitializer):
    """PostgreSQL database initializer."""

    @staticmethod
    def initialize(config=None, schema_locked=False, **kwargs):
        """
        Initialize PostgreSQL engine with psycopg driver.

        Args:
            config: Configuration dictionary
            schema_locked: Boolean to lock schema modifications
            **kwargs: Additional configuration parameters (also accepts
                      pool_min, pool_max, pool_enabled, pool_validate)

        Returns:
            Configured Engine instance
        """
        try:
            import psycopg
        except ImportError as e:
            raise ImportError(
                "PostgreSQL driver not available. Install with: pip install velocity-python[postgres]"
            ) from e

        from .sql import SQL

        # Base configuration from environment
        # psycopg v3 uses libpq param names; 'dbname' not 'database'.
        base_config = {
            "dbname": os.environ.get("DBDatabase"),
            "host": os.environ.get("DBHost"),
            "port": os.environ.get("DBPort"),
            "user": os.environ.get("DBUser"),
            "password": os.environ.get("DBPassword"),
        }

        # Remove None values
        base_config = {k: v for k, v in base_config.items() if v is not None}

        # Merge configurations
        final_config = PostgreSQLInitializer._merge_config(
            base_config, config, **kwargs
        )

        # Apply TCP keepalive defaults (user config takes precedence).
        for key, default_val in _DEFAULT_KEEPALIVE.items():
            final_config.setdefault(key, default_val)

        # SSL mode — default to "prefer" so connections upgrade when the
        # server supports TLS but don't fail when it doesn't.
        ssl_mode = os.environ.get("VELOCITY_SSL_MODE")
        if ssl_mode:
            final_config.setdefault("sslmode", ssl_mode)

        # Remap legacy 'database' key to 'dbname' for psycopg v3.
        # If user passed 'database', it overrides the env-derived 'dbname'.
        if "database" in final_config:
            final_config["dbname"] = final_config.pop("database")

        # Extract pool kwargs so they don't end up in the psycopg connect() dict.
        pool_kwargs = {}
        for pool_key in ("pool_min", "pool_max", "pool_enabled", "pool_validate"):
            if pool_key in final_config:
                pool_kwargs[pool_key] = final_config.pop(pool_key)

        # Validate required configuration
        required_keys = ["dbname", "host", "user", "password"]
        PostgreSQLInitializer._validate_required_config(final_config, required_keys)

        # Check for environment variable override for schema locking
        if os.environ.get("VELOCITY_SCHEMA_LOCKED", "").lower() in ("true", "1", "yes"):
            schema_locked = True

        return engine.Engine(
            psycopg, final_config, SQL,
            schema_locked=schema_locked,
            **pool_kwargs,
        )


# Maintain backward compatibility
def initialize(config=None, schema_locked=False, **kwargs):
    """Backward compatible initialization function - matches original behavior exactly."""
    try:
        import psycopg
    except ImportError as e:
        raise ImportError(
            "PostgreSQL driver not available. Install with: pip install velocity-python[postgres]"
        ) from e

    from .sql import SQL

    konfig = {
        "dbname": os.environ["DBDatabase"],
        "host": os.environ["DBHost"],
        "port": os.environ["DBPort"],
        "user": os.environ["DBUser"],
        "password": os.environ["DBPassword"],
    }
    konfig.update(config or {})
    konfig.update(kwargs)

    # Apply TCP keepalive defaults (user config takes precedence).
    for key, default_val in _DEFAULT_KEEPALIVE.items():
        konfig.setdefault(key, default_val)

    # SSL mode.
    ssl_mode = os.environ.get("VELOCITY_SSL_MODE")
    if ssl_mode:
        konfig.setdefault("sslmode", ssl_mode)

    # Remap legacy 'database' key to 'dbname' for psycopg v3.
    if "database" in konfig:
        konfig["dbname"] = konfig.pop("database")

    # Extract pool kwargs so they don't end up in the psycopg connect() call.
    pool_kwargs = {}
    for pool_key in ("pool_min", "pool_max", "pool_enabled", "pool_validate"):
        if pool_key in konfig:
            pool_kwargs[pool_key] = konfig.pop(pool_key)

    # Check for environment variable override for schema locking
    if os.environ.get("VELOCITY_SCHEMA_LOCKED", "").lower() in ("true", "1", "yes"):
        schema_locked = True

    return engine.Engine(
        psycopg, konfig, SQL,
        schema_locked=schema_locked,
        **pool_kwargs,
    )
