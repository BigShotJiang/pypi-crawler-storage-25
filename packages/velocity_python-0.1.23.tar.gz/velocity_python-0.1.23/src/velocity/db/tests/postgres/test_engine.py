import os
import datetime
import unittest
from velocity.db import exceptions
from velocity.db.core.engine import Engine
from velocity.db.core.transaction import Transaction
from .common import CommonPostgresTest, engine, test_db


@engine.transaction
class TestEngine(CommonPostgresTest):
    @classmethod
    def create_test_tables(cls, tx):
        """No special tables needed for engine tests."""
        pass

    def test_engine_init(self, tx):
        import psycopg
        from velocity.db.servers.postgres import SQL

        # Test the engine instance from common test
        assert engine.sql == SQL
        assert engine.driver == psycopg

    def test_engine_attributes(self, tx):
        import psycopg
        from velocity.db.servers.postgres import SQL

        # Test private attributes
        assert engine._Engine__sql == SQL
        assert engine._Engine__driver == psycopg

    def test_connect(self, tx):
        import psycopg

        assert engine.connect() != None
        conn = engine.connect()
        self.assertIsInstance(conn, psycopg.Connection)

    def test_other_stuff(self, tx):
        assert engine.version[:10] == "PostgreSQL"

        timestamp = engine.timestamp
        self.assertIsInstance(timestamp, datetime.datetime)
        assert engine.user == os.environ["DBUser"]
        assert test_db in engine.databases
        assert "public" in engine.schemas
        assert "information_schema" in engine.schemas
        assert "public" == engine.current_schema
        assert engine.current_database == test_db
        assert [] == engine.views
        assert [] == engine.tables

    def test_process_error(self, tx):
        exc = Exception("some driver error")
        with self.assertRaises(exceptions.DbException):
            engine.process_error(exc)

    def test_transaction_injection_1(self, tx):
        @engine.transaction
        def function():
            pass

        function()

        @engine.transaction
        def function(_tx):
            pass

        with self.assertRaises(NameError):
            function()

        @engine.transaction
        def function(tx):
            pass

        with self.assertRaises(TypeError):
            function(tx=3)
        with self.assertRaises(TypeError):
            function(tx=None)

    def test_transaction_injection_function(self, tx):
        with engine.transaction() as original:

            @engine.transaction
            def function(tx):
                assert tx != None
                assert tx != original
                self.assertIsInstance(tx, Transaction)

            function()

            @engine.transaction
            def function(tx):
                assert tx != None
                assert tx == original
                self.assertIsInstance(tx, Transaction)

            function(original)

            @engine.transaction
            def function(tx=None):
                assert tx != None
                assert tx != original
                self.assertIsInstance(tx, Transaction)

            function()

            @engine.transaction
            def function(tx=None):
                assert tx != None
                assert tx == original
                self.assertIsInstance(tx, Transaction)

            function(original)

            @engine.transaction
            def function(tx=None):
                assert tx != None
                assert tx == original
                self.assertIsInstance(tx, Transaction)

            function(tx=original)

            @engine.transaction
            def function(tx, a, b):
                assert tx != None
                assert tx != original
                self.assertIsInstance(tx, Transaction)

            function(1, 2)

            @engine.transaction
            def function(tx, a, b):
                assert tx != None
                assert tx == original
                self.assertIsInstance(tx, Transaction)

            function(original, 1, 2)

            @engine.transaction
            def function(tx, a, b):
                assert tx != None
                assert tx == original
                self.assertIsInstance(tx, Transaction)

            function(tx=original, a=1, b=2)

            @engine.transaction
            def function(tx, src, b):
                assert tx != None
                assert tx != src
                self.assertIsInstance(tx, Transaction)

            function(src=original, b=2)

            @engine.transaction
            def function(a, tx, b):
                assert tx != None
                assert tx != original
                self.assertIsInstance(tx, Transaction)

            function(1, 2)

            @engine.transaction
            def function(a, tx, b):
                assert tx != None
                assert tx == original
                self.assertIsInstance(tx, Transaction)

            function(1, original, 2)

    def test_transaction_injection_class(self, tx):
        test_class = self
        with engine.transaction() as original:

            @engine.transaction
            class TestClass:
                @engine.transaction
                def __init__(self, tx):
                    assert tx != None
                    assert tx != original
                    test_class.assertIsInstance(tx, Transaction)

                def first_method(self, tx):
                    assert tx != None
                    assert tx != original
                    test_class.assertIsInstance(tx, Transaction)

                def second_method(self, tx):
                    assert tx != None
                    assert tx == original
                    test_class.assertIsInstance(tx, Transaction)

            tc = TestClass()

            tc.first_method()
            tc.second_method(original)
            self.assertRaises(AssertionError, tc.second_method)


if __name__ == "__main__":
    unittest.main()
