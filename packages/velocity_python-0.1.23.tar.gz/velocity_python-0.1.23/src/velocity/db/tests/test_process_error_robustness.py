#!/usr/bin/env python3

"""
Test the robustness of the improved process_error method
"""

import sys
import unittest
from unittest.mock import Mock, patch
import logging

# Add the source directory to the path
sys.path.insert(0, "/home/ubuntu/tenspace/velocity-python/src")

from velocity.db.core.engine import Engine
from velocity.db import exceptions


class MockException(Exception):
    """Mock exception for testing"""

    def __init__(self, message, pgcode=None, pgerror=None):
        super().__init__(message)
        self.sqlstate = pgcode
        self.pgcode = pgcode
        self.pgerror = pgerror


class MockSQL:
    """Mock SQL class for testing"""

    server = "PostgreSQL"

    ApplicationErrorCodes = ["22P02", "42883", "42501", "42601", "25P01", "25P02", "42804"]
    DatabaseMissingErrorCodes = ["3D000"]
    TableMissingErrorCodes = ["42P01"]
    ColumnMissingErrorCodes = ["42703"]
    ForeignKeyMissingErrorCodes = ["42704"]
    ConnectionErrorCodes = [
        "08001",
        "08S01",
        "57P03",
        "08006",
        "53300",
        "08003",
        "08004",
        "08P01",
    ]
    DuplicateKeyErrorCodes = ["23505"]
    RetryTransactionCodes = ["40001", "40P01", "40002"]
    TruncationErrorCodes = ["22001"]
    LockTimeoutErrorCodes = ["55P03"]
    DatabaseObjectExistsErrorCodes = ["42710", "42P07", "42P04"]
    DataIntegrityErrorCodes = ["23503", "23502", "23514", "23P01", "22003"]

    @classmethod
    def get_error(cls, e):
        return getattr(e, "sqlstate", None), getattr(e, "pgerror", None) or str(e)

    @classmethod
    def classify_by_message(cls, msg):
        import re
        if not msg:
            return None
        m = msg.strip().lower()
        if re.search(r"key \(.*?\)=\(.*?\) already exists", m):
            return "DuplicateKey"
        if re.search(r"duplicate key value violates unique constraint", m):
            return "DuplicateKey"
        if re.search(r"database.*does not exist", m):
            return "DatabaseMissing"
        if "no such database" in m:
            return "DatabaseMissing"
        if "already exists" in m:
            return "ObjectExists"
        if cls.is_connection_error_message(msg):
            return "Connection"
        if "no such table:" in m:
            return "TableMissing"
        return None

    @classmethod
    def is_connection_error_message(cls, msg):
        if not msg:
            return False
        m = str(msg).strip().lower()
        needles = (
            "server closed the connection unexpectedly",
            "connection timed out",
        )
        return any(n in m for n in needles)

    @classmethod
    def enhance_message(cls, msg):
        if msg and "argument of where must be type boolean" in msg.lower():
            return "\n\n*** WHERE CLAUSE ERROR ***"
        return None


class TestProcessErrorRobustness(unittest.TestCase):

    def setUp(self):
        """Set up test fixtures"""
        self.engine = Engine(driver=Mock(), config={"test": "config"}, sql=MockSQL())

    # ── Error-code classification ────────────────────────────────────

    def test_error_code_classification(self):
        """Test that error codes are properly classified"""
        test_cases = [
            ("23505", exceptions.DbDuplicateKeyError, "unique violation"),
            ("40001", exceptions.DbRetryTransaction, "serialization failure"),
            ("40P01", exceptions.DbRetryTransaction, "deadlock detected"),
            ("42501", exceptions.DbApplicationError, "insufficient privilege"),
            ("42601", exceptions.DbApplicationError, "syntax error"),
            ("25P01", exceptions.DbApplicationError, "no active sql transaction"),
            ("3D000", exceptions.DbDatabaseMissingError, "invalid catalog name"),
            ("08003", exceptions.DbConnectionError, "connection does not exist"),
            ("23502", exceptions.DbDataIntegrityError, "not null violation"),
            ("42P01", exceptions.DbTableMissingError, "undefined table"),
            ("42703", exceptions.DbColumnMissingError, "undefined column"),
            ("55P03", exceptions.DbLockTimeoutError, "lock timeout"),
            ("42710", exceptions.DbObjectExistsError, "object exists"),
            ("22001", exceptions.DbTruncationError, "string truncation"),
            ("42704", exceptions.DbForeignKeyMissingError, "foreign key missing"),
        ]

        for pgcode, expected_exception, description in test_cases:
            with self.subTest(pgcode=pgcode, description=description):
                mock_exc = MockException(f"Test error: {description}", pgcode=pgcode)
                with self.assertRaises(expected_exception):
                    self.engine.process_error(mock_exc, "SELECT 1", {"param": "value"})

    # ── Message-based (regex) fallback ───────────────────────────────

    def test_message_fallback_classification(self):
        """Test classify_by_message fallback when error codes aren't available"""
        test_cases = [
            (
                "key (sys_id)=(123) already exists.",
                exceptions.DbDuplicateKeyError,
                "sys_id duplicate",
            ),
            (
                "duplicate key value violates unique constraint",
                exceptions.DbDuplicateKeyError,
                "unique constraint",
            ),
            (
                "database 'testdb' does not exist",
                exceptions.DbDatabaseMissingError,
                "database missing",
            ),
            (
                "no such database: mydb",
                exceptions.DbDatabaseMissingError,
                "database not found",
            ),
            (
                "table 'users' already exists",
                exceptions.DbObjectExistsError,
                "object exists",
            ),
            (
                "server closed the connection unexpectedly",
                exceptions.DbConnectionError,
                "connection closed",
            ),
            (
                "connection timed out",
                exceptions.DbConnectionError,
                "connection timeout",
            ),
            ("no such table: users", exceptions.DbTableMissingError, "table missing"),
        ]

        for message, expected_exception, description in test_cases:
            with self.subTest(message=message, description=description):
                # No pgcode → triggers classify_by_message fallback
                mock_exc = MockException(message)
                with self.assertRaises(expected_exception):
                    self.engine.process_error(mock_exc, "SELECT 1")

    # ── Re-raise of already-classified exceptions ────────────────────

    def test_already_custom_exception(self):
        """Test that DbException subclasses are re-raised as-is"""
        custom_exc = exceptions.DbConnectionError("Already a custom exception")
        with self.assertRaises(exceptions.DbConnectionError) as cm:
            self.engine.process_error(custom_exc)
        self.assertIs(cm.exception, custom_exc)

    # ── get_error failure ────────────────────────────────────────────

    def test_get_error_failure(self):
        """Test handling when get_error raises"""
        mock_exc = MockException("Test error")
        with patch.object(
            self.engine.sql, "get_error", side_effect=Exception("get_error failed")
        ):
            # Falls through to unclassified → DbException
            with self.assertRaises(exceptions.DbException):
                self.engine.process_error(mock_exc)

    # ── Unclassified errors → DbException ────────────────────────────

    def test_unknown_error_wraps_in_db_exception(self):
        """Unclassifiable errors are wrapped in DbException, not re-raised raw"""

        class UnknownException(Exception):
            pass

        mock_exc = UnknownException("Unknown error type")
        with self.assertRaises(exceptions.DbException) as cm:
            self.engine.process_error(mock_exc, "SELECT unknown")
        # Original chained via __cause__
        self.assertIs(cm.exception.__cause__, mock_exc)

    def test_unknown_error_logging(self):
        """Unclassified errors are logged with full context"""

        class UnknownException(Exception):
            pass

        mock_exc = UnknownException("Unknown error type")
        with patch("velocity.db.core.engine.logger") as mock_logger:
            with self.assertRaises(exceptions.DbException):
                self.engine.process_error(mock_exc, "SELECT unknown", {"param": "test"})

            mock_logger.error.assert_called_once()
            extra = mock_logger.error.call_args[1]["extra"]
            self.assertIn("available_error_codes", extra)
            self.assertEqual(extra["original_exception_type"], "UnknownException")

    # ── Exception chaining ───────────────────────────────────────────

    def test_exception_chaining(self):
        """Test that the original exception is chained via __cause__"""
        mock_exc = MockException("Original error", pgcode="23505")
        try:
            self.engine.process_error(mock_exc)
        except exceptions.DbDuplicateKeyError as e:
            self.assertIsInstance(e.__cause__, MockException)
            self.assertEqual(str(e.__cause__), "Original error")

    # ── Classified-error logging ─────────────────────────────────────

    def test_classified_error_logging(self):
        """Classified errors log a warning with context"""
        mock_exc = MockException("duplicate key", pgcode="23505", pgerror="duplicate key")

        with patch("velocity.db.core.engine.logger") as mock_logger:
            with self.assertRaises(exceptions.DbDuplicateKeyError):
                self.engine.process_error(mock_exc, "INSERT INTO t VALUES(1)", {"id": 1})

            mock_logger.warning.assert_called_once()
            call_args = mock_logger.warning.call_args
            msg = call_args[0][0]
            self.assertIn("code=%s", msg)

            extra = call_args[1]["extra"]
            self.assertEqual(extra["error_code"], "23505")
            self.assertEqual(extra["classified_as"], "DbDuplicateKeyError")
            self.assertEqual(extra["sql_stmt"], "INSERT INTO t VALUES(1)")

    # ── enhance_message hook ─────────────────────────────────────────

    def test_enhance_message_hook(self):
        """Dialect enhance_message text is appended to the error"""
        mock_exc = MockException(
            "argument of WHERE must be type boolean", pgcode="42804"
        )
        with self.assertRaises(exceptions.DbApplicationError) as cm:
            self.engine.process_error(mock_exc)
        self.assertIn("WHERE CLAUSE ERROR", str(cm.exception))

    # ── SQL context in enhanced message ──────────────────────────────

    def test_sql_included_in_enhanced_message(self):
        """SQL query is embedded in the raised exception message"""
        mock_exc = MockException("bad query", pgcode="42601")
        with self.assertRaises(exceptions.DbApplicationError) as cm:
            self.engine.process_error(mock_exc, "SELECT * FROM oops")
        self.assertIn("SELECT * FROM oops", str(cm.exception))

    # ── Credential masking ───────────────────────────────────────────

    def test_credentials_masked_in_message(self):
        """Sensitive info in driver error text is masked"""
        mock_exc = MockException("connection to host=db password=s3cret failed")
        with self.assertRaises(exceptions.DbException) as cm:
            self.engine.process_error(mock_exc)
        self.assertNotIn("s3cret", str(cm.exception))


def main():
    print("Testing robustness of improved process_error method...")
    logging.basicConfig(
        level=logging.DEBUG, format="%(levelname)s - %(name)s - %(message)s"
    )
    unittest.main(argv=[""], exit=False, verbosity=2)


if __name__ == "__main__":
    main()
