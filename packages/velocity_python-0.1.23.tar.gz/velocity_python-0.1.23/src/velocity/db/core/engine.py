import inspect
import os
import re
import time
import traceback
import threading
from contextlib import contextmanager
from functools import wraps
from velocity.db import exceptions
from velocity.db.core.transaction import Transaction
from velocity.db.utils import mask_config_for_display, mask_sensitive_in_string

import logging

logger = logging.getLogger("velocity.db.engine")
logger.setLevel(logging.INFO)  # Or DEBUG for more verbosity

# Map category keys (matching SQL dialect attribute name prefixes) to exception classes.
_CATEGORY_EXCEPTION_MAP = {
    "Application":       exceptions.DbApplicationError,
    "ColumnMissing":     exceptions.DbColumnMissingError,
    "TableMissing":      exceptions.DbTableMissingError,
    "DatabaseMissing":   exceptions.DbDatabaseMissingError,
    "ForeignKeyMissing": exceptions.DbForeignKeyMissingError,
    "Truncation":        exceptions.DbTruncationError,
    "DataIntegrity":     exceptions.DbDataIntegrityError,
    "Connection":        exceptions.DbConnectionError,
    "DuplicateKey":      exceptions.DbDuplicateKeyError,
    "ObjectExists":      exceptions.DbObjectExistsError,
    "LockTimeout":       exceptions.DbLockTimeoutError,
    "RetryTransaction":  exceptions.DbRetryTransaction,
}

# Attribute names on BaseSQLDialect, in the order they should be checked.
_CODE_LIST_ATTRS = [
    ("ApplicationErrorCodes",          "Application"),
    ("ColumnMissingErrorCodes",        "ColumnMissing"),
    ("TableMissingErrorCodes",         "TableMissing"),
    ("DatabaseMissingErrorCodes",      "DatabaseMissing"),
    ("ForeignKeyMissingErrorCodes",    "ForeignKeyMissing"),
    ("TruncationErrorCodes",           "Truncation"),
    ("DataIntegrityErrorCodes",        "DataIntegrity"),
    ("ConnectionErrorCodes",           "Connection"),
    ("DuplicateKeyErrorCodes",         "DuplicateKey"),
    ("DatabaseObjectExistsErrorCodes", "ObjectExists"),
    ("LockTimeoutErrorCodes",          "LockTimeout"),
    ("RetryTransactionCodes",          "RetryTransaction"),
]


def _build_error_code_map(sql_dialect) -> dict:
    """Build a {code: exception_class} dict from a dialect's code lists."""
    code_map: dict = {}
    for attr, category in _CODE_LIST_ATTRS:
        exc_cls = _CATEGORY_EXCEPTION_MAP[category]
        for code in getattr(sql_dialect, attr, ()):
            code_map.setdefault(code, exc_cls)   # first match wins
    return code_map

# Path of this file — used to filter stack frames.
_ENGINE_FILE = os.path.normpath(__file__)


class ConnectionPool:
    """
    A simple thread-safe connection pool for database connections.

    Manages a bounded set of reusable connections.  Connections are validated
    before being handed out (closed/stale ones are discarded).  When the pool
    is exhausted a new connection is created on-the-fly up to ``maxconn``;
    beyond that the caller blocks until one is returned.

    The pool is safe to share across Lambda warm-start invocations — stale
    connections left over from a previous invocation are detected and replaced
    transparently.
    """

    def __init__(self, connect_fn, minconn=1, maxconn=5, *, validate=True):
        """
        Args:
            connect_fn: Zero-argument callable that returns a new DB-API connection.
            minconn:    Minimum (and initial) number of connections to keep ready.
            maxconn:    Hard upper limit on concurrent connections.
            validate:   When True, run a lightweight check before handing out a
                        connection.  Disable when behind pgbouncer in transaction
                        mode to avoid an extra round-trip.
        """
        if maxconn < 1:
            raise ValueError("maxconn must be >= 1")
        if minconn < 0:
            minconn = 0
        if minconn > maxconn:
            minconn = maxconn

        self._connect_fn = connect_fn
        self._minconn = minconn
        self._maxconn = maxconn
        self._validate = validate

        self._lock = threading.Lock()
        self._available = threading.Semaphore(maxconn)
        self._pool: list = []
        self._total_created = 0
        self._closed = False

        # Pre-fill with minconn connections (best-effort).
        for _ in range(minconn):
            try:
                conn = self._connect_fn()
                self._pool.append(conn)
                self._total_created += 1
            except Exception:
                # If we can't pre-fill (e.g. DB unreachable at import-time),
                # connections will be created lazily on first getconn().
                break

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def getconn(self):
        """Borrow a connection from the pool (blocking if exhausted)."""
        if self._closed:
            raise exceptions.DbConnectionError("Connection pool is closed")

        t0 = time.perf_counter()
        self._available.acquire()  # blocks when maxconn reached

        with self._lock:
            # Try to reuse an idle connection.
            while self._pool:
                conn = self._pool.pop()
                if self._is_alive(conn):
                    elapsed_ms = (time.perf_counter() - t0) * 1000
                    logger.debug(
                        "Pool: reusing idle connection (pool_size=%d, wait=%.1f ms)",
                        len(self._pool), elapsed_ms,
                    )
                    return conn
                # Dead connection — close it silently and create a fresh one.
                logger.debug("Pool: discarding dead idle connection")
                self._safe_close(conn)
                self._total_created -= 1

            # No idle connection available — create a new one.
            try:
                conn = self._connect_fn()
                self._total_created += 1
                elapsed_ms = (time.perf_counter() - t0) * 1000
                logger.debug(
                    "Pool: created new connection (total=%d, wait=%.1f ms)",
                    self._total_created, elapsed_ms,
                )
                return conn
            except Exception:
                self._available.release()
                raise

    def putconn(self, conn, *, discard=False):
        """Return a connection to the pool (or discard it)."""
        if conn is None:
            self._available.release()
            return

        if discard or self._closed or not self._is_alive(conn):
            logger.debug("Pool: discarding connection (discard=%s, closed=%s)", discard, self._closed)
            self._safe_close(conn)
            with self._lock:
                self._total_created -= 1
            self._available.release()
            return

        with self._lock:
            self._pool.append(conn)
            logger.debug("Pool: returned connection (pool_size=%d)", len(self._pool))
        self._available.release()

    def closeall(self):
        """Close every connection and mark the pool as shut down."""
        self._closed = True
        with self._lock:
            while self._pool:
                self._safe_close(self._pool.pop())
            self._total_created = 0

    @property
    def size(self):
        """Number of idle connections currently in the pool."""
        with self._lock:
            return len(self._pool)

    @property
    def maxconn(self):
        return self._maxconn

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _is_alive(self, conn):
        """Return True if the connection looks usable."""
        if conn is None:
            return False
        try:
            # psycopg v3 returns bool; psycopg2 returned 0 for open.
            # Both are compatible with truthiness check.
            if getattr(conn, "closed", 0):
                return False
        except Exception:
            return False

        if not self._validate:
            return True

        # Lightweight validation — a fast server-side no-op.
        try:
            cur = conn.cursor()
            cur.execute("SELECT 1")
            cur.close()
            conn.commit()  # clear any transactional state
            return True
        except Exception:
            return False

    @staticmethod
    def _safe_close(conn):
        try:
            conn.close()
        except Exception:
            pass


class Engine:
    """
    Encapsulates driver config, connection logic, error handling, and transaction decoration.
    """

    MAX_RETRIES = 100

    def __init__(self, driver, config, sql, connect_timeout=None, schema_locked=False,
                 pool_min=None, pool_max=None, pool_enabled=None, pool_validate=True,
                 prepare_enabled=None):
        self.__config = config
        self.__sql = sql
        self.__driver = driver

        # Pre-build the error-code → exception-class lookup for O(1) classification.
        self.__error_code_map = _build_error_code_map(sql) if sql else {}

        if connect_timeout is None:
            connect_timeout = int(os.environ.get("VELOCITY_CONNECT_TIMEOUT", "5"))
        self.__connect_timeout = connect_timeout
        self.__schema_locked = schema_locked
        self.__schema_lock = threading.Lock()

        # R6 — Prepared statement support.
        # Disabled by default (safe for pgbouncer transaction-mode).
        # Set VELOCITY_PREPARE_ENABLED=true to opt in.
        if prepare_enabled is None:
            prepare_enabled = os.environ.get(
                "VELOCITY_PREPARE_ENABLED", "false"
            ).lower() in ("true", "1", "yes")
        self.__prepare_enabled = prepare_enabled

        # Connection pool configuration.
        # Env vars provide defaults; explicit constructor args override.
        if pool_enabled is None:
            pool_enabled = os.environ.get("VELOCITY_POOL_ENABLED", "true").lower() in ("true", "1", "yes")
        if pool_min is None:
            pool_min = int(os.environ.get("VELOCITY_POOL_MIN", "1"))
        if pool_max is None:
            pool_max = int(os.environ.get("VELOCITY_POOL_MAX", "5"))

        self.__pool_enabled = pool_enabled
        self.__pool: ConnectionPool | None = None

        if self.__pool_enabled:
            try:
                self.__pool = ConnectionPool(
                    connect_fn=self._raw_connect,
                    minconn=pool_min,
                    maxconn=pool_max,
                    validate=pool_validate,
                )
                logger.info("Connection pool created (min=%d, max=%d)", pool_min, pool_max)
            except Exception as exc:
                logger.warning("Failed to create connection pool, falling back to direct connections: %s", exc)
                self.__pool = None
                self.__pool_enabled = False

    def __str__(self):
        safe_config = mask_config_for_display(self.config)
        pool_info = ""
        if self.__pool:
            pool_info = f" pool(idle={self.__pool.size}, max={self.__pool.maxconn})"
        return f"[{self.sql.server}] engine({safe_config}){pool_info}"

    # ------------------------------------------------------------------
    # Connection management
    # ------------------------------------------------------------------

    @property
    def pool(self):
        """The connection pool, or None if pooling is disabled."""
        return self.__pool

    @property
    def pool_enabled(self):
        """Whether connection pooling is active."""
        return self.__pool_enabled and self.__pool is not None

    def get_pooled_connection(self):
        """Borrow a connection from the pool. Returns None if pooling is disabled."""
        if self.__pool:
            return self.__pool.getconn()
        return None

    def return_pooled_connection(self, conn, *, discard=False):
        """Return a connection to the pool. No-op if pooling is disabled."""
        if self.__pool and conn is not None:
            self.__pool.putconn(conn, discard=discard)
            return True
        return False

    def close_pool(self):
        """Shut down the connection pool, closing all idle connections."""
        if self.__pool:
            self.__pool.closeall()
            self.__pool = None
            self.__pool_enabled = False

    def connect(self):
        """
        Connects to the database and returns the connection object.
        If pooling is enabled, borrows from the pool.
        If the database is missing, tries to create it, then reconnect.
        """
        t0 = time.perf_counter()
        if self.__pool:
            try:
                conn = self.__pool.getconn()
                elapsed_ms = (time.perf_counter() - t0) * 1000
                logger.debug("Engine.connect: obtained pooled connection (%.1f ms)", elapsed_ms)
                return conn
            except exceptions.DbDatabaseMissingError:
                self.create_database()
                return self.__pool.getconn()
            except Exception:
                # Pool may have failed to connect — fall through to direct.
                pass

        try:
            conn = self._raw_connect()
            elapsed_ms = (time.perf_counter() - t0) * 1000
            logger.debug("Engine.connect: created direct connection (%.1f ms)", elapsed_ms)
        except exceptions.DbDatabaseMissingError:
            self.create_database()
            conn = self._raw_connect()
        if self.sql.server == "SQLite3":
            conn.isolation_level = None
        return conn

    def _raw_connect(self):
        """
        Create a new connection directly (bypassing pool).
        Used by the pool's connect_fn and as fallback.
        """
        conn = self.__connect()
        if self.sql.server == "SQLite3":
            conn.isolation_level = None
        return conn

    def __connect(self):
        """
        Internal connection logic, raising suitable exceptions on error.
        Enforces a connect timeout and handles different config types.
        """
        server = self.sql.server.lower()
        timeout_key = "timeout" if "sqlite" in server else "connect_timeout"
        timeout_val = self.__connect_timeout

        try:
            if isinstance(self.config, dict):
                config = self.config.copy()
                if timeout_key not in config:
                    config[timeout_key] = timeout_val
                return self.driver.connect(**config)

            elif isinstance(self.config, str):
                conn_str = self.config
                if timeout_key not in conn_str:
                    conn_str += f" {timeout_key}={timeout_val}"
                return self.driver.connect(conn_str)

            elif isinstance(self.config, (tuple, list)):
                config_args = list(self.config)
                if config_args and isinstance(config_args[-1], dict):
                    if timeout_key not in config_args[-1]:
                        config_args[-1][timeout_key] = timeout_val
                else:
                    config_args.append({timeout_key: timeout_val})
                return self.driver.connect(*config_args)

            else:
                raise TypeError(
                    f"Unhandled configuration parameter type: {type(self.config)}"
                )

        except Exception as e:
            raise self.process_error(e)

    def transaction(self, func_or_cls=None):
        """
        Decorator that provides a Transaction. If `tx` is passed in, uses it; otherwise, creates a new one.
        May also be used to decorate a class, in which case all methods are wrapped in a transaction if they accept `tx`.
        With no arguments, returns a new Transaction directly.
        """
        # print("Transaction", func_or_cls.__name__, type(func_or_cls))

        if func_or_cls is None:
            return Transaction(self)

        if isinstance(func_or_cls, classmethod):
            return classmethod(self.transaction(func_or_cls.__func__))

        if inspect.isfunction(func_or_cls) or inspect.ismethod(func_or_cls):
            names = list(inspect.signature(func_or_cls).parameters.keys())
            # print(func_or_cls.__name__, names)
            if "_tx" in names:
                raise NameError(
                    f"In function {func_or_cls.__name__}, '_tx' is not allowed as a parameter."
                )

            @wraps(func_or_cls)
            def new_function(*args, **kwds):
                tx = None
                names = list(inspect.signature(func_or_cls).parameters.keys())

                # print("inside", func_or_cls.__name__)
                # print(names)
                # print(args, kwds)

                if "tx" not in names:
                    # The function doesn't even declare a `tx` parameter, so run normally.
                    return func_or_cls(*args, **kwds)

                if "tx" in kwds:
                    if isinstance(kwds["tx"], Transaction):
                        tx = kwds["tx"]
                    else:
                        raise TypeError(
                            f"In function {func_or_cls.__name__}, keyword argument `tx` must be a Transaction object."
                        )
                else:
                    # Might be in positional args
                    pos = names.index("tx")
                    if len(args) > pos:
                        if isinstance(args[pos], Transaction):
                            tx = args[pos]

                if tx:
                    return self.exec_function(func_or_cls, tx, *args, **kwds)

                with Transaction(self) as local_tx:
                    pos = names.index("tx")
                    new_args = args[:pos] + (local_tx,) + args[pos:]
                    return self.exec_function(func_or_cls, local_tx, *new_args, **kwds)

            return new_function

        if inspect.isclass(func_or_cls):

            NewCls = type(func_or_cls.__name__, (func_or_cls,), {})

            for attr_name in dir(func_or_cls):
                # Optionally skip special methods
                if attr_name.startswith("__") and attr_name.endswith("__"):
                    continue

                attr = getattr(func_or_cls, attr_name)

                if callable(attr):
                    setattr(NewCls, attr_name, self.transaction(attr))

            return NewCls

        return Transaction(self)

    def exec_function(self, function, _tx, *args, **kwds):
        """
        Executes the given function inside the transaction `_tx`.
        Retries if it raises DbRetryTransaction or DbLockTimeoutError, up to MAX_RETRIES times.
        """
        depth = getattr(_tx, "_exec_function_depth", 0)
        setattr(_tx, "_exec_function_depth", depth + 1)

        try:
            if depth > 0:
                # Not top-level. Just call the function.
                return function(*args, **kwds)
            else:
                retry_count = 0
                lock_timeout_count = 0
                connection_retry_count = 0
                while True:
                    try:
                        return function(*args, **kwds)
                    except exceptions.DbRetryTransaction:
                        retry_count += 1
                        if retry_count > self.MAX_RETRIES:
                            raise
                        # Back off a bit to reduce contention on hot DDL.
                        time.sleep(min(2.0, 0.05 * (2**min(retry_count, 6))))
                        _tx.rollback()
                    except exceptions.DbLockTimeoutError:
                        lock_timeout_count += 1
                        if lock_timeout_count > self.MAX_RETRIES:
                            raise
                        time.sleep(min(2.0, 0.05 * (2**min(lock_timeout_count, 6))))
                        _tx.rollback()
                        continue
                    except exceptions.DbConnectionError as e:
                        # Transient disconnects can happen during maintenance / restarts.
                        # Retrying the entire top-level function is the safest option.
                        msg = str(e).strip().lower()
                        if not getattr(
                            self.sql, "is_transient_connection_error_message", lambda _m: False
                        )(msg):
                            raise

                        connection_retry_count += 1
                        if connection_retry_count > 6:
                            raise

                        logger.warning(
                            "Transient connection error (retry %d/6): %s",
                            connection_retry_count, e,
                        )

                        # Force a reconnect on the next attempt.
                        try:
                            _tx.close()
                        except Exception:
                            # If close() fails, discard the connection from the pool
                            # to avoid leaking a pool slot.
                            if _tx.connection is not None:
                                self.return_pooled_connection(_tx.connection, discard=True)
                            _tx.connection = None

                        time.sleep(min(2.0, 0.1 * (2**min(connection_retry_count, 5))))
                        continue
                    except Exception:
                        raise
        finally:
            setattr(_tx, "_exec_function_depth", depth)
            # or if depth was 0, you might delete the attribute:
            # if depth == 0:
            #     delattr(_tx, "_exec_function_depth")

    def perf_log(self, func):
        """
        Decorator that logs wall time, query count, and total query time
        for a ``@engine.transaction``-wrapped function.

        Usage::

            @engine.perf_log
            @engine.transaction
            def some_work(tx):
                ...

        The ``tx`` parameter **must** be a keyword argument or the first
        positional ``Transaction`` so we can read its counters.
        """

        @wraps(func)
        def wrapper(*args, **kwds):
            t0 = time.perf_counter()
            result = func(*args, **kwds)
            wall_ms = (time.perf_counter() - t0) * 1000

            # Find the Transaction among the arguments.
            tx = kwds.get("tx")
            if tx is None:
                for a in args:
                    if isinstance(a, Transaction):
                        tx = a
                        break

            qcount = getattr(tx, "_query_count", 0) if tx else 0
            qtime = getattr(tx, "_query_time_ms", 0.0) if tx else 0.0

            logger.info(
                "perf_log %s: wall=%.1f ms, queries=%d, query_time=%.1f ms",
                getattr(func, "__qualname__", func.__name__),
                wall_ms, qcount, qtime,
                extra={
                    "wall_ms": round(wall_ms, 1),
                    "query_count": qcount,
                    "query_time_ms": round(qtime, 1),
                },
            )
            return result

        return wrapper

    @property
    def driver(self):
        return self.__driver

    @property
    def config(self):
        return self.__config

    @property
    def sql(self):
        return self.__sql

    @property
    def prepare_enabled(self):
        """Whether psycopg v3 server-side prepared statements are active."""
        return self.__prepare_enabled

    @property
    def schema_locked(self):
        """Returns True if schema modifications are locked."""
        with self.__schema_lock:
            return self.__schema_locked

    def lock_schema(self):
        """Lock schema to prevent automatic modifications."""
        with self.__schema_lock:
            self.__schema_locked = True

    def unlock_schema(self):
        """Unlock schema to allow automatic modifications."""
        with self.__schema_lock:
            self.__schema_locked = False

    @contextmanager
    def unlocked_schema(self):
        """Temporarily unlock schema for automatic creation."""
        with self.__schema_lock:
            original_state = self.__schema_locked
            self.__schema_locked = False
        try:
            yield self
        finally:
            with self.__schema_lock:
                self.__schema_locked = original_state

    def async_transaction(self):
        """Return an :class:`AsyncTransaction` for use with ``async with``.

        Usage::

            async with engine.async_transaction() as tx:
                result = await tx.table("orders").select(where={"status": "active"})
                rows = await result.all()

        The returned object must be used as an async context manager.
        """
        from velocity.db.core.async_support import AsyncTransaction
        return AsyncTransaction(self)

    @property
    def version(self):
        """
        Returns the DB server version.
        """
        with Transaction(self) as tx:
            sql, vals = self.sql.version()
            return tx.execute(sql, vals).scalar()

    @property
    def timestamp(self):
        """
        Returns the current timestamp from the DB server.
        """
        with Transaction(self) as tx:
            sql, vals = self.sql.timestamp()
            return tx.execute(sql, vals).scalar()

    @property
    def user(self):
        """
        Returns the current user as known by the DB server.
        """
        with Transaction(self) as tx:
            sql, vals = self.sql.user()
            return tx.execute(sql, vals).scalar()

    @property
    def databases(self):
        """
        Returns a list of available databases.
        """
        with Transaction(self) as tx:
            sql, vals = self.sql.databases()
            result = tx.execute(sql, vals)
            return [x[0] for x in result.as_tuple()]

    @property
    def current_database(self):
        """
        Returns the name of the current database.
        """
        with Transaction(self) as tx:
            sql, vals = self.sql.current_database()
            return tx.execute(sql, vals).scalar()

    def create_database(self, name=None):
        """
        Creates a database if it doesn't exist, or does nothing if it does.
        """
        old = None
        if name is None:
            # Support both psycopg v3 ('dbname') and legacy ('database') key.
            old = self.config.get("dbname") or self.config.get("database")
            db_key = "dbname" if "dbname" in self.config else "database"
            self.set_config({db_key: "postgres"})
            name = old
        with Transaction(self) as tx:
            sql, vals = self.sql.create_database(name)
            tx.execute(sql, vals, single=True)
        if old:
            db_key = "dbname" if "dbname" in self.config else "database"
            self.set_config({db_key: old})
        return self

    def switch_to_database(self, database):
        """
        Switch the config to use a different database name, closing any existing connection.
        """
        conf = self.config
        if "database" in conf:
            conf["database"] = database
        if "dbname" in conf:
            conf["dbname"] = database
        return self

    def set_config(self, config):
        """
        Updates the internal config dictionary.
        """
        self.config.update(config)

    @property
    def schemas(self):
        """
        Returns a list of schemas in the current database.
        """
        with Transaction(self) as tx:
            sql, vals = self.sql.schemas()
            result = tx.execute(sql, vals)
            return [x[0] for x in result.as_tuple()]

    @property
    def current_schema(self):
        """
        Returns the current schema in use.
        """
        with Transaction(self) as tx:
            sql, vals = self.sql.current_schema()
            return tx.execute(sql, vals).scalar()

    @property
    def tables(self):
        """
        Returns a list of 'schema.table' for all tables in the current DB.
        """
        with Transaction(self) as tx:
            sql, vals = self.sql.tables()
            result = tx.execute(sql, vals)
            return [f"{x[0]}.{x[1]}" for x in result.as_tuple()]

    @property
    def views(self):
        """
        Returns a list of 'schema.view' for all views in the current DB.
        """
        with Transaction(self) as tx:
            sql, vals = self.sql.views()
            result = tx.execute(sql, vals)
            return [f"{x[0]}.{x[1]}" for x in result.as_tuple()]

    def process_error(self, exception, sql=None, parameters=None):
        """
        Central method to parse driver exceptions and re-raise them as our custom exceptions.
        """
        # If it's already a velocity exception, just re-raise it.
        if isinstance(exception, exceptions.DbException):
            raise exception

        # Extract error code & message from the driver exception.
        try:
            error_code, error_message = self.sql.get_error(exception)
        except Exception:
            error_code, error_message = None, str(exception)

        msg = str(exception)

        # ── Build enhanced message ───────────────────────────────────
        enhanced_message = msg

        # Dialect-specific developer guidance (e.g. WHERE-clause hints).
        try:
            hint = self.sql.enhance_message(msg)
        except (AttributeError, TypeError):
            hint = None
        if isinstance(hint, str):
            enhanced_message += hint

        if sql:
            enhanced_message += (
                f"\n\nSQL Query:\n{self._format_sql_with_params(sql, parameters)}"
            )

        # Append a few relevant call-stack frames for context.
        relevant_frames = [
            frame for frame in traceback.format_stack()
            if _ENGINE_FILE not in frame
        ][-3:]
        if relevant_frames:
            enhanced_message += "\n\nCall Context:\n" + "".join(relevant_frames)

        # Mask credentials that may have leaked into driver error text.
        enhanced_message = mask_sensitive_in_string(enhanced_message)

        # ── Classify by error code (O(1) dict lookup) ────────────────
        code_map = getattr(self, '_Engine__error_code_map', None) or {}
        exc_cls = code_map.get(error_code) if error_code else None

        # ── Classify by message text (dialect-specific fallback) ─────
        if exc_cls is None:
            try:
                category = self.sql.classify_by_message(msg)
            except (AttributeError, TypeError):
                category = None
            if isinstance(category, str):
                exc_cls = _CATEGORY_EXCEPTION_MAP.get(category)

        # ── Raise the classified exception ───────────────────────────
        if exc_cls is not None:
            logger.warning(
                "DB error classified: code=%s message=%s type=%s → %s",
                error_code, error_message,
                type(exception).__name__, exc_cls.__name__,
                extra={
                    "error_code": error_code,
                    "error_msg": error_message,
                    "classified_as": exc_cls.__name__,
                    "sql_stmt": sql,
                    "sql_params": parameters,
                },
            )
            raise exc_cls(enhanced_message) from exception

        # ── Unclassified — log and wrap in DbException ───────────────
        logger.error(
            "Unhandled/Unknown Error in engine.process_error",
            exc_info=True,
            extra={
                "error_code": error_code,
                "error_msg": error_message,
                "original_exception_type": type(exception).__name__,
                "available_error_codes": list(code_map.keys()),
                "sql_stmt": sql,
                "sql_params": parameters,
            },
        )
        raise exceptions.DbException(enhanced_message) from exception

    def _format_sql_with_params(self, sql, parameters):
        """
        Format SQL query with parameters merged for easy copy-paste debugging.
        """
        if not sql:
            return "No SQL provided"

        if not parameters:
            return sql

        try:
            # Handle different parameter formats
            if isinstance(parameters, (list, tuple)):
                # Convert parameters to strings and handle None values
                formatted_params = []
                for param in parameters:
                    if param is None:
                        formatted_params.append("NULL")
                    elif isinstance(param, str):
                        # Escape single quotes and wrap in quotes
                        escaped = param.replace("'", "''")
                        formatted_params.append(f"'{escaped}'")
                    elif isinstance(param, bool):
                        formatted_params.append("TRUE" if param else "FALSE")
                    else:
                        formatted_params.append(str(param))

                # Replace %s placeholders with actual values
                formatted_sql = sql
                for param in formatted_params:
                    formatted_sql = formatted_sql.replace("%s", param, 1)

                return formatted_sql

            elif isinstance(parameters, dict):
                # Handle named parameters
                formatted_sql = sql
                for key, value in parameters.items():
                    if value is None:
                        replacement = "NULL"
                    elif isinstance(value, str):
                        escaped = value.replace("'", "''")
                        replacement = f"'{escaped}'"
                    elif isinstance(value, bool):
                        replacement = "TRUE" if value else "FALSE"
                    else:
                        replacement = str(value)

                    # Replace %(key)s or :key patterns
                    formatted_sql = formatted_sql.replace(f"%({key})s", replacement)
                    formatted_sql = formatted_sql.replace(f":{key}", replacement)

                return formatted_sql
            else:
                return f"{sql}\n-- Parameters: {parameters}"

        except Exception as e:
            # If formatting fails, return original SQL with parameters shown separately
            return (
                f"{sql}\n-- Parameters (formatting failed): {parameters}\n-- Error: {e}"
            )
