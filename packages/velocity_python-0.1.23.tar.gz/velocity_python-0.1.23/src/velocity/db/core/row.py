import pprint
import time as _time
from collections.abc import MutableMapping
from velocity.db.exceptions import DbColumnMissingError


# Attributes that live on the Row instance itself and must never be
# intercepted by __getattr__ / __setattr__.
_INTERNAL_ATTRS = frozenset({
    "table", "pk", "_cache", "_column_set", "_batching", "_pending",
    "_cache_ttl", "_cache_time", "_no_cache", "_dirty_tracking", "_dirty",
})


class Row(MutableMapping):
    """
    Represents a single row in a given table, identified by a primary key.

    Acts as a ``MutableMapping`` so that standard dict idioms work:
    ``dict(row)``, ``{**row}``, ``for k in row:``, ``json.dumps(row)``.

    Data is fetched from the database **once** on first access and cached
    locally.  Call ``row.refresh()`` to re-fetch.  Writes are still
    write-through (immediate UPDATE) and also update the local cache.
    """

    def __init__(self, table, key, lock=None, cache_ttl=None, no_cache=False, dirty_tracking=False):
        if isinstance(table, str):
            raise Exception("Table parameter must be a `table` instance.")
        object.__setattr__(self, "table", table)

        if isinstance(key, (dict, Row)):
            pk = {}
            try:
                for k in self.key_cols:
                    pk[k] = key[k]
            except KeyError:
                pk = dict(key) if isinstance(key, Row) else key
        else:
            pk = {self.key_cols[0]: key}

        object.__setattr__(self, "pk", pk)
        object.__setattr__(self, "_cache", None)
        object.__setattr__(self, "_column_set", None)
        object.__setattr__(self, "_batching", False)
        object.__setattr__(self, "_pending", {})
        object.__setattr__(self, "_cache_ttl", cache_ttl)
        object.__setattr__(self, "_cache_time", None)
        object.__setattr__(self, "_no_cache", no_cache)
        object.__setattr__(self, "_dirty_tracking", dirty_tracking)
        object.__setattr__(self, "_dirty", {})
        if lock:
            self.lock()

    @classmethod
    def _from_data(cls, table, data):
        """Create a Row with its cache pre-populated from *data*.

        This avoids the lazy SELECT that normally fires on first attribute
        access, eliminating the N+1 problem when you already have the full
        row dict (e.g. from a bulk ``SELECT``).

        Args:
            table: The :class:`Table` instance this row belongs to.
            data:  A ``dict`` of ``{column_name: value}`` for the row.
                   Must include the primary-key column(s).

        Returns:
            A fully-initialised :class:`Row` whose local cache is *data*.
        """
        row = cls.__new__(cls)
        pk = {k: data[k] for k in ("sys_id",) if k in data}
        object.__setattr__(row, "table", table)
        object.__setattr__(row, "pk", pk)
        object.__setattr__(row, "_cache", dict(data))
        object.__setattr__(row, "_column_set", None)
        object.__setattr__(row, "_batching", False)
        object.__setattr__(row, "_pending", {})
        object.__setattr__(row, "_cache_ttl", None)
        object.__setattr__(row, "_cache_time", _time.monotonic())
        object.__setattr__(row, "_no_cache", False)
        object.__setattr__(row, "_dirty_tracking", False)
        object.__setattr__(row, "_dirty", {})
        return row

    # ------------------------------------------------------------------
    # Cache management
    # ------------------------------------------------------------------

    def _ensure_cache(self):
        """Populate the local cache from the database if not yet loaded or expired."""
        if self._no_cache:
            # Always fetch fresh — never store in cache
            data = self.table.select(where=self.pk).as_dict().one()
            return data or {}
        if self._cache is not None and self._cache_ttl is not None:
            elapsed = _time.monotonic() - (self._cache_time or 0)
            if elapsed > self._cache_ttl:
                object.__setattr__(self, "_cache", None)
                object.__setattr__(self, "_column_set", None)
        if self._cache is None:
            data = self.table.select(where=self.pk).as_dict().one()
            object.__setattr__(self, "_cache", data or {})
            object.__setattr__(self, "_cache_time", _time.monotonic())
        return self._cache

    def _column_names_lower(self):
        """Return a frozenset of lowered column names (cached)."""
        if self._column_set is None:
            cols = frozenset(k.lower() for k in self._ensure_cache())
            object.__setattr__(self, "_column_set", cols)
        return self._column_set

    def refresh(self):
        """Re-fetch the row data from the database, clearing the local cache."""
        object.__setattr__(self, "_cache", None)
        object.__setattr__(self, "_column_set", None)
        self._ensure_cache()
        return self

    def invalidate(self):
        """Clear the local cache so the next access re-fetches from the database."""
        object.__setattr__(self, "_cache", None)
        object.__setattr__(self, "_column_set", None)
        return self

    # ------------------------------------------------------------------
    # MutableMapping protocol
    # ------------------------------------------------------------------

    def __getitem__(self, key):
        if key in self.pk:
            return self.pk[key]
        cache = self._ensure_cache()
        if key in cache:
            return cache[key]
        # Fall back to a direct DB fetch for columns not in the initial SELECT
        return self.table.get_value(key, self.pk)

    def __setitem__(self, key, val):
        if key in self.pk:
            raise Exception("Cannot update a primary key.")
        if self._batching:
            self._pending[key] = val
            # Update local cache optimistically so reads see the pending value
            if self._cache is not None:
                self._cache[key] = val
                object.__setattr__(self, "_column_set", None)
            return
        if self._dirty_tracking:
            self._dirty[key] = val
            # Update local cache optimistically so reads see the dirty value
            if self._cache is not None:
                self._cache[key] = val
                object.__setattr__(self, "_column_set", None)
            return
        self.table.update_or_insert({key: val}, pk=self.pk)
        # Invalidate cache so trigger-computed columns are re-fetched
        object.__setattr__(self, "_cache", None)
        object.__setattr__(self, "_column_set", None)

    def __delitem__(self, key):
        if key in self.pk:
            raise Exception("Cannot delete a primary key.")
        if key not in self:
            return
        self[key] = None

    def __iter__(self):
        return iter(self._ensure_cache())

    def __len__(self):
        return len(self._ensure_cache())

    def __contains__(self, key):
        return key.lower() in self._column_names_lower()

    # ------------------------------------------------------------------
    # Attribute-style access  (row.name instead of row['name'])
    # ------------------------------------------------------------------

    def __getattr__(self, key):
        if key.startswith("_") or key in _INTERNAL_ATTRS:
            raise AttributeError(key)
        try:
            return self[key]
        except (KeyError, DbColumnMissingError):
            raise AttributeError(
                f"'{type(self).__name__}' object has no attribute '{key}'"
            )

    def __setattr__(self, key, val):
        if key in _INTERNAL_ATTRS or key.startswith("_"):
            object.__setattr__(self, key, val)
        else:
            self[key] = val

    # ------------------------------------------------------------------
    # Equality and hashing — based on (table name, pk)
    # ------------------------------------------------------------------

    def __eq__(self, other):
        if isinstance(other, Row):
            return self.table.name == other.table.name and self.pk == other.pk
        if isinstance(other, dict):
            return self.to_dict() == other
        return NotImplemented

    def __hash__(self):
        return hash((self.table.name, tuple(sorted(self.pk.items()))))

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    # ------------------------------------------------------------------
    # Representations
    # ------------------------------------------------------------------

    def __repr__(self):
        return repr(self.to_dict())

    def __str__(self):
        return pprint.pformat(self.to_dict())

    def __bool__(self):
        return bool(self._ensure_cache())

    # ------------------------------------------------------------------
    # dict-like helpers
    # ------------------------------------------------------------------

    def clear(self):
        """
        Deletes this row from the database.
        """
        self.table.delete(where=self.pk)
        self.invalidate()
        return self

    def keys(self):
        return self._ensure_cache().keys()

    def values(self, *args):
        d = self._ensure_cache()
        if args:
            return [d[arg] for arg in args]
        return list(d.values())

    def items(self):
        return self._ensure_cache().items()

    def get(self, key, failobj=None):
        try:
            data = self[key]
            if data is None:
                return failobj
            return data
        except DbColumnMissingError:
            return failobj
        except Exception as e:
            error_msg = str(e).lower()
            if "column" in error_msg and (
                "does not exist" in error_msg or "not found" in error_msg
            ):
                return failobj
            raise

    def setdefault(self, key, default=None):
        data = self[key]
        if data is None:
            self[key] = default
            return default
        return data

    def update(self, dict_=None, **kwds):
        """
        Updates columns in this row (write-through to DB + local cache).
        """
        data = {}
        if dict_:
            data.update(dict_)
        if kwds:
            data.update(kwds)
        if data:
            self.table.update_or_insert(data, pk=self.pk)
            # Invalidate cache so trigger-computed columns are re-fetched
            object.__setattr__(self, "_cache", None)
            object.__setattr__(self, "_column_set", None)
        return self

    def copy(self, lock=None):
        """
        Makes a copy of this row with a new sys_id, dropping sys_-prefixed columns from the new dict.
        """
        old = self.to_dict()
        for k in list(old.keys()):
            if "sys_" in k:
                old.pop(k)
        return self.table.new(old, lock=lock)

    def pop(self, key, *args):
        raise NotImplementedError

    def popitem(self):
        raise NotImplementedError

    def __lt__(self, other):
        raise NotImplementedError

    def __gt__(self, other):
        raise NotImplementedError

    def __le__(self, other):
        raise NotImplementedError

    def __ge__(self, other):
        raise NotImplementedError

    @classmethod
    def fromkeys(cls, iterable, value=None):
        raise NotImplementedError

    def to_dict(self):
        """
        Returns the row as a dictionary (from cache or via a SELECT on self.pk).
        """
        return dict(self._ensure_cache())

    def extract(self, *args):
        """
        Returns a dict containing only the specified columns from this row.
        """
        data = {}
        for key in args:
            if isinstance(key, (tuple, list)):
                data.update(self.extract(*key))
            else:
                data[key] = self[key]
        return data

    @property
    def key_cols(self):
        """
        Returns the primary key columns for the underlying table, defaulting to ['sys_id'] if missing.
        """
        return ["sys_id"]

    def split(self):
        """
        Splits data from PK references into (non_sys_data, pk).
        """
        old = self.to_dict()
        for k in list(old.keys()):
            if "sys_" in k:
                old.pop(k)
        return old, self.pk

    @property
    def data(self):
        """
        Returns the 'non-sys' data dictionary for this row.
        """
        return self.split()[0]

    def row(self, key, lock=None):
        """
        Retrieve a row from a foreign key column if present. E.g. row.row('fk_column').
        """
        value = self[key]
        if value is None:
            return None
        fk = self.table.foreign_key_info(key)
        if not fk:
            raise Exception(
                f"Column `{key}` is not a foreign key in `{self.table.name}`"
            )
        return self.table.tx.Row(fk["referenced_table_name"], value, lock=lock)

    def match(self, other):
        """
        Returns True if the columns in 'other' match this row's columns for the same keys.
        """
        for k in other:
            if self[k] != other[k]:
                return False
        return True

    def batch_update(self):
        """Context manager that defers writes until exit.

        Usage::

            with row.batch_update():
                row["name"] = "John"
                row["email"] = "john@example.com"
            # Single UPDATE executed here

        Reads inside the block see the pending values.  If an exception
        occurs the pending changes are discarded and the cache is
        invalidated so the next read re-fetches from the database.
        """
        return _BatchContext(self)

    def save(self):
        """Flush accumulated dirty-tracking changes to the database.

        When ``dirty_tracking=True``, assignments to the row accumulate
        in memory instead of writing through immediately.  Call
        ``.save()`` to flush them all in a single UPDATE::

            row = Row(table, 1, dirty_tracking=True)
            row["name"] = "John"
            row["email"] = "john@example.com"
            row.save()  # Single UPDATE with both columns

        Returns ``self`` for chaining.

        Raises:
            RuntimeError: If dirty tracking is not enabled on this row.
        """
        if not self._dirty_tracking:
            raise RuntimeError(
                "save() requires dirty_tracking=True. "
                "Use Row(table, key, dirty_tracking=True) or row.update({...})."
            )
        dirty = self._dirty
        object.__setattr__(self, "_dirty", {})
        if dirty:
            self.table.update_or_insert(dirty, pk=self.pk)
            # Invalidate cache so trigger-computed columns are re-fetched
            object.__setattr__(self, "_cache", None)
            object.__setattr__(self, "_column_set", None)
        return self

    @property
    def is_dirty(self):
        """Return True if there are unsaved dirty-tracking changes."""
        return bool(self._dirty)

    def discard(self):
        """Discard accumulated dirty-tracking changes without writing to DB.

        Also invalidates the cache so the next read re-fetches from the
        database, undoing any optimistic cache updates.

        Returns ``self`` for chaining.
        """
        object.__setattr__(self, "_dirty", {})
        object.__setattr__(self, "_cache", None)
        object.__setattr__(self, "_column_set", None)
        return self

    def touch(self):
        """
        Update sys_modified to current timestamp.
        """
        self["sys_modified"] = "@@CURRENT_TIMESTAMP"
        return self

    delete = clear

    def lock(self):
        """
        SELECT ... FOR UPDATE on this row.
        """
        self.table.select(where=self.pk, lock=True)
        return self

    def with_lock(self):
        """SELECT ... FOR UPDATE and clear the cache so the next read is fresh.

        Returns self for chaining::

            row = row.with_lock()
            balance = row["balance"]  # guaranteed fresh, locked
        """
        self.table.select(where=self.pk, lock=True)
        object.__setattr__(self, "_cache", None)
        object.__setattr__(self, "_column_set", None)
        return self

    def no_cache(self):
        """Return a new Row that never caches — every read hits the database.

        Useful for critical-path reads where staleness is unacceptable::

            fresh_row = row.no_cache()
            balance = fresh_row["balance"]  # always from DB
        """
        return Row(self.table, self.pk, no_cache=True)

    def notBlank(self, key, failobj=None):
        """
        Returns the value if it is not blank, else failobj.
        """
        data = self[key]
        return data if data else failobj

    getBlank = notBlank

    @property
    def sys_id(self):
        return self.pk["sys_id"]


class _BatchContext:
    """Implements the context-manager protocol for :meth:`Row.batch_update`."""

    __slots__ = ("_row",)

    def __init__(self, row):
        self._row = row

    def __enter__(self):
        object.__setattr__(self._row, "_batching", True)
        object.__setattr__(self._row, "_pending", {})
        return self._row

    def __exit__(self, exc_type, exc_val, exc_tb):
        row = self._row
        pending = row._pending
        object.__setattr__(row, "_batching", False)
        object.__setattr__(row, "_pending", {})

        if exc_type is not None:
            # Discard optimistic cache updates on error
            row.invalidate()
            return False

        if pending:
            row.table.update_or_insert(pending, pk=row.pk)
            # Invalidate cache so trigger-computed columns are re-fetched
            object.__setattr__(row, "_cache", None)
            object.__setattr__(row, "_column_set", None)
        return False
