"""
Authorize.Net Payment Processor Adapter

Implements the PaymentProcessorAdapter interface for Authorize.Net payment processing
using the Customer Information Manager (CIM) for stored payment profiles and the
Payment Transactions API for charges.

Key Features:
- Customer profile management (CIM)
- Stored payment method charges (authCaptureTransaction)
- Pre-authorization with later capture support
- Refunds via the Transaction API
- Transaction history and reporting

Configuration:
    Requires environment variables:
    - AN_API_LOGIN_ID or ANApiLoginId
    - AN_API_TRANSACTION_KEY or ANApiTransactionKey
    - AN_ENDPOINT or ANEndPoint (SDK endpoint URL)
"""

import decimal
import logging
import time
import xmltodict
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

from authorizenet import apicontractsv1, apicontrollers

from .base_adapter import PaymentProcessorAdapter, ProcessorError

logger = logging.getLogger(__name__)

# Suppress noisy SDK logs
logging.getLogger("authorizenet.sdk").setLevel(logging.ERROR)
logging.getLogger("pyxb").setLevel(logging.WARNING)

RESPONSE_CODES = {
    1: "Approved",
    2: "Declined",
    3: "Error",
    4: "Held for Review",
}


class AuthorizeNetAdapter(PaymentProcessorAdapter):
    """
    Authorize.Net adapter for payment processing via Customer Information Manager.

    Uses stored customer profiles with payment profiles for recurring and
    on-demand charges.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize Authorize.Net adapter with API credentials.

        Args:
            config: Dictionary containing:
                - api_login_id: Authorize.Net API Login ID (required)
                - api_transaction_key: Authorize.Net Transaction Key (required)
                - endpoint: SDK endpoint URL (required)
        """
        super().__init__(config)
        self.api_login_id = config.get("api_login_id")
        self.api_transaction_key = config.get("api_transaction_key")
        self.endpoint = config.get("endpoint")

        if not all([self.api_login_id, self.api_transaction_key, self.endpoint]):
            raise ValueError(
                "Authorize.Net configuration incomplete. Required: "
                "api_login_id, api_transaction_key, endpoint"
            )

    def _merchant_auth(self) -> apicontractsv1.merchantAuthenticationType:
        """Create a merchant authentication object for API requests."""
        auth = apicontractsv1.merchantAuthenticationType()
        auth.name = self.api_login_id
        auth.transactionKey = self.api_transaction_key
        return auth

    def _execute(self, controller):
        """Execute an API controller and parse the response.

        Returns the parsed response dict with envelope keys stripped.

        Raises:
            ProcessorError: On API-level errors (resultCode != 'Ok').
        """
        controller.setenvironment(self.endpoint)
        controller.execute()
        raw = controller._httpResponse
        if not raw:
            raise ProcessorError(
                processor="authorize_net",
                error_code="no_response",
                error_message="No response received from Authorize.Net",
            )
        response = xmltodict.parse(raw, dict_constructor=dict)
        response = response[list(response.keys())[0]]
        response.pop("@xmlns:xsi", "")
        response.pop("@xmlns:xsd", "")
        response.pop("@xmlns", "")
        if response["messages"]["resultCode"] != "Ok":
            msg_data = response["messages"]["message"]
            if isinstance(msg_data, list):
                parts = [f'{m["code"]}: {m["text"]}' for m in msg_data]
                error_message = "; ".join(parts)
                error_code = msg_data[0]["code"]
            else:
                error_message = f'{msg_data["code"]}: {msg_data["text"]}'
                error_code = msg_data["code"]
            raise ProcessorError(
                processor="authorize_net",
                error_code=error_code,
                error_message=error_message,
                metadata={"raw_messages": msg_data},
            )
        response.pop("messages", "")
        return response

    # ========================================================================
    # ACCOUNT MANAGEMENT
    # ========================================================================

    def create_account(self, tx, client_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Authorize.Net does not have connected/sub-merchant accounts.

        Clients share the platform's AN merchant account. This returns a
        placeholder record so the routing layer can treat it uniformly.
        """
        client_id = client_data["client_id"]

        payment_account = tx.table("client_payment_accounts").new()
        payment_account["client_id"] = client_id
        payment_account["processor_type"] = "authorize_net"
        payment_account["processor_account_id"] = f"an_{client_id}"
        payment_account["account_status"] = "active"
        payment_account["charges_enabled"] = True
        payment_account["payouts_enabled"] = False
        payment_account["details_submitted"] = True
        payment_account["requirements_data"] = {}
        payment_account["capabilities"] = {
            "card_payments": True,
            "manual_settlement": True,
        }

        return {
            "processor_account_id": f"an_{client_id}",
            "status": "active",
            "requires_onboarding": False,
            "onboarding_url": None,
            "charges_enabled": True,
            "payouts_enabled": False,
            "metadata": {"account_type": "shared_merchant"},
        }

    def get_account_status(self, tx, processor_account_id: str) -> Dict[str, Any]:
        """
        Authorize.Net shared merchant is always active if credentials are valid.
        """
        return {
            "account_id": processor_account_id,
            "status": "active",
            "charges_enabled": True,
            "payouts_enabled": False,
            "requirements_due": [],
            "requirements_past_due": [],
            "requirements_deadline": None,
            "verification_status": "verified",
            "metadata": {"account_type": "shared_merchant"},
        }

    def create_onboarding_link(
        self, tx, processor_account_id: str, return_url: str, refresh_url: str
    ) -> Optional[str]:
        """Authorize.Net does not support hosted onboarding flows."""
        return None

    # ========================================================================
    # CUSTOMER PROFILE MANAGEMENT (CIM)
    # ========================================================================

    def get_or_create_customer_profile(
        self, tx, customer_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Get an existing AN customer profile or create one.

        Looks up by email in payment_profiles table first. If not found,
        creates a new CIM profile at Authorize.Net.
        """
        email_address = customer_data["email_address"]

        existing = (
            tx.table("payment_profiles")
            .select(
                columns=["customer_profile_id"],
                where={"email_address": email_address, "src": "AN"},
                orderby="is_default desc, sys_id desc",
            )
            .one()
        )
        if existing and existing.get("customer_profile_id"):
            return {
                "customer_profile_id": existing["customer_profile_id"],
                "created": False,
            }

        profile = apicontractsv1.customerProfileType()
        profile.email = email_address
        profile.description = customer_data.get("name", email_address)

        request = apicontractsv1.createCustomerProfileRequest()
        request.merchantAuthentication = self._merchant_auth()
        request.profile = profile

        controller = apicontrollers.createCustomerProfileController(request)
        try:
            response = self._execute(controller)
        except ProcessorError as e:
            # E00039 = duplicate profile — extract existing ID
            if "E00039" in e.error_code or "E00039" in e.error_message:
                parts = e.error_message.split()
                for part in parts:
                    if part.strip().isdigit():
                        return {
                            "customer_profile_id": part.strip(),
                            "created": False,
                        }
            raise

        return {
            "customer_profile_id": response["customerProfileId"],
            "created": True,
        }

    def attach_payment_method(
        self,
        tx,
        customer_profile_id: str,
        payment_method_id: str,
        payment_data: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Create a payment profile under an existing AN customer profile.

        For Authorize.Net, ``payment_method_id`` is unused since card data
        must be supplied in ``payment_data``. The returned
        ``payment_profile_id`` is the CIM payment profile ID.
        """
        payment_data = payment_data or {}

        creditCard = apicontractsv1.creditCardType()
        creditCard.cardNumber = payment_data["card_number"]
        creditCard.expirationDate = payment_data["expiration_date"]
        if payment_data.get("card_code"):
            creditCard.cardCode = payment_data["card_code"]

        payment = apicontractsv1.paymentType()
        payment.creditCard = creditCard

        billTo = apicontractsv1.customerAddressType()
        billTo.firstName = payment_data.get("first_name", "")
        billTo.lastName = payment_data.get("last_name", "")
        if payment_data.get("address"):
            billTo.address = payment_data["address"]
        if payment_data.get("city"):
            billTo.city = payment_data["city"]
        if payment_data.get("state"):
            billTo.state = payment_data["state"]
        if payment_data.get("zip"):
            billTo.zip = payment_data["zip"]

        profile = apicontractsv1.customerPaymentProfileType()
        profile.customerType = "individual"
        profile.payment = payment
        profile.billTo = billTo
        profile.defaultPaymentProfile = payment_data.get("set_default", True)

        request = apicontractsv1.createCustomerPaymentProfileRequest()
        request.merchantAuthentication = self._merchant_auth()
        request.paymentProfile = profile
        request.customerProfileId = customer_profile_id
        request.validationMode = apicontractsv1.validationModeEnum.testMode

        controller = apicontrollers.createCustomerPaymentProfileController(request)
        response = self._execute(controller)

        return {
            "customer_profile_id": customer_profile_id,
            "payment_profile_id": response["customerPaymentProfileId"],
        }

    def detach_payment_method(
        self, tx, payment_method_id: str, payment_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Delete a payment profile from an AN customer profile.

        ``payment_data`` must include ``customer_profile_id``.
        """
        payment_data = payment_data or {}
        customer_profile_id = payment_data.get("customer_profile_id")
        if not customer_profile_id:
            raise ProcessorError(
                processor="authorize_net",
                error_code="missing_customer_profile_id",
                error_message="customer_profile_id is required to detach an AN payment method",
            )

        request = apicontractsv1.deleteCustomerPaymentProfileRequest()
        request.merchantAuthentication = self._merchant_auth()
        request.customerProfileId = customer_profile_id
        request.customerPaymentProfileId = payment_method_id

        controller = apicontrollers.deleteCustomerPaymentProfileController(request)
        try:
            self._execute(controller)
        except ProcessorError as e:
            # E00040 = record not found — already deleted
            if "E00040" in str(e.error_code) or "E00040" in str(e.error_message):
                logger.info(
                    "AN payment profile %s already deleted", payment_method_id
                )
            else:
                raise

        return {"payment_profile_id": payment_method_id, "detached": True}

    def delete_customer_profile(self, tx, customer_profile_id: str) -> Dict[str, Any]:
        """Delete an entire AN customer profile and all its payment profiles."""
        request = apicontractsv1.deleteCustomerProfileRequest()
        request.merchantAuthentication = self._merchant_auth()
        request.customerProfileId = customer_profile_id

        controller = apicontrollers.deleteCustomerProfileController(request)
        try:
            self._execute(controller)
        except ProcessorError as e:
            if "E00040" in str(e.error_code) or "E00040" in str(e.error_message):
                logger.info("AN customer profile %s already deleted", customer_profile_id)
            else:
                raise

        return {"customer_profile_id": customer_profile_id, "deleted": True}

    # ========================================================================
    # PAYMENT AUTHORIZATION (PRE-AUTH)
    # ========================================================================

    def authorize_payment(self, tx, payment_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Pre-authorize a payment using authOnlyTransaction on a stored profile.

        Authorize.Net authorizations expire after 30 days.
        """
        try:
            amount_cents = payment_data["amount"]
            amount_dollars = decimal.Decimal(amount_cents) / 100

            profile = apicontractsv1.customerProfilePaymentType()
            profile.customerProfileId = payment_data.get("customer_profile_id")
            profile.paymentProfile = apicontractsv1.paymentProfile()
            profile.paymentProfile.paymentProfileId = payment_data["payment_method"]

            tx_request = apicontractsv1.transactionRequestType()
            tx_request.transactionType = "authOnlyTransaction"
            tx_request.amount = amount_dollars
            tx_request.profile = profile

            if payment_data.get("client_id") or payment_data.get("description"):
                order = apicontractsv1.orderType()
                client_id = payment_data.get("client_id", "")
                desc = payment_data.get("description", str(client_id))
                order.description = str(desc)[:255]
                tx_request.order = order

            request = apicontractsv1.createTransactionRequest()
            request.merchantAuthentication = self._merchant_auth()
            request.transactionRequest = tx_request
            request.refId = f"ref{int(time.time() * 1000)}"

            controller = apicontrollers.createTransactionController(request)
            response = self._execute(controller)
            trans = response.get("transactionResponse", {})
            code = int(trans.get("responseCode", 3))

            if RESPONSE_CODES.get(code) == "Approved":
                return {
                    "processor_transaction_id": trans.get("transId"),
                    "status": "authorized",
                    "amount": amount_cents,
                    "currency": "usd",
                    "authorization_code": trans.get("authCode"),
                    "expires_at": datetime.now(timezone.utc) + timedelta(days=30),
                    "error_message": None,
                    "metadata": {
                        "response_code": code,
                        "response_text": RESPONSE_CODES.get(code),
                    },
                }
            else:
                msg = trans.get("messages", {})
                if isinstance(msg, dict) and "message" in msg:
                    m = msg["message"]
                    error_text = m.get("description", "") if isinstance(m, dict) else str(m)
                else:
                    error_text = RESPONSE_CODES.get(code, "Unknown error")
                return {
                    "processor_transaction_id": trans.get("transId"),
                    "status": "failed",
                    "amount": amount_cents,
                    "currency": "usd",
                    "authorization_code": None,
                    "expires_at": None,
                    "error_message": error_text,
                    "metadata": {"response_code": code},
                }

        except ProcessorError:
            raise
        except Exception as e:
            raise ProcessorError(
                processor="authorize_net",
                error_code="unexpected_error",
                error_message=str(e),
                metadata={"error_type": type(e).__name__},
            )

    def charge_stored_payment_method(
        self, tx, payment_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Charge a stored AN payment profile immediately (authCaptureTransaction).

        This is the primary billing path used by monthly recurring charges
        and spot donations.
        """
        try:
            amount_cents = payment_data["amount"]
            amount_dollars = decimal.Decimal(amount_cents) / 100

            profile = apicontractsv1.customerProfilePaymentType()
            profile.customerProfileId = payment_data.get("customer_profile_id")
            profile.paymentProfile = apicontractsv1.paymentProfile()
            profile.paymentProfile.paymentProfileId = payment_data["payment_method"]

            tx_request = apicontractsv1.transactionRequestType()
            tx_request.transactionType = "authCaptureTransaction"
            tx_request.amount = amount_dollars
            tx_request.profile = profile

            # Order description
            metadata = payment_data.get("metadata") or {}
            client_id = payment_data.get("client_id", "")
            campaign = metadata.get("campaign", str(client_id))
            if client_id or campaign:
                order = apicontractsv1.orderType()
                if client_id and campaign:
                    order.description = f"{client_id}::{campaign}"[:255]
                else:
                    order.description = str(client_id or campaign)[:255]
                tx_request.order = order

            # Line items
            line_items = metadata.get("line_items", [])
            if line_items:
                if len(line_items) > 30:
                    raise ProcessorError(
                        processor="authorize_net",
                        error_code="too_many_line_items",
                        error_message="Authorize.Net allows up to 30 line items per transaction",
                    )
                line_item_array = apicontractsv1.ArrayOfLineItem()
                for item in line_items:
                    li = apicontractsv1.lineItemType()
                    li.itemId = item.get("item_id", "")
                    li.name = item.get("name", "")
                    li.description = item.get("description", "")
                    li.quantity = item.get("qty", "1")
                    li.unitPrice = item.get("unit_price", "0")
                    line_item_array.lineItem.append(li)
                tx_request.lineItems = line_item_array

            request = apicontractsv1.createTransactionRequest()
            request.merchantAuthentication = self._merchant_auth()
            request.transactionRequest = tx_request
            request.refId = f"ref{int(time.time() * 1000)}"

            controller = apicontrollers.createTransactionController(request)
            response = self._execute(controller)
            trans = response.get("transactionResponse", {})
            code = int(trans.get("responseCode", 3))

            if RESPONSE_CODES.get(code) == "Approved":
                return {
                    "processor_transaction_id": trans.get("transId"),
                    "processor_charge_id": trans.get("transId"),
                    "status": RESPONSE_CODES[code],
                    "success": True,
                    "amount": amount_cents,
                    "currency": "usd",
                    "authorization_code": trans.get("authCode"),
                    "platform_fee": 0,
                    "client_amount": amount_cents,
                    "error_message": None,
                    "metadata": {
                        "response_code": code,
                        "auth_code": trans.get("authCode"),
                        "trans_id": trans.get("transId"),
                        "profile_customer_id": trans.get("profile", {}).get(
                            "customerProfileId"
                        ),
                        "profile_payment_id": trans.get("profile", {}).get(
                            "customerPaymentProfileId"
                        ),
                        "test_request": trans.get("testRequest"),
                    },
                }
            else:
                msg = trans.get("messages", {})
                if isinstance(msg, dict) and "message" in msg:
                    m = msg["message"]
                    error_text = m.get("description", "") if isinstance(m, dict) else str(m)
                else:
                    error_text = RESPONSE_CODES.get(code, "Unknown error")
                return {
                    "processor_transaction_id": trans.get("transId"),
                    "processor_charge_id": None,
                    "status": RESPONSE_CODES.get(code, "Error"),
                    "success": False,
                    "amount": amount_cents,
                    "currency": "usd",
                    "authorization_code": None,
                    "platform_fee": 0,
                    "client_amount": 0,
                    "error_message": error_text,
                    "metadata": {"response_code": code},
                }

        except ProcessorError:
            raise
        except Exception as e:
            return {
                "processor_transaction_id": None,
                "processor_charge_id": None,
                "status": "Error",
                "success": False,
                "amount": payment_data.get("amount"),
                "currency": "usd",
                "authorization_code": None,
                "platform_fee": 0,
                "client_amount": 0,
                "error_message": str(e),
                "metadata": {"error_type": type(e).__name__},
            }

    # ========================================================================
    # PAYMENT CAPTURE
    # ========================================================================

    def capture_payment(
        self, tx, processor_transaction_id: str, amount: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Capture a previously authorized AN transaction (priorAuthCaptureTransaction).
        """
        try:
            tx_request = apicontractsv1.transactionRequestType()
            tx_request.transactionType = "priorAuthCaptureTransaction"
            tx_request.refTransId = processor_transaction_id
            if amount is not None:
                tx_request.amount = decimal.Decimal(amount) / 100

            request = apicontractsv1.createTransactionRequest()
            request.merchantAuthentication = self._merchant_auth()
            request.transactionRequest = tx_request

            controller = apicontrollers.createTransactionController(request)
            response = self._execute(controller)
            trans = response.get("transactionResponse", {})
            code = int(trans.get("responseCode", 3))

            if RESPONSE_CODES.get(code) == "Approved":
                captured_cents = amount if amount is not None else 0
                return {
                    "processor_transaction_id": trans.get("transId"),
                    "processor_charge_id": trans.get("transId"),
                    "status": "captured",
                    "amount_captured": captured_cents,
                    "platform_fee": 0,
                    "client_amount": captured_cents,
                    "captured_at": datetime.now(timezone.utc),
                    "error_message": None,
                    "metadata": {"response_code": code},
                }
            else:
                raise ProcessorError(
                    processor="authorize_net",
                    error_code="capture_failed",
                    error_message=RESPONSE_CODES.get(code, "Capture failed"),
                    metadata={
                        "transaction_id": processor_transaction_id,
                        "response_code": code,
                    },
                )

        except ProcessorError:
            raise
        except Exception as e:
            raise ProcessorError(
                processor="authorize_net",
                error_code="unknown_error",
                error_message=str(e),
                metadata={"transaction_id": processor_transaction_id},
            )

    def cancel_payment(
        self, tx, processor_transaction_id: str, reason: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Void a previously authorized AN transaction.
        """
        try:
            tx_request = apicontractsv1.transactionRequestType()
            tx_request.transactionType = "voidTransaction"
            tx_request.refTransId = processor_transaction_id

            request = apicontractsv1.createTransactionRequest()
            request.merchantAuthentication = self._merchant_auth()
            request.transactionRequest = tx_request

            controller = apicontrollers.createTransactionController(request)
            response = self._execute(controller)
            trans = response.get("transactionResponse", {})
            code = int(trans.get("responseCode", 3))

            if RESPONSE_CODES.get(code) == "Approved":
                return {
                    "processor_transaction_id": processor_transaction_id,
                    "status": "cancelled",
                    "cancelled_at": datetime.now(timezone.utc),
                    "reason": reason,
                    "error_message": None,
                }
            else:
                raise ProcessorError(
                    processor="authorize_net",
                    error_code="cancellation_failed",
                    error_message=RESPONSE_CODES.get(code, "Void failed"),
                    metadata={"transaction_id": processor_transaction_id},
                )

        except ProcessorError:
            raise
        except Exception as e:
            raise ProcessorError(
                processor="authorize_net",
                error_code="unknown_error",
                error_message=str(e),
                metadata={"transaction_id": processor_transaction_id},
            )

    # ========================================================================
    # REFUNDS
    # ========================================================================

    def refund_payment(
        self,
        tx,
        processor_charge_id: str,
        amount: Optional[int] = None,
        reason: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Refund a settled AN transaction.

        Authorize.Net requires the last 4 digits of the card for refunds,
        which must be supplied via the ``payment_data`` metadata. If not
        available, this calls getTransactionDetails to retrieve them.
        """
        try:
            tx_request = apicontractsv1.transactionRequestType()
            tx_request.transactionType = "refundTransaction"
            tx_request.refTransId = processor_charge_id
            if amount is not None:
                tx_request.amount = decimal.Decimal(amount) / 100

            request = apicontractsv1.createTransactionRequest()
            request.merchantAuthentication = self._merchant_auth()
            request.transactionRequest = tx_request

            controller = apicontrollers.createTransactionController(request)
            response = self._execute(controller)
            trans = response.get("transactionResponse", {})
            code = int(trans.get("responseCode", 3))

            if RESPONSE_CODES.get(code) == "Approved":
                return {
                    "refund_id": trans.get("transId"),
                    "status": "succeeded",
                    "amount_refunded": amount or 0,
                    "platform_fee_refunded": 0,
                    "refunded_at": datetime.now(timezone.utc),
                    "reason": reason,
                    "error_message": None,
                }
            else:
                raise ProcessorError(
                    processor="authorize_net",
                    error_code="refund_failed",
                    error_message=RESPONSE_CODES.get(code, "Refund failed"),
                    metadata={"transaction_id": processor_charge_id},
                )

        except ProcessorError:
            raise
        except Exception as e:
            raise ProcessorError(
                processor="authorize_net",
                error_code="unknown_error",
                error_message=str(e),
                metadata={"transaction_id": processor_charge_id},
            )

    # ========================================================================
    # TRANSACTION REPORTING
    # ========================================================================

    def get_settled_batch_list(self, days: int = 1, **kwargs) -> Dict[str, Any]:
        """Retrieve settled batch list from Authorize.Net.

        Args:
            days: Number of days to look back (max 31).

        Returns:
            Parsed batch list response dict.
        """
        if days > 31:
            raise ProcessorError(
                processor="authorize_net",
                error_code="invalid_date_range",
                error_message="Date range cannot exceed 31 days",
            )

        request = apicontractsv1.getSettledBatchListRequest()
        request.merchantAuthentication = self._merchant_auth()
        request.includeStatistics = True

        start_date = kwargs.get("start_date")
        end_date = kwargs.get("end_date")
        if start_date and end_date:
            request.firstSettlementDate = start_date
            request.lastSettlementDate = end_date
        else:
            request.firstSettlementDate = datetime.now() - timedelta(days=days)
            request.lastSettlementDate = datetime.now()

        controller = apicontrollers.getSettledBatchListController(request)
        return self._execute(controller)

    def get_transaction_details(self, transaction_id: str) -> Dict[str, Any]:
        """Retrieve details for a single AN transaction."""
        request = apicontractsv1.getTransactionDetailsRequest()
        request.merchantAuthentication = self._merchant_auth()
        request.transId = transaction_id

        controller = apicontrollers.getTransactionDetailsController(request)
        return self._execute(controller)

    def get_unsettled_transactions(self) -> Dict[str, Any]:
        """Retrieve the list of unsettled transactions (fraud review queue)."""
        request = apicontractsv1.getUnsettledTransactionListRequest()
        request.merchantAuthentication = self._merchant_auth()

        controller = apicontrollers.getUnsettledTransactionListController(request)
        return self._execute(controller)

    def approve_held_transaction(self, transaction_id: str) -> Dict[str, Any]:
        """Approve a transaction held for fraud review."""
        return self._update_held_transaction(transaction_id, "approve")

    def decline_held_transaction(self, transaction_id: str) -> Dict[str, Any]:
        """Decline a transaction held for fraud review."""
        return self._update_held_transaction(transaction_id, "decline")

    def _update_held_transaction(
        self, transaction_id: str, action: str
    ) -> Dict[str, Any]:
        request_type = apicontractsv1.heldTransactionRequestType()
        request_type.action = action
        request_type.refTransId = transaction_id

        request = apicontractsv1.updateHeldTransactionRequest()
        request.merchantAuthentication = self._merchant_auth()
        request.heldTransactionRequest = request_type

        controller = apicontrollers.updateHeldTransactionController(request)
        return self._execute(controller)

    # ========================================================================
    # UTILITY METHODS
    # ========================================================================

    def validate_configuration(self) -> bool:
        """
        Validate AN configuration by attempting an API call.
        """
        try:
            request = apicontractsv1.getCustomerProfileIdsRequest()
            request.merchantAuthentication = self._merchant_auth()
            controller = apicontrollers.getCustomerProfileIdsController(request)
            self._execute(controller)
            return True
        except Exception:
            return False
