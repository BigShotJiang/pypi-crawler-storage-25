"""Generic payment adapters and shared charge rules for velocity-python.

Application-specific routing/profile logic lives outside velocity (e.g. in
support.app.payment).
"""

from .base_adapter import PaymentProcessorAdapter, ProcessorError
from .stripe_adapter import StripeAdapter
from .braintree_adapter import BraintreeAdapter

try:
    from .authorizenet_adapter import AuthorizeNetAdapter
except ImportError:
    AuthorizeNetAdapter = None

from .charge_rules import (
    should_charge_immediately,
    is_below_immediate_charge_minimum,
    is_above_immediate_charge_maximum,
)

__all__ = [
    # Base classes
    "PaymentProcessorAdapter",
    "ProcessorError",
    # Adapters
    "StripeAdapter",
    "BraintreeAdapter",
    "AuthorizeNetAdapter",
    # Generic shared helpers
    "should_charge_immediately",
    "is_below_immediate_charge_minimum",
    "is_above_immediate_charge_maximum",
]

__version__ = "1.0.0"
