# eXonware namespace package (allows multiple exonware.* packages to coexist)
__path__ = __import__('pkgutil').extend_path(__path__, __name__)
