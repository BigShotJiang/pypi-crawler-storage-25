"""
LangChain tools for NEAR Protocol.
Generated for: LangChain Tool - NEAR filter account
"""
import requests
import json
import base64
from typing import Optional, Type, Any, List, Dict, Union, Tuple, Set, Callable
from pydantic import BaseModel, Field

try:
    from langchain.tools import BaseTool
except ImportError:
    from langchain_core.tools import BaseTool  # langchain v0.2+

NEAR_RPC_MAINNET = "https://rpc.mainnet.near.org"
NEAR_RPC_TESTNET = "https://rpc.testnet.near.org"


def _near_rpc(method: str, params: Any, network: str = "mainnet") -> dict:
    """Execute NEAR JSON-RPC call."""
    url = NEAR_RPC_MAINNET if network == "mainnet" else NEAR_RPC_TESTNET
    resp = requests.post(url, json={"jsonrpc":"2.0","id":"1","method":method,"params":params}, timeout=10)
    resp.raise_for_status()
    data = resp.json()
    if "error" in data:
        raise RuntimeError(f"NEAR RPC error: {data['error']}")
    return data.get("result", {})


class NEARAccountInput(BaseModel):
    account_id: str = Field(description="NEAR account ID (e.g. example.near)")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARAccountTool(BaseTool):
    """Query NEAR account balance and storage info."""
    name: str = "near_account_info"
    description: str = "Get NEAR account balance and info. Input: account_id, network (optional)"
    args_schema: Type[BaseModel] = NEARAccountInput

    def _run(self, account_id: str, network: str = "mainnet") -> str:
        result = _near_rpc("query", {
            "request_type": "view_account", "finality": "final", "account_id": account_id
        }, network)
        near = int(result.get("amount", 0)) / 10**24
        return json.dumps({"account_id": account_id, "balance_near": f"{near:.4f}",
            "storage_bytes": result.get("storage_usage", 0)})

    async def _arun(self, account_id: str, network: str = "mainnet") -> str:
        return self._run(account_id, network)


class NEARViewFunctionInput(BaseModel):
    contract_id: str = Field(description="NEAR contract ID")
    method_name: str = Field(description="View method name")
    args: dict = Field(default={}, description="Method arguments")
    network: str = Field(default="mainnet", description="mainnet or testnet")


class NEARViewFunctionTool(BaseTool):
    """Call a view function on a NEAR smart contract."""
    name: str = "near_view_function"
    description: str = "Call a NEAR contract view function. Input: contract_id, method_name, args"
    args_schema: Type[BaseModel] = NEARViewFunctionInput

    def _run(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        args_b64 = base64.b64encode(json.dumps(args).encode()).decode()
        result = _near_rpc("query", {
            "request_type": "call_function", "finality": "final",
            "account_id": contract_id, "method_name": method_name, "args_base64": args_b64
        }, network)
        decoded = json.loads(bytes(result["result"]).decode())
        return json.dumps(decoded, indent=2)

    async def _arun(self, contract_id: str, method_name: str, args: dict = {}, network: str = "mainnet") -> str:
        return self._run(contract_id, method_name, args, network)


class FilterAccountsInput(BaseModel):
    account_ids: List[str]
    min_balance_near: Optional[float] = None
    max_balance_near: Optional[float] = None
    require_contract: Optional[bool] = None
    network: str = "mainnet"

class NEARFilterAccountsTool(BaseTool):
    name: str = "near_filter_accounts"
    description: str = (
        "Filter a list of NEAR accounts by criteria such as minimum/maximum balance "
        "(in NEAR), and whether they have a deployed contract. Returns matching accounts "
        "with their balances and contract status."
    )
    args_schema: Type[BaseModel] = FilterAccountsInput

    def _run(
        self,
        account_ids: List[str],
        min_balance_near: Optional[float] = None,
        max_balance_near: Optional[float] = None,
        require_contract: Optional[bool] = None,
        network: str = "mainnet",
    ) -> List[Dict[str, Any]]:
        results = []
        for account_id in account_ids:
            try:
                data = _near_rpc(
                    "query",
                    {"request_type": "view_account", "finality": "final", "account_id": account_id},
                    network=network,
                )
            except Exception as e:
                continue
            if "error" in data:
                continue
            balance_yocto = int(data.get("amount", 0))
            balance_near = balance_yocto / 1e24
            has_contract = data.get("code_hash", "11111111111111111111111111111111") != "11111111111111111111111111111111"
            if min_balance_near is not None and balance_near < min_balance_near:
                continue
            if max_balance_near is not None and balance_near > max_balance_near:
                continue
            if require_contract is not None and has_contract != require_contract:
                continue
            results.append({
                "account_id": account_id,
                "balance_near": round(balance_near, 6),
                "has_contract": has_contract,
                "storage_usage": data.get("storage_usage", 0),
            })
        return results

    async def _arun(
        self,
        account_ids: List[str],
        min_balance_near: Optional[float] = None,
        max_balance_near: Optional[float] = None,
        require_contract: Optional[bool] = None,
        network: str = "mainnet",
    ) -> List[Dict[str, Any]]:
        return self._run(
            account_ids=account_ids,
            min_balance_near=min_balance_near,
            max_balance_near=max_balance_near,
            require_contract=require_contract,
            network=network,
        )


class FilterAccountsByActivityInput(BaseModel):
    account_ids: List[str]
    min_transactions: Optional[int] = None
    network: str = "mainnet"

class NEARFilterAccountsByActivityTool(BaseTool):
    name: str = "near_filter_accounts_by_activity"
    description: str = (
        "Filter NEAR accounts by on-chain activity using the NEAR indexer API. "
        "Optionally require a minimum number of transactions. Returns accounts "
        "that meet the activity threshold with their transaction counts."
    )
    args_schema: Type[BaseModel] = FilterAccountsByActivityInput

    def _run(
        self,
        account_ids: List[str],
        min_transactions: Optional[int] = None,
        network: str = "mainnet",
    ) -> List[Dict[str, Any]]:
        base_url = (
            "https://api.nearblocks.io/v1/account"
            if network == "mainnet"
            else "https://api-testnet.nearblocks.io/v1/account"
        )
        results = []
        for account_id in account_ids:
            try:
                resp = requests.get(f"{base_url}/{account_id}", timeout=10)
                resp.raise_for_status()
                info = resp.json()
                txn_count = int(info.get("account", [{}])[0].get("txns_count", 0) if isinstance(info.get("account"), list) else info.get("txns_count", 0))
            except Exception:
                txn_count = 0
            if min_transactions is not None and txn_count < min_transactions:
                continue
            results.append({"account_id": account_id, "transaction_count": txn_count})
        return results

    async def _arun(
        self,
        account_ids: List[str],
        min_transactions: Optional[int] = None,
        network: str = "mainnet",
    ) -> List[Dict[str, Any]]:
        return self._run(
            account_ids=account_ids,
            min_transactions=min_transactions,
            network=network,
        )