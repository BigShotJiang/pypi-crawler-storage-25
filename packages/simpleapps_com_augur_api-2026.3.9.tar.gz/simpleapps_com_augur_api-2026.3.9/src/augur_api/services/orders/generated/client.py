"""
Generated client for orders service.
Source: shared/specs/orders.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.orders.generated.schemas import (
        OeHdrDocListParams,
        OeHdrLookupGetParams,
        PickTicketsLinesListParams,
        PickTicketsListParams,
        PoHdrListParams,
    )


class InvoiceHdrResource(BaseResource):
    """Resource for /invoice-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/invoice-hdr")

    def list_reprint(
        self,
        invoice_no: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /invoice-hdr/{invoiceNo}/reprint."""
        response = self._get(f"/{invoice_no}/reprint", params=options)
        return BaseResponse[Any].model_validate(response)


class OeHdrResource(BaseResource):
    """Resource for /oe-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/oe-hdr")

    def get_lookup(self, params: OeHdrLookupGetParams | None = None) -> BaseResponse[Any]:
        """GET /oe-hdr/lookup."""
        response = self._get("/lookup", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_doc(
        self,
        order_no: int,
        params: OeHdrDocListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /oe-hdr/{orderNo}/doc."""
        response = self._get(f"/{order_no}/doc", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_doc(self, order_no: int, params: OeHdrDocListParams | None = None) -> BaseResponse[Any]:
        """Alias for list_doc — GET /oe-hdr/{orderNo}/doc."""
        return self.list_doc(order_no, params=params)


class OeHdrSalesrepResource(BaseResource):
    """Resource for /oe-hdr-salesrep endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/oe-hdr-salesrep")

    def list_oe_hdr(
        self,
        salesrep_id: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /oe-hdr-salesrep/{salesrep-id}/oe-hdr."""
        response = self._get(f"/{salesrep_id}/oe-hdr", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_oe_hdr_doc(
        self,
        salesrep_id: int,
        order_no: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /oe-hdr-salesrep/{salesrep_id}/oe-hdr/{orderNo}/doc."""
        response = self._get(f"/{salesrep_id}/oe-hdr/{order_no}/doc", params=options)
        return BaseResponse[Any].model_validate(response)

    def get_oe_hdr_doc(
        self,
        salesrep_id: int,
        order_no: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """Alias for list_oe_hdr_doc — GET /oe-hdr-salesrep/{salesrep_id}/oe-hdr/{orderNo}/doc."""
        return self.list_oe_hdr_doc(salesrep_id, order_no, options=options)


class PickTicketsResource(BaseResource):
    """Resource for /pick-tickets endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/pick-tickets")

    def list(self, params: PickTicketsListParams | None = None) -> BaseResponse[Any]:
        """GET /pick-tickets."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        pick_ticket_no: float,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /pick-tickets/{pickTicketNo}."""
        response = self._get(f"/{pick_ticket_no}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_lines(
        self,
        pick_ticket_no: float,
        params: PickTicketsLinesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /pick-tickets/{pickTicketNo}/lines."""
        response = self._get(f"/{pick_ticket_no}/lines", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_lines(
        self,
        pick_ticket_no: float,
        line_number: float,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /pick-tickets/{pickTicketNo}/lines/{lineNumber}."""
        response = self._get(f"/{pick_ticket_no}/lines/{line_number}", params=options)
        return BaseResponse[Any].model_validate(response)


class PoHdrResource(BaseResource):
    """Resource for /po-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/po-hdr")

    def list(self, params: PoHdrListParams | None = None) -> BaseResponse[Any]:
        """GET /po-hdr."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create_scan(self, data: Any = None) -> BaseResponse[Any]:
        """POST /po-hdr/scan."""
        response = self._post("/scan", data=data)
        return BaseResponse[Any].model_validate(response)

    def get(self, po_no: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /po-hdr/{poNo}."""
        response = self._get(f"/{po_no}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_doc(self, po_no: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /po-hdr/{poNo}/doc."""
        response = self._get(f"/{po_no}/doc", params=options)
        return BaseResponse[Any].model_validate(response)

    def get_doc(self, po_no: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """Alias for list_doc — GET /po-hdr/{poNo}/doc."""
        return self.list_doc(po_no, options=options)


class OrdersClient(BaseServiceClient):
    """Client for the orders service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._invoice_hdr: InvoiceHdrResource | None = None
        self._oe_hdr: OeHdrResource | None = None
        self._oe_hdr_salesrep: OeHdrSalesrepResource | None = None
        self._pick_tickets: PickTicketsResource | None = None
        self._po_hdr: PoHdrResource | None = None

    @property
    def invoice_hdr(self) -> InvoiceHdrResource:
        """Access invoiceHdr endpoints."""
        if self._invoice_hdr is None:
            self._invoice_hdr = InvoiceHdrResource(self._http)
        return self._invoice_hdr

    @property
    def oe_hdr(self) -> OeHdrResource:
        """Access oeHdr endpoints."""
        if self._oe_hdr is None:
            self._oe_hdr = OeHdrResource(self._http)
        return self._oe_hdr

    @property
    def oe_hdr_salesrep(self) -> OeHdrSalesrepResource:
        """Access oeHdrSalesrep endpoints."""
        if self._oe_hdr_salesrep is None:
            self._oe_hdr_salesrep = OeHdrSalesrepResource(self._http)
        return self._oe_hdr_salesrep

    @property
    def pick_tickets(self) -> PickTicketsResource:
        """Access pickTickets endpoints."""
        if self._pick_tickets is None:
            self._pick_tickets = PickTicketsResource(self._http)
        return self._pick_tickets

    @property
    def po_hdr(self) -> PoHdrResource:
        """Access poHdr endpoints."""
        if self._po_hdr is None:
            self._po_hdr = PoHdrResource(self._http)
        return self._po_hdr
