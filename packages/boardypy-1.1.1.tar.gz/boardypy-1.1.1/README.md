# BoardyPy

BoardyPy is a desktop MicroPython IDE built with PyQt5.

It focuses on a lightweight workflow for MicroPython boards and bundles the tools you need in one place:

- code editor with syntax highlighting
- serial REPL / console
- local file explorer
- device file explorer for MicroPython boards
- bundled MicroPython library manager
- local script runner
- Pixel Matrix OLED drawing in the free Community tier

## Community / Pro Model

BoardyPy remains installable from PyPI as a free Community version:

```bash
pip install boardypy
pip install -U boardypy
```

Starting with the Community/Pro model, commercial features require a signed `license.bpylic` file. One active Pro license unlocks all Pro features. TFT drawing in Pixel Matrix is Pro; OLED drawing remains free.

The standalone owner-only License Maker lives in `license_maker/` and is not included in the PyPI package.

## Run

```bash
boardypy
```

## Development

```bash
pip install -e .
python -m boardypy
```

## Pro License Docs

See [docs/PRO_LICENSE.md](docs/PRO_LICENSE.md) for:

- creating private/public keys
- keeping `private_key.pem` safe
- generating `license.bpylic`
- activating Pro inside BoardyPy settings
- building the standalone License Maker for Windows and Linux

## Notes

- Python `>=3.9` is required by project metadata.
- Runtime configuration, logs, sessions, and `license.bpylic` are stored in the user profile directory, not inside the installed package.
- On Linux, serial access may require adding your user to the device group, for example: `sudo usermod -a -G dialout $USER`, then logging out and back in.
- The toolbar web search opens Yandex Search in the external browser; the generated URL includes the `clid` parameter.
- See `LICENSE` for the Community/Pro license model.
