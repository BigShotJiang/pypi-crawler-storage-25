from __future__ import annotations

import json
import subprocess
import sys
from typing import Any


_RUNNER_CODE = r'''
from __future__ import annotations

import builtins
import json
import sys
import time as _real_time
import traceback
import types


REQUEST = json.loads(sys.stdin.read() or "{}")
PROFILE = str(REQUEST.get("profile", "auto"))
CODE = str(REQUEST.get("code", ""))
MAX_TIMELINE_FRAMES = 40


def _profile_defaults(profile):
    if profile == "oled_128x32":
        return "oled", 128, 32
    if profile == "tft_128x160":
        return "tft", 128, 160
    if profile == "tft_160x128":
        return "tft", 160, 128
    return "oled", 128, 64


class _Capture:
    def __init__(self, target):
        self._target = target
        self._buffer = ""

    def write(self, text):
        text = str(text)
        if not text:
            return 0
        self._buffer += text
        while "\n" in self._buffer:
            line, self._buffer = self._buffer.split("\n", 1)
            self._target.append(line)
        return len(text)

    def flush(self):
        if self._buffer:
            self._target.append(self._buffer)
            self._buffer = ""


class _Env:
    def __init__(self):
        self.output = []
        self.stderr = []
        self.events = []
        self.displays = []
        self.frames = []
        self.sleep_count = 0
        self.pixel_event_count = 0

    def event(self, message):
        if len(self.events) < 500:
            self.events.append(str(message))

    def pixel_event(self, message):
        self.pixel_event_count += 1
        if self.pixel_event_count <= 80:
            self.event(message)
        elif self.pixel_event_count == 81:
            self.event("more TFT pixel writes hidden")

    def add_display(self, display):
        self.displays.append(display)
        self.event(f"{display.label}: {display.width}x{display.height}")

    def last_display(self):
        if self.displays:
            return self.displays[-1]
        mode, width, height = _profile_defaults(PROFILE)
        return _Display(width, height, mode=mode, label="Virtual display")

    def snapshot(self, duration_ms=0, reason="frame"):
        display = self.last_display()
        revision = getattr(display, "_revision", 0)
        if self.frames and self.frames[-1].get("_revision") == revision:
            return
        if len(self.frames) >= MAX_TIMELINE_FRAMES:
            return
        frame = {
            "duration_ms": max(40, int(duration_ms or 0)),
            "reason": str(reason),
            "display": display.snapshot(),
            "_revision": revision,
        }
        self.frames.append(frame)


ENV = _Env()


class _SimulationComplete(Exception):
    pass


def _limit_lines(values, limit=500):
    values = list(values)
    if len(values) <= limit:
        return values
    return values[:limit] + [f"... truncated {len(values) - limit} lines ..."]


def _rgb565_from(value, mode):
    if mode == "oled":
        return 1 if value else 0
    if isinstance(value, (tuple, list)) and len(value) >= 3:
        r, g, b = [max(0, min(255, int(part))) for part in value[:3]]
        return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)
    try:
        return int(value) & 0xFFFF
    except Exception:
        return 0xFFFF


class _Canvas:
    def __init__(self, width, height, mode="oled"):
        self.width = max(1, int(width))
        self.height = max(1, int(height))
        self.mode = mode
        self.background = 0 if mode == "oled" else 0x0000
        self.pixels = [
            [self.background for _ in range(self.width)]
            for _ in range(self.height)
        ]
        self.text_ops = []
        self._revision = 0

    def _touch(self):
        self._revision += 1

    def _inside(self, x, y):
        return 0 <= x < self.width and 0 <= y < self.height

    def _color(self, value):
        return _rgb565_from(value, self.mode)

    def fill(self, color):
        color = self._color(color)
        for y in range(self.height):
            self.pixels[y] = [color for _ in range(self.width)]
        self._touch()
        return None

    def pixel(self, x, y, color=None):
        x = int(x)
        y = int(y)
        if color is None:
            if not self._inside(x, y):
                return 0
            return self.pixels[y][x]
        if self._inside(x, y):
            self.pixels[y][x] = self._color(color)
            self._touch()
        return None

    def hline(self, x, y, width, color):
        x = int(x)
        y = int(y)
        width = int(width)
        for px in range(x, x + width):
            self.pixel(px, y, color)

    def vline(self, x, y, height, color):
        x = int(x)
        y = int(y)
        height = int(height)
        for py in range(y, y + height):
            self.pixel(x, py, color)

    def rect(self, x, y, width, height, color):
        x = int(x)
        y = int(y)
        width = int(width)
        height = int(height)
        self.hline(x, y, width, color)
        self.hline(x, y + height - 1, width, color)
        self.vline(x, y, height, color)
        self.vline(x + width - 1, y, height, color)

    def fill_rect(self, x, y, width, height, color):
        x = int(x)
        y = int(y)
        width = int(width)
        height = int(height)
        for py in range(y, y + height):
            for px in range(x, x + width):
                self.pixel(px, py, color)

    def line(self, x0, y0, x1, y1, color):
        x0 = int(x0)
        y0 = int(y0)
        x1 = int(x1)
        y1 = int(y1)
        dx = abs(x1 - x0)
        dy = -abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx + dy
        while True:
            self.pixel(x0, y0, color)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def text(self, text, x, y, color=1, *args):
        del args
        self.text_ops.append(
            {
                "text": str(text),
                "x": int(x),
                "y": int(y),
                "color": self._color(color),
            }
        )
        self._touch()

    def scroll(self, dx, dy):
        dx = int(dx)
        dy = int(dy)
        new_pixels = [
            [self.background for _ in range(self.width)]
            for _ in range(self.height)
        ]
        for y in range(self.height):
            for x in range(self.width):
                nx = x + dx
                ny = y + dy
                if 0 <= nx < self.width and 0 <= ny < self.height:
                    new_pixels[ny][nx] = self.pixels[y][x]
        self.pixels = new_pixels
        self._touch()

    def blit(self, source, x, y, *args):
        del args
        if not hasattr(source, "pixels"):
            return
        for sy, row in enumerate(source.pixels):
            for sx, color in enumerate(row):
                if color:
                    self.pixel(int(x) + sx, int(y) + sy, color)


class _Display(_Canvas):
    def __init__(self, width, height, mode="oled", label="Display"):
        super().__init__(width, height, mode)
        self.label = label
        self.power_on = True
        self.inverted = False
        self.backlight_on = True
        self._window = (0, 0, self.width - 1, self.height - 1)
        self._window_cursor = 0
        ENV.add_display(self)

    def snapshot(self):
        return {
            "mode": self.mode,
            "width": self.width,
            "height": self.height,
            "pixels": [row[:] for row in self.pixels],
            "text": [dict(item) for item in self.text_ops],
        }

    def show(self):
        ENV.event(f"{self.label}.show()")

    def init(self, *args, **kwargs):
        del args, kwargs
        ENV.event(f"{self.label}.init()")

    def initr(self, *args, **kwargs):
        del args, kwargs
        ENV.event(f"{self.label}.initr()")

    def reset(self):
        ENV.event(f"{self.label}.reset()")

    def power(self, state=None):
        if state is None:
            return self.power_on
        self.power_on = bool(state)
        ENV.event(f"{self.label}.power({self.power_on})")

    def poweroff(self):
        self.power(False)

    def poweron(self):
        self.power(True)

    def invert(self, state=None):
        if state is None:
            return self.inverted
        self.inverted = bool(state)
        ENV.event(f"{self.label}.invert({self.inverted})")

    def contrast(self, contrast):
        ENV.event(f"{self.label}.contrast({contrast})")

    def backlight(self, state=None):
        if state is None:
            return self.backlight_on
        self.backlight_on = bool(state)
        ENV.event(f"{self.label}.backlight({self.backlight_on})")

    def clear(self, color=0):
        self.fill(color)

    def _set_window(self, x0, y0, x1, y1, *args, **kwargs):
        del args, kwargs
        x0 = max(0, min(self.width - 1, int(x0)))
        y0 = max(0, min(self.height - 1, int(y0)))
        x1 = max(0, min(self.width - 1, int(x1)))
        y1 = max(0, min(self.height - 1, int(y1)))
        if x1 < x0:
            x0, x1 = x1, x0
        if y1 < y0:
            y0, y1 = y1, y0
        self._window = (x0, y0, x1, y1)
        self._window_cursor = 0

    def write_cmd(self, cmd):
        ENV.event(f"{self.label}.cmd(0x{int(cmd) & 0xFF:02X})")

    def write_data(self, data):
        try:
            size = len(data)
        except Exception:
            size = 1
        if self.mode == "tft":
            try:
                raw = bytes(data)
            except Exception:
                raw = b""
            if len(raw) >= 2:
                x0, y0, x1, y1 = self._window
                width = max(1, x1 - x0 + 1)
                max_pixels = width * max(1, y1 - y0 + 1)
                pixel_count = min(len(raw) // 2, max_pixels - self._window_cursor)
                for index in range(pixel_count):
                    offset = index * 2
                    color = ((raw[offset] & 0xFF) << 8) | (raw[offset + 1] & 0xFF)
                    pixel_index = self._window_cursor + index
                    x = x0 + (pixel_index % width)
                    y = y0 + (pixel_index // width)
                    if y > y1:
                        break
                    self.pixel(x, y, color)
                self._window_cursor += max(0, pixel_count)
        ENV.pixel_event(f"{self.label}.data({size} bytes)")

    def write_pixels(self, count, color):
        color_value = self._decode_color_data(color)
        x0, y0, x1, y1 = self._window
        width = max(1, x1 - x0 + 1)
        total = max(0, min(int(count), width * max(1, y1 - y0 + 1)))
        for offset in range(total):
            pixel_index = self._window_cursor + offset
            x = x0 + (pixel_index % width)
            y = y0 + (pixel_index // width)
            if y > y1:
                break
            self.pixel(x, y, color_value)
        self._window_cursor += total
        if total:
            self._touch()
        ENV.pixel_event(f"{self.label}.pixels({total})")

    @staticmethod
    def _decode_color_data(data):
        if isinstance(data, int):
            return data & 0xFFFF
        try:
            if len(data) >= 2:
                return ((int(data[0]) & 0xFF) << 8) | (int(data[1]) & 0xFF)
        except Exception:
            pass
        return 0xFFFF


class _SSD1306(_Display):
    def __init__(self, width, height, *args, **kwargs):
        del args, kwargs
        super().__init__(width, height, mode="oled", label="SSD1306 OLED")


class _TFT(_Display):
    COLOR_BLACK = 0x0000
    COLOR_BLUE = 0x001F
    COLOR_RED = 0xF800
    COLOR_GREEN = 0x07E0
    COLOR_CYAN = 0x07FF
    COLOR_MAGENTA = 0xF81F
    COLOR_YELLOW = 0xFFE0
    COLOR_WHITE = 0xFFFF
    BLACK = COLOR_BLACK
    BLUE = COLOR_BLUE
    RED = COLOR_RED
    GREEN = COLOR_GREEN
    CYAN = COLOR_CYAN
    MAGENTA = COLOR_MAGENTA
    YELLOW = COLOR_YELLOW
    WHITE = COLOR_WHITE
    RGB = 0x00
    BGR = 0x08

    def __init__(self, *args, **kwargs):
        width = kwargs.pop("width", None)
        height = kwargs.pop("height", None)
        if len(args) >= 2 and isinstance(args[0], int) and isinstance(args[1], int):
            width, height = args[0], args[1]
        if width is None or height is None:
            mode, width, height = _profile_defaults(PROFILE)
            if mode != "tft":
                width, height = 128, 160
        super().__init__(width, height, mode="tft", label="TFT display")

    def rgbcolor(self, r, g, b):
        return _rgb565_from((r, g, b), "tft")

    def text(self, *args, **kwargs):
        color = kwargs.get("color", 0xFFFF)
        if len(args) >= 5 and isinstance(args[0], int):
            x, y, value, _font, color = args[:5]
            super().text(value, x, y, color)
            return
        if len(args) >= 5:
            _font, value, x, y, color = args[:5]
            super().text(value, x, y, color)
            return
        if len(args) >= 3:
            x, y, value = args[:3]
            super().text(value, x, y, color)

    def char(self, x, y, value, font=None, color=0xFFFF, *args):
        del font, args
        super().text(value, x, y, color)


class _Pin:
    IN = 0
    OUT = 1
    OPEN_DRAIN = 2
    PULL_UP = 1
    PULL_DOWN = 2

    def __init__(self, pin_id, mode=-1, pull=None, value=None):
        self.id = pin_id
        self.mode = mode
        self.pull = pull
        self._value = 0 if value is None else int(bool(value))
        ENV.event(f"Pin({self.id}) init mode={self.mode} value={self._value}")

    def init(self, mode=-1, pull=None, value=None):
        self.mode = mode
        self.pull = pull
        if value is not None:
            self._value = int(bool(value))
        ENV.event(f"Pin({self.id}).init(mode={self.mode}, value={self._value})")

    def value(self, value=None):
        if value is None:
            ENV.event(f"Pin({self.id}).value() -> {self._value}")
            return self._value
        self._value = int(bool(value))
        ENV.event(f"Pin({self.id}).value({self._value})")
        return self._value

    def on(self):
        return self.value(1)

    def off(self):
        return self.value(0)

    def high(self):
        return self.on()

    def low(self):
        return self.off()

    __call__ = value


class _I2C:
    def __init__(self, id=-1, scl=None, sda=None, freq=400000, **kwargs):
        del kwargs
        self.id = id
        self.scl = scl
        self.sda = sda
        self.freq = freq
        ENV.event(f"I2C({self.id}) freq={self.freq}")

    def scan(self):
        addresses = [0x3C, 0x76, 0x48]
        ENV.event("I2C.scan() -> " + ", ".join(hex(item) for item in addresses))
        return addresses

    def writeto(self, addr, data, *args):
        del args
        ENV.event(f"I2C.writeto(0x{int(addr):02X}, {len(data)} bytes)")

    def writevto(self, addr, data, *args):
        del args
        size = 0
        for chunk in data:
            if chunk is not None:
                size += len(chunk)
        ENV.event(f"I2C.writevto(0x{int(addr):02X}, {size} bytes)")

    def readfrom(self, addr, size, *args):
        del args
        ENV.event(f"I2C.readfrom(0x{int(addr):02X}, {int(size)} bytes)")
        return bytes([0] * int(size))

    def readfrom_mem(self, addr, memaddr, size, *args):
        del args
        ENV.event(f"I2C.readfrom_mem(0x{int(addr):02X}, 0x{int(memaddr):02X}, {int(size)})")
        return bytes([0] * int(size))

    def writeto_mem(self, addr, memaddr, data, *args):
        del args
        ENV.event(f"I2C.writeto_mem(0x{int(addr):02X}, 0x{int(memaddr):02X}, {len(data)} bytes)")


class _SPI:
    def __init__(self, id=1, baudrate=1000000, polarity=0, phase=0, **kwargs):
        del kwargs
        self.id = id
        self.baudrate = baudrate
        self.polarity = polarity
        self.phase = phase
        ENV.event(f"SPI({self.id}) baudrate={self.baudrate}")

    def init(self, **kwargs):
        self.baudrate = kwargs.get("baudrate", self.baudrate)
        ENV.event(f"SPI({self.id}).init(baudrate={self.baudrate})")

    def write(self, data):
        ENV.event(f"SPI({self.id}).write({len(data)} bytes)")

    def read(self, size, write=0x00):
        del write
        ENV.event(f"SPI({self.id}).read({int(size)} bytes)")
        return bytes([0] * int(size))


class _PWM:
    def __init__(self, pin, freq=1000, duty=0, **kwargs):
        del kwargs
        self.pin = pin
        self._freq = freq
        self._duty = duty
        ENV.event(f"PWM(Pin {getattr(pin, 'id', pin)}) freq={freq} duty={duty}")

    def freq(self, value=None):
        if value is None:
            return self._freq
        self._freq = value
        ENV.event(f"PWM.freq({value})")

    def duty(self, value=None):
        if value is None:
            return self._duty
        self._duty = value
        ENV.event(f"PWM.duty({value})")

    def duty_u16(self, value=None):
        return self.duty(value)

    def deinit(self):
        ENV.event("PWM.deinit()")


class _ADC:
    def __init__(self, pin=0):
        self.pin = pin
        ENV.event(f"ADC({pin})")

    def read(self):
        ENV.event("ADC.read() -> 512")
        return 512

    def read_u16(self):
        ENV.event("ADC.read_u16() -> 32768")
        return 32768


class _Timer:
    PERIODIC = 1
    ONE_SHOT = 0

    def __init__(self, timer_id=-1):
        self.id = timer_id

    def init(self, period=0, mode=PERIODIC, callback=None, **kwargs):
        del kwargs
        ENV.event(f"Timer({self.id}).init(period={period}, mode={mode})")
        if callback is not None:
            callback(self)

    def deinit(self):
        ENV.event(f"Timer({self.id}).deinit()")


class _WLAN:
    STA_IF = 0
    AP_IF = 1

    def __init__(self, interface=0):
        self.interface = interface
        self._active = False
        self._connected = False

    def active(self, value=None):
        if value is None:
            return self._active
        self._active = bool(value)
        ENV.event(f"WLAN.active({self._active})")

    def connect(self, ssid, password=None):
        del password
        self._connected = True
        ENV.event(f"WLAN.connect({ssid!r})")

    def isconnected(self):
        return True

    def ifconfig(self):
        return ("192.168.4.2", "255.255.255.0", "192.168.4.1", "8.8.8.8")

    def scan(self):
        return [(b"BoardyPy-Sim", b"", 1, -45, 0, False)]


def _sleep(seconds):
    duration_ms = 0
    if isinstance(seconds, str):
        raw = seconds.strip().lower()
        if raw.endswith("ms"):
            try:
                duration_ms = int(float(raw[:-2]))
            except ValueError:
                duration_ms = 0
        elif raw.endswith("us"):
            try:
                duration_ms = max(1, int(float(raw[:-2]) / 1000))
            except ValueError:
                duration_ms = 0
    else:
        try:
            duration_ms = int(float(seconds) * 1000)
        except (TypeError, ValueError):
            duration_ms = 0
    ENV.snapshot(duration_ms, "sleep")
    ENV.sleep_count += 1
    if ENV.sleep_count <= 12:
        ENV.event(f"sleep({seconds})")
    if ENV.sleep_count >= MAX_TIMELINE_FRAMES:
        ENV.event(f"simulation stopped after {MAX_TIMELINE_FRAMES} virtual sleeps")
        raise _SimulationComplete()


def _ticks_ms():
    return int(_real_time.monotonic() * 1000)


def _install_modules():
    machine = types.ModuleType("machine")
    machine.Pin = _Pin
    machine.I2C = _I2C
    machine.SoftI2C = _I2C
    machine.SPI = _SPI
    machine.SoftSPI = _SPI
    machine.PWM = _PWM
    machine.ADC = _ADC
    machine.Timer = _Timer
    machine.freq = lambda *args: 80000000 if not args else ENV.event(f"machine.freq({args[0]})")
    machine.reset = lambda: ENV.event("machine.reset()")
    sys.modules["machine"] = machine

    framebuf = types.ModuleType("framebuf")
    framebuf.MONO_VLSB = 0
    framebuf.MONO_HLSB = 1
    framebuf.RGB565 = 2
    framebuf.FrameBuffer = lambda buffer, width, height, format: _Canvas(
        width, height, "tft" if format == framebuf.RGB565 else "oled"
    )
    sys.modules["framebuf"] = framebuf

    ssd1306 = types.ModuleType("ssd1306")
    ssd1306.SSD1306 = _SSD1306
    ssd1306.SSD1306_I2C = _SSD1306
    ssd1306.SSD1306_SPI = _SSD1306
    sys.modules["ssd1306"] = ssd1306

    st7735 = types.ModuleType("st7735")
    st7735.ST7735 = _TFT
    for name in (
        "COLOR_BLACK", "COLOR_BLUE", "COLOR_RED", "COLOR_GREEN", "COLOR_CYAN",
        "COLOR_MAGENTA", "COLOR_YELLOW", "COLOR_WHITE", "RGB", "BGR",
    ):
        setattr(st7735, name, getattr(_TFT, name))
    sys.modules["st7735"] = st7735

    tft = types.ModuleType("tft")
    tft.TFT = _TFT
    tft.TFT_GREEN = _TFT
    tft.rgbcolor = lambda r, g, b: _rgb565_from((r, g, b), "tft")
    for name in (
        "COLOR_BLACK", "COLOR_BLUE", "COLOR_RED", "COLOR_GREEN", "COLOR_CYAN",
        "COLOR_MAGENTA", "COLOR_YELLOW", "COLOR_WHITE", "BLACK", "BLUE", "RED",
        "GREEN", "CYAN", "MAGENTA", "YELLOW", "WHITE", "RGB", "BGR",
    ):
        setattr(tft, name, getattr(_TFT, name))
    sys.modules["tft"] = tft

    font = types.ModuleType("font")
    font.terminalfont = {"width": 6, "height": 8, "start": 32, "end": 127, "data": bytearray()}
    sys.modules["font"] = font

    network = types.ModuleType("network")
    network.STA_IF = _WLAN.STA_IF
    network.AP_IF = _WLAN.AP_IF
    network.WLAN = _WLAN
    sys.modules["network"] = network

    fake_time = types.ModuleType("time")
    fake_time.sleep = _sleep
    fake_time.sleep_ms = lambda value: _sleep(f"{value}ms")
    fake_time.sleep_us = lambda value: _sleep(f"{value}us")
    fake_time.ticks_ms = _ticks_ms
    fake_time.ticks_diff = lambda end, start: int(end) - int(start)
    fake_time.monotonic = _real_time.monotonic
    fake_time.time = lambda: int(_real_time.time())
    fake_time.localtime = _real_time.localtime
    sys.modules["time"] = fake_time
    sys.modules["utime"] = fake_time

    micropython = types.ModuleType("micropython")
    micropython.const = lambda value: value
    micropython.mem_info = lambda *args: ENV.event("micropython.mem_info()")
    micropython.schedule = lambda callback, arg=None: callback(arg)
    sys.modules["micropython"] = micropython

    gc = types.ModuleType("gc")
    gc.collect = lambda: ENV.event("gc.collect()")
    gc.mem_free = lambda: 42000
    gc.mem_alloc = lambda: 12000
    sys.modules["gc"] = gc

    fake_os = types.ModuleType("os")
    fake_os.listdir = lambda path="/": ["boot.py", "main.py", "lib"]
    fake_os.getcwd = lambda: "/"
    fake_os.mkdir = lambda path: ENV.event(f"os.mkdir({path!r})")
    fake_os.remove = lambda path: ENV.event(f"os.remove({path!r})")
    fake_os.rename = lambda old, new: ENV.event(f"os.rename({old!r}, {new!r})")
    fake_os.urandom = lambda size: bytes((index * 37) & 0xFF for index in range(int(size)))
    fake_os.getenv = lambda key, default=None: default
    fake_os.stat = lambda path: (0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    fake_os.uname = lambda: ("BoardyPy-Sim", "sim", "1.0", "MicroPython", "sim")
    sys.modules["os"] = fake_os
    sys.modules["uos"] = fake_os

    builtins.const = lambda value: value


_original_print = builtins.print
_original_stdout = sys.stdout
_original_stderr = sys.stderr
sys.stdout = _Capture(ENV.output)
sys.stderr = _Capture(ENV.stderr)


def _print(*args, **kwargs):
    sep = kwargs.get("sep", " ")
    end = kwargs.get("end", "\n")
    text = sep.join(str(item) for item in args) + end
    sys.stdout.write(text)


builtins.print = _print
_install_modules()

started = _real_time.monotonic()
ok = True
error = ""
try:
    compiled = compile(CODE, "simulated_main.py", "exec")
    exec(compiled, {"__name__": "__main__", "__file__": "simulated_main.py"})
except _SimulationComplete:
    ENV.event("simulation completed")
except Exception:
    ok = False
    error = traceback.format_exc()

sys.stdout.flush()
sys.stderr.flush()
builtins.print = _original_print
sys.stdout = _original_stdout
sys.stderr = _original_stderr

display = ENV.last_display()
ENV.snapshot(0, "final")
frames = []
for frame in ENV.frames:
    public_frame = dict(frame)
    public_frame.pop("_revision", None)
    frames.append(public_frame)
payload = {
    "ok": ok,
    "profile": PROFILE,
    "mode": display.mode,
    "elapsed_ms": int((_real_time.monotonic() - started) * 1000),
    "display": {
        "mode": display.mode,
        "width": display.width,
        "height": display.height,
        "pixels": display.pixels,
        "text": display.text_ops,
    },
    "frames": frames,
    "stdout": _limit_lines(ENV.output),
    "stderr": _limit_lines(ENV.stderr),
    "events": _limit_lines(ENV.events),
    "error": error,
}
sys.__stdout__.write(json.dumps(payload, ensure_ascii=False))
'''


def blank_simulation_result(profile: str = "auto", *, error: str = "") -> dict[str, Any]:
    mode = "tft" if profile.startswith("tft") else "oled"
    width, height = (128, 160) if profile == "tft_128x160" else (160, 128) if profile == "tft_160x128" else (128, 32) if profile == "oled_128x32" else (128, 64)
    background = 0x0000 if mode == "tft" else 0
    display = {
        "mode": mode,
        "width": width,
        "height": height,
        "pixels": [[background for _ in range(width)] for _ in range(height)],
        "text": [],
    }
    return {
        "ok": not bool(error),
        "profile": profile,
        "mode": mode,
        "elapsed_ms": 0,
        "display": display,
        "frames": [{"duration_ms": 250, "reason": "blank", "display": display}],
        "stdout": [],
        "stderr": [],
        "events": [],
        "error": error,
    }


def run_board_simulation(
    code: str,
    *,
    profile: str = "auto",
    timeout_seconds: float = 3.0,
) -> dict[str, Any]:
    request = json.dumps(
        {
            "code": code,
            "profile": profile,
        },
        ensure_ascii=False,
    )
    try:
        completed = subprocess.run(
            [sys.executable, "-I", "-c", _RUNNER_CODE],
            input=request,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            timeout=max(0.5, float(timeout_seconds)),
            check=False,
        )
    except subprocess.TimeoutExpired:
        return blank_simulation_result(
            profile,
            error=f"Simulation timeout after {timeout_seconds:.1f} seconds",
        )
    except OSError as exc:
        return blank_simulation_result(profile, error=f"Could not start simulator: {exc}")

    if completed.returncode != 0 and not completed.stdout.strip():
        stderr = completed.stderr.strip()
        return blank_simulation_result(
            profile,
            error=stderr or f"Simulator process exited with code {completed.returncode}",
        )

    try:
        result = json.loads(completed.stdout)
    except json.JSONDecodeError:
        return blank_simulation_result(
            profile,
            error=(
                "Simulator returned invalid data.\n\n"
                f"stdout:\n{completed.stdout}\n\nstderr:\n{completed.stderr}"
            ),
        )

    if completed.stderr.strip():
        stderr = result.setdefault("stderr", [])
        stderr.append(completed.stderr.strip())
    return result
