from __future__ import annotations

import json
import struct
from dataclasses import dataclass
from datetime import date
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from .device_id import device_id_matches
from .public_key import PUBLIC_KEY_PEM


MAGIC = b"BPYLIC1"
SIGNATURE_SIZE = 64
MAX_PAYLOAD_SIZE = 64 * 1024


@dataclass(frozen=True)
class LicenseStatus:
    active: bool
    reason: str
    payload: dict[str, Any] | None = None

    @property
    def email(self) -> str:
        return str((self.payload or {}).get("email", ""))

    @property
    def username(self) -> str:
        return str((self.payload or {}).get("username", ""))

    @property
    def expires(self) -> str:
        return str((self.payload or {}).get("expires", ""))

    @property
    def features(self) -> list[str]:
        values = (self.payload or {}).get("features", [])
        if not isinstance(values, list):
            return []
        return [str(value) for value in values]


def _load_public_key(public_key_pem: bytes) -> Ed25519PublicKey:
    key = serialization.load_pem_public_key(public_key_pem)
    if not isinstance(key, Ed25519PublicKey):
        raise ValueError("public key is not Ed25519")
    return key


def _split_license(data: bytes) -> tuple[bytes, bytes, bytes]:
    minimum_size = len(MAGIC) + 4 + SIGNATURE_SIZE
    if len(data) < minimum_size:
        raise ValueError("license file is too small")
    if not data.startswith(MAGIC):
        raise ValueError("invalid license header")

    payload_length = struct.unpack(">I", data[len(MAGIC) : len(MAGIC) + 4])[0]
    if payload_length <= 0 or payload_length > MAX_PAYLOAD_SIZE:
        raise ValueError("invalid payload length")

    payload_start = len(MAGIC) + 4
    payload_end = payload_start + payload_length
    signature_end = payload_end + SIGNATURE_SIZE
    if len(data) != signature_end:
        raise ValueError("invalid license size")

    signed_part = data[:payload_end]
    payload_bytes = data[payload_start:payload_end]
    signature = data[payload_end:signature_end]
    return signed_part, payload_bytes, signature


def read_license_payload(data: bytes) -> dict[str, Any]:
    _, payload_bytes, _ = _split_license(data)
    payload = json.loads(payload_bytes.decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("license payload must be a JSON object")
    return payload


def verify_license_signature(
    data: bytes,
    public_key_pem: bytes = PUBLIC_KEY_PEM,
) -> bool:
    signed_part, _, signature = _split_license(data)
    public_key = _load_public_key(public_key_pem)
    try:
        public_key.verify(signature, signed_part)
    except InvalidSignature:
        return False
    return True


def check_license_bytes(
    data: bytes | None,
    *,
    feature_name: str | None = None,
    public_key_pem: bytes = PUBLIC_KEY_PEM,
    today: date | None = None,
    check_device: bool = True,
) -> LicenseStatus:
    if not data:
        return LicenseStatus(False, "missing")

    try:
        if not verify_license_signature(data, public_key_pem):
            return LicenseStatus(False, "bad_signature")
        payload = read_license_payload(data)
    except (ValueError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        return LicenseStatus(False, f"invalid_format: {exc}")
    except Exception as exc:
        return LicenseStatus(False, f"invalid_key: {exc}")

    if payload.get("product") != "BoardyPy":
        return LicenseStatus(False, "wrong_product", payload)
    if int(payload.get("license_version", 0) or 0) != 1:
        return LicenseStatus(False, "unsupported_license_version", payload)
    if payload.get("plan") != "pro":
        return LicenseStatus(False, "wrong_plan", payload)

    expires_raw = str(payload.get("expires", "")).strip()
    try:
        expires = date.fromisoformat(expires_raw)
    except ValueError:
        return LicenseStatus(False, "invalid_expiration_date", payload)
    if expires < (today or date.today()):
        return LicenseStatus(False, "expired", payload)

    if check_device and not device_id_matches(str(payload.get("device_id", ""))):
        return LicenseStatus(False, "wrong_device", payload)

    features = payload.get("features", [])
    if features is not None and not isinstance(features, list):
        return LicenseStatus(False, "invalid_features", payload)

    return LicenseStatus(True, "active", payload)
