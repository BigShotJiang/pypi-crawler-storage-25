from __future__ import annotations

import shutil
from pathlib import Path

from ..paths import user_data_path
from .license_check import LicenseStatus, check_license_bytes


LICENSE_FILENAME = "license.bpylic"


def get_license_file_path() -> Path:
    return user_data_path(LICENSE_FILENAME)


def load_license() -> bytes | None:
    path = get_license_file_path()
    try:
        return path.read_bytes()
    except OSError:
        return None


def save_license_file(source_path: str | Path) -> LicenseStatus:
    source = Path(source_path)
    try:
        data = source.read_bytes()
    except OSError as exc:
        return LicenseStatus(False, f"read_failed: {exc}")

    status = check_license_bytes(data)
    if not status.active:
        return status

    target = get_license_file_path()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    except OSError as exc:
        return LicenseStatus(False, f"save_failed: {exc}", status.payload)
    return status


def delete_license() -> bool:
    path = get_license_file_path()
    try:
        path.unlink()
        return True
    except FileNotFoundError:
        return True
    except OSError:
        return False


def get_license_status() -> LicenseStatus:
    return check_license_bytes(load_license())


def is_pro_enabled() -> bool:
    return get_license_status().active


def has_feature(feature_name: str) -> bool:
    del feature_name
    return get_license_status().active
