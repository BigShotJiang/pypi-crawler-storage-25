from __future__ import annotations

import getpass
import hashlib
import platform
import re
import socket
from pathlib import Path


def _windows_machine_guid() -> str:
    if platform.system().lower() != "windows":
        return ""
    try:
        import winreg

        with winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SOFTWARE\Microsoft\Cryptography",
        ) as key:
            value, _ = winreg.QueryValueEx(key, "MachineGuid")
        return str(value).strip()
    except Exception:
        return ""


def _linux_machine_id() -> str:
    if platform.system().lower() != "linux":
        return ""
    for filename in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            value = Path(filename).read_text(encoding="utf-8").strip()
        except OSError:
            continue
        if value:
            return value
    return ""


def _fallback_fingerprint() -> str:
    parts = [
        socket.gethostname(),
        getpass.getuser(),
        platform.system(),
        platform.release(),
        platform.machine(),
        platform.node(),
    ]
    return "|".join(part.strip().lower() for part in parts if part)


def _device_fingerprint_source() -> str:
    source = _windows_machine_guid() or _linux_machine_id() or _fallback_fingerprint()
    return source.strip().lower()


def get_device_id() -> str:
    """Return a stable SHA256 hash for this machine, never raw serial data."""
    source = _device_fingerprint_source()
    digest_input = f"BoardyPy-device-id-v1|{source}".encode("utf-8", "replace")
    return hashlib.sha256(digest_input).hexdigest()


def get_device_code_for_user() -> str:
    """Return a short user-facing code derived from the full device hash."""
    digest = get_device_id().upper()
    return f"BPY-{digest[0:4]}-{digest[4:8]}-{digest[8:12]}"


def normalize_device_id(value: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


def device_id_matches(license_device_id: str) -> bool:
    expected_full = normalize_device_id(get_device_id())
    expected_code = normalize_device_id(get_device_code_for_user())
    actual = normalize_device_id(license_device_id)
    return bool(actual) and actual in {expected_full, expected_code}
